# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Pure Smart Tools Manager placement bridge for native Suite-owned panels.

The panel hot path performs only two fixed ``sys.modules`` lookups and one
public ``placement_allowed`` call.  It never imports, enables, reloads, scans,
repairs, caches, or mutates Smart Tools Manager.  Physical/logical editor
classification is local and deterministic.
"""

from __future__ import annotations

import sys

TOOL_KEY = "SMART_CAMLIGHT"

# These are the only Manager module names consulted by poll/draw code.
MANAGER_MODULE_NAMES = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
)

LOGICAL_TO_SPACE = {
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
}

PHYSICAL_SPACES = frozenset(LOGICAL_TO_SPACE.values())


def _text(value) -> str:
    try:
        return str(value or "").strip()
    except Exception:
        return ""


def _area_and_space(context):
    try:
        area = getattr(context, "area", None)
        space = getattr(context, "space_data", None)
    except Exception:
        return None, None
    return area, space


def physical_space_for_context(context) -> str | None:
    area, _space = _area_and_space(context)
    try:
        value = _text(getattr(area, "type", "")).upper()
    except Exception:
        return None
    return value if value in PHYSICAL_SPACES else None


def logical_editor_for_context(context) -> str | None:
    """Return one of Manager 1.5.57's 17 exact logical editor keys."""
    area, space = _area_and_space(context)
    try:
        area_type = _text(getattr(area, "type", "")).upper()
    except Exception:
        return None

    if area_type == "VIEW_3D":
        return "VIEW_3D"

    if area_type == "IMAGE_EDITOR":
        ui_type = _text(getattr(area, "ui_type", "") or getattr(space, "ui_type", "")).upper()
        mode = _text(getattr(space, "mode", "")).upper()
        return "UV_EDITOR" if ui_type in {"UV", "UV_EDITOR"} or mode == "UV" else "IMAGE_EDITOR"

    if area_type == "NODE_EDITOR":
        tree_type = _text(getattr(space, "tree_type", "") or getattr(area, "ui_type", "")).upper()
        if "COMPOSITOR" in tree_type:
            return "COMPOSITOR"
        if "GEOMETRY" in tree_type:
            return "GEOMETRY_NODE_EDITOR"
        if "TEXTURE" in tree_type:
            return "TEXTURE_NODE_EDITOR"
        # ShaderNodeTree and an empty, temporarily rebuilding Node Editor both
        # belong to the Manager's shader cell.  No active object is required.
        return "SHADER_EDITOR"

    if area_type == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if area_type == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if area_type == "DOPESHEET_EDITOR":
        return "DOPE_SHEET"

    if area_type == "GRAPH_EDITOR":
        mode = _text(getattr(space, "mode", "")).upper()
        return "DRIVERS" if mode == "DRIVERS" else "GRAPH_EDITOR"

    if area_type == "NLA_EDITOR":
        return "NLA_EDITOR"
    if area_type == "TEXT_EDITOR":
        return "TEXT_EDITOR"

    if area_type == "FILE_BROWSER":
        browse_mode = _text(getattr(space, "browse_mode", "") or getattr(area, "ui_type", "")).upper()
        return "ASSET_BROWSER" if browse_mode in {"ASSETS", "ASSET_BROWSER"} else "FILE_BROWSER"

    if area_type == "SPREADSHEET":
        return "SPREADSHEET"
    return None


def context_matches(logical_editor: str, context) -> bool:
    """Fail closed for unknown keys or physical/logical context mismatches."""
    key = _text(logical_editor).upper()
    expected_space = LOGICAL_TO_SPACE.get(key)
    if expected_space is None:
        return False
    if physical_space_for_context(context) != expected_space:
        return False
    return logical_editor_for_context(context) == key


def _manager_is_explicitly_disabled(module) -> bool:
    """Recognize the public enabled marker without consulting Manager internals."""
    try:
        return getattr(module, "__addon_enabled__", None) is False
    except Exception:
        return False


def _manager_modules():
    """Yield only the two contractually allowed already-loaded module objects."""
    seen: set[int] = set()
    for module_name in MANAGER_MODULE_NAMES:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        identity = id(module)
        if identity in seen:
            continue
        seen.add(identity)
        yield module_name, module


def placement_allowed(context, logical_editor: str) -> bool:
    """Return the Manager cell or standalone fail-open result.

    Known logical/physical mismatches fail closed before Manager lookup.  An
    absent, disabled, not-yet-READY, API-missing, exception-raising, or non-bool
    Manager is not verified authority and therefore fails open so the Suite
    remains independently usable.  A READY public API returns an exact bool and
    that bool is authoritative.
    """
    key = _text(logical_editor).upper()
    if not context_matches(key, context):
        return False

    for _module_name, module in _manager_modules():
        if _manager_is_explicitly_disabled(module):
            continue
        try:
            public_api = getattr(module, "placement_allowed", None)
        except Exception:
            public_api = None
        if not callable(public_api):
            continue
        try:
            result = public_api(TOOL_KEY, context, editor_key=key)
        except Exception:
            # Exceptions include genuinely NOT_READY transitions.  Without a
            # verified boolean authority the independent Suite remains usable.
            continue
        if isinstance(result, bool):
            return result
        # Non-bool means this module did not provide verified current-cell
        # authority.  A second exact alias may still be the live package copy.

    # No verified READY boolean was obtained.  This covers Manager absence,
    # disable, NOT_READY, stale alias modules, missing API, exceptions, and
    # non-bool results.  There is deliberately no private or cached fallback.
    return True


def refresh_public_api() -> bool:
    """Compatibility probe with no cache or mutation.

    Runtime registration may call this once, but panel polls always perform the
    same fixed live lookup so Manager enable/disable order cannot stale a cached
    function object.
    """
    for _module_name, module in _manager_modules():
        if _manager_is_explicitly_disabled(module):
            continue
        try:
            if callable(getattr(module, "placement_allowed", None)):
                return True
        except Exception:
            continue
    return False


def audit_snapshot() -> dict:
    loaded = []
    for module_name, module in _manager_modules():
        try:
            has_api = callable(getattr(module, "placement_allowed", None))
        except Exception:
            has_api = False
        loaded.append({
            "module": module_name,
            "disabled": _manager_is_explicitly_disabled(module),
            "has_public_placement_allowed": has_api,
        })
    return {
        "tool_key": TOOL_KEY,
        "manager_module_names": MANAGER_MODULE_NAMES,
        "loaded_modules": loaded,
        "logical_editor_count": len(LOGICAL_TO_SPACE),
        "physical_space_count": len(PHYSICAL_SPACES),
        "per_cell_cache": False,
    }
