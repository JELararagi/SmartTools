# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Exact, generation-owned Blender runtime resource lifecycle.

The shared ledger lives in ``bpy.app.driver_namespace`` so an older imported
module remains addressable during a disable/reload hand-off.  Every entry keeps
its exact Python identity.  A new generation never deletes or replaces a READY
older generation while its RNA is visible; Blender must first call that older
module's ``unregister`` function.
"""

from __future__ import annotations

from dataclasses import dataclass
import sys
import types
import uuid
from typing import Any, Callable, Iterable

import bpy
from bpy.app.handlers import persistent

SUITE_ID = "smart_camlight_suite"
LEDGER_KEY = "JELARARAGI_SMART_CAMLIGHT_RUNTIME_LEDGER_V3"
LEDGER_SCHEMA = 3
GENERATION = uuid.uuid4().hex

LOAD_POST_REARM_KEY = "lifecycle:load_post_rearm"

# Process-lifetime anchor for the shared ledger.  Measured on Blender 5.1.2
# (ec6e62d40fa9): ``bpy.app.driver_namespace`` is REPLACED with a fresh dict on
# every file load, so a ledger published only there disappears the first time
# the user opens a .blend.  ``shared_ledger()`` then minted an EMPTY ledger,
# ``_generation_record(create=False)`` returned None and
# ``unregister_generation()`` reported success having released nothing: disable
# left SCLSCameraSettings / SCLSLightSettings / SCLSObjectSettings /
# SCLSSceneSettings registered, their four pointer properties attached and this
# generation's translations catalog live, and the next enable died with
# "translations message cache already contains some data" (0 panels, 0
# operators until Blender restarted).
#
# A synthetic ``sys.modules`` entry is process-lifetime: it survives file loads
# and this package's own module purge, so the exact ledger object stays
# reachable and can be re-published into the fresh namespace deterministically.
_ANCHOR_MODULE_NAME = "jelararagi_smart_camlight_runtime_ledger_anchor_v1"

# The package module object this copy was imported into.  Used only to decline
# the dormant sweep when another imported copy has taken over the module tree.
_OWN_PACKAGE_MODULE = sys.modules.get(str(__package__ or SUITE_ID))

# True between ``commit_ready()`` and a successful release of this module
# copy's generation.  Module state is process-lifetime, so unlike the ledger it
# cannot be erased by a file load, which makes it the exact evidence that this
# copy owns resources the ledger can no longer account for.
_GENERATION_COMMITTED = False

STATE_REGISTERING = "REGISTERING"
STATE_READY = "READY"
STATE_RELEASING = "RELEASING"
STATE_FAILED = "FAILED"
STATE_RELEASE_FAILED = "RELEASE_FAILED"

BEGIN_STARTED = "STARTED"
BEGIN_ALREADY_CURRENT = "ALREADY_CURRENT"
BEGIN_ACTIVE_OTHER = "ACTIVE_OTHER_GENERATION"

_MISSING = object()


class LifecycleError(RuntimeError):
    pass


class ActiveGenerationError(LifecycleError):
    pass


class ResourceIdentityError(LifecycleError):
    pass


def _driver_namespace() -> dict:
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    if not isinstance(namespace, dict):
        raise LifecycleError("bpy.app.driver_namespace is unavailable")
    return namespace


def _anchor_store() -> dict:
    """Process-lifetime store keeping the exact ledger object reachable."""
    module = sys.modules.get(_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart CamLight runtime-ledger anchor. Keeps the exact ledger "
            "object reachable across Blender file loads, which replace "
            "bpy.app.driver_namespace. Not an importable module."
        )
        module.SCLS_LEDGERS = {}
        sys.modules[_ANCHOR_MODULE_NAME] = module
    store = getattr(module, "SCLS_LEDGERS", None)
    if not isinstance(store, dict):
        store = {}
        module.SCLS_LEDGERS = store
    return store


def _fresh_ledger() -> dict:
    return {
        "schema": LEDGER_SCHEMA,
        "suite_id": SUITE_ID,
        "active_generation": None,
        "generations": {},
        "last_error": "",
        "last_transition": "",
    }


def _valid_ledger(value) -> bool:
    return bool(
        isinstance(value, dict)
        and value.get("schema") == LEDGER_SCHEMA
        and value.get("suite_id") == SUITE_ID
    )


def shared_ledger() -> dict:
    namespace = _driver_namespace()
    value = namespace.get(LEDGER_KEY)
    if value is None:
        # A file load replaced driver_namespace.  The anchored ledger still
        # holds this generation's exact release callbacks, and every resource
        # it journals is process-global and survives a file load, so it stays
        # authoritative.  Re-publish it instead of minting an empty one.
        anchored = _anchor_store().get(LEDGER_KEY)
        if _valid_ledger(anchored):
            namespace[LEDGER_KEY] = anchored
            value = anchored
    if not _valid_ledger(value):
        value = _fresh_ledger()
        namespace[LEDGER_KEY] = value
    value.setdefault("generations", {})
    # Keep the anchor pointed at the exact live ledger object, including one
    # created or adopted by a prior generation of this suite.
    _anchor_store()[LEDGER_KEY] = value
    return value


@persistent
def _rearm_after_load(*_args) -> None:
    """Re-publish the anchored ledger after Blender replaces driver_namespace.

    Acquired on ``load_post`` as this generation's FIRST journaled resource, so
    the re-arm is itself owned and is removed by the generation's own teardown.
    Never raises: a persistent handler must not break foreign handlers or user
    work.  Reading the ledger is what re-publishes it (see ``shared_ledger``).
    """
    try:
        shared_ledger()
    except Exception:
        pass


def arm_load_post_rearm() -> bool:
    """Acquire the ``load_post`` re-arm for the current generation."""
    handler_list = getattr(getattr(bpy.app, "handlers", None), "load_post", None)
    if handler_list is None:
        return False
    if _resource_by_key(LOAD_POST_REARM_KEY) is None:
        # A dormant predecessor of THIS module copy can leave the exact callback
        # attached with no ledger row owning it.  The object is this module's
        # own function, so retiring it before re-acquisition adopts our own
        # leftover; no foreign handler is ever removed here.
        for item in reversed(tuple(handler_list)):
            if item is _rearm_after_load:
                try:
                    handler_list.remove(item)
                except Exception:
                    pass
    register_handler(LOAD_POST_REARM_KEY, handler_list, _rearm_after_load)
    return True


def _generation_record(generation: str = GENERATION, *, create: bool = False) -> dict | None:
    ledger = shared_ledger()
    records = ledger.setdefault("generations", {})
    record = records.get(generation)
    if record is None and create:
        record = {
            "generation": generation,
            "state": STATE_REGISTERING,
            "module_name": __package__ or SUITE_ID,
            "resources": [],
            "last_error": "",
            "ready_token": None,
        }
        records[generation] = record
    return record


def current_state() -> str:
    record = _generation_record(create=False)
    return str(record.get("state", "")) if isinstance(record, dict) else ""


def active_generation() -> str | None:
    value = shared_ledger().get("active_generation")
    return str(value) if value else None


def _raw_class_attribute(owner: type, name: str):
    try:
        return vars(owner).get(name, _MISSING)
    except Exception:
        return _MISSING


def _registered_python_type(identifier: str):
    identifier = str(identifier or "").strip()
    if not identifier:
        return None
    try:
        candidate = getattr(getattr(bpy, "types", None), identifier, None)
    except Exception:
        candidate = None
    return candidate if isinstance(candidate, type) else None


def _retire_stale_owned_pointer(owner: type, name: str, property_group: type) -> bool:
    """Remove one orphaned Smart CamLight pointer after exact type proof."""
    descriptor = _raw_class_attribute(owner, name)
    if descriptor is _MISSING:
        return False
    try:
        properties = getattr(getattr(owner, "bl_rna", None), "properties", None)
        rna_property = properties.get(name) if properties is not None else None
        fixed_type = getattr(rna_property, "fixed_type", None) if rna_property is not None else None
        expected_rna = getattr(property_group, "bl_rna", None)
        fixed_identifier = str(getattr(fixed_type, "identifier", "") or "")
        expected_identifier = str(getattr(expected_rna, "identifier", "") or "")
        fixed_module = str(getattr(fixed_type, "__module__", "") or "")
        expected_module = str(getattr(property_group, "__module__", "") or "")
        stale_type = _registered_python_type(fixed_identifier)
        package_name = str(__package__ or SUITE_ID)
        owned_module = package_name + ".properties"
        stale_module = str(getattr(stale_type, "__module__", "") or "")
        exact_owned_type = bool(
            fixed_identifier
            and fixed_identifier == expected_identifier
            and expected_module == owned_module
            and (
                fixed_module == owned_module
                or (stale_type is not None and stale_module == owned_module)
            )
        )
    except Exception:
        exact_owned_type = False
    if not exact_owned_type:
        return False
    try:
        delattr(owner, name)
    except Exception as exc:
        raise ResourceIdentityError(
            f"stale Smart CamLight pointer could not be retired: "
            f"{getattr(owner, '__name__', owner)}.{name}: {exc}"
        ) from exc
    if _raw_class_attribute(owner, name) is not _MISSING:
        raise ResourceIdentityError(
            f"stale Smart CamLight pointer remained after retirement: "
            f"{getattr(owner, '__name__', owner)}.{name}"
        )
    return True


def _class_identity_live(cls: type) -> bool:
    """Return whether Blender owns this exact Python RNA class identity.

    Normal attribute lookup can expose the base ``bpy.types.Operator.bl_rna``
    on an unregistered subclass.  Only a direct subclass RNA descriptor or an
    exact ``bpy.types`` class identity is accepted as registration evidence.
    """
    local_rna = _raw_class_attribute(cls, "bl_rna")
    types_namespace = getattr(bpy, "types", None)

    try:
        class_name = str(getattr(cls, "__name__", "") or "")
        exposed_by_name = getattr(types_namespace, class_name, _MISSING) if class_name else _MISSING
    except Exception:
        exposed_by_name = _MISSING
    if exposed_by_name is not _MISSING:
        return exposed_by_name is cls

    if local_rna is _MISSING or local_rna is None:
        return False

    try:
        identifier = str(getattr(local_rna, "identifier", "") or "")
        exposed = getattr(types_namespace, identifier, _MISSING) if identifier else _MISSING
        if exposed is not _MISSING:
            return exposed is cls
    except Exception:
        pass
    # Some extension RNA classes are not published as bpy.types attributes. A
    # direct non-inherited descriptor remains exact evidence in that case.
    return True


def class_identity_live(cls: type) -> bool:
    """Public read-only exact class identity probe used before instrumentation."""
    return _class_identity_live(cls)


def _verify_resource(resource: dict) -> bool:
    kind = resource.get("kind")
    try:
        if kind == "class":
            return _class_identity_live(resource["class"])
        if kind == "pointer_property":
            owner = resource["owner"]
            name = resource["name"]
            group = resource["property_group"]
            if _raw_class_attribute(owner, name) is not resource["descriptor"]:
                return False
            if not _class_identity_live(group):
                return False
            # Blender exposes the registered PointerProperty through the owning
            # RNA type.  When fixed_type is available, verify that it still
            # points at this exact PropertyGroup RNA identity.
            try:
                properties = getattr(getattr(owner, "bl_rna", None), "properties", None)
                rna_property = properties.get(name) if properties is not None else None
                fixed_type = getattr(rna_property, "fixed_type", None) if rna_property is not None else None
                group_rna = getattr(group, "bl_rna", None)
                if fixed_type is not None and group_rna is not None:
                    if fixed_type is not group_rna:
                        fixed_identifier = str(getattr(fixed_type, "identifier", "") or "")
                        group_identifier = str(getattr(group_rna, "identifier", "") or "")
                        if not fixed_identifier or fixed_identifier != group_identifier:
                            return False
            except Exception:
                pass
            return True
        if kind == "handler":
            callback = resource["callback"]
            return any(item is callback for item in tuple(resource["handler_list"]))
        if kind == "timer":
            callback = resource["callback"]
            if not bool(resource.get("armed", True)):
                return True
            return bool(bpy.app.timers.is_registered(callback))
        if kind in {"msgbus", "translation"}:
            return bool(resource.get("active", False))
    except Exception:
        return False
    return False


def verify_generation(generation: str = GENERATION) -> bool:
    record = _generation_record(generation, create=False)
    if not isinstance(record, dict):
        return False
    resources = tuple(record.get("resources", ()))
    return bool(resources) and all(_verify_resource(item) for item in resources)


def begin_registration() -> str:
    ledger = shared_ledger()
    active = ledger.get("active_generation")
    if active:
        active_record = _generation_record(str(active), create=False)
        if active == GENERATION and isinstance(active_record, dict) and active_record.get("state") == STATE_READY and verify_generation(GENERATION):
            return BEGIN_ALREADY_CURRENT
        # Never live-swap visible RNA from another READY generation.  The old
        # module retains exact release callbacks in this ledger and must be
        # disabled first by Blender.
        if isinstance(active_record, dict) and active_record.get("state") == STATE_READY:
            ledger["last_transition"] = BEGIN_ACTIVE_OTHER
            return BEGIN_ACTIVE_OTHER
        # A failed/releasing generation may be completed by exact identity.
        if isinstance(active_record, dict) and active_record.get("state") in {STATE_FAILED, STATE_RELEASE_FAILED, STATE_RELEASING}:
            _release_generation(str(active), allow_active=True)
            if ledger.get("active_generation"):
                ledger["last_transition"] = BEGIN_ACTIVE_OTHER
                return BEGIN_ACTIVE_OTHER
        elif active:
            ledger["last_transition"] = BEGIN_ACTIVE_OTHER
            return BEGIN_ACTIVE_OTHER

    record = _generation_record(create=True)
    record["state"] = STATE_REGISTERING
    record["resources"] = []
    record["last_error"] = ""
    record["ready_token"] = None
    ledger["last_transition"] = BEGIN_STARTED
    return BEGIN_STARTED


def _resources() -> list[dict]:
    record = _generation_record(create=True)
    return record.setdefault("resources", [])


def _resource_by_key(resource_key: str) -> dict | None:
    for resource in reversed(tuple(_resources())):
        if resource.get("resource_key") == resource_key:
            return resource
    return None


def _append_resource(resource: dict) -> dict:
    resource["generation"] = GENERATION
    _resources().append(resource)
    return resource


def register_class(cls: type, *, resource_key: str | None = None) -> type:
    existing = _resource_by_key(resource_key) if resource_key else None
    if existing is not None:
        if existing.get("class") is cls and _verify_resource(existing):
            return cls
        raise ResourceIdentityError(f"resource key already acquired: {resource_key}")
    bpy.utils.register_class(cls)
    resource = _append_resource({
        "kind": "class",
        "resource_key": resource_key or f"class:{cls.__module__}.{cls.__qualname__}",
        "class": cls,
    })
    if not _verify_resource(resource):
        _release_resource(resource)
        try:
            _resources().remove(resource)
        except ValueError:
            pass
        raise ResourceIdentityError(f"registered class identity verification failed: {cls.__name__}")
    return cls


def register_pointer_property(owner: type, name: str, prop_definition, *, property_group: type) -> object:
    key = f"pointer:{getattr(owner, '__name__', str(owner))}.{name}"
    existing_resource = _resource_by_key(key)
    if existing_resource is not None:
        if _verify_resource(existing_resource):
            return existing_resource["descriptor"]
        raise ResourceIdentityError(f"owned pointer property identity changed: {key}")

    before = _raw_class_attribute(owner, name)
    if before is not _MISSING:
        # Interrupted package replacement can leave a suite-owned PointerProperty
        # after its generation ledger has gone. Retire it only when Blender's
        # fixed RNA type resolves to the previous Smart CamLight class. Unknown
        # or foreign descriptors remain fail-closed.
        if not _retire_stale_owned_pointer(owner, name, property_group):
            raise ResourceIdentityError(f"pointer property already exists and is not owned by this generation: {key}")
    setattr(owner, name, prop_definition)
    descriptor = _raw_class_attribute(owner, name)
    if descriptor is _MISSING:
        try:
            delattr(owner, name)
        except Exception:
            pass
        raise ResourceIdentityError(f"pointer property descriptor unavailable: {key}")
    resource = _append_resource({
        "kind": "pointer_property",
        "resource_key": key,
        "owner": owner,
        "name": name,
        "descriptor": descriptor,
        "property_group": property_group,
    })
    if not _verify_resource(resource):
        _release_resource(resource)
        try:
            _resources().remove(resource)
        except ValueError:
            pass
        raise ResourceIdentityError(f"pointer property identity verification failed: {key}")
    return descriptor


def register_handler(resource_key: str, handler_list, callback: Callable) -> Callable:
    existing = _resource_by_key(resource_key)
    if existing is not None:
        if existing.get("callback") is callback and _verify_resource(existing):
            return callback
        raise ResourceIdentityError(f"handler resource key already acquired: {resource_key}")
    if any(item is callback for item in tuple(handler_list)):
        # The exact callback is already live but no current-generation ledger
        # entry owns it.  Never adopt a stale/foreign handler implicitly.
        raise ResourceIdentityError(f"handler callback is registered without current generation ownership: {resource_key}")
    handler_list.append(callback)
    resource = _append_resource({
        "kind": "handler",
        "resource_key": resource_key,
        "handler_list": handler_list,
        "callback": callback,
    })
    if not _verify_resource(resource):
        _release_resource(resource)
        try:
            _resources().remove(resource)
        except ValueError:
            pass
        raise ResourceIdentityError(f"handler identity verification failed: {resource_key}")
    return callback




def _identity_component(value):
    """Build a finite exact-identity token for one msgbus subscription value."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return (type(value).__name__, value)
    if isinstance(value, tuple):
        return ("tuple", tuple(_identity_component(item) for item in value))
    if isinstance(value, (set, frozenset)):
        return ("set", tuple(sorted((_identity_component(item) for item in value), key=repr)))
    if isinstance(value, list):
        return ("list", tuple(_identity_component(item) for item in value))
    try:
        pointer = int(value.as_pointer())
    except Exception:
        pointer = 0
    return ("rna", pointer) if pointer else ("python", id(value))


def _msgbus_signature(subscriptions: tuple[dict, ...]) -> tuple:
    return tuple(
        (
            _identity_component(spec.get("key")),
            _identity_component(tuple(spec.get("args", ()) or ())),
            ("notify", id(spec.get("notify"))),
            _identity_component(set(spec.get("options", set()) or set())),
        )
        for spec in subscriptions
    )

def register_msgbus_group(resource_key: str, subscriptions: Iterable[dict]) -> object:
    specs = tuple(dict(spec) for spec in subscriptions)
    signature = _msgbus_signature(specs)
    existing = _resource_by_key(resource_key)
    if existing is not None:
        if _verify_resource(existing) and existing.get("signature") == signature:
            return existing["owner"]
        # Membership changes are handled only at an explicit settings/event
        # boundary. Release the exact current-generation owner before acquiring
        # a new owner; no foreign or prior-generation subscription is touched.
        if not release_resource_key(resource_key):
            raise ResourceIdentityError(f"msgbus resource identity could not be released: {resource_key}")
    owner = object()
    try:
        for spec in specs:
            kwargs = dict(spec)
            kwargs["owner"] = owner
            bpy.msgbus.subscribe_rna(**kwargs)
    except Exception:
        try:
            bpy.msgbus.clear_by_owner(owner)
        except Exception:
            pass
        raise
    _append_resource({
        "kind": "msgbus",
        "resource_key": resource_key,
        "owner": owner,
        "signature": signature,
        "active": True,
    })
    return owner


def register_translation(resource_key: str, translation_key: str, dictionary: dict) -> str:
    existing = _resource_by_key(resource_key)
    if existing is not None:
        if existing.get("translation_key") == translation_key and _verify_resource(existing):
            return translation_key
        raise ResourceIdentityError(f"translation resource key already acquired: {resource_key}")
    bpy.app.translations.register(translation_key, dictionary)
    _append_resource({
        "kind": "translation",
        "resource_key": resource_key,
        "translation_key": translation_key,
        "active": True,
    })
    return translation_key


def schedule_one_shot_timer(resource_key: str, callback: Callable, *, first_interval: float = 0.0) -> bool:
    existing = _resource_by_key(resource_key)
    if existing is not None:
        if existing.get("callback") is callback and _verify_resource(existing):
            return False
        if existing.get("callback") is callback and not bool(existing.get("armed", True)):
            try:
                _resources().remove(existing)
            except ValueError:
                pass
        else:
            raise ResourceIdentityError(f"timer resource key already acquired: {resource_key}")
    if bpy.app.timers.is_registered(callback):
        raise ResourceIdentityError(f"timer callback is registered without current generation ownership: {resource_key}")
    bpy.app.timers.register(callback, first_interval=max(0.0, float(first_interval)))
    resource = _append_resource({
        "kind": "timer",
        "resource_key": resource_key,
        "callback": callback,
        "armed": True,
    })
    if not _verify_resource(resource):
        _release_resource(resource)
        try:
            _resources().remove(resource)
        except ValueError:
            pass
        raise ResourceIdentityError(f"timer identity verification failed: {resource_key}")
    return True


def retire_one_shot_timer(resource_key: str, callback: Callable) -> None:
    resource = _resource_by_key(resource_key)
    if resource is None or resource.get("callback") is not callback:
        return
    resource["armed"] = False
    try:
        _resources().remove(resource)
    except ValueError:
        pass


def release_resource_key(resource_key: str) -> bool:
    resource = _resource_by_key(resource_key)
    if resource is None:
        return True
    released = _release_resource(resource)
    if released:
        try:
            _resources().remove(resource)
        except ValueError:
            pass
    return released


def _release_resource(resource: dict) -> bool:
    kind = resource.get("kind")
    try:
        if kind == "timer":
            callback = resource["callback"]
            try:
                if bpy.app.timers.is_registered(callback):
                    bpy.app.timers.unregister(callback)
            finally:
                resource["armed"] = False
            return True
        if kind == "msgbus":
            bpy.msgbus.clear_by_owner(resource["owner"])
            resource["active"] = False
            return True
        if kind == "handler":
            callback = resource["callback"]
            handler_list = resource["handler_list"]
            for item in reversed(tuple(handler_list)):
                if item is callback:
                    handler_list.remove(item)
            return not any(item is callback for item in tuple(handler_list))
        if kind == "pointer_property":
            owner = resource["owner"]
            name = resource["name"]
            if _raw_class_attribute(owner, name) is resource["descriptor"]:
                delattr(owner, name)
                return _raw_class_attribute(owner, name) is _MISSING
            # Another generation/foreign owner replaced the attribute. Never
            # delete it; report identity mismatch to keep the ledger visible.
            return False
        if kind == "class":
            cls = resource["class"]
            if not _class_identity_live(cls):
                return True
            bpy.utils.unregister_class(cls)
            return not _class_identity_live(cls)
        if kind == "translation":
            bpy.app.translations.unregister(resource["translation_key"])
            resource["active"] = False
            return True
    except Exception:
        return False
    return False


def commit_ready(*, ready_token: object | None = None) -> None:
    global _GENERATION_COMMITTED
    ledger = shared_ledger()
    record = _generation_record(create=False)
    if not isinstance(record, dict) or record.get("state") != STATE_REGISTERING:
        raise LifecycleError("generation is not registering")
    resources = tuple(record.get("resources", ()))
    if not resources or not all(_verify_resource(item) for item in resources):
        raise ResourceIdentityError("not all required runtime identities verified")
    active = ledger.get("active_generation")
    if active not in (None, GENERATION):
        raise ActiveGenerationError("another generation became active")
    record["ready_token"] = ready_token if ready_token is not None else object()
    record["state"] = STATE_READY
    ledger["active_generation"] = GENERATION
    ledger["last_error"] = ""
    ledger["last_transition"] = STATE_READY
    _GENERATION_COMMITTED = True


def rollback_registration(error: BaseException | str = "") -> bool:
    record = _generation_record(create=False)
    if not isinstance(record, dict):
        return True
    record["state"] = STATE_FAILED
    record["last_error"] = str(error or "")[:1000]
    shared_ledger()["last_error"] = record["last_error"]
    return _release_generation(GENERATION, allow_active=False)


def _release_generation(generation: str, *, allow_active: bool) -> bool:
    global _GENERATION_COMMITTED
    ledger = shared_ledger()
    record = _generation_record(generation, create=False)
    if not isinstance(record, dict):
        return True
    active = ledger.get("active_generation")
    if active == generation and not allow_active and generation != GENERATION:
        return False
    record["state"] = STATE_RELEASING
    resources = record.setdefault("resources", [])
    failures: list[str] = []
    for resource in reversed(tuple(resources)):
        if _release_resource(resource):
            try:
                resources.remove(resource)
            except ValueError:
                pass
        else:
            failures.append(str(resource.get("resource_key") or resource.get("kind") or "resource"))
    if failures:
        record["state"] = STATE_RELEASE_FAILED
        record["last_error"] = ", ".join(failures)[:1000]
        ledger["last_error"] = record["last_error"]
        return False
    if ledger.get("active_generation") == generation:
        ledger["active_generation"] = None
    ledger.setdefault("generations", {}).pop(generation, None)
    ledger["last_transition"] = "RELEASED"
    if generation == GENERATION:
        _GENERATION_COMMITTED = False
    return True



_ASYNC_RESOURCE_KINDS = frozenset({"handler", "timer", "msgbus"})


def release_local_async_resources(generation: str = GENERATION) -> dict[str, Any]:
    """Release exact asynchronous identities owned by one imported copy.

    This pass is intentionally independent of ``active_generation``.  During a
    reload hand-off another copy may already own visible RNA, but callbacks,
    one-shot timers and msgbus owners acquired by this module remain safe to
    release because the ledger stores their exact Python identities.  Classes,
    PointerProperties and translations are never touched by this preflight.
    """
    record = _generation_record(generation, create=False)
    result = {
        "generation": generation,
        "released": [],
        "failures": [],
    }
    if not isinstance(record, dict):
        return result
    resources = record.setdefault("resources", [])
    for resource in reversed(tuple(resources)):
        if resource.get("kind") not in _ASYNC_RESOURCE_KINDS:
            continue
        key = str(resource.get("resource_key") or resource.get("kind") or "resource")
        if _release_resource(resource):
            try:
                resources.remove(resource)
            except ValueError:
                pass
            result["released"].append(key)
        else:
            result["failures"].append(key)
    if result["failures"]:
        record["last_error"] = ", ".join(result["failures"])[:1000]
        shared_ledger()["last_error"] = record["last_error"]
    return result

def _package_prefix() -> str:
    return str(__package__ or SUITE_ID)


def _own_module_tree_is_live() -> bool:
    """False once another imported copy owns this package's module name."""
    current = sys.modules.get(_package_prefix())
    return current is not None and current is _OWN_PACKAGE_MODULE


def _owned_module_name(name: str) -> bool:
    prefix = _package_prefix()
    return bool(prefix) and (name == prefix or name.startswith(prefix + "."))


def _owned_class(cls) -> bool:
    return _owned_module_name(str(getattr(cls, "__module__", "") or ""))


def _iter_descendants(base):
    seen: set[int] = set()
    pending = list(base.__subclasses__())
    while pending:
        cls = pending.pop()
        if id(cls) in seen:
            continue
        seen.add(id(cls))
        yield cls
        try:
            pending.extend(cls.__subclasses__())
        except Exception:
            pass


_SWEEP_BASE_NAMES = (
    "Panel",
    "Operator",
    "Menu",
    "UIList",
    "Header",
    "AddonPreferences",
    "Gizmo",
    "GizmoGroup",
    "PropertyGroup",
)

_SWEEP_POINTER_OWNER_NAMES = (
    "Scene",
    "Object",
    "Camera",
    "Light",
    "World",
    "Collection",
    "Material",
    "Mesh",
    "Armature",
    "ViewLayer",
    "WorkSpace",
    "WindowManager",
    "Screen",
    "Image",
    "NodeTree",
    "Brush",
)


def _sweep_dormant_leftovers() -> dict[str, Any]:
    """Module-prefix-owned teardown when no generation record can drive it.

    Only reached when this copy's generation record is unreachable, which is
    the shape the pre-anchor releases shipped: unregister released nothing and
    reported success.  Nothing outside this package's own installed module tree
    is touched, and the sweep declines entirely once another imported copy owns
    the package module name, because that copy's resources are not ours.
    """
    result: dict[str, Any] = {
        "declined": "",
        "pointers": [],
        "classes": [],
        "translations": [],
        "errors": [],
    }
    if not _own_module_tree_is_live():
        result["declined"] = "package module tree replaced by another copy"
        return result

    owned_classes: list[type] = []
    for base_name in _SWEEP_BASE_NAMES:
        base = getattr(getattr(bpy, "types", None), base_name, None)
        if not isinstance(base, type):
            continue
        for cls in _iter_descendants(base):
            if _owned_class(cls) and _class_identity_live(cls) and cls not in owned_classes:
                owned_classes.append(cls)

    group_identifiers: dict[str, type] = {}
    property_group = getattr(getattr(bpy, "types", None), "PropertyGroup", None)
    for cls in owned_classes:
        try:
            if property_group is None or not issubclass(cls, property_group):
                continue
        except Exception:
            continue
        rna = _raw_class_attribute(cls, "bl_rna")
        identifier = str(getattr(rna, "identifier", "") or "") if rna is not _MISSING else ""
        if identifier:
            group_identifiers[identifier] = cls

    # PointerProperties first: a PropertyGroup cannot be retired while an RNA
    # slot still resolves to it.
    for owner_name in _SWEEP_POINTER_OWNER_NAMES:
        owner = getattr(getattr(bpy, "types", None), owner_name, None)
        if not isinstance(owner, type):
            continue
        try:
            properties = tuple(owner.bl_rna.properties)
        except Exception:
            continue
        for rna_property in properties:
            try:
                if str(getattr(rna_property, "type", "") or "") != "POINTER":
                    continue
                name = str(getattr(rna_property, "identifier", "") or "")
                fixed_type = getattr(rna_property, "fixed_type", None)
                identifier = str(getattr(fixed_type, "identifier", "") or "")
            except Exception:
                continue
            if not name or identifier not in group_identifiers:
                continue
            if _raw_class_attribute(owner, name) is _MISSING:
                continue
            key = f"{owner_name}.{name}"
            try:
                delattr(owner, name)
            except Exception as exc:
                result["errors"].append(f"pointer {key}: {exc}")
                continue
            if _raw_class_attribute(owner, name) is _MISSING:
                result["pointers"].append(key)
            else:
                result["errors"].append(f"pointer {key}: still present after delattr")

    def _is_group(cls) -> bool:
        try:
            return property_group is not None and issubclass(cls, property_group)
        except Exception:
            return False

    # Leaf classes before PropertyGroups, so a group is retired last.
    for cls in sorted(owned_classes, key=_is_group):
        if not _class_identity_live(cls):
            continue
        name = str(getattr(cls, "__name__", "?") or "?")
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            result["errors"].append(f"class {name}: {exc}")
            continue
        if _class_identity_live(cls):
            result["errors"].append(f"class {name}: still registered after unregister")
        else:
            result["classes"].append(name)

    # This copy's own translations catalog key; the exact key this module copy
    # registered, never a scan of foreign catalogs.
    translation_key = f"{_package_prefix()}:{GENERATION}"
    try:
        bpy.app.translations.unregister(translation_key)
    except Exception:
        pass
    else:
        result["translations"].append(translation_key)
    return result


def unregister_generation() -> bool:
    global _GENERATION_COMMITTED
    ledger = shared_ledger()
    record = _generation_record(create=False)
    # Dormancy, exactly: this module copy committed a READY generation, and the
    # ledger no longer accounts for a single one of its resources.  The record
    # can be missing OR freshly minted and empty -- ``_resources()`` recreates
    # an empty record for this generation as soon as any earlier teardown step
    # asks for a resource key, so "record is None" alone does not detect it.
    dormant = bool(_GENERATION_COMMITTED) and (
        not isinstance(record, dict) or not record.get("resources")
    )
    if dormant:
        active = ledger.get("active_generation")
        if active and str(active) != GENERATION:
            # Another live generation owns the visible RNA. Its own module copy
            # must release it; never sweep a foreign generation's resources.
            ledger["last_transition"] = "NO_RECORD_ACTIVE_OTHER"
            return True
        sweep = _sweep_dormant_leftovers()
        ledger["last_sweep"] = sweep
        ledger["last_transition"] = "DORMANT_SWEEP"
        if isinstance(record, dict):
            record["state"] = STATE_RELEASING
        if sweep.get("errors"):
            ledger["last_error"] = "; ".join(str(item) for item in sweep["errors"])[:1000]
            return False
        if ledger.get("active_generation") == GENERATION:
            ledger["active_generation"] = None
        ledger.setdefault("generations", {}).pop(GENERATION, None)
        _GENERATION_COMMITTED = False
        _anchor_store().pop(LEDGER_KEY, None)
        return True
    if not isinstance(record, dict):
        return True

    # Always retire this module copy's exact handler/timer/msgbus identities
    # before checking whether another generation owns visible RNA.  This is the
    # reload-safe equivalent of an unregister owner guard preflight.
    async_result = release_local_async_resources(GENERATION)
    active = ledger.get("active_generation")
    if active not in (None, GENERATION):
        ledger["last_transition"] = "LOCAL_ASYNC_RELEASED_AFTER_HANDOFF"
        return not bool(async_result.get("failures"))
    released = _release_generation(GENERATION, allow_active=True)
    if released and not ledger.get("generations") and not ledger.get("active_generation"):
        # Nothing is owned any more; do not carry an empty ledger across the
        # process on the anchor.
        _anchor_store().pop(LEDGER_KEY, None)
    return released


def serializable_snapshot() -> dict[str, Any]:
    ledger = shared_ledger()
    result = {
        "schema": ledger.get("schema"),
        "suite_id": ledger.get("suite_id"),
        "active_generation": ledger.get("active_generation"),
        "last_error": ledger.get("last_error", ""),
        "last_transition": ledger.get("last_transition", ""),
        "generations": {},
    }
    for generation, record in ledger.get("generations", {}).items():
        result["generations"][str(generation)] = {
            "state": record.get("state"),
            "resource_keys": [str(item.get("resource_key") or "") for item in record.get("resources", ())],
            "resource_kinds": [str(item.get("kind") or "") for item in record.get("resources", ())],
        }
    return result
