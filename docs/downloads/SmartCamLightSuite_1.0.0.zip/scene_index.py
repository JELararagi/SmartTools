# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Bounded per-Scene Camera/Light UUID indexes.

Indexes are rebuilt only at explicit lifecycle/operator boundaries or for a
Scene placed in the finite dirty queue.  Property updates resolve their owner
through O(1) settings-pointer maps instead of scanning every Object once per
Camera/Light.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
import os
import uuid

import bpy

INDEX_SCHEMA = 2
MAX_SCENES = 256
UUID_NAMESPACE = uuid.UUID("667ad2f2-f7a5-4b93-a578-8539d47f611d")
OWNER_UUID_KEY = "_scls_owner_uuid"
ROLE_KEY = "_scls_role"
SOURCE_UUID_KEY = "_scls_source_uuid"
INSTANCE_UUID_KEY = "_scls_instance_uuid"
SUITE_OWNER_UUID = "d2644f44-9221-4df6-8973-88a825e9ca31"
_DRAW_REFRESH_CALLBACK = None


@dataclass
class SceneIndex:
    scene: object
    scene_pointer: int
    scene_uuid: str
    object_count: int = 0
    cameras: tuple = ()
    lights: tuple = ()
    camera_by_object_uuid: dict[str, object] = field(default_factory=dict)
    light_by_object_uuid: dict[str, object] = field(default_factory=dict)
    object_by_uuid: dict[str, object] = field(default_factory=dict)
    camera_data_by_uuid: dict[str, object] = field(default_factory=dict)
    light_data_by_uuid: dict[str, object] = field(default_factory=dict)
    camera_settings_to_objects: dict[int, tuple] = field(default_factory=dict)
    light_settings_to_objects: dict[int, tuple] = field(default_factory=dict)
    object_settings_to_objects: dict[int, tuple] = field(default_factory=dict)
    owned_helpers: dict[tuple[str, str], tuple] = field(default_factory=dict)
    dynamic_sun: object | None = None


_INDEXES: OrderedDict[int, SceneIndex] = OrderedDict()


def _pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value) if value is not None else 0


def _idprop(value, key: str, default=""):
    try:
        return value.get(key, default)
    except Exception:
        return default


def _normalize_path(path: str) -> str:
    text = str(path or "")
    try:
        text = bpy.path.abspath(text)
    except Exception:
        pass
    try:
        return os.path.normcase(os.path.normpath(text)) if text else ""
    except Exception:
        return text


def library_identity(id_data) -> str:
    if id_data is None:
        return ""
    try:
        library = getattr(id_data, "library", None)
        if library is not None:
            return _normalize_path(getattr(library, "filepath", ""))
    except Exception:
        pass
    try:
        override = getattr(id_data, "override_library", None)
        reference = getattr(override, "reference", None) if override is not None else None
        library = getattr(reference, "library", None) if reference is not None else None
        if library is not None:
            return _normalize_path(getattr(library, "filepath", ""))
    except Exception:
        pass
    return ""


def _is_writable_local(id_data) -> bool:
    if id_data is None or library_identity(id_data):
        return False
    try:
        if bool(getattr(id_data, "is_library_indirect", False)):
            return False
    except Exception:
        pass
    return True


def _valid_uuid(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        return str(uuid.UUID(text))
    except Exception:
        return ""


def _derived_uuid(id_data, kind: str) -> str:
    library = library_identity(id_data)
    name = str(getattr(id_data, "name_full", "") or getattr(id_data, "name", "") or "")
    payload = f"{kind}|{library}|{name}"
    return str(uuid.uuid5(UUID_NAMESPACE, payload))


def _settings_group(id_data, kind: str):
    try:
        if kind == "SCENE":
            return getattr(id_data, "smart_camlight_suite", None)
        if kind == "OBJECT":
            return getattr(id_data, "smart_camlight_object", None)
        if kind == "CAMERA":
            return getattr(id_data, "smart_camlight_settings", None)
        if kind == "LIGHT":
            return getattr(id_data, "smart_camlight_light", None)
    except Exception:
        pass
    return None


def persistent_uuid(id_data, kind: str, *, ensure: bool = False) -> str:
    group = _settings_group(id_data, kind)
    attr = "persistent_scene_uuid" if kind == "SCENE" else "persistent_uuid"
    value = _valid_uuid(getattr(group, attr, "") if group is not None else "")
    if value:
        return value
    if not _is_writable_local(id_data):
        return _derived_uuid(id_data, kind)
    if not ensure or group is None:
        return ""
    value = str(uuid.uuid4())
    try:
        setattr(group, attr, value)
        return value
    except Exception:
        return ""


def _assign_new_uuid(id_data, kind: str) -> str:
    group = _settings_group(id_data, kind)
    attr = "persistent_scene_uuid" if kind == "SCENE" else "persistent_uuid"
    if group is None or not _is_writable_local(id_data):
        return _derived_uuid(id_data, kind)
    value = str(uuid.uuid4())
    try:
        setattr(group, attr, value)
    except Exception:
        return ""
    return value


def identity_record(id_data, kind: str, *, ensure: bool = False) -> dict[str, str]:
    return {
        "kind": str(kind or ""),
        "persistent_uuid": persistent_uuid(id_data, kind, ensure=ensure),
        "library_identity": library_identity(id_data),
    }


def _append_map(mapping: dict[int, list], key: int, value) -> None:
    if key:
        mapping.setdefault(key, []).append(value)


def rebuild_scene(scene, *, ensure_uuids: bool = True) -> SceneIndex | None:
    if scene is None:
        return None
    scene_pointer = _pointer(scene)
    scene_uuid = persistent_uuid(scene, "SCENE", ensure=ensure_uuids)
    for other_pointer, other_index in tuple(_INDEXES.items()):
        if other_pointer == scene_pointer:
            continue
        if scene_uuid and other_index.scene_uuid == scene_uuid and other_index.scene is not scene and _is_writable_local(scene):
            scene_uuid = _assign_new_uuid(scene, "SCENE") if ensure_uuids else ""
            break
    cameras = []
    lights = []
    camera_by_object_uuid: dict[str, object] = {}
    light_by_object_uuid: dict[str, object] = {}
    object_by_uuid: dict[str, object] = {}
    camera_data_by_uuid: dict[str, object] = {}
    light_data_by_uuid: dict[str, object] = {}
    camera_settings: dict[int, list] = {}
    light_settings: dict[int, list] = {}
    object_settings: dict[int, list] = {}
    helper_lists: dict[tuple[str, str], list] = {}
    dynamic_sun = None

    seen_local_object_uuids: dict[str, object] = {}
    seen_local_camera_uuids: dict[str, object] = {}
    seen_local_light_uuids: dict[str, object] = {}
    for other_pointer, other_index in tuple(_INDEXES.items()):
        if other_pointer == scene_pointer:
            continue
        seen_local_object_uuids.update(other_index.object_by_uuid)
        seen_local_camera_uuids.update(other_index.camera_data_by_uuid)
        seen_local_light_uuids.update(other_index.light_data_by_uuid)

    try:
        objects = tuple(getattr(scene, "objects", ()) or ())
    except Exception:
        objects = ()

    for obj in objects:
        obj_kind = str(getattr(obj, "type", "") or "")
        obj_uuid = persistent_uuid(obj, "OBJECT", ensure=ensure_uuids)
        if obj_uuid and not library_identity(obj):
            prior = seen_local_object_uuids.get(obj_uuid)
            if prior is not None and prior is not obj:
                obj_uuid = _assign_new_uuid(obj, "OBJECT") if ensure_uuids else ""
            if obj_uuid:
                seen_local_object_uuids[obj_uuid] = obj
        if obj_uuid:
            object_by_uuid[obj_uuid] = obj
            group = _settings_group(obj, "OBJECT")
            _append_map(object_settings, _pointer(group), obj)

        owner_exact = str(_idprop(obj, OWNER_UUID_KEY, "") or "") == SUITE_OWNER_UUID
        instance_exact = bool(_valid_uuid(_idprop(obj, INSTANCE_UUID_KEY, "")))
        if owner_exact and instance_exact:
            role = str(_idprop(obj, ROLE_KEY, "") or "")
            source_uuid = _valid_uuid(_idprop(obj, SOURCE_UUID_KEY, ""))
            if role and source_uuid:
                helper_lists.setdefault((source_uuid, role), []).append(obj)
            if role == "dynamic_sun" and obj_kind == "LIGHT" and source_uuid == scene_uuid:
                dynamic_sun = obj

        data = getattr(obj, "data", None)
        if obj_kind == "CAMERA" and data is not None:
            cameras.append(obj)
            data_uuid = persistent_uuid(data, "CAMERA", ensure=ensure_uuids)
            if data_uuid and not library_identity(data):
                prior = seen_local_camera_uuids.get(data_uuid)
                if prior is not None and prior is not data:
                    data_uuid = _assign_new_uuid(data, "CAMERA") if ensure_uuids else ""
                if data_uuid:
                    seen_local_camera_uuids[data_uuid] = data
            if data_uuid:
                camera_data_by_uuid[data_uuid] = data
            if obj_uuid:
                camera_by_object_uuid[obj_uuid] = obj
            group = _settings_group(data, "CAMERA")
            _append_map(camera_settings, _pointer(group), obj)
        elif obj_kind == "LIGHT" and data is not None:
            lights.append(obj)
            data_uuid = persistent_uuid(data, "LIGHT", ensure=ensure_uuids)
            if data_uuid and not library_identity(data):
                prior = seen_local_light_uuids.get(data_uuid)
                if prior is not None and prior is not data:
                    data_uuid = _assign_new_uuid(data, "LIGHT") if ensure_uuids else ""
                if data_uuid:
                    seen_local_light_uuids[data_uuid] = data
            if data_uuid:
                light_data_by_uuid[data_uuid] = data
            if obj_uuid:
                light_by_object_uuid[obj_uuid] = obj
            group = _settings_group(data, "LIGHT")
            _append_map(light_settings, _pointer(group), obj)

    cameras.sort(key=lambda item: str(getattr(item, "name", "") or "").casefold())
    lights.sort(key=lambda item: str(getattr(item, "name", "") or "").casefold())
    index = SceneIndex(
        scene=scene,
        scene_pointer=scene_pointer,
        scene_uuid=scene_uuid,
        object_count=len(objects),
        cameras=tuple(cameras),
        lights=tuple(lights),
        camera_by_object_uuid=camera_by_object_uuid,
        light_by_object_uuid=light_by_object_uuid,
        object_by_uuid=object_by_uuid,
        camera_data_by_uuid=camera_data_by_uuid,
        light_data_by_uuid=light_data_by_uuid,
        camera_settings_to_objects={key: tuple(values) for key, values in camera_settings.items()},
        light_settings_to_objects={key: tuple(values) for key, values in light_settings.items()},
        object_settings_to_objects={key: tuple(values) for key, values in object_settings.items()},
        owned_helpers={key: tuple(values) for key, values in helper_lists.items()},
        dynamic_sun=dynamic_sun,
    )
    _INDEXES.pop(scene_pointer, None)
    _INDEXES[scene_pointer] = index
    while len(_INDEXES) > MAX_SCENES:
        _INDEXES.popitem(last=False)
    return index


def rebuild_all_scenes(*, ensure_uuids: bool = True) -> None:
    _INDEXES.clear()
    try:
        scenes = tuple(getattr(getattr(bpy, "data", None), "scenes", ()) or ())
    except Exception:
        scenes = ()
    for scene in scenes:
        rebuild_scene(scene, ensure_uuids=ensure_uuids)


def get_index(scene) -> SceneIndex | None:
    pointer = _pointer(scene)
    index = _INDEXES.get(pointer)
    if index is not None:
        _INDEXES.move_to_end(pointer)
    return index


def ensure_index(scene) -> SceneIndex | None:
    index = get_index(scene)
    if index is None or index.object_count != _scene_object_count(scene):
        return rebuild_scene(scene, ensure_uuids=True)
    return index


def invalidate_scene(scene) -> None:
    _INDEXES.pop(_pointer(scene), None)


def clear() -> None:
    global _DRAW_REFRESH_CALLBACK
    _INDEXES.clear()
    callback = _DRAW_REFRESH_CALLBACK
    _DRAW_REFRESH_CALLBACK = None
    try:
        if callback is not None and bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    except Exception:
        pass


def _scene_object_count(scene) -> int:
    try:
        return len(scene.objects)
    except Exception:
        return -1


def _index_is_stale(index, scene) -> bool:
    if index is None or index.object_count != _scene_object_count(scene):
        return True
    for obj in index.cameras + index.lights:
        try:
            obj.name
        except ReferenceError:
            return True
    return False


def _request_draw_refresh(scene) -> None:
    """Rebuild once outside draw, then redraw (a loaded file or an external add)."""
    global _DRAW_REFRESH_CALLBACK
    if _DRAW_REFRESH_CALLBACK is not None:
        return
    pointer = _pointer(scene)

    def _refresh():
        global _DRAW_REFRESH_CALLBACK
        _DRAW_REFRESH_CALLBACK = None
        for candidate in bpy.data.scenes:
            if _pointer(candidate) == pointer:
                rebuild_scene(candidate, ensure_uuids=True)
                break
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        return None

    _DRAW_REFRESH_CALLBACK = _refresh
    bpy.app.timers.register(_refresh, first_interval=0.0)


def _index_for_draw(scene):
    # Draw never traverses the Scene for the index or mutates it; a stale index
    # is shown once and replaced by a one-shot timer.
    index = get_index(scene)
    if scene is not None and _index_is_stale(index, scene):
        _request_draw_refresh(scene)
    return index


def camera_objects_for_draw(scene) -> tuple:
    index = _index_for_draw(scene)
    return _live_objects(index.cameras) if index is not None else ()


def light_objects_for_draw(scene) -> tuple:
    index = _index_for_draw(scene)
    return _live_objects(index.lights) if index is not None else ()


def _live_objects(objects) -> tuple:
    live = []
    for obj in objects:
        try:
            obj.name
        except ReferenceError:
            continue
        live.append(obj)
    return tuple(live)


def camera_objects_for_operation(scene) -> tuple:
    # Explicit operator boundaries may pay one linear Scene index rebuild.
    # This avoids stale equal-count replacement cases without any idle scan.
    index = rebuild_scene(scene, ensure_uuids=True)
    return index.cameras if index is not None else ()


def light_objects_for_operation(scene) -> tuple:
    index = rebuild_scene(scene, ensure_uuids=True)
    return index.lights if index is not None else ()


def camera_object_for_settings(settings, scene=None):
    pointer = _pointer(settings)
    if scene is not None:
        index = ensure_index(scene)
        values = index.camera_settings_to_objects.get(pointer, ()) if index else ()
        return values[0] if values else None
    for index in tuple(_INDEXES.values()):
        values = index.camera_settings_to_objects.get(pointer, ())
        if values:
            return values[0]
    return None


def light_objects_for_settings(settings, scene=None) -> tuple:
    pointer = _pointer(settings)
    if scene is not None:
        index = ensure_index(scene)
        return index.light_settings_to_objects.get(pointer, ()) if index else ()
    result = []
    for index in tuple(_INDEXES.values()):
        result.extend(index.light_settings_to_objects.get(pointer, ()))
    return tuple(result)


def object_for_settings(settings, scene=None):
    pointer = _pointer(settings)
    if scene is not None:
        index = ensure_index(scene)
        values = index.object_settings_to_objects.get(pointer, ()) if index else ()
        return values[0] if values else None
    for index in tuple(_INDEXES.values()):
        values = index.object_settings_to_objects.get(pointer, ())
        if values:
            return values[0]
    return None


def owned_helpers_for_source(scene, source_uuid: str, role: str) -> tuple:
    index = ensure_index(scene)
    if index is None:
        return ()
    return index.owned_helpers.get((str(source_uuid or ""), str(role or "")), ())


def dynamic_sun_for_scene(scene):
    index = ensure_index(scene)
    return index.dynamic_sun if index is not None else None


def audit_snapshot() -> dict:
    return {
        "index_schema": INDEX_SCHEMA,
        "max_scenes": MAX_SCENES,
        "scene_count": len(_INDEXES),
        "scenes": {
            str(index.scene_uuid): {
                "object_count": index.object_count,
                "camera_count": len(index.cameras),
                "light_count": len(index.lights),
                "owned_helper_keys": len(index.owned_helpers),
            }
            for index in _INDEXES.values()
        },
    }
