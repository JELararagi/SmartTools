# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Explicit operation status integration with safe shared-timer hand-off.

Operator methods are wrapped only while their classes are still plain Python
objects, before ``bpy.utils.register_class``.  This module never replaces a
Blender global API and never mutates a registered RNA class.

Some SmartTools packages also share the legacy single-slot status state stored
under ``JELARARAGI_SMARTTOOLS_STATUS_RUNTIME_V2``.  A timer callback kept in
that state is an exact Python object from one imported package copy.  On
unregister this module removes its own exact callback even when another copy
has taken Suite ownership, then asks a surviving provider copy to arm its own
callback when shared entries remain.  No foreign timer identity is removed.
"""

from __future__ import annotations

from collections import OrderedDict
from contextlib import nullcontext
import functools
import threading
import time
import uuid
from typing import Any

import bpy

from . import lifecycle

STATUS_NAMESPACE_KEY = "JELARARAGI_SMARTTOOLS_OPERATION_STATUS_V3"
_SHARED_STATUS_NAMESPACE_KEY = "JELARARAGI_SMARTTOOLS_STATUS_RUNTIME_V2"
_SHARED_PROVIDER_NAMESPACE_KEY = "JELARARAGI_SMARTTOOLS_STATUS_TIMER_PROVIDERS_V1"
# Compatibility name used by the shared SmartTools status runtime.
_NAMESPACE_KEY = _SHARED_STATUS_NAMESPACE_KEY
SUITE_ID = "smart_camlight_suite"
SUITE_LABEL = "Smart CamLight Suite"
MAX_STATUS_ENTRIES = 128
_SHARED_MIN_TIMER_INTERVAL = 0.04
_SHARED_UI_RETRY_INTERVAL = 0.10
_PREPARED_MARKER = "_scls_status_prepared_v112"
_PROVIDER_TOKEN = f"{SUITE_ID}:{lifecycle.GENERATION}"
_PROVIDER_REGISTERED = False
PREPARATION_AUDIT_LIMIT = 128
_MISSING = object()
_PREPARATION_AUDIT: list[dict] = []
_LAST_PREPARATION_REPORT: dict = {
    "status": "NOT_RUN",
    "class_count": 0,
    "prepared": [],
    "already_current": [],
    "safe_degraded": [],
}


def _driver_namespace() -> dict | None:
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    return namespace if isinstance(namespace, dict) else None


def _store() -> OrderedDict:
    namespace = _driver_namespace()
    if namespace is None:
        return OrderedDict()
    value = namespace.get(STATUS_NAMESPACE_KEY)
    if not isinstance(value, OrderedDict):
        value = OrderedDict()
        namespace[STATUS_NAMESPACE_KEY] = value
    return value


def _trim(store: OrderedDict) -> None:
    while len(store) > MAX_STATUS_ENTRIES:
        store.popitem(last=False)


def begin(operator_id: str, phase: str) -> str:
    token = uuid.uuid4().hex
    store = _store()
    store[token] = {
        "suite_id": SUITE_ID,
        "suite_label": SUITE_LABEL,
        "generation": lifecycle.GENERATION,
        "operator_id": str(operator_id or ""),
        "phase": str(phase or ""),
        "state": "RUNNING",
        "started_monotonic": time.monotonic(),
        "finished_monotonic": 0.0,
        "error": "",
    }
    _trim(store)
    return token


def finish(token: str, result=None) -> None:
    store = _store()
    record = store.get(token)
    if not isinstance(record, dict):
        return
    result_set = set(result or ()) if isinstance(result, (set, frozenset, tuple, list)) else set()
    record["state"] = "CANCELLED" if "CANCELLED" in result_set else "FINISHED"
    record["finished_monotonic"] = time.monotonic()
    store.move_to_end(token)
    _trim(store)


def fail(token: str, error: BaseException) -> None:
    store = _store()
    record = store.get(token)
    if not isinstance(record, dict):
        return
    record["state"] = "FAILED"
    record["finished_monotonic"] = time.monotonic()
    record["error"] = f"{type(error).__name__}: {str(error)[:240]}"
    store.move_to_end(token)
    _trim(store)


def _clear_operation_prefix(prefix: str) -> None:
    prefix_text = str(prefix or "")
    store = _store()
    for token, record in tuple(store.items()):
        if not isinstance(record, dict):
            continue
        suite_id = str(record.get("suite_id", "") or "")
        owner = str(record.get("owner", "") or "")
        if (
            suite_id.startswith(prefix_text)
            or owner.startswith(prefix_text)
            or str(token).startswith(prefix_text)
        ):
            store.pop(token, None)


def clear_suite_status() -> None:
    store = _store()
    for token, record in tuple(store.items()):
        if (
            isinstance(record, dict)
            and record.get("suite_id") == SUITE_ID
            and record.get("generation") == lifecycle.GENERATION
        ):
            store.pop(token, None)


def _class_label(cls) -> str:
    try:
        return str(getattr(cls, "__name__", "") or repr(cls))
    except Exception:
        return "<unknown>"


def _error_text(error: BaseException | str) -> str:
    if isinstance(error, BaseException):
        return f"{type(error).__name__}: {str(error)[:240]}"
    return str(error or "")[:280]


def _record_preparation_event(cls, disposition: str, *, phase: str, detail: str = "") -> None:
    _PREPARATION_AUDIT.append({
        "generation": lifecycle.GENERATION,
        "class": _class_label(cls),
        "phase": str(phase or "prepare"),
        "disposition": str(disposition or "UNKNOWN"),
        "detail": str(detail or "")[:280],
    })
    if len(_PREPARATION_AUDIT) > PREPARATION_AUDIT_LIMIT:
        del _PREPARATION_AUDIT[:-PREPARATION_AUDIT_LIMIT]


def _registered(cls) -> bool:
    """Return exact live RNA state; inherited base ``bl_rna`` is ignored."""
    try:
        return bool(lifecycle.class_identity_live(cls))
    except Exception:
        return False


def _wrap_method(cls, method_name: str, argument_kind: str) -> None:
    original = vars(cls).get(method_name)
    if not callable(original) or getattr(original, "_scls_status_wrapper", False):
        return
    operator_id = str(getattr(cls, "bl_idname", cls.__name__) or cls.__name__)

    if argument_kind == "context":
        @functools.wraps(original)
        def wrapped(self, context):
            token = begin(operator_id, method_name)
            try:
                result = original(self, context)
            except BaseException as exc:
                fail(token, exc)
                raise
            finish(token, result)
            return result
    elif argument_kind == "event":
        @functools.wraps(original)
        def wrapped(self, context, event):
            token = begin(operator_id, method_name)
            try:
                result = original(self, context, event)
            except BaseException as exc:
                fail(token, exc)
                raise
            finish(token, result)
            return result
    else:
        return
    wrapped._scls_status_wrapper = True
    wrapped._scls_status_original = original
    setattr(cls, method_name, wrapped)


def _restore_class_attribute(cls, name: str, value) -> str:
    try:
        current = vars(cls).get(name, _MISSING)
    except Exception as exc:
        return _error_text(exc)
    try:
        if value is _MISSING:
            if current is not _MISSING:
                delattr(cls, name)
        elif current is not value:
            setattr(cls, name, value)
        return ""
    except Exception as exc:
        return _error_text(exc)


def _instrument_class_transactional(cls) -> str:
    """Wrap a plain class and restore all touched attributes on any failure."""
    names = ("execute", "invoke", "modal", "cancel", _PREPARED_MARKER)
    try:
        before = {name: vars(cls).get(name, _MISSING) for name in names}
    except Exception as exc:
        return _error_text(exc)
    try:
        _wrap_method(cls, "execute", "context")
        _wrap_method(cls, "invoke", "event")
        _wrap_method(cls, "modal", "event")
        _wrap_method(cls, "cancel", "context")
        setattr(cls, _PREPARED_MARKER, True)
        return ""
    except Exception as exc:
        restore_errors = []
        for name in reversed(names):
            error = _restore_class_attribute(cls, name, before[name])
            if error:
                restore_errors.append(f"{name}={error}")
        detail = _error_text(exc)
        if restore_errors:
            detail = f"{detail}; restore: {'; '.join(restore_errors)}"
        return detail


def _public_preparation_report(
    *, status: str, classes: tuple, prepared: list, already_current: list, safe_degraded: list
) -> dict:
    return {
        "status": status,
        "class_count": len(classes),
        "prepared": [_class_label(cls) for cls in prepared],
        "already_current": [_class_label(cls) for cls in already_current],
        "safe_degraded": [
            {"class": _class_label(cls), "detail": detail}
            for cls, detail in safe_degraded
        ],
    }


def note_already_current_operator(cls, *, phase: str = "class_registration") -> None:
    """Record exact already-live RNA without mutating the registered class."""
    _record_preparation_event(cls, "ALREADY_CURRENT", phase=phase)


def record_preparation_safe_degradation(classes, error: BaseException | str) -> dict:
    """Convert an unexpected preparation failure into a non-throwing report."""
    global _LAST_PREPARATION_REPORT
    class_tuple = tuple(classes or ())
    detail = _error_text(error)
    degraded = [(cls, detail) for cls in class_tuple]
    for cls in class_tuple:
        _record_preparation_event(cls, "SAFE_DEGRADED", phase="prepare_entry", detail=detail)
    public = _public_preparation_report(
        status="SAFE_DEGRADED",
        classes=class_tuple,
        prepared=[],
        already_current=[],
        safe_degraded=degraded,
    )
    _LAST_PREPARATION_REPORT = public
    return {
        **public,
        "prepared_classes": (),
        "already_current_classes": (),
        "safe_degraded_classes": class_tuple,
    }


def prepare_operator_classes(classes) -> dict:
    """Instrument only unregistered classes and never abort add-on register.

    Exact registered classes continue as ``ALREADY_CURRENT`` no-ops. Any
    wrapping/probe failure is transactionally restored, recorded as
    ``SAFE_DEGRADED``, and returned without raising.
    """
    global _LAST_PREPARATION_REPORT
    class_tuple = tuple(classes or ())
    prepared: list = []
    already_current: list = []
    safe_degraded: list[tuple[object, str]] = []

    for cls in class_tuple:
        if _registered(cls):
            already_current.append(cls)
            _record_preparation_event(cls, "ALREADY_CURRENT", phase="prepare")
            continue
        try:
            marker_present = bool(vars(cls).get(_PREPARED_MARKER, False))
        except Exception as exc:
            detail = _error_text(exc)
            safe_degraded.append((cls, detail))
            _record_preparation_event(cls, "SAFE_DEGRADED", phase="marker_probe", detail=detail)
            continue
        if marker_present:
            prepared.append(cls)
            _record_preparation_event(cls, "PREPARED_CURRENT", phase="prepare")
            continue
        detail = _instrument_class_transactional(cls)
        if detail:
            safe_degraded.append((cls, detail))
            _record_preparation_event(cls, "SAFE_DEGRADED", phase="instrument", detail=detail)
        else:
            prepared.append(cls)
            _record_preparation_event(cls, "PREPARED", phase="instrument")

    if safe_degraded:
        status = "SAFE_DEGRADED"
    elif already_current and len(already_current) == len(class_tuple):
        status = "ALREADY_CURRENT"
    else:
        status = "READY"
    public = _public_preparation_report(
        status=status,
        classes=class_tuple,
        prepared=prepared,
        already_current=already_current,
        safe_degraded=safe_degraded,
    )
    _LAST_PREPARATION_REPORT = public
    return {
        **public,
        "prepared_classes": tuple(prepared),
        "already_current_classes": tuple(already_current),
        "safe_degraded_classes": tuple(cls for cls, _detail in safe_degraded),
    }


# -----------------------------------------------------------------------------
# Shared V2 status timer provider and exact-identity hand-off
# -----------------------------------------------------------------------------


def _shared_state() -> dict | None:
    """Return an existing V2 state without creating or replacing it.

    Other SmartTools copies own the V2 schema.  This compatibility layer only
    adds a provider lease when that state already exists, so it cannot replace
    a newer/foreign state or make an idle timer appear merely by importing this
    add-on.
    """
    namespace = _driver_namespace()
    if namespace is None:
        return None
    state = namespace.get(_SHARED_STATUS_NAMESPACE_KEY)
    return state if isinstance(state, dict) else None


def _provider_registry(*, create: bool) -> dict:
    namespace = _driver_namespace()
    if namespace is None:
        return {}
    registry = namespace.get(_SHARED_PROVIDER_NAMESPACE_KEY)
    if not isinstance(registry, dict):
        if not create:
            return {}
        registry = {}
        namespace[_SHARED_PROVIDER_NAMESPACE_KEY] = registry
    return registry


def _state_lock(state: dict):
    lock = state.get("lock")
    if hasattr(lock, "__enter__") and hasattr(lock, "__exit__"):
        return lock
    return nullcontext()


def _workspace_candidates() -> tuple:
    try:
        if bool(getattr(bpy.app, "background", False)):
            return ()
        if threading.current_thread() is not threading.main_thread():
            return ()
    except Exception:
        return ()
    result = []
    seen = set()

    def add(workspace) -> None:
        if workspace is None:
            return
        try:
            pointer = int(workspace.as_pointer())
        except Exception:
            pointer = id(workspace)
        if pointer in seen:
            return
        seen.add(pointer)
        result.append((pointer, workspace))

    try:
        wm = getattr(bpy.context, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            add(getattr(getattr(window, "screen", None), "workspace", None))
    except Exception:
        pass
    try:
        add(getattr(bpy.context, "workspace", None))
    except Exception:
        pass
    return tuple(result)


def _remove_expired_shared_entries(state: dict, now: float | None = None) -> None:
    entries = state.get("entries")
    if not isinstance(entries, dict):
        return
    current = time.monotonic() if now is None else float(now)
    for key, record in tuple(entries.items()):
        if not isinstance(record, dict):
            continue
        expires_at = record.get("expires_at")
        if expires_at is None:
            continue
        try:
            expired = float(expires_at) <= current
        except Exception:
            expired = True
        if expired:
            entries.pop(key, None)


def _publish_shared_status(state: dict) -> bool:
    entries = state.get("entries")
    if not isinstance(entries, dict):
        entries = {}
    candidates = [record for record in entries.values() if isinstance(record, dict)]
    top = max(
        candidates,
        key=lambda record: (int(record.get("priority", 0)), int(record.get("sequence", 0))),
        default=None,
    )
    text = str(top.get("text", "") or "") if isinstance(top, dict) else ""
    workspaces = _workspace_candidates()
    state.setdefault("workspace_text", {})
    workspace_text = state.get("workspace_text")
    if not isinstance(workspace_text, dict):
        workspace_text = {}
        state["workspace_text"] = workspace_text
    if not workspaces:
        state["last_text"] = text or None
        return False
    live = set()
    for pointer, workspace in workspaces:
        live.add(pointer)
        normalized = text or None
        if workspace_text.get(pointer) == normalized:
            continue
        try:
            workspace.status_text_set(text if text else None)
            workspace_text[pointer] = normalized
        except Exception:
            workspace_text.pop(pointer, None)
    for pointer in tuple(workspace_text):
        if pointer not in live:
            workspace_text.pop(pointer, None)
    state["last_text"] = text or None
    return True


def _shared_next_delay(state: dict) -> float | None:
    try:
        if bool(getattr(bpy.app, "background", False)):
            return None
    except Exception:
        return None
    entries = state.get("entries")
    if not isinstance(entries, dict) or not entries:
        return None
    now = time.monotonic()
    deadlines = []
    for record in entries.values():
        if not isinstance(record, dict) or record.get("expires_at") is None:
            continue
        try:
            deadlines.append(float(record["expires_at"]))
        except Exception:
            continue
    if deadlines:
        return max(_SHARED_MIN_TIMER_INTERVAL, min(deadlines) - now)
    if not _workspace_candidates():
        return _SHARED_UI_RETRY_INTERVAL
    return None


def _shared_timer():
    """Finite shared status callback owned by this exact module copy."""
    state = _shared_state()
    if state is None:
        return None
    with _state_lock(state):
        # A hand-off may have replaced ``timer_fn`` while this callback was
        # already executing.  Returning None retires only this callback.
        if state.get("timer_fn") is not _shared_timer:
            return None
        _remove_expired_shared_entries(state)
        _publish_shared_status(state)
        delay = _shared_next_delay(state)
        if delay is None:
            state["timer_registered"] = False
            return None
        return delay


def _provider_alive() -> bool:
    if not _PROVIDER_REGISTERED:
        return False
    try:
        state = lifecycle.current_state()
    except Exception:
        state = ""
    # A provider is published only from runtime.register().  An empty state is
    # accepted for compatibility with a live copy using a pre-ledger bootstrap,
    # while explicit failed/releasing states are never selected for hand-off.
    return state not in {
        lifecycle.STATE_FAILED,
        lifecycle.STATE_RELEASE_FAILED,
        lifecycle.STATE_RELEASING,
    }


def register_runtime() -> None:
    """Publish this copy as a possible V2 timer successor without arming it."""
    global _PROVIDER_REGISTERED
    registry = _provider_registry(create=True)
    registry[_PROVIDER_TOKEN] = {
        "token": _PROVIDER_TOKEN,
        "suite_id": SUITE_ID,
        "generation": lifecycle.GENERATION,
        "module_name": __name__,
        "timer_fn": _shared_timer,
        "ensure_fn": _ensure_shared_timer_from_provider,
        "alive_fn": _provider_alive,
        "registered_monotonic": time.monotonic(),
    }
    _PROVIDER_REGISTERED = True


def _unregister_exact_timer(callback) -> bool:
    if not callable(callback):
        return True
    try:
        timers = bpy.app.timers
        if timers.is_registered(callback):
            timers.unregister(callback)
        return not timers.is_registered(callback)
    except Exception:
        return False


def _ensure_shared_timer_from_provider(state: dict | None = None) -> bool:
    """Arm this provider's exact callback only while shared entries remain."""
    state = state if isinstance(state, dict) else _shared_state()
    if state is None:
        return False
    with _state_lock(state):
        entries = state.get("entries")
        if not isinstance(entries, dict) or not entries:
            state["timer_registered"] = False
            if state.get("timer_fn") is _shared_timer:
                state["timer_fn"] = None
            return False
        current = state.get("timer_fn")
        if callable(current) and current is not _shared_timer:
            try:
                if bpy.app.timers.is_registered(current):
                    state["timer_registered"] = True
                    return True
            except Exception:
                pass
        state["timer_fn"] = _shared_timer
        try:
            timers = bpy.app.timers
            if not timers.is_registered(_shared_timer):
                timers.register(_shared_timer, first_interval=_SHARED_MIN_TIMER_INTERVAL)
            state["timer_registered"] = True
            return True
        except Exception:
            if state.get("timer_fn") is _shared_timer:
                state["timer_fn"] = None
            state["timer_registered"] = False
            return False


def _surviving_provider() -> dict | None:
    registry = _provider_registry(create=False)
    candidates = []
    for token, record in tuple(registry.items()):
        if token == _PROVIDER_TOKEN or not isinstance(record, dict):
            continue
        alive_fn = record.get("alive_fn")
        ensure_fn = record.get("ensure_fn")
        timer_fn = record.get("timer_fn")
        alive = False
        try:
            alive = bool(alive_fn()) if callable(alive_fn) else False
        except Exception:
            alive = False
        if not alive or not callable(ensure_fn) or not callable(timer_fn):
            continue
        candidates.append(record)
    if not candidates:
        return None
    return max(candidates, key=lambda record: float(record.get("registered_monotonic", 0.0) or 0.0))


def _drop_own_provider() -> None:
    global _PROVIDER_REGISTERED
    namespace = _driver_namespace()
    if namespace is None:
        _PROVIDER_REGISTERED = False
        return
    registry = namespace.get(_SHARED_PROVIDER_NAMESPACE_KEY)
    if isinstance(registry, dict):
        registry.pop(_PROVIDER_TOKEN, None)
        if not registry:
            namespace.pop(_SHARED_PROVIDER_NAMESPACE_KEY, None)
    _PROVIDER_REGISTERED = False


def clear_prefix(prefix: str, *, context=None) -> None:
    """Clear this Suite status and hand off an exact shared timer identity.

    The current module's ``_shared_timer`` is always unregistered before its
    provider lease is removed, even if another package copy has already become
    the active Suite owner.  If unrelated V2 entries remain, the newest live
    provider copy registers its own exact callback.  No callback is selected by
    package-name text alone and no Blender API is monkeypatched.
    """
    del context  # Compatibility-only parameter; no context mutation is needed.
    prefix_text = str(prefix or "")
    _clear_operation_prefix(prefix_text)
    state = _shared_state()
    # Always probe this exact function object.  The shared state may already
    # point at a successor while this callback is still registered in Blender.
    own_timer = _shared_timer
    remaining_entries = False
    if state is not None:
        with _state_lock(state):
            entries = state.get("entries")
            if isinstance(entries, dict):
                for key, record in tuple(entries.items()):
                    owner = str(record.get("owner", "") or "") if isinstance(record, dict) else ""
                    if owner.startswith(prefix_text) or str(key).startswith(prefix_text):
                        entries.pop(key, None)
                remaining_entries = bool(entries)
            timer_fn = state.get("timer_fn")
            if timer_fn is _shared_timer:
                state["timer_fn"] = None
                state["timer_registered"] = False
            _publish_shared_status(state)
    # Exact timer release is deliberately outside the shared lock.  A callback
    # that is currently finishing sees ``timer_fn`` changed and returns None.
    _unregister_exact_timer(own_timer)
    _drop_own_provider()
    if state is not None and remaining_entries:
        provider = _surviving_provider()
        ensure_fn = provider.get("ensure_fn") if isinstance(provider, dict) else None
        if callable(ensure_fn):
            try:
                ensure_fn(state)
            except Exception:
                pass


def audit_snapshot() -> dict:
    store = _store()
    suite_records = [
        record
        for record in store.values()
        if (
            isinstance(record, dict)
            and record.get("suite_id") == SUITE_ID
            and record.get("generation") == lifecycle.GENERATION
        )
    ]
    shared_state = _shared_state()
    shared_timer_is_self = bool(
        isinstance(shared_state, dict)
        and shared_state.get("timer_fn") is _shared_timer
    )
    return {
        "schema": 4,
        "suite_id": SUITE_ID,
        "max_entries": MAX_STATUS_ENTRIES,
        "suite_entry_count": len(suite_records),
        "post_registration_mutation": False,
        "global_api_replacement": False,
        "shared_status_namespace": _SHARED_STATUS_NAMESPACE_KEY,
        "shared_provider_registered": _PROVIDER_REGISTERED,
        "shared_timer_is_this_module": shared_timer_is_self,
        "shared_timer_handoff": True,
        "preparation_policy": "PRE_REGISTER_ONLY_ALREADY_CURRENT_NO_OP_SAFE_DEGRADED",
        "last_preparation": dict(_LAST_PREPARATION_REPORT),
        "preparation_audit_limit": PREPARATION_AUDIT_LIMIT,
        "preparation_audit": [dict(item) for item in _PREPARATION_AUDIT],
        "instrumentation_exceptions_escape_register": False,
    }
