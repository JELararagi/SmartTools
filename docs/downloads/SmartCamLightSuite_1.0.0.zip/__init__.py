# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from . import lifecycle, runtime, translation

__version__ = "1.0.0"

bl_info = {
    'name': 'Smart CamLight',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'Sidebar > Smart CamLight',
    'description': 'Unified camera and light management with per-camera settings, rigs, paths, guides, linking, transactional light generation, and isolated Dynamic Sky.',
    'category': 'Camera',
}


def register() -> None:
    outcome = lifecycle.begin_registration()
    if outcome == lifecycle.BEGIN_ALREADY_CURRENT:
        return
    if outcome == lifecycle.BEGIN_ACTIVE_OTHER:
        # Visible RNA from another READY generation is never exchanged live.
        # Blender must call that exact generation unregister function first.
        return
    try:
        # FIRST acquisition of the generation: Blender replaces
        # bpy.app.driver_namespace on every file load, so the ledger is
        # re-published from its process-lifetime anchor by this handler.  Being
        # the first journaled resource makes it the last one released, so the
        # re-arm is live for the whole lifetime of the generation and is
        # removed by that generation's own teardown.
        lifecycle.arm_load_post_rearm()
        translation.I18N_DICT = translation.build_i18n_dict()
        lifecycle.register_translation(
            'translation:main',
            f'{__package__}:{lifecycle.GENERATION}',
            translation.I18N_DICT,
        )
        runtime.register()
        if not runtime.verify_ready():
            raise lifecycle.ResourceIdentityError('required Smart CamLight runtime identities are not READY')
        lifecycle.commit_ready(
            ready_token={
                'suite': 'Smart CamLight Suite',
                'version': __version__,
                'operators': 50,
                'panels': 12,
                'native_npanel_roots': 12,
                'property_groups': 4,
            }
        )
    except BaseException as exc:
        try:
            runtime.unregister()
        finally:
            lifecycle.rollback_registration(exc)
        raise


def unregister() -> None:
    # Exact local async cleanup is deliberately first.  It remains safe after a
    # reload hand-off because it removes only callback/owner objects created by
    # this imported module copy and never touches another copy's visible RNA.
    try:
        runtime.unregister_local_async_resources()
    except Exception:
        pass
    try:
        runtime.unregister()
    finally:
        lifecycle.unregister_generation()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
