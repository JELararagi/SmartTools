# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

import math
import os
import random
import textwrap

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

from . import cleanup, lifecycle, scene_index, status_runtime, transactions, translation as tr
from .properties import get_settings


def _source_uuid(id_data, kind: str = 'OBJECT') -> str:
    return scene_index.persistent_uuid(id_data, kind, ensure=True) if id_data is not None else ''


def _owned_helpers(scene, source_obj, roles) -> tuple:
    source_uuid = _source_uuid(source_obj, 'OBJECT')
    index = scene_index.get_index(scene) or scene_index.rebuild_scene(scene, ensure_uuids=True)
    if index is None or not source_uuid:
        return ()
    result = []
    for role in tuple(roles):
        for obj in index.owned_helpers.get((source_uuid, str(role)), ()):
            if cleanup.is_owned(obj, role=str(role), source_uuid=source_uuid):
                result.append(obj)
    return tuple(result)


def _owned_constraints(owner, roles) -> tuple:
    result = []
    try:
        values = tuple(owner.constraints)
    except Exception:
        values = ()
    for constraint in values:
        for role in roles:
            if cleanup.is_owned_constraint(owner, constraint, str(role)):
                result.append(constraint)
                break
    return tuple(result)


def _remove_owned_mesh_object(obj) -> None:
    """Remove one exact-owned object with its data and its now unused owned materials."""
    materials = ()
    try:
        materials = tuple(getattr(getattr(obj, 'data', None), 'materials', ()) or ())
    except Exception:
        materials = ()
    cleanup.remove_object_and_orphan_data(obj)
    for material in materials:
        if not cleanup.is_owned(material):
            continue
        try:
            if int(getattr(material, 'users', 0) or 0) == 0:
                bpy.data.materials.remove(material)
        except Exception:
            pass


def _defer_remove_objects(transaction, objects) -> None:
    """Remove only exact-owned old helpers after replacement commit."""
    exact = tuple(objects or ())

    def remove_old():
        for obj in exact:
            if cleanup.is_owned(obj):
                _remove_owned_mesh_object(obj)

    transaction.defer_commit(remove_old)


def _defer_remove_constraints(transaction, owner, constraints) -> None:
    exact = tuple(constraints)
    def remove_old():
        for constraint in exact:
            cleanup.remove_owned_constraint(owner, constraint)
    transaction.defer_commit(remove_old)


def _settings(context=None, *, scene=None):
    if scene is not None:
        return getattr(scene, 'smart_camlight_suite', None)
    return get_settings(context)


def _camera_name_property():
    return StringProperty(
        name=tr.add('Camera Name', 'カメラ名'),
        description=tr.add('Exact scene camera object name used by this operation. Panel buttons fill this automatically; leave it empty to use the Smart CamLight active camera.', 'この操作が使用するシーン内カメラオブジェクトの正確な名前です。パネルのボタンからは自動設定され、空欄の場合はSmart CamLight のアクティブカメラを使用します。'),
        default='',
    )


def _light_name_property():
    return StringProperty(
        name=tr.add('Light Name', 'ライト名'),
        description=tr.add('Exact scene light object name used by this operation. Panel buttons fill this automatically; leave it empty to use the Smart CamLight active light.', 'この操作が使用するシーン内ライトオブジェクトの正確な名前です。パネルのボタンからは自動設定され、空欄の場合はSmart CamLight のアクティブライトを使用します。'),
        default='',
    )


def _linked_object_name_property():
    return StringProperty(
        name=tr.add('Linked Object Name', 'リンク済みオブジェクト名'),
        description=tr.add('Exact object name selected from a light-linking or shadow-linking collection.', 'ライトリンキングまたはシャドウリンキングコレクションから選択したオブジェクトの正確な名前です。'),
        default='',
    )


def _render_mode_property():
    return EnumProperty(
        name=tr.add('Render Mode', 'レンダーモード'),
        description=tr.add('Choose a final Blender render or a viewport OpenGL render.', 'Blenderの最終レンダーまたはビューポートOpenGLレンダーを選択します。'),
        items=[
            ('NORMAL', tr.add('Normal Render', '通常レンダー'), tr.add('Run Blender final rendering with the scene render engine.', 'シーンのレンダーエンジンでBlenderの最終レンダーを実行します。')),
            ('VIEWPORT', tr.add('Viewport Render', 'ビューポートレンダー'), tr.add('Run Blender OpenGL viewport rendering from the current 3D View context.', '現在の3DビューコンテキストからBlenderのOpenGLビューポートレンダーを実行します。')),
        ],
        default='NORMAL',
    )


def _animation_property():
    return BoolProperty(
        name=tr.add('Render Animation', 'アニメーションをレンダー'),
        description=tr.add('Render the configured frame range instead of one still frame. Disable it for a single image.', '1枚の静止画ではなく設定フレーム範囲をレンダーします。単一画像の場合は無効にします。'),
        default=False,
    )


def _link_kind_property(*, include_both: bool = False):
    items = [
        ('RECEIVER', tr.add('Light Linking', 'ライトリンキング'), tr.add('Use the receiver collection that controls which objects receive this light.', 'このライトを受けるオブジェクトを制御する受光コレクションを使用します。')),
        ('BLOCKER', tr.add('Shadow Linking', 'シャドウリンキング'), tr.add('Use the blocker collection that controls which objects cast shadows for this light.', 'このライトで影を落とすオブジェクトを制御する遮光コレクションを使用します。')),
    ]
    if include_both:
        items.append(('BOTH', tr.add('Both', '両方'), tr.add('Apply the operation to both receiver and blocker collections.', '受光コレクションと遮光コレクションの両方へ操作を適用します。')))
    return EnumProperty(
        name=tr.add('Linking Type', 'リンキング種別'),
        description=tr.add('Choose whether the operation targets light receivers or shadow blockers.', '操作対象をライト受光またはシャドウ遮光から選択します。'),
        items=items,
        default='BOTH' if include_both else 'RECEIVER',
    )


def _camera_objects(scene):
    return list(scene_index.camera_objects_for_operation(scene))


def _light_objects(scene):
    return list(scene_index.light_objects_for_operation(scene))


def _notify_scene_structure_changed(scene) -> None:
    try:
        from . import runtime
        runtime.notify_scene_structure_changed(scene)
    except Exception:
        try:
            scene_index.rebuild_scene(scene, ensure_uuids=True)
        except Exception:
            pass


def _get_camera(context, name: str = ''):
    scene = context.scene
    if name:
        obj = scene.objects.get(name)
        if obj and obj.type == 'CAMERA':
            return obj
    settings = _settings(context)
    if settings and settings.active_camera_name:
        obj = scene.objects.get(settings.active_camera_name)
        if obj and obj.type == 'CAMERA':
            return obj
    obj = getattr(context, 'active_object', None)
    if obj and obj.type == 'CAMERA':
        return obj
    return getattr(scene, 'camera', None)


def _get_light(context, name: str = ''):
    scene = context.scene
    if name:
        obj = scene.objects.get(name)
        if obj and obj.type == 'LIGHT':
            return obj
    settings = _settings(context)
    if settings and settings.active_light_name:
        obj = scene.objects.get(settings.active_light_name)
        if obj and obj.type == 'LIGHT':
            return obj
    obj = getattr(context, 'active_object', None)
    if obj and obj.type == 'LIGHT':
        return obj
    lights = _light_objects(scene)
    return lights[0] if lights else None


def _select_object(context, obj):
    if not obj:
        return
    view_layer = getattr(context, 'view_layer', None)
    try:
        for item in tuple(getattr(view_layer, 'objects', ()) or ()):
            try:
                item.select_set(False, view_layer=view_layer)
            except TypeError:
                item.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    try:
        obj.hide_set(False)
    except Exception:
        pass
    try:
        obj.hide_viewport = False
    except Exception:
        pass
    try:
        try:
            obj.select_set(True, view_layer=view_layer)
        except TypeError:
            obj.select_set(True)
        if view_layer is not None:
            view_layer.objects.active = obj
    except Exception:
        pass


def _report(op, level, message_en, message_ja=None, context=None):
    """Report in the active UI language without caching data-dependent text."""
    try:
        english = str(message_en)
        japanese = str(message_ja if message_ja is not None else message_en)
        op.report({level}, japanese if tr.is_japanese(context) else english)
    except Exception:
        pass


def _fps(scene) -> float:
    render = scene.render
    base = float(getattr(render, 'fps_base', 1.0) or 1.0)
    return float(getattr(render, 'fps', 24) or 24) / base


def _parse_shutter_speed(value: str) -> float:
    text = str(value or '').strip().lower().replace('sec', '').replace('s', '')
    if not text:
        return 1.0 / 48.0
    if '/' in text:
        a, b = text.split('/', 1)
        num = float(a.strip() or 1.0)
        den = float(b.strip() or 1.0)
        if den == 0:
            return 1.0 / 48.0
        return num / den
    return float(text)



def apply_motion_blur(scene, cam_obj, *, transaction=None) -> float:
    if not cam_obj or cam_obj.type != 'CAMERA':
        return 0.0
    cset = cam_obj.data.smart_camlight_settings
    if not cset.motion_blur_enable:
        return 0.0
    shutter = 0.5
    try:
        if cset.motion_blur_mode == 'SHUTTER_SPEED':
            shutter = max(0.0, _parse_shutter_speed(cset.shutter_speed) * _fps(scene))
        else:
            shutter = max(0.0, float(cset.shutter_angle) / 360.0)
    except Exception:
        shutter = 0.5
    render = getattr(scene, 'render', None)
    _set_if_exists(render, 'use_motion_blur', True, transaction=transaction)
    _set_if_exists(render, 'motion_blur_shutter', shutter, transaction=transaction)
    return shutter

def _timeline_ranges_for_camera(scene, cam_obj):
    markers = [m for m in scene.timeline_markers if getattr(m, 'camera', None) == cam_obj]
    markers.sort(key=lambda m: int(getattr(m, 'frame', 0)))
    ranges = []
    all_camera_markers = [m for m in scene.timeline_markers if getattr(m, 'camera', None) is not None]
    all_camera_markers.sort(key=lambda m: int(getattr(m, 'frame', 0)))
    for marker in markers:
        start = int(marker.frame)
        end = int(scene.frame_end)
        for other in all_camera_markers:
            if int(other.frame) > start:
                end = int(other.frame) - 1
                break
        ranges.append((start, max(start, end)))
    return ranges


def camera_from_marker_at_frame(scene, frame: int):
    chosen = None
    for marker in sorted(scene.timeline_markers, key=lambda m: int(getattr(m, 'frame', 0))):
        cam = getattr(marker, 'camera', None)
        if cam is not None and int(marker.frame) <= int(frame):
            chosen = cam
        elif int(marker.frame) > int(frame):
            break
    return chosen


def _build_output_filepath(cam_obj, cset) -> str:
    base = str(cset.output_path or '//')
    parts = []
    if cset.output_subfolder:
        parts.append(str(cset.output_subfolder))
    filename = str(cset.output_filename or 'camera_render')
    if cset.include_camera_name:
        safe_name = ''.join(ch if ch.isalnum() or ch in '._-' else '_' for ch in cam_obj.name)
        parts.append(safe_name)
    parts.append(filename)
    path = base
    for part in parts:
        if part:
            path = os.path.join(path, part)
    return path



def _set_if_exists(obj, attr: str, value, *, transaction=None) -> bool:
    try:
        if obj is None or not hasattr(obj, attr):
            return False
        if transaction is not None:
            return bool(transaction.set_attr(obj, attr, value))
        setattr(obj, attr, value)
        return True
    except Exception:
        return False


def _set_image_format(image, media_type: str, file_format: str, *, transaction=None) -> None:
    """Write the media type first, because it limits the legal file formats."""
    if transaction is not None:
        # Rollback runs backwards: media type, then file format, then depth.
        transaction.snapshot_attr(image, 'color_depth')
        transaction.snapshot_attr(image, 'file_format')
    _set_if_exists(image, 'media_type', media_type, transaction=transaction)
    _set_if_exists(image, 'file_format', file_format, transaction=transaction)


def apply_camera_settings(context, cam_obj, *, apply_overscan=False, scene=None, transaction=None) -> bool:
    if not cam_obj or cam_obj.type != 'CAMERA':
        return False
    scene = scene or getattr(context, 'scene', None)
    if scene is None:
        return False
    cset = cam_obj.data.smart_camlight_settings
    if not cset.enable_custom_settings:
        return False
    _set_if_exists(scene, 'camera', cam_obj, transaction=transaction)
    render = scene.render
    _set_if_exists(render, 'resolution_x', int(cset.resolution_x), transaction=transaction)
    _set_if_exists(render, 'resolution_y', int(cset.resolution_y), transaction=transaction)
    _set_if_exists(render, 'resolution_percentage', int(cset.resolution_percentage), transaction=transaction)
    _set_if_exists(render, 'pixel_aspect_x', float(cset.pixel_aspect_x), transaction=transaction)
    _set_if_exists(render, 'pixel_aspect_y', float(cset.pixel_aspect_y), transaction=transaction)
    if cset.frame_range_mode == 'TIMELINE_MARKERS':
        ranges = _timeline_ranges_for_camera(scene, cam_obj)
        if ranges:
            _set_if_exists(scene, 'frame_start', ranges[0][0], transaction=transaction)
            _set_if_exists(scene, 'frame_end', ranges[-1][1], transaction=transaction)
            _set_if_exists(scene, 'frame_step', int(cset.frame_step), transaction=transaction)
    elif cset.sync_frame_range:
        _set_if_exists(scene, 'frame_start', int(cset.frame_start), transaction=transaction)
        _set_if_exists(scene, 'frame_end', int(cset.frame_end), transaction=transaction)
        _set_if_exists(scene, 'frame_step', int(cset.frame_step), transaction=transaction)
    _set_if_exists(render, 'filepath', _build_output_filepath(cam_obj, cset), transaction=transaction)
    _set_if_exists(render, 'use_file_extension', True, transaction=transaction)
    _set_if_exists(render, 'use_overwrite', bool(cset.overwrite_existing), transaction=transaction)
    _set_if_exists(render, 'film_transparent', bool(cset.film_transparent), transaction=transaction)
    image = render.image_settings
    fmt = cset.output_format
    if fmt in {'PNG', 'JPEG', 'OPEN_EXR'}:
        _set_image_format(image, 'IMAGE', fmt, transaction=transaction)
        if fmt == 'PNG':
            _set_if_exists(image, 'color_depth', cset.png_color_depth, transaction=transaction)
            _set_if_exists(image, 'compression', int(cset.png_compression), transaction=transaction)
        elif fmt == 'JPEG':
            _set_if_exists(image, 'quality', int(cset.jpeg_quality), transaction=transaction)
        elif fmt == 'OPEN_EXR':
            _set_if_exists(image, 'color_depth', cset.exr_color_depth, transaction=transaction)
            _set_if_exists(image, 'exr_codec', cset.exr_codec, transaction=transaction)
            _set_if_exists(image, 'use_preview', bool(cset.exr_preview), transaction=transaction)
    else:
        _set_image_format(image, 'VIDEO', 'FFMPEG', transaction=transaction)
        ff = render.ffmpeg
        if fmt == 'H264_MP4':
            _set_if_exists(ff, 'format', 'MPEG4', transaction=transaction)
            _set_if_exists(ff, 'codec', 'H264', transaction=transaction)
        elif fmt == 'H264_MKV':
            _set_if_exists(ff, 'format', 'MKV', transaction=transaction)
            _set_if_exists(ff, 'codec', 'H264', transaction=transaction)
        elif fmt == 'PRORES_MOV':
            _set_if_exists(ff, 'format', 'QUICKTIME', transaction=transaction)
            _set_if_exists(ff, 'codec', 'PRORES', transaction=transaction)
        _set_if_exists(ff, 'constant_rate_factor', cset.video_quality, transaction=transaction)
        _set_if_exists(ff, 'video_bitrate', int(cset.video_bitrate), transaction=transaction)
        _set_if_exists(ff, 'gopsize', int(cset.video_gopsize), transaction=transaction)
        if cset.use_audio and cset.audio_codec != 'NONE':
            _set_if_exists(ff, 'audio_codec', cset.audio_codec, transaction=transaction)
            _set_if_exists(ff, 'audio_bitrate', int(cset.audio_bitrate), transaction=transaction)
        else:
            _set_if_exists(ff, 'audio_codec', 'NONE', transaction=transaction)
    _set_if_exists(render, 'use_stamp', bool(cset.burn_metadata or cset.review_use_stamp), transaction=transaction)
    _set_if_exists(render, 'use_stamp_camera', bool(cset.review_stamp_camera), transaction=transaction)
    _set_if_exists(render, 'use_stamp_frame', bool(cset.review_stamp_frame), transaction=transaction)
    _set_if_exists(render, 'use_stamp_scene', bool(cset.review_stamp_scene), transaction=transaction)
    if cset.motion_blur_enable:
        apply_motion_blur(scene, cam_obj, transaction=transaction)
    if apply_overscan and cset.overscan_enable:
        apply_overscan_settings(context, cam_obj, scene=scene, transaction=transaction)
    else:
        _write_overscan_view(cam_obj.data, 1.0, transaction=transaction)
        _reset_other_overscan_views(scene, cam_obj.data, transaction=transaction)
    return True


def _render_camera_operation(context, cam_obj, *, mode: str, animation: bool, transaction=None) -> set[str]:
    """Delegate one external render and leave restoration to its transaction."""
    scene = context.scene
    render = scene.render
    # A movie format cannot be written as a single still.
    animation = bool(animation) or render.image_settings.media_type == 'VIDEO'
    if mode == 'VIEWPORT' and animation and cam_obj is not None:
        try:
            cset = cam_obj.data.smart_camlight_settings
            _set_if_exists(render, 'resolution_percentage', int(cset.review_resolution_percentage), transaction=transaction)
        except Exception:
            pass
    if mode == 'VIEWPORT':
        result = bpy.ops.render.opengl(animation=bool(animation), write_still=not bool(animation), view_context=True)
    else:
        result = bpy.ops.render.render(animation=bool(animation), write_still=not bool(animation))
    return set(result or {'FINISHED'})


def _overscan_fit_size(camera, render, width: int, height: int) -> float:
    """Pixel length of the image side that the camera sensor spans."""
    if camera.sensor_fit == 'HORIZONTAL':
        return float(width)
    if camera.sensor_fit == 'VERTICAL':
        return float(height)
    return max(width * float(render.pixel_aspect_x), height * float(render.pixel_aspect_y))


def _write_overscan_view(camera, factor: float, *, transaction=None) -> None:
    """Widen the camera view by factor, relative to its view without overscan."""
    cset = camera.smart_camlight_settings
    previous = float(cset.overscan_view_factor) or 1.0
    if math.isclose(previous, factor, rel_tol=1.0e-9):
        return
    ratio = previous / factor
    if camera.type == 'ORTHO':
        _set_if_exists(camera, 'ortho_scale', float(camera.ortho_scale) / ratio, transaction=transaction)
    else:
        _set_if_exists(camera, 'lens', float(camera.lens) * ratio, transaction=transaction)
    _set_if_exists(camera, 'shift_x', float(camera.shift_x) * ratio, transaction=transaction)
    _set_if_exists(camera, 'shift_y', float(camera.shift_y) * ratio, transaction=transaction)
    _set_if_exists(cset, 'overscan_view_factor', factor, transaction=transaction)


def _reset_other_overscan_views(scene, camera, *, transaction=None) -> None:
    # The scene resolution fits one camera, so only that camera may stay widened.
    for other in _camera_objects(scene):
        if other.data != camera:
            _write_overscan_view(other.data, 1.0, transaction=transaction)


def _overscan_base_resolution(settings, cset, render, *, transaction=None) -> tuple[int, int]:
    """Resolution of the picture to keep; remembers it for Revert outside render transactions."""
    if settings and transaction is None:
        # Anything but the size written last means someone changed the resolution since.
        current = (int(render.resolution_x), int(render.resolution_y))
        if not settings.overscan_original_x or current != (settings.overscan_applied_x, settings.overscan_applied_y):
            settings.overscan_original_x, settings.overscan_original_y = current
            settings.overscan_original_percentage = int(render.resolution_percentage)
    if cset.enable_custom_settings:
        return int(cset.resolution_x or render.resolution_x), int(cset.resolution_y or render.resolution_y)
    if settings and settings.overscan_original_x and settings.overscan_original_y:
        return int(settings.overscan_original_x), int(settings.overscan_original_y)
    return int(render.resolution_x), int(render.resolution_y)


def apply_overscan_settings(context, cam_obj, *, scene=None, transaction=None) -> bool:
    if not cam_obj or cam_obj.type != 'CAMERA':
        return False
    scene = scene or getattr(context, 'scene', None)
    if scene is None:
        return False
    settings = _settings(context, scene=scene)
    cset = cam_obj.data.smart_camlight_settings
    render = scene.render
    base_x, base_y = _overscan_base_resolution(settings, cset, render, transaction=transaction)
    if cset.overscan_mode == 'PERCENT':
        factor = 1.0 + float(cset.overscan_percentage) / 100.0
        value_x = max(1, round(base_x * factor))
        value_y = max(1, round(base_y * factor))
    elif cset.overscan_mode == 'PIXELS':
        extra = int(cset.overscan_extra_pixels)
        value_x = max(1, base_x + extra * 2)
        value_y = max(1, base_y + extra * 2)
    else:
        value_x = max(1, int(cset.overscan_specific_x))
        value_y = max(1, int(cset.overscan_specific_y))
    _set_if_exists(render, 'resolution_x', value_x, transaction=transaction)
    _set_if_exists(render, 'resolution_y', value_y, transaction=transaction)
    # Same size per pixel: the old picture stays put and the new pixels show more.
    if cam_obj.data.type != 'PANO':
        factor = _overscan_fit_size(cam_obj.data, render, value_x, value_y) / _overscan_fit_size(cam_obj.data, render, base_x, base_y)
        _write_overscan_view(cam_obj.data, factor, transaction=transaction)
    if settings and transaction is None:
        settings.overscan_applied_x, settings.overscan_applied_y = value_x, value_y
    _reset_other_overscan_views(scene, cam_obj.data, transaction=transaction)
    return True

def revert_overscan_settings(context) -> bool:
    settings = _settings(context)
    if not settings:
        return False
    render = context.scene.render
    for cam in _camera_objects(context.scene):
        _write_overscan_view(cam.data, 1.0)
    if settings.overscan_original_x and settings.overscan_original_y:
        render.resolution_x = int(settings.overscan_original_x)
        render.resolution_y = int(settings.overscan_original_y)
        if settings.overscan_original_percentage:
            render.resolution_percentage = int(settings.overscan_original_percentage)
        settings.overscan_original_x = 0
        settings.overscan_original_y = 0
        settings.overscan_original_percentage = 0
        settings.overscan_applied_x = 0
        settings.overscan_applied_y = 0
        return True
    return False


def _aim_at(obj, target_location):
    direction = Vector(target_location) - obj.location
    if direction.length < 1.0e-6:
        return
    try:
        obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    except Exception:
        pass


def _world_location(obj):
    if obj is None:
        return Vector((0.0, 0.0, 0.0))
    try:
        return obj.matrix_world.translation.copy()
    except Exception:
        try:
            return obj.location.copy()
        except Exception:
            return Vector((0.0, 0.0, 0.0))


def _target_location(context=None, *, scene=None):
    settings = _settings(context, scene=scene)
    if settings and settings.use_target_object and settings.target_object:
        return _world_location(settings.target_object)
    obj = getattr(context, 'active_object', None) if context is not None else None
    if obj and obj.type not in {'LIGHT', 'CAMERA'}:
        return _world_location(obj)
    return Vector((0.0, 0.0, 0.0))


def _apply_light_shape(data, settings):
    if getattr(data, 'type', None) == 'AREA':
        _set_if_exists(data, 'shape', settings.area_shape)
        if settings.area_shape in {'RECTANGLE', 'ELLIPSE'}:
            _set_if_exists(data, 'size', float(settings.area_size_x))
            _set_if_exists(data, 'size_y', float(settings.area_size_y))
        else:
            _set_if_exists(data, 'size', float(settings.light_size))
    elif getattr(data, 'type', None) in {'POINT', 'SPOT'}:
        _set_if_exists(data, 'shadow_soft_size', float(settings.light_size))
    if getattr(data, 'type', None) == 'SPOT':
        _set_if_exists(data, 'spot_size', float(settings.spot_size))
        _set_if_exists(data, 'spot_blend', float(settings.spot_blend))


def _apply_explicit_light_size(data, size: float) -> None:
    """Apply a preset-specific size without mutating persistent generator settings."""
    value = max(0.001, float(size))
    if getattr(data, 'type', None) == 'AREA':
        _set_if_exists(data, 'size', value)
        if getattr(data, 'shape', '') in {'RECTANGLE', 'ELLIPSE'}:
            _set_if_exists(data, 'size_y', value)
    elif getattr(data, 'type', None) in {'POINT', 'SPOT'}:
        _set_if_exists(data, 'shadow_soft_size', value)



def _create_light(
    context,
    name: str,
    light_type: str,
    location,
    energy: float,
    *,
    scene=None,
    transaction=None,
    role: str = 'generated_light',
):
    scene = scene or getattr(context, 'scene', None)
    if scene is None:
        return None
    settings = _settings(context, scene=scene)
    own_transaction = transaction is None
    tx = transaction or transactions.DataTransaction('Create Smart CamLight Light')
    try:
        data = bpy.data.lights.new(name=name, type=light_type)
        tx.track_datablock(bpy.data.lights, data)
        data.energy = float(energy)
        if settings:
            _apply_light_shape(data, settings)
        obj = bpy.data.objects.new(name, data)
        tx.track_object(obj)
        source_uuid = scene_index.persistent_uuid(scene, 'SCENE', ensure=True)
        cleanup.mark_owned(data, f'{role}_data', name, 'SCENE', source_uuid=source_uuid)
        cleanup.mark_object(obj, role, name, 'SCENE', source_uuid=source_uuid)
        scene.collection.objects.link(obj)
        tx.track_collection_link(scene.collection, obj)
        obj.location = Vector(location)
        obj.smart_camlight_object.is_generated_light = True
        target = _target_location(context, scene=scene)
        _aim_at(obj, target)
        if own_transaction:
            tx.commit()
            _notify_scene_structure_changed(scene)
        return obj
    except Exception:
        if own_transaction:
            tx.rollback()
            return None
        raise


def _make_track_to(obj, target, *, camera=False, transaction=None, role='', source_uuid=''):
    try:
        con = obj.constraints.new(type='TRACK_TO')
        if transaction is not None:
            transaction.track_constraint(obj, con)
        con.name = 'SCLS Track Target'
        con.target = target
        con.track_axis = 'TRACK_NEGATIVE_Z'
        con.up_axis = 'UP_Y'
        cleanup.mark_owned_constraint(
            obj,
            con,
            role or ('camera_rig_constraint' if camera else 'light_target_constraint'),
            transaction=transaction,
        )
        return con
    except Exception:
        return None


def _ensure_link_collection(context, light_obj, kind: str, *, transaction=None):
    if not light_obj or light_obj.type != 'LIGHT' or not hasattr(light_obj, 'light_linking'):
        return None
    ll = light_obj.light_linking
    attr = 'receiver_collection' if kind == 'RECEIVER' else 'blocker_collection'
    prefix = 'SCLS Light Linking' if kind == 'RECEIVER' else 'SCLS Shadow Linking'
    coll = getattr(ll, attr, None)
    if coll is not None:
        return coll
    own_transaction = transaction is None
    tx = transaction or transactions.DataTransaction('Create Smart CamLight Linking Collection')
    try:
        coll = bpy.data.collections.new(f'{prefix} - {light_obj.name}')
        tx.track_datablock(bpy.data.collections, coll)
        source_uuid = scene_index.persistent_uuid(light_obj, 'OBJECT', ensure=True)
        cleanup.mark_owned(coll, 'link_collection', light_obj.name, 'LIGHT', source_uuid=source_uuid)
        context.scene.collection.children.link(coll)

        def unlink_collection():
            try:
                context.scene.collection.children.unlink(coll)
            except Exception:
                pass

        tx.add_rollback(unlink_collection)
        if not tx.set_attr(ll, attr, coll):
            raise RuntimeError('light linking collection assignment failed')
        if own_transaction:
            tx.commit()
        return coll
    except Exception:
        if own_transaction:
            tx.rollback()
            return None
        raise

def _collection_object_link_state(coll, obj):
    # CollectionObject has no reference to its object; both lists share one order.
    try:
        for member, item in zip(coll.objects, coll.collection_objects):
            if member == obj:
                return item
    except Exception:
        pass
    return None


def _add_obj_to_link_collection(context, light_obj, obj, kind: str, state: str = 'INCLUDE') -> bool:
    coll = _ensure_link_collection(context, light_obj, kind)
    if coll is None or obj is None or obj == light_obj:
        return False
    linked = False
    try:
        linked = obj.name in coll.objects
    except Exception:
        try:
            linked = obj in tuple(coll.objects)
        except Exception:
            linked = False
    if not linked:
        try:
            coll.objects.link(obj)
            linked = True
        except Exception:
            return False
    item = _collection_object_link_state(coll, obj)
    link = getattr(item, 'light_linking', None)
    if link is not None:
        _set_if_exists(link, 'link_state', state)
    return linked


def _remove_obj_from_link_collection(light_obj, obj_name: str, kind: str) -> bool:
    if not light_obj or light_obj.type != 'LIGHT' or not hasattr(light_obj, 'light_linking'):
        return False
    ll = light_obj.light_linking
    coll = getattr(ll, 'receiver_collection' if kind == 'RECEIVER' else 'blocker_collection', None)
    if not coll:
        return False
    obj = bpy.data.objects.get(obj_name)
    if not obj:
        return False
    try:
        coll.objects.unlink(obj)
        return True
    except Exception:
        return False


def _set_link_state(light_obj, obj_name: str, kind: str, state: str) -> bool:
    if not light_obj or light_obj.type != 'LIGHT' or not hasattr(light_obj, 'light_linking'):
        return False
    ll = light_obj.light_linking
    coll = getattr(ll, 'receiver_collection' if kind == 'RECEIVER' else 'blocker_collection', None)
    obj = bpy.data.objects.get(obj_name)
    if not coll or not obj:
        return False
    item = _collection_object_link_state(coll, obj)
    link = getattr(item, 'light_linking', None)
    return _set_if_exists(link, 'link_state', state)


_HELP_TOPICS = {
    'overview': (
        (
            'Smart CamLight Suite places the same complete camera and lighting workflow in fixed Suite-owned sidebar roots for all 17 supported logical editors. Open the Camera or Light top-level section, select a scene object from its list, then expand only the child section needed for the current task.',
            'Smart CamLight Suite は、対応する17論理エディターのSuite所有固定サイドバールートへ、同一の完全なカメラ・照明ワークフローを表示します。最上層の「カメラ」または「ライト」を開き、シーン内オブジェクトをリストから選択して、現在の作業に必要な子セクションだけを展開します。',
        ),
        (
            'Question-mark buttons open this popup. Press Esc or click outside the popup to close it; opening help does not create or modify Blender datablocks and does not add an undo step.',
            '「?」ボタンでこのポップアップを開きます。Escキーまたはポップアップ外のクリックで閉じられます。ヘルプを開いてもBlenderデータブロックは作成・変更されず、Undo履歴も増えません。',
        ),
    ),
    'always_on': (
        (
            'N-panel State Save controls JSON persistence. When enabled, portable panel settings are written atomically after each change. When disabled, the latest validated snapshot is held in memory and committed at a .blend save/load boundary, add-on disable, Blender exit, or when immediate saving is enabled again.',
            '「Nパネル状態保存」はJSON永続化を制御します。有効時は移植可能なパネル設定を変更ごとに原子的保存し、無効時は最新の検証済みスナップショットを保持して、.blendの保存・読込境界、アドオン無効化、Blender終了、または即時保存を再び有効にした時に確定保存します。',
        ),
        (
            'All other switches are optional event-driven services. Camera selection uses active-object message-bus events, marker and per-camera synchronization use frame-change events, and linking/sky monitoring reacts only to relevant data events. With all switches disabled, no camera/light frame or depsgraph handler and no recurring timer remains active.',
            'その他の切り替えは任意のイベント駆動サービスです。カメラ選択はアクティブオブジェクトのメッセージバスイベント、マーカーとカメラ別同期はフレーム変更イベント、リンキングとスカイ監視は関連データイベント時だけ動作します。全て無効の場合、カメラ/ライト用のフレーム・depsgraphハンドラーや定期タイマーは残りません。',
        ),
    ),
    'camera': (
        (
            'Use Scene Cameras to add, select, activate, apply, or delete cameras. Enable the checkbox beside a camera before using its custom render, output, frame-range, review, overscan, or motion-blur settings.',
            '「シーン内カメラ」でカメラの追加、選択、アクティブ化、設定適用、削除を行います。カスタムのレンダー、出力、フレーム範囲、レビュー、オーバースキャン、モーションブラー設定を使う前に、カメラ横のチェックを有効にします。',
        ),
        (
            'Apply copies the selected camera profile into scene render settings. Render and Viewport apply the profile first and then delegate to Blender rendering. Batch commands process custom cameras in list order and leave the last processed camera active.',
            '「適用」は選択カメラのプロファイルをシーンのレンダー設定へ反映します。「レンダー」と「ビューポート」は先にプロファイルを適用してからBlenderのレンダー処理へ移ります。バッチ操作はカスタムカメラをリスト順に処理し、最後のカメラをアクティブに残します。',
        ),
    ),
    'camera_data': (
        (
            'Edit the selected camera object transform, lens, sensor, shift, clipping, display size, and Blender depth-of-field properties. Set DOF to Selected Object assigns the current non-camera active object as the focus object.',
            '選択カメラのオブジェクトトランスフォーム、レンズ、センサー、シフト、クリッピング、表示サイズ、Blender被写界深度プロパティを編集します。「DOFを選択オブジェクトに設定」は現在の非カメラアクティブオブジェクトをフォーカス対象へ割り当てます。',
        ),
    ),
    'resolution': (
        (
            'Width, Height, Scale, and Pixel Aspect are stored per camera. Swap exchanges width and height. Aspect preset buttons write common dimensions into the camera profile only; use Apply to copy them to the scene render settings.',
            '幅、高さ、スケール、ピクセル比率はカメラ別に保存されます。「入れ替え」は幅と高さを交換します。縦横比プリセットはカメラプロファイルだけを書き換えるため、シーンのレンダー設定へ反映するには「適用」を実行します。',
        ),
    ),
    'frame_range': (
        (
            'Per-Camera Range uses Start, End, and Step from this camera. Timeline Markers derives ranges from markers bound to cameras; Add Marker creates one at the current frame and binds it to the selected camera.',
            '「カメラ別範囲」はこのカメラの開始、終了、ステップを使用します。「タイムラインマーカー」はカメラへバインドされたマーカーから範囲を決定し、「マーカーを追加」は現在フレームに作成して選択カメラへバインドします。',
        ),
    ),
    'file_output': (
        (
            'Set the base output path, optional subfolder, file name, camera-name suffix, and overwrite policy stored on this camera. Blender // relative paths remain relative to the current .blend file.',
            'このカメラに保存する基本出力パス、任意サブフォルダー、ファイル名、カメラ名付加、上書き方針を設定します。Blenderの「//」相対パスは現在の.blendファイル基準のままです。',
        ),
    ),
    'file_format': (
        (
            'Choose PNG, JPEG, OpenEXR, H.264 MP4/MKV, or ProRes MOV and then configure only the options relevant to that format. Apply transfers supported values to Blender Image Settings or FFmpeg settings and switches the media type to match; unsupported build-specific fields are skipped safely. With a movie format, Render writes the whole frame range as one movie.',
            'PNG、JPEG、OpenEXR、H.264 MP4/MKV、ProRes MOVから選び、その形式に必要な項目だけを設定します。「適用」は対応値をBlenderの画像設定またはFFmpeg設定へ反映し、メディアタイプも形式に合わせて切り替えます。ビルド固有の未対応項目は安全にスキップします。動画の形式では、「レンダー」はフレーム範囲全体を1本の動画に書き出します。',
        ),
    ),
    'guides': (
        (
            'Create builds curve-based thirds, center, and safe-area guides parented to the camera. Recreate after changing guide settings. Remove deletes only Smart CamLight guide helpers owned by this camera.',
            '「作成」はカメラに親子付けしたカーブ式の三分割、中央、セーフエリアガイドを構築します。ガイド設定を変更した後は再作成してください。「削除」はこのカメラが所有するSmart CamLight ガイド補助だけを削除します。',
        ),
    ),
    'rig': (
        (
            'Create Camera Rig replaces this camera existing Smart CamLight target/dolly helpers, creates a Track To target, and optionally assigns it to depth of field. Target Size updates existing owned targets for this camera.',
            '「カメラリグを作成」は、このカメラの既存Smart CamLight ターゲット/ドリー補助を置き換え、Track Toターゲットを作成し、必要に応じて被写界深度へ割り当てます。「ターゲットサイズ」はこのカメラの既存所有ターゲットにも反映されます。',
        ),
        (
            'Insert Camera Key records location, rotation, lens, and focus distance. Fly View delegates navigation and Esc cancellation to Blender walk. Bake samples world transforms over the configured range and writes camera keys in one Smart CamLight operation.',
            '「カメラキーを挿入」は位置、回転、レンズ、フォーカス距離を記録します。「カメラフライビュー」はナビゲーションとEscキャンセルをBlender標準のウォーク操作へ委譲します。「ベイク」は設定範囲のワールドトランスフォームをサンプリングし、1回のSmart CamLight 操作でカメラキーを書き込みます。',
        ),
    ),
    'review': (
        (
            'Configure camera, frame, and scene stamps for review output. Prepare applies stamp settings without rendering. Viewport starts an OpenGL animation render after applying the selected camera profile.',
            'レビュー出力へカメラ名、フレーム、シーン名のスタンプを設定します。「準備」はレンダーせずスタンプ設定だけを適用し、「ビューポート」は選択カメラプロファイルを適用してOpenGLアニメーションレンダーを開始します。',
        ),
    ),
    'overscan': (
        (
            'Choose percentage, extra pixels, or an exact resolution. Apply stores the current scene resolution, enlarges the camera Width and Height (the scene resolution when the custom settings of the camera are off), and widens the camera lens so the original picture stays the same and the added pixels show more around it. Revert restores the stored width, height, scale, and lens. With Enable Overscan on, every panel button that applies or renders this camera uses overscan too, including Live Per-Camera Sync. Only one camera stays widened: applying another camera restores the previous one.',
            '比率、追加ピクセル、指定解像度から選びます。「適用」は現在のシーン解像度を保存し、カメラの幅・高さ（カメラ別設定が無効のカメラはシーンの解像度）を元に広げた大きさへ変更して、カメラのレンズを広げます。元の絵はそのままで、増えた分だけ周りが写ります。「戻す」は保存済みの幅、高さ、倍率とレンズを復元します。「オーバースキャンを有効化」を入れると、このカメラを適用・レンダーするパネルのボタンと「カメラ別設定の常時同期」でもオーバースキャンを使います。広げたままにできるカメラは1台だけで、別のカメラを適用すると前のカメラは元に戻ります。',
        ),
    ),
    'motion_blur': (
        (
            'Shutter Speed converts values such as 1/48 using the scene frame rate. Shutter Angle converts degrees so 180 degrees equals half-frame exposure. Refresh writes the converted value to Blender motion-blur settings.',
            '「シャッタースピード」は1/48などの値をシーンのフレームレートで変換します。「シャッター角」は角度を変換し、180度は半フレーム露光です。「更新」で変換値をBlenderのモーションブラー設定へ書き込みます。',
        ),
    ),
    'pov': (
        (
            'Create POV Camera Text writes a Blender Text datablock containing location, look-at, angle, optional aperture, and the note stored on this camera. Re-running replaces only the text owned by the same camera.',
            '「POVカメラテキストを作成」は、位置、注視点、画角、任意の絞り、このカメラのメモを含むBlender Textデータブロックを書き込みます。再実行時は同じカメラが所有するテキストだけを更新します。',
        ),
    ),
    'light': (
        (
            'Use Scene Lights to add, select, show/hide, lock, or delete lights. Generated-only filtering identifies lights created by Smart CamLight without hiding manually created lights from the scene itself.',
            '「シーン内ライト」でライトの追加、選択、表示/非表示、ロック、削除を行います。「生成ライトのみ表示」はSmart CamLight 生成ライトを識別してリストを絞り込み、手作業のライト自体はシーンから隠しません。',
        ),
    ),
    'light_data': (
        (
            'Edit transform, type, energy, color, area/spot shape, shadow, target size, and Cycles maximum bounces. Lock disables editing controls; target creates an Empty and Track To constraint; mirror duplicates the light across X or Y.',
            'トランスフォーム、タイプ、エネルギー、カラー、エリア/スポット形状、シャドウ、ターゲットサイズ、Cycles最大バウンスを編集します。ロックは編集操作を無効化し、ターゲットはEmptyとTrack Toを作成し、ミラーはXまたはY方向へライトを複製します。',
        ),
    ),
    'linking': (
        (
            'Initialize creates Blender receiver and blocker collections for the selected light. Add Selected links selected non-light objects. The check mark includes the object and the empty check mark excludes it, and the pressed one shows the current state; X unlinks the object without deleting it.',
            '「初期化」は選択ライト用のBlender受光・遮光コレクションを作成します。「選択を追加」は選択中の非ライトオブジェクトをリンクします。チェックの印は含める、空のチェックの印は除外で、押された方が今の状態です。「X」はオブジェクトを削除せずリンクだけを外します。',
        ),
        (
            'Select an object in Light Linking or Shadow Linking to edit its visibility and viewport display in the linked-object display box. The optional monitor only clears a selected name after that object is deleted and performs no recurring collection scan.',
            'ライトリンキングまたはシャドウリンキングでオブジェクトを選ぶと、リンク済みオブジェクト表示で可視性とビューポート表示を編集できます。任意の監視機能は選択オブジェクトが削除された時だけ名前を解除し、定期的なコレクション走査は行いません。',
        ),
    ),
    'generator': (
        (
            'Studio Preset creates predefined key/fill/rim layouts. Softbox creates an emission mesh plus area light. Set Selected Emission Strength opens an Esc-cancellable popup and changes Principled BSDF emission only after confirmation. The procedural generator uses count, type, distribution, distance, random seed, power range, shape, and optional target object.',
            '「スタジオプリセット」は既定のキー/フィル/リム配置を作成し、「ソフトボックス」は発光メッシュとエリアライトを作成します。「選択発光強度を設定」はEscでキャンセルできるポップアップを開き、確定後にだけPrincipled BSDFの発光を変更します。プロシージャル生成は数、タイプ、分布、距離、ランダムシード、パワー範囲、形状、任意ターゲットオブジェクトを使用します。',
        ),
        (
            'Clear deletes only lights marked as Smart CamLight generated lights and softbox planes. Manually created lights are retained.',
            '「クリア」はSmart CamLight 生成ライトとしてマークされたライトとソフトボックスの板だけを削除し、手作業で作成したライトは保持します。',
        ),
    ),
    'dynamic_sky': (
        (
            'Create or refresh builds a named Sky Texture, Background, and World Output chain and optionally a companion sun. Remove deletes Smart CamLight sky nodes and its companion sun from the current workflow.',
            '「作成/更新」は名前付きSky Texture、Background、World Outputの接続と、任意の連動サンを構築します。「削除」は現在のワークフローからSmart CamLight スカイノードと連動サンを削除します。',
        ),
        (
            'When Dynamic Sky Monitor is enabled, changes are synchronized only after a sky property, Scene.world, world-node, or companion-sun event. The continuation timer is one-shot and returns None, so no idle polling remains.',
            '「ダイナミックスカイ監視」が有効な場合、スカイプロパティ、Scene.world、ワールドノード、連動サンのイベント後だけ同期します。継続タイマーは1回でNoneを返すため、アイドルポーリングは残りません。',
        ),
    ),
}


def _draw_help_popup(layout, context, topic: str) -> None:
    paragraphs = _HELP_TOPICS.get(str(topic or ''), _HELP_TOPICS['overview'])
    for index, (english, japanese) in enumerate(paragraphs):
        text = tr.t(english, japanese, context)
        for line in textwrap.wrap(text, width=62, break_long_words=False, break_on_hyphens=False) or ['']:
            layout.label(text=line)
        if index + 1 < len(paragraphs):
            layout.separator(factor=0.6)


class SCLS_OT_toggle_ui_section(Operator):
    bl_idname = 'smart_camlight_suite.toggle_ui_section'
    bl_label = tr.add('Toggle Smart CamLight Section', 'Smart CamLight セクションを切り替え')
    bl_description = tr.add('Expand or collapse one Smart CamLight N-panel section. Use this to keep camera and light controls compact while preserving one-panel operation.', 'Smart CamLight Nパネル内の1つのセクションを展開または折りたたみます。1パネル構成を保ちながらカメラとライト操作をコンパクトにできます。')
    bl_options = {'INTERNAL'}

    section_key: StringProperty(
        name=tr.add('Section Key', 'セクションキー'),
        description=tr.add('Internal RNA property identifier for the top-level section being expanded or collapsed.', '展開または折りたたむ最上層セクションの内部RNAプロパティ識別子です。'),
        default='',
    )

    def execute(self, context):
        settings = _settings(context)
        if not settings or not self.section_key or not hasattr(settings, self.section_key):
            return {'CANCELLED'}
        setattr(settings, self.section_key, not bool(getattr(settings, self.section_key)))
        return {'FINISHED'}


class SCLS_OT_open_help(Operator):
    bl_idname = 'smart_camlight_suite.open_help'
    bl_label = tr.add('Open Smart CamLight Help', 'Smart CamLight ヘルプを開く')
    bl_description = tr.add('Open detailed help for the selected Smart CamLight section in an Esc-closeable popup without modifying Blender data.', '選択したSmart CamLight セクションの詳細ヘルプを、Blenderデータを変更しないEsc対応ポップアップで開きます。')
    bl_options = set()

    topic: StringProperty(
        name=tr.add('Help Topic', 'ヘルプ項目'),
        description=tr.add('Internal topic identifier supplied by the question-mark button beside a section header.', 'セクションヘッダー横の「?」ボタンから渡される内部ヘルプ項目識別子です。'),
        default='overview',
    )

    def execute(self, context):
        window_manager = getattr(context, 'window_manager', None)
        if window_manager is None:
            return {'CANCELLED'}
        topic = str(self.topic or 'overview')

        def draw(menu, popup_context):
            _draw_help_popup(menu.layout, popup_context, topic)

        window_manager.popup_menu(
            draw,
            title=tr.t('Smart CamLight Suite Help', 'Smart CamLight Suite ヘルプ', context),
            icon='QUESTION',
        )
        return {'FINISHED'}


class SCLS_OT_select_camera(Operator):
    bl_idname = 'smart_camlight_suite.select_camera'
    bl_label = tr.add('Select Camera', 'カメラを選択')
    bl_description = tr.add('Select the camera, make it the Smart CamLight active camera, and optionally make it the scene render camera. Hidden cameras are unhidden before selection.', 'カメラを選択し、Smart CamLight のアクティブカメラに設定します。必要に応じてシーンのレンダーカメラにも設定し、非表示カメラは選択前に表示します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()
    make_scene_camera: BoolProperty(
        name=tr.add('Make Scene Camera', 'シーンカメラに設定'),
        description=tr.add('Also assign the selected camera to Scene.camera for rendering and camera view.', '選択カメラをレンダーとカメラビュー用のScene.cameraにも割り当てます。'),
        default=True,
    )
    apply_settings: BoolProperty(
        name=tr.add('Apply Custom Settings', 'カスタム設定を適用'),
        description=tr.add('After selection, copy this camera enabled custom profile to the scene render settings.', '選択後、このカメラで有効なカスタムプロファイルをシーンのレンダー設定へ反映します。'),
        default=False,
    )

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        settings = _settings(context)
        if settings:
            settings.active_camera_name = cam.name
        if self.make_scene_camera:
            context.scene.camera = cam
        _select_object(context, cam)
        if self.apply_settings:
            apply_camera_settings(context, cam, apply_overscan=True)
        return {'FINISHED'}



class SCLS_OT_add_camera(Operator):
    bl_idname = 'smart_camlight_suite.add_camera'
    bl_label = tr.add('Add Smart Camera', 'Smart カメラを追加')
    bl_description = tr.add('Create a new camera, enable Smart CamLight custom settings, select it, and set it as the active scene camera.', '新規カメラを作成し、Smart CamLight カスタム設定を有効化して選択し、シーンのアクティブカメラに設定します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        tx = transactions.DataTransaction('Add Smart Camera')
        try:
            data = bpy.data.cameras.new('SCLS_Camera_Data')
            tx.track_datablock(bpy.data.cameras, data)
            cam = bpy.data.objects.new('SCLS_Camera', data)
            tx.track_object(cam)
            source_uuid = scene_index.persistent_uuid(scene, 'SCENE', ensure=True)
            cleanup.mark_owned(data, 'camera_data', cam.name, 'SCENE', source_uuid=source_uuid)
            cleanup.mark_object(cam, 'camera', cam.name, 'SCENE', source_uuid=source_uuid)
            target_collection = getattr(context, 'collection', None) or scene.collection
            target_collection.objects.link(cam)
            tx.track_collection_link(target_collection, cam)
            cam.location = Vector((0.0, -6.0, 3.0))
            cam.rotation_euler = (math.radians(60.0), 0.0, 0.0)
            data.smart_camlight_settings.enable_custom_settings = True
            if not tx.set_attr(scene, 'camera', cam):
                raise RuntimeError('scene camera assignment failed')
            settings = _settings(context)
            if settings is not None and not tx.set_attr(settings, 'active_camera_name', cam.name):
                raise RuntimeError('active camera setting failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, cam)
        return {'FINISHED'}

class SCLS_OT_delete_camera(Operator):
    bl_idname = 'smart_camlight_suite.delete_camera'
    bl_label = tr.add('Delete Camera', 'カメラを削除')
    bl_description = tr.add('Delete the selected Smart CamLight camera object from the scene. This does not delete other cameras.', '選択中のSmart CamLight カメラオブジェクトをシーンから削除します。他のカメラは削除しません。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        cleanup.remove_camera_guides_for_camera(cam)
        cleanup.remove_camera_paths_for_camera(cam)
        cleanup.remove_camera_rig_for_camera(cam, remove_constraints=True)
        cleanup.remove_pov_texts_for_camera(cam)
        cleanup.remove_object_and_orphan_data(cam)
        settings = _settings(context)
        if settings:
            settings.active_camera_name = ''
        _notify_scene_structure_changed(context.scene)
        return {'FINISHED'}


class SCLS_OT_apply_camera_settings(Operator):
    bl_idname = 'smart_camlight_suite.apply_camera_settings'
    bl_label = tr.add('Apply Camera Settings', 'カメラ設定を適用')
    bl_description = tr.add('Apply the selected camera custom resolution, output format, frame range, review stamp, transparent film, overscan, and motion-blur values to the scene render settings.', '選択カメラのカスタム解像度、出力形式、フレーム範囲、レビュースタンプ、透過フィルム、オーバースキャン、モーションブラー値をシーンのレンダー設定へ適用します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()
    apply_overscan: BoolProperty(
        name=tr.add('Apply Overscan', 'オーバースキャンを適用'),
        description=tr.add('Also apply the camera overscan mode while copying its custom profile to the scene.', 'カスタムプロファイルをシーンへ反映するときに、カメラのオーバースキャンモードも適用します。'),
        default=True,
    )

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not apply_camera_settings(context, cam, apply_overscan=self.apply_overscan):
            _report(
                self,
                'WARNING',
                'Camera custom settings are disabled or no camera was found.',
                'カメラのカスタム設定が無効、またはカメラが見つかりません。',
                context,
            )
            return {'CANCELLED'}
        return {'FINISHED'}


class SCLS_OT_apply_all_camera_settings(Operator):
    bl_idname = 'smart_camlight_suite.apply_all_camera_settings'
    bl_label = tr.add('Apply All Custom Cameras', '全カスタムカメラを適用')
    bl_description = tr.add('Visit every camera with Smart CamLight custom settings enabled and apply its settings once. The last processed camera remains active.', 'Smart CamLight カスタム設定が有効な全カメラを巡回して設定を一度ずつ適用します。最後に処理したカメラがアクティブのままになります。')
    bl_options = {'UNDO'}

    def execute(self, context):
        count = 0
        for cam in _camera_objects(context.scene):
            if cam.data.smart_camlight_settings.enable_custom_settings:
                if apply_camera_settings(context, cam, apply_overscan=True):
                    count += 1
        _report(self, 'INFO', f'Applied {count} camera settings.', f'{count}件のカメラ設定を適用しました。', context)
        return {'FINISHED'}


class SCLS_OT_swap_resolution(Operator):
    bl_idname = 'smart_camlight_suite.swap_resolution'
    bl_label = tr.add('Swap Resolution', '解像度を入れ替え')
    bl_description = tr.add('Swap the selected camera custom width and height. Use this to change between landscape and portrait framing without rewriting values.', '選択カメラのカスタム幅と高さを入れ替えます。値を書き直さず横長/縦長フレーミングを切り替えるために使います。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        cset = cam.data.smart_camlight_settings
        cset.resolution_x, cset.resolution_y = cset.resolution_y, cset.resolution_x
        return {'FINISHED'}


class SCLS_OT_add_marker_bind_camera(Operator):
    bl_idname = 'smart_camlight_suite.add_marker_bind_camera'
    bl_label = tr.add('Add Marker and Bind Camera', 'マーカーを追加してカメラにバインド')
    bl_description = tr.add('Create a timeline marker at the current frame and bind it to the selected camera for marker-based camera switching and per-camera frame ranges.', '現在フレームにタイムラインマーカーを作成し、選択カメラへバインドします。マーカー式カメラ切替とカメラ別フレーム範囲に使います。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        marker = context.scene.timeline_markers.new(f'SCLS_{cam.name}', frame=context.scene.frame_current)
        marker.camera = cam
        return {'FINISHED'}


class SCLS_OT_refresh_marker_camera(Operator):
    bl_idname = 'smart_camlight_suite.refresh_marker_camera'
    bl_label = tr.add('Refresh Marker Camera', 'マーカーカメラを更新')
    bl_description = tr.add('Set the scene active camera from the camera marker that is active at the current frame.', '現在フレームで有効なカメラマーカーからシーンのアクティブカメラを設定します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        cam = camera_from_marker_at_frame(context.scene, context.scene.frame_current)
        if not cam:
            return {'CANCELLED'}
        context.scene.camera = cam
        settings = _settings(context)
        if settings:
            settings.active_camera_name = cam.name
        return {'FINISHED'}



class SCLS_OT_create_camera_rig(Operator):
    bl_idname = 'smart_camlight_suite.create_camera_rig'
    bl_label = tr.add('Create Camera Rig', 'カメラリグを作成')
    bl_description = tr.add('Create a target-based camera rig using Empty objects and a Track To constraint. The optional dolly parent keeps movement separate from aiming.', 'EmptyオブジェクトとTrack Toコンストレイントでターゲット式カメラリグを作成します。任意のドリー親により移動と照準を分離できます。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        scene = context.scene
        cset = cam.data.smart_camlight_settings
        source_uuid = _source_uuid(cam, 'OBJECT')
        scene_index.rebuild_scene(scene, ensure_uuids=True)
        old_helpers = _owned_helpers(scene, cam, {'camera_rig_target', 'camera_rig_dolly'})
        old_constraints = _owned_constraints(cam, {'camera_rig_constraint'})
        tx = transactions.DataTransaction('Create Camera Rig')
        try:
            world_matrix = cam.matrix_world.copy()
            forward = world_matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))
            target_loc = world_matrix.translation + forward.normalized() * float(cset.rig_target_distance)
            target = bpy.data.objects.new(f'SCLS_Target_{cam.name}', None)
            tx.track_object(target)
            cleanup.mark_object(target, 'camera_rig_target', cam.name, 'CAMERA', source_uuid=source_uuid)
            target.empty_display_type = 'SPHERE'
            target.empty_display_size = max(0.001, float(getattr(cset, 'rig_target_size', 0.04) or 0.04))
            target.location = target_loc
            scene.collection.objects.link(target)
            tx.track_collection_link(scene.collection, target)

            if cset.rig_type == 'DOLLY_TARGET':
                dolly = bpy.data.objects.new(f'SCLS_Dolly_{cam.name}', None)
                tx.track_object(dolly)
                cleanup.mark_object(dolly, 'camera_rig_dolly', cam.name, 'CAMERA', source_uuid=source_uuid)
                dolly.empty_display_type = 'CUBE'
                dolly.empty_display_size = 0.8
                # matrix_world, not location: the camera transform below is solved
                # against the parent matrix, which a new object has not evaluated yet.
                dolly.matrix_world = Matrix.Translation(world_matrix.translation)
                scene.collection.objects.link(dolly)
                tx.track_collection_link(scene.collection, dolly)
                # Snapshot the transform before the parent: rollback runs backwards,
                # so the old parent is back when the old world transform is solved.
                if not tx.snapshot_attr(cam, 'matrix_world'):
                    raise RuntimeError('camera world transform snapshot failed')
                if not tx.set_attr(cam, 'parent', dolly):
                    raise RuntimeError('camera parent assignment failed')
                if not tx.set_attr(cam, 'matrix_world', world_matrix):
                    raise RuntimeError('camera world transform restore failed')
            else:
                old_parent = getattr(cam, 'parent', None)
                if cleanup.is_owned(old_parent, role='camera_rig_dolly', source_uuid=source_uuid):
                    if not tx.snapshot_attr(cam, 'matrix_world'):
                        raise RuntimeError('camera world transform snapshot failed')
                    if not tx.set_attr(cam, 'parent', None):
                        raise RuntimeError('camera parent clear failed')
                    if not tx.set_attr(cam, 'matrix_world', world_matrix):
                        raise RuntimeError('camera world transform restore failed')

            constraint = _make_track_to(
                cam,
                target,
                camera=True,
                transaction=tx,
                role='camera_rig_constraint',
                source_uuid=source_uuid,
            )
            if constraint is None:
                raise RuntimeError('camera track constraint creation failed')
            if cset.rig_create_dof:
                if not tx.set_attr(cam.data.dof, 'use_dof', True):
                    raise RuntimeError('camera DOF enable failed')
                if not tx.set_attr(cam.data.dof, 'focus_object', target):
                    raise RuntimeError('camera DOF target assignment failed')
            else:
                old_focus = getattr(cam.data.dof, 'focus_object', None)
                if cleanup.is_owned(old_focus, role='camera_rig_target', source_uuid=source_uuid):
                    if not tx.set_attr(cam.data.dof, 'focus_object', None):
                        raise RuntimeError('old camera DOF target clear failed')
            _defer_remove_constraints(tx, cam, old_constraints)
            _defer_remove_objects(tx, old_helpers)
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, target)
        return {'FINISHED'}

class SCLS_OT_set_dof_to_selected(Operator):
    bl_idname = 'smart_camlight_suite.set_dof_to_selected'
    bl_label = tr.add('Set DOF to Selected Object', 'DOFを選択オブジェクトに設定')
    bl_description = tr.add('Assign the currently selected non-camera object as the focus object of the active Smart CamLight camera.', '現在選択している非カメラオブジェクトを、アクティブなSmart CamLight カメラのフォーカスオブジェクトに割り当てます。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        target = context.active_object
        if not cam or not target or target == cam:
            return {'CANCELLED'}
        cam.data.dof.use_dof = True
        cam.data.dof.focus_object = target
        return {'FINISHED'}



class SCLS_OT_create_path_from_camera_keys(Operator):
    bl_idname = 'smart_camlight_suite.create_path_from_camera_keys'
    bl_label = tr.add('Create Path From Camera Keys', 'カメラキーからパスを作成')
    bl_description = tr.add('Sample the selected camera location animation over its frame range and create a curve path for review or further rigging.', '選択カメラの位置アニメーションをフレーム範囲でサンプリングし、レビューや追加リグ用のカーブパスを作成します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        scene = context.scene
        cset = cam.data.smart_camlight_settings
        start, end, step = int(cset.frame_start), int(cset.frame_end), max(1, int(cset.frame_step))
        source_uuid = _source_uuid(cam, 'OBJECT')
        scene_index.rebuild_scene(scene, ensure_uuids=True)
        old_paths = _owned_helpers(scene, cam, {'camera_path'})
        tx = transactions.DataTransaction('Create Camera Path')
        current_frame = int(scene.frame_current)
        tx.add_rollback(lambda: scene.frame_set(current_frame))
        try:
            curve = bpy.data.curves.new(f'SCLS_Path_{cam.name}', 'CURVE')
            tx.track_datablock(bpy.data.curves, curve)
            cleanup.mark_owned(curve, 'camera_path_data', cam.name, 'CAMERA', source_uuid=source_uuid)
            curve.dimensions = '3D'
            spline = curve.splines.new('POLY')
            frames = list(range(start, end + 1, step)) or [current_frame]
            spline.points.add(max(0, len(frames) - 1))
            for point, frame in zip(spline.points, frames):
                scene.frame_set(frame)
                loc = cam.matrix_world.translation
                point.co = (loc.x, loc.y, loc.z, 1.0)
            scene.frame_set(current_frame)
            obj = bpy.data.objects.new(curve.name, curve)
            tx.track_object(obj)
            cleanup.mark_object(obj, 'camera_path', cam.name, 'CAMERA', source_uuid=source_uuid)
            scene.collection.objects.link(obj)
            tx.track_collection_link(scene.collection, obj)
            curve.bevel_depth = 0.01
            _defer_remove_objects(tx, old_paths)
            tx.commit()
        except Exception:
            try:
                scene.frame_set(current_frame)
            except Exception:
                pass
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, obj)
        return {'FINISHED'}

class SCLS_OT_bake_camera_transform(Operator):
    bl_idname = 'smart_camlight_suite.bake_camera_transform'
    bl_label = tr.add('Bake Camera Transform', 'カメラトランスフォームをベイク')
    bl_description = tr.add('Bake the selected camera world transform into location and rotation keyframes over its configured frame range. This is useful after constraints or rig motion are approved.', '選択カメラのワールドトランスフォームを、設定フレーム範囲の位置・回転キーフレームへベイクします。コンストレイントやリグ動作を確定した後に使います。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        cset = cam.data.smart_camlight_settings
        current = context.scene.frame_current
        matrices = []
        frames = list(range(int(cset.frame_start), int(cset.frame_end) + 1, max(1, int(cset.frame_step))))
        try:
            for frame in frames:
                context.scene.frame_set(frame)
                matrices.append((frame, cam.matrix_world.copy()))
            cam.parent = None
            for frame, matrix in matrices:
                context.scene.frame_set(frame)
                cam.matrix_world = matrix
                cam.keyframe_insert('location', frame=frame)
                cam.keyframe_insert('rotation_euler', frame=frame)
        finally:
            context.scene.frame_set(current)
        return {'FINISHED'}


class SCLS_OT_create_camera_guides(Operator):
    bl_idname = 'smart_camlight_suite.create_camera_guides'
    bl_label = tr.add('Create Camera Guides', 'カメラガイドを作成')
    bl_description = tr.add('Create camera-space composition guides such as thirds, center cross, and safe area as curve objects parented to the selected camera.', '三分割、中央十字、セーフエリアなどのカメラ空間構図ガイドを、選択カメラに親子付けされたカーブオブジェクトとして作成します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        scene = context.scene
        scene_index.rebuild_scene(scene, ensure_uuids=True)
        old_guides = _owned_helpers(scene, cam, {'camera_guide'})
        tx = transactions.DataTransaction('Replace Camera Guides')
        try:
            guide = create_camera_guides(context, cam, transaction=tx)
            if guide is None:
                raise RuntimeError('camera guide creation failed')
            _defer_remove_objects(tx, old_guides)
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, guide)
        return {'FINISHED'}


class SCLS_OT_remove_camera_guides(Operator):
    bl_idname = 'smart_camlight_suite.remove_camera_guides'
    bl_label = tr.add('Remove Camera Guides', 'カメラガイドを削除')
    bl_description = tr.add('Remove Smart CamLight composition guide objects parented to the selected camera.', '選択カメラに親子付けされたSmart CamLight 構図ガイドオブジェクトを削除します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        remove_camera_guides(cam)
        _notify_scene_structure_changed(context.scene)
        return {'FINISHED'}


class SCLS_OT_apply_overscan(Operator):
    bl_idname = 'smart_camlight_suite.apply_overscan'
    bl_label = tr.add('Apply Overscan', 'オーバースキャンを適用')
    bl_description = tr.add('Apply the selected camera overscan mode to the scene render resolution and widen the camera lens to show more around the same picture. The original resolution is stored for revert.', '選択カメラのオーバースキャンモードをシーンのレンダー解像度へ適用し、同じ絵の周りが写るようにカメラのレンズを広げます。元の解像度は復元用に保存します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not apply_overscan_settings(context, cam):
            return {'CANCELLED'}
        return {'FINISHED'}


class SCLS_OT_revert_overscan(Operator):
    bl_idname = 'smart_camlight_suite.revert_overscan'
    bl_label = tr.add('Revert Overscan', 'オーバースキャンを戻す')
    bl_description = tr.add('Restore the render resolution and camera lens saved before the last Smart CamLight overscan application.', '直前のSmart CamLight オーバースキャン適用前に保存したレンダー解像度とカメラのレンズへ戻します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        return {'FINISHED'} if revert_overscan_settings(context) else {'CANCELLED'}


class SCLS_OT_refresh_motion_blur(Operator):
    bl_idname = 'smart_camlight_suite.refresh_motion_blur'
    bl_label = tr.add('Refresh Motion Blur', 'モーションブラーを更新')
    bl_description = tr.add('Convert the selected camera shutter speed or shutter angle into Blender motion blur settings immediately.', '選択カメラのシャッタースピードまたはシャッター角を、Blenderのモーションブラー設定へ即時変換します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        apply_motion_blur(context.scene, cam)
        return {'FINISHED'}


class SCLS_OT_prepare_review_stamps(Operator):
    bl_idname = 'smart_camlight_suite.prepare_review_stamps'
    bl_label = tr.add('Prepare Review Stamps', 'レビュースタンプを準備')
    bl_description = tr.add('Apply animation-review stamp settings for the selected camera without starting a render.', 'レンダーを開始せず、選択カメラのアニメーションレビュースタンプ設定を適用します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        cset = cam.data.smart_camlight_settings
        render = context.scene.render
        render.use_stamp = bool(cset.review_use_stamp)
        _set_if_exists(render, 'use_stamp_camera', bool(cset.review_stamp_camera))
        _set_if_exists(render, 'use_stamp_frame', bool(cset.review_stamp_frame))
        _set_if_exists(render, 'use_stamp_scene', bool(cset.review_stamp_scene))
        return {'FINISHED'}



class SCLS_OT_render_camera(Operator):
    bl_idname = 'smart_camlight_suite.render_camera'
    bl_label = tr.add('Render Selected Camera', '選択カメラをレンダー')
    bl_description = tr.add('Apply the selected camera settings and run either a final render or a viewport OpenGL render. Use with care because rendering can take time.', '選択カメラ設定を適用し、最終レンダーまたはビューポートOpenGLレンダーを実行します。レンダーには時間がかかるため注意して使用してください。')
    bl_options = set()

    camera_name: _camera_name_property()
    mode: _render_mode_property()
    animation: _animation_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        tx = transactions.DataTransaction('Render Selected Camera')
        try:
            apply_camera_settings(context, cam, apply_overscan=True, transaction=tx)
            if not tx.set_attr(context.scene, 'camera', cam):
                raise RuntimeError('render camera assignment failed')
            result = _render_camera_operation(
                context,
                cam,
                mode=self.mode,
                animation=bool(self.animation),
                transaction=tx,
            )
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        tx.rollback()
        return {'CANCELLED'} if 'CANCELLED' in result else {'FINISHED'}


class SCLS_OT_create_pov_camera_text(Operator):
    bl_idname = 'smart_camlight_suite.create_pov_camera_text'
    bl_label = tr.add('Create POV Camera Text', 'POVカメラテキストを作成')
    bl_description = tr.add('Create a Blender text block containing a simple POV-compatible camera statement based on the selected camera transform and lens data.', '選択カメラのトランスフォームとレンズ情報を基に、簡易POV互換camera文を含むBlenderテキストブロックを作成します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        source_uuid = _source_uuid(cam, 'OBJECT')
        old_texts = tuple(
            text for text in tuple(getattr(bpy.data, 'texts', ()) or ())
            if cleanup.is_owned(text, role='pov_text', source_uuid=source_uuid)
        )
        cset = cam.data.smart_camlight_settings
        loc = cam.matrix_world.translation
        direction = cam.matrix_world.to_quaternion() @ Vector((0, 0, -1))
        look = loc + direction
        angle = math.degrees(getattr(cam.data, 'angle', math.radians(50.0)))
        lines = [
            f'// {cset.pov_note}',
            'camera {',
            f'  location <{loc.x:.6f}, {loc.y:.6f}, {loc.z:.6f}>',
            f'  look_at <{look.x:.6f}, {look.y:.6f}, {look.z:.6f}>',
            f'  angle {angle:.6f}',
        ]
        if cset.pov_export_depth and getattr(cam.data.dof, 'use_dof', False):
            lines.append(f'  aperture {max(0.001, float(getattr(cam.data.dof, "aperture_fstop", 5.6))):.6f}')
            lines.append(f'  focal_point <{look.x:.6f}, {look.y:.6f}, {look.z:.6f}>')
        lines.append('}')
        tx = transactions.DataTransaction('Create POV Camera Text')
        try:
            text = bpy.data.texts.new(f'SCLS_POV_{cam.name}')
            tx.track_datablock(bpy.data.texts, text)
            cleanup.mark_owned(text, 'pov_text', cam.name, 'CAMERA', source_uuid=source_uuid)
            text.write('\n'.join(lines))
            tx.defer_commit(lambda: [bpy.data.texts.remove(item) for item in old_texts if cleanup.is_owned(item, role='pov_text', source_uuid=source_uuid)])
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        return {'FINISHED'}

def _material_for_guides(name, color, *, transaction, source_uuid: str):
    material = bpy.data.materials.new(name)
    transaction.track_datablock(bpy.data.materials, material)
    cleanup.mark_owned(
        material,
        'camera_guide_material',
        name,
        'CAMERA',
        source_uuid=source_uuid,
    )
    material.diffuse_color = color
    return material


def _add_line_spline(curve, p0, p1, *, dashed=False, segments=12):
    if not dashed:
        sp = curve.splines.new('POLY')
        sp.points.add(1)
        sp.points[0].co = (p0[0], p0[1], p0[2], 1.0)
        sp.points[1].co = (p1[0], p1[1], p1[2], 1.0)
        return
    p0v = Vector(p0)
    p1v = Vector(p1)
    for i in range(segments):
        if i % 2:
            continue
        a = p0v.lerp(p1v, i / segments)
        b = p0v.lerp(p1v, (i + 1) / segments)
        sp = curve.splines.new('POLY')
        sp.points.add(1)
        sp.points[0].co = (a.x, a.y, a.z, 1.0)
        sp.points[1].co = (b.x, b.y, b.z, 1.0)


def create_camera_guides(context, cam, *, transaction=None):
    if cam is None or getattr(cam, 'type', None) != 'CAMERA':
        return None
    scene = getattr(context, 'scene', None)
    if scene is None:
        return None
    own_transaction = transaction is None
    tx = transaction or transactions.DataTransaction('Create Camera Guides')
    source_uuid = _source_uuid(cam, 'OBJECT')
    try:
        cset = cam.data.smart_camlight_settings
        material = _material_for_guides(
            f'SCLS Camera Guide Material {cam.name}',
            cset.guide_color,
            transaction=tx,
            source_uuid=source_uuid,
        )
        frame = [Vector(value) for value in cam.data.view_frame(scene=scene)]
        if not frame:
            raise RuntimeError('camera view frame unavailable')
        xs = [value.x for value in frame]
        ys = [value.y for value in frame]
        z = frame[0].z
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        curve = bpy.data.curves.new(f'SCLS_Guides_{cam.name}', 'CURVE')
        tx.track_datablock(bpy.data.curves, curve)
        cleanup.mark_owned(
            curve,
            'camera_guide_data',
            cam.name,
            'CAMERA',
            source_uuid=source_uuid,
        )
        curve.dimensions = '3D'
        curve.resolution_u = 1
        curve.bevel_depth = float(cset.guide_line_width)
        dashed = cset.guide_line_style == 'DASHED'
        if cset.guide_thirds:
            for x in (xmin + (xmax - xmin) / 3.0, xmin + 2.0 * (xmax - xmin) / 3.0):
                _add_line_spline(curve, (x, ymin, z), (x, ymax, z), dashed=dashed)
            for y in (ymin + (ymax - ymin) / 3.0, ymin + 2.0 * (ymax - ymin) / 3.0):
                _add_line_spline(curve, (xmin, y, z), (xmax, y, z), dashed=dashed)
        if cset.guide_center:
            cx = (xmin + xmax) * 0.5
            cy = (ymin + ymax) * 0.5
            _add_line_spline(curve, (cx, ymin, z), (cx, ymax, z), dashed=dashed)
            _add_line_spline(curve, (xmin, cy, z), (xmax, cy, z), dashed=dashed)
        if cset.guide_safe_area:
            scale = max(0.01, min(1.0, float(cset.guide_safe_percentage) / 100.0))
            cx = (xmin + xmax) * 0.5
            cy = (ymin + ymax) * 0.5
            hw = (xmax - xmin) * 0.5 * scale
            hh = (ymax - ymin) * 0.5 * scale
            points = [
                (cx - hw, cy - hh, z),
                (cx + hw, cy - hh, z),
                (cx + hw, cy + hh, z),
                (cx - hw, cy + hh, z),
            ]
            for first, second in zip(points, points[1:] + points[:1]):
                _add_line_spline(curve, first, second, dashed=dashed)
        obj = bpy.data.objects.new(curve.name, curve)
        tx.track_object(obj)
        cleanup.mark_object(
            obj,
            'camera_guide',
            cam.name,
            'CAMERA',
            source_uuid=source_uuid,
        )
        scene.collection.objects.link(obj)
        tx.track_collection_link(scene.collection, obj)
        obj.parent = cam
        obj.matrix_parent_inverse.identity()
        obj.hide_render = not bool(cset.guide_render_enabled)
        curve.materials.append(material)
        if own_transaction:
            tx.commit()
            _notify_scene_structure_changed(scene)
        return obj
    except Exception:
        if own_transaction:
            tx.rollback()
            return None
        raise


def remove_camera_guides(cam):
    cleanup.remove_camera_guides_for_camera(cam)




class SCLS_OT_apply_aspect_preset(Operator):
    bl_idname = 'smart_camlight_suite.apply_aspect_preset'
    bl_label = tr.add('Apply Camera Aspect Preset', 'カメラ縦横比プリセットを適用')
    bl_description = tr.add('Apply a common aspect-ratio resolution preset to the selected camera custom resolution. This updates only Smart CamLight camera settings until Apply is used.', '一般的な縦横比の解像度プリセットを選択カメラのカスタム解像度へ適用します。適用ボタンを使うまではSmart CamLight のカメラ設定だけを更新します。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()
    preset: EnumProperty(
        name=tr.add('Aspect Preset', '縦横比プリセット'),
        description=tr.add('Choose a common width and height pair to store in the selected camera profile. Run Apply afterward to copy it to scene render settings.', '選択カメラのプロファイルへ保存する一般的な幅と高さの組み合わせを選択します。シーンのレンダー設定へ反映するには、その後に「適用」を実行します。'),
        items=[
            ('HD_16_9', tr.add('16:9 Landscape', '16:9 横長'), tr.add('Set 1920 x 1080 resolution.', '1920 x 1080解像度に設定します。')),
            ('VERTICAL_9_16', tr.add('9:16 Vertical', '9:16 縦長'), tr.add('Set 1080 x 1920 vertical resolution.', '1080 x 1920の縦長解像度に設定します。')),
            ('SQUARE_1_1', tr.add('1:1 Square', '1:1 正方形'), tr.add('Set 1080 x 1080 square resolution.', '1080 x 1080の正方形解像度に設定します。')),
            ('CINEMA_239', tr.add('2.39:1 Cinema', '2.39:1 シネマ'), tr.add('Set 2048 x 858 cinema-scope style resolution.', '2048 x 858のシネマスコープ風解像度に設定します。')),
            ('FOUR_THREE', tr.add('4:3 Classic', '4:3 クラシック'), tr.add('Set 1440 x 1080 classic 4:3 resolution.', '1440 x 1080のクラシックな4:3解像度に設定します。')),
        ],
        default='HD_16_9',
    )

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        values = {
            'HD_16_9': (1920, 1080),
            'VERTICAL_9_16': (1080, 1920),
            'SQUARE_1_1': (1080, 1080),
            'CINEMA_239': (2048, 858),
            'FOUR_THREE': (1440, 1080),
        }
        x, y = values.get(self.preset, (1920, 1080))
        cset = cam.data.smart_camlight_settings
        cset.resolution_x = x
        cset.resolution_y = y
        return {'FINISHED'}


class SCLS_OT_insert_camera_key(Operator):
    bl_idname = 'smart_camlight_suite.insert_camera_key'
    bl_label = tr.add('Insert Camera Key', 'カメラキーを挿入')
    bl_description = tr.add('Insert location, rotation, lens, and focus-distance keyframes for the selected camera at the current frame. Use it for simple camera-fly recording and review blocking.', '現在フレームで選択カメラの位置、回転、レンズ、フォーカス距離キーフレームを挿入します。簡易カメラフライ記録やレビューブロッキングに使います。')
    bl_options = {'UNDO'}

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        frame = context.scene.frame_current
        cam.keyframe_insert('location', frame=frame)
        cam.keyframe_insert('rotation_euler', frame=frame)
        cam.data.keyframe_insert('lens', frame=frame)
        try:
            cam.data.dof.keyframe_insert('focus_distance', frame=frame)
        except Exception:
            pass
        return {'FINISHED'}


class SCLS_OT_camera_fly_view(Operator):
    bl_idname = 'smart_camlight_suite.camera_fly_view'
    bl_label = tr.add('Start Camera Fly View', 'カメラフライビューを開始')
    bl_description = tr.add('Switch the current 3D View to the selected camera and start Blender walk navigation when the operator is run from a 3D View.', '現在の3Dビューを選択カメラの視点にし、3Dビューから実行された場合にBlender標準のウォーク操作を始めます。')
    bl_options = set()

    camera_name: _camera_name_property()

    def execute(self, context):
        cam = _get_camera(context, self.camera_name)
        if not cam:
            return {'CANCELLED'}
        if getattr(context.area, 'type', None) != 'VIEW_3D':
            _report(
                self,
                'INFO',
                'Start camera fly view from a 3D View area.',
                'カメラフライビューは3Dビュー領域から開始してください。',
                context,
            )
            return {'CANCELLED'}
        context.scene.camera = cam
        space = context.space_data
        space.camera = cam
        # Not view3d.view_camera: it toggles, and its smooth view would still be
        # running when walk starts.
        space.region_3d.view_perspective = 'CAMERA'
        # The button lives in the sidebar, but walk needs the main 3D View region.
        region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
        try:
            with context.temp_override(region=region):
                result = bpy.ops.view3d.walk('INVOKE_DEFAULT')
        except Exception:
            result = {'CANCELLED'}
        if 'CANCELLED' in result:
            _report(
                self,
                'WARNING',
                'Camera fly view could not start for this camera.',
                'このカメラではカメラフライビューを開始できません。',
                context,
            )
            return {'CANCELLED'}
        return {'FINISHED'}


class SCLS_OT_clear_camera_rigs(Operator):
    bl_idname = 'smart_camlight_suite.clear_camera_rigs'
    bl_label = tr.add('Clear Smart Camera Rigs', 'Smart カメラリグをクリア')
    bl_description = tr.add('Remove Smart CamLight target, dolly, and path helper objects and remove Smart CamLight track constraints from cameras. Camera objects are kept.', 'Smart CamLight のターゲット、ドリー、パス補助オブジェクトを削除し、カメラからSmart CamLight トラックコンストレイントを外します。カメラ本体は残します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        count = 0
        for cam in _camera_objects(context.scene):
            count += cleanup.remove_camera_rig_for_camera(cam, remove_constraints=True)
            count += cleanup.remove_camera_paths_for_camera(cam)
        _notify_scene_structure_changed(context.scene)
        _report(self, 'INFO', f'Cleared {count} camera rig items.', f'カメラリグ項目を{count}件クリアしました。', context)
        return {'FINISHED'}



class SCLS_OT_render_all_cameras(Operator):
    bl_idname = 'smart_camlight_suite.render_all_cameras'
    bl_label = tr.add('Render All Cameras', '全カメラをレンダー')
    bl_description = tr.add('Render every scene camera or every Smart CamLight custom camera in sequence after applying its camera-specific settings. This is a batch-render command and can take time.', 'シーン内の全カメラ、またはSmart CamLight カスタムカメラを順番にレンダーします。各カメラ固有設定を適用してから処理します。バッチレンダーコマンドのため時間がかかる場合があります。')
    bl_options = set()

    custom_only: BoolProperty(
        name=tr.add('Custom Cameras Only', 'カスタムカメラのみ'),
        description=tr.add('Render only cameras whose Smart CamLight custom settings checkbox is enabled. Disable it to render every camera in the current scene.', 'Smart CamLight のカスタム設定チェックが有効なカメラだけをレンダーします。無効にすると現在シーンの全カメラを処理します。'),
        default=True,
    )
    animation: _animation_property()
    mode: _render_mode_property()

    def execute(self, context):
        cameras = _camera_objects(context.scene)
        if self.custom_only:
            cameras = [cam for cam in cameras if cam.data.smart_camlight_settings.enable_custom_settings]
        if not cameras:
            return {'CANCELLED'}
        for cam in cameras:
            tx = transactions.DataTransaction('Render Camera Batch Item')
            try:
                apply_camera_settings(context, cam, apply_overscan=True, transaction=tx)
                if not tx.set_attr(context.scene, 'camera', cam):
                    raise RuntimeError('batch render camera assignment failed')
                result = _render_camera_operation(
                    context,
                    cam,
                    mode=self.mode,
                    animation=bool(self.animation),
                    transaction=tx,
                )
            except Exception:
                tx.rollback()
                return {'CANCELLED'}
            tx.rollback()
            if 'CANCELLED' in result:
                return {'CANCELLED'}
        return {'FINISHED'}

class SCLS_OT_select_light(Operator):
    bl_idname = 'smart_camlight_suite.select_light'
    bl_label = tr.add('Select Light', 'ライトを選択')
    bl_description = tr.add('Select the light and make it the active Smart CamLight light. Hidden lights are unhidden before selection.', 'ライトを選択し、Smart CamLight のアクティブライトに設定します。非表示ライトは選択前に表示します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        settings = _settings(context)
        if settings:
            settings.active_light_name = light.name
        _select_object(context, light)
        return {'FINISHED'}


class SCLS_OT_add_light(Operator):
    bl_idname = 'smart_camlight_suite.add_light'
    bl_label = tr.add('Add Smart Light', 'Smart ライトを追加')
    bl_description = tr.add('Create a new light using the Smart CamLight generator type, select it, and aim it at the configured target.', 'Smart CamLight 生成タイプを使って新規ライトを作成し、選択して設定ターゲットへ向けます。')
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        light_type = settings.light_type if settings else 'AREA'
        energy = settings.power_max if settings else 500.0
        obj = _create_light(
            context,
            'SCLS_Light',
            light_type,
            Vector((0.0, -4.0, 4.0)),
            energy,
            role='generated_light',
        )
        if obj is None:
            return {'CANCELLED'}
        if settings:
            settings.active_light_name = obj.name
        _select_object(context, obj)
        return {'FINISHED'}


class SCLS_OT_delete_light(Operator):
    bl_idname = 'smart_camlight_suite.delete_light'
    bl_label = tr.add('Delete Light', 'ライトを削除')
    bl_description = tr.add('Delete the selected Smart CamLight light object from the scene.', '選択中のSmart CamLight ライトオブジェクトをシーンから削除します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        cleanup.remove_light_targets_for_light(light)
        # Explicit delete operates on the user-selected light; automatic cleanup
        # remains exact-owner-only.
        cleanup.remove_object_and_orphan_data(light)
        settings = _settings(context)
        if settings:
            settings.active_light_name = ''
        _notify_scene_structure_changed(context.scene)
        return {'FINISHED'}


class SCLS_OT_toggle_light_lock(Operator):
    bl_idname = 'smart_camlight_suite.toggle_light_lock'
    bl_label = tr.add('Toggle Light Lock', 'ライトロックを切り替え')
    bl_description = tr.add('Toggle Smart CamLight editing lock for the selected light. Locked lights remain selectable but editing controls are disabled in the panel.', '選択ライトのSmart CamLight 編集ロックを切り替えます。ロック中のライトは選択できますが、パネル内の編集操作は無効になります。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        light.smart_camlight_object.locked_light = not bool(light.smart_camlight_object.locked_light)
        return {'FINISHED'}


class SCLS_OT_toggle_light_visibility(Operator):
    bl_idname = 'smart_camlight_suite.toggle_light_visibility'
    bl_label = tr.add('Toggle Light Visibility', 'ライト表示を切り替え')
    bl_description = tr.add('Toggle viewport and render visibility for the selected light.', '選択ライトのビューポート表示とレンダー表示を切り替えます。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        visible = not bool(light.hide_viewport or light.hide_render)
        light.hide_viewport = visible
        light.hide_render = visible
        try:
            light.hide_set(visible)
        except Exception:
            pass
        return {'FINISHED'}


class SCLS_OT_all_light_visibility(Operator):
    bl_idname = 'smart_camlight_suite.all_light_visibility'
    bl_label = tr.add('Set All Light Visibility', '全ライト表示を設定')
    bl_description = tr.add('Show or hide every light in the scene in both viewport and render visibility.', 'シーン内の全ライトをビューポート表示とレンダー表示の両方で表示または非表示にします。')
    bl_options = {'UNDO'}

    visible: BoolProperty(
        name=tr.add('Visible', '表示'),
        description=tr.add('Show every scene light when enabled, or hide every scene light from viewport and rendering when disabled.', '有効時はシーン内の全ライトを表示し、無効時は全ライトをビューポートとレンダーの両方で非表示にします。'),
        default=True,
    )

    def execute(self, context):
        for light in _light_objects(context.scene):
            light.hide_viewport = not self.visible
            light.hide_render = not self.visible
            try:
                light.hide_set(not self.visible)
            except Exception:
                pass
        return {'FINISHED'}


class SCLS_OT_isolate_light(Operator):
    bl_idname = 'smart_camlight_suite.isolate_light'
    bl_label = tr.add('Isolate Light', 'ライトを分離表示')
    bl_description = tr.add('Show the selected light and hide all other lights. Use Show All to restore light visibility.', '選択ライトだけを表示し、他のライトを非表示にします。復元するには全表示を使用します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        active = _get_light(context, self.light_name)
        if not active:
            return {'CANCELLED'}
        for light in _light_objects(context.scene):
            hide = light != active
            light.hide_viewport = hide
            light.hide_render = hide
            try:
                light.hide_set(hide)
            except Exception:
                pass
        return {'FINISHED'}


class SCLS_OT_mirror_light(Operator):
    bl_idname = 'smart_camlight_suite.mirror_light'
    bl_label = tr.add('Mirror Light', 'ライトをミラー')
    bl_description = tr.add('Duplicate the selected light and mirror the duplicate across the chosen world axis. The duplicate is aimed at the configured target.', '選択ライトを複製し、指定ワールド軸でミラーします。複製ライトは設定ターゲットへ向けます。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()
    axis: EnumProperty(
        name=tr.add('Mirror Axis', 'ミラー軸'),
        description=tr.add('Choose the world axis across which the duplicate light location is mirrored.', '複製ライトの位置を反転するワールド軸を選択します。'),
        items=[
            ('X', 'X', tr.add('Mirror the light position across the world X axis.', 'ライト位置をワールドX軸で反転します。')),
            ('Y', 'Y', tr.add('Mirror the light position across the world Y axis.', 'ライト位置をワールドY軸で反転します。')),
            ('Z', 'Z', tr.add('Mirror the light position across the world Z axis.', 'ライト位置をワールドZ軸で反転します。')),
        ],
        default='X',
    )

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        scene = context.scene
        tx = transactions.DataTransaction('Mirror Light')
        try:
            data = light.data.copy()
            tx.track_datablock(bpy.data.lights, data)
            dup = light.copy()
            tx.track_object(dup)
            dup.data = data
            dup.name = f'SCLS_Mirror_{light.name}'
            source_uuid = scene_index.persistent_uuid(scene, 'SCENE', ensure=True)
            cleanup.mark_owned(data, 'mirrored_light_data', light.name, 'LIGHT', source_uuid=source_uuid)
            cleanup.mark_object(dup, 'mirrored_light', light.name, 'LIGHT', source_uuid=source_uuid)
            scene.collection.objects.link(dup)
            tx.track_collection_link(scene.collection, dup)
            world_matrix = light.matrix_world.copy()
            loc = world_matrix.translation.copy()
            if self.axis == 'X':
                loc.x *= -1.0
            elif self.axis == 'Y':
                loc.y *= -1.0
            else:
                loc.z *= -1.0
            world_matrix.translation = loc
            dup.matrix_world = world_matrix
            dup.smart_camlight_object.is_generated_light = True
            target = _target_location(context)
            if dup.parent is not None:
                # _aim_at writes local rotation. Convert the world target through
                # the effective parent transform, including matrix_parent_inverse.
                parent_matrix = dup.parent.matrix_world @ dup.matrix_parent_inverse
                target = parent_matrix.inverted_safe() @ target
            _aim_at(dup, target)
            settings = _settings(context)
            if settings is not None and not tx.set_attr(settings, 'active_light_name', dup.name):
                raise RuntimeError('active light assignment failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, dup)
        return {'FINISHED'}


class SCLS_OT_create_light_target(Operator):
    bl_idname = 'smart_camlight_suite.create_light_target'
    bl_label = tr.add('Create Light Target', 'ライトターゲットを作成')
    bl_description = tr.add('Create an Empty target and add a Track To constraint so the selected light points at it.', 'Emptyターゲットを作成し、選択ライトがそれを向くようにTrack Toコンストレイントを追加します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        scene = context.scene
        source_uuid = _source_uuid(light, 'OBJECT')
        scene_index.rebuild_scene(scene, ensure_uuids=True)
        old_targets = _owned_helpers(scene, light, {'light_target'})
        old_constraints = _owned_constraints(light, {'light_target_constraint'})
        tx = transactions.DataTransaction('Replace Light Target')
        try:
            target = bpy.data.objects.new(f'SCLS_Light_Target_{light.name}', None)
            tx.track_object(target)
            target.empty_display_type = 'SPHERE'
            target.empty_display_size = max(0.001, float(getattr(light.data.smart_camlight_light, 'target_size', 0.05) or 0.05))
            target.location = _target_location(context)
            cleanup.mark_object(target, 'light_target', light.name, 'LIGHT', source_uuid=source_uuid)
            scene.collection.objects.link(target)
            tx.track_collection_link(scene.collection, target)
            constraint = _make_track_to(
                light,
                target,
                transaction=tx,
                role='light_target_constraint',
                source_uuid=source_uuid,
            )
            if constraint is None:
                raise RuntimeError('light target constraint creation failed')
            _defer_remove_constraints(tx, light, old_constraints)
            _defer_remove_objects(tx, old_targets)
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, target)
        return {'FINISHED'}


class SCLS_OT_generate_lights(Operator):
    bl_idname = 'smart_camlight_suite.generate_lights'
    bl_label = tr.add('Generate Lights', 'ライトを生成')
    bl_description = tr.add('Generate a deterministic set of lights using the Smart CamLight distribution, target, type, power, size, spot, and area-shape settings.', 'Smart CamLight の分布、ターゲット、タイプ、パワー、サイズ、スポット、エリア形状設定を使って、決定論的なライト群を生成します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        if not settings:
            return {'CANCELLED'}
        scene = context.scene
        rng = random.Random(int(settings.light_seed))
        count = int(settings.light_count)
        center = _target_location(context)
        radius = float(settings.light_distance)
        lights = []
        tx = transactions.DataTransaction('Generate Lights')
        try:
            for i in range(count):
                if settings.distribution == 'GRID':
                    side = max(1, math.ceil(math.sqrt(count)))
                    row = i // side
                    col = i % side
                    x = (col - (side - 1) * 0.5) * radius / max(1, side - 1)
                    z = (row - (side - 1) * 0.5) * radius / max(1, side - 1) + settings.light_z_offset
                    loc = center + Vector((x, -radius, z))
                elif settings.distribution == 'LINE':
                    x = (i - (count - 1) * 0.5) * radius / max(1, count - 1)
                    loc = center + Vector((x, -radius, settings.light_z_offset))
                elif settings.distribution == 'RANDOM':
                    theta = rng.random() * math.tau
                    r = radius * (0.4 + rng.random() * 0.6)
                    loc = center + Vector((math.cos(theta) * r, math.sin(theta) * r, settings.light_z_offset + rng.uniform(-1.0, 1.0) * settings.light_randomness))
                else:
                    theta = math.tau * i / max(1, count)
                    loc = center + Vector((math.cos(theta) * radius, math.sin(theta) * radius, settings.light_z_offset))
                loc += Vector((rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-1, 1))) * float(settings.light_randomness)
                energy = rng.uniform(float(settings.power_min), float(settings.power_max)) if settings.randomize_power else float(settings.power_max)
                obj = _create_light(
                    context,
                    f'SCLS_Generated_{i + 1:02d}',
                    settings.light_type,
                    loc,
                    energy,
                    transaction=tx,
                    role='generated_light',
                )
                if obj is None:
                    raise RuntimeError('generated light creation returned no object')
                lights.append(obj)
            if lights and not tx.set_attr(settings, 'active_light_name', lights[-1].name):
                raise RuntimeError('active generated light assignment failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        if lights:
            _select_object(context, lights[-1])
        return {'FINISHED'}


class SCLS_OT_clear_generated_lights(Operator):
    bl_idname = 'smart_camlight_suite.clear_generated_lights'
    bl_label = tr.add('Clear Generated Lights', '生成ライトをクリア')
    bl_description = tr.add('Delete lights marked as Smart CamLight generated lights and softbox planes. Manually created lights are left untouched.', 'Smart CamLight 生成ライトとしてマークされたライトとソフトボックスの板を削除します。手作業で作成したライトは残します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        generated_roles = {'generated_light', 'studio_light', 'softbox_light', 'mirrored_light'}
        count = 0
        for obj in tuple(_light_objects(context.scene)):
            try:
                role = str(obj.get(cleanup.ROLE_KEY, '') or '')
            except Exception:
                role = ''
            if role not in generated_roles or not cleanup.is_owned(obj, role=role):
                continue
            cleanup.remove_light_targets_for_light(obj)
            count += int(cleanup.remove_object_and_orphan_data(obj))
        for obj in tuple(context.scene.objects):
            if cleanup.is_owned(obj, role='softbox_plane'):
                _remove_owned_mesh_object(obj)
        _notify_scene_structure_changed(context.scene)
        _report(self, 'INFO', f'Cleared {count} generated lights.', f'生成ライトを{count}件クリアしました。', context)
        return {'FINISHED'}


class SCLS_OT_apply_studio_preset(Operator):
    bl_idname = 'smart_camlight_suite.apply_studio_preset'
    bl_label = tr.add('Apply Studio Preset', 'スタジオプリセットを適用')
    bl_description = tr.add('Create a ready-made studio light layout from the selected Smart CamLight preset and aim it at the configured target.', '選択したSmart CamLight プリセットから既成スタジオライトレイアウトを作成し、設定ターゲットへ向けます。')
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        if not settings:
            return {'CANCELLED'}
        scene = context.scene
        center = _target_location(context)
        preset = settings.studio_preset
        specs = []
        if preset == 'THREE_POINT':
            specs = [('Key', 'AREA', (3, -4, 4), 700, 4.0), ('Fill', 'AREA', (-4, -3, 3), 220, 6.0), ('Rim', 'SPOT', (0, 4, 3), 450, 1.0)]
        elif preset == 'SOFT_STUDIO':
            specs = [('LeftSoft', 'AREA', (-4, -3, 3), 500, 5.0), ('RightSoft', 'AREA', (4, -3, 3), 500, 5.0), ('TopSoft', 'AREA', (0, 0, 6), 350, 6.0)]
        elif preset == 'RIM_CIRCLE':
            for i in range(6):
                theta = math.tau * i / 6
                specs.append((f'Rim{i + 1}', 'SPOT', (math.cos(theta) * 5, math.sin(theta) * 5, 3), 300, 0.8))
        elif preset == 'PRODUCT_STRIP':
            specs = [('StripL', 'AREA', (-3, -4, 2.5), 650, 1.0), ('StripR', 'AREA', (3, -4, 2.5), 650, 1.0), ('BackStrip', 'AREA', (0, 3, 2), 250, 1.0)]
        else:
            specs = [('SkyFill', 'AREA', (0, -3, 6), 450, 8.0)]
        created = []
        tx = transactions.DataTransaction('Apply Studio Preset')
        try:
            for suffix, light_type, offset, energy, size in specs:
                obj = _create_light(
                    context,
                    f'SCLS_Studio_{suffix}',
                    light_type,
                    center + Vector(offset),
                    energy,
                    transaction=tx,
                    role='studio_light',
                )
                if obj is None:
                    raise RuntimeError('studio light creation returned no object')
                _apply_explicit_light_size(obj.data, size)
                created.append(obj)
            if preset == 'SKY_FILL':
                world = create_dynamic_sky(context, transaction=tx)
                if world is None:
                    raise RuntimeError('dynamic sky creation failed')
            if created and not tx.set_attr(settings, 'active_light_name', created[-1].name):
                raise RuntimeError('active studio light assignment failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        if created:
            _select_object(context, created[-1])
        return {'FINISHED'}


class SCLS_OT_create_softbox(Operator):
    bl_idname = 'smart_camlight_suite.create_softbox'
    bl_label = tr.add('Create Softbox', 'ソフトボックスを作成')
    bl_description = tr.add('Create an emission plane and an area light as a softbox setup aimed at the configured target.', '設定ターゲットへ向く発光プレーンとエリアライトを作成し、ソフトボックス設定を構築します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        if not settings:
            return {'CANCELLED'}
        scene = context.scene
        source_uuid = scene_index.persistent_uuid(scene, 'SCENE', ensure=True)
        center = _target_location(context)
        loc = center + Vector((0, -float(settings.light_distance), float(settings.light_z_offset)))
        half_size = max(0.0005, float(settings.light_size) * 0.5)
        tx = transactions.DataTransaction('Create Softbox')
        try:
            material = bpy.data.materials.new('SCLS_Softbox_Emission')
            tx.track_datablock(bpy.data.materials, material)
            cleanup.mark_owned(material, 'softbox_material', '', 'SCENE', source_uuid=source_uuid)
            material.use_nodes = True
            bsdf = next((node for node in material.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'), None)
            if bsdf:
                if 'Emission Color' in bsdf.inputs:
                    bsdf.inputs['Emission Color'].default_value = (1.0, 1.0, 1.0, 1.0)
                if 'Emission Strength' in bsdf.inputs:
                    bsdf.inputs['Emission Strength'].default_value = max(0.1, float(settings.power_max) / 100.0)

            mesh = bpy.data.meshes.new('SCLS_Softbox_Plane_Mesh')
            tx.track_datablock(bpy.data.meshes, mesh)
            cleanup.mark_owned(mesh, 'softbox_plane_mesh', '', 'SCENE', source_uuid=source_uuid)
            mesh.from_pydata(
                [
                    (-half_size, -half_size, 0.0),
                    (half_size, -half_size, 0.0),
                    (half_size, half_size, 0.0),
                    (-half_size, half_size, 0.0),
                ],
                [],
                [(0, 1, 2, 3)],
            )
            mesh.update()
            plane = bpy.data.objects.new('SCLS_Softbox_Plane', mesh)
            tx.track_object(plane)
            cleanup.mark_object(plane, 'softbox_plane', '', 'SCENE', source_uuid=source_uuid)
            scene.collection.objects.link(plane)
            tx.track_collection_link(scene.collection, plane)
            plane.location = loc
            mesh.materials.append(material)
            _aim_at(plane, center)

            light = _create_light(
                context,
                'SCLS_Softbox_Area',
                'AREA',
                loc + (center - loc).normalized() * 0.05,
                float(settings.power_max),
                transaction=tx,
                role='softbox_light',
            )
            if light is None:
                raise RuntimeError('softbox light creation failed')
            _aim_at(light, center)
            if not tx.set_attr(settings, 'active_light_name', light.name):
                raise RuntimeError('active softbox light assignment failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        _notify_scene_structure_changed(scene)
        _select_object(context, light)
        return {'FINISHED'}


def _set_socket_default(socket, value) -> bool:
    try:
        current = socket.default_value
        if isinstance(current, (int, float)) and isinstance(value, (int, float)):
            if math.isclose(float(current), float(value), rel_tol=1.0e-7, abs_tol=1.0e-7):
                return False
        elif current == value:
            return False
        socket.default_value = value
        return True
    except Exception:
        return False


def _set_numeric_attr_if_changed(owner, attr: str, value) -> bool:
    try:
        if not hasattr(owner, attr):
            return False
        current = getattr(owner, attr)
        if isinstance(current, (int, float)) and isinstance(value, (int, float)):
            if math.isclose(float(current), float(value), rel_tol=1.0e-7, abs_tol=1.0e-7):
                return False
        elif current == value:
            return False
        setattr(owner, attr, value)
        return True
    except Exception:
        return False


def _ensure_node_link(links, from_socket, to_socket) -> bool:
    """Ensure one exact node connection without accumulating stale input links."""
    try:
        for link in tuple(getattr(to_socket, 'links', ()) or ()):
            if getattr(link, 'from_socket', None) is from_socket and getattr(link, 'to_socket', None) is to_socket:
                return False
        for link in tuple(getattr(to_socket, 'links', ()) or ()):
            try:
                links.remove(link)
            except Exception:
                pass
        links.new(from_socket, to_socket)
        return True
    except Exception:
        return False


def _owned_role(id_data, role: str, *, source_uuid: str | None = None) -> bool:
    return cleanup.is_owned(id_data, role=role, source_uuid=source_uuid)


def _dynamic_sky_source_uuid(scene) -> str:
    return scene_index.persistent_uuid(scene, 'SCENE', ensure=True) if scene is not None else ''


def _exact_owned_dynamic_world(settings, scene):
    source_uuid = _dynamic_sky_source_uuid(scene)
    world = getattr(settings, 'dynamic_sky_owned_world', None) if settings is not None else None
    return world if cleanup.is_owned(world, role='dynamic_sky_world', source_uuid=source_uuid) else None


def _exact_owned_dynamic_sun(settings, scene):
    source_uuid = _dynamic_sky_source_uuid(scene)
    sun = getattr(settings, 'dynamic_sky_owned_sun', None) if settings is not None else None
    if cleanup.is_owned(sun, role='dynamic_sun', source_uuid=source_uuid):
        return sun
    index = scene_index.get_index(scene)
    candidate = getattr(index, 'dynamic_sun', None) if index is not None else None
    return candidate if cleanup.is_owned(candidate, role='dynamic_sun', source_uuid=source_uuid) else None


def _build_owned_dynamic_world(scene, settings, transaction):
    source_uuid = _dynamic_sky_source_uuid(scene)
    world = bpy.data.worlds.new('SCLS Dynamic Sky World')
    transaction.track_datablock(bpy.data.worlds, world)
    cleanup.mark_owned(world, 'dynamic_sky_world', '', 'SCENE', source_uuid=source_uuid)
    world.use_nodes = True
    node_tree = world.node_tree
    if node_tree is None:
        raise RuntimeError('owned dynamic sky world has no node tree')
    nodes = node_tree.nodes
    links = node_tree.links
    nodes.clear()
    output = nodes.new(type='ShaderNodeOutputWorld')
    output.name = 'SCLS Dynamic Sky Output'
    output.label = 'Smart CamLight Dynamic Sky Output'
    background = nodes.new(type='ShaderNodeBackground')
    background.name = 'SCLS Dynamic Sky Background'
    background.label = 'Smart CamLight Dynamic Sky Background'
    sky = nodes.new(type='ShaderNodeTexSky')
    sky.name = 'SCLS Dynamic Sky Texture'
    sky.label = 'Smart CamLight Dynamic Sky Texture'
    if not _set_socket_default(background.inputs['Strength'], float(settings.sky_strength)):
        background.inputs['Strength'].default_value = float(settings.sky_strength)
    _set_numeric_attr_if_changed(sky, 'turbidity', float(settings.sky_turbidity))
    links.new(sky.outputs['Color'], background.inputs['Color'])
    links.new(background.outputs['Background'], output.inputs['Surface'])
    return world


def _build_owned_dynamic_sun(scene, settings, transaction):
    source_uuid = _dynamic_sky_source_uuid(scene)
    data = bpy.data.lights.new('SCLS Dynamic Sky Sun Data', 'SUN')
    transaction.track_datablock(bpy.data.lights, data)
    cleanup.mark_owned(data, 'dynamic_sun_data', '', 'SCENE', source_uuid=source_uuid)
    sun = bpy.data.objects.new('SCLS Dynamic Sky Sun', data)
    transaction.track_object(sun)
    cleanup.mark_object(sun, 'dynamic_sun', '', 'SCENE', source_uuid=source_uuid)
    scene.collection.objects.link(sun)
    transaction.track_collection_link(scene.collection, sun)
    data.energy = float(settings.sky_sun_energy)
    sun.rotation_euler = (math.radians(45.0), 0.0, math.radians(35.0))
    sun.smart_camlight_object.is_generated_light = True
    return sun


def _defer_remove_world(transaction, world, scene, source_uuid: str) -> None:
    def remove_old_world():
        if not cleanup.is_owned(world, role='dynamic_sky_world', source_uuid=source_uuid):
            return
        if getattr(scene, 'world', None) is world:
            return
        try:
            if int(getattr(world, 'users', 0) or 0) == 0:
                bpy.data.worlds.remove(world)
        except Exception:
            pass

    transaction.defer_commit(remove_old_world)


def dynamic_sun_for_scene(scene):
    """Return the exact Scene-owned companion sun through pointers/index only."""
    if scene is None:
        return None
    settings = _settings(scene=scene)
    return _exact_owned_dynamic_sun(settings, scene)


def _socket_link_matches(input_socket, output_socket) -> bool:
    try:
        return any(
            getattr(link, 'from_socket', None) is output_socket
            and getattr(link, 'to_socket', None) is input_socket
            for link in tuple(getattr(input_socket, 'links', ()) or ())
        )
    except Exception:
        return False


def dynamic_sky_needs_refresh(scene) -> bool:
    """Pure exact-owned comparison used by the finite dirty continuation."""
    if scene is None:
        return False
    settings = _settings(scene=scene)
    if settings is None:
        return False
    world = _exact_owned_dynamic_world(settings, scene)
    if world is None or getattr(scene, 'world', None) is not world:
        return True
    try:
        if not bool(getattr(world, 'use_nodes', False)) or world.node_tree is None:
            return True
        nodes = world.node_tree.nodes
        output = nodes.get('SCLS Dynamic Sky Output')
        background = nodes.get('SCLS Dynamic Sky Background')
        sky = nodes.get('SCLS Dynamic Sky Texture')
        if output is None or background is None or sky is None:
            return True
        if str(getattr(output, 'bl_idname', '') or '') != 'ShaderNodeOutputWorld':
            return True
        if str(getattr(background, 'bl_idname', '') or '') != 'ShaderNodeBackground':
            return True
        if str(getattr(sky, 'bl_idname', '') or '') != 'ShaderNodeTexSky':
            return True
        strength = float(background.inputs['Strength'].default_value)
        if not math.isclose(strength, float(settings.sky_strength), rel_tol=1.0e-7, abs_tol=1.0e-7):
            return True
        if hasattr(sky, 'turbidity') and not math.isclose(float(sky.turbidity), float(settings.sky_turbidity), rel_tol=1.0e-7, abs_tol=1.0e-7):
            return True
        if not _socket_link_matches(background.inputs['Color'], sky.outputs['Color']):
            return True
        if not _socket_link_matches(output.inputs['Surface'], background.outputs['Background']):
            return True
    except Exception:
        return True

    sun = _exact_owned_dynamic_sun(settings, scene)
    if bool(settings.sky_create_sun):
        if sun is None or getattr(sun, 'type', None) != 'LIGHT':
            return True
        data = getattr(sun, 'data', None)
        if data is None or getattr(data, 'type', None) != 'SUN':
            return True
        try:
            if not math.isclose(float(data.energy), float(settings.sky_sun_energy), rel_tol=1.0e-7, abs_tol=1.0e-7):
                return True
        except Exception:
            return True
    elif sun is not None:
        return True
    return False


def create_dynamic_sky(context=None, *, scene=None, settings=None, transaction=None):
    scene = scene or getattr(context, 'scene', None)
    if scene is None:
        return None
    settings = settings or _settings(context, scene=scene)
    if settings is None:
        return None
    own_transaction = transaction is None
    tx = transaction or transactions.DataTransaction('Create Dynamic Sky')
    source_uuid = _dynamic_sky_source_uuid(scene)
    try:
        old_owned_world = _exact_owned_dynamic_world(settings, scene)
        old_owned_sun = _exact_owned_dynamic_sun(settings, scene)
        current_world = getattr(scene, 'world', None)
        previous_world = getattr(settings, 'dynamic_sky_previous_world', None)
        if current_world is not old_owned_world:
            previous_world = current_world

        new_world = _build_owned_dynamic_world(scene, settings, tx)
        new_sun = _build_owned_dynamic_sun(scene, settings, tx) if bool(settings.sky_create_sun) else None

        if not tx.set_attr(settings, 'dynamic_sky_previous_world', previous_world):
            raise RuntimeError('previous world pointer assignment failed')
        if not tx.set_attr(settings, 'dynamic_sky_owned_world', new_world):
            raise RuntimeError('owned world pointer assignment failed')
        if not tx.set_attr(settings, 'dynamic_sky_owned_sun', new_sun):
            raise RuntimeError('owned sun pointer assignment failed')
        if not tx.set_attr(scene, 'world', new_world):
            raise RuntimeError('scene world assignment failed')

        if old_owned_sun is not None and old_owned_sun is not new_sun:
            _defer_remove_objects(tx, (old_owned_sun,))
        if old_owned_world is not None and old_owned_world is not new_world:
            _defer_remove_world(tx, old_owned_world, scene, source_uuid)

        if own_transaction:
            tx.commit()
            _notify_scene_structure_changed(scene)
        return new_world
    except Exception:
        if own_transaction:
            tx.rollback()
            return None
        raise


def refresh_dynamic_sky(scene):
    """Finite refresh of the separate exact-owned World; no user World is edited."""
    if scene is None:
        return None
    settings = _settings(scene=scene)
    if settings is None or not bool(getattr(settings, 'live_dynamic_sky_monitor', False)):
        return None
    return create_dynamic_sky(scene=scene, settings=settings)


def remove_dynamic_sky(context=None, *, scene=None, settings=None, transaction=None) -> bool:
    scene = scene or getattr(context, 'scene', None)
    if scene is None:
        return False
    settings = settings or _settings(context, scene=scene)
    if settings is None:
        return False
    own_transaction = transaction is None
    tx = transaction or transactions.DataTransaction('Remove Dynamic Sky')
    source_uuid = _dynamic_sky_source_uuid(scene)
    try:
        owned_world = _exact_owned_dynamic_world(settings, scene)
        owned_sun = _exact_owned_dynamic_sun(settings, scene)
        previous_world = getattr(settings, 'dynamic_sky_previous_world', None)
        if getattr(scene, 'world', None) is owned_world:
            if not tx.set_attr(scene, 'world', previous_world):
                raise RuntimeError('previous world restoration failed')
        if not tx.set_attr(settings, 'dynamic_sky_owned_world', None):
            raise RuntimeError('owned world pointer clear failed')
        if not tx.set_attr(settings, 'dynamic_sky_owned_sun', None):
            raise RuntimeError('owned sun pointer clear failed')
        if not tx.set_attr(settings, 'dynamic_sky_previous_world', None):
            raise RuntimeError('previous world pointer clear failed')
        if bool(getattr(settings, 'live_dynamic_sky_monitor', False)):
            if not tx.set_attr(settings, 'live_dynamic_sky_monitor', False):
                raise RuntimeError('dynamic sky monitor disable failed')
        if owned_sun is not None:
            _defer_remove_objects(tx, (owned_sun,))
        if owned_world is not None:
            _defer_remove_world(tx, owned_world, scene, source_uuid)
        if own_transaction:
            tx.commit()
            _notify_scene_structure_changed(scene)
        return True
    except Exception:
        if own_transaction:
            tx.rollback()
            return False
        raise


class SCLS_OT_create_dynamic_sky(Operator):
    bl_idname = 'smart_camlight_suite.create_dynamic_sky'
    bl_label = tr.add('Create Dynamic Sky', 'ダイナミックスカイを作成')
    bl_description = tr.add('Create or refresh a separate Smart CamLight-owned procedural World and optional companion sun without changing the previous World node tree.', '変更前のWorldノードツリーを改変せず、Smart CamLight 所有の分離プロシージャルWorldと任意の連動サンを作成または更新します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        return {'FINISHED'} if create_dynamic_sky(context) is not None else {'CANCELLED'}


class SCLS_OT_remove_dynamic_sky(Operator):
    bl_idname = 'smart_camlight_suite.remove_dynamic_sky'
    bl_label = tr.add('Remove Dynamic Sky Nodes', 'ダイナミックスカイノードを削除')
    bl_description = tr.add('Restore the exact World assigned before Smart CamLight Dynamic Sky, then remove only the separate World and sun owned by this Scene.', 'Smart CamLight ダイナミックスカイ作成前の正確なWorld割り当てを復元し、このSceneが所有する分離Worldとサンだけを削除します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        return {'FINISHED'} if remove_dynamic_sky(context) else {'CANCELLED'}


class SCLS_OT_init_light_linking(Operator):
    bl_idname = 'smart_camlight_suite.init_light_linking'
    bl_label = tr.add('Initialize Light Linking', 'ライトリンキングを初期化')
    bl_description = tr.add('Create Blender receiver and blocker collections for the selected light so light linking and shadow linking can be edited from the Smart CamLight panel.', '選択ライト用のBlender受光/遮光コレクションを作成し、Smart CamLight パネルからライトリンキングとシャドウリンキングを編集できるようにします。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        tx = transactions.DataTransaction('Initialize Light Linking')
        try:
            receiver = _ensure_link_collection(context, light, 'RECEIVER', transaction=tx)
            blocker = _ensure_link_collection(context, light, 'BLOCKER', transaction=tx)
            if receiver is None or blocker is None:
                raise RuntimeError('light linking collection creation failed')
            tx.commit()
        except Exception:
            tx.rollback()
            return {'CANCELLED'}
        return {'FINISHED'}


class SCLS_OT_add_selected_to_linking(Operator):
    bl_idname = 'smart_camlight_suite.add_selected_to_linking'
    bl_label = tr.add('Add Selected to Linking', '選択をリンキングへ追加')
    bl_description = tr.add('Add selected non-light objects to the selected light receiver or blocker collection, then expose their visibility and viewport-display settings in the panel.', '選択中の非ライトオブジェクトを選択ライトの受光または遮光コレクションに追加し、パネルで可視性とビューポート表示設定を扱えるようにします。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()
    kind: _link_kind_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light:
            return {'CANCELLED'}
        count = 0
        for obj in list(context.selected_objects):
            if obj != light and obj.type != 'LIGHT':
                if _add_obj_to_link_collection(context, light, obj, self.kind, 'INCLUDE'):
                    count += 1
        _report(self, 'INFO', f'Added {count} objects to linking.', f'リンキングへオブジェクトを{count}件追加しました。', context)
        return {'FINISHED'}


class SCLS_OT_remove_linked_object(Operator):
    bl_idname = 'smart_camlight_suite.remove_linked_object'
    bl_label = tr.add('Remove Linked Object', 'リンク済みオブジェクトを削除')
    bl_description = tr.add('Remove one object from the selected light receiver or blocker collection without deleting the object from the scene.', 'シーンからオブジェクト自体を削除せず、選択ライトの受光または遮光コレクションから1つのオブジェクトを外します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()
    object_name: _linked_object_name_property()
    kind: _link_kind_property()

    def execute(self, context):
        light = _get_light(context, self.light_name)
        return {'FINISHED'} if _remove_obj_from_link_collection(light, self.object_name, self.kind) else {'CANCELLED'}


class SCLS_OT_select_linked_object(Operator):
    bl_idname = 'smart_camlight_suite.select_linked_object'
    bl_label = tr.add('Select Linked Object', 'リンク済みオブジェクトを選択')
    bl_description = tr.add('Select one object from the light or shadow linking list and make its visibility and viewport-display settings active in the panel.', 'ライトまたはシャドウリンキングリストから1つのオブジェクトを選択し、可視性とビューポート表示設定をパネルでアクティブにします。')
    bl_options = {'UNDO'}

    object_name: _linked_object_name_property()

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            return {'CANCELLED'}
        settings = _settings(context)
        if settings:
            settings.active_linked_object_name = obj.name
        _select_object(context, obj)
        return {'FINISHED'}


class SCLS_OT_set_link_state(Operator):
    bl_idname = 'smart_camlight_suite.set_link_state'
    bl_label = tr.add('Set Link State', 'リンク状態を設定')
    bl_description = tr.add('Set one linked object to Include or Exclude in the selected light receiver or blocker collection.', '選択ライトの受光または遮光コレクション内の1オブジェクトを含める/除外へ設定します。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()
    object_name: _linked_object_name_property()
    kind: _link_kind_property()
    state: EnumProperty(
        name=tr.add('Link State', 'リンク状態'),
        description=tr.add('Choose whether this object is included in or excluded from the selected Blender linking collection.', 'このオブジェクトを選択したBlenderリンキングコレクションへ含めるか除外するかを選択します。'),
        items=[
            ('INCLUDE', tr.add('Include', '含める'), tr.add('Include this object in the selected linking collection.', 'このオブジェクトを選択リンキングコレクションへ含めます。')),
            ('EXCLUDE', tr.add('Exclude', '除外'), tr.add('Exclude this object from the selected linking collection when supported by Blender.', 'Blenderが対応している場合、このオブジェクトを選択リンキングコレクションから除外します。')),
        ],
        default='INCLUDE',
    )

    def execute(self, context):
        light = _get_light(context, self.light_name)
        return {'FINISHED'} if _set_link_state(light, self.object_name, self.kind, self.state) else {'CANCELLED'}


class SCLS_OT_clear_light_linking(Operator):
    bl_idname = 'smart_camlight_suite.clear_light_linking'
    bl_label = tr.add('Clear Light Linking', 'ライトリンキングをクリア')
    bl_description = tr.add('Unassign and optionally keep the receiver or blocker collection for the selected light. Objects are not deleted.', '選択ライトの受光または遮光コレクションの割り当てを解除します。オブジェクトは削除しません。')
    bl_options = {'UNDO'}

    light_name: _light_name_property()
    kind: _link_kind_property(include_both=True)

    def execute(self, context):
        light = _get_light(context, self.light_name)
        if not light or not hasattr(light, 'light_linking'):
            return {'CANCELLED'}
        ll = light.light_linking
        if self.kind in {'RECEIVER', 'BOTH'}:
            _set_if_exists(ll, 'receiver_collection', None)
        if self.kind in {'BLOCKER', 'BOTH'}:
            _set_if_exists(ll, 'blocker_collection', None)
        return {'FINISHED'}


class SCLS_OT_clean_linking_collections(Operator):
    bl_idname = 'smart_camlight_suite.clean_linking_collections'
    bl_label = tr.add('Clean Linking Collections', 'リンキングコレクションを整理')
    bl_description = tr.add('Remove empty Smart CamLight light-linking and shadow-linking collections that are no longer assigned to any indexed light.', '索引済みライトへ割り当てられていない空のSmart CamLight ライト/シャドウリンクコレクションだけを削除します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        assigned_ids = set()
        known_light_uuids = set()
        for scene in tuple(getattr(bpy.data, 'scenes', ()) or ()):
            index = scene_index.get_index(scene)
            if index is None:
                continue
            for light in index.lights:
                light_uuid = scene_index.persistent_uuid(light, 'OBJECT', ensure=False)
                if light_uuid:
                    known_light_uuids.add(light_uuid)
                ll = getattr(light, 'light_linking', None)
                if ll is None:
                    continue
                for attr in ('receiver_collection', 'blocker_collection'):
                    coll = getattr(ll, attr, None)
                    if coll is not None:
                        assigned_ids.add(id(coll))
        count = 0
        for coll in tuple(getattr(bpy.data, 'collections', ()) or ()):
            if not cleanup.is_owned(coll, role='link_collection') or id(coll) in assigned_ids:
                continue
            try:
                source_uuid = str(coll.get(cleanup.SOURCE_UUID_KEY, '') or '')
            except Exception:
                source_uuid = ''
            # Conservative behavior: without a currently indexed source light,
            # ownership cannot prove that an off-scene user still does not use
            # the collection, so preserve it.
            if not source_uuid or source_uuid not in known_light_uuids:
                continue
            try:
                empty = not coll.objects and not coll.children
            except Exception:
                empty = False
            if empty:
                try:
                    bpy.data.collections.remove(coll)
                    count += 1
                except Exception:
                    pass
        _report(self, 'INFO', f'Cleaned {count} collections.', f'リンキングコレクションを{count}件整理しました。', context)
        return {'FINISHED'}


class SCLS_OT_set_emission_strength(Operator):
    bl_idname = 'smart_camlight_suite.set_emission_strength'
    bl_label = tr.add('Set Selected Emission Strength', '選択発光強度を設定')
    bl_description = tr.add('Set emission strength on Principled BSDF materials of selected mesh objects so mesh softboxes can be tuned from the light workflow.', '選択メッシュオブジェクトのPrincipled BSDFマテリアル発光強度を設定し、メッシュソフトボックスをライトワークフローから調整します。')
    bl_options = {'UNDO'}

    strength: FloatProperty(
        name=tr.add('Strength', '強度'),
        description=tr.add('Set Principled BSDF emission strength on every material assigned to selected mesh objects. Materials without a Principled BSDF node are skipped.', '選択メッシュオブジェクトへ割り当てられた全マテリアルのPrincipled BSDF発光強度を設定します。Principled BSDFノードがないマテリアルはスキップします。'),
        default=2.0,
        min=0.0,
        max=1000.0,
    )

    def invoke(self, context, event):
        window_manager = getattr(context, 'window_manager', None)
        if window_manager is None:
            return {'CANCELLED'}
        return window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        self.layout.prop(self, 'strength')

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            if obj.type != 'MESH' or not obj.data:
                continue
            for mat in obj.data.materials:
                if not mat or not mat.use_nodes or not mat.node_tree:
                    continue
                bsdf = next((node for node in mat.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'), None)
                if not bsdf:
                    continue
                if 'Emission Strength' in bsdf.inputs:
                    bsdf.inputs['Emission Strength'].default_value = float(self.strength)
                    count += 1
        _report(self, 'INFO', f'Updated {count} materials.', f'マテリアルを{count}件更新しました。', context)
        return {'FINISHED'}


CLASSES = (
    SCLS_OT_toggle_ui_section,
    SCLS_OT_open_help,
    SCLS_OT_select_camera,
    SCLS_OT_add_camera,
    SCLS_OT_delete_camera,
    SCLS_OT_apply_camera_settings,
    SCLS_OT_apply_all_camera_settings,
    SCLS_OT_swap_resolution,
    SCLS_OT_add_marker_bind_camera,
    SCLS_OT_refresh_marker_camera,
    SCLS_OT_create_camera_rig,
    SCLS_OT_set_dof_to_selected,
    SCLS_OT_create_path_from_camera_keys,
    SCLS_OT_bake_camera_transform,
    SCLS_OT_create_camera_guides,
    SCLS_OT_remove_camera_guides,
    SCLS_OT_apply_overscan,
    SCLS_OT_revert_overscan,
    SCLS_OT_refresh_motion_blur,
    SCLS_OT_prepare_review_stamps,
    SCLS_OT_render_camera,
    SCLS_OT_create_pov_camera_text,
    SCLS_OT_apply_aspect_preset,
    SCLS_OT_insert_camera_key,
    SCLS_OT_camera_fly_view,
    SCLS_OT_clear_camera_rigs,
    SCLS_OT_render_all_cameras,
    SCLS_OT_select_light,
    SCLS_OT_add_light,
    SCLS_OT_delete_light,
    SCLS_OT_toggle_light_lock,
    SCLS_OT_toggle_light_visibility,
    SCLS_OT_all_light_visibility,
    SCLS_OT_isolate_light,
    SCLS_OT_mirror_light,
    SCLS_OT_create_light_target,
    SCLS_OT_generate_lights,
    SCLS_OT_clear_generated_lights,
    SCLS_OT_apply_studio_preset,
    SCLS_OT_create_softbox,
    SCLS_OT_create_dynamic_sky,
    SCLS_OT_remove_dynamic_sky,
    SCLS_OT_init_light_linking,
    SCLS_OT_add_selected_to_linking,
    SCLS_OT_remove_linked_object,
    SCLS_OT_select_linked_object,
    SCLS_OT_set_link_state,
    SCLS_OT_clear_light_linking,
    SCLS_OT_clean_linking_collections,
    SCLS_OT_set_emission_strength,
)


def register() -> None:
    try:
        status_runtime.prepare_operator_classes(CLASSES)
    except Exception as exc:
        # Auxiliary status instrumentation and its audit recorder are both
        # non-critical; neither may abort registration of the original classes.
        try:
            status_runtime.record_preparation_safe_degradation(CLASSES, exc)
        except Exception:
            pass
    for cls in CLASSES:
        # Registered exact RNA is left untouched and treated as already current.
        if lifecycle.class_identity_live(cls):
            try:
                status_runtime.note_already_current_operator(cls)
            except Exception:
                pass
            continue
        try:
            lifecycle.register_class(cls, resource_key=f'operator_class:{cls.__name__}')
        except Exception:
            # Only an exact same-class registration race degrades to a no-op.
            # Unrelated registration errors remain visible to rollback.
            if lifecycle.class_identity_live(cls):
                try:
                    status_runtime.note_already_current_operator(cls, phase='register_race')
                except Exception:
                    pass
                continue
            raise


def unregister() -> None:
    # Exact reverse release is centralized in lifecycle.unregister_generation().
    return None
