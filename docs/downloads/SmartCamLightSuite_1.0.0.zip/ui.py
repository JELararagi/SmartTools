# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import bpy

from . import lifecycle, manager_bridge, operators, scene_index, translation as tr
from .properties import get_settings

_PANEL_CATEGORY = 'Smart CamLight'

_SECTION_DEFS = (
    ('ui_section_always_on', 'Always-on Toggles', '常時機能切り替え', 'TIME', 'always_on'),
    ('ui_section_camera', 'Camera', 'カメラ', 'CAMERA_DATA', 'camera'),
    ('ui_section_light', 'Light', 'ライト', 'LIGHT', 'light'),
)


def _t(en: str, ja: str, context=None) -> str:
    return tr.t(en, ja, context)


def _settings(context):
    return get_settings(context)


def _safe_icon(name: str, default='NONE') -> str:
    value = str(name or '').strip() or default
    try:
        # Defer to Blender; invalid icons are caught during draw.
        return value
    except Exception:
        return default


def _set_operator_props(op, **props) -> None:
    if op is None:
        return
    for key, value in props.items():
        try:
            setattr(op, key, value)
        except Exception:
            pass


def _operator(layout, op_id: str, *, text: str = '', icon: str = 'NONE', **props):
    try:
        op = layout.operator(op_id, text=text, icon=_safe_icon(icon))
    except Exception:
        op = layout.operator(op_id, text=text)
    _set_operator_props(op, **props)
    return op


def _help_button(layout, topic: str, context) -> None:
    try:
        op = layout.operator('smart_camlight_suite.open_help', text='', icon='QUESTION')
    except Exception:
        op = layout.operator('smart_camlight_suite.open_help', text='?')
    _set_operator_props(op, topic=topic)


def _section_expanded(settings, prop: str, default=False) -> bool:
    try:
        return bool(getattr(settings, prop, default))
    except Exception:
        return bool(default)


def _draw_section_header(layout, context, settings, show_prop: str, en: str, ja: str, *, icon='TOOL_SETTINGS', topic='overview', container=None):
    expanded = _section_expanded(settings, show_prop, False)
    label = _t(en, ja, context)
    box = container if container is not None else layout.box()
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    tri_icon = 'TRIA_DOWN' if expanded else 'TRIA_RIGHT'
    op = row.operator('smart_camlight_suite.toggle_ui_section', text='', icon=tri_icon, emboss=True, depress=expanded)
    _set_operator_props(op, section_key=show_prop)
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    op = row.operator('smart_camlight_suite.toggle_ui_section', text=label, icon=_safe_icon(icon, 'TOOL_SETTINGS'), emboss=False, depress=expanded)
    _set_operator_props(op, section_key=show_prop)
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    help_row = row.row(align=True)
    help_row.scale_x = 0.82
    _help_button(help_row, topic, context)
    return box, expanded


def _draw_foldout(layout, settings, prop: str, en: str, ja: str, context, *, icon='TOOL_SETTINGS', topic='overview'):
    label = _t(en, ja, context)
    try:
        header, body = layout.panel_prop(settings, prop)
    except Exception:
        owner_key = 0
        try:
            owner_key = int(settings.as_pointer())
        except Exception:
            owner_key = id(settings)
        header, body = layout.panel(
            idname=f'smart_camlight_child_{prop}_{owner_key}',
            default_closed=not _section_expanded(settings, prop, False),
        )
    header.label(text=label, icon=_safe_icon(icon, 'TOOL_SETTINGS'))
    right = header.row(align=True)
    right.alignment = 'RIGHT'
    _help_button(right, topic, context)
    return (body if body is not None else layout), body is not None


def _prop_if(layout, owner, prop: str, en: str | None = None, ja: str | None = None, context=None, **kw) -> bool:
    try:
        if owner is None or not hasattr(owner, prop):
            return False
        text = kw.pop('text', None)
        if text is None and en is not None and ja is not None:
            text = _t(en, ja, context)
        elif text is None:
            text = ''
        layout.prop(owner, prop, text=text, **kw)
        return True
    except Exception:
        return False


def _camera_list(context, settings):
    cams = list(scene_index.camera_objects_for_draw(context.scene))
    if settings and settings.show_custom_cameras_only:
        cams = [obj for obj in cams if getattr(obj.data.smart_camlight_settings, 'enable_custom_settings', False)]
    cams.sort(key=lambda obj: obj.name.lower())
    return cams


def _light_list(context, settings):
    lights = list(scene_index.light_objects_for_draw(context.scene))
    if settings and settings.show_generated_lights_only:
        lights = [obj for obj in lights if getattr(obj.smart_camlight_object, 'is_generated_light', False)]
    lights.sort(key=lambda obj: obj.name.lower())
    return lights


def _selected_camera(context, settings):
    if settings and settings.active_camera_name:
        obj = context.scene.objects.get(settings.active_camera_name)
        if obj and obj.type == 'CAMERA':
            return obj
    obj = getattr(context, 'active_object', None)
    if obj and obj.type == 'CAMERA':
        return obj
    cam = getattr(context.scene, 'camera', None)
    if cam and cam.type == 'CAMERA':
        return cam
    cams = _camera_list(context, settings)
    return cams[0] if cams else None


def _selected_light(context, settings):
    if settings and settings.active_light_name:
        obj = context.scene.objects.get(settings.active_light_name)
        if obj and obj.type == 'LIGHT':
            return obj
    obj = getattr(context, 'active_object', None)
    if obj and obj.type == 'LIGHT':
        return obj
    lights = _light_list(context, settings)
    return lights[0] if lights else None


def _draw_always_on_body(layout, context, settings) -> None:
    col = layout.column(align=True)
    toggles = (
        ('n_panel_state_save', 'N-panel State Save', 'Nパネル状態保存'),
        ('auto_active_camera', 'Auto Active Camera', '自動アクティブカメラ'),
        ('live_per_camera_sync', 'Live Per-Camera Sync', 'カメラ別設定の常時同期'),
        ('live_marker_camera_switch', 'Timeline Marker Camera Switch', 'タイムラインマーカーでカメラ切替'),
        ('live_motion_blur_sync', 'Live Physical Motion Blur', '物理モーションブラー常時同期'),
        ('live_light_link_monitor', 'Light Linking Monitor', 'ライトリンク監視'),
        ('live_dynamic_sky_monitor', 'Dynamic Sky Monitor', 'ダイナミックスカイ監視'),
        ('live_proxy_maintenance', 'Automatic Proxy Maintenance', 'プロキシ自動メンテナンス'),
    )
    for index, (prop, en, ja) in enumerate(toggles):
        if not hasattr(settings, prop):
            continue
        enabled = bool(getattr(settings, prop))
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=_t(en, ja, context))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.row(align=True).prop(
            settings,
            prop,
            text=_t('Enabled', '有効', context) if enabled else _t('Disabled', '無効', context),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
        if index == 0:
            col.separator(factor=0.5)


def _draw_camera_list(layout, context, settings) -> None:
    box = layout.box()
    row = box.row(align=True)
    row.label(text=_t('Scene Cameras', 'シーン内カメラ', context), icon='CAMERA_DATA')
    row.operator('smart_camlight_suite.add_camera', text='', icon='ADD')
    row.prop(settings, 'show_custom_cameras_only', text='', icon='FILTER')
    cams = _camera_list(context, settings)
    if not cams:
        if scene_index.get_index(context.scene) is None:
            message = _t('Loading scene cameras…', 'シーン内カメラを読み込み中…', context)
        elif settings.show_custom_cameras_only:
            message = _t('No custom cameras match the filter.', 'フィルターに一致するカスタムカメラがありません。', context)
        else:
            message = _t('No camera exists in this scene.', 'このシーンにカメラが存在しません。', context)
        box.label(text=message, icon='NONE')
        return
    active_name = settings.active_camera_name if settings else ''
    scene_cam = getattr(context.scene, 'camera', None)
    for cam in cams:
        cset = cam.data.smart_camlight_settings
        row = box.row(align=True)
        is_active = cam.name == active_name or cam == scene_cam
        op = row.operator('smart_camlight_suite.select_camera', text=cam.name, translate=False, icon='CAMERA_DATA', depress=is_active)
        _set_operator_props(op, camera_name=cam.name, make_scene_camera=True, apply_settings=False)
        row.prop(cset, 'enable_custom_settings', text='')
        op = row.operator('smart_camlight_suite.apply_camera_settings', text='', icon='CHECKMARK')
        _set_operator_props(op, camera_name=cam.name, apply_overscan=True)
        if cam == scene_cam:
            row.label(text='', icon='SCENE_DATA')
        else:
            op = row.operator('smart_camlight_suite.select_camera', text='', icon='RESTRICT_SELECT_OFF')
            _set_operator_props(op, camera_name=cam.name, make_scene_camera=True, apply_settings=False)
        op = row.operator('smart_camlight_suite.delete_camera', text='', icon='TRASH')
        _set_operator_props(op, camera_name=cam.name)


def _draw_camera_data(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_camera_data', 'Camera Data', 'カメラデータ', context, icon='CAMERA_DATA', topic='camera_data')
    if not expanded:
        return
    col = box.column(align=True)
    _prop_if(col, cam, 'name', 'Object Name', 'オブジェクト名', context)
    row = col.row(align=True)
    row.prop(cam, 'location', text=_t('Location', '位置', context))
    row = col.row(align=True)
    row.prop(cam, 'rotation_euler', text=_t('Rotation', '回転', context))
    _prop_if(col, cam, 'scale', 'Scale', 'スケール', context)
    data = cam.data
    col.separator()
    _prop_if(col, data, 'type', 'Type', 'タイプ', context)
    _prop_if(col, data, 'lens', 'Focal Length', '焦点距離', context)
    _prop_if(col, data, 'angle', 'Angle', '画角', context)
    _prop_if(col, data, 'sensor_width', 'Sensor Width', 'センサー幅', context)
    _prop_if(col, data, 'sensor_height', 'Sensor Height', 'センサー高さ', context)
    _prop_if(col, data, 'sensor_fit', 'Sensor Fit', 'センサーフィット', context)
    row = col.row(align=True)
    _prop_if(row, data, 'shift_x', 'Shift X', 'シフトX', context)
    _prop_if(row, data, 'shift_y', 'Shift Y', 'シフトY', context)
    row = col.row(align=True)
    _prop_if(row, data, 'clip_start', 'Clip Start', 'クリップ開始', context)
    _prop_if(row, data, 'clip_end', 'Clip End', 'クリップ終了', context)
    _prop_if(col, data, 'display_size', 'Display Size', '表示サイズ', context)
    dof = getattr(data, 'dof', None)
    if dof:
        sub = col.box()
        sub.label(text=_t('Depth of Field', '被写界深度', context), icon='VIEWZOOM')
        _prop_if(sub, dof, 'use_dof', 'Use DOF', 'DOFを使用', context)
        _prop_if(sub, dof, 'focus_object', 'Focus Object', 'フォーカスオブジェクト', context)
        _prop_if(sub, dof, 'focus_distance', 'Focus Distance', 'フォーカス距離', context)
        _prop_if(sub, dof, 'aperture_fstop', 'F-Stop', 'F値', context)
        _prop_if(sub, dof, 'aperture_blades', 'Blades', '絞り羽根', context)
        op = sub.operator('smart_camlight_suite.set_dof_to_selected', text=_t('Set DOF to Selected Object', 'DOFを選択オブジェクトに設定', context), icon='EYEDROPPER')
        _set_operator_props(op, camera_name=cam.name)


def _draw_camera_resolution(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_resolution_settings', 'Resolution', '解像度', context, icon='RENDER_STILL', topic='resolution')
    if not expanded:
        return
    col = box.column(align=True)
    row = col.row(align=True)
    row.prop(cset, 'resolution_x', text=_t('Width', '幅', context))
    row.prop(cset, 'resolution_y', text=_t('Height', '高さ', context))
    col.prop(cset, 'resolution_percentage', text=_t('Scale', 'スケール', context))
    row = col.row(align=True)
    row.prop(cset, 'pixel_aspect_x', text=_t('Pixel Aspect X', 'ピクセル比率X', context))
    row.prop(cset, 'pixel_aspect_y', text=_t('Pixel Aspect Y', 'ピクセル比率Y', context))
    op = col.operator('smart_camlight_suite.swap_resolution', text=_t('Swap Resolution', '解像度を入れ替え', context), icon='ARROW_LEFTRIGHT')
    _set_operator_props(op, camera_name=cam.name)
    preset_box = col.box()
    preset_box.label(text=_t('Aspect Presets', '縦横比プリセット', context), icon='PRESET')
    row = preset_box.row(align=True)
    for preset, label in (('HD_16_9', '16:9'), ('VERTICAL_9_16', '9:16'), ('SQUARE_1_1', '1:1')):
        op = row.operator('smart_camlight_suite.apply_aspect_preset', text=label)
        _set_operator_props(op, camera_name=cam.name, preset=preset)
    row = preset_box.row(align=True)
    for preset, label in (('CINEMA_239', '2.39:1'), ('FOUR_THREE', '4:3')):
        op = row.operator('smart_camlight_suite.apply_aspect_preset', text=label)
        _set_operator_props(op, camera_name=cam.name, preset=preset)


def _draw_camera_frame_range(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_frame_range', 'Frame Range', 'フレーム範囲', context, icon='TIME', topic='frame_range')
    if not expanded:
        return
    col = box.column(align=True)
    col.prop(cset, 'frame_range_mode', text=_t('Frame Range Mode', 'フレーム範囲モード', context))
    if cset.frame_range_mode == 'PER_CAMERA':
        row = col.row(align=True)
        row.prop(cset, 'frame_start', text=_t('Start', '開始', context))
        row.prop(cset, 'frame_end', text=_t('End', '終了', context))
        col.prop(cset, 'frame_step', text=_t('Step', 'ステップ', context))
        col.prop(cset, 'sync_frame_range', text=_t('Sync Timeline Range', 'タイムライン範囲を同期', context))
    else:
        ranges = operators._timeline_ranges_for_camera(context.scene, cam)
        if ranges:
            for idx, (start, end) in enumerate(ranges, 1):
                col.label(text=f'{_t("Frame Range", "フレーム範囲", context)} {idx}: {start} - {end}', icon='MARKER')
        else:
            col.label(text=_t('No timeline camera markers are bound to this camera.', 'このカメラにバインドされたタイムラインカメラマーカーがありません。'), icon='NONE')
    row = col.row(align=True)
    op = row.operator('smart_camlight_suite.add_marker_bind_camera', text=_t('Add Marker and Bind Camera', 'マーカーを追加してカメラにバインド', context), icon='MARKER')
    _set_operator_props(op, camera_name=cam.name)
    row.operator('smart_camlight_suite.refresh_marker_camera', text='', icon='FILE_REFRESH')


def _draw_camera_output(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_file_output', 'File Output', 'ファイル出力', context, icon='FILE_FOLDER', topic='file_output')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'output_path', text=_t('Output Path', '出力パス', context))
        col.prop(cset, 'output_subfolder', text=_t('Subfolder', 'サブフォルダー', context))
        col.prop(cset, 'output_filename', text=_t('File Name', 'ファイル名', context))
        col.prop(cset, 'include_camera_name', text=_t('Include Camera Name', 'カメラ名を含める', context))
        col.prop(cset, 'overwrite_existing', text=_t('Overwrite Existing Files', '既存ファイルを上書き', context))
    box, expanded = _draw_foldout(layout, cset, 'show_format_settings', 'File Format', 'ファイル形式', context, icon='OUTPUT', topic='file_format')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'output_format', text=_t('Format', '形式', context))
        fmt = cset.output_format
        if fmt == 'PNG':
            col.prop(cset, 'png_color_depth', text=_t('PNG Color Depth', 'PNG色深度', context))
            col.prop(cset, 'png_compression', text=_t('PNG Compression', 'PNG圧縮', context))
        elif fmt == 'JPEG':
            col.prop(cset, 'jpeg_quality', text=_t('JPEG Quality', 'JPEG品質', context))
        elif fmt == 'OPEN_EXR':
            col.prop(cset, 'exr_color_depth', text=_t('EXR Color Depth', 'EXR色深度', context))
            col.prop(cset, 'exr_codec', text=_t('EXR Codec', 'EXRコーデック', context))
            col.prop(cset, 'exr_preview', text=_t('Save EXR Preview', 'EXRプレビューを保存', context))
        else:
            col.prop(cset, 'video_quality', text=_t('Video Quality', '動画品質', context))
            col.prop(cset, 'video_bitrate', text=_t('Video Bitrate', '動画ビットレート', context))
            col.prop(cset, 'video_gopsize', text=_t('GOP Size', 'GOPサイズ', context))
            col.prop(cset, 'use_audio', text=_t('Include Audio', '音声を含める', context))
            if cset.use_audio:
                col.prop(cset, 'audio_codec', text=_t('Audio Codec', '音声コーデック', context))
                col.prop(cset, 'audio_bitrate', text=_t('Audio Bitrate', '音声ビットレート', context))
        col.prop(cset, 'film_transparent', text=_t('Transparent Film', '透過フィルム', context))
        col.prop(cset, 'burn_metadata', text=_t('Enable Burn-In Metadata', '焼き込みメタデータを有効化', context))


def _draw_camera_guides(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_guides', 'Composition Guides', '構図ガイド', context, icon='GRID', topic='guides')
    if not expanded:
        return
    col = box.column(align=True)
    col.prop(cset, 'guide_thirds', text=_t('Rule of Thirds', '三分割法', context))
    col.prop(cset, 'guide_center', text=_t('Center Cross', '中央十字', context))
    col.prop(cset, 'guide_safe_area', text=_t('Safe Area', 'セーフエリア', context))
    col.prop(cset, 'guide_safe_percentage', text=_t('Safe Area Percentage', 'セーフエリア比率', context))
    col.prop(cset, 'guide_line_style', text=_t('Guide Line Style', 'ガイド線スタイル', context))
    col.prop(cset, 'guide_line_width', text=_t('Guide Line Width', 'ガイド線幅', context))
    col.prop(cset, 'guide_color', text=_t('Guide Color', 'ガイド色', context))
    col.prop(cset, 'guide_render_enabled', text=_t('Render Guides', 'ガイドをレンダー表示', context))
    row = col.row(align=True)
    op = row.operator('smart_camlight_suite.create_camera_guides', text=_t('Create', '作成', context), icon='ADD')
    _set_operator_props(op, camera_name=cam.name)
    op = row.operator('smart_camlight_suite.remove_camera_guides', text=_t('Remove', '削除', context), icon='TRASH')
    _set_operator_props(op, camera_name=cam.name)


def _draw_camera_rig_review(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_rig', 'Camera Rig', 'カメラリグ', context, icon='CONSTRAINT', topic='rig')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'rig_type', text=_t('Rig Type', 'リグタイプ', context))
        col.prop(cset, 'rig_target_distance', text=_t('Target Distance', 'ターゲット距離', context))
        col.prop(cset, 'rig_target_size', text=_t('Target Size', 'ターゲットサイズ', context))
        col.prop(cset, 'rig_create_dof', text=_t('Use Target for DOF', 'ターゲットをDOFに使用', context))
        row = col.row(align=True)
        op = row.operator('smart_camlight_suite.create_camera_rig', text=_t('Create Camera Rig', 'カメラリグを作成', context), icon='OUTLINER_OB_EMPTY')
        _set_operator_props(op, camera_name=cam.name)
        op = row.operator('smart_camlight_suite.create_path_from_camera_keys', text='', icon='CURVE_PATH')
        _set_operator_props(op, camera_name=cam.name)
        row = col.row(align=True)
        op = row.operator('smart_camlight_suite.insert_camera_key', text=_t('Insert Camera Key', 'カメラキーを挿入', context), icon='KEY_HLT')
        _set_operator_props(op, camera_name=cam.name)
        op = row.operator('smart_camlight_suite.camera_fly_view', text=_t('Start Camera Fly View', 'カメラフライビューを開始', context), icon='VIEW_CAMERA')
        _set_operator_props(op, camera_name=cam.name)
        op = col.operator('smart_camlight_suite.bake_camera_transform', text=_t('Bake Camera Transform', 'カメラトランスフォームをベイク', context), icon='KEY_HLT')
        _set_operator_props(op, camera_name=cam.name)
        col.operator('smart_camlight_suite.clear_camera_rigs', text=_t('Clear Smart Camera Rigs', 'Smart カメラリグをクリア', context), icon='TRASH')
    box, expanded = _draw_foldout(layout, cset, 'show_review', 'Animation Review', 'アニメーションレビュー', context, icon='RENDER_ANIMATION', topic='review')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'review_use_stamp', text=_t('Use Review Stamps', 'レビュースタンプを使用', context))
        col.prop(cset, 'review_stamp_camera', text=_t('Stamp Camera Name', 'カメラ名をスタンプ', context))
        col.prop(cset, 'review_stamp_frame', text=_t('Stamp Frame', 'フレームをスタンプ', context))
        col.prop(cset, 'review_stamp_scene', text=_t('Stamp Scene', 'シーン名をスタンプ', context))
        col.prop(cset, 'review_resolution_percentage', text=_t('Review Scale', 'レビュースケール', context))
        row = col.row(align=True)
        op = row.operator('smart_camlight_suite.prepare_review_stamps', text=_t('Prepare Review Stamps', 'レビュースタンプを準備', context), icon='TEXT')
        _set_operator_props(op, camera_name=cam.name)
        op = row.operator('smart_camlight_suite.render_camera', text=_t('Viewport', 'ビューポート', context), icon='RENDER_ANIMATION')
        _set_operator_props(op, camera_name=cam.name, mode='VIEWPORT', animation=True)


def _draw_camera_overscan_motion_pov(layout, context, cam) -> None:
    cset = cam.data.smart_camlight_settings
    box, expanded = _draw_foldout(layout, cset, 'show_overscan', 'Overscan', 'オーバースキャン', context, icon='FULLSCREEN_ENTER', topic='overscan')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'overscan_enable', text=_t('Enable Overscan', 'オーバースキャンを有効化', context))
        col.prop(cset, 'overscan_mode', text=_t('Overscan Mode', 'オーバースキャンモード', context))
        if cset.overscan_mode == 'PERCENT':
            col.prop(cset, 'overscan_percentage', text=_t('Overscan Percentage', 'オーバースキャン比率', context))
        elif cset.overscan_mode == 'PIXELS':
            col.prop(cset, 'overscan_extra_pixels', text=_t('Extra Pixels', '追加ピクセル', context))
        else:
            row = col.row(align=True)
            row.prop(cset, 'overscan_specific_x', text=_t('Specific Width', '指定幅', context))
            row.prop(cset, 'overscan_specific_y', text=_t('Specific Height', '指定高さ', context))
        row = col.row(align=True)
        op = row.operator('smart_camlight_suite.apply_overscan', text=_t('Apply', '適用', context), icon='CHECKMARK')
        _set_operator_props(op, camera_name=cam.name)
        row.operator('smart_camlight_suite.revert_overscan', text=_t('Revert Overscan', 'オーバースキャンを戻す', context), icon='LOOP_BACK')
    box, expanded = _draw_foldout(layout, cset, 'show_motion_blur', 'Physical Motion Blur', '物理モーションブラー', context, icon='MOD_TIME', topic='motion_blur')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'motion_blur_enable', text=_t('Enable Physical Motion Blur', '物理モーションブラーを有効化', context))
        col.prop(cset, 'motion_blur_mode', text=_t('Motion Blur Mode', 'モーションブラーモード', context))
        if cset.motion_blur_mode == 'SHUTTER_SPEED':
            col.prop(cset, 'shutter_speed', text=_t('Shutter Speed', 'シャッタースピード', context))
        else:
            col.prop(cset, 'shutter_angle', text=_t('Shutter Angle', 'シャッター角', context))
        op = col.operator('smart_camlight_suite.refresh_motion_blur', text=_t('Refresh Motion Blur', 'モーションブラーを更新', context), icon='FILE_REFRESH')
        _set_operator_props(op, camera_name=cam.name)
    box, expanded = _draw_foldout(layout, cset, 'show_pov', 'POV Export Helper', 'POV書き出し補助', context, icon='TEXT', topic='pov')
    if expanded:
        col = box.column(align=True)
        col.prop(cset, 'pov_note', text=_t('POV Note', 'POVメモ', context))
        col.prop(cset, 'pov_export_depth', text=_t('Include Depth of Field in POV Text', 'POVテキストにDOFを含める', context))
        op = col.operator('smart_camlight_suite.create_pov_camera_text', text=_t('Create POV Camera Text', 'POVカメラテキストを作成', context), icon='TEXT')
        _set_operator_props(op, camera_name=cam.name)


def _draw_selected_camera(layout, context, settings) -> None:
    cam = _selected_camera(context, settings)
    box = layout.box()
    box.label(text=_t('Selected Camera', '選択中カメラ', context), icon='CAMERA_DATA')
    if not cam:
        box.label(text=_t('No camera exists in this scene.', 'このシーンにカメラが存在しません。'), icon='NONE')
        return
    cset = cam.data.smart_camlight_settings
    row = box.row(align=True)
    row.label(text=cam.name, icon='CAMERA_DATA', translate=False)
    if cam == context.scene.camera:
        row.label(text='', icon='SCENE_DATA')
    row.prop(cset, 'enable_custom_settings', text='')
    row = box.row(align=True)
    op = row.operator('smart_camlight_suite.apply_camera_settings', text=_t('Apply', '適用', context), icon='CHECKMARK')
    _set_operator_props(op, camera_name=cam.name, apply_overscan=True)
    op = row.operator('smart_camlight_suite.render_camera', text=_t('Render', 'レンダー', context), icon='RENDER_STILL')
    _set_operator_props(op, camera_name=cam.name, mode='NORMAL', animation=False)
    op = row.operator('smart_camlight_suite.render_camera', text=_t('Viewport', 'ビューポート', context), icon='RENDER_ANIMATION')
    _set_operator_props(op, camera_name=cam.name, mode='VIEWPORT', animation=False)
    row = box.row(align=True)
    op = row.operator('smart_camlight_suite.render_all_cameras', text=_t('All Cameras', '全カメラ', context), icon='RENDER_ANIMATION')
    _set_operator_props(op, custom_only=True, mode='NORMAL', animation=False)
    op = row.operator('smart_camlight_suite.apply_all_camera_settings', text=_t('Apply All Custom Cameras', '全カスタムカメラを適用', context), icon='CHECKMARK')
    _draw_camera_data(box, context, cam)
    _draw_camera_resolution(box, context, cam)
    _draw_camera_frame_range(box, context, cam)
    _draw_camera_output(box, context, cam)
    _draw_camera_guides(box, context, cam)
    _draw_camera_rig_review(box, context, cam)
    _draw_camera_overscan_motion_pov(box, context, cam)


def _draw_camera_body(layout, context, settings) -> None:
    _draw_camera_list(layout, context, settings)
    _draw_selected_camera(layout, context, settings)


def _draw_light_list(layout, context, settings) -> None:
    box = layout.box()
    row = box.row(align=True)
    row.label(text=_t('Scene Lights', 'シーン内ライト', context), icon='LIGHT')
    row.operator('smart_camlight_suite.add_light', text='', icon='ADD')
    row.prop(settings, 'show_generated_lights_only', text='', icon='FILTER')
    row.operator('smart_camlight_suite.all_light_visibility', text='', icon='HIDE_OFF').visible = True
    row.operator('smart_camlight_suite.all_light_visibility', text='', icon='HIDE_ON').visible = False
    lights = _light_list(context, settings)
    if not lights:
        if scene_index.get_index(context.scene) is None:
            message = _t('Loading scene lights…', 'シーン内ライトを読み込み中…', context)
        elif settings.show_generated_lights_only:
            message = _t('No generated lights match the filter.', 'フィルターに一致する生成ライトがありません。', context)
        else:
            message = _t('No light exists in this scene.', 'このシーンにライトが存在しません。', context)
        box.label(text=message, icon='NONE')
        return
    active_name = settings.active_light_name if settings else ''
    for light in lights:
        row = box.row(align=True)
        is_active = light.name == active_name
        op = row.operator('smart_camlight_suite.select_light', text=light.name, translate=False, icon='LIGHT', depress=is_active)
        _set_operator_props(op, light_name=light.name)
        op = row.operator('smart_camlight_suite.toggle_light_visibility', text='', icon='HIDE_ON' if light.hide_viewport or light.hide_render else 'HIDE_OFF')
        _set_operator_props(op, light_name=light.name)
        op = row.operator('smart_camlight_suite.toggle_light_lock', text='', icon='LOCKED' if light.smart_camlight_object.locked_light else 'UNLOCKED')
        _set_operator_props(op, light_name=light.name)
        op = row.operator('smart_camlight_suite.delete_light', text='', icon='TRASH')
        _set_operator_props(op, light_name=light.name)


def _draw_light_data(layout, context, light) -> None:
    data = light.data
    lset = data.smart_camlight_light
    locked = bool(light.smart_camlight_object.locked_light)
    box, expanded = _draw_foldout(layout, lset, 'show_light_data', 'Light Data', 'ライトデータ', context, icon='LIGHT', topic='light_data')
    if not expanded:
        return
    col = box.column(align=True)
    if locked:
        col.label(text=_t('Locked', 'ロック中', context), icon='LOCKED')
    edit = col.column(align=True)
    edit.enabled = not locked
    _prop_if(edit, light, 'name', 'Object Name', 'オブジェクト名', context)
    edit.prop(light, 'location', text=_t('Location', '位置', context))
    edit.prop(light, 'rotation_euler', text=_t('Rotation', '回転', context))
    _prop_if(edit, data, 'type', 'Type', 'タイプ', context)
    _prop_if(edit, data, 'energy', 'Energy', 'エネルギー', context)
    _prop_if(edit, data, 'color', 'Color', 'カラー', context)
    if getattr(data, 'type', '') == 'AREA':
        _prop_if(edit, data, 'shape', 'Shape', '形状', context)
        _prop_if(edit, data, 'size', 'Size', 'サイズ', context)
        _prop_if(edit, data, 'size_y', 'Size Y', 'サイズY', context)
    elif getattr(data, 'type', '') in {'POINT', 'SPOT'}:
        _prop_if(edit, data, 'shadow_soft_size', 'Soft Size', 'ソフトサイズ', context)
    if getattr(data, 'type', '') == 'SPOT':
        _prop_if(edit, data, 'spot_size', 'Spot Size', 'スポットサイズ', context)
        _prop_if(edit, data, 'spot_blend', 'Spot Blend', 'スポットブレンド', context)
    edit.prop(lset, 'target_size', text=_t('Target Size', 'ターゲットサイズ', context))
    _prop_if(edit, data, 'use_shadow', 'Use Shadow', 'シャドウを使用', context)
    cycles = getattr(data, 'cycles', None)
    if cycles:
        sub = edit.box()
        sub.label(text='Cycles')
        _prop_if(sub, lset, 'max_bounces', 'Max Bounces', '最大バウンス', context)
    row = col.row(align=True)
    op = row.operator('smart_camlight_suite.toggle_light_lock', text=_t('Locked', 'ロック中', context) if locked else _t('Unlocked', 'ロック解除', context), icon='LOCKED' if locked else 'UNLOCKED')
    _set_operator_props(op, light_name=light.name)
    op = row.operator('smart_camlight_suite.create_light_target', text=_t('Create Light Target', 'ライトターゲットを作成', context), icon='OUTLINER_OB_EMPTY')
    _set_operator_props(op, light_name=light.name)
    row = col.row(align=True)
    op = row.operator('smart_camlight_suite.mirror_light', text=_t('Mirror', 'ミラー', context) + ' X', icon='MOD_MIRROR')
    _set_operator_props(op, light_name=light.name, axis='X')
    op = row.operator('smart_camlight_suite.mirror_light', text='Y', icon='MOD_MIRROR')
    _set_operator_props(op, light_name=light.name, axis='Y')
    op = row.operator('smart_camlight_suite.isolate_light', text=_t('Isolate', '分離表示', context), icon='SOLO_ON')
    _set_operator_props(op, light_name=light.name)


def _link_collection(light, kind: str):
    ll = getattr(light, 'light_linking', None)
    if not ll:
        return None
    return getattr(ll, 'receiver_collection' if kind == 'RECEIVER' else 'blocker_collection', None)


def _draw_linked_objects(layout, context, light, kind: str) -> None:
    title_en = 'Light Linking' if kind == 'RECEIVER' else 'Shadow Linking'
    title_ja = 'ライトリンキング' if kind == 'RECEIVER' else 'シャドウリンキング'
    coll = _link_collection(light, kind)
    box = layout.box()
    row = box.row(align=True)
    row.label(text=_t(title_en, title_ja, context), icon='LINKED')
    op = row.operator('smart_camlight_suite.add_selected_to_linking', text='', icon='ADD')
    _set_operator_props(op, light_name=light.name, kind=kind)
    if coll:
        op = row.operator('smart_camlight_suite.clear_light_linking', text='', icon='PANEL_CLOSE')
        _set_operator_props(op, light_name=light.name, kind=kind)
    if not coll:
        box.label(text=_t('Not initialized', '未初期化', context), icon='NONE')
        return
    objects = list(coll.objects)
    if not objects:
        box.label(text=_t('No linked objects.', 'リンク済みオブジェクトがありません。', context), icon='NONE')
        return
    for obj, item in zip(objects, coll.collection_objects):
        included = item.light_linking.link_state == 'INCLUDE'
        row = box.row(align=True)
        op = row.operator('smart_camlight_suite.select_linked_object', text=obj.name, translate=False, icon='OBJECT_DATA')
        _set_operator_props(op, object_name=obj.name)
        op = row.operator('smart_camlight_suite.set_link_state', text='', icon='CHECKBOX_HLT', depress=included)
        _set_operator_props(op, light_name=light.name, object_name=obj.name, kind=kind, state='INCLUDE')
        op = row.operator('smart_camlight_suite.set_link_state', text='', icon='CHECKBOX_DEHLT', depress=not included)
        _set_operator_props(op, light_name=light.name, object_name=obj.name, kind=kind, state='EXCLUDE')
        op = row.operator('smart_camlight_suite.remove_linked_object', text='', icon='X')
        _set_operator_props(op, light_name=light.name, object_name=obj.name, kind=kind)


def _draw_linked_object_display(layout, context, settings) -> None:
    obj = context.scene.objects.get(settings.active_linked_object_name) if settings and getattr(context, 'scene', None) else None
    box = layout.box()
    box.label(text=_t('Linked Object Display', 'リンク済みオブジェクト表示', context), icon='OBJECT_DATA')
    if not obj:
        box.label(text=_t('No object selected', 'オブジェクト未選択', context), icon='NONE')
        return
    box.label(text=obj.name, icon='OBJECT_DATA', translate=False)
    col = box.column(align=True)
    _prop_if(col, obj, 'hide_viewport', 'Hide in Viewport', 'ビューポートで非表示', context)
    _prop_if(col, obj, 'hide_render', 'Hide in Render', 'レンダーで非表示', context)
    _prop_if(col, obj, 'display_type', 'Display Type', '表示タイプ', context)
    _prop_if(col, obj, 'show_name', 'Show Name', '名前を表示', context)
    _prop_if(col, obj, 'show_in_front', 'Show In Front', '前面表示', context)
    _prop_if(col, obj, 'color', 'Object Color', 'オブジェクトカラー', context)


def _draw_light_linking(layout, context, settings, light) -> None:
    lset = light.data.smart_camlight_light
    box, expanded = _draw_foldout(layout, lset, 'show_linking', 'Light Linking', 'ライトリンキング', context, icon='LINKED', topic='linking')
    if not expanded:
        return
    if not hasattr(light, 'light_linking'):
        box.label(text=_t('This Blender build does not expose light linking on light objects.', 'このBlenderビルドではライトオブジェクトのライトリンキングが公開されていません。'), icon='ERROR')
        return
    row = box.row(align=True)
    op = row.operator('smart_camlight_suite.init_light_linking', text=_t('Initialize', '初期化', context), icon='ADD')
    _set_operator_props(op, light_name=light.name)
    row.operator('smart_camlight_suite.clean_linking_collections', text=_t('Clean Linking', 'リンキングを整理', context), icon='BRUSH_DATA')
    _draw_linked_objects(box, context, light, 'RECEIVER')
    _draw_linked_objects(box, context, light, 'BLOCKER')
    _draw_linked_object_display(box, context, settings)


def _draw_light_generator(layout, context, settings) -> None:
    box, expanded = _draw_foldout(
        layout,
        settings,
        'show_light_utilities',
        'Light Generator',
        'ライト生成',
        context,
        icon='LIGHT',
        topic='generator',
    )
    if not expanded:
        return
    col = box.column(align=True)
    col.prop(settings, 'studio_preset', text=_t('Studio Preset', 'スタジオプリセット', context))
    row = col.row(align=True)
    row.operator('smart_camlight_suite.apply_studio_preset', text=_t('Apply Studio Preset', 'スタジオプリセットを適用', context), icon='PRESET')
    row.operator('smart_camlight_suite.create_softbox', text=_t('Softbox', 'ソフトボックス', context), icon='MESH_PLANE')
    col.operator(
        'smart_camlight_suite.set_emission_strength',
        text=_t('Set Selected Emission Strength', '選択発光強度を設定', context),
        icon='MATERIAL',
    )
    col.separator()
    col.prop(settings, 'light_count', text=_t('Light Count', 'ライト数', context))
    col.prop(settings, 'light_type', text=_t('Light Type', 'ライトタイプ', context))
    col.prop(settings, 'distribution', text=_t('Distribution', '分布', context))
    col.prop(settings, 'light_distance', text=_t('Distance', '距離', context))
    col.prop(settings, 'light_z_offset', text=_t('Z Offset', 'Zオフセット', context))
    col.prop(settings, 'light_randomness', text=_t('Randomness', 'ランダム量', context))
    col.prop(settings, 'light_seed', text=_t('Random Seed', 'ランダムシード', context))
    col.prop(settings, 'randomize_power', text=_t('Randomize Power', 'パワーをランダム化', context))
    row = col.row(align=True)
    row.prop(settings, 'power_min', text=_t('Power Min', '最小パワー', context))
    row.prop(settings, 'power_max', text=_t('Power Max', '最大パワー', context))
    if settings.light_type == 'AREA':
        col.prop(settings, 'area_shape', text=_t('Area Shape', 'エリア形状', context))
        if settings.area_shape in {'RECTANGLE', 'ELLIPSE'}:
            row = col.row(align=True)
            row.prop(settings, 'area_size_x', text=_t('Area Size X', 'エリアサイズX', context))
            row.prop(settings, 'area_size_y', text=_t('Area Size Y', 'エリアサイズY', context))
        else:
            col.prop(settings, 'light_size', text=_t('Light Size', 'ライトサイズ', context))
    elif settings.light_type == 'SPOT':
        col.prop(settings, 'light_size', text=_t('Light Size', 'ライトサイズ', context))
        col.prop(settings, 'spot_size', text=_t('Spot Size', 'スポットサイズ', context))
        col.prop(settings, 'spot_blend', text=_t('Spot Blend', 'スポットブレンド', context))
    else:
        col.prop(settings, 'light_size', text=_t('Light Size', 'ライトサイズ', context))
    col.prop(settings, 'use_target_object', text=_t('Use Target Object', 'ターゲットオブジェクトを使用', context))
    if settings.use_target_object:
        col.prop(settings, 'target_object', text=_t('Target Object', 'ターゲットオブジェクト', context))
    row = col.row(align=True)
    row.operator('smart_camlight_suite.generate_lights', text=_t('Generate Lights', 'ライトを生成', context), icon='LIGHT')
    row.operator('smart_camlight_suite.clear_generated_lights', text=_t('Clear', 'クリア', context), icon='TRASH')


def _draw_dynamic_sky(layout, context, settings) -> None:
    box, expanded = _draw_foldout(
        layout,
        settings,
        'show_dynamic_sky',
        'Dynamic Sky',
        'ダイナミックスカイ',
        context,
        icon='WORLD',
        topic='dynamic_sky',
    )
    if not expanded:
        return
    col = box.column(align=True)
    row = col.row(align=True)
    row.operator('smart_camlight_suite.create_dynamic_sky', text=_t('Create or Refresh', '作成または更新', context), icon='FILE_REFRESH')
    row.operator('smart_camlight_suite.remove_dynamic_sky', text=_t('Remove', '削除', context), icon='TRASH')
    col.prop(settings, 'sky_strength', text=_t('Sky Strength', 'スカイ強度', context))
    col.prop(settings, 'sky_turbidity', text=_t('Sky Turbidity', 'スカイ濁度', context))
    col.prop(settings, 'sky_create_sun', text=_t('Create Sun Light', 'サンライトを作成', context))
    if settings.sky_create_sun:
        col.prop(settings, 'sky_sun_energy', text=_t('Sun Energy', 'サン強度', context))


def _draw_selected_light(layout, context, settings) -> None:
    light = _selected_light(context, settings)
    box = layout.box()
    box.label(text=_t('Selected Light', '選択中ライト', context), icon='LIGHT')
    if not light:
        box.label(text=_t('No light exists in this scene.', 'このシーンにライトが存在しません。'), icon='NONE')
        return
    row = box.row(align=True)
    row.label(text=light.name, icon='LIGHT', translate=False)
    if light.smart_camlight_object.is_generated_light:
        row.label(text=_t('Generated', '生成済み', context), icon='CHECKMARK')
    if light.smart_camlight_object.locked_light:
        row.label(text='', icon='LOCKED')
    _draw_light_data(box, context, light)
    _draw_light_linking(box, context, settings, light)


def _draw_light_body(layout, context, settings) -> None:
    _draw_light_list(layout, context, settings)
    _draw_selected_light(layout, context, settings)
    _draw_light_generator(layout, context, settings)
    _draw_dynamic_sky(layout, context, settings)


_SECTION_DRAWERS = {
    'ui_section_always_on': _draw_always_on_body,
    'ui_section_camera': _draw_camera_body,
    'ui_section_light': _draw_light_body,
}


def _panel_poll(context, expected_physical_space: str, allowed_logical_editors=()) -> bool:
    """Pure physical-first native-root poll.

    No Scene/Object requirement is imposed: enabled roots remain usable in all
    managed editors even when no object is active.  Unknown logical mappings or
    physical mismatches fail closed before the public Manager API is consulted.
    """
    if manager_bridge.physical_space_for_context(context) != expected_physical_space:
        return False
    logical_editor = manager_bridge.logical_editor_for_context(context)
    if logical_editor is None:
        return False
    if manager_bridge.LOGICAL_TO_SPACE.get(logical_editor) != expected_physical_space:
        return False
    if allowed_logical_editors and logical_editor not in allowed_logical_editors:
        return False
    return bool(manager_bridge.placement_allowed(context, logical_editor))


def _draw_root_panel(self, context) -> None:
    layout = self.layout
    layout.use_property_split = False
    layout.use_property_decorate = False
    settings = _settings(context)
    if settings is None:
        layout.label(text=_t('Settings are not available.', '設定を使用できません。', context), icon='ERROR')
        return None
    # Allocate every top-level sibling before any expanded body draws native
    # child panels. This keeps later top-level headers at the root x-origin.
    top_slots = tuple(layout.row(align=False) for _unused in _SECTION_DEFS)
    top_boxes = tuple(slot.box() for slot in top_slots)
    prepared = []
    for box, (prop, en, ja, icon, topic) in zip(top_boxes, _SECTION_DEFS):
        section_box, expanded = _draw_section_header(
            layout,
            context,
            settings,
            prop,
            en,
            ja,
            icon=icon,
            topic=topic,
            container=box,
        )
        prepared.append((section_box, expanded, prop))

    for box, expanded, prop in prepared:
        if not expanded:
            continue
        drawer = _SECTION_DRAWERS.get(prop)
        if drawer is None:
            continue
        try:
            drawer(box, context, settings)
        except Exception as exc:
            warn = box.box()
            warn.alert = True
            message = _t("Failed to draw this section", "このセクションの描画に失敗しました", context)
            if not tr.is_japanese(context):
                message = f'{message}: {str(exc)[:160]}'
            warn.label(text=message, icon='ERROR')
    return None


def _native_root_poll(cls, context):
    return _panel_poll(context, cls.bl_space_type, getattr(cls, "_smart_tools_manager_logical_editor_keys", ()))


def _native_root_draw(self, context):
    # Always discard the body helper result and return Blender's required None.
    _draw_root_panel(self, context)
    return None


class _SCLSNativeRootPanelMixin:
    def draw_header_preset(self, context):
        _help_button(self.layout, 'overview', context)

    bl_label = 'Smart CamLight'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True

    @classmethod
    def poll(cls, context):
        return _panel_poll(context, cls.bl_space_type)

    def draw(self, context):
        # Blender Panel.draw must return None.  The canonical body helper is
        # called for its UI side effect and any future status value is discarded.
        _draw_root_panel(self, context)
        return None


class VIEW3D_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'VIEW3D_PT_scls_root'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class IMAGE_PT_scls_image_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'IMAGE_PT_scls_image_root'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class NODE_PT_scls_shader_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'NODE_PT_scls_shader_root'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class SEQUENCER_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'SEQUENCER_PT_scls_root'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class CLIP_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'CLIP_PT_scls_root'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class DOPESHEET_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'DOPESHEET_PT_scls_root'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class GRAPH_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'GRAPH_PT_scls_root'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class NLA_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'NLA_PT_scls_root'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class TEXT_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'TEXT_PT_scls_root'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class FILEBROWSER_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'FILEBROWSER_PT_scls_root'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_logical_editor_keys = ('FILE_BROWSER',)
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


class FILEBROWSER_PT_scls_assets_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'FILEBROWSER_PT_scls_assets_root'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    _smart_tools_manager_logical_editor_keys = ('ASSET_BROWSER',)
    poll = classmethod(_native_root_poll)


class SPREADSHEET_PT_scls_root(_SCLSNativeRootPanelMixin, bpy.types.Panel):
    bl_idname = 'SPREADSHEET_PT_scls_root'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart CamLight'
    _smart_tools_manager_tool_key = 'SMART_CAMLIGHT'
    _smart_tools_manager_native_npanel_root = True
    poll = classmethod(_native_root_poll)
    draw = _native_root_draw


NATIVE_ROOT_CLASSES = (
    VIEW3D_PT_scls_root,
    IMAGE_PT_scls_image_root,
    NODE_PT_scls_shader_root,
    SEQUENCER_PT_scls_root,
    CLIP_PT_scls_root,
    DOPESHEET_PT_scls_root,
    GRAPH_PT_scls_root,
    NLA_PT_scls_root,
    TEXT_PT_scls_root,
    FILEBROWSER_PT_scls_root,
    FILEBROWSER_PT_scls_assets_root,
    SPREADSHEET_PT_scls_root,
)

CLASSES = NATIVE_ROOT_CLASSES


def register() -> None:
    for cls in CLASSES:
        lifecycle.register_class(cls, resource_key=f"panel_class:{cls.__name__}")


def unregister() -> None:
    return None
