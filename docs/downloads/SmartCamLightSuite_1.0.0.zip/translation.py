# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from collections import OrderedDict


_MAX_STATIC_ENTRIES = 2048
_STATIC: OrderedDict[str, str] = OrderedDict()


def add(en: str, ja: str) -> str:
    """Register an English/Japanese text pair and return the English source string."""
    try:
        en_s = str(en or '')
        ja_s = str(ja or '')
    except Exception:
        return en
    if en_s and ja_s and en_s != ja_s:
        _STATIC.pop(en_s, None)
        _STATIC[en_s] = ja_s
        while len(_STATIC) > _MAX_STATIC_ENTRIES:
            _STATIC.popitem(last=False)
    return en_s


def is_japanese(context=None) -> bool:
    try:
        lang = getattr(getattr(context, 'preferences', None), 'view', None).language
    except Exception:
        lang = ''
    if not lang:
        try:
            import bpy
            lang = getattr(getattr(bpy.context, 'preferences', None), 'view', None).language
        except Exception:
            lang = ''
    if not lang or lang == 'DEFAULT':
        try:
            import bpy
            lang = getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''
        except Exception:
            lang = ''
    lang = str(lang or '').lower()
    return lang.startswith('ja') or 'japanese' in lang


def t(en: str, ja: str, context=None) -> str:
    add(en, ja)
    return str(ja if is_japanese(context) else en)


def build_i18n_dict() -> dict[str, dict[tuple[str, str], str]]:
    return {'ja_JP': {(context, en): ja for en, ja in _STATIC.items() if en and ja for context in ('*', 'Operator')}}


# Visible UI text used by the root panel and common operators.
for _en, _ja in {
    'Smart CamLight Suite': 'Smart CamLight Suite',
    'Smart CamLight': 'Smart CamLight',
    'Always-on Toggles': '常時機能切り替え',
    'Camera': 'カメラ',
    'Light': 'ライト',
    'Enabled': '有効',
    'Disabled': '無効',
    'N-panel State Save': 'Nパネル状態保存',
    'Auto Active Camera': '自動アクティブカメラ',
    'Live Per-Camera Sync': 'カメラ別設定の常時同期',
    'Timeline Marker Camera Switch': 'タイムラインマーカーでカメラ切替',
    'Live Physical Motion Blur': '物理モーションブラー常時同期',
    'Light Linking Monitor': 'ライトリンク監視',
    'Dynamic Sky Monitor': 'ダイナミックスカイ監視',
    'Scene Cameras': 'シーン内カメラ',
    'Scene Lights': 'シーン内ライト',
    'Loading scene cameras…': 'シーン内カメラを読み込み中…',
    'Loading scene lights…': 'シーン内ライトを読み込み中…',
    'No custom cameras match the filter.': 'フィルターに一致するカスタムカメラがありません。',
    'No generated lights match the filter.': 'フィルターに一致する生成ライトがありません。',
    'Selected Camera': '選択中カメラ',
    'Selected Light': '選択中ライト',
    'No camera exists in this scene.': 'このシーンにカメラが存在しません。',
    'No light exists in this scene.': 'このシーンにライトが存在しません。',
    'Add Camera': 'カメラを追加',
    'Add Light': 'ライトを追加',
    'Select': '選択',
    'Set Active': 'アクティブ化',
    'Delete': '削除',
    'Apply': '適用',
    'Refresh': '更新',
    'Render': 'レンダー',
    'Viewport': 'ビューポート',
    'All Cameras': '全カメラ',
    'Resolution': '解像度',
    'Frame Range': 'フレーム範囲',
    'File Output': 'ファイル出力',
    'File Format': 'ファイル形式',
    'Camera Data': 'カメラデータ',
    'Transform': 'トランスフォーム',
    'Depth of Field': '被写界深度',
    'Composition Guides': '構図ガイド',
    'Camera Rig': 'カメラリグ',
    'Animation Review': 'アニメーションレビュー',
    'Overscan': 'オーバースキャン',
    'Physical Motion Blur': '物理モーションブラー',
    'POV Export Helper': 'POV書き出し補助',
    'Light Data': 'ライトデータ',
    'Light Linking': 'ライトリンキング',
    'Shadow Linking': 'シャドウリンキング',
    'Linked Object Display': 'リンク済みオブジェクト表示',
    'Light Generator': 'ライト生成',
    'Apply Studio Preset': 'スタジオプリセットを適用',
    'Dynamic Sky': 'ダイナミックスカイ',
    'Softbox': 'ソフトボックス',
    'Utilities': 'ユーティリティ',
    'Create': '作成',
    'Clear': 'クリア',
    'Clean': '整理',
    'Mirror': 'ミラー',
    'Isolate': '分離表示',
    'Show All': '全表示',
    'Hide All': '全非表示',
    'Initialize': '初期化',
    'Add Selected': '選択を追加',
    'Remove': '削除',
    'Visible': '表示',
    'Render Visible': 'レンダー表示',
    'Viewport Display': 'ビューポート表示',
    'Display Type': '表示タイプ',
    'Show Name': '名前を表示',
    'Show In Front': '前面表示',
    'No linked objects.': 'リンク済みオブジェクトがありません。',
    'Use the Initialize button to create the Blender light/shadow linking collections.': '初期化ボタンでBlenderのライト/シャドウリンク用コレクションを作成します。',
    'Settings are not available.': '設定を使用できません。',
    'Failed to draw this section': 'このセクションの描画に失敗しました',
    'Help': 'ヘルプ',
    'Guide': 'ガイド',
    'Target': 'ターゲット',
    'Generated': '生成済み',
    'Active Scene Camera': 'シーンのアクティブカメラ',
    'Custom': 'カスタム',
    'Locked': 'ロック中',
    'Unlocked': 'ロック解除',
    'Receiver Collection': '受光コレクション',
    'Blocker Collection': '遮光コレクション',
    'Include': '含める',
    'Exclude': '除外',
    'Use target object': 'ターゲットオブジェクトを使用',
    'Three Point': 'スリーポイント',
    'Soft Studio': 'ソフトスタジオ',
    'Rim Circle': 'リム円形',
    'Product Strip': '商品ストリップ',
    'Sky Fill': 'スカイフィル',
}.items():
    add(_en, _ja)

# Add-on metadata that Blender shows in the add-on / extension listing.  The
# bl_info values themselves stay the stable English message IDs; only the
# Japanese side is registered here, through the same catalog mechanism.
for _en, _ja in {
    'Sidebar > Smart CamLight': 'サイドバー > Smart CamLight',
    'Unified camera and light management with per-camera settings, rigs, paths, guides, linking, transactional light generation, and isolated Dynamic Sky.': 'カメラ別設定、リグ、パス、ガイド、リンキング、トランザクション方式のライト生成、独立したダイナミックスカイを備えた統合カメラ・ライト管理。',
}.items():
    add(_en, _ja)

I18N_DICT = build_i18n_dict()
