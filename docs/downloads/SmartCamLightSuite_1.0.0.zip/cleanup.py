# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Exact-owner cleanup for Smart CamLight generated data.

No deletion decision is based on a package name, display name, prefix, or a
user-editable Smart CamLight property.  Every automatically removable ID must
carry the Suite UUID, a persistent per-ID instance UUID, an explicit role, and
(where applicable) the persistent UUID of its source object/scene.
"""

from __future__ import annotations

import time
import uuid

import bpy

from . import lifecycle, scene_index

OWNER_UUID_KEY = scene_index.OWNER_UUID_KEY
ROLE_KEY = scene_index.ROLE_KEY
SOURCE_UUID_KEY = scene_index.SOURCE_UUID_KEY
SUITE_OWNER_UUID = scene_index.SUITE_OWNER_UUID
INSTANCE_UUID_KEY = "_scls_instance_uuid"
GENERATION_KEY = "_scls_generation"
SOURCE_NAME_KEY = "_scls_source_name"          # informational only
SOURCE_TYPE_KEY = "_scls_source_type"          # informational only
DATA_VERSION_KEY = "_scls_data_version"
DATA_VERSION = "1.0.17"
# Constraints cannot hold ID properties, so the owner object records them.
OWNED_CONSTRAINTS_KEY = "_scls_owned_constraints"

# Backward-compatible exported names.  These values are never used as an
# ownership predicate.
_OWNER_KEY = OWNER_UUID_KEY
_ROLE_KEY = ROLE_KEY
_SOURCE_NAME_KEY = SOURCE_NAME_KEY
_OWNER_VALUE = SUITE_OWNER_UUID

_LAST_FULL_CLEANUP = 0.0
_LAST_PERIODIC_CLEANUP = 0.0


def _id_name(idb) -> str:
    try:
        return str(getattr(idb, "name", "") or "")
    except Exception:
        return ""


def _set_idprop(idb, key: str, value) -> bool:
    try:
        idb[key] = value
        return True
    except Exception:
        return False


def _get_idprop(idb, key: str, default=""):
    try:
        return idb.get(key, default)
    except Exception:
        return default


def _valid_uuid(value) -> str:
    text = str(value or "").strip()
    try:
        return str(uuid.UUID(text)) if text else ""
    except Exception:
        return ""


def mark_owned(
    idb,
    role: str = "",
    source_name: str = "",
    source_type: str = "",
    *,
    source_uuid: str = "",
    instance_uuid: str = "",
) -> str:
    """Mark a newly created ID/constraint with exact Suite ownership.

    ``source_name`` is retained only for UI/debugging compatibility.  Cleanup
    uses ``source_uuid`` and never falls back to that name.
    """
    if idb is None:
        return ""
    instance = _valid_uuid(instance_uuid) or _valid_uuid(_get_idprop(idb, INSTANCE_UUID_KEY, "")) or str(uuid.uuid4())
    _set_idprop(idb, OWNER_UUID_KEY, SUITE_OWNER_UUID)
    _set_idprop(idb, INSTANCE_UUID_KEY, instance)
    _set_idprop(idb, GENERATION_KEY, lifecycle.GENERATION)
    _set_idprop(idb, ROLE_KEY, str(role or ""))
    _set_idprop(idb, SOURCE_UUID_KEY, _valid_uuid(source_uuid))
    _set_idprop(idb, DATA_VERSION_KEY, DATA_VERSION)
    return instance


def mark_object(
    obj,
    role: str = "",
    source_name: str = "",
    source_type: str = "",
    *,
    source_uuid: str = "",
    instance_uuid: str = "",
) -> str:
    return mark_owned(
        obj,
        role,
        source_name,
        source_type,
        source_uuid=source_uuid,
        instance_uuid=instance_uuid,
    )


def is_owned(idb, *, role: str | None = None, source_uuid: str | None = None) -> bool:
    if idb is None:
        return False
    if str(_get_idprop(idb, OWNER_UUID_KEY, "") or "") != SUITE_OWNER_UUID:
        return False
    if not _valid_uuid(_get_idprop(idb, INSTANCE_UUID_KEY, "")):
        return False
    if role is not None and str(_get_idprop(idb, ROLE_KEY, "") or "") != str(role):
        return False
    if source_uuid is not None and _valid_uuid(_get_idprop(idb, SOURCE_UUID_KEY, "")) != _valid_uuid(source_uuid):
        return False
    return True


def _is_owned(idb) -> bool:
    return is_owned(idb)


def _role(idb) -> str:
    return str(_get_idprop(idb, ROLE_KEY, "") or "") if is_owned(idb) else ""


def _source_uuid(idb) -> str:
    return _valid_uuid(_get_idprop(idb, SOURCE_UUID_KEY, "")) if is_owned(idb) else ""


def _source_name(idb, _fallback_prefix: str = "") -> str:
    # Informational compatibility helper; never used for ownership.
    return str(_get_idprop(idb, SOURCE_NAME_KEY, "") or "") if is_owned(idb) else ""


def _remove_orphan_data(data) -> bool:
    if data is None:
        return False
    try:
        if int(getattr(data, "users", 0) or 0) != 0:
            return False
    except Exception:
        return False
    # isinstance, not the RNA identifier: lights and curves report subclasses
    # such as AreaLight and TextCurve.
    collection = None
    for data_type, candidate in (
        (bpy.types.Camera, bpy.data.cameras),
        (bpy.types.Light, bpy.data.lights),
        (bpy.types.Curve, bpy.data.curves),
        (bpy.types.Mesh, bpy.data.meshes),
        (bpy.types.Material, bpy.data.materials),
        (bpy.types.World, bpy.data.worlds),
        (bpy.types.NodeTree, bpy.data.node_groups),
    ):
        if isinstance(data, data_type):
            collection = candidate
            break
    if collection is None:
        return False
    try:
        collection.remove(data)
        return True
    except TypeError:
        try:
            collection.remove(data, do_unlink=True)
            return True
        except Exception:
            return False
    except Exception:
        return False


def _remove_object(obj) -> bool:
    if obj is None:
        return False
    data = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return False
    if is_owned(data):
        _remove_orphan_data(data)
    return True


def remove_object_and_orphan_data(obj) -> bool:
    """Remove the exact object supplied by an explicit operator/transaction."""
    return _remove_object(obj)


def _remove_collection(coll) -> bool:
    if coll is None or not is_owned(coll):
        return False
    try:
        bpy.data.collections.remove(coll)
        return True
    except Exception:
        return False


def _scenes_for_object(obj) -> tuple:
    try:
        scenes = tuple(getattr(obj, "users_scene", ()) or ())
        if scenes:
            return scenes
    except Exception:
        pass
    try:
        scene = bpy.context.scene
        return (scene,) if scene is not None and scene.objects.get(getattr(obj, "name", "")) is obj else ()
    except Exception:
        return ()


def _source_object_uuid(obj, kind: str) -> str:
    return scene_index.persistent_uuid(obj, kind, ensure=False)


def _owned_helpers(source_obj, source_kind: str, roles: set[str]) -> tuple:
    source_uuid = _source_object_uuid(source_obj, source_kind)
    if not source_uuid:
        return ()
    result = []
    seen = set()
    for scene in _scenes_for_object(source_obj):
        index = scene_index.get_index(scene)
        if index is None:
            # Explicit cleanup may rebuild at an operator boundary; never from
            # Panel.draw or Panel.poll.
            index = scene_index.rebuild_scene(scene, ensure_uuids=True)
        if index is None:
            continue
        for role in roles:
            for helper in index.owned_helpers.get((source_uuid, role), ()):
                pointer = id(helper)
                if pointer not in seen and is_owned(helper, role=role, source_uuid=source_uuid):
                    seen.add(pointer)
                    result.append(helper)
    return tuple(result)


def cleanup_legacy_lighthelper_proxy_data(context=None, *, aggressive: bool = False) -> dict[str, int]:
    """Compatibility no-op for unsafe legacy name-based cleanup.

    Earlier versions inferred ownership from ``LightHelper`` names and could
    unlink foreign data.  Current versions deliberately do not migrate or delete those
    IDs without an exact owner UUID.
    """
    return {
        "safe_unlinks": 0,
        "collections": 0,
        "objects": 0,
        "meshes": 0,
        "skipped_foreign": 0,
    }


def mark_owned_constraint(owner, constraint, role: str, *, transaction=None) -> bool:
    """Record one newly created constraint on its owner object, by exact name."""
    if transaction is not None:
        transaction.snapshot_item(owner, OWNED_CONSTRAINTS_KEY)
    try:
        record = dict(owner.get(OWNED_CONSTRAINTS_KEY, {}) or {})
        record[str(constraint.name)] = str(role or "")
        owner[OWNED_CONSTRAINTS_KEY] = record
        return True
    except Exception:
        return False


def is_owned_constraint(owner, constraint, role: str | None = None) -> bool:
    try:
        recorded = owner.get(OWNED_CONSTRAINTS_KEY, {}).get(str(constraint.name))
    except Exception:
        return False
    return recorded is not None and (role is None or str(recorded) == str(role))


def remove_owned_constraint(owner, constraint) -> bool:
    """Remove one recorded constraint and forget its record."""
    if not is_owned_constraint(owner, constraint):
        return False
    name = str(constraint.name)
    try:
        owner.constraints.remove(constraint)
    except Exception:
        return False
    try:
        record = dict(owner.get(OWNED_CONSTRAINTS_KEY, {}) or {})
        record.pop(name, None)
        if record:
            owner[OWNED_CONSTRAINTS_KEY] = record
        else:
            del owner[OWNED_CONSTRAINTS_KEY]
    except Exception:
        pass
    return True


def _remove_owned_constraints(owner, *, role: str) -> int:
    count = 0
    try:
        constraints = tuple(owner.constraints)
    except Exception:
        constraints = ()
    for constraint in constraints:
        if is_owned_constraint(owner, constraint, role):
            count += int(remove_owned_constraint(owner, constraint))
    return count


def remove_camera_guides_for_camera(cam) -> int:
    if cam is None:
        return 0
    count = 0
    for obj in _owned_helpers(cam, "OBJECT", {"camera_guide"}):
        count += int(_remove_object(obj))
    return count


def remove_camera_paths_for_camera(cam) -> int:
    if cam is None:
        return 0
    count = 0
    for obj in _owned_helpers(cam, "OBJECT", {"camera_path"}):
        count += int(_remove_object(obj))
    return count


def remove_pov_texts_for_camera(cam) -> int:
    if cam is None:
        return 0
    source_uuid = _source_object_uuid(cam, "OBJECT")
    if not source_uuid:
        return 0
    count = 0
    for text in tuple(getattr(bpy.data, "texts", ()) or ()):
        if not is_owned(text, role="pov_text", source_uuid=source_uuid):
            continue
        try:
            bpy.data.texts.remove(text)
            count += 1
        except Exception:
            pass
    return count


def remove_camera_rig_for_camera(cam, *, remove_constraints: bool = True) -> int:
    if cam is None:
        return 0
    source_uuid = _source_object_uuid(cam, "OBJECT")
    if not source_uuid:
        return 0
    count = 0
    try:
        world_matrix = cam.matrix_world.copy()
    except Exception:
        world_matrix = None
    if remove_constraints:
        count += _remove_owned_constraints(cam, role="camera_rig_constraint")
    try:
        parent = getattr(cam, "parent", None)
        if is_owned(parent, role="camera_rig_dolly", source_uuid=source_uuid):
            cam.parent = None
    except Exception:
        pass
    if world_matrix is not None:
        try:
            cam.matrix_world = world_matrix
        except Exception:
            pass
    for obj in _owned_helpers(cam, "OBJECT", {"camera_rig_target", "camera_rig_dolly"}):
        count += int(_remove_object(obj))
    return count


def remove_light_targets_for_light(light) -> int:
    if light is None:
        return 0
    source_uuid = _source_object_uuid(light, "OBJECT")
    if not source_uuid:
        return 0
    count = 0
    try:
        world_matrix = light.matrix_world.copy()
    except Exception:
        world_matrix = None
    count += _remove_owned_constraints(light, role="light_target_constraint")
    if world_matrix is not None:
        try:
            light.matrix_world = world_matrix
        except Exception:
            pass
    for obj in _owned_helpers(light, "OBJECT", {"light_target"}):
        count += int(_remove_object(obj))
    return count


def cleanup_scene_selection_names(context=None) -> int:
    cleaned = 0
    try:
        scene = getattr(context or bpy.context, "scene", None)
    except Exception:
        scene = None
    settings = getattr(scene, "smart_camlight_suite", None) if scene is not None else None
    if settings is None:
        return 0
    for attr, expected_type in (
        ("active_camera_name", "CAMERA"),
        ("active_light_name", "LIGHT"),
        ("active_linked_object_name", None),
    ):
        try:
            name = str(getattr(settings, attr, "") or "")
            obj = scene.objects.get(name) if name else None
            if name and (obj is None or (expected_type and getattr(obj, "type", None) != expected_type)):
                setattr(settings, attr, "")
                cleaned += 1
        except Exception:
            pass
    return cleaned


def _cleanup_stale_helpers_in_scene(scene) -> int:
    index = scene_index.get_index(scene) or scene_index.rebuild_scene(scene, ensure_uuids=True)
    if index is None:
        return 0
    removable_roles = {
        "camera_guide",
        "camera_path",
        "camera_rig_target",
        "camera_rig_dolly",
        "light_target",
        "dynamic_sun",
        "softbox_mesh",
        "softbox_plane",
    }
    valid_source_uuids = set(index.object_by_uuid)
    valid_source_uuids.add(index.scene_uuid)
    removed = 0
    for (source_uuid, role), objects in tuple(index.owned_helpers.items()):
        if role not in removable_roles or source_uuid in valid_source_uuids:
            continue
        for obj in tuple(objects):
            if is_owned(obj, role=role, source_uuid=source_uuid):
                removed += int(_remove_object(obj))
    if removed:
        scene_index.rebuild_scene(scene, ensure_uuids=True)
    return removed


def _cleanup_owned_orphan_datablocks() -> int:
    removed = 0
    collections = (
        getattr(bpy.data, "curves", ()),
        getattr(bpy.data, "meshes", ()),
        getattr(bpy.data, "materials", ()),
        getattr(bpy.data, "lights", ()),
        getattr(bpy.data, "cameras", ()),
        getattr(bpy.data, "worlds", ()),
        getattr(bpy.data, "node_groups", ()),
    )
    for collection in collections:
        for datablock in tuple(collection or ()):
            if not is_owned(datablock):
                continue
            try:
                users = int(getattr(datablock, "users", 0) or 0)
            except Exception:
                users = 1
            if users == 0:
                removed += int(_remove_orphan_data(datablock))
    return removed



def clean_dirty_owned_ids(scene, dirty_ids) -> dict[str, int]:
    """Process only exact-owned IDs received from one concrete event.

    The current Scene index is rebuilt once at this finite event boundary.  No
    global ``bpy.data`` sweep and no other Scene traversal is performed.
    """
    stats = {"owned_helpers": 0, "owned_orphans": 0, "examined": 0}
    if scene is None:
        return stats
    index = scene_index.rebuild_scene(scene, ensure_uuids=True)
    if index is None:
        return stats
    valid_source_uuids = set(index.object_by_uuid)
    if index.scene_uuid:
        valid_source_uuids.add(index.scene_uuid)
    removable_roles = {
        "camera_guide",
        "camera_path",
        "camera_rig_target",
        "camera_rig_dolly",
        "light_target",
        "dynamic_sun",
        "softbox_mesh",
        "softbox_plane",
    }
    seen = set()
    for id_data in tuple(dirty_ids or ()):
        pointer = id(id_data)
        if id_data is None or pointer in seen:
            continue
        seen.add(pointer)
        stats["examined"] += 1
        if is_owned(id_data):
            role = _role(id_data)
            source_uuid = _source_uuid(id_data)
            identifier = str(getattr(getattr(id_data, "bl_rna", None), "identifier", "") or "")
            if identifier == "Object" and role in removable_roles and source_uuid and source_uuid not in valid_source_uuids:
                stats["owned_helpers"] += int(_remove_object(id_data))
                continue
            try:
                users = int(getattr(id_data, "users", 0) or 0)
            except Exception:
                users = 1
            if identifier != "Object" and users == 0:
                stats["owned_orphans"] += int(_remove_orphan_data(id_data))
        data = getattr(id_data, "data", None)
        if data is not None and is_owned(data):
            try:
                users = int(getattr(data, "users", 0) or 0)
            except Exception:
                users = 1
            if users == 0:
                stats["owned_orphans"] += int(_remove_orphan_data(data))
    stats["total"] = stats["owned_helpers"] + stats["owned_orphans"]
    return stats

def clean_stale_proxy_data(context=None, *, aggressive: bool = False, reason: str = "") -> dict[str, int]:
    """Explicit finite cleanup of exact-owned stale helpers only."""
    stats = {
        "legacy_safe_unlinks": 0,
        "legacy_collections": 0,
        "legacy_objects": 0,
        "legacy_meshes": 0,
        "scene_names": cleanup_scene_selection_names(context),
        "owned_helpers": 0,
        "owned_orphans": 0,
    }
    try:
        scenes = tuple(getattr(bpy.data, "scenes", ()) or ())
    except Exception:
        scenes = ()
    for scene in scenes:
        stats["owned_helpers"] += _cleanup_stale_helpers_in_scene(scene)
    stats["owned_orphans"] = _cleanup_owned_orphan_datablocks()
    stats["total"] = sum(value for value in stats.values() if isinstance(value, int))
    global _LAST_FULL_CLEANUP
    _LAST_FULL_CLEANUP = time.monotonic()
    return stats


def periodic_cleanup(context=None, *, interval: float = 10.0) -> dict[str, int] | None:
    """Compatibility entry point; never schedules itself or any watchdog."""
    global _LAST_PERIODIC_CLEANUP
    now = time.monotonic()
    if now - _LAST_PERIODIC_CLEANUP < max(0.0, float(interval)):
        return None
    _LAST_PERIODIC_CLEANUP = now
    return clean_stale_proxy_data(context, aggressive=False, reason="finite_event")
