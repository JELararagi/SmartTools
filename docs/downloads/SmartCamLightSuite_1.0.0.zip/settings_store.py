# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Validated, identity-keyed JSON persistence for Smart CamLight.

Disk input is read once per explicit lifecycle load.  RNA updates patch only the
owning Scene/Camera/Light/Object record in memory.  Writes use a unique sibling
temporary file, flush/fsync, atomic replacement, and a strict readback check.
Invalid input is never interpreted as an empty profile and never overwrites the
current Blender values.
"""

from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import os
import shutil
import tempfile
import time
import uuid

import bpy
from bpy.app.handlers import persistent

from . import lifecycle, scene_index

SCHEMA_VERSION = 6
DOCUMENT_KIND = "smart_camlight_suite.settings"
CONFIG_DIRNAME = "Smart_CamLight_Suite"
CONFIG_FILENAME = "Smart_CamLight_Suite.json"
BACKUP_SUFFIX = ".bak"
CHECKSUM_ALGORITHM = "sha256"
MAX_DIRTY_RECORDS = 4096

# Cross-file values are explicit UI defaults only.  Camera/Light/Object values
# are always scoped to one exact blend identity.
PORTABLE_SCENE_PROPERTIES = frozenset({
    "ui_section_always_on",
    "ui_section_camera",
    "ui_section_light",
    "n_panel_state_save",
    "show_custom_cameras_only",
    "show_generated_lights_only",
    "show_camera_utilities",
    "show_light_utilities",
    "show_dynamic_sky",
    "light_count",
    "light_distance",
    "light_randomness",
    "light_z_offset",
    "light_type",
    "area_shape",
    "light_size",
    "area_size_x",
    "area_size_y",
    "power_min",
    "power_max",
    "randomize_power",
    "light_seed",
    "distribution",
    "use_target_object",
    "spot_size",
    "spot_blend",
    "studio_preset",
    "sky_strength",
    "sky_turbidity",
    "sky_sun_energy",
    "sky_create_sun",
})

# Internal identities, rollback pointers, and temporary state are stored in the
# .blend through RNA but never copied into the JSON profile.
NON_PERSISTED_PROPERTIES = frozenset({
    "rna_type",
    "persistent_uuid",
    "persistent_scene_uuid",
    "persistent_blend_uuid",
    "dynamic_sky_previous_world",
    "dynamic_sky_owned_world",
    "dynamic_sky_owned_sun",
    "overscan_original_x",
    "overscan_original_y",
    "overscan_original_percentage",
    "overscan_applied_x",
    "overscan_applied_y",
    "overscan_view_factor",
})

ACTIVE_NAME_TYPES = {
    "active_camera_name": "CAMERA_OBJECT",
    "active_light_name": "LIGHT_OBJECT",
    "active_linked_object_name": "OBJECT",
}

_APPLYING = False
_LOADED = False
_BASE_DOCUMENT: dict | None = None
_WORKING_DOCUMENT: dict | None = None
_DIRTY: OrderedDict[str, None] = OrderedDict()
_CONFIG_ROOT_OVERRIDE: Path | None = None
_LAST_LOAD_SOURCE = "NOT_LOADED"
_LAST_ERROR = ""


def _set_config_root_for_tests(path: str | os.PathLike | None) -> None:
    global _CONFIG_ROOT_OVERRIDE
    _CONFIG_ROOT_OVERRIDE = Path(path) if path is not None else None


def config_path(*, create: bool = True) -> Path:
    if _CONFIG_ROOT_OVERRIDE is not None:
        root = _CONFIG_ROOT_OVERRIDE
    else:
        root = Path(bpy.utils.user_resource("CONFIG"))
    directory = root / CONFIG_DIRNAME
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory / CONFIG_FILENAME


def backup_path() -> Path:
    path = config_path(create=False)
    return path.with_name(path.name + BACKUP_SUFFIX)


def _normalize_path(path: str) -> str:
    text = str(path or "")
    try:
        text = bpy.path.abspath(text)
    except Exception:
        pass
    try:
        return os.path.normcase(os.path.normpath(text)) if text else ""
    except Exception:
        return text


def _valid_uuid(value) -> str:
    text = str(value or "").strip()
    try:
        return str(uuid.UUID(text)) if text else ""
    except Exception:
        return ""


def _pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value) if value is not None else 0


def _canonical_payload(document: dict) -> bytes:
    value = deepcopy(document)
    value.pop("checksum", None)
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return text.encode("utf-8", errors="strict")


def _checksum(document: dict) -> str:
    return hashlib.sha256(_canonical_payload(document)).hexdigest()


def _finalize_document(document: dict) -> dict:
    result = deepcopy(document)
    result["schema_version"] = SCHEMA_VERSION
    result["document_kind"] = DOCUMENT_KIND
    result["checksum_algorithm"] = CHECKSUM_ALGORITHM
    result["checksum"] = _checksum(result)
    return result


def _validate_document(value, *, expected_revision: int | None = None) -> tuple[bool, str]:
    if not isinstance(value, dict):
        return False, "root_not_object"
    if value.get("document_kind") != DOCUMENT_KIND:
        return False, "document_kind"
    if value.get("schema_version") != SCHEMA_VERSION:
        return False, "schema_version"
    if value.get("checksum_algorithm") != CHECKSUM_ALGORITHM:
        return False, "checksum_algorithm"
    revision = value.get("revision")
    if not isinstance(revision, int) or revision < 0:
        return False, "revision"
    if expected_revision is not None and revision != expected_revision:
        return False, "revision_mismatch"
    if not _valid_uuid(value.get("document_uuid")):
        return False, "document_uuid"
    if not isinstance(value.get("portable_defaults"), dict):
        return False, "portable_defaults"
    if not isinstance(value.get("blends"), dict):
        return False, "blends"
    checksum = str(value.get("checksum") or "")
    if len(checksum) != 64 or checksum != _checksum(value):
        return False, "checksum"
    return True, "ok"


def _read_document(path: Path) -> tuple[dict | None, str]:
    try:
        raw = path.read_bytes()
    except FileNotFoundError:
        return None, "missing"
    except Exception as exc:
        return None, f"read:{type(exc).__name__}"
    try:
        text = raw.decode("utf-8", errors="strict")
        value = json.loads(text)
    except Exception as exc:
        return None, f"decode:{type(exc).__name__}"
    valid, reason = _validate_document(value)
    return (value, "valid") if valid else (None, f"invalid:{reason}")


def _fsync_directory(directory: Path) -> None:
    flags = getattr(os, "O_DIRECTORY", 0) | os.O_RDONLY
    try:
        fd = os.open(str(directory), flags)
    except Exception:
        return
    try:
        os.fsync(fd)
    except Exception:
        pass
    finally:
        os.close(fd)


def _write_bytes_fsync(path: Path, data: bytes) -> None:
    with open(path, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def _pretty_bytes(document: dict) -> bytes:
    text = json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    return text.encode("utf-8", errors="strict")


def _preserve_invalid_main(path: Path) -> None:
    if not path.exists():
        return
    _valid, _reason = _read_document(path)
    if _valid is not None:
        return
    suffix = f".corrupt.{int(time.time())}.{uuid.uuid4().hex}"
    destination = path.with_name(path.name + suffix)
    try:
        shutil.copyfile(path, destination)
        with open(destination, "rb") as handle:
            os.fsync(handle.fileno())
    except Exception:
        pass


def _atomic_write_document(document: dict, *, update_backup: bool = True) -> tuple[bool, str]:
    path = config_path(create=True)
    directory = path.parent
    finalized = _finalize_document(document)
    expected_revision = int(finalized["revision"])
    temp_path: Path | None = None
    backup_temp: Path | None = None
    try:
        fd, name = tempfile.mkstemp(prefix=f".{CONFIG_FILENAME}.", suffix=".tmp", dir=str(directory))
        os.close(fd)
        temp_path = Path(name)
        _write_bytes_fsync(temp_path, _pretty_bytes(finalized))
        temp_doc, temp_state = _read_document(temp_path)
        if temp_doc is None:
            return False, f"tmp_{temp_state}"
        valid, reason = _validate_document(temp_doc, expected_revision=expected_revision)
        if not valid or temp_doc.get("checksum") != finalized.get("checksum"):
            return False, f"tmp_verify:{reason}"

        if update_backup and path.exists():
            current, current_state = _read_document(path)
            if current is not None:
                fd, backup_name = tempfile.mkstemp(prefix=f".{CONFIG_FILENAME}.bak.", suffix=".tmp", dir=str(directory))
                os.close(fd)
                backup_temp = Path(backup_name)
                _write_bytes_fsync(backup_temp, path.read_bytes())
                check, state = _read_document(backup_temp)
                if check is None:
                    return False, f"backup_tmp_{state}"
                os.replace(backup_temp, backup_path())
                backup_temp = None
                _fsync_directory(directory)
            elif current_state != "missing":
                _preserve_invalid_main(path)

        os.replace(temp_path, path)
        temp_path = None
        _fsync_directory(directory)
        readback, state = _read_document(path)
        if readback is None:
            return False, f"readback_{state}"
        valid, reason = _validate_document(readback, expected_revision=expected_revision)
        if not valid or readback.get("checksum") != finalized.get("checksum"):
            return False, f"readback_verify:{reason}"
        return True, "ok"
    except Exception as exc:
        return False, f"write:{type(exc).__name__}:{str(exc)[:160]}"
    finally:
        for item in (temp_path, backup_temp):
            if item is not None:
                try:
                    item.unlink(missing_ok=True)
                except Exception:
                    pass


def _restore_backup_to_main(document: dict) -> bool:
    # Recovery keeps the valid backup intact and does not rotate it through the
    # ordinary previous-main backup path.
    ok, _reason = _atomic_write_document(document, update_backup=False)
    return ok


def _new_document() -> dict:
    return _finalize_document({
        "document_kind": DOCUMENT_KIND,
        "schema_version": SCHEMA_VERSION,
        "revision": 0,
        "document_uuid": str(uuid.uuid4()),
        "checksum_algorithm": CHECKSUM_ALGORITHM,
        "checksum": "",
        "portable_defaults": {"scene": {}},
        "blends": {},
    })


def load_payload(*, force: bool = False) -> dict | None:
    """Read main/backup once and keep the validated document in memory."""
    global _LOADED, _BASE_DOCUMENT, _WORKING_DOCUMENT, _LAST_LOAD_SOURCE, _LAST_ERROR
    if _LOADED and not force:
        return deepcopy(_BASE_DOCUMENT) if _BASE_DOCUMENT is not None else None
    main, main_state = _read_document(config_path(create=False))
    backup, backup_state = _read_document(backup_path())
    candidates = []
    if main is not None:
        candidates.append((int(main.get("revision", 0)), "main", main))
    if backup is not None:
        candidates.append((int(backup.get("revision", 0)), "backup", backup))
    if candidates:
        _revision, source, chosen = max(candidates, key=lambda item: (item[0], item[1] == "main"))
        _BASE_DOCUMENT = deepcopy(chosen)
        _WORKING_DOCUMENT = deepcopy(chosen)
        _LAST_LOAD_SOURCE = source
        _LAST_ERROR = ""
        if source == "backup" and (main is None or int(chosen.get("revision", 0)) >= int((main or {}).get("revision", -1))):
            _restore_backup_to_main(chosen)
    else:
        # Missing or damaged input remains an explicit NOT_READY document.  No
        # RNA value is applied and no default file is created here.
        _BASE_DOCUMENT = None
        _WORKING_DOCUMENT = None
        _LAST_LOAD_SOURCE = "none"
        _LAST_ERROR = f"main={main_state};backup={backup_state}"
    _LOADED = True
    return deepcopy(_BASE_DOCUMENT) if _BASE_DOCUMENT is not None else None


def _blend_file_identity(blend_uuid: str) -> str:
    try:
        filepath = _normalize_path(getattr(bpy.data, "filepath", ""))
    except Exception:
        filepath = ""
    # Unsaved files use the persistent UUID stored in their Scenes, not a
    # module-session token, so exact identity survives add-on reloads without
    # ever matching another unsaved blend.
    return filepath or f"UNSAVED:{_valid_uuid(blend_uuid)}"


def _iter_scenes() -> tuple:
    try:
        return tuple(getattr(bpy.data, "scenes", ()) or ())
    except Exception:
        return ()


def _ensure_blend_uuid() -> str:
    scenes = _iter_scenes()
    candidates = []
    for scene in scenes:
        settings = getattr(scene, "smart_camlight_suite", None)
        value = _valid_uuid(getattr(settings, "persistent_blend_uuid", "") if settings is not None else "")
        if value:
            candidates.append(value)
    blend_uuid = candidates[0] if candidates else str(uuid.uuid4())
    for scene in scenes:
        settings = getattr(scene, "smart_camlight_suite", None)
        if settings is None:
            continue
        try:
            if _valid_uuid(getattr(settings, "persistent_blend_uuid", "")) != blend_uuid:
                settings.persistent_blend_uuid = blend_uuid
        except Exception:
            pass
    return blend_uuid


def blend_identity() -> dict[str, str]:
    blend_uuid = _ensure_blend_uuid()
    return {
        "persistent_uuid": blend_uuid,
        "file_identity": _blend_file_identity(blend_uuid),
    }


def _blend_key(identity: dict[str, str]) -> str:
    payload = f"BLEND|{identity.get('persistent_uuid','')}|{identity.get('file_identity','')}"
    return hashlib.sha256(payload.encode("utf-8", errors="strict")).hexdigest()


def _entity_identity(id_data, kind: str, blend: dict[str, str], *, ensure: bool = True) -> dict[str, str]:
    base = scene_index.identity_record(id_data, kind, ensure=ensure)
    return {
        "blend_uuid": str(blend.get("persistent_uuid") or ""),
        "blend_file_identity": str(blend.get("file_identity") or ""),
        "kind": str(kind or ""),
        "persistent_uuid": str(base.get("persistent_uuid") or ""),
        "library_identity": _normalize_path(str(base.get("library_identity") or "")),
    }


def _entity_key(identity: dict[str, str]) -> str:
    fields = (
        identity.get("blend_uuid", ""),
        identity.get("blend_file_identity", ""),
        identity.get("kind", ""),
        identity.get("persistent_uuid", ""),
        identity.get("library_identity", ""),
    )
    return hashlib.sha256("|".join(map(str, fields)).encode("utf-8", errors="strict")).hexdigest()


def _serializable_scalar(value):
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if value != value or value in {float("inf"), float("-inf")}:
            return None
        return value
    try:
        if hasattr(value, "__iter__") and not isinstance(value, (str, bytes, dict)):
            values = list(value)
            if all(isinstance(item, (bool, int, float, str)) for item in values):
                return values
    except Exception:
        pass
    return None


def _property_definition(settings, name: str):
    try:
        return settings.bl_rna.properties.get(name)
    except Exception:
        return None


def _id_reference(id_data, kind: str, blend: dict[str, str]) -> dict | None:
    if id_data is None:
        return None
    identity = _entity_identity(id_data, kind, blend, ensure=True)
    if not identity.get("persistent_uuid"):
        return None
    return {"__idref__": identity}


def _scene_object_by_name(scene, name: str, expected: str = ""):
    try:
        obj = scene.objects.get(str(name or ""))
    except Exception:
        obj = None
    if obj is not None and expected and getattr(obj, "type", "") != expected:
        return None
    return obj


def _serialize_property(settings, name: str, *, scene, blend: dict[str, str]):
    if name in NON_PERSISTED_PROPERTIES:
        return None
    try:
        value = getattr(settings, name)
    except Exception:
        return None
    if name in ACTIVE_NAME_TYPES:
        expected = ACTIVE_NAME_TYPES[name]
        expected_type = "CAMERA" if expected == "CAMERA_OBJECT" else "LIGHT" if expected == "LIGHT_OBJECT" else ""
        obj = _scene_object_by_name(scene, value, expected_type)
        return _id_reference(obj, "OBJECT", blend)
    prop = _property_definition(settings, name)
    prop_type = str(getattr(prop, "type", "") or "").upper()
    if prop_type == "POINTER":
        identifier = str(getattr(getattr(value, "bl_rna", None), "identifier", "") or "OBJECT").upper()
        kind = "OBJECT" if identifier == "OBJECT" else identifier
        return _id_reference(value, kind, blend)
    if prop_type == "COLLECTION":
        return None
    return _serializable_scalar(value)


def _settings_property_names(settings) -> tuple[str, ...]:
    try:
        props = tuple(settings.bl_rna.properties)
    except Exception:
        return ()
    result = []
    for prop in props:
        name = str(getattr(prop, "identifier", "") or "")
        if not name or name in NON_PERSISTED_PROPERTIES:
            continue
        if bool(getattr(prop, "is_readonly", False)):
            continue
        if str(getattr(prop, "type", "") or "").upper() == "COLLECTION":
            continue
        result.append(name)
    return tuple(result)


def _snapshot_settings(settings, *, scene, blend: dict[str, str]) -> dict:
    result = {}
    for name in _settings_property_names(settings):
        value = _serialize_property(settings, name, scene=scene, blend=blend)
        if value is not None:
            result[name] = value
    return result


def _ensure_blend_record(document: dict, identity: dict[str, str]) -> dict:
    key = _blend_key(identity)
    blends = document.setdefault("blends", {})
    record = blends.setdefault(key, {
        "blend_identity": deepcopy(identity),
        "scenes": {},
        "cameras": {},
        "lights": {},
        "objects": {},
    })
    record["blend_identity"] = deepcopy(identity)
    for domain in ("scenes", "cameras", "lights", "objects"):
        if not isinstance(record.get(domain), dict):
            record[domain] = {}
    return record


def _put_record(domain: dict, id_data, kind: str, settings, scene, blend: dict[str, str], values: dict | None = None) -> str:
    identity = _entity_identity(id_data, kind, blend, ensure=True)
    key = _entity_key(identity)
    record = domain.setdefault(key, {})
    record["identity"] = identity
    record["name_metadata"] = str(getattr(id_data, "name", "") or "")
    record["values"] = values if values is not None else _snapshot_settings(settings, scene=scene, blend=blend)
    return key


def _ensure_working_document() -> dict:
    global _WORKING_DOCUMENT
    if _WORKING_DOCUMENT is None:
        # Missing or corrupt input starts an explicit, empty validated document.
        # Only the concrete dirty Scene/ID/property is inserted below; do not
        # traverse every Scene or serialize unrelated Camera/Light datablocks.
        # Unrecorded RNA remains authoritative in the .blend and is never reset.
        _WORKING_DOCUMENT = _new_document()
    return _WORKING_DOCUMENT


def _mark_dirty(key: str) -> None:
    _DIRTY.pop(key, None)
    _DIRTY[key] = None
    while len(_DIRTY) > MAX_DIRTY_RECORDS:
        _DIRTY.popitem(last=False)
    _sync_boundary_handler_leases()


def _settings_owner(settings, context=None):
    try:
        scene = getattr(context, "scene", None)
    except Exception:
        scene = None
    pointer = _pointer(settings)
    if scene is not None:
        sset = getattr(scene, "smart_camlight_suite", None)
        if _pointer(sset) == pointer:
            return "scenes", scene, "SCENE", scene
        index = scene_index.get_index(scene)
        if index is not None:
            try:
                objects = index.camera_settings_to_objects.get(pointer, ())
                if objects:
                    return "cameras", objects[0].data, "CAMERA", scene
                objects = index.light_settings_to_objects.get(pointer, ())
                if objects:
                    return "lights", objects[0].data, "LIGHT", scene
                objects = index.object_settings_to_objects.get(pointer, ())
                if objects:
                    return "objects", objects[0], "OBJECT", scene
            except ReferenceError:
                # The cached index still names an object that was removed.
                pass
        # The pointer was not present in the cached index. Rebuild exactly this
        # Scene once at the explicit property-change boundary so an equal-count
        # object replacement cannot resolve to stale Camera/Light data.
        index = scene_index.rebuild_scene(scene, ensure_uuids=True)
        if index is not None:
            objects = index.camera_settings_to_objects.get(pointer, ())
            if objects:
                return "cameras", objects[0].data, "CAMERA", scene
            objects = index.light_settings_to_objects.get(pointer, ())
            if objects:
                return "lights", objects[0].data, "LIGHT", scene
            objects = index.object_settings_to_objects.get(pointer, ())
            if objects:
                return "objects", objects[0], "OBJECT", scene
    for candidate in _iter_scenes():
        sset = getattr(candidate, "smart_camlight_suite", None)
        if _pointer(sset) == pointer:
            return "scenes", candidate, "SCENE", candidate
        index = scene_index.get_index(candidate)
        if index is None:
            continue
        objects = index.camera_settings_to_objects.get(pointer, ())
        if objects:
            return "cameras", objects[0].data, "CAMERA", candidate
        objects = index.light_settings_to_objects.get(pointer, ())
        if objects:
            return "lights", objects[0].data, "LIGHT", candidate
        objects = index.object_settings_to_objects.get(pointer, ())
        if objects:
            return "objects", objects[0], "OBJECT", candidate
    return None


def record_property_change(settings, context, property_name: str) -> bool:
    if _APPLYING or property_name in NON_PERSISTED_PROPERTIES:
        return False
    owner = _settings_owner(settings, context)
    if owner is None:
        return False
    domain_name, id_data, kind, scene = owner
    try:
        id_data.name
    except ReferenceError:
        return False
    document = _ensure_working_document()
    blend = blend_identity()
    blend_record = _ensure_blend_record(document, blend)
    domain = blend_record[domain_name]
    identity = _entity_identity(id_data, kind, blend, ensure=True)
    key = _entity_key(identity)
    record = domain.setdefault(key, {
        "identity": identity,
        "name_metadata": str(getattr(id_data, "name", "") or ""),
        "values": {},
    })
    values = record.setdefault("values", {})
    value = _serialize_property(settings, property_name, scene=scene, blend=blend)
    if value is None:
        values.pop(property_name, None)
    else:
        values[property_name] = value
    record["identity"] = identity
    record["name_metadata"] = str(getattr(id_data, "name", "") or "")
    dirty_key = f"{domain_name}:{key}:{property_name}"
    _mark_dirty(dirty_key)
    if domain_name == "scenes" and property_name in PORTABLE_SCENE_PROPERTIES and value is not None and not (isinstance(value, dict) and "__idref__" in value):
        document.setdefault("portable_defaults", {}).setdefault("scene", {})[property_name] = value
        _mark_dirty(f"portable:{property_name}")
    try:
        immediate = bool(getattr(scene.smart_camlight_suite, "n_panel_state_save", False))
    except Exception:
        immediate = False
    if immediate:
        return save_settings(context=context)
    return True


def _current_revision() -> int:
    revisions = []
    for document in (_BASE_DOCUMENT, _WORKING_DOCUMENT):
        if isinstance(document, dict) and isinstance(document.get("revision"), int):
            revisions.append(int(document["revision"]))
    return max(revisions, default=0)


def save_settings(settings=None, *, context=None, force: bool = False) -> bool:
    global _BASE_DOCUMENT, _WORKING_DOCUMENT, _LAST_ERROR
    if not _LOADED:
        load_payload()
    if not _DIRTY and not force:
        _sync_boundary_handler_leases()
        return True
    working = _ensure_working_document()
    candidate = deepcopy(working)
    candidate["revision"] = _current_revision() + 1
    candidate = _finalize_document(candidate)
    ok, reason = _atomic_write_document(candidate, update_backup=True)
    if not ok:
        _LAST_ERROR = reason
        _sync_boundary_handler_leases()
        return False
    _BASE_DOCUMENT = deepcopy(candidate)
    _WORKING_DOCUMENT = deepcopy(candidate)
    _DIRTY.clear()
    _LAST_ERROR = ""
    _sync_boundary_handler_leases()
    return True


def flush_deferred_settings() -> bool:
    if not _DIRTY:
        _sync_boundary_handler_leases()
        return True
    return save_settings(force=True)


def _identity_tuple(identity: dict) -> tuple[str, ...]:
    return (
        str(identity.get("blend_uuid") or ""),
        str(identity.get("blend_file_identity") or ""),
        str(identity.get("kind") or ""),
        str(identity.get("persistent_uuid") or ""),
        _normalize_path(str(identity.get("library_identity") or "")),
    )


def _live_identity_maps(blend: dict[str, str]) -> dict[str, dict[tuple[str, ...], object]]:
    result = {"SCENE": {}, "CAMERA": {}, "LIGHT": {}, "OBJECT": {}}
    seen_camera = set()
    seen_light = set()
    seen_object = set()
    for scene in _iter_scenes():
        identity = _entity_identity(scene, "SCENE", blend, ensure=True)
        result["SCENE"][_identity_tuple(identity)] = scene
        index = scene_index.rebuild_scene(scene, ensure_uuids=True)
        if index is None:
            continue
        for obj in index.cameras:
            if _pointer(obj) not in seen_object:
                seen_object.add(_pointer(obj))
                identity = _entity_identity(obj, "OBJECT", blend, ensure=True)
                result["OBJECT"][_identity_tuple(identity)] = obj
            data = getattr(obj, "data", None)
            if data is not None and _pointer(data) not in seen_camera:
                seen_camera.add(_pointer(data))
                identity = _entity_identity(data, "CAMERA", blend, ensure=True)
                result["CAMERA"][_identity_tuple(identity)] = data
        for obj in index.lights:
            if _pointer(obj) not in seen_object:
                seen_object.add(_pointer(obj))
                identity = _entity_identity(obj, "OBJECT", blend, ensure=True)
                result["OBJECT"][_identity_tuple(identity)] = obj
            data = getattr(obj, "data", None)
            if data is not None and _pointer(data) not in seen_light:
                seen_light.add(_pointer(data))
                identity = _entity_identity(data, "LIGHT", blend, ensure=True)
                result["LIGHT"][_identity_tuple(identity)] = data
    return result


def _resolve_idref(value, maps: dict[str, dict[tuple[str, ...], object]]):
    if not isinstance(value, dict) or "__idref__" not in value:
        return None
    identity = value.get("__idref__")
    if not isinstance(identity, dict):
        return None
    kind = str(identity.get("kind") or "")
    return maps.get(kind, {}).get(_identity_tuple(identity))


def _apply_property(settings, name: str, value, *, scene, maps) -> bool:
    if name in NON_PERSISTED_PROPERTIES or not hasattr(settings, name):
        return False
    if name in ACTIVE_NAME_TYPES:
        obj = _resolve_idref(value, maps)
        if obj is None:
            return False
        try:
            setattr(settings, name, str(obj.name))
            return True
        except Exception:
            return False
    if isinstance(value, dict) and "__idref__" in value:
        resolved = _resolve_idref(value, maps)
        if resolved is None:
            return False
        try:
            setattr(settings, name, resolved)
            return True
        except Exception:
            return False
    if isinstance(value, (bool, int, float, str, list)):
        try:
            setattr(settings, name, value)
            return True
        except Exception:
            return False
    return False


def _settings_for_id(id_data, kind: str):
    try:
        if kind == "SCENE":
            return id_data.smart_camlight_suite
        if kind == "CAMERA":
            return id_data.smart_camlight_settings
        if kind == "LIGHT":
            return id_data.smart_camlight_light
        if kind == "OBJECT":
            return id_data.smart_camlight_object
    except Exception:
        pass
    return None


def apply_saved_settings(scene=None, *, force: bool = False) -> bool:
    """Apply validated in-memory values; this function never reads a file."""
    global _APPLYING
    if not _LOADED:
        # Lifecycle code performs the single explicit disk read. Scene changes,
        # draw/poll paths, and compatibility callers never trigger file I/O.
        return False
    if _BASE_DOCUMENT is None:
        return False
    blend = blend_identity()
    maps = _live_identity_maps(blend)
    blend_record = _BASE_DOCUMENT.get("blends", {}).get(_blend_key(blend))
    changed = False
    _APPLYING = True
    try:
        # Portable defaults are applied only when this exact blend has no JSON
        # record.  Existing .blend RNA remains authoritative otherwise.
        if not isinstance(blend_record, dict):
            defaults = _BASE_DOCUMENT.get("portable_defaults", {}).get("scene", {})
            targets = (scene,) if scene is not None else _iter_scenes()
            for target_scene in targets:
                settings = getattr(target_scene, "smart_camlight_suite", None)
                if settings is None:
                    continue
                for name, value in defaults.items():
                    if name in PORTABLE_SCENE_PROPERTIES:
                        changed |= _apply_property(settings, name, value, scene=target_scene, maps=maps)
            return changed

        domain_kinds = (("scenes", "SCENE"), ("cameras", "CAMERA"), ("lights", "LIGHT"), ("objects", "OBJECT"))
        for domain_name, kind in domain_kinds:
            domain = blend_record.get(domain_name, {})
            if not isinstance(domain, dict):
                continue
            for record in domain.values():
                if not isinstance(record, dict):
                    continue
                identity = record.get("identity")
                if not isinstance(identity, dict):
                    continue
                id_data = maps.get(kind, {}).get(_identity_tuple(identity))
                if id_data is None:
                    continue
                if scene is not None and kind == "SCENE" and id_data is not scene:
                    continue
                settings = _settings_for_id(id_data, kind)
                if settings is None:
                    continue
                values = record.get("values", {})
                if not isinstance(values, dict):
                    continue
                target_scene = id_data if kind == "SCENE" else scene or getattr(bpy.context, "scene", None)
                for name, value in values.items():
                    changed |= _apply_property(settings, name, value, scene=target_scene, maps=maps)
        return changed
    finally:
        _APPLYING = False


def apply_saved_settings_to_all_scenes(*, force: bool = False) -> None:
    apply_saved_settings(None, force=force)


def ensure_context_scene(context=None) -> None:
    try:
        scene = getattr(context or bpy.context, "scene", None)
    except Exception:
        scene = None
    if scene is not None:
        apply_saved_settings(scene)


def make_update(existing, property_name: str):
    """Compose an existing RNA callback with identity-keyed persistence."""
    def _update(self, context):
        if callable(existing):
            existing(self, context)
        if not _APPLYING:
            record_property_change(self, context, property_name)
    return _update


def is_applying() -> bool:
    return _APPLYING


@persistent
def _deferred_save_pre(_dummy=None):
    flush_deferred_settings()


@persistent
def _deferred_load_pre(_dummy=None):
    flush_deferred_settings()


def _sync_boundary_handler_leases() -> None:
    needed = bool(_DIRTY)
    specs = (
        ("settings:save_pre", getattr(bpy.app.handlers, "save_pre", None), _deferred_save_pre),
        ("settings:load_pre", getattr(bpy.app.handlers, "load_pre", None), _deferred_load_pre),
    )
    for key, handler_list, callback in specs:
        if handler_list is None:
            continue
        try:
            if needed:
                lifecycle.register_handler(key, handler_list, callback)
            else:
                lifecycle.release_resource_key(key)
        except Exception:
            # Persistence remains dirty and is retried by the next explicit
            # update, save boundary, or add-on unregister.
            pass


def unregister() -> None:
    flush_deferred_settings()
    lifecycle.release_resource_key("settings:load_pre")
    lifecycle.release_resource_key("settings:save_pre")


def audit_snapshot() -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "loaded": _LOADED,
        "document_ready": _BASE_DOCUMENT is not None,
        "dirty_count": len(_DIRTY),
        "last_load_source": _LAST_LOAD_SOURCE,
        "last_error": _LAST_ERROR,
        "main_path": str(config_path(create=False)),
        "backup_path": str(backup_path()),
    }
