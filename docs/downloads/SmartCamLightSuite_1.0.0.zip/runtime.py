# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Finite event runtime for Smart CamLight.

Handlers only enqueue bounded work.  All camera/light synchronization executes
from one-shot continuations that always return ``None``.  With every live
feature disabled and no pending persistence write, this module owns no handler,
message-bus subscription, timer, thread, process, or worker.
"""

from __future__ import annotations

from collections import OrderedDict

import bpy
from bpy.app.handlers import persistent

from . import (
    cleanup,
    lifecycle,
    manager_bridge,
    operators,
    properties,
    scene_index,
    settings_store,
    status_runtime,
    ui,
)

_REGISTERED = False
_PROCESSING = False
_MAX_DIRTY_SCENES = 256
_MAX_DIRTY_IDS_PER_SCENE = 256
_DIRTY_SCENES: OrderedDict[int, dict] = OrderedDict()
_DIRTY_TIMER_KEY = "runtime:dirty_timer"
_DIRTY_TIMER_CALLBACK = None


def _pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value) if value is not None else 0


def _iter_scene_settings():
    try:
        scenes = tuple(getattr(bpy.data, "scenes", ()) or ())
    except Exception:
        scenes = ()
    for scene in scenes:
        settings = getattr(scene, "smart_camlight_suite", None)
        if settings is not None:
            yield scene, settings


def _needs_depsgraph(settings) -> bool:
    if settings is None:
        return False
    linked_name = str(getattr(settings, 'active_linked_object_name', '') or '')
    return bool(
        (getattr(settings, 'live_light_link_monitor', False) and linked_name)
        or getattr(settings, 'live_dynamic_sky_monitor', False)
        or getattr(settings, 'live_proxy_maintenance', False)
    )


def _needs_active_msgbus(settings) -> bool:
    return bool(settings and getattr(settings, 'auto_active_camera', False))


def _needs_frame(settings) -> bool:
    return bool(settings and (
        getattr(settings, "live_marker_camera_switch", False)
        or getattr(settings, "live_per_camera_sync", False)
        or getattr(settings, "live_motion_blur_sync", False)
    ))


def _needs_sky_msgbus(settings) -> bool:
    return bool(settings and getattr(settings, "live_dynamic_sky_monitor", False))


def _any_live_feature() -> bool:
    return any(
        _needs_depsgraph(settings)
        or _needs_frame(settings)
        or _needs_active_msgbus(settings)
        or _needs_sky_msgbus(settings)
        for _scene, settings in _iter_scene_settings()
    )


def _schedule_dirty_timer() -> None:
    global _DIRTY_TIMER_CALLBACK
    if not _DIRTY_SCENES:
        return
    current = _DIRTY_TIMER_CALLBACK
    if current is not None:
        try:
            if bpy.app.timers.is_registered(current):
                return
        except Exception:
            pass
        # An externally cancelled one-shot is released only through its exact
        # current-generation ledger entry before a replacement is acquired.
        lifecycle.release_resource_key(_DIRTY_TIMER_KEY)
        _DIRTY_TIMER_CALLBACK = None

    def continuation():
        return _process_dirty_timer(continuation)

    try:
        scheduled = lifecycle.schedule_one_shot_timer(_DIRTY_TIMER_KEY, continuation, first_interval=0.0)
        if scheduled:
            _DIRTY_TIMER_CALLBACK = continuation
    except lifecycle.ResourceIdentityError:
        return
    except Exception:
        # Keep dirty work queued. The next concrete event or settings update
        # retries exact acquisition; handlers never synchronize directly.
        return


def queue_scene_dirty(scene, reason: str, *, id_data=None) -> bool:
    if scene is None or not _REGISTERED:
        return False
    pointer = _pointer(scene)
    if not pointer:
        return False
    record = _DIRTY_SCENES.pop(pointer, None)
    if not isinstance(record, dict):
        record = {"scene": scene, "reasons": set(), "ids": OrderedDict()}
    record["scene"] = scene
    record.setdefault("reasons", set()).add(str(reason or "event"))
    ids = record.setdefault("ids", OrderedDict())
    id_pointer = _pointer(id_data)
    if id_pointer:
        ids.pop(id_pointer, None)
        ids[id_pointer] = id_data
        while len(ids) > _MAX_DIRTY_IDS_PER_SCENE:
            ids.popitem(last=False)
    _DIRTY_SCENES[pointer] = record
    while len(_DIRTY_SCENES) > _MAX_DIRTY_SCENES:
        _DIRTY_SCENES.popitem(last=False)
    _schedule_dirty_timer()
    return True


def _active_context_camera(scene):
    try:
        if bpy.context.scene is not scene:
            return None
        obj = bpy.context.view_layer.objects.active
        return obj if obj is not None and getattr(obj, "type", None) == "CAMERA" else None
    except Exception:
        return None


def _clear_stale_link_selection(scene, settings) -> None:
    if not getattr(settings, "live_light_link_monitor", False):
        return
    try:
        name = str(getattr(settings, "active_linked_object_name", "") or "")
        if name and scene.objects.get(name) is None:
            settings.active_linked_object_name = ""
    except Exception:
        pass


def _process_frame_work(scene, settings) -> None:
    camera = None
    if getattr(settings, "live_marker_camera_switch", False):
        try:
            camera = operators.camera_from_marker_at_frame(scene, scene.frame_current)
            if camera is not None and getattr(camera, "type", None) == "CAMERA":
                scene.camera = camera
                settings.active_camera_name = camera.name
        except Exception:
            camera = None
    if camera is None:
        camera = getattr(scene, "camera", None)
    if camera is None or getattr(camera, "type", None) != "CAMERA":
        return
    if getattr(settings, "live_per_camera_sync", False):
        try:
            operators.apply_camera_settings(None, camera, apply_overscan=True, scene=scene)
        except Exception:
            pass
    elif getattr(settings, "live_motion_blur_sync", False):
        try:
            operators.apply_motion_blur(scene, camera)
        except Exception:
            pass


def _process_depsgraph_work(scene, settings, reasons: set[str], dirty_ids=()) -> None:
    if 'active_camera' in reasons and getattr(settings, 'auto_active_camera', False):
        camera = _active_context_camera(scene)
        if camera is not None:
            try:
                if scene.camera is not camera:
                    scene.camera = camera
                if settings.active_camera_name != camera.name:
                    settings.active_camera_name = camera.name
            except Exception:
                pass
    if 'link_selection' in reasons:
        _clear_stale_link_selection(scene, settings)
    if reasons.intersection({'world_changed', 'dynamic_sky_settings', 'sky_dependency'}):
        if getattr(settings, 'live_dynamic_sky_monitor', False):
            try:
                if operators.dynamic_sky_needs_refresh(scene):
                    operators.refresh_dynamic_sky(scene)
            except Exception:
                pass
    if 'owned_proxy' in reasons and getattr(settings, 'live_proxy_maintenance', False):
        try:
            cleanup.clean_dirty_owned_ids(scene, dirty_ids)
        except Exception:
            pass


def _process_one(scene, reasons: set[str], dirty_ids=()) -> None:
    settings = getattr(scene, 'smart_camlight_suite', None)
    if settings is None:
        return
    if 'frame' in reasons:
        _process_frame_work(scene, settings)
    depsgraph_reasons = reasons.intersection({
        'active_camera',
        'link_selection',
        'world_changed',
        'dynamic_sky_settings',
        'sky_dependency',
        'owned_proxy',
    })
    if depsgraph_reasons:
        _process_depsgraph_work(scene, settings, depsgraph_reasons, dirty_ids)


def _process_dirty_timer(callback):
    global _PROCESSING, _DIRTY_TIMER_CALLBACK
    try:
        if _PROCESSING:
            return None
        _PROCESSING = True
        batch = tuple(_DIRTY_SCENES.values())
        _DIRTY_SCENES.clear()
        for record in batch:
            scene = record.get("scene") if isinstance(record, dict) else None
            reasons = set(record.get("reasons", ())) if isinstance(record, dict) else set()
            dirty_ids = tuple(record.get("ids", {}).values()) if isinstance(record, dict) else ()
            if scene is not None:
                _process_one(scene, reasons, dirty_ids)
        return None
    finally:
        _PROCESSING = False
        lifecycle.retire_one_shot_timer(_DIRTY_TIMER_KEY, callback)
        if _DIRTY_TIMER_CALLBACK is callback:
            _DIRTY_TIMER_CALLBACK = None
        # Work queued by the finite continuation is handed to a distinct
        # one-shot callback identity. This avoids re-registering the currently
        # executing Blender timer and never creates an idle poll.
        if _DIRTY_SCENES:
            _schedule_dirty_timer()


@persistent
def _depsgraph_event(scene=None, depsgraph=None):
    target = scene
    if target is None:
        try:
            target = bpy.context.scene
        except Exception:
            target = None
    settings = getattr(target, 'smart_camlight_suite', None) if target is not None else None
    if not _needs_depsgraph(settings):
        return
    try:
        updates = tuple(getattr(depsgraph, 'updates', ()) or ())
    except Exception:
        updates = ()
    if not updates:
        return

    reasons = set()
    linked_name = str(getattr(settings, 'active_linked_object_name', '') or '')
    sky_enabled = bool(getattr(settings, 'live_dynamic_sky_monitor', False))
    proxy_enabled = bool(getattr(settings, 'live_proxy_maintenance', False))
    owned_world = getattr(settings, 'dynamic_sky_owned_world', None) if sky_enabled else None
    owned_sun = getattr(settings, 'dynamic_sky_owned_sun', None) if sky_enabled else None
    sky_identities = {
        _pointer(value)
        for value in (
            owned_world,
            getattr(owned_world, 'node_tree', None),
            owned_sun,
            getattr(owned_sun, 'data', None),
        )
        if value is not None
    }

    sky_touched = False
    proxy_dirty_ids = []
    for update in updates:
        id_data = getattr(update, 'id', None)
        if id_data is None:
            continue
        if linked_name:
            identifier = str(getattr(getattr(id_data, 'bl_rna', None), 'identifier', '') or '')
            if identifier in {'Object', 'Collection', 'Scene'} or str(getattr(id_data, 'name', '') or '') == linked_name:
                reasons.add('link_selection')
        if sky_enabled and _pointer(id_data) in sky_identities:
            sky_touched = True
        if proxy_enabled:
            data = getattr(id_data, 'data', None)
            if cleanup.is_owned(id_data):
                reasons.add('owned_proxy')
                proxy_dirty_ids.append(id_data)
            if data is not None and cleanup.is_owned(data):
                reasons.add('owned_proxy')
                proxy_dirty_ids.append(data)
    if sky_touched:
        # Handlers only classify exact updated IDs and enqueue finite work.
        # Node graph comparison and synchronization run in the one-shot
        # continuation, never inside Blender's depsgraph callback.
        reasons.add('sky_dependency')
    for reason in reasons:
        queue_scene_dirty(target, reason)
    for id_data in proxy_dirty_ids:
        queue_scene_dirty(target, 'owned_proxy', id_data=id_data)


@persistent
def _frame_event(scene=None, depsgraph=None):
    settings = getattr(scene, "smart_camlight_suite", None) if scene is not None else None
    if _needs_frame(settings):
        queue_scene_dirty(scene, "frame")


def _world_msgbus_event(scene=None, *_args) -> None:
    # Each subscription is bound to one exact Scene RNA instance, so this
    # callback never scans every Scene and never synchronizes directly.
    settings = getattr(scene, 'smart_camlight_suite', None) if scene is not None else None
    if not _needs_sky_msgbus(settings):
        return
    # The message-bus callback is enqueue-only. Exact graph comparison and
    # synchronization are deferred to one finite one-shot continuation.
    queue_scene_dirty(scene, 'world_changed')


def _active_object_msgbus_event(*_args) -> None:
    try:
        scene = bpy.context.scene
    except Exception:
        scene = None
    settings = getattr(scene, 'smart_camlight_suite', None) if scene is not None else None
    if _needs_active_msgbus(settings):
        queue_scene_dirty(scene, 'active_camera')


def _sync_live_resources() -> None:
    scene_settings = tuple(_iter_scene_settings())
    needs_depsgraph = any(_needs_depsgraph(settings) for _scene, settings in scene_settings)
    needs_frame = any(_needs_frame(settings) for _scene, settings in scene_settings)
    sky_scenes = tuple(scene for scene, settings in scene_settings if _needs_sky_msgbus(settings))
    needs_sky_bus = bool(sky_scenes)
    needs_active_bus = any(_needs_active_msgbus(settings) for _scene, settings in scene_settings)

    handler_specs = (
        ('runtime:depsgraph', getattr(bpy.app.handlers, 'depsgraph_update_post', None), _depsgraph_event, needs_depsgraph),
        ('runtime:frame', getattr(bpy.app.handlers, 'frame_change_post', None), _frame_event, needs_frame),
    )
    for key, handler_list, callback, needed in handler_specs:
        if handler_list is None:
            continue
        if needed:
            lifecycle.register_handler(key, handler_list, callback)
        else:
            lifecycle.release_resource_key(key)

    if needs_sky_bus:
        lifecycle.register_msgbus_group(
            'runtime:sky_msgbus',
            tuple({
                'key': (scene, 'world'),
                'args': (scene,),
                'notify': _world_msgbus_event,
                'options': {'PERSISTENT'},
            } for scene in sky_scenes),
        )
    else:
        lifecycle.release_resource_key('runtime:sky_msgbus')

    if needs_active_bus and hasattr(bpy.types, 'LayerObjects'):
        lifecycle.register_msgbus_group(
            'runtime:active_msgbus',
            ({
                'key': (bpy.types.LayerObjects, 'active'),
                'args': (),
                'notify': _active_object_msgbus_event,
                'options': {'PERSISTENT'},
            },),
        )
    else:
        lifecycle.release_resource_key('runtime:active_msgbus')

    if not (needs_depsgraph or needs_frame or needs_sky_bus or needs_active_bus):
        _DIRTY_SCENES.clear()
        lifecycle.release_resource_key(_DIRTY_TIMER_KEY)


def on_settings_changed(scene=None) -> None:
    if not _REGISTERED:
        return
    try:
        _sync_live_resources()
    except Exception:
        pass
    if scene is not None:
        settings = getattr(scene, "smart_camlight_suite", None)
        if settings is not None and getattr(settings, "live_dynamic_sky_monitor", False):
            queue_scene_dirty(scene, "dynamic_sky_settings")


def notify_scene_structure_changed(scene) -> None:
    """Finite operator-boundary index update; no background resource is kept."""
    if scene is None:
        return
    scene_index.rebuild_scene(scene, ensure_uuids=True)



def _remove_exact_handler(handler_list, callback) -> int:
    """Remove only exact callback objects from one Blender handler list."""
    if handler_list is None or callback is None:
        return 0
    removed = 0
    for item in reversed(tuple(handler_list)):
        if item is callback:
            try:
                handler_list.remove(item)
                removed += 1
            except Exception:
                pass
    return removed


def unregister_local_async_resources() -> dict:
    """Unconditionally retire async resources originating from this copy.

    This runs before any generation/owner early return.  Direct handler removal
    uses exact function identity only; timers and msgbus owners are then retired
    through the generation ledger's exact identities.  Another imported copy is
    therefore unaffected even when it uses the same package/module names.
    """
    global _DIRTY_TIMER_CALLBACK
    removed_handlers = 0
    handler_specs = (
        (getattr(bpy.app.handlers, "depsgraph_update_post", None), _depsgraph_event),
        (getattr(bpy.app.handlers, "frame_change_post", None), _frame_event),
        (getattr(bpy.app.handlers, "save_pre", None), getattr(settings_store, "_deferred_save_pre", None)),
        (getattr(bpy.app.handlers, "load_pre", None), getattr(settings_store, "_deferred_load_pre", None)),
    )
    for handler_list, callback in handler_specs:
        removed_handlers += _remove_exact_handler(handler_list, callback)

    # The one-shot continuation is a closure, so keep and remove only its exact
    # object.  No timer is selected by name or module text.
    timer_callback = _DIRTY_TIMER_CALLBACK
    removed_timer = False
    if callable(timer_callback):
        try:
            if bpy.app.timers.is_registered(timer_callback):
                bpy.app.timers.unregister(timer_callback)
            removed_timer = not bpy.app.timers.is_registered(timer_callback)
        except Exception:
            removed_timer = False

    # Shared status cleanup first unregisters this module's exact V2 callback and
    # transfers remaining entries to a live provider copy.
    try:
        status_runtime.clear_prefix(status_runtime.SUITE_ID)
    except Exception:
        pass
    ledger_result = lifecycle.release_local_async_resources()
    _DIRTY_TIMER_CALLBACK = None
    return {
        "removed_handler_count": removed_handlers,
        "removed_dirty_timer": removed_timer,
        "ledger_released": tuple(ledger_result.get("released", ())),
        "ledger_failures": tuple(ledger_result.get("failures", ())),
    }

def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    status_runtime.register_runtime()
    properties.register()
    # One explicit lifecycle read. Applying the validated in-memory document
    # builds each Scene UUID index once; missing/corrupt input applies nothing.
    settings_store.load_payload()
    settings_store.apply_saved_settings_to_all_scenes()
    properties.sync_light_native_settings()
    properties.sync_target_display_sizes()
    manager_bridge.refresh_public_api()
    operators.register()
    ui.register()
    _REGISTERED = True
    _sync_live_resources()


def unregister() -> None:
    global _REGISTERED, _PROCESSING, _DIRTY_TIMER_CALLBACK
    # Must run before any owner/generation decision so a superseded copy cannot
    # leave its exact handlers, timer callbacks or msgbus owners behind.
    unregister_local_async_resources()
    try:
        settings_store.unregister()
    except Exception:
        pass
    _DIRTY_SCENES.clear()
    for key in (
        _DIRTY_TIMER_KEY,
        'runtime:active_msgbus',
        'runtime:sky_msgbus',
        'runtime:frame',
        'runtime:depsgraph',
    ):
        lifecycle.release_resource_key(key)
    scene_index.clear()
    status_runtime.clear_prefix(status_runtime.SUITE_ID)
    _PROCESSING = False
    _DIRTY_TIMER_CALLBACK = None
    _REGISTERED = False


def verify_ready() -> bool:
    if not _REGISTERED:
        return False
    if len(operators.CLASSES) != 50 or len(ui.CLASSES) != 12 or len(properties.CLASSES) != 4:
        return False
    native_roots = tuple(getattr(ui, "NATIVE_ROOT_CLASSES", ()))
    if len(native_roots) != 12:
        return False
    expected_spaces = {
        "VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR",
        "CLIP_EDITOR", "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR",
        "TEXT_EDITOR", "FILE_BROWSER", "SPREADSHEET",
    }
    expected_regions = {(space, "UI") for space in expected_spaces} | {("FILE_BROWSER", "TOOL_PROPS")}
    if {(cls.bl_space_type, cls.bl_region_type) for cls in native_roots} != expected_regions:
        return False
    for cls in native_roots:
        if str(getattr(cls, "bl_category", "") or "") != "Smart CamLight":
            return False
        if str(getattr(cls, "_smart_tools_manager_tool_key", "") or "") != "SMART_CAMLIGHT":
            return False
        if getattr(cls, "_smart_tools_manager_native_npanel_root", None) is not True:
            return False
        if str(getattr(cls, "bl_parent_id", "") or ""):
            return False
    required_classes = tuple(properties.CLASSES) + tuple(operators.CLASSES) + tuple(ui.CLASSES)
    if not all(lifecycle.class_identity_live(cls) for cls in required_classes):
        return False
    return lifecycle.verify_generation()


def audit_snapshot() -> dict:
    resources = lifecycle.serializable_snapshot()
    active = resources.get("generations", {}).get(lifecycle.GENERATION, {})
    kinds = list(active.get("resource_kinds", ()))
    keys = list(active.get("resource_keys", ()))
    return {
        "registered": _REGISTERED,
        "dirty_scene_count": len(_DIRTY_SCENES),
        "processing": _PROCESSING,
        "live_handler_keys": [key for key in keys if key.startswith("runtime:") and key in {"runtime:depsgraph", "runtime:frame"}],
        "live_timer_keys": [key for key, kind in zip(keys, kinds) if kind == "timer"],
        "live_msgbus_keys": [key for key, kind in zip(keys, kinds) if kind == "msgbus"],
        "worker_count": 0,
        "thread_count": 0,
        "process_count": 0,
        "max_dirty_scenes": _MAX_DIRTY_SCENES,
        "max_dirty_ids_per_scene": _MAX_DIRTY_IDS_PER_SCENE,
        "dirty_id_count": sum(len(record.get("ids", {})) for record in _DIRTY_SCENES.values() if isinstance(record, dict)),
        "any_live_feature": _any_live_feature() if _REGISTERED else False,
        "registered_panel_count": len(ui.CLASSES),
        "native_npanel_root_count": len(getattr(ui, "NATIVE_ROOT_CLASSES", ())),
        "native_npanel_root_spaces": tuple(
            str(getattr(cls, "bl_space_type", "") or "")
            for cls in getattr(ui, "NATIVE_ROOT_CLASSES", ())
        ),
    }
