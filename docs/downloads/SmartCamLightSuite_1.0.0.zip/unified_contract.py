# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
EXTENSION_ID = "smart_camlight_suite"
CONFIG_FOLDER = "Smart_CamLight_Suite"
CONFIG_FILE = "Smart_CamLight_Suite.json"
STATE_SAVE_PATH = "scene.smart_camlight_suite.n_panel_state_save"
SECTION_OPEN_PATH = "scene.smart_camlight_suite.ui_section_always_on"
RUNTIME_TOGGLE_PATHS = (
    "scene.smart_camlight_suite.auto_active_camera",
    "scene.smart_camlight_suite.live_per_camera_sync",
    "scene.smart_camlight_suite.live_marker_camera_switch",
    "scene.smart_camlight_suite.live_motion_blur_sync",
    "scene.smart_camlight_suite.live_light_link_monitor",
    "scene.smart_camlight_suite.live_dynamic_sky_monitor",
    "scene.smart_camlight_suite.live_proxy_maintenance",
)
ROOT_PANEL_IDS = (
    "VIEW3D_PT_scls_root",
    "IMAGE_PT_scls_image_root",
    "NODE_PT_scls_shader_root",
    "SEQUENCER_PT_scls_root",
    "CLIP_PT_scls_root",
    "DOPESHEET_PT_scls_root",
    "GRAPH_PT_scls_root",
    "NLA_PT_scls_root",
    "TEXT_PT_scls_root",
    "FILEBROWSER_PT_scls_root",
    "FILEBROWSER_PT_scls_assets_root",
    "SPREADSHEET_PT_scls_root",
)
LEGACY_LOGICAL_PANEL_IDS = ()
LOGICAL_EDITOR_KEYS = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "UV_EDITOR",
    "SHADER_EDITOR",
    "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR",
    "TEXTURE_NODE_EDITOR",
    "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR",
    "DOPE_SHEET",
    "GRAPH_EDITOR",
    "DRIVERS",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "ASSET_BROWSER",
    "FILE_BROWSER",
    "SPREADSHEET",
)

PERSISTENCE_ROOTS = (
    "scene.smart_camlight_suite",
    "camera.smart_camlight_settings",
    "object.smart_camlight_object",
    "light.smart_camlight_light",
)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.smart_camlight_suite.overscan_original_x",
    "scene.smart_camlight_suite.overscan_original_y",
    "scene.smart_camlight_suite.overscan_original_percentage",
    "scene.smart_camlight_suite.overscan_applied_x",
    "scene.smart_camlight_suite.overscan_applied_y",
    "scene.smart_camlight_suite.name",
    "camera.smart_camlight_settings.name",
    "object.smart_camlight_object.name",
    "object.smart_camlight_object.is_generated_light",
    "light.smart_camlight_light.name",
)
BLEND_OWNED_NPANEL_PATHS = (
    # Native datablock content is saved by the .blend itself.  These controls
    # are intentionally audited separately from portable suite preferences.
    "object.name",
    "object.location",
    "object.rotation_euler",
)
