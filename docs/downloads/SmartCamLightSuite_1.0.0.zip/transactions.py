# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
"""Finite rollback ledgers for Smart CamLight scene operations."""

from __future__ import annotations

from dataclasses import dataclass
import uuid
from typing import Callable

import bpy

TRANSACTION_UUID_KEY = "_scls_transaction_uuid"


def _copy_value(value):
    # ID.copy() would duplicate the datablock; a snapshot keeps the reference.
    if isinstance(value, bpy.types.ID):
        return value
    # An ID property value is only a view of its owner: keep a detached copy,
    # because replacing the property frees what the view points at.
    for detach in ('to_dict', 'to_list'):
        method = getattr(value, detach, None)
        if method is not None:
            return method()
    try:
        return value.copy()
    except Exception:
        pass
    if isinstance(value, (tuple, list, dict, set)):
        try:
            return type(value)(value)
        except Exception:
            pass
    return value


def _idprop(value, key: str, default=""):
    try:
        return value.get(key, default)
    except Exception:
        return default


def _set_idprop(value, key: str, data) -> None:
    try:
        value[key] = data
    except Exception:
        pass


@dataclass
class _Created:
    value: object
    remover: Callable[[object], None]


class DataTransaction:
    """Record exact mutations and generated IDs until one top-level commit."""

    def __init__(self, label: str = "Smart CamLight"):
        self.label = str(label or "Smart CamLight")
        self.uuid = str(uuid.uuid4())
        self._mutations: list[tuple[object, str, object]] = []
        self._created: list[_Created] = []
        self._rollback_actions: list[Callable[[], None]] = []
        self._commit_actions: list[Callable[[], None]] = []
        self._snapshots: set[tuple[int, str]] = set()
        self._mapping_snapshots: set[tuple[int, str]] = set()
        self._finished = False
        self.commit_failures: list[str] = []

    def snapshot_attr(self, owner, attr: str) -> bool:
        if owner is None or not attr:
            return False
        key = (id(owner), str(attr))
        if key in self._snapshots:
            return True
        try:
            old = _copy_value(getattr(owner, attr))
        except Exception:
            return False
        self._snapshots.add(key)
        self._mutations.append((owner, str(attr), old))
        return True

    def set_attr(self, owner, attr: str, value) -> bool:
        if owner is None or not hasattr(owner, attr):
            return False
        if not self.snapshot_attr(owner, attr):
            return False
        try:
            setattr(owner, attr, value)
            return True
        except Exception:
            return False

    def snapshot_item(self, owner, key: str) -> bool:
        if owner is None or not key:
            return False
        token = (id(owner), str(key))
        if token in self._mapping_snapshots:
            return True
        try:
            exists = str(key) in owner
            old = _copy_value(owner[str(key)]) if exists else None
        except Exception:
            return False
        self._mapping_snapshots.add(token)

        def restore():
            try:
                if exists:
                    owner[str(key)] = old
                elif str(key) in owner:
                    del owner[str(key)]
            except Exception:
                pass

        self._rollback_actions.append(restore)
        return True

    def set_item(self, owner, key: str, value) -> bool:
        if not self.snapshot_item(owner, key):
            return False
        try:
            owner[str(key)] = value
            return True
        except Exception:
            return False

    def track_collection_link(self, collection, obj) -> None:
        def unlink():
            try:
                collection.objects.unlink(obj)
            except Exception:
                pass
        self.add_rollback(unlink)

    def add_rollback(self, action: Callable[[], None]) -> None:
        if callable(action):
            self._rollback_actions.append(action)

    def defer_commit(self, action: Callable[[], None]) -> None:
        if callable(action):
            self._commit_actions.append(action)

    def track_created(self, value, remover: Callable[[object], None]) -> object:
        if value is None or not callable(remover):
            return value
        _set_idprop(value, TRANSACTION_UUID_KEY, self.uuid)
        self._created.append(_Created(value=value, remover=remover))
        return value

    def track_object(self, obj) -> object:
        def remove(value):
            try:
                bpy.data.objects.remove(value, do_unlink=True)
            except Exception:
                pass
        return self.track_created(obj, remove)

    def track_datablock(self, collection, value) -> object:
        def remove(item):
            try:
                collection.remove(item)
            except TypeError:
                try:
                    collection.remove(item, do_unlink=True)
                except Exception:
                    pass
            except Exception:
                pass
        return self.track_created(value, remove)

    def track_constraint(self, owner, constraint) -> object:
        def remove(item):
            try:
                owner.constraints.remove(item)
            except Exception:
                pass
        # Constraints cannot hold ID properties; rollback uses the exact object.
        self._created.append(_Created(value=constraint, remover=remove))
        return constraint

    def commit(self) -> bool:
        if self._finished:
            return False
        # Irreversible cleanup is deliberately delayed until all new IDs and
        # RNA mutations succeeded.  A failed cleanup leaves old owned helpers
        # in place rather than destroying user/foreign data or rolling back a
        # valid replacement.
        for action in tuple(self._commit_actions):
            try:
                action()
            except Exception as exc:
                self.commit_failures.append(str(exc)[:240])
        # The transaction token is rollback-only metadata.  Do not leave it on
        # successfully committed Blender IDs.
        for created in tuple(self._created):
            value = created.value
            try:
                if _idprop(value, TRANSACTION_UUID_KEY, "") == self.uuid and TRANSACTION_UUID_KEY in value:
                    del value[TRANSACTION_UUID_KEY]
            except Exception:
                pass
        self._finished = True
        self._mutations.clear()
        self._mapping_snapshots.clear()
        self._created.clear()
        self._rollback_actions.clear()
        self._commit_actions.clear()
        return True

    def rollback(self) -> bool:
        if self._finished:
            return False
        for action in reversed(tuple(self._rollback_actions)):
            try:
                action()
            except Exception:
                pass
        # Restore references before deleting IDs created by this transaction.
        # This is required for World/Object PointerProperties: attempting ID
        # removal while Scene or PropertyGroup RNA still references the new ID
        # can fail and leak a half-created datablock.
        for owner, attr, old in reversed(tuple(self._mutations)):
            try:
                setattr(owner, attr, old)
            except Exception:
                pass
        for created in reversed(tuple(self._created)):
            value = created.value
            # ID datablocks are removed only when they still carry this exact
            # transaction UUID.  Constraints are safe because the exact object
            # identity is retained.
            if isinstance(value, bpy.types.ID) and _idprop(value, TRANSACTION_UUID_KEY, "") != self.uuid:
                continue
            try:
                created.remover(value)
            except Exception:
                pass
        self._finished = True
        self._mutations.clear()
        self._mapping_snapshots.clear()
        self._created.clear()
        self._rollback_actions.clear()
        self._commit_actions.clear()
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, _traceback):
        if exc_type is not None:
            self.rollback()
            return False
        if not self._finished:
            self.rollback()
        return False
