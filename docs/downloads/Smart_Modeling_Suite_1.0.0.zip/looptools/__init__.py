bl_info = {
    "name": "Loop Tools",
    "author": "Bart Crouch, Vladimir Spivak (cwolf3d)",
    "version": (4, 7, 7),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Edit Tab / Edit Mode Context Menu",
    "warning": "",
    "description": "Mesh modelling toolkit. Several tools to aid modelling",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/mesh/looptools.html",
    "category": "Mesh",
}


import bmesh
import bpy
import collections
import mathutils
import math
from bpy_extras import view3d_utils
from bpy.types import (
        Operator,
        Menu,
        Panel,
        PropertyGroup,
        )
from bpy.props import (
        BoolProperty,
        EnumProperty,
        FloatProperty,
        IntProperty,
        PointerProperty,
        StringProperty,
        )
from .. import preferences
from ..utils import draw_section_help

# ########################################
# ##### General functions ################
# ########################################

# used by all tools to improve speed on reruns Unlink
looptools_cache = {}


def _active_annotation_layer(context):
    annotation = context.scene.annotation
    if annotation is None:
        return None
    layers = annotation.layers
    index = layers.active_index
    return layers[index] if 0 <= index < len(layers) else None


def _gpencil_guide_strokes(looptools):
    """Return the guide object's visible strokes in world coordinates."""
    guide = looptools.gstretch_guide
    layer = guide.data.layers.active
    frame = layer.current_frame()
    matrix = guide.matrix_world
    strokes = []
    for index, stroke in enumerate(frame.drawing.strokes):
        fake_stroke = gstretch_fake_stroke([matrix @ point.position for point in stroke.points])
        fake_stroke.gpencil_index = index
        strokes.append(fake_stroke)
    return strokes


def get_strokes(self, context):
    looptools =  context.window_manager.looptools
    if looptools.gstretch_use_guide == "Annotation":
        try:
            strokes = _active_annotation_layer(context).active_frame.strokes
            return True
        except:
            self.report({'WARNING'}, "active Annotation strokes not found")
            return False
    if looptools.gstretch_use_guide == "GPencil" and not looptools.gstretch_guide == None:
        try:
            return bool(_gpencil_guide_strokes(looptools))
        except:
            self.report({'WARNING'}, "active GPencil strokes not found")
            return False
    else:
        return False

# force a full recalculation next time
def cache_delete(tool):
    if tool in looptools_cache:
        del looptools_cache[tool]


# check cache for stored information
def cache_read(tool, obj, mesh, input_method, boundaries):
    entry = looptools_cache.get(tool)
    if entry is None or entry['signature'] != _loop_input_signature(obj, mesh, input_method, boundaries):
        return (False,) * 5
    return (True, entry['single_loops'], entry['loops'], entry['derived'], entry['mapping'])


# store information in the cache
def cache_write(tool, obj, mesh, input_method, boundaries, single_loops, loops, derived, mapping):
    looptools_cache[tool] = dict(
        signature=_loop_input_signature(obj, mesh, input_method, boundaries),
        single_loops=single_loops,
        loops=loops,
        derived=derived,
        mapping=mapping,
    )


# calculates natural cubic splines through all given knots
def calculate_cubic_splines(bm_mod, tknots, knots):
    """Solve the natural cubic's tridiagonal second-derivative system in linear time."""
    if knots[0] == knots[-1]:
        if len(knots) == 1:
            return False
        period = tknots[-1] - tknots[0]
        count = len(knots)
        before = [j % count for j in range(-5, -1)]
        after = [j % count for j in range(1, 5)]
        # The consumer uses these expanded parameters to look up its interval.
        tknots[:] = [tknots[j] - period for j in before] + tknots + [tknots[j] + period for j in after]
        knots[:] = [knots[j] for j in before] + knots + [knots[j] for j in after]
    widths = [(b - a) or 1.0e-8 for a, b in zip(tknots, tknots[1:])]
    count = len(knots)
    if count < 2:
        return False
    coords = [tuple(bm_mod.verts[j].co) for j in knots]
    curvature = [[0.0] * 3 for _ in knots]
    slopes = [[(b - a) / width for a, b in zip(start, end)]
              for start, end, width in zip(coords, coords[1:], widths)]
    upper = [0.0] * count
    for i in range(1, count - 1):
        left, right = widths[i - 1:i + 1]
        pivot = 2 * (left + right) - left * upper[i - 1]
        if pivot == 0.0:
            # Repeated anchors in short cyclic compatibility inputs can cancel
            # one elimination pivot. Use a pivoted solve for these small loops.
            import numpy as np
            system = np.zeros((count, count), dtype=float)
            system[0, 0] = system[-1, -1] = 1.0
            rhs = np.zeros((count, 3), dtype=float)
            for row in range(1, count - 1):
                h0, h1 = widths[row - 1:row + 1]
                system[row, row - 1:row + 2] = (h0, 2 * (h0 + h1), h1)
                rhs[row] = 6 * (np.asarray(slopes[row]) - slopes[row - 1])
            curvature = np.linalg.solve(system, rhs).tolist()
            break
        upper[i] = right / pivot
        curvature[i] = [(6 * (slopes[i][k] - slopes[i - 1][k]) - left * curvature[i - 1][k]) / pivot
                        for k in range(3)]
    else:
        for i in range(count - 2, 0, -1):
            curvature[i] = [a - upper[i] * b for a, b in zip(curvature[i], curvature[i + 1])]
    segments = []
    for i, width in enumerate(widths):
        segment = []
        for k in range(3):
            a, b = curvature[i][k], curvature[i + 1][k]
            tangent = slopes[i][k] - width * (2 * a + b) / 6
            segment.append([coords[i][k], tangent, a / 2, (b - a) / (6 * width), tknots[i]])
        segments.append(segment)
    return segments


# calculates linear splines through all given knots
def calculate_linear_splines(bm_mod, tknots, knots):
    segments = []
    for i, (a, b) in enumerate(zip(knots, knots[1:])):
        start = bm_mod.verts[a].co
        delta = bm_mod.verts[b].co - start
        segments.append([start.copy(), delta, tknots[i], tknots[i + 1] - tknots[i]])
    return segments


# calculate a best-fit plane to the given vertices
def calculate_plane(bm_mod, loop, method="best_fit", object=False):
    """The least-squares plane has the direction of least positional variance as its normal."""
    verts = [bm_mod.verts[index] for index in loop[0]]
    center = sum((v.co for v in verts), mathutils.Vector()) / len(verts)
    if method == "view":
        view = bpy.context.space_data.region_3d.view_matrix
        normal = view.inverted_safe().to_3x3() @ mathutils.Vector((0, 0, 1))
        if object:
            normal = object.matrix_world.to_3x3().transposed() @ normal
    elif method == "normal":
        normal = sum((v.normal for v in verts), mathutils.Vector())
    else:
        import numpy as np
        positions = np.asarray([tuple(v.co) for v in verts], dtype=float)
        centered = positions - positions.mean(axis=0)
        values, axes = np.linalg.eigh(centered.T @ centered)
        scale = max(abs(values[-1]), 1.0e-30)
        lowest = axes[:, values <= values[0] + scale * 1.0e-12]
        # Collinear or coincident guides admit many equally good planes.
        # Choose the world Z axis projected into that eigenspace, then Y or X.
        if lowest.shape[1] > 1:
            for axis in ((0,0,1), (0,1,0), (1,0,0)):
                direction = lowest @ (lowest.T @ axis)
                if np.linalg.norm(direction) > 1.0e-9:
                    break
        else:
            direction = lowest[:, 0]
            if sum(direction) < 0:
                direction = -direction
        normal = mathutils.Vector(direction)
    return center, normal.normalized()


# calculate splines based on given interpolation method (controller function)
def calculate_splines(interpolation, bm_mod, tknots, knots):
    if interpolation == 'cubic':
        splines = calculate_cubic_splines(bm_mod, tknots, knots[:])
    else:  # interpolations == 'linear'
        splines = calculate_linear_splines(bm_mod, tknots, knots[:])

    return(splines)


# check loops and only return valid ones
def check_loops(loops, mapping, mesh):
    def usable(indices):
        if len(indices) < 3 or (mapping and not any(mapping[index] >= 0 for index in indices)):
            return False
        vertices = mesh.verts
        return any((vertices[right].co - vertices[left].co).length > 1e-6
                   for left, right in zip(indices, indices[1:]))
    return [[indices, closed] for indices, closed in loops if usable(indices)]


# input: bmesh, output: dict with the edge-key as key and face-index as value
def dict_edge_faces(bm):
    visible = {edgekey(edge): [] for edge in bm.edges if not edge.hide}
    for face in bm.faces:
        if not face.hide:
            for key in face_edgekeys(face):
                if key in visible:
                    visible[key].append(face.index)
    return visible


# input: bmesh (edge-faces optional), output: dict with face-face connections
def dict_face_faces(bm, edge_faces=False):
    incident = edge_faces if edge_faces is not False else dict_edge_faces(bm)
    return {
        face.index: [other for key in face_edgekeys(face)
                     for other in incident.get(key, ()) if other != face.index]
        for face in bm.faces if not face.hide
    }


# input: bmesh, output: dict with the vert index as key and edge-keys as value
def dict_vert_edges(bm):
    incident = {v.index: [] for v in bm.verts if not v.hide}
    for edge in bm.edges:
        if not edge.hide:
            key = edgekey(edge)
            for index in key:
                if index in incident:
                    incident[index].append(key)
    return incident


# input: bmesh, output: dict with the vert index as key and face index as value
def dict_vert_faces(bm):
    faces = {v.index: [] for v in bm.verts if not v.hide}
    for face in bm.faces:
        if not face.hide:
            for vertex in face.verts:
                if vertex.index in faces:
                    faces[vertex.index].append(face.index)
    return faces


# input: list of edge-keys, output: dictionary with vertex-vertex connections
def dict_vert_verts(edge_keys):
    neighbors = {}
    for a, b in edge_keys:
        neighbors.setdefault(a, []).append(b)
        neighbors.setdefault(b, []).append(a)
    return neighbors


# return the edgekey ([v1.index, v2.index]) of a bmesh edge
def edgekey(edge):
    return(tuple(sorted([edge.verts[0].index, edge.verts[1].index])))


# returns the edgekeys of a bmesh face
def face_edgekeys(face):
    return([tuple(sorted([edge.verts[0].index, edge.verts[1].index])) for edge in face.edges])


# calculate input loops
def get_connected_input(obj, mesh, bypass_mirror, input):
    mirrored, evaluated = get_derived_bmesh(obj, mesh, bypass_mirror)
    traversable = [edgekey(edge) for edge in evaluated.edges if (not edge.hide) and edge.select]
    selected = get_connected_selections(traversable)
    output = selected if input == 'selected' else get_parallel_loops(evaluated, selected)
    return mirrored, evaluated, output


# sorts all edge-keys into a list of loops
def get_connected_selections(edge_keys):
    """Split a selection into open trails or rings in input incidence order."""
    remaining = dict_vert_verts(edge_keys)
    loops = []
    for start, incident in remaining.items():
        while incident:
            path = [start]
            used = {start}
            for side in range(2):
                if side:
                    path.reverse()
                while True:
                    end = path[-1]
                    candidate = next((v for v in remaining[end] if v not in used), None)
                    if candidate is None:
                        break
                    remaining[end].remove(candidate)
                    remaining[candidate].remove(end)
                    path.append(candidate)
                    used.add(candidate)
            first, last = path[0], path[-1]
            closed = first in remaining[last]
            if closed:
                remaining[last].remove(first)
                remaining[first].remove(last)
            loops.append([path, closed])
    return loops


# get the derived mesh data, if there is a mirror modifier
def get_derived_bmesh(object, bm, not_use_mirror):
    visible = [modifier for modifier in object.modifiers if modifier.show_viewport]
    use_evaluated = any(modifier.type == 'MIRROR' for modifier in visible)
    result = bm
    if use_evaluated:
        hidden = [modifier for modifier in visible if modifier.type != 'MIRROR']
        mergers = [modifier for modifier in visible if modifier.type == 'MIRROR'
                   and not_use_mirror and modifier.use_mirror_merge]
        result = bmesh.new()
        try:
            for modifier in hidden:
                modifier.show_viewport = False
            for modifier in mergers:
                modifier.use_mirror_merge = False
            evaluated = object.evaluated_get(bpy.context.evaluated_depsgraph_get())
            try:
                result.from_mesh(evaluated.to_mesh())
            finally:
                evaluated.to_mesh_clear()
        except BaseException:
            result.free()
            raise
        finally:
            for modifier in mergers:
                modifier.use_mirror_merge = True
            for modifier in hidden:
                modifier.show_viewport = True

    for elements in (result.verts, result.edges, result.faces):
        elements.ensure_lookup_table()
    return use_evaluated, result


# return a mapping of derived indices to indices
def get_mapping(derived, bm, bm_mod, single_vertices, full_search, loops):
    if not derived:
        return False

    source = {vertex.index: vertex for vertex in bm.verts
              if not vertex.hide and (full_search or vertex.select)}
    if single_vertices:
        singles = _mesh_position_index(bm_mod, single_vertices)
        origins = {}
        for vertex in source.values():
            match = next(_position_matches(singles, vertex.co), None)
            if match is not None:
                origins[match] = vertex.index
        affected = set(origins.values())
        for face in bm.faces:
            if not (face.select or face.hide) and any(v.index in affected for v in face.verts):
                for vertex in face.verts:
                    source.setdefault(vertex.index, vertex)

    result = dict.fromkeys((index for vertices, _ in loops for index in vertices), -1)
    for index in single_vertices or ():
        result.setdefault(index, -1)
    if not result:
        return result

    destinations = _mesh_position_index(bm_mod, result)
    pending = set(result)
    for vertex in source.values():
        for match in _position_matches(destinations, vertex.co):
            if match in pending:
                result[match] = vertex.index
                pending.remove(match)
                break
        if not pending:
            break
    return result


# calculate the determinant of a matrix
def matrix_determinant(m):
    return mathutils.Matrix(m).to_3x3().determinant()


# custom matrix inversion, to provide higher precision than the built-in one
def matrix_invert(m):
    matrix = mathutils.Matrix(m).to_3x3()
    try:
        return matrix.inverted()
    except ValueError as error:
        raise ZeroDivisionError("singular 3D matrix") from error


# returns a list of all loops parallel to the input, input included
def get_parallel_loops(bm_mod, loops):
    """Grow neighboring edge paths through side-connected strips of visible faces."""
    incidence = dict_edge_faces(bm_mod)
    neighbors = {face: set(adjacent) for face, adjacent in dict_face_faces(bm_mod, incidence).items()}

    def strip_faces(path):
        strips = [[], []]
        for edge in path:
            assigned = set()
            for face in incidence[edge]:
                for side, strip in enumerate(strips):
                    if side not in assigned and (not strip or strip[-1] in neighbors[face]):
                        strip.append(face)
                        assigned.add(side)
                        break
                if len(assigned) == len(strips):
                    break
        return strips

    def next_edges(strip, reached):
        edges = []
        for face_index in strip:
            face = bm_mod.faces[face_index]
            opposite = next((key for key in face_edgekeys(face) if reached.isdisjoint(key)), None)
            if opposite is not None:
                edges.append(opposite)
        return edges

    def to_vertices(edges):
        shared_vertices = []
        for edge, following in zip(edges, edges[1:]):
            junction = next((vertex for vertex in edge if vertex in following), None)
            if junction is not None:
                shared_vertices.append(junction)
        if not shared_vertices:
            return [[], False]
        first = next(vertex for vertex in edges[0] if vertex != shared_vertices[0])
        last = next(vertex for vertex in edges[-1] if vertex != shared_vertices[-1])
        return [[first, *shared_vertices] if first == last else [first, *shared_vertices, last],
                first == last]

    paths = []
    for vertices, closed in loops:
        walk = [*vertices, vertices[0]] if closed and vertices else vertices
        seed = [tuple(sorted(pair)) for pair in zip(walk, walk[1:])]
        reached = set(walk)
        pending = [seed]
        paths.append(seed)
        while pending:
            path = pending.pop()
            if any(edge not in incidence for edge in path):
                return loops
            for strip in strip_faces(path):
                adjacent = next_edges(strip, reached)
                if adjacent:
                    for edge in adjacent:
                        reached.update(edge)
                    paths.append(adjacent)
                    pending.append(adjacent)

    return [to_vertices(path) for path in paths]


# gather initial data
def initialise():
    active = bpy.context.view_layer.objects.active
    needs_sync = any(modifier.show_viewport and modifier.type == 'MIRROR' for modifier in active.modifiers)
    if needs_sync:
        for mode in ('OBJECT', 'EDIT'):
            bpy.ops.object.mode_set(mode=mode)
    mesh = bmesh.from_edit_mesh(active.data)
    for elements in (mesh.verts, mesh.edges, mesh.faces):
        elements.ensure_lookup_table()
    return active, mesh


# move the vertices to their new locations
def move_verts(object, bm, mapping, move, lock, influence):
    axes = _editing_coordinates(object, bpy.context) if lock else None
    inverse = axes.inverted() if axes is not None else None
    blend = influence / 100.0
    vertices = bm.verts
    reflections = _reflections(object.data)
    for positions in move:
        for index, requested in positions:
            local_index = mapping[index] if mapping else index
            if local_index < 0:
                continue
            vertex = vertices[local_index]
            original = vertex.co.copy()
            if axes is not None:
                delta = (requested - original) @ inverse
                for component, is_locked in enumerate(lock):
                    if is_locked:
                        delta[component] = 0
                requested = original + delta @ axes
            destination = requested if influence < 0 else requested * blend + original * ((100 - influence) / 100)
            for reflection in reflections:
                reflected_destination = reflection * destination
                for counterpart in vertices:
                    if counterpart.co == reflection * vertex.co:
                        counterpart.co = reflected_destination
            vertex.co = destination

    bm.normal_update()
    object.data.update()
    for elements in (vertices, bm.edges, bm.faces):
        elements.ensure_lookup_table()


# load custom tool settings
def settings_load(operator):
    preferences = bpy.context.window_manager.looptools
    for public_name, saved_name in _preference_links(operator):
        setattr(operator, public_name, getattr(preferences, saved_name))


# store custom tool settings
def settings_write(operator):
    preferences = bpy.context.window_manager.looptools
    for public_name, saved_name in _preference_links(operator):
        setattr(preferences, saved_name, getattr(operator, public_name))


# clean up and set settings back to original state
def terminate():
    # update editmesh cached data
    obj = bpy.context.active_object
    if obj.mode == 'EDIT':
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)


# ########################################
# ##### Bridge functions #################
# ########################################

# calculate a cubic spline through the middle section of 4 given coordinates
def bridge_calculate_cubic_spline(_mesh, coordinates):
    # Unit-spaced natural cubic: solve the two interior curvatures directly.
    coefficients = []
    for start, left, right, end in zip(*coordinates, strict=True):
        before = 3.0 * (right - 2.0 * left + start)
        after = 3.0 * (end - 2.0 * right + left)
        bend_left = (4.0 * before - after) / 15.0
        bend_right = (4.0 * after - before) / 15.0
        slope = right - left - (2.0 * bend_left + bend_right) / 3.0
        coefficients.append([left, slope, bend_left, (bend_right - bend_left) / 3.0, 1])
    return coefficients


# return a list with new vertex location vectors, a list with face vertex
# integers, and the highest vertex integer in the virtual mesh
def bridge_calculate_geometry(bm, lines, vertex_normals, segments,
interpolation, cubic_strength, min_width, max_vert_index):
    new_verts = []
    faces = []

    # calculate location based on interpolation method
    def get_location(line, segment, splines):
        fraction = segment / segments
        if interpolation == 'cubic':
            return mathutils.Vector(tuple(
                start + fraction * (slope + fraction * (curve + fraction * correction))
                for start, slope, curve, correction, _ in splines[line]
            ))
        first, last = lines[line]
        return bm.verts[first].co.lerp(bm.verts[last].co, fraction)

    # no interpolation needed
    if segments == 1:
        for i, line in enumerate(lines):
            if i < len(lines) - 1:
                faces.append([line[0], lines[i + 1][0], lines[i + 1][1], line[1]])
    # more than 1 segment, interpolate
    else:
        # calculate splines (if necessary) once, so no recalculations needed
        if interpolation == 'cubic':
            splines = []
            for line in lines:
                v1 = bm.verts[line[0]].co
                v2 = bm.verts[line[1]].co
                size = (v2 - v1).length * cubic_strength
                splines.append(bridge_calculate_cubic_spline(bm,
                    [v1 + size * vertex_normals[line[0]], v1, v2,
                    v2 + size * vertex_normals[line[1]]]))
        else:
            splines = False

        # create starting situation
        virtual_width = [(bm.verts[lines[i][0]].co -
                          bm.verts[lines[i + 1][0]].co).length for i
                          in range(len(lines) - 1)]
        new_verts = [get_location(0, seg, splines) for seg in range(1,
            segments)]
        first_line_indices = [i for i in range(max_vert_index + 1,
            max_vert_index + segments)]

        prev_verts = new_verts[:]  # vertex locations of verts on previous line
        prev_vert_indices = first_line_indices[:]
        max_vert_index += segments - 1  # highest vertex index in virtual mesh
        next_verts = []  # vertex locations of verts on current line
        next_vert_indices = []

        for i, line in enumerate(lines):
            if i < len(lines) - 1:
                v1 = line[0]
                v2 = lines[i + 1][0]
                end_face = True
                for seg in range(1, segments):
                    loc1 = prev_verts[seg - 1]
                    loc2 = get_location(i + 1, seg, splines)
                    if (loc1 - loc2).length < (min_width / 100) * virtual_width[i] \
                      and line[1] == lines[i + 1][1]:
                        # triangle, no new vertex
                        faces.append([v1, v2, prev_vert_indices[seg - 1],
                            prev_vert_indices[seg - 1]])
                        next_verts += prev_verts[seg - 1:]
                        next_vert_indices += prev_vert_indices[seg - 1:]
                        end_face = False
                        break
                    else:
                        if i == len(lines) - 2 and lines[0] == lines[-1]:
                            # quad with first line, no new vertex
                            faces.append([v1, v2, first_line_indices[seg - 1],
                                prev_vert_indices[seg - 1]])
                            v2 = first_line_indices[seg - 1]
                            v1 = prev_vert_indices[seg - 1]
                        else:
                            # quad, add new vertex
                            max_vert_index += 1
                            faces.append([v1, v2, max_vert_index,
                                prev_vert_indices[seg - 1]])
                            v2 = max_vert_index
                            v1 = prev_vert_indices[seg - 1]
                            new_verts.append(loc2)
                            next_verts.append(loc2)
                            next_vert_indices.append(max_vert_index)
                if end_face:
                    faces.append([v1, v2, lines[i + 1][1], line[1]])

                prev_verts = next_verts[:]
                prev_vert_indices = next_vert_indices[:]
                next_verts = []
                next_vert_indices = []

    return(new_verts, faces, max_vert_index)


# calculate lines (list of lists, vertex indices) that are used for bridging
def bridge_calculate_lines(bm, loops, mode, twist, reverse):
    """Pair ordered profiles without fitting a potentially singular plane."""
    (left, left_closed), (right, right_closed) = loops
    if not left or not right:
        return []
    if (right_closed and not left_closed) or (left_closed == right_closed and len(right) > len(left)):
        left, right = right, left
        left_closed, right_closed = right_closed, left_closed
    left, right = list(left), list(right)
    coords = {i: bm.verts[i].co for i in set(left + right)}
    centers = [
        sum((coords[i] for i in profile), mathutils.Vector((0, 0, 0))) / len(profile)
        for profile in (left, right)
    ]
    centered = [{i: coords[i] - center for i in profile}
                for profile, center in zip((left, right), centers, strict=True)]

    # Both ends of open profiles stay at their ends. For loops, choose the seam
    # and winding with the least summed centered displacement across the strip.
    sample_count = min(16, len(left), len(right))
    divisor = max(1, sample_count - 1)
    if left_closed and right_closed:
        sample = [(i * len(left) // sample_count, i * len(right) // sample_count)
                  for i in range(sample_count)]
    else:
        sample = [(i * (len(left)-1) // divisor, i * (len(right)-1) // divisor)
                  for i in range(sample_count)]

    def alignment_cost(start, direction):
        return sum((centered[0][left[(start + direction * i) % len(left)]] - centered[1][right[j]]).length_squared
                   for i, j in sample)

    offsets = range(len(left)) if left_closed else (0,)
    forward = min(((alignment_cost(k, 1), k, 1) for k in offsets))
    offsets = range(len(left)) if left_closed else (len(left) - 1,)
    backward = min(((alignment_cost(k, -1), k, -1) for k in offsets))
    _, start, step = forward if forward[0] <= backward[0] else backward
    left = [left[(start + step * index) % len(left)] for index in range(len(left))]
    if len(right) > len(left):
        left, right = right, left
        left_closed, right_closed = right_closed, left_closed
    if twist and abs(twist) < len(left):
        left = left[twist:] + left[:twist]
    if reverse:
        left.reverse()

    if len(left) == len(right):
        lines = [[a,b] for a,b in zip(left, right, strict=True)]
    else:
        position = 0
        lines = [[left[0], right[0]]]
        for i, vertex in enumerate(left[1:], 1):
            if position < len(right) - 1:
                catch_up = len(left) - 1 - i < len(right) - 1 - position
                advance = mode == "basic" or (
                    coords[vertex] - coords[right[position + 1]]
                ).length_squared <= (coords[vertex] - coords[right[position]]).length_squared
                if catch_up or advance:
                    position += 1
            lines.append([vertex, right[position]])
    if left_closed and right_closed:
        lines.append(lines[0].copy())
    return lines


# calculate number of segments needed
def bridge_calculate_segments(mesh, lines, loops, segments):
    if segments:
        return segments

    edge_distance = 0.0
    edge_count = 0
    for vertices, closed in loops:
        indices = [*vertices, vertices[0]] if closed else vertices
        for start, end in zip(indices, indices[1:]):
            edge_distance += (mesh.verts[end].co - mesh.verts[start].co).length
            edge_count += 1

    span_distance = sum((mesh.verts[end].co - mesh.verts[start].co).length
                        for start, end in lines)
    typical_edge = edge_distance / edge_count
    typical_span = span_distance / len(lines)
    return max(1, round(typical_span / typical_edge))


# return dictionary with vertex index as key, and the normal vector as value
def bridge_calculate_virtual_vertex_normals(bm, lines, loops, edge_faces,
edgekey_to_edge):
    if not edge_faces:  # interpolation isn't set to cubic
        return False

    # pity reduce() isn't one of the basic functions in python anymore
    def average_vector_dictionary(dic):
        """Replace each multiple-sample bucket with its component mean."""
        for key, samples in dic.items():
            if len(samples) > 1:
                total = mathutils.Vector((0.0, 0.0, 0.0))
                for sample in samples:
                    total += sample
                dic[key] = [total / len(samples)]
        return dic

    # get all edges of the loop
    edges = [
        [edgekey_to_edge[tuple(sorted([loops[j][0][i],
        loops[j][0][i + 1]]))] for i in range(len(loops[j][0]) - 1)] for
        j in [0, 1]
        ]
    edges = edges[0] + edges[1]
    for j in [0, 1]:
        if loops[j][1]:  # circular
            edges.append(edgekey_to_edge[tuple(sorted([loops[j][0][0],
                loops[j][0][-1]]))])

    """
    calculation based on face topology (assign edge-normals to vertices)

    edge_normal = face_normal x edge_vector
    vertex_normal = average(edge_normals)
    """
    vertex_normals = dict([(vertex, []) for vertex in loops[0][0] + loops[1][0]])
    for edge in edges:
        faces = edge_faces[edgekey(edge)]  # valid faces connected to edge

        if faces:
            # get edge coordinates
            v1, v2 = [bm.verts[edgekey(edge)[i]].co for i in [0, 1]]
            edge_vector = v1 - v2
            if edge_vector.length < 1e-4:
                # zero-length edge, vertices at same location
                continue
            edge_center = (v1 + v2) / 2

            # average face coordinates, if connected to more than 1 valid face
            if len(faces) > 1:
                face_normal = mathutils.Vector()
                face_center = mathutils.Vector()
                for face in faces:
                    face_normal += face.normal
                    face_center += face.calc_center_median()
                face_normal /= len(faces)
                face_center /= len(faces)
            else:
                face_normal = faces[0].normal
                face_center = faces[0].calc_center_median()
            if face_normal.length < 1e-4:
                # faces with a surface of 0 have no face normal
                continue

            # calculate virtual edge normal
            edge_normal = edge_vector.cross(face_normal)
            edge_normal.length = 0.01
            if (face_center - (edge_center + edge_normal)).length > \
            (face_center - (edge_center - edge_normal)).length:
                # make normal face the correct way
                edge_normal.negate()
            edge_normal.normalize()
            # add virtual edge normal as entry for both vertices it connects
            for vertex in edgekey(edge):
                vertex_normals[vertex].append(edge_normal)

    """
    calculation based on connection with other loop (vertex focused method)
    - used for vertices that aren't connected to any valid faces

    plane_normal = edge_vector x connection_vector
    vertex_normal = plane_normal x edge_vector
    """
    vertices = [
        vertex for vertex, normal in vertex_normals.items() if not normal
        ]

    if vertices:
        # edge vectors connected to vertices
        edge_vectors = dict([[vertex, []] for vertex in vertices])
        for edge in edges:
            for v in edgekey(edge):
                if v in edge_vectors:
                    edge_vector = bm.verts[edgekey(edge)[0]].co - \
                        bm.verts[edgekey(edge)[1]].co
                    if edge_vector.length < 1e-4:
                        # zero-length edge, vertices at same location
                        continue
                    edge_vectors[v].append(edge_vector)

        # connection vectors between vertices of both loops
        connection_vectors = dict([[vertex, []] for vertex in vertices])
        connections = dict([[vertex, []] for vertex in vertices])
        for v1, v2 in lines:
            if v1 in connection_vectors or v2 in connection_vectors:
                new_vector = bm.verts[v1].co - bm.verts[v2].co
                if new_vector.length < 1e-4:
                    # zero-length connection vector,
                    # vertices in different loops at same location
                    continue
                if v1 in connection_vectors:
                    connection_vectors[v1].append(new_vector)
                    connections[v1].append(v2)
                if v2 in connection_vectors:
                    connection_vectors[v2].append(new_vector)
                    connections[v2].append(v1)
        connection_vectors = average_vector_dictionary(connection_vectors)
        connection_vectors = dict(
            [[vertex, vector[0]] if vector else
            [vertex, []] for vertex, vector in connection_vectors.items()]
            )

        for vertex, values in edge_vectors.items():
            # vertex normal doesn't matter, just assign a random vector to it
            if not connection_vectors[vertex]:
                vertex_normals[vertex] = [mathutils.Vector((1, 0, 0))]
                continue

            # calculate to what location the vertex is connected,
            # used to determine what way to flip the normal
            connected_center = mathutils.Vector()
            for v in connections[vertex]:
                connected_center += bm.verts[v].co
            if len(connections[vertex]) > 1:
                connected_center /= len(connections[vertex])
            if len(connections[vertex]) == 0:
                # shouldn't be possible, but better safe than sorry
                vertex_normals[vertex] = [mathutils.Vector((1, 0, 0))]
                continue

            # can't do proper calculations, because of zero-length vector
            if not values:
                if (connected_center - (bm.verts[vertex].co +
                connection_vectors[vertex])).length < (connected_center -
                (bm.verts[vertex].co - connection_vectors[vertex])).length:
                    connection_vectors[vertex].negate()
                vertex_normals[vertex] = [connection_vectors[vertex].normalized()]
                continue

            # calculate vertex normals using edge-vectors,
            # connection-vectors and the derived plane normal
            for edge_vector in values:
                plane_normal = edge_vector.cross(connection_vectors[vertex])
                vertex_normal = edge_vector.cross(plane_normal)
                vertex_normal.length = 0.1
                if (connected_center - (bm.verts[vertex].co +
                vertex_normal)).length < (connected_center -
                (bm.verts[vertex].co - vertex_normal)).length:
                    # make normal face the correct way
                    vertex_normal.negate()
                vertex_normal.normalize()
                vertex_normals[vertex].append(vertex_normal)

    # average virtual vertex normals, based on all edges it's connected to
    vertex_normals = average_vector_dictionary(vertex_normals)
    vertex_normals = dict([[vertex, vector[0]] for vertex, vector in vertex_normals.items()])

    return(vertex_normals)


# add vertices to mesh
def bridge_create_vertices(bm, vertices):
    for i in range(len(vertices)):
        bm.verts.new(vertices[i])
    bm.verts.ensure_lookup_table()


# add faces to mesh
def bridge_create_faces(object, bm, faces, twist):
    """Stitch simple contour cycles into faces and preserve their winding."""
    bm.verts.ensure_lookup_table()
    created = []
    for ring in faces:
        cycle = []
        for index in (reversed(ring) if twist < 0 else ring):
            if not cycle or cycle[-1] != index:
                cycle.append(index)
        if cycle and cycle[0] == cycle[-1]:
            cycle.pop()
        if len(cycle) < 3 or len(set(cycle)) != len(cycle):
            continue
        vertices = [bm.verts[index] for index in cycle]
        if bm.faces.get(vertices) is None:
            created.append(bm.faces.new(vertices))
    bm.normal_update()
    object.data.update(calc_edges=True)
    for sequence in (bm.verts, bm.edges, bm.faces):
        sequence.ensure_lookup_table()
    return created


# calculate input loops
def bridge_get_input(bm):
    contours = []
    for edge in bm.edges:
        if not edge.select or edge.hide:
            continue
        selection_count = sum(face.select and not face.hide for face in edge.link_faces)
        if selection_count <= 1:
            contours.append(edgekey(edge))
    return get_connected_selections(contours)


# return values needed by the bridge operator
def bridge_initialise(bm, interpolation):
    faces = list(bm.faces)
    if interpolation == 'cubic':
        references = {}
        selected_edges = {}
        for edge in bm.edges:
            if edge.hide:
                continue
            key = edgekey(edge)
            references[key] = sorted(
                (face for face in edge.link_faces if not face.select and not face.hide),
                key=lambda face: face.index,
            )
            if edge.select:
                selected_edges[key] = edge
    else:
        references = selected_edges = False
    selected_faces = [face.index for face in faces if face.select and not face.hide]
    smooth = bool(faces) and 2 * sum(face.smooth for face in faces) >= len(faces)
    return references, selected_edges, selected_faces, smooth


# return a string with the input method
def bridge_input_method(loft, loft_loop):
    method = ""
    if loft:
        if loft_loop:
            method = "Loft loop"
        else:
            method = "Loft no-loop"
    else:
        method = "Bridge"

    return(method)


# match up loops in pairs, used for multi-input bridging
def bridge_match_loops(bm, loops):
    """Pair neighboring contours when their average directions allow it."""
    centers = []
    offsets = []
    for vertices, _ in loops:
        position = mathutils.Vector((0.0, 0.0, 0.0))
        direction = position.copy()
        for index in vertices:
            vertex = bm.verts[index]
            position += vertex.co
            direction += vertex.normal
        centers.append(position / len(vertices))
        offsets.append(direction / len(vertices) / 10)

    all_neighbors = [[] for _ in loops]
    facing_neighbors = [[] for _ in loops]
    for right, center in enumerate(centers):
        for left in range(right):
            distance = (center - centers[left]).length
            all_neighbors[left].append((distance, right))
            all_neighbors[right].append((distance, left))
            if ((center - (centers[left] + offsets[left])).length < distance
                    and (centers[left] - (center + offsets[right])).length < distance):
                facing_neighbors[left].append((distance, right))
                facing_neighbors[right].append((distance, left))

    graph = facing_neighbors if any(facing_neighbors) else all_neighbors
    used = set()
    ordered = []
    for anchor, neighbors in enumerate(graph):
        if anchor in used or not neighbors:
            continue
        cutoff = 1.1 * min(distance for distance, _ in neighbors)
        choices = ((abs(len(loops[anchor][0]) - len(loops[index][0])), distance, index)
                   for distance, index in neighbors if distance < cutoff and index not in used)
        found = min(choices, default=None)
        if found is not None:
            partner = found[2]
            used.update((anchor, partner))
            ordered.extend((loops[anchor], loops[partner]))
    return ordered or loops


# remove old_selected_faces
def bridge_remove_internal_faces(bm, old_selected_faces):
    """Remove cap faces and leave edges that still border other faces."""
    bm.faces.ensure_lookup_table()
    caps = {bm.faces[index] for index in old_selected_faces}
    touched = {edge for cap in caps for edge in cap.edges}
    internal = []
    for edge in touched:
        neighbors = edge.link_faces
        if len(neighbors) >= 2 and all(face in caps for face in neighbors):
            internal.append(edge)
    for face in caps:
        bm.faces.remove(face)
    for edge in internal:
        bm.edges.remove(edge)
    for elements in (bm.faces, bm.edges, bm.verts):
        elements.ensure_lookup_table()


# update list of internal faces that are flagged for removal
def bridge_save_unused_faces(bm, old_selected_faces, loops):
    selected = set(old_selected_faces)
    bridged_vertices = {position for contour, _closed in loops for position in contour}
    pending = [
        bm.faces[index] for index in old_selected_faces
        if any(vertex.index in bridged_vertices for vertex in bm.faces[index].verts)
    ]
    connected = {face.index for face in pending}
    while pending:
        for vertex in pending.pop().verts:
            for face in vertex.link_faces:
                if face.index in selected and face.index not in connected:
                    connected.add(face.index)
                    pending.append(face)
    old_selected_faces[:] = [index for index in old_selected_faces if index in connected]


# add the newly created faces to the selection
def bridge_select_new_faces(new_faces, smooth):
    for face in new_faces:
        face.select_set(True)
        face.smooth = smooth


# sort loops, so they are connected in the correct order when lofting
def bridge_sort_loops(bm, loops, loft_loop):
    """Order contours by centroid distance, allowing a closed final pass."""
    if not loops:
        return []
    centers = {}
    for ordinal, (vertices, _) in enumerate(loops):
        points = [bm.verts[index].co for index in vertices]
        centers[ordinal] = mathutils.Vector(
            tuple(sum(point[axis] for point in points) / len(points) for axis in range(3))
        )

    def distance(left, right):
        return (centers[left] - centers[right]).length

    remaining = list(range(1, len(loops)))
    order = [0]
    while remaining:
        following = min(remaining, key=lambda ordinal: distance(order[-1], ordinal))
        order.append(following)
        remaining.remove(following)
    for offset, following in enumerate(order[2:], start=2):
        if distance(0, following) < distance(order[offset - 1], following):
            order = list(reversed(order[offset:])) + order[:offset]
            break
    if loft_loop:
        order.append(order[0])
    return [loops[ordinal] for ordinal in order]


# remapping old indices to new position in list
def bridge_update_old_selection(bm, old_selected_faces):
    """
    old_indices = old_selected_faces[:]
    old_selected_faces = []
    for i, face in enumerate(bm.faces):
        if face.index in old_indices:
            old_selected_faces.append(i)
    """
    old_selected_faces = [
        i for i, face in enumerate(bm.faces) if face.index in old_selected_faces
        ]

    return(old_selected_faces)


# ########################################
# ##### Circle functions #################
# ########################################

# convert 3d coordinates to 2d coordinates on plane
def circle_3d_to_2d(bm_mod, loop, com, normal):
    """Resolve positions in an orthogonal basis on the fitting plane."""
    axis = mathutils.Vector((1.0, 0.0, 0.0))
    q = axis.cross(normal)
    if q.length_squared == 0:
        axis = mathutils.Vector((0.0, 1.0, 0.0))
        q = axis.cross(normal)
    p = normal.cross(q)
    if not p.length_squared or not q.length_squared:
        p = mathutils.Vector((1.0, 0.0, 0.0))
        q = mathutils.Vector((0.0, -1.0, 0.0))
    local = []
    for index in loop[0]:
        delta = bm_mod.verts[index].co - com
        local.append([delta.dot(p) / p.length_squared, delta.dot(q) / q.length_squared, index])
    return local, p, q


# calculate a best-fit circle to the 2d locations on the plane
def circle_calculate_best_fit(locs_2d):
    """Fit a circle by minimizing the sum of squared radial residuals."""
    import numpy as np

    if not locs_2d:
        return 0.0, 0.0, 1.0
    xy = np.asarray([point[:2] for point in locs_2d], dtype=float)
    mean = xy.mean(axis=0)
    points = xy - mean
    scale = np.max(np.abs(points))
    if scale == 0.0:
        return float(mean[0]), float(mean[1]), 0.0
    points /= scale

    def refine(seed):
        center = seed.copy()
        for _ in range(50):
            offsets = center - points
            radii = np.linalg.norm(offsets, axis=1)
            residual = radii - radii.mean()
            cost = residual @ residual
            directions = np.divide(offsets, radii[:, None], out=np.zeros_like(offsets), where=radii[:, None] > 1.e-14)
            jacobian = directions - directions.mean(axis=0)
            step = np.linalg.lstsq(jacobian, -residual, rcond=None)[0]
            if np.linalg.norm(step) <= 1.e-10:
                break
            for _ in range(18):
                proposal = center + step
                lengths = np.linalg.norm(points - proposal, axis=1)
                if np.sum((lengths - lengths.mean()) ** 2) <= cost:
                    center = proposal
                    break
                step *= 0.5
            else:
                break
        radii = np.linalg.norm(points - center, axis=1)
        return np.sum((radii - radii.mean()) ** 2), center, radii.mean()

    lengths2 = np.einsum("ij,ij->i", points, points)
    guess, _, rank, _ = np.linalg.lstsq(2 * points, lengths2 - lengths2.mean(), rcond=None)
    if rank < 2:
        center = np.zeros(2, dtype=float)
        radius = np.mean(np.sqrt(lengths2))
    else:
        cost, center, radius = refine(guess)
        # A circle centered far along the minor axis approaches the best-fit line.
        # Explore both sides when that limit improves on a local radial minimum.
        variances, axes = np.linalg.eigh(points.T @ points)
        if cost > variances[0] + 1.e-12:
            for direction in (-1, 1):
                alternate = refine(direction * 2 * axes[:, 0])
                if alternate[0] < cost and alternate[2] < 1 / math.sqrt(np.finfo(np.float32).eps):
                    cost, center, radius = alternate
    center = mean + center * scale
    return float(center[0]), float(center[1]), float(radius * scale)


# calculate circle so no vertices have to be moved away from the center
def circle_calculate_min_fit(locs_2d):
    xs, ys = zip(*[(point[0], point[1]) for point in locs_2d])
    cx = (min(xs) + max(xs)) / 2.0
    cy = (min(ys) + max(ys)) / 2.0
    radius = min(math.hypot(x - cx, y - cy) for x, y in zip(xs, ys))
    return cx, cy, radius


# calculate the new locations of the vertices that need to be moved
def circle_calculate_verts(flatten, bm_mod, locs_2d, com, p, q, normal):
    planar = [[index, x * p + y * q + com] for x, y, index in locs_2d]
    if flatten:
        return planar

    positions = bm_mod.verts
    incident_edges, incident_faces = dict_vert_edges(bm_mod), dict_vert_faces(bm_mod)
    visible_faces = [face.index for face in bm_mod.faces if not face.hide]
    triangulated = {}
    rays = normal, -normal
    geometry = mathutils.geometry

    def hit_face(index, origin):
        if index not in triangulated:
            polygon = [vertex.co for vertex in bm_mod.faces[index].verts][:4]
            fan = [(polygon[0], polygon[1], polygon[2])]
            if len(polygon) == 4:
                fan.append((polygon[0], polygon[2], polygon[3]))
            triangulated[index] = fan
        for ray in rays:
            for triangle in triangulated[index]:
                hit = geometry.intersect_ray_tri(*triangle, ray, origin)
                if hit is not None:
                    return hit
        return None

    def hit_incident_edge(index, origin):
        for start, end in incident_edges[index]:
            foot, fraction = geometry.intersect_point_line(origin, positions[start].co, positions[end].co)
            if 1e-6 < fraction < 1 - 1e-6:
                return foot
        return None

    result = []
    for index, origin in planar:
        initial = positions[index].co
        displacement = origin - initial
        if origin == initial:
            result.append([index, origin])
            continue

        inclination = normal.angle(displacement)
        hit = initial if min(abs(inclination), abs(inclination - math.pi)) < 1e-6 else None
        if hit is None:
            local = (hit_face(face, origin) for face in incident_faces[index])
            hit = next((point for point in local if point is not None), None)
        if hit is None:
            hit = hit_incident_edge(index, origin)
        if hit is None:
            matches = (hit_face(face, origin) for face in visible_faces)
            ranked = (((origin - point).length, point) for point in matches if point is not None)
            nearest = min(ranked, default=None)
            hit = nearest[1] if nearest is not None else origin
        result.append([index, hit])
    return result


# check loops and only return valid ones
def circle_check_loops(single_loops, loops, mapping, bm_mod):
    assigned, validated = {}, []
    for position, (vertices, closed) in enumerate(loops):
        if len(vertices) < 3 or (mapping and not any(mapping[index] > -1 for index in vertices)):
            continue

        points = [bm_mod.verts[index].co for index in vertices]
        steps = [end - start for start, end in zip(points, points[1:])]
        turn = any(before.length_squared and after.length_squared and abs(before.angle(after, 0)) >= 1e-6
                   for before, after in zip(steps, steps[1:]))
        if turn:
            assigned[len(validated)] = single_loops[position]
            validated.append([vertices, closed])
    return assigned, validated


# calculate the location of single input vertices that need to be flattened
def circle_flatten_singles(bm_mod, com, p, q, normal, single_loop):
    return flatten_project(bm_mod, [single_loop, False], com, normal)


# calculate input loops
def circle_get_input(object, bm):
    from collections import Counter

    derived, mesh = get_derived_bmesh(object, bm, False)
    selected = [edgekey(edge) for edge in mesh.edges if edge.select and not edge.hide]
    if any(face.select and not face.hide for face in bm.faces):
        perimeter = Counter(edge for face in mesh.faces if face.select and not face.hide
                            for edge in face_edgekeys(face))
        boundaries = [edge for edge in selected if perimeter.get(edge, 1) == 1]
    else:
        boundaries = selected[:]

    attached = {vertex for edge in selected for vertex in edge}
    loose = [vertex.index for vertex in mesh.verts if vertex.select and not vertex.hide
             and vertex.index not in attached]
    anchors = set(loose)
    touched = {vertex.index: {} for vertex in mesh.verts if not vertex.hide}
    if anchors and bm.faces:
        for face in mesh.faces:
            if face.select or face.hide:
                continue
            first = next((vertex.index for vertex in face.verts if vertex.index in anchors), None)
            if first is None:
                continue
            for edge in face_edgekeys(face):
                if first not in edge:
                    boundaries.append(edge)
                    for index in edge:
                        touched[index][first] = None

    loops = get_connected_selections(boundaries)
    bound = {
        number: list(dict.fromkeys(anchor for vertex in vertices for anchor in touched[vertex])) if anchors and bm.faces else []
        for number, (vertices, _) in enumerate(loops)
    }
    return derived, mesh, loose, bound, loops


# recalculate positions based on the influence of the circle shape
def circle_influence_locs(locs_2d, new_locs_2d, influence):
    weight = influence / 100.0
    for j, (point, desired) in enumerate(zip(locs_2d, new_locs_2d)):
        x = point[0] + weight * (desired[0] - point[0])
        y = point[1] + weight * (desired[1] - point[1])
        locs_2d[j] = [x, y, point[2]]
    return locs_2d


# project 2d locations on circle, respecting distance relations between verts
def circle_project_non_regular(locs_2d, x0, y0, r, angle):
    cosine, sine = math.cos(angle), math.sin(angle)
    for j, point in enumerate(locs_2d):
        x, y = point[0] - x0, point[1] - y0
        span = math.hypot(x, y)
        if span:
            px = r * (cosine * x - sine * y) / span
            py = r * (sine * x + cosine * y) / span
        else:
            px = py = 0.0
        locs_2d[j] = [px, py, point[2]]
    return locs_2d


# project 2d locations on circle, with equal distance between all vertices
def circle_project_regular(locs_2d, x0, y0, r, angle):
    first, second = locs_2d[0], locs_2d[1]
    x, y = first[0] - x0, first[1] - y0
    phase = math.atan2(y, x) + angle
    cross = x * (second[1] - y0) - y * (second[0] - x0)
    step = math.copysign(math.tau / len(locs_2d), -1.0 if cross < 0.0 else 1.0)
    for j, point in enumerate(locs_2d):
        theta = phase + j * step
        locs_2d[j] = [r * math.cos(theta), r * math.sin(theta), point[2]]
    return locs_2d


# shift loop, so the first vertex is closest to the center
def circle_shift_loop(bm_mod, loop, com):
    indices, closed = loop
    if not indices:
        raise IndexError("no vertex in the loop")
    nearest = min(range(len(indices)), key=lambda j: (bm_mod.verts[indices[j]].co - com).length)
    return [indices[nearest:] + indices[:nearest], closed]


# ########################################
# ##### Curve functions ##################
# ########################################

# create lists with knots and points, all correctly sorted
def curve_calculate_knots(loop, verts_selected):
    vertices, closed = loop
    selected = set(verts_selected)
    knots = [vertex for vertex in vertices if vertex in selected]
    if not closed:
        if vertices[0] not in selected:
            knots.insert(0, vertices[0])
        if vertices[-1] not in selected:
            knots.append(vertices[-1])
        return knots, vertices[:]

    first_seen = {}
    for index, vertex in enumerate(vertices):
        first_seen.setdefault(vertex, index)
    indices = [first_seen[vertex] for vertex in knots]
    size = len(vertices)
    reach = size // 4
    gaps = [end - start for start, end in zip(indices, indices[1:] + [indices[0] + size])]
    by_gap = {}
    cut = None
    extra = []
    for index, gap in enumerate(gaps):
        first = by_gap.setdefault(gap, index)
        if gap > 2 * reach:
            before, after = indices[first], indices[(first + 1) % len(indices)]
            entering, cut = vertices[(before + reach) % size], vertices[(after - reach) % size]
            extra.extend(((vertices[before], entering), (entering, cut)))
    for prior, vertex in extra:
        knots.insert(knots.index(prior) + 1, vertex)

    if not cut:
        start = indices[0]
        return knots + [knots[0]], vertices[start:] + vertices[:start + 1]
    pivot = knots.index(cut)
    knots = knots[pivot:] + knots[:pivot]
    start, stop = vertices.index(knots[0]), vertices.index(knots[-1])
    points = vertices[start:stop + 1] if start <= stop else vertices[start:] + vertices[:stop + 1]
    return knots, points


# calculate relative positions compared to first knot
def curve_calculate_t(bm_mod, knots, points, pknots, regular, circular):
    projected = {}
    for vertex, position in zip(knots, pknots):
        projected.setdefault(vertex, position)
    locs = [projected[index] if index in projected else bm_mod.verts[index].co.copy()
            for index in points]
    tpoints = [0] if locs else []
    for left, right in zip(locs, locs[1:]):
        tpoints.append(tpoints[-1] + (right - left).length)

    if regular:
        stride = tpoints[-1] / (len(tpoints) - 1)
        tpoints[1:-1] = [index * stride for index in range(1, len(tpoints) - 1)]

    first_seen = {}
    for point, measure in zip(points, tpoints):
        first_seen.setdefault(point, measure)
    order = knots if regular else [index for index in points if index in projected]
    tknots = [first_seen[index] for index in order]
    if circular:
        tknots[-1] = tpoints[-1]
    return tknots, tpoints


# change the location of non-selected points to their place on the spline
def curve_calculate_vertices(bm_mod, knots, tknots, points, tpoints, splines,
                             interpolation, restriction):
    from bisect import bisect_left

    anchors = set(knots)
    measures = {}
    for index, measure in zip(points, tpoints):
        measures.setdefault(index, measure)

    at_knot = {}
    for index, measure in enumerate(tknots):
        at_knot.setdefault(measure, index)
    ordered_knots = sorted(tknots)

    def evaluate(measure):
        position = at_knot.get(measure)
        if position is None:
            position = bisect_left(ordered_knots, measure) - 1
        segment = splines[min(len(splines) - 1, max(0, position))]
        if interpolation != "cubic":
            origin, tangent, start, length = segment
            return ((measure - start) / length) * tangent + origin
        values = []
        for center, slope, curve, bend, origin in segment:
            distance = measure - origin
            values.append(center + slope * distance + curve * distance ** 2 + bend * distance ** 3)
        return mathutils.Vector(values)

    edits = []
    for point in points:
        vertex = bm_mod.verts[point]
        if point in anchors:
            if restriction != "none":
                edits.append([point, vertex.co])
            continue
        target = evaluate(measures[point])
        if restriction != "none":
            delta = target - vertex.co
            if delta.length >= 1e-6:
                half_turn = math.pi / 2
                if restriction == "extrude":
                    if not delta.angle(vertex.normal, 0) < half_turn + 1e-6:
                        continue
                elif not delta.angle(vertex.normal) > half_turn - 1e-6:
                    continue
        edits.append([point, target])
    return edits


# trim loops to part between first and last selected vertices (including)
def curve_cut_boundaries(bm_mod, loops):
    trimmed = []
    for vertices, closed in loops:
        visited = [index for index, vertex in enumerate(vertices) if bm_mod.verts[vertex].select]
        route = vertices[visited[0]:visited[-1] + 1]
        if not closed or len(route) < len(vertices) / 2:
            trimmed.append([route, False])
    return trimmed


# calculate input loops
def curve_get_input(object, bm, boundaries):
    derived, mesh = get_derived_bmesh(object, bm, False)
    pending = dict.fromkeys(vertex.index for vertex in mesh.verts if vertex.select and not vertex.hide)
    incident_edges, incident_faces = dict_vert_edges(mesh), dict_edge_faces(mesh)
    routes = []
    while pending:
        start = next(iter(pending))
        del pending[start]
        traversals = curve_vertex_loops(mesh, start, incident_edges, incident_faces)
        offset = 0
        cross_section = None
        while offset < len(traversals):
            path, _ = traversals[offset]
            selected = sum(mesh.verts[vertex].select for vertex in path)
            if selected < 2:
                del traversals[offset]
            elif selected == len(path):
                cross_section = path
                break
            offset += 1
        if cross_section:
            for vertex in cross_section:
                pending.pop(vertex, None)
            routes.extend(curve_perpendicular_loops(mesh, cross_section, incident_edges, incident_faces))
        else:
            routes.extend([path, closed] for path, closed in traversals)
    return derived, mesh, curve_cut_boundaries(mesh, routes) if boundaries else routes


# return all loops that are perpendicular to the given one
def curve_perpendicular_loops(bm_mod, start_loop, vert_edges, edge_faces):
    paths = []
    for anchor in start_loop:
        for route, closed in curve_vertex_loops(bm_mod, anchor, vert_edges, edge_faces):
            if any(not bm_mod.verts[vertex].select for vertex in route):
                paths.append((route, closed, route.index(anchor)))
    reference = min((entry for entry in paths if not entry[1]), key=lambda entry: len(entry[0]), default=None)
    if reference is None:
        return [[route, closed] for route, closed, _ in paths]

    ref_route, _, left = reference
    right = len(ref_route) - left - 1
    orient_left = left > right
    limited = []
    for route, closed, position in paths:
        length = len(route)
        radius = length / 2
        if (orient_left and position < radius) or (not orient_left and position > radius):
            route = route[::-1]
            position = length - position - 1

        if closed:
            step = left - position
            if 0 < left < length:
                route = route[-step:] + route[:-step]
            position = left if left < length else left - length
        start, stop = max(0, position - left), min(length, position + right + 1)
        limited.append([route[start:stop], False])
    return limited


# project knots on non-selected geometry
def curve_project_knots(bm_mod, verts_selected, knots, points, circular):
    fixed, selected = set(knots), set(verts_selected)
    positions = {}
    for index, vertex in enumerate(points):
        positions.setdefault(vertex, index)
    count = len(points)

    def nearest(start, step):
        return next((points[(start + offset * step) % count] for offset in range(1, count)
                     if points[(start + offset * step) % count] not in fixed), None)

    def project(vertex):
        anchor = bm_mod.verts[vertex].co.copy()
        if vertex not in selected:
            return anchor
        start = positions[vertex]
        left, right = nearest(start, -1), nearest(start, 1)
        if left and right and left != right:
            origin = bm_mod.verts[left].co
            direction = bm_mod.verts[right].co - origin
            return (anchor - origin).project(direction) + origin
        return anchor

    if circular:
        return [project(vertex) for vertex in knots]
    endpoints = [bm_mod.verts[index].co.copy() for index in (knots[0], knots[-1])]
    return [endpoints[0], *(project(vertex) for vertex in knots[1:-1]), endpoints[1]]


# find all loops through a given vertex
def curve_vertex_loops(bm_mod, start_vert, vert_edges, edge_faces):
    used = set()
    paths = []

    def follow(vertex, faces, path):
        while True:
            previous = path[-1] if path else None
            path.append(vertex)
            if previous is not None:
                used.add(tuple(sorted((previous, vertex))))

            incident = vert_edges[vertex]
            if not 3 <= len(incident) <= 4:
                return False
            eligible = (edge for edge in incident if edge not in used and faces.isdisjoint(edge_faces[edge]))
            connection = next(eligible, None)
            if connection is None:
                return False
            first, second = connection
            vertex = second if first == vertex else first
            if vertex == path[0]:
                return True
            faces = set(edge_faces[connection])

    for edge in vert_edges[start_vert]:
        if edge in used:
            continue
        path, closed = [], False
        for origin in edge:
            closed = follow(origin, set(edge_faces[edge]), path)
            if closed:
                break
            path.reverse()
        paths.append([path, closed])
    return paths


# ########################################
# ##### Flatten functions ################
# ########################################

# sort input into loops
def flatten_get_input(bm):
    selected = {v.index for v in bm.verts if v.select and not v.hide}
    adjacency = dict_vert_verts(edgekey(edge) for edge in bm.edges
        if edge.select and not edge.hide and all(v.index in selected for v in edge.verts))
    if not adjacency:
        return [[sorted(selected), False]]
    groups = []
    for first in sorted(selected):
        if first not in selected:
            continue
        selected.remove(first)
        group = [first]
        for vertex in group:
            for neighbor in adjacency.get(vertex, ()):
                if neighbor in selected:
                    selected.remove(neighbor)
                    group.append(neighbor)
        groups.append([group, False])
    return groups


# calculate position of vertex projections on plane
def flatten_project(bm, loop, com, normal):
    moves = []
    for index in loop[0]:
        point = bm.verts[index].co
        distance = (point - com).dot(normal)
        moves.append([index, point - distance * normal])
    return moves


# ########################################
# ##### Gstretch functions ###############
# ########################################

# fake stroke class, used to create custom strokes if no GP data is found
class gstretch_fake_stroke():
    def __init__(self, points):
        self.points = [gstretch_fake_stroke_point(p) for p in points]


# fake stroke point class, used in fake strokes
class gstretch_fake_stroke_point():
    def __init__(self, loc):
        self.co = loc


# flips loops, if necessary, to obtain maximum alignment to stroke
def gstretch_align_pairs(ls_pairs, object, bm_mod, method):
    transform = object.matrix_world

    def alignment(vertices, stroke, evenly, cache):
        targets = gstretch_relative_lengths([vertices, False], bm_mod) if not evenly else (
            index / (len(vertices) - 1) for index in range(len(vertices))
        )
        score = 0.0
        for vertex, distance in zip(vertices, targets, strict=True):
            point, cache = gstretch_eval_stroke(stroke, distance, cache)
            score += (point - (transform @ bm_mod.verts[vertex].co)).length
        return score, cache

    for loop, stroke in ls_pairs or ():
        indices = loop[0]
        forward, cache = alignment(indices, stroke, method == "regular", False)
        backward, _ = alignment(indices[::-1], stroke, method == "regular", cache)
        if backward <= forward:
            indices.reverse()
    return ls_pairs


# calculate vertex positions on stroke
def gstretch_calculate_verts(loop, stroke, object, bm_mod, method):
    world = object.matrix_world
    local = world.inverted()
    indices = loop[0]

    if method != "project":
        samples = (index / (len(indices) - 1) for index in range(len(indices))) if method == "regular" else (
            gstretch_relative_lengths(loop, bm_mod)
        )
        positions = []
        cache = False
        for index, distance in zip(indices, samples, strict=True):
            point, cache = gstretch_eval_stroke(stroke, distance, cache)
            positions.append([index, local @ point])
        return positions

    points = [point.co for point in stroke.points]
    segments = list(zip(points[1:], points))
    adjacency = dict_vert_edges(bm_mod)

    def first_intersection(start, end):
        for a, b in segments:
            pair = mathutils.geometry.intersect_line_line(start, end, a, b)
            if pair is None or (pair[0] - pair[1]).length >= 0.01:
                continue
            _, parameter = mathutils.geometry.intersect_point_line(pair[0], a, b)
            if -1 < parameter < 1:
                return pair[0]
        return None

    positions = []
    for index in indices:
        vertex = bm_mod.verts[index]
        point = None
        for edge in adjacency[index]:
            first, second = (bm_mod.verts[endpoint] for endpoint in edge)
            if first.select == second.select or first.hide or second.hide:
                continue
            point = first_intersection(world @ first.co, world @ second.co)
            if point:
                break
        if not point:
            point = first_intersection(vertex.co, vertex.co + vertex.normal)
        if point:
            positions.append([index, local @ point])
    return positions


# create new vertices, based on GP strokes
def gstretch_create_verts(object, bm_mod, strokes, method, conversion,
                         conversion_distance, conversion_max, conversion_min, conversion_vertices):
    def fixed_intervals(points, spacing):
        next_sample = spacing
        travelled = 0.0
        yield points[0]
        for start, finish in zip(points, points[1:]):
            delta = finish - start
            length = delta.length
            segment_end = travelled + length
            while next_sample < segment_end:
                yield start + ((next_sample - travelled) / length) * delta
                next_sample += spacing
            travelled = segment_end

    local = object.matrix_world.inverted()
    attachments = gstretch_match_single_verts(bm_mod, strokes, local)
    chains = []
    regular = method == "regular" and conversion != "distance"
    for stroke in strokes:
        points = [point.co for point in stroke.points]
        if not points:
            continue
        if conversion == "distance":
            samples = fixed_intervals(points, conversion_distance)
        else:
            minimum, maximum = {
                "vertices": (conversion_vertices, conversion_vertices),
                "limit_vertices": (conversion_min, conversion_max),
            }.get(conversion, (0, len(points)))
            samples = points[:maximum]
            if len(samples) < minimum:
                samples += [samples[-1]] * (minimum - len(samples))
                regular = True
        chains.append((stroke, [bm_mod.verts.new(local @ point) for point in samples]))

    bm_mod.verts.ensure_lookup_table()
    bm_mod.verts.index_update()
    moves = []
    for stroke, chain in chains:
        if len(chain) < 2:
            continue
        if regular:
            loop = [[vertex.index for vertex in chain], False]
            moves.extend(gstretch_calculate_verts(loop, stroke, object, bm_mod, "regular"))
        for left, right in zip(chain, chain[1:]):
            bm_mod.edges.new((left, right))
        for vertex in chain:
            vertex.select = True
        for vertex, guide, endpoint in attachments:
            if guide == stroke:
                bm_mod.edges.new((vertex, chain[endpoint]))
    bm_mod.edges.ensure_lookup_table()
    bmesh.update_edit_mesh(object.data)
    return moves


# erases the grease pencil stroke
def gstretch_erase_stroke(stroke, context):
    # change 3d coordinate into a stroke-point
    def sp(loc, context):
        mouse = view3d_utils.location_3d_to_region_2d(
            context.region, context.space_data.region_3d, loc)
        lib = {'name': "",
            'is_start': False,
            'location': (0, 0, 0),
            'mouse': mouse,
            'mouse_event': mouse,
            'pressure': 1,
            'size': 0,
            'time': 0,
            'x_tilt': 0,
            'y_tilt': 0}
        return(lib)

    gpencil_index = getattr(stroke, "gpencil_index", None)
    if gpencil_index is not None:
        looptools = context.window_manager.looptools
        frame = looptools.gstretch_guide.data.layers.active.current_frame()
        frame.drawing.remove_strokes(indices=(gpencil_index,))
        return

    if not isinstance(stroke, bpy.types.AnnotationStroke):
        # fake stroke, there is nothing to delete
        return

    layer = _active_annotation_layer(context)
    frame = layer.active_frame if layer is not None else None
    if frame is None:
        return
    if len(frame.strokes) == 1:
        layer.frames.remove(frame)
        return

    erase_stroke = [sp(p.co, context) for p in stroke.points]
    erase_stroke[0]['is_start'] = True
    bpy.ops.gpencil.annotate('EXEC_DEFAULT', mode='ERASER', stroke=erase_stroke)



# get point on stroke, given by relative distance (0.0 - 1.0)
def gstretch_eval_stroke(stroke, distance, stroke_lengths_cache=False):
    from bisect import bisect_left
    from itertools import accumulate

    points = stroke.points
    lengths = stroke_lengths_cache
    if not lengths:
        totals = tuple(accumulate(
            ((right.co - left.co).length for left, right in zip(points, points[1:])), initial=0
        ))
        denominator = max(totals[-1], 1e-7)
        lengths = [value / denominator for value in totals]

    right = bisect_left(lengths, distance)
    if right == len(lengths):
        return points[-1].co, lengths
    if right == 0 or distance == lengths[right]:
        return points[right].co, lengths
    left = right - 1
    fraction = (distance - lengths[left]) / (lengths[right] - lengths[left])
    origin = points[left].co
    return origin + fraction * (points[right].co - origin), lengths


# create fake grease pencil strokes for the active object
def gstretch_get_fake_strokes(object, bm_mod, loops):
    transform = object.matrix_world
    return [gstretch_fake_stroke([transform @ bm_mod.verts[index].co for index in (path[0], path[-1])])
            for path, _ in loops]

# get strokes
def gstretch_get_strokes(self, context):
    looptools =  context.window_manager.looptools
    gp = get_strokes(self, context)
    if not gp:
        return(None)
    if looptools.gstretch_use_guide == "Annotation":
        layer = _active_annotation_layer(context)
    if looptools.gstretch_use_guide == "GPencil" and not looptools.gstretch_guide == None:
        return _gpencil_guide_strokes(looptools)
    if not layer:
        return(None)
    frame = layer.active_frame
    if not frame:
        return(None)
    strokes = frame.strokes
    if len(strokes) < 1:
        return(None)

    return(strokes)

# returns a list with loop-stroke pairs
def gstretch_match_loops_strokes(loops, strokes, object, bm_mod):
    if not loops or not strokes:
        return None

    def centroid(points):
        return sum(points, mathutils.Vector()) / len(points)

    bm_mod.verts.ensure_lookup_table()
    centers = [centroid([point.co for point in stroke.points]) for stroke in strokes]
    uses = [0] * len(centers)
    pairs = []
    for loop in loops:
        center = object.matrix_world @ centroid([bm_mod.verts[index].co for index in loop[0]])
        choice = min(range(len(centers)), key=lambda index: (uses[index], (center - centers[index]).length))
        uses[choice] += 1
        pairs.append([loop, strokes[choice]])
    return pairs


# match single selected vertices to the closest stroke endpoint
# returns a list of tuples, constructed as: (vertex, stroke, stroke point index)
def gstretch_match_single_verts(bm_mod, strokes, mat_world):
    """Attach disconnected selected vertices to distinct guide endpoints by nearness."""
    targets = [(mat_world @ stroke.points[index].co, stroke, index)
               for stroke in strokes if len(stroke.points) for index in (0, -1)]
    isolated = [vertex for vertex in bm_mod.verts if vertex.select and not any(
        edge.other_vert(vertex).select for edge in vertex.link_edges
    )]
    matches = []
    while targets and isolated:
        _, node, endpoint = min(
            ((vertex.co - target[0]).length, i, j)
            for i, vertex in enumerate(isolated) for j, target in enumerate(targets)
        )
        _, stroke, index = targets.pop(endpoint)
        matches.append((isolated.pop(node), stroke, index))
    return matches


# returns list with a relative distance (0.0 - 1.0) of each vertex on the loop
def gstretch_relative_lengths(loop, bm_mod):
    from itertools import accumulate

    positions = [bm_mod.verts[index].co for index in loop[0]]
    totals = tuple(accumulate(((right - left).length for left, right in zip(positions, positions[1:])), initial=0))
    length = max(totals[-1], 1e-7)
    return [value / length for value in totals]


# convert cache-stored strokes into usable (fake) GP strokes
def gstretch_safe_to_true_strokes(safe_strokes):
    strokes = []
    for safe_stroke in safe_strokes:
        strokes.append(gstretch_fake_stroke(safe_stroke))

    return(strokes)


# convert a GP stroke into a list of points which can be stored in cache
def gstretch_true_to_safe_strokes(strokes):
    safe_strokes = []
    for stroke in strokes:
        safe_strokes.append([p.co.copy() for p in stroke.points])

    return(safe_strokes)


# force consistency in GUI, max value can never be lower than min value
def gstretch_update_max(self, context):
    # called from operator settings (after execution)
    if hasattr(self, 'conversion_min'):
        if self.conversion_min > self.conversion_max:
            self.conversion_max = self.conversion_min
    # called from toolbar
    else:
        lt = context.window_manager.looptools
        if lt.gstretch_conversion_min > lt.gstretch_conversion_max:
            lt.gstretch_conversion_max = lt.gstretch_conversion_min


# force consistency in GUI, min value can never be higher than max value
def gstretch_update_min(self, context):
    # called from operator settings (after execution)
    if hasattr(self, 'conversion_max'):
        if self.conversion_max < self.conversion_min:
            self.conversion_min = self.conversion_max
    # called from toolbar
    else:
        lt = context.window_manager.looptools
        if lt.gstretch_conversion_max < lt.gstretch_conversion_min:
            lt.gstretch_conversion_min = lt.gstretch_conversion_max


# ########################################
# ##### Relax functions ##################
# ########################################

# create lists with knots and points, all correctly sorted
def relax_calculate_knots(loops):
    anchor_groups, moving_groups = [], []
    for vertices, cyclic in loops:
        if cyclic:
            around_seam = [vertices[-1], *vertices, vertices[0]]
            passes = (
                (around_seam[::2], around_seam[1::2]),
                (around_seam[1::2], around_seam[2::2]),
            ) if len(vertices) % 2 == 0 else (
                (vertices[::2], vertices[1::2]),
                (around_seam[::2], around_seam[1::2]),
            )
        else:
            passes = ((vertices[::2], vertices[1:-1:2]), (vertices[1::2], vertices[2:-1:2]))
        for index, (anchors, movers) in enumerate(passes):
            if not movers and index:
                continue
            if cyclic:
                if anchors[0] != anchors[-1]:
                    anchors = [*anchors, anchors[0]]
                movers = movers[:1] + [vertex for vertex in movers[1:] if vertex != movers[0]] if movers else []
            anchor_groups.append(anchors)
            moving_groups.append(movers)
    return anchor_groups, moving_groups


# calculate relative positions compared to first knot
def relax_calculate_t(bm_mod, knots, points, regular):
    anchor_times, moving_times = [], []
    for anchors, movers in zip(knots, points):
        previous = bm_mod.verts[anchors[0]].co
        cumulative = 0.0
        fixed = [0.0]
        measured = []
        for index, anchor in enumerate(anchors[1:]):
            if index < len(movers):
                middle = bm_mod.verts[movers[index]].co
                cumulative += (middle - previous).length
                measured.append(cumulative)
                previous = middle
            current = bm_mod.verts[anchor].co
            cumulative += (current - previous).length
            fixed.append(cumulative)
            previous = current
        anchor_times.append(fixed)
        if regular:
            measured = [(a + b) * 0.5 for a, b in zip(fixed, fixed[1:])][:len(movers)]
        moving_times.append(measured)
    return anchor_times, moving_times


# change the location of the points to their place on the spline
def relax_calculate_verts(bm_mod, interpolation, tknots, knots, tpoints, points, splines):
    from bisect import bisect_left

    moves = []
    for anchors, times, indices, segments in zip(tknots, tpoints, points, splines):
        for time, index in zip(times, indices):
            next_knot = bisect_left(anchors, time)
            at_knot = next_knot < len(anchors) and anchors[next_knot] == time
            interval = min(len(segments) - 1, max(0, next_knot - (not at_knot)))
            coefficients = segments[interval]
            if interpolation == 'linear':
                start, delta, origin, width = coefficients
                target = start + delta * ((time - origin) / (width or 1.0e-8))
            else:
                values = []
                for start, tangent, square, cubic, origin in coefficients:
                    offset = time - origin
                    values.append(start + offset * (tangent + offset * (square + offset * cubic)))
                target = mathutils.Vector(values)
            moves.append([index, bm_mod.verts[index].co.lerp(target, 0.5)])
    return moves


# ########################################
# ##### Space functions ##################
# ########################################

# calculate relative positions compared to first knot
def space_calculate_t(bm_mod, knots):
    if not knots:
        return [], []
    lengths = [0.0]
    for a, b in zip(knots, knots[1:]):
        lengths.append(lengths[-1] + (bm_mod.verts[b].co - bm_mod.verts[a].co).length)
    step = lengths[-1] / (len(knots) - 1)
    return lengths, [i * step for i in range(len(knots))]


# change the location of the points to their place on the spline
def space_calculate_verts(bm_mod, interpolation, tknots, tpoints, points, splines):
    from bisect import bisect_right

    moves = []
    for index, target in zip(points, tpoints):
        interval = min(max(0, bisect_right(tknots, target) - 1), len(splines) - 1)
        coefficients = splines[interval]
        if interpolation == "linear":
            start, delta, origin, width = coefficients
            point = start + delta * ((target - origin) / width if width else 0.0)
        else:
            xyz = []
            for a, b, c, d, origin in coefficients:
                t = target - origin
                xyz.append(((d * t + c) * t + b) * t + a)
            point = mathutils.Vector(xyz)
        moves.append([index, point])
    return moves


# ########################################
# ##### Operators ########################
# ########################################

# bridge operator
class Bridge(Operator):
    bl_idname = 'mesh.looptools_bridge'
    bl_label = "Bridge / Loft"
    bl_description = "Bridge two, or loft several, loops of vertices"
    bl_options = {'UNDO'}

    cubic_strength: FloatProperty(
        name="Strength",
        description="Higher strength results in more fluid curves",
        default=1.0,
        soft_min=-3.0,
        soft_max=3.0
        )
    interpolation: EnumProperty(
        name="Interpolation mode",
        items=(('cubic', "Cubic", "Gives curved results"),
            ('linear', "Linear", "Basic, fast, straight interpolation")),
        description="Interpolation mode: algorithm used when creating "
                    "segments",
        default='cubic'
        )
    loft: BoolProperty(
        name="Loft",
        description="Loft multiple loops, instead of considering them as "
                    "a multi-input for bridging",
        default=False
        )
    loft_loop: BoolProperty(
        name="Loop",
        description="Connect the first and the last loop with each other",
        default=False
        )
    min_width: IntProperty(
        name="Minimum width",
        description="Segments with an edge smaller than this are merged "
                    "(compared to base edge)",
        default=0,
        min=0,
        max=100,
        subtype='PERCENTAGE'
        )
    mode: EnumProperty(
        name="Mode",
        items=(('basic', "Basic", "Fast algorithm"),
               ('shortest', "Shortest edge", "Slower algorithm with better vertex matching")),
        description="Algorithm used for bridging",
        default='shortest'
        )
    remove_faces: BoolProperty(
        name="Remove faces",
        description="Remove faces that are internal after bridging",
        default=True
        )
    reverse: BoolProperty(
        name="Reverse",
        description="Manually override the direction in which the loops "
                    "are bridged. Only use if the tool gives the wrong result",
        default=False
        )
    segments: IntProperty(
        name="Segments",
        description="Number of segments used to bridge the gap (0=automatic)",
        default=1,
        min=0,
        soft_max=20
        )
    twist: IntProperty(
        name="Twist",
        description="Twist what vertices are connected to each other",
        default=0
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        body = self.layout.column()
        paired = body.row(align=True)
        subdivisions = paired.column(align=True)
        shape = paired.column(align=True)
        subdivisions.prop(self, "segments")
        blending = subdivisions.row()
        blending.enabled = self.segments > 1
        blending.prop(self, "interpolation", text="")
        width = shape.row()
        width.enabled = self.segments > 1
        width.prop(self, "min_width", text="")
        strength = shape.row()
        strength.enabled = self.segments > 1 and self.interpolation == "cubic"
        strength.prop(self, "cubic_strength")

        body.prop(self, "remove_faces")
        if self.loft:
            body.prop(self, "loft_loop")
        body.separator()
        override = body.row(align=True)
        override.prop(self, "twist")
        override.prop(self, "reverse")

    def invoke(self, context, event):
        # load custom settings
        context.window_manager.looptools.bridge_loft = self.loft
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        active, mesh = initialise()
        try:
            edge_faces, edges, selected_faces, smooth = bridge_initialise(mesh, self.interpolation)
            settings_write(self)
            key = bridge_input_method(self.loft, self.loft_loop)
            cache = cache_read("Bridge", active, mesh, key, False)
            contours = cache[2] if cache[0] else bridge_get_input(mesh)
            if not cache[0]:
                if len(contours) > 2:
                    if self.loft:
                        contours = bridge_sort_loops(mesh, contours, self.loft_loop)
                    else:
                        contours = bridge_match_loops(mesh, contours)
                cache_write("Bridge", active, mesh, key, False, False, contours, False, False)

            vertices, polygons, used_contours = [], [], []
            last_index = len(mesh.verts) - 1
            stride = 1 if self.loft else 2
            for first in range(0, len(contours)-1, stride):
                profiles = contours[first:first+2]
                links = bridge_calculate_lines(mesh, profiles, self.mode, self.twist, self.reverse)
                if len(links) < 2:
                    continue
                directions = bridge_calculate_virtual_vertex_normals(mesh, links, profiles, edge_faces, edges)
                count = bridge_calculate_segments(mesh, links, profiles, self.segments)
                points, faces, last_index = bridge_calculate_geometry(
                    mesh, links, directions, count, self.interpolation, self.cubic_strength, self.min_width, last_index)
                vertices.extend(points or ())
                polygons.extend(faces or ())
                if faces:
                    used_contours.extend(profiles)

            if polygons:
                remove_caps = self.remove_faces and selected_faces
                if remove_caps:
                    bridge_save_unused_faces(mesh, selected_faces, used_contours)
                if vertices:
                    bridge_create_vertices(mesh, vertices)
                if remove_caps:
                    bridge_remove_internal_faces(mesh, selected_faces)
                created = bridge_create_faces(active, mesh, polygons, self.twist)
                bridge_select_new_faces(created, smooth)
                if not vertices:
                    cache_delete("Bridge")
                bmesh.update_edit_mesh(active.data, loop_triangles=False, destructive=True)
                bpy.ops.mesh.normals_make_consistent()
            return {"FINISHED"}
        finally:
            terminate()


# circle operator
class Circle(Operator):
    bl_idname = "mesh.looptools_circle"
    bl_label = "Circle"
    bl_description = "Move selected vertices into a circle shape"
    bl_options = {'UNDO'}

    custom_radius: BoolProperty(
        name="Radius",
        description="Force a custom radius",
        default=False
        )
    fit: EnumProperty(
        name="Method",
        items=(("best", "Best fit", "Non-linear least squares"),
               ("inside", "Fit inside", "Only move vertices towards the center")),
        description="Method used for fitting a circle to the vertices",
        default='best'
        )
    flatten: BoolProperty(
        name="Flatten",
        description="Flatten the circle, instead of projecting it on the mesh",
        default=True
        )
    influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    lock_z: BoolProperty(name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    radius: FloatProperty(
        name="Radius",
        description="Custom radius for circle",
        default=1.0,
        min=0.0,
        soft_max=1000.0
        )
    angle: FloatProperty(
        name="Angle",
        description="Rotate a circle by an angle",
        unit='ROTATION',
        default=math.radians(0.0),
        soft_min=math.radians(-360.0),
        soft_max=math.radians(360.0)
        )
    regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the circle",
        default=True
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        column = self.layout.column()
        column.prop(self, "fit")
        column.separator()
        column.prop(self, "flatten")
        radius_controls = column.row(align=True)
        radius_controls.prop(self, "custom_radius")
        value = radius_controls.row(align=True)
        value.active = self.custom_radius
        value.prop(self, "radius", text="")
        for name in ("regular", "angle"):
            column.prop(self, name)
        column.separator()
        movement = column.column(align=True)
        axes = movement.row(align=True)
        for label in "XYZ":
            option = "lock_" + label.lower()
            icon = "LOCKED" if getattr(self, option) else "UNLOCKED"
            axes.prop(self, option, text=label, icon=icon)
        movement.prop(self, "influence")

    def invoke(self, context, event):
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        obj, editable = initialise()
        settings_write(self)
        saved, singles, loops, derived, mapping = cache_read("Circle", obj, editable, False, False)
        if saved:
            derived, reference = get_derived_bmesh(obj, editable, False)
        else:
            derived, reference, loose, singles, loops = circle_get_input(obj, editable)
            mapping = get_mapping(derived, editable, reference, loose, False, loops)
            singles, loops = circle_check_loops(singles, loops, mapping, reference)
        try:
            if not saved:
                cache_write("Circle", obj, editable, False, False, singles, loops, derived, mapping)
            fit = circle_calculate_best_fit if self.fit == "best" else circle_calculate_min_fit
            arrange = circle_project_regular if self.regular else circle_project_non_regular
            changes = []
            for index, loop in enumerate(loops):
                center, normal = calculate_plane(reference, loop)
                points = circle_shift_loop(reference, loop, center) if loop[1] else loop
                original, right, back = circle_3d_to_2d(reference, points, center, normal)
                x, y, radius = fit(original)
                if self.custom_radius:
                    radius = self.radius / right.length

                ideal = arrange(original[:], x, y, radius, self.angle)
                destination = circle_influence_locs(original, ideal, self.influence)
                changes.append(circle_calculate_verts(self.flatten, reference, destination, center, right, back, normal))
                if self.flatten and singles:
                    changes.append(circle_flatten_singles(reference, center, right, back, normal, singles[index]))

            locks = [self.lock_x, self.lock_y, self.lock_z]
            move_verts(obj, editable, mapping, changes, locks if any(locks) else False, -1)
        finally:
            if derived:
                reference.free()
            terminate()
        return {"FINISHED"}


# curve operator
class Curve(Operator):
    bl_idname = "mesh.looptools_curve"
    bl_label = "Curve"
    bl_description = "Turn a loop into a smooth curve"
    bl_options = {'UNDO'}

    boundaries: BoolProperty(
        name="Boundaries",
        description="Limit the tool to work within the boundaries of the selected vertices",
        default=False
        )
    influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
              ("linear", "Linear", "Simple and fast linear algorithm")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the curve",
        default=True
        )
    restriction: EnumProperty(
        name="Restriction",
        items=(("none", "None", "No restrictions on vertex movement"),
              ("extrude", "Extrude only", "Only allow extrusions (no indentations)"),
              ("indent", "Indent only", "Only allow indentation (no extrusions)")),
        description="Restrictions on how the vertices can be moved",
        default='none'
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        body = self.layout.column()
        for name in ("interpolation", "restriction", "boundaries", "regular"):
            body.prop(self, name)

        body.separator()
        axes = body.row(align=True)
        for axis in "xyz":
            prop = "lock_" + axis
            icon = "LOCKED" if getattr(self, prop) else "UNLOCKED"
            axes.prop(self, prop, text=axis.upper(), icon=icon)
        body.prop(self, "influence")

    def invoke(self, context, event):
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        obj, editable = initialise()
        settings_write(self)
        cached, _, loops, derived, mapping = cache_read("Curve", obj, editable, False, self.boundaries)
        if cached:
            derived, reference = get_derived_bmesh(obj, editable, False)
        else:
            derived, reference, loops = curve_get_input(obj, editable, self.boundaries)
            mapping = get_mapping(derived, editable, reference, False, True, loops)
            loops = check_loops(loops, mapping, reference)

        try:
            selected = {vertex.index for vertex in reference.verts if vertex.select and not vertex.hide}
            if not cached:
                cache_write("Curve", obj, editable, False, self.boundaries, False, loops, derived, mapping)
            movements = []
            for route in loops:
                knots, points = curve_calculate_knots(route, selected)
                closed = route[1]
                projected = curve_project_knots(reference, selected, knots, points, closed)
                anchors, distances = curve_calculate_t(reference, knots, points, projected, self.regular, closed)
                pieces = calculate_splines(self.interpolation, reference, anchors, knots)
                edits = curve_calculate_vertices(reference, knots, anchors, points, distances, pieces,
                                                self.interpolation, self.restriction)
                movements.append(edits)
            mask = [self.lock_x, self.lock_y, self.lock_z]
            move_verts(obj, editable, mapping, movements, mask if any(mask) else False, self.influence)
        finally:
            if derived:
                reference.free()
            terminate()
        return {"FINISHED"}


# flatten operator
class Flatten(Operator):
    bl_idname = "mesh.looptools_flatten"
    bl_label = "Flatten"
    bl_description = "Flatten vertices on a best-fitting plane"
    bl_options = {'UNDO'}

    influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    lock_z: BoolProperty(name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    plane: EnumProperty(
        name="Plane",
        items=(("best_fit", "Best fit", "Calculate a best fitting plane"),
              ("normal", "Normal", "Derive plane from averaging vertex normals"),
              ("view", "View", "Flatten on a plane perpendicular to the viewing angle")),
        description="Plane on which vertices are flattened",
        default='best_fit'
        )
    restriction: EnumProperty(
        name="Restriction",
        items=(("none", "None", "No restrictions on vertex movement"),
               ("bounding_box", "Bounding box", "Vertices are restricted to "
               "movement inside the bounding box of the selection")),
        description="Restrictions on how the vertices can be moved",
        default='none'
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        options = self.layout.column()
        options.prop(self, "plane")
        options.separator()
        movement = options.column(align=True)
        locks = movement.row(align=True)
        for axis in "XYZ":
            key = f"lock_{axis.lower()}"
            locks.prop(self, key, text=axis, icon="LOCKED" if getattr(self, key) else "UNLOCKED")
        movement.prop(self, "influence")

    def invoke(self, context, event):
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        obj, mesh = initialise()
        try:
            settings_write(self)
            cached, _, regions, _, mapping = cache_read("Flatten", obj, mesh, False, False)
            if not cached:
                regions = check_loops(flatten_get_input(mesh), mapping, mesh)
                cache_write("Flatten", obj, mesh, False, False, False, regions, False, False)

            method = self.plane
            adjustments = [
                flatten_project(mesh, region, *calculate_plane(mesh, region, method=method, object=obj))
                for region in regions
            ]
            locks = [self.lock_x, self.lock_y, self.lock_z]
            move_verts(obj, mesh, False, adjustments, locks if any(locks) else False, self.influence)
        finally:
            terminate()
        return {"FINISHED"}


# Annotation operator
class RemoveAnnotation(Operator):
    bl_idname = "remove.annotation"
    bl_label = "Remove Annotation"
    bl_description = "Remove all Annotation Strokes"
    bl_options = {'UNDO'}

    def execute(self, context):

        layer = _active_annotation_layer(context)
        if layer is None or len(layer.frames) == 0:
            self.report({'INFO'}, "No Annotation data to Unlink")
            return {'CANCELLED'}
        for frame in list(layer.frames):
            layer.frames.remove(frame)

        return{'FINISHED'}

# GPencil operator
class RemoveGPencil(Operator):
    bl_idname = "remove.gp"
    bl_label = "Remove GPencil"
    bl_description = "Remove all GPencil Strokes"
    bl_options = {'UNDO'}

    def execute(self, context):

        try:
            looptools =  context.window_manager.looptools
            guide_data = looptools.gstretch_guide.data
            for layer in guide_data.layers:
                for frame in layer.frames:
                    frame.drawing.remove_strokes()
            guide_data.update_tag()
        except:
            self.report({'INFO'}, "No GPencil data to Unlink")
            return {'CANCELLED'}

        return{'FINISHED'}


class GStretch(Operator):
    bl_idname = "mesh.looptools_gstretch"
    bl_label = "Gstretch"
    bl_description = "Stretch selected vertices to active stroke"
    bl_options = {'UNDO'}

    conversion: EnumProperty(
        name="Conversion",
        items=(("distance", "Distance", "Set the distance between vertices "
                "of the converted  stroke"),
               ("limit_vertices", "Limit vertices", "Set the minimum and maximum "
                "number of vertices that converted strokes will have"),
               ("vertices", "Exact vertices", "Set the exact number of vertices "
                "that converted strokes will have. Short strokes "
                "with few points may contain less vertices than this number."),
               ("none", "No simplification", "Convert each point "
                "to a vertex")),
        description="If strokes are converted to geometry, "
                    "use this simplification method",
        default='limit_vertices'
        )
    conversion_distance: FloatProperty(
        name="Distance",
        description="Absolute distance between vertices along the converted "
                    " stroke",
        default=0.1,
        min=0.000001,
        soft_min=0.01,
        soft_max=100
        )
    conversion_max: IntProperty(
        name="Max Vertices",
        description="Maximum number of vertices strokes will "
                    "have, when they are converted to geometry",
        default=32,
        min=3,
        soft_max=500,
        update=gstretch_update_min
        )
    conversion_min: IntProperty(
        name="Min Vertices",
        description="Minimum number of vertices strokes will "
                    "have, when they are converted to geometry",
        default=8,
        min=3,
        soft_max=500,
        update=gstretch_update_max
        )
    conversion_vertices: IntProperty(
        name="Vertices",
        description="Number of vertices strokes will "
                    "have, when they are converted to geometry. If strokes have less "
                    "points than required, the 'Spread evenly' method is used",
        default=32,
        min=3,
        soft_max=500
        )
    delete_strokes: BoolProperty(
        name="Delete strokes",
        description="Remove strokes if they have been used."
                    "WARNING: DOES NOT SUPPORT UNDO",
        default=False
        )
    influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    method: EnumProperty(
        name="Method",
        items=(("project", "Project", "Project vertices onto the stroke, "
                 "using vertex normals and connected edges"),
                ("irregular", "Spread", "Distribute vertices along the full "
                "stroke, retaining relative distances between the vertices"),
                ("regular", "Spread evenly", "Distribute vertices at regular "
                "distances along the full stroke")),
        description="Method of distributing the vertices over the "
                    "stroke",
        default='regular'
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        options = self.layout.column()
        options.prop(self, "method")
        options.separator()
        conversion = options.column(align=True)
        conversion.prop(self, "conversion", text="")
        if self.conversion == "limit_vertices":
            bounds = conversion.row(align=True)
            for field, label in (("conversion_min", "Min"), ("conversion_max", "Max")):
                bounds.prop(self, field, text=label)
        else:
            field = {"distance": "conversion_distance", "vertices": "conversion_vertices"}.get(self.conversion)
            if field:
                conversion.prop(self, field)
        options.separator()
        movement = options.column(align=True)
        locks = movement.row(align=True)
        for axis in "XYZ":
            name = f"lock_{axis.lower()}"
            locks.prop(self, name, text=axis, icon="LOCKED" if getattr(self, name) else "UNLOCKED")
        movement.prop(self, "influence")
        options.separator()
        guide = context.window_manager.looptools.gstretch_use_guide
        action = {"Annotation": ("remove.annotation", "Delete annotation strokes"),
                  "GPencil": ("remove.gp", "Delete GPencil strokes")}.get(guide)
        if action:
            options.operator(action[0], text=action[1])

    def invoke(self, context, event):
        # flush cached strokes
        if 'Gstretch' in looptools_cache:
            looptools_cache['Gstretch']['single_loops'] = []
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        # initialise
        object, bm = initialise()
        settings_write(self)

        # check cache to see if we can save time
        cached, safe_strokes, loops, derived, mapping = cache_read("Gstretch",
            object, bm, False, False)
        if cached:
            straightening = False
            if safe_strokes:
                strokes = gstretch_safe_to_true_strokes(safe_strokes)
            # cached strokes were flushed (see operator's invoke function)
            elif get_strokes(self, context):
                strokes = gstretch_get_strokes(self, context)
            else:
                # straightening function (no GP) -> loops ignore modifiers
                straightening = True
                derived = False
                bm_mod = bm.copy()
                bm_mod.verts.ensure_lookup_table()
                bm_mod.edges.ensure_lookup_table()
                bm_mod.faces.ensure_lookup_table()
                strokes = gstretch_get_fake_strokes(object, bm_mod, loops)
            if not straightening:
                derived, bm_mod = get_derived_bmesh(object, bm, False)
        else:
            # get loops and strokes
            if get_strokes(self, context):
                # find loops
                derived, bm_mod, loops = get_connected_input(object, bm, False, input='selected')
                mapping = get_mapping(derived, bm, bm_mod, False, False, loops)
                loops = check_loops(loops, mapping, bm_mod)
                # get strokes
                strokes = gstretch_get_strokes(self, context)
            else:
                # straightening function (no GP) -> loops ignore modifiers
                derived = False
                mapping = False
                bm_mod = bm.copy()
                bm_mod.verts.ensure_lookup_table()
                bm_mod.edges.ensure_lookup_table()
                bm_mod.faces.ensure_lookup_table()
                edge_keys = [
                    edgekey(edge) for edge in bm_mod.edges if
                    edge.select and not edge.hide
                    ]
                loops = get_connected_selections(edge_keys)
                loops = check_loops(loops, mapping, bm_mod)
                # create fake strokes
                strokes = gstretch_get_fake_strokes(object, bm_mod, loops)

        # saving cache for faster execution next time
        if not cached:
            if strokes:
                safe_strokes = gstretch_true_to_safe_strokes(strokes)
            else:
                safe_strokes = []
            cache_write("Gstretch", object, bm, False, False,
                safe_strokes, loops, derived, mapping)

        # pair loops and strokes
        ls_pairs = gstretch_match_loops_strokes(loops, strokes, object, bm_mod)
        ls_pairs = gstretch_align_pairs(ls_pairs, object, bm_mod, self.method)

        move = []
        if not loops:
            # no selected geometry, convert GP to verts
            if strokes:
                move.append(gstretch_create_verts(object, bm, strokes,
                    self.method, self.conversion, self.conversion_distance,
                    self.conversion_max, self.conversion_min,
                    self.conversion_vertices))
                # Last first: removing a stroke renumbers the ones after it.
                for stroke in reversed(strokes):
                    gstretch_erase_stroke(stroke, context)
        elif ls_pairs:
            for (loop, stroke) in ls_pairs:
                move.append(gstretch_calculate_verts(loop, stroke, object,
                    bm_mod, self.method))
                if self.delete_strokes:
                    if not isinstance(stroke, bpy.types.AnnotationStroke):
                        # in case of cached fake stroke, get the real one
                        if get_strokes(self, context):
                            strokes = gstretch_get_strokes(self, context)
                            if loops and strokes:
                                ls_pairs = gstretch_match_loops_strokes(loops,
                                    strokes, object, bm_mod)
                                ls_pairs = gstretch_align_pairs(ls_pairs,
                                    object, bm_mod, self.method)
                                for (l, s) in ls_pairs:
                                    if l == loop:
                                        stroke = s
                                        break
                    gstretch_erase_stroke(stroke, context)

        # move vertices to new locations
        if self.lock_x or self.lock_y or self.lock_z:
            lock = [self.lock_x, self.lock_y, self.lock_z]
        else:
            lock = False
        bmesh.update_edit_mesh(object.data, loop_triangles=True, destructive=True)
        move_verts(object, bm, mapping, move, lock, self.influence)

        # cleaning up
        if derived:
            bm_mod.free()
        terminate()

        return{'FINISHED'}


# relax operator
class Relax(Operator):
    bl_idname = "mesh.looptools_relax"
    bl_label = "Relax"
    bl_description = "Relax the loop, so it is smoother"
    bl_options = {'UNDO'}

    input: EnumProperty(
        name="Input",
        items=(("all", "Parallel (all)", "Also use non-selected "
               "parallel loops as input"),
               ("selected", "Selection", "Only use selected vertices as input")),
        description="Loops that are relaxed",
        default='selected'
        )
    interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
               ("linear", "Linear", "Simple and fast linear algorithm")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    iterations: EnumProperty(
        name="Iterations",
        items=(("1", "1", "One"),
               ("3", "3", "Three"),
               ("5", "5", "Five"),
               ("10", "10", "Ten"),
              ("25", "25", "Twenty-five")),
        description="Number of times the loop is relaxed",
        default="1"
        )
    regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the loop",
        default=True
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        controls = self.layout.column()
        for name in ("interpolation", "input", "iterations", "regular"):
            controls.prop(self, name)

    def invoke(self, context, event):
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        obj, mesh = initialise()
        mirror = False
        evaluated = None
        try:
            settings_write(self)
            scope, interpolation = self.input, self.interpolation
            cached, _, paths, _, mapping = cache_read("Relax", obj, mesh, scope, False)
            if cached:
                mirror, evaluated = get_derived_bmesh(obj, mesh, False)
            else:
                mirror, evaluated, paths = get_connected_input(obj, mesh, False, scope)
                mapping = get_mapping(mirror, mesh, evaluated, False, False, paths)
                paths = check_loops(paths, mapping, evaluated)

            anchors, samples = relax_calculate_knots(paths)
            if not cached:
                cache_write("Relax", obj, mesh, scope, False, False, paths, mirror, mapping)

            for _ in range(int(self.iterations)):
                anchor_distances, sample_distances = relax_calculate_t(evaluated, anchors, samples, self.regular)
                coefficients = [
                    calculate_splines(interpolation, evaluated, distances, vertices)
                    for distances, vertices in zip(anchor_distances, anchors, strict=True)
                ]
                positions = relax_calculate_verts(evaluated, interpolation, anchor_distances,
                                                  anchors, sample_distances, samples, coefficients)
                move_verts(obj, mesh, mapping, [positions], False, -1)
        finally:
            if mirror and evaluated is not None:
                evaluated.free()
            terminate()
        return {"FINISHED"}


# space operator
class Space(Operator):
    bl_idname = "mesh.looptools_space"
    bl_label = "Space"
    bl_description = "Space the vertices in a regular distribution on the loop"
    bl_options = {'UNDO'}

    influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    input: EnumProperty(
        name="Input",
        items=(("all", "Parallel (all)", "Also use non-selected "
                "parallel loops as input"),
              ("selected", "Selection", "Only use selected vertices as input")),
        description="Loops that are spaced",
        default='selected'
        )
    interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
              ("linear", "Linear", "Vertices are projected on existing edges")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return(ob and ob.type == 'MESH' and context.mode == 'EDIT_MESH')

    def draw(self, context):
        controls = self.layout.column()
        for key in ("interpolation", "input"):
            controls.prop(self, key)
        controls.separator()
        placement = controls.column(align=True)
        toggles = placement.row(align=True)
        for letter in "XYZ":
            key = f"lock_{letter.lower()}"
            icon = "LOCKED" if getattr(self, key) else "UNLOCKED"
            toggles.prop(self, key, text=letter, icon=icon)
        placement.prop(self, "influence")

    def invoke(self, context, event):
        # load custom settings
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        obj, live_mesh = initialise()
        derived = False
        mesh = None
        try:
            settings_write(self)
            scope = self.input
            cached, _, paths, _, mapping = cache_read("Space", obj, live_mesh, scope, False)
            if cached:
                derived, mesh = get_derived_bmesh(obj, live_mesh, True)
            else:
                derived, mesh, paths = get_connected_input(obj, live_mesh, True, scope)
                mapping = get_mapping(derived, live_mesh, mesh, False, False, paths)
                paths = check_loops(paths, mapping, mesh)
                cache_write("Space", obj, live_mesh, scope, False, False, paths, derived, mapping)

            interpolation = self.interpolation
            positions = []
            for indices, ring in paths:
                knots = [*indices, indices[0]] if ring else indices[:]
                distances, targets = space_calculate_t(mesh, knots)
                coefficients = calculate_splines(interpolation, mesh, distances, knots)
                positions.append(space_calculate_verts(mesh, interpolation, distances,
                                                       targets, knots[:-1], coefficients))
            locks = [self.lock_x, self.lock_y, self.lock_z]
            move_verts(obj, live_mesh, mapping, positions, locks if any(locks) else False, self.influence)
        finally:
            if derived and mesh is not None:
                mesh.free()
            terminate()
            cache_delete("Space")
        return {"FINISHED"}


# ########################################
# ##### GUI and registration #############
# ########################################

# menu containing all tools
class VIEW3D_MT_edit_mesh_looptools(Menu):
    bl_label = "Loop Tools"

    def draw(self, context):
        actions = (
            ("bridge", "Bridge", False), ("circle", None, None), ("curve", None, None),
            ("flatten", None, None), ("gstretch", None, None), ("bridge", "Loft", True),
            ("relax", None, None), ("space", None, None),
        )
        for name, text, loft in actions:
            identifier = "mesh.looptools_" + name
            if loft is None:
                self.layout.operator(identifier)
            else:
                self.layout.operator(identifier, text=text).loft = loft


# panel containing all tools
class VIEW3D_PT_tools_looptools(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_context = "mesh_edit"
    bl_label = "Loop Tools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        lt = context.window_manager.looptools

        # bridge - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_bridge:
            split.prop(lt, "display_bridge", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_bridge", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_bridge", text="Bridge").loft = False
        draw_section_help(split, "looptools_bridge")
        # bridge - settings
        if lt.display_bridge:
            box = col.column(align=True).box().column()
            # box.prop(self, "mode")

            # top row
            col_top = box.column(align=True)
            row = col_top.row(align=True)
            col_left = row.column(align=True)
            col_right = row.column(align=True)
            col_right.active = lt.bridge_segments != 1
            col_left.prop(lt, "bridge_segments")
            col_right.prop(lt, "bridge_min_width", text="")
            # bottom row
            bottom_left = col_left.row()
            bottom_left.active = lt.bridge_segments != 1
            bottom_left.prop(lt, "bridge_interpolation", text="")
            bottom_right = col_right.row()
            bottom_right.active = lt.bridge_interpolation == 'cubic'
            bottom_right.prop(lt, "bridge_cubic_strength")
            # boolean properties
            col_top.prop(lt, "bridge_remove_faces")

            # override properties
            col_top.separator()
            row = box.row(align=True)
            row.prop(lt, "bridge_twist")
            row.prop(lt, "bridge_reverse")

        # circle - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_circle:
            split.prop(lt, "display_circle", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_circle", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_circle")
        # circle - settings
        if lt.display_circle:
            box = col.column(align=True).box().column()
            box.prop(lt, "circle_fit")
            box.separator()

            box.prop(lt, "circle_flatten")
            row = box.row(align=True)
            row.prop(lt, "circle_custom_radius")
            row_right = row.row(align=True)
            row_right.active = lt.circle_custom_radius
            row_right.prop(lt, "circle_radius", text="")
            box.prop(lt, "circle_regular")
            box.separator()

            col_move = box.column(align=True)
            row = col_move.row(align=True)
            if lt.circle_lock_x:
                row.prop(lt, "circle_lock_x", text="X", icon='LOCKED')
            else:
                row.prop(lt, "circle_lock_x", text="X", icon='UNLOCKED')
            if lt.circle_lock_y:
                row.prop(lt, "circle_lock_y", text="Y", icon='LOCKED')
            else:
                row.prop(lt, "circle_lock_y", text="Y", icon='UNLOCKED')
            if lt.circle_lock_z:
                row.prop(lt, "circle_lock_z", text="Z", icon='LOCKED')
            else:
                row.prop(lt, "circle_lock_z", text="Z", icon='UNLOCKED')
            col_move.prop(lt, "circle_influence")

        # curve - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_curve:
            split.prop(lt, "display_curve", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_curve", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_curve")
        # curve - settings
        if lt.display_curve:
            box = col.column(align=True).box().column()
            box.prop(lt, "curve_interpolation")
            box.prop(lt, "curve_restriction")
            box.prop(lt, "curve_boundaries")
            box.prop(lt, "curve_regular")
            box.separator()

            col_move = box.column(align=True)
            row = col_move.row(align=True)
            if lt.curve_lock_x:
                row.prop(lt, "curve_lock_x", text="X", icon='LOCKED')
            else:
                row.prop(lt, "curve_lock_x", text="X", icon='UNLOCKED')
            if lt.curve_lock_y:
                row.prop(lt, "curve_lock_y", text="Y", icon='LOCKED')
            else:
                row.prop(lt, "curve_lock_y", text="Y", icon='UNLOCKED')
            if lt.curve_lock_z:
                row.prop(lt, "curve_lock_z", text="Z", icon='LOCKED')
            else:
                row.prop(lt, "curve_lock_z", text="Z", icon='UNLOCKED')
            col_move.prop(lt, "curve_influence")

        # flatten - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_flatten:
            split.prop(lt, "display_flatten", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_flatten", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_flatten")
        # flatten - settings
        if lt.display_flatten:
            box = col.column(align=True).box().column()
            box.prop(lt, "flatten_plane")
            # box.prop(lt, "flatten_restriction")
            box.separator()

            col_move = box.column(align=True)
            row = col_move.row(align=True)
            if lt.flatten_lock_x:
                row.prop(lt, "flatten_lock_x", text="X", icon='LOCKED')
            else:
                row.prop(lt, "flatten_lock_x", text="X", icon='UNLOCKED')
            if lt.flatten_lock_y:
                row.prop(lt, "flatten_lock_y", text="Y", icon='LOCKED')
            else:
                row.prop(lt, "flatten_lock_y", text="Y", icon='UNLOCKED')
            if lt.flatten_lock_z:
                row.prop(lt, "flatten_lock_z", text="Z", icon='LOCKED')
            else:
                row.prop(lt, "flatten_lock_z", text="Z", icon='UNLOCKED')
            col_move.prop(lt, "flatten_influence")

        # gstretch - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_gstretch:
            split.prop(lt, "display_gstretch", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_gstretch", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_gstretch")
        # gstretch settings
        if lt.display_gstretch:
            box = col.column(align=True).box().column()
            box.prop(lt, "gstretch_use_guide")
            if lt.gstretch_use_guide == "GPencil":
                box.prop(lt, "gstretch_guide")
            box.prop(lt, "gstretch_method")

            col_conv = box.column(align=True)
            col_conv.prop(lt, "gstretch_conversion", text="")
            if lt.gstretch_conversion == 'distance':
                col_conv.prop(lt, "gstretch_conversion_distance")
            elif lt.gstretch_conversion == 'limit_vertices':
                row = col_conv.row(align=True)
                row.prop(lt, "gstretch_conversion_min", text="Min")
                row.prop(lt, "gstretch_conversion_max", text="Max")
            elif lt.gstretch_conversion == 'vertices':
                col_conv.prop(lt, "gstretch_conversion_vertices")
            box.separator()

            col_move = box.column(align=True)
            row = col_move.row(align=True)
            if lt.gstretch_lock_x:
                row.prop(lt, "gstretch_lock_x", text="X", icon='LOCKED')
            else:
                row.prop(lt, "gstretch_lock_x", text="X", icon='UNLOCKED')
            if lt.gstretch_lock_y:
                row.prop(lt, "gstretch_lock_y", text="Y", icon='LOCKED')
            else:
                row.prop(lt, "gstretch_lock_y", text="Y", icon='UNLOCKED')
            if lt.gstretch_lock_z:
                row.prop(lt, "gstretch_lock_z", text="Z", icon='LOCKED')
            else:
                row.prop(lt, "gstretch_lock_z", text="Z", icon='UNLOCKED')
            col_move.prop(lt, "gstretch_influence")
            if lt.gstretch_use_guide == "Annotation":
                box.operator("remove.annotation", text="Delete Annotation Strokes")
            if lt.gstretch_use_guide == "GPencil":
                box.operator("remove.gp", text="Delete GPencil Strokes")

        # loft - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_loft:
            split.prop(lt, "display_loft", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_loft", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_bridge", text="Loft").loft = True
        draw_section_help(split, "looptools_loft")
        # loft - settings
        if lt.display_loft:
            box = col.column(align=True).box().column()
            # box.prop(self, "mode")

            # top row
            col_top = box.column(align=True)
            row = col_top.row(align=True)
            col_left = row.column(align=True)
            col_right = row.column(align=True)
            col_right.active = lt.bridge_segments != 1
            col_left.prop(lt, "bridge_segments")
            col_right.prop(lt, "bridge_min_width", text="")
            # bottom row
            bottom_left = col_left.row()
            bottom_left.active = lt.bridge_segments != 1
            bottom_left.prop(lt, "bridge_interpolation", text="")
            bottom_right = col_right.row()
            bottom_right.active = lt.bridge_interpolation == 'cubic'
            bottom_right.prop(lt, "bridge_cubic_strength")
            # boolean properties
            col_top.prop(lt, "bridge_remove_faces")
            col_top.prop(lt, "bridge_loft_loop")

            # override properties
            col_top.separator()
            row = box.row(align=True)
            row.prop(lt, "bridge_twist")
            row.prop(lt, "bridge_reverse")

        # relax - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_relax:
            split.prop(lt, "display_relax", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_relax", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_relax")
        # relax - settings
        if lt.display_relax:
            box = col.column(align=True).box().column()
            box.prop(lt, "relax_interpolation")
            box.prop(lt, "relax_input")
            box.prop(lt, "relax_iterations")
            box.prop(lt, "relax_regular")

        # space - first line
        split = col.split(factor=0.15, align=True)
        if lt.display_space:
            split.prop(lt, "display_space", text="", icon='DOWNARROW_HLT')
        else:
            split.prop(lt, "display_space", text="", icon='RIGHTARROW')
        split.operator("mesh.looptools_space")
        # space - settings
        if lt.display_space:
            box = col.column(align=True).box().column()
            box.prop(lt, "space_interpolation")
            box.prop(lt, "space_input")
            box.separator()

            col_move = box.column(align=True)
            row = col_move.row(align=True)
            if lt.space_lock_x:
                row.prop(lt, "space_lock_x", text="X", icon='LOCKED')
            else:
                row.prop(lt, "space_lock_x", text="X", icon='UNLOCKED')
            if lt.space_lock_y:
                row.prop(lt, "space_lock_y", text="Y", icon='LOCKED')
            else:
                row.prop(lt, "space_lock_y", text="Y", icon='UNLOCKED')
            if lt.space_lock_z:
                row.prop(lt, "space_lock_z", text="Z", icon='LOCKED')
            else:
                row.prop(lt, "space_lock_z", text="Z", icon='UNLOCKED')
            col_move.prop(lt, "space_influence")


# property group containing all properties for the gui in the panel
class LoopToolSettings(PropertyGroup):
    """
    Fake module like class
    bpy.context.window_manager.looptools
    """
    # general display properties
    display_bridge: BoolProperty(
        name="Bridge settings",
        description="Display settings of the Bridge tool",
        default=False
        )
    display_circle: BoolProperty(
        name="Circle settings",
        description="Display settings of the Circle tool",
        default=False
        )
    display_curve: BoolProperty(
        name="Curve settings",
        description="Display settings of the Curve tool",
        default=False
        )
    display_flatten: BoolProperty(
        name="Flatten settings",
        description="Display settings of the Flatten tool",
        default=False
        )
    display_gstretch: BoolProperty(
        name="Gstretch settings",
        description="Display settings of the Gstretch tool",
        default=False
        )
    display_loft: BoolProperty(
        name="Loft settings",
        description="Display settings of the Loft tool",
        default=False
        )
    display_relax: BoolProperty(
        name="Relax settings",
        description="Display settings of the Relax tool",
        default=False
        )
    display_space: BoolProperty(
        name="Space settings",
        description="Display settings of the Space tool",
        default=False
        )

    # bridge properties
    bridge_cubic_strength: FloatProperty(
        name="Strength",
        description="Higher strength results in more fluid curves",
        default=1.0,
        soft_min=-3.0,
        soft_max=3.0
        )
    bridge_interpolation: EnumProperty(
        name="Interpolation mode",
        items=(('cubic', "Cubic", "Gives curved results"),
                ('linear', "Linear", "Basic, fast, straight interpolation")),
        description="Interpolation mode: algorithm used when creating segments",
        default='cubic'
        )
    bridge_loft: BoolProperty(
        name="Loft",
        description="Loft multiple loops, instead of considering them as "
                    "a multi-input for bridging",
        default=False
        )
    bridge_loft_loop: BoolProperty(
        name="Loop",
        description="Connect the first and the last loop with each other",
        default=False
        )
    bridge_min_width: IntProperty(
        name="Minimum width",
        description="Segments with an edge smaller than this are merged "
                    "(compared to base edge)",
        default=0,
        min=0,
        max=100,
        subtype='PERCENTAGE'
        )
    bridge_mode: EnumProperty(
        name="Mode",
        items=(('basic', "Basic", "Fast algorithm"),
                 ('shortest', "Shortest edge", "Slower algorithm with "
                                               "better vertex matching")),
        description="Algorithm used for bridging",
        default='shortest'
        )
    bridge_remove_faces: BoolProperty(
        name="Remove faces",
        description="Remove faces that are internal after bridging",
        default=True
        )
    bridge_reverse: BoolProperty(
        name="Reverse",
        description="Manually override the direction in which the loops "
                    "are bridged. Only use if the tool gives the wrong result",
        default=False
        )
    bridge_segments: IntProperty(
        name="Segments",
        description="Number of segments used to bridge the gap (0=automatic)",
        default=1,
        min=0,
        soft_max=20
        )
    bridge_twist: IntProperty(
        name="Twist",
        description="Twist what vertices are connected to each other",
        default=0
        )

    # circle properties
    circle_custom_radius: BoolProperty(
        name="Radius",
        description="Force a custom radius",
        default=False
        )
    circle_fit: EnumProperty(
        name="Method",
        items=(("best", "Best fit", "Non-linear least squares"),
            ("inside", "Fit inside", "Only move vertices towards the center")),
        description="Method used for fitting a circle to the vertices",
        default='best'
        )
    circle_flatten: BoolProperty(
        name="Flatten",
        description="Flatten the circle, instead of projecting it on the mesh",
        default=True
        )
    circle_influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    circle_lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    circle_lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    circle_lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    circle_radius: FloatProperty(
        name="Radius",
        description="Custom radius for circle",
        default=1.0,
        min=0.0,
        soft_max=1000.0
        )
    circle_regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the circle",
        default=True
        )
    circle_angle: FloatProperty(
        name="Angle",
        description="Rotate a circle by an angle",
        unit='ROTATION',
        default=math.radians(0.0),
        soft_min=math.radians(-360.0),
        soft_max=math.radians(360.0)
        )
    # curve properties
    curve_boundaries: BoolProperty(
        name="Boundaries",
        description="Limit the tool to work within the boundaries of the "
                    "selected vertices",
        default=False
        )
    curve_influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    curve_interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
            ("linear", "Linear", "Simple and fast linear algorithm")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    curve_lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    curve_lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    curve_lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    curve_regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the curve",
        default=True
        )
    curve_restriction: EnumProperty(
        name="Restriction",
        items=(("none", "None", "No restrictions on vertex movement"),
            ("extrude", "Extrude only", "Only allow extrusions (no indentations)"),
            ("indent", "Indent only", "Only allow indentation (no extrusions)")),
        description="Restrictions on how the vertices can be moved",
        default='none'
        )

    # flatten properties
    flatten_influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    flatten_lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False)
    flatten_lock_y: BoolProperty(name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    flatten_lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    flatten_plane: EnumProperty(
        name="Plane",
        items=(("best_fit", "Best fit", "Calculate a best fitting plane"),
            ("normal", "Normal", "Derive plane from averaging vertex "
            "normals"),
            ("view", "View", "Flatten on a plane perpendicular to the "
            "viewing angle")),
        description="Plane on which vertices are flattened",
        default='best_fit'
        )
    flatten_restriction: EnumProperty(
        name="Restriction",
        items=(("none", "None", "No restrictions on vertex movement"),
            ("bounding_box", "Bounding box", "Vertices are restricted to "
            "movement inside the bounding box of the selection")),
        description="Restrictions on how the vertices can be moved",
        default='none'
        )

    # gstretch properties
    gstretch_conversion: EnumProperty(
        name="Conversion",
        items=(("distance", "Distance", "Set the distance between vertices "
            "of the converted stroke"),
            ("limit_vertices", "Limit vertices", "Set the minimum and maximum "
            "number of vertices that converted GP strokes will have"),
            ("vertices", "Exact vertices", "Set the exact number of vertices "
            "that converted strokes will have. Short strokes "
            "with few points may contain less vertices than this number."),
            ("none", "No simplification", "Convert each point "
            "to a vertex")),
        description="If strokes are converted to geometry, "
                    "use this simplification method",
        default='limit_vertices'
        )
    gstretch_conversion_distance: FloatProperty(
        name="Distance",
        description="Absolute distance between vertices along the converted "
                    "stroke",
        default=0.1,
        min=0.000001,
        soft_min=0.01,
        soft_max=100
        )
    gstretch_conversion_max: IntProperty(
        name="Max Vertices",
        description="Maximum number of vertices strokes will "
                    "have, when they are converted to geometry",
        default=32,
        min=3,
        soft_max=500,
        update=gstretch_update_min
        )
    gstretch_conversion_min: IntProperty(
        name="Min Vertices",
        description="Minimum number of vertices strokes will "
                    "have, when they are converted to geometry",
        default=8,
        min=3,
        soft_max=500,
        update=gstretch_update_max
        )
    gstretch_conversion_vertices: IntProperty(
        name="Vertices",
        description="Number of vertices strokes will "
                    "have, when they are converted to geometry. If strokes have less "
                    "points than required, the 'Spread evenly' method is used",
        default=32,
        min=3,
        soft_max=500
        )
    gstretch_delete_strokes: BoolProperty(
        name="Delete strokes",
        description="Remove Grease Pencil strokes if they have been used "
                    "for Gstretch. WARNING: DOES NOT SUPPORT UNDO",
        default=False
        )
    gstretch_influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    gstretch_lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    gstretch_lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    gstretch_lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )
    gstretch_method: EnumProperty(
        name="Method",
        items=(("project", "Project", "Project vertices onto the stroke, "
                "using vertex normals and connected edges"),
                ("irregular", "Spread", "Distribute vertices along the full "
                "stroke, retaining relative distances between the vertices"),
                ("regular", "Spread evenly", "Distribute vertices at regular "
                "distances along the full stroke")),
        description="Method of distributing the vertices over the Grease "
                    "Pencil stroke",
        default='regular'
        )
    gstretch_use_guide: EnumProperty(
        name="Use guides",
        items=(("None", "None", "None"),
                ("Annotation", "Annotation", "Annotation"),
                ("GPencil", "GPencil", "GPencil")),
        default="None"
        )
    gstretch_guide: PointerProperty(
        name="GPencil object",
        description="Set GPencil object",
        type=bpy.types.Object
        )

    # relax properties
    relax_input: EnumProperty(name="Input",
        items=(("all", "Parallel (all)", "Also use non-selected "
                                           "parallel loops as input"),
                ("selected", "Selection", "Only use selected vertices as input")),
        description="Loops that are relaxed",
        default='selected'
        )
    relax_interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
                ("linear", "Linear", "Simple and fast linear algorithm")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    relax_iterations: EnumProperty(name="Iterations",
        items=(("1", "1", "One"),
                ("3", "3", "Three"),
                ("5", "5", "Five"),
                ("10", "10", "Ten"),
                ("25", "25", "Twenty-five")),
        description="Number of times the loop is relaxed",
        default="1"
        )
    relax_regular: BoolProperty(
        name="Regular",
        description="Distribute vertices at constant distances along the loop",
        default=True
        )

    # space properties
    space_influence: FloatProperty(
        name="Influence",
        description="Force of the tool",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
        )
    space_input: EnumProperty(
        name="Input",
        items=(("all", "Parallel (all)", "Also use non-selected "
                "parallel loops as input"),
            ("selected", "Selection", "Only use selected vertices as input")),
        description="Loops that are spaced",
        default='selected'
        )
    space_interpolation: EnumProperty(
        name="Interpolation",
        items=(("cubic", "Cubic", "Natural cubic spline, smooth results"),
            ("linear", "Linear", "Vertices are projected on existing edges")),
        description="Algorithm used for interpolation",
        default='cubic'
        )
    space_lock_x: BoolProperty(
        name="Lock X",
        description="Lock editing of the x-coordinate",
        default=False
        )
    space_lock_y: BoolProperty(
        name="Lock Y",
        description="Lock editing of the y-coordinate",
        default=False
        )
    space_lock_z: BoolProperty(
        name="Lock Z",
        description="Lock editing of the z-coordinate",
        default=False
        )

# draw function for integration in menus
def menu_func(self, context):
    self.layout.menu("VIEW3D_MT_edit_mesh_looptools")
    self.layout.separator()


# Add-ons Preferences Update Panel

# Define Panel classes for updating
panels = (
        VIEW3D_PT_tools_looptools,
        )


def update_panel(self, context):
    message = "Loop Tools: Updating Panel locations has failed"
    try:
        for panel in panels:
            if "bl_rna" in panel.__dict__:
                bpy.utils.unregister_class(panel)

        for panel in panels:
            panel.bl_category = getattr(preferences.get_preferences(context, __name__, LoopPreferences), 'category', 'Edit')
            bpy.utils.register_class(panel)

    except Exception as e:
        print("\n[{}]\n{}\n\nError:\n{}".format(__name__, message, e))
        pass


class LoopPreferences(PropertyGroup):
    # this must match the addon name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = __name__

    category: StringProperty(
            name="Tab Category",
            description="Choose a name for the category of the panel",
            default="Edit",
            update=update_panel
            )

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        col = row.column()
        col.label(text="Tab Category:")
        col.prop(self, "category", text="")


# define classes for registration
classes = (
    VIEW3D_MT_edit_mesh_looptools,
    VIEW3D_PT_tools_looptools,
    LoopToolSettings,
    Bridge,
    Circle,
    Curve,
    Flatten,
    GStretch,
    Relax,
    Space,
    LoopPreferences,
    RemoveAnnotation,
    RemoveGPencil,
)


# registering and menu integration
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.prepend(menu_func)
    bpy.types.WindowManager.looptools = PointerProperty(type=LoopToolSettings)
    update_panel(None, bpy.context)


# unregistering and removing menus
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_func)
    try:
        del bpy.types.WindowManager.looptools
    except Exception as e:
        print('unregister fail:\n', e)
        pass


if __name__ == "__main__":
    register()


def _loop_input_signature(obj, mesh, mode, borders):
    mirror_order = tuple(mod.name for mod in obj.modifiers
                         if mod.type == 'MIRROR' and mod.show_viewport)
    visible_selection = tuple(vertex.index for vertex in mesh.verts
                              if not vertex.hide and vertex.select)
    return (obj.name, mode, borders, mirror_order, visible_selection)

def _preference_links(operator):
    prefix = operator.name.partition(' ')[0].lower()
    return tuple((argument, f'{prefix}_{argument}') for argument in operator.as_keywords())


def _mesh_position_index(mesh, indices):
    from mathutils.kdtree import KDTree
    vertices = [mesh.verts[index] for index in indices]
    tree = KDTree(len(vertices))
    for rank, vertex in enumerate(vertices):
        tree.insert(vertex.co, rank)
    tree.balance()
    return tree, vertices

def _position_matches(index, position):
    tree, vertices = index
    nearby = sorted(rank for _, rank, _ in tree.find_range(position, 1.001e-6))
    return (vertices[rank].index for rank in nearby
            if (vertices[rank].co - position).length < 1e-6)


def _editing_coordinates(object, context):
    slot = context.scene.transform_orientation_slots[0]
    world = object.matrix_world.copy()
    if slot.custom_orientation:
        return slot.custom_orientation.matrix.to_4x4().inverted() @ world
    if slot.type == 'LOCAL':
        return mathutils.Matrix.Identity(4)
    if slot.type == 'VIEW':
        return context.region_data.view_matrix.copy() @ world
    return world

def _reflections(mesh):
    enabled = sum(1 << axis for axis, name in enumerate(('x','y','z'))
                  if getattr(mesh, f'use_mirror_{name}'))
    masks = (1, 2, 3, 5, 6, 7, 4)
    return [mathutils.Vector(tuple(-1 if bits & (1 << dim) else 1 for dim in range(3)))
            for bits in masks if bits & enabled == bits]
