# LoopTools Source Evidence

Compared upstream author field: Bart Crouch, Vladimir Spivak (cwolf3d)
Compared source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/mesh_looptools.py
Comparison commit: b42d68627734cb18af0e6f41537063984313a284
Comparison-source version: 4.7.7

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2011-2023 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

The bounded comparison with SmartModeling1.3.105 found 107 exactly matching nontrivial function ASTs in looptools/__init__.py. The complete files are not byte-identical or identical after line-ending normalization. AST matching includes identifiers and docstrings, excludes source positions, and requires at least30 AST nodes.

The original acquired archive/version and the origin of all other code have not been established. The comparison-source version is not a verified bundled-version claim. This notice preserves observed upstream declarations; it does not replace the full license terms, change existing code or headers, or establish complete attribution, license/source-offer compliance or sales clearance.
