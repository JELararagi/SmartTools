bl_info = {
    "name": "Vertex Copy",
    "author": "Smart Modeling",
    "version": (21, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Vertex Copy",
    "description": "High-precision vertex shape copy & paste (Exact / Mirror / Smart / Surface / Shape Key / Soft Wrap).",
    "category": "Mesh",
}

from . import translation as i18n
from . import core, extension, extension_plus, extension_lines


def register():
    i18n.register()
    core.register()
    extension.register()
    extension_plus.register()
    extension_lines.register()


def unregister():
    extension_lines.unregister()
    extension_plus.unregister()
    extension.unregister()
    core.unregister()
    i18n.unregister()



def _sms_pick_text(en, ja, context=None):
    try:
        return core._language.pick_text(en, ja, context)
    except Exception:
        try:
            lang = getattr(getattr(getattr(__import__('bpy'), 'context', None), 'preferences', None), 'view', None)
            code = str(getattr(lang, 'language', '') or '')
            return ja if code.startswith('ja') else en
        except Exception:
            return en


def draw_smart_modeling_settings(layout, context):
    """Draw the compact Vertex Copy settings inside Smart Modeling Suite."""
    scene = getattr(context, 'scene', None)
    if scene is None or not hasattr(scene, 'vscp_settings'):
        layout.label(text=_sms_pick_text('Vertex Copy settings are not loaded yet.', '頂点コピーの設定はまだ読み込まれていません。', context))
        return
    panel_cls = getattr(core, 'VSCP_PT_panel', None)
    draw_fn = None
    if panel_cls is not None:
        draw_fn = getattr(panel_cls, '_sms_original_draw_before_guard_51', None) or getattr(panel_cls, 'draw', None)
    if not callable(draw_fn):
        layout.label(text=_sms_pick_text('Vertex Copy panel UI is not available.', '頂点コピーのパネルUIを利用できません。', context), icon='ERROR')
        return
    # The unified Smart Modeling settings page must remain drawable even when
    # Vertex Copy's always-on runtime is disabled.  The always-on toggle controls
    # background preview/runtime behavior, not access to the tool settings UI.
    shim = type('_SMS_VERTEX_COPY_PANEL_HOST', (), {})()
    shim.layout = layout
    draw_fn(shim, context)
