import json
import math
import bpy
from ..bootstrap_common import class_is_owned_for_mutation as _vscpx_owned_class
from ..bootstrap_common import safe_unregister_class as _vscpx_exact_safe_unregister_class
import gpu
from gpu_extras.batch import batch_for_shader
from ..compat import get_uniform_color_shader
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from ..common import persistent_property_factory as _persistent_property

BoolProperty = _persistent_property(BoolProperty)
EnumProperty = _persistent_property(EnumProperty)
FloatProperty = _persistent_property(FloatProperty)
IntProperty = _persistent_property(IntProperty)
PointerProperty = _persistent_property(PointerProperty)
StringProperty = _persistent_property(StringProperty)
from bpy_extras.io_utils import ExportHelper, ImportHelper
from ..utils import default_user_filepath, ensure_parent_dir
from bpy_extras import view3d_utils
from mathutils import Vector

from . import core

_EXT_DRAW_HANDLER = None
_EXT_PREVIEW_CACHE = {}
_ORIG_COMPUTE_CANDIDATES = None
_ORIG_BUILD_MAPPING = None


def _add_ext_draw_handler():
    global _EXT_DRAW_HANDLER
    # This preview owns a SpaceView3D resource and therefore has no valid
    # registration target in Blender background mode.  Keep the persisted RNA
    # state intact; the first GUI session replays it through the same sync path.
    if bpy.app.background:
        return
    if _EXT_DRAW_HANDLER is not None:
        return
    try:
        _EXT_DRAW_HANDLER = bpy.types.SpaceView3D.draw_handler_add(_ext_draw_callback, (), 'WINDOW', 'POST_VIEW')
    except Exception:
        _EXT_DRAW_HANDLER = None


def _remove_ext_draw_handler():
    global _EXT_DRAW_HANDLER
    if _EXT_DRAW_HANDLER is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_EXT_DRAW_HANDLER, 'WINDOW')
    except Exception:
        pass
    _EXT_DRAW_HANDLER = None


def sync_ext_draw_handler(force_state=None):
    state = force_state
    if state is None:
        try:
            settings = _ext_settings(bpy.context)
            state = bool(getattr(settings, 'enable_advanced_preview', False))
        except Exception:
            state = False
    if state:
        _add_ext_draw_handler()
    else:
        _remove_ext_draw_handler()
    _safe_redraw()


def _update_advanced_preview_toggle(self, context):
    sync_ext_draw_handler(bool(getattr(self, 'enable_advanced_preview', False)))
    try:
        from .. import common as _persistent_settings
        _persistent_settings.save_persistent_settings(context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass


def _ext_settings(context=None):
    context = context or bpy.context
    scene = getattr(context, 'scene', None)
    if scene is None:
        return None
    return getattr(scene, 'vscpx_settings', None)


def _safe_redraw():
    try:
        core._tag_redraw_all_view3d()
    except Exception:
        pass


def _active_payload(context):
    try:
        return core._active_payload(context)
    except Exception:
        return None


def _resolve_mirror_axis(payload, obj, settings, ext):
    if not ext or not ext.use_auto_mirror_axis:
        return settings.mirror_axis
    center = Vector(payload.get('center_local', (0.0, 0.0, 0.0)))
    vals = {'X': abs(center.x), 'Y': abs(center.y), 'Z': abs(center.z)}
    axis = min(vals, key=vals.get)
    if ext.auto_mirror_axis_bias in vals:
        axis = ext.auto_mirror_axis_bias
    return axis


def _face_seed_faces(bm):
    faces = [f for f in bm.faces if f.select]
    if faces:
        return faces
    verts = [v for v in bm.verts if v.select]
    seed = []
    for v in verts:
        seed.extend(list(v.link_faces))
    if seed:
        return list({f.index: f for f in seed}.values())
    return list(bm.faces[:1])


def _faces_connected_by_rule(seed_faces, allow_link):
    if not seed_faces:
        return set()
    out = set()
    stack = list(seed_faces)
    while stack:
        f = stack.pop()
        if f.index in out:
            continue
        out.add(f.index)
        for e in f.edges:
            if not allow_link(e):
                continue
            for lf in e.link_faces:
                if lf.index not in out:
                    stack.append(lf)
    return out


def _uv_island_connected(face, edge, other, uv_layer):
    if uv_layer is None:
        return True
    shared = [v.index for v in edge.verts]
    if len(shared) != 2:
        return True
    def loops_for_face(f):
        loops = []
        for loop in f.loops:
            if loop.vert.index in shared:
                uv = loop[uv_layer].uv.copy()
                loops.append((loop.vert.index, (round(uv.x, 6), round(uv.y, 6))))
        return sorted(loops)
    return loops_for_face(face) == loops_for_face(other)


def _region_candidates(obj, bm, base_candidates, ext):
    if ext is None:
        return set(base_candidates)
    mode = ext.region_mode
    candidates = set(base_candidates)
    if mode == 'ALL':
        return candidates
    if mode == 'SELECTED':
        return candidates.intersection({v.index for v in bm.verts if v.select})
    if mode == 'MATERIAL':
        verts = set()
        for f in bm.faces:
            if f.material_index == ext.region_material_index:
                verts.update(v.index for v in f.verts)
        return candidates.intersection(verts)
    if mode in {'FACE_ISLAND', 'SEAM_ISLAND', 'UV_ISLAND'}:
        seed_faces = _face_seed_faces(bm)
        uv_layer = bm.loops.layers.uv.active if hasattr(bm.loops.layers, 'uv') else None
        if mode == 'FACE_ISLAND':
            allow = lambda e: True
        elif mode == 'SEAM_ISLAND':
            allow = lambda e: not e.seam
        else:
            def allow(e):
                if e.seam:
                    return False
                if len(e.link_faces) != 2:
                    return True
                return _uv_island_connected(e.link_faces[0], e, e.link_faces[1], uv_layer)
        face_ids = _faces_connected_by_rule(seed_faces, allow)
        verts = set()
        for fid in face_ids:
            verts.update(v.index for v in bm.faces[fid].verts)
        return candidates.intersection(verts)
    return candidates


def _patched_compute_candidate_indices(obj, bm, settings):
    global _ORIG_COMPUTE_CANDIDATES
    base = _ORIG_COMPUTE_CANDIDATES(obj, bm, settings)
    ext = _ext_settings()
    region = _region_candidates(obj, bm, set(base), ext)
    return sorted(region)


def _resolve_auto_mode(context, obj, payload, settings, ext):
    if ext is None or not ext.enable_auto_mode:
        return settings.paste_mode
    current = settings.paste_mode
    mirror_pref = current in {'MIRROR_EXACT', 'MIRROR_SMART'} or ext.force_mirror_auto
    exact_mode = 'MIRROR_EXACT' if mirror_pref else 'EXACT'
    smart_mode = 'MIRROR_SMART' if mirror_pref else 'SMART'
    bm = core._bm_from_edit_object(obj)
    ok, _reason = core._mesh_and_mapping_exact_possible(payload, bm, settings)
    if ok:
        return exact_mode
    if ext.auto_mode_fallback == 'SMART':
        return smart_mode
    return 'SURFACE_PROJECT'


def _patched_build_mapping_for_mode(context, obj, payload, settings):
    global _ORIG_BUILD_MAPPING
    ext = _ext_settings(context)
    prev_mode = settings.paste_mode
    prev_axis = settings.mirror_axis
    try:
        settings.mirror_axis = _resolve_mirror_axis(payload, obj, settings, ext)
        settings.paste_mode = _resolve_auto_mode(context, obj, payload, settings, ext)
        return _ORIG_BUILD_MAPPING(context, obj, payload, settings)
    finally:
        settings.paste_mode = prev_mode
        settings.mirror_axis = prev_axis


def _confidence_for_mapping(obj, mapping, payload, settings):
    if not mapping:
        return {}, []
    points = {}
    unmatched = []
    used_src = set()
    target_center = core._compute_target_center_from_mapping(obj.data, mapping)
    mode = settings.paste_mode
    ext = _ext_settings()
    max_d = max(1e-8, getattr(ext, 'confidence_distance_scale', 0.25))
    for tgt, src in mapping.items():
        if isinstance(src, dict) and 'index' in src:
            used_src.add(src['index'])
        if isinstance(tgt, int) and 0 <= tgt < len(obj.data.vertices):
            target = obj.data.vertices[tgt].co.copy()
            src_local = core._list_to_vec(src.get('projected_local', src['co_local']))
            src_rel = core._list_to_vec(src['co_rel'])
            predicted = target_center + src_rel if settings.smart_fit_to_target_center else src_local
            if mode in {'EXACT', 'MIRROR_EXACT'}:
                conf = 1.0
            else:
                dist = (target - predicted).length
                conf = max(0.0, 1.0 - min(1.0, dist / max_d))
            points[tgt] = conf
        elif isinstance(src, dict) and 'project_weights' in src:
            for idx, _w in src['project_weights']:
                points[idx] = max(points.get(idx, 0.0), 0.7)
    if payload:
        for item in payload.get('vertices', []):
            if item.get('index') not in used_src:
                pos = core._list_to_vec(item['co_local'])
                unmatched.append(obj.matrix_world @ pos)
    return points, unmatched


def _preview_cache_key(context, obj, payload, settings, ext):
    base = core._preview_signature(context, obj, payload, settings)
    return (
        base,
        getattr(ext, 'enable_advanced_preview', False),
        getattr(ext, 'preview_mode', 'CONFIDENCE'),
        getattr(ext, 'preview_line_mode', 'ALL'),
        getattr(ext, 'low_confidence_threshold', 0.35),
        getattr(ext, 'confidence_distance_scale', 0.25),
    )


def _build_ext_preview(context, obj, payload, settings, ext):
    key = _preview_cache_key(context, obj, payload, settings, ext)
    if key in _EXT_PREVIEW_CACHE:
        return _EXT_PREVIEW_CACHE[key]
    mapping, _mirror_mode, _projected_mode = core._build_mapping_for_mode(context, obj, payload, settings)
    conf_map, unmatched = _confidence_for_mapping(obj, mapping, payload, settings)
    good = []
    mid = []
    low = []
    lines_all = []
    lines_low = []
    landmark_lines = []
    thresh = ext.low_confidence_threshold
    for target_idx, src in mapping.items():
        target_indices = []
        pred = core._list_to_vec(src.get('projected_local', src['co_local']))
        pred_world = obj.matrix_world @ pred
        if isinstance(target_idx, int) and 0 <= target_idx < len(obj.data.vertices):
            target_indices = [target_idx]
        elif isinstance(src, dict) and 'project_weights' in src:
            target_indices = [idx for idx, _w in src['project_weights'] if 0 <= idx < len(obj.data.vertices)]
        for idx in target_indices:
            wco = obj.matrix_world @ obj.data.vertices[idx].co
            conf = conf_map.get(idx, 0.5)
            if conf >= 0.75:
                good.append(wco)
            elif conf >= thresh:
                mid.append(wco)
            else:
                low.append(wco)
                lines_low.extend([pred_world, wco])
            lines_all.extend([pred_world, wco])
        if ext.preview_line_mode == 'LANDMARKS' and settings.use_landmark_pairs and src.get('index') is not None:
            landmark_ids = {s for s, _t in core._parse_landmark_pairs(settings.landmark_pairs_text)}
            if src.get('index') in landmark_ids:
                for idx in target_indices:
                    landmark_lines.extend([pred_world, obj.matrix_world @ obj.data.vertices[idx].co])
    data = {
        'good': good,
        'mid': mid,
        'low': low,
        'unmatched': unmatched,
        'lines_all': lines_all,
        'lines_low': lines_low,
        'lines_landmark': landmark_lines,
    }
    _EXT_PREVIEW_CACHE[key] = data
    return data


def _draw_points(shader, coords, color, size):
    if not coords:
        return
    gpu.state.point_size_set(size)
    shader.bind()
    shader.uniform_float('color', color)
    batch = batch_for_shader(shader, 'POINTS', {'pos': coords})
    batch.draw(shader)


def _draw_lines(shader, coords, color, width):
    if not coords:
        return
    gpu.state.line_width_set(width)
    shader.bind()
    shader.uniform_float('color', color)
    batch = batch_for_shader(shader, 'LINES', {'pos': coords})
    batch.draw(shader)


def _ext_draw_callback():
    try:
        context = bpy.context
        ext = _ext_settings(context)
        if ext is None or not ext.enable_advanced_preview:
            return
        scene = context.scene
        settings = scene.vscp_settings
        obj = core._get_active_mesh(context)
        if obj is None or context.mode != 'EDIT_MESH':
            return
        payload = _active_payload(context)
        if not payload:
            return
        data = _build_ext_preview(context, obj, payload, settings, ext)
        shader = get_uniform_color_shader('3D')
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE')
        _draw_points(shader, data['good'], ext.preview_good_color, settings.preview_point_size + 1.0)
        _draw_points(shader, data['mid'], ext.preview_mid_color, settings.preview_point_size + 1.0)
        _draw_points(shader, data['low'], ext.preview_low_color, settings.preview_point_size + 1.0)
        if ext.show_unmatched_preview:
            _draw_points(shader, data['unmatched'], ext.preview_unmatched_color, settings.preview_point_size + 1.0)
        if ext.preview_line_mode == 'ALL':
            _draw_lines(shader, data['lines_all'], ext.preview_line_all_color, settings.preview_line_width)
        elif ext.preview_line_mode == 'LOW_CONF':
            _draw_lines(shader, data['lines_low'], ext.preview_line_low_color, settings.preview_line_width + 1.0)
        elif ext.preview_line_mode == 'LANDMARKS':
            _draw_lines(shader, data['lines_landmark'], ext.preview_line_landmark_color, settings.preview_line_width + 1.0)
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.blend_set('NONE')
    except Exception as exc:
        pass


class VSCPX_Settings(bpy.types.PropertyGroup):
    enable_auto_mode: BoolProperty(name='AUTO', description='If Exact is possible use Exact; otherwise auto-switch to Smart / Surface Project.', default=True)
    force_mirror_auto: BoolProperty(name='Prefer Mirror in AUTO', description='When AUTO decides, prefer mirror modes.', default=False)
    auto_mode_fallback: EnumProperty(name='AUTO Fallback', items=[('SMART', 'Smart', ''), ('SURFACE_PROJECT', 'Surface Project', '')], default='SMART', description='Mapping method used when AUTO cannot use an exact vertex match.')
    use_auto_mirror_axis: BoolProperty(name='Estimate Mirror Axis', description='Auto-estimate mirror axis from the source center.', default=False)
    auto_mirror_axis_bias: EnumProperty(name='Mirror Axis', items=[('X','X',''),('Y','Y',''),('Z','Z','')], default='X', description='Choose how Mirror Axis works. Pick the mode that best matches the current task and modeling workflow.')

    region_mode: EnumProperty(
        name='Region Filter',
        description='Further restrict candidate vertex region for Smart / Surface.',
        items=[
            ('ALL', 'All', 'Use the whole object.'),
            ('SELECTED', 'Selected Verts', 'Use only currently selected vertices as candidates.'),
            ('MATERIAL', 'Material', 'Limit candidates to vertices belonging to faces with the specified material index.'),
            ('FACE_ISLAND', 'Face Island', 'Limit candidates to face islands connected to the current selection.'),
            ('SEAM_ISLAND', 'Seam', 'Limit candidates to seam-separated islands.'),
            ('UV_ISLAND', 'UV Islands (Approx.)', 'Use only approximate UV islands based on UV boundaries and seams as candidates.'),
        ],
        default='ALL'
    )
    region_material_index: IntProperty(name='Material', default=0, min=0, description='Adjust Material. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    enable_advanced_preview: BoolProperty(name='Delta / Confidence Preview', description='Show the v12 color-coded preview only while you need comparison feedback. Disabled by default so this preview callback does not stay active all the time.', default=False, update=_update_advanced_preview_toggle)
    preview_mode: EnumProperty(name='Preview Mode', items=[('CONFIDENCE','Confidence',''),('DIFF','Delta Amount','')], default='CONFIDENCE', description='Choose how Preview Mode works. Pick the mode that best matches the current task and modeling workflow.')
    preview_line_mode: EnumProperty(name='Preview Lines', items=[('ALL','All Mappings',''),('LOW_CONF','Low Confidence Only',''),('LANDMARKS','Landmarks Only',''),('NONE','None','')], default='LOW_CONF', description='Choose which source-to-target mapping lines appear in the preview.')
    low_confidence_threshold: FloatProperty(name='Low Confidence Threshold', default=0.35, min=0.0, max=1.0, subtype='FACTOR', description='Adjust Low Confidence Threshold. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    confidence_distance_scale: FloatProperty(name='Confidence Distance Scale', description='Higher values make the low-confidence check more lenient.', default=0.25, min=1e-6, soft_max=100.0)
    show_unmatched_preview: BoolProperty(name='Show Unmatched', default=True, description='Highlight target vertices for which no source match was found.')
    preview_good_color: bpy.props.FloatVectorProperty(name='High Confidence Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.2, 1.0, 0.35, 0.9), description='Vector or color setting for High Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_mid_color: bpy.props.FloatVectorProperty(name='Medium Confidence Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.85, 0.2, 0.9), description='Vector or color setting for Medium Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_low_color: bpy.props.FloatVectorProperty(name='Low Confidence Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.25, 0.25, 0.95), description='Vector or color setting for Low Confidence Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_unmatched_color: bpy.props.FloatVectorProperty(name='Unmatched Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.7, 0.3, 1.0, 0.8), description='Vector or color setting for Unmatched Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_line_all_color: bpy.props.FloatVectorProperty(name='All Lines Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.2, 0.7, 1.0, 0.45), description='Vector or color setting for All Lines Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_line_low_color: bpy.props.FloatVectorProperty(name='Low Confidence Line Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.2, 0.2, 0.7), description='Vector or color setting for Low Confidence Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')
    preview_line_landmark_color: bpy.props.FloatVectorProperty(name='Landmark Line Color', subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.3, 1.0, 1.0, 0.85), description='Vector or color setting for Landmark Line Color. Use this to control color, direction, or other multi-value data used by the interface or tool.')

    workflow_step: EnumProperty(name='Workflow', items=[('COPY','1.Copy',''),('TARGET','2.Target',''),('VALIDATE','3.Validate',''),('PASTE','4.Paste','')], default='COPY', description='Choose how Workflow works. Pick the mode that best matches the current task and modeling workflow.')
    export_preset_basename: StringProperty(name='Export Name', default='vscp_presets', description='Text field for Export Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    pick_pixel_radius: IntProperty(name='Pick Radius (px)', default=18, min=4, max=128, description='Adjust Pick Radius (px). Larger or smaller values change the strength, amount, size, or precision used by the related tool.')
    report_action_filter: EnumProperty(name='Report Re-run Target', items=[('ALL','All',''),('OK','OKOnly',''),('NG','NGOnly',''),('LOW_CONF','Low Confidence Only','')], default='LOW_CONF', description='Filter which report targets are re-validated or pasted again.')


class VSCPX_OT_export_presets(bpy.types.Operator, ExportHelper):
    bl_idname = 'vscpx.export_presets'
    bl_label = 'Export Presets'
    bl_options = {'UNDO'}
    bl_description = 'Export custom presets to a JSON file.'
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'}, description='Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    def invoke(self, context, event):
        try:
            if not getattr(self, 'filepath', ''):
                self.filepath = default_user_filepath('vscp_presets.json', category='presets', create=True)
        except Exception:
            pass
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        s = context.scene.vscp_settings
        data = []
        for item in s.custom_presets:
            data.append({'name': item.name, 'payload_json': item.payload_json})
        ensure_parent_dir(self.filepath)
        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump({'presets': data}, f, ensure_ascii=False, indent=2)
        self.report({'INFO'}, f'Exported {len(data)} presets.')
        return {'FINISHED'}


class VSCPX_OT_import_presets(bpy.types.Operator, ImportHelper):
    bl_idname = 'vscpx.import_presets'
    bl_label = 'Import Presets'
    bl_options = {'UNDO'}
    bl_description = 'Import custom presets from a JSON file.'
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'}, description='Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    replace_same_name: BoolProperty(name='Overwrite Same Name', default=True, description='Enable or disable Overwrite Same Name. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')

    def invoke(self, context, event):
        try:
            if not getattr(self, 'filepath', ''):
                self.filepath = default_user_filepath('vscp_presets.json', category='presets', create=True)
        except Exception:
            pass
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        s = context.scene.vscp_settings
        with open(self.filepath, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        presets = payload.get('presets', [])
        imported = 0
        for entry in presets:
            name = str(entry.get('name', '')).strip()
            pj = str(entry.get('payload_json', '')).strip()
            if not name or not pj:
                continue
            found = None
            for item in s.custom_presets:
                if item.name == name:
                    found = item
                    break
            if found and self.replace_same_name:
                found.payload_json = pj
                imported += 1
            elif found:
                continue
            else:
                item = s.custom_presets.add()
                item.name = name
                item.payload_json = pj
                imported += 1
        self.report({'INFO'}, f'Imported {imported} presets.')
        return {'FINISHED'}


class VSCPX_OT_pick_landmark_modal(bpy.types.Operator):
    bl_idname = 'vscpx.pick_landmark_modal'
    bl_label = 'Register Landmarks in 3D View'
    bl_description = 'On first run pick the source vertex, on second run pick the target vertex in the 3D View to register a landmark pair.'
    bl_options = {'UNDO'}

    phase: StringProperty(default='SOURCE', description='Text field for Phase. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    source_index: IntProperty(default=-1, description='Adjust Source Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and core._get_active_mesh(context) is not None

    def _pick_nearest(self, context, obj):
        region = context.region
        rv3d = context.space_data.region_3d
        ext = _ext_settings(context)
        radius = ext.pick_pixel_radius if ext else 18
        mx = context.window_manager.windows[0].event_cursor_x if context.window_manager.windows else 0
        my = context.window_manager.windows[0].event_cursor_y if context.window_manager.windows else 0
        # region coords are supplied from modal event instead; fallback only
        return None

    def _pick_by_event(self, context, event, obj):
        region = context.region
        rv3d = context.space_data.region_3d
        best = None
        best_d = None
        ext = _ext_settings(context)
        limit = ext.pick_pixel_radius if ext else 18
        for v in obj.data.vertices:
            world = obj.matrix_world @ v.co
            co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
            if co2d is None:
                continue
            d = math.hypot(co2d.x - event.mouse_region_x, co2d.y - event.mouse_region_y)
            if d <= limit and (best is None or d < best_d):
                best = v.index
                best_d = d
        return best

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.report({'INFO'}, 'Landmark registration canceled.')
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            payload = _active_payload(context)
            if not payload:
                self.report({'ERROR'}, 'Active slot is empty.')
                return {'CANCELLED'}
            source_obj = bpy.data.objects.get(payload.get('source_object', ''))
            target_obj = core._get_active_mesh(context)
            if source_obj is None or target_obj is None:
                self.report({'ERROR'}, 'Source or target object could not be found.')
                return {'CANCELLED'}
            if self.phase == 'SOURCE':
                idx = self._pick_by_event(context, event, source_obj)
                if idx is None:
                    self.report({'WARNING'}, 'Could not pick the source vertex. Please click again.')
                    return {'RUNNING_MODAL'}
                self.source_index = idx
                self.phase = 'TARGET'
                self.report({'INFO'}, f'Picked source vertex {idx}. Next, click the target vertex.')
                return {'RUNNING_MODAL'}
            idx = self._pick_by_event(context, event, target_obj)
            if idx is None:
                self.report({'WARNING'}, 'Could not pick the target vertex. Please click again.')
                return {'RUNNING_MODAL'}
            s = context.scene.vscp_settings
            item = s.landmark_items.add()
            item.source_index = self.source_index
            item.target_index = idx
            core._sync_landmark_text_from_collection(s)
            self.report({'INFO'}, f'Landmark registered: {self.source_index} -> {idx}')
            _safe_redraw()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.phase = 'SOURCE'
        self.source_index = -1
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Click the source vertex.')
        return {'RUNNING_MODAL'}


class VSCPX_OT_validate_report_targets(bpy.types.Operator):
    bl_idname = 'vscpx.validate_report_targets'
    bl_label = 'Re-Validate Report Targets'
    bl_description = 'Filter targets by the previous report and re-validate only those targets.'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = _ext_settings(context)
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        names = _report_filtered_names(s, ext)
        if not names:
            self.report({'ERROR'}, 'No targets match the conditions.')
            return {'CANCELLED'}
        prev_mode = s.target_object_mode
        try:
            s.target_object_mode = 'SELECTED'
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            for name in names:
                obj = bpy.data.objects.get(name)
                if obj and obj.type == 'MESH':
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            result = core._run_nested_operator(self, bpy.ops.vscp.validate_targets)
        finally:
            s.target_object_mode = prev_mode
        return result


class VSCPX_OT_paste_report_targets(bpy.types.Operator):
    bl_idname = 'vscpx.paste_report_targets'
    bl_label = 'Target to Paste'
    bl_description = 'Filter targets by the previous report and paste only to those targets.'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = _ext_settings(context)
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        names = _report_filtered_names(s, ext)
        if not names:
            self.report({'ERROR'}, 'No targets match the conditions.')
            return {'CANCELLED'}
        prev_mode = s.target_object_mode
        try:
            s.target_object_mode = 'SELECTED'
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            for name in names:
                obj = bpy.data.objects.get(name)
                if obj and obj.type == 'MESH':
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            result = core._run_nested_operator(self, bpy.ops.vscp.paste_vertices)
        finally:
            s.target_object_mode = prev_mode
        return result


def _report_filtered_names(settings, ext):
    names = []
    mode = ext.report_action_filter if ext else 'ALL'
    thresh = ext.low_confidence_threshold if ext else 0.35
    for item in settings.last_run_reports:
        status = str(item.status)
        msg = str(item.message)
        low = ('Low Confidence' in msg) or ('Candidates' in msg and item.mapped_count > 0 and item.changed_count == 0)
        if mode == 'OK' and status != 'OK':
            continue
        if mode == 'NG' and status != 'NG':
            continue
        if mode == 'LOW_CONF' and not low:
            continue
        names.append(item.object_name)
    return names


class VSCPX_OT_apply_workflow_step(bpy.types.Operator):
    bl_idname = 'vscpx.apply_workflow_step'
    bl_label = 'Run Workflow'
    bl_description = 'Run the representative action for the currently selected workflow step.'
    bl_options = {'UNDO'}

    def _run_operator(self, operator, label):
        try:
            if not operator.poll():
                self.report({'WARNING'}, f'{label} is not available in the current mode or selection.')
                return {'CANCELLED'}
            return operator()
        except Exception as exc:
            self.report({'WARNING'}, f'{label} could not run: {exc}')
            return {'CANCELLED'}

    def execute(self, context):
        ext = _ext_settings(context)
        if ext is None:
            self.report({'WARNING'}, 'Vertex Copy workflow settings are not available.')
            return {'CANCELLED'}
        if ext.workflow_step == 'COPY':
            return self._run_operator(bpy.ops.vscp.copy_vertices, 'Copy Vertices')
        if ext.workflow_step == 'TARGET':
            self.report({'INFO'}, 'Adjust paste target, region filter, and AUTO mode settings.')
            return {'FINISHED'}
        if ext.workflow_step == 'VALIDATE':
            return self._run_operator(bpy.ops.vscp.validate_targets, 'Validate Targets')
        return self._run_operator(bpy.ops.vscp.paste_vertices, 'Paste Vertices')


class VSCPX_PT_panel(bpy.types.Panel):
    bl_label = 'Auxiliary Workflow'
    bl_description = 'Vertex Copy panel in the Smart Modeling workspace.'
    bl_idname = 'VSCPX_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return bool(
                feature_enabled(context, "enable_vertex_copy", True)
                and getattr(context, 'scene', None) is not None
                and hasattr(context.scene, 'vscp_settings')
                and hasattr(context.scene, 'vscpx_settings')
            )
        except Exception:
            return False

    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.vscp_settings
        ext = context.scene.vscpx_settings

        box = layout.box()
        box.label(text='Workflow Wizard')
        box.prop(ext, 'workflow_step', expand=True)
        box.operator('vscpx.apply_workflow_step', icon='PLAY')

        box = layout.box()
        box.label(text='AUTO / /')
        box.prop(ext, 'enable_auto_mode')
        row = box.row(align=True)
        row.prop(ext, 'force_mirror_auto')
        row.prop(ext, 'auto_mode_fallback')
        box.prop(ext, 'use_auto_mirror_axis')
        if ext.use_auto_mirror_axis:
            box.prop(ext, 'auto_mirror_axis_bias')
        box.prop(ext, 'region_mode')
        if ext.region_mode == 'MATERIAL':
            box.prop(ext, 'region_material_index')

        box = layout.box()
        box.label(text='3D View Landmarks')
        box.operator('vscpx.pick_landmark_modal', icon='RESTRICT_SELECT_OFF')
        box.prop(ext, 'pick_pixel_radius')

        box = layout.box()
        box.label(text='Delta / Confidence Preview')
        box.prop(ext, 'enable_advanced_preview')
        if ext.enable_advanced_preview:
            box.prop(ext, 'preview_mode')
            box.prop(ext, 'preview_line_mode')
            box.prop(ext, 'low_confidence_threshold')
            box.prop(ext, 'confidence_distance_scale')
            box.prop(ext, 'show_unmatched_preview')
            col = box.column(align=True)
            col.prop(ext, 'preview_good_color')
            col.prop(ext, 'preview_mid_color')
            col.prop(ext, 'preview_low_color')
            col.prop(ext, 'preview_unmatched_color')

        box = layout.box()
        box.label(text='JSON', translate=False)
        row = box.row(align=True)
        row.operator('vscpx.export_presets', icon='EXPORT')
        row.operator('vscpx.import_presets', icon='IMPORT')

        box = layout.box()
        box.label(text='Re-run from Report')
        box.prop(ext, 'report_action_filter')
        row = box.row(align=True)
        row.operator('vscpx.validate_report_targets', icon='CHECKMARK')
        row.operator('vscpx.paste_report_targets', icon='PASTEDOWN')


classes = (
    VSCPX_Settings,
    VSCPX_OT_export_presets,
    VSCPX_OT_import_presets,
    VSCPX_OT_pick_landmark_modal,
    VSCPX_OT_validate_report_targets,
    VSCPX_OT_paste_report_targets,
    VSCPX_OT_apply_workflow_step,
)

_VSCPX_PROPERTY_CLASSES = (VSCPX_Settings,)
_VSCPX_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _VSCPX_PROPERTY_CLASSES)


def _unregister_panel_by_idname(panel_idname):
    # The string ID is used only to locate this module's own class object. It is
    # never used to fetch or mutate a live class from bpy.types.
    cls = globals().get(str(panel_idname))
    if isinstance(cls, type) and _vscpx_owned_class(cls):
        _vscpx_exact_safe_unregister_class(cls)


def register():
    global _EXT_DRAW_HANDLER, _ORIG_COMPUTE_CANDIDATES, _ORIG_BUILD_MAPPING
    _unregister_panel_by_idname("VSCPX_PT_panel")
    for cls in classes:
        bpy.utils.register_class(cls)
    try:
        if hasattr(bpy.types.Scene, "vscpx_settings"):
            del bpy.types.Scene.vscpx_settings
    except Exception:
        pass
    bpy.types.Scene.vscpx_settings = PointerProperty(type=VSCPX_Settings, description='Stores settings for Vertex Copy Extension.')
    if _ORIG_COMPUTE_CANDIDATES is None:
        _ORIG_COMPUTE_CANDIDATES = core._compute_candidate_indices
        core._compute_candidate_indices = _patched_compute_candidate_indices
    if _ORIG_BUILD_MAPPING is None:
        _ORIG_BUILD_MAPPING = core._build_mapping_for_mode
        core._build_mapping_for_mode = _patched_build_mapping_for_mode
    sync_ext_draw_handler()

def unregister():
    global _EXT_DRAW_HANDLER
    _unregister_panel_by_idname("VSCPX_PT_panel")
    _remove_ext_draw_handler()
    for cls in reversed(_VSCPX_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    if hasattr(bpy.types.Scene, 'vscpx_settings'):
        del bpy.types.Scene.vscpx_settings
    for cls in reversed(_VSCPX_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

# --- Tooltip completion (Vertex Copy extension panel) ---
VSCPX_PT_panel.bl_description = 'Extended Vertex Copy workflow panel with reporting, staged actions, and safer transfer review.'
