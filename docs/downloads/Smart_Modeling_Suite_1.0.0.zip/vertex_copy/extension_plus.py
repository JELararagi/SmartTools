import json
import bpy
from ..bootstrap_common import class_is_owned_for_mutation as _vscpy_owned_class
from ..bootstrap_common import safe_unregister_class as _vscpy_exact_safe_unregister_class
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from ..common import persistent_property_factory as _persistent_property

BoolProperty = _persistent_property(BoolProperty)
EnumProperty = _persistent_property(EnumProperty)
FloatProperty = _persistent_property(FloatProperty)
IntProperty = _persistent_property(IntProperty)
PointerProperty = _persistent_property(PointerProperty)
StringProperty = _persistent_property(StringProperty)
from bpy_extras.io_utils import ExportHelper, ImportHelper
from ..utils import default_user_filepath, ensure_parent_dir

from . import core, extension


class VSCPY_Settings(bpy.types.PropertyGroup):
    report_export_mode: EnumProperty(
        name='Report Export Format',
        description='Export format for the previous report.',
        items=[
            ('JSON', 'JSON File', 'Export in JSON format.'),
            ('CSV', 'CSV File', 'Export as CSV.'),
        ],
        default='JSON',
    )
    report_filter_on_export: EnumProperty(
        name='Report Export Target',
        description='Choose which fields of the previous report to export.',
        items=[
            ('ALL', 'All Items', 'Export all items of the previous report.'),
            ('OK', 'OKOnly', 'Export only successful items.'),
            ('NG', 'NGOnly', 'Export only failed items.'),
            ('LOW_CONF', 'Low Confidence Only', 'Export only items marked as low confidence.'),
        ],
        default='ALL',
    )
    session_text_name: StringProperty(
        name='Text Name',
        description='Blender Text datablock name used for saving/loading sessions.',
        default='VSCP_Session',
    )
    include_clipboards_in_session: BoolProperty(
        name='Include clipboard in session',
        description='Include current clipboard slot contents when saving.',
        default=True,
    )
    include_reports_in_session: BoolProperty(
        name='Include report in session',
        description='Include the previous report when saving.',
        default=True,
    )
    sync_ext_settings_in_session: BoolProperty(
        name='Settings Save',
        description='Also save v12/v13 extension settings.',
        default=True,
    )
    cache_info_text: StringProperty(
        name='Cache Info',
        description='Approximate info for the current cache.',
        default='',
    )
    adaptive_force_smart: BoolProperty(
        name='Row Smart',
        description='When re-running Low/NG targets, temporarily bias toward Smart modes.',
        default=True,
    )
    adaptive_neighbors_multiplier: IntProperty(
        name='Neighbor Search Multiplier',
        description='Multiplier applied to Smart neighbor search count during re-run.',
        default=2,
        min=1,
        max=8,
    )
    adaptive_min_match_ratio: FloatProperty(
        name='Row Min',
        description='Minimum match ratio temporarily applied during adaptive re-run.',
        default=0.2,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    )
    adaptive_confidence_distance_scale: FloatProperty(
        name='Confidence/Distance Scale for Re-run',
        description='Distance scale to temporarily relax low-confidence judgement.',
        default=0.5,
        min=1e-6,
        soft_max=100.0,
    )
    adaptive_temp_report_filter: EnumProperty(
        name='Row Target',
        description='Report target set used for adaptive re-run.',
        items=[('LOW_CONF', 'Low Confidence Only', ''), ('NG', 'NGOnly', ''), ('OK', 'OKOnly', ''), ('ALL', 'All', '')],
        default='LOW_CONF',
    )


def _iter_filtered_reports(settings, ext, mode):
    for item in settings.last_run_reports:
        status = str(item.status)
        msg = str(item.message)
        low = ('Low Confidence' in msg) or ('Candidates' in msg and item.mapped_count > 0 and item.changed_count == 0)
        if mode == 'OK' and status != 'OK':
            continue
        if mode == 'NG' and status != 'NG':
            continue
        if mode == 'LOW_CONF' and not low:
            continue
        yield item


def _report_items_to_dicts(settings, ext, mode='ALL'):
    out = []
    for item in _iter_filtered_reports(settings, ext, mode):
        out.append({
            'object_name': item.object_name,
            'status': item.status,
            'changed_count': int(item.changed_count),
            'mapped_count': int(item.mapped_count),
            'normal_count': int(item.normal_count),
            'weight_count': int(item.weight_count),
            'uv_count': int(item.uv_count),
            'message': item.message,
        })
    return out


def _settings_to_simple_dict(prop_group, skip=frozenset()):
    data = {}
    if prop_group is None:
        return data
    for key in getattr(prop_group, 'bl_rna', {}).properties.keys():
        if key == 'rna_type' or key in skip:
            continue
        try:
            val = getattr(prop_group, key)
            if hasattr(val, 'to_list'):
                val = list(val)
            elif val.__class__.__name__ == 'bpy_prop_array':
                val = list(val)
            elif hasattr(val, 'keys') and callable(val.keys):
                continue
            data[key] = val
        except Exception:
            pass
    return data


def _apply_simple_dict(prop_group, data, skip=frozenset()):
    if prop_group is None:
        return
    for key, val in data.items():
        if key in skip or not hasattr(prop_group, key):
            continue
        try:
            setattr(prop_group, key, val)
        except Exception:
            pass


def _build_session_payload(context):
    s = context.scene.vscp_settings
    ext = getattr(context.scene, 'vscpx_settings', None)
    plus = getattr(context.scene, 'vscpy_settings', None)
    payload = {
        'version': 13,
        'addon': 'Vertex Shape Copy Paste Ultimate JP Advanced v13',
        'core_settings': core._settings_to_preset_payload(s),
        'active_slot_index': core._get_active_slot_index(context),
        'landmark_pairs_text': s.landmark_pairs_text,
        'custom_presets': [
            {'name': item.name, 'payload_json': item.payload_json}
            for item in s.custom_presets
        ],
    }
    if plus and plus.include_clipboards_in_session:
        payload['clipboards'] = core._build_clipboards(context)
    if plus and plus.include_reports_in_session:
        payload['reports'] = _report_items_to_dicts(s, ext, 'ALL')
        payload['last_run_summary'] = s.last_run_summary
    if plus and plus.sync_ext_settings_in_session:
        payload['ext_settings'] = _settings_to_simple_dict(ext)
        payload['plus_settings'] = _settings_to_simple_dict(plus, skip={'cache_info_text'})
    return payload


def _apply_session_payload(context, payload):
    s = context.scene.vscp_settings
    ext = getattr(context.scene, 'vscpx_settings', None)
    plus = getattr(context.scene, 'vscpy_settings', None)
    core._apply_preset_payload_to_settings(s, payload.get('core_settings', {}))
    if 'clipboards' in payload:
        core._save_clipboards(context, payload.get('clipboards', []))
    core._set_active_slot_index(context, int(payload.get('active_slot_index', 0)))
    if 'custom_presets' in payload:
        s.custom_presets.clear()
        for item in payload.get('custom_presets', []):
            cp = s.custom_presets.add()
            cp.name = str(item.get('name', 'Preset'))
            cp.payload_json = str(item.get('payload_json', '{}'))
    if 'reports' in payload:
        s.last_run_reports.clear()
        for item in payload.get('reports', []):
            rp = s.last_run_reports.add()
            rp.object_name = str(item.get('object_name', ''))
            rp.status = str(item.get('status', ''))
            rp.changed_count = int(item.get('changed_count', 0))
            rp.mapped_count = int(item.get('mapped_count', 0))
            rp.normal_count = int(item.get('normal_count', 0))
            rp.weight_count = int(item.get('weight_count', 0))
            rp.uv_count = int(item.get('uv_count', 0))
            rp.message = str(item.get('message', ''))
        s.last_run_summary = str(payload.get('last_run_summary', ''))
    if 'ext_settings' in payload:
        _apply_simple_dict(ext, payload.get('ext_settings', {}))
    if 'plus_settings' in payload:
        _apply_simple_dict(plus, payload.get('plus_settings', {}), skip={'cache_info_text'})
    try:
        core._sync_landmark_collection_from_text(s)
    except Exception:
        pass
    core._tag_redraw_all_view3d()


def _update_cache_info(context):
    plus = getattr(context.scene, 'vscpy_settings', None)
    if plus is None:
        return
    try:
        core_count = len(getattr(core, '_PREVIEW_CACHE', {}))
    except Exception:
        core_count = 0
    try:
        ext_count = len(getattr(extension, '_EXT_PREVIEW_CACHE', {}))
    except Exception:
        ext_count = 0
    plus.cache_info_text = f'Core: {core_count} / Ext: {ext_count}'


class VSCPY_OT_export_last_report(bpy.types.Operator, ExportHelper):
    bl_idname = 'vscpy.export_last_report'
    bl_label = 'Last Report'
    bl_description = 'Export the last validation/paste report.'
    bl_options = {'UNDO'}
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json;*.csv', options={'HIDDEN'}, description='Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    def invoke(self, context, event):
        try:
            plus = getattr(context.scene, 'vscpy_settings', None)
            mode = getattr(plus, 'report_export_mode', 'JSON') if plus else 'JSON'
            filename = 'vscp_last_report.csv' if mode == 'CSV' else 'vscp_last_report.json'
            if not getattr(self, 'filepath', ''):
                self.filepath = default_user_filepath(filename, category='reports', create=True)
        except Exception:
            pass
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = getattr(context.scene, 'vscpx_settings', None)
        plus = context.scene.vscpy_settings
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        mode = plus.report_filter_on_export
        rows = _report_items_to_dicts(s, ext, mode)
        if not rows:
            self.report({'ERROR'}, 'Nothing to export.')
            return {'CANCELLED'}
        if plus.report_export_mode == 'CSV' or self.filepath.lower().endswith('.csv'):
            lines = ['object_name,status,changed_count,mapped_count,normal_count,weight_count,uv_count,message']
            for r in rows:
                msg = str(r['message']).replace('"', '""')
                lines.append(f'"{r["object_name"]}","{r["status"]}",{r["changed_count"]},{r["mapped_count"]},{r["normal_count"]},{r["weight_count"]},{r["uv_count"]},"{msg}"')
            text = '\n'.join(lines)
        else:
            text = json.dumps({
                'summary': s.last_run_summary,
                'mode': mode,
                'items': rows,
            }, ensure_ascii=False, indent=2)
        ensure_parent_dir(self.filepath)
        with open(self.filepath, 'w', encoding='utf-8') as f:
            f.write(text)
        self.report({'INFO'}, f'Report exported: {len(rows)} items')
        return {'FINISHED'}


class VSCPY_OT_session_to_text(bpy.types.Operator):
    bl_idname = 'vscpy.session_to_text'
    bl_label = 'Save Session to Text'
    bl_description = 'Save current settings/slots/report into a Blender Text datablock.'
    bl_options = {'UNDO'}
    def execute(self, context):
        plus = context.scene.vscpy_settings
        payload = _build_session_payload(context)
        name = plus.session_text_name.strip() or 'VSCP_Session'
        text_block = bpy.data.texts.get(name)
        if text_block is None:
            text_block = bpy.data.texts.new(name)
        text_block.clear()
        text_block.write(json.dumps(payload, ensure_ascii=False, indent=2))
        _update_cache_info(context)
        self.report({'INFO'}, f'Save : {name}')
        return {'FINISHED'}


class VSCPY_OT_session_from_text(bpy.types.Operator):
    bl_idname = 'vscpy.session_from_text'
    bl_label = 'Restore Session from Text'
    bl_description = 'Restore settings/slots/reports from a Blender Text datablock.'
    bl_options = {'UNDO'}

    def execute(self, context):
        plus = context.scene.vscpy_settings
        name = plus.session_text_name.strip() or 'VSCP_Session'
        text_block = bpy.data.texts.get(name)
        if text_block is None:
            self.report({'ERROR'}, f'Text not found: {name}')
            return {'CANCELLED'}
        try:
            payload = json.loads(text_block.as_string())
        except Exception as e:
            self.report({'ERROR'}, f'JSON : {e}')
            return {'CANCELLED'}
        _apply_session_payload(context, payload)
        _update_cache_info(context)
        self.report({'INFO'}, f'Session restored: {name}')
        return {'FINISHED'}


class VSCPY_OT_export_session_file(bpy.types.Operator, ExportHelper):
    bl_idname = 'vscpy.export_session_file'
    bl_label = 'Save Session to JSON'
    bl_description = 'Save current settings/slots/report into an external JSON file.'
    bl_options = {'UNDO'}
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'}, description='Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    def invoke(self, context, event):
        try:
            if not getattr(self, 'filepath', ''):
                self.filepath = default_user_filepath('vscp_session.json', category='sessions', create=True)
        except Exception:
            pass
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        payload = _build_session_payload(context)
        ensure_parent_dir(self.filepath)
        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        self.report({'INFO'}, 'Session saved to JSON.')
        return {'FINISHED'}


class VSCPY_OT_import_session_file(bpy.types.Operator, ImportHelper):
    bl_idname = 'vscpy.import_session_file'
    bl_label = 'Load Session from JSON'
    bl_description = 'Load settings/slots/reports from an external JSON file.'
    bl_options = {'UNDO'}

    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'}, description='Text field for Filter Glob. Use it to enter a name, filter, note, identifier, or other text used by the tool.')

    def invoke(self, context, event):
        try:
            if not getattr(self, 'filepath', ''):
                self.filepath = default_user_filepath('vscp_session.json', category='sessions', create=True)
        except Exception:
            pass
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                payload = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, f'JSON : {e}')
            return {'CANCELLED'}
        _apply_session_payload(context, payload)
        _update_cache_info(context)
        self.report({'INFO'}, 'Session restored from JSON.')
        return {'FINISHED'}


class VSCPY_OT_clear_preview_caches(bpy.types.Operator):
    bl_idname = 'vscpy.clear_preview_caches'
    bl_label = 'Clear Preview Cache'
    bl_description = 'Clear preview cache (core/extension).'
    bl_options = {'UNDO'}

    def execute(self, context):
        try:
            getattr(core, '_PREVIEW_CACHE', {}).clear()
        except Exception:
            pass
        try:
            getattr(extension, '_EXT_PREVIEW_CACHE', {}).clear()
        except Exception:
            pass
        _update_cache_info(context)
        core._tag_redraw_all_view3d()
        self.report({'INFO'}, 'Preview cache cleared.')
        return {'FINISHED'}


class VSCPY_OT_refresh_cache_info(bpy.types.Operator):
    bl_idname = 'vscpy.refresh_cache_info'
    bl_label = 'Update Cache Info'
    bl_description = 'Refresh cache summary display.'
    bl_options = {'UNDO'}
    def execute(self, context):
        _update_cache_info(context)
        self.report({'INFO'}, context.scene.vscpy_settings.cache_info_text or 'Cache info updated.')
        return {'FINISHED'}




def _report_filtered_names_with_mode(settings, ext, mode='ALL'):
    names = []
    for item in settings.last_run_reports:
        status = str(item.status)
        msg = str(item.message)
        low = ('Low Confidence' in msg) or ('Candidates' in msg and item.mapped_count > 0 and item.changed_count == 0)
        if mode == 'OK' and status != 'OK':
            continue
        if mode == 'NG' and status != 'NG':
            continue
        if mode == 'LOW_CONF' and not low:
            continue
        names.append(item.object_name)
    return names


def _select_objects_by_names(context, names):
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    selected = []
    for name in names:
        obj = bpy.data.objects.get(name)
        if obj and obj.type == 'MESH':
            obj.select_set(True)
            selected.append(obj)
    if selected:
        context.view_layer.objects.active = selected[0]
    return selected


def _apply_adaptive_overrides(context):
    s = context.scene.vscp_settings
    ext = getattr(context.scene, 'vscpx_settings', None)
    plus = getattr(context.scene, 'vscpy_settings', None)
    state = {
        'paste_mode': s.paste_mode,
        'smart_search_neighbors': s.smart_search_neighbors,
        'smart_min_match_ratio': s.smart_min_match_ratio,
        'smart_min_match_count': s.smart_min_match_count,
        'report_action_filter': getattr(ext, 'report_action_filter', 'ALL') if ext else 'ALL',
        'confidence_distance_scale': getattr(ext, 'confidence_distance_scale', 0.25) if ext else 0.25,
    }
    if plus is None:
        return state
    if plus.adaptive_force_smart and s.paste_mode in {'EXACT', 'MIRROR_EXACT', 'AUTO'}:
        s.paste_mode = 'SMART'
    s.smart_search_neighbors = max(1, int(s.smart_search_neighbors * max(1, plus.adaptive_neighbors_multiplier)))
    s.smart_min_match_ratio = min(s.smart_min_match_ratio, plus.adaptive_min_match_ratio)
    s.smart_min_match_count = min(s.smart_min_match_count, 1)
    if ext is not None:
        ext.confidence_distance_scale = max(ext.confidence_distance_scale, plus.adaptive_confidence_distance_scale)
        ext.report_action_filter = plus.adaptive_temp_report_filter
    return state


def _restore_adaptive_overrides(context, state):
    s = context.scene.vscp_settings
    ext = getattr(context.scene, 'vscpx_settings', None)
    s.paste_mode = state.get('paste_mode', s.paste_mode)
    s.smart_search_neighbors = int(state.get('smart_search_neighbors', s.smart_search_neighbors))
    s.smart_min_match_ratio = float(state.get('smart_min_match_ratio', s.smart_min_match_ratio))
    s.smart_min_match_count = int(state.get('smart_min_match_count', s.smart_min_match_count))
    if ext is not None:
        ext.report_action_filter = state.get('report_action_filter', ext.report_action_filter)
        ext.confidence_distance_scale = float(state.get('confidence_distance_scale', ext.confidence_distance_scale))


class VSCPY_OT_select_report_targets(bpy.types.Operator):
    bl_idname = 'vscpy.select_report_targets'
    bl_label = 'Target Select'
    bl_description = 'Select objects that match the report filter.'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = getattr(context.scene, 'vscpx_settings', None)
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        names = _report_filtered_names_with_mode(s, ext, getattr(ext, 'report_action_filter', 'ALL') if ext else 'ALL')
        selected = _select_objects_by_names(context, names)
        if not selected:
            self.report({'ERROR'}, 'No mesh targets match the conditions.')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Selected {len(selected)} objects.')
        return {'FINISHED'}


class VSCPY_OT_adaptive_revalidate(bpy.types.Operator):
    bl_idname = 'vscpy.adaptive_revalidate'
    bl_label = 'Adaptive Re-Validation'
    bl_description = 'Temporarily adjust search settings and re-validate report targets (Low confidence / NG).'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = getattr(context.scene, 'vscpx_settings', None)
        plus = context.scene.vscpy_settings
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        names = _report_filtered_names_with_mode(s, ext, plus.adaptive_temp_report_filter)
        if not names:
            self.report({'ERROR'}, 'No targets for adaptive re-validation.')
            return {'CANCELLED'}
        prev_mode = s.target_object_mode
        state = _apply_adaptive_overrides(context)
        try:
            s.target_object_mode = 'SELECTED'
            selected = _select_objects_by_names(context, names)
            if not selected:
                self.report({'ERROR'}, 'Could not select target object.')
                return {'CANCELLED'}
            bpy.ops.object.mode_set(mode='EDIT')
            result = core._run_nested_operator(self, bpy.ops.vscp.validate_targets)
        finally:
            _restore_adaptive_overrides(context, state)
            s.target_object_mode = prev_mode
        if 'FINISHED' not in result:
            return result
        self.report({'INFO'}, f'Adaptive re-validation executed for {len(names)} items.')
        return {'FINISHED'}


class VSCPY_OT_adaptive_repaste(bpy.types.Operator):
    bl_idname = 'vscpy.adaptive_repaste'
    bl_label = 'Adaptive Re-Paste'
    bl_description = 'Temporarily adjust search settings and re-paste report targets (Low confidence / NG).'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        ext = getattr(context.scene, 'vscpx_settings', None)
        plus = context.scene.vscpy_settings
        if not s.last_run_reports:
            self.report({'ERROR'}, 'No previous report.')
            return {'CANCELLED'}
        names = _report_filtered_names_with_mode(s, ext, plus.adaptive_temp_report_filter)
        if not names:
            self.report({'ERROR'}, 'No targets for adaptive re-paste.')
            return {'CANCELLED'}
        prev_mode = s.target_object_mode
        state = _apply_adaptive_overrides(context)
        try:
            s.target_object_mode = 'SELECTED'
            selected = _select_objects_by_names(context, names)
            if not selected:
                self.report({'ERROR'}, 'Could not select target object.')
                return {'CANCELLED'}
            bpy.ops.object.mode_set(mode='EDIT')
            result = core._run_nested_operator(self, bpy.ops.vscp.paste_vertices)
        finally:
            _restore_adaptive_overrides(context, state)
            s.target_object_mode = prev_mode
        if 'FINISHED' not in result:
            return result
        self.report({'INFO'}, f'Adaptive re-paste executed for {len(names)} items.')
        return {'FINISHED'}


class VSCPY_OT_suggest_mode_from_targets(bpy.types.Operator):
    bl_idname = 'vscpy.suggest_mode_from_targets'
    bl_label = 'Suggest Simple Mode'
    bl_description = 'Quickly judge whether Exact is feasible for the current target and switch to the recommended mode.'
    bl_options = {'UNDO'}

    def execute(self, context):
        s = context.scene.vscp_settings
        payload = core._active_payload(context)
        if not payload:
            self.report({'ERROR'}, 'No copied data.')
            return {'CANCELLED'}
        source_total = int(payload.get('source_total_vert_count', 0))
        objs = []
        if s.target_object_mode == 'ACTIVE' and context.active_object and context.active_object.type == 'MESH':
            objs = [context.active_object]
        elif s.target_object_mode == 'SELECTED':
            objs = [o for o in context.selected_objects if o.type == 'MESH']
        elif s.target_object_mode == 'NAMED' and s.target_object_name:
            obj = bpy.data.objects.get(s.target_object_name)
            if obj and obj.type == 'MESH':
                objs = [obj]
        if not objs:
            self.report({'WARNING'}, 'No suitable targets found for Simple Mode suggestion.')
            return {'CANCELLED'}
        all_same = all(len(o.data.vertices) == source_total for o in objs)
        if all_same:
            s.paste_mode = 'EXACT'
            self.report({'INFO'}, 'Vertex counts match, so EXACT was set as the recommended mode.')
        else:
            s.paste_mode = 'SMART'
            self.report({'INFO'}, 'Vertex counts do not match, so SMART was set as the recommended mode.')
        return {'FINISHED'}
class VSCPY_PT_panel(bpy.types.Panel):
    bl_label = 'Auxiliary Report / Session'
    bl_description = 'Vertex Copy v14 panel in the Smart Modeling workspace.'
    bl_idname = 'VSCPY_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return bool(
                feature_enabled(context, "enable_vertex_copy", True)
                and getattr(context, 'scene', None) is not None
                and hasattr(context.scene, 'vscpy_settings')
            )
        except Exception:
            return False

    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        plus = context.scene.vscpy_settings

        box = layout.box()
        box.label(text='Export Report')
        box.prop(plus, 'report_export_mode', expand=True)
        box.prop(plus, 'report_filter_on_export')
        box.operator('vscpy.export_last_report', icon='EXPORT')

        box = layout.box()
        box.label(text='Save /')
        box.prop(plus, 'session_text_name')
        box.prop(plus, 'include_clipboards_in_session')
        box.prop(plus, 'include_reports_in_session')
        box.prop(plus, 'sync_ext_settings_in_session')
        row = box.row(align=True)
        row.operator('vscpy.session_to_text', icon='TEXT')
        row.operator('vscpy.session_from_text', icon='FILE_REFRESH')
        row = box.row(align=True)
        row.operator('vscpy.export_session_file', icon='EXPORT')
        row.operator('vscpy.import_session_file', icon='IMPORT')

        box = layout.box()
        box.label(text='Target')
        row = box.row(align=True)
        row.operator('vscpy.select_report_targets', icon='RESTRICT_SELECT_OFF')
        row.operator('vscpy.suggest_mode_from_targets', icon='LIGHT_SUN')

        box = layout.box()
        box.label(text='Adaptive Re-run for Low/NG')
        box.prop(plus, 'adaptive_temp_report_filter')
        box.prop(plus, 'adaptive_force_smart')
        box.prop(plus, 'adaptive_neighbors_multiplier')
        box.prop(plus, 'adaptive_min_match_ratio')
        box.prop(plus, 'adaptive_confidence_distance_scale')
        row = box.row(align=True)
        row.operator('vscpy.adaptive_revalidate', icon='VIEWZOOM')
        row.operator('vscpy.adaptive_repaste', icon='PASTEDOWN')

        box = layout.box()
        box.label(text='Cache Management')
        row = box.row(align=True)
        row.operator('vscpy.refresh_cache_info', icon='FILE_REFRESH')
        row.operator('vscpy.clear_preview_caches', icon='TRASH')
        if plus.cache_info_text:
            box.label(text=plus.cache_info_text)


classes = (
    VSCPY_Settings,
    VSCPY_OT_export_last_report,
    VSCPY_OT_select_report_targets,
    VSCPY_OT_adaptive_revalidate,
    VSCPY_OT_adaptive_repaste,
    VSCPY_OT_suggest_mode_from_targets,
    VSCPY_OT_session_to_text,
    VSCPY_OT_session_from_text,
    VSCPY_OT_export_session_file,
    VSCPY_OT_import_session_file,
    VSCPY_OT_clear_preview_caches,
    VSCPY_OT_refresh_cache_info,
)

_VSCPY_PROPERTY_CLASSES = (VSCPY_Settings,)
_VSCPY_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _VSCPY_PROPERTY_CLASSES)


def _unregister_panel_by_idname(panel_idname):
    # The string ID is used only to locate this module's own class object. It is
    # never used to fetch or mutate a live class from bpy.types.
    cls = globals().get(str(panel_idname))
    if isinstance(cls, type) and _vscpy_owned_class(cls):
        _vscpy_exact_safe_unregister_class(cls)


def register():
    _unregister_panel_by_idname("VSCPY_PT_panel")
    for cls in classes:
        bpy.utils.register_class(cls)
    try:
        if hasattr(bpy.types.Scene, "vscpy_settings"):
            del bpy.types.Scene.vscpy_settings
    except Exception:
        pass
    bpy.types.Scene.vscpy_settings = PointerProperty(type=VSCPY_Settings, description='Stores settings for Vertex Copy Extension Plus.')

def unregister():
    _unregister_panel_by_idname("VSCPY_PT_panel")
    for cls in reversed(_VSCPY_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    if hasattr(bpy.types.Scene, 'vscpy_settings'):
        del bpy.types.Scene.vscpy_settings
    for cls in reversed(_VSCPY_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

# --- Tooltip completion (Vertex Copy legacy extension panel) ---
VSCPY_PT_panel.bl_description = 'Legacy/plus Vertex Copy panel kept for compatibility and alternate workflows.'
