import bpy
import json
import sys

bl_info = {
    "name": "Merge Snap",
    "author": "Smart Modeling",
    "version": (1, 1, 0),
    "blender": (5, 0, 0),
    "location": "3D View > Smart Modeling / (Assign Shortcut manually)",
    "description": "Tool to toggle Auto Merge and Snap with safe backup/restore, modifier keys, cycling, indicators, and optional panel. ID: 'mesh.toggle_merge_snap'",
    "category": "Mesh",
}

# =============================================================================
# Translation Dictionary
# =============================================================================
translation_dict = {
    "ja_JP": {
        ("*", "Tool to toggle Auto Merge and Snap with safe backup/restore, modifier keys, cycling, indicators, and optional panel. ID: 'mesh.toggle_merge_snap'"):
            '自動マージとスナップを、元の状態を保ちながら切り替えるツールです。修飾キー、順送り、状態の表示に対応します。',
        ("*", "Merge Snap"): "マージスナップ",
        ("*", "Toggle Merge and Snap"): "マージとスナップを切替",
        ("*", "Toggle both Auto Merge and Snap. Shift: Auto Merge only. Alt: Snap only. Ctrl: Quick popup."):
            "自動マージとスナップを同時に切替。Shift: 自動マージのみ / Alt: スナップのみ / Ctrl: クイックポップアップ",
        ("*", "Auto Merge & Snap: {state}"): "自動マージ＆スナップ: {state}",
        ("*", "Auto Merge: {state}"): "自動マージ: {state}",
        ("*", "Snap: {state}"): "スナップ: {state}",
        ("*", "Restored previous settings."): "元の設定を復元しました。",
        ("*", "Snap Elements: {elements}"): "スナップ要素: {elements}",
        ("*", "Quick Snap Settings"): "クイックスナップ設定",
        ("*", "Apply"): "適用",
        ("*", "Cancel"): "キャンセル",

        # Preferences
        ("*", "Toggle Basis"): "トグル基準",
        ("*", "How to determine the combined ON/OFF state when toggling both."): "両方トグル時にON/OFFを判断する基準を選びます。",
        ("*", "Auto Merge"): "自動マージ",
        ("*", "Snap"): "スナップ",
        ("*", "Either ON"): "どちらかがON",
        ("*", "Both ON"): "両方ON",

        ("*", "Snap Enable Mode"): "スナップON時の要素設定",
        ("*", "How snap elements are set when enabling Snap via this tool."): "このツールでスナップをONにした時のスナップ要素の扱いです。",
        ("*", "Force Vertex"): "頂点に固定",
        ("*", "Keep Current"): "現在のまま",
        ("*", "Custom Set"): "ユーザー指定",

        ("*", "Custom Snap Elements"): "指定スナップ要素",
        ("*", "Used when Snap Enable Mode is Custom Set."): "「ユーザー指定」の時に使用されます。",

        ("*", "Repeat Action When Already ON"): "ON時の再実行動作",
        ("*", "What happens when the main toggle is pressed while already ON (no modifiers)."): "メインのトグルが既にONの状態で押された時（修飾キーなし）の動作です。",
        ("*", "Toggle OFF"): 'オフへ戻す',
        ("*", "Cycle Snap Elements"): "スナップ要素サイクル",

        ("*", "Enable Cycling"): "サイクルを有効化",
        ("*", "Cycle Order"): "サイクル順",
        ("*", "Edit the order used for cycling snap elements."): "スナップ要素サイクルの順番を編集します。",

        ("*", "Show Header Indicator"): "ヘッダーに状態表示",
        ("*", "Show Status Bar Indicator"): "ステータスバーに状態表示",
        ("*", "Off"): "OFF",
        ("*", "Temporary (reports)"): "一時表示（レポート）",
        ("*", "Always"): "常時表示",

        ("*", "Enable N-Panel"): "Nパネルを有効化",
        ("*", "Show a minimal panel in the 3D View N-Panel."): "3DビューNパネルに最小限のパネルを表示します。",
        ("*", "N-Panel Category"): "Nパネルタブ名",
        ("*", "The tab/category name in the N-Panel."): "Nパネル上のタブ名です。",

        ("*", "Debug Logging"): "デバッグログ",
        ("*", "Print debug information to the system console."): "システムコンソールにデバッグ情報を出力します。",

        # Panel
        ("*", "Status"): "状態",
        ("*", "Auto Merge"): "自動マージ",
        ("*", "Snap"): "スナップ",
        ("*", "Toggle Both"): "両方切替",
        ("*", "Toggle Auto Merge Only"): "自動マージのみ切替",
        ("*", "Toggle Snap Only"): "スナップのみ切替",
        ("*", "Cycle Snap"): "スナップサイクル",
        ("*", "Quick Popup"): "クイックポップアップ",
        ("*", "Detailed Settings"): "詳細設定",
        ("*", "The dedicated N-panel can stay hidden if you prefer the compact hub button only."): "コンパクトなハブのボタンだけで使いたい場合は、専用Nパネルを非表示のままでも問題ありません。",
        ("*", "Changing the tab name updates the optional panel category."): "タブ名を変更すると、任意表示のパネルカテゴリも更新されます。",
    }
}


translation_dict["ja_JP"].update({
    ("*", "Add the current snap-element state to the custom cycling order."): "現在のスナップ要素状態を、カスタムのサイクル順へ追加します。",
    ("*", "Remove the selected item from the custom snap cycling order."): "カスタムのスナップ要素サイクル順から、選択中の項目を削除します。",
    ("*", "Move the selected snap cycle item up or down in the custom order."): "選択中のスナップサイクル項目を、カスタム順序内で上下に移動します。",
    ("*", "Toggle both Auto Merge and Snap. Shift toggles Auto Merge only, Alt toggles Snap only, and Ctrl opens the quick popup."): "自動マージとスナップを同時に切り替えます。Shiftで自動マージのみ、Altでスナップのみ、Ctrlでクイックポップアップを開きます。",
    ("*", "Cycle through the configured snap element combinations without changing Auto Merge."): "自動マージを変えずに、設定済みのスナップ要素組み合わせを順番に切り替えます。",
    ("*", "Open a compact popup for quickly editing snap element toggles and applying them immediately."): "スナップ要素を素早く編集して即適用できるコンパクトなポップアップを開きます。",
    ("*", "Toggle only Auto Merge while leaving the current snap state untouched."): "現在のスナップ状態を維持したまま、自動マージだけを切り替えます。",
    ("*", "Toggle only Snap while leaving the current Auto Merge state untouched."): "現在の自動マージ状態を維持したまま、スナップだけを切り替えます。",
})


# =============================================================================
# Helpers
# =============================================================================
def _t(msg: str) -> str:
    """Translate a message string."""
    try:
        return bpy.app.translations.pgettext(msg)
    except Exception:
        return msg


def _smart_tools_window_active(context) -> bool:
    """Return True when the draw/poll request comes from the Smart Tools Properties host."""
    try:
        suite_package = str(__package__ or '').rsplit('.', 1)[0]
        pseudo_properties = sys.modules.get(suite_package + '.pseudo_properties')
        checker = getattr(pseudo_properties, "_is_smart_tools_context", None)
        if callable(checker):
            return bool(checker(context))
    except Exception:
        pass
    return False


def _update_n_panel_category(self, context):
    """Legacy compatibility stub.

    The old optional N-panel has been retired inside Smart Modeling.
    Detailed controls are now hosted by the Smart Modeling N-panel proxy system,
    so there is no category re-registration work left to do here.
    """
    return None


class _TAMS_NullOperatorProxy:
    def __setattr__(self, name, value):
        return None


_TAMS_NULL_OPERATOR_PROXY = _TAMS_NullOperatorProxy()


def _tams_operator_available(op_id: str) -> bool:
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return False
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    fn = getattr(group, tail, None) if group is not None else None
    return callable(fn)


def _tams_layout_operator_if_registered(layout, op_id: str, *, text='', icon='NONE'):
    if _tams_operator_available(op_id):
        return layout.operator(op_id, text=text, icon=icon)
    row = layout.row(align=True)
    row.enabled = False
    row.label(text=str(text or op_id), icon=str(icon or 'NONE'))
    return _TAMS_NULL_OPERATOR_PROXY



def _tams_is_native_registration_active() -> bool:
    try:
        return bool(bpy.app.driver_namespace.get('SMART_MODELING_SUITE_REGISTERING_NATIVE_TOOL', False))
    except Exception:
        return False


def _tams_rna_data_is_current(data) -> bool:
    if data is None:
        return False
    try:
        cls = type(data)
        cls_name = str(getattr(cls, '__name__', '') or '')
    except Exception:
        return False
    if not cls_name:
        return False
    try:
        registered = getattr(bpy.types, cls_name, None)
    except Exception:
        registered = None
    if registered is cls:
        return True
    try:
        module_name = str(getattr(cls, '__module__', '') or '')
    except Exception:
        module_name = ''
    return module_name in {'bpy.types', '_bpy_types'} and registered is not None


def _tams_context_is_usable(context=None) -> bool:
    if _tams_is_native_registration_active():
        return False
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None)
        scene = getattr(ctx, 'scene', None)
        return _tams_rna_data_is_current(wm) and _tams_rna_data_is_current(scene)
    except Exception:
        return False


def _get_prefs():
    """Return the Merge Snap settings stored on the current scene."""
    if _tams_is_native_registration_active():
        return None
    try:
        return getattr(bpy.context.scene, "tams_prefs", None)
    except Exception:
        return None


def _tams_feature_enabled(context, property_name: str, default: bool = True) -> bool:
    """Read the suite feature gate without importing modules from a UI callback."""
    try:
        suite_package = str(__package__ or '').rsplit('.', 1)[0]
        utils_module = sys.modules.get(suite_package + '.utils')
        feature_enabled = getattr(utils_module, 'feature_enabled', None)
        if callable(feature_enabled):
            return bool(feature_enabled(context, property_name, default))
    except Exception:
        pass
    return bool(default)


def _dbg(msg: str):
    prefs = None
    try:
        prefs = _get_prefs()
    except Exception:
        prefs = None
    if prefs and getattr(prefs, "debug_logging", False):
        print(f"[toggle_auto_merge_snap] {msg}")


def _safe_prop(ts, prop_id: str):
    return hasattr(ts, prop_id)


def _serialize_value(val):
    # Sets / enum flags
    if isinstance(val, set):
        return list(val)
    # Vectors / arrays
    try:
        # bpy_prop_array supports sequence protocol
        if hasattr(val, "__len__") and not isinstance(val, (str, bytes, dict, list, tuple, set)):
            return list(val)
    except Exception:
        pass
    # Basic JSON types are fine
    return val


def _is_enum_flag(ts, prop_id: str) -> bool:
    try:
        prop = ts.bl_rna.properties.get(prop_id)
        if prop and getattr(prop, "type", None) == 'ENUM':
            return bool(getattr(prop, "is_enum_flag", False))
    except Exception:
        pass
    return False


def _apply_value(ts, prop_id: str, val):
    if not _safe_prop(ts, prop_id):
        return
    try:
        if _is_enum_flag(ts, prop_id) and isinstance(val, (list, tuple)):
            setattr(ts, prop_id, set(val))
        else:
            setattr(ts, prop_id, val)
    except Exception as e:
        _dbg(f"Failed to apply {prop_id}={val!r}: {e}")


def _collect_props(ts, include_prefixes=(), include_exact=()):
    props = []
    try:
        for p in ts.bl_rna.properties:
            pid = p.identifier
            if pid == "rna_type":
                continue
            if pid in include_exact or any(pid.startswith(pref) for pref in include_prefixes):
                # Skip pointers/collections
                if getattr(p, "type", None) in {"POINTER", "COLLECTION"}:
                    continue
                props.append(pid)
    except Exception as e:
        _dbg(f"_collect_props error: {e}")
    return props


def _backup_toolsettings(ts, prop_ids):
    data = {}
    for pid in prop_ids:
        if not _safe_prop(ts, pid):
            continue
        try:
            data[pid] = _serialize_value(getattr(ts, pid))
        except Exception as e:
            _dbg(f"Backup read fail {pid}: {e}")
    return data


def _restore_toolsettings(ts, data: dict):
    for pid, val in data.items():
        _apply_value(ts, pid, val)


def _snap_prop_ids(ts):
    # Everything snap-related: use_snap, use_snap_*, snap_*
    return _collect_props(
        ts,
        include_prefixes=("use_snap", "snap_"),
        include_exact=("use_snap",),
    )


def _automerge_prop_ids(ts):
    # Auto Merge related: use_mesh_automerge, mesh_automerge_*
    return _collect_props(
        ts,
        include_prefixes=("mesh_automerge",),
        include_exact=("use_mesh_automerge",),
    )


def _format_elements(elems_set):
    try:
        return ",".join(sorted(list(elems_set)))
    except Exception:
        return str(elems_set)


def _cycle_next(elements_order, current_set):
    """Return next element-set from order based on current."""
    if not elements_order:
        return None
    # Find match by single element
    current_single = None
    if isinstance(current_set, set) and len(current_set) == 1:
        current_single = next(iter(current_set))
    if current_single and current_single in elements_order:
        idx = elements_order.index(current_single)
        return {elements_order[(idx + 1) % len(elements_order)]}
    # Otherwise start at first
    return {elements_order[0]}


# =============================================================================
# Dynamic Enum Items (version-safe)
# =============================================================================
# Blender only borrows the strings a dynamic enum callback returns, so every
# returned list stays referenced here (see bpy.props.EnumProperty).  Without
# this the item names can be freed and the popup shows broken text.
_TAMS_ENUM_ITEMS_HELD = {}


def _tams_hold_enum_items(kind, items):
    key = (kind, tuple(items))
    held = _TAMS_ENUM_ITEMS_HELD.get(key)
    if held is None:
        held = list(items)
        _TAMS_ENUM_ITEMS_HELD[key] = held
    return held


def _tams_tool_settings_enum_items(prop_name):
    # Item names are translated here with the source property's context so the
    # popup shows the same Japanese names as Blender's own snapping menu.
    items = []
    try:
        ts = bpy.context.scene.tool_settings
        prop = ts.bl_rna.properties.get(prop_name)
        if prop:
            ctxt = str(getattr(prop, "translation_context", "") or "*")
            for it in prop.enum_items:
                try:
                    name = bpy.app.translations.pgettext_iface(it.name, ctxt)
                except Exception:
                    name = it.name
                items.append((it.identifier, str(name or it.name), it.description))
    except Exception:
        pass
    return items


def _snap_elements_items(self, context):
    items = _tams_tool_settings_enum_items("snap_elements")
    if not items:
        # Fallback minimal set
        items = [
            ("VERTEX", "Vertex", ""),
            ("EDGE", "Edge", ""),
            ("FACE", "Face", ""),
            ("INCREMENT", "Increment", ""),
        ]
    return _tams_hold_enum_items("snap_elements", items)




# Static snap elements list (used for ENUM_FLAG properties: Blender requires static items
# when default is a set of identifiers).
_SNAP_ELEMENTS_ITEMS_STATIC = [
    ("VERTEX", "Vertex", ""),
    ("EDGE", "Edge", ""),
    ("FACE", "Face", ""),
    ("INCREMENT", "Increment", ""),
]
def _snap_target_items(self, context):
    items = _tams_tool_settings_enum_items("snap_target")
    if not items:
        items = [
            ("CLOSEST", "Closest", ""),
            ("CENTER", "Center", ""),
            ("MEDIAN", "Median", ""),
            ("ACTIVE", "Active", ""),
        ]
    return _tams_hold_enum_items("snap_target", items)


# =============================================================================
# Scene State
# =============================================================================
class TAMS_CycleItem(bpy.types.PropertyGroup):
    element: bpy.props.EnumProperty(name="Element", items=_SNAP_ELEMENTS_ITEMS_STATIC, default="VERTEX", description="Snap element stored in this cycle slot. The cycle operator will switch to this element when the slot becomes active.")


class TAMS_State(bpy.types.PropertyGroup):
    snap_managed: bpy.props.BoolProperty(default=False, description='Enable or disable Snap Managed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    automerge_managed: bpy.props.BoolProperty(default=False, description='Enable or disable Automerge Managed. Turn this on to use the related behavior, and turn it off when you want a simpler or safer workflow.')
    snap_backup_json: bpy.props.StringProperty(default="", description='Text field for Snap Backup Json. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    automerge_backup_json: bpy.props.StringProperty(default="", description='Text field for Automerge Backup Json. Use it to enter a name, filter, note, identifier, or other text used by the tool.')


# =============================================================================
# Preferences
# =============================================================================


class TAMS_Prefs(bpy.types.PropertyGroup):


    toggle_basis: bpy.props.EnumProperty(
        name="Toggle Basis",
        description="Choose which state is treated as the main reference when the tool toggles Auto Merge and Snap together.",
        items=[
            ("AUTO_MERGE", "Auto Merge", ""),
            ("SNAP", "Snap", ""),
            ("EITHER_ON", "Either ON", ""),
            ("BOTH_ON", "Both ON", ""),
        ],
        default="AUTO_MERGE",
    )

    snap_enable_mode: bpy.props.EnumProperty(
        name="Snap Enable Mode",
        description="Choose which snap elements should become active when this tool turns snapping on.",
        items=[
            ("FORCE_VERTEX", "Force Vertex", ""),
            ("KEEP_CURRENT", "Keep Current", ""),
            ("CUSTOM_SET", "Custom Set", ""),
        ],
        default="FORCE_VERTEX",
    )

    custom_snap_elements: bpy.props.EnumProperty(
        name="Custom Snap Elements",
        description="Snap elements that will be enabled when Snap Enable Mode is set to Custom Set.",
        items=_SNAP_ELEMENTS_ITEMS_STATIC,
        options={"ENUM_FLAG"},
        default={"VERTEX"},
    )
    repeat_action_when_on: bpy.props.EnumProperty(
        name="Repeat Action When Already ON",
        description="Choose what the main toggle should do if the managed state is already on and you press it again without modifier keys.",
        items=[
            ("TOGGLE_OFF", "Toggle OFF", ""),
            ("CYCLE", "Cycle Snap Elements", ""),
        ],
        default="TOGGLE_OFF",
    )

    enable_cycling: bpy.props.BoolProperty(
        name="Enable Cycling",
        description="Enable or disable the custom snap-element cycle list. When enabled, the cycle operator follows the order shown below.",
        default=True,
    )

    cycle_order: bpy.props.CollectionProperty(type=TAMS_CycleItem, description='Collection for Cycle Order. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')
    cycle_order_index: bpy.props.IntProperty(default=0, description='Adjust Cycle Order Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.')

    show_header_indicator: bpy.props.BoolProperty(
        name="Show Header Indicator",
        description="Show a small status hint in supported headers so you can see the managed Auto Merge / Snap state at a glance.",
        default=False,
    )

    status_bar_indicator: bpy.props.EnumProperty(
        name="Show Status Bar Indicator",
        description="Choose when the status bar indicator should be visible: never, only after reports, or always.",
        items=[
            ("OFF", "Off", ""),
            ("TEMP", "Temporary (reports)", ""),
            ("ALWAYS", "Always", ""),
        ],
        default="TEMP",
    )

    enable_n_panel: bpy.props.BoolProperty(
        name="Enable N-panel",
        description="Show a compact helper panel for this tool in the 3D View N-panel. Useful if you want mouse-accessible controls instead of relying only on shortcuts.",
        default=False,
    )

    debug_logging: bpy.props.BoolProperty(
        name="Debug Logging",
        description="Print extra diagnostic information to Blender's system console. Enable this only when you are troubleshooting the tool.",
        default=False,
    )

class TAMS_UL_cycle_order(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # item is TAMS_CycleItem
        row = layout.row(align=True)
        row.prop(item, "element", text="")


class MESH_OT_tams_cycle_add(bpy.types.Operator):
    bl_idname = "mesh.tams_cycle_add"

    bl_label = "Add Cycle Item"
    bl_description = "Add the current snap-element state to the custom cycling order."
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    def execute(self, context):
        prefs = _get_prefs()
        if not prefs:
            return {'CANCELLED'}
        it = prefs.cycle_order.add()
        current = context.scene.tool_settings.snap_elements
        if len(current) == 1:
            element = next(iter(current))
            if element in {item[0] for item in _SNAP_ELEMENTS_ITEMS_STATIC}:
                it.element = element
        prefs.cycle_order_index = max(0, len(prefs.cycle_order) - 1)
        return {'FINISHED'}


class MESH_OT_tams_cycle_remove(bpy.types.Operator):
    bl_idname = "mesh.tams_cycle_remove"

    bl_label = "Remove Cycle Item"
    bl_description = "Remove the selected item from the custom snap cycling order."
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    def execute(self, context):
        prefs = _get_prefs()
        if not prefs:
            return {'CANCELLED'}
        idx = prefs.cycle_order_index
        if 0 <= idx < len(prefs.cycle_order):
            prefs.cycle_order.remove(idx)
            prefs.cycle_order_index = min(idx, max(0, len(prefs.cycle_order) - 1))
        return {'FINISHED'}


class MESH_OT_tams_cycle_move(bpy.types.Operator):
    bl_idname = "mesh.tams_cycle_move"

    bl_label = "Move Cycle Item"
    bl_description = "Move the selected snap cycle item up or down in the custom order."
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    direction: bpy.props.EnumProperty(items=[('UP', 'UP', ''), ('DOWN', 'DOWN', '')], default='UP', description="Move the selected cycle item up or down inside the custom snap cycle order.")

    def execute(self, context):
        prefs = _get_prefs()
        if not prefs:
            return {'CANCELLED'}
        idx = prefs.cycle_order_index
        if not (0 <= idx < len(prefs.cycle_order)):
            return {'CANCELLED'}
        new_idx = idx - 1 if self.direction == 'UP' else idx + 1
        if not (0 <= new_idx < len(prefs.cycle_order)):
            return {'CANCELLED'}
        prefs.cycle_order.move(idx, new_idx)
        prefs.cycle_order_index = new_idx
        return {'FINISHED'}


# Make cycle item element selectable via dynamic enum in UI by overriding RNA draw with a search menu style.
# We keep as StringProperty to avoid hard-coding enum identifiers across versions.


# =============================================================================
# Core Actions
# =============================================================================
def _ensure_cycle_defaults(prefs):
    """Create the default snap cycle only during real UI/operator use.

    Do not touch nested WindowManager RNA while a native tool is being
    registered by the suite preload timer. During reinstall/shutdown Blender may
    still be removing or refining classes; deferring this collection setup avoids
    C/RNA access violations.
    """
    if prefs is None or not _tams_context_is_usable():
        return
    try:
        order = getattr(prefs, "cycle_order", None)
    except Exception:
        return
    if order is None:
        return
    try:
        if len(order) != 0:
            return
    except Exception:
        return

    candidates = ["VERTEX", "EDGE", "FACE", "INCREMENT"]
    try:
        ts = getattr(getattr(bpy.context, "scene", None), "tool_settings", None)
        prop = getattr(getattr(ts, "bl_rna", None), "properties", {}).get("snap_elements") if ts is not None else None
        if prop:
            supported = [e.identifier for e in prop.enum_items]
            candidates = [c for c in candidates if c in supported] or supported[:4] or candidates
    except Exception:
        pass

    for el in candidates:
        try:
            it = order.add()
        except Exception:
            break
        try:
            it.element = el
        except Exception:
            try:
                it.element = candidates[0]
            except Exception:
                pass

    try:
        prefs.cycle_order_index = 0
    except Exception:
        pass

def _get_state(scene):
    if not hasattr(scene, "tams_state") or scene.tams_state is None:
        return None
    return scene.tams_state


def _get_order_list(prefs, ts):
    _ensure_cycle_defaults(prefs)
    order = []
    if prefs and prefs.enable_cycling:
        for it in prefs.cycle_order:
            if it.element:
                order.append(it.element)
    # Filter to those supported by this Blender build
    supported = set()
    try:
        prop = ts.bl_rna.properties.get("snap_elements")
        if prop:
            supported = {e.identifier for e in prop.enum_items}
    except Exception:
        supported = set(order) if order else set()
    if supported:
        order = [e for e in order if e in supported]
    return order


def _enable_snap(context, prefs, state):
    ts = context.scene.tool_settings
    if not state.snap_managed:
        snap_ids = _snap_prop_ids(ts)
        data = _backup_toolsettings(ts, snap_ids)
        state.snap_backup_json = json.dumps(data, ensure_ascii=False)
        state.snap_managed = True
        _dbg(f"Snap backup stored ({len(data)} props).")

    # Enable snap
    ts.use_snap = True

    # Set snap elements based on preference
    try:
        if prefs.snap_enable_mode == "FORCE_VERTEX":
            ts.snap_elements = {'VERTEX'}
        elif prefs.snap_enable_mode == "CUSTOM_SET":
            ts.snap_elements = set(prefs.custom_snap_elements)
        # KEEP_CURRENT: do nothing
    except Exception as e:
        _dbg(f"Set snap_elements failed: {e}")


def _disable_snap(context, prefs, state):
    ts = context.scene.tool_settings
    if state.snap_managed and state.snap_backup_json:
        try:
            data = json.loads(state.snap_backup_json)
            _restore_toolsettings(ts, data)
            _dbg("Snap restored from backup.")
        except Exception as e:
            _dbg(f"Snap restore failed: {e}")
        state.snap_backup_json = ""
        state.snap_managed = False
    ts.use_snap = False


def _enable_automerge(context, prefs, state):
    ts = context.scene.tool_settings
    if not state.automerge_managed:
        ids = _automerge_prop_ids(ts)
        data = _backup_toolsettings(ts, ids)
        state.automerge_backup_json = json.dumps(data, ensure_ascii=False)
        state.automerge_managed = True
        _dbg(f"AutoMerge backup stored ({len(data)} props).")
    ts.use_mesh_automerge = True


def _disable_automerge(context, prefs, state):
    ts = context.scene.tool_settings
    if state.automerge_managed and state.automerge_backup_json:
        try:
            data = json.loads(state.automerge_backup_json)
            _restore_toolsettings(ts, data)
            _dbg("AutoMerge restored from backup.")
        except Exception as e:
            _dbg(f"AutoMerge restore failed: {e}")
        state.automerge_backup_json = ""
        state.automerge_managed = False
    ts.use_mesh_automerge = False


def _combined_current(ts, prefs):
    if prefs.toggle_basis == "AUTO_MERGE":
        return bool(getattr(ts, "use_mesh_automerge", False))
    if prefs.toggle_basis == "SNAP":
        return bool(getattr(ts, "use_snap", False))
    if prefs.toggle_basis == "EITHER_ON":
        return bool(getattr(ts, "use_mesh_automerge", False) or getattr(ts, "use_snap", False))
    if prefs.toggle_basis == "BOTH_ON":
        return bool(getattr(ts, "use_mesh_automerge", False) and getattr(ts, "use_snap", False))
    return bool(getattr(ts, "use_mesh_automerge", False))


def _cycle_snap(context, prefs):
    ts = context.scene.tool_settings
    order = _get_order_list(prefs, ts)
    nxt = _cycle_next(order, getattr(ts, "snap_elements", set()))
    if nxt is None:
        return None
    try:
        ts.snap_elements = nxt
    except Exception as e:
        _dbg(f"Cycle set snap_elements failed: {e}")
        return None
    return nxt


# =============================================================================
# Operators
# =============================================================================
class MESH_OT_toggle_merge_snap(bpy.types.Operator):
    """Toggle Auto Merge and Snap (Shift/Alt/Ctrl supported)"""

    bl_idname = "mesh.toggle_merge_snap"

    bl_label = 'Toggle Merge and Snap'
    bl_description = "Toggle both Auto Merge and Snap. Shift toggles Auto Merge only, Alt toggles Snap only, and Ctrl opens the quick popup."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True
    bl_description = "Toggle both Auto Merge and Snap. Shift: Auto Merge only. Alt: Snap only. Ctrl: Quick popup."

    def invoke(self, context, event):
        # Ctrl: quick popup dialog
        if event.ctrl:
            return bpy.ops.mesh.tams_quick_popup('INVOKE_DEFAULT')
        # Shift+Alt: force restore both (useful when repeat action is Cycle)
        if event.shift and event.alt:
            return self.execute_with_mode(context, mode="BOTH", force_off=True)
        # Shift: Auto Merge only
        if event.shift:
            return self.execute_with_mode(context, mode="AUTOMERGE", force_off=False)
        # Alt: Snap only
        if event.alt:
            return self.execute_with_mode(context, mode="SNAP", force_off=False)
        # Default: Both
        return self.execute_with_mode(context, mode="BOTH", force_off=False)

    def execute_with_mode(self, context, mode="BOTH", force_off=False):
        prefs = _get_prefs()
        if not prefs:
            return {'CANCELLED'}
        _ensure_cycle_defaults(prefs)

        scene = context.scene
        state = _get_state(scene)
        if not state:
            return {'CANCELLED'}

        ts = scene.tool_settings

        # Helpers for reporting
        def report_state(prefix, onoff):
            msg = _t(prefix).format(state="ON" if onoff else "OFF")
            self.report({'INFO'}, msg)

        if mode == "AUTOMERGE":
            cur = bool(getattr(ts, "use_mesh_automerge", False))
            if cur:
                _disable_automerge(context, prefs, state)
                report_state("Auto Merge: {state}", False)
            else:
                _enable_automerge(context, prefs, state)
                report_state("Auto Merge: {state}", True)
            return {'FINISHED'}

        if mode == "SNAP":
            cur = bool(getattr(ts, "use_snap", False))
            if cur:
                _disable_snap(context, prefs, state)
                report_state("Snap: {state}", bool(getattr(ts, "use_snap", False)))
            else:
                _enable_snap(context, prefs, state)
                report_state("Snap: {state}", True)
            return {'FINISHED'}

        # BOTH
        combined_on = _combined_current(ts, prefs)

        # If already ON and preference says "Cycle", cycle instead (no modifiers)
        if combined_on and not force_off and prefs.repeat_action_when_on == "CYCLE":
            # ensure snap is on, then cycle
            if not getattr(ts, "use_snap", False):
                _enable_snap(context, prefs, state)
            nxt = _cycle_snap(context, prefs)
            if nxt is not None:
                elems = _format_elements(nxt)
                self.report({'INFO'}, _t("Snap Elements: {elements}").format(elements=elems))
                return {'FINISHED'}

        if combined_on or force_off:
            _disable_snap(context, prefs, state)
            _disable_automerge(context, prefs, state)
            self.report({'INFO'}, _t("Auto Merge & Snap: {state}").format(state="OFF"))
            self.report({'INFO'}, _t("Restored previous settings."))
        else:
            _enable_automerge(context, prefs, state)
            _enable_snap(context, prefs, state)
            self.report({'INFO'}, _t("Auto Merge & Snap: {state}").format(state="ON"))

        return {'FINISHED'}

    def execute(self, context):
        # Fallback (execute without event) -> both
        return self.execute_with_mode(context, mode="BOTH", force_off=False)


class MESH_OT_tams_cycle_snap(bpy.types.Operator):
    bl_idname = "mesh.tams_cycle_snap"

    bl_label = "Cycle Snap"
    bl_description = "Cycle through the configured snap element combinations without changing Auto Merge."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    def execute(self, context):
        prefs = _get_prefs()
        if not prefs:
            return {'CANCELLED'}
        _ensure_cycle_defaults(prefs)

        ts = context.scene.tool_settings
        if not getattr(ts, "use_snap", False):
            # Don't auto-enable; just enable via addon logic so backup/restore is safe
            state = _get_state(context.scene)
            if state:
                _enable_snap(context, prefs, state)

        nxt = _cycle_snap(context, prefs)
        if nxt is None:
            return {'CANCELLED'}

        elems = _format_elements(nxt)
        self.report({'INFO'}, _t("Snap Elements: {elements}").format(elements=elems))
        return {'FINISHED'}


class MESH_OT_tams_quick_popup(bpy.types.Operator):
    bl_idname = "mesh.tams_quick_popup"

    bl_label = "Quick Snap Settings"
    bl_description = "Open a compact popup for quickly editing snap element toggles and applying them immediately."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    snap_target: bpy.props.EnumProperty(name="Snap Target", items=_snap_target_items, description="Choose the snap target rule that Blender should use when snapping is active from this quick popup.")
    snap_elements: bpy.props.EnumProperty(name="Snap Elements", items=_snap_elements_items, options={"ENUM_FLAG"}, description="Choose which snap elements should be enabled immediately when you apply this quick popup.")
    automerge_threshold: bpy.props.FloatProperty(name="Auto Merge Threshold", default=0.001, min=0.0, soft_max=0.1, description="Distance threshold used by Auto Merge when vertices are moved close enough to weld together.")

    def invoke(self, context, event):
        ts = context.scene.tool_settings
        # Initialize from current settings
        try:
            self.snap_target = getattr(ts, "snap_target", self.snap_target)
        except Exception:
            pass
        try:
            self.snap_elements = set(getattr(ts, "snap_elements", set()))
        except Exception:
            pass
        if hasattr(ts, "double_threshold"):
            try:
                self.automerge_threshold = float(getattr(ts, "double_threshold"))
            except Exception:
                pass

        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=360)

    def draw(self, context):
        layout = self.layout
        layout.label(text=_t("Quick Snap Settings"), icon="PREFERENCES")

        col = layout.column(align=True)
        col.prop(self, "snap_target")
        col.prop(self, "snap_elements")

        ts = context.scene.tool_settings
        if hasattr(ts, "double_threshold"):
            col.prop(self, "automerge_threshold")

    def execute(self, context):
        ts = context.scene.tool_settings
        try:
            setattr(ts, "snap_target", self.snap_target)
        except Exception as e:
            _dbg(f"Apply snap_target failed: {e}")

        try:
            setattr(ts, "snap_elements", set(self.snap_elements))
        except Exception as e:
            _dbg(f"Apply snap_elements failed: {e}")

        if hasattr(ts, "double_threshold"):
            try:
                setattr(ts, "double_threshold", float(self.automerge_threshold))
            except Exception as e:
                _dbg(f"Apply automerge_threshold failed: {e}")

        return {'FINISHED'}


# =============================================================================
# Optional UI: Header / Status Bar indicators
# =============================================================================
def _draw_indicator(layout, context):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts:
        return
    am = bool(getattr(ts, "use_mesh_automerge", False))
    sn = bool(getattr(ts, "use_snap", False))

    row = layout.row(align=True)
    row.scale_x = 0.85
    row.label(text="AM", icon="CHECKBOX_HLT" if am else "CHECKBOX_DEHLT")
    row.label(text="SN", icon="CHECKBOX_HLT" if sn else "CHECKBOX_DEHLT")


def tams_draw_view3d_header(self, context):
    prefs = None
    try:
        prefs = _get_prefs()
    except Exception:
        prefs = None
    # Respect Smart Modeling master enable switch
    if not _tams_feature_enabled(context, "enable_toggle_auto_merge_snap", True):
        return

    if not prefs or not getattr(prefs, "show_header_indicator", False):
        return
    layout = self.layout
    if hasattr(layout, "separator_spacer"):
        layout.separator_spacer()
    else:
        layout.separator()
    _draw_indicator(layout, context)


def tams_draw_statusbar(self, context):
    prefs = None
    try:
        prefs = _get_prefs()
    except Exception:
        prefs = None
    # Respect Smart Modeling master enable switch
    if not _tams_feature_enabled(context, "enable_toggle_auto_merge_snap", True):
        return

    if not prefs or getattr(prefs, "status_bar_indicator", "OFF") != "ALWAYS":
        return
    layout = self.layout
    if hasattr(layout, "separator_spacer"):
        layout.separator_spacer()
    else:
        layout.separator()
    _draw_indicator(layout, context)


# =============================================================================
# Dedicated UI panel (proxied into Smart Tools when the suite host is active)
# =============================================================================
class VIEW3D_PT_tams_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    bl_label = "Merge Snap"
    bl_description = 'Merge Snap panel in the Smart Modeling workspace.'

    @classmethod
    def poll(cls, context):
        if not _tams_feature_enabled(context, "enable_toggle_auto_merge_snap", True):
            return False
        if _smart_tools_window_active(context):
            return True
        prefs = _get_prefs()
        return bool(prefs and getattr(prefs, 'enable_n_panel', False))

    def draw(self, context):
        prefs = _get_prefs()
        layout = self.layout
        ts = context.scene.tool_settings

        box = layout.box()
        box.label(text=_t("Status"))
        row = box.row(align=True)
        row.label(text=_t("Auto Merge") + f": {'ON' if getattr(ts, 'use_mesh_automerge', False) else 'OFF'}")
        row.label(text=_t("Snap") + f": {'ON' if getattr(ts, 'use_snap', False) else 'OFF'}")

        col = layout.column(align=True)
        _tams_layout_operator_if_registered(col, "mesh.toggle_merge_snap", text=_t("Toggle Both"), icon="FILE_REFRESH")

        # Dedicated operators (reliable from UI)
        row = col.row(align=True)
        _tams_layout_operator_if_registered(row, "mesh.tams_toggle_automerge", text=_t("Toggle Auto Merge Only"))
        _tams_layout_operator_if_registered(row, "mesh.tams_toggle_snap", text=_t("Toggle Snap Only"))

        col.separator()
        _tams_layout_operator_if_registered(col, "mesh.tams_cycle_snap", text=_t("Cycle Snap"), icon="FILE_REFRESH")
        _tams_layout_operator_if_registered(col, "mesh.tams_quick_popup", text=_t("Quick Popup"), icon="PREFERENCES")


class VIEW3D_PT_tams_help(bpy.types.Panel):
    """Beginner-friendly guide for Merge Snap."""

    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    bl_label = "Guide / Tips"
    bl_description = 'Guide / Tips help panel with workflow notes and beginner guidance.'
    bl_idname = "VIEW3D_PT_tams_help"
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _tams_feature_enabled(context, "enable_toggle_auto_merge_snap", True)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=_t("What this tool does"))
        col = box.column(align=True)
        col.label(text=_t("Toggle Auto Merge and Snap quickly while modeling."))
        col.label(text=_t("This is useful when you switch between precise snapping and free editing."))

        box = layout.box()
        box.label(text=_t("How to use (beginner)"), icon='MOUSE_LMB')
        col = box.column(align=True)
        col.label(text=_t("• Toggle Both: switches Auto Merge and Snap together."))
        col.label(text=_t("• Toggle Auto Merge Only / Toggle Snap Only: independent control."))
        col.label(text=_t("• Cycle Snap: cycles snap elements (Vertex/Edge/Face/...) quickly."))



class MESH_OT_tams_toggle_automerge(bpy.types.Operator):
    bl_idname = "mesh.tams_toggle_automerge"

    bl_label = "Toggle Auto Merge Only"
    bl_description = "Toggle only Auto Merge while leaving the current snap state untouched."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    def execute(self, context):
        prefs = _get_prefs()
        state = _get_state(context.scene)
        if not prefs or not state:
            return {'CANCELLED'}
        ts = context.scene.tool_settings
        if getattr(ts, "use_mesh_automerge", False):
            _disable_automerge(context, prefs, state)
            self.report({'INFO'}, _t("Auto Merge: {state}").format(state="OFF"))
        else:
            _enable_automerge(context, prefs, state)
            self.report({'INFO'}, _t("Auto Merge: {state}").format(state="ON"))
        return {'FINISHED'}


class MESH_OT_tams_toggle_snap(bpy.types.Operator):
    bl_idname = "mesh.tams_toggle_snap"

    bl_label = "Toggle Snap Only"
    bl_description = "Toggle only Snap while leaving the current Auto Merge state untouched."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Explicit shortcut/operator execution remains available even when the
        # Always-on indicator/runtime switch is off.
        return True

    def execute(self, context):
        prefs = _get_prefs()
        state = _get_state(context.scene)
        if not prefs or not state:
            return {'CANCELLED'}
        ts = context.scene.tool_settings
        if getattr(ts, "use_snap", False):
            _disable_snap(context, prefs, state)
            self.report({'INFO'}, _t("Snap: {state}").format(state="OFF"))
        else:
            _enable_snap(context, prefs, state)
            self.report({'INFO'}, _t("Snap: {state}").format(state="ON"))
        return {'FINISHED'}


# =============================================================================
# Registration
# =============================================================================
classes = (
    TAMS_CycleItem,
    TAMS_State,
    TAMS_Prefs,
    TAMS_UL_cycle_order,
    MESH_OT_tams_cycle_add,
    MESH_OT_tams_cycle_remove,
    MESH_OT_tams_cycle_move,
    MESH_OT_toggle_merge_snap,
    MESH_OT_tams_cycle_snap,
    MESH_OT_tams_quick_popup,
    MESH_OT_tams_toggle_automerge,
    MESH_OT_tams_toggle_snap,
    VIEW3D_PT_tams_panel,
    VIEW3D_PT_tams_help,
)

_TAMS_PROPERTY_CLASSES = (
    TAMS_CycleItem,
    TAMS_State,
    TAMS_Prefs,
)
_TAMS_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _TAMS_PROPERTY_CLASSES)

_header_appended = False
_status_appended = False


def register():
    global _header_appended, _status_appended

    # Translations
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass


    try:
        if hasattr(bpy.types.Scene, "tams_state"):
            del bpy.types.Scene.tams_state
    except Exception:
        pass
    bpy.types.Scene.tams_state = bpy.props.PointerProperty(type=TAMS_State, description='Stores runtime state for Merge Snap.')
    try:
        if hasattr(bpy.types.Scene, "tams_prefs"):
            del bpy.types.Scene.tams_prefs
    except Exception:
        pass
    bpy.types.Scene.tams_prefs = bpy.props.PointerProperty(type=TAMS_Prefs, description='Stores Merge Snap settings for this scene')

    # Header indicator disabled in Smart Modeling (use Smart Tools / popup instead)
    # Ensure no stale handler remains from older versions.
    try:
        bpy.types.VIEW3D_HT_header.remove(tams_draw_view3d_header)
    except Exception:
        pass
    try:
        bpy.types.STATUSBAR_HT_header.remove(tams_draw_statusbar)
    except Exception:
        pass
    # Persistent STATUSBAR_HT_header callbacks are disabled for Blender 5.1.x
    # reinstall safety. Status remains available in Smart Modeling UI/reports.
    _status_appended = False

    # Cycle defaults are initialized lazily during UI/operator use.
    # Do not touch nested N-panel settings from register(), because this may be
    # called by a suite preload timer while Blender is refreshing RNA classes.

    # --- Add-on設定画面のdescription動的書き換え ---
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                desc_eng = "Tool to toggle Auto Merge and Snap with safe backup/restore, modifier keys, cycling, indicators, and optional panel. ID: 'mesh.toggle_merge_snap'"
                try:
                    desc_tr = bpy.app.translations.pgettext(desc_eng)
                except Exception:
                    desc_tr = desc_eng

                try:
                    prefs_ctx = getattr(bpy.context, "preferences", None)
                    lang = getattr(getattr(prefs_ctx, "view", None), "language", "") if prefs_ctx else ""
                    if (lang or "").startswith("ja") and desc_tr == desc_eng:
                        desc_tr = translation_dict.get("ja_JP", {}).get(("*", desc_eng), desc_tr)
                except Exception:
                    pass

                mod.bl_info["description"] = desc_tr
                break
    except Exception:
        pass


def unregister():
    global _header_appended, _status_appended

    # Restore english description
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Tool to toggle Auto Merge and Snap with safe backup/restore, modifier keys, cycling, indicators, and optional panel. ID: 'mesh.toggle_merge_snap'"
                break
    except Exception:
        pass

    # Remove handlers
    try:
        bpy.types.VIEW3D_HT_header.remove(tams_draw_view3d_header)
    except Exception:
        pass
    if _header_appended:
        try:
            bpy.types.VIEW3D_HT_header.remove(tams_draw_view3d_header)
        except Exception:
            pass
        _header_appended = False

    if _status_appended:
        try:
            bpy.types.STATUSBAR_HT_header.remove(tams_draw_statusbar)
        except Exception:
            pass
        _status_appended = False

    for cls in reversed(_TAMS_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    # Remove scene pointer
    try:
        del bpy.types.Scene.tams_state
    except Exception:
        pass
    try:
        del bpy.types.Scene.tams_prefs
    except Exception:
        pass

    for cls in reversed(_TAMS_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


if __name__ == "__main__":
    register()

# --- Tooltip completion (Merge Snap panels) ---
VIEW3D_PT_tams_help.bl_description = 'Beginner-friendly usage notes for Auto Merge / Snap toggle presets and cycling behavior.'


VIEW3D_PT_tams_panel.bl_description = 'Compact panel for toggling Auto Merge and snapping presets quickly while modeling.'

translation_dict["ja_JP"].update({
    ("*", "Snap element stored in this cycle slot. The cycle operator will switch to this element when the slot becomes active."):
        "このサイクルスロットへ保存されるスナップ要素です。サイクル実行時、このスロットが有効になると該当要素へ切り替わります。",
    ("*", "Choose which state is treated as the main reference when the tool toggles Auto Merge and Snap together."):
        "このツールが自動マージとスナップを同時切替するとき、どの状態を主な判定基準にするかを選びます。",
    ("*", "Choose which snap elements should become active when this tool turns snapping on."):
        "このツールでスナップをオンにした際、どのスナップ要素を有効化するかを選びます。",
    ("*", "Snap elements that will be enabled when Snap Enable Mode is set to Custom Set."):
        'スナップの有効化モードが「指定のセット」の時に有効にするスナップの要素です。',
    ("*", "Choose what the main toggle should do if the managed state is already on and you press it again without modifier keys."):
        "管理対象状態がすでにオンのとき、修飾キーなしで再度メイントグルを押した場合の動作を選びます。",
    ("*", "Enable or disable the custom snap-element cycle list. When enabled, the cycle operator follows the order shown below."):
        "カスタムのスナップ要素サイクル一覧を有効 / 無効にします。有効時、サイクルオペレーターは下の順序に従います。",
    ("*", "Show a small status hint in supported headers so you can see the managed Auto Merge / Snap state at a glance."):
        '対応ヘッダーに小さな状態ヒントを表示し、管理中の 自動マージ / スナップ 状態をひと目で確認できるようにします。',
    ("*", "Choose when the status bar indicator should be visible: never, only after reports, or always."):
        "ステータスバー表示のタイミングを選びます。非表示、レポート時のみ、常時表示から選択できます。",
    ("*", "Show a compact helper panel for this tool in the 3D View N-panel. Useful if you want mouse-accessible controls instead of relying only on shortcuts."):
        '3D View の N パネルへ、このツール用のコンパクト補助パネルを表示します。ショートカットだけでなくマウス操作でも使いたい場合に便利です。',
    ("*", "Print extra diagnostic information to Blender's system console. Enable this only when you are troubleshooting the tool."):
        "Blender のシステムコンソールへ追加診断情報を出力します。トラブルシュート時のみ有効化してください。",
    ("*", "Choose the snap target rule that Blender should use when snapping is active from this quick popup."):
        "このクイックポップアップからスナップを有効化した際に使う Blender のスナップターゲット規則を選びます。",
    ("*", "Choose which snap elements should be enabled immediately when you apply this quick popup."):
        "このクイックポップアップを適用した直後に有効化するスナップ要素を選びます。",
    ("*", "Distance threshold used by Auto Merge when vertices are moved close enough to weld together."):
        '頂点が十分近づいたときに 自動マージ で結合する距離しきい値です。',
    ("*", "Move the selected cycle item up or down inside the custom snap cycle order."):
        "選択中のサイクル項目を、カスタムスナップサイクル順の中で上下に移動します。",
})



translation_dict["ja_JP"].update({
    ("*", "Add Cycle Item"): "サイクル項目を追加",
    ("*", "Remove Cycle Item"): "サイクル項目を削除",
    ("*", "Move Cycle Item"): "サイクル項目を移動",
    ("*", "Element"): "要素",
    ("*", "Snap Target"): "スナップ対象",
    ("*", "Snap Elements"): "スナップ要素",
    ("*", "Auto Merge Threshold"): "自動マージしきい値",
    ("*", "AM"): "AM",
    ("*", "SN"): "SN",
})


# --- Smart Modeling source-style toggle override ---
def _sms_tams_apply_enable_elements(ts, prefs=None):
    mode = str(getattr(prefs, 'snap_enable_mode', 'FORCE_VERTEX') or 'FORCE_VERTEX') if prefs is not None else 'FORCE_VERTEX'
    try:
        if mode == 'CUSTOM_SET':
            custom = set(getattr(prefs, 'custom_snap_elements', set()) or set())
            if custom:
                ts.snap_elements = custom
            else:
                ts.snap_elements = {'VERTEX'}
        elif mode == 'KEEP_CURRENT':
            if not getattr(ts, 'snap_elements', None):
                ts.snap_elements = {'VERTEX'}
        else:
            ts.snap_elements = {'VERTEX'}
    except Exception:
        try:
            ts.snap_elements = {'VERTEX'}
        except Exception:
            pass


def _sms_tams_source_execute_with_mode(self, context, mode='BOTH', force_off=False):
    prefs = _get_prefs()
    ts = context.scene.tool_settings

    if mode == 'AUTOMERGE':
        new_state = False if force_off else (not bool(getattr(ts, 'use_mesh_automerge', False)))
        ts.use_mesh_automerge = new_state
        self.report({'INFO'}, _t('Auto Merge: {state}').format(state='ON' if new_state else 'OFF'))
        return {'FINISHED'}

    if mode == 'SNAP':
        new_state = False if force_off else (not bool(getattr(ts, 'use_snap', False)))
        ts.use_snap = new_state
        if new_state:
            _sms_tams_apply_enable_elements(ts, prefs)
        self.report({'INFO'}, _t('Snap: {state}').format(state='ON' if new_state else 'OFF'))
        return {'FINISHED'}

    # Source add-on behavior: use Auto Merge as the toggle basis and switch both together.
    new_state = False if force_off else (not bool(getattr(ts, 'use_mesh_automerge', False)))
    ts.use_mesh_automerge = new_state
    ts.use_snap = new_state
    if new_state:
        _sms_tams_apply_enable_elements(ts, prefs)
    self.report({'INFO'}, _t('Auto Merge & Snap: {state}').format(state='ON' if new_state else 'OFF'))
    return {'FINISHED'}

MESH_OT_toggle_merge_snap.execute_with_mode = _sms_tams_source_execute_with_mode
