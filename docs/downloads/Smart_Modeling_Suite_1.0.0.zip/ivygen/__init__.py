bl_info = {
    "name": "Ivy Generator",
    "author": "testscreenings, PKHG, TrumanBlending",
    "version": (0, 1, 5),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Ivy Generator (Create Tab)",
    "description": "Adds generated ivy to a mesh object starting "
                   "at the 3D cursor",
    "warning": "",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/add_curve/ivy_gen.html",
    "category": "Add Curve",
}


import bpy
from bpy.types import (
    Operator,
    Panel,
    PropertyGroup,
)
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)
from mathutils.bvhtree import BVHTree
from mathutils import (
    Vector,
    Matrix,
)
from collections import deque
from math import (
    pow, cos,
    pi, atan2,
)
from random import (
    random as rand_val,
    seed as rand_seed,
)
import time


def createIvyGeometry(IVY, growLeaves):
    """Turn each grown root into a tapered spline and optionally generate leaf quads."""
    from itertools import chain

    falloff = (1, 2, 4, 7, 9, 10, 9, 7, 4, 2, 1)
    winding = ((-1, 1), (1, 1), (1, -1), (-1, -1))
    down = Vector((0, 0, -1))
    leaf_vertices = []

    def smooth_surface(nodes):
        last = len(nodes) - 1
        for index, node in enumerate(nodes):
            sample_indices = (min(last, max(0, offset)) for offset in range(index - 5, index + 6))
            weighted = sum((nodes[i].adhesionVector * coefficient
                            for i, coefficient in zip(sample_indices, falloff, strict=True)),
                           node.smoothAdhesionVector)
            weighted /= sum(falloff)
            node.adhesionLength = weighted.length
            node.smoothAdhesionVector = weighted.normalized()

    def leaf_quads(node, following, relative):
        direction = node.smoothAdhesionVector
        ground = max(0.0, -direction.z)
        density = pow(relative, 0.7) + ground * pow(1 - relative, 2)
        alignment = node.adhesionLength
        azimuth = atan2(direction.y, direction.x) - pi / 2.0 + (rand_val() - 0.5) * (1.3 - alignment)
        elevation = 0.5 * direction.angle(down, 0) + (rand_val() - 0.5) * (1.1 - alignment)
        size = IVY.ivyLeafSize * (1.5 - (cos(2 * pi * density) * 0.5 + 0.5))
        pitch = Matrix.Rotation(elevation, 3, 'X')
        yaw = Matrix.Rotation(azimuth, 3, 'Z')
        bases = [Vector((1, 0, 0)), Vector((0, 1, 0))]
        for base in bases:
            base.rotate(pitch)
            base.rotate(yaw)
            base *= size
        u, v = bases
        for position in range(10):
            if rand_val() * density > IVY.leafProbability:
                jitter = Vector(tuple(rand_val() - 0.5 for _ in range(3)))
                center = node.pos.lerp(following.pos, position / 10.0) + IVY.ivyLeafSize * jitter
                yield from (x * u + y * v + center for x, y in winding)

    curve = bpy.data.curves.new("IVY", type='CURVE')
    curve.dimensions = '3D'
    curve.bevel_depth = 1
    curve.fill_mode = 'FULL'
    curve.resolution_u = 4
    for root in IVY.ivyRoots:
        nodes = list(root.ivyNodes)
        if len(nodes) < 2:
            continue
        length_factor = 1.0 / nodes[-1].length
        root_radius = (1.0 / (root.parents + 1) + 1.0) * IVY.ivyBranchSize
        branch = curve.splines.new(type='POLY')
        branch.points.add(len(nodes) - 1)
        branch.points.foreach_set('co', list(chain.from_iterable(node.pos.to_4d() for node in nodes)))
        branch.points.foreach_set('radius', [root_radius * (1.3 - node.length * length_factor) for node in nodes])
        smooth_surface(nodes)
        if growLeaves:
            for node, following in zip(nodes, nodes[1:]):
                leaf_vertices.extend(leaf_quads(node, following, node.length * length_factor))

    collection = bpy.context.collection.objects
    stem = bpy.data.objects.new("IVY_Curve", curve)
    collection.link(stem)
    if growLeaves:
        leaf_mesh = bpy.data.meshes.new("IvyLeaf")
        faces = [tuple(range(index, index + 4)) for index in range(0, len(leaf_vertices), 4)]
        leaf_mesh.from_pydata(leaf_vertices, [], faces)
        leaf_mesh.update(calc_edges=True)
        leaf_obj = bpy.data.objects.new("IvyLeaf", leaf_mesh)
        collection.link(leaf_obj)
        leaf_mesh.uv_layers.new(name="Leaves")
        leaf_obj.parent = stem


class IvyNode:
    """ The basic class used for each point on the ivy which is grown."""
    __slots__ = ('pos', 'primaryDir', 'adhesionVector', 'adhesionLength',
                 'smoothAdhesionVector', 'length', 'floatingLength', 'climb')

    def __init__(self):
        self.pos, self.adhesionVector, self.smoothAdhesionVector = (Vector() for _ in range(3))
        self.primaryDir = Vector((0, 0, 1))
        self.length, self.floatingLength, self.climb = 0.0001, 0.0, True


class IvyRoot:
    """ The class used to hold all ivy nodes growing from this root point."""
    __slots__ = ('ivyNodes', 'alive', 'parents')

    def __init__(self):
        self.ivyNodes = deque()
        self.alive = True
        self.parents = 0


class Ivy:
    """ The class holding all parameters and ivy roots."""
    __slots__ = ('ivyRoots', 'primaryWeight', 'randomWeight',
                 'gravityWeight', 'adhesionWeight', 'branchingProbability',
                 'leafProbability', 'ivySize', 'ivyLeafSize', 'ivyBranchSize',
                 'maxFloatLength', 'maxAdhesionDistance', 'maxLength')

    def __init__(self,
                 primaryWeight=0.5,
                 randomWeight=0.2,
                 gravityWeight=1.0,
                 adhesionWeight=0.1,
                 branchingProbability=0.05,
                 leafProbability=0.35,
                 ivySize=0.02,
                 ivyLeafSize=0.02,
                 ivyBranchSize=0.001,
                 maxFloatLength=0.5,
                 maxAdhesionDistance=1.0):
        total = primaryWeight + randomWeight + adhesionWeight
        self.primaryWeight, self.randomWeight, self.adhesionWeight = (
            weight / total for weight in (primaryWeight, randomWeight, adhesionWeight)
        )
        self.gravityWeight = gravityWeight
        self.branchingProbability, self.leafProbability = 1 - branchingProbability, 1 - leafProbability
        self.ivySize, self.ivyLeafSize, self.ivyBranchSize = ivySize, ivyLeafSize, ivyBranchSize
        self.maxFloatLength, self.maxAdhesionDistance = maxFloatLength, maxAdhesionDistance
        self.ivyRoots, self.maxLength = deque(), 0.0

    def seed(self, seedPos):
        # Seed the Ivy by making a new root and first node
        tmpRoot = IvyRoot()
        tmpIvy = IvyNode()
        tmpIvy.pos = seedPos

        tmpRoot.ivyNodes.append(tmpIvy)
        self.ivyRoots.append(tmpRoot)

    def grow(self, ob, bvhtree):
        """Advance each live tip, then choose at most one branch from the grown roots."""
        gravity_axis = self.ivySize * self.gravityWeight * Vector((0, 0, -1))

        def advance(tip):
            turn = Vector(tuple(rand_val() - 0.5 for _ in range(3))) + Vector((0, 0, 0.2))
            turn.normalize()
            attraction = adhesion(tip.pos, bvhtree, self.maxAdhesionDistance)
            intent = self.ivySize * (tip.primaryDir * self.primaryWeight + turn * self.randomWeight
                                    + attraction * self.adhesionWeight)
            gravity = gravity_axis * pow(tip.floatingLength / self.maxFloatLength, 0.7)
            contact, position = collision(bvhtree, tip.pos, tip.pos + intent + gravity)
            travelled = position - tip.pos
            tangent = (travelled - gravity).normalized()
            node = IvyNode()
            node.climb, node.pos = contact, position
            node.primaryDir = tip.primaryDir.lerp(tangent, 0.5).normalized()
            node.adhesionVector = attraction
            node.length = tip.length + travelled.length
            node.floatingLength = 0.0 if contact else tip.floatingLength + travelled.length
            return node

        for root in self.ivyRoots:
            if root.alive:
                tip = root.ivyNodes[-1]
                if tip.floatingLength > self.maxFloatLength:
                    root.alive = False
                node = advance(tip)
                self.maxLength = max(self.maxLength, node.length)
                root.ivyNodes.append(node)

        for root in self.ivyRoots:
            if not root.alive or root.parents > 3 or len(root.ivyNodes) < 2:
                continue
            reach = root.ivyNodes[-1].length
            for source in root.ivyNodes:
                readiness = 1.0 - (cos(2.0 * pi * source.length / reach) * 0.5 + 0.5)
                if rand_val() * readiness > self.branchingProbability:
                    seed = IvyNode()
                    seed.pos, seed.floatingLength = source.pos, source.floatingLength
                    shoot = IvyRoot()
                    shoot.parents = root.parents + 1
                    shoot.ivyNodes.append(seed)
                    self.ivyRoots.append(shoot)
                    return


def adhesion(loc, bvhtree, max_l):
    neighbor = bvhtree.find_nearest(loc, max_l)[0]
    if neighbor is None:
        return Vector()
    direction = neighbor - loc
    distance = direction.length
    if distance:
        return direction.normalized() * (1.0 - distance / max_l)
    return direction


def collision(bvhtree, pos, new_pos):
    motion = new_pos - pos
    position, normal, *_ = bvhtree.ray_cast(pos, motion, motion.length)
    if position is not None and motion.dot(normal) < 0.0:
        return True, position + (new_pos - position).reflect(normal)
    return False, new_pos


def bvhtree_from_object(ob):
    """Build an independent world-space surface index for the current ivy target."""
    import bmesh
    from mathutils.bvhtree import BVHTree

    graph = bpy.context.evaluated_depsgraph_get()
    target = ob.evaluated_get(graph)
    proxy = bmesh.new(use_operators=False)
    try:
        proxy.from_mesh(target.data)
        world = target.matrix_world
        # Preserve polygon identity and the face normals used by existing ivy
        # presets. Only point positions are moved into cursor/world space.
        for vertex in proxy.verts:
            vertex.co = world @ vertex.co
        return BVHTree.FromBMesh(proxy)
    finally:
        proxy.free()

def check_mesh_faces(ob):
    me = ob.data
    if len(me.polygons) > 0:
        return True

    return False


class IvyGen(Operator):
    bl_idname = "curve.ivy_gen"
    bl_label = "IvyGen"
    bl_description = "Generate Ivy on an Mesh Object"
    bl_options = {'UNDO'}

    updateIvy: BoolProperty(
        name="Update Ivy",
        description="Update the Ivy location based on the cursor and Panel settings",
        default=False
    )
    defaultIvy: BoolProperty(
        name="Default Ivy",
        options={"HIDDEN", "SKIP_SAVE"},
        default=False
    )

    @classmethod
    def poll(self, context):
        # Check if there's an object and whether it's a mesh
        ob = context.active_object
        return ((ob is not None) and
                (ob.type == 'MESH') and
                (context.mode == 'OBJECT'))

    def invoke(self, context, event):
        self.updateIvy = True
        return self.execute(context)

    def execute(self, context):
        if not self.updateIvy:
            return {'PASS_THROUGH'}

        preset = {"randomSeed": 0, "maxTime": 0, "maxIvyLength": 1.0, "ivySize": 0.02,
                  "maxFloatLength": 0.5, "maxAdhesionDistance": 1.0, "primaryWeight": 0.5,
                  "randomWeight": 0.2, "gravityWeight": 1.0, "adhesionWeight": 0.1,
                  "branchingProbability": 0.05, "leafProbability": 0.35,
                  "ivyBranchSize": 0.001, "ivyLeafSize": 0.02, "growLeaves": True}
        properties = context.window_manager.ivy_gen_props
        settings = preset if self.defaultIvy else {key: getattr(properties, key) for key in preset}

        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        source = context.active_object
        surface = bvhtree_from_object(source)
        if not check_mesh_faces(source):
            self.report({'WARNING'}, "Mesh Object doesn't have at least one Face. Operation Cancelled")
            return {'CANCELLED'}

        grow_leaves = settings.pop("growLeaves")
        length_limit, time_limit = settings.pop("maxIvyLength"), settings.pop("maxTime")
        rand_seed(settings.pop("randomSeed"))
        plant = Ivy(**settings)
        plant.seed(context.scene.cursor.location)
        started = time.time()
        next_report = 0.0
        running = True
        while running and plant.maxLength < length_limit and (not time_limit or time.time() - started < time_limit):
            plant.grow(source, surface)
            progress = plant.maxLength / length_limit * 100
            if progress > next_report:
                print('%0.2f%% of Ivy nodes have grown' % progress)
                next_report += 10
                if plant.maxLength > length_limit:
                    print("Halting Growth")
            running = any(root.alive for root in plant.ivyRoots)

        createIvyGeometry(plant, grow_leaves)
        print("Geometry Generation Complete")
        print("Ivy generated in %0.2f s" % (time.time() - started))
        self.updateIvy = self.defaultIvy = False
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "updateIvy", icon="FILE_REFRESH")


class CURVE_PT_IvyGenPanel(Panel):
    bl_label = "Ivy Generator"
    bl_idname = "CURVE_PT_IvyGenPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Modeling'
    bl_context = "objectmode"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        config = context.window_manager.ivy_gen_props
        buttons = self.layout.column(align=True)
        for preset, title, icon in (
            (False, "Add New Ivy", "OUTLINER_OB_CURVE"),
            (True, "Add New Default Ivy", "CURVE_DATA"),
        ):
            command = buttons.operator("curve.ivy_gen", text=title, icon=icon)
            command.defaultIvy = preset
            command.updateIvy = True

        sections = (
            ("Generation Settings:", ("randomSeed", "maxTime")),
            ("Size Settings:", ("maxIvyLength", "ivySize", "maxFloatLength", "maxAdhesionDistance")),
            ("Weight Settings:", ("primaryWeight", "randomWeight", "gravityWeight", "adhesionWeight")),
            ("Branch Settings:", ("branchingProbability", "ivyBranchSize")),
            (None, ("growLeaves",)),
        )
        if config.growLeaves:
            sections += (("Leaf Settings:", ("ivyLeafSize", "leafProbability")),)
        for label, keys in sections:
            column = self.layout.column(align=True)
            if label:
                column.label(text=label)
            for key in keys:
                column.prop(config, key)


class IvyGenProperties(PropertyGroup):
    maxIvyLength: FloatProperty(
        name="Max Ivy Length",
        description="Maximum ivy length in Blender Units",
        default=1.0,
        min=0.0,
        soft_max=3.0,
        subtype='DISTANCE',
        unit='LENGTH'
    )
    primaryWeight: FloatProperty(
        name="Primary Weight",
        description="Weighting given to the current direction",
        default=0.5,
        min=0.0,
        soft_max=1.0
    )
    randomWeight: FloatProperty(
        name="Random Weight",
        description="Weighting given to the random direction",
        default=0.2,
        min=0.0,
        soft_max=1.0
    )
    gravityWeight: FloatProperty(
        name="Gravity Weight",
        description="Weighting given to the gravity direction",
        default=1.0,
        min=0.0,
        soft_max=1.0
    )
    adhesionWeight: FloatProperty(
        name="Adhesion Weight",
        description="Weighting given to the adhesion direction",
        default=0.1,
        min=0.0,
        soft_max=1.0
    )
    branchingProbability: FloatProperty(
        name="Branching Probability",
        description="Probability of a new branch forming",
        default=0.05,
        min=0.0,
        soft_max=1.0
    )
    leafProbability: FloatProperty(
        name="Leaf Probability",
        description="Probability of a leaf forming",
        default=0.35,
        min=0.0,
        soft_max=1.0
    )
    ivySize: FloatProperty(
        name="Ivy Size",
        description="The length of an ivy segment in Blender"
                    " Units",
        default=0.02,
        min=0.0,
        soft_max=1.0,
        precision=3
    )
    ivyLeafSize: FloatProperty(
        name="Ivy Leaf Size",
        description="The size of the ivy leaves",
        default=0.02,
        min=0.0,
        soft_max=0.5,
        precision=3
    )
    ivyBranchSize: FloatProperty(
        name="Ivy Branch Size",
        description="The size of the ivy branches",
        default=0.001,
        min=0.0,
        soft_max=0.1,
        precision=4
    )
    maxFloatLength: FloatProperty(
        name="Max Float Length",
        description="The maximum distance that a branch "
                    "can live while floating",
        default=0.5,
        min=0.0,
        soft_max=1.0
    )
    maxAdhesionDistance: FloatProperty(
        name="Max Adhesion Length",
        description="The maximum distance that a branch "
                    "will feel the effects of adhesion",
        default=1.0,
        min=0.0,
        soft_max=2.0,
        precision=2
    )
    randomSeed: IntProperty(
        name="Random Seed",
        description="The seed governing random generation",
        default=0,
        min=0
    )
    maxTime: FloatProperty(
        name="Maximum Time",
        description="The maximum time to run the generation for "
                    "in seconds generation (0.0 = Disabled)",
        default=0.0,
        min=0.0,
        soft_max=10
    )
    growLeaves: BoolProperty(
        name="Grow Leaves",
        description="Grow leaves or not",
        default=True
    )


classes = (
    IvyGen,
    IvyGenProperties,
    CURVE_PT_IvyGenPanel
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.ivy_gen_props = PointerProperty(
        type=IvyGenProperties
    )


def unregister():
    del bpy.types.WindowManager.ivy_gen_props

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
