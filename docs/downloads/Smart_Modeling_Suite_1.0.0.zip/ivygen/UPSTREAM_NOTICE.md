# IvyGen Source Evidence

Compared upstream author field: testscreenings, PKHG, TrumanBlending
Compared source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/add_curve_ivygen.py
Comparison commit: b42d68627734cb18af0e6f41537063984313a284
Comparison-source version: 0.1.5

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2011-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

The bounded comparison with SmartModeling1.3.105 found 12 exactly matching nontrivial function ASTs in ivygen/__init__.py. The complete files are not byte-identical or identical after line-ending normalization. AST matching includes identifiers and docstrings, excludes source positions, and requires at least30 AST nodes.

The original acquired archive/version and the origin of all other code have not been established. The comparison-source version is not a verified bundled-version claim. This notice preserves observed upstream declarations; it does not replace the full license terms, change existing code or headers, or establish complete attribution, license/source-offer compliance or sales clearance.
