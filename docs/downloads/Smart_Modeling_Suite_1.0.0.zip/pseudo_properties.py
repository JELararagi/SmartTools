# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility entry for Smart Tools Manager's Modeling sidebar registration."""

from .navigation_properties import _publish_compatibility

# Legacy callers can load both names, each with its own callbacks and entries.
_publish_compatibility(globals())
