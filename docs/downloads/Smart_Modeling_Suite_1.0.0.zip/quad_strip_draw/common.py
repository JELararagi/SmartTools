"""Shared runtime flags, math helpers, and strip calculation helpers."""

import blf
import bpy
from bpy.props import BoolProperty
from mathutils import Vector, geometry
from bpy_extras import view3d_utils

_WM_FLAG_NAME = "safe_qsd_running"

_WM_STOP_FLAG_NAME = "safe_qsd_stop_requested"

_QSD_DRAW_TOGGLE_SYNC = False

_QSD_PENDING_TOGGLE_START = False

def _wm_get_running(context) -> bool:
    return bool(getattr(context.window_manager, _WM_FLAG_NAME, False))

def _wm_set_running(context, state: bool):
    if not hasattr(bpy.types.WindowManager, _WM_FLAG_NAME):
        try:
            bpy.types.WindowManager.safe_qsd_running = BoolProperty(name="QSD Running", description="Internal runtime flag for Draw Quad Strip.", default=False)
        except Exception:
            pass
    try:
        setattr(context.window_manager, _WM_FLAG_NAME, bool(state))
    except Exception:
        pass

def _wm_get_stop_requested(context) -> bool:
    return bool(getattr(context.window_manager, _WM_STOP_FLAG_NAME, False))

def _wm_set_stop_requested(context, state: bool):
    if not hasattr(bpy.types.WindowManager, _WM_STOP_FLAG_NAME):
        try:
            bpy.types.WindowManager.safe_qsd_stop_requested = BoolProperty(name="QSD Stop Requested", description="Internal stop request flag for Draw Quad Strip.", default=False)
        except Exception:
            pass
    try:
        setattr(context.window_manager, _WM_STOP_FLAG_NAME, bool(state))
    except Exception:
        pass

def _find_view3d_override(context=None):
    ctx = context or bpy.context
    try:
        window = getattr(ctx, "window", None)
        area = getattr(ctx, "area", None)
        region = getattr(ctx, "region", None)
        if window and area and area.type == 'VIEW_3D':
            if region is None or region.type != 'WINDOW':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is not None:
                return {"window": window, "screen": window.screen, "area": area, "region": region}
    except Exception:
        pass

    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return None
    for window in wm.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is not None:
                return {"window": window, "screen": screen, "area": area, "region": region}
    return None

def _scene_sync_draw_toggle(context, state: bool):
    global _QSD_DRAW_TOGGLE_SYNC
    scn = getattr(context, "scene", None)
    if scn is None or not hasattr(scn, "qsd_draw_toggle"):
        return
    try:
        _QSD_DRAW_TOGGLE_SYNC = True
        scn.qsd_draw_toggle = bool(state)
    except Exception:
        pass
    finally:
        _QSD_DRAW_TOGGLE_SYNC = False

def _qsd_start_from_toggle(context=None) -> bool:
    override = _find_view3d_override(context)
    if override is None:
        if context is not None:
            _scene_sync_draw_toggle(context, False)
        else:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return False
    try:
        with bpy.context.temp_override(**override):
            result = bpy.ops.mesh.quad_strip_draw('INVOKE_DEFAULT')
        ok = 'RUNNING_MODAL' in result or 'FINISHED' in result
        if not ok:
            if context is not None:
                _scene_sync_draw_toggle(context, False)
            else:
                try:
                    bpy.context.scene.qsd_draw_toggle = False
                except Exception:
                    pass
        return ok
    except Exception:
        if context is not None:
            _scene_sync_draw_toggle(context, False)
        else:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return False

def _qsd_schedule_toggle_start():
    global _QSD_PENDING_TOGGLE_START
    if _QSD_PENDING_TOGGLE_START:
        return
    _QSD_PENDING_TOGGLE_START = True

    def _run():
        global _QSD_PENDING_TOGGLE_START
        _QSD_PENDING_TOGGLE_START = False
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            if isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SHUTTING_DOWN')):
                return None
        except Exception:
            return None
        try:
            ctx = bpy.context
            scn = getattr(ctx, "scene", None)
            if scn is None or not hasattr(scn, "qsd_draw_toggle"):
                return None
            if not bool(scn.qsd_draw_toggle):
                return None
            if _wm_get_running(ctx):
                return None
            _qsd_start_from_toggle(ctx)
        except Exception:
            try:
                bpy.context.scene.qsd_draw_toggle = False
            except Exception:
                pass
        return None

    try:
        bpy.app.timers.register(_run, first_interval=0.01)
    except Exception:
        _QSD_PENDING_TOGGLE_START = False

def _qsd_update_draw_toggle(self, context):
    global _QSD_DRAW_TOGGLE_SYNC
    if _QSD_DRAW_TOGGLE_SYNC:
        return

    # This toggle is visible in the unified N-panel, so commit its current
    # value synchronously before any modal start/stop side effect runs.
    try:
        from .. import common as _suite_common
        _suite_common.save_persistent_settings(context, force=False)
    except Exception:
        pass

    desired = bool(getattr(self, "qsd_draw_toggle", False))
    try:
        wm = getattr(context, 'window_manager', None)
        area = getattr(context, 'area', None)
        if desired and (wm is None or (area is not None and getattr(area, 'type', None) != 'VIEW_3D')):
            _QSD_DRAW_TOGGLE_SYNC = True
            try:
                setattr(self, "qsd_draw_toggle", False)
            finally:
                _QSD_DRAW_TOGGLE_SYNC = False
            return
    except Exception:
        return

    running = _wm_get_running(context)

    if desired:
        if not running:
            _qsd_schedule_toggle_start()
        return

    if running:
        _wm_set_stop_requested(context, True)
        _force_redraw_view3d()

def _force_redraw_view3d():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def _cm_to_bu(value: float) -> float:
    return float(value) * 0.01

def _bu_to_cm(value: float) -> float:
    return float(value) * 100.0

def _blf_size(font_id: int, size: int, dpi: int = 72):
    """Call blf.size with Blender-version compatible signature."""
    try:
        blf.size(font_id, size, dpi)
    except TypeError:
        blf.size(font_id, size)

def _cursor_warp(window, x, y):
    try:
        window.cursor_warp(int(x), int(y))
    except Exception:
        pass

def _get_region_under_mouse(area, x, y):
    """Mouse coordinates x, y are absolute window coordinates."""
    if not area: return None
    for region in area.regions:
        if region.type == 'WINDOW':
            # Check if mouse is within region bounds
            if (region.x <= x < region.x + region.width) and \
               (region.y <= y < region.y + region.height):
                return region
    return None

def _get_view_vector(rv3d):
    # Modified to take rv3d directly for Quad View support
    return (rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))).normalized()

def _get_mouse_ray(region, rv3d, mouse_xy):
    # Modified to take region and rv3d directly for Quad View support
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse_xy)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse_xy)
    return origin, direction

def _ray_cast_plane_intersection(ray_origin, ray_dir, plane_point, plane_normal):
    return geometry.intersect_line_plane(ray_origin, ray_origin + ray_dir * 10000.0, plane_point, plane_normal, False)

def _bezier_quad(p0, p1, p2, t):
    return (1-t)**2 * p0 + 2*(1-t)*t * p1 + t**2 * p2

class StripCalculator:
    @staticmethod
    def calc_ribbon_points(
        p_start, p_end, n_start, n_end, 
        w_start, w_end, 
        subdivisions, 
        prev_tangent, prev_side_vec
    ):
        dist = (p_end - p_start).length
        steps = max(1, subdivisions + 1)
        
        center_points = []
        t0 = prev_tangent if prev_tangent else ((p_end - p_start).normalized() if dist > 0 else Vector((1,0,0)))
        
        if subdivisions > 0:
            cp = p_start + t0 * (dist * 0.4)
            SAMPLE_RES = 32
            raw_bezier = [_bezier_quad(p_start, cp, p_end, i/SAMPLE_RES) for i in range(SAMPLE_RES+1)]
            lens = [0.0]
            for i in range(1, len(raw_bezier)):
                lens.append(lens[-1] + (raw_bezier[i] - raw_bezier[i-1]).length)
            total_len = lens[-1]
            
            for i in range(steps + 1):
                target_d = total_len * (i / steps)
                idx = 0
                for k in range(len(lens)-1):
                    if lens[k] <= target_d <= lens[k+1]:
                        idx = k
                        break
                span = lens[idx+1] - lens[idx]
                local_t = (target_d - lens[idx]) / span if span > 1e-8 else 0
                real_t = (idx + local_t) / SAMPLE_RES
                
                pos = _bezier_quad(p_start, cp, p_end, real_t)
                norm = n_start.lerp(n_end, real_t).normalized()
                center_points.append({'pos': pos, 'norm': norm, 't_fac': i/steps})
        else:
            for i in range(steps + 1):
                t = i / steps
                pos = p_start.lerp(p_end, t)
                norm = n_start.lerp(n_end, t).normalized()
                center_points.append({'pos': pos, 'norm': norm, 't_fac': t})

        results = []
        count = len(center_points)
        
        for i in range(count):
            pt = center_points[i]
            pos = pt['pos']
            norm = pt['norm']
            t_fac = pt['t_fac']
            
            if i == 0: tan_in = t0
            else: tan_in = (pos - center_points[i-1]['pos']).normalized()
                
            if i == count - 1: tan_out = tan_in 
            else:
                diff = center_points[i+1]['pos'] - pos
                if diff.length_squared > 1e-8: tan_out = diff.normalized()
                else: tan_out = tan_in

            avg_tan = (tan_in + tan_out).normalized()
            if avg_tan.length_squared < 1e-6: avg_tan = tan_in 
            
            side = norm.cross(avg_tan).normalized()
            eff_tangent = tan_out if i < count-1 else tan_in
            current_w = w_start * (1 - t_fac) + w_end * t_fac
            
            p_l = pos + side * (current_w * 0.5)
            p_r = pos - side * (current_w * 0.5)
            
            results.append({
                'l': p_l, 'r': p_r, 
                'pos': pos, 'norm': norm, 'tan': eff_tangent, 'side': side,
                'width': current_w
            })
            
        return results
