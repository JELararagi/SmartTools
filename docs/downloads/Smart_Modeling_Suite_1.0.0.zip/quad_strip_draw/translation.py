"""Localization helpers and bilingual UI text for Draw Quad Strip."""

import bpy

CONST_TEXT = {'ADDON_DESC': {'en': 'Tool to draw strip polygons with mouse operations. Launched from the N-panel.',
                'ja': 'マウス操作で帯状ポリゴンを描画するツール。Nパネルから起動します。'},
 'BTN_ADVANCED': {'en': 'Advanced...', 'ja': '詳細...'},
 'BTN_BOUNDARY_TOOLS': {'en': 'Boundary Trace...', 'ja': '境界トレース...'},
 'BTN_CLEAR_TARGET': {'en': 'Clear Target', 'ja': '解除'},
 'BTN_GUIDE_ACTIONS': {'en': 'Guide Actions...', 'ja': 'ガイド操作...'},
 'BTN_SELECTION_TOOLS': {'en': 'Selection Tools...', 'ja': '選択ツール...'},
 'BTN_SET_FROM_SELECTION': {'en': 'Set from Selection', 'ja': '選択から設定'},
 'BTN_START': {'en': 'Start Strip Drawing', 'ja': 'ストリップ描画を開始'},
 'BTN_USE_ACTIVE_TARGET': {'en': 'Use Active Mesh', 'ja': 'アクティブを使用'},
 'HUD_DISABLED': {'en': '(Disabled)', 'ja': '（無効）'},
 'HUD_FIELD_HELP': {'en': 'Quad Field Paint: LMB drag = draw | Backspace = undo | RMB/Enter = finish | ESC = cancel',
                    'ja': 'Quad Field Paint: 左ドラッグ = 描画 | Backspace = 1手戻す | 右クリック/Enter = 終了 | ESC = キャンセル'},
 'HUD_HELP': {'en': 'Alt:Width / Ctrl+Alt:Thick / Right Click:End Strip / Esc・Enter:Finish',
              'ja': 'Alt:幅 / Ctrl+Alt:厚み / 右クリック:一連終了 / Esc・Enter:終了'},
 'HUD_LOCKED': {'en': '(Locked)', 'ja': '（固定中）'},
 'HUD_OFF': {'en': 'OFF', 'ja': 'OFF'},
 'HUD_ON': {'en': 'ON', 'ja': 'ON'},
 'HUD_STATE_0': {'en': 'Click to Start', 'ja': 'クリックして始点を決定'},
 'HUD_STATE_1': {'en': 'Set Direction', 'ja': '方向を設定'},
 'HUD_STATE_2': {'en': 'Drawing...', 'ja': 'ストリップ描写中'},
 'LBL_TAB_NAME': {'en': 'Tab Category Name', 'ja': 'タブカテゴリー名'},
 'OP_BOUNDARY_TRACE_PAINT': {'en': 'Boundary Trace Paint (Drag)', 'ja': '境界トレース描画（ドラッグ）'},
 'OP_GRID_FILL_PROJECT': {'en': 'Grid Fill + Project', 'ja': 'グリッドフィル＋投影'},
 'OP_GRID_FILL_PROJECT_LABEL': {'en': 'Grid Fill and Project', 'ja': 'グリッドフィルして投影'},
 'OP_GUIDES_CLEAR': {'en': 'Clear', 'ja': 'クリア'},
 'OP_GUIDES_CLEAR_LABEL': {'en': 'Clear Guide Edges', 'ja': 'ガイド辺を解除'},
 'OP_GUIDES_SELECT': {'en': 'Select', 'ja': '選択'},
 'OP_GUIDES_SELECT_LABEL': {'en': 'Select Guide Edges', 'ja': 'ガイド辺を選択'},
 'OP_GUIDES_SET': {'en': 'Set', 'ja': '設定'},
 'OP_GUIDES_SET_LABEL': {'en': 'Set Guide Edges', 'ja': 'ガイド辺を登録'},
 'OP_LOOP_TRACE_EXTEND': {'en': 'Loop Trace Extend (Drag)', 'ja': 'ループトレース延長（ドラッグ）'},
 'OP_PROJECT_SELECTED': {'en': 'Project Selected', 'ja': '選択を投影'},
 'OP_PROJECT_SELECTED_LABEL': {'en': 'Project Selected to Target', 'ja': '選択をターゲットへ投影'},
 'OP_QUAD_FIELD_PAINT': {'en': 'Quad Field Paint (Drag)', 'ja': 'クアッドフィールド描画（ドラッグ）'},
 'OP_RELAX_PROJECT': {'en': 'Relax + Project', 'ja': '緩和＋投影'},
 'OP_RELAX_PROJECT_LABEL': {'en': 'Relax and Project Selected', 'ja': '選択を緩和して投影'},
 'OP_RETOPO_PEN': {'en': 'Retopo Strip Draw', 'ja': 'リトポ・ストリップ描画'},
 'PANEL_LABEL': {'en': 'Quad Retopo', 'ja': 'クアッドリトポ'},
 'PLANE_VIEW': {'en': 'View', 'ja': 'ビュー'},
 'PLANE_VIEW_DESC': {'en': 'Draw on a plane that faces the current viewport.', 'ja': '現在のビューに正対した平面を基準に描画します。'},
 'PLANE_X': {'en': 'X', 'ja': 'X'},
 'PLANE_X_DESC': {'en': 'Draw on the global YZ plane.', 'ja': 'グローバルYZ平面を基準に描画します。'},
 'PLANE_Y': {'en': 'Y', 'ja': 'Y'},
 'PLANE_Y_DESC': {'en': 'Draw on the global XZ plane.', 'ja': 'グローバルXZ平面を基準に描画します。'},
 'PLANE_Z': {'en': 'Z', 'ja': 'Z'},
 'PLANE_Z_DESC': {'en': 'Draw on the global XY plane.', 'ja': 'グローバルXY平面を基準に描画します。'},
 'POPUP_BOUNDARY_ADVANCED_TITLE': {'en': 'Boundary Trace Advanced', 'ja': '境界トレース 詳細'},
 'POPUP_BOUNDARY_TITLE': {'en': 'Boundary Trace', 'ja': '境界トレース'},
 'POPUP_FIELD_ADVANCED_TITLE': {'en': 'Quad Field Paint Advanced', 'ja': 'クアッドフィールド描画詳細'},
 'POPUP_FIELD_SETTINGS_TITLE': {'en': 'Quad Field Paint Settings', 'ja': 'クアッドフィールド描画設定'},
 'POPUP_FILL_TOOLS_TITLE': {'en': 'Fill / Relax / Project', 'ja': 'フィル / 緩和 / 投影'},
 'POPUP_GUIDES_TITLE': {'en': 'Guide Actions', 'ja': 'ガイド操作'},
 'POPUP_RETOPO_SETUP_TITLE': {'en': 'Retopo Setup', 'ja': 'リトポ設定'},
 'PREF_PANEL_DISPLAY': {'en': 'Panel Display', 'ja': 'パネル表示'},
 'PROP_FIELD_ALIGN_GUIDES': {'en': 'Align Guides', 'ja': 'ガイド整列'},
 'PROP_FIELD_AUTO_FILL_ON_FINISH': {'en': 'Auto Fill On Finish', 'ja': '終了時自動フィル'},
 'PROP_FIELD_AUTO_STITCH': {'en': 'Auto Stitch', 'ja': '自動ステッチ'},
 'PROP_FIELD_BOUNDARY_ONLY': {'en': 'Boundary Only', 'ja': '境界のみ'},
 'PROP_FIELD_BOUNDARY_STRENGTH': {'en': 'Boundary Strength', 'ja': '境界強度'},
 'PROP_FIELD_COLUMNS': {'en': 'Columns', 'ja': '列数'},
 'PROP_FIELD_CURVATURE_BOOST': {'en': 'Curvature Boost', 'ja': '曲率強調'},
 'PROP_FIELD_EDGE_SNAP_PX': {'en': 'Edge Snap (px)', 'ja': '辺スナップ (px)'},
 'PROP_FIELD_EDGE_SNAP_TO_EDGES': {'en': 'Edge Snap To Edges', 'ja': '辺へスナップ'},
 'PROP_FIELD_FILL_RELAX_ITERS': {'en': 'Fill Relax Iters', 'ja': 'フィル緩和反復'},
 'PROP_FIELD_FILL_RELAX_STRENGTH': {'en': 'Fill Relax Strength', 'ja': 'フィル緩和強度'},
 'PROP_FIELD_FILL_SPAN': {'en': 'Fill Span (0=Auto)', 'ja': 'フィル Span (0=自動)'},
 'PROP_FIELD_GUIDE_STRENGTH': {'en': 'Guide Strength', 'ja': 'ガイド強度'},
 'PROP_FIELD_INTERSECT_TOL': {'en': 'Intersect Tol (cm)', 'ja': '交差許容値 (cm)'},
 'PROP_FIELD_LIVE_MERGE': {'en': 'Live Merge', 'ja': 'ライブマージ'},
 'PROP_FIELD_LIVE_MERGE_DIST': {'en': 'Live Merge Dist (cm)', 'ja': 'ライブマージ距離 (cm)'},
 'PROP_FIELD_MERGE_DIST': {'en': 'Merge Distance (cm)', 'ja': 'マージ距離 (cm)'},
 'PROP_FIELD_SCREEN_ADAPTIVE': {'en': 'Adaptive', 'ja': '適応'},
 'PROP_FIELD_SILHOUETTE_BOOST': {'en': 'Silhouette Boost', 'ja': 'シルエット強調'},
 'PROP_FIELD_SPACING_PX': {'en': 'Spacing(px)', 'ja': '間隔(px)'},
 'PROP_FIELD_STOP_ON_INTERSECT': {'en': 'Stop On Intersect', 'ja': '交差で停止'},
 'PROP_FIELD_TANGENT_INERTIA': {'en': 'Tangent Inertia', 'ja': '接線慣性'},
 'PROP_FIELD_TRACE_BOUNDARY': {'en': 'Trace Boundary', 'ja': '境界追従'},
 'PROP_FIELD_WIDTH': {'en': 'Field Width (cm)', 'ja': 'フィールド幅 (cm)'},
 'PROP_GRID_FILL_SPAN': {'en': 'Span (0=Auto)', 'ja': 'Span (0=自動)'},
 'PROP_GUIDE_SELECT': {'en': 'Select', 'ja': '選択'},
 'PROP_PLANE': {'en': 'Draw Plane', 'ja': '描画基準面'},
 'PROP_RELAX_ITERATIONS': {'en': 'Iterations', 'ja': '反復回数'},
 'PROP_RELAX_STRENGTH': {'en': 'Strength', 'ja': '強さ'},
 'PROP_RETOPO_FRONTFACE_ONLY': {'en': 'Frontface Only', 'ja': '前面のみ'},
 'PROP_RETOPO_LOOP_FLIP': {'en': 'Flip', 'ja': '反転'},
 'PROP_RETOPO_LOOP_INERTIA': {'en': 'Boundary Inertia', 'ja': '境界慣性'},
 'PROP_RETOPO_LOOP_LOCK_STRENGTH': {'en': 'Boundary Lock', 'ja': '境界ロック'},
 'PROP_RETOPO_LOOP_MAKE_FACES': {'en': 'Make Faces', 'ja': '面を作成'},
 'PROP_RETOPO_LOOP_MERGE_DIST': {'en': 'Loop Merge Dist (cm)', 'ja': 'ループマージ距離 (cm)'},
 'PROP_RETOPO_LOOP_SNAP_PX': {'en': 'Boundary Snap (px)', 'ja': '境界スナップ (px)'},
 'PROP_RETOPO_LOOP_SPACING_PX': {'en': 'Spacing (px)', 'ja': '間隔 (px)'},
 'PROP_RETOPO_LOOP_STEP': {'en': 'Step (cm)', 'ja': 'ステップ (cm)'},
 'PROP_RETOPO_MODE': {'en': 'Retopo Mode', 'ja': 'リトポモード'},
 'PROP_RETOPO_OFFSET': {'en': 'Retopo Offset (cm)', 'ja': 'リトポオフセット (cm)'},
 'PROP_RETOPO_PROJECT_MAX_DIST': {'en': 'Project Max Dist (cm)', 'ja': '投影最大距離 (cm)'},
 'PROP_RETOPO_SNAP_RADIUS': {'en': 'Snap Radius (px)', 'ja': 'スナップ半径 (px)'},
 'PROP_RETOPO_TARGET': {'en': 'Retopo Target', 'ja': 'リトポターゲット'},
 'PROP_SEGMENTS': {'en': 'Extra Segments', 'ja': '追加分割'},
 'PROP_SNAP': {'en': 'Snap to Surface', 'ja': '表面にスナップ'},
 'PROP_SOLIDIFY': {'en': 'Solidify', 'ja': '厚み付け'},
 'PROP_STRIP_VERTEX_MERGE': {'en': 'Merge Nearby Vertices', 'ja': '近い頂点を結合'},
 'PROP_STRIP_VERTEX_MERGE_DIST': {'en': 'Vertex Merge Distance (cm)', 'ja': '頂点結合距離 (cm)'},
 'PROP_THICKNESS': {'en': 'Thickness (cm)', 'ja': '厚み (cm)'},
 'PROP_WIDTH': {'en': 'Width (cm)', 'ja': '幅 (cm)'},
 'REPORT_ACTIVE_NOT_USABLE_TARGET': {'en': 'The active object cannot be used as the Retopo Target. It must be a mesh '
                                           'with at least one face.',
                                     'ja': 'アクティブオブジェクトはリトポターゲットとして使えません。少なくとも1つ以上の面を持つメッシュである必要があります。'},
 'REPORT_ASSIGN_ACTIVE_TARGET_FAILED': {'en': 'Failed to assign the active mesh as the Retopo Target.',
                                        'ja': 'アクティブメッシュをリトポターゲットとして設定できませんでした。'},
 'REPORT_ASSIGN_TARGET_FAILED': {'en': 'Failed to assign the Retopo Target.', 'ja': 'リトポターゲットの設定に失敗しました。'},
 'REPORT_ENABLE_RETOPO_MODE': {'en': 'Enable Retopo Mode in the panel before using retopo tools.',
                               'ja': 'リトポツールを使う前に、パネルで Retopo Mode を有効にしてください。'},
 'REPORT_GRID_FILL_FAILED': {'en': 'Grid Fill failed: {message}', 'ja': 'Grid Fill に失敗しました: {message}'},
 'REPORT_INTERSECTION_GUARD': {'en': 'Intersection guard stopped the stroke. Increase Tol or disable Stop on Intersect '
                                     'if you intentionally need tighter overlap.',
                               'ja': '交差ガードがストロークを停止しました。意図的にもっと密接させたい場合は、Tol を上げるか Stop on Intersect を無効にしてください。'},
 'REPORT_NO_USABLE_TARGET_SELECTION': {'en': 'No usable mesh target was found in the current selection. Choose a mesh '
                                             'that has at least one face.',
                                       'ja': '現在の選択から有効なメッシュターゲットを見つけられませんでした。少なくとも1つ以上の面を持つメッシュを選択してください。'},
 'REPORT_RETOPO_TARGET_AUTOSET': {'en': 'Retopo Target was auto-set to: {name}', 'ja': 'リトポターゲットを自動設定しました: {name}'},
 'REPORT_RETOPO_TARGET_MISSING': {'en': 'Retopo Target is not set. Open Retopo Setup and choose the high-poly target, '
                                        'or select the target mesh together with the retopo mesh before starting.',
                                  'ja': 'リトポターゲットが未設定です。開始前に Retopo Setup '
                                        'でハイポリターゲットを指定するか、リトポ用メッシュと一緒にターゲットメッシュも選択してください。'},
 'REPORT_RUNTIME_ERROR': {'en': 'Draw Quad Strip: {message}', 'ja': 'Quad Retopo エラー: {message}'},
 'REPORT_SELECT_GRID_FILL_BOUNDARY': {'en': 'Select boundary edges for Grid Fill first. Open boundary loops work best.',
                                      'ja': '先に Grid Fill 用の境界辺を選択してください。開いた境界ループが最も適しています。'},
 'REPORT_SELECT_GUIDE_EDGES': {'en': 'Select one or more edges first, then run Set Guide Edges.',
                               'ja': '先に1本以上の辺を選択してから、「ガイド辺を登録」を実行してください。'},
 'REPORT_SELECT_MESH_FOR_RETOPO': {'en': 'Select a mesh object first. Retopo Strip Draw will switch that mesh to Edit '
                                         'Mode automatically.',
                                   'ja': '先にメッシュオブジェクトを選択してください。Retopo Strip Draw はそのメッシュを自動で編集モードへ切り替えます。'},
 'REPORT_SELECT_RELAX_VERTS': {'en': 'Select one or more vertices to relax before running this command.',
                               'ja': 'このコマンドを実行する前に、緩和したい頂点を1つ以上選択してください。'},
 'REPORT_TARGET_BUILD_FAILED': {'en': 'Failed to build Retopo Target data. The target mesh may be invalid, hidden by '
                                      'evaluation, or unsupported in the current state.',
                                'ja': 'リトポターゲットのデータ構築に失敗しました。ターゲットメッシュが無効、評価結果で取得不能、または現在の状態では未対応の可能性があります。'},
 'REPORT_TARGET_CLEARED': {'en': 'Retopo Target cleared.', 'ja': 'リトポターゲットを解除しました。'},
 'REPORT_TARGET_CLEAR_FAILED': {'en': 'Failed to clear the Retopo Target.', 'ja': 'リトポターゲットを解除できませんでした。'},
 'REPORT_TARGET_SET': {'en': 'Retopo Target set to: {name}', 'ja': 'リトポターゲットを設定しました: {name}'},
 'REPORT_TARGET_SET_ACTIVE': {'en': 'Retopo Target set to active mesh: {name}',
                              'ja': 'アクティブメッシュをリトポターゲットに設定しました: {name}'},
 'REPORT_VIEW3D_NOT_FOUND': {'en': 'A 3D View region could not be found. Run this tool from a visible 3D Viewport.',
                             'ja': '3Dビュー領域が見つかりませんでした。表示中の 3D ビューポートから実行してください。'},
 'TIP_FIELD_ALIGN_GUIDES': {'en': 'Use previously registered guide edges to steer the patch flow. This is useful when '
                                  'you already know the desired edge-loop direction and want the generated quads to '
                                  'align to it. Turn it off when the patch should follow only the painted stroke and '
                                  'surface cues.',
                            'ja': '事前に登録したガイド辺を使ってパッチの流れ方向を誘導します。狙ったエッジループ方向が決まっていて、生成されるクアッドをそこへ合わせたいときに便利です。描いたストロークと表面形状だけに従わせたい場合はOFFにしてください。'},
 'TIP_FIELD_AUTO_FILL_ON_FINISH': {'en': 'After painting, try to detect a closed boundary around the patch and fill it '
                                         'automatically. This is useful for turning an outlined area into a finished '
                                         'quad patch with one stroke. Leave it off when you only want to sketch '
                                         'guiding strips and fill the area manually later.',
                                   'ja': '描画後、パッチ周囲に閉じた境界が見つかれば自動で穴埋めを試みます。輪郭を囲った領域を、1回の操作で完成したクアッドパッチへ変えたいときに便利です。ガイド用の帯だけを描いて、穴埋めは後で手動で行いたい場合はOFFにしてください。'},
 'TIP_FIELD_AUTO_STITCH': {'en': 'Automatically merge or stitch the new patch into nearby existing topology when the '
                                 'stroke is finished. This is convenient for building connected retopo patches without '
                                 'manual cleanup after every stroke. Turn it off when you want to place test patches '
                                 'first and decide later what should be welded.',
                           'ja': 'ストローク終了時に、新しいパッチを近くの既存トポロジーへ自動でマージ / '
                                 'ステッチします。毎回手作業で後処理せず、接続されたリトポパッチを作りたいときに便利です。まずは仮配置して、後でどこを溶接するか決めたい場合はOFFにしてください。'},
 'TIP_FIELD_BOUNDARY_ONLY': {'en': 'Limit endpoint snapping to boundary vertices only. This helps when you want to '
                                   'extend existing open topology without accidentally snapping into interior '
                                   'vertices. Turn it off when interior points should also be valid snap targets.',
                             'ja': '端点スナップ先を境界頂点のみに制限します。既存の開いたトポロジーを延長したいときに、内部頂点へ誤って吸着しにくくなります。内部点も有効なスナップ先にしたい場合はOFFにしてください。'},
 'TIP_FIELD_BOUNDARY_STRENGTH': {'en': 'Strength of the boundary-direction influence when boundary tracing is active. '
                                       'Lower values keep more of your painted direction, while higher values lock the '
                                       'patch to the detected boundary flow. Raise it when loops should hug an '
                                       'existing outline closely.',
                                 'ja': '境界追従が有効なとき、境界方向の影響度を決めます。低い値では描いた方向をより残し、高い値では検出した境界フローへ強く沿います。既存アウトラインへぴったり沿わせたいループでは高めが有効です。'},
 'TIP_FIELD_COLUMNS': {'en': 'Number of quad columns created across the patch width. Increasing this adds density '
                             'across the width, which is useful for broader deformation areas. Keep it low for simple '
                             'blockout, then raise it only when extra edge flow is needed.',
                       'ja': 'パッチの幅方向に作られるクアッド列数です。増やすほど幅方向の密度が上がるため、変形の多い広い領域に向きます。大まかな下書きでは少なめ、追加のエッジフローが必要になった段階で増やすのが扱いやすいです。'},
 'TIP_FIELD_CURVATURE_BOOST': {'en': 'Extra density multiplier used on strongly curved surfaces. Increase this when '
                                     'the patch should preserve bends, folds, or pronounced shape transitions. Reduce '
                                     'it if the tool is producing more density than you need on smooth surfaces.',
                               'ja': '曲率の強い表面で追加される密度倍率です。曲がり、折れ、形状変化の大きい場所をしっかり残したいときに上げてください。滑らかな面で密度が増えすぎる場合は下げると扱いやすくなります。'},
 'TIP_FIELD_EDGE_SNAP_PX': {'en': 'Screen-space snapping radius for patch endpoints. Increase this when you want '
                                  'stroke ends to find nearby boundaries or target features more easily. Set it to 0 '
                                  'when you want fully free placement with no endpoint snapping assistance.',
                            'ja': 'パッチ端点を吸着させる画面上のスナップ半径です。ストロークの端を近くの境界や特徴点へ合わせやすくしたいときに上げてください。端点スナップ補助を使わず完全に自由配置したい場合は '
                                  '0 にします。'},
 'TIP_FIELD_EDGE_SNAP_TO_EDGES': {'en': 'Prefer snapping to the nearest edge segment instead of only to vertices. This '
                                        'is useful when the target boundary is sparsely tessellated and the exact '
                                        'vertex positions do not line up with the place you want to connect. Disable '
                                        'it if snapping feels too eager along long edges.',
                                  'ja': '頂点だけでなく、最も近い辺セグメントへの吸着を優先します。ターゲット境界の分割が粗く、目的の位置にちょうど頂点が無い場合に便利です。長い辺に対して吸着が強すぎると感じる場合はOFFにしてください。'},
 'TIP_FIELD_FILL_RELAX_ITERS': {'en': 'Number of relax passes applied after Auto Fill. More iterations produce a '
                                      'smoother and more even result, but may also soften the original shape more '
                                      'strongly. Start with a low value and increase it only when the fill looks too '
                                      'stiff or uneven.',
                                'ja': 'Auto Fill 後に行う Relax '
                                      'の反復回数です。増やすほど結果は滑らかで均一になりますが、元の形状もより強く丸められます。まずは少なめから始め、フィル結果が硬すぎる・ムラが強いと感じたときだけ増やしてください。'},
 'TIP_FIELD_FILL_RELAX_STRENGTH': {'en': 'Strength of each relax pass applied after Auto Fill. Higher values smooth '
                                         'the filled patch more aggressively, while lower values preserve the original '
                                         'placement more closely. Use small values when you want cleanup without '
                                         "losing the stroke's original intent.",
                                   'ja': 'Auto Fill 後に各 Relax '
                                         'パスがどれだけ強く効くかを決めます。高い値ほど積極的に平滑化し、低い値ほど元の配置を保ちます。描いた意図を残したまま軽く整えたい場合は小さめが向いています。'},
 'TIP_FIELD_FILL_SPAN': {'en': 'Span value passed to Grid Fill during Auto Fill. Use it when the automatically chosen '
                               'span is not giving a clean quad arrangement. 0 lets the add-on estimate a suitable '
                               'value, so keep it there until you specifically need manual control.',
                         'ja': 'Auto Fill 時に Grid Fill へ渡す Span 値です。自動推定の Span でクアッド配置がきれいにならないときに使います。0 '
                               'ではアドオンが適切な値を推定するため、必要性を感じるまでは 0 のままが分かりやすいです。'},
 'TIP_FIELD_GUIDE_STRENGTH': {'en': 'How strongly the stored guide edges influence the generated patch. Low values '
                                    'keep the stroke behavior natural, while high values force the patch to follow the '
                                    'guide direction more aggressively. Start around the middle and raise it only when '
                                    'the flow keeps drifting away from your guides.',
                              'ja': '保存済みガイド辺が生成パッチへどれだけ強く影響するかを決めます。低い値ではストローク本来の流れを残し、高い値ではガイド方向をより強く優先します。まずは中間付近から始め、流れがガイドから外れやすいときだけ上げるのが分かりやすいです。'},
 'TIP_FIELD_INTERSECT_TOL': {'en': 'Tolerance used to decide whether a newly painted quad patch is intersecting '
                                   'existing geometry, measured in centimeters.\n'
                                   'Increase it when tiny overlaps should also stop the stroke.\n'
                                   'Lower it when you want to continue painting through very tight areas.\n'
                                   'This value is converted internally to Blender units before the intersection test.',
                             'ja': '新しく描いたクアッドパッチが既存ジオメトリと交差しているかを判定する許容値で、単位は cm です。\n'
                                   'わずかな食い込みでも停止させたい場合は値を上げます。\n'
                                   '非常に狭い場所でも描き続けたい場合は値を下げてください。\n'
                                   'この値は交差判定前に内部で Blender 単位へ変換されます。'},
 'TIP_FIELD_LIVE_MERGE': {'en': 'Try to reuse nearby existing vertices while drawing instead of creating duplicates. '
                                'This keeps the result cleaner and reduces later merge-by-distance cleanup. Turn it '
                                'off when you want to draft a patch freely first and weld it only after checking the '
                                'shape.',
                          'ja': '描画中に重複頂点を増やさず、近くの既存頂点を再利用しようとします。結果が整理されやすく、後で距離マージする手間も減ります。まずは自由にパッチを下書きし、形を見てから溶接したい場合はOFFにしてください。'},
 'TIP_FIELD_LIVE_MERGE_DIST': {'en': 'Distance threshold, in centimeters, used by Live Merge while the stroke is still '
                                     'being created. A larger value connects more readily, and a smaller value keeps '
                                     'patch vertices independent until they are very close. Adjust this carefully '
                                     'while watching the preview so only intended connections are captured.',
                               'ja': 'ストローク生成中に Live Merge が使う距離しきい値で、単位は cm '
                                     'です。大きいほど接続されやすく、小さいほど非常に近づくまで独立した頂点のまま保たれます。プレビューを見ながら少しずつ調整し、意図した接続だけを拾うようにしてください。'},
 'TIP_FIELD_MERGE_DIST': {'en': 'Distance threshold used by Auto Stitch when deciding whether new vertices should weld '
                                'to existing ones. Larger values close gaps more aggressively, while smaller values '
                                'preserve separation. Increase it only enough to catch the intended neighbors, '
                                'otherwise unrelated vertices can merge together.',
                          'ja': 'Auto Stitch '
                                'が新規頂点を既存頂点へ溶接するか判定するときの距離しきい値です。大きいほど隙間を積極的に閉じ、小さいほど独立性を保ちます。狙った近傍だけを拾える程度に少しずつ上げるのが安全で、上げすぎると無関係な頂点まで結合されます。'},
 'TIP_FIELD_SCREEN_ADAPTIVE': {'en': 'Automatically vary sampling density using what is visible on screen. When '
                                     'enabled, silhouettes and curved areas receive denser sampling, which helps '
                                     'preserve shape where it matters most. Turn it off when you want fully '
                                     'predictable, uniform spacing along the whole stroke.',
                               'ja': '画面上で見えている形状に応じてサンプリング密度を自動調整します。有効にすると、シルエットや曲面が強い場所でより細かくサンプリングされ、重要な形状を保ちやすくなります。ストローク全体で均一かつ予測しやすい間隔が欲しい場合はOFFにしてください。'},
 'TIP_FIELD_SILHOUETTE_BOOST': {'en': 'Extra density multiplier used near silhouette areas. Raise this when the patch '
                                      'needs to follow an outer contour more faithfully, especially around limbs, '
                                      'fingers, or profile edges. Lower values keep the result lighter and more even.',
                                'ja': 'シルエット付近で追加される密度倍率です。手足、指、外形の輪郭線など、外周の形をより忠実に追いたいときに上げてください。低い値にすると、結果はより軽く均一になります。'},
 'TIP_FIELD_SPACING_PX': {'en': 'Screen-space spacing used while sampling the stroke. Smaller values sample the mouse '
                                'path more densely and generate more geometry, while larger values produce a lighter '
                                'and simpler patch. Use small spacing for tight curves and larger spacing for long '
                                'smooth strokes.',
                          'ja': 'ストロークをサンプリングするときの画面上の間隔です。小さい値ほどマウス軌跡を細かく取り、生成ジオメトリも増えます。大きい値ほど軽くシンプルなパッチになります。きつい曲線では小さめ、長く滑らかなストロークでは大きめが向いています。'},
 'TIP_FIELD_STOP_ON_INTERSECT': {'en': 'Stop adding new rings when the tool detects likely self-intersection or '
                                       'conflicting topology in the local area. This protects the patch from folding '
                                       'into itself during dense strokes. Disable it only when you deliberately need '
                                       'to force the tool through cramped regions.',
                                 'ja': '局所的な自己交差や衝突しそうなトポロジーを検出したら、新しいリング生成を停止します。密なストロークでパッチが自分自身へ折り込むのを防ぐ安全装置です。狭い領域へ意図的に押し込みたい特別な場合だけOFFにしてください。'},
 'TIP_FIELD_TANGENT_INERTIA': {'en': 'Smoothing applied to the field tangent along the stroke. Higher values reduce '
                                     'jitter and sudden twists, but make the patch react more slowly to fast '
                                     'directional changes. Use medium values for most work, and lower it only when you '
                                     'need very sharp steering.',
                               'ja': 'ストロークに沿ったフィールド接線の平滑化量です。高い値ではジッターや急なねじれを抑えますが、方向変化への反応は遅くなります。通常は中間程度が扱いやすく、鋭い方向転換が必要なときだけ下げてください。'},
 'TIP_FIELD_TRACE_BOUNDARY': {'en': 'When the stroke approaches an existing boundary, rotate the generated flow so it '
                                    'follows that boundary direction. This helps extend loops cleanly along openings '
                                    'and cut edges. Turn it off if the patch should follow only the freehand stroke '
                                    'direction.',
                              'ja': 'ストロークが既存境界に近づいたとき、生成フローをその境界方向へ合わせます。開口部や切れ目に沿ってループをきれいに延長したいときに役立ちます。手描きの方向だけを優先したい場合はOFFにしてください。'},
 'TIP_FIELD_WIDTH': {'en': 'Overall width of the quad patch generated by Quad Field Paint, measured in centimeters.\n'
                           'This controls how wide the painted patch spreads to the left and right of your stroke.\n'
                           'Use a smaller value for narrow detail strips and a larger value for wider surface panels.\n'
                           'This value is converted internally to Blender units, so the centimeter label now matches '
                           'the actual result.',
                     'ja': 'Quad Field Paint が生成するクアッドパッチ全体の幅で、単位は cm です。\n'
                           'ストロークの左右へ、どのくらい広くパッチを展開するかを決めます。\n'
                           '細いディテール帯を作るなら小さめ、広い面パネルを一気に作るなら大きめに設定します。\n'
                           'この値は内部で Blender 単位へ変換されるため、cm 表示と実際の結果が一致します。'},
 'TIP_GRID_FILL_SPAN': {'en': "Span value passed to Blender's Grid Fill. 0 lets the operator estimate a suitable span "
                              'automatically from the selected boundary, which is usually the easiest starting point. '
                              'Set a manual value only when the default fill layout twists or distributes quads in an '
                              'undesirable way.',
                        'ja': 'Blender の Grid Fill に渡す Span 値です。0 '
                              'では選択境界から適切な値を自動推定するため、まずはそのまま使うのが最も簡単です。既定レイアウトでクアッドの並びがねじれる、または望まない分布になる場合だけ手動値を指定してください。'},
 'TIP_GUIDE_SELECT': {'en': 'Choose whether the stored guide edges should become selected or deselected when this '
                            'operator runs. This is helpful when you want to review guide placement visually, or clear '
                            'their selection state after checking them. It does not delete the guide flags themselves.',
                      'ja': 'このオペレーター実行時に、保存済みガイド辺を選択するか解除するかを決めます。ガイド配置を目で確認したいときや、確認後に選択状態だけ外したいときに便利です。ガイドフラグそのものを削除するわけではありません。'},
 'TIP_OP_BOUNDARY_TRACE_PAINT': {'en': 'Paint along an existing boundary to extend topology.\n'
                                       'This tool reads the nearby boundary direction while you drag, then grows new '
                                       'topology that follows that flow.\n'
                                       'Use it to continue openings, borders, sleeves, panel seams, or other '
                                       'already-established mesh boundaries.',
                                 'ja': '既存境界に沿ってトポロジーを延長する描画ツールです。\n'
                                       'ドラッグ中に近くの境界方向を読み取り、その流れに沿って新しいトポロジーを伸ばします。\n'
                                       '開口部、境界線、袖口、パネルの継ぎ目など、既に決まっているメッシュ境界をそのまま延長したいときに使います。'},
 'TIP_OP_CLEAR_TARGET': {'en': 'Clear the current Retopo Target reference. Use this when the stored target points to '
                               'the wrong object and you want to re-pick it cleanly.',
                         'ja': '現在のリトポターゲット参照を解除します。保存されているターゲットが違うオブジェクトを指しているときに、一度まっさらに戻して選び直したい場合に使います。'},
 'TIP_OP_GRID_FILL_PROJECT': {'en': 'Run Grid Fill on the selected boundary edges, then project the result to the '
                                    'Retopo Target.\n'
                                    'Use this to close retopo holes and immediately conform the new topology to the '
                                    'target surface.',
                              'ja': '選択した境界辺に Grid Fill を行い、その結果を Retopo Target に投影します。\n'
                                    '穴埋め後すぐに新規トポロジーをターゲット表面へ沿わせたいときに使います。'},
 'TIP_OP_GUIDES_CLEAR': {'en': 'Clear guide flags from the selected edges.\n'
                               'If nothing is selected, all guide edges in the edit mesh are cleared.',
                         'ja': '選択中の辺からガイド指定を解除します。\n何も選択していない場合は、編集メッシュ内の全ガイドを解除します。'},
 'TIP_OP_GUIDES_SELECT': {'en': 'Select all edges currently marked as guides.\n'
                                'Useful when you want to review, edit, or clear existing guide paths.',
                          'ja': '現在ガイドとして登録されている辺を選択します。\n既存ガイドの確認、編集、解除を行いたいときに便利です。'},
 'TIP_OP_GUIDES_SET': {'en': 'Mark the currently selected edges as guide edges.\n'
                             'Guide edges are used by Quad Field Paint to bias the flow direction.',
                       'ja': '現在選択中の辺をガイド辺として登録します。\n登録したガイドは Quad Field Paint の流れ方向の誘導に使われます。'},
 'TIP_OP_LOOP_TRACE_EXTEND': {'en': 'Drag-based loop extension from the selected open boundary.\n'
                                    'The operator repeatedly advances the boundary by the configured step length, '
                                    'projects the result to the target, and can stitch / make faces as it grows.\n'
                                    'Use this when you already have a clean starting border and want to push it '
                                    'forward quickly.',
                              'ja': '選択中の開いた境界から、ドラッグでループを延長します。\n'
                                    '設定したステップ長ごとに境界を前進させ、ターゲットへ投影しながら、必要に応じて面作成やマージも行います。\n'
                                    'きれいな開始境界が既にあり、それをまとめて前方へ押し出したい場合に便利です。'},
 'TIP_OP_PROJECT_SELECTED': {'en': 'Project the selected vertices onto the Retopo Target.\n'
                                   'Each selected vertex is moved to the closest point on the target surface, then '
                                   'offset along the target normal.',
                             'ja': '選択頂点を Retopo Target 上へ投影します。\n各頂点を最寄り表面へ移動し、その後ターゲット法線方向にオフセットします。'},
 'TIP_OP_QUAD_FIELD_PAINT': {'en': 'Paint a quad patch over the target surface.\n'
                                   'How it works:\n'
                                   '- The stroke is sampled along the surface.\n'
                                   '- A multi-column quad strip is generated from the sampled path.\n'
                                   '- Optional guide alignment, live merge, edge snap, boundary tracing, and auto fill '
                                   'can refine the result.\n'
                                   'Use this for broad retopo areas that are too large to build one edge loop at a '
                                   'time.',
                             'ja': 'ターゲット表面上へクアッドパッチを描画します。\n'
                                   '動作の流れ:\n'
                                   '- ストロークを表面に沿ってサンプリングする\n'
                                   '- その経路から複数列のクアッド帯を生成する\n'
                                   '- 必要に応じて、ガイド整列、ライブマージ、辺スナップ、境界追従、自動フィルで仕上げる\n'
                                   '1本ずつループを作るには広すぎるリトポ領域を、まとめて作りたいときに向いています。'},
 'TIP_OP_RELAX_PROJECT_SELECTED': {'en': 'Relax the selected vertices, then project them back to the Retopo Target.\n'
                                         'Useful for evening out spacing while keeping the result adhered to the '
                                         'highpoly surface.',
                                   'ja': '選択頂点を緩和してから Retopo Target 上へ再投影します。\n表面への追従を保ちながら、頂点間隔を整えたいときに便利です。'},
 'TIP_OP_RETOPO_PEN': {'en': 'Legacy compatibility entry for retopo drawing.\n'
                             'This command routes to the main Strip Draw operator while Retopo Mode is enabled, so it '
                             'uses the same surface projection workflow as the main strip tool.\n'
                             'For day-to-day work, start the main Strip Draw toggle and enable Retopo Mode when you '
                             'need projection.',
                       'ja': '旧リトポ描画コマンドとの互換性用エントリーです。\n'
                             'Retopo Mode が有効な状態で、このコマンドはメインの Strip Draw '
                             'オペレーターへ処理を渡します。つまり、メインのストリップ描画と同じ表面投影ワークフローで動作します。\n'
                             '通常作業では、メインの Strip Draw トグルを開始し、必要なときだけ Retopo Mode を有効にする使い方をおすすめします。'},
 'TIP_OP_SET_TARGET_FROM_SELECTION': {'en': 'Set the Retopo Target from the current selection. In Edit Mode, this '
                                            'looks for another selected mesh first, then falls back to the active mesh '
                                            'if it has surface polygons. Use this when the target picker feels '
                                            'ambiguous.',
                                      'ja': '現在の選択状態からリトポターゲットを設定します。編集モードでは、まず別の選択メッシュを探し、無ければ面を持つアクティブメッシュを使います。ターゲット指定が分かりづらいときに使ってください。'},
 'TIP_OP_START': {'en': 'Start the main strip drawing tool.\n'
                        'Workflow:\n'
                        '1) Click once to place the strip start.\n'
                        '2) Move the mouse to choose the direction.\n'
                        '3) Click again to lock the direction and preview the strip.\n'
                        '4) Keep clicking to add more strip segments.\n'
                        'Controls while running:\n'
                        '- Alt + Mouse Move: change strip width\n'
                        '- Ctrl + Alt + Mouse Move: change thickness when Solidify is enabled\n'
                        '- Right Click: finish only the current strip and immediately prepare for the next one\n'
                        '- Esc / Enter: finish the whole tool session and generate UVs\n'
                        'Use Surface Snap for drawing directly over an existing mesh.',
                  'ja': 'メインのストリップ描画ツールを開始します。\n'
                        '基本手順:\n'
                        '1) 1回クリックして始点を置く\n'
                        '2) マウス移動で進行方向を決める\n'
                        '3) もう一度クリックして方向を確定し、ストリップをプレビューする\n'
                        '4) 以後はクリックごとにセグメントを追加する\n'
                        '実行中の操作:\n'
                        '- Alt + マウス移動: ストリップ幅を変更\n'
                        '- Ctrl + Alt + マウス移動: Solidify 有効時に厚みを変更\n'
                        '- 右クリック: 現在の一連のストリップだけ終了し、次の描画入力に戻る\n'
                        '- Esc / Enter: ツール全体を終了して UV を生成\n'
                        '既存メッシュ表面へ直接描く場合は Surface Snap を有効にしてください。'},
 'TIP_OP_USE_ACTIVE_TARGET': {'en': 'Use the active mesh as the Retopo Target. This is useful when you want to draw '
                                    'directly on the current mesh or when only one mesh exists in the scene.',
                              'ja': 'アクティブメッシュをリトポターゲットとして使います。現在のメッシュ上に直接描きたいときや、シーン内に1つしかメッシュが無いときに便利です。'},
 'TIP_PLANE': {'en': 'Reference plane used when Surface Snap is off or when no surface is hit.\n'
                     'View follows the current viewport. X / Y / Z use global axis planes.',
               'ja': 'Surface Snap がOFF、またはヒット面がない場合に使う基準平面です。\nView は現在のビュー基準、X / Y / Z はグローバル軸平面を使います。'},
 'TIP_POPUP_BOUNDARY': {'en': 'Open Boundary Trace tools in a popup. From here you can launch drag-based tracing tools '
                              'and adjust the main tracing behavior without keeping a large settings block visible at '
                              'all times.',
                        'ja': '境界トレース系ツールをポップアップで開きます。ここからドラッグ式トレースツールを起動し、常時大きな設定欄を表示せずに基本トレース挙動を調整できます。'},
 'TIP_POPUP_BOUNDARY_ADVANCED': {'en': 'Open the advanced Boundary Trace controls in a popup. Use these when you need '
                                       'to tune snapping range, boundary lock strength, or tracing inertia.',
                                 'ja': '境界トレースの詳細設定をポップアップで開きます。スナップ範囲、境界ロック強度、追従慣性を細かく調整したいときに使います。'},
 'TIP_POPUP_FIELD_ADVANCED': {'en': 'Open the advanced Quad Field Paint controls in a popup. Use these only when you '
                                    'need detailed control over edge snapping, boundary following, live merge, or '
                                    'intersection stopping.',
                              'ja': 'クアッドフィールド描画の詳細設定をポップアップで開きます。辺スナップ、境界追従、ライブマージ、交差停止を細かく調整したいときだけ使ってください。'},
 'TIP_POPUP_FIELD_SETTINGS': {'en': 'Open the Quad Field Paint settings in a popup. Use this when you want to adjust '
                                    'patch width, density, flow guidance, stitch behavior, and finish options without '
                                    'filling the sidebar with controls.',
                              'ja': 'クアッドフィールド描画の設定をポップアップで開きます。サイドバーを項目で埋めずに、パッチ幅、密度、流れの誘導、ステッチ、仕上げの挙動を調整したいときに使います。'},
 'TIP_POPUP_FILL_TOOLS': {'en': 'Open the selection-based retopo tools in a popup. These commands work on the current '
                                'Edit Mode selection and help you project, relax, or rebuild selected topology.',
                          'ja': '選択ベースのリトポ補助ツールをポップアップで開きます。これらのコマンドは編集モードで現在選択中の要素に対して働き、投影、緩和、再構築を行います。'},
 'TIP_POPUP_GUIDES': {'en': 'Open guide actions in a compact popup. From here you can register selected edges as '
                            'guides, clear guide flags, or reselect saved guides.',
                      'ja': 'ガイド操作をコンパクトなポップアップで開きます。ここから、選択中の辺をガイド登録したり、ガイド指定を解除したり、保存済みガイドを再選択できます。'},
 'TIP_POPUP_RETOPO_SETUP': {'en': 'Open the shared retopo settings in a popup.\n'
                                  'Use this window to choose the target mesh that receives projection, then adjust '
                                  'offset, max projection distance, and frontface-only behavior.\n'
                                  'Open this first when retopo tools are not snapping to the expected surface.',
                            'ja': '共通のリトポ設定をポップアップで開きます。\n'
                                  'この画面では、投影先となるターゲットメッシュの指定と、オフセット、最大投影距離、前面のみ判定をまとめて調整できます。\n'
                                  'リトポ系ツールが期待した表面に吸着しないときは、まずここを確認してください。'},
 'TIP_PREF_CATEGORY': {'en': 'Change the sidebar tab name used by this add-on in the 3D View.\n'
                             'Use this when you want to place Draw Quad Strip under your own custom tool tab.\n'
                             'After changing it, the panel is re-registered so the new tab name appears immediately.',
                       'ja': '3Dビューのサイドバーで、このアドオンが表示されるタブ名を変更します。\n'
                             '自分のツールタブへ Draw Quad Strip をまとめたいときに使います。\n'
                             '変更後はパネルを再登録するため、新しいタブ名がすぐ反映されます。'},
 'TIP_RELAX_ITERATIONS': {'en': 'Number of relax passes performed before projection. More iterations even out spacing '
                                'more strongly, but can also drift the selection farther from its original shape '
                                'before it is projected back. Use a low value for gentle cleanup and a higher value '
                                'when the selected topology is visibly uneven.',
                          'ja': '投影前に行う Relax '
                                'の反復回数です。増やすほど頂点間隔はより均一になりますが、再投影前に元の形状から離れやすくもなります。軽い整えには少なめ、選択トポロジーのムラが目立つ場合は多めを使ってください。'},
 'TIP_RELAX_STRENGTH': {'en': 'How strongly each relax pass moves selected vertices toward the average of their '
                              'neighbors. Lower values preserve the current shape more closely, while higher values '
                              'smooth more aggressively. Start low if you are unsure, then raise it only when the '
                              'result still looks uneven after projection.',
                        'ja': '各 Relax '
                              'パスで選択頂点を周囲平均へどれだけ強く寄せるかを決めます。低い値では現在形状を残しやすく、高い値ではより積極的に平滑化されます。迷う場合は低めから始め、再投影後もムラが残るときだけ上げてください。'},
 'TIP_RETOPO_FRONTFACE_ONLY': {'en': 'Prefer front-facing hits when snapping or projecting.\n'
                                     'This helps reduce backface penetration and unwanted projection through the '
                                     'model.',
                               'ja': 'スナップや投影時に前面ヒットを優先します。\n背面貫通や、モデルを突き抜けた不要な投影を減らすのに役立ちます。'},
 'TIP_RETOPO_LOOP_FLIP': {'en': 'Reverse the outward direction used when extending the selected boundary. Use this '
                                'when the preview is growing on the wrong side of the loop. It is simply a direction '
                                'switch and does not change the selected source edges themselves.',
                          'ja': '選択境界を延長するときの外向き方向を反転します。プレビューがループの逆側へ伸びてしまうときに使ってください。これは方向の切り替えであり、選択元の辺そのものを変更するわけではありません。'},
 'TIP_RETOPO_LOOP_INERTIA': {'en': 'Smoothing applied to the tracked boundary tangent over time. Higher values '
                                   'suppress jitter and small hand tremors, but respond more slowly to sharp turns. '
                                   'Lower it when the boundary direction must react instantly, and raise it when you '
                                   'want calmer, cleaner tracing.',
                             'ja': '追跡中の境界接線に時間方向でかける平滑化量です。高い値ではジッターや手ブレを抑えますが、急な方向転換への反応は遅くなります。境界方向へ即座に反応したいときは下げ、より穏やかでクリーンなトレースが欲しいときは上げてください。'},
 'TIP_RETOPO_LOOP_LOCK_STRENGTH': {'en': 'How strongly mouse motion is locked to the detected boundary direction. Low '
                                         'values allow freer steering, while high values make the trace cling to the '
                                         'boundary and feel steadier. Raise it when you want stable loop growth, '
                                         'especially along long existing borders.',
                                   'ja': 'マウス移動を検出した境界方向へどれだけ強く固定するかを決めます。低い値では自由に操舵しやすく、高い値では境界へ強く沿って安定した挙動になります。特に長い既存境界に沿って安定してループを伸ばしたいときに上げると効果的です。'},
 'TIP_RETOPO_LOOP_MAKE_FACES': {'en': 'Create quad faces between the previous boundary and each newly extended '
                                      'boundary while tracing. Turn this off if you want to build only guide edges '
                                      'first and generate faces later. For normal retopo extension work, leaving it on '
                                      'is usually the most convenient choice.',
                                'ja': 'トレース中、前の境界と新しく延長した境界の間にクアッド面を作成します。まずはガイド辺だけを作り、面は後で張りたい場合はOFFにしてください。通常のリトポ延長作業では、ONのままが最も扱いやすいです。'},
 'TIP_RETOPO_LOOP_MERGE_DIST': {'en': 'Optional merge distance applied after each loop extension step. Use it to weld '
                                      'the newly extended result into nearby existing topology automatically. Set it '
                                      'to 0 when you want to keep every new step separate until the tracing is '
                                      'finished.',
                                'ja': '各ループ延長ステップの後に適用する任意のマージ距離です。新しく延長した結果を、近くの既存トポロジーへ自動溶接したいときに使います。トレース完了まで各ステップを独立のまま保ちたい場合は '
                                      '0 にしてください。'},
 'TIP_RETOPO_LOOP_SNAP_PX': {'en': 'Screen-space snapping radius used while Boundary Trace looks for nearby boundary '
                                   'features. Increase it when the target boundary is hard to catch, and lower it when '
                                   'the tool keeps grabbing neighboring structures you did not intend to follow. '
                                   'Setting it to 0 disables this snapping helper entirely.',
                             'ja': 'Boundary Trace '
                                   'が近くの境界特徴を探すときに使う画面上のスナップ半径です。狙った境界を捕まえにくい場合は上げ、意図しない隣接構造まで拾ってしまう場合は下げてください。0 '
                                   'にすると、このスナップ補助を完全に無効化できます。'},
 'TIP_RETOPO_LOOP_SPACING_PX': {'en': 'How much mouse travel is required before the next loop extension step is '
                                      'created. A small value reacts quickly and generates more steps, while a large '
                                      'value spaces the new rings farther apart. Lower it for careful tracing and '
                                      'raise it for long smooth sweeps.',
                                'ja': '次のループ延長ステップが作られるまでに必要なマウス移動量です。小さい値では反応が速くステップ数も増え、大きい値では新しいリング間隔が広くなります。慎重なトレースでは小さめ、長く滑らかな延長では大きめが向いています。'},
 'TIP_RETOPO_LOOP_STEP': {'en': 'World-space distance, in centimeters, added on each boundary extension step. Larger '
                                'values advance the loop farther with each sampled step, which is faster but rougher. '
                                'Smaller values give you tighter control and a cleaner fit around detailed shapes.',
                          'ja': '境界延長の1ステップごとに追加されるワールド空間距離で、単位は cm '
                                'です。大きい値では1回のステップで大きく進むため速いですが荒くなり、小さい値では細かく制御しやすくディテールの多い形状にもきれいに沿います。'},
 'TIP_RETOPO_MODE': {'en': 'Enable the Ultimate Retopo toolset in the panel.\n'
                           'When enabled, the add-on exposes the target projection, guide, field paint, and boundary '
                           'tracing tools.',
                     'ja': 'パネル内の Ultimate Retopo ツール群を有効にします。\n有効化すると、ターゲット投影、ガイド、フィールド描画、境界トレース系ツールが使用可能になります。'},
 'TIP_RETOPO_OFFSET': {'en': 'Distance to offset projected results along the target surface normal.\n'
                             'Use a small positive value to keep retopo geometry slightly above the target surface.',
                       'ja': '投影後にターゲット法線方向へずらす距離です。\n小さな正の値を使うと、リトポメッシュをターゲット表面からわずかに浮かせられます。'},
 'TIP_RETOPO_PROJECT_MAX_DIST': {'en': 'Maximum allowed distance for projection.\n'
                                       '0 means unlimited.\n'
                                       'If the nearest target point is farther than this value, the projection is '
                                       'skipped.',
                                 'ja': '投影を許可する最大距離です。\n0 は無制限です。\n最寄りターゲット点がこの値より遠い場合、その投影をスキップします。'},
 'TIP_RETOPO_SNAP_RADIUS': {'en': 'Screen-space pickup radius used by Start Retopo Pen while choosing an anchor on the '
                                  'target surface.\n'
                                  'Larger values make it easier to pick nearby existing vertices as strip anchors '
                                  'before projection.',
                            'ja': 'Start Retopo Pen がターゲット表面上のアンカー位置を決めるときに使う、画面空間の拾い範囲です。\n'
                                  '値を大きくすると、投影前に近くの既存頂点をストリップの基点として拾いやすくなります。'},
 'TIP_RETOPO_TARGET': {'en': 'High-poly or reference mesh used as the projection target for retopo tools.\n'
                             'Vertices created or projected by retopo operators are snapped to this object.\n'
                             'A common setup is: low-poly mesh in Edit Mode + high-poly mesh assigned here.',
                       'ja': 'リトポ系ツールの投影先として使うハイポリ、または参照用メッシュです。\n'
                             'リトポ系オペレーターで生成・投影される頂点は、このオブジェクトへ吸着します。\n'
                             '一般的な使い方は「ローポリ作業メッシュを編集モード」「ハイポリをここへ指定」です。'},
 'TIP_SEGMENTS': {'en': 'Interpolation amount between the previous point and the next point.\n'
                        '0 creates a straight connection.\n'
                        'Higher values insert extra subdivisions and smooth the strip with a curved path.',
                  'ja': '前のポイントと次のポイントの間に入れる補間量です。\n0 は直線接続になります。\n値を上げるほど分割が増え、曲線的に滑らかなストリップになります。'},
 'TIP_SNAP': {'en': 'Snap the drawing cursor to the surface under the mouse.\n'
                    'Useful for retopo-like placement, surface detailing, and drawing directly over existing meshes.',
              'ja': 'マウス下の表面へ描画位置を吸着させます。\nリトポ配置、表面ディテール作成、既存メッシュの上への直接描画に便利です。'},
 'TIP_SOLIDIFY': {'en': 'Create solid thickness instead of a flat ribbon.\n'
                        'Off: generate a single quad strip.\n'
                        'On: generate a closed box-like strip with thickness.',
                  'ja': '平面リボンではなく、厚みのある形状として生成します。\nOFF: 1枚の帯ポリゴンを生成\nON: 厚み付きの閉じた箱状ストリップを生成'},
 'TIP_STRIP_VERTEX_MERGE': {'en': 'When enabled, flat strip drawing reuses nearby existing vertices instead of always '
                                  'creating new ones.\n'
                                  'The preview updates live while drawing, while changing width, and while adjusting '
                                  'the merge distance in the N-panel.\n'
                                  'This option is forced off whenever Solidify is enabled.',
                            'ja': '有効にすると、平面ストリップ描画時に毎回新規頂点を作る代わりに、近くの既存頂点を再利用して結合します。\n'
                                  '描画中、幅調整中、Nパネルで結合距離を変更したときも、プレビューへリアルタイム反映されます。\n'
                                  'Solidify を有効にして厚み付きにした場合、この機能は強制的にOFF扱いになります。'},
 'TIP_STRIP_VERTEX_MERGE_DIST': {'en': 'Maximum world-space distance used when deciding whether a previewed strip '
                                       'vertex should snap to an existing vertex.\n'
                                       'Changing this value while the tool is running immediately updates the preview, '
                                       'so you can see whether the strip will stitch or stay separate before you click '
                                       'to confirm.',
                                 'ja': 'プレビュー中のストリップ頂点を既存頂点へ吸着させるかどうかを判定する、ワールド空間での最大距離です。\n'
                                       'ツール実行中にこの値を変えるとプレビューへ即時反映され、クリック確定前に結合されるか独立したままかを確認できます。'},
 'TIP_THICKNESS': {'en': 'Thickness applied when Solidify is enabled.\n'
                         'Use this to turn the ribbon into box-like geometry instead of a single polygon strip.\n'
                         'You can also tweak it during drawing with Ctrl + Alt + mouse move.',
                   'ja': 'Solidify が有効なときに使われる厚みです。\n板状ストリップを箱形状の立体ジオメトリとして生成できます。\n描画中に Ctrl + Alt + マウス移動でも調整できます。'},
 'TIP_WIDTH': {'en': 'Base width of the strip.\n'
                     'This value defines the initial ribbon width for newly added segments.\n'
                     'You can also tweak it interactively during drawing with Alt + mouse move.',
               'ja': 'ストリップの基準幅です。\n新しく追加するセグメントの初期幅を決めます。\n描画中に Alt + マウス移動でもインタラクティブに調整できます。'},
 'UI_ENABLE': {'en': 'Enable', 'ja': '有効'},
 'UI_FRONTFACE_ONLY': {'en': 'Frontface Only', 'ja': '前面のみ'},
 'UI_GROUP_BOUNDARY_CORE': {'en': 'Basic Trace Settings', 'ja': '基本トレース設定'},
 'UI_GROUP_FIELD_FINISH': {'en': 'Stitch / Finish', 'ja': 'ステッチ / 仕上げ'},
 'UI_GROUP_FIELD_GUIDANCE': {'en': 'Flow Guidance', 'ja': '流れの誘導'},
 'UI_GROUP_FIELD_SHAPE': {'en': 'Patch Shape', 'ja': 'パッチ形状'},
 'UI_GROUP_RETOPO_ACTIONS': {'en': 'Retopo Tools', 'ja': 'リトポツール'},
 'UI_LABEL_STATUS_RUNNING': {'en': 'Drawing is currently active in the viewport.', 'ja': '現在ビューポート上で描画ツールが動作中です。'},
 'UI_MAX_DIST': {'en': 'Max Projection Distance', 'ja': '最大投影距離'},
 'UI_OFFSET': {'en': 'Offset (cm)', 'ja': 'オフセット (cm)'},
 'UI_SECTION_BASIC_STRIP': {'en': 'Basic Strip Settings', 'ja': '基本ストリップ設定'},
 'UI_SECTION_RETOPO_ROOT': {'en': 'Ultimate Retopo', 'ja': 'アルティメット・リトポ'},
 'UI_SNAP_PX': {'en': 'Snap Radius (px)', 'ja': 'スナップ半径 (px)'},
 'UI_TARGET': {'en': 'Target', 'ja': 'ターゲット'},
 'UI_TARGET_STATUS_ACTIVE': {'en': 'Using the active mesh as target.', 'ja': 'アクティブメッシュをターゲットとして使用中です。'},
 'UI_TARGET_STATUS_AUTO': {'en': 'A likely target can be auto-detected.', 'ja': '自動検出できそうな候補があります。'},
 'UI_TARGET_STATUS_INVALID': {'en': 'Stored target is invalid. Pick it again.', 'ja': '保存済みターゲットが無効です。選び直してください。'},
 'UI_TARGET_STATUS_NONE': {'en': 'Target not chosen yet.', 'ja': 'ターゲットはまだ未設定です。'},
 'UI_TARGET_STATUS_READY': {'en': 'Current target is ready.', 'ja': '現在のターゲットは使用可能です。'}}


def _EN(key):
    return CONST_TEXT.get(key, {}).get("en", key)

def _T(key):
    text_en = _EN(key)
    try:
        return bpy.app.translations.pgettext(text_en)
    except Exception:
        return text_en

def _TT(key, **kwargs):
    template = _T(key)
    try:
        return template.format(**kwargs)
    except Exception:
        try:
            return _EN(key).format(**kwargs)
        except Exception:
            return _EN(key)

def _build_translation_dict():
    pairs = {}
    for item in CONST_TEXT.values():
        en = item.get("en")
        ja = item.get("ja")
        if en and ja:
            pairs[("*", en)] = ja
    return {"ja_JP": pairs}

bl_info_translation_dict = _build_translation_dict()
