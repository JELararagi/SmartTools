"""Shared retopo helper functions."""

import math

import bmesh
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy_extras import view3d_utils

from .localization import _T
from .common import (
    _get_mouse_ray,
    _get_view_vector,
    _ray_cast_plane_intersection,
)

def _qsd_poll_mesh_edit(context):
    obj = context.active_object
    return obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

def _qsd_prepare_retopo_edit_mesh(context):
    """Ensure there is an active mesh object and switch to mesh edit mode if needed.
    Returns the active mesh object on success, or None on failure.
    """
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        selected_meshes = [o for o in context.selected_objects if getattr(o, 'type', None) == 'MESH']
        if not selected_meshes:
            return None
        obj = selected_meshes[0]
        try:
            context.view_layer.objects.active = obj
        except Exception:
            return None
    if context.mode != 'EDIT_MESH':
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            return None
    obj = context.active_object
    if not obj or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None
    return obj

def _qsd_mesh_complexity_score(obj):
    """Return a practical score used to guess the most likely high-poly retopo target."""
    try:
        data = getattr(obj, "data", None)
        polys = len(getattr(data, "polygons", []))
        verts = len(getattr(data, "vertices", []))
        edges = len(getattr(data, "edges", []))
        mods = len(getattr(obj, "modifiers", []))
        dims = getattr(obj, "dimensions", Vector((0.0, 0.0, 0.0)))
        volume_hint = float(dims.x * dims.y * dims.z)
        return (polys * 1000000) + (verts * 1000) + (edges * 10) + mods + volume_hint
    except Exception:
        return 0

def _qsd_is_mesh_target(obj, require_polys=True):
    if obj is None:
        return False
    if getattr(obj, "type", None) != 'MESH':
        return False
    try:
        data = getattr(obj, "data", None)
        if data is None:
            return False
        if len(getattr(data, "vertices", [])) == 0:
            return False
        if require_polys and len(getattr(data, "polygons", [])) == 0:
            return False
    except Exception:
        return False
    return True

def _qsd_is_valid_target(context, obj, active=None, allow_active=True):
    if not _qsd_is_mesh_target(obj, require_polys=True):
        return False
    if not allow_active and obj == active:
        return False
    return True

def _qsd_iter_target_candidates(context, allow_active=False):
    active = getattr(context, "active_object", None)
    seen = set()

    def push(obj):
        if not _qsd_is_valid_target(context, obj, active, allow_active=allow_active):
            return None
        key = getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj)
        if key in seen:
            return None
        seen.add(key)
        return obj

    for obj in (getattr(context, "selected_objects", None) or []):
        cand = push(obj)
        if cand is not None:
            yield cand

    try:
        for obj in context.view_layer.objects:
            try:
                selected = obj.select_get(view_layer=context.view_layer)
            except TypeError:
                selected = obj.select_get()
            except Exception:
                selected = False
            if not selected:
                continue
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    if active is not None:
        try:
            for mod in getattr(active, "modifiers", []):
                for attr in ("target", "object", "auxiliary_target"):
                    cand = push(getattr(mod, attr, None))
                    if cand is not None:
                        yield cand
        except Exception:
            pass

    try:
        for obj in context.view_layer.objects:
            if not _qsd_is_valid_target(context, obj, active, allow_active=allow_active):
                continue
            try:
                if obj.hide_get() or getattr(obj, "hide_viewport", False):
                    continue
            except Exception:
                pass
            try:
                if hasattr(obj, "visible_get") and not obj.visible_get(view_layer=context.view_layer):
                    continue
            except TypeError:
                try:
                    if hasattr(obj, "visible_get") and not obj.visible_get():
                        continue
                except Exception:
                    pass
            except Exception:
                pass
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    try:
        for obj in getattr(context.scene, "objects", []):
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

    try:
        for obj in bpy.data.objects:
            cand = push(obj)
            if cand is not None:
                yield cand
    except Exception:
        pass

def _qsd_find_target_candidate(context, allow_active=False):
    candidates = list(_qsd_iter_target_candidates(context, allow_active=allow_active))
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    try:
        return max(candidates, key=_qsd_mesh_complexity_score)
    except Exception:
        return candidates[0]

def _qsd_get_target(context, auto_assign=True):
    scene = getattr(context, "scene", None)
    active = getattr(context, "active_object", None)
    tgt = getattr(scene, "qsd_retopo_target", None)

    # Root fix: keep honoring an explicitly chosen active mesh target.
    if _qsd_is_valid_target(context, tgt, active, allow_active=True):
        return tgt

    if auto_assign:
        candidate = _qsd_find_target_candidate(context, allow_active=False)
        if candidate is not None:
            try:
                scene.qsd_retopo_target = candidate
            except Exception:
                pass
            return candidate

        if _qsd_is_valid_target(context, active, active, allow_active=True):
            try:
                scene.qsd_retopo_target = active
            except Exception:
                pass
            return active
    return None

def _qsd_target_status_info(context):
    active = getattr(context, "active_object", None)
    stored = getattr(context.scene, "qsd_retopo_target", None)
    if _qsd_is_valid_target(context, stored, active, allow_active=True):
        if stored == active:
            return _T("UI_TARGET_STATUS_ACTIVE"), 'MESH_DATA'
        return f"{_T('UI_TARGET_STATUS_READY')}  [{stored.name}]", 'CHECKMARK'

    if stored is not None:
        return _T("UI_TARGET_STATUS_INVALID"), 'ERROR'

    candidate = _qsd_find_target_candidate(context, allow_active=False)
    if candidate is not None:
        return f"{_T('UI_TARGET_STATUS_AUTO')}  [{candidate.name}]", 'CHECKMARK'

    if _qsd_is_valid_target(context, active, active, allow_active=True):
        return _T("UI_TARGET_STATUS_ACTIVE"), 'CHECKMARK'

    return _T("UI_TARGET_STATUS_NONE"), 'ERROR'

def _qsd_assign_target(scene, obj):
    try:
        scene.qsd_retopo_target = obj
        return True
    except Exception:
        return False

def _qsd_pick_selected_target(context, allow_active_fallback=True):
    active = getattr(context, "active_object", None)
    candidate = _qsd_find_target_candidate(context, allow_active=False)
    if candidate is not None:
        return candidate
    if allow_active_fallback and _qsd_is_valid_target(context, active, active, allow_active=True):
        return active
    return None

def _qsd_build_target_bvh(target_obj, depsgraph):
    eval_obj = target_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    if mesh is None:
        return eval_obj, None, None

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        bvh = BVHTree.FromBMesh(bm)
    finally:
        bm.free()

    return eval_obj, mesh, bvh

def _qsd_clear_target_bvh(eval_obj, mesh):
    try:
        if eval_obj and mesh:
            eval_obj.to_mesh_clear()
    except Exception:
        pass

def _qsd_target_raycast(target_obj, bvh, origin_w, direction_w, max_dist=100000.0, frontface_only=False):
    inv = target_obj.matrix_world.inverted()
    origin = inv @ origin_w
    direction = (inv.to_3x3() @ direction_w).normalized()
    hit = bvh.ray_cast(origin, direction, max_dist)
    if hit and hit[0] is not None:
        loc_l, n_l, face_index, dist = hit
        loc_w = target_obj.matrix_world @ loc_l
        n_w = (target_obj.matrix_world.to_3x3() @ n_l).normalized()
        if frontface_only:
            # Require surface normal to face against the ray (avoid backface hits / penetration)
            if n_w.dot(-direction_w.normalized()) <= 0.0001:
                return None, None, None
        return loc_w, n_w, dist
    return None, None, None

def _qsd_target_nearest(target_obj, bvh, point_w):
    inv = target_obj.matrix_world.inverted()
    p_l = inv @ point_w
    hit = bvh.find_nearest(p_l)
    if hit and hit[0] is not None:
        loc_l, n_l, face_index, dist = hit
        loc_w = target_obj.matrix_world @ loc_l
        n_w = (target_obj.matrix_world.to_3x3() @ n_l).normalized()
        return loc_w, n_w, dist
    return None, None, None

def _qsd_point_seg_dist_2d(p, a, b):
    ab = b - a
    denom = ab.length_squared
    if denom <= 1e-12:
        return (p - a).length, 0.0
    t = (p - a).dot(ab) / denom
    t = max(0.0, min(1.0, t))
    proj = a + ab * t
    return (p - proj).length, t

def _qsd_seg_seg_dist_sq(p1, q1, p2, q2):
    """Return squared distance between two 3D segments, plus closest points.
    Robust enough for local intersection/penetration guards.
    """
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = d1.dot(d1)
    e = d2.dot(d2)
    f = d2.dot(r)

    if a <= 1e-12 and e <= 1e-12:
        return (p1 - p2).length_squared, p1, p2
    if a <= 1e-12:
        s = 0.0
        t = max(0.0, min(1.0, f / e)) if e > 1e-12 else 0.0
    else:
        c = d1.dot(r)
        if e <= 1e-12:
            t = 0.0
            s = max(0.0, min(1.0, -c / a))
        else:
            b = d1.dot(d2)
            denom = a * e - b * b
            if denom != 0.0:
                s = max(0.0, min(1.0, (b * f - c * e) / denom))
            else:
                s = 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = max(0.0, min(1.0, -c / a))
            elif t > 1.0:
                t = 1.0
                s = max(0.0, min(1.0, (b - c) / a))
    cp1 = p1 + d1 * s
    cp2 = p2 + d2 * t
    return (cp1 - cp2).length_squared, cp1, cp2

def _qsd_estimate_world_per_pixel(region, rv3d, world_point):
    """Estimate world distance that corresponds to 1 pixel near world_point."""
    try:
        p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, world_point)
        if p2d is None:
            return 0.0
        view_dir = _get_view_vector(rv3d)
        # plane passing through world_point facing the camera
        plane_p = world_point
        plane_n = view_dir

        o0, d0 = _get_mouse_ray(region, rv3d, (p2d.x, p2d.y))
        o1, d1 = _get_mouse_ray(region, rv3d, (p2d.x + 1.0, p2d.y))

        ip0 = _ray_cast_plane_intersection(o0, d0, plane_p, plane_n)
        ip1 = _ray_cast_plane_intersection(o1, d1, plane_p, plane_n)
        if ip0 is None or ip1 is None:
            return 0.0
        return (ip1 - ip0).length
    except Exception:
        return 0.0

def _qsd_estimate_span_pca(points, avg_edge_len, clamp_max=64):
    # Lightweight PCA-ish span estimate without numpy; stable fallback.
    if len(points) < 6 or avg_edge_len <= 1e-12:
        return max(1, min(clamp_max, int(round(len(points) / 4)) or 1))
    c = Vector((0,0,0))
    for p in points: c += p
    c /= len(points)
    # covariance
    xx=yy=zz=xy=xz=yz=0.0
    for p in points:
        d = p - c
        xx += d.x*d.x; yy += d.y*d.y; zz += d.z*d.z
        xy += d.x*d.y; xz += d.x*d.z; yz += d.y*d.z
    n=float(len(points))
    xx/=n; yy/=n; zz/=n; xy/=n; xz/=n; yz/=n
    A = [[xx,xy,xz],[xy,yy,yz],[xz,yz,zz]]
    V = [[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0]]
    def max_off(A):
        m=0.0;p=q=0
        for i in range(3):
            for j in range(i+1,3):
                if abs(A[i][j])>m:
                    m=abs(A[i][j]);p=i;q=j
        return m,p,q
    for _ in range(18):
        m,p,q = max_off(A)
        if m<1e-12: break
        app=A[p][p]; aqq=A[q][q]; apq=A[p][q]
        phi=0.5*math.atan2(2*apq,(aqq-app))
        c0=math.cos(phi); s0=math.sin(phi)
        for i in range(3):
            aip=A[i][p]; aiq=A[i][q]
            A[i][p]=c0*aip - s0*aiq
            A[i][q]=s0*aip + c0*aiq
        for i in range(3):
            api=A[p][i]; aqi=A[q][i]
            A[p][i]=c0*api - s0*aqi
            A[q][i]=s0*api + c0*aqi
        A[p][q]=A[q][p]=0.0
        for i in range(3):
            vip=V[i][p]; viq=V[i][q]
            V[i][p]=c0*vip - s0*viq
            V[i][q]=s0*vip + c0*viq
    evals=[A[0][0],A[1][1],A[2][2]]
    evecs=[Vector((V[0][i],V[1][i],V[2][i])) for i in range(3)]
    order=sorted(range(3), key=lambda i: evals[i], reverse=True)
    u=evecs[order[0]].normalized()
    v=evecs[order[1]].normalized()
    pu=[(p-c).dot(u) for p in points]
    pv=[(p-c).dot(v) for p in points]
    long=max(max(pu)-min(pu), max(pv)-min(pv))
    seg=max(1, int(round(long/avg_edge_len)))
    return max(1, min(clamp_max, seg))

def _qsd_edge_guide_layer(bm):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        layer = bm.edges.layers.int.new("qsd_guide")
    return layer

def _qsd_set_guide_edges(bm, edges):
    # Adding custom data can invalidate existing BMEdge wrappers.
    bm.edges.index_update()
    indices = [edge.index for edge in edges]
    layer = _qsd_edge_guide_layer(bm)
    bm.edges.ensure_lookup_table()
    for index in indices:
        bm.edges[index][layer] = 1

def _qsd_clear_guide_edges(bm, edges):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        return
    for e in edges:
        e[layer] = 0

def _qsd_select_guide_edges(bm, select=True):
    layer = _qsd_edge_guide_layer(bm)
    for e in bm.edges:
        if e[layer] == 1:
            e.select = bool(select)

def _qsd_nearest_guide_dir(obj, bm, point_w, radius=0.05):
    layer = bm.edges.layers.int.get("qsd_guide")
    if layer is None:
        return None
    inv = obj.matrix_world.inverted()
    p = inv @ point_w
    best = None
    best_d2 = radius * radius
    for e in bm.edges:
        if e[layer] != 1:
            continue
        a = e.verts[0].co
        b = e.verts[1].co
        # distance to segment
        ab = b - a
        denom = ab.length_squared
        if denom <= 1e-12:
            d2 = (p - a).length_squared
            t = 0.0
        else:
            t = (p - a).dot(ab) / denom
            t = max(0.0, min(1.0, t))
            proj = a + ab * t
            d2 = (p - proj).length_squared
        if d2 < best_d2:
            best_d2 = d2
            d = (b - a)
            if d.length > 1e-12:
                best = (obj.matrix_world.to_3x3() @ d).normalized()
    return best

