"""Panel and popup UI for Draw Quad Strip."""

import bpy
from bpy.types import Operator, Panel

from .localization import _EN, _T
from .common import _wm_get_running
from .retopo_utils import _qsd_target_status_info

def _qsd_popup_column(layout):
    col = layout.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    return col

def _qsd_draw_field_basic_popup(layout, scn):
    shape = layout.box().column(align=True)
    shape.use_property_split = True
    shape.use_property_decorate = False
    shape.label(text=_T("UI_GROUP_FIELD_SHAPE"), icon="MESH_GRID")
    shape.prop(scn, "qsd_field_width", text=_T("PROP_FIELD_WIDTH"))
    shape.prop(scn, "qsd_field_columns", text=_T("PROP_FIELD_COLUMNS"))
    shape.prop(scn, "qsd_field_spacing_px", text=_T("PROP_FIELD_SPACING_PX"))
    shape.prop(scn, "qsd_field_screen_adaptive", text=_T("PROP_FIELD_SCREEN_ADAPTIVE"), toggle=True)

    guide = layout.box().column(align=True)
    guide.use_property_split = True
    guide.use_property_decorate = False
    guide.label(text=_T("UI_GROUP_FIELD_GUIDANCE"), icon="CURVE_DATA")
    guide.prop(scn, "qsd_field_silhouette_boost", text=_T("PROP_FIELD_SILHOUETTE_BOOST"))
    guide.prop(scn, "qsd_field_curvature_boost", text=_T("PROP_FIELD_CURVATURE_BOOST"))
    guide.prop(scn, "qsd_field_align_guides", text=_T("PROP_FIELD_ALIGN_GUIDES"), toggle=True)
    guide.prop(scn, "qsd_field_guide_strength", text=_T("PROP_FIELD_GUIDE_STRENGTH"))

    finish = layout.box().column(align=True)
    finish.use_property_split = True
    finish.use_property_decorate = False
    finish.label(text=_T("UI_GROUP_FIELD_FINISH"), icon="MOD_ARRAY")
    finish.prop(scn, "qsd_field_auto_stitch", text=_T("PROP_FIELD_AUTO_STITCH"), toggle=True)
    finish.prop(scn, "qsd_field_merge_dist", text=_T("PROP_FIELD_MERGE_DIST"))
    finish.prop(scn, "qsd_field_auto_fill_on_finish", text=_T("PROP_FIELD_AUTO_FILL_ON_FINISH"), toggle=True)
    finish.prop(scn, "qsd_field_fill_span", text=_T("PROP_FIELD_FILL_SPAN"))
    finish.prop(scn, "qsd_field_fill_relax_iters", text=_T("PROP_FIELD_FILL_RELAX_ITERS"))
    finish.prop(scn, "qsd_field_fill_relax_strength", text=_T("PROP_FIELD_FILL_RELAX_STRENGTH"))

class MESH_OT_qsd_retopo_setup_popup(Operator):
    bl_idname = "mesh.qsd_retopo_setup_popup"
    bl_label = _EN("POPUP_RETOPO_SETUP_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_RETOPO_SETUP")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=420)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_retopo_target", text=_T("UI_TARGET"))
        status_text, status_icon = _qsd_target_status_info(context)
        info = col.row()
        info.use_property_split = False
        info.label(text=status_text, icon=status_icon)

        actions = col.row(align=True)
        actions.use_property_split = False
        actions.operator("mesh.qsd_set_target_from_selection", text=_T("BTN_SET_FROM_SELECTION"), icon="RESTRICT_SELECT_OFF")
        actions.operator("mesh.qsd_use_active_as_target", text=_T("BTN_USE_ACTIVE_TARGET"), icon="MESH_DATA")
        actions.operator("mesh.qsd_clear_retopo_target", text=_T("BTN_CLEAR_TARGET"), icon="X")

        col.separator()
        col.prop(scn, "qsd_retopo_offset", text=_T("UI_OFFSET"))
        col.prop(scn, "qsd_retopo_project_max_dist", text=_T("UI_MAX_DIST"))
        col.prop(scn, "qsd_retopo_frontface_only", text=_T("UI_FRONTFACE_ONLY"), toggle=True)
        col.prop(scn, "qsd_retopo_snap_radius", text=_T("UI_SNAP_PX"))

class MESH_OT_qsd_guides_popup(Operator):
    bl_idname = "mesh.qsd_guides_popup"
    bl_label = _EN("POPUP_GUIDES_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_GUIDES")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=300)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("mesh.qsd_guides_set", text=_T("OP_GUIDES_SET"), icon="ADD")
        col.operator("mesh.qsd_guides_clear", text=_T("OP_GUIDES_CLEAR"), icon="REMOVE")
        col.operator("mesh.qsd_guides_select", text=_T("OP_GUIDES_SELECT"), icon="RESTRICT_SELECT_OFF")

class MESH_OT_qsd_field_paint_popup(Operator):
    bl_idname = "mesh.qsd_field_paint_popup"
    bl_label = _EN("POPUP_FIELD_SETTINGS_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FIELD_SETTINGS")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=450)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        start = layout.row()
        start.scale_y = 1.1
        start.operator("mesh.qsd_quad_field_paint", text=_T("OP_QUAD_FIELD_PAINT"), icon="BRUSH_DATA")
        _qsd_draw_field_basic_popup(layout, scn)
        footer = layout.row(align=True)
        footer.operator_context = 'INVOKE_DEFAULT'
        footer.operator("mesh.qsd_field_paint_advanced_popup", text=_T("BTN_ADVANCED"), icon="PREFERENCES")

class MESH_OT_qsd_field_paint_advanced_popup(Operator):
    bl_idname = "mesh.qsd_field_paint_advanced_popup"
    bl_label = _EN("POPUP_FIELD_ADVANCED_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FIELD_ADVANCED")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=420)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_field_edge_snap_px", text=_T("PROP_FIELD_EDGE_SNAP_PX"))
        col.prop(scn, "qsd_field_boundary_only", text=_T("PROP_FIELD_BOUNDARY_ONLY"), toggle=True)
        col.prop(scn, "qsd_field_trace_boundary", text=_T("PROP_FIELD_TRACE_BOUNDARY"), toggle=True)
        col.prop(scn, "qsd_field_edge_snap_to_edges", text=_T("PROP_FIELD_EDGE_SNAP_TO_EDGES"), toggle=True)
        col.prop(scn, "qsd_field_boundary_strength", text=_T("PROP_FIELD_BOUNDARY_STRENGTH"))
        col.prop(scn, "qsd_field_tangent_inertia", text=_T("PROP_FIELD_TANGENT_INERTIA"))
        col.prop(scn, "qsd_field_live_merge", text=_T("PROP_FIELD_LIVE_MERGE"), toggle=True)
        col.prop(scn, "qsd_field_live_merge_dist", text=_T("PROP_FIELD_LIVE_MERGE_DIST"))
        col.prop(scn, "qsd_field_stop_on_intersect", text=_T("PROP_FIELD_STOP_ON_INTERSECT"), toggle=True)
        col.prop(scn, "qsd_field_intersect_tol", text=_T("PROP_FIELD_INTERSECT_TOL"))

class MESH_OT_qsd_fill_tools_popup(Operator):
    bl_idname = "mesh.qsd_fill_tools_popup"
    bl_label = _EN("POPUP_FILL_TOOLS_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_FILL_TOOLS")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=340)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("mesh.qsd_project_selected", text=_T("OP_PROJECT_SELECTED"), icon="MOD_SHRINKWRAP")
        col.operator("mesh.qsd_relax_project_selected", text=_T("OP_RELAX_PROJECT"), icon="MOD_SMOOTH")
        col.operator("mesh.qsd_grid_fill_project", text=_T("OP_GRID_FILL_PROJECT"), icon="MESH_GRID")

class MESH_OT_qsd_boundary_trace_popup(Operator):
    bl_idname = "mesh.qsd_boundary_trace_popup"
    bl_label = _EN("POPUP_BOUNDARY_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_BOUNDARY")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=430)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        actions = layout.column(align=True)
        actions.operator("mesh.qsd_boundary_trace_paint", text=_T("OP_BOUNDARY_TRACE_PAINT"), icon="TRACKING_FORWARDS")
        actions.operator("mesh.qsd_loop_trace_extend", text=_T("OP_LOOP_TRACE_EXTEND"), icon="MOD_ARRAY")

        core = layout.box().column(align=True)
        core.use_property_split = True
        core.use_property_decorate = False
        core.label(text=_T("UI_GROUP_BOUNDARY_CORE"), icon="MESH_DATA")
        core.prop(scn, "qsd_retopo_loop_step", text=_T("PROP_RETOPO_LOOP_STEP"))
        core.prop(scn, "qsd_retopo_loop_spacing_px", text=_T("PROP_RETOPO_LOOP_SPACING_PX"))
        core.prop(scn, "qsd_retopo_loop_flip", text=_T("PROP_RETOPO_LOOP_FLIP"), toggle=True)
        core.prop(scn, "qsd_retopo_loop_make_faces", text=_T("PROP_RETOPO_LOOP_MAKE_FACES"), toggle=True)
        core.prop(scn, "qsd_retopo_loop_merge_dist", text=_T("PROP_RETOPO_LOOP_MERGE_DIST"))

        footer = layout.row(align=True)
        footer.operator_context = 'INVOKE_DEFAULT'
        footer.operator("mesh.qsd_boundary_trace_advanced_popup", text=_T("BTN_ADVANCED"), icon="PREFERENCES")

class MESH_OT_qsd_boundary_trace_advanced_popup(Operator):
    bl_idname = "mesh.qsd_boundary_trace_advanced_popup"
    bl_label = _EN("POPUP_BOUNDARY_ADVANCED_TITLE")
    bl_options = set()
    _sms_no_undo = True
    bl_description = _EN("TIP_POPUP_BOUNDARY_ADVANCED")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        from ..utils import smart_tools_invoke_props_dialog
        return smart_tools_invoke_props_dialog(context, self, width=400)

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        col = _qsd_popup_column(layout)
        col.prop(scn, "qsd_retopo_loop_snap_px", text=_T("PROP_RETOPO_LOOP_SNAP_PX"))
        col.prop(scn, "qsd_retopo_loop_lock_strength", text=_T("PROP_RETOPO_LOOP_LOCK_STRENGTH"))
        col.prop(scn, "qsd_retopo_loop_inertia", text=_T("PROP_RETOPO_LOOP_INERTIA"))

class VIEW3D_PT_quad_strip_draw_final(Panel):
    bl_label = "Quad Strip / Retopo"
    bl_idname = "VIEW3D_PT_sms_quad_strip_draw"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    _smart_suite_host_panel = True
    bl_description = 'Integrated quad-strip drawing and retopo sketch panel grouped under Sketch Surface so strip creation, guide curves, and surface sketch helpers stay together.'

    @classmethod
    def poll(cls, context):
        return getattr(context, "scene", None) is not None and hasattr(context.scene, "qsd_draw_toggle")

    def draw_header(self, context):
        self.layout.label(text="", icon="MESH_GRID")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        scn = context.scene

        status = layout.box()
        status_col = status.column(align=True)
        status_col.use_property_split = False

        op_row = status_col.row()
        op_row.scale_y = 1.2
        op_row.use_property_split = False
        running = _wm_get_running(context)
        op_row.prop(scn, "qsd_draw_toggle", text=_T("BTN_START"), toggle=True)
        if running:
            status_col.label(text=_T("UI_LABEL_STATUS_RUNNING"))

        basic = layout.box().column(align=True)
        basic.label(text=_T("UI_SECTION_BASIC_STRIP"), icon="MESH_DATA")
        basic.prop(scn, "qsd_plane_mode", text=_T("PROP_PLANE"))
        basic.prop(scn, "qsd_use_surface_snap", text=_T("PROP_SNAP"), toggle=True)
        basic.prop(scn, "qsd_width", text=_T("PROP_WIDTH"))
        basic.prop(scn, "qsd_subdivisions", text=_T("PROP_SEGMENTS"))
        merge_row = basic.row(align=True)
        merge_row.use_property_split = False
        merge_row.enabled = True
        if scn.qsd_strip_vertex_merge and not scn.qsd_use_solidify:
            merge_split = merge_row.split(factor=0.42, align=True)
            merge_split.prop(scn, "qsd_strip_vertex_merge", text=_T("PROP_STRIP_VERTEX_MERGE"), toggle=True)
            merge_split.prop(scn, "qsd_strip_vertex_merge_distance", text="")
        else:
            merge_row.prop(scn, "qsd_strip_vertex_merge", text=_T("PROP_STRIP_VERTEX_MERGE"), toggle=True)
        solid_row = basic.row(align=True)
        solid_row.use_property_split = False
        if scn.qsd_use_solidify:
            solid_split = solid_row.split(factor=0.42, align=True)
            solid_split.prop(scn, "qsd_use_solidify", text=_T("PROP_SOLIDIFY"), toggle=True)
            solid_split.prop(scn, "qsd_thickness", text="")
        else:
            solid_row.prop(scn, "qsd_use_solidify", text=_T("PROP_SOLIDIFY"), toggle=True)

        ret = layout.box()
        ret_header = ret.row(align=True)
        ret_header.label(text=_T("UI_SECTION_RETOPO_ROOT"), icon="MOD_SHRINKWRAP")
        ret_header.prop(scn, "qsd_retopo_mode", text=_T("UI_ENABLE"), toggle=True)

        if scn.qsd_retopo_mode:
            ret_col = ret.column(align=True)
            target_row = ret_col.row(align=True)
            target_row.prop(scn, "qsd_retopo_target", text=_T("UI_TARGET"))
            target_row.operator_context = 'INVOKE_DEFAULT'
            target_row.operator("mesh.qsd_retopo_setup_popup", text="", icon="PREFERENCES")

            status_text, status_icon = _qsd_target_status_info(context)
            status_row = ret_col.row()
            status_row.use_property_split = False
            status_row.label(text=status_text, icon=status_icon)

            action_row = ret_col.row(align=True)
            action_row.use_property_split = False
            action_row.operator("mesh.qsd_set_target_from_selection", text="", icon="RESTRICT_SELECT_OFF")
            action_row.operator("mesh.qsd_use_active_as_target", text="", icon="MESH_DATA")
            action_row.operator("mesh.qsd_clear_retopo_target", text="", icon="X")

            tools = ret.box().column(align=True)
            tools.use_property_split = False
            tools.label(text=_T("UI_GROUP_RETOPO_ACTIONS"), icon="TOOL_SETTINGS")


            guides_row = tools.row(align=True)
            guides_row.operator_context = 'INVOKE_DEFAULT'
            guides_row.operator("mesh.qsd_guides_popup", text=_T("BTN_GUIDE_ACTIONS"), icon="CURVE_DATA")

            field_row = tools.row(align=True)
            field_row.operator("mesh.qsd_quad_field_paint", text=_T("OP_QUAD_FIELD_PAINT"), icon="BRUSH_DATA")
            field_row.operator_context = 'INVOKE_DEFAULT'
            field_row.operator("mesh.qsd_field_paint_popup", text="", icon="PREFERENCES")

            fill_row = tools.row(align=True)
            fill_row.operator_context = 'INVOKE_DEFAULT'
            fill_row.operator("mesh.qsd_fill_tools_popup", text=_T("BTN_SELECTION_TOOLS"), icon="MESH_GRID")

            boundary_row = tools.row(align=True)
            boundary_row.operator_context = 'INVOKE_DEFAULT'
            boundary_row.operator("mesh.qsd_boundary_trace_popup", text=_T("BTN_BOUNDARY_TOOLS"), icon="TRACKING_FORWARDS")
