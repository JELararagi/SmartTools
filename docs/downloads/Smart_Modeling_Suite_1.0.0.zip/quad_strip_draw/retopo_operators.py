"""Retopo operator classes."""

import math

import blf
import bmesh
import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty
from bpy.types import Operator
from mathutils import Vector
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils

from .localization import _EN, _T, _TT
from .common import (
    _blf_size,
    _cm_to_bu,
    _get_mouse_ray,
    _get_region_under_mouse,
    _get_view_vector,
)
from .retopo_utils import (
    _qsd_poll_mesh_edit,
    _qsd_prepare_retopo_edit_mesh,
    _qsd_is_valid_target,
    _qsd_get_target,
    _qsd_assign_target,
    _qsd_pick_selected_target,
    _qsd_build_target_bvh,
    _qsd_clear_target_bvh,
    _qsd_target_raycast,
    _qsd_target_nearest,
    _qsd_point_seg_dist_2d,
    _qsd_seg_seg_dist_sq,
    _qsd_estimate_world_per_pixel,
    _qsd_estimate_span_pca,
    _qsd_set_guide_edges,
    _qsd_clear_guide_edges,
    _qsd_select_guide_edges,
    _qsd_nearest_guide_dir,
)

class MESH_OT_qsd_guides_set(Operator):
    bl_idname = "mesh.qsd_guides_set"
    bl_label = _EN("OP_GUIDES_SET_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_SET")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        edges = [e for e in bm.edges if e.select]
        if not edges:
            self.report({'WARNING'}, _T("REPORT_SELECT_GUIDE_EDGES"))
            return {'CANCELLED'}
        _qsd_set_guide_edges(bm, edges)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_guides_clear(Operator):
    bl_idname = "mesh.qsd_guides_clear"
    bl_label = _EN("OP_GUIDES_CLEAR_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_CLEAR")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        edges = [e for e in bm.edges if e.select]
        if not edges:
            # if nothing selected, clear all guides
            layer = bm.edges.layers.int.get("qsd_guide")
            if layer is not None:
                for e in bm.edges:
                    e[layer] = 0
        else:
            _qsd_clear_guide_edges(bm, edges)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_guides_select(Operator):
    bl_idname = "mesh.qsd_guides_select"
    bl_label = _EN("OP_GUIDES_SELECT_LABEL")
    bl_description = _EN("TIP_OP_GUIDES_SELECT")
    bl_options = {"UNDO"}

    select: BoolProperty(name=_EN("PROP_GUIDE_SELECT"), default=True, description=_EN("TIP_GUIDE_SELECT"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        _qsd_select_guide_edges(bm, select=self.select)
        bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

class MESH_OT_qsd_retopo_pen(Operator):
    bl_idname = "mesh.qsd_retopo_pen"
    bl_label = _EN("OP_RETOPO_PEN")
    bl_description = _EN("TIP_OP_RETOPO_PEN")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            return True
        return any(getattr(o, 'type', None) == 'MESH' for o in context.selected_objects)

    def invoke(self, context, event):
        obj = _qsd_prepare_retopo_edit_mesh(context)
        if not obj:
            self.report({'ERROR'}, _T("REPORT_SELECT_MESH_FOR_RETOPO"))
            return {'CANCELLED'}
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        prev_tgt = getattr(context.scene, "qsd_retopo_target", None)
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        if tgt is not None and tgt != prev_tgt:
            self.report({'INFO'}, _TT("REPORT_RETOPO_TARGET_AUTOSET", name=tgt.name))
        result = bpy.ops.mesh.quad_strip_draw('INVOKE_DEFAULT')
        if 'CANCELLED' in result:
            return {'CANCELLED'}
        return {'FINISHED'}

class MESH_OT_qsd_project_selected(Operator):
    bl_idname = "mesh.qsd_project_selected"
    bl_label = _EN("OP_PROJECT_SELECTED_LABEL")
    bl_description = _EN("TIP_OP_PROJECT_SELECTED")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            for v in bm.verts:
                if not v.select:
                    continue
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_relax_project_selected(Operator):
    bl_idname = "mesh.qsd_relax_project_selected"
    bl_label = _EN("OP_RELAX_PROJECT_LABEL")
    bl_description = _EN("TIP_OP_RELAX_PROJECT_SELECTED")
    bl_options = {"UNDO"}

    iterations: IntProperty(name=_EN("PROP_RELAX_ITERATIONS"), default=10, min=1, max=200, description=_EN("TIP_RELAX_ITERATIONS"))
    strength: FloatProperty(name=_EN("PROP_RELAX_STRENGTH"), default=0.5, min=0.0, max=1.0, description=_EN("TIP_RELAX_STRENGTH"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()

            sel = [v for v in bm.verts if v.select]
            if not sel:
                self.report({'WARNING'}, _T("REPORT_SELECT_RELAX_VERTS"))
                return {'CANCELLED'}

            for _ in range(self.iterations):
                targets = {}
                for v in sel:
                    if not v.link_edges:
                        continue
                    avg = Vector((0,0,0))
                    n=0
                    for e in v.link_edges:
                        ov = e.other_vert(v)
                        avg += ov.co
                        n += 1
                    if n:
                        avg /= n
                        targets[v] = v.co.lerp(avg, self.strength)
                for v, co in targets.items():
                    v.co = co

            # project
            for v in sel:
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_grid_fill_project(Operator):
    bl_idname = "mesh.qsd_grid_fill_project"
    bl_label = _EN("OP_GRID_FILL_PROJECT_LABEL")
    bl_description = _EN("TIP_OP_GRID_FILL_PROJECT")
    bl_options = {"UNDO"}

    span: IntProperty(name=_EN("PROP_GRID_FILL_SPAN"), default=0, min=0, max=64, description=_EN("TIP_GRID_FILL_SPAN"))

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def execute(self, context):
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        deps = context.evaluated_depsgraph_get()
        eval_obj, mesh, bvh = _qsd_build_target_bvh(tgt, deps)
        try:
            obj = context.active_object
            scn = context.scene
            offset = _cm_to_bu(scn.qsd_retopo_offset)
            maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
            inv = obj.matrix_world.inverted()

            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()

            edges = [e for e in bm.edges if e.select]
            if not edges:
                self.report({'WARNING'}, _T("REPORT_SELECT_GRID_FILL_BOUNDARY"))
                return {'CANCELLED'}

            boundary_verts = list({v for e in edges for v in e.verts})
            avg_len = 0.0
            cnt = 0
            for e in edges:
                avg_len += (e.verts[0].co - e.verts[1].co).length
                cnt += 1
            avg_len = (avg_len / cnt) if cnt else 0.01

            span = self.span
            if span <= 0:
                span = _qsd_estimate_span_pca([obj.matrix_world @ v.co for v in boundary_verts], avg_len, 64)

            try:
                # The mesh operator supports span; bmesh.ops.grid_fill does not.
                result = bpy.ops.mesh.fill_grid(span=span)
                if "FINISHED" not in result:
                    return {"CANCELLED"}
                bm = bmesh.from_edit_mesh(obj.data)
            except Exception as ex:
                self.report({'ERROR'}, _TT("REPORT_GRID_FILL_FAILED", message=ex))
                return {'CANCELLED'}

            # project all selected/new verts (simple: project all verts in boundary_verts neighborhood)
            bm.verts.ensure_lookup_table()
            for v in bm.verts:
                if not v.select:
                    continue
                w = obj.matrix_world @ v.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, bvh, w)
                if loc_w is None:
                    continue
                if maxd > 0.0 and dist > maxd:
                    continue
                v.co = inv @ (loc_w + n_w * offset)

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        finally:
            _qsd_clear_target_bvh(eval_obj, mesh)
        return {'FINISHED'}

class MESH_OT_qsd_loop_trace_extend(Operator):
    bl_idname = "mesh.qsd_loop_trace_extend"
    bl_label = _EN("OP_LOOP_TRACE_EXTEND")
    bl_description = _EN("TIP_OP_LOOP_TRACE_EXTEND")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._accum = 0.0

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}
        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._accum = 0.0
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'FINISHED'}

    def cancel(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'CANCELLED'}

    def _step_extrude(self, context):

        obj = context.active_object
        scn = context.scene
        step_len = _cm_to_bu(scn.qsd_retopo_loop_step)
        flip = scn.qsd_retopo_loop_flip
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        frontface = scn.qsd_retopo_frontface_only

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.normal_update()

        boundary_edges = [e for e in bm.edges if e.select and len(e.link_faces) == 1]
        if not boundary_edges:
            return

        boundary_verts = list({v for e in boundary_edges for v in e.verts})
        tgt = _qsd_get_target(context)

        inv_obj = obj.matrix_world.inverted()
        obj3 = obj.matrix_world.to_3x3()
        obj3_inv = obj3.inverted()

        # Build neighbor map to estimate boundary tangents
        neigh = {v: [] for v in boundary_verts}
        for e in boundary_edges:
            v0, v1 = e.verts
            if v0 in neigh and v1 in neigh:
                neigh[v0].append(v1)
                neigh[v1].append(v0)

        # Outward direction per old boundary vert (local-space vector)
        dir_map = {}
        for v in boundary_verts:
            t_l = Vector((0.0, 0.0, 0.0))
            for nb in neigh.get(v, []):
                vec = (nb.co - v.co)
                if vec.length > 1e-12:
                    t_l += vec.normalized()
            if t_l.length < 1e-12:
                t_l = v.normal.orthogonal()
            t_l.normalize()
            t_w = (obj3 @ t_l).normalized()

            # Prefer target normal for stability on curved/highpoly surfaces
            n_w = None
            if tgt and self._tgt_bvh:
                wpos = obj.matrix_world @ v.co
                loc_w, nn_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpos)
                if nn_w is not None:
                    n_w = nn_w.normalized()
            if n_w is None:
                n_w = (obj3 @ v.normal).normalized()

            outward_w = t_w.cross(n_w)
            if outward_w.length < 1e-12:
                outward_w = n_w.orthogonal()
            outward_w.normalize()
            if flip:
                outward_w.negate()
            outward_l = (obj3_inv @ outward_w)
            if outward_l.length < 1e-12:
                outward_l = Vector((1.0, 0.0, 0.0))
            outward_l.normalize()
            dir_map[v] = outward_l

        # Extrude selected boundary edges (creates new boundary verts at same positions)
        res = bmesh.ops.extrude_edge_only(bm, edges=boundary_edges)
        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        if not new_verts:
            return

        # Map old->new using a KDTree (robust)
        kd = KDTree(len(boundary_verts))
        for i, ov in enumerate(boundary_verts):
            kd.insert(ov.co, i)
        kd.balance()

        old_to_new = {}
        for nv in new_verts:
            co, idx, dist = kd.find(nv.co)
            if idx is not None and dist is not None and dist < 1e-10:
                ov = boundary_verts[idx]
                old_to_new[ov] = nv

        # Create quad faces between old and new boundary (optional)
        if scn.qsd_retopo_loop_make_faces and old_to_new:
            for e in boundary_edges:
                ov0, ov1 = e.verts[0], e.verts[1]
                nv0 = old_to_new.get(ov0)
                nv1 = old_to_new.get(ov1)
                if nv0 is None or nv1 is None:
                    continue
                try:
                    bm.faces.new((ov0, ov1, nv1, nv0))
                except ValueError:
                    pass

        # Move and project new verts
        for ov, nv in old_to_new.items():
            d = dir_map.get(ov, Vector((1.0, 0.0, 0.0)))
            if d.length < 1e-12:
                d = Vector((1.0, 0.0, 0.0))
            nv.co = nv.co + d * step_len

            if tgt and self._tgt_bvh:
                w = obj.matrix_world @ nv.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
                if loc_w is not None and n_w is not None:
                    if maxd <= 0.0 or dist <= maxd:
                        # Optional max distance clamp
                        nv.co = inv_obj @ (loc_w + n_w * offset)

        # Optional live merge after each step
        md = _cm_to_bu(scn.qsd_retopo_loop_merge_dist)
        if md and md > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=md)
            except Exception:
                pass

        # Select the new boundary loop (edges with both verts in the new set)
        for e in bm.edges:
            e.select = False
        new_set = set(old_to_new.values())
        for e in bm.edges:
            if len(e.link_faces) == 1 and (e.verts[0] in new_set and e.verts[1] in new_set):
                e.select = True

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self.finish(context)
        if event.type == 'ESC':
            return self.cancel(context)
        if event.type == 'MOUSEMOVE':
            # use pixel accumulation to trigger steps
            lx = getattr(self, "_last_x", event.mouse_x)
            ly = getattr(self, "_last_y", event.mouse_y)
            dx = event.mouse_x - lx
            dy = event.mouse_y - ly
            self._accum += math.sqrt(dx*dx + dy*dy)
            self._last_x = event.mouse_x
            self._last_y = event.mouse_y
            spacing = max(1.0, context.scene.qsd_retopo_loop_spacing_px)
            while self._accum >= spacing:
                self._accum -= spacing
                self._step_extrude(context)
        return {'RUNNING_MODAL'}

class MESH_OT_qsd_boundary_trace_paint(Operator):
    bl_idname = "mesh.qsd_boundary_trace_paint"
    bl_label = _EN("OP_BOUNDARY_TRACE_PAINT")
    bl_description = _EN("TIP_OP_BOUNDARY_TRACE_PAINT")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._accum = 0.0
        self._region = None
        self._rv3d = None
        self._last_mouse = None
        self._last_tan = None

    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def _get_window_region(self, context):
        try:
            area = context.area
            if not area or area.type != 'VIEW_3D':
                return None, None
            region = None
            for r in area.regions:
                if r.type == 'WINDOW':
                    region = r
                    break
            rv3d = getattr(context.space_data, "region_3d", None)
            if region and rv3d:
                return region, rv3d
        except Exception:
            pass
        return None, None

    def _mouse_region_xy(self, event):
        if not self._region:
            return Vector((0.0, 0.0))
        return Vector((float(event.mouse_x - self._region.x), float(event.mouse_y - self._region.y)))

    def _iter_selected_boundary_edges(self, bm):
        return [e for e in bm.edges if e.select and len(e.link_faces) == 1]

    def _nearest_boundary_info_2d(self, context, bm, obj, mouse2d):
        region, rv3d = self._region, self._rv3d
        if not region or not rv3d:
            return None, None, None
        best_d = None
        best_t = None
        best_p = None
        for e in self._iter_selected_boundary_edges(bm):
            v0, v1 = e.verts
            p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v0.co)
            p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v1.co)
            if p0 is None or p1 is None:
                continue
            d, t = _qsd_point_seg_dist_2d(mouse2d, p0, p1)
            if best_d is None or d < best_d:
                seg = (p1 - p0)
                if seg.length > 1e-6:
                    best_d = d
                    best_t = seg.normalized()
                    best_p = p0 + seg * t
        return best_d, best_t, best_p

    def _auto_select_boundary_loop_under_mouse(self, context, mouse2d):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        region, rv3d = self._region, self._rv3d
        if not region or not rv3d:
            return False

        all_boundary = [e for e in bm.edges if len(e.link_faces) == 1]
        if not all_boundary:
            return False

        best_e = None
        best_d = None
        for e in all_boundary:
            v0, v1 = e.verts
            p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v0.co)
            p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v1.co)
            if p0 is None or p1 is None:
                continue
            d, t = _qsd_point_seg_dist_2d(mouse2d, p0, p1)
            if best_d is None or d < best_d:
                best_d = d
                best_e = e

        if best_e is None:
            return False

        # Select connected boundary loop starting from best_e
        for e in bm.edges:
            e.select = False
        stack = [best_e]
        visited = set()
        while stack:
            e = stack.pop()
            if e in visited:
                continue
            visited.add(e)
            if len(e.link_faces) != 1:
                continue
            e.select = True
            for v in e.verts:
                for ne in v.link_edges:
                    if ne not in visited and len(ne.link_faces) == 1:
                        stack.append(ne)

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        return True

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}

        self._region, self._rv3d = self._get_window_region(context)
        if not self._region or not self._rv3d:
            self.report({'ERROR'}, _T("REPORT_VIEW3D_NOT_FOUND"))
            return {'CANCELLED'}

        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._accum = 0.0
        self._last_mouse = self._mouse_region_xy(event)
        self._last_tan = None

        # If nothing is selected, auto-pick boundary loop under mouse (safe convenience)
        bm = bmesh.from_edit_mesh(context.active_object.data)
        if not self._iter_selected_boundary_edges(bm):
            self._auto_select_boundary_loop_under_mouse(context, self._last_mouse)

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'FINISHED'}

    def cancel(self, context):
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        return {'CANCELLED'}

    def _step_extrude(self, context):

        obj = context.active_object
        scn = context.scene
        step_len = _cm_to_bu(scn.qsd_retopo_loop_step)
        flip = scn.qsd_retopo_loop_flip
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        frontface = scn.qsd_retopo_frontface_only

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.normal_update()

        boundary_edges = [e for e in bm.edges if e.select and len(e.link_faces) == 1]
        if not boundary_edges:
            return

        boundary_verts = list({v for e in boundary_edges for v in e.verts})
        tgt = _qsd_get_target(context)

        inv_obj = obj.matrix_world.inverted()
        obj3 = obj.matrix_world.to_3x3()
        obj3_inv = obj3.inverted()

        # Build neighbor map to estimate boundary tangents
        neigh = {v: [] for v in boundary_verts}
        for e in boundary_edges:
            v0, v1 = e.verts
            if v0 in neigh and v1 in neigh:
                neigh[v0].append(v1)
                neigh[v1].append(v0)

        # Outward direction per old boundary vert (local-space vector)
        dir_map = {}
        for v in boundary_verts:
            t_l = Vector((0.0, 0.0, 0.0))
            for nb in neigh.get(v, []):
                vec = (nb.co - v.co)
                if vec.length > 1e-12:
                    t_l += vec.normalized()
            if t_l.length < 1e-12:
                t_l = v.normal.orthogonal()
            t_l.normalize()
            t_w = (obj3 @ t_l).normalized()

            # Prefer target normal for stability on curved/highpoly surfaces
            n_w = None
            if tgt and self._tgt_bvh:
                wpos = obj.matrix_world @ v.co
                loc_w, nn_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpos)
                if nn_w is not None:
                    n_w = nn_w.normalized()
            if n_w is None:
                n_w = (obj3 @ v.normal).normalized()

            outward_w = t_w.cross(n_w)
            if outward_w.length < 1e-12:
                outward_w = n_w.orthogonal()
            outward_w.normalize()
            if flip:
                outward_w.negate()
            outward_l = (obj3_inv @ outward_w)
            if outward_l.length < 1e-12:
                outward_l = Vector((1.0, 0.0, 0.0))
            outward_l.normalize()
            dir_map[v] = outward_l

        # Extrude selected boundary edges (creates new boundary verts at same positions)
        res = bmesh.ops.extrude_edge_only(bm, edges=boundary_edges)
        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        if not new_verts:
            return

        # Map old->new using a KDTree (robust)
        kd = KDTree(len(boundary_verts))
        for i, ov in enumerate(boundary_verts):
            kd.insert(ov.co, i)
        kd.balance()

        old_to_new = {}
        for nv in new_verts:
            co, idx, dist = kd.find(nv.co)
            if idx is not None and dist is not None and dist < 1e-10:
                ov = boundary_verts[idx]
                old_to_new[ov] = nv

        # Create quad faces between old and new boundary (optional)
        if scn.qsd_retopo_loop_make_faces and old_to_new:
            for e in boundary_edges:
                ov0, ov1 = e.verts[0], e.verts[1]
                nv0 = old_to_new.get(ov0)
                nv1 = old_to_new.get(ov1)
                if nv0 is None or nv1 is None:
                    continue
                try:
                    bm.faces.new((ov0, ov1, nv1, nv0))
                except ValueError:
                    pass

        # Move and project new verts
        for ov, nv in old_to_new.items():
            d = dir_map.get(ov, Vector((1.0, 0.0, 0.0)))
            if d.length < 1e-12:
                d = Vector((1.0, 0.0, 0.0))
            nv.co = nv.co + d * step_len

            if tgt and self._tgt_bvh:
                w = obj.matrix_world @ nv.co
                loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
                if loc_w is not None and n_w is not None:
                    if maxd <= 0.0 or dist <= maxd:
                        # Optional max distance clamp
                        nv.co = inv_obj @ (loc_w + n_w * offset)

        # Optional live merge after each step
        md = _cm_to_bu(scn.qsd_retopo_loop_merge_dist)
        if md and md > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=md)
            except Exception:
                pass

        # Select the new boundary loop (edges with both verts in the new set)
        for e in bm.edges:
            e.select = False
        new_set = set(old_to_new.values())
        for e in bm.edges:
            if len(e.link_faces) == 1 and (e.verts[0] in new_set and e.verts[1] in new_set):
                e.select = True

        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self.finish(context)
        if event.type == 'ESC':
            return self.cancel(context)

        if event.type == 'MOUSEMOVE':
            scn = context.scene
            mouse_raw = self._mouse_region_xy(event)
            if self._last_mouse is None:
                self._last_mouse = mouse_raw
                return {'RUNNING_MODAL'}

            obj = context.active_object
            bm = bmesh.from_edit_mesh(obj.data)

            snap_px = float(getattr(scn, "qsd_retopo_loop_snap_px", 14.0))
            lock = float(getattr(scn, "qsd_retopo_loop_lock_strength", 0.9))
            inertia = float(getattr(scn, "qsd_retopo_loop_inertia", 0.6))

            best_d, tan, snap_p = self._nearest_boundary_info_2d(context, bm, obj, mouse_raw)
            if tan is None and self._last_tan is not None:
                tan = self._last_tan

            # lock mouse to boundary (screen-space) when close enough
            mouse = mouse_raw
            if snap_p is not None and best_d is not None and best_d <= snap_px and lock > 0.0:
                lock_clamped = max(0.0, min(1.0, lock))
                mouse = mouse_raw.lerp(snap_p, lock_clamped)

            delta = mouse - self._last_mouse
            self._last_mouse = mouse

            if tan is not None:
                # stabilize tangent orientation and apply inertia smoothing
                if self._last_tan is not None:
                    if tan.dot(self._last_tan) < 0.0:
                        tan = -tan
                    try:
                        a = max(0.0, min(1.0, inertia))
                        tan = (tan.lerp(self._last_tan, a)).normalized()
                    except Exception:
                        pass
                self._last_tan = tan

                comp = float(delta.dot(tan))
                # suppress perpendicular motion based on lock strength
                perp = (delta - tan * comp)
                lock_clamped = max(0.0, min(1.0, lock))
                move = abs(comp) + perp.length * (1.0 - lock_clamped) * 0.05
            else:
                move = delta.length

            self._accum += float(move)

            spacing = max(1.0, context.scene.qsd_retopo_loop_spacing_px)
            while self._accum >= spacing:
                self._accum -= spacing
                self._step_extrude(context)

        return {'RUNNING_MODAL'}

class MESH_OT_qsd_quad_field_paint(Operator):
    bl_idname = "mesh.qsd_quad_field_paint"
    bl_label = _EN("OP_QUAD_FIELD_PAINT")
    bl_description = _EN("TIP_OP_QUAD_FIELD_PAINT")
    bl_options = {"UNDO", "BLOCKING"}

    def _reset_runtime_state(self):
        self._active_region = None
        self._active_rv3d = None
        self._depsgraph = None
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None
        self._stroke = False
        self._last_mouse = None
        self._last_loc = None
        self._last_n = None
        self._last_side = None
        self._last_tangent = None
        self._rings = []
        self._stack = []  # for undo/cancel
        self._hud = None
        self._bm_vert_kd = None
        self._bm_vert_list = None
        self._bm_boundary_kd = None
        self._bm_boundary_list = None
        self._bm_boundary_edge_kd = None
        self._bm_boundary_edges = None
        self._edge_mid_kd = None
        self._edge_mid_edges = None
        self._kd_rebuild_counter = 0
        self._guard_tripped = False
        self._guard_reported = False


    @classmethod
    def poll(cls, context):
        return _qsd_poll_mesh_edit(context)

    def _ensure_region(self, context, event):
        if self._active_region is None:
            reg = _get_region_under_mouse(context.area, event.mouse_x, event.mouse_y)
            if reg:
                self._active_region = reg
                self._active_rv3d = reg.data
        return (self._active_region, self._active_rv3d)

    def _mouse_ray_world(self, context, event):
        region, rv3d = self._ensure_region(context, event)
        if not region or not rv3d:
            region = context.region
            rv3d = context.region_data
        mx = event.mouse_x - region.x
        my = event.mouse_y - region.y
        origin, direction = _get_mouse_ray(region, rv3d, (mx, my))
        return origin, direction, region, rv3d, Vector((mx, my))

    def invoke(self, context, event):
        self._reset_runtime_state()
        if not context.scene.qsd_retopo_mode:
            self.report({'ERROR'}, _T("REPORT_ENABLE_RETOPO_MODE"))
            return {'CANCELLED'}
        tgt = _qsd_get_target(context)
        if not tgt:
            self.report({'ERROR'}, _T("REPORT_RETOPO_TARGET_MISSING"))
            return {'CANCELLED'}

        self._depsgraph = context.evaluated_depsgraph_get()
        self._tgt_eval, self._tgt_mesh, self._tgt_bvh = _qsd_build_target_bvh(tgt, self._depsgraph)
        self._stroke = False
        self._last_mouse = None
        self._rings.clear()
        self._stack.clear()
        self._last_loc = None
        self._last_n = None
        self._last_side = None
        self._last_tangent = None

        self._hud = bpy.types.SpaceView3D.draw_handler_add(self._draw_hud, (context,), "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _cleanup(self):
        try:
            if self._hud:
                bpy.types.SpaceView3D.draw_handler_remove(self._hud, "WINDOW")
        except Exception:
            pass
        self._hud = None
        _qsd_clear_target_bvh(self._tgt_eval, self._tgt_mesh)
        self._tgt_eval = None
        self._tgt_mesh = None
        self._tgt_bvh = None

    def _draw_hud(self, context):
        # Minimal HUD
        try:
            font_id = 0
            _blf_size(font_id, 14)
            blf.color(font_id, 1, 1, 1, 1)
            x, y = 30, 60
            blf.position(font_id, x, y, 0)
            blf.draw(font_id, _T("HUD_FIELD_HELP"))
        except Exception:
            pass

    def _effective_spacing_px(self, rv3d, n_w):
        scn = bpy.context.scene
        base = max(1.0, float(scn.qsd_field_spacing_px))
        if not scn.qsd_field_screen_adaptive:
            return base
        view_dir = _get_view_vector(rv3d)
        sil = 1.0 - abs(max(-1.0, min(1.0, n_w.dot(view_dir))))
        curv = 0.0
        if self._last_n is not None:
            a = max(-1.0, min(1.0, self._last_n.dot(n_w)))
            curv = math.acos(a) / math.pi
        eff = base / (1.0 + scn.qsd_field_silhouette_boost * sil + scn.qsd_field_curvature_boost * curv)
        return max(1.0, eff)

    
    def _rebuild_kd(self, bm, scn):
        """Rebuild KD trees used by Field Paint for snapping/guards."""
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
        except Exception:
            pass

        # All verts
        self._bm_vert_list = list(bm.verts)
        if self._bm_vert_list:
            kd = KDTree(len(self._bm_vert_list))
            for i, v in enumerate(self._bm_vert_list):
                kd.insert(v.co, i)
            kd.balance()
            self._bm_vert_kd = kd
        else:
            self._bm_vert_kd = None

        # Boundary verts
        bverts = []
        if scn.qsd_field_boundary_only:
            for v in bm.verts:
                for e in v.link_edges:
                    if len(e.link_faces) == 1:
                        bverts.append(v)
                        break
        else:
            bverts = self._bm_vert_list

        self._bm_boundary_list = bverts
        if bverts:
            kd2 = KDTree(len(bverts))
            for i, v in enumerate(bverts):
                kd2.insert(v.co, i)
            kd2.balance()
            self._bm_boundary_kd = kd2
        else:
            self._bm_boundary_kd = None

        # Boundary/all edges (for edge snapping & boundary tracing)
        try:
            all_edges = list(bm.edges)
            if scn.qsd_field_boundary_only:
                bedges = [e for e in all_edges if len(e.link_faces) == 1]
            else:
                bedges = all_edges
        except Exception:
            all_edges = list(bm.edges)
            bedges = all_edges

        self._bm_boundary_edges = bedges
        if bedges:
            kdE = KDTree(len(bedges))
            for i, e in enumerate(bedges):
                mid = (e.verts[0].co + e.verts[1].co) * 0.5
                kdE.insert(mid, i)
            kdE.balance()
            self._bm_boundary_edge_kd = kdE
        else:
            self._bm_boundary_edge_kd = None

        # Edge midpoints (for local intersection guard)
        edges = all_edges
        self._edge_mid_edges = edges
        if edges:
            kd3 = KDTree(len(edges))
            for i, e in enumerate(edges):
                mid = (e.verts[0].co + e.verts[1].co) * 0.5
                kd3.insert(mid, i)
            kd3.balance()
            self._edge_mid_kd = kd3
        else:
            self._edge_mid_kd = None

    def _snap_to_boundary_vertex(self, context, obj, bm, region, rv3d, point_w):
        scn = context.scene
        snap_px = int(scn.qsd_field_edge_snap_px)
        if snap_px <= 0 or self._bm_boundary_kd is None or not self._bm_boundary_list:
            return None, None, None

        wpp = _qsd_estimate_world_per_pixel(region, rv3d, point_w)
        if wpp <= 0.0:
            return None, None, None

        snap_dist_w = wpp * float(snap_px)
        # Approx local conversion using average object scale
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s = 1.0
        snap_dist_l = snap_dist_w / s

        inv = obj.matrix_world.inverted()
        p_l = inv @ point_w

        co, idx, dist = self._bm_boundary_kd.find(p_l)
        if idx is None or dist is None or dist > snap_dist_l:
            return None, None, None

        v = self._bm_boundary_list[idx]
        v_w = obj.matrix_world @ v.co

        # boundary direction (world) for tracing
        d_l = Vector((0, 0, 0))
        for e in v.link_edges:
            if len(e.link_faces) == 1:
                ov = e.other_vert(v)
                vec = (ov.co - v.co)
                if vec.length > 1e-12:
                    d_l += vec.normalized()
        if d_l.length < 1e-12:
            d_l = v.normal.orthogonal()
        d_l.normalize()
        d_w = (obj.matrix_world.to_3x3() @ d_l).normalized()
        return v_w, v, d_w

    def _snap_to_boundary_edge(self, context, obj, bm, region, rv3d, point_w):
        """Snap a world point to the nearest (boundary/all) edge segment within EdgeSnap(px)."""
        scn = context.scene
        snap_px = int(getattr(scn, "qsd_field_edge_snap_px", 0))
        if snap_px <= 0 or self._bm_boundary_edge_kd is None or not self._bm_boundary_edges:
            return None, None, None

        wpp = _qsd_estimate_world_per_pixel(region, rv3d, point_w)
        if wpp <= 0.0:
            return None, None, None

        snap_dist_w = wpp * float(snap_px)
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s = 1.0
        snap_dist_l = snap_dist_w / s

        inv = obj.matrix_world.inverted()
        p_l = inv @ point_w

        best_e = None
        best_q = None
        best_d = None

        search_r = max(snap_dist_l * 2.0, 1e-6)
        tol2 = snap_dist_l * snap_dist_l

        for co, ei, dd in self._bm_boundary_edge_kd.find_range(p_l, search_r):
            e = self._bm_boundary_edges[ei]
            if getattr(scn, "qsd_field_boundary_only", False) and len(e.link_faces) != 1:
                continue
            a = e.verts[0].co
            b = e.verts[1].co
            ab = b - a
            denom = ab.dot(ab)
            if denom < 1e-20:
                continue
            t = (p_l - a).dot(ab) / denom
            if t < 0.0:
                t = 0.0
            elif t > 1.0:
                t = 1.0
            q = a + ab * t
            d2 = (p_l - q).length_squared
            if d2 <= tol2 and (best_d is None or d2 < best_d):
                best_d = d2
                best_e = e
                best_q = q

        if best_e is None or best_q is None:
            return None, None, None

        obj3 = obj.matrix_world.to_3x3()
        ed = (best_e.verts[1].co - best_e.verts[0].co)
        if ed.length < 1e-12:
            ed = Vector((1.0, 0.0, 0.0))
        ed.normalize()
        d_w = (obj3 @ ed).normalized()
        q_w = obj.matrix_world @ best_q
        return q_w, best_e, d_w

    def _snap_to_boundary_auto(self, context, obj, bm, region, rv3d, point_w):
        """Auto snap helper: prefer edge snap when enabled, fallback to vertex snap."""
        scn = context.scene
        use_edges = bool(getattr(scn, "qsd_field_edge_snap_to_edges", True))
        if use_edges:
            sw, src, dw = self._snap_to_boundary_edge(context, obj, bm, region, rv3d, point_w)
            if sw is not None:
                return sw, src, dw
        return self._snap_to_boundary_vertex(context, obj, bm, region, rv3d, point_w)

    def _maybe_trace_boundary(self, context, obj, bm, region, rv3d, center_w, tangent_w):
        scn = context.scene
        if not scn.qsd_field_trace_boundary:
            return center_w, tangent_w
        snapped, _src, d_w = self._snap_to_boundary_auto(context, obj, bm, region, rv3d, center_w)
        if snapped is None or d_w is None:
            return center_w, tangent_w
        # blend tangent with boundary direction (separate strength from guide strength)
        s = 0.85
        try:
            s = max(0.0, min(1.0, float(getattr(scn, "qsd_field_boundary_strength", 0.85))))
        except Exception:
            pass
        if tangent_w is None:
            t = d_w.normalized()
        else:
            t = (tangent_w.lerp(d_w, s)).normalized()
        return snapped, t

    def _live_merge_find(self, bm, point_l, dist_l):
        if self._bm_vert_kd is None or not self._bm_vert_list or dist_l <= 0.0:
            return None
        co, idx, d = self._bm_vert_kd.find(point_l)
        if idx is None or d is None or d > dist_l:
            return None
        return self._bm_vert_list[idx]

    def _guard_intersection(self, obj, bm, created_verts, created_faces, tol_l):
        """Local, conservative intersection guard. Returns True if intersection risk detected."""
        if tol_l <= 0.0 or self._edge_mid_kd is None or not self._edge_mid_edges:
            return False

        cand_edges = set()
        for f in created_faces:
            for e in f.edges:
                cand_edges.add(e)

        if not cand_edges:
            return False

        # AABB of created verts
        mins = Vector((1e20, 1e20, 1e20))
        maxs = Vector((-1e20, -1e20, -1e20))
        for v in created_verts:
            c = v.co
            mins.x = min(mins.x, c.x); mins.y = min(mins.y, c.y); mins.z = min(mins.z, c.z)
            maxs.x = max(maxs.x, c.x); maxs.y = max(maxs.y, c.y); maxs.z = max(maxs.z, c.z)
        pad = tol_l * 8.0
        mins -= Vector((pad, pad, pad))
        maxs += Vector((pad, pad, pad))

        def in_aabb(vco):
            return (mins.x <= vco.x <= maxs.x) and (mins.y <= vco.y <= maxs.y) and (mins.z <= vco.z <= maxs.z)

        tol2 = tol_l * tol_l
        search_r = max(tol_l * 12.0, 0.01)

        for ce in cand_edges:
            a = ce.verts[0].co
            b = ce.verts[1].co
            mid = (a + b) * 0.5
            for co, ei, d in self._edge_mid_kd.find_range(mid, search_r):
                e = self._edge_mid_edges[ei]
                if e in cand_edges:
                    continue
                # Skip edges outside local area quickly
                if not (in_aabb(e.verts[0].co) or in_aabb(e.verts[1].co)):
                    continue
                # Skip if sharing verts (connected)
                if (e.verts[0] in ce.verts) or (e.verts[1] in ce.verts):
                    continue
                c = e.verts[0].co
                d0 = e.verts[1].co
                dsq, _, _ = _qsd_seg_seg_dist_sq(a, b, c, d0)
                if dsq < tol2:
                    return True
        return False

    def _auto_fill_on_finish(self, context, obj, bm):
        scn = context.scene
        if not scn.qsd_field_auto_fill_on_finish:
            return

        tgt = _qsd_get_target(context)
        if not tgt or self._tgt_bvh is None:
            return

        # collect boundary edges touching created geometry
        created = set()
        for step in self._stack:
            for v in step.get("verts", []):
                created.add(v)
        if not created:
            return

        bedges = [e for e in bm.edges if len(e.link_faces) == 1 and (e.verts[0] in created or e.verts[1] in created)]
        if len(bedges) < 4:
            return

        # build vertex->edges adjacency
        v2e = {}
        for e in bedges:
            for v in e.verts:
                v2e.setdefault(v, []).append(e)

        used = set()
        loops = []
        for e0 in bedges:
            if e0 in used:
                continue
            loop = []
            used.add(e0)
            loop.append(e0)
            v_start = e0.verts[0]
            v_prev = e0.verts[0]
            v_curr = e0.verts[1]
            closed = False
            for _ in range(10000):
                if v_curr == v_start:
                    closed = True
                    break
                cands = [e for e in v2e.get(v_curr, []) if e not in used]
                if not cands:
                    break
                # choose edge that doesn't go back to previous if possible
                ne = cands[0]
                if len(cands) > 1:
                    for e in cands:
                        ov = e.other_vert(v_curr)
                        if ov != v_prev:
                            ne = e
                            break
                used.add(ne)
                loop.append(ne)
                v_next = ne.other_vert(v_curr)
                v_prev, v_curr = v_curr, v_next
            if closed and len(loop) >= 4:
                loops.append(loop)

        if not loops:
            return

        # choose largest loop
        loop_edges = max(loops, key=lambda L: len(L))
        if len(loop_edges) < 4:
            return

        # estimate span
        boundary_verts = list({v for e in loop_edges for v in e.verts})
        avg_len = 0.0
        cnt = 0
        for e in loop_edges:
            avg_len += (e.verts[0].co - e.verts[1].co).length
            cnt += 1
        avg_len = (avg_len / cnt) if cnt else 0.01

        span = int(scn.qsd_field_fill_span)
        if span <= 0:
            span = _qsd_estimate_span_pca([obj.matrix_world @ v.co for v in boundary_verts], avg_len, 64)

        # run grid fill
        try:
            res = bmesh.ops.grid_fill(bm, edges=loop_edges, span=span)
        except Exception:
            return

        new_verts = [g for g in res.get("geom", []) if isinstance(g, bmesh.types.BMVert)]
        # relax new verts (boundary fixed)
        iters = int(scn.qsd_field_fill_relax_iters)
        strength = float(scn.qsd_field_fill_relax_strength)
        if iters > 0 and new_verts and strength > 0.0:
            new_set = set(new_verts)
            boundary_set = set(boundary_verts)
            for _ in range(iters):
                targets = {}
                for v in new_verts:
                    if v in boundary_set:
                        continue
                    avg = Vector((0,0,0))
                    n = 0
                    for e in v.link_edges:
                        ov = e.other_vert(v)
                        avg += ov.co
                        n += 1
                    if n:
                        avg /= n
                        targets[v] = v.co.lerp(avg, strength)
                for v, co in targets.items():
                    v.co = co

        # project new verts
        inv = obj.matrix_world.inverted()
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        for v in new_verts:
            w = obj.matrix_world @ v.co
            loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, w)
            if loc_w is None:
                continue
            if maxd > 0.0 and dist > maxd:
                continue
            v.co = inv @ (loc_w + n_w * offset)
    def _project_w(self, tgt, wpoint):
        scn = bpy.context.scene
        offset = _cm_to_bu(scn.qsd_retopo_offset)
        maxd = _cm_to_bu(scn.qsd_retopo_project_max_dist)
        loc_w, n_w, dist = _qsd_target_nearest(tgt, self._tgt_bvh, wpoint)
        if loc_w is None:
            return None, None
        if maxd > 0.0 and dist > maxd:
            return None, None
        return (loc_w + n_w * offset), n_w

    
    def _make_ring(self, context, obj, bm, region, rv3d, inv, loc_w, n_w, tangent_w, side_prev):
        scn = context.scene
        tgt = _qsd_get_target(context)
        cols = max(1, int(scn.qsd_field_columns))
        width = _cm_to_bu(float(scn.qsd_field_width))

        # guide alignment
        if scn.qsd_field_align_guides:
            gdir = _qsd_nearest_guide_dir(obj, bm, loc_w, radius=max(0.01, width*2.0))
            if gdir is not None:
                s = max(0.0, min(1.0, scn.qsd_field_guide_strength))
                tangent_w = (tangent_w.lerp(gdir, s)).normalized()

        side = n_w.cross(tangent_w)
        if side.length < 1e-12:
            side = n_w.orthogonal()
        side.normalize()
        if side_prev is not None and side.dot(side_prev) < 0.0:
            side = -side

        # live merge distance in local space
        live_merge = bool(scn.qsd_field_live_merge)
        merge_dist_w = _cm_to_bu(scn.qsd_field_live_merge_dist)
        try:
            sx, sy, sz = obj.matrix_world.to_scale()
            s_avg = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
        except Exception:
            s_avg = 1.0
        merge_dist_l = (merge_dist_w / s_avg) if s_avg > 1e-8 else merge_dist_w

        ring = []
        for i in range(cols + 1):
            t = i / cols
            off = (t - 0.5) * width
            p_w = loc_w + side * off
            p_w2, _n2 = self._project_w(tgt, p_w)
            if p_w2 is None:
                p_w2 = p_w

            # endpoint snap to boundary (vertex/edge)
            if i == 0 or i == cols:
                snapped, _src, _d = self._snap_to_boundary_auto(context, obj, bm, region, rv3d, p_w2)
                if snapped is not None:
                    p_w2 = snapped

            p_l = inv @ p_w2

            if live_merge and merge_dist_l > 0.0:
                ex = self._live_merge_find(bm, p_l, merge_dist_l)
                if ex is not None:
                    ring.append(ex)
                    continue

            v = bm.verts.new(p_l)
            ring.append(v)

        return ring, side

    def _connect_rings(self, obj, bm, ring_a, ring_b):
        cols = len(ring_a) - 1
        created_faces = []
        for i in range(cols):
            v0 = ring_a[i]
            v1 = ring_a[i+1]
            v2 = ring_b[i+1]
            v3 = ring_b[i]
            try:
                f = bm.faces.new((v0, v1, v2, v3))
                created_faces.append(f)
            except ValueError:
                pass
        return created_faces

    def _undo_last(self, context):
        if not self._stack:
            return
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        step = self._stack.pop()
        geom = []
        geom.extend(step.get("faces", []))
        geom.extend(step.get("verts", []))
        try:
            bmesh.ops.delete(bm, geom=geom, context="FACES")
        except Exception:
            # fallback: delete verts
            try:
                bmesh.ops.delete(bm, geom=geom, context="VERTS")
            except Exception:
                pass
        if self._rings:
            self._rings.pop()
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)

    def _finish(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        scn = context.scene
        # Optional: try to close and fill the painted region on finish
        try:
            self._auto_fill_on_finish(context, obj, bm)
        except Exception:
            pass
        if scn.qsd_field_auto_stitch and _cm_to_bu(scn.qsd_field_merge_dist) > 0.0:
            try:
                bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=_cm_to_bu(scn.qsd_field_merge_dist))
            except Exception:
                pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        self._cleanup()
        return {'FINISHED'}

    def _cancel(self, context):
        # delete everything created in this operator
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        geom = []
        for step in self._stack:
            geom.extend(step.get("faces", []))
            geom.extend(step.get("verts", []))
        if geom:
            try:
                bmesh.ops.delete(bm, geom=geom, context="FACES")
            except Exception:
                try:
                    bmesh.ops.delete(bm, geom=geom, context="VERTS")
                except Exception:
                    pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        self._cleanup()
        return {'CANCELLED'}

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'RIGHTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            return self._finish(context)
        if event.type == 'ESC':
            return self._cancel(context)
        if event.type in {'BACK_SPACE'} or (event.type == 'Z' and event.ctrl and event.value == 'PRESS'):
            self._undo_last(context)
            return {'RUNNING_MODAL'}

        # update region in quad-view while not drawing
        if event.type == 'MOUSEMOVE':
            reg = _get_region_under_mouse(context.area, event.mouse_x, event.mouse_y)
            if reg:
                self._active_region = reg
                self._active_rv3d = reg.data

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self._stroke = True
            self._last_mouse = None
            self._last_loc = None
            self._last_n = None
            self._last_side = None
            self._last_tangent = None
            self._rings.clear()
            self._stack.clear()
            self._kd_rebuild_counter = 0
            self._guard_reported = False
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._stroke = False
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE' and self._stroke:
            origin_w, dir_w, region, rv3d, mouse2d = self._mouse_ray_world(context, event)
            tgt = _qsd_get_target(context)
            loc_w, n_w, dist = _qsd_target_raycast(tgt, self._tgt_bvh, origin_w, dir_w, frontface_only=context.scene.qsd_retopo_frontface_only)
            if loc_w is None:
                return {'RUNNING_MODAL'}

            spacing = self._effective_spacing_px(rv3d, n_w)
            if self._last_mouse is not None:
                if (mouse2d - self._last_mouse).length < spacing:
                    return {'RUNNING_MODAL'}

            # sample accepted
            self._last_mouse = mouse2d.copy()
            # project center point
            center_w, n2 = self._project_w(tgt, loc_w)
            if center_w is None:
                center_w = loc_w
                n2 = n_w

            if self._last_loc is None:
                # first ring: tangent along view vector
                tangent = _get_view_vector(rv3d)
            else:
                tangent = (center_w - self._last_loc)
                if tangent.length < 1e-6:
                    return {'RUNNING_MODAL'}
                tangent.normalize()

            
            obj = context.active_object
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            scn = context.scene
            if (self._kd_rebuild_counter % 4) == 0:
                self._rebuild_kd(bm, scn)

            inv = obj.matrix_world.inverted()

            # Boundary trace (optional): snap center to nearby boundary and align flow direction
            center_w, tangent = self._maybe_trace_boundary(context, obj, bm, region, rv3d, center_w, tangent)
            # Re-project center after snapping
            center_w2, n3 = self._project_w(tgt, center_w)
            if center_w2 is not None:
                center_w = center_w2
                if n3 is not None:
                    n2 = n3

            # Tangent inertia: keep a stable flow direction (reduces jitter)
            try:
                inert = float(getattr(scn, "qsd_field_tangent_inertia", 0.6))
            except Exception:
                inert = 0.6
            inert = max(0.0, min(1.0, inert))
            if tangent is not None and self._last_tangent is not None:
                if tangent.dot(self._last_tangent) < 0.0:
                    tangent = -tangent
                try:
                    tangent = (tangent.lerp(self._last_tangent, inert)).normalized()
                except Exception:
                    pass
            if tangent is not None:
                self._last_tangent = tangent.copy()

            ring, side = self._make_ring(context, obj, bm, region, rv3d, inv, center_w, n2, tangent, self._last_side)
            created = {"verts": list(ring), "faces": []}

            if self._rings:
                prev = self._rings[-1]
                faces = self._connect_rings(obj, bm, prev, ring)
                created["faces"] = faces

            # Local intersection guard (conservative)
            if scn.qsd_field_stop_on_intersect and float(scn.qsd_field_intersect_tol) > 0.0 and created["faces"]:
                tol_w = _cm_to_bu(float(scn.qsd_field_intersect_tol))
                try:
                    sx, sy, sz = obj.matrix_world.to_scale()
                    s_avg = max(1e-8, (abs(sx) + abs(sy) + abs(sz)) / 3.0)
                except Exception:
                    s_avg = 1.0
                tol_l = tol_w / s_avg if s_avg > 1e-8 else tol_w

                if self._guard_intersection(obj, bm, created["verts"], created["faces"], tol_l):
                    # rollback this step
                    try:
                        bmesh.ops.delete(bm, geom=created["faces"] + created["verts"], context="FACES")
                    except Exception:
                        try:
                            bmesh.ops.delete(bm, geom=created["verts"], context="VERTS")
                        except Exception:
                            pass
                    if not self._guard_reported:
                        self._guard_reported = True
                        self.report({'WARNING'}, _T("REPORT_INTERSECTION_GUARD"))
                    self._stroke = False
                    bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
                    return {'RUNNING_MODAL'}

            self._rings.append(ring)
            self._stack.append(created)
            self._kd_rebuild_counter += 1
            self._last_loc = center_w
            self._last_n = n2
            self._last_side = side

            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)

        return {'RUNNING_MODAL'}

class MESH_OT_qsd_set_target_from_selection(Operator):
    bl_idname = "mesh.qsd_set_target_from_selection"
    bl_label = _EN("BTN_SET_FROM_SELECTION")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_SET_TARGET_FROM_SELECTION")

    def execute(self, context):
        candidate = _qsd_pick_selected_target(context, allow_active_fallback=True)
        if candidate is None:
            self.report({'ERROR'}, _T("REPORT_NO_USABLE_TARGET_SELECTION"))
            return {'CANCELLED'}
        if not _qsd_assign_target(context.scene, candidate):
            self.report({'ERROR'}, _T("REPORT_ASSIGN_TARGET_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _TT("REPORT_TARGET_SET", name=candidate.name))
        return {'FINISHED'}

class MESH_OT_qsd_use_active_as_target(Operator):
    bl_idname = "mesh.qsd_use_active_as_target"
    bl_label = _EN("BTN_USE_ACTIVE_TARGET")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_USE_ACTIVE_TARGET")

    def execute(self, context):
        active = getattr(context, "active_object", None)
        if not _qsd_is_valid_target(context, active, active, allow_active=True):
            self.report({'ERROR'}, _T("REPORT_ACTIVE_NOT_USABLE_TARGET"))
            return {'CANCELLED'}
        if not _qsd_assign_target(context.scene, active):
            self.report({'ERROR'}, _T("REPORT_ASSIGN_ACTIVE_TARGET_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _TT("REPORT_TARGET_SET_ACTIVE", name=active.name))
        return {'FINISHED'}

class MESH_OT_qsd_clear_retopo_target(Operator):
    bl_idname = "mesh.qsd_clear_retopo_target"
    bl_label = _EN("BTN_CLEAR_TARGET")
    bl_options = {'UNDO'}
    bl_description = _EN("TIP_OP_CLEAR_TARGET")

    def execute(self, context):
        try:
            context.scene.qsd_retopo_target = None
        except Exception:
            self.report({'ERROR'}, _T("REPORT_TARGET_CLEAR_FAILED"))
            return {'CANCELLED'}
        self.report({'INFO'}, _T("REPORT_TARGET_CLEARED"))
        return {'FINISHED'}
