"""Scene property registration for Draw Quad Strip."""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty

from .localization import _EN
from .common import _qsd_update_draw_toggle


def register_scene_properties():
    unregister_scene_properties()
    bpy.types.Scene.qsd_draw_toggle = BoolProperty(
        name=_EN("BTN_START"),
        default=False,
        update=_qsd_update_draw_toggle,
        description=_EN("TIP_OP_START"),
        options={'SKIP_SAVE'},
    )
    bpy.types.Scene.qsd_width = FloatProperty(
        name=_EN("PROP_WIDTH"),
        default=2.0,
        min=0.1,
        description=_EN("TIP_WIDTH"),
    )
    bpy.types.Scene.qsd_thickness = FloatProperty(
        name=_EN("PROP_THICKNESS"),
        default=2.0,
        min=0.1,
        description=_EN("TIP_THICKNESS"),
    )
    bpy.types.Scene.qsd_subdivisions = IntProperty(
        name=_EN("PROP_SEGMENTS"),
        default=0,
        min=0,
        max=32,
        description=_EN("TIP_SEGMENTS"),
    )
    bpy.types.Scene.qsd_use_solidify = BoolProperty(
        name=_EN("PROP_SOLIDIFY"),
        default=False,
        description=_EN("TIP_SOLIDIFY"),
    )
    bpy.types.Scene.qsd_use_surface_snap = BoolProperty(
        name=_EN("PROP_SNAP"),
        default=True,
        description=_EN("TIP_SNAP"),
    )
    bpy.types.Scene.qsd_strip_vertex_merge = BoolProperty(
        name=_EN("PROP_STRIP_VERTEX_MERGE"),
        default=True,
        description=_EN("TIP_STRIP_VERTEX_MERGE"),
    )
    bpy.types.Scene.qsd_strip_vertex_merge_distance = FloatProperty(
        name=_EN("PROP_STRIP_VERTEX_MERGE_DIST"),
        default=1.0,
        min=0.0,
        description=_EN("TIP_STRIP_VERTEX_MERGE_DIST"),
    )

    plane_items = [
        ('VIEW', _EN("PLANE_VIEW"), _EN("PLANE_VIEW_DESC")),
        ('X', _EN("PLANE_X"), _EN("PLANE_X_DESC")),
        ('Y', _EN("PLANE_Y"), _EN("PLANE_Y_DESC")),
        ('Z', _EN("PLANE_Z"), _EN("PLANE_Z_DESC")),
    ]
    bpy.types.Scene.qsd_plane_mode = EnumProperty(
        name=_EN("PROP_PLANE"),
        items=plane_items,
        default='VIEW',
        description=_EN("TIP_PLANE"),
    )

    bpy.types.Scene.qsd_retopo_mode = BoolProperty(
        name=_EN("PROP_RETOPO_MODE"),
        default=False,
        description=_EN("TIP_RETOPO_MODE"),
    )
    bpy.types.Scene.qsd_retopo_target = PointerProperty(
        name=_EN("PROP_RETOPO_TARGET"),
        type=bpy.types.Object,
        description=_EN("TIP_RETOPO_TARGET"),
    )
    bpy.types.Scene.qsd_retopo_offset = FloatProperty(
        name=_EN("PROP_RETOPO_OFFSET"),
        default=0.0,
        description=_EN("TIP_RETOPO_OFFSET"),
    )
    bpy.types.Scene.qsd_retopo_project_max_dist = FloatProperty(
        name=_EN("PROP_RETOPO_PROJECT_MAX_DIST"),
        default=0.0,
        min=0.0,
        description=_EN("TIP_RETOPO_PROJECT_MAX_DIST"),
    )
    bpy.types.Scene.qsd_retopo_frontface_only = BoolProperty(
        name=_EN("PROP_RETOPO_FRONTFACE_ONLY"),
        default=True,
        description=_EN("TIP_RETOPO_FRONTFACE_ONLY"),
    )
    bpy.types.Scene.qsd_retopo_snap_radius = IntProperty(
        name=_EN("PROP_RETOPO_SNAP_RADIUS"),
        default=12,
        min=2,
        max=120,
        description=_EN("TIP_RETOPO_SNAP_RADIUS"),
    )
    bpy.types.Scene.qsd_retopo_loop_step = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_STEP"),
        default=2.0,
        min=0.01,
        description=_EN("TIP_RETOPO_LOOP_STEP"),
    )
    bpy.types.Scene.qsd_retopo_loop_spacing_px = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_SPACING_PX"),
        default=18.0,
        min=1.0,
        description=_EN("TIP_RETOPO_LOOP_SPACING_PX"),
    )
    bpy.types.Scene.qsd_retopo_loop_flip = BoolProperty(
        name=_EN("PROP_RETOPO_LOOP_FLIP"),
        default=False,
        description=_EN("TIP_RETOPO_LOOP_FLIP"),
    )
    bpy.types.Scene.qsd_retopo_loop_make_faces = BoolProperty(
        name=_EN("PROP_RETOPO_LOOP_MAKE_FACES"),
        default=True,
        description=_EN("TIP_RETOPO_LOOP_MAKE_FACES"),
    )
    bpy.types.Scene.qsd_retopo_loop_merge_dist = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_RETOPO_LOOP_MERGE_DIST"),
    )
    bpy.types.Scene.qsd_retopo_loop_snap_px = IntProperty(
        name=_EN("PROP_RETOPO_LOOP_SNAP_PX"),
        default=14,
        min=0,
        max=120,
        description=_EN("TIP_RETOPO_LOOP_SNAP_PX"),
    )
    bpy.types.Scene.qsd_retopo_loop_lock_strength = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_LOCK_STRENGTH"),
        default=0.9,
        min=0.0,
        max=1.0,
        description=_EN("TIP_RETOPO_LOOP_LOCK_STRENGTH"),
    )
    bpy.types.Scene.qsd_retopo_loop_inertia = FloatProperty(
        name=_EN("PROP_RETOPO_LOOP_INERTIA"),
        default=0.6,
        min=0.0,
        max=1.0,
        description=_EN("TIP_RETOPO_LOOP_INERTIA"),
    )

    bpy.types.Scene.qsd_field_width = FloatProperty(
        name=_EN("PROP_FIELD_WIDTH"),
        default=10.0,
        min=0.01,
        description=_EN("TIP_FIELD_WIDTH"),
    )
    bpy.types.Scene.qsd_field_columns = IntProperty(
        name=_EN("PROP_FIELD_COLUMNS"),
        default=2,
        min=1,
        max=64,
        description=_EN("TIP_FIELD_COLUMNS"),
    )
    bpy.types.Scene.qsd_field_spacing_px = FloatProperty(
        name=_EN("PROP_FIELD_SPACING_PX"),
        default=12.0,
        min=1.0,
        description=_EN("TIP_FIELD_SPACING_PX"),
    )
    bpy.types.Scene.qsd_field_screen_adaptive = BoolProperty(
        name=_EN("PROP_FIELD_SCREEN_ADAPTIVE"),
        default=True,
        description=_EN("TIP_FIELD_SCREEN_ADAPTIVE"),
    )
    bpy.types.Scene.qsd_field_silhouette_boost = FloatProperty(
        name=_EN("PROP_FIELD_SILHOUETTE_BOOST"),
        default=1.0,
        min=0.0,
        max=10.0,
        description=_EN("TIP_FIELD_SILHOUETTE_BOOST"),
    )
    bpy.types.Scene.qsd_field_curvature_boost = FloatProperty(
        name=_EN("PROP_FIELD_CURVATURE_BOOST"),
        default=1.0,
        min=0.0,
        max=10.0,
        description=_EN("TIP_FIELD_CURVATURE_BOOST"),
    )
    bpy.types.Scene.qsd_field_align_guides = BoolProperty(
        name=_EN("PROP_FIELD_ALIGN_GUIDES"),
        default=True,
        description=_EN("TIP_FIELD_ALIGN_GUIDES"),
    )
    bpy.types.Scene.qsd_field_guide_strength = FloatProperty(
        name=_EN("PROP_FIELD_GUIDE_STRENGTH"),
        default=0.75,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_GUIDE_STRENGTH"),
    )
    bpy.types.Scene.qsd_field_auto_stitch = BoolProperty(
        name=_EN("PROP_FIELD_AUTO_STITCH"),
        default=True,
        description=_EN("TIP_FIELD_AUTO_STITCH"),
    )
    bpy.types.Scene.qsd_field_merge_dist = FloatProperty(
        name=_EN("PROP_FIELD_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_MERGE_DIST"),
    )
    bpy.types.Scene.qsd_field_edge_snap_px = IntProperty(
        name=_EN("PROP_FIELD_EDGE_SNAP_PX"),
        default=14,
        min=0,
        max=120,
        description=_EN("TIP_FIELD_EDGE_SNAP_PX"),
    )
    bpy.types.Scene.qsd_field_boundary_only = BoolProperty(
        name=_EN("PROP_FIELD_BOUNDARY_ONLY"),
        default=True,
        description=_EN("TIP_FIELD_BOUNDARY_ONLY"),
    )
    bpy.types.Scene.qsd_field_trace_boundary = BoolProperty(
        name=_EN("PROP_FIELD_TRACE_BOUNDARY"),
        default=True,
        description=_EN("TIP_FIELD_TRACE_BOUNDARY"),
    )
    bpy.types.Scene.qsd_field_edge_snap_to_edges = BoolProperty(
        name=_EN("PROP_FIELD_EDGE_SNAP_TO_EDGES"),
        default=True,
        description=_EN("TIP_FIELD_EDGE_SNAP_TO_EDGES"),
    )
    bpy.types.Scene.qsd_field_boundary_strength = FloatProperty(
        name=_EN("PROP_FIELD_BOUNDARY_STRENGTH"),
        default=0.85,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_BOUNDARY_STRENGTH"),
    )
    bpy.types.Scene.qsd_field_tangent_inertia = FloatProperty(
        name=_EN("PROP_FIELD_TANGENT_INERTIA"),
        default=0.6,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_TANGENT_INERTIA"),
    )
    bpy.types.Scene.qsd_field_live_merge = BoolProperty(
        name=_EN("PROP_FIELD_LIVE_MERGE"),
        default=True,
        description=_EN("TIP_FIELD_LIVE_MERGE"),
    )
    bpy.types.Scene.qsd_field_live_merge_dist = FloatProperty(
        name=_EN("PROP_FIELD_LIVE_MERGE_DIST"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_LIVE_MERGE_DIST"),
    )
    bpy.types.Scene.qsd_field_stop_on_intersect = BoolProperty(
        name=_EN("PROP_FIELD_STOP_ON_INTERSECT"),
        default=True,
        description=_EN("TIP_FIELD_STOP_ON_INTERSECT"),
    )
    bpy.types.Scene.qsd_field_intersect_tol = FloatProperty(
        name=_EN("PROP_FIELD_INTERSECT_TOL"),
        default=0.05,
        min=0.0,
        description=_EN("TIP_FIELD_INTERSECT_TOL"),
    )
    bpy.types.Scene.qsd_field_auto_fill_on_finish = BoolProperty(
        name=_EN("PROP_FIELD_AUTO_FILL_ON_FINISH"),
        default=False,
        description=_EN("TIP_FIELD_AUTO_FILL_ON_FINISH"),
    )
    bpy.types.Scene.qsd_field_fill_span = IntProperty(
        name=_EN("PROP_FIELD_FILL_SPAN"),
        default=0,
        min=0,
        max=64,
        description=_EN("TIP_FIELD_FILL_SPAN"),
    )
    bpy.types.Scene.qsd_field_fill_relax_iters = IntProperty(
        name=_EN("PROP_FIELD_FILL_RELAX_ITERS"),
        default=6,
        min=0,
        max=50,
        description=_EN("TIP_FIELD_FILL_RELAX_ITERS"),
    )
    bpy.types.Scene.qsd_field_fill_relax_strength = FloatProperty(
        name=_EN("PROP_FIELD_FILL_RELAX_STRENGTH"),
        default=0.35,
        min=0.0,
        max=1.0,
        description=_EN("TIP_FIELD_FILL_RELAX_STRENGTH"),
    )


def unregister_scene_properties():
    for attr in (
        'qsd_width', 'qsd_thickness', 'qsd_subdivisions', 'qsd_use_solidify', 'qsd_use_surface_snap',
        'qsd_plane_mode', 'qsd_draw_toggle', 'qsd_strip_vertex_merge', 'qsd_strip_vertex_merge_distance',
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass

    for attr in (
        'qsd_retopo_mode', 'qsd_retopo_target', 'qsd_retopo_offset', 'qsd_retopo_project_max_dist',
        'qsd_retopo_frontface_only', 'qsd_retopo_snap_radius', 'qsd_retopo_loop_step',
        'qsd_retopo_loop_spacing_px', 'qsd_retopo_loop_flip', 'qsd_retopo_loop_make_faces',
        'qsd_retopo_loop_merge_dist', 'qsd_retopo_loop_snap_px', 'qsd_retopo_loop_lock_strength',
        'qsd_retopo_loop_inertia', 'qsd_field_width', 'qsd_field_columns', 'qsd_field_spacing_px',
        'qsd_field_screen_adaptive', 'qsd_field_silhouette_boost', 'qsd_field_curvature_boost',
        'qsd_field_align_guides', 'qsd_field_guide_strength', 'qsd_field_edge_snap_px',
        'qsd_field_boundary_only', 'qsd_field_trace_boundary', 'qsd_field_edge_snap_to_edges',
        'qsd_field_boundary_strength', 'qsd_field_tangent_inertia', 'qsd_field_auto_stitch',
        'qsd_field_merge_dist', 'qsd_field_live_merge', 'qsd_field_live_merge_dist',
        'qsd_field_stop_on_intersect', 'qsd_field_intersect_tol', 'qsd_field_auto_fill_on_finish',
        'qsd_field_fill_span', 'qsd_field_fill_relax_iters', 'qsd_field_fill_relax_strength',
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
