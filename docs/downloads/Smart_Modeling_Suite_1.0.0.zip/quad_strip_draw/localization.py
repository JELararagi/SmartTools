# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for older Draw Quad Strip modules.

The bundled Draw Quad Strip code historically imported ``localization`` while
this package ships the implementation as ``translation``.  Re-exporting the
same symbols keeps all internal imports consistent without duplicating logic.
"""

from .translation import _EN, _T, _TT, CONST_TEXT

__all__ = ("_EN", "_T", "_TT", "CONST_TEXT")
