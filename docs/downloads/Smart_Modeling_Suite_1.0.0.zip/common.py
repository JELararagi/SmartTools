# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

import json
import os
import re
import sys
import fnmatch
from functools import lru_cache
from pathlib import Path

import bpy
from . import status_runtime as _status_runtime
from .bootstrap_common import (
    class_belongs_to_current_package as _common_class_belongs_to_current_package,
    class_is_owned_for_mutation as _common_class_is_owned_for_mutation,
    iter_exact_owned_classes as _common_iter_exact_owned_classes,
    safe_register_class as _common_safe_register_class,
    safe_unregister_class as _common_safe_unregister_class,
)
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

PACKAGE_ID = 'smart_modeling_suite'
ADDON_NAME = 'Smart_Modeling_Suite'
TOOL_LABEL_EN = 'Smart Modeling'
TOOL_LABEL_JA = 'スマートモデリング'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_NPANEL_STATE_SAVE_PROP = PACKAGE_ID + '_n_panel_state_save_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_ORIGINAL_UNREGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_PERSISTENCE_REGISTRATION_GUARD = False
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_APPLYING_PERSISTENT_SETTINGS = False
_PERSISTENCE_MSGBUS_OWNER = object()
_LAST_SCENE_POINTER = 0
_SCENE_RESTORE_PENDING = False
_SETTINGS_WRITE_BLOCKED = False
_SETTINGS_LOAD_ERROR = ''
_SETTINGS_WRITE_ERROR = ''
# Blender 5.1 can crash in panel_draw_header when add-ons replace header
# callbacks on already registered Panel RNA classes or when a header callback
# touches stale RNA during mode/scene changes. Smart Modeling keeps help
# buttons in panel bodies and removes package draw_header callbacks before
# registration instead of monkey-patching them at draw time.
_DISABLE_PACKAGE_PANEL_DRAW_HEADERS = True
_ENABLE_DYNAMIC_PANEL_HEADER_PATCH = False


def _suite_is_shutting_down() -> bool:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return isinstance(ns, dict) and bool(ns.get('SMART_MODELING_SUITE_SHUTTING_DOWN'))
    except Exception:
        return False

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Feature Toggles'): '常時機能切り替え',
    ('*', 'N-panel State Save'): 'Nパネル状態保存',
    ('*', 'Save every Smart Modeling Suite N-panel setting to Smart_Modeling_Suite/Smart_Modeling_Suite.json immediately when settings change.'): '設定を変えるたびに、N パネルの全設定を Smart_Modeling_Suite/Smart_Modeling_Suite.json にすぐ保存します。',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
    ('*', 'Vertex Slide'): '頂点スライド',
    ('*', 'Mesh Connect'): 'メッシュ接続',
    ('*', 'Mesh Align'): 'メッシュ整列',
    ('*', 'Crease Preset'): 'クリースプリセット',
    ('*', 'Open Crease Presets'): 'クリースプリセット',
    ('*', 'Quad Retopo'): 'クアッドリトポ',
    ('*', 'Modifier Companion'): 'モディファイア補助',
    ('*', 'Preferences not available'): 'プリファレンスは利用できません',
    ('*', 'Linked Delimit'): 'リンク範囲の区切り',
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated files stay below CONFIG/Smart_Modeling_Suite even when imports
    # fall back during early startup.
    try:
        from .storage import user_data_dir
        root = Path(user_data_dir(create=bool(create)))
    except Exception:
        try:
            from .utils import suite_user_dir
            root = Path(suite_user_dir(_STORAGE_DIRNAME, create=bool(create)))
        except Exception:
            version = '5.1'
            try:
                app_version = getattr(getattr(bpy, 'app', None), 'version', None)
                if app_version and len(app_version) >= 2:
                    version = f"{int(app_version[0])}.{int(app_version[1])}"
            except Exception:
                pass
            if sys.platform.startswith('win'):
                base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming'))
                root = base / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Modeling_Suite' / _STORAGE_DIRNAME
            else:
                root = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_Modeling_Suite' / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(bool(create_parent)).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _versioned_config_dir() -> Path:
    try:
        cfg = bpy.utils.user_resource('CONFIG')
        if cfg:
            path = Path(cfg)
            try:
                path.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
            return path
    except Exception:
        pass
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0))
        version_label = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
    except Exception:
        version_label = '5.1'
    if sys.platform.startswith('win'):
        base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming'))
        path = base / 'Blender Foundation' / 'Blender' / version_label / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version_label / 'config'
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def settings_dir() -> Path:
    """External Smart Modeling Suite settings directory under Blender config.

    On Windows Blender 5.1 this resolves to:
    C:/Users/<User>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Modeling_Suite
    """
    path = _versioned_config_dir() / 'Smart_Modeling_Suite'
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def settings_path():
    """External suite settings file in Blender's versioned config directory.

    On Windows Blender 5.1 this resolves to:
    C:/Users/<User>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Modeling_Suite/Smart_Modeling_Suite.json
    """
    path = settings_dir() / 'Smart_Modeling_Suite.json'
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def legacy_settings_paths():
    """Return older settings locations used before the dedicated folder."""
    paths = []
    try:
        legacy = _versioned_config_dir() / 'Smart_Modeling_Suite.json'
        if legacy != settings_path():
            paths.append(legacy)
    except Exception:
        pass
    return tuple(paths)


def _saved_bool(value, default=None):
    """Accept JSON booleans only; never treat strings such as "false" as true."""
    if isinstance(value, bool):
        return value
    return default


def settings_write_allowed() -> bool:
    """False while the canonical file is malformed and must be preserved."""
    return not bool(_SETTINGS_WRITE_BLOCKED)


def settings_load_error() -> str:
    return str(_SETTINGS_LOAD_ERROR or _SETTINGS_WRITE_ERROR or '')



def n_panel_state_save_enabled(context=None, *, allow_rna=True) -> bool:
    """Return whether continuous N-panel state saving is enabled.

    Blender 5.1 can call load_pre while RNA owners from the previous file are
    being torn down. Accessing AddonPreferences / WindowManager properties in
    that phase may crash inside Blender before Python can catch an exception, so
    file-backed settings are checked first and RNA access can be explicitly
    disabled by callers that run during file load.
    """
    # Core updates this canonical cache before invoking any save-side effect.
    # Using it first preserves saved OFF during startup while still observing a
    # live OFF/ON click in the same callback.
    try:
        core_module = sys.modules.get(f'{__package__}.core')
        cached = getattr(core_module, '_SMS_NPANEL_STATE_SAVE_CACHE', None) if core_module is not None else None
        if isinstance(cached, bool):
            return cached
    except Exception:
        pass
    # Prefer the canonical live N-panel control during ordinary UI callbacks.
    # Reading the cached file first returned the previous True value after the
    # user switched saving OFF, allowing integrated-tool callbacks to write.
    if allow_rna:
        try:
            ctx = context or getattr(bpy, 'context', None)
            wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
            state = getattr(wm, 'smart_modeling_suite_npanel_settings', None) if wm is not None else None
            if state is not None and hasattr(state, 'n_panel_state_save'):
                value = _saved_bool(getattr(state, 'n_panel_state_save'), None)
                if value is not None:
                    return value
        except Exception:
            pass
    try:
        data = _LOADED_SETTINGS or load_settings_file()
        if isinstance(data, dict):
            if 'n_panel_state_save' in data:
                value = _saved_bool(data.get('n_panel_state_save'), None)
                if value is not None:
                    return value
            if _NPANEL_STATE_SAVE_PROP in data:
                value = _saved_bool(data.get(_NPANEL_STATE_SAVE_PROP), None)
                if value is not None:
                    return value
            for root_name in ('window_manager', 'scene'):
                root = data.get(root_name)
                if isinstance(root, dict):
                    if 'n_panel_state_save' in root:
                        value = _saved_bool(root.get('n_panel_state_save'), None)
                        if value is not None:
                            return value
                    if _NPANEL_STATE_SAVE_PROP in root:
                        value = _saved_bool(root.get(_NPANEL_STATE_SAVE_PROP), None)
                        if value is not None:
                            return value
    except Exception:
        pass
    try:
        path = settings_path()
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict) and 'n_panel_state_save' in raw:
                value = _saved_bool(raw.get('n_panel_state_save'), None)
                if value is not None:
                    return value
    except Exception:
        pass
    if not allow_rna:
        return True
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import core as _sms_core
        prefs = _sms_core._sms_get_suite_prefs(ctx)
        if prefs is not None:
            return bool(getattr(prefs, 'n_panel_state_save'))
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else getattr(bpy.context, 'window_manager', None)
        if wm is not None:
            return bool(getattr(wm, _NPANEL_STATE_SAVE_PROP))
    except Exception:
        pass
    return True


def set_n_panel_state_save_enabled(value: bool, context=None, *, force_save=True) -> None:
    global _LOADED_SETTINGS
    ctx = context or getattr(bpy, 'context', None)
    value = bool(value)
    try:
        if not isinstance(_LOADED_SETTINGS, dict):
            _LOADED_SETTINGS = {}
        _LOADED_SETTINGS['n_panel_state_save'] = value
        wm_data = _LOADED_SETTINGS.setdefault('window_manager', {})
        if not isinstance(wm_data, dict):
            wm_data = {}
            _LOADED_SETTINGS['window_manager'] = wm_data
        wm_data[_NPANEL_STATE_SAVE_PROP] = value
    except Exception:
        pass
    try:
        from . import core as _sms_core
        prefs = _sms_core._sms_get_suite_prefs(ctx)
        if prefs is not None and hasattr(prefs, 'n_panel_state_save'):
            if bool(getattr(prefs, 'n_panel_state_save')) != value:
                setattr(prefs, 'n_panel_state_save', value)
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else getattr(bpy.context, 'window_manager', None)
        if wm is not None and hasattr(wm, _NPANEL_STATE_SAVE_PROP):
            if bool(getattr(wm, _NPANEL_STATE_SAVE_PROP)) != value:
                setattr(wm, _NPANEL_STATE_SAVE_PROP, value)
    except Exception:
        pass
    # Rebuild subscriptions immediately so turning the switch OFF removes all
    # property watchers in the same UI action, while turning it ON restores the
    # complete real-time persistence graph.
    try:
        sync_persistence_subscriptions(ctx)
    except Exception:
        pass
    try:
        core_module = sys.modules.get(f'{__package__}.core')
        sync_resources = getattr(core_module, '_sms_sync_settings_resident_resources', None) if core_module is not None else None
        if callable(sync_resources):
            sync_resources(value)
    except Exception:
        pass
    if force_save:
        try:
            save_persistent_settings(ctx, force=True, allow_disabled_transition=True)
        except Exception:
            pass

def _flush_core_npanel_settings(context=None):
    try:
        from . import core as _sms_core
    except Exception:
        return
    try:
        prefs = _sms_core._sms_get_suite_prefs(context or getattr(bpy, 'context', None))
        _sms_core._sms_capture_suite_panel_settings(context=context or getattr(bpy, 'context', None), prefs=prefs)
    except Exception:
        pass
    try:
        return _sms_core._sms_flush_panel_settings_save(force=True)
    except TypeError:
        try:
            return _sms_core._sms_flush_panel_settings_save()
        except Exception:
            return False
    except Exception:
        return False
    return False


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        try:
            from . import icon_runtime as _sms_icon_runtime
        except Exception:
            _sms_icon_runtime = None
        icons_dir = package_root() / 'icons'
        for name in ('header', 'help', 'clock'):
            if _sms_icon_runtime is not None:
                path = _sms_icon_runtime.resolve_icon_path(name)
            else:
                path = icons_dir / (name + '.png')
            if path.exists():
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            cleaned = {}
            for key, value in dict(extra).items():
                try:
                    msgid = str(key[1] if isinstance(key, tuple) and len(key) >= 2 else '')
                except Exception:
                    msgid = ''
                ja_text = str(value or '').strip()
                if not msgid or not ja_text:
                    continue
                if ja_text == 'プリファレンス not available':
                    ja_text = 'プリファレンスは利用できません'
                if ja_text.startswith('項目 '):
                    continue
                if 'スマートモデリング の機能説明です。' in ja_text:
                    continue
                if 'スマートモデリング の設定項目です。' in ja_text:
                    continue
                cleaned[key] = ja_text
            data.update(cleaned)
    except Exception:
        pass
    return {'ja_JP': data}


OPEN_HELP_POPUP_WIDTH = 680
# Popup margins, box borders and label padding reserved inside the popup body.
_OPEN_HELP_CONTENT_PADDING_PX = 72


def _wrap_lines(value, width_px, context=None):
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Measure each line with BLF (the same unscaled measurement the help popup
    # uses) so a label is split only when its drawn width would exceed the popup
    # body.  Japanese text has no spaces, so it is split by character.
    limit = max(40, int(width_px or 0))
    try:
        from . import help as _help
        lines = []
        for para in text_value.split('\n'):
            raw = para.strip()
            if not raw:
                lines.append('')
                continue
            lines.extend(_help._sms_wrap_help_text(raw, context=context, max_pixels=limit, min_pixels=40) or [raw])
        return lines
    except Exception:
        pass
    import textwrap
    import unicodedata
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wide = any(unicodedata.east_asian_width(ch) in ('W', 'F') for ch in raw)
        chars = max(8, int(limit / (12 if wide else 7)))
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=True, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    # context.region is the region the popup was opened from (sidebar or the
    # whole viewport), not the popup itself, so wrap against the popup width.
    width = OPEN_HELP_POPUP_WIDTH - _OPEN_HELP_CONTENT_PADDING_PX
    if icon != 'NONE':
        width -= 28
    first = True
    for line in _wrap_lines(value, width, context):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_MODELING_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_options = set()
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=OPEN_HELP_POPUP_WIDTH)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            from . import guide
            group = guide.get_group(topic)
        except Exception as exc:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help catalog could not be loaded: ' + str(exc)],
                'overview_ja': ['ヘルプカタログを読み込めませんでした: ' + str(exc)],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context))
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_MODELING_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Startup Runtime Toggle'
    bl_options = {'UNDO'}
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, str(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, str(exc))
        try:
            save_persistent_settings(context, force=False)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_MODELING_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_options = set()
    _sms_no_undo = True
    bl_description = 'Save current N-panel settings to versioned Blender config folder Smart_Modeling_Suite/Smart_Modeling_Suite.json and request Blender to save user preferences.'

    def execute(self, context):
        saved = bool(_flush_core_npanel_settings(context))
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        if saved:
            self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        elif not n_panel_state_save_enabled(context):
            self.report({'WARNING'}, text('N-panel State Save is disabled; the JSON file was not changed.', 'Nパネル状態保存が無効なため、JSONファイルは変更していません。', context))
        else:
            self.report({'ERROR'}, settings_load_error() or text('Settings could not be saved.', '設定を保存できませんでした。', context))
        return {'FINISHED'}


class SMART_MODELING_PT_always_on(bpy.types.Panel):
    bl_idname = 'SMART_MODELING_PT_always_on'
    bl_label = 'Startup Runtime Toggle'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        # Obsolete standalone panel.  The visible controls are embedded inside
        # the main Smart Modeling panel only.
        return False

    def draw_header(self, context):
        self.layout.label(text='', icon='TIME')

    def draw(self, context):
        draw_always_on_panel(self.layout, context)


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    # Do not inject generic operator properties here.  Older compatibility
    # code added ``mode``, ``action`` and ``topic`` to every Operator class.
    # Blender's automatic popup layout then exposed those unrelated fields
    # whenever a popup owner had no draw callback during its first lazy invoke,
    # producing malformed Smart Modeling popups.  Operators that need one of
    # these properties must declare it explicitly on their own class.
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls



def _safe_empty_panel_draw_header(self, context):
    return None

_SMART_MODELING_NATIVE_ROOT_IDS = frozenset(('VIEW3D_PT_sms_hub', 'IMAGE_PT_sms_hub', 'NODE_PT_sms_hub', 'SEQUENCER_PT_sms_hub', 'CLIP_PT_sms_hub', 'DOPESHEET_PT_sms_hub', 'GRAPH_PT_sms_hub', 'NLA_PT_sms_hub', 'TEXT_PT_sms_hub', 'FILEBROWSER_PT_sms_hub', 'SPREADSHEET_PT_sms_hub'))


def _is_single_visible_smart_modeling_root(cls) -> bool:
    try:
        identifiers = {
            str(getattr(cls, '__name__', '') or ''),
            str(getattr(cls, 'bl_idname', '') or ''),
        }
        return bool(identifiers.intersection(_SMART_MODELING_NATIVE_ROOT_IDS))
    except Exception:
        return False


def _should_skip_smart_modeling_panel_registration(cls) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        if not issubclass(cls, bpy.types.Panel):
            return False
    except Exception:
        return False
    if _is_single_visible_smart_modeling_root(cls):
        return False
    try:
        if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
            return False
        module_name = str(getattr(cls, '__module__', '') or '')
        category = str(getattr(cls, 'bl_category', '') or '')
    except Exception:
        return False
    return ('smart_modeling_suite' in module_name) or category == PANEL_CATEGORY


def _mark_smart_modeling_panel_hidden(cls) -> None:
    if not _common_class_is_owned_for_mutation(cls):
        return
    try:
        cls.poll = classmethod(lambda _cls, _context: False)
    except Exception:
        pass
    try:
        cls.draw = _safe_empty_panel_draw_header
        cls.draw_header = _safe_empty_panel_draw_header
    except Exception:
        pass
    try:
        setattr(cls, '_sms_skip_sidebar_registration', True)
        setattr(cls, '_sms_hidden_from_top_level_npanel', True)
    except Exception:
        pass


def _sanitize_panel_header_before_register(cls):
    if not _common_class_belongs_to_current_package(cls):
        return cls
    if not _DISABLE_PACKAGE_PANEL_DRAW_HEADERS or not isinstance(cls, type):
        return cls
    try:
        is_panel = issubclass(cls, bpy.types.Panel)
    except Exception:
        is_panel = False
    if not is_panel:
        return cls
    if _should_skip_smart_modeling_panel_registration(cls):
        _mark_smart_modeling_panel_hidden(cls)
        return cls
    try:
        cls.bl_category = PANEL_CATEGORY
    except Exception:
        pass
    try:
        label = str(getattr(cls, 'bl_label', '') or '')
        clean = _clean_label(label)
        if clean and clean != label:
            cls.bl_label = clean
    except Exception:
        pass
    try:
        if _is_always_panel(cls):
            cls.poll = classmethod(lambda _cls, context: False)
    except Exception:
        pass
    try:
        original = cls.__dict__.get('draw_header', None)
    except Exception:
        original = None
    if original is None:
        return cls
    try:
        setattr(cls, '_smart_common_original_draw_header_disabled', original)
    except Exception:
        pass
    try:
        delattr(cls, 'draw_header')
    except Exception:
        try:
            cls.draw_header = _safe_empty_panel_draw_header
        except Exception:
            pass
    return cls




def _is_panel_class_51(cls) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        return bool(panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base))
    except Exception:
        return False


def _patch_panel_in_place_51(existing, source) -> bool:
    if not (_is_panel_class_51(existing) and isinstance(source, type)):
        return False
    if not _common_class_is_owned_for_mutation(existing) or not _common_class_belongs_to_current_package(source):
        return False
    for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_space_type', 'bl_region_type', 'bl_parent_id', 'bl_options', 'bl_order'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    return True




def _sms_final_exit_in_progress_51() -> bool:
    try:
        from .bootstrap_common import _sms_blender_exit_in_progress_51
        return bool(_sms_blender_exit_in_progress_51())
    except Exception:
        return False


def _registered_rna_class_51(cls):
    if not isinstance(cls, type):
        return None
    if _sms_final_exit_in_progress_51():
        return None
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type):
            try:
                getattr(existing, 'bl_rna')
                return existing
            except Exception:
                pass
    except Exception:
        pass
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    if not bl_idname:
        return None
    try:
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        candidates = {bl_idname, class_name}
        if bl_idname and '.' in bl_idname and '_OT_' in class_name:
            namespace = bl_idname.split('.', 1)[0].upper()
            _, suffix = class_name.split('_OT_', 1)
            if namespace and suffix:
                candidates.add(f'{namespace}_OT_{suffix}')
        for candidate in tuple(c for c in candidates if c):
            for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                try:
                    base = getattr(bpy.types, base_name, None)
                    getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                    if callable(getter):
                        existing = getter(candidate, None)
                        if isinstance(existing, type):
                            return existing
                except Exception:
                    pass
    except Exception:
        pass
    for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter):
                existing = getter(bl_idname, None)
                if isinstance(existing, type):
                    return existing
        except Exception:
            pass
    try:
        if bl_idname and '.' in bl_idname:
            namespace, opname = bl_idname.split('.', 1)
            op_ns = getattr(bpy.ops, namespace, None)
            op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
            get_rna_type = getattr(op_fn, 'get_rna_type', None)
            if callable(get_rna_type):
                try:
                    rna = get_rna_type()
                except Exception:
                    rna = None
                identifier = str(getattr(rna, 'identifier', '') or '').strip() if rna is not None else ''
                if identifier:
                    class_name = str(getattr(cls, '__name__', '') or '').strip()
                    candidates = {class_name}
                    opname_suffix = ''.join(ch if ch.isalnum() else '_' for ch in opname).strip('_')
                    if namespace and opname_suffix:
                        candidates.add(f'{namespace.upper()}_OT_{opname_suffix}')
                    if '_OT_' in class_name:
                        try:
                            _prefix, suffix = class_name.split('_OT_', 1)
                            if suffix:
                                candidates.add(f'{namespace.upper()}_OT_{suffix}')
                        except Exception:
                            pass
                    if identifier in candidates:
                        # Resolve the actual registered Python class.  Returning
                        # ``cls`` here is unsafe when another class with the same
                        # bl_idname is already registered: Blender then treats the
                        # source class as unregistered and register_class() silently
                        # replaces the live RNA type, which can invalidate open UI or
                        # modal operator pointers.
                        for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                            try:
                                base = getattr(bpy.types, base_name, None)
                                getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                                existing = getter(identifier, None) if callable(getter) else None
                                if isinstance(existing, type):
                                    return existing
                            except Exception:
                                pass
                        try:
                            existing = getattr(bpy.types, identifier, None)
                            if isinstance(existing, type):
                                getattr(existing, 'bl_rna')
                                return existing
                        except Exception:
                            pass
    except Exception:
        pass
    return None


def _patch_registered_class_namespace_51(existing, source) -> None:
    try:
        source_dict = dict(getattr(source, '__dict__', {}) or {})
    except Exception:
        return
    try:
        annotation_names = set((source_dict.get('__annotations__') or {}).keys())
    except Exception:
        annotation_names = set()
    skip = {
        '__dict__', '__weakref__', '__module__', '__doc__', '__annotations__',
        '__slots__', 'bl_rna', 'rna_type',
        '_sms_lazy_keymap_proxy', '_sms_lazy_tool_id', '_sms_lazy_target_idname',
    }
    for name, value in source_dict.items():
        if name in skip or name in annotation_names or name.startswith('__'):
            continue
        try:
            if callable(getattr(value, 'function', None)) and hasattr(value, 'keywords'):
                continue
        except Exception:
            pass
        try:
            setattr(existing, name, value)
        except Exception:
            pass


def _patch_registered_class_in_place_51(existing, source) -> bool:
    if not (isinstance(existing, type) and isinstance(source, type)):
        return False
    if not _common_class_is_owned_for_mutation(existing) or not _common_class_belongs_to_current_package(source):
        return False
    if _is_panel_class_51(existing):
        return _patch_panel_in_place_51(existing, source)
    _patch_registered_class_namespace_51(existing, source)
    try:
        setattr(existing, '_sms_patched_in_place_51', True)
    except Exception:
        pass
    return True

def _safe_unregister_class(cls):
    if _sms_final_exit_in_progress_51():
        return True
    before = _common_class_is_owned_for_mutation(cls)
    if not before:
        return False
    _common_safe_unregister_class(cls)
    return True

def _purge_standalone_always_on_panel():
    if _suite_is_shutting_down():
        return
    target = globals().get('SMART_MODELING_PT_always_on')
    if isinstance(target, type) and _common_class_is_owned_for_mutation(target):
        _common_safe_unregister_class(target)


def _strip_register_option_from_operator(cls):
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        if op_base is None or not isinstance(cls, type) or not issubclass(cls, op_base):
            return
        opts = set(getattr(cls, 'bl_options', set()) or set())
        # Undo support is required, but REGISTER forces Blender to serialize
        # operator reports/last-properties. Multiple user crash logs for Blender
        # 5.1.0 Windows entered WM_operator_pystring_ex,
        # WM_operator_last_properties_store, or Macro_properties_get immediately
        # after add-on operators completed. Remove REGISTER for every suite
        # operator at registration time; explicit undo_push calls in destructive
        # tools keep the user-facing undo stack intact.
        if bool(getattr(cls, '_sms_requires_register', False)):
            opts.add('REGISTER')
        else:
            opts.discard('REGISTER')
        opts.discard('UNDO_GROUPED')
        is_lazy_proxy = bool(getattr(cls, '_sms_lazy_keymap_proxy', False))
        preserve_lazy_undo = bool(getattr(cls, '_sms_lazy_proxy_preserve_undo', False))
        if bool(getattr(cls, '_sms_no_undo', False)) or (is_lazy_proxy and not preserve_lazy_undo):
            opts.discard('UNDO')
        else:
            opts.add('UNDO')
        cls.bl_options = opts
    except Exception:
        pass

def _flatten_npanel_parent_before_register(cls):
    """Keep all SmartTools N-panel sections horizontally aligned.

    Blender indents Panel classes that use ``bl_parent_id``.  In a deep or
    lazily loaded SmartTools UI this compounds every time a child/grandchild
    section is exposed.  Flatten only sidebar (``bl_region_type == 'UI'``)
    panels before registration; non-sidebar panels keep their native parents.
    """
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            if str(getattr(cls, 'bl_region_type', '') or '') == 'UI':
                if str(getattr(cls, 'bl_parent_id', '') or ''):
                    cls.bl_parent_id = ''
    except Exception:
        pass
    return cls


def _register_class_wrapper(cls):
    _flatten_npanel_parent_before_register(cls)
    _materialize_annotations(cls)
    _strip_register_option_from_operator(cls)
    try:
        _status_runtime.instrument_operator_class(cls, 'smart_modeling_suite', 'Smart Modeling Suite')
    except Exception:
        pass
    _sanitize_panel_header_before_register(cls)
    try:
        if _should_skip_smart_modeling_panel_registration(cls):
            _mark_smart_modeling_panel_hidden(cls)
            return None
    except Exception:
        pass
    _common_safe_register_class(cls)
    return None


def _unregister_class_wrapper(cls):
    if _common_class_is_owned_for_mutation(cls):
        _common_safe_unregister_class(cls)
    return None


def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _ORIGINAL_UNREGISTER_CLASS, _REGISTER_PATCH_DEPTH, _PERSISTENCE_REGISTRATION_GUARD
    _REGISTER_PATCH_DEPTH += 1
    if _REGISTER_PATCH_DEPTH == 1:
        # Read the external payload before native/integrated PropertyGroups are
        # registered. Blender 5.1 may invoke their update callbacks while it is
        # still assigning defaults; writes stay blocked until the complete RNA
        # graph has been restored below.
        load_settings_file()
        _PERSISTENCE_REGISTRATION_GUARD = True
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    try:
        _ORIGINAL_REGISTER_CLASS = bpy.utils.register_class
        _ORIGINAL_UNREGISTER_CLASS = bpy.utils.unregister_class
        bpy.utils.register_class = _register_class_wrapper
        bpy.utils.unregister_class = _unregister_class_wrapper
    except Exception:
        _ORIGINAL_REGISTER_CLASS = None
        _ORIGINAL_UNREGISTER_CLASS = None


def end_register():
    global _ORIGINAL_REGISTER_CLASS, _ORIGINAL_UNREGISTER_CLASS, _REGISTER_PATCH_DEPTH, _PERSISTENCE_REGISTRATION_GUARD
    was_active = _REGISTER_PATCH_DEPTH > 0
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    if _ORIGINAL_REGISTER_CLASS is not None:
        try:
            bpy.utils.register_class = _ORIGINAL_REGISTER_CLASS
        except Exception:
            pass
    if _ORIGINAL_UNREGISTER_CLASS is not None:
        try:
            bpy.utils.unregister_class = _ORIGINAL_UNREGISTER_CLASS
        except Exception:
            pass
    _ORIGINAL_REGISTER_CLASS = None
    _ORIGINAL_UNREGISTER_CLASS = None
    if not was_active:
        return
    try:
        apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        pass
    _PERSISTENCE_REGISTRATION_GUARD = False
    try:
        save_persistent_settings(getattr(bpy, 'context', None), force=False)
    except Exception:
        pass


def _iter_relevant_panels():
    for cls in _common_iter_exact_owned_classes(current_generation_only=False):
        if not isinstance(cls, type) or cls is SMART_MODELING_PT_always_on:
            continue
        try:
            if issubclass(cls, bpy.types.Panel):
                yield cls
        except Exception:
            continue


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    """Neutralize stale header monkey patches left by older in-place loads."""
    for cls in _iter_relevant_panels():
        if getattr(cls, '_smart_common_header_patched', False):
            try:
                cls.draw_header = _safe_empty_panel_draw_header
            except Exception:
                pass
            try:
                delattr(cls, '_smart_common_header_patched')
            except Exception:
                pass

def _unpatch_panel_headers():
    if _suite_is_shutting_down():
        _PATCHED_PANELS.clear()
        _PATCHED_POLLS.clear()
        return
    # Do not restore old header/poll callbacks during extension disable/reinstall.
    # Restoring stale callbacks immediately before Blender removes or redraws Panel
    # RNA can re-enter panel handlers and crash Blender 5.1.0 on Windows.
    for cls, _original in reversed(_PATCHED_PANELS):
        try:
            _mark_smart_modeling_panel_hidden(cls)
        except Exception:
            pass
    _PATCHED_PANELS.clear()
    for cls, _original in reversed(_PATCHED_POLLS):
        try:
            _mark_smart_modeling_panel_hidden(cls)
        except Exception:
            pass
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    for cls in _common_iter_exact_owned_classes(current_generation_only=False):
        if not isinstance(cls, type):
            continue
        try:
            if issubclass(cls, bpy.types.AddonPreferences):
                yield cls
        except Exception:
            continue


def _patch_addon_preferences():
    # Candidates come only from the exact ownership ledger.
    pass
    for cls in _iter_relevant_addon_preferences():
        if getattr(cls, '_smart_common_preferences_patched', False):
            continue
        original = getattr(cls, 'draw', None)

        def _draw_npanel_only(self, context):
            try:
                box = self.layout.box()
                box.label(text=text('Settings are managed in the N-panel.', '設定はNパネルで管理します。', context), icon='PREFERENCES')
                box.label(text=text('Open the 3D View Sidebar and use this tool tab.', '3Dビューのサイドバーを開き、このツールのタブを使用してください。', context))
            except Exception:
                pass

        try:
            cls.draw = _draw_npanel_only
            cls._smart_common_preferences_patched = True
            _PATCHED_PREFERENCES.append((cls, original))
        except Exception:
            pass


def _unpatch_addon_preferences():
    # Candidates come only from the exact ownership ledger.
    pass
    if _suite_is_shutting_down():
        _PATCHED_PREFERENCES.clear()
        return
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                if hasattr(cls, 'draw'):
                    delattr(cls, 'draw')
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


_SMART_ID_REFERENCE = '__pointer__'
_LEGACY_SMART_ID_REFERENCE = '__smart_id_reference__'
_SMART_ENUM_SET = '__smart_enum_set__'
_SMART_SEQUENCE = '__smart_sequence__'
_SMART_COLLECTION = '__smart_collection__'


_CONTRACT_VALUES_CACHE = {}
_CONTRACT_MATCHER_CACHE = {}
_GLOB_PATTERN_CHARS = frozenset('*?[')


def _contract_values(name: str) -> tuple[str, ...]:
    """Return one immutable contract tuple without rebuilding it per RNA field."""
    key = str(name or '')
    cached = _CONTRACT_VALUES_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        from . import unified_contract as _contract
        value = getattr(_contract, key, ())
        result = tuple(str(item) for item in value if str(item or '').strip())
    except Exception:
        result = ()
    _CONTRACT_VALUES_CACHE[key] = result
    return result


def _contract_matcher(name: str):
    """Split fixed roots from wildcard patterns while preserving semantics."""
    key = str(name or '')
    cached = _CONTRACT_MATCHER_CACHE.get(key)
    if cached is not None:
        return cached
    fixed = []
    wildcard = []
    for pattern in _contract_values(key):
        if any(char in pattern for char in _GLOB_PATTERN_CHARS):
            wildcard.append(pattern)
        else:
            fixed.append(pattern)
    result = (tuple(fixed), tuple(wildcard))
    _CONTRACT_MATCHER_CACHE[key] = result
    return result


def _matches_contract_path(path: str, matcher) -> bool:
    fixed, wildcard = matcher
    for root in fixed:
        if path == root or path.startswith(root + '.'):
            return True
    return any(fnmatch.fnmatchcase(path, pattern) for pattern in wildcard)


@lru_cache(maxsize=16384)
def _path_excluded(path: str) -> bool:
    path = str(path or '').strip()
    if not path:
        return False
    return _matches_contract_path(path, _contract_matcher('EXCLUDED_TRANSIENT_PATHS'))


@lru_cache(maxsize=16384)
def _path_persisted(path: str) -> bool:
    path = str(path or '').strip()
    if not path or _path_excluded(path):
        return False
    roots = _contract_matcher('PERSISTENCE_ROOTS')
    dynamic = _contract_matcher('PERSISTED_DYNAMIC_RNA_PATTERNS')
    return _matches_contract_path(path, roots) or _matches_contract_path(path, dynamic)


def _root_owner_path(owner) -> str:
    try:
        if isinstance(owner, bpy.types.Scene):
            return 'scene'
        if isinstance(owner, bpy.types.WindowManager):
            return 'window_manager'
        if isinstance(owner, bpy.types.Object):
            return 'object'
    except Exception:
        pass
    return ''


def _id_reference(value):
    try:
        if isinstance(value, bpy.types.ID):
            # RNA pointer records use ID.name, matching Blender's collection
            # lookup key and the live N-panel value.  name_full may add library
            # decoration that cannot be resolved through bpy.data.*.get().
            name = str(getattr(value, 'name', '') or getattr(value, 'name_full', '') or '').strip()
            identifier = str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or type(value).__name__).strip()
            if name:
                return {_SMART_ID_REFERENCE: identifier, 'name': name}
    except Exception:
        pass
    return None


def _serialize_rna_value(value, prop=None, depth=0, path=''):
    if depth > 5:
        return None
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    reference = _id_reference(value)
    if reference is not None:
        return reference
    if isinstance(value, (set, frozenset)):
        # Plain arrays are intentionally used in canonical JSON so every value
        # remains human-readable and exhaustive validation can compare it with
        # the live enum-flag set without knowing an internal marker schema.
        # ENUM_FLAG has no ordering contract.  Canonicalize its members so the
        # same choice produces byte-identical JSON in every Blender process.
        return sorted(str(item) for item in value)
    try:
        prop_type = str(getattr(prop, 'type', '') or '').upper()
    except Exception:
        prop_type = ''
    if prop_type == 'COLLECTION':
        items = []
        try:
            for index, item in enumerate(value):
                if index >= 2048:
                    break
                item_ref = _id_reference(item)
                serialized = item_ref if item_ref is not None else _serialize_group(item, depth + 1, path=path)
                if serialized is not None:
                    items.append(serialized)
        except Exception:
            pass
        return {_SMART_COLLECTION: items}
    if prop_type == 'POINTER' or _is_suite_group(value):
        return _serialize_group(value, depth + 1, path=path)
    try:
        if bool(getattr(prop, 'is_array', False)):
            return [item for item in value]
    except Exception:
        pass
    try:
        if isinstance(value, (list, tuple)):
            return {_SMART_SEQUENCE: list(value)}
    except Exception:
        pass
    return None


def _iter_setting_roots(context=None, *, include_scene=False):
    """Return persistent setting roots.

    Cross-file settings must never write scene-local data back into a newly
    opened .blend file.  Earlier builds persisted both WindowManager and Scene
    addon properties; applying those Scene values on load could fire update
    callbacks or restore stale tool state from a different file.  Keep only
    WindowManager roots by default.  Scene values belong to the .blend file and
    are intentionally excluded from this external settings store.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    wm = getattr(ctx, 'window_manager', None)
    if wm is not None:
        roots.append(('window_manager', wm))
    if include_scene:
        scene = _active_scene(ctx)
        if scene is not None:
            roots.append(('scene', scene))
    return roots


_ROOT_SETTING_PREFIXES = (
    'smart_', 'sms_', 'smsuite_', 'enable_', 'ui_show_', 'mo2_', 'vscp_',
    'svs_', 'qsd_', 'quad_', 'dd_', 'direct_delete_', 'mesh_align_',
    'msap_', 'connect_', 'smart_connect_', 'tams_', 'awn_', 'cp_', 'sfs_',
    'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'smod_', 'sps_', 'srs_',
    'srig_', 'ssel_', 'suv_', 'sw_', 'st_', 'sk_', 'sss_'
)

_TRANSIENT_SETTING_NAMES = {
    'svs_vertex_slide_constraint_enabled',
    'tams_state',
    'mo2_backup_items',
}


def _module_prefix() -> str:
    try:
        pkg = str(__package__ or PACKAGE_ID)
        return pkg
    except Exception:
        return PACKAGE_ID


def _is_suite_group(value) -> bool:
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        return bool(module_name and (module_name.startswith(prefix) or 'smart_modeling_suite' in module_name))
    except Exception:
        return False


def _is_root_owner(owner) -> bool:
    try:
        return isinstance(owner, (bpy.types.Scene, bpy.types.WindowManager, bpy.types.Object))
    except Exception:
        return False


def _root_prop_identifier_relevant(name: str, owner=None) -> bool:
    lower = str(name or '').lower()
    if not lower or lower == 'rna_type' or lower in _TRANSIENT_SETTING_NAMES:
        return False
    if lower == _ALWAYS_ON_PROP.lower() or lower == _NPANEL_STATE_SAVE_PROP.lower():
        return True
    if lower.startswith(PACKAGE_ID.lower()):
        return True
    owner_path = _root_owner_path(owner)
    if owner_path and _path_persisted(f'{owner_path}.{name}'):
        return True
    return any(lower.startswith(prefix) for prefix in _ROOT_SETTING_PREFIXES)


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower in _TRANSIENT_SETTING_NAMES:
        return False
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    if _is_suite_group(value):
        return True
    if _is_suite_group(owner):
        return True
    if _is_root_owner(owner):
        owner_path = _root_owner_path(owner)
        if owner_path and _path_persisted(f'{owner_path}.{name}'):
            return True
        return any(lower.startswith(prefix) for prefix in _ROOT_SETTING_PREFIXES)
    prefixes = _ROOT_SETTING_PREFIXES + ('show_', 'use_', 'auto_', 'uv_')
    return any(lower.startswith(prefix) for prefix in prefixes)


def _serialize_group(obj, depth=0, path=''):
    if depth > 5 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    root_owner = _is_root_owner(obj)
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier in {'rna_type', 'name'}:
                continue
            prop_type = str(getattr(prop, 'type', '') or '').upper()
            if getattr(prop, 'is_readonly', False) and prop_type not in {'POINTER', 'COLLECTION'}:
                continue
            item_path = f'{path}.{identifier}' if path else identifier
            if _path_excluded(item_path):
                continue
            # On Blender 5.1, even getattr() on unrelated WindowManager / Scene
            # RNA properties can enter stale operator/path resolution during file
            # load or panel redraw. Filter root identifiers before touching RNA.
            if root_owner and not _root_prop_identifier_relevant(identifier, obj):
                continue
            value = getattr(obj, identifier)
            if not _prop_relevant(identifier, value, obj):
                continue
            serialized = _serialize_rna_value(value, prop, depth + 1, item_path)
            # A cleared PointerProperty is still a real persisted setting.
            # Keep its explicit null key so canonical coverage can distinguish
            # "the user cleared this selector" from "this RNA was never
            # captured" and restore it across scene/file boundaries.
            if serialized is not None or prop_type == 'POINTER':
                data[identifier] = serialized
        except Exception:
            continue
    return data


def persistent_property_factory(factory):
    """Add immediate canonical persistence to a bundled N-panel RNA factory.

    Blender's message bus is an event-only safety net, but it is dispatched on
    the UI event loop and therefore is not a synchronous write boundary.  Lazy
    bundled tools use this wrapper while defining their PropertyGroups so every
    successful user edit writes the canonical JSON before control returns.
    Existing update callbacks retain their original behavior.
    """
    def _factory(*args, **kwargs):
        options = dict(kwargs)
        previous = options.get('update')

        def _update(self, context):
            previous_error = None
            if callable(previous):
                try:
                    previous(self, context)
                except Exception as exc:
                    previous_error = exc
            try:
                if not _APPLYING_PERSISTENT_SETTINGS:
                    save_persistent_settings(context or getattr(bpy, 'context', None), force=False)
            finally:
                # Preserve Blender's normal error reporting for a tool's own
                # callback while still committing the edited setting.
                if previous_error is not None:
                    raise previous_error

        options['update'] = _update
        return factory(*args, **options)

    return _factory


def _deep_merge_dict(base, update):
    result = dict(base) if isinstance(base, dict) else {}
    if not isinstance(update, dict):
        return result
    for key, value in update.items():
        if isinstance(value, dict) and (
            _SMART_ID_REFERENCE in value or _LEGACY_SMART_ID_REFERENCE in value
        ):
            # An ID reference is one atomic typed value, not a settings group.
            # Replacing it also removes the obsolete nested marker during the
            # first v1.3.22 write instead of retaining both schemas forever.
            result[key] = dict(value)
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge_dict(result.get(key), value)
        else:
            result[key] = value
    return result


def _scene_profile_name(scene) -> str:
    try:
        return str(getattr(scene, 'name_full', '') or getattr(scene, 'name', '') or 'Scene')
    except Exception:
        return 'Scene'


def _active_scene(context=None):
    """Return the scene selected by the active Blender window.

    Around scene/file changes, and especially in background Blender,
    ``Context.scene`` can briefly remain the previous scene after
    ``Window.scene`` changes.  Window.scene is authoritative; contexts without
    a window retain the normal Context.scene fallback.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
    except Exception:
        pass
    try:
        return getattr(ctx, 'scene', None)
    except Exception:
        return None


def _scrub_excluded_tree(data, path=''):
    if not isinstance(data, dict):
        return data
    result = {}
    for key, value in data.items():
        item_path = f'{path}.{key}' if path else str(key)
        if _path_excluded(item_path):
            continue
        result[key] = _scrub_excluded_tree(value, item_path) if isinstance(value, dict) else value
    return result


def collect_persistent_settings(context=None):
    # Preserve settings owned by unloaded lazy tools.  Their RNA does not exist
    # until explicitly loaded, so replacing the whole JSON domain here would
    # silently erase valid settings on the next unrelated N-panel edit.
    previous = _LOADED_SETTINGS if isinstance(_LOADED_SETTINGS, dict) else {}
    payload = {
        'window_manager': dict(previous.get('window_manager', {})) if isinstance(previous.get('window_manager'), dict) else {},
        'scene_profiles': dict(previous.get('scene_profiles', {})) if isinstance(previous.get('scene_profiles'), dict) else {},
        'object_profiles': dict(previous.get('object_profiles', {})) if isinstance(previous.get('object_profiles'), dict) else {},
        'scene': dict(previous.get('scene', {})) if isinstance(previous.get('scene'), dict) else {},
    }
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is not None:
        current_wm = _serialize_group(wm, 0, path='window_manager')
        payload['window_manager'] = _deep_merge_dict(payload.get('window_manager'), current_wm)
    scene = _active_scene(ctx)
    if scene is not None:
        profile_name = _scene_profile_name(scene)
        profiles = payload.setdefault('scene_profiles', {})
        previous_profile = profiles.get(profile_name, {}) if isinstance(profiles, dict) else {}
        current_scene = _serialize_group(scene, 0, path='scene')
        profiles[profile_name] = _deep_merge_dict(previous_profile, current_scene)
        # N-panel settings are global user preferences, not document-local
        # artistic data. Keep one canonical scene snapshot for every scene.
        # Lazy integrated tools do not all own RNA at the same time; replacing
        # this dictionary outright would erase settings for every currently
        # unloaded tool (for example Archimesh when Key Operations is opened
        # first).  Merge the live owners into the previous canonical snapshot,
        # matching the named-profile behavior above.
        previous_scene = payload.get('scene', {}) if isinstance(payload.get('scene'), dict) else {}
        payload['scene'] = _deep_merge_dict(previous_scene, current_scene)
        # Bundled tools such as Tissue expose object-scoped N-panel settings.
        # Persist them by stable scene/object names instead of copying one
        # active object's values onto every object in a different file.
        object_profiles = payload.setdefault('object_profiles', {})
        scene_objects = object_profiles.setdefault(profile_name, {}) if isinstance(object_profiles, dict) else {}
        for obj in tuple(getattr(scene, 'objects', ()) or ()):
            try:
                object_name = str(getattr(obj, 'name_full', '') or getattr(obj, 'name', '') or '').strip()
                if not object_name:
                    continue
                current_object = _serialize_group(obj, 0, path='object')
                if not current_object:
                    continue
                previous_object = scene_objects.get(object_name, {}) if isinstance(scene_objects, dict) else {}
                scene_objects[object_name] = _deep_merge_dict(previous_object, current_object)
            except Exception:
                continue
    if isinstance(payload.get('window_manager'), dict):
        payload['window_manager'] = _scrub_excluded_tree(payload.get('window_manager'), 'window_manager')
    if isinstance(payload.get('scene_profiles'), dict):
        payload['scene_profiles'] = {
            str(name): _scrub_excluded_tree(values, 'scene')
            for name, values in payload.get('scene_profiles', {}).items()
            if isinstance(values, dict)
        }
    if isinstance(payload.get('scene'), dict):
        payload['scene'] = _scrub_excluded_tree(payload.get('scene'), 'scene')
    if isinstance(payload.get('object_profiles'), dict):
        payload['object_profiles'] = {
            str(scene_name): {
                str(object_name): _scrub_excluded_tree(values, 'object')
                for object_name, values in objects.items()
                if isinstance(values, dict)
            }
            for scene_name, objects in payload.get('object_profiles', {}).items()
            if isinstance(objects, dict)
        }
    if not payload.get('window_manager'):
        payload.pop('window_manager', None)
    if not payload.get('scene_profiles'):
        payload.pop('scene_profiles', None)
    if not payload.get('object_profiles'):
        payload.pop('object_profiles', None)
    return payload


def _resolve_id_reference(payload, scene=None):
    if not isinstance(payload, dict):
        return None
    marker = payload.get(_SMART_ID_REFERENCE)
    if isinstance(marker, str):
        identifier = marker.strip().lower()
        name = str(payload.get('name') or '').strip()
    else:
        # Read the pre-v1.3.22 nested record during migration, while every new
        # write uses the unified ``{"__pointer__": TYPE, "name": NAME}``
        # schema shared by all suites.
        legacy = payload.get(_LEGACY_SMART_ID_REFERENCE)
        if not isinstance(legacy, dict):
            return None
        identifier = str(legacy.get('type') or '').strip().lower()
        name = str(legacy.get('name') or '').strip()
    if not name:
        return None
    collections = {
        'object': 'objects', 'collection': 'collections', 'material': 'materials',
        'mesh': 'meshes', 'curve': 'curves', 'image': 'images', 'texture': 'textures',
        'nodegroup': 'node_groups', 'nodetree': 'node_groups', 'world': 'worlds',
        'camera': 'cameras', 'light': 'lights', 'action': 'actions',
    }
    attr = collections.get(identifier)
    if attr is None:
        for key, candidate in collections.items():
            if key in identifier:
                attr = candidate
                break
    try:
        owner = getattr(bpy.data, attr, None) if attr else None
        value = owner.get(name) if owner is not None else None
    except Exception:
        value = None
    if value is not None and identifier == 'object' and scene is not None:
        try:
            if scene.objects.get(value.name) is None:
                return None
        except Exception:
            return None
    return value


def _apply_collection(collection, items, depth=0, scene=None, path=''):
    if collection is None or not isinstance(items, list):
        return
    try:
        collection.clear()
    except Exception:
        return
    for values in items:
        try:
            item = collection.add()
        except Exception:
            break
        if isinstance(values, dict) and (
            _SMART_ID_REFERENCE in values or _LEGACY_SMART_ID_REFERENCE in values
        ):
            # ID collections are uncommon for add-on settings and cannot be
            # appended generically; leave the new row untouched.
            continue
        _apply_group(item, values, depth + 1, scene=scene, path=path)


def _apply_group(obj, data, depth=0, scene=None, path=''):
    if depth > 5 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            item_path = f'{path}.{key}' if path else str(key)
            if _path_excluded(item_path):
                continue
            if isinstance(value, dict) and (
                _SMART_ID_REFERENCE in value or _LEGACY_SMART_ID_REFERENCE in value
            ):
                resolved = _resolve_id_reference(value, scene=scene)
                if resolved is not None and hasattr(obj, key):
                    if getattr(obj, key, None) is not resolved:
                        setattr(obj, key, resolved)
            elif isinstance(value, dict) and _SMART_ENUM_SET in value:
                if hasattr(obj, key):
                    target = set(str(item) for item in value.get(_SMART_ENUM_SET, ()))
                    if set(getattr(obj, key, set()) or set()) != target:
                        setattr(obj, key, target)
            elif isinstance(value, dict) and _SMART_SEQUENCE in value:
                if hasattr(obj, key):
                    target = value.get(_SMART_SEQUENCE, [])
                    try:
                        current = list(getattr(obj, key))
                    except Exception:
                        current = None
                    if current != list(target):
                        setattr(obj, key, target)
            elif isinstance(value, dict) and _SMART_COLLECTION in value:
                child = getattr(obj, key, None)
                _apply_collection(child, value.get(_SMART_COLLECTION), depth + 1, scene=scene, path=item_path)
            elif isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1, scene=scene, path=item_path)
            elif hasattr(obj, key):
                try:
                    current = getattr(obj, key)
                except Exception:
                    current = object()
                if isinstance(current, (set, frozenset)) and isinstance(value, (list, tuple)):
                    value = set(str(item) for item in value)
                if current != value:
                    setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    global _APPLYING_PERSISTENT_SETTINGS, _LAST_SCENE_POINTER, _SCENE_RESTORE_PENDING
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    _APPLYING_PERSISTENT_SETTINGS = True
    try:
        wm = getattr(ctx, 'window_manager', None)
        wm_data = data.get('window_manager') if isinstance(data, dict) else None
        if wm is not None and isinstance(wm_data, dict):
            _apply_group(wm, wm_data, 0, scene=_active_scene(ctx), path='window_manager')
        scene = _active_scene(ctx)
        profiles = data.get('scene_profiles') if isinstance(data, dict) else None
        scene_data = data.get('scene') if isinstance(data, dict) and isinstance(data.get('scene'), dict) else None
        if not isinstance(scene_data, dict):
            scene_data = profiles.get(_scene_profile_name(scene)) if scene is not None and isinstance(profiles, dict) else None
        # One-time migration for pre-profile JSON.  It is applied only to the
        # active scene and becomes name-scoped on the next atomic save.
        if not isinstance(scene_data, dict) and isinstance(data, dict) and isinstance(data.get('scene'), dict):
            scene_data = data.get('scene')
        if scene is not None and isinstance(scene_data, dict):
            _apply_group(scene, scene_data, 0, scene=scene, path='scene')
        object_profiles = data.get('object_profiles') if isinstance(data, dict) else None
        scene_object_data = object_profiles.get(_scene_profile_name(scene), {}) if scene is not None and isinstance(object_profiles, dict) else {}
        if scene is not None and isinstance(scene_object_data, dict):
            for obj in tuple(getattr(scene, 'objects', ()) or ()):
                try:
                    object_name = str(getattr(obj, 'name_full', '') or getattr(obj, 'name', '') or '').strip()
                    object_data = scene_object_data.get(object_name)
                    if object_name and isinstance(object_data, dict):
                        _apply_group(obj, object_data, 0, scene=scene, path='object')
                except Exception:
                    continue
    finally:
        _APPLYING_PERSISTENT_SETTINGS = False
    try:
        scene = _active_scene(ctx)
        _LAST_SCENE_POINTER = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        _LAST_SCENE_POINTER = 0
    _SCENE_RESTORE_PENDING = False
    sync_persistence_subscriptions(ctx)


def _persistence_change_notify(*_args) -> None:
    if _APPLYING_PERSISTENT_SETTINGS:
        return
    try:
        if n_panel_state_save_enabled(getattr(bpy, 'context', None)):
            save_persistent_settings(getattr(bpy, 'context', None), force=False)
    except Exception:
        pass


def _scene_change_notify(*_args) -> None:
    if _APPLYING_PERSISTENT_SETTINGS:
        return
    try:
        apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        pass


def _subscribe_group_changes(obj, path: str, depth=0, seen=None) -> None:
    if obj is None or depth > 4:
        return
    seen = seen if isinstance(seen, set) else set()
    try:
        props = getattr(getattr(obj, 'bl_rna', None), 'properties', ())
    except Exception:
        props = ()
    root_owner = _is_root_owner(obj)
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier in {'rna_type', 'name'}:
                continue
            item_path = f'{path}.{identifier}' if path else identifier
            if _path_excluded(item_path):
                continue
            if root_owner and not _root_prop_identifier_relevant(identifier, obj):
                continue
            value = getattr(obj, identifier)
            if not _prop_relevant(identifier, value, obj):
                continue
            key = (type(obj), identifier)
            if key not in seen:
                seen.add(key)
                try:
                    bpy.msgbus.subscribe_rna(
                        key=key,
                        owner=_PERSISTENCE_MSGBUS_OWNER,
                        args=(),
                        notify=_persistence_change_notify,
                        options={'PERSISTENT'},
                    )
                except Exception:
                    pass
            if _is_suite_group(value):
                _subscribe_group_changes(value, item_path, depth + 1, seen)
        except Exception:
            continue


def sync_persistence_subscriptions(context=None) -> None:
    """Refresh event-only subscriptions after lazy tool RNA registration."""
    try:
        bpy.msgbus.clear_by_owner(_PERSISTENCE_MSGBUS_OWNER)
    except Exception:
        pass
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None or not n_panel_state_save_enabled(ctx):
        return
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, 'scene'),
            owner=_PERSISTENCE_MSGBUS_OWNER,
            args=(),
            notify=_scene_change_notify,
            options={'PERSISTENT'},
        )
    except Exception:
        pass
    # Property and scene subscriptions exist only while the user has enabled
    # N-panel saving; OFF removes the complete event fan-out immediately.
    seen = set()
    wm = getattr(ctx, 'window_manager', None)
    scene = _active_scene(ctx)
    _subscribe_group_changes(wm, 'window_manager', 0, seen)
    _subscribe_group_changes(scene, 'scene', 0, seen)
    for obj in tuple(getattr(scene, 'objects', ()) or ()) if scene is not None else ():
        _subscribe_group_changes(obj, 'object', 0, seen)


def restore_dynamic_persistent_settings(context=None) -> None:
    """Apply and subscribe newly loaded native/integrated tool settings."""
    try:
        apply_persistent_settings(context or getattr(bpy, 'context', None))
    except Exception:
        sync_persistence_subscriptions(context or getattr(bpy, 'context', None))


def begin_dynamic_registration() -> None:
    """Freeze canonical state while a lazy integrated tool creates its RNA."""
    global _PERSISTENCE_REGISTRATION_GUARD
    if _PERSISTENCE_REGISTRATION_GUARD:
        return
    load_settings_file()
    _PERSISTENCE_REGISTRATION_GUARD = True


def end_dynamic_registration(context=None) -> None:
    """Restore newly materialised RNA before allowing any JSON snapshot."""
    global _PERSISTENCE_REGISTRATION_GUARD
    if not _PERSISTENCE_REGISTRATION_GUARD:
        return
    try:
        apply_persistent_settings(context or getattr(bpy, 'context', None))
    finally:
        _PERSISTENCE_REGISTRATION_GUARD = False
    sync_persistence_subscriptions(context or getattr(bpy, 'context', None))


def _read_settings_payload(path: Path):
    try:
        if path and path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                data = raw.get('persistent_settings') if isinstance(raw.get('persistent_settings'), dict) else raw
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return None


_LEGACY_CAD_SCENE_SETTING_MAP = {
    # Pre-1.3.55 CAD Decimate settings used generic Scene RNA names.  They
    # are migrated only inside the Suite JSON payload; Blender RNA and user
    # data are not touched here.
    'auto_clear_garbage_data': 'sms_cad_auto_clear_garbage_data',
    'preserv_uvs': 'sms_cad_preserve_uvs',
    'preserve_uvs': 'sms_cad_preserve_uvs',
    'cad_decimate_export_path': 'sms_cad_export_path',
    'export_path': 'sms_cad_export_path',
    'decimation_ratio': 'sms_cad_decimation_ratio',
    'delete_files_after_import': 'sms_cad_delete_files_after_import',
    'export_selected_only': 'sms_cad_export_selected_only',
    'deceimate_type': 'sms_cad_decimate_type',
    'decimate_type': 'sms_cad_decimate_type',
    'merge_distance': 'sms_cad_merge_distance',
    'format': 'sms_cad_format',
    'fast_mode': 'sms_cad_fast_mode',
    'procent_or_amount': 'sms_cad_percent_or_amount',
    'percent_or_amount': 'sms_cad_percent_or_amount',
    'tris_count': 'sms_cad_tris_count',
}
_LEGACY_CAD_SCENE_SENTINELS = frozenset({
    'cad_decimate_export_path', 'deceimate_type', 'procent_or_amount',
})


def _migrate_legacy_cad_scene_settings(data):
    """Return a payload that cannot write old generic CAD RNA names.

    A distinctive old CAD key is required before values are copied to the new
    Suite-prefixed names.  All known generic keys are then removed from this
    Suite-owned payload so loading Smart Modeling cannot mutate a property now
    owned by another add-on.  The caller's dictionary is not modified.
    """
    if not isinstance(data, dict):
        return data
    migrated = dict(data)

    def migrate_scene_values(values):
        if not isinstance(values, dict):
            return values
        result = dict(values)
        is_legacy_cad_payload = bool(_LEGACY_CAD_SCENE_SENTINELS.intersection(result))
        if is_legacy_cad_payload:
            for old_name, new_name in _LEGACY_CAD_SCENE_SETTING_MAP.items():
                if new_name not in result and old_name in result:
                    result[new_name] = result[old_name]
        for old_name in _LEGACY_CAD_SCENE_SETTING_MAP:
            result.pop(old_name, None)
        return result

    if isinstance(migrated.get('scene'), dict):
        migrated['scene'] = migrate_scene_values(migrated.get('scene'))
    profiles = migrated.get('scene_profiles')
    if isinstance(profiles, dict):
        migrated['scene_profiles'] = {
            str(name): migrate_scene_values(values)
            for name, values in profiles.items()
            if isinstance(values, dict)
        }
    return migrated


def load_settings_file():
    global _LOADED_SETTINGS, _SETTINGS_WRITE_BLOCKED, _SETTINGS_LOAD_ERROR, _SETTINGS_WRITE_ERROR
    if _PERSISTENCE_REGISTRATION_GUARD and isinstance(_LOADED_SETTINGS, dict):
        return _LOADED_SETTINGS
    path = settings_path()
    canonical_exists = bool(path.exists())
    data = _read_settings_payload(path)
    if canonical_exists and data is None:
        # Preserve the malformed canonical file byte-for-byte.  A later UI
        # edit must not silently replace the user's only recoverable copy.
        _SETTINGS_WRITE_BLOCKED = True
        _SETTINGS_LOAD_ERROR = f'Invalid settings JSON: {path}'
    elif data is not None:
        _SETTINGS_WRITE_BLOCKED = False
        _SETTINGS_LOAD_ERROR = ''
        _SETTINGS_WRITE_ERROR = ''
    if data is None and not canonical_exists:
        for legacy in legacy_settings_paths():
            data = _read_settings_payload(legacy)
            if data is not None:
                break
    if isinstance(data, dict):
        data = _migrate_legacy_cad_scene_settings(data)
        _LOADED_SETTINGS = data
        return data
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False, *, allow_disabled_transition=False):
    global _AUTOSAVE_FINGERPRINT, _LOADED_SETTINGS, _SCENE_RESTORE_PENDING, _SETTINGS_WRITE_ERROR
    if _PERSISTENCE_REGISTRATION_GUARD:
        return False
    if not settings_write_allowed():
        return False
    save_enabled = n_panel_state_save_enabled(context)
    if not save_enabled and not allow_disabled_transition:
        # ``force`` controls dirty/fingerprint behavior only.  It never grants
        # permission to bypass the user-facing N-panel save switch.
        return False
    try:
        scene = _active_scene(context or getattr(bpy, 'context', None))
        pointer = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        pointer = 0
    if _LAST_SCENE_POINTER and pointer and pointer != _LAST_SCENE_POINTER:
        _SCENE_RESTORE_PENDING = True
        return False
    data = collect_persistent_settings(context)
    try:
        _LOADED_SETTINGS = data
    except Exception:
        pass
    try:
        path = settings_path()
        root = {}
        if path.exists():
            try:
                loaded = json.loads(path.read_text(encoding='utf-8'))
            except Exception:
                _SETTINGS_WRITE_ERROR = f'Invalid settings JSON: {path}'
                return False
            if not isinstance(loaded, dict):
                _SETTINGS_WRITE_ERROR = f'Invalid settings JSON root: {path}'
                return False
            root = loaded
        root['version'] = max(int(root.get('version', 0) or 0), 4)
        root['persistent_settings'] = data
        root['n_panel_state_save'] = bool(save_enabled)
        # The feature-toggle capture owns runtime resources but not disk I/O.
        # Fold its current state into this same canonical atomic transaction.
        try:
            feature_module = sys.modules.get(f'{__package__}.feature_toggle')
            snapshot = getattr(feature_module, 'persistent_state_snapshot', None) if feature_module is not None else None
            if callable(snapshot):
                root['feature_toggles'] = snapshot()
        except Exception:
            pass
        # Core owns disclosure/tool settings but delegates the write here.
        try:
            core_module = sys.modules.get(f'{__package__}.core')
            capture = getattr(core_module, '_sms_capture_suite_panel_settings', None) if core_module is not None else None
            prefs_getter = getattr(core_module, '_sms_get_suite_prefs', None) if core_module is not None else None
            snapshot_getter = getattr(core_module, '_sms_load_panel_settings_snapshot', None) if core_module is not None else None
            if callable(capture):
                prefs = prefs_getter(context or getattr(bpy, 'context', None)) if callable(prefs_getter) else None
                capture(context=context or getattr(bpy, 'context', None), prefs=prefs)
            if callable(snapshot_getter):
                panel_settings = snapshot_getter()
                if isinstance(panel_settings, dict):
                    root['panel_settings'] = panel_settings
        except Exception:
            pass
        raw = json.dumps(root, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        _SETTINGS_WRITE_ERROR = 'Unable to serialize Smart Modeling settings.'
        return False
    if raw == _AUTOSAVE_FINGERPRINT:
        return True
    try:
        if path.exists() and path.read_text(encoding='utf-8') == raw:
            _AUTOSAVE_FINGERPRINT = raw
            return True
    except Exception:
        pass
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(raw, encoding='utf-8')
        # Atomic replacement is the only committed write path.  If Windows has
        # the destination temporarily locked, keep the previous valid JSON and
        # retry on the next property event instead of truncating it in-place.
        os.replace(str(tmp), str(path))
    except Exception as exc:
        _SETTINGS_WRITE_ERROR = f'Unable to save Smart Modeling settings: {exc}'
        return False
    _AUTOSAVE_FINGERPRINT = raw
    _SETTINGS_WRITE_ERROR = ''
    return True


def _autosave_timer():
    try:
        if n_panel_state_save_enabled(bpy.context):
            save_persistent_settings(bpy.context)
    except Exception:
        pass
    return 1.0




@persistent
def _load_pre_handler(dummy=None):
    # Do not touch Blender RNA during load_pre. On Blender 5.1.0 Windows the
    # previous file's WindowManager/Add-on preference pointers can already be
    # partially invalid, and even hasattr()/getattr() on those RNA objects can
    # crash inside Blender before Python receives an exception. Continuous
    # autosave and unregister still save settings outside this unsafe phase.
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register():
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Startup Runtime',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
                options={'SKIP_SAVE'},
            ))
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _NPANEL_STATE_SAVE_PROP):
            setattr(bpy.types.WindowManager, _NPANEL_STATE_SAVE_PROP, BoolProperty(
                name='N-panel State Save',
                description='Save every Smart Modeling Suite N-panel setting to Smart_Modeling_Suite/Smart_Modeling_Suite.json immediately when settings change.',
                default=True,
                options={'SKIP_SAVE'},
            ))
    except Exception:
        pass
    _purge_standalone_always_on_panel()
    for cls in (SMART_MODELING_OT_open_help, SMART_MODELING_OT_set_always_on, SMART_MODELING_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    _purge_standalone_always_on_panel()
    load_settings_file()
    try:
        apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        sync_persistence_subscriptions(getattr(bpy, 'context', None))
    except Exception:
        pass
    # All integrated RNA has now been registered.  Materialize one complete
    # canonical snapshot immediately so a newly introduced setting is present
    # before the user edits any unrelated control.
    try:
        if n_panel_state_save_enabled(getattr(bpy, 'context', None)):
            save_persistent_settings(getattr(bpy, 'context', None), force=False)
    except Exception:
        pass
    try:
        from . import core as _sms_core
        cleanup = getattr(_sms_core, '_sms_cleanup_legacy_idle_resources_if_all_off', None)
        if callable(cleanup):
            cleanup(getattr(bpy, 'context', None))
    except Exception:
        pass
    # No load_pre/load_post handler or background autosave timer.  Persistent
    # message-bus subscriptions run only on an actual property/Scene event and
    # therefore survive file loads without introducing idle polling work.
    try:
        _remove_handler(bpy.app.handlers.load_pre, _load_pre_handler)
        _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    except Exception:
        pass
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _patch_panel_headers()
    _patch_addon_preferences()


def unregister():
    if not _suite_is_shutting_down():
        _purge_standalone_always_on_panel()
    # During extension reinstall/quit, avoid RNA scans and property deletion.
    # Stored JSON is updated by explicit safe save paths; unregister is cleanup
    # only and must not touch UI/WindowManager properties.
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_pre, _load_pre_handler)
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    try:
        bpy.msgbus.clear_by_owner(_PERSISTENCE_MSGBUS_OWNER)
    except Exception:
        pass
    for prop_name in (_ALWAYS_ON_PROP, _NPANEL_STATE_SAVE_PROP):
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                delattr(bpy.types.WindowManager, prop_name)
        except Exception:
            pass
    for cls in reversed(_REGISTERED_CLASSES):
        _safe_unregister_class(cls)
    _REGISTERED_CLASSES.clear()
    _remove_previews()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()
