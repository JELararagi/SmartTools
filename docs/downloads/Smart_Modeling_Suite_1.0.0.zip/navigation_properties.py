# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Normal Blender sidebar access for Modeling's legacy navigation API."""

from .bootstrap_common import (
    class_belongs_to_current_package,
    cleanup_stale_owned_classes,
    disable_owned_panel_class,
)

try:
    import bpy
except ImportError:
    bpy = None


def _viewports():
    manager = getattr(getattr(bpy, "context", None), "window_manager", None)
    for window in getattr(manager, "windows", ()):
        for area in getattr(getattr(window, "screen", None), "areas", ()):
            if area.type == "VIEW_3D":
                yield area


def _tag_redraws():
    try:
        for area in _viewports():
            try:
                area.tag_redraw()
            except (ReferenceError, RuntimeError):
                continue
    except (ReferenceError, RuntimeError):
        return


def _panel_class_belongs_to_current_package(cls):
    return class_belongs_to_current_package(cls)


def _disable_resident_panel_class(cls):
    return disable_owned_panel_class(cls)


def _purge_stale_proxy_panels():
    return cleanup_stale_owned_classes(panels_only=True)


def _context_area_type(context=None):
    if bpy is None:
        return ""
    try:
        active = context or bpy.context
        return getattr(getattr(active, "area", None), "type", "") or ""
    except (AttributeError, ReferenceError, RuntimeError):
        return ""


def _is_smart_tools_context(context=None):
    return _context_area_type(context) in ("", "VIEW_3D")


def _normalise_classes(panel_classes=None):
    return tuple(dict.fromkeys(cls for cls in (panel_classes or ()) if isinstance(cls, type)))


def _publish_compatibility(namespace):
    entries = {}
    suites = {}
    namespace.update(_REGISTERED_ENTRIES=entries, _SUITE_PRESENCE=suites,
                     _LAUNCHER_DRAW_CALLBACK=None, _LAUNCHER_DRAW_OWNER="")

    def repaint(*args, **kwargs):
        _tag_redraws()
        return True

    def refresh(*args, **kwargs):
        _purge_stale_proxy_panels()
        return repaint()

    def install(addon_key, label, icon="NONE", operator_id="", panel_classes=None, *,
                order=100, draw_callback=None, **kwargs):
        key = str(addon_key or "").strip()
        if not key:
            return False
        entries[key] = dict(addon_key=key, label=str(label or key), icon=str(icon or "NONE"),
                            operator_id=str(operator_id or ""), order=int(order or 100),
                            panel_classes=_normalise_classes(panel_classes), draw_callback=draw_callback)
        return refresh()

    def uninstall(addon_key, **kwargs):
        entries.pop(str(addon_key or "").strip(), None)
        return refresh()

    def set_launcher_draw_callback(callback, owner=""):
        namespace["_LAUNCHER_DRAW_CALLBACK"] = callback if callable(callback) else None
        namespace["_LAUNCHER_DRAW_OWNER"] = str(owner or "")
        return repaint()

    def clear_launcher_draw_callback(owner=""):
        held = namespace["_LAUNCHER_DRAW_OWNER"]
        return False if owner and held and str(owner) != held else set_launcher_draw_callback(None)

    def draw(layout, context=None, owner=""):
        callback = namespace["_LAUNCHER_DRAW_CALLBACK"]
        if callback is None:
            return 0
        try:
            try:
                callback(layout, context)
            except TypeError:
                callback(layout)
        except Exception:
            return 0
        return 1

    def mark_suite_presence(suite_key, installed=True):
        key = str(suite_key or "").strip()
        if key:
            suites[key] = bool(installed)
        return True

    def current_sidebar():
        return "standard-n-panel"

    def shutdown(*args, **kwargs):
        entries.clear()
        clear_launcher_draw_callback()
        return refresh()

    def register():
        refresh()

    def unregister():
        shutdown()

    def compatibility_success(*args, **kwargs):
        return True

    def no_proxy(*args, **kwargs):
        return None

    namespace.update(
        _iter_view3d_areas=_viewports, _tag_redraws=_tag_redraws,
        _panel_class_belongs_to_current_package=_panel_class_belongs_to_current_package,
        _disable_resident_panel_class=_disable_resident_panel_class,
        _purge_stale_proxy_panels=_purge_stale_proxy_panels,
        _context_area_type=_context_area_type, _is_smart_tools_context=_is_smart_tools_context,
        _normalise_classes=_normalise_classes,
        install=install, uninstall=uninstall, flush_redraws=repaint, mark_suite_presence=mark_suite_presence,
        set_launcher_draw_callback=set_launcher_draw_callback, clear_launcher_draw_callback=clear_launcher_draw_callback,
        _draw_launcher_fallback_contents=draw, _draw_smart_tools_window_contents=draw,
        _tag_redraw_all_properties_areas=_tag_redraws, _tag_redraw_all_view3d_areas=_tag_redraws,
        _shared_nav_button_operator_class=no_proxy, backend_summary=current_sidebar,
        shutdown_runtime=shutdown, register=register, unregister=unregister,
    )
    for public_name in (
        "refresh_runtime", "refresh_ui_runtime", "force_runtime_refresh", "sync_live_runtime_from_prefs",
        "open_smart_tools_window", "open_or_reuse_smart_tools_window", "open_window", "toggle_active",
    ):
        namespace[public_name] = refresh
    for legacy_name in (
        "ensure_shared_window_menu_button", "schedule_shared_window_menu_button_refresh",
        "remove_shared_window_menu_button_if_unused", "ensure_shared_nav_button_operators",
        "_smart_tools_v430_canonicalize_nav_entries", "_smart_tools_v440_canonicalize_existing_nav",
    ):
        namespace[legacy_name] = compatibility_success


_publish_compatibility(globals())
