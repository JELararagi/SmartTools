# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for the Smart Modeling standard N-panel UI.

The visible interface is built with ordinary ``bpy.types.Panel`` classes using
``bl_space_type='VIEW_3D'`` and ``bl_region_type='UI'``.  This module only
stores compatibility metadata and requests normal 3D View redraws.
"""

from __future__ import annotations

import sys
from typing import Any, Callable, Dict, Iterable, Optional, Tuple

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender supplies bpy at runtime.
    bpy = None  # type: ignore

from .bootstrap_common import (
    class_belongs_to_current_package as _exact_class_belongs_to_current_package,
    cleanup_stale_owned_classes as _cleanup_stale_owned_classes,
    disable_owned_panel_class as _disable_exact_owned_panel_class,
)

_REGISTERED_ENTRIES: Dict[str, Dict[str, Any]] = {}
_SUITE_PRESENCE: Dict[str, bool] = {}
_LAUNCHER_DRAW_CALLBACK: Optional[Callable[..., Any]] = None
_LAUNCHER_DRAW_OWNER: str = ""



def _iter_view3d_areas():
    if bpy is None:
        return
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    yield area
            except Exception:
                continue


def _tag_redraws() -> None:
    for area in _iter_view3d_areas() or ():
        try:
            area.tag_redraw()
        except Exception:
            pass



def _panel_class_belongs_to_current_package(cls) -> bool:
    return _exact_class_belongs_to_current_package(cls)

def _disable_resident_panel_class(cls) -> bool:
    return _disable_exact_owned_panel_class(cls)



def _purge_stale_proxy_panels() -> int:
    return _cleanup_stale_owned_classes(panels_only=True)


def _context_area_type(context=None) -> str:
    try:
        area = getattr(context or getattr(bpy, 'context', None), 'area', None) if bpy is not None else None
        return str(getattr(area, 'type', '') or '')
    except Exception:
        return ''


def _is_smart_tools_context(context=None) -> bool:
    """Return True only for the standard 3D View sidebar context."""
    area_type = _context_area_type(context)
    return not area_type or area_type == 'VIEW_3D'


def _normalise_classes(panel_classes: Iterable[type] | None = None) -> Tuple[type, ...]:
    classes = []
    seen = set()
    for cls in tuple(panel_classes or ()):  # defensive copy
        if not isinstance(cls, type):
            continue
        if cls in seen:
            continue
        seen.add(cls)
        classes.append(cls)
    return tuple(classes)


def install(addon_key: str, label: str, icon: str = 'NONE', operator_id: str = '', panel_classes: Iterable[type] | None = None, *, order: int = 100, draw_callback: Callable[..., Any] | None = None, **_kwargs) -> bool:
    key = str(addon_key or '').strip()
    if not key:
        return False
    _REGISTERED_ENTRIES[key] = {
        'addon_key': key,
        'label': str(label or key),
        'icon': str(icon or 'NONE'),
        'operator_id': str(operator_id or ''),
        'order': int(order or 100),
        'panel_classes': _normalise_classes(panel_classes),
        'draw_callback': draw_callback,
    }
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def uninstall(addon_key: str, **_kwargs) -> bool:
    key = str(addon_key or '').strip()
    if key:
        _REGISTERED_ENTRIES.pop(key, None)
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def refresh_runtime(*_args, **_kwargs) -> bool:
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def refresh_ui_runtime(*args, **kwargs) -> bool:
    return refresh_runtime(*args, **kwargs)


def force_runtime_refresh(*args, **kwargs) -> bool:
    return refresh_runtime(*args, **kwargs)


def sync_live_runtime_from_prefs(*args, **kwargs) -> bool:
    return refresh_runtime(*args, **kwargs)


def flush_redraws(*_args, **_kwargs) -> bool:
    _tag_redraws()
    return True


def _tag_redraw_all_properties_areas() -> None:
    _tag_redraws()


def _tag_redraw_all_view3d_areas() -> None:
    _tag_redraws()


def set_launcher_draw_callback(callback: Callable[..., Any] | None, owner: str = '') -> bool:
    global _LAUNCHER_DRAW_CALLBACK, _LAUNCHER_DRAW_OWNER
    _LAUNCHER_DRAW_CALLBACK = callback if callable(callback) else None
    _LAUNCHER_DRAW_OWNER = str(owner or '')
    _tag_redraws()
    return True


def clear_launcher_draw_callback(owner: str = '') -> bool:
    global _LAUNCHER_DRAW_CALLBACK, _LAUNCHER_DRAW_OWNER
    if owner and _LAUNCHER_DRAW_OWNER and str(owner) != _LAUNCHER_DRAW_OWNER:
        return False
    _LAUNCHER_DRAW_CALLBACK = None
    _LAUNCHER_DRAW_OWNER = ''
    _tag_redraws()
    return True


def _draw_launcher_fallback_contents(layout, context=None, owner: str = '') -> int:
    callback = _LAUNCHER_DRAW_CALLBACK
    if not callable(callback):
        return 0
    try:
        callback(layout, context)
        return 1
    except TypeError:
        try:
            callback(layout)
            return 1
        except Exception:
            return 0
    except Exception:
        return 0


def _draw_smart_tools_window_contents(layout, context=None, owner: str = '') -> int:
    return _draw_launcher_fallback_contents(layout, context, owner=owner)


def open_smart_tools_window(*_args, **_kwargs) -> bool:
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def open_or_reuse_smart_tools_window(*args, **kwargs) -> bool:
    return open_smart_tools_window(*args, **kwargs)


def open_window(*args, **kwargs) -> bool:
    return open_smart_tools_window(*args, **kwargs)


def toggle_active(*_args, **_kwargs) -> bool:
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def mark_suite_presence(suite_key: str, installed: bool = True) -> bool:
    key = str(suite_key or '').strip()
    if key:
        _SUITE_PRESENCE[key] = bool(installed)
    return True


def ensure_shared_window_menu_button(*_args, **_kwargs) -> bool:
    return True


def schedule_shared_window_menu_button_refresh(*_args, **_kwargs) -> bool:
    return True


def remove_shared_window_menu_button_if_unused(*_args, **_kwargs) -> bool:
    return True


def ensure_shared_nav_button_operators(*_args, **_kwargs) -> bool:
    return True


def _shared_nav_button_operator_class(*_args, **_kwargs):
    return None


def _smart_tools_v430_canonicalize_nav_entries(*_args, **_kwargs) -> bool:
    return True


def _smart_tools_v440_canonicalize_existing_nav(*_args, **_kwargs) -> bool:
    return True


def backend_summary() -> str:
    return 'standard-n-panel'


def shutdown_runtime(*_args, **_kwargs) -> bool:
    _REGISTERED_ENTRIES.clear()
    clear_launcher_draw_callback()
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def register() -> None:
    _purge_stale_proxy_panels()
    _tag_redraws()


def unregister() -> None:
    shutdown_runtime()
