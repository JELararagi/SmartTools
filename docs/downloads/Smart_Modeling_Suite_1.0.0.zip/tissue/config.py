import bpy
from bpy.props import (
    IntProperty,
    BoolProperty
    )

evaluatedDepsgraph = None

class tissuePreferences(bpy.types.PropertyGroup):
    bl_idname = __package__

    print_stats : IntProperty(
        name="Print Stats",
        description="Print in the console all details about the computing time.",
        default=1,
        min=0,
        max=4
        )

    use_numba_tess : BoolProperty(
        name="Numba Tessellate",
        description="Boost the Tessellation using Numba module. It will be slower during the first execution",
        default=True
        )

    def draw(self, context):

        layout = self.layout
        layout.prop(self, "print_stats")
        import importlib.util
        numba_spec = importlib.util.find_spec('numba')
        found = numba_spec is not None
        if found:
            try:
                import numba
                layout.label(text='Numba module installed correctly!')
                layout.prop(self, "use_numba_tess")
            except Exception:
                found = False
        if not found:
            layout.label(text='Numba module not installed.')
            layout.label(text='Using bundled NumPy fallback without sys.path changes.')
