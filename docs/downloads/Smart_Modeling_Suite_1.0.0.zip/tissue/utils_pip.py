import bpy
import sys


PYPATH = sys.executable  # bpy.app.binary_path_python


class Pip:
    """Policy-safe compatibility wrapper for Tissue's optional Numba helper.

    Smart Modeling is packaged as a Blender Extension. Runtime installation
    of third-party modules into an extension-local ``python_site`` folder requires
    mutating ``sys.path`` and triggers Blender's Extension policy warning.

    This wrapper intentionally avoids all ``sys.path`` changes and subprocess pip
    calls. Tissue remains functional through its bundled NumPy / pure-Python
    fallback paths. If a user wants Numba acceleration, it must be installed into
    Blender's Python environment outside this extension before Blender starts.
    """

    _POLICY_STATUS = (
        False,
        "Runtime Python package installation is disabled to keep the Blender Extension sys.path policy clean.",
    )

    def __init__(self):
        # Deliberately no ensurepip call here. Starting pip/ensurepip at add-on
        # runtime is not needed for the bundled fallback implementation and can
        # create policy-sensitive side effects.
        pass

    @staticmethod
    def _target_site_package():
        """Return no extension-local package path.

        Older bundled Tissue code used a ``python_site`` directory and appended it
        to ``sys.path``. That was the source of the Blender warning
        "Policy violation with sys.path: ./python_site". Keeping this method as
        a harmless compatibility stub prevents older call sites from failing.
        """
        return ""

    @staticmethod
    def _ensure_user_site_package():
        """Compatibility no-op. Never mutate ``sys.path``."""
        return ""

    def _cmd(self, action, options, module):
        return self._POLICY_STATUS

    def _popen(self, cmd):
        return iter(())

    def _run(self, cmd):
        return self._POLICY_STATUS

    def _ensurepip(self):
        return None

    @staticmethod
    def upgrade_pip():
        return Pip._POLICY_STATUS

    @staticmethod
    def uninstall(module, options=None):
        return Pip._POLICY_STATUS

    @staticmethod
    def install(module, options=None):
        """Do not install modules from inside the extension."""
        return Pip._POLICY_STATUS

    @staticmethod
    def blender_version():
        return bpy.app.version

    @staticmethod
    def python_version():
        return sys.version_info
