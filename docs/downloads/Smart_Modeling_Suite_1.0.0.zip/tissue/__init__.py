if "bpy" in locals():
    import importlib
    importlib.reload(tessellate_numpy)
    importlib.reload(tissue_properties)
    importlib.reload(weight_tools)
    importlib.reload(weight_reaction_diffusion)
    importlib.reload(dual_mesh)
    importlib.reload(lattice)
    importlib.reload(uv_to_mesh)
    importlib.reload(utils)
    importlib.reload(config)
    importlib.reload(material_tools)
    importlib.reload(curves_tools)
    importlib.reload(polyhedra)
    importlib.reload(texture_reaction_diffusion)
    importlib.reload(contour_curves)

else:
    from . import tessellate_numpy
    from . import tissue_properties
    from . import weight_tools
    from . import weight_reaction_diffusion
    from . import dual_mesh
    from . import lattice
    from . import uv_to_mesh
    from . import utils
    from . import config
    from . import material_tools
    from . import curves_tools
    from . import polyhedra
    from . import texture_reaction_diffusion
    from . import contour_curves

import bpy
from bpy.props import PointerProperty, CollectionProperty, BoolProperty




def _ensure_rotate_face_operator(name, bl_idname, label, shift):
    """Provide a safe fallback when an older cached tessellate_numpy module is missing these operators."""
    if hasattr(tessellate_numpy, name):
        return getattr(tessellate_numpy, name)

    class _TISSUE_OT_rotate_face_fallback(bpy.types.Operator):
        bl_description = 'Rotate the active UV corner order of selected faces for Tissue tessellation orientation.'
        bl_options = {'UNDO'}

        @classmethod
        def poll(cls, context):
            obj = getattr(context, 'object', None)
            return obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT'

        def execute(self, context):
            import bmesh
            from mathutils import Vector
            obj = context.object
            bm = bmesh.from_edit_mesh(obj.data)
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                uv_layer = bm.loops.layers.uv.new('Tissue Rotation')
            faces = [face for face in bm.faces if face.select]
            if not faces:
                return {'CANCELLED'}
            changed = False
            for face in faces:
                loops = list(face.loops)
                if not loops:
                    continue
                uvs = [loop[uv_layer].uv.copy() for loop in loops]
                if all((uv - uvs[0]).length < 1.0e-10 for uv in uvs[1:]):
                    count = len(loops)
                    if count == 3:
                        uvs = [Vector((0.0, 0.0)), Vector((1.0, 0.0)), Vector((0.0, 1.0))]
                    elif count == 4:
                        uvs = [Vector((0.0, 0.0)), Vector((1.0, 0.0)), Vector((1.0, 1.0)), Vector((0.0, 1.0))]
                    else:
                        continue
                s = int(shift) % len(loops)
                for loop, uv in zip(loops, uvs[s:] + uvs[:s]):
                    loop[uv_layer].uv = uv
                changed = True
            if changed:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                return {'FINISHED'}
            return {'CANCELLED'}

    _TISSUE_OT_rotate_face_fallback.__name__ = name
    _TISSUE_OT_rotate_face_fallback.bl_idname = bl_idname
    _TISSUE_OT_rotate_face_fallback.bl_label = label
    setattr(tessellate_numpy, name, _TISSUE_OT_rotate_face_fallback)
    return _TISSUE_OT_rotate_face_fallback


_ensure_rotate_face_operator('tissue_rotate_face_left', 'mesh.tissue_rotate_face_left', 'Rotate Face Left', 1)
_ensure_rotate_face_operator('tissue_rotate_face_right', 'mesh.tissue_rotate_face_right', 'Rotate Face Right', -1)
_ensure_rotate_face_operator('tissue_rotate_face_flip', 'mesh.tissue_rotate_face_flip', 'Flip Face Rotation', 2)


def _ensure_tessellate_iterations_panel():
    """Provide the iterations sub-panel expected by this package variant.

    Some bundled Tissue snapshots expose the tessellation iterations properties
    but no longer export ``TISSUE_PT_tessellate_iterations``.  The registration
    list still includes that class, so define a small compatibility panel before
    class registration instead of letting addon loading abort.
    """
    if hasattr(tessellate_numpy, 'TISSUE_PT_tessellate_iterations'):
        return getattr(tessellate_numpy, 'TISSUE_PT_tessellate_iterations')

    class TISSUE_PT_tessellate_iterations(bpy.types.Panel):
        bl_idname = 'TISSUE_PT_tessellate_iterations'
        bl_space_type = 'VIEW_3D'
        bl_region_type = 'UI'
        bl_category = 'Smart Modeling'
        bl_context = 'data'
        bl_parent_id = 'TISSUE_PT_tessellate_object'
        bl_label = 'Iterations'
        bl_options = {'DEFAULT_CLOSED'}

        @classmethod
        def poll(cls, context):
            try:
                return context.object.type == 'MESH' and context.object.tissue.tissue_type == 'TESSELLATE'
            except Exception:
                return False

        def draw(self, context):
            layout = self.layout
            try:
                props = context.object.tissue_tessellate
            except Exception:
                layout.label(text='Tessellation settings are not available')
                return

            col = layout.column(align=True)
            if hasattr(props, 'iterations'):
                col.prop(props, 'iterations')
            if hasattr(props, 'bool_combine'):
                col.prop(props, 'bool_combine')

    setattr(tessellate_numpy, 'TISSUE_PT_tessellate_iterations', TISSUE_PT_tessellate_iterations)
    return TISSUE_PT_tessellate_iterations


_ensure_tessellate_iterations_panel()


classes = (
    config.tissuePreferences,

    tissue_properties.tissue_prop,
    tissue_properties.tissue_tessellate_prop,
    tessellate_numpy.tissue_tessellate,
    tessellate_numpy.tissue_update_tessellate,
    tessellate_numpy.tissue_update_tessellate_deps,
    tessellate_numpy.TISSUE_PT_tessellate,
    tessellate_numpy.tissue_rotate_face_left,
    tessellate_numpy.tissue_rotate_face_right,
    tessellate_numpy.tissue_rotate_face_flip,
    tessellate_numpy.TISSUE_PT_tessellate_object,
    tessellate_numpy.TISSUE_PT_tessellate_frame,
    tessellate_numpy.TISSUE_PT_tessellate_component,
    tessellate_numpy.TISSUE_PT_tessellate_thickness,
    tessellate_numpy.TISSUE_PT_tessellate_direction,
    tessellate_numpy.TISSUE_PT_tessellate_options,
    tessellate_numpy.TISSUE_PT_tessellate_coordinates,
    tessellate_numpy.TISSUE_PT_tessellate_rotation,
    tessellate_numpy.TISSUE_PT_tessellate_selective,
    tessellate_numpy.TISSUE_PT_tessellate_morphing,
    tessellate_numpy.TISSUE_PT_tessellate_iterations,
    tessellate_numpy.tissue_render_animation,
    tessellate_numpy.tissue_remove,

    weight_tools.face_area_to_vertex_groups,
    weight_tools.vertex_colors_to_vertex_groups,
    weight_tools.vertex_group_to_vertex_colors,
    weight_tools.vertex_group_to_uv,
    weight_tools.TISSUE_PT_weight,
    weight_tools.TISSUE_PT_color,
    weight_tools.weight_contour_mask,
    weight_tools.weight_contour_displace,
    weight_tools.harmonic_weight,
    weight_tools.edges_deformation,
    weight_tools.edges_bending,
    weight_tools.weight_laplacian,
    weight_reaction_diffusion.start_reaction_diffusion,
    weight_reaction_diffusion.TISSUE_PT_reaction_diffusion,
    weight_reaction_diffusion.TISSUE_PT_reaction_diffusion_performance,
    weight_reaction_diffusion.TISSUE_PT_reaction_diffusion_vector_field,
    weight_reaction_diffusion.TISSUE_PT_reaction_diffusion_weight,
    weight_reaction_diffusion.TISSUE_PT_reaction_diffusion_cache,
    weight_reaction_diffusion.reset_reaction_diffusion_weight,
    weight_tools.formula_prop,
    weight_reaction_diffusion.reaction_diffusion_prop,
    weight_tools.weight_formula,
    weight_tools.update_weight_formula,
    weight_tools.curvature_to_vertex_groups,
    weight_tools.weight_formula_wiki,
    weight_tools.tissue_weight_distance,
    weight_tools.random_weight,
    weight_reaction_diffusion.bake_reaction_diffusion,
    weight_reaction_diffusion.reaction_diffusion_free_data,
    weight_tools.tissue_weight_streamlines,

    contour_curves.tissue_weight_contour_curves_pattern,
    contour_curves.tissue_update_contour_curves,
    contour_curves.tissue_contour_curves_prop,
    contour_curves.TISSUE_PT_contour_curves,

    dual_mesh.dual_mesh,
    dual_mesh.dual_mesh_tessellated,

    lattice.lattice_along_surface,

    material_tools.random_materials,
    material_tools.weight_to_materials,

    curves_tools.tissue_to_curve_prop,
    curves_tools.tissue_convert_to_curve,
    curves_tools.tissue_update_convert_to_curve,
    curves_tools.TISSUE_PT_convert_to_curve,

    uv_to_mesh.uv_to_mesh,

    polyhedra.polyhedral_wireframe,
    polyhedra.tissue_update_polyhedra,
    polyhedra.tissue_polyhedra_prop,
    polyhedra.TISSUE_PT_polyhedra_object,

    texture_reaction_diffusion.tex_reaction_diffusion_prop,
    texture_reaction_diffusion.start_tex_reaction_diffusion,
    texture_reaction_diffusion.reset_tex_reaction_diffusion,
    texture_reaction_diffusion.TISSUE_PT_tex_reaction_diffusion,
    texture_reaction_diffusion.TISSUE_PT_tex_reaction_diffusion_images
)

_REGISTERED = False

_OBJECT_PROPS = (
    ('tissue', lambda: PointerProperty(type=tissue_properties.tissue_prop)),
    ('tissue_tessellate', lambda: PointerProperty(type=tissue_properties.tissue_tessellate_prop)),
    ('tissue_polyhedra', lambda: PointerProperty(type=polyhedra.tissue_polyhedra_prop)),
    ('tissue_to_curve', lambda: PointerProperty(type=curves_tools.tissue_to_curve_prop)),
    ('tissue_contour_curves', lambda: PointerProperty(type=contour_curves.tissue_contour_curves_prop)),
    ('formula_settings', lambda: CollectionProperty(type=weight_tools.formula_prop)),
    ('reaction_diffusion_settings', lambda: PointerProperty(type=weight_reaction_diffusion.reaction_diffusion_prop)),
    ('tex_reaction_diffusion_settings', lambda: PointerProperty(type=texture_reaction_diffusion.tex_reaction_diffusion_prop)),
)


def _scene_has_running_reaction_diffusion() -> bool:
    try:
        for scene in bpy.data.scenes:
            for ob in getattr(scene, 'objects', ()):
                try:
                    if getattr(getattr(ob, 'reaction_diffusion_settings', None), 'run', False):
                        return True
                except Exception:
                    continue
    except Exception:
        pass
    return False


def _scene_has_running_texture_reaction_diffusion() -> bool:
    try:
        for scene in bpy.data.scenes:
            for ob in getattr(scene, 'objects', ()):
                try:
                    if getattr(getattr(ob, 'tex_reaction_diffusion_settings', None), 'run', False):
                        return True
                except Exception:
                    continue
    except Exception:
        pass
    return False


def _safe_register_class(cls):
    try:
        bpy.utils.register_class(cls)
    except ValueError:
        pass


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _has_handler(handler_list, fn):
    name = getattr(fn, '__name__', '')
    module = getattr(fn, '__module__', '')
    for item in tuple(handler_list or ()):
        if item is fn:
            return True
        if getattr(item, '__name__', '') == name and getattr(item, '__module__', '') == module:
            return True
    return False


def _safe_add_handler(handler_list, fn):
    try:
        if not _has_handler(handler_list, fn):
            handler_list.append(fn)
    except Exception:
        pass


def _safe_remove_handler(handler_list, fn):
    name = getattr(fn, '__name__', '')
    module = getattr(fn, '__module__', '')
    for item in list(tuple(handler_list or ())):
        if item is fn or (getattr(item, '__name__', '') == name and getattr(item, '__module__', '') == module):
            try:
                handler_list.remove(item)
            except Exception:
                pass


def _define_object_props():
    for attr, factory in _OBJECT_PROPS:
        try:
            if not hasattr(bpy.types.Object, attr):
                setattr(bpy.types.Object, attr, factory())
        except Exception:
            pass


def _clear_object_props():
    for attr, _factory in reversed(_OBJECT_PROPS):
        try:
            if hasattr(bpy.types.Object, attr):
                delattr(bpy.types.Object, attr)
        except Exception:
            pass


def register():
    global _REGISTERED
    if _REGISTERED:
        return

    for cls in classes:
        _safe_register_class(cls)

    _define_object_props()

    handler_list = getattr(bpy.app.handlers, 'frame_change_post', None)
    if handler_list is not None:
        if _scene_has_running_reaction_diffusion():
            _safe_add_handler(handler_list, weight_reaction_diffusion.reaction_diffusion_scene)
        if _scene_has_running_texture_reaction_diffusion():
            _safe_add_handler(handler_list, texture_reaction_diffusion.tex_rd_scene)

    _REGISTERED = True


def unregister():
    global _REGISTERED

    handler_list = getattr(bpy.app.handlers, 'frame_change_post', None)
    if handler_list is not None:
        for fn in (
            weight_reaction_diffusion.reaction_diffusion_scene,
            weight_reaction_diffusion.reaction_diffusion_def,
            texture_reaction_diffusion.tex_rd_scene,
            texture_reaction_diffusion.tex_reaction_diffusion_def,
        ):
            _safe_remove_handler(handler_list, fn)

    _clear_object_props()

    for cls in reversed(classes):
        _safe_unregister_class(cls)

    _REGISTERED = False


if __name__ == "__main__":
    register()
