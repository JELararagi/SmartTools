# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
#
#  Lazy help popup runtime for Smart Modeling.
#  This module is intentionally imported only from the Help operator, so the
#  detailed help dictionaries and setting-reference introspection do not add
#  Blender startup or normal N-panel drawing cost.
# ------------------------------------------------------------------------------


import sys
import unicodedata

try:
    import bpy
except Exception:  # pragma: no cover - keeps syntax tools usable outside Blender
    bpy = None

if bpy is not None:
    try:
        from bpy.props import StringProperty, IntProperty
    except Exception:  # pragma: no cover
        def StringProperty(**kwargs):
            return None
        def IntProperty(**kwargs):
            return None
else:  # pragma: no cover
    def StringProperty(**kwargs):
        return None
    def IntProperty(**kwargs):
        return None


_RUNTIME = None


def _bind_runtime(runtime=None):
    """Bind core helpers lazily.

    The heavy help module is imported only when the user clicks Help.  At that
    point we bind the already-loaded suite runtime functions into this module so
    the help popup can inspect the same tools, keymaps, panels, and RNA settings
    without duplicating normal N-panel code.
    """
    global _RUNTIME
    if runtime is None:
        package = str(__package__ or '').strip()
        candidates = []
        if package:
            candidates.append(package + '.core')
        candidates.extend(('smart_modeling_suite.core', 'bl_ext.user_default.smart_modeling_suite.core'))
        for name in candidates:
            runtime = sys.modules.get(name)
            if runtime is not None:
                break
    if runtime is None:
        return None
    _RUNTIME = runtime
    g = globals()
    for name in dir(runtime):
        if name in {'bpy', '_ui_text', '_pick_lang', '_language'} or name.startswith('_sms_') or name.startswith('_SMS_'):
            if name not in g:
                try:
                    g[name] = getattr(runtime, name)
                except Exception:
                    pass
    return runtime


def prepare_tool_help_settings_context(kind: str, alias: str, context=None, *, runtime=None) -> None:
    _bind_runtime(runtime)
    return _sms_prepare_tool_help_settings_context(kind, alias, context)


def draw_tool_help_popup(layout, context, kind: str, alias: str, label: str = '', *, runtime=None, popup_width=None) -> None:
    _bind_runtime(runtime)
    return _sms_draw_tool_help_popup(layout, context, kind, alias, label, popup_width=popup_width)


_SMS_NATIVE_HELP_INFO = {
    'vertex_copy': {
        'overview_en': (
            'Copies selected vertex positions into reusable slots and pastes them to another mesh or selection.',
            'Supports exact topology transfer, approximate transfer, mirrored transfer, and surface projection workflows.',
            'Useful for retopo corrections, symmetrical part fixes, and transferring edits between similar meshes.',
        ),
        'overview_ja': (
            '選択頂点の位置をスロットへ保存し、別メッシュや別選択へ貼り付ける頂点コピーツールです。',
            '同一トポロジ転送、近似転送、ミラー転送、サーフェス投影の用途に対応します。',
            'リトポ修正、左右対称パーツ調整、似たメッシュ間の編集転送に向いています。',
        ),
        'usage_en': (
            'Enter Edit Mode, select source vertices, then run Copy.',
            'Select or specify the target mesh, choose the paste mode, then run Paste.',
            'Use Validate before batch transfer when source and target topology may differ.', 'Basic options are for matching vertex numbers. Use Auxiliary when those numbers are insufficient and open Advanced for Smart, Surface, preview, or preset tuning.',
        ),
        'usage_ja': (
            '編集モードでコピー元の頂点を選択し、「コピー」を実行します。',
            '貼り付け先メッシュを選び、貼り付けモードを指定して「貼り付け」を実行します。',
            '頂点順や形状差がある場合は、まとめて転送する前に「検証」で確かめます。', '同じ頂点番号でのコピーと貼り付けは基本設定で行います。頂点番号で対応できない場合は補助機能を使い、Smart・Surface・プレビュー・プリセットを調整するときは詳細設定を開きます。',
        ),
    },
    'vertex_slide': {
        'overview_en': (
            'Enhanced modal vertex / edge slide tool for fast modeling cleanup and retopology edits.',
            'Provides loop and ring priority, proportional influence, and HUD feedback while sliding.',
        ),
        'overview_ja': (
            'モデリング整理やリトポ編集向けの拡張モーダル頂点 / 辺スライドツールです。',
            'スライド中にループ優先、リング優先、プロポーショナル影響、HUD表示を使えます。',
        ),
        'usage_en': (
            'Enter Edit Mode and select vertices or edges to slide.',
            'Run Vertex Slide, move the mouse, then confirm with LMB / Enter or cancel with RMB / Esc.',
            'During the modal operation, use the displayed shortcut hints to change slide behavior.',
            'Turn the constraint on and use G/R/S or the transform gizmo: moves, rotations and scales then slide along connected edges.',
            'When Vertex Slide is enabled in Always-on Toggles, the 3D View header in Edit Mode shows a button that switches the constraint.',
            'Turn Blender Proportional Editing on with O and enable Apply Proportional Editing so nearby vertices inside the radius also slide.',
        ),
        'usage_ja': (
            '編集モードでスライドしたい頂点または辺を選択します。',
            '頂点スライドを起動し、マウス移動で調整して LMB / Enter で確定、RMB / Esc でキャンセルします。',
            '実行中は表示されるショートカットヒントで挙動を切り替えます。',
            '「常時機能切り替え」で「頂点スライド」を有効にすると、編集モードの 3D ビューのヘッダーに、制約を切り替えるボタンが出ます。',
            '制約をオンにして G/R/S やトランスフォームのギズモを使うと、移動・回転・スケールがつながった辺に沿ったスライドになります。',
            'O キーで Blender のプロポーショナル編集をオンにし、「プロポーショナル編集を適用」を有効にすると、半径の中の周りの頂点も一緒にスライドします。',
        ),
    },
    'connect': {
        'overview_en': (
            'Creates useful connections between selected vertices or edges with fewer manual knife / connect steps.',
            'In edge-selection subdivision mode, it can open a 3ds Max-style Connect popup for Segments, Pinch, and Slide.',
            'Designed for quick topology construction and cleanup during edit-mode modeling.',
        ),
        'overview_ja': (
            '選択した頂点や辺を、手動のナイフ / 接続作業を減らして素早く接続するツールです。',
            '辺選択の細分化では、3ds Max の Connect に近いポップアップでセグメント、ピンチ、スライドを調整できます。',
            '編集モードでのトポロジ構築や整理を効率化します。',
        ),
        'usage_en': (
            'Enter Edit Mode and select the vertices or edges you want to connect.',
            'Press Connect Selection in the panel, or an assigned key.',
            'When edge mode is active and Show Popup is enabled, set Segments, Pinch, and Slide, then press Apply or Cancel.',
            'Disable Show Popup in the N-panel settings when you want direct execution with the stored scene settings.',
        ),
        'usage_ja': (
            '編集モードで接続したい頂点または辺を選択します。',
            'パネルの「選択を接続」か、割り当てたキーで実行します。',
            '辺モードでポップアップ表示が有効な場合は、セグメント、ピンチ、スライドを設定し、「適用」か「キャンセル」を押します。',
            'シーン内に保持した設定で直接実行したい場合は、Nパネル設定のポップアップ表示を無効にします。',
        ),
    },
    'mesh_align_preset': {
        'overview_en': (
            'Popup preset collection for aligning selected vertices, edges, faces, or objects.',
            'Includes axis alignment, center alignment, view / grid alignment, loop alignment, and distribution helpers.',
        ),
        'overview_ja': (
            '選択した頂点、辺、面、オブジェクトを整列するためのプリセットポップアップです。',
            '軸整列、中心整列、ビュー / グリッド整列、ループ整列、均等配置補助を含みます。',
        ),
        'usage_en': (
            'Select the elements to align in the appropriate mode.',
            'Press Open Align Presets in the panel, or a key you assigned to it, and choose the alignment command. The most used commands are also buttons in the panel.',
            'Use modifier-key behavior shown in each command tooltip for advanced alignment variants.',
            'Hold Alt on a button to slide along edges, and Ctrl to affect all targets.',
        ),
        'usage_ja': (
            '対象モードで整列したい要素を選択します。',
            'パネルの「整列プリセットを開く」か、割り当てたキーでポップアップを開き、そろえ方を選びます。よく使うそろえ方はパネルのボタンからも実行できます。',
            '高度な派生動作は、各コマンドのツールチップに記載された修飾キー操作を使います。',
            'ボタンを Alt を押しながら押すと辺に沿ってスライドし、Ctrl を押しながら押すと全部の対象に効きます。',
        ),
    },
    'direct_delete': {
        'overview_en': (
            'Fast delete workflow for Edit Mode that can avoid confirmation popups and choose context-aware delete actions.',
            'Can provide Delete / Backspace overrides and through-delete variants when its persistent runtime is enabled.',
        ),
        'overview_ja': (
            '確認ポップアップを減らし、選択状態に応じた削除動作を素早く実行する編集モード向け削除ツールです。',
            '常時機能を有効にすると Delete / Backspace 上書きや貫通する削除の操作を使えます。',
        ),
        'usage_en': (
            'Select mesh elements in Edit Mode.',
            'Run the desired Direct Delete command, or use assigned Delete / Backspace shortcuts if enabled.',
            'Use through-delete only when hidden or stacked elements should be affected intentionally.',
            'Smart chooses the safest delete or dissolve for the current selection. Through deletes elements behind the cursor, which helps on dense meshes.',
            'Increase the through radius for small details and decrease it for precision.',
            'Face AUTO / DELETE removes the selected faces plus non-shared adjacent edges and vertices. Use ONLY_FACES only when you want to keep the surrounding edges and vertices.',
        ),
        'usage_ja': (
            '編集モードで削除したいメッシュ要素を選択します。',
            '目的の削除コマンドを実行するか、有効化済みなら Delete / Backspace ショートカットを使います。',
            '隠れた要素や重なった要素まで処理したい場合だけ貫通する削除を使います。',
            '「スマート」は今の選択に合う削除か溶解を選びます。「貫通」はカーソルの奥の要素も消すので、細かいメッシュに向きます。',
            '貫通の半径は、小さな部分には大きく、正確に選びたい時は小さくします。',
            '面の「自動」「削除」は、選択の面と共有していない隣の辺・頂点も消します。周りの辺・頂点を残したい時だけ「面のみ」を使います。',
        ),
    },
    'model_organized': {
        'overview_en': (
            'Batch organization and cleanup workflow for selected mesh objects.',
            'Supports naming cleanup, transform application, mesh-data cleanup, modifier handling, and backup / restore.',
        ),
        'overview_ja': (
            '選択したメッシュオブジェクトを一括整理・クリーンアップするワークフローです。',
            '命名整理、トランスフォーム適用、メッシュデータ整理、モディファイア処理、バックアップ / 復元に対応します。',
        ),
        'usage_en': (
            'Select one or more mesh objects.',
            'Choose or adjust a cleanup preset, then run Organize Selection.',
            'Review the report and use Restore Backup if the result is not intended.',
        ),
        'usage_ja': (
            '1つ以上のメッシュオブジェクトを選択します。',
            'クリーンアッププリセットを選択または調整し、「選択を整理」を実行します。',
            'レポートを確認し、意図しない結果の場合は「バックアップを復元」を使います。',
        ),
    },
    'crease_preset': {
        'overview_en': (
            'Preset popup for applying and managing edge crease values.',
            'Useful for hard-surface edges that need non-destructive sharpness with subdivision workflows.',
        ),
        'overview_ja': (
            'エッジのクリース値を適用・管理するためのプリセットポップアップです。',
            'サブディビジョン運用で非破壊にエッジを立てたいハードサーフェス作業に向いています。',
        ),
        'usage_en': (
            'Enter Edit Mode and select the edges to crease.',
            'Press Open Crease Preset in the panel, or a key you assigned to it, and press a value button. After the first use the same buttons are also in the panel.',
            'Selected buttons change the selected edges. Linked buttons also change the edges connected to them.',
            'Button Count and Values decide which value buttons appear. They can be changed before and after the first use.',
            'Editing the crease value applies it to the selected edges. The selection value is filled from the selected edges (their average when several are selected) until you type one.', 'Crease values range from 0 to 1. To select edges by an exact value, enter the value with no edges selected, then run Select by Value.',
        ),
        'usage_ja': (
            '編集モードでクリースを付けたい辺を選択します。',
            'パネルの「クリースプリセットを開く」か、割り当てたキーでポップアップを開き、数値のボタンを押します。一度使った後は、同じボタンがパネルにも出ます。',
            '「選択」のボタンは選んだ辺に、「リンク」のボタンはつながった辺にも同じ値を付けます。',
            '「ボタン数」と「値」で、出す数値のボタンを決めます。一度使う前でも後でも変えられます。',
            'クリースの値を変えると選択中の辺に適用します。選択用の値は、手で入力するまで選択中の辺の値（複数なら平均）が入ります。', 'クリース値は 0 から 1 です。同じ値の辺を選ぶには、辺を選択していない状態で値を入力し、値による選択を実行します。',
        ),
    },
    'toggle_auto_merge_snap': {
        'overview_en': (
            'One-command control for Auto Merge and Snap related modeling states.',
            'Useful when frequently switching between free editing and precise snapping workflows.',
        ),
        'overview_ja': (
            '自動マージとスナップの状態をワンコマンドで切り替えるツールです。',
            '自由編集と精密スナップ作業を頻繁に切り替えるモデリングで役立ちます。',
        ),
        'usage_en': (
            'Run the toggle command to switch the configured merge / snap state.',
            'Use modifier-key variants if you want to toggle only Auto Merge or only Snap.',
            'Set up cycle states when you want repeated execution to rotate through multiple configurations.',
        ),
        'usage_ja': (
            'トグルコマンドを実行して、設定済みのマージ / スナップ状態を切り替えます。',
            '自動マージだけ、スナップだけを切り替えたい場合は修飾キー付きのコマンドを使います。',
            '複数状態を順番に切り替えたい場合はサイクル設定を使います。',
        ),
    },
    'apply_weighted_normal': {
        'overview_en': (
            'Applies or adds Weighted Normal cleanup directly from modeling workflows.',
            'Helps hard-surface models keep cleaner highlights without leaving Edit Mode.',
        ),
        'overview_ja': (
            'モデリング中に重み付き法線の追加・適用を直接行う法線整理ツールです。',
            'ハードサーフェスモデルのハイライトを、編集作業を止めずに整えやすくします。',
        ),
        'usage_en': (
            'Enter Edit Mode on the target mesh or multi-object edit selection.',
            'Run Apply Weighted Normal and choose add-only or add-and-apply behavior.',
            'Use selection-limited behavior only after selecting the vertices that should be affected.',
            "When Weighted Normal is enabled in Always-on Toggles, this command is also added to Blender's standard Alt+N Normals popup.",
        ),
        'usage_ja': (
            '対象メッシュ、またはマルチオブジェクト編集状態で編集モードに入ります。',
            '「重み付き法線」を実行し、追加のみ / 追加して適用の挙動を選びます。',
            '選択範囲だけに限定する場合は、先に対象頂点を選択します。',
            '「常時機能切り替え」で「重み付き法線」を有効にすると、Blender の Alt+N「法線」のメニューにもこのコマンドが出ます。',
        ),
    },
    'sketch_tools': {
        'overview_en': (
            'Converts annotation strokes and sketch input into curve or surface-strip geometry helpers.',
            'Useful for blocking guide curves, sketch-based surfaces, and quick retopo support geometry.',
        ),
        'overview_ja': (
            '注釈ストロークやスケッチ入力をカーブまたはサーフェスストリップ形状へ変換する補助ツールです。',
            'ガイドカーブ作成、スケッチベースの面作成、リトポ補助形状の作成に使えます。',
        ),
        'usage_en': (
            'Draw annotation strokes or prepare sketch input in the 3D View.',
            'Choose the conversion command that matches the desired curve or surface output.',
            'A surface strip spreads across the line as seen from the current view, so convert it from the view you drew it in.',
            'Adjust generated geometry settings after conversion if the result needs refinement.',
        ),
        'usage_ja': (
            '3Dビューで注釈ストロークを描くか、スケッチ入力を準備します。',
            '目的のカーブ化またはサーフェス化コマンドを選びます。',
            'サーフェスストリップは、今の表示から見て線の左右に広がります。線を描いた表示のまま変換します。',
            '変換後、必要に応じて生成された形状の設定を調整します。',
        ),
    },
    'quad_strip_draw': {
        'overview_en': (
            'Modal drawing tools for creating quad strips and retopology support geometry.',
            'Designed for drawing surface-following strips or rebuilding simple topology directly in the viewport.',
        ),
        'overview_ja': (
            'クアッドストリップやリトポ補助形状を作成するモーダル描画ツールです。',
            'ビューポート上で面追従ストリップを描いたり、単純なトポロジを再構築する用途に向いています。',
        ),
        'usage_en': (
            'Prepare the target mesh or surface if snapping / retopo guidance is needed.',
            'Start Draw Quad Strip or Start Retopo Pen, then draw in the viewport.',
            'Confirm or cancel the modal operation using the tool instructions shown during operation.',
        ),
        'usage_ja': (
            'スナップやリトポ補助が必要な場合は、対象メッシュまたはサーフェスを準備します。',
            'クアッドストリップを描画またはリトポペンを開始を起動し、ビューポート上で描画します。',
            '実行中に表示される操作指示に従って確定またはキャンセルします。',
        ),
    },

    'modeling_toolset_tools': {
        'overview_en': (
            'Adds one grouped command layer with a frame-free custom large-icon deck for hard-surface booleans, loop cleanup, F2-style face creation, quad rebuild, CAD cleanup, scatter, terrain, curve pipes, workplanes, falloff deformation, retopo wrapping, and procedural generators.',
            'It does not embed proprietary add-on code. Each command is a Blender-native upper-compatible alternative designed to approximate the workflow intent of the referenced tools.',
            'Commands are click-start tools with generated transparent PNG icons and do not keep background handlers or keymaps active unless the user assigns shortcuts manually.',
        ),
        'overview_ja': (
            '枠無しの独自大判アイコンデッキ付きで、ハードサーフェスブーリアン、ループ整理、F2風の面張り、クアッドを再構築、CAD整理、散布、地形、カーブパイプ、作業平面、フォールオフで変形、リトポ追従、プロシージャル生成を1つのコマンド群として追加します。',
            '商用アドオン等の独自コードは含めず、参照ツールの作業意図をBlender標準機能ベースで近似する上位互換代替コマンドとして構成しています。',
            '生成済みの透過PNGアイコンを使うクリック起動コマンドツールのため、ユーザーが手動でショートカットを割り当てない限り、バックグラウンドハンドラーやキーマップは常駐しません。',
        ),
        'usage_en': (
            'Open Modeling Toolkit inside the Smart Modeling N-panel and choose the command group that matches the task.',
            'For booleans, select cutters and make the target mesh active. For scatter, select source objects and make the surface active. For projection and kit insert, use the active mesh as the target.',
            'Review each operator tooltip and the redo panel parameters after execution to refine distances, counts, radii, and cleanup thresholds.',
        ),
        'usage_ja': (
            'Smart Modeling のNパネルから統合モデリングツールを開き、作業内容に合うコマンドグループを選びます。',
            'ブーリアンではカッターを選択し、対象メッシュをアクティブにします。散布ではソースを選択し、表面メッシュをアクティブにします。投影やキット素材を挿入ではアクティブメッシュをターゲットとして使います。',
            '各オペレーターのツールチップと実行後のリドゥパネルで、距離、数、半径、整理しきい値を調整します。',
        ),
    },
}

_SMS_INTEGRATED_HELP_INFO = {
    'antlandscape': {
        'overview_en': ('Generates procedural landscape meshes with terrain parameters.', 'Useful for quick ground forms, hills, noise-based terrain, and environment blocking.'),
        'overview_ja': ('地形パラメータからプロシージャルなランドスケープメッシュを生成します。', '地面形状、丘、ノイズ地形、環境ブロックアウトを素早く作る用途に向いています。'),
        'usage_en': ('Open its settings, choose terrain shape and noise parameters, then generate the landscape.', 'Refine size, subdivision, noise, erosion, and material options before finalizing.'),
        'usage_ja': ('地形形状とノイズパラメータを選んでランドスケープを生成します。', '確定前にサイズ、分割、ノイズ、浸食、マテリアル関連を調整します。'),
    },
    'archimesh': {
        'overview_en': ('Creates architecture-oriented objects such as rooms, doors, windows, stairs, and related parts.', 'Useful for blocking and generating building components inside Blender.'),
        'overview_ja': ('部屋、ドア、窓、階段などの建築向けオブジェクトを生成します。', 'Blender内で建築パーツのブロックアウトや生成を行う用途に向いています。'),
        'usage_en': ('Open the target architecture element panel, set dimensions and options, then add the object.', 'Adjust generated object parameters immediately after creation when available.'),
        'usage_ja': ('目的の建築要素パネルを開き、寸法とオプションを設定してオブジェクトを追加します。', '作成直後に利用できる場合は、生成オブジェクトのパラメータを調整します。'),
    },
    'boltfactory': {
        'overview_en': ('Generates bolts, nuts, and screw-like hard-surface primitives.', 'Useful for mechanical details and repeated fastening parts.'),
        'overview_ja': ('ボルト、ナット、ネジ状のハードサーフェスプリミティブを生成します。', '機械ディテールや締結部品を作成する用途に向いています。'),
        'usage_en': ('Choose the bolt or nut type, set dimensions and thread options, then add the mesh.', 'Adjust scale and bevel / shading after generation as needed.'),
        'usage_ja': ('ボルトまたはナットの種類を選び、寸法やネジ山設定を指定してメッシュを追加します。', '生成後、必要に応じてスケールやベベル / シェーディングを調整します。'),
    },
    'cell_fracture': {
        'overview_en': ('Fractures selected objects into cell-like pieces.', 'Useful for destruction setups, broken objects, and procedural fragment creation.'),
        'overview_ja': ('選択オブジェクトをセル状の破片に分割します。', '破壊表現、壊れたオブジェクト、プロシージャル破片作成に向いています。'),
        'usage_en': ('Select the object to fracture, choose source / point distribution options, then run fracture.', 'Use lower counts first for testing, then increase density when the result is correct.'),
        'usage_ja': ('分割したいオブジェクトを選択し、ソースや点分布設定を選んで「セル破砕」を実行します。', '最初は少ない破片数で確認し、結果が合ってから密度を上げます。'),
    },
    'curve_tools': {
        'overview_en': ('Adds modeling utilities for Bezier and NURBS curves and surfaces.', 'Useful for curve editing, curve-based modeling, and curve cleanup workflows.'),
        'overview_ja': ('ベジェ / NURBS カーブやサーフェス向けの編集ユーティリティを追加します。', 'カーブ編集、カーブベースモデリング、カーブ整理に使えます。'),
        'usage_en': ('Select curve objects or curve components, then run the relevant curve utility command.', 'Use settings for the specific operation when conversion or cleanup requires precision.'),
        'usage_ja': ('カーブオブジェクトまたはカーブ要素を選択し、目的のカーブユーティリティを実行します。', '変換や整理で精度が必要な場合は、該当操作の設定を調整します。'),
    },
    'edgeflow': {
        'overview_en': ('Adjusts mesh geometry to improve edge flow and fit curved surfaces.', 'Useful for smoothing topology transitions and improving deformation-friendly loops.'),
        'overview_ja': ('エッジフローを整え、曲面に沿うようにメッシュ形状を調整します。', 'トポロジのつながりを滑らかにし、変形に強いループを作る用途に向いています。'),
        'usage_en': ('Select the loops or edges to adjust in Edit Mode.', 'Run the required EdgeFlow command and adjust operation options if the shape needs more or less influence.'),
        'usage_ja': ('編集モードで調整したいループまたは辺を選択します。', '目的のエッジフローのコマンドを実行し、影響量が合わない場合は操作オプションを調整します。'),
    },
    'edit_mesh_tools': {
        'overview_en': ('Collection of mesh modeling utilities for edit-mode cleanup and construction.', 'Provides extra operations that complement Blender standard mesh editing.'),
        'overview_ja': ('編集モードの整理や形状構築を補助するメッシュモデリングユーティリティ集です。', 'Blender標準のメッシュ編集を補完する追加操作を提供します。'),
        'usage_en': ('Select the mesh elements required by the specific command.', 'Use the N-panel controls or command list, then run the operation that matches the intended edit.'),
        'usage_ja': ('実行するコマンドに必要なメッシュ要素を選択します。', 'Nパネル内の操作項目またはコマンド一覧から、目的の編集に合う操作を実行します。'),
    },
    'extra_curve_objectes': {
        'overview_en': ('Adds additional curve object generators and curve primitives.', 'Useful when Blender standard curve add options are not enough.'),
        'overview_ja': ('追加のカーブオブジェクト生成機能とカーブプリミティブを提供します。', 'Blender標準のカーブ追加だけでは足りない場合に使えます。'),
        'usage_en': ('Choose the curve primitive or generator, then set its parameters before adding it.', 'Edit the generated curve object after creation for final placement and shape.'),
        'usage_ja': ('追加したいカーブプリミティブまたは生成機能を選び、パラメータを設定して追加します。', '生成後にカーブオブジェクトを編集し、最終的な配置や形状を整えます。'),
    },
    'f2': {
        'overview_en': ('Speeds up face creation from selected vertices or edges.', 'Useful for retopology and filling missing faces with fewer clicks.'),
        'overview_ja': ('選択した頂点や辺からの面作成を高速化します。', 'リトポや欠けた面の補完を少ない操作で行う用途に向いています。'),
        'usage_en': ('In Edit Mode, select vertices or edges around the area to fill.', 'Run the F2 command or assigned shortcut to create the next face.'),
        'usage_ja': ('編集モードで、面を作りたい周辺の頂点または辺を選択します。', 'F2 コマンドまたは割り当てたショートカットを実行して次の面を作成します。'),
    },
    'ivygen': {
        'overview_en': ('Generates ivy growth from a start point on or near a mesh.', 'Useful for organic environment decoration and architectural vegetation details.'),
        'overview_ja': ('メッシュ上または付近の開始点からツタ形状を生成します。', '環境装飾や建築物の植生ディテール作成に向いています。'),
        'usage_en': ('Set the 3D cursor or start location, select the target object if required, then generate ivy.', 'Adjust growth, branch, leaf, and adhesion settings to fit the surface.'),
        'usage_ja': ('3Dカーソルまたは開始位置を設定し、必要に応じて対象オブジェクトを選択してツタを生成します。', '成長、枝、葉、吸着設定を調整して面に合わせます。'),
    },
    'key_operators_toolkit': {
        'overview_en': ('Toolkit of workflow shortcuts, handlers, menu hooks, and optional tablet / outliner integrations.', 'Useful for users who want Key Ops style navigation and modeling workflow shortcuts.'),
        'overview_ja': ('ワークフローショートカット、ハンドラー、メニュー連携、任意のタブレット / アウトライナー連携を含むツールキットです。', 'Key Ops 系のナビゲーションやモデリング操作ショートカットを使いたい場合に向いています。'),
        'usage_en': ('Enable only the persistent runtime items you actually need from the Always-on Toggles group.', 'Review keymap registration IDs in the N-panel and assign shortcuts in Blender Preferences as needed.', 'The first press of a CAD Decimate button turns that feature on and adds its settings and the manual steps to Panel UI in this section. Export, Process CAD Decimate and Import All run in that order and keep the source objects, also while Enable Fast Mode is on. Loop Tools buttons load Loop Tools first.'),
        'usage_ja': ('常時機能切り替えで、実際に必要な常時機能だけを有効化します。', 'Nパネル内のキーマップ登録IDを確認し、必要に応じて Blender プリファレンスでショートカットを割り当てます。', '「CAD ポリゴン削減」のボタンを初めて押すと、その機能が有効になり、この項目の「パネルUI」に設定と手動の手順が増えます。「エクスポート」「CAD ポリゴン削減を処理」「すべて読み込み」は、この順に押すと元の物を変えずに結果を読み込みます。「高速モードを有効化」がオンのままでも動きます。ループツールのボタンは、ループツールを読み込んでから実行します。'),
    },
    'looptools': {
        'overview_en': ('Mesh loop editing utilities such as relax, circle, bridge, flatten, and related loop operations.', 'Useful for cleanup, retopology, and improving selected loop shapes.'),
        'overview_ja': ('リラックス、円形化、ブリッジ、平面化などのループ編集ユーティリティです。', 'メッシュ整理、リトポ、選択ループ形状の改善に向いています。'),
        'usage_en': ('In Edit Mode, select the vertices or loops required by the operation.', 'Run the target Loop Tools command and adjust its operator options immediately after execution.'),
        'usage_ja': ('編集モードで、操作に必要な頂点またはループを選択します。', '目的のループツールのコマンドを実行し、実行直後のオペレーターオプションを調整します。'),
    },
    'mesh_repair_tools': {
        'overview_en': ('Mesh repair utilities for detecting and fixing common mesh problems.', 'Useful before export, simulation, booleans, or cleanup-sensitive workflows.'),
        'overview_ja': ('一般的なメッシュ問題を検出・修正するためのメッシュ修復ユーティリティです。', '書き出し、シミュレーション、ブーリアン、クリーンアップ前の確認に向いています。'),
        'usage_en': ('Select the mesh object to inspect or repair.', 'Run the relevant repair command, then review the result before applying destructive follow-up steps.'),
        'usage_ja': ('確認または修復したいメッシュオブジェクトを選択します。', '目的の修復コマンドを実行し、破壊的な後続処理の前に結果を確認します。'),
    },
    'mio3_flex': {
        'overview_en': ('Flex / deformation-oriented modeling helper tools.', 'Useful for shape adjustment and deformation-support workflows that do not need constant background processing.'),
        'overview_ja': ('フレックス / 変形系のモデリング補助ツールです。', '常時処理を必要としない形状調整や変形補助ワークフローに向いています。'),
        'usage_en': ('Select the target mesh or elements, open the appropriate Mio3 Flex command, and run it.', 'Adjust operation settings before or immediately after execution depending on the command.'),
        'usage_ja': ('対象メッシュまたは要素を選択し、目的のフレックス変形のコマンドを開いて実行します。', 'コマンドに応じて、実行前または実行直後に設定を調整します。'),
    },
    'polyquilt_fork': {
        'overview_en': ('Retopology-focused toolset for drawing and editing polygons on surfaces.', 'Useful for building clean topology over reference meshes.'),
        'overview_ja': ('サーフェス上でポリゴンを描画・編集するリトポ向けツールセットです。', '参照メッシュ上にきれいなトポロジを作成する用途に向いています。'),
        'usage_en': ('Prepare the reference mesh and start the PolyQuilt tool from its command or workspace tool.', 'Draw, extend, and adjust polygons using the tool instructions shown while active.'),
        'usage_ja': ('参照メッシュを準備し、コマンドまたはワークスペースツールから PolyQuilt を起動します。', '起動中に表示される操作指示に従って、ポリゴンを描画・延長・調整します。'),
    },
    'real_snow': {
        'overview_en': ('Generates snow meshes on selected objects or surfaces.', 'Useful for environment dressing and quick winter-scene detailing.'),
        'overview_ja': ('選択オブジェクトやサーフェス上に雪メッシュを生成します。', '環境装飾や冬景色のディテール作成に向いています。'),
        'usage_en': ('Select the target object, set snow amount and surface behavior, then generate snow.', 'Adjust generated mesh density and material after previewing the result.', 'Pressed in Edit Mode, it switches to Object Mode first; with Selected Faces on, snow forms only on the faces selected while editing. With no face selected it stops and shows a message.'),
        'usage_ja': ('対象オブジェクトを選択し、雪の量やサーフェス挙動を設定して生成します。', '結果を確認しながら、生成メッシュ密度やマテリアルを調整します。', '編集モードで押すと、オブジェクトモードへ切り替えてから作ります。「選択した面」がオンなら、編集中に選んだ面にだけ雪を作ります。面を選んでいない時は、作らずにメッセージを出します。'),
    },
    'sapling_tree_gen': {
        'overview_en': ('Procedural tree generator for trunks, branches, leaves, and presets.', 'Useful for quickly creating vegetation assets inside Blender.'),
        'overview_ja': ('幹、枝、葉、プリセットを扱うプロシージャル樹木生成ツールです。', 'Blender内で植生アセットを素早く作る用途に向いています。'),
        'usage_en': ('Choose a preset or start from default tree settings, then generate the tree.', 'Refine branch levels, shape, leaves, bevels, and randomness before finalizing.'),
        'usage_ja': ('プリセットを選ぶか既定設定から開始し、樹木を生成します。', '確定前に枝レベル、形状、葉、ベベル、ランダム性を調整します。'),
    },
    'scatter_objects': {
        'overview_en': ('Distributes object instances across another object or surface.', 'Useful for placing details such as stones, debris, vegetation, or repeated props.'),
        'overview_ja': ('別オブジェクトやサーフェス上にオブジェクトインスタンスを散布します。', '石、破片、植生、反復プロップなどの配置に向いています。'),
        'usage_en': ('Select or assign the source objects and the target scatter surface.', 'Set count, distribution, rotation, scale, and filtering options, then generate the scatter.'),
        'usage_ja': ('散布元オブジェクトと散布先サーフェスを選択または指定します。', '数、分布、回転、スケール、フィルタ設定を指定して散布を生成します。'),
    },
    'tissue': {
        'overview_en': ('Advanced mesh tessellation and reaction-diffusion toolkit.', 'Some workflows can use frame-change handlers for animated or automatically updating effects.'),
        'overview_ja': ('高度なメッシュテッセレーションとリアクション拡散のツールキットです。', '一部ワークフローでは、アニメーションや自動更新効果のためにフレーム変更ハンドラーを使います。'),
        'usage_en': ('Select generator and component meshes according to the Tissue operation you want to run.', 'Keep the Always-on toggle disabled unless automatic frame updates are required.', 'Run the chosen tessellation, conversion, or reaction-diffusion command and adjust its options.', "Choose a Generator before using Components, Thickness, or Selective settings. UV rotation uses the default when the generator has no mesh UV map. Turn off Component's Modifiers before using its shape keys. Reaction-Diffusion indicates when Use Modifiers is off."),
        'usage_ja': ('実行したい Tissue 操作に応じて、生成元とコンポーネントメッシュを選択します。', '自動フレーム更新が必要な場合以外は、常時機能切り替えを無効のままにします。', '目的のテッセレーション、変換、リアクション拡散コマンドを実行し、オプションを調整します。', 'Components・Thickness・Selective の設定には先に Generator を選びます。Generator にメッシュの UV マップがない場合、UV 回転は既定の回転を使います。コンポーネントのシェイプキーを使うときはそのモディファイアーをオフにします。Reaction-Diffusion は Use Modifiers がオフの場合に状態を表示します。'),
    },
}

_SMS_SUITE_PANEL_HELP_INFO = {
    'smart_modeling': {
        'overview_en': ('The Smart Modeling tab groups modeling commands by task and contains switches for tools that need to run in the background.',),
        'overview_ja': ('Smart Modeling タブは、モデリングのコマンドを作業別にまとめ、バックグラウンドで使うツールの切り替えも備えています。',),
        'usage_en': ('Open the tool section and use its controls for the current selection and mode. When a tool is ready to load, open its settings to load it. If N-panel settings are temporarily unavailable, use Rebuild N-panel Settings.',),
        'usage_ja': ('使うツールの見出しを開き、選択とモードに合う操作を実行します。「読込可能」のツールは設定を開くと読み込まれます。Nパネル設定を一時的に利用できない場合は「Nパネル設定を再構築」を押します。',),
    },
    'all_commands': {
        'overview_en': ('Displays menus and operators discovered from the bundled Smart Modeling tools.', 'Useful when you need a direct command button after loading individual tool sections.'),
        'overview_ja': ('同梱 Smart Modeling ツールから検出したメニューとオペレーターを表示します。', '個別ツールを読み込んだ後、直接コマンドボタンが必要な場合に使います。'),
        'usage_en': ('Commands are discovered automatically after install, startup, and scene load; use the N-panel list directly.', 'Return to Command Browser and press the required menu or operator button.'),
        'usage_ja': ('コマンドはインストール直後、Blender起動直後、シーン読込後に自動検出されるため、Nパネル一覧から直接使用します。', 'コマンドブラウザーへ戻り、必要なメニューまたはオペレーターボタンを押します。'),
    },
    'modifier_companion': {
        'overview_en': ('Provides companion utility commands shared with Smart Modifier workflows but kept outside stack-managed modifier tools.', 'These are explicit command buttons, not background services.'),
        'overview_ja': ('Smart Modifier ワークフローと連携する補助コマンドを、スタック管理型モディファイア外の機能として表示します。', 'これらは常駐サービスではなく、明示的に押した時だけ実行するコマンドです。'),
        'usage_en': ('Companion buttons are available from the N-panel when their context is valid.', 'Press the required command only when the current context is ready for it.'),
        'usage_ja': ('補助ツールのボタンは、条件が整った時にNパネルから使用できます。', '現在のコンテキストが整っている時だけ、必要なコマンドを押します。'),
    },
    'modifier_suite_notice': {
        'overview_en': ('Explains the division between Smart Modeling and Smart Modifier.', 'Smart Modeling keeps direct modeling helpers, generators, target-based commands, and click-start companion workflows; Smart Modifier keeps stack-managed modifier workflows.'),
        'overview_ja': ('Smart Modeling と Smart Modifier の役割分担を確認するための項目です。', 'Smart Modeling は直接モデリング補助、生成、対象依存コマンド、クリック起動の連携ワークフローを扱い、Smart Modifier はスタック管理型モディファイアワークフローを扱います。'),
        'usage_en': ('Use this section only as a compact status check for Smart Modifier detection.', 'Detailed companion commands are available from the Modifier Companion section when Smart Modifier is installed and enabled.'),
        'usage_ja': ('この項目は Smart Modifier の検出状態を簡潔に確認するために使います。', '詳細な連携コマンドは、Smart Modifier がインストールされ有効な場合にモディファイア補助から使用します。'),
    },
    'always_on_toggles': {
        'overview_en': ('Centralized control group for background-capable Smart Modeling runtimes.', 'Only tools that need handlers, timers, keymaps, draw callbacks, or persistent menu hooks are listed here.'),
        'overview_ja': ('バックグラウンド動作を持つ Smart Modeling ランタイムを一箇所で管理するグループです。', 'ハンドラー、タイマー、キーマップ、描画コールバック、常時メニュー連携が必要なツールだけをここに集約します。'),
        'usage_en': ('Turn a tool on only when you need its persistent behavior during the current session.', 'Leave unnecessary items off to keep startup, file load, and idle N-panel operation light.', "Smart Modeling does not register shortcuts automatically. Open a tool's manual keymap registration, use the location as a guide, and copy only the registration ID."),
        'usage_ja': ('現在の作業で常時動作が必要なツールだけを有効にします。', '不要な項目は無効のままにし、起動、ファイル読込、待機中のNパネル動作を軽くします。', 'Smart Modeling はショートカットを自動で登録しません。各ツールの手動キーマップ登録を開き、登録場所を目安に登録 ID のみコピーして登録します。'),
    },
    'suite_context_topology': {
        'overview_en': ('Integrated command group for context-sensitive polygon creation, fill, extrusion cleanup, inset, bridge, quad rebuilding, loop reshaping, and unbend workflows.',),
        'overview_ja': ('コンテキスト依存のポリゴン作成、面張り、押し出し整理、インセット、ブリッジ、クアッドを再構築、ループ整形、直線化をまとめた統合コマンドグループです。',),
        'usage_en': ('Select the relevant vertices, edges, faces, or mesh object, then press the command icon matching the edit you want.', 'Use the operator redo panel immediately after execution to refine action, mode, spacing, relaxation, or rebuild options.'),
        'usage_ja': ('対象の頂点、辺、面、メッシュオブジェクトを選択し、目的の編集に合うアイコンコマンドを押します。', '実行直後のオペレーター再実行パネルで、アクション、モード、間隔、リラックス、再構築オプションを調整します。'),
    },
    'suite_hard_surface_boolean': {
        'overview_en': ('Integrated hard-surface group for boolean fusion, clean apply, bevel / weighted normal stacks, planar cleanup, solidify, kit insertion, and modifier stack presets.',),
        'overview_ja': ('ブーリアン融合、適用整理、ベベル / 重み付き法線スタック、平面整理、厚み付け、キット素材を挿入、モディファイアスタックを追加をまとめたハードサーフェス統合グループです。',),
        'usage_en': ('Select a target mesh and cutter or kit objects as required by the command, then run the relevant icon.', 'Keep operations non-destructive until the result is confirmed, then use apply / clean commands when destructive cleanup is needed.'),
        'usage_ja': ('コマンドに応じて対象メッシュ、カッター、キットオブジェクトを選択し、該当アイコンを実行します。', '結果を確認するまでは非破壊スタックを維持し、破壊的整理が必要になった段階で適用・クリーンアップ系コマンドを使います。'),
    },
    'suite_curve_surface_retopo': {
        'overview_en': ('Integrated group for cable generation, rail sweep, duplicate along path, bend / projection, retopology remesh, shrinkwrap, and falloff deformation workflows.',),
        'overview_ja': ('ケーブル生成、レールスイープ、パス複製、曲げ / 投影、リトポリメッシュ、シュリンクラップ、フォールオフで変形をまとめた統合グループです。',),
        'usage_en': ('Use curves, selected edges, or mesh targets depending on the command.', 'After execution, refine bevel depth, remesh method, shrinkwrap behavior, bend amount, or falloff settings in the redo panel.'),
        'usage_ja': ('コマンドに応じてカーブ、選択辺、メッシュターゲットを使います。', '実行後、ベベル深度、リメッシュ方式、シュリンクラップの挙動、曲げ量、フォールオフ設定を再実行パネルで調整します。'),
    },
    'suite_procedural_generation': {
        'overview_en': ('Integrated procedural group for surface scatter, floors, walls, stairs, facade grids, terrain, wire detail, and slice guide generation.',),
        'overview_ja': ('表面に散布、床、壁、階段、ファサードグリッド、地形、ワイヤーディテール、スライスガイド生成をまとめたプロシージャル統合グループです。',),
        'usage_en': ('Select the target surface or object and run the generator command.', 'Use the redo panel to set counts, scale ranges, tile sizes, seed values, terrain resolution, slice counts, and related generation parameters.'),
        'usage_ja': ('対象サーフェスまたはオブジェクトを選択し、生成コマンドを実行します。', '再実行パネルで、数、スケール範囲、タイルサイズ、シード値、地形解像度、スライス数などの生成パラメータを調整します。'),
    },
    'suite_cleanup_cad_layout': {
        'overview_en': ('Integrated cleanup and layout group for mesh repair audit, CAD import cleaning, cursor / origin / workplane tools, drop / snap placement, replacement randomization, and solo visibility.',),
        'overview_ja': ('メッシュを監査して修復、CADインポートを整理、カーソル / 原点 / 作業平面、接地 / スナップ配置、置換ランダム化、単独表示をまとめた整理・配置統合グループです。',),
        'usage_en': ('Select the objects or meshes to clean, align, drop, replace, randomize, isolate, or reveal.', 'Use command options to control cleanup scope, placement mode, replacement behavior, random transform range, or visibility mode.'),
        'usage_ja': ('整理、整列、接地、置換、ランダム化、単独表示、全表示したいオブジェクトまたはメッシュを選択します。', 'コマンドオプションで、整理範囲、配置モード、置換挙動、ランダム変換範囲、表示モードを指定します。'),
    },
}



_SMS_MODELING_SECTION_OPERATOR_GROUPS = {
    'suite_context_topology': (
        ('smsuite.context_modeler', 'Context Modeler', 'Context-sensitive fill, inset, bridge, extrusion, and auto modeling command.'),
        ('smsuite.quad_rebuild', 'Rebuild Quads', 'Quad-oriented rebuild, grid fill, triangle-to-quad, and N-gon cleanup command.'),
        ('smsuite.loop_shape_suite', 'Shape Loops', 'Circle, relax, and spacing tools for selected loops and vertex groups.'),
        ('smsuite.align_unbend', 'Align / Unbend', 'Straightens or unbends selected geometry into a cleaner line or plane.'),
    ),
    'suite_hard_surface_boolean': (
        ('smsuite.boolean_fusion_stack', 'Create Boolean Fusion', 'Creates a non-destructive boolean stack using selected cutter objects.'),
        ('smsuite.boolean_apply_clean', 'Boolean Apply Clean', 'Applies boolean stacks and performs post-apply mesh cleanup.'),
        ('smsuite.bevel_normal_stack', 'Create Bevel Normal Stack', 'Adds bevel and weighted normal support for hard-surface shading.'),
        ('smsuite.unbevel_planar_clean', 'Clean Planar Bevels', 'Flattens and simplifies planar or unbevel-style selections.'),
        ('smsuite.solidify_plus', 'Create Solidify Shell', 'Adds controlled thickness and normal-aware solidify support.'),
        ('smsuite.kit_insert', 'Insert Kit Asset', 'Places kitbash objects onto the active surface and optionally prepares boolean cuts.'),
        ('smsuite.modifier_stack_preset', 'Add Modifier Stack', 'Applies hard-surface or procedural-detail modifier stack presets.'),
    ),
    'suite_curve_surface_retopo': (
        ('smsuite.cable_pipe_from_selection', 'Create Cable Pipe', 'Builds cable or pipe curves from selected edges or objects.'),
        ('smsuite.rail_sweep_generator', 'Generate Rail Sweep', 'Creates pipes or duplicates objects along curves and rails.'),
        ('smsuite.bend_projection', 'Bend / Project', 'Bends selected meshes or projects geometry toward target surfaces.'),
        ('smsuite.retopo_wrap_remesh', 'Wrap and Remesh', 'Creates voxel remesh or shrinkwrap-based retopology support.'),
        ('smsuite.falloff_deform', 'Deform with Falloff', 'Applies falloff-style proportional deformation.'),
    ),
    'suite_procedural_generation': (
        ('smsuite.scatter_surface', 'Scatter on Surface', 'Scatters selected source objects over an evaluated target mesh surface.'),
        ('smsuite.floor_wall_generator', 'Floor / Wall / Stairs / Facade Generator', 'Generates architectural floor, wall, stair, and facade geometry.'),
        ('smsuite.terrain_generator', 'Terrain Generator', 'Generates procedural terrain mesh from resolution, size, height, and seed settings.'),
        ('smsuite.slice_wire_detail', 'Slice / Wire Detail', 'Adds wireframe detail modifiers or creates slicing guide geometry.'),
    ),
    'suite_cleanup_cad_layout': (
        ('smsuite.mesh_repair_audit', 'Audit and Repair Mesh', 'Finds and optionally repairs common mesh validity issues.'),
        ('smsuite.cad_import_cleaner', 'Clean CAD Import', 'Converts and cleans imported CAD-like objects for Blender mesh workflows.'),
        ('smsuite.workplane_pivot_tools', 'Workplane / Pivot Tools', 'Moves cursor and origin or creates temporary workplane helpers.'),
        ('smsuite.drop_snap_tools', 'Drop / Snap Tools', 'Drops objects to surfaces, floors, or snap origin positions.'),
        ('smsuite.asset_replace_randomize', 'Asset Replace / Randomize', 'Replaces selected assets or applies randomized transform variation.'),
        ('smsuite.magic_solo', 'Solo Visibility', 'Isolates, hides, or reveals objects for visibility-focused editing.'),
    ),
}

_SMS_WORKFLOW_CATEGORY_HELP_INFO = {
    'suite_context_topology': {
        'label_en': 'Context and Topology',
        'label_ja': 'コンテキスト編集とトポロジー',
        'icon': 'EDITMODE_HLT',
        'operators': ('smsuite.context_modeler', 'smsuite.quad_rebuild', 'smsuite.loop_shape_suite', 'smsuite.align_unbend'),
        'overview_en': ('Context-sensitive modeling, F2-style face creation, quad rebuilding, loop circularization, relaxation, spacing, and line/unbend cleanup are grouped here.', 'Use this group for direct topology construction and fast correction before hard-surface or retopology passes.'),
        'overview_ja': ('コンテキスト依存モデリング、F2風の面張り、クアッドを再構築、ループの円形化、リラックス、等間隔化、直線化をまとめた項目です。', 'ハードサーフェス処理やリトポ前に、直接的なトポロジ構築と形状補正を素早く行うために使います。'),
        'usage_en': ('Select vertices, edges, or faces in Edit Mode, then press the command that matches the intended topology operation.', 'Use the redo panel immediately after execution to tune action, mode, distance, iterations, or cleanup behavior.'),
        'usage_ja': ('編集モードで頂点、辺、面を選択し、目的のトポロジ操作に合うコマンドを押します。', '実行直後のリドゥパネルで、アクション、モード、距離、反復回数、整理方法を調整します。'),
    },
    'suite_hard_surface_boolean': {
        'label_en': 'Hard Surface Modeling and Boolean',
        'label_ja': 'ハードサーフェスとブーリアン',
        'icon': 'MOD_BOOLEAN',
        'operators': ('smsuite.boolean_fusion_stack', 'smsuite.boolean_apply_clean', 'smsuite.bevel_normal_stack', 'smsuite.unbevel_planar_clean', 'smsuite.solidify_plus', 'smsuite.kit_insert', 'smsuite.modifier_stack_preset'),
        'overview_en': ('Non-destructive booleans, apply-and-clean passes, bevel / weighted-normal stacks, shelling, planar cleanup, and kit insertion are grouped here.', 'Use this group for hard-surface concept modeling, cutter-based detailing, and clean shading preparation.'),
        'overview_ja': ('非破壊ブーリアン、適用整理、ベベル / 重み付き法線スタック、厚み付け、平面整理、キット素材を挿入をまとめた項目です。', 'ハードサーフェスのコンセプトモデリング、カッターによるディテール追加、綺麗な陰影の下準備に使います。'),
        'usage_en': ('Make the target mesh active, select cutters or kit objects as needed, then run the boolean, bevel, solidify, or cleanup command.', 'Adjust bevel width, merge distance, operation type, solver behavior, and apply options in the redo panel.'),
        'usage_ja': ('対象メッシュをアクティブにし、必要に応じてカッターやキットオブジェクトを選択して、ブーリアン、ベベル、厚み付け、整理コマンドを実行します。', 'リドゥパネルで、ベベル幅、マージ距離、ブーリアン種別、ソルバー挙動、適用オプションを調整します。'),
    },
    'suite_curve_surface_retopo': {
        'label_en': 'Curve, Surface, and Retopo',
        'label_ja': 'カーブ、面追従、リトポ',
        'icon': 'CURVE_BEZCURVE',
        'operators': ('smsuite.cable_pipe_from_selection', 'smsuite.rail_sweep_generator', 'smsuite.bend_projection', 'smsuite.retopo_wrap_remesh', 'smsuite.falloff_deform'),
        'overview_en': ('Cable / pipe generation, rail sweep, path duplication, simple bending, surface projection, remesh, shrinkwrap, and radial falloff deformation are grouped here.', 'Use this group when geometry must follow curves, surfaces, or controlled deformation fields.'),
        'overview_ja': ('ケーブル / パイプ生成、レールスイープ、パス複製、シンプルな曲げ、面投影、リメッシュ、シュリンクラップ、放射フォールオフで変形をまとめた項目です。', '形状をカーブ、サーフェス、制御された変形範囲へ追従させたい時に使います。'),
        'usage_en': ('Prepare curves, mesh edges, target surfaces, or selected vertices depending on the command.', 'Tune radius, resolution, remesh method, shrinkwrap distance, projection height, falloff radius, and strength in the redo panel.'),
        'usage_ja': ('コマンドに応じて、カーブ、メッシュ辺、ターゲット面、選択頂点を準備します。', 'リドゥパネルで、半径、解像度、リメッシュ方式、シュリンクラップの距離、投影高さ、フォールオフ半径、強さを調整します。'),
    },
    'suite_procedural_generation': {
        'label_en': 'Procedural Generation',
        'label_ja': 'プロシージャル生成',
        'icon': 'GEOMETRY_NODES',
        'operators': ('smsuite.scatter_surface', 'smsuite.floor_wall_generator', 'smsuite.terrain_generator', 'smsuite.slice_wire_detail'),
        'overview_en': ('Surface scatter, floor tiles, brick walls, stairs, facades, terrain meshes, wire details, and slice guides are grouped here.', 'Use this group for environment blocking, architectural patterns, layout variation, and procedural detail passes.'),
        'overview_ja': ('表面に散布、床タイル、レンガ壁、階段、ファサード、地形メッシュ、ワイヤーディテール、スライスガイドをまとめた項目です。', '環境ブロックアウト、建築パターン、配置バリエーション、プロシージャルなディテール追加に使います。'),
        'usage_en': ('For scatter, select source objects and make the target surface active. For generators, set dimensions and counts in the redo panel after creation.', 'Use seed, count, rows, columns, size, roughness, and randomization settings to create repeatable variations.'),
        'usage_ja': ('散布ではソースオブジェクトを選択し、対象サーフェスをアクティブにします。生成系では作成後のリドゥパネルで寸法や数を設定します。', 'シード、数、行数、列数、サイズ、粗さ、ランダム化設定を使い、再現可能なバリエーションを作ります。'),
    },
    'suite_cleanup_cad_layout': {
        'label_en': 'Cleanup, CAD, and Layout',
        'label_ja': '整理、CAD、配置',
        'icon': 'TOOL_SETTINGS',
        'operators': ('smsuite.mesh_repair_audit', 'smsuite.cad_import_cleaner', 'smsuite.workplane_pivot_tools', 'smsuite.drop_snap_tools', 'smsuite.asset_replace_randomize', 'smsuite.magic_solo'),
        'overview_en': ('Mesh repair, CAD import cleanup, workplane / cursor / origin utilities, drop and snap placement, asset replacement, randomization, and solo visibility are grouped here.', 'Use this group to stabilize imported assets, align layout pieces, and inspect complex scenes without starting background services.'),
        'overview_ja': ('メッシュ修復、CADインポートを整理、作業平面 / カーソル / 原点補助、接地とスナップ配置、アセット置換、ランダム化、単独表示をまとめた項目です。', 'インポート素材の安定化、レイアウト部品の整列、複雑なシーンの確認を、常駐処理なしで行うために使います。'),
        'usage_en': ('Select the objects to repair, clean, drop, snap, replace, or isolate. Make the target or replacement object active where required.', 'Adjust merge distance, transform application, conversion, ray height, random scale, random rotation, and visibility mode in the redo panel.'),
        'usage_ja': ('修復、整理、接地、スナップ、置換、単独表示したいオブジェクトを選択します。必要な場合はターゲットまたは置換元をアクティブにします。', 'リドゥパネルで、マージ距離、トランスフォーム適用、変換、レイ高さ、ランダムスケール、ランダム回転、表示モードを調整します。'),
    },
}


def _sms_help_lines(info: dict, key_en: str, key_ja: str, context=None) -> tuple[str, ...]:
    if not isinstance(info, dict):
        return tuple()
    key = key_ja if _language.is_japanese(context) else key_en
    value = info.get(key)
    if isinstance(value, str):
        return tuple(line.strip() for line in value.splitlines() if line.strip())
    return tuple(str(line or '').strip() for line in tuple(value or ()) if str(line or '').strip())


def _sms_suite_help_item(alias: str) -> dict:
    alias = str(alias or '').strip()
    if not alias:
        return {}
    try:
        for item in tuple(_SMS_SUITE_PANEL_ITEMS or ()):  # provided by core
            if str((item or {}).get('id') or '').strip() == alias:
                return dict(item)
    except Exception:
        pass
    return {}


def _sms_native_help_label(tool_id: str, context=None) -> str:
    tool_id = str(tool_id or '').strip()
    try:
        meta = _sms_native_tool_meta(tool_id) or {}
    except Exception:
        meta = {}
    return _ui_text(str(meta.get('label') or tool_id.replace('_', ' ').title()), context)


def _sms_prefixed_native_help_lines(tool_id: str, context=None, *, usage=False) -> tuple[str, ...]:
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return tuple()
    info = dict(_SMS_NATIVE_HELP_INFO.get(tool_id) or {})
    if usage:
        lines = _sms_help_lines(info, 'usage_en', 'usage_ja', context)
    else:
        lines = _sms_help_lines(info, 'overview_en', 'overview_ja', context)
    if not lines:
        return tuple()
    label = _sms_native_help_label(tool_id, context)
    output = []
    for index, line in enumerate(lines):
        if index == 0:
            output.append(f'{label}: {line}')
        else:
            output.append(f'  {line}')
    return tuple(output)


def _sms_linked_native_ids_for_suite_panel(alias: str) -> tuple[str, ...]:
    item = _sms_suite_help_item(alias)
    result = []
    for tool_id in tuple(item.get('native_tool_ids') or ()):  # pragma: no branch
        text = str(tool_id or '').strip()
        if text and text not in result:
            result.append(text)
    return tuple(result)


def _sms_append_suite_panel_linked_function_help(kind: str, alias: str, overview: tuple[str, ...], usage: tuple[str, ...], context=None) -> tuple[tuple[str, ...], tuple[str, ...]]:
    del kind, alias, context
    # The popup must explain only the item whose Help button was clicked.
    # Linked tool details stay behind each linked tool's own Help button.
    return tuple(overview or ()), tuple(usage or ())


def _sms_append_linked_native_setting_sections(sections: list[dict], native_ids: tuple[str, ...], context=None) -> None:
    del sections, native_ids, context
    # Linked tool settings are intentionally excluded here so each Help popup
    # stays scoped to the clicked item only.
    return None



def _sms_workflow_category_record(alias: str, context=None) -> tuple[str, str, dict]:
    alias = str(alias or '').strip()
    if alias in _SMS_MODELING_SECTION_OPERATOR_GROUPS:
        info = dict(_SMS_SUITE_PANEL_HELP_INFO.get(alias) or {})
        label_map = {
            'suite_context_topology': ('Context and Topology', 'コンテキスト編集とトポロジー', 'EDITMODE_HLT'),
            'suite_hard_surface_boolean': ('Hard Surface Modeling and Boolean', 'ハードサーフェスとブーリアン', 'MOD_BOOLEAN'),
            'suite_curve_surface_retopo': ('Curve, Surface, and Retopo', 'カーブ、面追従、リトポ', 'CURVE_DATA'),
            'suite_procedural_generation': ('Procedural Generation', 'プロシージャル生成', 'OUTLINER_COLLECTION'),
            'suite_cleanup_cad_layout': ('Cleanup, CAD, and Layout', '整理、CAD、配置', 'TOOL_SETTINGS'),
        }
        en, ja, icon = label_map.get(alias, (alias.replace('_', ' ').title(), alias.replace('_', ' ').title(), 'TOOL_SETTINGS'))
        return _pick_lang(en, ja, context), icon, info
    try:
        for category in tuple(_SMS_WORKFLOW_CATEGORY_DEFS or ()):  # pragma: no branch
            if str((category or {}).get('id') or '').strip() == alias:
                label = _pick_lang(str((category or {}).get('label_en') or alias), str((category or {}).get('label_ja') or alias), context)
                info = {
                    'overview_en': (f'{label} groups related Smart Modeling tools so their settings stay compact in the N-panel.', 'The N-panel shows only the grouped tool names, settings toggles, and Help buttons; detailed explanations are kept inside this popup.'),
                    'overview_ja': (f'{label} は関連する Smart Modeling ツールをまとめ、Nパネルの設定表示を簡潔に保つためのグループです。', 'Nパネル本体にはツール名、設定切り替え、ヘルプボタンだけを表示し、詳細解説はこのポップアップに集約します。'),
                    'usage_en': ('Open a tool row only when you need its controls, or use the Help button for detailed function and setting references.', 'Persistent tools should be enabled from the Always-on Toggles group only when their background runtime is needed.'),
                    'usage_ja': ('操作項目が必要な時だけツール行を開き、機能と設定の詳細はヘルプボタンから確認します。', '常時機能系ツールは、バックグラウンド動作が必要な時だけ「常時機能切り替え」で有効にします。'),
                }
                return label, _sms_safe_icon((category or {}).get('icon'), 'TOOL_SETTINGS'), info
    except Exception:
        pass
    return alias.replace('_', ' ').title(), 'TOOL_SETTINGS', {}


def _sms_category_items(alias: str, context=None) -> list[dict]:
    alias = str(alias or '').strip()
    try:
        prefs = _sms_get_suite_prefs(context)
    except Exception:
        prefs = None
    try:
        grouped = _sms_group_unified_items(_sms_build_unified_items(context, prefs))
    except Exception:
        grouped = []
    for category, items in tuple(grouped or ()):  # pragma: no branch
        if str((category or {}).get('id') or '').strip() == alias:
            return list(items or [])
    return []


def _sms_item_help_kind_alias(item: dict) -> tuple[str, str]:
    kind = str((item or {}).get('kind') or '').strip()
    if kind == 'native':
        return kind, str(((item or {}).get('meta') or {}).get('tool_id') or '').strip()
    if kind == 'integrated':
        return kind, str(((item or {}).get('spec') or {}).get('alias') or '').strip()
    if kind == 'suite_panel':
        return kind, str((item or {}).get('id') or '').strip()
    return kind, str((item or {}).get('id') or (item or {}).get('label') or '').strip()

_SMS_SECTION_HELP_INFO = {
    'ui_section_main_options': (
        'Vertex Copy Options',
        '頂点コピーの設定',
        'Control which vertices receive the copied positions and whether to write them to a shape key.',
        'コピーした位置を適用する頂点と、シェイプキーへの書き込みを設定します。',
        'Use the same vertex order on both meshes for Same Vertex Number transfer.',
        '頂点数一致モードで転送する場合は、両方のメッシュの頂点順をそろえます。',
    ),
    'ui_section_auxiliary': (
        'Vertex Copy Auxiliary Functions',
        '頂点コピーの補助機能',
        'Access mirror, smart matching, surface projection, and transfer presets.',
        'ミラー、スマートマッチング、表面への投影、転送プリセットを利用できます。',
        'Choose a transfer mode that matches the source and target geometry.',
        'コピー元と貼り付け先の形状に合う転送モードを選びます。',
    ),
    'ui_section_expert_matching': (
        'Advanced Vertex Matching',
        '頂点マッチングの詳細設定',
        'Adjust how Smart mode weighs candidate matches.',
        'スマートモードで対応候補を評価する重みを調整します。',
        'Tune the tolerances and weights when the initial vertex correspondence is inaccurate.',
        '頂点の対応がずれる場合は、許容値と重みを調整します。',
    ),
    'edit_mesh_vert': (
        'Vertex Tools',
        '頂点ツール',
        'Edit individual vertices and align their positions.',
        '頂点を編集し、位置を整列します。',
        'Select vertices in Edit Mode and choose a vertex command. Use the adjacent menu for selection tools.',
        '編集モードで頂点を選択してコマンドを実行します。選択ツールは隣のメニューから開きます。',
    ),
    'edit_mesh_edge': (
        'Edge Tools',
        '辺ツール',
        'Offset, bevel, round, or change the length of mesh edges.',
        'メッシュの辺のオフセット、ベベル、丸め、長さの変更を行います。',
        'Select edges in Edit Mode before running the desired command.',
        '編集モードで辺を選択してから、目的のコマンドを実行します。',
    ),
    'edit_mesh_face': (
        'Face Tools',
        '面ツール',
        'Inset, cut, extrude, or add thickness to mesh faces.',
        'メッシュの面を差し込み、切断、押し出し、または厚み付けします。',
        'Select the faces to edit and choose the corresponding command.',
        '編集する面を選択し、対応するコマンドを実行します。',
    ),
    'edit_mesh_util': (
        'Utility Tools',
        'ユーティリティツール',
        'Clean up mesh geometry, convert faces, and correct normals.',
        'メッシュ形状の整理、面の変換、法線の修正を行います。',
        'Select the geometry to process, then choose the cleanup or conversion command.',
        '処理する形状を選択し、整理または変換のコマンドを実行します。',
    ),
    'looptools_bridge': (
        'Bridge',
        'ブリッジ',
        'Create faces between selected boundary loops.',
        '選択した境界ループの間に面を作成します。',
        'Select the loops in Edit Mode and set the number of segments before running Bridge.',
        '編集モードでループを選択し、分割数を設定してからブリッジを実行します。',
    ),
    'looptools_loft': (
        'Loft',
        'ロフト',
        'Create a surface through a series of selected loops.',
        '選択した複数のループを結んでサーフェスを作成します。',
        'Select the loops and adjust the interpolation or loop settings before running Loft.',
        'ループを選択し、補間やループの設定を調整してからロフトを実行します。',
    ),
    'keyops_set_bevel': (
        'Set Bevel',
        'ベベル設定',
        'Adjust bevel modifier settings on selected objects.',
        '選択したオブジェクトのベベルモディファイアを調整します。',
        'In Object Mode, choose the setting to change and apply the value or percentage.',
        'オブジェクトモードで項目を選び、値または割合を適用します。',
    ),
    'keyops_edit_settings': (
        'Edit Panel Settings',
        '編集パネル設定',
        'Configure the Key Operators Toolkit Edit Mesh panel.',
        'Key Operators Toolkit のメッシュ編集パネルを設定します。',
        'Enable the 3ds Max inspired layout to arrange the edit commands in that style.',
        '3ds Max 風のレイアウトを有効にすると、編集コマンドの配置が切り替わります。',
    ),
    'mio3_flex_options': (
        'Mio3 Flex Options',
        'Mio3 Flex オプション',
        'Configure how Mio3 Flex handles edge density and displays the original edges.',
        'Mio3 Flex の辺の密度と元の辺の表示を設定します。',
        'Enable Auto Density to adjust density automatically. Enable Show Original Edge to display the starting edge.',
        '密度を自動調整するには「自動密度」を有効にします。元の辺を表示するには「元の辺を表示」を有効にします。',
    ),
    'keyops_polycount_sort': (
        'Polygon Count Sorting',
        'ポリゴン数の並べ替え',
        'Sort objects by name or by the displayed geometry counts.',
        '名前や表示中の要素数でオブジェクトを並べ替えます。',
        'Click a column button to sort. Click the active column again to reverse the order.',
        '列のボタンを押して並べ替えます。同じ列をもう一度押すと順序が逆になります。',
    ),
    'keyops_polycount_settings': (
        'Polycount Settings',
        'ポリゴン数の設定',
        'Choose which objects and geometry counts appear in the list.',
        '一覧に表示するオブジェクトと要素数を選びます。',
        'Set the object and collection filters, visible columns, and maximum list length.',
        'オブジェクトとコレクションの絞り込み、表示する列、一覧の最大件数を設定します。',
    ),
    'keyops_polycount_auto_update': (
        'Polycount Auto Update',
        'ポリゴン数の自動更新',
        'Control automatic refresh of the polygon counts.',
        'ポリゴン数の自動更新を設定します。',
        'Enable Auto Update to refresh the counts as the scene changes.',
        'シーンの変更に合わせて更新するには「自動更新」を有効にします。',
    ),
    'keyops_material_order': (
        'Material Index Order',
        'マテリアルインデックスの順序',
        'Move an entry within the material index list.',
        'マテリアルインデックス一覧内で項目を移動します。',
        'Select an entry and press Up or Down to change its order.',
        '項目を選択し、「上」または「下」を押して順序を変更します。',
    ),
}


def _sms_tool_help_content(kind: str, alias: str, context=None) -> dict:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    info = {}
    label = alias.replace('_', ' ').title() if alias else _pick_lang('Tool', 'ツール', context)
    icon = 'HELP'

    if kind == 'native':
        meta = _sms_native_tool_meta(alias) or {}
        label = _ui_text(str(meta.get('label') or label), context)
        icon = _sms_safe_icon(meta.get('icon'), 'HELP')
        info = dict(_SMS_NATIVE_HELP_INFO.get(alias) or {})
    elif kind == 'section' and alias in _SMS_SECTION_HELP_INFO:
        label_en, label_ja, overview_en, overview_ja, usage_en, usage_ja = _SMS_SECTION_HELP_INFO[alias]
        label = _pick_lang(label_en, label_ja, context)
        info = {
            'overview_en': (overview_en,), 'overview_ja': (overview_ja,),
            'usage_en': (usage_en,), 'usage_ja': (usage_ja,),
        }
    elif kind == 'integrated':
        try:
            from . import registry as _sms_registry
            visible_spec = getattr(_sms_registry, 'is_visible_addon_spec', lambda spec: True)
            for spec in _sms_registry.build_specs(force=False):
                if not bool(visible_spec(spec)):
                    continue
                if str(spec.get('alias') or '').strip() == alias:
                    label = _ui_text(str(spec.get('display_name') or label), context)
                    if not info:
                        info = dict(_SMS_INTEGRATED_HELP_INFO.get(alias) or {})
                    if not info:
                        desc = str(spec.get('description') or '').strip()
                        desc_en = _sms_clean_help_text(desc, context) if desc else ''
                        info = {
                            'overview_en': (desc_en or f'{label} integrated modeling tool.',),
                            'overview_ja': (f'{label} の統合モデリングツールです。',),
                            'usage_en': ('This tool is registered automatically; use its displayed N-panel controls when needed.', 'Use the displayed panel, menus, or operators for the current selection and mode.'),
                            'usage_ja': ('このツールは自動登録されるため、必要な時に表示されたNパネル操作項目を使用します。', '現在の選択とモードに合わせて、表示されたパネル、メニュー、オペレーターを使用します。'),
                        }
                    break
        except Exception:
            info = dict(_SMS_INTEGRATED_HELP_INFO.get(alias) or {})
        if not info:
            info = dict(_SMS_INTEGRATED_HELP_INFO.get(alias) or {})
    elif kind == 'suite_panel':
        panel_info = dict(_SMS_SUITE_PANEL_HELP_INFO.get(alias) or {})
        info = panel_info
        try:
            for item in _SMS_SUITE_PANEL_ITEMS:
                if str(item.get('id') or '').strip() == alias:
                    label = _sms_suite_panel_item_label(item, context)
                    icon = _sms_safe_icon(item.get('icon'), 'HELP')
                    if not info:
                        info = {
                            'overview_en': (str(item.get('description_en') or '').strip() or f'{label} command section.',),
                            'overview_ja': (str(item.get('description_ja') or '').strip() or f'{label} のコマンド項目です。',),
                            'usage_en': ('Available command buttons are shown in the N-panel when the tool and context are ready.', 'Press the command that matches the current mode and selection.'),
                            'usage_ja': ('利用可能なコマンドボタンは、ツールとコンテキストが整った時にNパネルへ表示されます。', '現在のモードと選択に合うコマンドを実行します。'),
                        }
                    break
        except Exception:
            pass
    elif kind == 'runtime_group':
        label = _pick_lang('Always-on Toggles', '常時機能切り替え', context) if alias == 'always_on_toggles' else label
        icon = 'TIME'
        info = dict(_SMS_SUITE_PANEL_HELP_INFO.get(alias) or {})
    elif kind == 'workflow_category':
        label, icon, info = _sms_workflow_category_record(alias, context)

    overview = _sms_help_lines(info, 'overview_en', 'overview_ja', context)
    usage = _sms_help_lines(info, 'usage_en', 'usage_ja', context)
    if not overview:
        overview = (_pick_lang('This tool provides Smart Modeling functionality for the current workflow.', 'このツールは現在のワークフロー向けの Smart Modeling 機能を提供します。', context),)
    if not usage:
        usage = (_pick_lang('Use the displayed N-panel controls for the current context.', '現在のコンテキストに合わせてNパネルに表示された操作項目を使用します。', context),)
    overview, usage = _sms_append_suite_panel_linked_function_help(kind, alias, tuple(overview or ()), tuple(usage or ()), context)
    settings = _sms_tool_setting_help_sections(kind, alias, context)
    return {'label': label, 'icon': icon, 'overview': overview, 'usage': usage, 'settings': settings}


def _sms_text_display_width(text: str) -> int:
    """Return an approximate UI-cell width used only as a font-metric fallback."""
    width = 0
    for ch in str(text or ''):
        if ch == '	':
            width += 4
            continue
        if unicodedata.combining(ch):
            continue
        width += 2 if unicodedata.east_asian_width(ch) in {'F', 'W'} else 1
    return width


_SMS_HELP_POPUP_WIDTH_FALLBACK = 640
_SMS_HELP_POPUP_TEXT_GUTTER = 118
_SMS_HELP_POPUP_ICON_GUTTER = 24
_SMS_HELP_POPUP_INNER_GUTTER = 14
_SMS_HELP_POPUP_MIN_TEXT_WIDTH = 180
_SMS_HELP_NO_LINE_START = '、。，．,.）)」』】］]｝}！？!?：；:;ー・'


def _sms_help_popup_width_pixels(context=None) -> int:
    """Return the help popup pixel width used by the active operator."""
    try:
        runtime = _RUNTIME or _bind_runtime()
        width = int(getattr(runtime, '_SMS_HELP_POPUP_WIDTH', 0) or 0)
        if width > 0:
            return width
    except Exception:
        pass
    try:
        width = int(globals().get('_SMS_HELP_POPUP_WIDTH') or 0)
        if width > 0:
            return width
    except Exception:
        pass
    return int(_SMS_HELP_POPUP_WIDTH_FALLBACK)


def _sms_help_ui_scale(context=None) -> float:
    try:
        if context is None and bpy is not None:
            context = bpy.context
    except Exception:
        context = None
    try:
        scale = float(getattr(getattr(context, 'preferences', None).system, 'ui_scale', 1.0) or 1.0)
    except Exception:
        scale = 1.0
    return max(0.5, min(4.0, scale))


def _sms_set_blf_ui_size(context=None) -> None:
    try:
        import blf
    except Exception:
        return
    points = 11
    dpi = 72
    try:
        if context is None and bpy is not None:
            context = bpy.context
    except Exception:
        context = None
    try:
        styles = getattr(getattr(context, 'preferences', None), 'ui_styles', None)
        if styles:
            points = int(getattr(styles[0].widget, 'points', points) or points)
    except Exception:
        pass
    try:
        dpi = int(getattr(getattr(getattr(context, 'preferences', None), 'system', None), 'dpi', dpi) or dpi)
    except Exception:
        pass
    try:
        blf.size(0, points, dpi)
    except TypeError:
        try:
            blf.size(0, points)
        except Exception:
            pass
    except Exception:
        pass


def _sms_text_pixel_width(text: str, context=None) -> float:
    text = str(text or '').replace('	', '    ')
    if not text:
        return 0.0
    try:
        import blf
        _sms_set_blf_ui_size(context)
        size = blf.dimensions(0, text) or (0.0, 0.0)
        width = float(size[0] or 0.0)
        if width > 0:
            return width
    except Exception:
        pass
    return float(_sms_text_display_width(text)) * (7.25 * _sms_help_ui_scale(context))


def _sms_help_available_text_pixels(context=None, *, icon='NONE', inner_level: int = 0) -> int:
    popup_width = _sms_help_popup_width_pixels(context)
    gutter = _SMS_HELP_POPUP_TEXT_GUTTER + max(0, int(inner_level or 0)) * _SMS_HELP_POPUP_INNER_GUTTER
    try:
        if str(icon or 'NONE').upper() not in {'', 'NONE', 'BLANK1'}:
            gutter += _SMS_HELP_POPUP_ICON_GUTTER
    except Exception:
        pass
    return max(_SMS_HELP_POPUP_MIN_TEXT_WIDTH, int(popup_width - gutter))


def _sms_split_long_token_pixels(token: str, max_pixels: float, context=None, *, min_pixels: float | None = None) -> list[str]:
    token = str(token or '')
    if not token:
        return []
    if min_pixels is None:
        min_pixels = _SMS_HELP_POPUP_MIN_TEXT_WIDTH
    max_pixels = max(float(min_pixels), float(max_pixels or 0.0))
    if _sms_text_pixel_width(token, context) <= max_pixels:
        return [token]
    lines: list[str] = []
    current = ''
    for ch in token:
        candidate = current + ch
        if current and _sms_text_pixel_width(candidate, context) > max_pixels:
            # A closing mark does not start a line: the character before it moves along.
            if ch in _SMS_HELP_NO_LINE_START and len(current) > 1:
                cut = len(current) - 1
                while cut > 1 and current[cut] in _SMS_HELP_NO_LINE_START:
                    cut -= 1
                lines.append(current[:cut])
                current = current[cut:] + ch
            else:
                lines.append(current)
                current = ch
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def _sms_wrap_help_text(text: str, *, context=None, max_pixels: float | None = None, min_pixels: float | None = None) -> list[str]:
    """Wrap help text only when its measured width exceeds the popup body."""
    text = str(text or '').replace('\r\n', '\n').replace('\r', '\n').strip()
    if not text:
        return []
    if context is None:
        try:
            context = bpy.context if bpy is not None else None
        except Exception:
            context = None
    max_pixels = float(max_pixels if max_pixels is not None else _sms_help_available_text_pixels(context))
    if min_pixels is None:
        min_pixels = _SMS_HELP_POPUP_MIN_TEXT_WIDTH
    max_pixels = max(float(min_pixels), max_pixels)
    wrapped: list[str] = []
    for paragraph in text.split('\n'):
        paragraph = str(paragraph or '').strip()
        if not paragraph:
            wrapped.append('')
            continue
        if _sms_text_pixel_width(paragraph, context) <= max_pixels:
            wrapped.append(paragraph)
            continue
        tokens = paragraph.split()
        if not tokens:
            wrapped.append('')
            continue
        line = ''
        for token in tokens:
            token = str(token or '')
            if not token:
                continue
            candidate = f'{line} {token}' if line else token
            if _sms_text_pixel_width(candidate, context) <= max_pixels:
                line = candidate
                continue
            if line:
                wrapped.append(line)
                line = ''
            if _sms_text_pixel_width(token, context) <= max_pixels:
                line = token
            else:
                parts = _sms_split_long_token_pixels(token, max_pixels, context, min_pixels=min_pixels)
                if parts:
                    wrapped.extend(parts[:-1])
                    line = parts[-1]
        if line:
            wrapped.append(line)
    return wrapped


def _sms_wrapped_label(layout, text: str, *, icon='NONE', context=None, inner_level: int = 0):
    max_pixels = _sms_help_available_text_pixels(context, icon=icon, inner_level=inner_level)
    lines = _sms_wrap_help_text(text, context=context, max_pixels=max_pixels)
    if not lines:
        return
    first = True
    for line in lines:
        if line:
            layout.label(text=line, icon=icon if first else 'BLANK1')
        else:
            layout.separator(factor=0.35)
        first = False


def _sms_prepare_tool_help_settings_context(kind: str, alias: str, context=None) -> None:
    """Load the selected tool only when the Help button is clicked.

    N-panel drawing stays light; the Help popup can still document the same
    settings that the Settings section can actually expose.
    """
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if not alias:
        return
    if kind == 'native':
        try:
            _sms_ensure_native_tool_loaded(alias, context=context)
        except Exception:
            pass
        return
    if kind == 'integrated':
        try:
            _sms_ensure_integrated_tool_loaded(alias, context=context)
        except Exception:
            pass
        return
    if kind == 'suite_panel':
        try:
            for tool_id in _sms_linked_native_ids_for_suite_panel(alias):
                try:
                    _sms_ensure_native_tool_loaded(tool_id, context=context)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            _sms_rebuild_native_tool_records()
        except Exception:
            pass
        return
    if kind == 'workflow_category':
        try:
            if alias in _SMS_MODELING_SECTION_OPERATOR_GROUPS:
                _sms_ensure_native_tool_loaded('modeling_toolset_tools', context=context)
            else:
                grouped = _sms_group_unified_items(_sms_build_unified_items(context, _sms_get_suite_prefs(context)))
                for category, items in tuple(grouped or ()):  # pragma: no branch
                    if str((category or {}).get('id') or '').strip() != alias:
                        continue
                    for item in tuple(items or ()):
                        kind2 = str((item or {}).get('kind') or '').strip()
                        if kind2 == 'native':
                            tool_id = str(((item or {}).get('meta') or {}).get('tool_id') or '').strip()
                            if tool_id:
                                _sms_ensure_native_tool_loaded(tool_id, context=context)
                        elif kind2 == 'integrated':
                            alias2 = str(((item or {}).get('spec') or {}).get('alias') or '').strip()
                            if alias2:
                                _sms_ensure_integrated_tool_loaded(alias2, context=context)
                    break
            _sms_rebuild_native_tool_records()
        except Exception:
            pass
        return


def _sms_clean_help_text(value, context=None, *, fallback='') -> str:
    text = str(value or '').strip()
    if text:
        try:
            text = _ui_text(text, context)
        except Exception:
            pass
    text = ' '.join(str(text or '').split())
    fallback = str(fallback or '').strip()
    if text:
        try:
            if fallback and _language.is_japanese(context) and _language.contains_latin(text) and not _language.contains_japanese(text):
                return fallback
        except Exception:
            pass
        return text
    return fallback


def _sms_short_type_label(prop, context=None) -> str:
    try:
        ptype = str(getattr(prop, 'type', '') or '').strip().upper()
    except Exception:
        ptype = ''
    labels = {
        'BOOLEAN': ('Boolean toggle', 'オン・オフ切り替え'),
        'INT': ('Integer value', '整数値'),
        'FLOAT': ('Numeric value', '数値'),
        'STRING': ('Text value', 'テキスト値'),
        'ENUM': ('Selection menu', '選択メニュー'),
        'BOOLEAN_ARRAY': ('Boolean list', 'オン・オフ配列'),
        'INT_ARRAY': ('Integer list', '整数配列'),
        'FLOAT_ARRAY': ('Numeric list', '数値配列'),
    }
    en, ja = labels.get(ptype, ('Setting value', '設定値'))
    return _pick_lang(en, ja, context)


def _sms_enum_item_help_text(prop, context=None, *, max_items=12) -> str:
    try:
        if str(getattr(prop, 'type', '') or '').upper() != 'ENUM':
            return ''
    except Exception:
        return ''
    names = []
    try:
        enum_items = getattr(prop, 'enum_items', None) or ()
    except Exception:
        enum_items = ()
    for item in tuple(enum_items):
        try:
            if getattr(item, 'identifier', '') == '':
                continue
            name = _sms_clean_help_text(getattr(item, 'name', '') or getattr(item, 'identifier', ''), context)
            desc = _sms_clean_help_text(getattr(item, 'description', ''), context)
            if name and desc and desc != name:
                names.append(f'{name}: {desc}')
            elif name:
                names.append(name)
        except Exception:
            continue
        if len(names) >= max_items:
            break
    if not names:
        return ''
    suffix = ''
    try:
        total = len(tuple(getattr(prop, 'enum_items', None) or ()))
        if total > len(names):
            suffix = _pick_lang(f' and {total - len(names)} more', f' ほか {total - len(names)} 件', context)
    except Exception:
        pass
    return _pick_lang('Options: ', '選択肢: ', context) + '; '.join(names) + suffix


def _sms_rna_setting_help_items(data, *, include_names=None, exclude=None, context=None) -> list[dict]:
    items = []
    if data is None:
        return items
    include_names = tuple(str(name or '').strip() for name in tuple(include_names or ()) if str(name or '').strip())
    include_set = set(include_names)
    exclude = set(str(name or '').strip() for name in tuple(exclude or ()) if str(name or '').strip())
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        if props is None:
            return items
        prop_map = {}
        for prop in props:
            pid = str(getattr(prop, 'identifier', '') or '').strip()
            if pid:
                prop_map[pid] = prop
        iterable = [prop_map[name] for name in include_names if name in prop_map] if include_names else list(prop_map.values())
        seen = set()
        for prop in iterable:
            pid = str(getattr(prop, 'identifier', '') or '').strip()
            if not pid or pid == 'rna_type' or pid in seen or pid in exclude:
                continue
            seen.add(pid)
            if include_set and pid not in include_set:
                continue
            try:
                if getattr(prop, 'is_hidden', False) or getattr(prop, 'is_readonly', False):
                    continue
            except Exception:
                pass
            try:
                ptype = str(getattr(prop, 'type', '') or '').upper()
            except Exception:
                ptype = ''
            if ptype in {'COLLECTION', 'POINTER'}:
                continue
            label = _sms_clean_help_text(getattr(prop, 'name', '') or pid.replace('_', ' ').title(), context)
            generic_detail = _pick_lang(f'Controls the {label} setting.', f'{label} を設定します。', context)
            desc = _sms_clean_help_text(getattr(prop, 'description', ''), context, fallback=generic_detail)
            type_text = _sms_short_type_label(prop, context)
            enum_text = _sms_enum_item_help_text(prop, context)
            detail = desc or generic_detail
            extra = []
            if type_text:
                extra.append(_pick_lang('Type: ', '種類: ', context) + type_text)
            if enum_text:
                extra.append(enum_text)
            if extra:
                detail = detail + ' ' + ' '.join(extra)
            items.append({'label': label, 'detail': detail, 'icon': 'DOT', 'kind': 'property', 'identifier': pid})
    except Exception:
        return items
    return items


def _sms_panel_help_items_from_record(record, context=None) -> list[dict]:
    items = []
    try:
        panels = _sms_integrated_panel_classes(record or {})
    except Exception:
        panels = []
    for panel_cls in tuple(panels or ()):  # pragma: no branch
        try:
            if _sms_is_help_panel_class(panel_cls):
                continue
        except Exception:
            pass
        try:
            name = _sms_clean_help_text(getattr(panel_cls, 'bl_label', '') or getattr(panel_cls, '__name__', '') or 'Panel UI', context)
            fallback_desc = _pick_lang(
                'Original panel controls shown in this tool settings section. Use the visible controls according to the current mode and selection.',
                'このツールの設定欄に表示される元パネルUIです。現在のモードと選択状態に合わせて、表示された操作項目を使用します。',
                context,
            )
            desc = _sms_clean_help_text(getattr(panel_cls, 'bl_description', ''), context, fallback=fallback_desc)
        except Exception:
            continue
        if not desc:
            desc = fallback_desc
        items.append({'label': name, 'detail': desc, 'icon': 'PREFERENCES', 'kind': 'panel'})
    return items


def _sms_menu_help_items_from_entries(entries, context=None) -> list[dict]:
    items = []
    for menu_id, label, is_pie in tuple(entries or ()):  # pragma: no branch
        menu_type = _pick_lang('Pie menu', 'パイメニュー', context) if is_pie else _pick_lang('Menu', 'メニュー', context)
        lower_type = str(menu_type).lower()
        items.append({
            'label': _sms_clean_help_text(label or menu_id, context),
            'detail': _pick_lang(
                f'Opens the {lower_type} registered as {menu_id}.',
                f'{menu_id} として登録されている{menu_type}を開きます。',
                context,
            ),
            'icon': 'MENU_PANEL',
            'kind': 'menu',
        })
    return items


def _sms_operator_class_from_idname(op_id: str):
    op_id = str(op_id or '').strip()
    if not op_id or bpy is None:
        return None
    identifiers = [op_id]
    if '.' in op_id:
        prefix, suffix = op_id.split('.', 1)
        if prefix and suffix:
            identifiers.append(f'{prefix.upper()}_OT_{suffix}')
    try:
        getter = getattr(getattr(bpy.types, 'Operator', None), 'bl_rna_get_subclass_py', None)
    except Exception:
        getter = None
    if callable(getter):
        for identifier in identifiers:
            try:
                cls = getter(identifier, None)
            except Exception:
                cls = None
            if cls is not None:
                return cls
    try:
        for cls in tuple(getattr(bpy.types, 'Operator').__subclasses__()):
            try:
                if str(getattr(cls, 'bl_idname', '') or '').strip() == op_id:
                    return cls
            except Exception:
                continue
    except Exception:
        pass
    return None


def _sms_operator_setting_detail(op_id: str, context=None) -> str:
    cls = _sms_operator_class_from_idname(op_id)
    if cls is None:
        return ''
    try:
        items = _sms_rna_setting_help_items(cls, exclude={'rna_type'}, context=context)
    except Exception:
        items = []
    if not items:
        return ''
    parts = []
    for item in tuple(items):
        label = _sms_clean_help_text((item or {}).get('label') or '', context)
        detail = _sms_clean_help_text((item or {}).get('detail') or '', context)
        if label and detail:
            parts.append(f'{label}: {detail}')
        elif label:
            parts.append(label)
    if not parts:
        return ''
    return _pick_lang('Operator settings: ', 'オペレーター設定: ', context) + ' / '.join(parts)


def _sms_operator_help_items_from_entries(entries, context=None) -> list[dict]:
    items = []
    for op_id, label, desc in tuple(entries or ()):  # pragma: no branch
        op_cls = _sms_operator_class_from_idname(op_id)
        if op_cls is not None:
            try:
                class_label = _sms_clean_help_text(getattr(op_cls, 'bl_label', '') or '', context)
                if class_label:
                    label = class_label
            except Exception:
                pass
            try:
                class_desc = _sms_clean_help_text(getattr(op_cls, 'bl_description', '') or '', context)
                if class_desc:
                    desc = class_desc
            except Exception:
                pass
        label = _sms_clean_help_text(label or op_id, context)
        generic_desc = _pick_lang(f'Runs the operator {op_id}.', f'{op_id} オペレーターを実行します。', context)
        desc = _sms_clean_help_text(desc, context, fallback=generic_desc)
        if not desc:
            desc = generic_desc
        setting_detail = _sms_operator_setting_detail(op_id, context)
        if setting_detail:
            desc = f'{desc} {setting_detail}'
        desc = f'{desc} ' + _pick_lang(f'Registration ID: {op_id}.', f'登録ID: {op_id}。', context)
        items.append({'label': label, 'detail': desc, 'icon': 'TOOL_SETTINGS', 'kind': 'operator'})
    return items


def _sms_keymap_help_items_from_entries(entries, context=None) -> list[dict]:
    items = []
    seen = set()
    for entry in tuple(entries or ()):  # pragma: no branch
        if not isinstance(entry, dict):
            continue
        op_id = str(entry.get('idname') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = _sms_keymap_entry_label(entry, context) or op_id
        purpose = _sms_keymap_purpose_text(entry, context)
        location = _sms_keymap_pref_path(str(entry.get('keymap') or entry.get('km_name') or ''), str(entry.get('space_type') or ''), context)
        detail_parts = []
        if purpose:
            detail_parts.append(purpose)
        if location:
            detail_parts.append(_pick_lang('Registration location: ', '登録場所: ', context) + location)
        detail_parts.append(_pick_lang('Registration ID copied by the Copy button: ', 'コピーボタンでコピーする登録ID: ', context) + op_id)
        items.append({'label': label, 'detail': ' '.join(detail_parts), 'icon': 'KEYINGSET', 'kind': 'keymap'})
    return items


def _sms_append_section(sections: list[dict], title: str, items: list[dict], icon='PREFERENCES') -> None:
    clean_items = []
    seen = set()
    for item in tuple(items or ()):  # pragma: no branch
        label = str((item or {}).get('label') or '').strip()
        detail = str((item or {}).get('detail') or '').strip()
        if not label:
            continue
        key = (label, detail)
        if key in seen:
            continue
        seen.add(key)
        clean_items.append(dict(item))
    if clean_items:
        sections.append({'title': title, 'items': clean_items, 'icon': icon})


def _sms_native_setting_help_sections(alias: str, context=None) -> list[dict]:
    prefs = _sms_get_suite_prefs(context)
    sections = []
    try:
        _sms_restore_known_panel_settings(context)
    except Exception:
        pass

    try:
        keymaps = _sms_native_keymap_entries(alias)
    except Exception:
        keymaps = []
    _sms_append_section(sections, _pick_lang('Keymap Registration', 'キーマップ登録', context), _sms_keymap_help_items_from_entries(keymaps, context), icon='KEYINGSET')

    if alias == 'connect':
        try:
            data = getattr(getattr(context, 'scene', None), 'sms_smart_connect_settings', None)
        except Exception:
            data = None
        _sms_append_section(
            sections,
            _pick_lang('Settings', '設定', context),
            _sms_rna_setting_help_items(data, include_names=('show_popup', 'segments', 'pinch', 'slide'), context=context),
            icon='PREFERENCES',
        )

    try:
        groups = _sms_native_unified_settings_groups(context, prefs, alias)
    except Exception:
        groups = []
    for group in tuple(groups or ()):  # pragma: no branch
        title = str(group[0] if len(group) >= 1 else _pick_lang('3. Settings', '3. 設定項目', context))
        data = group[1] if len(group) >= 2 else None
        exclude = tuple(group[2]) if len(group) >= 3 else tuple()
        include_names = tuple(group[3]) if len(group) >= 4 else tuple()
        _sms_append_section(sections, title, _sms_rna_setting_help_items(data, include_names=include_names, exclude=exclude, context=context), icon='PREFERENCES')

    try:
        record = _sms_native_tool_record(alias) or {}
    except Exception:
        record = {}
    _sms_append_section(sections, _pick_lang('Panel UI', 'パネルUI', context), _sms_panel_help_items_from_record(record, context), icon='PREFERENCES')
    try:
        menus = _sms_native_menu_entries(record, context)
    except Exception:
        menus = []
    _sms_append_section(sections, _pick_lang('Menus', 'メニュー', context), _sms_menu_help_items_from_entries(menus, context), icon='MENU_PANEL')
    try:
        ops = _sms_native_operator_entries(record, context)
    except Exception:
        ops = []
    _sms_append_section(sections, _pick_lang('Operators', 'オペレーター', context), _sms_operator_help_items_from_entries(ops, context), icon='TOOL_SETTINGS')
    return sections


def _sms_integrated_setting_help_sections(alias: str, context=None) -> list[dict]:
    sections = []
    try:
        from . import loader as _sms_loader
        record = _sms_loader.get_record(alias) or {}
    except Exception:
        record = {}

    try:
        static_keymaps = _sms_integrated_static_keymap_entries(alias, context)
        captured_keymaps = _sms_captured_integrated_keymap_entries(alias)
    except Exception:
        static_keymaps, captured_keymaps = [], []
    _sms_append_section(sections, _pick_lang('Keymap Registration', 'キーマップ登録', context), _sms_keymap_help_items_from_entries(list(captured_keymaps or []) + list(static_keymaps or []), context), icon='KEYINGSET')

    try:
        prefs_objects = _sms_preferences_objects(context, record or {})
    except Exception:
        prefs_objects = []
    for title, pref_obj in tuple(prefs_objects or ()):  # pragma: no branch
        _sms_append_section(sections, _sms_clean_help_text(title, context) or _pick_lang('N-panel Settings', 'Nパネル設定', context), _sms_rna_setting_help_items(pref_obj, context=context), icon='PREFERENCES')

    _sms_append_section(sections, _pick_lang('Panel UI', 'パネルUI', context), _sms_panel_help_items_from_record(record, context), icon='PREFERENCES')
    try:
        menus = _sms_integrated_menu_entries(record or {}, context)
    except Exception:
        menus = []
    _sms_append_section(sections, _pick_lang('Menus', 'メニュー', context), _sms_menu_help_items_from_entries(menus, context), icon='MENU_PANEL')
    try:
        ops = _sms_integrated_operator_entries(record or {}, context)
    except Exception:
        ops = []
    _sms_append_section(sections, _pick_lang('Operators', 'オペレーター', context), _sms_operator_help_items_from_entries(ops, context), icon='TOOL_SETTINGS')
    return sections


def _sms_suite_panel_setting_help_sections(alias: str, context=None) -> list[dict]:
    sections = []
    item = None
    try:
        for candidate in _SMS_SUITE_PANEL_ITEMS:
            if str((candidate or {}).get('id') or '').strip() == str(alias or '').strip():
                item = dict(candidate)
                break
    except Exception:
        item = None
    if item:
        desc = _pick_lang(str(item.get('description_en') or ''), str(item.get('description_ja') or item.get('description_en') or ''), context)
        if desc:
            _sms_append_section(sections, _pick_lang('Command Section', 'コマンド項目', context), [{
                'label': _sms_suite_panel_item_label(item, context),
                'detail': desc,
                'icon': _sms_safe_icon(item.get('icon'), 'TOOL_SETTINGS'),
                'kind': 'suite_panel',
            }], icon='TOOL_SETTINGS')
        _sms_append_section(sections, _pick_lang('Display Scope', '表示範囲', context), [{
            'label': _pick_lang('This popup shows only this item.', 'このポップアップはこの項目のみを表示します。', context),
            'detail': _pick_lang("Open each linked tool's own Help button when you need the detailed commands or settings for that linked tool.", '連携ツールの詳しいコマンドや設定が必要な場合は、そのツール自身のヘルプボタンを開いてください。', context),
            'icon': 'QUESTION',
            'kind': 'suite_panel',
        }], icon='QUESTION')
    if str(alias or '').strip() == 'all_commands':
        loaded_ops = []
        try:
            for meta in _sms_tool_meta_entries():
                tool_id = str(meta.get('tool_id') or '').strip()
                if not tool_id or not _sms_native_tool_loaded(tool_id):
                    continue
                record = _sms_native_tool_record(tool_id)
                for op in _sms_native_operator_entries(record, context):
                    loaded_ops.append(op)
        except Exception:
            loaded_ops = []
        _sms_append_section(sections, _pick_lang('Discovered Operators', '検出済みオペレーター', context), _sms_operator_help_items_from_entries(loaded_ops, context), icon='TOOL_SETTINGS')
    return sections



def _sms_runtime_group_setting_help_sections(alias: str, context=None) -> list[dict]:
    sections = []
    alias = str(alias or '').strip()
    if alias != 'always_on_toggles':
        return sections
    try:
        prefs = _sms_get_suite_prefs(context)
    except Exception:
        prefs = None
    rows = []
    try:
        if prefs is not None and _sms_rna_prop_exists(prefs, 'ui_show_always_on_toggles'):
            expanded = bool(_sms_safe_get_rna_attr(prefs, 'ui_show_always_on_toggles', True))
            rows.append({
                'label': _pick_lang('Group expanded display', 'グループ展開表示', context),
                'detail': _pick_lang(
                    'Controls whether the Always-on Toggles group itself is expanded in the N-panel. This is only a display setting and does not activate any persistent runtime.',
                    'Nパネル上で常時機能切り替えグループ自体を展開表示するかを制御します。表示だけの設定であり、常時ランタイム自体は有効化しません。',
                    context,
                ) + ' ' + _pick_lang('Current state: ', '現在の状態: ', context) + (_pick_lang('Enabled', '有効', context) if expanded else _pick_lang('Disabled', '無効', context)),
                'icon': 'TRIA_DOWN' if expanded else 'TRIA_RIGHT',
                'kind': 'always_on_toggle',
            })
    except Exception:
        pass
    try:
        flat_items = _sms_flatten_unified_items(_sms_group_unified_items(_sms_build_unified_items(context, prefs)))
        items = _sms_always_on_control_items(flat_items)
    except Exception:
        items = []
    for item in tuple(items or ()):  # pragma: no branch
        label = _sms_suite_panel_item_label(item, context) if str((item or {}).get('kind') or '') == 'suite_panel' else _ui_text(str((item or {}).get('label') or '').strip(), context)
        if not label:
            continue
        enable_prop = str((item or {}).get('enable_prop') or '').strip()
        try:
            current = bool(_sms_safe_get_rna_attr(prefs, enable_prop, False)) if prefs is not None and enable_prop else False
        except Exception:
            current = False
        try:
            detail = _sms_always_on_description_for_item(item, context)
        except Exception:
            detail = _pick_lang('Controls whether this persistent runtime feature is allowed to stay active.', 'この常時ランタイム機能を継続動作可能にするかを制御します。', context)
        detail = _sms_clean_help_text(detail, context)
        state = _pick_lang('Current state: ', '現在の状態: ', context) + (_pick_lang('Enabled', '有効', context) if current else _pick_lang('Disabled', '無効', context))
        detail = f'{detail} {state}'
        rows.append({'label': label, 'detail': detail, 'icon': 'CHECKBOX_HLT' if current else 'CHECKBOX_DEHLT', 'kind': 'always_on_toggle'})
    _sms_append_section(sections, _pick_lang('Always-on Toggles', '常時機能切り替え', context), rows, icon='TIME')
    return sections

def _sms_suite_modeling_operator_section(alias: str, context=None) -> list[dict]:
    sections = []
    entries = list(_SMS_MODELING_SECTION_OPERATOR_GROUPS.get(str(alias or '').strip()) or ())
    if not entries:
        return sections
    _sms_append_section(sections, _pick_lang('Commands and Operator Settings', 'コマンドとオペレーター設定', context), _sms_operator_help_items_from_entries(entries, context), icon='TOOL_SETTINGS')
    return sections


def _sms_workflow_category_setting_help_sections(alias: str, context=None) -> list[dict]:
    alias = str(alias or '').strip()
    sections = []
    label, icon, _info = _sms_workflow_category_record(alias, context)
    _sms_append_section(sections, _pick_lang('Category Scope', 'カテゴリ範囲', context), [{
        'label': label or _pick_lang('Category', 'カテゴリ', context),
        'detail': _pick_lang(
            'This Help popup explains only this category header. Open the Help button on each tool row when you need the detailed commands and settings for that individual item.',
            'このヘルプポップアップではカテゴリ見出し自身のみを説明します。各項目の詳しいコマンドや設定が必要な場合は、そのツール行のヘルプボタンを開いてください。',
            context,
        ),
        'icon': _sms_safe_icon(icon, 'OUTLINER_COLLECTION'),
        'kind': 'workflow_category',
    }], icon='OUTLINER_COLLECTION')
    return sections

def _sms_tool_setting_help_sections(kind: str, alias: str, context=None) -> list[dict]:
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    if kind == 'native':
        return _sms_native_setting_help_sections(alias, context)
    if kind == 'integrated':
        return _sms_integrated_setting_help_sections(alias, context)
    if kind == 'suite_panel':
        return _sms_suite_panel_setting_help_sections(alias, context)
    if kind == 'runtime_group':
        return _sms_runtime_group_setting_help_sections(alias, context)
    if kind == 'workflow_category':
        return _sms_workflow_category_setting_help_sections(alias, context)
    return []


def _sms_draw_help_setting_item(col, context, item: dict) -> None:
    label = str((item or {}).get('label') or '').strip()
    detail = str((item or {}).get('detail') or '').strip()
    icon = _sms_safe_icon((item or {}).get('icon'), 'DOT')
    if not label:
        return
    _sms_wrapped_label(col, label, icon=icon, context=context, inner_level=1)
    if detail:
        sub = col.column(align=True)
        _sms_wrapped_label(sub, detail, icon='BLANK1', context=context, inner_level=2)


def _sms_draw_help_settings_sections(layout, context, sections) -> None:
    box = layout.box()
    box.label(text=_pick_lang('3. Settings', '3. 設定項目', context), icon='PREFERENCES')
    if not sections:
        _sms_wrapped_label(box, _pick_lang('No additional setting items are exposed in this tool settings section.', 'このツールの設定欄に追加設定項目はありません。', context), context=context, inner_level=1)
        return
    for section in tuple(sections or ()):  # pragma: no branch
        title = str((section or {}).get('title') or _pick_lang('3. Settings', '3. 設定項目', context)).strip()
        items = tuple((section or {}).get('items') or ())
        if not items:
            continue
        sub = box.box()
        _sms_wrapped_label(sub, title, icon=_sms_safe_icon((section or {}).get('icon'), 'PREFERENCES'), context=context, inner_level=2)
        col = sub.column(align=True)
        for item in items:
            _sms_draw_help_setting_item(col, context, item)


def _sms_draw_tool_help_popup(layout, context, kind: str, alias: str, label: str = '', *, popup_width=None):
    if popup_width is not None:
        try:
            globals()['_SMS_HELP_POPUP_WIDTH'] = int(popup_width)
        except Exception:
            pass
    content = _sms_tool_help_content(kind, alias, context)
    title = str(label or content.get('label') or alias or _pick_lang('Tool', 'ツール', context)).strip()
    icon = _sms_safe_icon(content.get('icon'), 'HELP')
    layout.use_property_split = False
    layout.use_property_decorate = False
    _sms_wrapped_label(layout, title, icon=icon, context=context)
    layout.separator()

    overview_box = layout.box()
    overview_box.label(text=_pick_lang('1. Feature Overview', '1. 機能概要', context))
    col = overview_box.column(align=True)
    for line in tuple(content.get('overview') or ()):
        _sms_wrapped_label(col, line, icon='DOT', context=context, inner_level=1)

    usage_box = layout.box()
    usage_box.label(text=_pick_lang('2. Usage', '2. 使用方法', context), icon='QUESTION')
    col = usage_box.column(align=True)
    for line in tuple(content.get('usage') or ()):
        _sms_wrapped_label(col, line, icon='DOT', context=context, inner_level=1)

    _sms_draw_help_settings_sections(layout, context, tuple(content.get('settings') or ()))

# ------------------------------------------------------------------------------
# Lazy popup operator
# ------------------------------------------------------------------------------
_OperatorBase = getattr(getattr(bpy, 'types', None), 'Operator', object) if bpy is not None else object
_REGISTERED = False


class SMS_OT_tool_help_popup(_OperatorBase):
    """Detailed Smart Modeling help popup registered only after Help is clicked."""
    _sms_no_undo = True
    bl_idname = "smart_modeling_suite.tool_help_popup"
    bl_label = "Smart Modeling Help"
    bl_description = "Display detailed Smart Modeling tool help."
    bl_options = set()

    kind: StringProperty(options={'SKIP_SAVE'}, default="")
    alias: StringProperty(options={'SKIP_SAVE'}, default="")
    label: StringProperty(options={'SKIP_SAVE'}, default="")
    popup_width: IntProperty(options={'SKIP_SAVE'}, default=_SMS_HELP_POPUP_WIDTH_FALLBACK)

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'alias', '') or '').strip()
        if label:
            return _pick_lang(
                f'Display detailed help for {label}.',
                f'{label} の詳細ヘルプを表示します。',
                context,
            )
        return _pick_lang(
            'Display detailed Smart Modeling tool help.',
            'Smart Modeling ツールの詳細ヘルプを表示します。',
            context,
        )

    def invoke(self, context, event):
        del event
        try:
            _bind_runtime()
            _sms_prepare_tool_help_settings_context(str(self.kind or ''), str(self.alias or ''), context)
        except Exception:
            pass
        width = int(getattr(self, 'popup_width', 0) or _SMS_HELP_POPUP_WIDTH_FALLBACK)
        try:
            return context.window_manager.invoke_props_dialog(self, width=width)
        except Exception:
            try:
                return context.window_manager.invoke_popup(self, width=width)
            except Exception:
                return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        try:
            _bind_runtime()
            _sms_draw_tool_help_popup(
                layout,
                context,
                str(self.kind or '').strip(),
                str(self.alias or '').strip(),
                str(self.label or '').strip(),
                popup_width=int(getattr(self, 'popup_width', 0) or _SMS_HELP_POPUP_WIDTH_FALLBACK),
            )
        except Exception as exc:
            try:
                box = layout.box()
                box.alert = True
                box.label(text=_pick_lang(f'Failed to draw help: {exc}', f'ヘルプ描画に失敗しました: {exc}', context), icon='ERROR')
            except Exception:
                pass


def register() -> None:
    global _REGISTERED
    if _REGISTERED or bpy is None:
        return
    try:
        bpy.utils.register_class(SMS_OT_tool_help_popup)
    except ValueError:
        pass
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    if not _REGISTERED or bpy is None:
        return
    try:
        bpy.utils.unregister_class(SMS_OT_tool_help_popup)
    except Exception:
        pass
    _REGISTERED = False


def show_tool_help(context, kind: str, alias: str, label: str = '', *, runtime=None, popup_width=None) -> bool:
    _bind_runtime(runtime)
    if bpy is None:
        return False
    kind = str(kind or '').strip()
    alias = str(alias or '').strip()
    label = str(label or '').strip()
    if not kind or not alias:
        return False
    try:
        _sms_prepare_tool_help_settings_context(kind, alias, context)
    except Exception:
        pass
    width = int(popup_width or _SMS_HELP_POPUP_WIDTH_FALLBACK)
    register()
    try:
        bpy.ops.smart_modeling_suite.tool_help_popup(
            'INVOKE_DEFAULT',
            kind=kind,
            alias=alias,
            label=label,
            popup_width=width,
        )
        return True
    except Exception:
        def _draw(menu, popup_context):
            layout = menu.layout
            try:
                _sms_draw_tool_help_popup(layout, popup_context, kind, alias, label, popup_width=width)
            except Exception as exc:
                try:
                    box = layout.box()
                    box.alert = True
                    box.label(text=_pick_lang(f'Failed to draw help: {exc}', f'ヘルプ描画に失敗しました: {exc}', popup_context), icon='ERROR')
                except Exception:
                    pass
        try:
            content = _sms_tool_help_content(kind, alias, context)
            title = str(label or content.get('label') or alias or _pick_lang('Tool Help', 'ツールヘルプ', context))
            icon = _sms_safe_icon(content.get('icon'), 'HELP')
            context.window_manager.popup_menu(_draw, title=title, icon=icon)
            return True
        except Exception:
            return False
