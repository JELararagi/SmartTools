# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable, Sequence

import os
import sys
import types
import uuid

import bpy


# ---------------------------------------------------------------------------
# Smart Modeling exact RNA class ownership (1.3.53)
# ---------------------------------------------------------------------------
# A shared prefix, class name, bl_idname, category, or module-name string is
# never ownership evidence.  The persistent ledger stores the exact Python
# class object, generation token, and the native remover captured when that
# exact object was registered by this package.
_SMS_CLASS_LEDGER_KEY = 'SMART_MODELING_SUITE_EXACT_CLASS_LEDGER_V1352'
_SMS_CLASS_LEDGER_SCHEMA = 'jelararagi.smart_modeling.exact-class-ledger.v1'
_SMS_CLASS_OWNER_UUID = 'cd612cf1-0f89-4dd6-a4af-d2ea747ed5a2'
_SMS_CLASS_MARKER_ATTR = '_sms_exact_class_owner_marker_v1352'
_SMS_CLASS_GENERATION = uuid.uuid4().hex
_SMS_CLASS_GENERATION_TOKEN = object()

# ---------------------------------------------------------------------------
# Process-lifetime anchor (1.3.88)
# ---------------------------------------------------------------------------
# Measured on Blender 5.1.2 (ec6e62d40fa9): ``bpy.app.driver_namespace`` is
# REPLACED with a fresh dict on every file load (``wm.open_mainfile`` leaves
# ``id(bpy.app.driver_namespace)`` changed).  The exact-class ledger lived only
# there, so the first ``.blend`` the user opened dropped it and the next
# ``unregister()`` removed 0 classes: 11 PropertyGroups (including
# ``DIRECTDELETE_AddonPreferences`` and every ``*Proxy`` preference group)
# stayed registered, accumulating one stranded set per disable/enable cycle.
#
# A synthetic ``sys.modules`` entry survives both a file load and this
# package's own live-update submodule purge -- every purge site in this suite
# is scoped to the ``smart_modeling_suite`` / ``<package>.`` prefix, and this
# name carries neither -- so the authoritative ledger object stays reachable
# and can be re-published into the fresh namespace deterministically.
# The anchor is scoped to this package only; it is never a shared registry.
_SMS_ANCHOR_MODULE_NAME = 'jelararagi_smart_modeling_bootstrap_anchor_v1'
_SMS_ANCHOR_STORE_ATTR = 'SMS_PROCESS_STATE'


def _anchor_store() -> dict:
    """Return this package's process-lifetime store (never raises)."""
    try:
        module = sys.modules.get(_SMS_ANCHOR_MODULE_NAME)
        if not isinstance(module, types.ModuleType):
            module = types.ModuleType(_SMS_ANCHOR_MODULE_NAME)
            module.__doc__ = (
                'Smart Modeling Suite process-lifetime anchor. Keeps the exact '
                'class-ownership ledger reachable across Blender file loads, '
                'which replace bpy.app.driver_namespace. Not an importable '
                'module and not a shared cross-suite registry.'
            )
            setattr(module, _SMS_ANCHOR_STORE_ATTR, {})
            sys.modules[_SMS_ANCHOR_MODULE_NAME] = module
        store = getattr(module, _SMS_ANCHOR_STORE_ATTR, None)
        if not isinstance(store, dict):
            store = {}
            setattr(module, _SMS_ANCHOR_STORE_ATTR, store)
        return store
    except Exception:
        return {}


def _new_class_ledger_state() -> dict:
    return {
        'schema': _SMS_CLASS_LEDGER_SCHEMA,
        'owner_uuid': _SMS_CLASS_OWNER_UUID,
        'suite_id': 'smart_modeling_suite',
        'generation': '',
        'generation_token': None,
        'entries': {},
    }


def _is_class_ledger_state(candidate: object) -> bool:
    return bool(
        isinstance(candidate, dict)
        and candidate.get('schema') == _SMS_CLASS_LEDGER_SCHEMA
        and candidate.get('owner_uuid') == _SMS_CLASS_OWNER_UUID
        and candidate.get('suite_id') == 'smart_modeling_suite'
        and isinstance(candidate.get('entries'), dict)
    )


_SMS_CLASS_LEDGER_LOCAL = _new_class_ledger_state()
try:
    _SMS_NATIVE_REGISTER_CLASS = bpy.utils.register_class
except Exception:
    _SMS_NATIVE_REGISTER_CLASS = None
try:
    _SMS_NATIVE_UNREGISTER_CLASS = bpy.utils.unregister_class
except Exception:
    _SMS_NATIVE_UNREGISTER_CLASS = None


def _class_ledger_state() -> dict:
    """Return the authoritative ledger, healing a wiped driver namespace.

    First touch after a file load re-publishes the anchored ledger object into
    the freshly replaced ``bpy.app.driver_namespace``, so any caller heals the
    suite -- not only the ``load_post`` handler.  A fresh state is minted only
    when neither the namespace, the anchor, nor the module-local copy holds a
    valid ledger, which is exactly the genuine first-registration case.
    """
    global _SMS_CLASS_LEDGER_LOCAL
    anchor = _anchor_store()
    state = None
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict):
            candidate = namespace.get(_SMS_CLASS_LEDGER_KEY)
            if _is_class_ledger_state(candidate):
                state = candidate
            else:
                anchored = anchor.get(_SMS_CLASS_LEDGER_KEY)
                if _is_class_ledger_state(anchored):
                    # A file load replaced driver_namespace; the ledger and its
                    # exact class objects, generation tokens and native removers
                    # all survive in this process.  Re-publish, never re-mint.
                    state = anchored
                elif _is_class_ledger_state(_SMS_CLASS_LEDGER_LOCAL):
                    state = _SMS_CLASS_LEDGER_LOCAL
                else:
                    state = _new_class_ledger_state()
                namespace[_SMS_CLASS_LEDGER_KEY] = state
    except Exception:
        state = None
    if not isinstance(state, dict):
        state = _SMS_CLASS_LEDGER_LOCAL
        if not isinstance(state, dict):
            state = _new_class_ledger_state()
    if not isinstance(state.get('entries'), dict):
        state['entries'] = {}
    # The module-local copy, the published dict and the anchor are kept as the
    # SAME object, so an entry recorded through any path stays visible to
    # release_current_owned_classes() regardless of which path found it.
    _SMS_CLASS_LEDGER_LOCAL = state
    try:
        anchor[_SMS_CLASS_LEDGER_KEY] = state
    except Exception:
        pass
    return state


def rearm_process_namespace_state() -> bool:
    """Re-publish anchored package state into a replaced driver namespace.

    Called from this suite's existing ``load_post`` handler, which is already
    journaled in ``_SMS_RUNTIME_HANDLER_RECEIPTS`` and removed on unregister.
    Never raises: a persistent handler must not fail foreign handlers or the
    user's file load.
    """
    try:
        _class_ledger_state()
    except Exception:
        return False
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict):
            for key, value in tuple(_anchor_store().items()):
                if key == _SMS_CLASS_LEDGER_KEY:
                    continue
                if key not in namespace:
                    namespace[key] = value
    except Exception:
        return False
    return True


def anchored_namespace_value(key: str, default=None):
    """Read a package key from the namespace, falling back to the anchor."""
    text = str(key or '')
    if not text:
        return default
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict) and text in namespace:
            return namespace[text]
    except Exception:
        pass
    try:
        store = _anchor_store()
        if text in store:
            value = store[text]
            try:
                namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
                if isinstance(namespace, dict):
                    namespace[text] = value
            except Exception:
                pass
            return value
    except Exception:
        pass
    return default


def publish_anchored_namespace_value(key: str, value) -> None:
    """Write a package key to the namespace AND the process anchor."""
    text = str(key or '')
    if not text:
        return
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict):
            namespace[text] = value
    except Exception:
        pass
    try:
        _anchor_store()[text] = value
    except Exception:
        pass


def drop_anchored_namespace_value(key: str, *, expected=None, match_expected: bool = False) -> None:
    """Remove a package key from the namespace AND the process anchor."""
    text = str(key or '')
    if not text:
        return
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(namespace, dict):
            if not match_expected or namespace.get(text) == expected:
                namespace.pop(text, None)
    except Exception:
        pass
    try:
        store = _anchor_store()
        if not match_expected or store.get(text) == expected:
            store.pop(text, None)
    except Exception:
        pass


def class_belongs_to_current_package(cls: type) -> bool:
    """Return True only when the defining module file is under this package root."""
    if not isinstance(cls, type):
        return False
    try:
        package_root = os.path.normcase(os.path.realpath(os.path.dirname(__file__)))
        module_name = str(getattr(cls, '__module__', '') or '')
        module = sys.modules.get(module_name)
        module_file = str(getattr(module, '__file__', '') or '') if module is not None else ''
        if not module_file:
            return False
        module_path = os.path.normcase(os.path.realpath(module_file))
        return module_path == package_root or module_path.startswith(package_root + os.sep)
    except Exception:
        return False


def _entry_matches_exact_class(entry: object, cls: type, *, current_generation_only: bool = False) -> bool:
    if not isinstance(entry, dict) or not isinstance(cls, type):
        return False
    if entry.get('owner_uuid') != _SMS_CLASS_OWNER_UUID:
        return False
    if entry.get('suite_id') != 'smart_modeling_suite':
        return False
    if entry.get('class') is not cls or int(entry.get('class_identity', 0) or 0) != id(cls):
        return False
    if current_generation_only and entry.get('generation') != _SMS_CLASS_GENERATION:
        return False
    token = entry.get('generation_token')
    if token is None:
        return False
    try:
        return getattr(cls, _SMS_CLASS_MARKER_ATTR, None) is token
    except Exception:
        return False


def exact_owned_class_entry(cls: type, *, current_generation_only: bool = False):
    state = _class_ledger_state()
    for entry in tuple(state.get('entries', {}).values()):
        if _entry_matches_exact_class(entry, cls, current_generation_only=current_generation_only):
            return entry
    return None


def is_exact_owned_class(cls: type, *, current_generation_only: bool = False) -> bool:
    return exact_owned_class_entry(cls, current_generation_only=current_generation_only) is not None


def class_is_owned_for_mutation(cls: type) -> bool:
    """Allow mutation only for exact ledger entries or package-defined classes."""
    return bool(is_exact_owned_class(cls) or class_belongs_to_current_package(cls))


def _class_owns_registered_rna(cls) -> bool:
    """True only while this exact class object still owns registered RNA.

    Measured on Blender 5.1.2 (ec6e62d40fa9): ``vars(cls)['bl_rna']`` is present
    only while the exact class is registered and is gone again after
    ``bpy.utils.unregister_class``, identically for Operator, Panel and
    PropertyGroup.  ``getattr(cls, 'bl_rna')`` cannot be used: an unregistered
    PropertyGroup subclass still answers it from its base type.  This is a plain
    ``__dict__`` read rather than an RNA call, so it is also safe on the
    shutdown path guarded by ``_sms_blender_exit_in_progress_51``.
    """
    if not isinstance(cls, type):
        return False
    try:
        return vars(cls).get('bl_rna') is not None
    except Exception:
        return False


def _remove_owned_entry(state: dict, entry_key: object, entry: dict, *, call_remover: bool, stats: dict | None = None) -> bool:
    cls = entry.get('class') if isinstance(entry, dict) else None
    if not _entry_matches_exact_class(entry, cls):
        return False
    unregistered = False
    if call_remover:
        if _class_owns_registered_rna(cls):
            remover = entry.get('native_remover')
            if not callable(remover):
                return False
            try:
                remover(cls)
            except Exception:
                # Keep the row only when the class really is still registered:
                # that is a genuine removal failure a later sweep must retry.
                if _class_owns_registered_rna(cls):
                    return False
            unregistered = True
        # else: this exact class was already unregistered through one of the
        # suite's own module-level teardowns, which call bpy.utils.unregister_class
        # directly and never touch this table.  Before 1.3.88 the row was left
        # behind and the whole ledger was silently collected on the next file
        # load, so nobody noticed.  Now that the ledger is anchored for the life
        # of the process, an un-retired row is a permanent strong reference to a
        # dead class: measured +68 rows per enable/disable cycle, unbounded.
        # The row is stale bookkeeping, not a live resource -- retire it.
    try:
        if getattr(cls, _SMS_CLASS_MARKER_ATTR, None) is entry.get('generation_token'):
            delattr(cls, _SMS_CLASS_MARKER_ATTR)
    except Exception:
        pass
    try:
        state.get('entries', {}).pop(entry_key, None)
    except Exception:
        return False
    if isinstance(stats, dict):
        key = 'unregistered' if unregistered else 'retired'
        stats[key] = int(stats.get(key, 0)) + 1
    return True


def cleanup_stale_owned_classes(*, panels_only: bool = False) -> int:
    """Remove only exact old-generation classes recorded by this suite.

    Returns the number of classes this call actually unregistered.  Rows
    retired as stale bookkeeping are dropped from the table but deliberately
    not counted, so the published contract of this return value is unchanged.
    """
    state = _class_ledger_state()
    stats: dict = {}
    for key, entry in tuple(state.get('entries', {}).items()):
        if not isinstance(entry, dict) or entry.get('generation') == _SMS_CLASS_GENERATION:
            continue
        cls = entry.get('class')
        if panels_only and not _is_panel_class_51(cls):
            continue
        _remove_owned_entry(state, key, entry, call_remover=True, stats=stats)
    return int(stats.get('unregistered', 0))


def begin_class_ownership_generation() -> str:
    """Recover exact stale entries before registering this import generation."""
    state = _class_ledger_state()
    if state.get('generation') == _SMS_CLASS_GENERATION and state.get('generation_token') is _SMS_CLASS_GENERATION_TOKEN:
        return _SMS_CLASS_GENERATION
    cleanup_stale_owned_classes(panels_only=False)
    state['generation'] = _SMS_CLASS_GENERATION
    state['generation_token'] = _SMS_CLASS_GENERATION_TOKEN
    return _SMS_CLASS_GENERATION


def record_owned_class(cls: type, *, native_remover=None) -> bool:
    if not isinstance(cls, type) or not class_belongs_to_current_package(cls):
        return False
    begin_class_ownership_generation()
    state = _class_ledger_state()
    remover = native_remover if callable(native_remover) else _SMS_NATIVE_UNREGISTER_CLASS
    if not callable(remover):
        return False
    entry_key = f'{_SMS_CLASS_GENERATION}:{id(cls)}'
    try:
        setattr(cls, _SMS_CLASS_MARKER_ATTR, _SMS_CLASS_GENERATION_TOKEN)
    except Exception:
        return False
    state['entries'][entry_key] = {
        'owner_uuid': _SMS_CLASS_OWNER_UUID,
        'suite_id': 'smart_modeling_suite',
        'generation': _SMS_CLASS_GENERATION,
        'generation_token': _SMS_CLASS_GENERATION_TOKEN,
        'class': cls,
        'class_identity': id(cls),
        'module': str(getattr(cls, '__module__', '') or ''),
        'native_remover': remover,
        'is_panel': bool(_is_panel_class_51(cls)),
    }
    return True


def unregister_exact_owned_class(cls: type, *, any_generation: bool = False) -> bool:
    state = _class_ledger_state()
    for key, entry in tuple(state.get('entries', {}).items()):
        if not _entry_matches_exact_class(entry, cls, current_generation_only=not any_generation):
            continue
        return _remove_owned_entry(state, key, entry, call_remover=True)
    return False


def release_current_owned_classes() -> int:
    """Unregister this generation's exact classes and empty its ledger rows.

    Returns the number of classes actually unregistered here; rows whose class
    a module-level teardown already unregistered are retired without inflating
    the count.
    """
    state = _class_ledger_state()
    stats: dict = {}
    for key, entry in reversed(tuple(state.get('entries', {}).items())):
        cls = entry.get('class') if isinstance(entry, dict) else None
        if not _entry_matches_exact_class(entry, cls, current_generation_only=True):
            continue
        _remove_owned_entry(state, key, entry, call_remover=True, stats=stats)
    if state.get('generation') == _SMS_CLASS_GENERATION:
        state['generation'] = ''
        state['generation_token'] = None
    return int(stats.get('unregistered', 0))


def disable_owned_panel_class(cls: type) -> bool:
    """Hide a Panel only when current-package or exact-ledger ownership is proven."""
    if not _is_panel_class_51(cls) or not class_is_owned_for_mutation(cls):
        return False
    try:
        cls.poll = classmethod(lambda _cls, _context: False)
    except Exception:
        return False
    def _sms_empty_owned_panel_draw(self, context):
        return None
    try:
        cls.draw = _sms_empty_owned_panel_draw
        cls.draw_header = _sms_empty_owned_panel_draw
        setattr(cls, '_sms_hidden_by_suite', True)
    except Exception:
        pass
    return True


def iter_exact_owned_classes(*, current_generation_only: bool = True):
    state = _class_ledger_state()
    result = []
    for entry in tuple(state.get('entries', {}).values()):
        cls = entry.get('class') if isinstance(entry, dict) else None
        if _entry_matches_exact_class(entry, cls, current_generation_only=current_generation_only):
            result.append(cls)
    return tuple(result)


def exact_class_ownership_snapshot() -> dict:
    state = _class_ledger_state()
    entries = []
    for entry in tuple(state.get('entries', {}).values()):
        cls = entry.get('class') if isinstance(entry, dict) else None
        if not _entry_matches_exact_class(entry, cls):
            continue
        entries.append({
            'generation': str(entry.get('generation') or ''),
            'class_identity': int(entry.get('class_identity', 0) or 0),
            'module': str(entry.get('module') or ''),
            'class_name': str(getattr(cls, '__name__', '') or ''),
            'is_panel': bool(entry.get('is_panel')),
        })
    return {
        'schema': _SMS_CLASS_LEDGER_SCHEMA,
        'owner_uuid': _SMS_CLASS_OWNER_UUID,
        'generation': _SMS_CLASS_GENERATION,
        'entries': tuple(entries),
    }


# The former Window-menu SmartTools bootstrap is intentionally disabled because
# SmartTools is now hosted entirely in each suite's 3D View N-panel category.

_STALE_EXTERNAL_ADDONS = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'bl_ext.user_default.Smart_Modeling_Suite',
    'Smart_Modeling_Suite',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)


def _schedule_userpref_save() -> None:
    # Startup cleanup must not call save_userpref automatically; doing so can
    # re-enter UI layout while extension RNA is being refreshed.
    return None


def cleanup_stale_external_addons(*, save_preferences: bool = False) -> bool:
    changed = False
    try:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        addons = getattr(prefs, 'addons', None) if prefs is not None else None
    except Exception:
        addons = None
    if addons is not None:
        for module_name in _STALE_EXTERNAL_ADDONS:
            addon_entry = None
            try:
                addon_entry = addons.get(module_name)
            except Exception:
                addon_entry = None
            if addon_entry is None:
                try:
                    addon_entry = addons[module_name]
                except Exception:
                    addon_entry = None
            if addon_entry is not None:
                try:
                    addons.remove(addon_entry)
                    changed = True
                except Exception:
                    try:
                        del addons[module_name]
                        changed = True
                    except Exception:
                        pass
            try:
                sys.modules.pop(module_name, None)
            except Exception:
                pass
    if changed and save_preferences:
        _schedule_userpref_save()
    return changed



def cleanup_empty_user_interface_keymaps() -> bool:
    changed = False
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
        for config_name in ('addon',):
            kc = getattr(keyconfigs, config_name, None) if keyconfigs is not None else None
            keymaps = getattr(kc, 'keymaps', None) if kc is not None else None
            if keymaps is None:
                continue
            try:
                km = keymaps.get('User Interface')
            except Exception:
                km = None
            if km is None:
                continue
            try:
                if len(getattr(km, 'keymap_items', ())) == 0:
                    keymaps.remove(km)
                    changed = True
            except Exception:
                pass
    except Exception:
        pass
    if changed:
        _schedule_userpref_save()
    return changed


def ensure_user_interface_keymap() -> bool:
    # Do not create an empty "User Interface" keymap. Blender 5.x reports a
    # console warning for every empty keymap during event handling, so the safe
    # behavior is to remove only stale empty copies left by older builds.
    return cleanup_empty_user_interface_keymaps()

def strip_register_option_from_operator(cls: type) -> None:
    try:
        op_base = getattr(bpy.types, 'Operator', None)
        if op_base is not None and isinstance(cls, type) and issubclass(cls, op_base):
            opts = set(getattr(cls, 'bl_options', set()) or set())
            if bool(getattr(cls, '_sms_requires_register', False)):
                opts.add('REGISTER')
                cls.bl_options = opts
            elif 'REGISTER' in opts:
                opts.discard('REGISTER')
                cls.bl_options = opts
    except Exception:
        pass



def _is_panel_class_51(cls: type) -> bool:
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        return bool(panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base))
    except Exception:
        return False


def _is_propertygroup_class_51(cls: type) -> bool:
    try:
        group_base = getattr(bpy.types, 'PropertyGroup', None)
        return bool(group_base is not None and isinstance(cls, type) and issubclass(cls, group_base))
    except Exception:
        return False


def registered_propertygroup_subclass(name: str):
    """Truthful PropertyGroup registration lookup for Blender 5.1.

    Measured on 5.1.2 (ec6e62d40fa9): an UNREGISTERED PropertyGroup subclass
    still answers ``getattr(cls, 'bl_rna')`` (the attribute is inherited from
    the base type, identifier ``PropertyGroup``), and REGISTERED PropertyGroups
    are NOT exposed as ``bpy.types`` attributes.  The only reliable evidence of
    registration is ``PropertyGroup.bl_rna_get_subclass_py``.
    """
    try:
        base = getattr(bpy.types, 'PropertyGroup', None)
        getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
        if callable(getter):
            existing = getter(str(name or ''), None)
            if isinstance(existing, type):
                return existing
    except Exception:
        pass
    return None


def propertygroup_is_registered(cls) -> bool:
    """True only when *this exact class object* owns the registered RNA."""
    try:
        return registered_propertygroup_subclass(str(getattr(cls, '__name__', '') or '')) is cls
    except Exception:
        return False


def _patch_panel_in_place_51(existing: type, source: type) -> bool:
    if not (_is_panel_class_51(existing) and isinstance(source, type)):
        return False
    if not class_is_owned_for_mutation(existing) or not class_belongs_to_current_package(source):
        return False
    for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_space_type', 'bl_region_type', 'bl_parent_id', 'bl_options', 'bl_order'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    for attr in ('poll', 'draw', 'draw_header', 'draw_header_preset'):
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    record_owned_class(existing)
    return True


def _hide_panel_class_51(cls: type) -> None:
    disable_owned_panel_class(cls)



def _sms_blender_exit_in_progress_51() -> bool:
    """Return True while Blender is performing its final add-on shutdown.

    Do not access Blender RNA here.  During ``bpy.utils._on_exit`` the C-side
    RNA registry may already be partially released; querying
    ``bl_rna_get_subclass_py`` at that point can crash Blender natively.  A
    pure-Python stack check is sufficient and leaves ordinary add-on disable,
    reinstall, and development reload behavior unchanged.
    """
    try:
        frame = sys._getframe(1)
    except Exception:
        return False
    for _index in range(20):
        if frame is None:
            break
        try:
            function_name = str(frame.f_code.co_name or "")
            module_name = str(frame.f_globals.get("__name__", "") or "")
        except Exception:
            function_name = ""
            module_name = ""
        if function_name == "_on_exit" and module_name == "bpy.utils":
            return True
        if function_name in {"_sws_on_exit_wrapper", "_sws_guarded_disable_all"} and module_name.endswith(".crash_guard"):
            return True
        try:
            frame = frame.f_back
        except Exception:
            break
    return False


def _registered_rna_class_51(cls: type):
    """Return an already registered RNA class with the same C/RNA identity.

    Blender 5.1 Windows can crash if an add-on reinstall unregisters or replaces
    an Operator/Menu/Panel class while the UI or a modal operator still owns the
    previous C-side RNA pointer.  Therefore same-session reinstalls patch the
    existing class object in place and never force a remove/register cycle.
    """
    if not isinstance(cls, type):
        return None
    if _sms_blender_exit_in_progress_51():
        return None
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type):
            try:
                getattr(existing, 'bl_rna')
                return existing
            except Exception:
                pass
    except Exception:
        pass
    # PropertyGroups never appear as bpy.types attributes on Blender 5.1 and
    # usually carry no bl_idname, so without this lookup a registered group is
    # invisible here and reinstall paths try to double-register it.
    if _is_propertygroup_class_51(cls):
        existing = registered_propertygroup_subclass(str(getattr(cls, '__name__', '') or ''))
        if isinstance(existing, type):
            return existing
    bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    if not bl_idname:
        return None
    try:
        class_name = str(getattr(cls, '__name__', '') or '').strip()
        candidates = {bl_idname, class_name}
        if bl_idname and '.' in bl_idname and '_OT_' in class_name:
            namespace = bl_idname.split('.', 1)[0].upper()
            _, suffix = class_name.split('_OT_', 1)
            if namespace and suffix:
                candidates.add(f'{namespace}_OT_{suffix}')
        for candidate in tuple(c for c in candidates if c):
            for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                try:
                    base = getattr(bpy.types, base_name, None)
                    getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                    if callable(getter):
                        existing = getter(candidate, None)
                        if isinstance(existing, type):
                            return existing
                except Exception:
                    pass
    except Exception:
        pass
    for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
        try:
            base = getattr(bpy.types, base_name, None)
            getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
            if callable(getter):
                existing = getter(bl_idname, None)
                if isinstance(existing, type):
                    return existing
        except Exception:
            pass
    try:
        if bl_idname and '.' in bl_idname:
            namespace, opname = bl_idname.split('.', 1)
            op_ns = getattr(bpy.ops, namespace, None)
            op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
            get_rna_type = getattr(op_fn, 'get_rna_type', None)
            if callable(get_rna_type):
                try:
                    rna = get_rna_type()
                except Exception:
                    rna = None
                identifier = str(getattr(rna, 'identifier', '') or '').strip() if rna is not None else ''
                if identifier:
                    class_name = str(getattr(cls, '__name__', '') or '').strip()
                    candidates = {class_name}
                    opname_suffix = ''.join(ch if ch.isalnum() else '_' for ch in opname).strip('_')
                    if namespace and opname_suffix:
                        candidates.add(f'{namespace.upper()}_OT_{opname_suffix}')
                    if '_OT_' in class_name:
                        try:
                            _prefix, suffix = class_name.split('_OT_', 1)
                            if suffix:
                                candidates.add(f'{namespace.upper()}_OT_{suffix}')
                        except Exception:
                            pass
                    if identifier in candidates:
                        # Resolve the actual registered Python class.  Returning
                        # ``cls`` here is unsafe when another class with the same
                        # bl_idname is already registered: Blender then treats the
                        # source class as unregistered and register_class() silently
                        # replaces the live RNA type, which can invalidate open UI or
                        # modal operator pointers.
                        for base_name in ('Operator', 'Menu', 'Panel', 'AddonPreferences', 'PropertyGroup', 'Gizmo', 'GizmoGroup', 'UIList', 'Header'):
                            try:
                                base = getattr(bpy.types, base_name, None)
                                getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
                                existing = getter(identifier, None) if callable(getter) else None
                                if isinstance(existing, type):
                                    return existing
                            except Exception:
                                pass
                        try:
                            existing = getattr(bpy.types, identifier, None)
                            if isinstance(existing, type):
                                getattr(existing, 'bl_rna')
                                return existing
                        except Exception:
                            pass
    except Exception:
        pass
    return None


def _patch_registered_class_in_place_51(existing: type, source: type) -> bool:
    if not (isinstance(existing, type) and isinstance(source, type)):
        return False
    if not class_is_owned_for_mutation(existing) or not class_belongs_to_current_package(source):
        return False
    if _is_panel_class_51(existing):
        return _patch_panel_in_place_51(existing, source)
    attrs = (
        'bl_idname', 'bl_label', 'bl_description', 'bl_category', 'bl_space_type',
        'bl_region_type', 'bl_parent_id', 'bl_options', 'bl_order', 'bl_context',
        'bl_property', 'bl_translation_context',
    )
    for attr in attrs:
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    methods = (
        'poll', 'draw', 'draw_header', 'draw_header_preset', 'execute', 'invoke',
        'modal', 'cancel', 'check', 'description', 'menu_draw', 'draw_item',
    )
    for attr in methods:
        if attr in getattr(source, '__dict__', {}):
            try:
                setattr(existing, attr, getattr(source, attr))
            except Exception:
                pass
    try:
        setattr(existing, '_sms_patched_in_place_51', True)
    except Exception:
        pass
    record_owned_class(existing)
    return True




def safe_register_class(cls: type) -> bool:
    if not isinstance(cls, type) or not class_belongs_to_current_package(cls):
        return False
    begin_class_ownership_generation()
    strip_register_option_from_operator(cls)
    try:
        existing = _registered_rna_class_51(cls)
    except Exception:
        existing = None
    if existing is cls:
        return record_owned_class(cls)
    if isinstance(existing, type):
        if not class_is_owned_for_mutation(existing):
            # Register-side tolerance for cross-version live reinstall
            # (drag&drop onto a running Blender).  A same-name PropertyGroup
            # left registered by a previous install - whose ownership evidence
            # is gone together with the old modules - would otherwise block
            # this package's own group forever, and every
            # PointerProperty(type=...) referencing the fresh class then fails
            # with "missing bl_rna ... may not be registered" during
            # register().  PropertyGroups are plain data groups: unlike
            # Operator/Menu/Panel they are replaced, never patched in place,
            # and replacing them cannot invalidate open UI type pointers.
            # This tolerance is strictly limited to PropertyGroup pairs.
            if (
                _is_propertygroup_class_51(existing)
                and _is_propertygroup_class_51(cls)
                and callable(_SMS_NATIVE_UNREGISTER_CLASS)
                and callable(_SMS_NATIVE_REGISTER_CLASS)
            ):
                try:
                    _SMS_NATIVE_UNREGISTER_CLASS(existing)
                except Exception:
                    return False
                try:
                    _SMS_NATIVE_REGISTER_CLASS(cls)
                except Exception:
                    return False
                return record_owned_class(cls)
            return False
        if _is_panel_class_51(existing):
            return _patch_panel_in_place_51(existing, cls)
        return _patch_registered_class_in_place_51(existing, cls)
    if not callable(_SMS_NATIVE_REGISTER_CLASS):
        return False
    try:
        _SMS_NATIVE_REGISTER_CLASS(cls)
    except (RuntimeError, ValueError):
        try:
            existing = _registered_rna_class_51(cls)
        except Exception:
            existing = None
        if isinstance(existing, type) and class_is_owned_for_mutation(existing):
            return _patch_registered_class_in_place_51(existing, cls)
        return False
    except Exception:
        return False
    return record_owned_class(cls)


def safe_unregister_class(cls: type) -> None:
    if not isinstance(cls, type) or _sms_blender_exit_in_progress_51():
        return
    unregister_exact_owned_class(cls, any_generation=False)

def safe_register_classes(classes: Iterable[type], *, registered: list[type] | None = None) -> tuple[type, ...]:
    out: list[type] = []
    for cls in classes:
        if safe_register_class(cls):
            out.append(cls)
            if isinstance(registered, list):
                registered.append(cls)
    return tuple(out)


def safe_unregister_classes(classes: Iterable[type]) -> None:
    for cls in reversed(tuple(classes)):
        safe_unregister_class(cls)


def iter_window_menu_classes(menu_names: Sequence[str] | None = None):
    del menu_names
    return iter(())


def iter_window_menu_draw_functions(menu_cls) -> tuple[object, ...]:
    del menu_cls
    return ()


def purge_window_menu_callbacks(menu_cls, matcher, *, keep=None) -> int:
    del menu_cls, matcher, keep
    return 0


def install_window_menu_entry(draw_fn, *, matcher=None, menu_names=None, install_all=False, redraw_area_types=None) -> tuple[str, ...]:
    del draw_fn, matcher, menu_names, install_all, redraw_area_types
    return ()


def remove_window_menu_entry(draw_fn=None, *, matcher=None, menu_names=None, redraw_area_types=None) -> None:
    del draw_fn, matcher, menu_names, redraw_area_types
    return None


def remove_window_menu_entry_if_unused(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_shared_window_menu_button_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_window_menu_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def tag_redraw_window_menu_areas(area_types: Sequence[str] | None = None) -> None:
    del area_types
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass
