# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## extra_curve_objectes
- Origin / 出どころ: extensions.blender.org: extra_curve_objectes — https://projects.blender.org/extensions/add_curve_extra_objects
- Copyright / 著作権者: Community
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - curve_tools/outline.py
  - curve_tools/path_finder.py
  - curve_tools/splines_sequence.py
  - extra_curve_objectes/__init__.py
  - extra_curve_objectes/add_curve_aceous_galore.py
  - extra_curve_objectes/add_curve_braid.py
  - extra_curve_objectes/add_curve_celtic_links.py
  - extra_curve_objectes/add_curve_curly.py
  - extra_curve_objectes/add_curve_simple.py
  - extra_curve_objectes/add_curve_spirals.py
  - extra_curve_objectes/add_curve_spirofit_bouncespline.py
  - extra_curve_objectes/add_curve_torus_knots.py
  - extra_curve_objectes/add_surface_plane_cone.py
  - extra_curve_objectes/beveltaper_curve.py
  - extra_curve_objectes/preferences.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/braided_coil.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/flower_mesh_2d.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/n_13x8_wicker_globe.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/n_7x6.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/n_9x9_color.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/slinky_knot.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/snowflake_2d.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/sun_cross_2d.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/tripple_dna.py
  - extra_curve_objectes/presets/operator/curve.torus_knot_plus/wicker_basket.py
  - tissue/material_tools.py

## extra_mesh_objects
- Origin / 出どころ: extensions.blender.org: extra_mesh_objects — https://projects.blender.org/extensions/add_mesh_extra_objects
- Copyright / 著作権者: Community
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - boltfactory/__init__.py
  - curve_tools/fillet.py
  - edit_mesh_tools/random_vertices.py
  - edit_mesh_tools/split_solidify.py

## add_mesh_BoltFactory
- Origin / 出どころ: add mesh boltfactory (public upstream source)
- Copyright / 著作権者: Aaron Keith
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - boltfactory/boltfactory.py
  - boltfactory/create_mesh.py

## model small sources (model_small_sources_20260920)
- Origin / 出どころ: model small sources (public upstream source)
- Copyright / 著作権者: testscreenings, PKHG, TrumanBlending
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - edit_mesh_tools/__init__.py
  - edit_mesh_tools/mesh_edges_floor_plan.py
  - edit_mesh_tools/mesh_filletplus.py
  - edit_mesh_tools/mesh_relax.py
  - edit_mesh_tools/mesh_vertex_chamfer.py
  - f2/__init__.py
  - ivygen/__init__.py
  - key_operators_toolkit/fix_maya_pivot/operators/fast_merge.py
  - looptools/__init__.py

## screencast (src)
- Origin / 出どころ: screencast (public upstream source) — https://github.com/nutti/Screencast-Keys
- Copyright / 著作権者: nutti, Paulo Gomes, Bart Crouch, John E. Herrenyo
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - vertex_slide/__init__.py

## storytools (storytools_3_3_2_evidence)
- Origin / 出どころ: storytools (public upstream source) — https://github.com/Pullusb/storytools
- Copyright / 著作権者: Samuel Bernou <bernou.samuel@gmail.com>
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - direct_delete/preview.py
  - key_operators_toolkit/fix_maya_pivot/operators/maya_pivot.py

## blender__blender-addons
- Origin / 出どころ: blender blender addons (public upstream source) — https://github.com/BenjaminSauder/EdgeFlow
- Copyright / 著作権者: testscreenings, Michael Soluyanov
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - curve_tools/__init__.py
  - curve_tools/remove_doubles.py
  - key_operators_toolkit/fix_maya_pivot/operators/unique_collection_duplicate.py

## Archimesh (Architecture Generator) (archimesh)
- Origin / 出どころ: https://projects.blender.org/blender/blender-addons (archimesh/)
- Copyright / 著作権者: Antonio Vazquez (antonioya); Blender Foundation
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - archimesh/achm_main_panel.py
  - archimesh/achm_tools.py

## Curve Tools (curve_tools)
- Origin / 出どころ: https://projects.blender.org/blender/blender-addons (curve_tools/)
- Copyright / 著作権者: Mackraken; Spivak Vladimir (cwolf3d); Alexander Meissner (Lichtso, cad.py); Yann Bertrand (jimflim); Michael Soluyanov; Blender Foundation
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - curve_tools/cad.py
  - curve_tools/internal.py
  - curve_tools/show_resolution.py
  - curve_tools/util.py

## Key Ops: Toolkit (key_operators_toolkit)
- Origin / 出どころ: https://github.com/Dangry98/Key-Ops-Toolkit
- Copyright / 著作権者: Dan-Gry
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - key_operators_toolkit/fix_maya_pivot/operators/add_modifier.py
  - key_operators_toolkit/fix_maya_pivot/operators/auto_delete.py
  - key_operators_toolkit/fix_maya_pivot/operators/auto_smooth.py
  - key_operators_toolkit/fix_maya_pivot/operators/extrude_edge_along_normals.py
  - key_operators_toolkit/fix_maya_pivot/operators/seam.py
  - key_operators_toolkit/fix_maya_pivot/utils/mesh_utils.py

## Mesh Repair Tools (mesh_repair_tools)
- Origin / 出どころ: https://extensions.blender.org/add-ons/mesh-repair-tools/
- Copyright / 著作権者: SineWave
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - mesh_repair_tools/mrts.py
  - mesh_repair_tools/sinewave.py

## Mio3 Flex (mio3_flex)
- Origin / 出どころ: https://github.com/mio3io/mio3_flex
- Copyright / 著作権者: Mio (mio3io)
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - mio3_flex/utils.py

## PolyQuilt (fork) (polyquilt_fork)
- Origin / 出どころ: https://github.com/Dangry98/PolyQuilt-for-Blender-4.0 (original: https://github.com/sakana3/PolyQuilt)
- Copyright / 著作権者: Sakana3; Dan-Gry
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - polyquilt_fork/poly_quilt_fork/pq_icon.py

## Tissue (tissue)
- Origin / 出どころ: https://github.com/alessandro-zomparelli/tissue
- Copyright / 著作権者: Alessandro Zomparelli (Co-de-iT)
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - tissue/dual_mesh.py
