# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import math
import sys
from typing import Iterable

import bpy
import bmesh
from mathutils import Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    StringProperty,
)

bl_info = {
    "name": "Crease Preset",
    "author": "Smart Modeling",
    "version": (1, 2, 1),
    "blender": (5, 0, 0),
    "location": "View3D > F3 Search > Crease Preset",
    "description": "Preset collection for edge crease settings.",
    "category": "Mesh",
}

_CREASE_PRESET_POPUP_WIDTH = 420
_CREASE_VALUE_EPSILON = 1.0e-6
_CREASE_CLIPBOARD: dict = {}
_SUPPRESS_ACTIVE_VALUE_UPDATE = False
_SUPPRESS_SELECT_VALUE_UPDATE = False
_SELECT_VALUE_MANUAL_OVERRIDE = False


translation_dict = {
    "ja_JP": {
        ("*", "Preset collection for edge crease settings."): "エッジクリース設定用のプリセット集です。",
        ("*", "Crease Preset"): "クリースプリセット",
        ("*", "Open Crease Presets"): "クリースプリセット",
        ("*", "Selected"): "選択",
        ("*", "Linked"): "リンク",
        ("*", "Use Pie Menu"): 'パイメニューを使用',
        ("*", "Delimit by Seam"): "シームで区切る",
        ("*", "Delimit by Sharp"): "シャープで区切る",
        ("*", "Delimit by Material"): "マテリアルで区切る",
        ("*", "Seam"): "シーム",
        ("*", "Sharp"): "シャープ",
        ("*", "Material"): "マテリアル",
        ("*", "Button Count (Selected)"): "ボタン数（選択）",
        ("*", "Values (Selected)"): "値（選択）",
        ("*", "Button Count (Linked)"): "ボタン数（リンク）",
        ("*", "Values (Linked)"): "値（リンク）",
        ("*", "Selected Edge Crease"): "選択中の辺のクリース",
        ("*", "Crease Value to Select"): "選択するクリース値",
        ("*", "Value used by Select Edges by Crease Value. When this field has not been typed manually, it is filled from the selected edge crease value; with multiple selected edges it uses the average. Editing this field does not change the current edge crease values."): '「クリースの値で辺を選択」に使う値です。手で入力していない時は選択中の辺の値が入り、複数なら平均です。この欄を変えても今の辺の値は変わりません。',
        ("*", "Shows the crease value of the selected edge. When multiple edges are selected, it shows their average. Editing this field applies the new value to the selected edges."): '選択中の辺のクリースの値を表します。複数の辺の選択では平均を表します。この欄を変えると新しい値を選択中の辺に適用します。',
        ("*", "Select Edges by Crease Value"): "指定クリース値の辺を全選択",
        ("*", "Crease Match Tolerance"): "クリース一致許容差",
        ("*", "Approximate Paste Tolerance"): "近似ペースト許容差",
        ("*", "No mesh in edit mode"): "編集モードのメッシュがありません",
        ("*", "No editable mesh object found"): "編集可能なメッシュオブジェクトがありません",
        ("*", "No edges found for the requested mode"): "指定モードで対象の辺が見つかりません",
        ("*", "No selected edges found"): "選択中の辺がありません",
        ("*", "No copied crease data"): "コピー済みのクリース情報がありません",
        ("*", "Applied crease {}"): "クリース {} を適用しました",
        ("*", "Apply Crease"): "クリースを適用",
        ("*", "Linked Delimit"): "リンク範囲の区切り",
        ("*", "Open the edge-crease preset menu for the current Edit Mode mesh selection."): "現在の編集モードのメッシュ選択に対してクリースプリセットを開きます。",
        ("*", "Current / Select by Value"): "現在値 / 数値で選択",
        ("*", "Selected edges: {count} / average {value:g}"): "選択中の辺: {count} / 平均 {value:g}",
        ("*", "No edge is selected."): "辺が選択されていません。",
        ("*", "Editing this value applies it to the currently selected edges."): "この値を編集すると、現在選択中の辺へ適用されます。",
        ("*", "When the selection value has not been typed manually, it is filled from the currently selected edge crease value. Multiple selected edges use the average."): "選択用の数値欄を手入力していない場合は、現在選択中の辺のクリース値が自動入力されます。複数選択時は平均値を使います。",
        ("*", "Select Same Value"): "同じ数値の辺を選択",
        ("*", "Copy / Paste Crease"): "クリースをコピー / ペースト",
        ("*", "Copy Selected Edge Creases"): "選択辺のクリースをコピー",
        ("*", "Paste Same Topology"): "同トポロジーへペースト",
        ("*", "Paste Approximate"): "近似ペースト",
        ("*", "Clipboard: {objects} object(s), {edges} edge(s)"): "コピー内容: {objects} オブジェクト / {edges} 辺",
        ("*", "Clipboard: empty"): "コピー内容: 空",
        ("*", "Preset Values"): "プリセット値",
        ("*", "Selected Preset Values"): "選択プリセット値",
        ("*", "Linked Preset Values"): "リンクプリセット値",
        ("*", "Copied {edges} selected edge crease value(s) from {objects} object(s)."): "{objects} オブジェクトから {edges} 件の選択辺クリース値をコピーしました。",
        ("*", "Selected {count} edge(s) with crease {value:g}."): "クリース {value:g} の辺を {count} 本選択しました。",
        ("*", "Pasted {edges} edge crease value(s) to {objects} object(s) by same topology."): "同トポロジーで {objects} オブジェクトへ {edges} 件の辺クリース値をペーストしました。",
        ("*", "Pasted {edges} edge crease value(s) to {objects} object(s) by approximate matching."): "近似一致で {objects} オブジェクトへ {edges} 件の辺クリース値をペーストしました。",
        ("*", "No same-topology target was found."): "同トポロジーのペースト先が見つかりませんでした。",
        ("*", "No approximate target edge was found within the tolerance."): "許容差内の近似ペースト先辺が見つかりませんでした。",
        ("*", "Select every edge whose crease value matches the value in the field."): "入力欄の値と同じクリース値を持つ辺をすべて選択します。",
        ("*", "Select every edge whose crease value matches the specified selection value. This works even when no edge is selected and the value was typed manually."): "指定した選択用クリース値と一致する辺をすべて選択状態にします。辺未選択で手入力した数値からも実行できます。",
        ("*", "Select every edge whose crease value matches the specified selection value. This works after typing a crease value manually, or after selecting one or more edges so the field is auto-filled from their crease value."): 'クリースの値が指定の値に合う辺をすべて選びます。値を手で入力するか、辺を選んで欄に自動で入れてから使います。',
        ("*", "Copy the crease values of the selected edges. Use this before pasting to another mesh object."): "選択中の辺のクリース値をコピーします。別メッシュへペーストする前に実行します。",
        ("*", "Paste copied edge crease values to mesh objects that have the same vertex and edge topology, using edge indices."): "コピーした辺クリース値を、頂点数と辺数が同じ同トポロジーのメッシュへ辺番号基準でペーストします。",
        ("*", "Paste copied edge crease values to approximately matching edges using relative edge position, direction angle, and length."): "コピーした辺クリース値を、辺の相対位置、方向角度、長さを基準に近い辺へペーストします。",
        ("*", "Quick Start"): 'クイックスタート',
        ("*", "Open Crease Preset"): "クリースプリセットを開く",
        ("*", "Apply common crease weights quickly (0.0 to 1.0)."): "よく使うクリース値（0.0〜1.0）をすばやく適用します。",
        ("*", "Quick Apply (Selected)"): "クイック適用（選択）",
    }
}


def _tr(text: str) -> str:
    try:
        return bpy.app.translations.pgettext(str(text))
    except Exception:
        return str(text)


def _ui_float(value: float) -> str:
    try:
        return f"{float(value):g}"
    except Exception:
        return "0"


def _suite_prefs(context=None):
    ctx = context or getattr(bpy, 'context', None)
    package_root = str(__package__ or '').rsplit('.', 1)[0]
    candidates = []
    if package_root:
        candidates.append(package_root + '.core')
    candidates.extend(('smart_modeling_suite.core', 'bl_ext.user_default.smart_modeling_suite.core'))
    for module_name in candidates:
        try:
            module = sys.modules.get(module_name)
        except Exception:
            module = None
        getter = getattr(module, '_sms_get_suite_prefs', None) if module is not None else None
        if callable(getter):
            try:
                suite = getter(ctx)
                if suite is not None:
                    return suite
            except Exception:
                pass
    try:
        from ..utils import get_suite_prefs
        return get_suite_prefs(ctx)
    except Exception:
        return None


def _proxy_prefs(context=None):
    ctx = context or getattr(bpy, 'context', None)
    package = str(__package__ or 'smart_modeling_suite.crease_preset')
    root = package.rsplit('.', 1)[0] if '.' in package else 'smart_modeling_suite'
    candidates = []
    if root:
        candidates.append(root + '.preferences')
    candidates.extend(('smart_modeling_suite.preferences', 'bl_ext.user_default.smart_modeling_suite.preferences'))
    for module_name in candidates:
        try:
            module = sys.modules.get(module_name)
            if module is None:
                module = __import__(module_name, fromlist=['get_preferences'])
        except Exception:
            module = None
        getter = getattr(module, 'get_preferences', None) if module is not None else None
        if callable(getter):
            try:
                prefs = getter(context=ctx, addon_key=package, prefs_cls=CreasePresetPreferences)
                if prefs is not None:
                    return prefs
            except Exception:
                pass
    return None


def _get_prefs(context=None):
    # Prefer the dedicated WindowManager proxy for this tool.  It survives the
    # Blender Extension / user_default lazy-load path even when suite-level nested
    # PointerProperties are intentionally disabled for Blender 5.1 reinstall safety.
    proxy = _proxy_prefs(context)
    if proxy is not None:
        try:
            _ensure_crease_preset_pref_runtime_props(proxy)
        except Exception:
            pass
        return proxy
    suite = _suite_prefs(context)
    prefs = getattr(suite, 'crease_preset', None) if suite else None
    try:
        _ensure_crease_preset_pref_runtime_props(prefs)
    except Exception:
        pass
    return prefs


_DEFAULT_SELECTED_VALUES = (0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
_DEFAULT_LINKED_VALUES = (0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)


def _default_preset_state():
    return {
        'use_pie_menu': False,
        'linked_delimit_seam': False,
        'linked_delimit_sharp': False,
        'linked_delimit_material': False,
        'sel_count': 4,
        'sel_values': _DEFAULT_SELECTED_VALUES,
        'link_count': 4,
        'link_values': _DEFAULT_LINKED_VALUES,
        'active_crease_value': 0.0,
        'select_crease_value': 0.0,
        'match_tolerance': 0.0001,
        'approx_match_tolerance': 0.18,
    }


def _pref_bool(prefs, name, default=False):
    try:
        return bool(getattr(prefs, name))
    except Exception:
        return bool(default)


def _pref_int(prefs, name, default=0):
    try:
        return int(getattr(prefs, name))
    except Exception:
        return int(default)


def _pref_float(prefs, name, default=0.0):
    try:
        return float(getattr(prefs, name))
    except Exception:
        return float(default)


def _pref_values(prefs, name, default_values):
    try:
        values = tuple(float(v) for v in getattr(prefs, name))
        if len(values) >= len(default_values):
            return values[:len(default_values)]
        if values:
            return values + tuple(default_values[len(values):])
    except Exception:
        pass
    return tuple(float(v) for v in default_values)


def _crease_preset_state(context=None):
    prefs = _get_prefs(context)
    defaults = _default_preset_state()
    return {
        'prefs': prefs,
        'use_pie_menu': _pref_bool(prefs, 'use_pie_menu', defaults['use_pie_menu']),
        'linked_delimit_seam': _pref_bool(prefs, 'linked_delimit_seam', defaults['linked_delimit_seam']),
        'linked_delimit_sharp': _pref_bool(prefs, 'linked_delimit_sharp', defaults['linked_delimit_sharp']),
        'linked_delimit_material': _pref_bool(prefs, 'linked_delimit_material', defaults['linked_delimit_material']),
        'sel_count': max(0, min(10, _pref_int(prefs, 'sel_count', defaults['sel_count']))),
        'sel_values': _pref_values(prefs, 'sel_values', defaults['sel_values']),
        'link_count': max(0, min(10, _pref_int(prefs, 'link_count', defaults['link_count']))),
        'link_values': _pref_values(prefs, 'link_values', defaults['link_values']),
        'active_crease_value': min(1.0, max(0.0, _pref_float(prefs, 'active_crease_value', defaults['active_crease_value']))),
        'select_crease_value': min(1.0, max(0.0, _pref_float(prefs, 'select_crease_value', _pref_float(prefs, 'active_crease_value', defaults['select_crease_value'])))),
        'match_tolerance': max(0.0, _pref_float(prefs, 'match_tolerance', defaults['match_tolerance'])),
        'approx_match_tolerance': max(0.001, _pref_float(prefs, 'approx_match_tolerance', defaults['approx_match_tolerance'])),
    }


class CreasePresetItem(bpy.types.PropertyGroup):
    label: StringProperty(default="")
    value: FloatProperty(default=0.0, min=0.0, max=1.0)
    apply_mode: EnumProperty(
        items=[('SELECTED', 'Selected', ''), ('LINKED', 'Linked', '')],
        default='SELECTED',
    )


def _active_crease_value_update(self, context):
    global _SUPPRESS_ACTIVE_VALUE_UPDATE
    if _SUPPRESS_ACTIVE_VALUE_UPDATE:
        return
    try:
        value = float(getattr(self, 'active_crease_value', 0.0))
    except Exception:
        return
    try:
        _set_selected_edge_crease_value(context, value)
    except Exception:
        pass


def _select_crease_value_update(self, context):
    del context
    global _SUPPRESS_SELECT_VALUE_UPDATE, _SELECT_VALUE_MANUAL_OVERRIDE
    if _SUPPRESS_SELECT_VALUE_UPDATE:
        return
    _SELECT_VALUE_MANUAL_OVERRIDE = True


class CreasePresetPreferences(bpy.types.PropertyGroup):
    use_pie_menu: BoolProperty(
        name="Use Pie Menu",
        description="Open the crease presets as a radial pie menu. Disable it when you prefer the vertical popup layout with value tools and copy/paste controls.",
        default=False,
    )
    linked_delimit_seam: BoolProperty(
        name="Delimit by Seam",
        description="When applying a linked crease value, stop the linked search at seam edges so the crease does not spread across UV or modeling boundaries.",
        default=False,
    )
    linked_delimit_sharp: BoolProperty(
        name="Delimit by Sharp",
        description="When applying a linked crease value, stop the linked search at sharp edges so hard-edge boundaries can limit the affected area.",
        default=False,
    )
    linked_delimit_material: BoolProperty(
        name="Delimit by Material",
        description="When applying a linked crease value, stop the linked search when crossing edges between different material regions.",
        default=False,
    )
    sel_count: IntProperty(
        name="Button Count (Selected)",
        description="Number of quick crease buttons shown for selected edges. Increase it when you want more preset values in the popup.",
        default=4,
        min=0,
        max=10,
    )
    sel_values: FloatVectorProperty(
        name="Values (Selected)",
        description="Crease values used by the selected-edge preset buttons. Each value is clamped between 0.0 and 1.0.",
        size=10,
        default=(0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        min=0.0,
        max=1.0,
    )
    link_count: IntProperty(
        name="Button Count (Linked)",
        description="Number of quick crease buttons shown for linked edge areas. Linked mode expands from the current selection through connected edges.",
        default=4,
        min=0,
        max=10,
    )
    link_values: FloatVectorProperty(
        name="Values (Linked)",
        description="Crease values used by the linked-edge preset buttons. Each value is clamped between 0.0 and 1.0.",
        size=10,
        default=(0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        min=0.0,
        max=1.0,
    )
    active_crease_value: FloatProperty(
        name="Selected Edge Crease",
        description="Shows the crease value of the selected edge. When multiple edges are selected, it shows their average. Editing this field applies the new value to the selected edges.",
        default=0.0,
        min=0.0,
        max=1.0,
        precision=4,
        update=_active_crease_value_update,
    )
    select_crease_value: FloatProperty(
        name="Crease Value to Select",
        description="Value used by Select Edges by Crease Value. When this field has not been typed manually, it is filled from the selected edge crease value; with multiple selected edges it uses the average. Editing this field does not change the current edge crease values.",
        default=0.0,
        min=0.0,
        max=1.0,
        precision=4,
        update=_select_crease_value_update,
    )
    match_tolerance: FloatProperty(
        name="Crease Match Tolerance",
        description="Tolerance used by Select Same Value. Use a very small value for exact crease matching, or increase it slightly when values were generated by scripts and may contain tiny floating-point differences.",
        default=0.0001,
        min=0.0,
        max=0.25,
        precision=5,
    )
    approx_match_tolerance: FloatProperty(
        name="Approximate Paste Tolerance",
        description="Tolerance for approximate paste. Larger values allow crease data to transfer to less similar edges; smaller values require closer relative position, direction angle, and length.",
        default=0.18,
        min=0.001,
        max=2.0,
        precision=3,
    )


def _ensure_crease_preset_pref_runtime_props(prefs) -> bool:
    """Patch old in-session preference proxy RNA classes during overwrite installs.

    Previous builds created Crease Preset proxy PropertyGroups without the
    dedicated select-by-value field.  Blender keeps registered RNA classes alive
    during extension overwrite installs, so this function adds the missing field
    to the live class when Blender permits dynamic RNA properties.  Fresh loads
    use the class annotation above and do not need this compatibility path.
    """
    if prefs is None:
        return False
    try:
        getattr(prefs, 'select_crease_value')
        return True
    except Exception:
        pass
    try:
        cls = type(prefs)
    except Exception:
        return False
    try:
        setattr(cls, 'select_crease_value', FloatProperty(
            name="Crease Value to Select",
            description="Value used by Select Edges by Crease Value. When this field has not been typed manually, it is filled from the selected edge crease value; with multiple selected edges it uses the average. Editing this field does not change the current edge crease values.",
            default=0.0,
            min=0.0,
            max=1.0,
            precision=4,
            update=_select_crease_value_update,
        ))
    except Exception:
        return False
    try:
        getattr(prefs, 'select_crease_value')
        return True
    except Exception:
        return False


def _edit_mesh_objects(context) -> list:
    objects = []
    try:
        for obj in tuple(getattr(context, 'objects_in_mode_unique_data', ()) or ()):  # multi-object edit mode
            if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
                objects.append(obj)
    except Exception:
        pass
    if objects:
        return objects
    obj = getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
        return [obj]
    return []


def _selected_mesh_objects(context) -> list:
    objects = []
    try:
        objects.extend([obj for obj in tuple(getattr(context, 'selected_objects', ()) or ()) if getattr(obj, 'type', None) == 'MESH'])
    except Exception:
        pass
    obj = getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH' and obj not in objects:
        objects.insert(0, obj)
    return objects


def _target_mesh_objects(context) -> list:
    edit_objects = _edit_mesh_objects(context)
    if edit_objects:
        return edit_objects
    return _selected_mesh_objects(context)


def _ensure_bmesh_indices(bm):
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()
    except Exception:
        pass


def _ensure_crease_layer(bm, create=True):
    layer = None
    try:
        layer = bm.edges.layers.float.get('crease_edge')
    except Exception:
        layer = None
    if layer is None and create:
        try:
            layer = bm.edges.layers.float.new('crease_edge')
        except Exception:
            layer = None
    return layer


def _get_bmesh_and_layer(context):
    obj = getattr(context, 'active_object', None)
    if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
        return None, None, None
    bm = bmesh.from_edit_mesh(obj.data)
    _ensure_bmesh_indices(bm)
    layer = _ensure_crease_layer(bm, create=True)
    return obj, bm, layer


def _iter_edit_bmeshes(context, *, create_layer=True):
    for obj in _edit_mesh_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            _ensure_bmesh_indices(bm)
            layer = _ensure_crease_layer(bm, create=create_layer)
            if layer is not None or not create_layer:
                yield obj, bm, layer
        except Exception:
            continue


def _selected_edges_from_bmesh(bm) -> list:
    edges = []
    for edge in bm.edges:
        try:
            if bool(edge.select):
                edges.append(edge)
        except Exception:
            pass
    return edges


def _selected_edge_average(context):
    total = 0.0
    count = 0
    for _obj, bm, layer in _iter_edit_bmeshes(context, create_layer=False):
        for edge in _selected_edges_from_bmesh(bm):
            try:
                total += float(edge[layer]) if layer is not None else 0.0
                count += 1
            except Exception:
                pass
    if count <= 0:
        return None, 0
    return total / count, count


def _set_pref_active_value(prefs, value):
    global _SUPPRESS_ACTIVE_VALUE_UPDATE
    if prefs is None:
        return
    try:
        current = float(getattr(prefs, 'active_crease_value'))
        if abs(current - float(value)) <= _CREASE_VALUE_EPSILON:
            return
    except Exception:
        pass
    _SUPPRESS_ACTIVE_VALUE_UPDATE = True
    try:
        setattr(prefs, 'active_crease_value', min(1.0, max(0.0, float(value))))
    except Exception:
        pass
    finally:
        _SUPPRESS_ACTIVE_VALUE_UPDATE = False


def _set_pref_select_value(prefs, value):
    global _SUPPRESS_SELECT_VALUE_UPDATE
    if prefs is None:
        return
    try:
        _ensure_crease_preset_pref_runtime_props(prefs)
    except Exception:
        pass
    try:
        current = float(getattr(prefs, 'select_crease_value'))
        if abs(current - float(value)) <= _CREASE_VALUE_EPSILON:
            return
    except Exception:
        pass
    _SUPPRESS_SELECT_VALUE_UPDATE = True
    try:
        setattr(prefs, 'select_crease_value', min(1.0, max(0.0, float(value))))
    except Exception:
        pass
    finally:
        _SUPPRESS_SELECT_VALUE_UPDATE = False


def _refresh_active_value_from_selection(context, prefs=None):
    prefs = prefs or _get_prefs(context)
    average, count = _selected_edge_average(context)
    if count > 0 and average is not None:
        _set_pref_active_value(prefs, average)
    return average, count


def _refresh_select_value_from_selection(context, prefs=None, *, average=None, count=None):
    prefs = prefs or _get_prefs(context)
    if average is None or count is None:
        average, count = _selected_edge_average(context)
    if count > 0 and average is not None and not _SELECT_VALUE_MANUAL_OVERRIDE:
        _set_pref_select_value(prefs, average)
    return average, count


def _reset_select_value_manual_override():
    global _SELECT_VALUE_MANUAL_OVERRIDE
    _SELECT_VALUE_MANUAL_OVERRIDE = False


def _set_selected_edge_crease_value(context, value) -> int:
    changed = 0
    value = min(1.0, max(0.0, float(value)))
    for obj, bm, layer in _iter_edit_bmeshes(context, create_layer=True):
        local = 0
        for edge in _selected_edges_from_bmesh(bm):
            try:
                edge[layer] = value
                local += 1
            except Exception:
                pass
        if local:
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
            changed += local
    return changed


def _material_boundary(edge):
    try:
        mats = {f.material_index for f in edge.link_faces}
        return len(mats) > 1
    except Exception:
        return False


def _edge_cross_allowed(edge, delimit_seam=False, delimit_sharp=False, delimit_material=False):
    if delimit_seam and getattr(edge, 'seam', False):
        return False
    if delimit_sharp and not bool(getattr(edge, 'smooth', True)):
        return False
    if delimit_material and _material_boundary(edge):
        return False
    return True


def _target_edges(bm, mode='SELECTED', *, delimit_seam=False, delimit_sharp=False, delimit_material=False):
    if mode == 'SELECTED':
        edges = [e for e in bm.edges if e.select]
        if edges:
            return edges
        verts = [v for v in bm.verts if v.select]
        return [e for e in bm.edges if e.select or all(v.select for v in e.verts)] if verts else []

    seed_verts = []
    for v in bm.verts:
        if v.select:
            seed_verts.append(v)
    for e in bm.edges:
        if e.select:
            seed_verts.extend(list(e.verts))
    for f in bm.faces:
        if f.select:
            seed_verts.extend(list(f.verts))
    if not seed_verts:
        return []

    visited = set()
    stack = list({v for v in seed_verts})
    edges = set(e for e in bm.edges if e.select)
    while stack:
        v = stack.pop()
        if v in visited:
            continue
        visited.add(v)
        for e in v.link_edges:
            edges.add(e)
            if _edge_cross_allowed(e, delimit_seam=delimit_seam, delimit_sharp=delimit_sharp, delimit_material=delimit_material):
                ov = e.other_vert(v)
                if ov not in visited:
                    stack.append(ov)
    return list(edges)


def set_edge_crease(context, value, mode='SELECTED', *, delimit_seam=False, delimit_sharp=False, delimit_material=False):
    objects_seen = 0
    changed_edges = 0
    for obj, bm, layer in _iter_edit_bmeshes(context, create_layer=True):
        objects_seen += 1
        edges = _target_edges(
            bm,
            mode=mode,
            delimit_seam=delimit_seam,
            delimit_sharp=delimit_sharp,
            delimit_material=delimit_material,
        )
        if not edges:
            continue
        for edge in edges:
            try:
                edge[layer] = float(value)
                changed_edges += 1
            except Exception:
                pass
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
    if objects_seen <= 0:
        return False, "No mesh in edit mode"
    if changed_edges <= 0:
        return False, "No edges found for the requested mode"
    return True, f"Applied crease {value}"


def _mesh_bounds_from_bmesh(bm):
    coords = [v.co.copy() for v in bm.verts]
    if not coords:
        zero = Vector((0.0, 0.0, 0.0))
        one = Vector((1.0, 1.0, 1.0))
        return zero, one, 1.0
    min_v = Vector((min(v.x for v in coords), min(v.y for v in coords), min(v.z for v in coords)))
    max_v = Vector((max(v.x for v in coords), max(v.y for v in coords), max(v.z for v in coords)))
    size = max_v - min_v
    diag = max(float(size.length), _CREASE_VALUE_EPSILON)
    return min_v, size, diag


def _edge_feature(edge, layer, min_v, size, diag):
    v1, v2 = edge.verts
    co1 = v1.co.copy()
    co2 = v2.co.copy()
    mid = (co1 + co2) * 0.5
    vec = co2 - co1
    length = float(vec.length)
    if length > _CREASE_VALUE_EPSILON:
        direction = vec.normalized()
    else:
        direction = Vector((0.0, 0.0, 0.0))
    norm_mid = Vector((
        (mid.x - min_v.x) / (size.x if abs(size.x) > _CREASE_VALUE_EPSILON else diag),
        (mid.y - min_v.y) / (size.y if abs(size.y) > _CREASE_VALUE_EPSILON else diag),
        (mid.z - min_v.z) / (size.z if abs(size.z) > _CREASE_VALUE_EPSILON else diag),
    ))
    try:
        crease_value = float(edge[layer]) if layer is not None else 0.0
    except Exception:
        crease_value = 0.0
    return {
        'index': int(getattr(edge, 'index', -1)),
        'verts': (int(getattr(v1, 'index', -1)), int(getattr(v2, 'index', -1))),
        'value': min(1.0, max(0.0, crease_value)),
        'mid': (float(norm_mid.x), float(norm_mid.y), float(norm_mid.z)),
        'dir': (float(direction.x), float(direction.y), float(direction.z)),
        'length': float(length / diag) if diag > _CREASE_VALUE_EPSILON else 0.0,
    }


def _score_edge_match(source_edge: dict, target_edge: dict) -> float:
    sm = Vector(source_edge.get('mid', (0.0, 0.0, 0.0)))
    tm = Vector(target_edge.get('mid', (0.0, 0.0, 0.0)))
    pos_score = float((sm - tm).length)
    sd = Vector(source_edge.get('dir', (0.0, 0.0, 0.0)))
    td = Vector(target_edge.get('dir', (0.0, 0.0, 0.0)))
    try:
        if sd.length > _CREASE_VALUE_EPSILON and td.length > _CREASE_VALUE_EPSILON:
            sd.normalize()
            td.normalize()
            angle_score = 1.0 - abs(max(-1.0, min(1.0, float(sd.dot(td)))))
        else:
            angle_score = 1.0
    except Exception:
        angle_score = 1.0
    len_score = abs(float(source_edge.get('length', 0.0)) - float(target_edge.get('length', 0.0)))
    return pos_score + (angle_score * 0.35) + (len_score * 0.75)


def _edge_data_from_edit_object(obj, *, selected_only=True):
    bm = bmesh.from_edit_mesh(obj.data)
    _ensure_bmesh_indices(bm)
    layer = _ensure_crease_layer(bm, create=True)
    min_v, size, diag = _mesh_bounds_from_bmesh(bm)
    edges = []
    for edge in bm.edges:
        if selected_only and not bool(edge.select):
            continue
        edges.append(_edge_feature(edge, layer, min_v, size, diag))
    return {
        'object_name': getattr(obj, 'name', ''),
        'mesh_name': getattr(getattr(obj, 'data', None), 'name', ''),
        'vert_count': len(bm.verts),
        'edge_count': len(bm.edges),
        'edges': edges,
    }


def _edge_data_from_object_mesh(obj, *, selected_only=True):
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        _ensure_bmesh_indices(bm)
        layer = _ensure_crease_layer(bm, create=True)
        min_v, size, diag = _mesh_bounds_from_bmesh(bm)
        edges = []
        mesh_edges = getattr(obj.data, 'edges', ())
        for edge in bm.edges:
            if selected_only:
                selected = False
                try:
                    selected = bool(mesh_edges[edge.index].select)
                except Exception:
                    selected = False
                if not selected:
                    continue
            edges.append(_edge_feature(edge, layer, min_v, size, diag))
        return {
            'object_name': getattr(obj, 'name', ''),
            'mesh_name': getattr(getattr(obj, 'data', None), 'name', ''),
            'vert_count': len(bm.verts),
            'edge_count': len(bm.edges),
            'edges': edges,
        }
    finally:
        try:
            bm.free()
        except Exception:
            pass


def _copy_source_objects(context) -> list:
    edit_objects = _edit_mesh_objects(context)
    if edit_objects:
        return edit_objects
    return _selected_mesh_objects(context)


def _write_same_topology_to_edit_object(obj, source: dict) -> int:
    bm = bmesh.from_edit_mesh(obj.data)
    _ensure_bmesh_indices(bm)
    if len(bm.verts) != int(source.get('vert_count', -1)) or len(bm.edges) != int(source.get('edge_count', -1)):
        return 0
    layer = _ensure_crease_layer(bm, create=True)
    changed = 0
    for item in tuple(source.get('edges') or ()):  # pragma: no branch
        try:
            idx = int(item.get('index', -1))
            if 0 <= idx < len(bm.edges):
                bm.edges[idx][layer] = min(1.0, max(0.0, float(item.get('value', 0.0))))
                changed += 1
        except Exception:
            pass
    if changed:
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
    return changed


def _write_same_topology_to_object_mesh(obj, source: dict) -> int:
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        _ensure_bmesh_indices(bm)
        if len(bm.verts) != int(source.get('vert_count', -1)) or len(bm.edges) != int(source.get('edge_count', -1)):
            return 0
        layer = _ensure_crease_layer(bm, create=True)
        changed = 0
        for item in tuple(source.get('edges') or ()):  # pragma: no branch
            try:
                idx = int(item.get('index', -1))
                if 0 <= idx < len(bm.edges):
                    bm.edges[idx][layer] = min(1.0, max(0.0, float(item.get('value', 0.0))))
                    changed += 1
            except Exception:
                pass
        if changed:
            bm.to_mesh(obj.data)
            obj.data.update()
        return changed
    finally:
        try:
            bm.free()
        except Exception:
            pass


def _target_edges_features_from_bmesh(bm, layer):
    min_v, size, diag = _mesh_bounds_from_bmesh(bm)
    return [_edge_feature(edge, layer, min_v, size, diag) for edge in bm.edges]


def _write_approx_to_edit_object(obj, source: dict, tolerance: float) -> int:
    bm = bmesh.from_edit_mesh(obj.data)
    _ensure_bmesh_indices(bm)
    layer = _ensure_crease_layer(bm, create=True)
    target_features = _target_edges_features_from_bmesh(bm, layer)
    used = set()
    changed = 0
    for src_edge in tuple(source.get('edges') or ()):  # pragma: no branch
        best_idx = -1
        best_score = float('inf')
        for target in target_features:
            idx = int(target.get('index', -1))
            if idx in used or idx < 0:
                continue
            score = _score_edge_match(src_edge, target)
            if score < best_score:
                best_score = score
                best_idx = idx
        if best_idx >= 0 and best_score <= tolerance:
            try:
                bm.edges[best_idx][layer] = min(1.0, max(0.0, float(src_edge.get('value', 0.0))))
                used.add(best_idx)
                changed += 1
            except Exception:
                pass
    if changed:
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
    return changed


def _write_approx_to_object_mesh(obj, source: dict, tolerance: float) -> int:
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        _ensure_bmesh_indices(bm)
        layer = _ensure_crease_layer(bm, create=True)
        target_features = _target_edges_features_from_bmesh(bm, layer)
        used = set()
        changed = 0
        for src_edge in tuple(source.get('edges') or ()):  # pragma: no branch
            best_idx = -1
            best_score = float('inf')
            for target in target_features:
                idx = int(target.get('index', -1))
                if idx in used or idx < 0:
                    continue
                score = _score_edge_match(src_edge, target)
                if score < best_score:
                    best_score = score
                    best_idx = idx
            if best_idx >= 0 and best_score <= tolerance:
                try:
                    bm.edges[best_idx][layer] = min(1.0, max(0.0, float(src_edge.get('value', 0.0))))
                    used.add(best_idx)
                    changed += 1
                except Exception:
                    pass
        if changed:
            bm.to_mesh(obj.data)
            obj.data.update()
        return changed
    finally:
        try:
            bm.free()
        except Exception:
            pass


def _source_for_target(target, clipboard, *, same_topology=True):
    sources = tuple((clipboard or {}).get('sources') or ())
    if not sources:
        return None
    if same_topology:
        try:
            tv = len(target.data.vertices)
            te = len(target.data.edges)
        except Exception:
            tv = te = -1
        for source in sources:
            if int(source.get('vert_count', -1)) == tv and int(source.get('edge_count', -1)) == te:
                return source
        return None
    # Prefer the same topology source when available, otherwise use the first
    # copied source as the pattern for approximate matching.
    same = _source_for_target(target, clipboard, same_topology=True)
    return same if same is not None else sources[0]


def _clipboard_counts():
    sources = tuple(_CREASE_CLIPBOARD.get('sources') or ())
    return len(sources), sum(len(tuple(src.get('edges') or ())) for src in sources)


class MESH_OT_Crease_Apply(bpy.types.Operator):
    bl_idname = "mesh.crease_apply"
    bl_label = "Apply Crease"
    # Opening the popup is UI-only.  The child crease operators own the
    # actual mesh edit and its single Undo record.
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    crease_value: FloatProperty(default=0.0, min=0.0, max=1.0)
    apply_mode: EnumProperty(
        items=[('SELECTED', 'Selected', ''), ('LINKED', 'Linked', '')],
        default='SELECTED',
    )
    delimit_seam: BoolProperty(default=False)
    delimit_sharp: BoolProperty(default=False)
    delimit_material: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        ok, msg = set_edge_crease(
            context,
            self.crease_value,
            mode=self.apply_mode,
            delimit_seam=self.delimit_seam,
            delimit_sharp=self.delimit_sharp,
            delimit_material=self.delimit_material,
        )
        level = {'INFO'} if ok else {'WARNING'}
        self.report(level, _tr(msg))
        return {'FINISHED'} if ok else {'CANCELLED'}


class MESH_OT_Crease_SelectSameValue(bpy.types.Operator):
    bl_idname = "mesh.crease_select_same_value"
    bl_label = "Select Same Value"
    bl_description = "Select every edge whose crease value matches the specified selection value. This works after typing a crease value manually, or after selecting one or more edges so the field is auto-filled from their crease value."
    bl_options = {'UNDO'}

    value: FloatProperty(default=-1.0, min=-1.0, max=1.0)
    tolerance: FloatProperty(default=-1.0, min=-1.0, max=0.25)

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        prefs = _get_prefs(context)
        state = _crease_preset_state(context)
        value = float(self.value) if float(self.value) >= 0.0 else float(state['select_crease_value'])
        tolerance = float(self.tolerance) if float(self.tolerance) >= 0.0 else float(state['match_tolerance'])
        selected = 0
        for obj, bm, layer in _iter_edit_bmeshes(context, create_layer=True):
            for face in bm.faces:
                try:
                    face.select_set(False)
                except Exception:
                    pass
            for edge in bm.edges:
                try:
                    edge.select_set(False)
                except Exception:
                    pass
            for vert in bm.verts:
                try:
                    vert.select_set(False)
                except Exception:
                    pass
            for edge in bm.edges:
                try:
                    match = abs(float(edge[layer]) - value) <= tolerance
                except Exception:
                    match = abs(value) <= tolerance
                if match:
                    try:
                        edge.select_set(True)
                        selected += 1
                    except Exception:
                        pass
            try:
                bm.select_flush_mode()
            except Exception:
                pass
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        try:
            context.tool_settings.mesh_select_mode = (False, True, False)
        except Exception:
            pass
        _set_pref_select_value(prefs, value)
        _set_pref_active_value(prefs, value)
        _reset_select_value_manual_override()
        self.report({'INFO'}, _tr("Selected {count} edge(s) with crease {value:g}.").format(count=selected, value=value))
        return {'FINISHED'}


class MESH_OT_Crease_CopySelected(bpy.types.Operator):
    bl_idname = "mesh.crease_copy_selected"
    bl_label = "Copy Selected Edge Creases"
    bl_description = "Copy the crease values of the selected edges. Use this before pasting to another mesh object; same-topology paste uses edge numbers, and approximate paste uses relative edge position, angle, and length."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        global _CREASE_CLIPBOARD
        sources = []
        for obj in _copy_source_objects(context):
            try:
                if getattr(obj, 'mode', '') == 'EDIT':
                    data = _edge_data_from_edit_object(obj, selected_only=True)
                else:
                    data = _edge_data_from_object_mesh(obj, selected_only=True)
            except Exception:
                data = None
            if data and data.get('edges'):
                sources.append(data)
        if not sources:
            self.report({'WARNING'}, _tr('No selected edges found'))
            return {'CANCELLED'}
        _CREASE_CLIPBOARD = {'sources': sources}
        objects, edges = _clipboard_counts()
        self.report({'INFO'}, _tr('Copied {edges} selected edge crease value(s) from {objects} object(s).').format(edges=edges, objects=objects))
        return {'FINISHED'}


class MESH_OT_Crease_PasteSameTopology(bpy.types.Operator):
    bl_idname = "mesh.crease_paste_same_topology"
    bl_label = "Paste Same Topology"
    bl_description = "Paste copied edge crease values to mesh objects that have the same vertex and edge topology. This uses edge indices, so it is the most accurate option for duplicated or matching meshes."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        if not _CREASE_CLIPBOARD.get('sources'):
            self.report({'WARNING'}, _tr('No copied crease data'))
            return {'CANCELLED'}
        total_edges = 0
        object_count = 0
        edit_mode = bool(_edit_mesh_objects(context))
        for obj in _target_mesh_objects(context):
            source = _source_for_target(obj, _CREASE_CLIPBOARD, same_topology=True)
            if source is None:
                continue
            try:
                changed = _write_same_topology_to_edit_object(obj, source) if edit_mode and getattr(obj, 'mode', '') == 'EDIT' else _write_same_topology_to_object_mesh(obj, source)
            except Exception:
                changed = 0
            if changed:
                total_edges += changed
                object_count += 1
        if total_edges <= 0:
            self.report({'WARNING'}, _tr('No same-topology target was found.'))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr('Pasted {edges} edge crease value(s) to {objects} object(s) by same topology.').format(edges=total_edges, objects=object_count))
        return {'FINISHED'}


class MESH_OT_Crease_PasteApproximate(bpy.types.Operator):
    bl_idname = "mesh.crease_paste_approximate"
    bl_label = "Paste Approximate"
    bl_description = "Paste copied edge crease values to approximately matching edges. This compares each edge by relative position in the mesh, direction angle, and relative length, so it can transfer creases to a different topology when the shape is similar."
    bl_options = {'UNDO'}

    tolerance: FloatProperty(default=-1.0, min=-1.0, max=2.0)

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        if not _CREASE_CLIPBOARD.get('sources'):
            self.report({'WARNING'}, _tr('No copied crease data'))
            return {'CANCELLED'}
        state = _crease_preset_state(context)
        tolerance = float(self.tolerance) if float(self.tolerance) >= 0.0 else float(state['approx_match_tolerance'])
        total_edges = 0
        object_count = 0
        edit_mode = bool(_edit_mesh_objects(context))
        for obj in _target_mesh_objects(context):
            source = _source_for_target(obj, _CREASE_CLIPBOARD, same_topology=False)
            if source is None:
                continue
            try:
                changed = _write_approx_to_edit_object(obj, source, tolerance) if edit_mode and getattr(obj, 'mode', '') == 'EDIT' else _write_approx_to_object_mesh(obj, source, tolerance)
            except Exception:
                changed = 0
            if changed:
                total_edges += changed
                object_count += 1
        if total_edges <= 0:
            self.report({'WARNING'}, _tr('No approximate target edge was found within the tolerance.'))
            return {'CANCELLED'}
        self.report({'INFO'}, _tr('Pasted {edges} edge crease value(s) to {objects} object(s) by approximate matching.').format(edges=total_edges, objects=object_count))
        return {'FINISHED'}


def _layout_operator(layout, idname, *, text=None, icon='NONE'):
    try:
        return layout.operator(idname, text=text if text is not None else '', icon=icon)
    except Exception:
        row = layout.row(align=True)
        row.enabled = False
        return row.operator(idname, text=text if text is not None else '', icon=icon)


def _draw_crease_value_field(layout, prefs, prop, caption, *, in_menu=False):
    if in_menu:
        layout.prop(prefs, prop, text=_tr(caption))
        return
    column = layout.column(align=True)
    column.use_property_split = False
    column.label(text=_tr(caption))
    column.prop(prefs, prop, text='')


def _draw_current_value_tools(layout, context, *, narrow=False, in_menu=False):
    state = _crease_preset_state(context)
    prefs = state['prefs']
    average, count = _refresh_active_value_from_selection(context, prefs)
    _refresh_select_value_from_selection(context, prefs, average=average, count=count)
    if prefs is None:
        prefs = _get_prefs(context)
    box = layout if in_menu else layout.box()
    box.use_property_split = not narrow
    box.use_property_decorate = False
    box.label(text=_tr('Current / Select by Value'), icon='EDGESEL')
    info = box if in_menu else box.column(align=True)
    if count > 0 and average is not None:
        info.label(text=_tr('Selected edges: {count} / average {value:g}').format(count=count, value=average))
    else:
        info.label(text=_tr('No edge is selected.'))
    if prefs is not None:
        row = box if in_menu else box.row(align=True)
        _draw_crease_value_field(row, prefs, 'active_crease_value', 'Selected Edge Crease', in_menu=in_menu)

        has_select_prop = False
        try:
            has_select_prop = _ensure_crease_preset_pref_runtime_props(prefs)
        except Exception:
            has_select_prop = False
        row = box if in_menu else box.row(align=True)
        if has_select_prop:
            _draw_crease_value_field(row, prefs, 'select_crease_value', 'Crease Value to Select', in_menu=in_menu)
            select_value = float(getattr(prefs, 'select_crease_value', state['select_crease_value']))
        else:
            select_value = float(state['select_crease_value'])
            row.label(text=f"{_tr('Crease Value to Select')}: {select_value:g}")

        row = box if in_menu else box.row(align=True)
        op = row.operator('mesh.crease_select_same_value', text=_tr('Select Edges by Crease Value'), icon='RESTRICT_SELECT_OFF')
        try:
            op.value = select_value
            op.tolerance = float(getattr(prefs, 'match_tolerance'))
        except Exception:
            pass
        _draw_crease_value_field(box, prefs, 'match_tolerance', 'Crease Match Tolerance', in_menu=in_menu)
    else:
        row = box if in_menu else box.row(align=True)
        row.label(text=_tr('Crease Value to Select'))
        row.operator('mesh.crease_select_same_value', text=_tr('Select Edges by Crease Value'), icon='RESTRICT_SELECT_OFF')


def _draw_copy_paste_tools(layout, context, *, narrow=False, in_menu=False):
    state = _crease_preset_state(context)
    prefs = state['prefs']
    objects, edges = _clipboard_counts()
    box = layout if in_menu else layout.box()
    box.use_property_split = not narrow
    box.use_property_decorate = False
    box.label(text=_tr('Copy / Paste Crease'), icon='COPYDOWN')
    if edges:
        box.label(text=_tr('Clipboard: {objects} object(s), {edges} edge(s)').format(objects=objects, edges=edges))
    else:
        box.label(text=_tr('Clipboard: empty'))
    row = box if in_menu else box.row(align=True)
    row.operator('mesh.crease_copy_selected', text=_tr('Copy Selected Edge Creases'), icon='COPYDOWN')
    row = box if in_menu else (box.column(align=True) if narrow else box.row(align=True))
    row.operator('mesh.crease_paste_same_topology', text=_tr('Paste Same Topology'), icon='PASTEDOWN')
    op = row.operator('mesh.crease_paste_approximate', text=_tr('Paste Approximate'), icon='SNAP_EDGE')
    try:
        op.tolerance = float(state['approx_match_tolerance'])
    except Exception:
        pass
    if prefs is not None:
        _draw_crease_value_field(box, prefs, 'approx_match_tolerance', 'Approximate Paste Tolerance', in_menu=in_menu)


def _draw_preset_buttons(layout, context, *, in_menu=False):
    state = _crease_preset_state(context)
    prefs = state['prefs']

    if prefs is not None:
        layout.prop(prefs, 'use_pie_menu')

    box = layout if in_menu else layout.box()
    box.label(text=_tr('Selected'), icon='EDGESEL')
    flow = box if in_menu else box.grid_flow(
        row_major=True, columns=4, even_columns=True, even_rows=True, align=True,
    )
    for i in range(int(state['sel_count'])):
        val = float(state['sel_values'][i])
        op = flow.operator('mesh.crease_apply', text=f'{val:g}')
        op.crease_value = val
        op.apply_mode = 'SELECTED'

    box = layout if in_menu else layout.box()
    box.label(text=_tr('Linked'), icon='LINKED')
    flow = box if in_menu else box.grid_flow(
        row_major=True, columns=4, even_columns=True, even_rows=True, align=True,
    )
    for i in range(int(state['link_count'])):
        val = float(state['link_values'][i])
        op = flow.operator('mesh.crease_apply', text=f'{val:g}')
        op.crease_value = val
        op.apply_mode = 'LINKED'
        op.delimit_seam = bool(state['linked_delimit_seam'])
        op.delimit_sharp = bool(state['linked_delimit_sharp'])
        op.delimit_material = bool(state['linked_delimit_material'])

    if prefs is not None:
        delim = layout if in_menu else layout.box()
        delim.use_property_split = False
        delim.use_property_decorate = False
        delim.label(text=_tr('Linked Delimit'), icon='MOD_MASK')
        row = delim if in_menu else delim.row(align=True)
        row.use_property_split = False
        row.use_property_decorate = False
        row.prop(prefs, 'linked_delimit_seam', text=_tr('Seam'), toggle=True)
        row.prop(prefs, 'linked_delimit_sharp', text=_tr('Sharp'), toggle=True)
        row.prop(prefs, 'linked_delimit_material', text=_tr('Material'), toggle=True)


def _draw_crease_preset_layout(layout, context):
    layout.use_property_split = True
    layout.use_property_decorate = False
    _draw_current_value_tools(layout, context)
    _draw_copy_paste_tools(layout, context)
    _draw_preset_buttons(layout, context)


def draw_smart_modeling_panel(layout, context):
    layout.use_property_split = True
    layout.use_property_decorate = False

    box = layout.box()
    box.label(text=_tr('Quick Start'), icon='PLAY')
    row = box.row(align=True)
    row.scale_y = 1.25
    row.operator_context = 'INVOKE_DEFAULT'
    row.operator('mesh.edge_crease_master', text=_tr('Open Crease Preset'), icon='PRESET')

    box = layout.box()
    box.label(text=_tr('Quick Apply (Selected)'), icon='GREASEPENCIL')
    row = box.row(align=True)
    for value, label in ((0.0, '0.0'), (0.25, '0.25'), (0.5, '0.5'), (1.0, '1.0')):
        op = row.operator('mesh.crease_apply', text=label)
        op.crease_value = value
        op.apply_mode = 'SELECTED'

    _draw_current_value_tools(layout, context)
    _draw_copy_paste_tools(layout, context)


def draw_smart_modeling_settings(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    row = layout.row(align=True)
    row.scale_y = 1.15
    row.operator_context = 'INVOKE_DEFAULT'
    row.operator('mesh.edge_crease_master', text=_tr('Open Crease Preset'), icon='PRESET')
    _draw_current_value_tools(layout, context, narrow=True)
    _draw_copy_paste_tools(layout, context, narrow=True)
    _draw_preset_buttons(layout, context)
    prefs = _get_prefs(context)
    if prefs is None:
        return
    box = layout.box()
    box.use_property_split = False
    box.use_property_decorate = False
    box.label(text=_tr('Preset Values'), icon='PRESET')
    for count_name, values_name, title in (
        ('sel_count', 'sel_values', 'Selected Preset Values'),
        ('link_count', 'link_values', 'Linked Preset Values'),
    ):
        box.prop(prefs, count_name)
        box.label(text=_tr(title))
        flow = box.grid_flow(row_major=True, columns=4, even_columns=True, even_rows=True, align=True)
        for index in range(int(getattr(prefs, count_name, 0))):
            flow.prop(prefs, values_name, index=index, text='')


class MESH_MT_CreasePresetMenu(bpy.types.Menu):
    bl_idname = "MESH_MT_crease_preset_menu"
    bl_label = "Crease Preset"

    def draw(self, context):
        layout = self.layout
        _draw_current_value_tools(layout, context, narrow=True, in_menu=True)
        layout.separator()
        _draw_copy_paste_tools(layout, context, narrow=True, in_menu=True)
        layout.separator()
        _draw_preset_buttons(layout, context, in_menu=True)


class MESH_MT_CreasePresetPieMenu(bpy.types.Menu):
    bl_idname = "MESH_MT_crease_preset_pie_menu"
    bl_label = "Crease Preset"

    def draw(self, context):
        state = _crease_preset_state(context)
        pie = self.layout.menu_pie()
        selected_label = _tr('Selected')
        linked_label = _tr('Linked')
        linked_kwargs = {
            'delimit_seam': bool(state['linked_delimit_seam']),
            'delimit_sharp': bool(state['linked_delimit_sharp']),
            'delimit_material': bool(state['linked_delimit_material']),
        }
        slots = []
        for i in range(int(state['sel_count'])):
            slots.append(('SELECTED', float(state['sel_values'][i]), {}))
            if len(slots) >= 4:
                break
        for i in range(int(state['link_count'])):
            slots.append(('LINKED', float(state['link_values'][i]), linked_kwargs))
            if len(slots) >= 8:
                break
        while len(slots) < 8:
            slots.append(None)
        for slot in slots[:8]:
            if slot is None:
                pie.separator()
                continue
            mode, value, extra = slot
            prefix = selected_label if mode == 'SELECTED' else linked_label
            op = pie.operator('mesh.crease_apply', text=f'{prefix} {value:g}')
            op.crease_value = value
            op.apply_mode = mode
            op.delimit_seam = bool(extra.get('delimit_seam', False))
            op.delimit_sharp = bool(extra.get('delimit_sharp', False))
            op.delimit_material = bool(extra.get('delimit_material', False))


def invoke_crease_preset_menu(
    context=None,
    *,
    report_cb=None,
    operator=None,
    event=None,
    invoke=False,
):
    del event
    _reset_select_value_manual_override()
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return {'CANCELLED'}
    prefs = _get_prefs(context)
    use_pie = bool(getattr(prefs, 'use_pie_menu', False)) if prefs is not None else False
    menu_id = MESH_MT_CreasePresetPieMenu.bl_idname if use_pie else MESH_MT_CreasePresetMenu.bl_idname
    if use_pie:
        try:
            return bpy.ops.wm.call_menu_pie(name=menu_id)
        except Exception:
            return {'CANCELLED'}
    # A popup must be owned by Blender's currently executing registered
    # wmOperator instance.  Never construct MESH_OT_CreaseMaster() directly:
    # that object has no valid RNA/operator lifetime and can fail on the first
    # key press or crash when the popup is torn down.
    popup_operator = operator
    if not invoke or popup_operator is None:
        return {'CANCELLED'}
    try:
        return context.window_manager.invoke_popup(popup_operator, width=_CREASE_PRESET_POPUP_WIDTH)
    except Exception as exc:
        if callable(report_cb):
            try:
                report_cb({'WARNING'}, str(exc))
            except Exception:
                pass
        return {'CANCELLED'}
    return {'CANCELLED'}


class MESH_OT_CreaseMaster(bpy.types.Operator):
    bl_idname = "mesh.edge_crease_master"
    bl_label = 'Open Crease Presets'
    bl_description = "Open the edge-crease preset menu for the current Edit Mode mesh selection. The popup shows the selected edge crease value, lets you select edges by value, and provides crease copy/paste tools."
    # Popup display is UI-only.  Child crease operators own the mesh edit and
    # the single Undo record.
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        # Popup-only operator.  Returning CANCELLED for direct execution avoids
        # creating transient WM macro/operator property state in Blender 5.1.
        return {'CANCELLED'}

    def invoke(self, context, event):
        return invoke_crease_preset_menu(
            context,
            report_cb=self.report,
            operator=self,
            event=event,
            invoke=True,
        )

    def draw(self, context):
        _draw_crease_preset_layout(self.layout, context)


classes = (
    CreasePresetItem,
    CreasePresetPreferences,
    MESH_OT_Crease_Apply,
    MESH_OT_Crease_SelectSameValue,
    MESH_OT_Crease_CopySelected,
    MESH_OT_Crease_PasteSameTopology,
    MESH_OT_Crease_PasteApproximate,
    MESH_MT_CreasePresetMenu,
    MESH_MT_CreasePresetPieMenu,
    MESH_OT_CreaseMaster,
)


def register():
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass
        except RuntimeError:
            pass
    # In overwrite installs, the suite-level preference proxy may already be an
    # old live RNA class.  Add the new select-by-value field if Blender allows it.
    try:
        suite = _suite_prefs(getattr(bpy, 'context', None))
        _ensure_crease_preset_pref_runtime_props(getattr(suite, 'crease_preset', None) if suite else None)
    except Exception:
        pass
    # Panel.draw cannot create the settings storage, so it must exist from here on.
    _get_prefs(getattr(bpy, 'context', None))


def unregister():
    global _CREASE_CLIPBOARD
    _CREASE_CLIPBOARD = {}
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
