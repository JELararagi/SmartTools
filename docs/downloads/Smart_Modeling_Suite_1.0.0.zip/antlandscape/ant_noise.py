import bpy
from mathutils.noise import (
    seed_set,
    noise,
    turbulence,
    turbulence_vector,
    fractal,
    hybrid_multi_fractal,
    multi_fractal,
    ridged_multi_fractal,
    hetero_terrain,
    random_unit_vector,
    variable_lacunarity,
    voronoi,
)
from math import (
    floor, sqrt,
    sin, cos, pi,
)

noise_basis_default = "BLENDER"
noise_basis = [
    ("BLENDER", "Blender", "Blender default noise", 0),
    ("PERLIN_ORIGINAL", "Perlin", "Perlin noise", 1),
    ("PERLIN_NEW", "New Perlin", "New Perlin noise", 2),
    ("VORONOI_F1", "Voronoi F1", "Voronoi F1", 3),
    ("VORONOI_F2", "Voronoi F2", "Voronoi F2", 4),
    ("VORONOI_F3", "Voronoi F3", "Voronoi F3", 5),
    ("VORONOI_F4", "Voronoi F4", "Voronoi F4", 6),
    ("VORONOI_F2F1", "Voronoi F2-F1", "Voronoi F2-F1", 7),
    ("VORONOI_CRACKLE", "Voronoi Crackle", "Voronoi Crackle", 8),
    ("CELLNOISE", "Cell Noise", "Cell noise", 9)
]

# ------------------------------------------------------------
# Height scale:


def Height_Scale(input, iscale, offset, invert):
    if invert != 0:
        return (1.0 - input) * iscale + offset
    else:
        return input * iscale + offset


# Functions for marble_noise and effects:

def Dist(x, y):
    return sqrt((x * x) + (y * y))


def sin_bias(a):
    return 0.5 + 0.5 * sin(a)


def cos_bias(a):
    return 0.5 + 0.5 * cos(a)


def tri_bias(a):
    b = 2 * pi
    a = 1 - 2 * abs(floor((a * (1 / b)) + 0.5) - (a * (1 / b)))
    return a


def saw_bias(a):
    b = 2 * pi
    n = int(a / b)
    a -= n * b
    if a < 0:
        a += b
    return a / b


def soft(a):
    return a


def sharp(a):
    return a**0.5


def sharper(a):
    return sharp(sharp(a))


def no_bias(a):
    return a


def shapes(x, y, z, shape=0):
    if 5 <= shape <= 7 and shape in (5, 6, 7):
        return {5: z, 6: y, 7: x}[shape] * pi
    u, v = x * pi, y * pi
    if shape in (1, 2):
        phase = u ** 2 + v ** 2
        oscillation = cos(phase) if shape == 1 else u * sin(phase) + v * cos(phase)
        return oscillation / (phase + 0.5)
    if shape == 3:
        return 1.5 - sum(cos(axis * pi) for axis in (u, v, z * pi))
    if shape == 4:
        return sin(2 * u + sin(2 * v))
    return 5 * (x + y + z)


# marble_noise
def marble_noise(x, y, z, origin, size, shape, bias, sharpnes, turb, depth, hard, basis, amp, freq):
    position = tuple(a + b for a, b in zip((x, y, z), origin[:3]))
    disturbance = turbulence_vector(position, depth, hard, noise_basis=basis)
    wave = {1: cos_bias, 2: tri_bias, 3: saw_bias}.get(bias, sin_bias)
    sample = wave(shapes(x, y, z, shape) + turb * disturbance[1])
    if sharpnes in (1, 4):
        sample = sharp(sample)
    elif sharpnes in (2, 5):
        sample = sharper(sample)
    return sample if sharpnes in (3, 4, 5) else 1.0 - sample


# vl_noise_turbulence:
def vlnTurbMode(coords, distort, basis, vlbasis, hardnoise):
    # hard noise
    if hardnoise:
        return (abs(-variable_lacunarity(coords, distort, noise_type1=basis, noise_type2=vlbasis)))
    # soft noise
    else:
        return variable_lacunarity(coords, distort, noise_type1=basis, noise_type2=vlbasis)


def vl_noise_turbulence(coords, distort, depth, basis, vlbasis, hardnoise, amp, freq):
    def sample(position):
        value = variable_lacunarity(position, distort, noise_type1=basis, noise_type2=vlbasis)
        return abs(value) if hardnoise else value

    elevation = sample(coords)
    for band in range(1, depth + 1):
        scale = freq * band
        elevation += sample(tuple(axis * scale for axis in coords)) * (0.5 * amp / band)
    return elevation


# duo_multiFractal:
def double_multiFractal(coords, H, lacunarity, octaves, offset, gain, basis, vlbasis):
    fine_at = tuple(axis * 1.5 + 1.0 for axis in coords)
    coarse_at = tuple(axis - 1.0 for axis in coords)
    fine = multi_fractal(fine_at, 1.0, 1.0, 1.0, noise_basis=basis) * (offset * 0.5)
    coarse = multi_fractal(coarse_at, H, lacunarity, octaves, noise_basis=vlbasis) * (gain * 0.5)
    return _terrain_energy(fine, coarse)


# distorted_heteroTerrain:
def distorted_heteroTerrain(coords, H, lacunarity, octaves, offset, distort, basis, vlbasis):
    base = hetero_terrain(coords, 1.0, 2.0, 1.0, 1.0, noise_basis=basis) / 2
    warped = tuple(axis + base * distort for axis in coords)
    detail = hetero_terrain(warped, H, lacunarity, octaves, offset, noise_basis=vlbasis) / 4
    return _terrain_energy(base, detail)


# SlickRock:
def slick_rock(coords, H, lacunarity, octaves, offset, gain, distort, basis, vlbasis):
    bend = multi_fractal(coords, 1.0, 2.0, 2.0, noise_basis=basis) * distort / 4
    sample_at = tuple(axis + bend for axis in coords)
    ridges = ridged_multi_fractal(sample_at, H, lacunarity, octaves, offset + 0.1, 2 * gain, noise_basis=vlbasis)
    return (bend * ridges + bend) / 2


# vlhTerrain
def vl_hTerrain(coords, H, lacunarity, octaves, offset, basis, vlbasis, distort):
    surface = hetero_terrain(coords, H, lacunarity, octaves, offset, noise_basis=basis) / 4
    lattice = variable_lacunarity(coords, distort, noise_type1=basis, noise_type2=vlbasis)
    return surface * (0.5 + surface * lattice / 2)


# another turbulence
def ant_turbulence(coords, depth, hardnoise, nbasis, amp, freq, distortion):
    half = tuple(axis / 2 for axis in coords)
    drift = turbulence_vector(half, depth, False, noise_basis=nbasis, amplitude_scale=amp, frequency_scale=freq)
    warped = tuple(drift * 0.5 * distortion)
    return 0.5 + turbulence(warped, 2, hardnoise, noise_basis="VORONOI_F1") / 2


# rocks noise
def rocks_noise(coords, depth, hardnoise, nbasis, distortion):
    x, y, z = coords
    displacement = turbulence(coords, 4, False, noise_basis="BLENDER") / 8 * distortion
    near = turbulence((x + displacement, y + displacement, z), 2, False, noise_basis="VORONOI_F2F1")
    far = turbulence((x, y, z + near * 0.1875 * distortion), depth, hardnoise, noise_basis=nbasis)
    return 0.5 + (near + (far - near) / 2) / 2


# shattered_hterrain:
def shattered_hterrain(coords, H, lacunarity, octaves, offset, distort, basis):
    breakup = turbulence_vector(coords, 6, False)[0]
    displacement = (breakup / 2 + 0.5) * distort / 2
    fragments = turbulence_vector(tuple(axis + displacement for axis in coords), 0, False, noise_basis="VORONOI_F2F1")[0]
    twice = tuple(2 * axis for axis in coords)
    slope = hetero_terrain(twice, H, lacunarity, octaves, offset, noise_basis=basis) / 2
    return ((fragments + 0.5) * slope + slope / 2) / 2


# strata_hterrain
def strata_hterrain(coords, H, lacunarity, octaves, offset, distort, basis):
    bedrock = hetero_terrain(coords, H, lacunarity, octaves, offset, noise_basis=basis) / 2
    wavelength = 5 * distort
    if not wavelength:
        return bedrock / 2
    ripple = sin(bedrock * wavelength * pi) * (0.1 / wavelength * pi)
    return (bedrock + ripple) / 2


# Planet Noise by: Farsthary
# https://farsthary.com/2010/11/24/new-planet-procedural-texture/
def planet_noise(coords, oct=6, hard=0, noisebasis="PERLIN_ORIGINAL", nabla=0.001):
    def sample(position):
        return turbulence(position, oct, hard, noise_basis=noisebasis)

    x, y, z = coords
    separation = nabla * 1000
    first = sample(coords)
    second = sample((first + separation, y, z))
    third = sample((first, second + separation, z))
    position = first, second, third
    step = 0.001
    at_x, at_y, at_z = (
        sample(tuple(value + step if axis == index else value for index, value in enumerate(position)))
        for axis in range(3)
    )
    return ((third - at_y) - (second - at_z),
            (third - at_x) - (first - at_z),
            (second - at_x) - (first - at_y))


# ----------------------------------------------------------------------
# v.1.04 Effect functions:

def maximum(a, b):
    if (a > b):
        b = a
    return b


def minimum(a, b):
    if (a < b):
        b = a
    return b


def Mix_Modes(a, b, mixfactor, mode):
    mode = int(mode)
    lower = a * (1.0 - mixfactor)
    upper = b * (1.0 + mixfactor)
    if mode == 0:
        return lower * 0.5 + upper * 0.5
    if mode == 1:
        return lower + upper
    if mode == 2:
        return lower - upper
    if mode == 3:
        return lower * upper
    if mode == 4:
        return abs(lower - upper)
    if mode == 5:
        return 1.0 - (1.0 - lower) * (1.0 - upper)
    if mode == 6:
        return (lower + upper) % 1.0
    if mode == 7:
        return lower if lower < upper else upper
    if mode == 8:
        return lower if lower > upper else upper
    return 0


Bias_Types = [sin_bias, cos_bias, tri_bias, saw_bias, no_bias]
Sharp_Types = [soft, sharp, sharper]


# Transpose effect coords:
def Trans_Effect(coords, size, loc):
    return (*(axis * 2.0 / size + origin for axis, origin in zip(coords[:2], loc[:2])), coords[2])


# Effect_Basis_Function:
def Effect_Basis_Function(coords, type, bias):
    select_bias = Bias_Types[int(bias)] if 1 <= int(type) <= 12 else None
    effect = int(type)
    x, y, _ = coords
    u, v = x * pi, y * pi
    flat = x, y, 0
    if 1 <= effect <= 12:
        b = select_bias
        match effect:
            case 1:
                elevation = b(x + y)
            case 2:
                elevation = (b(u) + b(v)) / 2
            case 3:
                elevation = b(sin(u + sin(v)))
            case 4:
                elevation = b(cos(x) + sin(y) + cos(2 * x + 2 * y) - sin(-4 * x + 4 * y))
            case 5:
                elevation = 1 - b(sin(u) + sin(v))
            case 6:
                elevation = b(2 * u) * b(2 * v) - 0.5
            case 7:
                elevation = b(1 - (x * x + y * y))
            case 8:
                radius_squared = x * x + y * y
                elevation = b((x * sin(radius_squared) + y * cos(radius_squared)) / (x ** 2 + y ** 2 + 0.5)) * 2
            case 9:
                elevation = b(1 - sqrt((x * x) ** 10 + (y * y) ** 10) ** 0.1)
            case 10:
                elevation = float(max(b(u), b(v)) < 0.5)
            case 11:
                elevation = float(min(b(u), b(v)) < 0.025)
            case 12:
                primary = b(max(b(u), b(v)))
                secondary = b(max(b(2 * u + 2), b(2 * v + 2)))
                elevation = 3 * min(primary, secondary) - 2
                if elevation > 0.5:
                    elevation = 1.0
    else:
        match effect:
            case 13:
                z = turbulence(flat, 6, False, noise_basis="BLENDER") / 4
                elevation = min(0.5, variable_lacunarity((x, y, z), 0.25, noise_type2="VORONOI_CRACKLE"))
            case 14:
                elevation = 2.5 * min(0.25, 2.5 * abs(noise(flat, noise_basis="PERLIN_ORIGINAL")) - 0.1)
            case 15:
                elevation = min(0.75, 0.5 + noise(flat, noise_basis="VORONOI_F2F1"))
            case 16 | 21:
                distance = voronoi(flat, distance_metric="DISTANCE_SQUARED")[0][0]
                elevation = 2 * min(0.5, 0.25 + 1.5 * distance) if effect == 16 else min(0.25, 2 * (1 - distance) - 1.5)
            case 17:
                elevation = cos(5 * noise(flat, noise_basis="BLENDER")) / 2
            case 18:
                sample = 0.5 + turbulence((5 * x, 5 * y, 0), 8, False, noise_basis="BLENDER") / 2
                elevation = (sample * sample) ** 5
            case 19:
                elevation = 1.5 * noise((2 * x, 2 * y, 0), noise_basis="BLENDER") - 0.75
            case 20:
                elevation = min(0.25, 2 * turbulence(flat, 6, False, noise_basis="BLENDER"))
            case _:
                elevation = 0.0
    return 0.0 if elevation < 0.0 else elevation


# fractalize Effect_Basis_Function: ------------------------------
def Effect_Function(coords, type, bias, turb, depth, frequency, amplitude):
    warp = 0.0
    if turb > 0.0:
        warp = turb * (0.5 + 0.5 * turbulence(coords, 6, False, noise_basis="BLENDER"))
    x, y, z = (axis + warp for axis in coords) if turb > 0.0 else coords
    sample = Effect_Basis_Function
    height = amplitude * sample((x, y, z), type, bias)
    for band in range(1, depth + 1):
        x, y = x * frequency, y * frequency
        height += amplitude * sample((x, y, z), type, bias) / band
    return height


# ------------------------------------------------------------
# landscape_gen
def noise_gen(coords, props):
    seed, *shift = props[13:17]
    scale = props[20]
    if seed:
        seed_set(seed)
        origin = random_unit_vector()
        lateral = tuple(axis * 100 for axis in origin[:2])
        offsets = tuple(value - value / 2 + delta for value, delta in zip(lateral, shift)) + (shift[2],)
    else:
        origin = offsets = shift
    point = tuple(axis / (scale * stretch) + shift for axis, stretch, shift in zip(coords, props[17:20], offsets))
    elevation = _surface_signal(point, props, offsets, origin)

    mix, mode, effect, bias, turbulence_amount, bands, frequency, amplitude, size, left, bottom, strength, offset, flip = props[51:65]
    if effect not in (0, "0"):
        sample_at = Trans_Effect(coords, size, (left, bottom))
        detail = Effect_Function(sample_at, effect, bias, turbulence_amount, bands, frequency, amplitude)
        elevation = Mix_Modes(elevation, Height_Scale(detail, strength, offset, flip), mix, mode)
    height, invert, base, ceiling, floor = props[36:41]
    elevation = Height_Scale(elevation, height, base, invert)
    elevation = _terrain_edges(elevation, coords, props)
    elevation = _terrain_terraces(elevation, props[45], props[46], height)
    if elevation < floor:
        elevation = floor
    if elevation > ceiling:
        elevation = ceiling
    return elevation

def _terrain_energy(first, second):
    return (first * first + second * second) / 2.0

def _surface_signal(coords, properties, offsets, origin):
    mode = properties[21]
    modes = (
        "multi_fractal", "ridged_multi_fractal", "hybrid_multi_fractal", "hetero_terrain",
        "fractal", "turbulence_vector", "variable_lacunarity", "marble_noise",
        "shattered_hterrain", "strata_hterrain", "ant_turbulence", "vl_noise_turbulence",
        "vl_hTerrain", "distorted_heteroTerrain", "double_multiFractal", "rocks_noise",
        "slick_rock", "planet_noise", "blender_texture",
    )
    if isinstance(mode, (int, float)) and 0 <= mode < len(modes) and mode == int(mode):
        mode = modes[int(mode)]
    basis, secondary, distortion, hard, depth, amp, frequency = properties[22:29]
    fractal_settings = (*properties[29:31], depth)
    offset, gain = properties[31:33]
    hard = int(hard)
    match mode:
        case "multi_fractal":
            return multi_fractal(coords, *fractal_settings, noise_basis=basis) / 2
        case "ridged_multi_fractal":
            return ridged_multi_fractal(coords, *fractal_settings, offset, gain, noise_basis=basis) / 2
        case "hybrid_multi_fractal":
            return hybrid_multi_fractal(coords, *fractal_settings, offset, gain, noise_basis=basis) / 2
        case "hetero_terrain":
            return hetero_terrain(coords, *fractal_settings, offset, noise_basis=basis) / 4
        case "fractal":
            return fractal(coords, *fractal_settings, noise_basis=basis)
        case "turbulence_vector":
            return turbulence_vector(coords, depth, hard, noise_basis=basis, amplitude_scale=amp, frequency_scale=frequency)[0]
        case "variable_lacunarity":
            return variable_lacunarity(coords, distortion, noise_type1=basis, noise_type2=secondary)
        case "marble_noise":
            bias, sharpness, profile = map(int, properties[33:36])
            shift = properties[14:17]
            point = tuple(coord - off + value for coord, off, value in zip(coords, offsets, shift))
            origin = tuple(coord + value for coord, value in zip(origin, shift))
            return marble_noise(*point, origin, properties[20], profile, bias, sharpness, distortion, depth, hard, basis, amp, frequency)
        case "shattered_hterrain":
            return shattered_hterrain(coords, *fractal_settings, offset, distortion, basis)
        case "strata_hterrain":
            return strata_hterrain(coords, *fractal_settings, offset, distortion, basis)
        case "ant_turbulence":
            return ant_turbulence(coords, depth, hard, basis, amp, frequency, distortion)
        case "vl_noise_turbulence":
            return vl_noise_turbulence(coords, distortion, depth, basis, secondary, hard, amp, frequency)
        case "vl_hTerrain":
            return vl_hTerrain(coords, *fractal_settings, offset, basis, secondary, distortion)
        case "distorted_heteroTerrain":
            return distorted_heteroTerrain(coords, *fractal_settings, offset, distortion, basis, secondary)
        case "double_multiFractal":
            return double_multiFractal(coords, *fractal_settings, offset, gain, basis, secondary)
        case "rocks_noise":
            return rocks_noise(coords, depth, hard, basis, distortion)
        case "slick_rock":
            return slick_rock(coords, *fractal_settings, offset, gain, distortion, basis, secondary)
        case "planet_noise":
            return 0.5 + planet_noise(coords, depth, hard, basis)[2] / 2
        case "blender_texture":
            texture = bpy.data.textures.get(properties[7])
            return texture.evaluate(coords)[3] if texture else 0.0
        case _:
            return 0.5

def _terrain_edges(value, coords, properties):
    edge_mode = int(properties[41])
    if properties[4] or not edge_mode:
        return value
    x, y = coords[:2]
    width, length = properties[10:12]
    edge_level, power_x, power_y = properties[42:45]
    horizontal = (2 * abs(x) / width) ** power_x
    vertical = (2 * abs(y) / length) ** power_y
    distance = sqrt((0, vertical, horizontal, horizontal + vertical)[edge_mode])
    if distance >= 1:
        return edge_level
    smooth = distance * distance * (3 - 2 * distance)
    level = value - edge_level
    return level - level * smooth + edge_level

def _terrain_terraces(value, style, frequency, height):
    if style not in (1, 2, 3, 4, 5, "1", "2", "3", "4", "5") or height == 0 or frequency == 0:
        return value
    frequency = frequency / height
    style = int(style)
    if style > 3:
        terrace = int(value * frequency) / frequency
        return terrace if style == 4 else (value + terrace) / 2
    if style == 1:
        frequency *= 2
    wave = sin(value * frequency * pi) * (0.1 / frequency * pi)
    if style != 1:
        wave = abs(wave) if style == 3 else -abs(wave)
    return value + wave