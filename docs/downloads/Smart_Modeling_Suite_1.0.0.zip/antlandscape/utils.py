# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Expose the optional numerical accelerator's actual import availability."""

from importlib import import_module as _load


def _available():
    try:
        _load("numexpr")
    except ImportError:
        return False
    return True


numexpr_available = _available()
