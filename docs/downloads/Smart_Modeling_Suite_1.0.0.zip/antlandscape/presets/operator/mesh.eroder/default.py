# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart Modeling preset: default."""

import bpy


def apply(parameters):
    resets = {
        'Iterations': 1,
        'IterRiver': 30,
        'IterAva': 5,
        'IterDiffuse': 5,
        'Ef': 0.0,
        'Kd': 0.1,
        'Kt': 1.0471975512,
        'Kr': 0.01,
        'Kv': 0.0,
        'userainmap': True,
        'Ks': 0.5,
        'Kdep': 0.1,
        'Kz': 0.3,
        'Kc': 0.9,
        'Ka': 1.0,
        'Kev': 0.5,
        'numexpr': True,
        'Pd': 0.2,
        'Pa': 0.5,
        'Pw': 1.0,
        'smooth': True,
        'showiterstats': False,
        'showmeshstats': False,
    }
    for field, value in resets.items():
        setattr(parameters, field, value)


if bpy.context.active_operator is not None:
    apply(bpy.context.active_operator)
