# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart Modeling preset: strong erosion."""

import bpy


def apply(parameters):
    resets = {
        'Iterations': 1,
        'IterRiver': 30,
        'IterAva': 5,
        'IterDiffuse': 5,
        'Ef': 1.0,
        'Kd': 0.26,
        'Kt': 1.0471975512,
        'Kr': 0.023,
        'Kv': 0.55,
        'userainmap': True,
        'Ks': 0.22,
        'Kdep': 0.1,
        'Kz': 0.21,
        'Kc': 0.82,
        'Ka': 1.0,
        'Kev': 0.27,
        'numexpr': True,
        'Pd': 0.2,
        'Pa': 0.89,
        'Pw': 1.0,
        'smooth': True,
        'showiterstats': False,
        'showmeshstats': False,
    }
    for field, value in resets.items():
        setattr(parameters, field, value)


if bpy.context.active_operator is not None:
    apply(bpy.context.active_operator)
