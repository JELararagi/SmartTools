# A.N.T. Landscape Source Evidence

Compared upstream author field: Jimmy Hazevoet
Comparison commit: b42d68627734cb18af0e6f41537063984313a284
Comparison-source version: 0.1.8

## antlandscape/__init__.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/ant_landscape/__init__.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2017-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 6.

## antlandscape/ant_functions.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/ant_landscape/ant_functions.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2017-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 17.

## antlandscape/ant_noise.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/ant_landscape/ant_noise.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2017-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 21.

The bounded comparison with SmartModeling 1.3.107 found 44 exact function AST matches across these three files, including identifiers and docstrings, excluding source positions, and requiring at least 30 AST nodes. No complete file was byte-identical or identical after line-ending normalization.

The original acquired archive/version and the origin of all other code have not been established. The comparison-source version is not a verified bundled-version claim. This notice preserves observed upstream declarations; it does not replace full license terms, change existing code or headers, or establish complete attribution, license/source-offer compliance or sales clearance.
