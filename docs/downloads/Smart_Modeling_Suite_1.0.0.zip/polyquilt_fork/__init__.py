from __future__ import annotations

import sys as _smarttools_sys


def _smarttools_purge_polyquilt_modules():
    """Drop stale nested PolyQuilt modules before loading this wrapper.

    Blender can reinstall extensions in the same Python process. The old
    PolyQuilt q_mesh package may remain in sys.modules without the compatibility
    aliases added by Smart Modeling, causing import-time failures such as
    "cannot import name 'q_mesh'". Purging only this wrapper's nested modules
    forces a clean import while leaving the wrapper module itself intact.
    """
    prefix = f"{__package__}.poly_quilt_fork"
    for name in list(_smarttools_sys.modules):
        if name == prefix or name.startswith(prefix + "."):
            _smarttools_sys.modules.pop(name, None)


_smarttools_purge_polyquilt_modules()

from .poly_quilt_fork import *  # noqa: F401,F403
from .poly_quilt_fork import __name__ as _SMARTTOOLS_ENTRY_NAME
from .poly_quilt_fork import register as _smarttools_entry_register
from .poly_quilt_fork import unregister as _smarttools_entry_unregister
import importlib as _smarttools_importlib

_smarttools_entry_module = _smarttools_importlib.import_module('.poly_quilt_fork', __package__)
bl_info = getattr(_smarttools_entry_module, 'bl_info', {
    'name': 'PolyQuilt Fork',
    'author': 'Sakana3, Dan-Gry, modified by JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 0, 0),
    'location': 'Extensions > Install from Disk',
    'description': 'PolyQuilt Fork integrated wrapper for Smart Modeling.',
    'category': '3D View',
})


def register():
    return _smarttools_entry_register()


def unregister():
    return _smarttools_entry_unregister()
