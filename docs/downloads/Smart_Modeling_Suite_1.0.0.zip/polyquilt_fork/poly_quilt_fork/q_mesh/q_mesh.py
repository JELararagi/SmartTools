from operator import invert
import bpy
import bmesh
import math
import copy
import mathutils
import bpy_extras
import collections
from mathutils import *
from .q_snap import q_snap
import numpy as np
from ..utils import pqutil
from ..utils import draw_util
from ..utils.dpi import *
from .element_item import element_item
from .q_mesh_operators import q_mesh_operators
from .q_mesh_highlight import q_mesh_highlight

__all__ = ['q_mesh','SelectStack']
        
class QMesh(q_mesh_operators) :

    def __init__(self , obj , preferences) :
        super().__init__(obj, preferences)
        self.highlight = q_mesh_highlight(self)
        self.invalid = False

    def __del__(self) :
        super().__del__()
        if self.highlight :
            del self.highlight

    def UpdateMesh( self , changeTopology = True , loop_triangles = True,destructive = True ) :
        super().UpdateMesh(changeTopology,loop_triangles,destructive)
        if changeTopology :
            self.highlight.setDirty()

    def CheckValid( self , context ) :
        val = super()._CheckValid(context)
        if val == False or self.invalid :
            self.highlight.setDirty()
            self.reload_obj(context)
            self.invalid = False
        return val

    def UpdateView( self ,context , forced = False ):
        self.highlight.UpdateView(context)

    def PickElement( self , coord , radius : float , ignore = [] , edgering = False , backface_culling = None , elements = ['FACE','EDGE','VERT'] , check_func = None ) -> element_item :
        if 'SELECT' in elements :
            select = set()
            if 'VERT' in self.bm.select_mode :
                select.add('VERT')
                select.add('EDGE')
                select.add('FACE')
            if 'EDGE' in self.bm.select_mode :
                select.add('EDGE')
                select.add('FACE')
            if 'FACE' in self.bm.select_mode :
                select.add('FACE')
            elements = set(elements) & select

        if backface_culling == None :
            backface_culling = self.get_shading(bpy.context).show_backface_culling
        rv3d = bpy.context.region_data
        matrix = rv3d.perspective_matrix

        hitElement = element_item.Empty()

        ignoreFaces =  [ i for i in ignore if isinstance( i , bmesh.types.BMFace ) ]        

        # Hitする頂点を探す
        hitVert = element_item.Empty()
        if 'VERT' in elements :
            ignoreVerts =  [ i for i in ignore if isinstance( i , bmesh.types.BMVert ) ]
            candidateVerts = self.highlight.CollectVerts( coord , radius , ignoreVerts , edgering , backface_culling = backface_culling  )
            for vert in candidateVerts :
                if check_func and not check_func( vert ) :
                    continue

                # 各点からRayを飛ばす
                if q_snap.is_target( vert.hitPosition ) :
                    hitTemp = self.highlight.PickFace( vert.coord , ignoreFaces , backface_culling = False  )
                    if hitTemp.isEmpty :
                        # 何の面にもヒットしないなら採択
                        hitVert = vert
                        break
                    else :
                        if vert.element in hitTemp.element.verts :
                            # ヒットした面に含まれているなら採択
                            hitVert = vert
                            break
                        else :
                            # ヒットしたポイントより後ろなら採択
                            v1 = matrix @ vert.hitPosition
                            v2 = matrix @ hitTemp.hitPosition
                            if v1.z <= v2.z :
                                hitVert = vert
                                break

        # Todo:ヒットするエッジを探す
        hitEdge = element_item.Empty()
        if 'EDGE' in elements :
            ignoreEdges =  [ i for i in ignore if isinstance( i , bmesh.types.BMEdge ) ]
            candidateEdges = self.highlight.CollectEdge( coord , radius , ignoreEdges , backface_culling = backface_culling , edgering= edgering )

            for edge in candidateEdges :
                if check_func and not check_func( edge ) :
                    continue
                if q_snap.is_target( edge.hitPosition ) :                
                    hitTemp = self.highlight.PickFace( edge.coord , ignoreFaces , backface_culling = False )
                    if hitTemp.isEmpty :
                        hitEdge = edge
                        break
                    else:
                        if edge.element in hitTemp.element.edges :
                            # ヒットした面に含まれているなら採択
                            hitEdge = edge
                            break
                        else :
                            # ヒットしたポイントより後ろなら採択
                            v1 = matrix @ edge.hitPosition
                            v2 = matrix @ hitTemp.hitPosition
                            if v1.z <= v2.z :
                                hitEdge = edge
                                break


        if hitVert.isEmpty and hitEdge.isEmpty :
            if 'FACE' in elements :            
                # hitする面を探す
                hitFace = self.highlight.PickFace( coord , ignoreFaces , backface_culling = backface_culling  )
                # 候補頂点/エッジがないなら面を返す
                if hitFace.isNotEmpty :
                    if check_func == None or check_func( hitFace ) :
                        if q_snap.is_target( hitFace.hitPosition ) :                
                            hitElement = hitFace
        elif hitVert.isNotEmpty and hitEdge.isNotEmpty :
            if hitVert.element in hitEdge.element.verts :
                return hitVert
            v1 = matrix @ hitVert.hitPosition.to_4d()
            v2 = matrix @ hitEdge.hitPosition.to_4d()
            if v1.z <= v2.z :
                hitElement = hitVert
            else :
                hitElement = hitEdge
        elif hitVert.isNotEmpty :
            hitElement = hitVert
        elif hitEdge.isNotEmpty :
            hitElement = hitEdge
        
        return hitElement


# Legacy lowercase alias expected by bundled PolyQuilt imports.
# Several PolyQuilt modules import `q_mesh` directly from this module and
# instantiate it as a class. Keep the original public symbol available while
# preserving the Python class name `QMesh`.
q_mesh = QMesh


class SelectStack :
    def __init__(self, context , bm) :
        self.context = context
        self.bm = bm
        self.mesh_select_mode = context.tool_settings.mesh_select_mode[0:3]

    def push( self ) :
        self.mesh_select_mode = self.context.tool_settings.mesh_select_mode[0:3]
        self.vert_selection = [ v.select for v in self.bm.verts ]
        self.face_selection = [ f.select for f in self.bm.faces ]
        self.edge_selection = [ e.select for e in self.bm.edges ]
        self.select_history = self.bm.select_history[:]
        self.mesh_select_mode = self.context.tool_settings.mesh_select_mode[0:3]

    def select_mode( self , vert , edge , face ) :
        self.context.tool_settings.mesh_select_mode = (vert , edge , face)


    def pop( self ) :
        for select , v in zip( self.vert_selection , self.bm.verts ) :
            v.select = select
        for select , f in zip( self.face_selection , self.bm.faces ) :
            f.select = select
        for select , e in zip( self.edge_selection , self.bm.edges ) :
            e.select = select

        self.bm.select_history = self.select_history

        del self.vert_selection
        del self.face_selection
        del self.edge_selection

        self.context.tool_settings.mesh_select_mode = self.mesh_select_mode
