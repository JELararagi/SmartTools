try:
    from .q_mesh import q_mesh, QMesh, SelectStack
except ImportError:
    # Older cached module objects may expose only the class name after an
    # in-place extension reinstall. Fall back to the class and re-export the
    # legacy lowercase name expected by bundled PolyQuilt modules.
    from .q_mesh import QMesh, SelectStack
    q_mesh = QMesh

try:
    from .q_snap import q_snap, QSnap
except ImportError:
    from .q_snap import QSnap
    q_snap = QSnap

try:
    from .element_item import element_item, ElementItem
except ImportError:
    from .element_item import ElementItem
    element_item = ElementItem

# PolyQuilt modules use ``from ..q_mesh import *`` and then refer to the
# historical CamelCase classes directly. Keep both the lowercase compatibility
# aliases and the class names exported so package-level star imports work in
# Blender's extension namespace and after in-place reinstalls.
__all__ = [
    'q_mesh', 'QMesh', 'SelectStack',
    'q_snap', 'QSnap',
    'element_item', 'ElementItem',
]
