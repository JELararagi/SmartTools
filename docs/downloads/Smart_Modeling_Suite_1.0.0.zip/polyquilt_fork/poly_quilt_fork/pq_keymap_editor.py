import os
import bpy
from bpy.types import WorkSpaceTool , Panel
from bpy.utils.toolsystem import ToolDef
from .pq_icon import *
import inspect
import rna_keymap_ui
from ... import preferences


def _pq_prefs(context=None):
    try:
        from .pq_preferences import PolyQuiltPreferences
    except Exception:
        PolyQuiltPreferences = None
    return preferences.get_preferences(context or bpy.context, __package__, PolyQuiltPreferences)

def _safe_kmi_properties(_item):
    return None

def draw_tool_keymap(operator, layout, keyconfing, keymapname):
    # Manual-keymap policy: do not display or mutate live Preferences > Keymap
    # items from the embedded PolyQuilt UI.  Smart Modeling Suite exposes the
    # copyable operator IDs at the bottom of the PolyQuilt section instead.
    del keyconfing
    col = layout.column(align=True)
    col.label(text="Manual Keymap Registration")
    col.label(text="Keymap: " + str(keymapname or ""))
    col.label(text="Operator ID: " + str(operator or ""))

def draw_tool_keymap_ui( operator , context , _layout , text , tool) :

    preferences = _pq_prefs(context)
    header, body = _layout.box().panel_prop(preferences, "keymap_setting_expanded")
    header.label(text=text + " Setting")

    if body is not None:
        draw_tool_keymap( operator , body.column(), None,"3D View Tool: Edit Mesh, " + tool.bl_label )
