# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""PolyQuilt preference data and the existing manual-shortcut interface.

Only the documented RNA surface is declared here; package updates and
automatic shortcut registration are intentionally outside this component.
"""

from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty
from bpy.types import PropertyGroup

__all__ = ["PolyQuiltPreferences"]


# Each tuple describes a public RNA field: identifier, constructor family,
# and the values observable by Blender and the existing PolyQuilt UI.
_COLOR_FIELDS = (
    ("highlight_color", "HighlightColor", "HighlightColor", (1.0, 1.0, 0.2, 1.0)),
    ("makepoly_color", "MakePolyColor", "MakePoly Color", (0.4, 0.7, 0.9, 1.0)),
    ("split_color", "SplitColor", "Split Color", (0.1, 1.0, 0.25, 1.0)),
    ("threshold", "DeleteColor", "Delete Color", (1.0, 0.1, 0.1, 1.0)),
    ("delete_color", "DeleteColor", "Delete Color", (1.0, 0.1, 0.1, 1.0)),
)

_NUMBER_FIELDS = (
    ("distance_to_highlight", "distance_to_highlight", "distance_to_highlight", 2.5, 1.0, 10.0),
    ("highlight_vertex_size", "Highlight Vertex Size", "Highlight Vertex Size", 6.0, 0.5, 16.0),
    ("highlight_line_width", "Highlight Line Width", "Highlight Line Width", 1.0, 0.1, 3.0),
    ("highlight_face_alpha", "Highlight Face Alpha", "Highlight Face Alpha", 0.2, 0.1, 1.0),
    ("longpress_time", "LongPressTime", "Long press Time", 0.4, 0.2, 1.0),
    ("marker_size", "Marker Size", "Marker Size", 1.0, 0.1, 5.0),
    ("brush_size", "Brush Size", "Brush Size", 50.0, 5.0, 200.0),
    ("brush_strength", "Brush Strength", "Brush Strength", 0.5, 0.0, 1.0),
    ("line_segment_length", "Line segment length", "Line segment length", 0.1, 0.01, 5.0),
    ("vertex_dissolve_angle", "Vertex Dessolve Angle", "Vertex Dessolve Angle", 120.0, 0.0, 180.0),
)

_BOOLEAN_FIELDS = (
    ("extra_setting_expanded", "Extra", "Extra", False),
    ("is_debug", "is Debug", "is Debug", False),
    ("fix_to_x_zero", "fix_to_x_zero", "Fix X=0", False),
    ("keymap_setting_expanded", "Keymap", "Keymap", False),
)

_DRAG_ACTIONS = (
    ("NONE", "None", ""),
    ("ORBIT", "Orbit", ""),
    ("PAN", "Pan", ""),
    ("DOLLY", "Dolly", ""),
    ("KNIFE", "Knife", ""),
    ("SELECT_BOX", "Select Box", ""),
    ("SELECT_LASSO", "Select Lasso", ""),
)

_TOOL_GROUPS = (
    ("PolyQuilt", "Master", ""),
    ("PolyQuilt:Poly", "Lowpoly", ""),
    ("PolyQuilt:Extrude", "Extrude", ""),
    ("PolyQuilt:LoopCut", "LoopCut", ""),
    ("PolyQuilt:Knife", "Knife", ""),
    ("PolyQuilt:Delete", "Delete", ""),
    ("PolyQuilt:Brush", "Brush", ""),
)

# Keep the original public identifier order, including the historically named
# "threshold" color field. Existing files may persist any of these values.
_FIELD_ORDER = (
    "highlight_color", "makepoly_color", "split_color", "threshold", "delete_color",
    "distance_to_highlight", "highlight_vertex_size", "highlight_line_width",
    "highlight_face_alpha", "longpress_time", "marker_size",
    "extra_setting_expanded", "is_debug", "loopcut_division",
    "brush_size", "brush_strength", "line_segment_length", "fix_to_x_zero",
    "space_drag_op", "vertex_dissolve_angle", "keymap_setting_expanded", "keymap_category",
)


def _properties_by_identifier():
    """Construct registrations from one shared public declaration table."""
    definitions = {}
    for identifier, title, help_text, rgba in _COLOR_FIELDS:
        definitions[identifier] = FloatVectorProperty(
            name=title, description=help_text, default=rgba,
            min=0.0, max=1.0, size=4, subtype="COLOR",
        )
    for identifier, title, help_text, initial, minimum, maximum in _NUMBER_FIELDS:
        definitions[identifier] = FloatProperty(
            name=title, description=help_text, default=initial,
            min=minimum, max=maximum,
        )
    for identifier, title, help_text, initial in _BOOLEAN_FIELDS:
        definitions[identifier] = BoolProperty(
            name=title, description=help_text, default=initial,
        )
    definitions["loopcut_division"] = IntProperty(
        name="LoopCut DIVISON", description="LoopCut Division", min=0, max=16, default=0,
    )
    definitions["space_drag_op"] = EnumProperty(
        name="Space Drag Operation", description="Space Drag Operation",
        items=_DRAG_ACTIONS, default="NONE",
    )
    definitions["keymap_category"] = EnumProperty(
        name="Category", description="Preferences Category",
        items=_TOOL_GROUPS, default="PolyQuilt",
    )
    if set(definitions) != set(_FIELD_ORDER):
        raise RuntimeError("PolyQuilt preference declaration mismatch")
    return {identifier: definitions[identifier] for identifier in _FIELD_ORDER}


# The layout descriptors below preserve the established UI presentation order.
_TOOL_CONTROLS = (
    ("Long Press Time", None, "longpress_time", "Time"),
    ("Distance to Highlight", None, "distance_to_highlight", "Distance"),
    ("Highlight Vertex Size", "VERTEXSEL", "highlight_vertex_size", "Size"),
    ("Highlight Line Width", "EDGESEL", "highlight_line_width", "Width"),
    ("Highlight Face Alpha", "FACESEL", "highlight_face_alpha", "Alpha"),
    ("Marker Size", None, "marker_size", "Size"),
    ("Space Drag Operation", None, "space_drag_op", ""),
)

_SWATCH_CONTROLS = (
    ("highlight_color", "HighlightColor"),
    ("makepoly_color", "MakePolyColor"),
    ("split_color", "SplitColor"),
    ("delete_color", "DeleteColor"),
)

_MANUAL_OPERATOR_IDS = (
    "mesh.poly_quilt", "mesh.poly_quilt_retopo", "none.poly_quilt_daemon",
)


class PolyQuiltPreferences(PropertyGroup):
    bl_idname = __package__

    def draw(self, context):
        page = self.layout

        settings = page.row()
        settings.label(text="Tool settings:", icon="TOOL_SETTINGS")
        fields = settings.box().column()
        for caption, glyph, identifier, field_caption in _TOOL_CONTROLS:
            line = fields.row()
            if glyph is None:
                line.label(text=caption)
            else:
                line.label(text=caption, icon=glyph)
            line.prop(self, identifier, text=field_caption)

        palette = page.row()
        palette.column().label(text="Color settings:", icon="COLOR")
        colors = palette.box().column()
        for identifier, caption in _SWATCH_CONTROLS:
            colors.row().prop(self, identifier, text=caption)

        page.prop(
            self, "keymap_setting_expanded", text="Keymap setting",
            icon="TRIA_DOWN" if self.keymap_setting_expanded else "TRIA_RIGHT",
        )
        if self.keymap_setting_expanded:
            collection = page.column()
            collection.row().prop(self, "keymap_category", expand=True)
            guide = collection.box().column(align=True)
            guide.label(text="Manual Keymap Registration")
            guide.label(text="Keymap: 3D View Tool: Edit Mesh, " + self.keymap_category)
            for identifier in _MANUAL_OPERATOR_IDS:
                guide.label(text="Operator ID: " + identifier)
            from ...core import _sms_draw_manual_setup_guidance
            _sms_draw_manual_setup_guidance(guide, context, "polyquilt_fork")

        page.prop(
            self, "extra_setting_expanded", text="Extra Settings",
            icon="TRIA_DOWN" if self.extra_setting_expanded else "TRIA_RIGHT",
        )
        if self.extra_setting_expanded:
            details = page.column()
            details.scale_y = 1
            details.label(text="Automatic keymap setup is disabled. Register shortcuts manually from the IDs shown in Smart Modeling settings.")
            page.row().prop(self, "is_debug", text="Debug")


PolyQuiltPreferences.__annotations__ = _properties_by_identifier()
