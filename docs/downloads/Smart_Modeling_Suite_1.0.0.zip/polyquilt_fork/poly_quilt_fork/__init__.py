import bpy
from bpy.utils.toolsystem import ToolDef
from . import pq_operator_add_empty_object
from . import gizmo_preselect
from .pq_operator import *
from .pq_icon import *
from .pq_tool import PolyQuiltTools
from .pq_tool_ui import (
    VIEW3D_PT_tools_polyquilt_options,
    VIEW3D_PT_tools_polyquilt_gpencil,
)
from .pq_preferences import *
from .translation import pq_translation_dict

classes = (
    MESH_OT_poly_quilt,
    MESH_OT_poly_quilt_retopo,
    MESH_OT_poly_quilt_daemon,
    PolyQuiltPreferences,
    VIEW3D_PT_tools_polyquilt_options,
    VIEW3D_PT_tools_polyquilt_gpencil,
    pq_operator_add_empty_object.MESH_OT_PolyQuilt_Gpenci_Tools,
    pq_operator_add_empty_object.MESH_OT_GPencil_2_Edge,
    pq_operator_add_empty_object.OBJECT_OT_add_object,
) + tuple(getattr(gizmo_preselect, 'all_gizmos', ()))




def _cleanup_polyquilt_tool_keymaps():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        kc = getattr(getattr(wm, 'keyconfigs', None), 'addon', None) if wm is not None else None
        keymaps = getattr(kc, 'keymaps', None) if kc is not None else None
        if keymaps is None:
            return
        for km in list(keymaps):
            name = str(getattr(km, 'name', '') or '')
            if not name.startswith('3D View Tool: Edit Mesh, PolyQuilt'):
                continue
            try:
                for kmi in list(getattr(km, 'keymap_items', ()) or ()):  # remove legacy auto entries
                    try:
                        km.keymap_items.remove(kmi)
                    except Exception:
                        pass
                keymaps.remove(km)
            except Exception:
                pass
    except Exception:
        pass

def _safe_tool_register(tool):
    try:
        bpy.utils.register_tool(tool['tool'], after=tool.get('after'), group=tool.get('group'))
    except Exception:
        pass


def _safe_tool_unregister(tool):
    try:
        bpy.utils.unregister_tool(tool['tool'])
    except Exception:
        pass


def register():
    try:
        bpy.app.translations.register(__name__, pq_translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, pq_translation_dict)
        except Exception:
            pass
    register_icons()

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass

    try:
        bpy.types.VIEW3D_MT_mesh_add.remove(pq_operator_add_empty_object.add_object_button)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_mesh_add.append(pq_operator_add_empty_object.add_object_button)
    except Exception:
        pass

    # Preferences RNA must exist before the gizmo draw context becomes read-only.
    from ... import preferences as suite_preferences
    suite_preferences.get_preferences(bpy.context, __package__, PolyQuiltPreferences)

    for tool in PolyQuiltTools:
        _safe_tool_register(tool)
    _cleanup_polyquilt_tool_keymaps()


def unregister():
    for tool in PolyQuiltTools:
        _safe_tool_unregister(tool)
    _cleanup_polyquilt_tool_keymaps()

    try:
        bpy.types.VIEW3D_MT_mesh_add.remove(pq_operator_add_empty_object.add_object_button)
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    unregister_icons()
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

if __name__ == "__main__":
    register()
