import bpy
import math
import mathutils
import bmesh
import bpy_extras
import collections
import copy
from ..utils import pqutil
from ..utils import draw_util
from ..q_mesh import *
from ..utils.mouse_event_util import ButtonEventUtil, MBEventType
from .subtool import *
from .subtool_makepoly import *
from .subtool_knife import *
from .subtool_edgeloop_cut import *
from .subtool_edgeloop_dissolve import *
from .subtool_edge_extrude import *
from .subtool_vert_extrude import *
from .subtool_face_extrude import *
from .subtool_face_insert import *
from .subtool_move import *
from .subtool_fin_slice import *
from .subtool_polypen import *

class MainToolDefault(MainTool) :
    name = "Master Tool"

    def __init__(self,op,currentTarget, button) :
        super().__init__(op,currentTarget, button)        

    def LMBEventCallback(self , event ):
        self.debugStr = str(event.type)

        if event.type == MBEventType.Release :
            self.isExit = True

        elif event.type == MBEventType.Click :
            if self.currentTarget.isVert or self.currentTarget.isEmpty or self.currentTarget.isEdge:
                self.SetSubTool( SubToolMakePoly(self.operator,self.currentTarget , self.buttonType ) )

        elif event.type == MBEventType.LongClick :
            if self.currentTarget.isVert :
                self.bmo.dissolve_vert( self.currentTarget.element , False , False , dissolve_vert_angle=self.preferences.vertex_dissolve_angle  )
            elif self.currentTarget.isEdge :
                self.bmo.dissolve_edge( self.currentTarget.element , use_verts = False , use_face_split = False , dissolve_vert_angle=self.preferences.vertex_dissolve_angle )
            elif self.currentTarget.isFace :
                self.bmo.Remove( self.currentTarget.element )
            self.bmo.UpdateMesh()
            self.currentTarget = ElementItem.Empty()

        elif event.type == MBEventType.LongPressDrag :
            if self.currentTarget.isEdge :
                tools = []
                if SubToolPolyPen.Check( self ,self.currentTarget) : 
                    tools.append(SubToolPolyPen(self.operator,self.currentTarget))
                else :
                    if len(self.currentTarget.element.link_faces) > 0 :
                        tools.append(SubToolEdgeLoopCut(self.operator,self.currentTarget, self.buttonType ))
                    if SubToolEdgeloopDissolve.Check( self ,self.currentTarget) : 
                        tools.append(SubToolEdgeloopDissolve(self.operator,self.currentTarget))
                    if SubToolEdgeExtrude.Check( self ,self.currentTarget) : 
                        tools.append(SubToolEdgeExtrude(self.operator,self.currentTarget,False))
                self.SetSubTool( tools )
            elif self.currentTarget.isVert :
                tools = []
                tools.append(SubToolFinSlice(self.operator,self.currentTarget ))
                if SubToolFaceInsert.Check( self ,self.currentTarget ) :
                    tools.append(SubToolFaceInsert(self.operator,self.currentTarget ))
                if SubToolVertExtrude.Check( self ,self.currentTarget ) :
                    tools.append(SubToolVertExtrude(self.operator,self.currentTarget))
                self.SetSubTool( tools )
            elif self.currentTarget.isFace :
                if not QSnap.is_active() :
                    tools = []
                    tools.append(SubToolFaceExtrude(self.operator,self.currentTarget , self.mouse_pos ))
                    self.SetSubTool( tools )
            elif self.currentTarget.isEmpty :
                self.SetSubTool( SubToolKnife(self.operator,self.currentTarget , self.LMBEvent.PressPos ) )   

        elif event.type == MBEventType.Drag :
            if self.currentTarget.isEdge :
                if self.currentTarget.can_extrude() :
                    self.SetSubTool( SubToolEdgeExtrude(self.operator,self.currentTarget , False ) )
                else :
                    self.SetSubTool( SubToolMove(self.operator,self.currentTarget , self.mouse_pos ) )
            elif self.currentTarget.isNotEmpty :
                self.SetSubTool( SubToolMove(self.operator,self.currentTarget , self.mouse_pos ) )
            else :
                self.isExit = self.do_empty_space(event)


    @classmethod
    def DrawHighlight( cls , gizmo , element ) :
        if element != None and gizmo.bmo != None :
            funcs = []
            funcs.append( element.DrawFunc( gizmo.bmo.obj , gizmo.preferences.highlight_color , gizmo.preferences , True ) )

#            if not QSnap.is_active() :
#                if element.isFace :
#                    funcs.append( element.draw_face_center_marker_func( gizmo.preferences.highlight_color , element.is_hit_center() , element.is_hit_center() ) )

            return funcs
        return None

    def OnDraw( self , context  ) :
        if self.LMBEvent.isPresure :
            if self.currentTarget.isNotEmpty :
                self.LMBEvent.Draw( self.currentTarget.coord )
            else:
                self.LMBEvent.Draw( None )

    def OnDraw3D( self , context  ) :
        if self.currentTarget.isNotEmpty :
            color = self.color_highlight()
            if self.LMBEvent.is_hold :
                color = self.color_delete()
            self.currentTarget.Draw( self.bmo.obj , color , self.preferences )

    def OnExit( self ) :
        pass
