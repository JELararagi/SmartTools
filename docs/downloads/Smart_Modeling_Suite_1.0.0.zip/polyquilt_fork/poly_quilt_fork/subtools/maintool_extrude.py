import bpy
import math
import mathutils
import bmesh
import bpy_extras
import collections
import copy
from ..utils import pqutil
from ..utils import draw_util
from ..q_mesh import *
from ..utils.mouse_event_util import ButtonEventUtil, MBEventType
from .subtool import *
from .subtool_makepoly import *
from .subtool_knife import *
from .subtool_edgeloop_cut import *
from .subtool_edge_extrude import *
from .subtool_vert_extrude import *
from .subtool_move import *
from .subtool_fin_slice import *
from .subtool_polypen import *

class MainToolExtrude(MainTool) :
    name = "Edge Extrude"

    def __init__(self,op,currentTarget, button) :
        super().__init__(op,currentTarget, button , no_hold = True )        

    def LMBEventCallback(self , event ):
        self.debugStr = str(event.type)

        if event.type == MBEventType.Release :
            self.isExit = True

        elif event.type == MBEventType.Click or event.type == MBEventType.LongClick :
            if self.currentTarget.isVert or self.currentTarget.isEmpty or self.currentTarget.isEdge:
                self.SetSubTool( SubToolMakePoly(self.operator,self.currentTarget , self.buttonType ) )

        elif event.type == MBEventType.Drag or event.type == MBEventType.LongPressDrag :
            if self.currentTarget.isEdge :
                self.SetSubTool( SubToolEdgeExtrude(self.operator,self.currentTarget,False)) 
            elif self.currentTarget.isVert :
                self.SetSubTool( SubToolVertExtrude(self.operator,self.currentTarget)) 

    @classmethod
    def DrawHighlight( cls , gizmo , element ) :
        if element != None and gizmo.bmo != None :
            return element.DrawFunc( gizmo.bmo.obj , gizmo.preferences.highlight_color , gizmo.preferences , marker = True )
        return None

    @staticmethod
    def pick_element( qmesh , location , preferences ) :
        element = qmesh.PickElement( location , preferences.distance_to_highlight, edgering = True, elements = ['EDGE','VERT'] )        
#       element.set_snap_div( preferences.loopcut_division )
        return element

    def OnDraw( self , context  ) :
        pass

    def OnDraw3D( self , context  ) :
        self.currentTarget.Draw( self.bmo.obj , self.color_highlight() , self.preferences )

    def OnExit( self ) :
        pass
