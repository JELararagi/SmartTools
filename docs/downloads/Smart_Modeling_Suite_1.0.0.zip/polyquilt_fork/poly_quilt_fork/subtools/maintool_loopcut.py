import bpy
import math
import mathutils
import bmesh
import bpy_extras
import collections
import copy
from ..utils import pqutil
from ..utils import draw_util
from ..q_mesh import *
from ..utils.mouse_event_util import ButtonEventUtil, MBEventType
from .subtool import *
from .subtool_makepoly import *
from .subtool_knife import *
from .subtool_edgeloop_cut import *
from .subtool_edgeloop_dissolve import *
from .subtool_edge_extrude import *
from .subtool_vert_extrude import *
from .subtool_move import *
from .subtool_fin_slice import *
from .subtool_polypen import *

class MainToolLoopCut(MainTool) :
    name = "Loop Cut"

    def __init__(self,op,currentTarget, button) :
        super().__init__(op,currentTarget, button , no_hold = True )        

    def LMBEventCallback(self , event ):
        last_mouse_pos = event.mouse_pos
        self.debugStr = str(event.type)

        if event.type == MBEventType.Release :
            self.isExit = True

        elif event.type == MBEventType.Down :
            if SubToolEdgeLoopCut.Check( self , self.currentTarget ):
                self.SetSubTool( SubToolEdgeLoopCut(self.operator,self.currentTarget, self.buttonType ) )

    @classmethod
    def DrawHighlight( cls , gizmo , target ) :
        if SubToolEdgeLoopCut.Check( None , target ) :
            return SubToolEdgeLoopCut.DrawHighlight( gizmo , target )
        return None

    @staticmethod
    def pick_element( qmesh , location , preferences ) :
        element = qmesh.PickElement( location , preferences.distance_to_highlight, edgering = False, elements = ['EDGE'] )        
        element.set_snap_div( preferences.loopcut_division )
        return element

    def OnDraw( self , context  ) :
        pass

    def OnDraw3D( self , context  ) :
        self.currentTarget.Draw( self.bmo.obj , self.color_highlight() , self.preferences )

    def OnExit( self ) :
        pass
