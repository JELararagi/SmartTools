from .maintool_default import MainToolDefault
from .maintool_hold import MainToolHold
from .maintool_brush import *
from .maintool_lowpoly import MainToolLowPoly
from .maintool_knife import MainToolKnife
from .maintool_delete import MainToolDelete
from .maintool_extrude import MainToolExtrude
from .maintool_loopcut import MainToolLoopCut
from .maintool_edgeloop import MainToolEdgeLoop
from .maintool_edgeloop_dissolve import MainToolEdgeLoopDissolve
from .subtool_edgeloop_extrude import SubToolEdgeLoopExtrude
from .subtool_seam import SubToolSeam
from .subtool_seam_loop import SubToolSeamLoop
from .maintool_quad_patch import MainToolQuadPatch

maintools = {
    'NONE'              : None ,
    'MASTER'            : MainToolDefault ,
#   'HOLD'              : MainToolHold ,
    'LOWPOLY'           : MainToolLowPoly ,
    'BRUSH'             : MainToolBrush ,
    'EXTRUDE'           : MainToolExtrude ,
    'KNIFE'             : MainToolKnife ,
    'DELETE'            : MainToolDelete ,
    'EDGELOOP'          : MainToolEdgeLoop ,
    'LOOPCUT'           : MainToolLoopCut ,
    'EDGELOOP_EXTRUDE'  : SubToolEdgeLoopExtrude ,
    'EDGELOOP_DISSOLVE' : MainToolEdgeLoopDissolve ,
    'MARK_SEAM'         : SubToolSeam ,
    'MARK_SEAM_LOOP'    : SubToolSeamLoop ,
    'QUADPATCH'         : MainToolQuadPatch ,
}

def enum_tool_callback(scene, context ):
    return ( ( tool , cls.name if cls else "None" , "" ,"", index  ) for index , (tool,cls) in enumerate(maintools.items()) )