import bpy
import math
import mathutils
import bmesh
import bpy_extras
import collections
import copy
from ..utils import pqutil
from ..utils import draw_util
from ..q_mesh import *
from ..utils.mouse_event_util import ButtonEventUtil, MBEventType
from .subtool import *
from .subtool_knife import *
from .subtool_edgeloop_cut import *
from .subtool_delete import *

class MainToolDelete(MainTool) :
    name = "Delete"

    def __init__(self,op,currentTarget, button) :
        super().__init__(op,currentTarget, button , no_hold = True )        

    def LMBEventCallback(self , event ):
        self.debugStr = str(event.type)

        if event.type == MBEventType.Release :
            self.isExit = True
        elif event.type == MBEventType.Down or event.type == MBEventType.Click or event.type == MBEventType.LongClick:
            self.SetSubTool(SubToolDelete( self , self.currentTarget))
        elif event.type == MBEventType.Drag or event.type == MBEventType.LongPressDrag :
            self.SetSubTool(SubToolDelete( self , self.currentTarget))

    @classmethod
    def DrawHighlight( cls , gizmo , element ) :
        return SubToolDelete.DrawHighlight( gizmo , element )

    def OnDraw( self , context  ) :
        pass

    def OnDraw3D( self , context  ) :
        if self.currentTarget.isNotEmpty :
            self.currentTarget.Draw( self.bmo.obj , self.preferences.delete_color  , self.preferences , edge_pivot = False )

    def OnExit( self ) :
        pass

    @classmethod
    def GetCursor(cls) :
        return 'ERASER'

    @staticmethod
    def pick_element( qmesh , location , preferences ) :
        element = qmesh.PickElement( location , preferences.distance_to_highlight )        
        return element
