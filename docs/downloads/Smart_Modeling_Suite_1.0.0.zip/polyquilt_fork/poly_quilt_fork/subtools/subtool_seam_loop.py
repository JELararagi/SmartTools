import sys
import bpy
import math
import mathutils
import bmesh
import copy
import bpy_extras
import collections
from ..utils import pqutil
from ..utils import draw_util
from ..q_mesh import *
from .subtool import MainTool
from ..utils.dpi import *
from .subtool_seam import SubToolSeam

class SubToolSeamLoop(SubToolSeam) :
    name = "Mark Seam Loop"

    @staticmethod
    def Check( root , target ) :
        return target.isEdge

    @staticmethod
    def pick_element( qmesh , location , preferences ) :
        element = qmesh.PickElement( location , preferences.distance_to_highlight , elements = ["EDGE"] )        
        return element

    def OnUpdate( self , context , event ) :
        if event.type == 'MOUSEMOVE':
            preTarget = self.currentTarget
            self.currentTarget = self.bmo.PickElement( self.mouse_pos , self.preferences.distance_to_highlight , elements = ["VERT","EDGE"]  )
            if self.currentTarget.isEdge :
                e = self.find_seam_loop( self.bmo , self.currentTarget.element )
                self.removes = (e,[])
                self.startTarget = self.currentTarget
            else :
                self.removes = ([self.currentTarget.element],[])
        elif event.type == self.buttonType : 
            if event.value == 'RELEASE' :
                if self.currentTarget.isEdge :
                    e = self.find_seam_loop( self.bmo , self.currentTarget.element )
                    self.removes = (e,[])
                    self.startTarget = self.currentTarget
                else :
                    self.removes = ([self.currentTarget.element],[])
                self.SeamElement(self.currentTarget )
                return 'FINISHED'
        elif event.type == 'RIGHTMOUSE': 
            if event.value == 'RELEASE' :
                return 'FINISHED'
        return 'RUNNING_MODAL'

    @classmethod
    def DrawHighlight( cls , gizmo , element ) :
        if element.isEdge and gizmo.bmo != None :
            edges = cls.find_seam_loop( gizmo.bmo , element.element )
            if edges :
                alpha = 1
                vertex_size = gizmo.preferences.highlight_vertex_size        
                width = 1.65
                if not element.element.seam :
                    color = bpy.context.preferences.themes["Default"].view_3d.edge_seam
                    color = (color[0],color[1],color[2],1)
                else :
                    color = ( 0, 0 , 0 ,1)
        
                mirrors = []
                if gizmo.bmo.is_mirror_mode :
                    mirrors = [ gizmo.bmo.find_mirror(m) for m in edges ]
                    mirrors = [ m for m in mirrors if m ]
                funcs = []
                funcs.append(draw_util.drawElementsHilight3DFunc( gizmo.bmo.obj , gizmo.bmo.bm, edges , vertex_size , width , alpha , color ))
                if mirrors :
                    funcs.append( draw_util.drawElementsHilight3DFunc( gizmo.bmo.obj  , gizmo.bmo.bm, mirrors , vertex_size , width , alpha * 0.5 , color ))
                return funcs
        return None
