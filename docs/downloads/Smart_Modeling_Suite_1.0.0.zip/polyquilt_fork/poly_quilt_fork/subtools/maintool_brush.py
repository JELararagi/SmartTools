import bpy
import math
import mathutils
import bmesh
import bpy_extras
import collections
import copy
from ..utils import pqutil
from ..utils import draw_util
from ..utils.dpi import *
from ..q_mesh import *
from ..utils.mouse_event_util import ButtonEventUtil, MBEventType
from .subtool import *
from .subtool_brush_relax import *
from .subtool_brush_size import *
from .subtool_brush_move import *
from .subtool_brush_delete import *
from .subtool_move import *
from .subtool_autoquad import *
from ..utils.dpi import *



def _pq_operator_property_names(props):
    try:
        prop_map = getattr(getattr(props, "bl_rna", None), "properties", None)
        keys = getattr(prop_map, "keys", None)
        if callable(keys):
            return {str(k) for k in keys()}
    except Exception:
        pass
    return set()


def _pq_has_operator_property(props, name):
    return str(name) in _pq_operator_property_names(props)


def _pq_get_operator_property(props, name, default=None):
    if not _pq_has_operator_property(props, name):
        return default
    try:
        return props[str(name)]
    except Exception:
        try:
            return getattr(props, str(name))
        except Exception:
            return default


def _pq_is_property_set(props, name):
    if not _pq_has_operator_property(props, name):
        return False
    try:
        return bool(props.is_property_set(str(name)))
    except Exception:
        return False


class MainToolBrush(MainTool) :
    name = "Brush"

    def __init__(self,op,currentTarget, button) :
        super().__init__(op,currentTarget, button)        
        brush_tbl = {
            'SMOOTH' : SubToolBrushRelax ,
            'MOVE' : SubToolBrushMove ,
            'DELETE' : SubToolBrushDelete ,
        }

        brush = op.brush_type
        self.brush_type = brush_tbl[ brush ]

        self.callback = { 
            MBEventType.Release         : [] ,
            MBEventType.Click           : [SubToolAutoQuad] ,
            MBEventType.LongClick       : [] ,
            MBEventType.LongPressDrag   : [SubToolBrushSize] ,
            MBEventType.Drag            : [self.brush_type] ,
        }

    def LMBEventCallback(self , event ):
        self.debugStr = str(event.type)
        if event.type in self.callback.keys() :
            tools = [ t( event.event , self) for t in self.callback[event.type] if t.Check( self , self.currentTarget ) ]
            if tools :
                self.SetSubTool( tools )
            self.isExit = True

    @classmethod
    def DrawHighlight( cls , gizmo , element ) :
        if SubToolAutoQuad.Check( None , element ) :
            Draw = [SubToolAutoQuad.DrawHighlight(gizmo,element)]
        else :
            Draw = []

        radius = display.dot( gizmo.preferences.brush_size )
        strength = gizmo.preferences.brush_strength
        mode = 'SMOOTH'

        # Do not dereference gizmo.keyitem.properties. KeyMapItem operator
        # properties can be stale after extension reinstall on Blender 5.1.x.
        from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
        tool = ToolSelectPanelHelper.tool_active_from_context(bpy.context)
        props = tool.operator_properties( gizmo.tool.pq_operator )
        mode = _pq_get_operator_property(props, "brush_type", mode)

        if mode == 'MOVE' :
            Draw.append( SubToolBrushMove.DrawHighlight( gizmo , element ) )
        elif mode == 'DELETE' :
            Draw.append( SubToolBrushDelete.DrawHighlight( gizmo , element ) )
        else :
            Draw.append( SubToolBrushRelax.DrawHighlight( gizmo , element ) )

        return Draw

    @classmethod
    def UpdateHighlight( cls , gizmo , element ) :
        return True

    def OnDraw( self , context  ) :
        self.brush_type.Draw( self.preferences , self.mouse_pos )

        self.LMBEvent.Draw( self.mouse_pos )

        if self.LMBEvent.is_hold :
            draw_util.DrawFont( "Strenght = " + '{:.0f}'.format(self.preferences.brush_strength * 100) , 10 , self.mouse_pos , (0,0) )
            draw_util.DrawFont( "Radius = " + '{:.0f}'.format( display.dot(self.preferences.brush_size ) ) , 10 , self.mouse_pos , (0,-8) )

    def OnDraw3D( self , context  ) :
        if not self.LMBEvent.presureComplite :        
            if SubToolAutoQuad.Check( self , self.currentTarget ) :
                draw = SubToolAutoQuad.DrawHighlight(self,self.currentTarget)
                if draw :
                    draw()

    @classmethod
    def GetCursor(cls) :
        return 'CROSSHAIR'

    @classmethod
    def recive_event( cls , gizmo , context , event ) :
        if any( [ event.shift , event.ctrl , event.alt,  event.oskey ] ) :
            if event.type == 'WHEELUPMOUSE' :
                cls.change_brush_size( gizmo.preferences , context ,-50 , 0 )
                return True

            if event.type == 'WHEELDOWNMOUSE' :
                cls.change_brush_size( gizmo.preferences , context , 50 , 0 )
                return True

        return False

    @classmethod
    def change_brush_size( cls , preferences , context , brush_size_value , brush_strong_value ):
        if context.area.type == 'VIEW_3D' :
            a = (preferences.brush_size * preferences.brush_size) / 40000.0 + 0.1
            preferences.brush_size = preferences.brush_size + brush_size_value * a       
            strength = min( max( 0 , preferences.brush_strength + brush_strong_value ) , 1 )
            preferences.brush_strength = strength
            context.area.tag_redraw()
