import bpy
from bpy.types import WorkSpaceTool , Panel
from bpy.utils.toolsystem import ToolDef
from .pq_icon import *
from .pq_tool_ui import *
from .pq_keymap_editor import draw_tool_keymap_ui

class ToolPolyQuiltBase(WorkSpaceTool):
    pq_main_tool = 'MASTER'
    pq_description = 'Master Tool'
    pq_tools = [ "MASTER" ]
    pq_operator = "mesh.poly_quilt"

    bl_space_type='VIEW_3D'
    bl_context_mode='EDIT_MESH'
    bl_widget = "MESH_GGT_PQ_Preselect"

    @classmethod
    def tool_keymaps( cls , main_tools , operator = pq_operator , shift = ["NONE"] , ctrl = ["NONE"] , alt = ["NONE"], ctrl_shift = ["NONE"] ) :
        # Manual-keymap policy: workspace-tool mouse/key bindings must not be
        # installed into Preferences > Keymap automatically.  The relevant
        # operator IDs are shown at the bottom of the PolyQuilt / Key Ops section
        # for manual binding when the user wants them.
        del main_tools, operator, shift, ctrl, alt, ctrl_shift
        return ()

    @classmethod
    def draw_settings( cls ,context, layout, tool):
        reg = context.region.type

#        keyconfigs = context.window_manager.keyconfigs.user      
#        keymap = keyconfigs.keymaps["3D View Tool: Edit Mesh, " + cls.bl_label ]            
#       tools = [ item.properties.tool_mode for item in keymap.keymap_items if item.idname == 'mesh.poly_quilt' and hasattr( item.properties , "tool_mode" ) ]
        tools = cls.pq_tools
        if reg == 'UI' :
            draw_settings_ui( cls.pq_operator , context , layout , tool  , ui = tools)
            draw_tool_keymap_ui( cls.pq_operator , context , layout , cls.pq_description , cls)
        elif reg == 'WINDOW' :
            draw_settings_ui( cls.pq_operator , context , layout , tool  , ui = tools)
            draw_tool_keymap_ui( cls.pq_operator , context , layout , cls.pq_description , cls )
        elif reg == 'TOOL_HEADER' :
            draw_settings_toolheader( cls.pq_operator , context , layout , tool , ui = tools )

class ToolPolyQuilt(ToolPolyQuiltBase):
    pq_main_tool = 'MASTER'
    pq_description = 'Master Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt"
    bl_label = "PolyQuilt"
    bl_description = ( "Lowpoly Tool" )
    bl_icon = "ops.mesh.polybuild_hover"
    bl_widget = "MESH_GGT_PQ_Preselect"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH'], ctrl = ['LOOPCUT'], ctrl_shift=['DELETE'] )

class ToolPolyQuiltPoly(ToolPolyQuiltBase):
    pq_main_tool = 'LOWPOLY'
    pq_description = 'LowPoly Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_poly"
    bl_label = "PolyQuilt:Poly"
    bl_description = ( "Lowpoly Tool" )
    bl_icon = "ops.mesh.polybuild_hover"
    bl_widget = "MESH_GGT_PQ_Lowpoly"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH'] )

class ToolPolyQuiltKnife(ToolPolyQuiltBase):
    pq_main_tool = 'KNIFE'
    pq_description = 'Knife Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_knife"
    bl_label = "PolyQuilt:Knife"
    bl_description = ( "Quick Knife Tool" )
    bl_icon = "ops.mesh.knife_tool"
    bl_widget = "MESH_GGT_PQ_Knife"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH'] )


class ToolPolyQuiltDelete(ToolPolyQuiltBase):
    pq_main_tool = 'DELETE'
    pq_description = 'Delete Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_delete"
    bl_label = "PolyQuilt:Delete"
    bl_description = ( "Quick Delete Tool" )
    bl_icon = "ops.mesh.polybuild_hover"
    bl_widget = "MESH_GGT_PQ_Delete"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH','DELETE'] )

class ToolPolyQuiltExtrude(ToolPolyQuiltBase):
    pq_main_tool = 'EXTRUDE'
    pq_description = 'Extrude Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_extrude"
    bl_label = "PolyQuilt:Extrude"
    bl_description = ( "Edge Extrude Tool" )
    bl_icon = "ops.mesh.extrude_region_move"
    bl_widget = "MESH_GGT_PQ_Extrude"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH'] ) 

class ToolPolyQuiltEdgeLoop(ToolPolyQuiltBase):
    pq_main_tool = 'EDGELOOP'
    pq_description = 'EdgeLoop Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_edgeloop"
    bl_label = "PolyQuilt:EdgeLoop"
    bl_description = ( "Edgeloop Tool" )
    bl_icon = "ops.mesh.loopcut_slide"
    bl_widget = "MESH_GGT_PQ_EdgeLoop"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH'] )

class ToolPolyQuiltQuadPatch(ToolPolyQuiltBase):
    pq_main_tool = 'QUADPATCH'
    pq_description = 'QuadPatch Tool'
    pq_tools = [ "MASTER" , "RETOPO" ]    
    pq_operator = "mesh.poly_quilt_retopo"

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_quad_patch"
    bl_label = "PolyQuilt:QuadPatch"
    bl_description = ( "QuadPatch Tool" )
    bl_icon = "ops.mesh.polybuild_hover"
    bl_widget = "MESH_GGT_PQ_QuadPatch"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , operator = pq_operator , shift = ['BRUSH'] )


class ToolPolyQuiltLoopCut(ToolPolyQuiltBase):
    pq_main_tool = 'LOOPCUT'
    pq_description = 'LoopCut Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_loopcut"
    bl_label = "PolyQuilt:LoopCut"
    bl_description = ( "LoopCut Tool" )
    bl_icon = "ops.mesh.loopcut_slide"
    bl_widget = "MESH_GGT_PQ_LoopCut"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool] , shift = ['BRUSH']) 

class ToolPolyQuiltBrush(ToolPolyQuiltBase):
    pq_main_tool = 'BRUSH'
    pq_description = 'Brush Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_brush"
    bl_label = "PolyQuilt:Brush"
    bl_description = ( "Brush Tool" )
    bl_icon = "ops.mesh.polybuild_hover"
    bl_widget = "MESH_GGT_PQ_Brush"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool], shift = ['BRUSH'] ) 

class ToolPolyQuiltSeam(ToolPolyQuiltBase):
    pq_main_tool = 'MARK_SEAM'
    pq_description = 'Seam Tool'

    # The prefix of the idname should be your add-on name.
    bl_idname = "mesh_tool.poly_quilt_seam"
    bl_label = "PolyQuilt:Seam"
    bl_description = ( "Seam Tool" )
    bl_icon = "ops.mesh.knife_tool"
    bl_widget = "MESH_GGT_PQ_Seam"
    bl_keymap = ToolPolyQuiltBase.tool_keymaps( [pq_main_tool], ctrl = ['MARK_SEAM_LOOP'] ) 

PolyQuiltTools = (
    { 'tool' : ToolPolyQuiltQuadPatch , 'after' : {"builtin.poly_build"} , 'group' : True },
    { 'tool' : ToolPolyQuilt       , 'after' : {"builtin.poly_build"} , 'group' : True },
    { 'tool' : ToolPolyQuiltPoly  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltExtrude  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltEdgeLoop  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltLoopCut  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltKnife  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltDelete  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltBrush  , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
    { 'tool' : ToolPolyQuiltSeam , 'after' : {"mesh_tool.poly_quilt"} , 'group' : False },
)
