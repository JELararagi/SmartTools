import bpy
import os
import bpy.utils.previews

try:
    from ... import icon_runtime as _sms_icon_runtime
except Exception:  # pragma: no cover
    _sms_icon_runtime = None

__all__ = ['register_icons', 'unregister_icons', 'custom_icon']

icons = [
    'icon_geom_vert', 'icon_geom_edge', 'icon_geom_triangle', 'icon_geom_quad', 'icon_geom_polygon',
    'icon_move_free', 'icon_move_x', 'icon_move_y', 'icon_move_z', 'icon_move_normal', 'icon_move_tangent',
    'icon_opt_backcull', 'icon_opt_mirror', 'icon_opt_x0',
    'icon_brush_move', 'icon_brush_relax', 'icon_brush_delete',
]

custom_icons = None


def register_icons():
    global custom_icons
    if custom_icons is not None:
        unregister_icons()
    custom_icons = bpy.utils.previews.new()
    my_icons_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'icons')
    for icon in icons:
        filepath = None
        if _sms_icon_runtime is not None:
            try:
                candidate = _sms_icon_runtime.resolve_icon_path(icon)
                if candidate.is_file():
                    filepath = str(candidate)
            except Exception:
                filepath = None
        if filepath is None:
            candidate = os.path.join(my_icons_dir, icon + '.png')
            if os.path.isfile(candidate):
                filepath = candidate
        if filepath is None:
            continue
        try:
            custom_icons.load(icon, filepath, 'IMAGE')
        except Exception:
            pass



def unregister_icons():
    global custom_icons
    if custom_icons is None:
        return
    try:
        bpy.utils.previews.remove(custom_icons)
    except Exception:
        pass
    custom_icons = None



def custom_icon(name):
    global custom_icons
    try:
        if custom_icons is None:
            return 0
        item = custom_icons.get(name)
        return int(getattr(item, 'icon_id', 0) or 0) if item is not None else 0
    except Exception:
        return 0



def custom_icon_t(name):
    global custom_icons
    try:
        return custom_icons.get(name) if custom_icons is not None else None
    except Exception:
        return None
