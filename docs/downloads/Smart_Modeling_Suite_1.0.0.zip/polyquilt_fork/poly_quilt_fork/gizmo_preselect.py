import bpy
import bmesh
import mathutils
import time
from .q_mesh import *
from .utils import draw_util
from .subtools import *
from .pq_tool import *
from ... import preferences




def _pq_active_view3d_tool(context=None):
    """Return the active VIEW_3D workspace tool for the current mode.

    Blender keeps registered tools and active tools in different places.  Using
    a broad scan of ``context.workspace.tools`` can keep PolyQuilt's preselect
    gizmo/modal daemon alive after the user has switched back to Blender's
    normal Select Box/Circle/Lasso tools.  When that happens the PolyQuilt edge
    preselect path can consume drag-selection events, which makes edge range
    selection appear broken while vertex/face selection still works.
    """
    context = context or bpy.context
    try:
        workspace = getattr(context, 'workspace', None)
        tools = getattr(workspace, 'tools', None) if workspace is not None else None
        if tools is None:
            return None
        mode = str(getattr(context, 'mode', '') or 'EDIT_MESH')
        if callable(getattr(tools, 'from_space_view3d_mode', None)):
            tool = tools.from_space_view3d_mode(mode, create=False)
            if tool is not None:
                try:
                    tool.refresh_from_context()
                except Exception:
                    pass
                return tool
    except Exception:
        pass
    try:
        mode = str(getattr(context, 'mode', '') or '')
        for tool in getattr(getattr(context, 'workspace', None), 'tools', ()):
            try:
                if str(getattr(tool, 'space_type', '') or '') != 'VIEW_3D':
                    continue
            except Exception:
                pass
            try:
                tool_mode = str(getattr(tool, 'mode', '') or '')
                if tool_mode and mode and tool_mode != mode:
                    continue
            except Exception:
                pass
            return tool
    except Exception:
        pass
    return None


def _pq_tool_id(tool):
    try:
        return str(getattr(tool, 'idname', '') or '')
    except Exception:
        return ''


def _pq_tool_widget(tool):
    try:
        return str(getattr(tool, 'widget', '') or '')
    except Exception:
        return ''


def _pq_is_polyquilt_tool_id(tool_id):
    tool_id = str(tool_id or '')
    return tool_id == 'mesh_tool.poly_quilt' or tool_id.startswith('mesh_tool.poly_quilt_')


def _pq_is_any_polyquilt_active_tool(context=None):
    return _pq_is_polyquilt_tool_id(_pq_tool_id(_pq_active_view3d_tool(context)))


def _pq_active_tool_matches_widget(context, widget_id):
    active = _pq_active_view3d_tool(context)
    if active is None:
        return False
    return _pq_tool_widget(active) == str(widget_id or '')


def _pq_active_tool_matches_class(context, tool_cls):
    active = _pq_active_view3d_tool(context)
    if active is None:
        return False
    try:
        return _pq_tool_id(active) == str(getattr(tool_cls, 'bl_idname', '') or '')
    except Exception:
        return False

def _pq_prefs(context=None):
    try:
        from .pq_preferences import PolyQuiltPreferences
    except Exception:
        PolyQuiltPreferences = None
    return preferences.get_preferences(context or bpy.context, __package__, PolyQuiltPreferences)

def _pq_operator_property_names(props):
    try:
        prop_map = getattr(getattr(props, "bl_rna", None), "properties", None)
        keys = getattr(prop_map, "keys", None)
        if callable(keys):
            return {str(k) for k in keys()}
    except Exception:
        pass
    return set()


def _pq_has_operator_property(props, name):
    return str(name) in _pq_operator_property_names(props)


def _pq_get_operator_property(props, name, default=None):
    if not _pq_has_operator_property(props, name):
        return default
    try:
        return props[str(name)]
    except Exception:
        try:
            return getattr(props, str(name))
        except Exception:
            return default


def _pq_is_property_set(props, name):
    if not _pq_has_operator_property(props, name):
        return False
    try:
        return bool(props.is_property_set(str(name)))
    except Exception:
        return False

class PQ_Gizmo_Preselect( bpy.types.Gizmo):
    bl_idname = "MESH_GT_PQ_Preselect"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.bmo = None
        self.currentElement = None
        self.preferences = _pq_prefs(bpy.context)
        self.DrawHighlight = None
        self.region = None
        self.subtool = None
        self.tool_table = [None,None,None,None]
        self.tool = None
        self.invalid = False
        self.temp = bmesh.new()

    def setup(self):
        self.bmo = None        
        self.currentElement = ElementItem.Empty()

    def init( self , context , tool ) :
        self.tool = tool
        self.maintool = maintools[tool.pq_main_tool]
        self.subtool = self.maintool
        self.region = context.region_data
        self.bmo = q_mesh( context.active_object , self.preferences )
        self.keyitem = None
        if self.subtool :
            context.window.cursor_set( self.subtool.GetCursor() )

    def exit( self , context, cancel) :
        print("hoge")
        pass

    @property
    def operator( self ) :
        return self.tool.pq_operator

    def test_select(self, context, location):
        if self.invalid :
            self.bmo.invalid = True
            self.invalid = False

        if PQ_GizmoGroup_Base.running_polyquilt :
            self.DrawHighlight = None
            return -1
        
        if self.currentElement == None :
            self.currentElement = ElementItem.Empty()

        self.mouse_pos = mathutils.Vector(location) 
        if context.region == self.region :
            return -1
        if self.bmo == None :
            self.bmo = q_mesh( context.active_object , self.preferences )
        self.bmo.CheckValid( context )
        self.bmo.UpdateView(context)
        QSnap.update(context)

        if self.subtool != None :
            element = self.subtool.pick_element( self.bmo , location , self.preferences )
            element.set_snap_div( self.preferences.loopcut_division )
            if self.subtool.UpdateHighlight( self , element ) :
                context.area.tag_redraw()
        else :
            element = ElementItem.Empty()

        self.currentElement = element

        if self.subtool != None :
            self.DrawHighlight = self.subtool.DrawHighlight( self , self.currentElement )
        else :
            self.DrawHighlight = None

        return -1

    def draw(self, context):
        if PQ_GizmoGroup_Base.running_polyquilt  :
            self.DrawHighlight = None

        if self.DrawHighlight != None :
            if type(self.DrawHighlight) == list :
                for drawHighlight in self.DrawHighlight :
                    drawHighlight()
            else :
                self.DrawHighlight()

    def refresh( self , context ) :
        if self.bmo != None :
            self.invalid = True
            self.currentElement = ElementItem.Empty()
            self.DrawHighlight = None

    def recive_event( self , context , event ) :
        if not _pq_active_tool_matches_class(context, self.tool):
            return False
        subtool = self.maintool

        self.keyitem = self.get_keyitem( event.shift , event.ctrl , event.alt,  event.oskey )
        # Do not dereference self.keyitem.properties. On Blender 5.1.0 Windows,
        # stale KeyMapItem operator properties can crash native RNA before Python
        # can catch an exception. Tool properties remain available from workspace tools.

        if self.subtool != subtool :
            self.subtool = subtool
            if context.area :
                context.area.tag_redraw()
        if self.subtool :
            PQ_GizmoGroup_Base.set_cursor( subtool.GetCursor() )
        else :
            PQ_GizmoGroup_Base.set_cursor( )

        if context.region_data == self.region and self.subtool:
            return self.subtool.recive_event( self , context , event )
        return False

    def get_keyitem( self , shift , ctrl , alt,  oskey ) :
        try:
            keymaps = bpy.context.window_manager.keyconfigs.user.keymaps
            keymap = keymaps.get("3D View Tool: Edit Mesh, " + self.tool.bl_label)
        except Exception:
            keymap = None
        if keymap is None:
            return None
        for item in getattr(keymap, 'keymap_items', ()) :
            if self.operator == item.idname and item.active :
                if [ item.shift , item.ctrl , item.alt,  item.oskey ] == [ shift , ctrl , alt,  oskey ] :
                    return item
        return None

    def invoke( self , context, event) :
        pass

    def get_attr( self , attr ) :
        # Do not read self.keyitem.properties; use the active workspace tool state only.
        tool = _pq_active_view3d_tool(bpy.context)
        if tool is not None and _pq_tool_id(tool) == str(getattr(self.tool, 'bl_idname', '') or ''):
            try:
                props = tool.operator_properties(self.operator)
                return _pq_get_operator_property(props, attr)
            except Exception:
                return None
        return None

class PQ_GizmoGroup_Base(bpy.types.GizmoGroup):
    my_tool = ToolPolyQuiltBase
    bl_idname = "MESH_GGT_PQ_Preselect"
    bl_label = "PolyQuilt Preselect Gizmo"
    bl_options = {'3D'}    
    bl_region_type = 'WINDOW'
    bl_space_type = 'VIEW_3D'
    bl_idname = my_tool.bl_widget
    child_gizmos = []

    cursor = 'DEFAULT'

    running_polyquilt = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.gizmo = None

    def __del__(self) :
        if hasattr( self , "gizmo" ) :
            try:
                PQ_GizmoGroup_Base.child_gizmos.remove( self.gizmo )
            except Exception:
                pass
        if not PQ_GizmoGroup_Base.child_gizmos :
            QSnap.remove_ref()

    @classmethod
    def poll(cls, context):
        if context.mode != 'EDIT_MESH' :
            return False
        if not _pq_active_tool_matches_widget(context, cls.bl_idname):
            try:
                context.window_manager.gizmo_group_type_unlink_delayed(cls.bl_idname)
            except Exception:
                pass
            return False
        if not PQ_GizmoGroup_Base.running_polyquilt :
            context.window.cursor_set( cls.cursor )        
        return True

    def setup(self, context):
        QSnap.add_ref(context)
        self.gizmo = self.gizmos.new(PQ_Gizmo_Preselect.bl_idname)
        self.gizmo.init(context , self.my_tool )
        PQ_GizmoGroup_Base.child_gizmos.append(self.gizmo)

    def refresh( self , context ) :
        if hasattr( self , "gizmo" ) :        
            self.gizmo.refresh(context)

    @classmethod
    def set_cursor(cls, cursor = 'DEFAULT' ):
        cls.cursor = cursor

    @classmethod
    def get_gizmo(cls, region ):
        gizmo = [ i for i in cls.child_gizmos if i.region == region ]
        if gizmo :
            return gizmo[0]
        return None

    @classmethod
    def recive_event( cls , context , event ) :
        if not _pq_is_any_polyquilt_active_tool(context):
            return False
        ret = False
        for gizmo in cls.child_gizmos :
            ret = ret | gizmo.recive_event( context , event)
        return ret

    @classmethod
    def depsgraph_update_post( cls , scene ) :
        for gizmo in cls.child_gizmos :
            gizmo.refresh( bpy.context )


class PQ_GizmoGroup_Preselect(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuilt
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Preselect Gizmo"

class PQ_GizmoGroup_Lowpoly(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltPoly
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Lowpoly Gizmo"

class PQ_GizmoGroup_Knife(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltKnife
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Knife Gizmo"

class PQ_GizmoGroup_Delete(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltDelete
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Delete Gizmo"

class PQ_GizmoGroup_Extrude(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltExtrude
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Extrude Gizmo"

class PQ_GizmoGroup_EdgeLoop(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltEdgeLoop
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Edgeloop Gizmo"

class PQ_GizmoGroup_LoopCut(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltLoopCut
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt LoopCut Gizmo"

class PQ_GizmoGroup_Brush(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltBrush
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Brush Gizmo"

class PQ_GizmoGroup_Seam(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltSeam
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt Seam Gizmo"

class PQ_GizmoGroup_QuadPatch(PQ_GizmoGroup_Base):
    my_tool = ToolPolyQuiltQuadPatch
    bl_idname = my_tool.bl_widget
    bl_label = "PolyQuilt QuadOatch Gizmo"

all_gizmos = ( PQ_Gizmo_Preselect , PQ_GizmoGroup_Preselect , PQ_GizmoGroup_Lowpoly , PQ_GizmoGroup_Knife , PQ_GizmoGroup_Delete, PQ_GizmoGroup_Extrude, PQ_GizmoGroup_EdgeLoop, PQ_GizmoGroup_LoopCut, PQ_GizmoGroup_Brush, PQ_GizmoGroup_Seam, PQ_GizmoGroup_QuadPatch )



