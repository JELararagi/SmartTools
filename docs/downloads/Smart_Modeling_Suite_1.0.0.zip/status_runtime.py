# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared single-slot status-bar runtime for the SmartTools family.

Every SmartTools package carries an identical copy of this module.  Runtime
state lives in ``bpy.app.driver_namespace`` so independently imported
Extension packages cooperate through one status slot instead of appending
duplicate STATUSBAR header callbacks.
"""
from __future__ import annotations

from contextlib import contextmanager
import inspect
import threading
import time
from typing import Any, Dict, Iterator, Optional

try:
    import bpy
except Exception:  # pragma: no cover - allows static tooling outside Blender.
    bpy = None  # type: ignore[assignment]

_NAMESPACE_KEY = "JELARARAGI_SMARTTOOLS_STATUS_RUNTIME_V2"
_STATE_VERSION = 4
_DEFAULT_TRANSIENT_SECONDS = 1.8
_MIN_TIMER_INTERVAL = 0.04
_UI_RETRY_INTERVAL = 0.10
_RESOURCE_MONITOR_INTERVAL = 0.10
_DRAW_HEARTBEAT_INTERVAL = 0.25
_DRAW_STALE_SECONDS = 0.75
_MAX_STATUS_ENTRIES = 128
_MAX_STATUS_KEY_CHARS = 256
_MAX_STATUS_OWNER_CHARS = 256
_MAX_STATUS_TEXT_CHARS = 1024
_MAX_STATUS_KIND_CHARS = 64
_SELF_MANAGED_OPERATOR_IDS = {
    # These operators maintain richer live status text themselves.  Wrapping a
    # lazy proxy with a generic completion message would overwrite the feature's
    # single specialised status entry on the first invocation.
    "mesh.smart_vert_slide",
    "mesh.smart_vert_slide_modal",
    "mesh.smart_vert_slide_constraint_monitor",
}

# Exact identity of a shared mapping created by this bundled module while the
# package was imported.  register() runs after package import, so an ownership
# snapshot taken only there is too late to observe this creation boundary.
_SHARED_STATE_CREATED_BY_THIS_MODULE = None


def _fallback_state() -> Dict[str, Any]:
    state = globals().get("_FALLBACK_STATE")
    if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
        state = _new_state()
        globals()["_FALLBACK_STATE"] = state
    return state


def _new_state() -> Dict[str, Any]:
    return {
        "version": _STATE_VERSION,
        "lock": threading.RLock(),
        "sequence": 0,
        "entries": {},
        "workspace_text": {},
        "last_text": None,
        "timer_fn": None,
        "timer_registered": False,
        "stats": {},
        "registration_depth": {},
        "resource_capture_depth": 0,
        "resource_context_stack": [],
        "resource_original_apis": {},
        "resource_native_apis": {},
        "resource_monitor_fn": None,
        "resource_monitor_registered": False,
        "resource_monitor_running": False,
        "timer_records": {},
        "draw_records": {},
        "draw_space_classes": None,
        "handler_wrappers": {},
        "rna_boundary_depth": 0,
        "rna_boundary_resume_after": 0.0,
        "rna_boundary_handlers_installed": False,
    }


def _state() -> Dict[str, Any]:
    global _SHARED_STATE_CREATED_BY_THIS_MODULE
    if bpy is None:
        # Static/unit-test fallback.  This attribute is local to the module and
        # intentionally not shared outside Blender.
        return _fallback_state()
    namespace = bpy.app.driver_namespace
    state = namespace.get(_NAMESPACE_KEY)
    if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
        # A foreign/pre-existing value is never replaced or adopted.  Keep the
        # Suite operational on its module-local fallback and fail closed at the
        # shared ownership boundary.
        if _NAMESPACE_KEY in namespace:
            return _fallback_state()
        state = _new_state()
        namespace[_NAMESPACE_KEY] = state
        _SHARED_STATE_CREATED_BY_THIS_MODULE = state
    return state


def shared_state_identity_snapshot():
    """Capture whether the shared mapping existed without creating it."""
    if bpy is None:
        return None
    try:
        namespace = bpy.app.driver_namespace
        if not isinstance(namespace, dict):
            return None
        existed = _NAMESPACE_KEY in namespace
        return {
            "namespace": namespace,
            "existed": existed,
            "value": namespace.get(_NAMESPACE_KEY) if existed else None,
        }
    except Exception:
        return None


def shared_state_created_since(snapshot):
    """Return the exact newly-created state, never a pre-existing mapping."""
    if bpy is None or not isinstance(snapshot, dict) or bool(snapshot.get("existed", True)):
        return None
    try:
        namespace = snapshot.get("namespace")
        if namespace is not bpy.app.driver_namespace or not isinstance(namespace, dict):
            return None
        state = namespace.get(_NAMESPACE_KEY)
        if isinstance(state, dict) and state.get("version") == _STATE_VERSION:
            return state
    except Exception:
        pass
    return None


def shared_state_created_by_this_module():
    """Return only the exact mapping created after an absent-key observation."""
    if bpy is None or not isinstance(_SHARED_STATE_CREATED_BY_THIS_MODULE, dict):
        return None
    try:
        namespace = bpy.app.driver_namespace
        if isinstance(namespace, dict) and namespace.get(_NAMESPACE_KEY) is _SHARED_STATE_CREATED_BY_THIS_MODULE:
            return _SHARED_STATE_CREATED_BY_THIS_MODULE
    except Exception:
        pass
    return None


def _shared_state_is_exact_idle_locked(state: Dict[str, Any]) -> bool:
    """Fail closed unless the shared state has no live or foreign ownership."""
    allowed_keys = set(_new_state()) | {
        "handler_generations",
        "handler_generation_sequence",
    }
    if set(state) - allowed_keys:
        return False
    if state.get("version") != _STATE_VERSION:
        return False
    for name in (
        "entries",
        "stats",
        "registration_depth",
        "resource_context_stack",
        "resource_original_apis",
        "timer_records",
        "draw_records",
        "handler_wrappers",
        "handler_generations",
    ):
        if state.get(name):
            return False
    if any(value is not None for value in dict(state.get("workspace_text", {})).values()):
        return False
    if state.get("last_text") is not None:
        return False
    if int(state.get("resource_capture_depth", 0) or 0) != 0:
        return False
    if int(state.get("rna_boundary_depth", 0) or 0) != 0:
        return False
    if float(state.get("rna_boundary_resume_after", 0.0) or 0.0) > _now():
        return False
    for name in (
        "timer_registered",
        "resource_monitor_registered",
        "resource_monitor_running",
        "rna_boundary_handlers_installed",
    ):
        if bool(state.get(name, False)):
            return False
    return True


def release_shared_state_if_exact_idle(expected_state) -> bool:
    """Remove only the exact state this Suite created and only while idle."""
    if bpy is None or not isinstance(expected_state, dict):
        return False
    try:
        namespace = bpy.app.driver_namespace
        if not isinstance(namespace, dict) or namespace.get(_NAMESPACE_KEY) is not expected_state:
            return False
        lock = expected_state.get("lock")
        if lock is None:
            return False
        with lock:
            if namespace.get(_NAMESPACE_KEY) is not expected_state:
                return False
            if not _shared_state_is_exact_idle_locked(expected_state):
                return False
            if namespace.get(_NAMESPACE_KEY) is not expected_state:
                return False
            namespace.pop(_NAMESPACE_KEY, None)
            return True
    except Exception:
        return False


def _now() -> float:
    return time.monotonic()


def _on_main_thread() -> bool:
    try:
        return threading.current_thread() is threading.main_thread()
    except Exception:
        return True


def _workspace_candidates(context=None):
    if bpy is None or not _on_main_thread():
        return []
    result = []
    seen = set()

    def _add(workspace):
        if workspace is None:
            return
        try:
            pointer = int(workspace.as_pointer())
        except Exception:
            pointer = id(workspace)
        if pointer in seen:
            return
        seen.add(pointer)
        result.append((pointer, workspace))

    try:
        _add(getattr(context, "workspace", None))
    except Exception:
        pass
    try:
        wm = getattr(bpy.context, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            screen = getattr(window, "screen", None)
            _add(getattr(screen, "workspace", None))
    except Exception:
        pass
    try:
        _add(getattr(bpy.context, "workspace", None))
    except Exception:
        pass
    return result


def _remove_expired_locked(state: Dict[str, Any], now: Optional[float] = None) -> None:
    now = _now() if now is None else now
    entries = state["entries"]
    expired = [key for key, value in tuple(entries.items())
               if value.get("expires_at") is not None and float(value["expires_at"]) <= now]
    for key in expired:
        entries.pop(key, None)


def _top_entry_locked(state: Dict[str, Any]):
    _remove_expired_locked(state)
    entries = tuple(state["entries"].values())
    if not entries:
        return None
    # A currently executing task wins over a short completion notice, and a
    # short notice wins over a passive always-on service.  Within one priority,
    # the most recent update wins.  Only that one entry is ever published.
    return max(entries, key=lambda item: (int(item.get("priority", 0)), int(item.get("sequence", 0))))


def _publish_locked(state: Dict[str, Any], context=None) -> bool:
    entry = _top_entry_locked(state)
    text = str(entry.get("text", "")) if entry is not None else ""
    workspaces = _workspace_candidates(context)
    if not workspaces:
        state["last_text"] = text or None
        return False

    live_pointers = set()
    for pointer, workspace in workspaces:
        live_pointers.add(pointer)
        previous = state["workspace_text"].get(pointer)
        normalized = text or None
        if previous == normalized:
            continue
        try:
            workspace.status_text_set(text if text else None)
            state["workspace_text"][pointer] = normalized
        except (ReferenceError, RuntimeError):
            state["workspace_text"].pop(pointer, None)
        except Exception:
            pass
    for pointer in tuple(state["workspace_text"]):
        if pointer not in live_pointers:
            state["workspace_text"].pop(pointer, None)
    state["last_text"] = text or None
    return True


def _next_delay_locked(state: Dict[str, Any]) -> Optional[float]:
    # The same bounded, event-driven path is used in foreground and background
    # Blender.  With no workspace, publication retries are time-bounded and the
    # timer unregisters itself as soon as no expiry/retry deadline remains.
    now = _now()
    deadlines = [float(value["expires_at"]) for value in state["entries"].values()
                 if value.get("expires_at") is not None]
    if deadlines:
        return max(_MIN_TIMER_INTERVAL, min(deadlines) - now)
    # If an entry is active but no GUI workspace was ready yet, retry only while
    # that entry exists.  There is no idle polling when the status queue is empty.
    if state["entries"] and not _workspace_candidates(None):
        retry_deadlines = [
            float(value.get("ui_retry_until", 0.0) or 0.0)
            for value in state["entries"].values()
        ]
        if retry_deadlines and max(retry_deadlines) > now:
            return min(_UI_RETRY_INTERVAL, max(_MIN_TIMER_INTERVAL, max(retry_deadlines) - now))
    return None


def _shared_timer():
    state = _state()
    lock = state["lock"]
    with lock:
        _remove_expired_locked(state)
        _publish_locked(state)
        delay = _next_delay_locked(state)
        if delay is None:
            state["timer_registered"] = False
            return None
        return delay


def _ensure_timer_locked(state: Dict[str, Any]) -> None:
    if bpy is None:
        state["timer_registered"] = False
        return
    delay = _next_delay_locked(state)
    if delay is None:
        return
    timer_fn = state.get("timer_fn")
    if not callable(timer_fn):
        timer_fn = _shared_timer
        state["timer_fn"] = timer_fn
    try:
        timers = bpy.app.timers
        if timers.is_registered(timer_fn):
            state["timer_registered"] = True
            return
        timers.register(timer_fn, first_interval=max(_MIN_TIMER_INTERVAL, float(delay)))
        state["timer_registered"] = True
    except Exception:
        state["timer_registered"] = False


def _upsert(key: str, owner: str, text: str, *, priority: int,
            duration: Optional[float], kind: str, context=None) -> str:
    # Status state is shared by all Smart Tools copies.  Bound every caller-owned
    # string before it enters the shared cache so a malformed operator report
    # cannot create an unbounded resident allocation.
    key = str(key or "")[:_MAX_STATUS_KEY_CHARS]
    owner = str(owner or "")[:_MAX_STATUS_OWNER_CHARS]
    text = str(text or "")[:_MAX_STATUS_TEXT_CHARS]
    kind = str(kind or "")[:_MAX_STATUS_KIND_CHARS]
    state = _state()
    lock = state["lock"]
    with lock:
        existing = state["entries"].get(key)
        if (existing is not None and duration is None
                and existing.get("kind") == kind
                and existing.get("text") == text
                and int(existing.get("priority", 0)) == int(priority)):
            _publish_locked(state, context)
            return key
        state["sequence"] = int(state.get("sequence", 0)) + 1
        sequence = state["sequence"]
        state["entries"][key] = {
            "key": key,
            "owner": owner,
            "text": text,
            "priority": int(priority),
            "sequence": sequence,
            "kind": kind,
            "expires_at": None if duration is None else _now() + max(0.0, float(duration)),
            # Retry workspace publication only for a short bounded window.  The
            # status entry itself may remain valid, but it never creates an
            # unbounded idle polling timer when no UI workspace exists.
            "ui_retry_until": _now() + 1.0,
        }
        if len(state["entries"]) > _MAX_STATUS_ENTRIES:
            overflow = len(state["entries"]) - _MAX_STATUS_ENTRIES
            oldest = sorted(
                state["entries"].items(),
                key=lambda item: int(item[1].get("sequence", 0)),
            )
            for stale_key, _stale_entry in oldest[:overflow]:
                if stale_key != key:
                    state["entries"].pop(stale_key, None)
        _publish_locked(state, context)
        _ensure_timer_locked(state)
    return key


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None) -> str:
    """Replace the transient status owned by *owner*.

    Repeated calls use the same key and therefore cannot grow horizontally or
    create duplicate status-bar callbacks.
    """
    key = f"transient:{owner}"
    return _upsert(key, owner, text, priority=20, duration=duration, kind="transient", context=context)


def set_service(owner: str, text: str, *, context=None) -> str:
    """Show one persistent status for an actually running background service."""
    key = f"service:{owner}"
    return _upsert(key, owner, text, priority=10, duration=None, kind="service", context=context)


def begin_task(owner: str, text: str, *, context=None) -> str:
    """Begin a nested foreground task and return its unique token."""
    state = _state()
    with state["lock"]:
        state["sequence"] = int(state.get("sequence", 0)) + 1
        sequence = state["sequence"]
    token = f"task:{owner}:{sequence}"
    return _upsert(token, owner, text, priority=30, duration=None, kind="task", context=context)


def update_task(token: str, text: str, *, context=None) -> bool:
    state = _state()
    lock = state["lock"]
    with lock:
        entry = state["entries"].get(token)
        if entry is None:
            return False
        state["sequence"] = int(state.get("sequence", 0)) + 1
        entry["sequence"] = state["sequence"]
        entry["text"] = str(text or "")
        _publish_locked(state, context)
    return True


def finish_task(token: str, final_text: Optional[str] = None,
                duration: float = 0.12, *, context=None) -> None:
    state = _state()
    lock = state["lock"]
    with lock:
        entry = state["entries"].pop(token, None)
        owner = str(entry.get("owner", token)) if entry else str(token)
        _publish_locked(state, context)
    if final_text:
        set_transient(owner, final_text, duration=duration, context=context)


def _cancel_timer_if_idle_locked(state: Dict[str, Any]) -> None:
    if bpy is None or state["entries"]:
        return
    timer_fn = state.get("timer_fn")
    if not callable(timer_fn):
        state["timer_registered"] = False
        return
    try:
        timers = bpy.app.timers
        if timers.is_registered(timer_fn):
            timers.unregister(timer_fn)
    except Exception:
        pass
    state["timer_registered"] = False


def clear(owner_or_token: str, *, context=None) -> None:
    """Clear an exact task token or every status entry owned by the identifier."""
    state = _state()
    lock = state["lock"]
    with lock:
        entries = state["entries"]
        entries.pop(owner_or_token, None)
        for key, entry in tuple(entries.items()):
            if entry.get("owner") == owner_or_token:
                entries.pop(key, None)
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)
        _ensure_timer_locked(state)


def _status_value_belongs_to_suite(value: object, suite_id: str) -> bool:
    """Match the exact Suite namespace, never a loose text prefix."""
    text = str(value or "")
    root = str(suite_id or "")
    if not root:
        return False
    return text == root or text.startswith(root + ".") or text.startswith(root + ":")


def clear_prefix(prefix: str, *, context=None) -> None:
    """Compatibility name for exact Suite-namespace cleanup.

    The API name is retained for existing callers.  Ownership is established by
    a boundary-aware Suite ID match and by exact resource receipts; arbitrary
    string prefixes never authorize cleanup.
    """
    suite_id = str(prefix or "")
    _cleanup_resource_records(suite_id)
    state = _state()
    lock = state["lock"]
    with lock:
        for key, entry in tuple(state["entries"].items()):
            if (_status_value_belongs_to_suite(entry.get("owner"), suite_id)
                    or _status_value_belongs_to_suite(key, suite_id)):
                state["entries"].pop(key, None)
        state.setdefault("stats", {}).pop(suite_id, None)
        state.setdefault("registration_depth", {}).pop(suite_id, None)
        stack = state.setdefault("resource_context_stack", [])
        stack[:] = [
            item for item in stack
            if not (isinstance(item, dict) and str(item.get("suite_id", "") or "") == suite_id)
        ]
        state["resource_capture_depth"] = len(stack)
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)
        _ensure_timer_locked(state)


def clear_all(*, context=None) -> None:
    _cleanup_resource_records("")
    state = _state()
    lock = state["lock"]
    with lock:
        state["entries"].clear()
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)


def snapshot() -> Dict[str, Any]:
    """Return a serialisable runtime snapshot for regression tests."""
    state = _state()
    with state["lock"]:
        _remove_expired_locked(state)
        top = _top_entry_locked(state)
        return {
            "version": state.get("version"),
            "entry_count": len(state["entries"]),
            "entries": [dict(item) for item in state["entries"].values()],
            "visible_text": None if top is None else top.get("text"),
            "timer_registered": bool(state.get("timer_registered", False)),
            "captured_timer_count": len(state.get("timer_records", {})),
            "captured_draw_count": len(state.get("draw_records", {})),
            "resource_capture_depth": int(state.get("resource_capture_depth", 0)),
            "resource_monitor_registered": bool(state.get("resource_monitor_registered", False)),
            "stats": {suite: dict(values) for suite, values in state.get("stats", {}).items()},
        }


@contextmanager
def task_scope(owner: str, text: str, *, context=None,
               completed_text: Optional[str] = None,
               error_prefix: Optional[str] = None) -> Iterator[str]:
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception as exc:
        finish_task(
            token,
            f"{error_prefix or 'Error'}: {exc}",
            duration=2.5,
            context=context,
        )
        raise
    else:
        finish_task(token, completed_text, context=context)


def _is_japanese(context=None) -> bool:
    if bpy is None:
        return False
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, "preferences", None), "view", None)
        return str(getattr(view, "language", "") or "").startswith("ja")
    except Exception:
        return False


def _translated_label(value: str) -> str:
    text = str(value or "")
    if bpy is None or not text:
        return text
    try:
        return str(bpy.app.translations.pgettext_iface(text) or text)
    except Exception:
        return text


def _humanize_identifier(value: str) -> str:
    """Return a stable, readable label for an RNA identifier."""
    text = str(value or "").strip()
    if not text:
        return "Option"
    if "." in text:
        text = text.rsplit(".", 1)[-1]
    text = text.replace("_", " ").replace("-", " ")
    words = [word for word in text.split() if word]
    if not words:
        return "Option"
    return " ".join(word.upper() if len(word) <= 3 and word.isalpha() else word.capitalize() for word in words)


def _default_operator_description(cls, suite_label: str) -> str:
    del cls, suite_label
    return ""


def _default_property_description(display_name: str, property_kind: str) -> str:
    del display_name, property_kind
    return ""


def _ensure_rna_class_tooltips(cls, suite_label: str):
    """Fill only missing operator/property descriptions before RNA registration.

    Existing authored descriptions are never changed.  The fallback guarantees
    that every exposed RNA control has a beginner-readable tooltip in the
    language active when the Extension is registered.
    """
    if not isinstance(cls, type):
        return cls
    try:
        operator_base = getattr(getattr(bpy, "types", None), "Operator", None) if bpy is not None else None
        if operator_base is not None and issubclass(cls, operator_base):
            if not str(getattr(cls, "bl_description", "") or "").strip():
                cls.bl_description = _default_operator_description(cls, suite_label)
    except Exception:
        pass

    try:
        annotations = dict(vars(cls).get("__annotations__", {}) or {})
    except Exception:
        annotations = {}
    for property_name, deferred in annotations.items():
        try:
            keywords = getattr(deferred, "keywords", None)
            if not isinstance(keywords, dict):
                continue
            if str(keywords.get("description", "") or "").strip():
                continue
            function = getattr(deferred, "function", None)
            kind = getattr(function, "__name__", "Property")
            display_name = str(keywords.get("name", "") or "").strip() or _humanize_identifier(property_name)
            keywords["description"] = _default_property_description(display_name, kind)
        except Exception:
            continue
    return cls


def _operator_status_text(suite_label: str, operator_label: str, phase: str, context=None) -> str:
    suite = _translated_label(suite_label)
    operator = _translated_label(operator_label)
    japanese = _is_japanese(context)
    if phase == "running":
        return f"{suite}: 「{operator}」を実行中…" if japanese else f"{suite}: Running “{operator}”…"
    if phase == "completed":
        return f"{suite}: 「{operator}」が完了しました" if japanese else f"{suite}: Completed “{operator}”"
    if phase == "cancelled":
        return f"{suite}: 「{operator}」を取消しました" if japanese else f"{suite}: Cancelled “{operator}”"
    return f"{suite}: 「{operator}」でエラーが発生しました" if japanese else f"{suite}: Error in “{operator}”"


def _result_has(result, value: str) -> bool:
    try:
        return value in result
    except Exception:
        return False


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    """Instrument one Python Operator class without changing its Undo contract.

    The wrapper keeps one task token for the complete invoke/execute/modal
    lifecycle.  An ``invoke`` that calls ``execute`` therefore does not create a
    second visible entry, and a modal event does not update the status string on
    every mouse move.
    """
    if bpy is None or not isinstance(cls, type):
        return cls
    try:
        operator_base = getattr(bpy.types, "Operator", None)
        if operator_base is None or not issubclass(cls, operator_base):
            return cls
    except Exception:
        return cls
    _ensure_rna_class_tooltips(cls, suite_label)
    # Do not return solely because the class was instrumented earlier.  Lazy
    # SmartTools replace methods in-place after the proxy RNA class is already
    # registered.  Each method is checked independently below, so newly applied
    # real methods are wrapped while existing wrappers remain untouched.

    try:
        if bool(getattr(cls, "_jelararagi_status_managed_v2", False)):
            return cls
    except Exception:
        pass

    bl_idname = str(getattr(cls, "bl_idname", "") or "").strip()
    if not bl_idname:
        return cls
    if bl_idname in _SELF_MANAGED_OPERATOR_IDS:
        try:
            cls._jelararagi_status_managed_v2 = True
        except Exception:
            pass
        return cls
    operator_label = str(getattr(cls, "bl_label", "") or bl_idname)
    owner = f"{suite_id}.operator.{bl_idname}"
    token_attr = "_jelararagi_status_task_token_v2"

    def _get_token(instance):
        # Operator instances are not reused for an unrelated invocation.  The
        # instance attribute is therefore sufficient and avoids taking the
        # shared runtime lock on every MOUSEMOVE modal event.
        try:
            return getattr(instance, token_attr, None) or None
        except Exception:
            return None

    def _ensure_token(instance, context):
        token = _get_token(instance)
        if token:
            return token
        token = begin_task(
            owner,
            _operator_status_text(suite_label, operator_label, "running", context),
            context=context,
        )
        try:
            setattr(instance, token_attr, token)
        except Exception:
            pass
        return token

    def _finish(instance, context, *, cancelled=False, error=False):
        token = _get_token(instance)
        if not token:
            return
        try:
            setattr(instance, token_attr, None)
        except Exception:
            pass
        phase = "error" if error else ("cancelled" if cancelled else "completed")
        finish_task(
            token,
            _operator_status_text(suite_label, operator_label, phase, context),
            duration=0.12 if not error else 2.5,
            context=context,
        )

    def _wrap(name: str):
        original = getattr(cls, name, None)
        if not callable(original):
            return
        try:
            if bool(getattr(original, "_jelararagi_status_wrapper_v2", False)):
                return
        except Exception:
            pass

        if name == "modal":
            def _make_modal(_original):
                def wrapped(self, context, event):
                    _ensure_token(self, context)
                    try:
                        event_type = str(getattr(event, "type", "") or "")
                        if event_type in _RESOURCE_TERMINAL_MODAL_EVENTS:
                            with capture_runtime_resources(suite_id, suite_label):
                                result = _original(self, context, event)
                        else:
                            result = _original(self, context, event)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if _result_has(result, "CANCELLED"):
                        _finish(self, context, cancelled=True)
                    elif _result_has(result, "FINISHED"):
                        _finish(self, context)
                    return result
                return wrapped
            wrapped = _make_modal(original)
        elif name == "cancel":
            def _make_cancel(_original):
                def wrapped(self, context):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            return _original(self, context)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    finally:
                        _finish(self, context, cancelled=True)
                return wrapped
            wrapped = _make_cancel(original)
        elif name == "invoke":
            def _make_invoke(_original):
                def wrapped(self, context, event):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            result = _original(self, context, event)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if not _result_has(result, "RUNNING_MODAL"):
                        _finish(self, context, cancelled=_result_has(result, "CANCELLED"))
                    return result
                return wrapped
            wrapped = _make_invoke(original)
        else:  # execute
            def _make_execute(_original):
                def wrapped(self, context):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            result = _original(self, context)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if not _result_has(result, "RUNNING_MODAL"):
                        _finish(self, context, cancelled=_result_has(result, "CANCELLED"))
                    return result
                return wrapped
            wrapped = _make_execute(original)

        try:
            wrapped.__name__ = getattr(original, "__name__", name)
            wrapped.__doc__ = getattr(original, "__doc__", None)
            wrapped._jelararagi_status_wrapper_v2 = True
            wrapped._jelararagi_status_original_v2 = original
            setattr(cls, name, wrapped)
        except Exception:
            pass

    # Wrap execute first.  If invoke calls self.execute(), both methods reuse the
    # same instance token and still appear as a single status entry.
    for method_name in ("execute", "invoke", "modal", "cancel"):
        _wrap(method_name)
    try:
        cls._jelararagi_status_instrumented_v2 = True
    except Exception:
        pass
    _increment_stat(suite_id, "operator_class")
    return cls


def _iter_operator_subclasses():
    if bpy is None:
        return
    base = getattr(bpy.types, "Operator", None)
    if base is None:
        return
    seen = set()
    stack = list(base.__subclasses__())
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        yield cls
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str) -> int:
    """Instrument every currently loaded Operator class owned by one package."""
    marker = str(package_marker or suite_id).lower()
    count = 0
    for cls in _iter_operator_subclasses() or ():
        try:
            module_name = str(getattr(cls, "__module__", "") or "").lower()
            if marker not in module_name:
                continue
            if not str(getattr(cls, "bl_idname", "") or "").strip():
                continue
            instrument_operator_class(cls, suite_id, suite_label)
            count += 1
        except Exception:
            continue
    return count


def _callback_display_name(callback) -> str:
    try:
        return str(getattr(callback, "__name__", "") or getattr(callback, "__qualname__", "") or "Callback")
    except Exception:
        return "Callback"


def _suite_registration_active(suite_id: str) -> bool:
    try:
        state = _state()
        with state["lock"]:
            return int(state.setdefault("registration_depth", {}).get(suite_id, 0)) > 0
    except Exception:
        return False


_RESOURCE_TERMINAL_MODAL_EVENTS = frozenset({
    "TIMER", "LEFTMOUSE", "RIGHTMOUSE", "ESC", "RET", "NUMPAD_ENTER", "SPACE",
})


def _active_resource_context(state=None):
    state = state or _state()
    try:
        stack = state.setdefault("resource_context_stack", [])
        return stack[-1] if stack else None
    except Exception:
        return None


def _is_internal_status_timer(callback) -> bool:
    try:
        name = str(getattr(callback, "__name__", "") or "")
        globals_dict = getattr(callback, "__globals__", {})
        return (
            name in {"_shared_timer", "_resource_monitor_timer"}
            and isinstance(globals_dict, dict)
            and globals_dict.get("_NAMESPACE_KEY") == _NAMESPACE_KEY
        )
    except Exception:
        return False


def _resource_status_text(suite_label: str, callback, kind_en: str, kind_ja: str, *, active=False):
    label = _translated_label(_callback_display_name(callback))
    suite = _translated_label(suite_label)
    if _is_japanese(None):
        suffix = "が動作中" if active else "を実行中…"
        return f"{suite}: {kind_ja}「{label}」{suffix}"
    suffix = " active" if active else "…"
    return f"{suite}: {'Active ' if active else 'Running '}{kind_en} “{label}”{suffix}"


def _timer_record_for(callback, state=None, suite_id=None):
    state = state or _state()
    for record in tuple(state.setdefault("timer_records", {}).values()):
        if suite_id and record.get("suite_id") != suite_id:
            continue
        if record.get("original") is callback:
            return record
    return None


def _native_timer_apis(state=None):
    state = state or _state()
    native = state.setdefault("resource_native_apis", {})
    if bpy is not None and not native:
        try:
            native.update({
                "timer_register": bpy.app.timers.register,
                "timer_unregister": bpy.app.timers.unregister,
                "timer_is_registered": bpy.app.timers.is_registered,
            })
        except Exception:
            pass
    return native


def _cancel_resource_monitor_if_idle(state=None):
    state = state or _state()
    with state["lock"]:
        if state.setdefault("timer_records", {}) or state.setdefault("draw_records", {}):
            return
        monitor_fn = state.get("resource_monitor_fn")
        running = bool(state.get("resource_monitor_running", False))
        state["resource_monitor_registered"] = False
    if not callable(monitor_fn) or running or bpy is None:
        return
    native = _native_timer_apis(state)
    is_registered = native.get("timer_is_registered")
    unregister = native.get("timer_unregister")
    try:
        if callable(is_registered) and callable(unregister) and is_registered(monitor_fn):
            unregister(monitor_fn)
    except Exception:
        pass


def _drop_timer_record(record, *, clear_status=True):
    if not record:
        return
    state = _state()
    with state["lock"]:
        for key, value in tuple(state.setdefault("timer_records", {}).items()):
            if value is record:
                state["timer_records"].pop(key, None)
    if clear_status:
        clear(str(record.get("owner", "")))
    _cancel_resource_monitor_if_idle(state)
    _remove_global_draw_boundary_handlers_if_unused()


def _resource_monitor_timer():
    """Legacy one-shot terminator for a monitor created by an older generation.

    Smart Modeling no longer registers a resource-monitor timer.  If Blender
    invokes a previously registered exact callback after a live replacement,
    returning ``None`` retires it immediately without inspecting foreign state.
    """
    state = _state()
    with state["lock"]:
        state["resource_monitor_registered"] = False
        state["resource_monitor_running"] = False
    return None


def _ensure_resource_monitor(state=None, *, native_register=None, native_is_registered=None):
    """Compatibility no-op.

    Resource ownership is recorded by the feature modules that create each
    timer/draw/msgbus resource.  A periodic status monitor would add idle wakeups
    and is therefore intentionally not installed.
    """
    del state, native_register, native_is_registered
    return None


def _captured_timer_register(function, *args, **kwargs):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_register = originals.get("timer_register")
    original_unregister = originals.get("timer_unregister")
    original_is_registered = originals.get("timer_is_registered")
    if not callable(original_register):
        return bpy.app.timers.register(function, *args, **kwargs)
    context = _active_resource_context(state)
    if not context or _is_internal_status_timer(function):
        return original_register(function, *args, **kwargs)

    # Register the exact original callback.  Replacing it with a wrapper breaks
    # later native ``unregister(original)`` calls after this capture ends.
    result = original_register(function, *args, **kwargs)
    suite_id, suite_label = context["suite_id"], context["suite_label"]
    record = _timer_record_for(function, state, suite_id)
    if record is None:
        owner = f"{suite_id}.timer.{id(function)}"
        record = {
            "suite_id": suite_id,
            "suite_label": suite_label,
            "original": function,
            "owner": owner,
            "native_unregister": original_unregister,
            "native_is_registered": original_is_registered,
        }
        with state["lock"]:
            state.setdefault("timer_records", {})[f"{suite_id}:{id(function)}"] = record
        _increment_stat(suite_id, "timer_callback")
    set_service(
        str(record.get("owner", "")),
        _resource_status_text(suite_label, function, "timer", "タイマー", active=True),
    )
    _ensure_resource_monitor(
        state,
        native_register=original_register,
        native_is_registered=original_is_registered,
    )
    return result


def _captured_timer_unregister(function):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_unregister = originals.get("timer_unregister")
    if not callable(original_unregister):
        return bpy.app.timers.unregister(function)
    record = _timer_record_for(function, state)
    try:
        return original_unregister(function)
    finally:
        if record:
            _drop_timer_record(record)


def _captured_timer_is_registered(function):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_is_registered = originals.get("timer_is_registered")
    if not callable(original_is_registered):
        return bpy.app.timers.is_registered(function)
    return original_is_registered(function)


def _draw_boundary_handler_lists():
    if bpy is None:
        return ()
    handlers = bpy.app.handlers
    result = []
    for name, phase in (
        ("load_pre", "begin"), ("load_post", "end"),
        # Autosave and explicit saves can serialize/replace evaluated owners while
        # a region redraw is pending.  Treat save boundaries exactly like file-load
        # and undo boundaries so no SmartTools draw callback can enter RNA geometry
        # access during Blender's native save pipeline.
        ("save_pre", "begin"), ("save_post", "end"),
        ("undo_pre", "begin"), ("undo_post", "end"),
        ("redo_pre", "begin"), ("redo_post", "end"),
    ):
        handler_list = getattr(handlers, name, None)
        if handler_list is not None:
            result.append((handler_list, phase))
    return tuple(result)


def _global_draw_boundary_begin(*_args):
    state = _state()
    with state["lock"]:
        state["rna_boundary_depth"] = int(state.get("rna_boundary_depth", 0)) + 1
        state["rna_boundary_resume_after"] = float("inf")


def _global_draw_boundary_end(*_args):
    state = _state()
    with state["lock"]:
        depth = max(0, int(state.get("rna_boundary_depth", 0)) - 1)
        state["rna_boundary_depth"] = depth
        if depth == 0:
            # A draw may be requested from the same native file/undo callback.
            # Wait for a later UI event before any SmartTools draw callback runs.
            state["rna_boundary_resume_after"] = _now() + 0.20


for _callback, _phase in (
    (_global_draw_boundary_begin, "begin"),
    (_global_draw_boundary_end, "end"),
):
    try:
        _callback._jelararagi_global_draw_boundary_v1 = True
        _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
        _callback = bpy.app.handlers.persistent(_callback)
    except Exception:
        try:
            _callback._bpy_persistent = None
            _callback._jelararagi_global_draw_boundary_v1 = True
            _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
        except Exception:
            pass
# Rebind after applying persistent; assignment in the loop is local only.
try:
    _global_draw_boundary_begin = bpy.app.handlers.persistent(_global_draw_boundary_begin)
except Exception:
    pass
try:
    _global_draw_boundary_end = bpy.app.handlers.persistent(_global_draw_boundary_end)
except Exception:
    pass
for _callback, _phase in (
    (_global_draw_boundary_begin, "begin"),
    (_global_draw_boundary_end, "end"),
):
    try:
        _callback._jelararagi_global_draw_boundary_v1 = True
        _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
    except Exception:
        pass
try:
    del _callback, _phase
except Exception:
    pass


def _ensure_global_draw_boundary_handlers():
    """Compatibility no-op; immutable draw snapshots need no global handlers."""
    return None


def _remove_global_draw_boundary_handlers_if_unused():
    """Remove only exact legacy receipts, never scan handler lists by marker."""
    state = _state()
    receipts = ()
    with state["lock"]:
        receipts = tuple(state.pop("rna_boundary_handler_receipts", ()) or ())
        state["rna_boundary_handlers_installed"] = False
        state["rna_boundary_depth"] = 0
        state["rna_boundary_resume_after"] = 0.0
    for receipt in reversed(receipts):
        if not isinstance(receipt, dict):
            continue
        _remove_one_identity(receipt.get("list"), receipt.get("callback"))
    return None


def _draw_callback_execution_safe(record=None):
    # Foreground and background use the same safety path.  Background Blender
    # naturally fails the window/screen/area/region requirement below, rather
    # than bypassing lifecycle verification through a special branch.
    if bpy is None or not _on_main_thread():
        return False
    state = _state()
    with state["lock"]:
        if int(state.get("rna_boundary_depth", 0)) > 0:
            return False
        if _now() < float(state.get("rna_boundary_resume_after", 0.0) or 0.0):
            return False
    if record is not None and _now() < float(record.get("not_before", 0.0) or 0.0):
        return False
    try:
        ctx = bpy.context
        wm = getattr(ctx, "window_manager", None)
        if wm is None or bool(getattr(wm, "is_interface_locked", False)):
            return False
        return bool(getattr(ctx, "window", None) and getattr(ctx, "screen", None)
                    and getattr(ctx, "area", None) and getattr(ctx, "region", None))
    except Exception:
        return False

def _discover_draw_space_classes(state):
    """Compatibility no-op retained for older callers.

    Current Smart Modeling generations never intercept ``Space*.draw_handler_*``
    and therefore have no reason to scan ``bpy.types``.  Interrupted legacy
    replacements are restored from the exact class/descriptor receipts already
    stored in ``resource_original_apis``.
    """
    if isinstance(state, dict):
        state.pop("draw_space_classes", None)
    return ()


def _drop_draw_record(record, *, clear_status=True):
    if not record:
        return
    state = _state()
    handle = record.get("handle")
    with state["lock"]:
        if handle is not None:
            state.setdefault("draw_records", {}).pop(id(handle), None)
        else:
            for key, value in tuple(state.setdefault("draw_records", {}).items()):
                if value is record:
                    state["draw_records"].pop(key, None)
    if clear_status:
        clear(str(record.get("owner", "")))
    _cancel_resource_monitor_if_idle(state)


def _refresh_draw_record(record):
    state = _state()
    now = _now()
    record["last_seen"] = now
    handle = record.get("handle")
    if handle is not None:
        with state["lock"]:
            state.setdefault("draw_records", {})[id(handle)] = record
    last_publish = float(record.get("last_publish", 0.0) or 0.0)
    if now - last_publish >= _DRAW_HEARTBEAT_INTERVAL:
        record["last_publish"] = now
        set_service(str(record.get("owner", "")), str(record.get("status_text", "")))
    _ensure_resource_monitor(state)


def _make_draw_callback_wrapper(record):
    original = record.get("callback")

    def wrapped(*args, **kwargs):
        if not _draw_callback_execution_safe(record):
            return None
        _refresh_draw_record(record)
        try:
            return original(*args, **kwargs)
        except ReferenceError:
            # RNA owners can disappear while Blender redraws during teardown.
            # Stop advertising the dead service; the owning suite will remove
            # the native handle during its normal cleanup path.
            _drop_draw_record(record)
            return None

    try:
        wrapped.__name__ = getattr(original, "__name__", "draw_callback")
        wrapped.__qualname__ = getattr(original, "__qualname__", wrapped.__name__)
        wrapped.__doc__ = getattr(original, "__doc__", None)
        wrapped.__module__ = getattr(original, "__module__", wrapped.__module__)
        wrapped._jelararagi_status_draw_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = original
    except Exception:
        pass
    return wrapped


def _make_captured_draw_add(space_name, original_add):
    def captured(*args, **kwargs):
        state = _state()
        context = _active_resource_context(state)
        if not context:
            return original_add(*args, **kwargs)

        callback = args[0] if args else kwargs.get("callback")
        if not callable(callback):
            return original_add(*args, **kwargs)
        suite_id, suite_label = context["suite_id"], context["suite_label"]
        record = {
            "suite_id": suite_id,
            "suite_label": suite_label,
            "space_name": space_name,
            "handle": None,
            "owner": "",
            "callback": callback,
            "wrapped_callback": None,
            "region_type": args[2] if len(args) > 2 else kwargs.get("region_type", "WINDOW"),
            "last_seen": _now(),
            "last_publish": 0.0,
            "stale_after": _DRAW_STALE_SECONDS,
            # Do not execute a newly registered draw callback in the same native
            # startup/load callback that created it.
            "not_before": _now() + 0.25,
        }
        _ensure_global_draw_boundary_handlers()
        wrapped_callback = _make_draw_callback_wrapper(record)
        record["wrapped_callback"] = wrapped_callback
        if args:
            call_args = (wrapped_callback,) + tuple(args[1:])
            call_kwargs = kwargs
        else:
            call_args = args
            call_kwargs = dict(kwargs)
            call_kwargs["callback"] = wrapped_callback
        handle = original_add(*call_args, **call_kwargs)
        record["handle"] = handle
        record["owner"] = f"{suite_id}.draw.{space_name}.{id(handle)}"
        record["status_text"] = _resource_status_text(
            suite_label, callback, f"{space_name} drawing", "描画処理", active=True,
        )
        with state["lock"]:
            state.setdefault("draw_records", {})[id(handle)] = record
        _refresh_draw_record(record)
        _increment_stat(suite_id, "draw_handler")
        return handle
    return captured


def _make_captured_draw_remove(space_name, original_remove):
    def captured(handle, *args, **kwargs):
        state = _state()
        with state["lock"]:
            record = state.setdefault("draw_records", {}).get(id(handle))
        try:
            return original_remove(handle, *args, **kwargs)
        finally:
            if record:
                _drop_draw_record(record)
    return captured


def _install_resource_api_capture(state):
    """Compatibility no-op: Blender process-global APIs are never replaced."""
    del state
    return None


def _restore_one_draw_api(cls, name, owned, raw_value, fallback):
    """Legacy compatibility no-op; no draw API descriptor is replaced."""
    del cls, name, owned, raw_value, fallback
    return None


def _legacy_wrapper_matches(current, *, expected_name: str, original=None) -> bool:
    """Return True only for an exact legacy wrapper receipt from this runtime."""
    if not callable(current):
        return False
    try:
        globals_dict = getattr(current, "__globals__", None)
        if not isinstance(globals_dict, dict) or globals_dict.get("_NAMESPACE_KEY") != _NAMESPACE_KEY:
            return False
        # Every Smart Tools copy shares the namespace key.  The module identity
        # string narrows legacy restoration to this exact Extension package so a
        # live capture owned by another Suite is never reverted.
        if str(globals_dict.get("__name__", "") or "") != str(__name__):
            return False
        if str(getattr(current, "__name__", "") or "") != str(expected_name):
            return False
        if original is None:
            return True
        closure = tuple(getattr(current, "__closure__", ()) or ())
        return any(getattr(cell, "cell_contents", None) is original for cell in closure)
    except Exception:
        return False


def restore_legacy_process_api_receipts() -> int:
    """Restore only exact shared-API receipts left by Smart Modeling <= 1.3.54.

    Current generations never replace Blender process-global APIs.  Live add-on
    replacement can, however, interrupt the older try/finally block.  The
    driver-namespace state retains the exact native callables and class descriptor
    receipts, so those exact wrappers can be restored without module/type scans.
    """
    if bpy is None:
        return 0
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    if not isinstance(originals, dict) or not originals:
        return 0
    restored = 0

    timer_specs = (
        ("register", "timer_register", "_captured_timer_register"),
        ("unregister", "timer_unregister", "_captured_timer_unregister"),
        ("is_registered", "timer_is_registered", "_captured_timer_is_registered"),
    )
    for attribute, receipt_key, wrapper_name in timer_specs:
        original = originals.get(receipt_key)
        if not callable(original):
            continue
        try:
            current = getattr(bpy.app.timers, attribute)
            if current is original:
                continue
            if _legacy_wrapper_matches(current, expected_name=wrapper_name):
                setattr(bpy.app.timers, attribute, original)
                restored += 1
        except Exception:
            pass

    for record in tuple(originals.get("draw_apis", ()) or ()):
        if not isinstance(record, dict):
            continue
        cls = record.get("cls")
        if cls is None:
            continue
        for name, original_key, own_key, raw_key, wrapper_name in (
            ("draw_handler_add", "original_add", "own_add", "raw_add", "captured"),
            ("draw_handler_remove", "original_remove", "own_remove", "raw_remove", "captured"),
        ):
            original = record.get(original_key)
            if not callable(original):
                continue
            try:
                current = getattr(cls, name)
                if not _legacy_wrapper_matches(current, expected_name=wrapper_name, original=original):
                    continue
                if bool(record.get(own_key)):
                    setattr(cls, name, record.get(raw_key))
                elif name in vars(cls):
                    delattr(cls, name)
                restored += 1
            except Exception:
                pass

    # Registration callback capture also left exact native receipts in some
    # interrupted builds.  They are restored only when the currently installed
    # callable is the legacy wrapper itself and the exact native callable exists.
    for owner, attribute, receipt_key, wrapper_name in (
        (getattr(bpy, "utils", None), "register_class", "register_class", "register_class_with_tooltips"),
        (getattr(bpy, "msgbus", None), "subscribe_rna", "msgbus_subscribe_rna", "subscribe_rna_wrapper"),
    ):
        original = originals.get(receipt_key)
        if owner is None or not callable(original):
            continue
        try:
            current = getattr(owner, attribute)
            if _legacy_wrapper_matches(current, expected_name=wrapper_name):
                setattr(owner, attribute, original)
                restored += 1
        except Exception:
            pass

    with state["lock"]:
        state["resource_capture_depth"] = 0
        state.setdefault("resource_context_stack", []).clear()
        state["resource_original_apis"] = {}
    return restored


def _restore_resource_api_capture(state):
    """Restore exact legacy API receipts when a prior generation was interrupted.

    Current releases never patch shared APIs.  This function only clears the
    local capture bookkeeping; legacy exact restoration is handled by
    ``restore_legacy_process_api_receipts`` during register/unregister.
    """
    if not isinstance(state, dict):
        return None
    with state.get("lock", threading.RLock()):
        state["resource_capture_depth"] = 0
        state.setdefault("resource_context_stack", []).clear()
    return None


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    """Explicit-operation boundary without process-global API interception.

    Integrated feature modules retain their own exact timer/draw/msgbus ledgers.
    The status layer only records the active owner context and never replaces
    Blender APIs, so unrelated add-ons always call the native functions directly.
    """
    state = _state()
    context = {"suite_id": str(suite_id), "suite_label": str(suite_label), "token": object()}
    with state["lock"]:
        state["resource_capture_depth"] = int(state.get("resource_capture_depth", 0)) + 1
        state.setdefault("resource_context_stack", []).append(context)
    try:
        yield
    finally:
        with state["lock"]:
            stack = state.setdefault("resource_context_stack", [])
            for index in range(len(stack) - 1, -1, -1):
                if stack[index].get("token") is context["token"]:
                    stack.pop(index)
                    break
            state["resource_capture_depth"] = max(0, int(state.get("resource_capture_depth", 0)) - 1)


def _cleanup_resource_records(prefix: str):
    """Release exact legacy resource receipts owned by *prefix*.

    New code does not populate these status records.  They are retained only to
    clean up an interrupted 1.3.54-or-earlier capture.  No module/name/category
    scan is performed and foreign resources are never touched.
    """
    if bpy is None:
        return 0
    state = _state()
    timer_records = []
    draw_records = []
    with state["lock"]:
        for key, record in tuple(state.setdefault("timer_records", {}).items()):
            if not isinstance(record, dict):
                continue
            if prefix and str(record.get("suite_id", "") or "") != str(prefix):
                continue
            timer_records.append((key, record))
        for key, record in tuple(state.setdefault("draw_records", {}).items()):
            if not isinstance(record, dict):
                continue
            if prefix and str(record.get("suite_id", "") or "") != str(prefix):
                continue
            draw_records.append((key, record))

    removed = 0
    for key, record in reversed(timer_records):
        callback = record.get("original")
        is_registered = record.get("native_is_registered")
        unregister = record.get("native_unregister")
        try:
            if callable(callback) and callable(is_registered) and callable(unregister) and is_registered(callback):
                unregister(callback)
                removed += 1
        except Exception:
            pass
        with state["lock"]:
            if state.setdefault("timer_records", {}).get(key) is record:
                state["timer_records"].pop(key, None)
        clear(str(record.get("owner", "") or ""))

    for key, record in reversed(draw_records):
        handle = record.get("handle")
        native_remove = record.get("native_remove")
        region_type = record.get("region_type", "WINDOW")
        if not callable(native_remove):
            space_cls = record.get("space_cls")
            native_remove = getattr(space_cls, "draw_handler_remove", None) if space_cls is not None else None
        try:
            if handle is not None and callable(native_remove):
                native_remove(handle, region_type)
                removed += 1
        except Exception:
            pass
        with state["lock"]:
            if state.setdefault("draw_records", {}).get(key) is record:
                state["draw_records"].pop(key, None)
        clear(str(record.get("owner", "") or ""))

    # Retire the exact legacy monitor function when it has no records to watch.
    with state["lock"]:
        monitor_fn = state.get("resource_monitor_fn")
        has_records = bool(state.setdefault("timer_records", {}) or state.setdefault("draw_records", {}))
    if callable(monitor_fn) and not has_records:
        try:
            timers = bpy.app.timers
            if timers.is_registered(monitor_fn):
                timers.unregister(monitor_fn)
                removed += 1
        except Exception:
            pass
        with state["lock"]:
            state["resource_monitor_registered"] = False
    _remove_global_draw_boundary_handlers_if_unused()
    return removed


def _callback_invocation_adapter(callback):
    """Return a safe positional/keyword adapter for Blender callbacks.

    Blender 5.1 may pass more positional values to application handlers than
    older handlers declared.  Calling the original callback with every value
    breaks otherwise valid ``def handler(_dummy=None)`` functions.  Inspect the
    original signature once and trim only the surplus arguments.  We do not
    catch ``TypeError`` from the callback itself, because doing so would hide
    genuine implementation errors raised inside the handler.
    """
    try:
        signature = inspect.signature(callback)
    except (TypeError, ValueError):
        return None

    positional = []
    keyword_names = set()
    accepts_varargs = False
    accepts_varkw = False
    for parameter in signature.parameters.values():
        if parameter.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            positional.append(parameter)
        if parameter.kind in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            keyword_names.add(parameter.name)
        elif parameter.kind is inspect.Parameter.VAR_POSITIONAL:
            accepts_varargs = True
        elif parameter.kind is inspect.Parameter.VAR_KEYWORD:
            accepts_varkw = True

    return {
        "max_positional": None if accepts_varargs else len(positional),
        "positional_names": tuple(
            parameter.name
            for parameter in positional
            if parameter.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
        ),
        "keyword_names": None if accepts_varkw else frozenset(keyword_names),
    }


def _adapt_callback_invocation(args, kwargs, adapter):
    if not adapter:
        return tuple(args), dict(kwargs)

    max_positional = adapter.get("max_positional")
    call_args = tuple(args) if max_positional is None else tuple(args[:max_positional])

    keyword_names = adapter.get("keyword_names")
    if keyword_names is None:
        call_kwargs = dict(kwargs)
    else:
        call_kwargs = {key: value for key, value in kwargs.items() if key in keyword_names}

    # Avoid passing a positional-or-keyword parameter twice.
    positional_names = adapter.get("positional_names") or ()
    for name in positional_names[:len(call_args)]:
        call_kwargs.pop(name, None)
    return call_args, call_kwargs


def _run_callback_with_status(callback, args, kwargs, *, owner: str, suite_label: str,
                              kind_en: str, kind_ja: str):
    suite_id = str(owner or "").split('.', 1)[0]
    # During add-on registration one parent status already names the complete
    # operation.  Thousands of RNA default/update callbacks must not each take
    # the shared lock or replace the status text; that was measurable startup
    # latency and made heavy workspaces several seconds slower.
    if _suite_registration_active(suite_id):
        return callback(*args, **kwargs)
    context = None
    for value in args:
        if value is not None and hasattr(value, "workspace") and hasattr(value, "window_manager"):
            context = value
            break
    label = _callback_display_name(callback)
    text = (
        f"{_translated_label(suite_label)}: {kind_ja}「{_translated_label(label)}」を実行中…"
        if _is_japanese(context)
        else f"{_translated_label(suite_label)}: Running {kind_en} “{_translated_label(label)}”…"
    )
    token = begin_task(owner, text, context=context)
    try:
        with capture_runtime_resources(suite_id, suite_label):
            return callback(*args, **kwargs)
    except Exception:
        finish_task(token, _operator_status_text(suite_label, label, "error", context), duration=2.5, context=context)
        raise
    finally:
        # If the error path already removed the token this is a no-op.
        finish_task(token, context=context)


def _increment_stat(suite_id: str, key: str, amount: int = 1) -> None:
    try:
        state = _state()
        with state["lock"]:
            suite_stats = state.setdefault("stats", {}).setdefault(suite_id, {})
            suite_stats[key] = int(suite_stats.get(key, 0)) + int(amount)
    except Exception:
        pass


def _wrap_property_callback(callback, suite_id: str, suite_label: str, callback_kind: str):
    if not callable(callback):
        return callback
    try:
        if bool(getattr(callback, "_jelararagi_status_property_wrapper_v2", False)):
            return callback
    except Exception:
        pass
    owner = f"{suite_id}.property.{callback_kind}"
    if callback_kind == "update":
        def wrapped(self, context):
            return _run_callback_with_status(
                callback, (self, context), {}, owner=owner,
                suite_label=suite_label, kind_en="property update", kind_ja="設定更新",
            )
    elif callback_kind == "set":
        def wrapped(self, value):
            return _run_callback_with_status(
                callback, (self, value), {}, owner=owner,
                suite_label=suite_label, kind_en="property setter", kind_ja="設定書き込み",
            )
    elif callback_kind == "search":
        def wrapped(self, context, edit_text):
            return _run_callback_with_status(
                callback, (self, context, edit_text), {}, owner=owner,
                suite_label=suite_label, kind_en="property search", kind_ja="設定検索",
            )
    else:
        return callback
    try:
        wrapped.__name__ = getattr(callback, "__name__", callback_kind)
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped._jelararagi_status_property_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = callback
    except Exception:
        pass
    _increment_stat(suite_id, f"property_{callback_kind}")
    return wrapped


def _wrap_msgbus_notify(callback, suite_id: str, suite_label: str):
    if not callable(callback):
        return callback
    try:
        if bool(getattr(callback, "_jelararagi_status_msgbus_wrapper_v2", False)):
            return callback
    except Exception:
        pass
    owner = f"{suite_id}.msgbus"
    def wrapped(*args, **kwargs):
        return _run_callback_with_status(
            callback, args, kwargs, owner=owner,
            suite_label=suite_label, kind_en="message-bus callback", kind_ja="メッセージ通知",
        )
    try:
        wrapped.__name__ = getattr(callback, "__name__", "msgbus_notify")
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped._jelararagi_status_msgbus_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = callback
    except Exception:
        pass
    _increment_stat(suite_id, "msgbus_notify")
    return wrapped


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    """Registration status boundary without replacing shared Blender APIs.

    Classes and properties are sanitized explicitly by the Suite's registration
    helpers.  This context only tracks nesting and the visible registration task.
    """
    restore_legacy_process_api_receipts()
    state = _state()
    with state["lock"]:
        depths = state.setdefault("registration_depth", {})
        depths[suite_id] = int(depths.get(suite_id, 0)) + 1
    registration_token = begin_task(
        f"{suite_id}.registration",
        (f"{_translated_label(suite_label)}: 登録処理を実行中…"
         if _is_japanese(None) else f"{_translated_label(suite_label)}: Registering…"),
    )
    try:
        yield
    finally:
        with state["lock"]:
            depths = state.setdefault("registration_depth", {})
            remaining = max(0, int(depths.get(suite_id, 0)) - 1)
            if remaining:
                depths[suite_id] = remaining
            else:
                depths.pop(suite_id, None)
        finish_task(registration_token)


def _handler_lists():
    """Yield only Blender handler collections known to Smart Modeling.

    The previous implementation traversed every attribute on ``bpy.app.handlers``
    and later used callback names/module strings as ownership evidence.  Handler
    ownership is now established exclusively by an exact before/after receipt
    captured around this Suite's synchronous register transaction.
    """
    if bpy is None:
        return
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is None:
        return
    for name in (
        "animation_playback_pre", "animation_playback_post",
        "blend_import_pre", "blend_import_post",
        "composite_pre", "composite_post", "composite_cancel",
        "depsgraph_update_pre", "depsgraph_update_post",
        "exit_pre", "quit_pre",
        "extension_repos_update_pre", "extension_repos_update_post",
        "frame_change_pre", "frame_change_post",
        "load_factory_preferences_post", "load_factory_startup_post",
        "load_pre", "load_post",
        "object_bake_pre", "object_bake_complete", "object_bake_cancel",
        "redo_pre", "redo_post",
        "render_init", "render_pre", "render_post", "render_write",
        "render_complete", "render_cancel", "render_stats",
        "save_pre", "save_post", "save_post_fail",
        "translation_update_post",
        "undo_pre", "undo_post", "version_update", "xr_session_start_pre",
    ):
        try:
            value = getattr(handlers, name, None)
        except Exception:
            value = None
        if isinstance(value, list):
            yield name, value


def _identity_count(values, target) -> int:
    return sum(1 for value in tuple(values) if value is target)


def _remove_one_identity(collection, target) -> bool:
    """Remove one exact callback occurrence, preferring the latest receipt."""
    try:
        for index in range(len(collection) - 1, -1, -1):
            if collection[index] is target:
                collection.pop(index)
                return True
    except Exception:
        pass
    return False


def _handler_generation_store(state=None):
    state = _state() if state is None else state
    return state.setdefault("handler_generations", {})


def begin_handler_generation(suite_id: str, owner_uuid: str):
    """Start an exact handler-registration transaction.

    The token captures list objects and callback identities before the Suite's
    register function runs.  No Blender API is replaced or wrapped.
    """
    state = _state()
    with state["lock"]:
        sequence = int(state.get("handler_generation_sequence", 0)) + 1
        state["handler_generation_sequence"] = sequence
    baseline = []
    for handler_name, handler_list in _handler_lists() or ():
        baseline.append({
            "handler_name": handler_name,
            "list": handler_list,
            "callbacks": tuple(handler_list),
        })
    return {
        "suite_id": str(suite_id or ""),
        "owner_uuid": str(owner_uuid or ""),
        "generation": sequence,
        "baseline": tuple(baseline),
        "committed": False,
    }


def _collect_handler_additions(token):
    records = []
    order = 0
    for baseline in tuple((token or {}).get("baseline", ()) or ()):
        handler_list = baseline.get("list")
        if not isinstance(handler_list, list):
            continue
        baseline_callbacks = tuple(baseline.get("callbacks", ()) or ())
        baseline_counts = {}
        for callback in baseline_callbacks:
            key = id(callback)
            item = baseline_counts.get(key)
            if item is None:
                baseline_counts[key] = [callback, 1]
            elif item[0] is callback:
                item[1] += 1
        seen_counts = {}
        for index, callback in enumerate(tuple(handler_list)):
            key = id(callback)
            seen = seen_counts.get(key)
            if seen is None:
                seen_counts[key] = [callback, 1]
                occurrence = 1
            elif seen[0] is callback:
                seen[1] += 1
                occurrence = seen[1]
            else:
                # ``id`` reuse cannot occur while both objects are strongly held,
                # but keep the comparison identity-safe for synthetic test doubles.
                occurrence = 1
            baseline_item = baseline_counts.get(key)
            baseline_count = baseline_item[1] if baseline_item and baseline_item[0] is callback else 0
            if occurrence <= baseline_count:
                continue
            order += 1
            records.append({
                "handler_name": str(baseline.get("handler_name", "") or ""),
                "list": handler_list,
                "callback": callback,
                "registered_index": int(index),
                "receipt_order": int(order),
            })
    return records


def commit_handler_generation(token):
    """Commit exact callbacks added by one successful register transaction."""
    if not isinstance(token, dict) or bool(token.get("committed", False)):
        return None
    suite_id = str(token.get("suite_id", "") or "")
    owner_uuid = str(token.get("owner_uuid", "") or "")
    generation = int(token.get("generation", 0) or 0)
    records = _collect_handler_additions(token)
    state = _state()
    with state["lock"]:
        suite_store = _handler_generation_store(state).setdefault(suite_id, {})
        suite_store[generation] = {
            "suite_id": suite_id,
            "owner_uuid": owner_uuid,
            "generation": generation,
            "records": records,
        }
    token["committed"] = True
    token["records"] = records
    return generation


def rollback_handler_generation(token) -> int:
    """Rollback only callbacks added after this token's exact baseline."""
    if not isinstance(token, dict):
        return 0
    records = token.get("records") if bool(token.get("committed", False)) else None
    if not isinstance(records, list):
        records = _collect_handler_additions(token)
    removed = 0
    for record in reversed(tuple(records)):
        if _remove_one_identity(record.get("list"), record.get("callback")):
            removed += 1
    if bool(token.get("committed", False)):
        state = _state()
        suite_id = str(token.get("suite_id", "") or "")
        generation = int(token.get("generation", 0) or 0)
        with state["lock"]:
            suite_store = _handler_generation_store(state).get(suite_id, {})
            suite_store.pop(generation, None)
            if not suite_store:
                _handler_generation_store(state).pop(suite_id, None)
    token["committed"] = False
    return removed


def release_handler_generations(suite_id: str, owner_uuid: Optional[str] = None,
                                generation: Optional[int] = None) -> int:
    """Release exact callbacks owned by committed Smart Modeling receipts.

    Foreign callbacks are never searched by name, module, prefix, attributes, or
    equality.  Only the exact list/callback pairs captured during registration
    are removed, in reverse receipt order.
    """
    state = _state()
    removed = 0
    with state["lock"]:
        suite_store = dict(_handler_generation_store(state).get(str(suite_id or ""), {}))
    for generation_id in sorted(suite_store, reverse=True):
        if generation is not None and int(generation_id) != int(generation):
            continue
        receipt = suite_store[generation_id]
        if owner_uuid is not None and str(receipt.get("owner_uuid", "") or "") != str(owner_uuid):
            continue
        for record in reversed(tuple(receipt.get("records", ()) or ())):
            if _remove_one_identity(record.get("list"), record.get("callback")):
                removed += 1
        with state["lock"]:
            live_store = _handler_generation_store(state).get(str(suite_id or ""), {})
            live_store.pop(generation_id, None)
            if not live_store:
                _handler_generation_store(state).pop(str(suite_id or ""), None)
    return removed


def handler_generation_snapshot(suite_id: str):
    """Return a metadata-only snapshot for audit/UI diagnostics."""
    state = _state()
    result = []
    with state["lock"]:
        suite_store = dict(_handler_generation_store(state).get(str(suite_id or ""), {}))
    for generation_id, receipt in sorted(suite_store.items()):
        result.append({
            "suite_id": str(receipt.get("suite_id", "") or ""),
            "owner_uuid": str(receipt.get("owner_uuid", "") or ""),
            "generation": int(generation_id),
            "handlers": [
                {
                    "handler_name": str(record.get("handler_name", "") or ""),
                    "callback_id": int(id(record.get("callback"))),
                    "list_id": int(id(record.get("list"))),
                }
                for record in tuple(receipt.get("records", ()) or ())
            ],
        })
    return result


def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None) -> int:
    """Compatibility no-op.

    Smart Modeling no longer creates persistent status-marker handlers, so no
    process-global marker scan is permitted or required.
    """
    del suite_id
    return 0


def _restore_missing_persistent_handler_markers() -> int:
    return 0


def _global_persistent_handler_prune_load_post(_filepath=None, *_args):
    """Legacy symbol retained for old callback receipts; never registered."""
    return None


def _ensure_global_persistent_handler_prune_callback() -> None:
    return None


def _remove_global_persistent_handler_prune_if_unused() -> None:
    state = _state()
    receipt = state.pop("global_persistent_prune_receipt", None)
    if not isinstance(receipt, dict):
        return
    _remove_one_identity(receipt.get("list"), receipt.get("callback"))


def instrument_loaded_package_handlers(package_marker: str, suite_id: str,
                                       suite_label: str) -> int:
    """Compatibility no-op: handler status wrapping is intentionally disabled.

    Operator status instrumentation remains available.  Handler wrappers were
    removed because they alter callback identity and can outlive add-on disable.
    """
    del package_marker, suite_id, suite_label
    return 0


def _legacy_global_prune_from_record(record):
    wrapper = record.get("wrapper") if isinstance(record, dict) else None
    namespace = getattr(wrapper, "__globals__", None)
    if not isinstance(namespace, dict):
        return None
    callback = namespace.get("_global_persistent_handler_prune_load_post")
    return callback if callable(callback) else None


def restore_package_handlers(suite_id: str) -> int:
    """Remove legacy handler wrappers using their exact persisted receipts only.

    This is a one-way compatibility cleanup for 1.3.52 and earlier.  It never
    scans callback names, module strings, package prefixes, or foreign handler
    attributes.  The exact wrapper/original/list relation recorded by the old
    status runtime is the sole ownership evidence.
    """
    state = _state()
    mappings = state.setdefault("handler_wrappers", {})
    removed = 0
    global_candidates = []
    matching_keys = []
    for key, record in tuple(mappings.items()):
        if not isinstance(record, dict) or str(record.get("suite_id", "") or "") != str(suite_id or ""):
            continue
        matching_keys.append(key)
        candidate = _legacy_global_prune_from_record(record)
        if callable(candidate) and not any(candidate is item for item in global_candidates):
            global_candidates.append(candidate)
        handler_list = record.get("list")
        wrapper = record.get("wrapper")
        original = record.get("original")
        while _remove_one_identity(handler_list, wrapper):
            removed += 1
        # A proxy could have been restored by an older partial cleanup.  Because
        # this record is exact ownership evidence for the old Suite generation,
        # remove that exact original as well before the new generation registers.
        while _remove_one_identity(handler_list, original):
            removed += 1
        for attr_name in (
            "_jelararagi_status_suite_id_v3",
            "_jelararagi_status_suite_label_v3",
            "_jelararagi_status_package_marker_v3",
        ):
            try:
                if original is not None and hasattr(original, attr_name):
                    delattr(original, attr_name)
            except Exception:
                pass
        try:
            clear(str(record.get("owner", "") or ""))
        except Exception:
            pass
    for key in matching_keys:
        mappings.pop(key, None)

    # Remove the old global prune callback only through the exact function object
    # recovered from a removed wrapper's globals, and only when no remaining
    # persistent-marker receipt still depends on that same callback.
    for callback in global_candidates:
        still_needed = False
        for record in tuple(mappings.values()):
            if not isinstance(record, dict) or record.get("mode") != "persistent_marker":
                continue
            if _legacy_global_prune_from_record(record) is callback:
                still_needed = True
                break
        if still_needed:
            continue
        handlers = getattr(getattr(getattr(bpy, "app", None), "handlers", None), "load_post", None) if bpy is not None else None
        while _remove_one_identity(handlers, callback):
            removed += 1
    return removed
