import bpy, mathutils
from . import util

bl_info = {
    'name': 'Curve Remove Doubles',
    'author': 'Michael Soluyanov',
    'version': (1, 1),
    'blender': (2, 80, 0),
    'location': 'View3D > Context menu (W/RMB) > Remove Doubles',
    'description': 'Adds command "Remove Doubles" for curves',
    'category': 'Add Curve'
}

def _weld_spline(spline, distance):
    bezier = spline.type == 'BEZIER'
    points = tuple(spline.bezier_points if bezier else spline.points)
    if len(points) < 2:
        return []

    selection = 'select_control_point' if bezier else 'select'
    previous = points[-1] if spline.use_cyclic_u else None
    deletion = []
    for point in points:
        if point is previous:
            continue
        adjacent_selection = (
            previous is not None and not previous.hide and not point.hide
            and getattr(previous, selection) and getattr(point, selection)
        )
        if adjacent_selection:
            if (point.co - previous.co).length < distance:
                if bezier:
                    previous.handle_right_type = 'FREE'
                    previous.handle_right = point.handle_right
                previous.co = (previous.co + point.co) * 0.5
                deletion.append((point, selection))
                continue
            if bezier:
                if point.handle_left_type == 'VECTOR' and (previous.handle_right - previous.co).length < distance:
                    previous.handle_right_type = 'VECTOR'
                if previous.handle_right_type == 'VECTOR' and (point.handle_left - point.co).length < distance:
                    point.handle_left_type = 'VECTOR'
        previous = point
    return deletion


def main(context, distance=0.01):
    if context.mode != 'EDIT_CURVE':
        bpy.ops.object.mode_set(mode='EDIT')

    # Edit curves can share RNA data. Collect every deletion before asking
    # Blender to remove vertices once across the whole edit session.
    deletion = [
        entry
        for obj in context.objects_in_mode_unique_data
        for spline in obj.data.splines
        for entry in _weld_spline(spline, distance)
    ]
    bpy.ops.curve.select_all(action='DESELECT')
    if deletion:
        for point, selection in deletion:
            setattr(point, selection, True)
        bpy.ops.curve.delete(type='VERT')
        bpy.ops.curve.select_all(action='DESELECT')
    return len(deletion)


class CurveRemvDbs(bpy.types.Operator):
    """Merge consecutive points that are near to each other"""
    bl_idname = 'curvetools.remove_doubles'
    bl_label = 'Remove Doubles'
    bl_options = {'UNDO'}

    distance: bpy.props.FloatProperty(name = 'Distance', default = 0.01)

    @classmethod
    def poll(cls, context):
        return util.Selected1OrMoreCurves()

    def execute(self, context):
        removed=main(context, self.distance)
        self.report({'INFO'}, "Removed %d bezier points" % removed)
        return {'FINISHED'}



def menu_func(self, context):
    self.layout.operator(CurveRemvDbs.bl_idname, text='Remove Doubles')

def register():
    bpy.utils.register_class(CurveRemvDbs)
    bpy.types.VIEW3D_MT_edit_curve_context_menu.append(menu_func)

def unregister():
    bpy.utils.unregister_class(CurveRemvDbs)
    bpy.types.VIEW3D_MT_edit_curve_context_menu.remove(menu_func)

if __name__ == "__main__":
    register()

operators = [CurveRemvDbs]
