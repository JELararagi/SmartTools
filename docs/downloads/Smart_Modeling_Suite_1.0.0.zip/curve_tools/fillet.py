bl_info = {
    'name': 'Curve Fillet',
    'author': 'Spivak Vladimir (cwolf3d)',
    'version': (0, 0, 1),
    'blender': (2, 80, 0),
    'location': 'Curve Tools addon. (N) Panel',
    'description': 'Various types of fillet (chamfering)',
    'warning': '', # used for warning icon and text in addons panel
    'doc_url': '',
    'tracker_url': '',
    'category': 'Curve',
}


import bpy
from bpy.props import *
from bpy_extras import object_utils, view3d_utils
from mathutils import  *
from math import  *

def click(self, context, event):
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.context.view_layer.update()


def remove_handler(handlers):
    for handler in handlers:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        except:
            pass
    for handler in handlers:
        handlers.remove(handler)


class Fillet(bpy.types.Operator):
    bl_idname = "curvetools.fillet"
    bl_label = "Curve Fillet"
    bl_description = "Curve Fillet"
    bl_options = {'UNDO'}

    x: IntProperty(name="x", description="x")
    y: IntProperty(name="y", description="y")
    location3D: FloatVectorProperty(name = "",
                description = "Start location",
                default = (0.0, 0.0, 0.0),
                subtype = 'XYZ')

    handlers = []

    # Keep the legacy public ID as an alias of the working panel command.
    # The former modal implementation only selected points and never filleted.
    Fillet_radius: FloatProperty(name="Radius", default=0.25, unit='LENGTH')
    Fillet_Type: EnumProperty(name="Type", items=[
        ('Round', "Round", "Round"), ('Chamfer', "Chamfer", "Chamfer")])

    def draw(self, context):
        self.layout.prop(self, "Fillet_radius")
        self.layout.prop(self, "Fillet_Type", expand=True)

    def execute(self, context):
        return bpy.ops.curvetools.bezier_points_fillet(
            'EXEC_DEFAULT', Fillet_radius=self.Fillet_radius,
            Fillet_Type=self.Fillet_Type)

    def invoke(self, context, event):
        return self.execute(context)

    @classmethod
    def poll(cls, context):
        return (context.object is not None and
                context.object.type == 'CURVE')

def register():
    for cls in classes:
        bpy.utils.register_class(operators)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(operators)

if __name__ == "__main__":
    register()

operators = [Fillet]
