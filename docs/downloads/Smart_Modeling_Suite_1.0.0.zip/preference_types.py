# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    StringProperty,
)


class SMS_MSAP_AddonPreferencesProxy(bpy.types.PropertyGroup):
    """Lightweight proxy for Mesh Align suite settings."""
    pass


class SMS_CreasePresetItemProxy(bpy.types.PropertyGroup):
    label: StringProperty(default="")
    value: FloatProperty(default=0.0, min=0.0, max=1.0)
    apply_mode: EnumProperty(
        items=[('SELECTED', 'Selected', ''), ('LINKED', 'Linked', '')],
        default='SELECTED',
    )


class SMS_CreasePresetPreferencesProxy(bpy.types.PropertyGroup):
    use_pie_menu: BoolProperty(name="Use Pie Menu", default=False)
    linked_delimit_seam: BoolProperty(name="Delimit by Seam", default=False)
    linked_delimit_sharp: BoolProperty(name="Delimit by Sharp", default=False)
    linked_delimit_material: BoolProperty(name="Delimit by Material", default=False)
    sel_count: IntProperty(name="Button Count (Selected)", default=4, min=0, max=10)
    sel_values: FloatVectorProperty(
        name="Values (Selected)",
        size=10,
        default=(0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        min=0.0,
        max=1.0,
    )
    link_count: IntProperty(name="Button Count (Linked)", default=4, min=0, max=10)
    link_values: FloatVectorProperty(
        name="Values (Linked)",
        size=10,
        default=(0.0, 0.25, 0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        min=0.0,
        max=1.0,
    )
    active_crease_value: FloatProperty(
        name="Selected Edge Crease",
        description="Shows the selected edge crease value. With multiple selected edges it stores their average; editing applies through the loaded Crease Preset tool when available.",
        default=0.0,
        min=0.0,
        max=1.0,
        precision=4,
    )
    select_crease_value: FloatProperty(
        name="Crease Value to Select",
        description="Value used when selecting all edges whose crease matches the specified number. When it has not been typed manually in the popup, Crease Preset fills it from the selected edge crease value.",
        default=0.0,
        min=0.0,
        max=1.0,
        precision=4,
    )
    match_tolerance: FloatProperty(
        name="Crease Match Tolerance",
        description="Tolerance used when selecting all edges that have the same crease value as the value field.",
        default=0.0001,
        min=0.0,
        max=0.25,
        precision=5,
    )
    approx_match_tolerance: FloatProperty(
        name="Approximate Paste Tolerance",
        description="Tolerance used when approximate crease paste matches edges by relative position, direction angle, and length.",
        default=0.18,
        min=0.001,
        max=2.0,
        precision=3,
    )


class SMS_AWN_AddonPreferencesProxy(bpy.types.PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        description="Choose the preset used when creating the Weighted Normal modifier.",
        items=[
            ('HARD_SURFACE', 'Hard Surface Modeling', ''),
            ('GAME', 'Game Asset', ''),
            ('MINIMAL', 'Minimal', ''),
            ('CUSTOM', 'Custom', ''),
        ],
        default='HARD_SURFACE',
    )
    apply_mode: EnumProperty(
        name="Apply Mode",
        description="Choose whether the modifier is applied immediately or kept non-destructive.",
        items=[
            ('ADD_AND_APPLY', 'Add & Apply', ''),
            ('ADD_ONLY', 'Add Only', ''),
        ],
        default='ADD_AND_APPLY',
    )
    limit_to_selection: BoolProperty(
        name="Limit To Selection",
        description="Compatibility option kept for the suite UI. This migrated version applies Weighted Normal to the whole object.",
        default=False,
    )
    keep_sharp: BoolProperty(
        name="Keep Sharp",
        description="Keep sharp edges enabled when creating the modifier.",
        default=True,
    )
    weight: FloatProperty(
        name="Weight",
        description="Weight value used by the created modifier.",
        default=50.0,
        min=1.0,
        max=100.0,
    )
    threshold: FloatProperty(
        name="Threshold",
        description="Threshold used by the created modifier.",
        default=0.01,
        min=0.0,
        max=10.0,
        precision=4,
    )


_SMS_TAMS_SNAP_ELEMENTS_ITEMS = [
    ("VERTEX", "Vertex", ""),
    ("EDGE", "Edge", ""),
    ("FACE", "Face", ""),
    ("INCREMENT", "Increment", ""),
]


class SMS_TAMS_CycleItemProxy(bpy.types.PropertyGroup):
    element: EnumProperty(
        name="Element",
        items=_SMS_TAMS_SNAP_ELEMENTS_ITEMS,
        default="VERTEX",
        description="Snap element stored in this cycle slot. The cycle operator will switch to this element when the slot becomes active.",
    )


class SMS_TAMS_PrefsProxy(bpy.types.PropertyGroup):
    toggle_basis: EnumProperty(
        name="Toggle Basis",
        description="Choose which state is treated as the main reference when the tool toggles Auto Merge and Snap together.",
        items=[
            ("AUTO_MERGE", "Auto Merge", ""),
            ("SNAP", "Snap", ""),
            ("EITHER_ON", "Either ON", ""),
            ("BOTH_ON", "Both ON", ""),
        ],
        default="AUTO_MERGE",
    )
    snap_enable_mode: EnumProperty(
        name="Snap Enable Mode",
        description="Choose which snap elements should become active when this tool turns snapping on.",
        items=[
            ("FORCE_VERTEX", "Force Vertex", ""),
            ("KEEP_CURRENT", "Keep Current", ""),
            ("CUSTOM_SET", "Custom Set", ""),
        ],
        default="FORCE_VERTEX",
    )
    custom_snap_elements: EnumProperty(
        name="Custom Snap Elements",
        description="Snap elements that will be enabled when Snap Enable Mode is set to Custom Set.",
        items=_SMS_TAMS_SNAP_ELEMENTS_ITEMS,
        options={"ENUM_FLAG"},
        default={"VERTEX"},
    )
    repeat_action_when_on: EnumProperty(
        name="Repeat Action When Already ON",
        description="Choose what the main toggle should do if the managed state is already on and you press it again without modifier keys.",
        items=[
            ("TOGGLE_OFF", "Toggle OFF", ""),
            ("CYCLE", "Cycle Snap Elements", ""),
        ],
        default="TOGGLE_OFF",
    )
    enable_cycling: BoolProperty(
        name="Enable Cycling",
        description="Enable or disable the custom snap-element cycle list. When enabled, the cycle operator follows the order shown below.",
        default=True,
    )
    cycle_order: CollectionProperty(
        type=SMS_TAMS_CycleItemProxy,
        description='Collection for Cycle Order. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.',
    )
    cycle_order_index: IntProperty(
        default=0,
        description='Adjust Cycle Order Index. Larger or smaller values change the strength, amount, size, or precision used by the related tool.',
    )
    show_header_indicator: BoolProperty(
        name="Show Header Indicator",
        description="Show a small status hint in supported headers so you can see the managed Auto Merge / Snap state at a glance.",
        default=False,
    )
    status_bar_indicator: EnumProperty(
        name="Show Status Bar Indicator",
        description="Choose when the status bar indicator should be visible: never, only after reports, or always.",
        items=[
            ("OFF", "Off", ""),
            ("TEMP", "Temporary (reports)", ""),
            ("ALWAYS", "Always", ""),
        ],
        default="TEMP",
    )
    enable_n_panel: BoolProperty(
        name="Enable N-panel",
        description="Show a compact helper panel for this tool in the 3D View N-panel. Useful if you want mouse-accessible controls instead of relying only on shortcuts.",
        default=False,
    )
    debug_logging: BoolProperty(
        name="Debug Logging",
        description="Print extra diagnostic information to Blender's system console. Enable this only when you are troubleshooting the tool.",
        default=False,
    )
