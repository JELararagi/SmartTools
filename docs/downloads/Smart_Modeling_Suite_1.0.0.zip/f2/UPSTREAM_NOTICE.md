# F2 Source Evidence

Compared upstream author field: Bart Crouch, Alexander Nedovizin, Paul Kotelevets (concept design), Adrian Rutkowski
Compared source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/mesh_f2.py
Comparison commit: b42d68627734cb18af0e6f41537063984313a284
Comparison-source version: 1.8.4

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2013-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

The bounded comparison with SmartModeling1.3.105 found 4 exactly matching nontrivial function ASTs in f2/__init__.py. The complete files are not byte-identical or identical after line-ending normalization. AST matching includes identifiers and docstrings, excludes source positions, and requires at least30 AST nodes.

The original acquired archive/version and the origin of all other code have not been established. The comparison-source version is not a verified bundled-version claim. This notice preserves observed upstream declarations; it does not replace the full license terms, change existing code or headers, or establish complete attribution, license/source-offer compliance or sales clearance.
