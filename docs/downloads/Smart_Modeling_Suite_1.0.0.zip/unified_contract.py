CONTRACT_VERSION = 3
EXTENSION_ID = "smart_modeling_suite"
CONFIG_FOLDER = "Smart_Modeling_Suite"
CONFIG_FILE = "Smart_Modeling_Suite.json"
STATE_SAVE_PATH = "window_manager.smart_modeling_suite_npanel_settings.n_panel_state_save"
SECTION_OPEN_PATH = "window_manager.smart_modeling_suite_npanel_settings.ui_show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.smart_modeling_suite_npanel_settings.enable_vertex_copy",
    "window_manager.smart_modeling_suite_npanel_settings.enable_tool_key_operators_toolkit",
    "window_manager.smart_modeling_suite_npanel_settings.enable_vertex_slide",
    "window_manager.smart_modeling_suite_npanel_settings.enable_toggle_auto_merge_snap",
    "window_manager.smart_modeling_suite_npanel_settings.enable_direct_delete",
    "window_manager.smart_modeling_suite_npanel_settings.enable_apply_weighted_normal",
    "window_manager.smart_modeling_suite_npanel_settings.enable_archimesh_hint_overlay",
    "window_manager.smart_modeling_suite_npanel_settings.enable_tool_tissue",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
DYNAMIC_RUNTIME_TOGGLE_PATHS = (
    # Registered only after the Key Operation Tools settings are explicitly
    # opened/materialized.  This is the original Polycount Auto Update RNA, not
    # a proxy Bool, so the local row and the canonical top row stay identical.
    "scene.polycount_props.auto_update_polycount",
    # Vertex Copy's three preview modes each own a SpaceView3D draw handler.
    # The properties appear only after the lazy Vertex Copy owner is
    # materialized; both the local controls and top Always-on rows use these
    # exact RNA paths, and every property defaults to OFF.
    "scene.vscp_settings.show_gpu_preview",
    "scene.vscpx_settings.enable_advanced_preview",
    "scene.vscpz_settings.show_mapping_edit_overlay",
)
RESIDENT_RESOURCE_CONTROLS = (
    {"path": "window_manager.smart_modeling_suite_npanel_settings.n_panel_state_save", "resources": ("msgbus", "save_pre_handler"), "owner": "suite_settings_persistence"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_vertex_copy", "resources": ("draw_handlers",), "owner": "vertex_copy"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_tool_key_operators_toolkit", "resources": ("handlers", "menu_hooks"), "owner": "key_operators_toolkit"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_vertex_slide", "resources": ("draw_handlers", "timers", "header_status"), "owner": "vertex_slide"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_toggle_auto_merge_snap", "resources": ("header_status",), "owner": "toggle_auto_merge_snap"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_direct_delete", "resources": ("draw_handlers",), "owner": "direct_delete"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_apply_weighted_normal", "resources": ("menu_hooks",), "owner": "apply_weighted_normal"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_archimesh_hint_overlay", "resources": ("draw_handlers",), "owner": "archimesh_hint_overlay"},
    {"path": "window_manager.smart_modeling_suite_npanel_settings.enable_tool_tissue", "resources": ("handlers",), "owner": "tissue"},
    {"path": "scene.polycount_props.auto_update_polycount", "resources": ("event_refresh",), "owner": "polycount"},
    {"path": "scene.vscp_settings.show_gpu_preview", "resources": ("draw_handlers",), "owner": "vertex_copy.core"},
    {"path": "scene.vscpx_settings.enable_advanced_preview", "resources": ("draw_handlers",), "owner": "vertex_copy.extension"},
    {"path": "scene.vscpz_settings.show_mapping_edit_overlay", "resources": ("draw_handlers",), "owner": "vertex_copy.extension_lines"},
)
LIFECYCLE_SAFETY_RESOURCES = (
    {"event": "load_pre", "callback": "_sms_load_pre_runtime_safety", "purpose": "cancel_on_demand_and_refresh_without_rna_or_settings_io"},
    {"event": "load_post", "callback": "_sms_load_post_runtime_refresh", "purpose": "rearm_namespace_and_schedule_safe_restore"},
    {"event": "exit_pre", "callback": "_sms_exit_pre_runtime_safety", "purpose": "cleanup_owned_transient_resources"},
)
PERSISTENCE_ROOTS = (
    "window_manager.smart_modeling_suite_npanel_settings",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    # Native/integrated tools register these settings only when explicitly
    # loaded.  common.sync_persistence_subscriptions() observes them at that
    # boundary without an idle polling loop.
    "scene.smsk_props",
    "scene.meshfixtool_properties",
    # Lazy architecture / mesh-edit / repair N-panel settings.  These are
    # user-facing preferences and therefore use the suite's portable external
    # JSON rather than relying on whichever .blend happened to be open.
    "scene.archimesh_*",
    "scene.mesh_extra_tools",
    "scene.fix_wizard_properties",
    "scene.snow",
    "window_manager.mio3ce",
    "scene.qsd_*",
    "window_manager.looptools",
    "window_manager.direct_delete_settings",
    "window_manager.ivy_gen_props",
    "scene.vscpy_settings",
    "scene.vscpz_settings",
    "scene.vscp_settings",
    "scene.vscpx_settings",
    "scene.mo2_props",
    "scene.mo2_backup_items",
    "window_manager.edittools",
    "scene.scatter_properties",
    "scene.align_slide_props",
    "window_manager.auto_loft",
    "scene.curvetools",
    "scene.tams_state",
    # Key Operators Toolkit direct RNA and property groups.
    "scene.auto_focus_in_outliner",
    "scene.select_children",
    "scene.collapse_unselected_collections",
    "scene.material_list_property",
    "scene.bevel_segment_amount",
    "scene.bevel_segment_by_percent",
    "scene.bevel_offset",
    "scene.compensate_for_scale",
    "scene.bevel_segments_type",
    "window_manager.float_value",
    "window_manager.float_color_value",
    "window_manager.integer_value",
    "scene.vertex_color",
    "scene.RGB_Enum",
    "window_manager.live_booleans",
    "scene.smart_uv_sync_enable",
    "scene.auto_lod_props",
    "scene.polycount_props",
    "scene.sms_cad_auto_clear_garbage_data",
    "scene.sms_cad_preserve_uvs",
    "scene.sms_cad_export_path",
    "scene.sms_cad_decimation_ratio",
    "scene.sms_cad_delete_files_after_import",
    "scene.sms_cad_export_selected_only",
    "scene.sms_cad_decimate_type",
    "scene.sms_cad_merge_distance",
    "scene.sms_cad_format",
    "scene.sms_cad_fast_mode",
    "scene.sms_cad_percent_or_amount",
    "scene.sms_cad_tris_count",
    # Tissue stores artistic controls on each object.  They are keyed by stable
    # scene/object names in the canonical JSON so changing one object never
    # overwrites another object's N-panel state after a file/scene switch.
    "object.tissue",
    "object.tissue_tessellate",
    "object.tissue_polyhedra",
    "object.tissue_to_curve",
    "object.tissue_contour_curves",
    "object.formula_settings",
    "object.reaction_diffusion_settings",
    "object.tex_reaction_diffusion_settings",
)
BLEND_OWNED_NPANEL_PATHS = (
    # Native Blender mesh-edit state is document/tool state.  It is displayed
    # by bundled panels but remains owned by the .blend instead of being copied
    # globally into Smart_Modeling_Suite.json.
    "scene.tool_settings.use_edge_path_live_unwrap",
    "scene.tool_settings.use_transform_correct_face_attributes",
    "scene.tool_settings.use_mesh_automerge",
)
EXCLUDED_TRANSIENT_PATHS = (
    # Blender's inherited PropertyGroup display name is not an N-panel setting.
    "window_manager.smart_modeling_suite_npanel_settings.name",
    "scene.material_list_property.name",
    "scene.auto_lod_props.name",
    "scene.polycount_props.name",
    "scene.meshfixtool_properties.name",
    "scene.vscp_settings.name",
    "scene.vscpx_settings.name",
    "scene.vscpy_settings.name",
    "scene.vscpz_settings.name",
    # Operation-in-progress and generated repair statistics are live result
    # state, not editable N-panel preferences.
    "scene.meshfixtool_properties.meshfixing",
    "scene.meshfixtool_properties.sum_vertices",
    "scene.meshfixtool_properties.sum_edges",
    "scene.meshfixtool_properties.sum_faces",
    "scene.meshfixtool_properties.sum_holes",
    "scene.meshfixtool_properties.sum_volumes",
    "object.tissue.name",
    "object.tissue_tessellate.name",
    "object.tissue_polyhedra.name",
    "object.tissue_to_curve.name",
    "object.tissue_contour_curves.name",
    "object.formula_settings.name",
    "object.reaction_diffusion_settings.name",
    "object.tex_reaction_diffusion_settings.name",
    # One-shot simulation invalidation flags are changed automatically by
    # Tissue and consumed on the next frame; they are runtime state rather than
    # durable N-panel preferences.
    "object.reaction_diffusion_settings.update_geometry_data",
    "object.reaction_diffusion_settings.update_baked_geometry",
    # Generated list rows, recalculated from the current scene; the filter and
    # presentation settings beside them remain fully persisted.
    "scene.polycount_props.my_collection",
    # Runtime backup state for the temporary merge/snap transaction.
    "scene.tams_state*",
    # Generated reversible backup entries contain file-owned object data.
    "scene.mo2_backup_items*",
    # Per-object procedural landscape data is artistic .blend content.
    "object.ant_landscape",
)
ROOT_PANEL_IDS = (
    "VIEW3D_PT_sms_hub",
    "IMAGE_PT_sms_hub",
    "NODE_PT_sms_hub",
    "SEQUENCER_PT_sms_hub",
    "CLIP_PT_sms_hub",
    "DOPESHEET_PT_sms_hub",
    "GRAPH_PT_sms_hub",
    "NLA_PT_sms_hub",
    "TEXT_PT_sms_hub",
    "FILEBROWSER_PT_sms_hub",
    "SPREADSHEET_PT_sms_hub",
)
