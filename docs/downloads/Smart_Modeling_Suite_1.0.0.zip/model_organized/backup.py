import bpy
from bpy.types import PropertyGroup
from bpy.props import StringProperty, CollectionProperty
from . import modifiers as mo_mod

BACKUP_COLLECTION_NAME = "_MO_Backup"
TRANSACTION_COLLECTION_PREFIX = "_MO_Transaction_"

def _data_collection(data):
    if data is None:
        return None
    try:
        if isinstance(data, bpy.types.Mesh):
            return bpy.data.meshes
        if isinstance(data, bpy.types.Curve):
            return bpy.data.curves
    except ReferenceError:
        return None
    return None


def _data_get_like(data, name):
    collection = _data_collection(data)
    return collection.get(name) if collection is not None and name else None


def _remove_data_if_unused(data):
    try:
        collection = _data_collection(data)
        if (
            data is None
            or collection is None
            or getattr(data, "library", None) is not None
            or getattr(data, "users", 0) != 0
        ):
            return False
        if collection.get(data.name) == data:
            collection.remove(data)
            return True
    except (ReferenceError, RuntimeError, TypeError):
        pass
    return False


def _ensure_object_type(context, obj, target_type):
    if obj.type == target_type:
        return ()
    if (obj.type, target_type) not in {('MESH', 'CURVE'), ('CURVE', 'MESH')}:
        raise RuntimeError(f"Unsupported Model Organizer rollback type conversion: {obj.type} -> {target_type}")
    from .core import object_operator_context

    previous_data = getattr(obj, "data", None)
    obj.modifiers.clear()
    with object_operator_context(context, obj):
        result = bpy.ops.object.convert(target=target_type)
    if 'FINISHED' not in set(result or ()) or obj.type != target_type:
        raise RuntimeError(f"Could not restore object type {target_type} for {obj.name}.")
    return tuple(data for data in (previous_data, getattr(obj, "data", None)) if data is not None)


class MO2_BackupItem(PropertyGroup):
    original_name: StringProperty(name="Original Name", description='Text field for Original Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    backup_name: StringProperty(name="Backup Name", description='Text field for Backup Name. Use it to enter a name, filter, note, identifier, or other text used by the tool.')
    original_data_name: StringProperty(name="Original Data Name", description="Original object data-block name used to restore names and shared links on cancel.")

def ensure_backup_collection():
    col = bpy.data.collections.get(BACKUP_COLLECTION_NAME)
    if not col:
        col = bpy.data.collections.new(BACKUP_COLLECTION_NAME)
        # Link to scene master collection
        bpy.context.scene.collection.children.link(col)
    col.hide_viewport = True
    col.hide_render = True
    col.hide_select = True
    return col

def clear_backup_scene_data(scene):
    scene.mo2_backup_id = ""
    scene.mo2_backup_items.clear()

def create_backup_for_objects(context, objects, backup_id: str):
    scene = context.scene
    col = ensure_backup_collection()
    # Clear previous mapping, keep old backup objects until user clears them.
    clear_backup_scene_data(scene)
    scene.mo2_backup_id = backup_id

    created = []
    for obj in objects:
        try:
            bobj = obj.copy()
            if obj.data:
                bobj.data = obj.data.copy()
            # Keep modifiers (obj.copy includes modifiers), and custom props too.
            bobj.animation_data_clear()  # keep backups lightweight; original drivers are not needed for restore.
            bobj.name = f"{obj.name}__MO_BACKUP__{backup_id}"
            col.objects.link(bobj)
            # Ensure backup is not linked elsewhere (avoid clutter)
            for c in list(bobj.users_collection):
                if c != col:
                    c.objects.unlink(bobj)
            item = scene.mo2_backup_items.add()
            item.original_name = obj.name
            item.backup_name = bobj.name
            item.original_data_name = getattr(obj.data, "name", "") if obj.data else ""
            created.append(bobj)
        except Exception:
            continue
    return created

def create_transaction_backup(context, objects, transaction_id: str):
    """Create an operator-private rollback snapshot without replacing user backups."""
    collection = bpy.data.collections.new(f"{TRANSACTION_COLLECTION_PREFIX}{transaction_id}")
    context.scene.collection.children.link(collection)
    collection.hide_render = True
    records = []
    data_copies = {}
    try:
        for obj in objects:
            record = {
                "object": obj,
                "object_name": obj.name,
                "original_data": getattr(obj, "data", None),
                "original_data_name": getattr(getattr(obj, "data", None), "name", ""),
                "original_type": obj.type,
                "original_collections": tuple(obj.users_collection),
                "modifier_drivers": mo_mod.snapshot_modifier_drivers(obj),
                "backup_object": None,
                "collection": collection,
                # Parent linkage is snapshotted as plain record values because the
                # backup object itself is detached from the parent below: a hidden
                # backup that stays parented is excluded from depsgraph evaluation,
                # so Blender's child-compensation during the parent's transform or
                # origin step corrupts the backup's transforms (measured on 5.1.2).
                "parent": obj.parent,
                "parent_type": obj.parent_type,
                "parent_bone": obj.parent_bone,
                "matrix_parent_inverse": obj.matrix_parent_inverse.copy(),
            }
            records.append(record)
            # Read-only library objects fail closed in process_object before mutation.
            if (
                getattr(obj, "library", None) is not None
                and getattr(obj, "override_library", None) is None
            ) or not getattr(obj, "is_editable", True):
                continue

            backup_object = obj.copy()
            record["backup_object"] = backup_object
            if obj.data:
                data_key = obj.data.as_pointer()
                backup_data = data_copies.get(data_key)
                if backup_data is None:
                    backup_data = obj.data.copy()
                    data_copies[data_key] = backup_data
                backup_object.data = backup_data
            backup_object.animation_data_clear()
            backup_object.name = f"{obj.name}__MO_TXN__{transaction_id}"
            # Detach the backup from the scene hierarchy: parented hidden copies
            # are silently rewritten by Blender's parent-child compensation while
            # the live parent is processed, which would corrupt the rollback data.
            backup_object.parent = None
            collection.objects.link(backup_object)
            backup_object.hide_render = True
            backup_object.hide_viewport = True
            backup_object.hide_select = True
    except Exception:
        delete_transaction_backup(records)
        if collection.name in bpy.data.collections:
            bpy.data.collections.remove(collection)
        raise
    return records

def _restore_modifiers_checked(context, source, target):
    from .core import object_operator_context

    target.modifiers.clear()
    if len(source.modifiers) == 0:
        return

    collection_states = [(collection, collection.hide_viewport) for collection in source.users_collection]
    source_state = (source.hide_viewport, source.hide_select)
    try:
        for collection, _state in collection_states:
            collection.hide_viewport = False
        source.hide_viewport = False
        source.hide_select = False
        context.view_layer.update()
        with object_operator_context(context, source, (source, target)):
            result = bpy.ops.object.make_links_data(type='MODIFIERS')
        if 'FINISHED' not in result:
            raise RuntimeError("Blender did not restore the modifier stack.")
        expected = [(modifier.name, modifier.type) for modifier in source.modifiers]
        actual = [(modifier.name, modifier.type) for modifier in target.modifiers]
        if actual != expected:
            raise RuntimeError("The restored modifier stack failed its postcondition.")
    finally:
        source.hide_viewport, source.hide_select = source_state
        for collection, state in collection_states:
            collection.hide_viewport = state

def restore_transaction_backup(context, records):
    """Restore the supplied processed records; shared object-data relationships are rebuilt."""
    records = [record for record in records if record and record.get("backup_object")]
    data_groups = {}
    for record in records:
        original_data = record.get("original_data")
        if original_data is not None:
            data_groups.setdefault(original_data.as_pointer(), []).append(record)

    restored_data = {}
    for data_key, group in data_groups.items():
        original_data = group[0].get("original_data")
        processed_original_in_place = any(
            record.get("object")
            and record["object"].name in bpy.data.objects
            and getattr(record["object"], "data", None) == original_data
            for record in group
        )
        if original_data is not None and (
            group[0].get("original_type") == 'CURVE'
            or not processed_original_in_place
        ):
            # Curve-to-Mesh conversion replaces the object data without mutating
            # the original Curve datablock, so rollback can preserve its exact ID.
            restored_data[data_key] = original_data
        else:
            backup_data = group[0]["backup_object"].data
            restored_data[data_key] = backup_data.copy() if backup_data else None

    restored = 0
    for record in records:
        obj = record.get("object")
        backup_object = record.get("backup_object")
        if obj is None or backup_object is None or obj.name not in bpy.data.objects:
            raise RuntimeError(f"Rollback target is missing: {record.get('object_name', '<unknown>')}")

        # Parent linkage comes from the record snapshot: the backup object is
        # deliberately unparented (see create_transaction_backup).
        obj.parent = record.get("parent")
        obj.parent_type = record.get("parent_type", 'OBJECT')
        obj.parent_bone = record.get("parent_bone", "")
        recorded_inverse = record.get("matrix_parent_inverse")
        if recorded_inverse is not None:
            obj.matrix_parent_inverse = recorded_inverse.copy()
        obj.rotation_mode = backup_object.rotation_mode
        obj.location = backup_object.location
        obj.scale = backup_object.scale
        obj.delta_location = backup_object.delta_location
        obj.delta_scale = backup_object.delta_scale
        obj.delta_rotation_euler = backup_object.delta_rotation_euler
        obj.delta_rotation_quaternion = backup_object.delta_rotation_quaternion
        if obj.rotation_mode == 'QUATERNION':
            obj.rotation_quaternion = backup_object.rotation_quaternion
        elif obj.rotation_mode == 'AXIS_ANGLE':
            obj.rotation_axis_angle = backup_object.rotation_axis_angle
        else:
            obj.rotation_euler = backup_object.rotation_euler
        original_name = record.get("object_name", "")
        if original_name and obj.name != original_name:
            obj.name = original_name
        obj.color = tuple(backup_object.color)
        obj.show_wire = backup_object.show_wire
        obj.display_type = backup_object.display_type

        original_collections = tuple(record.get("original_collections") or ())
        for collection in tuple(obj.users_collection):
            if collection not in original_collections:
                collection.objects.unlink(obj)
        for collection in original_collections:
            if collection.name in bpy.data.collections and obj.name not in collection.objects:
                collection.objects.link(obj)

        original_data = record.get("original_data")
        if original_data is not None and backup_object.data is not None:
            transient_data = list(_ensure_object_type(
                context,
                obj,
                record.get("original_type", backup_object.type),
            ))
            transient_data.append(getattr(obj, "data", None))
            target_data = restored_data.get(original_data.as_pointer())
            if target_data is None:
                raise RuntimeError(f"Could not restore object data for {obj.name}.")
            obj.data = target_data
            original_data_name = record.get("original_data_name", "")
            if original_data_name:
                obj.data.name = original_data_name
            for previous_data in transient_data:
                if previous_data is not None and previous_data != target_data:
                    _remove_data_if_unused(previous_data)

        _restore_modifiers_checked(context, backup_object, obj)
        if record.get("modifier_drivers"):
            mo_mod.restore_modifier_drivers(obj, record["modifier_drivers"])
        restored += 1
    # Data names can be reclaimed only after every mutated original has lost
    # its last user and has been removed above.
    for record in records:
        obj = record.get("object")
        original_data_name = record.get("original_data_name", "")
        if obj and obj.name in bpy.data.objects and obj.data and original_data_name:
            obj.data.name = original_data_name
    context.view_layer.update()
    from .core import cleanup_unused_mirror_frame_helpers
    cleanup_unused_mirror_frame_helpers()
    return restored

def delete_transaction_backup(records, *, discard_replaced_original_data=False):
    """Delete only private snapshots and committed type-conversion source data."""
    backup_objects = []
    backup_data = []
    collections = []
    replaced_original_data = []
    for record in records or ():
        backup_object = record.get("backup_object") if record else None
        collection = record.get("collection") if record else None
        if backup_object and backup_object not in backup_objects:
            backup_objects.append(backup_object)
            if backup_object.data and backup_object.data not in backup_data:
                backup_data.append(backup_object.data)
        if collection and collection not in collections:
            collections.append(collection)
        if discard_replaced_original_data and record:
            original_data = record.get("original_data")
            obj = record.get("object")
            original_type = record.get("original_type")
            if (
                original_data is not None
                and original_data not in replaced_original_data
                and obj is not None
                and obj.name in bpy.data.objects
                and obj.type != original_type
            ):
                replaced_original_data.append(original_data)
    for backup_object in backup_objects:
        if backup_object.name in bpy.data.objects:
            bpy.data.objects.remove(backup_object, do_unlink=True)
    for data in backup_data:
        _remove_data_if_unused(data)
    for data in replaced_original_data:
        _remove_data_if_unused(data)
    for collection in collections:
        if collection.name in bpy.data.collections:
            bpy.data.collections.remove(collection)
    return len(backup_objects)

def find_backup_object(scene, backup_name: str):
    return bpy.data.objects.get(backup_name)

def restore_from_backup(context):
    scene = context.scene
    if not scene.mo2_backup_id or len(scene.mo2_backup_items) == 0:
        return 0

    restored = 0
    restore_object_pointers = {
        obj.as_pointer()
        for item in scene.mo2_backup_items
        if (obj := bpy.data.objects.get(item.original_name)) is not None
    }
    restored_data_by_name = {}
    original_data_names = {
        str(getattr(item, "original_data_name", "") or "")
        for item in scene.mo2_backup_items
    }
    for original_data_name in original_data_names:
        if not original_data_name:
            continue
        backup_object = next(
            (bpy.data.objects.get(item.backup_name) for item in scene.mo2_backup_items
             if str(getattr(item, "original_data_name", "") or "") == original_data_name),
            None,
        )
        live_data = _data_get_like(getattr(backup_object, "data", None), original_data_name)
        if live_data is None:
            continue
        has_external_user = any(
            getattr(candidate, "data", None) == live_data
            and candidate.as_pointer() not in restore_object_pointers
            for candidate in bpy.data.objects
        )
        if has_external_user:
            restored_data_by_name[original_data_name] = live_data
        elif live_data.users == 0:
            _remove_data_if_unused(live_data)

    # Restore in-place: for each original, copy data/modifiers back from backup.
    for item in scene.mo2_backup_items:
        obj = bpy.data.objects.get(item.original_name)
        bobj = find_backup_object(scene, item.backup_name)
        if not obj or not bobj:
            continue
        try:
            # Transform / display
            obj.matrix_world = bobj.matrix_world.copy()
            obj.color = tuple(bobj.color)
            obj.show_wire = bobj.show_wire
            obj.display_type = bobj.display_type

            # Data
            if obj.data and bobj.data:
                transient_data = list(_ensure_object_type(context, obj, bobj.type))
                transient_data.append(getattr(obj, "data", None))
                original_data_name = str(getattr(item, "original_data_name", "") or "")
                original_shared_data = restored_data_by_name.get(original_data_name) if original_data_name else None
                if original_shared_data is not None:
                    obj.data = original_shared_data
                else:
                    obj.data = bobj.data.copy()
                for old_data in transient_data:
                    if old_data is not None and old_data != obj.data:
                        _remove_data_if_unused(old_data)
                if original_data_name and obj.data.name != original_data_name:
                    try:
                        obj.data.name = original_data_name
                    except Exception:
                        pass
                if original_data_name:
                    restored_data_by_name.setdefault(original_data_name, obj.data)

            # Modifiers: rebuild from backup using link copy for fidelity
            obj.modifiers.clear()
            # Link modifiers from backup to obj (active must be backup)
            sel = context.selected_objects
            act = context.view_layer.objects.active
            for o in sel:
                o.select_set(False)
            bobj.select_set(True)
            obj.select_set(True)
            context.view_layer.objects.active = bobj
            try:
                bpy.ops.object.make_links_data(type='MODIFIERS')
            except Exception:
                pass
            # Restore selection
            for o in context.selected_objects:
                o.select_set(False)
            for o in sel:
                try: o.select_set(True)
                except Exception: pass
            context.view_layer.objects.active = act

            restored += 1
        except Exception:
            continue

    for original_data_name, restored_data in restored_data_by_name.items():
        if restored_data and restored_data.name != original_data_name:
            try:
                restored_data.name = original_data_name
            except Exception:
                pass

    from .core import cleanup_unused_mirror_frame_helpers
    cleanup_unused_mirror_frame_helpers()
    return restored

def delete_backup_objects():
    col = bpy.data.collections.get(BACKUP_COLLECTION_NAME)
    if not col:
        return 0
    objs = list(col.objects)
    data_blocks = list({obj.data for obj in objs if getattr(obj, "data", None) is not None})
    for o in objs:
        try:
            bpy.data.objects.remove(o, do_unlink=True)
        except Exception:
            pass
    for data in data_blocks:
        _remove_data_if_unused(data)
    try:
        bpy.data.collections.remove(col)
    except Exception:
        pass
    return len(objs)
