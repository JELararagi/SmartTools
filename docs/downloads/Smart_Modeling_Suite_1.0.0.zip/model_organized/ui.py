import bpy

PANEL_IDNAME = "MO2_PT_MainPanel"


def _t(msgid: str) -> str:
    return bpy.app.translations.pgettext(msgid)


def _enabled(context) -> bool:
    try:
        from ..utils import feature_enabled
        return feature_enabled(context, "enable_model_organized", True)
    except Exception:
        return True


def _props(context):
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    try:
        return getattr(scene, "mo2_props", None)
    except Exception:
        return None


def _safe_prop(layout, data, name: str, *, text=None, toggle=False):
    if data is None or not name:
        return False
    try:
        if not hasattr(data, name):
            return False
    except Exception:
        return False
    kwargs = {}
    if text is not None:
        kwargs["text"] = text
    if toggle:
        kwargs["toggle"] = True
    try:
        layout.prop(data, name, **kwargs)
        return True
    except Exception:
        try:
            row = layout.row(align=True)
            row.label(text=f"{name}: {_t('Unavailable')}", icon='ERROR')
        except Exception:
            pass
    return False


def _operator_if_available(layout, op_idname: str, *, text: str, icon: str = 'NONE'):
    try:
        head, tail = op_idname.split('.', 1)
        op_group = getattr(bpy.ops, head, None)
        op = getattr(op_group, tail, None) if op_group is not None else None
        if op is None:
            layout.label(text=text, icon='ERROR')
            return None
        return layout.operator(op_idname, text=text, icon=icon)
    except Exception:
        try:
            layout.label(text=text, icon='ERROR')
        except Exception:
            pass
    return None


def update_panel_category(new_category: str):
    """The suite uses a fixed single N-panel tab: Smart Modeling."""
    return


def draw_model_organizer_settings(layout, context, *, show_actions: bool = True):
    """Draw all Model Organizer settings in one stable Smart Modeling host UI.

    The standalone child panels are intentionally not registered as Blender N-panel
    classes in Smart Modeling Suite.  This helper is used by both the compact hub
    and the unified 設定 view so every setting remains visible and editable from
    the single public Smart Modeling panel.
    """
    props = _props(context)
    layout.use_property_split = True
    layout.use_property_decorate = False

    if props is None:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_t("Model Organizer settings are not registered."), icon='ERROR')
        return 0

    drawn = 0

    if show_actions:
        box = layout.box()
        box.label(text=_t("Execution"), icon='PLAY')
        row = box.row(align=True)
        row.scale_y = 1.15
        row.operator_context = 'INVOKE_DEFAULT'
        _operator_if_available(row, "mo2.organize_modal", text=_t("Organize Selection"), icon='CHECKMARK')
        _operator_if_available(row, "mo2.restore_backup", text=_t("Restore Backup"), icon='LOOP_BACK')
        _operator_if_available(row, "mo2.clear_backup", text="", icon='TRASH')
        drawn += 1

    box = layout.box()
    box.label(text=_t("Preset"), icon='PRESET')
    _safe_prop(box, props, "preset", text="")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Modifiers"), icon='MODIFIER')
    _safe_prop(box, props, "keep_mode", text="")
    sub = box.column(align=True)
    try:
        sub.enabled = props.keep_mode in {'KEEP_REBUILD', 'KEEP_SAFE'}
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "keep_modifier_drivers")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Transforms"), icon='ORIENTATION_GLOBAL')
    col = box.column(align=True)
    row = col.row(align=True)
    _safe_prop(row, props, "apply_location", text=_t("Location"), toggle=True)
    _safe_prop(row, props, "apply_rotation", text=_t("Rotation"), toggle=True)
    _safe_prop(row, props, "apply_scale", text=_t("Scale"), toggle=True)
    _safe_prop(col, props, "shade_smooth")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Display"), icon='RESTRICT_VIEW_OFF')
    col = box.column(align=True)
    _safe_prop(col, props, "set_object_color")
    sub = col.column(align=True)
    try:
        sub.enabled = bool(props.set_object_color)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "object_color")
    _safe_prop(col, props, "set_wire_off")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Clean Data"), icon='BRUSH_DATA')
    col = box.column(align=True)
    _safe_prop(col, props, "remove_crease")
    _safe_prop(col, props, "remove_bevel_weight")
    _safe_prop(col, props, "clear_custom_normals")
    _safe_prop(col, props, "recalc_normals")
    _safe_prop(col, props, "convert_geometry_nodes_to_mesh")
    row = col.row(align=True)
    _safe_prop(row, props, "merge_by_distance")
    sub = row.row(align=True)
    try:
        sub.enabled = bool(props.merge_by_distance)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "merge_distance", text=_t("Distance"))
    _safe_prop(col, props, "delete_loose")
    _safe_prop(col, props, "remove_empty_material_slots")
    _safe_prop(col, props, "purge_orphans")
    _safe_prop(col, props, "rename_data_to_object_name")
    _operator_if_available(col, "mo2.rename_data_to_object_name", text=_t("Rename Data to Object Name"), icon='SORTALPHA')
    drawn += 1

    box = layout.box()
    box.label(text=_t("Origin / Pivot"), icon='PIVOT_ACTIVE')
    _safe_prop(box, props, "origin_mode", text="")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Rename / Collections"), icon='OUTLINER_COLLECTION')
    col = box.column(align=True)
    _safe_prop(col, props, "rename_enable")
    sub = col.column(align=True)
    try:
        sub.enabled = bool(props.rename_enable)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "rename_pattern")
    _safe_prop(sub, props, "rename_start_index")
    col.separator()
    _safe_prop(col, props, "move_to_collection_enable")
    sub = col.column(align=True)
    try:
        sub.enabled = bool(props.move_to_collection_enable)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "target_collection")
    _safe_prop(sub, props, "remove_empty_collections")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Preflight Checks"), icon='VIEWZOOM')
    col = box.column(align=True)
    _safe_prop(col, props, "preflight_enable")
    sub = col.column(align=True)
    try:
        sub.enabled = bool(props.preflight_enable)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "check_nonmanifold")
    _safe_prop(sub, props, "check_negative_scale")
    _safe_prop(sub, props, "auto_fix_negative_scale")
    _safe_prop(sub, props, "warn_shapekeys_armature")
    drawn += 1

    box = layout.box()
    box.label(text=_t("Backup / Restore"), icon='FILE_BACKUP')
    col = box.column(align=True)
    _safe_prop(col, props, "backup_enable")
    sub = col.column(align=True)
    try:
        sub.enabled = bool(props.backup_enable)
    except Exception:
        sub.enabled = True
    _safe_prop(sub, props, "restore_on_cancel")
    try:
        count = len(getattr(context.scene, "mo2_backup_items", ()))
    except Exception:
        count = 0
    col.label(text=_t("Stored Backups: {count}").format(count=count))
    drawn += 1

    return drawn


def draw_smart_modeling_settings(layout, context):
    return draw_model_organizer_settings(layout, context, show_actions=True)


class MO2_PT_MainPanel(bpy.types.Panel):
    """Main panel for Model Organizer."""

    bl_label = "Model Organizer"
    bl_description = 'Model Organizer panel in the Smart Modeling workspace.'
    bl_idname = PANEL_IDNAME
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        draw_model_organizer_settings(self.layout, context, show_actions=True)


class MO2_PT_Modifiers(bpy.types.Panel):
    bl_label = "Modifiers"
    bl_description = 'Modifiers panel in the Smart Modeling workspace.'
    bl_idname = "MO2_PT_Modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        props = _props(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Modifiers"), icon='MODIFIER')
        _safe_prop(box, props, "keep_mode", text="")
        sub = box.column(align=True)
        try:
            sub.enabled = props.keep_mode in {'KEEP_REBUILD', 'KEEP_SAFE'}
        except Exception:
            sub.enabled = True
        _safe_prop(sub, props, "keep_modifier_drivers")


class MO2_PT_Transforms(bpy.types.Panel):
    bl_label = "Transforms"
    bl_description = 'Transforms panel in the Smart Modeling workspace.'
    bl_idname = "MO2_PT_Transforms"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        props = _props(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Transforms"), icon='ORIENTATION_GLOBAL')
        row = box.row(align=True)
        _safe_prop(row, props, "apply_location", text=_t("Location"), toggle=True)
        _safe_prop(row, props, "apply_rotation", text=_t("Rotation"), toggle=True)
        _safe_prop(row, props, "apply_scale", text=_t("Scale"), toggle=True)
        _safe_prop(box, props, "shade_smooth")


class MO2_PT_CleanData(bpy.types.Panel):
    bl_label = "Clean Data"
    bl_description = 'Clean Data panel in the Smart Modeling workspace.'
    bl_idname = "MO2_PT_CleanData"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        props = _props(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Clean Data"), icon='BRUSH_DATA')
        col = box.column(align=True)
        for prop in ("remove_crease", "remove_bevel_weight", "clear_custom_normals", "recalc_normals", "convert_geometry_nodes_to_mesh"):
            _safe_prop(col, props, prop)
        row = col.row(align=True)
        _safe_prop(row, props, "merge_by_distance")
        sub = row.row(align=True)
        try:
            sub.enabled = bool(props.merge_by_distance)
        except Exception:
            sub.enabled = True
        _safe_prop(sub, props, "merge_distance", text=_t("Distance"))
        for prop in ("delete_loose", "remove_empty_material_slots", "purge_orphans"):
            _safe_prop(col, props, prop)
        _operator_if_available(col, "mo2.rename_data_to_object_name", text=_t("Rename Data to Object Name"), icon='SORTALPHA')


class MO2_PT_OriginPivot(bpy.types.Panel):
    bl_label = "Origin / Pivot"
    bl_description = 'Origin / Pivot panel in the Smart Modeling workspace.'
    bl_idname = "MO2_PT_OriginPivot"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        props = _props(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Origin / Pivot"), icon='PIVOT_ACTIVE')
        _safe_prop(box, props, "origin_mode", text="")


class MO2_PT_RenameCollections(bpy.types.Panel):
    bl_label = "Rename / Collections"
    bl_description = 'Rename / Collections panel in the Smart Modeling workspace.'
    bl_idname = "MO2_PT_RenameCollections"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        props = _props(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Rename / Collections"), icon='OUTLINER_COLLECTION')
        _safe_prop(box, props, "rename_enable")
        col = box.column(align=True)
        try:
            col.enabled = bool(props.rename_enable)
        except Exception:
            col.enabled = True
        _safe_prop(col, props, "rename_pattern")
        _safe_prop(col, props, "rename_start_index")
        box.separator()
        _safe_prop(box, props, "move_to_collection_enable")
        col = box.column(align=True)
        try:
            col.enabled = bool(props.move_to_collection_enable)
        except Exception:
            col.enabled = True
        _safe_prop(col, props, "target_collection")
        _safe_prop(col, props, "remove_empty_collections")


class MO2_PT_Help(bpy.types.Panel):
    bl_label = "Guide / Tips"
    bl_description = 'Guide / Tips help panel with workflow notes and beginner guidance.'
    bl_idname = "MO2_PT_Help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        box = layout.box()
        box.label(text=_t("Beginner workflow"))
        col = box.column(align=True)
        col.label(text=_t("• Choose a Preset first."))
        col.label(text=_t("• Click Organize Selection. A backup is created automatically."))
        col.label(text=_t("• If results are unexpected, click Restore Backup."))
        box = layout.box()
        box.label(text=_t("Tips"), icon='LIGHT')
        col = box.column(align=True)
        col.label(text=_t("• Use Clean Data when models come from many sources and contain messy data."))
        col.label(text=_t("• Use Rename / Collections to keep Outliner tidy for large projects."))


# --- Tooltip completion (Model Organizer panels) ---
MO2_PT_Modifiers.bl_description = 'Modifier cleanup, apply, keep, and organization helpers for safer object housekeeping.'
MO2_PT_Transforms.bl_description = 'Transform cleanup helpers for scale, rotation, and data-safe normalization workflows.'
MO2_PT_CleanData.bl_description = 'Mesh/data cleanup helpers for normals, doubles, unused slots, and similar maintenance tasks.'
MO2_PT_OriginPivot.bl_description = 'Origin and pivot helpers for reorganizing object control points safely.'
MO2_PT_RenameCollections.bl_description = 'Batch renaming and collection organization helpers for cleaner scenes.'
MO2_PT_Help.bl_description = 'Beginner-friendly workflow notes for Model Organizer.'
MO2_PT_MainPanel.bl_description = 'Complete main panel for organizing, cleaning, and standardizing selected objects before export or further modeling.'
