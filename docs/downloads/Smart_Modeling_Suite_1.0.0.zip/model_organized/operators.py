import bpy
import time
from mathutils import Matrix
from .core import (
    ensure_object_mode,
    process_object,
    preflight_checks,
    rename_objects,
    rename_data_to_object_names,
    move_objects_to_collection,
    purge_orphans,
    capture_selection_state,
    restore_selection_state,
    object_operator_context,
)
from .backup import (
    create_backup_for_objects,
    restore_from_backup,
    delete_backup_objects,
    create_transaction_backup,
    restore_transaction_backup,
    delete_transaction_backup,
)
from . import core

def _settings_dict(props):
    return {
        "keep_mode": props.keep_mode,
        "keep_modifier_drivers": props.keep_modifier_drivers,
        "apply_location": props.apply_location,
        "apply_rotation": props.apply_rotation,
        "apply_scale": props.apply_scale,
        "shade_smooth": props.shade_smooth,
        "set_object_color": props.set_object_color,
        "object_color": tuple(props.object_color),
        "set_wire_off": props.set_wire_off,
        "remove_crease": props.remove_crease,
        "remove_bevel_weight": props.remove_bevel_weight,
        "clear_custom_normals": props.clear_custom_normals,
        "recalc_normals": props.recalc_normals,
        "convert_geometry_nodes_to_mesh": props.convert_geometry_nodes_to_mesh,
        "merge_by_distance": props.merge_by_distance,
        "merge_distance": props.merge_distance,
        "delete_loose": props.delete_loose,
        "remove_empty_material_slots": props.remove_empty_material_slots,
        "purge_orphans": props.purge_orphans,  # run at end
        "origin_mode": props.origin_mode,
        "auto_fix_negative_scale": props.auto_fix_negative_scale,
        "keep_modifier_drivers": props.keep_modifier_drivers,
    }

class MO2_OT_OrganizeModal(bpy.types.Operator):
    bl_idname = "mo2.organize_modal"
    bl_label = 'Organize Selection'
    bl_description = "Clean, normalize, and organize the selected objects using the active preset while creating a reversible backup. Includes transform safety, cleanup helpers, modifier preservation, and batch organization options."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return feature_enabled(context, "enable_model_organized", True)
        except Exception:
            return True

    _timer = None
    _objects = None
    _index = 0
    _total = 0
    _backup_created = False
    _settings = None
    _log = None
    _successful_objects = None
    _orig_sel = None
    _orig_active = None
    _orig_mode = 'OBJECT'
    _transaction_records = None
    _processed_records = None
    _attempted_pointers = None
    _initial_world = None
    _initial_parent_world = None
    _initial_parent_inverse = None
    _target_pointers = None

    def _report_info(self, msg_eng):
        pgettext = bpy.app.translations.pgettext
        self.report({'INFO'}, pgettext("Preflight: {msg}").format(msg=pgettext(msg_eng)))

    def execute(self, context):
        # Host layouts and user keymaps may dispatch EXEC_DEFAULT. Reuse the
        # established modal path so both invocation modes behave identically.
        return self.invoke(context, None)

    def invoke(self, context, event):
        pgettext = bpy.app.translations.pgettext
        self._orig_sel, self._orig_active = capture_selection_state(context)
        self._orig_mode = getattr(self._orig_active, "mode", 'OBJECT') if self._orig_active else 'OBJECT'
        try:
            ensure_object_mode(context)
        except Exception as exc:
            self.report({'ERROR'}, pgettext("Could not start Model Organizer: {err}").format(err=pgettext(str(exc))))
            return {'CANCELLED'}

        props = context.scene.mo2_props
        include_curves = bool(props.convert_geometry_nodes_to_mesh)
        unique_targets = {
            obj.as_pointer(): obj
            for obj in self._orig_sel
            if obj.type == 'MESH' or (include_curves and obj.type == 'CURVE')
        }
        def _hierarchy_depth(obj):
            depth = 0
            parent = obj.parent
            while parent is not None:
                depth += 1
                parent = parent.parent
            return depth

        targets = sorted(
            unique_targets.values(),
            key=lambda obj: (_hierarchy_depth(obj), obj.name_full.casefold(), obj.name_full, obj.as_pointer()),
        )
        if not targets:
            restore_selection_state(context, self._orig_sel, self._orig_active)
            self.report({'WARNING'}, pgettext("No mesh objects selected."))
            return {'CANCELLED'}

        # Do not re-apply presets at execution time.
        # The attached Model_Organized tool runs with the current UI state.
        # Presets are applied only when the user explicitly changes the preset property.

        # Preflight
        if props.preflight_enable:
            for obj in targets:
                warns = preflight_checks(
                    obj,
                    do_nonmanifold=props.check_nonmanifold,
                    do_neg_scale=props.check_negative_scale
                )
                for w in warns:
                    self._report_info(w)
                if props.warn_shapekeys_armature:
                    if core.has_shape_keys(obj):
                        self._report_info("Shape keys detected. Safe mode will skip Location/Rotation apply.")
                    if core.has_armature_modifier(obj):
                        self._report_info("Armature modifier detected. Safe mode will skip Location/Rotation apply.")

        # Private transaction backup is always present, independently of the
        # optional user-visible backup feature. It powers per-object rollback
        # and ESC/RMB cancellation without replacing an older saved backup.
        self._transaction_records = None
        self._processed_records = []
        try:
            transaction_id = f"{time.time_ns()}_{id(self)}"
            self._transaction_records = create_transaction_backup(context, targets, transaction_id)
        except Exception as exc:
            restore_selection_state(context, self._orig_sel, self._orig_active)
            self.report({'ERROR'}, pgettext("Could not start Model Organizer: {err}").format(err=pgettext(str(exc))))
            return {'CANCELLED'}

        # Optional user-visible backup.
        self._backup_created = False
        if props.backup_enable:
            backup_id = str(int(time.time()))
            backup_targets = [
                obj for obj in targets
                if not (
                    getattr(obj, "library", None) is not None
                    and getattr(obj, "override_library", None) is None
                )
                and getattr(obj, "is_editable", True)
            ]
            created = create_backup_for_objects(context, backup_targets, backup_id)
            self._backup_created = len(created) == len(backup_targets)
            if not self._backup_created:
                for backup_object in created:
                    if backup_object and backup_object.name in bpy.data.objects:
                        bpy.data.objects.remove(backup_object, do_unlink=True)
                delete_transaction_backup(self._transaction_records)
                self._transaction_records = []
                restore_selection_state(context, self._orig_sel, self._orig_active)
                self.report({'ERROR'}, pgettext("Could not create a complete Model Organizer backup."))
                return {'CANCELLED'}

        self._objects = tuple(targets)
        self._index = 0
        self._total = len(targets)
        self._settings = _settings_dict(props)
        self._created_mirror_helpers = []
        self._settings["_created_mirror_helpers"] = self._created_mirror_helpers
        self._log = []
        self._successful_objects = []
        self._attempted_pointers = set()
        self._target_pointers = {obj.as_pointer() for obj in targets}
        self._initial_world = {obj.as_pointer(): obj.matrix_world.copy() for obj in targets}
        self._initial_parent_world = {
            obj.as_pointer(): obj.parent.matrix_world.copy()
            for obj in targets
            if obj.parent is not None
        }
        self._initial_parent_inverse = {
            obj.as_pointer(): obj.matrix_parent_inverse.copy()
            for obj in targets
            if obj.parent is not None
        }

        # Progress
        try:
            context.window_manager.progress_begin(0, self._total)
        except Exception:
            pass

        # Timer modal
        self._timer = None
        try:
            self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
            context.window_manager.modal_handler_add(self)
        except Exception as exc:
            self.report({'ERROR'}, pgettext("Could not start Model Organizer: {err}").format(err=pgettext(str(exc))))
            return self.finish(context, cancelled=True)
        return {'RUNNING_MODAL'}

    def _repair_child_parent_inverse(self, context, records):
        """Rebuild matrix_parent_inverse after a rollback so recorded children keep
        their pre-run world transform.

        Blender rewrites a child's parent inverse while the parent's transforms or
        origin are adjusted. Rolling back only one side of that pair (the parent on
        cancel, or the child after its own step failed) leaves the stored inverse
        inconsistent with the parent's current matrix and visibly drifts the child.
        Deriving the inverse from the recorded initial parent state restores the
        child's original world transform in both directions.
        """
        for record in records or ():
            obj = record.get("object") if record else None
            if obj is None or obj.name not in bpy.data.objects:
                continue
            parent = obj.parent
            if parent is None:
                continue
            if str(getattr(obj, "parent_type", "OBJECT") or "OBJECT") != 'OBJECT':
                continue
            pointer = obj.as_pointer()
            initial_parent_world = (self._initial_parent_world or {}).get(pointer)
            initial_parent_inverse = (self._initial_parent_inverse or {}).get(pointer)
            if initial_parent_world is None or initial_parent_inverse is None:
                continue
            expected = parent.matrix_world.inverted_safe() @ initial_parent_world @ initial_parent_inverse
            current = obj.matrix_parent_inverse
            if all(abs(expected[i][j] - current[i][j]) <= 1.0e-9 for i in range(4) for j in range(4)):
                continue
            obj.matrix_parent_inverse = expected
        context.view_layer.update()

    def finish(self, context, cancelled=False, restore_backup=False):
        pgettext = bpy.app.translations.pgettext
        wm = context.window_manager
        if self._timer:
            try: wm.event_timer_remove(self._timer)
            except Exception: pass
            self._timer = None
        try:
            wm.progress_end()
        except Exception:
            pass

        try:
            delete_transaction_backup(
                self._transaction_records or (),
                discard_replaced_original_data=not cancelled,
            )
        except Exception as exc:
            self.report({'ERROR'}, pgettext("Could not clear Model Organizer transaction data: {err}").format(err=pgettext(str(exc))))
        self._transaction_records = []

        # Selection, active object, and input mode are operation invariants.
        try:
            ensure_object_mode(context)
            restore_selection_state(context, self._orig_sel, self._orig_active)
            if self._orig_mode != 'OBJECT' and self._orig_active and self._orig_active.name in context.view_layer.objects:
                with object_operator_context(context, self._orig_active, self._orig_sel):
                    result = bpy.ops.object.mode_set(mode=self._orig_mode)
                if 'FINISHED' not in result:
                    raise RuntimeError(f"Could not restore {self._orig_mode} mode.")
                restore_selection_state(context, self._orig_sel, self._orig_active)
        except Exception as exc:
            self.report({'ERROR'}, pgettext("Could not restore the original selection or mode: {err}").format(err=pgettext(str(exc))))

        if cancelled:
            if restore_backup:
                self.report({'INFO'}, pgettext("Canceled. Restored from backup."))
            else:
                self.report({'INFO'}, pgettext("Canceled."))
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    def modal(self, context, event):
        pgettext = bpy.app.translations.pgettext
        props = context.scene.mo2_props

        if event.type in {'ESC', 'RIGHTMOUSE'}:
            restored = False
            if self._processed_records:
                try:
                    restore_transaction_backup(context, self._processed_records)
                    self._repair_child_parent_inverse(context, self._transaction_records)
                    core.cleanup_unused_mirror_frame_helpers(self._created_mirror_helpers)
                    restored = True
                except Exception as exc:
                    self.report({'ERROR'}, pgettext("Could not fully roll back Model Organizer: {err}").format(err=pgettext(str(exc))))
            return self.finish(context, cancelled=True, restore_backup=restored)

        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}

        if self._index >= self._total:
            # Post steps: rename / collection / purge / cleanup collections
            processed = [bpy.data.objects[o.name] for o in (self._successful_objects or []) if o and o.name in bpy.data.objects]
            if not processed:
                self.report({'ERROR'}, pgettext("Organized {count} objects.").format(count=0))
                return self.finish(context, cancelled=True)

            try:
                if props.rename_enable:
                    rename_objects(processed, props.rename_pattern, props.rename_start_index)

                if props.rename_data_to_object_name:
                    rename_data_to_object_names(processed)

                if props.move_to_collection_enable:
                    move_objects_to_collection(context, processed, props.target_collection, props.remove_empty_collections)

                if props.purge_orphans:
                    purge_orphans()
            except Exception as exc:
                try:
                    restore_transaction_backup(context, self._processed_records)
                    self._repair_child_parent_inverse(context, self._transaction_records)
                    core.cleanup_unused_mirror_frame_helpers(self._created_mirror_helpers)
                except Exception as rollback_exc:
                    self.report({'ERROR'}, pgettext("Could not fully roll back Model Organizer: {err}").format(err=pgettext(str(rollback_exc))))
                self.report({'ERROR'}, pgettext("Model Organizer post-processing failed: {err}").format(err=pgettext(str(exc))))
                return self.finish(context, cancelled=True, restore_backup=True)

            self.report({'INFO'}, pgettext("Organized {count} objects.").format(count=len(processed)))
            return self.finish(context, cancelled=False)

        obj = self._objects[self._index]
        record = self._transaction_records[self._index]
        self._index += 1
        self._processed_records.append(record)

        pointer = obj.as_pointer()
        if pointer in self._attempted_pointers:
            self.report({'ERROR'}, pgettext("Model Organizer attempted {name} more than once.").format(name=obj.name))
            return self.finish(context, cancelled=True)
        self._attempted_pointers.add(pointer)

        # Skip if object was deleted
        if obj.name not in bpy.data.objects:
            message = "Object was removed before Model Organizer could process it."
            self._log.append((record.get("object_name", obj.name), message))
            self.report({'ERROR'}, pgettext("Error on {name}: {err}").format(name=record.get("object_name", obj.name), err=pgettext(message)))
            try:
                context.window_manager.progress_update(self._index)
            except Exception:
                pass
            return {'RUNNING_MODAL'}

        def _warn(msg_eng):
            self._report_info(msg_eng)

        current_obj = obj
        detached_parent = None
        object_settings = self._settings
        delta_identity = (
            all(abs(value) <= 1.0e-8 for value in current_obj.delta_location)
            and all(abs(value - 1.0) <= 1.0e-8 for value in current_obj.delta_scale)
            and all(abs(value) <= 1.0e-8 for value in current_obj.delta_rotation_euler)
            and abs(current_obj.delta_rotation_quaternion[0] - 1.0) <= 1.0e-8
            and all(abs(value) <= 1.0e-8 for value in current_obj.delta_rotation_quaternion[1:])
        )
        exact_parent_apply = (
            current_obj.parent
            and current_obj.parent.as_pointer() in self._target_pointers
            and self._settings.get("apply_location", True)
            and self._settings.get("apply_rotation", True)
            and self._settings.get("apply_scale", True)
            and self._settings.get("keep_mode") != "KEEP_SAFE"
            and not core._has_active_constraints(current_obj)
            and not core._animated_transform_channels(current_obj)
            and delta_identity
        )
        if exact_parent_apply:
            detached_parent = current_obj.parent
            current_obj.parent = None
            current_obj.matrix_parent_inverse.identity()
            current_obj.location = (0.0, 0.0, 0.0)
            current_obj.scale = (1.0, 1.0, 1.0)
            current_obj.delta_location = (0.0, 0.0, 0.0)
            current_obj.delta_scale = (1.0, 1.0, 1.0)
            current_obj.delta_rotation_euler = (0.0, 0.0, 0.0)
            current_obj.delta_rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
            if current_obj.rotation_mode == 'QUATERNION':
                current_obj.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
            elif current_obj.rotation_mode == 'AXIS_ANGLE':
                current_obj.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
            else:
                current_obj.rotation_euler = (0.0, 0.0, 0.0)
            object_settings = dict(self._settings)
            object_settings["_exact_apply_matrix"] = tuple(
                tuple(value for value in row) for row in self._initial_world[pointer]
            )
            context.view_layer.update()
        elif current_obj.parent and current_obj.parent.as_pointer() in self._target_pointers:
            # When a selected parent has its transforms baked, its object matrix
            # changes even though its visible geometry stays in place. Preserve
            # the child's complete local animation/driver channels by compensating
            # through matrix_parent_inverse instead of assigning matrix_world,
            # which writes into animated transform channels at the current frame.
            if str(getattr(current_obj, "parent_type", "OBJECT") or "OBJECT") == 'OBJECT':
                initial_parent_world = self._initial_parent_world.get(pointer)
                initial_parent_inverse = self._initial_parent_inverse.get(pointer)
                if initial_parent_world is not None and initial_parent_inverse is not None:
                    current_obj.matrix_parent_inverse = (
                        current_obj.parent.matrix_world.inverted_safe()
                        @ initial_parent_world
                        @ initial_parent_inverse
                    )
                else:
                    current_obj.matrix_world = self._initial_world[pointer].copy()
            else:
                current_obj.matrix_world = self._initial_world[pointer].copy()
            context.view_layer.update()
        try:
            ok, msg = process_object(context, current_obj, object_settings, report_cb=_warn)
        except Exception as exc:
            ok, msg = False, str(exc)
        finally:
            if detached_parent and detached_parent.name in bpy.data.objects:
                target_world = current_obj.matrix_world.copy()
                current_obj.parent = detached_parent
                current_obj.matrix_basis = Matrix.Identity(4)
                current_obj.matrix_parent_inverse = (
                    detached_parent.matrix_world.inverted_safe() @ target_world
                )
                context.view_layer.update()
        if not ok:
            try:
                restore_transaction_backup(context, (record,))
                self._repair_child_parent_inverse(context, (record,))
                core.cleanup_unused_mirror_frame_helpers(self._created_mirror_helpers)
            except Exception as rollback_exc:
                self.report({'ERROR'}, pgettext("Could not roll back {name}: {err}").format(name=obj.name, err=pgettext(str(rollback_exc))))
                try:
                    restore_transaction_backup(context, self._processed_records)
                    self._repair_child_parent_inverse(context, self._transaction_records)
                    core.cleanup_unused_mirror_frame_helpers(self._created_mirror_helpers)
                except Exception:
                    pass
                return self.finish(context, cancelled=True, restore_backup=True)
            self._log.append((obj.name, msg))
            self.report({'ERROR'}, pgettext("Error on {name}: {err}").format(name=obj.name, err=pgettext(str(msg))))
        else:
            self._successful_objects.append(current_obj)

        try:
            context.window_manager.progress_update(self._index)
        except Exception:
            pass
        return {'RUNNING_MODAL'}

class MO2_OT_RestoreBackup(bpy.types.Operator):
    bl_idname = "mo2.restore_backup"
    bl_label = 'Restore Backup'
    bl_description = "Restore the most recent backup created by the organize operator."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return feature_enabled(context, "enable_model_organized", True)
        except Exception:
            return True

    def execute(self, context):
        pgettext = bpy.app.translations.pgettext
        count = restore_from_backup(context)
        if count <= 0:
            self.report({'WARNING'}, pgettext("No backup to restore."))
            return {'CANCELLED'}
        self.report({'INFO'}, pgettext("Restored {count} objects from backup.").format(count=count))
        return {'FINISHED'}

class MO2_OT_ClearBackup(bpy.types.Operator):
    bl_idname = "mo2.clear_backup"
    bl_label = "Clear Backup Data"
    bl_description = "Delete the temporary backup data stored by Model Organizer when you no longer need to restore it."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return feature_enabled(context, "enable_model_organized", True)
        except Exception:
            return True

    def execute(self, context):
        pgettext = bpy.app.translations.pgettext
        n = delete_backup_objects()
        # Clear scene mapping too
        try:
            context.scene.mo2_backup_id = ""
            context.scene.mo2_backup_items.clear()
        except Exception:
            pass
        self.report({'INFO'}, pgettext("Backup cleared."))
        return {'FINISHED'}

class MO2_OT_RenameDataToObjectName(bpy.types.Operator):
    bl_idname = "mo2.rename_data_to_object_name"
    bl_label = "Rename Data to Object Name"
    bl_description = "Rename the data-block of each selected object to match its object name. Multi-user, linked, and library data-blocks are skipped and reported. Running it again changes nothing."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            from ..utils import feature_enabled
            return feature_enabled(context, "enable_model_organized", True)
        except Exception:
            return True

    def report(self, type, message):
        # The suite's registration wrapper (core._sms_force_operator_undo_class)
        # replaces Operator.report with a no-op on every operator class that does
        # not define its own. This operator's contract is "skipped and reported",
        # so keep Blender's real report channel (status bar / Info editor).
        return bpy.types.Operator.report(self, type, message)

    def execute(self, context):
        pgettext = bpy.app.translations.pgettext
        selected, _active = capture_selection_state(context)
        candidates = [obj for obj in selected if getattr(obj, "data", None) is not None]
        if not candidates:
            self.report({'WARNING'}, pgettext("No selected objects have data-blocks."))
            return {'CANCELLED'}

        renamed = 0
        skipped = 0
        for obj in candidates:
            data = obj.data
            if data.name == obj.name:
                # Already in sync: nothing to do, so a second run changes nothing.
                continue
            if (
                getattr(obj, "library", None) is not None
                or getattr(data, "library", None) is not None
                or not getattr(data, "is_editable", True)
                or int(getattr(data, "users", 1) or 0) > 1
            ):
                skipped += 1
                continue
            previous_name = data.name
            data.name = obj.name
            if data.name != obj.name:
                # Another data-block of this type already owns the object name and
                # Blender assigned a numbered variant. Keep the previous name instead
                # of leaving a name that matches nothing.
                data.name = previous_name
                skipped += 1
                continue
            renamed += 1

        if skipped:
            self.report(
                {'WARNING'},
                pgettext("Skipped {count} data-block(s): multi-user, linked, or the name is already in use.").format(count=skipped),
            )
        if not renamed:
            self.report({'INFO'}, pgettext("Data names already match the object names."))
            return {'CANCELLED'}
        self.report({'INFO'}, pgettext("Renamed {count} data-block(s).").format(count=renamed))
        return {'FINISHED'}
