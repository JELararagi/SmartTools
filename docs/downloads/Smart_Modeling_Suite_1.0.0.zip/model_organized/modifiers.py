import bpy

# Modifier types that often change behavior after applying transforms.
RISKY_MODIFIER_TYPES = {
    'ARMATURE', 'LATTICE', 'CURVE', 'HOOK', 'SHRINKWRAP', 'SIMPLE_DEFORM',
    'MIRROR', 'ARRAY', 'CAST', 'WARP', 'MESH_DEFORM', 'SURFACE_DEFORM',
    'NODES',
}

def is_risky_modifier(mod):
    try:
        return mod.type in RISKY_MODIFIER_TYPES
    except Exception:
        return False

def snapshot_modifiers(obj):
    """Serialize modifiers to Python dicts for rebuilding."""
    snaps = []
    for mod in obj.modifiers:
        m = {
            "name": mod.name,
            "type": mod.type,
            "show_viewport": mod.show_viewport,
            "show_render": mod.show_render,
            "show_in_editmode": getattr(mod, "show_in_editmode", False),
            "show_on_cage": getattr(mod, "show_on_cage", False),
            "show_expanded": getattr(mod, "show_expanded", True),
            "properties": {},
        }
        # Capture writable RNA properties
        for prop in mod.bl_rna.properties:
            pid = prop.identifier
            if pid in {"name", "type", "rna_type"}:
                continue
            if prop.is_readonly:
                continue
            try:
                val = getattr(mod, pid)
            except Exception:
                continue

            try:
                if prop.type == 'POINTER':
                    if val is None:
                        m["properties"][pid] = None
                    else:
                        # Store ID name (object, collection, etc.)
                        m["properties"][pid] = getattr(val, "name", None)
                elif prop.type == 'COLLECTION':
                    # Usually complex (e.g., vertex groups), skip for safety
                    continue
                else:
                    # Scalars, enums, vectors, etc.
                    if isinstance(val, (list, tuple)):
                        m["properties"][pid] = tuple(val)
                    else:
                        m["properties"][pid] = val
            except Exception:
                continue

        snaps.append(m)
    return snaps

def rebuild_modifiers(obj, snaps):
    """Recreate modifiers from snapshots. Best-effort."""
    obj.modifiers.clear()
    for m in snaps:
        try:
            newm = obj.modifiers.new(name=m["name"], type=m["type"])
            # Restore base flags
            newm.show_viewport = m.get("show_viewport", True)
            newm.show_render = m.get("show_render", True)
            if hasattr(newm, "show_in_editmode"):
                newm.show_in_editmode = m.get("show_in_editmode", False)
            if hasattr(newm, "show_on_cage"):
                newm.show_on_cage = m.get("show_on_cage", False)
            if hasattr(newm, "show_expanded"):
                newm.show_expanded = m.get("show_expanded", True)

            # Restore properties
            for pid, val in m.get("properties", {}).items():
                try:
                    prop = newm.bl_rna.properties.get(pid)
                    if not prop or prop.is_readonly:
                        continue
                    if prop.type == 'POINTER':
                        if val is None:
                            setattr(newm, pid, None)
                        else:
                            # Try resolve as Object first, then Collection.
                            target = bpy.data.objects.get(val) or bpy.data.collections.get(val)
                            if target is not None:
                                setattr(newm, pid, target)
                    else:
                        setattr(newm, pid, val)
                except Exception:
                    continue
        except Exception:
            continue

def snapshot_modifier_drivers(obj):
    """Capture drivers that target modifier properties on this object."""
    ad = obj.animation_data
    if not ad or not ad.drivers:
        return []

    drivers = []
    for fcu in ad.drivers:
        try:
            if not (fcu.data_path or "").startswith('modifiers["'):
                continue
            d = fcu.driver
            item = {
                "data_path": fcu.data_path,
                "array_index": fcu.array_index,
                "driver_type": d.type,
                "expression": d.expression,
                "use_self": d.use_self,
                "variables": [],
            }
            for var in d.variables:
                v = {"name": var.name, "type": var.type, "targets": []}
                for t in var.targets:
                    tv = {
                        "id_type": t.id_type,
                        "id_name": getattr(t.id, "name", None) if t.id else None,
                        "data_path": t.data_path,
                        "transform_type": getattr(t, "transform_type", None),
                        "transform_space": getattr(t, "transform_space", None),
                        "bone_target": getattr(t, "bone_target", None),
                    }
                    v["targets"].append(tv)
                item["variables"].append(v)
            drivers.append(item)
        except Exception:
            continue
    return drivers

def restore_modifier_drivers(obj, drivers):
    """Restore drivers captured by snapshot_modifier_drivers()."""
    if not drivers:
        return

    for item in drivers:
        try:
            try:
                fcu = obj.driver_add(item["data_path"], item["array_index"])
            except TypeError:
                # Blender reports scalar driver F-Curves with array_index == 0,
                # but driver_add() rejects an explicit index for scalar RNA.
                fcu = obj.driver_add(item["data_path"])
            d = fcu.driver
            d.type = item.get("driver_type", 'SCRIPTED')
            d.expression = item.get("expression", "")
            d.use_self = item.get("use_self", False)

            # Clear default variables
            while d.variables:
                d.variables.remove(d.variables[0])

            for v in item.get("variables", []):
                var = d.variables.new()
                var.name = v.get("name", "var")
                var.type = v.get("type", 'SINGLE_PROP')
                # Ensure targets count matches type expectations; set as many as available.
                for i, tv in enumerate(v.get("targets", [])):
                    if i >= len(var.targets):
                        break
                    t = var.targets[i]
                    try:
                        t.id_type = tv.get("id_type", t.id_type)
                    except Exception:
                        pass
                    id_name = tv.get("id_name")
                    if id_name:
                        # Resolve ID
                        rid = bpy.data.objects.get(id_name) or bpy.data.armatures.get(id_name) or bpy.data.meshes.get(id_name) or bpy.data.collections.get(id_name)
                        if rid:
                            t.id = rid
                    t.data_path = tv.get("data_path", "")
                    if hasattr(t, "transform_type") and tv.get("transform_type") is not None:
                        t.transform_type = tv["transform_type"]
                    if hasattr(t, "transform_space") and tv.get("transform_space") is not None:
                        t.transform_space = tv["transform_space"]
                    if hasattr(t, "bone_target") and tv.get("bone_target") is not None:
                        t.bone_target = tv["bone_target"]
        except Exception:
            continue
