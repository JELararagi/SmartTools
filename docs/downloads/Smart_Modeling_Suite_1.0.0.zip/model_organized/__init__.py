# -*- coding: utf-8 -*-
import bpy
import webbrowser

# ------------------------------------------------------------------------------
bl_info = {
    "name": "Model Organizer",
    "author": "Smart Modeling",
    "version": (2, 0, 2),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Model Organizer",
    "description": "Model organization suite. Presets, safe transform, cleanup, modifier keep, backup/restore.",
    "category": "Object",
}

from .translation import register_i18n, unregister_i18n
from .backup import MO2_BackupItem
from .properties import MO2_Settings, register_scene_props, unregister_scene_props
from .operators import MO2_OT_OrganizeModal, MO2_OT_RestoreBackup, MO2_OT_ClearBackup, MO2_OT_RenameDataToObjectName
from .ui import (
    MO2_PT_MainPanel, MO2_PT_Modifiers, MO2_PT_Transforms, MO2_PT_CleanData,
    MO2_PT_OriginPivot, MO2_PT_RenameCollections,
    update_panel_category, draw_smart_modeling_settings,
)

classes = (
    MO2_BackupItem,
    MO2_Settings,
    MO2_OT_OrganizeModal,
    MO2_OT_RestoreBackup,
    MO2_OT_ClearBackup,
    MO2_OT_RenameDataToObjectName,
    MO2_PT_MainPanel,
    MO2_PT_Modifiers,
    MO2_PT_Transforms,
    MO2_PT_CleanData,
    MO2_PT_OriginPivot,
    MO2_PT_RenameCollections,
)

_MO2_PROPERTY_CLASSES = (
    MO2_BackupItem,
    MO2_Settings,
)

_MO2_RUNTIME_CLASSES = tuple(cls for cls in classes if cls not in _MO2_PROPERTY_CLASSES)


def register():
    register_i18n(__name__)

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass

    register_scene_props()

def unregister():
    for cls in reversed(_MO2_RUNTIME_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    unregister_scene_props()

    for cls in reversed(_MO2_PROPERTY_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    unregister_i18n(__name__)

if __name__ == "__main__":
    register()
