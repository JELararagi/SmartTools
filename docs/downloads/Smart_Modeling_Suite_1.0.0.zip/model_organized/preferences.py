# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Stable RNA type for older Model Organizer settings attachments."""

from bpy.types import PropertyGroup


class MO2_AddonPreferences(PropertyGroup):
    """The suite supplies its shared panel category."""
