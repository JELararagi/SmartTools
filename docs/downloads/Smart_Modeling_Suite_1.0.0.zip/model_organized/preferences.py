import bpy


class MO2_AddonPreferences(bpy.types.PropertyGroup):
    """Compatibility container for shared Model Organizer settings.

    The N-panel category is fixed to Smart Modeling by the suite, so no user-facing
    tab-name setting is exposed here.
    """
    pass
