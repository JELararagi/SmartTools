import bpy

# NOTE:
# - Use bpy.app.translations.pgettext("English String") in UI/Reports.
# - Add translations here keyed by the exact English string.

translation_dict = {
    "ja_JP": {
        ("*", "Model organization suite. Presets, safe transform, cleanup, modifier keep, backup/restore."):
            "モデル整理セット。プリセット/安全なトランスフォーム適用/クリーンアップ/モディファイア保持/バックアップ&復元",

        # UI - Panel
        ("*", "Model Organizer"): "モデル整理",
        ("*", "Organize Selection"): '選択を整理',
        ("*", "Restore Last Backup"): "直前バックアップを復元",
        ("*", "Clear Backup Data"): "バックアップデータを削除",
        ("*", "No mesh objects selected."): "メッシュオブジェクトが選択されていません。",
        ("*", "Organized {count} objects."): "{count} 個のオブジェクトを整理しました。",
        ("*", "Canceled. Restored from backup."): "キャンセルしました。バックアップから復元しました。",
        ("*", "Canceled."): "キャンセルしました。",
        ("*", "Restored {count} objects from backup."): "{count} 個のオブジェクトをバックアップから復元しました。",
        ("*", "No backup to restore."): "復元できるバックアップがありません。",
        ("*", "Backup cleared."): "バックアップを削除しました。",

        ("*", "Clean, normalize, and organize the selected objects using the active preset while creating a reversible backup."):
            "アクティブプリセットに従って選択オブジェクトを整理・正規化し、戻せるバックアップも同時に作成します。",
        ("*", "Restore the most recent backup created by the organize operator."):
            "整理オペレーターが作成した最新バックアップを復元します。",
        ("*", "Delete the temporary backup data stored by Model Organizer when you no longer need to restore it."):
            '復元の必要がなくなったときに、モデル整理が保持している一時バックアップデータを削除します。',
        # Sections
        ("*", "Preset"): "プリセット",
        ("*", "Safety"): '安全',
        ("*", "Modifiers"): "モディファイア",
        ("*", "Transforms"): "トランスフォーム",
        ("*", "Clean Data"): 'データ整理',
        ("*", "Origin / Pivot"): "原点 / ピボット",
        ("*", "Rename / Collections"): "リネーム / コレクション",
        ("*", "Preflight Checks"): "事前チェック",
        ("*", "Backup / Restore"): "バックアップ / 復元",
        ("*", "Progress"): '進行状況',

        # Presets
        ("*", "Game Export"): "ゲーム書き出し",
        ("*", "Rig Prep"): "リグ前処理",
        ("*", "Model Cleanup"): "モデリング仕上げ",
        ("*", "Custom"): "カスタム",

        # Modifier modes
        ("*", "Bake / Apply All"): "ベイク（全適用）",
        ("*", "Keep Modifiers (Link Copy)"): "保持（リンクコピー）",
        ("*", "Keep Modifiers (Rebuild)"): "保持（再構築）",
        ("*", "Keep + Protect (Safe)"): "保持 + 保護（安全）",

        # Options
        ("*", "Apply Location"): "位置を適用",
        ("*", "Apply Rotation"): "回転を適用",
        ("*", "Apply Scale"): "スケールを適用",
        ("*", "Shade Smooth"): "スムーズシェード",
        ("*", "Set Object Color"): "オブジェクトカラー設定",
        ("*", "Set Wire Off"): 'ワイヤー表示をオフ',
        ("*", "Object Color"): "オブジェクトカラー",

        ("*", "Remove Crease Attributes"): "クリース属性を削除",
        ("*", "Remove Bevel Weight Attributes"): "ベベルウェイト属性を削除",
        ("*", "Clear Custom Normals"): "カスタム法線をクリア",
        ("*", "Recalculate Normals"): "法線を再計算",
        ("*", "Convert Geometry Nodes to Standard Mesh"): "ジオメトリノードを標準メッシュ化",
        ("*", "Merge by Distance"): "距離でマージ",
        ("*", "Distance"): "距離",
        ("*", "Delete Loose Geometry"): "ルースジオメトリ削除",
        ("*", "Remove Empty Material Slots"): "空マテリアルスロット削除",
        ("*", "Purge Orphans"): "不要データのパージ",
        ("*", "Rename Data to Object Name"): "データ名をオブジェクト名に改名",

        ("*", "Origin Mode"): "原点モード",
        ("*", "World Origin (0,0,0)"): "原点（0,0,0）",
        ("*", "Choose where the object origin/pivot is placed after organization. The default moves the origin to the world origin at coordinates 0, 0, 0 while preserving the visible mesh position."):
            '整理の後の原点の位置を選びます。既定では見た目の位置を保ったまま原点をワールドの 0, 0, 0 へ動かします。',
        ("*", "Place the object origin/pivot at the world origin coordinates 0, 0, 0 while keeping the mesh visually in place"):
            'メッシュの見た目を保ったまま、原点をワールドの 0, 0, 0 に置く',
        ("*", "None"): "なし",
        ("*", "To Geometry"): "ジオメトリへ",
        ("*", "Center of Mass"): "重心",
        ("*", "To 3D Cursor"): "3Dカーソルへ",

        ("*", "Enable Rename"): "リネーム有効",
        ("*", "Rename Pattern"): "リネームパターン",
        ("*", "Start Index"): "開始番号",
        ("*", "Enable Move To Collection"): "コレクション移動有効",
        ("*", "Target Collection"): '対象のコレクション',
        ("*", "Remove Empty Collections"): "空コレクション削除",

        ("*", "Enable Preflight"): "事前チェック有効",
        ("*", "Check Non-Manifold"): "非多様体チェック",
        ("*", "Check Negative Scale"): "負スケールチェック",
        ("*", "Auto Fix Negative Scale"): "負スケール自動修正",
        ("*", "Warn Shape Keys / Armature"): "シェイプキー/アーマチュア警告",

        ("*", "Enable Backup"): "バックアップ有効",
        ("*", "Restore on Cancel"): "キャンセル時に復元",

        # Reports / warnings
        ("*", "Preflight: {msg}"): "事前チェック: {msg}",
        ("*", "Non-manifold edges found: {count}"): "非多様体エッジ検出: {count}",
        ("*", "Negative scale detected."): "負スケールを検出しました。",
        ("*", "Shape keys detected. Safe mode will skip Location/Rotation apply."): "シェイプキーを検出しました。安全モードでは位置/回転適用をスキップします。",
        ("*", "Armature modifier detected. Safe mode will skip Location/Rotation apply."): "Armatureモディファイアを検出しました。安全モードでは位置/回転適用をスキップします。",
        ("*", "Animated or driven transforms were detected. Unsafe transform and origin changes were skipped."): "アニメーションまたはドライバー付きトランスフォームを検出しました。安全に適用できないトランスフォーム変更と原点変更をスキップしました。",
        ("*", "Origin mode 'None': the origin was moved back to its original position after the transform changes."): "原点モードが「なし」のため、トランスフォーム変更後に原点を元の位置へ戻しました。",
        ("*", "A disabled Geometry Nodes modifier was left unchanged."): "無効化されているジオメトリノードモディファイアは変更せず保持しました。",
        ("*", "A Geometry Nodes modifier produced no mesh at the current frame and was left unchanged."): "現在のフレームでメッシュを生成していないジオメトリノードモディファイアは変更せず保持しました。",
        ("*", "A Geometry Nodes modifier could not be converted safely and was left unchanged."): "安全に変換できないジオメトリノードモディファイアは変更せず保持しました。",
        ("*", "Error on {name}: {err}"): "エラー ({name}): {err}",
    }
}

def register_i18n(addon_module_name: str):
    try:
        bpy.app.translations.register(addon_module_name, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(addon_module_name)
        except Exception:
            pass
        bpy.app.translations.register(addon_module_name, translation_dict)

def unregister_i18n(addon_module_name: str):
    try:
        bpy.app.translations.unregister(addon_module_name)
    except Exception:
        pass

translation_dict["ja_JP"].update({
    ("*", "Choose a ready-made workflow preset. Use this when you want a safer starting point instead of configuring every cleanup option manually."):
        "既成のワークフロープリセットを選択します。すべての整理項目を手動調整する代わりに、安全な出発点が欲しいときに使います。",
    ("*", "Choose how modifiers are handled during organization. Bake applies them, while the Keep modes try to preserve or rebuild them after cleanup."):
        '整理中にモディファイアをどう扱うかを選びます。ベイクは適用し、維持の方式はクリーンアップ後に保持または再構築を試みます。',
    ("*", "When a rebuild-style modifier mode is used, also try to preserve drivers that target modifier properties."):
        "再構築系のモディファイア保持モード使用時、モディファイアの各プロパティを参照するドライバーも可能な限り保持します。",
    ("*", "Clean, normalize, and organize the selected objects using the active preset while creating a reversible backup. Includes transform safety, cleanup helpers, modifier preservation, and batch organization options."):
        "アクティブプリセットに従って選択オブジェクトを整理・正規化し、戻せるバックアップも同時に作成します。トランスフォーム安全処理、クリーンアップ補助、モディファイア保持、バッチ整理オプションを含みます。",
    ("*", "Restore the most recent backup created by the organize operator."):
        "整理オペレーターが作成した最新バックアップを復元します。",
    ("*", "Delete the temporary backup data stored by Model Organizer when you no longer need to restore it."):
        '復元の必要がなくなったときに、モデル整理が保持している一時バックアップデータを削除します。',
})



translation_dict["ja_JP"].update({
    ("*", "Keep Modifier Drivers"): "モディファイアドライバーを保持",
    ("*", "Apply the object location transform during organization."): "整理中にオブジェクトの位置トランスフォームを適用します。",
    ("*", "Apply the object rotation transform during organization."): "整理中にオブジェクトの回転トランスフォームを適用します。",
    ("*", "Apply the object scale transform during organization."): "整理中にオブジェクトのスケールトランスフォームを適用します。",
    ("*", "Set mesh shading to smooth after the cleanup pass."): "クリーンアップ後にメッシュのシェーディングをスムーズへ設定します。",
    ("*", "Assign a viewport object color after processing."): "処理後にビューポート用オブジェクトカラーを割り当てます。",
    ("*", "Viewport object color applied when Set Object Color is enabled."): '「オブジェクトの色を設定」が有効の時に適用するビューポートの色です。',
    ("*", "Disable per-object wireframe overlay after organization."): "整理後にオブジェクト単位のワイヤーフレームオーバーレイを無効化します。",
    ("*", "Clear mesh crease data from the processed objects."): "処理対象オブジェクトからメッシュのクリースデータを消去します。",
    ("*", "Clear bevel-weight data from edges and vertices when supported."): "対応環境では、辺や頂点のベベルウェイトデータを消去します。",
    ("*", "Remove stored custom split normals before recalculating or exporting."): "再計算や書き出し前に保存済みカスタム分割法線を除去します。",
    ("*", "Recalculate mesh normals outside after cleanup."): "クリーンアップ後にメッシュ法線を外側向きへ再計算します。",
    ("*", "Apply every Geometry Nodes modifier on each processed mesh object and bake the node-generated result into ordinary editable mesh data. When a Curve object is selected, its bevel, extrusion, taper, fill, and resolution render geometry is also converted to an ordinary editable mesh. Geometry Nodes modifiers are removed after a successful conversion; other modifiers continue to follow the Modifiers setting."): "処理対象の各メッシュオブジェクトにあるジオメトリノードモディファイアを適用し、ノードで生成された結果を通常編集できる標準メッシュデータへ変換します。カーブオブジェクトを選択している場合は、ベベル、押し出し、テーパー、フィル、解像度などのレンダリング設定で生成される形状も、通常編集できる標準メッシュへ変換します。正常に変換できたジオメトリノードモディファイアは削除され、その他のモディファイアは「モディファイア」の設定に従います。",
    ("*", "Merge nearby duplicate vertices as part of the cleanup step."): "クリーンアップ工程の一部として、近接重複頂点を統合します。",
    ("*", "Distance threshold used for Merge by Distance."): '距離でマージに使う距離のしきい値です。',
    ("*", "Delete loose vertices and edges that are not part of faces."): "面に属していないルース頂点や辺を削除します。",
    ("*", "Remove unused empty material slots from processed mesh objects."): "処理対象メッシュオブジェクトから未使用の空マテリアルスロットを除去します。",
    ("*", "Run an orphan-data purge after the organization pass."): "整理処理後に不要データのパージを実行します。",
    ("*", "Rename each processed mesh data-block to match its final object name."): "処理済みメッシュのデータ名を最終的なオブジェクト名に揃えます。",
    ("*", "Set object origin after processing"): "処理後にオブジェクト原点を設定します。",
    ("*", "Rename processed objects using the pattern below."): "下のパターンを使って処理済みオブジェクトをリネームします。",
    ("*", "Pattern used when renaming objects, for example {name}_{index}."): 'オブジェクトをリネームするときのパターンです。例: {name}_{index}',
    ("*", "Starting index used by the rename pattern."): "リネームパターンで使う開始番号です。",
    ("*", "Move processed objects into the target collection."): "処理済みオブジェクトを指定コレクションへ移動します。",
    ("*", "Name of the collection that will receive processed objects."): "処理済みオブジェクトを受け取るコレクション名です。",
    ("*", "Remove empty source collections after moving the objects."): "オブジェクト移動後に空になった元コレクションを削除します。",
    ("*", "Run validation checks before modifying the selected objects."): "選択オブジェクトを変更する前に検証チェックを実行します。",
    ("*", "Warn when non-manifold edges are found during preflight."): "事前チェックで非多様体エッジが見つかったときに警告します。",
    ("*", "Warn when negative object scale is detected."): "負のオブジェクトスケールが検出されたときに警告します。",
    ("*", "Attempt to correct negative scale safely when it is detected."): "負スケールが検出された際、安全に補正を試みます。",
    ("*", "Warn when shape keys or armature modifiers make transform application risky."): "シェイプキーやアーマチュアモディファイアがあり、トランスフォーム適用が危険なときに警告します。",
    ("*", "Create a temporary reversible backup before making changes."): "変更前に一時的な復元可能バックアップを作成します。",
    ("*", "Restore from the temporary backup if the organize operator is cancelled."): '整理のコマンドがキャンセルされた場合、一時バックアップから復元します。',
    ("*", "Backup ID"): "バックアップ ID",
    ("*", "Internal backup identifier used by Model Organizer."): 'モデル整理が使う内部バックアップ識別子です。',
    ("*", "MO2 Backup ID"): 'モデル整理のバックアップ ID',
    ("*", "Internal scene-level backup identifier used by Model Organizer."): "Model Organizer が使うシーン単位の内部バックアップ識別子です。",
})

translation_dict["ja_JP"].update({
    ("*", "Execution"): "実行",
    ("*", "Restore Backup"): "バックアップを復元",
    ("*", "Select mesh objects, adjust the settings below, then run Organize Selection."):
        "メッシュオブジェクトを選択し、下の設定を調整してから「選択オブジェクトを整理」を実行します。",
    ("*", "Display"): "表示",
    ("*", "Location"): "位置",
    ("*", "Rotation"): "回転",
    ("*", "Scale"): "スケール",
    ("*", "Stored Backups: {count}"): "保存済みバックアップ: {count}",
    ("*", "Model Organizer settings are not registered."): "モデル整理の設定が登録されていません。",
    ("*", "Unavailable"): "使用不可",
    ("*", "Could not start Model Organizer: {err}"): "モデル整理を開始できませんでした: {err}",
    ("*", "Could not rename mesh data: {err}"): "メッシュデータ名を変更できませんでした: {err}",
})

# Report / error message catalog for the organize execution path.  The outer
# report templates are formatted with pgettext-translated inner messages, so
# every inner message that can reach self.report() is listed here as well.
translation_dict["ja_JP"].update({
    # Operator-level report templates
    ("*", "Could not create a complete Model Organizer backup."): "モデル整理の完全なバックアップを作成できませんでした。",
    ("*", "Could not clear Model Organizer transaction data: {err}"): "モデル整理のトランザクションデータを削除できませんでした: {err}",
    ("*", "Could not restore the original selection or mode: {err}"): "元の選択状態またはモードを復元できませんでした: {err}",
    ("*", "Could not fully roll back Model Organizer: {err}"): "モデル整理を完全にロールバックできませんでした: {err}",
    ("*", "Model Organizer post-processing failed: {err}"): "モデル整理の後処理に失敗しました: {err}",
    ("*", "Model Organizer attempted {name} more than once."): "モデル整理が {name} を複数回処理しようとしました。",
    ("*", "Could not roll back {name}: {err}"): "{name} をロールバックできませんでした: {err}",
    ("*", "Object was removed before Model Organizer could process it."): "モデル整理が処理する前にオブジェクトが削除されました。",
    # process_object result messages
    ("*", "Model Organizer requires a mesh object."): "モデル整理にはメッシュオブジェクトが必要です。",
    ("*", "Model Organizer requires object geometry data."): "モデル整理にはオブジェクトの形状データが必要です。",
    ("*", "Linked library objects are read-only. Make a local override before organizing."): "リンクされたライブラリオブジェクトは読み取り専用です。整理する前にローカルオーバーライドを作成してください。",
    ("*", "Object is not editable."): "オブジェクトが編集できません。",
    ("*", "Active constraints prevent safe transform or origin application."): "有効なコンストレイントがあるため、トランスフォームや原点の適用を安全に行えません。",
    # Core execution errors surfaced through the report templates
    ("*", "Could not switch to Object Mode."): "オブジェクトモードに切り替えられませんでした。",
    ("*", "Operator target is not available in the active view layer."): "オペレーターの対象がアクティブなビューレイヤーにありません。",
    ("*", "Blender did not apply the requested object transforms."): "要求されたオブジェクトのトランスフォームを適用できませんでした。",
    ("*", "Blender did not smooth the requested object."): "要求されたオブジェクトにスムーズシェードを適用できませんでした。",
    ("*", "Could not enter Edit Mode to clear custom normals."): "カスタム法線をクリアするための編集モードに入れませんでした。",
    ("*", "Could not select the mesh to clear custom normals."): "カスタム法線をクリアするメッシュを選択できませんでした。",
    ("*", "Blender did not clear custom normals."): "カスタム法線をクリアできませんでした。",
    ("*", "Could not return to Object Mode after clearing custom normals."): "カスタム法線のクリア後にオブジェクトモードへ戻れませんでした。",
    ("*", "Blender did not set the requested object origin."): "要求されたオブジェクト原点を設定できませんでした。",
    ("*", "Multiple processed objects still share one mesh data-block."): "処理した複数のオブジェクトが 1 つのメッシュデータを共有したままです。",
    ("*", "Model Organizer requires an editable mesh object."): "モデル整理には編集可能なメッシュオブジェクトが必要です。",
    ("*", "Mesh data is not editable."): "メッシュデータが編集できません。",
    ("*", "Could not safely apply negative Scale."): "負のスケールを安全に適用できませんでした。",
    ("*", "Could not bake the modifier stack."): "モディファイアスタックをベイクできませんでした。",
    ("*", "Applying transforms would change the evaluated modifier result; this object was left unchanged."): "トランスフォームを適用するとモディファイアの評価結果が変わるため、このオブジェクトは変更しませんでした。",
    ("*", "Could not create the temporary modifier carrier."): "一時的なモディファイア保持用オブジェクトを作成できませんでした。",
    ("*", "Could not restore the original modifier stack."): "元のモディファイアスタックを復元できませんでした。",
    # Curve render-geometry conversion errors
    ("*", "Could not restore modifiers after converting curve render geometry."): "カーブのレンダー形状をメッシュ化した後、モディファイアを復元できませんでした。",
    ("*", "The curve modifier stack failed its post-conversion validation."): "変換後のカーブモディファイアスタックの検証に失敗しました。",
    ("*", "Blender did not convert the curve render geometry to a mesh."): "カーブのレンダー形状をメッシュへ変換できませんでした。",
    ("*", "Curve render geometry conversion did not produce a standard mesh object."): "カーブのレンダー形状変換で標準メッシュオブジェクトが生成されませんでした。",
    # Geometry Nodes conversion errors
    ("*", "A Geometry Nodes modifier became unavailable before evaluation."): "評価前にジオメトリノードモディファイアが利用できなくなりました。",
    ("*", "A Geometry Nodes modifier became unavailable before it could be applied."): "適用前にジオメトリノードモディファイアが利用できなくなりました。",
    # Backup / rollback errors
    ("*", "Blender did not restore the modifier stack."): "モディファイアスタックを復元できませんでした。",
    ("*", "The restored modifier stack failed its postcondition."): "復元したモディファイアスタックの事後検証に失敗しました。",
    # Enum item descriptions not covered elsewhere
    ("*", "Snapshot and rebuild modifiers (best-effort)"): "モディファイアをスナップショットして再構築します（ベストエフォート）",
    ("*", "Rebuild with safety rules for rigs/shape keys"): "リグ/シェイプキー向けの安全ルールで再構築します",
    ("*", "Do not change origin"): "原点を変更しません",
    ("*", "Origin to geometry"): "原点をジオメトリへ移動します",
    ("*", "Origin to 3D cursor"): "原点を3Dカーソルへ移動します",
    # Panel descriptions not covered by the suite-wide catalog
    ("*", "Origin / Pivot panel in the Smart Modeling workspace."): 'Smart Modeling ワークスペースの原点 / ピボットのパネルです。',
    ("*", "Rename / Collections panel in the Smart Modeling workspace."): 'Smart Modeling ワークスペースの名前変更 / コレクションのパネルです。',
    ("*", "Guide / Tips help panel with workflow notes and beginner guidance."): 'ワークフローの補足と初心者向けガイドを表示するヘルプパネルです。',
})

# Standalone "Rename Data to Object Name" operator in the Clean Data section.
# The label shares the msgid of the organize option above.
translation_dict["ja_JP"].update({
    ("*", "Rename the data-block of each selected object to match its object name. Multi-user, linked, and library data-blocks are skipped and reported. Running it again changes nothing."):
        '選択中の各オブジェクトのデータ名をオブジェクト名に合わせます。複数で共有、リンク、ライブラリのデータは飛ばして報告します。もう一度実行しても変わりません。',
    ("*", "No selected objects have data-blocks."): "データブロックを持つオブジェクトが選択されていません。",
    ("*", "Skipped {count} data-block(s): multi-user, linked, or the name is already in use."):
        "{count} 個のデータブロックをスキップしました（マルチユーザー、リンク、または同名データが既に存在）。",
    ("*", "Data names already match the object names."): "データ名はすでにオブジェクト名と一致しています。",
    ("*", "Renamed {count} data-block(s)."): "{count} 個のデータブロック名をオブジェクト名に改名しました。",
})
