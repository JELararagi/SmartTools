import bpy
from bpy.types import PropertyGroup
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty,
    PointerProperty, StringProperty, IntProperty, CollectionProperty
)
from .core import apply_preset
from .backup import MO2_BackupItem

def _update_preset(self, context):
    apply_preset(self)

def _update_panel_category_pref(self, context):
    # handled in prefs.py
    return None

class MO2_Settings(PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        description="Choose a ready-made workflow preset. Use this when you want a safer starting point instead of configuring every cleanup option manually.",
        items=[
            ('GAME_EXPORT', "Game Export", "Export-ready (FBX/GLTF) oriented settings"),
            ('RIG_PREP', "Rig Prep", "Safer settings for rigs/shape keys"),
            ('MODEL_CLEANUP', "Model Cleanup", "General cleanup for modeling"),
            ('CUSTOM', "Custom", "Do not overwrite settings automatically"),
        ],
        default='CUSTOM',
        update=_update_preset
    )

    keep_mode: EnumProperty(
        name="Modifiers",
        description="Choose how modifiers are handled during organization. Bake applies them, while the Keep modes try to preserve or rebuild them after cleanup.",
        items=[
            ('BAKE', "Bake / Apply All", "Apply all modifiers (convert to mesh)"),
            ('KEEP_LINK', "Keep Modifiers (Link Copy)", "Temporary duplicate and link-copy modifiers back"),
            ('KEEP_REBUILD', "Keep Modifiers (Rebuild)", "Snapshot and rebuild modifiers (best-effort)"),
            ('KEEP_SAFE', "Keep + Protect (Safe)", "Rebuild with safety rules for rigs/shape keys"),
        ],
        default='KEEP_LINK'
    )
    keep_modifier_drivers: BoolProperty(
        name="Keep Modifier Drivers",
        description="When a rebuild-style modifier mode is used, also try to preserve drivers that target modifier properties.",
        default=True
    )

    # Transforms
    apply_location: BoolProperty(name="Apply Location", description="Apply the object location transform during organization.", default=True)
    apply_rotation: BoolProperty(name="Apply Rotation", description="Apply the object rotation transform during organization.", default=True)
    apply_scale: BoolProperty(name="Apply Scale", description="Apply the object scale transform during organization.", default=True)

    # Shading / display
    shade_smooth: BoolProperty(name="Shade Smooth", description="Set mesh shading to smooth after the cleanup pass.", default=True)
    set_object_color: BoolProperty(name="Set Object Color", description="Assign a viewport object color after processing.", default=True)
    object_color: FloatVectorProperty(
        name="Object Color",
        subtype='COLOR',
        size=4,
        min=0.0, max=1.0,
        description="Viewport object color applied when Set Object Color is enabled.",
        default=(0.0, 0.0, 0.0, 1.0)
    )
    set_wire_off: BoolProperty(name="Set Wire Off", description="Disable per-object wireframe overlay after organization.", default=True)

    # Clean Data
    remove_crease: BoolProperty(name="Remove Crease Attributes", description="Clear mesh crease data from the processed objects.", default=True)
    remove_bevel_weight: BoolProperty(name="Remove Bevel Weight Attributes", description="Clear bevel-weight data from edges and vertices when supported.", default=True)
    clear_custom_normals: BoolProperty(name="Clear Custom Normals", description="Remove stored custom split normals before recalculating or exporting.", default=False)
    recalc_normals: BoolProperty(name="Recalculate Normals", description="Recalculate mesh normals outside after cleanup.", default=False)
    convert_geometry_nodes_to_mesh: BoolProperty(
        name="Convert Geometry Nodes to Standard Mesh",
        description="Apply every Geometry Nodes modifier on each processed mesh object and bake the node-generated result into ordinary editable mesh data. When a Curve object is selected, its bevel, extrusion, taper, fill, and resolution render geometry is also converted to an ordinary editable mesh. Geometry Nodes modifiers are removed after a successful conversion; other modifiers continue to follow the Modifiers setting.",
        default=False,
    )
    merge_by_distance: BoolProperty(name="Merge by Distance", description="Merge nearby duplicate vertices as part of the cleanup step.", default=False)
    merge_distance: FloatProperty(name="Distance", description="Distance threshold used for Merge by Distance.", default=0.0001, min=0.0, precision=6)
    delete_loose: BoolProperty(name="Delete Loose Geometry", description="Delete loose vertices and edges that are not part of faces.", default=False)
    remove_empty_material_slots: BoolProperty(name="Remove Empty Material Slots", description="Remove unused empty material slots from processed mesh objects.", default=False)
    purge_orphans: BoolProperty(name="Purge Orphans", description="Run an orphan-data purge after the organization pass.", default=False)
    rename_data_to_object_name: BoolProperty(name="Rename Data to Object Name", description="Rename each processed mesh data-block to match its final object name.", default=False)

    # Origin / Pivot
    origin_mode: EnumProperty(
        name="Origin Mode",
        description="Choose where the object origin/pivot is placed after organization. The default moves the origin to the world origin at coordinates 0, 0, 0 while preserving the visible mesh position.",
        items=[
            ('WORLD_ORIGIN', "World Origin (0,0,0)", "Place the object origin/pivot at the world origin coordinates 0, 0, 0 while keeping the mesh visually in place"),
            ('NONE', "None", "Do not change origin"),
            ('GEOMETRY', "To Geometry", "Origin to geometry"),
            ('COM', "Center of Mass", "Origin to center of mass"),
            ('CURSOR', "To 3D Cursor", "Origin to 3D cursor"),
        ],
        default='WORLD_ORIGIN'
    )

    # Rename / collections
    rename_enable: BoolProperty(name="Enable Rename", description="Rename processed objects using the pattern below.", default=False)
    rename_pattern: StringProperty(name="Rename Pattern", description="Pattern used when renaming objects, for example {name}_{index}.", default="{name}")
    rename_start_index: IntProperty(name="Start Index", description="Starting index used by the rename pattern.", default=1, min=0)

    move_to_collection_enable: BoolProperty(name="Enable Move To Collection", description="Move processed objects into the target collection.", default=False)
    target_collection: StringProperty(name="Target Collection", description="Name of the collection that will receive processed objects.", default="MO_Organized")
    remove_empty_collections: BoolProperty(name="Remove Empty Collections", description="Remove empty source collections after moving the objects.", default=False)

    # Preflight
    preflight_enable: BoolProperty(name="Enable Preflight", description="Run validation checks before modifying the selected objects.", default=False)
    check_nm_edges: BoolProperty(name="Check Non-Manifold", description="Warn when non-manifold edges are found during preflight.", default=False)
    check_negative_scale: BoolProperty(name="Check Negative Scale", description="Warn when negative object scale is detected.", default=False)
    auto_fix_negative_scale: BoolProperty(name="Auto Fix Negative Scale", description="Attempt to correct negative scale safely when it is detected.", default=False)
    warn_shapekeys_armature: BoolProperty(name="Warn Shape Keys / Armature", description="Warn when shape keys or armature modifiers make transform application risky.", default=True)

    # Backup
    backup_enable: BoolProperty(name="Enable Backup", description="Create a temporary reversible backup before making changes.", default=False)
    restore_on_cancel: BoolProperty(name="Restore on Cancel", description="Restore from the temporary backup if the organize operator is cancelled.", default=False)

class MO2_SceneBackup(PropertyGroup):
    mo2_backup_id: StringProperty(name="Backup ID", description="Internal backup identifier used by Model Organizer.", default="")
    mo2_backup_items: CollectionProperty(type=MO2_BackupItem, description='Collection for Mo2 Backup Items. The tool stores multiple items here, such as presets, reports, backups, or temporary entries.')

def register_scene_props():
    unregister_scene_props()
    bpy.types.Scene.mo2_props = PointerProperty(type=MO2_Settings, description='Stores settings for Model Organizer.')
    bpy.types.Scene.mo2_backup_id = StringProperty(name="MO2 Backup ID", description="Internal scene-level backup identifier used by Model Organizer.", default="")
    bpy.types.Scene.mo2_backup_items = CollectionProperty(type=MO2_BackupItem, description='Stores temporary backup entries for Model Organizer.')

def unregister_scene_props():
    if hasattr(bpy.types.Scene, "mo2_props"):
        del bpy.types.Scene.mo2_props
    if hasattr(bpy.types.Scene, "mo2_backup_id"):
        del bpy.types.Scene.mo2_backup_id
    if hasattr(bpy.types.Scene, "mo2_backup_items"):
        del bpy.types.Scene.mo2_backup_items
