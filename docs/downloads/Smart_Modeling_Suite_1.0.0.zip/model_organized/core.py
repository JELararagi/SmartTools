import bpy
import bmesh
from contextlib import contextmanager
from mathutils import Matrix, Vector
from . import modifiers as mo_mod

def ensure_object_mode(context):
    if context.object and context.object.mode != 'OBJECT':
        result = bpy.ops.object.mode_set(mode='OBJECT')
        if 'FINISHED' not in result:
            raise RuntimeError("Could not switch to Object Mode.")

def capture_selection_state(context):
    """Return a stable selection/active snapshot for operator context repair."""
    selected = [obj for obj in context.view_layer.objects if obj is not None and obj.select_get()]
    return selected, context.view_layer.objects.active

def restore_selection_state(context, selected, active):
    """Restore selection without relying on the current operator override."""
    for obj in context.view_layer.objects:
        if obj is None:
            continue
        try:
            obj.select_set(False)
        except Exception:
            pass
    for obj in selected or ():
        try:
            if obj and obj.name in context.view_layer.objects:
                obj.select_set(True)
        except Exception:
            pass
    try:
        if active and active.name in context.view_layer.objects:
            context.view_layer.objects.active = active
        else:
            context.view_layer.objects.active = None
    except Exception:
        pass

@contextmanager
def object_operator_context(context, active, selected=None):
    """Build and restore the exact active/selection context required by bpy.ops."""
    if active is None or active.name not in context.view_layer.objects:
        raise RuntimeError("Operator target is not available in the active view layer.")
    selected = list(selected or (active,))
    if active not in selected:
        selected.insert(0, active)
    selected = [obj for obj in selected if obj and obj.name in context.view_layer.objects]
    editable = [obj for obj in selected if getattr(obj, "is_editable", True)]
    previous_selected, previous_active = capture_selection_state(context)
    try:
        restore_selection_state(context, selected, active)
        override = {
            "object": active,
            "active_object": active,
            "selected_objects": selected,
            "selected_editable_objects": editable,
        }
        with context.temp_override(**override):
            yield
    finally:
        restore_selection_state(context, previous_selected, previous_active)

def _select_only(context, obj):
    for o in context.selected_objects:
        try: o.select_set(False)
        except Exception: pass
    try:
        obj.select_set(True)
        context.view_layer.objects.active = obj
    except Exception:
        pass

_TRANSFORM_DATA_PATHS = {
    "location": {"location"},
    "rotation": {"rotation_euler", "rotation_quaternion", "rotation_axis_angle"},
    "scale": {"scale"},
}

def _iter_active_action_fcurves(obj):
    animation = getattr(obj, "animation_data", None)
    action = getattr(animation, "action", None) if animation else None
    if action is None:
        return

    for curve in getattr(action, "fcurves", ()):
        yield curve

    slot = getattr(animation, "action_slot", None)
    if slot is None:
        return
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            try:
                channelbag = strip.channelbag(slot, ensure=False)
            except Exception:
                channelbag = None
            if channelbag is not None:
                yield from channelbag.fcurves

def _animated_transform_channels(obj):
    animation = getattr(obj, "animation_data", None)
    if animation is None:
        return set()

    paths = set()
    for curve in getattr(animation, "drivers", ()):
        if not getattr(curve, "mute", False):
            paths.add(curve.data_path)
    for curve in _iter_active_action_fcurves(obj):
        if not getattr(curve, "mute", False):
            paths.add(curve.data_path)

    channels = {
        channel
        for channel, data_paths in _TRANSFORM_DATA_PATHS.items()
        if paths.intersection(data_paths)
    }
    for track in getattr(animation, "nla_tracks", ()):
        if getattr(track, "mute", False):
            continue
        if any(not getattr(strip, "mute", False) for strip in track.strips):
            channels.update(_TRANSFORM_DATA_PATHS)
            break
    return channels

def _has_active_constraints(obj):
    return any(
        not getattr(constraint, "mute", False)
        and float(getattr(constraint, "influence", 1.0)) > 0.0
        for constraint in obj.constraints
    )

def _rotation_is_identity(obj, tolerance=1.0e-6):
    if obj.rotation_mode == 'QUATERNION':
        values = obj.rotation_quaternion
        return abs(values[0] - 1.0) <= tolerance and all(abs(value) <= tolerance for value in values[1:])
    if obj.rotation_mode == 'AXIS_ANGLE':
        return abs(obj.rotation_axis_angle[0]) <= tolerance
    return all(abs(value) <= tolerance for value in obj.rotation_euler)

def _evaluated_world_bounds(context, obj):
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        if not mesh.vertices:
            return None
        points = [evaluated.matrix_world @ vertex.co for vertex in mesh.vertices]
        return tuple(
            tuple(fn(point[axis] for point in points) for axis in range(3))
            for fn in (min, max)
        )
    finally:
        evaluated.to_mesh_clear()

def _bounds_match(left, right, tolerance=2.0e-4):
    if left is None or right is None:
        return left is right
    return all(
        abs(float(a) - float(b)) <= tolerance
        for left_corner, right_corner in zip(left, right)
        for a, b in zip(left_corner, right_corner)
    )

_MIRROR_FRAME_MARKER = "_smart_modeling_mirror_frame_v1"

def _create_implicit_mirror_frame(context, obj):
    """Give implicit Mirror modifiers a stable copy of their current frame.

    A Mirror modifier with no ``mirror_object`` uses the owning object's local
    origin.  Moving that origin therefore moves the evaluated mirror plane even
    when the source mesh is rebased correctly.  Materialize the old object
    matrix as one add-on-owned Empty before transform/origin changes.  Explicit
    user mirror objects are never changed.
    """
    implicit = [
        modifier
        for modifier in obj.modifiers
        if modifier.type == 'MIRROR' and modifier.mirror_object is None
    ]
    if not implicit:
        return None

    helper = bpy.data.objects.new(f"_SM_MirrorFrame_{obj.name_full}", None)
    try:
        helper[_MIRROR_FRAME_MARKER] = True
        helper["_smart_modeling_owner"] = obj.name_full
        helper.empty_display_type = 'PLAIN_AXES'
        helper.empty_display_size = 0.1
        helper.hide_select = True
        helper.hide_render = True
        helper.hide_viewport = True
        helper.matrix_world = obj.matrix_world.copy()
        context.scene.collection.objects.link(helper)
        for modifier in implicit:
            modifier.mirror_object = helper
        context.view_layer.update()
        return helper
    except Exception:
        for modifier in implicit:
            try:
                if modifier.mirror_object == helper:
                    modifier.mirror_object = None
            except Exception:
                pass
        if helper.name in bpy.data.objects:
            bpy.data.objects.remove(helper, do_unlink=True)
        raise

def cleanup_unused_mirror_frame_helpers(helpers=None):
    """Remove only unreferenced Empty objects owned by this feature."""
    candidates = tuple(helpers) if helpers is not None else tuple(bpy.data.objects)
    eligible = []
    for helper in candidates:
        try:
            if (
                helper is None
                or helper.name not in bpy.data.objects
                or helper.type != 'EMPTY'
                or getattr(helper, "library", None) is not None
                or getattr(helper, "override_library", None) is not None
                or not bool(helper.get(_MIRROR_FRAME_MARKER, False))
                or bool(getattr(helper, "use_fake_user", False))
                or helper.users > len(helper.users_collection)
            ):
                continue
            eligible.append(helper)
        except ReferenceError:
            continue

    if not eligible:
        return 0
    try:
        user_map = bpy.data.user_map(subset=eligible)
    except Exception:
        # Ownership information is incomplete: retain every helper rather than
        # risking deletion of an object referenced by a constraint or other ID.
        return 0

    removed = 0
    for helper in eligible:
        try:
            users = user_map.get(helper, ())
            if any(
                not isinstance(user, (bpy.types.Scene, bpy.types.Collection))
                for user in users
            ):
                continue
            referenced = any(
                modifier.type == 'MIRROR'
                and getattr(modifier, "mirror_object", None) == helper
                for candidate in bpy.data.objects
                for modifier in getattr(candidate, "modifiers", ())
            )
            if referenced:
                continue
            bpy.data.objects.remove(helper, do_unlink=True)
            removed += 1
        except ReferenceError:
            continue
    return removed

def apply_transforms(context, obj, loc=True, rot=True, scale=True):
    if not any((loc, rot, scale)):
        return
    with object_operator_context(context, obj):
        result = bpy.ops.object.transform_apply(location=loc, rotation=rot, scale=scale)
    if 'FINISHED' not in result:
        raise RuntimeError("Blender did not apply the requested object transforms.")
    context.view_layer.update()
    failed = []
    if loc and any(abs(value) > 1.0e-6 for value in obj.location):
        failed.append("Location")
    if rot and not _rotation_is_identity(obj):
        failed.append("Rotation")
    if scale and any(abs(value - 1.0) > 1.0e-6 for value in obj.scale):
        failed.append("Scale")
    if failed:
        raise RuntimeError("Transform values were not reset: " + ", ".join(failed))

def shade_smooth(context, obj):
    try:
        with object_operator_context(context, obj):
            result = bpy.ops.object.shade_smooth()
        if 'FINISHED' not in result:
            raise RuntimeError("Blender did not smooth the requested object.")
    except Exception:
        # Fallback: set smooth flag per polygon
        me = obj.data
        if me and hasattr(me, "polygons"):
            for p in me.polygons:
                p.use_smooth = True

def remove_mesh_attributes(mesh, remove_crease=True, remove_bevel=True):
    if not hasattr(mesh, "attributes"):
        return
    targets = []
    if remove_crease:
        targets += ['crease_edge', 'crease_vert']
    if remove_bevel:
        targets += ['bevel_weight_edge', 'bevel_weight_vert']
    for name in targets:
        if name in mesh.attributes:
            try:
                mesh.attributes.remove(mesh.attributes[name])
            except Exception:
                pass

def clear_custom_normals(context, obj):
    # Needs edit mode operator for reliable clearing
    if not bool(getattr(getattr(obj, "data", None), "has_custom_normals", False)):
        return
    try:
        with object_operator_context(context, obj):
            if 'FINISHED' not in bpy.ops.object.mode_set(mode='EDIT'):
                raise RuntimeError("Could not enter Edit Mode to clear custom normals.")
            try:
                if 'FINISHED' not in bpy.ops.mesh.select_all(action='SELECT'):
                    raise RuntimeError("Could not select the mesh to clear custom normals.")
                if 'FINISHED' not in bpy.ops.mesh.customdata_custom_splitnormals_clear():
                    raise RuntimeError("Blender did not clear custom normals.")
            finally:
                if 'FINISHED' not in bpy.ops.object.mode_set(mode='OBJECT'):
                    raise RuntimeError("Could not return to Object Mode after clearing custom normals.")
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(f"Could not clear custom normals: {exc}") from exc

def recalc_normals_bmesh(mesh):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    try:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    except Exception:
        pass
    bm.to_mesh(mesh)
    bm.free()

def merge_by_distance(mesh, dist=0.0001):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    try:
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)
    except Exception:
        pass
    bm.to_mesh(mesh)
    bm.free()

def delete_loose_geometry(mesh):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    # Loose verts: no edges and no faces
    loose_verts = [v for v in bm.verts if (not v.link_edges and not v.link_faces)]
    # Loose edges: no faces
    loose_edges = [e for e in bm.edges if (not e.link_faces)]
    try:
        if loose_edges:
            bmesh.ops.delete(bm, geom=loose_edges, context='EDGES')
        if loose_verts:
            bmesh.ops.delete(bm, geom=loose_verts, context='VERTS')
    except Exception:
        pass
    bm.to_mesh(mesh)
    bm.free()

def remove_empty_material_slots(obj):
    me = obj.data
    if not me or not hasattr(me, "materials"):
        return
    mats = [m for m in me.materials if m is not None]
    if len(mats) == len(me.materials):
        return
    me.materials.clear()
    for m in mats:
        me.materials.append(m)

def purge_orphans():
    # Best-effort, may require repeating
    try:
        for _ in range(3):
            res = bpy.ops.outliner.orphans_purge(do_recursive=True)
            if 'CANCELLED' in res:
                break
    except Exception:
        pass

def _set_origin_to_world_point(context, obj, point):
    """Move *obj*'s origin to a world-space point while keeping the mesh visually in place."""
    with object_operator_context(context, obj):
        scene = getattr(context, 'scene', None)
        cursor = getattr(scene, 'cursor', None) if scene is not None else None
        old_cursor = None
        try:
            if cursor is not None:
                old_cursor = cursor.location.copy()
                cursor.location = point
        except Exception:
            old_cursor = None
        try:
            result = bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        finally:
            try:
                if cursor is not None and old_cursor is not None:
                    cursor.location = old_cursor
            except Exception:
                pass
        if 'FINISHED' not in result:
            raise RuntimeError("Blender did not set the requested object origin.")

def _transform_mesh_keep_facing(mesh, matrix):
    """Bake ``matrix`` into ``mesh`` without turning faces inside out.

    ``Mesh.transform`` keeps the corner order, so a mirroring matrix (negative
    determinant, e.g. a negative Scale or a negatively scaled parent) leaves
    every face facing inward.  Flip the winding back the way Apply Transform
    does, and re-apply custom normals in their transformed visible directions
    so the shading stays identical.
    """
    matrix = Matrix(matrix)
    mirrored = matrix.to_3x3().determinant() < 0.0
    custom = None
    if mirrored and getattr(mesh, "has_custom_normals", False):
        normal_matrix = matrix.to_3x3().inverted_safe().transposed()
        corner_normals = mesh.corner_normals
        custom = {}
        for polygon in mesh.polygons:
            for loop_index in polygon.loop_indices:
                custom[(polygon.index, mesh.loops[loop_index].vertex_index)] = (
                    normal_matrix @ Vector(corner_normals[loop_index].vector)
                ).normalized()
    mesh.transform(matrix, shape_keys=True)
    if not mirrored:
        return
    mesh.flip_normals()
    if custom:
        normals = [(0.0, 0.0, 0.0)] * len(mesh.loops)
        for polygon in mesh.polygons:
            for loop_index in polygon.loop_indices:
                value = custom.get((polygon.index, mesh.loops[loop_index].vertex_index))
                if value is not None:
                    normals[loop_index] = tuple(value)
        mesh.normals_split_custom_set(normals)
    mesh.update()

def _set_origin_to_world_point_exact(context, obj, point):
    """Set an editable mesh origin in world coordinates without cursor context.

    The cursor operator can resolve through an object's parent/local matrix while
    a batch is rebuilding parent inverses.  Rebase mesh coordinates against the
    exact old/new world matrices instead, so the requested world pivot and every
    visible world-space vertex are both explicit invariants.
    """
    if obj.type != 'MESH' or obj.data is None:
        _set_origin_to_world_point(context, obj, point)
        return
    old_world = obj.matrix_world.copy()
    child_inverses = [
        (child, child.matrix_parent_inverse.copy())
        for child in obj.children
        if str(getattr(child, "parent_type", "OBJECT") or "OBJECT") == 'OBJECT'
    ]
    # WORLD_ORIGIN is the organizer's final transform-reset contract, not only
    # a translation change.  Rebase the mesh by the complete old world matrix
    # so the visible model remains fixed while the output object becomes an
    # identity transform at the requested world-space point.  Copying the old
    # basis here left unchecked Rotation/Scale channels in the final result.
    target_world = Matrix.Translation(Vector(point))
    local_rebase = target_world.inverted_safe() @ old_world
    _transform_mesh_keep_facing(obj.data, local_rebase)
    obj.delta_location = (0.0, 0.0, 0.0)
    obj.delta_scale = (1.0, 1.0, 1.0)
    obj.delta_rotation_euler = (0.0, 0.0, 0.0)
    obj.delta_rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    obj.matrix_basis = Matrix.Identity(4)
    if (
        obj.parent is not None
        and str(getattr(obj, "parent_type", "OBJECT") or "OBJECT") == 'OBJECT'
    ):
        # Represent the exact world target in the existing parent frame.  A
        # direct matrix_world assignment can be re-resolved from stale local
        # channels when the depsgraph updates, causing the safety postcondition
        # to roll the object back even though its geometry was rebased correctly.
        obj.matrix_parent_inverse = obj.parent.matrix_world.inverted_safe() @ target_world
    else:
        obj.matrix_world = target_world
    for child, old_inverse in child_inverses:
        if child.name in bpy.data.objects and child.parent == obj:
            child.matrix_parent_inverse = target_world.inverted_safe() @ old_world @ old_inverse
    context.view_layer.update()
    if any(
        abs(float(obj.matrix_world[row][column]) - float(target_world[row][column])) > 1.0e-6
        for row in range(4)
        for column in range(4)
    ):
        raise RuntimeError("Blender did not set the requested world-space identity transform.")

def set_origin(context, obj, mode, initial_origin=None):
    # mode: 'WORLD_ORIGIN'|'NONE'|'GEOMETRY'|'COM'|'CURSOR'
    # Returns True when mode 'NONE' had to move the origin back to its
    # pre-processing position, None otherwise.
    mode = str(mode or 'WORLD_ORIGIN')
    if mode == 'NONE':
        # "Do not change origin": earlier steps (applying Location, or the
        # exact parent-apply matrix bake) relocate the origin as a side
        # effect. Restore the origin captured before processing so the
        # user-visible pivot stays exactly where it was.
        if initial_origin is None:
            return None
        context.view_layer.update()
        if all(abs(current - initial) <= 1.0e-6
               for current, initial in zip(obj.matrix_world.translation, initial_origin)):
            return None
        _set_origin_to_world_point(context, obj, tuple(initial_origin))
        return True
    if mode == 'WORLD_ORIGIN':
        _set_origin_to_world_point_exact(context, obj, (0.0, 0.0, 0.0))
        return None
    with object_operator_context(context, obj):
        if mode == 'GEOMETRY':
            result = bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        elif mode == 'COM':
            # Blender supports center of mass option in newer versions
            try:
                result = bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
            except Exception:
                result = bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        elif mode == 'CURSOR':
            result = bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        else:
            raise RuntimeError(f"Unknown origin mode: {mode}")
        if 'FINISHED' not in result:
            raise RuntimeError("Blender did not set the requested object origin.")

def rename_objects(objects, pattern="{name}", start_index=1):
    used = set(o.name for o in bpy.data.objects)
    idx = start_index
    for obj in objects:
        base_name = obj.name
        new_name = pattern.replace("{name}", base_name).replace("{index}", str(idx))
        # Ensure unique
        if new_name in used and new_name != obj.name:
            suffix = 1
            candidate = f"{new_name}.{suffix:03d}"
            while candidate in used:
                suffix += 1
                candidate = f"{new_name}.{suffix:03d}"
            new_name = candidate
        obj.name = new_name
        used.add(new_name)
        idx += 1

def rename_data_to_object_names(objects):
    """Rename processed mesh data-blocks to their final object names."""
    pairs = []
    by_data = {}
    for obj in objects:
        data = getattr(obj, "data", None)
        if getattr(obj, "type", None) != 'MESH' or data is None:
            continue
        key = data.as_pointer()
        previous = by_data.get(key)
        if previous is not None and previous != obj.name:
            raise RuntimeError("Multiple processed objects still share one mesh data-block.")
        if previous is None:
            by_data[key] = obj.name
            pairs.append((obj, data))

    selected_data = {data.as_pointer() for _obj, data in pairs}
    for obj, data in pairs:
        existing = bpy.data.meshes.get(obj.name)
        if existing is not None and existing.as_pointer() not in selected_data:
            raise RuntimeError(f"Mesh data name '{obj.name}' is already used outside the processed selection.")

    originals = [(data, data.name) for _obj, data in pairs]
    try:
        # Free all selected names first so swaps/cycles are deterministic.
        for index, (_obj, data) in enumerate(pairs):
            data.name = f"__MO2_DATA_SYNC_{index:04d}__"
        for obj, data in pairs:
            data.name = obj.name
            if data.name != obj.name:
                raise RuntimeError(f"Blender assigned '{data.name}' instead of '{obj.name}'.")
    except Exception:
        try:
            for index, (data, _name) in enumerate(originals):
                data.name = f"__MO2_DATA_ROLLBACK_{index:04d}__"
            for data, name in originals:
                data.name = name
        except Exception:
            pass
        raise
    return len(pairs)

def move_objects_to_collection(context, objects, collection_name: str, remove_empty_collections=False):
    if not collection_name:
        return
    target = bpy.data.collections.get(collection_name)
    if not target:
        target = bpy.data.collections.new(collection_name)
        context.scene.collection.children.link(target)
    for obj in objects:
        # unlink from all collections then link to target
        for col in list(obj.users_collection):
            try:
                col.objects.unlink(obj)
            except Exception:
                pass
        try:
            target.objects.link(obj)
        except Exception:
            pass
    if remove_empty_collections:
        cleanup_empty_collections()

def cleanup_empty_collections():
    # remove empty collections without children
    changed = True
    while changed:
        changed = False
        for col in list(bpy.data.collections):
            if col.name == "Collection":
                continue
            if len(col.objects) == 0 and len(col.children) == 0:
                try:
                    bpy.data.collections.remove(col)
                    changed = True
                except Exception:
                    pass

def preflight_checks(obj, do_nonmanifold=True, do_neg_scale=True):
    """Return list of warning strings (English)."""
    warnings = []
    if do_neg_scale:
        try:
            sx, sy, sz = obj.scale
            if (sx * sy * sz) < 0.0:
                warnings.append("Negative scale detected.")
        except Exception:
            pass

    if do_nonmanifold and obj.type == 'MESH' and obj.data:
        try:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            non = sum(1 for e in bm.edges if not e.is_manifold)
            bm.free()
            if non > 0:
                warnings.append(f"Non-manifold edges found: {non}")
        except Exception:
            pass
    return warnings

def fix_negative_scale(context, obj):
    # Best-effort: apply scale then recalc normals (can change look if custom normals exist).
    _select_only(context, obj)
    try:
        apply_transforms(context, obj, loc=False, rot=False, scale=True)
    except Exception:
        return False
    return True

def make_unique_mesh(obj):
    if obj.type != 'MESH' or not obj.data:
        raise RuntimeError("Model Organizer requires an editable mesh object.")
    if obj.data.users > 1 or getattr(obj.data, "library", None) is not None:
        obj.data = obj.data.copy()
    if not getattr(obj.data, "is_editable", True):
        raise RuntimeError("Mesh data is not editable.")

def _restore_curve_modifier_carrier(context, obj, carrier, driver_snaps):
    """Restore the exact modifier stack saved before Curve-to-Mesh conversion."""
    if carrier is None:
        return
    result = {'CANCELLED'}
    try:
        with object_operator_context(context, carrier, (carrier, obj)):
            result = bpy.ops.object.make_links_data(type='MODIFIERS')
        if 'FINISHED' not in set(result or ()):
            raise RuntimeError("Could not restore modifiers after converting curve render geometry.")
        expected = [(modifier.name, modifier.type) for modifier in carrier.modifiers]
        actual = [(modifier.name, modifier.type) for modifier in obj.modifiers]
        if actual != expected:
            raise RuntimeError("The curve modifier stack failed its post-conversion validation.")
        if driver_snaps:
            mo_mod.restore_modifier_drivers(obj, driver_snaps)
    finally:
        if carrier and carrier.name in bpy.data.objects:
            bpy.data.objects.remove(carrier, do_unlink=True)


def convert_curve_render_geometry_to_mesh(context, obj):
    """Convert legacy Curve bevel/extrude render geometry to an editable Mesh.

    ``object.convert`` is the Blender-owned conversion path that evaluates Curve
    bevel, extrusion, taper, fill, and resolution settings.  It also applies every
    modifier by default, so the original modifier stack is carried outside the
    conversion and linked back immediately afterward.  Geometry Nodes modifiers can
    then be handled by ``apply_geometry_nodes_modifiers`` under the existing option,
    while all other modifiers continue to follow the selected Modifiers mode.
    """
    if obj.type != 'CURVE' or obj.data is None:
        return False

    carrier = None
    temporary_curve_data = None
    if obj.data.users > 1 or getattr(obj.data, "library", None) is not None:
        temporary_curve_data = obj.data.copy()
        obj.data = temporary_curve_data

    driver_snaps = mo_mod.snapshot_modifier_drivers(obj)
    if len(obj.modifiers):
        carrier = obj.copy()
        carrier.animation_data_clear()
        carrier.name = f"_MO_CurveModifierCarrier_{obj.name}"
        context.scene.collection.objects.link(carrier)
        carrier.hide_render = True
        carrier.hide_viewport = False
        carrier.hide_select = False
        obj.modifiers.clear()

    conversion_finished = False
    try:
        with object_operator_context(context, obj):
            result = bpy.ops.object.convert(target='MESH')
        conversion_finished = 'FINISHED' in set(result or ())
        if not conversion_finished:
            raise RuntimeError("Blender did not convert the curve render geometry to a mesh.")
        if obj.type != 'MESH' or not isinstance(getattr(obj, "data", None), bpy.types.Mesh):
            raise RuntimeError("Curve render geometry conversion did not produce a standard mesh object.")
        if carrier is not None:
            _restore_curve_modifier_carrier(context, obj, carrier, driver_snaps)
            carrier = None
        context.view_layer.update()
        return True
    finally:
        # On an operator failure the object may still be a Curve with its modifier
        # stack cleared. Restore that stack before allowing the transaction rollback
        # to run. If conversion succeeded but modifier restoration failed, the
        # transaction backup remains the authority for the complete rollback.
        if carrier is not None:
            if not conversion_finished and obj.type == 'CURVE':
                try:
                    _restore_curve_modifier_carrier(context, obj, carrier, driver_snaps)
                    carrier = None
                except Exception:
                    pass
            if carrier is not None and carrier.name in bpy.data.objects:
                bpy.data.objects.remove(carrier, do_unlink=True)
        if temporary_curve_data is not None and temporary_curve_data.users == 0:
            try:
                if bpy.data.curves.get(temporary_curve_data.name) == temporary_curve_data:
                    bpy.data.curves.remove(temporary_curve_data)
            except Exception:
                pass


def has_shape_keys(obj):
    try:
        return bool(obj.data and obj.data.shape_keys)
    except Exception:
        return False

def has_armature_modifier(obj):
    try:
        return any(m.type == 'ARMATURE' for m in obj.modifiers)
    except Exception:
        return False

def has_risky_modifiers(obj):
    try:
        return any(mo_mod.is_risky_modifier(m) for m in obj.modifiers)
    except Exception:
        return False

def keep_modifiers_linkcopy_prepare(context, obj):
    """Return (temp_obj, dummy_mesh)"""
    with object_operator_context(context, obj):
        result = bpy.ops.object.duplicate(linked=True)
        temp = context.view_layer.objects.active
    if 'FINISHED' not in result or temp is None or temp == obj:
        raise RuntimeError("Could not create the temporary modifier carrier.")
    dummy = bpy.data.meshes.new(f"MO_Dummy_{obj.name}")
    temp.data = dummy
    obj.modifiers.clear()
    return temp, dummy

def keep_modifiers_linkcopy_restore(context, obj, temp):
    result = {'CANCELLED'}
    try:
        with object_operator_context(context, temp, (temp, obj)):
            result = bpy.ops.object.make_links_data(type='MODIFIERS')
    finally:
        if temp and temp.name in bpy.data.objects:
            bpy.data.objects.remove(temp, do_unlink=True)
    if 'FINISHED' not in result:
        raise RuntimeError("Could not restore the original modifier stack.")

@contextmanager
def _evaluate_modifier_stack_through(context, obj, modifier):
    """Temporarily hide modifiers below *modifier* while it is evaluated.

    Geometry Nodes modifiers can output a geometry set without a mesh component.
    Calling ``object.modifier_apply`` in that state emits a Blender error before
    Python can handle it.  This helper lets the caller inspect the exact stack
    result through the target modifier first, without permanently changing any
    modifier visibility state.
    """
    modifiers = tuple(getattr(obj, "modifiers", ()))
    try:
        index = modifiers.index(modifier)
    except ValueError as exc:
        raise RuntimeError("A Geometry Nodes modifier became unavailable before evaluation.") from exc

    hidden_states = []
    try:
        for later_modifier in modifiers[index + 1:]:
            try:
                visible = bool(later_modifier.show_viewport)
                hidden_states.append((later_modifier, visible))
                if visible:
                    later_modifier.show_viewport = False
            except Exception:
                # Continue with the best available evaluation. The state is still
                # restored below for every modifier that was read successfully.
                pass
        context.view_layer.update()
        yield
    finally:
        for later_modifier, visible in hidden_states:
            try:
                later_modifier.show_viewport = visible
            except Exception:
                pass
        try:
            context.view_layer.update()
        except Exception:
            pass


def _geometry_nodes_has_nonempty_mesh_output(context, obj, modifier):
    """Return whether the stack through *modifier* contains usable mesh data.

    Blender cannot apply a Geometry Nodes modifier whose evaluated geometry set
    contains only curves, point clouds, volumes, instances, or an empty geometry
    set to a mesh object.  Detecting that condition before invoking the operator
    prevents the host-level error report and allows Model Organizer to preserve
    the modifier instead of cancelling the whole object transaction.
    """
    if not bool(getattr(modifier, "show_viewport", True)):
        return False, "DISABLED"

    with _evaluate_modifier_stack_through(context, obj, modifier):
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)

        geometry_getter = getattr(evaluated, "evaluated_geometry", None)
        if callable(geometry_getter):
            geometry = geometry_getter()
            mesh = getattr(geometry, "mesh", None)
            if mesh is None:
                return False, "NO_MESH"
            counts = (
                len(getattr(mesh, "vertices", ())),
                len(getattr(mesh, "edges", ())),
                len(getattr(mesh, "polygons", ())),
            )
            return any(counts), "MESH" if any(counts) else "NO_MESH"

        # Compatibility fallback for Blender builds without GeometrySet access.
        mesh = evaluated.to_mesh()
        try:
            counts = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
            return any(counts), "MESH" if any(counts) else "NO_MESH"
        finally:
            evaluated.to_mesh_clear()


def apply_geometry_nodes_modifiers(context, obj, report_cb=None):
    """Bake only Geometry Nodes modifiers into the current mesh object.

    Other modifier types are left in their original relative order and continue to
    follow the Model Organizer modifier handling mode.  Every apply result is
    checked before processing continues so the caller's transaction backup can
    restore the object cleanly on failure.
    """
    node_modifier_names = [
        str(getattr(modifier, "name", "") or "")
        for modifier in tuple(getattr(obj, "modifiers", ()))
        if getattr(modifier, "type", "") == 'NODES'
    ]
    if not node_modifier_names:
        return 0
    applied = 0
    for name in node_modifier_names:
        modifier = obj.modifiers.get(name) if name else None
        if modifier is None:
            raise RuntimeError("A Geometry Nodes modifier became unavailable before it could be applied.")

        has_mesh, output_state = _geometry_nodes_has_nonempty_mesh_output(
            context,
            obj,
            modifier,
        )
        if not has_mesh:
            if report_cb:
                if output_state == "DISABLED":
                    report_cb("A disabled Geometry Nodes modifier was left unchanged.")
                else:
                    report_cb("A Geometry Nodes modifier produced no mesh at the current frame and was left unchanged.")
            # Applying a later modifier while an earlier Geometry Nodes modifier
            # remains in the stack is not deterministic in Blender. Preserve the
            # remaining stack exactly instead of attempting out-of-order applies.
            break

        try:
            with object_operator_context(context, obj):
                result = bpy.ops.object.modifier_apply(modifier=name, report=False)
        except RuntimeError:
            # A dependency can change between the evaluated preflight and the
            # operator call. If Blender left the modifier intact, preserve it and
            # continue rather than rolling back all other safe organization work.
            if obj.modifiers.get(name) is not None:
                if report_cb:
                    report_cb("A Geometry Nodes modifier could not be converted safely and was left unchanged.")
                break
            raise
        if 'FINISHED' not in set(result or ()):
            if obj.modifiers.get(name) is not None:
                if report_cb:
                    report_cb("A Geometry Nodes modifier could not be converted safely and was left unchanged.")
                break
            raise RuntimeError(f"Could not apply Geometry Nodes modifier: {name}")
        if obj.modifiers.get(name) is not None:
            raise RuntimeError(f"Geometry Nodes modifier was not removed after apply: {name}")
        if obj.type != 'MESH' or not isinstance(getattr(obj, "data", None), bpy.types.Mesh):
            raise RuntimeError(f"Geometry Nodes conversion did not produce a standard mesh object: {name}")
        applied += 1
    try:
        context.view_layer.update()
    except Exception:
        pass
    return applied


def process_object(context, obj, settings, report_cb=None):
    """Process a single object. Returns (ok: bool, msg: str)."""
    # Keep selection stable by operating per object
    created_mirror_helper = None
    try:
        convert_curve = bool(settings.get("convert_geometry_nodes_to_mesh", False)) and obj.type == 'CURVE'
        if obj.type != 'MESH' and not convert_curve:
            return False, "Model Organizer requires a mesh object."
        if obj.data is None:
            return False, "Model Organizer requires object geometry data."
        if getattr(obj, "library", None) is not None and getattr(obj, "override_library", None) is None:
            return False, "Linked library objects are read-only. Make a local override before organizing."
        if not getattr(obj, "is_editable", True):
            return False, "Object is not editable."

        keep_mode = settings.get("keep_mode", "KEEP_LINK")
        verify_modifier_bounds = bool(obj.modifiers) and not any(
            settings.get(name, False)
            for name in ("merge_by_distance", "delete_loose")
        )
        modifier_bounds_before = _evaluated_world_bounds(context, obj) if verify_modifier_bounds else None
        attribute_cleanup_preapplied = False
        temp_obj = None
        dummy_mesh = None
        driver_snaps = None

        # Safe/protect mode: adjust apply settings if risky
        apply_loc = settings.get("apply_location", True)
        apply_rot = settings.get("apply_rotation", True)
        apply_sca = settings.get("apply_scale", True)

        if keep_mode == "KEEP_SAFE":
            if has_shape_keys(obj):
                apply_loc = False
                apply_rot = False
                if report_cb:
                    report_cb("Shape keys detected. Safe mode will skip Location/Rotation apply.")
            if has_armature_modifier(obj):
                apply_loc = False
                apply_rot = False
                if report_cb:
                    report_cb("Armature modifier detected. Safe mode will skip Location/Rotation apply.")
            if has_risky_modifiers(obj):
                # still allow scale apply by default
                pass

        origin_mode = settings.get("origin_mode", "WORLD_ORIGIN")
        # Origin mode 'NONE' promises an unchanged origin, so record the
        # pre-processing world origin before any step can relocate it. When
        # the modal pre-baked this object (exact parent apply), its transforms
        # are already zeroed and the true initial origin lives in the bake
        # matrix instead of the current world matrix.
        exact_apply_matrix_setting = settings.get("_exact_apply_matrix")
        if exact_apply_matrix_setting is not None:
            initial_origin = Matrix(exact_apply_matrix_setting).to_translation()
        else:
            initial_origin = obj.matrix_world.translation.copy()
        requested_channels = {
            channel
            for channel, enabled in (
                ("location", apply_loc),
                ("rotation", apply_rot),
                ("scale", apply_sca),
            )
            if enabled
        }
        auto_fix_scale = False
        if settings.get("auto_fix_negative_scale", False):
            sx, sy, sz = obj.scale
            auto_fix_scale = (
                (sx * sy * sz) < 0.0
                and (settings.get("clear_custom_normals", False) or settings.get("recalc_normals", False))
            )
            if auto_fix_scale:
                requested_channels.add("scale")

        origin_requested = str(origin_mode or 'WORLD_ORIGIN') != 'NONE'
        if _has_active_constraints(obj) and (requested_channels or origin_requested):
            return False, "Active constraints prevent safe transform or origin application."
        animated_channels = _animated_transform_channels(obj)
        conflicts = requested_channels.intersection(animated_channels)
        inner_dependencies = {
            "location": {"rotation", "scale"},
            "rotation": {"scale"},
            "scale": frozenset(),
        }
        for channel in requested_channels:
            if animated_channels.intersection(inner_dependencies[channel]):
                conflicts.add(channel)

        # Animated/driven transforms must be preserved. Skip only unsafe
        # transform/origin operations for this object instead of cancelling every
        # other requested cleanup action.
        if "location" in conflicts:
            apply_loc = False
        if "rotation" in conflicts:
            apply_rot = False
        if "scale" in conflicts:
            apply_sca = False
            auto_fix_scale = False
        if origin_requested and animated_channels:
            origin_mode = 'NONE'
        if conflicts or (origin_requested and animated_channels):
            if report_cb:
                report_cb("Animated or driven transforms were detected. Unsafe transform and origin changes were skipped.")

        if convert_curve:
            convert_curve_render_geometry_to_mesh(context, obj)

        make_unique_mesh(obj)

        if settings.get("convert_geometry_nodes_to_mesh", False):
            apply_geometry_nodes_modifiers(context, obj, report_cb=report_cb)

        # Crease/bevel attribute removal intentionally changes a Subsurf result.
        # Establish the transform/origin preservation baseline after that explicit
        # cleanup, so the final modifier-bound check does not misclassify the
        # requested cleanup as a failed transform and roll the object back.
        if (
            keep_mode in {"KEEP_LINK", "KEEP_REBUILD", "KEEP_SAFE"}
            and verify_modifier_bounds
            and obj.modifiers
        ):
            mesh = obj.data if obj.type == 'MESH' else None
            if mesh and (
                settings.get("remove_crease", True)
                or settings.get("remove_bevel_weight", True)
            ):
                remove_mesh_attributes(
                    mesh,
                    remove_crease=settings.get("remove_crease", True),
                    remove_bevel=settings.get("remove_bevel_weight", True),
                )
                attribute_cleanup_preapplied = True
                context.view_layer.update()
                modifier_bounds_before = _evaluated_world_bounds(context, obj)

        will_change_transform_or_origin = (
            any((apply_loc, apply_rot, apply_sca))
            or auto_fix_scale
            or origin_mode != 'NONE'
        )
        if keep_mode in {"KEEP_LINK", "KEEP_REBUILD", "KEEP_SAFE"} and will_change_transform_or_origin:
            created_mirror_helper = _create_implicit_mirror_frame(context, obj)
            if created_mirror_helper is not None:
                settings.setdefault("_created_mirror_helpers", []).append(created_mirror_helper)

        # Preflight auto fix negative scale (if requested)
        if auto_fix_scale and not fix_negative_scale(context, obj):
            raise RuntimeError("Could not safely apply negative Scale.")

        # Modifier handling
        if keep_mode == "BAKE":
            with object_operator_context(context, obj):
                result = bpy.ops.object.convert(target='MESH')
            if 'FINISHED' not in result:
                raise RuntimeError("Could not bake the modifier stack.")
        elif keep_mode in {"KEEP_LINK", "KEEP_REBUILD", "KEEP_SAFE"}:
            driver_snaps = mo_mod.snapshot_modifier_drivers(obj) if settings.get("keep_modifier_drivers", True) else None
            temp_obj, dummy_mesh = keep_modifiers_linkcopy_prepare(context, obj)
        else:
            # default to link mode
            temp_obj, dummy_mesh = keep_modifiers_linkcopy_prepare(context, obj)

        try:
            # Apply transforms
            exact_apply_matrix = settings.get("_exact_apply_matrix")
            if exact_apply_matrix is not None and apply_loc and apply_rot and apply_sca:
                matrix = Matrix(exact_apply_matrix)
                _transform_mesh_keep_facing(obj.data, matrix)
                obj.location = (0.0, 0.0, 0.0)
                obj.scale = (1.0, 1.0, 1.0)
                if obj.rotation_mode == 'QUATERNION':
                    obj.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                elif obj.rotation_mode == 'AXIS_ANGLE':
                    obj.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
                else:
                    obj.rotation_euler = (0.0, 0.0, 0.0)
                context.view_layer.update()
            else:
                apply_transforms(context, obj, loc=apply_loc, rot=apply_rot, scale=apply_sca)

            # Smooth shading
            if settings.get("shade_smooth", True):
                shade_smooth(context, obj)

            # Clean Data
            mesh = obj.data if obj.type == 'MESH' else None
            if mesh:
                if not attribute_cleanup_preapplied:
                    remove_mesh_attributes(mesh,
                                           remove_crease=settings.get("remove_crease", True),
                                           remove_bevel=settings.get("remove_bevel_weight", True))

                if settings.get("merge_by_distance", False):
                    merge_by_distance(mesh, settings.get("merge_distance", 0.0001))

                if settings.get("delete_loose", False):
                    delete_loose_geometry(mesh)

                if settings.get("clear_custom_normals", False):
                    clear_custom_normals(context, obj)

                if settings.get("recalc_normals", False):
                    # if custom normals were cleared or user doesn't care
                    recalc_normals_bmesh(mesh)

            if settings.get("remove_empty_material_slots", False):
                remove_empty_material_slots(obj)

            # Display tweaks
            if settings.get("set_object_color", False):
                obj.color = settings.get("object_color", (0.0, 0.0, 0.0, 1.0))
            if settings.get("set_wire_off", False):
                obj.show_wire = False

            # Origin
            origin_restored = set_origin(context, obj, origin_mode, initial_origin=initial_origin)
            if origin_restored and report_cb:
                report_cb("Origin mode 'None': the origin was moved back to its original position after the transform changes.")
        finally:
            # Restore modifiers even if a later operation fails.
            if keep_mode in {"KEEP_LINK", "KEEP_REBUILD", "KEEP_SAFE"} and temp_obj:
                keep_modifiers_linkcopy_restore(context, obj, temp_obj)
                if driver_snaps:
                    mo_mod.restore_modifier_drivers(obj, driver_snaps)
                if dummy_mesh:
                    try: bpy.data.meshes.remove(dummy_mesh)
                    except Exception: pass

        if verify_modifier_bounds:
            context.view_layer.update()
            modifier_bounds_after = _evaluated_world_bounds(context, obj)
            if not _bounds_match(modifier_bounds_before, modifier_bounds_after):
                raise RuntimeError(
                    "Applying transforms would change the evaluated modifier result; "
                    "this object was left unchanged."
                )

        return True, "OK"
    except Exception as e:
        if created_mirror_helper is not None:
            try:
                for modifier in getattr(obj, "modifiers", ()):
                    if (
                        modifier.type == 'MIRROR'
                        and getattr(modifier, "mirror_object", None) == created_mirror_helper
                    ):
                        modifier.mirror_object = None
                cleanup_unused_mirror_frame_helpers((created_mirror_helper,))
                helpers = settings.get("_created_mirror_helpers", [])
                if created_mirror_helper in helpers:
                    helpers.remove(created_mirror_helper)
            except Exception:
                pass
        return False, str(e)

def apply_preset(props):
    """Apply recommended settings based on preset, unless preset is CUSTOM."""
    if props.preset == 'CUSTOM':
        return

    # Defaults
    props.keep_mode = 'KEEP_LINK'
    props.apply_location = True
    props.apply_rotation = True
    props.apply_scale = True
    props.shade_smooth = True
    props.set_object_color = True

    props.remove_crease = True
    props.remove_bevel_weight = True
    props.clear_custom_normals = False
    props.recalc_normals = False
    props.convert_geometry_nodes_to_mesh = False
    props.merge_by_distance = False
    props.merge_distance = 0.0001
    props.delete_loose = False
    props.remove_empty_material_slots = False
    props.purge_orphans = False
    props.rename_data_to_object_name = False

    props.origin_mode = 'WORLD_ORIGIN'

    props.rename_enable = False
    props.rename_pattern = "{name}"
    props.rename_start_index = 1

    props.move_to_collection_enable = False
    props.target_collection = "MO_Organized"
    props.remove_empty_collections = False

    props.preflight_enable = False
    props.check_nonmanifold = False
    props.check_negative_scale = False
    props.auto_fix_negative_scale = False
    props.warn_shapekeys_armature = True

    props.backup_enable = False
    props.restore_on_cancel = False

    if props.preset == 'GAME_EXPORT':
        props.keep_mode = 'KEEP_LINK'
        props.apply_location = False
        props.apply_rotation = True
        props.apply_scale = True
        props.clear_custom_normals = False
        props.recalc_normals = True
        props.merge_by_distance = False
        props.delete_loose = True
        props.remove_empty_material_slots = True
        props.origin_mode = 'WORLD_ORIGIN'
        props.purge_orphans = True

    elif props.preset == 'RIG_PREP':
        props.keep_mode = 'KEEP_SAFE'
        props.apply_location = False
        props.apply_rotation = False
        props.apply_scale = True
        props.clear_custom_normals = False
        props.recalc_normals = False
        props.merge_by_distance = False
        props.delete_loose = False
        props.origin_mode = 'WORLD_ORIGIN'
        props.purge_orphans = False

    elif props.preset == 'MODEL_CLEANUP':
        props.keep_mode = 'KEEP_LINK'
        props.apply_location = True
        props.apply_rotation = True
        props.apply_scale = True
        props.merge_by_distance = True
        props.merge_distance = 0.0001
        props.delete_loose = True
        props.remove_empty_material_slots = True
        props.origin_mode = 'WORLD_ORIGIN'
