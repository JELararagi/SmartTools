import bpy
import webbrowser
import math

# 1. 冒頭のライセンス・権利表記
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  【ライセンス】
#  - 著作権: 本ソフトウェアの権利は「Smart Modeling」に帰属します。
#  - ライセンス: GNU General Public License v3.0 以降（GPL-3.0-or-later）で配布します。
# ------------------------------------------------------------------------------

bl_info = {
    "name": "Mesh Align",
    "author": "Smart Modeling",
    "version": (1, 2, 1),
    "blender": (5, 0, 0),
    "location": "View3D > F3 Search > Mesh Align",
    "description": "Preset collection for mesh alignment. Supports vertex sliding and multi-object editing. ID: 'mesh.mesh_align_master'",
    "category": "Mesh",
}

import bpy
import bmesh
from bpy_extras import view3d_utils
from mathutils import Vector, geometry, Matrix
from mathutils.kdtree import KDTree


def _msap_update_edit_mesh(mesh):
    # Moved vertices keep their old face normals until they are recalculated,
    # which leaves stale shading on the aligned faces.
    bmesh.from_edit_mesh(mesh).normal_update()
    bmesh.update_edit_mesh(mesh)

try:
    from .. import flow_algorithms as _sms_flow
except Exception:
    _sms_flow = None

try:
    from . import undo_bridge as _msap_undo_bridge
except Exception:
    _msap_undo_bridge = None


# =============================================================
# 0. 翻訳辞書
# =============================================================
translation_dict = {
    "ja_JP": {
        ("*", "Preset collection for mesh alignment. Supports vertex sliding and multi-object editing. ID: 'mesh.mesh_align_master'"): 'メッシュ整列のプリセット集。頂点スライドと複数オブジェクトの編集に対応します。',
        ("*", "Mesh Align"): "メッシュ整列",
        ("*", "[Alt]: Slide / [Ctrl]: All Objects"): "修飾キー: [Alt] スライド / [Ctrl] 全オブジェ対象",
        ("*", "Distribute Evenly"): "均等に配置",
        ("*", "Distribute vertices at equal intervals"): "始点と終点の間で均等な間隔になるように配置します",
        ("*", "Standard Align"): "標準整列",
        ("*", "View / Grid"): "ビュー / グリッド",
        ("*", "Loop Align"): "ループ整列",
        ("*", "Annotation Align"): "アノテーション整列",
        ("*", "Concentrated to Center"): "中心に集結",
        ("*", "Align to View"): 'ビューに揃える',
        ("*", "Align Horiz to View"): "視点と水平",
        ("*", "View X"): 'ビュー X',
        ("*", "View Y"): 'ビュー Y',
        ("*", "View Z"): 'ビュー Z',
        ("*", "Align to Grid"): "グリッドに揃える",
        ("*", "3D Line"): "3D直線",
        ("*", "2D Line (View)"): "2D直線（ビュー）",
        ("*", "Equal Edge Length"): "辺の長さを統一",
        ("*", "Average"): "平均",
        ("*", "Longest"): "最長合わせ",
        ("*", "Shortest"): "最短合わせ",
        ("*", "Use the average selected edge length"): "選択辺の平均長に統一します",
        ("*", "Use the longest selected edge length"): "選択辺の最長辺に統一します",
        ("*", "Use the shortest selected edge length"): "選択辺の最短辺に統一します",
        ("*", "Align to Annotate"): "アノテート線に揃える",
        ("*", "Clear Annotations"): "アノテート全削除",
        ("*", "Align X coordinates. [Alt]: Slide / [Ctrl]: All Objects"): "選択頂点のX座標を揃えます。[Ctrl]で全オブジェクト対象、[Alt]で頂点スライド限定。",
        ("*", "Align Y coordinates. [Alt]: Slide / [Ctrl]: All Objects"): "選択頂点のY座標を揃えます。[Ctrl]で全オブジェクト対象、[Alt]で頂点スライド限定。",
        ("*", "Align Z coordinates. [Alt]: Slide / [Ctrl]: All Objects"): "選択頂点のZ座標を揃えます。[Ctrl]で全オブジェクト対象、[Alt]で頂点スライド限定。",
        ("*", "Collapse vertices to center. [Ctrl]: All Objects"): "選択頂点を中心一点に集合させます。[Ctrl]で全オブジェクト対象。",
        ("*", "Flatten to view plane. [Alt]: Slide / [Ctrl]: All Objects"): "視点と平行な平面に揃えます。[Ctrl]で全オブジェクト対象、[Alt]で頂点スライド限定。",
        ("*", "Align horizontally in view. [Alt]: Slide / [Ctrl]: All Objects"): "視点から見て水平方向のラインに揃えます。[Ctrl]で全オブジェクト対象、[Alt]で頂点スライド限定。",
        ("*", "Align depth to grid view"): "視点から見て奥行き方向をグリッドに揃えます。",
        ("*", "Align to active annotation line. [Alt]: Slide"): "アクティブなアノテーション線（ストローク）に投影して揃えます。[Alt]で頂点スライド限定。",
        ("*", "Delete all annotations in the scene"): "シーン内のすべてのアノテート線を削除します。",
        ("*", "Align vertices in a perfect 3D line"): "3D空間で始点と終点を結ぶ直線に整列します。",
        ("*", "Align in view. [Alt]: Slide"): "ビュー上で直線になるように移動します。[Alt]で辺上をスライド限定。",
        ("*", "Flow Tools"): "フローツール",
        ("*", "Selected Symmetry Pairs"): "選択対称ペア整列",
        ("*", "Mirror-align selected vertex pairs"): '選択中の頂点の組をミラーで揃える',
        ("*", "Mirror Axis"): 'ミラーの軸',
        ("*", "Source Direction"): '元の向き',
        ("*", "Positive to Negative"): 'プラスからマイナスへ',
        ("*", "Negative to Positive"): 'マイナスからプラスへ',
        ("*", "Distance Threshold"): "距離しきい値",
        ("*", "Execute"): "実行",
        ("*", "Choose the object-local axis to reflect across."): '反転に使うオブジェクトのローカルの軸を選びます。',
        ("*", "Mirror across the object-local X axis."): 'オブジェクトのローカル X 軸で反転します。',
        ("*", "Mirror across the object-local Y axis."): 'オブジェクトのローカル Y 軸で反転します。',
        ("*", "Mirror across the object-local Z axis."): 'オブジェクトのローカル Z 軸で反転します。',
        ("*", "Choose the fixed source side and the destination side that will move."): '固定する元の側と動かす先の側を選びます。',
        ("*", "Keep the positive side fixed and mirror it to the negative side."): 'プラス側を固定し、マイナス側へ写します。',
        ("*", "Keep the negative side fixed and mirror it to the positive side."): 'マイナス側を固定し、プラス側へ写します。',
        ("*", "Maximum object-local distance between a mirrored source position and a compatible destination vertex."): '反転した元の位置と対応する先の頂点の間の最大の距離（ローカル）です。',
        ("*", "Mirror-align topology-compatible pairs seeded by selected vertices, edges, or faces in object-local coordinates."): '選択中の頂点、辺、面から広げたトポロジーの合う組を、ローカル座標でミラーして揃えます。',
        ("*", "Set Flow"): 'フロー設定',
                ("*", "Adjust edge flow to smooth curvature"): "選択した頂点・辺の流れを周囲の曲面に合わせて滑らかに整えます。",
                ("*", "Opens the Mesh Align popup. Use X/Y/Z to align selected vertices by coordinate, Center to collapse them to their center, Grid to project them onto the active view grid plane, View commands to align in the current viewport, Annotation commands to align to the active annotation stroke, and Flow Set to smooth selected edge flow. Hold Alt to slide where supported and Ctrl to process all editable objects where supported."):
            "メッシュ整列のポップアップを開きます。X/Y/Z は選択頂点の座標整列、中心は選択を中心へ集結、辺の長さを統一では複数の選択辺を平均・最長・最短の長さへ揃え、グリッドはアクティブビューのグリッド面へ投影、ビュー系は現在の視点基準の整列、アノテーション系はアクティブな注釈線への整列、フローセットは選択エッジの流れを滑らかに整えます。対応する機能では Alt で辺上スライド、Ctrl で全編集オブジェクト対象になります。",
        ("*", "Project selected vertices onto the active viewport grid plane, matching a 3ds Max-style grid align workflow."):
            '選択中の頂点をビューポートのグリッドの平面へ投影します（3ds Max 風のグリッド整列）。',
        ("*", "Smooth the selected edge flow by repositioning selected vertices along surrounding topology."):
            '周りのトポロジーに沿って選択中の頂点を動かし、辺の流れを滑らかにします。',
        ("*", "Flow Algorithm"): "フローアルゴリズム",
        ("*", "Current Flow"): "現在のフロー",
        ("*", "3ds Max Flow"): "3ds Maxフロー",
        ("*", "EdgeFlow"): "EdgeFlow",
        ("*", "Keeps the existing Smart Modeling flow algorithm. It smooths selected vertices by reading the surrounding topology and rebuilding the curve between stable unselected neighbours."):
            "既存のSmart Modelingフローアルゴリズムを使用します。周囲のトポロジーを読み取り、安定した未選択の隣接頂点の間に選択頂点を滑らかに再配置します。",
        ("*", "Uses a 3ds Max-style flow fit. It preserves the selected loop structure while using the outer neighbouring vertices as curve controls to rebuild the selected flow more strongly along the surrounding surface."):
            "3ds Max風のフローフィットを使用します。選択ループ構造を維持しながら、外側の隣接頂点を曲線制御点として使い、周囲の面の流れにより強く沿うように再配置します。",
        ("*", "Uses the bundled EdgeFlow 1.1.2-style local Hermite flow calculation. It is useful when the selected edge flow should follow neighbouring quad-loop curvature more aggressively."):
            '同梱EdgeFlow 1.1.2系のローカルエルミートフロー計算を使用します。選択エッジフローを隣接する四角形ループの曲率へより積極的に合わせたい場合に有効です。',
        ("*", "Choose which algorithm Flow Set uses when smoothing selected vertices or selected edge loops."):
            "フローセットで選択頂点または選択エッジループを滑らかに整える際に使用するアルゴリズムを選択します。",
    }
}


def _msap_is_japanese(context=None):
    try:
        prefs = getattr(getattr(context or bpy.context, "preferences", None), "view", None)
        lang = str(getattr(prefs, "language", "") or "")
        if lang.startswith("ja"):
            return True
    except Exception:
        pass
    try:
        return bool(bpy.app.translations.locale.startswith("ja"))
    except Exception:
        return False


def _msap_text(en, ja, context=None):
    return str(ja if _msap_is_japanese(context) else en)


def _msap_poll_edit_mesh(context):
    try:
        if context is None or getattr(context, "mode", "") != 'EDIT_MESH':
            return False
        obj = getattr(context, "active_object", None)
        return obj is not None and getattr(obj, "type", None) == 'MESH' and getattr(obj, "data", None) is not None
    except Exception:
        return False


_MESH_ALIGN_MASTER_DESCRIPTION_EN = (
    "Opens the Mesh Align popup. Use X/Y/Z to align selected vertices by coordinate, "
    "Center to collapse them to their center, Equal Edge Length to match selected edges to their average, longest, or shortest length, "
    "Grid to project them onto the active view grid plane, "
    "View commands to align in the current viewport, Annotation commands to align to the active annotation stroke, "
    "and Flow Set to smooth selected edge flow. Hold Alt to slide where supported and Ctrl to process all editable objects where supported."
)
_MESH_ALIGN_MASTER_DESCRIPTION_JA = (
    "メッシュ整列のポップアップを開きます。X/Y/Z は選択頂点の座標整列、中心は選択を中心へ集結、"
    "辺の長さを統一では複数の選択辺を平均・最長・最短の長さへ揃え、グリッドはアクティブビューのグリッド面へ投影、"
    "ビュー系は現在の視点基準の整列、アノテーション系はアクティブな注釈線への整列、"
    "フローセットは選択エッジの流れを滑らかに整えます。対応する機能では Alt で辺上スライド、Ctrl で全編集オブジェクト対象になります。"
)


_MSAP_FLOW_ALGORITHM_CURRENT = getattr(_sms_flow, 'FLOW_ALGORITHM_CURRENT', 'CURRENT') if _sms_flow is not None else 'CURRENT'
_MSAP_FLOW_ALGORITHM_MAX = getattr(_sms_flow, 'FLOW_ALGORITHM_MAX', 'MAX_3DS') if _sms_flow is not None else 'MAX_3DS'
_MSAP_FLOW_ALGORITHM_EDGEFLOW = getattr(_sms_flow, 'FLOW_ALGORITHM_EDGEFLOW', 'EDGEFLOW') if _sms_flow is not None else 'EDGEFLOW'

_MSAP_FLOW_ALGORITHM_NAME = "Flow Algorithm"
_MSAP_FLOW_ALGORITHM_DESCRIPTION = "Choose which algorithm Flow Set uses when smoothing selected vertices or selected edge loops."
_MSAP_FLOW_ALGORITHM_ITEMS = (
    (
        _MSAP_FLOW_ALGORITHM_CURRENT,
        "Current Flow",
        "Keeps the existing Smart Modeling flow algorithm. It smooths selected vertices by reading the surrounding topology and rebuilding the curve between stable unselected neighbours.",
    ),
    (
        _MSAP_FLOW_ALGORITHM_MAX,
        "3ds Max Flow",
        "Uses a 3ds Max-style flow fit. It preserves the selected loop structure while using the outer neighbouring vertices as curve controls to rebuild the selected flow more strongly along the surrounding surface.",
    ),
    (
        _MSAP_FLOW_ALGORITHM_EDGEFLOW,
        "EdgeFlow",
        "Uses the bundled EdgeFlow 1.1.2-style local Hermite flow calculation. It is useful when the selected edge flow should follow neighbouring quad-loop curvature more aggressively.",
    ),
)

_MSAP_EDGE_LENGTH_MODE_AVERAGE = 'AVERAGE'
_MSAP_EDGE_LENGTH_MODE_LONGEST = 'LONGEST'
_MSAP_EDGE_LENGTH_MODE_SHORTEST = 'SHORTEST'
_MSAP_EDGE_LENGTH_MODE_ITEMS = (
    (
        _MSAP_EDGE_LENGTH_MODE_AVERAGE,
        "Average",
        "Use the average selected edge length",
    ),
    (
        _MSAP_EDGE_LENGTH_MODE_LONGEST,
        "Longest",
        "Use the longest selected edge length",
    ),
    (
        _MSAP_EDGE_LENGTH_MODE_SHORTEST,
        "Shortest",
        "Use the shortest selected edge length",
    ),
)


def _msap_normalize_flow_algorithm(value):
    if _sms_flow is not None:
        try:
            return _sms_flow.normalize_flow_algorithm(value)
        except Exception:
            pass
    try:
        value = str(value or '').upper()
    except Exception:
        value = ''
    if value in {_MSAP_FLOW_ALGORITHM_MAX, 'MAX', '3DSMAX', '3DS_MAX'}:
        return _MSAP_FLOW_ALGORITHM_MAX
    if value in {_MSAP_FLOW_ALGORITHM_EDGEFLOW, 'EDGE_FLOW'}:
        return _MSAP_FLOW_ALGORITHM_EDGEFLOW
    return _MSAP_FLOW_ALGORITHM_CURRENT


def _msap_scene_props(context=None):
    try:
        return getattr((context or bpy.context).scene, 'align_slide_props')
    except Exception:
        return None


def _msap_scene_flow_algorithm(context=None, fallback=None):
    if fallback is not None:
        return _msap_normalize_flow_algorithm(fallback)
    props = _msap_scene_props(context)
    try:
        return _msap_normalize_flow_algorithm(getattr(props, 'flow_algorithm', _MSAP_FLOW_ALGORITHM_CURRENT))
    except Exception:
        return _MSAP_FLOW_ALGORITHM_CURRENT


def _msap_store_flow_algorithm(context=None, algorithm=None):
    props = _msap_scene_props(context)
    if props is None or algorithm is None:
        return
    try:
        props.flow_algorithm = _msap_normalize_flow_algorithm(algorithm)
    except Exception:
        pass


# =============================================================
# 1. プロパティ
# =============================================================
class AlignSlideSceneProps(bpy.types.PropertyGroup):
    use_even_distribution: bpy.props.BoolProperty(
        name="Distribute Evenly",
        description="Distribute vertices at equal intervals",
        default=False
    )
    flow_algorithm: bpy.props.EnumProperty(
        name=_MSAP_FLOW_ALGORITHM_NAME,
        description=_MSAP_FLOW_ALGORITHM_DESCRIPTION,
        items=_MSAP_FLOW_ALGORITHM_ITEMS,
        default=_MSAP_FLOW_ALGORITHM_CURRENT,
        options={'SKIP_SAVE'},
    )

# =============================================================
# 2. ヘルパー関数
# =============================================================
def get_ordered_selection(bm):
    selected_verts = [v for v in bm.verts if v.select]
    if len(selected_verts) < 3: return None, "Select at least 3 connected vertices."
    endpoints = []
    for v in selected_verts:
        if len([e for e in v.link_edges if e.other_vert(v).select]) == 1:
            endpoints.append(v)
    if len(endpoints) != 2: return None, "Selection must be a single continuous chain (open loop)."
    ordered = [endpoints[0]]; curr = endpoints[0]; rem = set(selected_verts); rem.remove(curr)
    while rem:
        next_v = next((e.other_vert(curr) for e in curr.link_edges if e.other_vert(curr) in rem), None)
        if next_v: ordered.append(next_v); rem.remove(next_v); curr = next_v
        else: break
    return ordered, None

def get_target_objects(context):
    return [o for o in context.objects_in_mode_unique_data if o.type == 'MESH']


_MSAP_SYMMETRY_AXIS_ITEMS = (
    ('X', "X", "Mirror across the object-local X axis."),
    ('Y', "Y", "Mirror across the object-local Y axis."),
    ('Z', "Z", "Mirror across the object-local Z axis."),
)
_MSAP_SYMMETRY_DIRECTION_ITEMS = (
    ('POSITIVE_TO_NEGATIVE', "Positive to Negative", "Keep the positive side fixed and mirror it to the negative side."),
    ('NEGATIVE_TO_POSITIVE', "Negative to Positive", "Keep the negative side fixed and mirror it to the positive side."),
)


def _msap_symmetry_seed_vertices(bm):
    """Return visible vertices seeded by vertex, edge, or face selection."""
    seeds = {vert for vert in bm.verts if vert.select and not vert.hide}
    for edge in bm.edges:
        if edge.select and not edge.hide:
            seeds.update(vert for vert in edge.verts if not vert.hide)
    for face in bm.faces:
        if face.select and not face.hide:
            seeds.update(vert for vert in face.verts if not vert.hide)
    return seeds


def _msap_symmetry_vertex_signature(vert):
    """Symmetric local topology signature independent of coordinates/order."""
    edge_face_counts = tuple(sorted(len(edge.link_faces) for edge in vert.link_edges))
    face_sizes = tuple(sorted(len(face.verts) for face in vert.link_faces))
    neighbour_signatures = []
    for edge in vert.link_edges:
        neighbour = edge.other_vert(vert)
        neighbour_signatures.append((
            len(neighbour.link_edges),
            sum(1 for linked in neighbour.link_edges if len(linked.link_faces) == 1),
            tuple(sorted(len(face.verts) for face in neighbour.link_faces)),
        ))
    return (
        len(vert.link_edges),
        edge_face_counts,
        face_sizes,
        tuple(sorted(neighbour_signatures)),
    )


def _msap_unique_distance_choice(options, ambiguity_epsilon):
    if not options:
        return None, False
    ordered = sorted(options, key=lambda item: (float(item[1]), int(item[0].index)))
    if len(ordered) > 1 and abs(float(ordered[1][1]) - float(ordered[0][1])) <= ambiguity_epsilon:
        return None, True
    return ordered[0], False


def _msap_choose_symmetry_pairs(bm, axis_index, source_sign, threshold):
    """Choose deterministic one-to-one mirror pairs without mutating BMesh."""
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    seeds = _msap_symmetry_seed_vertices(bm)
    threshold = max(0.0, float(threshold))
    plane_epsilon = max(1.0e-12, threshold * 1.0e-9)
    ambiguity_epsilon = max(1.0e-12, threshold * 1.0e-9)
    distance_epsilon = max(1.0e-12, threshold * 1.0e-12)
    visible = [vert for vert in bm.verts if vert.is_valid and not vert.hide]
    sources = sorted(
        (vert for vert in visible if float(vert.co[axis_index]) * source_sign > plane_epsilon),
        key=lambda vert: int(vert.index),
    )
    destinations = sorted(
        (vert for vert in visible if float(vert.co[axis_index]) * source_sign < -plane_epsilon),
        key=lambda vert: int(vert.index),
    )
    if not seeds or not sources or not destinations:
        return [], {'seed_count': len(seeds), 'ambiguous': 0, 'unmatched': len(seeds)}

    destination_tree = KDTree(len(destinations))
    for offset, destination in enumerate(destinations):
        destination_tree.insert(destination.co, offset)
    destination_tree.balance()
    destination_signatures = {vert: _msap_symmetry_vertex_signature(vert) for vert in destinations}
    source_options = {}
    reverse_options = {vert: [] for vert in destinations}
    for source in sources:
        mirrored = source.co.copy()
        mirrored[axis_index] = -mirrored[axis_index]
        signature = _msap_symmetry_vertex_signature(source)
        options = []
        for _coordinate, offset, distance in destination_tree.find_range(mirrored, threshold + distance_epsilon):
            destination = destinations[int(offset)]
            if destination_signatures[destination] != signature:
                continue
            option = (destination, float(distance), mirrored.copy())
            options.append(option)
            reverse_options[destination].append((source, float(distance), mirrored.copy()))
        source_options[source] = options

    # Resolve all visible counterparts before selection eligibility. Iterative
    # reciprocal matching reserves exact pairs before displaced alternatives.
    remaining_sources = set(sources)
    remaining_destinations = set(destinations)
    global_pairs = []
    ambiguous_vertices = set()
    while remaining_sources and remaining_destinations:
        selected_source = {}
        for source in sorted(remaining_sources, key=lambda vert: int(vert.index)):
            options = [option for option in source_options[source] if option[0] in remaining_destinations]
            choice, is_ambiguous = _msap_unique_distance_choice(options, ambiguity_epsilon)
            if is_ambiguous:
                ambiguous_vertices.add(('SOURCE', int(source.index)))
            if choice is not None:
                selected_source[source] = choice

        selected_destination = {}
        for destination in sorted(remaining_destinations, key=lambda vert: int(vert.index)):
            options = [option for option in reverse_options[destination] if option[0] in remaining_sources]
            choice, is_ambiguous = _msap_unique_distance_choice(options, ambiguity_epsilon)
            if is_ambiguous:
                ambiguous_vertices.add(('DESTINATION', int(destination.index)))
            if choice is not None:
                selected_destination[destination] = choice

        round_pairs = []
        for source in sorted(remaining_sources, key=lambda vert: int(vert.index)):
            source_choice = selected_source.get(source)
            if source_choice is None:
                continue
            destination, distance, mirrored = source_choice
            destination_choice = selected_destination.get(destination)
            if destination_choice is not None and destination_choice[0] is source:
                round_pairs.append((source, destination, mirrored, distance))
        if not round_pairs:
            break
        global_pairs.extend(round_pairs)
        remaining_sources.difference_update(pair[0] for pair in round_pairs)
        remaining_destinations.difference_update(pair[1] for pair in round_pairs)

    pairs = []
    covered_seeds = set()
    for source, destination, mirrored, distance in global_pairs:
        if source not in seeds and destination not in seeds:
            continue
        pairs.append((source, destination, mirrored, distance))
        if source in seeds:
            covered_seeds.add(source)
        if destination in seeds:
            covered_seeds.add(destination)
    return pairs, {
        'seed_count': len(seeds),
        'ambiguous': len(ambiguous_vertices),
        'unmatched': max(0, len(seeds) - len(covered_seeds)),
    }


def run_selected_symmetry_alignment(context, axis, direction, threshold):
    axis_index = {'X': 0, 'Y': 1, 'Z': 2}[str(axis)]
    source_sign = 1.0 if direction == 'POSITIVE_TO_NEGATIVE' else -1.0
    mesh_records = []
    planned = []
    totals = {'pairs': 0, 'moved': 0, 'seed_count': 0, 'ambiguous': 0, 'unmatched': 0, 'objects': 0}
    seen_data = set()
    for obj in get_target_objects(context):
        data = getattr(obj, 'data', None)
        if data is None:
            continue
        try:
            data_key = int(data.as_pointer())
        except Exception:
            data_key = id(data)
        if data_key in seen_data:
            continue
        seen_data.add(data_key)
        bm = bmesh.from_edit_mesh(data)
        pairs, stats = _msap_choose_symmetry_pairs(bm, axis_index, source_sign, threshold)
        totals['seed_count'] += stats['seed_count']
        totals['ambiguous'] += stats['ambiguous']
        totals['unmatched'] += stats['unmatched']
        if pairs:
            totals['objects'] += 1
            mesh_records.append((data, bm))
        for source, destination, mirrored, distance in pairs:
            planned.append((data, source, destination, destination.co.copy(), mirrored.copy(), distance))
    totals['pairs'] = len(planned)
    try:
        for _data, _source, destination, _original, mirrored, _distance in planned:
            if (destination.co - mirrored).length > 1.0e-12:
                destination.co = mirrored
                totals['moved'] += 1
        for data, _bm in mesh_records:
            _msap_update_edit_mesh(data)
    except Exception:
        for _data, _source, destination, original, _mirrored, _distance in planned:
            destination.co = original
        for data, _bm in mesh_records:
            _msap_update_edit_mesh(data)
        raise
    return totals

# =============================================================
# 3. ロジック
# =============================================================
def run_absolute_align(context, axes, use_global):
    objects = get_target_objects(context)
    if not objects: return

    if use_global:
        min_global = Vector((float('inf'), float('inf'), float('inf')))
        max_global = Vector((float('-inf'), float('-inf'), float('-inf')))
        has_verts = False
        for obj in objects:
            bm = bmesh.from_edit_mesh(obj.data)
            mw = obj.matrix_world
            for v in bm.verts:
                if v.select:
                    wco = mw @ v.co
                    for i in range(3):
                        min_global[i] = min(min_global[i], wco[i])
                        max_global[i] = max(max_global[i], wco[i])
                    has_verts = True
        if not has_verts: return
        global_target = (min_global + max_global) / 2.0

    for obj in objects:
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [v for v in bm.verts if v.select]
        if not sel: continue

        if not use_global:
            min_local = Vector((float('inf'), float('inf'), float('inf')))
            max_local = Vector((float('-inf'), float('-inf'), float('-inf')))
            for v in sel:
                for i in range(3):
                    min_local[i] = min(min_local[i], v.co[i])
                    max_local[i] = max(max_local[i], v.co[i])
            local_target = (min_local + max_local) / 2.0
        
        mw_inv = obj.matrix_world.inverted()
        for v in sel:
            final_target = mw_inv @ global_target if use_global else local_target
            if axes[0]: v.co.x = final_target.x
            if axes[1]: v.co.y = final_target.y
            if axes[2]: v.co.z = final_target.z
            
        _msap_update_edit_mesh(obj.data)


def run_slide_logic(context, axis_idx, use_global):
    objects = get_target_objects(context)
    if not objects: return

    if use_global:
        min_val = float('inf')
        max_val = float('-inf')
        has_verts = False
        for obj in objects:
            bm = bmesh.from_edit_mesh(obj.data)
            for v in bm.verts:
                if v.select:
                    val = v.co[axis_idx]
                    min_val = min(min_val, val)
                    max_val = max(max_val, val)
                    has_verts = True
        if not has_verts: return
        global_target_val = (min_val + max_val) / 2.0

    for obj in objects:
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [v for v in bm.verts if v.select]
        if not sel: continue

        if not use_global:
            min_val = min(v.co[axis_idx] for v in sel)
            max_val = max(v.co[axis_idx] for v in sel)
            target_val = (min_val + max_val) / 2.0
        else:
            target_val = global_target_val

        for v in sel:
            best_p, min_d, found = v.co.copy(), float('inf'), False
            for e in v.link_edges:
                ov = e.other_vert(v); vec = (ov.co - v.co).normalized()
                if abs(vec[axis_idx]) < 1e-6: continue
                p = v.co + vec * ((target_val - v.co[axis_idx]) / vec[axis_idx])
                d = (p - v.co).length
                if d < min_d: min_d, best_p, found = d, p, True
            
            v.co = best_p if found else v.co
            if not found: v.co[axis_idx] = target_val
            
        _msap_update_edit_mesh(obj.data)


def run_grid_logic(context):
    """Project selected edit vertices onto the active view grid plane.

    This matches the expected 3ds Max-style Grid Align behavior more closely
    than averaging the selection depth: the current viewport defines the grid
    plane, and selected vertices are moved onto that plane as seen from the
    active view. Standard orthographic views snap to the exact world XY/XZ/YZ
    grid plane through the origin.
    """
    objects = get_target_objects(context)
    rv3d = getattr(context, "region_data", None)
    if not objects or rv3d is None:
        return

    try:
        view_matrix = rv3d.view_matrix
        normal = Vector((view_matrix[2][0], view_matrix[2][1], view_matrix[2][2]))
        if normal.length_squared < 1e-12:
            return
        normal.normalize()
    except Exception:
        return

    # For standard Top/Front/Side-like orthographic views, use the dominant
    # world axis exactly so the result lands on Blender's visible construction
    # grid plane instead of on a numerically tilted plane.
    try:
        dominant_axis = max(range(3), key=lambda index: abs(normal[index]))
        if abs(normal[dominant_axis]) >= 0.85:
            sign = 1.0 if normal[dominant_axis] >= 0.0 else -1.0
            axis_normal = Vector((0.0, 0.0, 0.0))
            axis_normal[dominant_axis] = sign
            normal = axis_normal
    except Exception:
        pass

    plane_point = Vector((0.0, 0.0, 0.0))

    for obj in objects:
        bm = bmesh.from_edit_mesh(obj.data)
        mw = obj.matrix_world
        mwi = mw.inverted()
        sel = [v for v in bm.verts if v.select and not v.hide]
        if not sel:
            continue

        for v in sel:
            wco = mw @ v.co
            distance = (wco - plane_point).dot(normal)
            projected = wco - normal * distance
            v.co = mwi @ projected

        _msap_update_edit_mesh(obj.data)


def run_view_align(context, axis_idx, use_global, slide=False):
    objects = get_target_objects(context)
    if not objects or not context.region_data: return

    view_mat = context.region_data.view_matrix
    view_mat_inv = view_mat.inverted()

    if use_global:
        min_val = float('inf')
        max_val = float('-inf')
        has_verts = False
        for obj in objects:
            bm = bmesh.from_edit_mesh(obj.data)
            mw = obj.matrix_world
            for v in [v for v in bm.verts if v.select]:
                view_co = view_mat @ (mw @ v.co)
                min_val = min(min_val, view_co[axis_idx])
                max_val = max(max_val, view_co[axis_idx])
                has_verts = True
        if not has_verts: return
        global_target_val = (min_val + max_val) / 2.0

    for obj in objects:
        bm = bmesh.from_edit_mesh(obj.data)
        sel = [v for v in bm.verts if v.select]
        if not sel: continue
        
        mw = obj.matrix_world
        mwi = mw.inverted()

        if not use_global:
            min_val = min((view_mat @ (mw @ v.co))[axis_idx] for v in sel)
            max_val = max((view_mat @ (mw @ v.co))[axis_idx] for v in sel)
            local_target_val = (min_val + max_val) / 2.0
        else:
            local_target_val = global_target_val

        for v in sel:
            wco = mw @ v.co
            v_view = view_mat @ wco
            
            if slide:
                best_p, min_d, found = wco.copy(), float('inf'), False
                for e in v.link_edges:
                    ov = e.other_vert(v)
                    ov_wco = mw @ ov.co
                    ov_view = view_mat @ ov_wco
                    vec_view = ov_view - v_view
                    if abs(vec_view[axis_idx]) < 1e-6: continue
                    
                    t = (local_target_val - v_view[axis_idx]) / vec_view[axis_idx]
                    p_view = v_view + vec_view * t
                    p_world = view_mat_inv @ p_view
                    d = (p_world - wco).length
                    if d < min_d:
                        min_d, best_p, found = d, p_world, True
                
                v.co = mwi @ best_p if found else v.co
                if not found:
                    v_view[axis_idx] = local_target_val
                    v.co = mwi @ (view_mat_inv @ v_view)
            else:
                v_view[axis_idx] = local_target_val
                v.co = mwi @ (view_mat_inv @ v_view)

        _msap_update_edit_mesh(obj.data)


def get_annotation_points(context):
    ann = getattr(context, "annotation_data", None)
    if ann is None:
        scn = getattr(context, "scene", None)
        ann = getattr(scn, "annotation", None) if scn else None
    if ann is None:
        scn = getattr(context, "scene", None)
        ann = getattr(scn, "grease_pencil", None) if scn else None
    if ann is None:
        sp = getattr(context, "space_data", None)
        ann = getattr(sp, "annotation", None) if sp else None
    if ann is None:
        sp = getattr(context, "space_data", None)
        ann = getattr(sp, "grease_pencil", None) if sp else None
    if not ann:
        return []

    layers = getattr(ann, "layers", None)
    if not layers:
        return []

    layer = getattr(layers, "active", None)
    if layer is None:
        try:
            layer = layers[-1]
        except Exception:
            layer = next(iter(layers), None)
    if layer is None:
        return []

    frame = getattr(layer, "active_frame", None)
    if frame is None:
        frames = getattr(layer, "frames", None)
        if frames:
            frame = getattr(frames, "active", None)
            if frame is None:
                try:
                    frame = frames[-1]
                except Exception:
                    frame = next(iter(frames), None)
            if frame is None and hasattr(frames, "get"):
                try:
                    frame = frames.get(getattr(context.scene, "frame_current", 1))
                except Exception:
                    frame = None
    if frame is None:
        return []

    strokes = getattr(frame, "strokes", None)
    if not strokes:
        return []

    stroke = getattr(strokes, "active", None)
    if stroke is None:
        try:
            stroke = strokes[-1]
        except Exception:
            stroke = next(iter(strokes), None)
    if stroke is None:
        return []

    points = getattr(stroke, "points", None)
    if not points:
        return []

    pts = []
    for p in points:
        co = getattr(p, "co", None)
        if co is None:
            continue
        try:
            pts.append(Vector(co))
        except Exception:
            try:
                pts.append(co.copy())
            except Exception:
                pass
    return pts

def run_annotate_align(context, slide=False):
    try:
        region = context.region
        rv3d = context.region_data
        if not region or not rv3d:
            return False, "This must be run from the 3D Viewport."
            
        points_3d = get_annotation_points(context)
        if not points_3d: 
            return False, "No active annotation line found."

        # Orthographic views can drift when projecting back/forth via region 2D helpers.
        # Use view-space XY directly for ORTHO (and ORTHO camera) to keep pixel-perfect alignment.
        is_ortho = False
        try:
            vp = getattr(rv3d, "view_perspective", None)
            if vp == 'ORTHO':
                is_ortho = True
            elif vp == 'CAMERA':
                cam = getattr(getattr(context, "scene", None), "camera", None)
                if cam and getattr(cam, "type", None) == 'CAMERA':
                    is_ortho = (getattr(getattr(cam, "data", None), "type", None) == 'ORTHO')
            else:
                is_ortho = (getattr(rv3d, "is_perspective", True) is False)
        except Exception:
            is_ortho = False

        if is_ortho:
            view_mat = rv3d.view_matrix
            view_mat_inv = view_mat.inverted()

            points_v2 = []
            for p in points_3d:
                pv = view_mat @ p
                points_v2.append(Vector((pv.x, pv.y)))

            if len(points_v2) < 2:
                return False, "Annotation line is out of view."

            objects = get_target_objects(context)
            for obj in objects:
                bm = bmesh.from_edit_mesh(obj.data)
                mw = obj.matrix_world
                mwi = mw.inverted()
                sel = [v for v in bm.verts if v.select]
                if not sel:
                    continue

                for v in sel:
                    wco = mw @ v.co
                    v_view = view_mat @ wco
                    v_xy = Vector((v_view.x, v_view.y))

                    if slide:
                        best_p, min_d, found = v.co.copy(), float('inf'), False
                        for e in v.link_edges:
                            ov = e.other_vert(v)
                            ov_wco = mw @ ov.co
                            ov_view = view_mat @ ov_wco
                            ov_xy = Vector((ov_view.x, ov_view.y))
                            edge_dir = ov_xy - v_xy
                            if edge_dir.length_squared < 1e-12:
                                continue

                            for i in range(len(points_v2) - 1):
                                pA = points_v2[i]
                                pB = points_v2[i + 1]
                                line_dir = pB - pA
                                if line_dir.length_squared < 1e-12:
                                    continue

                                det = edge_dir.x * line_dir.y - edge_dir.y * line_dir.x
                                if abs(det) <= 1e-10:
                                    continue

                                diff = pA - v_xy
                                t_edge = (diff.x * line_dir.y - diff.y * line_dir.x) / det
                                t_line = (diff.x * edge_dir.y - diff.y * edge_dir.x) / det

                                if -1e-4 <= t_edge <= 1.0 + 1e-4 and -1e-4 <= t_line <= 1.0 + 1e-4:
                                    int_wco = wco + (ov_wco - wco) * t_edge
                                    d = (mwi @ int_wco - v.co).length
                                    if d < min_d:
                                        min_d, best_p, found = d, mwi @ int_wco, True

                        if found:
                            v.co = best_p
                    else:
                        best_closest = None
                        min_sq_dist = float('inf')

                        for i in range(len(points_v2) - 1):
                            pA = points_v2[i]
                            pB = points_v2[i + 1]
                            line_dir = pB - pA
                            line_len_sq = line_dir.length_squared
                            if line_len_sq < 1e-12:
                                continue

                            vec_to_pt = v_xy - pA
                            t = vec_to_pt.dot(line_dir) / line_len_sq
                            t = max(0.0, min(1.0, t))
                            closest = pA + line_dir * t
                            sq_dist = (v_xy - closest).length_squared

                            if sq_dist < min_sq_dist:
                                min_sq_dist = sq_dist
                                best_closest = closest

                        if best_closest is not None:
                            new_view = Vector((best_closest.x, best_closest.y, v_view.z))
                            new_wco = view_mat_inv @ new_view
                            v.co = mwi @ new_wco

                _msap_update_edit_mesh(obj.data)

            return True, ""
        
        points_2d = []
        for p in points_3d:
            p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p)
            if p2d is not None:
                points_2d.append(p2d)
                
        if len(points_2d) < 2:
            return False, "Annotation line is out of view."
            
        objects = get_target_objects(context)
        for obj in objects:
            bm = bmesh.from_edit_mesh(obj.data)
            mw = obj.matrix_world
            mwi = mw.inverted()
            sel = [v for v in bm.verts if v.select]
            if not sel: continue
            
            for v in sel:
                wco = mw @ v.co
                v_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, wco)
                if v_2d is None: continue
                
                if slide:
                    best_p, min_d, found = v.co.copy(), float('inf'), False
                    for e in v.link_edges:
                        ov_wco = mw @ e.other_vert(v).co
                        ov_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, ov_wco)
                        if ov_2d is None: continue
                        
                        edge_dir_2d = ov_2d - v_2d
                        
                        for i in range(len(points_2d) - 1):
                            pA_2d = points_2d[i]
                            pB_2d = points_2d[i+1]
                            line_dir_2d = pB_2d - pA_2d
                            
                            det = edge_dir_2d.x * line_dir_2d.y - edge_dir_2d.y * line_dir_2d.x
                            
                            if abs(det) > 1e-6:
                                diff = pA_2d - v_2d
                                t_edge = (diff.x * line_dir_2d.y - diff.y * line_dir_2d.x) / det
                                t_line = (diff.x * edge_dir_2d.y - diff.y * edge_dir_2d.x) / det
                                
                                if -1e-4 <= t_edge <= 1.0 + 1e-4 and -1e-4 <= t_line <= 1.0 + 1e-4:
                                    int_2d = v_2d + edge_dir_2d * t_edge
                                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, int_2d)
                                    ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, int_2d)
                                    
                                    res = geometry.intersect_line_line(wco, ov_wco, ray_origin, ray_origin + ray_dir)
                                    if res:
                                        int_wco = res[0]
                                    else:
                                        int_wco = wco + (ov_wco - wco) * t_edge
                                        
                                    d = (mwi @ int_wco - v.co).length
                                    if d < min_d:
                                        min_d, best_p, found = d, mwi @ int_wco, True
                    if found: v.co = best_p
                else:
                    best_closest_2d = None
                    min_sq_dist = float('inf')
                    
                    for i in range(len(points_2d) - 1):
                        pA_2d = points_2d[i]
                        pB_2d = points_2d[i+1]
                        line_dir_2d = pB_2d - pA_2d
                        line_len_sq = line_dir_2d.length_squared
                        
                        if line_len_sq < 1e-6: continue
                        
                        vec_to_pt = v_2d - pA_2d
                        t = vec_to_pt.dot(line_dir_2d) / line_len_sq
                        t = max(0.0, min(1.0, t))
                        
                        closest_2d = pA_2d + line_dir_2d * t
                        sq_dist = (v_2d - closest_2d).length_squared
                        
                        if sq_dist < min_sq_dist:
                            min_sq_dist = sq_dist
                            best_closest_2d = closest_2d
                            
                    if best_closest_2d:
                        new_wco = view3d_utils.region_2d_to_location_3d(region, rv3d, best_closest_2d, wco)
                        if new_wco:
                            v.co = mwi @ new_wco
                        
            _msap_update_edit_mesh(obj.data)
        return True, ""
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return False, f"Annotation Error: {str(e)}"

def get_straight_path(start_v, first_e, max_steps=30):
    path = [start_v]
    curr_v = start_v
    curr_e = first_e
    for _ in range(max_steps):
        next_v = curr_e.other_vert(curr_v)
        if next_v in path: break
        path.append(next_v)
        in_faces = set(curr_e.link_faces)
        candidates = []
        for e in next_v.link_edges:
            if e == curr_e: continue
            if not in_faces.intersection(set(e.link_faces)):
                candidates.append(e)
        if len(candidates) == 1:
            curr_v = next_v
            curr_e = candidates[0]
        else:
            break
    return path

def run_set_flow(context, iterations=1, algorithm=None):
    algorithm = _msap_scene_flow_algorithm(context, algorithm)
    objects = get_target_objects(context)
    if not objects:
        return False

    changed_any = False
    for obj in objects:
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            pass

        if _sms_flow is not None:
            sel_verts = _sms_flow.selected_flow_vertices(bm)
            if not sel_verts:
                continue
            try:
                moved = _sms_flow.apply_flow_algorithm_to_vertices(
                    bm,
                    sel_verts,
                    algorithm=algorithm,
                    iterations=8 if algorithm == _MSAP_FLOW_ALGORITHM_EDGEFLOW else int(iterations or 1),
                    preserve_current_factors=False,
                )
            except Exception:
                moved = 0
            if moved:
                try:
                    bm.normal_update()
                except Exception:
                    pass
                _msap_update_edit_mesh(obj.data)
                changed_any = True
            continue

        # Fallback: original Smart Modeling flow algorithm.
        for _ in range(iterations):
            sel_verts = [v for v in bm.verts if v.select]
            if not sel_verts:
                break
            new_positions = {}
            for v in sel_verts:
                edges = list(v.link_edges)
                if len(edges) < 2:
                    continue
                min_sel_depth = float('inf')
                best_full_path = None
                for i in range(len(edges)):
                    for j in range(i+1, len(edges)):
                        e1, e2 = edges[i], edges[j]
                        if set(e1.link_faces).intersection(set(e2.link_faces)):
                            continue
                        p1 = get_straight_path(v, e1, 30)
                        p2 = get_straight_path(v, e2, 30)
                        d1 = sum(1 for pt in p1[1:] if pt.select)
                        d2 = sum(1 for pt in p2[1:] if pt.select)
                        if (d1 + d2) < min_sel_depth:
                            min_sel_depth = d1 + d2
                            best_full_path = p1[::-1][:-1] + p2
                if not best_full_path:
                    for e in edges:
                        p = get_straight_path(v, e, 30)
                        d = sum(1 for pt in p[1:] if pt.select)
                        if d < min_sel_depth:
                            min_sel_depth = d
                            best_full_path = p
                if not best_full_path:
                    continue
                idx_v = best_full_path.index(v)
                idx_L, idx_R = -1, -1
                for i in range(idx_v - 1, -1, -1):
                    if not best_full_path[i].select:
                        idx_L = i
                        break
                for i in range(idx_v + 1, len(best_full_path)):
                    if not best_full_path[i].select:
                        idx_R = i
                        break
                if idx_L == -1:
                    idx_L = 0
                if idx_R == -1:
                    idx_R = len(best_full_path) - 1
                if idx_L == idx_v or idx_R == idx_v:
                    continue
                num_segments = float(idx_R - idx_L)
                t = float(idx_v - idx_L) / num_segments
                U_L1, U_R1 = best_full_path[idx_L].co, best_full_path[idx_R].co
                U_L2 = best_full_path[idx_L-1].co if idx_L >= 1 else U_L1 + (U_L1 - best_full_path[idx_L+1].co)
                U_R2 = best_full_path[idx_R+1].co if idx_R+1 < len(best_full_path) else U_R1 + (U_R1 - best_full_path[idx_R-1].co)
                n = num_segments
                p0, p1, p2, p3 = U_L2, U_L1, U_R1, U_R2
                v12 = p2 - p1
                avg_seg_len = v12.length / n if n > 0 else v12.length
                adj_v01 = (p1 - p0).normalized() * avg_seg_len if (p1-p0).length > 1e-6 else v12.normalized() * avg_seg_len
                adj_v23 = (p3 - p2).normalized() * avg_seg_len if (p3-p2).length > 1e-6 else v12.normalized() * avg_seg_len
                T1 = (n**2 / (n+1)) * adj_v01 + (1.0 / (n+1)) * v12
                T2 = (1.0 / (n+1)) * v12 + (n**2 / (n+1)) * adj_v23
                chord_len = v12.length
                if T1.length > chord_len * 1.5:
                    T1 = T1.normalized() * chord_len * 1.5
                if T2.length > chord_len * 1.5:
                    T2 = T2.normalized() * chord_len * 1.5
                t2, t3 = t*t, t*t*t
                h1, h2, h3, h4 = 2*t3 - 3*t2 + 1, -2*t3 + 3*t2, t3 - 2*t2 + t, t3 - t2
                new_positions[v] = h1 * p1 + h2 * p2 + h3 * T1 + h4 * T2
            if new_positions:
                for v, co in new_positions.items():
                    v.co = co
                changed_any = True
        _msap_update_edit_mesh(obj.data)
    return changed_any

# =============================================================
# 4. オペレーター定義
# =============================================================

_MSAP_OPERATOR_DESCRIPTIONS = {
    "mesh.align_x": (
        "Align selected vertices to the average X coordinate. Hold Alt while clicking to slide vertices along their connected edges until they reach the target X value. Hold Ctrl to calculate the target across all editable objects.",
        "選択頂点を平均X座標へ整列します。クリック時にAltを押すと接続エッジ上をスライドして目標X値へ揃えます。Ctrlを押すと全編集オブジェクトをまとめて目標値を計算します。",
    ),
    "mesh.align_y": (
        "Align selected vertices to the average Y coordinate. Hold Alt while clicking to slide vertices along their connected edges until they reach the target Y value. Hold Ctrl to calculate the target across all editable objects.",
        "選択頂点を平均Y座標へ整列します。クリック時にAltを押すと接続エッジ上をスライドして目標Y値へ揃えます。Ctrlを押すと全編集オブジェクトをまとめて目標値を計算します。",
    ),
    "mesh.align_z": (
        "Align selected vertices to the average Z coordinate. Hold Alt while clicking to slide vertices along their connected edges until they reach the target Z value. Hold Ctrl to calculate the target across all editable objects.",
        "選択頂点を平均Z座標へ整列します。クリック時にAltを押すと接続エッジ上をスライドして目標Z値へ揃えます。Ctrlを押すと全編集オブジェクトをまとめて目標値を計算します。",
    ),
    "mesh.align_collapse": (
        "Move selected vertices to their common center point. Hold Ctrl to calculate one shared center across all editable objects.",
        "選択頂点を共通の中心点へ集結します。Ctrlを押すと全編集オブジェクトをまとめて1つの中心点を計算します。",
    ),
    "mesh.align_view": (
        "Align selected vertices to the same view-space Z depth. Hold Alt to keep each vertex constrained to its connected edge while aligning. Hold Ctrl to use all editable objects as one target set.",
        "選択頂点を視点から見た同じZ奥行きへ整列します。Altを押すと各頂点を接続エッジ上に拘束して整列します。Ctrlを押すと全編集オブジェクトを1つの対象として扱います。",
    ),
    "mesh.align_view_h": (
        "Align selected vertices to the same view-space Y coordinate, forming a horizontal line. Hold Alt to slide along connected edges while aligning. Hold Ctrl to calculate the target across all editable objects.",
        "選択頂点を視点から見た同じY座標へ揃え、水平線上に整列します。Altを押すと接続エッジ上をスライドして整列します。Ctrlを押すと全編集オブジェクトをまとめて目標値を計算します。",
    ),
    "mesh.align_view_x": (
        "Align selected vertices to the same view-space X coordinate, forming a vertical line. Hold Alt to slide along connected edges while aligning. Hold Ctrl to calculate the target across all editable objects.",
        "選択頂点を視点から見た同じX座標へ揃え、垂直線上に整列します。Altを押すと接続エッジ上をスライドして整列します。Ctrlを押すと全編集オブジェクトをまとめて目標値を計算します。",
    ),
    "mesh.align_grid": (
        "Project selected vertices onto the grid plane seen from the active viewport. Top, Front, and Side views use the exact world grid plane, matching a 3ds Max-style grid align workflow.",
        "アクティブビューから見たグリッド平面へ選択頂点を投影します。トップ、フロント、サイド系ビューでは正確なワールドグリッド面を使い、3ds Maxのグリッド整列に近い挙動で揃えます。",
    ),
    "mesh.align_annotate": (
        "Align selected vertices to the active annotation stroke in the viewport. Hold Alt to slide vertices along connected edges until they meet the annotation line.",
        "選択頂点をビューポート上のアクティブなアノテーション線へ整列します。Altを押すと接続エッジ上をスライドしてアノテーション線へ合わせます。",
    ),
    "mesh.clear_annotation": (
        "Delete all annotation strokes in the current scene. Use this after annotation-based alignment when the guide strokes are no longer needed.",
        "現在のシーン内のアノテーション線をすべて削除します。アノテーション整列後、ガイド線が不要になったときに使用します。",
    ),
    "mesh.align_linear_3d": (
        "Align the selected open vertex chain into a straight 3D line between its endpoints. Use this for loop cleanup when you need a perfectly straight spatial line.",
        "選択した開いた頂点チェーンを、両端点を結ぶ3D直線上へ整列します。ループ整理で空間的に完全な直線へ揃えたい場合に使用します。",
    ),
    "mesh.align_move_view": (
        "Align the selected chain as a straight 2D line in the current view. This preserves the current viewport reading and is useful for screen-space cleanup.",
        "選択チェーンを現在の視点上で2D直線として整列します。現在のビューポート上の見え方を基準に、画面上での整理に使います。",
    ),
    "mesh.smart_modeling_equalize_edge_length": (
        "Make every selected edge the same world-space length. Choose the selected-edge average, longest edge, or shortest edge as the target. Disconnected edges and connected edge networks are supported.",
        "選択中の全ての辺を同じワールド長へ統一します。選択辺の平均・最長・最短から目標長を選べます。非連結辺と連結した辺ネットワークの両方に対応します。",
    ),
    "mesh.set_flow": (
        "Smooth the selected edge or vertex flow without adding new edges. The popup lets you choose the current Smart Modeling algorithm, a 3ds Max-style surface fit, or the bundled EdgeFlow 1.1.2-style Hermite flow algorithm.",
        "新しい辺を追加せず、選択頂点または選択エッジの流れを滑らかに整えます。ポップアップで現在のSmart Modelingアルゴリズム、3ds Max風のサーフェスフィット、同梱EdgeFlow 1.1.2系のHermiteフローアルゴリズムを切り替えられます。",
    ),
}


def _msap_operator_description(idname, context=None):
    en, ja = _MSAP_OPERATOR_DESCRIPTIONS.get(str(idname or ''), (str(idname or ''), str(idname or '')))
    return _msap_text(en, ja, context)

def _msap_edit_mesh_signature(context):
    """Return a compact edit-mesh signature for one-click undo decisions.

    The Mesh Align buttons are intended to behave as one user action.  Blender
    only creates a usable undo step when the data-changing operator returns
    FINISHED with UNDO enabled, so the operators compare pre/post mesh state and
    return FINISHED only when a real coordinate/topology change occurred.
    """
    signature = []
    try:
        objects = get_target_objects(context)
    except Exception:
        objects = []
    for obj in objects:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            coords = tuple((round(float(v.co.x), 9), round(float(v.co.y), 9), round(float(v.co.z), 9)) for v in bm.verts if v.is_valid)
            selection = tuple(bool(v.select) for v in bm.verts if v.is_valid)
            signature.append((int(obj.as_pointer()), len(bm.verts), len(bm.edges), len(bm.faces), coords, selection))
        except Exception:
            continue
    return tuple(signature)


def _msap_run_one_undo_action(context, action):
    """Run one mesh edit and preserve its exact click-before selection.

    Blender's automatic Edit-Mesh Undo restores the coordinate change, but a
    selection made immediately before the next click can otherwise be omitted
    from the snapshot.  The directional bridge writes a private token into the
    same automatic UNDO state and restores before/after selection on Undo/Redo
    without adding another visible history step.
    """
    transaction = None
    if _msap_undo_bridge is not None:
        try:
            transaction = _msap_undo_bridge.begin(context)
        except Exception:
            transaction = None
    before = _msap_edit_mesh_signature(context)
    try:
        action()
    except Exception:
        import traceback
        traceback.print_exc()
        if transaction is not None:
            try:
                _msap_undo_bridge.rollback(transaction)
            except Exception:
                pass
        return {'CANCELLED'}
    after = _msap_edit_mesh_signature(context)
    if after == before:
        if transaction is not None:
            try:
                _msap_undo_bridge.rollback(transaction)
            except Exception:
                pass
        return {'CANCELLED'}
    if transaction is not None:
        try:
            _msap_undo_bridge.commit(transaction, context)
        except Exception:
            pass
    return {'FINISHED'}


def _msap_finish_if_changed(context, before):
    return {'FINISHED'} if _msap_edit_mesh_signature(context) != before else {'CANCELLED'}


_MSAP_EDGE_LENGTH_EPSILON = 1.0e-10


def _msap_collect_selected_edge_groups(context):
    groups = []
    lengths = []
    for obj in get_target_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            matrix_world = obj.matrix_world.copy()
            matrix_world_inverse = matrix_world.inverted()
        except Exception:
            continue

        selected_edges = []
        world_positions = {}
        for edge in bm.edges:
            try:
                if not edge.is_valid or not edge.select or edge.hide:
                    continue
                vert_a, vert_b = edge.verts
                if vert_a.hide or vert_b.hide:
                    continue
                point_a = world_positions.setdefault(vert_a, matrix_world @ vert_a.co)
                point_b = world_positions.setdefault(vert_b, matrix_world @ vert_b.co)
                edge_length = float((point_b - point_a).length)
                if not math.isfinite(edge_length):
                    continue
                selected_edges.append((vert_a, vert_b, int(edge.index)))
                lengths.append(edge_length)
            except Exception:
                continue

        if selected_edges:
            groups.append({
                'object': obj,
                'bmesh': bm,
                'matrix_world_inverse': matrix_world_inverse,
                'positions': world_positions,
                'edges': selected_edges,
            })
    return groups, lengths


def _msap_selected_edge_components(edges):
    adjacency = {}
    for edge_index, (vert_a, vert_b, seed) in enumerate(edges):
        adjacency.setdefault(vert_a, []).append((vert_b, edge_index, seed))
        adjacency.setdefault(vert_b, []).append((vert_a, edge_index, seed))

    components = []
    unseen = set(adjacency)
    while unseen:
        root = min(unseen, key=lambda vert: int(getattr(vert, 'index', 0)))
        stack = [root]
        component_verts = set()
        component_edge_indices = set()
        while stack:
            vert = stack.pop()
            if vert in component_verts:
                continue
            component_verts.add(vert)
            unseen.discard(vert)
            for other, edge_index, _seed in adjacency.get(vert, ()):
                component_edge_indices.add(edge_index)
                if other not in component_verts:
                    stack.append(other)
        components.append((component_verts, [edges[index] for index in sorted(component_edge_indices)]))
    return components


def _msap_edge_constraint_direction(point_a, point_b, seed=0):
    delta = point_b - point_a
    distance = float(delta.length)
    if distance > _MSAP_EDGE_LENGTH_EPSILON:
        return delta / distance
    axes = (
        Vector((1.0, 0.0, 0.0)),
        Vector((0.0, 1.0, 0.0)),
        Vector((0.0, 0.0, 1.0)),
    )
    return axes[abs(int(seed)) % len(axes)].copy()


def _msap_recenter_edge_positions(original, solved, vertices):
    if not vertices:
        return solved
    original_center = Vector((0.0, 0.0, 0.0))
    solved_center = Vector((0.0, 0.0, 0.0))
    for vert in vertices:
        original_center += original[vert]
        solved_center += solved[vert]
    offset = (original_center - solved_center) / float(len(vertices))
    for vert in vertices:
        solved[vert] = solved[vert] + offset
    return solved


def _msap_edge_length_error(positions, edges, target_length):
    error = 0.0
    for vert_a, vert_b, _seed in edges:
        error = max(error, abs(float((positions[vert_b] - positions[vert_a]).length) - target_length))
    return error


def _msap_solve_tree_edge_lengths(original, vertices, edges, target_length):
    if target_length <= _MSAP_EDGE_LENGTH_EPSILON:
        center = Vector((0.0, 0.0, 0.0))
        for vert in vertices:
            center += original[vert]
        center /= float(len(vertices))
        return {vert: center.copy() for vert in vertices}

    adjacency = {vert: [] for vert in vertices}
    for vert_a, vert_b, seed in edges:
        adjacency[vert_a].append((vert_b, seed))
        adjacency[vert_b].append((vert_a, seed))

    root = min(vertices, key=lambda vert: int(getattr(vert, 'index', 0)))
    solved = {root: original[root].copy()}
    stack = [root]
    while stack:
        vert = stack.pop()
        for other, seed in adjacency.get(vert, ()):
            if other in solved:
                continue
            direction = _msap_edge_constraint_direction(original[vert], original[other], seed)
            solved[other] = solved[vert] + direction * target_length
            stack.append(other)
    if len(solved) != len(vertices):
        return None
    return _msap_recenter_edge_positions(original, solved, vertices)


def _msap_solve_cyclic_edge_lengths(original, vertices, edges, target_length, tolerance):
    if target_length <= _MSAP_EDGE_LENGTH_EPSILON:
        return _msap_solve_tree_edge_lengths(original, vertices, edges, target_length)

    solved = {vert: original[vert].copy() for vert in vertices}
    if _msap_edge_length_error(solved, edges, target_length) <= tolerance:
        return solved

    edge_count = len(edges)
    if edge_count <= 512:
        max_iterations = 512
    elif edge_count <= 4096:
        max_iterations = 256
    else:
        max_iterations = 96

    for iteration in range(max_iterations):
        for vert_a, vert_b, seed in edges:
            point_a = solved[vert_a]
            point_b = solved[vert_b]
            delta = point_b - point_a
            distance = float(delta.length)
            if distance > _MSAP_EDGE_LENGTH_EPSILON:
                direction = delta / distance
            else:
                direction = _msap_edge_constraint_direction(original[vert_a], original[vert_b], seed)
                distance = 0.0
            correction = direction * ((distance - target_length) * 0.5)
            solved[vert_a] = point_a + correction
            solved[vert_b] = point_b - correction

        if iteration < 8 or (iteration + 1) % 8 == 0:
            if _msap_edge_length_error(solved, edges, target_length) <= tolerance:
                return _msap_recenter_edge_positions(original, solved, vertices)

    if _msap_edge_length_error(solved, edges, target_length) <= tolerance:
        return _msap_recenter_edge_positions(original, solved, vertices)
    return None


def _msap_solve_selected_edge_group(group, target_length, tolerance):
    original = group['positions']
    solved = {}
    for vertices, edges in _msap_selected_edge_components(group['edges']):
        # Every acyclic component can preserve each original edge direction and
        # satisfy the requested length exactly in one traversal.
        if len(edges) == len(vertices) - 1:
            component_solution = _msap_solve_tree_edge_lengths(original, vertices, edges, target_length)
        else:
            component_solution = _msap_solve_cyclic_edge_lengths(
                original,
                vertices,
                edges,
                target_length,
                tolerance,
            )
        if component_solution is None:
            return None
        if _msap_edge_length_error(component_solution, edges, target_length) > tolerance:
            return None
        solved.update(component_solution)
    return solved


def run_equalize_selected_edge_lengths(context, target_mode):
    groups, lengths = _msap_collect_selected_edge_groups(context)
    edge_count = len(lengths)
    if edge_count < 2:
        return {'status': 'NEED_SELECTION', 'edge_count': edge_count}

    normalized_mode = str(target_mode or _MSAP_EDGE_LENGTH_MODE_AVERAGE).upper()
    if normalized_mode == _MSAP_EDGE_LENGTH_MODE_LONGEST:
        target_length = max(lengths)
    elif normalized_mode == _MSAP_EDGE_LENGTH_MODE_SHORTEST:
        target_length = min(lengths)
    else:
        normalized_mode = _MSAP_EDGE_LENGTH_MODE_AVERAGE
        target_length = sum(lengths) / float(edge_count)

    tolerance = max(1.0e-7, abs(target_length) * 1.0e-6)
    solved_groups = []
    max_error = 0.0
    for group in groups:
        solved = _msap_solve_selected_edge_group(group, target_length, tolerance)
        if solved is None:
            return {
                'status': 'UNRESOLVED_CONSTRAINTS',
                'edge_count': edge_count,
                'target_length': target_length,
                'target_mode': normalized_mode,
            }
        max_error = max(max_error, _msap_edge_length_error(solved, group['edges'], target_length))
        solved_groups.append((group, solved))

    change_tolerance = max(1.0e-12, abs(target_length) * 1.0e-10)
    changed = False
    for group, solved in solved_groups:
        original = group['positions']
        if any((solved[vert] - original[vert]).length > change_tolerance for vert in solved):
            changed = True
            break
    if not changed:
        return {
            'status': 'ALREADY_EQUAL',
            'edge_count': edge_count,
            'target_length': target_length,
            'target_mode': normalized_mode,
            'max_error': max_error,
        }

    # No BMesh coordinate is touched until every component has solved and
    # passed the same world-space error bound, preventing partial edits.
    for group, solved in solved_groups:
        inverse = group['matrix_world_inverse']
        for vert, world_position in solved.items():
            vert.co = inverse @ world_position
        _msap_update_edit_mesh(group['object'].data)

    return {
        'status': 'CHANGED',
        'edge_count': edge_count,
        'target_length': target_length,
        'target_mode': normalized_mode,
        'max_error': max_error,
    }


class MESH_OT_Align_Base(bpy.types.Operator):
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(getattr(cls, 'bl_idname', ''), context)

    def invoke(self, context, event):
        self.use_global = bool(getattr(event, "ctrl", False))
        self.use_slide = bool(getattr(event, "alt", False))
        return self.execute(context)


class MESH_OT_Align_Selected_Symmetry(bpy.types.Operator):
    bl_idname = "mesh.align_selected_symmetry"
    bl_label = "Mirror-align selected vertex pairs"
    bl_description = "Mirror-align topology-compatible pairs seeded by selected vertices, edges, or faces in object-local coordinates."
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Mirror Axis",
        description="Choose the object-local axis to reflect across.",
        items=_MSAP_SYMMETRY_AXIS_ITEMS,
        default='X',
        options={'SKIP_SAVE'},
    )
    direction: bpy.props.EnumProperty(
        name="Source Direction",
        description="Choose the fixed source side and the destination side that will move.",
        items=_MSAP_SYMMETRY_DIRECTION_ITEMS,
        default='POSITIVE_TO_NEGATIVE',
        options={'SKIP_SAVE'},
    )
    distance_threshold: bpy.props.FloatProperty(
        name="Distance Threshold",
        description="Maximum object-local distance between a mirrored source position and a compatible destination vertex.",
        default=0.001,
        min=0.0,
        soft_max=1.0,
        precision=6,
        subtype='DISTANCE',
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_props_dialog(
                self,
                width=380,
                confirm_text=_msap_text("Execute", "実行", context),
            )
        except TypeError:
            return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, "axis", expand=True)
        layout.prop(self, "direction")
        layout.prop(self, "distance_threshold")
        layout.separator()
        if self.direction == 'POSITIVE_TO_NEGATIVE':
            layout.label(text=_msap_text("Positive side stays fixed; negative side moves.", "プラス側を固定し、マイナス側だけを移動します。", context))
        else:
            layout.label(text=_msap_text("Negative side stays fixed; positive side moves.", "マイナス側を固定し、プラス側だけを移動します。", context))

    def execute(self, context):
        result_holder = {}

        def action():
            result_holder.update(run_selected_symmetry_alignment(
                context,
                self.axis,
                self.direction,
                self.distance_threshold,
            ))

        result = _msap_run_one_undo_action(context, action)
        stats = result_holder
        moved = int(stats.get('moved', 0))
        pairs = int(stats.get('pairs', 0))
        ambiguous = int(stats.get('ambiguous', 0))
        unmatched = int(stats.get('unmatched', 0))
        if result == {'FINISHED'}:
            self.report(
                {'INFO'},
                _msap_text(
                    f"Mirror-aligned {moved} destination vertices in {pairs} pairs; skipped {ambiguous} ambiguous and {unmatched} unmatched selections.",
                    f"{pairs} ペアの対象頂点 {moved} 個を鏡映整列しました。曖昧 {ambiguous} 件、未対応 {unmatched} 件をスキップしました。",
                    context,
                ),
            )
        else:
            self.report(
                {'INFO'},
                _msap_text(
                    f"No destination changed; skipped {ambiguous} ambiguous and {unmatched} unmatched selections.",
                    f"移動対象はありません。曖昧 {ambiguous} 件、未対応 {unmatched} 件をスキップしました。",
                    context,
                ),
            )
        return result


class MESH_OT_Align_X(MESH_OT_Align_Base):
    bl_idname = "mesh.align_x"
    bl_label = "X"
    def execute(self, c):
        return _msap_run_one_undo_action(
            c,
            lambda: run_slide_logic(c, 0, getattr(self, 'use_global', False)) if getattr(self, 'use_slide', False) else run_absolute_align(c, (True, False, False), getattr(self, 'use_global', False)),
        )

class MESH_OT_Align_Y(MESH_OT_Align_Base):
    bl_idname = "mesh.align_y"
    bl_label = "Y"
    def execute(self, c):
        return _msap_run_one_undo_action(
            c,
            lambda: run_slide_logic(c, 1, getattr(self, 'use_global', False)) if getattr(self, 'use_slide', False) else run_absolute_align(c, (False, True, False), getattr(self, 'use_global', False)),
        )

class MESH_OT_Align_Z(MESH_OT_Align_Base):
    bl_idname = "mesh.align_z"
    bl_label = "Z"
    def execute(self, c):
        return _msap_run_one_undo_action(
            c,
            lambda: run_slide_logic(c, 2, getattr(self, 'use_global', False)) if getattr(self, 'use_slide', False) else run_absolute_align(c, (False, False, True), getattr(self, 'use_global', False)),
        )

class MESH_OT_Align_Collapse(MESH_OT_Align_Base):
    bl_idname = "mesh.align_collapse"
    bl_label = "Collapse"
    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_absolute_align(c, (True, True, True), getattr(self, 'use_global', False)))

class MESH_OT_Align_View_X(MESH_OT_Align_Base):
    bl_idname = "mesh.align_view_x"
    bl_label = "View X"
    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_view_align(c, 0, getattr(self, 'use_global', False), slide=getattr(self, 'use_slide', False)))

class MESH_OT_Align_View_H(MESH_OT_Align_Base):
    bl_idname = "mesh.align_view_h"
    bl_label = "View Y"
    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_view_align(c, 1, getattr(self, 'use_global', False), slide=getattr(self, 'use_slide', False)))

class MESH_OT_Align_View(MESH_OT_Align_Base):
    bl_idname = "mesh.align_view"
    bl_label = "View Z"
    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_view_align(c, 2, getattr(self, 'use_global', False), slide=getattr(self, 'use_slide', False)))

class MESH_OT_Align_Grid(bpy.types.Operator):
    bl_idname = "mesh.align_grid"
    bl_label = "Align to Grid"
    bl_description = "Project selected vertices onto the active viewport grid plane, matching a 3ds Max-style grid align workflow."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_grid_logic(c))

class MESH_OT_Align_Annotate(MESH_OT_Align_Base):
    bl_idname = "mesh.align_annotate"
    bl_label = "Align to Annotate"
    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_annotate_align(c, slide=getattr(self, 'use_slide', False)))

def _msap_safe_clear_annotation_layers(scene):
    """Remove all annotation/grease pencil layers safely.

    Blender's bpy_prop_collection doesn't always implement .clear().
    This helper never raises and returns number of removed layers.
    """
    gp = getattr(scene, "annotation", None) or getattr(scene, "grease_pencil", None)
    if not gp:
        return 0
    layers = getattr(gp, "layers", None)
    if not layers:
        return 0

    removed = 0
    # Primary: remove first layer until empty (safest during mutation)
    try:
        while len(layers) > 0:
            layers.remove(layers[0])
            removed += 1
        return removed
    except Exception:
        pass

    # Fallback: remove from a snapshot list
    try:
        for layer in list(layers):
            layers.remove(layer)
            removed += 1
    except Exception:
        return removed

    return removed



def _msap_selected_verts_for_object(obj):
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        return bm, [v for v in bm.verts if v.is_valid and v.select and not v.hide]
    except Exception:
        return None, []


def _msap_max_distance_pair(points):
    if len(points) < 2:
        return None
    best = None
    best_len = -1.0
    for i, a in enumerate(points):
        for b in points[i + 1:]:
            try:
                d = (a - b).length_squared
            except Exception:
                d = -1.0
            if d > best_len:
                best_len = d
                best = (a, b)
    return best if best_len > 1.0e-18 else None


def _msap_open_chain_endpoint_indices(verts):
    """Return endpoint indices for one connected open selected chain.

    The common Mesh Align case is an edge chain.  Finding its two topological
    endpoints is linear in the number of selected vertices/edges, whereas the
    legacy farthest-pair search is quadratic.  Ambiguous selections (branches,
    closed loops, disconnected components, or loose point clouds) deliberately
    return ``None`` so the exact legacy fallback remains available.
    """
    if len(verts) < 2:
        return None
    index_by_vert = {vert: index for index, vert in enumerate(verts)}
    selected = set(index_by_vert)
    endpoints = []
    adjacency = {}
    for vert in verts:
        neighbors = []
        try:
            for edge in vert.link_edges:
                other = edge.other_vert(vert)
                if other in selected:
                    neighbors.append(other)
        except Exception:
            return None
        degree = len(neighbors)
        if degree == 1:
            endpoints.append(vert)
        elif degree != 2:
            return None
        adjacency[vert] = tuple(neighbors)
    if len(endpoints) != 2:
        return None

    # Confirm that all selected vertices belong to the same component.  This
    # avoids changing the legacy result for multiple independent chains.
    visited = set()
    stack = [endpoints[0]]
    while stack:
        vert = stack.pop()
        if vert in visited:
            continue
        visited.add(vert)
        stack.extend(other for other in adjacency.get(vert, ()) if other not in visited)
    if len(visited) != len(verts):
        return None
    return index_by_vert[endpoints[0]], index_by_vert[endpoints[1]]


def run_linear_3d_logic(context):
    changed = False
    for obj in get_target_objects(context):
        bm, verts = _msap_selected_verts_for_object(obj)
        if bm is None or len(verts) < 2:
            continue
        points = [v.co.copy() for v in verts]
        endpoint_indices = _msap_open_chain_endpoint_indices(verts)
        pair = (
            (points[endpoint_indices[0]], points[endpoint_indices[1]])
            if endpoint_indices is not None
            else _msap_max_distance_pair(points)
        )
        if pair is None:
            continue
        start, end = pair
        axis = end - start
        length_sq = axis.length_squared
        if length_sq <= 1.0e-18:
            continue
        for v in verts:
            try:
                t = (v.co - start).dot(axis) / length_sq
                v.co = start + axis * t
                changed = True
            except Exception:
                pass
        try:
            _msap_update_edit_mesh(obj.data)
        except Exception:
            pass
    return changed


def _msap_view_vectors(context):
    try:
        rv3d = getattr(getattr(context, 'space_data', None), 'region_3d', None)
        if rv3d is None:
            area = getattr(context, 'area', None)
            if area is not None:
                for space in getattr(area, 'spaces', ()):
                    rv3d = getattr(space, 'region_3d', None)
                    if rv3d is not None:
                        break
        if rv3d is None:
            return None
        inv = rv3d.view_matrix.inverted()
        right = Vector((inv[0][0], inv[1][0], inv[2][0])).normalized()
        up = Vector((inv[0][1], inv[1][1], inv[2][1])).normalized()
        view = Vector((inv[0][2], inv[1][2], inv[2][2])).normalized()
        if right.length <= 1.0e-8 or up.length <= 1.0e-8 or view.length <= 1.0e-8:
            return None
        return right, up, view
    except Exception:
        return None


def run_linear_view_logic(context):
    basis = _msap_view_vectors(context)
    if basis is None:
        return run_linear_3d_logic(context)
    right, up, view = basis
    changed = False
    for obj in get_target_objects(context):
        bm, verts = _msap_selected_verts_for_object(obj)
        if bm is None or len(verts) < 2:
            continue
        try:
            mw = obj.matrix_world.copy()
            imw = mw.inverted()
        except Exception:
            continue
        world_points = [mw @ v.co for v in verts]
        coords2d = [(p.dot(right), p.dot(up)) for p in world_points]
        endpoint_indices = _msap_open_chain_endpoint_indices(verts)
        if endpoint_indices is not None:
            a = coords2d[endpoint_indices[0]]
            b = coords2d[endpoint_indices[1]]
            best = (a, b)
            best_len = (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
        else:
            # Preserve the exact legacy behaviour for non-chain selections.
            best = None
            best_len = -1.0
            for i, a in enumerate(coords2d):
                for j, b in enumerate(coords2d[i + 1:], i + 1):
                    d = (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
                    if d > best_len:
                        best_len = d
                        best = (a, b)
        if best is None or best_len <= 1.0e-18:
            continue
        a, b = best
        ax, ay = a
        bx, by = b
        vx = bx - ax
        vy = by - ay
        denom = (vx * vx) + (vy * vy)
        if denom <= 1.0e-18:
            continue
        for v, p, xy in zip(verts, world_points, coords2d):
            try:
                x, y = xy
                t = ((x - ax) * vx + (y - ay) * vy) / denom
                px = ax + vx * t
                py = ay + vy * t
                depth = p.dot(view)
                new_world = right * px + up * py + view * depth
                v.co = imw @ new_world
                changed = True
            except Exception:
                pass
        try:
            _msap_update_edit_mesh(obj.data)
        except Exception:
            pass
    return changed


class MESH_OT_Clear_Annotation(bpy.types.Operator):
    bl_idname = "mesh.clear_annotation"
    bl_label = "Clear Annotations"
    bl_description = "Delete all annotation strokes in the current scene."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context is not None

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def execute(self, context):
        try:
            removed = _msap_safe_clear_annotation_layers(context.scene)
        except Exception:
            # Never fail the operator; this is a cleanup action.
            removed = 0
        return {'FINISHED'} if int(removed or 0) > 0 else {'CANCELLED'}

class MESH_OT_Align_Linear_3D(bpy.types.Operator):
    bl_idname = "mesh.align_linear_3d"
    bl_label = "3D Line"
    bl_description = "Align the selected open vertex chain into a straight 3D line between its endpoints."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_linear_3d_logic(c))

class MESH_OT_Align_Move_View(MESH_OT_Align_Base):
    bl_idname = "mesh.align_move_view"
    bl_label = "2D Line (View)"

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def execute(self, c):
        return _msap_run_one_undo_action(c, lambda: run_linear_view_logic(c))


class MESH_OT_Equalize_Edge_Length(bpy.types.Operator):
    bl_idname = "mesh.smart_modeling_equalize_edge_length"
    bl_label = "Equal Edge Length"
    bl_description = "Make every selected edge the same world-space length."
    bl_options = {'UNDO'}

    target_mode: bpy.props.EnumProperty(
        name="Target Length",
        description="Choose which selected edge length becomes the shared target",
        items=_MSAP_EDGE_LENGTH_MODE_ITEMS,
        default=_MSAP_EDGE_LENGTH_MODE_AVERAGE,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def execute(self, context):
        result = {}
        outcome = _msap_run_one_undo_action(
            context,
            lambda: result.update(run_equalize_selected_edge_lengths(context, self.target_mode)),
        )
        status = result.get('status', '')
        if status == 'NEED_SELECTION':
            self.report(
                {'WARNING'},
                _msap_text(
                    "Select at least two visible edges.",
                    "表示中の辺を2本以上選択してください。",
                    context,
                ),
            )
        elif status == 'UNRESOLVED_CONSTRAINTS':
            self.report(
                {'WARNING'},
                _msap_text(
                    "The selected cyclic edge network could not reach one shared length without residual error.",
                    "選択した閉ループを含む辺ネットワークを、残留誤差なく同じ長さへ収束できませんでした。",
                    context,
                ),
            )
        elif status == 'ALREADY_EQUAL':
            self.report(
                {'INFO'},
                _msap_text(
                    "The selected edges already have the target length.",
                    "選択辺はすでに目標の長さで統一されています。",
                    context,
                ),
            )
        elif status == 'CHANGED' and outcome == {'FINISHED'}:
            mode_label = {
                _MSAP_EDGE_LENGTH_MODE_AVERAGE: _msap_text("average", "平均", context),
                _MSAP_EDGE_LENGTH_MODE_LONGEST: _msap_text("longest", "最長", context),
                _MSAP_EDGE_LENGTH_MODE_SHORTEST: _msap_text("shortest", "最短", context),
            }.get(result.get('target_mode'), _msap_text("average", "平均", context))
            edge_count = int(result.get('edge_count', 0))
            target_length = float(result.get('target_length', 0.0))
            self.report(
                {'INFO'},
                _msap_text(
                    f"Matched {edge_count} edges to the {mode_label} length ({target_length:.6g}).",
                    f"{edge_count}本の辺を{mode_label}の長さ（{target_length:.6g}）へ統一しました。",
                    context,
                ),
            )
        return outcome


class MESH_OT_Set_Flow(bpy.types.Operator):
    bl_idname = "mesh.set_flow"
    bl_label = "Set Flow"
    bl_description = "Smooth the selected edge flow by repositioning selected vertices along surrounding topology."
    bl_options = {'UNDO'}

    algorithm: bpy.props.EnumProperty(
        name=_MSAP_FLOW_ALGORITHM_NAME,
        description=_MSAP_FLOW_ALGORITHM_DESCRIPTION,
        items=_MSAP_FLOW_ALGORITHM_ITEMS,
        default=_MSAP_FLOW_ALGORITHM_CURRENT,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _msap_operator_description(cls.bl_idname, context)

    def invoke(self, context, event):
        del event
        self.algorithm = _msap_scene_flow_algorithm(context)
        try:
            return context.window_manager.invoke_props_dialog(self, width=320, confirm_text=bpy.app.translations.pgettext_iface("Apply"))
        except TypeError:
            return context.window_manager.invoke_props_dialog(self, width=320)
        except Exception:
            return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, "algorithm")

    def execute(self, c):
        _msap_store_flow_algorithm(c, self.algorithm)
        return _msap_run_one_undo_action(c, lambda: run_set_flow(c, iterations=1, algorithm=self.algorithm))

# =============================================================
# 5. UIパネル
# =============================================================
_MSAP_MESH_ALIGN_POPUP_WIDTH = 420


def _msap_draw_mesh_align_master_layout(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    layout.operator_context = 'INVOKE_DEFAULT'
    c = layout.column(align=True)
    c.separator(factor=0.6)
    c.label(text=_msap_text("Selected Symmetry Pairs", "選択対称ペア整列", context), icon='MOD_MIRROR')
    r = c.row(align=True); r.scale_y = 1.2
    r.operator(
        "mesh.align_selected_symmetry",
        text=_msap_text("Mirror-align selected vertex pairs", "選択頂点ペアを鏡映整列", context),
        icon='MOD_MIRROR',
    )
    c.separator(factor=0.6)
    r = c.row(align=True); r.scale_y = 1.2
    r.operator("mesh.align_x", text="X"); r.operator("mesh.align_y", text="Y"); r.operator("mesh.align_z", text="Z")
    r = c.row(align=True); r.scale_y = 1.2
    r.operator("mesh.align_view_x", text=_msap_text("View X", "視点でX", context))
    r.operator("mesh.align_view_h", text=_msap_text("View Y", "視点でY", context))
    r.operator("mesh.align_view", text=_msap_text("View Z", "視点でZ", context))
    c.separator(factor=0.6)
    r = c.row(align=True); r.scale_y = 1.2
    r.operator("mesh.align_collapse", text=_msap_text("Concentrated to Center", "中心に集結", context))
    r.operator("mesh.align_grid", text=_msap_text("Align to Grid", "グリッドに揃える", context))
    c.separator(factor=0.35)
    c.label(text=_msap_text("Equal Edge Length", "辺の長さを統一", context), icon='EDGESEL')
    r = c.row(align=True); r.scale_y = 1.2
    op = r.operator("mesh.smart_modeling_equalize_edge_length", text=_msap_text("Average", "平均", context))
    op.target_mode = _MSAP_EDGE_LENGTH_MODE_AVERAGE
    op = r.operator("mesh.smart_modeling_equalize_edge_length", text=_msap_text("Longest", "最長合わせ", context))
    op.target_mode = _MSAP_EDGE_LENGTH_MODE_LONGEST
    op = r.operator("mesh.smart_modeling_equalize_edge_length", text=_msap_text("Shortest", "最短合わせ", context))
    op.target_mode = _MSAP_EDGE_LENGTH_MODE_SHORTEST
    c.separator(factor=0.35)
    c.label(text=_msap_text("Annotation Align", "アノテーション整列", context), icon='GREASEPENCIL')
    r = c.row(align=True); r.scale_y = 1.2
    r.operator("mesh.align_annotate", text=_msap_text("Align to Annotate", "アノテート線に揃える", context))
    r.operator("mesh.clear_annotation", text="", icon='TRASH')
    c.separator(factor=0.35)
    c.label(text=_msap_text("Loop Align", "ループ整列", context), icon='MOD_CURVE')
    r = c.row(align=True); r.scale_y = 1.2
    r.operator("mesh.align_linear_3d", text=_msap_text("3D Line", "3D直線", context), icon='MESH_DATA')
    r.operator("mesh.align_move_view", text=_msap_text("2D Line (View)", "2D直線（ビュー）", context), icon='VERTEXSEL')
    c.separator(factor=0.35)
    c.label(text=_msap_text("Flow", "フロー", context), icon='CURVE_PATH')
    props = _msap_scene_props(context)
    if props is not None:
        c.prop(props, "flow_algorithm", text=_msap_text("Flow Algorithm", "フローアルゴリズム", context))
    r = c.row(align=True); r.scale_y = 1.2
    try:
        r.operator_context = 'EXEC_DEFAULT'
    except Exception:
        pass
    op = r.operator("mesh.set_flow", text=_msap_text("Set Flow", 'フロー設定', context))
    try:
        op.algorithm = _msap_scene_flow_algorithm(context)
    except Exception:
        pass


def invoke_mesh_align_popup(context=None, *, operator=None, event=None, invoke=False):
    """Open the Mesh Align popup without replacing its active RNA owner.

    The first shortcut invocation is received by Smart Modeling's lightweight
    lazy proxy.  The loader patches the real implementation into that same
    registered class, and this helper opens the popup on the *current* operator
    instance.  No Python-created operator object and no second bpy.ops call are
    used, so the initial key event is not lost and Blender keeps one valid modal
    owner for the complete popup lifetime.
    """
    del event
    context = context or getattr(bpy, 'context', None)
    if not invoke or context is None or operator is None:
        return {'CANCELLED'}
    try:
        if bpy.app.background:
            return {'CANCELLED'}
        if getattr(context, 'window_manager', None) is None or getattr(context, 'window', None) is None:
            return {'CANCELLED'}
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return {'CANCELLED'}
        return context.window_manager.invoke_popup(operator, width=_MSAP_MESH_ALIGN_POPUP_WIDTH)
    except Exception:
        return {'CANCELLED'}


class MESH_OT_MeshAlignMaster(bpy.types.Operator):
    bl_idname = "mesh.mesh_align_master"
    bl_label = 'Open Align Presets'
    bl_description = _MESH_ALIGN_MASTER_DESCRIPTION_EN
    # This operator only opens the command popup.  The selected child alignment
    # operator owns the actual mesh edit and its one Undo record.
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    @classmethod
    def poll(cls, context):
        return _msap_poll_edit_mesh(context)

    @classmethod
    def description(cls, context, properties):
        return _MESH_ALIGN_MASTER_DESCRIPTION_JA if _msap_is_japanese(context) else _MESH_ALIGN_MASTER_DESCRIPTION_EN

    def _can_open_popup(self, context):
        try:
            if bpy.app.background:
                return False
            if context is None or getattr(context, "window_manager", None) is None:
                return False
            if getattr(context, "window", None) is None:
                return False
            area = getattr(context, "area", None)
            if area is not None and getattr(area, "type", None) != 'VIEW_3D':
                return False
            return True
        except Exception:
            return False

    def _open_fixed_width_popup(self, context):
        if not self._can_open_popup(context):
            return {'CANCELLED'}
        try:
            return context.window_manager.invoke_popup(self, width=_MSAP_MESH_ALIGN_POPUP_WIDTH)
        except Exception:
            return {'CANCELLED'}

    def execute(self, context):
        # EXEC_DEFAULT must not open an operator popup. Blender 5.1 can crash while
        # rebuilding operator property UI from execute-called popups. UI buttons set
        # operator_context to INVOKE_DEFAULT, while background/F3 execute stays safe.
        return {'CANCELLED'}

    def invoke(self, context, event):
        return invoke_mesh_align_popup(
            context,
            operator=self,
            event=event,
            invoke=True,
        )

    def draw(self, context):
        _msap_draw_mesh_align_master_layout(self.layout, context)


# =============================================================
# 6. 登録
# =============================================================
classes = (
    AlignSlideSceneProps,
    MESH_OT_Align_Selected_Symmetry,
    MESH_OT_Align_X, MESH_OT_Align_Y, MESH_OT_Align_Z, MESH_OT_Align_Collapse,
    MESH_OT_Align_View_X, MESH_OT_Align_View_H, MESH_OT_Align_View, MESH_OT_Align_Grid,
    MESH_OT_Align_Annotate, MESH_OT_Clear_Annotation,
    MESH_OT_Align_Linear_3D, MESH_OT_Align_Move_View,
    MESH_OT_Equalize_Edge_Length,
    MESH_OT_Set_Flow,
    MESH_OT_MeshAlignMaster,
)

def _msap_unregister_stale_connect_flow_operator():
    # Historical operator IDs are not ownership evidence. Exact stale classes
    # are reclaimed by the suite-level generation ledger before feature load.
    return 0


def register():
    _msap_unregister_stale_connect_flow_operator()
    try: bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        bpy.app.translations.unregister(__name__)
        bpy.app.translations.register(__name__, translation_dict)
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.align_slide_props = bpy.props.PointerProperty(type=AlignSlideSceneProps)

    # --- Add-on設定画面のdescription動的書き換え ---
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                desc_eng = "Preset collection for mesh alignment. Supports vertex sliding and multi-object editing. ID: 'mesh.mesh_align_master'"
                try:
                    desc_tr = bpy.app.translations.pgettext(desc_eng)
                except Exception:
                    desc_tr = desc_eng
                    
                try:
                    prefs = getattr(bpy.context, "preferences", None)
                    lang = getattr(getattr(prefs, "view", None), "language", "") if prefs else ""
                    if (lang or "").startswith("ja") and desc_tr == desc_eng:
                        desc_tr = translation_dict.get("ja_JP", {}).get(("*", desc_eng), desc_tr)
                except Exception:
                    pass
                
                mod.bl_info["description"] = desc_tr
                break
    except Exception:
        pass


def unregister():
    try:
        # --- Add-on設定画面のdescriptionを元の英語に戻す ---
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Preset collection for mesh alignment. Supports vertex sliding and multi-object editing. ID: 'mesh.mesh_align_master'"
                break
    except Exception:
        pass

    try: bpy.app.translations.unregister(__name__)
    except: pass
    if hasattr(bpy.types.Scene, "align_slide_props"): del bpy.types.Scene.align_slide_props
    for cls in reversed(classes):
        if hasattr(cls, "bl_rna"): bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()


# --- Smart Modeling compatibility layer ---
try:
    from bpy.types import PropertyGroup
except Exception:
    PropertyGroup = object

class MSAP_AddonPreferences(PropertyGroup):
    pass

_SMS_MSAP_ORIGINAL_REGISTER = register
_SMS_MSAP_ORIGINAL_UNREGISTER = unregister

def register():
    try:
        bpy.utils.register_class(MSAP_AddonPreferences)
    except ValueError:
        pass
    _SMS_MSAP_ORIGINAL_REGISTER()


def unregister():
    try:
        _SMS_MSAP_ORIGINAL_UNREGISTER()
    finally:
        try:
            bpy.utils.unregister_class(MSAP_AddonPreferences)
        except Exception:
            pass
