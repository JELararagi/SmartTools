# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Directional selection Undo bridge for Mesh Align.

Blender's edit-mesh Undo correctly restores Mesh Align coordinates, but a
selection made immediately before the next click can remain outside the global
Undo snapshot.  Consecutive clicks then restore the previous operation's
selection instead of the state immediately before the click.

This bridge writes a private integer token into the edited BMesh as part of the
same automatic UNDO operator.  Undo/Redo handlers read that token and restore
the exact directional selection snapshot for the matching click.  It adds no
extra Undo step and uses no timer, polling, draw handler, key monitor, or thread.
"""

from __future__ import annotations

from collections import Counter
import secrets

import bmesh
import bpy

_NS_KEY = "SMART_MODELING_MESH_ALIGN_UNDO_BRIDGE"
_LAYER_PREFIX = ".jel_sms_mesh_align_undo_"
_MAX_OPERATIONS = 4096
_MAX_TOKEN = 2_000_000_000
_HANDLER_NAMES = {"_undo_post", "_redo_post", "_load_pre", "_save_pre", "_save_post", "_save_post_fail"}


def _uid(id_data) -> int:
    try:
        return int(getattr(id_data, "session_uid", 0) or 0)
    except Exception:
        return 0


def _state(create: bool = True):
    try:
        ns = bpy.app.driver_namespace
    except Exception:
        return None
    state = ns.get(_NS_KEY)
    if not isinstance(state, dict):
        if not create:
            return None
        state = {
            "layer_name": f"{_LAYER_PREFIX}{secrets.token_hex(6)}",
            "next_token": 1,
            "current_token": 0,
            "operations": {},
            "order": [],
            "meshes": {},
            "save_restore": [],
            "syncing": False,
            "shutdown": False,
            "shutdown_callback": shutdown,
        }
        ns[_NS_KEY] = state
    if not str(state.get("layer_name") or "").startswith(_LAYER_PREFIX):
        state["layer_name"] = f"{_LAYER_PREFIX}{secrets.token_hex(6)}"
    state.setdefault("next_token", 1)
    state.setdefault("current_token", 0)
    state.setdefault("operations", {})
    state.setdefault("order", [])
    state.setdefault("meshes", {})
    state.setdefault("save_restore", [])
    state.setdefault("syncing", False)
    state.setdefault("shutdown", False)
    state["shutdown_callback"] = shutdown
    return state


def _layer_name() -> str:
    state = _state(True)
    return str(state.get("layer_name") or "") if state else ""


def _mesh_key(mesh) -> str:
    return f"{_uid(mesh)}:{str(getattr(mesh, 'name_full', '') or getattr(mesh, 'name', '') or '')}"


def _mesh_record(mesh) -> dict:
    return {"name": str(getattr(mesh, "name_full", "") or getattr(mesh, "name", "") or ""), "uid": _uid(mesh)}


def _object_record(obj) -> dict:
    return {"name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""), "uid": _uid(obj)}


def _resolve_id(collection, record):
    if not isinstance(record, dict):
        return None
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    item = collection.get(name) if name else None
    if item is not None and (not uid or _uid(item) == uid):
        return item
    if uid:
        for candidate in collection:
            if _uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return item


def _resolve_mesh(record):
    return _resolve_id(bpy.data.meshes, record)


def _resolve_object(record):
    return _resolve_id(bpy.data.objects, record)


def _mesh_entry(mesh, create: bool = True):
    state = _state(create)
    if state is None:
        return None
    key = _mesh_key(mesh)
    entry = state["meshes"].get(key)
    if not isinstance(entry, dict):
        if not create:
            uid = _uid(mesh)
            for old_key, candidate in tuple(state["meshes"].items()):
                if uid and int(candidate.get("uid") or 0) == uid:
                    entry = candidate
                    if old_key != key:
                        state["meshes"].pop(old_key, None)
                        state["meshes"][key] = entry
                    break
        if not isinstance(entry, dict):
            if not create:
                return None
            entry = {"name": str(mesh.name), "uid": _uid(mesh), "known_tokens": set(), "last_token": 0}
            state["meshes"][key] = entry
    entry["name"] = str(mesh.name)
    entry["uid"] = _uid(mesh)
    entry.setdefault("known_tokens", set())
    entry.setdefault("last_token", 0)
    return entry


def _is_our_handler(fn) -> bool:
    try:
        return str(getattr(fn, "__module__", "")).endswith(".mesh_align_preset.undo_bridge") and str(getattr(fn, "__name__", "")) in _HANDLER_NAMES
    except Exception:
        return False


def ensure() -> bool:
    state = _state(True)
    if state is None:
        return False
    state["shutdown"] = False
    for handlers, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
        (bpy.app.handlers.save_pre, _save_pre),
        (bpy.app.handlers.save_post, _save_post),
        (bpy.app.handlers.save_post_fail, _save_post_fail),
    ):
        for fn in tuple(handlers):
            if fn is not current and _is_our_handler(fn):
                try: handlers.remove(fn)
                except Exception: pass
        if current not in handlers:
            handlers.append(current)
    return True


def _next_token() -> int:
    state = _state(True)
    token = int(state.get("next_token") or 1) if state else 0
    if token <= 0 or token > _MAX_TOKEN:
        token = 1
    if state:
        state["next_token"] = token + 1
    return token


def _domain_layer(domain, name: str, create: bool):
    try:
        layer = domain.layers.int.get(name)
        if layer is None and create:
            layer = domain.layers.int.new(name)
        return layer
    except Exception:
        return None


def _write_token(mesh, token: int, *, bm=None) -> bool:
    name = _layer_name()
    if mesh is None or not name:
        return False
    try:
        bm = bm or (bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None)
    except Exception:
        bm = None
    if bm is None:
        return False
    changed = False
    for domain in (bm.verts, bm.edges, bm.faces):
        layer = _domain_layer(domain, name, token > 0)
        if token <= 0:
            if layer is not None:
                try: domain.layers.int.remove(layer); changed = True
                except Exception: pass
            continue
        if layer is None:
            continue
        try:
            for element in domain:
                element[layer] = int(token)
            changed = True
        except Exception:
            pass
    try: bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    except Exception: pass
    if token > 0:
        entry = _mesh_entry(mesh, True)
        if entry is not None:
            entry["last_token"] = int(token)
    return changed or token <= 0


def _read_token(mesh, entry=None) -> int:
    entry = entry or _mesh_entry(mesh, False)
    if not isinstance(entry, dict):
        return 0
    known = {int(v) for v in entry.get("known_tokens", set()) if int(v) > 0}
    if not known:
        return 0
    try: bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
    except Exception: bm = None
    if bm is None:
        return 0
    counts = Counter()
    name = _layer_name()
    for domain in (bm.verts, bm.edges, bm.faces):
        layer = _domain_layer(domain, name, False)
        if layer is None:
            continue
        try: counts.update(int(element[layer]) for element in domain if int(element[layer]) in known)
        except Exception: pass
    if not counts:
        return 0
    return int(max((count, token) for token, count in counts.items())[1])


def _remove_stale_layers(mesh) -> None:
    current = _layer_name()
    try: bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
    except Exception: bm = None
    if bm is None:
        return
    changed = False
    for domain in (bm.verts, bm.edges, bm.faces):
        try: names = tuple(domain.layers.int.keys())
        except Exception: names = ()
        for name in names:
            if str(name).startswith(_LAYER_PREFIX) and str(name) != current:
                try:
                    layer = domain.layers.int.get(name)
                    if layer is not None: domain.layers.int.remove(layer); changed = True
                except Exception: pass
    if changed:
        try: bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except Exception: pass


def _edit_objects(context) -> tuple:
    try: objects = tuple(getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None) or ())
    except Exception: objects = ()
    if not objects:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        objects = (obj,) if obj is not None else ()
    out, seen = [], set()
    for obj in objects:
        try:
            if obj is None or obj.type != "MESH" or obj.mode != "EDIT": continue
            key = int(obj.data.as_pointer())
            if key in seen: continue
            seen.add(key); out.append(obj)
        except Exception: pass
    return tuple(out)


def _indices(domain) -> tuple:
    result = []
    for element in domain:
        try:
            if bool(element.select): result.append(int(element.index))
        except Exception: pass
    return tuple(result)


def _capture_selection(context, objects=None) -> dict:
    records = []
    for obj in tuple(objects or _edit_objects(context)):
        mesh = getattr(obj, "data", None)
        if mesh is None: continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        except Exception: continue
        history = []
        try:
            for element in bm.select_history:
                if isinstance(element, bmesh.types.BMVert): history.append(("VERT", int(element.index)))
                elif isinstance(element, bmesh.types.BMEdge): history.append(("EDGE", int(element.index)))
                elif isinstance(element, bmesh.types.BMFace): history.append(("FACE", int(element.index)))
        except Exception: pass
        try: active_face = int(bm.faces.active.index) if bm.faces.active is not None else -1
        except Exception: active_face = -1
        records.append({
            "mesh": _mesh_record(mesh), "object": _object_record(obj),
            "verts": _indices(bm.verts), "edges": _indices(bm.edges), "faces": _indices(bm.faces),
            "history": tuple(history), "active_face": active_face,
        })
    try: select_mode = tuple(bool(v) for v in context.tool_settings.mesh_select_mode)
    except Exception: select_mode = (True, False, False)
    try: active = context.view_layer.objects.active
    except Exception: active = None
    return {"records": tuple(records), "select_mode": select_mode, "active_object": _object_record(active) if active else None}


def _apply_selection(payload) -> bool:
    if not isinstance(payload, dict):
        return False
    changed = False
    try:
        mode = tuple(bool(v) for v in payload.get("select_mode", (True, False, False)))
        if len(mode) == 3: bpy.context.tool_settings.mesh_select_mode = mode
    except Exception: pass
    for record in tuple(payload.get("records") or ()):
        mesh = _resolve_mesh(record.get("mesh"))
        if mesh is None or not bool(getattr(mesh, "is_editmode", False)): continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
            bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        except Exception: continue
        for domain in (bm.verts, bm.edges, bm.faces):
            for element in domain:
                try: element.select = False
                except Exception: pass
        for key, domain in (("verts", bm.verts), ("edges", bm.edges), ("faces", bm.faces)):
            for index in tuple(record.get(key) or ()):
                try:
                    if 0 <= int(index) < len(domain): domain[int(index)].select = True
                except Exception: pass
        try:
            bm.select_history.clear()
            for kind, index in tuple(record.get("history") or ()):
                domain = bm.verts if kind == "VERT" else bm.edges if kind == "EDGE" else bm.faces
                if 0 <= int(index) < len(domain): bm.select_history.add(domain[int(index)])
        except Exception: pass
        try:
            i = int(record.get("active_face", -1)); bm.faces.active = bm.faces[i] if 0 <= i < len(bm.faces) else None
        except Exception: pass
        try: bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False); changed = True
        except Exception: pass
    active = _resolve_object(payload.get("active_object"))
    if active is not None:
        try: bpy.context.view_layer.objects.active = active
        except Exception: pass
    return changed


def _current_known_token(state) -> int:
    counts = Counter()
    for entry in tuple(state.get("meshes", {}).values()):
        mesh = _resolve_mesh(entry)
        if mesh is None: continue
        token = _read_token(mesh, entry)
        if token > 0: counts[token] += 1
    return int(counts.most_common(1)[0][0]) if counts else 0


def _prune_future(state, current: int) -> None:
    for token in tuple(state.get("operations", {})):
        if int(token) > int(current): state["operations"].pop(token, None)
    state["order"] = [int(t) for t in state.get("order", ()) if int(t) <= int(current)]
    known = {int(t) for t in state.get("operations", {})}
    for entry in tuple(state.get("meshes", {}).values()):
        entry["known_tokens"] = {int(t) for t in entry.get("known_tokens", set()) if int(t) in known}


def begin(context):
    objects = _edit_objects(context)
    if not objects or not ensure():
        return None
    state = _state(True)
    meshes = []
    for obj in objects:
        mesh = obj.data; _remove_stale_layers(mesh); _mesh_entry(mesh, True); meshes.append(mesh)
    current = _current_known_token(state)
    if not current:
        current = int(state.get("current_token") or 0)
    _prune_future(state, current)
    token = _next_token()
    if token <= 0: return None
    return {"before_token": current, "after_token": token, "objects": objects, "meshes": tuple(meshes), "before": _capture_selection(context, objects)}


def commit(record, context=None) -> bool:
    if not isinstance(record, dict): return False
    state = _state(False)
    if not state: return False
    context = context or bpy.context
    token = int(record.get("after_token") or 0)
    if token <= 0: return False
    after = _capture_selection(context, record.get("objects"))
    for mesh in tuple(record.get("meshes") or ()):
        entry = _mesh_entry(mesh, True); entry.setdefault("known_tokens", set()).add(token)
        try: bm = bmesh.from_edit_mesh(mesh) if bool(getattr(mesh, "is_editmode", False)) else None
        except Exception: bm = None
        if not _write_token(mesh, token, bm=bm): return False
    state["operations"][token] = {"before_token": int(record.get("before_token") or 0), "after_token": token, "before": record.get("before"), "after": after}
    order = state.setdefault("order", [])
    if token in order: order.remove(token)
    order.append(token)
    while len(order) > _MAX_OPERATIONS:
        old = int(order.pop(0)); state["operations"].pop(old, None)
    state["current_token"] = token
    return True


def rollback(record) -> None:
    if not isinstance(record, dict): return
    state = _state(False)
    if not state: return
    token = int(record.get("after_token") or 0)
    state.get("operations", {}).pop(token, None)
    try: state.get("order", []).remove(token)
    except Exception: pass
    state["current_token"] = int(record.get("before_token") or 0)
    _apply_selection(record.get("before"))


def _undo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"): return
    state["syncing"] = True
    try:
        previous = int(state.get("current_token") or 0)
        operation = state.get("operations", {}).get(previous)
        if not isinstance(operation, dict): return
        target = int(operation.get("before_token") or 0)
        if _current_known_token(state) != target: return
        _apply_selection(operation.get("before")); state["current_token"] = target
    finally:
        state["syncing"] = False


def _redo_post(_dummy=None):
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"): return
    state["syncing"] = True
    try:
        current = int(state.get("current_token") or 0)
        read = _current_known_token(state)
        candidates = [op for op in state.get("operations", {}).values() if int(op.get("before_token") or 0) == current and int(op.get("after_token") or 0) == read]
        if not candidates: return
        operation = min(candidates, key=lambda op: int(op.get("after_token") or 0))
        _apply_selection(operation.get("after")); state["current_token"] = int(operation.get("after_token") or 0)
    finally:
        state["syncing"] = False


def _load_pre(_dummy=None):
    shutdown()


def _save_pre(_filepath=None):
    state = _state(False)
    if not state or state.get("shutdown"): return
    restore = []
    for entry in tuple(state.get("meshes", {}).values()):
        mesh = _resolve_mesh(entry)
        if mesh is None: continue
        token = _read_token(mesh, entry)
        _write_token(mesh, 0)
        if token > 0: restore.append((_mesh_record(mesh), token))
    state["save_restore"] = restore


def _restore_after_save():
    state = _state(False)
    if not state or state.get("shutdown"): return
    restore = list(state.get("save_restore", ()) or ()); state["save_restore"] = []
    for mesh_record, token in restore:
        mesh = _resolve_mesh(mesh_record)
        if mesh is not None: _write_token(mesh, int(token))


def _save_post(_filepath=None):
    _restore_after_save()


def _save_post_fail(_filepath=None):
    _restore_after_save()


def shutdown() -> None:
    state = _state(False)
    if state:
        state["shutdown"] = True
        for entry in tuple(state.get("meshes", {}).values()):
            mesh = _resolve_mesh(entry)
            if mesh is not None:
                try: _write_token(mesh, 0)
                except Exception: pass
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post, bpy.app.handlers.load_pre, bpy.app.handlers.save_pre, bpy.app.handlers.save_post, bpy.app.handlers.save_post_fail):
        for fn in tuple(handlers):
            if _is_our_handler(fn):
                try: handlers.remove(fn)
                except Exception: pass
    try: bpy.app.driver_namespace.pop(_NS_KEY, None)
    except Exception: pass


def runtime_snapshot() -> dict:
    state = _state(False)
    return {
        "active": bool(state and not state.get("shutdown")),
        "current_token": int(state.get("current_token") or 0) if state else 0,
        "operation_count": len(state.get("operations", {})) if state else 0,
        "handler_count": sum(1 for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post, bpy.app.handlers.load_pre, bpy.app.handlers.save_pre, bpy.app.handlers.save_post, bpy.app.handlers.save_post_fail) for fn in handlers if _is_our_handler(fn)),
        "timer_count": 0,
    }
