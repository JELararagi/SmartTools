# SPDX-License-Identifier: GPL-3.0-or-later
"""Set the metric dimensions in Blender’s active fastener operator."""

from bpy import context

parameters = {
    'bf_Model_Type': 'bf_Model_Bolt',
    'bf_Head_Type': 'bf_Head_Hex',
    'bf_Bit_Type': 'bf_Bit_None',
    'bf_Nut_Type': 'bf_Nut_Hex',
    'bf_Major_Dia': 3,
    'bf_Pitch': 0.5,
    'bf_Rounded_Root_Dia': 2.387,
    'bf_Minor_Dia': 2.459,
    'bf_Shank_Dia': 3,
    'bf_Shank_Length': 0,
    'bf_Thread_Length': 6,
    'bf_Crest_Percent': 12.5,
    'bf_Root_Percent': 25,
    'bf_Div_Count': 36,
    'bf_Allen_Bit_Depth': 1.5,
    'bf_Allen_Bit_Flat_Distance': 2.5,
    'bf_Torx_Bit_Depth': 1.5,
    'bf_Torx_Size_Type': 'bf_Torx_T10',
    'bf_Philips_Bit_Dia': 1.82,
    'bf_Phillips_Bit_Depth': 1.1431535570000002,
    'bf_Hex_Head_Height': 2,
    'bf_Hex_Head_Flat_Distance': 5.5,
    'bf_12_Point_Head_Height': 3,
    'bf_12_Point_Head_Flat_Distance': 3,
    'bf_12_Point_Head_Flange_Dia': 5.72,
    'bf_CounterSink_Head_Dia': 6.3,
    'bf_CounterSink_Head_Angle': 1.5708,
    'bf_Cap_Head_Height': 3,
    'bf_Cap_Head_Dia': 5.5,
    'bf_Dome_Head_Dia': 5.6,
    'bf_Pan_Head_Dia': 5.6,
    'bf_Hex_Nut_Height': 2.4,
    'bf_Hex_Nut_Flat_Distance': 5.5,
    'bf_12_Point_Nut_Height': 3,
    'bf_12_Point_Nut_Flat_Distance': 4,
    'bf_12_Point_Nut_Flange_Dia': 5.72,
}
operator = context.active_operator
for field, setting in parameters.items():
    setattr(operator, field, setting)
