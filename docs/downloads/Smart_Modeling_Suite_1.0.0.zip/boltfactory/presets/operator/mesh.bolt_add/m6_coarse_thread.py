# SPDX-License-Identifier: GPL-3.0-or-later
"""Set the metric dimensions in Blender’s active fastener operator."""

from bpy import context

parameters = {
    'bf_Model_Type': 'bf_Model_Bolt',
    'bf_Head_Type': 'bf_Head_Hex',
    'bf_Bit_Type': 'bf_Bit_None',
    'bf_Nut_Type': 'bf_Nut_Hex',
    'bf_Major_Dia': 6,
    'bf_Pitch': 1,
    'bf_Rounded_Root_Dia': 4.773,
    'bf_Minor_Dia': 4.917,
    'bf_Shank_Dia': 6,
    'bf_Shank_Length': 0,
    'bf_Thread_Length': 12,
    'bf_Crest_Percent': 12.5,
    'bf_Root_Percent': 25,
    'bf_Div_Count': 36,
    'bf_Allen_Bit_Depth': 3.0,
    'bf_Allen_Bit_Flat_Distance': 5,
    'bf_Torx_Bit_Depth': 3.0,
    'bf_Torx_Size_Type': 'bf_Torx_T30',
    'bf_Philips_Bit_Dia': 3.9000000000000004,
    'bf_Phillips_Bit_Depth': 2.449614765,
    'bf_Hex_Head_Height': 4,
    'bf_Hex_Head_Flat_Distance': 10,
    'bf_12_Point_Head_Height': 6,
    'bf_12_Point_Head_Flat_Distance': 6,
    'bf_12_Point_Head_Flange_Dia': 10.22,
    'bf_CounterSink_Head_Dia': 12.6,
    'bf_CounterSink_Head_Angle': 1.5708,
    'bf_Cap_Head_Height': 6,
    'bf_Cap_Head_Dia': 10,
    'bf_Dome_Head_Dia': 12,
    'bf_Pan_Head_Dia': 12,
    'bf_Hex_Nut_Height': 5,
    'bf_Hex_Nut_Flat_Distance': 10,
    'bf_12_Point_Nut_Height': 6.1,
    'bf_12_Point_Nut_Flat_Distance': 8,
    'bf_12_Point_Nut_Flange_Dia': 10.5,
}
operator = context.active_operator
for field, setting in parameters.items():
    setattr(operator, field, setting)
