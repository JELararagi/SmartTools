# SPDX-License-Identifier: GPL-3.0-or-later
"""Set the metric dimensions in Blender’s active fastener operator."""

from bpy import context

parameters = {
    'bf_Model_Type': 'bf_Model_Bolt',
    'bf_Head_Type': 'bf_Head_Hex',
    'bf_Bit_Type': 'bf_Bit_None',
    'bf_Nut_Type': 'bf_Nut_Hex',
    'bf_Major_Dia': 12,
    'bf_Pitch': 1.5,
    'bf_Rounded_Root_Dia': 10.16,
    'bf_Minor_Dia': 10.376,
    'bf_Shank_Dia': 12,
    'bf_Shank_Length': 33,
    'bf_Thread_Length': 32,
    'bf_Crest_Percent': 12.5,
    'bf_Root_Percent': 25,
    'bf_Div_Count': 36,
    'bf_Allen_Bit_Depth': 6.0,
    'bf_Allen_Bit_Flat_Distance': 10,
    'bf_Torx_Bit_Depth': 6.0,
    'bf_Torx_Size_Type': 'bf_Torx_T55',
    'bf_Philips_Bit_Dia': 7.800000000000001,
    'bf_Phillips_Bit_Depth': 4.89922953,
    'bf_Hex_Head_Height': 7.5,
    'bf_Hex_Head_Flat_Distance': 19,
    'bf_12_Point_Head_Height': 12,
    'bf_12_Point_Head_Flat_Distance': 12,
    'bf_12_Point_Head_Flange_Dia': 18.27,
    'bf_CounterSink_Head_Dia': 22,
    'bf_CounterSink_Head_Angle': 1.5708,
    'bf_Cap_Head_Height': 12,
    'bf_Cap_Head_Dia': 18.5,
    'bf_Dome_Head_Dia': 24,
    'bf_Pan_Head_Dia': 24,
    'bf_Hex_Nut_Height': 10,
    'bf_Hex_Nut_Flat_Distance': 19,
    'bf_12_Point_Nut_Height': 12.8,
    'bf_12_Point_Nut_Flat_Distance': 14,
    'bf_12_Point_Nut_Flange_Dia': 20.9,
}
operator = context.active_operator
for field, setting in parameters.items():
    setattr(operator, field, setting)
