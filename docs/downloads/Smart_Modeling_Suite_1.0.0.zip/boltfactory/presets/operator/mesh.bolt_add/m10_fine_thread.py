# SPDX-License-Identifier: GPL-3.0-or-later
"""Set the metric dimensions in Blender’s active fastener operator."""

from bpy import context

parameters = {
    'bf_Model_Type': 'bf_Model_Bolt',
    'bf_Head_Type': 'bf_Head_Hex',
    'bf_Bit_Type': 'bf_Bit_None',
    'bf_Nut_Type': 'bf_Nut_Hex',
    'bf_Major_Dia': 10,
    'bf_Pitch': 1.25,
    'bf_Rounded_Root_Dia': 8.466,
    'bf_Minor_Dia': 8.647,
    'bf_Shank_Dia': 10,
    'bf_Shank_Length': 0,
    'bf_Thread_Length': 20,
    'bf_Crest_Percent': 12.5,
    'bf_Root_Percent': 25,
    'bf_Div_Count': 36,
    'bf_Allen_Bit_Depth': 5.0,
    'bf_Allen_Bit_Flat_Distance': 8,
    'bf_Torx_Bit_Depth': 5.0,
    'bf_Torx_Size_Type': 'bf_Torx_T50',
    'bf_Philips_Bit_Dia': 6.5,
    'bf_Phillips_Bit_Depth': 4.082691275,
    'bf_Hex_Head_Height': 6.4,
    'bf_Hex_Head_Flat_Distance': 17,
    'bf_12_Point_Head_Height': 10,
    'bf_12_Point_Head_Flat_Distance': 10,
    'bf_12_Point_Head_Flange_Dia': 16.27,
    'bf_CounterSink_Head_Dia': 20,
    'bf_CounterSink_Head_Angle': 1.5708,
    'bf_Cap_Head_Height': 10,
    'bf_Cap_Head_Dia': 16,
    'bf_Dome_Head_Dia': 20,
    'bf_Pan_Head_Dia': 20,
    'bf_Hex_Nut_Height': 8,
    'bf_Hex_Nut_Flat_Distance': 17,
    'bf_12_Point_Nut_Height': 10.2,
    'bf_12_Point_Nut_Flat_Distance': 12,
    'bf_12_Point_Nut_Flange_Dia': 17.8,
}
operator = context.active_operator
for field, setting in parameters.items():
    setattr(operator, field, setting)
