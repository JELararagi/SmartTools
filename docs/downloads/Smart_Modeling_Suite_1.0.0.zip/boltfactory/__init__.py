"""
Boltfactory Extension registration file
"""

import os

if "bpy" not in locals():
    import bpy
    from . import boltfactory
    from . import create_mesh
else:
    import importlib
    importlib.reload(boltfactory)
    importlib.reload(create_mesh)


def register():
    """Register Boltfactory in Blender"""

    boltfactory.register()

    # Install Presets
    preset_path = os.path.join(os.path.dirname(__file__))
    unregister_preset_path = getattr(bpy.utils, "unregister_preset_path", None)
    preset_registry = getattr(bpy.utils, "_preset_path_registry", ())
    if callable(unregister_preset_path) and preset_path in preset_registry:
        try:
            unregister_preset_path(preset_path)
        except Exception:
            pass
    if register_preset_path := getattr(bpy.utils, "register_preset_path", None):
        register_preset_path(preset_path)


def unregister():
    """Un-Register Boltfactory in Blender"""

    # Remove Presets
    if unregister_preset_path := getattr(bpy.utils, "unregister_preset_path", None):
        unregister_preset_path(os.path.join(os.path.dirname(__file__)))

    boltfactory.unregister()


if __name__ == "__main__":
    register()
