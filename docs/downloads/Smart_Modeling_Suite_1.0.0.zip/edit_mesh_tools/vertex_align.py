bl_info = {
    "name": "Vertex Align",
    "author": "",
    "version": (0, 1, 7),
    "blender": (2, 61, 0),
    "location": "View3D > Tool Shelf",
    "description": "",
    "warning": "",
    "doc_url": "",
    "category": "Mesh",
}


import bmesh
import bpy
from bpy.props import (
        BoolProperty,
        BoolVectorProperty,
        FloatVectorProperty,
        PointerProperty,
        )
from mathutils import Vector
from bpy.types import Operator, PropertyGroup

from .. import language as _language


_TRANSLATIONS = {
    "Active Vertex": "アクティブ頂点",
    "Align to original": "保存頂点へ整列",
    "Align to custom coordinates": "カスタム座標へ整列",
    "Tweak custom coordinates": '指定の座標を微調整',
    "Use Stored Coordinates": '記録した座標を使う',
    "Stored Coordinates": '記録した座標',
    "Coordinates": "座標",
    "Axis": "軸",
    "Using Stored Coordinates": '記録した座標を使用中',
    "Please select exactly one vertex": "頂点を1つだけ選択してください",
    "Selected vertex coordinates are stored": "選択頂点の座標を保存しました",
    "No stored vertex coordinates. Operation cancelled": "保存済みの頂点座標がないため、処理を取り消しました",
    "No vertices selected. Operation cancelled": "頂点が選択されていないため、処理を取り消しました",
}
for _en, _ja in _TRANSLATIONS.items():
    _language.register_translation(_en, _ja)


def _ui_text(value, context=None):
    return _language.ui_text(value, context=context)


_SCENE_POINTER_NAME = "mesh_extra_tools"


class VertexAlignSettings(PropertyGroup):
    """Persistent settings used by the Edit Mesh Tools vertex-align popup."""

    vert_align_axis: BoolVectorProperty(
        name="Axis",
        description=(
            "Choose which coordinate axes are changed when aligning the selected "
            "vertices to the stored active vertex"
        ),
        default=(True, True, True),
        size=3,
    )
    vert_align_use_stored: BoolProperty(
        name="Use Stored Coordinates",
        description=(
            "Initialize the custom-coordinate popup with the coordinate stored by "
            "Active Vertex"
        ),
        default=False,
    )
    vert_align_store_axis: FloatVectorProperty(
        name="Stored Coordinates",
        description="Coordinates saved by Active Vertex for later alignment",
        default=(0.0, 0.0, 0.0),
        size=3,
        subtype='XYZ',
        precision=4,
    )


def _edit_bmesh(context):
    obj = getattr(context, "active_object", None)
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, None
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    return obj, bm


def _selected_vertex_indices(context):
    _obj, bm = _edit_bmesh(context)
    if bm is None:
        return []
    return [vert.index for vert in bm.verts if vert.select]


class va_buf:
    # The indices are only a short-lived popup selection snapshot.  Persistent
    # coordinates live in Scene.mesh_extra_tools and are restored by the suite's
    # canonical JSON persistence layer.
    list_0 = []


class Vertex_align_store(Operator):
    bl_idname = "vertex_align.store_id"
    bl_label = "Active Vertex"
    bl_options = {'UNDO'}
    bl_description = (
        "Store the selected vertex coordinate as the alignment target. "
        "Select exactly one vertex before using this command"
    )

    @classmethod
    def poll(cls, context):
        return bool(
            context.active_object
            and context.active_object.type == 'MESH'
            and context.mode == 'EDIT_MESH'
        )

    def execute(self, context):
        obj, bm = _edit_bmesh(context)
        selected = [vert for vert in bm.verts if vert.select] if bm else []
        if len(selected) != 1:
            self.report({'WARNING'}, _ui_text("Please select exactly one vertex", context))
            return {'CANCELLED'}

        settings = context.scene.mesh_extra_tools
        settings.vert_align_store_axis = tuple(selected[0].co)
        settings.vert_align_use_stored = True

        # Preserve the original tool behavior: after storing the target, clear
        # the selection so the user can choose the vertices to align.
        for vert in bm.verts:
            vert.select = False
        bm.select_history.clear()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, _ui_text("Selected vertex coordinates are stored", context))
        return {'FINISHED'}


class Vertex_align_original(Operator):
    bl_idname = "vertex_align.align_original"
    bl_label = "Align to original"
    bl_description = "Align selected vertices to the coordinates stored by Active Vertex"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(
            context.active_object
            and context.active_object.type == 'MESH'
            and context.mode == 'EDIT_MESH'
        )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Axis:")
        row = layout.row(align=True)
        settings = context.scene.mesh_extra_tools
        row.prop(settings, "vert_align_axis", text="X", index=0, toggle=True)
        row.prop(settings, "vert_align_axis", text="Y", index=1, toggle=True)
        row.prop(settings, "vert_align_axis", text="Z", index=2, toggle=True)

    def execute(self, context):
        obj, bm = _edit_bmesh(context)
        if bm is None:
            return {'CANCELLED'}
        settings = context.scene.mesh_extra_tools
        if not settings.vert_align_use_stored:
            self.report({'INFO'}, _ui_text("No stored vertex coordinates. Operation cancelled", context))
            return {'CANCELLED'}
        selected = [vert for vert in bm.verts if vert.select]
        if not selected:
            self.report({'INFO'}, _ui_text("No vertices selected. Operation cancelled", context))
            return {'CANCELLED'}

        target = settings.vert_align_store_axis
        axes = settings.vert_align_axis
        changed = False
        for vert in selected:
            co = vert.co.copy()
            for axis in range(3):
                if axes[axis] and abs(co[axis] - target[axis]) > 1.0e-12:
                    co[axis] = target[axis]
                    changed = True
            vert.co = co
        if not changed:
            return {'CANCELLED'}
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}


class Vertex_align_coord_list(Operator):
    bl_idname = "vertex_align.coord_list_id"
    bl_label = "Align to custom coordinates"
    bl_description = (
        "Open the custom-coordinate popup and align the currently selected vertices "
        "on the enabled axes"
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return bool(
            context.active_object
            and context.active_object.type == 'MESH'
            and context.mode == 'EDIT_MESH'
        )

    def _open_popup(self, context):
        va_buf.list_0 = _selected_vertex_indices(context)
        if not va_buf.list_0:
            self.report({'INFO'}, _ui_text("No vertices selected. Operation cancelled", context))
            return {'CANCELLED'}
        result = bpy.ops.vertex_align.coord_menu_id('INVOKE_DEFAULT')
        return {'FINISHED'} if 'RUNNING_MODAL' in result else result

    def invoke(self, context, event):
        return self._open_popup(context)

    def execute(self, context):
        return self._open_popup(context)


class Vertex_align_coord_menu(Operator):
    bl_idname = "vertex_align.coord_menu_id"
    bl_label = "Tweak custom coordinates"
    bl_description = "Change the custom coordinates used to align selected vertices"
    bl_options = {'UNDO'}

    def_axis_coord: FloatVectorProperty(
        name="Coordinates",
        description="Coordinates assigned on the enabled axes",
        default=(0.0, 0.0, 0.0),
        min=-1000000.0,
        max=1000000.0,
        step=1,
        size=3,
        subtype='XYZ',
        precision=4,
    )
    use_axis_coord: BoolVectorProperty(
        name="Axis",
        description="Choose the coordinate axes that are changed",
        default=(False, False, False),
        size=3,
    )

    @classmethod
    def poll(cls, context):
        return bool(
            context.active_object
            and context.active_object.type == 'MESH'
            and context.mode == 'EDIT_MESH'
        )

    def draw(self, context):
        layout = self.layout
        if context.scene.mesh_extra_tools.vert_align_use_stored:
            layout.label(text="Using Stored Coordinates")
        for index, label in enumerate("XYZ"):
            row = layout.row(align=True)
            row.prop(self, "use_axis_coord", index=index, text=label, toggle=True)
            row.prop(self, "def_axis_coord", index=index, text="")

    def invoke(self, context, event):
        if not va_buf.list_0:
            va_buf.list_0 = _selected_vertex_indices(context)
        if not va_buf.list_0:
            self.report({'INFO'}, _ui_text("No vertices selected. Operation cancelled", context))
            return {'CANCELLED'}
        settings = context.scene.mesh_extra_tools
        if settings.vert_align_use_stored:
            self.def_axis_coord = settings.vert_align_store_axis
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        obj, bm = _edit_bmesh(context)
        if bm is None:
            return {'CANCELLED'}
        bm.verts.ensure_lookup_table()
        valid = [index for index in va_buf.list_0 if 0 <= index < len(bm.verts)]
        axes = tuple(bool(value) for value in self.use_axis_coord)
        if not valid or not any(axes):
            return {'CANCELLED'}

        changed = False
        for index in valid:
            vert = bm.verts[index]
            co = vert.co.copy()
            for axis in range(3):
                if axes[axis] and abs(co[axis] - self.def_axis_coord[axis]) > 1.0e-12:
                    co[axis] = self.def_axis_coord[axis]
                    changed = True
            vert.co = co
        if not changed:
            return {'CANCELLED'}
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}


#  Register
classes = (
    VertexAlignSettings,
    Vertex_align_store,
    Vertex_align_original,
    Vertex_align_coord_list,
    Vertex_align_coord_menu,
)


def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass
    if not hasattr(bpy.types.Scene, _SCENE_POINTER_NAME):
        setattr(
            bpy.types.Scene,
            _SCENE_POINTER_NAME,
            PointerProperty(type=VertexAlignSettings),
        )


def unregister():
    if hasattr(bpy.types.Scene, _SCENE_POINTER_NAME):
        try:
            delattr(bpy.types.Scene, _SCENE_POINTER_NAME)
        except Exception:
            pass
    va_buf.list_0.clear()
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
