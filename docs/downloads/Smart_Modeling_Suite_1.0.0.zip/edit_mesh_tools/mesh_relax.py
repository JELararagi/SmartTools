"""Redistribute selected surface vertices while keeping them on the input surface."""

import bmesh
import bpy
from bpy.props import IntProperty
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def _relax_selected(context, iterations):
    for obj in context.objects_in_mode_unique_data:
        mesh = obj.data
        editable = bmesh.from_edit_mesh(mesh)
        movable = [v for v in editable.verts if v.select and not v.hide and v.is_manifold and not v.is_boundary]
        if not movable or not iterations:
            continue
        # Restrict projection to the vertex's own incident faces. Nearby
        # overlapping pieces must never attract vertices across the gap.
        editable.verts.index_update()
        points = [v.co.copy() for v in editable.verts]
        surfaces = {}
        for vertex in movable:
            faces = [tuple(v.index for v in face.verts) for face in vertex.link_faces]
            local = sorted({i for face in faces for i in face})
            remap = {idx: n for n, idx in enumerate(local)}
            surfaces[vertex] = BVHTree.FromPolygons(
                [points[i] for i in local],
                [tuple(remap[i] for i in face) for face in faces],
            )
        for _ in range(iterations):
            updates = {}
            for v in movable:
                neighbors = [edge.other_vert(v).co for edge in v.link_edges]
                center = sum(neighbors, Vector((0, 0, 0))) / len(neighbors)
                hit, _, _, _ = surfaces[v].find_nearest(v.co.lerp(center, 0.5))
                if hit is not None:
                    updates[v] = hit
            for v, co in updates.items():
                v.co = co
        bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=False)


def relax_mesh(context):
    """Run one surface-relaxation step in mesh edit mode."""
    _relax_selected(context, 1)


class Relax(bpy.types.Operator):
    bl_idname = "mesh.relax"
    bl_label = "Relax"
    bl_description = "Relax selected vertices along the mesh surface"
    bl_options = {"UNDO"}

    iterations: IntProperty(name="Relax iterations", default=1, min=0, max=100, soft_max=10)

    @classmethod
    def poll(cls, context):
        return context.mode == "EDIT_MESH"

    def execute(self, context):
        _relax_selected(context, self.iterations)
        return {"FINISHED"}


def menu_func(menu, context):
    menu.layout.operator(Relax.bl_idname)


def register():
    bpy.utils.register_class(Relax)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_func)
    bpy.types.VIEW3D_MT_edit_mesh_vertices.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_edit_mesh_vertices.remove(menu_func)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_func)
    bpy.utils.unregister_class(Relax)
