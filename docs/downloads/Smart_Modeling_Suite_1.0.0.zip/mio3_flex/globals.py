# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Give flexible mesh tools the suite's contextual preference provider."""

import bpy

from .. import preferences as suite_preferences

preferences = suite_preferences


def get_preference_idname():
    return __package__


def get_preferences(context=None):
    try:
        from .preferences import PREFERENCE_mio3me as fallback
    except (ImportError, AttributeError, RuntimeError):
        fallback = None
    active_context = context if context is not None else bpy.context
    return suite_preferences.get_preferences(active_context, get_preference_idname(), fallback)


def get_preference(name):
    return getattr(get_preferences(), name, None)
