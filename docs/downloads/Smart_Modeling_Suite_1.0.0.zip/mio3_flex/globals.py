import bpy
from .. import preferences


def get_preference_idname():
    return __package__


def get_preferences(context=None):
    try:
        from .preferences import PREFERENCE_mio3me
    except Exception:
        PREFERENCE_mio3me = None
    return preferences.get_preferences(context or bpy.context, __package__, PREFERENCE_mio3me)


def get_preference(name):
    return getattr(get_preferences(), name, None)
