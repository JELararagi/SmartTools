import bpy

translation_dict = {
    "ja_JP": {
        ("*", "Path Deform"): "パスで変形",
        ("Operator", "Path Deform"): "パスで変形",
        ("Operator", "Quick"): 'クイック',
        ("*", "Deforms an edge loop with a curve"): "カーブでエッジループを変形します",
        ("*", "Omit the option for instant transformation"): "オプションを省略して即時変形します",
        ("*", "Control Points"): "制御点",
        ("*", "Confirmed"): "確定しました",
        ("*", "Auto Density"): "密度を自動調整",
        ("*", "Automatically adjust control point distribution based on edge density"): "エッジの密度に基づいて制御点の分布を自動的に調整します",
        ("*", "Original Edge"): "元のエッジ",
        ("*", "Show Original Edge"): "元のエッジを表示",
        ("*", "Display the original edge loop for reference"): "参照のために元のエッジループを表示します",
        ("*", "Right Click Action"): "右クリックの操作",
        ("*", "Choose the action for the right mouse button"): "右マウスボタンの操作を選択します",
        ("*", "Use right mouse button to confirm actions"): "右クリックで操作を確定します",
        ("*", "Use right mouse button to cancel actions"): "右クリックで操作をキャンセルします",

        ("*", "No valid edge loops found. Select at least 3 connected edges."): "有効なエッジループが見つかりません。少なくとも3つの連続したエッジを選択してください。",

        # GPU GUI
        ("*", "🐻Tips"): "🐻Tips",
        ("*", "[Click] Confirm"): '[クリック] 確定',
        ("*", "[Shift+Wheel] [Alt+Wheel] Control Points [Ctrl+Click] Add or Delete"): '[Shift+ホイール] [Alt+ホイール] 制御点の数 [Ctrl+クリック] 追加または削除',
        ("*", "[R] Reset Deform [M] Mirror Toggle [H] Hide Path [↑↓] Roundness"): '[R] 変形をリセット [M] ミラーの切り替え [H] パスを隠す [↑↓] 丸み',
    }
}  # fmt: skip


def register():
    try:
        bpy.app.translations.register(__package__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__package__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__package__, translation_dict)
        except Exception:
            pass


def unregister():
    try:
        bpy.app.translations.unregister(__package__)
    except Exception:
        pass
