from . import preferences
from . import translation
from . import main_ui
from .globals import get_preferences
from .modules import curve_edges


module_list = [
    preferences,
    translation,
    curve_edges,
    main_ui,
]


def register():
    for module in module_list:
        module.register()
    # Create the RNA settings before the options popover can draw.
    get_preferences()


def unregister():
    for module in reversed(module_list):
        module.unregister()
