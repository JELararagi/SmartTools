import bpy.types
import math
from ..utils.pref_utils import get_keyops_prefs, get_icon
from .persistence_bridge import persistent_property

_PersistBoolProperty = persistent_property(bpy.props.BoolProperty)
_PersistIntProperty = persistent_property(bpy.props.IntProperty)
_PersistFloatProperty = persistent_property(bpy.props.FloatProperty)
_PersistStringProperty = persistent_property(bpy.props.StringProperty)

prefs = get_keyops_prefs()

_DELETE_SMALL_FACES_GROUP_NAME = "Smart Modeling - Delete Small Faces"
_DELETE_SMALL_FACES_GROUP_MARKER = "jelararagi_smart_modeling_delete_small_faces_v1"

# to do:
# add X symmetrize option for decimate modifier - DONE
# orginize menu panel better
# replace delete small face with delete by mesh island
# use split edge node instead of modifer
# place the lods in the current collection?
# add auto smooth angle
# add data transfere for normals - DONE
# fix node group for delete small faces error and update to last version
# Convert Deletesmall Faces/DeleteLooseEdges to function instead
#option for planar decimation

def delete_loose_edge_node_group():
    delete_loose_edge = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Delete Loose Edge")

    delete_loose_edge.is_modifier = True
    
    #initialize delete_loose_edge nodes
    #delete_loose_edge interface
    #Socket Geometry
    geometry_socket = delete_loose_edge.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    
    #Socket Geometry
    geometry_socket_1 = delete_loose_edge.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    
    
    #node Group Input
    group_input = delete_loose_edge.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    
    #node Boolean Math
    boolean_math = delete_loose_edge.nodes.new("FunctionNodeBooleanMath")
    boolean_math.name = "Boolean Math"
    boolean_math.operation = 'NOT'
    #Boolean_001
    boolean_math.inputs[1].default_value = False
    
    #node Delete Geometry
    delete_geometry = delete_loose_edge.nodes.new("GeometryNodeDeleteGeometry")
    delete_geometry.name = "Delete Geometry"
    delete_geometry.domain = 'EDGE'
    delete_geometry.mode = 'ALL'
    
    #node Edge Neighbors
    edge_neighbors = delete_loose_edge.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
    edge_neighbors.name = "Edge Neighbors"
    
    #node Group Output
    group_output = delete_loose_edge.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    
    
    
    
    #Set locations
    group_input.location = (-340.0, 0.0)
    boolean_math.location = (-203.79037475585938, -102.6886215209961)
    delete_geometry.location = (-35.70556640625, 64.91195678710938)
    edge_neighbors.location = (-388.9553527832031, -148.6557159423828)
    group_output.location = (166.10665893554688, 65.12358093261719)
    
    #Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    boolean_math.width, boolean_math.height = 140.0, 100.0
    delete_geometry.width, delete_geometry.height = 140.0, 100.0
    edge_neighbors.width, edge_neighbors.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    
    #initialize delete_loose_edge links
    #group_input.Geometry -> delete_geometry.Geometry
    delete_loose_edge.links.new(group_input.outputs[0], delete_geometry.inputs[0])
    #delete_geometry.Geometry -> group_output.Geometry
    delete_loose_edge.links.new(delete_geometry.outputs[0], group_output.inputs[0])
    #boolean_math.Boolean -> delete_geometry.Selection
    delete_loose_edge.links.new(boolean_math.outputs[0], delete_geometry.inputs[1])
    #edge_neighbors.Face Count -> boolean_math.Boolean
    delete_loose_edge.links.new(edge_neighbors.outputs[0], boolean_math.inputs[0])
    return delete_loose_edge


def _ensure_delete_small_faces_node_group():
    group = next(
        (
            item
            for item in bpy.data.node_groups
            if bool(item.get(_DELETE_SMALL_FACES_GROUP_MARKER, False))
        ),
        None,
    )
    if group is None:
        group = bpy.data.node_groups.get(_DELETE_SMALL_FACES_GROUP_NAME)
    if group is not None:
        threshold = next((item for item in group.interface.items_tree if getattr(item, "item_type", "") == "SOCKET" and getattr(item, "in_out", "") == "INPUT" and getattr(item, "name", "") == "Maximum Face Area"), None)
        if threshold is not None:
            return group, threshold.identifier
        # Never destructively replace an unknown user node group.  A group
        # created by this tool can be rebuilt safely; otherwise create a
        # unique Smart Modeling group below.
        if bool(group.get(_DELETE_SMALL_FACES_GROUP_MARKER, False)) and group.users == 0:
            bpy.data.node_groups.remove(group)
            group = None

    if group is not None:
        group = None

    group = bpy.data.node_groups.new(type='GeometryNodeTree', name=_DELETE_SMALL_FACES_GROUP_NAME)
    group[_DELETE_SMALL_FACES_GROUP_MARKER] = True
    group.is_modifier = True
    out_socket = group.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    in_socket = group.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    threshold = group.interface.new_socket(name="Maximum Face Area", in_out='INPUT', socket_type='NodeSocketFloat')
    threshold.default_value = 0.0005
    threshold.min_value = 0.0

    group_in = group.nodes.new("NodeGroupInput")
    group_out = group.nodes.new("NodeGroupOutput")
    group_out.is_active_output = True
    face_area = group.nodes.new("GeometryNodeInputMeshFaceArea")
    compare = group.nodes.new("FunctionNodeCompare")
    compare.data_type = 'FLOAT'
    compare.operation = 'LESS_THAN'
    delete = group.nodes.new("GeometryNodeDeleteGeometry")
    delete.domain = 'FACE'
    delete.mode = 'ALL'

    group.links.new(group_in.outputs[in_socket.identifier], delete.inputs['Geometry'])
    group.links.new(face_area.outputs['Area'], compare.inputs['A'])
    group.links.new(group_in.outputs[threshold.identifier], compare.inputs['B'])
    group.links.new(compare.outputs['Result'], delete.inputs['Selection'])
    group.links.new(delete.outputs['Geometry'], group_out.inputs[out_socket.identifier])
    return group, threshold.identifier


def _set_nodes_modifier_input(modifier, socket_identifier: str, value) -> bool:
    """Assign a Geometry Nodes modifier input using its interface identifier."""
    try:
        modifier[socket_identifier] = value
        try:
            modifier[f"{socket_identifier}_use_attribute"] = False
        except Exception:
            pass
        return True
    except Exception:
        return False


def _move_modifier_to_index(obj, modifier, target_index: int) -> None:
    try:
        current_index = list(obj.modifiers).index(modifier)
        target_index = max(0, min(int(target_index), len(obj.modifiers) - 1))
        if current_index != target_index:
            obj.modifiers.move(current_index, target_index)
    except Exception:
        pass


def _apply_modifier_to_object(context, obj, modifier_name: str) -> bool:
    modifier = obj.modifiers.get(modifier_name)
    if modifier is None:
        return False
    view_layer = context.view_layer
    previous_active = view_layer.objects.active
    previous_selected = tuple(context.selected_objects)
    try:
        for item in previous_selected:
            try:
                item.select_set(False)
            except Exception:
                pass
        obj.select_set(True)
        view_layer.objects.active = obj
        with context.temp_override(
            object=obj,
            active_object=obj,
            selected_objects=[obj],
            selected_editable_objects=[obj],
        ):
            if not bpy.ops.object.modifier_apply.poll():
                return False
            return 'FINISHED' in set(bpy.ops.object.modifier_apply(modifier=modifier.name) or set())
    finally:
        try:
            obj.select_set(False)
        except Exception:
            pass
        for item in previous_selected:
            try:
                item.select_set(True)
            except Exception:
                pass
        try:
            view_layer.objects.active = previous_active
        except Exception:
            pass

class AutoLODProperties(bpy.types.PropertyGroup):
    suffix: _PersistStringProperty(default="_LOD")  # type: ignore
    iterativ_lod_suffix: _PersistBoolProperty(default=True)  # type: ignore
    lod_parent_object: _PersistBoolProperty(default=False)  # type: ignore
    apply_decimate_modifier: _PersistBoolProperty(default=False)  # type: ignore
    amount_of_lods: _PersistIntProperty(default=3, min=1)  # type: ignore
    lod_difference: _PersistFloatProperty(default=45.0, min=0.0, max=100.0)  # type: ignore
    unlock_normals_on_all_lods: _PersistBoolProperty(default=False)  # type: ignore
    edge_split: _PersistBoolProperty(default=False)  # type: ignore
    edge_split_angle: _PersistFloatProperty(default=60.0)  # type: ignore
    max_face_size: _PersistFloatProperty(default=0.0005)  # type: ignore
    remove_non_manifold_faces: _PersistBoolProperty(default=False)  # type: ignore
    multipler: _PersistFloatProperty(default=2.0)  # type: ignore
    delete_loose_edges: _PersistBoolProperty(default=True)  # type: ignore
    keep_symmetry_X: _PersistBoolProperty(default=False)  # type: ignore
    transfere_normals: _PersistBoolProperty(default=True)  # type: ignore
    transfere_edge_normals: _PersistBoolProperty(default=True)  # type: ignore
    create_collection: _PersistBoolProperty(default=False)  # type: ignore
    add_weighted_normals: _PersistBoolProperty(default=True)  # type: ignore


class AutoLOD(bpy.types.Operator):
    bl_idname = "keyops.auto_lod"
    bl_label = "Auto LOD"
    bl_description = "Auto LOD"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        props = context.scene.auto_lod_props
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        suffix = props.suffix
        parent_object = props.lod_parent_object
        apply_decimate_modifier = props.apply_decimate_modifier
        amount_of_lods = props.amount_of_lods
        lod_difference = props.lod_difference / 100.0
        edge_split = props.edge_split
        max_face_size = props.max_face_size
        remove_non_manifold_faces = props.remove_non_manifold_faces
        multipler = props.multipler
        transfere_normals = props.transfere_normals
        transfere_edge_normals = props.transfere_edge_normals
        create_collection = props.create_collection
        add_weighted_normals = props.add_weighted_normals

        if not selected_objects:
            self.report({'WARNING'}, "Select at least one mesh object")
            return {'CANCELLED'}

        total_steps = len(selected_objects) * amount_of_lods
        current_step = 0

        # Begin progress bar
        wm = bpy.context.window_manager
        wm.progress_begin(0, total_steps)

        orginal_objects = selected_objects.copy()

        if props.iterativ_lod_suffix:
            for obj in orginal_objects:
                if "_LOD_" in obj.name:
                    obj.name = obj.name[:-13]
                obj["LOD"] = str(0)
 

        if props.delete_loose_edges:
            if bpy.data.node_groups.get("Delete Loose Edge") is None:
                delete_loose_edge_node_group()

        for obj in selected_objects:
            for i in range(amount_of_lods):
                # Update progress cursor
                wm.progress_update(current_step)

                new_object = obj.copy()
                new_object.data = obj.data.copy()

                if not props.iterativ_lod_suffix:
                    lod_name = f"{obj.name}{suffix}{(i + 1)}"
                else:
                    start_prefix = "_LOD_"
                    underscore = "_"

                    lod_name = f"{obj.name}{start_prefix}{underscore * (i + 1)}{i + 1}{underscore * (6 - i)}"
                    new_object["LOD"] = str(i + 1)

                new_object.name = lod_name

                if obj.type == 'MESH':
                    bpy.context.collection.objects.link(new_object)
                    bpy.context.view_layer.objects.active = new_object

                    if edge_split:
                        split_edge_modifier = new_object.modifiers.new(name="EDGE_SPLIT", type="EDGE_SPLIT")
                        split_edge_modifier.show_in_editmode = False
                        split_angle_degrees = props.edge_split_angle
                        split_angle_radians = math.radians(split_angle_degrees)
                        split_edge_modifier.split_angle = split_angle_radians
                        _move_modifier_to_index(new_object, split_edge_modifier, 0)

                    decimate_modifier = new_object.modifiers.new(name="Decimate", type='DECIMATE')
                    decimate_modifier.ratio = (1 - lod_difference) ** (i + 1)
                    if props.keep_symmetry_X:
                        decimate_modifier.use_symmetry = True
                    _move_modifier_to_index(new_object, decimate_modifier, 1 if edge_split else 0)

                    if props.unlock_normals_on_all_lods:
                        bpy.ops.mesh.customdata_custom_splitnormals_clear()

                    if apply_decimate_modifier:
                        if edge_split and not _apply_modifier_to_object(context, new_object, "EDGE_SPLIT"):
                            self.report({'WARNING'}, f"Unable to apply EDGE_SPLIT on {new_object.name}")
                        if not _apply_modifier_to_object(context, new_object, "Decimate"):
                            self.report({'WARNING'}, f"Unable to apply Decimate on {new_object.name}")
                        context.view_layer.objects.active = new_object

                    if parent_object:
                        new_object.parent = obj
                        new_object.matrix_parent_inverse = obj.matrix_world.inverted()

                    bpy.context.view_layer.objects.active = new_object

                    if props.delete_loose_edges:
                        modifier = new_object.modifiers.get("Delete Loose Edge")
                        if modifier is None:
                            modifier = new_object.modifiers.new('Delete Loose Edge', 'NODES')
                        modifier.node_group = bpy.data.node_groups['Delete Loose Edge']

                    if remove_non_manifold_faces:
                        node_group, threshold_identifier = _ensure_delete_small_faces_node_group()
                        modifier = new_object.modifiers.get("Delete Small Faces")
                        if modifier is None:
                            modifier = new_object.modifiers.new("Delete Small Faces", 'NODES')
                        modifier.node_group = node_group
                        if not _set_nodes_modifier_input(
                            modifier,
                            threshold_identifier,
                            float(max_face_size) * (float(multipler) ** i),
                        ):
                            self.report({'WARNING'}, f"Unable to set small-face threshold on {new_object.name}")

                    if transfere_normals or transfere_edge_normals:
                        mod = new_object.modifiers.new(type='DATA_TRANSFER', name='Transfere_Normals')
                        mod.object = obj
                        mod.use_object_transform = False

                    if transfere_edge_normals:
                        mod.data_types_edges = {'SHARP_EDGE'}

                    if transfere_normals:
                        mod.data_types_loops = {'CUSTOM_NORMAL'}

                    if add_weighted_normals:
                        mod = new_object.modifiers.new(type='WEIGHTED_NORMAL', name='Weighted Normals')
                        mod.keep_sharp = True

                    current_step += 1

        # End progress bar

        # Rename the original objects with the suffix
        for obj in orginal_objects:
            if obj.type == 'MESH':
                if props.iterativ_lod_suffix:
                    obj.name = obj.name + "_LOD_0_______"
                else:
                    obj.name = f"{obj.name}{suffix}0"

        # create collections for each orginal object and name them the same name as the orginal object - suffix
        if create_collection:
            for obj in orginal_objects:
                # remove the suffix from the name to get the collection name without suffix
                collection_name = obj.name[:-len(suffix)]
                collection = bpy.data.collections.new(collection_name)
                bpy.context.scene.collection.children.link(collection)
        wm.progress_end()

        return {'FINISHED'}
    def register():
        bpy.utils.register_class(AutoLODProperties)
        bpy.utils.register_class(GenerateLODPanel)
        bpy.types.Scene.auto_lod_props = bpy.props.PointerProperty(type=AutoLODProperties)

    def unregister():
        try:
            del bpy.types.Scene.auto_lod_props
        except Exception:
            pass
        for cls in (GenerateLODPanel, AutoLODProperties):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass


class GenerateLODPanel(bpy.types.Panel):
    bl_idname = "OBJECT_PT_generate_lod"
    bl_label = "Generate LOD"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_options = {'DEFAULT_CLOSED'}
    # bl_parent_id = "KEYOPS_PT_toolkit_panel"

    @classmethod
    def poll(cls, context):
        if context.mode == "OBJECT":
            return True

    def draw_header(self, context):
        layout = self.layout
        layout.label(text="", icon="MESH_ICOSPHERE")

    def draw(self, context):
        layout = self.layout    
        box = layout.box()
        props = context.scene.auto_lod_props

        row = box.row()
        if not props.iterativ_lod_suffix:
            row.prop(props, "suffix")
            row.prop(props, "iterativ_lod_suffix", text="Auto")
        else:
            row.alignment = 'LEFT'
            row.label(text="suffix:")
            row.prop(props, "iterativ_lod_suffix", text="Auto")
        row = box.row(align=True)
        row.prop(props, "lod_parent_object", text="Parent")

        row.prop(props, "keep_symmetry_X", text="Symmetry")

        row = box.row()
        row.label(text="Transfere Normals:")
        row = box.row(align=True)
        row.prop(props, "transfere_normals", text="Face Normals", toggle=True)
        row.prop(props, "transfere_edge_normals", text="Edge Normals", toggle=True)

        row = box.row()
        row.prop(props, "add_weighted_normals", text="Weighted Normals")

        row = box.row()
        row.prop(props, "unlock_normals_on_all_lods", text="Unlock Normals")

        row = box.row()
        row.prop(props, "amount_of_lods", text="Amount of LODs")

        row = box.row()
        row.prop(props, "lod_difference", text="LOD Difference %")

        row = box.row()
        row.scale_y = 1.4
        row.operator("keyops.auto_lod", text="Generate LODs", icon='MESH_ICOSPHERE')
