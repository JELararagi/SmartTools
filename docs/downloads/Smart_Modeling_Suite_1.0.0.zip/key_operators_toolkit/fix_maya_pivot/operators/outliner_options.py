import bpy
from bpy.app.handlers import persistent
from .persistence_bridge import compose_update

previous_selected_objects = []
clicked_in_outliner = False


def _addon_keyconfig():
    wm = getattr(bpy.context, 'window_manager', None)
    keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    return getattr(keyconfigs, 'addon', None)


def _iter_outliner_keymap_items():
    kc = _addon_keyconfig()
    if kc is None:
        return []
    result = []
    for km in kc.keymaps:
        if km.name != 'Outliner':
            continue
        for kmi in km.keymap_items:
            if getattr(kmi, 'idname', '') == 'keyops.outliner_click':
                result.append((km, kmi))
    return result


def _outliner_keymap_registered() -> bool:
    return bool(_iter_outliner_keymap_items())


def register_outliner_click_keymap(register=True):
    # Manual-only policy: do not create Outliner mouse/key shortcuts
    # automatically.  The operator ID is exposed for manual registration.
    if not register:
        unregister_outliner_click_keymap()
    return None, None

def unregister_outliner_click_keymap():
    for km, kmi in reversed(_iter_outliner_keymap_items()):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    kc = _addon_keyconfig()
    if kc is None:
        return
    for km in list(kc.keymaps):
        try:
            if km.name == 'Outliner' and len(km.keymap_items) == 0:
                kc.keymaps.remove(km)
        except Exception:
            pass


def _append_handler_once(handler_list, handler):
    for fn in tuple(handler_list):
        if fn is handler or (
            getattr(fn, '__name__', '') == getattr(handler, '__name__', '')
            and getattr(fn, '__module__', '') == getattr(handler, '__module__', '')
        ):
            return
    try:
        handler_list.append(handler)
    except Exception:
        pass


def _remove_handler(handler_list, handler):
    for fn in tuple(handler_list):
        if fn is handler or (
            getattr(fn, '__name__', '') == getattr(handler, '__name__', '')
            and getattr(fn, '__module__', '') == getattr(handler, '__module__', '')
        ):
            try:
                handler_list.remove(fn)
            except Exception:
                pass


def _scene_option_enabled(scene) -> bool:
    if scene is None:
        return False
    return bool(
        getattr(scene, 'auto_focus_in_outliner', False)
        or getattr(scene, 'select_children', False)
        or getattr(scene, 'close_unselected_collections', False)
    )


@persistent
def register_handler(dummy=None):
    scene = getattr(bpy.context, 'scene', None)
    if scene is None:
        return
    enabled_selection_options(scene, bpy.context)


def selection_option_handler(dummy, depsgraph):
    global previous_selected_objects
    global clicked_in_outliner
    current_selected_objects = bpy.context.selected_objects

    if previous_selected_objects != current_selected_objects:
        previous_selected_objects = current_selected_objects

        if bpy.context.scene.auto_focus_in_outliner or bpy.context.scene.close_unselected_collections:
            if not clicked_in_outliner:
                outliner_areas = [a for a in bpy.context.screen.areas if a.type == 'OUTLINER']
                if not outliner_areas:
                    return
                largest_area = max(outliner_areas, key=lambda a: a.width * a.height)
                largest_region = next(r for r in largest_area.regions if r.type == 'WINDOW')

                override_context = {
                    'area': largest_area,
                    'region': largest_region,
                }

                with bpy.context.temp_override(**override_context):
                    if bpy.context.scene.close_unselected_collections:
                        bpy.ops.outliner.expanded_toggle()
                        bpy.ops.outliner.expanded_toggle()

                    bpy.ops.outliner.show_active()

        def walk_children(ob):
            yield ob
            for child in ob.children:
                yield from walk_children(child)

        if bpy.context.scene.select_children and clicked_in_outliner:
            for obj in current_selected_objects:
                for child in walk_children(obj):
                    child.select_set(True)

    clicked_in_outliner = False


def draw_options_in_outliner(self, context):
    layout = self.layout
    layout.label(text='Selection')
    row = layout.row()
    row.prop(context.scene, 'auto_focus_in_outliner')
    row = layout.row()
    row.prop(context.scene, 'close_unselected_collections')
    row = layout.row()
    row.prop(context.scene, 'select_children')


def enabled_selection_options(self, context):
    scene = self if self is not None else getattr(context, 'scene', None)
    depsgraph_handlers = getattr(bpy.app.handlers, 'depsgraph_update_post', None)
    if depsgraph_handlers is None:
        return

    if _scene_option_enabled(scene):
        _append_handler_once(depsgraph_handlers, selection_option_handler)
        # Do not auto-register Outliner click keymaps.
    else:
        _remove_handler(depsgraph_handlers, selection_option_handler)
        unregister_outliner_click_keymap()


class OutlinerClick(bpy.types.Operator):
    bl_idname = 'keyops.outliner_click'
    bl_label = 'KeyOps: Outliner Click'
    bl_description = ''
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return (
            context.scene.auto_focus_in_outliner
            or context.scene.select_children
            or context.scene.close_unselected_collections
        )

    def invoke(self, context, event):
        global clicked_in_outliner
        clicked_in_outliner = True
        return {'PASS_THROUGH'}


def register():
    try:
        bpy.utils.register_class(OutlinerClick)
    except ValueError:
        pass
    if not hasattr(bpy.types.Scene, 'auto_focus_in_outliner'):
        bpy.types.Scene.auto_focus_in_outliner = bpy.props.BoolProperty(
            name='Auto Select in Outliner',
            description='Automatically focus on the selected objects in the outliner, can be slow with many objects',
            default=False,
            update=compose_update(enabled_selection_options),
        )
    if not hasattr(bpy.types.Scene, 'select_children'):
        bpy.types.Scene.select_children = bpy.props.BoolProperty(
            name='Select Children',
            description='Automatically select children of selected objects',
            default=False,
            update=compose_update(enabled_selection_options),
        )
    if not hasattr(bpy.types.Scene, 'close_unselected_collections'):
        bpy.types.Scene.close_unselected_collections = bpy.props.BoolProperty(
            name='Collapse Unselected Collections',
            description='Automatically collapse collections that are not related to the selected objects',
            default=False,
            update=compose_update(enabled_selection_options),
        )

    try:
        bpy.types.OUTLINER_PT_filter.remove(draw_options_in_outliner)
    except Exception:
        pass
    try:
        bpy.types.OUTLINER_PT_filter.prepend(draw_options_in_outliner)
    except Exception:
        pass

    _append_handler_once(bpy.app.handlers.load_post, register_handler)
    if _scene_option_enabled(getattr(bpy.context, 'scene', None)):
        enabled_selection_options(getattr(bpy.context, 'scene', None), bpy.context)


def unregister():
    try:
        bpy.utils.unregister_class(OutlinerClick)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.depsgraph_update_post, selection_option_handler)
    _remove_handler(bpy.app.handlers.load_post, register_handler)

    for attr_name in ('auto_focus_in_outliner', 'select_children', 'close_unselected_collections'):
        try:
            if hasattr(bpy.types.Scene, attr_name):
                delattr(bpy.types.Scene, attr_name)
        except Exception:
            pass

    try:
        bpy.types.OUTLINER_PT_filter.remove(draw_options_in_outliner)
    except Exception:
        pass

    unregister_outliner_click_keymap()
