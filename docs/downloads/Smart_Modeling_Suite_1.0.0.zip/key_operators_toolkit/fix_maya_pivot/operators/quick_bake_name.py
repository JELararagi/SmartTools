"""Name and isolate high- and low-resolution mesh bake groups."""
import re
import secrets
import string

import bpy
from bpy.app.translations import pgettext_tip
from bpy.props import BoolProperty, EnumProperty, StringProperty


BAKE_SUFFIX = re.compile(r"(?P<stem>.+)_(?P<role>low|high)(?P<index>\.[0-9]+)?$")
SAFE_ALPHABET = string.ascii_uppercase + string.digits


def stem_of(name):
    match = BAKE_SUFFIX.fullmatch(name)
    return match["stem"] if match else name


def triangle_count(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    if mesh is None:
        return 0
    try:
        return len(mesh.loop_triangles)
    finally:
        evaluated.to_mesh_clear()


def name_is_available(mapping):
    for obj, name in mapping:
        current = bpy.data.objects.get(name)
        if current is not None and current != obj:
            return False
    return True


class QuickBakeName(bpy.types.Operator):
    bl_idname = "keyops.quick_bake_name"
    bl_label = "Quick Bake Name"
    bl_description = "Name selected mesh objects for matching high- and low-resolution texture bakes"
    bl_options = {"UNDO"}

    random_name: BoolProperty(name="Random Name", description="Generate a shared base name for the pair", default=True)
    rename_datablock: BoolProperty(
        name="Rename Datablock", description="Give single-user mesh data the same name as its object", default=True)
    hide: BoolProperty(name="Hide Objects", description="Hide the named objects in this viewport", default=False)
    type: StringProperty(name="Type", options={"SKIP_SAVE"})
    new_name: StringProperty(name="New Name", description="New base name for this bake group", options={"SKIP_SAVE"})

    def warn(self, message):
        self.report({"WARNING"}, pgettext_tip(message))
        return {"CANCELLED"}

    def invoke(self, context, event):
        if self.type != "RENAME":
            return self.execute(context)
        if context.object is None:
            return self.warn("Please select an active object")
        self.new_name = stem_of(context.object.name)
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        if self.type == "RENAME":
            layout.prop(self, "new_name")
        else:
            for property_name in ("hide", "random_name", "rename_datablock"):
                layout.prop(self, property_name)

    def execute(self, context):
        active = context.view_layer.objects.active
        meshes = [obj for obj in context.selected_objects if obj.type == "MESH" and obj.is_editable]
        if self.type == "RENAME":
            return self.rename_group(context, active)
        if self.type in {"set_high_name", "set_low_name"}:
            if not meshes:
                return self.warn("Select a mesh to assign a bake suffix")
            suffix = self.type.split("_")[1]
            for obj in meshes:
                obj.name = f"{stem_of(obj.name)}_{suffix}"
            return {"FINISHED"}
        if len(meshes) < 2:
            return self.warn("Please select at least two objects")
        if len(meshes) > 2 and active not in meshes:
            return self.warn("Select the low-resolution mesh as the active object")
        low = self.low_object(context, meshes, active)
        others = sorted((obj for obj in meshes if obj != low), key=lambda obj: obj.name)
        base = stem_of(low.name)
        for _ in range(16 if self.random_name else 1):
            if self.random_name:
                base = "".join(secrets.choice(SAFE_ALPHABET) for _ in range(5))
            names = [(low, f"{base}_low")]
            names.extend((obj, f"{base}_high{f'.{index:03d}' if index else ''}")
                         for index, obj in enumerate(others))
            if name_is_available(names):
                break
        else:
            return self.warn("Name already exists, please rename the low poly object.")
        for obj, label in names:
            obj.name = label
            if self.rename_datablock and obj.data.users == 1 and obj.data.is_editable:
                obj.data.name = label
            if self.hide:
                obj.hide_set(True, view_layer=context.view_layer)
        return {"FINISHED"}

    @staticmethod
    def low_object(context, meshes, active):
        if len(meshes) > 2:
            return active
        low = [obj for obj in meshes if any(collection.name.casefold() == "low"
                                            for collection in obj.users_collection)]
        high = [obj for obj in meshes if any(collection.name.casefold() == "high"
                                             for collection in obj.users_collection)]
        if len(low) == len(high) == 1 and low[0] != high[0]:
            return low[0]
        depsgraph = context.evaluated_depsgraph_get()
        return min(meshes, key=lambda obj: (triangle_count(obj, depsgraph), obj != active, obj.name))

    def rename_group(self, context, active):
        if active is None:
            return self.warn("Please select an active object")
        new_base = self.new_name.strip()
        if not new_base:
            return self.warn("Enter a new name for the bake group")
        old_base = stem_of(active.name)
        mapping = []
        for obj in context.scene.objects:
            match = BAKE_SUFFIX.fullmatch(obj.name)
            if match is not None and match["stem"] == old_base and obj.is_editable:
                mapping.append((obj, f'{new_base}_{match["role"]}{match["index"] or ""}'))
        if not mapping:
            return self.warn("No bake group matches the selected object")
        if not name_is_available(mapping):
            return self.warn("Name already exists, please rename the low poly object.")
        for obj, label in mapping:
            obj.name = label
        return {"FINISHED"}

    @staticmethod
    def register():
        for cls in (QuickBakeNamePanel, HideShowLowHigh):
            bpy.utils.register_class(cls)

    @staticmethod
    def unregister():
        for cls in (HideShowLowHigh, QuickBakeNamePanel):
            if cls.is_registered:
                bpy.utils.unregister_class(cls)


class HideShowLowHigh(bpy.types.Operator):
    bl_idname = "keyops.hide_show_low_high"
    bl_label = "Hide Show Low High"
    bl_description = "Set visibility of bake meshes in the current view layer"
    bl_options = {"INTERNAL", "UNDO"}

    group: EnumProperty(items=(("HIGH", "High", ""), ("LOW", "Low", ""), ("ALL", "All", "")))
    action: EnumProperty(items=(("SHOW", "Show", ""), ("HIDE", "Hide", "")))

    def execute(self, context):
        for obj in context.view_layer.objects:
            match = BAKE_SUFFIX.fullmatch(obj.name)
            if match and (self.group == "ALL" or match["role"].upper() == self.group):
                obj.hide_set(self.action == "HIDE", view_layer=context.view_layer)
        return {"FINISHED"}


class QuickBakeNamePanel(bpy.types.Panel):
    bl_idname = "KEYOPS_PT_quick_bake_name_panel"
    bl_label = "Quick Bake Name"
    bl_description = "Manage names and visibility for texture baking"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Modeling"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def draw_header(self, context):
        self.layout.label(icon="MATSHADERBALL")

    def draw(self, context):
        line = self.layout.row(align=True)
        line.operator("keyops.quick_bake_name", text="Quick Bake Name")
        line.operator("keyops.quick_bake_name", text="Rename").type = "RENAME"
        labels = self.layout.row(align=True)
        for role in ("high", "low"):
            labels.operator("keyops.quick_bake_name", text=f"Add _{role}").type = f"set_{role}_name"
        visibility = self.layout.box()
        for group in ("HIGH", "LOW", "ALL"):
            controls = visibility.row(align=True)
            controls.label(text=group.lower())
            for action in ("SHOW", "HIDE"):
                op = controls.operator("keyops.hide_show_low_high", text=action)
                op.group = group
                op.action = action
