"""Legacy shortcut declarations live in classes_keymap_items."""
