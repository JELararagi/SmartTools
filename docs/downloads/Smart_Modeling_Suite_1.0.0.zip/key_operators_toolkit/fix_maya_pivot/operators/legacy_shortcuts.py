# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Historical module name for callers that import the shortcut package directly."""

__all__ = ()
