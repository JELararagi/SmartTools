# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for the renamed smart apply scale operator module."""

from .apply_scale import SmartApplyScale, apply_scale, menu_apply

__all__ = ("SmartApplyScale", "apply_scale", "menu_apply")
