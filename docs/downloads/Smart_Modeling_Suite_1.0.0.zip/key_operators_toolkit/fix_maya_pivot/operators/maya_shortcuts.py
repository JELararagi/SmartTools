# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Retain the historical Maya shortcut command for stored user keymaps."""

from bpy.types import Operator


class MayaShortcuts(Operator):
    """Acknowledges the callback. Shortcut assignments are edited in Preferences."""

    bl_idname = "keyops.maya_shortcuts"
    bl_label = "KeyOps: Maya Shortcuts"
    bl_options = {"UNDO"}

    def execute(self, context):
        return set(("FINISHED",))
