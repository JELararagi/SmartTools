# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Transactional CAD decimation for Smart Modeling Suite.

The slow OBJ workflow is confined to a UUID session directory owned by this
Suite.  Existing objects and external OBJ files are never overwritten or
removed.  Every generated Blender ID and file is recorded by exact identity in
an execution journal so failures can roll back without global orphan cleanup.
"""
from __future__ import annotations

import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import uuid

import bpy

from .... import language as _language
from ..utils.pref_utils import get_keyops_prefs


_CAD_OWNER_UUID = "67e4193e-2613-476d-a1f7-e6caa77b19ef"
_CAD_SUITE_ID = "smart_modeling_suite"
_CAD_SCHEMA = 2
_CAD_MANAGED_DIRECTORY = "SmartModelingCADManaged"
_CAD_RUNTIME_KEY = "JELARARAGI_SMS_CAD_DECIMATE_RUNTIME_V2"
_CAD_PROPERTY_KEY = "JELARARAGI_SMS_CAD_DECIMATE_PROPERTIES_V2"
_CAD_CLASS_KEY = "JELARARAGI_SMS_CAD_DECIMATE_CLASSES_V2"
_CAD_GENERATION = uuid.uuid4().hex
_CAD_MIN_FREE_BYTES = 16 * 1024 * 1024
_CAD_MAX_RUNTIME_SESSIONS = 8
_SUPPORTED_TYPES = frozenset({"MESH", "CURVE", "FONT", "SURFACE", "META"})
_GENERATED_KEYS = {
    "owner_uuid": "_sms_cad_owner_uuid",
    "suite_id": "_sms_cad_suite_id",
    "schema": "_sms_cad_schema",
    "generation": "_sms_cad_generation",
    "session_uuid": "_sms_cad_session_uuid",
    "artifact_uuid": "_sms_cad_artifact_uuid",
    "source_uuid": "_sms_cad_source_uuid",
    "role": "_sms_cad_role",
}

# Retained for compatibility with scripts that imported this historical symbol.
totall_tris = 0
prefs = get_keyops_prefs()


def _runtime_state():
    namespace = bpy.app.driver_namespace
    state = namespace.get(_CAD_RUNTIME_KEY)
    if not isinstance(state, dict) or state.get("owner_uuid") != _CAD_OWNER_UUID:
        state = {
            "owner_uuid": _CAD_OWNER_UUID,
            "suite_id": _CAD_SUITE_ID,
            "sessions": {},
            "last_error": "",
        }
        namespace[_CAD_RUNTIME_KEY] = state
    return state


def _set_runtime_error(message: str) -> None:
    state = _runtime_state()
    text = str(message or "")[:1024]
    if state.get("last_error") != text:
        state["last_error"] = text


def _scene_pointer(scene) -> int:
    try:
        return int(scene.as_pointer())
    except Exception:
        return id(scene)


def _record_active_session(scene, manifest_path: Path, session_uuid: str) -> None:
    state = _runtime_state()
    sessions = state.setdefault("sessions", {})
    key = _scene_pointer(scene)
    sessions[key] = {
        "manifest_path": str(manifest_path),
        "session_uuid": str(session_uuid),
        "generation": _CAD_GENERATION,
    }
    # Runtime receipts are a cache, not output ownership.  Bound them strictly.
    while len(sessions) > _CAD_MAX_RUNTIME_SESSIONS:
        sessions.pop(next(iter(sessions)))


def _active_session_receipt(scene):
    receipt = _runtime_state().setdefault("sessions", {}).get(_scene_pointer(scene))
    if not isinstance(receipt, dict):
        return None
    if receipt.get("generation") != _CAD_GENERATION:
        return None
    return receipt


def _drop_active_session(scene, session_uuid: str | None = None) -> None:
    sessions = _runtime_state().setdefault("sessions", {})
    key = _scene_pointer(scene)
    receipt = sessions.get(key)
    if not isinstance(receipt, dict):
        sessions.pop(key, None)
        return
    if session_uuid is None or receipt.get("session_uuid") == str(session_uuid):
        sessions.pop(key, None)


def _sms_user_default_fallback(*parts):
    try:
        version = getattr(getattr(bpy, "app", None), "version", (5, 1, 0))
        version_label = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else "5.1"
    except Exception:
        version_label = "5.1"
    if os.name == "nt":
        base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
        root = os.path.join(base, "Blender Foundation", "Blender", version_label)
    else:
        root = os.path.join(os.path.expanduser("~"), ".config", "blender", version_label)
    path = os.path.join(root, "config", "Smart_Modeling_Suite", *[
        str(part).strip("/\\") for part in parts if str(part or "").strip("/\\")
    ])
    os.makedirs(path, exist_ok=True)
    return path


def _default_cad_decimate_export_path():
    try:
        from ....utils import suite_user_dir
        return suite_user_dir("cad_decimate", create=True)
    except Exception:
        try:
            config_dir = bpy.utils.user_resource("CONFIG", create=False)
            path = os.path.join(str(config_dir), "Smart_Modeling_Suite", "cad_decimate")
            os.makedirs(path, exist_ok=True)
            return path
        except Exception:
            return _sms_user_default_fallback("cad_decimate")


def _path_is_reparse_or_symlink(path: Path) -> bool:
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        return False
    except OSError:
        return True
    if stat.S_ISLNK(info.st_mode):
        return True
    attributes = int(getattr(info, "st_file_attributes", 0) or 0)
    reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    return bool(attributes & reparse_flag)


def _assert_no_reparse_path(path: Path) -> None:
    current = Path(os.path.abspath(os.fspath(path)))
    chain = []
    while True:
        chain.append(current)
        parent = current.parent
        if parent == current:
            break
        current = parent
    for item in reversed(chain):
        if item.exists() and _path_is_reparse_or_symlink(item):
            raise RuntimeError(f"Managed CAD path must not contain a symlink or reparse point: {item}")


def _managed_root(scene) -> Path:
    configured = str(getattr(scene, "sms_cad_export_path", "") or _default_cad_decimate_export_path())
    base = Path(os.path.abspath(os.path.expanduser(configured)))
    _assert_no_reparse_path(base)
    root = base / _CAD_MANAGED_DIRECTORY
    root.mkdir(parents=True, exist_ok=True)
    _assert_no_reparse_path(root)
    if not root.is_dir():
        raise RuntimeError("CAD managed root is not a directory")
    return root


def _ensure_capacity(path: Path, minimum_bytes: int = _CAD_MIN_FREE_BYTES) -> None:
    try:
        free = int(shutil.disk_usage(path).free)
    except OSError as exc:
        raise RuntimeError(f"Unable to query free space for CAD staging: {exc}") from exc
    if free < int(minimum_bytes):
        raise OSError(errno.ENOSPC, "Insufficient free space for CAD staging", os.fspath(path))


def _new_session(scene):
    root = _managed_root(scene)
    _ensure_capacity(root)
    session_uuid = uuid.uuid4().hex
    session_dir = root / session_uuid
    session_dir.mkdir(mode=0o700, parents=False, exist_ok=False)
    _assert_no_reparse_path(session_dir)
    manifest_path = session_dir / "manifest.json"
    manifest = {
        "schema": _CAD_SCHEMA,
        "owner_uuid": _CAD_OWNER_UUID,
        "suite_id": _CAD_SUITE_ID,
        "document_generation": _CAD_GENERATION,
        "session_uuid": session_uuid,
        "managed_root": os.fspath(root),
        "session_dir": os.fspath(session_dir),
        "artifacts": [],
        "outputs": [],
        "state": "staging",
    }
    journal = {
        "session_uuid": session_uuid,
        "root": root,
        "session_dir": session_dir,
        "manifest_path": manifest_path,
        "created_files": [],
        "created_paths": [],
        "created_objects": [],
        "created_data": [],
        "created_modifiers": [],
    }
    return manifest, journal


def _file_identity(path: Path):
    info = os.stat(path, follow_symlinks=False)
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError(f"CAD artifact is not a regular file: {path}")
    return {
        "device": int(info.st_dev),
        "inode": int(info.st_ino),
        "size": int(info.st_size),
        "mtime_ns": int(getattr(info, "st_mtime_ns", int(info.st_mtime * 1_000_000_000))),
    }


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_obj_file(path: Path):
    _assert_no_reparse_path(path)
    identity = _file_identity(path)
    if identity["size"] <= 0:
        raise RuntimeError(f"OBJ export is empty: {path}")
    vertices = 0
    primitives = 0
    with open(path, "r", encoding="utf-8", errors="strict", newline="") as handle:
        for line in handle:
            if line.startswith("v "):
                parts = line.split()
                if len(parts) < 4:
                    raise RuntimeError(f"Malformed OBJ vertex in {path.name}")
                for value in parts[1:4]:
                    number = float(value)
                    if not (number == number and abs(number) != float("inf")):
                        raise RuntimeError(f"Non-finite OBJ coordinate in {path.name}")
                vertices += 1
            elif line.startswith(("f ", "l ", "p ")):
                primitives += 1
    if vertices <= 0 or primitives <= 0:
        raise RuntimeError(f"OBJ structure validation failed: {path.name}")
    return {
        "identity": identity,
        "sha256": _sha256_file(path),
        "vertices": vertices,
        "primitives": primitives,
    }


def _same_identity(left, right) -> bool:
    return all(int(left.get(key, -1)) == int(right.get(key, -2)) for key in (
        "device", "inode", "size", "mtime_ns"
    ))


def _verify_artifact_record(record):
    path = Path(str(record.get("path", "")))
    checked = _validate_obj_file(path)
    if checked["sha256"] != str(record.get("sha256", "")):
        raise RuntimeError(f"CAD artifact hash changed: {path.name}")
    if not _same_identity(checked["identity"], record.get("identity", {})):
        raise RuntimeError(f"CAD artifact identity changed: {path.name}")
    return path


def _atomic_write_manifest(path: Path, manifest) -> None:
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8") + b"\n"
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with open(temporary, "xb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            if temporary.exists():
                temporary.unlink()
        except OSError:
            pass


def _load_active_manifest(scene):
    receipt = _active_session_receipt(scene)
    if receipt is None:
        raise RuntimeError("No active Smart Modeling CAD transaction exists")
    manifest_path = Path(str(receipt.get("manifest_path", "")))
    root = _managed_root(scene)
    _assert_no_reparse_path(manifest_path)
    try:
        if os.path.commonpath((os.fspath(root), os.fspath(manifest_path))) != os.fspath(root):
            raise RuntimeError("CAD manifest is outside the Suite-managed root")
    except ValueError as exc:
        raise RuntimeError("CAD manifest is outside the Suite-managed root") from exc
    with open(manifest_path, "r", encoding="utf-8", errors="strict") as handle:
        manifest = json.load(handle)
    if not isinstance(manifest, dict):
        raise RuntimeError("CAD manifest is invalid")
    expected = {
        "schema": _CAD_SCHEMA,
        "owner_uuid": _CAD_OWNER_UUID,
        "suite_id": _CAD_SUITE_ID,
        "document_generation": _CAD_GENERATION,
        "session_uuid": receipt.get("session_uuid"),
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            raise RuntimeError(f"CAD manifest ownership mismatch: {key}")
    if Path(str(manifest.get("managed_root", ""))) != root:
        raise RuntimeError("CAD manifest managed-root mismatch")
    session_dir = Path(str(manifest.get("session_dir", "")))
    if session_dir.parent != root or session_dir.name != str(manifest.get("session_uuid", "")):
        raise RuntimeError("CAD manifest session directory mismatch")
    _assert_no_reparse_path(session_dir)
    return manifest, manifest_path


def _operator_finished(result) -> bool:
    return "FINISHED" in set(result or set()) and "CANCELLED" not in set(result or set())


def _eligible_selected_objects(context):
    return tuple(obj for obj in tuple(getattr(context, "selected_objects", ()) or ())
                 if getattr(obj, "type", None) in _SUPPORTED_TYPES
                 and getattr(obj, "library", None) is None
                 and getattr(obj, "override_library", None) is None)


def _selection_snapshot(context):
    selected = tuple(getattr(context, "selected_objects", ()) or ())
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    return selected, active


def _restore_selection(context, snapshot) -> None:
    selected, active = snapshot
    try:
        for obj in tuple(getattr(context.scene, "objects", ()) or ()):
            try:
                obj.select_set(False)
            except Exception:
                pass
        for obj in selected:
            try:
                if obj.name in context.scene.objects:
                    obj.select_set(True)
            except Exception:
                pass
        try:
            context.view_layer.objects.active = active
        except Exception:
            pass
    except Exception:
        pass


def _select_only(context, obj) -> None:
    for current in tuple(getattr(context.scene, "objects", ()) or ()):
        try:
            current.select_set(False)
        except Exception:
            pass
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _tag_generated_id(data_block, *, session_uuid: str, artifact_uuid: str,
                      source_uuid: str, role: str) -> None:
    values = {
        "owner_uuid": _CAD_OWNER_UUID,
        "suite_id": _CAD_SUITE_ID,
        "schema": _CAD_SCHEMA,
        "generation": _CAD_GENERATION,
        "session_uuid": session_uuid,
        "artifact_uuid": artifact_uuid,
        "source_uuid": source_uuid,
        "role": role,
    }
    for logical, key in _GENERATED_KEYS.items():
        data_block[key] = values[logical]


def _id_is_owned(data_block, *, session_uuid: str, artifact_uuid: str | None = None) -> bool:
    try:
        if data_block.get(_GENERATED_KEYS["owner_uuid"]) != _CAD_OWNER_UUID:
            return False
        if data_block.get(_GENERATED_KEYS["suite_id"]) != _CAD_SUITE_ID:
            return False
        if int(data_block.get(_GENERATED_KEYS["schema"], -1)) != _CAD_SCHEMA:
            return False
        if data_block.get(_GENERATED_KEYS["generation"]) != _CAD_GENERATION:
            return False
        if data_block.get(_GENERATED_KEYS["session_uuid"]) != session_uuid:
            return False
        if artifact_uuid is not None and data_block.get(_GENERATED_KEYS["artifact_uuid"]) != artifact_uuid:
            return False
        return True
    except Exception:
        return False


def _new_objects_after(context, before):
    return tuple(obj for obj in tuple(getattr(context.scene, "objects", ()) or ())
                 if all(obj is not old for old in before))


def _remove_exact_generated_object(obj, *, session_uuid: str, artifact_uuid: str | None = None) -> bool:
    if not _id_is_owned(obj, session_uuid=session_uuid, artifact_uuid=artifact_uuid):
        return False
    data = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return False
    if data is not None and _id_is_owned(data, session_uuid=session_uuid, artifact_uuid=artifact_uuid):
        try:
            if int(getattr(data, "users", 1)) == 0 and getattr(data, "library", None) is None:
                collection = getattr(bpy.data, "meshes", None)
                if collection is not None:
                    collection.remove(data)
        except Exception:
            pass
    return True


def _safe_delete_exact_file(record) -> bool:
    path = _verify_artifact_record(record)
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def _rollback_created_files(journal) -> None:
    session_dir = Path(journal.get("session_dir"))
    seen = set()
    # ``created_paths`` is an execution receipt, not a directory scan.  It allows
    # malformed/CANCELLED partial files to be removed even before validation.
    for raw_path in reversed(tuple(journal.get("created_paths", ()) or ())):
        try:
            path = Path(raw_path)
            key = os.path.normcase(os.path.abspath(os.fspath(path)))
            if key in seen:
                continue
            seen.add(key)
            if path.parent != session_dir or _path_is_reparse_or_symlink(path):
                continue
            path.unlink(missing_ok=True)
        except Exception:
            pass
    for record in reversed(tuple(journal.get("created_files", ()) or ())):
        try:
            path = Path(str(record.get("path", "")))
            key = os.path.normcase(os.path.abspath(os.fspath(path)))
            if key in seen or path.parent != session_dir or _path_is_reparse_or_symlink(path):
                continue
            seen.add(key)
            if path.exists():
                checked = _validate_obj_file(path)
                if checked["sha256"] == record.get("sha256"):
                    path.unlink()
        except Exception:
            pass


def _rollback_session(journal, *, remove_directory: bool) -> None:
    session_uuid = str(journal.get("session_uuid", ""))
    for obj in reversed(tuple(journal.get("created_objects", ()) or ())):
        try:
            _remove_exact_generated_object(obj, session_uuid=session_uuid)
        except Exception:
            pass
    for obj, modifier in reversed(tuple(journal.get("created_modifiers", ()) or ())):
        try:
            if modifier in obj.modifiers:
                obj.modifiers.remove(modifier)
        except Exception:
            pass
    _rollback_created_files(journal)
    manifest_path = journal.get("manifest_path")
    if remove_directory and manifest_path is not None:
        try:
            Path(manifest_path).unlink(missing_ok=True)
        except Exception:
            pass
        try:
            session_dir = Path(journal.get("session_dir"))
            if session_dir.parent == Path(journal.get("root")):
                session_dir.rmdir()
        except Exception:
            pass


def _export_session(context):
    sources = _eligible_selected_objects(context)
    if not sources:
        raise RuntimeError("Select at least one local mesh or curve object")
    manifest, journal = _new_session(context.scene)
    snapshot = _selection_snapshot(context)
    preserve_uv = bool(getattr(context.scene, "sms_cad_preserve_uvs", True))
    try:
        for source in sources:
            _ensure_capacity(journal["session_dir"])
            artifact_uuid = uuid.uuid4().hex
            source_uuid = uuid.uuid4().hex
            output_path = journal["session_dir"] / f"source-{artifact_uuid}.obj"
            journal["created_paths"].append(output_path)
            _select_only(context, source)
            result = bpy.ops.wm.obj_export(
                filepath=os.fspath(output_path),
                export_selected_objects=True,
                export_uv=preserve_uv,
                export_materials=False,
            )
            if not _operator_finished(result):
                raise RuntimeError(f"OBJ export was cancelled for {source.name}")
            checked = _validate_obj_file(output_path)
            record = {
                "artifact_uuid": artifact_uuid,
                "source_uuid": source_uuid,
                "source_name": str(source.name),
                "source_type": str(source.type),
                "source_pointer": int(source.as_pointer()),
                "role": "source_export",
                "path": os.fspath(output_path),
                **checked,
            }
            manifest["artifacts"].append(record)
            journal["created_files"].append(record)
        manifest["state"] = "exported"
        _atomic_write_manifest(journal["manifest_path"], manifest)
        _record_active_session(context.scene, journal["manifest_path"], manifest["session_uuid"])
        return manifest, journal
    except Exception:
        _rollback_session(journal, remove_directory=True)
        raise
    finally:
        _restore_selection(context, snapshot)


def _add_decimate_modifier(scene, obj, journal):
    mode = str(getattr(scene, "sms_cad_decimate_type", "DECIMATE"))
    if mode == "DECIMATE":
        modifier = obj.modifiers.new(name="SMS CAD Decimate", type="DECIMATE")
        if str(getattr(scene, "sms_cad_percent_or_amount", "PROCENT")) == "PROCENT":
            modifier.ratio = float(getattr(scene, "sms_cad_decimation_ratio", 0.2))
        else:
            mesh = getattr(obj, "data", None)
            try:
                mesh.calc_loop_triangles()
                current = max(1, len(mesh.loop_triangles))
            except Exception:
                current = max(1, len(getattr(mesh, "polygons", ()) or ()))
            modifier.ratio = min(1.0, max(0.0, int(getattr(scene, "sms_cad_tris_count", 10000)) / current))
    else:
        modifier = obj.modifiers.new(name="SMS CAD Weld", type="WELD")
        modifier.merge_threshold = float(getattr(scene, "sms_cad_merge_distance", 0.02))
        if mode == "CONNECT" and hasattr(modifier, "mode"):
            modifier.mode = "CONNECTED"
    journal.setdefault("created_modifiers", []).append((obj, modifier))
    return modifier


def _apply_modifier(context, obj, modifier) -> None:
    _select_only(context, obj)
    result = bpy.ops.object.modifier_apply(modifier=modifier.name)
    if not _operator_finished(result):
        raise RuntimeError(f"Modifier application was cancelled for {obj.name}")


def _process_active_session(context):
    manifest, manifest_path = _load_active_manifest(context.scene)
    original_manifest = json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8") + b"\n"
    journal = {
        "session_uuid": manifest["session_uuid"],
        "root": Path(manifest["managed_root"]),
        "session_dir": Path(manifest["session_dir"]),
        "manifest_path": manifest_path,
        "created_files": [],
        "created_paths": [],
        "created_objects": [],
        "created_modifiers": [],
    }
    snapshot = _selection_snapshot(context)
    outputs = []
    try:
        for source_record in tuple(manifest.get("artifacts", ()) or ()):
            source_path = _verify_artifact_record(source_record)
            before = tuple(getattr(context.scene, "objects", ()) or ())
            result = bpy.ops.wm.obj_import(filepath=os.fspath(source_path))
            if not _operator_finished(result):
                raise RuntimeError(f"OBJ import was cancelled: {source_path.name}")
            imported = _new_objects_after(context, before)
            if not imported:
                raise RuntimeError(f"OBJ import created no objects: {source_path.name}")
            artifact_uuid = uuid.uuid4().hex
            source_uuid = str(source_record["source_uuid"])
            for obj in imported:
                _tag_generated_id(
                    obj,
                    session_uuid=manifest["session_uuid"],
                    artifact_uuid=artifact_uuid,
                    source_uuid=source_uuid,
                    role="processing_object",
                )
                data = getattr(obj, "data", None)
                if data is not None:
                    _tag_generated_id(
                        data,
                        session_uuid=manifest["session_uuid"],
                        artifact_uuid=artifact_uuid,
                        source_uuid=source_uuid,
                        role="processing_data",
                    )
                journal["created_objects"].append(obj)

            # OBJ imports normally create one object; process each exact generated
            # object independently so no scene-wide scan or source mutation occurs.
            for index, obj in enumerate(imported):
                modifier = _add_decimate_modifier(context.scene, obj, journal)
                _apply_modifier(context, obj, modifier)
                output_uuid = uuid.uuid4().hex
                temporary = journal["session_dir"] / f"output-{output_uuid}.tmp.obj"
                committed = journal["session_dir"] / f"output-{output_uuid}.obj"
                journal["created_paths"].extend((temporary, committed))
                _ensure_capacity(journal["session_dir"])
                _select_only(context, obj)
                result = bpy.ops.wm.obj_export(
                    filepath=os.fspath(temporary),
                    export_selected_objects=True,
                    export_uv=bool(getattr(context.scene, "sms_cad_preserve_uvs", True)),
                    export_materials=False,
                )
                if not _operator_finished(result):
                    raise RuntimeError(f"Processed OBJ export was cancelled: {obj.name}")
                checked_temp = _validate_obj_file(temporary)
                os.replace(temporary, committed)
                checked = _validate_obj_file(committed)
                if checked["sha256"] != checked_temp["sha256"]:
                    raise RuntimeError("Processed OBJ changed during atomic commit")
                output_record = {
                    "artifact_uuid": output_uuid,
                    "source_uuid": source_uuid,
                    "source_artifact_uuid": str(source_record["artifact_uuid"]),
                    "object_index": index,
                    "role": "decimated_output",
                    "path": os.fspath(committed),
                    **checked,
                }
                outputs.append(output_record)
                journal["created_files"].append(output_record)

            for obj in reversed(imported):
                _remove_exact_generated_object(
                    obj,
                    session_uuid=manifest["session_uuid"],
                    artifact_uuid=artifact_uuid,
                )
                if obj in journal["created_objects"]:
                    journal["created_objects"].remove(obj)
        manifest["outputs"] = outputs
        manifest["state"] = "processed"
        _atomic_write_manifest(manifest_path, manifest)
        return manifest, journal
    except Exception:
        _rollback_session(journal, remove_directory=False)
        temporary_manifest = manifest_path.with_name(manifest_path.name + ".rollback")
        try:
            with open(temporary_manifest, "wb") as handle:
                handle.write(original_manifest)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_manifest, manifest_path)
        finally:
            try:
                temporary_manifest.unlink(missing_ok=True)
            except OSError:
                pass
        raise
    finally:
        _restore_selection(context, snapshot)


def _import_active_session(context, *, delete_managed_files: bool):
    manifest, manifest_path = _load_active_manifest(context.scene)
    outputs = tuple(manifest.get("outputs", ()) or ())
    if not outputs:
        raise RuntimeError("The active CAD transaction has no processed OBJ outputs")
    snapshot = _selection_snapshot(context)
    created = []
    try:
        for record in outputs:
            path = _verify_artifact_record(record)
            before = tuple(getattr(context.scene, "objects", ()) or ())
            result = bpy.ops.wm.obj_import(filepath=os.fspath(path))
            if not _operator_finished(result):
                raise RuntimeError(f"OBJ import was cancelled: {path.name}")
            imported = _new_objects_after(context, before)
            if not imported:
                raise RuntimeError(f"OBJ import created no objects: {path.name}")
            for obj in imported:
                _tag_generated_id(
                    obj,
                    session_uuid=manifest["session_uuid"],
                    artifact_uuid=str(record["artifact_uuid"]),
                    source_uuid=str(record["source_uuid"]),
                    role="committed_object",
                )
                data = getattr(obj, "data", None)
                if data is not None:
                    _tag_generated_id(
                        data,
                        session_uuid=manifest["session_uuid"],
                        artifact_uuid=str(record["artifact_uuid"]),
                        source_uuid=str(record["source_uuid"]),
                        role="committed_data",
                    )
                created.append(obj)
        manifest["state"] = "imported"
        _atomic_write_manifest(manifest_path, manifest)
        if delete_managed_files:
            # Explicit confirmation is required by the invoking operator.  Delete
            # only exact manifest artifacts after revalidating hash and identity.
            for record in tuple(manifest.get("artifacts", ()) or ()) + outputs:
                _safe_delete_exact_file(record)
            manifest["state"] = "imported_files_deleted"
            _atomic_write_manifest(manifest_path, manifest)
        return created
    except Exception:
        for obj in reversed(created):
            _remove_exact_generated_object(obj, session_uuid=manifest["session_uuid"])
        raise
    finally:
        _restore_selection(context, snapshot)


def _fast_decimate_selected(context):
    selected = _eligible_selected_objects(context)
    if not selected:
        raise RuntimeError("Select at least one local mesh or curve object")
    created_modifiers = []
    try:
        for obj in selected:
            context.view_layer.objects.active = obj
            journal = {"created_modifiers": created_modifiers}
            _add_decimate_modifier(context.scene, obj, journal)
        return selected
    except Exception:
        for obj, modifier in reversed(created_modifiers):
            try:
                if modifier in obj.modifiers:
                    obj.modifiers.remove(modifier)
            except Exception:
                pass
        raise


_FAILURE_TEXT_JA = {
    "Select at least one local mesh or curve object": "メッシュかカーブを 1 つ以上選んでください。",
    "No active Smart Modeling CAD transaction exists": "先に「エクスポート」を実行してください。",
    "The active CAD transaction has no processed OBJ outputs": "先に「CAD ポリゴン削減を処理」を実行してください。",
}


def _report_failure(operator, exc) -> set[str]:
    message = str(exc or "CAD Decimate failed")
    _set_runtime_error(message)
    message = _language.pick_text(
        message,
        _FAILURE_TEXT_JA.get(message, "CAD ポリゴン削減を完了できませんでした。書き出し先の設定と空き容量を確かめてください。"),
    )
    try:
        operator.report({"ERROR"}, message)
    except Exception:
        pass
    return {"CANCELLED"}


class CADDecimate(bpy.types.Operator):
    bl_idname = "keyops.cad_decimate"
    bl_label = "Auto CAD Decimate"
    bl_description = (
        "Decimate selected local objects. Slow mode uses a private UUID staging "
        "transaction and never overwrites source objects or external OBJ files."
    )
    bl_options = {"UNDO"}

    confirm_managed_delete: bpy.props.BoolProperty(
        name="Delete Verified Managed OBJ Files",
        default=False,
        description=(
            "After a successful import, delete only OBJ artifacts created by this "
            "exact Smart Modeling transaction whose owner, hash, and file identity still match."
        ),
        options={"HIDDEN"},
    )

    def invoke(self, context, event):
        del event
        if (not bool(getattr(context.scene, "sms_cad_fast_mode", True))
                and bool(getattr(context.scene, "sms_cad_delete_files_after_import", False))):
            return context.window_manager.invoke_props_dialog(self)
        return self.execute(context)

    def draw(self, context):
        del context
        self.layout.prop(self, "confirm_managed_delete")

    def execute(self, context):
        try:
            if bool(getattr(context.scene, "sms_cad_fast_mode", True)):
                _fast_decimate_selected(context)
            else:
                manifest, journal = _export_session(context)
                try:
                    _processed_manifest, process_journal = _process_active_session(context)
                    journal["created_files"].extend(process_journal.get("created_files", ()))
                    journal["created_paths"].extend(process_journal.get("created_paths", ()))
                    _import_active_session(
                        context,
                        delete_managed_files=(
                            bool(getattr(context.scene, "sms_cad_delete_files_after_import", False))
                            and bool(self.confirm_managed_delete)
                        ),
                    )
                except Exception:
                    _rollback_session(journal, remove_directory=True)
                    _drop_active_session(context.scene, manifest["session_uuid"])
                    raise
            _set_runtime_error("")
            return {"FINISHED"}
        except Exception as exc:
            return _report_failure(self, exc)

    # The two CAD panels are not registered here: the suite draws them from the
    # Python classes inside the Key Ops section, like the other bundled panels.
    @staticmethod
    def register():
        for cls in (ExportCADDecimate, ImportCADDecimate, ImportAllCADDecimate):
            _register_class_exact(cls)
        _register_cad_properties()

    @staticmethod
    def unregister():
        _unregister_cad_properties()
        for cls in reversed((ExportCADDecimate, ImportCADDecimate, ImportAllCADDecimate)):
            _unregister_class_exact(cls)
        _runtime_state().setdefault("sessions", {}).clear()


class ExportCADDecimate(bpy.types.Operator):
    bl_idname = "keyops.export_cad_decimate"
    bl_label = "Export CAD Decimate"
    bl_description = "Export selected objects to a private, verified Smart Modeling OBJ transaction"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        try:
            _export_session(context)
            _set_runtime_error("")
            return {"FINISHED"}
        except Exception as exc:
            return _report_failure(self, exc)


class ImportCADDecimate(bpy.types.Operator):
    bl_idname = "keyops.import_cad_decimate"
    bl_label = "Process CAD Decimate"
    bl_description = "Process only OBJ files recorded by the active Smart Modeling CAD transaction"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        try:
            _process_active_session(context)
            _set_runtime_error("")
            return {"FINISHED"}
        except Exception as exc:
            return _report_failure(self, exc)


class ImportAllCADDecimate(bpy.types.Operator):
    bl_idname = "keyops.import_all_cad_decimate"
    bl_label = "Import CAD Decimate"
    bl_description = "Import only verified outputs from the active Smart Modeling CAD transaction"
    bl_options = {"UNDO"}

    confirm_managed_delete: bpy.props.BoolProperty(
        name="Delete Verified Managed OBJ Files",
        default=False,
        description=(
            "Delete only files created by this exact transaction after import and "
            "after owner, hash, generation, and file identity are revalidated."
        ),
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def invoke(self, context, event):
        del event
        if bool(getattr(context.scene, "sms_cad_delete_files_after_import", False)):
            return context.window_manager.invoke_props_dialog(self)
        return self.execute(context)

    def draw(self, context):
        del context
        self.layout.prop(self, "confirm_managed_delete")

    def execute(self, context):
        try:
            _import_active_session(
                context,
                delete_managed_files=(
                    bool(getattr(context.scene, "sms_cad_delete_files_after_import", False))
                    and bool(self.confirm_managed_delete)
                ),
            )
            _set_runtime_error("")
            return {"FINISHED"}
        except Exception as exc:
            return _report_failure(self, exc)


class KEYOPS_PT_cad_decimate_panel_manual(bpy.types.Panel):
    bl_parent_id = ""
    bl_label = "Manual Decimation"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Modeling"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and not bool(getattr(context.scene, "sms_cad_fast_mode", True))

    def draw(self, context):
        del context
        layout = self.layout
        layout.operator("keyops.export_cad_decimate", text="Export")
        layout.operator("keyops.import_cad_decimate", text="Process CAD Decimate")
        layout.operator("keyops.import_all_cad_decimate", text="Import All")
        return None


class CADDecimatePanel(bpy.types.Panel):
    bl_description = "CAD Decimate Panel"
    bl_label = "CAD Decimate"
    bl_idname = "KEYOPS_PT_cad_decimate_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Modeling"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        del context
        self.layout.label(text="", icon="MOD_DECIM")
        return None

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def draw(self, context):
        box = self.layout.box()
        if get_keyops_prefs().enable_cad_decimate:
            scene = context.scene
            box.prop(scene, "sms_cad_decimate_type", text="")
            if scene.sms_cad_decimate_type != "DECIMATE":
                box.label(text="Does not preserve UVs", icon="ERROR")
            box.prop(scene, "sms_cad_fast_mode", text="Enable Fast Mode", toggle=True)
            col = box.column(align=True)
            row = col.row(align=True)
            if scene.sms_cad_decimate_type == "DECIMATE":
                row.prop(scene, "sms_cad_percent_or_amount", text="Percent or Amount", expand=True)
                row = col.row(align=True)
                if scene.sms_cad_percent_or_amount == "PROCENT":
                    row.prop(scene, "sms_cad_decimation_ratio", text="Decimation %")
                else:
                    row.prop(scene, "sms_cad_tris_count", text="Target Tris:")
            else:
                box.prop(scene, "sms_cad_merge_distance", text="Merge Amount")
            if not scene.sms_cad_fast_mode:
                box.prop(scene, "sms_cad_export_selected_only", text="Selected Only")
                if scene.sms_cad_decimate_type == "DECIMATE":
                    box.prop(scene, "sms_cad_preserve_uvs", text="Preserve UVs")
                box.prop(scene, "sms_cad_delete_files_after_import", text="Delete Files After Import")
                box.prop(scene, "sms_cad_auto_clear_garbage_data", text="Clean Transaction Artifacts")
                box.prop(scene, "sms_cad_export_path", text="Path")
            row = box.row()
            row.operator("keyops.cad_decimate", text="CAD Decimate", icon="MOD_DECIM")
            row.scale_y = 1.4
        return None


def _class_state():
    namespace = bpy.app.driver_namespace
    state = namespace.get(_CAD_CLASS_KEY)
    if not isinstance(state, dict) or state.get("owner_uuid") != _CAD_OWNER_UUID:
        state = {
            "owner_uuid": _CAD_OWNER_UUID,
            "suite_id": _CAD_SUITE_ID,
            "generation": _CAD_GENERATION,
            "receipts": {},
        }
        namespace[_CAD_CLASS_KEY] = state
    return state


def _class_registered_name(cls) -> str:
    idname = str(getattr(cls, "bl_idname", "") or "")
    if issubclass(cls, bpy.types.Operator) and "." in idname:
        head, tail = idname.split(".", 1)
        return f"{head.upper()}_OT_{tail}"
    return idname or cls.__name__


def _class_is_registered_exact(cls) -> bool:
    try:
        return getattr(bpy.types, _class_registered_name(cls), None) is cls
    except Exception:
        return False


def _register_class_exact(cls) -> None:
    state = _class_state()
    receipts = state.setdefault("receipts", {})
    if _class_is_registered_exact(cls):
        receipts[cls.__name__] = {
            "class": cls,
            "generation": _CAD_GENERATION,
            "native_unregister": bpy.utils.unregister_class,
        }
        return
    existing = getattr(bpy.types, _class_registered_name(cls), None)
    if existing is not None and existing is not cls:
        old_receipt = receipts.get(cls.__name__)
        if not isinstance(old_receipt, dict) or old_receipt.get("class") is not existing:
            raise RuntimeError(f"Foreign Blender class collision: {cls.__name__}")
        native_unregister = old_receipt.get("native_unregister")
        if not callable(native_unregister):
            raise RuntimeError(f"Missing exact native remover for stale class: {cls.__name__}")
        native_unregister(existing)
        if getattr(bpy.types, _class_registered_name(cls), None) is existing:
            raise RuntimeError(f"Stale class did not unregister: {cls.__name__}")
    bpy.utils.register_class(cls)
    if not _class_is_registered_exact(cls):
        raise RuntimeError(f"Class registration did not retain exact identity: {cls.__name__}")
    receipts[cls.__name__] = {
        "class": cls,
        "generation": _CAD_GENERATION,
        "native_unregister": bpy.utils.unregister_class,
    }
    state["generation"] = _CAD_GENERATION


def _unregister_class_exact(cls) -> None:
    state = _class_state()
    receipt = state.setdefault("receipts", {}).get(cls.__name__)
    if not isinstance(receipt, dict) or receipt.get("class") is not cls:
        return
    if not _class_is_registered_exact(cls):
        state["receipts"].pop(cls.__name__, None)
        return
    native_unregister = receipt.get("native_unregister")
    if not callable(native_unregister):
        return
    try:
        native_unregister(cls)
    except Exception:
        return
    if not _class_is_registered_exact(cls):
        state["receipts"].pop(cls.__name__, None)


def _cad_property_factories():
    return {
        "sms_cad_auto_clear_garbage_data": lambda: bpy.props.BoolProperty(
            name="Clean Transaction Artifacts",
            default=False,
            description=(
                "Release only temporary Blender IDs created by the current CAD transaction. "
                "This never runs a global orphan purge and never changes linked or foreign data."
            ),
        ),
        "sms_cad_preserve_uvs": lambda: bpy.props.BoolProperty(
            name="Preserve UVs", default=True,
            description="Preserve UV coordinates in the private staged OBJ output.",
        ),
        "sms_cad_export_path": lambda: bpy.props.StringProperty(
            name="Path", subtype="DIR_PATH",
            description=(
                "Parent directory for the Suite-owned SmartModelingCADManaged session root. "
                "Existing OBJ files in this directory are never scanned or deleted."
            ),
            default=_default_cad_decimate_export_path(),
        ),
        "sms_cad_decimation_ratio": lambda: bpy.props.FloatProperty(
            name="Decimation Ratio", default=0.2, min=0.0, max=1.0, subtype="FACTOR",
            description="Ratio used by the Decimate modifier in the transaction.",
        ),
        "sms_cad_delete_files_after_import": lambda: bpy.props.BoolProperty(
            name="Delete Files After Import", default=False,
            description=(
                "Request deletion after explicit confirmation. Only exact Suite-managed files "
                "with matching owner, hash, generation, and file identity can be deleted."
            ),
        ),
        "sms_cad_export_selected_only": lambda: bpy.props.BoolProperty(
            name="Export Selected Only", default=True,
            description=(
                "Compatibility setting. CAD Decimate always limits destructive work to selected "
                "local objects; it never performs a scene-wide export or deletion."
            ),
        ),
        "sms_cad_decimate_type": lambda: bpy.props.EnumProperty(
            name="Decimate Type",
            items=[
                ("DECIMATE", "High Quality (Slow)", "Use a Decimate modifier"),
                ("WELD", "Medium Quality (Fast)", "Use a Weld modifier"),
                ("CONNECT", "Low Quality (Fastest)", "Use connected weld mode"),
            ],
            default="DECIMATE",
            description="Choose the decimation algorithm.",
        ),
        "sms_cad_merge_distance": lambda: bpy.props.FloatProperty(
            name="Merge Distance", default=0.02, min=0.001, max=1.0, subtype="FACTOR",
            description="Merge distance used by Weld-based CAD decimation.",
        ),
        "sms_cad_format": lambda: bpy.props.EnumProperty(
            name="Format",
            items=[("OBJ", "OBJ", "Verified transaction format")],
            default="OBJ",
            description="CAD transaction format. OBJ is validated before every commit.",
        ),
        "sms_cad_fast_mode": lambda: bpy.props.BoolProperty(
            name="Fast Mode", default=True,
            description=(
                "Add decimation modifiers directly to selected local objects. Disable to use "
                "the slower private staged OBJ transaction without modifying the originals."
            ),
        ),
        "sms_cad_percent_or_amount": lambda: bpy.props.EnumProperty(
            name="Percent or Amount",
            items=[
                ("PROCENT", "By Percent", "Decimate by ratio"),
                ("AMOUNT", "By Tris Count", "Target an approximate triangle count"),
            ],
            default="PROCENT",
            description="Choose ratio or target triangle count.",
        ),
        "sms_cad_tris_count": lambda: bpy.props.IntProperty(
            name="Target Tris Count", default=10000, min=1,
            description="Approximate target triangle count for high-quality decimation.",
        ),
    }


def _property_state():
    namespace = bpy.app.driver_namespace
    state = namespace.get(_CAD_PROPERTY_KEY)
    if not isinstance(state, dict) or state.get("owner_uuid") != _CAD_OWNER_UUID:
        state = {
            "owner_uuid": _CAD_OWNER_UUID,
            "suite_id": _CAD_SUITE_ID,
            "generation": _CAD_GENERATION,
            "descriptors": {},
        }
        namespace[_CAD_PROPERTY_KEY] = state
    return state


def _register_cad_properties() -> None:
    state = _property_state()
    if state.get("generation") != _CAD_GENERATION:
        for name, descriptor in tuple(state.get("descriptors", {}).items()):
            try:
                if vars(bpy.types.Scene).get(name) is descriptor:
                    delattr(bpy.types.Scene, name)
            except Exception:
                pass
        state["descriptors"] = {}
        state["generation"] = _CAD_GENERATION
    added = []
    try:
        for name, factory in _cad_property_factories().items():
            current = vars(bpy.types.Scene).get(name)
            if current is not None:
                if state["descriptors"].get(name) is current:
                    continue
                # A foreign/unknown descriptor is preserved unchanged.
                continue
            setattr(bpy.types.Scene, name, factory())
            descriptor = vars(bpy.types.Scene).get(name)
            if descriptor is None:
                raise RuntimeError(f"Scene property registration failed: {name}")
            state["descriptors"][name] = descriptor
            added.append((name, descriptor))
    except Exception:
        for name, descriptor in reversed(added):
            try:
                if vars(bpy.types.Scene).get(name) is descriptor:
                    delattr(bpy.types.Scene, name)
            except Exception:
                pass
            state["descriptors"].pop(name, None)
        raise


def _unregister_cad_properties() -> None:
    state = _property_state()
    for name, descriptor in reversed(tuple(state.get("descriptors", {}).items())):
        try:
            if vars(bpy.types.Scene).get(name) is descriptor:
                delattr(bpy.types.Scene, name)
        except Exception:
            pass
    state["descriptors"] = {}
    _runtime_state().setdefault("sessions", {}).clear()
