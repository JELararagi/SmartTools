# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

import time

import bmesh
import bpy
from bpy.types import Operator

from ..utils import edit_mode_undo_bridge as _undo_bridge
from ..utils.pref_utils import get_is_addon_enabled


_UI_ONLY_TYPES = {
    "select_up",
    "select_down",
    "select_top",
    "select_bottom",
    "Toggle_Space",
    "Material_Tab",
    "select",
}


def _space_context(context) -> str:
    try:
        return str(context.space_data.context)
    except Exception:
        return ""


def _modifier_list_enabled() -> bool:
    try:
        return bool(get_is_addon_enabled("Modifier_List_Fork"))
    except Exception:
        return False


def _resolve_modifier_object(context):
    obj = getattr(context, "active_object", None)
    linked_proxy = False
    if obj is None or not hasattr(obj, "modifiers"):
        return None, False
    if not _modifier_list_enabled():
        return obj, False
    try:
        if len(obj.modifiers) != 1:
            return obj, False
        modifier = obj.modifiers[0]
        if modifier.name != "Duplicate Linked Modifiers" or modifier.type != "NODES" or modifier.node_group is None:
            return obj, False
        for item in modifier.node_group.interface.items_tree:
            if item.in_out != "INPUT" or item.identifier != "Socket_2":
                continue
            target = modifier.get(item.identifier)
            if target is not None and target.name in bpy.data.objects:
                return bpy.data.objects[target.name], True
    except Exception:
        pass
    return obj, linked_proxy


def _active_modifier(obj):
    try:
        return obj.modifiers.active
    except Exception:
        return None


def _modifier_index(obj, modifier) -> int:
    try:
        return int(obj.modifiers.find(modifier.name))
    except Exception:
        return -1


def _result_finished(result) -> bool:
    try:
        return "FINISHED" in set(result)
    except Exception:
        return False


def _current_matrices(record) -> dict:
    result = {}
    for obj in tuple(record.get("tracked_objects") or record.get("users") or ()):
        try:
            result[str(obj.name)] = obj.matrix_world.copy()
        except Exception:
            pass
    return result


def _record_for_object(records, obj):
    for record in tuple(records or ()):
        try:
            if record.get("mesh") == obj.data:
                return record
        except Exception:
            continue
    return None


def _run_edit_modifier_transaction(context, obj, mutator) -> bool:
    records = _undo_bridge.begin_transaction(context)
    record = _record_for_object(records, obj)
    if record is None:
        return False
    _undo_bridge.track_transaction_modifiers(record, (obj,))
    changed = False
    try:
        changed = bool(mutator())
        if not changed:
            _undo_bridge.rollback_transaction_record(record)
            return False
        _undo_bridge.commit_transaction_modifiers(record, (obj,))
        bm = bmesh.from_edit_mesh(obj.data)
        if not _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm):
            raise RuntimeError("Unable to commit the Edit Mode modifier transaction")
        return True
    except Exception:
        _undo_bridge.rollback_transaction_record(record)
        raise


def _evaluated_active_modifier_mesh(obj, active_modifier):
    """Evaluate only the active modifier on an Object-Mode clone.

    Blender does not evaluate the modifier stack of the live object while its
    Mesh is in Edit Mode. A temporary clone preserves the user's current mode,
    avoids mode-change Undo entries, and mirrors Blender's single-modifier Apply
    behavior by containing only the active modifier.
    """
    source_mesh = None
    temp_object = None
    result_mesh = None
    try:
        try:
            obj.update_from_editmode()
        except Exception:
            pass
        source_mesh = obj.data.copy()
        source_mesh.name = ".JEL_SMS_Modifier_Source"
        temp_object = bpy.data.objects.new(".JEL_SMS_Modifier_Evaluation", source_mesh)
        bpy.context.scene.collection.objects.link(temp_object)
        temp_object.matrix_world = obj.matrix_world.copy()
        try:
            temp_object.hide_render = True
            temp_object.display_type = "WIRE"
        except Exception:
            pass
        try:
            for key in tuple(obj.keys()):
                try:
                    temp_object[key] = obj[key]
                except Exception:
                    pass
        except Exception:
            pass
        for group in tuple(obj.vertex_groups):
            cloned_group = temp_object.vertex_groups.new(name=group.name)
            try:
                cloned_group.lock_weight = group.lock_weight
            except Exception:
                pass
        if _undo_bridge.clone_modifier_to_object(active_modifier, temp_object) is None:
            raise RuntimeError(f"Unable to clone modifier {active_modifier.name!r}")
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()
        evaluated = temp_object.evaluated_get(depsgraph)
        result_mesh = bpy.data.meshes.new_from_object(
            evaluated,
            preserve_all_data_layers=True,
            depsgraph=depsgraph,
        )
        if result_mesh is None:
            raise RuntimeError(f"Modifier {active_modifier.name!r} did not produce a Mesh")
        result_mesh.name = ".JEL_SMS_Modifier_Result"
        return result_mesh
    finally:
        if temp_object is not None:
            try:
                bpy.data.objects.remove(temp_object, do_unlink=True)
            except Exception:
                pass
        if source_mesh is not None and getattr(source_mesh, "users", 0) == 0:
            try:
                bpy.data.meshes.remove(source_mesh)
            except Exception:
                pass
        if result_mesh is not None and getattr(result_mesh, "users", 0) != 0:
            # The returned Mesh is expected to have zero users. Do not remove it
            # here if Blender assigned a temporary evaluated user unexpectedly.
            pass


def _apply_modifier_in_edit_mode(operator, context, obj, active_modifier) -> bool:
    if obj.type != "MESH" or obj.mode != "EDIT":
        return False
    try:
        if int(obj.data.users) > 1:
            operator.report({"WARNING"}, "Object data has multiple users; make it single-user before applying the modifier")
            return False
    except Exception:
        pass
    try:
        if obj.data.shape_keys is not None:
            operator.report({"WARNING"}, "Blender cannot apply this modifier while the mesh has Shape Keys")
            return False
    except Exception:
        pass

    records = _undo_bridge.begin_transaction(context)
    record = _record_for_object(records, obj)
    if record is None:
        return False
    _undo_bridge.track_transaction_modifiers(record, (obj,))

    backup_mesh = None
    evaluated_mesh = None
    try:
        try:
            obj.update_from_editmode()
        except Exception:
            pass
        backup_mesh = obj.data.copy()
        evaluated_mesh = _evaluated_active_modifier_mesh(obj, active_modifier)
        if evaluated_mesh is None:
            raise RuntimeError("The evaluated modifier mesh could not be created")

        bm = bmesh.from_edit_mesh(obj.data)
        bm.clear()
        bm.from_mesh(evaluated_mesh)
        try:
            bm.normal_update()
        except Exception:
            pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        obj.modifiers.remove(active_modifier)

        _undo_bridge.commit_transaction_modifiers(record, (obj,))
        bm = bmesh.from_edit_mesh(obj.data)
        if not _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm):
            raise RuntimeError("Unable to commit the applied modifier transaction")
        return True
    except Exception as exc:
        if backup_mesh is not None:
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.clear()
                bm.from_mesh(backup_mesh)
                bm.normal_update()
                bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
            except Exception:
                pass
        _undo_bridge.rollback_transaction_record(record)
        operator.report({"ERROR"}, f"Unable to apply modifier atomically: {exc}")
        return False
    finally:
        for mesh in (evaluated_mesh, backup_mesh):
            if mesh is not None:
                try:
                    bpy.data.meshes.remove(mesh)
                except Exception:
                    pass


def _write_evaluated_mesh_into_target(target_mesh, evaluated_mesh) -> None:
    """Copy evaluated geometry/custom-data without replacing the Mesh ID.

    Keeping the existing datablock preserves its custom properties and the
    owning Object's vertex-group namespace, while BMesh transfers topology,
    UVs, generic attributes, material indices, deform weights, and selections.
    """
    materials = tuple(evaluated_mesh.materials)
    active_uv = ""
    render_uv = ""
    try:
        if evaluated_mesh.uv_layers.active is not None:
            active_uv = str(evaluated_mesh.uv_layers.active.name)
        if evaluated_mesh.uv_layers.active_render is not None:
            render_uv = str(evaluated_mesh.uv_layers.active_render.name)
    except Exception:
        pass
    active_color = str(getattr(evaluated_mesh.color_attributes, "active_color_name", "") or "")
    default_color = str(getattr(evaluated_mesh.color_attributes, "default_color_name", "") or "")

    bm = bmesh.new()
    try:
        bm.from_mesh(evaluated_mesh)
        bm.to_mesh(target_mesh)
    finally:
        bm.free()

    try:
        target_mesh.materials.clear()
        for material in materials:
            target_mesh.materials.append(material)
    except Exception:
        pass
    try:
        if active_uv and target_mesh.uv_layers.get(active_uv) is not None:
            target_mesh.uv_layers.active = target_mesh.uv_layers.get(active_uv)
        if render_uv and target_mesh.uv_layers.get(render_uv) is not None:
            target_mesh.uv_layers.active_render = target_mesh.uv_layers.get(render_uv)
    except Exception:
        pass
    try:
        if active_color and target_mesh.color_attributes.get(active_color) is not None:
            target_mesh.color_attributes.active_color_name = active_color
        if default_color and target_mesh.color_attributes.get(default_color) is not None:
            target_mesh.color_attributes.default_color_name = default_color
    except Exception:
        pass
    target_mesh.update()


def _apply_modifier_in_object_mode(operator, context, obj, active_modifier) -> bool:
    """Apply one modifier without nesting Blender's own Undo operator.

    ``ModiKey`` is the sole Object-Mode Undo owner.  Calling
    ``bpy.ops.object.modifier_apply`` from it would create a nested history
    boundary whose first Undo can mix the preceding user action with only part
    of the apply result.  Evaluating the active modifier on an isolated clone
    and assigning the resulting Mesh keeps the complete operation in the
    dispatcher's single Undo entry.
    """
    if obj is None or getattr(obj, "type", "") != "MESH" or getattr(obj, "mode", "") != "OBJECT":
        return False
    try:
        if int(obj.data.users) > 1:
            operator.report({"WARNING"}, "Object data has multiple users; make it single-user before applying the modifier")
            return False
    except Exception:
        pass
    try:
        if obj.data.shape_keys is not None:
            operator.report({"WARNING"}, "Blender cannot apply this modifier while the mesh has Shape Keys")
            return False
    except Exception:
        pass

    target_mesh = obj.data
    evaluated_mesh = None
    backup_mesh = None
    try:
        backup_mesh = target_mesh.copy()
        evaluated_mesh = _evaluated_active_modifier_mesh(obj, active_modifier)
        if evaluated_mesh is None:
            raise RuntimeError("The evaluated modifier mesh could not be created")
        _write_evaluated_mesh_into_target(target_mesh, evaluated_mesh)
        obj.modifiers.remove(active_modifier)
        return True
    except Exception as exc:
        if backup_mesh is not None:
            try:
                _write_evaluated_mesh_into_target(target_mesh, backup_mesh)
            except Exception:
                pass
        operator.report({"ERROR"}, f"Unable to apply modifier: {exc}")
        return False
    finally:
        for mesh in (evaluated_mesh, backup_mesh):
            if mesh is not None and getattr(mesh, "users", 0) == 0:
                try:
                    bpy.data.meshes.remove(mesh)
                except Exception:
                    pass


def _apply_all_modifiers_in_object_mode(operator, obj) -> bool:
    if obj is None or getattr(obj, "type", "") != "MESH" or getattr(obj, "mode", "") != "OBJECT":
        return False
    if len(obj.modifiers) == 0:
        return False
    try:
        if int(obj.data.users) > 1:
            operator.report({"WARNING"}, "Object data has multiple users; make it single-user before applying modifiers")
            return False
    except Exception:
        pass
    try:
        if obj.data.shape_keys is not None:
            operator.report({"WARNING"}, "Blender cannot apply modifiers while the mesh has Shape Keys")
            return False
    except Exception:
        pass

    target_mesh = obj.data
    result_mesh = None
    backup_mesh = None
    try:
        backup_mesh = target_mesh.copy()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()
        evaluated = obj.evaluated_get(depsgraph)
        result_mesh = bpy.data.meshes.new_from_object(
            evaluated,
            preserve_all_data_layers=True,
            depsgraph=depsgraph,
        )
        if result_mesh is None:
            raise RuntimeError("The evaluated modifier stack did not produce a Mesh")
        _write_evaluated_mesh_into_target(target_mesh, result_mesh)
        obj.modifiers.clear()
        return True
    except Exception as exc:
        if backup_mesh is not None:
            try:
                _write_evaluated_mesh_into_target(target_mesh, backup_mesh)
            except Exception:
                pass
        operator.report({"ERROR"}, f"Unable to apply modifier stack: {exc}")
        return False
    finally:
        for mesh in (result_mesh, backup_mesh):
            if mesh is not None and getattr(mesh, "users", 0) == 0:
                try:
                    bpy.data.meshes.remove(mesh)
                except Exception:
                    pass


def _clone_modifier(source, target):
    modifier = _undo_bridge.clone_modifier_to_object(source, target)
    if modifier is None:
        return None
    return modifier


def _execute_modifier_data(operator, context, action: str):
    obj, linked_proxy = _resolve_modifier_object(context)
    if obj is None:
        return {"CANCELLED"}
    active_modifier = _active_modifier(obj)
    if active_modifier is None:
        return {"CANCELLED"}
    active_index = _modifier_index(obj, active_modifier)
    edit_mode = bool(getattr(obj, "mode", "") == "EDIT" and getattr(obj, "type", "") == "MESH")

    if action in _UI_ONLY_TYPES:
        try:
            bpy.ops.keyops.modi_key_no_undo(type=action)
        except Exception:
            pass
        return {"CANCELLED"}

    def apply_mutation(mutator):
        if edit_mode:
            try:
                return _run_edit_modifier_transaction(context, obj, mutator)
            except Exception as exc:
                operator.report({"ERROR"}, str(exc))
                return False
        return bool(mutator())

    if action == "move_up":
        if active_index <= 0:
            return {"CANCELLED"}
        changed = apply_mutation(lambda: (obj.modifiers.move(active_index, active_index - 1), True)[1])
    elif action == "move_top":
        if active_index <= 0:
            return {"CANCELLED"}
        changed = apply_mutation(lambda: (obj.modifiers.move(active_index, 0), True)[1])
    elif action == "move_down":
        if active_index < 0 or active_index >= len(obj.modifiers) - 1:
            return {"CANCELLED"}
        changed = apply_mutation(lambda: (obj.modifiers.move(active_index, active_index + 1), True)[1])
    elif action == "move_bottom":
        if active_index < 0 or active_index >= len(obj.modifiers) - 1:
            return {"CANCELLED"}
        changed = apply_mutation(lambda: (obj.modifiers.move(active_index, len(obj.modifiers) - 1), True)[1])
    elif action == "delete":
        changed = apply_mutation(lambda: (obj.modifiers.remove(active_modifier), True)[1])
    elif action == "delete_named_modi_on_all_selected":
        name = str(active_modifier.name)
        targets = []
        for target in tuple(getattr(context, "selected_objects", ()) or ()):
            if hasattr(target, "modifiers") and target.modifiers.get(name) is not None:
                targets.append(target)
        if not targets:
            return {"CANCELLED"}
        if edit_mode:
            records = _undo_bridge.begin_transaction(context)
            record = _record_for_object(records, obj)
            if record is None:
                return {"CANCELLED"}
            _undo_bridge.track_transaction_modifiers(record, targets)
            try:
                for target in targets:
                    modifier = target.modifiers.get(name)
                    if modifier is not None:
                        target.modifiers.remove(modifier)
                _undo_bridge.commit_transaction_modifiers(record, targets)
                bm = bmesh.from_edit_mesh(obj.data)
                changed = _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm)
            except Exception:
                _undo_bridge.rollback_transaction_record(record)
                raise
        else:
            for target in targets:
                modifier = target.modifiers.get(name)
                if modifier is not None:
                    target.modifiers.remove(modifier)
            changed = True
    elif action == "Copy_Modifier_to_Selected":
        targets = [
            target for target in tuple(getattr(context, "selected_objects", ()) or ())
            if target is not obj and hasattr(target, "modifiers")
        ]
        if not targets:
            return {"CANCELLED"}
        if edit_mode:
            records = _undo_bridge.begin_transaction(context)
            record = _record_for_object(records, obj)
            if record is None:
                return {"CANCELLED"}
            _undo_bridge.track_transaction_modifiers(record, targets)
            try:
                changed = any(_clone_modifier(active_modifier, target) is not None for target in targets)
                if not changed:
                    _undo_bridge.rollback_transaction_record(record)
                    return {"CANCELLED"}
                _undo_bridge.commit_transaction_modifiers(record, targets)
                bm = bmesh.from_edit_mesh(obj.data)
                changed = _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm)
            except Exception:
                _undo_bridge.rollback_transaction_record(record)
                raise
        else:
            changed = any(_clone_modifier(active_modifier, target) is not None for target in targets)
    elif action == "Apply":
        started = time.perf_counter()
        name = str(active_modifier.name)
        if edit_mode:
            changed = _apply_modifier_in_edit_mode(operator, context, obj, active_modifier)
        elif getattr(obj, "type", "") == "MESH":
            changed = _apply_modifier_in_object_mode(operator, context, obj, active_modifier)
        else:
            try:
                with context.temp_override(
                    object=obj,
                    active_object=obj,
                    selected_objects=[obj],
                    selected_editable_objects=[obj],
                ):
                    changed = _result_finished(bpy.ops.object.modifier_apply(modifier=active_modifier.name))
            except Exception as exc:
                operator.report({"ERROR"}, f"Unable to apply modifier: {exc}")
                changed = False
        if changed:
            elapsed = time.perf_counter() - started
            operator.report({"INFO"}, f"Applied {name} in {elapsed:.2f} seconds" if elapsed > 1.0 else f"Applied {name} in {elapsed * 1000.0:.2f} ms")
    elif action == "Apply_All":
        if edit_mode:
            operator.report({"WARNING"}, "Apply All is unavailable in Edit Mode")
            return {"CANCELLED"}
        if getattr(obj, "type", "") == "MESH":
            changed = _apply_all_modifiers_in_object_mode(operator, obj)
        else:
            changed = _result_finished(bpy.ops.object.convert(target="MESH"))
    elif action == "HideAll":
        if not any(bool(modifier.show_viewport) for modifier in obj.modifiers):
            return {"CANCELLED"}
        def mutate():
            for modifier in obj.modifiers:
                modifier.show_viewport = False
            return True
        changed = apply_mutation(mutate)
    elif action == "ShowAll":
        if not any(not bool(modifier.show_viewport) for modifier in obj.modifiers):
            return {"CANCELLED"}
        def mutate():
            for modifier in obj.modifiers:
                modifier.show_viewport = True
            return True
        changed = apply_mutation(mutate)
    elif action == "Render_Toggle":
        changed = apply_mutation(lambda: (setattr(active_modifier, "show_render", not active_modifier.show_render), True)[1])
    elif action == "Viewport_Toggle":
        changed = apply_mutation(lambda: (setattr(active_modifier, "show_viewport", not active_modifier.show_viewport), True)[1])
    elif action == "Viewport_Toggle_all_selected":
        current = bool(active_modifier.show_viewport)
        name = str(active_modifier.name)
        targets = []
        seen = set()
        for target in tuple(getattr(context, "selected_objects", ()) or ()) + (obj,):
            try:
                pointer = int(target.as_pointer())
            except Exception:
                continue
            if pointer in seen or not hasattr(target, "modifiers") or target.modifiers.get(name) is None:
                continue
            seen.add(pointer)
            targets.append(target)
        if not targets:
            return {"CANCELLED"}
        if edit_mode:
            records = _undo_bridge.begin_transaction(context)
            record = _record_for_object(records, obj)
            if record is None:
                return {"CANCELLED"}
            _undo_bridge.track_transaction_modifiers(record, targets)
            try:
                for target in targets:
                    target.modifiers.get(name).show_viewport = not current
                _undo_bridge.commit_transaction_modifiers(record, targets)
                bm = bmesh.from_edit_mesh(obj.data)
                changed = _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm)
            except Exception:
                _undo_bridge.rollback_transaction_record(record)
                raise
        else:
            for target in targets:
                target.modifiers.get(name).show_viewport = not current
            changed = True
    elif action == "Edit_Toggle":
        changed = apply_mutation(lambda: (setattr(active_modifier, "show_in_editmode", not active_modifier.show_in_editmode), True)[1])
    elif action == "Cage_Toggle":
        changed = apply_mutation(lambda: (setattr(active_modifier, "show_on_cage", not active_modifier.show_on_cage), True)[1])
    elif action == "Duplicate":
        def mutate():
            duplicate = _clone_modifier(active_modifier, obj)
            if duplicate is None:
                return False
            new_index = _modifier_index(obj, duplicate)
            target_index = min(active_index + 1, len(obj.modifiers) - 1)
            if new_index != target_index:
                obj.modifiers.move(new_index, target_index)
            obj.modifiers.active = duplicate
            return True
        changed = apply_mutation(mutate)
    else:
        return {"CANCELLED"}

    return {"FINISHED"} if changed else {"CANCELLED"}


_MATERIAL_PAYLOAD_NAMESPACE = "smart_modeling.modi_key.material_slots"


def _session_uid(id_data) -> int:
    try:
        return int(id_data.session_uid)
    except Exception:
        return 0


def _material_reference(material):
    if material is None:
        return {"direct": None, "name": "", "uid": 0}
    return {
        "direct": material,
        "name": str(getattr(material, "name_full", "") or getattr(material, "name", "") or ""),
        "uid": _session_uid(material),
    }


def _resolve_material_reference(record):
    if not isinstance(record, dict):
        return None
    direct = record.get("direct")
    if direct is not None:
        try:
            direct.as_pointer()
            return direct
        except Exception:
            pass
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    if name:
        candidate = bpy.data.materials.get(name)
        if candidate is not None and (not uid or _session_uid(candidate) == uid):
            record["direct"] = candidate
            return candidate
    if uid:
        for candidate in bpy.data.materials:
            if _session_uid(candidate) == uid:
                record["direct"] = candidate
                record["name"] = str(candidate.name)
                return candidate
    return None


def _material_object_reference(obj):
    return {
        "direct": obj,
        "name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""),
        "uid": _session_uid(obj),
    }


def _resolve_material_object(record):
    if not isinstance(record, dict):
        return None
    direct = record.get("direct")
    if direct is not None:
        try:
            direct.as_pointer()
            return direct
        except Exception:
            pass
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    if name:
        candidate = bpy.data.objects.get(name)
        if candidate is not None and (not uid or _session_uid(candidate) == uid):
            record["direct"] = candidate
            return candidate
    if uid:
        for candidate in bpy.data.objects:
            if _session_uid(candidate) == uid:
                record["direct"] = candidate
                record["name"] = str(candidate.name)
                return candidate
    return None


def _material_slot_records(obj) -> list[dict]:
    records = []
    for slot in tuple(getattr(obj, "material_slots", ()) or ()):
        try:
            link = str(slot.link)
        except Exception:
            link = "DATA"
        try:
            material = slot.material
        except Exception:
            material = None
        records.append({"link": link, "material": _material_reference(material)})
    return records


def _material_face_indices(obj) -> list[int]:
    if getattr(obj, "type", "") != "MESH":
        return []
    try:
        if obj.data.is_editmode:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()
            return [int(face.material_index) for face in bm.faces]
    except Exception:
        pass
    try:
        return [int(poly.material_index) for poly in obj.data.polygons]
    except Exception:
        return []


def _capture_material_object(obj) -> dict:
    return {
        **_material_object_reference(obj),
        "slots": _material_slot_records(obj),
        "active_index": int(getattr(obj, "active_material_index", 0) or 0),
        "face_indices": _material_face_indices(obj),
    }


def _material_related_objects(objects) -> tuple:
    unique = []
    seen = set()
    requested = tuple(objects or ())
    data_blocks = set()
    for obj in requested:
        if obj is None or not hasattr(obj, "material_slots"):
            continue
        try:
            key = int(obj.as_pointer())
        except Exception:
            continue
        if key not in seen:
            seen.add(key)
            unique.append(obj)
        try:
            data = obj.data
            if data is not None and int(data.users) > 1:
                data_blocks.add(int(data.as_pointer()))
        except Exception:
            pass
    if data_blocks:
        for obj in bpy.data.objects:
            try:
                if int(obj.data.as_pointer()) not in data_blocks:
                    continue
                key = int(obj.as_pointer())
            except Exception:
                continue
            if key not in seen:
                seen.add(key)
                unique.append(obj)
    return tuple(unique)


def _capture_material_payload(objects) -> dict:
    return {"objects": [_capture_material_object(obj) for obj in _material_related_objects(objects)]}


def _apply_material_slot_records(obj, records, face_indices=None, active_index=0) -> bool:
    data = getattr(obj, "data", None)
    materials = getattr(data, "materials", None)
    if materials is None:
        return False
    resolved = []
    for record in tuple(records or ()):
        resolved.append({
            "link": str(record.get("link") or "DATA"),
            "material": _resolve_material_reference(record.get("material")),
        })
    materials.clear()
    for record in resolved:
        materials.append(record["material"])
    for index, record in enumerate(resolved):
        try:
            slot = obj.material_slots[index]
            slot.link = record["link"] if record["link"] in {"DATA", "OBJECT"} else "DATA"
            slot.material = record["material"]
        except Exception:
            pass
    count = len(resolved)
    try:
        obj.active_material_index = max(0, min(int(active_index), max(0, count - 1)))
    except Exception:
        pass
    if face_indices is not None and getattr(obj, "type", "") == "MESH":
        try:
            if obj.data.is_editmode:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.faces.ensure_lookup_table()
                for face, material_index in zip(bm.faces, face_indices):
                    face.material_index = max(0, min(int(material_index), max(0, count - 1))) if count else 0
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            else:
                for poly, material_index in zip(obj.data.polygons, face_indices):
                    poly.material_index = max(0, min(int(material_index), max(0, count - 1))) if count else 0
                obj.data.update()
        except Exception:
            return False
    return True


def _restore_material_payload(payload, _entry=None, _token=None) -> None:
    if not isinstance(payload, dict):
        return
    for record in tuple(payload.get("objects") or ()):
        obj = _resolve_material_object(record)
        if obj is None:
            continue
        _apply_material_slot_records(
            obj,
            record.get("slots") or (),
            record.get("face_indices") or (),
            record.get("active_index", 0),
        )


def _run_edit_material_transaction(context, objects, mutator) -> bool:
    active = getattr(context, "active_object", None)
    records = _undo_bridge.begin_transaction(context)
    record = _record_for_object(records, active)
    if record is None:
        return False
    tracked = _material_related_objects(objects)
    before = _capture_material_payload(tracked)
    _undo_bridge.register_payload_handler(_MATERIAL_PAYLOAD_NAMESPACE, _restore_material_payload)
    try:
        changed = bool(mutator())
        if not changed:
            _undo_bridge.rollback_transaction_record(record)
            return False
        after = _capture_material_payload(tracked)
        if not _undo_bridge.set_transaction_payload(
            record,
            _MATERIAL_PAYLOAD_NAMESPACE,
            before,
            after,
        ):
            raise RuntimeError("Unable to record the Material Slot transaction")
        bm = bmesh.from_edit_mesh(active.data)
        if not _undo_bridge.commit_transaction_record(record, _current_matrices(record), bm=bm):
            raise RuntimeError("Unable to commit the Material Slot transaction")
        return True
    except Exception:
        _restore_material_payload(before)
        _undo_bridge.rollback_transaction_record(record)
        raise


def _material_move_records(records, face_indices, source: int, target: int):
    count = len(records)
    if source < 0 or source >= count or target < 0 or target >= count or source == target:
        return None
    order = list(range(count))
    item = order.pop(source)
    order.insert(target, item)
    old_to_new = {old: new for new, old in enumerate(order)}
    moved = [records[old] for old in order]
    indices = [old_to_new.get(int(index), 0) for index in face_indices]
    return moved, indices


def _material_remove_records(records, face_indices, remove_index: int):
    if remove_index < 0 or remove_index >= len(records):
        return None
    remaining = [record for index, record in enumerate(records) if index != remove_index]
    mapped = []
    for material_index in face_indices:
        material_index = int(material_index)
        if material_index == remove_index:
            mapped.append(max(0, remove_index - 1))
        elif material_index > remove_index:
            mapped.append(material_index - 1)
        else:
            mapped.append(material_index)
    return remaining, mapped


def _material_copy_face_indices(face_indices, old_count: int, new_count: int):
    if new_count <= 0:
        return [0 for _index in face_indices]
    shift = max(0, int(old_count) - int(new_count))
    return [max(0, min(int(index) - shift, new_count - 1)) for index in face_indices]


def _execute_material_data(context, action: str):
    obj = getattr(context, "active_object", None)
    if obj is None or not hasattr(obj, "material_slots") or not hasattr(getattr(obj, "data", None), "materials"):
        return {"CANCELLED"}
    if action in _UI_ONLY_TYPES:
        try:
            bpy.ops.keyops.modi_key_no_undo(type=action)
        except Exception:
            pass
        return {"CANCELLED"}

    edit_mode = bool(getattr(context, "mode", "") == "EDIT_MESH" and getattr(obj, "type", "") == "MESH")
    slots = _material_slot_records(obj)
    face_indices = _material_face_indices(obj)
    active_index = int(getattr(obj, "active_material_index", 0) or 0)

    def perform(objects, mutator):
        if edit_mode:
            try:
                return _run_edit_material_transaction(context, objects, mutator)
            except Exception:
                return False
        return bool(mutator())

    if action == "delete":
        changed_state = _material_remove_records(slots, face_indices, active_index)
        if changed_state is None:
            return {"CANCELLED"}
        new_slots, new_indices = changed_state
        changed = perform(
            (obj,),
            lambda: _apply_material_slot_records(
                obj,
                new_slots,
                new_indices,
                min(active_index, max(0, len(new_slots) - 1)),
            ),
        )
    elif action in {"move_top", "move_bottom", "move_up", "move_down"}:
        if not slots:
            return {"CANCELLED"}
        if action == "move_top":
            target_index = 0
        elif action == "move_bottom":
            target_index = len(slots) - 1
        elif action == "move_up":
            target_index = active_index - 1
        else:
            target_index = active_index + 1
        changed_state = _material_move_records(slots, face_indices, active_index, target_index)
        if changed_state is None:
            return {"CANCELLED"}
        new_slots, new_indices = changed_state
        changed = perform(
            (obj,),
            lambda: _apply_material_slot_records(obj, new_slots, new_indices, target_index),
        )
    elif action == "Duplicate":
        new_slots = list(slots)
        new_slots.append({"link": "DATA", "material": _material_reference(None)})
        changed = perform(
            (obj,),
            lambda: _apply_material_slot_records(obj, new_slots, face_indices, len(new_slots) - 1),
        )
    elif action == "Apply" and edit_mode:
        if not slots:
            return {"CANCELLED"}
        bm = bmesh.from_edit_mesh(obj.data)
        selected = [face for face in bm.faces if face.select]
        if not selected or all(int(face.material_index) == active_index for face in selected):
            return {"CANCELLED"}
        def assign_selected():
            for face in selected:
                face.material_index = active_index
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            return True
        changed = perform((obj,), assign_selected)
    elif action == "Apply":
        targets = [
            target for target in tuple(getattr(context, "selected_editable_objects", ()) or getattr(context, "selected_objects", ()) or ())
            if target is not obj and hasattr(target, "material_slots") and hasattr(getattr(target, "data", None), "materials")
        ]
        if not targets:
            return {"CANCELLED"}
        source_records = _material_slot_records(obj)
        if not source_records:
            return {"CANCELLED"}
        changed_targets = []
        for target in targets:
            target_records = _material_slot_records(target)
            target_indices = _material_face_indices(target)
            source_signature = [(record["link"], _resolve_material_reference(record["material"])) for record in source_records]
            target_signature = [(record["link"], _resolve_material_reference(record["material"])) for record in target_records]
            if source_signature == target_signature:
                continue
            changed_targets.append((target, target_records, target_indices))
        if not changed_targets:
            return {"CANCELLED"}
        def copy_slots():
            for target, old_records, old_indices in changed_targets:
                mapped = _material_copy_face_indices(old_indices, len(old_records), len(source_records))
                if not _apply_material_slot_records(
                    target,
                    source_records,
                    mapped,
                    min(active_index, max(0, len(source_records) - 1)),
                ):
                    return False
            return True
        changed = perform([target for target, _records, _indices in changed_targets], copy_slots)
    else:
        return {"CANCELLED"}

    return {"FINISHED"} if changed else {"CANCELLED"}


class ModiKey(Operator):
    bl_idname = "keyops.modi_key"
    bl_label = "KeyOps: Modi Key"
    bl_description = ""
    # This keymap-facing dispatcher does not own an automatic Undo entry.
    # Direct RNA/BMesh modifier changes are finalized by one explicit boundary;
    # Blender's standard Apply/Material operators keep their own single entry.
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    type: bpy.props.StringProperty(name="type")  # type: ignore

    def invoke(self, context, event):
        del event
        return self.execute(context)

    def execute(self, context):
        action = str(self.type or "")
        current = _space_context(context)
        if action in _UI_ONLY_TYPES:
            return bpy.ops.keyops.modi_key_no_undo(type=action)
        if current == "MATERIAL":
            result = _execute_material_data(context, action)
            if not _result_finished(result):
                return result
            try:
                pushed = bpy.ops.ed.undo_push(message="Smart Material")
            except Exception as exc:
                self.report({"ERROR"}, f"Unable to record Material Undo state: {exc}")
                return {"CANCELLED"}
            return {"FINISHED"} if _result_finished(pushed) else {"CANCELLED"}
        if current != "MODIFIER":
            return {"CANCELLED"}

        obj, _linked = _resolve_modifier_object(context)
        edit_mode = bool(obj is not None and getattr(obj, "mode", "") == "EDIT" and getattr(obj, "type", "") == "MESH")
        result = _execute_modifier_data(self, context, action)
        if not _result_finished(result):
            return result
        if not edit_mode and action in {"Apply", "Apply_All"} and obj is not None and getattr(obj, "type", "") != "MESH":
            # Non-Mesh conversion/apply is owned by Blender's standard operator.
            return result
        try:
            pushed = bpy.ops.ed.undo_push(message="Smart Modifier")
        except Exception as exc:
            self.report({"ERROR"}, f"Unable to record modifier Undo state: {exc}")
            return {"CANCELLED"}
        return {"FINISHED"} if _result_finished(pushed) else {"CANCELLED"}


class ModiKeyNoUndo(Operator):
    bl_idname = "keyops.modi_key_no_undo"
    bl_label = "KeyOps: Modi Key No Undo"
    bl_description = ""
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    type: bpy.props.StringProperty(name="type")  # type: ignore

    def execute(self, context):
        obj = getattr(context, "active_object", None)
        current = _space_context(context)
        action = str(self.type)

        if action == "Toggle_Space":
            if obj is None:
                return {"CANCELLED"}
            target = None
            if obj.type in {"MESH", "CURVE", "SURFACE", "META", "FONT"}:
                target = "MODIFIER" if current != "MODIFIER" else "DATA"
            elif obj.type == "LIGHT":
                target = "DATA" if current != "DATA" else "OBJECT"
            if target is None or target == current:
                return {"CANCELLED"}
            context.space_data.context = target
            return {"FINISHED"}

        if action == "Material_Tab":
            if obj is None or obj.type not in {"MESH", "CURVE", "SURFACE", "META", "FONT"} or current == "MATERIAL":
                return {"CANCELLED"}
            context.space_data.context = "MATERIAL"
            return {"FINISHED"}

        if current == "MODIFIER":
            obj, _linked = _resolve_modifier_object(context)
            if obj is None:
                return {"CANCELLED"}
            active = _active_modifier(obj)
            if active is None:
                return {"CANCELLED"}
            index = _modifier_index(obj, active)
            target = index
            if action == "select_up" and index > 0:
                target = index - 1
            elif action == "select_down" and index < len(obj.modifiers) - 1:
                target = index + 1
            elif action == "select_top" and index > 0:
                target = 0
            elif action == "select_bottom" and index < len(obj.modifiers) - 1:
                target = len(obj.modifiers) - 1
            else:
                return {"CANCELLED"}
            obj.modifiers.active = obj.modifiers[target]
            return {"FINISHED"}

        if current == "MATERIAL" and obj is not None:
            count = len(obj.material_slots)
            if count <= 0:
                return {"CANCELLED"}
            index = int(obj.active_material_index)
            target = index
            if action == "select_up" and index > 0:
                target = index - 1
            elif action == "select_down" and index < count - 1:
                target = index + 1
            elif action == "select_top" and index > 0:
                target = 0
            elif action == "select_bottom" and index < count - 1:
                target = count - 1
            else:
                return {"CANCELLED"}
            obj.active_material_index = target
            return {"FINISHED"}

        return {"CANCELLED"}
