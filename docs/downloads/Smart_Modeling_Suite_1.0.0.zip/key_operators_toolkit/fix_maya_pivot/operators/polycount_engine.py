"""Count the evaluated geometry owned by each row in the polygon list."""
from bpy.types import Object

_COUNTABLE = frozenset(("MESH", "CURVE", "FONT", "SURFACE", "META"))
_COLUMNS = {"NAME": 0, "TRIS": 1, "VERT": 2, "VERTS": 2, "EDGE": 3, "EDGES": 3, "FACE": 4, "FACES": 4}


def row_key(row, column):
    index = _COLUMNS.get(column, 1)
    value = row[index]
    return value.casefold() if index == 0 else value


def order_rows(rows, column, flip):
    rows.sort(key=lambda row: row_key(row, column), reverse=not flip if column == "NAME" else flip)


def _objects(context, settings):
    if settings.polycount_use_selection_only:
        return context.selected_objects
    if settings.filter_by == "VISIBLE":
        return context.visible_objects
    if settings.filter_by == "COLLECTION":
        return (settings.my_collection or context.collection).objects
    return context.view_layer.objects if settings.show_only_enabled_collections else context.scene.objects


def _mesh_counts(obj, graph):
    evaluated = obj.evaluated_get(graph)
    mesh = evaluated.to_mesh()
    if mesh is None:
        return None
    try:
        return tuple(map(len, (mesh.loop_triangles, mesh.vertices, mesh.edges, mesh.polygons)))
    finally:
        evaluated.to_mesh_clear()


def count_rows(context, settings):
    graph = context.evaluated_depsgraph_get()
    measured: dict[Object, tuple[int, int, int, int] | None] = {}

    def lookup(obj):
        if obj not in measured:
            measured[obj] = _mesh_counts(obj, graph)
        return measured[obj]

    def selected(obj):
        return obj.select_get(view_layer=context.view_layer)

    rows = []
    objects = tuple(_objects(context, settings))
    for obj in objects:
        if obj.type in _COUNTABLE:
            counts = lookup(obj)
            if counts is not None:
                rows.append((obj.name, *counts, selected(obj)))
        elif (settings.show_collection_instances and obj.instance_type == "COLLECTION" and
              obj.instance_collection is not None):
            values = [lookup(child) for child in obj.instance_collection.objects if child.type in _COUNTABLE]
            totals = tuple(map(sum, zip(*(item for item in values if item is not None)))) or (0, 0, 0, 0)
            rows.append((obj.name, *totals, selected(obj)))
    return rows
