# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Maintain the manual shortcut policy for all retained navigation callbacks."""


def _leave_keymaps_as_configured():
    """Existing keymap choices belong to the Blender user."""


def add_tablet_navigation():
    _leave_keymaps_as_configured()


def remove_tablet_navigation():
    _leave_keymaps_as_configured()


def update_tablet_navigation(self, context):
    _leave_keymaps_as_configured()
