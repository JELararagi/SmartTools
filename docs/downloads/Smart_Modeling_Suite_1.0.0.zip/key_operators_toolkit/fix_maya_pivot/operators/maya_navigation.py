def add_tablet_navigation():
    # Manual-only policy: do not add tablet navigation keymaps automatically.
    return None


def remove_tablet_navigation():
    # Do not modify user/active keymaps. Older addon-created entries can be
    # removed manually in Blender Preferences if the user previously created them.
    return None


def update_tablet_navigation(self, context):
    return None
