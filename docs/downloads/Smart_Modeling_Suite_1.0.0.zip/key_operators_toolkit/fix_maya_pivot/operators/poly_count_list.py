"""Interactive view of the Smart Modeling evaluated-mesh counts."""
import bpy
from bpy.app.translations import pgettext_iface, pgettext_tip
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty, StringProperty

from ....utils import draw_section_help
from .persistence_bridge import persistent_property
from .polycount_engine import count_rows, order_rows, row_key


_BOOL = persistent_property(BoolProperty)
_ENUM = persistent_property(EnumProperty)
_INT = persistent_property(IntProperty)
_POINTER = persistent_property(PointerProperty)

_COLUMNS = (
    ("TRIS", "TRIS", "Tri", "Tris", "MESH_DATA", 1, 1),
    ("VERT", "VERTS", "Verts", "Vert", "VERTEXSEL", 2, 2),
    ("EDGE", "EDGES", "Edges", "Edge", "EDGESEL", 4, 3),
    ("FACE", "FACE", "Face", "Face", "FACESEL", 8, 4),
)
_SORT = "keyops.polycount_user_interaction"
_UNDO = {"SKIP_SAVE"}
_ICONS = {
    "MESH": "OUTLINER_OB_MESH", "CURVE": "OUTLINER_OB_CURVE",
    "FONT": "OUTLINER_OB_FONT", "SURFACE": "OUTLINER_OB_SURFACE",
    "META": "OUTLINER_OB_META", "EMPTY": "OUTLINER_OB_EMPTY",
    "CAMERA": "OUTLINER_OB_CAMERA", "LIGHT": "OUTLINER_OB_LIGHT",
    "ARMATURE": "OUTLINER_OB_ARMATURE", "LATTICE": "OUTLINER_OB_LATTICE",
    "SPEAKER": "OUTLINER_OB_SPEAKER", "LIGHT_PROBE": "OUTLINER_OB_LIGHTPROBE",
}

polycount = []
polycount_sorting = "TRIS"
polycount_sorting_ascending = True
total_tris = 0


class PolyCountProperties(bpy.types.PropertyGroup):
    polycount_use_selection_only: _BOOL(name="Use selected only", description="Compute stats only for selected objects")
    auto_update_polycount: _BOOL(
        name="Auto Update",
        description="Refresh the list when the panel is redrawn, but only while the top-level Key Operation Tools always-on switch is enabled. Leave disabled for zero-cost ordinary use.")
    filter_list_show: _ENUM(
        name="List Show", description="Show",
        items=tuple((key, label, label, icon, value) for key, _, _, label, icon, value, _ in _COLUMNS),
        options={"ENUM_FLAG"}, default={"TRIS", "VERT", "FACE"})
    show_total_tris: _BOOL(name="Show Total Tris", description="Show Total Tris in the list", default=True)
    filter_by: _ENUM(name="Filter", description="Filter",
                     items=(("ALL", "All", "", "NONE", 0),
                            ("VISIBLE", "Visible", "", "HIDE_OFF", 1),
                            ("COLLECTION", "Collection", "", "OUTLINER_COLLECTION", 2)),
                     default="ALL")
    my_collection: _POINTER(name="Collection", type=bpy.types.Collection)
    round_numbers: _BOOL(name="Round Numbers", description="Round the numbers, slower, but more readable", default=True)
    show_only_enabled_collections: _BOOL(name="Show Only Enabled Collections", default=True)
    show_collection_instances: _BOOL(name="Show Collection Instances")
    show_obj_type: _BOOL(name="Show Object Type")
    max_list_length: _INT(name="Max List Length", description="Maximum number of objects to show in the list",
                          default=500, min=1)


def _polycount_live_refresh_enabled(context):
    settings = getattr(context.scene, "polycount_props", None)
    switches = getattr(context.window_manager, "smart_modeling_suite_npanel_settings", None)
    return bool(settings is not None and settings.auto_update_polycount and
                getattr(switches, "enable_tool_key_operators_toolkit", False))


def get_poly_count(context):
    global total_tris
    rows = count_rows(context, context.scene.polycount_props)
    order_rows(rows, polycount_sorting, polycount_sorting_ascending)
    total_tris = sum(row[1] for row in rows)
    return rows


def refresh_rows(context):
    polycount[:] = get_poly_count(context)


def sortList(item):
    return row_key(item, polycount_sorting)


def deselect_all(context):
    for obj in tuple(context.selected_objects):
        obj.select_set(False, view_layer=context.view_layer)


def trim_numbers(number):
    if number < 1000:
        return str(number)
    divisor, suffix = (1000, "k") if number < 1000000 else (1000000, "m")
    return f"{number / divisor:,.2f}{suffix}".replace(",", " ")


class PolyCountList(bpy.types.Operator):
    bl_idname = "keyops.poly_count_list"
    bl_label = "Poly Count List"
    bl_description = "Refresh the polycount list, only needed if auto update is off"
    _sms_no_undo = True

    def execute(self, context):
        refresh_rows(context)
        return {"FINISHED"}

    @staticmethod
    def register():
        for cls in _HELPERS:
            if not cls.is_registered:
                bpy.utils.register_class(cls)
        if not hasattr(bpy.types.Scene, "polycount_props"):
            bpy.types.Scene.polycount_props = PointerProperty(type=PolyCountProperties)

    @staticmethod
    def unregister():
        if not bpy.app.driver_namespace.get("SMART_MODELING_SUITE_SHUTTING_DOWN", False):
            return
        if hasattr(bpy.types.Scene, "polycount_props"):
            del bpy.types.Scene.polycount_props
        for cls in reversed(_HELPERS):
            if cls.is_registered:
                bpy.utils.unregister_class(cls)
        polycount.clear()


class POLYCOUNT_OT_refresh(bpy.types.Operator):
    bl_idname = "keyops.polycount_user_interaction"
    bl_label = "Show polycount in Scene properties panel"
    bl_description = "Object Name"
    _sms_no_undo = True

    make_active: StringProperty(options=_UNDO)
    poly_sort: EnumProperty(
        items=(("NAME", "Name", ""), *tuple((key, title, "") for _, key, _, title, _, _, _ in _COLUMNS)),
        default="TRIS", options=_UNDO)
    refresh: BoolProperty(options=_UNDO)

    @classmethod
    def poll(cls, context):
        return bool(context.view_layer.objects)

    def invoke(self, context, event):
        if self.make_active and not self.refresh:
            return self.select_row(context, extend=event.shift, toggle=event.ctrl)
        return self.execute(context)

    def select_row(self, context, *, extend=False, toggle=False):
        objects = context.view_layer.objects
        obj = objects.get(self.make_active)
        if obj is None or context.mode != "OBJECT" or not obj.visible_get(view_layer=context.view_layer):
            self.report({"WARNING"}, pgettext_tip("Object not in an enabled collection or view layer"))
            return {"CANCELLED"}
        if toggle:
            obj.select_set(not obj.select_get(view_layer=context.view_layer), view_layer=context.view_layer)
        else:
            if not extend:
                deselect_all(context)
            obj.select_set(True, view_layer=context.view_layer)
            objects.active = obj
        if context.area is not None:
            context.area.tag_redraw()
        return {"FINISHED"}

    def execute(self, context):
        global polycount_sorting, polycount_sorting_ascending
        if self.refresh:
            refresh_rows(context)
        elif self.make_active:
            return self.select_row(context)
        else:
            if self.poly_sort == polycount_sorting:
                polycount_sorting_ascending = not polycount_sorting_ascending
            polycount_sorting = self.poly_sort
            order_rows(polycount, polycount_sorting, polycount_sorting_ascending)
        return {"FINISHED"}


class KEYOPS_PT_poly_count_list_panel(bpy.types.Panel):
    bl_idname = "KEYOPS_PT_poly_count_list_panel"
    bl_label = "Polycount List"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Modeling"
    bl_context = "scene"

    def draw(self, context):
        layout, settings = self.layout, context.scene.polycount_props
        live = _polycount_live_refresh_enabled(context)
        if live:
            refresh_rows(context)
        format_count = trim_numbers if settings.round_numbers else lambda n: f"{n:,}"
        if settings.show_total_tris:
            layout.label(text=f'{pgettext_iface("Total Tris")}: {format_count(total_tris)}', translate=False)
        if live and len(polycount) > 500:
            layout.label(text="Warning: > 500 objects, might be slow with auto update", icon="ERROR")

        controls = layout.row(align=True)
        controls.prop(settings, "auto_update_polycount", text="Auto", icon="FILE_REFRESH")
        controls.operator("keyops.poly_count_list", text="Refresh")
        controls.popover(panel="POLYCOUNTILST_PT_Settings", icon="FILTER", text="")
        layout.prop(settings, "polycount_use_selection_only", text="Only selected", icon="RESTRICT_SELECT_OFF")

        rendered = [(sort, title, index) for key, sort, title, _, _, _, index in _COLUMNS
                    if key in settings.filter_list_show]
        table = layout.column(align=True)
        header = table.row(align=True)
        for sort, title in [("NAME", "Name"), *((sort, title) for sort, title, _ in rendered)]:
            icon = "NONE"
            if sort == polycount_sorting:
                icon = "TRIA_DOWN" if polycount_sorting_ascending else "TRIA_UP"
            header.operator(_SORT, text=title, icon=icon).poly_sort = sort
        draw_section_help(header, "keyops_polycount_sort")

        objects = context.view_layer.objects
        for values in polycount[:settings.max_list_length]:
            name = values[0]
            obj = objects.get(name)
            selected = obj is not None and obj.select_get(view_layer=context.view_layer)
            icon = "NONE"
            if settings.show_obj_type and obj is not None:
                icon = ("OUTLINER_COLLECTION" if obj.instance_type == "COLLECTION" else
                        _ICONS.get(obj.type, "OBJECT_DATAMODE"))
            entry = table.row(align=True)
            entry.operator(_SORT, text=name, icon=icon, depress=selected, translate=False).make_active = name
            for _, _, index in rendered:
                entry.label(text=format_count(values[index]), translate=False)
        if len(polycount) > settings.max_list_length:
            info = layout.row(align=True)
            info.label(text="Max List Length Reached", icon="QUESTION")
            info.prop(settings, "max_list_length", text="Current:")


class POLYCOUNTILST_PT_Settings(bpy.types.Panel):
    bl_idname = "POLYCOUNTILST_PT_Settings"
    bl_label = "Polycount Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_section_help(self.layout, "keyops_polycount_settings")

    def draw(self, context):
        layout, settings = self.layout, context.scene.polycount_props
        layout.label(text="Filter by:")
        column_buttons = layout.grid_flow(columns=2, align=True)
        for key, _, _, _, icon, _, _ in _COLUMNS:
            column_buttons.prop_enum(settings, "filter_list_show", key, icon=icon)
        display = layout.column(align=True)
        display.prop(settings, "show_total_tris", text="Total Tris")
        display.prop(settings, "round_numbers")
        display.prop(settings, "show_obj_type")
        display.prop(settings, "max_list_length")
        filters = layout.column(align=True)
        filters.label(text="Filter Objects by:")
        filters.prop(settings, "filter_by", expand=True)
        if settings.filter_by == "ALL":
            filters.prop(settings, "show_only_enabled_collections")
        elif settings.filter_by == "VISIBLE":
            filters.label(text="Only Visible Objects are Now Shown")
        else:
            filters.prop(settings, "my_collection", text="Custom")
        filters.prop(settings, "show_collection_instances", text="Include Collection Instances")


class POLYCOUNT_PT_AutoUpdate_Settings(bpy.types.Panel):
    bl_idname = "POLYCOUNT_PT_AutoUpdate_Settings"
    bl_label = "Auto Update Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_section_help(self.layout, "keyops_polycount_auto_update")

    def draw(self, context):
        self.layout.prop(context.scene.polycount_props, "auto_update_polycount")


_HELPERS = (PolyCountProperties, KEYOPS_PT_poly_count_list_panel, POLYCOUNT_OT_refresh, POLYCOUNTILST_PT_Settings)
