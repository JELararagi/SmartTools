# Based on the excellent Polycount Addon by Vinc3r
# https://github.com/Vinc3r/Polycount
# I used this addon a lot and really liked it, but I feelt it could be improved in terms of performance, ui and usability when working in big production scenes.
# Its now about 1000-5000x times faster than the original addon, it has a realtime mode by defualt and more streamlined ui along with some new features.
""""
TODO:
auto refresh option - DONE
fix category can't be set as defaults - DONE
dont refresh when just selecting an object in name mode - DONE
total poly count - DONE
Does not work correclty in edit modes, skips counting object if in edit mode - DONE
Cant select objects from list in edit mode - DONE

Show both selected objects and active object in list - DONE
Option to show by Collection in List Category - DONE
Option to Limit to a Collection or Collections - DONE
Show the object type icon in the list - DONE
Show poly count for instaced collections - DONE
Max UI length, if more than x objects - DONE
Smarter update, Only update on dependency graph change? Option - 
Update once every x ms? Option - 
Limit to only update the selected objects, keep the rest in global polycount cache, dont clear the list -
"""

import bpy
from ....utils import draw_section_help
from bpy.types import PropertyGroup
from bpy.props import (EnumProperty, BoolProperty, StringProperty, PointerProperty, IntProperty)
from .persistence_bridge import persistent_property

_PersistEnumProperty = persistent_property(EnumProperty)
_PersistBoolProperty = persistent_property(BoolProperty)
_PersistPointerProperty = persistent_property(PointerProperty)
_PersistIntProperty = persistent_property(IntProperty)

polycount = []
polycount_sorting_ascending = True
polycount_sorting = 'TRIS'
ev = []
total_tris = 0

class PolyCountProperties(PropertyGroup):
    polycount_use_selection_only: _PersistBoolProperty(  # type: ignore
        name="Use selected only",
        description="Compute stats only for selected objects",
        default=False
    )
    auto_update_polycount: _PersistBoolProperty(  # type: ignore
        name="Auto Update",
        description="Refresh the list when the panel is redrawn, but only while the top-level Key Operation Tools always-on switch is enabled. Leave disabled for zero-cost ordinary use.",
        default=False
    )
    filter_list_show: _PersistEnumProperty(  # type: ignore
        name="List Show",
        description="Show",
        items=[
            ('TRIS', "Tris", "Tris", 'MESH_DATA', 1),
            ('VERT', "Vert", "Vert", 'VERTEXSEL', 2),
            ('EDGE', "Edge", "Edge", 'EDGESEL', 4),
            ('FACE', "Face", "Face", 'FACESEL', 8)
        ],
        options={'ENUM_FLAG'},
        default={'TRIS', 'VERT', 'FACE'}
    )
    show_total_tris: _PersistBoolProperty(  # type: ignore
        name="Show Total Tris",
        description="Show Total Tris in the list",
        default=True
    )
    filter_by: _PersistEnumProperty(  # type: ignore
        name="Filter",
        description="Filter",
        items=[
            ('ALL', "All", "", 'NONE', 0),
            ('VISIBLE', "Visible", "", 'HIDE_OFF', 1),
            ('COLLECTION', "Collection", "", '', 2)
        ],
        default='ALL'
    )
    my_collection: _PersistPointerProperty(name="Collection",type=bpy.types.Collection)  # type: ignore

    round_numbers: _PersistBoolProperty(  # type: ignore
        name="Round Numbers",
        description="Round the numbers, slower, but more readable",
        default=True
    )
    show_only_enabled_collections: _PersistBoolProperty(  # type: ignore
        name="Show Only Enabled Collections",
        description="Show only enabled collections",
        default=True
    )
    show_collection_instances: _PersistBoolProperty(  # type: ignore
        name="Show Collection Instances",
        description="Show collection instances",
        default=False
    )
    show_obj_type: _PersistBoolProperty(  # type: ignore
        name="Show Object Type",
        description="Warning: Slow in big scenes, shows the icon of the object type",
        default=False
    )
    max_list_length: _PersistIntProperty(  # type: ignore
        name="Max List Length",
        description="Maximum number of objects to show in the list",
        default=500,
        min=1
    )

def deselect_all(context):
    for obj in context.scene.objects:
        if obj.select_get():
            obj.select_set(False)
        
def sortList(item):
    if polycount_sorting == 'NAME':
        return item[0].casefold()
    elif polycount_sorting == 'TRIS':
        return item[1]
    elif polycount_sorting == 'VERTS':
        return item[2]
    elif polycount_sorting == 'EDGES':
        return item[3]
    elif polycount_sorting == 'FACES':
        return item[4]
    else:
        return item[1]

def get_poly_count(context):
    selection = None
    global total_tris
    c = context
    props = c.scene.polycount_props

    if props.filter_by == 'ALL':
        if props.show_only_enabled_collections:
            filter_type = c.view_layer.objects
        else:
            filter_type = c.scene.objects
    if props.filter_by == 'VISIBLE':
        filter_type = c.visible_objects
    if props.filter_by == 'COLLECTION':
        if props.my_collection is None:
            filter_type = c.collection.objects
        else:
            filter_type = bpy.data.collections[props.my_collection.name].objects
    if props.polycount_use_selection_only:
        filter_type = c.selected_objects

    selection = [obj for obj in filter_type if obj.type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}]

    # import time
    # start = time.time()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    show_collection_instances = props.show_collection_instances
    # replace mesh cache with just global polycount cache
    mesh_cache = {}

    if not show_collection_instances:
        for obj in selection:
            eval_obj = obj.evaluated_get(depsgraph)
            m = eval_obj.to_mesh()
            if m is not None:
                try:
                    tris = len(m.loop_triangles)
                    verts = len(m.vertices)
                    edges = len(m.edges)
                    faces = len(m.polygons)
                    total_tris += tris
                    selected = obj.select_get()
                    yield obj.name, tris, verts, edges, faces, selected
                finally:
                    eval_obj.to_mesh_clear()
                
    else:
        for obj in selection:
            eval_obj = obj.evaluated_get(depsgraph)
            if obj.name not in mesh_cache:
                m = eval_obj.to_mesh()
                if m is not None:
                    try:
                        mesh_cache[obj.name] = (len(m.loop_triangles), len(m.vertices), len(m.edges), len(m.polygons))
                    finally:
                        eval_obj.to_mesh_clear()
    
            if obj.name in mesh_cache:
                tris, verts, edges, faces = mesh_cache[obj.name]
                total_tris += tris
                selected = obj.select_get()
                yield obj.name, tris, verts, edges, faces, selected

        for obj in c.scene.objects:
            if obj.instance_type == 'COLLECTION' and obj.instance_collection:
                collection_instance_name = obj.name
                collection_tris = 0
                collection_verts = 0
                collection_edges = 0
                collection_faces = 0
                collection_selected = obj.select_get()

                for ob_col in obj.instance_collection.objects:
                    if ob_col.type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}:
                        eval_obj = ob_col.evaluated_get(depsgraph)
                        if ob_col.name not in mesh_cache:
                            m = eval_obj.to_mesh()
                            if m is not None:
                                mesh_cache[ob_col.name] = (len(m.loop_triangles), len(m.vertices), len(m.edges), len(m.polygons))
                                eval_obj.to_mesh_clear()
                        if ob_col.name in mesh_cache:
                            tris, verts, edges, faces = mesh_cache[ob_col.name]
                            collection_tris += tris
                            collection_verts += verts
                            collection_edges += edges
                            collection_faces += faces

                yield collection_instance_name, collection_tris, collection_verts, collection_edges, collection_faces, collection_selected
    # print(time.time() - start)  

    if polycount_sorting == 'NAME':
        name_ascending = not polycount_sorting_ascending
        polycount.sort(key=sortList, reverse=name_ascending)
    else:
        polycount.sort(key=sortList, reverse=polycount_sorting_ascending)

    total_tris = 0
    for obj in polycount:
        total_tris += obj[1]

    return {'FINISHED'}


def _polycount_live_refresh_enabled(context) -> bool:
    """Return whether the two explicit always-on gates authorize live scans.

    ``auto_update_polycount`` existed before Smart Modeling gained its unified
    top-level runtime controls.  Old files can therefore contain it as True.
    Requiring the canonical Key Operation Tools switch as well guarantees that
    all top-level always-on switches OFF means no scene/evaluated-mesh scan from
    an ordinary N-panel redraw, including for those legacy files.
    """
    try:
        scene = getattr(context, "scene", None)
        local = bool(getattr(getattr(scene, "polycount_props", None), "auto_update_polycount", False))
        wm = getattr(context, "window_manager", None)
        suite = getattr(wm, "smart_modeling_suite_npanel_settings", None)
        master = bool(getattr(suite, "enable_tool_key_operators_toolkit", False))
        return bool(local and master)
    except Exception:
        return False

class PolyCountList(bpy.types.Operator):
    bl_idname = "keyops.poly_count_list"
    bl_label = "Poly Count List"
    bl_description = "Refresh the polycount list, only needed if auto update is off"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        global polycount
        polycount.clear()
        for ob in get_poly_count(context):
            polycount.append(ob)
        return {'FINISHED'}
    
    def register():
        # The settings owner must exist even when the optional Polycount UI is
        # disabled.  Otherwise a saved OFF state prevents its own RNA from
        # being reconstructed after a full Suite disable/re-enable cycle.
        # Registration may be reached both from module startup and Blender's
        # Operator.register callback, so every step is intentionally
        # idempotent.
        for cls in (
            PolyCountProperties,
            KEYOPS_PT_poly_count_list_panel,
            POLYCOUNT_OT_refresh,
            POLYCOUNTILST_PT_Settings,
        ):
            try:
                registered = getattr(bpy.types, cls.__name__, None)
            except Exception:
                registered = None
            if registered is cls:
                continue
            try:
                bpy.utils.register_class(cls)
            except Exception:
                pass
        if not hasattr(bpy.types.Scene, "polycount_props"):
            bpy.types.Scene.polycount_props = PointerProperty(type=PolyCountProperties)
        # bpy.utils.register_class(POLYCOUNT_PT_AutoUpdate_Settings)

    def unregister():
        # Disabling only the optional Polycount UI must not destroy its durable
        # settings owner; otherwise an OFF value cannot be restored or edited
        # after restart.  Full Suite/loader teardown sets this flag and removes
        # every helper and RNA root symmetrically.
        try:
            shutting_down = bool(
                bpy.app.driver_namespace.get('SMART_MODELING_SUITE_SHUTTING_DOWN', False)
            )
        except Exception:
            shutting_down = False
        if not shutting_down:
            return
        for cls in (POLYCOUNTILST_PT_Settings, POLYCOUNT_OT_refresh, KEYOPS_PT_poly_count_list_panel):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        try:
            del bpy.types.Scene.polycount_props
        except Exception:
            pass
        try:
            bpy.utils.unregister_class(PolyCountProperties)
        except Exception:
            pass

class KEYOPS_PT_poly_count_list_panel(bpy.types.Panel):
    bl_label = "Polycount List"
    bl_idname = "KEYOPS_PT_poly_count_list_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        global polycount_sorting_ascending
        global polycount_sorting
        global polycount
        global total_tris

        props = context.scene.polycount_props

        if _polycount_live_refresh_enabled(context):
            polycount.clear()
            for ob in get_poly_count(context):
                polycount.append(ob)

        if props.show_total_tris:
            row = layout.row(align=True)
            if props.round_numbers:
                row.label(text=bpy.app.translations.pgettext_iface("Total Tris") + ": {}".format(trim_numbers(total_tris)), translate=False)
            else:
                row.label(text=bpy.app.translations.pgettext_iface("Total Tris") + ": " + "{:,}".format(total_tris), translate=False)

        row = layout.row(align=True)
        if len(polycount) > 500 and _polycount_live_refresh_enabled(context):
            row.label(text="Warning: > 500 objects, might be slow with auto update", icon="ERROR")

        row = layout.row(align=True)
        row.prop(props, "auto_update_polycount", text="Auto", icon="FILE_REFRESH", toggle=False)
        # row.popover(panel="POLYCOUNT_PT_AutoUpdate_Settings", icon="PREFERENCES", text="")
        row.operator("keyops.poly_count_list", text="Refresh", icon="FILE_REFRESH")
        row.popover(panel="POLYCOUNTILST_PT_Settings", icon="FILTER", text="")
        layout.prop(props, "polycount_use_selection_only", text="Only selected", icon="RESTRICT_SELECT_OFF", toggle=False)

        col_flow = layout.column_flow(columns=0, align=True)
        row = col_flow.row(align=True)

        if polycount_sorting == 'NAME':
            if polycount_sorting_ascending:
                row.operator("keyops.polycount_user_interaction", text="Name", icon="TRIA_DOWN").poly_sort = 'NAME'
            else:
                row.operator("keyops.polycount_user_interaction", text="Name", icon="TRIA_UP").poly_sort = 'NAME'
        else:
            row.operator("keyops.polycount_user_interaction", text="Name").poly_sort = 'NAME'

        if 'TRIS' in props.filter_list_show:
            if polycount_sorting == 'TRIS':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Tri", icon="TRIA_DOWN").poly_sort = 'TRIS'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Tri", icon="TRIA_UP").poly_sort = 'TRIS'
            else:
                row.operator("keyops.polycount_user_interaction", text="Tri").poly_sort = 'TRIS'

        if 'VERT' in props.filter_list_show:
            if polycount_sorting == 'VERTS':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Verts", icon="TRIA_DOWN").poly_sort = 'VERTS'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Verts", icon="TRIA_UP").poly_sort = 'VERTS'
            else:
                row.operator("keyops.polycount_user_interaction", text="Verts").poly_sort = 'VERTS'

        if 'EDGE' in props.filter_list_show:
            if polycount_sorting == 'EDGES':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Edges", icon="TRIA_DOWN").poly_sort = 'EDGES'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Edges", icon="TRIA_UP").poly_sort = 'EDGES'
            else:
                row.operator("keyops.polycount_user_interaction", text="Edges").poly_sort = 'EDGES'

        if 'FACE' in props.filter_list_show:
            if polycount_sorting == 'FACE':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Face", icon="TRIA_DOWN").poly_sort = 'FACE'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Face", icon="TRIA_UP").poly_sort = 'FACE'
            else:
                row.operator("keyops.polycount_user_interaction", text="Face").poly_sort = 'FACE'
        draw_section_help(row, "keyops_polycount_sort")
        # import time
        # start = time.time()
        if len(polycount) > 0:
            filter_list_show = props.filter_list_show
            round_numbers = props.round_numbers
            show_collection_instances = props.show_collection_instances
            show_obj_type = props.show_obj_type

            max_list_length = props.max_list_length
            for i, obj in enumerate(polycount):
                if i >= max_list_length:
                    break

                row = col_flow.row(align=True)
                selected = obj[5]

                if show_obj_type:
                    obj_name = obj[0]
                    obj_data = bpy.data.objects.get(obj_name)
                    object_type = obj_data.type if obj_data else 'OBJECT'
                    
                    # Check if the object is an instanced collection
                    if show_collection_instances and obj_data.instance_type == 'COLLECTION':
                        icon = 'OUTLINER_COLLECTION'
                    else:
                        icon = 'OUTLINER_OB_' + object_type if object_type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META', 'ARMATURE', 'CAMERA', 'LIGHT', 'LATTICE', 'EMPTY', 'SPEAKER', 'LIGHT_PROBE'} else 'OBJECT_DATAMODE'
        
                    row.operator("keyops.polycount_user_interaction", text=str(obj_name), icon=icon, depress=selected).make_active = obj_name
                else:
                    row.operator("keyops.polycount_user_interaction", text=str(obj[0]), depress=selected).make_active = obj[0]

                if 'TRIS' in filter_list_show:
                    tris_number = trim_numbers(obj[1]) if round_numbers else str("{:,.0f}".format(obj[1]))
                    row.label(text=tris_number)
                if 'VERT' in filter_list_show:
                    verts_number = trim_numbers(obj[2]) if round_numbers else str("{:,.0f}".format(obj[2]))
                    row.label(text=verts_number)
                if 'EDGE' in filter_list_show:
                    edge_number = trim_numbers(obj[3]) if round_numbers else str("{:,.0f}".format(obj[3]))
                    row.label(text=edge_number)
                if 'FACE' in filter_list_show:
                    faces_number = trim_numbers(obj[4]) if round_numbers else str("{:,.0f}".format(obj[4]))
                    row.label(text=faces_number)
                
                #add reached max list length warning
                if i == max_list_length - 1:
                    row = col_flow.row(align=True)
                    row.alignment = 'LEFT'
                    row.label(text="Max List Length Reached", icon="QUESTION")
                    row.prop(props, "max_list_length", text="Current:")
            # print(time.time() - start)

class POLYCOUNTILST_PT_Settings(bpy.types.Panel):
    bl_label = "Polycount Settings"
    bl_idname = "POLYCOUNTILST_PT_Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        draw_section_help(self.layout, "keyops_polycount_settings")

    def draw(self, context):
        layout = self.layout
        props = context.scene.polycount_props

        row = layout.row()
        row.label(text="Filter by:")
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop_enum(props, "filter_list_show", 'TRIS', icon='MESH_DATA')
        row.prop_enum(props, "filter_list_show", 'VERT', icon='VERTEXSEL')
        row = col.row(align=True)
        row.prop_enum(props, "filter_list_show", 'EDGE', icon='EDGESEL')
        row.prop_enum(props, "filter_list_show", 'FACE', icon='FACESEL')

        row = layout.row()
        row.label(text="Show:")
        layout.prop(props, "show_total_tris", text="Total Tris")
        layout.prop(props, "round_numbers", text="Round Numbers")
        layout.prop(props, "show_obj_type", text="Object Type")
        layout.label(text="Max List Length:")
        layout.prop(props, "max_list_length", text="")
        layout.label(text="Filter Objects by:")
        layout.column(align=True).prop(props, "filter_by", text="Object Visible", expand=True)

        if props.filter_by == 'ALL':
            row = layout.row()
            row.prop(props, "show_only_enabled_collections", text="Show Only Enabled Collections")

        if props.filter_by == 'VISIBLE':
            row = layout.row()
            row.label(text="Only Visible Objects are Now Shown")

        if props.filter_by == 'COLLECTION':
            row = layout.row()
            row.prop(props, "my_collection", text="Custom")
            row = layout.row()
            row.prop(props, "show_collection_instances", text="Include Collection Instances")

class POLYCOUNT_PT_AutoUpdate_Settings(bpy.types.Panel):
    bl_label = "Auto Update Settings"
    bl_idname = "POLYCOUNT_PT_AutoUpdate_Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        draw_section_help(self.layout, "keyops_polycount_auto_update")

    def draw(self, context):
        layout = self.layout
        props = context.scene.polycount_props

        row = layout.row()
        row.label(text="Auto Update Settings:")
        row = layout.row()
        row.prop(props, "auto_update_polycount", text="Auto Update")

class POLYCOUNT_OT_refresh(bpy.types.Operator):
    bl_idname = "keyops.polycount_user_interaction"
    bl_label = "Show polycount in Scene properties panel"
    bl_options = set()
    _sms_no_undo = True
    bl_description = "Object Name"
    make_active: StringProperty(default="") # type: ignore
    poly_sort: EnumProperty(
        items=[
            ('NAME', "Name", ""),
            ('VERTS', "Verts", ""),
            ('EDGES', "Edges", ""),
            ('FACE', "Faces", ""),
            ('TRIS', "Tris", "")
        ], default='TRIS'
    ) # type: ignore
    refresh: BoolProperty(default=False) # type: ignore

    @classmethod
    def poll(cls, context):
        return len(context.view_layer.objects) > 0
    def invoke(self, context, event):
        global ev
        ev = []
        if event.shift:
            ev.append("Shift")
        if event.ctrl:
            ev.append("Ctrl")
        ev.append("Click")
        return self.execute(context)

    def execute(self, context):
        global polycount_sorting_ascending
        global polycount_sorting

        if self.refresh:
            self.refresh = False
            pass
        else:
            if self.make_active != "" and bpy.data.objects.get(str(self.make_active)) is not None:
                if context.mode == 'OBJECT':
                    if ev == ["Shift", "Click"]:
                        context.view_layer.objects.active = bpy.data.objects[str(self.make_active)]
                        context.view_layer.objects.active.select_set(True)
                    elif "Ctrl" in ev:
                        obj = bpy.data.objects[str(self.make_active)]
                        obj.select_set(not obj.select_get())
                    else:
                        deselect_all(context)
                        context.view_layer.objects.active = bpy.data.objects[str(self.make_active)]
                        context.view_layer.objects.active.select_set(True)
                else:
                    self.report({'WARNING'}, "Object not in an enabled collection or view layer")
            else:
                if self.poly_sort == polycount_sorting:
                    polycount_sorting_ascending = not polycount_sorting_ascending
                else:
                    polycount_sorting = self.poly_sort
            self.make_active = ""

        if polycount_sorting == 'NAME':
            name_ascending = not polycount_sorting_ascending
            polycount.sort(key=sortList, reverse=name_ascending)
        else:
            polycount.sort(key=sortList, reverse=polycount_sorting_ascending)

        return {'FINISHED'}

def trim_numbers(number):
    if number < 1000:
        return str(number)
    elif number < 1000000:
        return "{:,.2f}k".format(round(number / 1000, 2)).replace(",", " ")
    else:
        return "{:,.2f}m".format(round(number / 1000000, 2)).replace(",", " ")
