"""Immediate Smart Modeling JSON persistence for integrated KeyOps RNA."""

from __future__ import annotations

import importlib


def request_save(_self=None, context=None) -> None:
    try:
        package = str(__package__ or '')
        root = package.split('.key_operators_toolkit', 1)[0]
        common = importlib.import_module(root + '.common')
        if bool(getattr(common, '_APPLYING_PERSISTENT_SETTINGS', False)):
            return
        common.save_persistent_settings(context, force=False)
    except Exception:
        pass


def compose_update(callback=None):
    def _update(self, context):
        result = None
        if callable(callback):
            try:
                result = callback(self, context)
            except Exception:
                result = None
        request_save(self, context)
        return result

    _update._smart_modeling_persistence_update = True
    return _update


def persistent_property(factory):
    def _factory(*args, **kwargs):
        callback = kwargs.get('update')
        if not bool(getattr(callback, '_smart_modeling_persistence_update', False)):
            kwargs['update'] = compose_update(callback)
        return factory(*args, **kwargs)

    return _factory
