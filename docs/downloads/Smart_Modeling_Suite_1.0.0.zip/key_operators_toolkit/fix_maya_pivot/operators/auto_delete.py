import bpy.types
from ..utils.pref_utils import get_keyops_prefs

def remove_confirm_delete():
    # Do not mutate existing keymap-item operator properties from preference
    # callbacks. Blender 5.1.0 can crash when stale KeyMapItem.properties is
    # resolved during extension reinstall or preference refresh.
    return None

def default_confirm_delete():
    return None

def update_auto_delete_confirm_delete(self, context):
    if self.auto_delete_confirm_object_mode:
        default_confirm_delete()
    else:
        remove_confirm_delete()

class AutoDelete(bpy.types.Operator):
    bl_idname = "keyops.auto_delete"
    bl_label = "KeyOps: Auto Delete"
    bl_options = {'UNDO'}

    object_mode: bpy.props.BoolProperty(
        name="Object Mode",
        description="Delete objects in object mode",
        default=False
    ) # type:ignore

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.mode == 'EDIT'

    # def invoke(self, context, event):
    #     prefs = get_keyops_prefs()
    #     if prefs.auto_delete_confirm_object_mode:
    #         return context.window_manager.invoke_confirm(self, event)
    #     return self.execute(context)
       

    def execute(self, context):
        if self.object_mode:
            # fast delete test
            import time
            start = time.time()
            for obj in bpy.context.selected_objects:
                for collection in list(obj.users_collection):
                    collection.objects.unlink(obj)
            #     bpy.data.objects.remove(obj)

            # bpy.data.batch_remove()
            # bpy.ops.object.delete(use_global=False, confirm=True)

            # Diagnostic timing print removed for packaged runtime performance.

        prefs = get_keyops_prefs()
        select_mode = context.tool_settings.mesh_select_mode
        if select_mode[0]:
            bpy.ops.mesh.delete(type='VERT')
        elif select_mode[1]:
            if prefs.auto_delete_dissolv_edge:
                bpy.ops.mesh.dissolve_edges()
            else:
                bpy.ops.mesh.delete(type='EDGE')
        elif select_mode[2]:
            bpy.ops.mesh.delete(type='FACE')
        else:
            self.report({'ERROR'}, "Invalid selection mode")

        return {'FINISHED'}
    
    def register():
        remove_confirm_delete()
    
    def unregister():
        default_confirm_delete()
