import bpy


def _safe_kmi_property_get(props, name, default=None):
    del props, name
    return default


def _safe_copy_menu_name(dst_item, src_item):
    del dst_item, src_item
    # Do not touch KeyMapItem.properties. Blender 5.1.0 Windows can crash
    # resolving operator properties during extension reinstall/UI refresh.
    return None



def _manual_only_report(operator):
    try:
        operator.report({'INFO'}, 'Smart Modeling Suite does not modify Preferences > Keymap automatically. Copy the operator ID from the tool settings and bind it manually.')
    except Exception:
        pass
    return {'CANCELLED'}

class Rebind(bpy.types.Operator):
    bl_idname = "keyops.rebind"
    bl_label = "KeyOps: Rebind"
    bl_description = "Move Pivot Key Press"
    bl_options = {'INTERNAL', 'UNDO'}

    type: bpy.props.StringProperty(default="") # type: ignore

    def execute(self, context):
        if self.type == "Default_Pie":
            prefs = bpy.context.preferences.view
            prefs.pie_animation_timeout = 6
            prefs.pie_tap_timeout = 20
            prefs.pie_initial_timeout = 0
            prefs.pie_menu_radius = 100
            prefs.pie_menu_threshold = 12
            prefs.pie_menu_confirm = 0
        elif self.type == "No_Lag_Pie":
            prefs = bpy.context.preferences.view
            prefs.pie_animation_timeout = 0
            prefs.pie_tap_timeout = 0
            prefs.pie_initial_timeout = 0
            prefs.pie_menu_radius = 85
            prefs.pie_menu_threshold = 11
            prefs.pie_menu_confirm = 0
        elif self.type in {"Remove Select Type Shortcuts", "Add Select Type Shortcuts"}:
            return _manual_only_report(self)
            
        return {'FINISHED'}
