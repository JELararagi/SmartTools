"""Apply local object scale using Blender, then preserve length-valued modifier inputs."""
from math import fsum, isclose, isfinite
from mathutils import Vector
import bpy


_LENGTH_FIELDS = {
    "ARRAY": ("merge_threshold",),
    "BOOLEAN": ("double_threshold",),
    "SCREW": ("screw_offset", "merge_threshold"),
    "MIRROR": ("merge_threshold",),
    "SOLIDIFY": ("thickness",),
    "WIREFRAME": ("thickness",),
    "DISPLACE": ("strength",),
    "SHRINKWRAP": ("offset",),
    "WELD": ("merge_threshold",),
    "REMESH": ("voxel_size",),
}


def apply_scale(obj):
    """Apply the scale of one object without modifying another selected object."""
    with bpy.context.temp_override(object=obj, active_object=obj, selected_objects=[obj],
                                   selected_editable_objects=[obj]):
        return bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)


def _adjust_node_distances(modifier, factors, factor):
    group = modifier.node_group
    if group is None:
        return
    for socket in group.interface.items_tree:
        if socket.item_type != "SOCKET" or socket.in_out != "INPUT":
            continue
        identifier = socket.identifier
        if modifier.get(identifier + "_use_attribute"):
            continue
        socket_kind = socket.bl_socket_idname
        subtype = getattr(socket, "subtype", "")
        if socket_kind == "NodeSocketFloatDistance" or (socket_kind == "NodeSocketFloat" and subtype == "DISTANCE"):
            modifier[identifier] = factor * modifier.get(identifier, socket.default_value)
        elif (socket_kind == "NodeSocketVectorTranslation" or
              (socket_kind == "NodeSocketVector" and subtype == "TRANSLATION")):
            translation = modifier.get(identifier, socket.default_value)
            modifier[identifier] = Vector(component * scale for component, scale in zip(translation, factors))


def _adjust_modifiers(obj, scale, *, adjust_textures, adjust_nodes):
    magnitudes = tuple(map(abs, scale))
    distance_scale = fsum(magnitudes) / 3
    for modifier in obj.modifiers:
        if not modifier.show_viewport:
            continue
        for key in _LENGTH_FIELDS.get(modifier.type, ()):
            if hasattr(modifier, key):
                setattr(modifier, key, distance_scale * getattr(modifier, key))
        if modifier.type == "ARRAY":
            modifier.constant_offset_displace = tuple(
                offset * factor for offset, factor in zip(modifier.constant_offset_displace, scale)
            )
        elif modifier.type == "BEVEL" and modifier.offset_type != "PERCENT":
            modifier.width *= distance_scale
        elif modifier.type == "DISPLACE" and adjust_textures and modifier.texture_coords in {"LOCAL", "OBJECT"}:
            texture = modifier.texture
            if texture is not None and hasattr(texture, "noise_scale"):
                if texture.users > 1:
                    modifier.texture = texture.copy()
                modifier.texture.noise_scale *= distance_scale
        elif modifier.type == "SKIN" and obj.type == "MESH":
            for layer in obj.data.skin_vertices:
                for vertex in layer.data:
                    vertex.radius = tuple(radius * distance_scale for radius in vertex.radius)
        elif modifier.type == "NODES" and adjust_nodes:
            _adjust_node_distances(modifier, scale, distance_scale)


def _mesh_data_users(data):
    return data.users - int(data.use_fake_user)


class SmartApplyScale(bpy.types.Operator):
    bl_idname = "object.smart_modeling_apply_scale"
    bl_label = "Smart Apply Scale"
    bl_description = "Apply scale while compensating in the modifiers for the scale difference"
    bl_options = {"UNDO"}

    deselect: bpy.props.BoolProperty(name="Deselect problem objects", default=False)
    scaleTextures: bpy.props.BoolProperty(name="Scale procedural displacement textures", default=False)
    makeClonesReal: bpy.props.BoolProperty(name="Make objects single user", default=False)
    geomtryNodes: bpy.props.BoolProperty(name="Geometry Nodes", default=True,
                                        description="Scale distance and translation inputs")

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        selected = tuple(context.selected_objects)
        if not selected:
            self.report({"WARNING"}, "No objects selected")
            return {"CANCELLED"}
        shared = {obj for obj in selected if obj.data is not None and _mesh_data_users(obj.data) > 1}
        skipped = []
        uneven = []
        completed = 0
        for obj in selected:
            data = obj.data
            scale = tuple(obj.scale)
            if (data is None or not obj.is_editable or not data.is_editable or
                    any(not isfinite(value) or value == 0 for value in scale) or
                    (obj in shared and not self.makeClonesReal)):
                skipped.append(obj)
                continue
            if not all(isclose(abs(scale[0]), abs(value), rel_tol=1e-6) for value in scale[1:]):
                uneven.append(obj)
            if obj in shared:
                obj.data = data.copy()
            try:
                changed = apply_scale(obj)
            except RuntimeError:
                changed = {"CANCELLED"}
            if changed != {"FINISHED"}:
                if obj in shared:
                    duplicate = obj.data
                    obj.data = data
                    bpy.data.batch_remove(ids=[duplicate])
                skipped.append(obj)
                continue
            _adjust_modifiers(obj, scale, adjust_textures=self.scaleTextures, adjust_nodes=self.geomtryNodes)
            completed += 1
        if self.deselect:
            for obj in skipped + uneven:
                if obj.is_editable:
                    obj.select_set(False)
        if skipped or uneven:
            locale = context.preferences.view.language == "ja_JP"
            if locale:
                warning = f"スケール適用を省略: {len(skipped)} 件。非均等スケールの距離値は平均で補正: {len(uneven)} 件。"
            else:
                warning = f"Skipped {len(skipped)} objects. Adjusted distances by the mean scale for {len(uneven)} non-uniform objects."
            self.report({"WARNING"}, warning)
        return {"FINISHED"} if completed else {"CANCELLED"}

    @staticmethod
    def register():
        bpy.types.VIEW3D_MT_object_apply.prepend(menu_apply)

    @staticmethod
    def unregister():
        bpy.types.VIEW3D_MT_object_apply.remove(menu_apply)


def menu_apply(self, context):
    layout = self.layout
    layout.separator()
    layout.operator_context = "INVOKE_DEFAULT"
    layout.operator(SmartApplyScale.bl_idname, text=SmartApplyScale.bl_label, icon="FREEZE")
