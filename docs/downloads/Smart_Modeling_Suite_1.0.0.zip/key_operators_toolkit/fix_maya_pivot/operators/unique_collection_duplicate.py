# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Copy selected objects into the high or low scene collection."""

import bpy


def duplicate_into_collection(context):
    collection_name = "low" if bpy.data.collections.get("high") else "high"
    before = {item.as_pointer() for item in context.scene.objects}
    result = bpy.ops.object.duplicate(linked=False)
    if "FINISHED" not in result:
        return {"CANCELLED"}

    copies = tuple(item for item in context.selected_objects if item.as_pointer() not in before)
    if not copies:
        return {"CANCELLED"}

    children = context.scene.collection.children
    destination = children.get(collection_name)
    if destination is None:
        destination = bpy.data.collections.new(collection_name)
        children.link(destination)

    for item in copies:
        if destination.objects.get(item.name) is None:
            destination.objects.link(item)
        for former in tuple(item.users_collection):
            if former != destination:
                former.objects.unlink(item)
        if item.data is not None and item.data.users > 1:
            item.data = item.data.copy()
    return {"FINISHED"}


class UniqueCollectionDuplicate(bpy.types.Operator):
    bl_idname = "keyops.unique_collection_duplicate"
    bl_label = "Unique Collection Duplicate"
    bl_description = "Duplicate the selected objects and separate their mesh data"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and bool(context.selected_objects)

    def execute(self, context):
        return duplicate_into_collection(context)
