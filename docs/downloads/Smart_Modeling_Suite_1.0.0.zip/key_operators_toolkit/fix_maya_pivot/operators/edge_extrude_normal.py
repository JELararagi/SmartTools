"""Blender 5.1 compatible edge extrusion along mesh normals.

The bundled tools previously depended on ``geometry.execute_node_group``.
That operator is not registered in Blender 5.1, so the UI entry existed while
execution failed.  This module performs the same edit directly on the active
BMesh and leaves only the newly generated top edges selected.
"""

from __future__ import annotations

import bmesh
from mathutils import Vector


def _edge_offset_normal(edge) -> Vector:
    """Return a stable normal for one selected edge before extrusion."""
    normal = Vector((0.0, 0.0, 0.0))
    try:
        for face in edge.link_faces:
            normal += face.normal
    except Exception:
        pass
    if normal.length_squared <= 1.0e-20:
        try:
            normal = edge.verts[0].normal + edge.verts[1].normal
        except Exception:
            normal = Vector((0.0, 0.0, 1.0))
    if normal.length_squared <= 1.0e-20:
        normal = Vector((0.0, 0.0, 1.0))
    normal.normalize()
    return normal


def extrude_selected_edges_by_normal(context, offset: float) -> bool:
    """Extrude each selected edge independently along its local normal.

    Geometry Nodes' Edge Extrude tool used ``Individual=True``.  Processing one
    source edge at a time reproduces that ownership model: adjacent selected
    edges do not unexpectedly share the duplicated top vertices.
    """
    obj = getattr(context, "active_object", None)
    if obj is None or getattr(obj, "type", None) != "MESH" or getattr(context, "mode", "") != "EDIT_MESH":
        return False

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    source_edges = [edge for edge in bm.edges if edge.select and edge.is_valid]
    if not source_edges:
        return False

    edge_specs = []
    for edge in source_edges:
        try:
            edge_specs.append((edge, _edge_offset_normal(edge)))
        except Exception:
            continue
    if not edge_specs:
        return False

    # Clear the source selection before selecting only each generated top edge.
    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = False
    try:
        bm.select_history.clear()
    except Exception:
        pass

    generated_top_edges = []
    amount = float(offset)
    for source_edge, normal in edge_specs:
        if not source_edge.is_valid:
            continue
        original_verts = set(source_edge.verts)
        result = bmesh.ops.extrude_edge_only(
            bm,
            edges=[source_edge],
            use_select_history=False,
        )
        new_verts = [element for element in result.get("geom", ()) if isinstance(element, bmesh.types.BMVert) and element not in original_verts]
        if len(new_verts) < 2:
            continue
        translation = normal * amount
        for vert in new_verts:
            vert.co += translation
        new_vert_set = set(new_verts)
        for element in result.get("geom", ()):
            if isinstance(element, bmesh.types.BMEdge) and all(vert in new_vert_set for vert in element.verts):
                generated_top_edges.append(element)

    if not generated_top_edges:
        return False

    for edge in generated_top_edges:
        if not edge.is_valid:
            continue
        edge.select = True
        for vert in edge.verts:
            vert.select = True
        try:
            bm.select_history.add(edge)
        except Exception:
            pass

    bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
    return True
