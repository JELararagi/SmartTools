"""UV modeling operators built from Blender's public BMesh, mesh and UV APIs."""
from contextlib import contextmanager
from math import isfinite

import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from bpy.types import Operator, Panel

from ..utils.register_extensions import acquire_shared_scene_properties, release_shared_scene_properties


MODES = ("VERTEX", "EDGE", "FACE")
UNWRAP_METHODS = (
    ("ANGLE_BASED", "Angle Based", "Angle Based"),
    ("CONFORMAL", "Conformal", "Conformal"),
)
ROTATION_METHODS = (
    ("AXIS_ALIGNED", "Axis Aligned", "Axis Aligned"),
    ("CARDINAL", "Cardinal", "Cardinal"),
    ("ANY", "Any", "Any"),
)
IN_PLACE_ROTATION_METHODS = (
    ("ANY", "Any", "Any"),
    ("CARDINAL", "Cardinal", "Cardinal"),
    ("AXIS_ALIGNED", "Axis Aligned", "Axis Aligned"),
)
PACK_TARGETS = (
    ("CLOSEST_UDIM", "Closest UDIM", "Closest UDIM"),
    ("ACTIVE_UDIM", "Active UDIM", "Active UDIM"),
    ("ORIGINAL_AABB", "Original AABB", "Original AABB"),
)


def editing(context):
    return context.mode == "EDIT_MESH"


def in_uv_editor(context):
    return bool(context.area and context.area.type == "IMAGE_EDITOR")


def edit_meshes(context):
    return [(obj.data, bmesh.from_edit_mesh(obj.data))
            for obj in context.objects_in_mode_unique_data if obj.type == "MESH"]


def refresh(mesh):
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)


def operate(operator, **options):
    return operator("EXEC_DEFAULT", False, **options) if operator.poll() else {"CANCELLED"}


def set_mesh_mode(settings, mode):
    settings.mesh_select_mode = tuple(domain == mode for domain in MODES)


def mesh_mode(settings):
    return next((mode for mode, active in reversed(tuple(zip(MODES, settings.mesh_select_mode)))
                 if active), "VERTEX")


def clear_mesh_selection(mesh):
    for elements in (mesh.faces, mesh.edges, mesh.verts):
        for element in elements:
            element.select = False
    mesh.select_history.clear()


def uv_selection_to_mesh(mesh, mode):
    faces = []
    edges = set()
    vertices = set()
    for face in mesh.faces:
        if face.hide:
            continue
        if face.uv_select:
            faces.append(face)
        for corner in face.loops:
            if corner.uv_select_edge and not corner.edge.hide:
                edges.add(corner.edge)
            if corner.uv_select_vert and not corner.vert.hide:
                vertices.add(corner.vert)
    clear_mesh_selection(mesh)
    for element in {"VERTEX": vertices, "EDGE": edges, "FACE": faces}[mode]:
        element.select_set(True)
    mesh.select_flush_mode()


def mesh_selection_to_uv(mesh, mode):
    visible = [face for face in mesh.faces if not face.hide]
    for face in mesh.faces:
        face.uv_select_set(False)
        for corner in face.loops:
            corner.uv_select_vert_set(False)
            corner.uv_select_edge_set(False)
    for face in visible:
        if mode == "FACE":
            face.uv_select_set(face.select)
        for corner in face.loops:
            if mode == "VERTEX" and corner.vert.select:
                corner.uv_select_vert_set(True)
            if mode == "EDGE" and corner.edge.select:
                corner.uv_select_edge_set(True)
    mesh.uv_select_flush_mode()
    for face in visible:
        face.select_set(True)

def switch_sync(context, *, keep_selection, active_meshes_only=False):
    settings = context.tool_settings
    enable_sync = not settings.use_uv_select_sync
    source_mode = mesh_mode(settings) if not enable_sync else settings.uv_select_mode
    if source_mode not in MODES:
        source_mode = "FACE"
    targets = edit_meshes(context)
    if active_meshes_only:
        targets = [(data, mesh) for data, mesh in targets if any(v.select for v in mesh.verts)]
    settings.use_uv_select_sync = enable_sync
    if keep_selection:
        if enable_sync:
            set_mesh_mode(settings, source_mode)
        else:
            settings.uv_select_mode = source_mode
        change = uv_selection_to_mesh if enable_sync else mesh_selection_to_uv
        for data, mesh in targets:
            mesh.loops.layers.uv.verify()
            change(mesh, source_mode)
            refresh(data)
    elif not enable_sync:
        operate(bpy.ops.mesh.select_all, action="SELECT")


class SmartUVSync(Operator):
    bl_idname = "keyops.smart_uv_sync"
    bl_label = "KeyOps: Smart UV Sync"
    bl_description = "Toggle Sync Mode and UV Selection while preserving selection and selection mode"
    bl_options = {"UNDO"}

    fast_sync: BoolProperty(
        name="Fast Mode", default=False,
        description="Fast Mode, Right Click to Toggle Sync Mode and UV Selection, can be slow on very large meshes",
    )

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        switch_sync(context, keep_selection=context.scene.smart_uv_sync_enable,
                    active_meshes_only=self.fast_sync)
        return {"FINISHED"}

    @staticmethod
    def register():
        registered = []
        acquired = False
        try:
            acquire_shared_scene_properties("uv_sync", "uv_tools")
            acquired = True
            for cls in _REGISTERED_WITH_SYNC:
                if not cls.is_registered:
                    bpy.utils.register_class(cls)
                    registered.append(cls)
        except Exception:
            for cls in reversed(registered):
                bpy.utils.unregister_class(cls)
            if acquired:
                release_shared_scene_properties("uv_sync", "uv_tools")
            raise

    @staticmethod
    def unregister():
        for cls in reversed(_REGISTERED_WITH_SYNC):
            if cls.is_registered:
                bpy.utils.unregister_class(cls)
        release_shared_scene_properties("uv_sync", "uv_tools")


class UVCut(Operator):
    bl_idname = "uv.keyops_uv_cut"
    bl_label = "KeyOps: UV Cut"
    bl_description = "Maya like Cut UVs"
    bl_options = {"UNDO"}

    quick: BoolProperty(name="Quick", default=False, description="Quick Cut", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        if context.tool_settings.use_uv_select_sync:
            switch_sync(context, keep_selection=context.scene.smart_uv_sync_enable)
            self.report({"WARNING"}, "UV Sync needs to be disabled for this operation")
            operate(bpy.ops.uv.select_mode, type="EDGE")
            return {"CANCELLED"}
        if not bpy.ops.uv.mark_seam.poll() or not bpy.ops.uv.rip_move.poll():
            return {"CANCELLED"}
        bpy.ops.uv.mark_seam("EXEC_DEFAULT", True)
        bpy.ops.uv.rip_move(
            "EXEC_DEFAULT", True,
            TRANSFORM_OT_translate={"value": (0.00025, 0.00025, 0.0)},
            UV_OT_rip={"location": (100.0, 100.0)},
        )
        if self.quick:
            if bpy.ops.uv.select_linked_pick.poll():
                bpy.ops.uv.select_linked_pick("INVOKE_DEFAULT")
            if bpy.ops.transform.transform.poll():
                bpy.ops.transform.transform("INVOKE_DEFAULT")
        return {"FINISHED"}


def uv_edge_endpoints(loop, layer):
    other = loop.link_loop_next
    return {loop.vert: loop[layer].uv.copy(), other.vert: other[layer].uv.copy()}


def uv_continuous(a, b, layer):
    left = uv_edge_endpoints(a, layer)
    right = uv_edge_endpoints(b, layer)
    return left.keys() == right.keys() and all(
        (left[vertex] - right[vertex]).length_squared <= 1e-12 for vertex in left
    )


def uv_components(faces, layer):
    unvisited = set(faces)
    for first in faces:
        if first not in unvisited:
            continue
        unvisited.remove(first)
        part = [first]
        for face in part:
            for root in face.loops:
                if root.edge.seam:
                    continue
                for neighbor in root.edge.link_loops:
                    if neighbor.face in unvisited and uv_continuous(root, neighbor, layer):
                        unvisited.remove(neighbor.face)
                        part.append(neighbor.face)
        yield part


def uv_box(coordinates):
    return min(p.x for p in coordinates), min(p.y for p in coordinates), \
        max(p.x for p in coordinates), max(p.y for p in coordinates)


def fit_uv_region(loops, layer, original):
    current = [loop[layer].uv.copy() for loop in loops]
    before = uv_box(original)
    after = uv_box(current)
    widths = [(before[axis + 2] - before[axis], after[axis + 2] - after[axis]) for axis in (0, 1)]
    if any(old <= 1e-8 or new <= 1e-8 for old, new in widths):
        return
    ratio = min(old / new for old, new in widths)
    shift = tuple((before[axis] + before[axis + 2] -
                   (after[axis] + after[axis + 2]) * ratio) / 2 for axis in (0, 1))
    if isfinite(ratio):
        for loop, point in zip(loops, current):
            loop[layer].uv = (point.x * ratio + shift[0], point.y * ratio + shift[1])


class UnwrapSelection:
    def __init__(self, mesh, synced, subset, expand, ignore_pin):
        self.mesh = mesh
        self.layer = mesh.loops.layers.uv.active
        self.groups = []
        self.selected = {}
        self.seams = {}
        self.original_uvs = {}
        if self.layer is None:
            if not synced or not any(face.select and not face.hide for face in mesh.faces):
                return
            self.layer = mesh.loops.layers.uv.verify()
        layer = self.layer
        visible = [face for face in mesh.faces if not face.hide and (synced or face.select)]
        seeds = {face for face in visible if (face.select if synced else
                                             face.uv_select or any(corner.uv_select_vert for corner in face.loops))}
        included = set(seeds)
        if not subset and expand:
            for part in uv_components(visible, layer):
                if any(face in seeds for face in part):
                    included.update(part)
        if not ignore_pin:
            included = {face for face in included if not any(loop[layer].pin_uv for loop in face.loops)}
        self.included = included
        self.groups = [
            [loop for face in part for loop in face.loops]
            for part in uv_components([face for face in visible if face in included], layer)
        ]
        if not included:
            return
        self.face_uv_flags = {face: face.uv_select for face in mesh.faces}
        self.loop_flags = {corner: (corner.uv_select_vert, corner.uv_select_edge, corner[layer].pin_uv)
                           for face in mesh.faces for corner in face.loops}
        self.original_uvs = {corner: corner[layer].uv.copy() for corner in self.loop_flags}
        if synced:
            self.selected = {element: element.select
                             for collection in (mesh.verts, mesh.edges, mesh.faces) for element in collection}
            self.history = tuple(mesh.select_history)
        for edge in mesh.edges:
            linked = list(edge.link_loops)
            touches = [loop for loop in linked if loop.face in included]
            if touches and not edge.seam and (
                len(touches) != len(linked)
                or any(not uv_continuous(touches[0], other, layer) for other in touches[1:])
            ):
                self.seams[edge] = False
                edge.seam = True
        if synced:
            clear_mesh_selection(mesh)
            for face in included:
                face.select_set(True)
        else:
            for face in mesh.faces:
                face.uv_select_set(face in included)
                for corner in face.loops:
                    corner.uv_select_vert_set(face in included)
                    corner.uv_select_edge_set(face in included)
        if ignore_pin:
            for face in included:
                for corner in face.loops:
                    corner[layer].pin_uv = False

    def finish(self, *, commit, pack):
        if not self.groups:
            return
        if commit and not pack:
            for loops in self.groups:
                fit_uv_region(loops, self.layer, [self.original_uvs[loop] for loop in loops])
        for corner, original in self.original_uvs.items():
            if not commit or corner.face not in self.included:
                corner[self.layer].uv = original
        for edge, was_seam in self.seams.items():
            edge.seam = was_seam
        for element, was_selected in self.selected.items():
            element.select = was_selected
        if self.selected:
            self.mesh.select_history.clear()
            for element in self.history:
                self.mesh.select_history.add(element)
        for face, flag in self.face_uv_flags.items():
            face.uv_select_set(flag)
        for corner, (vertex, edge, pin) in self.loop_flags.items():
            corner.uv_select_vert_set(vertex)
            corner.uv_select_edge_set(edge)
            corner[self.layer].pin_uv = pin


class UnwrapInPlace(Operator):
    bl_idname = "uv.keyops_unwrap_in_place"
    bl_label = "KeyOps: Unwrap in Place"
    bl_description = "Unwrap in Place"
    bl_options = {"UNDO"}

    selected_only: BoolProperty(name="Selected Only", default=False, description="Selected Only")
    ignore_pin: BoolProperty(name="Ignore Pin", default=True, description="Ignore Pin")
    select_islands: BoolProperty(name="Select Islands (Slow)", default=False, description="Select Islands")
    uv_unwrap_method: EnumProperty(name="Method", items=UNWRAP_METHODS, default="CONFORMAL", description="UV Unwrap Method")
    pack_uv_islands: BoolProperty(name="Pack UV Islands", default=True, description="Pack UV Islands")
    margin: FloatProperty(name="Margin", default=0.001, description="Margin")
    rotate: BoolProperty(name="Rotate", default=True, description="Rotate")
    rotation_method: EnumProperty(name="Rotation Method", items=IN_PLACE_ROTATION_METHODS, default="CARDINAL", description="Rotation Method")

    @classmethod
    def poll(cls, context):
        return editing(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        for key in ("selected_only", "ignore_pin", "uv_unwrap_method", "pack_uv_islands"):
            layout.prop(self, key)
        if self.pack_uv_islands:
            for key in ("margin", "rotate", "rotation_method"):
                layout.prop(self, key)

    def execute(self, context):
        transaction = []
        commit = False
        synced = context.tool_settings.use_uv_select_sync
        if not bpy.ops.uv.unwrap.poll():
            self.report({"WARNING"}, "UV unwrap is unavailable in the current context")
            return {"CANCELLED"}
        try:
            for data, mesh in edit_meshes(context):
                state = UnwrapSelection(mesh, synced, self.selected_only, self.select_islands, self.ignore_pin)
                if state.groups:
                    transaction.append((data, state))
                    refresh(data)
            if not transaction:
                self.report({"WARNING"}, "Nothing is selected")
                return {"FINISHED"}
            result = bpy.ops.uv.unwrap(
                "EXEC_DEFAULT", False, method=self.uv_unwrap_method, fill_holes=True, correct_aspect=True,
                use_subsurf_data=False, margin_method="SCALED", margin=max(0.0, self.margin),
            )
            if "FINISHED" not in result:
                return result
            operate(bpy.ops.uv.average_islands_scale, scale_uv=True, shear=False)
            if self.pack_uv_islands:
                packed = operate(
                    bpy.ops.uv.pack_islands, udim_source="ORIGINAL_AABB", margin=max(0.0, self.margin),
                    shape_method="AABB", rotate_method=self.rotation_method, rotate=self.rotate,
                )
                if "FINISHED" not in packed:
                    return packed
            commit = True
            return {"FINISHED"}
        finally:
            for data, state in transaction:
                state.finish(commit=commit, pack=self.pack_uv_islands)
                refresh(data)


def sharp_edge_group():
    marker = "smart_modeling_uv_sharp"
    for tree in bpy.data.node_groups:
        if tree.bl_idname == "GeometryNodeTree" and tree.get(marker):
            return tree

    tree = bpy.data.node_groups.new("SharpFromUVIslands", "GeometryNodeTree")
    tree[marker] = True
    for name, socket, direction in (
        ("Geometry", "NodeSocketGeometry", "INPUT"),
        ("UV", "NodeSocketVector", "INPUT"),
        ("Only UV Island Borders", "NodeSocketBool", "INPUT"),
        ("Geometry", "NodeSocketGeometry", "OUTPUT"),
    ):
        tree.interface.new_socket(name=name, socket_type=socket, in_out=direction)

    def node(kind, label, x, y):
        item = tree.nodes.new(kind)
        item.label = label
        item.location = (x, y)
        return item

    def set_input(socket, value):
        if isinstance(value, bpy.types.NodeSocket):
            tree.links.new(value, socket)
        else:
            socket.default_value = value

    def boolean(operation, a, b, x, y):
        item = node("FunctionNodeBooleanMath", operation, x, y)
        item.operation = operation
        set_input(item.inputs[0], a)
        if b is not None:
            set_input(item.inputs[1], b)
        return item.outputs[0]

    def next_corner(corner, y):
        item = node("GeometryNodeOffsetCornerInFace", "Other end of edge", -770, y)
        set_input(item.inputs[0], corner)
        set_input(item.inputs[1], 1)
        return item.outputs[0]

    def sample(corner, field, data_type, label, x, y):
        item = node("GeometryNodeFieldAtIndex", label, x, y)
        item.domain = "CORNER"
        item.data_type = data_type
        set_input(item.inputs["Index"], corner)
        set_input(item.inputs["Value"], field)
        return item.outputs[0]

    def different(a, b, y):
        item = node("ShaderNodeVectorMath", "Distance between endpoint UVs", -120, y)
        item.operation = "DISTANCE"
        set_input(item.inputs[0], a)
        set_input(item.inputs[1], b)
        threshold = node("ShaderNodeMath", "UV discontinuity", 80, y)
        threshold.operation = "GREATER_THAN"
        set_input(threshold.inputs[0], item.outputs["Value"])
        set_input(threshold.inputs[1], 1e-7)
        return threshold.outputs[0]

    def switch(input_type, choose, when_false, when_true, x, y):
        item = node("GeometryNodeSwitch", "Choose matching side", x, y)
        item.input_type = input_type
        for socket, value in zip(item.inputs, (choose, when_false, when_true)):
            set_input(socket, value)
        return item.outputs[0]

    inputs = node("NodeGroupInput", "UV Layer", -1250, -580)
    output = node("NodeGroupOutput", "Marked geometry", 1340, 380)
    sides = [node("GeometryNodeCornersOfEdge", "Face side", -1000, y) for y in (340, -120)]
    set_input(sides[1].inputs["Sort Index"], 1)
    a, b = (side.outputs["Corner Index"] for side in sides)
    a_end = next_corner(a, 180)
    b_end = next_corner(b, -280)
    vertex = node("GeometryNodeVertexOfCorner", "Endpoint identity", -990, -550).outputs["Vertex Index"]
    comparison = node("FunctionNodeCompare", "Same starting endpoint", -350, -540)
    comparison.data_type = "INT"
    comparison.operation = "EQUAL"
    for socket, corner in zip((socket for socket in comparison.inputs if socket.enabled), (a, b)):
        set_input(socket, sample(corner, vertex, "INT", "Sample endpoint", -540, -480 if corner == a else -660))
    same_direction = comparison.outputs["Result"]
    uv = inputs.outputs["UV"]
    uv_a, uv_a_end, uv_b, uv_b_end = (
        sample(corner, uv, "FLOAT_VECTOR", "Sample endpoint UV", -550, y)
        for corner, y in zip((a, a_end, b, b_end), (420, 220, 20, -180))
    )
    matching_b = switch("VECTOR", same_direction, uv_b_end, uv_b, -330, 40)
    matching_b_end = switch("VECTOR", same_direction, uv_b, uv_b_end, -330, -200)
    discontinuous = boolean("OR", different(uv_a, matching_b, 440), different(uv_a_end, matching_b_end, 200), 280, 420)
    open_edge = node("FunctionNodeCompare", "One adjacent face", 70, -120)
    open_edge.data_type = "INT"
    open_edge.operation = "EQUAL"
    sockets = [socket for socket in open_edge.inputs if socket.enabled]
    set_input(sockets[0], sides[0].outputs["Total"])
    set_input(sockets[1], 1)
    raw = boolean("OR", discontinuous, open_edge.outputs["Result"], 470, 420)

    islands = node("GeometryNodeEdgesToFaceGroups", "UV island face groups", 460, 140)
    set_input(islands.inputs[0], raw)
    boundary = node("GeometryNodeMeshFaceSetBoundaries", "UV island boundaries", 650, 140)
    set_input(boundary.inputs[0], islands.outputs[0])
    sharp = switch("BOOLEAN", inputs.outputs["Only UV Island Borders"], raw, boundary.outputs[0], 840, 220)
    smooth_faces = node("GeometryNodeSetShadeSmooth", "Smooth faces", 650, -130)
    smooth_faces.domain = "FACE"
    set_input(smooth_faces.inputs["Geometry"], inputs.outputs["Geometry"])
    smooth_edges = node("GeometryNodeSetShadeSmooth", "Set sharpness from UV borders", 1130, 420)
    smooth_edges.domain = "EDGE"
    set_input(smooth_edges.inputs["Geometry"], smooth_faces.outputs["Geometry"])
    set_input(smooth_edges.inputs["Shade Smooth"], boolean("NOT", sharp, None, 990, 220))
    set_input(output.inputs["Geometry"], smooth_edges.outputs["Geometry"])
    return tree


def owned_sharp_modifier(obj, tree):
    for modifier in obj.modifiers:
        if modifier.type == "NODES" and modifier.node_group == tree:
            return modifier
    modifier = obj.modifiers.new(name="SharpFromUVIslands", type="NODES")
    modifier.node_group = tree
    return modifier


class SharpFromUVIslands(bpy.types.Operator):
    bl_idname = "keyops.sharp_from_uv_islands"
    bl_label = "KeyOps: Sharp From UV Islands"
    bl_description = "Mark Sharp Edges from UV Islands"
    bl_options = {"UNDO"}
    only_uv_island_borders: BoolProperty(name="Only UV Island Borders", default=True, description="Only UV Island Borders")
    apply_modifier: BoolProperty(name="Apply Modifier", default=False, description="Apply Modifier")

    @classmethod
    def poll(cls, context):
        return context.mode in {"OBJECT", "EDIT_MESH"} and any(
            obj.type == "MESH" and obj.data.uv_layers.active for obj in context.selected_objects
        )

    def execute(self, context):
        objects = tuple(obj for obj in context.selected_objects if obj.type == "MESH" and obj.data.uv_layers.active)
        if not objects:
            self.report({"WARNING"}, "No selected mesh has an active UV map")
            return {"CANCELLED"}
        tree = sharp_edge_group()
        sockets = {
            item.name: item.identifier for item in tree.interface.items_tree
            if item.item_type == "SOCKET" and item.in_out == "INPUT"
        }
        uv_input = sockets["UV"]
        edit_mode = context.mode == "EDIT_MESH"
        if edit_mode:
            bpy.ops.object.mode_set(mode="OBJECT")
        try:
            for obj in objects:
                modifier = owned_sharp_modifier(obj, tree)
                modifier[f"{uv_input}_use_attribute"] = True
                modifier[f"{uv_input}_attribute_name"] = obj.data.uv_layers.active.name
                modifier[sockets["Only UV Island Borders"]] = self.only_uv_island_borders
                obj.data.update()
                if self.apply_modifier:
                    if obj.data.users != 1:
                        self.report({"WARNING"}, f"{obj.name}: sharpness modifier kept because the mesh is shared")
                        continue
                    with context.temp_override(object=obj, active_object=obj):
                        bpy.ops.object.modifier_apply(modifier=modifier.name)
        finally:
            if edit_mode:
                bpy.ops.object.mode_set(mode="EDIT")
        return {"FINISHED"}


def smooth_mesh_faces(mesh, *, selected_only):
    changed = False
    for face in mesh.faces:
        if not face.hide and (not selected_only or face.select):
            face.smooth = True
            changed = True
    return changed


def disable_legacy_auto_smooth(obj):
    for modifier in obj.modifiers:
        if modifier.type != "NODES" or not modifier.node_group:
            continue
        if modifier.name in {"Auto Smooth", "Smooth by Angle"} or modifier.node_group.name == "Smooth by Angle":
            modifier.show_viewport = False
            modifier.show_render = False


class AutoSeam(bpy.types.Operator):
    bl_idname = "keyops.seam_by_angle"
    bl_label = "Seam by Angle"
    bl_options = {"UNDO"}
    angle: FloatProperty(name="Angle", default=1.0472, min=0.0, max=180.0, description="Angle", subtype="ANGLE")
    selection: BoolProperty(name="On Selection Only", default=False, description="Selection")
    mark_seams: BoolProperty(name="Mark Seams", default=True, description="Mark Seams")
    mark_sharp: BoolProperty(name="Mark Sharp", default=True, description="Mark Sharp")
    keep_existing_seams: BoolProperty(name="Keep Existing Seams", default=False, description="Keep Existing Seams")
    shading_by_sharp_edge: BoolProperty(name="Smooth by Sharp Edge", default=True, description="Shading by Sharp Edge")
    select_seams: BoolProperty(name="Select New Seams", default=False, description="Select Seams")

    @classmethod
    def poll(cls, context):
        return context.mode in {"OBJECT", "EDIT_MESH"} and context.active_object is not None and context.active_object.type == "MESH"

    def execute(self, context):
        object_mode = context.mode == "OBJECT"
        if object_mode:
            bpy.ops.object.mode_set(mode="EDIT")
        try:
            bpy.ops.mesh.select_mode(type="EDGE")
            for data, mesh in edit_meshes(context):
                target = {edge for edge in mesh.edges if not edge.hide and (not self.selection or edge.select)}
                chosen = {edge for edge in target if edge.is_manifold and edge.calc_face_angle() > self.angle}
                for edge in target:
                    if self.mark_seams and (not self.keep_existing_seams or edge in chosen):
                        edge.seam = edge in chosen
                    if self.mark_sharp and edge in chosen:
                        edge.smooth = False
                if self.select_seams or not self.selection:
                    for face in mesh.faces:
                        if not face.hide:
                            face.select = False
                    for vert in mesh.verts:
                        if not vert.hide:
                            vert.select = False
                    for edge in mesh.edges:
                        if not edge.hide:
                            edge.select_set(self.select_seams and edge in chosen)
                    mesh.select_flush_mode()
                if self.shading_by_sharp_edge:
                    smooth_mesh_faces(mesh, selected_only=False)
                refresh(data)
        finally:
            if object_mode:
                bpy.ops.object.mode_set(mode="OBJECT")
        return {"FINISHED"}


class ToggleSmoothSharp(bpy.types.Operator):
    bl_idname = "keyops.smooth_by_sharp"
    bl_label = "Toggle Smooth Sharp"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return AutoSeam.poll(context)

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == "MESH":
                disable_legacy_auto_smooth(obj)
        if context.mode == "OBJECT":
            return operate(bpy.ops.object.shade_smooth, keep_sharp_edges=True)
        for data, mesh in edit_meshes(context):
            if smooth_mesh_faces(mesh, selected_only=True):
                refresh(data)
        return {"FINISHED"}


@contextmanager
def editing_unsynced(context):
    settings = context.tool_settings
    previous = settings.mesh_select_mode[:]
    synced = settings.use_uv_select_sync
    keep = context.scene.smart_uv_sync_enable
    if synced:
        context.scene.smart_uv_sync_enable = True
        switch_sync(context, keep_selection=True)
    try:
        yield
    finally:
        if synced:
            try:
                switch_sync(context, keep_selection=True)
                settings.mesh_select_mode = previous
            finally:
                context.scene.smart_uv_sync_enable = keep


class OrientIslandToEdge(bpy.types.Operator):
    bl_idname = "keyops.orient_island_to_edge"
    bl_label = "Orient Island to Edge"
    bl_description = "Orient Island to Edge"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        with editing_unsynced(context):
            return operate(bpy.ops.uv.align_rotation, method="EDGE")


class RemoveSeam(bpy.types.Operator):
    bl_idname = "keyops.remove_seam"
    bl_label = "KeyOps: Remove Seam"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        operation = bpy.ops.mesh.mark_seam
        if not operation.poll():
            return {"CANCELLED"}
        operation("EXEC_DEFAULT", False, clear=True)
        return operate(bpy.ops.mesh.mark_sharp, clear=True)


class RemoveAllPins(bpy.types.Operator):
    bl_idname = "uv.remove_all_pins"
    bl_label = "KeyOps: Clear All Pins"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        for data, mesh in edit_meshes(context):
            layer = mesh.loops.layers.uv.active
            if layer is not None:
                for face in mesh.faces:
                    for loop in face.loops:
                        loop[layer].pin_uv = False
                refresh(data)
        return {"FINISHED"}


class UnwrapSelected(bpy.types.Operator):
    bl_idname = "keyops.unwrap_selected"
    bl_label = "Unwrap Selected"
    bl_description = "Unwrap Selected"
    bl_options = {"UNDO"}
    method: EnumProperty(items=UNWRAP_METHODS, default="ANGLE_BASED")
    fill_holes: BoolProperty(name="Fill Holes", default=True)
    corret_aspect: BoolProperty(name="Correct Aspect", default=True)
    use_subsurf_data: BoolProperty(name="Use Subdivision Surface", default=False)

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        with editing_unsynced(context):
            return operate(
                bpy.ops.uv.unwrap, method=self.method, fill_holes=self.fill_holes,
                correct_aspect=self.corret_aspect, use_subsurf_data=self.use_subsurf_data, margin=0.001,
            )


class QuickPack(bpy.types.Operator):
    bl_idname = "uv.keyops_quick_pack"
    bl_label = "Quick Pack"
    bl_description = "Quick Pack"
    bl_options = {"UNDO"}
    margin: FloatProperty(name="Margin", description="Margin", default=0.001)
    scale: BoolProperty(name="Scale", description="Scale", default=True)
    rotate: BoolProperty(name="Rotate", description="Rotate", default=True)
    rotate_method: EnumProperty(name="Rotate Method", description="Rotate Method", items=ROTATION_METHODS, default="CARDINAL")
    merge_overlapping: BoolProperty(name="Merge Overlapping", description="Merge Overlapping", default=False)
    udim_source: EnumProperty(name="Pack to", description="UDIM Source", items=PACK_TARGETS, default="CLOSEST_UDIM")

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        return operate(
            bpy.ops.uv.pack_islands, shape_method="AABB", margin=self.margin, scale=self.scale,
            rotate=self.rotate, rotate_method=self.rotate_method, merge_overlap=self.merge_overlapping,
            udim_source=self.udim_source,
        )


class IsolateUVIsland(bpy.types.Operator):
    bl_idname = "uv.keyops_isolate_uv_island"
    bl_label = "Isolate UV Island"
    bl_description = "Isolate UV Island"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return editing(context)

    def execute(self, context):
        linked = operate(bpy.ops.uv.select_linked)
        if "FINISHED" not in linked:
            return linked
        for data, mesh in edit_meshes(context):
            layer = mesh.loops.layers.uv.active
            if layer is None:
                continue
            keep = {
                face for face in mesh.faces if not face.hide and (
                    face.select if context.tool_settings.use_uv_select_sync else
                    any(loop.uv_select_vert for loop in face.loops)
                )
            }
            for vert in mesh.verts:
                if not vert.hide:
                    vert.select = False
            for edge in mesh.edges:
                if not edge.hide:
                    edge.select = False
            for face in mesh.faces:
                if not face.hide:
                    face.select_set(face in keep)
            mesh.select_flush_mode()
            refresh(data)
        context.tool_settings.mesh_select_mode = (False, False, True)
        context.tool_settings.use_uv_select_sync = False
        for data, mesh in edit_meshes(context):
            layer = mesh.loops.layers.uv.active
            if layer is not None:
                for face in mesh.faces:
                    for loop in face.loops:
                        loop.uv_select_vert_set(face.select and not face.hide)
                        loop.uv_select_edge_set(face.select and not face.hide)
                refresh(data)
        return {"FINISHED"}


class SelectSimilarUVIsland(bpy.types.Operator):
    bl_idname = "uv.keyops_select_similar_uv_island"
    bl_label = "Select Similar UV Island"
    bl_description = "Select Similar UV Island"
    bl_options = {"UNDO"}
    treshold: FloatProperty(name="Treshold", description="Treshold", default=0.001, min=0.0, max=1.0, precision=3)

    @classmethod
    def poll(cls, context):
        return editing(context) and in_uv_editor(context) and not context.tool_settings.use_uv_select_sync

    def execute(self, context):
        if context.tool_settings.uv_select_mode != "FACE":
            operate(bpy.ops.uv.select_mode, type="FACE")
        context.tool_settings.use_uv_select_island = True
        return operate(bpy.ops.uv.select_similar, type="AREA_3D", threshold=self.treshold)


class UVEDITORSMARTUVSYNC_PT_Panel(Panel):
    bl_idname = "UVEDITORSMARTUVSYNC_PT_Panel"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Modeling"
    bl_label = "Key Ops: Toolkit - UV Tools"

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = self.layout
        layout.operator("keyops.smart_uv_sync")
        layout.prop(context.scene, "smart_uv_sync_enable")
        layout.prop(context.scene.tool_settings, "use_edge_path_live_unwrap")
        layout.prop(context.space_data.uv_editor, "use_live_unwrap")
        groups = (
            (("uv.keyops_isolate_uv_island", ""), ("uv.reveal", ""), ("keyops.sharp_from_uv_islands", ""),
             ("uv.seams_from_islands", ""), ("uv.average_islands_scale", "")),
            (("uv.unwrap", ""), ("keyops.unwrap_selected", ""), ("uv.keyops_unwrap_in_place", ""),
             ("mesh.mark_seam", "Mark Seam", {"clear": False}), ("keyops.remove_seam", "Clear Seam"),
             ("uv.keyops_uv_cut", "UV Cut", {}, "EXEC_DEFAULT"), ("uv.stitch", "", {}, "EXEC_DEFAULT"),
             ("keyops.seam_by_angle", "", {}, "INVOKE_DEFAULT")),
            (("uv.keyops_quick_pack", ""), ("uv.pack_islands", "Exact Pack"),
             ("uv.pin", "Pin", {"clear": False}), ("uv.pin", "Unpin", {"clear": True}),
             ("uv.select_pinned", "Select Pinned"), ("uv.remove_all_pins", ""),
             ("keyops.orient_island_to_edge", ""), ("uv.align_rotation", "Align Rotation", {"method": "AUTO"})),
            (("uv.select_more", ""), ("uv.select_less", ""), ("uv.keyops_select_similar_uv_island", ""),
             ("uv.select_overlap", ""), ("uv.select_linked", ""), ("uv.select_all", "Invert", {"action": "INVERT"})),
            (("transform.mirror", "Flip X", {"constraint_axis": (True, False, False)}),
             ("transform.mirror", "Flip Y", {"constraint_axis": (False, True, False)}),
             ("uv.copy", ""), ("uv.paste", "")),
        )
        for group in groups:
            section = layout.column(align=True)
            for operator_id, label, *options in group:
                section.operator_context = options[1] if len(options) > 1 else "INVOKE_DEFAULT"
                operator = section.operator(operator_id, text=label) if label else section.operator(operator_id)
                if options:
                    for key, value in options[0].items():
                        setattr(operator, key, value)


_REGISTERED_WITH_SYNC = (
    UVEDITORSMARTUVSYNC_PT_Panel, UVCut, SharpFromUVIslands, UnwrapInPlace, AutoSeam,
    ToggleSmoothSharp, OrientIslandToEdge, UnwrapSelected, QuickPack, IsolateUVIsland,
    RemoveSeam, SelectSimilarUVIsland, RemoveAllPins,
)
