import bpy.types
from ..classes_keymap_items import classes as classesdict
from ..classes_keymap_items import keymap_items as keysdict
from ..utils.pref_utils import get_keyops_prefs
import importlib
import uuid

#The following code is based on the MACHIN3 addon: MACHIN3tools
#Check out there awesome addons here: https://machin3.io/   


_SHARED_SCENE_PROP_STATE_KEY = "JELARARAGI_SMS_KEYOPS_SHARED_SCENE_PROPERTIES_V1"
_SHARED_SCENE_PROP_OWNER_UUID = "f20817e4-9615-48a2-9a41-519441c9d0d3"
_SHARED_SCENE_PROP_GENERATION = uuid.uuid4().hex


def _shared_scene_property_state():
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        namespace = globals()
    state = namespace.get(_SHARED_SCENE_PROP_STATE_KEY)
    if not isinstance(state, dict) or state.get("owner_uuid") != _SHARED_SCENE_PROP_OWNER_UUID:
        state = {
            "owner_uuid": _SHARED_SCENE_PROP_OWNER_UUID,
            "suite_id": "smart_modeling_suite",
            "groups": {},
        }
        namespace[_SHARED_SCENE_PROP_STATE_KEY] = state
    return state


def _shared_scene_property_definitions(group_name):
    if group_name == "bevel":
        return {
            "bevel_segment_amount": lambda: bpy.props.IntProperty(
                name="Bevel Segment Amount", default=2, min=1, max=128,
                description="Set the exact segment count used by the bevel utilities.",
            ),
            "bevel_segment_by_percent": lambda: bpy.props.IntProperty(
                name="Bevel Segment By %", default=-50, min=-100, max=100,
                subtype='FACTOR',
                description="Change bevel segment counts by the specified percentage.",
            ),
            "bevel_offset": lambda: bpy.props.FloatProperty(
                name="Bevel Offset", default=0.1, min=0.0, max=10.0,
                description="Width threshold used by the bevel utility filters.",
            ),
            "compensate_for_scale": lambda: bpy.props.BoolProperty(
                name="Compensate for Scale", default=True,
                description="Compensate the bevel offset for each object's scale.",
            ),
            "bevel_segments_type": lambda: bpy.props.EnumProperty(
                name="Bevel Segment Target",
                items=[
                    ('ALL', 'All Bevels', 'Apply to every bevel modifier'),
                    ('TOP', 'First Bevel', 'Apply to the first bevel modifier'),
                    ('BOTTOM', 'Last Bevel', 'Apply to the last bevel modifier'),
                    ('BY_OFFSET', 'By Bevel Offset', 'Apply only to matching bevel widths'),
                ],
                default='ALL',
                description="Choose which bevel modifiers receive the segment setting.",
            ),
        }
    if group_name == "uv_sync":
        from ..operators.persistence_bridge import request_save
        return {
            "smart_uv_sync_enable": lambda: bpy.props.BoolProperty(
                name="Smart UV Sync",
                default=True,
                description=(
                    "When enabled, Smart UV Sync also preserves the corresponding "
                    "mesh and UV selection modes. Disable it for the lighter native toggle."
                ),
                update=request_save,
            ),
        }
    raise KeyError(group_name)


def acquire_shared_scene_properties(group_name, owner_token):
    """Acquire one exact, generation-owned Scene property group.

    Existing foreign descriptors are never overwritten.  Interrupted receipts from
    an older Smart Modeling generation are reclaimed only when the current Scene
    descriptor is the exact object stored in that receipt.
    """
    state = _shared_scene_property_state()
    groups = state.setdefault("groups", {})
    record = groups.get(group_name)
    if isinstance(record, dict) and record.get("generation") != _SHARED_SCENE_PROP_GENERATION:
        for name, descriptor in tuple(record.get("descriptors", {}).items()):
            try:
                if vars(bpy.types.Scene).get(name) is descriptor:
                    delattr(bpy.types.Scene, name)
            except Exception:
                pass
        groups.pop(group_name, None)
        record = None
    if not isinstance(record, dict):
        record = {
            "generation": _SHARED_SCENE_PROP_GENERATION,
            "descriptors": {},
            "owners": set(),
            "foreign": set(),
        }
        groups[group_name] = record

    owner_key = (str(owner_token), _SHARED_SCENE_PROP_GENERATION)
    if owner_key in record["owners"]:
        return True

    added = []
    try:
        for name, factory in _shared_scene_property_definitions(group_name).items():
            current = vars(bpy.types.Scene).get(name)
            owned = record["descriptors"].get(name)
            if current is not None:
                if owned is current:
                    continue
                record["foreign"].add(name)
                continue
            setattr(bpy.types.Scene, name, factory())
            descriptor = vars(bpy.types.Scene).get(name)
            if descriptor is None:
                raise RuntimeError(f"Scene property registration produced no descriptor: {name}")
            record["descriptors"][name] = descriptor
            added.append((name, descriptor))
        record["owners"].add(owner_key)
        return True
    except Exception:
        for name, descriptor in reversed(added):
            try:
                if vars(bpy.types.Scene).get(name) is descriptor:
                    delattr(bpy.types.Scene, name)
            except Exception:
                pass
            record["descriptors"].pop(name, None)
        if not record["owners"] and not record["descriptors"]:
            groups.pop(group_name, None)
        raise


def release_shared_scene_properties(group_name, owner_token):
    state = _shared_scene_property_state()
    groups = state.setdefault("groups", {})
    record = groups.get(group_name)
    if not isinstance(record, dict):
        return 0
    owner_key = (str(owner_token), _SHARED_SCENE_PROP_GENERATION)
    record.setdefault("owners", set()).discard(owner_key)
    if record["owners"]:
        return 0
    removed = 0
    for name, descriptor in reversed(tuple(record.get("descriptors", {}).items())):
        try:
            if vars(bpy.types.Scene).get(name) is descriptor:
                delattr(bpy.types.Scene, name)
                removed += 1
        except Exception:
            pass
    groups.pop(group_name, None)
    return removed

def release_all_shared_scene_properties():
    """Release every exact descriptor owned by this loaded module generation.

    This is a final disable/rollback safety net.  It does not inspect property
    names outside the ledger and never removes a descriptor that has been
    replaced by Blender, the user, or another add-on.
    """
    state = _shared_scene_property_state()
    groups = state.setdefault("groups", {})
    removed = 0
    for group_name, record in reversed(tuple(groups.items())):
        if not isinstance(record, dict):
            continue
        for name, descriptor in reversed(tuple(record.get("descriptors", {}).items())):
            try:
                if vars(bpy.types.Scene).get(name) is descriptor:
                    delattr(bpy.types.Scene, name)
                    removed += 1
            except Exception:
                pass
        groups.pop(group_name, None)
    return removed

_registered_hooks = set()


def register_classes(classlists):
    classes = []
    for classlist in classlists:
        for path, declarations in classlist:
            module = importlib.import_module(f"..{path}", package=__package__)
            if not declarations:
                if module not in _registered_hooks:
                    module.register()
                    _registered_hooks.add(module)
                classes.append(module)
                continue
            for class_name, _ in declarations:
                cls = getattr(module, class_name)
                # Restoring preferences can enable an already registered feature.
                if not cls.is_registered:
                    bpy.utils.register_class(cls)
                classes.append(cls)
    return classes


def unregister_classes(classes):
    for cls in reversed(list(classes or [])):
        try:
            if cls in _registered_hooks:
                cls.unregister()
                _registered_hooks.remove(cls)
            else:
                bpy.utils.unregister_class(cls)
        except Exception:
            pass


def get_classes(classlist):
    classes = []

    for fr, imps in classlist:
        if not imps:
            classes.append(importlib.import_module(f"..{fr}", package=__package__))
            continue
        type = "OT" if "operators" in fr else "MT"
        classes.extend(getattr(bpy.types, f"KEYOPS_{type}_{imp[1]}", False) for imp in imps)
    return classes



def _operator_properties_contains(props, name):
    # Never inspect existing KeyMapItem.properties. hasattr/getattr can enter
    # WM_operator_properties_create_ptr and crash before Python can catch it.
    del props, name
    return False

def _safe_get_operator_property(props, name, default=None):
    del props, name
    return default


def _safe_set_operator_property(props, name, value) -> bool:
    del props, name, value
    return False


def _keymap_item_basic_match(kmi, item):
    del kmi, item
    # Avoid all existing KeyMapItem RNA reads during registration. Even basic
    # properties can be stale during reinstall on Blender 5.1.0 Windows.
    return False

def _properties_match(kmi, properties):
    # Duplicate detection uses id/key/modifier matching only. Do not resolve
    # kmi.properties for existing items.
    del kmi, properties
    return True


def _find_existing_keymap_item(km, item):
    del km, item
    return None

def register_keymaps(keylists):
    """Return no keymaps.

    Smart Modeling Suite is manual-keymap only.  Integrated Key Ops operators
    remain registered, but this function must not create entries in
    Preferences > Keymap automatically.
    """
    del keylists
    return []

def unregister_keymaps(keymaps):
    del keymaps
    return None


def get_keymaps(keylist):
    del keylist
    return []

def enable_extension(self, register, extension):
    name = extension.replace("_", " ").title()
    debug = False

    if register:
        classlist, keylist = eval("get_%s()" % extension)
        classes = register_classes(classlist)

        from .. import classes as default_classes

        for c in classes:
            if c not in default_classes:
                default_classes.append(c)

        keymaps = register_keymaps(keylist)

        from .. import keymaps as default_keymaps
        for k in keymaps:
            if k not in default_keymaps:
                default_keymaps.append(k)

        classlist.clear()
        keylist.clear()

    else:
        keylist = keysdict.get(extension.upper())

        if keylist:
            keymaps = get_keymaps(keylist)

            from .. import keymaps as default_keymaps
            for k in keymaps:
                if k in default_keymaps:
                    default_keymaps.remove(k)

            unregister_keymaps(keymaps)

        classlist = classesdict[extension.upper()]
        classes = get_classes(classlist)

        from .. import classes as default_classes

        for c in classes:
            if c in default_classes:
                default_classes.remove(c)


        unregister_classes(classes)


def operator(operator_name):
    def decorator(func):
        def wrapper(classlists=[], keylists=[]):
            if getattr(get_keyops_prefs(), f"enable_{operator_name.lower().replace(' ', '_')}"):
                operator_class = classesdict[operator_name.upper().replace(' ', '_')]
                operator_key = keysdict.get(operator_name.upper().replace(' ', '_'), None)
                classlists.append(operator_class)
                if operator_key:
                    keylists.append(operator_key)
            return classlists, keylists
        return wrapper
    return decorator

def get_extension():
    functions = [
                 get_auto_delete,
                 get_toggle_retopology,
                 get_maya_pivot,
                 get_maya_navigation,
                 get_double_click_select_island,
                 get_uv_tools,
                 get_add_objects_pie,
                 get_add_modifier_pie,
                 get_workspace_pie,
                 get_cursor_pie,
                 get_legacy_shortcuts,
                 get_fast_merge,
                 get_modi_key,
                 get_uv_pies,
                 get_utility_pie,
                 get_cad_decimate,
                 get_auto_lod,
                 get_polycount_list,
                 get_toolkit_panel,
                 get_quick_bake_name,
                 get_quick_export,
                 get_atri_op,
                 get_material_index,
                 get_outliner_options,
                 get_viewport_menu,
]
    classlists, keylists = [], []
    for func in functions:
        classlists, keylists = func(classlists, keylists)
    return classlists, keylists


@operator("Auto Delete")
def get_auto_delete(): pass

@operator("Toggle Retopology")
def get_toggle_retopology(): pass

@operator("Maya Pivot")
def get_maya_pivot(): pass

@operator("Maya Navigation")
def get_maya_navigation(): pass

@operator("Double Click Select Island")
def get_double_click_select_island(): pass

@operator("UV Tools")
def get_uv_tools(): pass

@operator("Add Objects Pie")
def get_add_objects_pie(): pass

@operator("Add Modifier Pie")
def get_add_modifier_pie(): pass

@operator("Workspace Pie")
def get_workspace_pie(): pass

@operator("Legacy Shortcuts")
def get_legacy_shortcuts(): pass

@operator("Cursor Pie")
def get_cursor_pie(): pass

@operator("Fast Merge")
def get_fast_merge(): pass

@operator("Modi Key")
def get_modi_key(): pass

@operator("UV Pies")
def get_uv_pies(): pass

@operator("Utility Pie")
def get_utility_pie(): pass

@operator("CAD Decimate")
def get_cad_decimate(): pass

@operator("Auto LOD")
def get_auto_lod(): pass

@operator("Polycount List")
def get_polycount_list(): pass

@operator("Toolkit Panel")
def get_toolkit_panel(): pass

@operator("Quick Bake Name")
def get_quick_bake_name(): pass

@operator("Quick Export")
def get_quick_export(): pass

@operator("Atri OP")
def get_atri_op(): pass

@operator("Material Index")
def get_material_index(): pass

@operator("Outliner Options")
def get_outliner_options(): pass

@operator("Viewport Menu")
def get_viewport_menu(): pass