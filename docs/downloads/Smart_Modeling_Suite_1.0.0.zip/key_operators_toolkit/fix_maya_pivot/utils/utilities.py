import bpy

def force_show_obj(context, obj, select=True):
    """
    Force show the object in the viewport, even if the collection is hidden.
    """
    obj_collection = obj.users_collection[0]

    if obj_collection.hide_viewport == True or context.view_layer.layer_collection.children[obj_collection.name].hide_viewport == True:
        obj_collection.hide_viewport = False
        context.view_layer.layer_collection.children[obj_collection.name].hide_viewport = False
        for obj in obj_collection.objects:
            if not obj.hide_get():
                obj.hide_set(True)

    obj.hide_set(False)
    obj.hide_viewport = False
    if select:
        obj.select_set(True)
        context.view_layer.objects.active = obj


def move_selected_to_collection(context, name):
    """Move the selected objects into the scene's child collection ``name``, creating it when missing."""
    scene_collection = context.scene.collection
    collection = scene_collection.children.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        scene_collection.children.link(collection)
    for obj in context.selected_objects:
        for owner in tuple(obj.users_collection):
            if owner != collection:
                owner.objects.unlink(obj)
        if obj.name not in collection.objects:
            collection.objects.link(obj)
    return collection
