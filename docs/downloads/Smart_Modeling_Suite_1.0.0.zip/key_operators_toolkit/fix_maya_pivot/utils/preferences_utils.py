import bpy
try:
    import rna_keymap_ui  # compatibility only; stale KMI drawing is disabled
except Exception:
    rna_keymap_ui = None
import os
from pathlib import Path

try:
    from .... import icon_runtime as _sms_icon_runtime
except Exception:  # pragma: no cover
    _sms_icon_runtime = None
from bpy.utils import previews
from .. import __package__ as base_package
from .... import preferences

def get_is_addon_enabled(addon_name):
    needle = str(addon_name or '').strip().lower()
    if not needle:
        return False
    try:
        import addon_utils
        for module in addon_utils.modules():
            module_name = str(getattr(module, '__name__', '') or '').lower()
            if needle in module_name:
                try:
                    return bool(addon_utils.check(module_name)[1])
                except Exception:
                    return True
    except Exception:
        pass
    return False

def get_addon_name():
    return base_package

def get_keyops_prefs():
    try:
        from ..addon_preferences import KeyOpsPreferences
    except Exception:
        KeyOpsPreferences = None
    return preferences.get_preferences(bpy.context, base_package, KeyOpsPreferences)

def get_addon_path(addon_name):
    needle = str(addon_name or '').strip().lower()
    if not needle:
        return ''
    try:
        import addon_utils
        for module in addon_utils.modules():
            module_name = str(getattr(module, '__name__', '') or '')
            if needle in module_name.lower():
                return module_name
    except Exception:
        pass
    return ''




def _operator_properties_names(props):
    del props
    return set()

def _operator_property_get(props, name, default=None):
    del props, name
    return default

def get_addon_preferences(addon_name):
    normalized = str(addon_name or '').strip().lower()
    if 'polyquilt' in normalized:
        try:
            from ....polyquilt_fork.poly_quilt_fork.pq_preferences import PolyQuiltPreferences
        except Exception:
            PolyQuiltPreferences = None
        root_package = base_package.split('.key_operators_toolkit', 1)[0]
        addon_key = root_package + '.polyquilt_fork.poly_quilt_fork'
        return preferences.get_addon_entry(bpy.context, addon_key, PolyQuiltPreferences)
    addon_key = get_addon_path(addon_name) or str(addon_name or '')
    return preferences.get_addon_entry(bpy.context, addon_key, None)



def _keymap_item_basic_match(km_item, item):
    try:
        return (
            getattr(km_item, 'idname', None) == item.get('idname') and
            getattr(km_item, 'type', None) == item.get('type') and
            getattr(km_item, 'value', None) == item.get('value') and
            bool(getattr(km_item, 'repeat', False)) == bool(item.get('repeat', False)) and
            bool(getattr(km_item, 'ctrl', False)) == bool(item.get('ctrl', False)) and
            bool(getattr(km_item, 'shift', False)) == bool(item.get('shift', False)) and
            bool(getattr(km_item, 'alt', False)) == bool(item.get('alt', False))
        )
    except Exception:
        return False

#The following code is based on the MACHIN3 addon: MACHIN3tools
#Check out there awesome addons here: https://machin3.io/
def draw_keymap(key_config, name, key_list, layout):
    drawn = []
    index = 0

    for item in key_list:
        is_drawn = False

        if item.get("keymap"):
            key_map = key_config.keymaps.get(item.get("keymap"))

            key_map_item = None
            if key_map:
                for km_item in key_map.keymap_items:
                    if _keymap_item_basic_match(km_item, item):
                        key_map_item = km_item
                        break
            if key_map_item:
                if index == 0:
                    box = layout.box()

                if len(key_list) == 1:
                    label = name.title().replace("_", " ")
                else:
                    if index == 0:
                        box.label(text=name.title().replace("_", " "))

                    label = item.get("label")

                row = box.split(factor=0.15)
                row.label(text=label)

                safe = row.row(align=True)
                safe.label(text=f"{getattr(key_map_item, 'type', '')} {getattr(key_map_item, 'value', '')}")
                safe.label(text=str(getattr(key_map_item, 'idname', '') or ''))

                is_drawn = True
                index += 1

        drawn.append(is_drawn)
    return drawn

_LEGACY_ICON_KEYS = (
    "diffrance", "intersection", "slice", "union",
)


def register_icons():
    icon_collection = previews.new()
    here = Path(__file__).resolve()
    candidate_dirs = (
        (here.parents[3] / "icons").resolve(),
        (here.parent.parent / "icons").resolve(),
    )
    loaded = set()
    for key in _LEGACY_ICON_KEYS:
        filepath = None
        if _sms_icon_runtime is not None:
            try:
                candidate = _sms_icon_runtime.resolve_icon_path(key)
                if candidate.is_file():
                    filepath = candidate
            except Exception:
                filepath = None
        if filepath is None:
            for path in candidate_dirs:
                candidate = (path / f"{key}.png").resolve()
                if candidate.is_file():
                    filepath = candidate
                    break
        if filepath is None or key in loaded:
            continue
        try:
            icon_collection.load(key, str(filepath), 'IMAGE')
            loaded.add(key)
        except Exception:
            pass
    return icon_collection


def unregister_icons(icon_collection):
    if icon_collection is None:
        return
    try:
        previews.remove(icon_collection)
    except Exception:
        pass


icons = None


def set_icons(icon_collection):
    global icons
    icons = icon_collection


def get_icon(name):
    global icons
    try:
        if icons is None:
            return 0
        item = icons.get(str(name or ""))
        return int(getattr(item, 'icon_id', 0) or 0) if item is not None else 0
    except Exception:
        return 0