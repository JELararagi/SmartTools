# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Atomic Edit-Mesh Undo support for object-level companion state.

Blender stores Mesh Edit Mode changes in the edit-mesh undo stack, while object
matrices and modifier stacks live outside that stack.  Commands that temporarily
leave Edit Mode therefore tend to create several visible Undo steps.

This module keeps those commands in Edit Mode.  A private integer BMesh layer is
changed together with the edit mesh, and event-only Undo/Redo handlers restore
object matrices and modifier stacks associated with that token.  No polling,
frame handler, draw handler, key monitor, or continuously running timer is used.

The private layer is removed before saving and restored only in memory after the
save completes.  It is also removed during full Smart Modeling teardown.
"""

from __future__ import annotations

from collections import Counter
import secrets

import bmesh
import bpy
from mathutils import Color, Euler, Matrix, Quaternion, Vector


_BRIDGE_NS_KEY = "SMART_MODELING_EDIT_MODE_UNDO_BRIDGE"
_LAYER_PREFIX = ".jel_sms_edit_undo_"
_HANDLER_NAMES = {
    "_undo_post",
    "_redo_post",
    "_load_pre",
    "_save_pre",
    "_save_post",
    "_save_post_fail",
}
_MAX_STATES_PER_MESH = 2048
_MAX_TOKEN = 2_000_000_000

_ID_COLLECTION_NAMES = (
    "objects",
    "collections",
    "meshes",
    "curves",
    "metaballs",
    "armatures",
    "lattices",
    "cameras",
    "lights",
    "lightprobes",
    "materials",
    "textures",
    "images",
    "node_groups",
    "worlds",
    "scenes",
    "actions",
    "grease_pencils_v3",
    "grease_pencils",
    "particle_settings",
    "movieclips",
    "masks",
    "sounds",
    "speakers",
    "texts",
    "fonts",
    "volumes",
    "pointclouds",
    "hair_curves",
)
_VALUE_ID_REF = "__jel_sms_id_ref__"
_VALUE_SET = "__jel_sms_set__"
_VALUE_TUPLE = "__jel_sms_tuple__"
_VALUE_DICT = "__jel_sms_dict__"
_SKIP_VALUE = object()


def _state(create: bool = True):
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        return None
    state = namespace.get(_BRIDGE_NS_KEY)
    if not isinstance(state, dict):
        if not create:
            return None
        state = {
            "layer_name": f"{_LAYER_PREFIX}{secrets.token_hex(6)}",
            "next_token": 1,
            "meshes": {},
            "payload_handlers": {},
            "save_restore": [],
            "syncing": False,
            "shutdown": False,
            "shutdown_callback": None,
        }
        namespace[_BRIDGE_NS_KEY] = state
    layer_name = str(state.get("layer_name") or "")
    if not layer_name.startswith(_LAYER_PREFIX):
        state["layer_name"] = f"{_LAYER_PREFIX}{secrets.token_hex(6)}"
    state.setdefault("next_token", 1)
    state.setdefault("meshes", {})
    state.setdefault("payload_handlers", {})
    state.setdefault("save_restore", [])
    state.setdefault("syncing", False)
    state.setdefault("shutdown", False)
    state.setdefault("shutdown_callback", None)
    return state


def _is_handler(function) -> bool:
    try:
        module_name = str(getattr(function, "__module__", "") or "")
        function_name = str(getattr(function, "__name__", "") or "")
    except Exception:
        return False
    return module_name.endswith(".edit_mode_undo_bridge") and function_name in _HANDLER_NAMES


def ensure() -> bool:
    """Install event-only handlers after the first relevant command is used."""
    state = _state(True)
    if state is None:
        return False
    state["shutdown"] = False
    state["shutdown_callback"] = shutdown
    for collection, current in (
        (bpy.app.handlers.undo_post, _undo_post),
        (bpy.app.handlers.redo_post, _redo_post),
        (bpy.app.handlers.load_pre, _load_pre),
        (bpy.app.handlers.save_pre, _save_pre),
        (bpy.app.handlers.save_post, _save_post),
        (bpy.app.handlers.save_post_fail, _save_post_fail),
    ):
        for function in tuple(collection):
            if function is current:
                continue
            if _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
        if current not in collection:
            collection.append(current)
    return True


def capture_edit_objects(context) -> tuple:
    """Return unique Mesh objects participating in the current Edit Mode."""
    try:
        objects = tuple(getattr(context, "objects_in_mode", None) or ())
    except Exception:
        objects = ()
    if not objects:
        obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
        objects = (obj,) if obj is not None else ()
    result = []
    seen = set()
    for obj in objects:
        try:
            if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
                continue
            key = int(obj.as_pointer())
            if key in seen:
                continue
            seen.add(key)
            result.append(obj)
        except Exception:
            continue
    return tuple(result)


def capture_edit_context(context):
    """Compatibility helper returning active name and multi-object Edit names."""
    objects = capture_edit_objects(context)
    names = [str(obj.name) for obj in objects]
    try:
        active = context.view_layer.objects.active
        active_name = str(getattr(active, "name", "") or "")
    except Exception:
        active_name = ""
    if not active_name and names:
        active_name = names[0]
    return active_name, names


def _id_uid(id_data) -> int:
    try:
        return int(getattr(id_data, "session_uid", 0) or 0)
    except Exception:
        return 0


def _mesh_key(mesh) -> str:
    return f"{_id_uid(mesh)}:{str(getattr(mesh, 'name_full', '') or getattr(mesh, 'name', '') or '')}"


def _matrix_tuple(matrix) -> tuple:
    return tuple(tuple(float(value) for value in row) for row in Matrix(matrix))


def _matrix_from(value) -> Matrix | None:
    try:
        return Matrix(value)
    except Exception:
        return None


def _object_record(obj, matrix=None) -> dict:
    return {
        "name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""),
        "uid": _id_uid(obj),
        "matrix": _matrix_tuple(matrix if matrix is not None else obj.matrix_world),
    }


def _resolve_mesh(record):
    name = str(record.get("name") or "")
    mesh = bpy.data.meshes.get(name) if name else None
    uid = int(record.get("uid") or 0)
    if mesh is not None and (not uid or _id_uid(mesh) == uid):
        return mesh
    if uid:
        for candidate in bpy.data.meshes:
            if _id_uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return mesh


def _resolve_object(record):
    name = str(record.get("name") or "")
    obj = bpy.data.objects.get(name) if name else None
    uid = int(record.get("uid") or 0)
    if obj is not None and (not uid or _id_uid(obj) == uid):
        return obj
    if uid:
        for candidate in bpy.data.objects:
            if _id_uid(candidate) == uid:
                record["name"] = str(candidate.name)
                return candidate
    return obj


# -----------------------------------------------------------------------------
# Modifier stack snapshots


def _id_reference(id_data) -> dict:
    return {
        _VALUE_ID_REF: True,
        "direct": id_data,
        "name": str(getattr(id_data, "name_full", "") or getattr(id_data, "name", "") or ""),
        "uid": _id_uid(id_data),
        "rna": str(getattr(getattr(id_data, "bl_rna", None), "identifier", "") or ""),
    }


def _resolve_id_reference(record):
    if not isinstance(record, dict):
        return None
    direct = record.get("direct")
    if direct is not None:
        try:
            direct.as_pointer()
            return direct
        except Exception:
            pass
    name = str(record.get("name") or "")
    uid = int(record.get("uid") or 0)
    rna = str(record.get("rna") or "")
    for collection_name in _ID_COLLECTION_NAMES:
        collection = getattr(bpy.data, collection_name, None)
        if collection is None:
            continue
        candidate = None
        if name:
            try:
                candidate = collection.get(name)
            except Exception:
                candidate = None
        if candidate is not None:
            try:
                if (not rna or candidate.bl_rna.identifier == rna) and (not uid or _id_uid(candidate) == uid):
                    record["direct"] = candidate
                    return candidate
            except Exception:
                pass
        if uid:
            try:
                for candidate in collection:
                    if _id_uid(candidate) != uid:
                        continue
                    if rna and candidate.bl_rna.identifier != rna:
                        continue
                    record["direct"] = candidate
                    record["name"] = str(getattr(candidate, "name", "") or "")
                    return candidate
            except Exception:
                continue
    return None


def _snapshot_value(value):
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    try:
        if isinstance(value, bpy.types.ID):
            return _id_reference(value)
    except Exception:
        pass
    if isinstance(value, (Vector, Euler, Quaternion, Color, Matrix)):
        try:
            if isinstance(value, Matrix):
                return {_VALUE_TUPLE: tuple(tuple(float(item) for item in row) for row in value)}
            return {_VALUE_TUPLE: tuple(float(item) for item in value)}
        except Exception:
            return _SKIP_VALUE
    value_type = type(value).__name__
    if value_type in {"bpy_prop_array", "IDPropertyArray"}:
        try:
            result = tuple(_snapshot_value(item) for item in value)
        except Exception:
            return _SKIP_VALUE
        if any(item is _SKIP_VALUE for item in result):
            return _SKIP_VALUE
        return {_VALUE_TUPLE: result}
    if value_type == "IDPropertyGroup" or isinstance(value, dict):
        result = {}
        try:
            items = value.items()
        except Exception:
            return _SKIP_VALUE
        for key, item in items:
            copied = _snapshot_value(item)
            if copied is not _SKIP_VALUE:
                result[str(key)] = copied
        return {_VALUE_DICT: result}
    if isinstance(value, set):
        return {_VALUE_SET: tuple(sorted(str(item) for item in value))}
    if isinstance(value, (list, tuple)):
        result = []
        for item in value:
            copied = _snapshot_value(item)
            if copied is _SKIP_VALUE:
                return _SKIP_VALUE
            result.append(copied)
        return {_VALUE_TUPLE: tuple(result)}
    return _SKIP_VALUE


def _restore_value(value):
    if not isinstance(value, dict):
        return value
    if value.get(_VALUE_ID_REF):
        return _resolve_id_reference(value)
    if _VALUE_SET in value:
        return set(value.get(_VALUE_SET) or ())
    if _VALUE_TUPLE in value:
        return tuple(_restore_value(item) for item in value.get(_VALUE_TUPLE) or ())
    if _VALUE_DICT in value:
        return {str(key): _restore_value(item) for key, item in (value.get(_VALUE_DICT) or {}).items()}
    return value


def _snapshot_curve_mapping(mapping):
    if mapping is None or type(mapping).__name__ != "CurveMapping":
        return None
    result = {"curves": []}
    for name in (
        "use_clip",
        "extend",
        "tone",
        "clip_min_x",
        "clip_min_y",
        "clip_max_x",
        "clip_max_y",
        "black_level",
        "white_level",
    ):
        try:
            copied = _snapshot_value(getattr(mapping, name))
        except Exception:
            continue
        if copied is not _SKIP_VALUE:
            result[name] = copied
    try:
        mapping.initialize()
    except Exception:
        pass
    for curve in tuple(getattr(mapping, "curves", ()) or ()):
        points = []
        try:
            for point in curve.points:
                points.append({
                    "location": (float(point.location[0]), float(point.location[1])),
                    "handle_type": str(point.handle_type),
                })
        except Exception:
            points = []
        result["curves"].append(points)
    return result


def _restore_curve_mapping(mapping, snapshot) -> None:
    if mapping is None or not isinstance(snapshot, dict):
        return
    try:
        mapping.initialize()
    except Exception:
        pass
    for name, stored in snapshot.items():
        if name == "curves":
            continue
        try:
            setattr(mapping, name, _restore_value(stored))
        except Exception:
            pass
    for curve, saved_points in zip(tuple(getattr(mapping, "curves", ()) or ()), snapshot.get("curves", [])):
        try:
            existing = list(curve.points)
            for point in reversed(existing[2:]):
                curve.points.remove(point)
            if len(existing) >= 2 and len(saved_points) >= 2:
                existing[0].location = saved_points[0].get("location", existing[0].location)
                existing[0].handle_type = saved_points[0].get("handle_type", existing[0].handle_type)
                existing[1].location = saved_points[-1].get("location", existing[1].location)
                existing[1].handle_type = saved_points[-1].get("handle_type", existing[1].handle_type)
                for item in saved_points[1:-1]:
                    point = curve.points.new(float(item["location"][0]), float(item["location"][1]))
                    point.handle_type = item.get("handle_type", point.handle_type)
        except Exception:
            pass
    try:
        mapping.update()
    except Exception:
        pass


def snapshot_modifier(modifier) -> dict:
    """Capture one modifier in memory without touching external files."""
    properties = {}
    pointer_properties = {}
    nested = {}
    try:
        rna_properties = tuple(modifier.bl_rna.properties)
    except Exception:
        rna_properties = ()
    for prop in rna_properties:
        identifier = str(getattr(prop, "identifier", "") or "")
        if not identifier or identifier in {"rna_type", "name", "type"}:
            continue
        if bool(getattr(prop, "is_readonly", False)) or str(getattr(prop, "type", "") or "") == "COLLECTION":
            continue
        try:
            value = getattr(modifier, identifier)
        except Exception:
            continue
        if type(value).__name__ == "CurveMapping":
            saved = _snapshot_curve_mapping(value)
            if saved is not None:
                nested[identifier] = saved
            continue
        copied = _snapshot_value(value)
        if copied is _SKIP_VALUE:
            continue
        if str(getattr(prop, "type", "") or "") == "POINTER":
            pointer_properties[identifier] = copied
        else:
            properties[identifier] = copied

    id_properties = {}
    try:
        keys = tuple(modifier.keys())
    except Exception:
        keys = ()
    for key in keys:
        if str(key) == "_RNA_UI":
            continue
        try:
            copied = _snapshot_value(modifier[key])
        except Exception:
            continue
        if copied is not _SKIP_VALUE:
            id_properties[str(key)] = copied

    special = {}
    if str(getattr(modifier, "type", "") or "") == "HOOK":
        try:
            special["hook_vertex_indices"] = tuple(int(index) for index in modifier.vertex_indices_get())
        except Exception:
            pass
    if str(getattr(modifier, "type", "") or "") == "UV_PROJECT":
        try:
            special["projectors"] = [
                _snapshot_value(projector.object) for projector in modifier.projectors
            ]
        except Exception:
            pass

    return {
        "name": str(getattr(modifier, "name", "") or "Modifier"),
        "type": str(getattr(modifier, "type", "") or ""),
        "properties": properties,
        "pointer_properties": pointer_properties,
        "nested": nested,
        "id_properties": id_properties,
        "special": special,
    }


def _apply_modifier_snapshot(modifier, snapshot) -> None:
    # Assign data-block pointers first. Geometry Nodes socket ID properties and
    # subtarget strings depend on those pointers already being available.
    for identifier, stored in (snapshot.get("pointer_properties") or {}).items():
        try:
            setattr(modifier, str(identifier), _restore_value(stored))
        except Exception:
            pass
    for identifier, stored in (snapshot.get("properties") or {}).items():
        try:
            setattr(modifier, str(identifier), _restore_value(stored))
        except Exception:
            pass
    for identifier, saved in (snapshot.get("nested") or {}).items():
        try:
            _restore_curve_mapping(getattr(modifier, str(identifier)), saved)
        except Exception:
            pass
    for key, stored in (snapshot.get("id_properties") or {}).items():
        try:
            modifier[str(key)] = _restore_value(stored)
        except Exception:
            pass

    special = snapshot.get("special") or {}
    indices = special.get("hook_vertex_indices")
    if indices is not None:
        try:
            modifier.vertex_indices_set(tuple(int(index) for index in indices))
        except Exception:
            pass
    projectors = special.get("projectors")
    if projectors is not None:
        try:
            modifier.projector_count = len(projectors)
            for projector, stored in zip(modifier.projectors, projectors):
                projector.object = _restore_value(stored)
        except Exception:
            pass


def clone_modifier_to_object(source_modifier, target_object):
    """Clone one modifier for direct operations or temporary evaluation."""
    snapshot = snapshot_modifier(source_modifier)
    modifier_type = str(snapshot.get("type") or "")
    if not modifier_type:
        return None
    try:
        result = target_object.modifiers.new(str(snapshot.get("name") or "Modifier"), modifier_type)
    except Exception:
        return None
    _apply_modifier_snapshot(result, snapshot)
    return result


def snapshot_modifier_stack(obj) -> dict:
    try:
        modifiers = tuple(obj.modifiers)
    except Exception:
        modifiers = ()
    try:
        active = obj.modifiers.active
        active_index = obj.modifiers.find(active.name) if active is not None else -1
    except Exception:
        active_index = -1
    return {
        "name": str(getattr(obj, "name_full", "") or getattr(obj, "name", "") or ""),
        "uid": _id_uid(obj),
        "active_index": int(active_index),
        "modifiers": [snapshot_modifier(modifier) for modifier in modifiers],
    }


def _restore_modifier_stack(record) -> bool:
    if not isinstance(record, dict):
        return False
    obj = _resolve_object(record)
    if obj is None:
        return False
    snapshots = tuple(record.get("modifiers") or ())
    try:
        for modifier in reversed(tuple(obj.modifiers)):
            obj.modifiers.remove(modifier)
    except Exception:
        return False
    rebuilt = []
    for snapshot in snapshots:
        modifier_type = str(snapshot.get("type") or "")
        if not modifier_type:
            continue
        try:
            modifier = obj.modifiers.new(str(snapshot.get("name") or "Modifier"), modifier_type)
        except Exception:
            continue
        _apply_modifier_snapshot(modifier, snapshot)
        rebuilt.append(modifier)
    active_index = int(record.get("active_index", -1))
    if rebuilt and active_index >= 0:
        active_index = max(0, min(active_index, len(rebuilt) - 1))
        try:
            obj.modifiers.active = rebuilt[active_index]
        except Exception:
            pass
    try:
        obj.update_tag(refresh={"OBJECT", "DATA"})
    except Exception:
        pass
    return True


def capture_modifier_stacks(objects) -> list[dict]:
    result = []
    seen = set()
    for obj in tuple(objects or ()):
        try:
            key = int(obj.as_pointer())
            if key in seen:
                continue
            seen.add(key)
            result.append(snapshot_modifier_stack(obj))
        except Exception:
            continue
    return result


# -----------------------------------------------------------------------------
# Edit-mesh state tokens and transactions


def _mesh_entry(mesh, create: bool = True):
    state = _state(create)
    if state is None:
        return None
    key = _mesh_key(mesh)
    entry = state["meshes"].get(key)
    if not isinstance(entry, dict):
        if not create:
            uid = _id_uid(mesh)
            for old_key, candidate in tuple(state["meshes"].items()):
                if int(candidate.get("uid") or 0) == uid and uid:
                    entry = candidate
                    if old_key != key:
                        state["meshes"].pop(old_key, None)
                        state["meshes"][key] = entry
                    break
        if not isinstance(entry, dict):
            if not create:
                return None
            entry = {
                "name": str(mesh.name),
                "uid": _id_uid(mesh),
                "states": {},
                "zero_state": None,
                "modifier_states": {},
                "zero_modifier_state": None,
                "payloads": {},
                "zero_payloads": {},
                "state_order": [],
                "objects": [],
                "last_synced_token": None,
            }
            state["meshes"][key] = entry
    entry["name"] = str(mesh.name)
    entry["uid"] = _id_uid(mesh)
    entry.setdefault("states", {})
    entry.setdefault("zero_state", None)
    entry.setdefault("modifier_states", {})
    entry.setdefault("zero_modifier_state", None)
    entry.setdefault("payloads", {})
    entry.setdefault("zero_payloads", {})
    entry.setdefault("state_order", [])
    entry.setdefault("objects", [])
    entry.setdefault("last_synced_token", None)
    return entry


def _next_token() -> int:
    state = _state(True)
    if state is None:
        return 0
    token = int(state.get("next_token") or 1)
    if token <= 0 or token > _MAX_TOKEN:
        token = 1
    state["next_token"] = token + 1
    return token


def _known_tokens(entry) -> set[int]:
    result = set()
    for container_name in ("states", "modifier_states", "payloads"):
        for token in entry.get(container_name, {}):
            try:
                value = int(token)
            except Exception:
                continue
            if value > 0:
                result.add(value)
    return result


def _layer_name() -> str:
    state = _state(True)
    return str(state.get("layer_name") or "") if state else ""


def _edit_bmesh(mesh):
    try:
        if bool(getattr(mesh, "is_editmode", False)):
            return bmesh.from_edit_mesh(mesh)
    except Exception:
        pass
    return None


def _token_counts_from_bmesh(bm, layer_name: str) -> Counter:
    counts = Counter()
    if bm is None or not layer_name:
        return counts
    try:
        layer = bm.verts.layers.int.get(layer_name)
    except Exception:
        layer = None
    if layer is None:
        return counts
    try:
        for vert in bm.verts:
            value = int(vert[layer])
            if value > 0:
                counts[value] += 1
    except Exception:
        return Counter()
    return counts


def _token_counts_from_mesh(mesh, layer_name: str) -> Counter:
    counts = Counter()
    if mesh is None or not layer_name:
        return counts
    try:
        attribute = mesh.attributes.get(layer_name)
    except Exception:
        attribute = None
    if attribute is None:
        return counts
    try:
        if str(getattr(attribute, "domain", "")) != "POINT" or str(getattr(attribute, "data_type", "")) != "INT":
            return counts
    except Exception:
        return counts
    try:
        values = [0] * len(attribute.data)
        attribute.data.foreach_get("value", values)
        counts.update(value for value in values if int(value) > 0)
    except Exception:
        try:
            for item in attribute.data:
                value = int(item.value)
                if value > 0:
                    counts[value] += 1
        except Exception:
            return Counter()
    return counts


def read_known_token(mesh, entry=None) -> int:
    """Return the dominant token known to this runtime, or zero if absent."""
    entry = entry or _mesh_entry(mesh, create=False)
    if not isinstance(entry, dict):
        return 0
    known = _known_tokens(entry)
    if not known:
        return 0
    bm = _edit_bmesh(mesh)
    counts = _token_counts_from_bmesh(bm, _layer_name()) if bm is not None else _token_counts_from_mesh(mesh, _layer_name())
    candidates = [(count, token) for token, count in counts.items() if token in known]
    if not candidates:
        return 0
    candidates.sort(reverse=True)
    return int(candidates[0][1])


def _write_token(mesh, token: int, *, bm=None) -> bool:
    layer_name = _layer_name()
    token = int(token or 0)
    if not layer_name or mesh is None:
        return False
    bm = bm or _edit_bmesh(mesh)
    if bm is not None:
        try:
            layer = bm.verts.layers.int.get(layer_name)
            if token <= 0:
                if layer is not None:
                    bm.verts.layers.int.remove(layer)
            else:
                if layer is None:
                    layer = bm.verts.layers.int.new(layer_name)
                for vert in bm.verts:
                    vert[layer] = token
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            return True
        except Exception:
            return False
    try:
        attribute = mesh.attributes.get(layer_name)
    except Exception:
        attribute = None
    try:
        if token <= 0:
            if attribute is not None:
                mesh.attributes.remove(attribute)
            return True
        if attribute is None or str(getattr(attribute, "domain", "")) != "POINT" or str(getattr(attribute, "data_type", "")) != "INT":
            if attribute is not None:
                mesh.attributes.remove(attribute)
            attribute = mesh.attributes.new(name=layer_name, type="INT", domain="POINT")
        values = [token] * len(attribute.data)
        try:
            attribute.data.foreach_set("value", values)
        except Exception:
            for item in attribute.data:
                item.value = token
        mesh.update()
        return True
    except Exception:
        return False


def _remove_stale_private_layers(mesh) -> None:
    current = _layer_name()
    bm = _edit_bmesh(mesh)
    if bm is not None:
        try:
            names = tuple(bm.verts.layers.int.keys())
        except Exception:
            names = ()
        changed = False
        for name in names:
            if str(name).startswith(_LAYER_PREFIX) and str(name) != current:
                try:
                    layer = bm.verts.layers.int.get(name)
                    if layer is not None:
                        bm.verts.layers.int.remove(layer)
                        changed = True
                except Exception:
                    pass
        if changed:
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except Exception:
                pass
        return
    try:
        attributes = tuple(mesh.attributes)
    except Exception:
        attributes = ()
    changed = False
    for attribute in attributes:
        try:
            name = str(attribute.name)
            if name.startswith(_LAYER_PREFIX) and name != current:
                mesh.attributes.remove(attribute)
                changed = True
        except Exception:
            pass
    if changed:
        try:
            mesh.update()
        except Exception:
            pass


def _mesh_users(mesh, candidates=()) -> tuple:
    result = []
    seen = set()
    for obj in candidates:
        try:
            if obj.type == "MESH" and obj.data == mesh:
                key = int(obj.as_pointer())
                if key not in seen:
                    seen.add(key)
                    result.append(obj)
        except Exception:
            continue
    try:
        expected_users = int(mesh.users)
    except Exception:
        expected_users = len(result)
    if expected_users > len(result):
        # Shared data is uncommon. Scan only when the operation is executed.
        for obj in bpy.data.objects:
            try:
                if obj.type != "MESH" or obj.data != mesh:
                    continue
                key = int(obj.as_pointer())
                if key in seen:
                    continue
                seen.add(key)
                result.append(obj)
            except Exception:
                continue
    return tuple(result)


def _prune_entry(entry) -> None:
    order = entry.setdefault("state_order", [])
    while len(order) > _MAX_STATES_PER_MESH:
        old = int(order.pop(0))
        entry.get("states", {}).pop(old, None)
        entry.get("modifier_states", {}).pop(old, None)
        entry.get("payloads", {}).pop(old, None)


def _remember_state(entry, token: int, objects, matrices=None) -> None:
    token = int(token or 0)
    if token <= 0 or not isinstance(entry, dict):
        return
    matrix_map = matrices or {}
    records = []
    for obj in objects:
        try:
            matrix = matrix_map.get(str(obj.name), obj.matrix_world)
            records.append(_object_record(obj, matrix))
        except Exception:
            continue
    entry["states"][token] = records
    entry["objects"] = [_object_record(obj) for obj in objects]
    order = entry["state_order"]
    if token in order:
        order.remove(token)
    order.append(token)
    _prune_entry(entry)


def _remember_modifier_state(entry, token: int, modifier_states) -> None:
    if not isinstance(entry, dict):
        return
    copied = list(modifier_states or ())
    token = int(token or 0)
    if token > 0:
        entry.setdefault("modifier_states", {})[token] = copied
    else:
        entry["zero_modifier_state"] = copied


def register_payload_handler(namespace: str, callback) -> bool:
    namespace = str(namespace or "").strip()
    if not namespace or not callable(callback) or not ensure():
        return False
    state = _state(True)
    if state is None:
        return False
    state.setdefault("payload_handlers", {})[namespace] = callback
    return True


def unregister_payload_handler(namespace: str, callback=None) -> None:
    state = _state(False)
    if not state:
        return
    handlers = state.get("payload_handlers")
    if not isinstance(handlers, dict):
        return
    namespace = str(namespace or "").strip()
    current = handlers.get(namespace)
    if current is not None and (callback is None or current is callback):
        handlers.pop(namespace, None)


def set_transaction_payload(record, namespace: str, before_payload, after_payload) -> bool:
    if not isinstance(record, dict):
        return False
    entry = record.get("entry")
    namespace = str(namespace or "").strip()
    if not isinstance(entry, dict) or not namespace:
        return False
    before_token = int(record.get("before_token") or 0)
    after_token = int(record.get("after_token") or 0)
    if before_token > 0:
        entry.setdefault("payloads", {}).setdefault(before_token, {})[namespace] = before_payload
    else:
        entry.setdefault("zero_payloads", {})[namespace] = before_payload
    if after_token > 0:
        entry.setdefault("payloads", {}).setdefault(after_token, {})[namespace] = after_payload
    return after_token > 0


def prepare_edit_meshes(context) -> bool:
    """Create a known baseline token before an Undo-owning child starts."""
    objects = capture_edit_objects(context)
    if not objects or not ensure():
        return False
    grouped = {}
    for obj in objects:
        try:
            grouped.setdefault(int(obj.data.as_pointer()), {"mesh": obj.data, "edit_objects": []})["edit_objects"].append(obj)
        except Exception:
            continue
    prepared = False
    for group in grouped.values():
        mesh = group["mesh"]
        _remove_stale_private_layers(mesh)
        entry = _mesh_entry(mesh, create=True)
        users = _mesh_users(mesh, group["edit_objects"])
        token = read_known_token(mesh, entry)
        if token <= 0:
            token = _next_token()
            if token <= 0 or not _write_token(mesh, token):
                continue
        _remember_state(entry, token, users)
        entry["last_synced_token"] = token
        prepared = True
    return prepared


def begin_transaction(context):
    """Begin one top-level Edit-Mesh Undo transaction."""
    objects = capture_edit_objects(context)
    if not objects or not ensure():
        return None
    grouped = {}
    for obj in objects:
        try:
            grouped.setdefault(int(obj.data.as_pointer()), {"mesh": obj.data, "edit_objects": []})["edit_objects"].append(obj)
        except Exception:
            continue
    records = []
    for group in grouped.values():
        mesh = group["mesh"]
        _remove_stale_private_layers(mesh)
        entry = _mesh_entry(mesh, create=True)
        before_token = read_known_token(mesh, entry)
        users = _mesh_users(mesh, group["edit_objects"])
        before_matrices = {str(obj.name): obj.matrix_world.copy() for obj in users}
        if before_token > 0:
            _remember_state(entry, before_token, users, matrices=before_matrices)
        else:
            entry["zero_state"] = [_object_record(obj, before_matrices.get(str(obj.name))) for obj in users]
        entry["last_synced_token"] = before_token
        records.append({
            "mesh": mesh,
            "entry": entry,
            "edit_objects": tuple(group["edit_objects"]),
            "users": users,
            "tracked_objects": users,
            "before_token": before_token,
            "after_token": _next_token(),
            "before_matrices": before_matrices,
        })
    return records or None


def begin_prepared_transaction(context):
    """Return transaction records after ``prepare_edit_meshes`` was called."""
    objects = capture_edit_objects(context)
    if not objects or not ensure():
        return None
    grouped = {}
    for obj in objects:
        try:
            grouped.setdefault(int(obj.data.as_pointer()), {"mesh": obj.data, "edit_objects": []})["edit_objects"].append(obj)
        except Exception:
            continue
    records = []
    for group in grouped.values():
        mesh = group["mesh"]
        entry = _mesh_entry(mesh, create=True)
        before_token = read_known_token(mesh, entry)
        if before_token <= 0:
            return None
        users = _mesh_users(mesh, group["edit_objects"])
        before_matrices = {str(obj.name): obj.matrix_world.copy() for obj in users}
        _remember_state(entry, before_token, users, matrices=before_matrices)
        entry["last_synced_token"] = before_token
        records.append({
            "mesh": mesh,
            "entry": entry,
            "edit_objects": tuple(group["edit_objects"]),
            "users": users,
            "tracked_objects": users,
            "before_token": before_token,
            "after_token": _next_token(),
            "before_matrices": before_matrices,
        })
    return records or None


def track_transaction_objects(record, objects) -> tuple:
    """Extend a transaction with related objects such as unchanged children."""
    if not isinstance(record, dict):
        return ()
    unique = []
    seen = set()
    for obj in tuple(objects or ()):
        try:
            key = int(obj.as_pointer())
        except Exception:
            continue
        if key in seen:
            continue
        seen.add(key)
        unique.append(obj)
    tracked = tuple(unique)
    record["tracked_objects"] = tracked
    before = record.setdefault("before_matrices", {})
    for obj in tracked:
        try:
            before.setdefault(str(obj.name), obj.matrix_world.copy())
        except Exception:
            pass
    entry = record.get("entry")
    token = int(record.get("before_token") or 0)
    if isinstance(entry, dict):
        if token > 0:
            _remember_state(entry, token, tracked, matrices=before)
        else:
            entry["zero_state"] = [_object_record(obj, before.get(str(obj.name))) for obj in tracked]
    return tracked


def track_transaction_modifiers(record, objects) -> tuple:
    """Capture pre-operation modifier stacks for an Edit-Mode transaction."""
    if not isinstance(record, dict):
        return ()
    unique = []
    seen = set()
    for obj in tuple(objects or ()):
        try:
            if obj is None or not hasattr(obj, "modifiers"):
                continue
            key = int(obj.as_pointer())
        except Exception:
            continue
        if key in seen:
            continue
        seen.add(key)
        unique.append(obj)
    objects = tuple(unique)
    states = capture_modifier_stacks(objects)
    record["modifier_objects"] = objects
    record["before_modifier_states"] = states
    _remember_modifier_state(record.get("entry"), int(record.get("before_token") or 0), states)
    return objects


def commit_transaction_modifiers(record, objects=None) -> bool:
    if not isinstance(record, dict):
        return False
    tracked = tuple(objects or record.get("modifier_objects") or ())
    states = capture_modifier_stacks(tracked)
    record["after_modifier_states"] = states
    _remember_modifier_state(record.get("entry"), int(record.get("after_token") or 0), states)
    return True


def rollback_transaction_modifiers(record) -> None:
    if not isinstance(record, dict):
        return
    for snapshot in tuple(record.get("before_modifier_states") or ()):
        try:
            _restore_modifier_stack(snapshot)
        except Exception:
            pass


def commit_transaction_record(record, matrices, *, bm=None) -> bool:
    mesh = record.get("mesh")
    entry = record.get("entry")
    token = int(record.get("after_token") or 0)
    if mesh is None or not isinstance(entry, dict) or token <= 0:
        return False
    _remember_state(entry, token, record.get("tracked_objects", record.get("users", ())), matrices=matrices)
    if not _write_token(mesh, token, bm=bm):
        return False
    entry["last_synced_token"] = token
    return True


def rollback_transaction_record(record, *, bm=None) -> None:
    mesh = record.get("mesh")
    if mesh is None:
        return
    for obj in record.get("tracked_objects", record.get("users", ())):
        try:
            matrix = record.get("before_matrices", {}).get(str(obj.name))
            if matrix is not None:
                obj.matrix_world = matrix
        except Exception:
            pass
    rollback_transaction_modifiers(record)
    before_token = int(record.get("before_token") or 0)
    _write_token(mesh, before_token, bm=bm)
    entry = record.get("entry")
    if isinstance(entry, dict):
        entry["last_synced_token"] = before_token


# -----------------------------------------------------------------------------
# Undo/Redo synchronization


def _object_parent_depth(obj) -> int:
    depth = 0
    seen = set()
    current = getattr(obj, "parent", None)
    while current is not None and depth < 1024:
        try:
            key = int(current.as_pointer())
        except Exception:
            break
        if key in seen:
            break
        seen.add(key)
        depth += 1
        current = getattr(current, "parent", None)
    return depth


def _apply_matrix_assignments(assignments) -> bool:
    pending = []
    for obj, matrix in tuple(assignments or ()):
        if obj is None or matrix is None:
            continue
        pending.append((_object_parent_depth(obj), obj, matrix))
    if not pending:
        return False
    pending.sort(key=lambda item: item[0])
    index = 0
    while index < len(pending):
        depth = pending[index][0]
        while index < len(pending) and pending[index][0] == depth:
            _depth, obj, matrix = pending[index]
            try:
                obj.matrix_world = matrix
            except Exception:
                pass
            index += 1
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
    return True


def _sync_state_from_tokens() -> None:
    state = _state(False)
    if not state or state.get("shutdown") or state.get("syncing"):
        return
    state["syncing"] = True
    try:
        assignments_by_pointer = {}
        modifier_jobs = []
        payload_jobs = []
        payload_handlers = dict(state.get("payload_handlers", {}) or {})
        for entry in tuple(state.get("meshes", {}).values()):
            mesh = _resolve_mesh(entry)
            if mesh is None:
                continue
            token = read_known_token(mesh, entry)
            if entry.get("last_synced_token") == token:
                continue
            if token <= 0:
                object_states = entry.get("zero_state")
                modifier_states = entry.get("zero_modifier_state")
                payload_map = entry.get("zero_payloads")
            else:
                object_states = entry.get("states", {}).get(token)
                modifier_states = entry.get("modifier_states", {}).get(token)
                payload_map = entry.get("payloads", {}).get(token)

            if isinstance(modifier_states, list):
                modifier_jobs.extend(modifier_states)
            if isinstance(object_states, list):
                for object_record in object_states:
                    obj = _resolve_object(object_record)
                    if obj is None:
                        continue
                    matrix = _matrix_from(object_record.get("matrix"))
                    if matrix is None:
                        continue
                    try:
                        assignments_by_pointer[int(obj.as_pointer())] = (obj, matrix)
                    except Exception:
                        pass
            if isinstance(payload_map, dict):
                for namespace, payload in tuple(payload_map.items()):
                    callback = payload_handlers.get(namespace)
                    if callable(callback):
                        payload_jobs.append((callback, payload, entry, token))
            entry["last_synced_token"] = token

        for snapshot in modifier_jobs:
            try:
                _restore_modifier_stack(snapshot)
            except Exception:
                pass
        _apply_matrix_assignments(assignments_by_pointer.values())
        for callback, payload, entry, token in payload_jobs:
            try:
                callback(payload, entry, token)
            except Exception:
                pass
    finally:
        state["syncing"] = False


def _undo_post(_dummy=None):
    _sync_state_from_tokens()


def _redo_post(_dummy=None):
    _sync_state_from_tokens()


def _load_pre(_dummy=None):
    # Opening another .blend discards the current Undo history.
    shutdown()


def _strip_current_layer(mesh) -> int:
    entry = _mesh_entry(mesh, create=False)
    token = read_known_token(mesh, entry) if entry else 0
    _write_token(mesh, 0)
    return token


def _save_pre(_filepath=None):
    state = _state(False)
    if not state or state.get("shutdown"):
        return
    restore = []
    for key, entry in tuple(state.get("meshes", {}).items()):
        mesh = _resolve_mesh(entry)
        if mesh is None:
            continue
        token = _strip_current_layer(mesh)
        if token > 0:
            restore.append((key, token))
    state["save_restore"] = restore


def _restore_after_save() -> None:
    state = _state(False)
    if not state or state.get("shutdown"):
        return
    restore = list(state.get("save_restore") or ())
    state["save_restore"] = []
    for key, token in restore:
        entry = state.get("meshes", {}).get(key)
        if not isinstance(entry, dict):
            continue
        mesh = _resolve_mesh(entry)
        if mesh is not None:
            _write_token(mesh, int(token))


def _save_post(_filepath=None):
    _restore_after_save()


def _save_post_fail(_filepath=None):
    _restore_after_save()


def handler_count() -> int:
    total = 0
    for collection in (
        bpy.app.handlers.undo_post,
        bpy.app.handlers.redo_post,
        bpy.app.handlers.load_pre,
        bpy.app.handlers.save_pre,
        bpy.app.handlers.save_post,
        bpy.app.handlers.save_post_fail,
    ):
        total += sum(1 for function in collection if _is_handler(function))
    return total


def timer_active() -> bool:
    """Compatibility audit API. This implementation never registers a timer."""
    return False


def shutdown() -> None:
    """Remove private mesh state and all handlers during full Suite teardown."""
    state = _state(False)
    if state is not None:
        state["shutdown"] = True
        state["payload_handlers"] = {}
        state["save_restore"] = []
        for entry in tuple(state.get("meshes", {}).values()):
            mesh = _resolve_mesh(entry)
            if mesh is not None:
                _write_token(mesh, 0)
        state["meshes"] = {}
    for collection in (
        bpy.app.handlers.undo_post,
        bpy.app.handlers.redo_post,
        bpy.app.handlers.load_pre,
        bpy.app.handlers.save_pre,
        bpy.app.handlers.save_post,
        bpy.app.handlers.save_post_fail,
    ):
        for function in tuple(collection):
            if _is_handler(function):
                try:
                    collection.remove(function)
                except Exception:
                    pass
    try:
        bpy.app.driver_namespace.pop(_BRIDGE_NS_KEY, None)
    except Exception:
        pass
