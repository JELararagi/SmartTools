# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Compatibility shim for legacy Key Ops preference utility imports."""

from .preferences_utils import *  # noqa: F401,F403
