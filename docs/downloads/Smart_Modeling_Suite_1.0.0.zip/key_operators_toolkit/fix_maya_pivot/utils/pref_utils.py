# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Resolve historical preference imports to the shared preference services."""

from . import preferences_utils as _preferences

__all__ = tuple(getattr(_preferences, "__all__", ()) or (name for name in vars(_preferences) if not name.startswith("_")))


def __getattr__(name):
    if name not in __all__:
        raise AttributeError(name)
    return getattr(_preferences, name)


def __dir__():
    return sorted(set(globals()) | set(__all__))
