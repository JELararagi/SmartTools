from .addon_preferences import KeyOpsPreferences
from .operators.rebind import Rebind
from .utils.register_extensions import get_extension, register_classes, unregister_classes, register_keymaps, unregister_keymaps
from .utils.pref_utils import register_icons, unregister_icons 

default_classes = [KeyOpsPreferences,Rebind]
debug = False

if 'bpy' in locals():
    import os
    import importlib

    for cls in default_classes:
        importlib.reload(cls)
    
    from . import classes_keymap_items

    for module in [classes_keymap_items]:
        importlib.reload(module)

    utils_modules = sorted([name[:-3] for name in os.listdir(os.path.join(__path__[0], "utils")) if name.endswith('.py')])

    for module in utils_modules:
        impline = f"from . utils import {module}"

        if debug:
            pass

        exec(impline)
        importlib.reload(eval(module))

    modules = []

    for label in classes_keymap_items.classes:
        entries = classes_keymap_items.classes[label]
        for entry in entries:
            path = entry[0].split('.')
            module = path.pop(-1)

            if (path, module) not in modules:
                modules.append((path, module))

    for path, module in modules:
        if path:
            impline = f"from . {'.'.join(path)} import {module}"
        else:
            impline = f"from . import {module}"

        if debug:
            pass

        exec(impline)
        importlib.reload(eval(module))

import bpy

def register():
    global classes, keymaps, default_classes, icons

    if debug:
        import time 
        addon_start_time = time.time()

    # Register default classes
    for cls in default_classes:
        bpy.utils.register_class(cls)

    # Polycount settings are persistent configuration, independent of whether
    # its optional operator/panel entry is enabled.  Materialize the native
    # owner unconditionally; its live mesh scan remains gated by both explicit
    # always-on switches and is therefore idle while those switches are OFF.
    from .operators.poly_count_list import PolyCountList
    PolyCountList.register()

    # Get extension classes and keymaps
    extension_classlists, extension_keylists = get_extension()

    # Register extension classes
    classes = register_classes(extension_classlists)

    # Lazy operator shells do not run the source class's register callback.
    # Own the settings separately from the optional UV panel lifecycle.
    from .utils.register_extensions import acquire_shared_scene_properties
    acquire_shared_scene_properties("uv_sync", "keyops_package")

    # Register extension keymaps
    keymaps = register_keymaps(extension_keylists)
    if debug:
            pass

    icons = register_icons()
    try:
        from .utils import preferences_utils as _preferences_utils
        _preferences_utils.set_icons(icons)
    except Exception:
        pass


def unregister():
    from .utils.register_extensions import release_shared_scene_properties
    release_shared_scene_properties("uv_sync", "keyops_package")
    # Persistent Polycount ownership is intentionally retained when only its
    # optional UI is switched off, but must be removed first during full Suite
    # teardown even if another bundled class later fails to unregister.
    try:
        from .operators.poly_count_list import PolyCountList
        PolyCountList.unregister()
    except Exception:
        pass

    for cls in default_classes:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
 
    global classes, keymaps, icons
    unregister_keymaps(keymaps)
    unregister_classes(classes)

    # When the optional Polycount entry was disabled it is absent from
    # ``classes``, so Blender cannot invoke its class unregister callback.
    # The callback is idempotent and also covers that case.
    try:
        from .operators.poly_count_list import PolyCountList
        PolyCountList.unregister()
    except Exception:
        pass

    classes, keymaps = None, None

    try:
        from .utils import preferences_utils as _preferences_utils
        _preferences_utils.set_icons(None)
    except Exception:
        pass
    unregister_icons(icons)
