from __future__ import annotations

from .fix_maya_pivot import *  # noqa: F401,F403
from .fix_maya_pivot import __name__ as _SMARTTOOLS_ENTRY_NAME
from .fix_maya_pivot import register as _smarttools_entry_register
from .fix_maya_pivot import unregister as _smarttools_entry_unregister
import importlib as _smarttools_importlib

_smarttools_entry_module = _smarttools_importlib.import_module('.fix_maya_pivot', __package__)
bl_info = getattr(_smarttools_entry_module, 'bl_info', {
    'name': 'Key Operators Toolkit',
    'author': 'Smart Modeling',
    'version': (1, 0, 0),
    'blender': (5, 0, 0),
    'location': 'Extensions > Install from Disk',
    'description': 'Key Operators Toolkit integrated wrapper for Smart Modeling.',
    'category': '3D View',
})


def register():
    return _smarttools_entry_register()


def unregister():
    return _smarttools_entry_unregister()
