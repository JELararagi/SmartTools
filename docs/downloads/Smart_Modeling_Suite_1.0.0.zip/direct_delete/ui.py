import bpy
from .settings import get_settings

def _t(msgid: str) -> str:
    return bpy.app.translations.pgettext(msgid)

def _enabled(context) -> bool:
    try:
        from ..utils import feature_enabled
        return feature_enabled(context, "enable_direct_delete", True)
    except Exception:
        return True

class VIEW3D_PT_direct_delete(bpy.types.Panel):
    """Direct Delete - main panel (short, modern layout)."""

    bl_label = "Direct Delete"
    bl_description = 'Direct Delete panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return

        # --- Quick Actions ---
        box = layout.box()
        box.label(text=_t("Quick Delete"), icon='TRASH')

        row = box.row(align=True)
        row.scale_y = 1.25
        row.operator("mesh.delete_direct", text=_t("Direct Delete (Smart)"), icon='TRASH')
        row.operator("mesh.delete_direct_through", text=_t("Through"), icon='RESTRICT_SELECT_OFF')

        row = box.row(align=True)
        row.operator("mesh.delete_direct_del", text=_t("DEL Override"), icon='EVENT_DEL')
        row.operator("mesh.delete_direct_bs", text=_t("Override Backspace"), icon='EVENT_BACKSPACE')

        # Object mode helpers (only when relevant)
        if context.mode == 'OBJECT':
            box = layout.box()
            box.label(text=_t("Object Mode"), icon='OBJECT_DATA')
            row = box.row(align=True)
            row.operator("object.delete_direct_objects", text=_t("Delete Objects (No Popup)"), icon='TRASH')
            row.operator("object.delete_history_modifiers", text=_t("Delete History (Remove Modifiers)"), icon='MODIFIER')


# -----------------------------
# Sub-panels (foldable sections)
# -----------------------------

class VIEW3D_PT_direct_delete_mode(bpy.types.Panel):
    bl_label = "Mode"
    bl_description = 'Mode panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete_mode"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return
        box = layout.box()
        box.label(text=_t("Mode"), icon='OPTIONS')
        box.prop(s, "smart_context")
        row = box.row(align=True)
        row.prop(s, "ignore_hidden")
        row.prop(s, "multi_object_edit")

class VIEW3D_PT_direct_delete_actions(bpy.types.Panel):
    bl_label = "Per-Element Action"
    bl_description = 'Per-Element Action panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete_actions"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return
        box = layout.box()
        box.label(text=_t("Per-Element Action"), icon='MESH_DATA')
        box.prop(s, "vert_action")
        box.prop(s, "edge_action")
        box.prop(s, "face_action")

class VIEW3D_PT_direct_delete_through(bpy.types.Panel):
    bl_label = "Delete Through"
    bl_description = 'Delete Through panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete_through"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return
        box = layout.box()
        box.label(text=_t("Delete Through"), icon='RESTRICT_SELECT_OFF')
        box.prop(s, "use_delete_through")
        row = box.row(align=True)
        row.prop(s, "through_samples")
        row.prop(s, "through_radius_px")
        box.prop(s, "through_depth")

class VIEW3D_PT_direct_delete_topology(bpy.types.Panel):
    bl_label = "Topology Aware"
    bl_description = 'Topology Aware panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete_topology"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return
        box = layout.box()
        box.label(text=_t("Topology Aware"), icon='MOD_TRIANGULATE')
        box.prop(s, "topology_aware")
        row = box.row(align=True)
        row.prop(s, "topo_try_grid_fill")
        row.prop(s, "topo_join_tris")
        box.prop(s, "topo_max_hole_verts")

class VIEW3D_PT_direct_delete_post(bpy.types.Panel):
    bl_label = "Post Process"
    bl_description = 'Post Process panel in the Smart Modeling workspace.'
    bl_idname = "VIEW3D_PT_direct_delete_post"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _enabled(context)

    def draw(self, context):
        s = get_settings(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not s:
            layout.label(text=_t("Settings not found."), icon='ERROR')
            return
        box = layout.box()
        box.label(text=_t("Post Process"), icon='BRUSH_DATA')
        row = box.row(align=True)
        row.prop(s, "auto_fill")
        row.prop(s, "auto_relax")
        box.prop(s, "relax_iterations")
        box.prop(s, "relax_factor")


# -----------------------------
# Smart Modeling Suite hosted UI
# -----------------------------

def _pick(en: str, ja: str, context=None) -> str:
    try:
        from .. import language as _sms_language
        return _sms_language.pick_text(en, ja, context=context)
    except Exception:
        return _t(ja if str(getattr(getattr(getattr(context, "preferences", None), "view", None), "language", "") or "").startswith("ja") else en)


def _prop(layout, data, name: str, **kwargs) -> bool:
    try:
        if data is None or not name:
            return False
        layout.prop(data, name, **kwargs)
        return True
    except Exception:
        return False


def draw_smart_modeling_settings(layout, context):
    """Draw Direct Delete settings inside Smart Modeling Suite's unified page.

    This avoids dumping raw RNA groups into the hosted settings page and keeps
    keymap registration details in the suite-level popup button.
    """
    s = get_settings(context)
    layout.use_property_split = True
    layout.use_property_decorate = False

    if not s:
        box = layout.box()
        box.alert = True
        box.label(text=_pick("Direct Delete settings are not available.", "直接削除の設定を利用できません。", context), icon='ERROR')
        return

    # Execution
    box = layout.box()
    box.label(text=_pick("Execution", "実行", context), icon='TRASH')
    row = box.row(align=True)
    row.scale_y = 1.15
    row.operator("mesh.delete_direct", text=_pick("Delete Selection", "選択を削除", context), icon='TRASH')
    row.operator("mesh.delete_direct_through", text=_pick("Through", "貫通", context), icon='XRAY')
    row = box.row(align=True)
    row.operator("mesh.delete_direct_del", text=_pick("DEL Override", "DEL上書き", context), icon='EVENT_DEL')
    row.operator("mesh.delete_direct_bs", text=_pick("Backspace Override", "Backspace上書き", context), icon='EVENT_BACKSPACE')
    if getattr(context, 'mode', '') == 'OBJECT':
        row = box.row(align=True)
        row.operator("object.delete_direct_objects", text=_pick("Delete Objects", "オブジェクトを削除", context), icon='OUTLINER_OB_MESH')
        row.operator("object.delete_history_modifiers", text=_pick("Delete History", "履歴を削除", context), icon='MODIFIER')

    # Basic behavior
    box = layout.box()
    box.label(text=_pick("Basic Behavior", "基本動作", context), icon='OPTIONS')
    _prop(box, s, "smart_context")
    row = box.row(align=True)
    _prop(row, s, "ignore_hidden")
    _prop(row, s, "multi_object_edit")

    # Element actions
    box = layout.box()
    box.label(text=_pick("Per-Element Action", "要素別アクション", context), icon='MESH_DATA')
    _prop(box, s, "vert_action")
    _prop(box, s, "edge_action")
    _prop(box, s, "face_action")

    # Delete through
    box = layout.box()
    box.label(text=_pick("Delete Through", '貫通選択を削除', context), icon='RESTRICT_SELECT_OFF')
    _prop(box, s, "use_delete_through")
    row = box.row(align=True)
    _prop(row, s, "through_samples")
    _prop(row, s, "through_radius_px")
    _prop(box, s, "through_depth")

    # Cleanup and topology
    box = layout.box()
    box.label(text=_pick("Cleanup / Topology", "クリーンアップ / トポロジー", context), icon='MOD_TRIANGULATE')
    _prop(box, s, "topology_aware")
    row = box.row(align=True)
    _prop(row, s, "topo_try_grid_fill")
    _prop(row, s, "topo_join_tris")
    _prop(box, s, "topo_max_hole_verts")
    box.separator()
    row = box.row(align=True)
    _prop(row, s, "auto_fill")
    _prop(row, s, "auto_relax")
    _prop(box, s, "relax_iterations")
    _prop(box, s, "relax_factor")
    box.separator()
    _prop(box, s, "auto_clean")
    _prop(box, s, "clean_merge_dist")
    _prop(box, s, "clean_degenerate_dist")

    # Advanced safeguards
    box = layout.box()
    box.label(text=_pick("Advanced / Safety", "詳細 / 安全", context), icon='LOCKED')
    _prop(box, s, "soft_delete")
    _prop(box, s, "soft_radius")
    _prop(box, s, "soft_falloff_power")
    box.separator()
    _prop(box, s, "safety_guard")
    _prop(box, s, "safety_threshold")
    box.separator()
    row = box.row(align=True)
    _prop(row, s, "preview_overlay")
    _prop(row, s, "object_mode_delete_enabled")
    _prop(box, s, "delete_history_modifiers")


# --- Tooltip completion (Direct Delete panels) ---
VIEW3D_PT_direct_delete.bl_description = 'Main panel for instant delete behaviors, delete-through, topology-aware cleanup, and post-process options.'
VIEW3D_PT_direct_delete_mode.bl_description = 'Choose the primary Direct Delete mode and how the shortcut behaves.'
VIEW3D_PT_direct_delete_actions.bl_description = 'Configure per-element behavior for vertices, edges, and faces when deleting instantly.'
VIEW3D_PT_direct_delete_through.bl_description = 'Options for deleting through occluded or stacked mesh elements.'
VIEW3D_PT_direct_delete_topology.bl_description = 'Topology-aware safeguards and cleanup choices to reduce messy results after delete.'
VIEW3D_PT_direct_delete_post.bl_description = 'Optional post-process steps that run after the delete action completes.'
