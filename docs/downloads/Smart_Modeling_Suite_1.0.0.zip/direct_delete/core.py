# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

"""Crash-safe Direct Delete operators.

The standalone Direct_Delete behavior is preserved: delete the current edit-mode
selection immediately without Blender's delete popup.  On interactive Blender
builds the actual topology mutation is deferred to a short timer so the running
operator can return before Blender's event/handler stack resolves operator RNA.
This avoids Blender 5.1 Windows crashes observed after ``bpy.ops.mesh.delete_direct()``.
"""

from __future__ import annotations

import bpy
import bmesh

from . import undo_bridge as _dd_undo_bridge
from . import object_undo_bridge as _dd_object_undo_bridge

try:
    from ..edit_multi import edit_mesh_objects as _sms_edit_mesh_objects
except Exception:
    _sms_edit_mesh_objects = None


_PENDING_DELETE_SNAPSHOTS: list[dict] = []
_DELETE_TIMER_REGISTERED = False


def _safe_undo_push(message='Smart Modeling Action'):
    """Push one explicit undo state without touching operator RNA/history.

    Direct Delete intentionally avoids Blender's REGISTER/last-operator path on
    Windows 5.1 because that path has repeatedly crashed while resolving stale
    operator/report data after destructive edit-mode deletes.  This helper keeps
    undo/redo usable for the finished mesh mutation while avoiding self.report()
    and operator property serialization.
    """
    try:
        bpy.ops.ed.undo_push(message=str(message or 'Smart Modeling Action'))
        return True
    except Exception:
        return False


def _stop_conflicting_runtime(context=None):
    """Stop modal/timer/draw states before destructive deletion.

    Keep the user's toggle flags intact. Resetting Scene/WindowManager RNA from
    a destructive mesh operator can force Blender 5.1 to resolve stale operator
    properties during report/redraw generation.
    """
    del context
    try:
        from ..vertex_slide import operators as _svs_ops
        stop = getattr(_svs_ops, '_svs_stop_timer_monitor', None)
        if callable(stop):
            stop()
    except Exception:
        pass
    try:
        from ..quad_strip_draw import common as _qsd_common
        request_stop = getattr(_qsd_common, 'request_stop', None)
        if callable(request_stop):
            request_stop()
    except Exception:
        pass
    try:
        from . import preview as _dd_preview
        remove = getattr(_dd_preview, 'remove_handler', None)
        if callable(remove):
            remove()
    except Exception:
        pass


def _force_cancel_result(status):
    """Return a crash-safe operator result for Direct Delete.

    In Blender 5.1 Windows, FINISHED mesh operators can enter
    WM_operator_pystring_ex / WM_operator_last_properties_store after the mesh
    was already changed, which has crashed in the user logs for Direct Delete.
    The geometry operation is already complete, so interactive UI calls return
    CANCELLED to skip those post-operator history/report code paths.  Background
    test runs may return FINISHED because there is no UI operator history.
    """
    try:
        status_set = set(status or ())
    except Exception:
        status_set = set()
    if 'FINISHED' not in status_set:
        return {'CANCELLED'}
    return {'CANCELLED'}


_STABLE_TRANSFORM_ORIENTATIONS = {
    'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT',
    'OBJECT', 'WORLD',
}


def _sanitize_dynamic_transform_orientation(context=None):
    """Avoid stale face/custom orientation pointers before topology deletion.

    Blender stores ad-hoc Face orientations as named transform orientations.
    If a selected face is deleted while that orientation is active, Blender 5.1
    Windows can later crash while formatting the following operator report.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        slots = getattr(scene, 'transform_orientation_slots', None) if scene is not None else None
        if slots is None:
            return
        for slot in list(slots):
            try:
                current = str(getattr(slot, 'type', '') or '')
            except Exception:
                current = ''
            if current and current not in _STABLE_TRANSFORM_ORIENTATIONS:
                try:
                    slot.type = 'GLOBAL'
                except Exception:
                    pass
    except Exception:
        pass


def _clear_bmesh_active_selection(bm):
    try:
        bm.select_history.clear()
    except Exception:
        pass
    try:
        bm.faces.active = None
    except Exception:
        pass


def _pgettext(message: str) -> str:
    try:
        return bpy.app.translations.pgettext(str(message))
    except Exception:
        return str(message)


def _edit_mesh_objects(context):
    if callable(_sms_edit_mesh_objects):
        try:
            return list(_sms_edit_mesh_objects(context, unique_data=True))
        except Exception:
            pass
    objects = []
    try:
        for obj in tuple(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or ()):  # multi-object edit mode
            if obj is not None and getattr(obj, "type", None) == 'MESH' and getattr(obj, "mode", None) == 'EDIT' and obj not in objects:
                objects.append(obj)
    except Exception:
        pass
    if objects:
        return objects
    try:
        obj = getattr(context, "active_object", None)
        if obj is not None and getattr(obj, "type", None) == 'MESH' and getattr(obj, "mode", None) == 'EDIT':
            return [obj]
    except Exception:
        pass
    return []


def _active_edit_mesh_object(context):
    objects = _edit_mesh_objects(context)
    if not objects:
        return None
    try:
        active = getattr(context, "active_object", None)
        if active in objects:
            return active
    except Exception:
        pass
    return objects[0]


def _selection_mode(context):
    try:
        mode = tuple(bool(value) for value in getattr(context.tool_settings, "mesh_select_mode", (True, False, False)))
    except Exception:
        mode = (True, False, False)
    if len(mode) < 3:
        mode = tuple(mode) + (False,) * (3 - len(mode))
    return mode[:3]


def _safe_indices(elements, attr='index'):
    result = []
    for elem in elements:
        try:
            if elem.select:
                idx = int(getattr(elem, attr))
                if idx >= 0:
                    result.append(idx)
        except Exception:
            pass
    return result


def _ensure_bmesh_tables(bm):
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass
    for seq in (getattr(bm, 'verts', ()), getattr(bm, 'edges', ()), getattr(bm, 'faces', ())):
        try:
            seq.index_update()
        except Exception:
            pass


def _safe_update_edit_mesh(mesh):
    try:
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=True)
        return True
    except TypeError:
        try:
            bmesh.update_edit_mesh(mesh)
            return True
        except Exception:
            return False
    except Exception:
        return False



def _direct_delete_settings(context):
    try:
        wm = getattr(context, 'window_manager', None)
        settings = getattr(wm, 'direct_delete_settings', None) if wm is not None else None
        return settings
    except Exception:
        return None


def _snapshot_edit_delete(context, variant='SMART', mouse_xy=None):
    del variant, mouse_xy
    _stop_conflicting_runtime(context)
    _sanitize_dynamic_transform_orientation(context)
    objects = _edit_mesh_objects(context)
    if not objects:
        return None
    select_mode = _selection_mode(context)
    settings = _direct_delete_settings(context)

    records = []
    for obj in objects:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            _ensure_bmesh_tables(bm)
        except Exception:
            continue
        delete_context = ''
        action = 'AUTO'
        if select_mode[2]:
            delete_kind = 'FACES'
            indices = _safe_indices(bm.faces)
            try:
                action = str(getattr(settings, 'face_action', 'AUTO') or 'AUTO').strip().upper()
            except Exception:
                action = 'AUTO'
            # AUTO/DELETE mirrors Blender's normal Face delete behavior: remove
            # selected faces together with non-shared adjacent boundary edges and
            # vertices.  Keep FACES_ONLY only for the explicit Only Faces action.
            delete_context = 'FACES_ONLY' if action == 'ONLY_FACES' else 'FACES'
        elif select_mode[1]:
            delete_kind = 'EDGES'
            indices = _safe_indices(bm.edges)
            try:
                action = str(getattr(settings, 'edge_action', 'AUTO') or 'AUTO').strip().upper()
            except Exception:
                action = 'AUTO'
            delete_context = 'EDGES'
        else:
            delete_kind = 'VERTS'
            indices = _safe_indices(bm.verts)
            try:
                action = str(getattr(settings, 'vert_action', 'AUTO') or 'AUTO').strip().upper()
            except Exception:
                action = 'AUTO'
            delete_context = 'VERTS'
        if not indices:
            continue
        try:
            object_name = str(obj.name)
        except Exception:
            object_name = ''
        records.append({
            'object_name': object_name,
            'delete_kind': delete_kind,
            'delete_context': delete_context,
            'action': action,
            'indices': tuple(indices),
        })

    if not records:
        return None
    snapshot = {
        'kind': 'edit_mesh',
        'objects': tuple(records),
        'select_mode': tuple(bool(v) for v in select_mode),
    }
    # Backward-compatible top-level fields for single-object snapshots and any
    # external caller that still inspects the old structure.
    if len(records) == 1:
        snapshot.update(records[0])
    return snapshot

def _snapshot_object_delete(context):
    _stop_conflicting_runtime(context)
    try:
        selected = [str(obj.name) for obj in (getattr(context, "selected_objects", ()) or []) if obj is not None]
    except Exception:
        selected = []
    if not selected:
        return None
    return {
        'kind': 'objects',
        'object_names': tuple(selected),
    }


def _ensure_edit_object(obj):
    try:
        ctx = bpy.context
        if getattr(ctx, 'mode', '') != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except Exception:
            pass
        obj.select_set(True)
        ctx.view_layer.objects.active = obj
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass
        return getattr(obj, 'mode', '') == 'EDIT'
    except Exception:
        return False


def _apply_edit_delete_record(record: dict) -> bool:
    obj = None
    try:
        obj = bpy.data.objects.get(str(record.get('object_name') or ''))
    except Exception:
        obj = None
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    # Never run bpy.ops from the Direct Delete apply path.  In multi-object Edit
    # Mode each participating object already owns a live edit BMesh; abort an
    # object if it is no longer in Edit Mode instead of mode-toggling here.
    if getattr(obj, 'mode', '') != 'EDIT':
        return False
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        _ensure_bmesh_tables(bm)
    except Exception:
        return False
    delete_kind = str(record.get('delete_kind') or 'VERTS')
    indices = {int(i) for i in tuple(record.get('indices') or ()) if int(i) >= 0}
    if not indices:
        return False
    try:
        if delete_kind == 'FACES':
            geom = [face for face in bm.faces if int(face.index) in indices]
        elif delete_kind == 'EDGES':
            geom = [edge for edge in bm.edges if int(edge.index) in indices]
        else:
            geom = [vert for vert in bm.verts if int(vert.index) in indices]
        if not geom:
            return False
        delete_context = str(record.get('delete_context') or delete_kind or 'VERTS').strip().upper()
        if delete_kind == 'FACES' and delete_context not in {'FACES', 'FACES_ONLY'}:
            delete_context = 'FACES'
        elif delete_kind == 'EDGES' and delete_context not in {'EDGES', 'EDGES_FACES'}:
            delete_context = 'EDGES'
        elif delete_kind == 'VERTS' and delete_context != 'VERTS':
            delete_context = 'VERTS'
        _clear_bmesh_active_selection(bm)
        bmesh.ops.delete(bm, geom=geom, context=delete_context)
        _clear_bmesh_active_selection(bm)
        try:
            bm.select_flush_mode()
        except Exception:
            pass
        if not _safe_update_edit_mesh(obj.data):
            return False
        return True
    except Exception:
        return False


def _apply_edit_delete_snapshot(snapshot: dict) -> bool:
    _stop_conflicting_runtime(bpy.context)
    _sanitize_dynamic_transform_orientation(bpy.context)
    records = tuple(snapshot.get('objects') or ())
    if not records:
        records = (snapshot,)
    changed = False
    for record in records:
        if not isinstance(record, dict):
            continue
        try:
            if _apply_edit_delete_record(record):
                changed = True
        except Exception:
            pass
    if changed:
        _stop_conflicting_runtime(bpy.context)
    return changed

def _apply_object_delete_snapshot(snapshot: dict) -> bool:
    _stop_conflicting_runtime(bpy.context)
    names = tuple(str(name or '') for name in tuple(snapshot.get('object_names') or ()) if str(name or ''))
    if not names:
        return False
    try:
        if getattr(bpy.context, 'mode', '') != 'OBJECT':
            return False
    except Exception:
        return False
    changed = False
    for name in names:
        try:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                bpy.data.objects.remove(obj, do_unlink=True)
                changed = True
        except Exception:
            pass
    _stop_conflicting_runtime(bpy.context)
    return changed


def _apply_delete_snapshot(snapshot: dict) -> bool:
    if not isinstance(snapshot, dict):
        return False
    if str(snapshot.get('kind') or '') == 'objects':
        return _apply_object_delete_snapshot(snapshot)
    return _apply_edit_delete_snapshot(snapshot)


def clear_pending_delete_snapshots():
    """Cancel queued Direct Delete timer work before unloading or disabling runtime."""
    global _DELETE_TIMER_REGISTERED
    _PENDING_DELETE_SNAPSHOTS.clear()
    _DELETE_TIMER_REGISTERED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_flush_pending_delete_snapshots):
            timers.unregister(_flush_pending_delete_snapshots)
    except Exception:
        pass


def _flush_pending_delete_snapshots():
    global _DELETE_TIMER_REGISTERED
    _DELETE_TIMER_REGISTERED = False
    queue = list(_PENDING_DELETE_SNAPSHOTS)
    _PENDING_DELETE_SNAPSHOTS.clear()
    for snapshot in queue:
        try:
            _apply_delete_snapshot(snapshot)
        except Exception:
            pass
    return None


def _schedule_delete_snapshot(snapshot: dict, *, undo_transaction=None, object_undo_transaction=None) -> bool:
    global _DELETE_TIMER_REGISTERED
    if not snapshot:
        return False
    # Apply synchronously and return CANCELLED in interactive sessions via
    # _force_cancel_result().  This avoids both known crash paths: operator-history
    # string/report generation after FINISHED and deferred py_timer_execute access
    # to stale RNA/operator pointers.
    #
    # Edit-Mesh deletion uses a directional token bridge.  It records only the
    # post-change state and restores the click-before selection from the token
    # transition, so consecutive clicks create exactly one visible Undo step
    # each.  Object-Mode callers retain the older explicit boundary until their
    # separate Global-Undo bridge is installed.
    _DELETE_TIMER_REGISTERED = False
    _PENDING_DELETE_SNAPSHOTS.clear()
    changed = _apply_delete_snapshot(snapshot)
    if not changed:
        if undo_transaction is not None:
            try:
                _dd_undo_bridge.rollback(undo_transaction)
            except Exception:
                pass
        if object_undo_transaction is not None:
            try:
                _dd_object_undo_bridge.rollback(object_undo_transaction)
            except Exception:
                pass
        return False
    if undo_transaction is not None:
        try:
            if _dd_undo_bridge.commit(undo_transaction, bpy.context):
                return True
        except Exception:
            pass
    if object_undo_transaction is not None:
        try:
            if _dd_object_undo_bridge.commit(
                object_undo_transaction, bpy.context, message='Direct Delete Objects'
            ):
                return True
        except Exception:
            pass
    _safe_undo_push('Direct Delete')
    return True


def perform_delete(context, variant='SMART', mouse_xy=None):
    snapshot = _snapshot_edit_delete(context, variant=variant, mouse_xy=mouse_xy)
    if not snapshot:
        return {'CANCELLED'}, _pgettext("Nothing selected")
    transaction = None
    try:
        transaction = _dd_undo_bridge.begin(context)
    except Exception:
        transaction = None
    if transaction is None:
        # Crash-safe compatibility fallback.  The normal path above is used on
        # Blender 5.1 and is the only path accepted by the consecutive Undo
        # regression.  Keep this fallback for unusual contexts where Edit-Mesh
        # token initialization is unavailable.
        _safe_undo_push('Before Direct Delete')
    ok = _schedule_delete_snapshot(snapshot, undo_transaction=transaction)
    return ({'FINISHED'} if ok else {'CANCELLED'}), _pgettext("Delete scheduled")


def perform_object_delete(context):
    snapshot = _snapshot_object_delete(context)
    if not snapshot:
        return {'CANCELLED'}, _pgettext("Nothing selected")
    transaction = None
    try:
        transaction = _dd_object_undo_bridge.begin(context)
    except Exception:
        transaction = None
    if transaction is None:
        _safe_undo_push('Before Direct Delete')
    ok = _schedule_delete_snapshot(snapshot, object_undo_transaction=transaction)
    return ({'FINISHED'} if ok else {'CANCELLED'}), _pgettext("Delete scheduled")


class _BaseMeshOp(bpy.types.Operator):
    bl_description = 'Internal base operator class used by Direct Delete.'
    # Direct Delete deliberately returns CANCELLED after a successful mutation
    # to avoid Blender 5.1's unstable last-operator serialization path.  The
    # actual edit is bounded by the directional token bridge, which creates one
    # history step per click while restoring the exact click-before selection.
    # Giving this wrapper Blender's automatic UNDO ownership creates an empty
    # Edit-Mode step when there is no selection (the first Ctrl+Z only changes
    # mode instead of reverting the previous edit), and can also duplicate the
    # explicit history boundary on changed operations.
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return _active_edit_mesh_object(context) is not None


class MESH_OT_delete_direct(_BaseMeshOp):
    bl_idname = "mesh.delete_direct"
    bl_label = 'Delete Selection'
    bl_description = "Delete the selected vertices, edges, or faces immediately according to the active mesh selection mode, without opening Blender's delete popup."

    def execute(self, context):
        status, _msg = perform_delete(context, variant='SMART')
        return _force_cancel_result(status)


class MESH_OT_delete_direct_del(_BaseMeshOp):
    bl_idname = "mesh.delete_direct_del"
    bl_label = 'Override Delete Key'
    bl_description = "Run Direct Delete from a Delete-key override."

    def execute(self, context):
        status, _msg = perform_delete(context, variant='DEL')
        return _force_cancel_result(status)


class MESH_OT_delete_direct_bs(_BaseMeshOp):
    bl_idname = "mesh.delete_direct_bs"
    bl_label = 'Override Backspace'
    bl_description = "Run Direct Delete from a Backspace override."

    def execute(self, context):
        status, _msg = perform_delete(context, variant='BS')
        return _force_cancel_result(status)


class MESH_OT_delete_direct_through(_BaseMeshOp):
    bl_idname = "mesh.delete_direct_through"
    bl_label = 'Delete Through Selection'
    bl_description = "Run Direct Delete using the stable selection-based path."

    def execute(self, context):
        status, _msg = perform_delete(context, variant='THROUGH')
        return _force_cancel_result(status)


class OBJECT_OT_delete_direct_objects(bpy.types.Operator):
    bl_idname = "object.delete_direct_objects"
    bl_label = 'Delete Objects'
    bl_description = "Delete the selected objects without an extra confirmation popup."
    # The object deletion owns an explicit before/after undo boundary in
    # ``perform_object_delete``.  Keep this crash-safe CANCELLED wrapper out of
    # Blender's automatic operator history.
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        try:
            return getattr(context, "mode", "") == 'OBJECT' and bool(getattr(context, "selected_objects", ()))
        except Exception:
            return False

    def execute(self, context):
        status, _msg = perform_object_delete(context)
        return _force_cancel_result(status)


def perform_delete_history_modifiers(context):
    """Remove selected-object modifiers as one explicit Global Undo step."""
    try:
        if getattr(context, "mode", "") != 'OBJECT':
            return {'CANCELLED'}, _pgettext("Object Mode is required")
    except Exception:
        return {'CANCELLED'}, _pgettext("Object Mode is required")

    selected = list(getattr(context, "selected_objects", ()) or ())
    # Determine the complete change set before opening an Undo transaction.
    # Repeating the command on objects without modifiers must not add an empty
    # step or consume the previous real edit.
    targets = []
    for obj in selected:
        try:
            modifiers = tuple(getattr(obj, "modifiers", ()) or ())
        except Exception:
            modifiers = ()
        if modifiers:
            targets.append((obj, modifiers))
    if not targets:
        return {'CANCELLED'}, _pgettext("No modifiers to remove")

    transaction = None
    try:
        transaction = _dd_object_undo_bridge.begin(context)
    except Exception:
        transaction = None
    if transaction is None:
        _safe_undo_push('Before Delete History')

    changed = False
    for obj, modifiers in targets:
        for modifier in modifiers:
            try:
                obj.modifiers.remove(modifier)
                changed = True
            except Exception:
                pass
    if not changed:
        if transaction is not None:
            try:
                _dd_object_undo_bridge.rollback(transaction)
            except Exception:
                pass
        return {'CANCELLED'}, _pgettext("No modifiers removed")

    committed = False
    if transaction is not None:
        try:
            committed = _dd_object_undo_bridge.commit(
                transaction, context, message='Delete History'
            )
        except Exception:
            committed = False
    if not committed:
        _safe_undo_push('Delete History')
    return {'FINISHED'}, _pgettext("Modifiers removed")


class OBJECT_OT_delete_history_mods(bpy.types.Operator):
    bl_idname = "object.delete_history_modifiers"
    bl_label = "Delete History (Remove Modifiers)"
    bl_description = "Remove all modifiers from the selected objects."
    # Modifier removal is explicitly bounded by perform_delete_history_modifiers.
    # The wrapper itself does not own an automatic Blender Undo step.
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        try:
            return getattr(context, "mode", "") == 'OBJECT' and bool(getattr(context, "selected_objects", ()))
        except Exception:
            return False

    def execute(self, context):
        status, _message = perform_delete_history_modifiers(context)
        return _force_cancel_result(status)

