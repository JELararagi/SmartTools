# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Lazy package shell for Direct Delete.

Only the PropertyGroup/AddonPreferences schema is imported with Smart Modeling's
N-panel shell.  Operators, BMesh code, preview helpers, and keymap helpers are
loaded when the Direct Delete settings are opened or a registered shortcut is
used for the first time.
"""

from __future__ import annotations

import importlib
import sys

import bpy

from . import translation as i18n
from . import settings


bl_info = {
    "name": "Direct Delete",
    "author": "JELararagi",
    "version": (2, 0, 4),
    "blender": (5, 1, 0),
    "location": "View3D > N-panel > Direct Delete / Shortcut",
    "description": "Smart delete without popup (Max/Maya-like). ID: 'mesh.delete_direct'",
    "category": "Mesh",
}


# Runtime modules intentionally remain unloaded until first use.
core = None
ui = None
keymap = None
preview = None
classes = ()
_DIRECT_DELETE_PROPERTY_CLASSES = (
    settings.DirectDeleteSettings,
    settings.DIRECTDELETE_AddonPreferences,
)
_DIRECT_DELETE_RUNTIME_CLASSES = ()


def _load_runtime_modules():
    global core, ui, keymap, preview, classes, _DIRECT_DELETE_RUNTIME_CLASSES
    package = __name__
    if core is None:
        core = importlib.import_module(package + ".core")
    if ui is None:
        ui = importlib.import_module(package + ".ui")
    if keymap is None:
        keymap = importlib.import_module(package + ".keymap")
    if preview is None:
        preview = importlib.import_module(package + ".preview")
    runtime_classes = (
        keymap.DIRECTDELETE_OT_install_keymaps,
        keymap.DIRECTDELETE_OT_remove_keymaps,
        core.MESH_OT_delete_direct,
        core.MESH_OT_delete_direct_del,
        core.MESH_OT_delete_direct_bs,
        core.MESH_OT_delete_direct_through,
        core.OBJECT_OT_delete_direct_objects,
        core.OBJECT_OT_delete_history_mods,
    )
    _DIRECT_DELETE_RUNTIME_CLASSES = runtime_classes
    classes = (
        settings.DirectDeleteSettings,
        *runtime_classes,
        settings.DIRECTDELETE_AddonPreferences,
    )
    return core, ui, keymap, preview


def _loaded_module(suffix: str):
    return sys.modules.get(__name__ + suffix)


# ------------------------------------------------------------
# Lazy keymap proxy helpers
# ------------------------------------------------------------

def _sms_direct_delete_mouse_xy(context):
    region = getattr(context, "region", None)
    if region is not None and getattr(region, "type", "") == "WINDOW":
        try:
            return (int(getattr(region, "width", 0) or 0) // 2, int(getattr(region, "height", 0) or 0) // 2)
        except Exception:
            pass
    area = getattr(context, "area", None)
    if area is not None:
        try:
            for region in getattr(area, "regions", ()):
                if getattr(region, "type", "") == "WINDOW":
                    return (int(getattr(region, "width", 0) or 0) // 2, int(getattr(region, "height", 0) or 0) // 2)
        except Exception:
            pass
    return (0, 0)


def _sms_execute_delete_variant(context=None, *, variant="SMART"):
    runtime_core, _runtime_ui, _runtime_keymap, _runtime_preview = _load_runtime_modules()
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return {"CANCELLED"}
    mouse_xy = None
    if str(variant or "").strip() == "THROUGH":
        mouse_xy = _sms_direct_delete_mouse_xy(ctx)
    try:
        status, _message = runtime_core.perform_delete(
            ctx,
            variant=str(variant or "SMART").strip() or "SMART",
            mouse_xy=mouse_xy,
        )
        return runtime_core._force_cancel_result(status)
    except Exception:
        return {"CANCELLED"}


def execute_delete_direct_smart(context=None, *, invoke=False):
    del invoke
    return _sms_execute_delete_variant(context, variant="SMART")


def execute_delete_direct_del(context=None, *, invoke=False):
    del invoke
    return _sms_execute_delete_variant(context, variant="DEL")


def execute_delete_direct_bs(context=None, *, invoke=False):
    del invoke
    return _sms_execute_delete_variant(context, variant="BS")


def execute_delete_direct_through(context=None, *, invoke=False):
    del invoke
    return _sms_execute_delete_variant(context, variant="THROUGH")


def execute_delete_direct_objects(context=None, *, invoke=False):
    del invoke
    runtime_core, _runtime_ui, _runtime_keymap, _runtime_preview = _load_runtime_modules()
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return {"CANCELLED"}
    try:
        status, _message = runtime_core.perform_object_delete(ctx)
        return runtime_core._force_cancel_result(status)
    except Exception:
        return {"CANCELLED"}


def execute_delete_history_modifiers(context=None, *, invoke=False):
    """Lazy-keymap entry point for Delete History.

    Keep the lightweight proxy registered while it is the active wmOperator.
    The actual modifier removal is delegated to a plain Python function so the
    first key press works without unregistering/replacing the proxy RNA class.
    """
    del invoke
    runtime_core, _runtime_ui, _runtime_keymap, _runtime_preview = _load_runtime_modules()
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return {"CANCELLED"}
    try:
        status, _message = runtime_core.perform_delete_history_modifiers(ctx)
        return runtime_core._force_cancel_result(status)
    except Exception:
        return {"CANCELLED"}


def draw_smart_modeling_settings(layout, context):
    _runtime_core, runtime_ui, _runtime_keymap, _runtime_preview = _load_runtime_modules()
    draw_fn = getattr(runtime_ui, "draw_smart_modeling_settings", None)
    if callable(draw_fn):
        return draw_fn(layout, context)
    return None


# ------------------------------------------------------------
# Registration
# ------------------------------------------------------------

def _set_blinfo_description_localized():
    try:
        import addon_utils
        for module in addon_utils.modules():
            if module.__name__ != __name__:
                continue
            description_en = "Smart delete without popup (Max/Maya-like). ID: 'mesh.delete_direct'"
            try:
                description = bpy.app.translations.pgettext(description_en)
            except Exception:
                description = description_en
            try:
                prefs = getattr(bpy.context, "preferences", None)
                language = getattr(getattr(prefs, "view", None), "language", "") if prefs else ""
                if (language or "").startswith("ja") and description == description_en:
                    description = i18n.translation_dict.get("ja_JP", {}).get(("*", description_en), description)
            except Exception:
                pass
            module.bl_info["description"] = description
            break
    except Exception:
        pass


def register():
    runtime_core, _runtime_ui, runtime_keymap, _runtime_preview = _load_runtime_modules()
    del runtime_core
    try:
        bpy.app.translations.register(__name__, i18n.translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, i18n.translation_dict)

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass

    try:
        if hasattr(bpy.types.WindowManager, "direct_delete_settings"):
            del bpy.types.WindowManager.direct_delete_settings
    except Exception:
        pass
    bpy.types.WindowManager.direct_delete_settings = bpy.props.PointerProperty(
        type=settings.DirectDeleteSettings,
        description="Stores settings for Direct Delete.",
        options={"SKIP_SAVE"},
    )

    # Unified Suite policy: keymaps are user-managed and are never installed
    # automatically while registering the feature.
    try:
        runtime_keymap.remove_keymaps()
    except Exception:
        pass
    _set_blinfo_description_localized()


def unregister():
    runtime_keymap = keymap or _loaded_module(".keymap")
    runtime_core = core or _loaded_module(".core")
    runtime_preview = preview or _loaded_module(".preview")

    if runtime_keymap is not None:
        try:
            runtime_keymap.remove_keymaps()
        except Exception:
            pass
    if runtime_core is not None:
        try:
            runtime_core.clear_pending_delete_snapshots()
        except Exception:
            pass
    if runtime_preview is not None:
        try:
            runtime_preview.remove_handler()
        except Exception:
            pass

    for cls in reversed(tuple(_DIRECT_DELETE_RUNTIME_CLASSES or ())):
        if hasattr(cls, "bl_rna"):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass

    try:
        if hasattr(bpy.types.WindowManager, "direct_delete_settings"):
            del bpy.types.WindowManager.direct_delete_settings
    except Exception:
        pass

    for cls in reversed(_DIRECT_DELETE_PROPERTY_CLASSES):
        if hasattr(cls, "bl_rna"):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    try:
        import addon_utils
        for module in addon_utils.modules():
            if module.__name__ == __name__:
                module.bl_info["description"] = "Smart delete without popup (Max/Maya-like). ID: 'mesh.delete_direct'"
                break
    except Exception:
        pass


if __name__ == "__main__":
    register()
