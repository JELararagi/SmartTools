translation_dict = {
    "ja_JP": {
        # Add-on / general
        ("*", "Direct Delete"): "直接削除",
        ("*", "Smart delete without popup (Max/Maya-like). ID: 'mesh.delete_direct'"):
            'ポップアップなしの賢い削除（Max/Maya 風）。',
        ("*", "Smart delete without popup (Max/Maya-like)"): 'ポップアップなしの賢い削除（Max/Maya 風）',

        # Panel
        ("*", "Direct Delete (All)"): "直接削除（全部入り）",
        ("*", "Main"): "メイン",
        ("*", "Mode"): "モード",
        ("*", "Smart Context"): 'スマートコンテキスト',
        ("*", "Per-Element Action"): "要素別アクション",
        ("*", "Vertex Action"): '頂点の動作',
        ("*", "Edge Action"): '辺の動作',
        ("*", "Face Action"): '面の動作',
        ("*", "Delete Through"): "貫通選択を削除",
        ("*", "Topology Aware"): 'トポロジー考慮',
        ("*", "Post Process"): "後処理",
        ("*", "Auto Fill"): '自動穴埋め',
        ("*", "Auto Relax"): "自動リラックス",
        ("*", "Auto Clean"): '自動で整理',
        ("*", "Soft Delete"): "ソフト削除",
        ("*", "Safety"): "安全",
        ("*", "Preview Overlay"): 'プレビューオーバーレイ',
        ("*", "Keymap Presets"): "キーマッププリセット",

        # Operators / buttons
        ("*", "Direct Delete (Smart)"): "直接削除（スマート）",
        ("*", "Direct Delete (DEL)"): "直接削除（DEL）",
        ("*", "Direct Delete (BS)"): '直接削除（Backspace）',
        ("*", "Direct Delete (Through)"): "直接削除（貫通）",
        ("*", "Delete Objects (No Popup)"): "オブジェクトを削除（ポップアップ無し）",
        ("*", "Delete History (Remove Modifiers)"): '履歴削除（モディファイア削除）',
        ("*", "Install Keymaps"): "キーマップを追加",
        ("*", "Remove Keymaps"): "キーマップを削除",

        # Property enum labels
        ("*", "SMART"): "SMART",
        ("*", "DELETE"): "削除",
        ("*", "DISSOLVE"): "溶解",
        ("*", "COLLAPSE"): "コラプス",
        ("*", "LOOP_DELETE"): "ループ削除",
        ("*", "RING_DELETE"): "リング削除",
        ("*", "FACES"): "面",
        ("*", "EDGES"): "辺",
        ("*", "VERTS"): "頂点",
        ("*", "ONLY_FACES"): "面のみ",
        ("*", "AUTO"): "自動",
        ("*", "BLENDER"): "Blender",
        ("*", "3DSMAX"): "3dsMax",
        ("*", "MAYA"): "Maya",

        ("*", "Delete selected mesh elements instantly without a confirmation popup, using smart context-aware behavior and the add-on settings for topology-friendly cleanup."):
            "確認ポップアップ無しで選択メッシュ要素を即削除します。スマート判定とSmart Modeling Nパネル設定を使い、トポロジーを意識したクリーンアップ向けの挙動を行います。",
        ("*", "Delete selected mesh elements immediately using the dedicated DEL-override behavior."):
            "DEL上書き専用の挙動で、選択中のメッシュ要素を即削除します。",
        ("*", "Delete selected mesh elements immediately using the dedicated Backspace-override behavior."):
            "Backspaceを上書き専用の挙動で、選択中のメッシュ要素を即削除します。",
        ("*", "Delete through the mesh under the cursor for stacked or occluded geometry cleanup workflows."):
            "カーソル下のメッシュを貫通的に削除し、重なったり隠れたりしたジオメトリ整理に使えます。",
        ("*", "Delete the selected objects immediately without an extra confirmation popup."):
            "追加確認ポップアップ無しで、選択オブジェクトを即削除します。",
        ("*", "Remove modifiers from the selected objects to mimic a light Maya-style delete-history cleanup pass."):
            "選択オブジェクトのモディファイアを取り除き、Maya風の軽い履歴削除クリーンアップを行います。",
        # Tooltips (short)
        ("*", "Delete without popup based on selection mode"): "選択モードに応じてポップアップ無し削除",
        ("*", "Unsupported mode"): "未対応のモードです",
        ("*", "No editable mesh"): "編集可能なメッシュがありません",
        ("*", "Nothing selected"): "選択がありません",
        ("*", "Deleted elements"): "要素を削除しました",
    }
}

translation_dict["ja_JP"].update({
    ("*", "Automatically choose the most suitable delete behavior from the current selection pattern. This is the safest starting point for beginners because it tries to avoid unnecessary topology damage."):
        "現在の選択パターンから最適な削除方法を自動で選びます。初心者が最初に使う設定として安全で、不要なトポロジー破壊を避けやすくなります。",
    ("*", "Ignore hidden vertices, edges, and faces so the tool only edits what is currently visible."):
        "非表示の頂点・辺・面を無視し、現在見えている部分だけを編集対象にします。",
    ("*", "Apply the delete operation to every mesh that is currently participating in multi-object Edit Mode."):
        "マルチオブジェクト編集モードに参加している全メッシュへ削除処理を適用します。",
    ("*", "Choose what Delete Selection should do when the current selection is vertices. AUTO decides for you, while the other modes force a specific result."):
        '現在の選択が頂点のときに選択を削除が何を行うかを決めます。自動 は状況に応じて自動判断し、他のモードは結果を固定します。',
    ("*", "Choose what Delete Selection should do when the current selection is edges. AUTO is recommended unless you need a fixed delete style."):
        '現在の選択が辺のときに選択を削除が何を行うかを決めます。特定の削除結果を固定したい場合以外は 自動 推奨です。',
    ("*", "Choose what Delete Selection should do when the current selection is faces. AUTO uses a practical default, while the other modes force a predictable outcome."):
        '現在の選択が面のときに選択を削除が何を行うかを決めます。自動 は実用的な既定値を使い、他のモードは結果を固定します。',
    ("*", "Allow the Through variant to keep deleting surfaces under the mouse even when they are hidden behind outer faces."):
        '貫通版で、外側の面に隠れている表面も含めてマウス下を貫通選択を削除できるようにします。',
    ("*", "Number of sample rays cast around the mouse cursor. Higher values catch thin or slanted targets more reliably but cost more performance."):
        "マウスカーソル周辺へ飛ばすサンプルレイ数です。値を上げると細い形状や斜め面を拾いやすくなりますが、処理負荷は少し上がります。",
    ("*", "Size of the sampling circle around the mouse cursor in pixels. Increase this if the Through variant misses small targets."):
        'マウスカーソル周辺のサンプリング円サイズ（ピクセル）です。小さな対象を 貫通版が取り逃がす場合に増やしてください。',
    ("*", "Maximum number of surfaces that can be deleted along the cursor ray. Useful for stacked shells or overlapping geometry."):
        "カーソルレイに沿って削除できる最大表面数です。重なったシェルや多層構造の整理に役立ちます。",
    ("*", "Try to repair the surrounding topology after deletion. Useful when you want cleaner holes instead of raw element removal only."):
        "削除後に周囲のトポロジー修復を試みます。単純削除だけでなく、よりきれいな穴埋め結果を得たいときに有効です。",
    ("*", "Prefer Grid Fill when the border looks grid-like, then fall back to a simpler fill method if Grid Fill is not suitable."):
        '境界がグリッド状に見える場合はグリッドフィルを優先し、適さない場合はより単純な穴埋めへフォールバックします。',
    ("*", "After filling, try to merge nearby triangle pairs into quads for cleaner topology."):
        "穴埋め後に近接する三角形ペアを四角形へまとめ、より整ったトポロジーを目指します。",
    ("*", "Maximum border size that automatic repair is allowed to process. Lower values are safer; higher values attempt larger hole repairs."):
        "自動修復で処理する境界サイズの上限です。小さい値は安全寄りで、大きい値はより大きな穴の修復を試みます。",
    ("*", "Automatically fill open boundary holes created near the deleted region after the main delete step."):
        "メイン削除のあと、削除領域周辺にできた開口境界を自動で埋めます。",
    ("*", "Smooth nearby vertices after deletion to soften bumps and sudden shape changes around the edited area."):
        "削除後に周囲頂点を平滑化し、編集領域まわりの凹凸や急激な形状変化を和らげます。",
    ("*", "Number of smoothing passes used by Auto Relax. More iterations create a softer, more averaged result."):
        '自動リラックス で行う平滑化パス数です。回数を増やすほど、より柔らかく平均化された結果になります。',
    ("*", "Strength of each Auto Relax pass. Lower values are subtle; higher values smooth the area more aggressively."):
        '自動リラックス 1回あたりの強さです。低い値は控えめ、高い値は強めに平滑化します。',
    ("*", "Run a cleanup pass after deletion. This can merge doubles, dissolve degenerate geometry, and remove loose leftovers."):
        "削除後にクリーンアップ処理を実行します。重複頂点の統合、破損ジオメトリの溶解、ルース要素の削除などを行えます。",
    ("*", "Distance threshold used when Auto Clean merges overlapping or near-duplicate vertices."):
        '自動で整理が重なった頂点や近接重複頂点を統合する際の距離しきい値です。',
    ("*", "Threshold used to detect very small or broken geometry that should be treated as degenerate during Auto Clean."):
        '自動で整理中に極小または破損したジオメトリを縮退とみなすためのしきい値です。',
    ("*", "Expand the affected region outward from the original selection using a falloff, similar to soft-delete workflows in other DCC tools."):
        '他の DCC のソフト削除のように、元の選択から外側へフォールオフ付きで影響範囲を広げます。',
    ("*", "World-space radius used by Soft Delete to include nearby vertices around the original selection."):
        'ソフト削除が元の選択周辺の頂点を巻き込むために使うワールド空間半径です。',
    ("*", "Controls how sharply the Soft Delete influence fades. Higher values keep the effect closer to the original selection."):
        'ソフト削除の影響がどれだけ急に減衰するかを制御します。高い値ほど元の選択付近に効果が集中します。',
    ("*", "Show a confirmation warning when the current selection is unusually large, helping to prevent accidental destructive deletes."):
        "現在の選択が極端に多いときに確認警告を表示し、誤って大規模削除する事故を防ぎます。",
    ("*", "Number of selected elements that will trigger the Safety Guard confirmation dialog."):
        '安全確認の画面を出す選択の要素数です。',
    ("*", "Draw a viewport preview of the current selection or affected area when the tool supports it."):
        "対応機能では、現在の選択や影響範囲をビューポート上にプレビュー表示します。",
    ("*", "Enable the object-mode Direct Delete operator so selected objects can be removed immediately without Blender's extra delete popup."):
        'オブジェクトモード版直接削除を有効にし、Blender の追加削除ポップアップなしで選択オブジェクトを即削除できるようにします。',
    ("*", "Enable the Maya-style Delete History helper that removes all modifiers from the selected objects."):
        '選択中のオブジェクトの全モディファイアーを消す Maya 風の履歴削除を有効にします。',
    ("*", "Install and manage the Direct Delete shortcut overrides automatically. Disable this if you prefer to bind the operators manually in Blender's Keymap preferences."):
        '直接削除のショートカット上書きを自動で追加・管理します。Blender のキーマップ設定で手動割り当てしたい場合は無効にしてください。',
    ("*", "Choose a shortcut style. BLENDER keeps Blender-like behavior unless you explicitly enable overrides, 3DSMAX installs dedicated Delete and Backspace overrides, and MAYA favors Delete Selection on Delete."):
        'ショートカットスタイルを選択します。Blender は明示的に上書きを有効化しない限り Blender らしい挙動を維持し、3ds Max は Delete / Backspace 専用上書きを入れ、MAYA は Delete にスマート Delete を割り当てる構成です。',
    ("*", "Keep Blender-like behavior. Only the overrides you explicitly enable below will be installed."):
        "Blender に近い挙動を維持します。下の項目で明示的に有効化した上書きだけをインストールします。",
    ("*", "Delete = hard delete, Backspace = dissolve / only-faces. Good for a 3ds Max-style workflow."):
        "Delete はハード削除、Backspace は溶解 / 面のみ削除です。3ds Max 風ワークフロー向けです。",
    ("*", "Delete = Delete Selection, Backspace stays optional. Good for a lighter Maya-style workflow."):
        'Delete で選択を削除、Backspace は任意です。軽い Maya 風の作業に向きます。',
    ("*", "Install a Delete-key override in Edit Mode using the behavior defined by the selected preset."):
        "選択中プリセットで定義された挙動を使って、編集モードの Delete キー上書きを追加します。",
    ("*", "Install a Backspace-key override in Edit Mode using the behavior defined by the selected preset."):
        "選択中プリセットで定義された挙動を使って、編集モードの Backspace キー上書きを追加します。",
    ("*", "Install the Direct Delete shortcut entries into the current Blender key configuration using the active preset and override options."):
        '現在の Blender キー設定へ、アクティブなプリセットと上書き設定に基づく直接削除ショートカットを追加します。',
    ("*", "Remove the Direct Delete shortcut entries that were previously installed by this add-on from Blender's current key configuration."):
        'このアドオンが現在の Blender キー設定へ追加した直接削除ショートカットを削除します。',
})



translation_dict["ja_JP"].update({
    ("*", "Smart Context"): 'スマートコンテキスト',
    ("*", "Ignore Hidden"): "非表示を無視",
    ("*", "Multi-Object Edit"): "マルチオブジェクト編集",
    ("*", "Vertex Action"): '頂点の動作',
    ("*", "Edge Action"): '辺の動作',
    ("*", "Face Action"): '面の動作',
    ("*", "Delete Through"): "貫通選択を削除",
    ("*", "Samples"): "サンプル数",
    ("*", "Radius (px)"): "半径 (px)",
    ("*", "Depth Hits"): "深度ヒット数",
    ("*", "Topology Aware"): "トポロジー考慮",
    ("*", "Try Grid Fill"): 'グリッドフィルを試す',
    ("*", "Join Triangles"): "三角を結合",
    ("*", "Max Hole Verts"): "最大穴境界頂点数",
    ("*", "Auto Fill"): '自動穴埋め',
    ("*", "Auto Relax"): "自動リラックス",
    ("*", "Iterations"): "反復回数",
    ("*", "Factor"): "係数",
    ("*", "Auto Clean"): '自動で整理',
    ("*", "Merge Distance"): "マージ距離",
    ("*", "Degenerate Dist"): "縮退距離",
    ("*", "Soft Delete"): "ソフト削除",
    ("*", "Radius"): "半径",
    ("*", "Falloff Power"): '減衰の強さ',
    ("*", "Preview Overlay"): "プレビューオーバーレイ",
    ("*", "Object Mode Delete"): 'オブジェクトモードの削除',
    ("*", "Delete History (Modifiers)"): "履歴削除 (モディファイア)",
    ("*", "Enable Keymaps"): "キーマップを有効化",
    ("*", "Preset"): "プリセット",
    ("*", "Override Delete Key"): 'Deleteキーを上書き',
    ("*", "Override Backspace Key"): "Backspace キーを上書き",
})
