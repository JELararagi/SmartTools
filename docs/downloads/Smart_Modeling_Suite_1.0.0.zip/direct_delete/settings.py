import bpy
from bpy.types import PropertyGroup
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
)


def _update_keymaps(self, context):
    # Manual-only policy: Direct Delete settings never install keymap items.
    try:
        from . import keymap
        keymap.remove_keymaps()
    except Exception:
        pass
    return None


def _update_keymap_preset(self, context):
    # Preset values are retained for old files, but they do not create or update
    # Blender Preferences > Keymap entries.
    try:
        self.enable_keymaps = False
    except Exception:
        pass
    try:
        from . import keymap
        keymap.remove_keymaps()
    except Exception:
        pass
    return None

def _update_preview_overlay(self, context):
    # Original Direct_Delete has no viewport draw handler. Keep this no-op to
    # avoid persistent UI draw callbacks during normal editing.
    try:
        from . import preview
        preview.remove_handler()
    except Exception:
        pass

ADDON_ID = __package__  # "direct_delete"

def _enum_action_items():
    return [
        ('AUTO', "AUTO", "Smart / context-based"),
        ('DELETE', "DELETE", "Hard delete"),
        ('DISSOLVE', "DISSOLVE", "Dissolve to keep topology"),
        ('COLLAPSE', "COLLAPSE", "Collapse (edges mainly)"),
        ('LOOP_DELETE', "LOOP_DELETE", "Delete edge loop"),
        ('RING_DELETE', "RING_DELETE", "Delete edge ring"),
        ('ONLY_FACES', "ONLY_FACES", "Delete faces only (keep edges/verts)"),
    ]

class DirectDeleteSettings(PropertyGroup):
    # Main switches
    smart_context: BoolProperty(
        name="Smart Context",
        description="Automatically choose the most suitable delete behavior from the current selection pattern. This is the safest starting point for beginners because it tries to avoid unnecessary topology damage.",
        default=True,
    )
    ignore_hidden: BoolProperty(
        name="Ignore Hidden",
        description="Ignore hidden vertices, edges, and faces so the tool only edits what is currently visible.",
        default=True,
    )
    multi_object_edit: BoolProperty(
        name="Multi-Object Edit",
        description="Apply the delete operation to every mesh that is currently participating in multi-object Edit Mode.",
        default=True,
    )

    # Per element action
    vert_action: EnumProperty(
        name="Vertex Action",
        description="Choose what Delete Selection should do when the current selection is vertices. AUTO decides for you, while the other modes force a specific result.",
        items=_enum_action_items(),
        default='AUTO',
    )
    edge_action: EnumProperty(
        name="Edge Action",
        description="Choose what Delete Selection should do when the current selection is edges. AUTO is recommended unless you need a fixed delete style.",
        items=_enum_action_items(),
        default='AUTO',
    )
    face_action: EnumProperty(
        name="Face Action",
        description="Choose what Delete Selection should do when the current selection is faces. AUTO uses a practical default, while the other modes force a predictable outcome.",
        items=_enum_action_items(),
        default='AUTO',
    )

    # Delete through (mouse ray)
    use_delete_through: BoolProperty(
        name="Delete Through",
        description="Allow the Through variant to keep deleting surfaces under the mouse even when they are hidden behind outer faces.",
        default=False,
    )
    through_samples: IntProperty(
        name="Samples",
        description="Number of sample rays cast around the mouse cursor. Higher values catch thin or slanted targets more reliably but cost more performance.",
        default=5,
        min=1,
        max=25,
    )
    through_radius_px: IntProperty(
        name="Radius (px)",
        description="Size of the sampling circle around the mouse cursor in pixels. Increase this if the Through variant misses small targets.",
        default=6,
        min=0,
        max=80,
    )
    through_depth: IntProperty(
        name="Depth Hits",
        description="Maximum number of surfaces that can be deleted along the cursor ray. Useful for stacked shells or overlapping geometry.",
        default=32,
        min=1,
        max=512,
    )

    # Topology aware delete / repair
    topology_aware: BoolProperty(
        name="Topology Aware",
        description="Try to repair the surrounding topology after deletion. Useful when you want cleaner holes instead of raw element removal only.",
        default=False,
    )
    topo_try_grid_fill: BoolProperty(
        name="Try Grid Fill",
        description="Prefer Grid Fill when the border looks grid-like, then fall back to a simpler fill method if Grid Fill is not suitable.",
        default=True,
    )
    topo_join_tris: BoolProperty(
        name="Join Triangles",
        description="After filling, try to merge nearby triangle pairs into quads for cleaner topology.",
        default=True,
    )
    topo_max_hole_verts: IntProperty(
        name="Max Hole Verts",
        description="Maximum border size that automatic repair is allowed to process. Lower values are safer; higher values attempt larger hole repairs.",
        default=120,
        min=6,
        max=2000,
    )

    # Post process
    auto_fill: BoolProperty(
        name="Auto Fill",
        description="Automatically fill open boundary holes created near the deleted region after the main delete step.",
        default=False,
    )
    auto_relax: BoolProperty(
        name="Auto Relax",
        description="Smooth nearby vertices after deletion to soften bumps and sudden shape changes around the edited area.",
        default=False,
    )
    relax_iterations: IntProperty(
        name="Iterations",
        description="Number of smoothing passes used by Auto Relax. More iterations create a softer, more averaged result.",
        default=5,
        min=1,
        max=80,
    )
    relax_factor: FloatProperty(
        name="Factor",
        description="Strength of each Auto Relax pass. Lower values are subtle; higher values smooth the area more aggressively.",
        default=0.5,
        min=0.0,
        max=1.0,
    )

    auto_clean: BoolProperty(
        name="Auto Clean",
        description="Run a cleanup pass after deletion. This can merge doubles, dissolve degenerate geometry, and remove loose leftovers.",
        default=False,
    )
    clean_merge_dist: FloatProperty(
        name="Merge Distance",
        description="Distance threshold used when Auto Clean merges overlapping or near-duplicate vertices.",
        default=0.0001,
        min=0.0,
        max=0.1,
        precision=6,
    )
    clean_degenerate_dist: FloatProperty(
        name="Degenerate Dist",
        description="Threshold used to detect very small or broken geometry that should be treated as degenerate during Auto Clean.",
        default=0.00001,
        min=0.0,
        max=0.1,
        precision=6,
    )

    # Soft delete (selection expansion)
    soft_delete: BoolProperty(
        name="Soft Delete",
        description="Expand the affected region outward from the original selection using a falloff, similar to soft-delete workflows in other DCC tools.",
        default=False,
    )
    soft_radius: FloatProperty(
        name="Radius",
        description="World-space radius used by Soft Delete to include nearby vertices around the original selection.",
        default=0.25,
        min=0.0001,
        max=1000.0,
        precision=4,
    )
    soft_falloff_power: FloatProperty(
        name="Falloff Power",
        description="Controls how sharply the Soft Delete influence fades. Higher values keep the effect closer to the original selection.",
        default=2.0,
        min=0.1,
        max=16.0,
    )

    # Safety
    safety_guard: BoolProperty(
        name="Safety Guard",
        description="Show a confirmation warning when the current selection is unusually large, helping to prevent accidental destructive deletes.",
        default=False,
    )
    safety_threshold: IntProperty(
        name="Threshold",
        description="Number of selected elements that will trigger the Safety Guard confirmation dialog.",
        default=2000,
        min=1,
        max=5_000_000,
    )

    # Preview overlay
    preview_overlay: BoolProperty(
        name="Preview Overlay",
        description='Draw a viewport preview of the current selection or affected area only while you need it. The draw callback is disabled by default so it does not stay active during startup or normal editing.',
        default=False,
        update=_update_preview_overlay,
    )

    # Object mode helpers
    object_mode_delete_enabled: BoolProperty(
        name="Object Mode Delete",
        description="Enable the object-mode Direct Delete operator so selected objects can be removed immediately without Blender's extra delete popup.",
        default=True,
    )
    delete_history_modifiers: BoolProperty(
        name="Delete History (Modifiers)",
        description="Enable the Maya-style Delete History helper that removes all modifiers from the selected objects.",
        default=True,
    )

class DIRECTDELETE_AddonPreferences(bpy.types.PropertyGroup):


    enable_keymaps: BoolProperty(
        name="Manual Keymaps Only",
        description="Compatibility flag only. Smart Modeling Suite never installs Direct Delete keymaps automatically; copy the operator ID shown at the bottom of the tool settings and bind it manually in Blender Preferences > Keymap.",
        default=False,
        update=_update_keymaps,
    )
    keymap_preset: EnumProperty(
        name="Preset",
        description="Legacy shortcut style note retained for older saved files. It does not install or update keymaps; use the registration IDs shown in the tool settings for manual binding.",
        items=[
            ('BLENDER', "BLENDER", "Manual reference only. Keep Blender-like behavior unless you bind the operator IDs yourself."),
            ('3DSMAX', "3DSMAX", "Manual reference only. Suggested Delete / Backspace style for 3ds Max-like workflows."),
            ('MAYA', "MAYA", "Manual reference only. Suggested Delete Selection style for Maya-like workflows."),
        ],
        default='3DSMAX',
        update=_update_keymap_preset,
    )
    override_delete_key: BoolProperty(
        name="Override Delete Key",
        description="Manual reference only. This setting never installs a Delete-key override automatically.",
        default=False,
        update=_update_keymaps,
    )
    override_backspace_key: BoolProperty(
        name="Override Backspace Key",
        description="Manual reference only. This setting never installs a Backspace-key override automatically.",
        default=False,
        update=_update_keymaps,
    )

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="Manual Keymap Registration Only")
        col.label(text="Copy the operator IDs from the bottom of the Direct Delete settings and bind them manually in Preferences > Keymap.", icon='COPYDOWN')


def get_settings(context):
    wm = context.window_manager
    return getattr(wm, "direct_delete_settings", None)
