import bpy
from .settings import DIRECTDELETE_AddonPreferences

_addon_keymaps = []
_DIRECT_DELETE_KEYMAP_IDNAMES = {
    "mesh.delete_direct",
    "mesh.delete_direct_del",
    "mesh.delete_direct_bs",
    "mesh.delete_direct_through",
    "object.delete_direct_objects",
    "object.delete_history_modifiers",
}


def _addon_keyconfig():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        keyconfigs = getattr(wm, "keyconfigs", None) if wm else None
        return getattr(keyconfigs, "addon", None) if keyconfigs else None
    except Exception:
        return None


def _kmi_token(km, kmi):
    out = []
    for item in (km, kmi):
        try:
            out.append(int(item.as_pointer()))
        except Exception:
            out.append(id(item))
    return tuple(out)


def _iter_stale_keymap_items(kc):
    if kc is None:
        return
    for km in list(getattr(kc, "keymaps", ())):
        try:
            keymap_items = list(getattr(km, "keymap_items", ()))
        except Exception:
            keymap_items = []
        for kmi in keymap_items:
            try:
                idname = str(getattr(kmi, "idname", "") or "")
            except Exception:
                idname = ""
            if idname in _DIRECT_DELETE_KEYMAP_IDNAMES:
                yield km, kmi


def _remove_keymap_item(km, kmi):
    if km is None or kmi is None:
        return False
    try:
        km.keymap_items.remove(kmi)
        return True
    except Exception:
        return False

def _prefs():
    """Return Direct Delete prefs stored inside Smart Modeling N-panel settings.

    Direct Delete shortcuts are manual-only.  The preferences object is kept only
    for compatibility with older saved settings; it is never used to install
    persistent keymap items.
    """
    try:
        from ..utils import get_suite_prefs
        prefs = get_suite_prefs(bpy.context)
        if not prefs:
            return None
        try:
            from .. import core as _sms_core
            safe_get = getattr(_sms_core, "_sms_safe_get_rna_attr", None)
            if callable(safe_get):
                return safe_get(prefs, "direct_delete", None)
        except Exception:
            pass
        return None
    except Exception:
        return None

def add_keymap(kc, km_name, idname, key, value='PRESS', ctrl=False, shift=False, alt=False):
    """Compatibility no-op.

    Smart Modeling Suite must never create persistent keymap entries in
    Blender Preferences.  This function is retained so older callbacks do not
    fail, but it intentionally does not call any Preferences keymap creation API.
    """
    del kc, km_name, idname, key, value, ctrl, shift, alt
    return None


def _preset_delete_operator(prefs):
    preset = str(getattr(prefs, "keymap_preset", "3DSMAX") or "3DSMAX")
    if preset == '3DSMAX':
        return "mesh.delete_direct_del"
    return "mesh.delete_direct"


def install_keymaps():
    """Never install persistent Direct Delete keymaps.

    Older Smart Modeling builds could write Delete / Backspace overrides into
    the add-on key configuration.  New builds are manual-registration only, so
    an install request only cleans stale items and then stops.
    """
    remove_keymaps()
    return False


def remove_keymaps():
    global _addon_keymaps
    entries = list(_addon_keymaps)
    kc = _addon_keyconfig()
    if kc is not None:
        entries.extend(list(_iter_stale_keymap_items(kc)))

    seen = set()
    for km, kmi in entries:
        token = _kmi_token(km, kmi)
        if token in seen:
            continue
        seen.add(token)
        _remove_keymap_item(km, kmi)

    _addon_keymaps = []


def refresh_keymaps_from_prefs():
    # Manual-only policy: preference changes never create keymaps.
    remove_keymaps()
    return False

class DIRECTDELETE_OT_install_keymaps(bpy.types.Operator):
    bl_idname = "direct_delete.install_keymaps"
    bl_label = "Keymaps Are Manual Only"
    bl_description = "Smart Modeling Suite never installs Direct Delete shortcuts automatically. Use the registration ID shown at the bottom of the tool settings and bind it manually in Blender Preferences > Keymap."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        install_keymaps()
        self.report({'INFO'}, "Direct Delete keymaps are manual-only. Stale add-on keymaps were cleaned if present.")
        return {'FINISHED'}


class DIRECTDELETE_OT_remove_keymaps(bpy.types.Operator):
    bl_idname = "direct_delete.remove_keymaps"
    bl_label = "Clean Stale Keymaps"
    bl_description = "Remove stale Direct Delete keymap entries created by older Smart Modeling Suite builds. New shortcuts must be registered manually by the user."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        remove_keymaps()
        self.report({'INFO'}, "Stale Direct Delete keymaps cleaned.")
        return {'FINISHED'}
