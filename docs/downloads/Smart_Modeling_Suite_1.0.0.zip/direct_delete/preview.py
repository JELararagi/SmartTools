# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import bmesh
import gpu
from gpu_extras.batch import batch_for_shader

from ..compat import get_uniform_color_shader


_handler = None
_MAX_PREVIEW_POINTS = 20_000
_MAX_PREVIEW_LINES = 20_000


class _DirectDeletePreviewSnapshot:
    __slots__ = ("shader", "point_batch", "line_batch", "enabled")

    def __init__(self):
        self.shader = None
        self.point_batch = None
        self.line_batch = None
        self.enabled = False

    def clear(self):
        self.point_batch = None
        self.line_batch = None
        self.enabled = False


_PREVIEW_SNAPSHOT = _DirectDeletePreviewSnapshot()


def _get_settings(context=None):
    context = context or bpy.context
    wm = getattr(context, "window_manager", None)
    return getattr(wm, "direct_delete_settings", None) if wm is not None else None


def _collect_preview_geometry(context, settings):
    if context is None or getattr(context, "mode", None) != 'EDIT_MESH':
        return (), ()

    if bool(getattr(settings, "multi_object_edit", True)):
        objects = list(getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", ()))
    else:
        objects = [getattr(context, "active_object", None)]
    objects = [obj for obj in objects if obj is not None and obj.type == 'MESH']

    ignore_hidden = bool(getattr(settings, "ignore_hidden", True))
    points = []
    line_coordinates = []
    for obj in objects:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            matrix_world = obj.matrix_world.copy()
        except Exception:
            continue

        for vert in bm.verts:
            if vert.select and (not ignore_hidden or not vert.hide):
                points.append(matrix_world @ vert.co)
                if len(points) >= _MAX_PREVIEW_POINTS:
                    break

        remaining_lines = _MAX_PREVIEW_LINES - (len(line_coordinates) // 2)
        if remaining_lines > 0:
            for edge in bm.edges:
                if edge.select and (not ignore_hidden or not edge.hide):
                    line_coordinates.extend((matrix_world @ edge.verts[0].co, matrix_world @ edge.verts[1].co))
                    remaining_lines -= 1
                    if remaining_lines <= 0:
                        break

        if len(points) >= _MAX_PREVIEW_POINTS and len(line_coordinates) >= (_MAX_PREVIEW_LINES * 2):
            break

    return tuple(points), tuple(line_coordinates)


def refresh_snapshot(context=None):
    """Rebuild the bounded preview snapshot outside the draw callback."""
    context = context or bpy.context
    settings = _get_settings(context)
    if settings is None or not bool(getattr(settings, "preview_overlay", False)):
        _PREVIEW_SNAPSHOT.clear()
        return False

    points, lines = _collect_preview_geometry(context, settings)
    try:
        shader = get_uniform_color_shader('3D')
        point_batch = batch_for_shader(shader, 'POINTS', {"pos": points}) if points else None
        line_batch = batch_for_shader(shader, 'LINES', {"pos": lines}) if lines else None
    except Exception:
        _PREVIEW_SNAPSHOT.clear()
        return False

    _PREVIEW_SNAPSHOT.shader = shader
    _PREVIEW_SNAPSHOT.point_batch = point_batch
    _PREVIEW_SNAPSHOT.line_batch = line_batch
    _PREVIEW_SNAPSHOT.enabled = bool(point_batch or line_batch)
    return _PREVIEW_SNAPSHOT.enabled


def _draw(snapshot):
    """Draw only immutable GPU resources prepared by ``refresh_snapshot``."""
    if snapshot is None or not snapshot.enabled or snapshot.shader is None:
        return

    shader = snapshot.shader
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('LESS_EQUAL')
        if snapshot.point_batch is not None:
            gpu.state.point_size_set(5.0)
            shader.bind()
            shader.uniform_float("color", (1.0, 0.2, 0.2, 0.9))
            snapshot.point_batch.draw(shader)
        if snapshot.line_batch is not None:
            shader.bind()
            shader.uniform_float("color", (1.0, 0.2, 0.2, 0.6))
            snapshot.line_batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.point_size_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.depth_test_set('NONE')
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def ensure_handler():
    global _handler
    if bpy.app.background or _handler is not None:
        return
    try:
        _handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw,
            (_PREVIEW_SNAPSHOT,),
            'WINDOW',
            'POST_VIEW',
        )
    except Exception:
        _handler = None


def sync_handler(force_state=None):
    state = force_state
    if state is None:
        try:
            state = bool(getattr(_get_settings(), 'preview_overlay', False))
        except Exception:
            state = False

    if state:
        refresh_snapshot()
        ensure_handler()
    else:
        remove_handler()

    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def remove_handler():
    global _handler
    if _handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_handler, 'WINDOW')
        except Exception:
            pass
        _handler = None
    _PREVIEW_SNAPSHOT.clear()
