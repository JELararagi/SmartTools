# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

SUITE_META = {
    'smart_modeling_suite': ('Smart Modeling', 'pseudo_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def integrated_root() -> Path:
    return package_root()


NATIVE_TOOL_DIRS = {
    'apply_weighted_normal',
    'crease_preset',
    'direct_delete',
    'mesh_align_preset',
    'model_organized',
    'quad_strip_draw',
    'vertex_copy',
    'vertex_slide',
    'connect',
    'toggle_auto_merge_snap',
    'modeling_toolset_tools',
}

REMOVED_TOOL_DIRS = {
    'smart_' + 'modeling_' + 'smart',
    'bonsai',
    'e_topology_smooth',
    'modern_primitive',
}

# Directories used by Smart Modeling itself or generated at runtime.  These are
# not bundled add-ons and must never be exposed as tools in the N-panel.  When
# older packages may still contain read-only settings/user_data seed folders;
# filtering them here prevents
# entries such as icon / settings / user_data from appearing under Utility Tools.
NON_ADDON_DIRS = {
    '__pycache__',
    'icon',
    'icons',
    'image',
    'images',
    'resource',
    'resources',
    'asset',
    'assets',
    'settings',
    'setting',
    'user_data',
    'userdata',
    'data',
    'storage',
    'cache',
    'caches',
    'runtime',
    'tmp',
    'temp',
    'log',
    'logs',
    'backup',
    'backups',
    'preset',
    'presets',
    'locale',
    'locales',
    'translation',
    'translations',
    'doc',
    'docs',
    'documentation',
}


def is_non_addon_dir_name(name: str) -> bool:
    text = str(name or '').strip().strip('/\\').lower()
    if not text:
        return True
    if text.startswith('.') or text.startswith('__'):
        return True
    return text in NON_ADDON_DIRS


def is_visible_addon_spec(spec: dict[str, Any] | None) -> bool:
    if not isinstance(spec, dict):
        return False
    alias = str(spec.get('alias') or '').strip()
    source_alias = str(spec.get('source_alias') or '').strip()
    outer_zip = str(spec.get('outer_zip') or '').strip()
    src_dir = str(spec.get('src_dir') or '').strip()
    init_relpath = str(spec.get('init_relpath') or '').strip()
    names = [alias, source_alias, outer_zip[:-4] if outer_zip.lower().endswith('.zip') else outer_zip]
    if any(is_non_addon_dir_name(value) for value in names if value):
        return False
    if src_dir:
        try:
            if is_non_addon_dir_name(Path(src_dir).name):
                return False
        except Exception:
            pass
    # A bundled add-on must have an __init__.py chosen by _find_init_file.
    # Generated data directories do not, and should be ignored even if they sit
    # in older package-local seed layouts.
    if not init_relpath:
        return False
    return True

DISPLAY_NAME_OVERRIDES = {
    'antlandscape': 'Terrain Generator',
    'boltfactory': 'Bolt Generator',
    'cell_fracture': 'Cell Fracture',
    'extra_curve_objectes': 'Curve Objects',
    'f2': 'Face Builder',
    'key_operators_toolkit': 'Key Ops Toolkit',
    'mio3_flex': 'Flex Deform',
    'polyquilt_fork': 'PolyQuilt Retopo',
    'sapling_tree_gen': 'Tree Generator',
    'tissue': 'Tissue Generator',
    'archimesh': 'Architecture Generator',
    'curve_tools': 'Curve Toolkit',
    'edgeflow': 'Edge Flow',
    'edit_mesh_tools': 'Mesh Edit Toolkit',
    'ivygen': 'Ivy Generator',
    'looptools': 'Loop Tools',
    'mesh_repair_tools': 'Mesh Repair',
    'real_snow': 'Snow Generator',
    'scatter_objects': 'Object Scatter',
}


def vendors_root() -> Path:
    return integrated_root()


def report_path() -> Path:
    return package_root() / 'INTEGRATED_ADDONS_REPORT.md'


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'integrated_addon'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def _suite_name_to_key(label: str) -> str:
    normalized = str(label or '').strip().lower()
    for suite_key, (suite_name, _nav) in SUITE_META.items():
        if normalized == suite_name.lower() or normalized == suite_key.lower() or normalized == suite_key.replace('_', ' ').lower():
            return suite_key
    fallback = normalized.replace(' ', '_').replace('-', '_')
    if fallback.endswith('_suite'):
        return fallback
    return fallback


def simplify_folder_name(text: str) -> str:
    name = sanitize_alias(text)
    name = re.sub(r'^add_on_', '', name)
    name = re.sub(r'_v\d+(?:_\d+)*(?:_(?:windows|linux|macos)(?:_[a-z0-9]+)*)?$', '', name)
    name = re.sub(r'_v\d+(?:_\d+)*$', '', name)
    return name or sanitize_alias(text)


def _parse_report() -> dict[str, dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return {}

    specs: dict[str, dict[str, Any]] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            source_alias = sanitize_alias(match.group('outer'))
            alias = simplify_folder_name(match.group('outer'))
            current = {
                'alias': alias,
                'source_alias': source_alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': _suite_name_to_key(match.group('suite').strip()),
                'suite_name': match.group('suite').strip(),
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs[alias] = current
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''

    # Prefer AST so both single-quoted and double-quoted bl_info dictionaries are
    # handled.  The previous regex missed several bundled tools, leaving raw
    # folder aliases in the N-panel even though their files contained proper names.
    try:
        tree = ast.parse(text)
        for node in tree.body:
            if not isinstance(node, ast.Assign):
                continue
            if not any(isinstance(target, ast.Name) and target.id == 'bl_info' for target in node.targets):
                continue
            try:
                info = ast.literal_eval(node.value)
            except Exception:
                info = None
            if isinstance(info, dict):
                return (str(info.get('name') or '').strip(), str(info.get('description') or '').strip())
    except Exception:
        pass

    name_match = re.search(r'["\']name["\']\s*:\s*["\']([^"\']+)["\']', text)
    desc_match = re.search(r'["\']description["\']\s*:\s*["\']([^"\']+)["\']', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _find_init_file(src_dir: Path) -> tuple[str, str, str, str]:
    init_files = list(src_dir.rglob('__init__.py'))
    if not init_files:
        return '', '', '', ''

    scored: list[tuple[tuple[int, int, int, str], Path]] = []
    for path in init_files:
        rel = path.relative_to(src_dir).as_posix()
        depth = len(path.relative_to(src_dir).parts)
        text = ''
        try:
            text = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            text = ''
        has_bl_info = 'bl_info' in text
        has_register = 'def register' in text
        score = (
            0 if has_bl_info else 1,
            0 if has_register else 1,
            depth,
            rel,
        )
        scored.append((score, path))
    scored.sort(key=lambda item: item[0])
    chosen = scored[0][1]
    init_relpath = chosen.relative_to(src_dir).as_posix()
    parts = init_relpath.split('/')
    if len(parts) == 1:
        source_root = ''
        original_module_name = ''
        import_mode = 'root_package'
    else:
        source_root = '/'.join(parts[:-1])
        original_module_name = parts[0]
        import_mode = 'package'
    return init_relpath, source_root, original_module_name, import_mode


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    report_specs = _parse_report()
    root = vendors_root()
    results: list[dict[str, Any]] = []
    if not root.exists():
        _CACHE = []
        return []

    ignored = NATIVE_TOOL_DIRS | REMOVED_TOOL_DIRS | NON_ADDON_DIRS

    for vendor_dir in sorted(root.iterdir(), key=lambda item: item.name.lower()):
        if not vendor_dir.is_dir():
            continue
        dir_name = vendor_dir.name
        dir_name_lower = dir_name.lower()
        if dir_name.startswith('__') or dir_name.startswith('.'):
            continue
        if dir_name in ignored or dir_name_lower in ignored:
            continue

        # A visible integrated tool must be importable as a Python package.
        # Resource/state folders do not have an __init__.py and caused entries
        # such as icon, settings, and user_data to appear in the Other category.
        init_relpath, source_root, original_module_name, import_mode = _find_init_file(vendor_dir)
        if not init_relpath:
            continue

        alias = dir_name
        spec = dict(report_specs.get(alias) or {
            'alias': alias,
            'source_alias': alias,
            'outer_zip': alias + '.zip',
            'display_name': alias,
            'suite': 'smart_modeling_suite',
            'suite_name': 'Smart Modeling',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
        })
        spec['alias'] = alias
        override_name = DISPLAY_NAME_OVERRIDES.get(alias)
        current_display = str(spec.get('display_name') or '').strip()
        if override_name and (not current_display or current_display == alias or current_display == spec.get('source_alias')):
            spec['display_name'] = override_name
        src_dir = vendor_dir
        spec['src_dir'] = str(src_dir)
        spec['source_root'] = source_root
        spec['original_module_name'] = original_module_name
        spec['import_mode'] = import_mode
        spec['init_relpath'] = init_relpath
        spec['search_root'] = source_root
        spec['vendor_dir'] = str(vendor_dir)
        spec['suite_name'] = spec.get('suite_name') or SUITE_META.get(spec['suite'], ('Unknown', ''))[0]
        init_path = src_dir / init_relpath
        name, description = _read_bl_info_name_and_description(init_path)
        current_display = str(spec.get('display_name') or '').strip()
        if name and (not current_display or current_display == alias or current_display == spec.get('source_alias')):
            spec['display_name'] = name
        spec['description'] = description or str(spec.get('display_name') or alias)
        if not is_visible_addon_spec(spec):
            continue
        results.append(spec)

    # One visible N-panel entry per physical bundled tool.  Keep the first spec
    # for each alias and ignore accidental duplicate records from stale reports
    # or in-place extension updates.
    deduped: list[dict[str, Any]] = []
    seen_aliases: set[str] = set()
    for spec in results:
        alias = str(spec.get('alias') or '').strip()
        if not alias or alias in seen_aliases:
            continue
        seen_aliases.add(alias)
        deduped.append(spec)

    _CACHE = list(deduped)
    return list(deduped)
