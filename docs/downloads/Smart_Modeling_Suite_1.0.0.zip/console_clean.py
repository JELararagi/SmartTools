# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

# This module is intentionally defensive.  It removes stale SmartTools keymap
# artifacts left by older builds and wraps migrated N-panel draw functions so
# Blender never receives a non-None value from Panel.draw().

import sys
from typing import Iterable

import bpy

_INSTALLED = False
_LEGACY_OPERATOR_CLASSES: list[type] = []
_TIMER_TAGS: set[str] = set()

_STALE_EXTENSION_MODULES = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)

_LEGACY_NPANEL_OPERATOR_IDS = (
    'wm.bl_ext_npanel_popup_menu',
    'wm.bl_ext_npanel_operator_enum_popup',
    'wm.bl_ext_npanel_call_menu_pie',
)

_STALE_OPERATOR_PREFIXES = (
    'wm.smart_tools_',
    'wm.smart_tools_window',
    'wm.smart_tools_browser',
    'wm.bl_ext_npanel_',
)

_COMPAT_PROP_NAMES = (
    'action', 'mode_to', 'mode', 'cut', 'reduce_mode', 'operator', 'operator_id',
    'menu', 'menu_id', 'pie', 'name', 'data_path', 'value', 'text', 'icon', 'addon_key',
)


def _addon_id() -> str:
    pkg = str(__package__ or __name__ or '').strip('.')
    parts = [p for p in pkg.split('.') if p]
    if 'user_default' in parts:
        idx = parts.index('user_default')
        if idx + 1 < len(parts):
            return parts[idx + 1]
    for part in reversed(parts):
        if part.startswith('smart_') and part.endswith('_suite'):
            return part
    return parts[-1] if parts else 'smart_tools'


def _suite_operator_prefixes() -> tuple[str, ...]:
    addon = _addon_id()
    base = addon[:-6] if addon.endswith('_suite') else addon
    return tuple(dict.fromkeys((
        addon + '.',
        base + '.',
        'wm.' + addon,
        'wm.' + base,
        'wm.' + addon.replace('_suite', '') + '_suite_',
    )))


def _iter_keyconfigs():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    except Exception:
        keyconfigs = None
    if keyconfigs is None:
        return ()
    out = []
    for name in ('user', 'addon', 'active', 'default'):
        try:
            kc = getattr(keyconfigs, name, None)
        except Exception:
            kc = None
        if kc is not None:
            out.append((name, kc))
    return tuple(out)


def _keymap_item_count(km) -> int:
    try:
        return len(getattr(km, 'keymap_items', ()) or ())
    except Exception:
        count = 0
        try:
            for _ in getattr(km, 'keymap_items', ()):
                count += 1
        except Exception:
            pass
        return count


def _kmi_signature(kmi):
    try:
        return (
            str(getattr(kmi, 'idname', '') or ''),
            str(getattr(kmi, 'type', '') or ''),
            str(getattr(kmi, 'value', '') or ''),
            bool(getattr(kmi, 'any', False)),
            bool(getattr(kmi, 'shift', False)),
            bool(getattr(kmi, 'ctrl', False)),
            bool(getattr(kmi, 'alt', False)),
            bool(getattr(kmi, 'oskey', False)),
            str(getattr(kmi, 'key_modifier', '') or ''),
        )
    except Exception:
        return None


def _copy_keymap_item(dst_km, src_kmi):
    # Manual-keymap policy: Smart Modeling Suite must never create Preferences >
    # Keymap entries automatically.  Older builds used this helper while trying
    # to repair an empty User Interface keymap; keep the name only so old calls
    # fail safely without registering anything.
    return None

def _ensure_nonempty_user_interface_keymap() -> bool:
    # Never synthesize user keymaps.  This function is retained for startup
    # compatibility but now delegates only to the stale-empty cleanup below.
    return False


def _remove_empty_addon_user_interface_keymap() -> bool:
    changed = False
    for config_name, kc in _iter_keyconfigs():
        if config_name not in {'addon'}:
            continue
        try:
            maps = getattr(kc, 'keymaps', None)
            km = maps.get('User Interface') if maps is not None else None
        except Exception:
            km = None
        if km is not None and _keymap_item_count(km) <= 0:
            try:
                maps.remove(km)
                changed = True
            except Exception:
                pass
    return changed


def _kmi_should_remove(kmi, *, aggressive: bool = False) -> bool:
    try:
        idname = str(getattr(kmi, 'idname', '') or '')
    except Exception:
        idname = ''
    if not idname:
        return False
    if idname in _LEGACY_NPANEL_OPERATOR_IDS:
        return True
    if idname.startswith(_STALE_OPERATOR_PREFIXES):
        return True
    # Do not remove current Smart Modeling Suite operator IDs from the user's
    # keyconfig.  Manual bindings created by the user must remain persistent.
    return False


def _remove_stale_keymap_items() -> bool:
    changed = False
    for config_name, kc in _iter_keyconfigs():
        if config_name == 'user':
            # Preserve all user-created manual shortcuts.  The suite may clean
            # stale add-on keyconfig artifacts, but it must not edit Preferences
            # > Keymap entries owned by the user.
            continue
        aggressive = False
        try:
            maps = list(getattr(kc, 'keymaps', ()) or ())
        except Exception:
            maps = []
        for km in maps:
            try:
                items = list(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                items = []
            for kmi in items:
                if not _kmi_should_remove(kmi, aggressive=aggressive):
                    continue
                try:
                    km.keymap_items.remove(kmi)
                    changed = True
                except Exception:
                    try:
                        kmi.active = False
                        changed = True
                    except Exception:
                        pass
            try:
                if str(getattr(km, 'name', '') or '') == 'User Interface' and _keymap_item_count(km) <= 0 and config_name == 'addon':
                    kc.keymaps.remove(km)
                    changed = True
            except Exception:
                pass
    return changed


def _is_current_suite_module_name(name: str) -> bool:
    """Return True for every case variant of the package being imported.

    Windows resolves Extension directories case-insensitively.  Therefore the
    physical directory may be ``Smart_Modeling_Suite`` while Blender's manifest
    ID is ``smart_modeling_suite``.  Treating either spelling as stale removes the
    active parent package and makes ``from . import runtime`` recursively reload
    ``__init__.py`` until Python raises RecursionError.
    """
    candidate = str(name or '').strip().casefold()
    package = str(__package__ or '').strip().casefold()
    if not candidate or not package:
        return False
    package_leaf = package.rsplit('.', 1)[-1]
    candidate_leaf = candidate.rsplit('.', 1)[-1]
    return candidate == package or candidate_leaf == package_leaf


def _purge_stale_addon_entries() -> bool:
    changed = False
    try:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        addons = getattr(prefs, 'addons', None) if prefs is not None else None
    except Exception:
        addons = None

    current_package = str(__package__ or '').strip()
    current_module = sys.modules.get(current_package) if current_package else None

    if addons is not None:
        for name in _STALE_EXTENSION_MODULES:
            # Never remove the package that owns this cleanup module, including a
            # mixed-case spelling retained by an older manual installation.
            if _is_current_suite_module_name(name):
                continue
            loaded = sys.modules.get(name)
            if current_module is not None and loaded is current_module:
                continue
            entry = None
            try:
                entry = addons.get(name)
            except Exception:
                try:
                    entry = addons[name]
                except Exception:
                    entry = None
            if entry is not None:
                try:
                    addons.remove(entry)
                    changed = True
                except Exception:
                    pass
            try:
                loaded = sys.modules.get(name)
                if current_module is None or loaded is not current_module:
                    sys.modules.pop(name, None)
            except Exception:
                pass
    return changed


def clean_keymaps_and_preferences(*, save: bool = True) -> bool:
    changed = False
    for fn in (_purge_stale_addon_entries, _remove_empty_addon_user_interface_keymap, _remove_stale_keymap_items):
        try:
            if fn():
                changed = True
        except Exception:
            pass
    if changed and save:
        _schedule_userpref_save()
    return changed


def _schedule_userpref_save() -> None:
    # Do not save Blender preferences from automatic cleanup paths. Explicit
    # user action through the N-panel Save Preferences button performs the save.
    return None


def _operator_registered(op_id: str) -> bool:
    try:
        op_id = str(op_id or '').strip()
        base = getattr(bpy.types, 'Operator', None)
        getter = getattr(base, 'bl_rna_get_subclass_py', None) if base is not None else None
        if callable(getter) and getter(op_id, None):
            return True
        if '.' in op_id:
            namespace, opname = op_id.split('.', 1)
            op_ns = getattr(bpy.ops, namespace, None)
            if op_ns is not None:
                try:
                    if opname in dir(op_ns):
                        return True
                except Exception:
                    pass
                try:
                    return getattr(op_ns, opname, None) is not None
                except Exception:
                    return False
    except Exception:
        pass
    return False


def _make_legacy_operator_class(class_name: str, bl_idname: str):
    from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty

    def execute(self, context):
        return {'CANCELLED'}

    attrs = {
        '__module__': __name__,
        'bl_idname': bl_idname,
        'bl_label': 'SmartTools Legacy Compatibility',
        'bl_options': {'INTERNAL'},
        'execute': execute,
        'action': StringProperty(options={'SKIP_SAVE'}),
        'mode_to': StringProperty(options={'SKIP_SAVE'}),
        'mode': StringProperty(options={'SKIP_SAVE'}),
        'cut': BoolProperty(default=False, options={'SKIP_SAVE'}),
        'reduce_mode': StringProperty(options={'SKIP_SAVE'}),
        'operator': StringProperty(options={'SKIP_SAVE'}),
        'operator_id': StringProperty(options={'SKIP_SAVE'}),
        'menu': StringProperty(options={'SKIP_SAVE'}),
        'menu_id': StringProperty(options={'SKIP_SAVE'}),
        'pie': StringProperty(options={'SKIP_SAVE'}),
        'name': StringProperty(options={'SKIP_SAVE'}),
        'data_path': StringProperty(options={'SKIP_SAVE'}),
        'value': StringProperty(options={'SKIP_SAVE'}),
        'text': StringProperty(options={'SKIP_SAVE'}),
        'icon': StringProperty(options={'SKIP_SAVE'}),
        'addon_key': StringProperty(options={'SKIP_SAVE'}),
        'index': IntProperty(default=0, options={'SKIP_SAVE'}),
        'factor': FloatProperty(default=0.0, options={'SKIP_SAVE'}),
    }
    return type(class_name, (bpy.types.Operator,), attrs)


def register_legacy_operator_compatibility() -> None:
    # Do not register legacy wm.bl_ext_npanel_* compatibility operators during
    # install/reinstall.  Blender 5.1 logs show these duplicate RNA classes are
    # auto-unregistered/re-registered, which is a crash-prone path when panels are
    # visible.  Current Smart Modeling UI no longer calls these wrappers.
    return None


def _wrap_callable_returns_none(fn):
    if not callable(fn):
        return fn
    if getattr(fn, '_safe_panel_draw_returns_none', False):
        return fn
    def _wrapped(self, context):
        try:
            fn(self, context)
        except TypeError:
            try:
                fn(context)
            except TypeError:
                try:
                    fn(self)
                except Exception:
                    pass
            except Exception:
                pass
        except Exception:
            pass
        return None
    try:
        _wrapped.__name__ = getattr(fn, '__name__', '_wrapped_draw')
        _wrapped.__doc__ = getattr(fn, '__doc__', None)
        _wrapped._safe_panel_draw_returns_none = True
    except Exception:
        pass
    return _wrapped


def sanitize_panel_draws() -> int:
    """Standard N-panel build: do not mutate registered Panel.draw methods.

    Replacing draw/draw_header on already-registered RNA panel classes during
    or shortly before a region layout pass can destabilize Blender 5.1.  Kept
    as a compatibility no-op for callers from older Smart Modeling builds.
    """
    return 0


def _timer_install(tag: str, interval: float):
    # v1.2.20: do not register cleanup timers.  The immediate cleanup in
    # install() is sufficient and avoids stale timer callbacks accessing removed
    # RNA after an extension reinstall.
    _TIMER_TAGS.add(tag)
    return


def install() -> None:
    global _INSTALLED
    try:
        register_legacy_operator_compatibility()
    except Exception:
        pass
    try:
        clean_keymaps_and_preferences(save=True)
    except Exception:
        pass
    try:
        sanitize_panel_draws()
    except Exception:
        pass
    for tag, interval in (('early', 0.05), ('post_register', 0.35), ('late', 1.25), ('final', 3.0)):
        _timer_install(tag, interval)
    _INSTALLED = True


def uninstall() -> None:
    # Keep shared legacy compatibility operators registered while Blender is
    # running.  Multiple SmartTools packages can depend on them, and leaving a
    # harmless cancelling operator is safer than unregistering underneath another
    # enabled suite.
    try:
        sanitize_panel_draws()
    except Exception:
        pass
