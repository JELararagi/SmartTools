def points_as_bmesh_cells(verts, points, points_scale=None, margin_bounds=0.05, margin_cell=0.0):
    """Intersect the padded box with the site's weighted-distance bisector halfspaces."""
    from itertools import product
    from math import sqrt
    from mathutils import Vector, geometry, kdtree

    if len(points) < 2 or not verts:
        return []
    weights = tuple(points_scale) if points_scale is not None else (1.0, 1.0, 1.0)
    metric = tuple(sqrt(weight) for weight in weights)
    low = Vector([min(vertex[k] for vertex in verts) - margin_bounds for k in range(3)])
    high = Vector([max(vertex[k] for vertex in verts) + margin_bounds for k in range(3)])
    scaled = [tuple(point[k] * metric[k] for k in range(3)) for point in points]
    tree = kdtree.KDTree(len(points))
    for index, coordinate in enumerate(scaled):
        tree.insert(coordinate, index)
    tree.balance()
    cells = []
    for index, site in enumerate(points):
        bounds = [(low[k] - site[k], high[k] - site[k]) for k in range(3)]
        corners = [Vector(co) for co in product(*(pair[::-1] for pair in bounds))]
        planes = []
        for axis, (minimum, maximum) in enumerate(bounds):
            for sign, distance in ((1.0, -maximum), (-1.0, minimum)):
                plane = [0.0, 0.0, 0.0, distance]
                plane[axis] = sign
                planes.append(plane)
        visited = {index}
        count = min(16, len(points))
        radius = max(sqrt(sum(weights[k] * p[k] ** 2 for k in range(3))) for p in corners)
        done = False
        while not done:
            neighbors = sorted(tree.find_n(scaled[index], count), key=lambda item: (item[2], item[1]))
            for _, neighbor, distance in neighbors:
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                # The Cauchy-Schwarz bound excludes every farther site as well.
                if distance > 2 * (radius + max(metric) * max(margin_cell, 0.0)) * (1.0 + 1.e-6):
                    done = True
                    break
                separation = Vector(points[neighbor]) - Vector(site)
                normal = Vector([weights[k] * separation[k] for k in range(3)])
                if normal.length_squared == 0.0:
                    continue
                normal.normalize()
                limit = 0.5 * normal.dot(separation) - margin_cell
                if all(normal.dot(p) < limit - 1.e-6 for p in corners):
                    continue
                planes.append([*normal, -limit])
                corners, active = geometry.points_in_planes(planes)
                if not corners:
                    done = True
                    break
                planes = [planes[j] for j in active]
                radius = max(sqrt(sum(weights[k] * p[k] ** 2 for k in range(3))) for p in corners)
            if count == len(points):
                break
            count = min(2 * count, len(points))
        if corners:
            cells.append((site, corners))
    return cells
