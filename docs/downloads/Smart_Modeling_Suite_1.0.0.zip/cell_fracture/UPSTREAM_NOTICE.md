# Cell Fracture Source Evidence

Compared upstream author field: ideasman42, phymec, Sergey Sharybin
Comparison commit: b42d68627734cb18af0e6f41537063984313a284
Comparison-source version: 0.2

## cell_fracture/__init__.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/object_fracture_cell/__init__.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2010-2022 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 6.

## cell_fracture/fracture_cell_calc.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/object_fracture_cell/fracture_cell_calc.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2012 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 1.

## cell_fracture/fracture_cell_setup.py

Source: https://raw.githubusercontent.com/blender/blender-addons/b42d68627734cb18af0e6f41537063984313a284/object_fracture_cell/fracture_cell_setup.py

The compared upstream source carries these declarations:

```text
# SPDX-FileCopyrightText: 2012 Blender Foundation
#
# SPDX-License-Identifier: GPL-2.0-or-later
```

Exactly matching nontrivial function ASTs: 5.

The bounded comparison with SmartModeling 1.3.106 found 12 exact function AST matches across these three files, including identifiers and docstrings, excluding source positions, and requiring at least 30 AST nodes. No complete file was byte-identical or identical after line-ending normalization.

The original acquired archive/version and the origin of all other code have not been established. The comparison-source version is not a verified bundled-version claim. This notice preserves observed upstream declarations; it does not replace full license terms, change existing code or headers, or establish complete attribution, license/source-offer compliance or sales clearance.
