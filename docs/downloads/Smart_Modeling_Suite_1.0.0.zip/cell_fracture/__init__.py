import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
)

from bpy.types import Operator


def main_object(context, collection, obj, level, **kw):
    import random
    from mathutils import Vector
    from . import fracture_cell_setup as cells

    pipeline = kw.copy()
    cleanup = {name: pipeline.pop(name) for name in (
        "use_recenter", "use_remove_original", "use_island_split", "use_debug_bool",
        "use_interior_vgroup", "use_sharp_edges", "use_sharp_edges_apply",
    )}
    repeat = {name: pipeline.pop("recursion" + name) for name in (
        "", "_source_limit", "_clamp", "_chance", "_chance_select",
    )}
    if level:
        pipeline["source_limit"] = repeat["_source_limit"]

    def choose_shards(shards):
        indices = list(range(len(shards)))
        fraction = repeat["_chance"]
        if fraction == 1.0:
            return reversed(indices)
        mode = repeat["_chance_select"]
        if mode == "RANDOM":
            random.shuffle(indices)
        elif mode.startswith("SIZE_"):
            def diagonal(index):
                bounds = shards[index].bound_box
                return (Vector(bounds[0]) - Vector(bounds[6])).length_squared
            indices.sort(key=diagonal)
        elif mode.startswith("CURSOR_"):
            cursor = context.scene.cursor.location.copy()
            indices.sort(key=lambda index: (shards[index].location - cursor).length_squared)
        if mode.endswith("_MAX"):
            indices.reverse()
        count = int(fraction * len(indices))
        return sorted(indices[:count], reverse=True)

    def subdivide(shards, depth):
        additions = []
        for index in choose_shards(shards):
            parent = shards[index]
            additions.extend(main_object(context, collection, parent, depth, **kw))
            if cleanup["use_remove_original"]:
                collection.objects.unlink(parent)
                del shards[index]
            if repeat["_clamp"] and len(shards) + len(additions) >= repeat["_clamp"]:
                break
        shards.extend(additions)

    redraw = pipeline["use_debug_redraw"]
    previous_display = obj.display_type
    obj.select_set(False)
    if redraw:
        obj.display_type = 'WIRE'
    try:
        cutters = cells.cell_fracture_objects(context, collection, obj, **pipeline)
        mark_interior = cleanup["use_interior_vgroup"] or cleanup["use_sharp_edges"]
        shards = cells.cell_fracture_boolean(
            context, collection, obj, cutters, use_island_split=cleanup["use_island_split"],
            use_interior_hide=mark_interior, use_debug_bool=cleanup["use_debug_bool"],
            use_debug_redraw=redraw, level=level,
        )
        if cleanup["use_recenter"]:
            with context.temp_override(selected_editable_objects=shards):
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        if not level:
            for depth in range(1, repeat[""] + 1):
                subdivide(shards, depth)
                if repeat["_clamp"] and len(shards) > repeat["_clamp"]:
                    break
            if mark_interior:
                cells.cell_fracture_interior_handle(
                    shards, **{name: cleanup[name] for name in (
                        "use_interior_vgroup", "use_sharp_edges", "use_sharp_edges_apply",
                    )}
                )
        return shards
    finally:
        if redraw:
            obj.display_type = previous_display


def main(context, **kw):
    import time
    t = time.time()
    objects_context = context.selected_editable_objects

    kw_copy = kw.copy()

    # mass
    mass_mode = kw_copy.pop("mass_mode")
    mass = kw_copy.pop("mass")
    collection_name = kw_copy.pop("collection_name")

    collection = context.collection
    if collection_name:
        collection_current = collection
        collection = bpy.data.collections.get(collection_name)
        if collection is None:
            collection = bpy.data.collections.new(collection_name)
            collection_current.children.link(collection)
        del collection_current

    objects = []
    for obj in objects_context:
        if obj.type == 'MESH':
            objects += main_object(context, collection, obj, 0, **kw_copy)

    bpy.ops.object.select_all(action='DESELECT')
    for obj_cell in objects:
        obj_cell.select_set(True)

    # FIXME(campbell): we should be able to initialize rigid-body data.
    if mass_mode == 'UNIFORM':
        for obj_cell in objects:
            rb = obj_cell.rigid_body
            if rb is not None:
                rb.mass = mass
    elif mass_mode == 'VOLUME':
        from mathutils import Vector

        def _get_volume(obj_cell):
            """Measure a closed shard's volume in world space without editing the source mesh."""
            import bmesh

            shell = bmesh.new()
            try:
                shell.from_mesh(obj_cell.data)
                local_volume = shell.calc_volume(signed=False)
                return local_volume * abs(obj_cell.matrix_world.to_3x3().determinant())
            finally:
                shell.free()

        obj_volume_ls = [_get_volume(obj_cell) for obj_cell in objects]
        obj_volume_tot = sum(obj_volume_ls)
        if obj_volume_tot > 0.0:
            mass_fac = mass / obj_volume_tot
            for i, obj_cell in enumerate(objects):
                rb = obj_cell.rigid_body
                if rb is not None:
                    rb.mass = obj_volume_ls[i] * mass_fac
    else:
        assert(0)

    print("Done! %d objects in %.4f sec" % (len(objects), time.time() - t))


class FractureCell(Operator):
    bl_idname = "object.add_fracture_cell_objects"
    bl_label = "Cell fracture selected mesh objects"
    bl_options = {'PRESET', 'UNDO'}

    # -------------------------------------------------------------------------
    # Source Options
    source: EnumProperty(
        name="Source",
        items=(
            ('VERT_OWN', "Own Verts", "Use own vertices"),
            ('VERT_CHILD', "Child Verts", "Use child object vertices"),
            ('PARTICLE_OWN', "Own Particles", (
                "All particle systems of the "
                "source object"
            )),
            ('PARTICLE_CHILD', "Child Particles", (
                "All particle systems of the "
                "child objects"
            )),
            ('PENCIL', "Annotation Pencil", "Annotation Grease Pencil."),
        ),
        options={'ENUM_FLAG'},
        default={'PARTICLE_OWN'},
    )

    source_limit: IntProperty(
        name="Source Limit",
        description="Limit the number of input points, 0 for unlimited",
        min=0, max=5000,
        default=100,
    )

    source_noise: FloatProperty(
        name="Noise",
        description="Randomize point distribution",
        min=0.0, max=1.0,
        default=0.0,
    )

    cell_scale: FloatVectorProperty(
        name="Scale",
        description="Scale Cell Shape",
        size=3,
        min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0),
    )

    # -------------------------------------------------------------------------
    # Recursion

    recursion: IntProperty(
        name="Recursion",
        description="Break shards recursively",
        min=0, max=5000,
        default=0,
    )

    recursion_source_limit: IntProperty(
        name="Source Limit",
        description="Limit the number of input points, 0 for unlimited (applies to recursion only)",
        min=0, max=5000,
        default=8,
    )

    recursion_clamp: IntProperty(
        name="Clamp Recursion",
        description=(
            "Finish recursion when this number of objects is reached "
            "(prevents recursing for extended periods of time), zero disables"
        ),
        min=0, max=10000,
        default=250,
    )

    recursion_chance: FloatProperty(
        name="Random Factor",
        description="Likelihood of recursion",
        min=0.0, max=1.0,
        default=0.25,
    )

    recursion_chance_select: EnumProperty(
        name="Recurse Over",
        items=(
            ('RANDOM', "Random", ""),
            ('SIZE_MIN', "Small", "Recursively subdivide smaller objects"),
            ('SIZE_MAX', "Big", "Recursively subdivide bigger objects"),
            ('CURSOR_MIN', "Cursor Close", "Recursively subdivide objects closer to the cursor"),
            ('CURSOR_MAX', "Cursor Far", "Recursively subdivide objects farther from the cursor"),
        ),
        default='SIZE_MIN',
    )

    # -------------------------------------------------------------------------
    # Mesh Data Options

    use_smooth_faces: BoolProperty(
        name="Smooth Interior",
        description="Smooth Faces of inner side",
        default=False,
    )

    use_sharp_edges: BoolProperty(
        name="Sharp Edges",
        description="Set sharp edges when disabled",
        default=True,
    )

    use_sharp_edges_apply: BoolProperty(
        name="Apply Split Edge",
        description="Split sharp hard edges",
        default=True,
    )

    use_data_match: BoolProperty(
        name="Match Data",
        description="Match original mesh materials and data layers",
        default=True,
    )

    use_island_split: BoolProperty(
        name="Split Islands",
        description="Split disconnected meshes",
        default=True,
    )

    margin: FloatProperty(
        name="Margin",
        description="Gaps for the fracture (gives more stable physics)",
        min=0.0, max=1.0,
        default=0.001,
    )

    material_index: IntProperty(
        name="Material",
        description="Material index for interior faces",
        default=0,
    )

    use_interior_vgroup: BoolProperty(
        name="Interior VGroup",
        description="Create a vertex group for interior verts",
        default=False,
    )

    # -------------------------------------------------------------------------
    # Physics Options

    mass_mode: EnumProperty(
        name="Mass Mode",
        items=(
            ('VOLUME', "Volume", "Objects get part of specified mass based on their volume"),
            ('UNIFORM', "Uniform", "All objects get the specified mass"),
        ),
        default='VOLUME',
    )

    mass: FloatProperty(
        name="Mass",
        description="Mass to give created objects",
        min=0.001, max=1000.0,
        default=1.0,
    )

    # -------------------------------------------------------------------------
    # Object Options

    use_recenter: BoolProperty(
        name="Recenter",
        description="Recalculate the center points after splitting",
        default=True,
    )

    use_remove_original: BoolProperty(
        name="Remove Original",
        description="Removes the parents used to create the shatter",
        default=True,
    )

    # -------------------------------------------------------------------------
    # Scene Options
    #
    # .. different from object options in that this controls how the objects
    #    are setup in the scene.

    collection_name: StringProperty(
        name="Collection",
        description=(
            "Create objects in a collection "
            "(use existing or create new)"
        ),
    )

    # -------------------------------------------------------------------------
    # Debug
    use_debug_points: BoolProperty(
        name="Debug Points",
        description="Create mesh data showing the points used for fracture",
        default=False,
    )

    use_debug_redraw: BoolProperty(
        name="Show Progress Realtime",
        description="Redraw as fracture is done",
        default=True,
    )

    use_debug_bool: BoolProperty(
        name="Debug Boolean",
        description="Skip applying the boolean modifier",
        default=False,
    )

    def execute(self, context):
        keywords = self.as_keywords()  # ignore=("blah",)

        main(context, **keywords)

        return {'FINISHED'}

    def invoke(self, context, event):
        # print(self.recursion_chance_select)
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=760)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column()
        col.label(text="Point Source")
        rowsub = col.row()
        rowsub.prop(self, "source")
        rowsub = col.row()
        rowsub.prop(self, "source_limit")
        rowsub.prop(self, "source_noise")
        rowsub = col.row()
        rowsub.prop(self, "cell_scale")

        box = layout.box()
        col = box.column()
        col.label(text="Recursive Shatter")
        rowsub = col.row(align=True)
        rowsub.prop(self, "recursion")
        rowsub.prop(self, "recursion_source_limit")
        rowsub.prop(self, "recursion_clamp")
        rowsub = col.row()
        rowsub.prop(self, "recursion_chance")
        rowsub = col.row()
        rowsub.prop(self, "recursion_chance_select", expand=True)

        box = layout.box()
        col = box.column()
        col.label(text="Mesh Data")
        rowsub = col.row()
        rowsub.prop(self, "use_smooth_faces")
        rowsub.prop(self, "use_sharp_edges")
        rowsub.prop(self, "use_sharp_edges_apply")
        rowsub.prop(self, "use_data_match")
        rowsub = col.row()

        # on same row for even layout but in fact are not all that related
        rowsub.prop(self, "material_index")
        rowsub.prop(self, "use_interior_vgroup")

        # could be own section, control how we subdiv
        rowsub.prop(self, "margin")
        rowsub.prop(self, "use_island_split")

        box = layout.box()
        col = box.column()
        col.label(text="Physics")
        rowsub = col.row(align=True)
        rowsub.prop(self, "mass_mode")
        rowsub.prop(self, "mass")

        box = layout.box()
        col = box.column()
        col.label(text="Object")
        rowsub = col.row(align=True)
        rowsub.prop(self, "use_recenter")

        box = layout.box()
        col = box.column()
        col.label(text="Scene")
        rowsub = col.row(align=True)
        rowsub.prop(self, "collection_name")

        box = layout.box()
        col = box.column()
        col.label(text="Debug")
        rowsub = col.row(align=True)
        rowsub.prop(self, "use_debug_redraw")
        rowsub.prop(self, "use_debug_points")
        rowsub.prop(self, "use_debug_bool")


def menu_func(self, context):
    layout = self.layout
    layout.separator()
    layout.operator("object.add_fracture_cell_objects", text="Cell Fracture")


def register():
    bpy.utils.register_class(FractureCell)
    bpy.types.VIEW3D_MT_object_quick_effects.append(menu_func)


def unregister():
    bpy.utils.unregister_class(FractureCell)
    bpy.types.VIEW3D_MT_object_quick_effects.remove(menu_func)


if __name__ == "__main__":
    register()
