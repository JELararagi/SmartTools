# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# Independent Torus Knot + operator preset.
# Preset: Braided Coil
import bpy
op = bpy.context.active_operator
if op is None:
    raise RuntimeError("Torus Knot +: apply this preset from the active operator")
op.absolute_location = False
op.adaptive_resolution = False
op.colorSet = '1'
op.edit_mode = True
op.flip_p = False
op.flip_q = False
op.geo_bDepth = 0.027523
op.geo_bRes = 2
op.geo_extrude = 0.0
op.geo_offset = 0.0
op.geo_surface = True
op.handleType = 'AUTO'
op.mode = 'MAJOR_MINOR'
op.multiple_links = True
op.options_plus = True
op.outputType = 'BEZIER'
op.random_colors = False
op.saturation = 0.76
op.segment_res = 12
op.torus_R = 1.14
op.torus_eR = 1.25
op.torus_h = 1.55
op.torus_iR = 0.75
op.torus_p = 6
op.torus_q = 4
op.torus_r = 0.4104
op.torus_rP = 0.44879895
op.torus_res = 500
op.torus_s = 1.0
op.torus_sP = 0.34906585
op.torus_u = 1
op.torus_v = 1
op.use_colors = True
