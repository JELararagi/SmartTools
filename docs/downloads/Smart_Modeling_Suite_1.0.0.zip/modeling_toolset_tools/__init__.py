# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

import math
import random
from pathlib import Path
from typing import Iterable

import bpy
import bmesh
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

try:
    from .. import language as _language
except Exception:  # pragma: no cover
    _language = None

try:
    from .. import icon_runtime as _sms_icon_runtime
except Exception:  # pragma: no cover
    _sms_icon_runtime = None


bl_info = {
    "name": "Modeling Toolkit",
    "author": "JELararagi",
    "version": (1, 1, 4),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Smart Modeling",
    "description": "Integrated Smart Modeling command layer for hard-surface, retopology, procedural, CAD-like, scatter, spline, and cleanup workflows.",
    "category": "Mesh",
}


def _pick(en: str, ja: str, context=None) -> str:
    if _language is not None:
        try:
            return _language.pick_text(en, ja, context=context)
        except Exception:
            pass
    try:
        lang = str(getattr(getattr(getattr(context or bpy.context, "preferences", None), "view", None), "language", "") or "")
        return ja if lang.startswith("ja") else en
    except Exception:
        return en


def _ui(text: str, context=None) -> str:
    if _language is not None:
        try:
            return _language.ui_text(text, context=context)
        except Exception:
            pass
    return str(text or "")


def _register_translation(en: str, ja: str) -> None:
    if not en or not ja or en == ja or _language is None:
        return
    try:
        _language.register_translation(en, ja)
    except Exception:
        pass


def _active_object(context):
    try:
        return context.view_layer.objects.active
    except Exception:
        return getattr(context, "active_object", None)


def _active_mesh(context):
    obj = _active_object(context)
    return obj if obj is not None and getattr(obj, "type", None) == "MESH" else None


def _selected_objects(context, types: set[str] | None = None) -> list[bpy.types.Object]:
    result = []
    try:
        objects = list(context.selected_objects or [])
    except Exception:
        objects = []
    for obj in objects:
        if obj is None:
            continue
        if types is not None and getattr(obj, "type", None) not in types:
            continue
        result.append(obj)
    return result


def _selected_meshes(context) -> list[bpy.types.Object]:
    return _selected_objects(context, {"MESH"})


def _ensure_object_mode(context) -> str:
    obj = _active_object(context)
    mode = getattr(obj, "mode", "OBJECT") if obj is not None else "OBJECT"
    if obj is not None and mode != "OBJECT":
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
    return mode


def _restore_mode(context, mode: str) -> None:
    obj = _active_object(context)
    if obj is None:
        return
    if mode and mode != "OBJECT":
        try:
            bpy.ops.object.mode_set(mode=mode)
        except Exception:
            pass


def _link_object(context, obj) -> None:
    coll = None
    try:
        coll = context.collection
    except Exception:
        coll = None
    if coll is None:
        try:
            coll = context.scene.collection
        except Exception:
            coll = None
    if coll is not None:
        try:
            coll.objects.link(obj)
            return
        except RuntimeError:
            return
        except Exception:
            pass
    try:
        bpy.context.scene.collection.objects.link(obj)
    except Exception:
        pass


def _set_active(context, obj) -> None:
    if obj is None:
        return
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        obj.select_set(True)
    except Exception:
        pass


def _selection_snapshot(context):
    try:
        selected = tuple(context.selected_objects or ())
    except Exception:
        selected = tuple()
    return _active_object(context), selected


def _restore_selection_snapshot(context, snapshot) -> None:
    active, selected = snapshot if snapshot else (None, tuple())
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        pass
    try:
        alive = set(getattr(bpy.data, "objects", ()))
    except Exception:
        alive = None
    for obj in selected:
        if obj is None or (alive is not None and obj not in alive):
            continue
        try:
            obj.select_set(True)
        except Exception:
            pass
    if active is not None and (alive is None or active in alive):
        _set_active(context, active)


def _select_only(context, obj) -> None:
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        pass
    _set_active(context, obj)


def _safe_modifier(obj, mod_type: str, name: str):
    if obj is None:
        return None
    try:
        return obj.modifiers.new(name=name, type=mod_type)
    except Exception:
        return None


def _apply_modifier(context, obj, mod) -> bool:
    if obj is None or mod is None:
        return False
    snapshot = _selection_snapshot(context)
    mode = _ensure_object_mode(context)
    _select_only(context, obj)
    try:
        bpy.ops.object.modifier_apply(modifier=mod.name)
        ok = True
    except Exception:
        ok = False
    _restore_selection_snapshot(context, snapshot)
    _restore_mode(context, mode)
    return ok


def _mesh_cleanup_object(obj, *, merge_distance=0.0001, dissolve_angle=0.01745, delete_loose=True, recalc=True) -> dict[str, int]:
    result = {"merged": 0, "deleted": 0, "dissolved": 0, "faces": 0}
    if obj is None or getattr(obj, "type", None) != "MESH" or getattr(obj, "data", None) is None:
        return result
    mesh = obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        if delete_loose:
            loose_edges = [e for e in bm.edges if not e.link_faces]
            loose_verts = [v for v in bm.verts if not v.link_edges and not v.link_faces]
            result["deleted"] = len(loose_edges) + len(loose_verts)
            if loose_edges:
                try:
                    bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")
                except Exception:
                    pass
            if loose_verts:
                try:
                    bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")
                except Exception:
                    pass
        if merge_distance and merge_distance > 0:
            before = len(bm.verts)
            try:
                bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=float(merge_distance))
                bm.verts.ensure_lookup_table()
                result["merged"] = max(0, before - len(bm.verts))
            except Exception:
                pass
        if dissolve_angle and dissolve_angle > 0:
            before_edges = len(bm.edges)
            try:
                bmesh.ops.dissolve_limit(
                    bm,
                    angle_limit=float(dissolve_angle),
                    verts=list(bm.verts),
                    edges=list(bm.edges),
                    delimit={"NORMAL"},
                )
                bm.edges.ensure_lookup_table()
                result["dissolved"] = max(0, before_edges - len(bm.edges))
            except Exception:
                pass
        if recalc and bm.faces:
            try:
                bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            except Exception:
                pass
        result["faces"] = len(bm.faces)
        bm.to_mesh(mesh)
        try:
            mesh.update()
        except Exception:
            pass
    finally:
        bm.free()
    return result


def _selected_edit_vertices(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    return bm, [v for v in bm.verts if v.select]


def _bbox_world(obj):
    try:
        return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    except Exception:
        loc = getattr(obj, "location", Vector((0, 0, 0)))
        return [Vector(loc)]


def _bbox_size(obj) -> Vector:
    pts = _bbox_world(obj)
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    zs = [p.z for p in pts]
    return Vector((max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)))


def _bbox_center(obj) -> Vector:
    pts = _bbox_world(obj)
    if not pts:
        return Vector((0, 0, 0))
    return sum(pts, Vector((0, 0, 0))) / len(pts)


def _evaluated_object(context, obj):
    if obj is None:
        return None
    try:
        depsgraph = context.evaluated_depsgraph_get() if context is not None else bpy.context.evaluated_depsgraph_get()
        return obj.evaluated_get(depsgraph)
    except Exception:
        return obj


def _closest_world_point(target, world_point: Vector, max_distance: float = 1.0e6, context=None):
    if target is None or getattr(target, "type", None) != "MESH":
        return None, None
    for obj in (_evaluated_object(context, target), target):
        if obj is None:
            continue
        try:
            inv = obj.matrix_world.inverted()
            local_point = inv @ world_point
            ok, loc, normal, _face = obj.closest_point_on_mesh(local_point, distance=float(max_distance))
            if ok:
                world_normal = obj.matrix_world.to_3x3() @ normal
                if world_normal.length > 1.0e-8:
                    world_normal.normalize()
                else:
                    world_normal = Vector((0.0, 0.0, 1.0))
                return obj.matrix_world @ loc, world_normal
        except Exception:
            pass
    return None, None


def _raycast_down(target, world_origin: Vector, distance: float, context=None):
    if target is None or getattr(target, "type", None) != "MESH":
        return None, None
    for obj in (_evaluated_object(context, target), target):
        if obj is None:
            continue
        try:
            inv = obj.matrix_world.inverted()
            origin_local = inv @ world_origin
            direction_local = (inv.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
            ok, loc, normal, _index = obj.ray_cast(origin_local, direction_local, distance=float(distance))
            if ok:
                world_normal = obj.matrix_world.to_3x3() @ normal
                if world_normal.length > 1.0e-8:
                    world_normal.normalize()
                else:
                    world_normal = Vector((0.0, 0.0, 1.0))
                return obj.matrix_world @ loc, world_normal
        except Exception:
            pass
    return None, None


def _make_mesh_object(context, name: str, verts: list[Vector | tuple], faces: list[tuple[int, ...]]):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata([tuple(v) for v in verts], [], [tuple(f) for f in faces])
    try:
        mesh.update()
    except Exception:
        pass
    obj = bpy.data.objects.new(name, mesh)
    _link_object(context, obj)
    return obj


def _append_box(verts: list[Vector], faces: list[tuple[int, ...]], center: Vector, size: Vector) -> None:
    sx, sy, sz = size.x * 0.5, size.y * 0.5, size.z * 0.5
    base = len(verts)
    x, y, z = center.x, center.y, center.z
    verts.extend([
        Vector((x - sx, y - sy, z - sz)), Vector((x + sx, y - sy, z - sz)),
        Vector((x + sx, y + sy, z - sz)), Vector((x - sx, y + sy, z - sz)),
        Vector((x - sx, y - sy, z + sz)), Vector((x + sx, y - sy, z + sz)),
        Vector((x + sx, y + sy, z + sz)), Vector((x - sx, y + sy, z + sz)),
    ])
    faces.extend([
        (base + 0, base + 1, base + 2, base + 3),
        (base + 4, base + 7, base + 6, base + 5),
        (base + 0, base + 4, base + 5, base + 1),
        (base + 1, base + 5, base + 6, base + 2),
        (base + 2, base + 6, base + 7, base + 3),
        (base + 3, base + 7, base + 4, base + 0),
    ])


def _bezier_point(p0: Vector, h0: Vector, h1: Vector, p1: Vector, t: float) -> Vector:
    u = 1.0 - float(t)
    return (p0 * (u ** 3)) + (h0 * (3.0 * u * u * t)) + (h1 * (3.0 * u * t * t)) + (p1 * (t ** 3))


def _curve_points_world(curve_obj, resolution: int = 32) -> list[Vector]:
    points: list[Vector] = []
    if curve_obj is None or getattr(curve_obj, "type", None) != "CURVE":
        return points
    data = curve_obj.data
    resolution = max(2, int(resolution or 32))
    for spline in getattr(data, "splines", []):
        local_points: list[Vector] = []
        if getattr(spline, "type", "") == "BEZIER":
            bpoints = list(getattr(spline, "bezier_points", []) or [])
            if len(bpoints) >= 2:
                cyclic = bool(getattr(spline, "use_cyclic_u", False))
                segment_count = len(bpoints) if cyclic else len(bpoints) - 1
                steps = max(2, resolution // max(1, segment_count))
                for i in range(segment_count):
                    a = bpoints[i]
                    b = bpoints[(i + 1) % len(bpoints)]
                    for step in range(steps):
                        if local_points and step == 0:
                            continue
                        t = step / float(steps)
                        local_points.append(_bezier_point(a.co, a.handle_right, b.handle_left, b.co, t))
                if not cyclic:
                    local_points.append(bpoints[-1].co.copy())
        else:
            for point in getattr(spline, "points", []) or []:
                try:
                    local_points.append(Vector((point.co.x, point.co.y, point.co.z)))
                except Exception:
                    pass
        if len(local_points) < 2:
            continue
        for point in local_points:
            points.append(curve_obj.matrix_world @ point)
    if len(points) > resolution and resolution > 2:
        step = max(1, len(points) // resolution)
        points = points[::step][:resolution]
    return points


def _sample_mesh_surface(obj, count: int, seed: int = 0, context=None):
    """Area-weighted sampling on the evaluated mesh when Blender provides it.

    This makes scatter placement follow visible modifier results instead of only
    the original mesh data, while falling back to raw mesh data when evaluation is
    unavailable or Blender is running in a restricted context.
    """
    random.seed(int(seed))
    samples = []
    if obj is None or getattr(obj, "type", None) != "MESH":
        return samples
    mesh = None
    owner = None
    matrix = getattr(obj, "matrix_world", Matrix.Identity(4)).copy()
    try:
        depsgraph = context.evaluated_depsgraph_get() if context is not None else bpy.context.evaluated_depsgraph_get()
        owner = obj.evaluated_get(depsgraph)
        matrix = owner.matrix_world.copy()
        try:
            mesh = owner.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
        except TypeError:
            mesh = owner.to_mesh()
    except Exception:
        mesh = getattr(obj, "data", None)
        owner = None
        matrix = getattr(obj, "matrix_world", Matrix.Identity(4)).copy()
    if mesh is None:
        return samples
    try:
        try:
            mesh.calc_loop_triangles()
        except Exception:
            pass
        triangles = list(getattr(mesh, "loop_triangles", []) or [])
        if not triangles:
            return samples
        verts = [matrix @ v.co for v in mesh.vertices]
        weighted = []
        total_area = 0.0
        for tri in triangles:
            ids = list(tri.vertices)
            if len(ids) < 3:
                continue
            a, b, c = verts[ids[0]], verts[ids[1]], verts[ids[2]]
            area = (b - a).cross(c - a).length * 0.5
            if area <= 1.0e-12:
                continue
            total_area += area
            weighted.append((total_area, a, b, c))
        if not weighted or total_area <= 0:
            return samples
        for _i in range(max(0, int(count))):
            pick = random.random() * total_area
            lo, hi = 0, len(weighted) - 1
            while lo < hi:
                mid = (lo + hi) // 2
                if weighted[mid][0] < pick:
                    lo = mid + 1
                else:
                    hi = mid
            _w, a, b, c = weighted[lo]
            r1 = math.sqrt(random.random())
            r2 = random.random()
            point = a * (1.0 - r1) + b * (r1 * (1.0 - r2)) + c * (r1 * r2)
            normal = (b - a).cross(c - a)
            if normal.length > 1.0e-8:
                normal.normalize()
            else:
                normal = Vector((0.0, 0.0, 1.0))
            samples.append((point, normal))
    finally:
        if owner is not None:
            try:
                owner.to_mesh_clear()
            except Exception:
                pass
    return samples


def _normal_to_matrix(normal: Vector) -> Matrix:
    n = normal.copy()
    if n.length < 1.0e-8:
        n = Vector((0.0, 0.0, 1.0))
    n.normalize()
    quat = n.to_track_quat("Z", "Y")
    return quat.to_matrix().to_4x4()


def _op_exists(idname: str) -> bool:
    try:
        category, name = str(idname).split(".", 1)
        return hasattr(getattr(bpy.ops, category), name)
    except Exception:
        return False


_ICON_ITEMS_CACHE: set[str] | None = None


def _valid_icon_items() -> set[str]:
    global _ICON_ITEMS_CACHE
    if _ICON_ITEMS_CACHE is not None:
        return _ICON_ITEMS_CACHE
    icons: set[str] = set()
    try:
        fn = bpy.types.UILayout.bl_rna.functions.get("label")
        icon_prop = fn.parameters.get("icon") if fn is not None else None
        if icon_prop is not None:
            icons = {item.identifier for item in icon_prop.enum_items}
    except Exception:
        icons = set()
    _ICON_ITEMS_CACHE = icons
    return icons


def _safe_icon(icon: str, fallback: str = "TOOL_SETTINGS") -> str:
    try:
        icon = str(icon or fallback)
        fallback = str(fallback or "NONE")
        icons = _valid_icon_items()
        if icons:
            if icon in icons:
                return icon
            if fallback in icons:
                return fallback
            return "NONE" if "NONE" in icons else fallback
        return icon
    except Exception:
        return fallback


_PREVIEW_COLLECTIONS: dict[str, object] = {}
_CUSTOM_ICON_KEYS = (
    "context_auto", "context_fill", "context_extrude", "context_inset", "context_bridge",
    "quad_auto", "quad_grid", "quad_tris", "loop_circle", "loop_relax", "loop_space", "align_line",
    "boolean_stack", "boolean_apply", "bevel_normal", "planar_clean", "solidify_plus", "kit_insert",
    "modifier_stack", "modifier_stack_hardsurface", "modifier_stack_detail",
    "cable_pipe", "rail_sweep", "rail_sweep_pipe", "rail_sweep_path", "bend", "project",
    "retopo_wrap", "retopo_voxel", "shrinkwrap_surface", "falloff",
    "surface_scatter", "floor_tiles", "brick_wall", "stairs", "facade_grid", "terrain",
    "slice_wire", "slice_wire_wire", "slice_wire_slices",
    "repair_audit", "cad_cleaner", "workplane", "workplane_cursor", "workplane_origin", "workplane_plane",
    "drop_snap", "drop_surface", "drop_floor", "snap_origin",
    "replace_randomize", "asset_replace", "randomize_transform", "magic_solo", "magic_reveal",
    "fallback",
)


def _icons_dir() -> Path:
    return Path(__file__).resolve().parents[1] / 'icons'


def _icons_dirs() -> tuple[Path, ...]:
    here = Path(__file__).resolve().parent
    candidates = (
        _icons_dir(),
        here / 'icons',
        Path(__file__).resolve().parents[1] / 'icons',
    )
    result: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        key = str(resolved)
        if key in seen:
            continue
        seen.add(key)
        result.append(resolved)
    return tuple(result)


def _preview_collection_has_icons(pcoll) -> bool:
    try:
        return bool(pcoll) and any(pcoll.get(key) is not None for key in _CUSTOM_ICON_KEYS)
    except Exception:
        return False


def _load_custom_icons(force: bool = False) -> None:
    if force:
        _release_custom_icons()
    current = _PREVIEW_COLLECTIONS.get("main")
    if _preview_collection_has_icons(current):
        return
    try:
        import bpy.utils.previews as previews
    except Exception:
        return
    bases = [path for path in _icons_dirs() if path.exists()]
    if not bases:
        _PREVIEW_COLLECTIONS.pop("main", None)
        return
    try:
        pcoll = previews.new()
    except Exception:
        return
    loaded = 0
    for key in _CUSTOM_ICON_KEYS:
        path = None
        if _sms_icon_runtime is not None:
            try:
                candidate = _sms_icon_runtime.resolve_icon_path(key)
                if candidate.is_file():
                    path = candidate
            except Exception:
                path = None
        if path is None:
            for base in bases:
                candidate = (base / f"{key}.png").resolve()
                if candidate.is_file():
                    path = candidate
                    break
        if path is None:
            continue
        try:
            pcoll.load(key, str(path), "IMAGE")
            loaded += 1
        except Exception:
            pass
    if loaded > 0:
        _PREVIEW_COLLECTIONS["main"] = pcoll
    else:
        try:
            previews.remove(pcoll)
        except Exception:
            pass
        _PREVIEW_COLLECTIONS.pop("main", None)


def _release_custom_icons() -> None:
    try:
        import bpy.utils.previews as previews
    except Exception:
        _PREVIEW_COLLECTIONS.clear()
        return
    for pcoll in list(_PREVIEW_COLLECTIONS.values()):
        try:
            previews.remove(pcoll)
        except Exception:
            pass
    _PREVIEW_COLLECTIONS.clear()


def _icon_value(key: str) -> int:
    key = str(key or "")
    try:
        pcoll = _PREVIEW_COLLECTIONS.get("main")
        if not _preview_collection_has_icons(pcoll):
            _load_custom_icons(force=True)
            pcoll = _PREVIEW_COLLECTIONS.get("main")
        if pcoll is not None:
            item = pcoll.get(key)
            if item is None and key != "fallback":
                _load_custom_icons(force=True)
                pcoll = _PREVIEW_COLLECTIONS.get("main")
                if pcoll is not None:
                    item = pcoll.get(key)
            if item is None and pcoll is not None:
                item = pcoll.get("fallback")
            if item is not None:
                return int(getattr(item, "icon_id", 0) or 0)
    except Exception:
        pass
    return 0


def _button_with_custom_icon(parent, operator_id: str, icon_key: str, label_en: str, label_ja: str, context, props: dict | None = None):
    # Icon-only operator button; keep normal emboss so Blender highlights the button on hover.
    cell = parent.column(align=True)
    icon_row = cell.row(align=True)
    icon_row.scale_y = 3.35
    icon_id = _icon_value(icon_key)
    if icon_id:
        op = icon_row.operator(operator_id, text="", icon_value=icon_id, emboss=True)
    else:
        op = icon_row.operator(operator_id, text="", icon=_safe_icon("TOOL_SETTINGS"), emboss=True)
    for name, value in (props or {}).items():
        try:
            setattr(op, name, value)
        except Exception:
            pass
    label_row = cell.row(align=True)
    label_row.scale_y = 0.72
    label_row.alignment = "CENTER"
    label_row.label(text=_pick(label_en, label_ja, context))
    return op


def _selection_status_text(context) -> str:
    try:
        selected = len(context.selected_objects or [])
    except Exception:
        selected = 0
    obj = _active_object(context)
    if obj is None:
        return _pick("No active object", "アクティブなし", context)
    mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    typ = str(getattr(obj, "type", "OBJECT") or "OBJECT")
    if mode == "EDIT" and typ == "MESH":
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            v = sum(1 for item in bm.verts if item.select)
            e = sum(1 for item in bm.edges if item.select)
            f = sum(1 for item in bm.faces if item.select)
            return _pick(f"Edit mesh: V{v} E{e} F{f}", f"編集メッシュ: 頂点{v} 辺{e} 面{f}", context)
        except Exception:
            return _pick("Edit mesh", "編集メッシュ", context)
    return _pick(f"{typ}: {selected} selected", f"{typ}: {selected}個選択", context)


def _call_op(idname: str, **kwargs) -> bool:
    try:
        category, name = str(idname).split(".", 1)
        op = getattr(getattr(bpy.ops, category), name)
        # An operator can return without raising and still do nothing: mesh.f2
        # only implements invoke(), so an EXEC call returns PASS_THROUGH.  Only
        # FINISHED counts, otherwise callers would skip their fallback operator.
        return "FINISHED" in op(**kwargs)
    except Exception:
        return False


def _merge_by_distance_edit(threshold: float = 0.0001) -> bool:
    threshold = float(max(0.0, threshold))
    # Blender 5.1 exposes the UI command "Merge by Distance" through the
    # legacy RNA identifier ``mesh.remove_doubles``.  The newer-looking
    # ``mesh.merge_by_distance`` identifier is not registered in the target
    # version and would silently turn this tool into a no-op fallback path.
    return _call_op("mesh.remove_doubles", threshold=threshold)


def _safe_report(operator, level: str, en: str, ja: str, context=None) -> None:
    try:
        operator.report({str(level or "INFO")}, _pick(en, ja, context))
    except Exception:
        pass


def _create_modifier_texture(name: str, texture_type: str = "VORONOI"):
    textures = getattr(getattr(bpy, "data", None), "textures", None)
    if textures is None:
        return None
    try:
        return textures.new(name, type=texture_type)
    except Exception:
        return None


def _evaluated_mesh_object_copy(context, obj, name_suffix: str = "Mesh"):
    if obj is None:
        return None
    if getattr(obj, "type", None) == "MESH":
        return obj
    try:
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = bpy.data.meshes.new_from_object(eval_obj, depsgraph=depsgraph)
        if mesh is None:
            return None
        mesh.update()
        cutter = bpy.data.objects.new(f"{obj.name} {name_suffix}", mesh)
        cutter.matrix_world = obj.matrix_world.copy()
        _link_object(context, cutter)
        return cutter
    except Exception:
        return None


def _circle_selected_vertices_fallback(obj, regular: bool = True) -> bool:
    try:
        bm, verts = _selected_edit_vertices(obj)
    except Exception:
        return False
    if len(verts) < 3:
        return False
    center = sum((v.co for v in verts), Vector((0, 0, 0))) / len(verts)
    normal = sum((v.normal for v in verts), Vector((0, 0, 0)))
    if normal.length < 1.0e-8:
        normal = Vector((0, 0, 1))
    normal.normalize()
    axis_x = normal.cross(Vector((0, 0, 1)))
    if axis_x.length < 1.0e-8:
        axis_x = normal.cross(Vector((0, 1, 0)))
    axis_x.normalize()
    axis_y = normal.cross(axis_x).normalized()
    coords = []
    for v in verts:
        rel = v.co - center
        x = rel.dot(axis_x)
        y = rel.dot(axis_y)
        coords.append((math.atan2(y, x), v, x, y))
    radius = sum(math.sqrt(x * x + y * y) for _a, _v, x, y in coords) / len(coords)
    if radius <= 1.0e-8:
        return False
    coords.sort(key=lambda item: item[0])
    if regular:
        base_angle = coords[0][0]
        for i, (_ang, v, _x, _y) in enumerate(coords):
            angle = base_angle + math.tau * i / len(coords)
            v.co = center + axis_x * (math.cos(angle) * radius) + axis_y * (math.sin(angle) * radius)
    else:
        for angle, v, _x, _y in coords:
            v.co = center + axis_x * (math.cos(angle) * radius) + axis_y * (math.sin(angle) * radius)
    bmesh.update_edit_mesh(obj.data)
    return True


def _space_selected_vertices_fallback(obj, iterations: int = 1) -> bool:
    try:
        bm, verts = _selected_edit_vertices(obj)
    except Exception:
        return False
    selected = set(verts)
    if len(selected) < 3:
        return False
    edges = [e for e in bm.edges if e.select and e.verts[0] in selected and e.verts[1] in selected]
    if not edges:
        return False
    adjacency = {v: [] for v in selected}
    for e in edges:
        a, b = e.verts
        adjacency[a].append(b)
        adjacency[b].append(a)
    endpoints = [v for v, links in adjacency.items() if len(links) == 1]
    start = endpoints[0] if endpoints else next(iter(selected))
    ordered = []
    prev = None
    cur = start
    for _ in range(len(selected) + 2):
        if cur in ordered:
            break
        ordered.append(cur)
        candidates = [n for n in adjacency.get(cur, []) if n != prev]
        if not candidates:
            break
        prev, cur = cur, candidates[0]
    if len(ordered) < 3:
        return False
    closed = bool(adjacency.get(ordered[-1]) and ordered[0] in adjacency.get(ordered[-1], [])) and not endpoints
    pts = [v.co.copy() for v in ordered]
    if closed:
        segment_lengths = [(pts[(i + 1) % len(pts)] - pts[i]).length for i in range(len(pts))]
        total = sum(segment_lengths)
        if total <= 1.0e-8:
            return False
        # Circle-like spacing on the current polygon perimeter.
        target_step = total / len(pts)
        accum = [0.0]
        for length in segment_lengths[:-1]:
            accum.append(accum[-1] + length)
        curve_pts = pts + [pts[0]]
        curve_dist = [0.0]
        for i in range(len(pts)):
            curve_dist.append(curve_dist[-1] + (curve_pts[i + 1] - curve_pts[i]).length)
        for i, v in enumerate(ordered):
            target = target_step * i
            j = 0
            while j < len(curve_dist) - 1 and curve_dist[j + 1] < target:
                j += 1
            span = max(1.0e-8, curve_dist[j + 1] - curve_dist[j])
            t = (target - curve_dist[j]) / span
            v.co = curve_pts[j].lerp(curve_pts[j + 1], t)
    else:
        total = sum((pts[i + 1] - pts[i]).length for i in range(len(pts) - 1))
        if total <= 1.0e-8:
            return False
        target_step = total / (len(pts) - 1)
        curve_dist = [0.0]
        for i in range(len(pts) - 1):
            curve_dist.append(curve_dist[-1] + (pts[i + 1] - pts[i]).length)
        for i, v in enumerate(ordered):
            target = target_step * i
            j = 0
            while j < len(curve_dist) - 1 and curve_dist[j + 1] < target:
                j += 1
            if j >= len(pts) - 1:
                v.co = pts[-1]
            else:
                span = max(1.0e-8, curve_dist[j + 1] - curve_dist[j])
                t = (target - curve_dist[j]) / span
                v.co = pts[j].lerp(pts[j + 1], t)
    bmesh.update_edit_mesh(obj.data)
    return True


class SMSUITE_OT_context_modeler(Operator):
    bl_idname = "smsuite.context_modeler"
    bl_label = 'Model by Context'
    bl_description = "Runs a ZModeler-style context action for the current selection: fills edges, extrudes faces with cleanup, bridges loops, or performs a safe inset depending on the selected component mode."
    bl_options = {"UNDO"}

    action: EnumProperty(
        name="Action",
        description="Choose the context modeling action. Auto mode tries to infer the safest operation from the active selection and falls back to face creation.",
        items=(
            ("AUTO", "Auto", "Infer the best action from the current selection and context."),
            ("FILL", "Fill", "Create faces from selected vertices or edges, similar to F2 and grid-fill workflows."),
            ("EXTRUDE", "Clean Extrude", "Extrude the selected region and immediately merge, recalculate normals, and remove tiny overlaps."),
            ("INSET", "Inset", "Inset selected faces and keep the result editable for panel-line or CAD-like blocking."),
            ("BRIDGE", "Bridge", "Bridge selected edge loops when two compatible boundaries are selected."),
        ),
        default="AUTO",
    )
    distance: FloatProperty(
        name="Distance",
        description="Extrusion distance used by Clean Extrude. Use a small value for panel lips and a larger value for block-out modeling.",
        default=0.1,
        min=-1000.0,
        max=1000.0,
    )
    inset_amount: FloatProperty(
        name="Inset Amount",
        description="Inset width used by the Inset action. This creates a local border suitable for panel lines, bevel preparation, and ZModeler-like edits.",
        default=0.03,
        min=0.0,
        max=1000.0,
    )

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None and getattr(obj, "mode", "OBJECT") == "EDIT"

    def execute(self, context):
        action = self.action
        if action == "AUTO":
            action = "FILL"
            try:
                obj = _active_mesh(context)
                bm = bmesh.from_edit_mesh(obj.data)
                selected_faces = [f for f in bm.faces if f.select]
                selected_edges = [e for e in bm.edges if e.select]
                if selected_faces:
                    action = "INSET"
                elif len(selected_edges) >= 6:
                    # If selected edges form two or more disconnected components,
                    # bridge is usually the higher-value contextual intent.
                    remaining = set(selected_edges)
                    components = 0
                    while remaining:
                        components += 1
                        stack = [remaining.pop()]
                        while stack:
                            edge = stack.pop()
                            linked = [e for v in edge.verts for e in v.link_edges if e in remaining]
                            for e in linked:
                                remaining.discard(e)
                                stack.append(e)
                    if components >= 2:
                        action = "BRIDGE"
            except Exception:
                action = "FILL"
        if action == "FILL":
            if not _call_op("mesh.f2"):
                if not _call_op("mesh.edge_face_add"):
                    _call_op("mesh.fill") or _call_op("mesh.fill_grid")
        elif action == "EXTRUDE":
            if not _call_op("mesh.extrude_region_move", TRANSFORM_OT_translate={"value": (0.0, 0.0, float(self.distance))}):
                _call_op("mesh.extrude_region_shrink_fatten", TRANSFORM_OT_shrink_fatten={"value": float(self.distance)})
            _merge_by_distance_edit(0.0001)
            _call_op("mesh.normals_make_consistent", inside=False)
        elif action == "INSET":
            if not _call_op("mesh.inset", thickness=float(self.inset_amount), depth=0.0):
                _safe_report(self, "WARNING", "Inset could not run in the current selection.", "現在の選択状態ではインセットを実行できません。", context)
                return {"CANCELLED"}
        elif action == "BRIDGE":
            if not (_call_op("mesh.looptools_bridge") or _call_op("mesh.bridge_edge_loops")):
                _safe_report(self, "WARNING", "Bridge could not run. Select two compatible edge loops.", "ブリッジを実行できません。互換性のある2つのエッジループを選択してください。", context)
                return {"CANCELLED"}
        return {"FINISHED"}


class SMSUITE_OT_loop_shape_suite(Operator):
    bl_idname = "smsuite.loop_shape_suite"
    bl_label = 'Shape Loops'
    bl_description = "Provides Loop Tools-style circle, relax, space, bridge, loft, and flatten actions with safe fallbacks for selected loops and strips."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Select the loop operation. Circle regularizes holes, Relax evens tension, Space equalizes vertex spacing, Bridge and Loft connect loops, and Flatten projects the selection to a plane.",
        items=(
            ("CIRCLE", "Circle", "Regularize the selected loop into a circular shape."),
            ("RELAX", "Relax", "Smooth selected vertices while preserving the overall shape."),
            ("SPACE", "Space", "Equalize spacing along selected loops."),
            ("BRIDGE", "Bridge", "Bridge two selected loops or boundary selections."),
            ("FLATTEN", "Flatten", "Flatten selected vertices to their average local Z plane."),
        ),
        default="RELAX",
    )
    iterations: IntProperty(
        name="Iterations",
        description="Number of smoothing or spacing passes used by modes that support iterative cleanup. Higher values are smoother but can soften details.",
        default=4,
        min=1,
        max=64,
    )

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None and getattr(obj, "mode", "OBJECT") == "EDIT"

    def execute(self, context):
        mode = self.mode
        if mode == "CIRCLE":
            ok = _call_op("mesh.looptools_circle", fit="best", flatten=True, regular=True)
            if not ok:
                ok = _circle_selected_vertices_fallback(_active_mesh(context), regular=True)
            if not ok:
                _call_op("mesh.vertices_smooth", repeat=1, factor=0.5)
        elif mode == "RELAX":
            ok = _call_op("mesh.looptools_relax", input="selected", interpolation="cubic", iterations=int(self.iterations), regular=True)
            if not ok:
                _call_op("mesh.vertices_smooth", repeat=int(self.iterations), factor=0.5)
        elif mode == "SPACE":
            if not _call_op("mesh.looptools_space", input="selected", interpolation="cubic"):
                if not _space_selected_vertices_fallback(_active_mesh(context), iterations=int(self.iterations)):
                    _call_op("mesh.vertices_smooth", repeat=max(1, int(self.iterations) // 2), factor=0.25)
        elif mode == "BRIDGE":
            if not (_call_op("mesh.looptools_bridge") or _call_op("mesh.bridge_edge_loops")):
                _safe_report(self, "WARNING", "Bridge could not run. Select compatible boundary loops.", "ブリッジを実行できません。互換性のある境界ループを選択してください。", context)
                return {"CANCELLED"}
        elif mode == "FLATTEN":
            if not _call_op("mesh.looptools_flatten", plane="best_fit", restriction="none"):
                obj = _active_mesh(context)
                bm, verts = _selected_edit_vertices(obj)
                if not verts:
                    return {"CANCELLED"}
                avg_z = sum(v.co.z for v in verts) / len(verts)
                for v in verts:
                    v.co.z = avg_z
                bmesh.update_edit_mesh(obj.data)
        return {"FINISHED"}


class SMSUITE_OT_boolean_fusion_stack(Operator):
    bl_idname = "smsuite.boolean_fusion_stack"
    bl_label = 'Create Boolean Fusion'
    bl_description = "Builds a non-destructive boolean stack on the active mesh from the other selected cutter objects, then optionally adds bevel and weighted-normal cleanup for Hard Ops, Boxcutter, Fluent, MeshFusion, and MOP-style workflows."
    bl_options = {"UNDO"}

    operation: EnumProperty(
        name="Operation",
        description="Boolean operation applied from each selected cutter to the active target. Difference cuts holes, Union fuses forms, and Intersect keeps only overlapping volume.",
        items=(
            ("DIFFERENCE", "Difference", "Subtract each cutter from the active object."),
            ("UNION", "Union", "Union each cutter with the active object."),
            ("INTERSECT", "Intersect", "Keep only the overlapping volume between target and cutters."),
        ),
        default="DIFFERENCE",
    )
    hide_cutters: BoolProperty(
        name="Hide Cutters",
        description="Hide cutter objects in the viewport after the boolean modifiers are created while keeping them available for later non-destructive editing.",
        default=True,
    )
    add_bevel: BoolProperty(
        name="Add Bevel",
        description="Add a small bevel modifier after the boolean stack to create cleaner hard-surface highlights and a MeshFusion-like softened intersection.",
        default=True,
    )
    bevel_width: FloatProperty(
        name="Bevel Width",
        description="Width of the bevel modifier added after the boolean stack. Keep this low for panel cuts and increase it for mechanical fillets.",
        default=0.025,
        min=0.0,
        max=1000.0,
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None and len(_selected_objects(context)) >= 2

    def execute(self, context):
        mode = _ensure_object_mode(context)
        target = _active_mesh(context)
        cutters = [obj for obj in _selected_objects(context, {"MESH", "CURVE", "FONT", "SURFACE"}) if obj != target]
        if target is None or not cutters:
            _safe_report(self, "WARNING", "Select an active mesh target and at least one cutter object.", "アクティブなメッシュ対象と、少なくとも1つのカッターを選択してください。", context)
            _restore_mode(context, mode)
            return {"CANCELLED"}
        created = 0
        for cutter in cutters:
            cutter_obj = _evaluated_mesh_object_copy(context, cutter, name_suffix="Boolean Cutter")
            if cutter_obj is None or getattr(cutter_obj, "type", None) != "MESH":
                continue
            mod = _safe_modifier(target, "BOOLEAN", f"SMToolset {self.operation.title()} {cutter_obj.name}")
            if mod is None:
                continue
            try:
                mod.operation = self.operation
            except Exception:
                pass
            try:
                mod.object = cutter_obj
            except Exception:
                pass
            try:
                mod.solver = "EXACT"
            except Exception:
                pass
            if self.hide_cutters:
                for item in {cutter, cutter_obj}:
                    try:
                        item.display_type = "WIRE"
                        item.hide_viewport = True
                        item.hide_render = True
                    except Exception:
                        pass
            created += 1
        if self.add_bevel and self.bevel_width > 0:
            bevel = _safe_modifier(target, "BEVEL", "SMToolset Boolean Bevel")
            if bevel is not None:
                try:
                    bevel.width = float(self.bevel_width)
                    bevel.segments = 2
                    bevel.affect = "EDGES"
                    bevel.harden_normals = True
                except Exception:
                    pass
            wn = _safe_modifier(target, "WEIGHTED_NORMAL", "SMToolset Boolean Weighted Normal")
            if wn is not None:
                try:
                    wn.keep_sharp = True
                except Exception:
                    pass
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Created {created} boolean modifiers.", f"{created}個のブーリアンモディファイアを作成しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_boolean_apply_clean(Operator):
    bl_idname = "smsuite.boolean_apply_clean"
    bl_label = 'Apply and Clean Boolean'
    bl_description = "Applies boolean modifiers on selected objects, then performs merge-by-distance, limited dissolve, normal recalculation, and optional weighted-normal restoration for clean game-ready or render-ready meshes."
    bl_options = {"UNDO"}

    apply_all_booleans: BoolProperty(
        name="Apply All Boolean Modifiers",
        description="Apply every Boolean modifier on each selected mesh before cleanup. Disable this when you only want to clean already-applied boolean results.",
        default=True,
    )
    merge_distance: FloatProperty(
        name="Merge Distance",
        description="Distance used to weld overlapping vertices after boolean application. Increase slightly when cutters leave doubled vertices.",
        default=0.0001,
        min=0.0,
        max=1.0,
    )
    add_weighted_normal: BoolProperty(
        name="Add Weighted Normal",
        description="Add a Weighted Normal modifier after cleanup to reduce shading artifacts on N-gon and boolean-heavy hard-surface meshes.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        snapshot = _selection_snapshot(context)
        mode = _ensure_object_mode(context)
        total_mods = 0
        total_objs = 0
        try:
            for obj in _selected_meshes(context):
                _set_active(context, obj)
                if self.apply_all_booleans:
                    for mod in list(obj.modifiers):
                        if getattr(mod, "type", "") == "BOOLEAN":
                            if _apply_modifier(context, obj, mod):
                                total_mods += 1
                _mesh_cleanup_object(obj, merge_distance=float(self.merge_distance), dissolve_angle=0.01745, delete_loose=True, recalc=True)
                if self.add_weighted_normal:
                    wn = _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Weighted Normal")
                    if wn is not None:
                        try:
                            wn.keep_sharp = True
                        except Exception:
                            pass
                total_objs += 1
        finally:
            _restore_selection_snapshot(context, snapshot)
            _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Cleaned {total_objs} objects and applied {total_mods} boolean modifiers.", f"{total_objs}個のオブジェクトを整理し、{total_mods}個のブーリアンを適用しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_bevel_normal_stack(Operator):
    bl_idname = "smsuite.bevel_normal_stack"
    bl_label = 'Create Bevel Normal Stack'
    bl_description = "Adds a hard-surface bevel and weighted-normal stack to selected objects, acting as a non-destructive Mesh Machine, ReBevel, and weighted normal cleanup alternative."
    bl_options = {"UNDO"}

    width: FloatProperty(
        name="Width",
        description="Bevel width applied to selected mesh objects. Use very small values for highlight bevels and larger values for visible mechanical fillets.",
        default=0.025,
        min=0.0,
        max=1000.0,
    )
    segments: IntProperty(
        name="Segments",
        description="Number of bevel segments. One segment creates chamfers, two or more create rounded fillets.",
        default=2,
        min=1,
        max=64,
    )
    apply_stack: BoolProperty(
        name="Apply Stack",
        description="Apply the bevel and weighted-normal modifiers immediately. Leave this disabled to keep the stack non-destructive.",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        for obj in _selected_meshes(context):
            bevel = _safe_modifier(obj, "BEVEL", "SMToolset Bevel")
            if bevel is not None:
                try:
                    bevel.width = float(self.width)
                    bevel.segments = int(self.segments)
                    bevel.harden_normals = True
                    bevel.affect = "EDGES"
                except Exception:
                    pass
            wn = _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Weighted Normal")
            if wn is not None:
                try:
                    wn.keep_sharp = True
                except Exception:
                    pass
            if self.apply_stack:
                _apply_modifier(context, obj, bevel)
                _apply_modifier(context, obj, wn)
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_unbevel_planar_clean(Operator):
    bl_idname = "smsuite.unbevel_planar_clean"
    bl_label = 'Clean Planar Bevels'
    bl_description = "Runs a conservative unbevel-like cleanup by limited-dissolving near-planar bevel support edges, welding tiny overlaps, and recalculating normals to reduce boolean and bevel artifacts."
    bl_options = {"UNDO"}

    angle_degrees: FloatProperty(
        name="Planar Angle",
        description="Maximum angle treated as planar during limited dissolve. Low values preserve bevels; higher values remove more support edges.",
        default=3.0,
        min=0.0,
        max=45.0,
    )
    merge_distance: FloatProperty(
        name="Merge Distance",
        description="Weld distance after dissolve. Use a tiny value to remove duplicate boolean vertices without collapsing intended detail.",
        default=0.0001,
        min=0.0,
        max=1.0,
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        obj = _active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        if getattr(obj, "mode", "OBJECT") == "EDIT":
            _call_op("mesh.dissolve_limited", angle_limit=math.radians(float(self.angle_degrees)))
            _merge_by_distance_edit(float(self.merge_distance))
            _call_op("mesh.normals_make_consistent", inside=False)
        else:
            mode = _ensure_object_mode(context)
            for item in _selected_meshes(context):
                _mesh_cleanup_object(item, merge_distance=float(self.merge_distance), dissolve_angle=math.radians(float(self.angle_degrees)), delete_loose=False, recalc=True)
            _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_cable_pipe_from_selection(Operator):
    bl_idname = "smsuite.cable_pipe_from_selection"
    bl_label = 'Create Cable Pipe'
    bl_description = "Creates Cablerator, Sweep Mesh, ReeperX, Topowire, and ElboPipe-style cables or pipes from selected curves or mesh edges, with bevel depth and resolution applied automatically."
    bl_options = {"UNDO"}

    radius: FloatProperty(
        name="Radius",
        description="Cable or pipe radius assigned to generated curves. Increase for pipes and decrease for thin wires.",
        default=0.025,
        min=0.0001,
        max=1000.0,
    )
    resolution: IntProperty(
        name="Resolution",
        description="Curve bevel resolution used for rounded cable cross sections. Higher values are smoother but heavier.",
        default=4,
        min=0,
        max=32,
    )
    convert_mesh_edges: BoolProperty(
        name="Convert Selected Mesh Edges",
        description="When running in Edit Mode on a mesh, convert selected edges into separate pipe curves before applying bevel settings.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_objects(context, {"CURVE", "MESH"}))

    def execute(self, context):
        obj = _active_object(context)
        created = 0
        if obj is not None and getattr(obj, "type", None) == "MESH" and getattr(obj, "mode", "OBJECT") == "EDIT" and self.convert_mesh_edges:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            mw = obj.matrix_world.copy()
            for edge in [e for e in bm.edges if e.select]:
                curve = bpy.data.curves.new("SMToolset Cable", "CURVE")
                curve.dimensions = "3D"
                curve.resolution_u = int(self.resolution)
                curve.bevel_depth = float(self.radius)
                curve.bevel_resolution = int(self.resolution)
                spline = curve.splines.new("POLY")
                spline.points.add(1)
                for i, vert in enumerate(edge.verts):
                    p = mw @ vert.co
                    spline.points[i].co = (p.x, p.y, p.z, 1.0)
                cable = bpy.data.objects.new("SMToolset Cable", curve)
                _link_object(context, cable)
                created += 1
            return {"FINISHED"} if created else {"CANCELLED"}
        mode = _ensure_object_mode(context)
        for curve_obj in _selected_objects(context, {"CURVE"}):
            try:
                curve_obj.data.dimensions = "3D"
                curve_obj.data.bevel_depth = float(self.radius)
                curve_obj.data.bevel_resolution = int(self.resolution)
                curve_obj.data.resolution_u = max(1, int(self.resolution))
                created += 1
            except Exception:
                pass
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Updated or created {created} cable objects.", f"{created}個のケーブルオブジェクトを更新または作成しました。", context)
        return {"FINISHED"} if created else {"CANCELLED"}


class SMSUITE_OT_align_unbend(Operator):
    bl_idname = "smsuite.align_unbend"
    bl_label = 'Align and Unbend'
    bl_description = "Aligns selected vertices to a best-fit line or axis to emulate Align Edges, Unbend Mesh, Modo workplane cleanup, and precision CAD-like straightening workflows."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Line mode projects selected vertices to a best-fit line. Axis modes align to the average coordinate on the chosen local axis.",
        items=(
            ("LINE", "Best Fit Line", "Project selected vertices to the line between the farthest selected points."),
            ("X", "Local X", "Align selected vertices to their average local X coordinate."),
            ("Y", "Local Y", "Align selected vertices to their average local Y coordinate."),
            ("Z", "Local Z", "Align selected vertices to their average local Z coordinate."),
        ),
        default="LINE",
    )
    preserve_span: BoolProperty(
        name="Preserve Span",
        description="When using Best Fit Line, keep vertices distributed along the full selected span instead of collapsing them to the center.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None and getattr(obj, "mode", "OBJECT") == "EDIT"

    def execute(self, context):
        obj = _active_mesh(context)
        bm, verts = _selected_edit_vertices(obj)
        if len(verts) < 2:
            _safe_report(self, "WARNING", "Select at least two vertices.", "少なくとも2つの頂点を選択してください。", context)
            return {"CANCELLED"}
        if self.mode in {"X", "Y", "Z"}:
            idx = {"X": 0, "Y": 1, "Z": 2}[self.mode]
            avg = sum(v.co[idx] for v in verts) / len(verts)
            for v in verts:
                v.co[idx] = avg
        else:
            pts = [v.co.copy() for v in verts]
            a, b = pts[0], pts[-1]
            max_d = -1.0
            limit = min(len(pts), 256)
            sample = pts if len(pts) <= limit else pts[::max(1, len(pts) // limit)]
            for p in sample:
                for q in sample:
                    d = (p - q).length_squared
                    if d > max_d:
                        max_d = d
                        a, b = p.copy(), q.copy()
            direction = b - a
            if direction.length < 1.0e-8:
                return {"CANCELLED"}
            direction.normalize()
            for v in verts:
                if self.preserve_span:
                    t = (v.co - a).dot(direction)
                    v.co = a + direction * t
                else:
                    v.co = a
        bmesh.update_edit_mesh(obj.data)
        return {"FINISHED"}


class SMSUITE_OT_quad_rebuild(Operator):
    bl_idname = "smsuite.quad_rebuild"
    bl_label = 'Rebuild Quads'
    bl_description = "Rebuilds selected topology with quad-oriented fallbacks: F2 fill, grid fill, triangle-to-quad conversion, quad caps, Boolean Quad Ready-style preparation, and N-gon cleanup."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Choose a quad rebuild operation. Auto tries a safe sequence for missing faces and N-gon cleanup.",
        items=(
            ("AUTO", "Auto", "Run a safe sequence of fill, triangle-to-quad, and cleanup operations."),
            ("FILL", "Fill", "Fill selected boundary edges or vertices."),
            ("GRID", "Grid Fill", "Create an organized quad grid across selected boundary loops."),
            ("TRIS_TO_QUADS", "Tris to Quads", "Convert adjacent triangles into quads where possible."),
            ("POKE", "Poke", "Poke selected faces to create radial topology for controlled cleanup."),
        ),
        default="AUTO",
    )

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None and getattr(obj, "mode", "OBJECT") == "EDIT"

    def execute(self, context):
        if self.mode in {"AUTO", "FILL"}:
            _call_op("mesh.f2") or _call_op("mesh.edge_face_add") or _call_op("mesh.fill")
        if self.mode in {"AUTO", "GRID"}:
            _call_op("mesh.fill_grid")
        if self.mode in {"AUTO", "TRIS_TO_QUADS"}:
            _call_op("mesh.tris_convert_to_quads")
        if self.mode == "POKE":
            _call_op("mesh.poke")
        if self.mode == "AUTO":
            _call_op("mesh.normals_make_consistent", inside=False)
        return {"FINISHED"}


class SMSUITE_OT_mesh_repair_audit(Operator):
    bl_idname = "smsuite.mesh_repair_audit"
    bl_label = 'Audit and Repair Mesh'
    bl_description = "Audits and repairs selected meshes using 3D Print Toolbox, mesh repair, CAD cleanup, imported-DWG cleanup, Nsolve-style planar cleanup, and manifold-fix inspired operations."
    bl_options = {"UNDO"}

    fix_mesh: BoolProperty(
        name="Fix Mesh",
        description="When enabled, remove loose geometry, weld doubles, dissolve near-planar edges, and recalculate normals. When disabled, only reports basic mesh counts.",
        default=True,
    )
    merge_distance: FloatProperty(
        name="Merge Distance",
        description="Weld threshold for duplicate vertices. Use tiny values for scans and imported CAD meshes; increase carefully for messy data.",
        default=0.0001,
        min=0.0,
        max=1.0,
    )
    planar_angle: FloatProperty(
        name="Planar Angle",
        description="Limited dissolve angle in degrees for removing tiny planar support edges while preserving intentional corners.",
        default=1.0,
        min=0.0,
        max=45.0,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context) or _active_mesh(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        objects = _selected_meshes(context) or ([_active_mesh(context)] if _active_mesh(context) else [])
        repaired = 0
        report_edges = 0
        for obj in objects:
            if self.fix_mesh:
                _mesh_cleanup_object(obj, merge_distance=float(self.merge_distance), dissolve_angle=math.radians(float(self.planar_angle)), delete_loose=True, recalc=True)
                repaired += 1
            bm = None
            try:
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                report_edges += sum(1 for e in bm.edges if len(e.link_faces) != 2)
            except Exception:
                pass
            finally:
                if bm is not None:
                    try:
                        bm.free()
                    except Exception:
                        pass
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Objects: {len(objects)}, non-manifold boundary/irregular edges: {report_edges}, repaired: {repaired}.", f"オブジェクト数: {len(objects)}、非多様体境界/不規則辺: {report_edges}、修復数: {repaired}。", context)
        return {"FINISHED"}


class SMSUITE_OT_solidify_plus(Operator):
    bl_idname = "smsuite.solidify_plus"
    bl_label = 'Create Solidify Shell'
    bl_description = "Adds robust thickness with even offset, optional rim cleanup, bevel, and weighted normals as an upper-compatible Create Solidify Shell and hard-surface shelling helper."
    bl_options = {"UNDO"}

    thickness: FloatProperty(
        name="Thickness",
        description="Thickness added by the Solidify modifier. Positive values expand outward according to the selected offset setting.",
        default=0.05,
        min=-1000.0,
        max=1000.0,
    )
    offset: FloatProperty(
        name="Offset",
        description="Solidify offset. Use 1 for outward, 0 for centered, and -1 for inward thickness.",
        default=1.0,
        min=-1.0,
        max=1.0,
    )
    add_bevel: BoolProperty(
        name="Add Bevel and Normals",
        description="Add bevel and weighted-normal modifiers after Solidify to keep shell edges readable and shading stable.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        for obj in _selected_meshes(context):
            solid = _safe_modifier(obj, "SOLIDIFY", "SMToolset Create Solidify Shell")
            if solid is not None:
                try:
                    solid.thickness = float(self.thickness)
                    solid.offset = float(self.offset)
                    solid.use_quality_normals = True
                    solid.use_even_offset = True
                except Exception:
                    pass
            if self.add_bevel:
                bevel = _safe_modifier(obj, "BEVEL", "SMToolset Shell Bevel")
                if bevel is not None:
                    try:
                        bevel.width = abs(float(self.thickness)) * 0.08
                        bevel.segments = 1
                        bevel.harden_normals = True
                    except Exception:
                        pass
                _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Shell Weighted Normal")
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_bend_projection(Operator):
    bl_idname = "smsuite.bend_projection"
    bl_label = 'Bend and Project'
    bl_description = "Adds Simple Bend deformation or projects selected geometry to a target surface, covering Simple Bend, Projection Modeling, shrinkwrap, and surface-conform workflows."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Bend adds a non-destructive Simple Deform modifier. Project moves selected vertices or objects to the closest point on the active target surface.",
        items=(
            ("BEND", "Bend", "Add a Simple Deform Bend modifier to selected mesh objects."),
            ("PROJECT", "Project to Target", "Project selected object vertices to the active target mesh by closest point."),
        ),
        default="BEND",
    )
    angle: FloatProperty(
        name="Angle",
        description="Bend angle in degrees for the Simple Deform modifier.",
        default=90.0,
        min=-3600.0,
        max=3600.0,
    )
    max_distance: FloatProperty(
        name="Max Distance",
        description="Maximum projection distance for closest-point projection. Increase when source geometry is far away from the target surface.",
        default=100.0,
        min=0.0,
        max=100000.0,
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        if self.mode == "BEND":
            mode = _ensure_object_mode(context)
            for obj in _selected_meshes(context):
                mod = _safe_modifier(obj, "SIMPLE_DEFORM", "SMToolset Simple Bend")
                if mod is not None:
                    try:
                        mod.deform_method = "BEND"
                        mod.angle = math.radians(float(self.angle))
                    except Exception:
                        pass
            _restore_mode(context, mode)
            return {"FINISHED"}
        target = _active_mesh(context)
        sources = [obj for obj in _selected_meshes(context) if obj != target]
        if target is None or not sources:
            _safe_report(self, "WARNING", "Select source mesh objects and make the target surface active.", "ソースメッシュを選択し、対象サーフェスをアクティブにしてください。", context)
            return {"CANCELLED"}
        mode = _ensure_object_mode(context)
        for obj in sources:
            mesh = obj.data
            inv_src = obj.matrix_world.inverted()
            for vert in mesh.vertices:
                wp = obj.matrix_world @ vert.co
                hit, _normal = _closest_world_point(target, wp, max_distance=float(self.max_distance), context=context)
                if hit is not None:
                    vert.co = inv_src @ hit
            try:
                mesh.update()
            except Exception:
                pass
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_retopo_wrap_remesh(Operator):
    bl_idname = "smsuite.retopo_wrap_remesh"
    bl_label = 'Wrap and Remesh'
    bl_description = "Creates a Quad Remesher, QRemeshify, Retopoflow, Quad Draw, Topobuild, and shrinkwrap-inspired retopology pass using Blender-native remesh and shrinkwrap fallbacks."
    bl_options = {"UNDO"}

    method: EnumProperty(
        name="Method",
        description="Choose the remesh strategy. Quadriflow is used when available; Voxel Remesh is a broadly available fallback; Shrinkwrap Only keeps existing topology.",
        items=(
            ("QUADRIFLOW", "Quadriflow", "Run Blender Quadriflow remesh when the operator is available."),
            ("VOXEL", "Voxel", "Add or run voxel remeshing for even all-quad-like sculpt base topology."),
            ("SHRINKWRAP", "Shrinkwrap Only", "Add a shrinkwrap modifier to conform source topology to the active target."),
        ),
        default="VOXEL",
    )
    target_faces: IntProperty(
        name="Target Faces",
        description="Approximate target face count for Quadriflow remeshing. Ignored by methods that do not expose target face count.",
        default=5000,
        min=100,
        max=1000000,
    )
    voxel_size: FloatProperty(
        name="Voxel Size",
        description="Voxel size for voxel remesh fallback. Smaller values preserve more detail and create heavier meshes.",
        default=0.05,
        min=0.0001,
        max=1000.0,
    )
    add_shrinkwrap: BoolProperty(
        name="Add Shrinkwrap",
        description="Add a shrinkwrap modifier to the active target or to the second selected mesh after remeshing, useful for retopology projection.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None

    def execute(self, context):
        mode = _ensure_object_mode(context)
        obj = _active_mesh(context)
        targets = [o for o in _selected_meshes(context) if o != obj]
        if self.method == "QUADRIFLOW":
            try:
                bpy.ops.object.quadriflow_remesh(target_faces=int(self.target_faces))
            except Exception:
                _safe_report(self, "WARNING", "Quadriflow is unavailable in this context; adding voxel Remesh modifier instead.", "このコンテキストではQuadriflowを使用できないため、代わりにVoxel Remeshモディファイアを追加します。", context)
                self.method = "VOXEL"
        if self.method == "VOXEL":
            mod = _safe_modifier(obj, "REMESH", "SMToolset Voxel Remesh")
            if mod is not None:
                try:
                    mod.mode = "VOXEL"
                    mod.voxel_size = float(self.voxel_size)
                    mod.use_smooth_shade = True
                except Exception:
                    pass
        if self.add_shrinkwrap and targets:
            sw = _safe_modifier(obj, "SHRINKWRAP", "SMToolset Retopo Shrinkwrap")
            if sw is not None:
                try:
                    sw.target = targets[0]
                    sw.wrap_method = "NEAREST_SURFACEPOINT"
                except Exception:
                    pass
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_scatter_surface(Operator):
    bl_idname = "smsuite.scatter_surface"
    bl_label = 'Scatter on Surface'
    bl_description = "Scatters selected source objects across the active mesh surface with random scale, rotation, and normal alignment, covering Geo-Scatter, Forest Pack, MASH, spPaint3D, BagaPie scatter, and environment painting workflows."
    bl_options = {"UNDO"}

    count: IntProperty(
        name="Count",
        description="Number of scattered instances to create across the active target surface.",
        default=50,
        min=1,
        max=100000,
    )
    seed: IntProperty(
        name="Seed",
        description="Random seed for deterministic scatter placement. Change this value to generate a different distribution.",
        default=1,
        min=0,
        max=999999,
    )
    min_scale: FloatProperty(
        name="Minimum Scale",
        description="Minimum random scale multiplier applied to scattered instances.",
        default=0.7,
        min=0.0,
        max=1000.0,
    )
    max_scale: FloatProperty(
        name="Maximum Scale",
        description="Maximum random scale multiplier applied to scattered instances.",
        default=1.3,
        min=0.0,
        max=1000.0,
    )
    align_to_normal: BoolProperty(
        name="Align to Normal",
        description="Rotate each scattered instance so its local Z axis follows the sampled surface normal, useful for rocks, plants, bolts, and panel details.",
        default=True,
    )
    linked_data: BoolProperty(
        name="Linked Data",
        description="Use linked object data for lower memory usage. Disable this when each scattered object needs unique mesh edits later.",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None and len(_selected_objects(context)) >= 2

    def execute(self, context):
        mode = _ensure_object_mode(context)
        target = _active_mesh(context)
        sources = [o for o in _selected_objects(context) if o != target]
        if target is None or not sources:
            _safe_report(self, "WARNING", "Select scatter source objects and make the target mesh active.", "散布元オブジェクトを選択し、対象メッシュをアクティブにしてください。", context)
            _restore_mode(context, mode)
            return {"CANCELLED"}
        samples = _sample_mesh_surface(target, int(self.count), seed=int(self.seed), context=context)
        random.seed(int(self.seed) + 911)
        created = 0
        for point, normal in samples:
            src = random.choice(sources)
            obj = src.copy()
            if not self.linked_data and getattr(src, "data", None) is not None:
                try:
                    obj.data = src.data.copy()
                except Exception:
                    pass
            obj.location = point
            scale = random.uniform(float(self.min_scale), float(self.max_scale))
            obj.scale = tuple(scale * v for v in src.scale)
            if self.align_to_normal:
                try:
                    obj.matrix_world = Matrix.Translation(point) @ _normal_to_matrix(normal) @ Matrix.Diagonal((obj.scale.x, obj.scale.y, obj.scale.z, 1.0))
                except Exception:
                    pass
            else:
                try:
                    obj.rotation_euler.z += random.random() * math.tau
                except Exception:
                    pass
            _link_object(context, obj)
            created += 1
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Scattered {created} instances.", f"{created}個のインスタンスを散布しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_floor_wall_generator(Operator):
    bl_idname = "smsuite.floor_wall_generator"
    bl_label = 'Generate Floor and Wall'
    bl_description = "Generates FloorGenerator, BrickIt, RailClone facade, Archviz tile, stair, and wall blocking geometry as editable mesh pieces from procedural dimensions."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Choose the procedural asset to generate: floor tiles, brick wall, stairs, or facade strips.",
        items=(
            ("FLOOR", "Floor Tiles", "Generate individual floor or tile faces inside a rectangular area."),
            ("WALL", "Brick Wall", "Generate a brick wall from stacked box bricks with alternating offsets."),
            ("STAIRS", "Stairs", "Generate block-out stairs from repeated rectangular steps."),
            ("FACADE", "Facade Grid", "Generate a simple architectural facade grid for fast concept blocking."),
        ),
        default="FLOOR",
    )
    width: FloatProperty(name="Width", description="Overall generated width in Blender units.", default=4.0, min=0.001, max=100000.0)
    depth: FloatProperty(name="Depth", description="Overall generated depth or thickness depending on the selected generator mode.", default=4.0, min=0.001, max=100000.0)
    height: FloatProperty(name="Height", description="Overall generated height for walls, stairs, and facade grids.", default=2.5, min=0.001, max=100000.0)
    columns: IntProperty(name="Columns", description="Number of generated columns, tiles, bricks per row, or facade bays.", default=8, min=1, max=1000)
    rows: IntProperty(name="Rows", description="Number of generated rows, tile rows, brick courses, steps, or facade floors.", default=6, min=1, max=1000)
    gap: FloatProperty(name="Gap", description="Gap between tiles, bricks, or facade pieces. Use zero for continuous geometry.", default=0.02, min=0.0, max=1000.0)

    def execute(self, context):
        verts: list[Vector] = []
        faces: list[tuple[int, ...]] = []
        width = float(self.width)
        depth = float(self.depth)
        height = float(self.height)
        cols = max(1, int(self.columns))
        rows = max(1, int(self.rows))
        gap = max(0.0, float(self.gap))
        if self.mode == "FLOOR":
            sx = width / cols
            sy = depth / rows
            for y in range(rows):
                for x in range(cols):
                    cx = -width * 0.5 + sx * (x + 0.5)
                    cy = -depth * 0.5 + sy * (y + 0.5)
                    hw = max(0.0001, sx - gap) * 0.5
                    hd = max(0.0001, sy - gap) * 0.5
                    base = len(verts)
                    verts.extend([Vector((cx - hw, cy - hd, 0)), Vector((cx + hw, cy - hd, 0)), Vector((cx + hw, cy + hd, 0)), Vector((cx - hw, cy + hd, 0))])
                    faces.append((base, base + 1, base + 2, base + 3))
        elif self.mode == "WALL":
            sx = width / cols
            sz = height / rows
            for z in range(rows):
                offset = (sx * 0.5) if z % 2 else 0.0
                for x in range(cols):
                    cx = -width * 0.5 + sx * (x + 0.5) + offset
                    if cx > width * 0.5:
                        cx -= width
                    cz = sz * (z + 0.5)
                    _append_box(verts, faces, Vector((cx, 0.0, cz)), Vector((max(0.001, sx - gap), max(0.001, depth), max(0.001, sz - gap))))
        elif self.mode == "STAIRS":
            sx = width
            step_depth = depth / rows
            step_height = height / rows
            for i in range(rows):
                cy = -depth * 0.5 + step_depth * (i + 0.5)
                # Each step is a solid block from the floor, so its centre is half
                # of its own height; the top of the last step is the overall height.
                cz = step_height * (i + 1) * 0.5
                _append_box(verts, faces, Vector((0.0, cy, cz)), Vector((sx, max(0.001, step_depth - gap), max(0.001, step_height * (i + 1) - gap))))
        else:
            sx = width / cols
            sz = height / rows
            bar = max(0.01, min(sx, sz) * 0.08)
            for x in range(cols + 1):
                cx = -width * 0.5 + sx * x
                _append_box(verts, faces, Vector((cx, 0.0, height * 0.5)), Vector((bar, depth, height)))
            for z in range(rows + 1):
                cz = sz * z
                _append_box(verts, faces, Vector((0.0, 0.0, cz)), Vector((width, depth, bar)))
        obj = _make_mesh_object(context, f"SMToolset {self.mode.title()}", verts, faces)
        _set_active(context, obj)
        return {"FINISHED"}


class SMSUITE_OT_terrain_generator(Operator):
    bl_idname = "smsuite.terrain_generator"
    bl_label = 'Generate Terrain'
    bl_description = "Generates editable terrain meshes inspired by Terrain Generator, Houdini heightfields, Terrain Builder, rock generators, and procedural environment block-out tools."
    bl_options = {"UNDO"}

    size: FloatProperty(name="Size", description="Overall terrain width and depth in Blender units.", default=8.0, min=0.001, max=100000.0)
    subdivisions: IntProperty(name="Subdivisions", description="Grid subdivisions used to build the terrain. Higher values create smoother terrain but heavier meshes.", default=64, min=2, max=512)
    height: FloatProperty(name="Height", description="Maximum vertical displacement applied by the layered procedural noise.", default=1.0, min=0.0, max=100000.0)
    seed: IntProperty(name="Seed", description="Random seed used by the procedural terrain noise.", default=7, min=0, max=999999)
    roughness: FloatProperty(name="Roughness", description="Controls how much higher-frequency detail is added to the terrain. Higher values create rougher landscapes.", default=0.55, min=0.0, max=2.0)

    def execute(self, context):
        random.seed(int(self.seed))
        n = int(self.subdivisions)
        size = float(self.size)
        verts: list[Vector] = []
        faces: list[tuple[int, ...]] = []
        phases = [random.random() * math.tau for _ in range(6)]
        for y in range(n + 1):
            fy = y / n
            for x in range(n + 1):
                fx = x / n
                px = (fx - 0.5) * size
                py = (fy - 0.5) * size
                z = 0.0
                amp = 1.0
                freq = 1.0
                for i in range(4):
                    z += math.sin((px * freq + phases[i]) * 1.3) * math.cos((py * freq + phases[i + 1]) * 1.7) * amp
                    amp *= float(self.roughness)
                    freq *= 2.17
                z *= float(self.height) * 0.25
                verts.append(Vector((px, py, z)))
        for y in range(n):
            for x in range(n):
                a = y * (n + 1) + x
                faces.append((a, a + 1, a + n + 2, a + n + 1))
        obj = _make_mesh_object(context, "SMToolset Terrain", verts, faces)
        try:
            for p in obj.data.polygons:
                p.use_smooth = True
        except Exception:
            pass
        _set_active(context, obj)
        return {"FINISHED"}


class SMSUITE_OT_rail_sweep_generator(Operator):
    bl_idname = "smsuite.rail_sweep_generator"
    bl_label = 'Generate Rail Sweep'
    bl_description = "Creates RailClone, Sweep Mesh, Duplicate Along Path, spline extruder, and procedural pipe alternatives by sweeping curves or duplicating source objects along selected curves."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Curve Pipe sets bevel depth on selected curves. Duplicate Source places the selected source object along the active curve control points.",
        items=(
            ("PIPE", "Curve Pipe", "Turn selected curve paths into editable pipes or rails."),
            ("DUPLICATE", "Duplicate Source", "Duplicate a selected source object along the active curve points."),
        ),
        default="PIPE",
    )
    radius: FloatProperty(name="Radius", description="Pipe radius for Curve Pipe mode.", default=0.04, min=0.0001, max=10000.0)
    count: IntProperty(name="Count", description="Maximum number of duplicates sampled along curve points in Duplicate Source mode.", default=16, min=2, max=10000)

    @classmethod
    def poll(cls, context):
        return bool(_selected_objects(context, {"CURVE", "MESH"}))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        if self.mode == "PIPE":
            done = 0
            for curve in _selected_objects(context, {"CURVE"}):
                try:
                    curve.data.dimensions = "3D"
                    curve.data.bevel_depth = float(self.radius)
                    curve.data.bevel_resolution = 3
                    curve.data.resolution_u = 16
                    done += 1
                except Exception:
                    pass
            _restore_mode(context, mode)
            return {"FINISHED"} if done else {"CANCELLED"}
        curve = _active_object(context)
        if curve is None or getattr(curve, "type", None) != "CURVE":
            curves = _selected_objects(context, {"CURVE"})
            curve = curves[0] if curves else None
        sources = [o for o in _selected_objects(context) if o != curve and getattr(o, "type", None) != "CURVE"]
        if curve is None or not sources:
            _safe_report(self, "WARNING", "Select a source object and make a curve path active.", "ソースオブジェクトを選択し、カーブパスをアクティブにしてください。", context)
            _restore_mode(context, mode)
            return {"CANCELLED"}
        points = _curve_points_world(curve, resolution=int(self.count))
        if not points:
            _restore_mode(context, mode)
            return {"CANCELLED"}
        source = sources[0]
        for p in points[: int(self.count)]:
            inst = source.copy()
            inst.data = getattr(source, "data", None)
            inst.location = p
            _link_object(context, inst)
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_workplane_pivot_tools(Operator):
    bl_idname = "smsuite.workplane_pivot_tools"
    bl_label = 'Set Workplane and Pivot'
    bl_description = "Places the 3D cursor, origin, or helper workplane from the current selection, covering Modo Workplane, Action Centers, Pivot Tools, Drop to Floor setup, and CAD-like modeling plane workflows."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Cursor to Selection moves the 3D cursor. Origin to Cursor moves selected object origins. Workplane creates a helper plane at the cursor.",
        items=(
            ("CURSOR_TO_SELECTION", "Cursor to Selection", "Move the 3D cursor to the center of the selected elements or objects."),
            ("ORIGIN_TO_CURSOR", "Origin to Cursor", "Move selected object origins to the current 3D cursor."),
            ("CREATE_WORKPLANE", "Create Workplane", "Create a named helper plane at the cursor for visual modeling reference."),
        ),
        default="CURSOR_TO_SELECTION",
    )
    plane_size: FloatProperty(name="Plane Size", description="Size of the helper plane created by Create Workplane mode.", default=2.0, min=0.001, max=100000.0)

    def execute(self, context):
        mode = getattr(_active_object(context), "mode", "OBJECT") if _active_object(context) else "OBJECT"
        if self.mode == "CURSOR_TO_SELECTION":
            if _active_mesh(context) is not None and mode == "EDIT":
                obj = _active_mesh(context)
                bm, verts = _selected_edit_vertices(obj)
                if verts:
                    pos = sum((obj.matrix_world @ v.co for v in verts), Vector((0, 0, 0))) / len(verts)
                    context.scene.cursor.location = pos
            else:
                objects = _selected_objects(context)
                if objects:
                    context.scene.cursor.location = sum((o.location.copy() for o in objects), Vector((0, 0, 0))) / len(objects)
        elif self.mode == "ORIGIN_TO_CURSOR":
            old = _ensure_object_mode(context)
            try:
                bpy.ops.object.origin_set(type="ORIGIN_CURSOR", center="MEDIAN")
            except Exception:
                pass
            _restore_mode(context, old)
        else:
            size = float(self.plane_size) * 0.5
            c = context.scene.cursor.location.copy()
            verts = [c + Vector((-size, -size, 0)), c + Vector((size, -size, 0)), c + Vector((size, size, 0)), c + Vector((-size, size, 0))]
            obj = _make_mesh_object(context, "SMToolset Workplane", verts, [(0, 1, 2, 3)])
            try:
                obj.display_type = "WIRE"
                obj.show_wire = True
            except Exception:
                pass
            _set_active(context, obj)
        return {"FINISHED"}


class SMSUITE_OT_drop_snap_tools(Operator):
    bl_idname = "smsuite.drop_snap_tools"
    bl_label = 'Drop and Snap'
    bl_description = "Drops, snaps, or aligns selected objects to the active target, providing DropIt, Drop to Floor, QuickSnap, surface placement, and simple layout alignment alternatives."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Drop moves selected objects down to the active target surface. Snap Origin moves objects to the active origin. Floor moves objects to world Z zero.",
        items=(
            ("DROP", "Drop to Active Surface", "Drop selected objects vertically onto the active mesh surface."),
            ("SNAP_ORIGIN", "Snap to Active Origin", "Move selected objects to the active object's origin."),
            ("FLOOR", "Drop to Floor", "Move selected objects so their lowest point rests on world Z zero."),
        ),
        default="DROP",
    )
    offset: FloatProperty(name="Offset", description="Vertical offset left above the hit surface or floor after dropping.", default=0.0, min=-1000.0, max=1000.0)
    ray_height: FloatProperty(name="Ray Height", description="Height above each object origin where downward raycasts begin for surface dropping.", default=100.0, min=0.0, max=100000.0)

    @classmethod
    def poll(cls, context):
        return bool(_selected_objects(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        active = _active_object(context)
        selected = [o for o in _selected_objects(context) if o != active]
        moved = 0
        if self.mode == "FLOOR":
            for obj in _selected_objects(context):
                pts = _bbox_world(obj)
                min_z = min((p.z for p in pts), default=obj.location.z)
                obj.location.z += -min_z + float(self.offset)
                moved += 1
        elif self.mode == "SNAP_ORIGIN":
            if active is None:
                return {"CANCELLED"}
            for obj in selected:
                obj.location = active.location.copy()
                moved += 1
        else:
            if active is None or getattr(active, "type", None) != "MESH":
                _safe_report(self, "WARNING", "Make a mesh surface active and select objects to drop onto it.", "接地先のメッシュサーフェスをアクティブにし、その上へ落とすオブジェクトを選択してください。", context)
                _restore_mode(context, mode)
                return {"CANCELLED"}
            for obj in selected:
                start = obj.location.copy() + Vector((0.0, 0.0, float(self.ray_height)))
                hit, _normal = _raycast_down(active, start, float(self.ray_height) * 2.0 + 1000.0, context=context)
                if hit is None:
                    continue
                min_z = min((p.z for p in _bbox_world(obj)), default=obj.location.z)
                obj.location.z += hit.z - min_z + float(self.offset)
                moved += 1
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Moved {moved} objects.", f"{moved}個のオブジェクトを移動しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_falloff_deform(Operator):
    bl_idname = "smsuite.falloff_deform"
    bl_label = 'Deform with Falloff'
    bl_description = "Applies a Modo-style radial falloff deformation from the 3D cursor to selected vertices, useful for controlled panel bulges, dents, organic hard-surface transitions, and proportional modeling cleanup."
    bl_options = {"UNDO"}

    strength: FloatProperty(name="Strength", description="Displacement strength applied along selected vertex normals near the 3D cursor.", default=0.1, min=-1000.0, max=1000.0)
    radius: FloatProperty(name="Radius", description="Falloff radius around the 3D cursor. Vertices outside this radius remain unchanged.", default=1.0, min=0.0001, max=100000.0)
    power: FloatProperty(name="Power", description="Falloff exponent. Higher values concentrate deformation near the cursor; lower values make a broad deformation.", default=2.0, min=0.01, max=32.0)

    @classmethod
    def poll(cls, context):
        obj = _active_mesh(context)
        return obj is not None and getattr(obj, "mode", "OBJECT") == "EDIT"

    def execute(self, context):
        obj = _active_mesh(context)
        bm, verts = _selected_edit_vertices(obj)
        if not verts:
            return {"CANCELLED"}
        center = obj.matrix_world.inverted() @ context.scene.cursor.location
        radius = float(self.radius)
        for v in verts:
            d = (v.co - center).length
            if d > radius:
                continue
            factor = max(0.0, 1.0 - d / radius) ** float(self.power)
            normal = v.normal.copy()
            if normal.length < 1.0e-8:
                normal = Vector((0.0, 0.0, 1.0))
            v.co += normal.normalized() * float(self.strength) * factor
        bmesh.update_edit_mesh(obj.data)
        return {"FINISHED"}


class SMSUITE_OT_modifier_stack_preset(Operator):
    bl_idname = "smsuite.modifier_stack_preset"
    bl_label = 'Add Modifier Stack'
    bl_description = "Adds non-destructive stack presets inspired by 3ds Max modifier stacks, Houdini SOP chains, Modo MeshOps, BY-GEN, BagaPie, and procedural modeling workflows."
    bl_options = {"UNDO"}

    preset: EnumProperty(
        name="Preset",
        description="Choose a modifier stack. Hard Surface Modeling adds bevel and normals; Mirror Array adds mirror and array; Procedural Detail adds wireframe and displacement; Game Cleanup adds decimate and normals.",
        items=(
            ("HARD_SURFACE", "Hard Surface Modeling", "Bevel plus weighted normals for clean hard-surface shading."),
            ("MIRROR_ARRAY", "Mirror Array", "Mirror and array modifiers for symmetric repeated modeling."),
            ("PROCEDURAL_DETAIL", "Procedural Detail", "Wireframe and displacement detail stack for BY-GEN or Trypogen-style forms."),
            ("GAME_CLEANUP", "Game Cleanup", "Weighted normals and decimate for lightweight game asset cleanup."),
        ),
        default="HARD_SURFACE",
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_meshes(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        for obj in _selected_meshes(context):
            if self.preset == "HARD_SURFACE":
                bevel = _safe_modifier(obj, "BEVEL", "SMToolset Stack Bevel")
                if bevel is not None:
                    try:
                        bevel.width = 0.025
                        bevel.segments = 2
                        bevel.harden_normals = True
                    except Exception:
                        pass
                _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Stack Weighted Normal")
            elif self.preset == "MIRROR_ARRAY":
                _safe_modifier(obj, "MIRROR", "SMToolset Stack Mirror")
                arr = _safe_modifier(obj, "ARRAY", "SMToolset Stack Array")
                if arr is not None:
                    try:
                        arr.count = 3
                        arr.relative_offset_displace = (1.15, 0.0, 0.0)
                    except Exception:
                        pass
            elif self.preset == "PROCEDURAL_DETAIL":
                wire = _safe_modifier(obj, "WIREFRAME", "SMToolset Stack Wire")
                if wire is not None:
                    try:
                        wire.thickness = 0.02
                        wire.use_even_offset = True
                    except Exception:
                        pass
                disp = _safe_modifier(obj, "DISPLACE", "SMToolset Stack Displace")
                if disp is not None:
                    try:
                        tex = _create_modifier_texture("SMToolset Procedural Texture", "VORONOI")
                        if tex is not None:
                            disp.texture = tex
                        disp.strength = 0.03
                    except Exception:
                        pass
                _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Stack Weighted Normal")
            else:
                dec = _safe_modifier(obj, "DECIMATE", "SMToolset Stack Decimate")
                if dec is not None:
                    try:
                        dec.ratio = 0.7
                    except Exception:
                        pass
                _safe_modifier(obj, "WEIGHTED_NORMAL", "SMToolset Stack Weighted Normal")
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_cad_import_cleaner(Operator):
    bl_idname = "smsuite.cad_import_cleaner"
    bl_label = 'Clean CAD Import'
    bl_description = "Cleans imported CAD, DWG, Plasticity, MoI3D, NURBS-converted, and kitbash assets by applying transforms, converting curves, merging doubles, normalizing names, and removing loose mesh data."
    bl_options = {"UNDO"}

    convert_curves: BoolProperty(name="Convert Curves", description="Convert selected curve objects to meshes before cleanup so imported CAD splines can be welded and simplified.", default=False)
    apply_transforms: BoolProperty(name="Apply Transforms", description="Apply location, rotation, and scale transforms to selected objects before mesh cleanup.", default=True)
    rename_prefix: StringProperty(name="Rename Prefix", description="Optional prefix applied to cleaned objects for easier scene organization.", default="SMS_CAD")
    merge_distance: FloatProperty(name="Merge Distance", description="Weld threshold for converted or imported mesh objects.", default=0.0001, min=0.0, max=1.0)

    @classmethod
    def poll(cls, context):
        return bool(_selected_objects(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        objects = list(_selected_objects(context))
        cleaned = 0
        processed = []
        for index, original in enumerate(objects, start=1):
            obj = original
            _select_only(context, obj)
            if self.convert_curves and getattr(obj, "type", None) == "CURVE":
                try:
                    bpy.ops.object.convert(target="MESH")
                    obj = _active_object(context)
                except Exception:
                    pass
            if self.apply_transforms and getattr(obj, "type", None) == "MESH":
                _select_only(context, obj)
                try:
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
                except Exception:
                    pass
            if getattr(obj, "type", None) == "MESH":
                _mesh_cleanup_object(obj, merge_distance=float(self.merge_distance), dissolve_angle=math.radians(1.0), delete_loose=True, recalc=True)
                cleaned += 1
            prefix = str(self.rename_prefix or "").strip()
            if prefix and obj is not None:
                try:
                    obj.name = f"{prefix}_{index:03d}"
                except Exception:
                    pass
            if obj is not None:
                processed.append(obj)
        try:
            bpy.ops.object.select_all(action="DESELECT")
            for obj in processed:
                try:
                    obj.select_set(True)
                except Exception:
                    pass
            if processed:
                _set_active(context, processed[-1])
        except Exception:
            pass
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Cleaned {cleaned} mesh objects.", f"{cleaned}個のメッシュオブジェクトを整理しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_asset_replace_randomize(Operator):
    bl_idname = "smsuite.asset_replace_randomize"
    bl_label = 'Replace and Randomize Assets'
    bl_description = "Replaces or randomizes selected placeholder objects using the active object as the source, covering Instance Replacer, Random Transform, kitbash placement, and batch layout variation workflows."
    bl_options = {"UNDO"}

    replace_with_active: BoolProperty(name="Replace With Active", description="Replace selected placeholder objects with linked duplicates of the active object while preserving each placeholder transform.", default=True)
    keep_placeholders: BoolProperty(name="Keep Placeholders", description="Keep original placeholder objects after creating replacements. Disable this for a true replacement operation.", default=False)
    random_rotation: BoolProperty(name="Random Rotation", description="Apply random Z rotation to selected or replacement objects for natural layout variation.", default=True)
    min_scale: FloatProperty(name="Minimum Scale", description="Minimum random scale multiplier.", default=0.9, min=0.0, max=1000.0)
    max_scale: FloatProperty(name="Maximum Scale", description="Maximum random scale multiplier.", default=1.1, min=0.0, max=1000.0)
    seed: IntProperty(name="Seed", description="Random seed for repeatable replacement and transform variation.", default=3, min=0, max=999999)

    @classmethod
    def poll(cls, context):
        return _active_object(context) is not None and len(_selected_objects(context)) >= 1

    def execute(self, context):
        mode = _ensure_object_mode(context)
        active = _active_object(context)
        selected = [o for o in _selected_objects(context) if o != active]
        random.seed(int(self.seed))
        changed = 0
        if self.replace_with_active and active is not None:
            for obj in selected:
                inst = active.copy()
                try:
                    inst.data = active.data
                except Exception:
                    pass
                inst.matrix_world = obj.matrix_world.copy()
                if self.random_rotation:
                    inst.rotation_euler.z += random.random() * math.tau
                s = random.uniform(float(self.min_scale), float(self.max_scale))
                inst.scale = tuple(v * s for v in inst.scale)
                _link_object(context, inst)
                if not self.keep_placeholders:
                    try:
                        bpy.data.objects.remove(obj, do_unlink=True)
                    except Exception:
                        pass
                changed += 1
        else:
            for obj in selected or [active]:
                if self.random_rotation:
                    obj.rotation_euler.z += random.random() * math.tau
                s = random.uniform(float(self.min_scale), float(self.max_scale))
                obj.scale = tuple(v * s for v in obj.scale)
                changed += 1
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Processed {changed} objects.", f"{changed}個のオブジェクトを処理しました。", context)
        return {"FINISHED"}


class SMSUITE_OT_magic_solo(Operator):
    bl_idname = "smsuite.magic_solo"
    bl_label = 'Solo Visibility'
    bl_description = "Isolates, reveals, or toggles selected objects without changing the rest of the Smart Modeling UI, providing MagicSolo, clean panel focus, and layout inspection alternatives."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Isolate hides unselected objects, Reveal All shows everything, and Hide Selected hides only the current selection.",
        items=(
            ("ISOLATE", "Isolate", "Hide unselected scene objects and keep selected objects visible."),
            ("REVEAL", "Reveal All", "Reveal all objects in the current view layer."),
            ("HIDE_SELECTED", "Hide Selected", "Hide the selected objects only."),
        ),
        default="ISOLATE",
    )

    def execute(self, context):
        selected = set(_selected_objects(context))
        if self.mode == "ISOLATE" and not selected:
            _safe_report(self, "WARNING", "Select at least one object before isolating.", "単独表示する前に、少なくとも1つのオブジェクトを選択してください。", context)
            return {"CANCELLED"}
        try:
            objects = list(context.view_layer.objects)
        except Exception:
            objects = list(bpy.data.objects)
        if self.mode == "REVEAL":
            for obj in objects:
                try:
                    obj.hide_set(False)
                except Exception:
                    pass
        elif self.mode == "HIDE_SELECTED":
            for obj in selected:
                try:
                    obj.hide_set(True)
                except Exception:
                    pass
        else:
            for obj in objects:
                try:
                    obj.hide_set(obj not in selected)
                except Exception:
                    pass
        return {"FINISHED"}


class SMSUITE_OT_slice_wire_detail(Operator):
    bl_idname = "smsuite.slice_wire_detail"
    bl_label = 'Add Slice Wire Detail'
    bl_description = "Adds procedural slicer, divider, trypogen, wireframe, thrausi-style fracture prep, and contour detail alternatives through non-destructive modifier stacks or generated slicing guides."
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="Mode",
        description="Wire Detail adds triangulate, wireframe, and displacement modifiers. Slice Guides creates evenly spaced guide planes through the selected objects.",
        items=(
            ("WIRE", "Wire Detail", "Add procedural wireframe and displacement detail modifiers."),
            ("SLICE_GUIDES", "Slice Guides", "Create evenly spaced slicing guide planes through selected object bounds."),
        ),
        default="WIRE",
    )
    count: IntProperty(name="Count", description="Number of slicing guide planes or detail repetitions.", default=8, min=1, max=1000)
    thickness: FloatProperty(name="Thickness", description="Wire thickness or guide plane thickness.", default=0.02, min=0.0001, max=1000.0)

    @classmethod
    def poll(cls, context):
        return bool(_selected_objects(context))

    def execute(self, context):
        mode = _ensure_object_mode(context)
        objects = _selected_meshes(context)
        if not objects:
            _restore_mode(context, mode)
            _safe_report(self, "WARNING", "Select at least one mesh object.", "少なくとも1つのメッシュオブジェクトを選択してください。", context)
            return {"CANCELLED"}
        if self.mode == "WIRE":
            for obj in objects:
                _safe_modifier(obj, "TRIANGULATE", "SMToolset Divider Triangulate")
                wire = _safe_modifier(obj, "WIREFRAME", "SMToolset Trypogen Wire")
                if wire is not None:
                    try:
                        wire.thickness = float(self.thickness)
                        wire.use_even_offset = True
                    except Exception:
                        pass
                disp = _safe_modifier(obj, "DISPLACE", "SMToolset Micro Displace")
                if disp is not None:
                    try:
                        tex = _create_modifier_texture("SMToolset Slice Noise", "VORONOI")
                        if tex is not None:
                            disp.texture = tex
                        disp.strength = float(self.thickness) * 0.5
                    except Exception:
                        pass
        else:
            for obj in objects:
                center = _bbox_center(obj)
                size = _bbox_size(obj)
                for i in range(int(self.count)):
                    z = center.z - size.z * 0.5 + size.z * (i + 0.5) / max(1, int(self.count))
                    verts: list[Vector] = []
                    faces: list[tuple[int, ...]] = []
                    _append_box(verts, faces, Vector((center.x, center.y, z)), Vector((size.x * 1.1, size.y * 1.1, float(self.thickness))))
                    guide = _make_mesh_object(context, f"SMToolset Slice Guide {obj.name}", verts, faces)
                    try:
                        guide.display_type = "WIRE"
                    except Exception:
                        pass
        _restore_mode(context, mode)
        return {"FINISHED"}


class SMSUITE_OT_kit_insert(Operator):
    bl_idname = "smsuite.kit_insert"
    bl_label = 'Insert Kit Asset'
    bl_description = "Places selected kitbash assets onto the active surface near the 3D cursor and optionally adds boolean preparation, covering Kit Ops, Polystein, Primo, insert mesh, plug, and CAD detail workflows."
    bl_options = {"UNDO"}

    snap_to_surface: BoolProperty(name="Snap to Surface", description="Snap inserted kit objects to the closest point on the active mesh surface near the 3D cursor.", default=True)
    align_to_normal: BoolProperty(name="Align to Normal", description="Align inserted kit objects so their local Z axis follows the active surface normal.", default=True)
    add_boolean: BoolProperty(name="Add Boolean Difference", description="Add a Difference boolean from each inserted kit object to the active target for cut-in details. Leave disabled for surface-only kitbash placement.", default=False)
    scale: FloatProperty(name="Scale", description="Scale multiplier applied to inserted kit objects after duplication.", default=1.0, min=0.0001, max=1000.0)

    @classmethod
    def poll(cls, context):
        return _active_mesh(context) is not None and len(_selected_objects(context)) >= 2

    def execute(self, context):
        mode = _ensure_object_mode(context)
        target = _active_mesh(context)
        kits = [o for o in _selected_objects(context) if o != target]
        cursor = context.scene.cursor.location.copy()
        hit, normal = _closest_world_point(target, cursor, max_distance=100000.0, context=context)
        location = hit if (hit is not None and self.snap_to_surface) else cursor
        normal = normal or Vector((0.0, 0.0, 1.0))
        inserted = 0
        for kit in kits:
            inst = kit.copy()
            try:
                inst.data = kit.data.copy() if getattr(kit, "data", None) is not None else None
            except Exception:
                pass
            inst.location = location
            inst.scale = tuple(float(self.scale) * v for v in kit.scale)
            if self.align_to_normal:
                try:
                    inst.matrix_world = Matrix.Translation(location) @ _normal_to_matrix(normal) @ Matrix.Diagonal((inst.scale.x, inst.scale.y, inst.scale.z, 1.0))
                except Exception:
                    pass
            _link_object(context, inst)
            if self.add_boolean and target is not None:
                mod = _safe_modifier(target, "BOOLEAN", f"SMToolset Kit Cut {inst.name}")
                if mod is not None:
                    try:
                        mod.operation = "DIFFERENCE"
                        mod.object = inst
                        mod.solver = "EXACT"
                    except Exception:
                        pass
            inserted += 1
        _restore_mode(context, mode)
        _safe_report(self, "INFO", f"Inserted {inserted} kit objects.", f"{inserted}個のキットオブジェクトを挿入しました。", context)
        return {"FINISHED"}



def _draw_section_help_icon(row, alias: str, label: str) -> None:
    try:
        op = row.operator(
            "smart_modeling_suite.show_tool_help",
            text="",
            icon="QUESTION",
            emboss=True,
        )
        op.kind = "workflow_category"
        op.alias = str(alias or "")
        op.label = str(label or "")
    except Exception:
        pass

def draw_integrated_panel(layout, context):
    """Draw the compact Toolset-integrated command deck without registering a separate panel."""
    layout.use_property_split = False
    layout.use_property_decorate = False

    status = layout.box()
    status_row = status.row(align=True)
    status_row.scale_y = 1.05
    status_row.label(text=_selection_status_text(context), icon=_safe_icon("CHECKMARK", "NONE"))
    hint = status.row(align=True)
    hint.scale_y = 0.72
    hint.label(text=_pick("Frame-free large icon command deck", "枠無し大判アイコンのコマンドデッキ", context))

    def section(title_en: str, title_ja: str, icon_key: str, columns: int = 4, help_alias: str = ""):
        box = layout.box()
        head = box.row(align=True)
        head.scale_y = 0.9
        title = _pick(title_en, title_ja, context)
        head.label(text=title, icon_value=_icon_value(icon_key))
        _draw_section_help_icon(head, help_alias or icon_key, title)
        try:
            grid = box.grid_flow(columns=columns, even_columns=True, even_rows=True, align=True)
        except Exception:
            grid = box.column(align=True)
        return grid

    grid = section("Context and Topology", "コンテキスト編集とトポロジー", "context_auto", 4, "suite_context_topology")
    _button_with_custom_icon(grid, "smsuite.context_modeler", "context_auto", "Auto", "自動", context, {"action": "AUTO"})
    _button_with_custom_icon(grid, "smsuite.context_modeler", "context_fill", "Fill", "面張り", context, {"action": "FILL"})
    _button_with_custom_icon(grid, "smsuite.context_modeler", "context_extrude", "Extrude", "押出整理", context, {"action": "EXTRUDE"})
    _button_with_custom_icon(grid, "smsuite.context_modeler", "context_inset", "Inset", "インセット", context, {"action": "INSET"})
    _button_with_custom_icon(grid, "smsuite.context_modeler", "context_bridge", "Bridge", "ブリッジ", context, {"action": "BRIDGE"})
    _button_with_custom_icon(grid, "smsuite.quad_rebuild", "quad_auto", "Quad Auto", "クアッド自動", context, {"mode": "AUTO"})
    _button_with_custom_icon(grid, "smsuite.quad_rebuild", "quad_grid", "Grid Fill", "格子面張り", context, {"mode": "GRID"})
    _button_with_custom_icon(grid, "smsuite.quad_rebuild", "quad_tris", "Tris→Quad", "三角→四角", context, {"mode": "TRIS_TO_QUADS"})
    _button_with_custom_icon(grid, "smsuite.loop_shape_suite", "loop_circle", "Circle", "円形化", context, {"mode": "CIRCLE"})
    _button_with_custom_icon(grid, "smsuite.loop_shape_suite", "loop_relax", "Relax", "リラックス", context, {"mode": "RELAX"})
    _button_with_custom_icon(grid, "smsuite.loop_shape_suite", "loop_space", "Space", "等間隔", context, {"mode": "SPACE"})
    _button_with_custom_icon(grid, "smsuite.align_unbend", "align_line", "Unbend", "直線化", context)

    grid = section("Hard Surface Modeling and Boolean", "ハードサーフェスとブーリアン", "boolean_stack", 4, "suite_hard_surface_boolean")
    _button_with_custom_icon(grid, "smsuite.boolean_fusion_stack", "boolean_stack", "Fusion", "融合", context)
    _button_with_custom_icon(grid, "smsuite.boolean_apply_clean", "boolean_apply", "Apply", "適用整理", context)
    _button_with_custom_icon(grid, "smsuite.bevel_normal_stack", "bevel_normal", "Bevel", "ベベル", context)
    _button_with_custom_icon(grid, "smsuite.unbevel_planar_clean", "planar_clean", "Planar", "平面整理", context)
    _button_with_custom_icon(grid, "smsuite.solidify_plus", "solidify_plus", "Solidify", "厚み付け", context)
    _button_with_custom_icon(grid, "smsuite.kit_insert", "kit_insert", "Kit", "キット素材を挿入", context)
    _button_with_custom_icon(grid, "smsuite.modifier_stack_preset", "modifier_stack_hardsurface", "HS Stack", "硬質スタック", context, {"preset": "HARD_SURFACE"})
    _button_with_custom_icon(grid, "smsuite.modifier_stack_preset", "modifier_stack_detail", "Detail", "生成ディテール", context, {"preset": "PROCEDURAL_DETAIL"})

    grid = section("Curve, Surface, and Retopo", "カーブ、面追従、リトポ", "cable_pipe", 4, "suite_curve_surface_retopo")
    _button_with_custom_icon(grid, "smsuite.cable_pipe_from_selection", "cable_pipe", "Cable", "ケーブル", context)
    _button_with_custom_icon(grid, "smsuite.rail_sweep_generator", "rail_sweep_pipe", "Rail Pipe", "レール管", context, {"mode": "PIPE"})
    _button_with_custom_icon(grid, "smsuite.rail_sweep_generator", "rail_sweep_path", "Along Path", "パス複製", context, {"mode": "DUPLICATE"})
    _button_with_custom_icon(grid, "smsuite.bend_projection", "bend", "Bend", "曲げ", context, {"mode": "BEND"})
    _button_with_custom_icon(grid, "smsuite.bend_projection", "project", "Project", "投影", context, {"mode": "PROJECT"})
    _button_with_custom_icon(grid, "smsuite.retopo_wrap_remesh", "retopo_voxel", "Retopo", "リトポ", context, {"method": "VOXEL"})
    _button_with_custom_icon(grid, "smsuite.retopo_wrap_remesh", "shrinkwrap_surface", "Shrink", "面追従", context, {"method": "SHRINKWRAP"})
    _button_with_custom_icon(grid, "smsuite.falloff_deform", "falloff", "Falloff", "フォールオフ", context)

    grid = section("Procedural Generation", "プロシージャル生成", "surface_scatter", 4, "suite_procedural_generation")
    _button_with_custom_icon(grid, "smsuite.scatter_surface", "surface_scatter", "Scatter", "表面に散布", context)
    _button_with_custom_icon(grid, "smsuite.floor_wall_generator", "floor_tiles", "Floor", "床タイル", context, {"mode": "FLOOR"})
    _button_with_custom_icon(grid, "smsuite.floor_wall_generator", "brick_wall", "Wall", "レンガ壁", context, {"mode": "WALL"})
    _button_with_custom_icon(grid, "smsuite.floor_wall_generator", "stairs", "Stairs", "階段", context, {"mode": "STAIRS"})
    _button_with_custom_icon(grid, "smsuite.floor_wall_generator", "facade_grid", "Facade", "ファサード", context, {"mode": "FACADE"})
    _button_with_custom_icon(grid, "smsuite.terrain_generator", "terrain", "Terrain", "地形", context)
    _button_with_custom_icon(grid, "smsuite.slice_wire_detail", "slice_wire_wire", "Wire", "ワイヤ化", context, {"mode": "WIRE"})
    _button_with_custom_icon(grid, "smsuite.slice_wire_detail", "slice_wire_slices", "Slices", "スライス", context, {"mode": "SLICE_GUIDES"})

    grid = section("Cleanup, CAD, and Layout", "整理、CAD、配置", "repair_audit", 4, "suite_cleanup_cad_layout")
    _button_with_custom_icon(grid, "smsuite.mesh_repair_audit", "repair_audit", "Repair", "修復監査", context)
    _button_with_custom_icon(grid, "smsuite.cad_import_cleaner", "cad_cleaner", "CAD", "CAD整理", context)
    _button_with_custom_icon(grid, "smsuite.workplane_pivot_tools", "workplane_cursor", "Cursor", "カーソル", context, {"mode": "CURSOR_TO_SELECTION"})
    _button_with_custom_icon(grid, "smsuite.workplane_pivot_tools", "workplane_origin", "Origin", "原点", context, {"mode": "ORIGIN_TO_CURSOR"})
    _button_with_custom_icon(grid, "smsuite.workplane_pivot_tools", "workplane_plane", "Plane", "作業平面", context, {"mode": "CREATE_WORKPLANE"})
    _button_with_custom_icon(grid, "smsuite.drop_snap_tools", "drop_surface", "Drop", "表面接地", context, {"mode": "DROP"})
    _button_with_custom_icon(grid, "smsuite.drop_snap_tools", "drop_floor", "Floor", "床接地", context, {"mode": "FLOOR"})
    _button_with_custom_icon(grid, "smsuite.drop_snap_tools", "snap_origin", "Snap", "原点スナップ", context, {"mode": "SNAP_ORIGIN"})
    _button_with_custom_icon(grid, "smsuite.asset_replace_randomize", "asset_replace", "Replace", "置換", context, {"replace_with_active": True})
    _button_with_custom_icon(grid, "smsuite.asset_replace_randomize", "randomize_transform", "Random", "ランダム", context, {"replace_with_active": False})
    _button_with_custom_icon(grid, "smsuite.magic_solo", "magic_solo", "Solo", "単独表示", context, {"mode": "ISOLATE"})
    _button_with_custom_icon(grid, "smsuite.magic_solo", "magic_reveal", "Reveal", "全表示", context, {"mode": "REVEAL"})



_CLASSES = (
    SMSUITE_OT_context_modeler,
    SMSUITE_OT_loop_shape_suite,
    SMSUITE_OT_boolean_fusion_stack,
    SMSUITE_OT_boolean_apply_clean,
    SMSUITE_OT_bevel_normal_stack,
    SMSUITE_OT_unbevel_planar_clean,
    SMSUITE_OT_cable_pipe_from_selection,
    SMSUITE_OT_align_unbend,
    SMSUITE_OT_quad_rebuild,
    SMSUITE_OT_mesh_repair_audit,
    SMSUITE_OT_solidify_plus,
    SMSUITE_OT_bend_projection,
    SMSUITE_OT_retopo_wrap_remesh,
    SMSUITE_OT_scatter_surface,
    SMSUITE_OT_floor_wall_generator,
    SMSUITE_OT_terrain_generator,
    SMSUITE_OT_rail_sweep_generator,
    SMSUITE_OT_workplane_pivot_tools,
    SMSUITE_OT_drop_snap_tools,
    SMSUITE_OT_falloff_deform,
    SMSUITE_OT_modifier_stack_preset,
    SMSUITE_OT_cad_import_cleaner,
    SMSUITE_OT_asset_replace_randomize,
    SMSUITE_OT_magic_solo,
    SMSUITE_OT_slice_wire_detail,
    SMSUITE_OT_kit_insert,
)

_TRANSLATIONS = {
    "Modeling Toolkit": "統合モデリングツール",
    "Smart Modeling Toolkit": "Smart Modeling 統合モデリングツール",
    "Integrated Smart Modeling command layer for hard-surface, retopology, procedural, CAD-like, scatter, spline, and cleanup workflows.": 'ハードサーフェス、リトポロジー、プロシージャル、CAD 風、散布、スプライン、整理の作業のコマンドをまとめた物です。',
    "Context and Topology": "コンテキスト編集とトポロジー",
    "Hard Surface Modeling and Boolean": "ハードサーフェスとブーリアン",
    "Curve, Surface, and Retopo": "カーブ、面追従、リトポ",
    "Procedural Generation": "プロシージャル生成",
    "Cleanup, CAD, and Layout": "整理、CAD、配置",
    "Auto Model": "自動モデリング",
    "Rebuild Quads": "クアッドを再構築",
    "Relax": "リラックス",
    "Unbend": "直線化",
    "Fusion Stack": '融合のスタック',
    "Apply Clean": "適用して整理",
    "Bevel Normals": "ベベル法線",
    "Planar Clean": "平面整理",
    "Create Solidify Shell": 'シェル厚みを作成',
    "Insert Kit Asset": "キット素材を挿入",
    "Cable Pipe": "ケーブル化",
    "Rail Sweep": "レール生成",
    "Bend": "曲げ",
    "Project": "投影",
    "Retopo Wrap": "リトポ追従",
    "Falloff": '減衰',
    "Scatter on Surface": "表面に散布",
    "Floor Wall": "床と壁を生成",
    "Terrain": "地形",
    "Slice Wire": "スライスワイヤ",
    "Repair Audit": "修復監査",
    "CAD Cleaner": 'CAD の整理',
    "Workplane": "作業平面",
    "Drop Snap": "接地スナップ",
    "Replace Randomize": "置換ランダム",
    "Solo Visibility": "単独表示",
}

for _cls in _CLASSES:
    _label = getattr(_cls, "bl_label", "")
    _desc = getattr(_cls, "bl_description", "")
    if _label:
        _TRANSLATIONS.setdefault(_label, _label)
    if _desc:
        _TRANSLATIONS.setdefault(_desc, _desc)

_TRANSLATIONS.update({
    "Runs a ZModeler-style context action for the current selection: fills edges, extrudes faces with cleanup, bridges loops, or performs a safe inset depending on the selected component mode.": "現在の選択に対してZModeler風のコンテキスト操作を実行します。辺からの面張り、クリーンアップ付き押し出し、ループブリッジ、安全なインセットを選択状態に応じて使います。",
    "Provides Loop Tools-style circle, relax, space, bridge, loft, and flatten actions with safe fallbacks for selected loops and strips.": '選択のループや帯に、円・リラックス・等間隔・ブリッジ・ロフト・平坦化を行います。',
    "Builds a non-destructive boolean stack on the active mesh from the other selected cutter objects, then optionally adds bevel and weighted-normal cleanup for Hard Ops, Boxcutter, Fluent, MeshFusion, and MOP-style workflows.": '他の選択カッターからアクティブメッシュへ非破壊ブーリアンスタックを作成し、必要に応じてベベルと重み付き法線を追加します。Hard Ops、Boxcutter、Fluent、MeshFusion、MOP系の作業をBlender標準機能で代替します。',
    "Applies boolean modifiers on selected objects, then performs merge-by-distance, limited dissolve, normal recalculation, and optional weighted-normal restoration for clean game-ready or render-ready meshes.": "選択オブジェクトのブーリアンモディファイアを適用し、距離マージ、制限溶解、法線再計算、任意の重み付き法線復元を行います。ゲーム向け、レンダー向けの整理済みメッシュ作成に使います。",
    "Adds a hard-surface bevel and weighted-normal stack to selected objects, acting as a non-destructive Mesh Machine, ReBevel, and weighted normal cleanup alternative.": "選択オブジェクトへハードサーフェス向けのベベルと重み付き法線スタックを追加します。Mesh Machine、ReBevel、法線整理の非破壊代替として使います。",
    "Runs a conservative unbevel-like cleanup by limited-dissolving near-planar bevel support edges, welding tiny overlaps, and recalculating normals to reduce boolean and bevel artifacts.": "ほぼ平面のベベル補助辺を制限溶解し、微小な重複を溶接し、法線を再計算する保守的なUnbevel風クリーンアップを行います。",
    "Creates Cablerator, Sweep Mesh, ReeperX, Topowire, and ElboPipe-style cables or pipes from selected curves or mesh edges, with bevel depth and resolution applied automatically.": '選択カーブまたはメッシュ辺から、Cablerator、Sweep Mesh、ReeperX、Topowire、ElboPipe風のケーブルやパイプを作成し、ベベル深度と解像度を自動設定します。',
    "Aligns selected vertices to a best-fit line or axis to emulate Align Edges, Unbend Mesh, Modo workplane cleanup, and precision CAD-like straightening workflows.": '選択頂点をベストフィット線または軸へ整列します。Align Edges、Unbend Mesh、Modo作業平面整理、CAD風の直線化作業を代替します。',
    "Rebuilds selected topology with quad-oriented fallbacks: F2 fill, grid fill, triangle-to-quad conversion, quad caps, Boolean Quad Ready-style preparation, and N-gon cleanup.": 'F2面張り、グリッドフィル、三角形から四角形への変換、クアッドキャップ、Boolean Quad Ready風の準備、Nゴン整理を使い、選択トポロジーをクアッド寄りに再構築します。',
    "Audits and repairs selected meshes using 3D Print Toolbox, mesh repair, CAD cleanup, imported-DWG cleanup, Nsolve-style planar cleanup, and manifold-fix inspired operations.": '3D Print Toolbox、メッシュ修復、CAD整理、DWGインポート整理、Nsolve風の平面整理、多様体修復を意識した処理で選択メッシュを監査・修復します。',
    "Adds robust thickness with even offset, optional rim cleanup, bevel, and weighted normals as an upper-compatible Create Solidify Shell and hard-surface shelling helper.": '均一オフセットの厚み、任意のリム整理、ベベル、重み付き法線を追加します。Create Solidify Shellおよびハードサーフェスのシェル化補助の代替です。',
    "Adds Simple Bend deformation or projects selected geometry to a target surface, covering Simple Bend, Projection Modeling, shrinkwrap, and surface-conform workflows.": 'Simple Bend変形を追加するか、選択ジオメトリをターゲット面へ投影します。Simple Bend、Projection Modeling、Shrinkwrap、面追従作業を代替します。',
    "Creates a Quad Remesher, QRemeshify, Retopoflow, Quad Draw, Topobuild, and shrinkwrap-inspired retopology pass using Blender-native remesh and shrinkwrap fallbacks.": 'Blender標準のリメッシュとShrinkwrapを使い、Quad Remesher、QRemeshify、Retopoflow、Quad Draw、Topobuild風のリトポ処理を作成します。',
    "Scatters selected source objects across the active mesh surface with random scale, rotation, and normal alignment, covering Geo-Scatter, Forest Pack, MASH, spPaint3D, BagaPie scatter, and environment painting workflows.": '選択ソースをアクティブメッシュ表面へランダムスケール、回転、法線追従付きで散布します。Geo-Scatter、Forest Pack、MASH、spPaint3D、BagaPie散布、環境ペイント作業を代替します。',
    "Generates FloorGenerator, BrickIt, RailClone facade, Archviz tile, stair, and wall blocking geometry as editable mesh pieces from procedural dimensions.": 'FloorGenerator、BrickIt、RailCloneファサード、建築タイル、階段、壁のブロックアウト形状を寸法から編集可能なメッシュとして生成します。',
    "Generates editable terrain meshes inspired by Terrain Generator, Houdini heightfields, Terrain Builder, rock generators, and procedural environment block-out tools.": 'Terrain Generator、Houdini HeightField、Terrain Builder、岩生成、プロシージャル環境ブロックアウトを意識した編集可能な地形メッシュを生成します。',
    "Creates RailClone, Sweep Mesh, Duplicate Along Path, spline extruder, and procedural pipe alternatives by sweeping curves or duplicating source objects along selected curves.": 'カーブのパイプ化またはカーブ沿い複製により、RailClone、Sweep Mesh、Duplicate Along Path、スプライン押し出し、プロシージャルパイプの代替を作成します。',
    "Places the 3D cursor, origin, or helper workplane from the current selection, covering Modo Workplane, Action Centers, Pivot Tools, Drop to Floor setup, and CAD-like modeling plane workflows.": '現在の選択から3Dカーソル、原点、補助作業平面を配置します。Modo Workplane、Action Centers、Pivot Tools、Drop to Floor準備、CAD風作業平面を代替します。',
    "Drops, snaps, or aligns selected objects to the active target, providing DropIt, Drop to Floor, QuickSnap, surface placement, and simple layout alignment alternatives.": '選択オブジェクトをアクティブターゲットへ接地、スナップ、整列します。DropIt、Drop to Floor、QuickSnap、表面配置、簡易レイアウト整列を代替します。',
    "Applies a Modo-style radial falloff deformation from the 3D cursor to selected vertices, useful for controlled panel bulges, dents, organic hard-surface transitions, and proportional modeling cleanup.": "3Dカーソルを中心にModo風の放射フォールオフで変形を選択頂点へ適用します。制御されたパネルの膨らみ、へこみ、有機的なハードサーフェス遷移、プロポーショナル整理に使います。",
    "Adds non-destructive stack presets inspired by 3ds Max modifier stacks, Houdini SOP chains, Modo MeshOps, BY-GEN, BagaPie, and procedural modeling workflows.": '3ds Maxのモディファイアスタック、Houdini SOPチェーン、Modo MeshOps、BY-GEN、BagaPie、プロシージャルモデリングを意識した非破壊スタックプリセットを追加します。',
    "Cleans imported CAD, DWG, Plasticity, MoI3D, NURBS-converted, and kitbash assets by applying transforms, converting curves, merging doubles, normalizing names, and removing loose mesh data.": 'インポートしたCAD、DWG、Plasticity、MoI3D、NURBS変換、キットバッシュ素材を、トランスフォーム適用、カーブ変換、重複頂点マージ、命名整理、ルーズメッシュ削除で整理します。',
    "Replaces or randomizes selected placeholder objects using the active object as the source, covering Instance Replacer, Random Transform, kitbash placement, and batch layout variation workflows.": 'アクティブオブジェクトをソースとして選択プレースホルダーを置換またはランダム化します。Instance Replacer、Random Transform、キットバッシュ配置、一括レイアウト差分を代替します。',
    "Isolates, reveals, or toggles selected objects without changing the rest of the Smart Modeling UI, providing MagicSolo, clean panel focus, and layout inspection alternatives.": 'Smart Modeling UIの他の部分を変更せず、選択オブジェクトの単独表示、再表示、非表示を行います。MagicSolo、集中表示、レイアウト確認の代替です。',
    "Adds procedural slicer, divider, trypogen, wireframe, thrausi-style fracture prep, and contour detail alternatives through non-destructive modifier stacks or generated slicing guides.": '非破壊モディファイアスタックまたはスライスガイド生成により、Slicer、Divider、Trypogen、Wireframe、Thrausi風破砕準備、等高線ディテールの代替を追加します。',
    "Places selected kitbash assets onto the active surface near the 3D cursor and optionally adds boolean preparation, covering Kit Ops, Polystein, Primo, insert mesh, plug, and CAD detail workflows.": '選択キットバッシュ素材を3Dカーソル近くのアクティブ面へ配置し、必要に応じてブーリアン準備を追加します。Kit Ops、Polystein、Primo、Insert Mesh、Plug、CADディテール作業を代替します。',
    "Grouped command panel for Blender-native upper-compatible alternatives to the modeling support tools listed in the Smart Modeling reference document.": "Smart Modeling参考資料にあるモデリング支援ツール群に対する、Blender標準機能ベースの上位互換代替コマンドをまとめたパネルです。",
})


_TRANSLATIONS.update({
    "Action": "アクション",
    "Mode": "モード",
    "Method": "方式",
    "Operation": "操作",
    "Preset": "プリセット",
    "Add Bevel": "ベベルを追加",
    "Add Bevel and Normals": "ベベルと法線を追加",
    "Add Boolean Difference": "差分ブーリアンを追加",
    "Add Shrinkwrap": 'シュリンクラップを追加',
    "Add Weighted Normal": "重み付き法線を追加",
    "Align to Normal": "法線へ整列",
    "Angle": "角度",
    "Apply All Boolean Modifiers": 'ブーリアンモディファイアーをすべて適用',
    "Apply Stack": "スタックを適用",
    "Apply Transforms": "トランスフォームを適用",
    "Bevel Width": "ベベル幅",
    "Columns": '列数',
    "Convert Curves": "カーブを変換",
    "Convert Selected Mesh Edges": '選択中のメッシュの辺を変換',
    "Count": "数",
    "Depth": '深さ',
    "Distance": "距離",
    "Fix Mesh": 'メッシュを修正',
    "Gap": "隙間",
    "Height": "高さ",
    "Hide Cutters": "カッターを非表示",
    "Inset Amount": '差し込みの量',
    "Iterations": "反復回数",
    "Keep Placeholders": "プレースホルダーを保持",
    "Linked Data": 'リンクしたデータ',
    "Max Distance": "最大距離",
    "Maximum Scale": "最大スケール",
    "Merge Distance": "マージ距離",
    "Minimum Scale": "最小スケール",
    "Offset": "オフセット",
    "Planar Angle": '平面の角度',
    "Plane Size": '平面のサイズ',
    "Power": '強さ',
    "Preserve Span": "範囲を保持",
    "Radius": "半径",
    "Random Rotation": "ランダム回転",
    "Ray Height": "レイ高さ",
    "Rename Prefix": "リネーム接頭辞",
    "Replace With Active": "アクティブで置換",
    "Resolution": "解像度",
    "Roughness": "粗さ",
    "Rows": "行数",
    "Scale": "スケール",
    "Seed": "シード",
    "Segments": "セグメント",
    "Size": "サイズ",
    "Snap to Surface": "表面へスナップ",
    "Strength": "強さ",
    "Subdivisions": "分割数",
    "Target Faces": '目標面数',
    "Thickness": "厚み",
    "Voxel Size": "ボクセルサイズ",
    "Width": "幅",
    "Add a Difference boolean from each inserted kit object to the active target for cut-in details. Leave disabled for surface-only kitbash placement.": "挿入した各キットオブジェクトからアクティブ対象へ差分ブーリアンを追加し、切り込みディテールを作ります。表面配置だけにしたい場合は無効にします。",
    "Add a Weighted Normal modifier after cleanup to reduce shading artifacts on N-gon and boolean-heavy hard-surface meshes.": "クリーンアップ後に重み付き法線モディファイアを追加し、Nゴンやブーリアンの多いハードサーフェスメッシュの陰影乱れを軽減します。",
    "Add a shrinkwrap modifier to the active target or to the second selected mesh after remeshing, useful for retopology projection.": 'リメッシュの後でアクティブな対象か 2 番目の選択のメッシュへシュリンクラップを追加します。リトポロジーの投影に向きます。',
    "Add a small bevel modifier after the boolean stack to create cleaner hard-surface highlights and a MeshFusion-like softened intersection.": "ブーリアンスタック後に小さなベベルを追加し、ハードサーフェスのハイライトとMeshFusion風の柔らかい交差部を作ります。",
    "Add bevel and weighted-normal modifiers after Solidify to keep shell edges readable and shading stable.": "Solidifyの後にベベルと重み付き法線を追加し、シェル端部を見やすく保ち、陰影を安定させます。",
    "Align inserted kit objects so their local Z axis follows the active surface normal.": "挿入するキットオブジェクトのローカルZ軸を、アクティブ表面の法線方向へ合わせます。",
    "Apply every Boolean modifier on each selected mesh before cleanup. Disable this when you only want to clean already-applied boolean results.": "クリーンアップ前に、選択メッシュ上のすべてのブーリアンモディファイアを適用します。既に適用済みの結果だけを整理する場合は無効にします。",
    "Apply location, rotation, and scale transforms to selected objects before mesh cleanup.": 'メッシュの掃除の前に、選択中のオブジェクトの位置・回転・スケールを適用します。',
    "Apply random Z rotation to selected or replacement objects for natural layout variation.": "選択オブジェクトまたは置換後オブジェクトへZ軸ランダム回転を加え、自然な配置差を作ります。",
    "Apply the bevel and weighted-normal modifiers immediately. Leave this disabled to keep the stack non-destructive.": "ベベルと重み付き法線モディファイアを即時適用します。非破壊スタックとして残す場合は無効にします。",
    "Approximate target face count for Quadriflow remeshing. Ignored by methods that do not expose target face count.": "Quadriflowリメッシュのおおよその目標面数です。目標面数を持たない方式では無視されます。",
    "Bend adds a non-destructive Simple Deform modifier. Project moves selected vertices or objects to the closest point on the active target surface.": "Bendは非破壊のSimple Deformを追加します。Projectは選択頂点またはオブジェクトをアクティブ対象表面の最近接点へ移動します。",
    "Bend angle in degrees for the Simple Deform modifier.": "Simple Deformモディファイアで使う曲げ角度です。単位は度です。",
    "Bevel width applied to selected mesh objects. Use very small values for highlight bevels and larger values for visible mechanical fillets.": "選択メッシュへ適用するベベル幅です。ハイライト用は非常に小さく、見える機械的フィレットには大きめに設定します。",
    "Boolean operation applied from each selected cutter to the active target. Difference cuts holes, Union fuses forms, and Intersect keeps only overlapping volume.": "各選択カッターからアクティブ対象へ適用するブーリアン操作です。Differenceは穴を開け、Unionは形状を融合し、Intersectは重なった体積だけを残します。",
    "Cable or pipe radius assigned to generated curves. Increase for pipes and decrease for thin wires.": "生成カーブへ割り当てるケーブルまたはパイプの半径です。パイプは大きく、細いワイヤは小さくします。",
    "Choose a modifier stack. Hard Surface Modeling adds bevel and normals; Mirror Array adds mirror and array; Procedural Detail adds wireframe and displacement; Game Cleanup adds decimate and normals.": 'モディファイアースタックを選びます。ハードサーフェスはベベルと法線、ミラーと配列はミラーと配列、プロシージャルの細部はワイヤーフレームと変位、ゲーム向けの整理はポリゴン削減と法線を追加します。',
    "Choose a quad rebuild operation. Auto tries a safe sequence for missing faces and N-gon cleanup.": "クアッドを再構築処理を選びます。Autoは欠損面の作成とNゴン整理に向いた安全な順序を試します。",
    "Choose the context modeling action. Auto mode tries to infer the safest operation from the active selection and falls back to face creation.": "コンテキストモデリングのアクションを選びます。Autoは現在の選択から安全な処理を推測し、失敗時は面作成に戻します。",
    "Choose the procedural asset to generate: floor tiles, brick wall, stairs, or facade strips.": "生成するプロシージャル素材を選びます。床タイル、レンガ壁、階段、ファサード帯に対応します。",
    "Choose the remesh strategy. Quadriflow is used when available; Voxel Remesh is a broadly available fallback; Shrinkwrap Only keeps existing topology.": "リメッシュ方式を選びます。利用可能ならQuadriflowを使い、汎用フォールバックとしてVoxel Remeshを使います。Shrinkwrap Onlyは既存トポロジーを保持します。",
    "Controls how much higher-frequency detail is added to the terrain. Higher values create rougher landscapes.": "地形に加える高周波ディテールの量を制御します。値を大きくすると、より荒い地形になります。",
    "Convert selected curve objects to meshes before cleanup so imported CAD splines can be welded and simplified.": "整理前に選択カーブをメッシュへ変換し、インポートしたCADスプラインを溶接・簡略化できるようにします。",
    "Cursor to Selection moves the 3D cursor. Origin to Cursor moves selected object origins. Workplane creates a helper plane at the cursor.": '「カーソルを選択へ」は 3D カーソルを、「原点をカーソルへ」は選択中のオブジェクトの原点を動かします。作業平面はカーソルの位置に補助の平面を作ります。',
    "Curve Pipe sets bevel depth on selected curves. Duplicate Source places the selected source object along the active curve control points.": "Curve Pipeは選択カーブへベベル深度を設定します。Duplicate Sourceは選択ソースをアクティブカーブの制御点に沿って配置します。",
    "Curve bevel resolution used for rounded cable cross sections. Higher values are smoother but heavier.": "丸いケーブル断面に使うカーブベベル解像度です。値を大きくすると滑らかになりますが重くなります。",
    "Displacement strength applied along selected vertex normals near the 3D cursor.": "3Dカーソル近くの選択頂点法線方向へ適用する変位量です。",
    "Distance used to weld overlapping vertices after boolean application. Increase slightly when cutters leave doubled vertices.": "ブーリアン適用後に重なった頂点を溶接する距離です。カッターにより重複頂点が残る場合は少し上げます。",
    "Drop moves selected objects down to the active target surface. Snap Origin moves objects to the active origin. Floor moves objects to world Z zero.": '落下は選択中のオブジェクトをアクティブの面へ下ろします。原点へスナップはアクティブの原点へ、床はワールドの Z=0 へ動かします。',
    "Extrusion distance used by Clean Extrude. Use a small value for panel lips and a larger value for block-out modeling.": "Clean Extrudeで使う押し出し距離です。パネル縁には小さく、ブロックアウトには大きく設定します。",
    "Falloff exponent. Higher values concentrate deformation near the cursor; lower values make a broad deformation.": "フォールオフ指数です。値を大きくするとカーソル付近に変形が集中し、小さくすると広い範囲に変形します。",
    "Falloff radius around the 3D cursor. Vertices outside this radius remain unchanged.": "3Dカーソル周囲のフォールオフ半径です。この半径の外側の頂点は変化しません。",
    "Gap between tiles, bricks, or facade pieces. Use zero for continuous geometry.": "タイル、レンガ、ファサード部品の隙間です。連続した形状にする場合はゼロにします。",
    "Grid subdivisions used to build the terrain. Higher values create smoother terrain but heavier meshes.": "地形作成に使うグリッド分割数です。値を大きくすると滑らかになりますが、メッシュは重くなります。",
    "Height above each object origin where downward raycasts begin for surface dropping.": "表面へ接地するための下向きレイキャストを、各オブジェクト原点のどれだけ上から開始するかを指定します。",
    "Hide cutter objects in the viewport after the boolean modifiers are created while keeping them available for later non-destructive editing.": "ブーリアン作成後にカッターをビューポートで非表示にします。カッター自体は残るため、後から非破壊編集できます。",
    "Inset width used by the Inset action. This creates a local border suitable for panel lines, bevel preparation, and ZModeler-like edits.": "Insetアクションで使う幅です。パネルライン、ベベル準備、ZModeler風編集に適した局所的な縁を作ります。",
    "Isolate hides unselected objects, Reveal All shows everything, and Hide Selected hides only the current selection.": "Isolateは未選択オブジェクトを隠し、Reveal Allはすべて表示し、Hide Selectedは現在の選択だけを隠します。",
    "Keep original placeholder objects after creating replacements. Disable this for a true replacement operation.": "置換作成後も元のプレースホルダーを保持します。完全に置換したい場合は無効にします。",
    "Limited dissolve angle in degrees for removing tiny planar support edges while preserving intentional corners.": "意図した角を保ちながら微小な平面補助辺を削除するための制限溶解角度です。単位は度です。",
    "Line mode projects selected vertices to a best-fit line. Axis modes align to the average coordinate on the chosen local axis.": "Lineモードは選択頂点をベストフィット線へ投影します。Axisモードは指定ローカル軸の平均座標へ揃えます。",
    "Maximum angle treated as planar during limited dissolve. Low values preserve bevels; higher values remove more support edges.": "制限溶解で平面と見なす最大角度です。低い値はベベルを保持し、高い値はより多くの補助辺を削除します。",
    "Maximum number of duplicates sampled along curve points in Duplicate Source mode.": "Duplicate Sourceモードでカーブ点に沿ってサンプリングする複製数の上限です。",
    "Maximum projection distance for closest-point projection. Increase when source geometry is far away from the target surface.": "最近接点投影で使う最大距離です。元ジオメトリが対象表面から遠い場合は上げます。",
    "Maximum random scale multiplier applied to scattered instances.": "散布インスタンスへ適用するランダムスケール倍率の最大値です。",
    "Maximum random scale multiplier.": "ランダムスケール倍率の最大値です。",
    "Maximum vertical displacement applied by the layered procedural noise.": "レイヤー化したプロシージャルノイズで適用する最大垂直変位です。",
    "Minimum random scale multiplier applied to scattered instances.": "散布インスタンスへ適用するランダムスケール倍率の最小値です。",
    "Minimum random scale multiplier.": "ランダムスケール倍率の最小値です。",
    "Number of bevel segments. One segment creates chamfers, two or more create rounded fillets.": "ベベルセグメント数です。1は面取り、2以上は丸いフィレットを作ります。",
    "Number of generated columns, tiles, bricks per row, or facade bays.": "生成する列数、タイル数、1段あたりのレンガ数、またはファサード区画数です。",
    "Number of generated rows, tile rows, brick courses, steps, or facade floors.": "生成する行数、タイル行数、レンガ段数、ステップ数、またはファサード階数です。",
    "Number of scattered instances to create across the active target surface.": "アクティブ対象表面全体へ作成する散布インスタンス数です。",
    "Number of slicing guide planes or detail repetitions.": "スライスガイド平面またはディテール反復の数です。",
    "Number of smoothing or spacing passes used by modes that support iterative cleanup. Higher values are smoother but can soften details.": "反復整理に対応するモードで使うスムージングまたは間隔調整の回数です。値を大きくすると滑らかになりますが、ディテールが弱くなる場合があります。",
    "Optional prefix applied to cleaned objects for easier scene organization.": "整理後のオブジェクトへ任意で付ける接頭辞です。シーン整理をしやすくします。",
    "Overall generated depth or thickness depending on the selected generator mode.": "選択した生成モードに応じた全体の奥行きまたは厚みです。",
    "Overall generated height for walls, stairs, and facade grids.": "壁、階段、ファサードグリッドの全体高さです。",
    "Overall generated width in Blender units.": "Blender単位での全体幅です。",
    "Overall terrain width and depth in Blender units.": "Blender単位での地形の幅と奥行きです。",
    "Pipe radius for Curve Pipe mode.": 'カーブパイプモードのパイプの半径です。',
    "Random seed for deterministic scatter placement. Change this value to generate a different distribution.": "決定的な散布配置に使うランダムシードです。値を変えると分布が変わります。",
    "Random seed for repeatable replacement and transform variation.": "再現可能な置換とトランスフォーム変化に使うランダムシードです。",
    "Random seed used by the procedural terrain noise.": "プロシージャル地形ノイズに使うランダムシードです。",
    "Replace selected placeholder objects with linked duplicates of the active object while preserving each placeholder transform.": "各プレースホルダーのトランスフォームを保ったまま、選択プレースホルダーをアクティブオブジェクトのリンク複製で置換します。",
    "Rotate each scattered instance so its local Z axis follows the sampled surface normal, useful for rocks, plants, bolts, and panel details.": "散布インスタンスのローカルZ軸をサンプリングした表面法線に合わせます。岩、植物、ボルト、パネルディテールに有効です。",
    "Scale multiplier applied to inserted kit objects after duplication.": "複製後の挿入キットオブジェクトへ適用するスケール倍率です。",
    "Select the loop operation. Circle regularizes holes, Relax evens tension, Space equalizes vertex spacing, Bridge and Loft connect loops, and Flatten projects the selection to a plane.": "ループ操作を選びます。Circleは穴を円形化し、Relaxは張力を均一化し、Spaceは頂点間隔を揃え、BridgeとLoftはループを接続し、Flattenは選択を平面へ投影します。",
    "Size of the helper plane created by Create Workplane mode.": '作業平面の作成モードで作る補助の平面のサイズです。',
    "Snap inserted kit objects to the closest point on the active mesh surface near the 3D cursor.": "挿入キットオブジェクトを、3Dカーソル近くのアクティブメッシュ表面の最近接点へスナップします。",
    "Solidify offset. Use 1 for outward, 0 for centered, and -1 for inward thickness.": "Solidifyのオフセットです。1は外側、0は中央、-1は内側へ厚みを付けます。",
    "Thickness added by the Solidify modifier. Positive values expand outward according to the selected offset setting.": "Solidifyモディファイアで追加する厚みです。正の値は選択したオフセット設定に従って広がります。",
    "Use linked object data for lower memory usage. Disable this when each scattered object needs unique mesh edits later.": "メモリ使用量を抑えるため、リンクされたオブジェクトデータを使います。各散布オブジェクトを後で個別編集する場合は無効にします。",
    "Vertical offset left above the hit surface or floor after dropping.": "接地後に、ヒットした表面または床面から残す垂直オフセットです。",
    "Voxel size for voxel remesh fallback. Smaller values preserve more detail and create heavier meshes.": "Voxel Remeshフォールバックで使うボクセルサイズです。小さい値ほどディテールを保持しますが、メッシュは重くなります。",
    "Weld distance after dissolve. Use a tiny value to remove duplicate boolean vertices without collapsing intended detail.": "溶解後の溶接距離です。意図したディテールを潰さずブーリアン重複頂点を消すには小さい値を使います。",
    "Weld threshold for converted or imported mesh objects.": "変換済みまたはインポート済みメッシュオブジェクトの溶接しきい値です。",
    "Weld threshold for duplicate vertices. Use tiny values for scans and imported CAD meshes; increase carefully for messy data.": "重複頂点の溶接しきい値です。スキャンやインポートCADには小さい値を使い、乱れたデータでは慎重に上げます。",
    "When enabled, remove loose geometry, weld doubles, dissolve near-planar edges, and recalculate normals. When disabled, only reports basic mesh counts.": "有効にすると、ルーズ形状削除、重複頂点溶接、ほぼ平面の辺の溶解、法線再計算を行います。無効時は基本的なメッシュ数だけを報告します。",
    "When running in Edit Mode on a mesh, convert selected edges into separate pipe curves before applying bevel settings.": "メッシュの編集モードで実行した場合、ベベル設定を適用する前に、選択辺を別個のパイプカーブへ変換します。",
    "When using Best Fit Line, keep vertices distributed along the full selected span instead of collapsing them to the center.": "Best Fit Line使用時に、頂点を中心へ潰さず、選択範囲全体に沿って分布を保持します。",
    "Width of the bevel modifier added after the boolean stack. Keep this low for panel cuts and increase it for mechanical fillets.": "ブーリアンスタック後に追加するベベル幅です。パネルカットには小さく、機械的フィレットには大きくします。",
    "Wire Detail adds triangulate, wireframe, and displacement modifiers. Slice Guides creates evenly spaced guide planes through the selected objects.": 'ワイヤーの細部は三角形化・ワイヤーフレーム・変位のモディファイアーを追加します。スライスのガイドは選択中のオブジェクトを横切る等間隔の平面を作ります。',
    "Wire thickness or guide plane thickness.": "ワイヤーの太さ、またはガイド平面の厚みです。",
})


# Additional translations for Blender redo panels, operator search, and enum choices.
# These strings are not drawn through _pick(), so they must be registered explicitly.
_TRANSLATIONS.update({
    "Add a Simple Deform Bend modifier to selected mesh objects.": '選択中のメッシュに曲げのシンプル変形モディファイアーを追加します。',
    "Add a shrinkwrap modifier to conform source topology to the active target.": "ソースのトポロジーをアクティブ対象に沿わせるShrinkwrapモディファイアを追加します。",
    "Add or run voxel remeshing for even all-quad-like sculpt base topology.": "均一なスカルプト用ベーストポロジーを作るため、Voxelリメッシュを追加または実行します。",
    "Add procedural wireframe and displacement detail modifiers.": "プロシージャルなワイヤーフレームと変位ディテールのモディファイアを追加します。",
    "Align and Unbend": "整列して直線化",
    "Align selected vertices to their average local X coordinate.": "選択頂点をローカルX座標の平均位置へ揃えます。",
    "Align selected vertices to their average local Y coordinate.": "選択頂点をローカルY座標の平均位置へ揃えます。",
    "Align selected vertices to their average local Z coordinate.": "選択頂点をローカルZ座標の平均位置へ揃えます。",
    "Apply and Clean Boolean": "ブーリアンを適用して整理",
    "Replace and Randomize Assets": 'アセットを置換してランダム化',
    "Auto": "自動",
    "Bend and Project": "曲げて投影",
    "Best Fit Line": "最適直線",
    "Create Bevel Normal Stack": "ベベル法線スタックを作成",
    "Bevel plus weighted normals for clean hard-surface shading.": "ハードサーフェスの陰影を整えるため、ベベルと重み付き法線を追加します。",
    "Create Boolean Fusion": "ブーリアン融合を作成",
    "Brick Wall": "レンガ壁",
    "Bridge": "ブリッジ",
    "Bridge selected edge loops when two compatible boundaries are selected.": "互換性のある2つの境界が選択されている場合、選択エッジループをブリッジします。",
    "Bridge two selected loops or boundary selections.": "選択した2つのループまたは境界選択をブリッジします。",
    "Clean CAD Import": 'CAD の読み込みを整理',
    "Create Cable Pipe": 'ケーブルパイプを作成',
    "Circle": "円形化",
    "Clean Extrude": "整理付き押し出し",
    "Convert adjacent triangles into quads where possible.": "可能な範囲で隣接する三角形を四角形へ変換します。",
    "Create Workplane": "作業平面を作成",
    "Create a named helper plane at the cursor for visual modeling reference.": "視覚的なモデリング基準として、カーソル位置に名前付きの補助平面を作成します。",
    "Create an organized quad grid across selected boundary loops.": "選択境界ループの内側に整理された四角形グリッドを作成します。",
    "Create evenly spaced slicing guide planes through selected object bounds.": "選択オブジェクトの範囲を横切る等間隔のスライスガイド平面を作成します。",
    "Create faces from selected vertices or edges, similar to F2 and grid-fill workflows.": "F2やグリッドフィルに近い流れで、選択頂点または辺から面を作成します。",
    "Cursor to Selection": "カーソルを選択へ",
    "Curve Pipe": "カーブパイプ",
    "Difference": "差分",
    "Drop and Snap": "接地してスナップ",
    "Drop selected objects vertically onto the active mesh surface.": "選択オブジェクトを垂直方向に落とし、アクティブメッシュ表面へ接地します。",
    "Drop to Active Surface": "アクティブ面へ接地",
    "Drop to Floor": "床へ接地",
    "Duplicate Source": "ソースを複製",
    "Duplicate a selected source object along the active curve points.": "選択したソースオブジェクトをアクティブカーブの点に沿って複製します。",
    "Equalize spacing along selected loops.": "選択ループに沿った頂点間隔を均一化します。",
    "Extrude the selected region and immediately merge, recalculate normals, and remove tiny overlaps.": "選択範囲を押し出し、直後にマージ、法線再計算、微小な重なり除去を行います。",
    "Facade Grid": "ファサード格子",
    "Deform with Falloff": "フォールオフで変形",
    "Fill": "面張り",
    "Fill selected boundary edges or vertices.": "選択した境界辺または頂点を面で埋めます。",
    "Flatten": "平面化",
    "Flatten selected vertices to their average local Z plane.": "選択頂点をローカルZの平均平面へ揃えて平面化します。",
    "Floor Tiles": "床タイル",
    "Generate Floor and Wall": '床と壁を生成',
    "Game Cleanup": "ゲーム向け整理",
    "Generate a brick wall from stacked box bricks with alternating offsets.": "交互にずらした箱形レンガを積み重ねてレンガ壁を生成します。",
    "Generate a simple architectural facade grid for fast concept blocking.": "素早いコンセプトブロックアウト用の簡易建築ファサード格子を生成します。",
    "Generate block-out stairs from repeated rectangular steps.": "長方形ステップの繰り返しからブロックアウト用階段を生成します。",
    "Generate individual floor or tile faces inside a rectangular area.": "矩形範囲の中に個別の床面またはタイル面を生成します。",
    "Grid Fill": "格子面張り",
    "Hard Surface Modeling": "ハードサーフェス",
    "Hide Selected": "選択を非表示",
    "Hide the selected objects only.": "現在選択しているオブジェクトだけを非表示にします。",
    "Hide unselected scene objects and keep selected objects visible.": "未選択のシーンオブジェクトを隠し、選択オブジェクトだけを表示したままにします。",
    "Infer the best action from the current selection and context.": "現在の選択状態とコンテキストから最適な操作を推定します。",
    "Inset": '差し込み',
    "Inset selected faces and keep the result editable for panel-line or CAD-like blocking.": "選択面をインセットし、パネルラインやCAD風ブロックアウト向けに編集可能な状態を保ちます。",
    "Intersect": "交差",
    "Isolate": "単独表示",
    "Keep only the overlapping volume between target and cutters.": "対象とカッターが重なっている体積だけを残します。",
    "Local X": "ローカルX",
    "Local Y": "ローカルY",
    "Local Z": "ローカルZ",
    "Shape Loops": 'ループ形状を調整',
    "Audit and Repair Mesh": "メッシュを監査して修復",
    "Mirror Array": "ミラー配列",
    "Mirror and array modifiers for symmetric repeated modeling.": "対称形状や繰り返し形状のために、ミラーと配列モディファイアを追加します。",
    "Add Modifier Stack": "モディファイアスタックを追加",
    "Move selected object origins to the current 3D cursor.": "選択オブジェクトの原点を現在の3Dカーソルへ移動します。",
    "Move selected objects so their lowest point rests on world Z zero.": "選択オブジェクトの最下点がワールドZゼロに接するように移動します。",
    "Move selected objects to the active object's origin.": "選択オブジェクトをアクティブオブジェクトの原点へ移動します。",
    "Move the 3D cursor to the center of the selected elements or objects.": "3Dカーソルを選択要素または選択オブジェクトの中心へ移動します。",
    "Origin to Cursor": "原点をカーソルへ",
    "Poke": "ポーク",
    "Poke selected faces to create radial topology for controlled cleanup.": "選択面をポークし、整理しやすい放射状トポロジーを作成します。",
    "Procedural Detail": "プロシージャルディテール",
    "Project selected object vertices to the active target mesh by closest point.": "選択オブジェクトの頂点を、最近接点でアクティブ対象メッシュへ投影します。",
    "Project selected vertices to the line between the farthest selected points.": "選択頂点を、最も離れた選択点同士を結ぶ線へ投影します。",
    "Project to Target": "対象へ投影",
    "Quadriflow": "Quadriflow",
    "Generate Rail Sweep": "レールスイープを生成",
    "Regularize the selected loop into a circular shape.": "選択ループを円形に整えます。",
    "Wrap and Remesh": "追従してリメッシュ",
    "Reveal All": "すべて表示",
    "Reveal all objects in the current view layer.": "現在のビューレイヤー内の全オブジェクトを表示します。",
    "Run Blender Quadriflow remesh when the operator is available.": '使える時は Blender の QuadriFlow リメッシュを実行します。',
    "Run a safe sequence of fill, triangle-to-quad, and cleanup operations.": "面張り、三角形から四角形への変換、整理処理を安全な順序で実行します。",
    "Shrinkwrap Only": 'シュリンクラップのみ',
    "Slice Guides": "スライスガイド",
    "Add Slice Wire Detail": 'スライスワイヤ詳細を追加',
    "Model by Context": 'コンテキストに応じて作成',
    "Smooth selected vertices while preserving the overall shape.": "全体形状を保ちながら選択頂点を滑らかにします。",
    "Snap to Active Origin": "アクティブ原点へスナップ",
    "Space": "等間隔",
    "Stairs": "階段",
    "Subtract each cutter from the active object.": "各カッターをアクティブオブジェクトから差し引きます。",
    "Terrain Generator": '地形生成',
    "Tris to Quads": "三角形を四角形へ",
    "Turn selected curve paths into editable pipes or rails.": "選択カーブパスを編集可能なパイプまたはレールへ変換します。",
    "Clean Planar Bevels": '平面ベベルを整理',
    "Union": "合成",
    "Union each cutter with the active object.": "各カッターをアクティブオブジェクトと合成します。",
    "Voxel": "ボクセル",
    "Weighted normals and decimate for lightweight game asset cleanup.": "軽量なゲームアセット整理向けに、重み付き法線とデシメートを追加します。",
    "Wire Detail": "ワイヤディテール",
    "Wireframe and displacement detail stack for BY-GEN or Trypogen-style forms.": "BY-GENやTrypogen風形状のために、ワイヤーフレームと変位ディテールのスタックを追加します。",
    "Set Workplane and Pivot": '作業平面と原点を設定',
})


def _register_translations() -> None:
    if _language is not None:
        try:
            register_map = getattr(_language, "register_translation_map", None)
            if callable(register_map):
                register_map(dict(_TRANSLATIONS))
                return
        except Exception:
            pass
    for en, ja in _TRANSLATIONS.items():
        _register_translation(en, ja)


def register():
    _register_translations()
    _load_custom_icons(force=True)
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _release_custom_icons()


if __name__ == "__main__":
    register()
