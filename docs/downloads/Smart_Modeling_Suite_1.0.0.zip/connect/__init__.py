# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Mesh Connect",
    "author": "JELararagi",
    "version": (1, 4, 2),
    "blender": (5, 0, 0),
    "location": "View3D > Edit Mode",
    "description": "Automatically switches between vertex connect and subdivide depending on the current selection mode.",
    "category": "Mesh",
}

import bpy
from ..bootstrap_common import (
    class_is_owned_for_mutation as _connect_owned_class,
    safe_unregister_class as _connect_exact_safe_unregister_class,
)
import bmesh
import gpu
import math
from gpu_extras.batch import batch_for_shader
from bpy.props import BoolProperty, IntProperty, PointerProperty, EnumProperty

try:
    from ..edit_multi import edit_mesh_objects as _sms_edit_mesh_objects
except Exception:
    _sms_edit_mesh_objects = None

try:
    from .. import flow_algorithms as _sms_flow
except Exception:
    _sms_flow = None


_SCENE_SETTINGS_PROP = "sms_smart_connect_settings"
_CONNECT_DIALOG_WIDTH = 360
_POSITION_EPSILON = 1.0e-4

_SEGMENTS_NAME = "Segments"
_SEGMENTS_DESCRIPTION = (
    "Sets the number of new connecting edge loops created across the selected edge ring. "
    "The default is 1; increase this value to insert multiple evenly distributed edge loops."
)
_PINCH_NAME = "Pinch"
_PINCH_DESCRIPTION = (
    "Adjusts the spacing between newly created edges when Segments is 2 or higher. "
    "Negative values pull the new edges toward the center, while positive values push them outward toward the original vertices."
)
_SLIDE_NAME = "Slide"
_SLIDE_DESCRIPTION = (
    "Offsets the entire set of newly created edges along the original selected edges. "
    "Use negative or positive values to bias the cut positions toward either side of the original edge."
)
_SHOW_POPUP_NAME = "Show Popup"
_SHOW_POPUP_DESCRIPTION = (
    "When enabled, invoking Mesh Connect in edge selection mode opens the Connect popup before applying edge subdivision. "
    "Disable this to run immediately with the current Segments, Pinch, Slide, and connection type values stored in this scene."
)
_CONNECT_ALGORITHM_NORMAL = 'NORMAL'
_CONNECT_ALGORITHM_FLOW = 'FLOW'
_CONNECT_ALGORITHM_NAME = "Connection Type"
_CONNECT_ALGORITHM_DESCRIPTION = (
    "Switches the edge-mode Mesh Connect algorithm. Normal Connect creates straight subdivision connections. "
    "Flow Connect first applies Segments, Pinch, and Slide, then smooths the generated vertices along the surrounding edge flow."
)
_NORMAL_CONNECT_NAME = "Normal Connect"
_NORMAL_CONNECT_DESCRIPTION = (
    "Creates the connection with the standard Mesh Connect subdivision algorithm while preserving the current Segments, Pinch, and Slide values."
)
_FLOW_CONNECT_NAME = "Flow Connect"
_FLOW_CONNECT_DESCRIPTION = (
    "Creates the connection with the current Segments, Pinch, and Slide values, then adjusts the generated vertices to follow the surrounding edge flow."
)
_FLOW_ALGORITHM_CURRENT = getattr(_sms_flow, 'FLOW_ALGORITHM_CURRENT', 'CURRENT') if _sms_flow is not None else 'CURRENT'
_FLOW_ALGORITHM_MAX = getattr(_sms_flow, 'FLOW_ALGORITHM_MAX', 'MAX_3DS') if _sms_flow is not None else 'MAX_3DS'
_FLOW_ALGORITHM_EDGEFLOW = getattr(_sms_flow, 'FLOW_ALGORITHM_EDGEFLOW', 'EDGEFLOW') if _sms_flow is not None else 'EDGEFLOW'
_FLOW_ALGORITHM_NAME = "Flow Algorithm"
_FLOW_ALGORITHM_DESCRIPTION = (
    "Chooses the curvature fitting algorithm used after Flow Connect creates the new edges. "
    "Current Flow keeps the existing Smart Modeling smoothing, 3ds Max Flow uses a stronger surface-fit curve based on outer neighbours, "
    "and EdgeFlow uses the bundled EdgeFlow 1.1.2-style local Hermite flow calculation."
)
_CURRENT_FLOW_NAME = "Current Flow"
_CURRENT_FLOW_DESCRIPTION = (
    "Keeps the existing Smart Modeling Flow Connect algorithm. It preserves Segments, Pinch, and Slide positions, then smooths the generated vertices between stable neighbouring topology."
)
_MAX_FLOW_NAME = "3ds Max Flow"
_MAX_FLOW_DESCRIPTION = (
    "Uses a 3ds Max-style Flow Connect fit. It preserves Segments, Pinch, and Slide positions, then rebuilds the generated vertices with outer neighbouring vertices as curve controls."
)
_EDGEFLOW_FLOW_NAME = "EdgeFlow"
_EDGEFLOW_FLOW_DESCRIPTION = (
    "Uses the bundled EdgeFlow 1.1.2-style local Hermite flow calculation. It preserves Segments, Pinch, and Slide positions while matching neighbouring quad-loop curvature more aggressively."
)
_APPLY_CONTINUE_DESCRIPTION = (
    "Legacy Mesh Connect apply action. It applies the current Segments, Pinch, and Slide values and closes the popup."
)
_SMART_CONNECT_OPERATOR_DESCRIPTION = (
    "Connects selected vertices in vertex mode. In edge mode, it opens the Mesh Connect popup when enabled or directly subdivides selected edges using the current connection type plus Segments, Pinch, and Slide settings. In face mode, it runs Blender's native Subdivide."
)

translation_dict = {
    "ja_JP": {
        ("*", "Mesh Connect"): "メッシュ接続",
        ("*", "Automatically switches between vertex connect and subdivide depending on the current selection mode."):
            "現在の選択モードに応じて、頂点接続と細分化を自動で切り替えます。",
        ("*", "Run Connect in vertex mode and Subdivide in edge/face mode"):
            '頂点モードでは接続、辺/面モードでは細分化を実行',
        ("*", "Run Connect in vertex mode, open the Mesh Connect popup in edge mode when enabled, and Subdivide in face mode"):
            "頂点モードでは接続、辺モードでは設定に応じてメッシュ接続ポップアップまたは細分化、面モードでは細分化を実行します。",
        ("*", _SMART_CONNECT_OPERATOR_DESCRIPTION):
            "頂点選択モードでは、同じ面上で選択した頂点同士を接続します。辺選択モードでは、設定に応じてメッシュ接続ポップアップを開くか、現在の接続方式、セグメント、ピンチ、スライド設定で選択エッジを直接細分化します。面選択モードでは、Blender標準の細分化を実行します。",
        ("*", "Selected vertices do not share a face. Select vertices on the same face."):
            "選択頂点が同じ面を共有していません。同じ面上の頂点を選択してください。",
        ("*", _SEGMENTS_NAME): "セグメント",
        ("*", _SEGMENTS_DESCRIPTION):
            "選択したエッジリングに対して新しく作成する接続エッジループの本数を設定します。デフォルトは1です。値を増やすと、複数のエッジループを等間隔で挿入できます。",
        ("*", _PINCH_NAME): "ピンチ",
        ("*", _PINCH_DESCRIPTION):
            "セグメントが2以上のとき、新しく作成されるエッジ同士の間隔を調整します。マイナス値では中央へ寄せ、プラス値では元の頂点側へ外向きに広げます。",
        ("*", _SLIDE_NAME): "スライド",
        ("*", _SLIDE_DESCRIPTION):
            "新しく作成されるエッジ全体を、元の選択エッジに沿ってオフセットします。マイナス値またはプラス値で、分割位置を元のエッジのどちらか一方へ偏らせます。",
        ("*", _SHOW_POPUP_NAME): "ポップアップを表示",
        ("*", _SHOW_POPUP_DESCRIPTION):
            "有効にすると、辺選択モードでメッシュ接続を実行したときに、細分化を適用する前に接続ポップアップを表示します。無効にすると、このシーンに保存されている接続方式、セグメント、ピンチ、スライドの現在値で即時実行します。",
        ("*", _CONNECT_ALGORITHM_NAME): "接続方式",
        ("*", _CONNECT_ALGORITHM_DESCRIPTION):
            "辺選択モードのメッシュ接続アルゴリズムを切り替えます。通常接続は直線的な細分化接続を作成します。フロー接続はセグメント、ピンチ、スライドを適用した後、生成された頂点を周囲のエッジフローに沿って滑らかに補正します。",
        ("*", _NORMAL_CONNECT_NAME): "通常接続",
        ("*", _NORMAL_CONNECT_DESCRIPTION):
            "現在のセグメント、ピンチ、スライド値を保持したまま、標準のメッシュ接続細分化アルゴリズムで接続を作成します。",
        ("*", _FLOW_CONNECT_NAME): "フロー接続",
        ("*", _FLOW_CONNECT_DESCRIPTION):
            "現在のセグメント、ピンチ、スライド値で接続を作成した後、生成された頂点を周囲のエッジフローに沿うように補正します。",
        ("*", _FLOW_ALGORITHM_NAME): "フローアルゴリズム",
        ("*", _FLOW_ALGORITHM_DESCRIPTION):
            "フロー接続で新しい辺を作成した後に使用する曲率フィットアルゴリズムを選択します。現在のフローは既存のSmart Modeling補正、3ds Maxフローは外側の隣接頂点を使った強めのサーフェスフィット、EdgeFlowは同梱EdgeFlow 1.1.2系のローカルHermiteフロー計算を使用します。",
        ("*", _CURRENT_FLOW_NAME): "現在のフロー",
        ("*", _CURRENT_FLOW_DESCRIPTION):
            "既存のSmart Modelingフロー接続アルゴリズムを使用します。セグメント、ピンチ、スライド位置を保持し、その後、安定した隣接トポロジーの間で生成頂点を滑らかに補正します。",
        ("*", _MAX_FLOW_NAME): "3ds Maxフロー",
        ("*", _MAX_FLOW_DESCRIPTION):
            "3ds Max風のフロー接続フィットを使用します。セグメント、ピンチ、スライド位置を保持し、外側の隣接頂点を曲線制御点として生成頂点を再配置します。",
        ("*", _EDGEFLOW_FLOW_NAME): "EdgeFlow",
        ("*", _EDGEFLOW_FLOW_DESCRIPTION):
            "同梱EdgeFlow 1.1.2系のローカルHermiteフロー計算を使用します。セグメント、ピンチ、スライド位置を保持しながら、隣接する四角形ループの曲率へより積極的に合わせます。",
        ("*", _APPLY_CONTINUE_DESCRIPTION):
            "現在のセグメント、ピンチ、スライドの値でメッシュ接続を適用し、ポップアップを閉じます。",
        ("*", "Apply"): "適用",
        ("*", "Apply the current Mesh Connect settings and close the popup."):
            '今のメッシュ接続の設定を適用して画面を閉じます。',
        ("*", "Cancel"): "キャンセル",
        ("*", "Close the Mesh Connect popup without applying changes."):
            '変更を適用せずにメッシュ接続の画面を閉じます。',
        ("*", "Mesh Connect Settings"): 'メッシュ接続の設定',
        ("*", "Scene-local settings for Mesh Connect. Values are kept while the scene remains open and are used by the popup and direct execution mode."):
            'メッシュ接続のシーンごとの設定です。シーンを開いている間は値を保ち、画面と直接の実行に使います。',
    }
}


def _feature_enabled(context=None):
    try:
        from ..utils import feature_enabled
        return feature_enabled(context or bpy.context, 'enable_connect', True)
    except Exception:
        return True


def _report_message(report_cb, levels, message):
    if not callable(report_cb):
        return
    try:
        translated = bpy.app.translations.pgettext(str(message or ''))
    except Exception:
        translated = str(message or '')
    try:
        report_cb(set(levels or {'INFO'}), translated)
    except Exception:
        try:
            report_cb(levels or {'INFO'}, translated)
        except Exception:
            pass


def _round_value(value):
    try:
        return round(float(value), 8)
    except Exception:
        return 0.0


def _clamp(value, minimum, maximum):
    try:
        value = float(value)
    except Exception:
        value = float(minimum)
    return max(float(minimum), min(float(maximum), value))


def _clamp_int(value, minimum, maximum):
    try:
        value = int(round(float(value)))
    except Exception:
        value = int(minimum)
    return max(int(minimum), min(int(maximum), value))


_CONNECT_ALGORITHM_ITEMS = (
    (_CONNECT_ALGORITHM_NORMAL, _NORMAL_CONNECT_NAME, _NORMAL_CONNECT_DESCRIPTION),
    (_CONNECT_ALGORITHM_FLOW, _FLOW_CONNECT_NAME, _FLOW_CONNECT_DESCRIPTION),
)

_FLOW_ALGORITHM_ITEMS = (
    (_FLOW_ALGORITHM_CURRENT, _CURRENT_FLOW_NAME, _CURRENT_FLOW_DESCRIPTION),
    (_FLOW_ALGORITHM_MAX, _MAX_FLOW_NAME, _MAX_FLOW_DESCRIPTION),
    (_FLOW_ALGORITHM_EDGEFLOW, _EDGEFLOW_FLOW_NAME, _EDGEFLOW_FLOW_DESCRIPTION),
)


def _normalize_flow_algorithm(value):
    if _sms_flow is not None:
        try:
            return _sms_flow.normalize_flow_algorithm(value)
        except Exception:
            pass
    try:
        value = str(value or '').upper()
    except Exception:
        value = ''
    if value in {_FLOW_ALGORITHM_MAX, 'MAX', '3DSMAX', '3DS_MAX'}:
        return _FLOW_ALGORITHM_MAX
    if value in {_FLOW_ALGORITHM_EDGEFLOW, 'EDGE_FLOW'}:
        return _FLOW_ALGORITHM_EDGEFLOW
    return _FLOW_ALGORITHM_CURRENT


def _normalize_connect_algorithm(value):
    try:
        value = str(value or '').upper()
    except Exception:
        value = ''
    if value == _CONNECT_ALGORITHM_FLOW:
        return _CONNECT_ALGORITHM_FLOW
    return _CONNECT_ALGORITHM_NORMAL


def _vec_key(vec):
    return (
        _round_value(getattr(vec, 'x', 0.0)),
        _round_value(getattr(vec, 'y', 0.0)),
        _round_value(getattr(vec, 'z', 0.0)),
    )


def _edge_signature(edge):
    try:
        a = _vec_key(edge.verts[0].co)
        b = _vec_key(edge.verts[1].co)
    except Exception:
        return None
    return tuple(sorted((a, b)))


def _vec_tuple(vec):
    return (
        float(getattr(vec, 'x', 0.0)),
        float(getattr(vec, 'y', 0.0)),
        float(getattr(vec, 'z', 0.0)),
    )


def _vec_sub(a, b):
    return (
        float(a[0]) - float(b[0]),
        float(a[1]) - float(b[1]),
        float(a[2]) - float(b[2]),
    )


def _vec_dot(a, b):
    return (
        float(a[0]) * float(b[0]) +
        float(a[1]) * float(b[1]) +
        float(a[2]) * float(b[2])
    )


def _vec_len_sq(vec):
    return _vec_dot(vec, vec)


def _vec_lerp(start, end, factor):
    factor = float(factor)
    return (
        float(start[0]) + (float(end[0]) - float(start[0])) * factor,
        float(start[1]) + (float(end[1]) - float(start[1])) * factor,
        float(start[2]) + (float(end[2]) - float(start[2])) * factor,
    )


def _segment_factor(point, start, end):
    segment = _vec_sub(end, start)
    segment_len_sq = _vec_len_sq(segment)
    if segment_len_sq <= 1.0e-12:
        return 0.0
    offset = _vec_sub(point, start)
    return _vec_dot(offset, segment) / segment_len_sq


def _point_on_segment(point, start, end, *, tol=1.0e-6):
    factor = _segment_factor(point, start, end)
    if factor < (-tol) or factor > (1.0 + tol):
        return False

    closest = _vec_lerp(start, end, factor)
    delta = _vec_sub(point, closest)
    return _vec_len_sq(delta) <= (tol * tol)


def _edge_lies_on_segment(edge, segment, *, tol=1.0e-6):
    try:
        start, end = segment
        point_a = _vec_tuple(edge.verts[0].co)
        point_b = _vec_tuple(edge.verts[1].co)
    except Exception:
        return False
    return _point_on_segment(point_a, start, end, tol=tol) and _point_on_segment(point_b, start, end, tol=tol)


def _edge_pair_shares_vertex(edge_a, edge_b):
    try:
        return bool(set(edge_a.verts).intersection(edge_b.verts))
    except Exception:
        return False


def _vec_dist_sq(a, b):
    return _vec_len_sq(_vec_sub(a, b))


def _edge_base_segment(edge):
    try:
        return (_vec_tuple(edge.verts[0].co), _vec_tuple(edge.verts[1].co))
    except Exception:
        return None


def _edge_safe_for_subdivide(edge):
    """Reject malformed/degenerate selected edges before entering native BMesh."""
    try:
        if edge is None or not edge.is_valid or edge.hide or len(edge.verts) != 2:
            return False
        coords = tuple(float(value) for vert in edge.verts for value in vert.co)
        if not all(math.isfinite(value) for value in coords):
            return False
        return float((edge.verts[1].co - edge.verts[0].co).length_squared) > 1.0e-20
    except Exception:
        return False


def _reverse_segment(segment):
    try:
        return (segment[1], segment[0])
    except Exception:
        return segment


def _edge_face_loop_reversed(edge, face):
    """Return whether BMEdge native order is reversed against this face loop."""
    try:
        for loop in getattr(face, 'loops', ()):  # face loop order is the topology reference
            if getattr(loop, 'edge', None) is edge:
                start = getattr(loop, 'vert', None)
                end = getattr(getattr(loop, 'link_loop_next', None), 'vert', None)
                if start is None or end is None:
                    return None
                try:
                    return not (edge.verts[0] is start and edge.verts[1] is end)
                except Exception:
                    return None
    except Exception:
        return None
    return None


def _edge_pair_orientation_relation(edge_a, edge_b, face=None):
    """Return whether edge_b should be reversed relative to edge_a.

    For a face with two selected ring edges, the face-loop order is the most
    stable reference.  Distance-only endpoint pairing can become ambiguous at a
    closed ring seam, which caused one generated Mesh Connect line to receive
    the opposite Slide offset.  The loop-order relation is used first; geometric
    distance is kept only as a fallback for nonstandard topology.
    """
    try:
        if face is not None and not _edge_pair_shares_vertex(edge_a, edge_b):
            rev_a = _edge_face_loop_reversed(edge_a, face)
            rev_b = _edge_face_loop_reversed(edge_b, face)
            if rev_a is not None and rev_b is not None:
                # Opposite edges in one face point in opposite directions when
                # both are read in face-loop order.  If their native order has
                # the same loop-reversal state, edge_b must be reversed relative
                # to edge_a so Slide positions match the same side of the face.
                return 1 if not (bool(rev_a) ^ bool(rev_b)) else 0
    except Exception:
        pass

    seg_a = _edge_base_segment(edge_a)
    seg_b = _edge_base_segment(edge_b)
    if seg_a is None or seg_b is None:
        return 0
    a0, a1 = seg_a
    b0, b1 = seg_b
    try:
        same_order = _vec_dist_sq(a0, b0) + _vec_dist_sq(a1, b1)
        swapped_order = _vec_dist_sq(a0, b1) + _vec_dist_sq(a1, b0)
        return 1 if swapped_order < same_order else 0
    except Exception:
        return 0


def _selected_connect_edges(bm, selected_edges=None):
    """Return a deterministic tuple of valid selected edges."""
    if selected_edges is None:
        source = tuple(getattr(bm, 'edges', ()))
    else:
        source = tuple(selected_edges)
    result = []
    seen = set()
    for edge in source:
        try:
            marker = id(edge)
            if marker in seen or not edge.is_valid or edge.hide or not edge.select:
                continue
        except Exception:
            continue
        seen.add(marker)
        result.append(edge)
    try:
        result.sort(key=lambda edge: (int(edge.index), id(edge)))
    except Exception:
        pass
    return tuple(result)


def _selected_edge_face_pairs(selected_edges):
    """Collect each relevant face once without scanning the complete BMesh."""
    selected_edges = tuple(selected_edges or ())
    selected_ids = {id(edge) for edge in selected_edges}
    pairs = []
    seen_faces = set()
    for edge in selected_edges:
        try:
            linked_faces = tuple(edge.link_faces)
        except Exception:
            linked_faces = ()
        for face in linked_faces:
            try:
                marker = id(face)
                if marker in seen_faces or not face.is_valid or face.hide:
                    continue
                seen_faces.add(marker)
                selected = [
                    candidate for candidate in face.edges
                    if id(candidate) in selected_ids
                    and candidate.is_valid
                    and not candidate.hide
                ]
            except Exception:
                continue
            if len(selected) == 2:
                pairs.append((face, selected[0], selected[1]))
    try:
        pairs.sort(key=lambda item: (int(item[0].index), id(item[0])))
    except Exception:
        pass
    return tuple(pairs)


def _selected_edge_orientation_bits(bm, selected_edges=None):
    """Build one coherent direction for every selected ring edge.

    Only faces linked to the selected edges are visited.  This keeps the common
    ring path O(selected edges + linked faces), instead of scanning all faces in
    a dense edit mesh for every popup refresh or Connect execution.
    """
    try:
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    selected_edges = _selected_connect_edges(bm, selected_edges)
    graph = {edge: [] for edge in selected_edges}
    for face, edge_a, edge_b in _selected_edge_face_pairs(selected_edges):
        relation = bool(_edge_pair_orientation_relation(edge_a, edge_b, face))
        graph[edge_a].append((edge_b, relation))
        graph[edge_b].append((edge_a, relation))

    bits = {}
    for root in selected_edges:
        if root in bits:
            continue
        bits[root] = False
        stack = [root]
        while stack:
            edge = stack.pop()
            bit = bool(bits.get(edge, False))
            neighbours = graph.get(edge, ())
            try:
                neighbours = sorted(neighbours, key=lambda item: (int(item[0].index), id(item[0])))
            except Exception:
                pass
            for other, relation in neighbours:
                wanted = bool(bit ^ bool(relation))
                if other not in bits:
                    bits[other] = wanted
                    stack.append(other)
                # On malformed/non-manifold topology keep the first coherent
                # path.  Valid quad rings have no parity conflict, including the
                # closing face, so every edge receives the same Pinch/Slide axis.
    return bits


def _oriented_segment_for_edge(edge, orientation_bits):
    segment = _edge_base_segment(edge)
    if segment is None:
        return None
    try:
        if bool(orientation_bits.get(edge, False)):
            return _reverse_segment(segment)
    except Exception:
        pass
    return segment


def _selected_ring_segments_and_pairs(bm, selected_edges=None, orientation_bits=None):
    """Return consistently oriented selected edge segments and face pairs."""
    selected_edges = _selected_connect_edges(bm, selected_edges)
    if orientation_bits is None:
        orientation_bits = _selected_edge_orientation_bits(bm, selected_edges)
    segments = []
    pairs = []

    for edge in selected_edges:
        segment = _oriented_segment_for_edge(edge, orientation_bits)
        if segment is not None:
            segments.append(segment)

    for _face, edge_a, edge_b in _selected_edge_face_pairs(selected_edges):
        segment_a = _oriented_segment_for_edge(edge_a, orientation_bits)
        segment_b = _oriented_segment_for_edge(edge_b, orientation_bits)
        if segment_a is None or segment_b is None:
            continue
        pairs.append((segment_a, segment_b, not _edge_pair_shares_vertex(edge_a, edge_b)))
    return segments, pairs


def _selected_face_edge_pairs(bm):
    """Compatibility wrapper for older internal callers."""
    try:
        _segments, pairs = _selected_ring_segments_and_pairs(bm)
        return pairs
    except Exception:
        return []


def _uv_layer_names(bm):
    try:
        return tuple(layer.name for layer in bm.loops.layers.uv)
    except Exception:
        return ()


def _loop_uv_for_vert(face, vert, uv_layer):
    try:
        for loop in face.loops:
            if getattr(loop, 'vert', None) is vert:
                uv = loop[uv_layer].uv
                return (float(uv.x), float(uv.y))
    except Exception:
        pass
    return None


def _uv_lerp(start_uv, end_uv, factor):
    factor = float(factor)
    return (
        float(start_uv[0]) + (float(end_uv[0]) - float(start_uv[0])) * factor,
        float(start_uv[1]) + (float(end_uv[1]) - float(start_uv[1])) * factor,
    )


def _capture_selected_edge_uv_data(bm, *, selected_edges=None, orientation_bits=None, source_ids=None):
    """Capture UV endpoint data on selected edges before native subdivision.

    Mesh Connect uses Blender's native Subdivide to create the topology, then
    moves the new cut vertices to the requested Pinch / Slide positions.  Loop
    UVs are independent from vertex coordinates, so they must be recalculated
    from the original per-face UV endpoints after those vertices are moved.
    Keeping the calculation per linked face preserves UV seams and separate UV
    islands instead of averaging both sides of an edge.
    """
    data = []
    try:
        if not _uv_layer_names(bm):
            return data
        selected_edges = _selected_connect_edges(bm, selected_edges)
        if orientation_bits is None:
            orientation_bits = _selected_edge_orientation_bits(bm, selected_edges)
        uv_layers = list(bm.loops.layers.uv)
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        return data

    for edge in selected_edges:
        try:
            segment = _oriented_segment_for_edge(edge, orientation_bits)
            if segment is None:
                continue
            start, end = segment
            edge_v0, edge_v1 = edge.verts[0], edge.verts[1]
            start_is_v0 = (_vec_dist_sq(_vec_tuple(edge_v0.co), start) <= _vec_dist_sq(_vec_tuple(edge_v1.co), start))
            start_vert = edge_v0 if start_is_v0 else edge_v1
            end_vert = edge_v1 if start_is_v0 else edge_v0
            sources = []
            for face in list(getattr(edge, 'link_faces', ())):
                try:
                    if face is None or not face.is_valid or face.hide:
                        continue
                    layer_pairs = {}
                    for layer in uv_layers:
                        start_uv = _loop_uv_for_vert(face, start_vert, layer)
                        end_uv = _loop_uv_for_vert(face, end_vert, layer)
                        if start_uv is not None and end_uv is not None:
                            layer_pairs[layer.name] = (start_uv, end_uv)
                    if layer_pairs:
                        sources.append({
                            'center': _vec_tuple(face.calc_center_median()),
                            'normal': _vec_tuple(face.normal),
                            'layers': layer_pairs,
                        })
                except Exception:
                    continue
            if sources:
                source_id = 0
                if source_ids:
                    try:
                        source_id = int(source_ids.get(edge, 0) or 0)
                    except Exception:
                        source_id = 0
                data.append({'source_id': source_id, 'segment': segment, 'sources': sources})
        except Exception:
            continue
    return data


def _choose_uv_source_for_loop(loop, sources):
    if not sources:
        return None
    try:
        face = loop.face
        center = _vec_tuple(face.calc_center_median())
        normal = _vec_tuple(face.normal)
    except Exception:
        return sources[0]

    best = None
    best_score = None
    for source in sources:
        try:
            center_score = _vec_dist_sq(center, source.get('center', center))
            normal_score = 1.0 - abs(_vec_dot(normal, source.get('normal', normal)))
            score = center_score + normal_score
        except Exception:
            score = 0.0
        if best is None or score < best_score:
            best = source
            best_score = score
    return best


def _restore_subdivision_uvs_after_positioning(
    bm,
    uv_data,
    before_vertex_keys,
    target_positions,
    candidate_verts=None,
    source_vertex_groups=None,
):
    if not uv_data or not target_positions:
        return 0
    try:
        uv_layers = {layer.name: layer for layer in bm.loops.layers.uv}
    except Exception:
        return 0
    if not uv_layers:
        return 0

    restored = 0
    try:
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    try:
        vertex_pool = tuple(
            vert for vert in tuple(candidate_verts or ())
            if vert is not None and vert.is_valid and not vert.hide
        )
    except Exception:
        vertex_pool = ()
    if not vertex_pool:
        vertex_pool = tuple(getattr(bm, 'verts', ()))

    for item in uv_data:
        try:
            segment = item.get('segment')
            sources = item.get('sources') or ()
            start, end = segment
        except Exception:
            continue
        item_vertex_pool = vertex_pool
        source_id = int(item.get('source_id', 0) or 0)
        if source_id > 0 and source_vertex_groups:
            try:
                item_vertex_pool = tuple(source_vertex_groups.get(source_id, ()))
            except Exception:
                item_vertex_pool = ()
        for vert in item_vertex_pool:
            try:
                if not vert.is_valid or vert.hide:
                    continue
                if _vec_key(vert.co) in before_vertex_keys:
                    continue
                point = _vec_tuple(vert.co)
                if not _point_on_segment(point, start, end, tol=1.0e-5):
                    continue
                factor = _clamp(_segment_factor(point, start, end), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
            except Exception:
                continue
            for loop in list(getattr(vert, 'link_loops', ())):
                source = _choose_uv_source_for_loop(loop, sources)
                if not source:
                    continue
                for layer_name, pair in (source.get('layers') or {}).items():
                    layer = uv_layers.get(layer_name)
                    if layer is None:
                        continue
                    try:
                        uv = _uv_lerp(pair[0], pair[1], factor)
                        loop[layer].uv.x = uv[0]
                        loop[layer].uv.y = uv[1]
                        restored += 1
                    except Exception:
                        continue
    return restored

def _find_cut_vertices_on_segment(bm, segment, before_vertex_keys, target_positions, *, tol=1.0e-5):
    try:
        start, end = segment
    except Exception:
        return {}
    result = {}
    for vert in list(getattr(bm, 'verts', ())):
        try:
            if not vert.is_valid or vert.hide:
                continue
            co = _vec_tuple(vert.co)
            if _vec_key(vert.co) in before_vertex_keys:
                continue
            if not _point_on_segment(co, start, end, tol=tol):
                continue
            factor = _segment_factor(co, start, end)
        except Exception:
            continue
        for target in target_positions:
            try:
                key = _round_value(target)
                distance = abs(float(factor) - float(target))
            except Exception:
                continue
            if distance > max(tol * 10.0, 1.0e-4):
                continue
            current = result.get(key)
            if current is None:
                result[key] = (distance, vert)
            elif distance < current[0]:
                result[key] = (distance, vert)
    return {key: item[1] for key, item in result.items()}


def _ensure_edge_between_vertices(bm, vert_a, vert_b):
    if vert_a is None or vert_b is None or vert_a is vert_b:
        return None
    try:
        if not vert_a.is_valid or not vert_b.is_valid:
            return None
    except Exception:
        return None
    try:
        existing = bm.edges.get((vert_a, vert_b))
        if existing is not None and existing.is_valid:
            return existing
    except Exception:
        pass
    # Prefer connect_verts so a shared face is split correctly instead of only
    # creating a loose edge inside the face.
    try:
        result = bmesh.ops.connect_verts(bm, verts=[vert_a, vert_b], check_degenerate=True)
        geom = list(result.get('edges', []) or result.get('geom', []) or [])
        for elem in geom:
            if isinstance(elem, bmesh.types.BMEdge) and elem.is_valid:
                try:
                    if set(elem.verts) == {vert_a, vert_b}:
                        return elem
                except Exception:
                    return elem
        existing = bm.edges.get((vert_a, vert_b))
        if existing is not None and existing.is_valid:
            return existing
    except Exception:
        pass
    try:
        edge = bm.edges.new((vert_a, vert_b))
        return edge if edge.is_valid else None
    except Exception:
        return None


def _edge_exists_between_vertices(bm, vert_a, vert_b):
    if vert_a is None or vert_b is None or vert_a is vert_b:
        return False
    try:
        edge = bm.edges.get((vert_a, vert_b))
        return bool(edge is not None and edge.is_valid)
    except Exception:
        return False


def _target_complement_positions(target_positions):
    result = []
    seen = set()
    for target in target_positions or ():
        try:
            value = _clamp(1.0 - float(target), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
            key = _round_value(value)
        except Exception:
            continue
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return tuple(result)


def _move_cut_vertex_to_factor(vert, segment, factor):
    try:
        if vert is None or not vert.is_valid:
            return False
        start, end = segment
        factor = _clamp(float(factor), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
        co = _vec_lerp(start, end, factor)
        vert.co.x = co[0]
        vert.co.y = co[1]
        vert.co.z = co[2]
        return True
    except Exception:
        return False


def _dissolve_generated_edge(bm, edge, before_vertex_keys):
    try:
        if edge is None or not edge.is_valid:
            return False
        if any(_vec_key(vert.co) in before_vertex_keys for vert in edge.verts):
            return False
        bmesh.ops.dissolve_edges(bm, edges=[edge], use_verts=False, use_face_split=False)
        return True
    except Exception:
        try:
            if edge is not None and edge.is_valid:
                edge.select_set(False)
        except Exception:
            pass
        return False


def _ensure_closed_ring_connect_edges(bm, face_edge_pairs, before_vertex_keys, target_positions):
    """Verify and repair connect edges for cyclic selected edge rings.

    The repair now handles two separate closed-ring failure modes:

    * missing closing connect edges;
    * a minority of connect edges using the opposite Slide side.

    Existing generated edges are counted first.  The side with more generated
    connect edges is treated as the correct side.  Minority-side edges are
    dissolved when safe, missing vertices are moved to the majority factor, and
    all expected connect edges are recreated.
    """
    ensured = []
    if not face_edge_pairs or not target_positions:
        return ensured
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    complement_positions = _target_complement_positions(target_positions)
    pair_cache = []
    same_count = 0
    reversed_count = 0

    for segment_a, segment_b, _opposite in face_edge_pairs:
        verts_a = _find_cut_vertices_on_segment(bm, segment_a, before_vertex_keys, target_positions)
        verts_a_reversed = _find_cut_vertices_on_segment(bm, segment_a, before_vertex_keys, complement_positions)
        verts_b = _find_cut_vertices_on_segment(bm, segment_b, before_vertex_keys, target_positions)
        verts_b_reversed = _find_cut_vertices_on_segment(bm, segment_b, before_vertex_keys, complement_positions)
        if (not verts_a and not verts_a_reversed) or (not verts_b and not verts_b_reversed):
            continue
        pair_cache.append((segment_a, segment_b, verts_a, verts_a_reversed, verts_b, verts_b_reversed))
        for target in target_positions:
            key = _round_value(target)
            reverse_factor = _clamp(1.0 - float(target), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
            reverse_key = _round_value(reverse_factor)
            vert_a = verts_a.get(key) or verts_a_reversed.get(reverse_key)
            if _edge_exists_between_vertices(bm, vert_a, verts_b.get(key)):
                same_count += 1
            if _edge_exists_between_vertices(bm, vert_a, verts_b_reversed.get(reverse_key)):
                reversed_count += 1

    use_reversed_majority = bool(reversed_count > same_count and reversed_count > 0)

    for segment_a, segment_b, verts_a, verts_a_reversed, verts_b, verts_b_reversed in pair_cache:
        for target in target_positions:
            key = _round_value(target)
            target_factor = _clamp(float(target), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
            reverse_factor = _clamp(1.0 - float(target), _POSITION_EPSILON, 1.0 - _POSITION_EPSILON)
            reverse_key = _round_value(reverse_factor)

            vert_a = verts_a.get(key)
            if vert_a is None:
                alt_a = verts_a_reversed.get(reverse_key)
                if alt_a is not None and _move_cut_vertex_to_factor(alt_a, segment_a, target_factor):
                    vert_a = alt_a
                    verts_a[key] = alt_a
                    verts_a_reversed.pop(reverse_key, None)
            if vert_a is None:
                continue

            if use_reversed_majority:
                desired_b = verts_b_reversed.get(reverse_key)
                wrong_b = verts_b.get(key)
                desired_factor_b = reverse_factor
            else:
                desired_b = verts_b.get(key)
                wrong_b = verts_b_reversed.get(reverse_key)
                desired_factor_b = target_factor

            if desired_b is None and wrong_b is not None:
                if _move_cut_vertex_to_factor(wrong_b, segment_b, desired_factor_b):
                    desired_b = wrong_b
                    if use_reversed_majority:
                        verts_b_reversed[reverse_key] = wrong_b
                        verts_b.pop(key, None)
                    else:
                        verts_b[key] = wrong_b
                        verts_b_reversed.pop(reverse_key, None)
                    wrong_b = None

            if desired_b is None:
                desired_b = (verts_b.get(key) if not use_reversed_majority else verts_b_reversed.get(reverse_key))
            if desired_b is None:
                continue

            # Remove the minority-side generated connection if it still exists.
            if wrong_b is not None and wrong_b is not desired_b:
                try:
                    wrong_edge = bm.edges.get((vert_a, wrong_b))
                except Exception:
                    wrong_edge = None
                if wrong_edge is not None and wrong_edge.is_valid:
                    _dissolve_generated_edge(bm, wrong_edge, before_vertex_keys)
                    try:
                        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                    except Exception:
                        pass

            edge = _ensure_edge_between_vertices(bm, vert_a, desired_b)
            if edge is not None and edge.is_valid:
                ensured.append(edge)

    if ensured:
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            pass
    return ensured


def _smart_connect_cut_positions(segments, pinch, slide):
    segments = _clamp_int(segments, 1, 64)
    pinch = _clamp(pinch, -100.0, 100.0)
    slide = _clamp(slide, -100.0, 100.0)

    positions = [float(index + 1) / float(segments + 1) for index in range(segments)]

    if segments >= 2:
        normalized_pinch = pinch / 100.0
        max_offset = max(abs(position - 0.5) for position in positions)
        if max_offset > 1.0e-8:
            if normalized_pinch < 0.0:
                scale = max(0.0, 1.0 + normalized_pinch)
            else:
                max_scale = (0.5 - _POSITION_EPSILON) / max_offset
                scale = 1.0 + normalized_pinch * max(0.0, max_scale - 1.0)
            positions = [0.5 + ((position - 0.5) * scale) for position in positions]

    desired_shift = (slide / 100.0) * 0.5
    min_position = min(positions)
    max_position = max(positions)
    min_shift = _POSITION_EPSILON - min_position
    max_shift = (1.0 - _POSITION_EPSILON) - max_position
    shift = max(min_shift, min(max_shift, desired_shift))
    positions = [_clamp(position + shift, _POSITION_EPSILON, 1.0 - _POSITION_EPSILON) for position in positions]
    positions.sort()

    if len(positions) >= 2:
        min_gap = _POSITION_EPSILON
        has_gap_conflict = any(
            positions[index] <= positions[index - 1] + min_gap
            for index in range(1, len(positions))
        )
        if has_gap_conflict:
            center = sum(positions) / float(len(positions))
            span = min_gap * float(len(positions) - 1)
            start = center - (span * 0.5)
            start = max(_POSITION_EPSILON, min((1.0 - _POSITION_EPSILON) - span, start))
            positions = [start + (float(index) * min_gap) for index in range(len(positions))]

    return tuple(positions)


def _move_subdivision_vertices_to_positions(
    bm,
    selected_segments,
    before_vertex_keys,
    target_positions,
    candidate_verts=None,
):
    if not selected_segments or not target_positions:
        return 0

    try:
        vertex_pool = tuple(
            vert for vert in tuple(candidate_verts or ())
            if vert is not None and vert.is_valid and not vert.hide
        )
    except Exception:
        vertex_pool = ()
    if not vertex_pool:
        vertex_pool = tuple(getattr(bm, 'verts', ()))

    assignments = {}
    for segment in selected_segments:
        try:
            start, end = segment
        except Exception:
            continue
        candidates = []
        for vert in vertex_pool:
            try:
                if not vert.is_valid or vert.hide:
                    continue
                point = _vec_tuple(vert.co)
                factor = _segment_factor(point, start, end)
                if factor <= _POSITION_EPSILON or factor >= (1.0 - _POSITION_EPSILON):
                    continue
                if _vec_key(vert.co) in before_vertex_keys:
                    continue
                if not _point_on_segment(point, start, end, tol=1.0e-5):
                    continue
                candidates.append((factor, vert))
            except Exception:
                continue
        if not candidates:
            continue

        candidates.sort(key=lambda item: item[0])
        if len(candidates) == len(target_positions):
            index_pairs = enumerate(candidates)
            for target_index, (_factor, vert) in index_pairs:
                assignments.setdefault(vert, []).append(_vec_lerp(start, end, target_positions[target_index]))
        else:
            last_candidate = max(1, len(candidates) - 1)
            last_target = max(1, len(target_positions) - 1)
            for candidate_index, (_factor, vert) in enumerate(candidates):
                if len(target_positions) == 1:
                    target_index = 0
                else:
                    target_index = int(round((candidate_index / last_candidate) * last_target))
                target_index = max(0, min(len(target_positions) - 1, target_index))
                assignments.setdefault(vert, []).append(_vec_lerp(start, end, target_positions[target_index]))

    moved = 0
    for vert, coords in assignments.items():
        try:
            if not vert.is_valid or not coords:
                continue
            count = float(len(coords))
            vert.co.x = sum(coord[0] for coord in coords) / count
            vert.co.y = sum(coord[1] for coord in coords) / count
            vert.co.z = sum(coord[2] for coord in coords) / count
            moved += 1
        except Exception:
            continue
    return moved


def _oriented_vertices_for_edge(edge, orientation_bits):
    """Return the live endpoint objects in the same direction as the segment."""
    try:
        start, end = edge.verts[0], edge.verts[1]
        if bool((orientation_bits or {}).get(edge, False)):
            start, end = end, start
        return start, end
    except Exception:
        return None


def _clear_connect_edge_tags(bm):
    """Clear the private BMEdge scratch bit used during one connect operation."""
    try:
        for edge in tuple(bm.edges):
            if edge is not None and edge.is_valid:
                edge.tag = False
    except Exception:
        pass


def _new_cut_vertices_from_tagged_result(result, before_vertices):
    """Collect cut vertices in Blender's original result order without scans.

    ``subdivide_edges`` propagates ``BMEdge.tag`` to the split pieces of a tagged
    source edge.  Cross/connect edges are untagged.  Iterating the same result
    keys as the legacy implementation preserves the target-vertex ordering used
    by all three Flow algorithms, while the incident-tag test is constant time.
    """
    before_vertices = set(before_vertices or ())
    result_verts = []
    seen = set()
    for key in ('geom', 'geom_inner', 'geom_split'):
        for vert in _result_bmesh_elements(result, key, bmesh.types.BMVert):
            try:
                if vert in before_vertices or id(vert) in seen or not vert.is_valid or vert.hide:
                    continue
                if not any(edge.is_valid and bool(edge.tag) for edge in tuple(vert.link_edges)):
                    continue
            except Exception:
                continue
            seen.add(id(vert))
            result_verts.append(vert)
    return result_verts


def _segment_point_key(point):
    try:
        return (
            _round_value(point[0]),
            _round_value(point[1]),
            _round_value(point[2]),
        )
    except Exception:
        return (0.0, 0.0, 0.0)


def _live_segment_endpoint(endpoint, point, endpoint_index):
    """Resolve a source endpoint after a destructive BMesh subdivision."""
    try:
        if endpoint is not None and endpoint.is_valid:
            return endpoint
    except Exception:
        pass
    key = _segment_point_key(point)
    for vert in tuple((endpoint_index or {}).get(key, ())):
        try:
            if vert.is_valid:
                return vert
        except Exception:
            continue
    return None


def _tagged_source_chain_vertices(start_vert, end_vert, segment, *, expected_count):
    """Trace the tagged split chain for one original edge in O(cuts).

    Selected source edges may share endpoints, so the next branch is chosen by
    increasing interpolation factor on the original straight segment.  This is
    independent of BMesh element order and does not create a custom-data layer.
    """
    if start_vert is None or end_vert is None or segment is None:
        return ()
    try:
        if not start_vert.is_valid or not end_vert.is_valid:
            return ()
        start_point, end_point = segment
    except Exception:
        return ()

    current = start_vert
    current_factor = 0.0
    visited_edges = set()
    interior = []
    max_steps = max(2, int(expected_count) + 2)
    for _step in range(max_steps):
        if current is end_vert:
            break
        choices = []
        try:
            linked_edges = tuple(current.link_edges)
        except Exception:
            linked_edges = ()
        for edge in linked_edges:
            try:
                marker = id(edge)
                if marker in visited_edges or not edge.is_valid or not bool(edge.tag):
                    continue
                other = edge.other_vert(current)
                if other is None or not other.is_valid:
                    continue
                point = _vec_tuple(other.co)
                if not _point_on_segment(point, start_point, end_point, tol=1.0e-5):
                    continue
                factor = float(_segment_factor(point, start_point, end_point))
                if factor <= current_factor + 1.0e-7:
                    continue
                choices.append((factor, id(edge), edge, other))
            except Exception:
                continue
        if not choices:
            return ()
        choices.sort(key=lambda item: (item[0], item[1]))
        factor, _marker, edge, other = choices[0]
        visited_edges.add(id(edge))
        current = other
        current_factor = factor
        if current is not end_vert:
            interior.append(current)

    if current is not end_vert or len(interior) != int(expected_count):
        return ()
    return tuple(interior)


def _source_vertex_groups_from_tagged_edges(
    result,
    source_segments,
    source_endpoints,
    *,
    expected_count,
):
    """Map each original selected edge to its cut vertices without data layers."""
    tagged_edges = []
    seen = set()
    for key in ('geom_split', 'geom', 'geom_inner'):
        for edge in _result_bmesh_elements(result, key, bmesh.types.BMEdge):
            try:
                marker = id(edge)
                if marker in seen or not edge.is_valid or not bool(edge.tag):
                    continue
            except Exception:
                continue
            seen.add(marker)
            tagged_edges.append(edge)

    endpoint_index = {}
    for edge in tagged_edges:
        try:
            for vert in edge.verts:
                if vert is not None and vert.is_valid:
                    endpoint_index.setdefault(_vec_key(vert.co), []).append(vert)
        except Exception:
            continue

    groups = {}
    for source_id, segment in source_segments.items():
        endpoints = (source_endpoints or {}).get(source_id)
        if not endpoints:
            continue
        start_ref, end_ref = endpoints
        try:
            start_point, end_point = segment
        except Exception:
            continue
        start_vert = _live_segment_endpoint(start_ref, start_point, endpoint_index)
        end_vert = _live_segment_endpoint(end_ref, end_point, endpoint_index)
        chain = _tagged_source_chain_vertices(
            start_vert,
            end_vert,
            segment,
            expected_count=expected_count,
        )
        if chain:
            groups[int(source_id)] = chain
    return groups


def _move_source_vertex_groups_to_positions(source_vertex_groups, source_segments, target_positions):
    """Move grouped cut vertices without scanning every source edge/vertex pair."""
    if not source_vertex_groups or not source_segments or not target_positions:
        return 0
    assignments = {}
    for source_id, verts in source_vertex_groups.items():
        segment = source_segments.get(int(source_id))
        if segment is None:
            continue
        try:
            start, end = segment
        except Exception:
            continue
        candidates = []
        for vert in tuple(verts or ()):
            try:
                if vert is None or not vert.is_valid or vert.hide:
                    continue
                factor = _segment_factor(_vec_tuple(vert.co), start, end)
                candidates.append((factor, vert))
            except Exception:
                continue
        if not candidates:
            continue
        candidates.sort(key=lambda item: item[0])
        last_candidate = max(1, len(candidates) - 1)
        last_target = max(1, len(target_positions) - 1)
        for candidate_index, (_factor, vert) in enumerate(candidates):
            if len(target_positions) == 1:
                target_index = 0
            elif len(candidates) == len(target_positions):
                target_index = candidate_index
            else:
                target_index = int(round((candidate_index / last_candidate) * last_target))
            target_index = max(0, min(len(target_positions) - 1, target_index))
            assignments.setdefault(vert, []).append(_vec_lerp(start, end, target_positions[target_index]))

    moved = 0
    for vert, coords in assignments.items():
        try:
            if not vert.is_valid or not coords:
                continue
            count = float(len(coords))
            vert.co.x = sum(coord[0] for coord in coords) / count
            vert.co.y = sum(coord[1] for coord in coords) / count
            vert.co.z = sum(coord[2] for coord in coords) / count
            moved += 1
        except Exception:
            continue
    return moved


def _flow_get_straight_path(start_v, first_e, max_steps=256):
    path = [start_v]
    curr_v = start_v
    curr_e = first_e
    for _index in range(max(1, int(max_steps))):
        try:
            next_v = curr_e.other_vert(curr_v)
        except Exception:
            break
        if next_v in path:
            break
        path.append(next_v)
        try:
            in_faces = set(curr_e.link_faces)
        except Exception:
            in_faces = set()
        candidates = []
        try:
            linked_edges = list(next_v.link_edges)
        except Exception:
            linked_edges = []
        for edge in linked_edges:
            if edge is curr_e:
                continue
            try:
                if not edge.is_valid or edge.hide:
                    continue
            except Exception:
                pass
            try:
                if not in_faces.intersection(set(edge.link_faces)):
                    candidates.append(edge)
            except Exception:
                continue
        if len(candidates) == 1:
            curr_v = next_v
            curr_e = candidates[0]
        else:
            break
    return path


def _flow_factor_from_current_position(vert, left_co, right_co, fallback):
    try:
        direction = right_co - left_co
        length_sq = float(direction.length_squared)
        if length_sq <= 1.0e-12:
            return float(fallback)
        factor = float((vert.co - left_co).dot(direction) / length_sq)
        if factor != factor:
            return float(fallback)
        return _clamp(factor, 0.0, 1.0)
    except Exception:
        return float(fallback)


def _apply_flow_to_vertices(bm, target_verts, *, iterations=1, preserve_current_factors=True):
    """Smooth generated Mesh Connect vertices along surrounding topology.

    This is based on Mesh Align's Flow Set logic, but it uses an explicit vertex
    set instead of the current selection and preserves each generated vertex's
    current interpolation factor.  Preserving the factor is required so Flow
    Connect still honors Mesh Connect's Segments, Pinch, and Slide positions.
    """
    try:
        selected_set = {v for v in target_verts if v is not None and v.is_valid and not v.hide}
    except Exception:
        selected_set = set()
    if not selected_set:
        return 0

    moved_total = 0
    for _iteration in range(max(1, int(iterations or 1))):
        new_positions = {}
        for vert in list(selected_set):
            try:
                if not vert.is_valid or vert.hide:
                    continue
                edges = [edge for edge in vert.link_edges if edge.is_valid and not edge.hide]
            except Exception:
                continue
            if len(edges) < 2:
                continue

            min_sel_depth = float('inf')
            best_full_path = None
            try:
                for index_a in range(len(edges)):
                    for index_b in range(index_a + 1, len(edges)):
                        edge_a, edge_b = edges[index_a], edges[index_b]
                        try:
                            if set(edge_a.link_faces).intersection(set(edge_b.link_faces)):
                                continue
                        except Exception:
                            continue
                        path_a = _flow_get_straight_path(vert, edge_a, 256)
                        path_b = _flow_get_straight_path(vert, edge_b, 256)
                        depth_a = sum(1 for path_vert in path_a[1:] if path_vert in selected_set)
                        depth_b = sum(1 for path_vert in path_b[1:] if path_vert in selected_set)
                        if (depth_a + depth_b) < min_sel_depth:
                            min_sel_depth = depth_a + depth_b
                            best_full_path = path_a[::-1][:-1] + path_b
            except Exception:
                best_full_path = None

            if not best_full_path:
                try:
                    for edge in edges:
                        path = _flow_get_straight_path(vert, edge, 256)
                        depth = sum(1 for path_vert in path[1:] if path_vert in selected_set)
                        if depth < min_sel_depth:
                            min_sel_depth = depth
                            best_full_path = path
                except Exception:
                    best_full_path = None

            if not best_full_path or vert not in best_full_path:
                continue

            try:
                idx_vert = best_full_path.index(vert)
            except Exception:
                continue

            idx_left, idx_right = -1, -1
            for idx in range(idx_vert - 1, -1, -1):
                if best_full_path[idx] not in selected_set:
                    idx_left = idx
                    break
            for idx in range(idx_vert + 1, len(best_full_path)):
                if best_full_path[idx] not in selected_set:
                    idx_right = idx
                    break
            if idx_left == -1:
                idx_left = 0
            if idx_right == -1:
                idx_right = len(best_full_path) - 1
            if idx_left == idx_vert or idx_right == idx_vert or idx_left >= idx_right:
                continue

            num_segments = float(idx_right - idx_left)
            fallback_t = float(idx_vert - idx_left) / num_segments if num_segments > 0.0 else 0.5
            try:
                left_co = best_full_path[idx_left].co.copy()
                right_co = best_full_path[idx_right].co.copy()
                left_outer = (
                    best_full_path[idx_left - 1].co.copy()
                    if idx_left >= 1
                    else left_co + (left_co - best_full_path[idx_left + 1].co)
                )
                right_outer = (
                    best_full_path[idx_right + 1].co.copy()
                    if idx_right + 1 < len(best_full_path)
                    else right_co + (right_co - best_full_path[idx_right - 1].co)
                )
            except Exception:
                continue

            if preserve_current_factors:
                t = _flow_factor_from_current_position(vert, left_co, right_co, fallback_t)
            else:
                t = fallback_t

            chord = right_co - left_co
            chord_len = float(chord.length)
            if chord_len <= 1.0e-12:
                continue
            n = max(1.0, num_segments)
            avg_seg_len = chord_len / n
            left_vec = left_co - left_outer
            right_vec = right_outer - right_co
            try:
                tangent_left = left_vec.normalized() * avg_seg_len if left_vec.length > 1.0e-6 else chord.normalized() * avg_seg_len
            except Exception:
                tangent_left = chord.normalized() * avg_seg_len
            try:
                tangent_right = right_vec.normalized() * avg_seg_len if right_vec.length > 1.0e-6 else chord.normalized() * avg_seg_len
            except Exception:
                tangent_right = chord.normalized() * avg_seg_len

            tangent_1 = (n ** 2 / (n + 1.0)) * tangent_left + (1.0 / (n + 1.0)) * chord
            tangent_2 = (1.0 / (n + 1.0)) * chord + (n ** 2 / (n + 1.0)) * tangent_right
            try:
                if tangent_1.length > chord_len * 1.5:
                    tangent_1 = tangent_1.normalized() * chord_len * 1.5
                if tangent_2.length > chord_len * 1.5:
                    tangent_2 = tangent_2.normalized() * chord_len * 1.5
            except Exception:
                pass

            t2 = t * t
            t3 = t2 * t
            h1 = 2.0 * t3 - 3.0 * t2 + 1.0
            h2 = -2.0 * t3 + 3.0 * t2
            h3 = t3 - 2.0 * t2 + t
            h4 = t3 - t2
            try:
                new_positions[vert] = h1 * left_co + h2 * right_co + h3 * tangent_1 + h4 * tangent_2
            except Exception:
                continue

        for vert, co in new_positions.items():
            try:
                if vert.is_valid and not vert.hide:
                    vert.co = co
                    moved_total += 1
            except Exception:
                continue

    return moved_total


def _generated_vertices_on_selected_segments(bm, before_vertex_keys, selected_segments, target_positions):
    result = []
    seen = set()
    if not selected_segments:
        return result
    tolerance = 1.0e-5
    for segment in selected_segments:
        try:
            start, end = segment
        except Exception:
            continue
        for vert in list(getattr(bm, 'verts', ())):
            try:
                if not vert.is_valid or vert.hide:
                    continue
                if id(vert) in seen:
                    continue
                if _vec_key(vert.co) in before_vertex_keys:
                    continue
                point = _vec_tuple(vert.co)
                if not _point_on_segment(point, start, end, tol=tolerance):
                    continue
                if target_positions:
                    factor = _segment_factor(point, start, end)
                    if not any(abs(float(factor) - float(target)) <= 1.0e-3 for target in target_positions):
                        continue
                seen.add(id(vert))
                result.append(vert)
            except Exception:
                continue
    return result


def _flow_segment_map_for_vertices(flow_verts, selected_segments):
    mapping = {}
    if not flow_verts or not selected_segments:
        return mapping
    for vert in list(flow_verts):
        try:
            if vert is None or not vert.is_valid or vert.hide:
                continue
            point = _vec_tuple(vert.co)
        except Exception:
            continue
        for segment in selected_segments:
            try:
                if _point_on_segment(point, segment, tol=1.0e-4):
                    mapping[vert] = segment
                    break
            except Exception:
                continue
    return mapping


def _apply_selected_flow_algorithm(bm, flow_verts, *, algorithm=None, preserve_axis_segments=None):
    if not flow_verts:
        return 0
    algorithm = _normalize_flow_algorithm(algorithm)
    if _sms_flow is not None:
        try:
            return _sms_flow.apply_flow_algorithm_to_vertices(
                bm,
                flow_verts,
                algorithm=algorithm,
                iterations=8 if algorithm == _FLOW_ALGORITHM_EDGEFLOW else 1,
                preserve_current_factors=True,
                preserve_axis_segments=preserve_axis_segments,
            )
        except Exception:
            pass
    return _apply_flow_to_vertices(bm, flow_verts, iterations=1, preserve_current_factors=True)


def _scene_settings(context=None):
    scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return None
    try:
        return getattr(scene, _SCENE_SETTINGS_PROP)
    except Exception:
        return None


def _settings_values(context=None, *, segments=None, pinch=None, slide=None):
    settings = _scene_settings(context)
    if segments is None:
        segments = getattr(settings, 'segments', 1) if settings is not None else 1
    if pinch is None:
        pinch = getattr(settings, 'pinch', 0) if settings is not None else 0
    if slide is None:
        slide = getattr(settings, 'slide', 0) if settings is not None else 0
    return (
        _clamp_int(segments, 1, 64),
        _clamp_int(pinch, -100, 100),
        _clamp_int(slide, -100, 100),
    )


def _settings_algorithm(context=None, *, algorithm=None):
    if algorithm is not None:
        return _normalize_connect_algorithm(algorithm)
    settings = _scene_settings(context)
    try:
        return _normalize_connect_algorithm(getattr(settings, 'algorithm', _CONNECT_ALGORITHM_NORMAL))
    except Exception:
        return _CONNECT_ALGORITHM_NORMAL


def _settings_flow_algorithm(context=None, *, flow_algorithm=None):
    if flow_algorithm is not None:
        return _normalize_flow_algorithm(flow_algorithm)
    settings = _scene_settings(context)
    try:
        return _normalize_flow_algorithm(getattr(settings, 'flow_algorithm', _FLOW_ALGORITHM_CURRENT))
    except Exception:
        return _FLOW_ALGORITHM_CURRENT


def _store_settings(context=None, *, segments=None, pinch=None, slide=None, show_popup=None, algorithm=None, flow_algorithm=None):
    settings = _scene_settings(context)
    if settings is None:
        return
    try:
        if segments is not None:
            settings.segments = _clamp_int(segments, 1, 64)
        if pinch is not None:
            settings.pinch = _clamp_int(pinch, -100, 100)
        if slide is not None:
            settings.slide = _clamp_int(slide, -100, 100)
        if show_popup is not None:
            settings.show_popup = bool(show_popup)
        if algorithm is not None:
            settings.algorithm = _normalize_connect_algorithm(algorithm)
        if flow_algorithm is not None:
            settings.flow_algorithm = _normalize_flow_algorithm(flow_algorithm)
    except Exception:
        pass


def _should_show_popup(context=None):
    settings = _scene_settings(context)
    try:
        return bool(getattr(settings, 'show_popup', True))
    except Exception:
        return True


def _select_mode(context):
    try:
        mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
        if len(mode) >= 3:
            return mode[0], mode[1], mode[2]
    except Exception:
        pass
    return False, False, False


def _edit_mesh_objects(context):
    if callable(_sms_edit_mesh_objects):
        try:
            return list(_sms_edit_mesh_objects(context, unique_data=True))
        except Exception:
            pass
    objects = []
    try:
        source = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or ()
        for obj in tuple(source):
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT' and obj not in objects:
                objects.append(obj)
    except Exception:
        pass
    if objects:
        return objects
    try:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
            objects.append(obj)
    except Exception:
        pass
    return objects




_SMART_CONNECT_PREVIEW = {
    'handler': None,
    'shader': None,
    'batch': None,
    'line_count': 0,
    'active': False,
}


def _smart_connect_tag_view_redraw():
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in getattr(wm, 'windows', ()) if wm is not None else ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) if screen is not None else ():
                try:
                    if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


def _smart_connect_edge_pair_points(mw, edge_a, edge_b):
    a0 = mw @ edge_a.verts[0].co
    a1 = mw @ edge_a.verts[1].co
    b0 = mw @ edge_b.verts[0].co
    b1 = mw @ edge_b.verts[1].co
    try:
        same_order = (a0 - b0).length_squared + (a1 - b1).length_squared
        swapped_order = (a0 - b1).length_squared + (a1 - b0).length_squared
        if swapped_order < same_order:
            b0, b1 = b1, b0
    except Exception:
        pass
    return a0, a1, b0, b1


def _smart_connect_preview_build_lines(context, *, segments=None, pinch=None, slide=None):
    """Build ring-consistent preview lines from selected-edge topology only."""
    try:
        positions = _smart_connect_cut_positions(*(
            _settings_values(context, segments=segments, pinch=pinch, slide=slide)
        ))
    except Exception:
        return ()

    lines = []
    for obj in _edit_mesh_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            matrix_world = obj.matrix_world.copy()
            selected_edges = _selected_connect_edges(bm)
        except Exception:
            continue
        if not selected_edges:
            continue

        orientation_bits = _selected_edge_orientation_bits(bm, selected_edges)
        face_line_count = 0
        for _face, edge_a, edge_b in _selected_edge_face_pairs(selected_edges):
            endpoints_a = _oriented_vertices_for_edge(edge_a, orientation_bits)
            endpoints_b = _oriented_vertices_for_edge(edge_b, orientation_bits)
            if endpoints_a is None or endpoints_b is None:
                continue
            try:
                a0 = matrix_world @ endpoints_a[0].co
                a1 = matrix_world @ endpoints_a[1].co
                b0 = matrix_world @ endpoints_b[0].co
                b1 = matrix_world @ endpoints_b[1].co
            except Exception:
                continue
            for factor in positions:
                try:
                    p1 = a0.lerp(a1, factor)
                    p2 = b0.lerp(b1, factor)
                    lines.append((
                        (float(p1.x), float(p1.y), float(p1.z)),
                        (float(p2.x), float(p2.y), float(p2.z)),
                    ))
                    face_line_count += 1
                except Exception:
                    continue

        if face_line_count == 0:
            for edge in selected_edges:
                endpoints = _oriented_vertices_for_edge(edge, orientation_bits)
                if endpoints is None:
                    continue
                try:
                    start = matrix_world @ endpoints[0].co
                    end = matrix_world @ endpoints[1].co
                    direction = end - start
                    if direction.length_squared <= 1.0e-12:
                        continue
                    tick = direction * 0.08
                    for factor in positions:
                        point = start.lerp(end, factor)
                        lines.append((
                            (float((point - tick).x), float((point - tick).y), float((point - tick).z)),
                            (float((point + tick).x), float((point + tick).y), float((point + tick).z)),
                        ))
                except Exception:
                    continue
    return tuple(lines)


def _smart_connect_preview_draw(snapshot):
    """Draw the immutable preview batch built by popup/property updates."""
    if snapshot is None:
        return
    shader = snapshot.get('shader')
    batch = snapshot.get('batch')
    if shader is None or batch is None:
        return
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.5)
        shader.bind()
        shader.uniform_float('color', (0.2, 0.65, 1.0, 0.95))
        batch.draw(shader)
    except Exception:
        return
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def _smart_connect_preview_shader():
    shader = _SMART_CONNECT_PREVIEW.get('shader')
    if shader is not None:
        return shader
    for shader_name in ('UNIFORM_COLOR', '3D_UNIFORM_COLOR'):
        try:
            shader = gpu.shader.from_builtin(shader_name)
            break
        except Exception:
            shader = None
    _SMART_CONNECT_PREVIEW['shader'] = shader
    return shader


def _smart_connect_preview_update(context=None, *, segments=None, pinch=None, slide=None):
    if not bool(_SMART_CONNECT_PREVIEW.get('active')):
        return
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return

    lines = ()
    try:
        _vert_mode, edge_mode, face_mode = _select_mode(context)
        if getattr(context, 'mode', '') == 'EDIT_MESH' and edge_mode and not face_mode:
            lines = _smart_connect_preview_build_lines(
                context,
                segments=segments,
                pinch=pinch,
                slide=slide,
            )
    except Exception:
        lines = ()

    coords = tuple(point for line in lines for point in line)
    shader = _smart_connect_preview_shader()
    batch = None
    if shader is not None and coords:
        try:
            batch = batch_for_shader(shader, 'LINES', {'pos': coords})
        except Exception:
            batch = None
    _SMART_CONNECT_PREVIEW['batch'] = batch
    _SMART_CONNECT_PREVIEW['line_count'] = len(lines)
    _smart_connect_tag_view_redraw()


def _smart_connect_preview_start(context=None, *, segments=None, pinch=None, slide=None):
    context = context or getattr(bpy, 'context', None)
    _SMART_CONNECT_PREVIEW['active'] = True
    _smart_connect_preview_shader()
    if _SMART_CONNECT_PREVIEW.get('handler') is None:
        try:
            _SMART_CONNECT_PREVIEW['handler'] = bpy.types.SpaceView3D.draw_handler_add(
                _smart_connect_preview_draw,
                (_SMART_CONNECT_PREVIEW,),
                'WINDOW',
                'POST_VIEW',
            )
        except Exception:
            _SMART_CONNECT_PREVIEW['handler'] = None
    _smart_connect_preview_update(context, segments=segments, pinch=pinch, slide=slide)


def _smart_connect_preview_stop():
    handler = _SMART_CONNECT_PREVIEW.get('handler')
    _SMART_CONNECT_PREVIEW['handler'] = None
    _SMART_CONNECT_PREVIEW['active'] = False
    _SMART_CONNECT_PREVIEW['batch'] = None
    _SMART_CONNECT_PREVIEW['line_count'] = 0
    if handler is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        except Exception:
            pass
    _smart_connect_tag_view_redraw()


def _smart_connect_preview_property_update(self, context):
    try:
        _smart_connect_preview_update(
            context,
            segments=getattr(self, 'segments', None),
            pinch=getattr(self, 'pinch', None),
            slide=getattr(self, 'slide', None),
        )
    except Exception:
        pass


def _invoke_connect_dialog(context):
    """Launch the child properties dialog and finish the caller immediately.

    A dispatcher or lazy proxy must never propagate the child's RUNNING_MODAL
    status as its own.  Only ``mesh.smart_connect_dialog`` owns the modal dialog.
    """
    del context
    try:
        result = bpy.ops.mesh.smart_connect_dialog('INVOKE_DEFAULT')
    except Exception:
        try:
            result = bpy.ops.mesh.smart_connect_dialog()
        except Exception:
            return {'CANCELLED'}
    try:
        status = set(result or ())
    except Exception:
        status = set()
    if 'RUNNING_MODAL' in status or 'FINISHED' in status:
        return {'FINISHED'}
    return {'CANCELLED'}


def _schedule_connect_dialog_reopen():
    # Compatibility no-op. Older builds reopened the popup here, which could
    # duplicate Mesh Connect popups. The current UI intentionally has only
    # Apply and Cancel, so continuation/reopen behavior is disabled.
    return None


def _vertex_slide_constraint_enabled(context):
    try:
        from ..vertex_slide import operators as _vertex_slide_ops
        fn = getattr(_vertex_slide_ops, '_svs_scene_enabled', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        pass
    return False


def _restore_vertex_slide_constraint_enabled(context):
    try:
        from ..vertex_slide import operators as _vertex_slide_ops
        fn = getattr(_vertex_slide_ops, '_svs_set_scene_enabled', None)
        if callable(fn):
            fn(context, True)
            return True
    except Exception:
        pass
    return False


def _begin_vertex_slide_topology_transaction(context):
    """Suspend the live Vertex Slide monitor before changing edit topology."""
    if not _vertex_slide_constraint_enabled(context):
        return False
    try:
        from ..vertex_slide import operators as _vertex_slide_ops
        fn = getattr(_vertex_slide_ops, 'begin_external_topology_change', None)
        if callable(fn):
            fn(context)
            return True
    except Exception:
        pass
    return False


def _end_vertex_slide_topology_transaction(context, *, started=False, request_rebase=True):
    if not started:
        return False
    try:
        from ..vertex_slide import operators as _vertex_slide_ops
        fn = getattr(_vertex_slide_ops, 'end_external_topology_change', None)
        if callable(fn):
            fn(context, request_rebase=bool(request_rebase))
            return True
    except Exception:
        pass
    return False


def _resync_vertex_slide_after_topology_change(context, *, was_enabled=False):
    """Keep Vertex Slide active after Mesh Connect creates new selectable edges.

    Mesh Connect changes edit-mode topology in both vertex and edge modes.
    Preserve the ON state captured before the BMesh transaction and synchronize
    the monitor to the newly generated selection baseline before the next
    transform begins.
    """
    try:
        from ..vertex_slide import operators as _vertex_slide_ops
    except Exception:
        return False

    if bool(was_enabled):
        try:
            setter = getattr(_vertex_slide_ops, '_svs_set_scene_enabled', None)
            if callable(setter):
                setter(context, True)
        except Exception:
            pass

    try:
        enabled_now = bool(getattr(_vertex_slide_ops, '_svs_scene_enabled', lambda _ctx: False)(context))
    except Exception:
        enabled_now = False
    if not enabled_now:
        return False

    for name in (
        'sync_constraint_after_topology_change',
        'ensure_constraint_monitor_synced',
    ):
        try:
            fn = getattr(_vertex_slide_ops, name, None)
        except Exception:
            fn = None
        if callable(fn):
            try:
                return bool(fn(context, restart=True))
            except TypeError:
                try:
                    return bool(fn(context))
                except Exception:
                    return False
            except Exception:
                return False
    return False


def _shared_connect_face(vert_a, vert_b):
    """Return a valid visible face that still contains both vertices.

    The face is resolved immediately before every split.  Earlier splits may
    invalidate or replace the original BMFace, so retaining face references
    across the operation is unsafe and can lead to native BMesh crashes.
    """
    if vert_a is None or vert_b is None or vert_a is vert_b:
        return None
    try:
        if not vert_a.is_valid or not vert_b.is_valid:
            return None
    except Exception:
        return None
    try:
        faces_b = {face for face in vert_b.link_faces if face.is_valid and not face.hide}
    except Exception:
        faces_b = set()
    try:
        for face in tuple(vert_a.link_faces):
            if face is not None and face.is_valid and not face.hide and face in faces_b:
                return face
    except Exception:
        pass
    return None


def _safe_split_face_between_vertices(bm, vert_a, vert_b):
    """Split one current face between two vertices without nested operators.

    ``bmesh.ops.connect_vert_pair`` can traverse several faces internally and
    has been observed to enter unstable native paths on degenerate or recently
    modified edit meshes.  Resolving a single current shared face and using
    ``bmesh.utils.face_split`` keeps every topology mutation local and validates
    the resulting edge before it is returned.
    """
    if bm is None or vert_a is None or vert_b is None or vert_a is vert_b:
        return None
    try:
        existing = bm.edges.get((vert_a, vert_b))
        if existing is not None and existing.is_valid:
            return None
    except Exception:
        pass
    face = _shared_connect_face(vert_a, vert_b)
    if face is None:
        return None
    try:
        _new_face, split_loop = bmesh.utils.face_split(
            face,
            vert_a,
            vert_b,
            use_exist=True,
        )
    except (ReferenceError, RuntimeError, ValueError, TypeError):
        return None
    except Exception:
        return None
    try:
        edge = getattr(split_loop, 'edge', None)
        if edge is not None and edge.is_valid:
            return edge
    except Exception:
        pass
    try:
        edge = bm.edges.get((vert_a, vert_b))
        return edge if edge is not None and edge.is_valid else None
    except Exception:
        return None


def _run_safe_connect_on_object(context, obj, report_cb=None):
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', '') != 'EDIT':
        return {'CANCELLED'}

    me = getattr(obj, 'data', None)
    if me is None:
        return {'CANCELLED'}

    try:
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        return {'CANCELLED'}

    selected_verts = [v for v in bm.verts if getattr(v, 'is_valid', True) and v.select and not v.hide]
    if len(selected_verts) < 2:
        return {'CANCELLED'}

    # Preserve the original vertex selection and history.  The topology change
    # creates only edges/faces, so these BMVert references remain valid.
    original_selected_vert_indices = []
    try:
        original_selected_vert_indices = [int(v.index) for v in selected_verts if getattr(v, 'is_valid', True)]
    except Exception:
        original_selected_vert_indices = []
    original_select_history_verts = []
    try:
        original_selected_lookup = set(selected_verts)
        original_select_history_verts = [
            elem for elem in bm.select_history
            if isinstance(elem, bmesh.types.BMVert)
            and elem in original_selected_lookup
            and getattr(elem, 'is_valid', True)
        ]
    except Exception:
        original_select_history_verts = []

    selected_set = set(selected_verts)
    pair_keys = set()
    pairs = []
    shared_face_found = False
    try:
        # Build only immutable vertex pairs before changing topology.  BMFace
        # references are intentionally not retained across face splits.
        for face in tuple(bm.faces):
            if not getattr(face, 'is_valid', True) or face.hide:
                continue
            face_selected = [
                vert for vert in face.verts
                if vert in selected_set and getattr(vert, 'is_valid', True)
            ]
            if len(face_selected) < 2:
                continue
            shared_face_found = True
            if len(face_selected) == 2:
                candidate_pairs = ((face_selected[0], face_selected[1]),)
            else:
                # Match the established Smart Connect behaviour: connect
                # consecutive selected vertices in the face-loop order.  Each
                # pair is resolved against the *current* face immediately before
                # splitting, so preceding splits cannot leave stale BMFace data.
                candidate_pairs = tuple(
                    (face_selected[index], face_selected[index + 1])
                    for index in range(len(face_selected) - 1)
                )
            for vert_a, vert_b in candidate_pairs:
                if vert_a is vert_b:
                    continue
                key = tuple(sorted((id(vert_a), id(vert_b))))
                if key in pair_keys:
                    continue
                try:
                    existing = bm.edges.get((vert_a, vert_b))
                    if existing is not None and existing.is_valid:
                        continue
                except Exception:
                    pass
                pair_keys.add(key)
                pairs.append((vert_a, vert_b))
    except Exception:
        pairs = []

    if not shared_face_found or not pairs:
        _report_message(report_cb, {'WARNING'}, "Selected vertices do not share a face. Select vertices on the same face.")
        return {'CANCELLED'}

    new_edges = []
    for vert_a, vert_b in pairs:
        edge = _safe_split_face_between_vertices(bm, vert_a, vert_b)
        if edge is not None:
            new_edges.append(edge)

    try:
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        pass

    new_edges = [edge for edge in new_edges if edge is not None and getattr(edge, 'is_valid', False)]
    if not new_edges:
        return {'CANCELLED'}

    restored_verts = []
    try:
        for face in tuple(bm.faces):
            if getattr(face, 'is_valid', True):
                face.select_set(False)
        for edge in tuple(bm.edges):
            if getattr(edge, 'is_valid', True):
                edge.select_set(False)
        for vert in tuple(bm.verts):
            if getattr(vert, 'is_valid', True):
                vert.select_set(False)

        for vert in selected_verts:
            if getattr(vert, 'is_valid', True) and not getattr(vert, 'hide', False):
                vert.select_set(True)
                restored_verts.append(vert)

        if not restored_verts and original_selected_vert_indices:
            try:
                bm.verts.ensure_lookup_table()
            except Exception:
                pass
            for index in original_selected_vert_indices:
                try:
                    vert = bm.verts[index]
                except Exception:
                    vert = None
                if vert is not None and getattr(vert, 'is_valid', True) and not getattr(vert, 'hide', False):
                    vert.select_set(True)
                    restored_verts.append(vert)

        bm.select_mode = {'VERT'}
        try:
            bm.select_flush_mode()
        except Exception:
            pass

        # Enforce a pure vertex selection after flushing.  The newly created
        # connection edges must not force the viewport into edge selection mode.
        for face in tuple(bm.faces):
            if getattr(face, 'is_valid', True):
                face.select_set(False)
        for edge in tuple(bm.edges):
            if getattr(edge, 'is_valid', True):
                edge.select_set(False)
        for vert in restored_verts:
            if getattr(vert, 'is_valid', True) and not getattr(vert, 'hide', False):
                vert.select_set(True)

        try:
            bm.select_history.clear()
            history_restored = False
            for vert in original_select_history_verts:
                if getattr(vert, 'is_valid', True) and vert in restored_verts:
                    bm.select_history.add(vert)
                    history_restored = True
            if not history_restored:
                for vert in restored_verts:
                    if getattr(vert, 'is_valid', True):
                        bm.select_history.add(vert)
        except Exception:
            pass
    except Exception:
        for vert in selected_verts:
            try:
                if getattr(vert, 'is_valid', True) and not getattr(vert, 'hide', False):
                    vert.select_set(True)
            except Exception:
                pass

    try:
        bm.normal_update()
    except Exception:
        pass
    try:
        # This function performs the topology mutation itself, so the edit-mesh
        # update must be destructive.  Using a non-destructive update after a
        # face split can leave Blender's derived edit caches out of sync.
        # Topology changed: rebuild edit-mode tessellation before the 3D View
        # redraws.  Leaving loop triangles stale is harmless in background mode
        # but can crash Blender's viewport/depsgraph immediately after return.
        bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
    except TypeError:
        try:
            bmesh.update_edit_mesh(me, True)
        except Exception:
            return {'CANCELLED'}
    except Exception:
        return {'CANCELLED'}

    try:
        context.tool_settings.mesh_select_mode = (True, False, False)
    except Exception:
        pass
    return {'FINISHED'}

def run_safe_connect(context, report_cb=None):
    edit_objects = _edit_mesh_objects(context)
    if not edit_objects:
        return {'CANCELLED'}

    vertex_slide_was_enabled = _vertex_slide_constraint_enabled(context)
    any_finished = False
    for obj in edit_objects:
        try:
            result = _run_safe_connect_on_object(context, obj, report_cb=None)
            if 'FINISHED' in set(result or ()):
                any_finished = True
        except Exception:
            continue

    if any_finished:
        try:
            context.tool_settings.mesh_select_mode = (True, False, False)
        except Exception:
            pass
        _resync_vertex_slide_after_topology_change(context, was_enabled=vertex_slide_was_enabled)
        return {'FINISHED'}

    _report_message(report_cb, {'WARNING'}, "Selected vertices do not share a face. Select vertices on the same face.")
    return {'CANCELLED'}

def _result_bmesh_elements(result, key, element_type):
    """Return unique, currently valid BMesh elements from an operator result."""
    unique = []
    seen = set()
    try:
        values = tuple((result or {}).get(key, ()) or ())
    except Exception:
        values = ()
    for element in values:
        if not isinstance(element, element_type):
            continue
        try:
            if not element.is_valid:
                continue
        except Exception:
            continue
        marker = id(element)
        if marker in seen:
            continue
        seen.add(marker)
        unique.append(element)
    return unique


def _new_cut_vertices_from_result(result, before_vertices, selected_segments):
    """Collect the new cut vertices produced on the originally selected edges."""
    candidates = []
    seen = set()
    before_vertices = set(before_vertices or ())
    for key in ('geom', 'geom_inner', 'geom_split'):
        for vert in _result_bmesh_elements(result, key, bmesh.types.BMVert):
            if vert in before_vertices or id(vert) in seen:
                continue
            try:
                point = _vec_tuple(vert.co)
                if selected_segments and not any(
                    _point_on_segment(point, segment[0], segment[1], tol=1.0e-5)
                    for segment in selected_segments
                ):
                    continue
            except Exception:
                continue
            seen.add(id(vert))
            candidates.append(vert)
    return candidates


def _select_connect_result_edges(bm, target_edges):
    """Select only the generated Mesh Connect result edges."""
    target_edge_set = {
        edge for edge in tuple(target_edges or ())
        if edge is not None and getattr(edge, 'is_valid', False) and not getattr(edge, 'hide', False)
    }
    try:
        for face in tuple(bm.faces):
            if face.is_valid:
                face.select_set(False)
        for edge in tuple(bm.edges):
            if edge.is_valid:
                edge.select_set(False)
        for vert in tuple(bm.verts):
            if vert.is_valid:
                vert.select_set(False)
    except Exception:
        pass

    for edge in target_edge_set:
        try:
            edge.select_set(True)
            for vert in edge.verts:
                if vert.is_valid and not vert.hide:
                    vert.select_set(True)
        except Exception:
            continue

    try:
        bm.select_mode = {'EDGE'}
        bm.select_flush_mode()
    except Exception:
        pass

    # Selection flushing can reselect split pieces.  Enforce the exact result
    # set once more so the user receives only the new connection edges whenever
    # the topology operation produced them.
    try:
        for face in tuple(bm.faces):
            if face.is_valid:
                face.select_set(False)
        for edge in tuple(bm.edges):
            if edge.is_valid and edge not in target_edge_set:
                edge.select_set(False)
        for edge in target_edge_set:
            if edge.is_valid and not edge.hide:
                edge.select_set(True)
                for vert in edge.verts:
                    if vert.is_valid and not vert.hide:
                        vert.select_set(True)
        bm.select_history.clear()
        for edge in target_edge_set:
            if edge.is_valid:
                bm.select_history.add(edge)
    except Exception:
        pass
    return target_edge_set


def _run_edge_subdivide_on_object(obj, *, segments, target_positions, use_flow_connect, flow_algorithm):
    """Subdivide one edit BMesh in one undo-owned, linear-time transaction.

    ``BMEdge.tag`` marks the selected source edges before subdivision. Blender
    propagates that scratch bit to their split pieces, while generated connect
    edges remain untagged.  The split chains are then traced from the original
    endpoints, avoiding both custom-data allocation and the former quadratic
    source-edge/vertex scans.  Not creating a custom-data layer is important:
    layer allocation can change BMesh element order and therefore alter the
    established Current/3ds Max/EdgeFlow tie-breaking results.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', '') != 'EDIT':
        return False
    me = getattr(obj, 'data', None)
    if me is None:
        return False
    try:
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        return False

    _clear_connect_edge_tags(bm)
    try:
        selected_edges = [
            edge for edge in tuple(bm.edges)
            if edge.is_valid and edge.select and not edge.hide and _edge_safe_for_subdivide(edge)
        ]
        if not selected_edges:
            return False

        before_vertices = {vert for vert in tuple(bm.verts) if vert.is_valid}
        before_vertex_keys = {_vec_key(vert.co) for vert in before_vertices if not vert.hide}
        orientation_bits = _selected_edge_orientation_bits(bm, selected_edges)

        source_ids = {}
        source_segments = {}
        source_endpoints = {}
        original_segments = []
        for source_id, edge in enumerate(selected_edges, 1):
            segment = _oriented_segment_for_edge(edge, orientation_bits)
            endpoints = _oriented_vertices_for_edge(edge, orientation_bits)
            if segment is None or endpoints is None:
                continue
            source_ids[edge] = source_id
            source_segments[source_id] = segment
            source_endpoints[source_id] = endpoints
            original_segments.append(segment)
            try:
                edge.tag = True
            except Exception:
                pass
        original_segments = tuple(original_segments)
        if not original_segments:
            return False

        uv_data = _capture_selected_edge_uv_data(
            bm,
            selected_edges=selected_edges,
            orientation_bits=orientation_bits,
            source_ids=source_ids,
        )

        try:
            result = bmesh.ops.subdivide_edges(
                bm,
                edges=selected_edges,
                cuts=int(segments),
                use_grid_fill=False,
                smooth=0.0,
            ) or {}
        except (ReferenceError, RuntimeError, ValueError, TypeError):
            return False
        except Exception:
            return False

        try:
            bm.verts.index_update()
            bm.edges.index_update()
            bm.faces.index_update()
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            pass

        expected_per_source = max(1, int(segments))
        source_vertex_groups = _source_vertex_groups_from_tagged_edges(
            result,
            source_segments,
            source_endpoints,
            expected_count=expected_per_source,
        )
        grouped_complete = bool(
            len(source_vertex_groups) == len(source_segments)
            and all(len(source_vertex_groups.get(source_id, ())) == expected_per_source for source_id in source_segments)
        )

        # Preserve Blender's result-list order.  Flow algorithms contain valid
        # geometric ties, so changing the order of otherwise equivalent BMesh
        # elements can select a different but unintended path.
        new_cut_verts = _new_cut_vertices_from_tagged_result(result, before_vertices)
        expected_cut_count = max(1, len(selected_edges) * expected_per_source)
        if len(new_cut_verts) < expected_cut_count:
            # Compatibility fallback for Blender builds that do not propagate
            # BMEdge.tag through subdivide_edges.
            new_cut_verts = _new_cut_vertices_from_result(result, before_vertices, original_segments)
        position_candidates = new_cut_verts if len(new_cut_verts) >= expected_cut_count else None

        # The direct source-chain mapping is the linear fast path for normal
        # Connect.  Flow Connect intentionally keeps the legacy geometric
        # association and candidate ordering: its Current/3ds Max/EdgeFlow
        # algorithms contain valid equal-distance ties, and changing which cut
        # vertex is associated with a source segment changes the established
        # result even when topology is identical.
        use_grouped_positioning = bool(grouped_complete and not use_flow_connect)

        if target_positions and original_segments:
            if use_grouped_positioning:
                _move_source_vertex_groups_to_positions(
                    source_vertex_groups,
                    source_segments,
                    target_positions,
                )
            else:
                _move_subdivision_vertices_to_positions(
                    bm,
                    original_segments,
                    before_vertex_keys,
                    target_positions,
                    candidate_verts=position_candidates,
                )
            try:
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
            except Exception:
                pass
            _restore_subdivision_uvs_after_positioning(
                bm,
                uv_data,
                before_vertex_keys,
                target_positions,
                candidate_verts=position_candidates,
                source_vertex_groups=source_vertex_groups if grouped_complete else None,
            )

        # ``geom_inner`` contains the cross/connect edges generated inside faces.
        # Tagged edges are source-edge split pieces; untagged edges are generated
        # connections.  If a Blender build reports different tag propagation,
        # retain the exact legacy geometric classifier as a compatibility fallback.
        inner_edges = _result_bmesh_elements(result, 'geom_inner', bmesh.types.BMEdge)
        connect_edges = []
        if inner_edges:
            try:
                connect_edges = [edge for edge in inner_edges if edge.is_valid and not bool(edge.tag)]
            except Exception:
                connect_edges = []
            if not connect_edges:
                connect_edges = [
                    edge for edge in inner_edges
                    if not any(_edge_lies_on_segment(edge, segment, tol=1.0e-5) for segment in original_segments)
                ]
            if not connect_edges:
                connect_edges = list(inner_edges)
        if not connect_edges:
            connect_edges = _result_bmesh_elements(result, 'geom_split', bmesh.types.BMEdge)
        if not connect_edges and new_cut_verts:
            seen_edges = set()
            for vert in new_cut_verts:
                try:
                    for edge in tuple(vert.link_edges):
                        if edge.is_valid and not edge.hide and id(edge) not in seen_edges:
                            seen_edges.add(id(edge))
                            connect_edges.append(edge)
                except Exception:
                    continue

        if use_flow_connect and new_cut_verts:
            # Preserve the exact legacy segment resolver for Flow modes.  See
            # ``use_grouped_positioning`` above; using the direct groups here
            # changes tie-breaking in all three established Flow algorithms.
            segment_map = _flow_segment_map_for_vertices(new_cut_verts, original_segments)
            _apply_selected_flow_algorithm(
                bm,
                new_cut_verts,
                algorithm=flow_algorithm,
                preserve_axis_segments=segment_map,
            )

        try:
            bm.normal_update()
        except Exception:
            pass

        target_edge_set = _select_connect_result_edges(bm, connect_edges)
        if not target_edge_set:
            return False

        _clear_connect_edge_tags(bm)
        try:
            bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
        except TypeError:
            try:
                bmesh.update_edit_mesh(me, True)
            except Exception:
                return False
        except Exception:
            return False
        return True
    finally:
        _clear_connect_edge_tags(bm)


def run_edge_subdivide(context, *, segments=None, pinch=None, slide=None, algorithm=None, flow_algorithm=None):
    """Create Mesh Connect cuts with a single BMesh-owned topology transaction."""
    vertex_slide_was_enabled = _vertex_slide_constraint_enabled(context)
    segments, pinch, slide = _settings_values(
        context,
        segments=segments,
        pinch=pinch,
        slide=slide,
    )
    algorithm = _settings_algorithm(context, algorithm=algorithm)
    flow_algorithm = _settings_flow_algorithm(context, flow_algorithm=flow_algorithm)
    use_flow_connect = (algorithm == _CONNECT_ALGORITHM_FLOW)
    target_positions = _smart_connect_cut_positions(segments, pinch, slide)

    try:
        original_select_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    except Exception:
        original_select_mode = (False, True, False)
    try:
        context.tool_settings.mesh_select_mode = (False, True, False)
    except Exception:
        pass

    edit_objects = _edit_mesh_objects(context)
    if not edit_objects:
        if vertex_slide_was_enabled:
            _restore_vertex_slide_constraint_enabled(context)
        return {'CANCELLED'}

    any_finished = False
    any_selected = False
    for obj in edit_objects:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            if any(edge.is_valid and edge.select and not edge.hide for edge in tuple(bm.edges)):
                any_selected = True
        except Exception:
            continue
        try:
            if _run_edge_subdivide_on_object(
                obj,
                segments=segments,
                target_positions=target_positions,
                use_flow_connect=use_flow_connect,
                flow_algorithm=flow_algorithm,
            ):
                any_finished = True
        except Exception:
            # One malformed edit object must not abort or corrupt the remaining
            # objects in multi-object Edit Mode.
            continue

    try:
        context.tool_settings.mesh_select_mode = (False, True, False) if any_finished else original_select_mode
    except Exception:
        pass

    if any_finished:
        _resync_vertex_slide_after_topology_change(
            context,
            was_enabled=vertex_slide_was_enabled,
        )
        return {'FINISHED'}
    if vertex_slide_was_enabled:
        _restore_vertex_slide_constraint_enabled(context)
    return {'CANCELLED'} if any_selected else {'CANCELLED'}


def _run_face_subdivide_on_object(obj, *, cuts=1):
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', '') != 'EDIT':
        return False
    me = getattr(obj, 'data', None)
    if me is None:
        return False
    try:
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    except Exception:
        return False

    mutated = False
    try:
        selected_faces = [
            face for face in tuple(bm.faces)
            if face.is_valid and face.select and not face.hide
        ]
        if not selected_faces:
            return False

        selected_edges = []
        seen_edges = set()
        for face in selected_faces:
            for edge in tuple(face.edges):
                if edge.is_valid and not edge.hide and id(edge) not in seen_edges:
                    seen_edges.add(id(edge))
                    selected_edges.append(edge)
        if not selected_edges:
            return False

        result = bmesh.ops.subdivide_edges(
            bm,
            edges=selected_edges,
            cuts=max(1, int(cuts)),
            use_grid_fill=True,
            smooth=0.0,
        ) or {}
        mutated = True
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # Collect affected faces only from the BMesh operator result.  Older
        # builds added and removed a temporary custom-data layer around this
        # operation; that custom-data churn can invalidate edit-mesh caches and
        # is unnecessary because subdivide_edges already reports its geometry.
        affected_faces = set()
        for key in ('geom', 'geom_inner', 'geom_split'):
            for face in _result_bmesh_elements(result, key, bmesh.types.BMFace):
                if face.is_valid and not face.hide:
                    affected_faces.add(face)

        # Some Blender/BMesh configurations return only the new vertices/edges.
        # Resolve their linked faces after the operation rather than retaining
        # any BMFace reference from before the destructive topology change.
        for key in ('geom', 'geom_inner', 'geom_split'):
            for vert in _result_bmesh_elements(result, key, bmesh.types.BMVert):
                try:
                    for face in tuple(vert.link_faces):
                        if face.is_valid and not face.hide:
                            affected_faces.add(face)
                except Exception:
                    pass
            for edge in _result_bmesh_elements(result, key, bmesh.types.BMEdge):
                try:
                    for face in tuple(edge.link_faces):
                        if face.is_valid and not face.hide:
                            affected_faces.add(face)
                except Exception:
                    pass

        if not affected_faces:
            # Selection propagation is a final conservative fallback.  The
            # topology operation already succeeded, so never report cancellation
            # after mutation merely because one Blender build returned a sparse
            # result dictionary.
            affected_faces.update(
                face for face in tuple(bm.faces)
                if face.is_valid and face.select and not face.hide
            )

        for face in tuple(bm.faces):
            if face.is_valid:
                face.select_set(False)
        for edge in tuple(bm.edges):
            if edge.is_valid:
                edge.select_set(False)
        for vert in tuple(bm.verts):
            if vert.is_valid:
                vert.select_set(False)
        for face in tuple(affected_faces):
            if face.is_valid and not face.hide:
                face.select_set(True)
        bm.select_mode = {'FACE'}
        try:
            bm.select_flush_mode()
        except Exception:
            pass
        try:
            bm.select_history.clear()
            for face in tuple(affected_faces):
                if face.is_valid:
                    bm.select_history.add(face)
        except Exception:
            pass
        try:
            bm.normal_update()
        except Exception:
            pass
        return True
    except (ReferenceError, RuntimeError, ValueError, TypeError):
        return False
    except Exception:
        return False
    finally:
        if mutated:
            try:
                bmesh.update_edit_mesh(me, loop_triangles=True, destructive=True)
            except TypeError:
                try:
                    bmesh.update_edit_mesh(me, True)
                except Exception:
                    pass
            except Exception:
                pass


def run_native_subdivide(context):
    """Subdivide selected faces directly in every edited mesh object."""
    vertex_slide_was_enabled = _vertex_slide_constraint_enabled(context)
    edit_objects = _edit_mesh_objects(context)
    if not edit_objects:
        if vertex_slide_was_enabled:
            _restore_vertex_slide_constraint_enabled(context)
        return {'CANCELLED'}

    any_finished = False
    for obj in edit_objects:
        try:
            if _run_face_subdivide_on_object(obj, cuts=1):
                any_finished = True
        except Exception:
            continue

    if any_finished:
        try:
            context.tool_settings.mesh_select_mode = (False, False, True)
        except Exception:
            pass
        _resync_vertex_slide_after_topology_change(
            context,
            was_enabled=vertex_slide_was_enabled,
        )
        return {'FINISHED'}
    if vertex_slide_was_enabled:
        _restore_vertex_slide_constraint_enabled(context)
    return {'CANCELLED'}

def _execute_smart_connect_core(context=None, *, report_cb=None, segments=None, pinch=None, slide=None, algorithm=None, flow_algorithm=None):
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return {'CANCELLED'}
    topology_guard_started = _begin_vertex_slide_topology_transaction(context)
    try:
        vert_mode, edge_mode, face_mode = _select_mode(context)

        # Branch strictly by the current selection mode.
        # Vertex mode -> Connect
        # Edge mode   -> Subdivide selected edges and place the generated edge loops
        #                according to Segments / Pinch / Slide.
        # Face mode   -> Native Subdivide for the current face selection.
        #
        # When multiple modes are enabled, prefer the highest-dimensional mode so
        # an active edge/face workflow never falls back to vertex-connect by
        # accident.
        if face_mode:
            return run_native_subdivide(context)
        if edge_mode:
            return run_edge_subdivide(
                context,
                segments=segments,
                pinch=pinch,
                slide=slide,
                algorithm=algorithm,
                flow_algorithm=flow_algorithm,
            )
        if vert_mode:
            return run_safe_connect(context, report_cb=report_cb)
        return {'CANCELLED'}
    finally:
        # Release only after all destructive BMesh updates have returned.  The
        # Vertex Slide monitor performs its rebase on the next safe event/timer,
        # never from inside this operator's native finalization path.
        _end_vertex_slide_topology_transaction(
            context,
            started=topology_guard_started,
            request_rebase=True,
        )


def _connect_background_undo_push(message):
    """Compatibility no-op retained for callers from older integrated builds.

    Mesh Connect now performs its topology changes directly through BMesh inside
    the owning operator.  Blender's normal ``UNDO`` operator handling therefore
    creates one coherent undo step and no nested manual undo push is required.
    """
    del message
    return False


def _connect_result_after_apply(result):
    """Normalize an internal result without hiding successful mutations."""
    try:
        status = set(result or ())
    except Exception:
        status = set()
    return {'FINISHED'} if 'FINISHED' in status else {'CANCELLED'}


def _connect_finish_background_undo(result):
    return _connect_result_after_apply(result)


def _connect_cancel_after_apply(result):
    # Kept under the legacy helper name because older lazy-proxy integrations
    # may still call it.  Successful BMesh transactions must return FINISHED so
    # Blender records a valid undo step and does not retain a mutated operator
    # that reported cancellation.
    return _connect_result_after_apply(result)


def _execute_connect_through_undo_owner(
    context,
    *,
    report_cb=None,
    segments=None,
    pinch=None,
    slide=None,
    algorithm=None,
    flow_algorithm=None,
):
    """Run the mutation through the dedicated UNDO-owning operator.

    ``mesh.smart_connect`` and its legacy/lazy wrappers are dispatchers only.
    Keeping the actual BMesh transaction in ``mesh.smart_connect_confirm`` gives
    Blender exactly one operator-history owner and one undo step.
    """
    segments, pinch, slide = _settings_values(
        context,
        segments=segments,
        pinch=pinch,
        slide=slide,
    )
    algorithm = _settings_algorithm(context, algorithm=algorithm)
    flow_algorithm = _settings_flow_algorithm(context, flow_algorithm=flow_algorithm)

    confirm_op = getattr(getattr(bpy.ops, 'mesh', None), 'smart_connect_confirm', None)
    confirm_available = False
    try:
        if confirm_op is not None:
            confirm_op.get_rna_type()
            confirm_available = True
    except Exception:
        confirm_available = False

    if confirm_available:
        try:
            result = confirm_op(
                'EXEC_DEFAULT',
                segments=segments,
                pinch=pinch,
                slide=slide,
                algorithm=algorithm,
                flow_algorithm=flow_algorithm,
            )
            return _connect_result_after_apply(result)
        except Exception:
            # The child may already have entered its native BMesh transaction.
            # Never retry the mutation directly after an operator-call failure;
            # a second pass could touch partially changed topology and crash.
            return {'CANCELLED'}

    # Direct fallback is permitted only when the UNDO-owning class has never
    # been registered (for example isolated unit tests).  No child transaction
    # can have started in this branch.
    result = _execute_smart_connect_core(
        context,
        report_cb=report_cb,
        segments=segments,
        pinch=pinch,
        slide=slide,
        algorithm=algorithm,
        flow_algorithm=flow_algorithm,
    )
    return _connect_result_after_apply(result)


def execute_smart_connect(context=None, *, report_cb=None, invoke=False, segments=None, pinch=None, slide=None, algorithm=None, flow_algorithm=None):
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return {'CANCELLED'}
    _vert_mode, edge_mode, face_mode = _select_mode(context)
    if bool(invoke) and edge_mode and not face_mode and _should_show_popup(context):
        return _invoke_connect_dialog(context)
    return _execute_connect_through_undo_owner(
        context,
        report_cb=report_cb,
        segments=segments,
        pinch=pinch,
        slide=slide,
        algorithm=algorithm,
        flow_algorithm=flow_algorithm,
    )


class SMS_SmartConnectSceneSettings(bpy.types.PropertyGroup):
    bl_label = "Mesh Connect Settings"
    bl_description = "Scene-local settings for Mesh Connect. Values are kept while the scene remains open and are used by the popup and direct execution mode."

    segments: IntProperty(
        name=_SEGMENTS_NAME,
        description=_SEGMENTS_DESCRIPTION,
        default=1,
        min=1,
        max=64,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    pinch: IntProperty(
        name=_PINCH_NAME,
        description=_PINCH_DESCRIPTION,
        default=0,
        min=-100,
        max=100,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    slide: IntProperty(
        name=_SLIDE_NAME,
        description=_SLIDE_DESCRIPTION,
        default=0,
        min=-100,
        max=100,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    algorithm: EnumProperty(
        name=_CONNECT_ALGORITHM_NAME,
        description=_CONNECT_ALGORITHM_DESCRIPTION,
        items=_CONNECT_ALGORITHM_ITEMS,
        default=_CONNECT_ALGORITHM_NORMAL,
        options={'SKIP_SAVE'},
    )
    flow_algorithm: EnumProperty(
        name=_FLOW_ALGORITHM_NAME,
        description=_FLOW_ALGORITHM_DESCRIPTION,
        items=_FLOW_ALGORITHM_ITEMS,
        default=_FLOW_ALGORITHM_CURRENT,
        options={'SKIP_SAVE'},
    )
    show_popup: BoolProperty(
        name=_SHOW_POPUP_NAME,
        description=_SHOW_POPUP_DESCRIPTION,
        default=True,
        options={'SKIP_SAVE'},
    )


class _SmartConnectOperatorProps:
    segments: IntProperty(
        name=_SEGMENTS_NAME,
        description=_SEGMENTS_DESCRIPTION,
        default=1,
        min=1,
        max=64,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    pinch: IntProperty(
        name=_PINCH_NAME,
        description=_PINCH_DESCRIPTION,
        default=0,
        min=-100,
        max=100,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    slide: IntProperty(
        name=_SLIDE_NAME,
        description=_SLIDE_DESCRIPTION,
        default=0,
        min=-100,
        max=100,
        options={'SKIP_SAVE'},
        update=_smart_connect_preview_property_update,
    )
    algorithm: EnumProperty(
        name=_CONNECT_ALGORITHM_NAME,
        description=_CONNECT_ALGORITHM_DESCRIPTION,
        items=_CONNECT_ALGORITHM_ITEMS,
        default=_CONNECT_ALGORITHM_NORMAL,
        options={'SKIP_SAVE'},
    )
    flow_algorithm: EnumProperty(
        name=_FLOW_ALGORITHM_NAME,
        description=_FLOW_ALGORITHM_DESCRIPTION,
        items=_FLOW_ALGORITHM_ITEMS,
        default=_FLOW_ALGORITHM_CURRENT,
        options={'SKIP_SAVE'},
    )

    def _load_from_scene(self, context):
        segments, pinch, slide = _settings_values(context)
        self.segments = segments
        self.pinch = pinch
        self.slide = slide
        self.algorithm = _settings_algorithm(context)
        self.flow_algorithm = _settings_flow_algorithm(context)

    def _store_to_scene(self, context):
        _store_settings(context, segments=self.segments, pinch=self.pinch, slide=self.slide, algorithm=self.algorithm, flow_algorithm=self.flow_algorithm)


class MESH_OT_smart_connect_apply_continue(_SmartConnectOperatorProps, bpy.types.Operator):
    bl_idname = "mesh.smart_connect_apply_continue"
    bl_label = "Apply"
    bl_description = _APPLY_CONTINUE_DESCRIPTION
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return _feature_enabled(context) and obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        # Legacy class kept only so stale registrations from older builds can be
        # unregistered safely.  It no longer reopens the popup.
        self._store_to_scene(context)
        _smart_connect_preview_stop()
        result = _execute_smart_connect_core(
            context,
            report_cb=None,
            segments=self.segments,
            pinch=self.pinch,
            slide=self.slide,
            algorithm=self.algorithm,
            flow_algorithm=self.flow_algorithm,
        )
        return _connect_cancel_after_apply(result)


class MESH_OT_smart_connect_confirm(_SmartConnectOperatorProps, bpy.types.Operator):
    bl_idname = "mesh.smart_connect_confirm"
    bl_label = "Apply"
    bl_description = "Apply the current Mesh Connect settings and close the popup."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        self._store_to_scene(context)
        _smart_connect_preview_stop()
        result = _execute_smart_connect_core(
            context,
            report_cb=None,
            segments=self.segments,
            pinch=self.pinch,
            slide=self.slide,
            algorithm=self.algorithm,
            flow_algorithm=self.flow_algorithm,
        )
        return _connect_cancel_after_apply(result)


class MESH_OT_smart_connect_deferred_apply(_SmartConnectOperatorProps, bpy.types.Operator):
    """Apply Mesh Connect on the first event after the popup has fully closed.

    Blender 5.1 can retain dialog panel/operator custom-data until the modal
    confirmation handler returns.  Performing a destructive edit-BMesh update
    inside that handler can race the dialog teardown and crash in native UI/RNA
    finalization.  This operator owns the undo step and defers the mutation to a
    window timer event, which is processed only after the dialog operator has
    returned and its temporary UI data has been released.
    """

    bl_idname = "mesh.smart_connect_deferred_apply"
    bl_label = "Apply Mesh Connect"
    bl_description = "Internal deferred Mesh Connect transaction used after the settings popup closes."
    bl_options = {'INTERNAL', 'UNDO'}

    _timer = None
    _completed = False

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return _feature_enabled(context) and obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def _remove_timer(self, context):
        timer = getattr(self, '_timer', None)
        self._timer = None
        if timer is not None:
            try:
                context.window_manager.event_timer_remove(timer)
            except Exception:
                pass

    def invoke(self, context, event):
        del event
        self._completed = False
        try:
            self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            self._remove_timer(context)
            return {'CANCELLED'}

    def modal(self, context, event):
        if getattr(self, '_completed', False):
            self._remove_timer(context)
            return {'CANCELLED'}
        # Blender 5.1's Python Event RNA does not expose the originating timer
        # object.  This modal operator owns only one short-lived timer, so the
        # first TIMER event after invocation is the intended deferred trigger.
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        self._completed = True
        self._remove_timer(context)
        try:
            result = _execute_smart_connect_core(
                context,
                report_cb=None,
                segments=self.segments,
                pinch=self.pinch,
                slide=self.slide,
                algorithm=self.algorithm,
                flow_algorithm=self.flow_algorithm,
            )
        except Exception:
            return {'CANCELLED'}
        return _connect_result_after_apply(result)

    def cancel(self, context):
        self._completed = True
        self._remove_timer(context)


class MESH_OT_smart_connect_cancel(bpy.types.Operator):
    bl_idname = "mesh.smart_connect_cancel"
    bl_label = "Cancel"
    bl_description = "Close the Mesh Connect popup without applying changes."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return _feature_enabled(context) and obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        _smart_connect_preview_stop()
        return {'FINISHED'}


class MESH_OT_smart_connect_dialog(_SmartConnectOperatorProps, bpy.types.Operator):
    bl_idname = "mesh.smart_connect_dialog"
    bl_label = "Mesh Connect"
    bl_description = _SHOW_POPUP_DESCRIPTION
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        del event
        self._load_from_scene(context)
        _smart_connect_preview_start(context, segments=self.segments, pinch=self.pinch, slide=self.slide)
        confirm_text = bpy.app.translations.pgettext_iface("Apply")
        try:
            return context.window_manager.invoke_props_dialog(self, width=_CONNECT_DIALOG_WIDTH, confirm_text=confirm_text)
        except TypeError:
            try:
                return context.window_manager.invoke_props_dialog(self, width=_CONNECT_DIALOG_WIDTH)
            except Exception:
                return {'CANCELLED'}
        except Exception:
            return {'CANCELLED'}

    def cancel(self, context):
        _smart_connect_preview_stop()

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        algorithm_row = layout.row(align=True)
        algorithm_row.use_property_split = False
        algorithm_row.prop(self, "algorithm", expand=True)
        if _normalize_connect_algorithm(getattr(self, "algorithm", _CONNECT_ALGORITHM_NORMAL)) == _CONNECT_ALGORITHM_FLOW:
            layout.prop(self, "flow_algorithm")
        layout.separator(factor=0.35)
        layout.prop(self, "segments")
        pinch_row = layout.row()
        pinch_row.enabled = int(getattr(self, 'segments', 1)) >= 2
        pinch_row.prop(self, "pinch")
        layout.prop(self, "slide")

    def execute(self, context):
        self._store_to_scene(context)
        _smart_connect_preview_stop()
        # Complete the entire topology transaction synchronously while handling
        # the Apply click.  A popover may close as soon as the pointer leaves its
        # bounds, so correctness must not depend on a later popup-owned modal or
        # timer event.  The dedicated confirm operator remains the sole UNDO
        # owner and returns only after the BMesh operation has fully completed.
        return _execute_connect_through_undo_owner(
            context,
            report_cb=None,
            segments=self.segments,
            pinch=self.pinch,
            slide=self.slide,
            algorithm=self.algorithm,
            flow_algorithm=self.flow_algorithm,
        )


class MESH_OT_smart_connect(bpy.types.Operator):
    """Dispatch Mesh Connect without owning modal state or undo."""
    bl_idname = "mesh.smart_connect"
    bl_label = 'Connect Selection'
    bl_description = _SMART_CONNECT_OPERATOR_DESCRIPTION
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        del event
        return execute_smart_connect(context, report_cb=None, invoke=True)

    def execute(self, context):
        # UI buttons use EXEC_DEFAULT in many N-panel contexts. Route EXEC through
        # the same popup gate as INVOKE. The child dialog/confirm operator owns the
        # modal state and undo transaction; this dispatcher always terminates.
        return execute_smart_connect(context, report_cb=None, invoke=True)


class SMS_OT_legacy_mesh_connect(bpy.types.Operator):
    """Compatibility dispatcher for old shortcuts that call mesh.connect."""
    bl_idname = "mesh.connect"
    bl_label = 'Connect Selection'
    bl_description = _SMART_CONNECT_OPERATOR_DESCRIPTION
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return _feature_enabled(context) and obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        del event
        return execute_smart_connect(context, report_cb=None, invoke=True)

    def execute(self, context):
        return execute_smart_connect(context, report_cb=None, invoke=True)


def draw_smart_modeling_settings(layout, context):
    settings = _scene_settings(context)
    if settings is None:
        return
    layout.use_property_split = True
    layout.use_property_decorate = False
    layout.prop(settings, "segments")
    pinch_row = layout.row()
    try:
        pinch_row.enabled = int(getattr(settings, 'segments', 1)) >= 2
    except Exception:
        pinch_row.enabled = True
    pinch_row.prop(settings, "pinch")
    layout.prop(settings, "slide")
    toggle_row = layout.row(align=True)
    toggle_row.use_property_split = False
    toggle_row.prop(settings, "show_popup", toggle=True, icon='MENU_PANEL')


def _attach_scene_settings_property():
    try:
        if not hasattr(bpy.types.Scene, _SCENE_SETTINGS_PROP):
            setattr(
                bpy.types.Scene,
                _SCENE_SETTINGS_PROP,
                PointerProperty(
                    type=SMS_SmartConnectSceneSettings,
                    name="Mesh Connect Settings",
                    description="Scene-local settings for Mesh Connect. Values are kept while the scene remains open and are used by the popup and direct execution mode.",
                    options={'SKIP_SAVE'},
                ),
            )
    except Exception:
        pass


def _detach_scene_settings_property():
    try:
        if hasattr(bpy.types.Scene, _SCENE_SETTINGS_PROP):
            delattr(bpy.types.Scene, _SCENE_SETTINGS_PROP)
    except Exception:
        pass


def _smart_connect_operator_annotations():
    return {
        'segments': IntProperty(
            name=_SEGMENTS_NAME,
            description=_SEGMENTS_DESCRIPTION,
            default=1,
            min=1,
            max=64,
            options={'SKIP_SAVE'},
            update=_smart_connect_preview_property_update,
        ),
        'pinch': IntProperty(
            name=_PINCH_NAME,
            description=_PINCH_DESCRIPTION,
            default=0,
            min=-100,
            max=100,
            options={'SKIP_SAVE'},
            update=_smart_connect_preview_property_update,
        ),
        'slide': IntProperty(
            name=_SLIDE_NAME,
            description=_SLIDE_DESCRIPTION,
            default=0,
            min=-100,
            max=100,
            options={'SKIP_SAVE'},
            update=_smart_connect_preview_property_update,
        ),
        'algorithm': EnumProperty(
            name=_CONNECT_ALGORITHM_NAME,
            description=_CONNECT_ALGORITHM_DESCRIPTION,
            items=_CONNECT_ALGORITHM_ITEMS,
            default=_CONNECT_ALGORITHM_NORMAL,
            options={'SKIP_SAVE'},
        ),
        'flow_algorithm': EnumProperty(
            name=_FLOW_ALGORITHM_NAME,
            description=_FLOW_ALGORITHM_DESCRIPTION,
            items=_FLOW_ALGORITHM_ITEMS,
            default=_FLOW_ALGORITHM_CURRENT,
            options={'SKIP_SAVE'},
        ),
    }


try:
    MESH_OT_smart_connect_apply_continue.__annotations__ = _smart_connect_operator_annotations()
    MESH_OT_smart_connect_confirm.__annotations__ = _smart_connect_operator_annotations()
    MESH_OT_smart_connect_deferred_apply.__annotations__ = _smart_connect_operator_annotations()
    MESH_OT_smart_connect_dialog.__annotations__ = _smart_connect_operator_annotations()
except Exception:
    pass


_legacy_classes = (
    MESH_OT_smart_connect_apply_continue,
)

classes = (
    SMS_SmartConnectSceneSettings,
    MESH_OT_smart_connect_confirm,
    MESH_OT_smart_connect_deferred_apply,
    MESH_OT_smart_connect_cancel,
    MESH_OT_smart_connect_dialog,
    MESH_OT_smart_connect,
    SMS_OT_legacy_mesh_connect,
)


def _unregister_stale_connect_operator_class_names():
    # Names and operator IDs are not ownership evidence. Only exact local class
    # objects already recorded by this suite may be removed.
    removed = 0
    for candidate in tuple(_legacy_classes) + tuple(classes):
        if isinstance(candidate, type) and _connect_owned_class(candidate):
            _connect_exact_safe_unregister_class(candidate)
    return removed


def register():
    # Do not unregister existing operator RNA during on-demand loading. The suite
    # registration wrapper safely patches an existing lazy proxy in place; RNA
    # removal while that proxy is executing is a native use-after-free hazard.
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass
    for cls in _legacy_classes:
        if _connect_owned_class(cls):
            _connect_exact_safe_unregister_class(cls)
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass
    _attach_scene_settings_property()


def unregister():
    _smart_connect_preview_stop()
    _detach_scene_settings_property()
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    for cls in _legacy_classes:
        if _connect_owned_class(cls):
            _connect_exact_safe_unregister_class(cls)
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
