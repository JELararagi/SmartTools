import bpy

from .translation import TRANSLATIONS

# Cleared in unregister(); nothing populates it in this build, but the name must
# exist or disabling the tool raises NameError.
_ENUM_ITEMS_CACHE: dict = {}


_BEHAVIOR_ITEMS = (
    (
        'STRAIGHT',
        "Straight",
        "Keep sliding along the chosen edge direction. It can pass through the next vertex.",
        0,
    ),
    (
        'STOP',
        "Stop at Vertex",
        "Stop exactly on the next vertex. Each vertex stops independently.",
        1,
    ),
    (
        'CORNER',
        "Corner Slide",
        "When it reaches a vertex, turn and continue along the next connected edge.",
        2,
    ),
)

_BASELINE_ITEMS = (
    ('INDIVIDUAL', "Individual", "", 0),
    ('ACTIVE', "Active", "", 1),
)


def _translated(text):
    try:
        return bpy.app.translations.pgettext_iface(text)
    except Exception:
        try:
            return bpy.app.translations.pgettext(text)
        except Exception:
            return text


def _translation_owner():
    return str(__package__ or __name__).strip()


def _safe_register_translations():
    owner = _translation_owner()
    if not owner:
        return
    try:
        bpy.app.translations.unregister(owner)
    except Exception:
        pass
    bpy.app.translations.register(owner, TRANSLATIONS)


def _safe_unregister_translations():
    owner = _translation_owner()
    if not owner:
        return
    try:
        bpy.app.translations.unregister(owner)
    except Exception:
        pass


class SmartVertSlidePreferences(bpy.types.PropertyGroup):

    hit_behavior_normal: bpy.props.EnumProperty(
        name="Behavior (Normal)",
        description="What to do when a sliding vertex reaches the next vertex while Blender proportional editing is off.",
        items=_BEHAVIOR_ITEMS,
        default='STOP',
    )
    hit_behavior_proportional: bpy.props.EnumProperty(
        name="Behavior (Proportional)",
        description="What to do when a sliding vertex reaches the next vertex while Blender proportional editing is on.",
        items=_BEHAVIOR_ITEMS,
        default='CORNER',
    )

    use_proportional_editing: bpy.props.BoolProperty(
        name="Apply Proportional Editing",
        description="When Blender Proportional Editing (O) is ON, also slide vertices inside the proportional radius. Selected vertices always move at full strength. Works with Connected Only and Multi-Object Edit.",
        default=True,
    )

    edge_lock_enabled: bpy.props.BoolProperty(
        name="Edge Lock (Hysteresis)",
        description="Keep the chosen slide direction stable so the tool does not jump between candidate edges too easily while you move the mouse.",
        default=True,
    )
    edge_lock_keep_dot: bpy.props.FloatProperty(
        name="Keep Threshold (dot)",
        description="Keep using the previously chosen edge while its direction still matches the mouse direction above this threshold.",
        default=0.75,
        min=-1.0, max=1.0,
        subtype='FACTOR',
    )
    edge_lock_switch_margin: bpy.props.FloatProperty(
        name="Switch Margin",
        description="Require a noticeably better edge before switching away from the current one. Increase this to reduce jitter in dense topology.",
        default=0.08,
        min=0.0, max=1.0,
        subtype='FACTOR',
    )

    baseline: bpy.props.EnumProperty(
        name="Baseline",
        description="Choose how the slide direction is computed when multiple vertices are selected. Individual uses each local edge, while Active follows the active element more closely.",
        items=_BASELINE_ITEMS,
        default='INDIVIDUAL',
    )

    loop_priority: bpy.props.BoolProperty(
        name="Loop priority",
        description="Give extra priority to edges that continue the active edge loop. Useful for maintaining clean edge flow during retopo and cleanup.",
        default=False,
    )
    ring_priority: bpy.props.BoolProperty(
        name="Ring priority",
        description="Give extra priority to edges that continue the active edge ring. Useful when you want the movement to respect a ring-based structure.",
        default=False,
    )
    loop_ring_bonus: bpy.props.FloatProperty(
        name="Loop/Ring Bonus",
        description="Extra score added to loop- or ring-matching edges. Raise this if you want loop/ring preference to dominate direction picking more strongly.",
        default=0.25,
        min=0.0, max=2.0,
    )

    flow_bias: bpy.props.FloatProperty(
        name="Corner Flow Bias",
        description="When Corner behavior is used, bias the result toward the previous travel direction so the slide stays smoother through turns.",
        default=0.35,
        min=0.0, max=1.0,
        subtype='FACTOR',
    )

    sensitivity: bpy.props.FloatProperty(
        name="Sensitivity",
        description="Overall slide sensitivity. The default tracks the projected edge length like Blender vertex slide; larger values move farther for the same mouse motion, and smaller values allow finer control.",
        default=0.0045,
        min=0.0001, max=0.05,
    )
    slow_factor: bpy.props.FloatProperty(
        name="Slow factor",
        description="Precision multiplier used while holding Shift during the slide. Lower values make fine adjustments easier.",
        default=0.2,
        min=0.01, max=1.0,
        subtype='FACTOR',
    )
    snap_step: bpy.props.FloatProperty(
        name="Snap step",
        description="Step size used while Ctrl snapping is active. For example, 0.1 moves in increments of one tenth of the guiding edge length.",
        default=0.1,
        min=0.001, max=0.5,
        subtype='FACTOR',
    )

    show_hud: bpy.props.BoolProperty(
        name="Show HUD",
        description="Display a small on-screen HUD in the viewport so you can see the current mode, precision state, and other slide hints while working.",
        default=True,
    )
    show_guides: bpy.props.BoolProperty(
        name="Show Guides",
        description="Draw visual guide lines in the viewport, such as the chosen edge direction and helper indicators, while the tool is running.",
        default=True,
    )

    keymap_operator_id: bpy.props.StringProperty(
        name="Operator ID",
        description="Operator registration ID used when assigning a shortcut for Vertex Slide.",
        default="mesh.smart_vert_slide",
    )

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text=_translated("Settings"))
        col = box.column(align=True)
        col.prop(self, "use_proportional_editing", text=_translated("Apply Proportional Editing"))
        col.separator()
        col.label(text=_translated("On Hit Adjacent Vertex Behavior:"))
        col.prop(self, "hit_behavior_normal", text=_translated("Standard"))
        col.prop(self, "hit_behavior_proportional", text=_translated("Proportional"))

        box = layout.box()
        box.prop(self, "baseline")
        box.prop(self, "edge_lock_enabled")
        sub = box.column(align=True)
        sub.active = self.edge_lock_enabled
        sub.prop(self, "edge_lock_keep_dot")
        sub.prop(self, "edge_lock_switch_margin")

        box = layout.box()
        box.prop(self, "loop_priority")
        box.prop(self, "ring_priority")
        box.prop(self, "loop_ring_bonus")
        box.prop(self, "flow_bias")

        box = layout.box()
        box.prop(self, "sensitivity")
        box.prop(self, "slow_factor")
        box.prop(self, "snap_step")

        box = layout.box()
        box.prop(self, "show_hud")
        box.prop(self, "show_guides")



def _safe_reregister_class(cls):
    try:
        bpy.utils.register_class(cls)
        return
    except ValueError:
        # The suite registers this shared preferences PropertyGroup before
        # SMS_NPanelSettings attaches its PointerProperty.  Do not unregister and
        # recreate it here; doing so invalidates the already-created nested RNA
        # pointer and can crash Blender when the Vertex Slide settings are drawn.
        return
    except Exception:
        return


def register():
    _safe_reregister_class(SmartVertSlidePreferences)
    _safe_register_translations()


def unregister():
    _safe_unregister_translations()
    _ENUM_ITEMS_CACHE.clear()
    try:
        bpy.utils.unregister_class(SmartVertSlidePreferences)
    except Exception:
        pass
