import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from ..compat import get_uniform_color_shader

def safe_set_uniform(shader, name, value):
    try:
        shader.uniform_float(name, value)
    except Exception:
        return False
    return True

# Draw handler is managed by the operator.
def draw_lines_3d(lines, color=(1,1,1,1)):
    try:
        if not lines:
            return
        shader = get_uniform_color_shader('3D')
        batch = batch_for_shader(shader, 'LINES', {"pos": lines})
        shader.bind()
        safe_set_uniform(shader, "color", color)
        batch.draw(shader)
    except Exception:
        return

def draw_polyline_3d(points, color=(1,1,1,1)):
    if len(points) < 2:
        return
    verts = []
    for i in range(len(points)-1):
        verts.extend([points[i], points[i+1]])
    draw_lines_3d(verts, color=color)

def draw_circle_2d(center, radius, segments=64, color=(1,1,1,1)):
    try:
        import math
        if radius <= 0:
            return
        pts = []
        for i in range(segments):
            a0 = (i/segments) * math.tau
            a1 = ((i+1)/segments) * math.tau
            p0 = (center[0] + math.cos(a0)*radius, center[1] + math.sin(a0)*radius)
            p1 = (center[0] + math.cos(a1)*radius, center[1] + math.sin(a1)*radius)
            pts.extend([p0, p1])
        shader = get_uniform_color_shader('2D')
        batch = batch_for_shader(shader, 'LINES', {"pos": pts})
        shader.bind()
        safe_set_uniform(shader, "color", color)
        batch.draw(shader)
    except Exception:
        return

def draw_hud_text(text_lines, x=20, y=80):
    try:
        # Use blf for text
        import blf
        font_id = 0
        try:
            blf.size(font_id, 13)
        except TypeError:
            blf.size(font_id, 13, 72)
        except Exception:
            return
        try:
            # Do not inherit a transparent/black BLF color from another
            # POST_PIXEL owner when Smart Overlay replays this HUD last.
            blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        except Exception:
            pass
        dy = 16
        for i, line in enumerate(text_lines):
            blf.position(font_id, x, y - i*dy, 0)
            blf.draw(font_id, line)
    except Exception:
        return
