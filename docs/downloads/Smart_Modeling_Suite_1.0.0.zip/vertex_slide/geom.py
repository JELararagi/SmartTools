import math
import bpy
import bmesh
import mathutils
from mathutils import Vector
from mathutils.kdtree import KDTree

from .const import clamp

# -----------------------------
# Proportional falloff
# -----------------------------
def falloff_weight(t, falloff='SMOOTH'):
    """Return proportional influence for normalized distance ``t``.

    ``t`` is 0.0 at the selected source vertex and 1.0 at the
    proportional radius.  The returned weight is therefore 1.0 near the
    selection and fades toward 0.0 at the radius.
    """
    t = clamp(float(t), 0.0, 1.0)
    f = str(falloff or 'SMOOTH').upper()
    x = 1.0 - t

    if f == 'CONSTANT':
        return 1.0 if t < 1.0 else 0.0
    if f == 'LINEAR':
        return x
    if f == 'SHARP':
        return x * x
    if f == 'ROOT':
        return math.sqrt(max(0.0, x))
    if f == 'SPHERE':
        return math.sqrt(max(0.0, 1.0 - (t * t)))
    if f == 'INVERSE_SQUARE':
        # Blender's inverse-square feel is very strong near the selection, but
        # it still needs to fade out at the edge of the radius for this custom
        # slide implementation.
        d = max(1.0e-8, t)
        base = 1.0 / (1.0 + 20.0 * d * d)
        edge = 1.0 / 21.0
        return clamp((base - edge) / (1.0 - edge), 0.0, 1.0)

    # SMOOTH default.  The previous implementation was inverted and made
    # far vertices move as strongly as, or stronger than, near vertices.
    return x * x * (3.0 - 2.0 * x)

# -----------------------------
# KDTree helpers
# -----------------------------
def build_kdtree(verts):
    kd = KDTree(len(verts))
    for i, v in enumerate(verts):
        kd.insert(v, i)
    kd.balance()
    return kd

def vertices_within_radius(kd, sources, radius):
    """Return set of indices within radius of ANY source (3D)."""
    idx = set()
    r = float(radius)
    for s in sources:
        for (co, i, dist) in kd.find_range(s, r):
            idx.add(i)
    return idx

# -----------------------------
# Connected distance (bounded Dijkstra)
# -----------------------------
def connected_distances_cutoff(bm, source_verts, cutoff):
    """Return dict {vert_index: dist} for verts with dist <= cutoff along edges."""
    import heapq
    cutoff = float(cutoff)
    dist = {}
    heap = []
    for v in source_verts:
        dist[v.index] = 0.0
        heapq.heappush(heap, (0.0, v))
    while heap:
        d, v = heapq.heappop(heap)
        if d > cutoff:
            break
        if d != dist.get(v.index, None):
            continue
        for e in v.link_edges:
            ov = e.other_vert(v)
            nd = d + (ov.co - v.co).length
            if nd <= cutoff and (ov.index not in dist or nd < dist[ov.index]):
                dist[ov.index] = nd
                heapq.heappush(heap, (nd, ov))
    return dist

# -----------------------------
# Loop / Ring detection via Blender operator (robust)
# -----------------------------
def compute_loop_ring_sets(context, obj, bm, seed_edge, want_loop=True, want_ring=True):
    """Compute loop/ring edge index sets for a seed edge using bpy.ops.mesh.loop_multi_select.
    This is executed rarely (only when seed edge changes or toggles change) because it touches selection.
    Returns (loop_set, ring_set): sets of edge indices in bm.
    """
    loop_set = set()
    ring_set = set()

    if seed_edge is None:
        return loop_set, ring_set

    # Capture current selection state
    sel_mode = context.tool_settings.mesh_select_mode[:]
    sel_verts = [v.index for v in bm.verts if v.select]
    sel_edges = [e.index for e in bm.edges if e.select]
    sel_faces = [f.index for f in bm.faces if f.select]
    hist = None
    if bm.select_history:
        hist = bm.select_history.active

    def restore():
        # clear
        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False
        for i in sel_verts:
            if i < len(bm.verts): bm.verts[i].select = True
        for i in sel_edges:
            if i < len(bm.edges): bm.edges[i].select = True
        for i in sel_faces:
            if i < len(bm.faces): bm.faces[i].select = True
        if hist is not None:
            try:
                bm.select_history.clear()
                bm.select_history.add(hist)
            except Exception:
                pass
        context.tool_settings.mesh_select_mode = sel_mode
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    try:
        # Set edge select mode
        context.tool_settings.mesh_select_mode = (False, True, False)
        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False
        seed_edge.select = True
        bm.select_history.clear()
        bm.select_history.add(seed_edge)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        # Need active object
        prev_active = context.view_layer.objects.active
        context.view_layer.objects.active = obj

        if want_loop:
            bpy.ops.mesh.select_edge_loop_multi()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            loop_set = {e.index for e in bm.edges if e.select}

            # reset to seed for ring
            for e in bm.edges: e.select = False
            seed_edge.select = True
            bm.select_history.clear()
            bm.select_history.add(seed_edge)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        if want_ring:
            bpy.ops.mesh.select_edge_ring_multi()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            ring_set = {e.index for e in bm.edges if e.select}

        context.view_layer.objects.active = prev_active
    except Exception:
        # If operator fails, return empty sets (safe fallback)
        loop_set = set()
        ring_set = set()
    finally:
        restore()

    return loop_set, ring_set

# -----------------------------
# Path walking along graph (edge slide)
# -----------------------------
def walk_along_edges(v_start, v_next, distance, adjacency, mode, pick_next_edge_fn, max_steps=64):
    """Return a point starting at v_start moving towards v_next by distance along edges.
    adjacency: dict vert_index -> list of neighbor vert_index
    pick_next_edge_fn: function(prev_vi, cur_vi, prev_dir3, step)-> next_vi or None
    """
    if v_start == v_next:
        return v_start.co.copy()

    cur_vi = v_start.index
    next_vi = v_next.index
    cur_co = v_start.co.copy()
    remaining = float(distance)
    prev_vi = None
    prev_dir3 = (v_next.co - v_start.co)
    if prev_dir3.length == 0:
        return cur_co
    prev_dir3.normalize()

    steps = 0
    while remaining != 0.0 and steps < max_steps:
        steps += 1
        nco = adjacency[cur_vi]["co"][next_vi]
        seg = (nco - cur_co)
        seg_len = seg.length
        if seg_len < 1e-10:
            # at vertex
            if abs(remaining) < 1e-10:
                break
            # choose next
            nn = pick_next_edge_fn(prev_vi, cur_vi, prev_dir3, steps)
            if nn is None:
                break
            prev_vi, cur_vi, next_vi = cur_vi, cur_vi, nn
            cur_co = adjacency[cur_vi]["co"][cur_vi]  # should be vertex co
            continue

        step_dir = seg.normalized()
        # If remaining sign opposite to segment direction, we treat as moving backwards (swap)
        # But in this tool we always move forward along chosen next, so assume remaining positive
        if remaining >= 0:
            if remaining <= seg_len or mode == 'STOP':
                # within segment
                t = clamp(remaining / seg_len, 0.0, 1.0) if mode == 'STOP' else remaining / seg_len
                cur_co = cur_co + step_dir * (t * seg_len)
                remaining = 0.0
                break
            else:
                # pass vertex
                cur_co = nco.copy()
                remaining -= seg_len
        else:
            # negative: go backwards
            if abs(remaining) <= seg_len or mode == 'STOP':
                t = clamp(abs(remaining) / seg_len, 0.0, 1.0) if mode == 'STOP' else abs(remaining) / seg_len
                cur_co = cur_co - step_dir * (t * seg_len)
                remaining = 0.0
                break
            else:
                cur_co = nco.copy()
                remaining += seg_len  # remaining is negative

        # at vertex, select next based on mode
        if remaining != 0.0:
            prev_vi = cur_vi
            cur_vi = next_vi
            # update prev_dir3 based on last segment
            prev_dir3 = step_dir if remaining >= 0 else -step_dir
            nn = pick_next_edge_fn(prev_vi, cur_vi, prev_dir3, steps)
            if nn is None:
                break
            next_vi = nn

    return cur_co
