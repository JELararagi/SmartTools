ADDON_ID = __package__  # resolves to the nested module package when bundled in the suite

import sys

from ..utils import get_suite_prefs

_PREF_ALIASES = {
    "use_proportional_effect": "use_proportional_editing",
}

_DEFAULT_PREFS = {
    "hit_behavior_normal": 'STOP',
    "hit_behavior_proportional": 'CORNER',
    "use_proportional_editing": True,
    "edge_lock_enabled": True,
    "edge_lock_keep_dot": 0.75,
    "edge_lock_switch_margin": 0.08,
    "baseline": 'INDIVIDUAL',
    "loop_priority": False,
    "ring_priority": False,
    "loop_ring_bonus": 0.25,
    "flow_bias": 0.35,
    "sensitivity": 0.0045,
    "slow_factor": 0.2,
    "snap_step": 0.1,
    "show_hud": True,
    "show_guides": True,
    "keymap_operator_id": "mesh.smart_vert_slide",
}
_RUNTIME_PREF_FALLBACKS = {}


def _normalize_pref_key(name):
    key = str(name or "").strip()
    return _PREF_ALIASES.get(key, key)


def get_prefs(context):
    """Return Vertex Slide prefs stored inside Smart Modeling preferences."""
    try:
        prefs = get_suite_prefs(context)
        if not prefs:
            return None
        core_mod = sys.modules.get(f"{ADDON_ID.rsplit('.', 1)[0]}.core")
        if core_mod is not None:
            try:
                toggle_active = bool(getattr(core_mod, "_sms_toggle_update_active", lambda: False)())
                sync_active = bool(getattr(core_mod, "_sms_runtime_sync_active", lambda: False)())
            except Exception:
                toggle_active = True
                sync_active = True
            if toggle_active or sync_active:
                return None
            safe_get = getattr(core_mod, "_sms_safe_get_rna_attr", None)
            if callable(safe_get):
                return safe_get(prefs, "vertex_slide", None)
        return None
    except Exception:
        return None


def pref_get(prefs, name, default=None):
    key = _normalize_pref_key(name)
    if not key:
        return default
    if prefs is not None:
        try:
            return getattr(prefs, key)
        except Exception:
            pass
    if key in _RUNTIME_PREF_FALLBACKS:
        return _RUNTIME_PREF_FALLBACKS[key]
    if key in _DEFAULT_PREFS:
        return _DEFAULT_PREFS[key]
    return default


def pref_set(prefs, name, value):
    key = _normalize_pref_key(name)
    if not key:
        return False
    if prefs is not None:
        try:
            setattr(prefs, key, value)
            if key in _RUNTIME_PREF_FALLBACKS:
                _RUNTIME_PREF_FALLBACKS.pop(key, None)
            return True
        except Exception:
            pass
    _RUNTIME_PREF_FALLBACKS[key] = value
    return False


def clamp(x, a, b):
    return a if x < a else b if x > b else x
