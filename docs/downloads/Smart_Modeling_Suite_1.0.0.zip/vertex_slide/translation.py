TRANSLATIONS = {
    "ja_JP": {
        ("*", "Vertex Slide"): "頂点スライド",
        ("*", "Enhanced Vertex Slide with Multi-Object Edit, Proportional, HUD, Loop/Ring priority"):
            "マルチ編集・プロポ・HUD・ループ/リング優先に対応した頂点スライド",
        ("*", "Start Vertex Slide (Modal)"): '頂点スライドを開始（モーダル）',
        ("*", "Behavior (Normal)"): "挙動（通常）",
        ("*", "Behavior (Proportional)"): "挙動（プロポON）",
        ("*", "Straight"): "直進",
        ("*", "Stop"): "停止",
        ("*", "Corner"): "コーナー",
        ("*", "Active"): "アクティブ",
        ("*", "Individual"): "個別",
        ("*", "Loop priority"): "ループ優先",
        ("*", "Ring priority"): "リング優先",
        ("*", "Show HUD"): "HUD表示",
        ("*", "Show Guides"): "ガイド表示",
        ("*", "Edge Lock (Hysteresis)"): "エッジロック（安定化）",
        ("*", "Snap step"): "スナップ刻み",
        ("*", "Slow factor"): "スロー倍率",
        ("*", "Sensitivity"): "感度",
        ("*", "Baseline"): "基準",
        ("*", "Proportional Effect"): "プロポ反映",
        ("*", "Press C to cycle behavior. Shift+C toggles proportional effect."): 'Cで挙動を切替。Shift+CでプロポーショナルをON/OFF。',
        ("*", "L toggles Loop priority. R toggles Ring priority. B toggles baseline (Individual/Active)."):
            "Lでループ優先、Rでリング優先、Bで基準（個別/アクティブ）を切替。",
        ("*", "Shift = slow, Ctrl = snap, Alt = invert, Wheel = radius, Type numbers = ratio."):
            "Shift=スロー、Ctrl=スナップ、Alt=反転、ホイール=半径、数値入力=比率。",
    }
}

TRANSLATIONS["ja_JP"].update({
    ("*", "Enhanced Vertex Slide with multi-object edit support, optional proportional influence, a viewport HUD, and loop/ring-aware direction picking."):
        'マルチオブジェクト編集、任意のプロポーショナル影響、ビューポート HUD、ループ / リング考慮の方向選択に対応した強化版頂点スライドです。',
    ("*", "Behavior used when this tool's proportional effect is turned off. Straight is stable, Stop limits corner changes, and Corner follows bends more aggressively."):
        "このツール独自のプロポーショナル効果がオフのときに使う挙動です。Straight は安定重視、Stop はコーナー変化を抑え、Corner は曲がりに積極的に追従します。",
    ("*", "Behavior used when this tool's proportional effect is turned on. Choose how the slide should react when the active direction reaches corners or branches."):
        "このツール独自のプロポーショナル効果がオンのときに使う挙動です。進行方向がコーナーや分岐へ到達した際の反応を選びます。",
    ("*", "Also influence nearby vertices while sliding so the movement falls off smoothly instead of affecting only the directly selected elements."):
        "スライド中に近傍頂点にも影響を与え、直接選択要素だけでなく滑らかに減衰する移動を行います。",
    ("*", "Keep the chosen slide direction stable so the tool does not jump between candidate edges too easily while you move the mouse."):
        "選ばれたスライド方向を安定させ、マウス移動中に候補エッジ間を不用意に飛び移らないようにします。",
    ("*", "Keep using the previously chosen edge while its direction still matches the mouse direction above this threshold."):
        "以前選ばれたエッジ方向がマウス方向とこのしきい値以上で一致している間は、そのエッジを継続使用します。",
    ("*", "Require a noticeably better edge before switching away from the current one. Increase this to reduce jitter in dense topology."):
        "現在のエッジから切り替えるには明確に良い候補を要求します。密なトポロジーでのブレを減らしたい場合は値を上げてください。",
    ("*", "Choose how the slide direction is computed when multiple vertices are selected. Individual uses each local edge, while Active follows the active element more closely."):
        '複数の頂点を選択している時のスライドの向きの決め方です。「個別」は頂点ごとの近くの辺を、「アクティブ」はアクティブな要素を基準にします。',
    ("*", "Give extra priority to edges that continue the active edge loop. Useful for maintaining clean edge flow during retopo and cleanup."):
        "アクティブエッジループの延長にある辺を優先します。リトポや整理時にきれいなエッジフローを維持しやすくなります。",
    ("*", "Give extra priority to edges that continue the active edge ring. Useful when you want the movement to respect a ring-based structure."):
        "アクティブエッジリングの延長にある辺を優先します。リング構造を尊重した移動をしたいときに役立ちます。",
    ("*", "Extra score added to loop- or ring-matching edges. Raise this if you want loop/ring preference to dominate direction picking more strongly."):
        "ループまたはリング一致エッジへ加算する追加スコアです。方向選択でループ / リング優先を強めたい場合は値を上げます。",
    ("*", "When Corner behavior is used, bias the result toward the previous travel direction so the slide stays smoother through turns."):
        'コーナーの動作使用時に、前回の進行方向を優先して曲がり部分でも滑らかにスライドしやすくします。',
    ("*", "Overall slide sensitivity. Larger values move farther for the same mouse motion; smaller values allow finer control."):
        "全体のスライド感度です。同じマウス移動でも値が大きいほど遠くへ動き、小さいほど細かく制御できます。",
    ("*", "Precision multiplier used while holding Shift during the slide. Lower values make fine adjustments easier."):
        "スライド中に Shift を押した際の精密操作倍率です。値が低いほど細かな調整がしやすくなります。",
    ("*", "Step size used while Ctrl snapping is active. For example, 0.1 moves in increments of one tenth of the guiding edge length."):
        "Ctrl スナップ中の刻み幅です。たとえば 0.1 なら、基準エッジ長の 10 分の 1 単位で移動します。",
    ("*", "Display a small on-screen HUD in the viewport so you can see the current mode, precision state, and other slide hints while working."):
        "ビューポート上に小さな HUD を表示し、現在モードや精密操作状態などのヒントを作業中に確認できます。",
    ("*", "Draw visual guide lines in the viewport, such as the chosen edge direction and helper indicators, while the tool is running."):
        "ツール実行中、選択されたエッジ方向や補助インジケーターなどのガイド線をビューポートへ描画します。",
})


TRANSLATIONS["ja_JP"].update({
    ("*", "Settings"): "設定",
    ("*", "Apply Proportional Editing"): "プロポーション編集を反映",
    ("*", "When Blender Proportional Editing (O) is ON, also slide vertices inside the proportional radius. Selected vertices always move at full strength. Works with Connected Only and Multi-Object Edit."):
        "Blenderのプロポーション編集（O）がONのとき、影響半径内の頂点も一緒にスライドします。選択頂点は常に強さ100%で動きます。『接続のみ』とマルチオブジェクト編集にも対応します。",
    ("*", "On Hit Adjacent Vertex Behavior:"): "隣接頂点に当たった時の挙動:",
    ("*", "Standard"): '通常',
    ("*", "Normal"): '通常',
    ("*", "Proportional"): 'プロポーショナル',
    ("*", "Stop at Vertex"): '頂点で止める',
    ("*", "Corner Slide"): '角でスライド',
    ("*", "Keep sliding along the chosen edge direction. It can pass through the next vertex."):
        '選んだ辺の向きにスライドし続けます。次の頂点を通り過ぎることもあります。',
    ("*", "Stop exactly on the next vertex. Each vertex stops independently."):
        '次の頂点でぴったり止めます。頂点ごとに別々に止まります。',
    ("*", "When it reaches a vertex, turn and continue along the next connected edge."):
        '頂点に着いたら曲がり、つながった次の辺に沿って進みます。',
    ("*", "What to do when a sliding vertex reaches the next vertex while Blender proportional editing is off."):
        "Blenderのプロポーション編集がオフのとき、スライド頂点が次の頂点に到達した際の挙動です。",
    ("*", "What to do when a sliding vertex reaches the next vertex while Blender proportional editing is on."):
        "Blenderのプロポーション編集がオンのとき、スライド頂点が次の頂点に到達した際の挙動です。",
    ("*", "Shortcut Registration Guide"): "ショートカット登録方法",
    ("*", "Current Default: Shift + V"): "現在のデフォルト: Shift + V",
    ("*", "1) Preferences > Keymap > 3D View > Mesh > Mesh (Global)"): '1) プリファレンス > キーマップ > 3D ビュー > メッシュ > メッシュ（グローバル）',
    ("*", "2) Click 'Add New' at the bottom"): '2) 一番下の「新規追加」をクリックします。',
    ("*", "3) Paste the Operator ID into 'Identifier'"): '3) 「識別子」にコマンド ID を貼り付けます。',
    ("*", "4) Assign your preferred key"): "4) お好みのキーを設定してください",
    ("*", "Operator ID"): 'コマンド ID',
    ("*", "Slide Calculation"): "スライド計算",
    ("*", "Controls"): "操作設定",
    ("*", "Display"): "表示",
    ("*", "To use proportional support, turn Blender Proportional Editing on with O before starting the tool."):
        "プロポーショナル対応を使う場合は、ツール開始前に O で Blender のプロポーション編集をオンにしてください。",
    ("*", "When Blender Proportional Editing is ON and Apply Proportional Editing is enabled, nearby vertices inside the radius also slide."):
        "Blenderのプロポーション編集がONで『プロポーション編集を反映』が有効な場合、半径内の近傍頂点も一緒にスライドします。",
    ("*", "Quick Start"): "クイックスタート",
    ("*", "Behavior"): "挙動",
    ("*", "Tip: Open \"Guide / Tips\" below for full controls and setup."): "詳しい操作と設定は下の『ガイド / ヒント』を開いて確認してください。",
})

TRANSLATIONS["ja_JP"].update({
    ("*", "Toggle Vertex Slide"): "頂点スライドを切替",
    ("*", "Vertex Slide Constraint"): "頂点スライド制約",
    ("*", "Vertex Slide Constraint: ON"): "頂点スライド制約: ON",
    ("*", "Vertex Slide Constraint: OFF"): "頂点スライド制約: OFF",
    ("*", "Toggle Vertex Slide Constraint. While ON in Edit Mode, normal Move, Rotate, Scale, and transform gizmo operations are constrained so moved vertices slide along connected mesh edges."):
        "頂点スライド制約を切り替えます。ONの間は編集モードの通常移動、回転、スケール、トランスフォームギズモによる頂点操作を、接続エッジ上のスライド移動へ補正します。",
    ("*", "Enter Edit Mode on a mesh object before enabling Vertex Slide Constraint."):
        "頂点スライド制約を有効にする前に、メッシュオブジェクトの編集モードに入ってください。",
    ("*", "Could not start Vertex Slide Constraint monitor."):
        "頂点スライド制約の監視を開始できませんでした。",
    ("*", "Vertex Slide Constraint enabled."): "頂点スライド制約を有効にしました。",
    ("*", "Vertex Slide Constraint disabled."): "頂点スライド制約を無効にしました。",
    ("*", "1) Select vertices/edges   2) Turn ON   3) Use G/R/S or the transform gizmo"):
        "1) 頂点/辺を選択   2) ONにする   3) G/R/S またはトランスフォームギズモで操作",
    ("*", "While ON, normal Move, Rotate, Scale, and Transform gizmo edits slide along connected edges."):
        "ONの間、通常の移動・回転・スケール・トランスフォームギズモ操作が接続エッジ上のスライドへ補正されます。",
    ("*", "To use proportional support, turn Blender Proportional Editing on with O."):
        "プロポーショナル対応を使う場合は、OキーでBlenderのプロポーショナル編集をONにしてください。",
    ("*", "Vertex Slide is a toggle constraint for normal vertex transforms."):
        "頂点スライドは通常の頂点トランスフォームに対するトグル式制約です。",
    ("*", "It projects G/R/S and gizmo edits onto connected mesh edges so forms can be adjusted without leaving the flow."):
        "G/R/Sとギズモ操作を接続エッジ上へ投影し、流れを崩さず形状を調整できます。",
    ("*", "• Turn Vertex Slide Constraint ON from the button or your keymap."):
        "• ボタンまたはキーマップから頂点スライド制約をONにします。",
    ("*", "• Use Blender's normal G/R/S keys or the transform gizmo; moved vertices are corrected onto connected edges."):
        "• Blender標準のG/R/Sキーまたはトランスフォームギズモを使います。動いた頂点は接続エッジ上へ補正されます。",
    ("*", "• Turn Blender Proportional Editing on with O when nearby vertices should also slide."):
        "• 近傍頂点もスライドさせたい場合は、OキーでBlenderのプロポーショナル編集をONにします。",
    ("*", "Constraint notes"): "制約メモ",
    ("*", "The ON/OFF button is a toggle. Turn it OFF to return to normal transforms."):
        "ON/OFFボタンはトグルです。OFFにすると通常のトランスフォームへ戻ります。",
    ("*", "Behavior settings below control how far vertices may continue when they hit adjacent vertices."):
        "下の挙動設定では、隣接頂点に到達したときにどこまで継続するかを調整します。",
    ("*", "Loop and Ring priority bias the chosen slide edge when several connected edges are possible."):
        "複数の接続エッジ候補がある場合、ループ/リング優先で選ばれるスライドエッジを補正します。",
    ("*", "Proportional Editing uses Blender's current O-key radius and falloff."):
        'プロポーショナル編集は Blender の O キーの半径と減衰を使います。',
    ("*", "Native transform shortcuts and gizmos remain usable while the constraint is ON."):
        "制約ON中も通常のトランスフォームショートカットとギズモをそのまま使用できます。",
    ("*", "Shortcut setup"): "ショートカット設定",
    ("*", "Assign mesh.smart_vert_slide to any shortcut you want to use as the ON/OFF toggle."):
        "ON/OFFトグルとして使いたいショートカットに mesh.smart_vert_slide を割り当てます。",
    ("*", "Open: Edit > Preferences > Keymap > 3D View > Mesh"):
        "開く場所: 編集 > プリファレンス > キーマップ > 3Dビュー > メッシュ",
    ("*", 'Use the Operator ID: "mesh.smart_vert_slide".'):
        'コマンド ID "mesh.smart_vert_slide" を使います。',
    ("*", "The shortcut toggles the constraint ON or OFF; normal G/R/S and gizmos do the transform."):
        "ショートカットは制約のON/OFFを切り替えます。実際の変形は通常のG/R/Sやギズモで行います。",
})
