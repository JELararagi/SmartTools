import bpy
from .const import get_prefs


def _t(msgid: str) -> str:
    return bpy.app.translations.pgettext(msgid)


def _feature_enabled(context) -> bool:
    try:
        from ..utils import feature_enabled
        return feature_enabled(context, "enable_vertex_slide", True)
    except Exception:
        return True


class VIEW3D_PT_svs_panel(bpy.types.Panel):
    """Main panel for Vertex Slide (N-panel)."""

    bl_label = "Vertex Slide"
    bl_description = 'Main Vertex Slide panel for fast constrained sliding, HUD options, and proportional support.'
    bl_idname = "VIEW3D_PT_svs_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _feature_enabled(context)

    def draw(self, context):
        prefs = get_prefs(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        if prefs is None:
            layout.label(text=_t("Loading tool settings."), icon='TIME')
            return

        box = layout.box()
        box.label(text=_t("Quick Start"), icon='PLAY')
        wm = getattr(context, 'window_manager', None)
        scene = getattr(context, 'scene', None)
        enabled = bool(getattr(wm, 'svs_vertex_slide_constraint_enabled', getattr(scene, 'svs_vertex_slide_constraint_enabled', False)))
        row = box.row(align=True)
        row.scale_y = 1.25
        row.operator(
            "mesh.smart_vert_slide",
            text=_t("Vertex Slide Constraint: ON") if enabled else _t("Vertex Slide Constraint: OFF"),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            depress=enabled,
        )

        box = layout.box()
        box.label(text=_t("Settings"), icon='PREFERENCES')
        col = box.column(align=True)
        col.prop(prefs, "use_proportional_editing", text=_t("Apply Proportional Editing"))
        col.separator()
        col.label(text=_t("On Hit Adjacent Vertex Behavior:"))
        col.prop(prefs, "hit_behavior_normal", text=_t("Standard"))
        col.prop(prefs, "hit_behavior_proportional", text=_t("Proportional"))

        box = layout.box()
        box.label(text=_t("Slide Calculation"), icon='PIVOT_ACTIVE')
        box.prop(prefs, "baseline")
        box.prop(prefs, "edge_lock_enabled")
        sub = box.column(align=True)
        sub.active = bool(getattr(prefs, 'edge_lock_enabled', True))
        sub.prop(prefs, "edge_lock_keep_dot")
        sub.prop(prefs, "edge_lock_switch_margin")
        box.prop(prefs, "loop_priority")
        box.prop(prefs, "ring_priority")
        box.prop(prefs, "loop_ring_bonus")
        box.prop(prefs, "flow_bias")

        box = layout.box()
        box.label(text=_t("Controls"), icon='EVENT_K')
        box.prop(prefs, "sensitivity")
        box.prop(prefs, "slow_factor")
        box.prop(prefs, "snap_step")

        box = layout.box()
        box.label(text=_t("Display"), icon='HIDE_OFF')
        box.prop(prefs, "show_hud")
        box.prop(prefs, "show_guides")




def register():
    bpy.utils.register_class(VIEW3D_PT_svs_panel)


def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_svs_panel)
