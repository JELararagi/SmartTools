import bpy
from .const import get_prefs


def _t(msgid: str) -> str:
    return bpy.app.translations.pgettext(msgid)


def _feature_enabled(context) -> bool:
    try:
        from ..utils import feature_enabled
        return feature_enabled(context, "enable_vertex_slide", True)
    except Exception:
        return True


class VIEW3D_PT_svs_panel(bpy.types.Panel):
    """Main panel for Vertex Slide (N-panel)."""

    bl_label = "Vertex Slide"
    bl_description = 'Main Vertex Slide panel for fast constrained sliding, HUD options, and proportional support.'
    bl_idname = "VIEW3D_PT_svs_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'

    @classmethod
    def poll(cls, context):
        return _feature_enabled(context)

    def draw(self, context):
        prefs = get_prefs(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        if prefs is None:
            layout.label(text=_t("Loading tool settings."), icon='TIME')
            return

        box = layout.box()
        box.label(text=_t("Quick Start"), icon='PLAY')
        wm = getattr(context, 'window_manager', None)
        scene = getattr(context, 'scene', None)
        enabled = bool(getattr(wm, 'svs_vertex_slide_constraint_enabled', getattr(scene, 'svs_vertex_slide_constraint_enabled', False)))
        row = box.row(align=True)
        row.scale_y = 1.25
        row.operator(
            "mesh.smart_vert_slide",
            text=_t("Vertex Slide Constraint: ON") if enabled else _t("Vertex Slide Constraint: OFF"),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            depress=enabled,
        )

        box = layout.box()
        box.label(text=_t("Settings"), icon='PREFERENCES')
        col = box.column(align=True)
        col.prop(prefs, "use_proportional_editing", text=_t("Apply Proportional Editing"))
        col.separator()
        col.label(text=_t("On Hit Adjacent Vertex Behavior:"))
        col.prop(prefs, "hit_behavior_normal", text=_t("Standard"))
        col.prop(prefs, "hit_behavior_proportional", text=_t("Proportional"))

        box = layout.box()
        box.label(text=_t("Slide Calculation"), icon='PIVOT_ACTIVE')
        box.prop(prefs, "baseline")
        box.prop(prefs, "edge_lock_enabled")
        sub = box.column(align=True)
        sub.active = bool(getattr(prefs, 'edge_lock_enabled', True))
        sub.prop(prefs, "edge_lock_keep_dot")
        sub.prop(prefs, "edge_lock_switch_margin")
        box.prop(prefs, "loop_priority")
        box.prop(prefs, "ring_priority")
        box.prop(prefs, "loop_ring_bonus")
        box.prop(prefs, "flow_bias")

        box = layout.box()
        box.label(text=_t("Controls"), icon='EVENT_K')
        box.prop(prefs, "sensitivity")
        box.prop(prefs, "slow_factor")
        box.prop(prefs, "snap_step")

        box = layout.box()
        box.label(text=_t("Display"), icon='HIDE_OFF')
        box.prop(prefs, "show_hud")
        box.prop(prefs, "show_guides")


        layout.separator()
        layout.label(text=_t('Tip: Open "Guide / Tips" below for full controls and setup.'), icon='QUESTION')


class VIEW3D_PT_svs_help(bpy.types.Panel):
    """Beginner-friendly guide & tips."""

    bl_label = "Guide / Tips"
    bl_description = 'Guide / Tips help panel with workflow notes and beginner guidance.'
    bl_idname = "VIEW3D_PT_svs_help"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Modeling'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _feature_enabled(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text=_t("What this tool is"))
        col = box.column(align=True)
        col.label(text=_t("Vertex Slide is a toggle constraint for normal vertex transforms."))
        col.label(text=_t("It projects G/R/S and gizmo edits onto connected mesh edges so forms can be adjusted without leaving the flow."))

        box = layout.box()
        box.label(text=_t("How to use (basic)"), icon='MOUSE_LMB')
        col = box.column(align=True)
        col.label(text=_t("• Select vertices/edges in Edit Mode."))
        col.label(text=_t("• Turn Vertex Slide Constraint ON from the button or your keymap."))
        col.label(text=_t("• Use Blender's normal G/R/S keys or the transform gizmo; moved vertices are corrected onto connected edges."))
        col.label(text=_t("• Turn Blender Proportional Editing on with O when nearby vertices should also slide."))

        box = layout.box()
        box.label(text=_t("Constraint notes"), icon='EVENT_K')
        col = box.column(align=True)
        col.label(text=_t("The ON/OFF button is a toggle. Turn it OFF to return to normal transforms."))
        col.label(text=_t("Behavior settings below control how far vertices may continue when they hit adjacent vertices."))
        col.label(text=_t("Loop and Ring priority bias the chosen slide edge when several connected edges are possible."))
        col.label(text=_t("Proportional Editing uses Blender's current O-key radius and falloff."))
        col.label(text=_t("Native transform shortcuts and gizmos remain usable while the constraint is ON."))



def register():
    bpy.utils.register_class(VIEW3D_PT_svs_panel)
    bpy.utils.register_class(VIEW3D_PT_svs_help)


def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_svs_help)
    bpy.utils.unregister_class(VIEW3D_PT_svs_panel)
