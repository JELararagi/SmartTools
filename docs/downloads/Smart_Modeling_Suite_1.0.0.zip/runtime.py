# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import bpy

_REMOVED_VENDOR_DIRS: tuple[str, ...] = (
    'bonsai',
    'e_topology_smooth',
    'modern_primitive',
)


def package_root(file_path: str) -> Path:
    return Path(file_path).resolve().parent


def _candidate_addon_ids(package_name: str | None, module_name: str | None, file_path: str | None) -> tuple[str, ...]:
    values: list[str] = []
    for raw in (
        package_name,
        module_name,
        Path(file_path).resolve().parent.name if file_path else '',
        Path(file_path).stem if file_path else '',
    ):
        text = str(raw or '').strip()
        if not text:
            continue
        if text not in values:
            values.append(text)
        if '.' in text:
            head = text.split('.', 1)[0].strip()
            if head and head not in values:
                values.append(head)
    return tuple(values)


def _remove_path(target: Path) -> None:
    if not target.exists():
        return
    try:
        if target.is_dir():
            shutil.rmtree(target, ignore_errors=True)
        else:
            target.unlink(missing_ok=True)
    except Exception:
        pass


def _purge_removed_modules(package_ids: tuple[str, ...]) -> None:
    stale_names: list[str] = []
    for module_name in tuple(sys.modules.keys()):
        name = str(module_name or '').strip()
        if not name:
            continue
        matched = False
        for removed in _REMOVED_VENDOR_DIRS:
            if name == removed or name.startswith(removed + '.'):
                matched = True
                break
            for package_id in package_ids:
                prefix = f'{package_id}.{removed}'
                if name == prefix or name.startswith(prefix + '.'):
                    matched = True
                    break
            if matched:
                break
        if matched:
            stale_names.append(name)
    for name in stale_names:
        try:
            sys.modules.pop(name, None)
        except Exception:
            pass


def _cleanup_compiled_cache(root: Path) -> None:
    # Runtime bytecode caches are not distribution payload.  Python validates
    # them against the source timestamp/hash, so deleting them on every Blender
    # start only forces recompilation and makes the first tool interaction slow.
    # Release ZIP generation still excludes __pycache__ and *.pyc.
    del root


def preflight_cleanup(package_name: str | None, module_name: str | None, file_path: str | None):
    root = package_root(file_path or __file__)
    package_ids = _candidate_addon_ids(package_name, module_name, file_path)
    _purge_removed_modules(package_ids)

    for removed in _REMOVED_VENDOR_DIRS:
        _remove_path(root / removed)

    _cleanup_compiled_cache(root)
    return root


def get_addon_preferences(context=None, package_name: str | None = None, module_name: str | None = None, file_path: str | None = None):
    """Return the suite N-panel settings proxy.

    The extension deliberately does not use Blender legacy preference properties;
    bundled tools access their shared settings through the WindowManager N-panel
    property group registered by core.py.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        from .utils import get_suite_prefs
        prefs = get_suite_prefs(ctx)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        return getattr(wm, 'smart_modeling_suite_npanel_settings', None) if wm is not None else None
    except Exception:
        return None
