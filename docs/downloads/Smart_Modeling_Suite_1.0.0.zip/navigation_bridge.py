# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
"""Standard N-panel bridge for Smart Modeling.

The bridge only keeps compatibility metadata and asks Blender to redraw ordinary
3D View Sidebar panels registered by ``core``.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, Tuple
import time

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

from .bootstrap_common import (
    class_belongs_to_current_package as _exact_class_belongs_to_current_package,
    cleanup_stale_owned_classes as _cleanup_stale_owned_classes,
    disable_owned_panel_class as _disable_exact_owned_panel_class,
)

_ENTRIES: Dict[str, Dict[str, Any]] = {}



def _iter_view3d_areas():
    if bpy is None:
        return
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    yield area
            except Exception:
                continue


def _tag_redraws() -> None:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None) if bpy is not None else None
        unsafe_until = float((ns or {}).get('SMART_MODELING_SUITE_RNA_UNSAFE_UNTIL', 0.0) or 0.0) if isinstance(ns, dict) else 0.0
        if unsafe_until and time.monotonic() < unsafe_until:
            return
    except Exception:
        return
    for area in _iter_view3d_areas() or ():
        try:
            area.tag_redraw()
        except Exception:
            pass



def _panel_class_belongs_to_current_package(cls) -> bool:
    return _exact_class_belongs_to_current_package(cls)

def _disable_resident_panel_class(cls) -> bool:
    return _disable_exact_owned_panel_class(cls)



def _purge_stale_proxy_panels() -> int:
    return _cleanup_stale_owned_classes(panels_only=True)


def _normalise_classes(panel_classes: Iterable[type] | None = None) -> Tuple[type, ...]:
    result = []
    seen = set()
    for cls in tuple(panel_classes or ()):  # defensive copy
        if not isinstance(cls, type):
            continue
        if cls in seen:
            continue
        seen.add(cls)
        result.append(cls)
    return tuple(result)


def install(addon_key: str, label: str, icon: str = 'NONE', operator_id: str = '', panel_classes: Iterable[type] | None = None, *, order: int = 100, draw_callback: Callable[..., Any] | None = None, **_kwargs) -> bool:
    key = str(addon_key or '').strip()
    if not key:
        return False
    _ENTRIES[key] = {
        'addon_key': key,
        'label': str(label or key),
        'icon': str(icon or 'NONE'),
        'operator_id': str(operator_id or ''),
        'order': int(order or 100),
        'panel_classes': _normalise_classes(panel_classes),
        'draw_callback': draw_callback,
    }
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def uninstall(addon_key: str, **_kwargs) -> bool:
    key = str(addon_key or '').strip()
    if key:
        _ENTRIES.pop(key, None)
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def refresh_runtime(*_args, **_kwargs) -> bool:
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def force_runtime_refresh(*args, **kwargs) -> bool:
    return refresh_runtime(*args, **kwargs)


def flush_redraws(*_args, **_kwargs) -> bool:
    _tag_redraws()
    return True


def open_window(*_args, **_kwargs) -> bool:
    _purge_stale_proxy_panels()
    _tag_redraws()
    return True


def toggle_active(*args, **kwargs) -> bool:
    return refresh_runtime(*args, **kwargs)


def backend_summary() -> str:
    return 'standard-n-panel'


def shutdown_runtime() -> None:
    _ENTRIES.clear()
    _purge_stale_proxy_panels()
    _tag_redraws()


def _draw_smart_tools_window_contents(*_args, **_kwargs) -> int:
    return 0


def register() -> None:
    refresh_runtime()


def unregister() -> None:
    shutdown_runtime()
