# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Coordinate the suite loader with the older UI registration facade."""

from contextlib import suppress

from . import loader, ui_runtime


def register() -> None:
    with suppress(Exception):
        ui_runtime.unregister()
    loader.register_all()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
