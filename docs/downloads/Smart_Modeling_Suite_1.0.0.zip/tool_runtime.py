# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from . import loader as loader, ui_runtime as ui_runtime


def register() -> None:
    try:
        ui_runtime.unregister()
    except Exception:
        pass
    loader.register_all()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
