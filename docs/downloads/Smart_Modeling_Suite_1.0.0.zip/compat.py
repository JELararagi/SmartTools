# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------

"""Compatibility helpers for Smart Modeling.

Focused on Blender 5.0 while gracefully handling shader name changes between
older/newer GPU APIs.
"""
import gpu


def get_uniform_color_shader(dimension: str = "3D"):
    """Return a uniform-color GPU shader with safe fallbacks.

    Blender changed built-in shader names over time. This helper tries the
    most likely candidates in a stable order.
    """
    candidates = []
    if str(dimension).upper().startswith("2"):
        candidates = ["UNIFORM_COLOR", "2D_UNIFORM_COLOR"]
    else:
        candidates = ["UNIFORM_COLOR", "3D_UNIFORM_COLOR"]

    last_error = None
    for name in candidates:
        try:
            return gpu.shader.from_builtin(name)
        except Exception as exc:  # pragma: no cover - Blender runtime path
            last_error = exc
    if last_error:
        raise last_error
    raise RuntimeError("Could not create uniform color shader")
