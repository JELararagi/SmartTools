# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Lazy-loaded, source-driven help content for Smart Modeling.

The popup catalog is built from the current source tree when the help button is
opened. This avoids stale pre-generated entries whose labels/descriptions can
become detached from the actual operators and N-panel properties.
"""

from __future__ import annotations

import ast
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

PACKAGE_ID = 'smart_modeling_suite'
TOOL_LABEL_EN = 'Smart Modeling'
TOOL_LABEL_JA = 'スマートモデリング'

_EXCLUDED_FILES = {
    'guide.py',
    'language_extra.py',
    'translation_generated.py',
    'translation_curated.py',
    'tooltip_audit.py',
}
_EXCLUDED_DIR_PARTS = {'__pycache__', '.git', '.mypy_cache', '.pytest_cache'}

_PROP_TYPES = {
    'BoolProperty': 'Bool',
    'IntProperty': 'Int',
    'FloatProperty': 'Float',
    'StringProperty': 'String',
    'EnumProperty': 'Enum',
    'FloatVectorProperty': 'Vector',
    'IntVectorProperty': 'Vector',
    'BoolVectorProperty': 'Vector',
    'PointerProperty': 'Pointer',
    'CollectionProperty': 'Collection',
}

_COMMON_NAME_JA = {
    'Smart Modeling': 'Smart Modeling',
    'Help': 'ヘルプ',
    'Open Help': 'ヘルプを開く',
    'Save Preferences': 'プリファレンスを保存',
    'Always-on Toggle': '常時機能切り替え',
    'Feature Overview': '機能概要',
    'Usage': '使用方法',
    'Settings': '設定',
    'Commands': 'コマンド',
    'Menus': 'メニュー',
    'Operators': 'オペレーター',
    'Enabled': '有効',
    'Disabled': '無効',
    'Name': '名前',
    'Target': '対象',
    'Mode': 'モード',
    'Options': '設定',
    'Radius': '半径',
    'Size': 'サイズ',
    'Scale': 'スケール',
    'Offset': 'オフセット',
    'Strength': '強さ',
    'Threshold': 'しきい値',
    'Distance': '距離',
    'Angle': '角度',
    'マテリアル': 'マテリアル',
    'Texture': 'テクスチャ',
    'Collection': 'コレクション',
    'Export': '書き出し',
    'Import': '読み込み',
    'Preview': 'プレビュー',
    'Clear': 'クリア',
    'Reset': 'リセット',
    'Apply': '適用',
    'Select': '選択',
    'Delete': '削除',
    'Copy': 'コピー',
    'Paste': '貼り付け',
}


def _source_root() -> Path:
    return Path(__file__).resolve().parent


def _contains_ja(text: str) -> bool:
    return bool(re.search(r'[\u3040-\u30ff\u3400-\u9fff]', str(text or '')))


def _clean_text(value: object) -> str:
    text = str(value or '').replace('\r', ' ').replace('\n', ' ')
    return re.sub(r'\s+', ' ', text).strip()


def _literal_string(node: ast.AST | None) -> str:
    if node is None:
        return ''
    try:
        value = ast.literal_eval(node)
    except Exception:
        return ''
    return _clean_text(value) if isinstance(value, str) else ''


def _call_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Call):
        node = node.func
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ''


def _call_keyword(call: ast.Call, *names: str) -> str:
    wanted = set(names)
    for keyword in call.keywords:
        if keyword.arg in wanted:
            value = _literal_string(keyword.value)
            if value:
                return value
    return ''


def _assigned_string(stmt: ast.stmt, attr_name: str) -> str:
    if isinstance(stmt, ast.Assign):
        for target in stmt.targets:
            if isinstance(target, ast.Name) and target.id == attr_name:
                return _literal_string(stmt.value)
    if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name) and stmt.target.id == attr_name:
        return _literal_string(stmt.value)
    return ''


def _property_call_from_stmt(stmt: ast.stmt) -> tuple[str, ast.Call] | None:
    value: ast.AST | None = None
    key = ''
    if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
        key = stmt.target.id
        value = stmt.value or stmt.annotation
    elif isinstance(stmt, ast.Assign):
        if len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name):
            key = stmt.targets[0].id
            value = stmt.value
    if not key or not isinstance(value, ast.Call):
        return None
    name = _call_name(value)
    if name not in _PROP_TYPES:
        return None
    return key, value


def _label_from_key(key: str) -> str:
    key = str(key or '').strip('_')
    if not key:
        return 'Item'
    text = re.sub(r'[_\-]+', ' ', key)
    text = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', text)
    return ' '.join(part.capitalize() if part.islower() else part for part in text.split())


def _name_ja(name: str) -> str:
    name = _clean_text(name)
    if not name:
        return '項目'
    if _contains_ja(name):
        return name
    if name in _COMMON_NAME_JA:
        return _COMMON_NAME_JA[name]
    words = [part for part in re.split(r'\s+', name) if part]
    if len(words) == 1:
        return _COMMON_NAME_JA.get(words[0], name)
    translated = [_COMMON_NAME_JA.get(word, word) for word in words]
    return ' '.join(translated)


def _setting_desc_ja(name: str, prop_type: str) -> str:
    label = _name_ja(name)
    if prop_type == 'Bool':
        return f'「{label}」をオンまたはオフにします。必要な動作だけを有効にし、不要な場合は無効にしてください。Nパネルで変更した値は保存対象です。'
    if prop_type == 'Enum':
        return f'「{label}」の処理モードを選択します。目的に近いモードを選んでから関連コマンドを実行してください。Nパネルで変更した値は保存対象です。'
    if prop_type in {'Int', 'Float', 'Vector'}:
        return f'「{label}」の数値を調整します。小さく変更して結果を確認しながら使うと安全です。Nパネルで変更した値は保存対象です。'
    if prop_type == 'String':
        return f'「{label}」の名前、検索語、パスなどの文字列を指定します。手動でディレクトリやファイルを指定する項目は、その指定先を使用します。'
    if prop_type in {'Pointer', 'Collection'}:
        return f'「{label}」に関連する設定グループを保持します。表示されている下位項目を必要に応じて調整してください。'
    return f'「{label}」を調整します。Nパネルで変更した値は保存対象になり、再起動やシーン切り替え後も維持されます。'


def _operator_desc_ja(name: str) -> str:
    label = _name_ja(name)
    return f'「{label}」コマンドを実行します。対象オブジェクトや編集モードを確認し、必要な設定をNパネルで調整してから実行してください。'


def _panel_usage_ja(title: str) -> list[str]:
    label = _name_ja(title)
    return [
        '3DビューでNキーを押してサイドバーを開き、Smart Modeling タブからこの項目を表示します。',
        f'「{label}」内の設定を必要な分だけ調整し、対象を選択してから関連コマンドを実行します。',
        '設定項目はNパネル側で保存され、Blender再起動やシーン切り替え後も復元されます。',
    ]


def _panel_usage_en(title: str) -> list[str]:
    return [
        'Press N in the 3D View to open the Sidebar, then use the Smart Modeling tab.',
        f'Adjust only the visible {title} settings you need, select the target object or data, then run the related command.',
        'N-panel settings are saved by the suite and restored after Blender restarts or scene changes.',
    ]


def _iter_source_files() -> list[Path]:
    files: list[Path] = []
    root = _source_root()
    for path in root.rglob('*.py'):
        rel = path.relative_to(root)
        if path.name in _EXCLUDED_FILES:
            continue
        if any(part in _EXCLUDED_DIR_PARTS for part in rel.parts):
            continue
        files.append(path)
    return sorted(files)


def _scan_file(path: Path) -> dict[str, Any]:
    root = _source_root()
    rel = str(path.relative_to(root)).replace('\\', '/')
    try:
        tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'), filename=rel)
    except Exception:
        return {'module': rel, 'classes': [], 'settings': [], 'operators': []}

    classes: list[dict[str, Any]] = []
    module_settings: list[dict[str, Any]] = []
    operators: list[dict[str, Any]] = []

    def add_setting(key: str, call: ast.Call, owner: str = '') -> None:
        prop_kind = _PROP_TYPES.get(_call_name(call), 'Property')
        name = _call_keyword(call, 'name') or _label_from_key(key)
        desc = _call_keyword(call, 'description')
        item = {
            'key': key,
            'name_en': name,
            'name_ja': _name_ja(name),
            'description_en': desc or f'Sets {name}. This N-panel value is saved and restored by Smart Modeling.',
            'description_ja': desc if _contains_ja(desc) else _setting_desc_ja(name, prop_kind),
            'type': prop_kind,
            'module': rel,
        }
        if owner:
            item['owner'] = owner
        module_settings.append(item)

    for stmt in tree.body:
        prop = _property_call_from_stmt(stmt)
        if prop is not None:
            add_setting(prop[0], prop[1])
            continue
        if not isinstance(stmt, ast.ClassDef):
            continue
        attrs: dict[str, str] = {}
        class_settings: list[dict[str, Any]] = []
        for body_stmt in stmt.body:
            for attr in ('bl_idname', 'bl_label', 'bl_description'):
                value = _assigned_string(body_stmt, attr)
                if value:
                    attrs[attr] = value
            prop = _property_call_from_stmt(body_stmt)
            if prop is not None:
                key, call = prop
                before = len(module_settings)
                add_setting(key, call, owner=stmt.name)
                class_settings.append(module_settings[before])
        label = attrs.get('bl_label') or _label_from_key(stmt.name)
        desc = attrs.get('bl_description') or ''
        bl_idname = attrs.get('bl_idname') or stmt.name
        kind = 'Operator' if ('.' in bl_idname and not bl_idname.startswith('VIEW3D_PT_')) or stmt.name.startswith(('OT_', 'MESH_OT_', 'OBJECT_OT_')) else 'Panel'
        info = {
            'class_name': stmt.name,
            'key': bl_idname,
            'title_en': label,
            'title_ja': _name_ja(label),
            'description_en': desc,
            'description_ja': desc if _contains_ja(desc) else (f'「{_name_ja(label)}」の操作パネルです。表示中の設定とコマンドを確認して使用してください。' if kind == 'Panel' else _operator_desc_ja(label)),
            'kind': kind,
            'module': rel,
            'settings': class_settings,
        }
        classes.append(info)
        if kind == 'Operator':
            operators.append({
                'key': bl_idname,
                'name_en': label,
                'name_ja': _name_ja(label),
                'description_en': desc or f'Runs the {label} command.',
                'description_ja': desc if _contains_ja(desc) else _operator_desc_ja(label),
                'type': 'Operator',
                'module': rel,
                'owner': stmt.name,
            })

    return {'module': rel, 'classes': classes, 'settings': module_settings, 'operators': operators}


def _overview_group(stats: dict[str, int]) -> dict[str, Any]:
    return {
        'title_en': TOOL_LABEL_EN + ' Help',
        'title_ja': TOOL_LABEL_JA + ' ヘルプ',
        'icon': 'HELP',
        'overview_en': [
            'Smart Modeling is a Blender 5.1 Extension modeling toolkit. Runtime controls are consolidated in the 3D View N-panel.',
            f'The current source scan detected {stats.get("panels", 0)} panel classes, {stats.get("operators", 0)} operators, and {stats.get("settings", 0)} adjustable property entries.',
        ],
        'overview_ja': [
            'スマートモデリングは Blender 5.1 Extension 形式のモデリングツールです。操作UIは3DビューのNパネルへ集約しています。',
            f'現在のソース解析で、パネル {stats.get("panels", 0)} 件、オペレーター {stats.get("operators", 0)} 件、調整可能な設定項目 {stats.get("settings", 0)} 件を検出しました。',
        ],
        'usage_en': [
            'Open the Sidebar with N, select the Smart Modeling tab, choose the target object or data, adjust the visible controls, then run the relevant command button.',
            'Use the question-mark help icon in each group header for detailed descriptions. The catalog is loaded only after the icon is clicked.',
        ],
        'usage_ja': [
            'Nキーでサイドバーを開き、Smart Modeling タブを選びます。対象オブジェクトやデータを選択し、表示されている設定を調整してから該当ボタンを実行します。',
            '各グループヘッダーの「？」ヘルプを押すと詳細を確認できます。ヘルプカタログはクリック時だけ読み込まれます。',
        ],
        'settings': [],
        'operators': [],
    }


@lru_cache(maxsize=1)
def _build_groups() -> dict[str, dict[str, Any]]:
    modules = [_scan_file(path) for path in _iter_source_files()]
    module_settings: dict[str, list[dict[str, Any]]] = {}
    module_ops: dict[str, list[dict[str, Any]]] = {}
    groups: dict[str, dict[str, Any]] = {}
    stats = {'panels': 0, 'operators': 0, 'settings': 0}

    for mod in modules:
        module = str(mod.get('module') or '')
        settings = list(mod.get('settings') or [])
        ops = list(mod.get('operators') or [])
        module_settings[module] = settings
        module_ops[module] = ops
        stats['settings'] += len(settings)
        stats['operators'] += len(ops)
        for cls in mod.get('classes') or []:
            if cls.get('kind') == 'Panel':
                stats['panels'] += 1

    groups['overview'] = _overview_group(stats)

    for mod in modules:
        module = str(mod.get('module') or '')
        for cls in mod.get('classes') or []:
            title_en = str(cls.get('title_en') or cls.get('class_name') or TOOL_LABEL_EN)
            title_ja = str(cls.get('title_ja') or _name_ja(title_en))
            desc_en = str(cls.get('description_en') or '')
            desc_ja = str(cls.get('description_ja') or f'「{title_ja}」のヘルプです。')
            class_settings = list(cls.get('settings') or [])
            if not class_settings:
                class_settings = module_settings.get(module, [])[:80]
            ops = module_ops.get(module, [])[:80]
            group = {
                'title_en': title_en,
                'title_ja': title_ja,
                'icon': 'HELP',
                'overview_en': [desc_en or f'{title_en} controls and commands in the Smart Modeling N-panel.'],
                'overview_ja': [desc_ja],
                'usage_en': _panel_usage_en(title_en),
                'usage_ja': _panel_usage_ja(title_ja),
                'settings': class_settings,
                'operators': ops,
            }
            for key in (cls.get('class_name'), cls.get('key')):
                if key:
                    groups[str(key)] = group

    return groups


def get_group(topic: str | None = None) -> dict[str, Any]:
    key = str(topic or 'overview')
    groups = _build_groups()
    return groups.get(key) or groups.get('overview') or {}


def all_topics() -> list[str]:
    return sorted(_build_groups().keys())


# Compatibility for code that expects a module-level HELP_GROUPS symbol. The
# catalog is still lazy because the actual source scan happens in _build_groups().
HELP_GROUPS: dict[str, dict[str, Any]] = {'overview': _overview_group({'panels': 0, 'operators': 0, 'settings': 0})}
