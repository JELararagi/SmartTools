# EdgeFlow upstream notice

This directory contains bundled material identified as EdgeFlow.

- Upstream author shown by `bl_info`: Benjamin Sauder
- Upstream source: https://github.com/BenjaminSauder/EdgeFlow
- Audited upstream commit: `9d8f6918f26b33c8627f51af7f38cd26a44802d8`
- Source `bl_info` version: `1.1.2`
- Mapping review: 9 bundled Python files; 3 byte-exact matches, 6 modified files, and 57 non-trivial AST matches.
- The original upstream license text is preserved in [LICENSE](LICENSE).

This notice records a source comparison only. It does not establish the historical acquired archive, whole-package rights clearance, full license compliance, or sales approval.
