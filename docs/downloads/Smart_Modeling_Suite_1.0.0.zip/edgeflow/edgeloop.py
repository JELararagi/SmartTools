import bpy
import bmesh
import math
import mathutils

from . import interpolate

from .op_set_vertex_curve  import map_segment_onto_spline 

class Loop():
    def __init__(self, bm, edges):
        self.bm = bm
        self.edges = edges
        start, alternate = edges[0].verts
        if len(edges) > 1 and start in edges[1].verts:
            start = alternate
        ordered = [start]
        for edge in edges:
            ordered.append(edge.other_vert(ordered[-1]))
        if sum(ordered[0].co) < sum(ordered[-1].co):
            ordered.reverse()
            edges.reverse()
        self.verts = ordered
        self.initial_vert_positions = [vertex.co.copy() for vertex in ordered]
        self.is_cyclic = ordered[0] == ordered[-1]
        self.valences = []
        self.ring = {edge: [] for edge in edges}
        self.edge_rings = {}
        self.ends = {}

    def __str__(self):
        lines = [""]
        for edge, valence in zip(self.edges, self.valences, strict=True):
            rings = "".join(f" | {neighbor.index} " for neighbor in self.get_ring(edge))
            ends = "".join(f" end: {neighbor.index}" for neighbor in self.get_ring_ends(edge))
            lines.extend((f"edge: {edge.index} - valence: {valence}{rings}", ends))
        return "\n".join(lines) + "\n"

    def __repr__(self):
        return self.__str__()

    def set_ring(self, edge, ring_edge):
        if edge in self.ring and len(self.ring[edge]) <= 2:
            self.ring[edge].append(ring_edge)

    def get_ring(self, edge):
        if edge in self.ring:
            return self.ring[edge]

        raise Exception("edge not in Edgeloop!")

    def select(self):
        for edge in self.edges:
            edge.select = True

    def get_ring_ends(self, edge):
        ring = self.edge_rings[edge]
        return (ring[0], ring[len(ring) - 1])

    def set_curve_flow(self, tension, use_rail, rail_type, rail_start, rail_end):
        """Fit a cubic from the direction of the outer edges of an open selection."""
        if self.is_cyclic or len(self.verts) < 3:
            return
        vertices = self.verts
        first_corner = vertices[1].co.copy()
        last_corner = vertices[-2].co.copy()
        start = vertices[0].co.copy()
        end = vertices[-1].co.copy()
        start_vector = first_corner - start
        end_vector = last_corner - end
        start_direction = start_vector.normalized()
        end_direction = end_vector.normalized()
        if use_rail:
            if rail_type == "ABSOLUTE":
                start = first_corner - rail_start * start_direction
                end = last_corner - rail_end * end_direction
            else:
                start += rail_start * start_vector
                end += rail_end * end_vector
        handle_length = 0.5 * tension * (end - start).length
        samples = mathutils.geometry.interpolate_bezier(start, start + handle_length * start_direction,
                                                         end + handle_length * end_direction, end, 1000)
        map_segment_onto_spline(vertices, samples)




    def straighten(self, distance):
        """Place the edge ends along the line joining their adjacent continuations."""
        edge = self.edges[0]
        if any(len(vertex.link_edges) <= 3 for vertex in edge.verts):
            return
        blocked = {edge}
        for face in edge.link_faces[:2 if not edge.is_boundary else 1]:
            if len(face.verts) == 4:
                blocked.update(face.edges)

        def continuation(endpoint):
            candidates = set(endpoint.link_edges) - blocked
            center = mathutils.Vector((0.0, 0.0, 0.0))
            for adjacent in candidates:
                center += adjacent.other_vert(endpoint).co
            return center / len(candidates) if candidates else center

        endpoints = [continuation(vertex) for vertex in edge.verts]
        direction = endpoints[1] - endpoints[0]
        travel = min(distance, direction.length * 0.5) * direction.normalized()
        edge.verts[0].co = endpoints[0] + travel
        edge.verts[1].co = endpoints[1] - travel


    def set_linear(self, even_spacing):
        """Move the interior vertices of an open chain onto its endpoint line."""
        if self.is_cyclic or len(self.edges) < 2:
            return

        neighbors = {}
        for edge in self.edges:
            first, second = edge.verts
            neighbors.setdefault(first, []).append(second)
            neighbors.setdefault(second, []).append(first)
        ends = [vertex for vertex, links in neighbors.items() if len(links) == 1]
        if len(ends) != 2 or any(len(links) > 2 for links in neighbors.values()):
            return

        start, finish = ends
        delta = finish.co - start.co
        squared = delta.length_squared

        ordered = [start]
        previous, current = None, start
        while current != finish:
            options = [neighbor for neighbor in neighbors[current] if neighbor != previous]
            if len(options) != 1 or len(ordered) > len(self.edges):
                return
            previous, current = current, options[0]
            ordered.append(current)
        if len(ordered) != len(neighbors):
            return

        origin = start.co.copy()
        segments = len(ordered) - 1
        for step, vertex in enumerate(ordered[1:-1], 1):
            fraction = step / segments
            if not even_spacing and squared > 0.0:
                fraction = (vertex.co - origin).dot(delta) / squared
            vertex.co = origin + fraction * delta


    def blend_start_end(self, blend_start, blend_end, blend_type):
        """Fade edited coordinates by travelled distance from each free endpoint."""
        from itertools import accumulate

        if self.is_cyclic:
            return
        total = len(self.verts)
        counts = [blend_start, blend_end]
        if sum(counts) >= total:
            if counts[0] == counts[1]:
                counts = [(total + 1) // 2, total // 2]
            else:
                shorter = 0 if counts[0] < counts[1] else 1
                larger = 1 - shorter
                counts[larger] = max(total - counts[shorter] - 1, 0)

        for endpoint, count in enumerate(counts):
            if count <= 0:
                continue
            width = min(total, count + 1)
            indices = range(width) if endpoint == 0 else range(total - 1, total - width - 1, -1)
            positions = [self.verts[index].co for index in indices]
            lengths = tuple(accumulate(
                ((b - a).length for a, b in zip(positions, positions[1:])), initial=0
            ))
            span = lengths[-1]
            if not span:
                continue
            for index, travelled in zip(indices, lengths, strict=True):
                weight = travelled / span
                if blend_type == "SMOOTH":
                    weight = interpolate.smooth_step(0.0, 1.0, weight)
                vertex = self.verts[index]
                vertex.co = self.initial_vert_positions[index].lerp(vertex.co, weight)


    def set_flow(self, tension, min_angle):
        """Fit a cubic midpoint across the face strip meeting each selected vertex."""

        def outside(edge, inner):
            a, b = edge.verts
            return (b if a == inner else a).co

        def clipped_handle(handle, inner, across, center):
            outward = (handle - inner).normalized()
            inward = (center - inner).normalized()
            cosine = max(-1.0, min(1.0, outward.dot(inward)))
            if math.acos(cosine) < min_angle:
                return inner - (across - inner) * 0.5
            return handle

        def transverse_controls(corner, center):
            left_side = corner.link_loop_next.link_loop_next
            right_side = corner.link_loop_radial_prev.link_loop_prev.link_loop_prev
            left_vertex = left_side.vert
            right_vertex = right_side.link_loop_radial_next.vert
            left, right = left_vertex.co, right_vertex.co
            if left_side.edge.is_boundary:
                start = left - (right - left)
            else:
                rim = left_side.link_loop_radial_next.link_loop_next.edge
                start = clipped_handle(outside(rim, left_vertex), left, right, center)
            if right_side.edge.is_boundary:
                right = right_side.edge.other_vert(right_vertex).co
                finish = right - (left - right)
            else:
                rim = right_side.link_loop_radial_prev.link_loop_prev.edge
                finish = clipped_handle(outside(rim, right_vertex), right, left, center)
            return start, left, right, finish

        def midpoint(start, left, right, finish):
            if start == left or right == finish:
                print("invalid input - two control points are identical!")
                return None
            span = (right - left).length * 0.5
            start = left + span * (start - left).normalized()
            finish = right + span * (finish - right).normalized()
            # At t=1/2 the cubic is the average of its inner points plus
            # one eighth of the difference between its endpoint derivatives.
            scale = (1.0 + tension) * 0.5 / 8.0
            return mathutils.Vector([
                (p + q) * 0.5 + scale * ((p - a) - (b - q))
                for a, p, q, b in zip(start, left, right, finish, strict=True)
            ])

        for edge in self.edges:
            if edge.is_boundary:
                continue
            samples = {}
            for corner in edge.link_loops:
                vertex = edge.other_vert(corner.vert)
                samples[vertex] = transverse_controls(corner, vertex.co)
            for vertex, controls in samples.items():
                destination = midpoint(*controls)
                if destination is not None:
                    vertex.co = destination
 
            

