# SPDX-License-Identifier: GPL-3.0-or-later
"""Shortest paths along a Blender edit mesh. Independent implementation for SmartModeling."""
from heapq import heappop, heappush
from itertools import count
from math import dist, inf


class _Node:
    def __init__(self, v):
        self.vert = v
        self.length = inf
        self._previous = None
        self._route = None

    @property
    def edges(self):
        yield from self.vert.link_edges

    @property
    def shortest_path(self):
        if self._route is None:
            cursor = self
            backwards = []
            while cursor._previous is not None:
                cursor, incoming = cursor._previous
                backwards.append(incoming)
            self._route = list(reversed(backwards))
        return self._route


def find_path(bm, v_start, v_target=None, use_topology_distance=False):
    """Return a vertex-to-node mapping, stopping when the requested target is settled."""
    nodes = {vertex: _Node(vertex) for vertex in bm.verts}
    start = nodes[v_start]
    start.length = 0.0
    sequence = count()
    queue = [(start.length, next(sequence), start)]
    while queue:
        travelled, _, current = heappop(queue)
        if travelled != current.length:
            continue
        if current.vert == v_target:
            break
        for edge in current.edges:
            adjacent = nodes[edge.other_vert(current.vert)]
            weight = 1.0 if use_topology_distance else dist(current.vert.co, adjacent.vert.co)
            proposed = travelled + weight
            if proposed < adjacent.length:
                adjacent.length = proposed
                adjacent._previous = current, edge
                heappush(queue, (proposed, next(sequence), adjacent))
    return nodes
