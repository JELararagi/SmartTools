bl_info = {
    "name": "Edge Flow",
    "category": "Mesh",
    "author": "Benjamin Sauder",
    "description": "Helps adjusting geometry to curved surfaces",
    "version": (1, 1, 2),
    "location": "Mesh > Edge > Set Edge Flow",
    "blender": (3, 5, 1),
    "tracker_url": "https://github.com/BenjaminSauder/EdgeFlow/issues",
    "wiki_url": "https://github.com/BenjaminSauder/EdgeFlow",
}

if "bpy" in locals():
    import importlib
    importlib.reload(util)
    importlib.reload(edgeloop)
    importlib.reload(interpolate)
    importlib.reload(op_set_edge_flow)
    importlib.reload(op_set_edge_linear)
    importlib.reload(op_set_edge_curve)
    importlib.reload(op_set_vertex_curve)
else:
    from . import (
        util,
        interpolate,
        edgeloop,
        op_set_edge_flow,
        op_set_edge_linear,
        op_set_edge_curve,
        op_set_vertex_curve,
    )

import bpy
from bpy.types import Menu
from bpy.props import BoolProperty, EnumProperty
from .. import preferences


def _prefs(context=None):
    return preferences.get_preferences(context or bpy.context, __package__, SMART_MODELING_SUITE_5799AB_Preferences)


def _safe_menu_remove(menu, fn):
    try:
        menu.remove(fn)
    except Exception:
        pass


def _safe_menu_append(menu, fn):
    _safe_menu_remove(menu, fn)
    try:
        menu.append(fn)
    except Exception:
        pass


def _safe_menu_prepend(menu, fn):
    _safe_menu_remove(menu, fn)
    try:
        menu.prepend(fn)
    except Exception:
        pass


def menu_func_edges(self, context):
    layout = self.layout
    layout.separator()
    layout.operator_context = "INVOKE_DEFAULT"
    layout.operator(op_set_edge_flow.SetEdgeFlowOP.bl_idname, text='Set Flow')
    layout.operator(op_set_edge_curve.SetEdgeCurveOP.bl_idname, text='Set Curve')
    layout.operator(op_set_edge_linear.SetEdgeLinearOP.bl_idname, text='Set Linear')


def menu_func_vertices(self, context):
    layout = self.layout
    layout.separator()
    layout.operator_context = "INVOKE_DEFAULT"
    layout.operator(op_set_vertex_curve.SetVertexCurveOp.bl_idname, text='Set Vertex Curve')


list_insertion_options = [
    ("BOTTOM", "Bottom of Menu", "", 1),
    ("TOP", "Top of menu", "", 2),
]


def _sync_context_menu(context=None):
    prefs = _prefs(context)
    menu = bpy.types.VIEW3D_MT_edit_mesh_context_menu
    _safe_menu_remove(menu, menu_func_context_menu)
    if prefs and getattr(prefs, 'add_to_rightclick_menu', True):
        if getattr(prefs, 'list_insertion_choice', 'BOTTOM') == 'BOTTOM':
            _safe_menu_append(menu, menu_func_context_menu)
        else:
            _safe_menu_prepend(menu, menu_func_context_menu)


def on_preferences_update(self, context):
    _sync_context_menu(context)


class SMART_MODELING_SUITE_5799AB_Preferences(bpy.types.PropertyGroup):
    bl_idname = __package__

    add_to_rightclick_menu: BoolProperty(name="Extend rightlick menu", default=True, update=on_preferences_update)
    list_insertion_choice: EnumProperty(name="Add at", items=list_insertion_options, default='BOTTOM', update=on_preferences_update)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.label(text="UI Options")
        col = layout.column(heading="Add commands to rightlick menu")
        col.prop(self, "add_to_rightclick_menu", text="")
        row = col.row()
        row.prop(self, "list_insertion_choice")
        row.enabled = self.add_to_rightclick_menu


class VIEW3D_MT_edit_mesh_set_flow(Menu):
    bl_label = "Set Flow"

    def draw(self, context):
        layout = self.layout
        mesh_select_mode = context.scene.tool_settings.mesh_select_mode[:3]
        if mesh_select_mode == (True, False, False):
            layout.operator(op_set_vertex_curve.SetVertexCurveOp.bl_idname, text='Set Vertex Curve')
        elif mesh_select_mode == (False, True, False):
            layout.operator(op_set_edge_flow.SetEdgeFlowOP.bl_idname, text='Set Flow')
            layout.operator(op_set_edge_curve.SetEdgeCurveOP.bl_idname, text='Set Curve')
            layout.operator(op_set_edge_linear.SetEdgeLinearOP.bl_idname, text='Set Linear')


def menu_func_context_menu(self, context):
    prefs = _prefs(context)
    mesh_select_mode = context.scene.tool_settings.mesh_select_mode[:3]
    if mesh_select_mode == (True, False, False) or mesh_select_mode == (False, True, False):
        if prefs and getattr(prefs, 'list_insertion_choice', 'BOTTOM') == 'BOTTOM':
            self.layout.separator()
        self.layout.menu("VIEW3D_MT_edit_mesh_set_flow")
        if prefs and getattr(prefs, 'list_insertion_choice', 'BOTTOM') == 'TOP':
            self.layout.separator()


classes = [
    SMART_MODELING_SUITE_5799AB_Preferences,
    op_set_edge_flow.SetEdgeFlowOP,
    op_set_edge_linear.SetEdgeLinearOP,
    op_set_edge_curve.SetEdgeCurveOP,
    op_set_vertex_curve.SetVertexCurveOp,
    VIEW3D_MT_edit_mesh_set_flow,
]


def register():
    for c in classes:
        try:
            bpy.utils.register_class(c)
        except ValueError:
            pass
    _safe_menu_append(bpy.types.VIEW3D_MT_edit_mesh_edges, menu_func_edges)
    _safe_menu_append(bpy.types.VIEW3D_MT_edit_mesh_vertices, menu_func_vertices)
    _sync_context_menu(bpy.context)


def unregister():
    _safe_menu_remove(bpy.types.VIEW3D_MT_edit_mesh_context_menu, menu_func_context_menu)
    _safe_menu_remove(bpy.types.VIEW3D_MT_edit_mesh_edges, menu_func_edges)
    _safe_menu_remove(bpy.types.VIEW3D_MT_edit_mesh_vertices, menu_func_vertices)
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
