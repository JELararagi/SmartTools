# SPDX-License-Identifier: GPL-3.0-or-later
"""Edge walking and ring association for the Smart Modeling mesh tools."""

from collections import deque

from . import edgeloop


def walk_boundary(start_edge, limit_to_edges=None):
    """Collect a connected boundary run, stopping at two-valence corners."""
    component = {start_edge}
    frontier = deque([start_edge])
    while frontier:
        edge = frontier.popleft()
        for endpoint in edge.verts:
            if len(endpoint.link_edges) <= 2:
                continue
            for neighbor in endpoint.link_edges:
                if (neighbor.is_boundary and neighbor not in component
                        and (limit_to_edges is None or neighbor in limit_to_edges)):
                    component.add(neighbor)
                    frontier.append(neighbor)

    incidence = {}
    for edge in component:
        for endpoint in edge.verts:
            incidence.setdefault(endpoint, []).append(edge)

    remaining = component - {start_edge}
    result = deque([start_edge])
    for endpoint, insert in zip(start_edge.verts, (result.append, result.appendleft), strict=True):
        while remaining:
            choices = [edge for edge in incidence[endpoint] if edge in remaining]
            if not choices:
                break
            following = choices[-1]
            remaining.remove(following)
            endpoint = following.other_vert(endpoint)
            insert(following)
    if remaining:
        raise Exception("WTF")
    return list(result)


def walk_ngon(start_edge, limit_to_edges=None):
    """Follow the perimeter of the largest incident polygon in both directions."""
    anchor = max((corner for corner in start_edge.link_loops if len(corner.face.verts) > 4),
                 key=lambda corner: len(corner.face.verts))
    perimeter = tuple(anchor.face.loops)
    origin = perimeter.index(anchor)
    rotated = perimeter[origin + 1:] + perimeter[:origin]
    found = {start_edge}
    path = deque([start_edge])
    for corners, forward in ((rotated, True), (reversed(rotated), False)):
        insert = path.append if forward else path.appendleft
        for corner in corners:
            edge = corner.edge
            joint = corner.vert if forward else edge.other_vert(corner.vert)
            if (len(joint.link_edges) >= 4 or edge in found
                    or (limit_to_edges is not None and edge not in limit_to_edges)):
                break
            found.add(edge)
            insert(edge)
    return list(path)


def walk_edge_loop(start_edge, limit_to_edges=None):
    """Walk straight through valence-four vertices by crossing the incoming face."""
    path = deque([start_edge])
    visited = {start_edge}
    for side, corner in enumerate(start_edge.link_loops):
        insert = path.appendleft if side else path.append
        while len(corner.vert.link_edges) == 4:
            across = corner.link_loop_prev.link_loop_radial_prev
            corner = across.link_loop_prev
            edge = corner.edge
            if edge in visited or (limit_to_edges is not None and edge not in limit_to_edges):
                break
            visited.add(edge)
            insert(edge)
    return list(path)


def walk_wire(start_edge, limit_to_edges=None):
    """Follow the wire through degree-two vertices from both ends."""
    used = {start_edge}
    sides = []
    for vertex in start_edge.verts:
        arm = []
        cursor = start_edge
        while len(vertex.link_edges) == 2:
            first, second = vertex.link_edges
            outgoing = second if first == cursor else first
            if not outgoing.is_wire or outgoing in used:
                break
            if limit_to_edges is not None and outgoing not in limit_to_edges:
                break
            arm.append(outgoing)
            used.add(outgoing)
            cursor, vertex = outgoing, outgoing.other_vert(vertex)
        sides.append(arm)
    return [*reversed(sides[0]), start_edge, *sides[1]]


def get_edgeloop(bm, start_edge, limit_to_edges=None):
    """Choose a traversal for the topology surrounding the initial edge."""
    if start_edge.is_wire:
        walker = walk_wire
    else:
        low, high = sorted(len(vertex.link_edges) for vertex in start_edge.verts)
        follows_quad_flow = low == 4 and high >= 4
        if not follows_quad_flow and any(len(loop.face.verts) > 4 for loop in start_edge.link_loops):
            walker = walk_ngon
        else:
            walker = walk_boundary if start_edge.is_boundary else walk_edge_loop
    return edgeloop.Loop(bm, walker(start_edge, limit_to_edges))


def get_edgeloops(bm, edges):
    remaining = set(edges)
    paths = []
    while remaining:
        anchor = remaining.pop()
        path = get_edgeloop(bm, anchor, remaining)
        remaining.difference_update(path.edges)
        paths.append(path)
    return compute_edgeloop_data(paths)


def find_edge_ring_neighbours(edgeloops, edge_to_Edgeloop):
    """Link selected opposite edges across the quads of the selected paths."""
    for path in edgeloops:
        for edge in path.edges:
            connected = path.get_ring(edge)
            if len(connected) == 2:
                continue
            opposites = (corner.link_loop_next.link_loop_next.edge for corner in edge.link_loops
                         if len(corner.face.verts) == 4)
            for opposite in opposites:
                adjacent = edge_to_Edgeloop.get(opposite)
                if adjacent is not None and opposite not in connected:
                    path.set_ring(edge, opposite)
                    adjacent.set_ring(opposite, edge)


def find_control_edgeloop(edgeloops, edge_to_Edgeloop):
    """Associate selected edges that share a transverse path and record its ends."""
    for path in edgeloops:
        for seed in path.edges:
            if seed.is_wire or seed in path.edge_rings:
                continue
            ends = []
            ring = deque((seed.link_loops[0],))
            for side, start in enumerate(seed.link_loops):
                extend = ring.appendleft if side else ring.append
                visited = set()
                cursor = start.link_loop_prev.link_loop_prev
                while cursor not in visited:
                    visited.add(cursor)
                    edge = cursor.edge
                    if edge not in edge_to_Edgeloop:
                        ends.append(cursor)
                        break
                    extend(cursor)
                    if edge.is_boundary:
                        ends.append(cursor)
                        break
                    across = cursor.link_loop_radial_prev
                    cursor = across.link_loop_prev.link_loop_prev
            for corner in ring:
                selected = edge_to_Edgeloop[corner.edge]
                selected.edge_rings[corner.edge] = ring
                selected.ends[corner.edge] = ends


def compute_edge_ring_valences(edgeloops, edge_to_Edgeloop):
    """Count branch continuations for each starting edge of the selected ring graph."""
    crossings = {edge: owner.get_ring(edge) for edge, owner in edge_to_Edgeloop.items()}

    def continuation_count(anchor):
        pending, finished = {anchor}, set()
        count = 0
        while pending:
            current = pending.pop()
            finished.add(current)
            next_edges = [neighbor for neighbor in crossings[current] if neighbor not in finished]
            count += bool(next_edges)
            pending.update(next_edges)
        return count

    for path in edgeloops:
        values = [continuation_count(edge) for edge in path.edges]
        path.valences.extend(values)
        path.max_valence = max(values, default=-1)


def compute_edgeloop_data(edgeloops):
    owners = {edge: path for path in edgeloops for edge in path.edges}
    find_edge_ring_neighbours(edgeloops, owners)
    compute_edge_ring_valences(edgeloops, owners)
    find_control_edgeloop(edgeloops, owners)
    return sorted(reversed(edgeloops), key=lambda path: path.max_valence, reverse=True)
