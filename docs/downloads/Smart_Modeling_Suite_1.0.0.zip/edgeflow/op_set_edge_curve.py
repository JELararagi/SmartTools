import math
import time
import bpy
from bpy.props import BoolProperty, IntProperty, FloatProperty, EnumProperty
import bmesh

from . import op_set_edge_flow

class SetEdgeCurveOP(bpy.types.Operator, op_set_edge_flow.SetEdgeLoopBase):

    bl_idname = "mesh.set_edge_curve"
    is_invoked = False
    bl_label = "Set Edge Curve"
    bl_options = {'UNDO'}
    bl_description = "Adjust curvature along the direction the edgeloop\nALT: reuse last settings"

    rail_mode = (
        ("ABSOLUTE", "Absolute", "", 1),
        ("FACTOR", "Factor", "", 2),
    )

    mix: FloatProperty(name="Mix", default=1.0, min=0.0, max=1.0, subtype='FACTOR', description="Interpolate between inital position and the calculated end position")
    tension : IntProperty(name="Tension", default=100, soft_min=-500, soft_max=500, description="Tension can be used to tighten up the curvature")

    use_rail : BoolProperty(name="Use Rail", default=False, description="Customize the interpolation by using the first and last edge of the edgeloop to control the curvature")
    rail_mode: bpy.props.EnumProperty(name="Rail Mode", items=rail_mode, default=2, description="Switch rail mode between using absolute units or a factor of the length of the edge")
    rail_start_width : FloatProperty(name="Rail Start", default=1.0, subtype='DISTANCE', description="Choose how long the rail is at the start")
    rail_end_width : FloatProperty(name="Rail End", default=1.0, subtype='DISTANCE', description="Choose how long the rail is at the end")
    rail_start_factor : FloatProperty(name="Rail Start", default=1.0, soft_min=0.0, soft_max=1.5, subtype='FACTOR', description="Choose how long the rail is at the start")
    rail_end_factor : FloatProperty(name="Rail End", default=1.0, soft_min=0.0, soft_max=1.5, subtype='FACTOR', description="Choose how long the rail is at the end")
   
    def execute(self, context):
        if not self.is_invoked:
            return self.invoke(context, None)
        self.revert_to_intial_positions()
        absolute = self.rail_mode == "ABSOLUTE"
        start = self.rail_start_width if absolute else self.rail_start_factor
        end = self.rail_end_width if absolute else self.rail_end_factor
        for obj in self.objects:
            for chain in self.edgeloops[obj]:
                chain.set_curve_flow(self.tension / 100.0, self.use_rail, self.rail_mode, start, end)
            self.bm[obj].normal_update()
        self.store_final_positions()
        self.apply_mix()
        for obj in self.objects:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        properties = layout.column(align=True)
        for field in ("mix", "tension"):
            properties.prop(self, field)
        properties.separator()
        properties.prop(self, "use_rail")
        rails = properties.column(align=True)
        rails.row().prop(self, "rail_mode", expand=True)
        absolute = self.rail_mode == "ABSOLUTE"
        suffix = "width" if absolute else "factor"
        display = {"slider": False} if absolute else {}
        for side in ("start", "end"):
            rails.prop(self, "rail_" + side + "_" + suffix, **display)
        rails.enabled = self.use_rail

    def invoke(self, context, event):
        super(SetEdgeCurveOP, self).invoke(context)
     
        if event and not event.alt:
            self.tension = 100
            self.mix = 1.0

        return self.execute(context)
