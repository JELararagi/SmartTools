# SPDX-License-Identifier: GPL-3.0-or-later
"""Straighten selected mesh loops, retaining Blender's edit and redo state."""
import bmesh
import bpy
from bpy.props import BoolProperty
from . import op_set_edge_flow


class SetEdgeLinearOP(bpy.types.Operator, op_set_edge_flow.SetEdgeLoopBase):
    bl_idname = "mesh.set_edge_linear"
    bl_label = "Set Edge Linear"
    bl_description = "Makes edge loops linear between start and end vertices"
    bl_options = {"UNDO"}
    is_invoked = False

    space_evenly: BoolProperty(name="Space evenly", default=False,
                               description="Spread the vertices in even distances")

    def can_straighten(self):
        return all(edge.link_faces for obj in self.objects
                   for loop in self.edgeloops[obj] for edge in loop.edges)

    def invoke(self, context, event):
        # The shared setup acquires the edit BMeshes and remembers the entry coordinates.
        for obj in context.objects_in_mode_unique_data:
            if obj.type == "MESH":
                mesh = bmesh.from_edit_mesh(obj.data)
                if any(edge.select and edge.is_wire for edge in mesh.edges):
                    self.report({"WARNING"}, "Set Edge Linear requires edges connected to faces")
                    return {"CANCELLED"}
        op_set_edge_flow.SetEdgeLoopBase.invoke(self, context)
        return self.execute(context)

    def execute(self, context):
        if not self.is_invoked:
            return self.invoke(context, None)
        if not self.can_straighten():
            self.report({"WARNING"}, "Set Edge Linear requires edges connected to faces")
            return {"CANCELLED"}

        self.revert_to_intial_positions()
        for obj in self.objects:
            for loop in self.edgeloops[obj]:
                loop.set_linear(self.space_evenly)
        self.store_final_positions()
        self.apply_mix()
        for obj in self.objects:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {"FINISHED"}
