# SPDX-License-Identifier: GPL-3.0-or-later
"""Scalar and sampled cubic curves for the SmartModeling mesh operators."""
import numpy as np


def clamp(x, lowerlimit=0.0, upperlimit=1.0):
    return min(upperlimit, max(x, lowerlimit))


def smooth_step(a, b, x):
    t = clamp((x - a) / (b - a))
    return t * t * (3.0 - 2.0 * t)


def _evaluate(p, q, start_slope, end_slope, t):
    """Evaluate a cubic in Horner form with the given endpoint derivatives."""
    delta = q - p
    quadratic = 3 * delta - 2 * start_slope - end_slope
    cubic = start_slope + end_slope - 2 * delta
    return p + t * (start_slope + t * (quadratic + t * cubic))


def hermite_1d(y0, y1, y2, y3, mu, tension, bias):
    scale = (1.0 - tension) * 0.5
    previous = scale * (1.0 + bias)
    following = scale * (1.0 - bias)
    inside = y2 - y1
    left = previous * (y1 - y0) + following * inside
    right = previous * inside + following * (y3 - y2)
    return _evaluate(y1, y2, left, right, mu)


def hermite_3d(p1, p2, p3, p4, mu, tension, bias):
    return [hermite_1d(p1[axis], p2[axis], p3[axis], p4[axis], mu, tension, bias)
            for axis in range(3)]


def catmullrom(P0, P1, P2, P3, a, nPoints=100):
    """Sample the segment between the middle control points with chord-based knots."""
    p, q, r, s = np.asarray([P0, P1, P2, P3], dtype=float)
    gaps = np.linalg.norm(np.diff([p, q, r, s], axis=0), axis=1) ** a
    before, span, after = gaps
    # Duplicate outer handles use a one-sided tangent. Coincident middle
    # controls describe a point, including when a is positive.
    chord = r - q
    left = chord.copy()
    right = chord.copy()
    if before > 0 and span > 0:
        left = chord + span * ((q - p) / before - (r - p) / (before + span))
    if after > 0 and span > 0:
        right = chord + span * ((s - r) / after - (s - q) / (span + after))
    samples = np.linspace(0.0, 1.0, nPoints)[:, np.newaxis]
    return _evaluate(q, r, left, right, samples)
