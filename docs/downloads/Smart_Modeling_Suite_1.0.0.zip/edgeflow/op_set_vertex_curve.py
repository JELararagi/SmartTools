import math

import bpy
from bpy.props import IntProperty, FloatProperty, BoolProperty
import bmesh
import mathutils

from . import interpolate
from . import dijkstra


def collect_vert_path(bm, selected, use_topology_distance):
    """Join shortest routes in pick order, retaining the latest visit to each vertex."""
    bm.verts.ensure_lookup_table()
    visits = {}
    for first, last in zip(selected, selected[1:]):
        start, finish = bm.verts[first], bm.verts[last]
        result = dijkstra.find_path(bm, start, finish, use_topology_distance)
        steps = result[finish].shortest_path
        cursor = start
        for edge in steps:
            visits.pop(cursor, None)
            visits[cursor] = None
            cursor = edge.other_vert(cursor)
        visits.pop(finish, None)
        visits[finish] = None
    return list(visits)


def split_vert_path_into_segments(bm, selected, vert_path):
    """Partition at guides encountered in the user's requested order."""
    knots = []
    segments = []
    first = 0
    for i, point in enumerate(vert_path):
        if len(knots) >= len(selected) or point.index != selected[len(knots)]:
            continue
        if knots and i > first:
            segments.append(vert_path[first:i + 1])
            first = i
        knots.append(point)
    if first < len(vert_path) - 1 or not segments:
        segments.append(vert_path[first:])
    return knots, segments


def map_segment_onto_spline(segment, positions):
    """Sample along the polyline, retaining its established interval offset and fixed endpoints."""
    from bisect import bisect_left
    from itertools import accumulate

    if not segment:
        raise IndexError("the mesh segment is empty")
    interior = segment[1:-1]
    if not interior:
        return
    samples = [mathutils.Vector(p) for p in positions]
    widths = [(b-a).length for a,b in zip(samples, samples[1:])]
    cumulative = list(accumulate(widths))
    extent = cumulative[-1]
    if extent == 0.0:
        return
    # The operator assigns at most one mesh vertex per sampled interval.
    # In dense selections the remaining vertices retain their entry coordinates.
    pending = iter(interior)
    previous_interval = -1
    for order in range(1, len(segment)):
        along = extent * (order / (len(segment) - 1))
        index = min(bisect_left(cumulative, along), len(widths)-1)
        if index == previous_interval:
            continue
        previous_interval = index
        vertex = next(pending, None)
        if vertex is None:
            break
        if widths[index] == 0:
            vertex.co = samples[index]
        else:
            fraction = (along - cumulative[index]) / widths[index]
            vertex.co = samples[index].lerp(samples[index+1], fraction)


def _spline_end_control(vertex, inward, next_guide):
    """Continue a selected path through the endpoint's face fan or along its wire."""
    for corner in vertex.link_loops:
        following = corner.link_loop_next
        preceding = corner.link_loop_prev
        if following.vert == inward:
            side = preceding.vert
            border = preceding.edge
            across_boundary = preceding.link_loop_prev.vert
        elif preceding.vert == inward:
            side = following.vert
            border = corner.edge
            across_boundary = following.link_loop_next.vert
        else:
            continue
        # Cross the side of the corner to the next polygon in the fan.
        for face in border.link_faces:
            if face == corner.face:
                continue
            for other in face.loops:
                if other.vert == vertex:
                    a = other.link_loop_next.vert
                    b = other.link_loop_prev.vert
                    return (b if a == side else a).co.copy()
        return across_boundary.co.copy()

    # A wire endpoint has no face fan. Its straightest incident continuation is
    # the tangent reference. At a free end use the reflection of the next guide.
    outward = (vertex.co - inward.co).normalized()
    neighbors = [e.other_vert(vertex) for e in vertex.link_edges if e.other_vert(vertex) != inward]
    if neighbors:
        neighbor = max(neighbors, key=lambda v: ((v.co - vertex.co).normalized().dot(outward), -v.index))
        return neighbor.co.copy()
    return 2.0 * vertex.co - next_guide


def curve_hermite(bm, selected, vert_path, tension, space_evenly):
    """Fit a piecewise cubic through the picked guides; retain each guide unless spacing is global."""
    guides, spans = split_vert_path_into_segments(bm, selected, vert_path)
    if len(guides) < 4 or len(guides) != len(selected) or len(spans) + 1 != len(guides):
        return 1, "No ordered path through all selected spline guides"
    if any(len(span) < 2 for span in spans):
        return 1, "No connected path through all selected spline guides"
    if any(bm.edges.get((a, b)) is None for span in spans for a, b in zip(span, span[1:])):
        return 1, "No connected path through all selected spline guides"
    knots = [v.co.copy() for v in guides]
    last = len(spans) - 1
    outer_start = _spline_end_control(guides[0], spans[0][1], knots[1])
    outer_end = _spline_end_control(guides[-1], spans[-1][-2], knots[-2])
    full_path = []
    for i, span in enumerate(spans):
        start, end = knots[i:i + 2]
        size = (end - start).length
        prev = outer_start if i == 0 else knots[i - 1]
        following = outer_end if i == last else knots[i + 2]
        if i == 0:
            following = end + size * (following - end).normalized()
        if i == last:
            approach_length = (start - knots[i - 2]).length
            prev = start + approach_length * (prev - start).normalized()
        samples = [interpolate.hermite_3d(prev, start, end, following, j / 1000.0, -tension, 0)
                   for j in range(1000)]
        if space_evenly:
            full_path.extend(samples)
        else:
            map_segment_onto_spline(span, samples)
    if space_evenly:
        map_segment_onto_spline(vert_path, full_path)
    return 0, ""


def curve_bezier(bm, selected, vert_path):
    """Fit the first guide interval, preserving the callable's first-span contract."""
    from bisect import bisect_left
    from itertools import accumulate

    knots, spans = split_vert_path_into_segments(bm, selected, vert_path)
    if len(knots) < 3 or not spans or len(spans[0]) < 3:
        return 0
    a, b, c = [v.co.copy() for v in knots[:3]]
    chord = (b - a).normalized()
    bend = ((b - a) - (c - b)).normalized()
    projection = bend.dot(chord)
    second = chord - projection * bend
    first_handle, last_handle = a.copy(), b.copy()
    if bend.length_squared:
        reach = 0.5 * (c - b).length * projection
        first_handle += reach * bend
        last_handle -= reach * second.normalized()
    span = spans[0]
    samples = mathutils.geometry.interpolate_bezier(a, first_handle, last_handle, b, len(span) * 100)
    distances = [0.0, *accumulate((q - p).length for p, q in zip(samples, samples[1:]))]
    length = distances[-1]
    if length:
        spacing = length / (len(span) - 1)
        idx = 0
        for vert in span[1:-1]:
            idx = min(bisect_left(distances, distances[idx] + spacing), len(samples) - 1)
            vert.co = samples[idx]
    return 0


def circle_3_points(bm, selected, vert_path, tension, space_evenly):
    """Construct the circumcircle and rotate around its center between successive picks."""
    guides, sections = split_vert_path_into_segments(bm, selected, vert_path)
    if len(guides) != 3 or len(sections) != 2:
        return 1, "No connected path through all three selected vertices"
    # A backtracking route can omit a previous visit. Only explore the mesh
    # when the displayed route has a gap, and stop once every guide is reached.
    has_gap = any(bm.edges.get((a, b)) is None for a, b in zip(vert_path, vert_path[1:]))
    if has_gap:
        pending = set(guides)
        pending.discard(guides[0])
        seen = {guides[0]}
        frontier = [guides[0]]
        while frontier and pending:
            current = frontier.pop()
            for edge in current.link_edges:
                neighbor = edge.other_vert(current)
                if neighbor not in seen:
                    seen.add(neighbor)
                    frontier.append(neighbor)
                    pending.discard(neighbor)
        if pending:
            return 1, "No connected path through all three selected vertices"
    first, through, last = [guide.co.copy() for guide in guides]
    samples_per_half = len(vert_path) * 50
    if tension == -1.0:
        sample_count = samples_per_half * 2
        line = [first.lerp(last, i / sample_count) for i in range(sample_count)]
        map_segment_onto_spline(vert_path, line)
        return 0, ""

    midpoint = (first + last) * 0.5
    through += tension * (through - midpoint).normalized()
    side = through - first
    diagonal = last - first
    normal = side.cross(diagonal)
    divisor = 2.0 * normal.length_squared
    if divisor == 0.0:
        return 1, "found no intersection"

    center = first + (side.length_squared * diagonal.cross(normal)
                      + diagonal.length_squared * normal.cross(side)) / divisor
    axis = normal.normalized()

    def arc_points(a, b, divisions, include_end):
        radial = a - center
        end = b - center
        angle = math.atan2(axis.dot(radial.cross(end)), radial.dot(end))
        sideways = axis.cross(radial)
        for i in range(divisions + int(include_end)):
            t = angle * i / divisions
            yield center + (math.cos(t) * radial + math.sin(t) * sideways)

    pairs = ((first, through), (through, last))
    if space_evenly:
        samples = [point for a,b in pairs for point in arc_points(a,b,samples_per_half,False)]
        map_segment_onto_spline(vert_path, samples)
    else:
        for section, (a,b) in zip(sections, pairs):
            for vertex, point in zip(section, arc_points(a,b,len(section)-1,True)):
                vertex.co = point
    return 0, ""


def circle_2_points(bm, selected, vert_path, tension, flip, rotate):
    """Distribute the path along an arc defined by its chord and signed sagitta."""
    bm.verts.ensure_lookup_table()
    first, last = (bm.verts[index] for index in selected)
    diameter = last.co - first.co
    radius = diameter.length * 0.5

    samples = len(vert_path) * 100
    if not samples:
        return 1, "found no intersection"
    height = radius * (1.0 + tension)
    if tension == -1.0:
        positions = [first.co.lerp(last.co, i / samples) for i in range(samples)]
    else:
        if radius == 0.0:
            return 1, "found no intersection"
        along = diameter.normalized()
        lateral = first.normal.cross(along).normalized()
        if lateral.length_squared == 0.0:
            return 1, "found no intersection"
        if rotate:
            lateral = along.cross(lateral).normalized()
        if flip != (height < 0.0):
            lateral.negate()
        sagitta = abs(height)
        arc_radius = (radius * radius + sagitta * sagitta) / (2.0 * sagitta)
        midpoint = (first.co + last.co) * 0.5
        center = midpoint + (sagitta - arc_radius) * lateral
        crown = (midpoint + sagitta * lateral) - center
        spans = (((first.co-center).normalized(), crown.normalized()),
                 (crown.normalized(), (last.co-center).normalized()))
        half_samples = samples // 2
        positions = [center + arc_radius * begin.slerp(end, i / half_samples)
                     for begin,end in spans for i in range(half_samples)]
    map_segment_onto_spline(vert_path, positions)
    return 0, ""


'''

OPERATOR

'''


class SetVertexCurveOp(bpy.types.Operator):
    bl_idname = "mesh.align_vertex_curve"
    bl_label = "Set Vertex Curve"
    bl_options = {'UNDO'}
    bl_description = '''Curves vertices between the selected vertices in picking order of the selected vertices.
    2 vertices selected: placed on a half circle between endpoints.
    3 vertices selected: placed onto a circle segment between endpoints.
    4+ vertices selected: placed onto a spline going through selected vertices

    ALT: reuse last settings
    '''

    mix: FloatProperty(name="Mix", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                       description="Interpolate between inital position and the calculated end position")
    tension: IntProperty(name="Tension", default=0, min=-500, max=500,
                         description="Tension can be used to tighten up the curvature")
    use_topology_distance: BoolProperty(name="Use Topology Distance", default=False,
                                        description="Use the edge count instead of edge lengths for distance measure")
    flip: BoolProperty(name="Flip Half Circle", default=False,
                       description="Flip the half circle into other direction")
    rotate: BoolProperty(name="Rotate Half Circle", default=False,
                       description="Rotate the half circle by 90 degrees")
    space_evenly: BoolProperty(name="Space evenly", default=False,
                               description="Spread the vertices in even distances")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.column().prop(self, "mix")
        controls = layout.column(align=True)
        fields = ["tension", "use_topology_distance"]
        if self.vert_count == 2:
            fields.extend(("flip", "rotate"))
        elif self.vert_count >= 3:
            fields.append("space_evenly")
        for name in fields:
            controls.prop(self, name)

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        active = getattr(context, 'active_object', None)
        if (getattr(space, 'type', None) == 'VIEW_3D'
            and active is not None
            and getattr(active, 'type', None) == "MESH"
                and getattr(active, 'mode', None) == 'EDIT'):

            scene = getattr(context, 'scene', None)
            tool_settings = getattr(scene, 'tool_settings', None)
            mesh_select_mode = tuple(getattr(tool_settings, 'mesh_select_mode', (False, False, False))[:3])
            return mesh_select_mode == (True, False, False)
        return False

    def get_bm(self, me):
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        return bm

    def get_selected(self, bm):
        """Picking order is the order of vertices entered in the active edit history."""
        return [element.index for element in bm.select_history
                if isinstance(element, bmesh.types.BMVert) and element.is_valid and element.select]

    def invoke(self, context, event):
        self.vert_count = 0
        self.intial_vert_positions = []
        if event is not None and not event.alt:
            self.mix = 1.0
            self.tension = 0
            self.use_topology_distance = False
            self.space_evenly = False
        return self.execute(context)

    def execute(self, context):
        bm = self.get_bm(context.object.data)
        selected = self.get_selected(bm)

        if not hasattr(self, 'intial_vert_positions'):
            self.intial_vert_positions = []
        self.vert_count = len(selected)

        if len(selected) < 2:
            self.report(
                {'WARNING'}, f"Align vertex curve: Please select 2, 3 or more vertices")
            return {'CANCELLED'}
        # print ("#" * 66)

        vert_path = collect_vert_path(bm, selected, self.use_topology_distance)

        if len(self.intial_vert_positions) == 0:
            for vert in vert_path:
                self.intial_vert_positions.append(vert.co.copy())

        tension = self.tension / 100.0

        if len(selected) == 2:
            result, msg = circle_2_points(
                bm, selected, vert_path, tension, self.flip, self.rotate)
        elif len(selected) == 3:
            result, msg = circle_3_points(
                bm, selected, vert_path, tension, self.space_evenly)
        else:
            result, msg = curve_hermite(
                bm, selected, vert_path, tension, self.space_evenly)

        if result > 0:
            self.report({'INFO'}, msg)

        for i, vert in enumerate(vert_path):
            vert.co = self.intial_vert_positions[i].lerp(vert.co, self.mix)

        bmesh.update_edit_mesh(context.object.data, loop_triangles=True)

        return {'FINISHED'}
