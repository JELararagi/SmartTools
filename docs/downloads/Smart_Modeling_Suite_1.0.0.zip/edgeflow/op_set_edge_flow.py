import math
import time
import bpy
from bpy.props import IntProperty, FloatProperty, EnumProperty
import bmesh
from . import util

class SetEdgeLoopBase():

    mix: FloatProperty(name="Mix", default=1.0, min=0.0, max=1.0, subtype='FACTOR', description="Interpolate between inital position and the calculated end position")
    
    def get_bm(self, obj):        
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        return bm

    def revert_to_intial_positions(self):        
        for obj in self.objects:
            for index, pos in self.intial_vert_positions[obj].items():
                vert = self.bm[obj].verts[index]
                vert.co = pos

    def store_final_positions(self):
        self.final_vert_positions = {
            obj: {index: self.bm[obj].verts[index].co.copy() for index in initial}
            for obj, initial in self.intial_vert_positions.items()
        }

    def apply_mix(self):
        if self.mix >= 1.0 and self.last_mix >= 1.0:
            return
        for obj, loops in self.edgeloops.items():
            initial = self.intial_vert_positions[obj]
            final = self.final_vert_positions[obj]
            affected = {vertex for loop in loops for vertex in loop.verts}
            for vertex in affected:
                index = vertex.index
                vertex.co = initial[index].lerp(final[index], self.mix)
         

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        active = getattr(context, 'active_object', None)
        return (
            getattr(space, 'type', None) == 'VIEW_3D'
            and active is not None
            and getattr(active, 'type', None) == "MESH"
            and getattr(active, 'mode', None) == 'EDIT')

    '''
    The base invoke stores affected objects, bmesh and intial vertex positions.
    The 'redo' calls by the undo system makes the bm invalid - so i have to look it up again...
    The storing of the intial vertex positions should only happen on the intial code path.  
    '''
    def invoke(self, context):
        self.is_invoked = True

        self.last_mix = self.mix
        
        self.intial_vert_positions = {}
        self.final_vert_positions = {}


        self.objects = set(context.selected_editable_objects) if context.selected_editable_objects else set([context.object])
        self.bm = {}
        self.edgeloops = {}
                
        if not hasattr(self, 'intial_vert_positions'):
            self.intial_vert_positions = {}
        store_intial_positions = not self.intial_vert_positions

        ignore = set()
        for obj in self.objects:
            if obj.mode != 'EDIT':
                ignore.add(obj)
                continue

            bm = self.get_bm(obj)
            edges = [e for e in bm.edges if e.select]
            if len(edges) == 0:
                ignore.add(obj)
                continue

            self.bm[obj] = bm
            edge_loops = util.get_edgeloops(bm, edges)
            self.edgeloops[obj] = edge_loops

            if store_intial_positions:
                self.intial_vert_positions[obj] = {}
                for e in edges:
                    for v in e.verts:
                        if v.index not in self.intial_vert_positions[obj]:
                            p = v.co.copy()
                            p = p.freeze()
                            self.intial_vert_positions[obj][v.index] = p

        self.objects = self.objects - ignore


class SetEdgeFlowOP(bpy.types.Operator, SetEdgeLoopBase):

    bl_idname = "mesh.set_edge_flow"
    is_invoked = False
    bl_label = "Set Edge Flow"
    bl_options = {'UNDO'}
    bl_description = "Adjust curvature to match surface defined by edges crossing the edgeloop\nALT: reuse last settings"

    blend_mode = (
        ("ABSOLUTE", "Absolute", "", 1),
        ("FACTOR", "Factor", "", 2),
    )

    blend_type = (
        ("LINEAR", "Linear", ""),
        ("SMOOTH", "Smooth", ""),
    )   
    
    tension: IntProperty(name="Tension", default=180, min=-500, max=500, description="Tension can be used to tighten up the curvature")    
    iterations: IntProperty(name="Iterations", default=8, min=1, soft_max=32, description="How often the curveature operation is repeated")
    
    blend_mode: bpy.props.EnumProperty(name="Blend Mode", items=blend_mode, description="Switch blend mode between absolute vertex counts and a factor of the whole edgeloop")
    blend_start_int: bpy.props.IntProperty(name="Blend Start", default=0, min=0, description="The number of vertices from the start of the loop used to blend to the adjusted loop position")
    blend_end_int: bpy.props.IntProperty(name="Blend End", default=0, min=0, description="The number of vertices from the end of the loop used to blend to the adjusted loop position")
    blend_start_float: bpy.props.FloatProperty(name="Blend Start", default=0.0, min=0.0, max=1.0, subtype='FACTOR', description="Loop fraction from the start of the loop used to blend to the adjusted loop position")
    blend_end_float: bpy.props.FloatProperty(name="Blend End", default=0.0, min=0.0, max=1.0, subtype='FACTOR', description="Loop fraction from the end of the loop used to blend to the adjusted loop position")
    blend_type: bpy.props.EnumProperty(name="Blend Curve", items=blend_type, description="The interpolation used to blend between the adjusted loop position and the unaffected start and/or end points")
    
    min_angle : IntProperty(name="Min Angle", default=0, min=0, max=180, subtype='FACTOR', description="After which angle the edgeloop curvature is ignored")


    def draw(self, context):
        self.layout.use_property_split = True
        options = self.layout.column(align=True)
        for setting in ("mix", "tension", "iterations", "min_angle"):
            options.prop(self, setting)
        options.separator()
        options.row().prop(self, "blend_mode", expand=True)
        suffix = "int" if self.blend_mode == "ABSOLUTE" else "float"
        for end in ("start", "end"):
            options.prop(self, f"blend_{end}_{suffix}")
        options.row().prop(self, "blend_type", expand=True)
             

    def execute(self, context):
        if not self.is_invoked:
            return self.invoke(context, None)

        if self.mix == self.last_mix:
            tension = self.tension * 0.01
            cutoff = math.radians(self.min_angle)
            for obj in self.objects:
                loops = self.edgeloops[obj]
                for _ in range(self.iterations):
                    for loop in loops:
                        loop.set_flow(tension=tension, min_angle=cutoff)
                for loop in loops:
                    if self.blend_mode == "FACTOR":
                        size = len(loop.verts)
                        amounts = round(size * self.blend_start_float), round(size * self.blend_end_float)
                    else:
                        amounts = self.blend_start_int, self.blend_end_int
                    loop.blend_start_end(*amounts, self.blend_type)
            self.store_final_positions()

        self.apply_mix()
        for obj in self.objects:
            self.bm[obj].normal_update()
            bmesh.update_edit_mesh(obj.data)
        self.last_mix = self.mix
        self.is_invoked = False
        return {"FINISHED"}


    def invoke(self, context, event):
        super().invoke(context)
        if event and not event.alt:
            for name, value in (
                ("mix", 1.0), ("tension", 180), ("iterations", 16), ("min_angle", 0),
                ("blend_start_int", 0), ("blend_end_int", 0),
                ("blend_start_float", 0), ("blend_end_float", 0),
            ):
                setattr(self, name, value)
        return self.execute(context)



