# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import sys

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty

try:
    from ..edit_multi import edit_mesh_objects as _sms_edit_mesh_objects, selected_mesh_objects as _sms_selected_mesh_objects
except Exception:
    _sms_edit_mesh_objects = None
    _sms_selected_mesh_objects = None

bl_info = {
    "name": "Weighted Normal",
    "author": "Smart Modeling",
    "version": (1, 1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Edit Mode > Alt+N Menu",
    "description": "Add and apply a Weighted Normal modifier from Edit Mode.",
    "category": "Mesh",
}

translation_dict = {
    "ja_JP": {
        ("*", "Apply Weighted Normal"): "重み付き法線を適用",
        ("*", "Add and apply a Weighted Normal modifier from Edit Mode."): '編集モードから重み付き法線モディファイアーを追加して適用します。',
        ("*", "No mesh object selected"): "メッシュオブジェクトが選択されていません",
        ("*", "Applied weighted normals"): '重み付き法線を適用しました',
        ("*", "Added weighted normal modifier"): '重み付き法線モディファイアーを追加しました',
        ("*", "Selection-limited apply is not supported in this migrated version; the modifier is applied to the whole object."):
            "この移植版では選択範囲限定適用には対応していないため、オブジェクト全体へ適用します。",
        ("*", "An error occurred: "): "エラーが発生しました: ",
        ("*", "Preset"): "プリセット",
        ("*", "Choose the preset used when creating the Weighted Normal modifier."): '重み付き法線モディファイアーを作る時のプリセットを選びます。',
        ("*", "Apply Mode"): '適用モード',
        ("*", "Choose whether the modifier is applied immediately or kept non-destructive."): "すぐ適用するか、非破壊で残すかを選択します。",
        ("*", "Limit To Selection"): "選択範囲のみ",
        ("*", "Compatibility option kept for the suite UI. This migrated version applies Weighted Normal to the whole object."): '画面の互換のためのオプションです。重み付き法線はオブジェクト全体に適用します。',
        ("*", "Keep Sharp"): "シャープを維持",
        ("*", "Keep sharp edges enabled when creating the modifier."): "モディファイア作成時にシャープ維持を有効にします。",
        ("*", "Weight"): 'ウェイト',
        ("*", "Weight value used by the created modifier."): "作成されるモディファイアで使う重み値です。",
        ("*", "Threshold"): "しきい値",
        ("*", "Threshold used by the created modifier."): "作成されるモディファイアで使うしきい値です。",
        ("*", "Run Apply Weighted Normal"): "重み付き法線を実行",
        ("*", "Add an execution button to Blender's standard Alt+N Normals popup while this feature is enabled."): "この機能が有効なとき、Blender標準のAlt+N ノーマルポップアップに実行ボタンを追加します。",
    }
}


def _suite_prefs(context=None):
    try:
        from ..utils import get_suite_prefs
        return get_suite_prefs(context or bpy.context)
    except Exception:
        return None


def _edit_mesh_objects(context):
    if callable(_sms_edit_mesh_objects):
        try:
            return list(_sms_edit_mesh_objects(context, unique_data=False))
        except Exception:
            pass
    objects = []
    try:
        for obj in tuple(getattr(context, 'objects_in_mode', None) or ()):  # object-level modifier operation; do not unique-filter data
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT' and obj not in objects:
                objects.append(obj)
    except Exception:
        pass
    if objects:
        return objects
    try:
        obj = getattr(context, 'active_object', None)
        if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
            objects.append(obj)
    except Exception:
        pass
    return objects


def _selected_mesh_objects(context):
    if callable(_sms_selected_mesh_objects):
        try:
            return list(_sms_selected_mesh_objects(context))
        except Exception:
            pass
    result = []
    try:
        for obj in tuple(getattr(context, 'selected_objects', ()) or ()):  # object mode fallback
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and obj not in result:
                result.append(obj)
    except Exception:
        pass
    try:
        obj = getattr(context, 'active_object', None)
        if obj is not None and getattr(obj, 'type', None) == 'MESH' and obj not in result:
            result.insert(0, obj)
    except Exception:
        pass
    return result


def _target_mesh_objects(context):
    edit_objects = _edit_mesh_objects(context)
    if edit_objects:
        return edit_objects
    return _selected_mesh_objects(context)


def _selection_snapshot(context):
    try:
        active = getattr(context.view_layer.objects, 'active', None)
    except Exception:
        active = getattr(context, 'active_object', None)
    try:
        selected = tuple(getattr(context, 'selected_objects', ()) or ())
    except Exception:
        selected = tuple()
    return active, selected


def _restore_selection_snapshot(context, snapshot):
    active, selected = snapshot if snapshot else (None, tuple())
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    for obj in selected:
        try:
            if obj is not None and obj.name in bpy.data.objects:
                obj.select_set(True)
        except Exception:
            pass
    try:
        if active is not None and active.name in bpy.data.objects:
            context.view_layer.objects.active = active
    except Exception:
        pass


class AWN_AddonPreferences(bpy.types.PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        description="Choose the preset used when creating the Weighted Normal modifier.",
        items=[
            ('HARD_SURFACE', 'Hard Surface Modeling', ''),
            ('GAME', 'Game Asset', ''),
            ('MINIMAL', 'Minimal', ''),
            ('CUSTOM', 'Custom', ''),
        ],
        default='HARD_SURFACE',
    )
    apply_mode: EnumProperty(
        name="Apply Mode",
        description="Choose whether the modifier is applied immediately or kept non-destructive.",
        items=[
            ('ADD_AND_APPLY', 'Add & Apply', ''),
            ('ADD_ONLY', 'Add Only', ''),
        ],
        default='ADD_AND_APPLY',
    )
    limit_to_selection: BoolProperty(
        name="Limit To Selection",
        description="Compatibility option kept for the suite UI. This migrated version applies Weighted Normal to the whole object.",
        default=False,
    )
    keep_sharp: BoolProperty(
        name="Keep Sharp",
        description="Keep sharp edges enabled when creating the modifier.",
        default=True,
    )
    weight: FloatProperty(
        name="Weight",
        description="Weight value used by the created modifier.",
        default=50.0,
        min=1.0,
        max=100.0,
    )
    threshold: FloatProperty(
        name="Threshold",
        description="Threshold used by the created modifier.",
        default=0.01,
        min=0.0,
        max=10.0,
        precision=4,
    )


class MESH_OT_ApplyWeightedNormal(bpy.types.Operator):
    """Apply Weighted Normal"""
    bl_idname = "mesh.apply_weighted_normal"
    bl_label = 'Apply Weighted Normal'
    bl_options = {'UNDO'}

    preset: EnumProperty(
        name="Preset",
        items=[
            ('HARD_SURFACE', 'Hard Surface Modeling', ''),
            ('GAME', 'Game Asset', ''),
            ('MINIMAL', 'Minimal', ''),
            ('CUSTOM', 'Custom', ''),
        ],
        default='CUSTOM',
    )
    apply_mode: EnumProperty(
        name="Apply Mode",
        items=[
            ('ADD_AND_APPLY', 'Add & Apply', ''),
            ('ADD_ONLY', 'Add Only', ''),
        ],
        default='ADD_AND_APPLY',
    )
    limit_to_selection: BoolProperty(name="Limit To Selection", default=False)
    keep_sharp: BoolProperty(name="Keep Sharp", default=True)
    weight: FloatProperty(name="Weight", default=50.0, min=1.0, max=100.0)
    threshold: FloatProperty(name="Threshold", default=0.01, min=0.0, max=10.0, precision=4)

    @classmethod
    def poll(cls, context):
        try:
            if context.mode == 'EDIT_MESH':
                return bool(_edit_mesh_objects(context))
            return bool(_target_mesh_objects(context))
        except Exception:
            return False

    def invoke(self, context, _event):
        prefs = None
        try:
            suite = _suite_prefs(context)
            prefs = getattr(suite, 'apply_weighted_normal', None) if suite else None
        except Exception:
            prefs = None
        if prefs is not None:
            try:
                if self.preset == 'CUSTOM':
                    self.preset = getattr(prefs, 'preset', 'HARD_SURFACE')
                self.apply_mode = getattr(prefs, 'apply_mode', self.apply_mode)
                self.limit_to_selection = getattr(prefs, 'limit_to_selection', self.limit_to_selection)
                self.keep_sharp = getattr(prefs, 'keep_sharp', self.keep_sharp)
                self.weight = float(getattr(prefs, 'weight', self.weight))
                self.threshold = float(getattr(prefs, 'threshold', self.threshold))
            except Exception:
                pass
        return self.execute(context)

    def _apply_preset(self):
        preset = str(self.preset or 'HARD_SURFACE')
        if preset == 'HARD_SURFACE':
            self.keep_sharp = True
            self.weight = 75.0
            self.threshold = 0.01
        elif preset == 'GAME':
            self.keep_sharp = True
            self.weight = 50.0
            self.threshold = 0.01
        elif preset == 'MINIMAL':
            self.keep_sharp = False
            self.weight = 50.0
            self.threshold = 0.0

    def execute(self, context):
        pgettext = bpy.app.translations.pgettext
        targets = _target_mesh_objects(context)
        if not targets:
            self.report({'WARNING'}, pgettext("No mesh object selected"))
            return {'CANCELLED'}

        self._apply_preset()

        if self.limit_to_selection:
            self.report({'INFO'}, pgettext("Selection-limited apply is not supported in this migrated version; the modifier is applied to the whole object."))

        prev_mode = context.mode
        snapshot = _selection_snapshot(context)
        applied = 0
        added = 0
        try:
            if prev_mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception:
                    pass

            for obj in targets:
                if obj is None or getattr(obj, 'type', None) != 'MESH':
                    continue
                try:
                    mod = obj.modifiers.new(name="WeightedNormal_Temp", type='WEIGHTED_NORMAL')
                    mod.keep_sharp = bool(self.keep_sharp)
                    try:
                        mod.weight = int(round(self.weight))
                    except Exception:
                        mod.weight = self.weight
                    try:
                        mod.thresh = float(self.threshold)
                    except Exception:
                        pass

                    if self.apply_mode == 'ADD_ONLY':
                        added += 1
                        continue

                    try:
                        bpy.ops.object.select_all(action='DESELECT')
                    except Exception:
                        pass
                    try:
                        obj.select_set(True)
                        context.view_layer.objects.active = obj
                    except Exception:
                        pass
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                    applied += 1
                except Exception as exc:
                    # Continue with the remaining selected/edit objects; report an
                    # error only if every target fails.
                    last_error = exc
                    continue

            if self.apply_mode == 'ADD_ONLY' and added:
                self.report({'INFO'}, pgettext("Added weighted normal modifier"))
            elif applied:
                self.report({'INFO'}, pgettext("Applied weighted normals"))
            else:
                message = str(locals().get('last_error', ''))
                self.report({'ERROR'}, pgettext("An error occurred: ") + message)
                return {'CANCELLED'}
        finally:
            try:
                _restore_selection_snapshot(context, snapshot)
            except Exception:
                pass
            try:
                if prev_mode == 'EDIT_MESH':
                    bpy.ops.object.mode_set(mode='EDIT')
                elif prev_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode=prev_mode)
            except Exception:
                try:
                    if prev_mode == 'EDIT_MESH':
                        bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass

        return {'FINISHED'}


_menu_appended = False
_menu_runtime_active = False


def _copy_prefs_to_operator(op, context=None):
    prefs = None
    try:
        suite = _suite_prefs(context)
        prefs = getattr(suite, 'apply_weighted_normal', None) if suite else None
    except Exception:
        prefs = None
    if prefs is None or op is None:
        return op
    for attr in ('preset', 'apply_mode', 'limit_to_selection', 'keep_sharp', 'weight', 'threshold'):
        try:
            if hasattr(op, attr):
                setattr(op, attr, getattr(prefs, attr))
        except Exception:
            pass
    return op


def _menu_runtime_enabled(context=None):
    try:
        suite = _suite_prefs(context)
        if suite is None:
            return False
        return bool(getattr(suite, 'enable_apply_weighted_normal', False))
    except Exception:
        return False


def menu_func(self, context):
    try:
        if not _menu_runtime_active:
            return
        layout = getattr(self, 'layout', None)
        if layout is None:
            return
        layout.separator()
        op = layout.operator(MESH_OT_ApplyWeightedNormal.bl_idname, text=bpy.app.translations.pgettext('Run Apply Weighted Normal'), icon='MOD_NORMALEDIT')
        _copy_prefs_to_operator(op, context)
    except Exception:
        pass


def enable_menu_integration():
    global _menu_appended, _menu_runtime_active
    _menu_runtime_active = True
    menu = getattr(bpy.types, 'VIEW3D_MT_edit_mesh_normals', None)
    if menu is None:
        return False
    try:
        menu.remove(menu_func)
    except Exception:
        pass
    try:
        menu.append(menu_func)
        _menu_appended = True
        return True
    except Exception:
        _menu_appended = False
        return False


def disable_menu_integration():
    global _menu_appended, _menu_runtime_active
    _menu_runtime_active = False
    menu = getattr(bpy.types, 'VIEW3D_MT_edit_mesh_normals', None)
    if menu is not None:
        try:
            menu.remove(menu_func)
        except Exception:
            pass
    _menu_appended = False
    return True


classes = (
    AWN_AddonPreferences,
    MESH_OT_ApplyWeightedNormal,
)


def register():
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass

    if _menu_runtime_enabled(getattr(bpy, 'context', None)):
        enable_menu_integration()
    else:
        disable_menu_integration()


def unregister():
    disable_menu_integration()

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
