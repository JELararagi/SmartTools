# -*- coding: utf-8 -*-
"""N-panel settings bridge for integrated tools in Smart Modeling.

Integrated tools are loaded as submodules of the root extension package.  This
module supplies per-tool WindowManager PropertyGroup proxies so legacy modules
that request add-on-style settings can still run, while the visible UI and saved
state remain controlled from the Smart Modeling N-panel instead of Blender's
legacy preference properties.
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

import bpy
from bpy.props import PointerProperty
from .bootstrap_common import (
    class_is_owned_for_mutation as _prefs_owned_class,
    registered_propertygroup_subclass as _prefs_registered_propertygroup_subclass,
    safe_register_class as _prefs_exact_safe_register_class,
    safe_unregister_class as _prefs_exact_safe_unregister_class,
)

_PROXY_CLASSES: dict[str, type] = {}
_PROXY_PROPS: dict[str, str] = {}
_REGISTERED = False


class _AddonEntryProxy:
    __slots__ = ('module', 'preferences')

    def __init__(self, module: str, preferences: Any):
        self.module = str(module or '')
        self.preferences = preferences


def _sanitize_name(text: str) -> str:
    value = re.sub(r'[^0-9A-Za-z_]+', '_', str(text or '').strip())
    value = re.sub(r'_+', '_', value).strip('_')
    if not value:
        value = 'integrated_addon'
    if value[0].isdigit():
        value = '_' + value
    return value


def _key_token(text: str) -> str:
    clean = _sanitize_name(text)[:24]
    digest = hashlib.sha1(str(text or '').encode('utf-8')).hexdigest()[:10]
    if not clean:
        clean = 'integrated_addon'
    return f'{clean}_{digest}'




def _prop_deferred_kind(prop_def) -> str:
    try:
        fn = getattr(prop_def, 'function', None)
        name = str(getattr(fn, '__name__', '') or '')
        if name:
            return name
    except Exception:
        pass
    try:
        text = repr(prop_def)
    except Exception:
        text = ''
    for name in (
        'BoolProperty', 'IntProperty', 'FloatProperty', 'StringProperty',
        'EnumProperty', 'FloatVectorProperty', 'IntVectorProperty',
        'BoolVectorProperty', 'PointerProperty', 'CollectionProperty',
    ):
        if name in text:
            return name
    return ''


def _safe_proxy_annotations(prefs_cls: type | None) -> dict[str, Any]:
    annotations = dict(getattr(prefs_cls, '__annotations__', {}) or {}) if prefs_cls is not None else {}
    safe = {}
    for name, prop_def in annotations.items():
        kind = _prop_deferred_kind(prop_def)
        # Pointer/Collection properties frequently reference classes that are not
        # registered while integrated tools are loaded lazily.  Keeping them in a
        # proxy PropertyGroup can produce missing bl_rna PointerProperty errors.
        if kind in {'PointerProperty', 'CollectionProperty'}:
            continue
        safe[name] = prop_def
    return safe


def _proxy_class_ready(cls) -> bool:
    # NOTE: getattr(cls, 'bl_rna') is NOT a registration check on Blender
    # 5.1.2 - an unregistered PropertyGroup subclass inherits bl_rna from the
    # base type, so that check reports stale proxies as ready and lets them
    # reach PointerProperty(type=...), which then fails with missing bl_rna.
    # Only the RNA registry lookup is truthful.
    try:
        return _prefs_registered_propertygroup_subclass(str(getattr(cls, '__name__', '') or '')) is cls
    except Exception:
        return False


def _safe_register_proxy_class(cls) -> bool:
    # Registration is exact-identity owned. A same-name foreign RNA class is a
    # collision, not a stale proxy that this suite may reuse or replace.
    return bool(_prefs_exact_safe_register_class(cls) and _proxy_class_ready(cls))

def _addon_key_candidates(addon_key: str) -> tuple[str, ...]:
    text = str(addon_key or '').strip()
    if not text:
        return tuple()
    candidates: list[str] = [text]
    leaf = text.split('.')[-1].strip()
    if leaf and leaf not in candidates:
        candidates.append(leaf)
    return tuple(candidates)


def _real_preferences(context, addon_key: str):
    # Kept only as a compatibility stub for older internal imports.
    # Integrated tool settings must resolve through the N-panel proxy path below.
    return None


def _build_proxy_methods(annotation_names: tuple[str, ...]):
    names = tuple(annotation_names)

    def keys(self):
        return list(names)

    def values(self):
        
        result = []
        for name in names:
            try:
                result.append(getattr(self, name))
            except Exception:
                pass
        return result

    def items(self):
        
        result = []
        for name in names:
            try:
                result.append((name, getattr(self, name)))
            except Exception:
                pass
        return result

    def get(self, key, default=None):
        try:
            return getattr(self, str(key), default)
        except Exception:
            return default

    def __contains__(self, key):
        
        try:
            getattr(self, str(key))
            return True
        except Exception:
            return False

    def __getitem__(self, key):
        return getattr(self, str(key))

    def __setitem__(self, key, value):
        try:
            setattr(self, str(key), value)
        except Exception:
            pass

    return {
        'keys': keys,
        'values': values,
        'items': items,
        'get': get,
        '__contains__': __contains__,
        '__getitem__': __getitem__,
        '__setitem__': __setitem__,
    }


def _create_proxy_class(addon_key: str, prefs_cls: type | None) -> type:
    annotations = _safe_proxy_annotations(prefs_cls)
    class_name = f'SMS_INTPREFS_{_key_token(addon_key)}'
    # A same-session Suite re-enable can leave Blender's live RNA class
    # available briefly after the Python registry dictionaries were cleared.
    # Reuse that authoritative class object.  Returning a freshly-created but
    # unregistered class with the same name makes PointerProperty reject the
    # proxy and causes every integrated preference lookup to return None.
    try:
        # bpy.types attribute lookup never finds registered PropertyGroups on
        # Blender 5.1; the RNA registry lookup is the working equivalent.
        existing = _prefs_registered_propertygroup_subclass(class_name)
    except Exception:
        existing = None
    if isinstance(existing, type) and _proxy_class_ready(existing) and _prefs_owned_class(existing):
        return existing
    attrs: dict[str, Any] = {
        '__module__': __name__,
        '__annotations__': annotations,
        # The proxy stands in for this class when pre-load panel values are copied over.
        '_sms_source_class_name': str(getattr(prefs_cls, '__name__', '') or ''),
    }
    attrs.update(_build_proxy_methods(tuple(annotations.keys())))
    proxy_cls = type(class_name, (bpy.types.PropertyGroup,), attrs)
    if _safe_register_proxy_class(proxy_cls):
        try:
            registered = _prefs_registered_propertygroup_subclass(class_name)
        except Exception:
            registered = None
        return registered if isinstance(registered, type) and _proxy_class_ready(registered) and _prefs_owned_class(registered) else proxy_cls
    else:
        # Fallback to an empty proxy instead of propagating a partially-registered
        # class into PointerProperty(type=...), which causes missing bl_rna errors.
        attrs['__annotations__'] = {}
        attrs.update(_build_proxy_methods(tuple()))
        proxy_cls = type(class_name, (bpy.types.PropertyGroup,), attrs)
        _safe_register_proxy_class(proxy_cls)
    try:
        registered = getattr(bpy.types, class_name, None)
    except Exception:
        registered = None
    return registered if isinstance(registered, type) and _proxy_class_ready(registered) and _prefs_owned_class(registered) else proxy_cls


def _ensure_proxy_storage(addon_key: str, prefs_cls: type | None) -> str:
    key = str(addon_key or '').strip() or 'integrated_addon'
    proxy_cls = _PROXY_CLASSES.get(key)
    if proxy_cls is None or not _proxy_class_ready(proxy_cls):
        _PROXY_CLASSES[key] = _create_proxy_class(key, prefs_cls)
        proxy_cls = _PROXY_CLASSES[key]
    token = _key_token(key).lower().lstrip('_')
    prop_name = _PROXY_PROPS.get(key) or f'sms_intprefs_{token}'
    # A loader-owned RNA cleanup can remove the WindowManager property before
    # the parent preference bridge is asked to clear its Python dictionaries.
    # Never trust the cached name alone: reconstruct the missing property from
    # the live proxy class during the next same-session enable.
    if not hasattr(bpy.types.WindowManager, prop_name):
        try:
            if proxy_cls is None or not _proxy_class_ready(proxy_cls):
                _PROXY_CLASSES[key] = _create_proxy_class(key, prefs_cls)
                proxy_cls = _PROXY_CLASSES[key]
            if _proxy_class_ready(proxy_cls):
                setattr(bpy.types.WindowManager, prop_name, PointerProperty(type=proxy_cls, options={'SKIP_SAVE'}))
        except Exception:
            # If the proxy type is not accepted by RNA, rebuild it empty once, but
            # never pass an unregistered class into PointerProperty.
            _PROXY_CLASSES[key] = _create_proxy_class(key, None)
            try:
                if _proxy_class_ready(_PROXY_CLASSES[key]):
                    setattr(bpy.types.WindowManager, prop_name, PointerProperty(type=_PROXY_CLASSES[key], options={'SKIP_SAVE'}))
            except Exception:
                pass
    _PROXY_PROPS[key] = prop_name
    return prop_name


def register() -> None:
    global _REGISTERED
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    for prop_name in reversed(tuple(_PROXY_PROPS.values())):
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                delattr(bpy.types.WindowManager, prop_name)
        except Exception:
            pass
    _PROXY_PROPS.clear()

    for proxy_cls in reversed(tuple(_PROXY_CLASSES.values())):
        _prefs_exact_safe_unregister_class(proxy_cls)
    _PROXY_CLASSES.clear()
    _REGISTERED = False


def get_preferences(context=None, addon_key: str | None = None, prefs_cls: type | None = None):
    if not _REGISTERED:
        register()
    context = context or getattr(bpy, 'context', None)
    base_key = str(addon_key or '').strip() or str(getattr(prefs_cls, 'bl_idname', '') or 'integrated_addon')
    if prefs_cls is not None:
        cls_key = f"{getattr(prefs_cls, '__module__', '')}.{getattr(prefs_cls, '__name__', '')}".strip('.')
        key = f"{base_key}:{cls_key}" if cls_key else base_key
    else:
        key = base_key

    # Do not use Blender legacy preference properties for integrated tools.
    # All integrated settings are proxied through WindowManager storage and
    # persisted by the suite's N-panel JSON settings snapshot.
    prop_name = _ensure_proxy_storage(key, prefs_cls)
    wm = getattr(context, 'window_manager', None) if context is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return None
    try:
        return getattr(wm, prop_name)
    except Exception:
        return None


def get_addon_entry(context=None, addon_key: str | None = None, prefs_cls: type | None = None):
    return _AddonEntryProxy(str(addon_key or ''), get_preferences(context=context, addon_key=addon_key, prefs_cls=prefs_cls))
