# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Lazy-loaded Smart Geometry help.

This module is intentionally not imported by UI, runtime, or normal operators.
Only the small ``smart_geometry_suite.open_help`` operator imports it after a
Help icon is clicked.  The long manual strings, popup wrapping helpers, and popup
operator registration live here so Blender startup and ordinary N-panel redraws
stay light.
"""

import unicodedata
from dataclasses import dataclass
from typing import Any

import bpy
from bpy.props import IntProperty, StringProperty

from . import always_on, catalog

_TRANSLATION_DOMAIN = 'smart_geometry_suite_lazy_help'
_TRANSLATIONS_REGISTERED = False


def _is_ja(context=None) -> bool:
    try:
        return catalog.is_japanese(context)
    except Exception:
        try:
            locale = str(getattr(bpy.app.translations, 'locale', '') or '')
            if not locale:
                locale = str(getattr(bpy.context.preferences.view, 'language', '') or '')
            return locale.lower().startswith('ja')
        except Exception:
            return False


def _pair(en: str, ja: str, context=None) -> str:
    return str(ja if _is_ja(context) else en)


@dataclass(frozen=True)
class SettingHelp:
    key: str
    name_en: str
    name_ja: str
    desc_en: str
    desc_ja: str


def _s(key: str, en: str, ja: str, desc_en: str, desc_ja: str) -> SettingHelp:
    return SettingHelp(key, en, ja, desc_en, desc_ja)


_SETTINGS: dict[str, SettingHelp] = {item.key: item for item in [
    _s('feature_category', 'Feature Category', '機能カテゴリ', 'Filters the feature catalog by functional family. It only changes the visible list and never modifies generated node groups.', '機能カタログを用途別カテゴリで絞り込みます。表示リストだけを変え、生成済みノードグループは変更しません。'),
    _s('source_filter', 'Design Domain Filter', '設計ドメインフィルター', 'Filters the catalog by independent design domain such as attributes, selection, terrain, motion, architecture, materials, diagnostics, automation, or open data.', '属性、選択、地形、モーション、建築、マテリアル、診断、自動化、外部データなどの独自設計ドメインで絞り込みます。'),
    _s('active_feature', 'Active Feature', 'アクティブ機能', 'Chooses the feature capsule that Apply Feature and the contextual feature help will use.', '機能を適用ボタンと機能別ヘルプで対象にするカプセルを選びます。'),
    _s('active_pack', 'Active Pack', 'アクティブパック', 'Chooses a workflow pack made from multiple capsules, such as core attributes, environment generation, motion, architecture, interop, or precision workflows.', 'コア属性、環境生成、モーション、建築、外部連携、精度処理など、複数カプセルをまとめたワークフローパックを選びます。'),
    _s('search_filter', 'Search Filter', '検索フィルター', 'Narrows visible catalog rows by name, domain, keyword, category, or Japanese term.', '名前、ドメイン、キーワード、カテゴリ、日本語語句で表示カタログを絞り込みます。'),
    _s('capsule_prefix', 'Capsule Prefix', 'カプセル接頭辞', 'Prefix used for generated node groups, modifiers, helper objects, reports, and attributes. Keep it unique to locate and remove generated data easily.', '生成ノードグループ、モディファイア、補助オブジェクト、レポート、属性に付ける接頭辞です。固有にしておくと生成物の検索と削除が容易になります。'),
    _s('mark_assets', 'Mark Node Groups as Assets', 'ノードグループをアセット化', 'Marks newly generated node groups as Blender assets when the running Blender build supports it.', '現在のBlenderが対応している場合、生成したノードグループをBlenderアセットとして登録します。'),
    _s('selection_string', 'Selection String', '選択文字列', 'Expression used by the precision selection engine. It supports index ranges, keywords, comparisons, bands, ranks, grow/shrink, and boolean combinations.', '高精度選択エンジンで使う式です。インデックス範囲、キーワード、比較、帯域、順位、成長/収縮、論理演算を扱えます。'),
    _s('terrain_resolution', 'Terrain Resolution', '地形解像度', 'Number of grid points per side for generated precision terrain. Higher values improve detail but increase computation.', '高精度地形の一辺あたりのグリッド点数です。大きいほど詳細になりますが計算量が増えます。'),
    _s('terrain_size', 'Terrain Size', '地形サイズ', 'World size of the generated terrain grid.', '生成地形グリッドのワールドサイズです。'),
    _s('terrain_height', 'Terrain Height', '地形高さ', 'Maximum procedural displacement height written into height, slope, flow, wetness, sediment, erosion, channel, stream, bank, and strata attributes.', '高さ、傾斜、流れ、湿り、堆積、侵食、水路、流路、河岸、地層属性へ反映する最大変位高さです。'),
    _s('terrain_erosion_iterations', 'Terrain Erosion Iterations', '地形侵食反復', 'Thermal relaxation pass count before hydraulic flow and sediment attributes are calculated.', '水理フローと堆積属性を計算する前に行う熱緩和パス数です。'),
    _s('terrain_hydraulic_droplets', 'Terrain Hydraulic Droplets', '地形水理ドロップ数', 'Number of deterministic water-drop walkers used to carve cleaner channels, banks, deposition fields, and stream-order attributes.', '水路、河岸、堆積場、流路次数属性を形成する決定論的な水滴ウォーカー数です。'),
    _s('terrain_hydraulic_iterations', 'Terrain Hydraulic Iterations', '地形水理反復', 'Lightweight hydraulic transport pass count used by terrain helper functions.', '地形補助処理で使う軽量水理輸送パス数です。'),
    _s('terrain_channel_strength', 'Terrain Channel Strength', '地形水路強度', 'Strength of channel carving and deposition. Lower values are subtle; higher values cut stronger river paths.', '水路カットと堆積の強度です。低い値は控えめ、高い値は強い河川跡になります。'),
    _s('terrain_v7_ridge_preservation', 'Terrain Ridge Preservation', '地形稜線保持', 'Controls ridge-preserving relaxation so sharp ridges remain while unstable pits and terraces are smoothed.', '稜線を残しながら不安定な窪みや段丘を滑らかにする緩和の強さです。'),
    _s('terrain_v7_channel_count', 'Terrain Channel Count', '地形水路数', 'Maximum number of primary deterministic channel walkers.', '主要な決定論的水路ウォーカーの最大数です。'),
    _s('terrain_v7_field_fusion', 'Terrain Field Fusion', '地形フィールド融合', 'Post-terrain fusion strength for channel, watershed, contour, patch, material, and distribution handoff attributes.', '地形生成後に水路、流域、等高線、パッチ、マテリアル、分布受け渡し属性を統合する強さです。'),
    _s('scatter_count', 'Scatter Count', '散布数', 'Target count used by surface distribution, helper blocks, growth curves, and proxy instances.', '表面分布、補助ブロック、成長カーブ、プロキシインスタンスで使う目標数です。'),
    _s('structure_floors', 'Structure Floors', '階数', 'Number of floors in the modular structure. More floors make a taller structure; the width and depth follow Radius / Size.', 'モジュラー構造の階の数です。増やすほど高くなります。幅と奥行きは「半径 / サイズ」で決まります。'),
    _s('scatter_radius', 'Scatter Radius', '散布半径', 'Default radius, spacing, or helper-object size for scatter, growth, surface detail, visible proxies, and fragmentation.', '散布、成長、表面ディテール、可視プロキシ、破片化で使う標準半径・間隔・補助サイズです。'),
    _s('scatter_min_spacing', 'Scatter Minimum Spacing', '散布最小間隔', 'Minimum world-space distance between accepted scatter points when blue-noise rejection is enabled.', 'ブルーノイズ除外が有効なとき、採用される散布点同士の最小ワールド距離です。'),
    _s('scatter_blue_noise', 'Use Blue-Noise Rejection', 'ブルーノイズ除外を使用', 'Rejects candidates that are too close to accepted points to reduce visible clumping.', '採用済み点に近すぎる候補を拒否し、見た目の偏りを減らします。'),
    _s('scatter_quality_passes', 'Scatter Quality Passes', '散布品質パス', 'Candidate quality pass count for adaptive low-discrepancy surface distribution.', '適応型低差異表面分布の候補品質パス数です。'),
    _s('scatter_relax_iterations', 'Scatter Relax Iterations', '散布緩和反復', 'Post-placement relaxation pass count for reducing residual point clumping.', '配置後に残る点群の偏りを減らす緩和反復数です。'),
    _s('scatter_adaptive_spacing', 'Use Adaptive Spacing', '適応間隔を使用', 'Adapts spacing by density, habitat score, and slope so stable dense areas can accept closer points.', '密度、生息環境スコア、傾斜に応じて間隔を変え、安定した高密度領域には近い点配置を許可します。'),
    _s('scatter_visibility_culling', 'Use Camera Visibility Gate', 'カメラ可視性ゲートを使用', 'When a camera exists, down-ranks or rejects distribution outside the camera frustum by using visibility attributes.', 'カメラがある場合、可視性属性を使って視錐台外の分布を低評価または拒否します。'),
    _s('scatter_normal_offset', 'Scatter Normal Offset', '散布法線オフセット', 'Offsets generated scatter points along sampled surface normals.', '生成した散布点をサンプル面の法線方向へずらします。'),
    _s('scatter_biome_bias', 'Scatter Habitat Bias', '散布生息環境バイアス', 'Adjusts how strongly habitat attributes influence distribution weight.', '生息環境属性が分布ウェイトへ与える影響の強さです。'),
    _s('scatter_candidate_multiplier', 'Scatter Candidate Multiplier', '散布候補倍率', 'Number of candidate samples tested per requested point. Higher values improve spacing and weighted placement.', '要求点ごとに試す候補サンプル数です。大きいほど間隔と重み付き配置が安定します。'),
    _s('scatter_v7_lloyd_iterations', 'Tangent Relax Iterations', '接平面緩和反復', 'Additional tangent-plane relaxation passes after point distribution.', '点分布後に行う接平面方向の追加緩和パス数です。'),
    _s('scatter_v7_fairness_strength', 'Distribution Fairness Strength', '分布均等性強度', 'Strength used by spacing diagnostics and relaxation to normalize nearest-neighbor distances.', '間隔診断と緩和で最近傍距離を均一化する強さです。'),
    _s('scatter_v7_anisotropy_strength', 'Scatter Anisotropy Strength', '散布異方性強度', 'How strongly normal, tangent, flow, and slope direction affect distribution diagnostics.', '法線、接線、流れ、傾斜方向が分布診断へ影響する強さです。'),
    _s('scatter_v7_priority_bias', 'Scatter Priority Bias', '散布優先度バイアス', 'How strongly distribution priority favors high-confidence, high-habitat, low-risk areas.', '高信頼・高生息適性・低リスク領域を優先する強さです。'),
    _s('scatter_v8_stability_bias', 'Scatter Stability Bias', '散布安定性バイアス', 'Prioritizes stable, visible, high-confidence regions when scoring distribution points.', '分布点を評価するときに安定・可視・高信頼領域を優先します。'),
    _s('density_threshold', 'Density Threshold', '密度しきい値', 'Threshold used by density, selection, habitat, scatter, and visibility tools.', '密度、選択、生息環境、散布、可視性ツールで使うしきい値です。'),
    _s('growth_branches', 'Growth Branches', '成長枝数', 'Number of deterministic branch splines created by organic growth helpers.', '有機成長ヘルパーで作成する決定論的な枝スプライン数です。'),
    _s('drainage_curve_count', 'Drainage Curve Count', '排水カーブ数', 'Maximum number of downhill flow curves generated from terrain or mesh attributes.', '地形またはメッシュ属性から生成する下り方向フローカーブの最大数です。'),
    _s('fragment_piece_count', 'Fragment Piece Count', '破片数', 'Target number of clustered mesh fragments. Zero chooses the amount automatically from the face count of the mesh.', 'クラスタ破片の目標数です。0の場合はメッシュの面数から自動で決めます。'),
    _s('fragment_v7_contiguity', 'Fragment Contiguity Bias', '破片連続性バイアス', 'How strongly graph clustering keeps adjacent faces in the same fragment.', '隣接面を同じ破片に保つグラフクラスタリングの強さです。'),
    _s('fragment_v7_compactness', 'Fragment Compactness', '破片コンパクト性', 'Compactness scoring for generated fragments so pieces remain readable for animation and handoff.', '生成破片のコンパクトさを評価し、アニメーションや受け渡しで読みやすい破片にします。'),
    _s('fragment_v8_interlock_bias', 'Fragment Interlock Bias', '破片連結性バイアス', 'Controls readability, glue, and seam metadata after clustered fragmentation.', 'クラスタ破片化後の読みやすさ、接着、切れ目メタデータを調整します。'),
    _s('diagnostic_sample_limit', 'Diagnostic Sample Limit', '診断サンプル上限', 'Maximum number of object and attribute samples written into diagnostic reports.', '診断レポートに書き出すオブジェクトと属性サンプルの最大数です。'),
    _s('debug_attribute', 'Debug Attribute', 'デバッグ属性', 'Attribute name used by heatmap and snapshot tools.', 'ヒートマップとスナップショットツールで使う属性名です。'),
    _s('random_seed', 'Random Seed', 'ランダムシード', 'Deterministic seed used by generated attributes, terrain noise, point placement, details, fragments, growth curves, and proxy instances.', '属性、地形ノイズ、点配置、ディテール、破片、成長カーブ、プロキシインスタンスで使う決定論的シードです。'),
    _s('csv_path', 'CSV Path', 'CSVパス', 'Optional CSV path containing x, y, z columns and optional id, scale, density, or numeric custom columns.', 'x、y、z列と任意のid、scale、density、数値カスタム列を持つCSVファイルのパスです。'),
    _s('precision_preset', 'Precision Preset', '精度プリセット', 'Tuned profile for terrain, distribution, relaxation, diagnostics, and visual workflow buttons.', '地形、分布、緩和、診断、ビジュアルワークフローボタンの調整済みプロファイルです。'),
    _s('ui_density', 'UI Density', 'UI密度', 'Chooses visual, balanced, or technical presentation density for the N-panel.', 'Nパネルの表示密度をビジュアル、バランス、テクニカルから選びます。'),
    _s('ui_use_custom_icons', 'Use Custom Icon Buttons', 'カスタムアイコンボタンを使用', 'Blender 5.1 crash-safe mode keeps live custom preview icon IDs disabled and draws command buttons with Blender standard icons. The bundled PNG assets remain available for validation and export.', 'Blender 5.1のクラッシュ安全モードでは、ライブのカスタムプレビューアイコンIDを無効化し、コマンドボタンはBlender標準アイコンで描画します。同梱PNG資産は検証と書き出し用に保持します。'),
    _s('ui_icon_scale', 'Icon Preview Scale', 'アイコンプレビュー倍率', 'Controls the display size of large icon previews.', '大型アイコンプレビューの表示サイズを調整します。'),
    _s('ui_button_scale', 'Command Button Height', 'コマンドボタン高さ', 'Controls the vertical height of major command buttons.', '主要コマンドボタンの縦方向の高さを調整します。'),
    _s('ui_show_icon_dashboard', 'Show Icon Dashboard', 'アイコンダッシュボード表示', 'Shows the command dashboard with Blender standard icons in Blender 5.1 crash-safe mode.', 'Blender 5.1安全モードではBlender標準アイコンでコマンドダッシュボードを表示します。'),
    _s('ui_show_visual_guides', 'Show Visual Guides', 'ビジュアルガイド表示', 'Shows icon-only reference diagrams for the workflow.', 'ワークフロー用のアイコンのみのリファレンス図を表示します。'),
    _s('ui_borderless_icon_buttons', 'Borderless Icon Buttons', '枠無しアイコンボタン', 'Uses borderless operator buttons where possible while keeping the whole button area clickable.', '可能な範囲で枠無しオペレーターボタンを使い、ボタン領域全体はクリック可能に保ちます。'),
    _s('ui_v8_show_command_ribbon', 'Show Command Ribbon', 'コマンドリボン表示', 'Shows the command ribbon with very large borderless icon previews.', '非常に大きい枠無しアイコンプレビューを使うコマンドリボンを表示します。'),
    _s('ui_v8_max_icon_fill', 'Icon Figure Fill', 'アイコン図形充填率', 'Documents the intended fill ratio of bundled icon artwork.', '同梱アイコン図形の想定充填率を示す設定です。'),
    _s('ui_v8_tile_scale', 'Dashboard Tile Scale', 'ダッシュボードタイル倍率', 'Controls how large dashboard icon preview tiles appear.', 'ダッシュボードのアイコンプレビュータイルの大きさを調整します。'),
    _s('ui_v8_show_reference_strips', 'Show Reference Strips', 'リファレンス帯を表示', 'Shows large icon-only reference diagrams.', '大型のアイコンのみのリファレンス図を表示します。'),
    _s('precision_v7_strength', 'Base Precision Strength', '基礎精度強度', 'Global intensity for the base precision polish.', '基礎精度ポリッシュ全体の強度です。'),
    _s('precision_v7_feature_preservation', 'Feature Preservation', '特徴保持', 'How strongly ridges, cavities, boundaries, and high-curvature details are preserved.', '稜線、窪み、境界、高曲率ディテールを保持する強さです。'),
    _s('precision_v7_material_regions', 'Material Regions', 'マテリアル領域数', 'Number of stable material region IDs generated by the material composer.', 'マテリアルコンポーザーが生成する安定したマテリアル領域ID数です。'),
    _s('precision_v8_strength', 'Precision Strength', '精度強度', 'Global strength for operation-grade confidence, stability, distribution, material, hydrology, and diagnostic scores.', '操作品質レベルの信頼度、安定性、分布、マテリアル、水文、診断スコア全体の強度です。'),
    _s('precision_v8_quality_passes', 'Quality Passes', '品質パス', 'Number of lightweight quality analysis passes.', '軽量な品質解析パス数です。'),
    _s('precision_v8_feature_radius', 'Feature Radius', '特徴半径', 'Neighborhood radius for stability, saliency, and field-coherence approximations.', '安定性、注目度、フィールド整合性近似で使う近傍半径です。'),
    _s('precision_v8_material_contrast', 'Material Contrast', 'マテリアルコントラスト', 'Contrast applied to the material-lane composer.', 'マテリアルレーンコンポーザーへ適用するコントラストです。'),
    _s('precision_v8_risk_suppression', 'Risk Suppression', 'リスク抑制', 'Down-ranks high-risk topology, boundary, overdraw, and low-confidence regions.', '高リスクトポロジー、境界、過描画、低信頼領域を低評価にします。'),
    _s('show_advanced', 'Show Advanced', '詳細を表示', 'Shows advanced controls, metadata, generated IDs, and technical diagnostics.', '詳細コントロール、メタデータ、生成ID、技術診断を表示します。'),
    _s('n_panel_state_save', 'N-panel State Save', 'Nパネル状態保存', 'Controls when Smart Geometry writes all N-panel settings to Smart_Geometry_Suite/Smart_Geometry_Suite.json in Blender config. Enable it to save every change immediately; disable it to defer writes until the current scene is closed or replaced, Blender exits, or Blender Preferences are saved.', 'Smart Geometryの全Nパネル設定をBlender設定フォルダ内のSmart_Geometry_Suite/Smart_Geometry_Suite.jsonへ書き込むタイミングを制御します。有効の場合は各変更を即時保存し、無効の場合は現在のシーンを閉じる・置き換える、Blender終了、またはプリファレンス保存時まで書き込みを保留します。'),
    _s('show_always_on_toggles', 'Always-on Toggles Group Open', '常時機能切り替えグループを開く', 'Opens or closes the clock-marked always-on group at the top of the N-panel.', 'Nパネル最上部の時計アイコン付き常時起動グループを開閉します。'),
]}

_ALWAYS_ON_SETTINGS = tuple(
    SettingHelp(
        item.pref_property,
        item.label_en,
        item.label_ja,
        item.description_en,
        item.description_ja,
    )
    for item in always_on.feature_definitions()
)


def _setting(key: str) -> SettingHelp:
    return _SETTINGS[key]


def _settings_for(keys: list[str]) -> list[SettingHelp]:
    return [_SETTINGS[k] for k in keys if k in _SETTINGS]


def _operator_setting(en: str, ja: str, desc_en: str, desc_ja: str) -> SettingHelp:
    return SettingHelp('operator', en, ja, desc_en, desc_ja)


_HELP_GROUPS: dict[str, dict[str, Any]] = {
    'suite_overview': {
        'label_en': 'Smart Geometry', 'label_ja': 'Smart Geometry', 'icon': 'GEOMETRY_NODES',
        'overview_en': [
            'Central panel for applying feature capsules, workflow packs, and generated Geometry Nodes libraries while keeping the N-panel compact.',
            'The suite is organized around attributes, selection logic, surface distribution, terrain, hydrology, fragments, growth curves, diagnostics, visual operation, and open-data manifests.',
        ],
        'overview_ja': [
            '機能カプセル、ワークフローパック、生成Geometry Nodesライブラリを扱う中心パネルです。Nパネル本体は簡潔に保ち、詳細説明はヘルプへ分離しています。',
            '属性、選択ロジック、表面分布、地形、水文、破片、成長カーブ、診断、ビジュアル操作、外部データマニフェストを軸に構成しています。',
        ],
        'usage_en': [
            'Choose Active Feature and Apply Feature to add one capsule to selected meshes.',
            'Choose Active Pack and Apply Pack to add a prepared workflow stack.',
            'Use Create Library when node groups must be generated before reuse or asset marking.',
        ],
        'usage_ja': [
            'アクティブ機能を選び、機能を適用で選択メッシュへ1つのカプセルを追加します。',
            'アクティブパックを選び、パックを適用で準備済みワークフロースタックを追加します。',
            'ノードグループを先に生成・再利用・アセット化したい場合はライブラリ作成を使います。',
        ],
        'settings': _settings_for(['active_feature', 'active_pack', 'capsule_prefix', 'mark_assets', 'precision_preset', 'show_advanced']),
    },
    'always_on': {
        'label_en': 'Always-on Toggles', 'label_ja': '常時機能切り替え', 'icon': 'TIME',
        'overview_en': [
            'This group contains persisted helper switches, but the former recurring monitors have been converted to on-demand checks.',
            'Enabled helpers run only at safe boundaries such as setting changes, N-panel diagnostics drawing, explicit Smart Geometry commands, save, load, or exit.',
        ],
        'overview_ja': [
            'このグループには維持保存される補助スイッチを集約していますが、従来の繰り返し監視はオンデマンド確認へ変換しています。',
            '有効な補助処理は、設定変更、Nパネル診断描画、Smart Geometry明示コマンド、保存、読み込み、終了など安全な境界でだけ実行されます。',
        ],
        'usage_en': [
            'Enable only the helper needed for the current task. The suite does not start recurring scene-scanning timers for these feature switches.',
            'The right-side Enabled/Disabled checkboxes are saved as settings, so they persist across startup and file loads.',
        ],
        'usage_ja': [
            '現在の作業に必要な補助機能だけ有効にします。これらの機能切り替えでは、シーンを繰り返し走査するタイマーを開始しません。',
            '右側の有効/無効のチェックは設定として保存されるので、次の起動やファイルを開いた後も保たれます。',
        ],
        'settings': list(_ALWAYS_ON_SETTINGS) + _settings_for(['n_panel_state_save','show_always_on_toggles']),
    },
    'visual_dashboard': {
        'label_en': 'Visual Dashboard', 'label_ja': 'ビジュアルダッシュボード', 'icon': 'IMAGE_DATA',
        'overview_en': ['Large-icon command deck for the main one-click workflows. It keeps operation paths visible without exposing every technical option in the N-panel.'],
        'overview_ja': ['主要なワンクリックワークフローを大型アイコンで扱うコマンドデッキです。Nパネルに全技術設定を並べず、操作導線を見やすくします。'],
        'usage_en': ['Select a mesh when the workflow affects existing geometry, then click the tile for polish, environment, surface design, fragments, diagnostics, or full demo generation.'],
        'usage_ja': ['既存メッシュへ作用する処理ではメッシュを選択し、磨き込み、環境、表面設計、破片、診断、完全デモのタイルをクリックします。'],
        'settings': _settings_for(['precision_preset', 'ui_v8_tile_scale', 'ui_v8_show_reference_strips', 'ui_icon_scale', 'ui_button_scale']),
    },
    'workflow_v8_polish': {
        'label_en': 'Polish', 'label_ja': '磨き込み', 'icon': 'SOLO_ON',
        'overview_en': ['Generates operation-grade quality attributes for selected meshes, including saliency, coherence, confidence, material lanes, stability, risk, and LOD scores.'],
        'overview_ja': ['選択メッシュに、注目度、整合性、信頼度、マテリアルレーン、安定性、リスク、LODスコアなどの操作品質属性を生成します。'],
        'usage_en': ['Select one or more mesh objects, adjust the precision controls in Settings, then run Polish before distribution, materials, diagnostics, or export.'],
        'usage_ja': ['1つ以上のメッシュを選択し、設定の精度の項目を調整してから、分布、マテリアル、診断、書き出し前に磨き込みを実行します。'],
        'settings': _settings_for(['precision_v8_strength', 'precision_v8_quality_passes', 'precision_v8_feature_radius', 'precision_v8_material_contrast', 'precision_v8_risk_suppression']),
    },
    'workflow_refine': {
        'label_en': 'Refine', 'label_ja': '再構築', 'icon': 'FILE_REFRESH',
        'overview_en': ['Rebuilds precision attributes on selected meshes after modeling edits or topology changes.'],
        'overview_ja': ['モデリング編集やトポロジー変更後に、選択メッシュの精度属性を再構築します。'],
        'usage_en': ['Select meshes, run Refine, then use selection, scatter, material, or diagnostic tools on the refreshed SGS attributes.'],
        'usage_ja': ['メッシュを選択して再構築を実行し、更新されたSGS属性を選択、散布、マテリアル、診断ツールで利用します。'],
        'settings': _settings_for(['precision_v7_strength', 'precision_v7_feature_preservation', 'terrain_v7_field_fusion', 'random_seed']),
    },
    'workflow_environment': {
        'label_en': 'Environment', 'label_ja': '環境', 'icon': 'MESH_GRID',
        'overview_en': ['Creates terrain, distribution points, and drainage curves for environment blockout and procedural habitat workflows.'],
        'overview_ja': ['環境ブロックアウトとプロシージャルな生息環境ワークフロー向けに、地形、分布ポイント、排水カーブを生成します。'],
        'usage_en': ['Set terrain and scatter controls, then run Environment or use individual terrain, scatter, and flow buttons for more control.'],
        'usage_ja': ['地形と散布設定を調整して環境を実行します。細かく制御したい場合は地形、散布、フローの個別ボタンを使います。'],
        'settings': _settings_for(['terrain_resolution','terrain_size','terrain_height','terrain_erosion_iterations','terrain_hydraulic_droplets','terrain_channel_strength','terrain_v7_channel_count','scatter_count','scatter_radius','scatter_min_spacing','drainage_curve_count','random_seed']),
    },
    'workflow_surface': {
        'label_en': 'Surface Design', 'label_ja': '表面設計', 'icon': 'MESH_CUBE',
        'overview_en': ['Builds surface distribution, detail blocks, and proxy instance previews for design iteration.'],
        'overview_ja': ['デザイン検討用に、表面分布、ディテールブロック、プロキシインスタンスプレビューを生成します。'],
        'usage_en': ['Prepare attributes, set distribution quality and spacing, then run Surface Design or individual detail/proxy buttons.'],
        'usage_ja': ['属性を準備し、分布品質と間隔を設定してから表面設計、または個別のディテール/プロキシボタンを実行します。'],
        'settings': _settings_for(['scatter_count','scatter_radius','scatter_min_spacing','scatter_blue_noise','scatter_quality_passes','scatter_relax_iterations','scatter_adaptive_spacing','scatter_v8_stability_bias','density_threshold']),
    },
    'workflow_fragment': {
        'label_en': 'Fragments', 'label_ja': '破片', 'icon': 'MOD_EXPLODE',
        'overview_en': ['Creates clustered fragments with stable piece IDs, mass, energy, seam, glue, and readability metadata.'],
        'overview_ja': ['安定した破片ID、質量、エネルギー、切れ目、接着、読みやすさメタデータを持つクラスタ破片を生成します。'],
        'usage_en': ['Select a mesh, set target piece count and contiguity/compactness/interlock controls, then create clustered fragments.'],
        'usage_ja': ['メッシュを選択し、破片数、連続性、コンパクト性、連結性を設定してからクラスタ破片を作成します。'],
        'settings': _settings_for(['fragment_piece_count','fragment_v7_contiguity','fragment_v7_compactness','fragment_v8_interlock_bias','scatter_radius','random_seed']),
    },
    'workflow_diagnose': {
        'label_en': 'Diagnose', 'label_ja': '診断', 'icon': 'VIEWZOOM',
        'overview_en': ['Creates heatmaps, snapshots, and JSON diagnostics for generated attributes, geometry complexity, distribution quality, and manifest auditing.'],
        'overview_ja': ['生成属性、ジオメトリ複雑度、分布品質、マニフェスト監査用に、ヒートマップ、スナップショット、診断JSONを作成します。'],
        'usage_en': ['Choose the debug attribute, run heatmap or snapshot for visual checks, then export diagnostics when a report is needed.'],
        'usage_ja': ['デバッグ属性を選び、視覚確認にはヒートマップまたはスナップショットを実行し、レポートが必要な場合は診断JSONを書き出します。'],
        'settings': _settings_for(['debug_attribute','diagnostic_sample_limit','density_threshold','show_advanced']),
    },
    'workflow_full_demo': {
        'label_en': 'Full Demo', 'label_ja': '完全デモ', 'icon': 'SCENE_DATA',
        'overview_en': ['Builds a full verification scene with terrain, distribution, drainage, surface details, growth curves, modular structure, and diagnostics.'],
        'overview_ja': ['地形、分布、排水、表面ディテール、成長カーブ、モジュラー構造、診断を含む検証シーンを一括生成します。'],
        'usage_en': ['Use this in a test file when checking the complete suite pipeline. It creates multiple helper objects.'],
        'usage_ja': ['ツールセット全体のパイプラインを確認するテストファイルで使います。複数の補助オブジェクトを生成します。'],
        'settings': _settings_for(['terrain_resolution','scatter_count','structure_floors','scatter_radius','growth_branches','fragment_piece_count','drainage_curve_count','random_seed']),
    },
    'quick_start': {
        'label_en': 'Quick Start', 'label_ja': 'クイック開始', 'icon': 'PLAY',
        'overview_en': ['Compact entry point for creating the node library, rebuilding it, generating a demo scene, applying the full suite, and running the precision polish.'],
        'overview_ja': ['ノードライブラリ作成、再構築、デモシーン生成、完全ツールセット適用、精度ポリッシュをまとめた入口です。'],
        'usage_en': ['Start with Create Node Group Library. Use Rebuild after updating the addon or changing the prefix. Apply Full Toolset only for coverage tests because it can add many modifiers.'],
        'usage_ja': ['まずノードグループライブラリ作成を実行します。アドオン更新後や接頭辞変更後は再構築を使います。完全ツールセット適用は多数のモディファイアを追加するため、主にカバー確認用です。'],
        'settings': _settings_for(['capsule_prefix','mark_assets','precision_preset','show_advanced']),
    },
    'feature_catalog': {
        'label_en': 'Feature Catalog', 'label_ja': '機能カタログ', 'icon': 'NODETREE',
        'overview_en': ['Searchable list of all feature capsules. The visible N-panel list stays compact, while each row has its own help popup for details.'],
        'overview_ja': ['全機能カプセルを検索できる一覧です。Nパネル本体は簡潔にし、各行のヘルプポップアップで詳細を確認します。'],
        'usage_en': ['Filter by category, design domain, or search text. Press the function icon button to apply a feature, or the Help icon to read feature-specific details.'],
        'usage_ja': ['カテゴリ、設計ドメイン、検索語で絞り込みます。機能別アイコンボタンで機能を適用し、ヘルプアイコンで機能別詳細を確認します。'],
        'settings': _settings_for(['feature_category','source_filter','search_filter','active_feature','show_advanced']),
    },
    'procedural_builders': {
        'label_en': 'Procedural Builders', 'label_ja': 'プロシージャル生成', 'icon': 'TOOL_SETTINGS',
        'overview_en': [
            'Technical builder panel for attributes, terrain, distribution, flow, details, structures, growth curves, fragments, heatmaps, and snapshots.',
            'Terrain Mesh: creates a terrain mesh from the settings shown in that section.',
            'Drainage Flow Curves: creates downhill guide curves from the active mesh terrain attributes.',
            'Surface Distribution Points: creates a point-cloud mesh from the active surface or a fallback grid.',
            'Relax and Preview Instances: relaxes generated points or creates lightweight visible proxy instances for checking the distribution.',
            'CSV Point Cloud: imports x, y, z CSV columns as a generated point-cloud mesh.',
            'Surface Detail Blocks: creates density-ranked helper blocks on the active surface or fallback grid.',
            'Modular Structure: generates a tiered modular structure mesh with Smart Geometry attributes. Floors sets the height; Radius / Size sets the overall size.',
            'Organic Growth Curves: creates procedural curves for ivy, roots, cables, veins, or trail guides.',
            'Grease Pencil Mesh Generators: create mesh or Geometry Nodes results from Grease Pencil strokes. They use the selected stroke and object, and need no numeric settings.',
            'Debris Module Generator: choose one module; only that module\'s settings are shown. Modules: brick rubble, corrugated metal, crystals, gemstones, grass, gravel, leaves, logs, meteor fragments, obsidian, pigeons, planks, riverstones, sandstone, shrapnel, slate, snowflakes, splinters, and twigs.',
            'Mesh Fragment Generator: creates clustered fragment helper objects from the active mesh faces.',
            'Max Primitive Generators: creates primitive and AEC-style generator objects. Edit the values of a created primitive in the Max Primitives Parameters panel on the Modifiers tab of the Properties editor. After changing a value, press Refresh Max Primitive to apply it to the shape, or turn on the Parametric Primitive Auto Update always-on feature to apply it without pressing. The values stay editable after the file is saved and reopened. After the modifier is applied or removed the object is an ordinary mesh, and its hand edits are kept.',
            'Attribute sections: build attribute layers on the active or generated mesh, write a selection attribute from the selection string and density threshold, and generate heatmap materials and snapshot meshes from the selected debug attribute.',
            'Outside Object Mode, commands that need Object Mode are disabled until you return to it.',
        ],
        'overview_ja': [
            '属性、地形、分布、フロー、ディテール、構造、成長カーブ、破片、ヒートマップ、スナップショットを扱う技術生成パネルです。',
            '地形メッシュ：その欄の設定で地形メッシュを作成します。',
            '排水フローカーブ：アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
            '表面分布ポイント：アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
            '緩和とプレビューインスタンス：生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
            'CSVポイントクラウド：CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
            '表面ディテールブロック：アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
            'モジュラー構造：Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。「階数」で高さ、「半径 / サイズ」で全体の大きさを決めます。',
            '有機成長カーブ：蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
            'Grease Pencilメッシュ生成：Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。選択中のストロークとオブジェクトを使うので、数値の設定は要りません。',
            'デブリモジュール生成：モジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。モジュールは、レンガ片、波板金属、結晶、宝石、草、砂利、落ち葉、丸太、隕石片、黒曜石、ハト、板材、川石、砂岩、榴散片、スレート、雪結晶、木片、小枝です。',
            'メッシュ破砕生成：アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
            'Maxプリミティブ生成：プリミティブやAEC系生成オブジェクトを作成します。作成後の数値は、プロパティエディターのモディファイアータブの「Max Primitivesパラメーター」で直します。数値を変えたら「Maxプリミティブを更新」を押すと形に反映されます。常時機能の「パラメトリックプリミティブ自動更新」を入れると、押さなくても反映されます。保存して開き直した後も同じように直せます。モディファイアーを適用または削除した後は普通のメッシュになり、手で編集した形はそのまま残ります。',
            '属性の各欄：アクティブまたは生成済みメッシュへ属性レイヤーを作成・再構築し、選択文字列と密度しきい値から選択属性を書き込み、選択したデバッグ属性からヒートマップマテリアルとスナップショットメッシュを生成します。',
            'オブジェクトモード以外では、オブジェクトモード用のボタンは戻るまで無効です。',
        ],
        'usage_en': ['Build precision attributes first when operating on an existing mesh. Then run the specific generator needed for terrain, scatter, flow, details, growth, fragments, or diagnostics.'],
        'usage_ja': ['既存メッシュを対象にする場合は、先に高精度属性を構築します。その後、地形、散布、フロー、ディテール、成長、破片、診断の必要な生成器を実行します。'],
        'settings': _settings_for(['selection_string','terrain_resolution','terrain_size','terrain_height','terrain_erosion_iterations','terrain_hydraulic_droplets','terrain_hydraulic_iterations','terrain_channel_strength','terrain_v7_ridge_preservation','terrain_v7_channel_count','terrain_v7_field_fusion','scatter_count','structure_floors','scatter_radius','scatter_min_spacing','scatter_blue_noise','scatter_quality_passes','scatter_relax_iterations','scatter_adaptive_spacing','scatter_visibility_culling','scatter_normal_offset','scatter_biome_bias','scatter_candidate_multiplier','scatter_v7_lloyd_iterations','scatter_v7_fairness_strength','scatter_v7_anisotropy_strength','scatter_v7_priority_bias','scatter_v8_stability_bias','density_threshold','growth_branches','drainage_curve_count','fragment_piece_count','fragment_v7_contiguity','fragment_v7_compactness','fragment_v8_interlock_bias','precision_v8_strength','precision_v8_quality_passes','precision_v8_feature_radius','precision_v8_material_contrast','precision_v8_risk_suppression','debug_attribute','random_seed']),
    },
    'interop': {
        'label_en': 'Interop / Manifests', 'label_ja': '外部連携 / マニフェスト', 'icon': 'EXPORT',
        'overview_en': ['Imports CSV point data and exports neutral JSON sidecar manifests for feature inventory, design coverage, USD-oriented primvars, bundle metadata, and diagnostics.'],
        'overview_ja': ['CSVポイントデータを読み込み、機能インベントリ、設計カバー、USD向けprimvar、バンドルメタデータ、診断用の中立JSONサイドカーマニフェストを書き出します。'],
        'usage_en': ['Set CSV Path or use the file picker on Import CSV Points. Use manifest exports when handing generated attributes and node-group metadata to another tool or pipeline step.'],
        'usage_ja': ['CSVパスを指定するか、CSVポイント読み込みのファイル選択を使います。他ツールやパイプラインへ生成属性とノードグループメタデータを渡す場合はマニフェスト書き出しを使います。'],
        'settings': _settings_for(['csv_path','capsule_prefix','debug_attribute','diagnostic_sample_limit']),
    },
    'diagnostics': {
        'label_en': 'Diagnostics', 'label_ja': '診断', 'icon': 'HELP',
        'overview_en': ['Shows compact active-mesh and generated-node counts, then provides report export and cleanup actions. Detailed explanation stays in this popup.'],
        'overview_ja': ['アクティブメッシュと生成ノード数を簡潔に表示し、レポート書き出しと整理操作を提供します。詳細説明はこのポップアップへ分離しています。'],
        'usage_en': ['Select a mesh to inspect, then export diagnostics or inventory. Enable advanced display only when generated-node cleanup is needed.'],
        'usage_ja': ['検査するメッシュを選択し、診断またはインベントリを書き出します。生成ノード整理が必要な場合だけ詳細表示を有効にします。'],
        'settings': _settings_for(['diagnostic_sample_limit','debug_attribute','show_advanced']),
    },
    'visual_ui': {
        'label_en': 'Visual UI', 'label_ja': 'ビジュアルUI', 'icon': 'IMAGE_DATA',
        'overview_en': ['Controls the icon-first interface, maximum-fill icon display, visual reference strips, and quality controls.'],
        'overview_ja': ['アイコン優先UI、最大充填アイコン表示、ビジュアルリファレンス帯、品質設定を調整します。'],
        'usage_en': ['Use Visual or Balanced density for normal work. Increase icon and tile scale for high-DPI displays. Live custom preview icon IDs remain disabled in Blender 5.1 crash-safe mode.'],
        'usage_ja': ['通常作業ではビジュアルまたはバランス密度を使います。高DPI環境ではアイコン倍率とタイル倍率を上げます。Blender 5.1安全モードではライブのカスタムプレビューアイコンIDを無効のままにします。'],
        'settings': _settings_for(['ui_density','ui_use_custom_icons','ui_icon_scale','ui_button_scale','ui_show_icon_dashboard','ui_show_visual_guides','ui_borderless_icon_buttons','ui_v8_show_command_ribbon','ui_v8_max_icon_fill','ui_v8_tile_scale','ui_v8_show_reference_strips','precision_v7_strength','precision_v7_feature_preservation','precision_v7_material_regions','precision_v8_strength','precision_v8_quality_passes','precision_v8_material_contrast']),
    },
    'design_coverage': {
        'label_en': 'Design Coverage', 'label_ja': '設計カバー範囲', 'icon': 'CHECKMARK',
        'overview_en': ['Compact audit view for feature categories and independent design domains represented in the suite catalog.'],
        'overview_ja': ['ツールセットカタログ内の機能カテゴリと独自設計ドメインを確認する簡易監査ビューです。'],
        'usage_en': ['Use this panel to confirm the catalog coverage, then export Design Coverage JSON from Interop when a portable audit file is needed.'],
        'usage_ja': ['このパネルでカタログカバーを確認し、持ち運べる監査ファイルが必要な場合は外部連携から設計カバーJSONを書き出します。'],
        'settings': _settings_for(['feature_category','source_filter','search_filter','show_advanced']),
    },
}


# Backward-compatible UI topic aliases.  The N-panel uses concise topic keys;
# the lazy help body keeps the richer internal group names.
_HELP_GROUPS['root'] = _HELP_GROUPS['suite_overview']
_HELP_GROUPS['dashboard'] = _HELP_GROUPS['visual_dashboard']
_HELP_GROUPS['catalog'] = _HELP_GROUPS['feature_catalog']
_HELP_GROUPS['builders'] = _HELP_GROUPS['procedural_builders']
_HELP_GROUPS['builder_controls'] = _HELP_GROUPS['procedural_builders']
_HELP_GROUPS['coverage'] = _HELP_GROUPS['design_coverage']
_HELP_GROUPS['help_index'] = {
    'label_en': 'Help Index', 'label_ja': 'ヘルプ一覧', 'icon': 'HELP',
    'overview_en': ['Compact index of the same lazy help popups available from each tool group header. It contains navigation buttons only and no long manual text in the N-panel itself.'],
    'overview_ja': ['各ツールグループ見出しから開ける遅延ヘルプポップアップをまとめた簡易一覧です。Nパネル本体には長い説明文を置かず、移動用ボタンだけを表示します。'],
    'usage_en': ['Click a Help icon beside the tool group you want to inspect. The detailed manual module is imported at that moment only.'],
    'usage_ja': ['確認したいツールグループ横のヘルプアイコンをクリックします。詳細マニュアルモジュールはその時だけ読み込まれます。'],
    'settings': _settings_for(['active_feature','active_pack','show_advanced']),
}


# Backward-compatible and nested-group aliases used by compact N-panel help buttons.
_HELP_GROUPS['root'] = _HELP_GROUPS['suite_overview']
_HELP_GROUPS['dashboard'] = _HELP_GROUPS['visual_dashboard']
_HELP_GROUPS['catalog'] = _HELP_GROUPS['feature_catalog']
_HELP_GROUPS['builders'] = _HELP_GROUPS['procedural_builders']
_HELP_GROUPS['coverage'] = _HELP_GROUPS['design_coverage']
_HELP_GROUPS['builder_controls'] = {
    'label_en': 'Builder Controls', 'label_ja': '生成コントロール', 'icon': 'TOOL_SETTINGS',
    'overview_en': ['Unified setting block shared by the procedural builders. It controls terrain precision, hydraulic shaping, surface distribution, growth, fragmentation, quality, diagnostics, and deterministic randomization.'],
    'overview_ja': ['プロシージャル生成で共有する統一設定ブロックです。地形精度、水理形成、表面分布、成長、破片化、品質、診断、決定論的ランダム化を制御します。'],
    'usage_en': ['Adjust only the controls related to the builder you are about to run. Use Precision Preset first when you need safe baseline values.'],
    'usage_ja': ['これから実行する生成器に関係する項目だけを調整します。安全な基準値が必要な場合は先に精度プリセットを適用します。'],
    'settings': _HELP_GROUPS['procedural_builders']['settings'],
}

_SECTION_TITLES = {
    'overview': ('1. Feature Overview', '1. 機能概要'),
    'usage': ('2. Usage', '2. 使用方法'),
    'settings': ('3. Settings', '3. 設定項目'),
}

_TRANSLATIONS = {
    'ja_JP': {
        ('*', 'Smart Geometry Help'): 'Smart Geometry ヘルプ',
        ('*', 'Display detailed Smart Geometry tool help.'): 'Smart Geometryツールの詳細ヘルプを表示します。',
        ('*', 'Help'): 'ヘルプ',
        ('*', 'Help Topic Key'): 'ヘルプトピックキー',
        ('*', 'Internal key that selects the detailed Smart Geometry help topic opened by this popup.'):
            'このポップアップで開くSmart Geometry詳細ヘルプのトピックを選択する内部キーです。',
        ('*', 'Optional Smart Geometry feature identifier used to show feature-specific instructions in the help popup.'):
            'ヘルプポップアップで機能別の説明を表示するための任意のSmart Geometry機能識別子です。',
        ('Operator', 'Smart Geometry Help'):
            'Smart Geometry ヘルプ',
        ('*', 'Page of this help shown in the popup.'):
            'ポップアップに表示するこのヘルプのページです。',
    }
}


def _display_units(text: str) -> int:
    total = 0
    for ch in str(text or ''):
        total += 4 if ch == '\t' else (2 if unicodedata.east_asian_width(ch) in {'F', 'W'} else 1)
    return total


_NO_LINE_START = frozenset('。、，．・：；！？）」』】〕,.:;!?)]')


def _wrap_display_line(text: str, limit: int) -> list[str]:
    raw = str(text or '')
    if not raw:
        return ['']
    limit = max(12, int(limit or 48))
    if _display_units(raw) <= limit:
        return [raw]
    lines: list[str] = []
    current: list[str] = []
    units = 0
    last_space = -1

    def flush() -> None:
        nonlocal current, units, last_space
        line = ''.join(current).strip()
        if line:
            lines.append(line)
        current = []
        units = 0
        last_space = -1

    for ch in raw:
        u = 4 if ch == '\t' else (2 if unicodedata.east_asian_width(ch) in {'F', 'W'} else 1)
        if current and units + u > limit and ch not in _NO_LINE_START:
            # A break right after a leading bullet would leave the bullet alone.
            # A space early in the line would leave a short line in Japanese text.
            if last_space > 1 and _display_units(''.join(current[:last_space])) * 2 >= limit:
                line = ''.join(current[:last_space]).strip()
                if line:
                    lines.append(line)
                remainder = ''.join(current[last_space + 1:]).lstrip()
                current = list(remainder)
                units = _display_units(remainder)
                last_space = -1
                for idx, old in enumerate(current):
                    if old.isspace():
                        last_space = idx
            else:
                flush()
        current.append(ch)
        units += u
        if ch.isspace():
            last_space = len(current) - 1
    flush()
    # A few Japanese characters alone on the last line read badly; move some down.
    if len(lines) >= 2:
        head, tail = lines[-2], lines[-1]
        while head and (_display_units(tail) < limit // 6 or tail[0] in _NO_LINE_START):
            take = 1
            if unicodedata.east_asian_width(head[-1]) not in {'F', 'W'}:
                # A word in Japanese text (JSON, ID) moves down as a whole.
                if not head[-1].isascii() or not head[-1].isalnum() or not any(
                    unicodedata.east_asian_width(c) in {'F', 'W'} for c in tail
                ):
                    break
                while take < len(head) and head[-take - 1].isascii() and head[-take - 1].isalnum():
                    take += 1
            head, tail = head[:-take], head[-take:] + tail
        if head and tail[0] not in _NO_LINE_START:
            lines[-2:] = [head, tail]
    return lines or ['']


def _ui_scale(context=None) -> float:
    try:
        return max(0.75, float(getattr(getattr((context or bpy.context).preferences, 'system', None), 'ui_scale', 1.0) or 1.0))
    except Exception:
        return 1.0


def _wrap_width(context=None) -> int:
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
        if width > 300:
            return max(30, min(110, int((width - 120) / (7.2 * _ui_scale(context)))))
    except Exception:
        pass
    return 96


def _wrap_label(layout, text: str, *, icon: str = 'NONE', context=None) -> None:
    for idx, line in enumerate(_wrap_display_line(text, _wrap_width(context))):
        try:
            layout.label(text=line, icon=icon if idx == 0 else 'BLANK1')
        except Exception:
            layout.label(text=line)


def _section_header(layout, key: str, context=None) -> None:
    en, ja = _SECTION_TITLES[key]
    row = layout.row(align=True)
    _wrap_label(row, _pair(en, ja, context), icon='TRIA_DOWN', context=context)


def _draw_bullets(layout, lines: list[str], context=None) -> None:
    col = layout.column(align=True)
    for line in lines:
        _wrap_label(col, f'• {line}', context=context)


def _setting_name(item: SettingHelp, context=None) -> str:
    return _pair(item.name_en, item.name_ja, context)


def _setting_desc(item: SettingHelp, context=None) -> str:
    return _pair(item.desc_en, item.desc_ja, context)


def _draw_settings(layout, settings: list[SettingHelp], context=None) -> None:
    if not settings:
        _wrap_label(layout, _pair('This tool has no editable settings.', 'このツールに編集可能な設定項目はありません。', context), context=context)
        return
    seen: set[str] = set()
    for item in settings:
        unique_key = f'{item.key}:{item.name_en}'
        if unique_key in seen:
            continue
        seen.add(unique_key)
        box = layout.box()
        _wrap_label(box, _setting_name(item, context), icon='DOT', context=context)
        _wrap_label(box, _setting_desc(item, context), context=context)


def _group_data(help_key: str, feature_id: str, context=None) -> dict[str, Any]:
    key = str(help_key or '').strip()
    if key == 'feature' or (feature_id and feature_id in catalog.FEATURE_BY_ID):
        return _feature_data(feature_id, context)
    data = _HELP_GROUPS.get(key)
    if data:
        return data
    return _HELP_GROUPS['suite_overview']


def _feature_data(feature_id: str, context=None) -> dict[str, Any]:
    feature = catalog.FEATURE_BY_ID.get(str(feature_id or '')) or {}
    label_en = str(feature.get('label_en') or feature.get('id') or 'Feature')
    label_ja = str(feature.get('label_ja') or label_en)
    summary_en = str(feature.get('summary_en') or feature.get('tooltip_en') or '')
    summary_ja = str(feature.get('summary_ja') or feature.get('tooltip_ja') or summary_en)
    tooltip_en = str(feature.get('tooltip_en') or summary_en)
    tooltip_ja = str(feature.get('tooltip_ja') or summary_ja)
    domain_en = str(feature.get('design_domain_en') or feature.get('design_domain') or '')
    domain_ja = str(feature.get('design_domain_ja') or domain_en)
    usage_en = [
        'Select one or more mesh objects when the feature is geometry-facing.',
        'Choose this feature in Active Feature or click its function icon button in Feature Catalog, then run Apply Feature.',
        'Use generated SGS attributes as masks, density fields, material signals, debug layers, or handoff metadata depending on the feature domain.',
    ]
    usage_ja = [
        'ジオメトリへ作用する機能では、先に1つ以上のメッシュオブジェクトを選択します。',
        'アクティブ機能でこの機能を選ぶか、機能カタログの機能別アイコンボタンを押してから機能を適用します。',
        '生成されるSGS属性は、機能ドメインに応じてマスク、密度フィールド、マテリアル信号、デバッグレイヤー、受け渡しメタデータとして使います。',
    ]
    settings = [
        SettingHelp('domain', 'Design Domain', '設計ドメイン', domain_en, domain_ja),
    ] + _settings_for(['active_feature','capsule_prefix','mark_assets','show_advanced'])
    return {
        'label_en': label_en,
        'label_ja': label_ja,
        'icon': 'NODE',
        'overview_en': list(dict.fromkeys(line for line in (summary_en, tooltip_en) if line)),
        'overview_ja': list(dict.fromkeys(line for line in (summary_ja, tooltip_ja) if line)),
        'usage_en': usage_en,
        'usage_ja': usage_ja,
        'settings': settings,
    }


def _help_blocks(data: dict[str, Any], lang: str, context=None) -> list[dict[str, Any]]:
    limit = _wrap_width(context)
    blocks: list[dict[str, Any]] = []
    for section in ('overview', 'usage'):
        for line in list(data.get(f'{section}_{lang}') or data.get(f'{section}_en') or []):
            blocks.append({'section': section, 'lines': _wrap_display_line(f'• {line}', limit), 'boxed': False})
    seen: set[str] = set()
    for item in list(data.get('settings') or []):
        unique_key = f'{item.key}:{item.name_en}'
        if unique_key in seen:
            continue
        seen.add(unique_key)
        blocks.append({
            'section': 'settings',
            'name': _wrap_display_line(_setting_name(item, context), limit),
            'lines': _wrap_display_line(_setting_desc(item, context), limit),
            'boxed': True,
        })
    if not seen:
        text = _pair('This tool has no editable settings.', 'このツールに編集可能な設定項目はありません。', context)
        blocks.append({'section': 'settings', 'lines': _wrap_display_line(text, limit), 'boxed': False})
    return blocks


def _help_pages(blocks: list[dict[str, Any]], max_rows: int) -> list[list[dict[str, Any]]]:
    pages: list[list[dict[str, Any]]] = []
    page: list[dict[str, Any]] = []
    rows = 0
    section = None
    for block in blocks:
        cost = len(block['lines']) + len(block.get('name') or ()) + (1 if block['boxed'] else 0)
        if page and rows + cost + (2 if block['section'] != section else 0) > max_rows:
            pages.append(page)
            page = []
            rows = 0
        if not page or block['section'] != section:
            rows += 2
        page.append(block)
        rows += cost
        section = block['section']
    if page:
        pages.append(page)
    return pages or [[]]


def _help_max_rows(context) -> int:
    # A dialog taller than the window is clipped and cannot be scrolled.
    try:
        height = int(getattr(getattr(context, 'window', None), 'height', 0) or 0)
    except Exception:
        height = 0
    if height <= 0:
        return 30
    return max(10, int(height * 0.85 / (22 * _ui_scale(context))) - 6)


class SGS_OT_help_popup(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.help_popup'
    bl_label = 'Smart Geometry Help'
    bl_description = 'Display detailed Smart Geometry tool help.'
    bl_options = set()

    help_key: StringProperty(
        name='Help Topic Key',
        description='Internal key that selects the detailed Smart Geometry help topic opened by this popup.',
        options={'SKIP_SAVE'},
        default='suite_overview',
    )
    feature_id: StringProperty(
        name='Feature ID',
        description='Optional Smart Geometry feature identifier used to show feature-specific instructions in the help popup.',
        options={'SKIP_SAVE'},
        default='',
    )
    page: IntProperty(
        name='Page',
        description='Page of this help shown in the popup.',
        options={'SKIP_SAVE'},
        default=1,
        min=1,
    )

    @classmethod
    def description(cls, context, properties):
        return _pair('Display detailed help for this Smart Geometry tool.', 'このSmart Geometryツールの詳細ヘルプを表示します。', context)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=840)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        data = _group_data(str(self.help_key or ''), str(self.feature_id or ''), context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        icon = str(data.get('icon') or 'HELP')
        title = _pair(str(data.get('label_en') or 'Help'), str(data.get('label_ja') or data.get('label_en') or 'ヘルプ'), context)
        header = layout.box()
        _wrap_label(header, title, icon=icon, context=context)

        lang = 'ja' if _is_ja(context) else 'en'
        pages = _help_pages(_help_blocks(data, lang, context), _help_max_rows(context))
        index = min(int(self.page), len(pages)) - 1
        if len(pages) > 1:
            row = header.row(align=True)
            row.prop(self, 'page', text=_pair('Page', 'ページ', context))
            row.label(text=f'/ {len(pages)}')
        box = None
        column = None
        section = None
        for block in pages[index]:
            if box is None or block['section'] != section:
                section = block['section']
                box = layout.box()
                _section_header(box, section, context)
                column = box.column(align=True)
            parent = box.box() if block['boxed'] else column
            for idx, line in enumerate(block.get('name') or ()):
                parent.label(text=line, icon='DOT' if idx == 0 else 'BLANK1')
            for idx, line in enumerate(block['lines']):
                parent.label(text=line, icon='NONE' if idx == 0 else 'BLANK1')


def _register_translations() -> bool:
    """Register the lazy help translation through the exact Suite ledger."""
    global _TRANSLATIONS_REGISTERED
    if _TRANSLATIONS_REGISTERED:
        return True
    from . import ownership
    ledger = ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger) or not ownership.runtime_active_for_generation():
        return False
    if not any(record.get('key') == _TRANSLATION_DOMAIN for record in ledger.get('translations', ())):
        ownership.register_translation(ledger, _TRANSLATION_DOMAIN, _TRANSLATIONS)
    _TRANSLATIONS_REGISTERED = True
    return True


def _unregister_translations() -> bool:
    """Compatibility no-op; the generation transaction owns translation teardown."""
    return True


_REGISTERED = False


def register() -> bool:
    """Acquire the lazy popup RNA through exact generation ownership once."""
    global _REGISTERED
    from . import ownership
    ledger = ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger) or not ownership.runtime_active_for_generation():
        return False
    if any(record.get('class') is SGS_OT_help_popup for record in ledger.get('classes', ())):
        _REGISTERED = True
        _register_translations()
        return True
    before_classes = len(ledger.get('classes', ()))
    before_translations = len(ledger.get('translations', ()))
    try:
        if not _register_translations():
            return False
        ownership.register_class(ledger, SGS_OT_help_popup)
    except Exception:
        # Roll back only resources acquired by this explicit lazy registration.
        for record in reversed(tuple(ledger.get('classes', ())[before_classes:])):
            if ownership.unregister_class_record(ledger, record) and record in ledger.get('classes', []):
                ledger['classes'].remove(record)
        for record in reversed(tuple(ledger.get('translations', ())[before_translations:])):
            if ownership.remove_translation_record(ledger, record) and record in ledger.get('translations', []):
                ledger['translations'].remove(record)
        _REGISTERED = False
        raise
    _REGISTERED = True
    return True


def unregister() -> bool:
    """Compatibility no-op; full RNA teardown belongs to the owner transaction."""
    return True


def show_help(context, help_key: str = 'suite_overview', feature_id: str = '') -> bool:
    if not register():
        return False
    key = str(help_key or '').strip() or ('feature' if feature_id else 'suite_overview')
    fid = str(feature_id or '').strip()
    try:
        bpy.ops.smart_geometry_suite.help_popup('INVOKE_DEFAULT', help_key=key, feature_id=fid)
        return True
    except Exception:
        def _draw(menu, popup_context):
            data = _group_data(key, fid, popup_context)
            layout = menu.layout
            title = _pair(str(data.get('label_en') or 'Help'), str(data.get('label_ja') or 'ヘルプ'), popup_context)
            _wrap_label(layout, title, icon=str(data.get('icon') or 'HELP'), context=popup_context)
            lang = 'ja' if _is_ja(popup_context) else 'en'
            for section in ('overview', 'usage', 'settings'):
                box = layout.box()
                _section_header(box, section, popup_context)
                if section == 'settings':
                    _draw_settings(box, list(data.get('settings') or []), popup_context)
                else:
                    _draw_bullets(box, list(data.get(f'{section}_{lang}') or data.get(f'{section}_en') or []), popup_context)
        try:
            context.window_manager.popup_menu(_draw, title=_pair('Smart Geometry Help', 'Smart Geometry ヘルプ', context), icon='HELP')
            return True
        except Exception:
            return False
