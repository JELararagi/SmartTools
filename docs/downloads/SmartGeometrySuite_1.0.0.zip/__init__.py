# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from . import runtime

__version__ = "8.2.52"

bl_info = {
    'name': 'Smart Geometry',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'Supported Editors > Sidebar > Smart Geometry',
    'description': 'Smart Geometry Suite with exact generation ownership, transactional registration, eleven native physical-space roots with seventeen logical-editor decisions, event-driven JSON persistence, bounded caches, lazy implementation loading, and zero idle runtime while disabled.',
    'category': 'Smart Geometry',
}


def register() -> None:
    """Register the Extension using one exact generation transaction."""
    runtime.register()


def unregister() -> None:
    """Fully stop the exact published generation after a successful settings flush."""
    runtime.unregister()


def smart_tools_manager_suspend(context=None) -> bool:
    """Public Manager soft-OFF notification; never disables or reloads add-ons."""
    del context
    return bool(runtime.suspend())


def smart_tools_manager_resume(context=None) -> bool:
    """Public Manager soft-ON notification; resumes current RNA without JSON reload."""
    del context
    return bool(runtime.resume())


def smart_tools_manager_safe_reload(context=None):
    """Public mutation-free cached health query for Manager repair boundaries."""
    del context
    return runtime.safe_reload()


if __name__ == '__main__':
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
