# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

import importlib
import sys
import time

import bpy
from bpy.props import StringProperty

from . import catalog, manager_compat, ownership
from .properties import get_settings


class _LazyModuleProxy:
    __slots__ = ('_leaf', '_module')

    def __init__(self, leaf: str):
        self._leaf = str(leaf)
        self._module = None

    @property
    def full_name(self) -> str:
        return f'{__package__}.{self._leaf}'

    def load(self):
        module = self._module
        if module is None or sys.modules.get(self.full_name) is not module:
            module = importlib.import_module(self.full_name)
            self._module = module
            ledger = ownership.shared_ledger()
            if ledger is not None:
                ownership.record_lazy_module(ledger, module)
        return module

    def release(self) -> None:
        self._module = None

    def __getattr__(self, name):
        return getattr(self.load(), name)


always_on = _LazyModuleProxy('always_on')
debris_generators = _LazyModuleProxy('debris_generators')
node_factory = _LazyModuleProxy('node_factory')
storage = _LazyModuleProxy('storage')

_PANEL_CATEGORY = 'Smart Geometry'

_ICON_ALIAS = {
    'MOD_NODES': 'GEOMETRY_NODES',
    'OUTLINER_DATA_GEOMETRYSET': 'GEOMETRY_SET',
}

_CUSTOM_ICON_FALLBACK = {
    'logo': 'GEOMETRY_NODES',
    'dashboard': 'WINDOW',
    'precision': 'VIEWZOOM',
    'overdrive': 'SOLO_ON',
    'terrain': 'MESH_GRID',
    'scatter': 'PARTICLES',
    'relax': 'MOD_PARTICLE_INSTANCE',
    'flow': 'CURVE_PATH',
    'greeble': 'MESH_CUBE',
    'fragment': 'MOD_EXPLODE',
    'heatmap': 'COLOR',
    'attribute': 'RNA',
    'selection': 'RESTRICT_SELECT_OFF',
    'material': 'MATERIAL',
    'manifest': 'EXPORT',
    'quality': 'CHECKMARK',
    'diagnostics': 'VIEWZOOM',
    'snapshot': 'DUPLICATE',
    'csv': 'FILE',
    'structure': 'HOME',
    'growth': 'CURVE_DATA',
    'volume': 'OUTLINER_OB_MESH',
    'motion': 'CURVE_DATA',
    'automation': 'TOOL_SETTINGS',
    'capsule': 'GEOMETRY_NODES',
    'utility': 'TOOL_SETTINGS',
}

_SECTION_DEFS = (
    ('ui_section_always_on', 'Always-on Toggles', '常時起動切り替え', 'TIME', 'always_on'),
    ('ui_section_terrain_generators', 'Terrain / Environment', '地形 / 環境生成', 'MESH_GRID', 'procedural_builders'),
    ('ui_section_distribution_generators', 'Distribution / Scatter', '分布 / 散布生成', 'PARTICLES', 'procedural_builders'),
    ('ui_section_structure_surface_generators', 'Structure / Surface', '構造 / 表面生成', 'MESH_CUBE', 'procedural_builders'),
    ('ui_section_organic_stroke_generators', 'Organic / Stroke', '有機 / ストローク生成', 'CURVE_DATA', 'procedural_builders'),
    ('ui_section_debris_fragment_generators', 'Debris / Fragment', 'デブリ / 破砕生成', 'MOD_EXPLODE', 'procedural_builders'),
    ('ui_section_primitive_generators', 'Primitive Generators', 'プリミティブ生成', 'MESH_CUBE', 'procedural_builders'),
    ('ui_section_attribute_visual_generators', 'Attribute / Visualization', '属性 / 可視化生成', 'COLOR', 'procedural_builders'),
    ('ui_section_settings', 'Settings', '設定', 'PREFERENCES', 'suite_overview'),
)

_BUILDER_CONTROL_PROPS = (
    ('terrain_resolution', 'Terrain Resolution', '地形解像度'),
    ('terrain_size', 'Terrain Size', '地形サイズ'),
    ('terrain_height', 'Terrain Height', '地形高さ'),
    ('terrain_erosion_iterations', 'Erosion Iterations', '侵食反復'),
    ('terrain_hydraulic_droplets', 'Hydraulic Droplets', '水理ドロップ数'),
    ('terrain_hydraulic_iterations', 'Hydraulic Iterations', '水理反復'),
    ('terrain_channel_strength', 'Channel Strength', '水路強度'),
    ('terrain_v7_ridge_preservation', 'Ridge Preservation', '稜線保持'),
    ('terrain_v7_channel_count', 'Channel Count', '水路数'),
    ('terrain_v7_field_fusion', 'Field Fusion', 'フィールド融合'),
    ('scatter_count', 'Amount', '数量'),
    ('structure_floors', 'Floors', '階数'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
    ('scatter_min_spacing', 'Minimum Spacing', '最小間隔'),
    ('scatter_blue_noise', 'Blue-Noise Rejection', 'ブルーノイズ除外'),
    ('scatter_quality_passes', 'Quality Passes', '品質パス'),
    ('scatter_relax_iterations', 'Relax Iterations', '緩和反復'),
    ('scatter_adaptive_spacing', 'Adaptive Spacing', '適応間隔'),
    ('scatter_visibility_culling', 'Camera Visibility Gate', 'カメラ可視性ゲート'),
    ('scatter_normal_offset', 'Normal Offset', '法線オフセット'),
    ('scatter_biome_bias', 'Habitat Bias', '生息環境バイアス'),
    ('scatter_candidate_multiplier', 'Candidate Multiplier', '候補倍率'),
    ('scatter_v7_lloyd_iterations', 'Tangent Relax Iterations', '接平面緩和反復'),
    ('scatter_v7_fairness_strength', 'Fairness Strength', '均等性強度'),
    ('scatter_v7_anisotropy_strength', 'Anisotropy Strength', '異方性強度'),
    ('scatter_v7_priority_bias', 'Priority Bias', '優先度バイアス'),
    ('drainage_curve_count', 'Drainage Curves', '排水カーブ数'),
    ('density_threshold', 'Density Threshold', '密度しきい値'),
    ('growth_branches', 'Growth Branches', '成長枝数'),
    ('fragment_piece_count', 'Fragment Pieces', '破片数'),
    ('fragment_v7_contiguity', 'Fragment Contiguity', '破片連続性'),
    ('fragment_v7_compactness', 'Fragment Compactness', '破片コンパクト性'),
    ('precision_v8_strength', 'Precision Strength', '精度強度'),
    ('precision_v8_quality_passes', 'Quality Passes', '品質パス'),
    ('precision_v8_feature_radius', 'Feature Radius', '特徴半径'),
    ('precision_v8_material_contrast', 'Material Contrast', 'マテリアルコントラスト'),
    ('precision_v8_risk_suppression', 'Risk Suppression', 'リスク抑制'),
    ('scatter_v8_stability_bias', 'Scatter Stability', '分布安定性'),
    ('fragment_v8_interlock_bias', 'Fragment Interlock', '破片連結性'),
    ('debug_attribute', 'Debug Attribute', 'デバッグ属性'),
    ('random_seed', 'Random Seed', 'ランダムシード'),
)

_DRAW_SETTINGS = None
_RUNTIME_ACTIVE = False
_FEATURE_ICON_CACHE_MAX = max(64, len(catalog.FEATURES) + 16)
_FEATURE_ICON_SPEC_CACHE: dict[str, tuple[str, str]] = {}
_ACTIVE_STATS_CACHE = {'time': 0.0, 'key': None, 'value': None}
_NODE_GROUPS_CACHE = {'time': 0.0, 'value': ()}
_COVERAGE_ROWS_CACHE: dict[str, object] = {}
_SECTION_DRAWERS = {}


def clear_runtime_caches() -> None:
    """Clear every bounded N-panel cache at suspend/unregister boundaries."""
    global _DRAW_SETTINGS
    _DRAW_SETTINGS = None
    _FEATURE_ICON_SPEC_CACHE.clear()
    _ACTIVE_STATS_CACHE.update(time=0.0, key=None, value=None)
    _NODE_GROUPS_CACHE.update(time=0.0, value=())
    _COVERAGE_ROWS_CACHE.clear()
    try:
        catalog.clear_runtime_caches()
    except Exception:
        pass
    for proxy in (always_on, debris_generators, node_factory, storage):
        proxy.release()


def set_runtime_active(active: bool) -> None:
    global _RUNTIME_ACTIVE
    _RUNTIME_ACTIVE = bool(active)
    if not _RUNTIME_ACTIVE:
        clear_runtime_caches()
    _tag_view3d_ui_redraw()


def _safe_icon_name(name: str | None, default: str = 'NONE') -> str:
    value = str(name or '').strip()
    if not value:
        return default
    return _ICON_ALIAS.get(value, value)


def _operator_has_property(op, key: str) -> bool:
    try:
        bl_rna = getattr(op, 'bl_rna', None)
        props = getattr(bl_rna, 'properties', None)
        if props is None:
            return False
        return key in props.keys()
    except Exception:
        return False


def _set_operator_props(op, **props) -> None:
    if op is None:
        return
    for key, value in props.items():
        try:
            setattr(op, key, value)
            continue
        except Exception:
            pass
        if not _operator_has_property(op, key):
            continue
        try:
            setattr(op, key, value)
        except Exception:
            pass


def _t(en: str, ja: str, context=None) -> str:
    return catalog.text(en, ja, context)


def _settings(context):
    if _DRAW_SETTINGS is not None:
        return _DRAW_SETTINGS
    return get_settings(context)


_SUPPORTED_N_PANEL_SPACE_TYPES = frozenset({
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
})


def _panel_poll(
    context, physical_space_type: str, logical_editor_keys: tuple[str, ...],
    panel_region: str,
) -> bool:
    """Return one pure current-cell decision for one registered physical root.

    Each logical editor has one registered root Panel. The root classifies the current logical editor from the live context, verifies
    that the result belongs to its physical space, and forwards that exact key to
    the already-loaded Manager's cached ``placement_allowed`` API.  This function
    never imports, enables, reloads, scans, writes files, registers resources, or
    schedules redraw/timer work.
    """
    try:
        if not _RUNTIME_ACTIVE or not ownership.runtime_active_for_generation():
            return False
        if context is None or getattr(context, 'window_manager', None) is None:
            return False
        physical = str(physical_space_type or '').strip().upper()
        if physical not in _SUPPORTED_N_PANEL_SPACE_TYPES:
            return False
        area = getattr(context, 'area', None)
        if area is None or str(getattr(area, 'type', '') or '').strip().upper() != physical:
            return False
        region = getattr(context, 'region', None)
        if region is not None and getattr(region, 'type', None) not in {panel_region, 'WINDOW'}:
            return False
        logical = manager_compat.logical_editor_key_from_context(context)
        if logical not in logical_editor_keys:
            return False
        return bool(manager_compat.placement_allowed(context, logical))
    except Exception:
        return False


def _custom_icons_allowed(context) -> bool:
    # Blender 5.1 crash-safe policy: do not expose custom preview icon IDs to
    # live UI controls. Standard Blender icons are used for all operator rows.
    return False


def _draw_mode_guard(layout, context) -> bool:
    """Draw a mode note without suppressing the common panel body."""
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''
    if mode not in {'', 'OBJECT'}:
        try:
            box = layout.box()
            _label(
                box,
                'Object Mode commands are disabled.',
                'オブジェクトモード専用のボタンは無効',
                context,
            )
        except Exception:
            pass
    return True


def _label(layout, en: str, ja: str, context=None, icon: str = 'NONE') -> None:
    try:
        layout.label(text=_t(en, ja, context), icon=_safe_icon_name(icon))
    except Exception:
        layout.label(text=_t(en, ja, context))


def _icon(name: str, settings=None, context=None) -> int:
    # Blender 5.1 stability build: never request live custom preview icon IDs
    # from N-panel draw code. Returning 0 forces _button() to use Blender's
    # standard fallback icon path only.
    return 0


def _default_button_label(op_id: str, context=None, **props) -> str:
    """Return a visible command label when an operator caller omits one.

    Functional buttons should never become icon-only controls.  Top-level
    section disclosure buttons and help controls are drawn through separate
    helpers, so their existing format is not changed here.
    """
    op_id = str(op_id or '').strip()
    feature_id = str(props.get('feature_id') or '').strip()
    if op_id == 'smart_geometry_suite.apply_feature' and feature_id:
        feature = catalog.FEATURE_BY_ID.get(feature_id)
        if feature:
            return catalog.localized(feature, 'label', context)
    labels = {
        'smart_geometry_suite.apply_feature': ('Apply Feature', '機能を適用'),
        'smart_geometry_suite.apply_pack': ('Apply Pack', 'パックを適用'),
        'smart_geometry_suite.apply_precision_preset': ('Apply Precision Preset', '精度プリセットを適用'),
        'smart_geometry_suite.run_visual_workflow': ('Run Workflow', 'ワークフローを実行'),
        'smart_geometry_suite.polish_precision_overdrive': ('Run Precision Polish', '精度ポリッシュを実行'),
    }
    if op_id in labels:
        en, ja = labels[op_id]
        return _t(en, ja, context)
    try:
        namespace, opname = op_id.split('.', 1)
        op_ns = getattr(bpy.ops, namespace, None)
        op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
        get_rna_type = getattr(op_fn, 'get_rna_type', None)
        if callable(get_rna_type):
            name = str(getattr(get_rna_type(), 'name', '') or '').strip()
            if name:
                return name
    except Exception:
        pass
    try:
        return op_id.replace('_', ' ').replace('.', ' / ').title()
    except Exception:
        return _t('Run Command', 'コマンドを実行', context)


_OBJECT_MODE_OPERATOR_IDS = frozenset({
    'smart_geometry_suite.create_node_library',
    'smart_geometry_suite.rebuild_node_library',
    'smart_geometry_suite.apply_feature',
    'smart_geometry_suite.apply_pack',
    'smart_geometry_suite.apply_full_independent_suite',
    'smart_geometry_suite.add_standard_attributes',
    'smart_geometry_suite.refine_scene_precision',
    'smart_geometry_suite.apply_selection_string',
    'smart_geometry_suite.create_terrain',
    'smart_geometry_suite.create_scatter_points',
    'smart_geometry_suite.relax_distribution_points',
    'smart_geometry_suite.create_flow_network',
    'smart_geometry_suite.create_greeble_blocks',
    'smart_geometry_suite.create_building_proxy',
    'smart_geometry_suite.create_ivy_curve',
    'smart_geometry_suite.explode_mesh_to_pieces',
    'smart_geometry_suite.import_csv_points',
    'smart_geometry_suite.create_demo_scene',
    'smart_geometry_suite.create_attribute_heatmap',
    'smart_geometry_suite.create_attribute_snapshot',
    'smart_geometry_suite.create_distribution_proxy_instances',
    'smart_geometry_suite.polish_precision_overdrive',
    'smart_geometry_suite.run_visual_workflow',
    'smart_geometry_suite.remove_generated_node_groups',
    'smart_geometry_suite.debris_generate',
    'jel_max.add_generator',
    'jel_max.draw_generator',
    'jel_max.update_selected',
    'jel_max.update_all',
    'jel_max.refresh_selected',
    'gptools.add_gpencil',
    'gptools.gn_solid_mesh',
    'gptools.gn_mirror_mesh',
    'gptools.gn_path_mesh',
    'gptools.gn_wall_mesh',
    'gptools.screw_mesh',
    'gptools.lattice_wrap',
    'gptools.bool_cut',
    'gptools.array_on_curve',
    'gptools.apply_all_modifiers',
    'gptools.stamp_scatter',
    'gptools.knife_cut',
})


def _operator_context_enabled(op_id: str, context) -> bool:
    if str(op_id) not in _OBJECT_MODE_OPERATOR_IDS:
        return True
    try:
        return str(getattr(context, 'mode', '') or '') in {'', 'OBJECT'}
    except Exception:
        return False


def _button(layout, op_id: str, label: str = '', icon_name: str = '', fallback: str = 'NONE', context=None, scale: float = 1.0, emboss: bool | None = None, **props):
    del scale, emboss
    row = layout.row(align=True)
    try:
        row.enabled = _operator_context_enabled(op_id, context)
    except Exception:
        pass
    try:
        # Keep every sidebar operator at Blender's normal row height.  Older
        # saved settings and precision presets may still contain large icon
        # scale values, so button height is intentionally independent here.
        row.scale_y = 1.0
    except Exception:
        pass
    if fallback == 'NONE' and icon_name:
        fallback = _CUSTOM_ICON_FALLBACK.get(str(icon_name or ''), 'NONE')
    fallback_icon = _safe_icon_name(fallback, 'NONE')
    button_label = str(label or '').strip() or _default_button_label(op_id, context, **props)

    try:
        op = row.operator(op_id, text=button_label, icon=fallback_icon, emboss=True)
    except TypeError:
        try:
            op = row.operator(op_id, text=button_label, icon=fallback_icon)
        except TypeError:
            try:
                op = row.operator(op_id, text=button_label, icon='NONE', emboss=True)
            except TypeError:
                try:
                    op = row.operator(op_id, text=button_label, icon='NONE')
                except TypeError:
                    op = row.operator(op_id, text=button_label)
    _set_operator_props(op, **props)
    return op


def _help_button(layout, topic: str, context=None, *, feature_id: str = '', scale: float = 1.0):
    del scale
    row = layout.row(align=True)
    try:
        row.scale_x = 0.82
    except Exception:
        pass
    try:
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_geometry_suite.open_help', text='', icon='QUESTION', emboss=True)
    except TypeError:
        op = row.operator('smart_geometry_suite.open_help', text='?')
    _set_operator_props(op, help_key=str(topic or 'suite_overview'), feature_id=str(feature_id or ''))
    return op


def _icon_ref(layout, name: str, context, scale: float | None = None) -> None:
    del scale, context
    key = str(name or '')
    if key in {'workflow_reference', 'attribute_stack_reference', 'precision_pipeline_reference', 'command_deck_reference', 'icon_reference_sheet'}:
        return
    # Blender 5.1 crash-safe UI: draw Blender standard icons in reference grids
    # and avoid live custom preview icon_value handles entirely.
    fallback = _CUSTOM_ICON_FALLBACK.get(key, 'IMAGE_DATA')
    try:
        layout.label(text='', icon=_safe_icon_name(fallback, 'IMAGE_DATA'))
    except Exception:
        try:
            layout.label(text='', icon='IMAGE_DATA')
        except Exception:
            pass


def _section_expanded(settings, prop: str, default: bool = False) -> bool:
    try:
        return bool(getattr(settings, prop, default)) if settings is not None and hasattr(settings, prop) else bool(default)
    except Exception:
        return bool(default)


def _draw_section_header(layout, context, settings, show_prop: str, en: str, ja: str, *, icon: str = 'TOOL_SETTINGS', topic: str = 'suite_overview', feature_id: str = ''):
    expanded = _section_expanded(settings, show_prop, False)
    label = _t(en, ja, context)
    box = layout.box()
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    tri_icon = 'TRIA_DOWN' if expanded else 'TRIA_RIGHT'
    safe_icon = _safe_icon_name(icon, 'TOOL_SETTINGS')

    try:
        op = row.operator('smart_geometry_suite.toggle_ui_section', text='', icon=tri_icon, emboss=True, depress=bool(expanded))
        _set_operator_props(op, section_key=str(show_prop), label=label)
    except Exception:
        row.label(text='', icon=tri_icon)

    split = row.split(factor=0.86, align=True)
    left = split.row(align=True)
    try:
        op = left.operator('smart_geometry_suite.toggle_ui_section', text=label, icon=safe_icon, emboss=False, depress=bool(expanded))
        _set_operator_props(op, section_key=str(show_prop), label=label)
    except Exception:
        left.label(text=label, icon=safe_icon)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    _help_button(right, topic, context, feature_id=feature_id)
    return box, expanded


def _draw_child_panel(layout, context, owner, show_prop: str, en: str, ja: str, *, icon: str = 'NONE'):
    """Draw a compact Blender-style disclosure child and return its body."""
    label = _t(en, ja, context)
    try:
        header, body = layout.panel_prop(owner, show_prop)
    except Exception:
        try:
            owner_key = int(owner.as_pointer())
        except Exception:
            owner_key = id(owner)
        header, body = layout.panel(
            idname=f'smart_geometry_child_{show_prop}_{owner_key}',
            default_closed=not _section_expanded(owner, show_prop, True),
        )
    header.label(text=label, icon=_safe_icon_name(icon, 'NONE'))
    return body


def _draw_child_section_header(layout, context, settings, show_prop: str, en: str, ja: str, *, icon: str = 'NONE', default_open: bool = False):
    del default_open
    return _draw_child_panel(layout, context, settings, show_prop, en, ja, icon=icon)


def _draw_subsection_header(layout, context, settings, show_prop: str, en: str, ja: str, *, icon: str = 'TOOL_SETTINGS', topic: str = 'suite_overview'):
    del topic
    body = _draw_child_panel(layout, context, settings, show_prop, en, ja, icon=icon)
    return body, body is not None




def _cache_feature_icon(feature_id: str, value: tuple[str, str]) -> tuple[str, str]:
    if feature_id:
        _FEATURE_ICON_SPEC_CACHE[feature_id] = value
        while len(_FEATURE_ICON_SPEC_CACHE) > _FEATURE_ICON_CACHE_MAX:
            try:
                _FEATURE_ICON_SPEC_CACHE.pop(next(iter(_FEATURE_ICON_SPEC_CACHE)))
            except Exception:
                _FEATURE_ICON_SPEC_CACHE.clear()
                break
    return value
def _feature_icon_spec(feature: dict) -> tuple[str, str]:
    """Return (custom_icon_name, fallback_icon) for a feature apply button."""
    fid = str(feature.get('id') or '').lower()
    cached = _FEATURE_ICON_SPEC_CACHE.get(fid)
    if cached is not None:
        return cached
    category = str(feature.get('category') or '').lower()
    recipe = str(feature.get('recipe') or '').lower()
    domain = str(feature.get('design_domain_id') or feature.get('design_domain') or '').lower()
    label = str(feature.get('label_en') or feature.get('source_feature') or '').lower()
    blob = ' '.join((fid, category, recipe, domain, label))
    name_blob = ' '.join((fid, recipe, label))

    def has(*terms: str) -> bool:
        return any(term in blob for term in terms)

    def has_name(*terms: str) -> bool:
        return any(term in name_blob for term in terms)

    if has_name('icon', 'visual', 'ui', 'deck', 'atlas', 'reference', 'dashboard'):
        return _cache_feature_icon(fid, ('dashboard', 'WINDOW'))
    if has('hydrology', 'drainage', 'flow network'):
        return _cache_feature_icon(fid, ('flow', 'CURVE_PATH'))
    if has('terrain', 'heightfield', 'erosion', 'slope', 'habitat', 'biome'):
        return _cache_feature_icon(fid, ('terrain', 'MESH_GRID'))
    if has('relax', 'fairness', 'tangent-relaxed', 'centroidal'):
        return _cache_feature_icon(fid, ('relax', 'MOD_PARTICLE_INSTANCE'))
    if has('scatter', 'distribution', 'surface sampler', 'point projector', 'density', 'bounds anchor', 'brush'):
        return _cache_feature_icon(fid, ('scatter', 'PARTICLES'))
    if has('selection', 'boolean', 'gate', 'filter', 'mask', 'expression', 'resilience'):
        return _cache_feature_icon(fid, ('selection', 'RESTRICT_SELECT_OFF'))
    if has('fragment', 'fracture', 'explode', 'shatter', 'piece', 'interlock'):
        return _cache_feature_icon(fid, ('fragment', 'MOD_EXPLODE'))
    if has('greeble', 'panel'):
        return _cache_feature_icon(fid, ('greeble', 'MESH_CUBE'))
    if has('building', 'architecture', 'structure', 'modular'):
        return _cache_feature_icon(fid, ('structure', 'HOME'))
    if has('growth', 'ivy'):
        return _cache_feature_icon(fid, ('growth', 'CURVE_DATA'))
    if has('heatmap', 'heat score', 'saliency'):
        return _cache_feature_icon(fid, ('heatmap', 'COLOR'))
    if has('snapshot', 'checkpoint'):
        return _cache_feature_icon(fid, ('snapshot', 'DUPLICATE'))
    if has('diagnostic', 'inspector', 'audit', 'advisor', 'debug', 'analyzer', 'profiler'):
        return _cache_feature_icon(fid, ('diagnostics', 'VIEWZOOM'))
    if has('quality', 'risk', 'safety', 'guard', 'confidence', 'lod', 'stability'):
        return _cache_feature_icon(fid, ('quality', 'CHECKMARK'))
    if has('material', 'uv', 'mapping', 'wear', 'coordinate', 'grain', 'liquid'):
        return _cache_feature_icon(fid, ('material', 'MATERIAL'))
    if has('csv'):
        return _cache_feature_icon(fid, ('csv', 'FILE'))
    if has('manifest', 'usd', 'exchange', 'interop', 'bundle'):
        return _cache_feature_icon(fid, ('manifest', 'EXPORT'))
    if has('field', 'attribute', 'metadata', 'topology', 'curvature', 'normalizer', 'dictionary') or category == 'foundation':
        return _cache_feature_icon(fid, ('attribute', 'RNA'))
    if has('matter', 'volume', 'solver', 'liquid', 'agent', 'rig') or category == 'simulation':
        return _cache_feature_icon(fid, ('volume', 'OUTLINER_OB_MESH'))
    if has('motion', 'trail', 'signal', 'constraint', 'retarget') or category == 'motion':
        return _cache_feature_icon(fid, ('motion', 'CURVE_DATA'))
    if has('automation', 'python', 'script', 'controller') or category == 'automation':
        return _cache_feature_icon(fid, ('automation', 'TOOL_SETTINGS'))
    if has('capsule', 'compound', 'output', 'orchestrator') or category == 'capsule':
        return _cache_feature_icon(fid, ('capsule', 'GEOMETRY_NODES'))
    if category in {'utility', 'optimization'} or has('hash', 'realize', 'utility', 'remap', 'compute', 'grid', 'parallel', 'hierarchical'):
        return _cache_feature_icon(fid, ('utility', 'TOOL_SETTINGS'))
    if has('polish') or category == 'precision_overdrive':
        return _cache_feature_icon(fid, ('overdrive', 'SOLO_ON'))
    if has('precision', 'hyper') or category in {'command_precision', 'hyper_precision'}:
        return _cache_feature_icon(fid, ('precision', 'TOOL_SETTINGS'))
    return _cache_feature_icon(fid, ('', 'GEOMETRY_NODES'))


def _feature_apply_button(layout, feature: dict, context, *, label: str = ''):
    custom_icon, fallback = _feature_icon_spec(feature)
    button_label = str(label or '').strip() or catalog.localized(feature, 'label', context)
    op = _button(
        layout,
        'smart_geometry_suite.apply_feature',
        label=button_label,
        icon_name=custom_icon,
        fallback=fallback,
        context=context,
        scale=1.0,
        feature_id=str(feature.get('id') or ''),
    )
    return op


def _active_mesh_stats(context):
    """Read the last explicit/live diagnostic snapshot without scanning data."""
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return None
        name = str(wm.get('sgs_live_mesh_name', '') or '')
        if not name:
            return None
        return {
            'name': name,
            'vertices': int(wm.get('sgs_live_vertex_count', 0) or 0),
            'edges': int(wm.get('sgs_live_edge_count', 0) or 0),
            'polygons': int(wm.get('sgs_live_face_count', 0) or 0),
            'attributes': int(wm.get('sgs_live_attribute_count', 0) or 0),
            'modifiers': int(wm.get('sgs_live_modifier_count', 0) or 0),
        }
    except Exception:
        return None


def _filtered_features(settings, context):
    return catalog.filter_features(
        category=getattr(settings, 'feature_category', 'all'),
        source=getattr(settings, 'source_filter', 'all'),
        search=getattr(settings, 'search_filter', ''),
        context=context,
    )


def _tile(layout, context, op_id: str, icon_name: str, en: str, ja: str, fallback: str = 'NONE', *, topic: str = '', **props) -> None:
    box = layout.box()
    row = box.row(align=True)
    split = row.split(factor=0.86, align=True)
    left = split.row(align=True)
    label = _t(en, ja, context)
    _button(left, op_id, label=label, icon_name=icon_name, fallback=fallback, context=context, scale=1.0, emboss=True, **props)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    _help_button(right, topic or 'dashboard', context)



def _draw_always_on_body(layout, context, settings) -> None:
    # This section intentionally has no nested child foldout: across every
    # SmartTools product the state-save control is the first body row, followed
    # immediately by the complete set of runtime features.
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False

    if settings is not None and hasattr(settings, 'n_panel_state_save'):
        enabled = bool(getattr(settings, 'n_panel_state_save', True))
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        split.row(align=True).label(text=_t('N-panel State Save', 'Nパネル状態保存', context))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.prop(
            settings,
            'n_panel_state_save',
            text=_t('Enabled', '有効', context) if enabled else _t('Disabled', '無効', context),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
    else:
        _label(col, 'N-panel state saving is not available in this runtime.', 'この実行環境ではNパネル状態保存を使用できません。', context)

    col.separator(factor=0.5)

    for feature in always_on.feature_definitions():
        enabled = bool(always_on.feature_value(feature, context))
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=always_on.localized_label(feature, context))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.use_property_split = False
        right.use_property_decorate = False
        if settings is not None and hasattr(settings, feature.pref_property):
            right.prop(
                settings,
                feature.pref_property,
                text=_t('Enabled', '有効', context) if enabled else _t('Disabled', '無効', context),
                icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
                toggle=True,
            )
        else:
            disabled = right.row(align=True)
            disabled.enabled = False
            disabled.label(text=_t('Disabled', '無効', context), icon='CHECKBOX_DEHLT')

def _draw_suite_controls_body(layout, context, settings) -> None:
    overview = _draw_child_section_header(layout, context, settings, 'ui_child_suite_overview', 'Suite Overview', 'スイート概要', icon='GEOMETRY_NODES', default_open=True)
    if overview is not None:
        row = overview.row(align=True)
        _icon_ref(row, 'logo', context, scale=4.8)
        col = row.column(align=True)
        col.label(text='Smart Geometry')
        col.label(text=_t('Geometry Generators', 'ジオメトリ生成対応', context))

    active = _draw_child_section_header(layout, context, settings, 'ui_child_suite_active_targets', 'Active Targets', 'アクティブ対象', icon='RESTRICT_SELECT_OFF', default_open=True)
    if active is not None:
        col = active.column(align=True)
        col.prop(settings, 'active_feature', text=_t('Active Feature', 'アクティブ機能', context))
        col.prop(settings, 'active_pack', text=_t('Active Pack', 'アクティブパック', context))

    actions = _draw_child_section_header(layout, context, settings, 'ui_child_suite_actions', 'Apply and Library Actions', '適用とライブラリ操作', icon='NODETREE', default_open=True)
    if actions is not None:
        col = actions.column(align=True)
        row = col.row(align=True)
        _button(row, 'smart_geometry_suite.apply_feature', label=_t('Apply Feature', '機能を適用', context), icon_name='', fallback='GEOMETRY_NODES', context=context, scale=1.15)
        _button(row, 'smart_geometry_suite.apply_pack', label=_t('Apply Pack', 'パックを適用', context), icon_name='', fallback='PRESET', context=context, scale=1.15)
        row = col.row(align=True)
        _button(row, 'smart_geometry_suite.create_node_library', label=_t('Create Library', 'ライブラリ作成', context), icon_name='', fallback='NODETREE', context=context, scale=1.15)

    if getattr(settings, 'show_advanced', False):
        storage_body = _draw_child_section_header(layout, context, settings, 'ui_child_suite_storage', 'Storage', '保存先', icon='FILE_FOLDER', default_open=False)
        if storage_body is not None:
            storage_body.label(text=str(storage.user_data_dir(create=False)), translate=False)

def _draw_dashboard_body(layout, context, settings) -> None:
    preset_body = _draw_child_section_header(layout, context, settings, 'ui_child_dashboard_preset', 'Preset', 'プリセット', icon='PRESET', default_open=True)
    if preset_body is not None and settings is not None:
        row = preset_body.row(align=True)
        row.prop(settings, 'precision_preset', text=_t('Preset', 'プリセット', context))
        _button(row, 'smart_geometry_suite.apply_precision_preset', label=_t('Apply Precision Preset', '精度プリセットを適用', context), icon_name='', fallback='SOLO_ON', context=context, scale=1.0)

    precision_body = _draw_child_section_header(layout, context, settings, 'ui_child_dashboard_precision', 'Precision Workflows', '精度ワークフロー', icon='SOLO_ON', default_open=True)
    if precision_body is not None:
        _tile(precision_body, context, 'smart_geometry_suite.polish_precision_overdrive', 'overdrive', 'Polish', '磨き込み', 'FILE_REFRESH', topic='workflow_v8_polish')
        _tile(precision_body, context, 'smart_geometry_suite.run_visual_workflow', 'precision', 'Refine', '再構築', 'FILE_REFRESH', topic='workflow_refine', workflow_id='refine')

    workflows_body = _draw_child_section_header(layout, context, settings, 'ui_child_dashboard_scene_workflows', 'Scene Workflows', 'シーンワークフロー', icon='SCENE_DATA', default_open=True)
    if workflows_body is not None:
        _tile(workflows_body, context, 'smart_geometry_suite.run_visual_workflow', 'terrain', 'Environment', '環境', 'MESH_GRID', topic='workflow_environment', workflow_id='environment')
        _tile(workflows_body, context, 'smart_geometry_suite.run_visual_workflow', 'greeble', 'Surface Design', '表面設計', 'MESH_CUBE', topic='workflow_surface', workflow_id='surface')
        _tile(workflows_body, context, 'smart_geometry_suite.run_visual_workflow', 'fragment', 'Fragments', '破片', 'MOD_EXPLODE', topic='workflow_fragment', workflow_id='fragment')
        _tile(workflows_body, context, 'smart_geometry_suite.run_visual_workflow', 'diagnostics', 'Diagnose', '診断', 'VIEWZOOM', topic='workflow_diagnose', workflow_id='diagnose')
        _tile(workflows_body, context, 'smart_geometry_suite.run_visual_workflow', 'dashboard', 'Full Demo', '完全デモ', 'SCENE_DATA', topic='workflow_full_demo', workflow_id='full_demo')

def _draw_quick_start_body(layout, context, settings) -> None:
    scale = 1.0
    actions = _draw_child_section_header(layout, context, settings, 'ui_child_quick_start_actions', 'Setup Actions', 'セットアップ操作', icon='PLAY', default_open=True)
    if actions is not None:
        col = actions.column(align=True)
        _button(col, 'smart_geometry_suite.create_node_library', label=_t('Create Node Group Library', 'ノードグループライブラリ作成', context), icon_name='', fallback='NODETREE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.rebuild_node_library', label=_t('Rebuild Node Group Library', 'ノードグループライブラリ再構築', context), icon_name='', fallback='FILE_REFRESH', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_demo_scene', label=_t('Create Demo Scene', 'デモシーン作成', context), icon_name='', fallback='SCENE_DATA', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.apply_full_independent_suite', label=_t('Apply Full Independent Toolset', '完全独自ツールセットを適用', context), icon_name='', fallback='GEOMETRY_SET', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.polish_precision_overdrive', label=_t('Run Precision Polish', '精度ポリッシュを実行', context), icon_name='', fallback='FILE_REFRESH', context=context, scale=scale, emboss=False)

    presets = _draw_child_section_header(layout, context, settings, 'ui_child_quick_start_presets', 'Preset and Asset Options', 'プリセットとアセット設定', icon='PRESET', default_open=True)
    if presets is not None:
        presets.prop(settings, 'capsule_prefix', text=_t('Capsule Prefix', 'カプセル接頭辞', context))
        presets.prop(settings, 'mark_assets', text=_t('Mark Node Groups as Assets', 'ノードグループをアセット化', context))
        presets.prop(settings, 'precision_preset', text=_t('Precision Preset', '精度プリセット', context))
        _button(presets, 'smart_geometry_suite.apply_precision_preset', label=_t('Apply Precision Preset', '精度プリセットを適用', context), icon_name='', fallback='TOOL_SETTINGS', context=context, scale=scale, emboss=False)

    display = _draw_child_section_header(layout, context, settings, 'ui_child_quick_start_display', 'Display Options', '表示オプション', icon='PREFERENCES', default_open=False)
    if display is not None:
        display.prop(settings, 'show_advanced', text=_t('Show Advanced', '詳細を表示', context))

def _draw_catalog_body(layout, context, settings) -> None:
    filters = _draw_child_section_header(layout, context, settings, 'ui_child_catalog_filters', 'Filters', 'フィルター', icon='FILTER', default_open=True)
    if filters is not None:
        filters.prop(settings, 'feature_category', text=_t('Category', 'カテゴリ', context))
        filters.prop(settings, 'source_filter', text=_t('Domain', 'ドメイン', context))
        filters.prop(settings, 'search_filter', text=_t('Search', '検索', context))

    results = _draw_child_section_header(layout, context, settings, 'ui_child_catalog_results', 'Feature Results', '機能結果', icon='NODETREE', default_open=True)
    if results is None:
        return
    features = _filtered_features(settings, context)
    max_rows = 18 if not getattr(settings, 'show_advanced', False) else 64
    for feature in features[:max_rows]:
        fid = str(feature.get('id') or '')
        row = results.row(align=True)
        split = row.split(factor=0.86, align=True)
        left = split.row(align=True)
        _feature_apply_button(left, feature, context, label=catalog.localized(feature, 'label', context))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        _help_button(right, 'feature', context, feature_id=fid)
        if getattr(settings, 'show_advanced', False):
            results.label(text=catalog.feature_domain_label(feature, context))
    if len(features) > max_rows:
        _label(results, 'Narrow the catalog with search or enable advanced display for more rows.', '検索で絞り込むか、詳細表示を有効にすると表示行数が増えます。', context, icon='VIEWZOOM')

def _draw_setting_props(layout, context, settings, items) -> None:
    col = layout.column(align=True)
    for prop, en, ja in items:
        try:
            col.prop(settings, prop, text=_t(en, ja, context))
        except Exception:
            pass


def _draw_button_column(layout, context, settings, specs, *, scale: float | None = None) -> None:
    del scale
    col = layout.column(align=True)
    button_scale = 1.0
    for op_id, en, ja, icon, props in specs:
        if not _operator_registered(op_id):
            continue
        _button(col, op_id, label=_t(en, ja, context), icon_name='', fallback=icon, context=context, scale=button_scale, **dict(props or {}))


_TERRAIN_MESH_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('terrain_resolution', 'Terrain Resolution', '地形解像度'),
    ('terrain_size', 'Terrain Size', '地形サイズ'),
    ('terrain_height', 'Terrain Height', '地形高さ'),
    ('terrain_erosion_iterations', 'Erosion Iterations', '侵食反復'),
    ('terrain_hydraulic_droplets', 'Hydraulic Droplets', '水理ドロップ数'),
)

_TERRAIN_FLOW_PROPS = (
    ('drainage_curve_count', 'Drainage Curves', '排水カーブ数'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
    ('scatter_normal_offset', 'Normal Offset', '法線オフセット'),
)

_DISTRIBUTION_SURFACE_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('scatter_count', 'Amount', '数量'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
    ('scatter_min_spacing', 'Minimum Spacing', '最小間隔'),
    ('scatter_blue_noise', 'Blue-Noise Rejection', 'ブルーノイズ除外'),
    ('scatter_relax_iterations', 'Relax Iterations', '緩和反復'),
    ('scatter_normal_offset', 'Normal Offset', '法線オフセット'),
    ('scatter_biome_bias', 'Habitat Bias', '生息環境バイアス'),
    ('scatter_candidate_multiplier', 'Candidate Multiplier', '候補倍率'),
    ('density_threshold', 'Density Threshold', '密度しきい値'),
)

_DISTRIBUTION_RELAX_PROPS = (
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
    ('scatter_min_spacing', 'Minimum Spacing', '最小間隔'),
    ('scatter_relax_iterations', 'Relax Iterations', '緩和反復'),
)

_STRUCTURE_SURFACE_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('scatter_count', 'Amount', '数量'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
    ('density_threshold', 'Density Threshold', '密度しきい値'),
)

_MODULAR_STRUCTURE_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('structure_floors', 'Floors', '階数'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
)

_ORGANIC_GROWTH_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('growth_branches', 'Growth Branches', '成長枝数'),
    ('scatter_count', 'Amount', '数量'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
)

_FRAGMENT_PROPS = (
    ('random_seed', 'Random Seed', 'ランダムシード'),
    ('fragment_piece_count', 'Fragment Pieces', '破片数'),
    ('scatter_radius', 'Radius / Size', '半径 / サイズ'),
)

_PRECISION_TOOL_PROPS = (
    ('precision_preset', 'Precision Preset', '精度プリセット'),
    ('precision_v8_strength', 'Precision Strength', '精度強度'),
    ('precision_v8_quality_passes', 'Quality Passes', '品質パス'),
    ('precision_v8_feature_radius', 'Feature Radius', '特徴半径'),
    ('precision_v8_material_contrast', 'Material Contrast', 'マテリアルコントラスト'),
    ('precision_v8_risk_suppression', 'Risk Suppression', 'リスク抑制'),
    ('debug_attribute', 'Debug Attribute', 'デバッグ属性'),
)


def _draw_terrain_generators_body(layout, context, settings) -> None:
    terrain = _draw_child_section_header(layout, context, settings, 'ui_child_gen_terrain_mesh', 'Terrain Mesh', '地形メッシュ', icon='MESH_GRID', default_open=True)
    if terrain is not None:
        _draw_setting_props(terrain, context, settings, _TERRAIN_MESH_PROPS)
        _draw_button_column(terrain, context, settings, (
            ('smart_geometry_suite.create_terrain', 'Create Precision Terrain', '高精度地形を作成', 'MESH_GRID', {}),
        ))

    flow = _draw_child_section_header(layout, context, settings, 'ui_child_gen_terrain_flow', 'Drainage Flow Curves', '排水フローカーブ', icon='CURVE_PATH', default_open=True)
    if flow is not None:
        _draw_setting_props(flow, context, settings, _TERRAIN_FLOW_PROPS)
        _draw_button_column(flow, context, settings, (
            ('smart_geometry_suite.create_flow_network', 'Create Drainage Flow Network', '排水フローネットワークを作成', 'CURVE_PATH', {}),
        ))


def _draw_distribution_generators_body(layout, context, settings) -> None:
    surface = _draw_child_section_header(layout, context, settings, 'ui_child_gen_distribution_surface', 'Surface Distribution Points', '表面分布ポイント', icon='PARTICLES', default_open=True)
    if surface is not None:
        _draw_setting_props(surface, context, settings, _DISTRIBUTION_SURFACE_PROPS)
        _draw_button_column(surface, context, settings, (
            ('smart_geometry_suite.create_scatter_points', 'Create Precision Distribution Points', '高精度分布ポイントを作成', 'PARTICLES', {}),
        ))

    relax = _draw_child_section_header(layout, context, settings, 'ui_child_gen_distribution_relax_proxy', 'Relax and Preview Instances', '緩和とプレビューインスタンス', icon='MOD_PARTICLE_INSTANCE', default_open=True)
    if relax is not None:
        _draw_setting_props(relax, context, settings, _DISTRIBUTION_RELAX_PROPS)
        _draw_button_column(relax, context, settings, (
            ('smart_geometry_suite.relax_distribution_points', 'Relax Distribution Points', '分布ポイントを緩和', 'MOD_PARTICLE_INSTANCE', {}),
            ('smart_geometry_suite.create_distribution_proxy_instances', 'Create Distribution Proxy Instances', '分布プロキシインスタンスを作成', 'OUTLINER_OB_MESH', {}),
        ))

    csv = _draw_child_section_header(layout, context, settings, 'ui_child_gen_distribution_csv', 'CSV Point Cloud', 'CSVポイントクラウド', icon='FILE', default_open=False)
    if csv is not None:
        csv.prop(settings, 'csv_path', text=_t('CSV Path', 'CSVパス', context))
        _draw_button_column(csv, context, settings, (
            ('smart_geometry_suite.import_csv_points', 'Import CSV Points', 'CSVポイントを読み込み', 'FILE', {}),
        ))


def _draw_structure_surface_generators_body(layout, context, settings) -> None:
    surface = _draw_child_section_header(layout, context, settings, 'ui_child_gen_structure_surface', 'Surface Detail Blocks', '表面ディテールブロック', icon='MESH_CUBE', default_open=True)
    if surface is not None:
        _draw_setting_props(surface, context, settings, _STRUCTURE_SURFACE_PROPS)
        _draw_button_column(surface, context, settings, (
            ('smart_geometry_suite.create_greeble_blocks', 'Create Surface Detail Blocks', '表面ディテールブロックを作成', 'MESH_CUBE', {}),
        ))

    structure = _draw_child_section_header(layout, context, settings, 'ui_child_gen_structure_modular', 'Modular Structure', 'モジュラー構造', icon='HOME', default_open=True)
    if structure is not None:
        _draw_setting_props(structure, context, settings, _MODULAR_STRUCTURE_PROPS)
        _draw_button_column(structure, context, settings, (
            ('smart_geometry_suite.create_building_proxy', 'Create Modular Structure', 'モジュラー構造を作成', 'HOME', {}),
        ))


def _draw_organic_stroke_generators_body(layout, context, settings) -> None:
    growth = _draw_child_section_header(layout, context, settings, 'ui_child_gen_organic_growth', 'Organic Growth Curves', '有機成長カーブ', icon='CURVE_DATA', default_open=True)
    if growth is not None:
        _draw_setting_props(growth, context, settings, _ORGANIC_GROWTH_PROPS)
        _draw_button_column(growth, context, settings, (
            ('smart_geometry_suite.create_ivy_curve', 'Create Organic Growth Curves', '有機成長カーブを作成', 'CURVE_DATA', {}),
        ))

    grease = _draw_child_section_header(layout, context, settings, 'ui_child_gen_stroke_mesh', 'Grease Pencil Mesh Generators', 'Grease Pencilメッシュ生成', icon='GREASEPENCIL', default_open=True)
    if grease is not None:
        grid = grease.grid_flow(row_major=True, columns=2, align=True)
        grease_buttons = (
            ('gptools.add_gpencil', 'Add GP', 'GP追加', 'ADD', {}),
            ('gptools.apply_all_modifiers', 'Apply Modifiers', 'モディファイア適用', 'CHECKMARK', {}),
            ('gptools.gn_solid_mesh', 'Solid Mesh', 'ソリッドメッシュ', 'MOD_SOLIDIFY', {}),
            ('gptools.gn_mirror_mesh', 'Mirror Mesh', 'ミラーメッシュ', 'MOD_MIRROR', {}),
            ('gptools.gn_path_mesh', 'Path Mesh', 'パスメッシュ', 'MOD_CURVE', {}),
            ('gptools.gn_wall_mesh', 'Wall Mesh', '壁メッシュ', 'MOD_BUILD', {}),
            ('gptools.screw_mesh', 'Screw Mesh', 'スクリューメッシュ', 'MOD_SCREW', {}),
            ('gptools.bool_cut', 'Bool Cut', 'ブールカット', 'MOD_BOOLEAN', {}),
            ('gptools.array_on_curve', 'Array on Pencil', 'ペンシル上に配列', 'MOD_ARRAY', {}),
            ('gptools.knife_cut', 'Knife', 'ナイフ', 'MOD_EDGESPLIT', {}),
            ('gptools.stamp_scatter', 'Scatter', '散布', 'OUTLINER_OB_POINTCLOUD', {}),
            ('gptools.lattice_wrap', 'Lattice Wrap', 'ラティスラップ', 'MOD_LATTICE', {}),
        )
        for op_id, en, ja, icon, props in grease_buttons:
            if _operator_registered(op_id):
                _button(grid, op_id, label=_t(en, ja, context), fallback=icon, context=context, scale=1.05, **props)


def _draw_debris_fragment_generators_body(layout, context, settings) -> None:
    debris = _draw_child_section_header(layout, context, settings, 'ui_child_gen_debris_module', 'Debris Module Generator', 'デブリモジュール生成', icon='MESH_ICOSPHERE', default_open=True)
    if debris is not None:
        debris_generators.draw_panel(debris, context, include_popup_button=True, include_info=False)

    fragments = _draw_child_section_header(layout, context, settings, 'ui_child_gen_fragment_mesh', 'Mesh Fragment Generator', 'メッシュ破砕生成', icon='MOD_EXPLODE', default_open=True)
    if fragments is not None:
        _draw_setting_props(fragments, context, settings, _FRAGMENT_PROPS)
        _draw_button_column(fragments, context, settings, (
            ('smart_geometry_suite.explode_mesh_to_pieces', 'Create Clustered Fragments', 'クラスタ破片を作成', 'MOD_EXPLODE', {}),
        ))


def _draw_primitive_generators_body(layout, context, settings) -> None:
    primitives = _draw_child_section_header(layout, context, settings, 'ui_child_gen_primitives_max', 'Max Primitive Generators', 'Maxプリミティブ生成', icon='MESH_CUBE', default_open=True)
    if primitives is None:
        return
    if _menu_registered('JELMAX_MT_add_root'):
        primitives.menu('JELMAX_MT_add_root', text=_t('Open Max Primitives Menu', 'Maxプリミティブメニューを開く', context), icon='MESH_CUBE')
    grid = primitives.grid_flow(row_major=True, columns=2, align=True)
    if _operator_registered('jel_max.draw_generator'):
        _button(grid, 'jel_max.draw_generator', label=_t('Box', 'ボックス', context), fallback='MESH_CUBE', context=context, scale=1.05, generator_id='standard_box')
        _button(grid, 'jel_max.draw_generator', label=_t('Sphere', '球', context), fallback='MESH_UVSPHERE', context=context, scale=1.05, generator_id='standard_sphere')
        _button(grid, 'jel_max.draw_generator', label=_t('Cylinder', '円柱', context), fallback='MESH_CYLINDER', context=context, scale=1.05, generator_id='standard_cylinder')
        _button(grid, 'jel_max.draw_generator', label=_t('Wall', '壁', context), fallback='MOD_BUILD', context=context, scale=1.05, generator_id='aec_wall')



def _draw_attribute_visual_generators_body(layout, context, settings) -> None:
    precision = _draw_child_section_header(layout, context, settings, 'ui_child_gen_attribute_precision', 'Precision Attribute Generator', '高精度属性生成', icon='RNA', default_open=True)
    if precision is not None:
        _draw_setting_props(precision, context, settings, _PRECISION_TOOL_PROPS)
        _draw_button_column(precision, context, settings, (
            ('smart_geometry_suite.apply_precision_preset', 'Apply Precision Preset', '精度プリセットを適用', 'TOOL_SETTINGS', {}),
            ('smart_geometry_suite.add_standard_attributes', 'Build Precision Attributes', '高精度属性を構築', 'RNA', {}),
            ('smart_geometry_suite.refine_scene_precision', 'Refine Scene Precision', 'シーン精度を再構築', 'FILE_REFRESH', {}),
            ('smart_geometry_suite.polish_precision_overdrive', 'Run Precision Polish', '精度ポリッシュを実行', 'SOLO_ON', {}),
        ))

    selection = _draw_child_section_header(layout, context, settings, 'ui_child_gen_attribute_selection', 'Procedural Selection Attribute', 'プロシージャル選択属性', icon='RESTRICT_SELECT_OFF', default_open=True)
    if selection is not None:
        selection.prop(settings, 'selection_string', text=_t('Selection String', '選択文字列', context))
        selection.prop(settings, 'density_threshold', text=_t('Density Threshold', '密度しきい値', context))
        _draw_button_column(selection, context, settings, (
            ('smart_geometry_suite.apply_selection_string', 'Apply Selection String', '選択文字列を適用', 'RESTRICT_SELECT_OFF', {}),
        ))

    visual = _draw_child_section_header(layout, context, settings, 'ui_child_gen_attribute_visual_outputs', 'Attribute Visual Outputs', '属性可視化出力', icon='COLOR', default_open=True)
    if visual is not None:
        visual.prop(settings, 'debug_attribute', text=_t('Debug Attribute', 'デバッグ属性', context))
        _draw_button_column(visual, context, settings, (
            ('smart_geometry_suite.create_attribute_heatmap', 'Create Attribute Heatmap', '属性ヒートマップを作成', 'COLOR', {}),
            ('smart_geometry_suite.create_attribute_snapshot', 'Create Attribute Snapshot', '属性スナップショットを作成', 'DUPLICATE', {}),
        ))

def _draw_settings_body(layout, context, settings) -> None:
    scale = 1.0

    interface = _draw_child_section_header(layout, context, settings, 'ui_child_settings_interface', 'Interface', 'インターフェース', icon='PREFERENCES', default_open=True)
    if interface is not None:
        interface.prop(settings, 'ui_density', text=_t('UI Density', 'UI密度', context))
        interface.prop(settings, 'ui_icon_scale', text=_t('Icon Scale', 'アイコン倍率', context))
        interface.prop(settings, 'show_advanced', text=_t('Show Advanced', '詳細を表示', context))

    library = _draw_child_section_header(layout, context, settings, 'ui_child_settings_library', 'Node Library and Assets', 'ノードライブラリとアセット', icon='NODETREE', default_open=True)
    if library is not None:
        library.prop(settings, 'capsule_prefix', text=_t('Capsule Prefix', 'カプセル接頭辞', context))
        library.prop(settings, 'mark_assets', text=_t('Mark Node Groups as Assets', 'ノードグループをアセット化', context))
        _draw_button_column(library, context, settings, (
            ('smart_geometry_suite.create_node_library', 'Create Node Group Library', 'ノードグループライブラリ作成', 'NODETREE', {}),
            ('smart_geometry_suite.rebuild_node_library', 'Rebuild Node Group Library', 'ノードグループライブラリ再構築', 'FILE_REFRESH', {}),
        ), scale=scale)

    feature = _draw_child_section_header(layout, context, settings, 'ui_child_settings_feature_apply', 'Feature / Pack Apply', '機能 / パック適用', icon='GEOMETRY_NODES', default_open=True)
    if feature is not None:
        feature.prop(settings, 'active_feature', text=_t('Active Feature', 'アクティブ機能', context))
        feature.prop(settings, 'active_pack', text=_t('Active Pack', 'アクティブパック', context))
        row = feature.row(align=True)
        _button(row, 'smart_geometry_suite.apply_feature', label=_t('Apply Feature', '機能を適用', context), icon_name='', fallback='GEOMETRY_NODES', context=context, scale=1.15)
        _button(row, 'smart_geometry_suite.apply_pack', label=_t('Apply Pack', 'パックを適用', context), icon_name='', fallback='PRESET', context=context, scale=1.15)
        if settings and getattr(settings, 'show_advanced', False):
            feature.separator()
            feature.prop(settings, 'feature_category', text=_t('Category', 'カテゴリ', context))
            feature.prop(settings, 'source_filter', text=_t('Domain', 'ドメイン', context))
            feature.prop(settings, 'search_filter', text=_t('Search', '検索', context))
            features = _filtered_features(settings, context)
            for item in features[:10]:
                fid = str(item.get('id') or '')
                row = feature.row(align=True)
                split = row.split(factor=0.86, align=True)
                left = split.row(align=True)
                _feature_apply_button(left, item, context, label=catalog.localized(item, 'label', context))
                right = split.row(align=True)
                right.alignment = 'RIGHT'
                _help_button(right, 'feature', context, feature_id=fid)
            if len(features) > 10:
                _label(feature, 'Use search to narrow the advanced feature list.', '詳細機能一覧は検索で絞り込んでください。', context, icon='VIEWZOOM')

    diagnostics_body = _draw_child_section_header(layout, context, settings, 'ui_child_settings_diagnostics', 'Diagnostics and Cleanup', '診断とクリーンアップ', icon='VIEWZOOM', default_open=False)
    if diagnostics_body is not None:
        diagnostics_body.operator(
            'smart_geometry_suite.refresh_diagnostics',
            text=_t('Refresh Diagnostics', '診断を更新', context),
            icon='FILE_REFRESH',
        )
        stats = _active_mesh_stats(context)
        if stats is None:
            _label(diagnostics_body, 'No active mesh object. Select a mesh object first.', 'アクティブなメッシュオブジェクトがありません。先にメッシュオブジェクトを選択してください。', context)
        else:
            for key, en, ja in [('name', 'Name', '名前'), ('vertices', 'Vertices', '頂点'), ('edges', 'Edges', '辺'), ('polygons', 'Faces', '面'), ('attributes', 'Attributes', '属性'), ('modifiers', 'Modifiers', 'モディファイア')]:
                diagnostics_body.label(text=f'{_t(en, ja, context)}: {stats[key]}', translate=False)
        groups = _cached_generated_node_groups()
        diagnostics_body.label(text=f'{_t("Generated Node Groups", "生成済みノードグループ", context)}: {len(groups)}')
        for group in groups[:8]:
            diagnostics_body.label(text=group, translate=False)
        _draw_button_column(diagnostics_body, context, settings, (
            ('smart_geometry_suite.export_diagnostics', 'Export Diagnostics JSON', '診断JSONを書き出し', 'TEXT', {}),
            ('smart_geometry_suite.export_inventory', 'Export Inventory JSON', 'インベントリJSONを書き出し', 'FILE_TEXT', {}),
            ('smart_geometry_suite.remove_generated_node_groups', 'Remove Generated Node Groups', '生成済みノードグループを削除', 'TRASH', {}),
        ), scale=scale)

    reports = _draw_child_section_header(layout, context, settings, 'ui_child_settings_reports', 'Import / Export Manifests', '読み込み / 書き出しマニフェスト', icon='EXPORT', default_open=False)
    if reports is not None:
        _draw_button_column(reports, context, settings, (
            ('smart_geometry_suite.export_usd_manifest', 'Export USD Sidecar Manifest', 'USDサイドカーマニフェストを書き出し', 'EXPORT', {}),
            ('smart_geometry_suite.export_bundle_manifest', 'Export Toolset Bundle Manifest', 'ツールセットバンドルマニフェストを書き出し', 'PACKAGE', {}),
            ('smart_geometry_suite.export_design_coverage', 'Export Design Coverage JSON', '設計カバーJSONを書き出し', 'FILE_TICK', {}),
        ), scale=scale)

    debris_util = _draw_child_section_header(layout, context, settings, 'ui_child_settings_debris_utility', 'Debris Utility Settings', 'デブリ補助設定', icon='MESH_ICOSPHERE', default_open=False)
    if debris_util is not None:
        p = debris_generators.get_settings(context)
        if p is None:
            _label(debris_util, 'Debris settings are not available.', 'デブリ設定を使用できません。', context, icon='ERROR')
        else:
            debris_util.operator('smart_geometry_suite.debris_refresh_modules', text=debris_generators.tr('Embedded Module Availability', context), icon='CHECKMARK')
            debris_util.operator('smart_geometry_suite.debris_about', text=debris_generators.tr('About', context))

    visual = _draw_child_section_header(layout, context, settings, 'ui_child_settings_visual_reference', 'Visual Reference', 'ビジュアルリファレンス', icon='IMAGE_DATA', default_open=False)
    if visual is not None:
        _draw_button_column(visual, context, settings, (
            ('smart_geometry_suite.open_visual_reference', 'Open Visual Reference', 'ビジュアルリファレンスを開く', 'IMAGE_DATA', {}),
            ('smart_geometry_suite.export_icon_reference_sheet', 'Export Icon Reference Sheet', 'アイコンリファレンスを書き出し', 'IMAGE_DATA', {}),
        ), scale=scale)

    if settings and getattr(settings, 'show_advanced', False):
        coverage = _draw_child_section_header(layout, context, settings, 'ui_child_settings_coverage', 'Coverage Summary', 'カバー範囲サマリー', icon='CHECKMARK', default_open=False)
        if coverage is not None:
            category_rows, domain_rows = _coverage_rows(context)
            for text_value in category_rows[:24]:
                coverage.label(text=text_value)
            coverage.separator()
            for text_value in domain_rows[:24]:
                coverage.label(text=text_value)

        storage_body = _draw_child_section_header(layout, context, settings, 'ui_child_settings_storage', 'Storage', '保存先', icon='FILE_FOLDER', default_open=False)
        if storage_body is not None:
            storage_body.label(text=str(storage.user_data_dir(create=False)), translate=False)


def _draw_builder_controls_body(layout, context, settings) -> None:
    terrain_items = tuple(item for item in _BUILDER_CONTROL_PROPS if item[0].startswith('terrain_') or item[0] == 'drainage_curve_count')
    scatter_items = tuple(item for item in _BUILDER_CONTROL_PROPS if item[0].startswith('scatter_') or item[0] in {'density_threshold', 'structure_floors'})
    growth_fragment_items = tuple(item for item in _BUILDER_CONTROL_PROPS if item[0].startswith('growth_') or item[0].startswith('fragment_'))
    precision_debug_items = tuple(item for item in _BUILDER_CONTROL_PROPS if item[0].startswith('precision_') or item[0] in {'debug_attribute', 'random_seed'})

    terrain = _draw_child_section_header(layout, context, settings, 'ui_child_builder_controls_terrain', 'Terrain and Hydrology', '地形と水系', icon='MESH_GRID', default_open=False)
    if terrain is not None:
        _draw_setting_props(terrain, context, settings, terrain_items)

    scatter = _draw_child_section_header(layout, context, settings, 'ui_child_builder_controls_distribution', 'Scatter and Distribution', '散布と分布', icon='PARTICLES', default_open=False)
    if scatter is not None:
        _draw_setting_props(scatter, context, settings, scatter_items)

    fragments = _draw_child_section_header(layout, context, settings, 'ui_child_builder_controls_fragments', 'Growth and Fragmentation', '成長と破片化', icon='MOD_EXPLODE', default_open=False)
    if fragments is not None:
        _draw_setting_props(fragments, context, settings, growth_fragment_items)

    precision = _draw_child_section_header(layout, context, settings, 'ui_child_builder_controls_precision', 'Precision and Debug', '精度とデバッグ', icon='TOOL_SETTINGS', default_open=False)
    if precision is not None:
        _draw_setting_props(precision, context, settings, precision_debug_items)

def _operator_registered(op_id: str) -> bool:
    try:
        namespace, opname = str(op_id or '').split('.', 1)
        op_ns = getattr(bpy.ops, namespace, None)
        op_fn = getattr(op_ns, opname, None) if op_ns is not None else None
        get_rna_type = getattr(op_fn, 'get_rna_type', None)
        if not callable(get_rna_type):
            return False
        rna = get_rna_type()
        return bool(getattr(rna, 'identifier', '') or '')
    except Exception:
        return False


def _menu_registered(menu_id: str) -> bool:
    try:
        cls = getattr(bpy.types, str(menu_id or ''), None)
        return isinstance(cls, type)
    except Exception:
        return False



def _draw_migrated_sms_geometry_body(layout, context, settings) -> None:
    _label(layout, 'Migrated Geometry-Node Generators', '移植済みジオメトリノード生成ツール', context, icon='GEOMETRY_NODES')

    max_box = _draw_child_section_header(layout, context, settings, 'ui_child_builders_max_primitives', 'Max Primitives', 'Maxプリミティブ', icon='MESH_CUBE', default_open=True)
    if max_box is not None:
        if _menu_registered('JELMAX_MT_add_root'):
            max_box.menu('JELMAX_MT_add_root', text=_t('Open Max Primitives Menu', 'Maxプリミティブメニューを開く', context), icon='MESH_CUBE')
        grid = max_box.grid_flow(row_major=True, columns=2, align=True)
        if _operator_registered('jel_max.draw_generator'):
            _button(grid, 'jel_max.draw_generator', label=_t('Box', 'ボックス', context), fallback='MESH_CUBE', context=context, scale=1.05, generator_id='standard_box')
            _button(grid, 'jel_max.draw_generator', label=_t('Sphere', '球', context), fallback='MESH_UVSPHERE', context=context, scale=1.05, generator_id='standard_sphere')
            _button(grid, 'jel_max.draw_generator', label=_t('Cylinder', '円柱', context), fallback='MESH_CYLINDER', context=context, scale=1.05, generator_id='standard_cylinder')
            _button(grid, 'jel_max.draw_generator', label=_t('Wall', '壁', context), fallback='MOD_BUILD', context=context, scale=1.05, generator_id='aec_wall')
        row = max_box.row(align=True)
        if _operator_registered('jel_max.install_assets'):
            _button(row, 'jel_max.install_assets', label=_t('Install Assets', 'アセットをインストール', context), fallback='ASSET_MANAGER', context=context, scale=1.0)
        if _operator_registered('jel_max.update_all'):
            _button(row, 'jel_max.update_all', label=_t('Update All', '全て更新', context), fallback='FILE_REFRESH', context=context, scale=1.0)

    grease_box = _draw_child_section_header(layout, context, settings, 'ui_child_builders_grease_mesh', 'Grease Mesh', 'グリースメッシュ', icon='GREASEPENCIL', default_open=True)
    if grease_box is not None:
        grid = grease_box.grid_flow(row_major=True, columns=2, align=True)
        grease_buttons = (
            ('gptools.add_gpencil', 'Add GP', 'GP追加', 'ADD', {}),
            ('gptools.apply_all_modifiers', 'Apply Modifiers', 'モディファイア適用', 'CHECKMARK', {}),
            ('gptools.gn_solid_mesh', 'Solid Mesh', 'ソリッドメッシュ', 'MOD_SOLIDIFY', {}),
            ('gptools.gn_mirror_mesh', 'Mirror Mesh', 'ミラーメッシュ', 'MOD_MIRROR', {}),
            ('gptools.gn_path_mesh', 'Path Mesh', 'パスメッシュ', 'MOD_CURVE', {}),
            ('gptools.gn_wall_mesh', 'Wall Mesh', '壁メッシュ', 'MOD_BUILD', {}),
            ('gptools.screw_mesh', 'Screw Mesh', 'スクリューメッシュ', 'MOD_SCREW', {}),
            ('gptools.bool_cut', 'Bool Cut', 'ブールカット', 'MOD_BOOLEAN', {}),
            ('gptools.array_on_curve', 'Array on Pencil', 'ペンシル上に配列', 'MOD_ARRAY', {}),
            ('gptools.knife_cut', 'Knife', 'ナイフ', 'MOD_EDGESPLIT', {}),
            ('gptools.stamp_scatter', 'Scatter', '散布', 'OUTLINER_OB_POINTCLOUD', {}),
            ('gptools.lattice_wrap', 'Lattice Wrap', 'ラティスラップ', 'MOD_LATTICE', {}),
        )
        for op_id, en, ja, icon, props in grease_buttons:
            if _operator_registered(op_id):
                _button(grid, op_id, label=_t(en, ja, context), fallback=icon, context=context, scale=1.05, **props)

def _draw_debris_generators_body(layout, context, settings) -> None:
    del settings
    debris_generators.draw_panel(layout, context, include_popup_button=True, include_info=True)

def _draw_builders_body(layout, context, settings) -> None:
    scale = 1.0

    precision = _draw_child_section_header(layout, context, settings, 'ui_child_builders_precision_setup', 'Precision Setup', '精度セットアップ', icon='RNA', default_open=True)
    if precision is not None:
        col = precision.column(align=True)
        _button(col, 'smart_geometry_suite.add_standard_attributes', label=_t('Build Precision Attributes', '高精度属性を構築', context), icon_name='', fallback='RNA', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.refine_scene_precision', label=_t('Refine Scene Precision', 'シーン精度を再構築', context), icon_name='', fallback='FILE_REFRESH', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.polish_precision_overdrive', label=_t('Run Precision Polish', '精度ポリッシュを実行', context), icon_name='', fallback='SOLO_ON', context=context, scale=scale, emboss=False)

    selection = _draw_child_section_header(layout, context, settings, 'ui_child_builders_selection', 'Selection String Tools', '選択文字列ツール', icon='RESTRICT_SELECT_OFF', default_open=True)
    if selection is not None:
        selection.prop(settings, 'selection_string', text=_t('Selection String', '選択文字列', context))
        col = selection.column(align=True)
        _button(col, 'smart_geometry_suite.apply_selection_string', label=_t('Apply Selection String', '選択文字列を適用', context), icon_name='', fallback='RESTRICT_SELECT_OFF', context=context, scale=scale)

    controls, open_controls = _draw_subsection_header(layout, context, settings, 'ui_section_builder_controls', 'Builder Controls', '生成コントロール', icon='TOOL_SETTINGS', topic='builder_controls')
    if open_controls:
        _draw_builder_controls_body(controls, context, settings)

    migrated = _draw_child_section_header(layout, context, settings, 'ui_child_builders_migrated_generators', 'Migrated Generators', '移植済み生成ツール', icon='GEOMETRY_NODES', default_open=True)
    if migrated is not None:
        _draw_migrated_sms_geometry_body(migrated, context, settings)

    debris, open_debris = _draw_subsection_header(layout, context, settings, 'ui_section_debris_generators', 'Debris Generators', 'デブリ生成', icon='MESH_ICOSPHERE', topic='procedural_builders')
    if open_debris:
        _draw_debris_generators_body(debris, context, settings)

    scene = _draw_child_section_header(layout, context, settings, 'ui_child_builders_scene_generators', 'Scene Generators', 'シーン生成', icon='SCENE_DATA', default_open=True)
    if scene is not None:
        col = scene.column(align=True)
        _button(col, 'smart_geometry_suite.create_terrain', label=_t('Create Precision Terrain', '高精度地形を作成', context), icon_name='', fallback='MESH_GRID', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_scatter_points', label=_t('Create Precision Distribution Points', '高精度分布ポイントを作成', context), icon_name='', fallback='PARTICLES', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.relax_distribution_points', label=_t('Relax Distribution Points', '分布ポイントを緩和', context), icon_name='', fallback='MOD_PARTICLE_INSTANCE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_flow_network', label=_t('Create Drainage Flow Network', '排水フローネットワークを作成', context), icon_name='', fallback='CURVE_PATH', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_greeble_blocks', label=_t('Create Surface Detail Blocks', '表面ディテールブロックを作成', context), icon_name='', fallback='MESH_CUBE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_building_proxy', label=_t('Create Modular Structure', 'モジュラー構造を作成', context), icon_name='', fallback='HOME', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_ivy_curve', label=_t('Create Organic Growth Curves', '有機成長カーブを作成', context), icon_name='', fallback='CURVE_DATA', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.explode_mesh_to_pieces', label=_t('Create Clustered Fragments', 'クラスタ破片を作成', context), icon_name='', fallback='MOD_EXPLODE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_distribution_proxy_instances', label=_t('Create Distribution Proxy Instances', '分布プロキシインスタンスを作成', context), icon_name='', fallback='OUTLINER_OB_MESH', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_attribute_heatmap', label=_t('Create Attribute Heatmap', '属性ヒートマップを作成', context), icon_name='', fallback='COLOR', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.create_attribute_snapshot', label=_t('Create Attribute Snapshot', '属性スナップショットを作成', context), icon_name='', fallback='DUPLICATE', context=context, scale=scale)

def _draw_interop_body(layout, context, settings) -> None:
    scale = 1.0

    paths = _draw_child_section_header(layout, context, settings, 'ui_child_interop_paths', 'Input Paths', '入力パス', icon='FILE_FOLDER', default_open=True)
    if paths is not None:
        paths.prop(settings, 'csv_path', text=_t('CSV Path', 'CSVパス', context))

    exports = _draw_child_section_header(layout, context, settings, 'ui_child_interop_exports', 'Export Commands', '書き出しコマンド', icon='EXPORT', default_open=True)
    if exports is not None:
        col = exports.column(align=True)
        _button(col, 'smart_geometry_suite.import_csv_points', label=_t('Import CSV Points', 'CSVポイントを読み込み', context), icon_name='', fallback='FILE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.export_usd_manifest', label=_t('Export USD Sidecar Manifest', 'USDサイドカーマニフェストを書き出し', context), icon_name='', fallback='EXPORT', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.export_bundle_manifest', label=_t('Export Toolset Bundle Manifest', 'ツールセットバンドルマニフェストを書き出し', context), icon_name='', fallback='PACKAGE', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.export_design_coverage', label=_t('Export Design Coverage JSON', '設計カバーJSONを書き出し', context), icon_name='', fallback='FILE_TICK', context=context, scale=scale)

    bridges = _draw_child_section_header(layout, context, settings, 'ui_child_interop_bridges', 'Exchange Bridges', '交換ブリッジ', icon='LINKED', default_open=True)
    if bridges is not None:
        for fid in ('attribute_exchange_bridge', 'field_exchange_bridge', 'usd_attribute_manifest', 'csv_point_cloud_importer'):
            feature = catalog.FEATURE_BY_ID.get(fid)
            if not feature:
                continue
            row = bridges.row(align=True)
            split = row.split(factor=0.82, align=True)
            _feature_apply_button(split.row(align=True), feature, context, label=catalog.localized(feature, 'label', context))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            _help_button(right, 'feature', context, feature_id=fid)

def _refresh_generated_node_groups():
    try:
        value = tuple(
            str(getattr(group, 'name', '') or '')
            for group in node_factory.generated_node_groups()
            if str(getattr(group, 'name', '') or '')
        )
    except Exception:
        value = ()
    _NODE_GROUPS_CACHE.update(time=time.monotonic(), value=value)
    return value


def _cached_generated_node_groups():
    """Return the last explicit snapshot; N-panel draw must never scan data."""
    return tuple(_NODE_GROUPS_CACHE.get('value') or ())



def _draw_diagnostics_body(layout, context, settings) -> None:
    mesh_body = _draw_child_section_header(layout, context, settings, 'ui_child_diagnostics_active_mesh', 'Active Mesh', 'アクティブメッシュ', icon='OBJECT_DATA', default_open=True)
    if mesh_body is not None:
        mesh_body.operator(
            'smart_geometry_suite.refresh_diagnostics',
            text=_t('Refresh Diagnostics', '診断を更新', context),
            icon='FILE_REFRESH',
        )
        stats = _active_mesh_stats(context)
        if stats is None:
            _label(mesh_body, 'No active mesh object. Select a mesh object first.', 'アクティブなメッシュオブジェクトがありません。先にメッシュオブジェクトを選択してください。', context)
        else:
            for key, en, ja in [('name', 'Name', '名前'), ('vertices', 'Vertices', '頂点'), ('edges', 'Edges', '辺'), ('polygons', 'Faces', '面'), ('attributes', 'Attributes', '属性'), ('modifiers', 'Modifiers', 'モディファイア')]:
                mesh_body.label(text=f'{_t(en, ja, context)}: {stats[key]}', translate=False)

    groups_body = _draw_child_section_header(layout, context, settings, 'ui_child_diagnostics_node_groups', 'Generated Node Groups', '生成済みノードグループ', icon='NODETREE', default_open=True)
    if groups_body is not None:
        groups = _cached_generated_node_groups()
        groups_body.label(text=str(len(groups)))
        for group in groups[:12]:
            groups_body.label(text=group, translate=False)
        if len(groups) > 12:
            groups_body.label(text=f'+{len(groups) - 12}')

    exports = _draw_child_section_header(layout, context, settings, 'ui_child_diagnostics_exports', 'Diagnostics Export', '診断書き出し', icon='EXPORT', default_open=True)
    if exports is not None:
        scale = 1.0
        col = exports.column(align=True)
        _button(col, 'smart_geometry_suite.export_diagnostics', label=_t('Export Diagnostics JSON', '診断JSONを書き出し', context), icon_name='', fallback='TEXT', context=context, scale=scale)
        _button(col, 'smart_geometry_suite.export_inventory', label=_t('Export Inventory JSON', 'インベントリJSONを書き出し', context), icon_name='', fallback='FILE_TEXT', context=context, scale=scale)

    if settings and getattr(settings, 'show_advanced', False):
        maintenance = _draw_child_section_header(layout, context, settings, 'ui_child_diagnostics_maintenance', 'Maintenance', 'メンテナンス', icon='TRASH', default_open=False)
        if maintenance is not None:
            scale = 1.0
            col = maintenance.column(align=True)
            _button(col, 'smart_geometry_suite.remove_generated_node_groups', label=_t('Remove Generated Node Groups', '生成済みノードグループを削除', context), icon_name='', fallback='TRASH', context=context, scale=scale)

def _draw_visual_ui_body(layout, context, settings) -> None:
    display = _draw_child_section_header(layout, context, settings, 'ui_child_visual_ui_display', 'Display Controls', '表示コントロール', icon='PREFERENCES', default_open=True)
    if display is not None:
        display.prop(settings, 'ui_density', text=_t('UI Density', 'UI密度', context))
        display.prop(settings, 'ui_icon_scale', text=_t('Icon Scale', 'アイコン倍率', context))
        display.prop(settings, 'ui_v8_tile_scale', text=_t('Dashboard Tile Scale', 'ダッシュボードタイル倍率', context))
        display.prop(settings, 'ui_v8_show_reference_strips', text=_t('Show Reference Strips', 'リファレンス帯を表示', context))

    precision = _draw_child_section_header(layout, context, settings, 'ui_child_visual_ui_precision', 'Precision Display Values', '精度表示値', icon='SOLO_ON', default_open=True)
    if precision is not None:
        precision.prop(settings, 'precision_preset', text=_t('Precision Preset', '精度プリセット', context))
        precision.prop(settings, 'precision_v7_strength', text=_t('Base Precision Strength', '基礎精度強度', context))
        precision.prop(settings, 'precision_v7_feature_preservation', text=_t('Base Feature Preservation', '基礎特徴保持', context))
        precision.prop(settings, 'precision_v7_material_regions', text=_t('Material Regions', 'マテリアル領域数', context))
        precision.prop(settings, 'precision_v8_strength', text=_t('Precision Strength', '精度強度', context))
        precision.prop(settings, 'precision_v8_quality_passes', text=_t('Quality Passes', '品質パス', context))
        precision.prop(settings, 'precision_v8_material_contrast', text=_t('Material Contrast', 'マテリアルコントラスト', context))

    reference = _draw_child_section_header(layout, context, settings, 'ui_child_visual_ui_reference', 'Reference Tools', 'リファレンスツール', icon='IMAGE_DATA', default_open=True)
    if reference is not None:
        scale = 1.0
        _button(reference, 'smart_geometry_suite.open_visual_reference', label=_t('Open Visual Reference', 'ビジュアルリファレンスを開く', context), icon_name='', fallback='IMAGE_DATA', context=context, scale=scale)
        _button(reference, 'smart_geometry_suite.export_icon_reference_sheet', label=_t('Export Icon Reference Sheet', 'アイコンリファレンスを書き出し', context), icon_name='', fallback='IMAGE_DATA', context=context, scale=scale)

def _coverage_rows(context):
    lang = 'ja' if catalog.is_japanese(context) else 'en'
    cached = _COVERAGE_ROWS_CACHE.get(lang)
    if cached is not None:
        return cached
    counts = catalog.count_by_category()
    category_rows = []
    for category in catalog.CATEGORIES:
        cid = str(category.get('id') or '')
        if cid == 'all':
            continue
        category_rows.append(f'{catalog.localized(category, "label", context)}: {counts.get(cid, 0)}')
    domain_counts = catalog.count_by_domain()
    domain_rows = [f'{catalog.domain_label_from_value(src, context)}: {count}' for src, count in sorted(domain_counts.items(), key=lambda x: x[0].lower())[:48]]
    cached = (tuple(category_rows), tuple(domain_rows))
    _COVERAGE_ROWS_CACHE[lang] = cached
    return cached



def _draw_coverage_body(layout, context, settings) -> None:
    category_rows, domain_rows = _coverage_rows(context)
    categories = _draw_child_section_header(layout, context, settings, 'ui_child_coverage_categories', 'Categories', 'カテゴリ', icon='GROUP', default_open=True)
    if categories is not None:
        for text_value in category_rows:
            categories.label(text=text_value)
    domains = _draw_child_section_header(layout, context, settings, 'ui_child_coverage_domains', 'Design Domains', '設計ドメイン', icon='LINKED', default_open=True)
    if domains is not None:
        for text_value in domain_rows:
            domains.label(text=text_value)



_SECTION_DRAWERS.update({
    'ui_section_always_on': _draw_always_on_body,
    'ui_section_terrain_generators': _draw_terrain_generators_body,
    'ui_section_distribution_generators': _draw_distribution_generators_body,
    'ui_section_structure_surface_generators': _draw_structure_surface_generators_body,
    'ui_section_organic_stroke_generators': _draw_organic_stroke_generators_body,
    'ui_section_debris_fragment_generators': _draw_debris_fragment_generators_body,
    'ui_section_primitive_generators': _draw_primitive_generators_body,
    'ui_section_attribute_visual_generators': _draw_attribute_visual_generators_body,
    'ui_section_settings': _draw_settings_body,
})

def _tag_view3d_ui_redraw():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if getattr(area, 'type', None) not in _SUPPORTED_N_PANEL_SPACE_TYPES:
                    continue
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass




class SGS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.toggle_ui_section'
    bl_label = 'Toggle Smart Geometry Section'
    bl_description = 'Expand or collapse this Smart Geometry N-panel section.'
    bl_options = {'INTERNAL'}

    section_key: StringProperty(
        name='Section Property',
        description='Internal settings property whose Boolean value is toggled to expand or collapse this Smart Geometry section.',
        default='',
    )
    label: StringProperty(
        name='Section Label',
        description='Localized section label used by the N-panel disclosure control and operator history.',
        default='',
    )

    def execute(self, context):
        settings = _settings(context)
        key = str(getattr(self, 'section_key', '') or '').strip()
        if not key or settings is None or not hasattr(settings, key):
            return {'CANCELLED'}
        try:
            setattr(settings, key, not bool(getattr(settings, key)))
            _tag_view3d_ui_redraw()
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}


class SGS_OT_refresh_diagnostics(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.refresh_diagnostics'
    bl_label = 'Refresh Diagnostics'
    bl_description = 'Refresh the cached mesh and generated-node-group diagnostics on demand.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            always_on.refresh_mesh_inspector(context, force=True)
            _refresh_generated_node_groups()
            _tag_view3d_ui_redraw()
        except Exception as exc:
            self.report({'ERROR'}, catalog.failure_text('Could not refresh the diagnostics', '診断を更新できませんでした', exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def _draw_root_panel(self, context):
    global _DRAW_SETTINGS
    layout = self.layout
    layout.use_property_split = False
    layout.use_property_decorate = False
    previous_settings = _DRAW_SETTINGS
    settings = get_settings(context)
    _DRAW_SETTINGS = settings
    try:
        if settings is None:
            _label(layout, 'Settings are not available.', '設定を使用できません。', context, icon='ERROR')
            return
        _draw_mode_guard(layout, context)
        section_slots = []
        for show_prop, en, ja, icon, topic in _SECTION_DEFS:
            box, expanded = _draw_section_header(layout, context, settings, show_prop, en, ja, icon=icon, topic=topic)
            section_slots.append((box, expanded, show_prop))

        for box, expanded, show_prop in section_slots:
            if not expanded:
                continue
            drawer = _SECTION_DRAWERS.get(show_prop)
            if drawer is None:
                continue
            try:
                drawer(box, context, settings)
            except Exception as exc:
                warn = box.box()
                warn.alert = True
                warn.label(text=catalog.failure_text('Failed to draw this section', 'このセクションの描画に失敗しました', exc, context), icon='ERROR')
    finally:
        _DRAW_SETTINGS = previous_settings


class _SGSRootPanelMixin:
    def draw_header_preset(self, context):
        _help_button(self.layout, 'suite_overview', context)

    _sgs_logical_editor_keys: tuple[str, ...] = ()
    _smart_tools_manager_tool_key = 'SMART_GEOMETRY'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True

    @classmethod
    def poll(cls, context):
        return _panel_poll(context, cls.bl_space_type, cls._sgs_logical_editor_keys, cls.bl_region_type)

    def draw(self, context):
        _draw_root_panel(self, context)


class VIEW3D_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'VIEW3D_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('VIEW_3D',)


class IMAGE_PT_sgs_image_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Single physical Image Editor root for Image and UV logical editors."""
    bl_idname = 'IMAGE_PT_sgs_image_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('IMAGE_EDITOR', 'UV_EDITOR')


class IMAGE_PT_sgs_uv_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Legacy public class declaration; intentionally not registered as a root."""
    _smart_tools_manager_native_npanel_root = False
    _smart_tools_manager_legacy_unregistered = True
    bl_idname = 'IMAGE_PT_sgs_uv_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('UV_EDITOR',)


class NODE_PT_sgs_shader_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Legacy public class declaration; intentionally not registered as a root."""
    _smart_tools_manager_native_npanel_root = False
    _smart_tools_manager_legacy_unregistered = True
    bl_idname = 'NODE_PT_sgs_shader_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('SHADER_EDITOR',)


class NODE_PT_sgs_compositor_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Legacy public class declaration; intentionally not registered as a root."""
    _smart_tools_manager_native_npanel_root = False
    _smart_tools_manager_legacy_unregistered = True
    bl_idname = 'NODE_PT_sgs_compositor_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('COMPOSITOR',)


class NODE_PT_sgs_geometry_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Single physical Node Editor root for all four logical node editors."""
    bl_idname = 'NODE_PT_sgs_geometry_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = (
        'SHADER_EDITOR',
        'COMPOSITOR',
        'GEOMETRY_NODE_EDITOR',
        'TEXTURE_NODE_EDITOR',
    )


class NODE_PT_sgs_texture_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Legacy public class declaration; intentionally not registered as a root."""
    _smart_tools_manager_native_npanel_root = False
    _smart_tools_manager_legacy_unregistered = True
    bl_idname = 'NODE_PT_sgs_texture_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('TEXTURE_NODE_EDITOR',)


class SEQUENCER_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'SEQUENCER_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('VIDEO_SEQUENCER',)


class CLIP_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'CLIP_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('MOVIE_CLIP_EDITOR',)


class DOPESHEET_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'DOPESHEET_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('DOPE_SHEET',)


class GRAPH_PT_sgs_graph_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Single physical Graph Editor root for Graph and Drivers modes."""
    bl_idname = 'GRAPH_PT_sgs_graph_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('GRAPH_EDITOR', 'DRIVERS')


class GRAPH_PT_sgs_drivers_root(_SGSRootPanelMixin, bpy.types.Panel):
    """Legacy public class declaration; intentionally not registered as a root."""
    _smart_tools_manager_native_npanel_root = False
    _smart_tools_manager_legacy_unregistered = True
    bl_idname = 'GRAPH_PT_sgs_drivers_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('DRIVERS',)


class NLA_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'NLA_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('NLA_EDITOR',)


class TEXT_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'TEXT_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('TEXT_EDITOR',)


class FILEBROWSER_PT_sgs_asset_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'FILEBROWSER_PT_sgs_asset_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('ASSET_BROWSER',)


class FILEBROWSER_PT_sgs_file_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'FILEBROWSER_PT_sgs_file_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('FILE_BROWSER',)


class SPREADSHEET_PT_sgs_root(_SGSRootPanelMixin, bpy.types.Panel):
    bl_idname = 'SPREADSHEET_PT_sgs_root'
    bl_label = 'Smart Geometry'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = _PANEL_CATEGORY
    _sgs_logical_editor_keys = ('SPREADSHEET',)


# Exactly one registered, full-body Suite-owned root per logical editor.
ROOT_PANEL_CLASSES = (
    VIEW3D_PT_sgs_root,
    IMAGE_PT_sgs_image_root,
    NODE_PT_sgs_geometry_root,
    SEQUENCER_PT_sgs_root,
    CLIP_PT_sgs_root,
    DOPESHEET_PT_sgs_root,
    GRAPH_PT_sgs_graph_root,
    NLA_PT_sgs_root,
    TEXT_PT_sgs_root,
    FILEBROWSER_PT_sgs_file_root,
    FILEBROWSER_PT_sgs_asset_root,
    SPREADSHEET_PT_sgs_root,
)


CLASSES = (
    SGS_OT_toggle_ui_section,
    SGS_OT_refresh_diagnostics,
    *ROOT_PANEL_CLASSES,
)
