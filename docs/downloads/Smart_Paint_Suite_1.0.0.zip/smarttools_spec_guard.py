"""Enforce suite-local sidebar and operator registration requirements."""

from contextlib import contextmanager, suppress
import sys

import bpy


def _belongs(module):
    return bool(__package__) and (module == __package__ or module.startswith(__package__ + "."))


def _namespaces():
    for name, module in tuple(sys.modules.items()):
        if _belongs(name) and module is not None:
            yield vars(module)


def _owned_types(base):
    pending = [base]
    seen = {base}
    while pending:
        for cls in pending.pop().__subclasses__():
            if cls not in seen:
                seen.add(cls)
                pending.append(cls)
                if _belongs(cls.__module__):
                    yield cls


def _invisible(_class, _context):
    return False


def _conform_panel(cls):
    region = getattr(cls, "bl_region_type", "")
    browser = getattr(cls, "bl_space_type", "") == "FILE_BROWSER"
    if region != "UI" and not (BROWSER_ROOTS and browser and region == "TOOL_PROPS"):
        return
    name = cls.__name__
    panel = getattr(cls, "bl_idname", "")
    if name in PASSTHROUGH_IDS or panel in PASSTHROUGH_IDS:
        return
    if BROWSER_ROOTS and (browser or name in BROWSER_ROOTS):
        editors = getattr(cls, "_smart_tools_manager_editor_keys", ())
        visible = browser and panel == name and BROWSER_ROOTS.get(name) == (region, editors)
    else:
        visible = name in ROOT_IDS or panel in ROOT_IDS
    if visible:
        cls.bl_label = ROOT_LABEL
        cls.bl_category = ROOT_LABEL
    else:
        cls.poll = classmethod(_invisible)
        cls._smarttools_spec_hidden_sidebar = True


def _conform(cls):
    if not isinstance(cls, type) or not _belongs(cls.__module__):
        return
    if issubclass(cls, bpy.types.Operator):
        cls.bl_options = set(getattr(cls, "bl_options", ()) or ()) - {"REGISTER"}
    elif issubclass(cls, bpy.types.Panel):
        _conform_panel(cls)


def _restore_operator_options(register_class, unregister_class):
    for cls in _owned_types(bpy.types.Operator):
        original = set(getattr(cls, "bl_options", ()) or ())
        if "REGISTER" not in original:
            continue
        cls.bl_options = original - {"REGISTER"}
        if not cls.is_registered:
            continue
        try:
            unregister_class(cls)
            register_class(cls)
        except Exception:
            cls.bl_options = original
            if not cls.is_registered:
                with suppress(Exception):
                    register_class(cls)
            raise


@contextmanager
def _registration_scope():
    register_class = bpy.utils.register_class
    unregister_class = bpy.utils.unregister_class
    changed = []

    def register(cls):
        _conform(cls)
        return register_class(cls)

    try:
        for namespace in _namespaces():
            for name, value in tuple(namespace.items()):
                if value is register_class:
                    namespace[name] = register
                    changed.append((namespace, name))
        bpy.utils.register_class = register
        yield
        _restore_operator_options(register_class, unregister_class)
    finally:
        if bpy.utils.register_class is register:
            bpy.utils.register_class = register_class
        for namespace, name in reversed(changed):
            if namespace.get(name) is register:
                namespace[name] = register_class


def _cleanup():
    timers = bpy.app.timers
    for namespace in _namespaces():
        for callback in tuple(namespace.values()):
            if callable(callback):
                with suppress(Exception):
                    if timers.is_registered(callback):
                        timers.unregister(callback)
    for base in (bpy.types.Panel, bpy.types.Operator):
        for cls in _owned_types(base):
            if cls.is_registered:
                with suppress(Exception):
                    bpy.utils.unregister_class(cls)


def wrap(enable, disable):
    def register():
        with _registration_scope():
            return enable()

    def unregister():
        try:
            return disable()
        finally:
            _cleanup()

    return register, unregister

ROOT_LABEL = 'Smart Paint'
ROOT_IDS = frozenset(('SPS_PT_lightweight_image_editor', 'SPS_PT_lightweight_view3d', 'SPS_PT_root_asset_browser', 'SPS_PT_root_dope_sheet', 'SPS_PT_root_file_browser', 'SPS_PT_root_graph_editor', 'SPS_PT_root_movie_clip_editor', 'SPS_PT_root_nla_editor', 'SPS_PT_root_node_editor', 'SPS_PT_root_spreadsheet', 'SPS_PT_root_text_editor', 'SPS_PT_root_video_sequencer'))
BROWSER_ROOTS = {'SPS_PT_root_file_browser': ('UI', ('FILE_BROWSER',)), 'SPS_PT_root_asset_browser': ('TOOL_PROPS', ('ASSET_BROWSER',))}
PASSTHROUGH_IDS = frozenset(())
