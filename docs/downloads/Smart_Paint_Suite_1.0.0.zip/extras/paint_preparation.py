# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Clean-room, explicit paint preparation tools for Smart Paint.

This candidate intentionally has no handlers, timers, keymaps, modal
operators, workers, or draw callbacks. Every operation is button-driven and
finishes synchronously.
"""


from collections import deque
import math

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    StringProperty,
)


_FACE_MASK_PREFIX = ".sps_face_mask_"
_FACE_MASK_ENUM_CACHE = []


def _numpy():
    import numpy as np

    return np


def _active_mesh(context):
    obj = getattr(context, "active_object", None)
    if obj is None:
        obj = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(obj, "active", None)
    if obj is None or str(getattr(obj, "type", "")) != "MESH":
        return None, None
    mesh = getattr(obj, "data", None)
    return (obj, mesh) if mesh is not None else (None, None)


def _topology_matches(context, obj, mesh) -> bool:
    try:
        evaluated = obj.evaluated_get(context.evaluated_depsgraph_get())
        evaluated_mesh = getattr(evaluated, "data", None)
        return (
            evaluated_mesh is not None
            and len(evaluated_mesh.polygons) == len(mesh.polygons)
            and len(evaluated_mesh.loops) == len(mesh.loops)
        )
    except Exception:
        return False


def _selected_polygons(mesh):
    np = _numpy()
    selected = np.empty(len(mesh.polygons), dtype=np.bool_)
    mesh.polygons.foreach_get("select", selected)
    return selected


def _write_selection(mesh, selected) -> None:
    np = _numpy()
    mesh.polygons.foreach_set("select", np.ascontiguousarray(selected, dtype=np.bool_))
    mesh.use_paint_mask = bool(np.any(selected))
    mesh.update()


def _saved_face_mask_attributes(mesh):
    if mesh is None:
        return []
    result = []
    for attribute in getattr(mesh, "attributes", ()):
        if not str(getattr(attribute, "name", "")).startswith(_FACE_MASK_PREFIX):
            continue
        if str(getattr(attribute, "data_type", "")) != "BOOLEAN":
            continue
        if str(getattr(attribute, "domain", "")) != "FACE":
            continue
        if len(getattr(attribute, "data", ())) != len(mesh.polygons):
            continue
        result.append(attribute)
    return sorted(result, key=lambda item: str(item.name).casefold())


# Mask names are user data: this context has no catalog, so Blender shows them as typed.
_FACE_MASK_NAME_CONTEXT = "SmartPaintFaceMaskName"


def _face_mask_enum_items(_self, context):
    global _FACE_MASK_ENUM_CACHE
    _obj, mesh = _active_mesh(context)
    items = []
    for index, attribute in enumerate(_saved_face_mask_attributes(mesh)):
        display = str(attribute.name)[len(_FACE_MASK_PREFIX) :] or "Mask"
        items.append((str(attribute.name), display, _rpt("保存済みの面ペイントマスク"), index))
    if not items:
        items = [("__NONE__", _rpt("保存マスクなし"), _rpt("保存済みマスクがありません"), 0)]
    _FACE_MASK_ENUM_CACHE = items
    return _FACE_MASK_ENUM_CACHE


def _unique_face_mask_attribute_name(mesh, display_name: str) -> str:
    stem = str(display_name or "Mask").strip() or "Mask"
    stem = stem[:80]
    base = _FACE_MASK_PREFIX + stem
    if mesh.attributes.get(base) is None:
        return base
    for number in range(2, 10000):
        candidate = f"{base}.{number:03d}"
        if mesh.attributes.get(candidate) is None:
            return candidate
    raise RuntimeError("保存マスク名を割り当てられません")


def _mesh_arrays(mesh, *, include_uv: bool):
    np = _numpy()
    polygon_count = len(mesh.polygons)
    loop_count = len(mesh.loops)
    starts = np.empty(polygon_count, dtype=np.int32)
    totals = np.empty(polygon_count, dtype=np.int32)
    loop_edges = np.empty(loop_count, dtype=np.int32)
    loop_vertices = np.empty(loop_count, dtype=np.int32)
    mesh.polygons.foreach_get("loop_start", starts)
    mesh.polygons.foreach_get("loop_total", totals)
    mesh.loops.foreach_get("edge_index", loop_edges)
    mesh.loops.foreach_get("vertex_index", loop_vertices)

    if polygon_count:
        polygon_of_loop = np.repeat(np.arange(polygon_count, dtype=np.int32), totals)
        next_loops = np.arange(loop_count, dtype=np.int32) + 1
        next_loops[starts + totals - 1] = starts
    else:
        polygon_of_loop = np.empty(0, dtype=np.int32)
        next_loops = np.empty(0, dtype=np.int32)

    uv = None
    if include_uv:
        layer = getattr(mesh.uv_layers, "active", None)
        if layer is None:
            raise RuntimeError("UVマップがありません")
        uv = np.empty(loop_count * 2, dtype=np.float64)
        layer.data.foreach_get("uv", uv)
        uv = uv.reshape((-1, 2))
    return starts, totals, loop_edges, loop_vertices, polygon_of_loop, next_loops, uv


def _matching_polygon_pairs(
    loop_edges,
    loop_vertices,
    polygon_of_loop,
    next_loops,
    uv=None,
    *,
    epsilon: float = 1.0e-6,
):
    """Return polygon adjacency pairs, optionally restricted by UV continuity."""
    np = _numpy()
    loop_count = int(loop_edges.size)
    if not loop_count:
        return np.empty((0, 2), dtype=np.int32)

    order = np.argsort(loop_edges, kind="stable")
    sorted_edges = loop_edges[order]
    boundaries = np.flatnonzero(np.r_[True, sorted_edges[1:] != sorted_edges[:-1], True])
    group_sizes = np.diff(boundaries)
    two_starts = boundaries[:-1][group_sizes == 2]
    left = order[two_starts]
    right = order[two_starts + 1]
    valid = polygon_of_loop[left] != polygon_of_loop[right]
    if uv is not None and left.size:
        left_next = next_loops[left]
        right_next = next_loops[right]
        same_order = (
            (loop_vertices[left] == loop_vertices[right])
            & (loop_vertices[left_next] == loop_vertices[right_next])
        )
        reverse_order = (
            (loop_vertices[left] == loop_vertices[right_next])
            & (loop_vertices[left_next] == loop_vertices[right])
        )
        same_uv = (
            np.max(np.abs(uv[left] - uv[right]), axis=1) <= epsilon
        ) & (
            np.max(np.abs(uv[left_next] - uv[right_next]), axis=1) <= epsilon
        )
        reverse_uv = (
            np.max(np.abs(uv[left] - uv[right_next]), axis=1) <= epsilon
        ) & (
            np.max(np.abs(uv[left_next] - uv[right]), axis=1) <= epsilon
        )
        valid &= (same_order & same_uv) | (reverse_order & reverse_uv)
    vector_pairs = np.column_stack((polygon_of_loop[left[valid]], polygon_of_loop[right[valid]])).astype(
        np.int32, copy=False
    )

    exceptional_pairs = []
    for lo, group_size in zip(boundaries[:-1][group_sizes > 2], group_sizes[group_sizes > 2]):
        group = order[int(lo) : int(lo + group_size)]
        for left_offset in range(len(group) - 1):
            left = int(group[left_offset])
            left_polygon = int(polygon_of_loop[left])
            for right_offset in range(left_offset + 1, len(group)):
                right = int(group[right_offset])
                right_polygon = int(polygon_of_loop[right])
                if left_polygon == right_polygon:
                    continue
                if uv is not None:
                    left_next = int(next_loops[left])
                    right_next = int(next_loops[right])
                    left_vertex = int(loop_vertices[left])
                    left_next_vertex = int(loop_vertices[left_next])
                    right_vertex = int(loop_vertices[right])
                    right_next_vertex = int(loop_vertices[right_next])
                    if left_vertex == right_vertex and left_next_vertex == right_next_vertex:
                        matches = (
                            np.max(np.abs(uv[left] - uv[right])) <= epsilon
                            and np.max(np.abs(uv[left_next] - uv[right_next])) <= epsilon
                        )
                    elif left_vertex == right_next_vertex and left_next_vertex == right_vertex:
                        matches = (
                            np.max(np.abs(uv[left] - uv[right_next])) <= epsilon
                            and np.max(np.abs(uv[left_next] - uv[right])) <= epsilon
                        )
                    else:
                        matches = False
                    if not matches:
                        continue
                exceptional_pairs.append((left_polygon, right_polygon))
    if exceptional_pairs:
        extra = np.asarray(exceptional_pairs, dtype=np.int32)
        return np.vstack((vector_pairs, extra)) if len(vector_pairs) else extra
    return vector_pairs if len(vector_pairs) else np.empty((0, 2), dtype=np.int32)


def _adjacent_loop_pairs(loop_edges, polygon_of_loop):
    """Return polygon/edge/loop pairs for every shared mesh edge."""
    np = _numpy()
    if not int(loop_edges.size):
        empty_pairs = np.empty((0, 2), dtype=np.int32)
        empty = np.empty(0, dtype=np.int32)
        return empty_pairs, empty, empty, empty

    order = np.argsort(loop_edges, kind="stable")
    sorted_edges = loop_edges[order]
    boundaries = np.flatnonzero(np.r_[True, sorted_edges[1:] != sorted_edges[:-1], True])
    group_sizes = np.diff(boundaries)

    two_starts = boundaries[:-1][group_sizes == 2]
    left = order[two_starts]
    right = order[two_starts + 1]
    valid = polygon_of_loop[left] != polygon_of_loop[right]
    left = left[valid]
    right = right[valid]
    pairs = np.column_stack((polygon_of_loop[left], polygon_of_loop[right])).astype(
        np.int32, copy=False
    )
    edges = np.ascontiguousarray(loop_edges[left], dtype=np.int32)

    extra_pairs = []
    extra_edges = []
    extra_left = []
    extra_right = []
    for start, size in zip(boundaries[:-1][group_sizes > 2], group_sizes[group_sizes > 2]):
        group = order[int(start) : int(start + size)]
        for left_offset in range(len(group) - 1):
            left_loop = int(group[left_offset])
            left_polygon = int(polygon_of_loop[left_loop])
            for right_offset in range(left_offset + 1, len(group)):
                right_loop = int(group[right_offset])
                right_polygon = int(polygon_of_loop[right_loop])
                if left_polygon == right_polygon:
                    continue
                extra_pairs.append((left_polygon, right_polygon))
                extra_edges.append(int(loop_edges[left_loop]))
                extra_left.append(left_loop)
                extra_right.append(right_loop)
    if extra_pairs:
        extra_pairs_array = np.asarray(extra_pairs, dtype=np.int32)
        pairs = np.vstack((pairs, extra_pairs_array)) if len(pairs) else extra_pairs_array
        edges = np.concatenate((edges, np.asarray(extra_edges, dtype=np.int32)))
        left = np.concatenate((left, np.asarray(extra_left, dtype=np.int32)))
        right = np.concatenate((right, np.asarray(extra_right, dtype=np.int32)))
    return pairs, edges, left, right


def _uv_continuous_pairs(loop_vertices, next_loops, uv, left, right, epsilon=1.0e-6):
    np = _numpy()
    if not len(left):
        return np.empty(0, dtype=np.bool_)
    left_next = next_loops[left]
    right_next = next_loops[right]
    same_order = (
        (loop_vertices[left] == loop_vertices[right])
        & (loop_vertices[left_next] == loop_vertices[right_next])
    )
    reverse_order = (
        (loop_vertices[left] == loop_vertices[right_next])
        & (loop_vertices[left_next] == loop_vertices[right])
    )
    same_uv = (
        np.max(np.abs(uv[left] - uv[right]), axis=1) <= epsilon
    ) & (
        np.max(np.abs(uv[left_next] - uv[right_next]), axis=1) <= epsilon
    )
    reverse_uv = (
        np.max(np.abs(uv[left] - uv[right_next]), axis=1) <= epsilon
    ) & (
        np.max(np.abs(uv[left_next] - uv[right]), axis=1) <= epsilon
    )
    return (same_order & same_uv) | (reverse_order & reverse_uv)


def boundary_polygon_pairs(
    mesh,
    *,
    use_uv=True,
    use_seam=True,
    use_sharp=True,
    use_material=True,
    use_normal=False,
    normal_angle=math.radians(30.0),
):
    """Return traversable face pairs after applying explicit boundaries."""
    np = _numpy()
    arrays = _mesh_arrays(mesh, include_uv=bool(use_uv))
    _, _, loop_edges, loop_vertices, polygon_of_loop, next_loops, uv = arrays
    pairs, edge_indices, left, right = _adjacent_loop_pairs(loop_edges, polygon_of_loop)
    if not len(pairs):
        return pairs
    keep = np.ones(len(pairs), dtype=np.bool_)
    if use_uv:
        keep &= _uv_continuous_pairs(loop_vertices, next_loops, uv, left, right)
    if use_seam:
        flags = np.empty(len(mesh.edges), dtype=np.bool_)
        mesh.edges.foreach_get("use_seam", flags)
        keep &= ~flags[edge_indices]
    if use_sharp:
        flags = np.empty(len(mesh.edges), dtype=np.bool_)
        mesh.edges.foreach_get("use_edge_sharp", flags)
        keep &= ~flags[edge_indices]
    if use_material:
        material_indices = np.empty(len(mesh.polygons), dtype=np.int32)
        mesh.polygons.foreach_get("material_index", material_indices)
        keep &= material_indices[pairs[:, 0]] == material_indices[pairs[:, 1]]
    if use_normal:
        normals = np.empty(len(mesh.polygons) * 3, dtype=np.float64)
        mesh.polygons.foreach_get("normal", normals)
        normals = normals.reshape((-1, 3))
        cosine = np.einsum("ij,ij->i", normals[pairs[:, 0]], normals[pairs[:, 1]])
        keep &= cosine >= math.cos(max(0.0, min(float(normal_angle), math.pi)))
    return np.ascontiguousarray(pairs[keep], dtype=np.int32)


def expand_selection(selected, polygon_pairs):
    """Expand selected polygon seeds through an undirected adjacency graph."""
    np = _numpy()
    selected = np.asarray(selected, dtype=np.bool_).copy()
    polygon_count = int(selected.size)
    if not np.any(selected) or polygon_count == 0 or int(polygon_pairs.size) == 0:
        return selected

    pairs = np.asarray(polygon_pairs, dtype=np.int32).reshape((-1, 2))
    degrees = np.bincount(pairs.reshape(-1), minlength=polygon_count)
    offsets = np.zeros(polygon_count + 1, dtype=np.int64)
    np.cumsum(degrees, out=offsets[1:])
    adjacency_sources = np.concatenate((pairs[:, 0], pairs[:, 1]))
    adjacency_targets = np.concatenate((pairs[:, 1], pairs[:, 0]))
    adjacency_order = np.argsort(adjacency_sources, kind="stable")
    neighbors = np.ascontiguousarray(adjacency_targets[adjacency_order], dtype=np.int32)

    queue = deque(int(index) for index in np.flatnonzero(selected))
    while queue:
        polygon = queue.popleft()
        for neighbor in neighbors[offsets[polygon] : offsets[polygon + 1]]:
            neighbor_i = int(neighbor)
            if selected[neighbor_i]:
                continue
            selected[neighbor_i] = True
            queue.append(neighbor_i)
    return selected


def _expand_mesh_selection(context, *, uv_only: bool):
    obj, mesh = _active_mesh(context)
    if obj is None:
        raise RuntimeError("アクティブなメッシュがありません")
    if str(getattr(obj, "mode", "OBJECT")) == "EDIT":
        raise RuntimeError("テクスチャペイントまたはオブジェクトモードで実行してください")
    selected = _selected_polygons(mesh)
    if not selected.any():
        raise RuntimeError("選択済みの面がありません")
    arrays = _mesh_arrays(mesh, include_uv=uv_only)
    _, _, loop_edges, loop_vertices, polygon_of_loop, next_loops, uv = arrays
    pairs = _matching_polygon_pairs(
        loop_edges,
        loop_vertices,
        polygon_of_loop,
        next_loops,
        uv if uv_only else None,
    )
    expanded = expand_selection(selected, pairs)
    _write_selection(mesh, expanded)
    return int(expanded.sum())


def _expand_boundary_selection(context, **boundaries):
    obj, mesh = _active_mesh(context)
    if obj is None:
        raise RuntimeError("アクティブなメッシュがありません")
    if str(getattr(obj, "mode", "OBJECT")) == "EDIT":
        raise RuntimeError("テクスチャペイントまたはオブジェクトモードで実行してください")
    selected = _selected_polygons(mesh)
    if not selected.any():
        raise RuntimeError("選択済みの面がありません")
    pairs = boundary_polygon_pairs(mesh, **boundaries)
    expanded = expand_selection(selected, pairs)
    _write_selection(mesh, expanded)
    return int(expanded.sum())


def _valid_image(image) -> bool:
    try:
        return image is not None and int(image.size[0]) > 0 and int(image.size[1]) > 0
    except Exception:
        return False


def _active_image(context):
    try:
        if context.area is not None and context.area.type == "IMAGE_EDITOR":
            image = getattr(context.space_data, "image", None)
            if _valid_image(image):
                return image
    except Exception:
        pass
    try:
        image = context.scene.tool_settings.image_paint.canvas
        if _valid_image(image):
            return image
    except Exception:
        pass
    obj = getattr(context, "active_object", None)
    material = getattr(obj, "active_material", None) if obj is not None else None
    nodes = getattr(getattr(material, "node_tree", None), "nodes", ())
    active = getattr(nodes, "active", None)
    image = getattr(active, "image", None)
    return image if _valid_image(image) else None


def create_checker(name: str, size: int, tiles: int, color_a, color_b):
    np = _numpy()
    size = max(64, int(size))
    tiles = max(2, min(int(tiles), size))
    tile_size = max(1, int(math.ceil(size / tiles)))
    coordinates = np.arange(size, dtype=np.int32)
    pattern = ((coordinates[:, None] // tile_size) + (coordinates[None, :] // tile_size)) & 1
    colors = np.asarray((color_a, color_b), dtype=np.float32)
    pixels = colors[pattern].reshape((-1, 4))
    image = bpy.data.images.new(
        str(name or "SPS UV Checker"),
        width=size,
        height=size,
        alpha=True,
        float_buffer=False,
    )
    image.use_fake_user = True
    try:
        image.colorspace_settings.name = "sRGB"
    except Exception:
        pass
    image.pixels.foreach_set(np.ascontiguousarray(pixels, dtype=np.float32).reshape(-1))
    image.update()
    image["sps_mvp_utility_kind"] = "UV_CHECKER"
    image["sps_mvp_checker_tiles"] = int(tiles)
    return image


def measure_texel_density(context):
    np = _numpy()
    obj, mesh = _active_mesh(context)
    if obj is None:
        raise RuntimeError("アクティブなメッシュがありません")
    if str(getattr(obj, "mode", "OBJECT")) == "EDIT":
        raise RuntimeError("テクスチャペイントまたはオブジェクトモードで実行してください")
    if not _topology_matches(context, obj, mesh):
        raise RuntimeError("評価後トポロジーが異なるため計測できません")
    uv_layer = getattr(mesh.uv_layers, "active", None)
    if uv_layer is None:
        raise RuntimeError("UVマップがありません")
    image = _active_image(context)
    if image is None:
        raise RuntimeError("解像度の基準になる画像がありません")

    selected = _selected_polygons(mesh)
    use_selected = bool(selected.any())
    mesh.calc_loop_triangles()
    triangle_count = len(mesh.loop_triangles)
    vertices = np.empty(triangle_count * 3, dtype=np.int32)
    loops = np.empty(triangle_count * 3, dtype=np.int32)
    polygons = np.empty(triangle_count, dtype=np.int32)
    mesh.loop_triangles.foreach_get("vertices", vertices)
    mesh.loop_triangles.foreach_get("loops", loops)
    mesh.loop_triangles.foreach_get("polygon_index", polygons)
    vertices = vertices.reshape((-1, 3))
    loops = loops.reshape((-1, 3))
    if use_selected:
        keep = selected[polygons]
        vertices = vertices[keep]
        loops = loops[keep]
    if not len(vertices):
        raise RuntimeError("計測対象の面がありません")

    coordinates = np.empty(len(mesh.vertices) * 3, dtype=np.float64)
    mesh.vertices.foreach_get("co", coordinates)
    coordinates = coordinates.reshape((-1, 3))
    matrix = np.asarray(obj.matrix_world, dtype=np.float64)
    homogeneous = np.ones((len(coordinates), 4), dtype=np.float64)
    homogeneous[:, :3] = coordinates
    world = homogeneous @ matrix.T
    triangle_world = world[vertices, :3]
    area_m2 = 0.5 * np.linalg.norm(
        np.cross(triangle_world[:, 1] - triangle_world[:, 0], triangle_world[:, 2] - triangle_world[:, 0]),
        axis=1,
    )

    uv = np.empty(len(mesh.loops) * 2, dtype=np.float64)
    uv_layer.data.foreach_get("uv", uv)
    uv = uv.reshape((-1, 2))
    triangle_uv = uv[loops].copy()
    triangle_uv[:, :, 0] *= int(image.size[0])
    triangle_uv[:, :, 1] *= int(image.size[1])
    uv_a = triangle_uv[:, 1] - triangle_uv[:, 0]
    uv_b = triangle_uv[:, 2] - triangle_uv[:, 0]
    area_px = 0.5 * np.abs(uv_a[:, 0] * uv_b[:, 1] - uv_a[:, 1] * uv_b[:, 0])
    total_m2 = float(area_m2.sum())
    total_px = float(area_px.sum())
    if total_m2 <= 1.0e-20:
        raise RuntimeError("面積がゼロのため計測できません")
    pixels_per_meter = math.sqrt(total_px / total_m2)
    coverage = total_px / float(int(image.size[0]) * int(image.size[1]))
    return {
        "pixels_per_meter": pixels_per_meter,
        "coverage": coverage,
        "area_m2": total_m2,
        "pixel_area": total_px,
        "selected_only": use_selected,
        "image": str(image.name),
    }


class _SPSPaintPreparationOperator:
    bl_options = {"UNDO"}

    def _run(self, context):
        raise NotImplementedError

    def execute(self, context):
        try:
            message = self._run(context)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_msg(exc))
            return {"CANCELLED"}
        if message:
            self.report({"INFO"}, _rpt_msg(message))
        return {"FINISHED"}


class SPS_OT_paint_select_uv_island(_SPSPaintPreparationOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_select_uv_island"
    bl_label = "UV島へ拡張"
    bl_description = "選択済み面を起点に、UVが連続する面だけへペイントマスクを拡張します"

    def _run(self, context):
        count = _expand_mesh_selection(context, uv_only=True)
        return _rpt("UV島を {} 面選択しました", count)


class SPS_OT_paint_select_mesh_island(_SPSPaintPreparationOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_select_mesh_island"
    bl_label = "メッシュ島へ拡張"
    bl_description = "選択済み面を起点に、接続されたメッシュ面へペイントマスクを拡張します"

    def _run(self, context):
        count = _expand_mesh_selection(context, uv_only=False)
        return _rpt("メッシュ島を {} 面選択しました", count)


class SPS_OT_paint_select_boundary_region(_SPSPaintPreparationOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_select_boundary_region"
    bl_label = "境界内へ拡張"
    bl_description = "選択面を起点に、指定したUV・エッジ・マテリアル境界を越えずに面マスクを拡張します"

    use_uv: BoolProperty(name="UV不連続", default=True)
    use_seam: BoolProperty(name="シーム", default=True)
    use_sharp: BoolProperty(name="シャープ", default=True)
    use_material: BoolProperty(name="マテリアル", default=True)
    use_normal: BoolProperty(name="法線角", default=False)
    normal_angle: FloatProperty(
        name="最大法線角",
        subtype="ANGLE",
        default=math.radians(30.0),
        min=0.0,
        max=math.pi,
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, _context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "use_uv", toggle=True)
        row.prop(self, "use_seam", toggle=True)
        row = layout.row(align=True)
        row.prop(self, "use_sharp", toggle=True)
        row.prop(self, "use_material", toggle=True)
        row = layout.row(align=True)
        row.prop(self, "use_normal", toggle=True)
        angle = row.row(align=True)
        angle.enabled = bool(self.use_normal)
        angle.prop(self, "normal_angle", text="")

    def _run(self, context):
        count = _expand_boundary_selection(
            context,
            use_uv=bool(self.use_uv),
            use_seam=bool(self.use_seam),
            use_sharp=bool(self.use_sharp),
            use_material=bool(self.use_material),
            use_normal=bool(self.use_normal),
            normal_angle=float(self.normal_angle),
        )
        return _rpt("境界内を {} 面選択しました", count)


class SPS_OT_paint_clear_face_mask(_SPSPaintPreparationOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_clear_face_mask"
    bl_label = "面マスクを解除"
    bl_description = "面選択を解除し、テクスチャペイントの面マスクを無効にします"

    def _run(self, context):
        np = _numpy()
        obj, mesh = _active_mesh(context)
        if mesh is None:
            raise RuntimeError("アクティブなメッシュがありません")
        if str(getattr(obj, "mode", "OBJECT")) == "EDIT":
            raise RuntimeError("テクスチャペイントまたはオブジェクトモードで実行してください")
        _write_selection(mesh, np.zeros(len(mesh.polygons), dtype=np.bool_))
        return "面マスクを解除しました"


class SPS_OT_paint_face_mask_save(bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_face_mask_save"
    bl_label = "面マスクを保存"
    bl_description = "現在の面選択を.blend内の面の属性へ明示保存します"
    bl_options = {"UNDO"}

    name: StringProperty(name="マスク名", default="Mask", maxlen=80)

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        _obj, mesh = _active_mesh(context)
        if mesh is None:
            self.report({"ERROR"}, _rpt("アクティブなメッシュがありません"))
            return {"CANCELLED"}
        selected = _selected_polygons(mesh)
        if not selected.any():
            self.report({"ERROR"}, _rpt("保存する面選択がありません"))
            return {"CANCELLED"}
        attribute = None
        try:
            attribute = mesh.attributes.new(
                name=_unique_face_mask_attribute_name(mesh, self.name),
                type="BOOLEAN",
                domain="FACE",
            )
            attribute.data.foreach_set("value", selected)
            mesh.update()
        except Exception as exc:
            if attribute is not None:
                try:
                    mesh.attributes.remove(attribute)
                except Exception:
                    pass
            self.report({"ERROR"}, _rpt_fail("面マスクを保存できません", exc))
            return {"CANCELLED"}
        display = str(attribute.name)[len(_FACE_MASK_PREFIX) :]
        self.report({"INFO"}, _rpt("面マスクを保存: {}", display))
        return {"FINISHED"}


class SPS_OT_paint_face_mask_load(bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_face_mask_load"
    bl_label = "面マスクを読み込む"
    bl_description = "保存済み面の属性をテクスチャペイント面マスクへ読み込みます"
    bl_options = {"UNDO"}

    mask: EnumProperty(name="保存マスク", items=_face_mask_enum_items, translation_context=_FACE_MASK_NAME_CONTEXT)

    def invoke(self, context, _event):
        if not _saved_face_mask_attributes(_active_mesh(context)[1]):
            self.report({"ERROR"}, _rpt("保存済み面マスクがありません"))
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, _context):
        self.layout.prop(self, "mask", text=_rpt("保存マスク"))

    def execute(self, context):
        np = _numpy()
        _obj, mesh = _active_mesh(context)
        attribute = mesh.attributes.get(str(self.mask)) if mesh is not None else None
        if attribute not in _saved_face_mask_attributes(mesh):
            self.report({"ERROR"}, _rpt("保存済み面マスクを解決できません"))
            return {"CANCELLED"}
        selected = np.empty(len(mesh.polygons), dtype=np.bool_)
        attribute.data.foreach_get("value", selected)
        _write_selection(mesh, selected)
        self.report({"INFO"}, _rpt("面マスクを読み込み: {}", str(attribute.name)[len(_FACE_MASK_PREFIX):]))
        return {"FINISHED"}


class SPS_OT_paint_face_mask_delete(bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_face_mask_delete"
    bl_label = "保存面マスクを削除"
    bl_description = "選択した保存面マスク属性だけを削除します"
    bl_options = {"UNDO"}

    mask: EnumProperty(name="保存マスク", items=_face_mask_enum_items, translation_context=_FACE_MASK_NAME_CONTEXT)

    def invoke(self, context, _event):
        if not _saved_face_mask_attributes(_active_mesh(context)[1]):
            self.report({"ERROR"}, _rpt("保存済み面マスクがありません"))
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, _context):
        self.layout.prop(self, "mask", text=_rpt("保存マスク"))

    def execute(self, context):
        _obj, mesh = _active_mesh(context)
        attribute = mesh.attributes.get(str(self.mask)) if mesh is not None else None
        if attribute not in _saved_face_mask_attributes(mesh):
            self.report({"ERROR"}, _rpt("保存済み面マスクを解決できません"))
            return {"CANCELLED"}
        display = str(attribute.name)[len(_FACE_MASK_PREFIX) :]
        mesh.attributes.remove(attribute)
        mesh.update()
        self.report({"INFO"}, _rpt("保存面マスクを削除: {}", display))
        return {"FINISHED"}


class SPS_OT_image_create_uv_checker(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_create_uv_checker"
    bl_label = "UVチェッカーを作成"
    bl_description = "現在のペイント画像を変更せず、新しいUV確認用画像を作成します"
    bl_options = {"UNDO"}

    size: IntProperty(name="解像度", default=2048, min=64, max=16384)
    tiles: IntProperty(name="タイル数", default=16, min=2, max=256)
    color_a: FloatVectorProperty(
        name="色A", subtype="COLOR", size=4, min=0.0, max=1.0, default=(0.16, 0.16, 0.16, 1.0)
    )
    color_b: FloatVectorProperty(
        name="色B", subtype="COLOR", size=4, min=0.0, max=1.0, default=(0.72, 0.72, 0.72, 1.0)
    )

    def execute(self, context):
        try:
            image = create_checker("SPS UV Checker", self.size, self.tiles, self.color_a, self.color_b)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_msg(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("{} を作成しました", image.name))
        return {"FINISHED"}


class SPS_OT_paint_measure_texel_density(bpy.types.Operator):
    bl_idname = "smart_paint_suite.paint_measure_texel_density"
    bl_label = "テクセル密度を計測"
    bl_description = "UVと画像解像度からテクセル密度を読み取り専用で計測します"
    bl_options = set()

    def execute(self, context):
        try:
            result = measure_texel_density(context)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_msg(exc))
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            _rpt("{:.2f} px/m, UV被覆 {:.2f}%", result['pixels_per_meter'], result['coverage'] * 100.0),
        )
        return {"FINISHED"}


class SPS_PT_paint_preparation(bpy.types.Panel):
    bl_idname = "SPS_PT_paint_preparation"
    bl_label = "ペイント準備"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_view3d"
    bl_order = 12
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)
        column.operator(SPS_OT_paint_select_uv_island.bl_idname, icon="UV")
        column.operator(SPS_OT_paint_select_mesh_island.bl_idname, icon="MESH_DATA")
        column.operator(SPS_OT_paint_select_boundary_region.bl_idname, icon="MOD_MASK")
        column.operator(SPS_OT_paint_clear_face_mask.bl_idname, icon="X")
        row = layout.row(align=True)
        row.operator(SPS_OT_paint_face_mask_save.bl_idname, text="マスク保存", icon="ADD")
        row.operator(SPS_OT_paint_face_mask_load.bl_idname, text="読込", icon="IMPORT")
        row.operator(SPS_OT_paint_face_mask_delete.bl_idname, text="", icon="REMOVE")
        column = layout.column(align=True)
        column.operator(SPS_OT_image_create_uv_checker.bl_idname, icon="IMAGE_DATA")
        column.operator(SPS_OT_paint_measure_texel_density.bl_idname, icon="DRIVER_DISTANCE")


CLASSES = (
    SPS_OT_paint_select_uv_island,
    SPS_OT_paint_select_mesh_island,
    SPS_OT_paint_select_boundary_region,
    SPS_OT_paint_clear_face_mask,
    SPS_OT_paint_face_mask_save,
    SPS_OT_paint_face_mask_load,
    SPS_OT_paint_face_mask_delete,
    SPS_OT_image_create_uv_checker,
    SPS_OT_paint_measure_texel_density,
    SPS_PT_paint_preparation,
)


def register(transaction=None):
    """Compatibility registration routed through the root journal."""
    if transaction is None or not hasattr(transaction, "register_class"):
        raise RuntimeError("Smart Paint paint-preparation classes require the root transaction")
    for cls in CLASSES:
        transaction.register_class(cls)
    return True


def unregister():
    """Partial live RNA teardown is intentionally unsupported."""
    raise RuntimeError("Smart Paint classes are released only by root unregister()")
