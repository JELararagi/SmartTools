# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Clean-room, explicit image utilities for Smart Paint T3 prototyping."""


import time

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty


_SPLIT_TOKEN_KEY = "sps_mvp_channel_split_token"
_CHANNEL_KEY = "sps_mvp_channel_split_channel"
_SOURCE_KEY = "sps_mvp_utility_source"
_KIND_KEY = "sps_mvp_utility_kind"
_SCENE_TOKEN_KEY = "sps_mvp_latest_channel_split_token"
_SCENE_OUTPUT_KEY = "sps_mvp_latest_utility_image"
_LAST_SPLIT_TOKEN = ""
_LAST_OUTPUT_NAME = ""


def _numpy():
    import numpy as np

    return np


def _nearest_columns(np, column_sq, window: int):
    """For each pixel, the column minimising column_sq + dx * dx, row by row.

    The leftmost best column never moves left as x grows, so columns are solved
    halving the step, each searching only between its solved neighbours. Every
    best column is within ``window`` because x itself costs at most window ** 2.
    """
    count, width = column_sq.shape
    costs = column_sq.astype(np.int64)
    columns = np.zeros((count, width), dtype=np.int64)
    values = np.zeros((count, width), dtype=np.int64)
    step = 1
    while step * 2 <= width:
        step *= 2
    while step >= 1:
        xs = np.arange(step - 1, width, step * 2)
        low = np.zeros((count, xs.size), dtype=np.int64)
        high = np.full((count, xs.size), width - 1, dtype=np.int64)
        low[:, 1:] = columns[:, xs[1:] - step]
        solved = xs + step < width
        high[:, solved] = columns[:, xs[solved] + step]
        low = np.maximum(low, xs - window).ravel()
        high = np.minimum(high, xs + window).ravel()
        sizes = high - low + 1
        starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
        row = np.repeat(np.repeat(np.arange(count), xs.size), sizes)
        x = np.repeat(np.tile(xs, count), sizes)
        candidate = np.arange(int(sizes.sum())) - np.repeat(starts, sizes) + np.repeat(low, sizes)
        # Value first, then column: the minimum is the leftmost best column.
        keys = (costs[row, candidate] + (x - candidate) ** 2) * width + candidate
        found = np.minimum.reduceat(keys, starts).reshape(count, xs.size)
        columns[:, xs] = found % width
        values[:, xs] = found // width
        step //= 2
    return values, columns


def _nearest_within(seeds, reach: int, progress=None):
    """Squared distance and index of the nearest seed pixel, exact up to ``reach``.

    Pixels farther than ``reach`` get a squared distance above ``reach * reach``
    and an index that must not be used.
    """
    np = _numpy()
    seeds = np.asarray(seeds, dtype=bool)
    height, width = seeds.shape
    reach = max(1, int(reach))
    far = height + reach + 2
    rows = np.arange(height, dtype=np.int32)[:, None]
    above = np.maximum.accumulate(np.where(seeds, rows, -far), axis=0)
    below = np.minimum.accumulate(np.where(seeds, rows, far)[::-1], axis=0)[::-1]
    use_above = (rows - above) <= (below - rows)
    column_y = np.where(use_above, above, below)
    column_d = np.minimum(np.abs(column_y - rows), reach + 1)
    column_sq = column_d * column_d
    best = column_sq.copy()
    nearest_x = np.broadcast_to(np.arange(width, dtype=np.int32)[None, :], seeds.shape).copy()
    # Rows without a seed in range keep their defaults. Rows are solved in small
    # batches so a large image never builds one huge candidate array.
    solve_rows = np.nonzero(np.any(column_d <= reach, axis=1))[0]
    for start in range(0, solve_rows.size, 128):
        if progress is not None:
            progress(start / solve_rows.size)
        batch = solve_rows[start : start + 128]
        best[batch], nearest_x[batch] = _nearest_columns(np, column_sq[batch], reach + 1)
    nearest_y = np.take_along_axis(column_y, nearest_x, axis=1)
    return best, nearest_y, nearest_x


def _canvas(context):
    try:
        return context.scene.tool_settings.image_paint.canvas
    except Exception:
        return None


def _valid_image(image) -> bool:
    try:
        return (
            image is not None
            and str(getattr(image, "source", "") or "") != "TILED"
            and int(image.size[0]) > 0
            and int(image.size[1]) > 0
        )
    except Exception:
        return False


def _image_by_name(name: str):
    return bpy.data.images.get(str(name or "").strip())


def _latest_output(context):
    names = [_LAST_OUTPUT_NAME]
    try:
        names.append(str(context.scene.get(_SCENE_OUTPUT_KEY, "") or ""))
    except Exception:
        pass
    for name in names:
        image = _image_by_name(name)
        if _valid_image(image):
            return image
    return None


def _resolve_source(context, explicit: str = "", *, prefer_latest: bool = False):
    explicit_name = str(explicit or "").strip()
    if explicit_name:
        image = _image_by_name(explicit_name)
        return image if _valid_image(image) else None
    try:
        if getattr(context, "area", None) is not None and context.area.type == "IMAGE_EDITOR":
            image = getattr(getattr(context, "space_data", None), "image", None)
            if _valid_image(image) and image is not _canvas(context):
                return image
    except Exception:
        pass
    if prefer_latest:
        image = _latest_output(context)
        if _valid_image(image):
            return image
    image = _canvas(context)
    return image if _valid_image(image) else None


def _copy_colorspace(source, output, *, non_color: bool = False) -> None:
    try:
        output.colorspace_settings.name = (
            "Non-Color" if non_color else str(source.colorspace_settings.name)
        )
    except Exception:
        pass
    try:
        output.alpha_mode = "STRAIGHT"
    except Exception:
        pass


def _new_output(source, name: str, width: int, height: int, *, non_color: bool = False):
    image = bpy.data.images.new(
        str(name or "SPS Utility"),
        width=max(1, int(width)),
        height=max(1, int(height)),
        alpha=True,
        float_buffer=False,
    )
    image.use_fake_user = True
    _copy_colorspace(source, image, non_color=non_color)
    return image


def _read_pixels(image):
    np = _numpy()
    width, height = int(image.size[0]), int(image.size[1])
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    return pixels, width, height


def _write_pixels(image, pixels) -> None:
    np = _numpy()
    image.pixels.foreach_set(np.ascontiguousarray(pixels, dtype=np.float32).reshape(-1))
    image.update()


def _new_token(source) -> str:
    return f"{int(source.as_pointer()):x}-{time.time_ns():x}"


def _remember(context, image, *, token: str = "") -> None:
    global _LAST_OUTPUT_NAME, _LAST_SPLIT_TOKEN
    _LAST_OUTPUT_NAME = str(image.name)
    if token:
        _LAST_SPLIT_TOKEN = str(token)
    try:
        context.scene[_SCENE_OUTPUT_KEY] = str(image.name)
        if token:
            context.scene[_SCENE_TOKEN_KEY] = str(token)
    except Exception:
        pass


def _split_token(context) -> str:
    if _LAST_SPLIT_TOKEN:
        return str(_LAST_SPLIT_TOKEN)
    try:
        return str(context.scene.get(_SCENE_TOKEN_KEY, "") or "")
    except Exception:
        return ""


def split_channels(context, source):
    np = _numpy()
    source_pixels, width, height = _read_pixels(source)
    source_view = source_pixels.reshape((-1, 4))
    output_pixels = np.empty_like(source_pixels)
    output_view = output_pixels.reshape((-1, 4))
    token = _new_token(source)
    created = []
    try:
        for channel_index, channel_name in enumerate("RGBA"):
            values = source_view[:, channel_index]
            output_view[:, 0] = values
            output_view[:, 1] = values
            output_view[:, 2] = values
            output_view[:, 3] = 1.0
            image = _new_output(
                source,
                f"{source.name}_{channel_name}",
                width,
                height,
                non_color=True,
            )
            image[_SPLIT_TOKEN_KEY] = token
            image[_CHANNEL_KEY] = channel_name
            image[_SOURCE_KEY] = str(source.name)
            image[_KIND_KEY] = "CHANNEL_SPLIT"
            _write_pixels(image, output_pixels)
            created.append(image)
    except Exception:
        for image in reversed(created):
            try:
                bpy.data.images.remove(image)
            except Exception:
                pass
        raise
    _remember(context, created[-1], token=token)
    return created


def _split_set(context):
    token = _split_token(context)
    if not token:
        raise RuntimeError("no channel split set is available")
    result = {}
    for image in bpy.data.images:
        try:
            if str(image.get(_SPLIT_TOKEN_KEY, "") or "") != token:
                continue
            channel = str(image.get(_CHANNEL_KEY, "") or "").upper()
            if channel not in {"R", "G", "B", "A"} or channel in result:
                raise RuntimeError("ambiguous channel split set")
            result[channel] = image
        except RuntimeError:
            raise
        except Exception:
            continue
    if set(result) != set("RGBA"):
        raise RuntimeError("channel split set is incomplete")
    sizes = {(int(image.size[0]), int(image.size[1])) for image in result.values()}
    if len(sizes) != 1:
        raise RuntimeError("channel split dimensions do not match")
    return token, result


def pack_channels(context):
    np = _numpy()
    token, split = _split_set(context)
    source = split["R"]
    width, height = int(source.size[0]), int(source.size[1])
    pixel_count = width * height
    packed = np.empty(pixel_count * 4, dtype=np.float32)
    scratch = np.empty_like(packed)
    for channel_index, channel_name in enumerate("RGBA"):
        split[channel_name].pixels.foreach_get(scratch)
        packed[channel_index::4] = scratch[0::4]
    source_name = str(source.get(_SOURCE_KEY, "") or "SPS")
    image = _new_output(source, f"{source_name}_PACKED", width, height)
    try:
        image[_KIND_KEY] = "CHANNEL_PACK"
        image[_SOURCE_KEY] = source_name
        image[_SPLIT_TOKEN_KEY] = token
        _write_pixels(image, packed)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


def mirror_image(context, source, axis: str):
    np = _numpy()
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    axis_key = str(axis or "HORIZONTAL").upper()
    if axis_key == "HORIZONTAL":
        transformed = np.ascontiguousarray(view[:, ::-1, :])
        suffix = "MIRROR_X"
    elif axis_key == "VERTICAL":
        transformed = np.ascontiguousarray(view[::-1, :, :])
        suffix = "MIRROR_Y"
    else:
        raise ValueError(f"unsupported mirror axis: {axis_key}")
    image = _new_output(source, f"{source.name}_{suffix}", width, height)
    try:
        image[_KIND_KEY] = "MIRROR"
        image[_SOURCE_KEY] = str(source.name)
        _write_pixels(image, transformed)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


def rotate_image(context, source, direction: str):
    np = _numpy()
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    direction_key = str(direction or "CLOCKWISE").upper()
    if direction_key == "CLOCKWISE":
        transformed = np.ascontiguousarray(np.rot90(view, k=1))
        suffix = "ROTATE_CW"
    elif direction_key == "COUNTERCLOCKWISE":
        transformed = np.ascontiguousarray(np.rot90(view, k=3))
        suffix = "ROTATE_CCW"
    elif direction_key == "HALF":
        transformed = np.ascontiguousarray(np.rot90(view, k=2))
        suffix = "ROTATE_180"
    else:
        raise ValueError(f"unsupported rotation: {direction_key}")
    output_height, output_width = int(transformed.shape[0]), int(transformed.shape[1])
    image = _new_output(source, f"{source.name}_{suffix}", output_width, output_height)
    try:
        image[_KIND_KEY] = "ROTATE"
        image[_SOURCE_KEY] = str(source.name)
        _write_pixels(image, transformed)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


class _ProgressCursor:
    """Blender's progress cursor around a long pixel computation."""

    def __init__(self, context, parts: int = 1):
        self.window_manager = context.window_manager
        self.parts = max(1, int(parts))
        self.part = 0

    def __enter__(self):
        self.window_manager.progress_begin(0.0, 1.0)
        return self

    def __exit__(self, *_exc):
        self.window_manager.progress_end()
        return False

    def __call__(self, fraction: float) -> None:
        self.window_manager.progress_update((self.part + fraction) / self.parts)


def _dilate_transparent_rgb_inplace(
    rgba,
    *,
    radius: int,
    alpha_threshold: float,
    block_rows: int = 256,
    progress=None,
) -> int:
    """Extend RGB into low-alpha pixels without changing any alpha values."""
    np = _numpy()
    source = np.asarray(rgba, dtype=np.float32)
    if source.ndim != 3 or source.shape[2] != 4:
        raise ValueError("RGBA input must have shape (height, width, 4)")
    radius = max(0, int(radius))
    if radius == 0:
        return 0
    occupied = source[..., 3] > float(alpha_threshold)
    if not bool(np.any(occupied)):
        return 0

    empty = ~occupied
    best, all_nearest_y, all_nearest_x = _nearest_within(occupied, radius, progress)
    height = int(source.shape[0])
    radius_sq = int(radius * radius)
    block_rows = max(1, int(block_rows))
    changed = 0
    for y0 in range(0, height, block_rows):
        y1 = min(height, y0 + block_rows)
        nearest_y = all_nearest_y[y0:y1]
        nearest_x = all_nearest_x[y0:y1]
        target = empty[y0:y1] & (best[y0:y1] <= radius_sq)
        count = int(np.count_nonzero(target))
        if count:
            block = source[y0:y1]
            block[target, :3] = source[nearest_y[target], nearest_x[target], :3]
            changed += count
    return changed


def edge_pad_image(
    context,
    source,
    *,
    radius: int = 16,
    alpha_threshold: float = 1.0 / 255.0,
):
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    with _ProgressCursor(context) as progress:
        changed = _dilate_transparent_rgb_inplace(
            view,
            radius=max(1, min(64, int(radius))),
            alpha_threshold=max(0.0, min(1.0, float(alpha_threshold))),
            progress=progress,
        )
    if changed <= 0:
        raise RuntimeError("no transparent edge pixels are available for padding")
    image = _new_output(
        source,
        f"{source.name}_PAD_{max(1, min(64, int(radius)))}px",
        width,
        height,
    )
    try:
        image[_KIND_KEY] = "EDGE_PADDING"
        image[_SOURCE_KEY] = str(source.name)
        image["sps_mvp_edge_padding_radius"] = max(1, min(64, int(radius)))
        image["sps_mvp_edge_padding_changed_pixels"] = int(changed)
        _write_pixels(image, view)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image, changed


def _smoothstep(values):
    return values * values * (3.0 - (2.0 * values))


def _blend_tile_edges_inplace(
    rgba,
    *,
    overlap: int,
    horizontal: bool,
    vertical: bool,
) -> None:
    np = _numpy()
    image = np.asarray(rgba, dtype=np.float32)
    if image.ndim != 3 or image.shape[2] != 4:
        raise ValueError("RGBA input must have shape (height, width, 4)")
    height, width = int(image.shape[0]), int(image.shape[1])
    overlap = max(1, min(int(overlap), width // 2, height // 2))
    if overlap == 1:
        weight = np.zeros((1,), dtype=np.float32)
    else:
        weight = _smoothstep(
            np.linspace(0.0, 1.0, overlap, dtype=np.float32)
        )

    if horizontal:
        left = np.array(image[:, :overlap, :], copy=True)
        right = np.array(image[:, -overlap:, :][:, ::-1, :], copy=True)
        average = (left + right) * 0.5
        blend = weight[None, :, None]
        image[:, :overlap, :] = average * (1.0 - blend) + left * blend
        image[:, -overlap:, :] = (
            average * (1.0 - blend) + right * blend
        )[:, ::-1, :]

    if vertical:
        bottom = np.array(image[:overlap, :, :], copy=True)
        top = np.array(image[-overlap:, :, :][::-1, :, :], copy=True)
        average = (bottom + top) * 0.5
        blend = weight[:, None, None]
        image[:overlap, :, :] = average * (1.0 - blend) + bottom * blend
        image[-overlap:, :, :] = (
            average * (1.0 - blend) + top * blend
        )[::-1, :, :]


def blend_tile_edges_image(
    context,
    source,
    *,
    overlap: int = 64,
    direction: str = "BOTH",
):
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    overlap = max(1, min(int(overlap), 256, width // 2, height // 2))
    direction_key = str(direction or "BOTH").upper()
    if direction_key not in {"BOTH", "HORIZONTAL", "VERTICAL"}:
        raise ValueError(f"unsupported tile blend direction: {direction_key}")
    _blend_tile_edges_inplace(
        view,
        overlap=overlap,
        horizontal=direction_key in {"BOTH", "HORIZONTAL"},
        vertical=direction_key in {"BOTH", "VERTICAL"},
    )
    image = _new_output(
        source,
        f"{source.name}_TILE_{overlap}px",
        width,
        height,
    )
    try:
        image[_KIND_KEY] = "TILE_EDGE_BLEND"
        image[_SOURCE_KEY] = str(source.name)
        image["sps_mvp_tile_blend_overlap"] = int(overlap)
        image["sps_mvp_tile_blend_direction"] = direction_key
        _write_pixels(image, view)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


def _convert_map_inplace(rgba, mode: str) -> None:
    np = _numpy()
    image = np.asarray(rgba, dtype=np.float32)
    if image.ndim != 3 or image.shape[2] != 4:
        raise ValueError("RGBA input must have shape (height, width, 4)")
    mode_key = str(mode or "").upper()
    if mode_key == "NORMAL_Y_FLIP":
        image[..., 1] = 1.0 - image[..., 1]
    elif mode_key == "ROUGHNESS_SMOOTHNESS":
        image[..., :3] = 1.0 - image[..., :3]
    else:
        raise ValueError(f"unsupported map conversion: {mode_key}")


def convert_map_image(context, source, *, mode: str):
    colorspace = str(getattr(source.colorspace_settings, "name", "") or "")
    if colorspace != "Non-Color":
        raise RuntimeError("map conversion requires Non-Color input")
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    mode_key = str(mode or "").upper()
    _convert_map_inplace(view, mode_key)
    suffix = {
        "NORMAL_Y_FLIP": "NORMAL_Y_FLIP",
        "ROUGHNESS_SMOOTHNESS": "ROUGHNESS_SMOOTHNESS",
    }.get(mode_key)
    if suffix is None:
        raise ValueError(f"unsupported map conversion: {mode_key}")
    image = _new_output(
        source,
        f"{source.name}_{suffix}",
        width,
        height,
        non_color=True,
    )
    try:
        image[_KIND_KEY] = "MAP_CONVERSION"
        image[_SOURCE_KEY] = str(source.name)
        image["sps_mvp_map_conversion_mode"] = mode_key
        _write_pixels(image, view)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


def _generate_sdf_values(mask, *, spread: float, progress=None):
    np = _numpy()
    inside = np.asarray(mask, dtype=bool)
    if inside.ndim != 2:
        raise ValueError("SDF mask must be two-dimensional")
    if not bool(np.any(inside)) or bool(np.all(inside)):
        raise RuntimeError("SDF source must contain both inside and outside pixels")
    spread = max(1.0, float(spread))
    reach = int(np.ceil(spread)) + 1
    signed = np.sqrt(_nearest_within(~inside, reach, progress)[0].astype(np.float32))
    if progress is not None:
        progress.part = 1
    signed -= np.sqrt(_nearest_within(inside, reach, progress)[0].astype(np.float32))
    values = np.clip(0.5 + (signed / (2.0 * spread)), 0.0, 1.0)
    return values.astype(np.float32)


def generate_sdf_image(
    context,
    source,
    *,
    source_mode: str = "ALPHA",
    threshold: float = 0.5,
    spread: int = 64,
):
    np = _numpy()
    pixels, width, height = _read_pixels(source)
    view = pixels.reshape((height, width, 4))
    source_key = str(source_mode or "ALPHA").upper()
    threshold = max(0.0, min(1.0, float(threshold)))
    if source_key == "ALPHA":
        mask = view[..., 3] > threshold
    elif source_key == "LUMINANCE":
        luminance = (
            (view[..., 0] * np.float32(0.2126))
            + (view[..., 1] * np.float32(0.7152))
            + (view[..., 2] * np.float32(0.0722))
        )
        mask = luminance > threshold
    else:
        raise ValueError(f"unsupported SDF source mode: {source_key}")
    spread = max(1, min(256, int(spread)))
    with _ProgressCursor(context, 2) as progress:
        values = _generate_sdf_values(mask, spread=spread, progress=progress)
    view[..., 0] = values
    view[..., 1] = values
    view[..., 2] = values
    view[..., 3] = 1.0
    image = _new_output(
        source,
        f"{source.name}_SDF_{spread}px",
        width,
        height,
        non_color=True,
    )
    try:
        image[_KIND_KEY] = "SIGNED_DISTANCE_FIELD"
        image[_SOURCE_KEY] = str(source.name)
        image["sps_mvp_sdf_source_mode"] = source_key
        image["sps_mvp_sdf_threshold"] = float(threshold)
        image["sps_mvp_sdf_spread"] = int(spread)
        _write_pixels(image, view)
    except Exception:
        bpy.data.images.remove(image)
        raise
    _remember(context, image)
    return image


class SPS_OT_image_split_channels(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_split_channels"
    bl_label = "チャンネル分解"
    bl_description = "画像をRGBAの新規グレースケール画像へ分解します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")

    def execute(self, context):
        source = _resolve_source(context, self.source_image)
        if source is None:
            self.report({"ERROR"}, _rpt("分解する画像がありません"))
            return {"CANCELLED"}
        try:
            outputs = split_channels(context, source)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("チャンネル分解に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("{}: {}チャンネル", source.name, len(outputs)))
        return {"FINISHED"}


class SPS_OT_image_pack_channels(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_pack_channels"
    bl_label = "チャンネル合成"
    bl_description = "直前に分解したRGBA画像から新規パック画像を作成します"
    bl_options = set()

    def execute(self, context):
        try:
            output = pack_channels(context)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("チャンネル合成に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("パック画像: {}", output.name))
        return {"FINISHED"}


class SPS_OT_image_mirror(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_mirror"
    bl_label = "画像を反転"
    bl_description = "元画像を変更せず反転した新規画像を作成します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    axis: EnumProperty(
        name="方向",
        items=(
            ("HORIZONTAL", "左右", "画像のX方向を反転"),
            ("VERTICAL", "上下", "画像のY方向を反転"),
        ),
        default="HORIZONTAL",
    )

    def execute(self, context):
        source = _resolve_source(context, self.source_image, prefer_latest=True)
        if source is None:
            self.report({"ERROR"}, _rpt("反転する画像がありません"))
            return {"CANCELLED"}
        try:
            output = mirror_image(context, source, self.axis)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("画像反転に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("反転画像: {}", output.name))
        return {"FINISHED"}


class SPS_OT_image_rotate(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_rotate"
    bl_label = "画像を回転"
    bl_description = "元画像を変更せず90度または180度回転した新規画像を作成します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    direction: EnumProperty(
        name="方向",
        items=(
            ("CLOCKWISE", "右90°", "表示上で時計回りに90度回転"),
            ("COUNTERCLOCKWISE", "左90°", "表示上で反時計回りに90度回転"),
            ("HALF", "180°", "180度回転"),
        ),
        default="CLOCKWISE",
    )

    def execute(self, context):
        source = _resolve_source(context, self.source_image, prefer_latest=True)
        if source is None:
            self.report({"ERROR"}, _rpt("回転する画像がありません"))
            return {"CANCELLED"}
        try:
            output = rotate_image(context, source, self.direction)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("画像回転に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("回転画像: {}", output.name))
        return {"FINISHED"}


class SPS_OT_image_edge_padding(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_edge_padding"
    bl_label = "エッジパディング"
    bl_description = "透明部分へ近傍色を延長した新規画像を作成します。元画像とアルファは変更しません"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    radius: IntProperty(
        name="半径",
        description="透明領域へ色を延長する最大距離（ピクセル）",
        default=16,
        min=1,
        max=64,
    )
    alpha_threshold: FloatProperty(
        name="透明しきい値",
        description="このアルファ値以下を色延長の対象にします",
        default=1.0 / 255.0,
        min=0.0,
        max=1.0,
        precision=4,
        subtype="FACTOR",
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "radius")
        layout.prop(self, "alpha_threshold")

    def execute(self, context):
        source = _resolve_source(context, self.source_image)
        if source is None:
            self.report({"ERROR"}, _rpt("パディングする画像がありません"))
            return {"CANCELLED"}
        try:
            output, changed = edge_pad_image(
                context,
                source,
                radius=self.radius,
                alpha_threshold=self.alpha_threshold,
            )
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("エッジパディングに失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"{output.name}: {changed:,} px")
        return {"FINISHED"}


class SPS_OT_image_blend_tile_edges(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_blend_tile_edges"
    bl_label = "タイル境界ブレンド"
    bl_description = "反対側の画像端を対称ブレンドした新規タイル画像を作成します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    overlap: IntProperty(
        name="ブレンド幅",
        description="画像端から内側へブレンドする幅（ピクセル）",
        default=64,
        min=1,
        max=256,
    )
    direction: EnumProperty(
        name="方向",
        items=(
            ("BOTH", "左右 + 上下", "左右端と上下端をブレンド"),
            ("HORIZONTAL", "左右のみ", "左右端だけをブレンド"),
            ("VERTICAL", "上下のみ", "上下端だけをブレンド"),
        ),
        default="BOTH",
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "direction", expand=True)
        layout.prop(self, "overlap")

    def execute(self, context):
        source = _resolve_source(context, self.source_image)
        if source is None:
            self.report({"ERROR"}, _rpt("境界ブレンドする画像がありません"))
            return {"CANCELLED"}
        try:
            output = blend_tile_edges_image(
                context,
                source,
                overlap=self.overlap,
                direction=self.direction,
            )
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("タイル境界ブレンドに失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("タイル画像: {}", output.name))
        return {"FINISHED"}


class SPS_OT_image_convert_map(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_convert_map"
    bl_label = "マップ変換"
    bl_description = "Non-Color画像をノーマルマップ規格またはラフネス/スムースネス間で変換します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    mode: EnumProperty(
        name="変換",
        items=(
            (
                "NORMAL_Y_FLIP",
                "Normal OpenGL ↔ DirectX",
                "ノーマルマップのG(Y)チャンネルを反転",
            ),
            (
                "ROUGHNESS_SMOOTHNESS",
                "Roughness ↔ Smoothness",
                "RGBを反転してラフネスとスムースネスを相互変換",
            ),
        ),
        default="NORMAL_Y_FLIP",
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "mode", expand=True)

    def execute(self, context):
        source = _resolve_source(context, self.source_image)
        if source is None:
            self.report({"ERROR"}, _rpt("変換する画像がありません"))
            return {"CANCELLED"}
        try:
            output = convert_map_image(context, source, mode=self.mode)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("マップ変換に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("変換画像: {}", output.name))
        return {"FINISHED"}


class SPS_OT_image_generate_sdf(bpy.types.Operator):
    bl_idname = "smart_paint_suite.image_generate_sdf"
    bl_label = "SDF生成"
    bl_description = "アルファまたは輝度境界から符号付き距離場の新規画像を作成します"
    bl_options = set()

    source_image: StringProperty(name="Source Image", default="")
    source_mode: EnumProperty(
        name="境界ソース",
        items=(
            ("ALPHA", "Alpha", "アルファをしきい値判定"),
            ("LUMINANCE", "輝度", "RGBの線形輝度をしきい値判定"),
        ),
        default="ALPHA",
    )
    threshold: FloatProperty(
        name="しきい値",
        default=0.5,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    spread: IntProperty(
        name="距離幅",
        description="0から1へ正規化する内外距離（ピクセル）",
        default=64,
        min=1,
        max=256,
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "source_mode", expand=True)
        layout.prop(self, "threshold")
        layout.prop(self, "spread")

    def execute(self, context):
        source = _resolve_source(context, self.source_image)
        if source is None:
            self.report({"ERROR"}, _rpt("SDFを生成する画像がありません"))
            return {"CANCELLED"}
        try:
            output = generate_sdf_image(
                context,
                source,
                source_mode=self.source_mode,
                threshold=self.threshold,
                spread=self.spread,
            )
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("SDF生成に失敗", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("SDF画像: {}", output.name))
        return {"FINISHED"}


class SPS_PT_image_utilities_image_editor(bpy.types.Panel):
    bl_idname = "SPS_PT_image_utilities_image_editor"
    bl_label = "画像ユーティリティ"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_image_editor"
    bl_order = 12
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator(
            SPS_OT_image_split_channels.bl_idname,
            text="RGBA分解",
            icon="IMAGE_DATA",
        )
        row.operator(
            SPS_OT_image_pack_channels.bl_idname,
            text="RGBA合成",
            icon="NODE_COMPOSITING",
        )
        row = layout.row(align=True)
        left_right = row.operator(
            SPS_OT_image_mirror.bl_idname,
            text="左右",
            icon="ARROW_LEFTRIGHT",
        )
        left_right.axis = "HORIZONTAL"
        up_down = row.operator(
            SPS_OT_image_mirror.bl_idname,
            text="上下",
            icon="SORT_ASC",
        )
        up_down.axis = "VERTICAL"
        row = layout.row(align=True)
        clockwise = row.operator(
            SPS_OT_image_rotate.bl_idname,
            text="右90°",
            icon="LOOP_FORWARDS",
        )
        clockwise.direction = "CLOCKWISE"
        counterclockwise = row.operator(
            SPS_OT_image_rotate.bl_idname,
            text="左90°",
            icon="LOOP_BACK",
        )
        counterclockwise.direction = "COUNTERCLOCKWISE"
        half = row.operator(SPS_OT_image_rotate.bl_idname, text="180°")
        half.direction = "HALF"
        layout.operator(
            SPS_OT_image_edge_padding.bl_idname,
            text="エッジパディング...",
            icon="MOD_EXPLODE",
        )
        layout.operator(
            SPS_OT_image_blend_tile_edges.bl_idname,
            text="タイル境界ブレンド...",
            icon="MOD_WAVE",
        )
        layout.operator(
            SPS_OT_image_convert_map.bl_idname,
            text="マップ変換...",
            icon="NORMALS_FACE",
        )
        layout.operator(
            SPS_OT_image_generate_sdf.bl_idname,
            text="SDF生成...",
            icon="OUTLINER_DATA_FONT",
        )
        latest = _latest_output(context)
        if latest is not None:
            layout.label(text=str(latest.name), icon="IMAGE_DATA", translate=False)


OPERATOR_CLASSES = (
    SPS_OT_image_split_channels,
    SPS_OT_image_pack_channels,
    SPS_OT_image_mirror,
    SPS_OT_image_rotate,
    SPS_OT_image_edge_padding,
    SPS_OT_image_blend_tile_edges,
    SPS_OT_image_convert_map,
    SPS_OT_image_generate_sdf,
)
CLASSES = (*OPERATOR_CLASSES, SPS_PT_image_utilities_image_editor)


__all__ = (
    "CLASSES",
    "OPERATOR_CLASSES",
    "split_channels",
    "pack_channels",
    "mirror_image",
    "rotate_image",
    "edge_pad_image",
    "blend_tile_edges_image",
    "convert_map_image",
    "generate_sdf_image",
)
