# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read interchange swatches and rank visible image colors."""

from colorsys import hsv_to_rgb, rgb_to_hsv


_HUE_ROTATION_DEGREES = {
    "COMPLEMENTARY": (0, 180),
    "ANALOGOUS": (-30, 0, 30),
    "TRIADIC": (0, 120, 240),
    "SPLIT_COMPLEMENTARY": (0, 150, 210),
}


def _unit(value):
    return min(1.0, max(0.0, float(value)))


def _linear(value):
    if value > 0.04045:
        return ((value + 0.055) / 1.055) ** 2.4
    return value / 12.92


def _encoded(value):
    if value > 0.0031308:
        return 1.055 * value ** (1 / 2.4) - 0.055
    return 12.92 * value


def srgb8_to_linear(rgb):
    red, green, blue = rgb
    return tuple(_linear(_unit(int(component) / 255)) for component in (red, green, blue))


def harmony_colors_linear(rgb, mode):
    base = tuple(map(_unit, rgb))
    hue, saturation, brightness = rgb_to_hsv(*map(_encoded, base))
    if saturation <= 1e-4:
        raise ValueError("color harmony requires visible saturation")
    key = str(mode or "").upper()
    if key not in _HUE_ROTATION_DEGREES:
        raise ValueError(f"unsupported harmony mode: {mode}")
    return [
        tuple(map(_linear, hsv_to_rgb((hue + degrees / 360) % 1, saturation, brightness)))
        if degrees else base
        for degrees in _HUE_ROTATION_DEGREES[key]
    ]


def parse_gpl(text, *, max_colors=256):
    lines = iter(str(text or "").splitlines())
    header = next((line.strip() for line in lines if line.strip()), "")
    if header != "GIMP Palette":
        raise ValueError("missing GIMP Palette header")
    swatches = []
    limit = min(4096, max(1, int(max_colors)))
    for line in lines:
        values = line.strip().split(None, 3)
        if len(values) < 3 or values[0].startswith("#") or ":" in values[0]:
            continue
        try:
            rgb = tuple(map(int, values[:3]))
        except ValueError:
            continue
        if min(rgb) < 0 or max(rgb) > 255:
            continue
        title = values[3] if len(values) == 4 else f"Color {len(swatches) + 1}"
        swatches.append(dict(name=title, srgb8=rgb, linear=srgb8_to_linear(rgb)))
        if len(swatches) == limit:
            return swatches
    if not swatches:
        raise ValueError("palette contains no valid colors")
    return swatches


def quantize_linear_rgba(pixels, *, max_colors=16, alpha_threshold=0.05, max_samples=65536):
    import numpy as np

    samples = np.asarray(pixels, dtype=np.float32).reshape(-1, 4)
    capacity = max(1, int(max_samples))
    samples = samples[::max(1, (len(samples) + capacity - 1) // capacity)]
    visible = (samples[:, 3] >= float(alpha_threshold)) & np.isfinite(samples).all(axis=1)
    rgb = samples[visible, :3].clip(0, 1)
    if not len(rgb):
        raise ValueError("image contains no visible colors")
    encoded = rgb * 12.92
    nonlinear = rgb > 0.0031308
    encoded[nonlinear] = 1.055 * rgb[nonlinear] ** (1 / 2.4) - 0.055
    bins = (encoded * 31 + 0.5).astype(np.int32)
    keys = bins @ np.array([1, 32, 1024], dtype=np.int32)
    weights = np.bincount(keys)
    limit = min(256, max(1, int(max_colors)))
    ranked = np.argsort(-weights, kind="stable")[:limit]
    totals = [np.bincount(keys, weights=channel, minlength=len(weights)) for channel in rgb.T]
    return [
        dict(name=f"Extracted {index + 1}",
             count=int(weights[key]),
             linear=tuple(float(total[key] / weights[key]) for total in totals))
        for index, key in enumerate(key for key in ranked if weights[key])
    ]


__all__ = ("harmony_colors_linear", "parse_gpl", "quantize_linear_rgba", "srgb8_to_linear")
