# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Optional, explicit Smart Paint utilities."""

__all__ = ()
