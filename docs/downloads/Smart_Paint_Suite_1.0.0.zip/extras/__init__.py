# SPDX-License-Identifier: GPL-3.0-or-later
"""Optional Smart Paint tools are loaded by their respective callers."""

__all__ = ()
