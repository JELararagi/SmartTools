# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Explicit native Brush Asset import UI for lightweight Smart Paint."""


from pathlib import Path
import os
import tempfile

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ImportHelper


def _image_paint(context):
    try:
        return context.scene.tool_settings.image_paint
    except Exception:
        return None


def _unique_name(collection, base: str) -> str:
    stem = str(base or "Smart Paint Brush").strip() or "Smart Paint Brush"
    if collection.get(stem) is None:
        return stem
    for number in range(2, 10000):
        candidate = f"{stem} {number}"
        if collection.get(candidate) is None:
            return candidate
    return stem


def _paint_area_override(context):
    screen = getattr(context, "screen", None)
    if screen is None:
        return None
    preferred = getattr(context, "area", None)
    areas = []
    if preferred is not None and preferred.type in {"VIEW_3D", "IMAGE_EDITOR"}:
        areas.append(preferred)
    areas.extend(
        area for area in screen.areas
        if area not in areas and area.type in {"VIEW_3D", "IMAGE_EDITOR"}
    )
    for area in areas:
        region = next((item for item in area.regions if item.type == "WINDOW"), None)
        if region is not None:
            return area, region
    return None


def _activate_local_brush(context, brush) -> tuple[bool, str]:
    if bpy.app.background:
        return False, "background_mode"
    override = _paint_area_override(context)
    if override is None:
        return False, "paint_area_unavailable"
    area, region = override
    try:
        with context.temp_override(area=area, region=region, space_data=area.spaces.active):
            if not bpy.ops.brush.asset_activate.poll():
                return False, "asset_activate_poll_failed"
            result = bpy.ops.brush.asset_activate(
                asset_library_type="LOCAL",
                relative_asset_identifier=f"Brush/{brush.name}",
            )
    except Exception as exc:
        return False, repr(exc)
    paint = _image_paint(context)
    return bool("FINISHED" in result and paint is not None and paint.brush is brush), ""


def _new_brush_from_gbr(context, parsed, fallback_name: str, png_bytes: bytes):
    paint = _image_paint(context)
    source = getattr(paint, "brush", None) if paint is not None else None
    brush_name = _unique_name(bpy.data.brushes, parsed.name or fallback_name)
    brush = source.copy() if source is not None else bpy.data.brushes.new(
        brush_name, mode="TEXTURE_PAINT"
    )
    brush.name = brush_name
    if getattr(brush, "asset_data", None) is not None:
        brush.asset_clear()

    handle, temporary_path = tempfile.mkstemp(prefix="sps_gbr_", suffix=".png")
    os.close(handle)
    image = None
    try:
        Path(temporary_path).write_bytes(png_bytes)
        image = bpy.data.images.load(temporary_path, check_existing=False)
        image.name = _unique_name(bpy.data.images, brush_name + " Tip")
        try:
            image.colorspace_settings.name = "Non-Color"
        except Exception:
            pass
        image.pack()
        image.filepath_raw = f"//SPS_BrushTips/{brush_name}.png"
    finally:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
    if image is None:
        raise RuntimeError("failed to create the packed brush image")
    image["sps_gbr_sha256"] = str(parsed.sha256)
    image["sps_gbr_source_name"] = str(parsed.name or fallback_name)
    image.use_fake_user = True

    texture = bpy.data.textures.new(
        _unique_name(bpy.data.textures, brush_name + " Tip"), type="IMAGE"
    )
    texture.image = image
    try:
        texture.extension = "CLIP"
    except Exception:
        pass
    brush.texture = texture
    try:
        brush.texture_slot.map_mode = "VIEW_PLANE"
    except Exception:
        pass
    brush.size = max(1, min(5000, max(int(parsed.width), int(parsed.height))))
    brush.spacing = max(1, min(1000, int(parsed.spacing)))
    brush.use_fake_user = True
    brush["sps_gbr_sha256"] = str(parsed.sha256)
    brush["sps_gbr_width"] = int(parsed.width)
    brush["sps_gbr_height"] = int(parsed.height)
    brush["sps_gbr_spacing"] = int(parsed.spacing)
    brush.asset_mark()
    if brush.asset_data is not None:
        brush.asset_data.description = "Imported GIMP GBR brush tip"
        try:
            brush.asset_data.tags.new("GBR")
        except Exception:
            pass
    return brush, texture, image


class SPS_OT_brush_import_gbr(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_paint_suite.brush_import_gbr"
    bl_label = "GBRブラシを読み込む"
    bl_description = "GIMP GBR v2を現在のファイルのブラシ資産へ変換します"
    # Blender's Image pixels are not part of regular operator memfile undo.
    # Marking this import UNDO restores the new GENERATED image as a blank
    # buffer immediately after execute(), so asset import is explicit/non-undo.
    bl_options = set()

    filename_ext = ".gbr"
    filter_glob: StringProperty(default="*.gbr", options={"HIDDEN"})
    activate: BoolProperty(
        name="読み込み後に有効化",
        default=True,
        description="テクスチャペイント中なら読み込んだブラシ資産を有効化します",
    )

    def execute(self, context):
        path = Path(self.filepath)
        brush = texture = image = None
        try:
            from . import brush_core

            parsed = brush_core.parse_gbr(path.read_bytes())
            png_bytes = brush_core.encode_mask_png(parsed)
            brush, texture, image = _new_brush_from_gbr(
                context, parsed, path.stem, png_bytes
            )
        except Exception as exc:
            for collection, item in (
                (bpy.data.brushes, brush),
                (bpy.data.textures, texture),
                (bpy.data.images, image),
            ):
                if item is not None:
                    try:
                        collection.remove(item)
                    except Exception:
                        pass
            self.report({"ERROR"}, _rpt_fail("GBRブラシを読み込めません", exc))
            return {"CANCELLED"}

        activated = False
        if bool(self.activate):
            activated = _activate_local_brush(context, brush)[0]
        if bool(self.activate) and not activated and not bpy.app.background:
            self.report({"WARNING"}, _rpt("{}を読み込みました。有効化はブラシ棚から行ってください", brush.name))
        else:
            state = _rpt("有効化") if activated else _rpt("現在のファイルの資産へ追加")
            self.report({"INFO"}, f"{brush.name}: {state}")
        return {"FINISHED"}


def _draw_brush_assets(layout, context) -> None:
    paint = _image_paint(context)
    brush = getattr(paint, "brush", None) if paint is not None else None
    try:
        from bl_ui.properties_paint_common import BrushAssetShelf

        BrushAssetShelf.draw_popup_selector(layout, context, brush, show_name=True)
    except Exception:
        layout.label(text=getattr(brush, "name", "") or _rpt("ブラシ未選択"), icon="BRUSH_DATA", translate=False)
    row = layout.row(align=True)
    row.operator(SPS_OT_brush_import_gbr.bl_idname, text="GBR読込", icon="IMPORT")
    save = row.row(align=True)
    save.enabled = brush is not None
    save.operator("brush.asset_save_as", text="資産保存", icon="FILE_TICK")


class SPS_PT_brush_assets_view3d(bpy.types.Panel):
    bl_idname = "SPS_PT_brush_assets_view3d"
    bl_label = "ブラシ資産"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_view3d"
    bl_order = 10
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        _draw_brush_assets(self.layout, context)


class SPS_PT_brush_assets_image_editor(bpy.types.Panel):
    bl_idname = "SPS_PT_brush_assets_image_editor"
    bl_label = "ブラシ資産"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_image_editor"
    bl_order = 10
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        _draw_brush_assets(self.layout, context)


CLASSES = (
    SPS_OT_brush_import_gbr,
    SPS_PT_brush_assets_view3d,
    SPS_PT_brush_assets_image_editor,
)


__all__ = ("CLASSES",)
