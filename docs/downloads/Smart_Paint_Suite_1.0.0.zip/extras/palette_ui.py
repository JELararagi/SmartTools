# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Native Blender Palette UI and explicit import commands."""


from pathlib import Path

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper


def _image_paint(context):
    try:
        return context.scene.tool_settings.image_paint
    except Exception:
        return None


def _unified(context):
    settings = _image_paint(context)
    return getattr(settings, "unified_paint_settings", None) if settings is not None else None


def _current_color(context) -> tuple[float, float, float]:
    unified = _unified(context)
    if bool(getattr(unified, "use_unified_color", False)):
        try:
            return tuple(float(value) for value in unified.color[:3])
        except Exception:
            pass
    settings = _image_paint(context)
    try:
        return tuple(float(value) for value in settings.brush.color[:3])
    except Exception:
        return (0.5, 0.5, 0.5)


def _unique_palette_name(base: str) -> str:
    stem = str(base or "Smart Paint Palette").strip() or "Smart Paint Palette"
    if bpy.data.palettes.get(stem) is None:
        return stem
    for number in range(2, 10000):
        name = f"{stem} {number}"
        if bpy.data.palettes.get(name) is None:
            return name
    return stem


def _new_palette(context, name: str, colors) -> object:
    settings = _image_paint(context)
    if settings is None:
        raise RuntimeError("Image Paint settings are unavailable")
    palette = bpy.data.palettes.new(_unique_palette_name(name))
    palette.use_fake_user = True
    for color in colors:
        item = palette.colors.new()
        item.color = tuple(float(value) for value in color[:3])
    settings.palette = palette
    return palette


class SPS_OT_palette_new(bpy.types.Operator):
    bl_idname = "smart_paint_suite.palette_new"
    bl_label = "新規パレット"
    bl_description = "現在のBlenderペイント色からパレットを作成します"
    bl_options = {"UNDO"}

    name: StringProperty(name="名前", default="Smart Paint Palette")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        try:
            palette = _new_palette(context, self.name, [_current_color(context)])
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("パレットを作成できません", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("パレット作成: {}", palette.name))
        return {"FINISHED"}


class SPS_OT_palette_generate_harmony(bpy.types.Operator):
    bl_idname = "smart_paint_suite.palette_generate_harmony"
    bl_label = "調和色パレット"
    bl_description = "現在のBlenderペイント色から色相調和のパレットを作成します"
    bl_options = {"UNDO"}

    mode: EnumProperty(
        name="配色",
        items=(
            ("COMPLEMENTARY", "補色", "基準色と180度反対の色"),
            ("ANALOGOUS", "類似色", "基準色の前後30度"),
            ("TRIADIC", "トライアド", "120度間隔の3色"),
            (
                "SPLIT_COMPLEMENTARY",
                "分裂補色",
                "基準色と補色の前後30度",
            ),
        ),
        default="COMPLEMENTARY",
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, _context):
        self.layout.prop(self, "mode", expand=True)

    def execute(self, context):
        try:
            from . import palette_core

            colors = palette_core.harmony_colors_linear(
                _current_color(context),
                self.mode,
            )
            label = {
                "COMPLEMENTARY": "Complementary",
                "ANALOGOUS": "Analogous",
                "TRIADIC": "Triadic",
                "SPLIT_COMPLEMENTARY": "Split Complementary",
            }[self.mode]
            palette = _new_palette(context, f"Smart Paint {label}", colors)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("調和色を生成できません", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("{}: {}色", palette.name, len(palette.colors)))
        return {"FINISHED"}


class SPS_OT_palette_import_gpl(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_paint_suite.palette_import_gpl"
    bl_label = "GPLパレットを読み込む"
    bl_description = "GIMPパレット (.gpl)をBlender パレットとして読み込みます"
    bl_options = {"UNDO"}

    filename_ext = ".gpl"
    filter_glob: StringProperty(default="*.gpl", options={"HIDDEN"})

    def execute(self, context):
        path = Path(self.filepath)
        try:
            raw = path.read_bytes()
            try:
                text = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = raw.decode("latin-1")
            from . import palette_core

            parsed = palette_core.parse_gpl(text, max_colors=256)
            palette = _new_palette(context, path.stem, [entry["linear"] for entry in parsed])
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("GPLパレットを読み込めません", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("{}: {}色", palette.name, len(palette.colors)))
        return {"FINISHED"}


class SPS_OT_palette_import_png(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_paint_suite.palette_import_png"
    bl_label = "画像からパレットを作成"
    bl_description = "PNG/JPEG画像を縮小サンプリングし、主要色をパレットへ抽出します"
    bl_options = {"UNDO"}

    filename_ext = ".png"
    filter_glob: StringProperty(default="*.png;*.jpg;*.jpeg;*.tif;*.tiff", options={"HIDDEN"})
    max_colors: IntProperty(name="色数", default=16, min=2, max=32)
    alpha_threshold: FloatProperty(name="アルファしきい値", default=0.05, min=0.0, max=1.0, subtype="FACTOR")

    def execute(self, context):
        path = Path(self.filepath)
        image = None
        created = False
        try:
            existing = {int(item.as_pointer()) for item in bpy.data.images}
            image = bpy.data.images.load(str(path), check_existing=False)
            created = int(image.as_pointer()) not in existing
            width, height = int(image.size[0]), int(image.size[1])
            if width <= 0 or height <= 0:
                raise ValueError("invalid image dimensions")
            scale = min(1.0, 256.0 / max(width, height))
            target_width = max(1, int(round(width * scale)))
            target_height = max(1, int(round(height * scale)))
            if target_width != width or target_height != height:
                image.scale(target_width, target_height)
            import numpy as np

            pixels = np.empty(target_width * target_height * 4, dtype=np.float32)
            image.pixels.foreach_get(pixels)
            from . import palette_core

            colors = palette_core.quantize_linear_rgba(
                pixels,
                max_colors=int(self.max_colors),
                alpha_threshold=float(self.alpha_threshold),
                max_samples=65536,
            )
            palette = _new_palette(context, path.stem, [entry["linear"] for entry in colors])
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("画像から色を抽出できません", exc))
            return {"CANCELLED"}
        finally:
            if image is not None and created:
                try:
                    bpy.data.images.remove(image)
                except Exception:
                    pass
        self.report({"INFO"}, _rpt("{}: {}色", palette.name, len(palette.colors)))
        return {"FINISHED"}


def _draw_palette(layout, context) -> None:
    settings = _image_paint(context)
    if settings is None:
        layout.label(text="テクスチャペイント設定がありません")
        return
    header = layout.row(align=True)
    header.template_ID(settings, "palette", new=SPS_OT_palette_new.bl_idname)
    palette = getattr(settings, "palette", None)
    if palette is not None:
        layout.template_palette(settings, "palette", color=True)
        row = layout.row(align=True)
        row.operator("palette.color_add", text="", icon="ADD")
        row.operator("palette.color_delete", text="", icon="REMOVE")
        row.separator()
        row.operator(
            SPS_OT_palette_generate_harmony.bl_idname,
            text="調和色",
            icon="COLOR",
        )
        row = layout.row(align=True)
        row.operator(SPS_OT_palette_import_gpl.bl_idname, text="GPL", icon="IMPORT")
        row.operator(SPS_OT_palette_import_png.bl_idname, text="画像", icon="IMAGE_DATA")
    else:
        row = layout.row(align=True)
        row.operator(
            SPS_OT_palette_generate_harmony.bl_idname,
            text="調和色",
            icon="COLOR",
        )
        row = layout.row(align=True)
        row.operator(SPS_OT_palette_import_gpl.bl_idname, text="GPL", icon="IMPORT")
        row.operator(SPS_OT_palette_import_png.bl_idname, text="画像", icon="IMAGE_DATA")
    unified = _unified(context)
    if unified is not None:
        color = layout.row(align=True)
        color.prop(unified, "color", text="")
        color.prop(unified, "secondary_color", text="")


class SPS_PT_paint_assets_view3d(bpy.types.Panel):
    bl_idname = "SPS_PT_paint_assets_view3d"
    bl_label = "カラーパレット"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_view3d"
    bl_order = 11
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        _draw_palette(self.layout, context)


class SPS_PT_paint_assets_image_editor(bpy.types.Panel):
    bl_idname = "SPS_PT_paint_assets_image_editor"
    bl_label = "カラーパレット"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    bl_parent_id = "SPS_PT_lightweight_image_editor"
    bl_order = 11
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        _draw_palette(self.layout, context)


CLASSES = (
    SPS_OT_palette_new,
    SPS_OT_palette_generate_harmony,
    SPS_OT_palette_import_gpl,
    SPS_OT_palette_import_png,
    SPS_PT_paint_assets_view3d,
    SPS_PT_paint_assets_image_editor,
)


__all__ = ("CLASSES",)
