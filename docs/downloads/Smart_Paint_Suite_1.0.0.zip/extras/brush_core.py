# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Strict, Blender-independent readers for supported brush files."""

from __future__ import annotations

from dataclasses import dataclass
import binascii
import hashlib
import struct
import zlib


GBR_V2_MAGIC = 0x47494D50
GBR_V2_HEADER_SIZE = 28
MAX_BRUSH_DIMENSION = 4096
MAX_BRUSH_PIXELS = MAX_BRUSH_DIMENSION * MAX_BRUSH_DIMENSION


@dataclass(frozen=True)
class GbrBrush:
    name: str
    width: int
    height: int
    spacing: int
    gray_top_down: bytes
    sha256: str


def parse_gbr(data: bytes) -> GbrBrush:
    """Parse a GIMP GBR v2 grayscale brush without touching Blender state."""
    raw = bytes(data)
    if len(raw) < GBR_V2_HEADER_SIZE:
        raise ValueError("GBR header is truncated")
    header_size, version, width, height, depth, magic, spacing = struct.unpack(
        ">7I", raw[:GBR_V2_HEADER_SIZE]
    )
    if version != 2:
        raise ValueError(f"unsupported GBR version: {version}")
    if magic != GBR_V2_MAGIC:
        raise ValueError("invalid GBR magic")
    if depth != 1:
        raise ValueError(f"unsupported GBR depth: {depth}; grayscale depth 1 is required")
    if not (1 <= width <= MAX_BRUSH_DIMENSION and 1 <= height <= MAX_BRUSH_DIMENSION):
        raise ValueError(f"invalid GBR dimensions: {width}x{height}")
    pixel_count = width * height
    if pixel_count > MAX_BRUSH_PIXELS:
        raise ValueError("GBR pixel count exceeds the safety limit")
    if not (GBR_V2_HEADER_SIZE + 1 <= header_size <= len(raw)):
        raise ValueError(f"invalid GBR header size: {header_size}")
    name_bytes = raw[GBR_V2_HEADER_SIZE:header_size]
    if not name_bytes.endswith(b"\0"):
        raise ValueError("GBR v2 name is not NUL terminated")
    try:
        name = name_bytes[:-1].decode("utf-8").strip()
    except UnicodeDecodeError as exc:
        raise ValueError("GBR v2 name is not valid UTF-8") from exc
    body = raw[header_size:]
    if len(body) != pixel_count:
        raise ValueError(
            f"GBR body size mismatch: expected {pixel_count}, got {len(body)}"
        )
    if not (1 <= spacing <= 1000):
        raise ValueError(f"invalid GBR spacing: {spacing}")
    return GbrBrush(
        name=name,
        width=int(width),
        height=int(height),
        spacing=int(spacing),
        gray_top_down=body,
        sha256=hashlib.sha256(raw).hexdigest(),
    )


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    payload = kind + data
    return (
        struct.pack(">I", len(data))
        + payload
        + struct.pack(">I", binascii.crc32(payload) & 0xFFFFFFFF)
    )


def encode_mask_png(brush: GbrBrush) -> bytes:
    """Encode the GBR mask as a standard top-down RGBA PNG."""
    invert = bytes.maketrans(bytes(range(256)), bytes(reversed(range(256))))
    coverage = brush.gray_top_down.translate(invert)
    row_bytes = brush.width * 4
    scanline_bytes = row_bytes + 1
    raw = bytearray(scanline_bytes * brush.height)
    for row_index in range(brush.height):
        source_start = row_index * brush.width
        source = coverage[source_start:source_start + brush.width]
        rgba = bytearray(row_bytes)
        rgba[0::4] = source
        rgba[1::4] = source
        rgba[2::4] = source
        rgba[3::4] = b"\xff" * brush.width
        target_start = row_index * scanline_bytes
        raw[target_start] = 0
        raw[target_start + 1:target_start + scanline_bytes] = rgba
    header = struct.pack(">IIBBBBB", brush.width, brush.height, 8, 6, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", header)
        + _png_chunk(b"IDAT", zlib.compress(bytes(raw), level=6))
        + _png_chunk(b"IEND", b"")
    )


__all__ = ("GbrBrush", "encode_mask_png", "parse_gbr")
