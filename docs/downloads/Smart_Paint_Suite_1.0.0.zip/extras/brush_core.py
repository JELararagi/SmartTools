# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Decode grayscale GBR tips and encode their coverage for Blender."""

from dataclasses import dataclass
from hashlib import sha256
from struct import Struct
from zlib import compressobj, crc32


_HEADER = Struct(">7I")
_CHUNK_LENGTH = Struct(">I")
_PNG_FORMAT = Struct(">2I5B")
GBR_V2_MAGIC = int.from_bytes(b"GIMP", "big")
GBR_V2_HEADER_SIZE = _HEADER.size
MAX_BRUSH_DIMENSION = 4096
MAX_BRUSH_PIXELS = MAX_BRUSH_DIMENSION ** 2
_INVERT_GRAYSCALE = bytes(range(255, -1, -1))


@dataclass(frozen=True)
class GbrBrush:
    name: str
    width: int
    height: int
    spacing: int
    gray_top_down: bytes
    sha256: str


def parse_gbr(data):
    blob = bytes(data)
    if len(blob) < _HEADER.size:
        raise ValueError("GBR header is truncated")
    start, revision, width, rows, channels, signature, spacing = _HEADER.unpack_from(blob)
    if revision != 2 or signature != GBR_V2_MAGIC:
        raise ValueError("expected a GIMP GBR v2 signature")
    if channels != 1:
        raise ValueError("the brush tip must have one grayscale channel")
    if min(width, rows) < 1 or max(width, rows) > MAX_BRUSH_DIMENSION:
        raise ValueError(f"invalid GBR dimensions: {width}x{rows}")
    if not _HEADER.size < start <= len(blob) or blob[start - 1] != 0:
        raise ValueError("invalid GBR name field")
    if len(blob) - start != width * rows:
        raise ValueError("GBR data size does not match the brush dimensions")
    if not 1 <= spacing <= 1000:
        raise ValueError(f"invalid GBR spacing: {spacing}")
    name = blob[_HEADER.size:start - 1].decode("utf-8").strip()
    return GbrBrush(name, width, rows, spacing, blob[start:], sha256(blob).hexdigest())


def _chunk(kind, content):
    checksum = crc32(content, crc32(kind))
    return b"".join((_CHUNK_LENGTH.pack(len(content)), kind, content, _CHUNK_LENGTH.pack(checksum)))


def encode_mask_png(brush):
    width, height = brush.width, brush.height
    compressor = compressobj()
    row = bytearray(b"\xff" * (1 + 4 * width))
    row[0] = 0
    output = []
    for offset in range(0, width * height, width):
        intensity = brush.gray_top_down[offset:offset + width].translate(_INVERT_GRAYSCALE)
        for channel in (1, 2, 3):
            row[channel::4] = intensity
        output.append(compressor.compress(row))
    output.append(compressor.flush())
    dimensions = _PNG_FORMAT.pack(width, height, 8, 6, 0, 0, 0)
    return b"".join((b"\x89PNG\r\n\x1a\n", _chunk(b"IHDR", dimensions),
                     _chunk(b"IDAT", b"".join(output)), _chunk(b"IEND", b"")))


__all__ = ("GbrBrush", "encode_mask_png", "parse_gbr")
