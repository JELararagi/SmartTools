# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import os
import re
import sys
import traceback
import uuid
from datetime import datetime
from contextlib import contextmanager
from typing import Iterable, Optional

import bpy

from .constants import (
    ADDON_ID,
    BLEND_MODE_ITEMS,
    CHANNEL_INFO,
    CHANNEL_ITEMS,
    DEFAULT_COLOR_ATTRIBUTE_NAME,
    DEFAULT_UV_NAME,
    DEFAULT_VERTEX_COLOR_NAME,
    IMAGE_PREFIX,
    LAYER_KIND_ITEMS,
    MASK_CHANNEL_ITEMS,
    MASK_MODE_ITEMS,
    NODE_PREFIX,
    PROJECTION_ITEMS,
    report_text,
    TEMP_PREFIX,
)


LAYER_SNAPSHOT_PROPS = (
    "name", "layer_id", "enabled", "layer_kind", "opacity", "blend_mode", "projection_mode",
    "uv_map", "uv_scale", "uv_offset", "uv_rotation", "use_texture_bombing", "bombing_strength", "bombing_cell_scale", "bombing_seed",
    "use_base_color", "base_color_image", "fill_color",
    "use_roughness", "roughness_image", "roughness_value",
    "use_metallic", "metallic_image", "metallic_value",
    "use_normal", "normal_image", "normal_strength",
    "use_height", "height_image", "height_value", "height_strength",
    "use_emission", "emission_image", "emission_color", "emission_strength",
    "use_alpha", "alpha_image", "alpha_value",
    "use_ao", "ao_image", "ao_value",
    "filter_brightness", "filter_contrast", "filter_gamma", "filter_invert",
    "filter_hue_shift", "filter_saturation", "filter_value",
    "mask_mode", "mask_image", "mask_channel", "invert_mask", "mask_strength", "mask_threshold",
    "noise_scale", "noise_detail", "edge_balance", "vertex_color_attribute",
    "color_id_color", "color_id_tolerance",
    "anchor_layer_name", "anchor_channel", "anchor_layer_id",
    "use_height_blend", "height_blend_balance", "height_blend_invert",
)

MATERIAL_SNAPSHOT_PROPS = (
    "managed", "active_layer_index", "active_paint_channel", "resolution", "use_float_images",
    "use_udim", "multiply_ao_to_base_color", "use_bump_preview", "global_bump_strength",
    "enable_displacement_output", "displacement_scale", "default_uv_map",
    "ao_map", "normal_map", "position_map", "curvature_map", "thickness_map",
    "validation_message",
)


def _enum_ids(items) -> set[str]:
    return {item[0] for item in items}


VALID_LAYER_KINDS = _enum_ids(LAYER_KIND_ITEMS)
VALID_BLEND_MODES = _enum_ids(BLEND_MODE_ITEMS)
VALID_MASK_MODES = _enum_ids(MASK_MODE_ITEMS)
VALID_MASK_CHANNELS = _enum_ids(MASK_CHANNEL_ITEMS)
VALID_PROJECTION_MODES = _enum_ids(PROJECTION_ITEMS)
VALID_CHANNELS = _enum_ids(CHANNEL_ITEMS)

DEFAULT_LAYER_KIND = next((item[0] for item in LAYER_KIND_ITEMS), "PAINT")
DEFAULT_BLEND_MODE = next((item[0] for item in BLEND_MODE_ITEMS), "MIX")
DEFAULT_MASK_MODE = next((item[0] for item in MASK_MODE_ITEMS), "NONE")
DEFAULT_MASK_CHANNEL = next((item[0] for item in MASK_CHANNEL_ITEMS), "LUMA")
DEFAULT_PROJECTION_MODE = next((item[0] for item in PROJECTION_ITEMS), "UV")
DEFAULT_ANCHOR_CHANNEL = next((item[0] for item in CHANNEL_ITEMS), "BASE_COLOR")

LAYER_KIND_LABELS = {identifier: label for identifier, label, _desc in LAYER_KIND_ITEMS}

LAYER_FLOAT_LIMITS = {
    "opacity": (0.0, 1.0),
    "bombing_strength": (0.0, 2.0),
    "bombing_cell_scale": (0.25, 128.0),
    "bombing_seed": (-1000.0, 1000.0),
    "roughness_value": (0.0, 1.0),
    "metallic_value": (0.0, 1.0),
    "normal_strength": (0.0, 5.0),
    "height_value": (0.0, 1.0),
    "height_strength": (0.0, 5.0),
    "emission_strength": (0.0, 100.0),
    "alpha_value": (0.0, 1.0),
    "ao_value": (0.0, 1.0),
    "filter_brightness": (-2.0, 2.0),
    "filter_contrast": (-2.0, 2.0),
    "filter_gamma": (0.01, 4.0),
    "filter_hue_shift": (-0.5, 0.5),
    "filter_saturation": (0.0, 4.0),
    "filter_value": (0.0, 4.0),
    "mask_strength": (0.0, 1.0),
    "mask_threshold": (0.0, 1.0),
    "noise_scale": (0.001, 1024.0),
    "noise_detail": (0.0, 16.0),
    "edge_balance": (0.0, 4.0),
    "color_id_tolerance": (0.001, 1.0),
    "height_blend_balance": (0.0, 4.0),
}

LAYER_VECTOR_LIMITS = {
    "uv_scale": ((0.001, 0.001), (100.0, 100.0)),
    "uv_offset": ((-10.0, -10.0), (10.0, 10.0)),
    "fill_color": ((0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 1.0, 1.0)),
    "emission_color": ((0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 1.0, 1.0)),
    "color_id_color": ((0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 1.0, 1.0)),
}


class SPSException(RuntimeError):
    """Readable user-facing exception."""


def addon_prefs(context: Optional[bpy.types.Context] = None):
    context = context or bpy.context
    try:
        wm = getattr(context, 'window_manager', None)
        runtime_prefs = getattr(wm, 'smart_paint_suite_runtime_preferences', None) if wm is not None else None
        if runtime_prefs is not None:
            return runtime_prefs
    except Exception:
        pass

    prefs = getattr(context, "preferences", None)
    if not prefs:
        return None
    addons = getattr(prefs, "addons", {})
    for key in filter(None, [ADDON_ID, __package__, (__package__.split('.')[-1] if __package__ else None)]):
        addon = addons.get(key)
        if addon:
            return getattr(addon, 'preferences', None)
    return None



def _normalized_path_token(value: str) -> str:
    value = (value or '').strip().replace('\\', '/')
    return value.rstrip('/').lower()


def _extension_module_candidates() -> list[str]:
    candidates: list[str] = []
    for value in (
        ADDON_ID,
        __package__ or '',
        (__package__.split('.')[-1] if __package__ else ''),
        (__name__.split('.')[0] if __name__ else ''),
    ):
        value = (value or '').strip()
        if value and value not in candidates:
            candidates.append(value)
    return candidates


def _blender_user_version_root(create: bool = False) -> str:
    try:
        value = bpy.utils.resource_path('USER')
    except Exception:
        value = ''
    if value:
        path = os.path.abspath(str(value))
    else:
        version = f"{int(getattr(bpy.app, 'version', (5, 1))[0])}.{int(getattr(bpy.app, 'version', (5, 1))[1])}"
        if os.name == 'nt':
            appdata = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
            path = os.path.join(appdata, 'Blender Foundation', 'Blender', version)
        elif sys.platform == 'darwin':
            path = os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', 'Blender', version)
        else:
            path = os.path.join(os.path.expanduser('~'), '.config', 'blender', version)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def _blender_user_default_extension_path(package_id: str, create: bool = False) -> str:
    package_id = str(package_id or ADDON_ID or 'smart_paint_suite').strip()
    path = os.path.join(_blender_user_version_root(create=create), 'extensions', 'user_default', package_id)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def extension_user_storage_root(create: bool = True) -> str:
    utils_mod = getattr(bpy, 'utils', None)
    ext_fn = getattr(utils_mod, 'extension_path_user', None)
    if callable(ext_fn):
        for module_id in _extension_module_candidates():
            attempts = (
                lambda module_id=module_id: ext_fn(module_id),
                lambda module_id=module_id: ext_fn(module_id, create=create),
                lambda module_id=module_id: ext_fn(module_id, ''),
                lambda module_id=module_id: ext_fn(module_id, '', create=create),
                lambda module_id=module_id: ext_fn(module=module_id, create=create),
                lambda module_id=module_id: ext_fn(module=module_id, path='', create=create),
            )
            for attempt in attempts:
                try:
                    value = attempt()
                except TypeError:
                    continue
                except Exception:
                    continue
                if value:
                    value = os.path.abspath(value)
                    if create:
                        os.makedirs(value, exist_ok=True)
                    return value
    return os.path.abspath(_blender_user_default_extension_path(ADDON_ID, create=create))


def addon_storage_dir(*parts: str, create: bool = True) -> str:
    base = extension_user_storage_root(create=create)
    path = os.path.join(base, *[part for part in parts if part]) if parts else base
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def resolve_suite_directory(
    directory: str,
    default_subdir: str,
    *legacy_values: str,
    create_default: bool = True,
    create_custom: bool = False,
) -> str:
    directory = directory or ''
    normalized = _normalized_path_token(directory)
    legacy = {_normalized_path_token(value) for value in legacy_values if value}
    if not normalized or normalized in legacy:
        return addon_storage_dir(default_subdir, create=create_default)
    try:
        resolved = os.path.abspath(bpy.path.abspath(directory))
    except Exception:
        resolved = os.path.abspath(directory)
    if create_custom:
        os.makedirs(resolved, exist_ok=True)
    return resolved

def debug_log(message: str, context: Optional[bpy.types.Context] = None) -> None:
    try:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
        settings = getattr(scene, 'smart_paint_suite', None) if scene is not None else None
        if settings and getattr(settings, 'debug_logging', False):
            from . import status_runtime
            status_runtime.set_transient(
                "smart_paint_suite.debug", str(message)[:512], duration=2.0
            )
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError):
        return


@contextmanager
def preserve_render_settings(scene: bpy.types.Scene):
    engine = scene.render.engine
    bake = scene.render.bake
    bake_margin = bake.margin
    bake_target = getattr(bake, "target", None)
    bake_use_selected_to_active = getattr(bake, "use_selected_to_active", None)
    samples = getattr(scene.cycles, "samples", None) if hasattr(scene, "cycles") else None
    try:
        yield
    finally:
        scene.render.engine = engine
        bake.margin = bake_margin
        if bake_target is not None and hasattr(bake, "target"):
            try:
                bake.target = bake_target
            except Exception:
                pass
        if bake_use_selected_to_active is not None and hasattr(bake, "use_selected_to_active"):
            try:
                bake.use_selected_to_active = bake_use_selected_to_active
            except Exception:
                pass
        if samples is not None and hasattr(scene, "cycles"):
            scene.cycles.samples = samples


@contextmanager
def preserve_mode(context: bpy.types.Context):
    obj = context.object
    original_mode = obj.mode if obj else None
    try:
        yield
    finally:
        if obj and original_mode and obj.mode != original_mode:
            try:
                bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass


@contextmanager
def preserve_selection(context: bpy.types.Context):
    view_layer = context.view_layer
    active = view_layer.objects.active
    selected = list(context.selected_objects)
    try:
        yield
    finally:
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except Exception:
            pass
        for obj in selected:
            try:
                obj.select_set(True)
            except Exception:
                pass
        if active:
            view_layer.objects.active = active


@contextmanager
def temp_assign_material(obj: bpy.types.Object, material: bpy.types.Material):
    original_materials = [slot.material for slot in obj.material_slots]
    if len(obj.material_slots) == 0:
        obj.data.materials.append(material)
    else:
        for slot in obj.material_slots:
            slot.material = material
    try:
        yield
    finally:
        if len(original_materials) == 0:
            if obj.material_slots:
                obj.data.materials.pop(index=0)
        else:
            for idx, mat in enumerate(original_materials):
                if idx < len(obj.material_slots):
                    obj.material_slots[idx].material = mat


@contextmanager
def temporary_image_node(material: bpy.types.Material, image: bpy.types.Image, label: str = "SPS Bake Target"):
    nt = material.node_tree
    node = nt.nodes.new("ShaderNodeTexImage")
    node.name = unique_node_name(nt, f"{TEMP_PREFIX}{label}")
    node.label = label
    node.image = image
    nt.nodes.active = node
    node.select = True
    try:
        yield node
    finally:
        if node and nt and node.name in nt.nodes:
            nt.nodes.remove(node)


@contextmanager
def isolated_nodes(material: bpy.types.Material, keep_output: bool = False):
    nt = material.node_tree
    existing = list(nt.nodes)
    existing_links = [(link.from_socket, link.to_socket) for link in nt.links]
    if keep_output:
        nodes_to_remove = [n for n in existing if n.type != 'OUTPUT_MATERIAL']
    else:
        nodes_to_remove = existing
    for node in nodes_to_remove:
        nt.nodes.remove(node)
    try:
        yield nt
    finally:
        for node in list(nt.nodes):
            nt.nodes.remove(node)
        # We cannot reliably restore exact nodes, so this context is intended only on temporary materials.
        # Intentionally left empty for safety.


@contextmanager
def preserve_material_output_links(material: bpy.types.Material):
    nt = material.node_tree
    links = [(link.from_socket.path_from_id(), link.to_socket.path_from_id()) for link in nt.links]
    try:
        yield
    finally:
        # Nothing to do: rebuild code is deterministic.
        _ = links


@contextmanager
def temp_object_mode(context: bpy.types.Context):
    obj = context.object
    original_mode = obj.mode if obj else 'OBJECT'
    try:
        if obj and obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        yield
    finally:
        try:
            if obj and original_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=original_mode)
        except Exception:
            pass


@contextmanager
def force_object_mode(context: bpy.types.Context):
    with preserve_mode(context):
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        yield


@contextmanager
def active_material_context(context: bpy.types.Context, material: bpy.types.Material):
    obj = context.object
    if not obj:
        raise SPSException("No active object.")
    original_index = getattr(obj, "active_material_index", 0)
    idx = find_material_slot_index(obj, material)
    if idx >= 0:
        obj.active_material_index = idx
    try:
        yield
    finally:
        obj.active_material_index = original_index


@contextmanager
def suppress_prints():
    try:
        yield
    finally:
        pass


@contextmanager
def ensure_texture_paint_mode(context: bpy.types.Context):
    obj = context.object
    if not obj:
        raise SPSException("No active object.")
    original_mode = obj.mode
    try:
        if obj.mode != 'TEXTURE_PAINT':
            bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
        yield
    finally:
        try:
            if obj.mode != original_mode:
                bpy.ops.object.mode_set(mode=original_mode)
        except Exception:
            pass


@contextmanager
def temp_scene_camera(scene: bpy.types.Scene, camera_obj: bpy.types.Object):
    original = scene.camera
    scene.camera = camera_obj
    try:
        yield
    finally:
        scene.camera = original


def set_last_info_message(target, message: str) -> None:
    scene = None
    if hasattr(target, 'scene'):
        scene = target.scene
    elif hasattr(target, 'smart_paint_suite'):
        scene = target
    else:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return
    try:
        scene.smart_paint_suite.last_info_message = report_text(message, target)
    except Exception:
        pass
    debug_log(report_text(message, target))


def write_runtime_log(target, action: str, ex: Exception, *, restored: bool = False, snapshot_name: str = "", material: Optional[bpy.types.Material] = None, traceback_text: str = ""):
    scene = None
    if hasattr(target, 'scene'):
        scene = target.scene
    elif hasattr(target, 'smart_paint_suite'):
        scene = target
    else:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)

    traceback_text = traceback_text or traceback.format_exc()
    lines = [
        '# Smart Paint Runtime Log',
        '',
        f'- Time: {datetime.utcnow().isoformat(timespec="seconds") + "Z"}',
        f'- Action: {action}',
        f'- Error: {ex}',
        f'- Restored Snapshot: {restored}',
        f'- Snapshot Name: {snapshot_name or "None"}',
        f'- Material: {getattr(material, "name", "-")}',
        f'- Object: {getattr(getattr(getattr(bpy, "context", None), "object", None), "name", "-")}',
        '',
        '## Traceback',
        traceback_text.strip() or 'No traceback text captured.',
        '',
        '## Notes',
        '- This log is generated automatically when a Smart Paint operator raises an exception.',
        '- Use the Snapshot restore tools and Audit Report together when diagnosing damaged stacks or missing resources.',
    ]
    text_block = write_named_text_block('SPS_Runtime_Log', '\n'.join(lines) + '\n', unique=False)
    if scene is not None:
        try:
            scene.smart_paint_suite.last_runtime_log_text_name = text_block.name
        except Exception:
            pass
    return text_block


def _is_expected_user_error(ex: Exception) -> bool:
    return isinstance(ex, SPSException)


def _capture_runtime_log_for_exception(context, action: str, ex: Exception, *, restored: bool = False, snapshot_text=None, material: Optional[bpy.types.Material] = None) -> str:
    if _is_expected_user_error(ex):
        return ''
    tb_text = traceback.format_exc()
    try:
        log = write_runtime_log(
            context or getattr(bpy, 'context', None),
            action,
            ex,
            restored=restored,
            snapshot_name=getattr(snapshot_text, 'name', '') if snapshot_text is not None else '',
            material=material,
            traceback_text=tb_text,
        )
        return getattr(log, 'name', '') or ''
    except Exception:
        return ''


def _maybe_debug_traceback(action: str, ex: Exception, context: Optional[bpy.types.Context] = None) -> None:
    if _is_expected_user_error(ex):
        debug_log(f"Expected Smart Paint validation stop in {action}: {ex}", context)
        return
    debug_log(f"Exception in {action}: {type(ex).__name__}: {ex}", context)


def report_exception(self, action: str, ex: Exception) -> set[str]:
    context = getattr(bpy, 'context', None)
    log_name = _capture_runtime_log_for_exception(context, action, ex)
    _maybe_debug_traceback(action, ex, context)
    message = f"{action}: {ex}"
    if log_name:
        message += f" | Runtime log: {log_name}"
    set_last_info_message(context, message)
    self.report({'ERROR'}, report_text(message, locals().get('context')))
    return {'CANCELLED'}


def restore_snapshot_with_rebuild(context: bpy.types.Context, material: bpy.types.Material, text_block) -> bool:
    if context is None or material is None or text_block is None:
        return False
    try:
        restore_stack_snapshot(material, text_block)
        from .node_factory import rebuild_material_stack
        rebuild_material_stack(material)
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def report_exception_with_restore(self, context: Optional[bpy.types.Context], material: Optional[bpy.types.Material], snapshot_text, action: str, ex: Exception) -> set[str]:
    restored = False
    if (not _is_expected_user_error(ex)) and context is not None and material is not None and snapshot_text is not None:
        try:
            if scene_settings(context.scene).auto_restore_on_failure:
                restored = restore_snapshot_with_rebuild(context, material, snapshot_text)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            restored = False
    log_name = _capture_runtime_log_for_exception(context, action, ex, restored=restored, snapshot_text=snapshot_text, material=material)
    _maybe_debug_traceback(action, ex, context)
    if restored:
        message = f"{action}: {ex} | Restored the last automatic snapshot."
    else:
        message = f"{action}: {ex}"
    if log_name:
        message += f" | Runtime log: {log_name}"
    set_last_info_message(context or getattr(bpy, 'context', None), message)
    self.report({'ERROR'}, report_text(message, locals().get('context')))
    return {'CANCELLED'}


def ensure_mesh_object(context: bpy.types.Context) -> bpy.types.Object:
    obj = context.object
    if not obj or obj.type != 'MESH':
        raise SPSException("A mesh object must be active.")
    return obj


def ensure_material(obj: bpy.types.Object) -> bpy.types.Material:
    mat = obj.active_material
    if mat is None:
        mat = bpy.data.materials.new(name=f"{obj.name}_SPS")
        obj.active_material = mat
    if not mat.use_nodes:
        mat.use_nodes = True
    return mat


def material_settings(material: bpy.types.Material):
    settings = getattr(material, "smart_paint_suite", None)
    if settings is None:
        raise SPSException("Smart Paint properties are not registered.")
    return settings


def scene_settings(scene: bpy.types.Scene):
    settings = getattr(scene, "smart_paint_suite", None)
    if settings is None:
        raise SPSException("Smart Paint scene properties are not registered.")
    return settings


def _jsonable_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if hasattr(value, "to_list"):
        try:
            return value.to_list()
        except Exception:
            pass
    if isinstance(value, (list, tuple)):
        return [_jsonable_value(item) for item in value]
    try:
        return list(value)
    except Exception:
        return value


def serialize_sps_layer(layer) -> dict:
    payload = {}
    for prop_name in LAYER_SNAPSHOT_PROPS:
        if hasattr(layer, prop_name):
            payload[prop_name] = _jsonable_value(getattr(layer, prop_name))
    return payload


def serialize_sps_material(material: bpy.types.Material) -> dict:
    settings = material_settings(material)
    return {
        "schema": "smart_paint_suite_stack_snapshot",
        "schema_version": 1,
        "created_at": datetime.utcnow().isoformat(timespec='seconds') + "Z",
        "material_name": material.name,
        "settings": {prop_name: _jsonable_value(getattr(settings, prop_name)) for prop_name in MATERIAL_SNAPSHOT_PROPS if hasattr(settings, prop_name)},
        "layers": [serialize_sps_layer(layer) for layer in settings.layers],
    }


def _write_text_block(text_block, content: str) -> None:
    try:
        text_block.clear()
    except Exception:
        while getattr(text_block, 'lines', None):
            try:
                text_block.lines.remove(text_block.lines[0])
            except Exception:
                break
    text_block.write(content)


def _text_block_string(text_block) -> str:
    if text_block is None:
        return ""
    if hasattr(text_block, "as_string"):
        try:
            return text_block.as_string()
        except Exception:
            pass
    try:
        return "\n".join(line.body for line in text_block.lines)
    except Exception:
        return ""


def create_stack_snapshot(material: bpy.types.Material, reason: str = "Manual snapshot", manual: bool = True, scene: Optional[bpy.types.Scene] = None):
    payload = serialize_sps_material(material)
    payload["reason"] = reason
    prefix = "SPS_Snapshot_" if manual else "SPS_AutoSnapshot_"
    base_name = f"{prefix}{slugify(material.name)}"
    if manual:
        text_block = bpy.data.texts.new(name=unique_name(bpy.data.texts, base_name))
    else:
        text_block = bpy.data.texts.get(base_name) or bpy.data.texts.new(name=base_name)
    _write_text_block(text_block, json.dumps(payload, ensure_ascii=False, indent=2))
    settings = material_settings(material)
    settings.last_snapshot_text = text_block.name
    if scene is not None:
        try:
            scene.smart_paint_suite.snapshot_text_name = text_block.name
        except Exception:
            pass
    return text_block


def auto_snapshot_material_stack(context: bpy.types.Context, material: bpy.types.Material, reason: str = "Auto snapshot"):
    try:
        scn_settings = scene_settings(context.scene)
        if not getattr(scn_settings, 'auto_snapshot_major_actions', False):
            return None
    except Exception:
        return None
    try:
        return create_stack_snapshot(material, reason=reason, manual=False, scene=context.scene)
    except Exception:
        return None


def resolve_snapshot_text(material: bpy.types.Material, scene: Optional[bpy.types.Scene] = None):
    scene_name = ""
    if scene is not None:
        try:
            scene_name = scene.smart_paint_suite.snapshot_text_name
        except Exception:
            scene_name = ""
    for name in filter(None, [scene_name, getattr(material_settings(material), 'last_snapshot_text', '')]):
        text_block = bpy.data.texts.get(name)
        if text_block is not None:
            return text_block
    return None


def _clear_layer_collection(layers) -> None:
    if hasattr(layers, 'clear'):
        try:
            layers.clear()
            return
        except Exception:
            pass
    while len(layers):
        layers.remove(len(layers) - 1)


def restore_stack_snapshot(material: bpy.types.Material, text_block) -> dict:
    raw = _text_block_string(text_block)
    if not raw.strip():
        raise SPSException("The selected snapshot text is empty.")
    try:
        payload = json.loads(raw)
    except Exception as exc:
        raise SPSException(f"Snapshot JSON could not be parsed: {exc}") from exc
    if payload.get('schema') != 'smart_paint_suite_stack_snapshot':
        raise SPSException("The selected text is not a Smart Paint snapshot.")

    settings = material_settings(material)
    for prop_name, value in payload.get('settings', {}).items():
        if not hasattr(settings, prop_name):
            continue
        try:
            setattr(settings, prop_name, tuple(value) if isinstance(value, list) else value)
        except Exception:
            pass

    _clear_layer_collection(settings.layers)
    for layer_payload in payload.get('layers', []):
        layer = settings.layers.add()
        for prop_name, value in layer_payload.items():
            if not hasattr(layer, prop_name):
                continue
            if prop_name == 'layer_id' and not value:
                value = unique_short_id()
            try:
                setattr(layer, prop_name, tuple(value) if isinstance(value, list) else value)
            except Exception:
                pass
        ensure_layer_id(layer)

    validate_layer_references(material, auto_create_ids=True)
    settings.active_layer_index = sanitize_index(getattr(settings, 'active_layer_index', 0), len(settings.layers))
    settings.last_snapshot_text = getattr(text_block, 'name', '')
    return payload


def material_status_summary(material: bpy.types.Material) -> dict:
    fallback = {
        'layers': 0,
        'images': 0,
        'missing_images': 0,
        'missing_files': 0,
        'enabled_channels': 0,
        'linked_mesh_maps': 0,
        'active_target': '-',
        'snapshot_name': '',
    }
    if material is None:
        return fallback.copy()
    try:
        settings = material_settings(material)
    except Exception:
        return fallback.copy()

    layers = tuple(getattr(settings, 'layers', ()) or ())
    enabled_channels = 0
    missing_images = 0
    missing_files = 0
    linked_mesh_maps = 0
    try:
        active_layer = get_active_layer(material)
    except Exception:
        active_layer = None
    try:
        active_channel = getattr(settings, 'active_paint_channel', 'BASE_COLOR')
    except Exception:
        active_channel = 'BASE_COLOR'

    for layer in layers:
        layer_enabled = bool(getattr(layer, 'enabled', True))
        for channel in ('BASE_COLOR', 'ROUGHNESS', 'METALLIC', 'NORMAL', 'HEIGHT', 'EMISSION', 'ALPHA', 'AO'):
            enabled_attr = layer_channel_enabled_attr(channel)
            image_attr = layer_channel_image_attr(channel)
            try:
                channel_enabled = bool(getattr(layer, enabled_attr, False))
            except Exception:
                channel_enabled = False
            if not channel_enabled or not layer_enabled:
                continue
            enabled_channels += 1
            try:
                requires_image = layer_channel_requires_image(layer, channel)
            except Exception:
                requires_image = False
            image_name = getattr(layer, image_attr, '')
            image = bpy.data.images.get(image_name) if image_name else None
            if image is None:
                if requires_image:
                    missing_images += 1
                continue
            if getattr(image, 'packed_file', None):
                continue
            source = getattr(image, 'source', '')
            if source == 'GENERATED':
                continue
            path = image_abs_filepath(image)
            if path:
                if not os.path.exists(path):
                    missing_files += 1
            elif source not in {'TILED'}:
                missing_files += 1
        if layer_enabled and getattr(layer, 'mask_mode', '') == 'IMAGE':
            mask_name = getattr(layer, 'mask_image', '')
            if not mask_name or bpy.data.images.get(mask_name) is None:
                missing_images += 1

    for attr in ('ao_map', 'normal_map', 'position_map', 'curvature_map', 'thickness_map'):
        image_name = getattr(settings, attr, '')
        image = bpy.data.images.get(image_name) if image_name else None
        if image is None:
            continue
        linked_mesh_maps += 1
        if getattr(image, 'packed_file', None):
            continue
        source = getattr(image, 'source', '')
        if source == 'GENERATED':
            continue
        path = image_abs_filepath(image)
        if path:
            if not os.path.exists(path):
                missing_files += 1
        elif source not in {'TILED'}:
            missing_files += 1
    return {
        'layers': len(layers),
        'images': sum(1 for _ in iter_sps_images(material)),
        'missing_images': missing_images,
        'missing_files': missing_files,
        'enabled_channels': enabled_channels,
        'linked_mesh_maps': linked_mesh_maps,
        'active_target': f"{getattr(active_layer, 'name', '-')} / {active_channel}" if active_layer else active_channel,
        'snapshot_name': getattr(settings, 'last_snapshot_text', ''),
    }


def write_named_text_block(name: str, content: str, unique: bool = False):
    texts = getattr(getattr(bpy, 'data', None), 'texts', None)
    if texts is None:
        raise SPSException("Blender text datablocks are not available.")
    if unique:
        text_block = texts.new(name=unique_name(texts, name))
    else:
        text_block = texts.get(name) or texts.new(name=name)
    _write_text_block(text_block, content)
    return text_block


def image_abs_filepath(image: bpy.types.Image) -> str:
    raw = getattr(image, 'filepath', '') or getattr(image, 'filepath_raw', '') or ''
    if not raw:
        return ''
    try:
        return os.path.abspath(bpy.path.abspath(raw))
    except Exception:
        try:
            return os.path.abspath(raw)
        except Exception:
            return ''


def image_exists_on_disk(image: bpy.types.Image) -> bool:
    path = image_abs_filepath(image)
    if not path:
        return False
    if os.path.exists(path):
        return True
    basename = os.path.basename(path)
    directory = os.path.dirname(path) or os.getcwd()
    if not os.path.isdir(directory):
        return False
    if '<UDIM>' not in basename and '<UVTILE>' not in basename:
        return False
    regex_text = re.escape(basename)
    regex_text = regex_text.replace(re.escape('<UDIM>'), r'1\d{3}')
    regex_text = regex_text.replace(re.escape('<UVTILE>'), r'u\d+_v\d+')
    pattern = re.compile(rf'^{regex_text}$', flags=re.IGNORECASE)
    try:
        return any(pattern.match(entry) for entry in os.listdir(directory))
    except Exception:
        return False


def build_material_audit_report(material: bpy.types.Material, obj: Optional[bpy.types.Object] = None, scene: Optional[bpy.types.Scene] = None) -> str:
    settings = material_settings(material)
    now = datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    summary = material_status_summary(material)
    lines: list[str] = []
    lines.append('# Smart Paint Audit Report')
    lines.append('')
    lines.append(f'- Generated: {now}')
    lines.append(f'- Material: {material.name}')
    lines.append(f'- Object: {getattr(obj, "name", "-")}')
    lines.append(f'- Layers: {summary["layers"]}')
    lines.append(f'- Images: {summary["images"]}')
    lines.append(f'- Missing Images: {summary["missing_images"]}')
    lines.append(f'- Missing Files: {summary["missing_files"]}')
    lines.append(f'- Enabled Channels: {summary["enabled_channels"]}')
    lines.append(f'- Linked Mesh Maps: {summary["linked_mesh_maps"]}')
    lines.append(f'- Active Target: {summary["active_target"]}')
    lines.append(f'- Snapshot: {summary["snapshot_name"] or "None"}')
    if scene is not None:
        try:
            runtime_log_name = getattr(scene.smart_paint_suite, 'last_runtime_log_text_name', '')
        except Exception:
            runtime_log_name = ''
        lines.append(f'- Runtime Log: {runtime_log_name or "None"}')
    lines.append('')
    lines.append('## Stack Settings')
    lines.append(f'- Resolution: {getattr(settings, "resolution", "-")}')
    lines.append(f'- Float Images: {bool(getattr(settings, "use_float_images", False))}')
    lines.append(f'- UDIM: {bool(getattr(settings, "use_udim", False))}')
    lines.append(f'- Default UV Map: {getattr(settings, "default_uv_map", "") or "<active>"}')
    lines.append(f'- Multiply AO to Base Color: {bool(getattr(settings, "multiply_ao_to_base_color", False))}')
    lines.append(f'- Bump Preview: {bool(getattr(settings, "use_bump_preview", False))}')
    lines.append(f'- Displacement Output: {bool(getattr(settings, "enable_displacement_output", False))}')
    if scene is not None:
        scn_settings = scene_settings(scene)
        lines.append(f'- Export Directory: {getattr(scn_settings, "export_directory", "")}')
        lines.append(f'- Export Resolution: {getattr(scn_settings, "export_resolution", "")}')
        lines.append(f'- Export Format: {getattr(scn_settings, "export_format", "")}')
        lines.append(f'- Packed Layout: {getattr(scn_settings, "packed_export_layout", "")}')
        lines.append(f'- Auto Snapshot Major Actions: {bool(getattr(scn_settings, "auto_snapshot_major_actions", False))}')
        lines.append(f'- Auto Restore on Failure: {bool(getattr(scn_settings, "auto_restore_on_failure", False))}')
    if getattr(settings, 'validation_message', ''):
        lines.append(f'- Validation Message: {settings.validation_message}')
    if obj is not None:
        uv_layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
        uv_names = [layer.name for layer in uv_layers] if uv_layers else []
        lines.append(f'- UV Layers: {", ".join(uv_names) if uv_names else "None"}')
    lines.append('')
    lines.append('## Layer Diagnostics')
    if not settings.layers:
        lines.append('- No managed layers present.')
    id_counts: dict[str, int] = {}
    for layer in settings.layers:
        layer_id = getattr(layer, 'layer_id', '')
        if layer_id:
            id_counts[layer_id] = id_counts.get(layer_id, 0) + 1
    for index, layer in enumerate(settings.layers, start=1):
        issues: list[str] = []
        layer_id = getattr(layer, 'layer_id', '')
        if not layer_id:
            issues.append('missing layer ID')
        elif id_counts.get(layer_id, 0) > 1:
            issues.append('duplicate layer ID')
        uv_name = getattr(layer, 'uv_map', '')
        if obj is not None and uv_name:
            uv_layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
            if uv_layers is not None and uv_layers.get(uv_name) is None:
                issues.append(f"missing UV map '{uv_name}'")
        layer_enabled = bool(getattr(layer, 'enabled', True))
        for channel, info in CHANNEL_INFO.items():
            enabled_attr = layer_channel_enabled_attr(channel)
            image_attr = layer_channel_image_attr(channel)
            if not getattr(layer, enabled_attr, False):
                continue
            if not layer_enabled:
                continue
            image_name = getattr(layer, image_attr, '')
            image = bpy.data.images.get(image_name) if image_name else None
            if image is None:
                if layer_channel_requires_image(layer, channel):
                    issues.append(f"{info['label']}: missing image")
                continue
            expected_cs = info.get('colorspace', '')
            current_cs = ''
            try:
                current_cs = image.colorspace_settings.name
            except Exception:
                current_cs = ''
            if expected_cs and current_cs and current_cs != expected_cs:
                issues.append(f"{info['label']}: colorspace {current_cs} (expected {expected_cs})")
            if getattr(image, 'source', '') not in {'GENERATED', 'TILED'} and not getattr(image, 'packed_file', None) and not image_abs_filepath(image):
                issues.append(f"{info['label']}: unsaved external path")
        mask_mode = getattr(layer, 'mask_mode', '')
        if mask_mode == 'IMAGE' and layer_enabled:
            mask_name = getattr(layer, 'mask_image', '')
            if not mask_name or bpy.data.images.get(mask_name) is None:
                issues.append('mask image missing')
        elif mask_mode == 'ANCHOR':
            anchor_id = getattr(layer, 'anchor_layer_id', '')
            anchor_name = getattr(layer, 'anchor_layer_name', '')
            anchor_target = find_layer_by_id(material, anchor_id) if anchor_id else None
            if anchor_target is None and anchor_name:
                for candidate in settings.layers:
                    if candidate.name == anchor_name:
                        anchor_target = candidate
                        break
            if anchor_target is None:
                issues.append('broken anchor reference')
            elif anchor_target == layer:
                issues.append('self-anchor reference')
            elif _anchor_would_create_cycle(layer, anchor_target, {getattr(item, 'layer_id', ''): item for item in settings.layers}, {item.name: item for item in settings.layers}):
                issues.append('cyclic anchor reference')
            if getattr(layer, 'anchor_channel', '') not in VALID_CHANNELS:
                issues.append('invalid anchor channel')
        elif mask_mode in {'VERTEX_COLOR', 'COLOR_ID'}:
            attr_name = getattr(layer, 'vertex_color_attribute', '')
            color_attrs = getattr(getattr(obj, 'data', None), 'color_attributes', None) if obj is not None else None
            attr = color_attrs.get(attr_name) if color_attrs and attr_name else None
            if attr is None:
                issues.append(f"missing color attribute '{attr_name or '-'}'")
            if mask_mode == 'COLOR_ID':
                try:
                    tol = float(getattr(layer, 'color_id_tolerance', 0.0))
                    if tol < 0.0 or tol > 1.0:
                        issues.append('invalid Color ID tolerance')
                except Exception:
                    issues.append('invalid Color ID tolerance')
        elif mask_mode == 'AO_MAP' and not getattr(settings, 'ao_map', ''):
            issues.append('AO mesh map missing')
        elif mask_mode == 'CURVATURE_MAP' and not getattr(settings, 'curvature_map', ''):
            issues.append('curvature mesh map missing')
        elif mask_mode == 'THICKNESS_MAP' and not getattr(settings, 'thickness_map', ''):
            issues.append('thickness mesh map missing')
        elif mask_mode == 'POSITION_MAP' and not getattr(settings, 'position_map', ''):
            issues.append('position mesh map missing')
        elif mask_mode == 'NORMAL_CULL' and not getattr(settings, 'normal_map', ''):
            issues.append('normal mesh map missing')
        status = 'OK' if not issues else '; '.join(issues)
        kind_key = getattr(layer, 'layer_kind', '?')
        kind_label = LAYER_KIND_LABELS.get(kind_key, kind_key)
        lines.append(f"- [{index:02d}] {layer.name} | {kind_label} | {'enabled' if getattr(layer, 'enabled', True) else 'disabled'} | {status}")
    lines.append('')
    lines.append('## Mesh Maps')
    for attr, label in (('ao_map', 'AO'), ('normal_map', 'Normal'), ('position_map', 'Position'), ('curvature_map', 'Curvature'), ('thickness_map', 'Thickness')):
        image_name = getattr(settings, attr, '')
        image = bpy.data.images.get(image_name) if image_name else None
        if image is None:
            lines.append(f'- {label}: missing')
            continue
        path = image_abs_filepath(image)
        location = 'packed' if getattr(image, 'packed_file', None) else (path if path else 'generated/unsaved')
        lines.append(f'- {label}: {image.name} | {location}')
    lines.append('')
    if scene is not None:
        scn_settings = scene_settings(scene)
        lines.append('## Projection Buffer')
        buffer_image = getattr(scn_settings, 'projection_buffer_image', None)
        if buffer_image is None:
            lines.append('- No active projection buffer.')
        else:
            projection_layer = find_layer_by_id(material, getattr(scn_settings, 'projection_target_layer_id', '') or '') if getattr(scn_settings, 'projection_target_layer_id', '') else None
            projection_channel = getattr(scn_settings, 'projection_target_channel', '') or DEFAULT_ANCHOR_CHANNEL
            if projection_channel not in VALID_CHANNELS:
                lines.append(f"- Active Buffer: {buffer_image.name} | invalid target channel '{projection_channel}'")
            elif projection_layer is None:
                lines.append(f"- Active Buffer: {buffer_image.name} | missing target layer")
            else:
                image_attr = layer_channel_image_attr(projection_channel)
                current_name = getattr(projection_layer, image_attr, '') if hasattr(projection_layer, image_attr) else ''
                sync_state = 'linked' if current_name == buffer_image.name else f"desynced ({current_name or '-'})"
                lines.append(f"- Active Buffer: {buffer_image.name} | {projection_layer.name} / {projection_channel} | {sync_state}")
        lines.append('')
    lines.append('## Image Inventory')
    images = list(iter_sps_images(material))
    if not images:
        lines.append('- No SPS images linked to this material.')
    for image in images:
        path = image_abs_filepath(image)
        exists = image_exists_on_disk(image)
        packed = bool(getattr(image, 'packed_file', None))
        dirty = bool(getattr(image, 'is_dirty', False))
        try:
            colorspace = image.colorspace_settings.name
        except Exception:
            colorspace = '-'
        status_bits = []
        source = getattr(image, 'source', '')
        if packed:
            status_bits.append('packed')
        elif source == 'GENERATED':
            status_bits.append('generated')
        else:
            status_bits.append('external')
        status_bits.append('dirty' if dirty else 'clean')
        if source == 'TILED':
            status_bits.append('udim')
        if path:
            status_bits.append('exists' if exists else 'missing-file')
        elif source == 'GENERATED':
            status_bits.append('memory-only')
        else:
            status_bits.append('no-path')
        size = 'x'.join(str(int(v)) for v in getattr(image, 'size', (0, 0))[:2])
        lines.append(f"- {image.name} | {size} | {colorspace} | {', '.join(status_bits)} | {path or '-'}")
    lines.append('')
    lines.append('## Recommendations')
    recommendations: list[str] = []
    if summary['missing_images'] > 0:
        recommendations.append('Run Health Check or Validate to recreate or relink missing images.')
    if any(not image_exists_on_disk(img) and not getattr(img, 'packed_file', None) and getattr(img, 'source', '') != 'GENERATED' for img in images):
        recommendations.append('Use Repair Missing Paths or Consolidate Textures to normalize file locations.')
    if not summary['snapshot_name']:
        recommendations.append('Create a stack snapshot or enable Auto Snapshot Major Actions before large edits.')
    if obj is not None and not getattr(getattr(obj, 'data', None), 'uv_layers', None):
        recommendations.append('Run Auto UV Setup because the mesh currently has no UV layer.')
    if obj is not None:
        color_attrs = getattr(getattr(obj, 'data', None), 'color_attributes', None)
        if any(getattr(layer, 'mask_mode', '') in {'VERTEX_COLOR', 'COLOR_ID'} for layer in settings.layers) and not color_attrs:
            recommendations.append('Create a color attribute before using Vertex Color or Color ID masks.')
    if scene is not None and getattr(scene.smart_paint_suite, 'last_runtime_log_text_name', ''):
        recommendations.append('Open the latest Runtime Log text datablock to inspect the last operator failure in detail.')
    if not recommendations:
        recommendations.append('No critical issues were detected by the static audit.')
    for recommendation in recommendations:
        lines.append(f'- {recommendation}')
    return '\n'.join(lines) + '\n'



def slugify(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    return value or "Layer"


def unique_short_id() -> str:
    return uuid.uuid4().hex[:8]


def ensure_layer_id(layer) -> str:
    if not getattr(layer, "layer_id", ""):
        layer.layer_id = unique_short_id()
    return layer.layer_id


def unique_name(container: Iterable, base_name: str) -> str:
    names = {item.name for item in container}
    if base_name not in names:
        return base_name
    i = 1
    while True:
        candidate = f"{base_name}.{i:03d}"
        if candidate not in names:
            return candidate
        i += 1


def unique_node_name(node_tree: bpy.types.NodeTree, base_name: str) -> str:
    names = {node.name for node in node_tree.nodes}
    if base_name not in names:
        return base_name
    idx = 1
    while True:
        candidate = f"{base_name}_{idx:03d}"
        if candidate not in names:
            return candidate
        idx += 1


def make_image_name(material_name: str, layer_name: str, channel_suffix: str) -> str:
    return f"{IMAGE_PREFIX}{slugify(material_name)}_{slugify(layer_name)}_{channel_suffix}"


def clean_temp_data_name(name: str) -> bool:
    return name.startswith(TEMP_PREFIX) or name.startswith(NODE_PREFIX)


def is_sps_node(node: bpy.types.Node) -> bool:
    return node.name.startswith(NODE_PREFIX) or bool(node.get("sps_node"))


def is_sps_group(node_group: bpy.types.NodeTree) -> bool:
    return node_group.name.startswith(NODE_PREFIX) or node_group.name.startswith("SPS_GROUP_")


def mark_node(node: bpy.types.Node, layer_id: str = "", channel: str = "") -> bpy.types.Node:
    node["sps_node"] = True
    if layer_id:
        node["sps_layer_id"] = layer_id
    if channel:
        node["sps_channel"] = channel
    return node


def remove_sps_nodes(node_tree: bpy.types.NodeTree) -> None:
    for node in list(node_tree.nodes):
        if is_sps_node(node):
            node_tree.nodes.remove(node)


def remove_orphan_sps_data() -> dict[str, int]:
    removed = {"images": 0, "groups": 0, "materials": 0}
    for image in list(bpy.data.images):
        if image.name.startswith(IMAGE_PREFIX) and image.users == 0:
            image['sps_deferred_orphan_image'] = True
            removed["images"] += 1
    for group in list(bpy.data.node_groups):
        if is_sps_group(group) and group.users == 0:
            bpy.data.node_groups.remove(group)
            removed["groups"] += 1
    for material in list(bpy.data.materials):
        if material.name.startswith(f"{IMAGE_PREFIX}TMP_") and material.users == 0:
            material['sps_deferred_orphan_material'] = True
            removed["materials"] += 1
    return removed


def set_material_alpha_mode(material: bpy.types.Material, use_alpha: bool = True) -> None:
    try:
        if hasattr(material, "blend_method"):
            material.blend_method = 'BLEND' if use_alpha else 'OPAQUE'
        if hasattr(material, "shadow_method"):
            material.shadow_method = 'HASHED' if use_alpha else 'OPAQUE'
        if hasattr(material, "surface_render_method") and use_alpha:
            # Blender 5.x compatible property on some builds.
            try:
                material.surface_render_method = 'DITHERED'
            except Exception:
                pass
    except Exception:
        pass


def socket_by_names(sockets, names: Iterable[str]):
    for name in names:
        if name in sockets:
            return sockets[name]
    for socket in sockets:
        if socket.name in names:
            return socket
    return None


def ensure_uv_map(obj: bpy.types.Object, uv_name: str = DEFAULT_UV_NAME) -> str:
    mesh = obj.data
    uv_layers = getattr(mesh, "uv_layers", None)
    if uv_layers is None:
        raise SPSException("The active object does not support UV layers.")
    if len(uv_layers) == 0:
        uv_layers.new(name=uv_name)
    active = uv_layers.active or uv_layers[0]
    return active.name

def _triangle_area_uv_coords(uv0, uv1, uv2) -> float:
    return abs(((uv1.x - uv0.x) * (uv2.y - uv0.y)) - ((uv2.x - uv0.x) * (uv1.y - uv0.y))) * 0.5


def uv_layer_has_area(mesh, uv_layer, min_area: float = 1e-8) -> bool:
    loops = getattr(mesh, "loops", None)
    uv_data = getattr(uv_layer, "data", None)
    polygons = getattr(mesh, "polygons", None)
    if loops is None or uv_data is None or polygons is None:
        return False
    total = 0.0
    for poly in polygons:
        loop_indices = list(getattr(poly, 'loop_indices', ()))
        if len(loop_indices) < 3:
            continue
        base = loop_indices[0]
        for idx in range(1, len(loop_indices) - 1):
            tri = (base, loop_indices[idx], loop_indices[idx + 1])
            try:
                uv0 = uv_data[tri[0]].uv
                uv1 = uv_data[tri[1]].uv
                uv2 = uv_data[tri[2]].uv
            except Exception:
                continue
            total += _triangle_area_uv_coords(uv0, uv1, uv2)
            if total > min_area:
                return True
    return total > min_area


def run_auto_uv_workflow(context: bpy.types.Context, obj: bpy.types.Object, margin: float = 0.005, angle_limit: float = 66.0) -> str:
    uv_name = ensure_uv_map(obj)
    margin = max(0.0, float(margin))
    with preserve_mode(context):
        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        try:
            bpy.ops.uv.smart_project(angle_limit=float(angle_limit), island_margin=margin)
        except TypeError:
            bpy.ops.uv.smart_project(angle_limit=float(angle_limit))
        except Exception:
            bpy.ops.uv.smart_project()
        try:
            bpy.ops.uv.average_islands_scale()
        except Exception:
            pass
        try:
            bpy.ops.uv.pack_islands(margin=margin)
        except Exception:
            pass
    mesh = obj.data
    uv_layers = getattr(mesh, 'uv_layers', None)
    if uv_layers:
        active = uv_layers.active or uv_layers[0]
        return active.name
    return uv_name


def find_material_slot_index(obj: bpy.types.Object, material: bpy.types.Material) -> int:
    for i, slot in enumerate(obj.material_slots):
        if slot.material == material:
            return i
    return -1


def find_node_by_tag(node_tree: bpy.types.NodeTree, layer_id: str, channel: str) -> Optional[bpy.types.Node]:
    for node in node_tree.nodes:
        if node.get("sps_layer_id") == layer_id and node.get("sps_channel") == channel:
            return node
    return None


def get_active_layer(material) -> Optional[object]:
    settings = material_settings(material)
    if not settings.layers:
        return None
    idx = max(0, min(settings.active_layer_index, len(settings.layers) - 1))
    settings.active_layer_index = idx
    return settings.layers[idx]


def sanitize_index(index: int, length: int) -> int:
    return max(0, min(index, max(0, length - 1)))


def active_layer_index(settings) -> int:
    settings.active_layer_index = sanitize_index(settings.active_layer_index, len(settings.layers))
    return settings.active_layer_index


def _reserved_image_filepaths() -> set[str]:
    reserved: set[str] = set()
    try:
        images = getattr(getattr(bpy, 'data', None), 'images', ())
    except Exception:
        images = ()
    for image in images:
        for attr in ('filepath_raw', 'filepath'):
            value = getattr(image, attr, '') or ''
            if not value:
                continue
            try:
                abs_path = os.path.abspath(bpy.path.abspath(value))
            except Exception:
                try:
                    abs_path = os.path.abspath(value)
                except Exception:
                    continue
            reserved.add(os.path.normcase(abs_path))
    return reserved


def safe_image_filepath(base_dir: str, image_name: str, ext: str = ".png") -> str:
    abs_base_dir = bpy.path.abspath(base_dir)
    os.makedirs(abs_base_dir, exist_ok=True)
    ext = ext if ext.startswith('.') else f'.{ext}'
    placeholder = '<UDIM>' if '<UDIM>' in image_name else ''
    stem = image_name.replace('<UDIM>', '').strip() if placeholder else image_name
    stem = slugify(stem).lower()
    if placeholder:
        stem = f"{stem}_{placeholder}"

    reserved = _reserved_image_filepaths()

    def is_available(path: str) -> bool:
        norm = os.path.normcase(os.path.abspath(path))
        return norm not in reserved and not os.path.exists(path)

    candidate = os.path.abspath(os.path.join(abs_base_dir, f"{stem}{ext}"))
    if is_available(candidate):
        return candidate
    index = 1
    while True:
        candidate = os.path.abspath(os.path.join(abs_base_dir, f"{stem}_{index:03d}{ext}"))
        if is_available(candidate):
            return candidate
        index += 1


def channel_prop_name(channel: str) -> str:
    return channel.lower()


def layer_channel_image_attr(channel: str) -> str:
    return f"{channel.lower()}_image"


def layer_channel_enabled_attr(channel: str) -> str:
    return f"use_{channel.lower()}"


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def clampf(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def _sanitize_enum_value(owner, prop_name: str, valid_values: set[str], fallback: str, label: str | None = None) -> str | None:
    if not hasattr(owner, prop_name):
        return None
    try:
        value = str(getattr(owner, prop_name, '') or '')
    except Exception:
        value = ''
    if value in valid_values:
        return None
    safe_value = fallback if fallback in valid_values else next(iter(valid_values), fallback)
    try:
        setattr(owner, prop_name, safe_value)
    except Exception:
        return None
    target_label = label or prop_name.replace('_', ' ')
    owner_name = getattr(owner, 'name', 'item')
    if value:
        return f"Repaired invalid {target_label} '{value}' on '{owner_name}'."
    return f"Filled missing {target_label} on '{owner_name}'."


def _sanitize_float_prop(owner, prop_name: str, minimum: float, maximum: float, label: str | None = None, fallback: float | None = None) -> str | None:
    if not hasattr(owner, prop_name):
        return None
    try:
        value = float(getattr(owner, prop_name))
    except Exception:
        value = fallback if fallback is not None else minimum
    clamped = clampf(value, minimum, maximum)
    if abs(clamped - value) <= 1e-8:
        return None
    try:
        setattr(owner, prop_name, clamped)
    except Exception:
        return None
    target_label = label or prop_name.replace('_', ' ')
    owner_name = getattr(owner, 'name', 'item')
    return f"Clamped {target_label} on '{owner_name}'."


def _sanitize_vector_prop(owner, prop_name: str, minimums: tuple[float, ...], maximums: tuple[float, ...], label: str | None = None) -> str | None:
    if not hasattr(owner, prop_name):
        return None
    try:
        raw = tuple(float(v) for v in getattr(owner, prop_name))
    except Exception:
        raw = tuple(minimums)
    if len(raw) != len(minimums):
        raw = tuple(minimums)
    clamped = tuple(clampf(raw[i], minimums[i], maximums[i]) for i in range(len(minimums)))
    if all(abs(a - b) <= 1e-8 for a, b in zip(raw, clamped)):
        return None
    try:
        setattr(owner, prop_name, clamped)
    except Exception:
        return None
    target_label = label or prop_name.replace('_', ' ')
    owner_name = getattr(owner, 'name', 'item')
    return f"Clamped {target_label} on '{owner_name}'."


def rgb_from_value(value: float) -> tuple[float, float, float, float]:
    v = clamp01(value)
    return (v, v, v, 1.0)


def prop_exists(obj, prop_name: str) -> bool:
    return hasattr(obj, prop_name)


def draw_prop_if_exists(layout, data, prop_name: str, **kwargs) -> bool:
    if hasattr(data, prop_name):
        layout.prop(data, prop_name, **kwargs)
        return True
    return False


def list_uv_names(obj: bpy.types.Object) -> list[tuple[str, str, str]]:
    uv_layers = getattr(obj.data, "uv_layers", None)
    if not uv_layers:
        return [(DEFAULT_UV_NAME, DEFAULT_UV_NAME, DEFAULT_UV_NAME)]
    items = []
    for layer in uv_layers:
        items.append((layer.name, layer.name, layer.name))
    return items or [(DEFAULT_UV_NAME, DEFAULT_UV_NAME, DEFAULT_UV_NAME)]


def _resolve_anchor_target(layer, id_map: dict[str, object], name_map: dict[str, object]):
    target = None
    anchor_id = getattr(layer, 'anchor_layer_id', '')
    anchor_name = getattr(layer, 'anchor_layer_name', '')
    if anchor_id:
        target = id_map.get(anchor_id)
    if target is None and anchor_name:
        target = name_map.get(anchor_name)
    return target


def _anchor_would_create_cycle(layer, target, id_map: dict[str, object], name_map: dict[str, object]) -> bool:
    if target is None:
        return False
    visited = {layer}
    current = target
    while current is not None:
        if current in visited:
            return True
        visited.add(current)
        if getattr(current, 'mask_mode', '') != 'ANCHOR':
            return False
        current = _resolve_anchor_target(current, id_map, name_map)
    return False


def sanitize_layer_settings(layer, color_attribute_fallback: str = DEFAULT_VERTEX_COLOR_NAME) -> list[str]:
    messages: list[str] = []
    for prop_name, valid_values, fallback, label in (
        ('layer_kind', VALID_LAYER_KINDS, DEFAULT_LAYER_KIND, 'layer kind'),
        ('blend_mode', VALID_BLEND_MODES, DEFAULT_BLEND_MODE, 'blend mode'),
        ('projection_mode', VALID_PROJECTION_MODES, DEFAULT_PROJECTION_MODE, 'projection mode'),
        ('mask_mode', VALID_MASK_MODES, DEFAULT_MASK_MODE, 'mask mode'),
        ('mask_channel', VALID_MASK_CHANNELS, DEFAULT_MASK_CHANNEL, 'mask channel'),
        ('anchor_channel', VALID_CHANNELS, DEFAULT_ANCHOR_CHANNEL, 'anchor channel'),
    ):
        msg = _sanitize_enum_value(layer, prop_name, valid_values, fallback, label)
        if msg:
            messages.append(msg)
    for prop_name, limits in LAYER_FLOAT_LIMITS.items():
        msg = _sanitize_float_prop(layer, prop_name, limits[0], limits[1])
        if msg:
            messages.append(msg)
    for prop_name, limits in LAYER_VECTOR_LIMITS.items():
        msg = _sanitize_vector_prop(layer, prop_name, limits[0], limits[1])
        if msg:
            messages.append(msg)
    if getattr(layer, 'mask_mode', '') in {'VERTEX_COLOR', 'COLOR_ID'} and not getattr(layer, 'vertex_color_attribute', ''):
        layer.vertex_color_attribute = color_attribute_fallback
        messages.append(f"Filled missing color attribute name on '{layer.name}'.")
    return messages


def sanitize_projection_buffer_state(
    scene: bpy.types.Scene,
    material: Optional[bpy.types.Material] = None,
    remove_orphan_buffer: bool = True,
    preserve_detached_buffer: bool = False,
) -> list[str]:
    scn = scene_settings(scene)
    messages: list[str] = []
    buffer_image = getattr(scn, 'projection_buffer_image', None)
    target_layer_id = getattr(scn, 'projection_target_layer_id', '') or ''
    target_channel = getattr(scn, 'projection_target_channel', '') or DEFAULT_ANCHOR_CHANNEL
    if target_channel not in VALID_CHANNELS:
        scn.projection_target_channel = DEFAULT_ANCHOR_CHANNEL
        messages.append('Repaired invalid projection target channel.')
        target_channel = DEFAULT_ANCHOR_CHANNEL
    _sanitize_enum_value(scn, 'projection_previous_mode', VALID_PROJECTION_MODES, DEFAULT_PROJECTION_MODE, 'projection previous mode')
    _sanitize_enum_value(scn, 'projection_previous_layer_kind', VALID_LAYER_KINDS, DEFAULT_LAYER_KIND, 'projection previous layer kind')

    def clear_state(reason: str, *, force: bool = False):
        nonlocal buffer_image
        if preserve_detached_buffer and not force and buffer_image is not None:
            messages.append(reason)
            return
        old_buffer = buffer_image
        scn.projection_previous_image_name = ''
        scn.projection_previous_enabled = False
        scn.projection_previous_mode = DEFAULT_PROJECTION_MODE
        scn.projection_previous_layer_kind = DEFAULT_LAYER_KIND
        scn.projection_source_image_name = ''
        scn.projection_target_layer_id = ''
        scn.projection_target_channel = DEFAULT_ANCHOR_CHANNEL
        scn.projection_buffer_image = None
        buffer_image = None
        if remove_orphan_buffer and old_buffer is not None and getattr(old_buffer, 'users', 0) == 0:
            try:
                old_buffer['sps_deferred_orphan_image'] = True
            except Exception:
                pass
        messages.append(reason)

    if buffer_image is None:
        if target_layer_id or getattr(scn, 'projection_previous_image_name', '') or getattr(scn, 'projection_source_image_name', ''):
            clear_state('Cleared stale projection-buffer state without a buffer image.', force=True)
        return messages

    if material is None:
        if not target_layer_id:
            clear_state('Cleared orphan projection buffer that had no target layer.', force=not preserve_detached_buffer)
        return messages

    if not target_layer_id:
        clear_state('Projection buffer target metadata is missing, but the detached buffer can still be committed.', force=not preserve_detached_buffer)
        return messages

    layer = find_layer_by_id(material, target_layer_id)
    if layer is None:
        clear_state('Projection buffer target layer is missing, but the detached buffer can still be committed.', force=not preserve_detached_buffer)
        return messages

    image_attr = layer_channel_image_attr(target_channel)
    enabled_attr = layer_channel_enabled_attr(target_channel)
    if not hasattr(layer, image_attr) or not hasattr(layer, enabled_attr):
        clear_state('Projection buffer target channel is unavailable, but the detached buffer can still be committed.', force=not preserve_detached_buffer)
        return messages
    current_name = getattr(layer, image_attr, '')
    if current_name != buffer_image.name or not getattr(layer, enabled_attr, False):
        clear_state('Projection buffer layer no longer points to the buffer image, but the detached buffer can still be committed.', force=not preserve_detached_buffer)
        return messages
    return messages


def validate_layer_references(material: bpy.types.Material, auto_create_ids: bool = True) -> list[str]:
    settings = material_settings(material)
    messages = []
    seen_names: set[str] = set()
    seen_ids: set[str] = set()
    id_map: dict[str, object] = {}
    name_map: dict[str, object] = {}
    for index, layer in enumerate(settings.layers):
        if auto_create_ids:
            ensure_layer_id(layer)
        if not layer.name:
            layer.name = f"Layer {index + 1}"
            messages.append(f"Renamed empty layer #{index + 1}.")
        if layer.name in seen_names:
            old_name = layer.name
            layer.name = unique_name(settings.layers, layer.name)
            messages.append(f"Renamed duplicate layer '{old_name}' to '{layer.name}'.")
        seen_names.add(layer.name)

        layer_id = getattr(layer, 'layer_id', '')
        if not layer_id or layer_id in seen_ids:
            old_id = layer_id
            layer.layer_id = unique_short_id()
            if old_id:
                messages.append(f"Regenerated duplicate layer ID on '{layer.name}'.")
            else:
                messages.append(f"Generated missing layer ID on '{layer.name}'.")
        seen_ids.add(layer.layer_id)

        messages.extend(sanitize_layer_settings(layer))
        id_map[getattr(layer, 'layer_id', '')] = layer
        name_map[layer.name] = layer

    for layer in settings.layers:
        if getattr(layer, 'mask_mode', '') != 'ANCHOR':
            continue
        target = _resolve_anchor_target(layer, id_map, name_map)
        if target is None or target == layer:
            if getattr(layer, 'anchor_layer_id', '') or getattr(layer, 'anchor_layer_name', ''):
                messages.append(f"Cleared broken anchor reference on '{layer.name}'.")
            layer.anchor_layer_id = ''
            layer.anchor_layer_name = ''
            continue
        if _anchor_would_create_cycle(layer, target, id_map, name_map):
            layer.anchor_layer_id = ''
            layer.anchor_layer_name = ''
            messages.append(f"Cleared cyclic anchor reference on '{layer.name}'.")
            continue
        layer.anchor_layer_id = getattr(target, 'layer_id', '')
        layer.anchor_layer_name = target.name

    settings.active_layer_index = sanitize_index(settings.active_layer_index, len(settings.layers))
    return messages
def switch_object_mode(context: bpy.types.Context, mode: str) -> None:
    obj = context.object
    if not obj:
        raise SPSException("No active object.")
    if obj.mode == mode:
        return
    bpy.ops.object.mode_set(mode=mode)


def iter_sps_images(material: bpy.types.Material):
    settings = material_settings(material)
    seen = set()
    layer_image_attrs = (
        "base_color_image",
        "roughness_image",
        "metallic_image",
        "normal_image",
        "height_image",
        "emission_image",
        "alpha_image",
        "ao_image",
        "mask_image",
    )
    for layer in settings.layers:
        for attr in layer_image_attrs:
            image_name = getattr(layer, attr, "")
            if not image_name or image_name in seen:
                continue
            image = bpy.data.images.get(image_name)
            if image is None:
                continue
            seen.add(image_name)
            yield image
    for attr in ("ao_map", "normal_map", "position_map", "curvature_map", "thickness_map"):
        image_name = getattr(settings, attr, "")
        if not image_name or image_name in seen:
            continue
        image = bpy.data.images.get(image_name)
        if image is None:
            continue
        seen.add(image_name)
        yield image


def iter_sps_related_images(material: bpy.types.Material | None = None, scene: bpy.types.Scene | None = None):
    seen = set()

    def yield_image(image):
        if image is None:
            return
        name = getattr(image, 'name', '') or ''
        if not name or name in seen:
            return
        seen.add(name)
        return image

    if material is not None:
        for image in iter_sps_images(material):
            yielded = yield_image(image)
            if yielded is not None:
                yield yielded
    if scene is not None:
        scn = scene_settings(scene)
        direct_images = [
            getattr(scn, 'projection_image', None),
            getattr(scn, 'projection_buffer_image', None),
        ]
        named_images = [
            bpy.data.images.get(getattr(scn, 'projection_source_image_name', '') or ''),
            bpy.data.images.get(getattr(scn, 'last_external_edit_image_name', '') or ''),
        ]
        for image in direct_images + named_images:
            yielded = yield_image(image)
            if yielded is not None:
                yield yielded


def find_layer_by_id(material: bpy.types.Material, layer_id: str):
    settings = material_settings(material)
    for layer in settings.layers:
        if getattr(layer, "layer_id", "") == layer_id:
            return layer
    return None


def layer_channel_requires_image(layer, channel: str) -> bool:
    """Return whether the given layer/channel should be treated as image-driven for validation and audit."""
    layer_kind = getattr(layer, 'layer_kind', '') or 'PAINT'
    if layer_kind in {'PAINT', 'PBR_PAINT', 'DECAL'}:
        return True
    if channel == 'ALPHA' and layer_kind == 'DECAL':
        return True
    return False


def ensure_color_attribute(mesh, name: str, domain: str = 'CORNER', type_name: str = 'BYTE_COLOR'):
    attrs = getattr(mesh, "color_attributes", None)
    if attrs is None:
        raise SPSException("The active mesh does not support color attributes.")
    clean_name = str(name or '').strip() or DEFAULT_COLOR_ATTRIBUTE_NAME or DEFAULT_VERTEX_COLOR_NAME or 'SPS_Color'
    attr = attrs.get(clean_name)
    if attr is None:
        try:
            attr = attrs.new(name=clean_name, type=type_name, domain=domain)
        except TypeError:
            attr = attrs.new(name=clean_name, type=type_name)
    return attr


def set_active_color_attribute(mesh, attr) -> None:
    attrs = getattr(mesh, "color_attributes", None)
    if attrs is None or attr is None:
        raise SPSException("Color attributes are not available.")
    try:
        attrs.active_color = attr
    except Exception:
        pass
    try:
        attrs.active = attr
    except Exception:
        pass
    try:
        index = list(attrs).index(attr)
    except Exception:
        index = -1
    if index >= 0:
        for prop_name in ("active_color_index", "active_index", "render_color_index"):
            if hasattr(attrs, prop_name):
                try:
                    setattr(attrs, prop_name, index)
                except Exception:
                    pass


IMAGE_FILE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".exr", ".bmp", ".webp", ".hdr")
_UDIM_FILENAME_RE = re.compile(r"(?<!\d)(1\d{3})(?!\d)")
_UVTILE_FILENAME_RE = re.compile(r"(?<![A-Za-z0-9])(u\d+_v\d+)(?![A-Za-z0-9])", flags=re.IGNORECASE)


def _replace_last_match(text: str, pattern: re.Pattern[str], replacement: str) -> str | None:
    matches = list(pattern.finditer(text))
    if not matches:
        return None
    start, end = matches[-1].span(1 if pattern.groups else 0)
    return f"{text[:start]}{replacement}{text[end:]}"



def filename_udim_placeholder(filename: str) -> str | None:
    if not filename:
        return None
    if '<UDIM>' in filename or '<UVTILE>' in filename:
        return filename
    replaced = _replace_last_match(filename, _UDIM_FILENAME_RE, '<UDIM>')
    if replaced and replaced != filename:
        return replaced
    replaced = _replace_last_match(filename, _UVTILE_FILENAME_RE, '<UVTILE>')
    if replaced and replaced != filename:
        return replaced
    return None



def _image_fallback_filenames(image: bpy.types.Image) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def add_name(name: str) -> None:
        clean = str(name or '').strip()
        if not clean:
            return
        lower = clean.lower()
        if lower in seen:
            return
        seen.add(lower)
        names.append(clean)

    raw_name = str(getattr(image, 'name', '') or '').strip()
    if not raw_name:
        return names

    root, ext = os.path.splitext(raw_name)
    preferred_exts: list[str] = []
    if ext.lower() in IMAGE_FILE_EXTENSIONS:
        preferred_exts.append(ext.lower())
    file_format = str(getattr(image, 'file_format', '') or '').upper()
    format_map = {
        'PNG': '.png',
        'JPEG': '.jpg',
        'JPG': '.jpg',
        'TARGA': '.tga',
        'TARGA_RAW': '.tga',
        'TIFF': '.tif',
        'OPEN_EXR': '.exr',
        'OPEN_EXR_MULTILAYER': '.exr',
        'BMP': '.bmp',
        'WEBP': '.webp',
        'HDR': '.hdr',
    }
    guessed_ext = format_map.get(file_format)
    if guessed_ext and guessed_ext not in preferred_exts:
        preferred_exts.append(guessed_ext)
    if getattr(image, 'is_float', False) and '.exr' not in preferred_exts:
        preferred_exts.append('.exr')
    for ext_name in ('.png', '.tif', '.tga', '.jpg', '.webp', '.bmp'):
        if ext_name not in preferred_exts:
            preferred_exts.append(ext_name)

    if ext.lower() in IMAGE_FILE_EXTENSIONS:
        add_name(raw_name)
        add_name(filename_udim_placeholder(raw_name) or '')
    else:
        add_name(raw_name)
        add_name(filename_udim_placeholder(raw_name) or '')
        base_root = root or raw_name
        for ext_name in preferred_exts:
            candidate = f"{base_root}{ext_name}"
            add_name(candidate)
            add_name(filename_udim_placeholder(candidate) or '')
    return names



def image_basename_candidates(image: bpy.types.Image) -> list[str]:
    candidates: list[str] = []
    seen: set[str] = set()
    for attr in ('filepath', 'filepath_raw'):
        raw = getattr(image, attr, '') or ''
        path = bpy.path.abspath(raw) if raw else ''
        base = os.path.basename(path) if path else ''
        for name in (base, filename_udim_placeholder(base) or ''):
            lower = name.lower().strip()
            if lower and lower not in seen:
                seen.add(lower)
                candidates.append(lower)
    for fallback in _image_fallback_filenames(image):
        lower = fallback.lower().strip()
        if lower and lower not in seen:
            seen.add(lower)
            candidates.append(lower)
    return candidates



def image_basename(image: bpy.types.Image) -> str:
    candidates = image_basename_candidates(image)
    return candidates[0] if candidates else f"{image.name}.png"



def build_basename_index(directory: str) -> dict[str, str]:
    mapping, _used_dirs = build_basename_index_multi([directory])
    return mapping



def build_basename_index_multi(directories: Iterable[str]) -> tuple[dict[str, str], list[str]]:
    index: dict[str, str] = {}
    used_dirs: list[str] = []
    seen_dirs: set[str] = set()
    for directory in directories:
        if not directory:
            continue
        root_dir = bpy.path.abspath(directory)
        if not root_dir or not os.path.isdir(root_dir):
            continue
        norm_root = os.path.normcase(os.path.abspath(root_dir))
        if norm_root in seen_dirs:
            continue
        seen_dirs.add(norm_root)
        used_dirs.append(os.path.abspath(root_dir))
        for current_root, _dirs, files in os.walk(root_dir):
            for filename in sorted(files):
                lower = filename.lower()
                if not lower.endswith(IMAGE_FILE_EXTENSIONS):
                    continue
                abs_path = os.path.join(current_root, filename)
                index.setdefault(lower, abs_path)
                placeholder = filename_udim_placeholder(filename)
                if placeholder:
                    index.setdefault(placeholder.lower(), abs_path)
    if not used_dirs:
        raise SPSException('No valid search directories were found for path repair.')
    return index, used_dirs



def candidate_image_search_directories(scene: Optional[bpy.types.Scene] = None, material: Optional[bpy.types.Material] = None) -> list[str]:
    candidates: list[str] = []
    seen: set[str] = set()

    def add_directory(directory: str) -> None:
        if not directory:
            return
        try:
            abs_dir = os.path.abspath(bpy.path.abspath(directory))
        except Exception:
            try:
                abs_dir = os.path.abspath(directory)
            except Exception:
                return
        if not os.path.isdir(abs_dir):
            return
        norm = os.path.normcase(abs_dir)
        if norm in seen:
            return
        seen.add(norm)
        candidates.append(abs_dir)

    if scene is not None:
        scn_settings = scene_settings(scene)
        add_directory(resolve_suite_directory(getattr(scn_settings, 'import_directory', '') or '', 'textures', '//textures', create_default=True, create_custom=False))
        add_directory(resolve_suite_directory(getattr(scn_settings, 'consolidate_directory', '') or '', 'textures', '//textures', create_default=True, create_custom=False))
        add_directory(resolve_suite_directory(getattr(scn_settings, 'export_directory', '') or '', 'exports', '//exports', create_default=True, create_custom=False))
        last_external_name = getattr(scn_settings, 'last_external_edit_image_name', '') or ''
        if last_external_name:
            image = bpy.data.images.get(last_external_name)
            if image is not None:
                path = image_abs_filepath(image)
                if path:
                    add_directory(os.path.dirname(path))
    if scn_settings is not None:
        add_directory(resolve_suite_directory(getattr(scn_settings, 'default_image_dir', '') or '', 'textures', '//textures', create_default=True, create_custom=False))
    blend_path = getattr(getattr(bpy, 'data', None), 'filepath', '') or ''
    if blend_path:
        add_directory(os.path.dirname(blend_path))
    if material is not None or scene is not None:
        for image in iter_sps_related_images(material, scene):
            path = image_abs_filepath(image)
            if path:
                add_directory(os.path.dirname(path))
    return candidates



def _target_path_for_relinked_image(image: bpy.types.Image, target: str) -> str:
    candidates = image_basename_candidates(image)
    target_filename = os.path.basename(target)
    for candidate in candidates:
        if '<udim>' in candidate:
            placeholder = filename_udim_placeholder(target_filename)
            if placeholder and '<UDIM>' in placeholder:
                return os.path.join(os.path.dirname(target), placeholder)
        if '<uvtile>' in candidate:
            placeholder = filename_udim_placeholder(target_filename)
            if placeholder and '<UVTILE>' in placeholder:
                return os.path.join(os.path.dirname(target), placeholder)
    return target



def relink_images_by_basename_multi(images: Iterable[bpy.types.Image], directories: Iterable[str]) -> tuple[int, list[str], list[str]]:
    mapping, used_dirs = build_basename_index_multi(directories)
    repaired = 0
    failures: list[str] = []
    for image in images:
        if getattr(image, 'packed_file', None):
            continue
        current = bpy.path.abspath(getattr(image, 'filepath', '') or getattr(image, 'filepath_raw', '') or '')
        source = getattr(image, 'source', '') or ''
        if source == 'GENERATED' and not current:
            continue
        if current and image_exists_on_disk(image):
            continue
        target = None
        for basename in image_basename_candidates(image):
            target = mapping.get(basename)
            if target:
                break
        if not target:
            failures.append(image.name)
            continue
        relink_target = _target_path_for_relinked_image(image, target)
        if any(token in relink_target for token in ('<UDIM>', '<UVTILE>')):
            try:
                image.source = 'TILED'
            except Exception:
                pass
        written = False
        for attr in ('filepath', 'filepath_raw'):
            try:
                setattr(image, attr, relink_target)
                written = True
            except Exception:
                continue
        if not written:
            failures.append(image.name)
            continue
        try:
            image.reload()
        except Exception:
            pass
        repaired += 1
    return repaired, failures, used_dirs



def relink_images_by_basename(images: Iterable[bpy.types.Image], directory: str) -> tuple[int, list[str]]:
    repaired, failures, _used_dirs = relink_images_by_basename_multi(images, [directory])
    return repaired, failures

def udim_tile_number(u: float, v: float) -> int:
    u_index = int(u // 1)
    v_index = int(v // 1)
    return 1001 + u_index + (v_index * 10)


def collect_uv_udim_tiles(obj: bpy.types.Object, uv_map_name: str = "") -> list[int]:
    mesh = getattr(obj, 'data', None)
    uv_layers = getattr(mesh, 'uv_layers', None)
    if not uv_layers:
        return [1001]
    uv_layer = uv_layers.get(uv_map_name) if uv_map_name else (uv_layers.active or uv_layers[0])
    if uv_layer is None:
        return [1001]
    tiles = set()
    data = getattr(uv_layer, 'data', None)
    if data is None:
        return [1001]
    for loop in data:
        uv = getattr(loop, 'uv', None)
        if uv is None:
            continue
        tiles.add(udim_tile_number(float(uv[0]), float(uv[1])))
    if not tiles:
        tiles.add(1001)
    return sorted(t for t in tiles if t >= 1001)


def sync_image_tiles_to_numbers(image: bpy.types.Image, tile_numbers: Iterable[int]) -> int:
    if image is None or getattr(image, 'source', '') != 'TILED' or not hasattr(image, 'tiles'):
        return 0
    existing = {getattr(tile, 'number', None) for tile in image.tiles}
    added = 0
    for number in sorted(set(int(n) for n in tile_numbers if int(n) >= 1001)):
        if number in existing:
            continue
        try:
            image.tiles.new(number)
            added += 1
        except TypeError:
            try:
                image.tiles.new(tile_number=number)
                added += 1
            except Exception:
                continue
        except Exception:
            continue
    return added

# --- Smart Tools unified user_default path patch (2026-03-27) ---
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    default = str(default or "").strip()
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            manifest = os.path.join(current, "blender_manifest.toml")
            if os.path.isfile(manifest):
                with open(manifest, "r", encoding="utf-8") as handle:
                    for raw_line in handle:
                        line = raw_line.strip()
                        if not line.startswith("id"):
                            continue
                        _, _, value = line.partition("=")
                        value = str(value or "").strip().strip('"').strip("'")
                        if value:
                            return value
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        head = default.split(".", 1)[0].strip()
        if head:
            default = head
    return default

def _sps_legacy_smart_tools_version_user_default_root_L2193(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    utils = getattr(bpy, "utils", None)
    if utils is not None:
        ext_fn = getattr(utils, "extension_path_user", None)
        if callable(ext_fn) and package_id:
            call_variants = (
                ((package_id,), {"path": "", "create": create}),
                ((package_id, ""), {"create": create}),
                ((package_id,), {"create": create}),
                ((), {"module": package_id, "path": "", "create": create}),
                ((), {"module": package_id, "create": create}),
            )
            for args, kwargs in call_variants:
                try:
                    value = ext_fn(*args, **kwargs)
                    if value:
                        return str(value)
                except TypeError:
                    continue
                except Exception:
                    continue
    return _blender_user_default_extension_path(package_id or _smart_tools_manifest_extension_id(default=""), create=create)

# Explicit lineage for the historical implementation; a later definition
# supplies the final public API for this module.
_smart_tools_version_user_default_root = _sps_legacy_smart_tools_version_user_default_root_L2193

def _smart_tools_paint_extension_candidates() -> tuple[str, ...]:
    values = []
    try:
        values.extend(list(_extension_module_candidates()))
    except Exception:
        pass
    values.append(ADDON_ID)
    out = []
    for value in values:
        value = _smart_tools_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or (_smart_tools_manifest_extension_id(ADDON_ID),)

def _smart_tools_extension_user_storage_root(create: bool = True) -> str:
    for package_id in _smart_tools_paint_extension_candidates():
        path = _smart_tools_version_user_default_root(package_id, create=create)
        if path:
            return os.path.abspath(str(path))
    return os.path.abspath(_smart_tools_version_user_default_root(ADDON_ID, create=create))

extension_user_storage_root = _smart_tools_extension_user_storage_root

# --- Smart Tools user_default migration patch (2026-03-27) ---
def _smart_tools_manifest_dir() -> str:
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            if os.path.isfile(os.path.join(current, "blender_manifest.toml")):
                return current
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    return os.path.dirname(os.path.abspath(__file__))

def _smart_tools_has_visible_entries(path: str) -> bool:
    try:
        return any(name not in {".DS_Store", "Thumbs.db"} for name in os.listdir(path))
    except Exception:
        return False

def _smart_tools_merge_tree(src: str, dst: str) -> None:
    import shutil
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if name in {".DS_Store", "Thumbs.db"}:
            continue
        src_path = os.path.join(src, name)
        dst_path = os.path.join(dst, name)
        if os.path.isdir(src_path):
            shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        elif os.path.isfile(src_path) and not os.path.exists(dst_path):
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            shutil.copy2(src_path, dst_path)

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    target_path = ""
    config_dir = ""
    scripts_dir = ""
    try:
        manifest_dir = os.path.normpath(_smart_tools_manifest_dir())
        parts = os.path.normpath(manifest_dir).split(os.sep)
        if len(parts) >= 3 and parts[-2] == "user_default" and parts[-3] == "extensions":
            if create:
                os.makedirs(manifest_dir, exist_ok=True)
            return manifest_dir
    except Exception:
        pass
    utils = getattr(bpy, "utils", None)
    if utils is not None:
        ext_fn = getattr(utils, "extension_path_user", None)
        if callable(ext_fn) and package_id:
            call_variants = (
                ((package_id,), {"path": "", "create": create}),
                ((package_id, ""), {"create": create}),
                ((package_id,), {"create": create}),
                ((), {"module": package_id, "path": "", "create": create}),
                ((), {"module": package_id, "create": create}),
            )
            for args, kwargs in call_variants:
                try:
                    value = ext_fn(*args, **kwargs)
                    if value:
                        target_path = str(value)
                        break
                except TypeError:
                    continue
                except Exception:
                    continue
        try:
            config_dir = str(utils.resource_path('USER') or '')
        except Exception:
            config_dir = ''
        if config_dir:
            scripts_dir = os.path.join(config_dir, 'scripts')
    if not target_path and config_dir:
        version_root = os.path.normpath(config_dir)
        target_path = os.path.join(version_root, "extensions", "user_default", package_id)
    if not target_path:
        target_path = _blender_user_default_extension_path(package_id or _smart_tools_manifest_extension_id(default=""), create=create)

    legacy_candidates = []
    if scripts_dir and package_id:
        legacy_candidates.append(os.path.join(scripts_dir, "extensions", "user_default", package_id))
        legacy_candidates.append(os.path.join(scripts_dir, "extensions_user", package_id))
    if config_dir and package_id:
        legacy_candidates.append(os.path.join(os.path.normpath(config_dir), "extensions", "user_default", package_id))
    manifest_dir = _smart_tools_manifest_dir()
    if package_id:
        legacy_candidates.append(os.path.join(manifest_dir, "user_default", package_id))

    if create:
        os.makedirs(target_path, exist_ok=True)

    target_norm = os.path.normcase(os.path.normpath(target_path))
    if not _smart_tools_has_visible_entries(target_path):
        for legacy in legacy_candidates:
            if not legacy:
                continue
            legacy_norm = os.path.normcase(os.path.normpath(legacy))
            if legacy_norm == target_norm:
                continue
            if _smart_tools_has_visible_entries(legacy):
                try:
                    _smart_tools_merge_tree(legacy, target_path)
                except Exception:
                    pass
                break
    return target_path
