# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Data-only dirty registry for explicit Smart Paint save boundaries.

Dirty metadata participates in the same Suite-wide entry/actual-byte LRU as
pixel/document caches.  No Blender RNA/Image object is retained.
"""
from __future__ import annotations

import threading
from typing import Any

from . import resource_quota

_LOCK = threading.RLock()
_DIRTY_SETS = resource_quota.cache("paint.dirty_documents")
_DIRTY_LAYER_SETS = resource_quota.cache("paint.dirty_layers")


def _material_name(material) -> str:
    return str(getattr(material, "name", "") or "")


def _snapshot_key(material, channel: str = "BASE_COLOR") -> tuple[str, str]:
    return (_material_name(material), str(channel or "BASE_COLOR").upper())


def _dirty_layer_key(material, channel: str, layer_id: str) -> tuple[str, str, str]:
    return (*_snapshot_key(material, channel), str(layer_id or ""))


def _record_dirty_runtime(material, channel: str, image, layer_id: str, *, reason: str = "") -> None:
    key = _snapshot_key(material, channel)
    layer_key = _dirty_layer_key(material, channel, layer_id)
    image_name = str(getattr(image, "name", "") or "")
    rects = []
    try:
        bbox = tuple(int(value) for value in image.get("smart_paint_suite_dirty_bbox", ())[:4])
        if len(bbox) == 4:
            rects.append(bbox)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pass
    with _LOCK:
        current = dict(_DIRTY_SETS.get(key) or {})
        layers = list(current.get("layer_ids", ()) or ())
        images = list(current.get("images", ()) or ())
        if layer_id and layer_id not in layers:
            layers.append(str(layer_id))
        if image_name and image_name not in images:
            images.append(image_name)
        # Per-document truncation is a semantic cap; the global count+byte LRU
        # remains the authoritative retention limit.
        current.update({
            "layer_ids": layers[-256:],
            "images": images[-256:],
            "reason": str(reason or ""),
            "document_generation": f"{key[0]}:{key[1]}",
        })
        _DIRTY_SETS.put(key, current, document_generation=f"{key[0]}:{key[1]}")
        _DIRTY_LAYER_SETS.put(
            layer_key,
            {
                "image": image_name,
                "dirty_rects": rects,
                "reason": str(reason or ""),
                "document_generation": f"{key[0]}:{key[1]}",
            },
            document_generation=f"{key[0]}:{key[1]}",
        )


def phase2_dirty_runtime_snapshot(material, channel: str = "BASE_COLOR") -> dict[str, Any]:
    key = _snapshot_key(material, channel)
    with _LOCK:
        value = dict(_DIRTY_SETS.get(key) or {})
    return {
        "layer_ids": list(value.get("layer_ids", ()) or ()),
        "images": list(value.get("images", ()) or ()),
        "reason": str(value.get("reason", "") or ""),
    }


def clear_phase2_dirty_image(material, channel: str = "BASE_COLOR", *, image_name: str = "", layer_id: str = "", reason: str = "") -> None:
    del reason
    key = _snapshot_key(material, channel)
    layer_key = _dirty_layer_key(material, channel, layer_id)
    with _LOCK:
        current = dict(_DIRTY_SETS.get(key) or {})
        current["layer_ids"] = [value for value in current.get("layer_ids", ()) or () if str(value) != str(layer_id)]
        current["images"] = [value for value in current.get("images", ()) or () if str(value) != str(image_name)]
        if current["layer_ids"] or current["images"]:
            _DIRTY_SETS.put(key, current, document_generation=f"{key[0]}:{key[1]}")
        else:
            _DIRTY_SETS.pop(key, None)
        _DIRTY_LAYER_SETS.pop(layer_key, None)


def clear_all() -> None:
    with _LOCK:
        _DIRTY_SETS.clear()
        _DIRTY_LAYER_SETS.clear()


__all__ = (
    "_DIRTY_LAYER_SETS", "_DIRTY_SETS", "_dirty_layer_key",
    "_record_dirty_runtime", "_snapshot_key", "clear_all",
    "clear_phase2_dirty_image", "phase2_dirty_runtime_snapshot",
)
