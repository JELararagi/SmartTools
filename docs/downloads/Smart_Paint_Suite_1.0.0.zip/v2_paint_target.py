# SPDX-License-Identifier: GPL-3.0-or-later
"""Remember edited layers and image names until a document is saved."""

from threading import RLock

from . import resource_quota


_LOCK = RLock()
_DIRTY_SETS = resource_quota.cache("paint.dirty_documents")
_DIRTY_LAYER_SETS = resource_quota.cache("paint.dirty_layers")


def _material_name(material):
    return str(getattr(material, "name", "") or "")


def _snapshot_key(material, channel="BASE_COLOR"):
    return _material_name(material), str(channel or "BASE_COLOR").upper()


def _dirty_layer_key(material, channel, layer_id):
    return (*_snapshot_key(material, channel), str(layer_id or ""))


def _recent_names(existing, new):
    names = list(existing or ())
    if new and new not in names:
        names.append(str(new))
    return names[-256:]


def _bounds(image):
    try:
        rectangle = tuple(map(int, image.get("smart_paint_suite_dirty_bbox", ())[:4]))
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return []
    return [rectangle] if len(rectangle) == 4 else []


def _record_dirty_runtime(material, channel, image, layer_id, *, reason=""):
    document = _snapshot_key(material, channel)
    layer = _dirty_layer_key(material, channel, layer_id)
    image_name = str(getattr(image, "name", "") or "")
    generation = ":".join(document)
    changed = {"image": image_name, "dirty_rects": _bounds(image),
               "reason": str(reason or ""), "document_generation": generation}
    with _LOCK:
        data = dict(_DIRTY_SETS.get(document) or {})
        data.update(
            layer_ids=_recent_names(data.get("layer_ids"), layer_id),
            images=_recent_names(data.get("images"), image_name),
            reason=changed["reason"],
            document_generation=generation,
        )
        _DIRTY_SETS.put(document, data, document_generation=generation)
        _DIRTY_LAYER_SETS.put(layer, changed, document_generation=generation)


def phase2_dirty_runtime_snapshot(material, channel="BASE_COLOR"):
    with _LOCK:
        data = _DIRTY_SETS.get(_snapshot_key(material, channel)) or {}
        return {"layer_ids": list(data.get("layer_ids") or ()),
                "images": list(data.get("images") or ()),
                "reason": str(data.get("reason") or "")}


def clear_phase2_dirty_image(material, channel="BASE_COLOR", *, image_name="", layer_id="", reason=""):
    document = _snapshot_key(material, channel)
    with _LOCK:
        remaining = dict(_DIRTY_SETS.get(document) or {})
        for key, removed in (("layer_ids", layer_id), ("images", image_name)):
            remaining[key] = [name for name in remaining.get(key) or () if str(name) != str(removed)]
        if remaining["layer_ids"] or remaining["images"]:
            _DIRTY_SETS.put(document, remaining, document_generation=":".join(document))
        else:
            _DIRTY_SETS.pop(document, None)
        _DIRTY_LAYER_SETS.pop(_dirty_layer_key(material, channel, layer_id), None)


def clear_all():
    with _LOCK:
        for cache in (_DIRTY_SETS, _DIRTY_LAYER_SETS):
            cache.clear()


__all__ = (
    "_DIRTY_LAYER_SETS", "_DIRTY_SETS", "_dirty_layer_key",
    "_record_dirty_runtime", "_snapshot_key", "clear_all",
    "clear_phase2_dirty_image", "phase2_dirty_runtime_snapshot",
)
