# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Dict, Optional, Tuple

import bpy

from .constants import CHANNEL_INFO, NODE_PREFIX
from .utils import (
    SPSException,
    ensure_layer_id,
    mark_node,
    remove_sps_nodes,
    rgb_from_value,
    set_material_alpha_mode,
    socket_by_names,
    unique_node_name,
)



def _new_node(nt: bpy.types.NodeTree, node_type: str, name: str, location=(0.0, 0.0), label: str = "") -> bpy.types.Node:
    node = nt.nodes.new(node_type)
    node.name = unique_node_name(nt, f"{NODE_PREFIX}{name}")
    node.label = label or name
    node.location = location
    return mark_node(node)



def _new_frame(nt: bpy.types.NodeTree, name: str, location=(0.0, 0.0), label: str = "") -> bpy.types.Node:
    return _new_node(nt, "NodeFrame", name, location, label)



def _maybe_parent(node: bpy.types.Node, parent: Optional[bpy.types.Node]) -> bpy.types.Node:
    if parent is not None:
        node.parent = parent
    return node



def _new_rgb(nt: bpy.types.NodeTree, name: str, color, location=(0.0, 0.0), parent=None):
    node = _new_node(nt, "ShaderNodeRGB", name, location)
    node.outputs[0].default_value = color
    return _maybe_parent(node, parent)



def _new_value(nt: bpy.types.NodeTree, name: str, value: float, location=(0.0, 0.0), parent=None):
    node = _new_node(nt, "ShaderNodeValue", name, location)
    node.outputs[0].default_value = value
    return _maybe_parent(node, parent)



def _mix_rgb(nt: bpy.types.NodeTree, name: str, color1, color2, fac, blend_type='MIX', location=(0.0, 0.0), parent=None):
    node = _new_node(nt, "ShaderNodeMixRGB", name, location)
    try:
        node.blend_type = blend_type
    except Exception:
        node.blend_type = 'MIX'
    try:
        node.use_clamp = False
    except Exception:
        pass
    nt.links.new(color1, node.inputs[1])
    nt.links.new(color2, node.inputs[2])
    if hasattr(fac, "node"):
        nt.links.new(fac, node.inputs[0])
    else:
        node.inputs[0].default_value = float(fac)
    return _maybe_parent(node, parent)



def _math(nt: bpy.types.NodeTree, name: str, input_a, input_b=None, op='MULTIPLY', location=(0.0, 0.0), parent=None, clamp=False):
    node = _new_node(nt, "ShaderNodeMath", name, location)
    node.operation = op
    try:
        node.use_clamp = clamp
    except Exception:
        pass
    if hasattr(input_a, "node"):
        nt.links.new(input_a, node.inputs[0])
    else:
        node.inputs[0].default_value = float(input_a)
    if input_b is not None:
        if hasattr(input_b, "node"):
            nt.links.new(input_b, node.inputs[1])
        else:
            node.inputs[1].default_value = float(input_b)
    return _maybe_parent(node, parent)



def _vector_math(nt: bpy.types.NodeTree, name: str, input_a, input_b=None, op='ADD', location=(0.0, 0.0), parent=None, scale: float | None = None):
    node = _new_node(nt, "ShaderNodeVectorMath", name, location)
    node.operation = op
    if hasattr(input_a, "node"):
        nt.links.new(input_a, node.inputs[0])
    else:
        node.inputs[0].default_value = input_a
    if input_b is not None:
        if hasattr(input_b, "node"):
            nt.links.new(input_b, node.inputs[1])
        else:
            node.inputs[1].default_value = input_b
    if scale is not None and len(node.inputs) > 3:
        node.inputs[3].default_value = scale
    return _maybe_parent(node, parent)



def _rgb_to_bw(nt: bpy.types.NodeTree, name: str, color_socket, location=(0.0, 0.0), parent=None):
    node = _new_node(nt, "ShaderNodeRGBToBW", name, location)
    nt.links.new(color_socket, node.inputs[0])
    return _maybe_parent(node, parent)


def _reroute(nt: bpy.types.NodeTree, name: str, input_socket, location=(0.0, 0.0), parent=None):
    node = _new_node(nt, "NodeReroute", name, location)
    try:
        node.hide = True
    except Exception:
        pass
    nt.links.new(input_socket, node.inputs[0])
    return _maybe_parent(node, parent)



def _extract_factor(nt: bpy.types.NodeTree, name: str, color_socket, alpha_socket=None, channel='LUMA', location=(0.0, 0.0), parent=None):
    if channel == 'A' and alpha_socket is not None:
        return alpha_socket
    if channel == 'LUMA':
        return _rgb_to_bw(nt, f"{name}_BW", color_socket, location=location, parent=parent).outputs[0]
    sep = _new_node(nt, "ShaderNodeSeparateColor", f"{name}_Separate", location)
    nt.links.new(color_socket, sep.inputs[0])
    _maybe_parent(sep, parent)
    if channel == 'R':
        return sep.outputs[0]
    if channel == 'G':
        return sep.outputs[1]
    return sep.outputs[2]



def _color_from_factor(nt: bpy.types.NodeTree, name: str, factor_socket, location=(0.0, 0.0), parent=None):
    combine = _new_node(nt, "ShaderNodeCombineColor", name, location)
    for idx in range(3):
        nt.links.new(factor_socket, combine.inputs[idx])
    return _maybe_parent(combine, parent)



def _color_id_factor(nt: bpy.types.NodeTree, name: str, color_socket, target_color, tolerance: float, location=(0.0, 0.0), parent=None):
    target = _new_rgb(nt, f"{name}_Target", target_color, location, parent=parent)
    distance = _vector_math(nt, f"{name}_Distance", color_socket, target.outputs[0], op='DISTANCE', location=(location[0] + 220, location[1]), parent=parent)
    dist_socket = distance.outputs.get('Value', distance.outputs[1] if len(distance.outputs) > 1 else distance.outputs[0])
    tol = max(0.0001, float(tolerance or 0.0))
    normalized = _math(nt, f"{name}_Normalize", dist_socket, tol, op='DIVIDE', location=(location[0] + 420, location[1]), parent=parent, clamp=True).outputs[0]
    factor = _math(nt, f"{name}_Invert", 1.0, normalized, op='SUBTRACT', location=(location[0] + 620, location[1]), parent=parent, clamp=True).outputs[0]
    return factor


def _normal_cull_factor(nt: bpy.types.NodeTree, name: str, color_socket, location=(0.0, 0.0), parent=None):
    sep = _new_node(nt, "ShaderNodeSeparateColor", f"{name}_Separate", location)
    nt.links.new(color_socket, sep.inputs[0])
    _maybe_parent(sep, parent)
    rx = _math(nt, f"{name}_RCenter", sep.outputs[0], 0.5, op='SUBTRACT', location=(location[0] + 180, location[1] + 120), parent=parent).outputs[0]
    gx = _math(nt, f"{name}_GCenter", sep.outputs[1], 0.5, op='SUBTRACT', location=(location[0] + 180, location[1] + 40), parent=parent).outputs[0]
    rz = _math(nt, f"{name}_RAbs", rx, op='ABSOLUTE', location=(location[0] + 360, location[1] + 120), parent=parent).outputs[0]
    gz = _math(nt, f"{name}_GAbs", gx, op='ABSOLUTE', location=(location[0] + 360, location[1] + 40), parent=parent).outputs[0]
    slope = _math(nt, f"{name}_Slope", rz, gz, op='ADD', clamp=True, location=(location[0] + 560, location[1] + 80), parent=parent).outputs[0]
    blue_inv = _math(nt, f"{name}_BlueInv", 1.0, sep.outputs[2], op='SUBTRACT', clamp=True, location=(location[0] + 560, location[1] - 20), parent=parent).outputs[0]
    factor = _math(nt, f"{name}_Combine", slope, blue_inv, op='ADD', clamp=True, location=(location[0] + 760, location[1] + 20), parent=parent).outputs[0]
    return factor



def _build_height_blend_factor(nt: bpy.types.NodeTree, layer, vector_socket, x: float, y: float, parent=None):
    image_name = getattr(layer, 'height_image', '')
    image = bpy.data.images.get(image_name) if image_name else None
    if image is None:
        fac_socket = _new_value(nt, f"{layer.layer_id}_HeightBlendValue", max(0.0, min(1.0, layer.height_value)), (x, y), parent=parent).outputs[0]
    else:
        color_socket, _alpha_socket, _node = _image_output(nt, image, vector_socket, f"{layer.layer_id}_HeightBlend", (x, y), parent=parent, projection='BOX' if layer.projection_mode == 'BOX' else 'FLAT')
        fac_socket = _rgb_to_bw(nt, f"{layer.layer_id}_HeightBlendBW", color_socket, (x + 220, y), parent=parent).outputs[0]
    if layer.height_blend_invert:
        fac_socket = _math(nt, f"{layer.layer_id}_HeightBlendInvert", 1.0, fac_socket, op='SUBTRACT', clamp=True, location=(x + 420, y), parent=parent).outputs[0]
    if abs(layer.height_blend_balance - 1.0) > 1e-5:
        fac_socket = _math(nt, f"{layer.layer_id}_HeightBlendPower", fac_socket, max(0.001, layer.height_blend_balance), op='POWER', clamp=True, location=(x + 620, y), parent=parent).outputs[0]
    return fac_socket



def _image_output(nt: bpy.types.NodeTree, image: bpy.types.Image, vector_socket, name: str, location=(0.0, 0.0), parent=None, projection='FLAT') -> Tuple[bpy.types.NodeSocket, bpy.types.NodeSocket, bpy.types.Node]:
    node = _new_node(nt, "ShaderNodeTexImage", name, location)
    node.image = image
    try:
        node.projection = projection
        if projection == 'BOX':
            node.projection_blend = 0.2
    except Exception:
        pass
    nt.links.new(vector_socket, node.inputs[0])
    _maybe_parent(node, parent)
    return node.outputs[0], node.outputs[1], node



def _master_texture_image_for_channel(material: bpy.types.Material, channel: str):
    """Find the single document texture used for final viewport display."""
    if material is None:
        return None
    channel = str(channel or 'BASE_COLOR').upper()
    try:
        path = str(material.get(f'sps_texture_path_{channel}', '') or '')
    except Exception:
        path = ''
    mat_name = str(getattr(material, 'name', '') or '')
    best = None
    for image in getattr(bpy.data, 'images', ()):
        try:
            if not bool(image.get('smart_paint_suite_master_texture')):
                continue
            if str(image.get('smart_paint_suite_material', '') or '') != mat_name:
                continue
            if str(image.get('smart_paint_suite_channel', '') or '').upper() != channel:
                continue
            if path:
                img_path = str(getattr(image, 'filepath_raw', '') or getattr(image, 'filepath', '') or '')
                if img_path and bpy.path.abspath(img_path) == bpy.path.abspath(path):
                    return image
            best = image
        except Exception:
            continue
    return best


def _master_display_source(nt: bpy.types.NodeTree, material: bpy.types.Material, settings, channel: str, x: float, y: float):
    image = _master_texture_image_for_channel(material, channel)
    if image is None:
        return None, None, None
    try:
        if getattr(settings, 'default_uv_map', ''):
            uv = _new_node(nt, "ShaderNodeUVMap", f"Master_{channel}_UV", (x - 200, y))
            uv.uv_map = settings.default_uv_map
            vector = uv.outputs[0]
        else:
            texcoord = _new_node(nt, "ShaderNodeTexCoord", f"Master_{channel}_Coord", (x - 200, y))
            vector = texcoord.outputs.get("UV", texcoord.outputs[2])
    except Exception:
        texcoord = _new_node(nt, "ShaderNodeTexCoord", f"Master_{channel}_Coord", (x - 200, y))
        vector = texcoord.outputs.get("UV", texcoord.outputs[2])
    color, alpha, node = _image_output(nt, image, vector, f"Master_{channel}_Display", (x, y), projection='FLAT')
    try:
        node.label = f"Smart Paint Document {channel}"
        node['sps_master_display_node'] = True
    except Exception:
        pass
    return color, alpha, node


def _build_vector_source(nt: bpy.types.NodeTree, layer, x: float, y: float, parent=None):
    if layer.projection_mode == 'BOX':
        texcoord = _new_node(nt, "ShaderNodeTexCoord", f"{layer.layer_id}_GenCoord", (x, y))
        _maybe_parent(texcoord, parent)
        vector = texcoord.outputs.get("Generated", texcoord.outputs[0])
    else:
        if layer.uv_map:
            uv_node = _new_node(nt, "ShaderNodeUVMap", f"{layer.layer_id}_UV", (x, y))
            uv_node.uv_map = layer.uv_map
            _maybe_parent(uv_node, parent)
            vector = uv_node.outputs[0]
        else:
            texcoord = _new_node(nt, "ShaderNodeTexCoord", f"{layer.layer_id}_UVCoord", (x, y))
            _maybe_parent(texcoord, parent)
            vector = texcoord.outputs.get("UV", texcoord.outputs[2])

    needs_mapping = (
        abs(float(layer.uv_scale[0]) - 1.0) > 1e-6 or
        abs(float(layer.uv_scale[1]) - 1.0) > 1e-6 or
        abs(float(layer.uv_offset[0])) > 1e-6 or
        abs(float(layer.uv_offset[1])) > 1e-6 or
        abs(float(layer.uv_rotation)) > 1e-6
    )
    if needs_mapping:
        mapping = _new_node(nt, "ShaderNodeMapping", f"{layer.layer_id}_Mapping", (x + 120, y))
        _maybe_parent(mapping, parent)
        try:
            mapping.vector_type = 'POINT'
        except Exception:
            pass
        nt.links.new(vector, mapping.inputs[0])
        try:
            mapping.inputs['Location'].default_value[0] = float(layer.uv_offset[0])
            mapping.inputs['Location'].default_value[1] = float(layer.uv_offset[1])
            mapping.inputs['Rotation'].default_value[2] = float(layer.uv_rotation)
            mapping.inputs['Scale'].default_value[0] = max(0.001, float(layer.uv_scale[0]))
            mapping.inputs['Scale'].default_value[1] = max(0.001, float(layer.uv_scale[1]))
        except Exception:
            pass
        vector = mapping.outputs[0]
        x += 180

    if not layer.use_texture_bombing:
        return vector

    bomb_cell_scale = max(0.25, float(getattr(layer, 'bombing_cell_scale', 4.0) or 4.0))
    bomb_seed = float(getattr(layer, 'bombing_seed', 0.0) or 0.0)
    seeded_vector = vector
    if abs(bomb_seed) > 1e-6:
        seeded_vector = _vector_math(
            nt,
            f"{layer.layer_id}_BombSeedVec",
            vector,
            (bomb_seed, bomb_seed * 1.37, bomb_seed * 2.17),
            op='ADD',
            location=(x + 80, y + 120),
            parent=parent,
        ).outputs[0]

    cell_scale = _vector_math(nt, f"{layer.layer_id}_BombCellScale", seeded_vector, op='SCALE', location=(x + 140, y + 120), parent=parent, scale=bomb_cell_scale)
    cell_floor = _vector_math(nt, f"{layer.layer_id}_BombCellFloor", cell_scale.outputs[0], op='FLOOR', location=(x + 320, y + 120), parent=parent)
    white = _new_node(nt, "ShaderNodeTexWhiteNoise", f"{layer.layer_id}_BombWhite", (x + 500, y + 120))
    try:
        white.noise_dimensions = '3D'
    except Exception:
        pass
    nt.links.new(cell_floor.outputs[0], white.inputs[0])
    _maybe_parent(white, parent)
    cell_offset = _vector_math(nt, f"{layer.layer_id}_BombOffset", white.outputs.get("Color", white.outputs[0]), (0.5, 0.5, 0.5), op='SUBTRACT', location=(x + 700, y + 120), parent=parent)
    cell_strength = _vector_math(nt, f"{layer.layer_id}_BombStrength", cell_offset.outputs[0], op='SCALE', location=(x + 900, y + 120), parent=parent, scale=max(0.0, layer.bombing_strength) / bomb_cell_scale)
    bombed_base = _vector_math(nt, f"{layer.layer_id}_BombedBase", vector, cell_strength.outputs[0], op='ADD', location=(x + 1080, y + 120), parent=parent).outputs[0]

    scaled = _vector_math(nt, f"{layer.layer_id}_WarpScale", bombed_base, op='SCALE', location=(x + 140, y - 40), parent=parent, scale=max(0.001, layer.noise_scale))
    noise = _new_node(nt, "ShaderNodeTexNoise", f"{layer.layer_id}_WarpNoise", (x + 320, y - 20))
    nt.links.new(scaled.outputs[0], noise.inputs[0])
    try:
        noise.inputs[2].default_value = layer.noise_detail
    except Exception:
        pass
    _maybe_parent(noise, parent)

    offset = _vector_math(nt, f"{layer.layer_id}_WarpOffset", noise.outputs.get("Color", noise.outputs[1]), (0.5, 0.5, 0.5), op='SUBTRACT', location=(x + 520, y - 20), parent=parent)
    strength = _vector_math(nt, f"{layer.layer_id}_WarpStrength", offset.outputs[0], op='SCALE', location=(x + 700, y - 20), parent=parent, scale=layer.bombing_strength)
    added = _vector_math(nt, f"{layer.layer_id}_WarpedVector", bombed_base, strength.outputs[0], op='ADD', location=(x + 900, y - 20), parent=parent)
    return added.outputs[0]



def _build_generated_mask(nt: bpy.types.NodeTree, layer, vector_socket, x: float, y: float, mode: str, parent=None):
    if mode == 'NOISE':
        noise = _new_node(nt, "ShaderNodeTexNoise", f"{layer.layer_id}_MaskNoise", (x, y))
        nt.links.new(vector_socket, noise.inputs[0])
        try:
            noise.inputs[2].default_value = layer.noise_detail
            noise.inputs[3].default_value = 0.4
        except Exception:
            pass
        noise.inputs[1].default_value = max(0.001, layer.noise_scale)
        _maybe_parent(noise, parent)
        fac = noise.outputs.get("Fac", noise.outputs[0])
    elif mode == 'GRUNGE':
        noise = _new_node(nt, "ShaderNodeTexNoise", f"{layer.layer_id}_GrungeNoise", (x, y))
        noise.inputs[1].default_value = max(0.001, layer.noise_scale)
        try:
            noise.inputs[2].default_value = layer.noise_detail * 1.75
            noise.inputs[3].default_value = 0.65
        except Exception:
            pass
        nt.links.new(vector_socket, noise.inputs[0])
        _maybe_parent(noise, parent)

        voronoi = _new_node(nt, "ShaderNodeTexVoronoi", f"{layer.layer_id}_GrungeVoronoi", (x, y - 180))
        voronoi.inputs[1].default_value = max(0.001, layer.noise_scale * 0.5)
        nt.links.new(vector_socket, voronoi.inputs[0])
        _maybe_parent(voronoi, parent)

        mix = _mix_rgb(nt, f"{layer.layer_id}_GrungeMix", noise.outputs.get("Color", noise.outputs[1]), voronoi.outputs.get("Color", voronoi.outputs[1]), 0.5, blend_type='MULTIPLY', location=(x + 220, y - 80), parent=parent)
        fac = _rgb_to_bw(nt, f"{layer.layer_id}_GrungeBW", mix.outputs[0], location=(x + 430, y - 80), parent=parent).outputs[0]
    elif mode == 'SCRATCH':
        wave = _new_node(nt, "ShaderNodeTexWave", f"{layer.layer_id}_ScratchWave", (x, y))
        nt.links.new(vector_socket, wave.inputs[0])
        try:
            wave.wave_type = 'BANDS'
            wave.bands_direction = 'DIAGONAL'
            wave.inputs['Scale'].default_value = max(0.001, layer.noise_scale * 6.0)
            wave.inputs['Distortion'].default_value = min(50.0, max(0.0, layer.noise_detail * 1.5))
            wave.inputs['Detail'].default_value = min(16.0, max(0.0, layer.noise_detail))
            wave.inputs['Detail Scale'].default_value = 2.0
        except Exception:
            pass
        _maybe_parent(wave, parent)
        ramp = _new_node(nt, "ShaderNodeValToRGB", f"{layer.layer_id}_ScratchRamp", (x + 220, y))
        try:
            elems = ramp.color_ramp.elements
            elems[0].position = 0.46
            elems[1].position = 0.54
        except Exception:
            pass
        _maybe_parent(ramp, parent)
        nt.links.new(wave.outputs.get('Fac', wave.outputs[0]), ramp.inputs[0])
        fac = _rgb_to_bw(nt, f"{layer.layer_id}_ScratchBW", ramp.outputs[0], location=(x + 420, y), parent=parent).outputs[0]
    elif mode == 'CELLS':
        voronoi = _new_node(nt, "ShaderNodeTexVoronoi", f"{layer.layer_id}_CellsVoronoi", (x, y))
        nt.links.new(vector_socket, voronoi.inputs[0])
        try:
            voronoi.feature = 'DISTANCE_TO_EDGE'
        except Exception:
            pass
        try:
            voronoi.inputs['Scale'].default_value = max(0.001, layer.noise_scale * 1.2)
        except Exception:
            pass
        _maybe_parent(voronoi, parent)
        mapr = _new_node(nt, "ShaderNodeMapRange", f"{layer.layer_id}_CellsRange", (x + 220, y))
        try:
            mapr.inputs[1].default_value = 0.0
            mapr.inputs[2].default_value = 0.18
            mapr.inputs[3].default_value = 1.0
            mapr.inputs[4].default_value = 0.0
            mapr.clamp = True
        except Exception:
            pass
        _maybe_parent(mapr, parent)
        nt.links.new(voronoi.outputs.get('Distance', voronoi.outputs[0]), mapr.inputs[0])
        fac = mapr.outputs.get('Result', mapr.outputs[0])
    else:
        geo = _new_node(nt, "ShaderNodeNewGeometry", f"{layer.layer_id}_EdgeGeo", (x, y))
        _maybe_parent(geo, parent)
        pointiness = geo.outputs.get("Pointiness")
        if pointiness is None:
            # Fallback when Pointiness is unavailable in the current build/engine.
            return _new_value(nt, f"{layer.layer_id}_EdgeFallback", 1.0, (x + 200, y), parent=parent).outputs[0]
        noise = _new_node(nt, "ShaderNodeTexNoise", f"{layer.layer_id}_EdgeNoise", (x, y - 180))
        noise.inputs[1].default_value = max(0.001, layer.noise_scale)
        try:
            noise.inputs[2].default_value = layer.noise_detail
        except Exception:
            pass
        nt.links.new(vector_socket, noise.inputs[0])
        _maybe_parent(noise, parent)
        point_col = _color_from_factor(nt, f"{layer.layer_id}_EdgePointCol", pointiness, (x + 220, y + 20), parent=parent)
        edge_mix = _mix_rgb(nt, f"{layer.layer_id}_EdgeMix", point_col.outputs[0], noise.outputs.get("Color", noise.outputs[1]), 0.5, blend_type='MULTIPLY', location=(x + 460, y - 40), parent=parent)
        fac = _rgb_to_bw(nt, f"{layer.layer_id}_EdgeBW", edge_mix.outputs[0], location=(x + 700, y - 40), parent=parent).outputs[0]
        fac = _math(nt, f"{layer.layer_id}_EdgePow", fac, max(0.001, layer.edge_balance), op='POWER', location=(x + 880, y - 40), parent=parent).outputs[0]
    return fac



def _build_mask_factor(nt: bpy.types.NodeTree, material: bpy.types.Material, layer, vector_socket, anchors: Dict[Tuple[str, str], bpy.types.NodeSocket], x: float, y: float, parent=None):
    settings = material.smart_paint_suite
    fac_socket = None
    mode = layer.mask_mode
    if mode == 'NONE':
        fac_socket = _new_value(nt, f"{layer.layer_id}_MaskBase", 1.0, (x, y), parent=parent).outputs[0]
    elif mode == 'IMAGE':
        image = bpy.data.images.get(layer.mask_image)
        if image:
            color, alpha, _node = _image_output(
                nt,
                image,
                vector_socket,
                f"{layer.layer_id}_MaskImage",
                (x, y),
                parent=parent,
                projection='BOX' if layer.projection_mode == 'BOX' else 'FLAT',
            )
            fac_socket = _extract_factor(nt, f"{layer.layer_id}_MaskFac", color, alpha, layer.mask_channel, (x + 220, y), parent=parent)
    elif mode in {'AO_MAP', 'CURVATURE_MAP', 'THICKNESS_MAP', 'POSITION_MAP', 'NORMAL_CULL'}:
        image_name = {
            'AO_MAP': settings.ao_map,
            'CURVATURE_MAP': settings.curvature_map,
            'THICKNESS_MAP': settings.thickness_map,
            'POSITION_MAP': settings.position_map,
            'NORMAL_CULL': settings.normal_map,
        }[mode]
        if mode == 'NORMAL_CULL' and not image_name:
            image_name = getattr(layer, 'normal_image', '')
        image = bpy.data.images.get(image_name)
        if image:
            color, alpha, _node = _image_output(nt, image, vector_socket, f"{layer.layer_id}_{mode}", (x, y), parent=parent, projection='BOX' if layer.projection_mode == 'BOX' else 'FLAT')
            if mode == 'NORMAL_CULL' and layer.mask_channel == 'LUMA':
                fac_socket = _normal_cull_factor(nt, f"{layer.layer_id}_{mode}Fac", color, (x + 220, y), parent=parent)
            else:
                fac_socket = _extract_factor(nt, f"{layer.layer_id}_{mode}Fac", color, alpha, layer.mask_channel, (x + 220, y), parent=parent)
    elif mode == 'VERTEX_COLOR':
        attr = _new_node(nt, "ShaderNodeAttribute", f"{layer.layer_id}_VertexMask", (x, y))
        attr.attribute_name = layer.vertex_color_attribute
        _maybe_parent(attr, parent)
        fac_socket = _extract_factor(nt, f"{layer.layer_id}_VertexMaskFac", attr.outputs[0], attr.outputs[1] if len(attr.outputs) > 1 else None, layer.mask_channel, (x + 220, y), parent=parent)
    elif mode == 'COLOR_ID':
        attr = _new_node(nt, "ShaderNodeAttribute", f"{layer.layer_id}_ColorIDMask", (x, y))
        attr.attribute_name = layer.vertex_color_attribute
        _maybe_parent(attr, parent)
        fac_socket = _color_id_factor(nt, f"{layer.layer_id}_ColorIDMaskFac", attr.outputs[0], getattr(layer, 'color_id_color', (1.0, 0.0, 0.0, 1.0)), getattr(layer, 'color_id_tolerance', 0.08), (x + 220, y), parent=parent)
    elif mode == 'ANCHOR':
        fac_socket = anchors.get((getattr(layer, 'anchor_layer_id', ''), layer.anchor_channel)) or anchors.get((layer.anchor_layer_name, layer.anchor_channel))
        if fac_socket and layer.mask_channel != 'LUMA':
            # Anchor references are currently stored as color sockets; interpret by channel when requested.
            fac_socket = _extract_factor(nt, f"{layer.layer_id}_AnchorFac", fac_socket, None, layer.mask_channel, (x + 220, y), parent=parent)
        elif fac_socket:
            fac_socket = _rgb_to_bw(nt, f"{layer.layer_id}_AnchorBW", fac_socket, (x + 220, y), parent=parent).outputs[0]
    elif mode in {'NOISE', 'GRUNGE', 'SCRATCH', 'CELLS', 'EDGE_WEAR'}:
        fac_socket = _build_generated_mask(nt, layer, vector_socket, x, y, mode, parent=parent)

    if fac_socket is None:
        fac_socket = _new_value(nt, f"{layer.layer_id}_MaskFallback", 1.0, (x, y), parent=parent).outputs[0]
    if layer.invert_mask:
        fac_socket = _math(nt, f"{layer.layer_id}_MaskInvert", 1.0, fac_socket, op='SUBTRACT', location=(x + 420, y), parent=parent, clamp=True).outputs[0]
    if abs(layer.mask_threshold - 0.5) > 1e-5:
        # Basic threshold / contrast bias.
        if layer.mask_threshold >= 0.5:
            fac_socket = _math(nt, f"{layer.layer_id}_MaskThresholdSub", fac_socket, (layer.mask_threshold - 0.5) * 2.0, op='SUBTRACT', location=(x + 600, y), parent=parent, clamp=True).outputs[0]
        else:
            fac_socket = _math(nt, f"{layer.layer_id}_MaskThresholdAdd", fac_socket, (0.5 - layer.mask_threshold) * 2.0, op='ADD', location=(x + 600, y), parent=parent, clamp=True).outputs[0]
    if abs(layer.mask_strength - 1.0) > 1e-5:
        fac_socket = _math(nt, f"{layer.layer_id}_MaskStrength", fac_socket, layer.mask_strength, op='MULTIPLY', location=(x + 780, y), parent=parent, clamp=True).outputs[0]
    fac_socket = _math(nt, f"{layer.layer_id}_Opacity", fac_socket, layer.opacity, op='MULTIPLY', location=(x + 960, y), parent=parent, clamp=True).outputs[0]
    return fac_socket



def _fallback_source(nt: bpy.types.NodeTree, layer, channel: str, x: float, y: float, parent=None):
    if channel == 'BASE_COLOR':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", layer.fill_color, (x, y), parent=parent).outputs[0]
    if channel == 'ROUGHNESS':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", rgb_from_value(layer.roughness_value), (x, y), parent=parent).outputs[0]
    if channel == 'METALLIC':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", rgb_from_value(layer.metallic_value), (x, y), parent=parent).outputs[0]
    if channel == 'NORMAL':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", (0.5, 0.5, 1.0, 1.0), (x, y), parent=parent).outputs[0]
    if channel == 'HEIGHT':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", rgb_from_value(layer.height_value), (x, y), parent=parent).outputs[0]
    if channel == 'EMISSION':
        color_node = _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", layer.emission_color, (x, y), parent=parent)
        scale = _vector_math(nt, f"{layer.layer_id}_{channel}_Scale", color_node.outputs[0], op='SCALE', location=(x + 180, y), parent=parent, scale=layer.emission_strength)
        return scale.outputs[0]
    if channel == 'ALPHA':
        return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", rgb_from_value(layer.alpha_value), (x, y), parent=parent).outputs[0]
    return _new_rgb(nt, f"{layer.layer_id}_{channel}_Fallback", rgb_from_value(layer.ao_value), (x, y), parent=parent).outputs[0]



def _build_channel_source(nt: bpy.types.NodeTree, layer, channel: str, vector_socket, x: float, y: float, parent=None):
    image_name = getattr(layer, f"{channel.lower()}_image", "")
    image = bpy.data.images.get(image_name) if image_name else None
    projection = 'BOX' if layer.projection_mode == 'BOX' else 'FLAT'
    if image is None:
        return _fallback_source(nt, layer, channel, x, y, parent=parent), None

    color_socket, alpha_socket, node = _image_output(nt, image, vector_socket, f"{layer.layer_id}_{channel}", (x, y), parent=parent, projection=projection)
    mark_node(node, layer.layer_id, channel)

    if channel == 'EMISSION' and abs(layer.emission_strength - 1.0) > 1e-5:
        scale = _vector_math(nt, f"{layer.layer_id}_{channel}_Scale", color_socket, op='SCALE', location=(x + 220, y), parent=parent, scale=layer.emission_strength)
        return scale.outputs[0], node
    if channel == 'NORMAL' and abs(layer.normal_strength - 1.0) > 1e-5:
        neutral = _new_rgb(nt, f"{layer.layer_id}_{channel}_Neutral", (0.5, 0.5, 1.0, 1.0), (x + 220, y + 90), parent=parent)
        offset = _vector_math(nt, f"{layer.layer_id}_{channel}_Offset", color_socket, neutral.outputs[0], op='SUBTRACT', location=(x + 420, y), parent=parent)
        scaled = _vector_math(nt, f"{layer.layer_id}_{channel}_Scaled", offset.outputs[0], op='SCALE', location=(x + 620, y), parent=parent, scale=layer.normal_strength)
        restored = _vector_math(nt, f"{layer.layer_id}_{channel}_Restored", neutral.outputs[0], scaled.outputs[0], op='ADD', location=(x + 820, y), parent=parent)
        return restored.outputs[0], node
    if channel == 'HEIGHT' and abs(layer.height_strength - 1.0) > 1e-5:
        neutral = _new_rgb(nt, f"{layer.layer_id}_{channel}_Neutral", (0.5, 0.5, 0.5, 1.0), (x + 220, y + 90), parent=parent)
        offset = _vector_math(nt, f"{layer.layer_id}_{channel}_Offset", color_socket, neutral.outputs[0], op='SUBTRACT', location=(x + 420, y), parent=parent)
        scaled = _vector_math(nt, f"{layer.layer_id}_{channel}_Scaled", offset.outputs[0], op='SCALE', location=(x + 620, y), parent=parent, scale=layer.height_strength)
        restored = _vector_math(nt, f"{layer.layer_id}_{channel}_Restored", neutral.outputs[0], scaled.outputs[0], op='ADD', location=(x + 820, y), parent=parent)
        return restored.outputs[0], node
    if channel == 'ALPHA' and alpha_socket is not None:
        # Keep alpha images paintable even when the opacity lives in the alpha output.
        alpha_color = _color_from_factor(nt, f"{layer.layer_id}_{channel}_FromAlpha", alpha_socket, (x + 220, y), parent=parent)
        return alpha_color.outputs[0], node
    return color_socket, node





def _base_color_coverage_fallback(nt: bpy.types.NodeTree, layer, color_socket, alpha_socket, x: float, y: float, parent=None):
    """Coverage for BASE_COLOR layer images when Texture Paint writes RGB but not alpha."""
    if alpha_socket is None:
        return None
    try:
        inv = _new_node(nt, "ShaderNodeInvert", f"{layer.layer_id}_BaseCoverageInvert", (x, y))
        inv.parent = parent
        nt.links.new(color_socket, inv.inputs[1] if len(inv.inputs) > 1 else inv.inputs[0])
        bw = _rgb_to_bw(nt, f"{layer.layer_id}_BaseCoverageBW", inv.outputs[0], (x + 180, y), parent=parent).outputs[0]
        alpha_empty = _math(nt, f"{layer.layer_id}_BaseCoverageAlphaEmpty", alpha_socket, 0.001, op='LESS_THAN', clamp=False, location=(x + 340, y + 60), parent=parent).outputs[0]
        # Blender Texture Paint can write RGB on generated transparent layer
        # images without writing alpha.  A scalar RGB-delta fallback made colored
        # strokes fade after rebuilds.  Convert the fallback to a binary coverage
        # mask: any non-clear painted pixel is covered unless real alpha exists.
        painted = _math(nt, f"{layer.layer_id}_BaseCoveragePainted", bw, 0.001, op='GREATER_THAN', clamp=False, location=(x + 520, y + 40), parent=parent).outputs[0]
        fallback = _math(nt, f"{layer.layer_id}_BaseCoverageRGBFallback", painted, alpha_empty, op='MULTIPLY', clamp=True, location=(x + 700, y + 40), parent=parent).outputs[0]
        add = _math(nt, f"{layer.layer_id}_BaseCoverageAlphaOrRGB", alpha_socket, fallback, op='ADD', clamp=True, location=(x + 880, y), parent=parent)
        return add.outputs[0]
    except Exception:
        return alpha_socket


def _apply_layer_filters(nt: bpy.types.NodeTree, layer, channel: str, color_socket, x: float, y: float, parent=None):
    if channel == 'NORMAL':
        return color_socket

    socket = color_socket
    cursor_x = x

    if abs(float(getattr(layer, 'filter_brightness', 0.0))) > 1e-6 or abs(float(getattr(layer, 'filter_contrast', 0.0))) > 1e-6:
        bc = _new_node(nt, "ShaderNodeBrightContrast", f"{layer.layer_id}_{channel}_BrightContrast", (cursor_x, y))
        _maybe_parent(bc, parent)
        nt.links.new(socket, bc.inputs[0])
        try:
            bc.inputs[1].default_value = float(getattr(layer, 'filter_brightness', 0.0))
            bc.inputs[2].default_value = float(getattr(layer, 'filter_contrast', 0.0))
        except Exception:
            pass
        socket = bc.outputs[0]
        cursor_x += 180

    if abs(float(getattr(layer, 'filter_gamma', 1.0)) - 1.0) > 1e-6:
        gamma = _new_node(nt, "ShaderNodeGamma", f"{layer.layer_id}_{channel}_Gamma", (cursor_x, y))
        _maybe_parent(gamma, parent)
        nt.links.new(socket, gamma.inputs[0])
        try:
            gamma.inputs[1].default_value = max(0.001, float(getattr(layer, 'filter_gamma', 1.0)))
        except Exception:
            pass
        socket = gamma.outputs[0]
        cursor_x += 180

    if bool(getattr(layer, 'filter_invert', False)):
        inv = _new_node(nt, "ShaderNodeInvert", f"{layer.layer_id}_{channel}_Invert", (cursor_x, y))
        _maybe_parent(inv, parent)
        try:
            inv.inputs[0].default_value = 1.0
            nt.links.new(socket, inv.inputs[1])
        except Exception:
            nt.links.new(socket, inv.inputs[-1])
        socket = inv.outputs[0]
        cursor_x += 180

    if (abs(float(getattr(layer, 'filter_hue_shift', 0.0))) > 1e-6 or
            abs(float(getattr(layer, 'filter_saturation', 1.0)) - 1.0) > 1e-6 or
            abs(float(getattr(layer, 'filter_value', 1.0)) - 1.0) > 1e-6):
        hsv = _new_node(nt, "ShaderNodeHueSaturation", f"{layer.layer_id}_{channel}_HSV", (cursor_x, y))
        _maybe_parent(hsv, parent)
        try:
            hsv.inputs['Hue'].default_value = 0.5 + float(getattr(layer, 'filter_hue_shift', 0.0))
            hsv.inputs['Saturation'].default_value = float(getattr(layer, 'filter_saturation', 1.0))
            hsv.inputs['Value'].default_value = float(getattr(layer, 'filter_value', 1.0))
            if 'Fac' in hsv.inputs:
                hsv.inputs['Fac'].default_value = 1.0
            nt.links.new(socket, hsv.inputs['Color'])
        except Exception:
            try:
                hsv.inputs[0].default_value = 0.5 + float(getattr(layer, 'filter_hue_shift', 0.0))
                hsv.inputs[1].default_value = float(getattr(layer, 'filter_saturation', 1.0))
                hsv.inputs[2].default_value = float(getattr(layer, 'filter_value', 1.0))
                nt.links.new(socket, hsv.inputs[-1])
            except Exception:
                pass
        socket = hsv.outputs[0]

    return socket




def _can_rebuild_fast_base_stack(settings) -> bool:
    """True for the common Photoshop paint stack: Base Color image layers only."""
    try:
        layers = list(getattr(settings, 'layers', ()) or ())
        if not layers:
            return False
        for layer in layers:
            if not bool(getattr(layer, 'enabled', True)):
                continue
            if not bool(getattr(layer, 'use_base_color', False)):
                return False
            for ch in ('roughness', 'metallic', 'normal', 'height', 'emission', 'alpha', 'ao'):
                if bool(getattr(layer, 'use_' + ch, False)):
                    return False
            if str(getattr(layer, 'projection_mode', 'UV') or 'UV').upper() != 'UV':
                return False
            if bool(getattr(layer, 'use_texture_bombing', False)):
                return False
            if str(getattr(layer, 'mask_mode', 'NONE') or 'NONE').upper() not in {'NONE', 'OFF', ''}:
                return False
            if bool(getattr(layer, 'filter_invert', False)):
                return False
            if abs(float(getattr(layer, 'filter_brightness', 0.0) or 0.0)) > 1e-6:
                return False
            if abs(float(getattr(layer, 'filter_contrast', 0.0) or 0.0)) > 1e-6:
                return False
            if abs(float(getattr(layer, 'filter_gamma', 1.0) or 1.0) - 1.0) > 1e-6:
                return False
            if abs(float(getattr(layer, 'filter_hue_shift', 0.0) or 0.0)) > 1e-6:
                return False
            if abs(float(getattr(layer, 'filter_saturation', 1.0) or 1.0) - 1.0) > 1e-6:
                return False
            if abs(float(getattr(layer, 'filter_value', 1.0) or 1.0) - 1.0) > 1e-6:
                return False
        return True
    except Exception:
        return False




def _install_sps_master_display_after_stack(material: bpy.types.Material, channel: str = 'BASE_COLOR') -> None:
    """Route the viewport material through the stable Smart Paint master image.

    The node stack remains available for layer data/export, but the visible
    material input is a single composited texture so layer selection cannot make
    the 3D View show only one private layer.
    """
    try:
        from .psd_io import install_master_display_node
        install_master_display_node(material, channel)
    except Exception:
        pass


def _install_master_display_for_active_channel(material):
    """Keep 3D View/Image Editor display on the composited document texture.

    Smart Paint stores editable layers as private image buffers, but the user
    must always see the Photoshop-like merged document.  After any material
    stack rebuild, reconnect the active BSDF texture input to the composited
    master image instead of leaving it on a private layer node chain.
    """
    try:
        settings = getattr(material, 'smart_paint_suite', None)
        channel = str(getattr(settings, 'active_paint_channel', 'BASE_COLOR') or 'BASE_COLOR').upper() if settings is not None else 'BASE_COLOR'
        if channel not in CHANNEL_INFO:
            channel = 'BASE_COLOR'
        from .psd_io import install_master_display_node
        install_master_display_node(material, channel)
        if channel != 'BASE_COLOR':
            try:
                install_master_display_node(material, 'BASE_COLOR')
            except Exception:
                pass
    except Exception:
        pass

def _rebuild_fast_base_stack(material: bpy.types.Material) -> bpy.types.Material:
    """Minimal node stack for normal paint layers.

    This path avoids the full Smart Paint layer-style node graph when the stack only uses
    simple Base Color image layers.  It keeps all layers visible in the material
    while leaving each layer's Image Texture node addressable for Blender Texture
    Paint.  New-layer creation and layer selection become substantially lighter.
    """
    settings = material.smart_paint_suite
    if not material.use_nodes:
        material.use_nodes = True
    nt = material.node_tree
    remove_sps_nodes(nt)

    outputs = [node for node in nt.nodes if node.type == 'OUTPUT_MATERIAL' and not node.get('sps_node')]
    if outputs:
        output = next((node for node in outputs if getattr(node, 'is_active_output', False)), outputs[0])
    else:
        output = _new_node(nt, 'ShaderNodeOutputMaterial', 'Output', (900, 0), 'Smart Paint Output')
        try: output.is_active_output = True
        except Exception: pass
    for socket_index in (0, 2):
        if socket_index < len(output.inputs):
            for link in list(output.inputs[socket_index].links):
                try: nt.links.remove(link)
                except Exception: pass

    bsdf = _new_node(nt, 'ShaderNodeBsdfPrincipled', 'Principled', (650, 0), 'Smart Paint Principled')
    nt.links.new(bsdf.outputs[0], output.inputs[0])

    chain = _new_rgb(nt, 'Root_BaseColor', (1.0, 1.0, 1.0, 1.0), (-900, 180)).outputs[0]
    x = -650
    any_layer = False
    for layer in getattr(settings, 'layers', ()):
        ensure_layer_id(layer)
        if not bool(getattr(layer, 'enabled', True)):
            continue
        image = bpy.data.images.get(str(getattr(layer, 'base_color_image', '') or ''))
        if image is None:
            src = _new_rgb(nt, f'{layer.layer_id}_BASE_COLOR_Fallback', getattr(layer, 'fill_color', (1,1,1,1)), (x, 180)).outputs[0]
            fac = float(getattr(layer, 'opacity', 1.0) or 1.0)
            image_node = None
        else:
            node = _new_node(nt, 'ShaderNodeTexImage', f'{layer.layer_id}_BASE_COLOR', (x, 220), label=getattr(layer, 'name', 'Layer'))
            node.image = image
            mark_node(node, layer.layer_id, 'BASE_COLOR')
            src = node.outputs.get('Color') or node.outputs[0]
            alpha = node.outputs.get('Alpha') if hasattr(node.outputs, 'get') else (node.outputs[1] if len(node.outputs) > 1 else None)
            fac = alpha if alpha is not None else float(getattr(layer, 'opacity', 1.0) or 1.0)
            try:
                # Preserve old transparent-RGB brush fallback for generated layers.
                cov = _base_color_coverage_fallback(nt, layer, src, alpha, x, 20, parent=None) if alpha is not None else None
                if cov is not None:
                    fac = cov
            except Exception:
                pass
            if hasattr(fac, 'node') and abs(float(getattr(layer, 'opacity', 1.0) or 1.0) - 1.0) > 1e-6:
                fac = _math(nt, f'{layer.layer_id}_Opacity', fac, float(getattr(layer, 'opacity', 1.0) or 1.0), op='MULTIPLY', clamp=True, location=(x+160, 20)).outputs[0]
            elif not hasattr(fac, 'node'):
                fac = float(fac) * float(getattr(layer, 'opacity', 1.0) or 1.0)
            image_node = node
        mix = _mix_rgb(nt, f'{layer.layer_id}_BASE_COLOR_Mix', chain, src, fac, blend_type=getattr(layer, 'blend_mode', 'MIX'), location=(x + 270, 180))
        chain = mix.outputs[0]
        any_layer = True
        x += 360

    base_socket = socket_by_names(bsdf.inputs, CHANNEL_INFO['BASE_COLOR']['socket_names'])
    if base_socket is not None:
        nt.links.new(chain, base_socket)
    rough_socket = socket_by_names(bsdf.inputs, CHANNEL_INFO['ROUGHNESS']['socket_names'])
    if rough_socket is not None:
        try: rough_socket.default_value = 0.5
        except Exception: pass
    metal_socket = socket_by_names(bsdf.inputs, CHANNEL_INFO['METALLIC']['socket_names'])
    if metal_socket is not None:
        try: metal_socket.default_value = 0.0
        except Exception: pass
    set_material_alpha_mode(material, False)
    settings.managed = True
    _install_sps_master_display_after_stack(material, 'BASE_COLOR')
    return material

def _install_master_display_after_node_build(material: bpy.types.Material) -> None:
    try:
        settings = getattr(material, 'smart_paint_suite', None)
        channel = str(getattr(settings, 'active_paint_channel', 'BASE_COLOR') or 'BASE_COLOR')
    except Exception:
        channel = 'BASE_COLOR'
    try:
        from .psd_io import force_master_single_image_paint_target
        force_master_single_image_paint_target(bpy.context, material, channel, switch_to_paint=False)
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Smart Paint Suite 1.9.59 flat pseudo-layer material engine override
# -----------------------------------------------------------------------------
# The legacy shader-stack builder above is intentionally bypassed.  Layer data is
# stored in private Image datablocks and composited to one master texture for
# display.  The material graph remains constant-size no matter how many layers the
# document has.


def rebuild_material_stack(material: bpy.types.Material) -> bpy.types.Material:
    if material is None:
        raise SPSException("No material to rebuild.")
    try:
        from . import clean_layer_stack_engine as _clean
        return _clean.rebuild_material_stack(material)
    except Exception as exc:
        raise SPSException(str(exc))


def append_fast_base_layer_node(material: bpy.types.Material, layer) -> bool:
    try:
        from .psd_io import install_flat_layer_stack_material
        return bool(install_flat_layer_stack_material(material, 'BASE_COLOR', bpy.context, force_recompose=True, switch_to_paint=False))
    except Exception:
        return False


def find_final_channel_socket(material: bpy.types.Material, channel: str):
    """Return the flat master display output for export compatibility."""
    try:
        from .psd_io import _master_node_name, _safe_channel
        channel = _safe_channel(channel)
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return None
        node = nt.nodes.get(_master_node_name(channel))
        if node is None:
            return None
        return node.outputs.get('Alpha') if channel == 'ALPHA' else node.outputs.get('Color')
    except Exception:
        return None


def find_paint_image_node(material: bpy.types.Material, layer_id: str, channel: str) -> Optional[bpy.types.Node]:
    """Return the reusable flat active-layer write node when it targets layer_id."""
    if material is None or material.node_tree is None:
        return None
    try:
        channel = str(channel or 'BASE_COLOR').upper()
        node = material.node_tree.nodes.get('SPS_FlatActiveLayerWrite_' + channel)
        if node is not None:
            if not layer_id or str(node.get('sps_layer_id', '') or '') == str(layer_id or ''):
                return node
    except Exception:
        pass
    for node in material.node_tree.nodes:
        try:
            if node.get("sps_layer_id") == layer_id and node.get("sps_channel") == channel:
                return node
        except Exception:
            pass
    return None
