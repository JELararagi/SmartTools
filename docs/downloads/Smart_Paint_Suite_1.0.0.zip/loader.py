# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose Smart Paint tool locations to its settings panel."""

__all__ = ("get_record",)

_PREFERENCE_TOOLS = frozenset(("brushstroke_tools", "grease_pencil_tools"))
_EXTERNAL = {
    "ucupaint": {"status": "loaded", "module": "properties"},
}


def get_record(alias: str):
    name = str(alias) if alias else ""
    if name in _PREFERENCE_TOOLS:
        module = f"{name}.preferences"
    elif name == "textures_autosave":
        module = name
    else:
        record = _EXTERNAL.get(name)
        return record.copy() if record is not None else None
    return {"module": module, "status": "loaded"}
