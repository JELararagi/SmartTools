# SPDX-License-Identifier: GPL-3.0-or-later
"""Update the active editing workspace and choose an appropriate layer path."""

import bpy


def _show_image_in_image_editors(context, image, *, include_uv=True):
    if image is None:
        return False
    screen = getattr(context or bpy.context, "screen", None)
    if screen is None:
        return False
    for area in screen.areas:
        if area.type != "IMAGE_EDITOR":
            continue
        editor = area.spaces.active
        try:
            if editor is not None and (include_uv or editor.mode != "UV"):
                if editor.image != image:
                    editor.image = image
                area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            # The area can be removed by workspace changes.
            continue
    return True


def _sps_stack_is_large_or_lazy_for_add_layer(material, channel="BASE_COLOR"):
    if material is None:
        return False
    try:
        from . import psd_io

        width, height, layers = psd_io.collect_layers(material, channel)
    except (ImportError, AttributeError, RuntimeError, ValueError):
        return False
    if max(int(width), 0) * max(int(height), 0) >= 4096**2:
        return True
    if len(layers or ()) >= 24:
        return True
    return any(_pending_image(record) for record in layers or ())


def _pending_image(record):
    if not isinstance(record, dict):
        return False
    image = record.get("image") or record.get("image_ref")
    if image is None:
        return False
    try:
        return any(image.get(f"smart_paint_suite_lazy_{state}", False)
                   for state in ("psd_pending", "blank_layer"))
    except (AttributeError, ReferenceError, TypeError):
        return False


__all__ = ("_show_image_in_image_editors", "_sps_stack_is_large_or_lazy_for_add_layer")
