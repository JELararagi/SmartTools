# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared non-RNA helpers used by the canonical Smart Paint implementation.

This module intentionally declares no Blender classes.  It replaces historical
relative imports that were shipped without their source module.
"""
from __future__ import annotations

from typing import Any

import bpy


def _show_image_in_image_editors(context, image, *, include_uv: bool = True) -> bool:
    """Assign *image* to visible Image Editor spaces and request one redraw.

    The operation is bounded to the current window/screen and does not scan
    ``bpy.types`` or create timers.  UV editor spaces are included by default
    because Blender represents UV and Image editors with the same area type.
    """
    if image is None:
        return False
    ctx = context or getattr(bpy, "context", None)
    screens = []
    screen = getattr(ctx, "screen", None) if ctx is not None else None
    if screen is not None:
        screens.append(screen)
    changed = False
    for current in screens:
        for area in tuple(getattr(current, "areas", ()) or ()):
            if str(getattr(area, "type", "") or "") != "IMAGE_EDITOR":
                continue
            space = getattr(getattr(area, "spaces", None), "active", None)
            if space is None:
                continue
            mode = str(getattr(space, "mode", "") or "")
            if not include_uv and mode == "UV":
                continue
            try:
                if getattr(space, "image", None) is not image:
                    space.image = image
                    changed = True
                area.tag_redraw()
            except (AttributeError, ReferenceError, RuntimeError):
                continue
    return bool(changed or screens)


def _sps_stack_is_large_or_lazy_for_add_layer(material, channel: str = "BASE_COLOR") -> bool:
    """Return whether layer operations should avoid full-document eager work."""
    if material is None:
        return False
    try:
        from . import psd_io

        width, height, records = psd_io.collect_layers(material, channel)
    except (ImportError, AttributeError, RuntimeError, ValueError):
        return False
    lazy = False
    for item in records or ():
        if not isinstance(item, dict):
            continue
        image = item.get("image") or item.get("image_ref")
        try:
            lazy = lazy or bool(
                image is not None
                and (
                    image.get("smart_paint_suite_lazy_psd_pending", False)
                    or image.get("smart_paint_suite_lazy_blank_layer", False)
                )
            )
        except (AttributeError, ReferenceError, TypeError):
            pass
        if lazy:
            break
    pixels = max(0, int(width)) * max(0, int(height))
    return bool(lazy or len(records or ()) >= 24 or pixels >= 4096 * 4096)


__all__ = ("_show_image_in_image_editors", "_sps_stack_is_large_or_lazy_for_add_layer")
