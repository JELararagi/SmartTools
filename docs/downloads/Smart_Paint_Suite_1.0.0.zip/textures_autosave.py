"""Publish Smart Paint's explicit-save policy when its settings are edited."""

import bpy


_POLICY_PROPERTIES = (
    ('timer_enabled', 'textures_autosave_timer_enabled'),
    ('handler_enabled', 'textures_autosave_handler_enabled'),
)


def textures_autosave_timer_update(owner, _context):
    policy = {
        key: bool(getattr(owner, property_name, False))
        for key, property_name in _POLICY_PROPERTIES
    }
    bpy.app.driver_namespace['SPS_TEXTURE_AUTOSAVE_POLICY'] = policy


def textures_autosave_handler_update(owner, _context):
    textures_autosave_timer_update(owner, _context)
