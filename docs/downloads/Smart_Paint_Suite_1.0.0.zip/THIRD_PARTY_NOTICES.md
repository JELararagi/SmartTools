# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## blender org (vrm)
- Origin / 出どころ: extensions.blender.org: vrm — https://vrm-addon-for-blender.info
- Copyright / 著作権者: Isamu Mogi <dyob@lunaport.net>
- License / ライセンス: MIT
- Derived files in this add-on / 由来の部品:
  - editor_panels.py

## bl_pkg
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/bl_pkg)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - external_bridge/csp_worker.py

## bl_operators
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_operators)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - extras/palette_ui.py
