# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Event-driven Smart Paint services controlled by the top always-on group.

No repeating timer is installed. Animated brush updates run only on frame
changes, dirty texture saves run only before .blend saves, and brush-preset
snapshots run only after .blend saves.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any

import bpy
from bpy.app.handlers import persistent

SUITE_ID = "smart_paint_suite"
SUITE_LABEL = "Smart Paint Suite"
_ANIMATED_SERVICE = f"{SUITE_ID}.service.animated_brush"
_TEXTURE_SERVICE = f"{SUITE_ID}.service.texture_save_hook"
_BRUSH_SERVICE = f"{SUITE_ID}.service.brush_save_hook"
_REGISTERING_TRANSACTION = None


def _prefs(context=None):
    ctx = context or getattr(bpy, "context", None)
    try:
        return getattr(getattr(ctx, "window_manager", None), "smart_paint_suite_runtime_preferences", None)
    except Exception:
        return None


def _config_dir() -> Path:
    path = Path(bpy.utils.user_resource("CONFIG", create=True)) / "Smart_Paint_Suite"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _status_transient(owner: str, message_en: str, message_ja: str) -> None:
    try:
        from . import status_runtime
        from .constants import is_japanese_runtime

        japanese = bool(is_japanese_runtime(getattr(bpy, "context", None)))
        status_runtime.set_transient(
            owner,
            message_ja if japanese else message_en,
            duration=1.5,
        )
    except Exception:
        pass


def _status_service(owner: str, label_en: str, label_ja: str, enabled: bool) -> None:
    try:
        from . import status_runtime
        from .constants import is_japanese_runtime

        if enabled:
            japanese = bool(is_japanese_runtime(getattr(bpy, "context", None)))
            status_runtime.set_service(owner, f"{SUITE_LABEL}: {label_ja if japanese else label_en}")
        else:
            status_runtime.clear_prefix(owner)
    except Exception:
        pass


def _set_handler(handler_list, callback, enabled: bool, *, label: str) -> None:
    from . import runtime_registry

    global _REGISTERING_TRANSACTION
    if enabled:
        if callback in handler_list:
            return
        transaction = _REGISTERING_TRANSACTION
        if transaction is not None and getattr(transaction, "state", "") == "REGISTERING":
            transaction.add_handler(handler_list, callback, label=label)
        else:
            runtime_registry.add_handler(handler_list, callback, label=label)
    else:
        runtime_registry.remove_handler(handler_list, callback)


def _active_image_paint_brush():
    try:
        return getattr(bpy.context.tool_settings.image_paint, "brush", None)
    except Exception:
        return None


def _advance_animated_brush(scene) -> int:
    brush = _active_image_paint_brush()
    if brush is None:
        return 0
    changed = 0
    for attr in ("texture", "mask_texture"):
        texture = getattr(brush, attr, None)
        image = getattr(texture, "image", None) if texture is not None else None
        if image is None or str(getattr(image, "source", "") or "") not in {"SEQUENCE", "MOVIE"}:
            continue
        user = getattr(texture, "image_user", None)
        if user is None:
            continue
        try:
            frame = max(1, int(getattr(scene, "frame_current", 1)))
            if int(getattr(user, "frame_current", frame)) != frame:
                user.frame_current = frame
                changed += 1
        except Exception:
            continue
    return changed


@persistent
def _animated_brush_frame_change(scene, _depsgraph=None) -> None:
    if _advance_animated_brush(scene):
        _status_transient(
            f"{SUITE_ID}.animated_brush.frame",
            "Smart Paint Suite: Animated brush frame updated",
            "Smart Paint Suite: アニメブラシのフレームを更新しました",
        )


def _managed_materials():
    for material in tuple(getattr(bpy.data, "materials", ()) or ()):
        try:
            settings = getattr(material, "smart_paint_suite", None)
            if settings is None:
                continue
            if bool(getattr(settings, "managed", False)) or any(
                material.get(key)
                for key in (
                    "sps_texture_path_BASE_COLOR",
                    "sps_source_psd_path_BASE_COLOR",
                    "sps_lightweight_document_kind",
                )
            ):
                yield material
        except Exception:
            continue


def _material_needs_save(material) -> bool:
    try:
        from . import lightweight_mvp
        if lightweight_mvp._dirty_entries_for_save(material):
            return True
    except Exception:
        pass
    try:
        settings = getattr(material, "smart_paint_suite", None)
        for layer in tuple(getattr(settings, "layers", ()) or ()):
            for attr in ("image", "mask_image"):
                name = str(getattr(layer, attr, "") or "")
                image = bpy.data.images.get(name) if name else None
                if image is not None and bool(getattr(image, "is_dirty", False)):
                    return True
    except Exception:
        pass
    return False


def save_dirty_textures() -> dict[str, int]:
    from . import lightweight_mvp
    saved = failed = skipped = 0
    for material in _managed_materials():
        if not _material_needs_save(material):
            skipped += 1
            continue
        try:
            kind = str(lightweight_mvp._document_kind(material) or "").upper()
            if kind == "FLAT":
                result = lightweight_mvp.save_flat_document(
                    material,
                    bpy.context,
                    confirm_flatten=True,
                )
            else:
                result = lightweight_mvp.save_psd(material, bpy.context)
            if bool(result.get("ok", False)) or str(result.get("reason", "")) in {"unchanged", "no_changes"}:
                saved += 1
            else:
                failed += 1
        except Exception:
            failed += 1
    return {"saved": saved, "failed": failed, "skipped": skipped}


@persistent
def _save_dirty_textures_handler(_filepath=None, *_args) -> None:
    try:
        from . import status_runtime
        with status_runtime.task_scope(
            f"{SUITE_ID}.handler.texture_save",
            "Smart Paint Suite: Saving dirty textures…",
            completed_text="Smart Paint Suite: Dirty texture save finished",
        ):
            result = save_dirty_textures()
    except Exception:
        result = save_dirty_textures()
    _status_transient(
        f"{SUITE_ID}.texture_save.result",
        f"Smart Paint Suite: Texture save complete ({result['saved']} saved, {result['failed']} failed)",
        f"Smart Paint Suite: テクスチャ保存完了（保存 {result['saved']}、失敗 {result['failed']}）",
    )


def _simple_rna_snapshot(value) -> dict[str, Any]:
    result: dict[str, Any] = {}
    try:
        properties = value.bl_rna.properties
    except Exception:
        return result
    for prop in properties:
        identifier = str(getattr(prop, "identifier", "") or "")
        if not identifier or identifier == "rna_type" or bool(getattr(prop, "is_readonly", False)):
            continue
        if str(getattr(prop, "type", "") or "").upper() in {"POINTER", "COLLECTION"}:
            continue
        try:
            current = getattr(value, identifier)
        except Exception:
            continue
        if isinstance(current, (bool, int, float, str)):
            result[identifier] = current
        else:
            try:
                values = list(current)
                if all(isinstance(item, (bool, int, float, str)) for item in values):
                    result[identifier] = values
            except Exception:
                pass
    return result


def _atomic_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        try:
            if os.path.exists(temp_name):
                os.remove(temp_name)
        except Exception:
            pass


def save_brush_presets() -> dict[str, Any]:
    brushes = []
    for brush in tuple(getattr(bpy.data, "brushes", ()) or ()):
        try:
            brushes.append({
                "name": str(getattr(brush, "name", "") or ""),
                "settings": _simple_rna_snapshot(brush),
            })
        except Exception:
            continue
    path = _config_dir() / "brush_presets" / "brushes.json"
    _atomic_json(path, {"schema_version": 1, "brushes": brushes})
    return {"saved": len(brushes), "path": str(path)}


@persistent
def _save_brushes_handler(_filepath=None, *_args) -> None:
    try:
        from . import status_runtime
        with status_runtime.task_scope(
            f"{SUITE_ID}.handler.brush_save",
            "Smart Paint Suite: Saving brush presets…",
            completed_text="Smart Paint Suite: Brush preset save finished",
        ):
            result = save_brush_presets()
    except Exception:
        result = save_brush_presets()
    _status_transient(
        f"{SUITE_ID}.brush_save.result",
        f"Smart Paint Suite: Saved {result['saved']} brush presets",
        f"Smart Paint Suite: ブラシプリセットを {result['saved']} 件保存しました",
    )


def sync_runtime(context=None) -> None:
    prefs = _prefs(context)
    animated = bool(getattr(prefs, "suite_animated_brush_enabled", False)) if prefs else False
    textures = bool(getattr(prefs, "suite_texture_save_hook_enabled", False)) if prefs else False
    brushes = bool(getattr(prefs, "suite_brush_save_hook_enabled", False)) if prefs else False

    _set_handler(bpy.app.handlers.frame_change_post, _animated_brush_frame_change, animated, label="suite_features.animated_brush")
    _set_handler(bpy.app.handlers.save_pre, _save_dirty_textures_handler, textures, label="suite_features.texture_save")
    _set_handler(bpy.app.handlers.save_post, _save_brushes_handler, brushes, label="suite_features.brush_save")

    _status_service(_ANIMATED_SERVICE, "Animated Brush Runtime", "アニメブラシ常時処理", animated)
    _status_service(_TEXTURE_SERVICE, "Texture Save Hook", "テクスチャ保存フック", textures)
    _status_service(_BRUSH_SERVICE, "Brush Preset Save Hook", "ブラシプリセット保存フック", brushes)


def register(transaction) -> None:
    global _REGISTERING_TRANSACTION
    if _REGISTERING_TRANSACTION is not None:
        raise RuntimeError("Smart Paint suite features already registering")
    _REGISTERING_TRANSACTION = transaction
    transaction.add_cleanup(_reset_runtime_state, label="suite_features.reset")
    try:
        sync_runtime()
    finally:
        _REGISTERING_TRANSACTION = None


def _reset_runtime_state() -> None:
    global _REGISTERING_TRANSACTION
    _REGISTERING_TRANSACTION = None
    _status_service(_ANIMATED_SERVICE, "", "", False)
    _status_service(_TEXTURE_SERVICE, "", "", False)
    _status_service(_BRUSH_SERVICE, "", "", False)


def stop_all_runtime() -> None:
    """Remove all optional Suite handlers without changing saved preferences."""
    _set_handler(bpy.app.handlers.frame_change_post, _animated_brush_frame_change, False, label="suite_features.animated_brush")
    _set_handler(bpy.app.handlers.save_pre, _save_dirty_textures_handler, False, label="suite_features.texture_save")
    _set_handler(bpy.app.handlers.save_post, _save_brushes_handler, False, label="suite_features.brush_save")
    _reset_runtime_state()



def unregister() -> None:
    """Compatibility surface; the generation journal removes exact handlers."""
    _reset_runtime_state()


def active_resources() -> dict[str, bool]:
    return {
        "animated_brush": _animated_brush_frame_change in bpy.app.handlers.frame_change_post,
        "texture_save": _save_dirty_textures_handler in bpy.app.handlers.save_pre,
        "brush_save": _save_brushes_handler in bpy.app.handlers.save_post,
    }


__all__ = (
    "active_resources", "register", "save_brush_presets", "save_dirty_textures",
    "stop_all_runtime", "sync_runtime", "unregister",
)
