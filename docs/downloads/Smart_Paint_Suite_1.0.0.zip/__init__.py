# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Smart Paint Suite Blender Extension entry point.

Registration is one exact-identity transaction.  A failed component rolls back
only this generation.  Existing displayed RNA is never replaced live.
"""
from __future__ import annotations

__version__ = "1.0.0"
_REGISTRATION_REVISION = "1.9.310"

bl_info = {
    "name": 'Smart Paint',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Sidebar > Smart Paint",
    "description": (
        "Layered PSD and flat-image painting, native Texture Paint, selection, "
        "gradient, and explicit Photoshop / Clip Studio exchange."
    ),
    "category": "Smart Paint",
}

_SPS_LIGHTWEIGHT_MODE = True


def lightweight_mode_enabled() -> bool:
    return True


def _purge_stale_submodules() -> None:
    """Cross-version live reinstall tolerance (measured on Blender 5.1.2).

    Dropping a new zip onto a running Blender may reload only this file:
    ``addon_utils.enable`` calls ``importlib.reload`` on the package root
    alone, and ``bl_extension_ops`` purges the package's submodules only when
    the extension is still in the enabled defaults.  After any previously
    failed enable the defaults entry is gone, so every submodule of the OLD
    version stays cached in ``sys.modules`` and ``register()`` would execute
    old code against the new files (e.g. an old ``add_translation`` without
    stale-cache tolerance).  Detect the version skew and drop only this
    package's own cached submodules so the imports below resolve to the files
    actually on disk.  Old-generation resources stay recoverable: the runtime
    ledger lives in ``bpy.app.driver_namespace`` with self-contained removers,
    and ``begin_registration`` releases them before acquiring anew.
    """
    import sys
    import types

    prefix = __name__ + "."
    cached_registry = sys.modules.get(prefix + "runtime_registry")
    if cached_registry is None:
        return
    if str(getattr(cached_registry, "REVISION", "")) == _REGISTRATION_REVISION:
        return
    for key in [key for key in sys.modules if key.startswith(prefix)]:
        sys.modules.pop(key, None)
    # ``from . import x`` short-circuits on the parent package's ATTRIBUTE
    # before consulting sys.modules (importlib._handle_fromlist), and
    # ``importlib.reload`` keeps the old namespace.  Drop the stale submodule
    # attributes too, or every relative import below would silently rebind the
    # old modules again (measured on 5.1.2: the popped 1.9.287 runtime_registry
    # kept executing through exactly this path).
    package_module = sys.modules.get(__name__)
    if package_module is not None:
        for attr, value in list(vars(package_module).items()):
            if isinstance(value, types.ModuleType) and str(
                getattr(value, "__name__", "")
            ).startswith(prefix):
                try:
                    delattr(package_module, attr)
                except AttributeError:
                    pass


def register() -> None:
    _purge_stale_submodules()
    from . import lightweight_mvp, runtime_registry

    transaction = runtime_registry.begin_registration(_REGISTRATION_REVISION)
    try:
        lightweight_mvp.register(transaction)
        transaction.component("smart_paint_suite", "READY")
        transaction.commit()
        from . import manager_rule_api

        manager_rule_api.schedule_rule_matrix_subscription_once()
    except BaseException as exc:
        transaction.component("smart_paint_suite", "FAILED", repr(exc))
        transaction.rollback(exc)
        raise


def unregister() -> None:
    from . import runtime_registry

    result = runtime_registry.unregister(timeout=10.0)
    if not bool(result.get("ok", False)):
        raise RuntimeError(
            "Smart Paint Suite cleanup failed: "
            + "; ".join(str(value) for value in result.get("cleanup_errors", ()))
        )

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
