# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Opt-in live PSD composite display for the lightweight native-paint path.

The Blender Image Paint canvas remains the selected PSD layer.  This module
only owns a small material node graph which feeds Material Output.  It never
routes brush events, copies a composite back into a layer, or registers a
timer, handler, modal operator, worker, or keymap.
"""

from __future__ import annotations

import hashlib
import json
import struct
import time
import uuid
from pathlib import Path
from typing import Any

import bpy

from . import state
from .. import resource_quota, runtime_registry


CHANNEL = "BASE_COLOR"
_NODE_MARKER = "sps_mvp_live_composite_node"
_AUX_NODE_MARKER = "sps_mvp_live_composite_aux_node"
_IMAGE_MARKER = "sps_mvp_live_composite_cache"
_MASK_PROXY_MAP_PROPERTY = "sps_mvp_mask_display_proxies"
_MASK_PROXY_MAP_OWNER_PROPERTY = "sps_mvp_mask_display_proxies_owner"
_MASK_PROXY_MARKER = "sps_mvp_mask_display_proxy"
_MASK_PROXY_SOURCE = "sps_mvp_mask_display_source"
_MASK_PROXY_MATERIAL = "sps_mvp_mask_display_material"
_CUSTOM_SHADER_LINKS_PROPERTY = "sps_mvp_live_custom_shader_links"
_CUSTOM_SHADER_LINKS_VERSION = 1
_GRAPH_VERSION = "t42_custom_shader_document_inputs_v1"
_COLOR_CONVERSION_VERSION = "t25_normal_peel_mask_v1"
_EPSILON = 1.0 / 1024.0
_INVERSE_EPSILON = 1.0e-8
_ROUNDTRIP_TOLERANCE = 2.0 / 255.0
_MAX_CHAIN_LAYERS = 32
_PEEL_SUPPORTED_BLEND_MODES = frozenset(
    {"MIX", "MULTIPLY", "SCREEN", "OVERLAY", "HARD_LIGHT"}
)

# Every retained payload participates in the Suite-wide actual-byte LRU.  Values
# are names, hashes and plain metadata or numeric arrays; Blender RNA/Image and
# modules are never retained here.
_CACHE = resource_quota.cache("live_composite.material_metadata")
_MASK_DISPLAY_PROXY_CACHE = resource_quota.cache("live_composite.mask_proxy_map")
_EXPLICIT_IMAGE_U8_CACHE = resource_quota.cache("live_composite.explicit_image_u8")
_OWNER_UUID_PROPERTY = "sps_suite_owner_uuid"
_RUNTIME_GENERATION_PROPERTY = "sps_suite_runtime_generation"
_IMAGE_UUID_PROPERTY = "sps_suite_image_uuid"
_GROUP_UUID_PROPERTY = "sps_suite_node_group_uuid"
_OWNER_SCHEMA_PROPERTY = "sps_suite_owner_schema"
_OWNER_SCHEMA = 1


def _runtime_generation() -> str:
    return str(runtime_registry.snapshot().get("generation", "") or "")


def _tag_owned_image(image) -> None:
    image[_OWNER_UUID_PROPERTY] = resource_quota.SUITE_OWNER_UUID
    image[_RUNTIME_GENERATION_PROPERTY] = _runtime_generation()
    image[_IMAGE_UUID_PROPERTY] = str(image.get(_IMAGE_UUID_PROPERTY, "") or uuid.uuid4())
    image[_OWNER_SCHEMA_PROPERTY] = _OWNER_SCHEMA


def _exact_owned_image(image) -> bool:
    try:
        return bool(
            image is not None
            and str(image.get(_OWNER_UUID_PROPERTY, "") or "") == resource_quota.SUITE_OWNER_UUID
            and str(image.get(_IMAGE_UUID_PROPERTY, "") or "")
            and int(image.get(_OWNER_SCHEMA_PROPERTY, -1)) == _OWNER_SCHEMA
        )
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False


def _tag_owned_group(group) -> None:
    group[_OWNER_UUID_PROPERTY] = resource_quota.SUITE_OWNER_UUID
    group[_RUNTIME_GENERATION_PROPERTY] = _runtime_generation()
    group[_GROUP_UUID_PROPERTY] = str(group.get(_GROUP_UUID_PROPERTY, "") or uuid.uuid4())
    group[_OWNER_SCHEMA_PROPERTY] = _OWNER_SCHEMA


def _exact_owned_group(group) -> bool:
    try:
        return bool(
            group is not None
            and str(group.get(_OWNER_UUID_PROPERTY, "") or "") == resource_quota.SUITE_OWNER_UUID
            and str(group.get(_GROUP_UUID_PROPERTY, "") or "")
            and int(group.get(_OWNER_SCHEMA_PROPERTY, -1)) == _OWNER_SCHEMA
        )
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False


def _new_owned_group(base_name: str):
    name = str(base_name or "SPS_MVP_Group")
    if bpy.data.node_groups.get(name) is not None:
        name = f"{name}_{uuid.uuid4().hex[:10]}"
    group = bpy.data.node_groups.new(name, "ShaderNodeTree")
    _tag_owned_group(group)
    return group


def _replace_owned_group_or_create(base_name: str, current):
    if _exact_owned_group(current) and int(getattr(current, "users", 0) or 0) <= 0:
        captured_uuid = str(current.get(_GROUP_UUID_PROPERTY, "") or "")
        if captured_uuid:
            bpy.data.node_groups.remove(current)
            return _new_owned_group(base_name)
    return _new_owned_group(base_name)


def _store_mask_proxy_map(material_name: str, mapping: dict[str, str]) -> None:
    key = str(material_name or "")
    if not key:
        return
    _MASK_DISPLAY_PROXY_CACHE.put(
        key,
        {str(source): str(proxy) for source, proxy in dict(mapping or {}).items()},
        document_generation=key,
    )


def _remove_unused_cache_images(cache: dict[str, Any]) -> None:
    for image_name in tuple(cache.get("image_names", ()) or ()):
        image = bpy.data.images.get(str(image_name or ""))
        try:
            if _exact_owned_image(image) and int(getattr(image, "users", 0) or 0) <= 0:
                bpy.data.images.remove(image)
        except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
            continue


def _store_material_cache(material_name: str, cache: dict[str, Any]) -> None:
    key = str(material_name or "")
    if not key:
        return
    previous = _CACHE.get(key, {}) or {}
    if previous is not cache:
        _remove_unused_cache_images(previous)
    _CACHE.put(key, dict(cache or {}), document_generation=key)


def _trace(event: str, *, material=None, **payload) -> None:
    try:
        from .. import save_trace

        save_trace.emit(str(event or ""), material=material, channel=CHANNEL, **payload)
    except Exception:
        pass


def _material_name(material) -> str:
    return str(getattr(material, "name", "") or "")


def cache_image_u8_payload(material, image, payload) -> bool:
    """Retain one exact inactive mask snapshot per material for Review/Save."""
    if material is None or image is None or not isinstance(payload, tuple) or len(payload) != 3:
        return False
    try:
        import numpy as np

        width, height, pixels = payload
        width = int(width); height = int(height)
        if width <= 1 or height <= 1:
            return False
        value = np.asarray(pixels, dtype=np.uint8).reshape((height, width, 4))
        if not value.flags.c_contiguous:
            value = np.ascontiguousarray(value, dtype=np.uint8)
        material_name = _material_name(material)
        image_name = str(getattr(image, "name", "") or "")
        if not material_name or not image_name:
            return False
        for key, entry in list(_EXPLICIT_IMAGE_U8_CACHE.items()):
            if str(entry.get("material", "") or "") == material_name and key != image_name:
                _EXPLICIT_IMAGE_U8_CACHE.pop(key, None)
        return bool(_EXPLICIT_IMAGE_U8_CACHE.put(
            image_name,
            {
                "material": material_name,
                "width": width,
                "height": height,
                "pixels": value,
            },
            document_generation=material_name,
        ))
    except Exception:
        return False


def cached_image_u8_payload(image, width: int, height: int):
    if image is None:
        return None
    entry = _EXPLICIT_IMAGE_U8_CACHE.get(str(getattr(image, "name", "") or ""), {}) or {}
    try:
        if int(entry.get("width", 0) or 0) != int(width) or int(entry.get("height", 0) or 0) != int(height):
            return None
        return entry.get("pixels")
    except Exception:
        return None


def invalidate_image_u8_payload(image) -> None:
    if image is not None:
        _EXPLICIT_IMAGE_U8_CACHE.pop(str(getattr(image, "name", "") or ""), None)


def clear_explicit_image_u8_cache(material=None) -> None:
    if material is None:
        _EXPLICIT_IMAGE_U8_CACHE.clear()
        return
    material_name = _material_name(material)
    for key, entry in list(_EXPLICIT_IMAGE_U8_CACHE.items()):
        if str(entry.get("material", "") or "") == material_name:
            _EXPLICIT_IMAGE_U8_CACHE.pop(key, None)


def _mask_display_proxy_map(material) -> dict[str, str]:
    if material is None:
        return {}
    material_name = _material_name(material)
    cached = _MASK_DISPLAY_PROXY_CACHE.get(material_name)
    if cached is not None:
        return cached
    try:
        owner = str(material.get(_MASK_PROXY_MAP_OWNER_PROPERTY, "") or "")
        raw = material.get(_MASK_PROXY_MAP_PROPERTY, "") if owner == resource_quota.SUITE_OWNER_UUID else ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        raw = ""
    parsed = {}
    if raw:
        try:
            candidate = json.loads(str(raw))
            if isinstance(candidate, dict):
                parsed = candidate
        except Exception:
            pass
    mapping = {
        str(source): str(proxy)
        for source, proxy in parsed.items()
        if str(source or "") and str(proxy or "")
    }
    _store_mask_proxy_map(material_name, mapping)
    return mapping


def resolve_display_image(material, image_name: str):
    """Resolve an operation-published mask snapshot, or the source image."""
    source_name = str(image_name or "")
    proxy_name = _mask_display_proxy_map(material).get(source_name, "")
    proxy = bpy.data.images.get(proxy_name) if proxy_name else None
    if proxy is not None:
        return proxy
    return bpy.data.images.get(source_name) if source_name else None


def _runtime_materials_for_mask_rebind(material, context=None):
    result = []
    seen = set()

    def add(candidate):
        if candidate is None:
            return
        try:
            pointer = int(candidate.as_pointer())
        except Exception:
            pointer = id(candidate)
        if pointer in seen:
            return
        seen.add(pointer)
        result.append(candidate)

    add(material)
    ctx = context or getattr(bpy, "context", None)
    obj = getattr(ctx, "active_object", None) if ctx is not None else None
    if obj is None:
        return result
    try:
        depsgraph = ctx.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
    except Exception:
        return result
    material_pointer = int(material.as_pointer())
    material_name = _material_name(material)
    for slot_index, slot in enumerate(getattr(obj, "material_slots", ()) or ()):
        slot_material = getattr(slot, "material", None)
        if slot_material is None:
            continue
        try:
            same_pointer = int(slot_material.as_pointer()) == material_pointer
        except Exception:
            same_pointer = slot_material is material
        if not same_pointer and _material_name(slot_material) != material_name:
            continue
        evaluated_slots = getattr(evaluated, "material_slots", ()) or ()
        if slot_index < len(evaluated_slots):
            add(getattr(evaluated_slots[slot_index], "material", None))
    return result


def publish_mask_display_proxy(material, image, context=None) -> dict[str, Any]:
    """Publish one completed mask stroke to overlay and material GPU inputs.

    Native Image Paint keeps the authoritative mask datablock dirty in memory,
    but Blender can retain an older shader texture for that same Image. A fresh
    byte Image gives the GPU a new generation while save/reopen continues to use
    the untouched authoritative canvas.
    """
    started = time.perf_counter()
    if material is None or image is None:
        return {"ok": False, "reason": "mask_proxy_input_missing"}
    width, height = int(image.size[0]), int(image.size[1])
    if width <= 0 or height <= 0:
        return {"ok": False, "reason": "mask_proxy_size_invalid"}
    source_name = str(getattr(image, "name", "") or "")
    if not source_name:
        return {"ok": False, "reason": "mask_proxy_source_unnamed"}

    import numpy as np

    flat = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(flat)
    read_ready = time.perf_counter()
    token = hashlib.sha1(
        f"{_material_name(material)}|{source_name}|{time.time_ns()}".encode("utf-8")
    ).hexdigest()[:12]
    proxy = bpy.data.images.new(
        f"SPS_MVP_MASK_GPU_{token}",
        width=width,
        height=height,
        alpha=True,
        float_buffer=False,
    )
    try:
        proxy.colorspace_settings.name = str(image.colorspace_settings.name)
    except Exception:
        try:
            proxy.colorspace_settings.name = "Non-Color"
        except Exception:
            pass
    try:
        proxy.alpha_mode = str(getattr(image, "alpha_mode", "STRAIGHT") or "STRAIGHT")
    except Exception:
        pass
    proxy.pixels.foreach_set(flat)
    del flat
    proxy.update()
    write_ready = time.perf_counter()
    try:
        _tag_owned_image(proxy)
        proxy[_MASK_PROXY_MARKER] = True
        proxy[_MASK_PROXY_SOURCE] = source_name
        proxy[_MASK_PROXY_MATERIAL] = _material_name(material)
    except Exception:
        pass

    mapping = _mask_display_proxy_map(material)
    previous_name = str(mapping.get(source_name, "") or "")
    mapping[source_name] = str(proxy.name)
    _store_mask_proxy_map(_material_name(material), mapping)
    material[_MASK_PROXY_MAP_OWNER_PROPERTY] = resource_quota.SUITE_OWNER_UUID
    material[_MASK_PROXY_MAP_PROPERTY] = json.dumps(
        mapping,
        sort_keys=True,
        ensure_ascii=False,
    )

    rebound = 0
    for runtime_material in _runtime_materials_for_mask_rebind(material, context):
        tree = getattr(runtime_material, "node_tree", None)
        if tree is None:
            continue
        for node in list(getattr(tree, "nodes", ()) or ()):
            if str(getattr(node, "type", "") or "") != "TEX_IMAGE":
                continue
            if not str(getattr(node, "label", "") or "").startswith("Mask "):
                continue
            node_image = getattr(node, "image", None)
            node_name = str(getattr(node_image, "name", "") or "")
            if node_name not in {source_name, previous_name}:
                continue
            try:
                node.image = proxy
                rebound += 1
            except Exception:
                pass
        try:
            tree.update_tag()
        except Exception:
            pass
        try:
            runtime_material.update_tag()
        except Exception:
            pass
    try:
        (context or bpy.context).view_layer.update()
    except Exception:
        pass

    previous = bpy.data.images.get(previous_name) if previous_name else None
    if (
        previous is not None
        and previous is not proxy
        and _exact_owned_image(previous)
        and bool(previous.get(_MASK_PROXY_MARKER, False))
        and int(getattr(previous, "users", 0) or 0) == 0
    ):
        try:
            bpy.data.images.remove(previous)
        except Exception:
            pass

    return {
        "ok": True,
        "reason": "mask_proxy_published",
        "source": source_name,
        "proxy": str(proxy.name),
        "width": width,
        "height": height,
        "pixels": width * height,
        "rebound_nodes": int(rebound),
        "read_ms": round((read_ready - started) * 1000.0, 3),
        "write_ms": round((write_ready - read_ready) * 1000.0, 3),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }


def clear_mask_display_proxies(material=None) -> None:
    material_name = _material_name(material) if material is not None else ""
    # During addon enable/disable Blender exposes ``bpy.data`` as
    # ``_RestrictData``; ID collections are unreachable then.  Lifecycle
    # cleanup (register rollback, unregister) must still succeed by clearing
    # only the in-memory caches instead of raising AttributeError.
    data_materials = getattr(bpy.data, "materials", None)
    if material is not None:
        materials = [material]
    elif data_materials is not None:
        materials = list(data_materials)
    else:
        materials = []
    if material is None:
        _MASK_DISPLAY_PROXY_CACHE.clear()
    else:
        _MASK_DISPLAY_PROXY_CACHE.pop(material_name, None)
    for item in materials:
        if item is None:
            continue
        try:
            if str(item.get(_MASK_PROXY_MAP_OWNER_PROPERTY, "") or "") != resource_quota.SUITE_OWNER_UUID:
                continue
            if _MASK_PROXY_MAP_PROPERTY in item:
                del item[_MASK_PROXY_MAP_PROPERTY]
            if _MASK_PROXY_MAP_OWNER_PROPERTY in item:
                del item[_MASK_PROXY_MAP_OWNER_PROPERTY]
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    data_images = getattr(bpy.data, "images", None)
    for image in list(data_images) if data_images is not None else []:
        try:
            if not _exact_owned_image(image) or not bool(image.get(_MASK_PROXY_MARKER, False)):
                continue
            owner = str(image.get(_MASK_PROXY_MATERIAL, "") or "")
            if material_name and owner != material_name:
                continue
            if int(getattr(image, "users", 0) or 0) != 0:
                continue
            data_images.remove(image)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue


def _settings(material):
    try:
        return getattr(material, "smart_paint_suite", None)
    except Exception:
        return None


def _source_path(material) -> str:
    for key in (
        "sps_texture_path_BASE_COLOR",
        "sps_bodypaint_source_stack_path_BASE_COLOR",
        "sps_source_psd_path_BASE_COLOR",
        "sps_texture_source_path_BASE_COLOR",
    ):
        try:
            value = str(material.get(key, "") or "")
        except Exception:
            value = ""
        if not value:
            continue
        try:
            return str(Path(bpy.path.abspath(value)).resolve())
        except Exception:
            return value
    return ""


def _source_signature(path: str) -> str:
    try:
        resolved = Path(path).resolve()
        stat = resolved.stat()
        return f"{resolved}|{int(stat.st_size)}|{int(stat.st_mtime_ns)}"
    except Exception:
        return ""


def _source_record_index(layer) -> int:
    try:
        return int(getattr(layer, "psd_source_record_index", -1))
    except Exception:
        return -1


def _sourceless_document(material) -> bool:
    """Return True only for an explicitly opened flat Smart Paint document."""
    try:
        if str(material.get("sps_lightweight_document_kind", "") or "").upper() != "FLAT":
            return False
    except Exception:
        return False
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    return bool(layers) and not any(_source_record_index(layer) >= 0 for layer in layers)


def _sourceless_document_size(material) -> tuple[int, int]:
    try:
        width = int(material.get("sps_lightweight_document_width", 0) or 0)
        height = int(material.get("sps_lightweight_document_height", 0) or 0)
        if width > 1 and height > 1:
            return width, height
    except Exception:
        pass
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    for index, layer in enumerate(layers):
        if not _layer_is_paintable(layer):
            continue
        layer_id = _layer_id(layer, index)
        image = state.matching_canvas(material, layer_id, -1)
        if image is None:
            try:
                image = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
            except Exception:
                image = None
        try:
            width, height = int(image.size[0]), int(image.size[1])
            if width > 1 and height > 1:
                return width, height
        except Exception:
            continue
    return 0, 0


def _sourceless_signature(material) -> str:
    width, height = _sourceless_document_size(material)
    try:
        token = str(material.get("sps_lightweight_document_token", "") or "")
    except Exception:
        token = ""
    return f"flat|{_material_name(material)}|{token}|{int(width)}x{int(height)}"


def _layer_id(layer, index: int) -> str:
    try:
        value = str(getattr(layer, "layer_id", "") or "")
    except Exception:
        value = ""
    return value or f"layer_{int(index) + 1}"


def _stack_key(layer_id: str) -> str:
    return f"layer:{str(layer_id or '')}"


def _node_token(layer_id: str, record_index: int) -> str:
    """Keep imported node roles stable while disambiguating unsaved rows."""
    if int(record_index) >= 0:
        return str(int(record_index))
    digest = hashlib.sha1(str(layer_id or "").encode("utf-8", errors="replace")).hexdigest()[:10]
    return f"new_{digest}"


def _layer_is_paintable(layer) -> bool:
    if layer is None:
        return False
    try:
        if bool(getattr(layer, "is_group", False)):
            return False
        if str(getattr(layer, "layer_kind", "PAINT") or "PAINT").upper() in {"GROUP", "ADJUSTMENT"}:
            return False
        if str(getattr(layer, "adjustment_type", "NONE") or "NONE").upper() != "NONE":
            return False
    except Exception:
        return False
    return True


def _supported_adjustment_type(layer) -> str:
    if layer is None:
        return ""
    try:
        from . import adjustments

        adjustment_type = str(
            getattr(layer, "adjustment_type", "NONE") or "NONE"
        ).upper()
        if adjustment_type in adjustments.SUPPORTED_TYPES:
            return adjustment_type
    except Exception:
        pass
    return ""


def _normalized_blend_mode(value) -> str:
    mode = str(value or "MIX").upper()
    return "MIX" if mode == "NORMAL" else mode


def _direct_supported_blend_modes() -> frozenset[str]:
    """Modes implemented by the Photoshop-compatible forward blend groups."""
    try:
        from .. import sps_blend_nodes

        return frozenset(str(mode).upper() for mode in sps_blend_nodes.PSD_BLEND_MODES)
    except Exception:
        return _PEEL_SUPPORTED_BLEND_MODES


def _active_canvas(context=None):
    try:
        paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
        return getattr(paint, "canvas", None) if paint is not None else None
    except Exception:
        return None


def _active_record_index(material, context=None) -> int:
    image = _active_canvas(context)
    if image is not None:
        try:
            if str(image.get("smart_paint_suite_material", "") or "") == _material_name(material):
                return int(image.get("sps_psd_source_order", -1))
        except Exception:
            pass
    try:
        value = str(material.get("sps_v2_native_paint_target_image_BASE_COLOR", "") or "")
        image = bpy.data.images.get(value) if value else None
        return int(image.get("sps_psd_source_order", -1)) if image is not None else -1
    except Exception:
        return -1


def _active_layer_id(material, context=None) -> str:
    image = _active_canvas(context)
    if image is not None:
        try:
            if str(image.get("smart_paint_suite_material", "") or "") == _material_name(material):
                value = str(image.get("smart_paint_suite_layer_id", "") or "")
                if value:
                    return value
        except Exception:
            pass
    try:
        return str(material.get("sps_v2_native_paint_target_layer_id_BASE_COLOR", "") or "")
    except Exception:
        return ""


def _top_normal_chain(material) -> tuple[list[dict[str, Any]], str]:
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    rows = sorted(
        [
            (int(_source_record_index(layer)), int(index), layer)
            for index, layer in enumerate(layers)
            if int(_source_record_index(layer)) >= 0
        ],
        key=lambda item: item[0],
        reverse=True,
    )
    if not rows:
        return [], "source_records_missing"
    chain: list[dict[str, Any]] = []
    expected = int(rows[0][0])
    for record_index, index, layer in rows:
        if int(record_index) != expected:
            break
        blend_mode = _normalized_blend_mode(getattr(layer, "blend_mode", "MIX"))
        unsupported = (
            not _layer_is_paintable(layer)
            or blend_mode not in _direct_supported_blend_modes()
            or bool(getattr(layer, "clip_to_below", False))
        )
        if unsupported:
            break
        chain.append({
            "record_index": int(record_index),
            "layer_index": int(index),
            "layer_id": _layer_id(layer, index),
            "layer": layer,
            "current_blend_mode": blend_mode,
        })
        expected -= 1
        if len(chain) >= _MAX_CHAIN_LAYERS:
            break
    if not chain:
        return [], "top_layer_not_supported"
    return chain, ""


def _live_paint_chain(material) -> tuple[list[dict[str, Any]], str]:
    """Return every Blender-paintable PSD row with its structural ancestors.

    Unsupported adjustment/fill rows are intentionally transparent in the
    Blender layer stack. They must not truncate live composition, otherwise a
    valid paint row below the first adjustment can never participate in the 3D
    result. Group rows remain structural and contribute visibility, opacity,
    and source masks to their paint children.
    """
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if not layers:
        return [], "source_records_missing"
    groups: list[dict[str, Any]] = []
    chain: list[dict[str, Any]] = []
    seen_records: set[int] = set()
    seen_stack_keys: set[str] = set()
    clipping_base_by_scope: dict[tuple[str, ...], str] = {}
    for index, layer in enumerate(layers):
        depth = max(0, int(getattr(layer, "group_depth", 0) or 0))
        while groups and int(groups[-1]["depth"]) >= depth:
            groups.pop()
        ancestor_groups = tuple(
            group for group in groups if int(group["depth"]) < depth
        )
        scope_key = tuple(str(group.get("stack_key", "") or "") for group in ancestor_groups)
        if bool(getattr(layer, "is_group", False)) or str(
            getattr(layer, "layer_kind", "") or ""
        ).upper() == "GROUP":
            # A folder can be a Photoshop clipping base, but the flattened Live
            # paint graph cannot represent that group result exactly. Do not let
            # a clipped row above the folder bind to an older paint row below it.
            clipping_base_by_scope.pop(scope_key, None)
            record_index = int(_source_record_index(layer))
            group_layer_id = _layer_id(layer, index)
            group_blend_mode = _normalized_blend_mode(
                getattr(layer, "blend_mode", "PASS_THROUGH")
            )
            groups.append(
                {
                    "depth": depth,
                    "record_index": record_index,
                    "layer_index": int(index),
                    "layer_id": group_layer_id,
                    "stack_key": _stack_key(group_layer_id),
                    "layer": layer,
                    "blend_mode": group_blend_mode,
                    "pass_through": group_blend_mode == "PASS_THROUGH",
                }
            )
            continue
        adjustment_type = _supported_adjustment_type(layer)
        if adjustment_type:
            adjustment_layer_id = _layer_id(layer, index)
            adjustment_stack_key = _stack_key(adjustment_layer_id)
            if bool(getattr(layer, "clip_to_below", False)):
                if not str(clipping_base_by_scope.get(scope_key, "") or ""):
                    return [], "adjustment_clipping_base_unsupported"
            else:
                clipping_base_by_scope[scope_key] = adjustment_stack_key
            continue
        if not _layer_is_paintable(layer):
            # Unknown adjustment/fill/effect rows cannot participate in the
            # exact Blender graph. A clipping chain crossing one fails closed.
            clipping_base_by_scope.pop(scope_key, None)
            continue
        record_index = int(_source_record_index(layer))
        layer_id = _layer_id(layer, index)
        stack_key = _stack_key(layer_id)
        if stack_key in seen_stack_keys:
            return [], "duplicate_paint_layer_id"
        if record_index >= 0 and record_index in seen_records:
            return [], "duplicate_paint_source_record"
        blend_mode = _normalized_blend_mode(getattr(layer, "blend_mode", "MIX"))
        if blend_mode not in _direct_supported_blend_modes():
            return [], "paint_blend_mode_unsupported"
        clip_to_below = bool(getattr(layer, "clip_to_below", False))
        clip_base_key = ""
        if clip_to_below:
            clip_base_key = str(clipping_base_by_scope.get(scope_key, "") or "")
            if not clip_base_key:
                return [], "paint_clipping_base_unsupported"
        else:
            clipping_base_by_scope[scope_key] = stack_key
        if record_index >= 0:
            seen_records.add(record_index)
        seen_stack_keys.add(stack_key)
        chain.append(
            {
                "record_index": record_index,
                "layer_index": int(index),
                "layer_id": layer_id,
                "stack_key": stack_key,
                "node_token": _node_token(layer_id, record_index),
                "layer": layer,
                "current_blend_mode": blend_mode,
                "ancestor_groups": ancestor_groups,
                "clip_to_below": bool(clip_to_below),
                "clip_base_key": str(clip_base_key),
                "clipping_scope": scope_key,
            }
        )
    if not chain:
        return [], "paint_source_records_missing"
    if len(chain) > _MAX_CHAIN_LAYERS:
        return [], "paint_layer_limit_exceeded"
    # settings.layers is bottom-to-top. Runtime consumers expect Photoshop's
    # top-to-bottom display order and apply reversed(runtime) bottom-to-top.
    # PSD record numbers identify source payloads; they must never override a
    # Blender reorder or exclude a newly-created, not-yet-saved paint row.
    chain.reverse()
    return chain, ""


def _live_composition_structure(material, chain: list[dict[str, Any]]):
    """Build the exact bottom-to-top paint/group/adjustment tree."""
    from . import adjustments

    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if not layers:
        return None, "source_records_missing"
    chain_by_key = {
        str(item.get("stack_key", "") or ""): item
        for item in chain
    }
    root: list[dict[str, Any]] = []
    group_stack: list[dict[str, Any]] = []
    groups: list[dict[str, Any]] = []
    adjustment_nodes: list[dict[str, Any]] = []
    seen_layer_keys: set[str] = set()
    seen_adjustment_keys: set[str] = set()
    clipping_base_by_scope: dict[tuple[str, ...], str] = {}

    for index, layer in enumerate(layers):
        depth = max(0, int(getattr(layer, "group_depth", 0) or 0))
        while group_stack and int(group_stack[-1]["depth"]) >= depth:
            group_stack.pop()
        target = group_stack[-1]["children"] if group_stack else root
        scope_key = tuple(
            str(group.get("stack_key", "") or "") for group in group_stack
        )
        is_group = bool(getattr(layer, "is_group", False)) or str(
            getattr(layer, "layer_kind", "") or ""
        ).upper() == "GROUP"
        if is_group:
            clipping_base_by_scope.pop(scope_key, None)
            layer_id = _layer_id(layer, index)
            mode = _normalized_blend_mode(
                getattr(layer, "blend_mode", "PASS_THROUGH")
            )
            pass_through = mode == "PASS_THROUGH"
            if not pass_through and mode not in _direct_supported_blend_modes():
                return None, "isolated_group_blend_mode_unsupported"
            node = {
                "kind": "group",
                "depth": depth,
                "record_index": int(_source_record_index(layer)),
                "layer_index": int(index),
                "layer_id": layer_id,
                "stack_key": _stack_key(layer_id),
                "node_token": _node_token(
                    layer_id, int(_source_record_index(layer))
                ),
                "layer": layer,
                "blend_mode": mode,
                "pass_through": bool(pass_through),
                "children": [],
            }
            target.append(node)
            groups.append(node)
            group_stack.append(node)
            continue

        layer_id = _layer_id(layer, index)
        stack_key = _stack_key(layer_id)
        clip_to_below = bool(getattr(layer, "clip_to_below", False))
        clip_base_key = ""
        adjustment_type = _supported_adjustment_type(layer)
        supported_content = _layer_is_paintable(layer) or bool(adjustment_type)
        if supported_content:
            if clip_to_below:
                clip_base_key = str(
                    clipping_base_by_scope.get(scope_key, "") or ""
                )
                if not clip_base_key:
                    return None, "composition_clipping_base_unsupported"
            else:
                clipping_base_by_scope[scope_key] = stack_key

        if _layer_is_paintable(layer):
            item = chain_by_key.get(stack_key)
            if item is None:
                return None, "composition_tree_layer_missing"
            item["clip_to_below"] = bool(clip_to_below)
            item["clip_base_key"] = str(clip_base_key)
            target.append({"kind": "layer", "stack_key": stack_key})
            seen_layer_keys.add(stack_key)
            continue

        if adjustment_type:
            mode = _normalized_blend_mode(getattr(layer, "blend_mode", "MIX"))
            if mode != "MIX":
                return None, "adjustment_blend_mode_unsupported"
            if stack_key in seen_adjustment_keys:
                return None, "duplicate_adjustment_layer_id"
            node = {
                "kind": "adjustment",
                "depth": depth,
                "record_index": int(_source_record_index(layer)),
                "layer_index": int(index),
                "layer_id": layer_id,
                "stack_key": stack_key,
                "node_token": _node_token(
                    layer_id, int(_source_record_index(layer))
                ),
                "layer": layer,
                "adjustment_type": adjustment_type,
                "adjustment_state": adjustments.layer_state(layer),
                "clip_to_below": bool(clip_to_below),
                "clip_base_key": str(clip_base_key),
            }
            target.append(node)
            adjustment_nodes.append(node)
            seen_adjustment_keys.add(stack_key)
            continue

        clipping_base_by_scope.pop(scope_key, None)
        if any(not bool(group.get("pass_through", False)) for group in group_stack):
            return None, "isolated_group_unsupported_content"

    if seen_layer_keys != set(chain_by_key):
        return None, "composition_tree_incomplete"

    def signature_rows(nodes):
        rows = []
        for node in nodes:
            kind = str(node.get("kind", "") or "")
            if kind == "layer":
                rows.append(["L", str(node.get("stack_key", "") or "")])
            elif kind == "adjustment":
                rows.append(
                    [
                        "A",
                        str(node.get("stack_key", "") or ""),
                        dict(node.get("adjustment_state", {}) or {}),
                        bool(node.get("clip_to_below", False)),
                        str(node.get("clip_base_key", "") or ""),
                    ]
                )
            else:
                rows.append(
                    [
                        "G",
                        str(node.get("stack_key", "") or ""),
                        str(node.get("blend_mode", "") or ""),
                        bool(node.get("pass_through", False)),
                        signature_rows(list(node.get("children", []) or [])),
                    ]
                )
        return rows

    return {
        "nodes": root,
        "groups": groups,
        "adjustments": adjustment_nodes,
        "signature": json.dumps(signature_rows(root), separators=(",", ":")),
    }, ""


def _live_skipped_rows(material) -> list[dict[str, Any]]:
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    rows = []
    for index, layer in enumerate(layers):
        if _layer_is_paintable(layer) or _supported_adjustment_type(layer):
            continue
        rows.append(
            {
                "layer_index": int(index),
                "record_index": int(_source_record_index(layer)),
                "name": str(getattr(layer, "name", "") or ""),
                "kind": str(getattr(layer, "layer_kind", "") or ""),
                "is_group": bool(getattr(layer, "is_group", False)),
            }
        )
    return rows


def _source_mask_descriptor(record: dict, *, doc_width: int, doc_height: int) -> tuple[dict[str, Any] | None, str]:
    """Describe one exact raster user mask without decoding its pixel plane."""
    try:
        channels = {int(key): value for key, value in dict(record.get("channel_data", {}) or {}).items()}
    except Exception:
        channels = {}
    raw_hex = str(record.get("raw_mask_data", "") or "")
    has_mask_record = bool(raw_hex or -2 in channels or -3 in channels)
    if not has_mask_record:
        return {"source_mask": False, "active": False}, ""
    if -3 in channels:
        return None, "real_or_vector_mask_unsupported"
    try:
        raw = bytes.fromhex(raw_hex)
    except Exception:
        return None, "mask_metadata_invalid_hex"
    if len(raw) < 20:
        return None, "mask_metadata_truncated"
    if len(raw) != 20:
        return None, "mask_extended_metadata_unsupported"
    top, left, bottom, right = struct.unpack_from(">iiii", raw, 0)
    default_color = int(raw[16])
    flags = int(raw[17])
    if default_color not in {0, 255}:
        return None, "mask_default_color_invalid"
    if flags & 0x01:
        return None, "mask_relative_position_unsupported"
    if flags & 0x08:
        return None, "mask_rendered_data_unsupported"
    if flags & 0x10:
        return None, "mask_density_or_feather_unsupported"
    width = int(right) - int(left)
    height = int(bottom) - int(top)
    if width < 0 or height < 0:
        return None, "mask_bounds_invalid"
    if width == 0 or height == 0:
        channel = channels.get(-2)
        if channel is not None and len(channel) > 2:
            return None, "mask_zero_bounds_with_payload"
        return {
            "source_mask": True,
            "active": False,
            "empty": True,
            "disabled": bool(flags & 0x02),
            "record_index": int(record.get("record_index", -1)),
        }, ""
    if width > max(1, int(doc_width) * 4) or height > max(1, int(doc_height) * 4):
        return None, "mask_bounds_unreasonable"
    channel = channels.get(-2)
    if channel is None or len(channel) <= 2:
        return None, "mask_pixel_channel_missing"
    digest = hashlib.sha1()
    digest.update(raw)
    digest.update(bytes(channel))
    return {
        "source_mask": True,
        "active": not bool(flags & 0x02),
        "disabled": bool(flags & 0x02),
        "invert": bool(flags & 0x04),
        "default_color": default_color,
        "rect": (int(left), int(top), int(right), int(bottom)),
        "width": int(width),
        "height": int(height),
        "channel": channel,
        "signature": digest.hexdigest(),
        "record_index": int(record.get("record_index", -1)),
    }, ""


def _mask_modifier_values(layer) -> dict[str, Any]:
    try:
        channel = str(getattr(layer, "mask_channel", "LUMA") or "LUMA").upper()
    except Exception:
        channel = "LUMA"
    if channel not in {"LUMA", "R", "G", "B", "A", "ALPHA"}:
        channel = "LUMA"
    try:
        threshold = max(0.0, min(1.0, float(getattr(layer, "mask_threshold", 0.5))))
    except Exception:
        threshold = 0.5
    try:
        strength = max(0.0, min(2.0, float(getattr(layer, "mask_strength", 1.0) or 0.0)))
    except Exception:
        strength = 1.0
    try:
        invert = bool(getattr(layer, "invert_mask", False))
    except Exception:
        invert = False
    return {
        "channel_name": channel,
        "threshold": float(threshold),
        "strength": float(strength),
        "owner_invert": bool(invert),
    }


def _materialized_mask_descriptor(layer, *, doc_width: int, doc_height: int):
    mode = str(getattr(layer, "mask_mode", "NONE") or "NONE").upper()
    mask_name = str(getattr(layer, "mask_image", "") or "")
    if mode in {"", "NONE", "OFF"}:
        return None, ""
    if mode != "IMAGE":
        return None, "procedural_mask_mode_unsupported"
    image = bpy.data.images.get(mask_name) if mask_name else None
    if image is None:
        return None, "mask_image_missing"
    try:
        pending = bool(image.get("smart_paint_suite_lazy_psd_mask_pending", False))
        full_size = int(image.size[0]) == int(doc_width) and int(image.size[1]) == int(doc_height)
    except Exception:
        pending = False
        full_size = False
    if pending or not full_size:
        return None, ""
    modifiers = _mask_modifier_values(layer)
    signature = hashlib.sha1(
        (
            "image|"
            + str(mask_name)
            + "|"
            + str(int(doc_width))
            + "x"
            + str(int(doc_height))
            + "|"
            + str(modifiers)
        ).encode("utf-8", errors="replace")
    ).hexdigest()
    return {
        "kind": "image",
        "active": True,
        "image_name": str(mask_name),
        "signature": signature,
        **modifiers,
    }, ""


def _mask_descriptor_for_owner(layer, record: dict | None, document: dict):
    """Resolve one editable image mask or an immutable source-mask fallback."""
    mode = str(getattr(layer, "mask_mode", "NONE") or "NONE").upper()
    if mode in {"", "NONE", "OFF"}:
        return None, ""
    width = int(document.get("width", 0) or 0)
    height = int(document.get("height", 0) or 0)
    image_descriptor, image_reason = _materialized_mask_descriptor(
        layer,
        doc_width=width,
        doc_height=height,
    )
    if image_reason:
        return None, image_reason
    if image_descriptor is not None:
        return image_descriptor, ""
    if record is None:
        return None, "recordless_mask_not_materialized"
    descriptor, reason = _source_mask_descriptor(record, doc_width=width, doc_height=height)
    if descriptor is None:
        return None, reason
    if not bool(descriptor.get("source_mask", False)):
        return None, "source_mask_missing"
    if not bool(descriptor.get("active", False)):
        return None, ""
    modifiers = _mask_modifier_values(layer)
    descriptor = dict(descriptor)
    descriptor["kind"] = "source"
    descriptor.update(modifiers)
    descriptor["signature"] = hashlib.sha1(
        (
            str(descriptor.get("signature", "") or "")
            + "|"
            + str(modifiers)
        ).encode("utf-8", errors="replace")
    ).hexdigest()
    return descriptor, ""


def _source_mask_state_supported(layer, descriptor: dict[str, Any]) -> tuple[bool, str]:
    """Compatibility gate used by the explicit CPU review path."""
    mode = str(getattr(layer, "mask_mode", "NONE") or "NONE").upper()
    mask_name = str(getattr(layer, "mask_image", "") or "")
    if not bool(descriptor.get("source_mask", False)):
        if mode != "NONE" or mask_name:
            image = bpy.data.images.get(mask_name) if mask_name else None
            try:
                if image is not None and int(image.size[0]) > 1 and int(image.size[1]) > 1:
                    return True, ""
            except Exception:
                pass
            return False, "local_mask_not_materialized"
        return True, ""
    if mode not in {"NONE", "IMAGE"}:
        return False, "procedural_mask_mode_unsupported"
    if not mask_name:
        return True, ""
    image = bpy.data.images.get(mask_name)
    if image is None:
        return False, "source_mask_proxy_missing"
    try:
        if bool(image.get("smart_paint_suite_lazy_psd_mask_pending", False)):
            return True, ""
        if int(image.size[0]) <= 1 and int(image.size[1]) <= 1:
            return True, ""
        return True, ""
    except Exception:
        pass
    return False, "materialized_mask_invalid"


def _decode_source_mask_u8(descriptor: dict[str, Any], document: dict):
    """Decode a source user mask to Blender-bottom-up uint8 coverage."""
    if not bool(descriptor.get("active", False)):
        return None
    try:
        import numpy as np
        from .. import psd_io

        doc_width = int(document.get("width", 0) or 0)
        doc_height = int(document.get("height", 0) or 0)
        left, top, right, bottom = tuple(int(value) for value in descriptor["rect"])
        width = int(descriptor["width"])
        height = int(descriptor["height"])
        depth = int(document.get("depth", 8) or 8)
        if depth == 8:
            payload = psd_io._psd_decode_channel_bytes(
                descriptor["channel"],
                width,
                height,
                depth,
                psb=bool(document.get("psb")),
            )
            local_u8 = np.frombuffer(
                payload,
                dtype=np.uint8,
                count=width * height,
            ).reshape((height, width))
        else:
            local = psd_io._psd_channel_float_array(
                descriptor["channel"],
                width,
                height,
                depth,
                psb=bool(document.get("psb")),
            )
            local_u8 = np.clip(
                np.floor(np.asarray(local, dtype=np.float32) * 255.0 + 0.5),
                0,
                255,
            ).astype(np.uint8)
        full = np.full((doc_height, doc_width), int(descriptor["default_color"]), dtype=np.uint8)
        dst_x0 = max(0, left)
        dst_y0 = max(0, top)
        dst_x1 = min(doc_width, right)
        dst_y1 = min(doc_height, bottom)
        if dst_x1 > dst_x0 and dst_y1 > dst_y0:
            src_x0 = dst_x0 - left
            src_y0 = dst_y0 - top
            src_x1 = src_x0 + (dst_x1 - dst_x0)
            src_y1 = src_y0 + (dst_y1 - dst_y0)
            blender_y0 = doc_height - dst_y1
            blender_y1 = doc_height - dst_y0
            full[blender_y0:blender_y1, dst_x0:dst_x1] = local_u8[
                src_y0:src_y1,
                src_x0:src_x1,
            ][::-1, :]
        if bool(descriptor.get("invert", False)):
            full = np.subtract(255, full, dtype=np.uint8)
        return full
    except Exception:
        return None


def _apply_mask_modifiers_u8(coverage, descriptor: dict[str, Any]):
    try:
        import numpy as np

        values = np.asarray(coverage, dtype=np.float32) * (1.0 / 255.0)
        threshold = float(descriptor.get("threshold", 0.5))
        if abs(threshold - 0.5) > 1.0e-6:
            if threshold >= 0.5:
                values = np.clip(values - (threshold - 0.5) * 2.0, 0.0, 1.0)
            else:
                values = np.clip(values + (0.5 - threshold) * 2.0, 0.0, 1.0)
        values = np.clip(values * float(descriptor.get("strength", 1.0) or 0.0), 0.0, 1.0)
        if bool(descriptor.get("owner_invert", False)):
            values = 1.0 - values
        return np.ascontiguousarray(
            np.clip(np.floor(values * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
    except Exception:
        return None


def _decode_mask_descriptor_u8(descriptor: dict[str, Any], document: dict):
    try:
        import numpy as np

        if str(descriptor.get("kind", "source") or "source") == "image":
            width = int(document.get("width", 0) or 0)
            height = int(document.get("height", 0) or 0)
            image = bpy.data.images.get(str(descriptor.get("image_name", "") or ""))
            rgba = _image_u8(image, width, height)
            if rgba is None:
                return None
            channel = str(descriptor.get("channel_name", "LUMA") or "LUMA").upper()
            if channel == "R":
                coverage = rgba[:, :, 0]
            elif channel == "G":
                coverage = rgba[:, :, 1]
            elif channel == "B":
                coverage = rgba[:, :, 2]
            elif channel in {"A", "ALPHA"}:
                coverage = rgba[:, :, 3]
            else:
                linear = rgba[:, :, :3].astype(np.float32)
                coverage = np.clip(
                    np.floor(
                        linear[:, :, 0] * 0.2126
                        + linear[:, :, 1] * 0.7152
                        + linear[:, :, 2] * 0.0722
                        + 0.5
                    ),
                    0.0,
                    255.0,
                ).astype(np.uint8)
        else:
            coverage = _decode_source_mask_u8(descriptor, document)
        if coverage is None:
            return None
        return _apply_mask_modifiers_u8(coverage, descriptor)
    except Exception:
        return None


def _fragment_sampler_limit() -> int:
    try:
        import gpu

        getter = getattr(gpu.capabilities, "max_textures_frag_get", None)
        value = int(getter()) if callable(getter) else 0
        if value > 0:
            return value
    except Exception:
        pass
    return 32


def _payload_u8(payload, width: int, height: int):
    if not isinstance(payload, tuple) or len(payload) != 3:
        return None
    try:
        import numpy as np

        pw, ph, pixels = payload
        if int(pw) != int(width) or int(ph) != int(height):
            return None
        return np.ascontiguousarray(
            np.asarray(pixels, dtype=np.uint8).reshape((int(height), int(width), 4)),
            dtype=np.uint8,
        )
    except Exception:
        return None


def _current_entry_pixels_u8(entry, width: int, height: int):
    """Return the freshest process-local pixels of an activated layer, or None.

    While a PSD save runs, the save planner publishes ``save_current_payload``:
    the exact pixels the layered writer stores for that record, read after the
    last stroke or fill. ``current_payload`` only advances on a layer switch or
    an explicit snapshot, so preferring the save payload keeps a merged image
    written during the save from falling behind the saved layer records. The
    save removes the save payload when it finishes.
    """
    pixels = _payload_u8(entry.get("save_current_payload"), width, height)
    if pixels is None:
        pixels = _payload_u8(entry.get("current_payload"), width, height)
    return pixels


def _recordless_layer_canvas(material, layer, layer_id: str, record_index: int):
    """A layer never painted this session has no session entry; its image still holds its pixels."""
    canvas = state.matching_canvas(material, layer_id, record_index)
    if canvas is None and int(record_index) < 0:
        canvas = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
    return canvas


def _image_u8(image, width: int, height: int):
    if image is None:
        return None
    try:
        import numpy as np

        if (int(image.size[0]), int(image.size[1])) != (int(width), int(height)):
            return None
        cached = cached_image_u8_payload(image, width, height)
        if cached is not None:
            return cached
        flat = np.empty(int(width) * int(height) * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        return np.ascontiguousarray(
            np.clip(
                np.floor(flat.reshape((int(height), int(width), 4)) * 255.0 + 0.5),
                0.0,
                255.0,
            ),
            dtype=np.uint8,
        )
    except Exception:
        return None


def _decode_record_u8(record, document):
    try:
        import numpy as np
        from .. import psd_io

        width = int(document.get("width", 0) or 0)
        height = int(document.get("height", 0) or 0)
        depth = int(document.get("depth", 8) or 8)
        color_mode = int(document.get("color_mode", 3) or 3)
        # The editable production documents are normally 8-bit RGB. Building a
        # float32 document-sized RGBA array and quantizing it back to uint8 made
        # a six-layer 4K live graph spend over ten seconds in allocations and
        # conversions. Decode the authored bytes directly and place them in
        # Blender's bottom-up image order. Other PSD modes keep the established
        # generic decoder below.
        if depth == 8 and color_mode in {1, 3}:
            left = int(record.get("left", 0) or 0)
            top = int(record.get("top", 0) or 0)
            right = int(record.get("right", 0) or 0)
            bottom = int(record.get("bottom", 0) or 0)
            box_width = max(0, right - left)
            box_height = max(0, bottom - top)
            if box_width <= 0 or box_height <= 0:
                return np.zeros((height, width, 4), dtype=np.uint8)
            channels = {}
            for channel_id, raw in (record.get("channel_data", {}) or {}).items():
                try:
                    payload = psd_io._psd_decode_channel_bytes(
                        raw,
                        box_width,
                        box_height,
                        depth,
                        psb=bool(document.get("psb")),
                    )
                    channels[int(channel_id)] = np.frombuffer(
                        payload,
                        dtype=np.uint8,
                        count=box_width * box_height,
                    ).reshape((box_height, box_width))
                except Exception:
                    continue
            if not channels:
                return None

            dst_x0 = max(0, left)
            dst_y0 = max(0, top)
            dst_x1 = min(width, right)
            dst_y1 = min(height, bottom)
            if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
                return None
            src_x0 = dst_x0 - left
            src_y0 = dst_y0 - top
            src_x1 = src_x0 + (dst_x1 - dst_x0)
            src_y1 = src_y0 + (dst_y1 - dst_y0)
            full = np.zeros((height, width, 4), dtype=np.uint8)
            blender_y0 = height - dst_y1
            blender_y1 = height - dst_y0
            destination = full[blender_y0:blender_y1, dst_x0:dst_x1, :]

            def _copy_channel(source, output_index: int) -> None:
                if source is None:
                    return
                destination[:, :, output_index] = source[
                    src_y0:src_y1,
                    src_x0:src_x1,
                ][::-1, :]

            if color_mode == 1:
                gray = channels.get(0)
                _copy_channel(gray, 0)
                _copy_channel(gray, 1)
                _copy_channel(gray, 2)
            else:
                red = channels.get(0)
                _copy_channel(red, 0)
                _copy_channel(channels.get(1, red), 1)
                _copy_channel(channels.get(2, red), 2)
            has_color = any(channel_id in channels for channel_id in (0, 1, 2))
            if has_color:
                alpha = channels.get(-1)
                if alpha is None:
                    destination[:, :, 3] = 255
                else:
                    _copy_channel(alpha, 3)
            return full

        rgba = psd_io.decode_lazy_psd_layer_rgba(
            record,
            doc_width=width,
            doc_height=height,
            depth=depth,
            color_mode=color_mode,
            psb=bool(document.get("psb")),
            apply_layer_mask=False,
        )
        if width <= 1 or height <= 1:
            return None
        if rgba is None:
            left = int(record.get("left", 0) or 0)
            top = int(record.get("top", 0) or 0)
            right = int(record.get("right", 0) or 0)
            bottom = int(record.get("bottom", 0) or 0)
            if right <= left or bottom <= top:
                return np.zeros((height, width, 4), dtype=np.uint8)
            return None
        pixels = np.asarray(rgba, dtype=np.float32)
        if pixels.ndim == 2 and tuple(pixels.shape) == (width * height, 4):
            pixels = pixels.reshape((height, width, 4))
        if tuple(pixels.shape) != (height, width, 4):
            return None
        return np.ascontiguousarray(
            np.clip(np.floor(pixels * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
    except Exception:
        return None


def _compose_plain_layer_nodes_chunked(
    nodes,
    layer_states,
    *,
    width: int,
    height: int,
    sps_blend_nodes,
):
    """Compose a plain paint stack without allocating full-document float intermediates."""
    import numpy as np

    ordered = list(nodes or [])
    if not ordered or any(str(node.get("kind", "") or "") != "layer" for node in ordered):
        return None, 0
    if any(str(node.get("stack_key", "") or "") not in layer_states for node in ordered):
        return None, 0

    # Keep the working set bounded on 4K/8K documents. The blend oracle and
    # byte rounding remain identical to the general tree compositor.
    target_pixels = 512 * 1024
    chunk_rows = max(16, min(256, target_pixels // max(1, int(width))))
    result = np.empty((int(height), int(width), 4), dtype=np.uint8)

    def coverage_slice(coverage, y0: int, y1: int):
        if coverage is None:
            return None
        array = np.asarray(coverage, dtype=np.uint8)
        if int(array.size) != int(width) * int(height):
            raise RuntimeError("plain stack mask size mismatch")
        return array.reshape((int(height), int(width)))[y0:y1, :].reshape((-1,))

    def effective_base_alpha(layer_state, y0: int, y1: int):
        pixels = np.asarray(layer_state["pixels"], dtype=np.uint8)
        alpha = (
            pixels[y0:y1, :, 3].reshape((-1,)).astype(np.float32)
            * np.float32(1.0 / 255.0)
        )
        coverage = coverage_slice(layer_state.get("mask_coverage"), y0, y1)
        if coverage is not None:
            alpha *= coverage.astype(np.float32) * np.float32(1.0 / 255.0)
        alpha *= (
            float(layer_state["opacity"])
            if bool(layer_state["enabled"])
            else 0.0
        )
        return alpha

    for y0 in range(0, int(height), int(chunk_rows)):
        y1 = min(int(height), y0 + int(chunk_rows))
        count = (y1 - y0) * int(width)
        output = np.zeros((count, 4), dtype=np.float32)
        clip_alpha_cache = {}
        for node in ordered:
            stack_key = str(node.get("stack_key", "") or "")
            layer_state = layer_states[stack_key]
            pixels = np.asarray(layer_state["pixels"], dtype=np.uint8)
            source = (
                pixels[y0:y1, :, :].reshape((count, 4)).astype(np.float32)
                * np.float32(1.0 / 255.0)
            )
            source_alpha = source[:, 3]
            coverage = coverage_slice(layer_state.get("mask_coverage"), y0, y1)
            if coverage is not None:
                source_alpha = source_alpha * (
                    coverage.astype(np.float32) * np.float32(1.0 / 255.0)
                )
            clip_alpha = 1.0
            if bool(layer_state.get("clip_to_below", False)):
                base_key = str(layer_state.get("clip_base_key", "") or "")
                base_state = layer_states.get(base_key)
                if base_state is None:
                    raise RuntimeError("plain stack clipping base missing")
                clip_alpha = clip_alpha_cache.get(base_key)
                if clip_alpha is None:
                    clip_alpha = effective_base_alpha(base_state, y0, y1)
                    clip_alpha_cache[base_key] = clip_alpha
            output = sps_blend_nodes.composite_one_layer_oracle(
                output[:, :3],
                output[:, 3],
                source[:, :3],
                source_alpha,
                float(layer_state["opacity"]) if bool(layer_state["enabled"]) else 0.0,
                clip_alpha,
                str(layer_state["mode"]),
            )
        result[y0:y1, :, :] = np.ascontiguousarray(
            np.clip(
                np.floor(output.reshape((y1 - y0, int(width), 4)) * 255.0 + 0.5),
                0.0,
                255.0,
            ),
            dtype=np.uint8,
        )
    return result, int(chunk_rows)


def _compose_current_group_stack_pixels(material, context=None, *, any_stack=False):
    """Evaluate a fully supported paint/group/adjustment tree for Full Review.

    ``any_stack`` also evaluates a flat stack (no group or adjustment row) as a
    tree of top-level rows. The PSD save uses it for flat stacks the direct
    chain declines, such as a clipped top row.
    """
    started = time.perf_counter()
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    sourceless = _sourceless_document(material)
    if not any_stack and not sourceless and not any(
        bool(getattr(layer, "is_group", False))
        or str(getattr(layer, "layer_kind", "") or "").upper() == "GROUP"
        or bool(_supported_adjustment_type(layer))
        for layer in layers
    ):
        return None, {"ok": False, "reason": "group_stack_not_applicable"}
    path = _source_path(material)
    if not sourceless and (not path or not Path(path).is_file()):
        return None, {"ok": False, "reason": "source_psd_missing", "path": path}
    try:
        import numpy as np
        from .. import psd_io, sps_blend_nodes
        from . import adjustments

        chain, reason = _live_paint_chain(material)
        if not chain:
            return None, {"ok": False, "reason": reason or "paint_source_records_missing"}
        structure, structure_reason = _live_composition_structure(material, chain)
        if structure is None:
            return None, {"ok": False, "reason": structure_reason}
        unsupported_rows = [
            str(getattr(layer, "name", "") or "")
            for layer in layers
            if not _layer_is_paintable(layer)
            and not _supported_adjustment_type(layer)
            and not bool(getattr(layer, "is_group", False))
            and str(getattr(layer, "layer_kind", "") or "").upper() != "GROUP"
        ]
        if unsupported_rows:
            return None, {
                "ok": False,
                "reason": "group_stack_unsupported_rows",
                "rows": unsupported_rows,
            }

        if sourceless:
            width, height = _sourceless_document_size(material)
            metadata = {
                "width": int(width),
                "height": int(height),
                "depth": 8,
                "color_mode": 3,
                "psb": False,
                "layers": [],
            }
        else:
            metadata = psd_io.read_layered_psd_lazy(
                path,
                decode_merged=False,
                metadata_only=True,
            )
            width = int(metadata.get("width", 0) or 0)
            height = int(metadata.get("height", 0) or 0)
        if width <= 1 or height <= 1:
            return None, {"ok": False, "reason": "source_size_invalid", "path": path}
        material_source_records = {
            int(_source_record_index(layer))
            for layer in layers
            if int(_source_record_index(layer)) >= 0
        }
        metadata_source_records = {
            int(record.get("record_index", -1))
            for record in list(metadata.get("layers", []) or [])
            if int(record.get("record_index", -1)) >= 0
        }
        if material_source_records != metadata_source_records:
            return None, {
                "ok": False,
                "reason": "group_stack_source_records_incomplete",
                "material_records": sorted(material_source_records),
                "source_records": sorted(metadata_source_records),
            }

        document = (
            dict(metadata)
            if sourceless
            else psd_io.read_layered_psd_lazy(path, decode_merged=False)
        )
        records = {
            int(record.get("record_index", -1)): record
            for record in list(document.get("layers", []) or [])
            if int(record.get("record_index", -1)) >= 0
        }
        count = int(width) * int(height)

        def owner_mask_coverage(owner, record_index: int):
            record = records.get(int(record_index)) if int(record_index) >= 0 else None
            if int(record_index) >= 0 and record is None:
                return None, "source_group_record_missing"
            descriptor, mask_reason = _mask_descriptor_for_owner(owner, record, document)
            if descriptor is None:
                return (None, str(mask_reason or ""))
            if not bool(descriptor.get("active", False)):
                return None, ""
            coverage = _decode_mask_descriptor_u8(descriptor, document)
            if coverage is None:
                return None, "review_mask_decode_failed"
            return np.ascontiguousarray(coverage, dtype=np.uint8), ""

        def multiply_coverage(left, right):
            if left is None:
                return right
            if right is None:
                return left
            return np.ascontiguousarray(
                (left.astype(np.uint16) * right.astype(np.uint16) + 127) // 255,
                dtype=np.uint8,
            )

        group_states = {}
        for group in list(structure.get("groups", []) or []):
            stack_key = str(group.get("stack_key", "") or "")
            group_layer = group.get("layer")
            mode = _normalized_blend_mode(
                getattr(group_layer, "blend_mode", group.get("blend_mode", "PASS_THROUGH"))
            )
            if mode != "PASS_THROUGH" and mode not in _direct_supported_blend_modes():
                return None, {
                    "ok": False,
                    "reason": "review_group_blend_mode_unsupported",
                    "stack_key": stack_key,
                    "blend_mode": mode,
                }
            coverage, mask_reason = owner_mask_coverage(
                group_layer,
                int(group.get("record_index", -1)),
            )
            if mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "stack_key": stack_key,
                }
            group_states[stack_key] = {
                "stack_key": stack_key,
                "record_index": int(group.get("record_index", -1)),
                "mode": mode,
                "pass_through": mode == "PASS_THROUGH",
                "enabled": bool(getattr(group_layer, "enabled", True)),
                "opacity": max(
                    0.0,
                    min(1.0, float(getattr(group_layer, "opacity", 1.0) or 0.0)),
                ),
                "mask_coverage": coverage,
            }

        adjustment_states = {}
        for adjustment in list(structure.get("adjustments", []) or []):
            stack_key = str(adjustment.get("stack_key", "") or "")
            adjustment_layer = adjustment.get("layer")
            record_index = int(adjustment.get("record_index", -1))
            coverage, mask_reason = owner_mask_coverage(
                adjustment_layer,
                record_index,
            )
            if mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "stack_key": stack_key,
                }
            adjustment_states[stack_key] = {
                "stack_key": stack_key,
                "record_index": record_index,
                "layer": adjustment_layer,
                "adjustment_state": adjustments.layer_state(adjustment_layer),
                "mask_coverage": coverage,
                "enabled": bool(getattr(adjustment_layer, "enabled", True)),
                "opacity": max(
                    0.0,
                    min(
                        1.0,
                        float(getattr(adjustment_layer, "opacity", 1.0) or 0.0),
                    ),
                ),
                "clip_to_below": bool(adjustment.get("clip_to_below", False)),
                "clip_base_key": str(adjustment.get("clip_base_key", "") or ""),
            }

        layer_states = {}
        current_payload_records = []
        recordless_layers = []
        for item in chain:
            record_index = int(item.get("record_index", -1))
            layer_id = str(item.get("layer_id", "") or "")
            stack_key = str(item.get("stack_key", "") or "")
            layer = item.get("layer")
            record = records.get(record_index) if record_index >= 0 else None
            if record_index >= 0 and record is None:
                return None, {
                    "ok": False,
                    "reason": "source_record_missing",
                    "record_index": record_index,
                }
            entry = state.get_layer(material, layer_id) or {}
            pixels = _current_entry_pixels_u8(entry, width, height)
            if pixels is not None:
                current_payload_records.append(record_index)
            elif record is not None:
                pixels = _decode_record_u8(record, document)
            else:
                canvas = _recordless_layer_canvas(material, layer, layer_id, record_index)
                pixels = _image_u8(canvas, width, height)
                if pixels is None:
                    pixels = np.zeros((height, width, 4), dtype=np.uint8)
                recordless_layers.append(str(getattr(layer, "name", "") or layer_id))
            if pixels is None:
                return None, {
                    "ok": False,
                    "reason": "source_layer_decode_failed",
                    "record_index": record_index,
                }
            coverage, mask_reason = owner_mask_coverage(layer, record_index)
            if mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "record_index": record_index,
                }
            enabled = bool(getattr(layer, "enabled", True))
            opacity = float(getattr(layer, "opacity", 1.0) or 0.0)
            layer_states[stack_key] = {
                "stack_key": stack_key,
                "record_index": record_index,
                "layer": layer,
                "pixels": np.ascontiguousarray(pixels, dtype=np.uint8),
                "mask_coverage": coverage,
                "enabled": bool(enabled),
                "opacity": max(0.0, min(1.0, float(opacity))),
                "mode": _normalized_blend_mode(getattr(layer, "blend_mode", "MIX")),
                "clip_to_below": bool(item.get("clip_to_below", False)),
                "clip_base_key": str(item.get("clip_base_key", "") or ""),
            }

        plain_pixels, plain_chunk_rows = _compose_plain_layer_nodes_chunked(
            structure.get("nodes", []),
            layer_states,
            width=width,
            height=height,
            sps_blend_nodes=sps_blend_nodes,
        )
        if plain_pixels is not None:
            return plain_pixels, {
                "ok": True,
                "reason": (
                    "current_sourceless_stack_composited"
                    if sourceless
                    else "current_group_stack_composited"
                ),
                "path": str(path),
                "width": width,
                "height": height,
                "chain_records": [int(item.get("record_index", -1)) for item in chain],
                "layer_names": [str(getattr(item.get("layer"), "name", "") or "") for item in chain],
                "current_payload_records": sorted(current_payload_records),
                "recordless_layers": recordless_layers,
                "isolated_groups": [],
                "pass_through_groups": [],
                "compositor": "chunked_plain_stack",
                "chunk_rows": int(plain_chunk_rows),
                "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
            }

        def plane2d(value):
            if value is None:
                return None
            return np.ascontiguousarray(value, dtype=np.uint8).reshape((height, width))

        full_layer_states = layer_states
        full_group_states = group_states
        full_adjustment_states = adjustment_states
        for full_state in full_layer_states.values():
            full_state["pixels"] = np.ascontiguousarray(
                full_state["pixels"], dtype=np.uint8
            ).reshape((height, width, 4))
            full_state["mask_plane"] = plane2d(full_state.get("mask_coverage"))
        for full_state in list(full_group_states.values()) + list(full_adjustment_states.values()):
            full_state["mask_plane"] = plane2d(full_state.get("mask_coverage"))

        def compose_band(y0: int, y1: int):
            """Evaluate the whole tree on rows y0:y1; every operation is per pixel."""
            count = (int(y1) - int(y0)) * int(width)

            def band_mask(owner_state):
                plane = owner_state.get("mask_plane")
                return None if plane is None else plane[y0:y1].reshape((-1,))

            layer_states = {
                key: dict(value, pixels=value["pixels"][y0:y1], mask_coverage=band_mask(value))
                for key, value in full_layer_states.items()
            }
            group_states = {
                key: dict(value, mask_coverage=band_mask(value))
                for key, value in full_group_states.items()
            }
            adjustment_states = {
                key: dict(value, mask_coverage=band_mask(value))
                for key, value in full_adjustment_states.items()
            }

            clip_base_alpha = {}
            for stack_key, layer_state in layer_states.items():
                if bool(layer_state.get("clip_to_below", False)):
                    continue
                pixels = layer_state["pixels"]
                alpha = pixels[:, :, 3].astype(np.float32).reshape((-1,)) * (1.0 / 255.0)
                coverage = layer_state.get("mask_coverage")
                if coverage is not None:
                    alpha *= coverage.astype(np.float32).reshape((-1,)) * (1.0 / 255.0)
                alpha *= float(layer_state["opacity"]) if bool(layer_state["enabled"]) else 0.0
                clip_base_alpha[stack_key] = alpha

            def mix_group_effect(backdrop, effected, factor):
                """Interpolate a pass-through group's net effect in premultiplied RGBA."""
                fac = np.asarray(factor, dtype=np.float32)
                if fac.ndim == 0:
                    fac = np.full((count,), float(fac), dtype=np.float32)
                else:
                    fac = fac.reshape((-1,))
                fac = np.clip(fac, 0.0, 1.0)
                inverse = 1.0 - fac
                backdrop_alpha = backdrop[:, 3]
                effected_alpha = effected[:, 3]
                output_alpha = backdrop_alpha * inverse + effected_alpha * fac
                backdrop_premultiplied = backdrop[:, :3] * backdrop_alpha[:, None]
                effected_premultiplied = effected[:, :3] * effected_alpha[:, None]
                output_premultiplied = (
                    backdrop_premultiplied * inverse[:, None]
                    + effected_premultiplied * fac[:, None]
                )
                output = np.zeros_like(effected, dtype=np.float32)
                output[:, 3] = output_alpha
                covered = output_alpha > _INVERSE_EPSILON
                output[covered, :3] = (
                    output_premultiplied[covered] / output_alpha[covered, None]
                )
                return output

            def compose_nodes(nodes, backdrop):
                output = backdrop
                for node in list(nodes or []):
                    if str(node.get("kind", "")) == "layer":
                        layer_state = layer_states.get(str(node.get("stack_key", "") or ""))
                        if layer_state is None:
                            raise RuntimeError("review composition tree layer missing")
                        if sps_blend_nodes.normalize_mode(str(layer_state["mode"])) != "REPLACE" and (
                            not bool(layer_state["enabled"])
                            or float(layer_state["opacity"]) <= 0.0
                            or not bool(np.any(layer_state["pixels"][..., 3]))
                        ):
                            # Nothing of this row reaches the band: the backdrop's
                            # alpha and premultiplied colour stay as they are.
                            continue
                        source = layer_state["pixels"].reshape((count, 4)).astype(np.float32) * (1.0 / 255.0)
                        source_alpha = source[:, 3]
                        coverage = layer_state.get("mask_coverage")
                        if coverage is not None:
                            source_alpha = source_alpha * (
                                coverage.astype(np.float32).reshape((-1,)) * (1.0 / 255.0)
                            )
                        clip_alpha = 1.0
                        if bool(layer_state.get("clip_to_below", False)):
                            clip_alpha = clip_base_alpha.get(str(layer_state.get("clip_base_key", "") or ""))
                            if clip_alpha is None:
                                raise RuntimeError("review clipping base missing")
                        output = sps_blend_nodes.composite_one_layer_oracle(
                            output[:, :3],
                            output[:, 3],
                            source[:, :3],
                            source_alpha,
                            float(layer_state["opacity"]) if bool(layer_state["enabled"]) else 0.0,
                            clip_alpha,
                            str(layer_state["mode"]),
                        )
                        continue
                    if str(node.get("kind", "") or "") == "adjustment":
                        stack_key = str(node.get("stack_key", "") or "")
                        adjustment_state = adjustment_states.get(stack_key)
                        if adjustment_state is None:
                            raise RuntimeError("review composition tree adjustment missing")
                        factor = (
                            float(adjustment_state["opacity"])
                            if bool(adjustment_state["enabled"])
                            else 0.0
                        )
                        coverage = adjustment_state.get("mask_coverage")
                        if coverage is not None:
                            factor = factor * (
                                coverage.astype(np.float32).reshape((-1,))
                                * (1.0 / 255.0)
                            )
                        if bool(adjustment_state.get("clip_to_below", False)):
                            clip_alpha = clip_base_alpha.get(
                                str(adjustment_state.get("clip_base_key", "") or "")
                            )
                            if clip_alpha is None:
                                raise RuntimeError("review adjustment clipping base missing")
                            factor = factor * clip_alpha
                        adjusted = adjustments.apply_rgb(
                            output[:, :3],
                            adjustment_state["adjustment_state"],
                        )
                        updated = output.copy()
                        updated[:, :3] = (
                            output[:, :3] * (1.0 - np.asarray(factor)[:, None])
                            + adjusted * np.asarray(factor)[:, None]
                            if np.asarray(factor).ndim > 0
                            else output[:, :3] * (1.0 - float(factor))
                            + adjusted * float(factor)
                        )
                        output = updated
                        if not bool(adjustment_state.get("clip_to_below", False)):
                            clip_base_alpha[stack_key] = output[:, 3] * factor
                        continue
                    group_state = group_states.get(str(node.get("stack_key", "") or ""))
                    if group_state is None:
                        raise RuntimeError("review composition tree group missing")
                    if bool(group_state.get("pass_through", False)):
                        group_factor = (
                            float(group_state["opacity"])
                            if bool(group_state["enabled"])
                            else 0.0
                        )
                        group_mask = group_state.get("mask_coverage")
                        if group_mask is not None:
                            group_factor = group_factor * (
                                group_mask.astype(np.float32).reshape((-1)) * (1.0 / 255.0)
                            )
                        before_group = output
                        after_group = compose_nodes(node.get("children", []), output)
                        output = mix_group_effect(before_group, after_group, group_factor)
                        continue
                    group_output = compose_nodes(
                        node.get("children", []),
                        np.zeros((count, 4), dtype=np.float32),
                    )
                    group_alpha = group_output[:, 3]
                    group_mask = group_state.get("mask_coverage")
                    if group_mask is not None:
                        group_alpha = group_alpha * (
                            group_mask.astype(np.float32).reshape((-1,)) * (1.0 / 255.0)
                        )
                    output = sps_blend_nodes.composite_one_layer_oracle(
                        output[:, :3],
                        output[:, 3],
                        group_output[:, :3],
                        group_alpha,
                        float(group_state["opacity"]) if bool(group_state["enabled"]) else 0.0,
                        1.0,
                        str(group_state["mode"]),
                    )
                return output

            return compose_nodes(
                structure.get("nodes", []),
                np.zeros((count, 4), dtype=np.float32),
            )

        # Bound the float working set like the plain chunked path: the tree is
        # evaluated band by band, so 4K/8K documents never hold full-canvas float
        # intermediates per layer, group or adjustment.
        band_rows = max(16, min(256, (512 * 1024) // max(1, int(width))))
        bands = [
            (band_y0, min(int(height), band_y0 + band_rows))
            for band_y0 in range(0, int(height), band_rows)
        ]
        pixels_u8 = np.empty((int(height), int(width), 4), dtype=np.uint8)

        def run_band(band_range):
            band_y0, band_y1 = band_range
            band = compose_band(band_y0, band_y1)
            pixels_u8[band_y0:band_y1] = np.clip(
                np.floor(band.reshape((band_y1 - band_y0, int(width), 4)) * 255.0 + 0.5),
                0.0,
                255.0,
            ).astype(np.uint8)

        # numpy releases the GIL inside the per-pixel kernels, so independent
        # bands run side by side; each band writes only its own rows.
        import os as _os

        band_workers = max(1, min(4, (_os.cpu_count() or 2) // 2, len(bands)))
        if band_workers > 1:
            from concurrent.futures import ThreadPoolExecutor

            with ThreadPoolExecutor(max_workers=band_workers) as band_pool:
                list(band_pool.map(run_band, bands))
        else:
            for band_range in bands:
                run_band(band_range)
        return pixels_u8, {
            "ok": True,
            "reason": (
                "current_sourceless_stack_composited"
                if sourceless
                else "current_group_stack_composited"
            ),
            "path": str(path),
            "width": width,
            "height": height,
            "chain_records": [int(item.get("record_index", -1)) for item in chain],
            "layer_names": [str(getattr(item.get("layer"), "name", "") or "") for item in chain],
            "current_payload_records": sorted(current_payload_records),
            "recordless_layers": recordless_layers,
            "isolated_groups": [
                str(getattr(group.get("layer"), "name", "") or "")
                for group in list(structure.get("groups", []) or [])
                if not bool(group_states.get(str(group.get("stack_key", "") or ""), {}).get("pass_through", False))
            ],
            "pass_through_groups": [
                str(getattr(group.get("layer"), "name", "") or "")
                for group in list(structure.get("groups", []) or [])
                if bool(group_states.get(str(group.get("stack_key", "") or ""), {}).get("pass_through", False))
            ],
            "compositor": "chunked_tree",
            "chunk_rows": int(band_rows),
            "band_workers": int(band_workers),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return None, {
            "ok": False,
            "reason": "current_group_stack_exception",
            "error": repr(exc)[:512],
            "path": str(path),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }


def compose_current_stack_pixels(material, context=None):
    """Return the supported flat PSD stack as one current straight-RGBA image.

    This is an explicit review operation, not a timer path. It decodes each
    source record once, substitutes exact process-local layer snapshots, and
    applies the same CPU blend oracle as the live shader groups.
    """
    group_pixels, group_result = _compose_current_group_stack_pixels(material, context)
    if str(group_result.get("reason", "") or "") != "group_stack_not_applicable":
        return group_pixels, group_result
    started = time.perf_counter()
    path = _source_path(material)
    if not path or not Path(path).is_file():
        return None, {"ok": False, "reason": "source_psd_missing", "path": path}
    try:
        import numpy as np
        from .. import psd_io, sps_blend_nodes

        chain, reason = _top_normal_chain(material)
        chain_records = [int(item["record_index"]) for item in chain]
        settings = _settings(material)
        material_layers = list(
            getattr(settings, "layers", ()) if settings is not None else ()
        )
        material_source_records = sorted(
            {
                int(_source_record_index(layer))
                for layer in material_layers
                if int(_source_record_index(layer)) >= 0
            },
            reverse=True,
        )
        has_recordless_paint = any(
            _layer_is_paintable(layer) and int(_source_record_index(layer)) < 0
            for layer in material_layers
        )
        if (
            not chain
            or has_recordless_paint
            or chain_records != material_source_records
            or set(chain_records) != set(material_source_records)
        ):
            return None, {
                "ok": False,
                "reason": reason or "direct_stack_incomplete",
                "chain_records": chain_records,
                "source_records": material_source_records,
            }

        document = psd_io.read_layered_psd_lazy(
            path,
            decode_merged=False,
            metadata_only=True,
        )
        width = int(document.get("width", 0) or 0)
        height = int(document.get("height", 0) or 0)
        if width <= 1 or height <= 1:
            return None, {"ok": False, "reason": "source_size_invalid", "path": path}
        records = {
            int(record.get("record_index", -1)): record
            for record in list(document.get("layers", []) or [])
            if int(record.get("record_index", -1)) >= 0
        }
        if (
            not chain
            or chain_records != sorted(records.keys(), reverse=True)
            or set(chain_records) != set(records.keys())
        ):
            return None, {
                "ok": False,
                "reason": reason or "direct_stack_incomplete",
                "chain_records": chain_records,
                "source_records": sorted(records.keys(), reverse=True),
            }

        # Only a genuinely flat, fully supported document needs channel bytes.
        # Complex Photoshop documents normally exit at the metadata gate above;
        # copying every raw layer payload just to reject them added seconds to
        # every Full Review click.
        document = psd_io.read_layered_psd_lazy(path, decode_merged=False)
        records = {
            int(record.get("record_index", -1)): record
            for record in list(document.get("layers", []) or [])
            if int(record.get("record_index", -1)) >= 0
        }

        count = width * height
        output = np.zeros((count, 4), dtype=np.float32)
        layer_names = []
        current_payload_records = []
        for spec in reversed(chain):
            record_index = int(spec["record_index"])
            record = records[record_index]
            layer = spec["layer"]
            descriptor, mask_reason = _mask_descriptor_for_owner(
                layer,
                record,
                document,
            )
            if descriptor is None and mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "record_index": record_index,
                }

            entry = state.get_layer(material, str(spec["layer_id"] or "")) or {}
            pixels = _current_entry_pixels_u8(entry, width, height)
            if pixels is not None:
                current_payload_records.append(record_index)
            else:
                pixels = _decode_record_u8(record, document)
            if pixels is None:
                return None, {
                    "ok": False,
                    "reason": "source_layer_decode_failed",
                    "record_index": record_index,
                }

            source = np.asarray(pixels, dtype=np.float32).reshape((count, 4)) * (1.0 / 255.0)
            source_alpha = source[:, 3]
            if descriptor is not None and bool(descriptor.get("active", False)):
                coverage = _decode_mask_descriptor_u8(descriptor, document)
                if coverage is None:
                    return None, {
                        "ok": False,
                        "reason": "source_mask_decode_failed",
                        "record_index": record_index,
                    }
                source_alpha = source_alpha * (
                    np.asarray(coverage, dtype=np.float32).reshape((-1,)) * (1.0 / 255.0)
                )
            opacity = (
                max(0.0, min(1.0, float(getattr(layer, "opacity", 1.0) or 0.0)))
                if bool(getattr(layer, "enabled", True))
                else 0.0
            )
            output = sps_blend_nodes.composite_one_layer_oracle(
                output[:, :3],
                output[:, 3],
                source[:, :3],
                source_alpha,
                opacity,
                1.0,
                _normalized_blend_mode(getattr(layer, "blend_mode", "MIX")),
            )
            layer_names.append(str(getattr(layer, "name", "") or record_index))

        pixels_u8 = np.ascontiguousarray(
            np.clip(np.floor(output.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        return pixels_u8, {
            "ok": True,
            "reason": "current_direct_stack_composited",
            "path": str(path),
            "width": width,
            "height": height,
            "chain_records": chain_records,
            "layer_names": list(reversed(layer_names)),
            "current_payload_records": sorted(current_payload_records),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return None, {
            "ok": False,
            "reason": "current_direct_stack_exception",
            "error": repr(exc)[:512],
            "path": str(path),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }


def _cache_image(
    name: str,
    pixels_u8,
    *,
    signature: str,
    role: str,
    record_index: int = -1,
    colorspace: str = "sRGB",
    alpha_mode: str = "STRAIGHT",
):
    import numpy as np

    pixels = np.asarray(pixels_u8, dtype=np.uint8)
    if pixels.ndim != 3 or int(pixels.shape[2]) != 4:
        return None
    height, width = int(pixels.shape[0]), int(pixels.shape[1])
    image = bpy.data.images.get(name)
    exact = False
    if image is not None:
        try:
            exact = bool(
                _exact_owned_image(image)
                and image.get(_IMAGE_MARKER, False)
                and str(image.get("sps_mvp_live_signature", "") or "") == str(signature or "")
                and str(image.get("sps_mvp_live_role", "") or "") == str(role or "")
                and str(image.get("sps_mvp_live_colorspace", "") or "") == str(colorspace or "")
                and str(image.get("sps_mvp_live_alpha_mode", "") or "") == str(alpha_mode or "")
                and int(image.size[0]) == width
                and int(image.size[1]) == height
            )
        except Exception:
            exact = False
    if exact:
        return image
    if image is None:
        image = bpy.data.images.new(name=name, width=width, height=height, alpha=True, float_buffer=False)
    elif not _exact_owned_image(image):
        image = bpy.data.images.new(
            name=f"{name}_{uuid.uuid4().hex[:10]}",
            width=width,
            height=height,
            alpha=True,
            float_buffer=False,
        )
    try:
        image.generated_color = (1.0, 1.0, 1.0, 0.0)
        image.alpha_mode = str(alpha_mode or "STRAIGHT")
        image.colorspace_settings.name = str(colorspace or "sRGB")
        if int(image.size[0]) != width or int(image.size[1]) != height:
            image.scale(1, 1)
            image.generated_color = (1.0, 1.0, 1.0, 0.0)
            image.scale(width, height)
        float_pixels = np.empty(pixels.shape, dtype=np.float32)
        np.multiply(
            pixels,
            np.float32(1.0 / 255.0),
            out=float_pixels,
            casting="unsafe",
        )
        image.pixels.foreach_set(float_pixels.reshape((-1,)))
        image.update()
        image.use_fake_user = False
        _tag_owned_image(image)
        image[_IMAGE_MARKER] = True
        image["sps_mvp_live_signature"] = str(signature or "")
        image["sps_mvp_live_role"] = str(role or "")
        image["sps_mvp_live_colorspace"] = str(colorspace or "")
        image["sps_mvp_live_alpha_mode"] = str(alpha_mode or "STRAIGHT")
        if int(record_index) >= 0:
            image["sps_mvp_live_record_index"] = int(record_index)
        return image
    except Exception:
        return None


def _premultiply_rgba_u8(pixels_u8):
    """Return encoded RGB times alpha without changing the authored source."""
    import numpy as np

    pixels = np.ascontiguousarray(np.asarray(pixels_u8, dtype=np.uint8))
    if pixels.ndim != 3 or int(pixels.shape[2]) != 4:
        return None
    out = pixels.copy()
    alpha = pixels[:, :, 3]
    alpha_min = int(alpha.min())
    alpha_max = int(alpha.max())
    if alpha_min == 255:
        return out
    if alpha_max == 0:
        out[:, :, :3] = 0
        return out
    work = np.empty(out.shape[:2], dtype=np.uint16)
    for channel in range(3):
        np.multiply(pixels[:, :, channel], alpha, out=work, dtype=np.uint16)
        np.add(work, 127, out=work)
        np.floor_divide(work, 255, out=work)
        out[:, :, channel] = work
    return out


def _cache_premultiplied_image(
    name: str,
    pixels_u8,
    *,
    signature: str,
    role: str,
    record_index: int,
):
    """Cache encoded-premultiplied pixels for fringe-free GPU interpolation."""
    premultiplied = _premultiply_rgba_u8(pixels_u8)
    if premultiplied is None:
        return None
    image = _cache_image(
        name,
        premultiplied,
        signature=signature,
        role=role,
        record_index=int(record_index),
        colorspace="Non-Color",
        alpha_mode="CHANNEL_PACKED",
    )
    if image is not None:
        try:
            image["sps_mvp_premultiplied_display"] = True
        except Exception:
            pass
    return image


def _cache_mask_image(name: str, coverage_u8, *, signature: str, record_index: int):
    try:
        import numpy as np

        coverage = np.asarray(coverage_u8, dtype=np.uint8)
        if coverage.ndim != 2:
            return None
        pixels = np.empty((int(coverage.shape[0]), int(coverage.shape[1]), 4), dtype=np.uint8)
        pixels[:, :, 0] = coverage
        pixels[:, :, 1] = coverage
        pixels[:, :, 2] = coverage
        pixels[:, :, 3] = 255
        return _cache_image(
            name,
            pixels,
            signature=signature,
            role="source_mask",
            record_index=int(record_index),
            colorspace="Non-Color",
        )
    except Exception:
        return None


def clear_material_cache(material, *, remove_unused_images: bool = False) -> None:
    cache = _CACHE.pop(_material_name(material), None) or {}
    if not remove_unused_images:
        return
    for image_name in list(cache.get("image_names", []) or []):
        image = bpy.data.images.get(str(image_name or ""))
        try:
            if _exact_owned_image(image) and int(getattr(image, "users", 0) or 0) <= 0:
                bpy.data.images.remove(image)
        except Exception:
            pass


def has_cache(material) -> bool:
    cache = _CACHE.get(_material_name(material), {}) or {}
    direct_display = bool(
        cache.get("direct_display_stack", cache.get("direct_full_stack", False))
    )
    image_key = "display_image" if direct_display else "old_image"
    return bool(
        cache
        and (
            direct_display
            or bpy.data.images.get(str(cache.get("base_image", "") or "")) is not None
        )
        and all(
            bpy.data.images.get(str(spec.get(image_key, "") or "")) is not None
            and all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cache.get("layers", [])
        )
        and all(
            all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cache.get("groups", [])
        )
        and all(
            all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cache.get("adjustments", [])
        )
    )


def _overlay_mask_contract(mask_specs) -> list[dict[str, Any]]:
    return [
        {
            "image": str(mask_spec.get("image", "") or ""),
            "channel": str(mask_spec.get("channel", "LUMA") or "LUMA").upper(),
            "threshold": float(mask_spec.get("threshold", 0.5) or 0.5),
            "strength": float(mask_spec.get("strength", 1.0) or 0.0),
            "invert": bool(mask_spec.get("invert", False)),
        }
        for mask_spec in list(mask_specs or [])
    ]


def _overlay_tree_contract(nodes) -> list[dict[str, Any]]:
    result = []
    for node in list(nodes or []):
        kind = str(node.get("kind", "") or "")
        row = {
            "kind": kind,
            "stack_key": str(node.get("stack_key", "") or ""),
        }
        if kind == "group":
            row["children"] = _overlay_tree_contract(node.get("children", []))
        result.append(row)
    return result


def _store_image_editor_overlay_contract(
    material,
    cache: dict[str, Any],
    runtime,
    group_runtime,
    adjustment_runtime,
    structure,
    *,
    direct_display_stack: bool,
    direct_premultiplied_stack: bool,
    active_canvas,
) -> dict[str, Any]:
    layers = []
    for spec in list(runtime or []):
        use_live_canvas = bool(spec.get("use_live_canvas", False))
        image = (
            spec.get("current_image_ref")
            if use_live_canvas
            else spec.get("display_image_ref")
        )
        layers.append(
            {
                "stack_key": str(spec.get("stack_key", "") or ""),
                "record_index": int(spec.get("record_index", -1)),
                "layer_id": str(spec.get("layer_id", "") or ""),
                "image": str(getattr(image, "name", "") or ""),
                "scene_linear": bool(use_live_canvas),
                "enabled": bool(spec.get("current_enabled", True)),
                "opacity": float(spec.get("current_opacity", 1.0) or 0.0),
                "blend_mode": str(spec.get("current_blend_mode", "MIX") or "MIX"),
                "clip_to_below": bool(spec.get("clip_to_below", False)),
                "clip_base_key": str(spec.get("clip_base_key", "") or ""),
                "masks": _overlay_mask_contract(spec.get("mask_images", [])),
            }
        )
    groups = {}
    for stack_key, spec in dict(group_runtime or {}).items():
        groups[str(stack_key)] = {
            "stack_key": str(stack_key),
            "record_index": int(spec.get("record_index", -1)),
            "layer_id": str(spec.get("layer_id", "") or ""),
            "enabled": bool(spec.get("current_enabled", True)),
            "opacity": float(spec.get("current_opacity", 1.0) or 0.0),
            "blend_mode": str(spec.get("current_blend_mode", "MIX") or "MIX"),
            "pass_through": bool(spec.get("pass_through", False)),
            "clip_to_below": bool(spec.get("clip_to_below", False)),
            "clip_base_key": str(spec.get("clip_base_key", "") or ""),
            "masks": _overlay_mask_contract(spec.get("mask_images", [])),
        }
    adjustment_rows = {}
    for stack_key, spec in dict(adjustment_runtime or {}).items():
        adjustment_rows[str(stack_key)] = {
            "stack_key": str(stack_key),
            "record_index": int(spec.get("record_index", -1)),
            "layer_id": str(spec.get("layer_id", "") or ""),
            "enabled": bool(spec.get("current_enabled", True)),
            "opacity": float(spec.get("current_opacity", 1.0) or 0.0),
            "clip_to_below": bool(spec.get("clip_to_below", False)),
            "clip_base_key": str(spec.get("clip_base_key", "") or ""),
            "adjustment_state": dict(spec.get("adjustment_state", {}) or {}),
            "masks": _overlay_mask_contract(spec.get("mask_images", [])),
        }
    payload = {
        "version": "ie_overlay_contract_v3_calibrated_adjustments",
        "material": _material_name(material),
        "width": int(cache.get("width", 0) or 0),
        "height": int(cache.get("height", 0) or 0),
        "active_canvas": str(getattr(active_canvas, "name", "") or ""),
        "direct_display_stack": bool(direct_display_stack),
        "direct_premultiplied_stack": bool(direct_premultiplied_stack),
        "nodes": _overlay_tree_contract(structure.get("nodes", [])),
        "layers": layers,
        "groups": groups,
        "adjustments": adjustment_rows,
    }
    payload["signature"] = hashlib.sha1(
        json.dumps(payload, sort_keys=True, ensure_ascii=True).encode("utf-8")
    ).hexdigest()
    cache["image_editor_overlay_contract"] = payload
    _store_material_cache(_material_name(material), cache)
    return payload


def image_editor_overlay_contract(material) -> dict[str, Any] | None:
    """Return the read-only current-stack contract used by the Image Editor."""
    if material is None:
        return None
    try:
        if str(material.get("sps_lightweight_display_mode", "") or "") != "LIVE_COMPOSITE":
            return None
    except Exception:
        return None
    cache = _CACHE.get(_material_name(material), {}) or {}
    contract = cache.get("image_editor_overlay_contract")
    return contract if isinstance(contract, dict) else None


def _prepare_cache(
    material,
    *,
    force: bool = False,
    refresh_metadata: bool = False,
):
    path = _source_path(material)
    sourceless = _sourceless_document(material)
    if not sourceless and (not path or not Path(path).is_file()):
        return None, {"ok": False, "reason": "source_psd_missing"}
    material_name = _material_name(material)
    chain, reason = _live_paint_chain(material)
    if not chain:
        return None, {"ok": False, "reason": reason}
    structure, structure_reason = _live_composition_structure(material, chain)
    if structure is None:
        return None, {"ok": False, "reason": structure_reason}
    structure_signature = str(structure.get("signature", "") or "")
    structure_group_keys = [
        str(group.get("stack_key", "") or "")
        for group in list(structure.get("groups", []) or [])
    ]
    structure_adjustment_keys = [
        str(adjustment.get("stack_key", "") or "")
        for adjustment in list(structure.get("adjustments", []) or [])
    ]
    chain_records = [int(item["record_index"]) for item in chain]
    chain_keys = [str(item["stack_key"] or "") for item in chain]
    chain_ancestor_keys = {
        str(item["stack_key"] or ""): [
            str(group.get("stack_key", "") or "")
            for group in item.get("ancestor_groups", ())
        ]
        for item in chain
    }
    signature = _sourceless_signature(material) if sourceless else _source_signature(path)
    cached = _CACHE.get(material_name, {}) or {}
    cached_direct = bool(cached.get("direct_display_stack", cached.get("direct_full_stack", False)))
    cached_image_key = "display_image" if cached_direct else "old_image"
    cached_assets_valid = bool(
        not force
        and str(cached.get("path", "") or "") == str(path)
        and str(cached.get("signature", "") or "") == str(signature)
        and (
            cached_direct
            or bpy.data.images.get(str(cached.get("base_image", "") or "")) is not None
        )
        and all(
            bpy.data.images.get(str(spec.get(cached_image_key, "") or "")) is not None
            and all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cached.get("layers", [])
        )
        and all(
            all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cached.get("groups", [])
        )
        and all(
            all(
                bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                for mask_spec in list(spec.get("mask_images", []) or [])
            )
            for spec in cached.get("adjustments", [])
        )
    )
    cached_keys = list(cached.get("chain_keys", []) or [])
    cached_ancestors = dict(cached.get("chain_ancestor_keys", {}) or {})
    if (
        not refresh_metadata
        and cached_assets_valid
        and cached_keys == chain_keys
        and cached_ancestors == chain_ancestor_keys
        and str(cached.get("structure_signature", "") or "") == structure_signature
    ):
        return cached, {"ok": True, "cached": True, "reordered": False}
    if (
        not refresh_metadata
        and
        cached_assets_valid
        and len(cached_keys) == len(chain_keys)
        and set(cached_keys) == set(chain_keys)
        and cached_ancestors == chain_ancestor_keys
        and set(cached.get("structure_group_keys", []) or []) == set(structure_group_keys)
        and set(cached.get("structure_adjustment_keys", []) or [])
        == set(structure_adjustment_keys)
    ):
        cache_by_key = {
            str(spec.get("stack_key", "") or ""): spec
            for spec in cached.get("layers", [])
        }
        reordered = [cache_by_key.get(key) for key in chain_keys]
        if all(spec is not None for spec in reordered):
            source_records = list(cached.get("source_records", []) or [])
            direct_full_stack = bool(
                chain_records
                and all(int(index) >= 0 for index in chain_records)
                and chain_records == source_records
                and set(chain_records) == set(source_records)
            )
            cached["chain_records"] = chain_records
            cached["chain_keys"] = chain_keys
            cached["structure_signature"] = structure_signature
            cached["structure_group_keys"] = structure_group_keys
            cached["structure_adjustment_keys"] = structure_adjustment_keys
            cached["layers"] = reordered
            cached["source_blend_modes"] = [
                str(spec.get("old_blend_mode", "MIX") or "MIX")
                for spec in reordered
            ]
            cached["direct_full_stack"] = bool(direct_full_stack)
            return cached, {"ok": True, "cached": True, "reordered": True}

    started = time.perf_counter()
    try:
        import numpy as np
        from .. import psd_io

        # Live mode is built from the editable paint rows themselves. Avoid
        # decoding the large embedded merge; Full Review owns that explicit
        # on-demand operation.
        if sourceless:
            width, height = _sourceless_document_size(material)
            document = {
                "width": int(width),
                "height": int(height),
                "depth": 8,
                "color_mode": 3,
                "psb": False,
                "layers": [],
            }
        else:
            document = psd_io.read_layered_psd_lazy(path, decode_merged=False)
            width = int(document.get("width", 0) or 0)
            height = int(document.get("height", 0) or 0)
        if width <= 1 or height <= 1:
            return None, {"ok": False, "reason": "document_dimensions_invalid"}
        record_map = {
            int(record.get("record_index", -1)): record
            for record in list(document.get("layers", []) or [])
            if int(record.get("record_index", -1)) >= 0
        }
        source_records = sorted(record_map.keys(), reverse=True)
        direct_full_stack = bool(
            chain_records
            and all(int(index) >= 0 for index in chain_records)
            and chain_records == source_records
            and set(chain_records) == set(source_records)
        )
        direct_display_stack = True
        skipped_rows = _live_skipped_rows(material)
        mask_descriptors: dict[str, list[dict[str, Any]]] = {}
        group_mask_descriptors: dict[str, list[dict[str, Any]]] = {}
        adjustment_mask_descriptors: dict[str, list[dict[str, Any]]] = {}
        source_blend_modes: dict[str, str] = {}
        mask_texture_keys: set[str] = set()
        for item in chain:
            record_index = int(item["record_index"])
            stack_key = str(item["stack_key"] or "")
            record = record_map.get(record_index)
            if record_index >= 0 and record is None:
                return None, {"ok": False, "reason": "source_record_missing", "record_index": record_index}
            source_blend_mode = _normalized_blend_mode(
                record.get("blend_mode", "MIX")
                if record is not None
                else getattr(item["layer"], "blend_mode", "MIX")
            )
            if source_blend_mode not in _direct_supported_blend_modes():
                return None, {
                    "ok": False,
                    "reason": "source_blend_mode_unsupported",
                    "record_index": record_index,
                    "blend_mode": source_blend_mode,
                }
            source_blend_modes[stack_key] = source_blend_mode
            descriptor_rows = []
            # Parent masks are cached independently. Pass Through groups attach
            # them to descendants at runtime, while isolated groups apply them
            # once to the composed group result.
            mask_sources = [(item["layer"], record_index)]
            for mask_owner, mask_record_index in mask_sources:
                mask_record = record_map.get(mask_record_index) if mask_record_index >= 0 else None
                if mask_record_index >= 0 and mask_record is None:
                    return None, {
                        "ok": False,
                        "reason": "source_group_record_missing",
                        "record_index": mask_record_index,
                    }
                descriptor, mask_reason = _mask_descriptor_for_owner(
                    mask_owner,
                    mask_record,
                    document,
                )
                if descriptor is None and mask_reason:
                    return None, {
                        "ok": False,
                        "reason": mask_reason,
                        "record_index": mask_record_index,
                    }
                if descriptor is not None and bool(descriptor.get("active", False)):
                    descriptor_rows.append(descriptor)
            mask_descriptors[stack_key] = descriptor_rows
            if any(str(descriptor.get("kind", "source")) == "source" for descriptor in descriptor_rows):
                mask_texture_keys.add("source:" + stack_key)
            for descriptor in descriptor_rows:
                if str(descriptor.get("kind", "source")) == "image":
                    mask_texture_keys.add("image:" + str(descriptor.get("image_name", "") or ""))
        for group in list(structure.get("groups", []) or []):
            group_key = str(group.get("stack_key", "") or "")
            record_index = int(group.get("record_index", -1))
            record = record_map.get(record_index) if record_index >= 0 else None
            if record_index >= 0 and record is None:
                return None, {
                    "ok": False,
                    "reason": "source_group_record_missing",
                    "record_index": record_index,
                }
            descriptor, mask_reason = _mask_descriptor_for_owner(
                group.get("layer"),
                record,
                document,
            )
            if descriptor is None and mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "record_index": record_index,
                }
            descriptor_rows = [descriptor] if descriptor is not None and bool(descriptor.get("active", False)) else []
            group_mask_descriptors[group_key] = descriptor_rows
            if any(str(row.get("kind", "source")) == "source" for row in descriptor_rows):
                mask_texture_keys.add("source:" + group_key)
            for row in descriptor_rows:
                if str(row.get("kind", "source")) == "image":
                    mask_texture_keys.add("image:" + str(row.get("image_name", "") or ""))
        for adjustment in list(structure.get("adjustments", []) or []):
            adjustment_key = str(adjustment.get("stack_key", "") or "")
            record_index = int(adjustment.get("record_index", -1))
            record = record_map.get(record_index) if record_index >= 0 else None
            if record_index >= 0 and record is None:
                return None, {
                    "ok": False,
                    "reason": "source_adjustment_record_missing",
                    "record_index": record_index,
                }
            descriptor, mask_reason = _mask_descriptor_for_owner(
                adjustment.get("layer"),
                record,
                document,
            )
            if descriptor is None and mask_reason:
                return None, {
                    "ok": False,
                    "reason": mask_reason,
                    "record_index": record_index,
                }
            descriptor_rows = (
                [descriptor]
                if descriptor is not None and bool(descriptor.get("active", False))
                else []
            )
            adjustment_mask_descriptors[adjustment_key] = descriptor_rows
            if any(
                str(row.get("kind", "source")) == "source"
                for row in descriptor_rows
            ):
                mask_texture_keys.add("source:" + adjustment_key)
            for row in descriptor_rows:
                if str(row.get("kind", "source")) == "image":
                    mask_texture_keys.add(
                        "image:" + str(row.get("image_name", "") or "")
                    )
        mask_count = len(mask_texture_keys)
        texture_count = (
            len(chain) + int(mask_count)
            if direct_display_stack
            else 1 + len(chain) * 4 + int(mask_count)
        )
        sampler_limit = _fragment_sampler_limit()
        if texture_count > sampler_limit:
            return None, {
                "ok": False,
                "reason": "fragment_sampler_budget_exceeded",
                "texture_count": int(texture_count),
                "sampler_limit": int(sampler_limit),
            }

        token = hashlib.sha1((material_name + "|" + path).encode("utf-8", errors="replace")).hexdigest()[:12]
        base = None
        specs = []
        opaque_pixels = 0
        image_names = []
        reusable_specs = {}
        reusable_group_specs = {}
        reusable_adjustment_specs = {}
        if cached_assets_valid:
            reusable_specs = {
                str(spec.get("stack_key", "") or ""): spec
                for spec in cached.get("layers", [])
                if "opaque_pixels" in spec
                and cached_ancestors.get(str(spec.get("stack_key", "") or ""), [])
                == chain_ancestor_keys.get(str(spec.get("stack_key", "") or ""), [])
            }
            reusable_group_specs = {
                str(spec.get("stack_key", "") or ""): spec
                for spec in cached.get("groups", [])
            }
            reusable_adjustment_specs = {
                str(spec.get("stack_key", "") or ""): spec
                for spec in cached.get("adjustments", [])
            }
        for item in chain:
            record_index = int(item["record_index"])
            layer_id = str(item["layer_id"] or "")
            stack_key = str(item["stack_key"] or "")
            node_token = str(item["node_token"] or "")
            record = record_map.get(record_index)
            if record_index >= 0 and record is None:
                return None, {"ok": False, "reason": "source_record_missing", "record_index": record_index}
            entry = state.get_layer(material, layer_id) or {}
            descriptors = mask_descriptors[stack_key]
            mask_signatures = [str(descriptor.get("signature", "") or "") for descriptor in descriptors]
            expected_mask_signature = "|".join(
                mask_signatures
            )
            source_mask_signature = "|".join(
                str(descriptor.get("signature", "") or "")
                for descriptor in descriptors
                if str(descriptor.get("kind", "source") or "source") == "source"
            )
            live_mask_images = []
            for descriptor in descriptors:
                if str(descriptor.get("kind", "source") or "source") != "image":
                    continue
                image_name = str(descriptor.get("image_name", "") or "")
                if bpy.data.images.get(image_name) is None:
                    return None, {
                        "ok": False,
                        "reason": "materialized_mask_image_missing",
                        "record_index": record_index,
                    }
                live_mask_images.append({
                    "kind": "live_image",
                    "image": image_name,
                    "channel": str(descriptor.get("channel_name", "LUMA") or "LUMA"),
                    "threshold": float(descriptor.get("threshold", 0.5)),
                    "strength": float(descriptor.get("strength", 1.0) or 0.0),
                    "invert": bool(descriptor.get("owner_invert", False)),
                })
            reusable = reusable_specs.get(stack_key)
            if (
                reusable is not None
                and int(reusable.get("record_index", -999)) == record_index
                and str(reusable.get("mask_signature", "") or "") == expected_mask_signature
            ):
                reused_spec = dict(reusable)
                reused_spec.update(
                    {
                        "record_index": record_index,
                        "layer_id": layer_id,
                        "stack_key": stack_key,
                        "node_token": node_token,
                        "source_mask_signature": source_mask_signature,
                    }
                )
                specs.append(reused_spec)
                opaque_pixels += int(reused_spec.get("opaque_pixels", 0) or 0)
                for image_key in ("old_image", "display_image"):
                    image_name = str(reused_spec.get(image_key, "") or "")
                    if image_name and image_name not in image_names:
                        image_names.append(image_name)
                for mask_spec in list(reused_spec.get("mask_images", []) or []):
                    if str(mask_spec.get("kind", "") or "") != "source_cache":
                        continue
                    image_name = str(mask_spec.get("image", "") or "")
                    if image_name and image_name not in image_names:
                        image_names.append(image_name)
                continue
            if reusable is not None and int(reusable.get("record_index", -999)) == record_index:
                prior_source_masks = [
                    dict(mask_spec)
                    for mask_spec in list(reusable.get("mask_images", []) or [])
                    if str(mask_spec.get("kind", "") or "") == "source_cache"
                ]
                prior_live_masks = [
                    mask_spec
                    for mask_spec in list(reusable.get("mask_images", []) or [])
                    if str(mask_spec.get("kind", "") or "") == "live_image"
                ]
                reusable_source_signature = reusable.get("source_mask_signature")
                if reusable_source_signature is None:
                    reusable_source_signature = (
                        str(reusable.get("mask_signature", "") or "")
                        if prior_source_masks and not prior_live_masks
                        else ""
                    )
                source_assets_ready = bool(
                    not source_mask_signature
                    or (
                        prior_source_masks
                        and all(
                            bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                            for mask_spec in prior_source_masks
                        )
                    )
                )
                if str(reusable_source_signature or "") == source_mask_signature and source_assets_ready:
                    # A materialized mask changes only graph metadata. Keep the
                    # decoded 4K paint texture and any immutable source mask.
                    reused_spec = dict(reusable)
                    reused_spec.update(
                        {
                            "record_index": record_index,
                            "layer_id": layer_id,
                            "stack_key": stack_key,
                            "node_token": node_token,
                            "mask_images": prior_source_masks + live_mask_images,
                            "mask_signature": expected_mask_signature,
                            "source_mask_signature": source_mask_signature,
                            # A newly attached live mask can only reduce this
                            # count; zero is the conservative no-rescan value.
                            "opaque_pixels": (
                                int(reusable.get("opaque_pixels", 0) or 0)
                                if not live_mask_images
                                else 0
                            ),
                        }
                    )
                    specs.append(reused_spec)
                    opaque_pixels += int(reused_spec.get("opaque_pixels", 0) or 0)
                    for image_key in ("old_image", "display_image"):
                        image_name = str(reused_spec.get(image_key, "") or "")
                        if image_name and image_name not in image_names:
                            image_names.append(image_name)
                    for mask_spec in list(reused_spec.get("mask_images", []) or []):
                        if str(mask_spec.get("kind", "") or "") != "source_cache":
                            continue
                        image_name = str(mask_spec.get("image", "") or "")
                        if image_name and image_name not in image_names:
                            image_names.append(image_name)
                    continue
            old_pixels = _payload_u8(entry.get("preview_baseline_payload"), width, height)
            baseline_canvas = _recordless_layer_canvas(material, item.get("layer"), layer_id, record_index)
            if old_pixels is None and record is not None:
                old_pixels = _decode_record_u8(record, document)
            if old_pixels is None and record is None:
                old_pixels = _image_u8(baseline_canvas, width, height)
            if old_pixels is None and record is None:
                old_pixels = np.zeros((height, width, 4), dtype=np.uint8)
            if old_pixels is None:
                return None, {"ok": False, "reason": "source_layer_decode_failed", "record_index": record_index}
            baseline_signature = signature
            if record is None:
                baseline_signature = "|".join(
                    (
                        str(signature),
                        stack_key,
                        hashlib.sha1(memoryview(old_pixels)).hexdigest()[:16],
                    )
                )
            old_image_name = ""
            display_image_name = ""
            display_current_signature = ""
            display_pixels = old_pixels
            if direct_display_stack:
                current_pixels = _payload_u8(entry.get("current_payload"), width, height)
                if current_pixels is not None:
                    display_pixels = current_pixels
                    if baseline_canvas is not None:
                        display_current_signature = _current_display_signature(
                            baseline_canvas,
                            {"signature": signature},
                            stack_key,
                        )
                display_image = _cache_premultiplied_image(
                    f"SPS_MVP_LivePremul_{token}_{node_token}",
                    display_pixels,
                    signature=display_current_signature or baseline_signature,
                    role="source_premultiplied",
                    record_index=record_index,
                )
                if display_image is None:
                    return None, {
                        "ok": False,
                        "reason": "source_display_image_failed",
                        "record_index": record_index,
                    }
                display_image_name = str(display_image.name)
                image_names.append(display_image_name)
            else:
                old_image = _cache_image(
                    f"SPS_MVP_LiveOld_{token}_{node_token}",
                    old_pixels,
                    signature=baseline_signature,
                    role="source_baseline",
                    record_index=record_index,
                )
                if old_image is None:
                    return None, {
                        "ok": False,
                        "reason": "source_layer_image_failed",
                        "record_index": record_index,
                    }
                old_image_name = str(old_image.name)
                image_names.append(old_image_name)
            mask_images = list(live_mask_images)
            source_mask_coverage = None
            for descriptor in descriptors:
                if str(descriptor.get("kind", "source") or "source") == "image":
                    continue
                coverage = _decode_mask_descriptor_u8(descriptor, document)
                if coverage is None:
                    return None, {
                        "ok": False,
                        "reason": "source_mask_decode_failed",
                        "record_index": record_index,
                    }
                if source_mask_coverage is None:
                    source_mask_coverage = coverage
                else:
                    source_mask_coverage = (
                        source_mask_coverage.astype(np.uint16) * coverage.astype(np.uint16) + 127
                    ) // 255
                    source_mask_coverage = np.ascontiguousarray(source_mask_coverage, dtype=np.uint8)
            if source_mask_coverage is not None:
                mask_signature = "|".join(
                    str(descriptor.get("signature", "") or "")
                    for descriptor in descriptors
                    if str(descriptor.get("kind", "source") or "source") == "source"
                ) or signature
                mask_image = _cache_mask_image(
                    f"SPS_MVP_LiveMask_{token}_{node_token}",
                    source_mask_coverage,
                    signature=mask_signature,
                    record_index=record_index,
                )
                if mask_image is None:
                    return None, {"ok": False, "reason": "source_mask_image_failed", "record_index": record_index}
                mask_image_name = str(mask_image.name)
                image_names.append(mask_image_name)
                mask_images.insert(0, {
                    "kind": "source_cache",
                    "image": mask_image_name,
                    "channel": "R",
                    "threshold": 0.5,
                    "strength": 1.0,
                    "invert": False,
                })
            alpha_pixels = display_pixels if direct_display_stack else old_pixels
            if source_mask_coverage is None:
                effective_alpha = alpha_pixels[:, :, 3]
            else:
                effective_alpha = (
                    alpha_pixels[:, :, 3].astype(np.uint16) * source_mask_coverage.astype(np.uint16) + 127
                ) // 255
            layer_opaque_pixels = int(np.count_nonzero(effective_alpha >= 255))
            opaque_pixels += layer_opaque_pixels
            specs.append({
                "record_index": record_index,
                "layer_id": layer_id,
                "stack_key": stack_key,
                "node_token": node_token,
                "old_image": old_image_name,
                "display_image": display_image_name,
                "display_current_signature": display_current_signature,
                "mask_images": mask_images,
                "mask_signature": "|".join(mask_signatures),
                "source_mask_signature": source_mask_signature,
                "opaque_pixels": int(layer_opaque_pixels),
                "old_blend_mode": str(source_blend_modes[stack_key]),
                "old_enabled": bool(
                    entry.get(
                        "preview_enabled",
                        record.get("enabled", True)
                        if record is not None
                        else getattr(item["layer"], "enabled", True),
                    )
                ),
                "old_opacity": float(
                    entry.get(
                        "preview_opacity",
                        record.get("opacity", 1.0)
                        if record is not None
                        else getattr(item["layer"], "opacity", 1.0),
                    )
                    or 0.0
                ),
            })
        group_specs = []
        for group in list(structure.get("groups", []) or []):
            record_index = int(group.get("record_index", -1))
            layer_id = str(group.get("layer_id", "") or "")
            stack_key = str(group.get("stack_key", "") or "")
            node_token = str(group.get("node_token", "") or "")
            descriptors = list(group_mask_descriptors.get(stack_key, []) or [])
            mask_signature = "|".join(
                str(descriptor.get("signature", "") or "")
                for descriptor in descriptors
            )
            reusable = reusable_group_specs.get(stack_key)
            if (
                reusable is not None
                and int(reusable.get("record_index", -999)) == record_index
                and str(reusable.get("mask_signature", "") or "") == mask_signature
                and all(
                    bpy.data.images.get(str(mask_spec.get("image", "") or "")) is not None
                    for mask_spec in list(reusable.get("mask_images", []) or [])
                )
            ):
                reused_spec = dict(reusable)
                reused_spec.update({
                    "record_index": record_index,
                    "layer_id": layer_id,
                    "stack_key": stack_key,
                    "node_token": node_token,
                })
                group_specs.append(reused_spec)
                for mask_spec in list(reused_spec.get("mask_images", []) or []):
                    if str(mask_spec.get("kind", "") or "") != "source_cache":
                        continue
                    image_name = str(mask_spec.get("image", "") or "")
                    if image_name and image_name not in image_names:
                        image_names.append(image_name)
                continue

            mask_images = []
            source_mask_coverage = None
            for descriptor in descriptors:
                if str(descriptor.get("kind", "source") or "source") == "image":
                    image_name = str(descriptor.get("image_name", "") or "")
                    if bpy.data.images.get(image_name) is None:
                        return None, {
                            "ok": False,
                            "reason": "materialized_group_mask_image_missing",
                            "record_index": record_index,
                        }
                    mask_images.append({
                        "kind": "live_image",
                        "image": image_name,
                        "channel": str(descriptor.get("channel_name", "LUMA") or "LUMA"),
                        "threshold": float(descriptor.get("threshold", 0.5)),
                        "strength": float(descriptor.get("strength", 1.0) or 0.0),
                        "invert": bool(descriptor.get("owner_invert", False)),
                    })
                    continue
                coverage = _decode_mask_descriptor_u8(descriptor, document)
                if coverage is None:
                    return None, {
                        "ok": False,
                        "reason": "source_group_mask_decode_failed",
                        "record_index": record_index,
                    }
                if source_mask_coverage is None:
                    source_mask_coverage = coverage
                else:
                    source_mask_coverage = (
                        source_mask_coverage.astype(np.uint16) * coverage.astype(np.uint16) + 127
                    ) // 255
                    source_mask_coverage = np.ascontiguousarray(source_mask_coverage, dtype=np.uint8)
            if source_mask_coverage is not None:
                mask_image = _cache_mask_image(
                    f"SPS_MVP_LiveGroupMask_{token}_{node_token}",
                    source_mask_coverage,
                    signature=mask_signature or signature,
                    record_index=record_index,
                )
                if mask_image is None:
                    return None, {
                        "ok": False,
                        "reason": "source_group_mask_image_failed",
                        "record_index": record_index,
                    }
                image_name = str(mask_image.name)
                image_names.append(image_name)
                mask_images.insert(0, {
                    "kind": "source_cache",
                    "image": image_name,
                    "channel": "R",
                    "threshold": 0.5,
                    "strength": 1.0,
                    "invert": False,
                })
            group_specs.append({
                "record_index": record_index,
                "layer_id": layer_id,
                "stack_key": stack_key,
                "node_token": node_token,
                "mask_images": mask_images,
                "mask_signature": mask_signature,
            })
        adjustment_specs = []
        for adjustment in list(structure.get("adjustments", []) or []):
            record_index = int(adjustment.get("record_index", -1))
            layer_id = str(adjustment.get("layer_id", "") or "")
            stack_key = str(adjustment.get("stack_key", "") or "")
            node_token = str(adjustment.get("node_token", "") or "")
            descriptors = list(
                adjustment_mask_descriptors.get(stack_key, []) or []
            )
            mask_signature = "|".join(
                str(descriptor.get("signature", "") or "")
                for descriptor in descriptors
            )
            reusable = reusable_adjustment_specs.get(stack_key)
            if (
                reusable is not None
                and int(reusable.get("record_index", -999)) == record_index
                and str(reusable.get("mask_signature", "") or "")
                == mask_signature
                and all(
                    bpy.data.images.get(
                        str(mask_spec.get("image", "") or "")
                    )
                    is not None
                    for mask_spec in list(reusable.get("mask_images", []) or [])
                )
            ):
                reused_spec = dict(reusable)
                reused_spec.update(
                    {
                        "record_index": record_index,
                        "layer_id": layer_id,
                        "stack_key": stack_key,
                        "node_token": node_token,
                    }
                )
                adjustment_specs.append(reused_spec)
                for mask_spec in list(reused_spec.get("mask_images", []) or []):
                    if str(mask_spec.get("kind", "") or "") != "source_cache":
                        continue
                    image_name = str(mask_spec.get("image", "") or "")
                    if image_name and image_name not in image_names:
                        image_names.append(image_name)
                continue

            mask_images = []
            source_mask_coverage = None
            for descriptor in descriptors:
                if str(descriptor.get("kind", "source") or "source") == "image":
                    image_name = str(descriptor.get("image_name", "") or "")
                    if bpy.data.images.get(image_name) is None:
                        return None, {
                            "ok": False,
                            "reason": "materialized_adjustment_mask_image_missing",
                            "record_index": record_index,
                        }
                    mask_images.append(
                        {
                            "kind": "live_image",
                            "image": image_name,
                            "channel": str(
                                descriptor.get("channel_name", "LUMA") or "LUMA"
                            ),
                            "threshold": float(descriptor.get("threshold", 0.5)),
                            "strength": float(
                                descriptor.get("strength", 1.0) or 0.0
                            ),
                            "invert": bool(descriptor.get("owner_invert", False)),
                        }
                    )
                    continue
                coverage = _decode_mask_descriptor_u8(descriptor, document)
                if coverage is None:
                    return None, {
                        "ok": False,
                        "reason": "source_adjustment_mask_decode_failed",
                        "record_index": record_index,
                    }
                if source_mask_coverage is None:
                    source_mask_coverage = coverage
                else:
                    source_mask_coverage = (
                        source_mask_coverage.astype(np.uint16)
                        * coverage.astype(np.uint16)
                        + 127
                    ) // 255
                    source_mask_coverage = np.ascontiguousarray(
                        source_mask_coverage, dtype=np.uint8
                    )
            if source_mask_coverage is not None:
                mask_image = _cache_mask_image(
                    f"SPS_MVP_LiveAdjustmentMask_{token}_{node_token}",
                    source_mask_coverage,
                    signature=mask_signature or signature,
                    record_index=record_index,
                )
                if mask_image is None:
                    return None, {
                        "ok": False,
                        "reason": "source_adjustment_mask_image_failed",
                        "record_index": record_index,
                    }
                image_name = str(mask_image.name)
                image_names.append(image_name)
                mask_images.insert(
                    0,
                    {
                        "kind": "source_cache",
                        "image": image_name,
                        "channel": "R",
                        "threshold": 0.5,
                        "strength": 1.0,
                        "invert": False,
                    },
                )
            adjustment_specs.append(
                {
                    "record_index": record_index,
                    "layer_id": layer_id,
                    "stack_key": stack_key,
                    "node_token": node_token,
                    "mask_images": mask_images,
                    "mask_signature": mask_signature,
                }
            )
        cached = {
            "path": str(path),
            "signature": str(signature),
            "width": width,
            "height": height,
            "base_image": str(getattr(base, "name", "") or ""),
            "chain_records": chain_records,
            "chain_keys": chain_keys,
            "chain_ancestor_keys": chain_ancestor_keys,
            "structure_signature": structure_signature,
            "structure_group_keys": structure_group_keys,
            "structure_adjustment_keys": structure_adjustment_keys,
            "source_records": source_records,
            "source_blend_modes": [str(source_blend_modes[key]) for key in chain_keys],
            "layers": specs,
            "groups": group_specs,
            "adjustments": adjustment_specs,
            "mask_count": int(mask_count),
            "blend_modes": sorted(set(source_blend_modes.values())),
            "texture_count": int(texture_count),
            "sampler_limit": int(sampler_limit),
            "opaque_pixels": int(opaque_pixels),
            "direct_full_stack": bool(direct_full_stack),
            "direct_display_stack": bool(direct_display_stack),
            "skipped_rows": skipped_rows,
            "image_names": image_names,
        }
        _store_material_cache(material_name, cached)
        return cached, {
            "ok": True,
            "cached": False,
            "mask_count": int(mask_count),
            "texture_count": int(texture_count),
            "sampler_limit": int(sampler_limit),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return None, {"ok": False, "reason": "live_cache_exception", "error": repr(exc)[:512]}


def _add_socket(group, name: str, in_out: str, socket_type: str):
    socket = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    if socket_type == "NodeSocketFloat":
        socket.min_value = 0.0
        socket.max_value = 1.0
    return socket


def _link_or_set(tree, value, socket) -> None:
    if hasattr(value, "is_output"):
        tree.links.new(value, socket)
    else:
        socket.default_value = float(value)


def _math(tree, operation: str, a, b=0.0, *, clamp: bool = False):
    node = tree.nodes.new("ShaderNodeMath")
    _mark_node(node, "formula_math")
    node.operation = operation
    node.use_clamp = bool(clamp)
    _link_or_set(tree, a, node.inputs[0])
    _link_or_set(tree, b, node.inputs[1])
    return node.outputs[0]


def _separate(tree, color):
    node = tree.nodes.new("ShaderNodeSeparateColor")
    _mark_node(node, "formula_separate")
    node.mode = "RGB"
    tree.links.new(color, node.inputs["Color"])
    return node


def _combine(tree, channels):
    node = tree.nodes.new("ShaderNodeCombineColor")
    _mark_node(node, "formula_combine")
    node.mode = "RGB"
    for name, value in zip(("Red", "Green", "Blue"), channels):
        _link_or_set(tree, value, node.inputs[name])
    return node.outputs["Color"]


def _ensure_color_conversion_group(direction: str):
    key = str(direction or "").upper()
    name = "SPS_MVP_LinearToSRGB_v1" if key == "ENCODE" else "SPS_MVP_SRGBToLinear_v1"
    group = bpy.data.node_groups.get(name)
    if _exact_owned_group(group) and str(group.get("sps_mvp_formula_version", "") or "") == _COLOR_CONVERSION_VERSION:
        return group
    group = _replace_owned_group_or_create(name, group)
    group["sps_mvp_formula_version"] = _COLOR_CONVERSION_VERSION
    group["sps_mvp_color_conversion"] = key
    _add_socket(group, "Color", "INPUT", "NodeSocketColor")
    _add_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    inp = group.nodes.new("NodeGroupInput")
    out = group.nodes.new("NodeGroupOutput")
    separated = _separate(group, inp.outputs["Color"])
    outputs = []
    for channel in ("Red", "Green", "Blue"):
        value = separated.outputs[channel]
        if key == "ENCODE":
            selector = _math(group, "LESS_THAN", value, 0.0031308)
            low = _math(group, "MULTIPLY", value, 12.92)
            high = _math(
                group,
                "SUBTRACT",
                _math(group, "MULTIPLY", _math(group, "POWER", value, 1.0 / 2.4), 1.055),
                0.055,
            )
        else:
            selector = _math(group, "LESS_THAN", value, 0.04045)
            low = _math(group, "DIVIDE", value, 12.92)
            high = _math(
                group,
                "POWER",
                _math(group, "DIVIDE", _math(group, "ADD", value, 0.055), 1.055),
                2.4,
            )
        result = _math(
            group,
            "ADD",
            _math(group, "MULTIPLY", low, selector),
            _math(group, "MULTIPLY", high, _math(group, "SUBTRACT", 1.0, selector)),
            clamp=True,
        )
        outputs.append(result)
    group.links.new(_combine(group, outputs), out.inputs["Color"])
    return group


def _ensure_live_normal_blend_group():
    """Return a compact straight-alpha Source-Over group for Live MIX rows."""
    name = "SPS_MVP_LiveNormalBlend_v1"
    version = "straight_source_over_clip_v1"
    group = bpy.data.node_groups.get(name)
    if _exact_owned_group(group) and str(group.get("sps_mvp_formula_version", "") or "") == version:
        return group
    group = _replace_owned_group_or_create(name, group)
    group["sps_mvp_formula_version"] = version
    group["sps_mvp_contract"] = "straight_srgb_source_over_with_clip_alpha"
    for socket_name, socket_type in (
        ("Dst Color", "NodeSocketColor"),
        ("Dst Alpha", "NodeSocketFloat"),
        ("Src Color", "NodeSocketColor"),
        ("Src Alpha", "NodeSocketFloat"),
        ("Opacity", "NodeSocketFloat"),
        ("Clip Alpha", "NodeSocketFloat"),
    ):
        _add_socket(group, socket_name, "INPUT", socket_type)
    _add_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    _add_socket(group, "Alpha", "OUTPUT", "NodeSocketFloat")
    inp = group.nodes.new("NodeGroupInput")
    out = group.nodes.new("NodeGroupOutput")
    effective = _math(
        group,
        "MULTIPLY",
        _math(group, "MULTIPLY", inp.outputs["Src Alpha"], inp.outputs["Opacity"], clamp=True),
        inp.outputs["Clip Alpha"],
        clamp=True,
    )
    inverse = _math(group, "SUBTRACT", 1.0, effective, clamp=True)
    destination = _math(group, "MULTIPLY", inp.outputs["Dst Alpha"], inverse, clamp=True)
    output_alpha = _math(group, "ADD", effective, destination, clamp=True)
    source_factor = _math(
        group,
        "DIVIDE",
        effective,
        _math(group, "MAXIMUM", output_alpha, _INVERSE_EPSILON),
        clamp=True,
    )
    mix = group.nodes.new("ShaderNodeMixRGB")
    mix.blend_type = "MIX"
    mix.use_clamp = True
    group.links.new(source_factor, mix.inputs[0])
    group.links.new(inp.outputs["Dst Color"], mix.inputs[1])
    group.links.new(inp.outputs["Src Color"], mix.inputs[2])
    group.links.new(mix.outputs["Color"], out.inputs["Color"])
    group.links.new(output_alpha, out.inputs["Alpha"])
    return group


def _ensure_live_premultiplied_normal_blend_group():
    """Return a compact encoded-premultiplied Source-Over group for Live MIX rows."""
    name = "SPS_MVP_LivePremultipliedNormalBlend_v1"
    version = "premultiplied_source_over_clip_v1"
    group = bpy.data.node_groups.get(name)
    if _exact_owned_group(group) and str(group.get("sps_mvp_formula_version", "") or "") == version:
        return group
    group = _replace_owned_group_or_create(name, group)
    group["sps_mvp_formula_version"] = version
    group["sps_mvp_contract"] = "encoded_premultiplied_source_over_with_clip_alpha"
    for socket_name, socket_type in (
        ("Dst Color", "NodeSocketColor"),
        ("Dst Alpha", "NodeSocketFloat"),
        ("Src Color", "NodeSocketColor"),
        ("Src Alpha", "NodeSocketFloat"),
        ("Opacity", "NodeSocketFloat"),
        ("Clip Alpha", "NodeSocketFloat"),
    ):
        _add_socket(group, socket_name, "INPUT", socket_type)
    _add_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    _add_socket(group, "Alpha", "OUTPUT", "NodeSocketFloat")
    inp = group.nodes.new("NodeGroupInput")
    out = group.nodes.new("NodeGroupOutput")
    source_scale = _math(
        group,
        "MULTIPLY",
        inp.outputs["Opacity"],
        inp.outputs["Clip Alpha"],
        clamp=True,
    )
    effective = _math(
        group,
        "MULTIPLY",
        inp.outputs["Src Alpha"],
        source_scale,
        clamp=True,
    )
    inverse = _math(group, "SUBTRACT", 1.0, effective, clamp=True)
    source_color = _scale_color(group, inp.outputs["Src Color"], source_scale)
    destination_color = _scale_color(group, inp.outputs["Dst Color"], inverse)
    color = group.nodes.new("ShaderNodeVectorMath")
    _mark_node(color, "formula_vector_add")
    color.operation = "ADD"
    group.links.new(source_color, color.inputs[0])
    group.links.new(destination_color, color.inputs[1])
    output_alpha = _math(
        group,
        "ADD",
        effective,
        _math(group, "MULTIPLY", inp.outputs["Dst Alpha"], inverse, clamp=True),
        clamp=True,
    )
    group.links.new(color.outputs["Vector"], out.inputs["Color"])
    group.links.new(output_alpha, out.inputs["Alpha"])
    return group


def _ensure_peel_group(mode: str = "MIX"):
    mode_key = _normalized_blend_mode(mode)
    if mode_key not in _PEEL_SUPPORTED_BLEND_MODES:
        raise ValueError(f"unsupported live peel mode: {mode_key}")
    label = {
        "MIX": "Normal",
        "MULTIPLY": "Multiply",
        "SCREEN": "Screen",
        "OVERLAY": "Overlay",
        "HARD_LIGHT": "HardLight",
    }[mode_key]
    name = f"SPS_MVP_{label}Peel_v2"
    group = bpy.data.node_groups.get(name)
    if _exact_owned_group(group) and str(group.get("sps_mvp_formula_version", "") or "") == _GRAPH_VERSION:
        return group
    group = _replace_owned_group_or_create(name, group)
    group["sps_mvp_formula_version"] = _GRAPH_VERSION
    group["sps_mvp_contract"] = "saved_merged_remove_old_layer_exact_or_fallback"
    group["sps_mvp_peel_mode"] = mode_key
    for socket_name, socket_type in (
        ("Merged Color", "NodeSocketColor"),
        ("Merged Alpha", "NodeSocketFloat"),
        ("Old Color", "NodeSocketColor"),
        ("Old Alpha", "NodeSocketFloat"),
        ("Opacity", "NodeSocketFloat"),
    ):
        _add_socket(group, socket_name, "INPUT", socket_type)
    _add_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    _add_socket(group, "Alpha", "OUTPUT", "NodeSocketFloat")
    _add_socket(group, "Recoverable", "OUTPUT", "NodeSocketFloat")
    inp = group.nodes.new("NodeGroupInput")
    out = group.nodes.new("NodeGroupOutput")
    merged = _separate(group, inp.outputs["Merged Color"])
    old = _separate(group, inp.outputs["Old Color"])
    effective = _math(group, "MULTIPLY", inp.outputs["Old Alpha"], inp.outputs["Opacity"])
    one_minus = _math(group, "SUBTRACT", 1.0, effective)
    safe_one_minus = _math(group, "MAXIMUM", one_minus, _INVERSE_EPSILON)
    alpha_raw = _math(
        group,
        "DIVIDE",
        _math(group, "SUBTRACT", inp.outputs["Merged Alpha"], effective),
        safe_one_minus,
    )
    alpha = _math(group, "MAXIMUM", _math(group, "MINIMUM", alpha_raw, 1.0), 0.0)

    if mode_key == "MIX":
        safe_alpha = _math(group, "MAXIMUM", alpha, _EPSILON)
        channels = []
        for channel in ("Red", "Green", "Blue"):
            merged_p = _math(group, "MULTIPLY", merged.outputs[channel], inp.outputs["Merged Alpha"])
            old_p = _math(group, "MULTIPLY", old.outputs[channel], effective)
            peeled_p = _math(group, "DIVIDE", _math(group, "SUBTRACT", merged_p, old_p), safe_one_minus)
            channels.append(_math(group, "DIVIDE", peeled_p, safe_alpha, clamp=True))
        recoverable = _math(group, "GREATER_THAN", one_minus, _EPSILON)
    else:
        def clamp01(value):
            return _math(group, "MAXIMUM", _math(group, "MINIMUM", value, 1.0), 0.0)

        def within(value, lower: float, upper: float):
            return _math(
                group,
                "MULTIPLY",
                _math(group, "GREATER_THAN", value, float(lower) - _INVERSE_EPSILON),
                _math(group, "LESS_THAN", value, float(upper) + _INVERSE_EPSILON),
            )

        def select(factor, when_false, when_true):
            return _math(
                group,
                "ADD",
                _math(
                    group,
                    "MULTIPLY",
                    _math(group, "SUBTRACT", 1.0, factor),
                    when_false,
                ),
                _math(group, "MULTIPLY", factor, when_true),
            )

        k = _math(group, "MULTIPLY", alpha_raw, one_minus)
        recoverable = _math(
            group,
            "MULTIPLY",
            _math(group, "GREATER_THAN", one_minus, _INVERSE_EPSILON),
            within(alpha_raw, -_ROUNDTRIP_TOLERANCE, 1.0 + _ROUNDTRIP_TOLERANCE),
        )
        channels = []
        for channel in ("Red", "Green", "Blue"):
            merged_numerator = _math(
                group,
                "MULTIPLY",
                merged.outputs[channel],
                inp.outputs["Merged Alpha"],
            )
            source = old.outputs[channel]
            if mode_key == "MULTIPLY":
                denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(group, "MULTIPLY", effective, source),
                )
                candidate_raw = _math(
                    group,
                    "DIVIDE",
                    merged_numerator,
                    _math(group, "MAXIMUM", denominator, _INVERSE_EPSILON),
                )
                candidate = clamp01(candidate_raw)
                pure = _math(group, "MULTIPLY", candidate, source)
                candidate_valid = _math(
                    group,
                    "MULTIPLY",
                    _math(
                        group,
                        "GREATER_THAN",
                        _math(group, "ABSOLUTE", denominator),
                        _INVERSE_EPSILON,
                    ),
                    within(candidate_raw, -_ROUNDTRIP_TOLERANCE, 1.0 + _ROUNDTRIP_TOLERANCE),
                )
            elif mode_key == "SCREEN":
                denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(
                        group,
                        "MULTIPLY",
                        effective,
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                candidate_raw = _math(
                    group,
                    "DIVIDE",
                    _math(
                        group,
                        "SUBTRACT",
                        merged_numerator,
                        _math(group, "MULTIPLY", effective, source),
                    ),
                    _math(group, "MAXIMUM", denominator, _INVERSE_EPSILON),
                )
                candidate = clamp01(candidate_raw)
                pure = _math(
                    group,
                    "SUBTRACT",
                    1.0,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(group, "SUBTRACT", 1.0, candidate),
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                candidate_valid = _math(
                    group,
                    "MULTIPLY",
                    _math(
                        group,
                        "GREATER_THAN",
                        _math(group, "ABSOLUTE", denominator),
                        _INVERSE_EPSILON,
                    ),
                    within(candidate_raw, -_ROUNDTRIP_TOLERANCE, 1.0 + _ROUNDTRIP_TOLERANCE),
                )
            elif mode_key == "HARD_LIGHT":
                source_low = _math(
                    group,
                    "LESS_THAN",
                    source,
                    0.5 + _INVERSE_EPSILON,
                )
                low_denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(group, "MULTIPLY", 2.0, effective),
                        source,
                    ),
                )
                low_raw = _math(
                    group,
                    "DIVIDE",
                    merged_numerator,
                    _math(group, "MAXIMUM", low_denominator, _INVERSE_EPSILON),
                )
                high_denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(group, "MULTIPLY", 2.0, effective),
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                high_raw = _math(
                    group,
                    "DIVIDE",
                    _math(
                        group,
                        "SUBTRACT",
                        merged_numerator,
                        _math(
                            group,
                            "MULTIPLY",
                            effective,
                            _math(
                                group,
                                "SUBTRACT",
                                _math(group, "MULTIPLY", 2.0, source),
                                1.0,
                            ),
                        ),
                    ),
                    _math(group, "MAXIMUM", high_denominator, _INVERSE_EPSILON),
                )
                denominator = select(source_low, high_denominator, low_denominator)
                candidate_raw = select(source_low, high_raw, low_raw)
                candidate = clamp01(candidate_raw)
                low_pure = _math(
                    group,
                    "MULTIPLY",
                    _math(group, "MULTIPLY", 2.0, candidate),
                    source,
                )
                high_pure = _math(
                    group,
                    "SUBTRACT",
                    1.0,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(
                            group,
                            "MULTIPLY",
                            2.0,
                            _math(group, "SUBTRACT", 1.0, candidate),
                        ),
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                pure = select(source_low, high_pure, low_pure)
                candidate_valid = _math(
                    group,
                    "MULTIPLY",
                    _math(group, "GREATER_THAN", denominator, _INVERSE_EPSILON),
                    within(
                        candidate_raw,
                        -_ROUNDTRIP_TOLERANCE,
                        1.0 + _ROUNDTRIP_TOLERANCE,
                    ),
                )
            elif mode_key == "OVERLAY":
                low_denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(group, "MULTIPLY", 2.0, effective),
                        source,
                    ),
                )
                low_raw = _math(
                    group,
                    "DIVIDE",
                    merged_numerator,
                    _math(group, "MAXIMUM", low_denominator, _INVERSE_EPSILON),
                )
                low = clamp01(low_raw)
                low_valid = _math(
                    group,
                    "MULTIPLY",
                    _math(group, "GREATER_THAN", low_denominator, _INVERSE_EPSILON),
                    within(
                        low_raw,
                        -_ROUNDTRIP_TOLERANCE,
                        0.5 + _ROUNDTRIP_TOLERANCE,
                    ),
                )
                high_denominator = _math(
                    group,
                    "ADD",
                    k,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(group, "MULTIPLY", 2.0, effective),
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                high_raw = _math(
                    group,
                    "DIVIDE",
                    _math(
                        group,
                        "SUBTRACT",
                        merged_numerator,
                        _math(
                            group,
                            "MULTIPLY",
                            effective,
                            _math(
                                group,
                                "SUBTRACT",
                                _math(group, "MULTIPLY", 2.0, source),
                                1.0,
                            ),
                        ),
                    ),
                    _math(group, "MAXIMUM", high_denominator, _INVERSE_EPSILON),
                )
                high = clamp01(high_raw)
                high_valid = _math(
                    group,
                    "MULTIPLY",
                    _math(group, "GREATER_THAN", high_denominator, _INVERSE_EPSILON),
                    within(
                        high_raw,
                        0.5 - _ROUNDTRIP_TOLERANCE,
                        1.0 + _ROUNDTRIP_TOLERANCE,
                    ),
                )
                low_strict = _math(
                    group,
                    "MULTIPLY",
                    low_valid,
                    _math(group, "LESS_THAN", low, 0.5 + _INVERSE_EPSILON),
                )
                high_strict = _math(
                    group,
                    "MULTIPLY",
                    high_valid,
                    _math(group, "GREATER_THAN", high, 0.5),
                )
                choose_low = _math(
                    group,
                    "MAXIMUM",
                    low_strict,
                    _math(
                        group,
                        "MULTIPLY",
                        low_valid,
                        _math(
                            group,
                            "MULTIPLY",
                            _math(group, "SUBTRACT", 1.0, low_strict),
                            _math(group, "SUBTRACT", 1.0, high_strict),
                        ),
                    ),
                )
                candidate = select(choose_low, high, low)
                candidate_valid = select(choose_low, high_valid, low_valid)
                low_pure = _math(
                    group,
                    "MULTIPLY",
                    _math(group, "MULTIPLY", 2.0, candidate),
                    source,
                )
                high_pure = _math(
                    group,
                    "SUBTRACT",
                    1.0,
                    _math(
                        group,
                        "MULTIPLY",
                        _math(
                            group,
                            "MULTIPLY",
                            2.0,
                            _math(group, "SUBTRACT", 1.0, candidate),
                        ),
                        _math(group, "SUBTRACT", 1.0, source),
                    ),
                )
                use_low = _math(
                    group,
                    "LESS_THAN",
                    candidate,
                    0.5 + _INVERSE_EPSILON,
                )
                pure = select(use_low, high_pure, low_pure)
            else:
                raise ValueError(f"unsupported live peel mode: {mode_key}")
            channels.append(candidate)
            recoverable = _math(
                group,
                "MULTIPLY",
                recoverable,
                candidate_valid,
            )
            reconstructed = _math(
                group,
                "DIVIDE",
                _math(
                    group,
                    "ADD",
                    _math(group, "MULTIPLY", pure, effective),
                    _math(group, "MULTIPLY", candidate, k),
                ),
                _math(group, "MAXIMUM", inp.outputs["Merged Alpha"], _INVERSE_EPSILON),
            )
            error = _math(
                group,
                "ABSOLUTE",
                _math(group, "SUBTRACT", reconstructed, merged.outputs[channel]),
            )
            recoverable = _math(
                group,
                "MULTIPLY",
                recoverable,
                _math(group, "LESS_THAN", error, _ROUNDTRIP_TOLERANCE + _INVERSE_EPSILON),
            )
        reconstructed_alpha = _math(
            group,
            "ADD",
            effective,
            _math(group, "MULTIPLY", alpha, one_minus),
        )
        alpha_error = _math(
            group,
            "ABSOLUTE",
            _math(group, "SUBTRACT", reconstructed_alpha, inp.outputs["Merged Alpha"]),
        )
        recoverable = _math(
            group,
            "MULTIPLY",
            recoverable,
            _math(group, "LESS_THAN", alpha_error, _ROUNDTRIP_TOLERANCE + _INVERSE_EPSILON),
        )

    group.links.new(_combine(group, channels), out.inputs["Color"])
    group.links.new(alpha, out.inputs["Alpha"])
    group.links.new(recoverable, out.inputs["Recoverable"])
    return group


def _mark_node(node, role: str) -> None:
    try:
        node[_NODE_MARKER] = True
        node["sps_mvp_live_role"] = str(role or "")
    except Exception:
        pass


def _document_image_key(path: str) -> tuple[str, str]:
    try:
        resolved = Path(bpy.path.abspath(str(path or ""))).resolve()
    except Exception:
        try:
            resolved = Path(str(path or ""))
        except Exception:
            return "", ""
    parts = resolved.stem.casefold().split("_")
    while len(parts) > 1 and (parts[-1].isdigit() or parts[-1] == "copy"):
        parts.pop()
    return str(resolved.parent).casefold(), "_".join(parts)


def _socket_index(sockets, target) -> int:
    for index, socket in enumerate(sockets or ()):
        if socket == target:
            return int(index)
    return -1


def _socket_from_descriptor(node, collection_name: str, name: str, index: int):
    sockets = getattr(node, collection_name, ())
    try:
        if 0 <= int(index) < len(sockets):
            socket = sockets[int(index)]
            if not name or str(getattr(socket, "name", "") or "") == str(name):
                return socket
    except Exception:
        pass
    try:
        # Name-only lookup is a compatibility fallback. Some group nodes have
        # duplicate labels (for example two "Value" inputs), so the captured
        # index must remain authoritative whenever it is still valid.
        socket = sockets.get(str(name or ""))
        if socket is not None:
            return socket
    except Exception:
        pass
    return None


def _restore_custom_shader_links(material, tree, *, clear: bool = True) -> int:
    try:
        payload = json.loads(str(material.get(_CUSTOM_SHADER_LINKS_PROPERTY, "") or ""))
    except Exception:
        payload = {}
    records = list(payload.get("links", ()) or ()) if isinstance(payload, dict) else []
    restored = 0
    for record in records:
        try:
            source_node = tree.nodes.get(str(record.get("source_node", "") or ""))
            target_node = tree.nodes.get(str(record.get("target_node", "") or ""))
            if source_node is None or target_node is None:
                continue
            source_socket = _socket_from_descriptor(
                source_node,
                "outputs",
                str(record.get("source_socket", "") or ""),
                int(record.get("source_socket_index", -1)),
            )
            target_socket = _socket_from_descriptor(
                target_node,
                "inputs",
                str(record.get("target_socket", "") or ""),
                int(record.get("target_socket_index", -1)),
            )
            if source_socket is None or target_socket is None:
                continue
            for link in list(target_socket.links):
                tree.links.remove(link)
            tree.links.new(source_socket, target_socket)
            restored += 1
        except Exception:
            continue
    if clear:
        try:
            if _CUSTOM_SHADER_LINKS_PROPERTY in material:
                del material[_CUSTOM_SHADER_LINKS_PROPERTY]
        except Exception:
            pass
    return int(restored)


def _capture_custom_shader_targets(material, tree) -> list[dict[str, Any]]:
    source_key = _document_image_key(_source_path(material))
    if not source_key[1]:
        return []
    records: list[dict[str, Any]] = []
    for node in list(tree.nodes):
        try:
            if str(getattr(node, "type", "") or "") != "TEX_IMAGE":
                continue
            if bool(node.get(_NODE_MARKER, False)) or bool(node.get(_AUX_NODE_MARKER, False)):
                continue
            image = getattr(node, "image", None)
            if image is None:
                continue
            image_path = str(getattr(image, "filepath", "") or "")
            if not image_path or _document_image_key(image_path) != source_key:
                continue
            for output in node.outputs:
                output_name = str(getattr(output, "name", "") or "")
                if output_name not in {"Color", "Alpha"}:
                    continue
                for link in list(output.links):
                    target_node = getattr(link, "to_node", None)
                    target_socket = getattr(link, "to_socket", None)
                    if target_node is None or target_socket is None:
                        continue
                    records.append({
                        "source_node": str(node.name),
                        "source_socket": output_name,
                        "source_socket_index": _socket_index(node.outputs, output),
                        "target_node": str(target_node.name),
                        "target_socket": str(getattr(target_socket, "name", "") or ""),
                        "target_socket_index": _socket_index(target_node.inputs, target_socket),
                        "live_source": output_name.upper(),
                    })
        except Exception:
            continue
    if records:
        try:
            material[_CUSTOM_SHADER_LINKS_PROPERTY] = json.dumps({
                "version": _CUSTOM_SHADER_LINKS_VERSION,
                "links": records,
            }, ensure_ascii=False)
        except Exception:
            pass
    return records


def _connect_custom_shader_targets(tree, targets, color_socket, alpha_socket) -> int:
    connected = 0
    for target in list(targets or ()):
        try:
            target_node = tree.nodes.get(str(target.get("target_node", "") or ""))
            if target_node is None:
                continue
            target_socket = _socket_from_descriptor(
                target_node,
                "inputs",
                str(target.get("target_socket", "") or ""),
                int(target.get("target_socket_index", -1)),
            )
            if target_socket is None:
                continue
            for link in list(target_socket.links):
                tree.links.remove(link)
            source_socket = alpha_socket if str(target.get("live_source", "")) == "ALPHA" else color_socket
            tree.links.new(source_socket, target_socket)
            connected += 1
        except Exception:
            continue
    return int(connected)


def _remove_graph_nodes(tree, material=None) -> None:
    if material is not None:
        _restore_custom_shader_links(material, tree, clear=True)
    for node in list(tree.nodes):
        try:
            if bool(node.get(_NODE_MARKER, False)) or bool(node.get(_AUX_NODE_MARKER, False)):
                tree.nodes.remove(node)
        except Exception:
            continue


def _image_node(
    tree,
    image,
    *,
    role: str,
    location,
    interpolation: str = "Linear",
    auxiliary: bool = False,
):
    node = tree.nodes.new("ShaderNodeTexImage")
    node.image = image
    node.interpolation = str(interpolation or "Linear")
    node.extension = "CLIP"
    node.location = location
    node.label = role
    if auxiliary:
        node[_AUX_NODE_MARKER] = True
        node["sps_mvp_live_role"] = str(role or "")
    else:
        _mark_node(node, role)
    return node


def _group_node(tree, group, *, role: str, location):
    node = tree.nodes.new("ShaderNodeGroup")
    node.node_tree = group
    node.location = location
    node.label = role
    _mark_node(node, role)
    return node


def _mix_color(tree, first, second, factor):
    left = _separate(tree, first)
    right = _separate(tree, second)
    inverse = _math(tree, "SUBTRACT", 1.0, factor)
    return _combine(tree, [
        _math(
            tree,
            "ADD",
            _math(tree, "MULTIPLY", left.outputs[channel], inverse),
            _math(tree, "MULTIPLY", right.outputs[channel], factor),
            clamp=True,
        )
        for channel in ("Red", "Green", "Blue")
    ])


def _select_value(tree, condition, when_true, when_false):
    return _math(
        tree,
        "ADD",
        _math(tree, "MULTIPLY", condition, when_true),
        _math(
            tree,
            "MULTIPLY",
            _math(tree, "SUBTRACT", 1.0, condition),
            when_false,
        ),
    )


def _rgb_to_hsl_nodes(tree, color):
    channels = _separate(tree, color)
    red = channels.outputs["Red"]
    green = channels.outputs["Green"]
    blue = channels.outputs["Blue"]
    maximum = _math(tree, "MAXIMUM", red, _math(tree, "MAXIMUM", green, blue))
    minimum = _math(tree, "MINIMUM", red, _math(tree, "MINIMUM", green, blue))
    delta = _math(tree, "SUBTRACT", maximum, minimum)
    valid = _math(tree, "GREATER_THAN", delta, 1.0e-9)
    lightness = _math(
        tree,
        "MULTIPLY",
        _math(tree, "ADD", maximum, minimum),
        0.5,
        clamp=True,
    )
    low_saturation = _math(
        tree,
        "DIVIDE",
        delta,
        _math(tree, "MAXIMUM", _math(tree, "ADD", maximum, minimum), 1.0e-9),
    )
    high_saturation = _math(
        tree,
        "DIVIDE",
        delta,
        _math(
            tree,
            "MAXIMUM",
            _math(
                tree,
                "SUBTRACT",
                2.0,
                _math(tree, "ADD", maximum, minimum),
            ),
            1.0e-9,
        ),
    )
    low_half = _math(tree, "LESS_THAN", lightness, 0.5000001)
    saturation = _math(
        tree,
        "MULTIPLY",
        _select_value(tree, low_half, low_saturation, high_saturation),
        valid,
        clamp=True,
    )
    safe_delta = _math(tree, "MAXIMUM", delta, 1.0e-9)
    red_hue = _math(
        tree,
        "MODULO",
        _math(tree, "DIVIDE", _math(tree, "SUBTRACT", green, blue), safe_delta),
        6.0,
    )
    green_hue = _math(
        tree,
        "ADD",
        _math(tree, "DIVIDE", _math(tree, "SUBTRACT", blue, red), safe_delta),
        2.0,
    )
    blue_hue = _math(
        tree,
        "ADD",
        _math(tree, "DIVIDE", _math(tree, "SUBTRACT", red, green), safe_delta),
        4.0,
    )
    red_is_max = _math(
        tree,
        "LESS_THAN",
        _math(tree, "ABSOLUTE", _math(tree, "SUBTRACT", red, maximum)),
        1.0e-7,
    )
    green_is_max = _math(
        tree,
        "MULTIPLY",
        _math(tree, "SUBTRACT", 1.0, red_is_max),
        _math(
            tree,
            "LESS_THAN",
            _math(tree, "ABSOLUTE", _math(tree, "SUBTRACT", green, maximum)),
            1.0e-7,
        ),
    )
    hue_six = _math(
        tree,
        "ADD",
        _math(tree, "MULTIPLY", red_is_max, red_hue),
        _math(
            tree,
            "ADD",
            _math(tree, "MULTIPLY", green_is_max, green_hue),
            _math(
                tree,
                "MULTIPLY",
                _math(
                    tree,
                    "SUBTRACT",
                    1.0,
                    _math(tree, "ADD", red_is_max, green_is_max),
                ),
                blue_hue,
            ),
        ),
    )
    hue = _math(
        tree,
        "MULTIPLY",
        _math(tree, "MODULO", _math(tree, "DIVIDE", hue_six, 6.0), 1.0),
        valid,
    )
    return hue, saturation, lightness


def _hsl_to_rgb_nodes(tree, hue, saturation, lightness):
    hue_six = _math(
        tree,
        "MULTIPLY",
        _math(tree, "MODULO", hue, 1.0),
        6.0,
    )
    chroma = _math(
        tree,
        "MULTIPLY",
        _math(
            tree,
            "SUBTRACT",
            1.0,
            _math(
                tree,
                "ABSOLUTE",
                _math(tree, "SUBTRACT", _math(tree, "MULTIPLY", 2.0, lightness), 1.0),
            ),
        ),
        saturation,
    )
    secondary = _math(
        tree,
        "MULTIPLY",
        chroma,
        _math(
            tree,
            "SUBTRACT",
            1.0,
            _math(
                tree,
                "ABSOLUTE",
                _math(
                    tree,
                    "SUBTRACT",
                    _math(tree, "MODULO", hue_six, 2.0),
                    1.0,
                ),
            ),
        ),
    )
    sector = _math(tree, "FLOOR", hue_six)

    def sector_value(values):
        result = values[5]
        for index in range(4, -1, -1):
            result = _select_value(
                tree,
                _math(tree, "LESS_THAN", sector, float(index + 1)),
                values[index],
                result,
            )
        return result

    red = sector_value((chroma, secondary, 0.0, 0.0, secondary, chroma))
    green = sector_value((secondary, chroma, chroma, secondary, 0.0, 0.0))
    blue = sector_value((0.0, 0.0, secondary, chroma, chroma, secondary))
    offset = _math(
        tree,
        "SUBTRACT",
        lightness,
        _math(tree, "MULTIPLY", chroma, 0.5),
    )
    return _combine(
        tree,
        (
            _math(tree, "ADD", red, offset, clamp=True),
            _math(tree, "ADD", green, offset, clamp=True),
            _math(tree, "ADD", blue, offset, clamp=True),
        ),
    )


def _rgb_curve_node(tree, color, luts, *, role: str):
    node = tree.nodes.new("ShaderNodeRGBCurve")
    _mark_node(node, role)
    node.label = role
    node.mapping.initialize()
    node.mapping.use_clip = True
    node.mapping.clip_min_x = 0.0
    node.mapping.clip_min_y = 0.0
    node.mapping.clip_max_x = 1.0
    node.mapping.clip_max_y = 1.0
    # CurveMapping channel order is C, R, G, B. Keep C identity and author
    # one exact byte-domain curve for each encoded-sRGB channel.
    for channel_index, values in enumerate(luts, start=1):
        curve = node.mapping.curves[channel_index]
        sequence = [float(value) for value in values]
        curve.points[0].location = (0.0, sequence[0])
        curve.points[-1].location = (1.0, sequence[-1])
        for index in range(1, len(sequence) - 1):
            point = curve.points.new(index / float(len(sequence) - 1), sequence[index])
            point.handle_type = "VECTOR"
        curve.points[0].handle_type = "VECTOR"
        curve.points[-1].handle_type = "VECTOR"
    node.mapping.update()
    node.inputs["Fac"].default_value = 1.0
    tree.links.new(color, node.inputs["Color"])
    return node.outputs["Color"]


def _ensure_adjustment_group(adjustment_state: dict[str, Any]):
    from . import adjustments
    import numpy as np

    state = dict(adjustment_state or {})
    state["_native_units"] = True
    signature = hashlib.sha1(
        json.dumps(state, sort_keys=True, ensure_ascii=True).encode("utf-8")
    ).hexdigest()[:16]
    formula_version = adjustments.ADJUSTMENT_MATH_VERSION
    name = f"SPS_MVP_Adjustment_{signature}"
    group = bpy.data.node_groups.get(name)
    if (
        _exact_owned_group(group)
        and str(group.get("sps_mvp_formula_version", "") or "")
        == formula_version
    ):
        return group
    group = _replace_owned_group_or_create(name, group)
    group["sps_mvp_formula_version"] = formula_version
    group["sps_mvp_adjustment_state"] = json.dumps(
        state, sort_keys=True, ensure_ascii=True
    )
    _add_socket(group, "Color", "INPUT", "NodeSocketColor")
    _add_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    inp = group.nodes.new("NodeGroupInput")
    out = group.nodes.new("NodeGroupOutput")
    inp.location = (-900.0, 0.0)
    out.location = (900.0, 0.0)
    color = inp.outputs["Color"]
    adjustment_type = str(state.get("adjustment_type", "NONE") or "NONE").upper()

    if adjustment_type == "INVERT":
        invert = group.nodes.new("ShaderNodeInvert")
        _mark_node(invert, "adjustment_invert")
        invert.inputs["Fac"].default_value = 1.0
        group.links.new(color, invert.inputs["Color"])
        adjusted = invert.outputs["Color"]
    elif adjustment_type == "LEVELS":
        lut = adjustments._levels_transfer_lut(state)
        adjusted = _rgb_curve_node(
            group,
            color,
            (lut, lut, lut),
            role="adjustment_levels",
        )
    elif adjustment_type == "BRIGHTNESS_CONTRAST":
        lut = adjustments._brightness_contrast_lut(
            int(state.get("adj_brightness", 0)),
            int(state.get("adj_contrast", 0)),
        )
        adjusted = _rgb_curve_node(
            group,
            color,
            (lut, lut, lut),
            role="adjustment_brightness_contrast",
        )
    elif adjustment_type == "POSTERIZE":
        levels = max(2, min(256, int(state.get("adj_posterize_levels", 4))))
        channels = _separate(group, color)
        adjusted = _combine(
            group,
            tuple(
                _math(
                    group,
                    "DIVIDE",
                    _math(
                        group,
                        "FLOOR",
                        _math(
                            group,
                            "MULTIPLY",
                            channels.outputs[channel_name],
                            (255.0 / 256.0) * float(levels),
                        ),
                    ),
                    float(levels - 1),
                    clamp=True,
                )
                for channel_name in ("Red", "Green", "Blue")
            ),
        )
    elif adjustment_type == "THRESHOLD":
        threshold = float(state.get("adj_threshold", 128))
        channels = _separate(group, color)
        luminance = _math(
            group,
            "ADD",
            _math(group, "MULTIPLY", channels.outputs["Red"], 0.30),
            _math(
                group,
                "ADD",
                _math(group, "MULTIPLY", channels.outputs["Green"], 0.59),
                _math(group, "MULTIPLY", channels.outputs["Blue"], 0.11),
            ),
        )
        luminance = _math(
            group,
            "ROUND",
            _math(group, "MULTIPLY", luminance, 255.0),
        )
        boundary = (threshold - 1.0 / 255.0) * (255.0 / 256.0)
        white = _math(group, "GREATER_THAN", luminance, boundary)
        adjusted = _combine(group, (white, white, white))
    elif adjustment_type == "HUE_SATURATION":
        hue_shift = float(state.get("adj_hue", 0)) / 360.0
        saturation_shift = float(state.get("adj_saturation", 0)) / 100.0
        lightness_shift = float(state.get("adj_lightness", 0)) / 100.0
        if lightness_shift > 0.0:
            working = _mix_color(
                group,
                color,
                _combine(group, (1.0, 1.0, 1.0)),
                lightness_shift,
            )
        elif lightness_shift < 0.0:
            working = _scale_color(group, color, 1.0 + lightness_shift)
        else:
            working = color
        hue, saturation, lightness = _rgb_to_hsl_nodes(group, working)
        hue = _math(group, "MODULO", _math(group, "ADD", hue, hue_shift), 1.0)
        if saturation_shift > 0.0:
            saturation = _math(
                group,
                "DIVIDE",
                saturation,
                1.0 - saturation_shift + 0.01,
                clamp=True,
            )
        elif saturation_shift < 0.0:
            saturation = _math(
                group,
                "MULTIPLY",
                saturation,
                1.0 + saturation_shift,
                clamp=True,
            )
        adjusted = _hsl_to_rgb_nodes(group, hue, saturation, lightness)
    elif adjustment_type == "COLOR_BALANCE":
        luts = adjustments._color_balance_transfer_luts(state)
        adjusted = _rgb_curve_node(
            group,
            color,
            luts,
            role="adjustment_color_balance",
        )
    elif adjustment_type == "GRADIENT_MAP":
        channels = _separate(group, color)
        position = _math(
            group,
            "POWER",
            _math(
                group,
                "MULTIPLY",
                _math(
                    group,
                    "ADD",
                    channels.outputs["Red"],
                    _math(
                        group,
                        "ADD",
                        channels.outputs["Green"],
                        channels.outputs["Blue"],
                    ),
                ),
                1.0 / 3.0,
                clamp=True,
            ),
            0.625,
            clamp=True,
        )
        dark = tuple(
            float(value) / 65535.0
            for value in list(state.get("adj_gradient_dark", (0, 0, 0)))[:3]
        )
        light = tuple(
            float(value) / 65535.0
            for value in list(
                state.get("adj_gradient_light", (65535, 65535, 65535))
            )[:3]
        )
        adjusted = _combine(
            group,
            tuple(
                _math(
                    group,
                    "ADD",
                    _math(group, "MULTIPLY", dark[index], _math(group, "SUBTRACT", 1.0, position)),
                    _math(group, "MULTIPLY", light[index], position),
                    clamp=True,
                )
                for index in range(3)
            ),
        )
    else:
        adjusted = color

    group.links.new(adjusted, out.inputs["Color"])
    return group


def _mask_factor_from_texture(tree, texture, mask_spec: dict[str, Any]):
    channels = _separate(tree, texture.outputs["Color"])
    channel = str(mask_spec.get("channel", "LUMA") or "LUMA").upper()
    if channel == "R":
        factor = channels.outputs["Red"]
    elif channel == "G":
        factor = channels.outputs["Green"]
    elif channel == "B":
        factor = channels.outputs["Blue"]
    elif channel in {"A", "ALPHA"}:
        factor = texture.outputs["Alpha"]
    else:
        factor = _math(
            tree,
            "ADD",
            _math(tree, "MULTIPLY", channels.outputs["Red"], 0.2126),
            _math(
                tree,
                "ADD",
                _math(tree, "MULTIPLY", channels.outputs["Green"], 0.7152),
                _math(tree, "MULTIPLY", channels.outputs["Blue"], 0.0722),
            ),
            clamp=True,
        )
    threshold = float(mask_spec.get("threshold", 0.5))
    if abs(threshold - 0.5) > 1.0e-6:
        factor = _math(tree, "ADD", factor, (0.5 - threshold) * 2.0, clamp=True)
    factor = _math(
        tree,
        "MULTIPLY",
        factor,
        max(0.0, min(2.0, float(mask_spec.get("strength", 1.0) or 0.0))),
        clamp=True,
    )
    if bool(mask_spec.get("invert", False)):
        factor = _math(tree, "SUBTRACT", 1.0, factor, clamp=True)
    return factor


def _scale_color(tree, color, scale, *, role: str = "formula_vector_scale"):
    node = tree.nodes.new("ShaderNodeVectorMath")
    _mark_node(node, role)
    node.operation = "SCALE"
    tree.links.new(color, node.inputs[0])
    _link_or_set(tree, scale, node.inputs["Scale"])
    return node.outputs["Vector"]


def _unpremultiply_color(tree, color, alpha):
    """Return straight RGB from Blender's alpha-associated texture output."""
    covered = _math(tree, "GREATER_THAN", alpha, _INVERSE_EPSILON)
    safe_alpha = _math(tree, "MAXIMUM", alpha, _INVERSE_EPSILON)
    scale = _math(tree, "DIVIDE", covered, safe_alpha)
    return _scale_color(tree, color, scale)


def _image_has_authored_pixel_changes(image) -> bool:
    if image is None:
        return False
    for key in (
        "smart_paint_suite_direct_layer_dirty",
        "smart_paint_suite_painted_since_last_projection",
        "smart_paint_suite_dirty_from_master",
        "smart_paint_suite_authoritative_sparse_rgba_patch",
        "smart_paint_suite_exact_top_sparse_commit",
        "sps_bridge_external_import_authoritative",
    ):
        try:
            if bool(image.get(key, False)):
                return True
        except Exception:
            pass
    for key in (
        "smart_paint_suite_pixel_revision",
        "smart_paint_suite_layer_authoritative_revision",
    ):
        try:
            if int(image.get(key, 0) or 0) > 0:
                return True
        except Exception:
            pass
    return False


def _current_display_signature(image, cache, identity) -> str:
    values = [
        str(cache.get("signature", "") or ""),
        str(identity or ""),
        str(getattr(image, "name", "") or ""),
    ]
    try:
        values.append(str(int(image.as_pointer())))
    except Exception:
        values.append("0")
    try:
        values.extend((str(int(image.size[0])), str(int(image.size[1]))))
    except Exception:
        values.extend(("0", "0"))
    for key in (
        "smart_paint_suite_pixel_revision",
        "smart_paint_suite_layer_authoritative_revision",
        "smart_paint_suite_last_direct_commit_reason",
        "smart_paint_suite_dirty_bbox",
        "smart_paint_suite_sparse_rgba_patch_bbox",
    ):
        try:
            values.append(repr(image.get(key, None)))
        except Exception:
            values.append("")
    return "|".join(values)


def _current_premultiplied_display_image(material, spec, cache):
    """Return a filtered-display proxy while leaving the paint canvas straight."""
    baseline = bpy.data.images.get(str(spec.get("display_image", "") or ""))
    current = spec.get("current_image_ref")
    if baseline is None:
        return None
    read_canvas = bool(spec.get("read_canvas_pixels", False))
    if current is None or not (read_canvas or _image_has_authored_pixel_changes(current)):
        return baseline
    stack_key = str(spec.get("stack_key", "") or "")
    current_signature = _current_display_signature(current, cache, stack_key)
    canvas_flat = None
    if read_canvas:
        # The selected row is not this canvas's layer, so no live paint stream
        # shows it. Its unprojected edits exist only in the canvas pixels.
        try:
            import zlib

            import numpy as np

            canvas_flat = np.empty(int(spec["width"]) * int(spec["height"]) * 4, dtype=np.float32)
            current.pixels.foreach_get(canvas_flat)
            current_signature += f"|{zlib.crc32(memoryview(canvas_flat)):08x}"
        except Exception:
            return baseline
    if str(spec.get("display_current_signature", "") or "") == current_signature:
        return baseline
    try:
        import numpy as np
        from .. import psd_io

        width = int(spec["width"])
        height = int(spec["height"])
        rgba = canvas_flat
        getter = getattr(psd_io, "_image_array_np", None)
        if rgba is None and callable(getter):
            rgba = getter(current, use_cache=True)
        if rgba is None:
            flat = np.empty(width * height * 4, dtype=np.float32)
            current.pixels.foreach_get(flat)
            rgba = flat
        rgba = np.asarray(rgba, dtype=np.float32)
        if rgba.size != width * height * 4:
            return baseline
        pixels_u8 = np.ascontiguousarray(
            np.clip(np.floor(rgba.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        record_index = int(spec["record_index"])
        node_token = str(spec.get("node_token", record_index) or record_index)
        token = hashlib.sha1(
            (_material_name(material) + "|" + str(cache.get("path", "") or "")).encode(
                "utf-8", errors="replace"
            )
        ).hexdigest()[:12]
        image = _cache_premultiplied_image(
            f"SPS_MVP_LiveCurrentPremul_{token}_{node_token}",
            pixels_u8,
            signature=current_signature,
            role="current_premultiplied",
            record_index=record_index,
        )
        if image is not None:
            names = cache.setdefault("image_names", [])
            if str(image.name) not in names:
                names.append(str(image.name))
            for cached_spec in list(cache.get("layers", []) or []):
                if str(cached_spec.get("stack_key", "") or "") != stack_key:
                    continue
                cached_spec["display_image"] = str(image.name)
                cached_spec["display_current_signature"] = current_signature
                break
            return image
    except Exception:
        pass
    return baseline


def _find_current_image(material, spec, context=None):
    layer = spec["layer"]
    layer_id = str(spec["layer_id"] or "")
    record_index = int(spec["record_index"])
    image = state.matching_canvas(material, layer_id, record_index)
    active = _active_canvas(context)
    if image is None and active is not None:
        try:
            if (
                str(active.get("smart_paint_suite_material", "") or "") == _material_name(material)
                and (
                    str(active.get("smart_paint_suite_layer_id", "") or "") == layer_id
                    or (
                        record_index >= 0
                        and not str(active.get("smart_paint_suite_layer_id", "") or "")
                        and int(active.get("sps_psd_source_order", -1)) == record_index
                    )
                )
            ):
                image = active
        except Exception:
            pass
    if image is None:
        image = bpy.data.images.get(str(spec.get("old_image", "") or ""))
    try:
        width, height = int(image.size[0]), int(image.size[1])
    except Exception:
        return None
    if (width, height) != (int(spec["width"]), int(spec["height"])):
        return None
    return image


def _principled_nodes(material):
    try:
        if not bool(getattr(material, "use_nodes", False)):
            material.use_nodes = True
        tree = material.node_tree
        nodes = [node for node in tree.nodes if str(getattr(node, "type", "") or "") == "BSDF_PRINCIPLED"]
        return tree, nodes
    except Exception:
        return None, []


def build(
    material,
    context=None,
    *,
    force_cache: bool = False,
    refresh_metadata: bool = False,
) -> dict[str, Any]:
    """Enable or refresh the display-only live composite graph."""
    started = time.perf_counter()
    canvas_before = _active_canvas(context)
    canvas_pointer = int(canvas_before.as_pointer()) if canvas_before is not None else 0
    cache, cache_result = _prepare_cache(
        material,
        force=bool(force_cache),
        refresh_metadata=bool(refresh_metadata),
    )
    cache_ready_at = time.perf_counter()
    from . import adjustments

    if cache is None:
        result = dict(cache_result or {})
        _trace("mvp_live_composite_build", material=material, **result)
        return result
    cache.pop("image_editor_overlay_contract", None)
    chain, reason = _live_paint_chain(material)
    if not chain:
        result = {"ok": False, "reason": reason}
        _trace("mvp_live_composite_build", material=material, **result)
        return result
    structure, structure_reason = _live_composition_structure(material, chain)
    if structure is None:
        result = {"ok": False, "reason": structure_reason}
        _trace("mvp_live_composite_build", material=material, **result)
        return result
    active_record = _active_record_index(material, context)
    active_layer_id = _active_layer_id(material, context)
    active_canvas = _active_canvas(context)
    chain_records = [int(item["record_index"]) for item in chain]
    chain_layer_ids = [str(item["layer_id"] or "") for item in chain]
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    try:
        selected_index = int(getattr(settings, "active_layer_index", -1))
    except Exception:
        selected_index = -1
    selected_layer = (
        layers[selected_index] if 0 <= selected_index < len(layers) else None
    )
    if selected_layer is not None:
        active_item = None
        if _layer_is_paintable(selected_layer):
            active_item = next(
                (
                    item
                    for item in chain
                    if int(item["layer_index"]) == selected_index
                ),
                None,
            )
    else:
        active_item = next(
            (
                item
                for item in chain
                if active_layer_id
                and str(item["layer_id"] or "") == active_layer_id
            ),
            None,
        )
        if active_item is None and int(active_record) >= 0:
            active_item = next(
                (item for item in chain if int(item["record_index"]) == int(active_record)),
                None,
            )
    # Live composition is a display mode, so it must remain available while a
    # group, unsupported PSD row, or no paintable row is selected. In that
    # state the graph uses cached layer images and has no live paint stream.
    # Selecting a paintable layer later rebuilds the graph with its private
    # canvas as the write target.

    direct_full_stack = bool(cache.get("direct_full_stack", False))
    direct_display_stack = bool(cache.get("direct_display_stack", direct_full_stack))
    active_stack_key = str(active_item["stack_key"] or "") if active_item is not None else ""
    cache_by_key = {
        str(item.get("stack_key", "") or ""): item
        for item in cache.get("layers", [])
    }
    cache_group_by_key = {
        str(item.get("stack_key", "") or ""): item
        for item in cache.get("groups", [])
    }
    cache_adjustment_by_key = {
        str(item.get("stack_key", "") or ""): item
        for item in cache.get("adjustments", [])
    }
    runtime_started_at = time.perf_counter()
    runtime = []
    for item in chain:
        cached = cache_by_key.get(str(item["stack_key"] or ""))
        if cached is None:
            result = {"ok": False, "reason": "live_cache_chain_mismatch"}
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        spec = dict(item)
        spec.update(cached)
        spec["width"] = int(cache["width"])
        spec["height"] = int(cache["height"])
        image = _find_current_image(material, spec, context)
        if image is None and not direct_display_stack:
            result = {"ok": False, "reason": "current_layer_image_missing", "record_index": int(item["record_index"])}
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        spec["current_image_ref"] = image
        if direct_display_stack:
            is_active_canvas = False
            if image is not None and active_canvas is not None:
                try:
                    is_active_canvas = int(image.as_pointer()) == int(active_canvas.as_pointer())
                except Exception:
                    is_active_canvas = image is active_canvas
            use_live_canvas = bool(is_active_canvas and str(item["stack_key"] or "") == active_stack_key)
            spec["use_live_canvas"] = bool(use_live_canvas)
            spec["read_canvas_pixels"] = bool(is_active_canvas and not use_live_canvas)
            display_image = _current_premultiplied_display_image(material, spec, cache)
            if display_image is None:
                result = {
                    "ok": False,
                    "reason": "current_display_image_missing",
                    "record_index": int(item["record_index"]),
                }
                _trace("mvp_live_composite_build", material=material, **result)
                return result
            spec["display_image_ref"] = display_image
        spec["current_enabled"] = bool(getattr(item["layer"], "enabled", True))
        spec["current_opacity"] = max(
            0.0,
            min(1.0, float(getattr(item["layer"], "opacity", 1.0) or 0.0)),
        )
        spec["current_blend_mode"] = _normalized_blend_mode(
            getattr(item["layer"], "blend_mode", spec.get("old_blend_mode", "MIX"))
        )
        if (
            str(spec.get("old_blend_mode", "MIX")) not in (
                _direct_supported_blend_modes() if direct_display_stack else _PEEL_SUPPORTED_BLEND_MODES
            )
            or str(spec["current_blend_mode"]) not in (
                _direct_supported_blend_modes() if direct_display_stack else _PEEL_SUPPORTED_BLEND_MODES
            )
        ):
            result = {
                "ok": False,
                "reason": "runtime_blend_mode_unsupported",
                "record_index": int(item["record_index"]),
                "old_blend_mode": str(spec.get("old_blend_mode", "")),
                "current_blend_mode": str(spec.get("current_blend_mode", "")),
            }
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        runtime.append(spec)
    group_runtime = {}
    for group in list(structure.get("groups", []) or []):
        stack_key = str(group.get("stack_key", "") or "")
        cached_group = cache_group_by_key.get(stack_key)
        if cached_group is None:
            result = {"ok": False, "reason": "live_cache_group_mismatch", "stack_key": stack_key}
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        group_layer = group.get("layer")
        mode = _normalized_blend_mode(getattr(group_layer, "blend_mode", group.get("blend_mode", "PASS_THROUGH")))
        pass_through = mode == "PASS_THROUGH"
        if not pass_through and mode not in _direct_supported_blend_modes():
            result = {
                "ok": False,
                "reason": "runtime_group_blend_mode_unsupported",
                "stack_key": stack_key,
                "blend_mode": mode,
            }
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        group_spec = dict(group)
        group_spec.update(cached_group)
        group_spec["current_blend_mode"] = mode
        group_spec["pass_through"] = bool(pass_through)
        group_spec["current_enabled"] = bool(getattr(group_layer, "enabled", True))
        group_spec["current_opacity"] = max(
            0.0,
            min(1.0, float(getattr(group_layer, "opacity", 1.0) or 0.0)),
        )
        group_runtime[stack_key] = group_spec
    adjustment_runtime = {}
    for adjustment in list(structure.get("adjustments", []) or []):
        stack_key = str(adjustment.get("stack_key", "") or "")
        cached_adjustment = cache_adjustment_by_key.get(stack_key)
        if cached_adjustment is None:
            result = {
                "ok": False,
                "reason": "live_cache_adjustment_mismatch",
                "stack_key": stack_key,
            }
            _trace("mvp_live_composite_build", material=material, **result)
            return result
        adjustment_layer = adjustment.get("layer")
        adjustment_spec = dict(adjustment)
        adjustment_spec.update(cached_adjustment)
        adjustment_spec["current_enabled"] = bool(
            getattr(adjustment_layer, "enabled", True)
        )
        adjustment_spec["current_opacity"] = max(
            0.0,
            min(
                1.0,
                float(getattr(adjustment_layer, "opacity", 1.0) or 0.0),
            ),
        )
        adjustment_spec["adjustment_state"] = adjustments.layer_state(
            adjustment_layer
        )
        adjustment_runtime[stack_key] = adjustment_spec
    runtime_ready_at = time.perf_counter()

    actual_texture_count = (
        len(runtime)
        + int(cache.get("mask_count", 0) or 0)
        + 3 * sum(1 for spec in runtime if bool(spec.get("use_live_canvas", False)))
        if direct_display_stack
        else 1 + len(runtime) * 4 + int(cache.get("mask_count", 0) or 0)
    )
    sampler_limit = int(cache.get("sampler_limit", _fragment_sampler_limit()) or 0)
    if actual_texture_count > sampler_limit:
        result = {
            "ok": False,
            "reason": "fragment_sampler_budget_exceeded",
            "texture_count": int(cache.get("texture_count", 1 + len(runtime) * 2) or 0),
            "actual_texture_count": int(actual_texture_count),
            "sampler_limit": int(sampler_limit),
        }
        _trace("mvp_live_composite_build", material=material, **result)
        return result

    tree, principled = _principled_nodes(material)
    if tree is None:
        result = {"ok": False, "reason": "shader_tree_missing"}
        _trace("mvp_live_composite_build", material=material, **result)
        return result
    _remove_graph_nodes(tree, material=material)
    custom_shader_targets = []
    if not principled:
        custom_shader_targets = _capture_custom_shader_targets(material, tree)
        if not custom_shader_targets:
            result = {"ok": False, "reason": "shader_document_input_missing"}
            _trace("mvp_live_composite_build", material=material, **result)
            return result
    graph_started_at = time.perf_counter()
    try:
        from .. import psd_io, sps_blend_nodes

        encode_group = _ensure_color_conversion_group("ENCODE")
        decode_group = _ensure_color_conversion_group("DECODE")
        direct_full_stack = bool(cache.get("direct_full_stack", False))
        direct_display_stack = bool(cache.get("direct_display_stack", direct_full_stack))
        peel_modes = sorted({str(spec["old_blend_mode"]) for spec in runtime})
        current_modes = sorted(
            {str(spec["current_blend_mode"]) for spec in runtime}
            | {
                str(spec["current_blend_mode"])
                for spec in group_runtime.values()
                if not bool(spec.get("pass_through", False))
            }
        )
        direct_premultiplied_stack = bool(
            direct_display_stack
            and current_modes == ["MIX"]
            and not adjustment_runtime
        )
        peel_groups = (
            {}
            if direct_display_stack
            else {mode: _ensure_peel_group(mode) for mode in peel_modes}
        )
        blend_groups = {
            mode: (
                _ensure_live_premultiplied_normal_blend_group()
                if mode == "MIX" and direct_premultiplied_stack
                else _ensure_live_normal_blend_group()
                if mode == "MIX"
                else sps_blend_nodes.create_blend_node_group(mode, force=False)
            )
            for mode in current_modes
        }
        saved_color = None
        saved_alpha = None
        if direct_display_stack:
            # Every Blender-paintable row is represented by a display-only
            # premultiplied texture. Rows explicitly imported as unsupported are
            # transparent, so they cannot truncate the editable live stack.
            dst_color = _combine(tree, (0.0, 0.0, 0.0))
            dst_alpha = _math(tree, "MULTIPLY", 1.0, 0.0)
        else:
            base_image = bpy.data.images.get(str(cache.get("base_image", "") or ""))
            if base_image is None:
                raise RuntimeError("base image missing")
            base_tex = _image_node(tree, base_image, role="Saved PSD Composite", location=(-1500.0, 500.0))
            base_encode = _group_node(tree, encode_group, role="Saved Composite to sRGB", location=(-1260.0, 500.0))
            tree.links.new(base_tex.outputs["Color"], base_encode.inputs["Color"])
            saved_color = base_encode.outputs["Color"]
            saved_alpha = base_tex.outputs["Alpha"]
            dst_color = saved_color
            dst_alpha = saved_alpha
        safe = 1.0
        changed = 0.0
        current_nodes: dict[str, Any] = {}
        clip_base_effective_nodes: dict[str, Any] = {}
        mask_factor_nodes: dict[tuple[Any, ...], Any] = {}

        def mask_factor_for_specs(mask_specs, node_token: str, y: float, record_index: int):
            factor = 1.0
            for mask_position, mask_spec in enumerate(list(mask_specs or [])):
                mask_name = str(mask_spec.get("image", "") or "")
                mask_key = (
                    mask_name,
                    str(mask_spec.get("channel", "LUMA") or "LUMA").upper(),
                    round(float(mask_spec.get("threshold", 0.5) or 0.5), 6),
                    round(float(mask_spec.get("strength", 1.0) or 0.0), 6),
                    bool(mask_spec.get("invert", False)),
                )
                one_mask_factor = mask_factor_nodes.get(mask_key)
                if one_mask_factor is None:
                    mask_image = resolve_display_image(material, mask_name)
                    if mask_image is None:
                        raise RuntimeError(f"mask image missing for record {record_index}")
                    mask_tex = _image_node(
                        tree,
                        mask_image,
                        role=f"Mask {node_token}:{mask_position}",
                        location=(-1500.0 - mask_position * 180.0, y - 500.0),
                    )
                    one_mask_factor = _mask_factor_from_texture(tree, mask_tex, mask_spec)
                    mask_factor_nodes[mask_key] = one_mask_factor
                factor = _math(tree, "MULTIPLY", factor, one_mask_factor, clamp=True)
            return factor

        for position, spec in enumerate(runtime):
            y = 300.0 - position * 360.0
            node_token = str(spec.get("node_token", spec["record_index"]) or spec["record_index"])
            old_tex = None
            old_encode = None
            old_alpha = None
            current_alpha_override = None
            if direct_display_stack:
                if bool(spec.get("use_live_canvas", False)):
                    baseline_tex = _image_node(
                        tree,
                        spec["display_image_ref"],
                        role=f"Live Active Baseline {node_token}",
                        location=(-1900.0, y - 520.0),
                    )
                    baseline_point_tex = _image_node(
                        tree,
                        spec["display_image_ref"],
                        role=f"Live Active Baseline Point {node_token}",
                        location=(-2100.0, y - 520.0),
                        interpolation="Closest",
                        auxiliary=True,
                    )
                    # Image Texture nodes referencing the paint canvas receive
                    # native brush updates immediately. Keep alpha linear while
                    # taking straight RGB from a nearest sample so transparent
                    # hidden RGB cannot bleed into the live edge.
                    current_tex = _image_node(
                        tree,
                        spec["current_image_ref"],
                        role=f"Live Active Alpha {node_token}",
                        location=(-1500.0, y - 340.0),
                    )
                    current_color_tex = _image_node(
                        tree,
                        spec["current_image_ref"],
                        role=f"Live Active Color {node_token}",
                        location=(-1700.0, y - 340.0),
                        interpolation="Closest",
                        auxiliary=True,
                    )
                    current_encode = _group_node(
                        tree,
                        encode_group,
                        role=f"Live Active {node_token} to sRGB",
                        location=(-1260.0, y - 340.0),
                    )
                    # STRAIGHT-alpha image-node color is already straight scene-linear.
                    tree.links.new(
                        current_color_tex.outputs["Color"],
                        current_encode.inputs["Color"],
                    )
                    current_encoded = current_encode.outputs["Color"]
                    current_point_premultiplied = _scale_color(
                        tree,
                        current_encoded,
                        current_color_tex.outputs["Alpha"],
                        role="formula_live_point_premultiply",
                    )
                    current_premultiplied = _scale_color(
                        tree,
                        current_encoded,
                        current_tex.outputs["Alpha"],
                        role="formula_live_premultiply",
                    )
                    baseline_channels = _separate(
                        tree,
                        baseline_point_tex.outputs["Color"],
                    )
                    current_channels = _separate(
                        tree,
                        current_point_premultiplied,
                    )
                    sample_delta = _math(
                        tree,
                        "ABSOLUTE",
                        _math(
                            tree,
                            "SUBTRACT",
                            current_channels.outputs["Red"],
                            baseline_channels.outputs["Red"],
                        ),
                    )
                    for channel in ("Green", "Blue"):
                        sample_delta = _math(
                            tree,
                            "MAXIMUM",
                            sample_delta,
                            _math(
                                tree,
                                "ABSOLUTE",
                                _math(
                                    tree,
                                    "SUBTRACT",
                                    current_channels.outputs[channel],
                                    baseline_channels.outputs[channel],
                                ),
                            ),
                        )
                    alpha_delta = _math(
                        tree,
                        "ABSOLUTE",
                        _math(
                            tree,
                            "SUBTRACT",
                            current_color_tex.outputs["Alpha"],
                            baseline_point_tex.outputs["Alpha"],
                        ),
                    )
                    sample_delta = _math(tree, "MAXIMUM", sample_delta, alpha_delta)
                    pixel_changed = _math(tree, "GREATER_THAN", sample_delta, _ROUNDTRIP_TOLERANCE)
                    current_premultiplied = _mix_color(
                        tree,
                        baseline_tex.outputs["Color"],
                        current_premultiplied,
                        pixel_changed,
                    )
                    inverse_changed = _math(tree, "SUBTRACT", 1.0, pixel_changed)
                    current_alpha_override = _math(
                        tree,
                        "ADD",
                        _math(tree, "MULTIPLY", baseline_tex.outputs["Alpha"], inverse_changed),
                        _math(tree, "MULTIPLY", current_tex.outputs["Alpha"], pixel_changed),
                        clamp=True,
                    )
                    current_color = (
                        current_premultiplied
                        if direct_premultiplied_stack
                        else _unpremultiply_color(
                            tree,
                            current_premultiplied,
                            current_alpha_override,
                        )
                    )
                else:
                    current_tex = _image_node(
                        tree,
                        spec["display_image_ref"],
                        role=f"Live Premultiplied {node_token}",
                        location=(-1500.0, y - 340.0),
                    )
                    current_color = (
                        current_tex.outputs["Color"]
                        if direct_premultiplied_stack
                        else _unpremultiply_color(
                            tree,
                            current_tex.outputs["Color"],
                            current_tex.outputs["Alpha"],
                        )
                    )
            else:
                old_image = bpy.data.images.get(str(spec.get("old_image", "") or ""))
                old_tex = _image_node(
                    tree,
                    old_image,
                    role=f"Source {node_token}",
                    location=(-1500.0, y - 180.0),
                )
                old_color_tex = _image_node(
                    tree,
                    old_image,
                    role=f"Source Color {node_token}",
                    location=(-1700.0, y - 180.0),
                    interpolation="Closest",
                    auxiliary=True,
                )
                old_encode = _group_node(
                    tree,
                    encode_group,
                    role=f"Source {node_token} to sRGB",
                    location=(-1260.0, y - 180.0),
                )
                old_straight = _unpremultiply_color(
                    tree, old_color_tex.outputs["Color"], old_color_tex.outputs["Alpha"]
                )
                tree.links.new(old_straight, old_encode.inputs["Color"])
                current_tex = _image_node(
                    tree,
                    spec["current_image_ref"],
                    role=f"Live {node_token}",
                    location=(-1500.0, y - 340.0),
                )
                current_color_tex = _image_node(
                    tree,
                    spec["current_image_ref"],
                    role=f"Live Color {node_token}",
                    location=(-1700.0, y - 340.0),
                    interpolation="Closest",
                    auxiliary=True,
                )
                current_encode = _group_node(
                    tree,
                    encode_group,
                    role=f"Live {node_token} to sRGB",
                    location=(-1260.0, y - 340.0),
                )
                # STRAIGHT-alpha image-node color is already straight scene-linear.
                tree.links.new(
                    current_color_tex.outputs["Color"],
                    current_encode.inputs["Color"],
                )
                current_color = current_encode.outputs["Color"]
            mask_factor = 1.0
            mask_specs = list(spec.get("mask_images", []) or [])
            if mask_specs:
                mask_factor = mask_factor_for_specs(
                    mask_specs,
                    node_token,
                    y,
                    int(spec["record_index"]),
                )
            current_alpha = (
                current_alpha_override
                if current_alpha_override is not None
                else current_tex.outputs["Alpha"]
            )
            if old_tex is not None:
                old_alpha = old_tex.outputs["Alpha"]
            if mask_specs:
                if old_alpha is not None:
                    old_alpha = _math(tree, "MULTIPLY", old_alpha, mask_factor)
                current_alpha = _math(tree, "MULTIPLY", current_alpha, mask_factor)
                if direct_premultiplied_stack:
                    current_color = _scale_color(
                        tree,
                        current_color,
                        mask_factor,
                        role="formula_live_mask_premultiply",
                    )
            current_nodes[str(spec["stack_key"])] = (current_tex, current_color, current_alpha)
            effective_opacity = (
                max(0.0, min(1.0, float(spec["current_opacity"])))
                if bool(spec["current_enabled"])
                else 0.0
            )
            if not bool(spec.get("clip_to_below", False)):
                clip_base_effective_nodes[str(spec["stack_key"])] = _math(
                    tree,
                    "MULTIPLY",
                    current_alpha,
                    effective_opacity,
                    clamp=True,
                )

            if direct_display_stack:
                continue

            old_channels = _separate(tree, old_encode.outputs["Color"])
            current_channels = _separate(tree, current_color)
            sample_delta = _math(tree, "ABSOLUTE", _math(
                tree,
                "SUBTRACT",
                current_channels.outputs["Red"],
                old_channels.outputs["Red"],
            ))
            for channel in ("Green", "Blue"):
                channel_delta = _math(tree, "ABSOLUTE", _math(
                    tree,
                    "SUBTRACT",
                    current_channels.outputs[channel],
                    old_channels.outputs[channel],
                ))
                sample_delta = _math(tree, "MAXIMUM", sample_delta, channel_delta)
            alpha_delta = _math(
                tree,
                "ABSOLUTE",
                _math(tree, "SUBTRACT", current_alpha, old_alpha),
            )
            sample_delta = _math(tree, "MAXIMUM", sample_delta, alpha_delta)
            pixel_changed = _math(tree, "GREATER_THAN", sample_delta, _EPSILON)
            state_changed = bool(spec["current_enabled"]) != bool(spec["old_enabled"])
            state_changed = state_changed or abs(
                float(spec["current_opacity"]) - float(spec["old_opacity"])
            ) > _INVERSE_EPSILON
            state_changed = state_changed or str(spec["current_blend_mode"]) != str(spec["old_blend_mode"])
            if state_changed:
                pixel_changed = 1.0
            changed = _math(tree, "MAXIMUM", changed, pixel_changed)

            peel_mode = str(spec["old_blend_mode"])
            peel = _group_node(
                tree,
                peel_groups[peel_mode],
                role=f"Peel {peel_mode} source {node_token}",
                location=(-920.0 + position * 220.0, y),
            )
            tree.links.new(dst_color, peel.inputs["Merged Color"])
            tree.links.new(dst_alpha, peel.inputs["Merged Alpha"])
            tree.links.new(old_encode.outputs["Color"], peel.inputs["Old Color"])
            tree.links.new(old_alpha, peel.inputs["Old Alpha"])
            peel.inputs["Opacity"].default_value = (
                max(0.0, min(1.0, float(spec["old_opacity"]))) if bool(spec["old_enabled"]) else 0.0
            )
            dst_color = peel.outputs["Color"]
            dst_alpha = peel.outputs["Alpha"]
            current_opacity = (
                max(0.0, min(1.0, float(spec["current_opacity"]))) if bool(spec["current_enabled"]) else 0.0
            )
            current_effective = _math(tree, "MULTIPLY", current_alpha, current_opacity)
            current_opaque = _math(tree, "GREATER_THAN", current_effective, 1.0 - _EPSILON)
            opaque_replaces_destination = current_opaque if str(spec["current_blend_mode"]) == "MIX" else 0.0
            layer_safe = _math(
                tree,
                "MAXIMUM",
                peel.outputs["Recoverable"],
                opaque_replaces_destination,
            )
            safe = _math(tree, "MULTIPLY", safe, layer_safe)

        runtime_by_key = {
            str(spec.get("stack_key", "") or ""): spec
            for spec in runtime
        }
        apply_position = [0]

        def apply_source(dst_color_socket, dst_alpha_socket, src_color, src_alpha, spec, *, role_prefix: str):
            position = int(apply_position[0])
            apply_position[0] += 1
            node_token = str(spec.get("node_token", spec.get("record_index", -1)) or spec.get("record_index", -1))
            mode = str(spec["current_blend_mode"])
            blend = _group_node(
                tree,
                blend_groups[mode],
                role=f"{role_prefix} {mode} {node_token}",
                location=(80.0 + position * 240.0, 180.0 - position * 220.0),
            )
            tree.links.new(dst_color_socket, blend.inputs["Dst Color"])
            tree.links.new(dst_alpha_socket, blend.inputs["Dst Alpha"])
            tree.links.new(src_color, blend.inputs["Src Color"])
            tree.links.new(src_alpha, blend.inputs["Src Alpha"])
            blend.inputs["Opacity"].default_value = (
                max(0.0, min(1.0, float(spec["current_opacity"])))
                if bool(spec["current_enabled"])
                else 0.0
            )
            clip_alpha = 1.0
            if bool(spec.get("clip_to_below", False)):
                clip_base_key = str(spec.get("clip_base_key", "") or "")
                clip_alpha = clip_base_effective_nodes.get(clip_base_key)
                if clip_alpha is None:
                    raise RuntimeError(
                        f"clipping base missing for layer {spec['stack_key']}: {clip_base_key}"
                    )
            _link_or_set(tree, clip_alpha, blend.inputs["Clip Alpha"])
            return blend.outputs["Color"], blend.outputs["Alpha"]

        def apply_adjustment(
            dst_color_socket,
            dst_alpha_socket,
            spec,
        ):
            position = int(apply_position[0])
            apply_position[0] += 1
            node_token = str(
                spec.get("node_token", spec.get("record_index", -1))
                or spec.get("record_index", -1)
            )
            adjustment_group = _ensure_adjustment_group(
                dict(spec.get("adjustment_state", {}) or {})
            )
            adjustment_node = _group_node(
                tree,
                adjustment_group,
                role=f"Apply adjustment {node_token}",
                location=(80.0 + position * 240.0, 180.0 - position * 220.0),
            )
            tree.links.new(dst_color_socket, adjustment_node.inputs["Color"])
            factor = (
                max(0.0, min(1.0, float(spec.get("current_opacity", 1.0))))
                if bool(spec.get("current_enabled", True))
                else 0.0
            )
            mask_specs = list(spec.get("mask_images", []) or [])
            if mask_specs:
                factor = _math(
                    tree,
                    "MULTIPLY",
                    factor,
                    mask_factor_for_specs(
                        mask_specs,
                        node_token,
                        300.0 - float(position) * 360.0,
                        int(spec.get("record_index", -1)),
                    ),
                    clamp=True,
                )
            if bool(spec.get("clip_to_below", False)):
                clip_base_key = str(spec.get("clip_base_key", "") or "")
                clip_alpha = clip_base_effective_nodes.get(clip_base_key)
                if clip_alpha is None:
                    raise RuntimeError(
                        f"clipping base missing for adjustment {spec['stack_key']}: "
                        f"{clip_base_key}"
                    )
                factor = _math(
                    tree,
                    "MULTIPLY",
                    factor,
                    clip_alpha,
                    clamp=True,
                )
            elif str(spec.get("stack_key", "") or ""):
                clip_base_effective_nodes[str(spec["stack_key"])] = _math(
                    tree,
                    "MULTIPLY",
                    dst_alpha_socket,
                    factor,
                    clamp=True,
                )
            return (
                _mix_color(
                    tree,
                    dst_color_socket,
                    adjustment_node.outputs["Color"],
                    factor,
                ),
                dst_alpha_socket,
            )

        def compose_structure_nodes(nodes, base_color, base_alpha):
            out_color, out_alpha = base_color, base_alpha
            for node in list(nodes or []):
                if str(node.get("kind", "")) == "layer":
                    spec = runtime_by_key.get(str(node.get("stack_key", "") or ""))
                    if spec is None:
                        raise RuntimeError("composition tree references a missing paint layer")
                    _tex, src_color, src_alpha = current_nodes[str(spec["stack_key"])]
                    out_color, out_alpha = apply_source(
                        out_color,
                        out_alpha,
                        src_color,
                        src_alpha,
                        spec,
                        role_prefix="Apply live",
                    )
                    continue
                if str(node.get("kind", "")) == "adjustment":
                    spec = adjustment_runtime.get(
                        str(node.get("stack_key", "") or "")
                    )
                    if spec is None:
                        raise RuntimeError(
                            "composition tree references a missing adjustment layer"
                        )
                    out_color, out_alpha = apply_adjustment(
                        out_color,
                        out_alpha,
                        spec,
                    )
                    continue
                group_spec = group_runtime.get(str(node.get("stack_key", "") or ""))
                if group_spec is None:
                    raise RuntimeError("composition tree references a missing group")
                if bool(group_spec.get("pass_through", False)):
                    before_color, before_alpha = out_color, out_alpha
                    effected_color, effected_alpha = compose_structure_nodes(
                        node.get("children", []),
                        out_color,
                        out_alpha,
                    )
                    group_factor = (
                        max(0.0, min(1.0, float(group_spec["current_opacity"])))
                        if bool(group_spec["current_enabled"])
                        else 0.0
                    )
                    group_masks = list(group_spec.get("mask_images", []) or [])
                    if group_masks:
                        mask_factor = mask_factor_for_specs(
                            group_masks,
                            str(group_spec.get("node_token", "group") or "group"),
                            300.0 - float(apply_position[0]) * 360.0,
                            int(group_spec.get("record_index", -1)),
                        )
                        group_factor = _math(
                            tree,
                            "MULTIPLY",
                            group_factor,
                            mask_factor,
                            clamp=True,
                        )
                    before_premultiplied = (
                        before_color
                        if direct_premultiplied_stack
                        else _scale_color(
                            tree,
                            before_color,
                            before_alpha,
                            role="formula_pass_through_before_premultiply",
                        )
                    )
                    effected_premultiplied = (
                        effected_color
                        if direct_premultiplied_stack
                        else _scale_color(
                            tree,
                            effected_color,
                            effected_alpha,
                            role="formula_pass_through_after_premultiply",
                        )
                    )
                    out_premultiplied = _mix_color(
                        tree,
                        before_premultiplied,
                        effected_premultiplied,
                        group_factor,
                    )
                    out_alpha = _math(
                        tree,
                        "ADD",
                        _math(
                            tree,
                            "MULTIPLY",
                            before_alpha,
                            _math(tree, "SUBTRACT", 1.0, group_factor),
                        ),
                        _math(tree, "MULTIPLY", effected_alpha, group_factor),
                        clamp=True,
                    )
                    out_color = (
                        out_premultiplied
                        if direct_premultiplied_stack
                        else _unpremultiply_color(tree, out_premultiplied, out_alpha)
                    )
                    continue
                group_color = _combine(tree, (0.0, 0.0, 0.0))
                group_alpha = _math(tree, "MULTIPLY", 1.0, 0.0)
                group_color, group_alpha = compose_structure_nodes(
                    node.get("children", []),
                    group_color,
                    group_alpha,
                )
                group_masks = list(group_spec.get("mask_images", []) or [])
                if group_masks:
                    group_factor = mask_factor_for_specs(
                        group_masks,
                        str(group_spec.get("node_token", "group") or "group"),
                        300.0 - float(apply_position[0]) * 360.0,
                        int(group_spec.get("record_index", -1)),
                    )
                    group_alpha = _math(tree, "MULTIPLY", group_alpha, group_factor)
                    if direct_premultiplied_stack:
                        group_color = _scale_color(
                            tree,
                            group_color,
                            group_factor,
                            role="formula_live_group_mask_premultiply",
                        )
                out_color, out_alpha = apply_source(
                    out_color,
                    out_alpha,
                    group_color,
                    group_alpha,
                    group_spec,
                    role_prefix="Apply isolated group",
                )
            return out_color, out_alpha

        if direct_display_stack:
            dst_color, dst_alpha = compose_structure_nodes(
                structure.get("nodes", []),
                dst_color,
                dst_alpha,
            )
        else:
            for spec in reversed(runtime):
                _tex, src_color, src_alpha = current_nodes[str(spec["stack_key"])]
                dst_color, dst_alpha = apply_source(
                    dst_color,
                    dst_alpha,
                    src_color,
                    src_alpha,
                    spec,
                    role_prefix="Apply live",
                )

        if direct_display_stack:
            safe_color = (
                _unpremultiply_color(tree, dst_color, dst_alpha)
                if direct_premultiplied_stack
                else dst_color
            )
            safe_alpha = dst_alpha
        else:
            # A partial peel cannot always invert a filtered opaque edge. Keep
            # the saved Photoshop composite until a recoverable sample changes.
            live_factor = _math(tree, "MULTIPLY", safe, changed)
            safe_color = _mix_color(tree, saved_color, dst_color, live_factor)
            safe_alpha = _math(
                tree,
                "ADD",
                _math(tree, "MULTIPLY", saved_alpha, _math(tree, "SUBTRACT", 1.0, live_factor)),
                _math(tree, "MULTIPLY", dst_alpha, live_factor),
                clamp=True,
            )
        output_decode = _group_node(tree, decode_group, role="Composite to scene-linear", location=(780.0, 260.0))
        tree.links.new(safe_color, output_decode.inputs["Color"])
        if principled:
            for bsdf in principled:
                color_socket = bsdf.inputs.get("Base Color")
                alpha_socket = bsdf.inputs.get("Alpha")
                if color_socket is not None:
                    for link in list(color_socket.links):
                        tree.links.remove(link)
                    tree.links.new(output_decode.outputs["Color"], color_socket)
                if alpha_socket is not None:
                    for link in list(alpha_socket.links):
                        tree.links.remove(link)
                    tree.links.new(safe_alpha, alpha_socket)
        else:
            connected = _connect_custom_shader_targets(
                tree,
                custom_shader_targets,
                output_decode.outputs["Color"],
                safe_alpha,
            )
            if connected != len(custom_shader_targets):
                raise RuntimeError(f"custom shader target mismatch: {connected}/{len(custom_shader_targets)}")

        active_image = _active_canvas(context)
        active_node = None
        if active_image is not None:
            layer_id = str(active_image.get("smart_paint_suite_layer_id", "") or "")
            active_node = psd_io._ensure_layer_paint_node(material, layer_id, CHANNEL, active_image)
        if active_node is not None:
            tree.nodes.active = active_node
        active_stream = next(
            (spec for spec in runtime if bool(spec.get("use_live_canvas", False))),
            None,
        )
        _store_image_editor_overlay_contract(
            material,
            cache,
            runtime,
            group_runtime,
            adjustment_runtime,
            structure,
            direct_display_stack=bool(direct_display_stack),
            direct_premultiplied_stack=bool(direct_premultiplied_stack),
            active_canvas=_active_canvas(context),
        )
        material["sps_lightweight_display_mode"] = "LIVE_COMPOSITE"
        material["sps_mvp_live_composite_chain"] = json.dumps(chain_records)
        material["sps_mvp_live_composite_chain_layer_ids"] = json.dumps(
            chain_layer_ids,
            ensure_ascii=False,
        )
        material["sps_mvp_live_composite_blend_modes"] = json.dumps(
            sorted(set(peel_modes) | set(current_modes))
        )
        material["sps_mvp_live_composite_mask_count"] = int(cache.get("mask_count", 0) or 0)
        material["sps_mvp_live_composite_opaque_pixels"] = int(cache.get("opaque_pixels", 0) or 0)
        skipped_rows = list(cache.get("skipped_rows", []) or [])
        material["sps_mvp_live_composite_exact_saved_bypass"] = bool(not direct_display_stack)
        material["sps_mvp_live_composite_direct_full_stack"] = bool(direct_full_stack)
        material["sps_mvp_live_composite_direct_display_stack"] = bool(direct_display_stack)
        material["sps_mvp_live_composite_skipped_row_count"] = int(len(skipped_rows))
        material["sps_mvp_live_composite_skipped_rows"] = json.dumps(
            [str(row.get("name", "") or "") for row in skipped_rows],
            ensure_ascii=False,
        )
        material["sps_mvp_live_composite_actual_texture_count"] = int(actual_texture_count)
        material["sps_mvp_live_composite_custom_shader_target_count"] = int(len(custom_shader_targets))
        material["sps_mvp_live_composite_active_stream_record"] = int(
            active_stream.get("record_index", -1) if active_stream is not None else -1
        )
        material["sps_mvp_live_composite_active_stream_layer_id"] = str(
            active_stream.get("layer_id", "") if active_stream is not None else ""
        )
        material["sps_mvp_live_composite_warning"] = (
            "opaque_source_erase_uses_saved_preview"
            if int(cache.get("opaque_pixels", 0) or 0) > 0 and not direct_display_stack
            else ""
        )
        material.update_tag()
        tree.update_tag()
        # The live graph creates its image textures after the regular display
        # binding path. Re-apply the object workspace UV now so every newly
        # created texture in the add-on-owned temporary material uses the
        # selected paint channel rather than Blender's implicit default.
        try:
            from . import paint_workspace

            paint_workspace.synchronize(context, material)
        except Exception:
            pass
        canvas_after = _active_canvas(context)
        canvas_preserved = bool(
            canvas_before is not None
            and canvas_after is not None
            and int(canvas_after.as_pointer()) == int(canvas_pointer)
        )
        if not canvas_preserved and canvas_before is not None:
            try:
                paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
                paint.canvas = canvas_before
                canvas_preserved = True
            except Exception:
                pass
        result = {
            "ok": True,
            "reason": "live_composite_ready",
            "chain_records": chain_records,
            "chain_layer_ids": chain_layer_ids,
            "chain_layer_count": len(runtime),
            "clipped_layer_count": sum(
                1 for spec in runtime if bool(spec.get("clip_to_below", False))
            ),
            "mask_count": int(cache.get("mask_count", 0) or 0),
            "blend_modes": sorted(set(peel_modes) | set(current_modes)),
            "texture_count": int(cache.get("texture_count", 1 + len(runtime) * 2) or 0),
            "actual_texture_count": int(actual_texture_count),
            "sampler_limit": int(cache.get("sampler_limit", _fragment_sampler_limit()) or 0),
            "opaque_source_pixels": int(cache.get("opaque_pixels", 0) or 0),
            "exact_saved_bypass": bool(not direct_display_stack),
            "direct_full_stack": bool(direct_full_stack),
            "direct_display_stack": bool(direct_display_stack),
            "skipped_row_count": int(len(skipped_rows)),
            "skipped_rows": [str(row.get("name", "") or "") for row in skipped_rows],
            "active_stream_record": int(
                active_stream.get("record_index", -1) if active_stream is not None else -1
            ),
            "active_stream_layer_id": str(
                active_stream.get("layer_id", "") if active_stream is not None else ""
            ),
            "canvas_preserved": bool(canvas_preserved),
            "custom_shader_target_count": int(len(custom_shader_targets)),
            "cache_reused": bool(cache_result.get("cached", False)),
            "cache_reordered": bool(cache_result.get("reordered", False)),
            "phase_ms": {
                "cache": round((cache_ready_at - started) * 1000.0, 3),
                "runtime_images": round((runtime_ready_at - runtime_started_at) * 1000.0, 3),
                "graph": round((time.perf_counter() - graph_started_at) * 1000.0, 3),
            },
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
        _trace("mvp_live_composite_build", material=material, **result)
        return result
    except Exception as exc:
        try:
            _restore_custom_shader_links(material, tree, clear=True)
            _remove_graph_nodes(tree)
            tree.update_tag()
        except Exception:
            pass
        result = {
            "ok": False,
            "reason": "live_graph_exception",
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
        _trace("mvp_live_composite_build", material=material, **result)
        return result


def refresh(material, context=None) -> dict[str, Any]:
    return build(material, context, force_cache=False)


def disable(material, *, remove_nodes: bool = False) -> None:
    clear_mask_display_proxies(material)
    try:
        tree = getattr(material, "node_tree", None)
        if tree is not None:
            _restore_custom_shader_links(material, tree, clear=True)
        if tree is not None and bool(remove_nodes):
            _remove_graph_nodes(tree)
            tree.update_tag()
        for key in (
            "sps_mvp_live_composite_chain",
            "sps_mvp_live_composite_blend_modes",
            "sps_mvp_live_composite_mask_count",
            "sps_mvp_live_composite_opaque_pixels",
            "sps_mvp_live_composite_exact_saved_bypass",
            "sps_mvp_live_composite_direct_full_stack",
            "sps_mvp_live_composite_direct_display_stack",
            "sps_mvp_live_composite_skipped_row_count",
            "sps_mvp_live_composite_skipped_rows",
            "sps_mvp_live_composite_actual_texture_count",
            "sps_mvp_live_composite_custom_shader_target_count",
            _CUSTOM_SHADER_LINKS_PROPERTY,
            "sps_mvp_live_composite_active_stream_record",
            "sps_mvp_live_composite_warning",
        ):
            if key in material:
                del material[key]
    except Exception:
        pass

def clear_runtime_caches(*, remove_unused_owned_data: bool = True) -> None:
    """Release every Suite-owned live-composite cache and unused temporary ID.

    This is called only at explicit lifecycle boundaries.  Foreign/user images,
    materials and node groups are never selected by name or prefix.
    """
    _CACHE.clear()
    _MASK_DISPLAY_PROXY_CACHE.clear()
    _EXPLICIT_IMAGE_U8_CACHE.clear()
    if not remove_unused_owned_data:
        return
    clear_mask_display_proxies(None)
    for image in tuple(getattr(bpy.data, "images", ()) or ()):
        try:
            if _exact_owned_image(image) and int(getattr(image, "users", 0) or 0) <= 0:
                bpy.data.images.remove(image)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    for group in tuple(getattr(bpy.data, "node_groups", ()) or ()):
        try:
            if _exact_owned_group(group) and int(getattr(group, "users", 0) or 0) <= 0:
                bpy.data.node_groups.remove(group)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
