# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Event-driven live composite display for Solid-shaded 3D viewports.

Workbench Solid shading does not evaluate material node trees.  Evaluated mesh
and UV data are copied only by explicit/event-driven rebuild callbacks.  The
actual draw handler consumes an immutable Python/GPU snapshot and never calls
``evaluated_get``, ``evaluated_depsgraph_get``, ``Object.data``, mesh triangle
generation, shader construction, texture lookup, or GPU batch construction.
No handler or timer remains registered while the Solid overlay is inactive.
"""

from __future__ import annotations

import hashlib
import time
from types import MappingProxyType
from typing import Any

import bpy
import gpu as _gpu
from bpy.app.handlers import persistent

from .. import manager_rule_api as _manager_rule_api


ERROR_PROPERTY = "sps_mvp_solid_overlay_error"
_HANDLE = None
_ACTIVE_DISPLAY_MATERIAL_NAMES: tuple[str, ...] = ()
_BACKING_SHADER = None
# Draw state is a current immutable snapshot, not a history cache.  Replacing
# the tuple releases all previous object batches and texture handles at once.
_DRAW_SNAPSHOT: tuple[dict[str, Any], ...] = ()
_SNAPSHOT_GENERATION = 0
_BOUNDARY_DEPTH = 0
_BOUNDARY_READY_AFTER = 0.0
_REBUILD_TIMER_REGISTERED = False
_REBUILD_REQUESTED = False
_REBUILD_DUE_AT = 0.0
_SYNC_TIMER_REGISTERED = False
_RUNTIME_REQUESTED = False
_DORMANT_REPORTED = False


def _resolve_material(context):
    try:
        from .. import lightweight_mvp

        return lightweight_mvp._resolve_material(context)
    except Exception:
        return None


def _display_mode(material) -> str:
    try:
        return str(material.get("sps_lightweight_display_mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    except Exception:
        return "ACTIVE_LAYER"


def _refresh_active_display_materials() -> tuple[str, ...]:
    """Snapshot operation-bound display owners outside the draw callback."""
    global _ACTIVE_DISPLAY_MATERIAL_NAMES
    names = []
    for material in list(getattr(bpy.data, "materials", ()) or ()):
        try:
            if _display_mode(material) not in {"LIVE_COMPOSITE", "COMPOSITE_PREVIEW"}:
                continue
            name = str(
                getattr(material, "name_full", "")
                or getattr(material, "name", "")
                or ""
            )
            if name and name not in names:
                names.append(name)
        except Exception:
            continue
    _ACTIVE_DISPLAY_MATERIAL_NAMES = tuple(names)
    return _ACTIVE_DISPLAY_MATERIAL_NAMES


def _active_display_materials(context=None):
    """Resolve the cached display owners without trusting the active slot.

    Texture Paint can change ``active_material_index`` while a Review or Live
    display is active. The display contract belongs to the Smart Paint
    material that enabled the mode, not whichever slot happens to be active
    during a later redraw.
    """
    result = []
    seen = set()
    for name in _ACTIVE_DISPLAY_MATERIAL_NAMES:
        material = bpy.data.materials.get(str(name or ""))
        if material is None or _display_mode(material) not in {
            "LIVE_COMPOSITE",
            "COMPOSITE_PREVIEW",
        }:
            continue
        pointer = int(material.as_pointer())
        if pointer not in seen:
            seen.add(pointer)
            result.append(material)
    current = _resolve_material(context)
    if current is not None and _display_mode(current) in {
        "LIVE_COMPOSITE",
        "COMPOSITE_PREVIEW",
    }:
        pointer = int(current.as_pointer())
        if pointer not in seen:
            seen.add(pointer)
            result.append(current)
    return result


def _live_contract(material):
    try:
        from . import image_editor_overlay

        return image_editor_overlay._contract(material)
    except Exception as exc:
        return None, repr(exc)[:384]


def _preview_image(material):
    try:
        name = str(material.get("sps_lightweight_composite_image", "") or "")
    except Exception:
        name = ""
    return bpy.data.images.get(name) if name else None


def _object_uses_material(obj, material) -> bool:
    if obj is None or material is None:
        return False
    try:
        material_pointer = int(material.as_pointer())
        material_name = str(
            getattr(material, "name_full", "")
            or getattr(material, "name", "")
            or ""
        )
        for slot in getattr(obj, "material_slots", ()) or ():
            candidate = getattr(slot, "material", None)
            if candidate is None:
                continue
            candidate_name = str(
                getattr(candidate, "name_full", "")
                or getattr(candidate, "name", "")
                or ""
            )
            if (
                candidate is material
                or int(candidate.as_pointer()) == material_pointer
                or (material_name and candidate_name == material_name)
            ):
                return True
    except Exception:
        return False
    return False


def _visible_material_objects(context, material):
    try:
        candidates = list(getattr(context, "visible_objects", ()) or ())
    except Exception:
        candidates = []
    if not candidates:
        candidate = getattr(context, "active_object", None)
        candidates = [candidate] if candidate is not None else []
    result = []
    for obj in candidates:
        try:
            mesh = getattr(obj, "data", None)
            uv_layer = getattr(getattr(mesh, "uv_layers", None), "active", None)
            if (
                str(getattr(obj, "type", "") or "") == "MESH"
                and bool(obj.visible_get())
                and uv_layer is not None
                and _object_uses_material(obj, material)
            ):
                result.append(obj)
        except Exception:
            continue
    return result


def _create_shader(fragment: str, image_names, signature: str):
    import gpu

    interface = gpu.types.GPUStageInterfaceInfo(f"sps_solid_{signature[:10]}")
    interface.smooth("VEC2", "uv_interp")
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, "VEC3", "pos")
    info.vertex_in(1, "VEC2", "uv")
    info.vertex_out(interface)
    info.push_constant("MAT4", "model_view_projection")
    info.push_constant("VEC4", "solid_backing_color")
    for slot, _image_name in enumerate(image_names):
        info.sampler(slot, "FLOAT_2D", f"image_{slot}")
    info.fragment_out(0, "VEC4", "frag_color")
    info.vertex_source(
        "void main() {\n"
        "  uv_interp = uv;\n"
        "  gl_Position = model_view_projection * vec4(pos, 1.0);\n"
        "  gl_Position.z -= 0.00001 * gl_Position.w;\n"
        "}\n"
    )
    info.fragment_source(fragment)
    return gpu.shader.create_from_info(info)


def _backing_shader():
    """Return a minimal opaque pass for Solid view composite ownership.

    The native Texture Paint target is intentionally a private layer image.
    That image can be transparent, so Workbench may discard the mesh surface
    before the live composite draw handler runs.  A simple depth-writing pass
    keeps the evaluated mesh visible even when the composite shader skips a
    pixel or fails during one redraw.  It does not mutate the material or its
    render-time alpha contract.
    """
    global _BACKING_SHADER
    if _BACKING_SHADER is not None:
        return _BACKING_SHADER

    import gpu

    interface = gpu.types.GPUStageInterfaceInfo("sps_solid_backing")
    interface.smooth("VEC2", "uv_interp")
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, "VEC3", "pos")
    info.vertex_in(1, "VEC2", "uv")
    info.vertex_out(interface)
    info.push_constant("MAT4", "model_view_projection")
    info.push_constant("VEC4", "backing_color")
    info.fragment_out(0, "VEC4", "frag_color")
    info.vertex_source(
        "void main() {\n"
        "  uv_interp = uv;\n"
        "  gl_Position = model_view_projection * vec4(pos, 1.0);\n"
        "  gl_Position.z -= 0.000005 * gl_Position.w;\n"
        "}\n"
    )
    info.fragment_source(
        "void main() {\n"
        "  if (isnan(uv_interp.x) || isnan(uv_interp.y)) { discard; }\n"
        "  frag_color = vec4(backing_color.rgb, 1.0);\n"
        "}\n"
    )
    _BACKING_SHADER = gpu.shader.create_from_info(info)
    return _BACKING_SHADER


def _backing_color(material) -> tuple[float, float, float, float]:
    try:
        diffuse = tuple(float(value) for value in material.diffuse_color)
    except Exception:
        diffuse = ()
    if len(diffuse) < 3:
        diffuse = (0.8, 0.8, 0.8)
    return (
        max(0.0, min(1.0, diffuse[0])),
        max(0.0, min(1.0, diffuse[1])),
        max(0.0, min(1.0, diffuse[2])),
        1.0,
    )


def _live_runtime(contract: dict[str, Any]):
    """Compile one snapshot-owned shader; no historical GPU cache is retained."""
    from . import image_editor_overlay

    fragment, image_names = image_editor_overlay._build_shader_source(
        contract, output_mode="VIEW_3D"
    )
    token = "live|" + str(contract.get("signature", "") or "") + "|" + fragment
    signature = hashlib.sha1(token.encode("utf-8")).hexdigest()
    return {
        "signature": signature,
        "shader": _create_shader(fragment, image_names, signature),
        "image_names": tuple(image_names),
        "mode": "LIVE_COMPOSITE",
    }

def _preview_runtime(image):
    """Compile one preview shader for the next immutable snapshot."""
    image_name = str(getattr(image, "name", "") or "")
    signature = hashlib.sha1(("preview|" + image_name).encode("utf-8")).hexdigest()
    fragment = """
void main() {
    vec4 sampleValue = texture(image_0, uv_interp);
    float displayAlpha = clamp(sampleValue.a, 0.0, 1.0);
    vec3 displayColor = clamp(sampleValue.rgb, 0.0, 1.0) * displayAlpha
        + clamp(solid_backing_color.rgb, 0.0, 1.0) * (1.0 - displayAlpha);
    frag_color = vec4(clamp(displayColor, 0.0, 1.0), 1.0);
}
"""
    return {
        "signature": signature,
        "shader": _create_shader(fragment, (image_name,), signature),
        "image_names": (image_name,),
        "mode": "COMPOSITE_PREVIEW",
    }

def prepare(material, context=None) -> dict[str, Any]:
    if material is None:
        return {"ok": False, "reason": "material_missing"}
    mode = _display_mode(material)
    try:
        if mode == "LIVE_COMPOSITE":
            contract, reason = _live_contract(material)
            if contract is None:
                return {"ok": False, "reason": reason or "live_contract_missing"}
            runtime = _live_runtime(contract)
        elif mode == "COMPOSITE_PREVIEW":
            image = _preview_image(material)
            if image is None:
                return {"ok": False, "reason": "composite_preview_missing"}
            runtime = _preview_runtime(image)
        else:
            return {"ok": False, "reason": "composite_mode_inactive"}
    except Exception as exc:
        return {
            "ok": False,
            "reason": "solid_overlay_shader_failed",
            "error": repr(exc)[:512],
        }
    missing = [
        name
        for name in runtime["image_names"]
        if bpy.data.images.get(str(name or "")) is None
    ]
    if missing:
        return {
            "ok": False,
            "reason": "solid_overlay_texture_missing",
            "missing": missing[:8],
        }
    if context is not None:
        objects = _visible_material_objects(context, material)
        if not objects:
            return {"ok": False, "reason": "solid_overlay_mesh_missing"}
    return {
        "ok": True,
        "reason": "solid_overlay_ready",
        "signature": str(runtime["signature"]),
        "texture_count": len(runtime["image_names"]),
        "mode": mode,
    }


def _runtime(material):
    mode = _display_mode(material)
    if mode == "LIVE_COMPOSITE":
        contract, reason = _live_contract(material)
        if contract is None:
            raise RuntimeError(reason or "live_contract_missing")
        return _live_runtime(contract)
    if mode == "COMPOSITE_PREVIEW":
        image = _preview_image(material)
        if image is None:
            raise RuntimeError("composite_preview_missing")
        return _preview_runtime(image)
    raise RuntimeError("composite_mode_inactive")


def _file_boundary_active() -> bool:
    return bool(_BOUNDARY_DEPTH > 0 or time.monotonic() < float(_BOUNDARY_READY_AFTER))


def _clear_draw_snapshot() -> None:
    global _DRAW_SNAPSHOT, _SNAPSHOT_GENERATION
    _DRAW_SNAPSHOT = ()
    _SNAPSHOT_GENERATION += 1


def _target_material_slots(obj, material) -> set[int]:
    result = set()
    try:
        material_pointer = int(material.as_pointer())
        material_name = str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
        for slot_index, slot in enumerate(getattr(obj, "material_slots", ()) or ()):
            candidate = getattr(slot, "material", None)
            if candidate is None:
                continue
            candidate_name = str(getattr(candidate, "name_full", "") or getattr(candidate, "name", "") or "")
            if candidate is material or int(candidate.as_pointer()) == material_pointer or (material_name and candidate_name == material_name):
                result.add(int(slot_index))
    except Exception:
        return set()
    return result


def _extract_cpu_geometry(obj, material, depsgraph):
    """Copy evaluated mesh/UV arrays without calling ``Object.to_mesh``."""
    import numpy as np
    if obj is None or material is None or depsgraph is None or _file_boundary_active():
        return None
    try:
        if str(getattr(obj, "type", "") or "") != "MESH":
            return None
        target_slots = _target_material_slots(obj, material)
        if not target_slots:
            return None
        evaluated = obj.evaluated_get(depsgraph)
        evaluated_mesh = getattr(evaluated, "data", None)
        if not isinstance(evaluated_mesh, bpy.types.Mesh):
            return None
        evaluated_uv = getattr(getattr(evaluated_mesh, "uv_layers", None), "active", None)
        if evaluated_uv is None:
            return None
        evaluated_mesh.calc_loop_triangles()
        positions = []
        uvs = []
        for triangle in tuple(getattr(evaluated_mesh, "loop_triangles", ()) or ()):
            polygon_index = int(getattr(triangle, "polygon_index", -1))
            if polygon_index < 0 or polygon_index >= len(evaluated_mesh.polygons):
                continue
            polygon = evaluated_mesh.polygons[polygon_index]
            if int(getattr(polygon, "material_index", 0) or 0) not in target_slots:
                continue
            for loop_index in triangle.loops:
                loop_index = int(loop_index)
                loop = evaluated_mesh.loops[loop_index]
                co = evaluated_mesh.vertices[int(loop.vertex_index)].co
                uv = evaluated_uv.data[loop_index].uv
                positions.append((float(co.x), float(co.y), float(co.z)))
                uvs.append((float(uv.x), float(uv.y)))
        if not positions:
            return None
        return {
            "positions": np.asarray(positions, dtype=np.float32),
            "uvs": np.asarray(uvs, dtype=np.float32),
            "matrix_world": evaluated.matrix_world.copy(),
            "revision": time.monotonic_ns(),
        }
    except Exception:
        return None


def _build_batch(shader, geometry: dict[str, Any]):
    """Create one GPU batch outside the draw callback."""
    positions = geometry.get("positions")
    uvs = geometry.get("uvs")
    if positions is None or uvs is None or len(positions) == 0:
        return None
    from gpu_extras.batch import batch_for_shader

    return batch_for_shader(shader, "TRIS", {"pos": positions, "uv": uvs})


def _resolve_texture_handles(material, runtime: dict[str, Any]):
    """Resolve Blender images and GPU texture handles outside drawing."""
    gpu = _gpu
    from . import live_composite

    handles = []
    for image_name in tuple(runtime.get("image_names", ()) or ()):
        image = live_composite.resolve_display_image(material, image_name)
        if image is None:
            raise RuntimeError(f"solid overlay image missing: {image_name}")
        handles.append(gpu.texture.from_image(image))
    return tuple(handles)


def _set_material_error(material, message: str) -> None:
    """Update the diagnostic ID property only when its value actually changes."""
    text = str(message or "")[:512]
    try:
        current = str(material.get(ERROR_PROPERTY, "") or "")
        if current != text:
            material[ERROR_PROPERTY] = text
    except Exception:
        pass


def _rebuild_draw_snapshot_now() -> bool:
    """Build an atomic draw snapshot from evaluated RNA on the main thread.

    All evaluated-object access, loop-triangle generation, material traversal,
    image resolution, shader creation, texture creation, and GPU batch creation
    terminate here.  ``_draw_overlay`` only reads the completed tuple.
    """
    global _DRAW_SNAPSHOT, _SNAPSHOT_GENERATION
    if _file_boundary_active() or not _RUNTIME_REQUESTED or bpy.app.background:
        return False
    context = getattr(bpy, "context", None)
    try:
        if context is None or getattr(context, "window_manager", None) is None:
            return False
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        return False

    materials = tuple(_active_display_materials(context))
    if not materials:
        _clear_draw_snapshot()
        return True

    next_snapshot = []
    backing_shader = None
    for material in materials:
        try:
            runtime = _runtime(material)
            textures = _resolve_texture_handles(material, runtime)
            if backing_shader is None:
                backing_shader = _backing_shader()
            object_entries = []
            for obj in tuple(_visible_material_objects(context, material)):
                geometry = _extract_cpu_geometry(obj, material, depsgraph)
                if not isinstance(geometry, dict):
                    continue
                composite_batch = _build_batch(runtime["shader"], geometry)
                backing_batch = _build_batch(backing_shader, geometry)
                if composite_batch is None or backing_batch is None:
                    continue
                object_entries.append(MappingProxyType({
                    "matrix_world": geometry["matrix_world"],
                    "composite_batch": composite_batch,
                    "backing_batch": backing_batch,
                }))
            if not object_entries:
                _set_material_error(material, "solid_overlay_mesh_or_uv_missing")
                continue
            next_snapshot.append(MappingProxyType({
                "shader": runtime["shader"],
                "texture_uniforms": tuple(
                    f"image_{slot}" for slot in range(len(textures))
                ),
                "textures": textures,
                "backing_shader": backing_shader,
                "backing_color": _backing_color(material),
                "objects": tuple(object_entries),
            }))
            _set_material_error(material, "")
        except Exception as exc:
            _set_material_error(material, repr(exc))

    _SNAPSHOT_GENERATION += 1
    _DRAW_SNAPSHOT = tuple(next_snapshot)
    _tag_view3d()
    return bool(next_snapshot)


def _rebuild_tick():
    global _REBUILD_TIMER_REGISTERED, _REBUILD_REQUESTED, _REBUILD_DUE_AT
    from .. import runtime_registry
    runtime_registry.timer_finished(_rebuild_tick)
    _REBUILD_TIMER_REGISTERED = False
    if not _RUNTIME_REQUESTED:
        _REBUILD_REQUESTED = False
        _REBUILD_DUE_AT = 0.0
        return None
    now = time.monotonic()
    if _file_boundary_active():
        _schedule_rebuild(max(0.02, float(_BOUNDARY_READY_AFTER) - now))
        return None
    remaining = float(_REBUILD_DUE_AT) - now
    if remaining > 0.0:
        _schedule_rebuild(remaining)
        return None
    _REBUILD_REQUESTED = False
    _REBUILD_DUE_AT = 0.0
    _rebuild_draw_snapshot_now()
    return None


def _schedule_rebuild(delay=0.05) -> bool:
    global _REBUILD_TIMER_REGISTERED, _REBUILD_REQUESTED, _REBUILD_DUE_AT
    if bpy.app.background or not _RUNTIME_REQUESTED or not _ACTIVE_DISPLAY_MATERIAL_NAMES:
        return False
    _REBUILD_REQUESTED = True
    _REBUILD_DUE_AT = max(_REBUILD_DUE_AT, time.monotonic() + max(0.0, float(delay)))
    if _REBUILD_TIMER_REGISTERED:
        return True
    try:
        from .. import runtime_registry
        runtime_registry.register_timer(
            _rebuild_tick, first_interval=max(0.01, float(delay)),
            persistent=False, label="solid_overlay.rebuild_once",
        )
        _REBUILD_TIMER_REGISTERED = True
        return True
    except (RuntimeError, ReferenceError, AttributeError):
        _REBUILD_TIMER_REGISTERED = False
        return False


def _cancel_rebuild_timer() -> None:
    global _REBUILD_TIMER_REGISTERED, _REBUILD_REQUESTED, _REBUILD_DUE_AT
    from .. import runtime_registry
    runtime_registry.unregister_timer(_rebuild_tick)
    _REBUILD_TIMER_REGISTERED = False
    _REBUILD_REQUESTED = False
    _REBUILD_DUE_AT = 0.0


def _cancel_boundary_resume_timer() -> None:
    from .. import runtime_registry
    runtime_registry.unregister_timer(_boundary_resume_tick)


def _sync_tick():
    """Apply deferred handler mutation once, after event callbacks return."""
    global _SYNC_TIMER_REGISTERED
    from .. import runtime_registry
    runtime_registry.timer_finished(_sync_tick)
    _SYNC_TIMER_REGISTERED = False
    if _RUNTIME_REQUESTED:
        sync_handler_state()
    return None


def _schedule_sync(delay=0.01) -> bool:
    global _SYNC_TIMER_REGISTERED
    if bpy.app.background or not _RUNTIME_REQUESTED:
        return False
    if _SYNC_TIMER_REGISTERED:
        return True
    try:
        from .. import runtime_registry
        runtime_registry.register_timer(
            _sync_tick, first_interval=max(0.01, float(delay)),
            persistent=False, label="solid_overlay.sync_once",
        )
        _SYNC_TIMER_REGISTERED = True
        return True
    except (RuntimeError, ReferenceError, AttributeError):
        _SYNC_TIMER_REGISTERED = False
        return False


def _cancel_sync_timer() -> None:
    global _SYNC_TIMER_REGISTERED
    from .. import runtime_registry
    runtime_registry.unregister_timer(_sync_tick)
    _SYNC_TIMER_REGISTERED = False


def _capture_gpu_state(gpu_module) -> tuple[tuple[str, Any], ...]:
    captured = []
    for name in (
        "blend", "depth_test", "depth_mask", "face_culling", "line_width",
        "point_size", "scissor_test", "scissor", "viewport", "color_mask",
    ):
        getter = getattr(gpu_module.state, f"{name}_get", None)
        if not callable(getter):
            continue
        try:
            captured.append((name, getter()))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            continue
    return tuple(captured)


def _restore_gpu_state(gpu_module, captured: tuple[tuple[str, Any], ...]) -> None:
    for name, value in reversed(captured):
        setter = getattr(gpu_module.state, f"{name}_set", None)
        if not callable(setter):
            continue
        try:
            if name in {"scissor", "viewport", "color_mask"} and isinstance(value, (tuple, list)):
                setter(*value)
            else:
                setter(value)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            continue


def _draw_overlay():
    """Replay immutable GPU state only for the target workspace."""
    # File/undo boundaries clear the published snapshot before draw handlers
    # run. The single memory-only Manager query never scans windows or data.
    if not _manager_rule_api.workspace_runtime_allowed(getattr(bpy, "context", None)):
        return
    snapshot = _DRAW_SNAPSHOT
    if not snapshot:
        return
    gpu = _gpu
    captured = _capture_gpu_state(gpu)
    try:
        view_projection = (
            gpu.matrix.get_projection_matrix()
            @ gpu.matrix.get_model_view_matrix()
        )
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set("NONE")
        for material_state in snapshot:
            objects = material_state["objects"]
            if not objects:
                continue
            try:
                shader = material_state["shader"]
                shader.bind()
                shader.uniform_float("solid_backing_color", material_state["backing_color"])
                for uniform_name, texture in zip(
                    material_state["texture_uniforms"], material_state["textures"]
                ):
                    shader.uniform_sampler(uniform_name, texture)
                for object_state in objects:
                    shader.uniform_float(
                        "model_view_projection",
                        view_projection @ object_state["matrix_world"],
                    )
                    object_state["composite_batch"].draw(shader)
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                try:
                    backing = material_state["backing_shader"]
                    backing.bind()
                    backing.uniform_float("backing_color", material_state["backing_color"])
                    for object_state in objects:
                        backing.uniform_float(
                            "model_view_projection",
                            view_projection @ object_state["matrix_world"],
                        )
                        object_state["backing_batch"].draw(backing)
                except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                    continue
    finally:
        _restore_gpu_state(gpu, captured)

def _tag_view3d() -> None:
    try:
        for window in list(getattr(bpy.context.window_manager, "windows", ()) or ()):
            if not _manager_rule_api.workspace_runtime_allowed(
                bpy.context,
                workspace=getattr(window, "workspace", None),
            ):
                continue
            screen = getattr(window, "screen", None)
            for area in list(getattr(screen, "areas", ()) or ()):
                if str(getattr(area, "type", "") or "") == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


def _should_register() -> bool:
    return bool(_refresh_active_display_materials())


def _ensure_handler() -> None:
    global _HANDLE
    if _HANDLE is not None:
        return
    from .. import runtime_registry
    handle = bpy.types.SpaceView3D.draw_handler_add(
        _draw_overlay, (), "WINDOW", "POST_VIEW",
    )
    try:
        runtime_registry.track_draw_handler(
            bpy.types.SpaceView3D.draw_handler_remove, handle, "WINDOW",
            label="solid_view_overlay",
        )
    except Exception:
        bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
        raise
    _HANDLE = handle


def _remove_handler() -> None:
    global _HANDLE
    handle = _HANDLE
    _HANDLE = None
    if handle is None:
        return
    from .. import runtime_registry
    runtime_registry.untrack_draw_handler(handle, remove=True)


def clear_geometry_cache() -> None:
    """Invalidate the current snapshot after an explicit geometry/UV change."""
    _clear_draw_snapshot()
    if _RUNTIME_REQUESTED and _ACTIVE_DISPLAY_MATERIAL_NAMES:
        _schedule_rebuild(0.01)


def _report_dormant_skip_once(stage: str) -> None:
    """One console line per dormancy episode; lifecycle callbacks stay silent after that."""
    global _DORMANT_REPORTED
    if _DORMANT_REPORTED:
        return
    _DORMANT_REPORTED = True
    try:
        print(
            "[Smart Paint] solid view overlay skipped at "
            + str(stage)
            + ": no READY runtime generation (display resumes after re-enable)"
        )
    except Exception:
        pass


def sync_handler_state() -> None:
    global _DORMANT_REPORTED
    active = _refresh_active_display_materials() if _RUNTIME_REQUESTED else ()
    if active:
        from .. import runtime_registry
        if not runtime_registry.ensure_runtime_ready():
            # Reading the ledger already re-armed a generation that merely
            # lost its driver_namespace slot to a file load.  Reaching this
            # branch means the registry is legitimately dormant (mid-teardown
            # or failed enable): displaying is impossible, so skip quietly --
            # never raise out of a lifecycle callback -- and report once.
            _report_dormant_skip_once("sync_handler_state")
            return
        _DORMANT_REPORTED = False
        _cancel_sync_timer()
        _ensure_handlers()
        if _file_boundary_active():
            _remove_handler()
            _clear_draw_snapshot()
        else:
            _ensure_handler()
            # Explicit operator/property changes get one immediate rebuild.  A
            # one-shot timer is only a fallback when the current context cannot
            # supply a depsgraph/GPU resource at that exact moment.
            if not _rebuild_draw_snapshot_now():
                _schedule_rebuild(0.01)
    else:
        _remove_handler()
        _remove_handlers()
        _cancel_rebuild_timer()
        _cancel_sync_timer()
        _clear_draw_snapshot()
    _tag_view3d()


@persistent
def _boundary_pre(*_args):
    global _BOUNDARY_DEPTH, _BOUNDARY_READY_AFTER
    _BOUNDARY_DEPTH += 1
    _BOUNDARY_READY_AFTER = float("inf")
    # Same persistent-handler contract as _boundary_post: teardown problems
    # are contained and reported once, never raised into Blender's handler
    # loop where they would repeat on every save/undo/load boundary.
    try:
        _remove_handler()
        _cancel_rebuild_timer()
        _cancel_sync_timer()
        _cancel_boundary_resume_timer()
    except Exception as exc:
        _report_dormant_skip_once(f"_boundary_pre:{type(exc).__name__}")
    _clear_draw_snapshot()


@persistent
def _boundary_post(*_args):
    global _BOUNDARY_DEPTH, _BOUNDARY_READY_AFTER
    _BOUNDARY_DEPTH = max(0, int(_BOUNDARY_DEPTH) - 1)
    if _BOUNDARY_DEPTH > 0:
        return
    _BOUNDARY_READY_AFTER = 0.0
    if not _RUNTIME_REQUESTED:
        return
    # The lifecycle event itself is the wake-up.  Rebuild once now; no delayed resume
    # resume poll or repeating retry remains registered after this callback.
    # A persistent handler must never raise: Blender would print the traceback
    # on every boundary and skip nothing else this suite owns, but user-facing
    # console spam and handler-order side effects are still a defect
    # (reproduced on 1.9.289: RegistrationError out of undo_post/save_post).
    try:
        sync_handler_state()
    except Exception as exc:
        _report_dormant_skip_once(f"_boundary_post:{type(exc).__name__}")


def _boundary_resume_tick():
    """Compatibility one-shot target retained for old journal identities."""
    return None

@persistent
def _depsgraph_update(_scene, depsgraph):
    """Debounce only geometry/material changes while the overlay is active."""
    if not _RUNTIME_REQUESTED or _file_boundary_active():
        return
    if not _active_display_materials(getattr(bpy, "context", None)):
        # Do not mutate Blender handler lists from inside their own callback.
        # Empty the snapshot immediately, then remove all resources once on the
        # next main-loop turn.
        _clear_draw_snapshot()
        _schedule_sync(0.01)
        return
    relevant = False
    try:
        relevant_types = (
            bpy.types.Object,
            bpy.types.Mesh,
            bpy.types.Material,
            bpy.types.Collection,
            bpy.types.Scene,
        )
        for update in tuple(getattr(depsgraph, "updates", ()) or ()):
            if isinstance(getattr(update, "id", None), relevant_types):
                relevant = True
                break
    except Exception:
        relevant = True
    if relevant:
        _schedule_rebuild(0.05)


def _handler_pairs():
    pairs = [
        (bpy.app.handlers.load_pre, _boundary_pre),
        (bpy.app.handlers.load_post, _boundary_post),
        (bpy.app.handlers.save_pre, _boundary_pre),
        (bpy.app.handlers.save_post, _boundary_post),
        (bpy.app.handlers.depsgraph_update_post, _depsgraph_update),
    ]
    for name in ("undo_pre", "redo_pre"):
        handlers = getattr(bpy.app.handlers, name, None)
        if handlers is not None:
            pairs.append((handlers, _boundary_pre))
    for name in ("undo_post", "redo_post"):
        handlers = getattr(bpy.app.handlers, name, None)
        if handlers is not None:
            pairs.append((handlers, _boundary_post))
    return tuple(pairs)


def _ensure_handlers() -> None:
    from .. import runtime_registry
    for handlers, callback in _handler_pairs():
        if callback not in handlers:
            runtime_registry.add_handler(
                handlers, callback, label=f"solid_overlay.{callback.__name__}",
            )


def _remove_handlers() -> None:
    from .. import runtime_registry
    for handlers, callback in _handler_pairs():
        runtime_registry.remove_handler(handlers, callback)


def register_runtime(transaction) -> None:
    global _RUNTIME_REQUESTED, _BOUNDARY_DEPTH, _BOUNDARY_READY_AFTER, _DORMANT_REPORTED
    _RUNTIME_REQUESTED = True
    _BOUNDARY_DEPTH = 0
    _BOUNDARY_READY_AFTER = 0.0
    _DORMANT_REPORTED = False
    # Registration is resource-free.  Exact handlers/draw/timers are acquired
    # only after an explicit display request or a post-load restore.
    transaction.add_cleanup(unregister_runtime, label="solid_view_overlay.reset")


def unregister_runtime() -> None:
    global _ACTIVE_DISPLAY_MATERIAL_NAMES, _BACKING_SHADER
    global _RUNTIME_REQUESTED, _BOUNDARY_DEPTH, _BOUNDARY_READY_AFTER, _DORMANT_REPORTED
    _RUNTIME_REQUESTED = False
    _BOUNDARY_DEPTH = 0
    _BOUNDARY_READY_AFTER = 0.0
    _DORMANT_REPORTED = False
    _remove_handler()
    _remove_handlers()
    _cancel_rebuild_timer()
    _cancel_sync_timer()
    _cancel_boundary_resume_timer()
    _ACTIVE_DISPLAY_MATERIAL_NAMES = ()
    _clear_draw_snapshot()
    _BACKING_SHADER = None
    _tag_view3d()
