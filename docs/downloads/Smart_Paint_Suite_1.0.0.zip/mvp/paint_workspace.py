# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Non-destructive object paint-material and UV workspace.

The user's functional material graph is not replaced.  An object-local
material-slot override exposes a dedicated Smart Paint material while exact
slot, UV, mode and graph-edge provenance is retained for restoration.  The
cycle-scoped provenance is Undo-tracked and removed after restore.  No timer,
handler, or background scan is used.
"""


import json
import time
import uuid
from typing import Any

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)


OBJECT_PROPERTY = "smart_paint_workspace"
TEMP_MATERIAL_TAG = "sps_temporary_paint_material"
TEMP_OWNER_TAG = "sps_temporary_paint_owner_token"
TEMP_UV_NODE = "SPS_TemporaryPaintUV"
RESTORE_PROVENANCE_PREFIX = "sps_restore_"

_UV_UPDATE_GUARD: set[int] = set()
_ORIGINAL_GRAPH_SNAPSHOTS: dict[str, tuple[dict[str, Any], ...]] = {}
_OWNED_NODE_MARKERS = (
    TEMP_MATERIAL_TAG,
    "sps_mvp_live_composite_node",
    "sps_mvp_live_composite_aux_node",
    "sps_lightweight_active_display",
    "sps_lightweight_manual_composite_display",
    "sps_master_display_node",
)


def _trace(event: str, *, material=None, **payload: Any) -> None:
    try:
        from .. import save_trace

        save_trace.emit(str(event or ""), material=material, channel="BASE_COLOR", **payload)
    except Exception:
        pass


def _object_from_state(state, context=None):
    owner = getattr(state, "id_data", None)
    if isinstance(owner, bpy.types.Object):
        return owner
    ctx = context or getattr(bpy, "context", None)
    return getattr(ctx, "object", None) if ctx is not None else None


def state_for_object(obj):
    if obj is None:
        return None
    try:
        return getattr(obj, OBJECT_PROPERTY, None)
    except Exception:
        return None


def _pointer(value) -> int:
    try:
        native = int(value.as_pointer())
        return native if native > 0 else 0
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError, OverflowError):
        return 0


def _socket_default(socket):
    try:
        value = socket.default_value
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    try:
        return tuple(float(item) for item in value)
    except (TypeError, ValueError, ReferenceError):
        return None


def _graph_signature(material) -> dict[str, Any]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return {"use_nodes": bool(getattr(material, "use_nodes", False)), "nodes": (), "links": ()}
    nodes = []
    for node in tuple(tree.nodes):
        nodes.append((
            _pointer(node),
            str(getattr(node, "name", "") or ""),
            str(getattr(node, "bl_idname", "") or getattr(node, "type", "") or ""),
            tuple((str(getattr(socket, "name", "") or ""), _socket_default(socket)) for socket in getattr(node, "inputs", ())),
        ))
    links = []
    for link in tuple(tree.links):
        links.append((
            _pointer(getattr(link, "from_node", None)),
            str(getattr(getattr(link, "from_socket", None), "name", "") or ""),
            _pointer(getattr(link, "to_node", None)),
            str(getattr(getattr(link, "to_socket", None), "name", "") or ""),
        ))
    return {
        "use_nodes": bool(getattr(material, "use_nodes", False)),
        "nodes": tuple(sorted(nodes, key=lambda row: (row[0], row[1]))),
        "links": tuple(sorted(links)),
    }


def _socket_index(sockets, target) -> int:
    target_pointer = _pointer(target)
    for index, socket in enumerate(tuple(sockets or ())):
        if socket is target or (target_pointer > 0 and _pointer(socket) == target_pointer):
            return int(index)
    return -1


def _capture_link_records(material) -> tuple[dict[str, Any], ...]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return ()
    rows = []
    for link in tuple(tree.links):
        from_node = getattr(link, "from_node", None)
        to_node = getattr(link, "to_node", None)
        from_socket = getattr(link, "from_socket", None)
        to_socket = getattr(link, "to_socket", None)
        rows.append({
            "from_node_pointer": _pointer(from_node),
            "from_socket_pointer": _pointer(from_socket),
            "from_socket_index": _socket_index(getattr(from_node, "outputs", ()), from_socket),
            "from_socket_name": str(getattr(from_socket, "name", "") or ""),
            "to_node_pointer": _pointer(to_node),
            "to_socket_pointer": _pointer(to_socket),
            "to_socket_index": _socket_index(getattr(to_node, "inputs", ()), to_socket),
            "to_socket_name": str(getattr(to_socket, "name", "") or ""),
        })
    return tuple(rows)


def _socket_identity(sockets, target) -> dict[str, Any]:
    return {
        "identifier": str(getattr(target, "identifier", "") or ""),
        "index": _socket_index(sockets, target),
        "name": str(getattr(target, "name", "") or ""),
    }


def _provenance_materials(state) -> tuple[Any, ...]:
    materials = []
    seen = set()
    for slot in getattr(state, "original_slots", ()) or ():
        material = getattr(slot, "material", None)
        identity = _pointer(material)
        if material is None or identity <= 0 or identity in seen:
            continue
        seen.add(identity)
        materials.append(material)
    return tuple(materials)


def _new_provenance_key(materials) -> str:
    for _attempt in range(16):
        key = RESTORE_PROVENANCE_PREFIX + uuid.uuid4().hex[:20]
        collision = False
        for material in materials:
            tree = getattr(material, "node_tree", None)
            try:
                collision = key in material or any(key in node for node in tuple(getattr(tree, "nodes", ()) or ()))
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                collision = True
            if collision:
                break
        if not collision:
            return key
    return ""


def _capture_undo_provenance(state, materials) -> None:
    key = _new_provenance_key(materials)
    payload = {"version": 1, "key": key, "materials": []}
    if not key:
        state.graph_restore_key = ""
        state.graph_restore_json = ""
        return
    for material in materials:
        tree = getattr(material, "node_tree", None)
        material_tag = "material:" + uuid.uuid4().hex
        tagged_nodes = []
        try:
            material[key] = material_tag
            node_rows = []
            node_tags = {}
            for node in tuple(getattr(tree, "nodes", ()) or ()):
                node_tag = "node:" + uuid.uuid4().hex
                node[key] = node_tag
                tagged_nodes.append(node)
                node_tags[_pointer(node)] = node_tag
                node_rows.append({
                    "tag": node_tag,
                    "type": str(getattr(node, "bl_idname", "") or getattr(node, "type", "") or ""),
                })
            link_rows = []
            for link in tuple(getattr(tree, "links", ()) or ()):
                from_node = getattr(link, "from_node", None)
                to_node = getattr(link, "to_node", None)
                from_tag = node_tags.get(_pointer(from_node), "")
                to_tag = node_tags.get(_pointer(to_node), "")
                if not from_tag or not to_tag:
                    continue
                link_rows.append({
                    "from_node": from_tag,
                    "from_socket": _socket_identity(getattr(from_node, "outputs", ()), getattr(link, "from_socket", None)),
                    "to_node": to_tag,
                    "to_socket": _socket_identity(getattr(to_node, "inputs", ()), getattr(link, "to_socket", None)),
                })
            payload["materials"].append({
                "tag": material_tag,
                "nodes": node_rows,
                "links": link_rows,
            })
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            for node in tagged_nodes:
                try:
                    if key in node:
                        del node[key]
                except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                    pass
            try:
                if key in material:
                    del material[key]
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                pass
    state.graph_restore_key = key
    state.graph_restore_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _load_undo_provenance(state):
    key = str(getattr(state, "graph_restore_key", "") or "")
    raw = str(getattr(state, "graph_restore_json", "") or "")
    if not key or not raw.startswith("{"):
        return None
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if payload.get("version") != 1 or str(payload.get("key", "") or "") != key or not isinstance(payload.get("materials"), list):
        return None
    return payload


def _retire_provenance_tags(state) -> None:
    payload = _load_undo_provenance(state)
    if payload is None:
        return
    key = str(payload["key"])
    for material in _provenance_materials(state):
        tree = getattr(material, "node_tree", None)
        for node in tuple(getattr(tree, "nodes", ()) or ()):
            try:
                if key in node:
                    del node[key]
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                pass
        try:
            if key in material:
                del material[key]
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass


def _capture_original_graphs(state) -> None:
    token = str(getattr(state, "owner_token", "") or "")
    if not token:
        return
    rows = []
    seen = set()
    for slot in getattr(state, "original_slots", ()) or ():
        material = getattr(slot, "material", None)
        identity = _pointer(material)
        if material is None or identity <= 0 or identity in seen:
            continue
        seen.add(identity)
        signature = _graph_signature(material)
        rows.append({
            "material": material,
            "material_pointer": identity,
            "node_pointers": frozenset(row[0] for row in signature["nodes"] if row[0] > 0),
            "links": _capture_link_records(material),
            "signature": signature,
        })
    _ORIGINAL_GRAPH_SNAPSHOTS[token] = tuple(rows)
    _capture_undo_provenance(state, tuple(row["material"] for row in rows))


def _node_is_owned(node) -> bool:
    for marker in _OWNED_NODE_MARKERS:
        try:
            if bool(node.get(marker, False)):
                return True
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    return False


def _remove_owned_nodes(material, *, protected=()) -> int:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return 0
    protected_pointers = frozenset(int(value) for value in protected if int(value) > 0)
    removed = 0
    for node in tuple(tree.nodes):
        if _pointer(node) in protected_pointers or not _node_is_owned(node):
            continue
        try:
            tree.nodes.remove(node)
            removed += 1
        except (ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    return int(removed)


def _find_native(items, native_pointer: int):
    if native_pointer <= 0:
        return None
    for item in tuple(items or ()):
        if _pointer(item) == native_pointer:
            return item
    return None


def _find_snapshot_socket(node, collection_name: str, native_pointer: int, index: int, name: str):
    sockets = tuple(getattr(node, collection_name, ()) or ())
    found = _find_native(sockets, native_pointer)
    if found is not None:
        return found
    if 0 <= int(index) < len(sockets):
        candidate = sockets[int(index)]
        if str(getattr(candidate, "name", "") or "") == str(name or ""):
            return candidate
    matches = [socket for socket in sockets if str(getattr(socket, "name", "") or "") == str(name or "")]
    return matches[0] if len(matches) == 1 else None


def _snapshot_target_key(row) -> tuple[int, int, int, str]:
    return (
        int(row["to_node_pointer"]),
        int(row["to_socket_pointer"]),
        int(row["to_socket_index"]),
        str(row["to_socket_name"]),
    )


def _owned_displaced_targets(material, *, protected=()) -> frozenset[tuple[int, int, int, str]]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return frozenset()
    protected_pointers = frozenset(int(value) for value in protected if int(value) > 0)
    owned = {
        _pointer(node)
        for node in tuple(tree.nodes)
        if _pointer(node) not in protected_pointers and _node_is_owned(node)
    }
    targets = set()
    for link in tuple(tree.links):
        if _pointer(getattr(link, "from_node", None)) not in owned:
            continue
        to_node = getattr(link, "to_node", None)
        to_socket = getattr(link, "to_socket", None)
        targets.add((
            _pointer(to_node),
            _pointer(to_socket),
            _socket_index(getattr(to_node, "inputs", ()), to_socket),
            str(getattr(to_socket, "name", "") or ""),
        ))
    return frozenset(targets)


def _restore_snapshot_links(material, snapshot, displaced_targets) -> dict[str, int]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return {"links_restored": 0, "link_conflicts_preserved": 0, "link_endpoints_missing": 0, "links_not_owned_displacement": 0}
    restored = 0
    conflicts = 0
    missing = 0
    not_owned = 0
    for row in snapshot.get("links", ()):
        if _snapshot_target_key(row) not in displaced_targets:
            not_owned += 1
            continue
        from_node = _find_native(tree.nodes, int(row["from_node_pointer"]))
        to_node = _find_native(tree.nodes, int(row["to_node_pointer"]))
        if from_node is None or to_node is None:
            missing += 1
            continue
        from_socket = _find_snapshot_socket(
            from_node,
            "outputs",
            int(row["from_socket_pointer"]),
            int(row["from_socket_index"]),
            str(row["from_socket_name"]),
        )
        to_socket = _find_snapshot_socket(
            to_node,
            "inputs",
            int(row["to_socket_pointer"]),
            int(row["to_socket_index"]),
            str(row["to_socket_name"]),
        )
        if from_socket is None or to_socket is None:
            missing += 1
            continue
        target_pointer = _pointer(to_socket)
        source_pointer = _pointer(from_socket)
        inbound = [
            link
            for link in tuple(tree.links)
            if getattr(link, "to_socket", None) is to_socket
            or (target_pointer > 0 and _pointer(getattr(link, "to_socket", None)) == target_pointer)
        ]
        if any(
            getattr(link, "from_socket", None) is from_socket
            or (source_pointer > 0 and _pointer(getattr(link, "from_socket", None)) == source_pointer)
            for link in inbound
        ):
            continue
        if inbound and not bool(getattr(to_socket, "is_multi_input", False)):
            conflicts += 1
            continue
        try:
            tree.links.new(from_socket, to_socket)
            restored += 1
        except (ReferenceError, RuntimeError, TypeError, ValueError):
            missing += 1
    return {
        "links_restored": int(restored),
        "link_conflicts_preserved": int(conflicts),
        "link_endpoints_missing": int(missing),
        "links_not_owned_displacement": int(not_owned),
    }


def _tag_value(value, key: str) -> str:
    try:
        return str(value.get(key, "") or "")
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return ""


def _find_tagged(items, key: str, tag: str):
    matches = [item for item in tuple(items or ()) if _tag_value(item, key) == tag]
    return matches[0] if len(matches) == 1 else None


def _find_stable_socket(node, collection_name: str, record):
    sockets = tuple(getattr(node, collection_name, ()) or ())
    identifier = str(record.get("identifier", "") or "")
    if identifier:
        matches = [socket for socket in sockets if str(getattr(socket, "identifier", "") or "") == identifier]
        if len(matches) == 1:
            return matches[0]
    index = int(record.get("index", -1) or -1)
    name = str(record.get("name", "") or "")
    if 0 <= index < len(sockets):
        candidate = sockets[index]
        if str(getattr(candidate, "name", "") or "") == name:
            return candidate
    matches = [socket for socket in sockets if str(getattr(socket, "name", "") or "") == name]
    return matches[0] if name and len(matches) == 1 else None


def _stable_target_key(node_tag: str, socket_record) -> tuple[str, str, int, str]:
    return (
        str(node_tag or ""),
        str(socket_record.get("identifier", "") or ""),
        int(socket_record.get("index", -1) or -1),
        str(socket_record.get("name", "") or ""),
    )


def _owned_displaced_targets_stable(material, key: str, protected_tags) -> frozenset[tuple[str, str, int, str]]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return frozenset()
    protected = frozenset(str(value) for value in protected_tags)
    owned_pointers = {
        _pointer(node)
        for node in tuple(tree.nodes)
        if _tag_value(node, key) not in protected and _node_is_owned(node)
    }
    targets = set()
    for link in tuple(tree.links):
        if _pointer(getattr(link, "from_node", None)) not in owned_pointers:
            continue
        to_node = getattr(link, "to_node", None)
        to_tag = _tag_value(to_node, key)
        if to_tag not in protected:
            continue
        targets.add(_stable_target_key(
            to_tag,
            _socket_identity(getattr(to_node, "inputs", ()), getattr(link, "to_socket", None)),
        ))
    return frozenset(targets)


def _restore_stable_links(material, material_record, key: str, displaced_targets) -> dict[str, int]:
    tree = getattr(material, "node_tree", None) if material is not None else None
    if tree is None:
        return {"links_restored": 0, "link_conflicts_preserved": 0, "link_endpoints_missing": 0, "links_not_owned_displacement": 0}
    restored = 0
    conflicts = 0
    missing = 0
    not_owned = 0
    for row in material_record.get("links", ()):
        if _stable_target_key(str(row.get("to_node", "") or ""), row.get("to_socket", {})) not in displaced_targets:
            not_owned += 1
            continue
        from_node = _find_tagged(tree.nodes, key, str(row.get("from_node", "") or ""))
        to_node = _find_tagged(tree.nodes, key, str(row.get("to_node", "") or ""))
        if from_node is None or to_node is None:
            missing += 1
            continue
        from_socket = _find_stable_socket(from_node, "outputs", row.get("from_socket", {}))
        to_socket = _find_stable_socket(to_node, "inputs", row.get("to_socket", {}))
        if from_socket is None or to_socket is None:
            missing += 1
            continue
        inbound = [link for link in tuple(tree.links) if getattr(link, "to_socket", None) is to_socket]
        if any(getattr(link, "from_socket", None) is from_socket for link in inbound):
            continue
        if inbound and not bool(getattr(to_socket, "is_multi_input", False)):
            conflicts += 1
            continue
        try:
            tree.links.new(from_socket, to_socket)
            restored += 1
        except (ReferenceError, RuntimeError, TypeError, ValueError):
            missing += 1
    return {
        "links_restored": int(restored),
        "link_conflicts_preserved": int(conflicts),
        "link_endpoints_missing": int(missing),
        "links_not_owned_displacement": int(not_owned),
    }


def _cleanup_from_undo_provenance(state, payload) -> dict[str, Any]:
    key = str(payload["key"])
    materials = _provenance_materials(state)
    removed = 0
    links_restored = 0
    link_conflicts = 0
    link_missing = 0
    links_not_owned = 0
    ambiguous = 0
    matched = 0
    for record in payload.get("materials", ()):
        material = _find_tagged(materials, key, str(record.get("tag", "") or ""))
        if material is None:
            ambiguous += 1
            continue
        matched += 1
        tree = getattr(material, "node_tree", None)
        protected_tags = frozenset(str(row.get("tag", "") or "") for row in record.get("nodes", ()))
        if not _is_managed_material(material):
            protected_pointers = frozenset(
                _pointer(node)
                for node in tuple(getattr(tree, "nodes", ()) or ())
                if _tag_value(node, key) in protected_tags
            )
            displaced = _owned_displaced_targets_stable(material, key, protected_tags)
            removed += _remove_owned_nodes(material, protected=protected_pointers)
            link_result = _restore_stable_links(material, record, key, displaced)
            links_restored += link_result["links_restored"]
            link_conflicts += link_result["link_conflicts_preserved"]
            link_missing += link_result["link_endpoints_missing"]
            links_not_owned += link_result["links_not_owned_displacement"]
    _retire_provenance_tags(state)
    return {
        "materials": len(materials),
        "snapshot_materials": len(payload.get("materials", ())),
        "matched_snapshot_materials": int(matched),
        "owned_nodes_removed": int(removed),
        "exact_graph_matches": 0,
        "user_changed_graphs_preserved": int(link_conflicts + link_missing + links_not_owned),
        "links_restored": int(links_restored),
        "link_conflicts_preserved": int(link_conflicts),
        "link_endpoints_missing": int(link_missing),
        "links_not_owned_displacement": int(links_not_owned),
        "ambiguous_materials_preserved": int(ambiguous),
        "provenance": "UNDO_TRACKED_STABLE_TAGS",
    }


def _cleanup_restored_original_graphs(state) -> dict[str, Any]:
    persisted = _load_undo_provenance(state)
    if persisted is not None:
        return _cleanup_from_undo_provenance(state, persisted)
    token = str(getattr(state, "owner_token", "") or "")
    snapshots = _ORIGINAL_GRAPH_SNAPSHOTS.get(token, ())
    by_pointer = {int(row["material_pointer"]): row for row in snapshots}
    materials = []
    seen = set()
    for slot in getattr(state, "original_slots", ()) or ():
        material = getattr(slot, "material", None)
        identity = _pointer(material)
        if material is None or identity <= 0 or identity in seen:
            continue
        seen.add(identity)
        materials.append(material)
    removed = 0
    exact_matches = 0
    preserved_user_changes = 0
    links_restored = 0
    link_conflicts_preserved = 0
    link_endpoints_missing = 0
    links_not_owned_displacement = 0
    ambiguous_materials = 0
    for material in materials:
        identity = _pointer(material)
        snapshot = by_pointer.get(identity)
        if snapshot is None:
            ambiguous_materials += 1
            continue
        if not _is_managed_material(material):
            protected = snapshot.get("node_pointers", ())
            displaced_targets = _owned_displaced_targets(material, protected=protected)
            removed += _remove_owned_nodes(material, protected=protected)
            link_result = _restore_snapshot_links(material, snapshot, displaced_targets)
            links_restored += link_result["links_restored"]
            link_conflicts_preserved += link_result["link_conflicts_preserved"]
            link_endpoints_missing += link_result["link_endpoints_missing"]
            links_not_owned_displacement += link_result["links_not_owned_displacement"]
        if _graph_signature(material) == snapshot["signature"]:
            exact_matches += 1
        else:
            preserved_user_changes += 1
    return {
        "materials": len(materials),
        "snapshot_materials": len(snapshots),
        "owned_nodes_removed": int(removed),
        "exact_graph_matches": int(exact_matches),
        "user_changed_graphs_preserved": int(preserved_user_changes),
        "links_restored": int(links_restored),
        "link_conflicts_preserved": int(link_conflicts_preserved),
        "link_endpoints_missing": int(link_endpoints_missing),
        "links_not_owned_displacement": int(links_not_owned_displacement),
        "ambiguous_materials_preserved": int(ambiguous_materials),
    }


def _temporary_material_external_slots(material, *, exclude_object=None) -> int:
    count = 0
    for obj in tuple(getattr(getattr(bpy, "data", None), "objects", ()) or ()):
        if obj is exclude_object:
            continue
        for slot in tuple(getattr(obj, "material_slots", ()) or ()):
            try:
                if getattr(slot, "material", None) is material:
                    count += 1
            except (AttributeError, ReferenceError, RuntimeError):
                continue
    return int(count)


def _cleanup_temporary_material(material, state) -> dict[str, Any]:
    token = str(getattr(state, "owner_token", "") or "")
    try:
        exact_owner = bool(
            material is not None
            and bool(material.get(TEMP_MATERIAL_TAG, False))
            and str(material.get(TEMP_OWNER_TAG, "") or "") == token
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        exact_owner = False
    if not exact_owner:
        return {"exact_owner": False, "material_retained": True, "owned_nodes_removed": 0, "external_slots": 0}
    external_slots = _temporary_material_external_slots(material)
    settings = getattr(material, "smart_paint_suite", None)
    authored_layers = len(getattr(settings, "layers", ()) or ()) if settings is not None else 0
    return {
        "exact_owner": True,
        "material_retained": True,
        "owned_nodes_removed": 0,
        "external_slots": int(external_slots),
        "authored_layers": int(authored_layers),
    }


def _uv_layers(obj):
    if obj is None or str(getattr(obj, "type", "") or "") != "MESH":
        return None
    return getattr(getattr(obj, "data", None), "uv_layers", None)


def _uv_index(uv_layers, name: str) -> int:
    target = str(name or "")
    if uv_layers is None or not target:
        return -1
    for index, layer in enumerate(uv_layers):
        if str(getattr(layer, "name", "") or "") == target:
            return int(index)
    return -1


def _active_uv_name(obj) -> str:
    uv_layers = _uv_layers(obj)
    active = getattr(uv_layers, "active", None) if uv_layers is not None else None
    return str(getattr(active, "name", "") or "")


def _render_uv_name(obj) -> str:
    uv_layers = _uv_layers(obj)
    if uv_layers is None:
        return ""
    for layer in uv_layers:
        try:
            if bool(getattr(layer, "active_render", False)):
                return str(getattr(layer, "name", "") or "")
        except Exception:
            continue
    return ""


def _set_selected_uv_silent(obj, state, name: str) -> None:
    if obj is None or state is None:
        return
    key = int(obj.as_pointer())
    _UV_UPDATE_GUARD.add(key)
    try:
        state.selected_uv = str(name or "")
    finally:
        _UV_UPDATE_GUARD.discard(key)


def _is_managed_material(material) -> bool:
    if material is None:
        return False
    try:
        if bool(material.get(TEMP_MATERIAL_TAG, False)):
            return True
    except Exception:
        pass
    try:
        settings = getattr(material, "smart_paint_suite", None)
        if settings is not None and bool(getattr(settings, "managed", False)):
            return True
    except Exception:
        pass
    for key in (
        "sps_texture_path_BASE_COLOR",
        "sps_source_psd_path_BASE_COLOR",
        "sps_lightweight_document_kind",
    ):
        try:
            if material.get(key):
                return True
        except Exception:
            continue
    return False


def _sync_material_uv_nodes(material, uv_name: str) -> int:
    """Route every image in the add-on-owned paint material through one UV."""
    if material is None or not uv_name:
        return 0
    try:
        if not bool(material.get(TEMP_MATERIAL_TAG, False)):
            return 0
        material.use_nodes = True
        tree = getattr(material, "node_tree", None)
        if tree is None:
            return 0
        uv_node = tree.nodes.get(TEMP_UV_NODE)
        if uv_node is None or str(getattr(uv_node, "type", "") or "") != "UVMAP":
            if uv_node is not None:
                tree.nodes.remove(uv_node)
            uv_node = tree.nodes.new("ShaderNodeUVMap")
            uv_node.name = TEMP_UV_NODE
            uv_node.label = "Smart Paint UV"
            uv_node.location = (-900.0, -120.0)
        uv_node.uv_map = str(uv_name)
        uv_node[TEMP_MATERIAL_TAG] = True
        changed = 0
        for node in tuple(tree.nodes):
            if str(getattr(node, "type", "") or "") != "TEX_IMAGE":
                continue
            vector = node.inputs.get("Vector")
            output = uv_node.outputs.get("UV") if hasattr(uv_node.outputs, "get") else None
            if vector is None or output is None:
                continue
            links = list(getattr(vector, "links", ()) or ())
            if len(links) == 1 and getattr(links[0], "from_node", None) == uv_node:
                continue
            for link in links:
                try:
                    tree.links.remove(link)
                except Exception:
                    pass
            try:
                tree.links.new(output, vector)
                changed += 1
            except Exception:
                pass
        try:
            tree.update_tag()
            material.update_tag()
        except Exception:
            pass
        return int(changed)
    except Exception:
        return 0


def apply_uv(obj, uv_name: str, *, material=None) -> dict[str, Any]:
    started = time.perf_counter()
    uv_layers = _uv_layers(obj)
    if uv_layers is None:
        return {"ok": False, "reason": "uv_layers_unsupported"}
    index = _uv_index(uv_layers, uv_name)
    if index < 0:
        return {"ok": False, "reason": "uv_layer_missing", "uv": str(uv_name or "")}
    try:
        uv_layers.active_index = int(index)
    except Exception as exc:
        return {"ok": False, "reason": "uv_active_failed", "error": repr(exc)[:300]}
    render_ok = False
    for layer_index, layer in enumerate(uv_layers):
        try:
            layer.active_render = bool(layer_index == index)
            if layer_index == index:
                render_ok = bool(layer.active_render)
        except Exception:
            continue
    target = material
    state = state_for_object(obj)
    if target is None and state is not None and bool(getattr(state, "active", False)):
        target = getattr(state, "paint_material", None)
    if target is None:
        active_material = getattr(obj, "active_material", None)
        if _is_managed_material(active_material):
            target = active_material
    node_links = 0
    if target is not None and _is_managed_material(target):
        try:
            target["sps_target_uv_map"] = str(uv_name)
            target["sps_temporary_paint_uv"] = str(uv_name)
        except Exception:
            pass
        try:
            settings = getattr(target, "smart_paint_suite", None)
            if settings is not None:
                settings.default_uv_map = str(uv_name)
                if bool(target.get(TEMP_MATERIAL_TAG, False)):
                    for layer in getattr(settings, "layers", ()) or ():
                        try:
                            layer.uv_map = str(uv_name)
                        except Exception:
                            pass
        except Exception:
            pass
        node_links = _sync_material_uv_nodes(target, str(uv_name))
    result = {
        "ok": True,
        "reason": "uv_selected",
        "uv": str(uv_name),
        "active_index": int(index),
        "active": _active_uv_name(obj),
        "render": _render_uv_name(obj),
        "render_ok": bool(render_ok),
        "node_links_changed": int(node_links),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    _trace("temporary_paint_uv_selected", material=target, object=str(getattr(obj, "name", "") or ""), **result)
    return result


def synchronize(context=None, material=None) -> dict[str, Any]:
    ctx = context or getattr(bpy, "context", None)
    obj = getattr(ctx, "object", None) if ctx is not None else None
    state = state_for_object(obj)
    if obj is None or state is None:
        return {"ok": False, "reason": "object_state_missing"}
    if not bool(getattr(state, "active", False)):
        return {"ok": False, "reason": "temporary_paint_not_active"}
    target = getattr(state, "paint_material", None)
    if material is not None and target is not material:
        return {"ok": False, "reason": "material_not_temporary_target"}
    if target is None:
        return {"ok": False, "reason": "temporary_paint_material_missing"}
    name = str(getattr(state, "selected_uv", "") or "")
    if _uv_index(_uv_layers(obj), name) < 0:
        name = _active_uv_name(obj)
        if not name:
            uv_layers = _uv_layers(obj)
            name = str(getattr(uv_layers[0], "name", "") or "") if uv_layers and len(uv_layers) else ""
        _set_selected_uv_silent(obj, state, name)
    if not name:
        return {"ok": False, "reason": "uv_layer_missing"}
    return apply_uv(obj, name, material=target)


def _selected_uv_update(state, context) -> None:
    obj = _object_from_state(state, context)
    if obj is None:
        return
    key = int(obj.as_pointer())
    if key in _UV_UPDATE_GUARD:
        return
    uv_name = str(getattr(state, "selected_uv", "") or "")
    if not uv_name:
        return
    if not bool(getattr(state, "active", False)):
        # Merely choosing the future paint UV must never mutate the user's
        # current material or mesh state. Direct managed-material workflows
        # can still commit the staged choice with the explicit apply operator.
        state.last_error = ""
        state.last_status = _rpt("ペイント用マテリアルで使用: {}", uv_name)
        return
    material = getattr(state, "paint_material", None)
    result = apply_uv(obj, uv_name, material=material)
    if bool(result.get("ok", False)):
        state.last_error = ""
        state.last_status = _rpt("描画UV: {}", uv_name)
    else:
        state.last_error = str(result.get("reason", "uv_select_failed") or "uv_select_failed")


class SPSTemporaryMaterialSlotState(bpy.types.PropertyGroup):
    material: PointerProperty(type=bpy.types.Material)
    link: EnumProperty(
        items=(
            ("DATA", "Data", "Material stored on the mesh data"),
            ("OBJECT", "Object", "Material override stored on the object"),
        ),
        default="DATA",
    )


class SPSTemporaryPaintState(bpy.types.PropertyGroup):
    active: BoolProperty(default=False)
    paint_material: PointerProperty(type=bpy.types.Material)
    selected_uv: StringProperty(name="描画UV", default="", update=_selected_uv_update)
    original_slots: CollectionProperty(type=SPSTemporaryMaterialSlotState)
    original_slot_count: IntProperty(default=0, min=0)
    original_active_index: IntProperty(default=0, min=0)
    original_mode: StringProperty(default="OBJECT")
    original_uv_name: StringProperty(default="")
    original_render_uv_name: StringProperty(default="")
    original_canvas: PointerProperty(type=bpy.types.Image)
    original_paint_mode: StringProperty(default="IMAGE")
    created_slot: BoolProperty(default=False)
    owner_token: StringProperty(default="")
    graph_restore_key: StringProperty(default="", options={"HIDDEN"})
    graph_restore_json: StringProperty(default="", options={"HIDDEN"})
    last_status: StringProperty(default="")
    last_error: StringProperty(default="")


def _clear_restore_snapshot(state) -> None:
    _retire_provenance_tags(state)
    token = str(getattr(state, "owner_token", "") or "")
    if token:
        _ORIGINAL_GRAPH_SNAPSHOTS.pop(token, None)
    state.original_slots.clear()
    state.original_slot_count = 0
    state.original_active_index = 0
    state.original_mode = "OBJECT"
    state.original_uv_name = ""
    state.original_render_uv_name = ""
    state.original_canvas = None
    state.original_paint_mode = "IMAGE"
    state.created_slot = False
    state.graph_restore_key = ""
    state.graph_restore_json = ""


def _capture_restore_snapshot(obj, state, context=None) -> None:
    _clear_restore_snapshot(state)
    if not str(getattr(state, "owner_token", "") or ""):
        state.owner_token = uuid.uuid4().hex
    state.original_slot_count = int(len(obj.material_slots))
    state.original_active_index = int(getattr(obj, "active_material_index", 0) or 0)
    state.original_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    state.original_uv_name = _active_uv_name(obj)
    state.original_render_uv_name = _render_uv_name(obj)
    ctx = context or getattr(bpy, "context", None)
    try:
        paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
        state.original_canvas = getattr(paint, "canvas", None) if paint is not None else None
        state.original_paint_mode = str(getattr(paint, "mode", "IMAGE") or "IMAGE")
    except Exception:
        pass
    for slot in obj.material_slots:
        item = state.original_slots.add()
        item.material = getattr(slot, "material", None)
        item.link = str(getattr(slot, "link", "DATA") or "DATA")
    _capture_original_graphs(state)


def _ensure_baseline_shader(material) -> None:
    material.use_nodes = True
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return
    output = next((node for node in tree.nodes if str(getattr(node, "type", "")) == "OUTPUT_MATERIAL"), None)
    principled = next((node for node in tree.nodes if str(getattr(node, "type", "")) == "BSDF_PRINCIPLED"), None)
    if output is None:
        output = tree.nodes.new("ShaderNodeOutputMaterial")
        output.location = (300.0, 0.0)
        output[TEMP_MATERIAL_TAG] = True
    if principled is None:
        principled = tree.nodes.new("ShaderNodeBsdfPrincipled")
        principled.location = (0.0, 0.0)
        principled[TEMP_MATERIAL_TAG] = True
    surface = output.inputs.get("Surface")
    shader = principled.outputs.get("BSDF")
    if surface is not None and shader is not None and not list(getattr(surface, "links", ()) or ()):
        tree.links.new(shader, surface)


def _paint_material(obj, state):
    token = str(getattr(state, "owner_token", "") or "")
    if not token:
        token = uuid.uuid4().hex
        state.owner_token = token
    existing = getattr(state, "paint_material", None)
    try:
        if (
            existing is not None
            and bool(existing.get(TEMP_MATERIAL_TAG, False))
            and str(existing.get(TEMP_OWNER_TAG, "") or "") == token
        ):
            return existing, False
    except Exception:
        pass
    material = bpy.data.materials.new(name=f"SPS Paint - {getattr(obj, 'name', 'Object')}")
    material.use_fake_user = True
    material[TEMP_MATERIAL_TAG] = True
    material[TEMP_OWNER_TAG] = token
    material["sps_temporary_paint_owner_object"] = str(getattr(obj, "name", "") or "")
    material["sps_lightweight_mode"] = True
    try:
        material.diffuse_color = (0.8, 0.8, 0.8, 1.0)
    except Exception:
        pass
    _ensure_baseline_shader(material)
    state.paint_material = material
    return material, True


def _switch_object_mode(obj, mode: str) -> bool:
    target = str(mode or "OBJECT")
    if str(getattr(obj, "mode", "OBJECT") or "OBJECT") == target:
        return True
    try:
        bpy.ops.object.mode_set(mode=target)
        return str(getattr(obj, "mode", "") or "") == target
    except Exception:
        return False


def _invalidate_solid_geometry_cache() -> None:
    try:
        from . import solid_view_overlay

        solid_view_overlay.clear_geometry_cache()
    except Exception:
        pass


def _assign_temporary_material(obj, state, material) -> None:
    if len(obj.material_slots) == 0:
        try:
            obj.data.materials.append(None)
        except Exception:
            obj.data.materials.append(material)
        state.created_slot = True
    for slot in obj.material_slots:
        slot.link = "OBJECT"
        slot.material = material
    if not obj.material_slots or any(slot.material is not material for slot in obj.material_slots):
        raise RuntimeError("temporary_material_assignment_failed")
    obj.active_material_index = min(
        max(0, int(state.original_active_index)),
        max(0, len(obj.material_slots) - 1),
    )
    _invalidate_solid_geometry_cache()


def _restore_slots_preflight(obj, state) -> tuple[bool, str]:
    expected = int(getattr(state, "original_slot_count", 0) or 0)
    current = int(len(obj.material_slots))
    if bool(getattr(state, "created_slot", False)) and expected == 0:
        if current != 1:
            return False, "temporary_slot_count_changed"
        return True, ""
    if current != expected or len(state.original_slots) != expected:
        return False, "material_slot_count_changed"
    return True, ""


def _restore_material_slots(obj, state) -> None:
    expected = int(getattr(state, "original_slot_count", 0) or 0)
    if bool(getattr(state, "created_slot", False)) and expected == 0:
        # Blender keeps per-object MaterialSlot wrappers after Collection.pop().
        # Clear the temporary override first, expose the empty DATA slot, then
        # clear the shared mesh collection so every shared object returns to the
        # exact original zero-slot state.
        obj.material_slots[0].material = None
        obj.material_slots[0].link = "DATA"
        obj.data.materials.clear()
        _invalidate_solid_geometry_cache()
        return
    for index, saved in enumerate(state.original_slots):
        slot = obj.material_slots[index]
        link = str(getattr(saved, "link", "DATA") or "DATA")
        slot.link = link
        slot.material = getattr(saved, "material", None)
    if obj.material_slots:
        obj.active_material_index = min(
            max(0, int(state.original_active_index)),
            len(obj.material_slots) - 1,
        )
    _invalidate_solid_geometry_cache()


def _restore_uv_state(obj, state) -> None:
    uv_layers = _uv_layers(obj)
    if uv_layers is None or not len(uv_layers):
        return
    active_name = str(getattr(state, "original_uv_name", "") or "")
    active_index = _uv_index(uv_layers, active_name)
    if active_index < 0:
        active_index = 0
    try:
        uv_layers.active_index = int(active_index)
    except Exception:
        pass
    render_name = str(getattr(state, "original_render_uv_name", "") or "")
    render_index = _uv_index(uv_layers, render_name)
    for index, layer in enumerate(uv_layers):
        try:
            layer.active_render = bool(index == render_index) if render_index >= 0 else bool(index == active_index)
        except Exception:
            pass


def _quiesce_temporary_runtime(material) -> None:
    if material is None:
        return
    try:
        from . import image_editor_overlay

        image_editor_overlay.set_enabled(material, False)
    except Exception:
        pass
    try:
        from . import live_composite

        live_composite.disable(material, remove_nodes=True)
    except Exception:
        pass
    try:
        material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
    except Exception:
        pass
    try:
        from . import solid_view_overlay

        solid_view_overlay.sync_handler_state()
    except Exception:
        pass


def _fill_new_layer_with_material_color(activation, material) -> None:
    """Keep the object visible: a new document starts as a plain layer, not a transparent one."""
    import numpy as np

    from . import editing_tools

    if not bool(activation.get("ok", False)):
        return
    image = bpy.data.images.get(str(activation.get("image", "") or ""))
    if image is None:
        return
    rgb = editing_tools._linear_to_srgb(tuple(material.diffuse_color)[:3])
    pixels = np.empty((int(image.size[1]), int(image.size[0]), 4), dtype=np.uint8)
    pixels[:, :, :3] = np.clip(np.floor(rgb * 255.0 + 0.5), 0.0, 255.0)
    pixels[:, :, 3] = 255
    editing_tools._write_u8(image, pixels)


def enable(context=None) -> dict[str, Any]:
    started = time.perf_counter()
    ctx = context or getattr(bpy, "context", None)
    obj = getattr(ctx, "object", None) if ctx is not None else None
    if obj is None or str(getattr(obj, "type", "") or "") != "MESH":
        return {"ok": False, "reason": "active_mesh_missing"}
    state = state_for_object(obj)
    if state is None:
        return {"ok": False, "reason": "workspace_state_missing"}
    if bool(getattr(state, "active", False)):
        result = synchronize(ctx, getattr(state, "paint_material", None))
        result["reason"] = "temporary_paint_already_active" if result.get("ok") else result.get("reason")
        return result
    uv_layers = _uv_layers(obj)
    if uv_layers is None or not len(uv_layers):
        return {"ok": False, "reason": "uv_layer_missing"}
    selected_uv = str(getattr(state, "selected_uv", "") or "")
    if _uv_index(uv_layers, selected_uv) < 0:
        selected_uv = _active_uv_name(obj) or str(getattr(uv_layers[0], "name", "") or "")
        _set_selected_uv_silent(obj, state, selected_uv)
    _capture_restore_snapshot(obj, state, ctx)
    material, created = _paint_material(obj, state)
    if not _switch_object_mode(obj, "OBJECT"):
        _cleanup_restored_original_graphs(state)
        _cleanup_temporary_material(material, state)
        _clear_restore_snapshot(state)
        return {"ok": False, "reason": "object_mode_required"}
    try:
        _assign_temporary_material(obj, state, material)
        state.active = True
        uv_result = apply_uv(obj, selected_uv, material=material)
        if not bool(uv_result.get("ok", False)):
            raise RuntimeError(str(uv_result.get("reason", "uv_select_failed") or "uv_select_failed"))
    except Exception as exc:
        try:
            _restore_material_slots(obj, state)
            _restore_uv_state(obj, state)
        except Exception:
            pass
        state.active = False
        _cleanup_restored_original_graphs(state)
        _cleanup_temporary_material(material, state)
        _clear_restore_snapshot(state)
        return {"ok": False, "reason": "temporary_paint_enable_failed", "error": repr(exc)[:300]}
    activation = {"ok": True, "reason": "no_document"}
    try:
        from .. import lightweight_mvp

        settings = getattr(material, "smart_paint_suite", None)
        layers = getattr(settings, "layers", ()) if settings is not None else ()
        if layers:
            index = max(0, min(int(getattr(settings, "active_layer_index", 0) or 0), len(layers) - 1))
            activation = dict(lightweight_mvp.activate_layer(ctx, material, index) or {})
        elif settings is not None:
            activation = lightweight_mvp.add_paint_layer(ctx, material)
            _fill_new_layer_with_material_color(activation, material)
    except Exception as exc:
        activation = {"ok": False, "reason": "document_activation_failed", "error": repr(exc)[:300]}
    if not bool(activation.get("ok", False)):
        _switch_object_mode(obj, "TEXTURE_PAINT")
    state.last_error = ""
    state.last_status = _rpt("一時ペイント用マテリアル / UV: {}", selected_uv)
    result = {
        "ok": True,
        "reason": "temporary_paint_enabled",
        "object": str(getattr(obj, "name", "") or ""),
        "material_name": str(getattr(material, "name", "") or ""),
        "material_created": bool(created),
        "original_slot_count": int(state.original_slot_count),
        "temporary_slot_count": int(len(obj.material_slots)),
        "uv": str(selected_uv),
        "active_uv": _active_uv_name(obj),
        "render_uv": _render_uv_name(obj),
        "activation": activation,
        "mode": str(getattr(obj, "mode", "") or ""),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    _trace("temporary_paint_material_enabled", material=material, **result)
    return result


def restore(context=None) -> dict[str, Any]:
    started = time.perf_counter()
    ctx = context or getattr(bpy, "context", None)
    obj = getattr(ctx, "object", None) if ctx is not None else None
    state = state_for_object(obj)
    if obj is None or state is None or not bool(getattr(state, "active", False)):
        return {"ok": False, "reason": "temporary_paint_not_active"}
    preflight, reason = _restore_slots_preflight(obj, state)
    if not preflight:
        state.last_error = str(reason)
        return {"ok": False, "reason": str(reason)}
    material = getattr(state, "paint_material", None)
    try:
        from .. import lightweight_mvp

        lightweight_mvp._snapshot_canvas_before_layer_switch(material, "")
    except Exception:
        pass
    original_mode = str(getattr(state, "original_mode", "OBJECT") or "OBJECT")
    shared_paint_slots = _temporary_material_external_slots(material, exclude_object=obj)
    if shared_paint_slots == 0:
        _quiesce_temporary_runtime(material)
    _switch_object_mode(obj, "OBJECT")
    try:
        _restore_material_slots(obj, state)
        _restore_uv_state(obj, state)
        paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
        if paint is not None:
            try:
                paint.canvas = getattr(state, "original_canvas", None)
            except Exception:
                pass
            try:
                paint.mode = str(getattr(state, "original_paint_mode", "IMAGE") or "IMAGE")
            except Exception:
                pass
    except Exception as exc:
        try:
            if len(obj.material_slots) == 0:
                obj.data.materials.append(None)
            for slot in obj.material_slots:
                slot.link = "OBJECT"
                slot.material = material
        except Exception:
            pass
        state.last_error = "material_restore_failed"
        return {"ok": False, "reason": "material_restore_failed", "error": repr(exc)[:300]}
    original_graph_cleanup = _cleanup_restored_original_graphs(state)
    temporary_cleanup = _cleanup_temporary_material(material, state)
    state.active = False
    state.last_error = ""
    state.last_status = "元のマテリアルを復元"
    restored_slots = [
        {
            "material": str(getattr(getattr(slot, "material", None), "name", "") or ""),
            "link": str(getattr(slot, "link", "DATA") or "DATA"),
        }
        for slot in obj.material_slots
    ]
    _clear_restore_snapshot(state)
    if original_mode in {"OBJECT", "EDIT", "SCULPT", "VERTEX_PAINT", "WEIGHT_PAINT", "TEXTURE_PAINT"}:
        _switch_object_mode(obj, original_mode)
    result = {
        "ok": True,
        "reason": "original_material_restored",
        "object": str(getattr(obj, "name", "") or ""),
        "material_name": str(getattr(getattr(obj, "active_material", None), "name", "") or ""),
        "slots": restored_slots,
        "active_index": int(getattr(obj, "active_material_index", 0) or 0),
        "active_uv": _active_uv_name(obj),
        "render_uv": _render_uv_name(obj),
        "mode": str(getattr(obj, "mode", "") or ""),
        "original_graph_cleanup": original_graph_cleanup,
        "temporary_cleanup": temporary_cleanup,
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    result["shared_paint_slots_preserved"] = int(shared_paint_slots)
    _trace("temporary_paint_material_restored", material=material, **result)
    return result


class SPS_OT_enable_temporary_paint_material(bpy.types.Operator):
    bl_idname = "smart_paint_suite.enable_temporary_paint_material"
    bl_label = "ペイント用マテリアルへ切替"
    bl_description = "既存マテリアルを保存したまま、対象オブジェクトだけをSmart Paint用マテリアルへ切り替え、描く先のレイヤーを用意します"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return bool(obj is not None and str(getattr(obj, "type", "") or "") == "MESH")

    def execute(self, context):
        result = enable(context)
        if not bool(result.get("ok", False)):
            reason = str(result.get("reason", "temporary_paint_enable_failed") or "temporary_paint_enable_failed")
            message = {
                "uv_layer_missing": "対象メッシュにUVマップがありません。",
                "object_mode_required": "マテリアル切替のためオブジェクトモードへ移行できません。",
            }.get(reason, _rpt_fail("ペイント用マテリアルへ切り替えられません", reason))
            self.report({"ERROR"}, _rpt_msg(message))
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            _rpt("ペイント用マテリアル / UV: {} ({:.0f} ms)", result.get('uv', ''), float(result.get('elapsed_ms', 0.0))),
        )
        return {"FINISHED"}


class SPS_OT_restore_original_material(bpy.types.Operator):
    bl_idname = "smart_paint_suite.restore_original_material"
    bl_label = "元のマテリアルへ戻す"
    bl_description = "元のマテリアルスロット、リンク、アクティブ番号、UV、モードを復元します"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        state = state_for_object(getattr(context, "object", None))
        return bool(state is not None and getattr(state, "active", False))

    def execute(self, context):
        result = restore(context)
        if not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt_fail("元のマテリアルを復元できません", result.get("reason", "")))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("元のマテリアルを復元 ({:.0f} ms)", float(result.get('elapsed_ms', 0.0))))
        return {"FINISHED"}


class SPS_OT_apply_paint_uv(bpy.types.Operator):
    bl_idname = "smart_paint_suite.apply_paint_uv"
    bl_label = "描画UVを適用"
    bl_description = "選択したUVをテクスチャペイント、マテリアル表示、ソリッド合成表示へ同期します"
    bl_options = {"UNDO"}

    def execute(self, context):
        obj = getattr(context, "object", None)
        state = state_for_object(obj)
        if obj is None or state is None:
            return {"CANCELLED"}
        uv_name = str(getattr(state, "selected_uv", "") or "")
        if not uv_name:
            uv_name = _active_uv_name(obj)
            _set_selected_uv_silent(obj, state, uv_name)
        material = getattr(state, "paint_material", None) if bool(getattr(state, "active", False)) else getattr(obj, "active_material", None)
        result = apply_uv(obj, uv_name, material=material if _is_managed_material(material) else None)
        if not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt_fail("描画UVを適用できません", result.get("reason", "")))
            return {"CANCELLED"}
        state.last_error = ""
        state.last_status = _rpt("描画UV: {}", uv_name)
        self.report({"INFO"}, _rpt("描画UV: {}", uv_name))
        return {"FINISHED"}


def draw_controls(layout, context) -> None:
    obj = getattr(context, "object", None)
    if obj is None or str(getattr(obj, "type", "") or "") != "MESH":
        layout.label(text="メッシュオブジェクトを選択")
        return
    state = state_for_object(obj)
    if state is None:
        return
    active = bool(getattr(state, "active", False))
    button_row = layout.row(align=True)
    if active:
        button_row.operator(SPS_OT_restore_original_material.bl_idname, text="元のマテリアルへ戻す", icon="FILE_REFRESH")
        paint_material = getattr(state, "paint_material", None)
        material_name = str(getattr(paint_material, "name", "") or _rpt("ペイント用マテリアル"))
    else:
        button_row.operator(
            SPS_OT_enable_temporary_paint_material.bl_idname,
            text="ペイント用マテリアルへ切替",
            icon="MATERIAL",
        )
        material_name = str(getattr(getattr(obj, "active_material", None), "name", "") or _rpt("マテリアルなし"))
    material_row = layout.row(align=True)
    material_row.label(text=material_name, icon="MATERIAL", translate=False)
    uv_layers = _uv_layers(obj)
    uv_row = layout.row(align=True)
    if uv_layers is not None and len(uv_layers):
        uv_row.prop_search(state, "selected_uv", obj.data, "uv_layers", text="UV", icon="GROUP_UVS")
        uv_row.operator(SPS_OT_apply_paint_uv.bl_idname, text="", icon="CHECKMARK")
        if not str(getattr(state, "selected_uv", "") or ""):
            uv_row.label(text=_active_uv_name(obj), translate=False)
    else:
        uv_row.alert = True
        uv_row.label(text="UVマップがありません", icon="ERROR")
    if str(getattr(state, "last_error", "") or ""):
        error = layout.row()
        error.alert = True
        error.label(text=_rpt_msg(state.last_error)[:100], icon="ERROR")


CLASSES = (
    SPSTemporaryMaterialSlotState,
    SPSTemporaryPaintState,
    SPS_OT_enable_temporary_paint_material,
    SPS_OT_restore_original_material,
    SPS_OT_apply_paint_uv,
)


def _reset_runtime_state() -> None:
    _UV_UPDATE_GUARD.clear()
    _ORIGINAL_GRAPH_SNAPSHOTS.clear()


def register(transaction) -> None:
    transaction.register_property_group(SPSTemporaryMaterialSlotState)
    transaction.register_property_group(
        SPSTemporaryPaintState,
        dependencies=(SPSTemporaryMaterialSlotState,),
    )
    for cls in CLASSES[2:]:
        transaction.register_class(cls)
    transaction.add_pointer_property(
        bpy.types.Object,
        OBJECT_PROPERTY,
        SPSTemporaryPaintState,
    )
    transaction.add_cleanup(_reset_runtime_state, label="paint_workspace.reset")


def unregister() -> None:
    """Compatibility surface; exact removal is owned by runtime_registry."""
    _reset_runtime_state()
