# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the lightweight paint workspace's state API."""

from . import state

__all__ = ("state",)
