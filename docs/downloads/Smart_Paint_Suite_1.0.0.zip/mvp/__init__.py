# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Lightweight Smart Paint runtime primitives.

The core modules avoid timers, keymaps, modal operators, and workers. Most
provide small state, paint-target, composition, and save contracts for the
default local PSD workflow. ``image_editor_overlay`` additionally owns the
single opt-in Image Editor draw handler used for composite-display painting.
"""

from . import state

__all__ = ("state",)
