# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Dirty-only v11 marker adapter for the lightweight PSD workflow."""

from __future__ import annotations

import json
from typing import Any

import bpy

from . import state


CHANNEL = "BASE_COLOR"


_IMAGE_DIRTY_MARKERS = (
    "smart_paint_suite_direct_layer_dirty",
    "smart_paint_suite_bodypaint_direct_authoritative",
    "smart_paint_suite_user_edited",
    "smart_paint_suite_painted_since_last_projection",
    "smart_paint_suite_last_brush_color",
    "sps_v2_native_paint_dirty",
    "smart_paint_suite_dirty_bbox",
    "smart_paint_suite_dirty_rects_json",
    "sps_phase2_runtime_dirty_bbox",
    "sps_phase2_runtime_dirty_rects_json",
)


_MATERIAL_DIRTY_KEYS = (
    "sps_v2_dirty_layer_ids_BASE_COLOR",
    "sps_v2_dirty_images_BASE_COLOR",
    "sps_v2_dirty_source_indices_BASE_COLOR",
    "sps_v2_dirty_layer_id_BASE_COLOR",
    "sps_v2_dirty_image_BASE_COLOR",
)


def _trace(event: str, *, material=None, **payload) -> None:
    try:
        from .. import save_trace

        save_trace.emit(str(event or ""), material=material, channel=CHANNEL, **payload)
    except Exception:
        pass


def clear_dirty_scope(material) -> None:
    for key in _MATERIAL_DIRTY_KEYS:
        try:
            if key in material:
                del material[key]
        except Exception:
            pass


def clear_dirty_image(material, image_name: str = "", layer_id: str = "", *, reason: str = "") -> bool:
    image = bpy.data.images.get(str(image_name or "")) if image_name else None
    if image is not None:
        for key in _IMAGE_DIRTY_MARKERS:
            try:
                if key in image:
                    del image[key]
            except Exception:
                pass
    try:
        layer_ids = json.loads(str(material.get("sps_v2_dirty_layer_ids_BASE_COLOR", "[]") or "[]"))
    except Exception:
        layer_ids = []
    try:
        image_names = json.loads(str(material.get("sps_v2_dirty_images_BASE_COLOR", "[]") or "[]"))
    except Exception:
        image_names = []
    layer_ids = [str(value) for value in layer_ids if str(value or "") != str(layer_id or "")]
    image_names = [str(value) for value in image_names if str(value or "") != str(image_name or "")]
    try:
        material["sps_v2_dirty_layer_ids_BASE_COLOR"] = json.dumps(layer_ids, ensure_ascii=False)
        material["sps_v2_dirty_images_BASE_COLOR"] = json.dumps(image_names, ensure_ascii=False)
    except Exception:
        pass
    _trace(
        "mvp_save_adapter_clear_dirty_image",
        material=material,
        image=str(image_name or ""),
        layer_id=str(layer_id or ""),
        reason=str(reason or ""),
    )
    return True


def apply_v11_markers(material, entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Publish the exact lightweight save set using the established v11 keys."""
    layer_ids: list[str] = []
    image_names: list[str] = []
    source_indices: list[int] = []
    for entry in list(entries or []):
        image = entry.get("image_ref")
        if image is None:
            continue
        layer_id = str(entry.get("layer_id", "") or "")
        try:
            source_index = int(entry.get("record_index", -1))
        except Exception:
            source_index = -1
        layer_ids.append(layer_id)
        image_names.append(str(getattr(image, "name", "") or ""))
        if source_index >= 0:
            source_indices.append(source_index)
        for key, value in (
            ("smart_paint_suite_direct_layer_dirty", True),
            ("smart_paint_suite_bodypaint_direct_authoritative", True),
            ("smart_paint_suite_user_edited", True),
            ("smart_paint_suite_painted_since_last_projection", True),
            ("smart_paint_suite_last_brush_color", (1.0, 1.0, 1.0, 1.0)),
            ("smart_paint_suite_alpha_authoritative", True),
            ("sps_v2_native_paint_dirty", True),
            ("sps_v2_native_paint_target", True),
            ("smart_paint_suite_layer_id", layer_id),
            ("sps_lightweight_source_materialized_authoritative", True),
            ("sps_lightweight_bounds_authoritative", True),
            ("smart_paint_suite_psd_materialized_clean", True),
        ):
            try:
                image[key] = value
            except Exception:
                pass
        for key in (
            "smart_paint_suite_dirty_bbox",
            "smart_paint_suite_dirty_rects_json",
            "sps_phase2_runtime_dirty_bbox",
            "sps_phase2_runtime_dirty_rects_json",
        ):
            try:
                if key in image:
                    del image[key]
            except Exception:
                pass
        rect = entry.get("dirty_rect")
        if rect is not None:
            values = [int(value) for value in tuple(rect)[:4]]
            if len(values) == 4 and values[2] > values[0] and values[3] > values[1]:
                try:
                    image["smart_paint_suite_dirty_bbox"] = tuple(values)
                    image["smart_paint_suite_dirty_rects_json"] = json.dumps(
                        [values], separators=(",", ":")
                    )
                except Exception:
                    pass
        _trace(
            "mvp_save_adapter_layer_marked",
            material=material,
            layer_id=layer_id,
            record_index=int(source_index),
            image=str(getattr(image, "name", "") or ""),
            dirty_rect=list(entry.get("dirty_rect") or []),
        )
    try:
        material["sps_v2_dirty_only_save_BASE_COLOR"] = True
        material["sps_v2_local_mvp_active_BASE_COLOR"] = True
        material["sps_v2_dirty_layer_ids_BASE_COLOR"] = json.dumps(layer_ids, ensure_ascii=False)
        material["sps_v2_dirty_images_BASE_COLOR"] = json.dumps(image_names, ensure_ascii=False)
        material["sps_v2_dirty_source_indices_BASE_COLOR"] = json.dumps(source_indices)
        if layer_ids:
            material["sps_v2_dirty_layer_id_BASE_COLOR"] = layer_ids[-1]
        if image_names:
            material["sps_v2_dirty_image_BASE_COLOR"] = image_names[-1]
    except Exception:
        pass
    return {
        "layer_ids": layer_ids,
        "images": image_names,
        "source_indices": source_indices,
        "count": len(layer_ids),
    }


def commit_saved(material, entries: list[dict[str, Any]]) -> None:
    """Advance exact baselines after a successful v11 destination replace."""
    import numpy as np

    material_name = state.material_name(material)
    for entry in list(entries or []):
        image = entry.get("image_ref")
        if image is None:
            continue
        layer_id = str(entry.get("layer_id", "") or "")
        try:
            width, height = int(image.size[0]), int(image.size[1])
            payload = entry.get("save_current_payload")
            if not isinstance(payload, tuple) or len(payload) != 3:
                payload = None
            else:
                payload_width, payload_height, payload_pixels = payload
                if int(payload_width) != width or int(payload_height) != height:
                    payload = None
                else:
                    pixels = np.asarray(payload_pixels, dtype=np.uint8)
                    if pixels.size != width * height * 4:
                        payload = None
                    else:
                        payload = (width, height, pixels.reshape((height, width, 4)))
            if payload is None:
                flat = np.empty(width * height * 4, dtype=np.float32)
                image.pixels.foreach_get(flat)
                pixels = np.ascontiguousarray(
                    np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
                    dtype=np.uint8,
                )
                payload = (width, height, pixels)
            activated = state.ACTIVATED_LAYERS.get(material_name, {}).get(layer_id)
            if isinstance(activated, dict):
                activated["baseline_payload"] = payload
                # External conflict detection uses the push baseline first.
                # A successful PSD save commits these local pixels, so leaving
                # that baseline stale makes the next external edit conflict.
                activated["push_baseline_payload"] = payload
                activated["baseline_exact"] = True
                activated["current_payload"] = payload
                activated.pop("external_dirty_rects", None)
                activated.pop("external_import_token", None)
        except Exception:
            pass
        for key in _IMAGE_DIRTY_MARKERS:
            try:
                if key in image:
                    del image[key]
            except Exception:
                pass
        try:
            image["smart_paint_suite_psd_materialized_clean"] = True
            image["smart_paint_suite_saved_psd_clean_boundary"] = True
        except Exception:
            pass
    clear_dirty_scope(material)
    _trace(
        "mvp_save_adapter_commit",
        material=material,
        saved_layer_count=len(list(entries or [])),
    )
