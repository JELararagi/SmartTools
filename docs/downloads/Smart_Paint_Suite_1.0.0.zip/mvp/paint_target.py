# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Native Texture Paint target for the lightweight PSD workflow.

The module creates one full-document canvas per exact PSD record and binds it
directly to Blender's Image Paint canvas.  It owns no input hooks and performs
no compositing.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import bpy

from . import state


CHANNEL = "BASE_COLOR"
_MASK_CANVAS_PREFIX = "__sps_mask__:"
_SUITE_OWNER_UUID = "a57946f8-8f20-4e88-b304-6d6fc0e3ee7a"
_PSD_API: dict[str, Any] = {}


def configure_psd_api(api_module) -> None:
    """Bind PSD decode callables only from an explicit PSD operation.

    Layer selection and property/update callbacks never import the large PSD
    implementation.  A prior explicit Open/Review/Save operation may supply
    the final callables; saved full-size canvases need no decoder at all.
    """
    global _PSD_API
    names = (
        "lazy_psd_layer_payload_for_image",
        "read_layered_psd_lazy",
        "decode_lazy_psd_layer_rgba",
        "materialize_lazy_psd_layer_image",
    )
    bound = {name: getattr(api_module, name, None) for name in names}
    _PSD_API = {name: value for name, value in bound.items() if callable(value)}


def clear_psd_api() -> None:
    _PSD_API.clear()


def _ensure_write_node(material, layer_id: str, image):
    """Return one exact Suite-owned active write node without broad cleanup."""
    if material is None or image is None:
        return None
    try:
        if not bool(getattr(material, "use_nodes", False)):
            material.use_nodes = True
        tree = getattr(material, "node_tree", None)
        if tree is None:
            return None
        base_name = "SPS_FlatActiveLayerWrite_" + CHANNEL
        node = tree.nodes.get(base_name)
        owned = bool(
            node is not None
            and str(getattr(node, "type", "") or "") == "TEX_IMAGE"
            and (
                str(node.get("sps_suite_owner_uuid", "") or "") == _SUITE_OWNER_UUID
                or (
                    bool(node.get("sps_node", False))
                    and bool(node.get("sps_flat_write_node", False))
                    and str(getattr(node, "name", "") or "") == base_name
                )
            )
        )
        if not owned:
            node = tree.nodes.new("ShaderNodeTexImage")
            node.name = base_name
            node.label = "Smart Paint Active Layer Write"
            node.location = (-260.0, -260.0)
        node.image = image
        node.hide = True
        node["sps_node"] = True
        node["sps_flat_write_node"] = True
        node["sps_suite_owner_uuid"] = _SUITE_OWNER_UUID
        node["sps_layer_id"] = str(layer_id or "")
        node["sps_channel"] = CHANNEL
        tree.nodes.active = node
        return node
    except (AttributeError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _trace(event: str, *, material=None, **payload) -> None:
    try:
        from .. import save_trace

        values = dict(payload or {})
        values.pop("channel", None)
        save_trace.emit(str(event or ""), material=material, channel=CHANNEL, **values)
    except Exception:
        pass


def _layer_id(layer, index: int) -> str:
    try:
        value = str(getattr(layer, "layer_id", "") or "")
    except Exception:
        value = ""
    return value or f"layer_{int(index) + 1}"


def _record_index(layer) -> int:
    try:
        return int(getattr(layer, "psd_source_record_index", -1))
    except Exception:
        return -1


def _source_path(material, layer=None, image=None) -> str:
    for owner in (image, layer, material):
        if owner is None:
            continue
        for key in (
            "smart_paint_suite_source_file",
            "smart_paint_suite_layered_source_path",
            "sps_texture_path_BASE_COLOR",
            "sps_bodypaint_source_stack_path_BASE_COLOR",
            "sps_source_psd_path_BASE_COLOR",
            "sps_texture_source_path_BASE_COLOR",
        ):
            try:
                value = str(owner.get(key, "") or "")
            except Exception:
                value = ""
            if not value:
                continue
            try:
                return str(Path(bpy.path.abspath(value)).resolve())
            except Exception:
                return value
    return ""


def _source_payload(source_image, source_path: str, record_index: int):
    payload_for_image = _PSD_API.get("lazy_psd_layer_payload_for_image")
    read_layered = _PSD_API.get("read_layered_psd_lazy")

    if source_image is not None:
        try:
            source_image["sps_psd_source_order"] = int(record_index)
            source_image["sps_psd_source_ordinal"] = int(record_index)
            source_image["sps_psd_source_layer_index"] = int(record_index)
            if source_path:
                source_image["smart_paint_suite_source_file"] = source_path
                source_image["smart_paint_suite_layered_source_path"] = source_path
        except Exception:
            pass
        try:
            payload = payload_for_image(source_image) if callable(payload_for_image) else None
            record = dict((payload or {}).get("record") or {})
            if payload and int(record.get("record_index", -1)) == int(record_index):
                return payload
        except Exception:
            pass
    if not source_path or int(record_index) < 0:
        return None
    if not callable(read_layered):
        return None
    doc = read_layered(source_path, decode_merged=False)
    record = None
    for candidate in list(doc.get("layers", []) or []):
        try:
            if int(candidate.get("record_index", -1)) == int(record_index):
                record = candidate
                break
        except Exception:
            pass
    if record is None:
        return None
    return {
        "record": record,
        "doc_width": int(doc.get("width", 0) or 0),
        "doc_height": int(doc.get("height", 0) or 0),
        "depth": int(doc.get("depth", 8) or 8),
        "color_mode": int(doc.get("color_mode", 3) or 3),
        "psb": bool(doc.get("psb")),
    }


def _decode_source(payload):
    if not payload:
        return None
    import numpy as np
    decode_layer = _PSD_API.get("decode_lazy_psd_layer_rgba")

    width = int(payload.get("doc_width", 0) or 0)
    height = int(payload.get("doc_height", 0) or 0)
    depth = int(payload.get("depth", 8) or 8)
    color_mode = int(payload.get("color_mode", 3) or 3)
    if width > 1 and height > 1 and depth == 8 and color_mode in {1, 3}:
        try:
            from . import live_composite

            document = {
                "width": width,
                "height": height,
                "depth": depth,
                "color_mode": color_mode,
                "psb": bool(payload.get("psb")),
            }
            baseline = live_composite._decode_record_u8(payload.get("record"), document)
            if baseline is not None and tuple(baseline.shape) == (height, width, 4):
                pixels = np.empty((height, width, 4), dtype=np.float32)
                np.multiply(
                    baseline,
                    np.float32(1.0 / 255.0),
                    out=pixels,
                    casting="unsafe",
                )
                return width, height, pixels, baseline
        except Exception:
            pass
    if not callable(decode_layer):
        return None
    rgba = decode_layer(
        payload.get("record"),
        doc_width=width,
        doc_height=height,
        depth=depth,
        color_mode=color_mode,
        psb=bool(payload.get("psb")),
        apply_layer_mask=False,
    )
    if rgba is None or width <= 1 or height <= 1:
        return None
    pixels = np.asarray(rgba, dtype=np.float32)
    if pixels.ndim == 2 and int(pixels.shape[1]) == 4 and int(pixels.shape[0]) == width * height:
        pixels = pixels.reshape((height, width, 4))
    if pixels.ndim != 3 or tuple(pixels.shape) != (height, width, 4):
        return None
    pixels = np.ascontiguousarray(np.clip(pixels, 0.0, 1.0), dtype=np.float32)
    baseline = np.ascontiguousarray(
        np.clip(np.floor(pixels * 255.0 + 0.5), 0.0, 255.0), dtype=np.uint8
    )
    return width, height, pixels, baseline


def _document_size(material) -> tuple[int, int]:
    settings = getattr(material, "smart_paint_suite", None)
    for layer in list(getattr(settings, "layers", ()) or ()):
        try:
            image = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
        except Exception:
            image = None
        if image is None:
            continue
        try:
            width = int(image.get("smart_paint_suite_lazy_width", 0) or image.size[0])
            height = int(image.get("smart_paint_suite_lazy_height", 0) or image.size[1])
            if width > 1 and height > 1:
                return width, height
        except Exception:
            pass
    return 2048, 2048


def _stamp_canvas(image, material, layer, layer_id: str, record_index: int, source_path: str) -> None:
    values = (
        ("sps_mvp_native_canvas", True),
        ("smart_paint_suite_layer_image", True),
        ("smart_paint_suite_bodypaint_paintable", True),
        ("smart_paint_suite_material", str(getattr(material, "name", "") or "")),
        ("smart_paint_suite_channel", CHANNEL),
        ("smart_paint_suite_layer_id", str(layer_id or "")),
        ("smart_paint_suite_direct_layer_write_target", True),
        ("smart_paint_suite_alpha_authoritative", True),
        ("sps_v2_native_paint_target", True),
        ("sps_psd_source_order", int(record_index)),
        ("sps_psd_source_ordinal", int(record_index)),
        ("sps_psd_source_layer_index", int(record_index)),
        ("smart_paint_suite_lazy_psd_key", f"{str(getattr(image, 'name', '') or 'mvp')}|{int(record_index)}"),
        ("smart_paint_suite_source_file", str(source_path or "")),
        ("smart_paint_suite_layered_source_path", str(source_path or "")),
        ("smart_paint_suite_psd_materialized_clean", True),
        ("sps_lightweight_source_materialized_authoritative", True),
    )
    for key, value in values:
        if int(record_index) < 0 and (
            key.startswith("sps_psd_source_") or key == "smart_paint_suite_lazy_psd_key"
        ):
            continue
        if not source_path and key in {"smart_paint_suite_source_file", "smart_paint_suite_layered_source_path"}:
            continue
        try:
            image[key] = value
        except Exception:
            pass
    try:
        original_name = str(layer.get("sps_psd_original_name", "") or getattr(layer, "name", "") or "")
        if original_name:
            image["sps_psd_original_name"] = original_name
    except Exception:
        pass
    for key in (
        "smart_paint_suite_lazy_psd_pending",
        "smart_paint_suite_lazy_blank_layer",
        "smart_paint_suite_intentionally_empty",
        "smart_paint_suite_user_created_paint_layer",
    ):
        try:
            if key in image:
                del image[key]
        except Exception:
            pass


def _new_canvas(material, layer, layer_id: str, record_index: int, source_image, source_path: str):
    import numpy as np

    decoded = _decode_source(_source_payload(source_image, source_path, record_index)) if record_index >= 0 else None
    decoded_source = decoded is not None
    if decoded is not None:
        width, height, pixels, baseline = decoded
    else:
        width, height = _document_size(material)
        pixels = np.empty((height, width, 4), dtype=np.float32)
        pixels[:, :, 0:3] = 1.0
        pixels[:, :, 3] = 0.0
        if source_image is not None:
            try:
                sw, sh = int(source_image.size[0]), int(source_image.size[1])
                if sw == width and sh == height:
                    flat = np.empty(width * height * 4, dtype=np.float32)
                    source_image.pixels.foreach_get(flat)
                    pixels = np.ascontiguousarray(flat.reshape((height, width, 4)), dtype=np.float32)
            except Exception:
                pass
        baseline = np.ascontiguousarray(
            np.clip(np.floor(pixels * 255.0 + 0.5), 0.0, 255.0), dtype=np.uint8
        )
    name = f"SPS_MVP_{str(getattr(material, 'name', '') or 'Material')}_{layer_id}_{record_index}_{CHANNEL}"
    existing = bpy.data.images.get(name)
    reused_existing = False
    if existing is not None:
        try:
            exact = bool(
                existing.get("sps_mvp_native_canvas", False)
                and str(existing.get("smart_paint_suite_layer_id", "") or "") == str(layer_id or "")
                and int(existing.get("sps_psd_source_order", -1)) == int(record_index)
                and int(existing.size[0]) == int(width)
                and int(existing.size[1]) == int(height)
            )
        except Exception:
            exact = False
        if exact:
            image = existing
            reused_existing = True
        else:
            image = bpy.data.images.new(name=name, width=width, height=height, alpha=True, float_buffer=False)
    else:
        image = bpy.data.images.new(name=name, width=width, height=height, alpha=True, float_buffer=False)
    # GENERATED images lazily instantiate their pixel buffer from
    # generated_color. Keep that seed transparent before the first full write;
    # otherwise Blender can replace the decoded PSD alpha with the default
    # opaque generated buffer during update/bind.
    try:
        image.generated_color = (1.0, 1.0, 1.0, 0.0)
        image.alpha_mode = "STRAIGHT"
        if source_image is not None:
            image.colorspace_settings.name = source_image.colorspace_settings.name
        if reused_existing:
            # An exact-looking datablock loaded from .blend is not owned by the
            # new process-local layer state. Reallocate its generated backing
            # buffer before restoring PSD pixels; otherwise Blender can expose
            # only generated_color and silently ignore the decoded payload.
            image.scale(1, 1)
            image.generated_color = (1.0, 1.0, 1.0, 0.0)
            image.scale(width, height)
    except Exception:
        pass
    image.pixels.foreach_set(pixels.reshape((-1,)))
    image.update()
    # Blender normalizes byte-backed Image pixels on assignment.  The save
    # baseline must describe the actual native canvas, not the pre-assignment
    # decode array, otherwise millions of unchanged pixels look dirty.
    readback = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(readback)
    baseline = np.ascontiguousarray(
        np.clip(
            np.floor(readback.reshape((height, width, 4)) * 255.0 + 0.5),
            0.0,
            255.0,
        ),
        dtype=np.uint8,
    )
    try:
        image.use_fake_user = True
    except Exception:
        pass
    _stamp_canvas(image, material, layer, layer_id, record_index, source_path)
    try:
        if (
            int(record_index) < 0
            and source_image is not None
            and bool(source_image.get("smart_paint_suite_intentionally_empty", False))
        ):
            image["sps_lightweight_new_blank_layer"] = True
    except Exception:
        pass
    state.put_layer(material, layer_id, {
        "layer_id": layer_id,
        "image": str(image.name),
        "record_index": int(record_index),
        "baseline_exact": True,
        "baseline_payload": (int(width), int(height), baseline),
        "preview_baseline_payload": (int(width), int(height), baseline),
        "needs_post_bind_baseline": True,
        "current_payload": None,
        "preview_enabled": bool(getattr(layer, "enabled", True)),
        "preview_opacity": float(getattr(layer, "opacity", 1.0) or 0.0),
    })
    _trace(
        "mvp_paint_target_canvas_created",
        material=material,
        layer_id=str(layer_id or ""),
        record_index=int(record_index),
        image=str(getattr(image, "name", "") or ""),
        source_image=str(getattr(source_image, "name", "") or "") if source_image is not None else "",
        source_path=str(source_path or ""),
        decoded_source=bool(decoded_source),
        reused_existing=bool(reused_existing),
        image_size=[int(width), int(height)],
    )
    return image, True


def _bind_canvas(material, layer, image, layer_id: str, context=None, *, switch_to_paint: bool = True) -> bool:
    ctx = context or getattr(bpy, "context", None)
    node = _ensure_write_node(material, layer_id, image)
    try:
        if node is not None:
            material.node_tree.nodes.active = node
    except Exception:
        pass
    try:
        paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
        if paint is not None:
            if hasattr(paint, "mode"):
                paint.mode = "IMAGE"
            paint.canvas = image
    except Exception:
        pass
    try:
        setattr(layer, "base_color_image", image.name)
        material["sps_lightweight_active_target"] = "PIXELS"
        for stale_key in (
            "sps_lightweight_mask_owner_layer_id",
            "sps_lightweight_mask_target_image",
        ):
            if stale_key in material:
                del material[stale_key]
        material["sps_active_recording_layer_id_BASE_COLOR"] = str(layer_id or "")
        material["sps_active_private_layer_image_BASE_COLOR"] = image.name
        material["sps_native_write_image_BASE_COLOR"] = image.name
        material["sps_v2_native_paint_target_image_BASE_COLOR"] = image.name
        material["sps_v2_native_paint_target_layer_id_BASE_COLOR"] = str(layer_id or "")
        material["sps_v2_local_mvp_active_BASE_COLOR"] = True
        material["sps_all_layers_target_runtime_BASE_COLOR"] = False
    except Exception:
        pass
    if switch_to_paint:
        try:
            obj = getattr(ctx, "object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") != "TEXTURE_PAINT":
                if getattr(obj, "mode", "") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                bpy.ops.object.mode_set(mode="TEXTURE_PAINT")
        except Exception:
            pass
    return bool(node is not None or image is not None)


def _mask_canvas_id(layer_id: str) -> str:
    return _MASK_CANVAS_PREFIX + str(layer_id or "active")


def _stamp_mask_canvas(image, material, layer_id: str) -> None:
    """Keep a mask paint target outside the private paint-layer state map."""
    if image is None:
        return
    target_id = _mask_canvas_id(layer_id)
    for key, value in (
        ("sps_mvp_mask_canvas", True),
        ("smart_paint_suite_mask_image", True),
        ("smart_paint_suite_material", str(getattr(material, "name", "") or "")),
        ("smart_paint_suite_layer_id", target_id),
        ("sps_mvp_mask_owner_layer_id", str(layer_id or "")),
        ("smart_paint_suite_channel", "MASK"),
    ):
        try:
            image[key] = value
        except Exception:
            pass
    # paint_target.snapshot_outgoing() resolves private paint state by durable
    # PSD record identity. A mask canvas must never be adopted as that record's
    # RGBA paint layer when the user switches back to pixels.
    for key in (
        "sps_psd_source_order",
        "sps_psd_source_ordinal",
        "sps_psd_source_layer_index",
        "psd_source_record_index",
    ):
        try:
            if key in image:
                del image[key]
        except Exception:
            pass


def _ensure_mask_canvas(material, layer, layer_id: str):
    materialize = _PSD_API.get("materialize_lazy_psd_layer_image")

    width, height = _document_size(material)
    mask_name = str(getattr(layer, "mask_image", "") or "")
    image = bpy.data.images.get(mask_name) if mask_name else None
    created = False
    materialized = False
    if image is not None:
        try:
            pending = bool(image.get("smart_paint_suite_lazy_psd_mask_pending", False))
        except Exception:
            pending = False
        if pending or int(image.size[0]) <= 1 or int(image.size[1]) <= 1:
            try:
                materialized = bool(materialize(image)) if callable(materialize) else False
            except Exception:
                materialized = False
    if image is None:
        name = f"SPS_MVP_{str(getattr(material, 'name', '') or 'Material')}_{layer_id}_MASK"
        image = bpy.data.images.get(name)
        if image is None:
            image = bpy.data.images.new(
                name=name,
                width=int(width),
                height=int(height),
                alpha=True,
                float_buffer=False,
            )
            image.colorspace_settings.name = "Non-Color"
            image.generated_color = (1.0, 1.0, 1.0, 1.0)
            created = True
    try:
        current_width, current_height = int(image.size[0]), int(image.size[1])
    except Exception:
        current_width, current_height = 0, 0
    if current_width != int(width) or current_height != int(height):
        try:
            image.scale(1, 1)
            image.generated_color = (1.0, 1.0, 1.0, 1.0)
            image.scale(int(width), int(height))
        except Exception:
            return None, created, materialized
    try:
        image.alpha_mode = "STRAIGHT"
        image.use_fake_user = True
    except Exception:
        pass
    if materialized:
        try:
            # Materialization itself dirties Blender's generated Image. Packing
            # establishes a clean boundary so selecting an untouched source mask
            # does not force a later full-document PSD re-encode.
            image.pack()
        except Exception:
            pass
        try:
            image["sps_lightweight_mask_write_required"] = False
        except Exception:
            pass
    elif created:
        try:
            # A newly-added mask must be emitted even before its first stroke.
            image["sps_lightweight_mask_write_required"] = True
        except Exception:
            pass
    _stamp_mask_canvas(image, material, layer_id)
    try:
        layer.mask_mode = "IMAGE"
        layer.mask_image = image.name
        layer.mask_channel = "LUMA"
    except Exception:
        pass
    return image, created, materialized


def _bind_mask_canvas(material, image, layer_id: str, context=None, *, switch_to_paint: bool = True) -> bool:
    ctx = context or getattr(bpy, "context", None)
    node = _ensure_write_node(material, _mask_canvas_id(layer_id), image)
    try:
        if node is not None:
            material.node_tree.nodes.active = node
        paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
        if paint is not None:
            if hasattr(paint, "mode"):
                paint.mode = "IMAGE"
            paint.canvas = image
    except Exception:
        pass
    try:
        material["sps_lightweight_active_target"] = "MASK"
        material["sps_lightweight_mask_owner_layer_id"] = str(layer_id or "")
        material["sps_lightweight_mask_target_image"] = str(getattr(image, "name", "") or "")
    except Exception:
        pass
    if switch_to_paint:
        try:
            obj = getattr(ctx, "object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") != "TEXTURE_PAINT":
                if getattr(obj, "mode", "") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                bpy.ops.object.mode_set(mode="TEXTURE_PAINT")
        except Exception:
            pass
    return bool(node is not None or image is not None)


def activate_mask(material, layer_index: int, context=None, *, switch_to_paint: bool = True) -> dict[str, Any]:
    """Materialize/create one layer or group mask and make it the native canvas."""
    started = time.perf_counter()
    settings = getattr(material, "smart_paint_suite", None)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not layers or not (0 <= int(layer_index) < len(layers)):
        return {"ok": False, "reason": "layer_not_found"}
    layer = layers[int(layer_index)]
    layer_id = _layer_id(layer, int(layer_index))
    # Capture an outgoing pixel-layer brush buffer before the write node is
    # swapped to the mask. Synthetic mask ids keep the reverse switch isolated.
    snapshot_outgoing(material, context)
    image, created, materialized = _ensure_mask_canvas(material, layer, layer_id)
    if image is None:
        return {"ok": False, "reason": "mask_canvas_create_failed"}
    try:
        settings.active_layer_index = int(layer_index)
        if hasattr(settings, "lightweight_ui_layer_index"):
            settings.lightweight_ui_layer_index = int(layer_index)
    except Exception:
        pass
    ok = _bind_mask_canvas(
        material,
        image,
        layer_id,
        context,
        switch_to_paint=bool(switch_to_paint),
    )
    if ok:
        try:
            from . import selection_tools

            selection_tools.ensure_mask_refresh_keymap()
        except Exception:
            pass
    result = {
        "ok": bool(ok),
        "reason": "ok" if ok else "mask_canvas_bind_failed",
        "layer_index": int(layer_index),
        "layer_name": str(getattr(layer, "name", "") or ""),
        "layer_id": str(layer_id or ""),
        "is_group": bool(getattr(layer, "is_group", False)),
        "image": str(getattr(image, "name", "") or ""),
        "image_size": [int(image.size[0]), int(image.size[1])],
        "created": bool(created),
        "materialized": bool(materialized),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    _trace("mvp_mask_target_activate", material=material, **result)
    return result


def snapshot_outgoing(material, context=None) -> None:
    try:
        paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
        image = getattr(paint, "canvas", None) if paint is not None else None
        if image is None:
            return
        if bool(image.get("sps_mvp_mask_canvas", False)):
            # Mask pixels live on the layer/group mask image itself. They must
            # never enter the private RGBA paint-layer state, even when the
            # owning PSD record can be inferred from the active UI row.
            return
        layer_id = str(image.get("smart_paint_suite_layer_id", "") or "")
        material_name = str(getattr(material, "name", "") or "")
        canvas_material = str(image.get("smart_paint_suite_material", "") or "")
        if canvas_material != material_name and state.get_layer(material, layer_id) is None:
            return
        try:
            record_index = int(image.get("sps_psd_source_order", -1))
        except Exception:
            record_index = -1
        if record_index < 0:
            settings = getattr(material, "smart_paint_suite", None)
            layers = getattr(settings, "layers", ()) if settings is not None else ()
            try:
                active_index = int(getattr(settings, "active_layer_index", -1))
            except Exception:
                active_index = -1
            if 0 <= active_index < len(layers):
                active_layer = layers[active_index]
                record_index = _record_index(active_layer)
                if not layer_id:
                    layer_id = _layer_id(active_layer, active_index)
        repair = state.repair_external_import_baseline(
            material, layer_id, record_index, image
        )
        if bool(repair.get("repaired", False)):
            _trace(
                "mvp_paint_target_import_undo_repaired_before_snapshot",
                material=material,
                layer_id=str(layer_id or ""),
                record_index=int(record_index),
                image=str(getattr(image, "name", "") or ""),
                rects=[list(rect) for rect in repair.get("rects", [])],
            )
        adoption = state.adopt_canvas(material, layer_id, record_index, image)
        if adoption is None:
            return
        state.capture_canvas(material, layer_id, image)
        previous_layer_id = str(adoption.get("previous_layer_id", "") or "")
        if previous_layer_id and previous_layer_id != layer_id:
            _trace(
                "mvp_paint_target_identity_rebound",
                material=material,
                previous_layer_id=previous_layer_id,
                layer_id=layer_id,
                record_index=int(record_index),
                image=str(getattr(image, "name", "") or ""),
            )
    except Exception:
        pass


def activate(material, layer_index: int, context=None, *, switch_to_paint: bool = True) -> dict[str, Any]:
    start = time.perf_counter()
    settings = getattr(material, "smart_paint_suite", None)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not layers or not (0 <= int(layer_index) < len(layers)):
        return {"ok": False, "reason": "layer_not_found"}
    layer = layers[int(layer_index)]
    layer_id = _layer_id(layer, int(layer_index))
    record_index = _record_index(layer)
    snapshot_outgoing(material, context)
    _resolved_id, process_entry = state.find_layer(material, layer_id, record_index)
    process_entry = dict(process_entry or {})
    image = state.matching_canvas(material, layer_id, record_index)
    restored = False
    retired_source_image = ""
    if image is None:
        source_name = str(getattr(layer, "base_color_image", "") or "")
        source_image = bpy.data.images.get(source_name) if source_name else None
        source_path = _source_path(material, layer, source_image)
        try:
            image, restored = _new_canvas(
                material, layer, layer_id, record_index, source_image, source_path
            )
        except Exception as exc:
            _trace(
                "mvp_paint_target_activate",
                material=material,
                ok=False,
                reason="source_decode_failed",
                layer_id=layer_id,
                record_index=int(record_index),
                error=repr(exc)[:600],
            )
            return {"ok": False, "reason": "source_decode_failed", "error": repr(exc)[:600]}
        if source_image is not None and source_image != image:
            try:
                if (
                    int(source_image.size[0]) <= 1
                    and int(source_image.size[1]) <= 1
                ):
                    retired_source_image = source_name
            except Exception:
                retired_source_image = ""
        guards = list(process_entry.get("external_import_undo_guards") or [])
        payload_source = "current_payload"
        payload = process_entry.get(payload_source)
        if guards:
            import_baseline = process_entry.get("external_import_baseline_payload")
            if isinstance(import_baseline, tuple) and len(import_baseline) == 3:
                payload_source = "external_import_baseline_payload"
                payload = import_baseline
        if guards and isinstance(payload, tuple) and len(payload) == 3:
            try:
                import numpy as np

                width, height, pixels = payload
                if int(image.size[0]) == int(width) and int(image.size[1]) == int(height):
                    rgba = np.asarray(pixels, dtype=np.float32).reshape(
                        (int(height), int(width), 4)
                    ) * (1.0 / 255.0)
                    image.pixels.foreach_set(np.ascontiguousarray(rgba).reshape((-1,)))
                    image.update()
                    _stamp_canvas(image, material, layer, layer_id, record_index, source_path)
                    process_entry.update({
                        "layer_id": str(layer_id or ""),
                        "record_index": int(record_index),
                        "image": str(image.name),
                    })
                    state.put_layer(material, layer_id, process_entry)
                    restored = True
                    _trace(
                        "mvp_paint_target_import_undo_rehydrated",
                        material=material,
                        layer_id=str(layer_id or ""),
                        record_index=int(record_index),
                        image=str(getattr(image, "name", "") or ""),
                        payload_source=payload_source,
                    )
            except Exception:
                pass
    repair = state.repair_external_import_baseline(
        material, layer_id, record_index, image
    )
    if bool(repair.get("repaired", False)):
        _trace(
            "mvp_paint_target_import_undo_repaired",
            material=material,
            layer_id=str(layer_id or ""),
            record_index=int(record_index),
            image=str(getattr(image, "name", "") or ""),
            rects=[list(rect) for rect in repair.get("rects", [])],
        )
    try:
        settings.active_layer_index = int(layer_index)
        settings.active_paint_channel = CHANNEL
    except Exception:
        pass
    canvas_ok = _bind_canvas(
        material, layer, image, layer_id, context, switch_to_paint=bool(switch_to_paint)
    )
    result = {
        "ok": bool(canvas_ok),
        "reason": "ok" if canvas_ok else "canvas_bind_failed",
        "material": str(getattr(material, "name", "") or ""),
        "channel": CHANNEL,
        "layer_index": int(layer_index),
        "layer_name": str(getattr(layer, "name", "") or ""),
        "layer_id": layer_id,
        "record_index": int(record_index),
        "image": str(getattr(image, "name", "") or ""),
        "image_size": [int(image.size[0]), int(image.size[1])],
        "source_restored": bool(restored),
        "elapsed_ms": round((time.perf_counter() - start) * 1000.0, 3),
        "retired_source_image": str(retired_source_image or ""),
    }
    _trace(
        "mvp_paint_target_activate",
        material=material,
        **{key: value for key, value in result.items() if key != "material"},
    )
    return result
