# SPDX-License-Identifier: GPL-3.0-or-later
"""Cache metadata for Blender-owned previews without a timer or a draw callback."""

from ..resource_quota import cache

__all__ = ("ensure", "cached_icon_id", "has_entry", "clear_material", "shutdown", "cache_size")

_previews = cache("layer_thumbnails.metadata")


def _identity(datablock):
    if datablock is None:
        return 0
    try:
        return int(datablock.as_pointer())
    except Exception:
        return id(datablock)


def _preview_key(material, layer_id, index, image):
    try:
        width, height = image.size
        if min(width, height) > 1:
            return (_identity(material), str(layer_id or ""), int(index), _identity(image))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return None


def _preview_icon(image, refresh):
    image.preview_ensure()
    if refresh and image.preview is not None:
        try:
            image.preview.reload()
        except Exception:
            pass
        image.preview_ensure()
    return int(getattr(image.preview, "icon_id", 0) or 0)


def ensure(material, layer_id, record_index, image, *, force=False):
    key = _preview_key(material, layer_id, record_index, image)
    if key is None:
        return dict(ok=False, reason="image_not_materialized", icon_id=0)
    if not force:
        previous = _previews.get(key)
        if previous is not None:
            return previous.copy()
    try:
        icon = _preview_icon(image, force)
    except Exception as exc:
        return dict(ok=False, reason="preview_generation_failed", error=repr(exc)[:300], icon_id=0)
    layer = key[:3]
    for previous_key in tuple(_previews):
        if previous_key[:3] == layer and previous_key != key:
            _previews.pop(previous_key, None)
    result = dict(ok=True, reason="generated", icon_id=icon, image=image.name, record_index=key[2])
    _previews.put(key, result.copy(), document_generation=str(key[0]))
    return result


def cached_icon_id(material, layer_id, record_index, image):
    key = _preview_key(material, layer_id, record_index, image)
    return _previews.get(key, {}).get("icon_id", 0) if key is not None else 0


def has_entry(material, layer_id, record_index, image):
    key = _preview_key(material, layer_id, record_index, image)
    return key is not None and key in _previews


def clear_material(material):
    owner = _identity(material)
    keys = [key for key in _previews if key[0] == owner]
    for key in keys:
        _previews.pop(key, None)
    return len(keys)


def shutdown():
    _previews.clear()


def cache_size():
    return len(_previews)
