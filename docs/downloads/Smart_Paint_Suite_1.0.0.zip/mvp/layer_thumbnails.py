# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Explicit, idle-free thumbnail cache for the lightweight layer list.

The module is imported only after the user enables thumbnails.  It owns no
handler, timer, keymap, worker, draw callback, or PSD decoder.  Blender builds
the preview from an image that is already materialized in memory.
"""

from __future__ import annotations

from .. import resource_quota


_CACHE = resource_quota.cache("layer_thumbnails.metadata")


def _pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return int(id(value)) if value is not None else 0


def _key(material, layer_id: str, record_index: int, image) -> tuple[int, str, int, int]:
    return (
        _pointer(material),
        str(layer_id or ""),
        int(record_index),
        _pointer(image),
    )


def _materialized(image) -> bool:
    try:
        return image is not None and int(image.size[0]) > 1 and int(image.size[1]) > 1
    except Exception:
        return False


def ensure(material, layer_id: str, record_index: int, image, *, force: bool = False) -> dict[str, object]:
    """Generate one Blender-managed preview after an explicit user action."""
    if not _materialized(image):
        return {"ok": False, "reason": "image_not_materialized", "icon_id": 0}
    key = _key(material, layer_id, record_index, image)
    cached = _CACHE.get(key)
    if cached is not None and not force:
        return dict(cached)
    try:
        image.preview_ensure()
        preview = getattr(image, "preview", None)
        if force and preview is not None:
            try:
                preview.reload()
            except Exception:
                pass
            image.preview_ensure()
            preview = getattr(image, "preview", None)
        icon_id = int(getattr(preview, "icon_id", 0) or 0)
    except Exception as exc:
        return {
            "ok": False,
            "reason": "preview_generation_failed",
            "error": repr(exc)[:300],
            "icon_id": 0,
        }
    # One entry per material/layer identity. A replaced datablock must not keep
    # the icon belonging to its predecessor.
    prefix = (_pointer(material), str(layer_id or ""), int(record_index))
    for stale in list(_CACHE):
        if stale[:3] == prefix and stale != key:
            _CACHE.pop(stale, None)
    result = {
        "ok": True,
        "reason": "generated",
        "icon_id": int(icon_id),
        "image": str(getattr(image, "name", "") or ""),
        "record_index": int(record_index),
    }
    _CACHE.put(
        key,
        dict(result),
        document_generation=str(_pointer(material)),
    )
    return result


def cached_icon_id(material, layer_id: str, record_index: int, image) -> int:
    """Read an existing cache entry; never generate a preview here."""
    if not _materialized(image):
        return 0
    try:
        return int((_CACHE.get(_key(material, layer_id, record_index, image)) or {}).get("icon_id", 0) or 0)
    except Exception:
        return 0


def has_entry(material, layer_id: str, record_index: int, image) -> bool:
    return _key(material, layer_id, record_index, image) in _CACHE if _materialized(image) else False


def clear_material(material) -> int:
    pointer = _pointer(material)
    removed = 0
    for key in list(_CACHE):
        if int(key[0]) == pointer:
            _CACHE.pop(key, None)
            removed += 1
    return int(removed)


def shutdown() -> None:
    _CACHE.clear()


def cache_size() -> int:
    return len(_CACHE)


__all__ = (
    "ensure",
    "cached_icon_id",
    "has_entry",
    "clear_material",
    "shutdown",
    "cache_size",
)
