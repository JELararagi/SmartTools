# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Process-local state for the lightweight PSD paint workflow."""

from __future__ import annotations

import hashlib
from typing import Any

from .. import resource_quota


# Kept as plain dictionaries because the established lightweight UI and save
# planner already consume this shape.  State is intentionally process-local so
# Blender undo cannot roll layer identity or dirty ownership backward.
ACTIVATED_LAYERS = resource_quota.cache("mvp.activated_layers")


def material_name(material) -> str:
    return str(getattr(material, "name", "") or "")


def _reaccount(material) -> None:
    name = material_name(material)
    if name:
        try:
            ACTIVATED_LAYERS.reaccount(name)
        except (AttributeError, resource_quota.CachePolicyError):
            pass


def layer_bucket(material, *, create: bool = True) -> dict[str, dict[str, Any]]:
    name = material_name(material)
    if not name:
        return {}
    if create:
        return ACTIVATED_LAYERS.setdefault(name, {})
    return ACTIVATED_LAYERS.get(name, {}) or {}


def get_layer(material, layer_id: str) -> dict[str, Any] | None:
    value = layer_bucket(material, create=False).get(str(layer_id or ""))
    return value if isinstance(value, dict) else None


def find_layer(
    material,
    layer_id: str = "",
    record_index: int = -1,
) -> tuple[str, dict[str, Any] | None]:
    """Resolve process state by session id, then durable PSD record identity."""
    bucket = layer_bucket(material, create=False)
    lid = str(layer_id or "")
    if lid:
        exact = bucket.get(lid)
        if isinstance(exact, dict):
            try:
                if int(record_index) < 0 or int(exact.get("record_index", -1)) == int(record_index):
                    return lid, exact
            except Exception:
                pass
    try:
        record = int(record_index)
    except Exception:
        record = -1
    if record < 0:
        return "", None
    matches = []
    for candidate_id, candidate in bucket.items():
        if not isinstance(candidate, dict):
            continue
        try:
            if int(candidate.get("record_index", -1)) == record:
                matches.append((str(candidate_id or ""), candidate))
        except Exception:
            continue
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        # Prefer the entry whose image still exists. Duplicate aliases are
        # cleaned by adopt_canvas below; this branch only handles old sessions.
        try:
            import bpy

            alive = [
                item for item in matches
                if bpy.data.images.get(str(item[1].get("image", "") or "")) is not None
            ]
            if len(alive) == 1:
                return alive[0]
        except Exception:
            pass
    return "", None


def put_layer(material, layer_id: str, entry: dict[str, Any]) -> dict[str, Any]:
    lid = str(layer_id or "")
    if not lid:
        raise ValueError("layer_id is required")
    value = dict(entry or {})
    value["layer_id"] = lid
    layer_bucket(material)[lid] = value
    _reaccount(material)
    return value


def promote_record_identity(material, layer_id: str, record_index: int, image=None) -> dict[str, Any]:
    """Advance a process-local canvas when a new PSD row gets its record id."""
    lid = str(layer_id or "")
    try:
        record = int(record_index)
    except Exception:
        record = -1
    entry = get_layer(material, lid)
    if not lid or record < 0 or entry is None:
        return {"ok": False, "reason": "layer_state_missing"}
    current_image = str(entry.get("image", "") or "")
    image_name = str(getattr(image, "name", "") or "") if image is not None else current_image
    if current_image and image_name and current_image != image_name:
        return {"ok": False, "reason": "canvas_mismatch"}
    try:
        previous_record = int(entry.get("record_index", -1))
    except Exception:
        previous_record = -1
    value = dict(entry)
    value["layer_id"] = lid
    value["record_index"] = record
    if image_name:
        value["image"] = image_name
    put_layer(material, lid, value)
    if image is not None:
        for key, item in (
            ("smart_paint_suite_layer_id", lid),
            ("smart_paint_suite_material", material_name(material)),
            ("sps_psd_source_order", record),
            ("sps_psd_source_ordinal", record),
            ("sps_psd_source_layer_index", record),
        ):
            try:
                image[key] = item
            except Exception:
                pass
    return {
        "ok": True,
        "reason": "record_identity_promoted",
        "layer_id": lid,
        "previous_record_index": previous_record,
        "record_index": record,
        "image": image_name,
    }


def adopt_canvas(material, layer_id: str, record_index: int, image) -> dict[str, Any] | None:
    """Re-key an existing layer state after Blender undo remints RNA ids.

    The PSD record index is stable across memfile undo. Pixel baselines and
    unsaved snapshots are process-local and therefore must follow that durable
    identity instead of being discarded with the old random layer id.
    """
    lid = str(layer_id or "")
    try:
        record = int(record_index)
    except Exception:
        record = -1
    previous_id, previous = find_layer(material, lid, record)
    if not lid or previous is None:
        return None
    value = dict(previous)
    value["layer_id"] = lid
    value["record_index"] = record
    if image is not None:
        value["image"] = str(getattr(image, "name", "") or "")
    bucket = layer_bucket(material)
    for candidate_id, candidate in list(bucket.items()):
        try:
            same_record = record >= 0 and int((candidate or {}).get("record_index", -1)) == record
        except Exception:
            same_record = False
        if str(candidate_id or "") == str(previous_id or "") or same_record:
            bucket.pop(candidate_id, None)
    bucket[lid] = value
    _reaccount(material)
    if image is not None:
        for key, item in (
            ("smart_paint_suite_layer_id", lid),
            ("smart_paint_suite_material", material_name(material)),
            ("sps_psd_source_order", record),
            ("sps_psd_source_ordinal", record),
            ("sps_psd_source_layer_index", record),
        ):
            if record < 0 and key.startswith("sps_psd_source_"):
                continue
            try:
                image[key] = item
            except Exception:
                pass
    return {
        "entry": value,
        "previous_layer_id": str(previous_id or ""),
        "layer_id": lid,
        "record_index": record,
    }


def remove_layer(material, layer_id: str) -> None:
    layer_bucket(material, create=False).pop(str(layer_id or ""), None)
    _reaccount(material)


def clear_document(material) -> None:
    ACTIVATED_LAYERS.pop(material_name(material), None)


def clear_all() -> None:
    ACTIVATED_LAYERS.clear()


def matching_canvas(material, layer_id: str, record_index: int):
    """Return the exact session canvas if its durable identity still matches."""
    resolved_id, entry = find_layer(material, layer_id, record_index)
    if not entry:
        return None
    try:
        if int(entry.get("record_index", -1)) != int(record_index):
            return None
    except Exception:
        return None
    try:
        import bpy

        image = bpy.data.images.get(str(entry.get("image", "") or ""))
    except Exception:
        image = None
    if image is None:
        return None
    try:
        if int(image.get("sps_psd_source_order", -1)) != int(record_index):
            return None
        if not bool(image.get("sps_mvp_native_canvas", False)):
            return None
    except Exception:
        return None
    if str(resolved_id or "") != str(layer_id or "") or str(
        image.get("smart_paint_suite_layer_id", "") or ""
    ) != str(layer_id or ""):
        if adopt_canvas(material, layer_id, record_index, image) is None:
            return None
    return image


def repair_external_import_baseline(
    material,
    layer_id: str,
    record_index: int,
    image,
) -> dict[str, Any]:
    """Repair only imported regions that memfile undo restored exactly.

    External import is a baseline transition, not a native paint stroke. Blender
    global undo can nevertheless roll an imported Image datablock back to its
    pre-import pixels. The process-local guards survive that rollback. A region
    is repaired only when its current byte hash is exactly the recorded
    pre-import hash; arbitrary local paint is therefore left untouched.
    """
    resolved_id, entry = find_layer(material, layer_id, record_index)
    guards = list((entry or {}).get("external_import_undo_guards") or [])
    payload_source = "external_import_baseline_payload"
    payload = (entry or {}).get(payload_source)
    if not isinstance(payload, tuple) or len(payload) != 3:
        payload_source = "baseline_payload"
        payload = (entry or {}).get(payload_source)
    if not isinstance(payload, tuple) or len(payload) != 3:
        # Compatibility for process state created by the first D5 candidate.
        # New imports always retain the dedicated immutable baseline above.
        payload_source = "current_payload"
        payload = (entry or {}).get(payload_source)
    if image is None or not guards or not isinstance(payload, tuple) or len(payload) != 3:
        return {
            "ok": True,
            "repaired": False,
            "reason": "no_import_guard",
            "payload_source": payload_source,
        }
    try:
        import numpy as np

        width, height = int(image.size[0]), int(image.size[1])
        payload_width, payload_height, payload_pixels = payload
        if int(payload_width) != width or int(payload_height) != height:
            return {
                "ok": False,
                "repaired": False,
                "reason": "guard_payload_size_mismatch",
                "payload_source": payload_source,
            }
        expected = np.asarray(payload_pixels, dtype=np.uint8).reshape((height, width, 4))
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        current = np.ascontiguousarray(
            np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        repaired_rects = []
        for guard in guards:
            try:
                x0, y0, x1, y1 = (int(value) for value in tuple(guard.get("rect_blender", ()))[:4])
            except Exception:
                continue
            if x0 < 0 or y0 < 0 or x1 > width or y1 > height or x1 <= x0 or y1 <= y0:
                continue
            probes = list(guard.get("before_probes") or [])
            probe_rejected = False
            for probe in probes:
                try:
                    px, py, r, g, b, a = (int(value) for value in tuple(probe)[:6])
                except Exception:
                    continue
                if not (0 <= px < x1 - x0 and 0 <= py < y1 - y0):
                    continue
                if tuple(int(value) for value in current[y0 + py, x0 + px]) != (r, g, b, a):
                    probe_rejected = True
                    break
            if probe_rejected:
                continue
            region = np.ascontiguousarray(current[y0:y1, x0:x1], dtype=np.uint8)
            current_hash = hashlib.sha256(region.tobytes()).hexdigest()
            before_hash = str(guard.get("before_sha256", "") or "")
            after_hash = str(guard.get("after_sha256", "") or "")
            if not before_hash or before_hash == after_hash or current_hash != before_hash:
                continue
            replacement = np.ascontiguousarray(expected[y0:y1, x0:x1], dtype=np.uint8)
            replacement_hash = hashlib.sha256(replacement.tobytes()).hexdigest()
            # A later external import may advance the same region again. The
            # exact pre-import hash is the safety gate; restore the latest
            # external baseline rather than requiring the first guard's old
            # after hash. Never write a stale baseline that still equals the
            # rolled-back bytes.
            restore_hash = str(guard.get("restore_sha256", "") or after_hash)
            if replacement_hash == before_hash or replacement_hash != restore_hash:
                continue
            current[y0:y1, x0:x1] = replacement
            repaired_rects.append((x0, y0, x1, y1))
        if not repaired_rects:
            return {
                "ok": True,
                "repaired": False,
                "reason": "guard_not_rolled_back",
                "payload_source": payload_source,
                "current_u8": (width, height, current),
            }
        image.pixels.foreach_set(
            np.ascontiguousarray(current.astype(np.float32) * (1.0 / 255.0), dtype=np.float32).reshape((-1,))
        )
        image.update()
        adopted = adopt_canvas(material, layer_id, record_index, image)
        return {
            "ok": True,
            "repaired": True,
            "reason": "pre_import_pixels_restored",
            "record_index": int(record_index),
            "layer_id": str(layer_id or resolved_id or ""),
            "rects": repaired_rects,
            "adopted": bool(adopted is not None),
            "payload_source": payload_source,
            "current_u8": (width, height, current),
        }
    except Exception as exc:
        return {
            "ok": False,
            "repaired": False,
            "reason": "import_guard_repair_exception",
            "error": repr(exc)[:300],
            "payload_source": payload_source,
        }


def capture_canvas(material, layer_id: str, image) -> tuple[int, int, Any] | None:
    """Capture current pixels without mutating the Blender image."""
    if image is None:
        return None
    try:
        import numpy as np

        width, height = int(image.size[0]), int(image.size[1])
        if width <= 1 or height <= 1:
            return None
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        pixels = np.ascontiguousarray(
            np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        entry = dict(get_layer(material, layer_id) or {})
        entry.update({
            "layer_id": str(layer_id or ""),
            "image": str(getattr(image, "name", "") or ""),
            "current_payload": (width, height, pixels),
        })
        put_layer(material, layer_id, entry)
        return width, height, pixels
    except Exception:
        return None
