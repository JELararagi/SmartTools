# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Selection-aware pixel editing for the lightweight PSD workflow."""


import math
import time
import uuid
import zlib
from typing import Any

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty


# History/clipboard stacks retain metadata only.  Compressed pixel payloads live
# in the Suite-wide count+actual-byte LRU so Review, PSD, composite and editing
# caches cannot each consume an independent memory allowance.
from .. import resource_quota

_HISTORY: dict[str, list[dict[str, Any]]] = {}
_REDO: dict[str, list[dict[str, Any]]] = {}
_CLIPBOARD: dict[str, Any] | None = None
_MAX_HISTORY_STEPS = 6
_HISTORY_CACHE = resource_quota.cache("editing.history")
_CLIPBOARD_CACHE = resource_quota.cache("editing.clipboard")
GRADIENT_ITEMS = (
    ("LINEAR", "線形", "始点から終点へ直線的に変化します"),
    ("RADIAL", "放射", "始点を中心に円状に変化します"),
    ("ANGLE", "角度", "始点を中心に一周して変化します"),
    ("REFLECTED", "反射", "始点から両方向へ対称に変化します"),
    ("DIAMOND", "ダイヤ", "始点を中心に菱形状に変化します"),
)


def _resolve_material(context=None):
    try:
        from .. import lightweight_mvp

        return lightweight_mvp._resolve_material(context)
    except Exception:
        return None


def _target(context=None, *, allow_empty_selection: bool = False):
    material = _resolve_material(context)
    if material is None:
        return None, None, None, "material_missing"
    try:
        display_mode = str(material.get("sps_lightweight_display_mode", "") or "")
    except Exception:
        display_mode = ""
    if display_mode == "COMPOSITE_PREVIEW":
        return material, None, None, "full_review_read_only"
    try:
        from . import selection_tools

        image = selection_tools._operator_canvas(context, material)
    except Exception:
        image = None
    if image is None:
        return material, None, None, "editable_canvas_missing"
    width, height = int(image.size[0]), int(image.size[1])
    try:
        from . import selection_tools

        selection = selection_tools.mask_array(material, width, height)
    except Exception:
        selection = None
    if selection is not None:
        import numpy as np

        if not allow_empty_selection and not bool(np.any(selection > np.float32(0.0))):
            return material, image, selection, "selection_empty"
        if bool(np.all(selection >= np.float32(1.0))):
            selection = None
    return material, image, selection, ""


def _image_key(image) -> str:
    return str(getattr(image, "name_full", "") or getattr(image, "name", "") or "")


def _read_u8(image):
    import numpy as np

    width, height = int(image.size[0]), int(image.size[1])
    flat = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(flat)
    pixels = np.ascontiguousarray(
        np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
        dtype=np.uint8,
    )
    del flat
    return pixels


def _write_u8(image, pixels) -> None:
    import numpy as np

    values = np.ascontiguousarray(pixels, dtype=np.float32)
    values *= np.float32(1.0 / 255.0)
    image.pixels.foreach_set(values.reshape((-1,)))
    image.update()
    del values


def _drop_snapshot(snapshot: dict[str, Any] | None) -> None:
    token = str((snapshot or {}).get("token", "") or "")
    if token:
        _HISTORY_CACHE.pop(token, None)


def _pack_snapshot(image, pixels, label: str) -> dict[str, Any] | None:
    import numpy as np

    data = np.ascontiguousarray(pixels, dtype=np.uint8)
    payload = zlib.compress(data.tobytes(order="C"), level=1)
    token = f"history:{uuid.uuid4()}"
    document_generation = _image_key(image)
    if not _HISTORY_CACHE.put(
        token,
        payload,
        document_generation=document_generation,
    ):
        return None
    return {
        "width": int(data.shape[1]),
        "height": int(data.shape[0]),
        "token": token,
        "payload_bytes": len(payload),
        "label": str(label or ""),
        "created": time.monotonic(),
        "document_generation": document_generation,
    }


def _unpack_snapshot(snapshot):
    import numpy as np

    width = int(snapshot["width"])
    height = int(snapshot["height"])
    token = str(snapshot.get("token", "") or "")
    compressed = _HISTORY_CACHE.get(token) if token else None
    if not isinstance(compressed, (bytes, bytearray, memoryview)):
        raise ValueError("history_snapshot_evicted")
    raw = zlib.decompress(compressed)
    expected = width * height * 4
    if len(raw) != expected:
        raise ValueError("history_snapshot_size_mismatch")
    return np.frombuffer(raw, dtype=np.uint8).reshape((height, width, 4)).copy()


def _snapshot_available(snapshot: dict[str, Any]) -> bool:
    token = str(snapshot.get("token", "") or "")
    return bool(token and token in _HISTORY_CACHE)


def _trim_history() -> None:
    for collection in (_HISTORY, _REDO):
        for key in list(collection):
            stack = collection.get(key) or []
            retained = [item for item in stack if _snapshot_available(item)]
            while len(retained) > _MAX_HISTORY_STEPS:
                _drop_snapshot(retained.pop(0))
            if retained:
                collection[key] = retained
            else:
                collection.pop(key, None)


def _push_history(image, pixels, label: str) -> bool:
    key = _image_key(image)
    snapshot = _pack_snapshot(image, pixels, label)
    if snapshot is None:
        return False
    for stale in _REDO.pop(key, ()):  # a new edit invalidates redo payloads
        _drop_snapshot(stale)
    _HISTORY.setdefault(key, []).append(snapshot)
    _trim_history()
    return _snapshot_available(snapshot)


def _push_redo(image, pixels, label: str) -> dict[str, Any] | None:
    key = _image_key(image)
    snapshot = _pack_snapshot(image, pixels, label)
    if snapshot is None:
        return None
    _REDO.setdefault(key, []).append(snapshot)
    _trim_history()
    return snapshot


def _changed_info(before, after) -> dict[str, Any]:
    import numpy as np

    changed = np.any(before != after, axis=2)
    ys, xs = np.nonzero(changed)
    return {
        "pixels": int(changed.sum()),
        "bbox": (
            [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]
            if xs.size
            else None
        ),
    }


def _tag_redraw() -> None:
    try:
        from .. import lightweight_mvp

        lightweight_mvp._tag_redraw(bpy.context)
    except Exception:
        try:
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type in {"IMAGE_EDITOR", "VIEW_3D"}:
                        area.tag_redraw()
        except Exception:
            pass


def _record_result(material, operation: str, elapsed: float, info: dict[str, Any]) -> None:
    try:
        material["sps_edit_last_operation"] = str(operation)
        material["sps_edit_last_ms"] = round(float(elapsed) * 1000.0, 3)
        material["sps_edit_last_pixels"] = int(info.get("pixels", 0) or 0)
        material["sps_edit_last_bbox"] = list(info.get("bbox") or [])
        material["sps_edit_last_ok"] = bool(
            int(info.get("pixels", 0) or 0) > 0 and float(elapsed) < 10.0
        )
    except Exception:
        pass


def _commit(material, image, before, after, operation: str, started: float) -> dict[str, Any]:
    info = _changed_info(before, after)
    if int(info["pixels"]) <= 0:
        return {"ok": False, "reason": "no_pixel_change — 画素は変更されませんでした。", **info}
    if not _push_history(image, before, operation):
        return {"ok": False, "reason": "undo_snapshot_budget_exceeded", **info}
    try:
        _write_u8(image, after)
    except Exception:
        key = _image_key(image)
        stack = _HISTORY.get(key) or []
        if stack:
            _drop_snapshot(stack.pop())
        if not stack:
            _HISTORY.pop(key, None)
        raise
    # Save reads a wide alpha-only change as Blender's first-stroke artifact unless
    # it knows an edit made it, as when a white fill only raises alpha.
    try:
        import numpy as np

        raised = int(np.count_nonzero((before[:, :, 3] == 0) & (after[:, :, 3] > 0)))
        if raised > max(65536, (int(before.shape[0]) * int(before.shape[1])) // 100):
            image["sps_lightweight_explicit_alpha_edit"] = True
    except (AttributeError, IndexError, RuntimeError, TypeError):
        pass
    elapsed = time.perf_counter() - started
    _record_result(material, operation, elapsed, info)
    _tag_redraw()
    return {"ok": elapsed < 10.0, "elapsed": elapsed, **info}


def _linear_to_srgb(values):
    import numpy as np

    linear = np.clip(np.asarray(values, dtype=np.float32), 0.0, 1.0)
    return np.where(
        linear <= np.float32(0.0031308),
        linear * np.float32(12.92),
        np.float32(1.055) * np.power(linear, np.float32(1.0 / 2.4)) - np.float32(0.055),
    )


def _blend_replace(before, target, selection):
    import numpy as np

    if selection is None:
        after = np.empty_like(before)
        after[:, :, :] = target
        return after
    weight = np.asarray(selection, dtype=np.float32)[:, :, None]
    mixed = (
        before.astype(np.float32) * (np.float32(1.0) - weight)
        + np.asarray(target, dtype=np.float32)[None, None, :] * weight
    )
    return np.ascontiguousarray(np.clip(np.floor(mixed + 0.5), 0.0, 255.0), dtype=np.uint8)


def _gradient_pixels(
    before,
    selection,
    p0,
    p1,
    start_rgba,
    end_rgba,
    gradient_type: str,
):
    """Generate a selection-aware gradient in bounded row chunks."""
    import numpy as np

    height, width = int(before.shape[0]), int(before.shape[1])
    x0, y0 = np.float32(p0[0]), np.float32(p0[1])
    dx = np.float32(float(p1[0]) - float(p0[0]))
    dy = np.float32(float(p1[1]) - float(p0[1]))
    length_sq = np.float32(dx * dx + dy * dy)
    if float(length_sq) < 1.0e-6:
        return before.copy()
    length = np.float32(np.sqrt(length_sq))
    ux, uy = dx / length, dy / length
    mode = str(gradient_type or "LINEAR").upper()
    start = np.asarray(start_rgba, dtype=np.float32)
    end = np.asarray(end_rgba, dtype=np.float32)
    delta = end - start
    x_values = np.arange(width, dtype=np.float32)[None, :]
    after = before.copy()
    for row0 in range(0, height, 128):
        row1 = min(height, row0 + 128)
        y_values = np.arange(row0, row1, dtype=np.float32)[:, None]
        rel_x = x_values - x0
        rel_y = y_values - y0
        projection = (rel_x * dx + rel_y * dy) / length_sq
        if mode == "RADIAL":
            factor = np.sqrt(rel_x * rel_x + rel_y * rel_y) / length
        elif mode == "ANGLE":
            base_angle = np.arctan2(dy, dx)
            factor = np.mod(
                (np.arctan2(rel_y, rel_x) - base_angle) / np.float32(math.tau),
                np.float32(1.0),
            )
        elif mode == "REFLECTED":
            factor = np.abs(projection)
        elif mode == "DIAMOND":
            local_x = rel_x * ux + rel_y * uy
            local_y = -rel_x * uy + rel_y * ux
            factor = (np.abs(local_x) + np.abs(local_y)) / length
        else:
            factor = projection
        factor = np.clip(factor, 0.0, 1.0).astype(np.float32, copy=False)
        target = start[None, None, :] + factor[:, :, None] * delta[None, None, :]
        if selection is None:
            mixed = target
        else:
            weight = np.asarray(selection[row0:row1], dtype=np.float32)[:, :, None]
            mixed = before[row0:row1].astype(np.float32) * (np.float32(1.0) - weight) + target * weight
        after[row0:row1] = np.ascontiguousarray(
            np.clip(np.floor(mixed + np.float32(0.5)), 0.0, 255.0),
            dtype=np.uint8,
        )
    return after

def _alpha_over(base, source):
    import numpy as np

    base_f = base.astype(np.float32) * np.float32(1.0 / 255.0)
    source_f = source.astype(np.float32) * np.float32(1.0 / 255.0)
    source_alpha = source_f[:, :, 3:4]
    base_alpha = base_f[:, :, 3:4]
    out_alpha = source_alpha + base_alpha * (np.float32(1.0) - source_alpha)
    premultiplied = (
        source_f[:, :, :3] * source_alpha
        + base_f[:, :, :3] * base_alpha * (np.float32(1.0) - source_alpha)
    )
    out_rgb = base_f[:, :, :3].copy()
    np.divide(
        premultiplied,
        np.maximum(out_alpha, np.float32(1.0 / 65535.0)),
        out=out_rgb,
        where=out_alpha > np.float32(0.0),
    )
    output = np.concatenate((out_rgb, out_alpha), axis=2)
    return np.ascontiguousarray(
        np.clip(np.floor(output * np.float32(255.0) + 0.5), 0.0, 255.0),
        dtype=np.uint8,
    )


def _split_payload(before, selection):
    import numpy as np

    if selection is None:
        base = np.empty_like(before)
        base[:, :, :3] = np.uint8(255)
        base[:, :, 3] = np.uint8(0)
        return base, before.copy()
    weight = np.asarray(selection, dtype=np.float32)
    payload = before.copy()
    base = before.copy()
    payload[:, :, 3] = np.clip(
        np.floor(before[:, :, 3].astype(np.float32) * weight + 0.5),
        0.0,
        255.0,
    ).astype(np.uint8)
    base[:, :, 3] = np.clip(
        np.floor(before[:, :, 3].astype(np.float32) * (np.float32(1.0) - weight) + 0.5),
        0.0,
        255.0,
    ).astype(np.uint8)
    return base, payload


def _content_bbox(pixels, selection=None):
    import numpy as np

    if selection is None:
        active = pixels[:, :, 3] > 0
    else:
        active = np.asarray(selection, dtype=np.float32) > np.float32(0.0)
    ys, xs = np.nonzero(active)
    if not xs.size:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def _empty_canvas_like(pixels):
    import numpy as np

    output = np.empty_like(pixels)
    output[:, :, :3] = np.uint8(255)
    output[:, :, 3] = np.uint8(0)
    return output


def _place_region(canvas, region, center_x: float, center_y: float):
    width = int(region.shape[1])
    height = int(region.shape[0])
    x0 = int(round(float(center_x) - width * 0.5))
    y0 = int(round(float(center_y) - height * 0.5))
    x1, y1 = x0 + width, y0 + height
    dst_x0, dst_y0 = max(0, x0), max(0, y0)
    dst_x1, dst_y1 = min(int(canvas.shape[1]), x1), min(int(canvas.shape[0]), y1)
    if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
        return canvas
    src_x0, src_y0 = dst_x0 - x0, dst_y0 - y0
    src_x1, src_y1 = src_x0 + (dst_x1 - dst_x0), src_y0 + (dst_y1 - dst_y0)
    canvas[dst_y0:dst_y1, dst_x0:dst_x1] = region[src_y0:src_y1, src_x0:src_x1]
    return canvas


def _premultiplied_source(region):
    import numpy as np

    source = np.ascontiguousarray(region, dtype=np.float32)
    source *= np.float32(1.0 / 255.0)
    source[:, :, :3] *= source[:, :, 3:4]
    return source


def _encode_premultiplied(sample):
    import numpy as np

    alpha = np.clip(sample[:, :, 3:4], 0.0, 1.0)
    rgb = np.ones(sample[:, :, :3].shape, dtype=np.float32)
    np.divide(
        sample[:, :, :3],
        np.maximum(alpha, np.float32(1.0 / 65535.0)),
        out=rgb,
        where=alpha > np.float32(0.0),
    )
    rgba = np.concatenate((np.clip(rgb, 0.0, 1.0), alpha), axis=2)
    return np.ascontiguousarray(
        np.clip(np.floor(rgba * np.float32(255.0) + 0.5), 0.0, 255.0),
        dtype=np.uint8,
    )


def _resize_bilinear(region, output_width: int, output_height: int):
    import numpy as np

    source = _premultiplied_source(region)
    source_height, source_width = int(source.shape[0]), int(source.shape[1])
    output_width = max(1, int(output_width))
    output_height = max(1, int(output_height))
    if (source_width, source_height) == (output_width, output_height):
        return np.ascontiguousarray(region, dtype=np.uint8)
    x = (np.arange(output_width, dtype=np.float32) + np.float32(0.5))
    x *= np.float32(source_width / output_width)
    x -= np.float32(0.5)
    x = np.clip(x, 0.0, float(max(0, source_width - 1)))
    x0 = np.floor(x).astype(np.int32)
    x1 = np.minimum(x0 + 1, source_width - 1)
    wx = (x - x0.astype(np.float32))[None, :, None]
    output = np.empty((output_height, output_width, 4), dtype=np.uint8)
    for row0 in range(0, output_height, 128):
        row1 = min(output_height, row0 + 128)
        y = (np.arange(row0, row1, dtype=np.float32) + np.float32(0.5))
        y *= np.float32(source_height / output_height)
        y -= np.float32(0.5)
        y = np.clip(y, 0.0, float(max(0, source_height - 1)))
        y0 = np.floor(y).astype(np.int32)
        y1 = np.minimum(y0 + 1, source_height - 1)
        wy = (y - y0.astype(np.float32))[:, None, None]
        top = source[y0[:, None], x0[None, :]] * (np.float32(1.0) - wx)
        top += source[y0[:, None], x1[None, :]] * wx
        bottom = source[y1[:, None], x0[None, :]] * (np.float32(1.0) - wx)
        bottom += source[y1[:, None], x1[None, :]] * wx
        sample = top * (np.float32(1.0) - wy) + bottom * wy
        output[row0:row1] = _encode_premultiplied(sample)
    return output


def _rotate_bilinear(region, degrees: float):
    import math
    import numpy as np

    source = _premultiplied_source(region)
    source_height, source_width = int(source.shape[0]), int(source.shape[1])
    radians = math.radians(float(degrees))
    cosine, sine = math.cos(radians), math.sin(radians)
    output_width = max(1, int(math.ceil(abs(source_width * cosine) + abs(source_height * sine))))
    output_height = max(1, int(math.ceil(abs(source_height * cosine) + abs(source_width * sine))))
    output = np.empty((output_height, output_width, 4), dtype=np.uint8)
    output[:, :, :3] = np.uint8(255)
    output[:, :, 3] = np.uint8(0)
    destination_x = np.arange(output_width, dtype=np.float32) - np.float32((output_width - 1) * 0.5)
    source_cx = np.float32((source_width - 1) * 0.5)
    source_cy = np.float32((source_height - 1) * 0.5)
    for row0 in range(0, output_height, 128):
        row1 = min(output_height, row0 + 128)
        destination_y = np.arange(row0, row1, dtype=np.float32) - np.float32((output_height - 1) * 0.5)
        dx = destination_x[None, :]
        dy = destination_y[:, None]
        source_x = np.float32(cosine) * dx + np.float32(sine) * dy + source_cx
        source_y = -np.float32(sine) * dx + np.float32(cosine) * dy + source_cy
        valid = (
            (source_x >= 0.0)
            & (source_x <= float(source_width - 1))
            & (source_y >= 0.0)
            & (source_y <= float(source_height - 1))
        )
        sx = np.clip(source_x, 0.0, float(max(0, source_width - 1)))
        sy = np.clip(source_y, 0.0, float(max(0, source_height - 1)))
        x0 = np.floor(sx).astype(np.int32)
        y0 = np.floor(sy).astype(np.int32)
        x1 = np.minimum(x0 + 1, source_width - 1)
        y1 = np.minimum(y0 + 1, source_height - 1)
        wx = (sx - x0.astype(np.float32))[:, :, None]
        wy = (sy - y0.astype(np.float32))[:, :, None]
        top = source[y0, x0] * (np.float32(1.0) - wx) + source[y0, x1] * wx
        bottom = source[y1, x0] * (np.float32(1.0) - wx) + source[y1, x1] * wx
        sample = top * (np.float32(1.0) - wy) + bottom * wy
        sample[~valid] = np.float32(0.0)
        output[row0:row1] = _encode_premultiplied(sample)
    return output


def _affine_transform(region, *, scale: float = 1.0, degrees: float = 0.0, max_pixels: int):
    import math

    source_height, source_width = int(region.shape[0]), int(region.shape[1])
    scaled_width = max(1, int(round(source_width * float(scale))))
    scaled_height = max(1, int(round(source_height * float(scale))))
    radians = math.radians(float(degrees))
    projected_width = max(
        1,
        int(math.ceil(abs(scaled_width * math.cos(radians)) + abs(scaled_height * math.sin(radians)))),
    )
    projected_height = max(
        1,
        int(math.ceil(abs(scaled_height * math.cos(radians)) + abs(scaled_width * math.sin(radians)))),
    )
    if (
        projected_width > 16384
        or projected_height > 16384
        or projected_width * projected_height > int(max_pixels)
    ):
        raise ValueError("transform_size_budget")
    transformed = _resize_bilinear(region, scaled_width, scaled_height)
    normalized = float(degrees) % 360.0
    if min(abs(normalized), abs(normalized - 360.0)) <= 1.0e-6:
        return transformed
    return _rotate_bilinear(transformed, float(degrees))


def _transform_pixels(before, selection, *, kind: str, dx=0, dy=0, scale=1.0, degrees=0.0):
    import numpy as np

    bbox = _content_bbox(before, selection)
    if bbox is None:
        return before.copy()
    x0, y0, x1, y1 = bbox
    base, payload = _split_payload(before, selection)
    region = payload[y0:y1, x0:x1].copy()
    operation = str(kind or "").upper()
    if operation == "FLIP_H":
        region = np.ascontiguousarray(region[:, ::-1])
    elif operation == "FLIP_V":
        region = np.ascontiguousarray(region[::-1, :])
    elif operation == "ROTATE_90_CW":
        region = np.ascontiguousarray(np.rot90(region, k=3))
    elif operation == "ROTATE_90_CCW":
        region = np.ascontiguousarray(np.rot90(region, k=1))
    elif operation == "ROTATE_180":
        region = np.ascontiguousarray(np.rot90(region, k=2))
    elif operation == "AFFINE":
        region = _affine_transform(
            region,
            scale=float(scale),
            degrees=float(degrees),
            max_pixels=max(int(before.shape[0] * before.shape[1] * 2), 4 * 1024 * 1024),
        )
    transformed = _empty_canvas_like(before)
    center_x = (x0 + x1) * 0.5 + int(dx)
    center_y = (y0 + y1) * 0.5 + int(dy)
    _place_region(transformed, region, center_x, center_y)
    return _alpha_over(base, transformed)


def clear_document_state(_material=None) -> None:
    for collection in (_HISTORY, _REDO):
        for stack in collection.values():
            for snapshot in stack:
                _drop_snapshot(snapshot)
        collection.clear()
    _HISTORY_CACHE.clear()


def _clear_clipboard() -> None:
    global _CLIPBOARD
    metadata = _CLIPBOARD or {}
    for field in ("pixels_token", "mask_token"):
        token = str(metadata.get(field, "") or "")
        if token:
            _CLIPBOARD_CACHE.pop(token, None)
    _CLIPBOARD = None
    _CLIPBOARD_CACHE.clear()


def shutdown() -> None:
    clear_document_state()
    _clear_clipboard()


class _EditOperator:
    def _target_or_report(self, context, *, allow_empty_selection: bool = False):
        material, image, selection, reason = _target(
            context, allow_empty_selection=allow_empty_selection,
        )
        if reason:
            messages = {
                "full_review_read_only": "全体確認は閲覧専用です。",
                "selection_empty": "選択範囲が空です。",
                "editable_canvas_missing": "編集可能なアクティブレイヤーがありません。",
            }
            self.report({"WARNING"}, _rpt(messages.get(reason, "編集対象がありません。")))
            return None, None, None
        return material, image, selection

    def _finish(self, result):
        if not result.get("ok"):
            self.report({"WARNING"}, _rpt_msg(result.get("reason") or "画素は変更されませんでした。"))
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"{int(result.get('pixels', 0)):,} px / {float(result.get('elapsed', 0.0)):.2f}s",
        )
        return {"FINISHED"}


class SPS_OT_lightweight_edit_fill(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_fill"
    bl_label = "塗りつぶし"
    bl_description = "現在の色で選択範囲またはアクティブレイヤー全体を塗りつぶします"
    bl_options = set()

    color: FloatVectorProperty(
        size=3,
        subtype="COLOR",
        min=0.0,
        max=1.0,
        default=(0.8, 0.2, 0.2),
        options={"SKIP_SAVE"},
    )
    alpha: FloatProperty(default=1.0, min=0.0, max=1.0, options={"SKIP_SAVE"})

    def execute(self, context):
        import numpy as np

        material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        started = time.perf_counter()
        before = _read_u8(image)
        rgb = np.clip(np.floor(_linear_to_srgb(self.color) * 255.0 + 0.5), 0.0, 255.0)
        target = np.array(
            [rgb[0], rgb[1], rgb[2], round(float(self.alpha) * 255.0)],
            dtype=np.uint8,
        )
        after = _blend_replace(before, target, selection)
        return self._finish(_commit(material, image, before, after, "fill", started))



class SPS_OT_lightweight_edit_gradient(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_gradient"
    bl_label = "グラデーション"
    bl_description = "画像ビューでドラッグし、選択範囲またはアクティブレイヤーへグラデーションを描画します"
    bl_options = set()

    gradient_type: EnumProperty(items=GRADIENT_ITEMS, default="LINEAR", options={"SKIP_SAVE"})
    start_color: FloatVectorProperty(
        size=3,
        subtype="COLOR",
        min=0.0,
        max=1.0,
        default=(0.8, 0.2, 0.2),
        options={"SKIP_SAVE"},
    )
    end_color: FloatVectorProperty(
        size=3,
        subtype="COLOR",
        min=0.0,
        max=1.0,
        default=(0.12, 0.32, 0.9),
        options={"SKIP_SAVE"},
    )
    start_alpha: FloatProperty(default=1.0, min=0.0, max=1.0, options={"SKIP_SAVE"})
    end_alpha: FloatProperty(default=1.0, min=0.0, max=1.0, options={"SKIP_SAVE"})
    use_coordinates: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    x0: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    y0: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    x1: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    y1: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})

    def execute(self, context):
        import numpy as np

        material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        if not bool(self.use_coordinates):
            self.report({"WARNING"}, _rpt("画像ビュー上で始点から終点までドラッグしてください。"))
            return {"CANCELLED"}
        if int(self.x0) == int(self.x1) and int(self.y0) == int(self.y1):
            self.report({"WARNING"}, _rpt("グラデーションの長さがありません。"))
            return {"CANCELLED"}
        started = time.perf_counter()
        before = _read_u8(image)
        start_rgb = np.clip(
            np.floor(_linear_to_srgb(self.start_color) * 255.0 + 0.5),
            0.0,
            255.0,
        )
        end_rgb = np.clip(
            np.floor(_linear_to_srgb(self.end_color) * 255.0 + 0.5),
            0.0,
            255.0,
        )
        start_rgba = np.array(
            [start_rgb[0], start_rgb[1], start_rgb[2], round(float(self.start_alpha) * 255.0)],
            dtype=np.float32,
        )
        end_rgba = np.array(
            [end_rgb[0], end_rgb[1], end_rgb[2], round(float(self.end_alpha) * 255.0)],
            dtype=np.float32,
        )
        after = _gradient_pixels(
            before,
            selection,
            (int(self.x0), int(self.y0)),
            (int(self.x1), int(self.y1)),
            start_rgba,
            end_rgba,
            self.gradient_type,
        )
        return self._finish(_commit(material, image, before, after, "gradient", started))

    def invoke(self, context, event):
        if bool(self.use_coordinates):
            return self.execute(context)
        material, image, _selection = self._target_or_report(context)
        try:
            from . import selection_tools

            window_region = selection_tools._window_region(context)
        except Exception:
            window_region = None
        if image is None or window_region is None:
            self.report({"WARNING"}, _rpt("画像ビューからグラデーションを開始してください。"))
            return {"CANCELLED"}
        self._material_name = str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
        self._width = int(image.size[0])
        self._height = int(image.size[1])
        self._waiting = True
        self._dragging = False
        self._start = (0, 0)
        context.window_manager.modal_handler_add(self)
        try:
            context.window.cursor_modal_set("CROSSHAIR")
            context.area.header_text_set(_rpt("始点から終点までドラッグ。Escで取消"))
        except Exception:
            pass
        return {"RUNNING_MODAL"}

    def _finish_modal(self, context):
        try:
            from . import selection_tools

            selection_tools.clear_drag_guide()
        except Exception:
            pass
        try:
            context.window.cursor_modal_restore()
            context.area.header_text_set(None)
        except Exception:
            pass

    def _guide(self, context, event):
        from . import selection_tools

        point = selection_tools._event_image_xy(context, event, self._width, self._height)
        material = bpy.data.materials.get(str(getattr(self, "_material_name", "") or ""))
        if material is not None:
            selection_tools.set_drag_guide(
                material,
                self._width,
                self._height,
                (self._start, point),
                color_a=(0.02, 0.12, 0.42, 1.0),
                color_b=(0.7, 0.9, 1.0, 1.0),
            )
        return point

    def modal(self, context, event):
        from . import selection_tools

        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish_modal(context)
            return {"CANCELLED"}
        if bool(getattr(self, "_waiting", False)):
            if (
                event.type == "LEFTMOUSE"
                and event.value == "PRESS"
                and selection_tools._inside_image_window(context, event)
            ):
                self._waiting = False
                self._dragging = True
                self._start = selection_tools._event_image_xy(
                    context,
                    event,
                    self._width,
                    self._height,
                )
                self._guide(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE" and bool(getattr(self, "_dragging", False)):
            if selection_tools._inside_image_window(context, event):
                self._guide(context, event)
            return {"RUNNING_MODAL"}
        if (
            event.type == "LEFTMOUSE"
            and event.value == "RELEASE"
            and bool(getattr(self, "_dragging", False))
        ):
            end = self._guide(context, event)
            self.x0, self.y0 = int(self._start[0]), int(self._start[1])
            self.x1, self.y1 = int(end[0]), int(end[1])
            self.use_coordinates = True
            self._finish_modal(context)
            return self.execute(context)
        return {"RUNNING_MODAL"}

class SPS_OT_lightweight_edit_clear(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_clear"
    bl_label = "消去"
    bl_description = "選択範囲またはアクティブレイヤー全体のアルファを0にします"
    bl_options = set()

    def execute(self, context):
        import numpy as np

        material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        started = time.perf_counter()
        before = _read_u8(image)
        after = before.copy()
        if selection is None:
            after[:, :, 3] = np.uint8(0)
        else:
            after[:, :, 3] = np.clip(
                np.floor(
                    before[:, :, 3].astype(np.float32)
                    * (np.float32(1.0) - selection)
                    + 0.5
                ),
                0.0,
                255.0,
            ).astype(np.uint8)
        return self._finish(_commit(material, image, before, after, "clear", started))


class SPS_OT_lightweight_edit_transform(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_transform"
    bl_label = "変形"
    bl_description = "選択画素またはアクティブレイヤーを移動・回転・拡大縮小します"
    bl_options = set()

    kind: EnumProperty(
        items=(
            ("TRANSLATE", "移動", ""),
            ("AFFINE", "拡大縮小・回転", ""),
            ("FLIP_H", "左右反転", ""),
            ("FLIP_V", "上下反転", ""),
            ("ROTATE_90_CW", "右へ90度", ""),
            ("ROTATE_90_CCW", "左へ90度", ""),
            ("ROTATE_180", "180度", ""),
        ),
        default="TRANSLATE",
        options={"SKIP_SAVE"},
    )
    dx: IntProperty(default=0, min=-16384, max=16384, options={"SKIP_SAVE"})
    dy: IntProperty(default=0, min=-16384, max=16384, options={"SKIP_SAVE"})
    scale_percent: FloatProperty(
        default=100.0,
        min=1.0,
        max=1000.0,
        options={"SKIP_SAVE"},
    )
    degrees: FloatProperty(
        default=0.0,
        min=-360.0,
        max=360.0,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        started = time.perf_counter()
        before = _read_u8(image)
        kind = str(self.kind or "TRANSLATE").upper()
        try:
            after = _transform_pixels(
                before,
                selection,
                kind="AFFINE" if kind == "AFFINE" else kind,
                dx=int(self.dx) if kind == "TRANSLATE" else 0,
                dy=int(self.dy) if kind == "TRANSLATE" else 0,
                scale=float(self.scale_percent) * 0.01,
                degrees=float(self.degrees),
            )
        except Exception as exc:
            self.report({"WARNING"}, _rpt_fail("変形を適用できません", exc))
            return {"CANCELLED"}
        return self._finish(_commit(material, image, before, after, kind.lower(), started))


class SPS_OT_lightweight_edit_copy(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_copy"
    bl_label = "コピー"
    bl_description = "選択画素またはアクティブレイヤーの不透明範囲をコピーします"
    bl_options = set()

    def execute(self, context):
        global _CLIPBOARD
        import numpy as np

        _material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        started = time.perf_counter()
        pixels = _read_u8(image)
        bbox = _content_bbox(pixels, selection)
        if bbox is None:
            self.report({"WARNING"}, _rpt("コピーできる画素がありません。"))
            return {"CANCELLED"}
        x0, y0, x1, y1 = bbox
        region = np.ascontiguousarray(pixels[y0:y1, x0:x1], dtype=np.uint8)
        if selection is None:
            mask = np.ones((y1 - y0, x1 - x0), dtype=np.uint8) * np.uint8(255)
        else:
            mask = np.ascontiguousarray(
                np.clip(np.floor(selection[y0:y1, x0:x1] * 255.0 + 0.5), 0.0, 255.0),
                dtype=np.uint8,
            )
        pixels_payload = zlib.compress(region.tobytes(order="C"), level=1)
        mask_payload = zlib.compress(mask.tobytes(order="C"), level=1)
        pixels_token = f"clipboard:pixels:{uuid.uuid4()}"
        mask_token = f"clipboard:mask:{uuid.uuid4()}"
        _clear_clipboard()
        document_generation = _image_key(image)
        if not _CLIPBOARD_CACHE.put(
            pixels_token, pixels_payload, document_generation=document_generation
        ):
            self.report({"WARNING"}, _rpt("コピー領域が共有キャッシュ上限を超えています。"))
            return {"CANCELLED"}
        if not _CLIPBOARD_CACHE.put(
            mask_token, mask_payload, document_generation=document_generation
        ):
            _CLIPBOARD_CACHE.pop(pixels_token, None)
            self.report({"WARNING"}, _rpt("選択マスクが共有キャッシュ上限を超えています。"))
            return {"CANCELLED"}
        _CLIPBOARD = {
            "width": int(x1 - x0),
            "height": int(y1 - y0),
            "x": int(x0),
            "y": int(y0),
            "pixels_token": pixels_token,
            "mask_token": mask_token,
            "document_generation": document_generation,
        }
        elapsed = time.perf_counter() - started
        self.report({"INFO"}, f"{region.shape[1]} x {region.shape[0]} px / {elapsed:.2f}s")
        return {"FINISHED"} if elapsed < 10.0 else {"CANCELLED"}


class SPS_OT_lightweight_edit_paste(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_paste"
    bl_label = "貼り付け"
    bl_description = "コピーした画素をアクティブレイヤーの同じ位置へ貼り付けます"
    bl_options = set()

    offset_x: IntProperty(default=0, min=-16384, max=16384, options={"SKIP_SAVE"})
    offset_y: IntProperty(default=0, min=-16384, max=16384, options={"SKIP_SAVE"})

    def execute(self, context):
        import numpy as np

        material, image, selection = self._target_or_report(context)
        if image is None:
            return {"CANCELLED"}
        if not _CLIPBOARD:
            self.report({"WARNING"}, _rpt("Smart Paintのクリップボードは空です。"))
            return {"CANCELLED"}
        started = time.perf_counter()
        before = _read_u8(image)
        width = int(_CLIPBOARD["width"])
        height = int(_CLIPBOARD["height"])
        pixels_payload = _CLIPBOARD_CACHE.get(str(_CLIPBOARD.get("pixels_token", "") or ""))
        mask_payload = _CLIPBOARD_CACHE.get(str(_CLIPBOARD.get("mask_token", "") or ""))
        if not isinstance(pixels_payload, (bytes, bytearray, memoryview)) or not isinstance(
            mask_payload, (bytes, bytearray, memoryview)
        ):
            _clear_clipboard()
            self.report({"WARNING"}, _rpt("Smart Paintのクリップボードは解放済みです。"))
            return {"CANCELLED"}
        try:
            source = np.frombuffer(
                zlib.decompress(pixels_payload),
                dtype=np.uint8,
            ).reshape((height, width, 4)).copy()
            source_mask = np.frombuffer(
                zlib.decompress(mask_payload),
                dtype=np.uint8,
            ).reshape((height, width)).astype(np.float32) * np.float32(1.0 / 255.0)
        except (ValueError, zlib.error):
            _clear_clipboard()
            self.report({"WARNING"}, _rpt("Smart Paintのクリップボードが破損しています。"))
            return {"CANCELLED"}
        x0 = int(_CLIPBOARD["x"]) + int(self.offset_x)
        y0 = int(_CLIPBOARD["y"]) + int(self.offset_y)
        x1, y1 = x0 + width, y0 + height
        dst_x0, dst_y0 = max(0, x0), max(0, y0)
        dst_x1, dst_y1 = min(int(before.shape[1]), x1), min(int(before.shape[0]), y1)
        if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
            self.report({"WARNING"}, _rpt("貼り付け先が画像の外です。"))
            return {"CANCELLED"}
        src_x0, src_y0 = dst_x0 - x0, dst_y0 - y0
        src_x1, src_y1 = src_x0 + (dst_x1 - dst_x0), src_y0 + (dst_y1 - dst_y0)
        clipped = source[src_y0:src_y1, src_x0:src_x1].copy()
        weight = source_mask[src_y0:src_y1, src_x0:src_x1]
        if selection is not None:
            weight *= selection[dst_y0:dst_y1, dst_x0:dst_x1]
        clipped[:, :, 3] = np.clip(
            np.floor(clipped[:, :, 3].astype(np.float32) * weight + 0.5),
            0.0,
            255.0,
        ).astype(np.uint8)
        layer = _empty_canvas_like(before)
        layer[dst_y0:dst_y1, dst_x0:dst_x1] = clipped
        after = _alpha_over(before, layer)
        return self._finish(_commit(material, image, before, after, "paste", started))


class SPS_OT_lightweight_edit_undo(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_undo"
    bl_label = "編集を元に戻す"
    bl_description = "直前のSmart Paint編集操作を元に戻します"
    bl_options = set()

    def execute(self, context):
        material, image, _selection = self._target_or_report(
            context, allow_empty_selection=True,
        )
        if image is None:
            return {"CANCELLED"}
        key = _image_key(image)
        _trim_history()
        stack = _HISTORY.get(key) or []
        if not stack:
            self.report({"WARNING"}, _rpt("元に戻せるSmart Paint編集はありません。"))
            return {"CANCELLED"}
        snapshot = stack[-1]
        try:
            restored = _unpack_snapshot(snapshot)
        except (KeyError, ValueError, zlib.error):
            _drop_snapshot(stack.pop())
            self.report({"WARNING"}, _rpt("履歴は共有キャッシュから解放されています。"))
            return {"CANCELLED"}
        started = time.perf_counter()
        current = _read_u8(image)
        redo_snapshot = _push_redo(image, current, str(snapshot.get("label", "") or "undo"))
        if redo_snapshot is None:
            self.report({"WARNING"}, _rpt("やり直し履歴を確保できないため処理を中止しました。"))
            return {"CANCELLED"}
        try:
            _write_u8(image, restored)
        except Exception:
            redo_stack = _REDO.get(key) or []
            if redo_stack and redo_stack[-1] is redo_snapshot:
                _drop_snapshot(redo_stack.pop())
            raise
        stack.pop()
        _drop_snapshot(snapshot)
        if not stack:
            _HISTORY.pop(key, None)
        elapsed = time.perf_counter() - started
        info = _changed_info(current, restored)
        _record_result(material, "undo", elapsed, info)
        _tag_redraw()
        return {"FINISHED"} if elapsed < 10.0 else {"CANCELLED"}


class SPS_OT_lightweight_edit_redo(_EditOperator, bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_edit_redo"
    bl_label = "編集をやり直す"
    bl_description = "元に戻したSmart Paint編集操作をやり直します"
    bl_options = set()

    def execute(self, context):
        material, image, _selection = self._target_or_report(
            context, allow_empty_selection=True,
        )
        if image is None:
            return {"CANCELLED"}
        key = _image_key(image)
        _trim_history()
        stack = _REDO.get(key) or []
        if not stack:
            self.report({"WARNING"}, _rpt("やり直せるSmart Paint編集はありません。"))
            return {"CANCELLED"}
        snapshot = stack[-1]
        try:
            restored = _unpack_snapshot(snapshot)
        except (KeyError, ValueError, zlib.error):
            _drop_snapshot(stack.pop())
            self.report({"WARNING"}, _rpt("履歴は共有キャッシュから解放されています。"))
            return {"CANCELLED"}
        started = time.perf_counter()
        current = _read_u8(image)
        history_snapshot = _pack_snapshot(image, current, "redo")
        if history_snapshot is None:
            self.report({"WARNING"}, _rpt("元に戻す履歴を確保できないため処理を中止しました。"))
            return {"CANCELLED"}
        try:
            _write_u8(image, restored)
        except Exception:
            _drop_snapshot(history_snapshot)
            raise
        _HISTORY.setdefault(key, []).append(history_snapshot)
        stack.pop()
        _drop_snapshot(snapshot)
        if not stack:
            _REDO.pop(key, None)
        elapsed = time.perf_counter() - started
        info = _changed_info(current, restored)
        _record_result(material, "redo", elapsed, info)
        _trim_history()
        _tag_redraw()
        return {"FINISHED"} if elapsed < 10.0 else {"CANCELLED"}


def _draw_history_controls(layout, context, *, label: str, icon: str, show_header: bool) -> None:
    header = layout.row(align=True)
    if show_header:
        header.label(text=label, icon=icon)
    canvas = getattr(context.scene.tool_settings.image_paint, "canvas", None)
    _trim_history()
    history = _HISTORY.get(_image_key(canvas)) or []
    redo = _REDO.get(_image_key(canvas)) or []
    undo_row = header.row(align=True)
    undo_row.enabled = bool(history)
    undo_row.operator(SPS_OT_lightweight_edit_undo.bl_idname, text="", icon="LOOP_BACK")
    redo_row = header.row(align=True)
    redo_row.enabled = bool(redo)
    redo_row.operator(SPS_OT_lightweight_edit_redo.bl_idname, text="", icon="LOOP_FORWARDS")


def draw_paint_toolbar(layout, context, material, *, show_header: bool = True) -> None:
    settings = getattr(material, "smart_paint_suite", None)
    if settings is None:
        return
    if show_header:
        layout.separator()
    _draw_history_controls(layout, context, label="描画", icon="BRUSH_DATA", show_header=show_header)

    fill_row = layout.row(align=True)
    fill_row.prop(settings, "edit_fill_color", text="")
    fill_row.prop(settings, "edit_fill_alpha", text="A")
    fill = fill_row.operator(SPS_OT_lightweight_edit_fill.bl_idname, text="", icon="COLOR")
    fill.color = tuple(getattr(settings, "edit_fill_color", (0.8, 0.2, 0.2)))
    fill.alpha = float(getattr(settings, "edit_fill_alpha", 1.0))
    fill_row.operator(SPS_OT_lightweight_edit_clear.bl_idname, text="", icon="TRASH")

    end_row = layout.row(align=True)
    end_row.label(text="終点")
    end_row.prop(settings, "edit_gradient_end_color", text="")
    end_row.prop(settings, "edit_gradient_end_alpha", text="A")
    gradient_row = layout.row(align=True)
    gradient_row.prop(settings, "edit_gradient_type", text="方式")
    gradient = gradient_row.operator(
        SPS_OT_lightweight_edit_gradient.bl_idname,
        text="",
        icon="IPO_LINEAR",
    )
    gradient.gradient_type = str(getattr(settings, "edit_gradient_type", "LINEAR") or "LINEAR")
    gradient.start_color = tuple(getattr(settings, "edit_fill_color", (0.8, 0.2, 0.2)))
    gradient.end_color = tuple(getattr(settings, "edit_gradient_end_color", (0.12, 0.32, 0.9)))
    gradient.start_alpha = float(getattr(settings, "edit_fill_alpha", 1.0))
    gradient.end_alpha = float(getattr(settings, "edit_gradient_end_alpha", 1.0))


def draw_transform_toolbar(layout, context, material, *, show_header: bool = True) -> None:
    settings = getattr(material, "smart_paint_suite", None)
    if settings is None:
        return
    if show_header:
        layout.separator()
    _draw_history_controls(layout, context, label="変形", icon="ORIENTATION_VIEW", show_header=show_header)

    clipboard = layout.row(align=True)
    clipboard.operator(SPS_OT_lightweight_edit_copy.bl_idname, text="", icon="COPYDOWN")
    clipboard.operator(SPS_OT_lightweight_edit_paste.bl_idname, text="", icon="PASTEDOWN")

    move = layout.row(align=True)
    move.prop(settings, "edit_translate_x", text="X")
    move.prop(settings, "edit_translate_y", text="Y")
    translate = move.operator(SPS_OT_lightweight_edit_transform.bl_idname, text="", icon="EMPTY_ARROWS")
    translate.kind = "TRANSLATE"
    translate.dx = int(getattr(settings, "edit_translate_x", 0))
    translate.dy = int(getattr(settings, "edit_translate_y", 0))

    transform = layout.row(align=True)
    values = transform.column(align=True)
    values.prop(settings, "edit_scale_percent", text="倍率 %")
    values.prop(settings, "edit_rotate_degrees", text="角度")
    apply_button = transform.column(align=True)
    apply_button.scale_y = 2.0
    affine = apply_button.operator(SPS_OT_lightweight_edit_transform.bl_idname, text="", icon="ORIENTATION_VIEW")
    affine.kind = "AFFINE"
    affine.scale_percent = float(getattr(settings, "edit_scale_percent", 100.0))
    affine.degrees = float(getattr(settings, "edit_rotate_degrees", 0.0))
    flips = layout.row(align=True)
    for kind, icon in (
        ("FLIP_H", "ARROW_LEFTRIGHT"),
        ("FLIP_V", "SORT_ASC"),
        ("ROTATE_90_CCW", "LOOP_BACK"),
        ("ROTATE_90_CW", "LOOP_FORWARDS"),
    ):
        operator = flips.operator(
            SPS_OT_lightweight_edit_transform.bl_idname,
            text="",
            icon=icon,
        )
        operator.kind = kind


def draw_toolbar(layout, context, material, *, show_header: bool = True) -> None:
    """Compatibility wrapper for callers that still request the combined surface."""
    draw_paint_toolbar(layout, context, material, show_header=show_header)
    draw_transform_toolbar(layout, context, material, show_header=True)

CLASSES = (
    SPS_OT_lightweight_edit_fill,
    SPS_OT_lightweight_edit_gradient,
    SPS_OT_lightweight_edit_clear,
    SPS_OT_lightweight_edit_transform,
    SPS_OT_lightweight_edit_copy,
    SPS_OT_lightweight_edit_paste,
    SPS_OT_lightweight_edit_undo,
    SPS_OT_lightweight_edit_redo,
)
