# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Photoshop 2026 Color Balance and Levels transfer curves.

The compact tables were measured from deterministic 8-bit RGB ramps. Runtime
code only interpolates 65 curve knots; it never launches, scans, or polls an
external application.
"""

from __future__ import annotations

import base64
import zlib
from typing import Any

from .. import resource_quota

_CALIBRATION_CACHE = resource_quota.cache("adjustment.calibration_tables")


CALIBRATION_VERSION = "ps2026_ramp_v1"
CURVE_KNOT_X = (0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 148, 152, 156, 160, 164, 168, 172, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216, 220, 224, 228, 232, 236, 240, 244, 248, 252, 255)
_PRESERVE_SHADOW_HIGHLIGHT_B85 = (
    b"c-"
    b"rmOc~npNAIEXWnzbk@DQQ8rVa_nNkU~jCrR?jRd&a(&ib^U<$TrLw#ui$nq@pPMI_I9TuSHQwNei;g%<udA+`fHt@AodB<^Im`o0"
    b")t6e?QOnljC(B_3B}N`quqNPhGTTdu%41SEa(guV>iPVe*oQz3FtpCzXmMU^>v-"
    b"XKONDqN@1_0ygdeF?6*`MI3O5pjBT!f&lxRAfVFvWS-"
    b"*%R6?K3bL4<Z^pkmx5>QEhGS49a6~ZU;Ts)vc{bZgC22@y|%yaF43jf3X->hTQ<@-"
    b"@ylyCS?hte+HEqsd|XxgEdod@L~wddHydoMo|{DS5d1Kg;<Z3*Wel#@L{w}%rIx-UEDBkAA3z?O>6$d~a)w4f5oW&JBq%BU)%s*L"
    b"JCV^mw2*z|L7pS~a<Vn<BM8TxT?HD*As<2OTHr!5TH`0LRuI``Ed*uQ|wWP&GfnM@GiGMOO2Wimm4%VdH8t&FNNs>-"
    b"PTKa6VQHfG)W4R@VHEe%?~<3Q4>E4QDPzQ+kPF|g=u>pX#49umDfA>;C${PI8XegTikxKH3Q88^UVGH!s!WZVFc$+!U?lW_x-GOE"
    b"g`Dx><p7}e%&&Aay-"
    b"=Ik|do^Qy89s3hco~Iu?EBk;RXkld4d$6PDjQM_Hn|H^houeNXR$`5+0F&{aAi!k2fB=*60s>6N3kWb7FCf5Vynq0c@dC6ms>-"
    b"M;qgt<CBV8kl9({*8c}$@e`-g7axi29t`|7Qn!t#%(0X>t>y$6jPH<?<pa_yGghf}hy-pVb0gFdRlOvZSEFq1I?!c4{p2s0TYAk1"
    b"WpfH0FW0>Vtj2naJ7BS0yms*LJCVN{#8F|q8?cgU!*6KBm`wkmwn&VBJIr!La>o)%Z2jcPM}(=L4mI=FhzoaYl1v31v><jf27{k)"
    b"R5e<A(?F(xBFL5#`B0Wl^c2gI0+91vqNazKp9$N@1XBL~Eoj2sYSGID@cMpYTruRp2{TNs#H_v~vs!qsaUwa_<cUG&bqvB??duHA"
    b"f?UsCl6A<(j2$F6+_+B<trr55>xL~h-"
    b"6@aT!N*KR&~{^}jls7f#y?FkZ0Mhi$V87&~eWVC<;lhFbaOhyYxFc~c%!DO_61e4JM5==%5P|Bz(qbh$?b#x8QI``~5*kO#v<XLl"
    b"<_^*!GymRm2r1b1d^xd3-(l^ji)zLHRWYcGWos;{dS#y^Lghp-"
    b"K6>}sl3!LW`zOF_XRY@kJJVBDlC;>?(qXZ<Gj1rJ!GD<*_$tVFyCZhx-nT!&UWHL%XlF29mNhYHNXk}EDQEk|~jj?%`UVR7Kj~+K"
    b"+I<;W=$~BRjckVfqn0o5`wVMx~7L~pI3<>DBx9HYqz%WNQZ@^riz_1P5b{$AKp2?i&y(oVV8&w#S;ZJ}t85)2w86JQz85)2w85)2"
    b"w85)2w85)2w85)2w85)2w85)2w85)2w85*FJQT_XmYLk`*?K^=<9W>n0&1=f+Ig5P*!`5#Bn|kDU#@WmCok#gEUQ3Q@lU8jzSa$2"
    b"vf9OaTPlmaE!D}~e-"
    b"*q7V*vT{C{PDAw6_8PdGa2#(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(IFlg(S{c=^J*o|w>bC1(("
    b"G^Up-6$82Ni(SVOZ|hxqrj#fOgMHT`{MN*_i~=UEPp3Dstuay8Jbyj2a`HtjQd2u++_i)*MUvlAD5J#b>aGr`?&?Bl^-"
    b"NV6^Y4GPe5X_WB`T9k^vMZO9haaEEzyyvQz+x$x;C%CQAj7m@E}QVzN{KiOEs{BqmD*keDnLKw`2~fKo<P?x;3y(b~||(&n4*1`Z"
    b"oJ#@&1B>^X~k0#>ixu=VF(W8#z3PoKL&-+uU{proSu53zv0aYt(~sY4t_k5%8VS`)DeY-;S$)XbXmyrNfC;-"
    b"iYlWbr2;GFd!;$YhBC8k5BXh)fm_ATn7zfXHO=03wsc1Bgr(4<IsGJb=h#@c<%|#RG^;77rjYSv-KqWbpv~Zy(hLI<54L&8(P79X"
    b"ew4*zuDAQ<tn*wPxK$W>e#mQZvt7x_;yC<GiBMO2JVD$~9<j-nqxO-"
    b"`m<dxs9)3?ux+B$mpMb*>^bcc!t`!`7g@eeEg5_FF<Cp*b|VMED}IxvS<L6$zlOyCW{4-"
    b"nJf}OXR=rTnaLsnbS8@g(3va}KxeW@0G-"
    b"Jq0dyvd1kjl*5<q9NNC2J5A_3~}KB|qH>9uX&(YhNmsSZxAo)f3dp0jY7Ur=ZSv#AGSj~+jnb>S*~>wfOD7q6<`^GCID^VaP;bn3"
    b"!P>TpLFj|t5Ea{u74^~|OoI&$p9>GJ@p51u@K`TDKksNyhL@Ci6f77XApSvY{fWWfLqlZ68qOco5_Fj+8w!(_n#4wD4~I7}7{;4o"
    b"P*fWu_L01lG{12{|;4B#+XFo45k!2k}E1q1Zg9o70xTC{FwV$MwJfFbsdF7Dn_W>WJO`ve4sMQ+;0Y-"
    b"(c4iPPsU|MvTxhfkgtm+?lmflkXdMy3|bqz<+lHD;Vw&Aso+)!|W_nN3YdPCIp$aqgq1g(c+zql(F7{u3~nEEvFHvOoZj$@~B&lZ"
    b"66UOcn^>F<Bsh$7Fs0lgR=BJSOu4m`vseFqzB`U^1B>z+^H%fXQTj0F%l5049_90Zb<I1C+c`ZPc`tzEOuxox3xWIvh;m_({`$_;"
    b"JC~6<`zBGn=~q@R4I_nP)BnsNQ>=SNQVvn-82(ZPZNHz}U>PYfolUM>>zy+^-5*%WUf2gYikJ8QC??&B-"
    b"q+t$6oIYgDnBto;ORCi4QgOy&nLnXDbaW->2;%Vg~UHj{Y)TqbJ=u$inKz-"
    b"F>`0Gr9$0c<8~2e6r}9l&O?b^x2n+5v1PYX`8ItR28+vUUKQ$(%s_Ce8H>i~%yc_x^5x?eLM#Zk`jS0%k5+?iU!cc761=pLg#E&`"
    b"iz9I?q7$L2iB#pyr1^Rcz&gMYLijb<nU8qg_2}@BM?;tlO}K+0-"
    b"~NiW=vFRjlNWDhZQ0Pat8kRsf&L+yDWSwFB5p<^~9u%n6V%Su23gWNv_f$=m<|lQ{trCUXM>Oy&egn9K=~Fqsn|VKOH`!emZ>gvp"
    b"!$36nVi5+<_(4V$)X-LAcvB{Ql0ZSBA$x_eJ%n7PC!0BmAZ^mb-"
    b"b<CBh`IDPiwHTvegM^B!=D6RN1szAAI3{A|fY<hm%ZxB$Xi@TTl-Zvl^ICIO6U-"
    b"rhtC8ngGs&($ug5t8uYSyTdF`4xQGA45ZBur)n$e7Fy5HXn(AYn2qK*nTtfQZSg02!0n0U{=|0%S~P1<07p3Xn0G6(D0WD?r9%R)"
    b"CDjtN<C4SphO8vjSvH)&%M|Zl<emXwuQLYY#A~gY8B*xqwNVHjA3O5Nuj-=(?!QU{m)Uj6a%^o|%2&%5T5lzMqp<Q2eUm-"
    b"N%|y1<KVm0E=jC(~Fr@d&e<j$4{IJ?iVdvv1)Z#B(te|Vq(E4W@M|Ko0AV#v8wuW?Whtnx$X(1OlAj&n5+p9Gx<w^kjZrcQYNzkW"
    b"K6CLkTO{lAZGHH03nm>0;Ei?3y?Bd6Ch@CU4WFyngB7AH34EKYXZbf)&z)|tO*b^SsiGo(?Sm{qPdlNQinN!N%WjBWyTLb&R@LT4"
    b"{Tz@2KA=KC4y1RI(G>`_3p!5u!?1sHKPgwt=k%#cCzjUCUxKt`%%tr9^UGEAOFCR@W@SD!KNOFJ(8RXR!x2W<XKV4>#FzaQI)}D^"
    b"%G<;xh_D;<k|o^lQjWiCaVK7m|PnmXR;<h%w%;y29s+8<V;ovWH7llK+a@!Kn9c50U1nI2V^i=9gx9fbwCD_)d3kyRtID-"
    b"x#s&X@6iLw"
)
_PRESERVE_MIDTONE_B85 = (
    b"c-m!_hhNQW9LF=#*47?MNufQ6uFBr-&9%qPp4Yg<C3}QOltNNT$VyT|S{j;1X`lA4Q>RW#-23W&zt8hKr<3~!JfHJ<zrWw-JU<Z;"
    b"kzvDz4<9j7bd<P+l=Nsh1tk?VP3^Jc#v4yIx3-"
    b"%$W9Ga?%YI+8Ve^hZ|2lf|{1tD%dk?}RVm_v1<(JkpclHm6kN`X{CLu}Ak5SVg=O>w4;rY1>mo8tue$)0n2adR(^|<D9Cn)UM>)3"
    b">}oC0=j3y%hn0%GEl(lWC0gXhhx?CgJWp0i-7%c^y*+jj3ieC*T(QsBwUHy@Hd=N6XNwGIXd3Mi|nYwGA37@17Au%0sAaTWrs-"
    b"mn=8xVfLXc=e`#U}$(mbX@XhR#626d>`NwU;!ZkCX4_CShb!haQ^aj-@Cz&o<+WmPsz+HuB_*D@dJoK0-!o5fB-CUS-JL)Ejz*Bi"
    b"L)M9014hDq-"
    b"E!qR5i5G04M+eQbGcRe&1!~Iy`^y2mp9``vs5!K#*HdR^8av%>+OJ1W;5~)zH$_H$;K9`1|vh{I+5Z5kLUEd~OGZK6w!p8=sQFDr"
    b"DC*wKD-"
    b"=01JQs6lgeMqN%0LR0k(25CrVnM*uv%Zv_O0J&lNdpO~7JS5#ix%*6mgfCc0g2>^cpLI8UYx*cZ<Jb3&Z2$IsX^NTC$nz=ncNB|a"
    b"~03cxKc@Vf`?*X@Cr_NovcEgVpc=HYja=(^V*0*%f08#)9s;E-|f&rj_P1|<wJ9PBKnTuDh`_ck29}-hDS%qa)^{q637C-"
    b"<^9eu+I0)dNvg$>$-0*<(!zHr&=rvE)G5Ec6|IXyeCh+W;#+S$tlKmi2;00K-"
    b"cY^Kr;T)t`@0XTf@BpUR+a~}%4ihiH)>2pqgad}N6hXf!26d(Y&0Twp6!BoJ;Ej#w?KlC>Oc==#~@Rw1b5C{rNDr%eBm;f;eC_n-"
    b"53Qys0(Atfgx9^4tx}QFO84TVH3dI8N;y<Nle<>`htZQ!L^<jW0Euf*TXMh6irU?n$1uJ;`)H#o<01z1R=qVKVkeHH@lV8NHs&8)"
    b"R_5Cv-GD4IV(1HoV27y4Q*+k%a*R4Bof+x?y1bqAhf*wA>0w0spGFe}X%c~n&+Pg@=C`lQ4B~=X_efSRofeu0fselUra0?950-"
    b"!MaOF?NxO+zb}1dJ4uf&%K=dLTgX7a%x~0xn&J^MN5@;V&YgKvG&}Zhlc&Wo=_?NB1`j5SNxyQq|N205dDQp9B&Co&+HD@v{h0AU"
    b"z8R*j05+92y`hA%g|<$D0rV&O^_m0I!>VcL~62ERdR!lUG<$UR~eZ)=2{-"
    b"Wfh?SOu!tkps>Khi~!%;_kzJ7EkFoR0R;45z$hs>Wh?*yM1b&lBEZ|106>8lD3AgQfdCY=w0HLOLx7l!f{Nx?1LMh-wkTkzKq3GE"
    b"z~HMlv7`VYsH$shZRe2y@zF|Z+WJNa02}m^KokHI001x;^BxOiv5=s;zKO%-"
    b"^^yQtWer^eV^aVC0fQTe8^j0*3I&6a(Xnw*AS35XL2+4SO?@+m+tu6u?|_Jeyo#2d(Ig97dwj))2t)xs{siFptEjiMKyH3v3A?Hm"
    b"9CpwENd+|>0~0grsW`!9_y`ONBmx3M5C9CuC6WSPi^?jh>l$0yI=cJ5V}POt6tJ|L?nGa)!435AgbhFeFo8%g7@wR91wbJi2%1{k"
    b"JDC6_&2h$N*7h@Cf*?R35H<(}1Oz>Jga9x?EC4esDlJC>4nIIjS=(@;rJaNGT=EJE3&ah$9}<QD(J(?<02BfN1aNshG+>O5k*Uoz"
    b"$Jq<;8FyvQ!v<1;D1ZVarKD$q0ZM=hcs<`RKzfX>v4x$(OaP#d01ki=2m)XQUr+#k0VDtgFod3OKQKT=&&0~!an3^c4gmo~AYMV("
    b"AlLvDKmcd~7R-<mfWxj{8lb8_$;M&UeDWQ#ZEyo`+(Ln21OQe54PpUMSXl!@<ZwH?X@HEHf$0>-"
    b"xr+e6bt@zAB46Oc$Mk$08UzER01~vcae3Xn{TMJ>-O$|LdHzxWAddjK!bBk103v_@WMs3j0K1Y9fWz)S8lY)p=`d%p3;B-"
    b"O&ulQ+z~E4U0001kI07gDGk`6CA<zI>tqImM<}F*X)|Gk1sK7fQ5UxN35dZ+`nM{F-Y9xR)>S6-"
    b"qv`uWC7P_q7h~FV@{}%{%AR#FQ4Uz)oRW*cw%MbVuF=sN+"
)
_DIRECT_TONES_B85 = (
    b"c-pO3X+V$p7EZM9n>3~UpB9y*5;DSMi!s+S7)CYL%UDL3vL%wKCe@T=yON;{mn?~-"
    b"l!`+8qDA|@@0fe1`<&nVuSu6r^?rZOdCqgrdEWCA5cu3DI7UQVT3%UAQ_slE%4W`jr7PEM+_uNn-OK-"
    b"M==I1)iD@|{H7)P@K7$@LT1ZS%R&kuV_JoNH{`HErPFr{GJ9ykXAS5&*GCDpby`ZeF?K1%cg+wG|6qMC8bPY_WSkIgb_;-"
    b"$*e{^;|>ggMJ?(+5951u5y$}XyC==jk0spP_9QnE_p#%t*rPMR`}!Phu!+`fDNp<}=J1)aYfaVzR^;)~4uw^dD_2p}jVDk-BdPEA"
    b"wSz<9FdbX&WHfUn=UZP(rdZk|2?!56O(J|X2*Zedw%OV^M9qnK`EzfjlKGXi&;+4JnbS^1sA#((Z~c0F?3>r~L$OTYhdJL>V%<d>"
    b"QGC6)C<0zfw@IYm(C8JHmXmviSY{>Qfj-?7K#u)F840jJN0UIRWRJ}E6dx2UYTp{?id0HYXnWmQcb{fU#1-"
    b"1e)5OO}1R){)>pA3A!%%P%nGLRk2X$f%gOq!;Pg1tk@=O&vY|;RhH!K;6(}veoo2=geEQbor`vj++4AfAFZsFTO~B=}N@S$OkcT&"
    b"tAOB$}1|Xs%zl~5EK%VmRC|C)lDW_SkIhow{Qu#um555ww=yDA9Oo@670`jynOACTX!GC!~>t1Tllu3rlGa#9RiFIrGbI!M1AUvS"
    b"##&xBl%i~4O_PF;^01hfoG6D{KoBj(U0SwJ%5>zQ&0>7O>Haylq2#w6O2sFiTua-BgZ_wPyH5r?q6Y)KkCtwgyhuMS$S_t%B$;}+"
    b"qnSZtnEAlV>8QX9Q~DRzIQ_PKkaip?0&+_Hy|kFLg?=iH#q_+Y3bSdQ~?5XQvhKJStTOC*M7lZ{2|EqtA7wHfCK=6Bq)FiN-Jv{T"
    b"H3qcBY=n$HcpFYXku<f0xbS!#p-pA8@K+rd#}r(qf7uQ;Og~%N8W$P2(Svus%jfsI#>WvX+;%v9epYQ-"
    b"5Vkx34jKm04Vq%h6udOpbE;X>zZ0SdRPD%B~?wHA)8zb{xW|5_Uu1!<QQLoOIM)aov4SgAdvbxGq<3qw4%DcskO7`{eSxe#N?F6Y"
    b"wH_hd}hsEu=pbZNr1pJtbm)5_o6uh>DhU2ipwgYVH+1fTwX<kXEe!T8g&o?3>J_HaPcw~00m>8G6FgIMQ_WiY8#r{x_UoQ00mVLF"
    b"rSLm!}tyo(Bq^JCV&J$2kt<@xWr@-fP}@Upsul{ogY9^P1kUe#q?R|AOsi?5EDcKoWB%yjS4^ui2!<-UsysFH1!9-"
    b"B90Oi96d%zSX4|xQd(ACQCUSzT}yX@p^2FVjrM}Y@Pzdnw(fLxIpX2%AABK<EG_9}c40+*`+F9E;YCEnC8cEK6vwKlGPp4|gTI!m"
    b"*Ewz8zI)#Rw-XE>aqIr$gcs>~B~^_b6aWPH_(AE7`0243q$`K_@bU{f7kcf+o#?ovw5)>C>ZVRI6v7LOh)E1eKL}2)084|ZxO@8e"
    b"2cKv7*u)pGr1IM4E-"
    b"nD_6CUZmP}9)XGni;<PJ8tgRgbaQylt1W%i&`uef;5RSIN`hiCN@{trP$R2rn(Gpfrxs>l=})*!24Xy1L`1{RiBR!<2#<{{Ex5q}"
    b"24B!cur*_n&?A4<fvr!dMkG4IMoLh{rsQtu;+Gno6E{>bEl&2!HS4lf>t*vhs_|YZ}{o5I}H@uqg1LKVFlnpKM86&9@acR2XV3RU"
    b"qN7-"
    b"?|qan~<EAk^AOtWnD8DK#0Sus%!Ho{nQ!MyT6x;Ge!R(&J^J(Pm@w#XXh7}RoAz4^kN%F3yag=KvhErqca)e*^+nzrocC)(`T8fF"
    b";D6@)yCG&-Vrg?;d<imEp51tG<-"
    b"uDt{+H@)zCM!oMCIXXz2<z_>4Wo<NT1)bAFVN^gIpuIYS}>9o_FJfTXgv(Uj@7+$phP3looe2R}#kl>YYJsD69~9F+>FsfVL=_Pq"
    b"NO0i;xTrq;Ie7cX12&S?{0JWnrQ`X3>EIHiw{iH(OJB0s~IRaVzEG`Dti^}MG5(rWtVGv_T?zGgk8=es!*FZ9YldXx`8CH}yp04R"
    b"V8dRYKjbt9|U_RH7MC4^&w{fz=nlXzEI^-w=PAt@!5k1r{!paPm(+dKIIhVKWo&*G9Y+(PT<85*1M-IPC6+js4y8_U}-"
    b"DCA;T_{}>HaHOSW;Kr$L92rBQ03aaG3gGD*nPR1F2CX!v5`BRo24SPaZ{kYBLciv&v=MToF(P6hz!gA$BkLiaK)*>WRq#1j0th^c"
    b"d-nWQW?oTgRef_u?}%8M5JzA<IyjLXY9E;j8%%HJN$?a9c#@cs21_a_uW4xM92rl<+hX9#wXnAN81KRkHFl`Nl<v@>$ULnGXIf+1"
    b"h+V35r0e2Nqx_tH{rVH!pLr_M-+vg(zf<W@#-"
    b";t?uf9G6kdRfxp^5yczyC_7BcB$4<PV|#6MLLEU=KsAs^i$R53a0$GYxMu3wmPE8^M9?k1HF$(;?{I^;>tNV~BfZE{^1y`j&PsIT"
    b"rwjrm7at$jlP1xajNU+%>Tma8Cw@_85QG{H(k}lCE_iITt`oZk#$?mEKna4<uX@C(wJ!PH-AtaHrX69-"
    b"N#DATF<}rEdaPw!;f)ts@;Xc%pc5@Eh2EOwLQpeo6leW5_2UrKHX?HlH?Yp8c{_-"
    b"~X_62W~N#2X+_PBLVN9d|I9NfA#&}Cm^k&WngAa_|*=Z=ymCi7fvwX^uCJc<{qyLHnyMo1Y}h8Os!_x*)QiFw{9NZe$2W!czVtoT"
    b"Ku-|PbKF9$f+Be&zJ*Ob=rcrwfjlmK<;%J6Q7)#0q3j4)?)2H`~44rHvWe"
)
_LEVELS_GAMMA_B85 = (
    b"c-oDacR&=^8pVl5V~ZMN35H+~cA}9;#5{Z!%oC#~*4Uq7K}97ZMhprH(jgRS(tBqq!cqiQnkdFbqM~BKLX3*2*ka^;-"
    b"@SL*&aS@w|2uQe?|d_JXLWSm`Fjt3?b@|}zeC4PUApz?)%Vju!@rnhHh-"
    b"<HN1Up$P3u6r_BirEr_NnJ?D5gZeRcH)4jn#byz#%L&t9;6-8MUCzsU6BQw@*WWEX-lnCsjH=6d$()33kYfFYlc95ena6Vn;9<}F"
    b"&jc9ZpPM|c0Q1Vv%xnJZ1LZTv7biC65_y=Sl9eRV(8A2ifp<k)dWUw`v&GxK>1m#$j3*?O0~lZRhObdo};syTQ0*25QVWSS*pv;B"
    b"1SxLM=LQ>OptyYCk*TV-Ln&1UyLXAj??@YobZeo1BR`TCoGw!8#^_c%Umc);Lc!$%p8{|YWV1BMs=xN^;gE!%h6?Q?ST2?&XdOHt"
    b"$%sj5%a)nC8!;K{2tobT`fkRpLU8#u&Z<d|_2j7?0Z%`~4oe=%Ho;}+|kc6$%Fdin+)j*3so%q=Lbs5xDC>DsM(&8>ffK>LoJV4Q"
    b"G9TrfR(3OBuW<Cg6<yX_qhx_kQvg~516j<Q%)bpqxa8t>k3c?JUQJ9Nf!bw3+4bogk)FDIIqPBoh~=Z8g0SFTyVY3onB_Ut?0;_+"
    b")hFpMXsXXO=^lvkfTQ+M&|jXU=qK6(DSP3Qei-Fo)^1X~{c1zvpmx3lLhSh9Sz1z!B;UmToVJ;``nQko)HSzK0eycXuKT))+H|Iy"
    b"PIAkeXE&px{PgAGO*PGHOz{<z}5>nyFTcY=2|9vPdMnvo5cS5?;F{N-znV4$V-B?xrt-dlG7E*Y!}TwOd)uI?XnI3gwi+~+EbN{?"
    b"05oH|o?;c~-`+fDbIA3sBZ&b>a-A3DNt!q?wS1#-"
    b"l^r4=>r;^E^L7#bcOmz0{BomWs?R$g@i=j*RtzjgQCgGW!Ez51t3r%P|WAtMZpCYgf!A7EqFZrHqS2ciS=zK76#LQ1+KH^1;`Sw%"
    b"I>pa0|1m1{R|H~san<>_-2=-Nl$V64%kDKlol<-t9Wx3#l(baq4cp%HlbjI1Ndq7s!be*+CPKW=@20^Rxz8u{g<DP-"
    b"GM!sXFDH0SQ^hnI)+X_?ta3W`gQvH6Ptpz+S1e?5c*Fa8FB4|Ru*ooH%iP8XiCcSd-SJ}NE|?C0d+d?n7G`~4ySxOw~Tz5C5APpL"
    b"rn{-2LCnFe?2veoM>(f;232i?7V1A-"
    b"4nM8~6jh>!Ef$^3<S3;+fmJbL`}`AZb&p*LcJ>9=Hl)7Bky@tA#X{%9GQKYgz5!lf$>*Bj9QBxt1qJ@rRToH~2KQkVz&TzMg3QL!"
    b"{Wov%Jod-`nMAD1pe0AirIg%kK_;8+v0c}rGV!1d|o`jGf+UMb82!1}A#ZZHFn0l}-"
    b"+Z`yQv4IXD|zHr4_%dO=4WcL_8@%(RR&m({aG|(gw_;{Gnw7E;yY_NhGkDrew_}P3#bxrMW2oM4g16%?s(A&Ux=KPiLxU&U*=%1U"
    b"X*T?>APQrX07l0W+1Vo_k2$NZh*H~`Drw;Jr>!<u+zN+TrDFk?t1t1160Wd^?expt2E?;l8<7a#5-"
    b"y8Uc3;c^qRTWiOAOc_khyh3d2&jOr;nex7Eg^t|vm4w!e1Et<C8~0m2LL!P7=Q$TfD`CH-fXdjl?^;};jtM&_9r<F_otw^q^z72K"
    b"mlB7U<OD6!jK5)8O>U@5ndSk5dc0s$o|3p7nNXv1ON-"
    b"b8)$BM{FDg%0|NTSb5?D!v2$=n09=7NdCDRIAj}hjoB>RL45`4t$@49?@3P0|J_W!RNC0vHkRUN|?><ey3k)`0ym1E_zyR$2Cje9"
    b"cfNT&6z!~5Z0K-?WQDE4#Wm{~)fR}F|_xw=@fCPyFSVEdWEMPEm^>%n`y8Gb6Kb8Ps8z=+-f>0qdKoTHBCNR?6!e-"
    b"BYS1%wKfeq3PC{?ir&$1Pu1_(k(fDCaBP+;`jjkbH8&;YKmJOCv~4G@GZ0a*hSFkE1@+rh=tFOU*cWUB?B1epPv07|4K5P|VatoI"
    b"ynLj#nc&;U=6>`)`=5EBpt$dC#ct+26&gGXQ}eS?q{Dx)hz2&x;v1QY=iFkWrz;Ns;^-oL3lK^lPVAZGv&!V;iBt4Lt-"
    b"y50NTd=5bc)PR^Et&kaj4rv04fESpuX^#^eotOdg5aD;2H*kX(5E6(5rf;=B=;a?0j<0a?5+XM-"
    b"Um-I<JLD2b1ZG<AbA<%-2qCMGH-HFn2_y)JfcZ{GcSsN&&lyl@F@Ol!8uA8EV9u@sp8g>bF^MVkH6}CAKnxIsvIHowz|Pq#AT$!r"
    b"P?@v>nE}=zL8w7s@h>hufsi02U6TR43rL3qp-kWn2rS?0<{KOylZYKEwHY7?#R)_Ls~p_@Lok6Nhkp_9J3tK(glY){f%T4_0eA)`"
    b"2ce_l+ZgWx)*(eGNx%zO9`Ftf!vy3c!`%hE0ql?<lp){*Haq(SMa1GcHlMwU*<FASA~Zk{Hi_od1b#Z`8xk3x%#L#9mE3J8M<^Je"
    b"B`^USSHIBc1eSokO3rWw1ccHAVgXyX06@SJh#y4M06{1u5SPFN_IMl$k4;Kv3DlNI142=YRKVUdC?YN;Bbz1=btpzCNx-"
    b"*A1@?LeM<N26K-?jRkY8glLqWj7CnOpXkmGdKaT!8s0-"
    b"*$6z|r?`Oj0^`o)#m#$|F=qAPBUz>FoCli%rhR$rB}zAmkEA)`;y95pePkkAsiFd_KWhtxF&<WGxZ_=YWX#RK*dcEJ1@j0nbn@;1"
    b"U>_n3k1S@YVzp1gr#3z%?ie7~&UQIZeQxBxDK12_y_f0&c-Ez>pvizfXlFkRp%^xQE07LnZyF;a=$C1ZoKQ7C8aW&^Ta-"
    b"2;P=JSR<iDCg2qopN8MmD)FIELjo~FiGX)_LV7kJz|T590k_7Q5U30IL?q&$0_3}_mVcv569@=+hJwJakx9sqN1(X_F#@gxCg2;D"
    b"oCyq7+=q#l4mbpI0srU}1!2e??D<CtOCUnPGh_m9P#_>CH7l=(ewu2#55x#$0*7K#v-68fc?8n?Kn;PY1YRI8E-"
    b"i;JtPv$(CEjfkBj6cI1%l$!a|uKIxa5yzq688ILW^XRQ6M-zBNzW%;Xcl20!fJ+0?h&;37JO<OMoFDICoz28cG<7_Xq_-"
    b"6BSSbAUMgNY~>}YF_Z`#PEzCpL;Si?JC%s{m}e+%kqIPcfdKwNqOC-"
    b"A1Zo0dDcQ=Ss{aRptVJpio|02Q7;>LSq(ttOC`TX@h)6{NZjIz6iV%oP5CkIAatpD9S^>dz83MXSngycLj}!?E`8yHcsTvUQEeZn"
    b"B8F^Gd_`Xr!V|fW;ftZZEVinI&BLbeGW`WFnXc71Dtq8;=NCjdQ%A?0PhLVSoIsz>MaSCNgc@_Di>i2gd5U&9z5T8|0TFw}1z7f;"
    b"}UaAXZ7nD|1pFG7g)Q&*CMJkYxU07CeoMWgFfwmH;Kw?f&S><v1U)iO4$;s+n45>g;ZV~=jjDOZ$P)8tPs9m5~g)MUbR7jo$8cUE"
    b"0{15yjE$#"
)
_LEVELS_GAMMA_VALUES = tuple([index / 10.0 for index in range(1, 100)] + [9.99])


def _tables():
    import numpy as np

    def decode(payload: bytes, shape: tuple[int, ...]):
        raw = zlib.decompress(base64.b85decode(payload))
        return np.frombuffer(raw, dtype=np.uint8).reshape(shape)

    cached = _CALIBRATION_CACHE.get("color_balance")
    if cached is not None:
        return cached
    value = (
        decode(_PRESERVE_SHADOW_HIGHLIGHT_B85, (21, 21, 65)),
        decode(_PRESERVE_MIDTONE_B85, (41, 65)),
        decode(_DIRECT_TONES_B85, (3, 21, 65)),
    )
    _CALIBRATION_CACHE.put(
        "color_balance", value,
        document_generation=CALIBRATION_VERSION,
    )
    return value


def _interpolate_axis(table, value: float, minimum: float, maximum: float):
    import numpy as np

    position = np.clip((float(value) - minimum) / 10.0, 0.0, (maximum - minimum) / 10.0)
    lower = int(np.floor(position))
    upper = int(np.ceil(position))
    if lower == upper:
        return table[lower].astype(np.float32)
    factor = np.float32(position - lower)
    return table[lower].astype(np.float32) * (np.float32(1.0) - factor) + table[upper].astype(np.float32) * factor


def _interpolate_grid(table, shadow: float, highlight: float):
    import numpy as np

    shadow_position = np.clip((float(shadow) + 200.0) / 10.0, 0.0, 20.0)
    highlight_position = np.clip(float(highlight) / 10.0, 0.0, 20.0)
    shadow_lower = int(np.floor(shadow_position))
    shadow_upper = int(np.ceil(shadow_position))
    highlight_lower = int(np.floor(highlight_position))
    highlight_upper = int(np.ceil(highlight_position))
    shadow_factor = np.float32(shadow_position - shadow_lower)
    highlight_factor = np.float32(highlight_position - highlight_lower)

    lower = table[shadow_lower, highlight_lower].astype(np.float32)
    if shadow_lower != shadow_upper:
        lower = lower * (np.float32(1.0) - shadow_factor) + table[shadow_upper, highlight_lower].astype(np.float32) * shadow_factor
    if highlight_lower == highlight_upper:
        return lower
    upper = table[shadow_lower, highlight_upper].astype(np.float32)
    if shadow_lower != shadow_upper:
        upper = upper * (np.float32(1.0) - shadow_factor) + table[shadow_upper, highlight_upper].astype(np.float32) * shadow_factor
    return lower * (np.float32(1.0) - highlight_factor) + upper * highlight_factor



def _levels_table():
    import numpy as np

    cached = _CALIBRATION_CACHE.get("levels_gamma")
    if cached is not None:
        return cached
    raw = zlib.decompress(base64.b85decode(_LEVELS_GAMMA_B85))
    value = np.frombuffer(raw, dtype=np.uint8).reshape((100, 65)).copy()
    _CALIBRATION_CACHE.put(
        "levels_gamma", value,
        document_generation=CALIBRATION_VERSION,
    )
    return value


def levels_gamma_lut(gamma: float):
    """Return Photoshop 2026's slope-limited 8-bit Levels gamma LUT."""
    import numpy as np

    value = float(np.clip(float(gamma), 0.1, 9.99))
    anchors = np.asarray(_LEVELS_GAMMA_VALUES, dtype=np.float32)
    upper = int(np.searchsorted(anchors, value, side="left"))
    upper = min(upper, len(anchors) - 1)
    lower = max(0, upper - 1)
    table = _levels_table()
    if lower == upper or abs(float(anchors[upper] - anchors[lower])) < 1.0e-9:
        knots = table[upper].astype(np.float32)
    else:
        factor = np.float32(
            (value - float(anchors[lower]))
            / float(anchors[upper] - anchors[lower])
        )
        knots = (
            table[lower].astype(np.float32) * (np.float32(1.0) - factor)
            + table[upper].astype(np.float32) * factor
        )
    return np.interp(
        np.arange(256, dtype=np.float32),
        np.asarray(CURVE_KNOT_X, dtype=np.float32),
        knots,
    ).astype(np.float32) / np.float32(255.0)

def transfer_luts(state: dict[str, Any]):
    """Return three encoded-sRGB 256-entry LUTs for one native adjustment."""
    import numpy as np

    domain = np.arange(256, dtype=np.float32)
    knot_x = np.asarray(CURVE_KNOT_X, dtype=np.float32)
    ranges = np.asarray(
        (
            state.get("adj_color_balance_shadows", (0, 0, 0)),
            state.get("adj_color_balance_midtones", (0, 0, 0)),
            state.get("adj_color_balance_highlights", (0, 0, 0)),
        ),
        dtype=np.float32,
    )
    preserve_grid, preserve_mid, direct_tones = _tables()
    curves = []

    if bool(state.get("adj_preserve_luminosity", True)):
        shadow = ranges[0] - np.max(ranges[0])
        midtone = np.float32(2.0) * ranges[1] - np.min(ranges[1]) - np.max(ranges[1])
        highlight = ranges[2] - np.min(ranges[2])
        for channel in range(3):
            base_knots = _interpolate_grid(
                preserve_grid,
                float(shadow[channel]),
                float(highlight[channel]),
            )
            mid_knots = _interpolate_axis(
                preserve_mid,
                float(midtone[channel]),
                -200.0,
                200.0,
            )
            base_curve = np.interp(domain, knot_x, base_knots).astype(np.float32)
            mid_curve = np.interp(domain, knot_x, mid_knots).astype(np.float32)
            curves.append(
                np.interp(base_curve, domain, mid_curve).astype(np.float32)
                / np.float32(255.0)
            )
    else:
        for channel in range(3):
            curve = domain.copy()
            for tone in (0, 2, 1):
                tone_knots = _interpolate_axis(
                    direct_tones[tone],
                    float(ranges[tone, channel]),
                    -100.0,
                    100.0,
                )
                tone_curve = np.interp(domain, knot_x, tone_knots).astype(np.float32)
                curve = np.interp(curve, domain, tone_curve).astype(np.float32)
            curves.append(curve / np.float32(255.0))

    return tuple(curves)


def clear_calibration_cache() -> None:
    _CALIBRATION_CACHE.clear()
