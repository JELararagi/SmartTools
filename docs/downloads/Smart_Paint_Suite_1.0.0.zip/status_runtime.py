# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Thread-safe paint task and service messages."""

from contextlib import contextmanager
from threading import RLock
from time import monotonic


_messages = {}
_lock = RLock()


def _discard_expired(now):
    for owner, row in tuple(_messages.items()):
        end = row["expires"]
        if end and end <= now:
            del _messages[owner]


def _record(owner, text, duration=None):
    key = str(owner)
    with _lock:
        now = monotonic()
        _discard_expired(now)
        _messages[key] = dict(
            owner=key, text=str(text), updated=now,
            kind="service" if duration is None else "transient",
            expires=0.0 if duration is None else now + max(0.0, float(duration)),
        )


def set_transient(owner, text, *, duration=1.5, **_kwargs):
    _record(owner, text, duration)


def set_service(owner, text, **_kwargs):
    _record(owner, text)


def begin_task(owner, text, **_kwargs):
    _record(owner, text)
    return str(owner)


def update_task(owner, text, **_kwargs):
    _record(owner, text)


def finish_task(owner, text="", *, duration=1.5, **_kwargs):
    if text:
        _record(owner, text, duration)
    else:
        clear(owner)


def clear(owner):
    with _lock:
        _messages.pop(str(owner), None)


def clear_prefix(prefix):
    prefix = str(prefix)
    with _lock:
        for owner in tuple(_messages):
            if owner.startswith(prefix):
                del _messages[owner]


def clear_all():
    with _lock:
        _messages.clear()


def snapshot():
    with _lock:
        _discard_expired(monotonic())
        ordered = sorted(_messages.values(), key=lambda entry: entry["updated"], reverse=True)
        rows = [entry.copy() for entry in ordered]
        return dict(entries=rows, top=rows[0].copy() if rows else None, count=len(rows))


@contextmanager
def task_scope(owner, text, *, completed_text="", failed_text="", **_kwargs):
    begin_task(owner, text)
    try:
        yield
    except Exception:
        finish_task(owner, failed_text)
        raise
    else:
        finish_task(owner, completed_text)


__all__ = (
    "begin_task", "clear", "clear_all", "clear_prefix", "finish_task",
    "set_service", "set_transient", "snapshot", "task_scope", "update_task",
)
