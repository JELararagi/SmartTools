# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""外部連携のための小さな PSD の読み書き（標準ライブラリと numpy だけ）。

psd_tools と Pillow の代わりに、external_bridge が使っていた範囲だけを持つ。

* ヘッダー（幅・高さ・深さ・色モード・PSB）
* 層の記録（legacy 名・luni の Unicode 名・bbox・チャンネルの id と長さ・区切りの種類・
  旗・不透明度・合成モード・マスクの有無・追加情報ブロック）
* psd_tools 1.17.4 の PSDImage と同じ順に組む群の木
* チャンネルの画素の展開（8 ビット RGB の raw と RLE/PackBits。ほかは理由付きで断る）
* 記録の legacy 名と luni だけを書き換えて保存する書き手

Blender にも Smart Paint の他のモジュールにも依存しない。ワーカースレッドから呼ばれる
ので bpy を import しない。開く時にファイル全体を一度に読み、以後はその写しだけを見る
（psd_tools の PSDImage.open と同じく、開いた時点のスナップショットになる）。
開いた文書は書き換えないので、複数のスレッドから同時に読んでよい。
"""

from __future__ import annotations

from pathlib import Path
import struct
from typing import Any, Mapping

import numpy as np


class PsdError(ValueError):
    """PSD を扱えない時の例外。``reason`` に機械で読める理由を持つ。

    ValueError を継ぐので、呼び出し元の ``except (OSError, ValueError, ...)`` で捕まる。
    """

    def __init__(self, reason: str, detail: Any = None):
        self.reason = str(reason)
        self.detail = "" if detail is None else str(detail)
        super().__init__(f"{self.reason}:{self.detail}" if self.detail else self.reason)


class PsdFormatError(PsdError):
    """壊れた、または途中で切れた PSD。"""


class PsdUnsupportedError(PsdError):
    """形は正しいが、この読み手では扱わない PSD（16/32 ビット・ZIP・RGB 以外など）。"""


COLOR_MODE_RGB = 3

SECTION_OTHER = 0
SECTION_OPEN_FOLDER = 1
SECTION_CLOSED_FOLDER = 2
SECTION_BOUNDING_DIVIDER = 3

COMPRESSION_RAW = 0
COMPRESSION_RLE = 1
COMPRESSION_ZIP = 2
COMPRESSION_ZIP_PREDICTION = 3

_MAX_DIMENSION = 300000
# 記録 1 つの画素数の上限（1 チャンネルで 1 GiB）。PSD の最大 30000×30000 は収まる。
# 壊れた bbox で巨大な配列を確保して落ちないよう、これを超える記録は理由付きで断る。
_MAX_LAYER_PIXELS = 1 << 30
_ICC_PROFILE_RESOURCE = 1039
_BLOCK_SIGNATURES = (b"8BIM", b"8B64")
_RESOURCE_SIGNATURES = (b"8BIM", b"MeSa", b"AgHg", b"PHUT", b"DCSR")
# PSB で長さのフィールドが 8 バイトになるキー（psd_tools 1.17.4 の TaggedBlock._BIG_KEYS と同じ）。
_PSB_BIG_KEYS = frozenset((
    b"LMsk", b"Lr16", b"Lr32", b"Layr", b"Mt16", b"Mt32", b"Mtrn", b"Alph", b"FMsk",
    b"lnk2", b"lnk3", b"lnkE", b"FXid", b"FEid", b"FELS", b"PxSD", b"pths", b"extd",
    b"extn", b"cinf", b"artd",
))
_HIGH_DEPTH_LAYER_KEYS = (b"Lr16", b"Lr32")

# 層の種類の決め方は psd_tools 1.17.4 の PSDImage._init と同じ順にする。
_TYPE_KEYS = (b"TySh", b"tySh")
_SMART_OBJECT_KEYS = (b"SoLd", b"SoLE", b"PlLd", b"plLd")
# psd_tools の adjustments.TYPES と同じ順（最初に当たったキーで種類が決まる）。
_ADJUSTMENT_CLASSES = (
    (b"SoCo", "SolidColorFill"),
    (b"PtFl", "PatternFill"),
    (b"GdFl", "GradientFill"),
    (b"CgEd", "BrightnessContrast"),
    (b"curv", "Curves"),
    (b"expA", "Exposure"),
    (b"levl", "Levels"),
    (b"vibA", "Vibrance"),
    (b"hue2", "HueSaturation"),
    (b"blnc", "ColorBalance"),
    (b"blwh", "BlackAndWhite"),
    (b"phfl", "PhotoFilter"),
    (b"mixr", "ChannelMixer"),
    (b"clrL", "ColorLookup"),
    (b"nvrt", "Invert"),
    (b"post", "Posterize"),
    (b"thrs", "Threshold"),
    (b"selc", "SelectiveColor"),
    (b"grdm", "GradientMap"),
)
_FILL_CLASSES = frozenset(("SolidColorFill", "PatternFill", "GradientFill"))
_GROUP_CLASSES = frozenset(("Group", "Artboard"))
_SHAPE_KEYS = (b"vogk", b"vmsk", b"vsms", b"vstk", b"vscg")
_ARTBOARD_KEYS = (b"artb", b"artd", b"abdd")

_U8 = struct.Struct(">B")
_U16 = struct.Struct(">H")
_I16 = struct.Struct(">h")
_U32 = struct.Struct(">I")
_U64 = struct.Struct(">Q")
_HEADER = struct.Struct(">4sH6xHIIHH")
_RECORD_BOUNDS = struct.Struct(">iiiiH")
_CHANNEL_PSD = struct.Struct(">hI")
_CHANNEL_PSB = struct.Struct(">hQ")
_RECORD_BLEND = struct.Struct(">4s4sBBBB")
_MASK_RECT = struct.Struct(">iiii")

# RLE をまとめて展開する時、一度に np.repeat へ渡す圧縮データの上限（一時配列を小さく保つ）。
_RLE_CHUNK_BYTES = 1 << 22

# PackBits の見出し 1 バイトごとの「入力の進み」と「出す画素の数」（行からはみ出さない時）。
# 0〜127 は続く h+1 バイトの写し、129〜255 は次の 1 バイトを 257-h 回繰り返す、128 は何もしない。
_PACKBITS_ADVANCE = np.array(
    [value + 2 if value < 128 else (1 if value == 128 else 2) for value in range(256)],
    dtype=np.int64,
)
_PACKBITS_OUTPUT = np.array(
    [value + 1 if value < 128 else (0 if value == 128 else 257 - value) for value in range(256)],
    dtype=np.int64,
)


class _Reader:
    """範囲を確かめながら読む小さな読み手。はみ出しは PsdFormatError にする。"""

    __slots__ = ("data", "pos", "end")

    def __init__(self, data: bytes, pos: int, end: int):
        self.data = data
        self.pos = int(pos)
        self.end = int(end)

    def need(self, size: int, reason: str) -> None:
        if size < 0 or self.pos + size > self.end:
            raise PsdFormatError(reason, f"offset_{self.pos}")

    def unpack(self, packer: struct.Struct, reason: str) -> tuple:
        self.need(packer.size, reason)
        values = packer.unpack_from(self.data, self.pos)
        self.pos += packer.size
        return values

    def take(self, size: int, reason: str) -> bytes:
        self.need(size, reason)
        start = self.pos
        self.pos += size
        return self.data[start:self.pos]

    def skip(self, size: int, reason: str) -> None:
        self.need(size, reason)
        self.pos += size


class ChannelInfo:
    """層の記録のチャンネル 1 本。``length`` は圧縮の種類の 2 バイトを含む長さ。"""

    __slots__ = ("id", "length", "offset")

    def __init__(self, channel_id: int, length: int, offset: int = -1):
        self.id = int(channel_id)
        self.length = int(length)
        # ファイルの中で、このチャンネルの頭（圧縮の種類の 2 バイト）がある位置。
        self.offset = int(offset)

    def __repr__(self) -> str:
        return f"ChannelInfo(id={self.id}, length={self.length}, offset={self.offset})"


class TaggedBlock:
    """層の記録の追加情報ブロック 1 つ（署名・キー・長さ・データの位置）。"""

    __slots__ = ("signature", "key", "offset", "length_size", "length", "data_offset")

    def __init__(
        self,
        signature: bytes,
        key: bytes,
        offset: int,
        length_size: int,
        length: int,
        data_offset: int,
    ):
        self.signature = bytes(signature)
        self.key = bytes(key)
        self.offset = int(offset)
        self.length_size = int(length_size)
        self.length = int(length)
        self.data_offset = int(data_offset)

    @property
    def end(self) -> int:
        return self.data_offset + self.length

    def __repr__(self) -> str:
        return f"TaggedBlock({self.key!r}, length={self.length})"


class LayerRecord:
    """層の記録 1 つ。位置はすべてファイルの頭からのバイト数。"""

    __slots__ = (
        "index",
        "top",
        "left",
        "bottom",
        "right",
        "channels",
        "blend_signature",
        "blend_mode",
        "opacity",
        "clipping",
        "flags",
        "filler",
        "offset",
        "extra_length_offset",
        "extra_offset",
        "extra_end",
        "mask_offset",
        "mask_length",
        "mask_rect",
        "blending_ranges_offset",
        "name_offset",
        "name_bytes",
        "blocks",
        "blocks_offset",
        "blocks_end",
        "name",
        "unicode_name",
        "keys",
        "section_type",
        "tree_divider",
    )

    @property
    def bbox(self) -> list[int]:
        """[left, top, right, bottom]（移す前の _record_bbox と同じ並び）。"""
        return [int(self.left), int(self.top), int(self.right), int(self.bottom)]

    @property
    def width(self) -> int:
        return int(self.right - self.left)

    @property
    def height(self) -> int:
        return int(self.bottom - self.top)

    @property
    def end(self) -> int:
        return int(self.extra_end)

    @property
    def display_name(self) -> str:
        """luni があればその名前（NUL も削らない）、なければ legacy 名。"""
        return self.unicode_name if self.unicode_name is not None else self.name

    @property
    def has_mask(self) -> bool:
        """マスクの記録の最初の矩形が空でないこと（移す前の _has_mask と同じ）。"""
        if self.mask_rect is None:
            return False
        top, left, bottom, right = self.mask_rect
        return bool(right > left and bottom > top)

    @property
    def pixel_data_irrelevant(self) -> bool:
        return bool(self.flags & 0x10)

    @property
    def channel_ids(self) -> list[int]:
        return [int(channel.id) for channel in self.channels]

    def block(self, key: bytes) -> TaggedBlock | None:
        """同じキーが複数あれば、psd_tools と同じく後ろのものを返す。"""
        found = None
        for block in self.blocks:
            if block.key == key:
                found = block
        return found


class LayerNode:
    """psd_tools の層 1 つに当たる群の木の節。"""

    __slots__ = ("record_index", "class_name", "children")

    def __init__(self, record_index: int | None, class_name: str):
        # 閉じられなかった群は記録を持たない（psd_tools の _record が None の群と同じ）。
        self.record_index = record_index
        self.class_name = str(class_name)
        self.children: list[LayerNode] = []

    def is_group(self) -> bool:
        return self.class_name in _GROUP_CLASSES

    @property
    def kind(self) -> str:
        """psd_tools の Layer.kind と同じ（クラス名を小文字にして layer を除く）。"""
        return self.class_name.lower().replace("layer", "")


class PsdDocument:
    """開いた PSD/PSB。``data`` はファイル全体のバイト列で、書き換えない。"""

    __slots__ = (
        "path",
        "data",
        "version",
        "channel_count",
        "height",
        "width",
        "depth",
        "color_mode",
        "image_resources_offset",
        "image_resources_length",
        "has_icc_profile",
        "layer_mask_length_offset",
        "layer_mask_length",
        "layer_mask_end",
        "layer_info_length_offset",
        "layer_info_length",
        "layer_info_end",
        "layer_count_offset",
        "layer_count_raw",
        "records",
        "channel_data_offset",
        "channel_data_end",
        "global_block_keys",
    )

    @property
    def is_psb(self) -> bool:
        return self.version == 2

    def channel_compression(self, channel: ChannelInfo) -> int:
        """長さが 2 未満のチャンネルは psd_tools と同じく raw として扱う。"""
        if channel.length < 2:
            return COMPRESSION_RAW
        return int(_U16.unpack_from(self.data, channel.offset)[0])

    def channel_payload(self, channel: ChannelInfo) -> memoryview:
        """圧縮の種類の 2 バイトを除いた、チャンネルの画素のバイト列（写さない）。"""
        if channel.length < 2:
            return memoryview(b"")
        start = channel.offset + 2
        return memoryview(self.data)[start:channel.offset + channel.length]

    def layer_tree(self) -> LayerNode:
        return build_layer_tree(self.records)

    def visible_layers(self) -> tuple[dict[int, LayerNode], dict[int, int], list[dict[str, Any]]]:
        """群の木を psd_tools の順に歩き、(記録→節, 記録→深さ, 記録の無い節) を返す。"""
        return walk_layer_tree(self.layer_tree())


# ---------------------------------------------------------------------------
# 読み取り
# ---------------------------------------------------------------------------

def open_psd(path: str | Path) -> PsdDocument:
    """PSD/PSB を開く。壊れた形は PsdFormatError、扱わない形は PsdUnsupportedError。"""
    source = Path(path)
    with source.open("rb") as handle:
        data = handle.read()
    return parse_psd(data, path=str(source))


def parse_psd(data: bytes, *, path: str = "") -> PsdDocument:
    payload = bytes(data)
    try:
        return _parse_document(payload, str(path))
    except PsdError:
        raise
    except (struct.error, IndexError, OverflowError) as exc:
        # 範囲の確かめから漏れた形も、理由付きの ValueError にそろえる。
        raise PsdFormatError("psd_parse_failed", type(exc).__name__) from exc


def _parse_document(data: bytes, path: str) -> PsdDocument:
    size = len(data)
    reader = _Reader(data, 0, size)
    signature, version, channel_count, height, width, depth, color_mode = reader.unpack(
        _HEADER,
        "psd_header_truncated",
    )
    if signature != b"8BPS":
        raise PsdFormatError("not_a_psd_file")
    if version not in (1, 2):
        raise PsdUnsupportedError("unsupported_psd_version", version)
    psb = version == 2
    length_packer = _U64 if psb else _U32

    (color_mode_length,) = reader.unpack(_U32, "color_mode_data_truncated")
    reader.skip(color_mode_length, "color_mode_data_truncated")
    (resources_length,) = reader.unpack(_U32, "image_resources_truncated")
    resources_offset = reader.pos
    reader.skip(resources_length, "image_resources_truncated")

    document = PsdDocument()
    document.path = path
    document.data = data
    document.version = int(version)
    document.channel_count = int(channel_count)
    document.height = int(height)
    document.width = int(width)
    document.depth = int(depth)
    document.color_mode = int(color_mode)
    document.image_resources_offset = int(resources_offset)
    document.image_resources_length = int(resources_length)
    document.has_icc_profile = _has_image_resource(
        data,
        resources_offset,
        resources_offset + resources_length,
        _ICC_PROFILE_RESOURCE,
    )
    document.layer_mask_length_offset = int(reader.pos)
    (layer_mask_length,) = reader.unpack(length_packer, "layer_mask_section_truncated")
    layer_mask_start = reader.pos
    layer_mask_end = layer_mask_start + int(layer_mask_length)
    if layer_mask_end > size:
        raise PsdFormatError("layer_mask_section_truncated", f"offset_{layer_mask_start}")
    document.layer_mask_length = int(layer_mask_length)
    document.layer_mask_end = int(layer_mask_end)
    document.layer_info_length_offset = None
    document.layer_info_length = 0
    document.layer_info_end = int(layer_mask_start)
    document.layer_count_offset = None
    document.layer_count_raw = 0
    document.records = []
    document.channel_data_offset = int(layer_mask_start)
    document.channel_data_end = int(layer_mask_start)
    document.global_block_keys = ()
    if not layer_mask_length:
        return document

    section = _Reader(data, layer_mask_start, layer_mask_end)
    document.layer_info_length_offset = int(section.pos)
    (layer_info_length,) = section.unpack(length_packer, "layer_info_truncated")
    layer_info_start = section.pos
    layer_info_end = layer_info_start + int(layer_info_length)
    if layer_info_end > layer_mask_end:
        raise PsdFormatError("layer_info_truncated", f"offset_{layer_info_start}")
    document.layer_info_length = int(layer_info_length)
    document.layer_info_end = int(layer_info_end)
    document.channel_data_offset = int(layer_info_end)
    document.channel_data_end = int(layer_info_end)
    if layer_info_length:
        info = _Reader(data, layer_info_start, layer_info_end)
        document.layer_count_offset = int(info.pos)
        (layer_count,) = info.unpack(_I16, "layer_info_truncated")
        document.layer_count_raw = int(layer_count)
        records = [_parse_record(info, index, psb) for index in range(abs(int(layer_count)))]
        document.channel_data_offset = int(info.pos)
        for record in records:
            for channel in record.channels:
                channel.offset = int(info.pos)
                info.skip(channel.length, "channel_data_truncated")
        document.channel_data_end = int(info.pos)
        document.records = records
    document.global_block_keys = _global_block_keys(data, layer_info_end, layer_mask_end, psb)
    if not document.records:
        for key in _HIGH_DEPTH_LAYER_KEYS:
            if key in document.global_block_keys:
                # 16/32 ビットの文書は層を全体の追加情報（Lr16/Lr32）に持つ。この読み手では扱わない。
                raise PsdUnsupportedError(
                    "unsupported_psd_pixel_format",
                    f"depth_{int(depth)}_layers_in_{key.decode('ascii')}",
                )
    return document


def _parse_record(reader: _Reader, index: int, psb: bool) -> LayerRecord:
    data = reader.data
    record = LayerRecord()
    record.index = int(index)
    record.offset = int(reader.pos)
    top, left, bottom, right, channel_count = reader.unpack(
        _RECORD_BOUNDS,
        "layer_record_truncated",
    )
    channel_packer = _CHANNEL_PSB if psb else _CHANNEL_PSD
    channels = []
    for _ in range(int(channel_count)):
        channel_id, length = reader.unpack(channel_packer, "layer_record_truncated")
        channels.append(ChannelInfo(channel_id, length))
    blend_signature, blend_mode, opacity, clipping, flags, filler = reader.unpack(
        _RECORD_BLEND,
        "layer_record_truncated",
    )
    if blend_signature != b"8BIM":
        raise PsdFormatError("layer_record_signature_invalid", index)
    record.top = int(top)
    record.left = int(left)
    record.bottom = int(bottom)
    record.right = int(right)
    record.channels = channels
    record.blend_signature = blend_signature
    record.blend_mode = blend_mode
    record.opacity = int(opacity)
    record.clipping = int(clipping)
    record.flags = int(flags)
    record.filler = int(filler)

    record.extra_length_offset = int(reader.pos)
    (extra_length,) = reader.unpack(_U32, "layer_record_truncated")
    record.extra_offset = int(reader.pos)
    reader.need(int(extra_length), "layer_record_truncated")
    record.extra_end = int(reader.pos + int(extra_length))
    extra = _Reader(data, record.extra_offset, record.extra_end)

    record.mask_offset = int(extra.pos)
    (mask_length,) = extra.unpack(_U32, "layer_mask_data_truncated")
    mask_data_offset = extra.pos
    extra.skip(int(mask_length), "layer_mask_data_truncated")
    record.mask_length = int(mask_length)
    record.mask_rect = None
    if mask_length:
        if mask_length < 18:
            raise PsdFormatError("layer_mask_data_truncated", index)
        record.mask_rect = tuple(int(value) for value in _MASK_RECT.unpack_from(data, mask_data_offset))

    record.blending_ranges_offset = int(extra.pos)
    (blending_length,) = extra.unpack(_U32, "layer_blending_ranges_truncated")
    extra.skip(int(blending_length), "layer_blending_ranges_truncated")

    record.name_offset = int(extra.pos)
    (name_length,) = extra.unpack(_U8, "layer_name_truncated")
    record.name_bytes = extra.take(int(name_length), "layer_name_truncated")
    # 名前は長さの 1 バイトを含めて 4 の倍数に詰める（足りなければ記録の終わりまで）。
    padding = (-(1 + int(name_length))) % 4
    extra.pos = min(extra.pos + padding, extra.end)

    record.blocks_offset = int(extra.pos)
    blocks = []
    while extra.end - extra.pos >= 8:
        block_offset = extra.pos
        block_signature = data[block_offset:block_offset + 4]
        if block_signature not in _BLOCK_SIGNATURES:
            # psd_tools と同じく、署名が正しくない所で読むのをやめる（残りはそのまま持つ）。
            break
        key = data[block_offset + 4:block_offset + 8]
        extra.pos += 8
        big = psb and key in _PSB_BIG_KEYS
        (length,) = extra.unpack(_U64 if big else _U32, "tagged_block_truncated")
        data_offset = extra.pos
        extra.skip(int(length), "tagged_block_truncated")
        blocks.append(TaggedBlock(block_signature, key, block_offset, 8 if big else 4, length, data_offset))
    record.blocks = blocks
    record.blocks_end = int(extra.pos)
    reader.pos = record.extra_end

    record.name = record.name_bytes.decode("mac_roman")
    record.keys = frozenset(block.key for block in blocks)
    luni = record.block(b"luni")
    record.unicode_name = None if luni is None else _decode_unicode_block(data, luni)
    lsct = record.block(b"lsct")
    lsdk = record.block(b"lsdk")
    # 記録の section_type は移す前の _section_type と同じく lsct を先に見る。
    if lsct is not None:
        record.section_type = _section_kind(data, lsct) or 0
    elif lsdk is not None:
        record.section_type = _section_kind(data, lsdk) or 0
    else:
        record.section_type = 0
    # 群の木は psd_tools の _init と同じく lsdk を優先する。
    record.tree_divider = _section_kind(data, lsdk if lsdk is not None else lsct)
    return record


def _decode_unicode_block(data: bytes, block: TaggedBlock) -> str:
    if block.length < 4:
        return ""
    (count,) = _U32.unpack_from(data, block.data_offset)
    start = block.data_offset + 4
    raw = data[start:min(start + 2 * int(count), block.end)]
    if len(raw) % 2:
        raw = raw[:-1]
    return raw.decode("utf-16-be", "replace")


def _section_kind(data: bytes, block: TaggedBlock | None) -> int | None:
    if block is None or block.length < 4:
        return None
    (kind,) = _U32.unpack_from(data, block.data_offset)
    return int(kind) if kind <= SECTION_BOUNDING_DIVIDER else None


def _has_image_resource(data: bytes, start: int, end: int, resource_id: int) -> bool:
    pos = int(start)
    while pos + 6 <= end:
        if data[pos:pos + 4] not in _RESOURCE_SIGNATURES:
            return False
        (current_id,) = _U16.unpack_from(data, pos + 4)
        pos += 6
        if pos >= end:
            return False
        name_size = 1 + data[pos]
        pos += name_size + (name_size % 2)
        if pos + 4 > end:
            return False
        (length,) = _U32.unpack_from(data, pos)
        pos += 4
        if int(current_id) == int(resource_id):
            return True
        pos += int(length) + (int(length) % 2)
    return False


def _global_block_keys(data: bytes, start: int, end: int, psb: bool) -> tuple[bytes, ...]:
    """層情報の後ろ（全体のマスクと全体の追加情報）にあるブロックのキーを返す。"""
    pos = int(start)
    if pos + 4 <= end:
        (mask_length,) = _U32.unpack_from(data, pos)
        pos += 4 + int(mask_length)
    keys = []
    while pos + 12 <= end:
        if data[pos:pos + 4] not in _BLOCK_SIGNATURES:
            break
        key = data[pos + 4:pos + 8]
        pos += 8
        if psb and key in _PSB_BIG_KEYS:
            if pos + 8 > end:
                break
            (length,) = _U64.unpack_from(data, pos)
            pos += 8
        else:
            (length,) = _U32.unpack_from(data, pos)
            pos += 4
        keys.append(bytes(key))
        pos += int(length) + ((-int(length)) % 4)
    return tuple(keys)


# ---------------------------------------------------------------------------
# 群の木
# ---------------------------------------------------------------------------

def build_layer_tree(records) -> LayerNode:
    """psd_tools 1.17.4 の PSDImage._init と同じ規則で群の木を組む。

    種類 3（群の終わりの区切り）で群を作って積み、種類 1・2 で群を閉じてその記録を
    群の記録にする。種類 3 の記録自体は誰の記録にもならない。閉じる群が無い区切りは
    psd_tools では TypeError になるので、ここでは理由付きで断る。
    """
    root = LayerNode(None, "PSDImage")
    stack = [root]
    for record in records:
        current = stack[-1]
        keys = record.keys
        divider = record.tree_divider
        node: LayerNode | None = None
        end_of_group = False
        if divider is not None and divider != SECTION_OTHER:
            if divider == SECTION_BOUNDING_DIVIDER:
                node = LayerNode(None, "Group")
                stack.append(node)
            else:
                if len(stack) < 2:
                    raise PsdFormatError("section_divider_unbalanced", record.index)
                node = stack.pop()
                node.record_index = int(record.index)
                if any(key in keys for key in _ARTBOARD_KEYS):
                    node.class_name = "Artboard"
                end_of_group = True
        elif any(key in keys for key in _TYPE_KEYS):
            node = LayerNode(record.index, "TypeLayer")
        elif any(key in keys for key in _SMART_OBJECT_KEYS):
            node = LayerNode(record.index, "SmartObjectLayer")
        else:
            for key, class_name in _ADJUSTMENT_CLASSES:
                if key in keys:
                    node = LayerNode(record.index, class_name)
                    break
        shape = record.pixel_data_irrelevant and any(key in keys for key in _SHAPE_KEYS)
        if shape and (node is None or node.class_name in _FILL_CLASSES):
            node = LayerNode(record.index, "ShapeLayer")
        if node is None:
            node = LayerNode(record.index, "PixelLayer")
        if not end_of_group:
            current.children.append(node)
    return root


def walk_layer_tree(root: LayerNode) -> tuple[dict[int, LayerNode], dict[int, int], list[dict[str, Any]]]:
    """移す前の _visible_mapping・_layer_depths と同じ順（深さ優先・先に親）で歩く。"""
    mapping: dict[int, LayerNode] = {}
    depths: dict[int, int] = {}
    missing: list[dict[str, Any]] = []
    stack = [(iter(root.children), 0)]
    while stack:
        iterator, depth = stack[-1]
        node = next(iterator, None)
        if node is None:
            stack.pop()
            continue
        if node.record_index is None:
            # 閉じられなかった群。psd_tools では名前を読めず空になる。
            missing.append({"name": "", "depth": int(depth)})
        else:
            mapping[int(node.record_index)] = node
            depths[int(node.record_index)] = int(depth)
        if node.is_group():
            stack.append((iter(node.children), depth + 1))
    return mapping, depths, missing


# ---------------------------------------------------------------------------
# 画素
# ---------------------------------------------------------------------------

class RgbaImage:
    """PIL.Image の代わりに使う小さな RGBA 画像（(高さ, 幅, 4) の uint8 配列を包む）。

    ``size``（幅, 高さ）・``mode``・``convert("RGBA")``・``crop`` と、
    ``np.asarray(image)`` で配列を返す ``__array__`` だけを持つ。
    """

    __slots__ = ("array",)
    mode = "RGBA"

    def __init__(self, array):
        value = np.asarray(array)
        if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 4:
            raise ValueError("rgba_image_array_invalid")
        self.array = value

    @classmethod
    def blank(cls, width: int, height: int) -> "RgbaImage":
        """透明の黒で埋めた画像（PIL の Image.new("RGBA", size, (0, 0, 0, 0)) と同じ）。"""
        return cls(np.zeros((int(height), int(width), 4), dtype=np.uint8))

    @property
    def size(self) -> tuple[int, int]:
        return int(self.array.shape[1]), int(self.array.shape[0])

    @property
    def width(self) -> int:
        return int(self.array.shape[1])

    @property
    def height(self) -> int:
        return int(self.array.shape[0])

    def convert(self, mode: str) -> "RgbaImage":
        if str(mode) != "RGBA":
            raise ValueError(f"unsupported_image_mode:{mode}")
        return self

    def crop(self, box) -> "RgbaImage":
        left, top, right, bottom = (int(value) for value in box)
        width, height = self.size
        if left < 0 or top < 0 or right > width or bottom > height or right < left or bottom < top:
            raise ValueError("crop_box_out_of_bounds")
        return RgbaImage(self.array[top:bottom, left:right])

    def tobytes(self) -> bytes:
        return np.ascontiguousarray(self.array).tobytes()

    def __array__(self, dtype=None, copy=None):
        value = self.array
        if dtype is not None and np.dtype(dtype) != value.dtype:
            return value.astype(dtype)
        if copy:
            return value.copy()
        return value

    def __repr__(self) -> str:
        return f"RgbaImage(size={self.size})"


def require_rgb8(document: PsdDocument) -> None:
    """画素を展開できるのは 8 ビットの RGB だけ。ほかは理由付きで断る。"""
    if int(document.depth) != 8:
        raise PsdUnsupportedError("unsupported_psd_pixel_format", f"depth_{int(document.depth)}")
    if int(document.color_mode) != COLOR_MODE_RGB:
        raise PsdUnsupportedError(
            "unsupported_psd_pixel_format",
            f"color_mode_{int(document.color_mode)}",
        )


def _record_at(document: PsdDocument, record_index: int) -> LayerRecord:
    index = int(record_index)
    if index < 0 or index >= len(document.records):
        raise PsdError("record_index_out_of_range")
    return document.records[index]


def _check_dimensions(width: int, height: int) -> None:
    if (
        width > _MAX_DIMENSION
        or height > _MAX_DIMENSION
        or int(width) * int(height) > _MAX_LAYER_PIXELS
    ):
        raise PsdUnsupportedError("layer_dimensions_out_of_range", f"{width}x{height}")


def decode_channel_planes(
    document: PsdDocument,
    channels,
    width: int,
    height: int,
) -> list[np.ndarray]:
    """チャンネルを (高さ, 幅) の uint8 に展開する。8 ビットの raw と RLE だけを扱う。

    raw は短ければ断り、長ければ頭から使う（psd_tools の decompress と同じ）。
    RLE は psd_tools と同じ寛容な PackBits で、行の長さの表は PSD が 2 バイト、PSB が 4 バイト。
    ZIP とそのほかの圧縮は例外で落とさず、PsdUnsupportedError で理由を付けて断る。
    """
    require_rgb8(document)
    width = int(width)
    height = int(height)
    if width <= 0 or height <= 0:
        raise PsdError("record_pixels_unavailable")
    _check_dimensions(width, height)
    planes: list[np.ndarray | None] = [None] * len(channels)
    rle_jobs: list[tuple[int, int, int]] = []
    expected = width * height
    for position, channel in enumerate(channels):
        compression = document.channel_compression(channel)
        start = channel.offset + 2
        end = channel.offset + channel.length
        available = max(0, end - start)
        if compression == COMPRESSION_RAW:
            if channel.length < 2 or available < expected:
                raise PsdFormatError(
                    "channel_data_length_mismatch",
                    f"id_{channel.id}:{available}<{expected}",
                )
            planes[position] = np.frombuffer(
                document.data,
                dtype=np.uint8,
                count=expected,
                offset=start,
            ).reshape(height, width)
        elif compression == COMPRESSION_RLE:
            rle_jobs.append((position, start, end))
        elif compression == COMPRESSION_ZIP:
            raise PsdUnsupportedError("unsupported_channel_compression", "zip")
        elif compression == COMPRESSION_ZIP_PREDICTION:
            raise PsdUnsupportedError("unsupported_channel_compression", "zip_with_prediction")
        else:
            raise PsdUnsupportedError("unsupported_channel_compression", compression)
    if rle_jobs:
        decoded = _decode_rle_channels(
            document,
            [(start, end) for _position, start, end in rle_jobs],
            width,
            height,
        )
        for (position, _start, _end), plane in zip(rle_jobs, decoded):
            planes[position] = plane
    return planes  # type: ignore[return-value]


def _decode_rle_channels(
    document: PsdDocument,
    jobs: list[tuple[int, int]],
    width: int,
    height: int,
) -> list[np.ndarray]:
    data = document.data
    count_dtype = np.dtype(">u4") if document.is_psb else np.dtype(">u2")
    table_size = int(height) * count_dtype.itemsize
    # topil 相当は色→アルファの順に渡すが、ファイルの中ではアルファ（-1）が先にある。
    # 開始位置で並べ替えて一度に展開し、渡された順へ戻して返す。同じチャンネルは 1 回だけ展開する。
    unique_jobs = sorted(set((int(start), int(end)) for start, end in jobs))
    slot_by_job = {job: slot for slot, job in enumerate(unique_jobs)}
    starts_parts = []
    ends_parts = []
    previous_end = -1
    for start, end in unique_jobs:
        if end - start < table_size:
            raise PsdFormatError("rle_table_truncated", f"offset_{start}")
        if start < previous_end:
            raise PsdFormatError("rle_channel_order_invalid", f"offset_{start}")
        previous_end = end
        counts = np.frombuffer(data, dtype=count_dtype, count=height, offset=start).astype(np.int64)
        row_starts = np.empty(height, dtype=np.int64)
        row_starts[0] = 0
        if height > 1:
            np.cumsum(counts[:-1], out=row_starts[1:])
        row_starts += start + table_size
        row_ends = row_starts + counts
        # psd_tools はチャンネルの中だけを読むので、行の範囲もチャンネルの終わりで切る。
        np.minimum(row_starts, end, out=row_starts)
        np.minimum(row_ends, end, out=row_ends)
        starts_parts.append(row_starts)
        ends_parts.append(row_ends)
    starts = np.concatenate(starts_parts)
    ends = np.concatenate(ends_parts)
    rows = _packbits_rows(np.frombuffer(data, dtype=np.uint8), data, starts, ends, int(width))
    planes = [rows[slot * height:(slot + 1) * height] for slot in range(len(unique_jobs))]
    return [planes[slot_by_job[(int(start), int(end))]] for start, end in jobs]


def _packbits_rows(
    buffer: np.ndarray,
    data: bytes,
    starts: np.ndarray,
    ends: np.ndarray,
    row_size: int,
) -> np.ndarray:
    """PackBits の行をまとめて展開する（psd_tools の寛容な rle.decode と同じ結果）。

    行ごとの見出しの歩みを全行で並べて進め（1 回で各行 1 歩）、出す画素は
    「圧縮データの各バイトを何回繰り返すか」の表に直して np.repeat で一度に作る。
    starts/ends は各行の [頭, 終わり)（ファイルの位置。行の順に増える）。
    """
    row_count = int(starts.size)
    out = np.zeros((row_count, row_size), dtype=np.uint8)
    if row_count == 0 or row_size <= 0:
        return out
    # 位置と列は、足りる時は int32 で持つ（1 歩ごとの読み書きの量を半分にする）。
    small = int(buffer.size) + 1024 < (1 << 31) and int(row_size) + 1024 < (1 << 31)
    index_dtype = np.int32 if small else np.int64
    advance_table = _PACKBITS_ADVANCE.astype(index_dtype)
    output_table = _PACKBITS_OUTPUT.astype(index_dtype)
    produced = np.zeros(row_count, dtype=np.int64)
    rows = np.flatnonzero(starts < ends)
    pos = starts[rows].astype(index_dtype)
    end = ends[rows].astype(index_dtype)
    col = np.zeros(rows.size, dtype=index_dtype)
    headers: list[np.ndarray] = []
    literal_starts: list[np.ndarray] = []
    literal_ends: list[np.ndarray] = []
    run_positions: list[np.ndarray] = []
    run_lengths: list[np.ndarray] = []
    while rows.size:
        # 1 歩で各行の見出しを 1 つ進める。はみ出さない見出しは表を引くだけで進みと画素の数が決まる。
        header = buffer[pos]
        next_pos = pos + advance_table[header]
        next_col = col + output_table[header]
        finished = (next_pos >= end) | (next_col >= row_size)
        if not finished.any():
            headers.append(pos)
            pos = next_pos
            col = next_col
            continue
        done = np.flatnonzero(finished)
        produced[rows[done]] = next_col[done]
        over = (next_pos[done] > end[done]) | (next_col[done] > row_size)
        if over.any():
            # 行の終わりではみ出す見出し：psd_tools と同じく切り、その行をそこで終える。
            # 繰り返しの見出しが行の最後の 1 バイトなら何も出さない。写しは読める分と行の残りまで。
            odd = done[over]
            value = header[odd].astype(np.int64)
            begin = pos[odd].astype(np.int64) + 1
            stop = end[odd].astype(np.int64)
            start_col = col[odd].astype(np.int64)
            room = row_size - start_col
            run_ok = (value > 128) & (begin < stop)
            run_out = np.minimum(257 - value, room)
            literal_out = np.minimum(np.minimum(value + 1, stop - begin), room)
            literal_ok = (value < 128) & (literal_out > 0)
            if run_ok.any():
                run_positions.append(begin[run_ok].astype(index_dtype))
                run_lengths.append(run_out[run_ok].astype(index_dtype))
            if literal_ok.any():
                literal_starts.append(begin[literal_ok].astype(index_dtype))
                literal_ends.append((begin[literal_ok] + literal_out[literal_ok]).astype(index_dtype))
            produced[rows[odd]] = start_col + np.where(
                run_ok,
                run_out,
                np.where(literal_ok, literal_out, 0),
            )
            regular = np.ones(rows.size, dtype=bool)
            regular[odd] = False
            headers.append(pos[regular])
        else:
            headers.append(pos)
        keep = ~finished
        rows = rows[keep]
        pos = next_pos[keep]
        end = end[keep]
        col = next_col[keep]
    if headers:
        # はみ出さなかった見出しを、写しの範囲と繰り返しの位置・回数に直す。
        header_positions = np.concatenate(headers)
        values = buffer[header_positions]
        literal = values < 128
        begin = header_positions[literal] + 1
        literal_starts.append(begin)
        literal_ends.append(begin + output_table[values[literal]])
        run = values > 128
        run_positions.append(header_positions[run] + 1)
        run_lengths.append(output_table[values[run]])
        del header_positions, values, literal, run, begin

    full = produced == row_size
    full_rows = np.flatnonzero(full)
    if full_rows.size:
        low = int(starts[0])
        high = int(ends.max())
        span = high - low
        repeat = np.zeros(span, dtype=np.uint8)
        short_exists = bool(full_rows.size != row_count)

        def owned_by_full_rows(positions: np.ndarray) -> np.ndarray:
            owner = np.searchsorted(starts, positions, side="right") - 1
            return full[owner]

        if literal_starts:
            lit_start = np.concatenate(literal_starts)
            lit_end = np.concatenate(literal_ends)
            if short_exists:
                selected = owned_by_full_rows(lit_start)
                lit_start = lit_start[selected]
                lit_end = lit_end[selected]
            # 写しの範囲は重ならず、始まりと終わりも同じ位置に来ないので、代入だけで印を付けられる。
            marks = np.zeros(span + 1, dtype=np.int8)
            marks[lit_start - low] = 1
            marks[lit_end - low] = -1
            np.cumsum(marks[:-1], dtype=np.int8, out=repeat.view(np.int8))
        if run_positions:
            run_pos = np.concatenate(run_positions)
            run_len = np.concatenate(run_lengths)
            if short_exists:
                selected = owned_by_full_rows(run_pos)
                run_pos = run_pos[selected]
                run_len = run_len[selected]
            repeat[run_pos - low] = run_len.astype(np.uint8)
        region = buffer[low:high]
        full_starts = starts[full_rows] - low
        index = 0
        total = int(full_rows.size)
        while index < total:
            first = int(full_starts[index])
            stop = int(np.searchsorted(full_starts, first + _RLE_CHUNK_BYTES, side="right"))
            stop = max(stop, index + 1)
            last = int(full_starts[stop]) if stop < total else span
            stream = np.repeat(region[first:last], repeat[first:last])
            count = stop - index
            if stream.size != count * row_size:
                raise PsdFormatError("rle_decode_internal_mismatch", f"row_{int(full_rows[index])}")
            out[full_rows[index:stop]] = stream.reshape(count, row_size)
            index = stop
    for row in np.flatnonzero(~full):
        out[int(row)] = np.frombuffer(
            _packbits_row(data, int(starts[row]), int(ends[row]), row_size),
            dtype=np.uint8,
        )
    return out


def _packbits_row(data: bytes, start: int, end: int, size: int) -> bytes:
    """1 行の寛容な PackBits 展開（psd_tools.compression.rle.decode と同じ規則）。

    行をはみ出す繰り返しは切り、足りない入力は読める分だけ写し、残りは 0 で埋める。
    見出し 128 は何もしない。
    """
    result = bytearray(size)
    i = int(start)
    j = 0
    while i < end and j < size:
        header = data[i]
        i += 1
        if header > 128:
            if i >= end:
                break
            count = min(257 - header, size - j)
            result[j:j + count] = bytes((data[i],)) * count
            j += count
            i += 1
        elif header < 128:
            count = header + 1
            available = end - i
            actual = min(count, available, size - j)
            result[j:j + actual] = data[i:i + actual]
            j += actual
            i += min(count, available)
    return bytes(result)


def record_rgba_fast(document: PsdDocument, record_index: int) -> tuple[np.ndarray, list[int]]:
    """記録 1 つを (高さ, 幅, 4) の RGBA にする（移す前の record_image_fast_from_document と同じ）。

    チャンネル id 0〜2 を RGB、-1 と 3 をアルファにし、無いアルファは 255 にする。
    マスク（-2・-3）は使わない。合成も ICC の変換もしない。
    """
    require_rgb8(document)
    record = _record_at(document, record_index)
    bbox = record.bbox
    width = int(bbox[2] - bbox[0])
    height = int(bbox[3] - bbox[1])
    if width <= 0 or height <= 0:
        raise PsdError("record_pixels_unavailable")
    _check_dimensions(width, height)
    selected = []
    targets = []
    for channel in record.channels:
        target = 3 if channel.id == -1 else int(channel.id)
        if target not in (0, 1, 2, 3):
            continue
        selected.append(channel)
        targets.append(target)
    planes = decode_channel_planes(document, selected, width, height)
    seen = set(targets)
    if not {0, 1, 2}.issubset(seen):
        raise PsdError("rgb_channels_missing")
    # RGB は必ず全部そろうので先に埋めない。アルファが無い時だけ 255 で埋める。
    rgba = np.empty((height, width, 4), dtype=np.uint8)
    if 3 not in seen:
        rgba[..., 3] = 255
    for target, plane in zip(targets, planes):
        rgba[..., target] = plane
    return rgba, bbox


def record_rgba_topil(document: PsdDocument, record_index: int) -> np.ndarray | None:
    """psd_tools の layer.topil() に当たる RGBA。画素の無い層は None を返す。

    色のチャンネル（id 0 以上）を記録の並び順に先頭から 3 本使い、アルファは id -1。
    どれかの色のチャンネルにデータが無ければ None、アルファが無ければ 255 にする。
    マスクは使わない。psd_tools と違い ICC の変換はしない。
    """
    require_rgb8(document)
    record = _record_at(document, record_index)
    width = int(record.right - record.left)
    height = int(record.bottom - record.top)
    if width <= 0 or height <= 0:
        return None
    _check_dimensions(width, height)
    # psd_tools は同じ id が複数あれば後ろのチャンネルを使う。
    position_by_id = {int(channel.id): position for position, channel in enumerate(record.channels)}
    color_positions = [position_by_id[int(channel.id)] for channel in record.channels if channel.id >= 0]
    for position in color_positions:
        if record.channels[position].length <= 2:
            return None
    if len(color_positions) < 3:
        raise PsdError("rgb_channels_missing")
    positions = list(color_positions[:3])
    alpha_position = position_by_id.get(-1)
    if alpha_position is not None and record.channels[alpha_position].length <= 2:
        alpha_position = None
    if alpha_position is not None:
        positions.append(alpha_position)
    planes = decode_channel_planes(
        document,
        [record.channels[position] for position in positions],
        width,
        height,
    )
    rgba = np.empty((height, width, 4), dtype=np.uint8)
    for target in range(3):
        rgba[..., target] = planes[target]
    rgba[..., 3] = planes[3] if alpha_position is not None else 255
    return rgba


# ---------------------------------------------------------------------------
# 書き手（記録の legacy 名と luni だけを書き換える）
# ---------------------------------------------------------------------------

def _pascal_name(text: str) -> bytes:
    try:
        encoded = str(text).encode("mac_roman")
    except UnicodeEncodeError as exc:
        raise PsdError("legacy_name_unencodable") from exc
    if len(encoded) > 255:
        raise PsdError("legacy_name_too_long", len(encoded))
    value = bytes((len(encoded),)) + encoded
    return value + b"\0" * ((-len(value)) % 4)


def _unicode_block(signature: bytes, text: str) -> bytes:
    units = str(text).encode("utf-16-be")
    body = _U32.pack(len(units) // 2) + units
    body += b"\0" * ((-len(body)) % 4)
    return bytes(signature) + b"luni" + _U32.pack(len(body)) + body


def _renamed_record(document: PsdDocument, record: LayerRecord, legacy: str, unicode_text: str) -> list:
    view = memoryview(document.data)
    blocks: list[Any] = []
    replaced = False
    for block in record.blocks:
        if block.key == b"luni":
            blocks.append(_unicode_block(block.signature, unicode_text))
            replaced = True
        else:
            blocks.append(view[block.offset:block.end])
    if not replaced:
        blocks.append(_unicode_block(b"8BIM", unicode_text))
    extra = [
        # マスクと混合範囲は長さのフィールドごとそのまま写す。
        view[record.mask_offset:record.name_offset],
        _pascal_name(legacy),
        *blocks,
        # 読まなかった残り（署名の無い詰め物など）もそのまま写す。
        view[record.blocks_end:record.extra_end],
    ]
    extra_length = sum(len(part) for part in extra)
    if extra_length > 0xFFFFFFFF:
        raise PsdError("layer_record_too_large", record.index)
    return [view[record.offset:record.extra_length_offset], _U32.pack(extra_length), *extra]


def renamed_copy_parts(document: PsdDocument, renames: Mapping[int, tuple[str, str]]) -> list:
    """書き換えた PSD を、そのまま書き出せる部品の並びで返す。

    ``renames`` は {記録の番号: (legacy 名, luni の名前)}。チャンネルの画素のバイトは
    触らずにそのまま写し、記録の追加情報の長さ・層情報の長さ・層とマスクの節の長さを
    直す。層情報の詰めは元の長さと同じ境界（4 の倍数なら 4、偶数なら 2）にそろえる。
    """
    wanted = {int(key): (str(value[0]), str(value[1])) for key, value in dict(renames or {}).items()}
    view = memoryview(document.data)
    if document.layer_info_length_offset is None or not document.records:
        if wanted:
            raise PsdError("layer_records_missing")
        return [view]
    for record_index in wanted:
        _record_at(document, record_index)
    length_packer = _U64 if document.is_psb else _U32
    body: list[Any] = [view[document.layer_count_offset:document.layer_count_offset + 2]]
    for record in document.records:
        names = wanted.get(int(record.index))
        if names is None:
            body.append(view[record.offset:record.extra_end])
        else:
            body.extend(_renamed_record(document, record, names[0], names[1]))
    body.append(view[document.channel_data_offset:document.channel_data_end])
    content_length = sum(len(part) for part in body)
    original = int(document.layer_info_length)
    alignment = 4 if original % 4 == 0 else (2 if original % 2 == 0 else 1)
    padding = (-content_length) % alignment
    if padding:
        body.append(b"\0" * padding)
    layer_info_length = content_length + padding
    rest = view[document.layer_info_end:document.layer_mask_end]
    layer_mask_length = length_packer.size + layer_info_length + len(rest)
    limit = 0xFFFFFFFFFFFFFFFF if document.is_psb else 0xFFFFFFFF
    if layer_mask_length > limit:
        raise PsdError("layer_mask_section_too_large")
    return [
        view[:document.layer_mask_length_offset],
        length_packer.pack(layer_mask_length),
        length_packer.pack(layer_info_length),
        *body,
        rest,
        view[document.layer_mask_end:],
    ]


def build_renamed_copy(document: PsdDocument, renames: Mapping[int, tuple[str, str]]) -> bytes:
    return b"".join(bytes(part) if isinstance(part, memoryview) else part
                    for part in renamed_copy_parts(document, renames))


def save_renamed_copy(
    document: PsdDocument,
    renames: Mapping[int, tuple[str, str]],
    path: str | Path,
) -> None:
    """書き換えた PSD を ``path`` へ書く（全体を一度に組み立てず、部品ごとに書く）。

    移す前の psd_tools の save と同じく fsync はしない（呼び出し元が os.replace で置き換える）。
    """
    parts = renamed_copy_parts(document, renames)
    with Path(path).open("wb") as handle:
        for part in parts:
            handle.write(part)


def _packbits_plane(plane: np.ndarray, psb: bool) -> bytes:
    """8 ビットの面（高さ, 幅）を圧縮 1（PackBits）の中身にする（圧縮の種類の 2 バイトは含まない）。

    全部が同じ値の行は繰り返しの組で、それ以外の行は 128 バイトずつの素の組で詰める。
    透明な余白の多い層を小さく保ちつつ、画素ごとの Python の繰り返しを使わない。
    """
    plane = np.ascontiguousarray(plane, dtype=np.uint8)
    height, width = (int(value) for value in plane.shape)
    full, rest = divmod(width, 128)
    literal_length = full * 129 + (rest + 1 if rest else 0)
    run_length = full * 2 + (2 if rest else 0)
    constant = plane.min(axis=1) == plane.max(axis=1)
    rows: list[bytes] = [b""] * height
    literal_rows = np.nonzero(~constant)[0]
    if literal_rows.size:
        parts = []
        if full:
            chunks = np.empty((literal_rows.size, full, 129), dtype=np.uint8)
            chunks[:, :, 0] = 127
            chunks[:, :, 1:] = plane[literal_rows, :full * 128].reshape(literal_rows.size, full, 128)
            parts.append(chunks.reshape(literal_rows.size, full * 129))
        if rest:
            tail = np.empty((literal_rows.size, rest + 1), dtype=np.uint8)
            tail[:, 0] = rest - 1
            tail[:, 1:] = plane[literal_rows, full * 128:]
            parts.append(tail)
        block = np.hstack(parts) if len(parts) > 1 else parts[0]
        for position, row in enumerate(literal_rows.tolist()):
            rows[row] = block[position].tobytes()
    run_rows = np.nonzero(constant)[0]
    if run_rows.size:
        values = plane[run_rows, 0]
        block = np.empty((run_rows.size, run_length), dtype=np.uint8)
        if full:
            pairs = np.empty((run_rows.size, full, 2), dtype=np.uint8)
            pairs[:, :, 0] = 0x81  # 257 - 128：同じ値を 128 回
            pairs[:, :, 1] = values[:, None]
            block[:, :full * 2] = pairs.reshape(run_rows.size, full * 2)
        if rest:
            # 2 回以上は繰り返しの組、1 回だけは素の組（見出し 0）で書く。
            block[:, full * 2] = (257 - rest) & 0xFF if rest >= 2 else 0
            block[:, full * 2 + 1] = values
        for position, row in enumerate(run_rows.tolist()):
            rows[row] = block[position].tobytes()
    counts = np.where(constant, run_length, literal_length).astype(">u4" if psb else ">u2")
    return counts.tobytes() + b"".join(rows)


def _encoded_channel(plane: np.ndarray, psb: bool) -> bytes:
    """チャンネル 1 本のデータ（圧縮の種類の 2 バイト込み）。PackBits と生の小さい方を使う。"""
    plane = np.ascontiguousarray(plane, dtype=np.uint8)
    raw = plane.tobytes()
    packed = _packbits_plane(plane, psb)
    if len(packed) < len(raw):
        return _U16.pack(1) + packed
    return _U16.pack(0) + raw


def patched_copy_parts(
    document: PsdDocument,
    patches: Mapping[int, tuple[Any, np.ndarray]],
    renames: Mapping[int, tuple[str, str]] | None = None,
) -> list:
    """記録の画素を差し替えた PSD を、そのまま書き出せる部品の並びで返す。

    ``patches`` は {記録の番号: ([left, top, right, bottom], (高さ, 幅, 4) の RGBA の uint8)}。
    差し替える記録は外枠と色・アルファのチャンネル（0〜2・-1、あれば 3）を新しい画素で
    書き直す。マスク（-2・-3）などほかのチャンネルは元のバイトのまま写し、アルファの無い
    記録には -1 を足す。``renames`` は renamed_copy_parts と同じ。ほかの記録のバイト・
    群の区切り・追加情報・統合画像は触らず、長さのフィールドだけを直す。
    """
    require_rgb8(document)
    view = memoryview(document.data)
    if document.layer_info_length_offset is None or not document.records:
        raise PsdError("layer_records_missing")
    wanted = {int(key): (str(value[0]), str(value[1])) for key, value in dict(renames or {}).items()}
    for record_index in wanted:
        _record_at(document, record_index)
    psb = bool(document.is_psb)
    channel_packer = _CHANNEL_PSB if psb else _CHANNEL_PSD
    replaced: dict[int, tuple[tuple[int, int, int, int], list]] = {}
    for record_index, (bbox, rgba) in dict(patches or {}).items():
        record = _record_at(document, int(record_index))
        left, top, right, bottom = (int(value) for value in tuple(bbox)[:4])
        pixels = np.asarray(rgba, dtype=np.uint8)
        if right <= left or bottom <= top or pixels.shape != (bottom - top, right - left, 4):
            raise PsdError("patch_shape_invalid", int(record_index))
        _check_dimensions(right - left, bottom - top)
        planes = {0: pixels[..., 0], 1: pixels[..., 1], 2: pixels[..., 2], -1: pixels[..., 3], 3: pixels[..., 3]}
        ids = [int(channel.id) for channel in record.channels]
        channels: list = []
        if -1 not in ids and 3 not in ids:
            channels.append((-1, _encoded_channel(planes[-1], psb)))
        for channel in record.channels:
            channel_id = int(channel.id)
            if channel_id in planes:
                channels.append((channel_id, _encoded_channel(planes[channel_id], psb)))
            else:
                channels.append((channel_id, view[channel.offset:channel.offset + channel.length]))
        replaced[int(record_index)] = ((left, top, right, bottom), channels)
    length_packer = _U64 if psb else _U32
    body: list[Any] = [view[document.layer_count_offset:document.layer_count_offset + 2]]
    for record in document.records:
        index = int(record.index)
        names = wanted.get(index)
        if names is None:
            record_parts = [view[record.offset:record.extra_length_offset], view[record.extra_length_offset:record.extra_end]]
        else:
            record_parts = _renamed_record(document, record, names[0], names[1])
        if index in replaced:
            (left, top, right, bottom), channels = replaced[index]
            head = [_RECORD_BOUNDS.pack(top, left, bottom, right, len(channels))]
            head.extend(channel_packer.pack(int(channel_id), len(payload)) for channel_id, payload in channels)
            head.append(_RECORD_BLEND.pack(
                record.blend_signature, record.blend_mode, int(record.opacity),
                int(record.clipping), int(record.flags), int(record.filler),
            ))
            record_parts = [b"".join(head), *record_parts[1:]]
        body.extend(record_parts)
    for record in document.records:
        index = int(record.index)
        if index in replaced:
            body.extend(payload for _channel_id, payload in replaced[index][1])
        else:
            body.extend(view[channel.offset:channel.offset + channel.length] for channel in record.channels)
    content_length = sum(len(part) for part in body)
    original = int(document.layer_info_length)
    alignment = 4 if original % 4 == 0 else (2 if original % 2 == 0 else 1)
    padding = (-content_length) % alignment
    if padding:
        body.append(b"\0" * padding)
    layer_info_length = content_length + padding
    rest = view[document.layer_info_end:document.layer_mask_end]
    layer_mask_length = length_packer.size + layer_info_length + len(rest)
    limit = 0xFFFFFFFFFFFFFFFF if psb else 0xFFFFFFFF
    if layer_info_length > limit or layer_mask_length > limit:
        raise PsdError("layer_mask_section_too_large")
    return [
        view[:document.layer_mask_length_offset],
        length_packer.pack(layer_mask_length),
        length_packer.pack(layer_info_length),
        *body,
        rest,
        view[document.layer_mask_end:],
    ]


def save_patched_copy(
    document: PsdDocument,
    patches: Mapping[int, tuple[Any, np.ndarray]],
    path: str | Path,
    renames: Mapping[int, tuple[str, str]] | None = None,
) -> None:
    """画素を差し替えた PSD を ``path`` へ部品ごとに書く（呼び出し元が os.replace で置き換える）。"""
    parts = patched_copy_parts(document, patches, renames)
    with Path(path).open("wb") as handle:
        for part in parts:
            handle.write(part)
