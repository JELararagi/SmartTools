# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Create a CSP exchange copy with exact ASCII raw-record markers."""

from __future__ import annotations

import os
from pathlib import Path
import tempfile
from typing import Any

from .exchange_manifest import (
    atomic_write_json,
    file_fingerprint,
    marked_display_name,
    marker_for_record,
)
from .exchange_scan import (
    record_image_fast_from_document,
    scan_document,
    visible_pixel_hash,
)
from .psd_lite import LayerRecord, open_psd, save_renamed_copy


class ExchangePrepareError(RuntimeError):
    pass


def _populate_visible_hashes(
    canonical: Path,
    baseline: dict[str, Any],
) -> None:
    """Populate pixel hashes without retaining a PSD-wide decoded layer cache."""
    document = open_psd(canonical)
    for item in baseline["records"]:
        if not bool(item.get("editable", False)):
            continue
        record_index = int(item["record_index"])
        try:
            image, bbox = record_image_fast_from_document(document, record_index)
        except ValueError as exc:
            if str(exc) != "record_pixels_unavailable":
                raise
            # Match scan_document(include_pixels=True): an empty visible pixel
            # row is retained in the manifest but is not externally editable.
            item["editable"] = False
            item["pixel_reason"] = "topil_unavailable"
            continue
        expected_bbox = [int(value) for value in item["bbox"]]
        if bbox != expected_bbox:
            raise ExchangePrepareError(f"canonical_bounds_changed:{record_index}")
        item["pixel_size"] = [int(image.size[0]), int(image.size[1])]
        item["visible_pixel_hash"] = visible_pixel_hash(image)


def _legacy_name(record: LayerRecord) -> str:
    return str(record.name or "")


def _unicode_name(record: LayerRecord) -> str:
    value = record.unicode_name
    return "" if value is None else str(value)


def prepare_exchange(
    canonical_path: str | Path,
    exchange_path: str | Path,
    manifest_path: str | Path,
) -> dict[str, Any]:
    """Build exchange and manifest without modifying canonical.

    Both the raw legacy name and the CSP-visible ``luni`` name carry the exact
    record marker. CSP regenerates legacy names when saving, while preserving
    the visible Unicode name, so identity cannot rely on the legacy field alone.

    交換ファイルは psd_lite の書き手で作る。記録の legacy 名と luni だけを書き換え、
    チャンネルの画素のバイトは元のまま写す。
    """
    canonical = Path(canonical_path).resolve()
    exchange = Path(exchange_path).resolve()
    manifest_destination = Path(manifest_path).resolve()
    if canonical == exchange:
        raise ExchangePrepareError("exchange_must_not_equal_canonical")

    baseline = scan_document(canonical, include_pixels=False)
    _populate_visible_hashes(canonical, baseline)
    editable = [
        int(item["record_index"])
        for item in baseline["records"]
        if bool(item.get("editable", False))
    ]
    expected_names = {
        int(item["record_index"]): str(item.get("display_name", ""))
        for item in baseline["records"]
        if int(item["record_index"]) in editable
    }

    exchange.parent.mkdir(parents=True, exist_ok=True)
    handle, write_name = tempfile.mkstemp(
        prefix=exchange.name + ".",
        suffix=".write.tmp",
        dir=str(exchange.parent),
    )
    os.close(handle)
    try:
        # 開く時にファイル全体を一度に読むので、元の写しを別に作らなくても同じ時点の中身になる。
        source = open_psd(canonical)
        if len(source.records) != len(baseline["records"]):
            raise ExchangePrepareError("canonical_structure_changed")
        renames = {}
        for record_index in editable:
            record = source.records[record_index]
            if not _unicode_name(record):
                raise ExchangePrepareError(f"unicode_name_missing:{record_index}")
            renames[record_index] = (
                marker_for_record(record_index),
                marked_display_name(record_index, expected_names[record_index]),
            )
        save_renamed_copy(source, renames, write_name)
        del source
        os.replace(write_name, exchange)
    except Exception:
        Path(write_name).unlink(missing_ok=True)
        raise

    check = open_psd(exchange)
    check_records = list(check.records)
    for record_index in editable:
        record = check_records[record_index]
        if _legacy_name(record) != marker_for_record(record_index):
            raise ExchangePrepareError(f"legacy_marker_roundtrip_failed:{record_index}")
        expected_display = marked_display_name(record_index, expected_names[record_index])
        if _unicode_name(record) != expected_display:
            raise ExchangePrepareError(f"unicode_marker_roundtrip_failed:{record_index}")
    del check, check_records

    exchange_scan = scan_document(exchange, include_pixels=False)
    if exchange_scan["structural_signature"] != baseline["structural_signature"]:
        raise ExchangePrepareError("exchange_structure_changed")
    baseline["exchange"] = file_fingerprint(exchange)
    baseline["exchange_marked_records"] = editable
    atomic_write_json(manifest_destination, baseline)
    return {
        "ok": True,
        "canonical": baseline["canonical"],
        "exchange": baseline["exchange"],
        "manifest_path": str(manifest_destination),
        "editable_records": editable,
        "structural_signature": baseline["structural_signature"],
    }
