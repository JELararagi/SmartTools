# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Finite one-shot external PSD scanner.

This compatibility entry point intentionally has no resident loop, heartbeat,
poll interval, process monitor, or periodic JSON writer.  Production bridge
sessions use :mod:`win_events` and call :func:`worker_scan.scan_once` only after
a native file-change notification.  The command remains available for explicit
diagnostics when launched as a package module.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import tempfile
from typing import Any

if not __package__:
    # Direct file-path execution previously synthesized a package by mutating
    # the interpreter module table.  That reload-unsafe bootstrap has been removed.  Invoke with
    # ``python -m <extension_package>.external_bridge.csp_worker`` instead.
    raise SystemExit(2)

from .worker_scan import scan_once


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        if json.loads(path.read_text(encoding="utf-8")) != value:
            raise OSError("one_shot_result_readback_mismatch")
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def _load_config(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("config_not_object")
    required = ("manifest_path", "exchange_path", "session_dir")
    missing = [name for name in required if not str(value.get(name, "") or "")]
    if missing:
        raise ValueError("missing_config:" + ",".join(missing))
    return value


def run(config_path: str | Path) -> int:
    config = _load_config(Path(config_path).resolve(strict=True))
    session = Path(str(config["session_dir"])).resolve(strict=True)
    manifest = Path(str(config["manifest_path"])).resolve(strict=True)
    exchange = Path(str(config["exchange_path"])).resolve(strict=True)
    if session not in manifest.parents or session not in exchange.parents:
        raise ValueError("one_shot_path_escape")
    result = scan_once(
        manifest,
        exchange,
        session / "results",
        time_budget_seconds=max(0.1, min(120.0, float(config.get("time_budget_seconds", 30.0)))),
    )
    _atomic_json(session / "results" / "one_shot_status.json", {
        "schema": 1,
        "ok": bool(result.get("ok", False)),
        "reason": str(result.get("reason", "") or ""),
        "changed_records": [int(value) for value in result.get("changed_records", ()) or ()],
    })
    return 0 if bool(result.get("ok", False)) else 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args(argv)
    return run(args.config)


if __name__ == "__main__":
    raise SystemExit(main())
