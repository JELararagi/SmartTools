# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""One-shot CSP exchange scanner for the T5.1 prototype."""

from __future__ import annotations

from collections import OrderedDict
import hashlib
import json
import os
from pathlib import Path
import tempfile
import threading
import time
from typing import Any

import numpy as np

from .exchange_manifest import (
    MARKER_PREFIX,
    file_fingerprint,
    marker_for_record,
    marker_from_display_name,
    read_manifest,
)
from .exchange_scan import (
    align_record_images,
    record_image_fast_from_document,
    scan_document,
    visible_diff,
)
from .psd_lite import PsdError, open_psd


class WorkerScanError(RuntimeError):
    pass


_CANONICAL_VERIFIED: set[tuple[str, int, int, str]] = set()
_MAX_DECODE_WORKERS = 1
_DEFAULT_SCAN_TIME_BUDGET_SECONDS = 30.0


def _copy_raw_signature(value) -> list[list[Any]]:
    return [list(part) for part in list(value or ())]


class IncrementalBaselineStore:
    """Keep only Blender-accepted exchange generations as pixel baselines.

    The worker stages decoded record snapshots under the import token that was
    emitted to Blender. A snapshot becomes an accepted baseline only after the
    main process acknowledges that exact token. This keeps failed or partial
    core imports from advancing the external diff baseline.
    """

    def __init__(self, *, max_pending: int = 4):
        self._accepted: dict[int, dict[str, Any]] = {}
        self._pending: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._max_pending = max(1, int(max_pending))
        self.accepted_token = ""
        self.accepted_generation = ""
        self.last_ack: dict[str, Any] = {}
        self.evicted_pending = 0

    @staticmethod
    def snapshot(
        image,
        bbox,
        raw_payload_signature,
    ) -> dict[str, Any]:
        return {
            "image": image,
            "bbox": [int(value) for value in bbox],
            "raw_payload_signature": _copy_raw_signature(raw_payload_signature),
        }

    def baseline_item(
        self,
        record_index: int,
        canonical_item: dict[str, Any],
    ) -> dict[str, Any]:
        snapshot = self._accepted.get(int(record_index))
        if snapshot is None:
            return canonical_item
        item = dict(canonical_item)
        item["bbox"] = list(snapshot["bbox"])
        item["raw_payload_signature"] = _copy_raw_signature(
            snapshot["raw_payload_signature"]
        )
        item.pop("visible_pixel_hash", None)
        return item

    def baseline_image(self, record_index: int):
        snapshot = self._accepted.get(int(record_index))
        if snapshot is None:
            return None
        return snapshot["image"], list(snapshot["bbox"])

    def accept_invisible(self, record_index: int, snapshot: dict[str, Any]) -> None:
        # Hidden-RGB/compression-only changes have no Blender-visible payload.
        # Advancing them immediately avoids re-decoding the same harmless bytes.
        self._accepted[int(record_index)] = snapshot

    def stage(
        self,
        token: str,
        exchange_generation: str,
        snapshots: dict[int, dict[str, Any]],
    ) -> None:
        token = str(token or "")
        if not token or not snapshots:
            return
        self._pending[token] = {
            "exchange_generation": str(exchange_generation or ""),
            "records": {int(key): value for key, value in snapshots.items()},
        }
        self._pending.move_to_end(token)
        while len(self._pending) > self._max_pending:
            self._pending.popitem(last=False)
            self.evicted_pending += 1

    def acknowledge(self, token: str, exchange_generation: str = "") -> dict[str, Any]:
        token = str(token or "")
        pending = self._pending.get(token)
        if pending is None:
            outcome = {
                "ok": False,
                "reason": "ack_token_not_pending",
                "token": token,
            }
            self.last_ack = outcome
            return outcome
        expected_generation = str(pending.get("exchange_generation", "") or "")
        supplied_generation = str(exchange_generation or "")
        if supplied_generation and expected_generation != supplied_generation:
            outcome = {
                "ok": False,
                "reason": "ack_generation_mismatch",
                "token": token,
                "expected_generation": expected_generation,
                "supplied_generation": supplied_generation,
            }
            self.last_ack = outcome
            return outcome

        for record_index, snapshot in pending["records"].items():
            self._accepted[int(record_index)] = snapshot
        keys = list(self._pending)
        for pending_token in keys[: keys.index(token) + 1]:
            self._pending.pop(pending_token, None)
        self.accepted_token = token
        self.accepted_generation = expected_generation
        outcome = {
            "ok": True,
            "reason": "accepted",
            "token": token,
            "exchange_generation": expected_generation,
            "record_indices": sorted(int(value) for value in pending["records"]),
        }
        self.last_ack = outcome
        return outcome

    def status(self) -> dict[str, Any]:
        accepted_bytes = sum(
            int(snapshot["image"].size[0]) * int(snapshot["image"].size[1]) * 4
            for snapshot in self._accepted.values()
        )
        pending_bytes = sum(
            int(snapshot["image"].size[0]) * int(snapshot["image"].size[1]) * 4
            for item in self._pending.values()
            for snapshot in item["records"].values()
        )
        return {
            "accepted_token": self.accepted_token,
            "accepted_exchange_generation": self.accepted_generation,
            "accepted_record_indices": sorted(self._accepted),
            "accepted_bytes": accepted_bytes,
            "pending_baseline_tokens": list(self._pending),
            "pending_bytes": pending_bytes,
            "evicted_pending": int(self.evicted_pending),
            "last_ack": dict(self.last_ack),
        }


class _DecodeDocuments:
    """Read-only PSD documents shared by bounded candidate decoder threads."""

    def __init__(
        self,
        canonical_path: Path,
        exchange_path: Path,
        baseline_images: dict[int, tuple[Any, list[int]]] | None = None,
    ):
        self.exchange = open_psd(exchange_path)
        self._canonical_path = canonical_path
        self._canonical = None
        self._canonical_lock = threading.Lock()
        self._baseline_images = dict(baseline_images or {})

    def canonical(self):
        with self._canonical_lock:
            if self._canonical is None:
                self._canonical = open_psd(self._canonical_path)
            return self._canonical

    def baseline(self, record_index: int):
        snapshot = self._baseline_images.get(int(record_index))
        if snapshot is not None:
            return snapshot[0], list(snapshot[1])
        return record_image_fast_from_document(self.canonical(), record_index)


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        Path(temp_name).unlink(missing_ok=True)
        raise


def _atomic_npy(path: Path, value: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(handle, "wb") as stream:
            np.save(stream, value, allow_pickle=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        Path(temp_name).unlink(missing_ok=True)
        raise


def _canonical_is_current(manifest: dict[str, Any]) -> bool:
    expected = manifest["canonical"]
    source = Path(expected["path"]).resolve()
    stat = source.stat()
    key = (
        str(source),
        int(stat.st_size),
        int(stat.st_mtime_ns),
        str(expected.get("sha256", "")),
    )
    if key in _CANONICAL_VERIFIED:
        return True
    actual = file_fingerprint(expected["path"])
    ok = (
        str(actual.get("sha256", "")) == str(expected.get("sha256", ""))
        and int(actual.get("size", -1)) == int(expected.get("size", -2))
    )
    if ok:
        _CANONICAL_VERIFIED.clear()
        _CANONICAL_VERIFIED.add(key)
    return ok


def _normalized_channel_ids(value) -> tuple[int, ...] | None:
    try:
        return tuple(sorted(int(channel_id) for channel_id in value))
    except (TypeError, ValueError):
        return None


def _resolve_exchange_records(
    baseline: dict[str, Any],
    current: dict[str, Any],
) -> tuple[dict[int, int], list[dict[str, Any]]]:
    """Resolve canonical editable rows through exact CSP-visible markers.

    CSP is allowed to rasterize or reorder non-editable exchange rows. Every
    canonical editable row must still have exactly one visible marker, remain a
    compatible pixel row, and retain its channels and mask state. Pixel paint may
    legitimately expand, shrink, or translate the row bounds.
    """
    current_by_record = {
        int(item["record_index"]): item for item in current["records"]
    }
    expected_markers = {
        marker_for_record(int(item["record_index"]))
        for item in baseline["records"]
        if bool(item.get("editable", False))
    }
    marker_locations: dict[str, list[int]] = {
        marker: [] for marker in expected_markers
    }
    unexpected_sps_markers = []
    for item in current["records"]:
        display_name = str(item.get("display_name", "") or "")
        legacy_name = str(item.get("legacy_name", "") or "")
        actual = marker_from_display_name(display_name)
        record_index = int(item["record_index"])
        if actual in marker_locations:
            marker_locations[actual].append(record_index)
        elif display_name.startswith(MARKER_PREFIX) or legacy_name.startswith(MARKER_PREFIX):
            unexpected_sps_markers.append({
                "record_index": record_index,
                "display_name": display_name,
                "legacy_name": legacy_name,
            })

    failures = list(unexpected_sps_markers)
    resolved: dict[int, int] = {}
    for item in baseline["records"]:
        if not bool(item.get("editable", False)):
            continue
        record_index = int(item["record_index"])
        expected = marker_for_record(record_index)
        locations = marker_locations.get(expected, [])
        if len(locations) != 1:
            failures.append({
                "record_index": record_index,
                "expected": expected,
                "locations": locations,
            })
            continue
        exchange_record_index = int(locations[0])
        current_item = current_by_record.get(exchange_record_index)
        if current_item is None:
            failures.append({
                "record_index": record_index,
                "expected": expected,
                "locations": locations,
                "reason": "marked_record_missing",
            })
            continue
        incompatible = []
        if not bool(current_item.get("editable", False)):
            incompatible.append("not_pixel_editable")
        if str(current_item.get("kind", "")) != "PIXEL":
            incompatible.append("kind_changed")
        if int(current_item.get("section_type", 0)) != 0:
            incompatible.append("section_type_changed")
        expected_channels = _normalized_channel_ids(item.get("channel_ids", ()))
        current_channels = _normalized_channel_ids(
            current_item.get("channel_ids", ())
        )
        # Photoshop serializes alpha before RGB on save, while SPS-created
        # records may store the same unique channel IDs in RGB/alpha order.
        # Channel order is not layer structure; membership and multiplicity are.
        if (
            expected_channels is None
            or current_channels is None
            or current_channels != expected_channels
        ):
            incompatible.append("channels_changed")
        if bool(current_item.get("has_mask", False)) != bool(item.get("has_mask", False)):
            incompatible.append("mask_changed")

        if incompatible:
            failures.append({
                "record_index": record_index,
                "exchange_record_index": exchange_record_index,
                "expected": expected,
                "reason": "editable_record_structure_changed",
                "details": incompatible,
            })
            continue
        resolved[record_index] = exchange_record_index
    return resolved, failures


def _decode_candidate(
    *,
    documents: _DecodeDocuments,
    record_index: int,
    exchange_record_index: int,
    baseline_item: dict[str, Any],
) -> dict[str, Any]:
    """Decode and compare one candidate without writing persistent payloads."""
    row_started = time.perf_counter()
    stage_started = time.perf_counter()
    after, after_bbox = record_image_fast_from_document(
        documents.exchange,
        exchange_record_index,
    )
    after_ms = (time.perf_counter() - stage_started) * 1000.0
    # The sparse premultiplied-RGBA comparator below is both exact and faster
    # than hashing the entire visible record before comparing it. Raw channel
    # signatures already keep unchanged records out of this decode path.
    visible_hash_ms = 0.0

    stage_started = time.perf_counter()
    baseline_reader = getattr(documents, "baseline", None)
    if callable(baseline_reader):
        before, before_bbox = baseline_reader(record_index)
    else:
        before, before_bbox = record_image_fast_from_document(
            documents.canonical(),
            record_index,
        )
    before_ms = (time.perf_counter() - stage_started) * 1000.0
    stage_started = time.perf_counter()
    before_compare, after_compare, compare_bbox = align_record_images(
        before,
        before_bbox,
        after,
        after_bbox,
    )
    stats = visible_diff(before_compare, after_compare)
    diff_ms = (time.perf_counter() - stage_started) * 1000.0
    timing = {
        "record_index": int(record_index),
        "exchange_record_index": int(exchange_record_index),
        "baseline_decode_ms": round(before_ms, 3),
        "exchange_decode_ms": round(after_ms, 3),
        "visible_hash_ms": round(visible_hash_ms, 3),
        "visible_diff_ms": round(diff_ms, 3),
        "payload_write_ms": 0.0,
        "total_ms": round((time.perf_counter() - row_started) * 1000.0, 3),
    }
    if not bool(stats.get("meaningful", False)):
        return {
            "status": "skipped",
            "snapshot_image": after,
            "snapshot_bbox": after_bbox,
            "skipped": {
                "record_index": int(record_index),
                "reason": str(stats.get("reason", "visible_hash_unchanged")),
            },
            "timing": timing,
        }

    local = [int(value) for value in stats["bbox"]]
    after_u8 = np.asarray(after_compare, dtype=np.uint8)
    crop = np.array(
        after_u8[local[1]:local[3], local[0]:local[2], :],
        dtype=np.float32,
        order="C",
        copy=True,
    )
    crop /= np.float32(255.0)
    crop = np.ascontiguousarray(crop, dtype="<f4")
    payload_hash = hashlib.sha256(crop.tobytes(order="C")).hexdigest()
    rect_psd = [
        int(compare_bbox[0] + local[0]),
        int(compare_bbox[1] + local[1]),
        int(compare_bbox[0] + local[2]),
        int(compare_bbox[1] + local[3]),
    ]
    return {
        "status": "payload",
        "snapshot_image": after,
        "snapshot_bbox": after_bbox,
        "record_index": int(record_index),
        "exchange_record_index": int(exchange_record_index),
        "rect_psd": rect_psd,
        "crop": crop,
        "payload_hash": payload_hash,
        "visible_diff": stats,
        "before_bbox": before_bbox,
        "after_bbox": after_bbox,
        "bounds_changed": bool(before_bbox != after_bbox),
        "timing": timing,
    }


def _decode_candidates(
    *,
    canonical_path: Path,
    exchange_path: Path,
    candidate_record_indices: list[int],
    record_map: dict[int, int],
    baseline_by_record: dict[int, dict[str, Any]],
    baseline_images: dict[int, tuple[Any, list[int]]] | None = None,
    cancel_event: threading.Event | None = None,
    deadline: float | None = None,
) -> tuple[dict[int, dict[str, Any]], dict[str, Any] | None, int]:
    """Decode candidates sequentially under the Connect lease cancellation.

    Earlier builds created a private ``ThreadPoolExecutor`` for every external
    change.  Those child threads were not owned by the Suite generation and
    could outlive Disconnect/load_pre.  The event wait thread now performs the
    finite decode itself, checking the shared cancellation event and one fixed
    operation deadline between records.  No resident or untracked worker is
    created.
    """
    if not candidate_record_indices:
        return {}, None, 0
    decoded: dict[int, dict[str, Any]] = {}
    documents = _DecodeDocuments(
        canonical_path,
        exchange_path,
        baseline_images=baseline_images,
    )
    for record_index in candidate_record_indices:
        if cancel_event is not None and cancel_event.is_set():
            return decoded, {
                "ok": False,
                "blocked": True,
                "reason": "scan_cancelled",
                "record_index": int(record_index),
                "changed_records": [],
            }, 0
        if deadline is not None and time.monotonic() >= float(deadline):
            return decoded, {
                "ok": False,
                "blocked": True,
                "reason": "scan_time_budget_exceeded",
                "record_index": int(record_index),
                "changed_records": [],
            }, 0
        try:
            item = _decode_candidate(
                documents=documents,
                record_index=int(record_index),
                exchange_record_index=int(record_map[record_index]),
                baseline_item=baseline_by_record[record_index],
            )
        except (OSError, RuntimeError, TypeError, ValueError, KeyError, IndexError) as exc:
            return decoded, {
                "ok": False,
                "blocked": True,
                "reason": "candidate_decode_failed",
                "record_index": int(record_index),
                "error": repr(exc)[:512],
                "changed_records": [],
            }, 0
        if str(item.get("status", "")) == "blocked":
            return decoded, dict(item["result"]), 0
        decoded[int(record_index)] = item
    return decoded, None, 0

def scan_once(
    manifest_path: str | Path,
    exchange_path: str | Path,
    result_dir: str | Path,
    *,
    baseline_store: IncrementalBaselineStore | None = None,
    cancel_event: threading.Event | None = None,
    time_budget_seconds: float = _DEFAULT_SCAN_TIME_BUDGET_SECONDS,
) -> dict[str, Any]:
    overall_started = time.perf_counter()
    deadline = time.monotonic() + max(0.1, float(time_budget_seconds))
    if cancel_event is not None and cancel_event.is_set():
        return {"ok": False, "blocked": True, "reason": "scan_cancelled", "changed_records": []}
    timing: dict[str, float] = {}
    manifest = read_manifest(manifest_path)
    exchange = Path(exchange_path).resolve()
    destination = Path(result_dir).resolve()
    result_path = destination / "scan_result.json"

    stage_started = time.perf_counter()
    canonical_current = _canonical_is_current(manifest)
    timing["canonical_fingerprint_ms"] = (time.perf_counter() - stage_started) * 1000.0
    if not canonical_current:
        result = {
            "ok": False,
            "blocked": True,
            "reason": "stale_canonical_generation",
            "changed_records": [],
        }
        _atomic_json(result_path, result)
        return result

    stage_started = time.perf_counter()
    try:
        current = scan_document(exchange, include_pixels=False)
    except PsdError as exc:
        # 外部アプリが保存した PSD を読めない・扱えない時は、例外で落とさず理由付きで止める。
        result = {
            "ok": False,
            "blocked": True,
            "reason": str(exc.reason),
            "error": str(exc)[:512],
            "changed_records": [],
        }
        _atomic_json(result_path, result)
        return result
    timing["raw_scan_ms"] = (time.perf_counter() - stage_started) * 1000.0
    document = current.get("document", {})
    expected_document = manifest.get("document", {})
    if (
        int(document.get("width", -1)) != int(expected_document.get("width", -2))
        or int(document.get("height", -1)) != int(expected_document.get("height", -2))
    ):
        result = {
            "ok": False,
            "blocked": True,
            "reason": "document_dimensions_changed",
            "changed_records": [],
        }
        _atomic_json(result_path, result)
        return result

    record_map, marker_failures = _resolve_exchange_records(manifest, current)
    if marker_failures:
        result = {
            "ok": False,
            "blocked": True,
            "reason": "exchange_identity_mismatch",
            "identity_failures": marker_failures,
            "changed_records": [],
        }
        _atomic_json(result_path, result)
        return result

    canonical_by_record = {
        int(item["record_index"]): item for item in manifest["records"]
    }
    baseline_by_record = {
        record_index: (
            baseline_store.baseline_item(record_index, item)
            if baseline_store is not None
            else item
        )
        for record_index, item in canonical_by_record.items()
    }
    current_by_record = {
        int(item["record_index"]): item for item in current["records"]
    }
    candidate_record_indices = []
    for record_index, exchange_record_index in sorted(record_map.items()):
        baseline_item = baseline_by_record[record_index]
        current_item = current_by_record[exchange_record_index]
        if baseline_item.get("raw_payload_signature") != current_item.get("raw_payload_signature"):
            candidate_record_indices.append(int(record_index))

    canonical_path = Path(manifest["canonical"]["path"])
    stage_started = time.perf_counter()
    decoded, decode_failure, decode_workers = _decode_candidates(
        canonical_path=canonical_path,
        exchange_path=exchange,
        candidate_record_indices=candidate_record_indices,
        record_map=record_map,
        baseline_by_record=baseline_by_record,
        baseline_images=(
            {
                record_index: snapshot
                for record_index in candidate_record_indices
                if (snapshot := baseline_store.baseline_image(record_index)) is not None
            }
            if baseline_store is not None
            else None
        ),
        cancel_event=cancel_event,
        deadline=deadline,
    )
    timing["candidate_decode_ms"] = (time.perf_counter() - stage_started) * 1000.0
    timing["decode_workers"] = int(decode_workers)
    if decode_failure is not None:
        _atomic_json(result_path, decode_failure)
        return decode_failure

    payloads = []
    skipped = []
    record_timing = []
    pending_snapshots: dict[int, dict[str, Any]] = {}
    for record_index in candidate_record_indices:
        if cancel_event is not None and cancel_event.is_set():
            result = {"ok": False, "blocked": True, "reason": "scan_cancelled", "changed_records": []}
            _atomic_json(result_path, result)
            return result
        if time.monotonic() >= deadline:
            result = {"ok": False, "blocked": True, "reason": "scan_time_budget_exceeded", "changed_records": []}
            _atomic_json(result_path, result)
            return result
        item = decoded[record_index]
        snapshot_image = item.pop("snapshot_image")
        snapshot_bbox = item.pop("snapshot_bbox")
        current_item = current_by_record[int(record_map[record_index])]
        snapshot = (
            baseline_store.snapshot(
                snapshot_image,
                snapshot_bbox,
                current_item.get("raw_payload_signature"),
            )
            if baseline_store is not None
            else None
        )
        if str(item["status"]) == "skipped":
            skipped.append(dict(item["skipped"]))
            record_timing.append(dict(item["timing"]))
            if baseline_store is not None and snapshot is not None:
                baseline_store.accept_invisible(record_index, snapshot)
            continue
        if snapshot is not None:
            pending_snapshots[int(record_index)] = snapshot
        crop = item.pop("crop")
        payload_hash = str(item["payload_hash"])
        payload_path = destination / f"record_{int(record_index):05d}_{payload_hash[:16]}.npy"
        stage_started = time.perf_counter()
        _atomic_npy(payload_path, crop)
        write_ms = (time.perf_counter() - stage_started) * 1000.0
        timing_item = dict(item["timing"])
        timing_item["payload_write_ms"] = round(write_ms, 3)
        timing_item["total_ms"] = round(float(timing_item["total_ms"]) + write_ms, 3)
        record_timing.append(timing_item)
        payloads.append({
            "record_index": int(record_index),
            "exchange_record_index": int(item["exchange_record_index"]),
            "rect_psd": list(item["rect_psd"]),
            "payload_path": str(payload_path),
            "dtype": "<f4",
            "shape": [int(value) for value in crop.shape],
            "sha256": payload_hash,
            "visible_diff": dict(item["visible_diff"]),
        })

    exchange_fingerprint = dict(current["canonical"])
    timing["exchange_fingerprint_ms"] = 0.0
    token_source = {
        "canonical_generation": manifest["canonical"]["generation"],
        "exchange_generation": exchange_fingerprint["generation"],
        "payloads": [
            {
                "record_index": item["record_index"],
                "rect_psd": item["rect_psd"],
                "sha256": item["sha256"],
            }
            for item in payloads
        ],
    }
    import_token = hashlib.sha256(
        json.dumps(token_source, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if baseline_store is not None and pending_snapshots:
        baseline_store.stage(
            import_token,
            exchange_fingerprint["generation"],
            pending_snapshots,
        )
    result = {
        "ok": True,
        "blocked": False,
        "reason": "ok",
        "import_token": import_token,
        "canonical_generation": manifest["canonical"]["generation"],
        "exchange_generation": exchange_fingerprint["generation"],
        "candidate_records": candidate_record_indices,
        "changed_records": [int(item["record_index"]) for item in payloads],
        "exchange_record_map": [
            {
                "record_index": int(record_index),
                "exchange_record_index": int(exchange_record_index),
            }
            for record_index, exchange_record_index in sorted(record_map.items())
        ],
        "isolated_structure_changed": (
            str(current["structural_signature"]) != str(manifest["structural_signature"])
        ),
        "payloads": payloads,
        "skipped": skipped,
        "incremental_baseline": (
            baseline_store.status()
            if baseline_store is not None
            else {"mode": "canonical"}
        ),
        "timing_ms": {
            **{key: round(value, 3) for key, value in timing.items()},
            "records": record_timing,
            "overall": round((time.perf_counter() - overall_started) * 1000.0, 3),
        },
    }
    _atomic_json(result_path, result)
    return result
