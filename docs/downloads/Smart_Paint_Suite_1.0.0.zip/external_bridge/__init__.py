# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Optional, explicit Photoshop and Clip Studio bridge for Smart Paint Suite."""

from __future__ import annotations
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg

from pathlib import Path
import sys
import time

import bpy

from . import session
from .. import resource_quota
from ..constants import report_text


bl_info = {
    "name": "Smart Paint External Bridge",
    "author": "JELararagi",
    "version": (0, 3, 15),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Paint > External Bridge",
    "description": (
        "Optional explicit bridge between Smart Paint Suite, Adobe Photoshop, "
        "and Clip Studio Paint"
    ),
    "category": "Smart Paint",
}

_BACKEND_PROPERTY = "sps_external_bridge_backend"
_BACKEND_ITEMS = (
    (
        "PHOTOSHOP",
        "Photoshop",
        "Open and reload the isolated exchange in Adobe Photoshop",
    ),
    (
        "CLIP_STUDIO",
        "Clip Studio",
        "Open the isolated exchange in Clip Studio Paint",
    ),
)
_BACKEND_PREFERENCE_LOADING = False


def _backend_preference_path(*, create: bool = False) -> Path | None:
    try:
        root_value = str(
            bpy.utils.user_resource(
                "CONFIG",
                path="smart_paint_suite",
                create=bool(create),
            )
            or ""
        )
    except (OSError, RuntimeError, TypeError, ValueError):
        root_value = ""
    return Path(root_value) / "external_bridge_backend.json" if root_value else None


def _load_backend_preference() -> str:
    path = _backend_preference_path()
    try:
        value = session._read_json(path) if path is not None and path.is_file() else {}
        valid = bool(
            isinstance(value, dict)
            and int(value.get("schema", -1)) == 1
            and str(value.get("owner", "")) == "JELararagi:smart_paint_suite"
        )
        backend = str(value.get("backend", "") or "").upper() if valid else ""
    except (OSError, UnicodeError, ValueError, TypeError):
        backend = ""
    return backend if backend in session.SUPPORTED_BACKENDS else "PHOTOSHOP"


def _save_backend_preference(backend: str) -> None:
    value = str(backend or "").upper()
    if value not in session.SUPPORTED_BACKENDS:
        return
    path = _backend_preference_path(create=True)
    if path is None:
        return
    try:
        session._atomic_json(path, {"schema": 1, "owner": "JELararagi:smart_paint_suite", "backend": value})
    except (OSError, TypeError, ValueError) as exc:
        from .. import runtime_registry
        runtime_registry.component_state("external_bridge_preferences", "FAILED", str(exc))


def _backend_preference_updated(window_manager, _context) -> None:
    if _BACKEND_PREFERENCE_LOADING:
        return
    _save_backend_preference(
        str(getattr(window_manager, _BACKEND_PROPERTY, "PHOTOSHOP") or "PHOTOSHOP")
    )


def _restore_backend_preference() -> None:
    global _BACKEND_PREFERENCE_LOADING
    backend = _load_backend_preference()
    _BACKEND_PREFERENCE_LOADING = True
    try:
        managers = list(getattr(bpy.data, "window_managers", ()) or ())
        current = getattr(getattr(bpy, "context", None), "window_manager", None)
        if current is not None and current not in managers:
            managers.append(current)
        for window_manager in managers:
            try:
                setattr(window_manager, _BACKEND_PROPERTY, backend)
            except (AttributeError, RuntimeError, ReferenceError, TypeError):
                continue
    finally:
        _BACKEND_PREFERENCE_LOADING = False



def _selected_backend(context) -> str:
    window_manager = getattr(context, "window_manager", None)
    backend = str(
        getattr(window_manager, _BACKEND_PROPERTY, "PHOTOSHOP") or "PHOTOSHOP"
    ).upper()
    return backend if backend in session.SUPPORTED_BACKENDS else _load_backend_preference()


class SPS_BRIDGE_OT_paint_observer(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.paint_observer"
    bl_label = "External Paint Stroke Observer"
    bl_description = (
        "Observe completed native paint strokes while connected. The observer "
        "uses only actual mouse/pen events and creates no timer or idle wakeup"
    )
    bl_options = {"INTERNAL"}

    _window_pointer = 0
    _stroke_active = False
    _runtime_generation = ""

    @staticmethod
    def _is_paint_surface(context, event) -> bool:
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None)
        if screen is None:
            return False
        try:
            mouse_x, mouse_y = int(event.mouse_x), int(event.mouse_y)
        except (AttributeError, TypeError, ValueError):
            return False
        for area in screen.areas:
            if not (int(area.x) <= mouse_x < int(area.x + area.width) and int(area.y) <= mouse_y < int(area.y + area.height)):
                continue
            region = next((item for item in area.regions if item.type == "WINDOW" and int(item.x) <= mouse_x < int(item.x + item.width) and int(item.y) <= mouse_y < int(item.y + item.height)), None)
            if region is None:
                return False
            if area.type == "VIEW_3D":
                return str(getattr(context, "mode", "") or "") == "PAINT_TEXTURE"
            if area.type == "IMAGE_EDITOR":
                space = area.spaces.active
                return str(getattr(space, "mode", "") or "") == "PAINT"
            return False
        return False

    def invoke(self, context, event):
        del event
        from .. import runtime_registry

        state = session.snapshot()
        runtime_state = runtime_registry.snapshot()
        window = getattr(context, "window", None)
        if not state.get("connected") or window is None or not session.claim_paint_observer(window):
            return {"CANCELLED"}
        self._window_pointer = int(window.as_pointer())
        self._stroke_active = False
        self._runtime_generation = str(runtime_state.get("generation", "") or "")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        from .. import runtime_registry

        runtime_state = runtime_registry.snapshot()
        state = session.snapshot()
        window = getattr(context, "window", None)
        current_pointer = int(window.as_pointer()) if window is not None else 0
        if (
            not state.get("connected")
            or current_pointer != self._window_pointer
            or str(runtime_state.get("generation", "") or "") != self._runtime_generation
        ):
            session.release_paint_observer(self._window_pointer)
            return {"FINISHED"}

        # File-drop/native platform events can carry a C event code that is not
        # present in Python's Event.type enum.  Their value is not PRESS or
        # RELEASE, so reject them before reading Event.type and avoid the RNA
        # enum warning entirely.
        event_value = str(getattr(event, "value", "") or "")
        if event_value not in {"PRESS", "RELEASE"}:
            return {"PASS_THROUGH"}
        event_type = str(getattr(event, "type", "") or "")
        if event_type in {"LEFTMOUSE", "PEN"}:
            paint_surface = bool(event_value == "PRESS" and self._is_paint_surface(context, event))
            prepared = session.prepare_local_stroke(context) if paint_surface else None
            session.note_paint_observer_event(
                event_type,
                event_value,
                paint_surface=paint_surface,
                result=prepared,
            )
            if paint_surface and bool(prepared and prepared.get("ok")):
                self._stroke_active = True
            elif event_value == "RELEASE" and self._stroke_active:
                self._stroke_active = False
                result = session.notify_local_stroke(context)
                session.note_paint_observer_event(
                    event_type,
                    event_value,
                    stroke_complete=True,
                    result=result,
                )
        elif event_type == "ESC" and self._stroke_active:
            # No external transaction has begun before stroke release; Esc only
            # drops the pending observation and leaves Blender's native stroke
            # cancellation semantics untouched.
            self._stroke_active = False
        return {"PASS_THROUGH"}

    def cancel(self, context):
        del context
        self._stroke_active = False
        session.release_paint_observer(self._window_pointer)


# Automatic Blender->external push.  A keymap item on the paint click passes the
# event through to the native stroke and starts a timer that lives only until
# that stroke ends; nothing runs while the user is idle.
_STROKE_PUSH_KEYMAP_ITEMS: list = []
_STROKE_PUSH_STATE = {"pending": False}
_NATIVE_STROKE_IDNAMES = frozenset({"PAINT_OT_image_paint"})
_STROKE_START_GRACE_S = 0.5
_STROKE_SETTLE_S = 0.05


def _native_stroke_running() -> bool:
    try:
        for window in bpy.context.window_manager.windows:
            for operator in window.modal_operators:
                if str(getattr(operator, "bl_idname", "") or "") in _NATIVE_STROKE_IDNAMES:
                    return True
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    return False


def _selection_clip_pending() -> bool:
    module = sys.modules.get(__name__.rsplit(".", 1)[0] + ".mvp.selection_tools")
    return bool(getattr(module, "_CLIP_PENDING", False)) if module is not None else False


def _window_by_pointer(pointer: int):
    try:
        for window in bpy.context.window_manager.windows:
            if int(window.as_pointer()) == int(pointer):
                return window
    except (AttributeError, ReferenceError, RuntimeError):
        return None
    return None


def _push_finished_stroke(window_pointer: int, record_index: int) -> None:
    window = _window_by_pointer(window_pointer)
    if window is None or not session.is_connected():
        return
    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            result = session.notify_local_stroke(bpy.context, record_index=record_index)
    except (RuntimeError, ReferenceError, TypeError, ValueError) as exc:
        result = {"ok": False, "reason": "stroke_push_failed", "error": str(exc)[:384]}
    session.note_paint_observer_event("LEFTMOUSE", "RELEASE", stroke_complete=True, result=result)


def _schedule_stroke_push(window_pointer: int, record_index: int) -> bool:
    from .. import runtime_registry

    started = time.perf_counter()
    progress = {"seen": False, "idle_since": None}

    def wait_for_stroke_end():
        now = time.perf_counter()
        if _native_stroke_running() or _selection_clip_pending():
            progress["seen"] = True
            progress["idle_since"] = None
            return 0.05
        if not progress["seen"] and now - started < _STROKE_START_GRACE_S:
            return 0.05
        if progress["idle_since"] is None:
            progress["idle_since"] = now
            return _STROKE_SETTLE_S
        _STROKE_PUSH_STATE["pending"] = False
        _push_finished_stroke(window_pointer, record_index)
        return None

    _STROKE_PUSH_STATE["pending"] = True
    try:
        runtime_registry.register_timer(
            wait_for_stroke_end, first_interval=0.05, persistent=False, label="bridge_stroke_push"
        )
        return True
    except Exception:
        _STROKE_PUSH_STATE["pending"] = False
        return False


def _install_stroke_push_keymap() -> bool:
    if _STROKE_PUSH_KEYMAP_ITEMS:
        return True
    config = getattr(getattr(bpy.context.window_manager, "keyconfigs", None), "addon", None)
    if config is None:
        return False
    keymap = config.keymaps.get("Image Paint")
    if keymap is None:
        keymap = config.keymaps.new(name="Image Paint", space_type="EMPTY", region_type="WINDOW")
    item = keymap.keymap_items.new(
        SPS_BRIDGE_OT_stroke_push.bl_idname, type="LEFTMOUSE", value="PRESS", any=True
    )
    _STROKE_PUSH_KEYMAP_ITEMS.append((keymap, item))
    return True


def _remove_stroke_push_keymap() -> None:
    for keymap, item in reversed(list(_STROKE_PUSH_KEYMAP_ITEMS)):
        try:
            keymap.keymap_items.remove(item)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    _STROKE_PUSH_KEYMAP_ITEMS.clear()
    _STROKE_PUSH_STATE["pending"] = False


class SPS_BRIDGE_OT_stroke_push(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.stroke_push"
    bl_label = "Send Strokes to External App"
    bl_description = (
        "While connected, send each finished paint stroke to the external app. "
        "It runs only on a paint click and leaves no timer while idle"
    )
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        del event
        if _STROKE_PUSH_STATE["pending"] or not session.is_connected():
            return {"PASS_THROUGH"}
        window = getattr(context, "window", None)
        if window is None:
            return {"PASS_THROUGH"}
        prepared = session.prepare_local_stroke(context)
        session.note_paint_observer_event("LEFTMOUSE", "PRESS", paint_surface=True, result=prepared)
        if not bool(prepared.get("ok")):
            return {"PASS_THROUGH"}
        _schedule_stroke_push(int(window.as_pointer()), int(prepared.get("record_index", -1)))
        return {"PASS_THROUGH"}


class SPS_BRIDGE_OT_connect(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.connect"
    bl_label = "Connect"
    bl_description = "Start the selected external app bridge for the active Smart Paint PSD"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        result = session.connect(context, _selected_backend(context))
        if not result.get("ok"):
            self.report({"ERROR"}, _rpt_msg(result.get("reason") or "Bridge connect failed"))
            return {"CANCELLED"}
        # Finished strokes are sent by the paint-click keymap item; the legacy
        # observer is never started.  A connected idle session therefore has no
        # resident modal operator or repeating timer.
        _install_stroke_push_keymap()
        action = "rebuilt" if result.get("exchange_rebuilt") else "reused"
        label = str(result.get("backend_label", "External app"))
        self.report(
            {"INFO"},
            _rpt("{} exchange {}: {} records", label, _rpt(action), result.get('record_count', 0)),
        )
        return {"FINISHED"}


class SPS_BRIDGE_OT_disconnect(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.disconnect"
    bl_label = "Disconnect"
    bl_description = "Stop the isolated exchange worker and disconnect the external app bridge"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        del context
        _remove_stroke_push_keymap()
        result = session.disconnect("operator")
        if not result.get("ok"):
            reason = _rpt_msg(result.get("reason") or "Bridge stop failed")
            self.report({"WARNING"}, reason)
            return {"CANCELLED"}
        self.report({"INFO"}, report_text("External bridge disconnected"))
        return {"FINISHED"}


class SPS_BRIDGE_OT_open_exchange(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.open_exchange"
    bl_label = "Open Exchange"
    bl_description = "Open or focus the isolated exchange in the connected external app"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        del context
        return bool(session.snapshot().get("connected"))

    def execute(self, context):
        del context
        result = session.open_exchange()
        if not result.get("ok"):
            self.report({"ERROR"}, _rpt_msg(result.get("reason") or "External app launch failed"))
            return {"CANCELLED"}
        self.report({"INFO"}, report_text("Opening exchange"))
        return {"FINISHED"}


class SPS_BRIDGE_OT_apply_pending(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.apply_pending"
    bl_label = "Apply External Changes"
    bl_description = "Apply the latest verified external pixel changes as one baseline transition"
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def poll(cls, context):
        del context
        state = session.snapshot()
        return bool(state.get("connected")) and int(
            state.get("pending_count", 0) or 0
        ) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def cancel(self, context):
        del context
        return None

    @resource_quota.operation_boundary("external_bridge.apply_pending")
    def execute(self, context):
        result = session.apply_pending(context)
        if not result.get("ok"):
            self.report({"ERROR"}, _rpt_msg(result.get("reason") or "External import failed"))
            return {"CANCELLED"}
        if result.get("duplicate") or result.get("reason") == "no_pending_import":
            self.report({"INFO"}, report_text("No new external changes"))
        elif result.get("ack_pending"):
            self.report(
                {"WARNING"},
                _rpt("Applied {} patch(es); external ACK will be retried", int(result.get('patch_count', 0) or 0)),
            )
        else:
            self.report(
                {"INFO"},
                _rpt("Applied {} patch(es)", int(result.get('patch_count', 0) or 0)),
            )
        return {"FINISHED"}


class SPS_BRIDGE_OT_sync_open(bpy.types.Operator):
    bl_idname = "smart_paint_bridge.sync_open"
    bl_label = "Sync / Open"
    bl_description = "Retry pending verified changes, then open or focus the exchange"
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def poll(cls, context):
        del context
        return bool(session.snapshot().get("connected"))

    @resource_quota.operation_boundary("external_bridge.sync_open")
    def execute(self, context):
        result = session.sync_open(context)
        if not result.get("ok"):
            self.report({"ERROR"}, _rpt_msg(result.get("reason") or "External sync failed"))
            return {"CANCELLED"}
        if result.get("open_deferred"):
            self.report({"INFO"}, report_text("Sync queued"))
        elif int(result.get("patch_count", 0) or 0) > 0:
            self.report(
                {"INFO"},
                _rpt("Applied {} patch(es); opening exchange", int(result.get('patch_count', 0) or 0)),
            )
        else:
            self.report({"INFO"}, report_text("Opening exchange"))
        return {"FINISHED"}


def draw_panel(layout, context) -> None:
    """Draw the bridge inside the Suite's existing Smart Paint panel tree."""
    state = session.snapshot()
    if not state.get("connected"):
        selector = layout.row(align=True)
        selector.prop(
            context.window_manager,
            _BACKEND_PROPERTY,
            expand=True,
        )
        layout.operator(
            "smart_paint_bridge.connect",
            text="Connect",
            icon="LINKED",
        )
        return

    header = layout.row(align=True)
    worker_ok = bool(state.get("connected")) and not bool(state.get("resource_error"))
    header.label(
        text=str(state.get("backend_label", "External app")),
        icon="LINKED" if worker_ok else "ERROR",
    )
    header.operator(
        "smart_paint_bridge.sync_open",
        text="Sync / Open",
        icon="FILE_REFRESH",
    )
    header.operator(
        "smart_paint_bridge.disconnect",
        text="",
        icon="X",
    )

    exchange = str(state.get("exchange_path", "") or "")
    if exchange:
        layout.label(text=Path(exchange).name, icon="FILE_IMAGE", translate=False)
    phase = str(state.get("phase", "starting") or "starting")
    pending = int(state.get("pending_count", 0) or 0)
    status = _rpt(_PHASE_TEXT.get(phase, "接続中"))
    if pending:
        status += _rpt(" / 未反映 {}", pending)
    layout.label(text=status)

    error = str(state.get("last_error", "") or "")
    if error:
        notice = layout.row()
        notice.alert = True
        notice.label(text=_rpt_msg(error)[:180], icon="ERROR")

_PHASE_TEXT = {
    "disconnected": "未接続",
    "starting": "開始中",
    "preparing": "準備中",
    "launching": "外部アプリを起動中",
    "idle": "接続中",
    "pending_import": "外部の変更あり",
    "disconnecting": "切断中",
    "event_lease_ended": "待ち受けを終了",
    "resource_stop_failed": "切断に失敗",
}

_CLASSES = (
    SPS_BRIDGE_OT_paint_observer,
    SPS_BRIDGE_OT_stroke_push,
    SPS_BRIDGE_OT_connect,
    SPS_BRIDGE_OT_disconnect,
    SPS_BRIDGE_OT_open_exchange,
    SPS_BRIDGE_OT_apply_pending,
    SPS_BRIDGE_OT_sync_open,
)
CLASSES = _CLASSES


def before_load(_unused=None) -> None:
    """Stop every bridge lease before Blender replaces RNA/data."""
    _remove_stroke_push_keymap()
    try:
        session.disconnect("load_pre", blocking=True)
    finally:
        from .. import runtime_registry
        runtime_registry.run_load_pre_hooks(_unused)


def restore_after_load() -> None:
    """Restore only the persisted backend preference; no worker is resumed."""
    _restore_backend_preference()


def _cleanup_external_bridge() -> None:
    _remove_stroke_push_keymap()
    result = session.disconnect("unregister", blocking=True)
    if not bool(result.get("ok", False)):
        raise RuntimeError("; ".join(str(value) for value in result.get("resource_errors", ())))


def register(transaction) -> None:
    transaction.add_owned_rna_property(
        bpy.types.WindowManager,
        _BACKEND_PROPERTY,
        bpy.props.EnumProperty(
            name="Backend",
            description="External paint application",
            items=_BACKEND_ITEMS,
            default="PHOTOSHOP",
            update=_backend_preference_updated,
        ),
        kind="rna_property",
    )
    for cls in _CLASSES:
        transaction.register_class(cls)
    session.register_core_save_callback(transaction)
    transaction.add_handler(bpy.app.handlers.load_pre, before_load, label="external_bridge.load_pre")
    transaction.add_cleanup(_cleanup_external_bridge, label="external_bridge.cleanup")
    _restore_backend_preference()


def unregister() -> None:
    """Compatibility entry; the root generation journal owns teardown."""
    _remove_stroke_push_keymap()
    result = session.disconnect("unregister", blocking=True)
    if not bool(result.get("ok", False)):
        raise RuntimeError("; ".join(str(value) for value in result.get("resource_errors", ())))
