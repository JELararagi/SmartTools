# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Event-driven Photoshop / PSD bridge lifecycle for Smart Paint Suite.

The bridge has no heartbeat, polling timer, periodic worker process, or idle
JSON writer.  A Connect lease owns one Windows ``ReadDirectoryChangesW`` wait
thread blocked on native Events.  External changes enqueue one main-thread
internal UNDO operator through CPython's pending-call queue.  Disconnect/load
pre/unregister stop in the strict order timer removal (none), cancel, I/O close,
thread join, and finite process termination for Suite-owned one-shot workers.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import uuid
from typing import Any

import bpy

from .. import bridge_api as _bridge_api, resource_quota, runtime_registry

SUPPORTED_BACKENDS = frozenset({"PHOTOSHOP", "CLIP_STUDIO"})
CORE_SAVE_CALLBACK = "sps_external_bridge_on_core_save"
SESSION_SCHEMA = 4
RESULT_BYTE_BUDGET = resource_quota.GLOBAL_MEMORY_CACHE_BYTES
RESULT_COUNT_BUDGET = 32
COMMAND_COUNT_LIMIT = 64
COMMAND_FILE_BYTE_LIMIT = 64 * 1024
FILE_SETTLE_TIME_BUDGET_SECONDS = 0.75
FILE_SETTLE_INITIAL_SECONDS = 0.02
JOIN_TIMEOUT_SECONDS = 8.0

_LOCK = threading.RLock()
_LEASE = None
_OBSERVER_WINDOWS: set[int] = set()
_PENDING_RESULT: dict[str, Any] | None = None
_PENDING_CALL_QUEUED = False
_PENDING_CALL_CALLBACK = None
_DISCONNECT_CALL_QUEUED = False
_DISCONNECT_CALL_CALLBACK = None
_COMMITTED_TOKENS = resource_quota.cache("bridge.committed_tokens")
_APPLY_IN_PROGRESS = False

_DEFAULT_STATE: dict[str, Any] = {
    "connected": False,
    "backend": "",
    "document_key": "",
    "generation": "",
    "material_name": "",
    "path": "",
    "record_count": 0,
    "preferred_layer_name": "",
    "preferred_record_index": -1,
    "api_version": 0,
    "session_generation": "",
    "session_dir": "",
    "process_lease_uuid": "",
    "process_lease_pid": 0,
    "process_lease_creation_time": "",
    "process_lease_deadline": 0.0,
    "exchange_path": "",
    "manifest_path": "",
    "phase": "disconnected",
    "worker_pid": 0,
    "worker_running": False,
    "event_watcher_running": False,
    "periodic_timer_count": 0,
    "polling_worker_count": 0,
    "scan_count": 0,
    "pending_count": 0,
    "pending_token": "",
    "applied_token": "",
    "committed_token": "",
    "ack_pending": False,
    "local_push_phase": "",
    "local_push_count": 0,
    "local_push_retry_count": 0,
    "external_autosave_count": 0,
    "observer_event_count": 0,
    "observer_press_count": 0,
    "observer_stroke_count": 0,
    "observer_last_reason": "",
    "suppress_exchange_generation": "",
    "last_error": "",
    "resource_error": "",
}
_STATE: dict[str, Any] = dict(_DEFAULT_STATE)


class BridgeError(RuntimeError):
    pass


def _core_api():
    """Return the statically imported, non-resident bridge API.

    The API module imports no NumPy/PSD decoder at module load.  Static binding
    avoids reload-sensitive dynamic module lookup and makes the active
    implementation unambiguous for call-graph auditing.
    """
    return _bridge_api


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    """Atomic JSON with flush/fsync/replace/readback and one valid backup."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8") + b"\n"
    temp = path.with_name(path.name + f".{os.getpid()}.{time.monotonic_ns()}.tmp")
    backup = path.with_suffix(path.suffix + ".bak")
    try:
        if path.is_file() and not path.is_symlink():
            try:
                current = path.read_bytes()
                parsed = json.loads(current.decode("utf-8"))
                if isinstance(parsed, dict):
                    btmp = backup.with_name(backup.name + f".{time.monotonic_ns()}.tmp")
                    with btmp.open("xb") as handle:
                        handle.write(current)
                        handle.flush()
                        os.fsync(handle.fileno())
                    os.replace(btmp, backup)
            except (OSError, UnicodeError, json.JSONDecodeError):
                pass
        with temp.open("xb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        if path.read_bytes() != encoded:
            raise OSError("atomic_json_readback_mismatch")
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def _read_json(path: Path) -> dict[str, Any]:
    """Read a JSON object; recover from a valid backup without deleting damage."""
    for candidate in (Path(path), Path(path).with_suffix(Path(path).suffix + ".bak")):
        try:
            if candidate.is_symlink() or not candidate.is_file():
                continue
            value = json.loads(candidate.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                if candidate != Path(path):
                    _atomic_json(Path(path), value)
                return value
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue
    return {}


def _safe_file(path: Path, root: Path | None = None) -> bool:
    try:
        if path.is_symlink() or not path.is_file():
            return False
        stat = path.stat(follow_symlinks=False)
        if int(getattr(stat, "st_file_attributes", 0) or 0) & 0x400:
            return False
        if root is not None:
            resolved_root = root.resolve(strict=True)
            resolved_path = path.resolve(strict=True)
            if resolved_root not in resolved_path.parents:
                return False
        return True
    except OSError:
        return False


def _fingerprint(path: Path, *, root: Path | None = None) -> dict[str, Any]:
    if not _safe_file(path, root):
        raise BridgeError("bridge_file_identity_invalid")
    identity = resource_quota.file_identity(path)
    digest = resource_quota.file_sha256(path)
    return {
        "path": str(path.resolve(strict=True)),
        **identity,
        "sha256": digest,
        "generation": f"{identity['size']}:{identity['mtime_ns']}:{digest}",
    }


def _session_root() -> Path:
    root = str(bpy.utils.user_resource("CONFIG", path="smart_paint_suite/external_bridge", create=True) or "")
    if not root:
        raise BridgeError("bridge_config_root_unavailable")
    return Path(root)


def _new_session_paths(document: dict[str, Any]) -> dict[str, Any]:
    document_key = str(document["document_key"])
    session_generation = str(uuid.uuid4())
    slug = hashlib.sha256(document_key.encode("utf-8")).hexdigest()[:24]
    bridge_root = _session_root()
    session_dir = bridge_root / slug / session_generation
    runtime_generation = str(runtime_registry.snapshot().get("generation") or document.get("generation") or "")
    process_lease = resource_quota.process_lease_identity()
    resource_quota.mark_session(
        session_dir,
        generation=runtime_generation,
        document_key=document_key,
        session_generation=session_generation,
        process_lease=process_lease,
    )
    for name in ("results", "pending", "temp", "cache", "images", "logs"):
        (session_dir / name).mkdir(parents=True, exist_ok=True)
    # Global recursive LRU: exact owner/schema/document/session/process identity
    # only; active sessions from other Blender processes are never candidates.
    resource_quota.enforce_session_root(bridge_root, active_session=session_dir)
    return {
        "bridge_root": bridge_root,
        "root": session_dir,
        "process_lease": process_lease,
        "exchange": session_dir / "exchange.psd",
        "manifest": session_dir / "exchange_manifest.json",
        "local_snapshot": session_dir / "local_snapshot.psd",
        "results": session_dir / "results",
        "transaction": session_dir / "pending" / "apply_state.json",
        "ack": session_dir / "pending" / "ack.json",
    }



def _register_file(path: Path) -> None:
    """Register one exact managed file and its optional atomic backup.

    The session manifest is authoritative.  A JSON backup produced by
    :func:`_atomic_json` is therefore registered with its own SHA-256 and native
    file identity instead of remaining an unowned file that would block exact
    cleanup.
    """
    with _LOCK:
        root_text = str(_STATE.get("session_dir", "") or "")
        document_key = str(_STATE.get("document_key", "") or "")
        session_generation = str(_STATE.get("session_generation", "") or "")
    if not root_text or not document_key or not session_generation:
        return
    root = Path(root_text)
    candidates = [Path(path)]
    backup = Path(path).with_suffix(Path(path).suffix + ".bak")
    if backup != Path(path):
        candidates.append(backup)
    registered: list[Path] = []
    for candidate in candidates:
        if not _safe_file(candidate, root):
            continue
        resource_quota.register_managed_file(
            root,
            candidate,
            document_key=document_key,
            session_generation=session_generation,
        )
        registered.append(candidate)
    if not registered:
        return
    parent = Path(path).parent
    quotas = {
        "pending": (resource_quota.PENDING_COUNT_LIMIT, resource_quota.PENDING_BYTE_LIMIT),
        "results": (resource_quota.RESULT_COUNT_LIMIT, resource_quota.RESULT_BYTE_LIMIT),
        "temp": (resource_quota.TEMP_COUNT_LIMIT, resource_quota.TEMP_BYTE_LIMIT),
        "cache": (resource_quota.CACHE_COUNT_LIMIT, resource_quota.CACHE_BYTE_LIMIT),
        "images": (resource_quota.IMAGE_COUNT_LIMIT, resource_quota.IMAGE_BYTE_LIMIT),
    }
    limits = quotas.get(parent.name)
    if limits is not None:
        resource_quota.enforce_directory(
            parent,
            count_limit=limits[0],
            byte_limit=limits[1],
            preserve=tuple(registered),
        )
    elif parent.name == "logs":
        for candidate in registered:
            resource_quota.rotate_log(candidate)

def _remove_registered(path: Path) -> bool:
    with _LOCK:
        root = Path(str(_STATE.get("session_dir", "") or ""))
        document_key = str(_STATE.get("document_key", "") or "")
        session_generation = str(_STATE.get("session_generation", "") or "")
    if not root or not document_key or not session_generation:
        return False
    return resource_quota.remove_managed_file(
        root, path,
        document_key=document_key,
        session_generation=session_generation,
    )


def _prepare_exchange(canonical: Path, paths: dict[str, Path], *, prepare=None) -> dict[str, Any]:
    if prepare is None:
        from .exchange_prepare import prepare_exchange as prepare

    result = prepare(canonical, paths["exchange"], paths["manifest"])
    _register_file(paths["exchange"])
    _register_file(paths["manifest"])
    return result



def _register_directory_files(directory: Path) -> None:
    """Adopt every regular file created inside one Suite-owned session folder.

    The one-shot scanner writes atomically and may fail after producing a subset
    of payloads.  Registering the exact post-operation files in a ``finally``
    block prevents an unmanifested partial file from making later cleanup
    ambiguous.  The directory is a newly created owner/session root; links and
    reparse points are rejected by both this module and ``resource_quota``.
    """
    directory = Path(directory)
    try:
        files = tuple(directory.rglob("*")) if directory.is_dir() else ()
    except OSError:
        files = ()
    for candidate in files:
        if _safe_file(candidate, directory.parent):
            _register_file(candidate)


def _managed_payloads(result: dict[str, Any]) -> tuple[Path, ...]:
    paths: list[Path] = []
    with _LOCK:
        root = Path(str(_STATE.get("session_dir", "") or ""))
    for item in result.get("payloads", ()) or ():
        if not isinstance(item, dict):
            continue
        path = Path(str(item.get("payload_path", "") or ""))
        if _safe_file(path, root):
            paths.append(path)
    return tuple(paths)


_PENDING_CALL_TYPE = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p)
_DISCONNECT_REASON = "event_lease_ended"


def _auto_apply_dispatch(_argument) -> int:
    global _PENDING_CALL_QUEUED
    with _LOCK:
        _PENDING_CALL_QUEUED = False
        connected = bool(_STATE.get("connected"))
    if connected:
        try:
            # EXEC_DEFAULT enters the registered INTERNAL+UNDO operator once;
            # the worker thread never mutates Blender data directly.
            bpy.ops.smart_paint_bridge.apply_pending("EXEC_DEFAULT")
        except (RuntimeError, ReferenceError, AttributeError) as exc:
            _set_error("auto_apply_dispatch_failed", exc)
    return 0


def _lease_cleanup_dispatch(_argument) -> int:
    global _DISCONNECT_CALL_QUEUED
    with _LOCK:
        _DISCONNECT_CALL_QUEUED = False
        reason = str(_DISCONNECT_REASON or "event_lease_ended")
    disconnect(reason, blocking=True)
    return 0


# Keep native callback objects alive for the lifetime of this module.  Clearing
# a CFUNCTYPE object while CPython still owns a queued Py_AddPendingCall pointer
# can dereference freed executable memory during Disconnect/reload.
_PENDING_CALL_CALLBACK = _PENDING_CALL_TYPE(_auto_apply_dispatch)
_DISCONNECT_CALL_CALLBACK = _PENDING_CALL_TYPE(_lease_cleanup_dispatch)


def _enqueue_pending_call(callback) -> bool:
    try:
        pending = ctypes.pythonapi.Py_AddPendingCall
        pending.argtypes = (_PENDING_CALL_TYPE, ctypes.c_void_p)
        pending.restype = ctypes.c_int
        return int(pending(callback, None)) == 0
    except (AttributeError, TypeError, OSError):
        return False


def _schedule_auto_apply() -> bool:
    global _PENDING_CALL_QUEUED
    with _LOCK:
        if _PENDING_CALL_QUEUED or not _STATE.get("connected"):
            return False
        _PENDING_CALL_QUEUED = True
    if _enqueue_pending_call(_PENDING_CALL_CALLBACK):
        return True
    with _LOCK:
        _PENDING_CALL_QUEUED = False
    _set_error("pending_call_unavailable")
    return False


def _schedule_lease_cleanup(reason: str) -> bool:
    """Queue finite main-thread cleanup after an unexpected native wait exit."""
    global _DISCONNECT_CALL_QUEUED, _DISCONNECT_REASON
    with _LOCK:
        if _DISCONNECT_CALL_QUEUED:
            return False
        if str(runtime_registry.snapshot().get("state", "")) != "READY":
            return False
        _DISCONNECT_CALL_QUEUED = True
        _DISCONNECT_REASON = str(reason or "event_lease_ended")
    if _enqueue_pending_call(_DISCONNECT_CALL_CALLBACK):
        return True
    with _LOCK:
        _DISCONNECT_CALL_QUEUED = False
    return False

def _event_lease_terminated(error: str) -> None:
    with _LOCK:
        expected_stop = (
            not bool(_STATE.get("connected"))
            or str(_STATE.get("phase", "")) in {"disconnecting", "disconnected"}
        )
        if expected_stop:
            return
        _STATE["connected"] = False
        _STATE["event_watcher_running"] = False
        _STATE["worker_running"] = False
        _STATE["phase"] = "event_lease_ended"
        _STATE["last_error"] = (
            f"event_lease_ended: {error}" if error else "event_lease_ended"
        )[:512]
    runtime_registry.component_state("external_bridge", "FAILED", _STATE["last_error"])
    _schedule_lease_cleanup("event_lease_ended")


def _set_error(reason: str, error: BaseException | str = "") -> None:
    text = str(error or "")
    with _LOCK:
        _STATE["last_error"] = f"{reason}: {text}"[:512] if text else str(reason)[:512]
    runtime_registry.component_state("external_bridge", "FAILED", _STATE["last_error"])


def _settled_exchange_fingerprint(
    path: Path,
    *,
    root: Path,
    cancel_event: threading.Event,
) -> dict[str, Any] | None:
    """Wait only after a real native change event, within one fixed budget."""
    deadline = time.monotonic() + FILE_SETTLE_TIME_BUDGET_SECONDS
    delay = FILE_SETTLE_INITIAL_SECONDS
    previous: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        if cancel_event.wait(delay):
            return None
        current = _fingerprint(path, root=root)
        if previous is not None and current == previous:
            return current
        previous = current
        delay = min(0.16, delay * 2.0)
    return previous


def _scan_external_change(cancel_event: threading.Event) -> None:
    """Event worker path: file/data-only work; no Blender RNA and no idle loop."""
    global _PENDING_RESULT
    with _LOCK:
        if not _STATE.get("connected"):
            return
        root = Path(str(_STATE["session_dir"]))
        exchange = Path(str(_STATE["exchange_path"]))
        manifest = Path(str(_STATE["manifest_path"]))
        suppress = str(_STATE.get("suppress_exchange_generation", "") or "")
        lease_uuid = str(_STATE.get("process_lease_uuid", "") or "")
    try:
        current = _settled_exchange_fingerprint(
            exchange, root=root, cancel_event=cancel_event
        )
        if current is None:
            return
        if suppress and current["generation"] == suppress:
            return
        if lease_uuid:
            event_time = time.time()
            if not resource_quota.renew_session_lease(
                root, lease_uuid=lease_uuid, event_time=event_time
            ):
                raise BridgeError("process_lease_renew_failed")
            with _LOCK:
                _STATE["process_lease_deadline"] = (
                    event_time + resource_quota.SESSION_HEARTBEAT_LEASE_SECONDS
                )
                lease_state = _LEASE
            if isinstance(lease_state, dict):
                lease_object = lease_state.get("lease")
                renew = getattr(lease_object, "renew_deadline", None)
                if callable(renew):
                    renew()
        from .worker_scan import scan_once
        try:
            result = scan_once(
                manifest,
                exchange,
                root / "results",
                baseline_store=None,
                cancel_event=cancel_event,
                time_budget_seconds=30.0,
            )
        finally:
            _register_directory_files(root / "results")
        if not bool(result.get("ok")):
            raise BridgeError(str(result.get("reason", "external_scan_failed")))
        changed = list(result.get("payloads", ()) or ())
        token = str(result.get("import_token", "") or "")
        with _LOCK:
            _STATE["scan_count"] = int(_STATE.get("scan_count", 0) or 0) + 1
            if not changed or not token or token == str(_STATE.get("applied_token", "") or ""):
                _STATE["phase"] = "idle"
                return
            _PENDING_RESULT = dict(result)
            _STATE["pending_count"] = len(changed)
            _STATE["pending_token"] = token
            _STATE["phase"] = "pending_import"
            _STATE["last_error"] = ""
        _schedule_auto_apply()
    except (OSError, ValueError, BridgeError) as exc:
        _set_error("external_change_scan_failed", exc)
        _schedule_lease_cleanup("external_change_scan_failed")



def _watcher_change_callback(cancel_event: threading.Event):
    def _callback() -> None:
        _scan_external_change(cancel_event)
    return _callback


def _external_process_exited() -> None:
    _schedule_lease_cleanup("external_process_exit")


def _lease_deadline_reached() -> None:
    _schedule_lease_cleanup("lease_deadline")


def _start_event_lease(paths: dict[str, Any], *, process_handle: int = 0) -> dict[str, Any]:
    global _LEASE
    if os.name != "nt":
        return {"ok": True, "reason": "windows_event_watcher_not_started", "thread_count": 0}
    from .win_events import DirectoryChangeLease, close_native_handle

    cancel_event = threading.Event()
    root_cancel = runtime_registry.shared_cancel_event()
    lease = DirectoryChangeLease(
        paths["exchange"].parent,
        paths["exchange"].name,
        _watcher_change_callback(cancel_event),
        on_process_exit=_external_process_exited,
        on_deadline=_lease_deadline_reached,
        on_terminated=_event_lease_terminated,
        process_handle=int(process_handle or 0),
        owns_process_handle=bool(process_handle),
        root_cancel=root_cancel,
        deadline_seconds=resource_quota.SESSION_HEARTBEAT_LEASE_SECONDS,
    )
    thread = None
    io_tracked = False
    thread_tracked = False
    try:
        thread = lease.start()
        runtime_registry.track_io(
            lease,
            label="external_bridge_directory_io",
            close=lease.close_io,
        )
        io_tracked = True
        runtime_registry.track_thread(
            thread,
            label="external_bridge_event_wait",
            stop=lambda: (cancel_event.set(), lease.stop()),
        )
        thread_tracked = True
    except (OSError, RuntimeError, AttributeError, TypeError, ValueError):
        cancel_event.set()
        lease.stop()
        lease.close_io()
        lease.join(2.0)
        if thread_tracked and thread is not None:
            runtime_registry.untrack_thread(thread)
        if io_tracked:
            runtime_registry.untrack_io(lease, close=False)
        if process_handle and not getattr(lease, "owns_process_handle", False):
            close_native_handle(process_handle)
        raise
    _LEASE = {
        "lease": lease,
        "cancel": cancel_event,
        "thread": thread,
        "process_handle_transferred": bool(process_handle),
    }
    with _LOCK:
        _STATE["event_watcher_running"] = True
        _STATE["worker_running"] = False
        _STATE["periodic_timer_count"] = 0
        _STATE["polling_worker_count"] = 0
    return {"ok": True, "reason": "windows_event_watcher_started", "thread_count": 1}

def _stop_event_lease() -> list[str]:
    """Stop the Connect event lease without losing a still-live handle.

    The exact lease/thread/I/O identities stay in both ``_LEASE`` and the
    generation journal until cancel, I/O close and join have all succeeded.
    A later Disconnect/unregister call can therefore retry cleanup instead of
    orphaning an untracked native wait.
    """
    global _LEASE
    errors: list[str] = []
    lease_state = _LEASE
    if not isinstance(lease_state, dict):
        return errors
    lease = lease_state.get("lease")
    cancel = lease_state.get("cancel")
    thread = lease_state.get("thread")
    try:
        if isinstance(cancel, threading.Event):
            cancel.set()
        if lease is not None:
            lease.stop()
    except (OSError, RuntimeError, AttributeError) as exc:
        errors.append(f"cancel:{type(exc).__name__}:{exc}")
    try:
        if lease is not None:
            lease.close_io()
    except (OSError, RuntimeError, AttributeError) as exc:
        errors.append(f"io_close:{type(exc).__name__}:{exc}")
    joined = False
    try:
        joined = bool(lease is None or lease.join(JOIN_TIMEOUT_SECONDS))
        if not joined:
            errors.append("event_wait_thread_alive")
    except (OSError, RuntimeError, AttributeError) as exc:
        errors.append(f"join:{type(exc).__name__}:{exc}")
    if joined and not errors:
        try:
            if lease is not None:
                runtime_registry.untrack_io(lease, close=False)
            if thread is not None:
                runtime_registry.untrack_thread(thread)
        except (RuntimeError, AttributeError) as exc:
            errors.append(f"journal_release:{type(exc).__name__}:{exc}")
    if joined and not errors:
        _LEASE = None
    with _LOCK:
        _STATE["event_watcher_running"] = bool(not joined)
        _STATE["worker_running"] = bool(not joined)
        if errors:
            _STATE["resource_error"] = "; ".join(errors)[:512]
    return errors


def _launch_exchange(path: Path, *, retain_process_handle: bool = False) -> dict[str, Any]:
    """Open the exchange once; retain a Windows wait handle only for Connect."""
    if not path.is_file() or path.is_symlink():
        return {"ok": False, "reason": "exchange_missing_or_link"}
    try:
        if os.name == "nt":
            from .win_events import close_native_handle, launch_with_process_handle
            handle = int(launch_with_process_handle(path))
            if not retain_process_handle:
                close_native_handle(handle)
                handle = 0
            return {
                "ok": True,
                "reason": "exchange_open_dispatched",
                "process_handle": handle,
                "process_handle_owned": bool(handle),
            }
        command = ["open", str(path)] if sys_platform() == "darwin" else ["xdg-open", str(path)]
        subprocess.run(
            command,
            check=True,
            timeout=5.0,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return {"ok": True, "reason": "exchange_open_dispatched", "process_handle": 0}
    except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
        return {"ok": False, "reason": "exchange_open_failed", "error": str(exc)[:384]}



def sys_platform() -> str:
    import sys
    return str(sys.platform)


def connect(context, backend: str) -> dict[str, Any]:
    """Create one explicit, generation-owned Connect lease."""
    global _PENDING_RESULT
    backend = str(backend or "").upper()
    if backend not in SUPPORTED_BACKENDS:
        return {"ok": False, "reason": "unsupported_backend"}
    with _LOCK:
        if _STATE.get("connected") or _LEASE is not None:
            return {"ok": False, "reason": "bridge_already_connected"}

    try:
        from .exchange_prepare import prepare_exchange
    except ImportError as exc:
        return {
            "ok": False,
            "reason": "External bridge requires psd-tools and Pillow in Blender Python.",
            "error": str(exc)[:512],
        }

    api = _core_api()
    target = api.ensure_visible_paint_target(context)
    if not isinstance(target, dict) or not bool(target.get("ok")):
        return dict(target) if isinstance(target, dict) else {"ok": False, "reason": "visible_target_failed"}
    document = api.document_snapshot(context)
    if not isinstance(document, dict) or not bool(document.get("ok")):
        return dict(document) if isinstance(document, dict) else {"ok": False, "reason": "document_snapshot_failed"}
    source = Path(str(document.get("path", "") or ""))
    if not source.is_file() or source.is_symlink():
        return {"ok": False, "reason": "source_psd_missing_or_link"}

    paths: dict[str, Any] | None = None
    process_handle = 0
    state_installed = False
    try:
        paths = _new_session_paths(document)
        session_generation = str(paths["root"].name)
        process_lease = dict(paths["process_lease"])
        with _LOCK:
            _STATE.clear()
            _STATE.update({
                **_DEFAULT_STATE,
                "connected": True,
                "backend": backend,
                "document_key": str(document["document_key"]),
                "generation": str(document["generation"]),
                "material_name": str(document.get("material_name", "") or ""),
                "path": str(source.resolve(strict=True)),
                "record_count": len(document.get("records", ()) or ()),
                "preferred_layer_name": str(document.get("active_layer_name", "") or ""),
                "preferred_record_index": int(document.get("active_record_index", -1) or -1),
                "api_version": int(document.get("api_version", 0) or 0),
                "session_generation": session_generation,
                "session_dir": str(paths["root"]),
                "process_lease_uuid": str(process_lease.get("uuid", "") or ""),
                "process_lease_pid": int(process_lease.get("pid", 0) or 0),
                "process_lease_creation_time": str(process_lease.get("process_creation_time", "") or ""),
                "process_lease_deadline": float(process_lease.get("heartbeat_deadline", 0.0) or 0.0),
                "exchange_path": str(paths["exchange"]),
                "manifest_path": str(paths["manifest"]),
                "phase": "preparing",
            })
            _PENDING_RESULT = None
        state_installed = True

        prepared = _prepare_exchange(source, paths, prepare=prepare_exchange)
        fingerprint = _fingerprint(paths["exchange"], root=paths["root"])
        with _LOCK:
            _STATE["suppress_exchange_generation"] = fingerprint["generation"]
            _STATE["phase"] = "launching"
        opened = _launch_exchange(paths["exchange"], retain_process_handle=True)
        if not bool(opened.get("ok")):
            raise BridgeError(str(opened.get("reason", "exchange_open_failed")))
        process_handle = int(opened.get("process_handle", 0) or 0)
        watcher = _start_event_lease(paths, process_handle=process_handle)
        process_handle = 0  # exact ownership transferred to DirectoryChangeLease
        with _LOCK:
            _STATE["phase"] = "idle"
            _STATE["last_error"] = ""
            _STATE["resource_error"] = ""
        runtime_registry.component_state("external_bridge", "READY")
        resource_quota.touch_session(paths["root"])
        return {
            "ok": True,
            "reason": "connected",
            "backend_label": "Adobe Photoshop" if backend == "PHOTOSHOP" else "Clip Studio Paint",
            "record_count": len(document.get("records", ()) or ()),
            "exchange_rebuilt": True,
            "event_watcher": watcher.get("reason"),
            "periodic_timers": 0,
            "polling_workers": 0,
            "periodic_writes": 0,
            "prepared": prepared,
        }
    except (OSError, RuntimeError, ValueError, TypeError, AttributeError, BridgeError) as exc:
        if process_handle and os.name == "nt":
            try:
                from .win_events import close_native_handle
                close_native_handle(process_handle)
            except (OSError, RuntimeError, AttributeError):
                pass
        _set_error("connect_failed", exc)
        if state_installed:
            disconnect("connect_failed", blocking=True)
        elif paths is not None:
            lease = dict(paths.get("process_lease", {}) or {})
            lease_uuid = str(lease.get("uuid", "") or "")
            try:
                if lease_uuid:
                    resource_quota.release_session_lease(paths["root"], lease_uuid=lease_uuid)
                resource_quota.cleanup_session(paths["root"], remove_session=True)
            except (OSError, ValueError, TypeError):
                pass
        return {"ok": False, "reason": "connect_failed", "error": str(exc)[:512]}


def disconnect(reason: str = "", *, blocking: bool = True) -> dict[str, Any]:
    """Finite idempotent teardown; handle identities survive until cleanup ends."""
    del blocking  # teardown is intentionally always synchronous and finite
    global _PENDING_RESULT
    with _LOCK:
        if _STATE.get("phase") == "disconnecting":
            return {"ok": False, "reason": "bridge_disconnect_in_progress"}
        was_connected = bool(_STATE.get("connected"))
        session_text = str(_STATE.get("session_dir", "") or "")
        lease_uuid = str(_STATE.get("process_lease_uuid", "") or "")
        _STATE["connected"] = False
        _STATE["phase"] = "disconnecting"
    session_dir = Path(session_text) if session_text else None

    errors = _stop_event_lease()
    with _LOCK:
        _OBSERVER_WINDOWS.clear()

    lease_released = session_dir is None or not lease_uuid
    if session_dir is not None and lease_uuid:
        try:
            lease_released = resource_quota.release_session_lease(
                session_dir,
                lease_uuid=lease_uuid,
            )
            if not lease_released:
                errors.append("process_lease_release_failed")
        except (OSError, ValueError, TypeError) as exc:
            errors.append(f"process_lease_release:{type(exc).__name__}:{exc}")

    try:
        _bridge_api.clear_runtime_state("bridge_disconnect")
    except (AttributeError, RuntimeError, ReferenceError, TypeError, ValueError) as exc:
        errors.append(f"bridge_state_clear:{type(exc).__name__}:{exc}")
    resource_quota.clear_all_memory(reason="bridge_disconnect")
    with _LOCK:
        _PENDING_RESULT = None
        _COMMITTED_TOKENS.clear()

    native_stopped = _LEASE is None
    session_removed = session_dir is None
    if session_dir is not None and session_dir.is_dir() and native_stopped and lease_released:
        try:
            cleanup = resource_quota.cleanup_session(session_dir, remove_session=True)
            session_removed = bool(cleanup.get("session_removed", not session_dir.exists()))
            if session_dir.exists() and not session_removed:
                errors.append("managed_session_cleanup_incomplete")
            resource_quota.enforce_session_root(_session_root(), active_session=None)
        except (OSError, ValueError, TypeError) as exc:
            errors.append(f"quota_cleanup:{type(exc).__name__}:{exc}")
    elif session_dir is not None and not session_dir.exists():
        session_removed = True

    complete = bool(native_stopped and lease_released and not errors)
    resource_error = "; ".join(errors)[:512]
    if complete:
        with _LOCK:
            _STATE.clear()
            _STATE.update(_DEFAULT_STATE)
            _STATE["phase"] = "disconnected"
        runtime_registry.component_state("external_bridge", "OFF")
    else:
        # Keep exact session/lease metadata for a later idempotent cleanup retry;
        # never discard a live native handle or ambiguous managed root reference.
        with _LOCK:
            _STATE["event_watcher_running"] = bool(_LEASE is not None)
            _STATE["worker_running"] = bool(_LEASE is not None)
            _STATE["periodic_timer_count"] = 0
            _STATE["polling_worker_count"] = 0
            _STATE["resource_error"] = resource_error or "resource_cleanup_incomplete"
            _STATE["last_error"] = _STATE["resource_error"]
            _STATE["phase"] = "resource_stop_failed"
        runtime_registry.component_state("external_bridge", "FAILED", _STATE["resource_error"])
    return {
        "ok": complete,
        "reason": str(reason or "disconnected"),
        "was_connected": was_connected,
        "resource_errors": errors,
        "native_stopped": native_stopped,
        "lease_released": bool(lease_released),
        "session_removed": bool(session_removed),
        "resource_counts": runtime_registry.resource_counts(),
        "periodic_timers": 0,
        "polling_workers": 0,
        "periodic_writes": 0,
    }

def open_exchange(*, reload_existing: bool = False) -> dict[str, Any]:
    del reload_existing
    with _LOCK:
        if not _STATE.get("connected"):
            return {"ok": False, "reason": "bridge_not_connected"}
        path = Path(str(_STATE.get("exchange_path", "") or ""))
    return _launch_exchange(path)


def request_source_refresh() -> dict[str, Any]:
    with _LOCK:
        if not _STATE.get("connected"):
            return {"ok": False, "reason": "bridge_not_connected"}
        source = Path(str(_STATE["path"]))
        paths = {
            "root": Path(str(_STATE["session_dir"])),
            "exchange": Path(str(_STATE["exchange_path"])),
            "manifest": Path(str(_STATE["manifest_path"])),
        }
    try:
        prepared = _prepare_exchange(source, paths)
        fingerprint = _fingerprint(paths["exchange"], root=paths["root"])
        with _LOCK:
            _STATE["suppress_exchange_generation"] = fingerprint["generation"]
            _STATE["phase"] = "idle"
        return {"ok": True, "reason": "source_refresh_complete", "prepared": prepared}
    except (OSError, ValueError, BridgeError) as exc:
        _set_error("source_refresh_failed", exc)
        return {"ok": False, "reason": "source_refresh_failed", "error": str(exc)[:384]}


def prepare_local_stroke(context=None) -> dict[str, Any]:
    with _LOCK:
        if not _STATE.get("connected"):
            return {"ok": False, "reason": "bridge_not_connected"}
        record_index = int(_STATE.get("preferred_record_index", -1) or -1)
        document_key = str(_STATE.get("document_key", "") or "")
        generation = str(_STATE.get("generation", "") or "")
    api = _core_api()
    target = api.ensure_visible_paint_target(context)
    if not bool(target.get("ok")):
        return target
    record_index = int(target.get("active_record_index", record_index) or record_index)
    try:
        return api.prime_local_push_baseline(
            context,
            record_index,
            expected_document_key=document_key,
            expected_generation=generation,
        )
    except (AttributeError, RuntimeError, ValueError) as exc:
        return {"ok": False, "reason": "local_baseline_failed", "error": str(exc)[:384]}


def notify_local_stroke(context=None) -> dict[str, Any]:
    """Finite Blender->external transaction; no resident writer/thread/timer."""
    with _LOCK:
        if not _STATE.get("connected"):
            return {"ok": False, "reason": "bridge_not_connected"}
        paths = {
            "root": Path(str(_STATE["session_dir"])),
            "exchange": Path(str(_STATE["exchange_path"])),
            "manifest": Path(str(_STATE["manifest_path"])),
            "local_snapshot": Path(str(_STATE["session_dir"])) / "local_snapshot.psd",
        }
        document_key = str(_STATE["document_key"])
        generation = str(_STATE["generation"])
        record_index = int(_STATE.get("preferred_record_index", -1) or -1)
        _STATE["local_push_phase"] = "collecting"
    api = _core_api()
    collected = api.collect_local_patches(
        context, record_indices=[record_index] if record_index >= 0 else None
    )
    if not bool(collected.get("ok")):
        return collected
    if int(collected.get("count", 0) or 0) <= 0:
        with _LOCK:
            _STATE["local_push_phase"] = ""
        return {"ok": True, "reason": "no_local_changes", "count": 0}
    try:
        from .. import psd_io
        material = api._material(context)
        if material is None:
            raise BridgeError("smart_paint_material_not_found")
        with _LOCK:
            _STATE["local_push_phase"] = "writing"
        if not bool(psd_io.write_layered_psd(material, "BASE_COLOR", paths["local_snapshot"])):
            raise BridgeError("local_snapshot_write_failed")
        _register_file(paths["local_snapshot"])
        _prepare_exchange(paths["local_snapshot"], paths)
        current = _fingerprint(paths["exchange"], root=paths["root"])
        records = [int(item["record_index"]) for item in collected.get("patches", ())]
        rects = [
            (int(item["record_index"]), tuple(int(value) for value in item["rect_psd"]))
            for item in collected.get("patches", ())
        ]
        acknowledged = api.mark_pushed(
            context,
            str(collected.get("token", "") or ""),
            records=records,
            rects=rects,
            expected_document_key=document_key,
            expected_generation=generation,
        )
        if not bool(acknowledged.get("ok")):
            raise BridgeError(str(acknowledged.get("reason", "local_push_ack_failed")))
        with _LOCK:
            _STATE["suppress_exchange_generation"] = current["generation"]
            _STATE["local_push_phase"] = ""
            _STATE["local_push_count"] = int(_STATE.get("local_push_count", 0) or 0) + 1
            _STATE["phase"] = "idle"
        open_exchange(reload_existing=True)
        return {"ok": True, "reason": "local_push_complete", "count": len(records)}
    except (OSError, ValueError, RuntimeError, BridgeError) as exc:
        with _LOCK:
            _STATE["local_push_phase"] = "failed"
            _STATE["local_push_retry_count"] = int(_STATE.get("local_push_retry_count", 0) or 0) + 1
        _set_error("local_push_failed", exc)
        return {"ok": False, "reason": "local_push_failed", "error": str(exc)[:384]}


def _load_payloads(result: dict[str, Any]) -> list[dict[str, Any]]:
    import numpy as np

    with _LOCK:
        root = Path(str(_STATE["session_dir"]))
        document_key = str(_STATE.get("document_key", "") or "")
        session_generation = str(_STATE.get("session_generation", "") or "")
        lease_uuid = str(_STATE.get("process_lease_uuid", "") or "")
        runtime_generation = str(runtime_registry.snapshot().get("generation", "") or "")
    manifest = resource_quota.read_managed_manifest(root)
    if manifest is None:
        raise BridgeError("managed_session_manifest_invalid")
    patches: list[dict[str, Any]] = []
    total = 0
    for item in result.get("payloads", ()) or ():
        if not isinstance(item, dict):
            raise BridgeError("payload_contract_invalid")
        path = Path(str(item.get("payload_path", "") or ""))
        if not resource_quota.managed_file_matches(
            root,
            path,
            document_key=document_key,
            session_generation=session_generation,
            process_lease_uuid=lease_uuid,
            generation=runtime_generation,
        ):
            raise BridgeError("payload_managed_identity_mismatch")
        rgba = np.load(path, allow_pickle=False, mmap_mode="r")
        expected_shape = tuple(int(value) for value in item.get("shape", ()))
        if rgba.dtype != np.dtype("<f4") or tuple(rgba.shape) != expected_shape or rgba.ndim != 3 or rgba.shape[2] != 4:
            raise BridgeError("payload_shape_or_dtype_invalid")
        if not bool(rgba.flags.c_contiguous):
            # Scanner payloads are canonical C-order ``<f4`` NPY files.  A
            # non-contiguous view would require a document-sized duplicate;
            # reject it instead and keep the transaction uncommitted.
            raise BridgeError("payload_not_c_contiguous")
        if hashlib.sha256(memoryview(rgba).cast("B")).hexdigest() != str(item.get("sha256", "")):
            raise BridgeError("payload_hash_mismatch")
        total += int(rgba.nbytes)
        if total > RESULT_BYTE_BUDGET or len(patches) >= RESULT_COUNT_BUDGET:
            raise BridgeError("payload_shared_budget_exceeded")
        patches.append({
            "record_index": int(item["record_index"]),
            "rect_psd": tuple(int(value) for value in item["rect_psd"]),
            "rgba": rgba,
        })
    return patches



def _write_apply_state(phase: str, result: dict[str, Any], applied: dict[str, Any] | None = None) -> None:
    with _LOCK:
        path = Path(str(_STATE["session_dir"])) / "pending" / "apply_state.json"
    payload = {
        "schema": SESSION_SCHEMA,
        "owner": resource_quota.SUITE_OWNER,
        "phase": str(phase),
        "token": str(result.get("import_token", "") or ""),
        "exchange_generation": str(result.get("exchange_generation", "") or ""),
        "document_key": str(_STATE.get("document_key", "") or ""),
        "session_generation": str(_STATE.get("session_generation", "") or ""),
        "applied": dict(applied or {}),
        "updated_at": time.time(),
    }
    _atomic_json(path, payload)
    _register_file(path)


def _promote_exchange_ack(result: dict[str, Any]) -> None:
    from .exchange_manifest import atomic_write_json, read_manifest

    with _LOCK:
        root = Path(str(_STATE["session_dir"]))
        manifest_path = Path(str(_STATE["manifest_path"]))
        exchange_path = Path(str(_STATE["exchange_path"]))
        ack_path = root / "pending" / "ack.json"
    current = _fingerprint(exchange_path, root=root)
    expected = str(result.get("exchange_generation", "") or "")
    if expected and current["generation"] != expected:
        raise BridgeError("exchange_advanced_before_ack")
    manifest = read_manifest(manifest_path)
    manifest = dict(manifest)
    manifest["exchange"] = {
        "path": current["path"], "size": current["size"],
        "mtime_ns": current["mtime_ns"], "sha256": current["sha256"],
        "generation": current["generation"],
    }
    atomic_write_json(manifest_path, manifest)
    _register_file(manifest_path)
    _atomic_json(ack_path, {
        "schema": SESSION_SCHEMA,
        "owner": resource_quota.SUITE_OWNER,
        "token": str(result.get("import_token", "") or ""),
        "exchange_generation": current["generation"],
        "session_generation": str(_STATE.get("session_generation", "") or ""),
        "acknowledged_at": time.time(),
    })
    _register_file(ack_path)


def _finish_ack(result: dict[str, Any]) -> dict[str, Any]:
    global _PENDING_RESULT
    token = str(result.get("import_token", "") or "")
    try:
        _promote_exchange_ack(result)
    except (OSError, ValueError, BridgeError) as exc:
        with _LOCK:
            _STATE["ack_pending"] = True
            _STATE["phase"] = "ack_retry"
            _STATE["last_error"] = f"baseline_ack_failed: {exc}"[:512]
        return {"ok": False, "reason": "baseline_ack_failed", "error": str(exc)[:384], "data_committed": True}
    try:
        cleanup = getattr(_core_api(), "cleanup_retired_external_images", None)
        if callable(cleanup):
            cleanup(
                document_key=str(_STATE.get("document_key", "") or ""),
                token=token,
            )
    except (AttributeError, RuntimeError, ReferenceError, TypeError, ValueError) as exc:
        _set_error("retired_image_cleanup_failed", exc)
    for path in _managed_payloads(result):
        _remove_registered(path)
    with _LOCK:
        _STATE["ack_pending"] = False
        _STATE["pending_count"] = 0
        _STATE["pending_token"] = ""
        _STATE["applied_token"] = token
        _STATE["phase"] = "idle"
        _STATE["last_error"] = ""
        _PENDING_RESULT = None
    _COMMITTED_TOKENS.pop(token, None)
    return {"ok": True, "reason": "acknowledged", "token": token}



def apply_pending(context, *, automatic: bool = False) -> dict[str, Any]:
    del automatic
    global _APPLY_IN_PROGRESS
    with _LOCK:
        if not _STATE.get("connected"):
            return {"ok": False, "reason": "bridge_not_connected"}
        if _APPLY_IN_PROGRESS:
            return {"ok": False, "reason": "apply_in_progress"}
        result = dict(_PENDING_RESULT or {})
        token = str(result.get("import_token", "") or "")
        if not result or not token:
            return {"ok": True, "reason": "no_pending_import", "duplicate": True, "patch_count": 0}
        committed = token in _COMMITTED_TOKENS or token == str(_STATE.get("committed_token", "") or "")
        expected_document_key = str(_STATE["document_key"])
        expected_generation = str(_STATE["generation"])
        owner_generation = str(runtime_registry.snapshot().get("generation", "") or "")
        _APPLY_IN_PROGRESS = True
    patches: list[dict[str, Any]] = []
    try:
        if committed:
            patches = _load_payloads(result)
            match = _core_api().external_batch_matches_current(
                context,
                patches,
                expected_document_key=expected_document_key,
                expected_generation=expected_generation,
            ) if patches else {"ok": True, "matches": True, "reason": "no_visible_changes"}
            if bool(match.get("ok")) and bool(match.get("matches", False)):
                patches.clear()
                ack = _finish_ack(result)
                return {**ack, "duplicate": True, "patch_count": 0}
            invalidate = getattr(_core_api(), "invalidate_external_import_token", None)
            if callable(invalidate):
                invalidate(expected_document_key, token)
            _COMMITTED_TOKENS.pop(token, None)
            with _LOCK:
                _STATE["committed_token"] = ""
            committed = False

        _write_apply_state("PREPARED", result)
        if not patches:
            patches = _load_payloads(result)
        if not patches:
            _write_apply_state("COMMITTED", result, {"reason": "no_visible_changes"})
            _COMMITTED_TOKENS[token] = {"time": time.time(), "patch_count": 0}
            with _LOCK:
                _STATE["committed_token"] = token
            ack = _finish_ack(result)
            return {**ack, "duplicate": False, "patch_count": 0, "data_committed": False}

        applied = _core_api().apply_external_batch(
            context,
            patches,
            token,
            expected_document_key=expected_document_key,
            expected_generation=expected_generation,
            owner_generation=owner_generation,
        )
        if not isinstance(applied, dict) or not bool(applied.get("ok")):
            _write_apply_state("ROLLED_BACK", result, dict(applied or {}))
            return dict(applied) if isinstance(applied, dict) else {"ok": False, "reason": "core_apply_contract_invalid"}
        _write_apply_state("COMMITTED", result, {
            "reason": str(applied.get("reason", "") or ""),
            "patch_count": int(applied.get("patch_count", 0) or 0),
            "duplicate": bool(applied.get("duplicate", False)),
        })
        _COMMITTED_TOKENS[token] = {
            "time": time.time(),
            "patch_count": int(applied.get("patch_count", 0) or 0),
            "document_generation": expected_generation,
        }
        with _LOCK:
            _STATE["committed_token"] = token
        # Release NumPy mappings before ACK removes the payload files on Windows.
        patches.clear()
        ack = _finish_ack(result)
        if not bool(ack.get("ok")):
            return {
                **applied,
                "ok": True,
                "reason": "batch_applied_ack_pending",
                "baseline_ack": False,
                "ack_pending": True,
                "ack_error": str(ack.get("error", "") or "")[:384],
                "data_committed": True,
            }
        return {**applied, "baseline_ack": True, "ack_pending": False, "data_committed": True}
    except (OSError, ValueError, RuntimeError, BridgeError) as exc:
        try:
            _write_apply_state("ROLLED_BACK", result, {"error": str(exc)[:384]})
        except (OSError, ValueError, TypeError):
            pass
        _set_error("apply_failed", exc)
        return {"ok": False, "reason": "apply_failed", "error": str(exc)[:384]}
    finally:
        patches.clear()
        resource_quota.clear_for_memory_pressure()
        with _LOCK:
            _APPLY_IN_PROGRESS = False



def sync_open(context) -> dict[str, Any]:
    with _LOCK:
        pending = bool(_PENDING_RESULT)
    applied = apply_pending(context) if pending else {"ok": True, "reason": "no_pending_import", "patch_count": 0}
    if not bool(applied.get("ok")):
        return applied
    opened = open_exchange(reload_existing=True)
    return {**opened, "patch_count": int(applied.get("patch_count", 0) or 0)}


def claim_paint_observer(window) -> bool:
    try:
        pointer = int(window.as_pointer())
    except (AttributeError, TypeError, ValueError):
        return False
    with _LOCK:
        if not _STATE.get("connected") or pointer in _OBSERVER_WINDOWS:
            return False
        _OBSERVER_WINDOWS.add(pointer)
        return True


def release_paint_observer(window_pointer: int) -> None:
    with _LOCK:
        _OBSERVER_WINDOWS.discard(int(window_pointer or 0))


def observer_count() -> int:
    with _LOCK:
        return len(_OBSERVER_WINDOWS)


def note_paint_observer_event(event_type: str, event_value: str, **payload) -> None:
    with _LOCK:
        _STATE["observer_event_count"] = int(_STATE.get("observer_event_count", 0) or 0) + 1
        if str(event_value) == "PRESS":
            _STATE["observer_press_count"] = int(_STATE.get("observer_press_count", 0) or 0) + 1
        if payload.get("stroke_complete"):
            _STATE["observer_stroke_count"] = int(_STATE.get("observer_stroke_count", 0) or 0) + 1
        reason = payload.get("result")
        if isinstance(reason, dict):
            _STATE["observer_last_reason"] = str(reason.get("reason", "") or "")[:120]



def queue_layer_command(command: dict[str, Any]) -> dict[str, Any]:
    """Write one bounded, managed command batch on an active Connect lease.

    This is an explicit event-triggered write.  It creates no heartbeat,
    worker, repeating timer, or idle disk activity.
    """
    if not isinstance(command, dict):
        return {"ok": False, "reason": "layer_command_contract_invalid"}
    with _LOCK:
        if not _STATE.get("connected") or _STATE.get("backend") != "PHOTOSHOP":
            return {"ok": False, "reason": "photoshop_bridge_not_connected"}
        root = Path(str(_STATE.get("session_dir", "") or ""))
        session_generation = str(_STATE.get("session_generation", "") or "")
        document_key = str(_STATE.get("document_key", "") or "")
        process_lease_uuid = str(_STATE.get("process_lease_uuid", "") or "")
    path = root / "pending" / "layer_commands.json"
    existing = _read_json(path) if path.is_file() else {}
    rows = list(existing.get("commands", ()) or ()) if isinstance(existing, dict) else []
    safe = {
        "type": str(command.get("type", "") or ""),
        "layer_id": str(command.get("layer_id", "") or ""),
        "payload": {
            str(key): value for key, value in dict(command.get("payload", {}) or {}).items()
            if isinstance(value, (str, bool, int, float, type(None)))
        },
        "created_at": float(command.get("created_at", time.time()) or time.time()),
    }
    if not safe["type"] or not safe["layer_id"]:
        return {"ok": False, "reason": "layer_command_invalid"}
    rows.append(safe)
    rows = rows[-COMMAND_COUNT_LIMIT:]
    updated_at = time.time()

    def _payload(candidate_rows):
        return {
            "schema": SESSION_SCHEMA,
            "owner": resource_quota.SUITE_OWNER,
            "document_key": document_key,
            "session_generation": session_generation,
            "commands": list(candidate_rows),
            "updated_at": updated_at,
        }

    payload = _payload(rows)
    try:
        # Enforce both count and serialized-byte limits.  Drop oldest commands
        # only; the new explicit command is never silently truncated.
        while len(rows) > 1:
            encoded = json.dumps(
                payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ).encode("utf-8")
            if len(encoded) <= COMMAND_FILE_BYTE_LIMIT:
                break
            rows.pop(0)
            payload = _payload(rows)
        encoded = json.dumps(
            payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        if len(encoded) > COMMAND_FILE_BYTE_LIMIT:
            return {"ok": False, "reason": "layer_command_byte_budget_exceeded"}
        _atomic_json(path, payload)
        _register_file(path)
        if not resource_quota.renew_session_lease(
            root,
            lease_uuid=process_lease_uuid,
            event_time=updated_at,
        ):
            raise BridgeError("process_lease_renew_failed")
    except BridgeError as exc:
        _set_error("layer_command_lease_failed", exc)
        return {"ok": False, "reason": "layer_command_lease_failed", "error": str(exc)[:384]}
    except (OSError, TypeError, ValueError) as exc:
        _set_error("layer_command_write_failed", exc)
        return {"ok": False, "reason": "layer_command_write_failed", "error": str(exc)[:384]}
    return {"ok": True, "reason": "layer_command_queued", "count": len(rows)}

def sps_external_bridge_on_core_save(*_args, **_kwargs) -> None:
    if snapshot().get("connected"):
        notify_local_stroke(getattr(bpy, "context", None))


def register_core_save_callback(transaction=None) -> None:
    namespace = bpy.app.driver_namespace
    current = namespace.get(CORE_SAVE_CALLBACK)
    if current is sps_external_bridge_on_core_save:
        return
    if current is not None:
        raise BridgeError("core_save_callback_owned_by_other_generation")
    if transaction is not None:
        transaction.add_namespace_entry(namespace, CORE_SAVE_CALLBACK, sps_external_bridge_on_core_save)
    else:
        runtime_registry.add_namespace_entry(namespace, CORE_SAVE_CALLBACK, sps_external_bridge_on_core_save)


def unregister_core_save_callback() -> None:
    runtime_registry.remove_namespace_entry(
        bpy.app.driver_namespace,
        CORE_SAVE_CALLBACK,
        sps_external_bridge_on_core_save,
    )


def snapshot() -> dict[str, Any]:
    with _LOCK:
        result = dict(_STATE)
        result["observer_count"] = len(_OBSERVER_WINDOWS)
    result["backend_label"] = {
        "PHOTOSHOP": "Adobe Photoshop",
        "CLIP_STUDIO": "Clip Studio Paint",
    }.get(result.get("backend"), "Disconnected")
    result["resource_counts"] = runtime_registry.resource_counts()
    result["cache"] = resource_quota.memory_stats()
    return result


__all__ = (
    "SUPPORTED_BACKENDS", "_atomic_json", "_read_json", "apply_pending",
    "claim_paint_observer", "connect", "disconnect", "note_paint_observer_event",
    "notify_local_stroke", "observer_count", "open_exchange", "queue_layer_command",
    "prepare_local_stroke", "register_core_save_callback",
    "release_paint_observer", "request_source_refresh", "snapshot",
    "sync_open", "unregister_core_save_callback",
)
