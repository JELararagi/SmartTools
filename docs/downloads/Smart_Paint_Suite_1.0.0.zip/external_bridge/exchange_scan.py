# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Pure PSD scanner for the T5.1 CSP prototype.

No Blender or Smart Paint module may be imported from this file.
PSD の読み取りは同じ包みの psd_lite（標準ライブラリと numpy だけ）で行う。
画像は psd_lite.RgbaImage（(高さ, 幅, 4) の uint8 配列を包む型）で受け渡す。
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import numpy as np

from .exchange_manifest import (
    HASH_SPACE,
    RECORD_INDEX_SPACE,
    SCHEMA_VERSION,
    file_fingerprint,
    marker_for_record,
    structural_signature,
    validate_manifest,
)
from .psd_lite import (
    LayerNode,
    LayerRecord,
    PsdDocument,
    PsdError,
    RgbaImage,
    open_psd,
    record_rgba_fast,
    record_rgba_topil,
)


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _record_name(record: LayerRecord) -> str:
    """luni の名前があればそれを、なければ legacy 名を返す。"""
    return str(record.display_name)


def _section_type(record: LayerRecord) -> int:
    """lsct を先に、無ければ lsdk の区切りの種類を返す（どちらも無ければ 0）。"""
    return int(record.section_type)


def _channel_ids(record: LayerRecord) -> list[int]:
    return [int(value) for value in record.channel_ids]


def _record_bbox(record: LayerRecord) -> list[int]:
    return [int(value) for value in record.bbox]


def _visible_mapping(psd: PsdDocument) -> tuple[dict[int, LayerNode], list[dict[str, Any]]]:
    """群の木を psd_tools と同じ順に歩き、(記録の番号→節, 記録の無い節) を返す。"""
    mapping, _depths, missing = psd.visible_layers()
    return mapping, missing


def _layer_depths(psd: PsdDocument) -> dict[int, int]:
    _mapping, depths, _missing = psd.visible_layers()
    return depths


def _rgba_array(image) -> np.ndarray:
    """RgbaImage と (高さ, 幅, 4) の uint8 配列のどちらも RGBA の配列として返す。"""
    if isinstance(image, RgbaImage):
        return image.array
    value = np.asarray(image)
    if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 4:
        raise ValueError("rgba_image_invalid")
    return value


def _image_size(rgba: np.ndarray) -> tuple[int, int]:
    return int(rgba.shape[1]), int(rgba.shape[0])


def premultiplied_rgba_u8(image) -> np.ndarray:
    rgba = _rgba_array(image).astype(np.uint16)
    alpha = rgba[..., 3:4]
    rgb = (rgba[..., :3] * alpha + 127) // 255
    return np.concatenate((rgb, alpha), axis=2).astype(np.uint8, copy=False)


def visible_pixel_hash(image) -> str:
    rgba = _rgba_array(image)
    width, height = _image_size(rgba)
    digest = hashlib.sha256()
    digest.update(f"{width}x{height}\0{HASH_SPACE}\0".encode("ascii"))
    for top in range(0, height, 128):
        bottom = min(height, top + 128)
        block = rgba[top:bottom].astype(np.uint16)
        alpha = block[..., 3:4]
        visible = np.empty(block.shape, dtype=np.uint8)
        visible[..., :3] = ((block[..., :3] * alpha + 127) // 255).astype(
            np.uint8,
            copy=False,
        )
        visible[..., 3] = alpha[..., 0].astype(np.uint8, copy=False)
        digest.update(visible.tobytes(order="C"))
    return digest.hexdigest()


def visible_diff_dense_oracle(before, after) -> dict[str, Any]:
    """Reference implementation retained for exact sparse-diff validation."""
    before_rgba = _rgba_array(before)
    after_rgba = _rgba_array(after)
    before_size = _image_size(before_rgba)
    after_size = _image_size(after_rgba)
    if before_size != after_size:
        return {
            "same_size": False,
            "meaningful": True,
            "reason": "size_changed",
            "before_size": list(before_size),
            "after_size": list(after_size),
        }
    lhs = premultiplied_rgba_u8(before_rgba)
    rhs = premultiplied_rgba_u8(after_rgba)
    changed = np.any(lhs != rhs, axis=2)
    count = int(np.count_nonzero(changed))
    if count == 0:
        bbox = [0, 0, 0, 0]
        max_abs = 0
    else:
        ys, xs = np.nonzero(changed)
        bbox = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]
        delta = np.abs(lhs.astype(np.int16) - rhs.astype(np.int16))
        max_abs = int(delta[changed].max())
    return {
        "same_size": True,
        "compare_space": HASH_SPACE,
        "meaningful": bool(count),
        "reason": "visible_pixels_changed" if count else "visible_hash_unchanged",
        "count": count,
        "bbox": bbox,
        "max_abs": max_abs,
    }


def visible_diff(before, after) -> dict[str, Any]:
    """Compare visible pixels without premultiplying unchanged image regions."""
    lhs_rgba = _rgba_array(before)
    rhs_rgba = _rgba_array(after)
    before_size = _image_size(lhs_rgba)
    after_size = _image_size(rhs_rgba)
    if before_size != after_size:
        return {
            "same_size": False,
            "meaningful": True,
            "reason": "size_changed",
            "before_size": list(before_size),
            "after_size": list(after_size),
        }

    width, height = before_size
    count = 0
    min_x = width
    min_y = height
    max_x = -1
    max_y = -1
    max_abs = 0
    for top in range(0, height, 128):
        bottom = min(height, top + 128)
        lhs = lhs_rgba[top:bottom]
        rhs = rhs_rgba[top:bottom]
        lhs_alpha = lhs[..., 3]
        rhs_alpha = rhs[..., 3]
        alpha_changed = lhs_alpha != rhs_alpha
        rgb_changed = np.any(lhs[..., :3] != rhs[..., :3], axis=2)
        candidate = alpha_changed | (
            rgb_changed & ((lhs_alpha != 0) | (rhs_alpha != 0))
        )
        if not bool(np.any(candidate)):
            continue
        ys, xs = np.nonzero(candidate)
        lhs_pixels = lhs[candidate].astype(np.uint16, copy=False)
        rhs_pixels = rhs[candidate].astype(np.uint16, copy=False)
        lhs_visible = np.empty_like(lhs_pixels)
        rhs_visible = np.empty_like(rhs_pixels)
        lhs_visible[:, :3] = (
            lhs_pixels[:, :3] * lhs_pixels[:, 3:4] + 127
        ) // 255
        rhs_visible[:, :3] = (
            rhs_pixels[:, :3] * rhs_pixels[:, 3:4] + 127
        ) // 255
        lhs_visible[:, 3] = lhs_pixels[:, 3]
        rhs_visible[:, 3] = rhs_pixels[:, 3]
        exact = np.any(lhs_visible != rhs_visible, axis=1)
        exact_count = int(np.count_nonzero(exact))
        if exact_count == 0:
            continue
        changed_xs = xs[exact]
        changed_ys = ys[exact] + top
        count += exact_count
        min_x = min(min_x, int(changed_xs.min()))
        min_y = min(min_y, int(changed_ys.min()))
        max_x = max(max_x, int(changed_xs.max()))
        max_y = max(max_y, int(changed_ys.max()))
        delta = np.abs(
            lhs_visible[exact].astype(np.int16)
            - rhs_visible[exact].astype(np.int16)
        )
        max_abs = max(max_abs, int(delta.max()))
    bbox = [0, 0, 0, 0] if count == 0 else [min_x, min_y, max_x + 1, max_y + 1]
    return {
        "same_size": True,
        "compare_space": HASH_SPACE,
        "meaningful": bool(count),
        "reason": "visible_pixels_changed" if count else "visible_hash_unchanged",
        "count": count,
        "bbox": bbox,
        "max_abs": max_abs,
    }


def record_image(path: str | Path, record_index: int) -> tuple[RgbaImage, list[int]]:
    """見えている記録 1 つを、名前ではなく記録の番号で探して展開する。

    psd_tools の layer.topil() と同じく、色のチャンネルを記録の並び順に使う。
    群・区切り・木に現れない記録は record_not_pixel_visible で断る。
    """
    source = Path(path).resolve()
    psd = open_psd(source)
    index = int(record_index)
    if index < 0 or index >= len(psd.records):
        raise ValueError("record_index_out_of_range")
    mapping, _missing = _visible_mapping(psd)
    target = mapping.get(index)
    if target is None or bool(target.is_group()):
        raise ValueError("record_not_pixel_visible")
    rgba = record_rgba_topil(psd, index)
    if rgba is None:
        raise ValueError("record_pixels_unavailable")
    return RgbaImage(rgba), _record_bbox(psd.records[index])


def record_image_fast(path: str | Path, record_index: int) -> tuple[RgbaImage, list[int]]:
    """Decode one 8-bit RGB raw record without compositing or visible-tree lookup."""
    source = Path(path).resolve()
    psd = open_psd(source)
    return record_image_fast_from_document(psd, record_index)


def record_image_fast_from_document(
    psd: PsdDocument,
    record_index: int,
) -> tuple[RgbaImage, list[int]]:
    """開いてある読み取り専用の PSD から記録 1 つを展開する。

    8 ビット RGB の raw と RLE だけを扱う。ほかの形は理由付きの PsdError（ValueError）で断る。
    """
    rgba, bbox = record_rgba_fast(psd, record_index)
    return RgbaImage(rgba), [int(value) for value in bbox]


def align_record_images(
    before,
    before_bbox,
    after,
    after_bbox,
) -> tuple[RgbaImage, RgbaImage, list[int]]:
    """Place two cropped record images in their shared PSD-coordinate bounds."""
    lhs_bbox = [int(value) for value in list(before_bbox or ())]
    rhs_bbox = [int(value) for value in list(after_bbox or ())]
    if len(lhs_bbox) != 4 or len(rhs_bbox) != 4:
        raise ValueError("record_bounds_invalid")
    union = [
        min(lhs_bbox[0], rhs_bbox[0]),
        min(lhs_bbox[1], rhs_bbox[1]),
        max(lhs_bbox[2], rhs_bbox[2]),
        max(lhs_bbox[3], rhs_bbox[3]),
    ]
    width = int(union[2] - union[0])
    height = int(union[3] - union[1])
    if width <= 0 or height <= 0:
        raise ValueError("record_bounds_empty")

    def positioned(image, bbox: list[int]) -> RgbaImage:
        rgba = _rgba_array(image)
        expected = (int(bbox[2] - bbox[0]), int(bbox[3] - bbox[1]))
        if _image_size(rgba) != expected:
            raise ValueError("record_image_size_mismatch")
        if bbox == union:
            # 置き場所が共通の範囲と同じなら、写さずにそのまま使う（読むだけなので共有してよい）。
            return image if isinstance(image, RgbaImage) else RgbaImage(rgba)
        canvas = np.zeros((height, width, 4), dtype=np.uint8)
        left = int(bbox[0] - union[0])
        top = int(bbox[1] - union[1])
        canvas[top:top + expected[1], left:left + expected[0]] = rgba
        return RgbaImage(canvas)

    return positioned(before, lhs_bbox), positioned(after, rhs_bbox), union

def diff_record(before_path: str | Path, after_path: str | Path, record_index: int) -> dict[str, Any]:
    before, before_bbox = record_image(before_path, record_index)
    after, after_bbox = record_image(after_path, record_index)
    before_compare, after_compare, compare_bbox = align_record_images(
        before,
        before_bbox,
        after,
        after_bbox,
    )
    stats = visible_diff(before_compare, after_compare)
    local = list(stats.get("bbox", (0, 0, 0, 0)))
    if len(local) != 4 or local[2] <= local[0] or local[3] <= local[1]:
        rect_psd = [0, 0, 0, 0]
    else:
        rect_psd = [
            int(compare_bbox[0] + local[0]),
            int(compare_bbox[1] + local[1]),
            int(compare_bbox[0] + local[2]),
            int(compare_bbox[1] + local[3]),
        ]
    return {
        "ok": True,
        "reason": "ok",
        "record_index": int(record_index),
        "record_bbox": compare_bbox,
        "before_bbox": before_bbox,
        "after_bbox": after_bbox,
        "bounds_changed": bool(before_bbox != after_bbox),
        "rect_psd": rect_psd,
        "diff": stats,
    }


def _record_kind(record: LayerRecord, layer: LayerNode | None, section_type: int) -> str:
    if section_type == 3:
        return "DIVIDER"
    if layer is not None:
        if bool(layer.is_group()):
            return "GROUP"
        return str(layer.kind or "UNKNOWN").upper()
    return "RAW"


def _has_mask(record: LayerRecord) -> bool:
    return bool(record.has_mask)


def _raw_payload_signature(psd: PsdDocument, record: LayerRecord) -> list[list[Any]]:
    """層を展開せずに、圧縮されたままのチャンネルのバイトで署名を作る。

    並びは移す前と同じ [id, 圧縮の種類, 記録の長さ, 中身の長さ, sha256]。
    圧縮の種類は psd_tools の str(Compression) に合わせ、raw は空の文字列にする。
    """
    parts: list[list[Any]] = []
    for channel in record.channels:
        payload = psd.channel_payload(channel)
        compression = int(psd.channel_compression(channel))
        parts.append([
            int(channel.id),
            str(compression) if compression else "",
            int(channel.length),
            int(len(payload)),
            hashlib.sha256(payload).hexdigest(),
        ])
    return parts


def scan_document(
    path: str | Path,
    *,
    include_pixels: bool = True,
    include_raw_signatures: bool = True,
) -> dict[str, Any]:
    source = Path(path).resolve()
    psd = open_psd(source)
    visible, depths, missing = psd.visible_layers()
    records = []

    for record in psd.records:
        record_index = int(record.index)
        layer = visible.get(record_index)
        section_type = _section_type(record)
        kind = _record_kind(record, layer, section_type)
        channel_ids = _channel_ids(record)
        entry = {
            "record_index": record_index,
            "marker": marker_for_record(record_index),
            "legacy_name": str(record.name or ""),
            "display_name": _record_name(record),
            "kind": kind,
            "depth": int(depths.get(record_index, 0)),
            "section_type": int(section_type),
            "channel_ids": channel_ids,
            "has_mask": _has_mask(record),
            "bbox": _record_bbox(record),
            "editable": bool(layer is not None and kind == "PIXEL" and section_type == 0),
        }
        if include_raw_signatures and entry["editable"]:
            entry["raw_payload_signature"] = _raw_payload_signature(psd, record)
        if include_pixels and entry["editable"]:
            try:
                rgba = record_rgba_topil(psd, record_index)
            except PsdError as exc:
                # 展開できない形（16 ビット・ZIP など）は例外で止めず、理由を付けて編集の対象から外す。
                entry["editable"] = False
                entry["pixel_reason"] = str(exc)
            else:
                if rgba is None:
                    entry["editable"] = False
                    entry["pixel_reason"] = "topil_unavailable"
                else:
                    image = RgbaImage(rgba)
                    entry["pixel_size"] = [int(image.size[0]), int(image.size[1])]
                    entry["visible_pixel_hash"] = visible_pixel_hash(image)
        records.append(entry)

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "record_index_space": RECORD_INDEX_SPACE,
        "hash_space": HASH_SPACE,
        "canonical": file_fingerprint(source),
        "document": {"width": int(psd.width), "height": int(psd.height)},
        "record_count": int(len(records)),
        "visible_mapping_complete": not missing,
        "visible_mapping_missing": missing,
        "records": records,
    }
    manifest["structural_signature"] = structural_signature(records)
    return validate_manifest(manifest)


def candidate_records(baseline: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    """Return raw records whose compressed payloads need visible decoding."""
    validate_manifest(baseline)
    validate_manifest(current)
    if baseline["structural_signature"] != current["structural_signature"]:
        return {
            "ok": False,
            "reason": "structural_signature_mismatch",
            "candidate_records": [],
        }
    before = {int(item["record_index"]): item for item in baseline["records"]}
    after = {int(item["record_index"]): item for item in current["records"]}
    candidates = []
    for record_index in sorted(before):
        lhs = before[record_index]
        rhs = after[record_index]
        if not bool(lhs.get("editable", False)):
            continue
        if lhs.get("raw_payload_signature") != rhs.get("raw_payload_signature"):
            candidates.append(int(record_index))
    return {"ok": True, "reason": "ok", "candidate_records": candidates}


def compare_manifests(baseline: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    validate_manifest(baseline)
    validate_manifest(current)
    if baseline["structural_signature"] != current["structural_signature"]:
        return {
            "ok": False,
            "reason": "structural_signature_mismatch",
            "changed_records": [],
        }
    before = {int(item["record_index"]): item for item in baseline["records"]}
    after = {int(item["record_index"]): item for item in current["records"]}
    changed = []
    for record_index in sorted(before):
        lhs = str(before[record_index].get("visible_pixel_hash", ""))
        rhs = str(after[record_index].get("visible_pixel_hash", ""))
        if lhs and rhs and lhs != rhs:
            changed.append(int(record_index))
    return {"ok": True, "reason": "ok", "changed_records": changed}
