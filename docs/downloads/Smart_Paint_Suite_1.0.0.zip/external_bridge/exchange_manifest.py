# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Manifest schema and atomic persistence for the T5.1 CSP prototype."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Iterable


SCHEMA_VERSION = 2
HASH_SPACE = "premultiplied_rgba_u8"
RECORD_INDEX_SPACE = "raw_layer_records_0_based"
MARKER_PREFIX = "SPSREC_"
MARKER_SEPARATOR = " | "


class ManifestError(ValueError):
    """Raised when an exchange manifest violates the public schema."""


def marker_for_record(record_index: int) -> str:
    index = int(record_index)
    if index < 0 or index > 99999:
        raise ManifestError("record_index_out_of_range")
    return f"SPSREC_{index:05d}"


def marked_display_name(record_index: int, display_name: str) -> str:
    """Return the CSP-visible name carrying the exact raw-record identity."""
    return f"{marker_for_record(record_index)}{MARKER_SEPARATOR}{str(display_name)}"


def marker_from_display_name(value: Any) -> str | None:
    """Parse only the exact marker prefix written by :func:`marked_display_name`."""
    text = str(value or "")
    marker_length = len(MARKER_PREFIX) + 5
    if len(text) < marker_length + len(MARKER_SEPARATOR):
        return None
    marker = text[:marker_length]
    if not marker.startswith(MARKER_PREFIX):
        return None
    digits = marker[len(MARKER_PREFIX):]
    if not digits.isdigit():
        return None
    if text[marker_length:marker_length + len(MARKER_SEPARATOR)] != MARKER_SEPARATOR:
        return None
    try:
        expected = marker_for_record(int(digits))
    except ManifestError:
        return None
    return marker if marker == expected else None


def file_fingerprint(path: str | Path) -> dict[str, Any]:
    source = Path(path).resolve()
    stat = source.stat()
    digest = hashlib.sha256()
    with source.open("rb") as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    sha256 = digest.hexdigest()
    return {
        "path": str(source),
        "size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
        "sha256": sha256,
        "generation": f"{int(stat.st_size)}:{int(stat.st_mtime_ns)}:{sha256}",
    }


def structural_signature(records: Iterable[dict[str, Any]]) -> str:
    normalized = []
    for item in records:
        normalized.append({
            "record_index": int(item["record_index"]),
            "kind": str(item.get("kind", "")),
            "depth": int(item.get("depth", 0)),
            "section_type": int(item.get("section_type", 0)),
            "channel_ids": [int(value) for value in item.get("channel_ids", ())],
            "has_mask": bool(item.get("has_mask", False)),
            "bbox": [int(value) for value in item.get("bbox", (0, 0, 0, 0))],
        })
    encoded = json.dumps(
        normalized,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("ascii")
    return hashlib.sha256(encoded).hexdigest()


def validate_manifest(value: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ManifestError("manifest_not_object")
    if int(value.get("schema_version", -1)) != SCHEMA_VERSION:
        raise ManifestError("unsupported_schema_version")
    if str(value.get("record_index_space", "")) != RECORD_INDEX_SPACE:
        raise ManifestError("invalid_record_index_space")
    if str(value.get("hash_space", "")) != HASH_SPACE:
        raise ManifestError("invalid_hash_space")
    canonical = value.get("canonical")
    if not isinstance(canonical, dict) or not str(canonical.get("generation", "")):
        raise ManifestError("canonical_generation_missing")
    records = value.get("records")
    if not isinstance(records, list) or not records:
        raise ManifestError("records_missing")
    indices = []
    for item in records:
        if not isinstance(item, dict):
            raise ManifestError("record_not_object")
        record_index = int(item.get("record_index", -1))
        if record_index < 0:
            raise ManifestError("record_index_invalid")
        if str(item.get("marker", "")) != marker_for_record(record_index):
            raise ManifestError("record_marker_invalid")
        indices.append(record_index)
    if indices != sorted(indices) or len(indices) != len(set(indices)):
        raise ManifestError("record_indices_not_unique_sorted")
    expected = structural_signature(records)
    if str(value.get("structural_signature", "")) != expected:
        raise ManifestError("structural_signature_mismatch")
    return value


def atomic_write_json(path: str | Path, value: dict[str, Any]) -> None:
    validate_manifest(value)
    destination = Path(path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    handle, temp_name = tempfile.mkstemp(
        prefix=destination.name + ".",
        suffix=".tmp",
        dir=str(destination.parent),
    )
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, destination)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def read_manifest(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return validate_manifest(json.load(handle))
