# SPDX-License-Identifier: GPL-3.0-or-later
"""Validate an external document before refreshing its master image or editor."""

__all__ = ("validate_and_refresh_master",)


def validate_and_refresh_master(material, channel: str = "BASE_COLOR", *,
                                reason: str = "save", write_master: bool = False) -> bool:
    from . import bodypaint_core as document

    prepared = document.ensure_source_psd_stack_loaded(material, channel)
    if not prepared:
        return False
    if write_master:
        return document.write_composite_to_master(material, channel, force=True) is not None
    read_only = dict(commit_pending=False, commit_untracked=False,
                     force_recompose=False, switch_to_paint=False)
    return document.ensure_layer_stack_display_matches(material, channel, None, **read_only) is not None
