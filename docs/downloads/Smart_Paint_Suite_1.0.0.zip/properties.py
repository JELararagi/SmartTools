# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import json
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)

from .constants import (
    ADDON_ID,
    ADDON_NAME,
    BLEND_MODE_ITEMS,
    CHANNEL_ITEMS,
    DEFAULT_BAKE_MARGIN,
    DEFAULT_CHANNEL_ORDER,
    DEFAULT_COLOR_ATTRIBUTE_NAME,
    DEFAULT_EMISSION_COLOR,
    DEFAULT_FILL_COLOR,
    DEFAULT_UV_NAME,
    DEFAULT_VERTEX_COLOR_NAME,
    EXPORT_FORMAT_ITEMS,
    IMPORT_MODE_ITEMS,
    LAYER_KIND_ITEMS,
    ADJUSTMENT_TYPE_ITEMS,
    MASK_CHANNEL_ITEMS,
    MASK_MODE_ITEMS,
    MESH_MAP_ITEMS,
    PACKED_LAYOUT_ITEMS,
    PROJECTION_ITEMS,
    RESOLUTION_ITEMS,
    VECTOR_SHAPE_ITEMS,
    bi,
)


_SPS_USERPREF_SAVE_TIMER_REGISTERED = False
_SPS_LAYER_REBUILD_SUSPENDED = False
_SPS_LAYER_REBUILD_FORCE_SYNC = False
_SPS_ACTIVE_LAYER_UPDATE_STATE = {}


def _sps_lightweight_runtime_enabled() -> bool:
    """The Extension ships one authoritative lightweight runtime."""
    return True


def _sps_debug_trace(label: str, **payload) -> None:
    """Compatibility no-op: normal UI callbacks never perform disk logging."""
    del label, payload
    return None


def suspend_layer_rebuilds(flag: bool = True):
    global _SPS_LAYER_REBUILD_SUSPENDED
    old = _SPS_LAYER_REBUILD_SUSPENDED
    _SPS_LAYER_REBUILD_SUSPENDED = bool(flag)
    return old


def _save_user_preferences_now(_self=None, _context=None):
    try:
        from . import common as _sps_common
        _sps_common.request_persistent_settings_save(_context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass
    return None


def _persistent_restore_active() -> bool:
    try:
        from . import common as _sps_common
        return bool(getattr(_sps_common, '_APPLYING_PERSISTENT_SETTINGS', False))
    except Exception:
        return False


def _save_user_preferences_force(_self=None, _context=None):
    try:
        from . import common as _sps_common
        if bool(getattr(_sps_common, '_APPLYING_PERSISTENT_SETTINGS', False)):
            return None
        _sps_common.save_persistent_settings(_context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _update_n_panel_state_save(self, context):
    # The toggle itself must be persisted immediately so the next Blender
    # session knows whether subsequent edits are live-saved or boundary-saved.
    try:
        from . import common as _sps_common
        if not bool(getattr(_sps_common, '_APPLYING_PERSISTENT_SETTINGS', False)):
            _sps_common.commit_state_save_toggle(
                self,
                context or getattr(bpy, 'context', None),
                enabled=bool(getattr(self, 'n_panel_state_save', True)),
            )
    except Exception:
        pass
    return None


def _always_on_runtime_update(self, context):
    if _persistent_restore_active():
        return None
    try:
        from . import suite_features
        suite_features.sync_runtime(context)
    except Exception:
        pass
    return _save_user_preferences_now(self, context)

def _save_user_preferences_soon(_self=None, _context=None):
    global _SPS_USERPREF_SAVE_TIMER_REGISTERED
    # Zero-idle: preference persistence must not leave a delayed timer.  Save the
    # small JSON payload immediately from the explicit property/operator update.
    _SPS_USERPREF_SAVE_TIMER_REGISTERED = False
    _save_user_preferences_now(_self, _context)
    return None


SCENE_SETTINGS_PERSIST_PROPS = (
    'default_image_dir',
    'default_resolution',
    'auto_switch_to_paint',
    'auto_save_after_bake',
    'debug_logging',
    'bake_resolution',
    'bake_margin',
    'bake_samples',
    'selected_bake_map',
    'import_directory',
    'import_mode',
    'import_set_index',
    'projection_image',
    'projection_camera',
    'projection_buffer_image',
    'sprite_sheet_image',
    'projection_nudge_percent',
    'projection_scale_percent',
    'sprite_sheet_columns',
    'sprite_sheet_rows',
    'sprite_sheet_frame',
    'projection_previous_image_name',
    'projection_source_image_name',
    'projection_target_layer_id',
    'projection_target_channel',
    'projection_previous_enabled',
    'projection_previous_mode',
    'projection_previous_layer_kind',
    'vertex_color_attribute_name',
    'create_missing_images_during_validation',
    'auto_repair_paths_during_validation',
    'auto_rebuild_after_changes',
    'auto_pack_images',
    'auto_restore_on_failure',
    'auto_snapshot_major_actions',
    'snapshot_text_name',
    'last_audit_text_name',
    'last_runtime_log_text_name',
    'checker_resolution',
    'checker_size',
    'uv_pack_margin',
    'auto_unwrap_missing_uvs',
    'texel_density_size',
    'measured_texel_density',
    'target_texel_density',
    'export_directory',
    'export_set_name',
    'export_resolution',
    'export_format',
    'consolidate_directory',
    'consolidate_make_relative',
    'packed_export_layout',
    'vector_shape',
    'vector_resolution',
    'vector_color',
    'vector_line_width',
    'vector_softness',
    'vector_padding',
    'vector_repeat',
    'vector_rotation',
    'vector_use_height',
    'vector_height_strength',
    'vector_height_invert',
    'last_imported_set_label',
    'last_import_summary',
    'last_external_edit_image_name',
    'preview_light_energy',
    'height_preview_levels',
    'height_preview_strength',
    'height_preview_midlevel',
    'smart_workflow_profile',
    'smart_resolution',
    'smart_use_float_images',
    'smart_random_seed',
    'smart_bombing_strength',
    'smart_bombing_cell_scale',
    'smart_height_blend_balance',
    'smart_color_attribute_name',
    'smart_source_directory',
    'smart_bridge_directory',
    'smart_prompt',
    'smart_negative_prompt',
    'smart_2d_canvas_resolution',
    'smart_2d_stabilization',
    'smart_2d_gap_close',
    'smart_2d_selection_feather',
    'smart_2d_tone_lpi',
    'smart_2d_tone_angle',
    'smart_2d_timeline_frames',
    'smart_2d_reference_layer_name',
    'smart_2d_palette_name',
    'smart_2d_last_manifest_path',
    'smart_quality_mode',
    'smart_detail_density',
    'smart_mask_edge_softness',
    'smart_live_preflight',
    'smart_ui_compact',
    'smart_ui_icon_mode',
    'smart_icon_scale',
    'smart_show_reference_hints',
    'smart_superior_include_2d',
    'smart_quality_score',
    'smart_quality_grade',
    'smart_last_quality_report',
    'smart_last_quality_report_path',
    'smart_last_report_text_name',
    'smart_last_bridge_path',
    'last_info_message',
)

_SPS_APPLYING_SCENE_SETTINGS = False

_SPS_LAYER_REBUILD_TIMER_REGISTERED = False
_SPS_LAYER_REBUILD_IMPORT_RETRY = 0
_SPS_LAYER_REBUILD_MATERIALS: set[str] = set()
_SPS_LAYER_REBUILD_FORCE: set[str] = set()
_SPS_LAYER_REBUILD_COMMIT: set[str] = set()
_SPS_LAYER_REBUILD_RUNNING = False
_SPS_LAYER_REBUILD_TIMER_FUNC = None


def _find_material_names_for_layer(layer_item) -> list[str]:
    """Resolve only the direct RNA owner; never scan all Blender materials."""
    try:
        owner = getattr(layer_item, 'id_data', None)
        if isinstance(owner, bpy.types.Material):
            return [str(owner.name)]
    except (AttributeError, ReferenceError, TypeError):
        pass
    return []


def _sps_layer_rebuild_delay(force_recompose: bool = False) -> float:
    """Compatibility API. Property callbacks no longer schedule rebuild timers."""
    del force_recompose
    return 0.0


def _sps_layer_rebuild_begin_status() -> None:
    return None


def _sps_layer_rebuild_finish_status() -> None:
    return None


def _sps_layer_rebuild_timer_scope():
    from contextlib import nullcontext
    return nullcontext()


def _material_for_layer_update(layer_item, context=None):
    try:
        owner = getattr(layer_item, 'id_data', None)
        if isinstance(owner, bpy.types.Material):
            return owner
    except (AttributeError, ReferenceError, TypeError):
        pass
    ctx = context or getattr(bpy, 'context', None)
    try:
        obj = getattr(ctx, 'object', None)
        material = getattr(obj, 'active_material', None) if obj is not None else None
        return material if isinstance(material, bpy.types.Material) else None
    except (AttributeError, ReferenceError, TypeError):
        return None


def _mark_layer_metadata_dirty(layer_item=None, context=None, *, reason: str = 'metadata_update') -> None:
    """Small RNA-only update used by normal UI property callbacks.

    It never imports PSD/body-paint engines, allocates pixel arrays, traverses all
    datablocks, starts a timer, or recomposes a document. Explicit Operators own
    those operations and their rollback/Undo boundaries.
    """
    material = _material_for_layer_update(layer_item, context)
    if material is None:
        return
    try:
        settings = getattr(material, 'smart_paint_suite', None)
        channel = str(getattr(settings, 'active_paint_channel', 'BASE_COLOR') or 'BASE_COLOR').upper()
        if channel not in set(DEFAULT_CHANNEL_ORDER):
            channel = 'BASE_COLOR'
        material['sps_layer_stack_dirty_' + channel] = True
        material['sps_deferred_composite_dirty_' + channel] = True
        material['sps_deferred_composite_reason_' + channel] = str(reason or 'metadata_update')[:96]
        material['sps_layer_metadata_generation_' + channel] = int(
            material.get('sps_layer_metadata_generation_' + channel, 0) or 0
        ) + 1
    except (AttributeError, ReferenceError, TypeError, ValueError, RuntimeError):
        return


def _tag_current_paint_areas(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    screen = getattr(ctx, 'screen', None) if ctx is not None else None
    try:
        areas = tuple(getattr(screen, 'areas', ()) or ())
    except (AttributeError, ReferenceError, TypeError):
        areas = ()
    for area in areas:
        try:
            if str(getattr(area, 'type', '') or '') in {'VIEW_3D', 'IMAGE_EDITOR'}:
                area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            continue


def _schedule_layer_stack_rebuild(
    layer_item=None, context=None, *, force_recompose: bool = True, commit_pending: bool = True
):
    """Compatibility shim: record intent only; no timer or synchronous loop."""
    del force_recompose, commit_pending
    _mark_layer_metadata_dirty(layer_item, context, reason='explicit_rebuild_required')
    _tag_current_paint_areas(context)
    return None


def _immediate_material_paint_target_sync(layer_item=None, context=None) -> None:
    """Do not modify Image/node/tool targets from an RNA update callback."""
    _mark_layer_metadata_dirty(layer_item, context, reason='paint_target_sync_required')
    return None


def _sps_layer_update_is_live_syncing(layer, context) -> bool:
    for candidate in (layer, getattr(layer, 'id_data', None)):
        try:
            if candidate is not None and bool(candidate.get('sps_photoshop_live_syncing', False)):
                return True
        except (AttributeError, ReferenceError, TypeError):
            continue
    material = _material_for_layer_update(layer, context)
    try:
        settings = getattr(material, 'smart_paint_suite', None) if material is not None else None
        return bool(settings is not None and settings.get('sps_photoshop_live_syncing', False))
    except (AttributeError, ReferenceError, TypeError):
        return False


def _sps_forward_live_layer_metadata_change(layer, context) -> None:
    """Compatibility hook; metadata transport is explicit-operator only.

    RNA update callbacks never load bridge modules or write session JSON.  The
    connected bridge collects metadata from the next explicit Sync/Save action.
    """
    del layer, context
    return None

def _layer_stack_property_update(self, context):
    """RNA-only dirtiness update; pixel/PSD/bridge work is operator-owned."""
    if _SPS_LAYER_REBUILD_SUSPENDED or _sps_layer_update_is_live_syncing(self, context):
        return None
    try:
        if bool(self.get('sps_layer_stack_bulk_edit_in_progress', False)):
            return None
    except (AttributeError, ReferenceError, TypeError):
        return None
    _mark_layer_metadata_dirty(self, context)
    try:
        self['sps_last_enabled_state'] = bool(getattr(self, 'enabled', True))
    except (AttributeError, ReferenceError, TypeError, RuntimeError):
        pass
    # No module import/lookup, timer, full-stack composition, paint-target write
    # or bridge disk I/O is reachable from this callback.
    _tag_current_paint_areas(context)
    return None

def _adjustment_property_update(self, context):
    """Persist one adjustment edit without rebuilding during PSD bulk import."""
    try:
        if bool(self.get('sps_layer_stack_bulk_edit_in_progress', False)):
            return None
        if bool(self.get('sps_photoshop_live_syncing', False)):
            return None
    except Exception:
        pass
    if _SPS_LAYER_REBUILD_SUSPENDED or _sps_layer_update_is_live_syncing(self, context):
        return None
    return _layer_stack_property_update(self, context)



def _clipping_property_update(self, context):
    """Mark clipping metadata dirty; explicit operations rebuild the document."""
    return _layer_stack_property_update(self, context)


def _group_expanded_ui_update(self, context):
    """UI-only group open/close update.

    Expanding/collapsing a folder does not affect pixels, layer projection, PSD
    content, paint target or material nodes.  Scheduling the full layer-stack
    reload here made group UI operations feel as heavy as visibility toggles.
    """
    try:
        for area in getattr(getattr(context, 'screen', None), 'areas', ()) if context is not None else ():
            if getattr(area, 'type', '') in {'VIEW_3D', 'IMAGE_EDITOR'}:
                area.tag_redraw()
    except Exception:
        pass
    return None


def _sps_preferred_visible_document_image(mat, channel: str = 'BASE_COLOR'):
    if mat is None:
        return None
    ch = str(channel or 'BASE_COLOR').upper()

    def _is_psd_direct(image) -> bool:
        if image is None:
            return False
        try:
            name = str(getattr(image, 'name', '') or '').lower()
            if name.endswith(('.psd', '.psb')):
                return True
        except Exception:
            pass
        try:
            path = str(getattr(image, 'filepath_raw', '') or getattr(image, 'filepath', '') or '').lower()
            if path.endswith(('.psd', '.psb')):
                return True
        except Exception:
            pass
        return False

    def _image_from_prop(key):
        try:
            name = str(mat.get(key + ch, '') or '')
        except Exception:
            name = ''
        return bpy.data.images.get(name) if name else None

    for key in (
        'sps_visible_master_image_',
        'sps_document_target_image_',
        'sps_bodypaint_master_image_',
        'sps_master_texture_image_',
    ):
        img = _image_from_prop(key)
        if img is not None and not _is_psd_direct(img):
            return img
    try:
        mat_name = str(getattr(mat, 'name', '') or '')
        for img in bpy.data.images:
            try:
                if not bool(img.get('smart_paint_suite_visible_document', False)):
                    continue
                if str(img.get('smart_paint_suite_material', '') or '') not in {'', mat_name}:
                    continue
                if not _is_psd_direct(img):
                    return img
            except Exception:
                continue
    except Exception:
        pass
    try:
        for img in bpy.data.images:
            try:
                name = str(getattr(img, 'name', '') or '').lower()
                if 'psd_preview' in name or 'smart_preview' in name:
                    if not _is_psd_direct(img):
                        return img
            except Exception:
                continue
    except Exception:
        pass
    for key in (
        'sps_visible_master_image_',
        'sps_document_target_image_',
        'sps_bodypaint_master_image_',
        'sps_master_texture_image_',
    ):
        img = _image_from_prop(key)
        if img is not None:
            return img
    return None


def _lightweight_ui_layer_index_update(self, context):
    """Route UIList selection through the lightweight activation operator.

    ``active_layer_index`` remains the engine/save authority.  This separate
    UI index exists only because Blender's ``template_list`` requires an RNA
    integer property for row highlighting and selection.
    """
    if not _sps_lightweight_runtime_enabled():
        return None
    try:
        requested = int(getattr(self, 'lightweight_ui_layer_index', 0) or 0)
        current = int(getattr(self, 'active_layer_index', 0) or 0)
        count = len(getattr(self, 'layers', ()) or ())
    except Exception:
        return None
    if count <= 0 or requested == current:
        return None
    requested = max(0, min(requested, count - 1))
    try:
        result = bpy.ops.smart_paint_suite.lightweight_select_layer(layer_index=requested)
        if 'FINISHED' in set(result or ()):
            return None
    except Exception:
        pass
    # A failed activation must not leave the visual list selection detached
    # from the real paint/save target.
    try:
        self.lightweight_ui_layer_index = max(0, min(current, count - 1))
    except Exception:
        pass
    return None


def _active_layer_index_update(self, context):
    """Clamp active-layer metadata only; explicit activation owns Image changes."""
    if _SPS_LAYER_REBUILD_SUSPENDED:
        return None
    try:
        count = len(getattr(self, 'layers', ()) or ())
        requested = int(getattr(self, 'active_layer_index', 0) or 0)
        clamped = max(0, min(requested, count - 1)) if count else 0
        if clamped != requested:
            self.active_layer_index = clamped
            return None
        if int(getattr(self, 'lightweight_ui_layer_index', clamped) or 0) != clamped:
            self.lightweight_ui_layer_index = clamped
    except (AttributeError, ReferenceError, TypeError, ValueError, RuntimeError):
        return None
    material = _material_for_layer_update(self, context)
    if material is not None:
        try:
            layer = self.layers[clamped] if count else None
            layer_id = str(getattr(layer, 'layer_id', '') or '') if layer is not None else ''
            material['sps_lightweight_active_layer_id'] = layer_id
            material['sps_active_layer_index_BASE_COLOR'] = int(clamped)
        except (AttributeError, ReferenceError, TypeError, ValueError, RuntimeError, IndexError):
            pass
    _tag_current_paint_areas(context)
    return None



_POINTER_SCENE_SETTING_TARGETS = {
    "projection_image": "images",
    "projection_buffer_image": "images",
    "sprite_sheet_image": "images",
    "projection_camera": "objects",
}

def _root_addon_preferences(context=None):
    try:
        ctx = context or bpy.context
        wm = getattr(ctx, 'window_manager', None)
        runtime_prefs = getattr(wm, 'smart_paint_suite_runtime_preferences', None) if wm is not None else None
        if runtime_prefs is not None:
            return runtime_prefs
    except Exception:
        pass
    try:
        prefs = getattr(getattr(context or bpy.context, 'preferences', None), 'addons', None)
    except Exception:
        prefs = None
    if prefs is None:
        return None
    candidates = []
    for value in (ADDON_ID, __package__, (__package__.split('.')[0] if __package__ else ''), (__name__.split('.')[0] if __name__ else '')):
        value = str(value or '').strip()
        if value and value not in candidates:
            candidates.append(value)
    for key in candidates:
        try:
            addon = prefs.get(key)
        except Exception:
            addon = None
        if addon is not None:
            return getattr(addon, 'preferences', None)
    return None


def _json_safe_scene_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        if hasattr(value, '__len__') and hasattr(value, '__iter__'):
            return [float(v) if isinstance(v, float) else v for v in value]
    except Exception:
        pass
    return str(value)


def _scene_settings_payload(settings) -> dict:
    payload = {}
    if settings is None:
        return payload
    for prop_name in SCENE_SETTINGS_PERSIST_PROPS:
        try:
            value = getattr(settings, prop_name)
            if prop_name in _POINTER_SCENE_SETTING_TARGETS:
                payload[prop_name] = str(getattr(value, 'name', '') or '') if value is not None else ''
            else:
                payload[prop_name] = _json_safe_scene_value(value)
        except Exception:
            pass
    return payload


def _load_scene_settings_payload(context=None) -> dict:
    prefs = _root_addon_preferences(context)
    text = str(getattr(prefs, 'scene_settings_json', '') or '') if prefs is not None else ''
    if not text:
        return {}
    try:
        data = json.loads(text)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _write_scene_settings_payload(settings, context=None) -> None:
    prefs = _root_addon_preferences(context)
    if prefs is None or settings is None:
        return
    try:
        prefs.scene_settings_json = json.dumps(_scene_settings_payload(settings), ensure_ascii=False, sort_keys=True)
    except Exception:
        return
    _save_user_preferences_soon()


def _apply_scene_settings_payload_to_scene(scene, payload: dict) -> None:
    global _SPS_APPLYING_SCENE_SETTINGS
    if scene is None or not isinstance(payload, dict) or not payload:
        return
    settings = getattr(scene, 'smart_paint_suite', None)
    if settings is None:
        return
    _SPS_APPLYING_SCENE_SETTINGS = True
    try:
        for prop_name in SCENE_SETTINGS_PERSIST_PROPS:
            if prop_name not in payload:
                continue
            try:
                value = payload[prop_name]
                target_collection_name = _POINTER_SCENE_SETTING_TARGETS.get(prop_name)
                if target_collection_name:
                    name = str(value or '').strip()
                    collection = getattr(bpy.data, target_collection_name, None)
                    target = collection.get(name) if collection is not None and name else None
                    setattr(settings, prop_name, target)
                else:
                    setattr(settings, prop_name, value)
            except Exception:
                pass
    finally:
        _SPS_APPLYING_SCENE_SETTINGS = False


def apply_saved_scene_settings(context=None) -> None:
    payload = _load_scene_settings_payload(context)
    if not payload:
        return
    try:
        scenes = list(getattr(bpy.data, 'scenes', ()) or [])
    except Exception:
        scenes = []
    if not scenes:
        scene = getattr(context or bpy.context, 'scene', None)
        scenes = [scene] if scene is not None else []
    for scene in scenes:
        _apply_scene_settings_payload_to_scene(scene, payload)


def _sync_scene_settings_to_other_scenes(source_scene, context=None) -> None:
    payload = _load_scene_settings_payload(context)
    if not payload:
        return
    try:
        scenes = list(getattr(bpy.data, 'scenes', ()) or [])
    except Exception:
        scenes = []
    for scene in scenes:
        if scene is source_scene:
            continue
        _apply_scene_settings_payload_to_scene(scene, payload)


def _scene_settings_update(self, context):
    if _SPS_APPLYING_SCENE_SETTINGS:
        return None
    if _sps_lightweight_runtime_enabled():
        try:
            from . import common as _sps_common
            if not bool(getattr(_sps_common, '_APPLYING_PERSISTENT_SETTINGS', False)):
                _sps_common.request_persistent_settings_save(context, force=False)
        except Exception:
            pass
        return None
    _write_scene_settings_payload(self, context=context)
    try:
        _sync_scene_settings_to_other_scenes(getattr(context, 'scene', None), context=context)
    except Exception:
        pass
    return None


@persistent
def _sps_scene_settings_load_post(_dummy):
    apply_saved_scene_settings(getattr(bpy, 'context', None))


def _register_scene_settings_persistence():
    # Idle-zero build: do not append load_post handlers or apply saved scene
    # settings at add-on enable. Scene/Material RNA properties are already stored
    # in the .blend. Expensive cross-scene synchronization should happen only
    # from explicit user actions, not merely because the add-on is installed.
    return None

def _unregister_scene_settings_persistence():
    try:
        handlers = bpy.app.handlers.load_post
        while _sps_scene_settings_load_post in handlers:
            handlers.remove(_sps_scene_settings_load_post)
    except Exception:
        pass


def _tool_is_loaded(alias: str) -> bool:
    try:
        from . import loader
        record = loader.get_record(alias)
        return bool(record is not None and str(record.get('status') or '') == 'loaded')
    except Exception:
        return False


def _update_sidebar_category(self, context):
    if _persistent_restore_active():
        return None
    _save_user_preferences_soon()
    return None



def _brushstroke_resource_path_update(self, context):
    if _persistent_restore_active():
        return None
    _save_user_preferences_soon()
    if not _tool_is_loaded('brushstroke_tools'):
        return None
    try:
        from .brushstroke_tools.preferences import update_resource_path as _update
    except Exception:
        return None
    try:
        return _update(self, context)
    except Exception:
        return None


def _grease_pencil_update_panel(self, context):
    if _persistent_restore_active():
        return None
    _save_user_preferences_soon()
    if not _tool_is_loaded('grease_pencil_tools'):
        return None
    try:
        from .grease_pencil_tools.preferences import update_panel as _update
    except Exception:
        return None
    try:
        return _update(self, context)
    except Exception:
        return None


def _grease_pencil_auto_rebind(self, context):
    # Keymaps must never be registered automatically by Smart Paint Suite.
    # Keep the preferences saved for display/manual-reference purposes only.
    if _persistent_restore_active():
        return None
    del context
    _save_user_preferences_soon()
    return None


def _textures_autosave_timer_update(self, context):
    if _persistent_restore_active():
        return None
    _save_user_preferences_soon()
    if not _tool_is_loaded('textures_autosave'):
        return None
    try:
        from .textures_autosave import textures_autosave_timer_update as _update
    except Exception:
        return None
    try:
        return _update(self, context)
    except Exception:
        return None


def _textures_autosave_handler_update(self, context):
    if _persistent_restore_active():
        return None
    _save_user_preferences_soon()
    if not _tool_is_loaded('textures_autosave'):
        return None
    try:
        from .textures_autosave import textures_autosave_handler_update as _update
    except Exception:
        return None
    try:
        return _update(self, context)
    except Exception:
        return None


def _ucupaint_icons_update(self, context):
    if _persistent_restore_active():
        return
    _save_user_preferences_soon()
    screen = getattr(context, 'screen', None)
    if screen is None or not _tool_is_loaded('ucupaint'):
        return
    for area in tuple(screen.areas):
        try:
            area.tag_redraw()
        except ReferenceError:
            # A layout switch can invalidate an area between the snapshot and redraw.
            continue


class SPSBrushstrokeStyleItem(bpy.types.PropertyGroup):
    name: StringProperty(name=bi('Style Name', 'スタイル名'), default='', update=_save_user_preferences_soon)
    id_name: StringProperty(name=bi('Style ID', 'スタイル ID'), default='', update=_save_user_preferences_soon)
    filepath: StringProperty(name=bi('File Path', 'ファイルパス'), default='', update=_save_user_preferences_soon)
    category: StringProperty(name=bi('Category', 'カテゴリ'), default='', update=_save_user_preferences_soon)
    type: StringProperty(name=bi('Type', 'タイプ'), default='', update=_save_user_preferences_soon)


class SPSBrushstrokeToolPreferences(bpy.types.PropertyGroup):
    resource_path: StringProperty(
        name=bi('Resource Directory', 'リソースディレクトリ'),
        description=bi(
            'Directory that stores the Brushstroke Tools resource library and optional style packs. Leave it empty to use the managed extension user_default resource folder, where bundled resources are copied automatically when needed.',
            'ブラシストロークツールのリソースライブラリと追加スタイルパックを保存するフォルダーです。空欄のままなら拡張機能のリソースフォルダーを使い、必要に応じて同梱リソースを自動でコピーします。',
        ),
        subtype='DIR_PATH',
        default='',
        update=_brushstroke_resource_path_update,
    )
    import_relative_path: BoolProperty(
        name=bi('Relative Path', '相対パス'),
        description=bi(
            'When brushstroke assets are linked from the resource library, store the link path relative to the current .blend file whenever possible.',
            'ブラシストロークアセットをライブラリからリンクするとき、可能なら現在の .blend に対する相対パスで保存します。',
        ),
        default=True,
        update=_save_user_preferences_soon,
    )
    import_method: EnumProperty(
        name=bi('Import Method', '読み込み方法'),
        description=bi(
            'Choose whether Brushstroke Tools should append local copies of assets or keep them linked to the resource library.',
            'ブラシストロークツールのアセットをローカルコピーとして追加するか、リソースライブラリへリンクしたまま使うかを選びます。',
        ),
        items=(
            ('APPEND', 'Append', bi('Append the required data-blocks and keep image data local to this file.', '必要なデータブロックを追加し、画像データを現在のファイル側へ持ち込みます。')),
            ('LINK', 'Link', bi('Link the required data-blocks from the shared Brushstroke library.', '必要なデータブロックを共有 Brushstroke ライブラリからリンクします。')),
        ),
        default='APPEND',
        update=_save_user_preferences_soon,
    )
    brush_styles: CollectionProperty(type=SPSBrushstrokeStyleItem)
    active_brush_style_index: IntProperty(default=0, update=_save_user_preferences_soon)
    background_services_enabled: BoolProperty(
        name=bi('Background Services', 'バックグラウンドサービス'),
        description=bi('Keep live Brushstroke context synchronization callbacks active.', 'Brushstroke のライブ同期コールバックを有効なまま維持します。'),
        default=False,
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )


class SPSGreasePencilTimelineSettings(bpy.types.PropertyGroup):
    keycode: StringProperty(
        name=bi('Shortcut', 'ショートカット'),
        description=bi('Shortcut used to start timeline scrubbing from the viewport.', 'ビューポートからタイムラインスクラブを開始するショートカットです。'),
        default='MIDDLEMOUSE',
        update=_save_user_preferences_soon,
    )
    always_snap: BoolProperty(
        name=bi('Always Snap', '常にスナップ'),
        description=bi('Always snap to keyframes when possible. Use the alternate modifier to temporarily disable snapping.', '可能なときは常にキーフレームへスナップします。補助キーで一時的にスナップを外せます。'),
        default=False,
        update=_save_user_preferences_soon,
    )
    rolling_mode: BoolProperty(
        name=bi('Rolling Mode', 'ローリングモード'),
        description=bi('Use a gap-less flipbook style scrub mode that always snaps through available keys.', '利用可能なキーを常に順送りする、隙間なしのフリップブック式スクラブを使います。'),
        default=False,
        update=_save_user_preferences_soon,
    )
    use: BoolProperty(
        name=bi('Enable', '有効'),
        description=bi('Enable the viewport timeline scrub helper.', 'ビューポート用タイムラインスクラブ補助を有効にします。'),
        default=False,
        update=_grease_pencil_auto_rebind,
    )
    use_in_timeline_editor: BoolProperty(
        name=bi('Shortcut in timeline editors', 'タイムライン系エディターでも使う'),
        description=bi('Use the same scrub shortcut inside the Dope Sheet, Graph Editor, NLA, and Sequencer where supported.', '対応している場合は、ドープシート、グラフエディター、NLA、シーケンサーでも同じスクラブショートカットを使います。'),
        default=False,
        update=_grease_pencil_auto_rebind,
    )
    use_shift: BoolProperty(name=bi('Combine With Shift', 'Shift を組み合わせる'), description=bi('Require Shift for this shortcut.', 'このショートカットに Shift を必須にします。'), default=False, update=_grease_pencil_auto_rebind)
    use_alt: BoolProperty(name=bi('Combine With Alt', 'Alt を組み合わせる'), description=bi('Require Alt for this shortcut.', 'このショートカットに Alt を必須にします。'), default=True, update=_grease_pencil_auto_rebind)
    use_ctrl: BoolProperty(name=bi('Combine With Ctrl', 'Ctrl を組み合わせる'), description=bi('Require Ctrl for this shortcut.', 'このショートカットに Ctrl を必須にします。'), default=False, update=_grease_pencil_auto_rebind)
    evaluate_gp_obj_key: BoolProperty(
        name=bi('Use Grease Pencil Object Keyframes', 'Grease Pencil オブジェクトのキーフレームも使う'),
        description=bi('Also consider Grease Pencil object keyframes when snapping, not just the active layer frames.', 'スナップ時にアクティブレイヤーのフレームだけでなく、グリースペンシルオブジェクトのキーフレームも対象にします。'),
        default=True,
        update=_save_user_preferences_soon,
    )
    pixel_step: IntProperty(
        name=bi('Frame Interval On Screen', '画面上のフレーム間隔'),
        description=bi('Screen-space pixel distance that represents one frame while scrubbing.', 'スクラブ中に 1 フレームとして扱う画面上のピクセル間隔です。'),
        default=10,
        min=1,
        max=500,
        soft_min=2,
        soft_max=100,
        subtype='PIXEL',
        update=_save_user_preferences_soon,
    )
    use_hud: BoolProperty(name=bi('Display Timeline Overlay', 'タイムラインオーバーレイを表示'), description=bi('Show overlay information while timeline scrubbing is active.', 'タイムラインスクラブ中にオーバーレイ情報を表示します。'), default=True, update=_save_user_preferences_soon)
    use_hud_time_line: BoolProperty(name=bi('Timeline', 'タイムライン'), description=bi('Show the temporary timeline guide.', '一時的なタイムラインガイドを表示します。'), default=True, update=_save_user_preferences_soon)
    use_hud_keyframes: BoolProperty(name=bi('Keyframes', 'キーフレーム'), description=bi('Show keyframe markers in the overlay.', 'オーバーレイ内にキーフレームマーカーを表示します。'), default=True, update=_save_user_preferences_soon)
    use_hud_playhead: BoolProperty(name=bi('Playhead', '再生ヘッド'), description=bi('Show the playhead line in the overlay.', 'オーバーレイ内に再生ヘッド線を表示します。'), default=True, update=_save_user_preferences_soon)
    use_hud_frame_current: BoolProperty(name=bi('Text Frame Current', '現在フレーム文字'), description=bi('Show the current frame number as text.', '現在のフレーム番号を文字で表示します。'), default=True, update=_save_user_preferences_soon)
    use_hud_frame_offset: BoolProperty(name=bi('Text Frame Offset', 'オフセット文字'), description=bi('Show the frame offset from the starting point as text.', '開始位置からのフレーム差分を文字で表示します。'), default=True, update=_save_user_preferences_soon)
    color_timeline: FloatVectorProperty(name=bi('Timeline Color', 'タイムライン色'), description=bi('Color used for the temporary timeline overlay.', '一時的なタイムラインオーバーレイに使う色です。'), subtype='COLOR_GAMMA', size=4, default=(0.5, 0.5, 0.5, 0.6), min=0.0, max=1.0, update=_save_user_preferences_soon)
    color_playhead: FloatVectorProperty(name=bi('Cursor Color', 'カーソル色'), description=bi('Color used for the scrub cursor line and related text.', 'スクラブ用カーソル線と関連テキストに使う色です。'), subtype='COLOR_GAMMA', size=4, default=(0.01, 0.64, 1.0, 0.8), min=0.0, max=1.0, update=_save_user_preferences_soon)
    playhead_size: IntProperty(name=bi('Playhead Size', '再生ヘッドサイズ'), description=bi('Height of the playhead line in pixels.', '再生ヘッド線の高さをピクセルで指定します。'), default=100, min=2, max=10000, soft_min=10, soft_max=5000, subtype='PIXEL', update=_save_user_preferences_soon)
    lines_size: IntProperty(name=bi('Frame Lines Size', 'フレーム線サイズ'), description=bi('Height of the timeline frame marks in pixels.', 'タイムラインのフレーム目盛り高さをピクセルで指定します。'), default=10, min=1, max=10000, soft_min=5, soft_max=40, subtype='PIXEL', update=_save_user_preferences_soon)
    keyframe_aspect: EnumProperty(
        name=bi('Keyframe Display', 'キーフレーム表示'),
        description=bi('Choose how keyframes are drawn in the overlay.', 'オーバーレイ上でのキーフレーム表示方法を選びます。'),
        items=(
            ('LINE', 'Line', bi('Display keyframes as thick lines.', 'キーフレームを太線で表示します。')),
            ('SQUARE', 'Square', bi('Display keyframes as squares.', 'キーフレームを四角で表示します。')),
            ('DIAMOND', 'Diamond', bi('Display keyframes as diamonds.', 'キーフレームをひし形で表示します。')),
        ),
        default='LINE',
        update=_save_user_preferences_soon,
    )
    hide_overlays: BoolProperty(name=bi('Hide Overlays', 'オーバーレイを隠す'), description=bi('Hide viewport overlays and gizmos while scrubbing is active.', 'スクラブ中にビューポートオーバーレイとギズモを隠します。'), default=False, update=_save_user_preferences_soon)


class SPSGreasePencilLayerNavigatorSettings(bpy.types.PropertyGroup):
    box_height: IntProperty(
        name=bi('Layer Box Height', 'レイヤーボックス高さ'),
        description=bi('Height of each layer entry box. Larger values are easier to click but use more screen space.', '各レイヤー項目ボックスの高さです。大きいほどクリックしやすくなりますが、画面スペースを多く使います。'),
        default=30,
        min=10,
        max=200,
        soft_min=26,
        soft_max=120,
        subtype='PIXEL',
        update=_save_user_preferences_soon,
    )
    box_width: IntProperty(
        name=bi('Layer Box Width', 'レイヤーボックス幅'),
        description=bi('Width of each layer entry box. Larger values make long names easier to read.', '各レイヤー項目ボックスの幅です。大きいほど長いレイヤー名を読みやすくなります。'),
        default=250,
        min=120,
        max=500,
        soft_min=150,
        soft_max=350,
        subtype='PIXEL',
        update=_save_user_preferences_soon,
    )
    text_size: IntProperty(
        name=bi('Label Size', 'ラベルサイズ'),
        description=bi('Font size used for layer names in the navigator overlay.', 'ナビゲーターオーバーレイ内のレイヤー名に使う文字サイズです。'),
        default=12,
        min=4,
        max=40,
        soft_min=8,
        soft_max=20,
        subtype='PIXEL',
        update=_save_user_preferences_soon,
    )
    left_handed: BoolProperty(
        name=bi('Left Handed', '左利き配置'),
        description=bi('Offset the popup to the right side of the pointer to reduce hand occlusion while drawing with the left hand.', '左手で描いているときに手で隠れにくいよう、ポップアップをポインター右側へずらして表示します。'),
        default=False,
        update=_save_user_preferences_soon,
    )


class SPSGreasePencilToolPreferences(bpy.types.PropertyGroup):
    ts: PointerProperty(type=SPSGreasePencilTimelineSettings)
    nav: PointerProperty(type=SPSGreasePencilLayerNavigatorSettings)
    category: StringProperty(
        name=bi('Category', 'カテゴリ'),
        description=bi('Name of the legacy Grease Pencil sidebar category. This is kept for compatibility with the original tool package.', '旧グリースペンシルのサイドバーカテゴリ名です。互換のために維持されています。'),
        default='Grease Pencil',
        update=_grease_pencil_update_panel,
    )
    pref_tab: EnumProperty(
        name=bi('Preference Tool Tab', '設定タブ'),
        description=bi('Choose which Grease Pencil tool settings are shown in this settings section.', 'この設定セクションで表示するグリースペンシルツール設定を選びます。'),
        default='canvas_rotate',
        items=(
            ('canvas_rotate', 'Rotate Canvas', bi('Canvas Rotate tool shortcut and related settings.', 'キャンバス回転ツールのショートカットと関連設定です。')),
            ('box_deform', 'Box Deform', bi('Box Deform tool settings.', 'ボックス変形ツールの設定です。')),
            ('timeline_scrub', 'Timeline Scrub', bi('Timeline Scrub shortcut and overlay settings.', 'タイムラインスクラブのショートカットとオーバーレイ設定です。')),
            ('layer_navigator', 'Layer Navigator', bi('Layer Navigator overlay settings.', 'レイヤーナビゲーターのオーバーレイ設定です。')),
        ),
        update=_save_user_preferences_soon,
    )
    use_clic_drag: BoolProperty(name=bi('Use click drag directly on points', '点を直接ドラッグする'), description=bi('Temporarily switch to the tweak-style interaction so Box Deform points can be dragged directly.', 'ボックス変形の点を直接ドラッグできるよう、一時的に微調整の操作へ切り替えます。'), default=True, update=_save_user_preferences_soon)
    default_deform_type: EnumProperty(
        name=bi('Starting Interpolation', '開始時補間'),
        description=bi('Choose the default interpolation used when Box Deform starts.', 'ボックス変形の開始時に使う既定の補間方法を選びます。'),
        items=(
            ('KEY_LINEAR', 'Linear (perspective mode)', bi('Linear interpolation similar to corner or perspective style deformations.', 'コーナー変形や遠近変形に近い線形補間です。')),
            ('KEY_BSPLINE', 'Spline (smooth deform)', bi('Spline interpolation for smoother deformations, especially with more subdivisions.', '分割数が多い場合に滑らかな変形を作りやすいスプライン補間です。')),
        ),
        default='KEY_LINEAR',
        update=_save_user_preferences_soon,
    )
    auto_swap_deform_type: BoolProperty(name=bi('Auto swap interpolation mode', '補間を自動切替'), description=bi('Automatically switch Box Deform interpolation based on subdivision state until you override it manually.', '手動で上書きするまでは、分割状態に応じてボックス変形の補間方式を自動で切り替えます。'), default=True, update=_save_user_preferences_soon)
    canvas_use_hud: BoolProperty(name=bi('Use HUD', 'HUD を使う'), description=bi('Display angle guides and angle text while rotating the canvas.', 'キャンバス回転中に角度ガイド線と角度表示を出します。'), default=False, update=_save_user_preferences_soon)
    canvas_use_view_center: BoolProperty(name=bi('Rotate From View Center In Camera', 'カメラ時はビュー中心で回転'), description=bi('When in camera view, rotate from the viewport center instead of the camera center.', 'カメラビュー時に、カメラ中心ではなくビューポート中心を基準に回転します。'), default=True, update=_save_user_preferences_soon)
    canvas_use_shortcut: BoolProperty(name=bi('Show Shortcut Reference', 'ショートカット参照を表示'), description=bi('Shows manual shortcut reference settings only. Smart Paint Suite does not register this keymap automatically.', '手動ショートカット参照用の設定です。Smart Paint はこのキーマップを自動登録しません。'), default=False, update=_grease_pencil_auto_rebind)
    mouse_click: EnumProperty(
        name=bi('Mouse button', 'マウスボタン'),
        description=bi('Mouse button used together with the selected modifiers for canvas rotation.', '選択した修飾キーと組み合わせてキャンバス回転に使うマウスボタンです。'),
        default='MIDDLEMOUSE',
        items=(
            ('RIGHTMOUSE', 'Right click', bi('Use the right mouse button.', '右マウスボタンを使います。')),
            ('LEFTMOUSE', 'Left click', bi('Use the left mouse button.', '左マウスボタンを使います。')),
            ('MIDDLEMOUSE', 'Mid click', bi('Use the middle mouse button.', '中マウスボタンを使います。')),
            ('BUTTON4MOUSE', 'Mouse Button 4', bi('Use mouse button 4 (usually Back).', 'マウスボタン4（通常は戻る）を使います。')),
            ('BUTTON5MOUSE', 'Mouse Button 5', bi('Use mouse button 5 (usually Forward).', 'マウスボタン5（通常は進む）を使います。')),
        ),
        update=_grease_pencil_auto_rebind,
    )
    use_shift: BoolProperty(name=bi('Combine With Shift', 'Shift を組み合わせる'), description=bi('Require Shift for canvas rotation.', 'キャンバス回転に Shift を必須にします。'), default=False, update=_grease_pencil_auto_rebind)
    use_alt: BoolProperty(name=bi('Combine With Alt', 'Alt を組み合わせる'), description=bi('Require Alt for canvas rotation.', 'キャンバス回転に Alt を必須にします。'), default=True, update=_grease_pencil_auto_rebind)
    use_ctrl: BoolProperty(name=bi('Combine With Ctrl', 'Ctrl を組み合わせる'), description=bi('Require Ctrl for canvas rotation.', 'キャンバス回転に Ctrl を必須にします。'), default=True, update=_grease_pencil_auto_rebind)
    use_oskey: BoolProperty(name=bi('Combine With OS Key', 'OS キーを組み合わせる'), description=bi('Require the operating-system modifier key such as Win, Super, or Cmd.', 'Win、Super、Cmd などの OS 修飾キーを必須にします。'), default=False, update=_grease_pencil_auto_rebind)
    rc_angle_step: FloatProperty(name=bi('Angle Steps', '角度ステップ'), description=bi('Angle used for stepped canvas rotation when the alternate snap modifier is pressed.', '代替スナップ修飾キーを押しているときに使う段階回転の角度です。'), default=0.2617993877991494, min=0.01745329238474369, max=3.1415927410125732, soft_min=0.01745329238474369, soft_max=1.5707963705062866, step=10, precision=1, subtype='ANGLE', unit='ROTATION', update=_save_user_preferences_soon)


class SPSPaintSystemToolPreferences(bpy.types.PropertyGroup):
    background_services_enabled: BoolProperty(name=bi('Background Services', 'バックグラウンドサービス'), description=bi('Keep Paint System background callbacks active.', 'Paint System のバックグラウンドコールバックを有効に保ちます。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    show_tooltips: BoolProperty(name=bi('Show Tooltips', 'ツールチップを表示'), description=bi('Show helper tooltips in the Paint System UI.', 'Paint System UI 内で補助ツールチップを表示します。'), default=True, update=_save_user_preferences_soon)
    show_hex_color: BoolProperty(name=bi('Show Hex Color', 'Hex 色を表示'), description=bi('Show the hexadecimal color field in color settings.', '色設定内に 16 進カラー欄を表示します。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    show_more_color_picker_settings: BoolProperty(name=bi('Show More Color Picker Settings', 'カラーピッカー詳細を表示'), description=bi('Show more color picker controls.', 'カラーピッカーの詳細設定を表示します。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    use_compact_design: BoolProperty(name=bi('Use Compact Design', 'コンパクト表示を使う'), description=bi('Use a denser Paint System layout that saves screen space.', '画面スペースを節約する密度の高いレイアウトを使います。'), default=False, update=_save_user_preferences_soon)
    color_picker_scale: FloatProperty(name=bi('Color Picker Scale', 'カラーピッカー倍率'), description=bi('Scale the main color picker.', 'メインのカラーピッカー倍率です。'), default=1.0, min=0.5, max=3.0, options={'HIDDEN'}, update=_save_user_preferences_soon)
    preferred_coord_type: EnumProperty(name=bi('Preferred Coordinate Type', '優先座標タイプ'), description=bi('Preferred coordinate type used by Paint System tools.', 'ツールで優先する座標タイプです。'), items=(('AUTO', 'Auto UV', ''), ('UV', 'UV', ''), ('UNDETECTED', 'Undetected', '')), default='UNDETECTED', options={'HIDDEN'}, update=_save_user_preferences_soon)
    color_picker_scale_rmb: FloatProperty(name=bi('RMB Color Wheel Scale', '右クリックカラーホイール倍率'), description=bi('Scale the color wheel shown in the Texture Paint right-click popover.', "テクスチャペイントの右クリックポップオーバー内に出るカラーホイール倍率です。"), default=1.2, min=0.5, max=3.0, update=_save_user_preferences_soon)
    hide_norm_paint_tips: BoolProperty(name=bi('Hide Normal Painting Tips', '法線ペイントのヒントを隠す'), description=bi('Hide the normal painting tip hints.', '法線ペイントのヒント表示を隠します。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    hide_color_attr_tips: BoolProperty(name=bi('Hide Color Attribute Tips', 'カラー属性のヒントを隠す'), description=bi('Hide the color attribute tip hints.', 'カラー属性のヒント表示を隠します。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    use_legacy_ui: BoolProperty(name=bi('Use Legacy UI', '旧 UI を使う'), description=bi('Use the older Paint System interface style.', '以前のインターフェース表示を使います。'), default=False, update=_save_user_preferences_soon)
    show_hsv_sliders_rmb: BoolProperty(name=bi('Show Hue/Saturation/Value sliders (RMB)', '右クリックで HSV スライダーを表示'), description=bi('Show HSV sliders under the color wheel in the Texture Paint right-click popover.', "テクスチャペイントの右クリックポップオーバーで、カラーホイール下に HSV スライダーを表示します。"), default=True, update=_save_user_preferences_soon)
    show_active_palette_rmb: BoolProperty(name=bi('Show Active Palette (RMB)', '右クリックでアクティブパレットを表示'), description=bi('Show the active palette swatches in the right-click popover.', '右クリックポップオーバーにアクティブパレットのスウォッチを表示します。'), default=True, options={'HIDDEN'}, update=_save_user_preferences_soon)
    show_brush_settings_rmb: BoolProperty(name=bi('Show Brush Controls (RMB)', '右クリックでブラシ制御を表示'), description=bi('Show brush radius and strength controls in the right-click popover.', '右クリックポップオーバーにブラシ半径と強さの制御を表示します。'), default=True, update=_save_user_preferences_soon)
    loading_donations: BoolProperty(name=bi('Loading Donations', '寄付情報読込中'), description=bi('Internal loading flag for donation information.', '寄付情報の内部読み込みフラグです。'), default=False, options={'SKIP_SAVE', 'HIDDEN'}, update=_save_user_preferences_soon)
    version_check_interval_days: IntProperty(name=bi('Version Check Interval (Days)', '更新確認間隔（日）'), description=bi('Number of days between automatic version checks.', '自動バージョン確認の間隔（日数）です。'), default=1, min=0, soft_max=30, update=_save_user_preferences_soon)
    version_check_interval_hours: IntProperty(name=bi('Version Check Interval (Hours)', '更新確認間隔（時間）'), description=bi('Number of hours between automatic version checks.', '自動バージョン確認の間隔（時間）です。'), default=0, min=0, soft_max=23, update=_save_user_preferences_soon)
    version_check_interval_minutes: IntProperty(name=bi('Version Check Interval (Minutes)', '更新確認間隔（分）'), description=bi('Number of minutes between automatic version checks.', '自動バージョン確認の間隔（分）です。'), default=0, min=0, soft_max=59, update=_save_user_preferences_soon)
    update_state: EnumProperty(name=bi('Update State', '更新状態'), description=bi('Internal update-state cache.', '内部の更新状態キャッシュです。'), items=(('UNAVAILABLE', 'Unavailable', ''), ('AVAILABLE', 'Available', ''), ('LOADING', 'Loading', ''), ('ERROR', 'Error', '')), default='UNAVAILABLE', options={'SKIP_SAVE', 'HIDDEN'}, update=_save_user_preferences_soon)
    show_opacity_in_layer_list: BoolProperty(name=bi('Show Opacity in Layer List', 'レイヤー一覧に不透明度を表示'), description=bi('Show opacity values in the Paint System layer list.', 'Paint System のレイヤー一覧に不透明度を表示します。'), default=True, update=_save_user_preferences_soon)
    use_panel_quick_access: BoolProperty(name=bi('Use Panel Quick Access', 'パネルクイックアクセスを使う'), description=bi('Enable the Paint System quick-access panel shortcuts.', 'Paint System のクイックアクセス用パネルショートカットを有効にします。'), default=False, update=_save_user_preferences_soon)
    developer_mode: BoolProperty(name=bi('Developer Mode', '開発者モード'), description=bi('Enable developer-oriented Paint System logging and diagnostics.', '開発者向けのログと診断を有効にします。'), default=False, update=_save_user_preferences_soon)


class SPSTexturesAutosaveToolPreferences(bpy.types.PropertyGroup):
    use_timer: BoolProperty(name=bi('Use Autosave Timer', '自動保存タイマーを使う'), description=bi('Use Blender-timer based periodic autosave for dirty texture images.', '変更済みテクスチャ画像に対し、Blender タイマーを使った定期自動保存を行います。'), default=False, update=_textures_autosave_timer_update)
    do_overwrite_on_timer: BoolProperty(name=bi('Overwrite Existing on Autosave', '自動保存時に既存ファイルを上書き'), description=bi('When the source image already exists on disk, allow the timer path to overwrite that file instead of saving only autosave copies.', '元画像がディスク上にある場合、自動保存コピーだけでなくその既存ファイル自体もタイマー保存で上書きできるようにします。'), default=False, update=_save_user_preferences_soon)
    use_save_handler: BoolProperty(name=bi('Save On Blendfile Saving', '.blend 保存時にも保存する'), description=bi('Also write dirty texture images immediately before the current .blend file is saved.', '現在の .blend ファイル保存直前にも、変更済みテクスチャ画像を書き出します。'), default=False, update=_textures_autosave_handler_update)
    do_overwrite_on_save: BoolProperty(name=bi('Overwrite Existing on Blendfile Saving', '.blend 保存時に既存ファイルを上書き'), description=bi('When the source image already exists on disk, allow the blend-save hook to overwrite that file instead of saving only autosave copies.', '元画像がディスク上にある場合、.blend 保存フックで自動保存コピーだけでなく既存ファイル自体も上書きできるようにします。'), default=True, update=_save_user_preferences_soon)
    use_temp_dir: BoolProperty(name=bi('Use Extension Storage Root', '拡張機能保存領域を基準にする'), description=bi('Use the extension user_default autosave directory as the root for autosave copies. This keeps automatically generated files inside the installed extension storage area unless you manually enter another directory.', '自動保存コピーの基準に拡張機能の自動保存フォルダーを使います。別のフォルダーを手動で入力しない限り、自動生成ファイルを拡張機能の保存領域内に収めます。'), default=False, update=_save_user_preferences_soon)
    dirpath: StringProperty(name=bi('Autosave Directory', '自動保存ディレクトリ'), description=bi('Directory used for autosave copies. The legacy default //autosave_images is redirected to the extension user_default autosave directory. Enter another path only when you intentionally want to choose a manual directory.', '自動保存コピーを書き出すフォルダーです。従来の既定値は拡張機能の自動保存フォルダーへ振り替えられます。別の場所を明示したい時だけパスを入力します。'), subtype='DIR_PATH', default='//autosave_images', update=_save_user_preferences_soon)


class SPSUcupaintToolPreferences(bpy.types.PropertyGroup):
    background_services_enabled: BoolProperty(name=bi('Background Services', 'バックグラウンドサービス'), description=bi('Keep Layer Paint Engine background callbacks active.', 'Layer Paint Engine のバックグラウンドコールバックを有効に保ちます。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    default_new_image_size: IntProperty(name=bi('Custom Default Image Size', 'カスタム既定画像サイズ'), description=bi('Default image size used when Layer Paint Engine is set to use a custom image resolution.', 'Layer Paint Engine でカスタム画像解像度を使うときの既定サイズです。'), default=1024, min=64, max=16384, update=_save_user_preferences_soon)
    image_atlas_size: IntProperty(name=bi('Image Atlas Size', '画像アトラスサイズ'), description=bi('Resolution of the regular image atlas created by Layer Paint Engine.', 'Layer Paint Engine が作る通常画像アトラスの解像度です。'), default=8192, min=2048, max=16384, update=_save_user_preferences_soon)
    hdr_image_atlas_size: IntProperty(name=bi('HDR Image Atlas Size', 'HDR 画像アトラスサイズ'), description=bi('Resolution of the HDR image atlas created by Layer Paint Engine.', 'Layer Paint Engine が作る HDR 画像アトラスの解像度です。'), default=4096, min=1024, max=8192, update=_save_user_preferences_soon)
    unique_image_atlas_per_yp: BoolProperty(name=bi('Use unique Image Atlas per Layer Paint Engine tree', 'ツリーごとに固有アトラスを使う'), description=bi('Try to use a separate image atlas for each Layer Paint Engine node tree.', '各 Layer Paint Engine ノードツリーごとに別の画像アトラスを使うようにします。'), default=True, update=_save_user_preferences_soon)
    developer_mode: BoolProperty(name=bi('Developer Mode', '開発者モード'), description=bi('Show developer-oriented options inside Layer Paint Engine.', 'Layer Paint Engine 内で開発者向けオプションを表示します。'), default=False, update=_save_user_preferences_soon)
    show_experimental: BoolProperty(name=bi('Show Experimental Features', '実験的機能を表示'), description=bi('Show unfinished experimental Layer Paint Engine features.', '未完成の実験的 Layer Paint Engine 機能を表示します。'), default=False, update=_save_user_preferences_soon)
    use_image_preview: BoolProperty(name=bi('Use Image Preview/Thumbnail', '画像プレビュー/サムネイルを使う'), description=bi('Show image previews or thumbnails in Layer Paint Engine layer lists.', 'Layer Paint Engine のレイヤー一覧で画像プレビューやサムネイルを表示します。'), default=False, update=_save_user_preferences_soon)
    skip_property_popups: BoolProperty(name=bi('Skip Property Popups (Hold Shift to Show)', 'プロパティポップアップを省略（Shift で表示）'), description=bi('Skip property popups unless Shift is held, and reuse the last values when the popup is skipped.', 'Shift を押している場合を除いてプロパティポップアップを省略し、省略時は前回の値を再利用します。'), default=False, update=_save_user_preferences_soon)
    icons: EnumProperty(name=bi('Icons', 'アイコン'), description=bi('Choose which icon set Layer Paint Engine should use.', 'Layer Paint Engine が使うアイコンセットを選びます。'), items=(('DEFAULT', 'Default', bi('Icon set from the current Blender version.', '現在の Blender バージョンのアイコンを使います。')), ('LEGACY', 'Legacy', bi('Legacy icon set from older Blender versions.', '旧 Blender バージョン由来のレガシーアイコンを使います。'))), default='DEFAULT', update=_ucupaint_icons_update)
    make_preview_mode_srgb: BoolProperty(name=bi('Make Preview Mode use sRGB', 'プレビューモードを sRGB にする'), description=bi('Ensure preview mode uses sRGB color handling.', 'プレビューモードで sRGB カラー処理を使うようにします。'), default=True, update=_save_user_preferences_soon)
    parallax_without_baked: BoolProperty(name=bi('Parallax Without Use Baked', 'ベイクなしパララックス'), description=bi('Allow parallax without baked textures. This can be very slow.', 'ベイクテクスチャなしでもパララックスを許可します。非常に遅くなる場合があります。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)
    default_bake_device: EnumProperty(name=bi('Bake Device', 'ベイクデバイス'), description=bi('Default device used for Layer Paint Engine bake operations.', 'Layer Paint Engine のベイク処理で使う既定デバイスです。'), items=(('DEFAULT', 'Default', bi('Use the last selected bake device.', '最後に選択したベイクデバイスを使います。')), ('CPU', 'CPU', bi('Use CPU by default.', '既定で CPU を使います。')), ('GPU', 'GPU Compute', bi('Use GPU Compute by default.', '既定でGPU演算を使います。'))), default='DEFAULT', update=_save_user_preferences_soon)
    enable_baked_outside_by_default: BoolProperty(name=bi('Enable Baked Outside by default', '既定でベイク結果を外側に作る'), description=bi('Enable baked outside by default when creating new Layer Paint Engine nodes.', '新しいレイヤーペイントのノードを作るとき、既定でベイク結果を外側に作ります。'), default=False, update=_save_user_preferences_soon)
    enable_uniform_uv_scale_by_default: BoolProperty(name=bi('Enable Uniform UV Scale by default', '既定で UV スケールを均等にする'), description=bi('Enable uniform UV scale by default for layer and mask UV settings.', 'レイヤーとマスクの UV 設定で、既定で UV スケールを均等にします。'), default=False, update=_save_user_preferences_soon)
    enable_auto_udim_detection: BoolProperty(name=bi('Enable Auto UDIM Detection', '自動 UDIM 検出を有効'), description=bi('Automatically enable UDIM-related options when UDIM tiles are detected.', 'UDIM タイルを検出したとき、関連オプションを自動で有効にします。'), default=True, update=_save_user_preferences_soon)
    enable_material_view_warning: BoolProperty(name=bi('Enable "Switch to Material View" warning', '「マテリアル表示へ切替」警告を有効'), description=bi('Show a warning when the parent viewport is not using a material preview or render display mode.', '親ビューポートがマテリアルプレビュー / レンダー表示でないときに警告を表示します。'), default=True, update=_save_user_preferences_soon)
    layer_list_mode: EnumProperty(name=bi('Layer Lists Mode', 'レイヤー一覧モード'), description=bi('Choose how Layer Paint Engine layer lists are presented.', 'Layer Paint Engine のレイヤー一覧表示方法を選びます。'), items=(('DYNAMIC', 'Dynamic', bi('Dynamic layers list with dropdown support.', 'ドロップダウン対応の動的レイヤー一覧です。')), ('CLASSIC', 'Classic', bi('Classic layers list.', '従来型のレイヤー一覧です。')), ('BOTH', 'Dynamic & Classic (For Debugging)', bi('Show both list types for debugging.', 'デバッグ用に両方の一覧を表示します。'))), default='DYNAMIC', update=_save_user_preferences_soon)
    default_image_resolution: EnumProperty(name=bi('Default Image Size', '既定画像サイズ'), description=bi('Default image size behavior used when creating new Layer Paint Engine images.', '新しい Layer Paint Engine 画像を作るときの既定サイズ動作です。'), items=(('DEFAULT', 'Default', bi('Use the last selected image size.', '最後に選択した画像サイズを使います。')), ('512', '512', bi('Always use 512x512 by default.', '既定で常に 512x512 を使います。')), ('1024', '1024', bi('Always use 1024x1024 by default.', '既定で常に 1024x1024 を使います。')), ('2048', '2048', bi('Always use 2048x2048 by default.', '既定で常に 2048x2048 を使います。')), ('4096', '4096', bi('Always use 4096x4096 by default.', '既定で常に 4096x4096 を使います。')), ('CUSTOM', 'Custom Resolution', bi('Use a custom resolution by default.', '既定でカスタム解像度を使います。'))), default='DEFAULT', update=_save_user_preferences_soon)
    always_evaluate_frame: BoolProperty(name=bi('Always Evaluate on Frame Change', 'フレーム変更時に常に評価'), description=bi('Always evaluate Layer Paint Engine keyframe data on frame changes. This can be slow.', 'フレーム変更時に Layer Paint Engine のキーフレームデータを常に評価します。遅くなる場合があります。'), default=False, update=_save_user_preferences_soon)
    hide_update_notification: BoolProperty(name=bi('Hide Update Notification', '更新通知を隠す'), description=bi('Always hide update notifications inside Layer Paint Engine.', 'Layer Paint Engine 内の更新通知を常に隠します。'), default=False, update=_save_user_preferences_soon)
    eevee_next_displacement: BoolProperty(name=bi('Eevee Next Displacement', 'Eevee Next ディスプレイスメント'), description=bi('Internal Eevee Next displacement compatibility flag.', '内部用の Eevee Next ディスプレイスメント互換フラグです。'), default=False, options={'HIDDEN'}, update=_save_user_preferences_soon)



class SPSAddonPreferences(bpy.types.PropertyGroup):
    # Runtime-only root preferences.  This intentionally does not subclass
    # AddonPreferences, so Blender Preferences does not create a visible
    # "Preferences" section for this extension.


    show_always_on_toggles: BoolProperty(
        name=bi('Resident Feature Toggles', '常時機能切り替え'),
        description=bi(
            'Open or close the Resident Feature Toggles group at the top of the Smart Paint N-panel. This state is saved in the Smart Paint settings file and is closed by default.',
            'Smart Paint Nパネル最上部の常時機能切り替えグループを開閉します。この状態はSmart Paint設定ファイルへ保存され、既定では閉じています。',
        ),
        default=False,
        update=_update_sidebar_category,
    options={'HIDDEN'},)


    n_panel_state_save: BoolProperty(
        name=bi('N-panel State Save', 'Nパネル状態保存'),
        description=bi(
            'When enabled, Smart Paint N-panel changes are saved to config/Smart_Paint_Suite/Smart_Paint_Suite.json. Turning this off records OFF once and blocks every later automatic, direct, save, and shutdown writer until enabled again.',
            '有効の場合、Smart PaintのNパネル変更をconfig/Smart_Paint_Suite/Smart_Paint_Suite.jsonへ保存します。OFF操作自体は1回だけ記録し、その後は再びONにするまで自動・直接・保存時・終了時のすべての書き込みを停止します。',
        ),
        default=True,
        options={'HIDDEN'},
        update=_update_n_panel_state_save,
    )


    # Unified SmartTools N-panel foldout state.  These properties only replace
    # the old nested Panel hierarchy; the feature drawers and operators remain
    # unchanged.  Keeping the state on the runtime preferences makes the UI
    # deterministic in both View3D and Image Editor.
    ui_section_document: BoolProperty(name=bi('Document', 'ドキュメント'), default=True, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_layers: BoolProperty(name=bi('Layers', 'レイヤー'), default=True, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_selection: BoolProperty(name=bi('Selection', '選択範囲'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_paint: BoolProperty(name=bi('Paint', '描画'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_transform: BoolProperty(name=bi('Transform', '変形'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_properties: BoolProperty(name=bi('Properties', 'プロパティ'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_brush_assets: BoolProperty(name=bi('Brush Assets', 'ブラシ資産'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_palette: BoolProperty(name=bi('Color Palette', 'カラーパレット'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_paint_preparation: BoolProperty(name=bi('Paint Preparation', 'ペイント準備'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_image_utilities: BoolProperty(name=bi('Image Utilities', '画像ユーティリティ'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)
    ui_section_external: BoolProperty(name=bi('External Paint', '外部ペイント'), default=False, options={'HIDDEN'}, update=_save_user_preferences_now)

    suite_animated_brush_enabled: BoolProperty(
        name=bi('Animated Brush Event Runtime', 'アニメブラシイベント常時処理'),
        description=bi(
            'When enabled from the top Always-on Toggle group, Smart Paint monitors paint input and advances image-sequence brush textures using throttled event handling instead of a repeating high-frequency timer.',
            '最上部の常時機能切り替えから有効にすると、Smart Paint が描画入力を監視し、高頻度の反復タイマーではなく間引き済みイベント処理で画像シーケンスブラシテクスチャを進めます。',
        ),
        default=False,
        options={'HIDDEN'},
        update=_always_on_runtime_update,
    )

    suite_texture_save_hook_enabled: BoolProperty(
        name=bi('Save Dirty Textures on Blend Save', '.blend保存時テクスチャ保存'),
        description=bi(
            'When enabled from the top Always-on Toggle group, dirty texture images are written only when Blender saves the current .blend file. No periodic texture-save timer is used.',
            '最上部の常時機能切り替えから有効にすると、現在の .blend ファイル保存時だけ変更済みテクスチャ画像を書き出します。定期テクスチャ保存タイマーは使いません。',
        ),
        default=False,
        options={'HIDDEN'},
        update=_always_on_runtime_update,
    )

    suite_brush_save_hook_enabled: BoolProperty(
        name=bi('Save Brush Presets on Blend Save', '.blend保存時ブラシプリセット保存'),
        description=bi(
            'When enabled from the top Always-on Toggle group, editable Blender brush settings are saved as Smart Paint JSON presets after the current .blend file is saved. This protects brush edits without running a background timer.',
            '最上部の常時機能切り替えから有効にすると、現在の .blend ファイル保存後に編集可能なBlenderブラシ設定をSmart Paint JSONプリセットとして保存します。バックグラウンドタイマーなしでブラシ編集を保護します。',
        ),
        default=False,
        options={'HIDDEN'},
        update=_always_on_runtime_update,
    )

    default_image_dir: StringProperty(
        name="Default Image Directory",
        description=bi(
            "Directory used when Smart Paint saves images that do not have a file path yet. When left on the legacy default, the extension resolves this into its writable user_default storage area.",
            'まだ保存先がない画像を Smart Paint が保存するときに使う既定のフォルダーです。従来の既定値のままなら、拡張機能の書き込み可能な保存領域を使います。',
        ),
        subtype='DIR_PATH',
        default="//textures",
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )

    default_resolution: EnumProperty(
        name="Default Resolution",
        description=bi(
            "Default size for newly created paint images.",
            "新規ペイント画像を作るときの既定サイズです。",
        ),
        items=RESOLUTION_ITEMS,
        default='2048',
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )

    auto_switch_to_paint: BoolProperty(
        name="Auto Switch to Texture Paint",
        description=bi(
            "When a paint target is activated, automatically switch the active mesh into Texture Paint mode.",
            'ペイント対象を有効にしたとき、自動でテクスチャペイントモードへ切り替えます。',
        ),
        default=True,
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )

    auto_save_after_bake: BoolProperty(
        name="Auto Save After Bake",
        description=bi(
            "Save baked and newly generated images automatically whenever possible.",
            "可能な場合はベイクや新規生成のあとに画像を自動保存します。",
        ),
        default=False,
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )

    default_sidebar_category: StringProperty(
        name="Sidebar Category",
        description=bi(
            "Deprecated compatibility field. Smart Paint uses the standard 3D View N-panel category named Smart Paint.",
            "互換性維持用の旧設定です。Smart Paint は標準3DビューNパネルの Smart Paint カテゴリを使います。",
        ),
        default="Smart Paint",
        options={'HIDDEN'},
        update=_update_sidebar_category,
    )

    debug_logging: BoolProperty(
        name="Debug Logging",
        description=bi(
            "Print additional information to the console for troubleshooting.",
            "トラブルシュート用に追加情報をコンソールへ表示します。",
        ),
        default=False,
        options={'HIDDEN'},
        update=_save_user_preferences_soon,
    )

    scene_settings_json: StringProperty(
        name="Scene Settings Cache",
        description=bi(
            "Internal hidden cache used to keep Smart Paint N-panel scene settings persistent across Blender launches and scene changes.",
            "Smart Paint Nパネルのシーン設定を Blender 起動間やシーン切り替え後も維持するための内部非表示キャッシュです。",
        ),
        default="",
        options={'HIDDEN'},
    )

    brushstroke_tools: PointerProperty(type=SPSBrushstrokeToolPreferences,
    options={'HIDDEN'},)
    grease_pencil_tools: PointerProperty(type=SPSGreasePencilToolPreferences,
    options={'HIDDEN'},)
    system: PointerProperty(type=SPSPaintSystemToolPreferences,
    options={'HIDDEN'},)
    textures_autosave: PointerProperty(type=SPSTexturesAutosaveToolPreferences,
    options={'HIDDEN'},)
    ucupaint: PointerProperty(type=SPSUcupaintToolPreferences,
    options={'HIDDEN'},)

    def draw(self, context):
        return None


class SPSLayerItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Layer Name",
        description=bi(
            "Display name of the layer. This is also used when images and nodes are named.",
            "レイヤーの表示名です。画像やノード名にも使われます。",
        ),
        default="Layer",
    )

    layer_id: StringProperty(
        name="Layer ID",
        description=bi(
            "Internal stable identifier used to reconnect nodes and paint targets safely.",
            "ノードやペイント対象を安全に再接続するための内部IDです。",
        ),
        default="",
    )

    photoshop_layer_id: StringProperty(
        name="External Layer ID",
        description=bi(
            "External application layer identifier. This is kept separate from the internal layer ID.",
            "外部アプリ側のレイヤーIDです。内部レイヤーIDとは分離して保持します。",
        ),
        default="",
        options={'HIDDEN'},
    )

    psd_source_record_index: IntProperty(
        name="PSD Source Record Index",
        description=bi(
            "0-based raw PSD layer record index used as the durable external bridge identity.",
            '外部連携で変わらない目印として使う、0始まりのPSDレイヤー記録の番号です。',
        ),
        default=-1,
        options={'HIDDEN'},
    )

    enabled: BoolProperty(
        name="Enabled",
        description=bi(
            "Mute or unmute the layer without deleting its images or settings.",
            "画像や設定を削除せずにレイヤーを有効／無効化します。",
        ),
        default=True,
        update=_layer_stack_property_update,
    )

    selected_for_edit: BoolProperty(
        name=bi("Edit Selection", "編集対象"),
        description=bi(
            "Manually include this layer in multi-layer edit operations. The active layer is always treated as selected even when this checkbox is off; checked layers are added to the active layer for BodyPaint-style simultaneous transforms and color corrections.",
            "複数レイヤー編集にこのレイヤーを手動で含めます。アクティブレイヤーはこのチェックがOFFでも常に選択中として扱われ、チェックしたレイヤーはアクティブレイヤーに追加され、BodyPaint風に変形や色調補正を同時適用できます。",
        ),
        default=False,
        update=_layer_stack_property_update,
    )

    layer_kind: EnumProperty(
        name="Layer Kind",
        description=bi(
            "General purpose of the layer. Paint uses images, PBR Paint keeps multiple paintable PBR images together, Fill uses values, Decal is good for overlays, and Procedural / Weather rely more on generated masks.",
            'レイヤーの用途です。ペイントは画像中心、PBRペイントは複数のPBR画像をまとめて扱い、塗りつぶしは値中心、デカールは重ね用途、プロシージャル / ウェザーは生成マスクが主体です。',
        ),
        items=LAYER_KIND_ITEMS,
        default='PAINT',
    )

    opacity: FloatProperty(
        name="Opacity",
        description=bi(
            "Master opacity of the layer after masks are evaluated.",
            "マスク評価後に適用されるレイヤー全体の不透明度です。",
        ),
        min=0.0,
        max=1.0,
        default=1.0,
        subtype='FACTOR',
        update=_layer_stack_property_update,
    )

    blend_mode: EnumProperty(
        name="Blend Mode",
        description=bi(
            "Blend mode used when this layer is composited over the result below.",
            "下の結果へこのレイヤーを合成するときの合成モードです。",
        ),
        items=BLEND_MODE_ITEMS,
        default='MIX',
        update=_layer_stack_property_update,
    )

    adjustment_type: EnumProperty(
        name=bi("Adjustment", "調整"),
        description=bi(
            "Photoshop / Clip Studio style adjustment layer type. It affects the composited result below without changing source layer pixels.",
            "Photoshop / Clip Studio 風の調整レイヤー種別です。元レイヤーのピクセルを変更せず、下の合成結果へ作用します。",
        ),
        items=ADJUSTMENT_TYPE_ITEMS,
        default='NONE',
        update=_adjustment_property_update,
    )

    adj_brightness: FloatProperty(name=bi("Brightness", "明るさ"), description=bi("Brightness offset used by brightness/contrast adjustment.", "明るさ・コントラスト調整で使う明るさ補正値です。"), min=-1.0, max=1.0, default=0.0, update=_adjustment_property_update)
    adj_contrast: FloatProperty(name=bi("Contrast", "コントラスト"), description=bi("Contrast amount. 0 keeps original contrast.", "コントラスト量です。0で元のコントラストを維持します。"), min=-1.0, max=1.0, default=0.0, update=_adjustment_property_update)
    adj_exposure: FloatProperty(name=bi("Exposure", "露光量"), description=bi("Exposure offset in stops for brightness/contrast style adjustment.", "明るさ調整に加える露光量です。"), min=-8.0, max=8.0, default=0.0, update=_adjustment_property_update)
    adj_gamma: FloatProperty(name=bi("Gamma", "ガンマ"), description=bi("Gamma correction. 1 keeps original gamma.", "ガンマ補正です。1で元のガンマを維持します。"), min=0.01, max=10.0, default=1.0, update=_adjustment_property_update)
    adj_hue: FloatProperty(name=bi("Hue", "色相"), description=bi("Hue rotation. 1.0 turns the hue by 180 degrees.", "色相回転です。1.0で色相を180度回します。"), min=-1.0, max=1.0, default=0.0, update=_adjustment_property_update)
    adj_saturation: FloatProperty(name=bi("Saturation", "彩度"), description=bi("Saturation adjustment. 0 keeps original saturation.", "彩度調整です。0で元の彩度を維持します。"), min=-1.0, max=1.0, default=0.0, update=_adjustment_property_update)
    adj_lightness: FloatProperty(name=bi("Lightness", "明度"), description=bi("Lightness adjustment.", "明度調整です。"), min=-1.0, max=1.0, default=0.0, update=_adjustment_property_update)
    adj_posterize_levels: IntProperty(name=bi("Posterize Levels", "階調数"), description=bi("Number of posterize tonal levels.", "階調化の段階数です。"), min=2, max=256, default=4, update=_adjustment_property_update)
    adj_threshold: FloatProperty(name=bi("Threshold", "しきい値"), description=bi("Threshold value used by binarization.", "2値化で使うしきい値です。"), min=0.0, max=1.0, default=0.5, subtype='FACTOR', update=_adjustment_property_update)
    adj_levels_input_black: FloatProperty(name=bi("Input Black", "入力黒"), description=bi("Input black level.", "入力黒レベルです。"), min=0.0, max=1.0, default=0.0, subtype='FACTOR', update=_adjustment_property_update)
    adj_levels_input_white: FloatProperty(name=bi("Input White", "入力白"), description=bi("Input white level.", "入力白レベルです。"), min=0.0, max=1.0, default=1.0, subtype='FACTOR', update=_adjustment_property_update)
    adj_levels_gamma: FloatProperty(name=bi("Levels Gamma", "レベルガンマ"), description=bi("Levels gamma/midtone.", "レベル補正の中間調ガンマです。"), min=0.01, max=10.0, default=1.0, update=_adjustment_property_update)
    adj_levels_output_black: FloatProperty(name=bi("Output Black", "出力黒"), description=bi("Output black level.", "出力黒レベルです。"), min=0.0, max=1.0, default=0.0, subtype='FACTOR', update=_adjustment_property_update)
    adj_levels_output_white: FloatProperty(name=bi("Output White", "出力白"), description=bi("Output white level.", "出力白レベルです。"), min=0.0, max=1.0, default=1.0, subtype='FACTOR', update=_adjustment_property_update)
    adj_curve_points: StringProperty(name=bi("Curve Points", "カーブ点"), description=bi("Tone curve control points stored as JSON pairs in 0-1 range.", "0-1範囲のトーンカーブ制御点JSONです。"), default="[[0,0],[1,1]]", update=_adjustment_property_update)
    adj_color_balance_shadows: FloatVectorProperty(name=bi("Shadows", "シャドウ"), description=bi("Color balance offset for shadows.", "シャドウのカラーバランス補正です。"), size=3, min=-1.0, max=1.0, default=(0.0,0.0,0.0), subtype='COLOR', update=_adjustment_property_update)
    adj_color_balance_midtones: FloatVectorProperty(name=bi("Midtones", "中間調"), description=bi("Color balance offset for midtones.", "中間調のカラーバランス補正です。"), size=3, min=-1.0, max=1.0, default=(0.0,0.0,0.0), subtype='COLOR', update=_adjustment_property_update)
    adj_color_balance_highlights: FloatVectorProperty(name=bi("Highlights", "ハイライト"), description=bi("Color balance offset for highlights.", "ハイライトのカラーバランス補正です。"), size=3, min=-1.0, max=1.0, default=(0.0,0.0,0.0), subtype='COLOR', update=_adjustment_property_update)
    adj_gradient_dark: FloatVectorProperty(name=bi("Gradient Dark", "グラデーション暗部"), description=bi("Dark endpoint for gradient map.", "グラデーションマップの暗部色です。"), size=4, min=0.0, max=1.0, default=(0.0,0.0,0.0,1.0), subtype='COLOR', update=_adjustment_property_update)
    adj_gradient_light: FloatVectorProperty(name=bi("Gradient Light", "グラデーション明部"), description=bi("Light endpoint for gradient map.", "グラデーションマップの明部色です。"), size=4, min=0.0, max=1.0, default=(1.0,1.0,1.0,1.0), subtype='COLOR', update=_adjustment_property_update)
    adj_preserve_luminosity: BoolProperty(name=bi("Preserve Luminosity", "輝度を保持"), description=bi("Preserve luminance for color balance adjustments.", "カラーバランス調整で輝度をできるだけ維持します。"), default=True, update=_adjustment_property_update)

    psd_raw_adjustment_tags: StringProperty(
        name="PSD Adjustment Descriptor",
        description=bi(
            "Raw Photoshop adjustment-layer tag payloads preserved from PSD import. This keeps Photoshop-specific Descriptor parameters intact when saving back to PSD.",
            'PSD読み込み時に保持した Photoshop 調整レイヤーの生データです。PSD保存時に Photoshop 固有の設定を壊さず保持します。',
        ),
        default="",
        options={'HIDDEN'},
    )

    psd_raw_layer_tags: StringProperty(
        name="PSD Raw Layer Tags",
        description=bi(
            "Raw PSD tagged layer blocks preserved for round-trip compatibility.",
            "往復互換のために保持するPSD追加レイヤータグの生データです。",
        ),
        default="",
        options={'HIDDEN'},
    )

    clip_to_below: BoolProperty(
        name=bi("Clip to Layer Below", "下のレイヤーでクリッピング"),
        description=bi(
            "Clip this layer by the alpha of the nearest normal layer below, like Photoshop / Clip Studio clipping. The pixel data itself is kept unchanged.",
            "Photoshop / Clip Studio の「下のレイヤーでクリッピング」のように、このレイヤーを直下の通常レイヤーのアルファで切り抜きます。ピクセルデータ自体は変更しません。",
        ),
        default=False,
        update=_clipping_property_update,
    )

    is_group: BoolProperty(
        name=bi("Layer Group", "レイヤーグループ"),
        description=bi(
            "Treat this item as a layer group/folder marker. It does not paint pixels itself, but its name and state are preserved when Smart Paint reads or writes PSD files.",
            "この項目をレイヤーグループ／フォルダーとして扱います。自体はピクセルを描画しませんが、PSD読み込み／保存時に名前と状態を保持します。",
        ),
        default=False,
    )

    group_expanded: BoolProperty(
        name=bi("Group Expanded", "グループを展開"),
        description=bi(
            "Store whether this group is expanded. PSD export/import preserves this as far as the PSD section-divider data allows.",
            "このグループが展開状態かどうかを保持します。PSDのセクション区切り情報で可能な範囲で保存／読み込みします。",
        ),
        default=True,
    )

    group_depth: IntProperty(
        name=bi("Group Depth", "グループ階層"),
        description=bi(
            "Internal group nesting depth imported from PSD files. Normally this is managed automatically.",
            "PSDから読み込んだグループ階層の内部値です。通常は自動管理されます。",
        ),
        min=0,
        max=32,
        default=0,
    )

    projection_mode: EnumProperty(
        name="Projection",
        description=bi(
            "UV uses the selected UV map. Box uses generated coordinates with box projection and is useful for seam friendly blocking or decals.",
            'UVは指定のUVマップを使います。ボックスは生成座標のボックス投影で、継ぎ目を減らしたラフ塗りやデカールに有効です。',
        ),
        items=PROJECTION_ITEMS,
        default='UV',
    )

    uv_map: StringProperty(
        name="UV Map",
        description=bi(
            "UV map name used by this layer when Projection is set to UV.",
            "Projection が UV のときにこのレイヤーが使うUVマップ名です。",
        ),
        default=DEFAULT_UV_NAME,
    )


    uv_scale: FloatVectorProperty(
        name="UV Scale",
        description=bi(
            "Per-layer UV scale / tiling. Useful for matching external UV transform workflows and resizing decals without editing the source image.",
            'レイヤー単位のUV拡大率 / タイリングです。外部ツールのUV変形に合わせたり、元画像を編集せずにデカールの大きさを変えたりする時に便利です。',
        ),
        size=2,
        default=(1.0, 1.0),
        min=0.001,
        max=100.0,
    )

    uv_offset: FloatVectorProperty(
        name="UV Offset",
        description=bi(
            "Per-layer UV translation in normalized texture space.",
            "正規化されたテクスチャ空間での、レイヤー単位UV平行移動です。",
        ),
        size=2,
        default=(0.0, 0.0),
        min=-10.0,
        max=10.0,
    )

    uv_rotation: FloatProperty(
        name="UV Rotation",
        description=bi(
            "Per-layer UV rotation applied before sampling images or procedural masks.",
            "画像や生成マスクをサンプリングする前に掛かる、レイヤー単位のUV回転です。",
        ),
        subtype='ANGLE',
        default=0.0,
    )

    use_texture_bombing: BoolProperty(
        name="Anti-Tiling Warp",
        description=bi(
            "Adds a stochastic UV warp before texture sampling. This is not identical to dedicated texture bombing tools, but it reduces obvious repetition and is fast enough for everyday use.",
            'テクスチャ読み取り前に確率的なUVの歪みを加えます。専用のテクスチャボンビングと完全には同じではありませんが、目立つ繰り返しを減らし、普段使いできる速さです。',
        ),
        default=False,
    )

    bombing_strength: FloatProperty(
        name="Warp Strength",
        description=bi(
            "How strongly the anti-tiling warp distorts the input coordinates.",
            "アンチタイリング用ワープが入力座標をどれくらい歪ませるかです。",
        ),
        min=0.0,
        max=2.0,
        default=0.15,
    )

    bombing_cell_scale: FloatProperty(
        name="Bombing Cell Scale",
        description=bi(
            "Approximate cell size used by the anti-tiling offset. Lower values create broader breakup, higher values create finer variation similar to texture bombing scatter cells.",
            'アンチタイリング用オフセットで使うおおよそのセルサイズです。小さい値は大きな崩し、大きい値はテクスチャボンビングの散布セルに近い細かな変化になります。',
        ),
        min=0.25,
        max=128.0,
        default=4.0,
    )

    bombing_seed: FloatProperty(
        name="Bombing Seed",
        description=bi(
            "Seed-like offset for the anti-tiling pattern. Change this to quickly get a different breakup arrangement without touching the source texture.",
            "アンチタイリングパターン用の疑似シードです。元テクスチャを変更せずに、ブレイクアップの並びだけを素早く変えられます。",
        ),
        min=-1000.0,
        max=1000.0,
        default=0.0,
    )

    use_base_color: BoolProperty(
        name="Use Base Color",
        description=bi(
            "Whether this layer contributes to the base color channel.",
            "このレイヤーをベースカラーチャンネルへ寄与させるかです。",
        ),
        default=True,
    )
    base_color_image: StringProperty(name="Base Color Image", description=bi("Image used for the base color channel.", "ベースカラー用画像です。"), default="")
    fill_color: FloatVectorProperty(
        name="Fill Color",
        description=bi(
            "Fallback color used by Fill layers or whenever no base color image is assigned.",
            '塗りつぶしレイヤー、またはベースカラー画像が未設定のときに使う代替の色です。',
        ),
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=DEFAULT_FILL_COLOR,
    )

    use_roughness: BoolProperty(name="Use Roughness", description=bi("Enable roughness contribution.", "粗さ寄与を有効にします。"), default=True)
    roughness_image: StringProperty(name="Roughness Image", description=bi("Image used for roughness.", "粗さ用画像です。"), default="")
    roughness_value: FloatProperty(name="Roughness Value", description=bi("Fallback roughness value used when no image is assigned.", "画像がないときに使う代替粗さ値です。"), min=0.0, max=1.0, default=0.5, subtype='FACTOR')

    use_metallic: BoolProperty(name="Use Metallic", description=bi("Enable metallic contribution.", "メタリック寄与を有効にします。"), default=False)
    metallic_image: StringProperty(name="Metallic Image", description=bi("Image used for metallic.", "メタリック用画像です。"), default="")
    metallic_value: FloatProperty(name="Metallic Value", description=bi("Fallback metallic value used when no image is assigned.", "画像がないときに使う代替メタリック値です。"), min=0.0, max=1.0, default=0.0, subtype='FACTOR')

    use_normal: BoolProperty(name="Use Normal", description=bi("Enable normal contribution.", "ノーマル寄与を有効にします。"), default=False)
    normal_image: StringProperty(name="Normal Image", description=bi("Image used for tangent-space normal details.", "タンジェント空間ノーマルの画像です。"), default="")
    normal_strength: FloatProperty(name="Normal Strength", description=bi("Strength multiplier for this layer's normal contribution.", "このレイヤーのノーマル寄与にかかる強度です。"), min=0.0, max=5.0, default=1.0)

    use_height: BoolProperty(name="Use Height", description=bi("Enable height/bump contribution.", "高さ／バンプ寄与を有効にします。"), default=False)
    height_image: StringProperty(name="Height Image", description=bi("Image used for height or bump details.", "高さ／バンプ用画像です。"), default="")
    height_value: FloatProperty(name="Height Value", description=bi("Fallback height value used when no image is assigned.", "画像がないときに使う代替高さ値です。"), min=0.0, max=1.0, default=0.5, subtype='FACTOR')
    height_strength: FloatProperty(name="Height Strength", description=bi("Strength multiplier for bump or displacement preview.", "バンプ／ディスプレイスメント表示にかかる強度です。"), min=0.0, max=5.0, default=0.2)

    use_emission: BoolProperty(name="Use Emission", description=bi("Enable emission contribution.", "発光寄与を有効にします。"), default=False)
    emission_image: StringProperty(name="Emission Image", description=bi("Image used for emission color.", "発光色用画像です。"), default="")
    emission_color: FloatVectorProperty(name="Emission Color", description=bi("Fallback emission color when no image is assigned.", "画像がないときに使う代替発光色です。"), subtype='COLOR', size=4, min=0.0, max=1.0, default=DEFAULT_EMISSION_COLOR)
    emission_strength: FloatProperty(name="Emission Strength", description=bi("Strength multiplier for emission contribution.", "発光寄与にかかる強度です。"), min=0.0, max=100.0, default=1.0)

    use_alpha: BoolProperty(name="Use Alpha", description=bi("Enable alpha/opacity contribution.", "アルファ／不透明度寄与を有効にします。"), default=False)
    alpha_image: StringProperty(name="Alpha Image", description=bi("Image used for alpha/opacity.", "アルファ／不透明度用画像です。"), default="")
    alpha_value: FloatProperty(name="Alpha Value", description=bi("Fallback alpha value used when no image is assigned.", "画像がないときに使う代替アルファ値です。"), min=0.0, max=1.0, default=1.0, subtype='FACTOR')

    use_ao: BoolProperty(name="Use AO", description=bi("Enable AO helper contribution. AO can optionally be multiplied into base color for viewport preview and export preparation.", "AO補助寄与を有効にします。AOはビューポート表示や書き出し準備のためにベースカラーへ乗算できます。"), default=False)
    ao_image: StringProperty(name="AO Image", description=bi("Image used for AO contribution.", "AO寄与用画像です。"), default="")
    ao_value: FloatProperty(name="AO Value", description=bi("Fallback AO value used when no image is assigned.", "画像がないときに使う代替AO値です。"), min=0.0, max=1.0, default=1.0, subtype='FACTOR')

    filter_brightness: FloatProperty(
        name="Brightness",
        description=bi(
            "Per-layer brightness adjustment applied before this layer is blended into the stack. Useful for quickly matching imported textures or decals without editing the source image.",
            "このレイヤーをスタックへ合成する前に掛ける明るさ補正です。元画像を直接編集せずに、読み込んだテクスチャやデカールの明るさ合わせを素早く行えます。",
        ),
        min=-2.0,
        max=2.0,
        default=0.0,
    )

    filter_contrast: FloatProperty(
        name="Contrast",
        description=bi(
            "Per-layer contrast adjustment applied before blending. Positive values add punch, negative values flatten the image.",
            "合成前に掛けるレイヤー単位のコントラスト補正です。正の値でメリハリを増し、負の値で平坦にします。",
        ),
        min=-2.0,
        max=2.0,
        default=0.0,
    )

    filter_gamma: FloatProperty(
        name="Gamma",
        description=bi(
            "Per-layer gamma correction. Values above 1 darken the midtones, values below 1 brighten them.",
            "レイヤー単位のガンマ補正です。1より大きい値は中間調を暗くし、1より小さい値は明るくします。",
        ),
        min=0.01,
        max=4.0,
        default=1.0,
    )

    filter_invert: BoolProperty(
        name="Invert",
        description=bi(
            "Invert this layer's sampled colors before blending. Useful for quick mask, roughness or decal reversals.",
            "このレイヤーのサンプル色を合成前に反転します。マスク、粗さ、デカールの反転を素早く試したいときに便利です。",
        ),
        default=False,
    )

    filter_hue_shift: FloatProperty(
        name="Hue Shift",
        description=bi(
            "Per-layer hue shift. Small values are usually enough for decal and color-variation work.",
            "レイヤー単位の色相シフトです。デカールや色バリエーション用途では小さな値で十分なことが多いです。",
        ),
        min=-0.5,
        max=0.5,
        default=0.0,
        subtype='FACTOR',
    )

    filter_saturation: FloatProperty(
        name="Saturation",
        description=bi(
            "Per-layer saturation multiplier. 1 keeps the original saturation, 0 removes color.",
            "レイヤー単位の彩度倍率です。1で元の彩度を維持し、0で色味を取り除きます。",
        ),
        min=0.0,
        max=4.0,
        default=1.0,
    )

    filter_value: FloatProperty(
        name="Value",
        description=bi(
            "Per-layer value / brightness multiplier in HSV space. Use this for quick decal and albedo intensity matching.",
            "HSV空間でのレイヤー単位の明度倍率です。デカールやアルベド強度を手早く合わせる用途に向きます。",
        ),
        min=0.0,
        max=4.0,
        default=1.0,
    )

    mask_mode: EnumProperty(
        name="Mask Mode",
        description=bi(
            "Select how the layer mask is sourced. Image uses a dedicated mask texture, Anchor can read another layer channel, and the generated modes build procedural masks.",
            'レイヤーマスクの取得方法です。画像は専用のマスク画像、アンカーは別レイヤーのチャンネルを参照、生成モードはプロシージャルにマスクを作ります。',
        ),
        items=MASK_MODE_ITEMS,
        default='NONE',
    )

    mask_image: StringProperty(name="Mask Image", description=bi("Dedicated image used as a layer mask when Mask Mode is Image.", 'マスクモードが画像のときに使う専用のマスク画像です。'), default="")
    mask_channel: EnumProperty(name="Mask Channel", description=bi("Choose which image channel is used as the mask value.", "どの画像チャンネルをマスク値として使うかを選びます。"), items=MASK_CHANNEL_ITEMS, default='LUMA')
    invert_mask: BoolProperty(name="Invert Mask", description=bi("Invert the final mask before opacity is applied.", "不透明度適用前の最終マスクを反転します。"), default=False)
    mask_strength: FloatProperty(name="Mask Strength", description=bi("Additional multiplier applied to the final mask.", "最終マスクへ追加で掛ける倍率です。"), min=0.0, max=2.0, default=1.0)
    mask_threshold: FloatProperty(name="Mask Threshold", description=bi("Threshold used by procedural masks to sharpen or soften the result.", "生成マスクの輪郭を締めたり緩めたりするしきい値です。"), min=0.0, max=1.0, default=0.5)
    noise_scale: FloatProperty(name="Noise Scale", description=bi("Scale of the procedural noise / grunge mask.", "プロシージャルノイズ／グランジマスクのスケールです。"), min=0.01, max=100.0, default=5.0)
    noise_detail: FloatProperty(name="Noise Detail", description=bi("Detail of the procedural noise / grunge mask.", "プロシージャルノイズ／グランジマスクのディテール量です。"), min=0.0, max=16.0, default=2.0)
    edge_balance: FloatProperty(name="Edge Balance", description=bi("Controls how strongly the edge-wear mask focuses on exposed edges.", "エッジ摩耗マスクが露出エッジへどれくらい集中するかを調整します。"), min=0.0, max=4.0, default=1.0)
    vertex_color_attribute: StringProperty(name="Vertex Color Attribute", description=bi("Name of the vertex color or color attribute used when Mask Mode is Vertex Color.", 'マスクモードが頂点カラーのときに使う頂点カラー / カラー属性名です。'), default=DEFAULT_VERTEX_COLOR_NAME)
    color_id_color: FloatVectorProperty(
        name="Target Color",
        description=bi(
            "Color selected from a color-attribute ID map when Mask Mode is Color ID.",
            'マスクモードがカラーIDのときに、カラー属性のIDマップから選ぶ対象の色です。',
        ),
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 0.0, 0.0, 1.0),
    )
    color_id_tolerance: FloatProperty(
        name="Color Tolerance",
        description=bi(
            "How close an ID color must be to the target color before it is treated as part of the mask. Lower values are stricter, higher values accept a broader range.",
            "ID 色がマスク対象として扱われるまでに、対象色へどれくらい近い必要があるかです。低いほど厳密、高いほど広い範囲を許容します。",
        ),
        min=0.001,
        max=1.0,
        default=0.08,
        subtype='FACTOR',
    )
    anchor_layer_name: StringProperty(name="Anchor Layer", description=bi("Name of the source layer used when Mask Mode is Anchor.", 'マスクモードがアンカーのときに参照する元レイヤー名です。'), default="")
    anchor_channel: EnumProperty(name="Anchor Channel", description=bi("Channel pulled from the source layer when Mask Mode is Anchor.", 'マスクモードがアンカーのときに元レイヤーから取得するチャンネルです。'), items=CHANNEL_ITEMS, default='BASE_COLOR')

    anchor_layer_id: StringProperty(
        name="Anchor Layer ID",
        description=bi(
            "Internal stable identifier used to keep anchor references valid even when a source layer is renamed.",
            "元レイヤー名が変わってもアンカー参照を保つための内部IDです。",
        ),
        default="",
    )
    use_height_blend: BoolProperty(
        name="Height Blend / Carve",
        description=bi(
            "Use the layer height as an additional blend driver. This approximates carve-group or height-blend style layering found in dedicated texturing tools.",
            'レイヤーの高さ情報を追加のブレンドの基準に使います。専用テクスチャツールの高さブレンド風の積層を近似します。',
        ),
        default=False,
    )
    height_blend_balance: FloatProperty(
        name="Height Blend Balance",
        description=bi(
            "How strongly the height information sharpens or widens the blend between this layer and the result below.",
            "高さ情報がこのレイヤーと下地のブレンド境界をどれくらい鋭く／広くするかです。",
        ),
        min=0.0,
        max=4.0,
        default=1.0,
    )
    height_blend_invert: BoolProperty(
        name="Invert Height Blend",
        description=bi(
            "Invert the height-driven blend so cavities or low areas are favored instead of high areas.",
            "高さ駆動ブレンドを反転し、高い部分ではなく低い部分や溝を優先します。",
        ),
        default=False,
    )


class SPSMaterialSettings(bpy.types.PropertyGroup):
    managed: BoolProperty(
        name="Managed Material",
        description=bi(
            "Marks that this material is controlled by Smart Paint and can be safely rebuilt from stored layer data.",
            "このマテリアルが Smart Paint 管理下にあり、保存されたレイヤーデータから安全に再構築できることを示します。",
        ),
        default=False,
    )

    active_layer_index: IntProperty(
        name="Active Layer Index",
        description=bi("Index of the currently selected layer in the Smart Paint UI.", "Smart Paint UI で現在選択中のレイヤー番号です。"),
        default=0,
        min=0,
        update=_active_layer_index_update,
    )

    lightweight_ui_layer_index: IntProperty(
        name="Layer List Selection",
        description=bi(
            "UIList selection routed through the lightweight layer activation operator.",
            'レイヤー一覧の選択値です。必ずレイヤーの切り替え操作を経由します。',
        ),
        default=0,
        min=0,
        options={'HIDDEN', 'SKIP_SAVE'},
        update=_lightweight_ui_layer_index_update,
    )

    selection_mode: EnumProperty(
        name="\u9078\u629e\u30e2\u30fc\u30c9",
        description="\u65b0\u3057\u3044\u9078\u629e\u7bc4\u56f2\u306e\u7d50\u5408\u65b9\u6cd5\u3067\u3059\u3002",
        items=(
            ('REPLACE', "\u7f6e\u63db", "\u73fe\u5728\u306e\u9078\u629e\u7bc4\u56f2\u3092\u7f6e\u304d\u63db\u3048\u307e\u3059"),
            ('ADD', "\u8ffd\u52a0", "\u73fe\u5728\u306e\u9078\u629e\u7bc4\u56f2\u3078\u8ffd\u52a0\u3057\u307e\u3059"),
            ('SUBTRACT', "\u524a\u9664", "\u73fe\u5728\u306e\u9078\u629e\u7bc4\u56f2\u304b\u3089\u524a\u9664\u3057\u307e\u3059"),
            ('INTERSECT', "\u4ea4\u5dee", "\u73fe\u5728\u306e\u9078\u629e\u7bc4\u56f2\u3068\u306e\u5171\u901a\u90e8\u5206\u3092\u6b8b\u3057\u307e\u3059"),
        ),
        default='REPLACE',
        options={'SKIP_SAVE'},
    )

    selection_feather: FloatProperty(
        name="\u9078\u629e\u306e\u307c\u304b\u3057",
        description="\u9078\u629e\u5883\u754c\u3092\u5185\u5074\u3078\u6ed1\u3089\u304b\u306b\u307c\u304b\u3059\u5e45\u3067\u3059\u3002",
        min=0.0,
        max=512.0,
        soft_max=64.0,
        default=0.0,
        options={'SKIP_SAVE'},
    )

    edit_fill_color: FloatVectorProperty(
        name="\u5857\u308a\u3064\u3076\u3057\u8272",
        description="\u9078\u629e\u7bc4\u56f2\u307e\u305f\u306f\u30ec\u30a4\u30e4\u30fc\u3078\u9069\u7528\u3059\u308b\u8272\u3067\u3059\u3002",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.8, 0.2, 0.2),
        options={'SKIP_SAVE'},
    )

    edit_fill_alpha: FloatProperty(
        name="\u5857\u308a\u3064\u3076\u3057\u4e0d\u900f\u660e\u5ea6",
        min=0.0,
        max=1.0,
        default=1.0,
        options={'SKIP_SAVE'},
    )

    edit_gradient_end_color: FloatVectorProperty(
        name="グラデーション終了色",
        description="グラデーション終点の色です。始点には塗りつぶし色を使います。",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.12, 0.32, 0.9),
        options={'SKIP_SAVE'},
    )

    edit_gradient_end_alpha: FloatProperty(
        name="グラデーション終了不透明度",
        min=0.0,
        max=1.0,
        default=1.0,
        options={'SKIP_SAVE'},
    )

    edit_gradient_type: EnumProperty(
        name="グラデーション方式",
        items=(
            ('LINEAR', "線形", "始点から終点へ直線的に変化します"),
            ('RADIAL', "放射", "始点を中心に円状に変化します"),
            ('ANGLE', "角度", "始点を中心に一周して変化します"),
            ('REFLECTED', "反射", "始点から両方向へ対称に変化します"),
            ('DIAMOND', "ダイヤ", "始点を中心に菱形状に変化します"),
        ),
        default='LINEAR',
        options={'SKIP_SAVE'},
    )
    edit_translate_x: IntProperty(
        name="\u79fb\u52d5 X",
        min=-16384,
        max=16384,
        default=0,
        options={'SKIP_SAVE'},
    )

    edit_translate_y: IntProperty(
        name="\u79fb\u52d5 Y",
        min=-16384,
        max=16384,
        default=0,
        options={'SKIP_SAVE'},
    )

    edit_scale_percent: FloatProperty(
        name="\u62e1\u5927\u7e2e\u5c0f",
        min=1.0,
        max=1000.0,
        default=100.0,
        options={'SKIP_SAVE'},
    )

    edit_rotate_degrees: FloatProperty(
        name="\u56de\u8ee2",
        min=-360.0,
        max=360.0,
        default=0.0,
        options={'SKIP_SAVE'},
    )

    active_paint_channel: EnumProperty(
        name="Active Paint Channel",
        description=bi("Channel that will become the active paint target when you click Paint Target buttons.", "ペイント対象ボタンを押したときに有効化されるチャンネルです。"),
        items=CHANNEL_ITEMS,
        default='BASE_COLOR',
    )

    layers: CollectionProperty(
        name="Layers",
        description=bi(
            "Managed Smart Paint layer collection used by the non-destructive stack.",
            "非破壊スタックで使われる Smart Paint 管理レイヤーのコレクションです。",
        ),
        type=SPSLayerItem,
    )

    resolution: EnumProperty(
        name="Texture Resolution",
        description=bi("Default resolution used for new images in this material stack.", "このマテリアルスタックで新規画像を作るときの既定解像度です。"),
        items=RESOLUTION_ITEMS,
        default='2048',
    )

    use_float_images: BoolProperty(
        name="Use Float Images",
        description=bi("Create 32-bit float images for new maps. This is useful for displacement and data channels but uses more memory.", '新規マップを32ビット浮動小数点画像で作成します。ディスプレイスメントやデータ系に有効ですが、メモリを多く使います。'),
        default=False,
    )

    use_udim: BoolProperty(
        name="Use Tiled / UDIM Images",
        description=bi("Create tiled images when possible. Basic tiled creation is supported, but exact UDIM workflows still depend on Blender's native image tools.", "可能な場合はタイル画像で作成します。基本的なタイル作成には対応しますが、厳密なUDIM運用は Blender 標準画像機能にも依存します。"),
        default=False,
    )

    multiply_ao_to_base_color: BoolProperty(
        name="Preview AO in Base Color",
        description=bi("Multiply the assembled AO result into the base color so viewport preview more closely matches common game-texture exports.", "合成したAO結果をベースカラーへ乗算し、ゲーム用書き出しに近い見た目をビューポートで確認しやすくします。"),
        default=True,
    )

    use_bump_preview: BoolProperty(
        name="Use Height as Bump Preview",
        description=bi("Feed the assembled height result into a bump node for viewport preview.", "合成した高さ結果をバンプノードへ渡してビューポート確認に使います。"),
        default=True,
    )

    global_bump_strength: FloatProperty(
        name="Global Bump Strength",
        description=bi("Master multiplier for the bump preview built from the height channel.", "高さチャンネルから作るバンプ表示の全体強度です。"),
        min=0.0,
        max=5.0,
        default=0.25,
    )

    enable_displacement_output: BoolProperty(
        name="Enable Displacement Output",
        description=bi("Connect a displacement node to the material output in addition to the bump preview. This is useful mainly in Cycles setups.", "バンプ表示に加えてマテリアル出力へディスプレイスメントも接続します。主に Cycles 向けです。"),
        default=False,
    )

    displacement_scale: FloatProperty(
        name="Displacement Scale",
        description=bi("Scale applied to the displacement output generated from the height result.", "高さ結果から作るディスプレイスメント出力に掛ける倍率です。"),
        min=0.0,
        max=5.0,
        default=0.05,
    )

    default_uv_map: StringProperty(
        name="Default UV Map",
        description=bi("Preferred UV map name for newly created layers.", "新規レイヤーで優先して使うUVマップ名です。"),
        default=DEFAULT_UV_NAME,
    )

    ao_map: StringProperty(name="AO Map", description=bi("Stored AO mesh map image name.", "保存されているAOメッシュマップ画像名です。"), default="")
    normal_map: StringProperty(name="Normal Map", description=bi("Stored normal mesh map image name.", "保存されているノーマルメッシュマップ画像名です。"), default="")
    position_map: StringProperty(name="Position Map", description=bi("Stored position mesh map image name.", "保存されている位置メッシュマップ画像名です。"), default="")
    curvature_map: StringProperty(name="Curvature Map", description=bi("Stored curvature mesh map image name.", "保存されている曲率メッシュマップ画像名です。"), default="")
    thickness_map: StringProperty(name="Thickness Map", description=bi("Stored thickness approximation map image name.", "保存されている厚み近似マップ画像名です。"), default="")

    validation_message: StringProperty(
        name="Validation Message",
        description=bi("Last validation summary message.", "最後の検証結果メッセージです。"),
        default="",
    )

    last_snapshot_text: StringProperty(
        name="Last Snapshot Text",
        description=bi(
            "Name of the Blender Text datablock that stores the latest Smart Paint stack snapshot for this material.",
            'このマテリアル向けの最新の Smart Paint スタックスナップショットを保存しているテキストデータブロック名です。',
        ),
        default="",
    )


class SPSSceneSettings(bpy.types.PropertyGroup):
    default_image_dir: StringProperty(
        name=bi("Default Image Directory", "既定画像フォルダー"),
        description=bi(
            "Directory used when Smart Paint saves images that do not have a file path yet. When left on the legacy default, the extension resolves this into its writable user_default storage area.",
            'まだ保存先がない画像を Smart Paint が保存するときに使う既定のフォルダーです。従来の既定値のままなら、拡張機能の書き込み可能な保存領域を使います。',
        ),
        subtype='DIR_PATH',
        default="//textures",
        update=_scene_settings_update,
    )

    default_resolution: EnumProperty(
        name=bi("Default Resolution", "既定解像度"),
        description=bi(
            "Default size for newly created paint images.",
            "新規ペイント画像を作るときの既定サイズです。",
        ),
        items=RESOLUTION_ITEMS,
        default='2048',
        update=_scene_settings_update,
    )

    auto_switch_to_paint: BoolProperty(
        name=bi("Auto Switch to Texture Paint", "自動でテクスチャペイントへ切替"),
        description=bi(
            "When a paint target is activated, automatically switch the active mesh into Texture Paint mode.",
            'ペイント対象を有効にしたとき、自動でテクスチャペイントモードへ切り替えます。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    auto_save_after_bake: BoolProperty(
        name=bi("Auto Save After Bake", "ベイク後に自動保存"),
        description=bi(
            "Save baked and newly generated images automatically whenever possible.",
            "可能な場合はベイクや新規生成のあとに画像を自動保存します。",
        ),
        default=False,
        update=_scene_settings_update,
    )

    debug_logging: BoolProperty(
        name=bi("Debug Logging", "デバッグログ"),
        description=bi(
            "Print additional information to the console for troubleshooting.",
            "トラブルシュート用に追加情報をコンソールへ表示します。",
        ),
        default=False,
        update=_scene_settings_update,
    )

    bake_resolution: EnumProperty(
        name="Bake Resolution",
        description=bi("Resolution for newly baked mesh maps.", "新しくベイクするメッシュマップの解像度です。"),
        items=RESOLUTION_ITEMS,
        default='2048',
        update=_scene_settings_update,
    )

    bake_margin: IntProperty(
        name="Bake Margin",
        description=bi("Pixel margin used for bake operations.", "ベイク時に使うピクセル余白です。"),
        default=DEFAULT_BAKE_MARGIN,
        min=0,
        max=64,
        update=_scene_settings_update,
    )

    bake_samples: IntProperty(
        name="Bake Samples",
        description=bi("Cycles sample count used for mesh map baking. Lower values are faster, higher values are cleaner.", "メッシュマップベイクに使う Cycles サンプル数です。少ないと高速、多いと綺麗になります。"),
        default=16,
        min=1,
        max=4096,
        update=_scene_settings_update,
    )

    selected_bake_map: EnumProperty(
        name="Selected Map",
        description=bi("Mesh map that will be baked by the generic Bake button.", '汎用のベイクボタンでベイクされるメッシュマップです。'),
        items=MESH_MAP_ITEMS,
        default='AO',
        update=_scene_settings_update,
    )

    import_directory: StringProperty(
        name="Import Directory",
        description=bi("Folder scanned when importing PBR texture sets. The legacy default resolves to the extension user_default texture area.", 'PBRテクスチャセットの読み込み時に調べるフォルダーです。従来の既定値は拡張機能のテクスチャ領域を指します。'),
        subtype='DIR_PATH',
        default="//textures",
        update=_scene_settings_update,
    )

    import_mode: EnumProperty(
        name="Import Mode",
        description=bi("Choose whether imported PBR textures fill the active layer or create a new layer.", "読み込んだPBRテクスチャをアクティブレイヤーへ割り当てるか、新規レイヤーを作るか選びます。"),
        items=IMPORT_MODE_ITEMS,
        default='NEW_LAYER',
        update=_scene_settings_update,
    )

    import_set_index: IntProperty(
        name="Import Set Index",
        description=bi(
            "When the import folder contains multiple detected PBR sets, choose which grouped set should be used by Import PBR Set.",
            '読み込みフォルダーに複数のPBRセットが見つかったとき、「PBRセットを読み込む」でどのセットを使うか選びます。',
        ),
        default=0,
        min=0,
        max=4096,
        update=_scene_settings_update,
    )

    projection_image: PointerProperty(
        name="Projection Image",
        description=bi("Image used by projection helper actions.", "投影補助アクションで使う画像です。"),
        type=bpy.types.Image,
        update=_scene_settings_update,
    )

    projection_camera: PointerProperty(
        name="Projection Camera",
        description=bi("Camera used by the projection helper. If empty, the active scene camera is used.", "投影補助で使うカメラです。空ならシーンのアクティブカメラを使います。"),
        type=bpy.types.Object,
        update=_scene_settings_update,
    )

    projection_buffer_image: PointerProperty(
        name="Projection Buffer",
        description=bi("Temporary image used by the projection buffer workflow.", "投影バッファワークフローで使う一時画像です。"),
        type=bpy.types.Image,
        update=_scene_settings_update,
    )

    projection_nudge_percent: FloatProperty(
        name="Buffer Nudge %",
        description=bi(
            "How far the projection buffer is nudged for the arrow-style 2D transforms. The value is a percentage of the current image width or height, which makes the step size resolution independent.",
            "矢印系の2D変形で投影バッファをどれくらい移動するかの割合です。現在の画像の幅または高さに対する割合なので、解像度に依存しにくい移動量になります。",
        ),
        default=0.05,
        min=0.001,
        max=0.5,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    projection_scale_percent: FloatProperty(
        name="Buffer Zoom %",
        description=bi(
            "How strongly the projection buffer is zoomed for the Scale Up / Scale Down style 2D transforms. Smaller values are gentler, larger values behave more like a strong paint-buffer crop or pull-back.",
            '拡大 / 縮小の2D変形で投影バッファをどれくらい拡大縮小するかの割合です。値が小さいと穏やかで、値が大きいと強い切り取りや引きのような補正になります。',
        ),
        default=0.1,
        min=0.01,
        max=0.5,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    sprite_sheet_image: PointerProperty(
        name="Sprite Sheet Image",
        description=bi(
            "Image treated as a sprite sheet. Frames can be extracted into projection images or active layer channels as a Blender-native approximation of sprite-sheet brush workflows.",
            "スプライトシートとして扱う画像です。フレームを切り出して投影画像やアクティブレイヤーチャンネルへ送ることで、スプライトシートブラシ系ワークフローを Blender ネイティブに近似します。",
        ),
        type=bpy.types.Image,
        update=_scene_settings_update,
    )

    sprite_sheet_columns: IntProperty(
        name="Sprite Columns",
        description=bi(
            "How many frame columns the sprite sheet contains.",
            "スプライトシートが何列のフレームで構成されているかです。",
        ),
        default=4,
        min=1,
        max=64,
        update=_scene_settings_update,
    )

    sprite_sheet_rows: IntProperty(
        name="Sprite Rows",
        description=bi(
            "How many frame rows the sprite sheet contains.",
            "スプライトシートが何行のフレームで構成されているかです。",
        ),
        default=4,
        min=1,
        max=64,
        update=_scene_settings_update,
    )

    sprite_sheet_frame: IntProperty(
        name="Sprite Frame",
        description=bi(
            "Zero-based frame index. Frame 0 is the top-left tile, then it advances left-to-right, top-to-bottom.",
            "0始まりのフレーム番号です。0 は左上タイルで、その後は左から右、上から下の順に進みます。",
        ),
        default=0,
        min=0,
        max=4095,
        update=_scene_settings_update,
    )

    projection_previous_image_name: StringProperty(
        name="Previous Projection Target",
        description=bi("Internal image name used to restore the layer channel when a projection buffer is canceled.", "投影バッファをキャンセルしたときにレイヤーチャンネルを復元するための内部画像名です。"),
        default="",
        update=_scene_settings_update,
    )

    projection_source_image_name: StringProperty(
        name="Projection Source Image",
        description=bi("Internal source image name used to reset the active projection buffer back to its original projection image.", "アクティブな投影バッファを元の投影画像へ戻すために使う内部ソース画像名です。"),
        default="",
        update=_scene_settings_update,
    )

    projection_target_layer_id: StringProperty(
        name="Projection Target Layer ID",
        description=bi("Internal layer identifier used by the projection buffer workflow.", "投影バッファワークフローで使う内部レイヤー識別子です。"),
        default="",
        update=_scene_settings_update,
    )

    projection_target_channel: EnumProperty(
        name="Projection Target Channel",
        description=bi("Layer channel currently used by the projection buffer workflow.", "投影バッファワークフローで現在使われているレイヤーチャンネルです。"),
        items=CHANNEL_ITEMS,
        default='BASE_COLOR',
        update=_scene_settings_update,
    )

    projection_previous_enabled: BoolProperty(
        name="Projection Previous Enabled",
        description=bi(
            "Internal flag storing whether the target channel was enabled before the projection buffer started.",
            "投影バッファ開始前に対象チャンネルが有効だったかを保持する内部フラグです。",
        ),
        default=False,
        update=_scene_settings_update,
    )

    projection_previous_mode: EnumProperty(
        name="Projection Previous Mode",
        description=bi(
            "Internal value used to restore the layer projection mode when a projection buffer is canceled.",
            "投影バッファをキャンセルしたときにレイヤーの投影方式を復元する内部値です。",
        ),
        items=PROJECTION_ITEMS,
        default='UV',
        update=_scene_settings_update,
    )

    projection_previous_layer_kind: EnumProperty(
        name="Projection Previous Layer Kind",
        description=bi(
            "Internal value used to restore the layer kind when a projection buffer is canceled.",
            "投影バッファをキャンセルしたときにレイヤー種別を復元する内部値です。",
        ),
        items=LAYER_KIND_ITEMS,
        default='PAINT',
        update=_scene_settings_update,
    )

    vertex_color_attribute_name: StringProperty(
        name="Vertex Color Layer",
        description=bi("Color attribute used by the vertex-color approximation workflow and by baking vertex paint back into image textures.", "頂点カラー近似ワークフローや、頂点ペイントを画像テクスチャへベイクし直す際に使うカラー属性です。"),
        default=DEFAULT_COLOR_ATTRIBUTE_NAME,
        update=_scene_settings_update,
    )

    create_missing_images_during_validation: BoolProperty(
        name="Auto Create Missing Images",
        description=bi("When Validate is executed, automatically create missing images for enabled channels when enough information is available.", '検証の実行時、必要な情報が揃っていれば有効チャンネルの不足画像を自動で作成します。'),
        default=True,
        update=_scene_settings_update,
    )

    auto_repair_paths_during_validation: BoolProperty(
        name="Auto Repair Missing Paths",
        description=bi(
            "When Validate runs, search the import, consolidate, export and known image folders for missing external textures and relink them by basename, including UDIM placeholder paths.",
            '検証の実行時、読み込み・集約・書き出しと既知の画像フォルダーを調べ、見失った外部テクスチャをファイル名で再接続します。UDIM のプレースホルダーパスも対象です。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    auto_rebuild_after_changes: BoolProperty(
        name="Auto Rebuild After Major Actions",
        description=bi("Automatically rebuild the managed material after important actions such as baking, importing or layer changes.", "ベイク・読込・レイヤー変更など重要操作のあとに管理マテリアルを自動再構築します。"),
        default=True,
        update=_scene_settings_update,
    )

    auto_pack_images: BoolProperty(
        name="Auto Pack Images",
        description=bi("Pack newly created images into the current blend file after creation or import.", "新規作成・読込した画像を現在のblendファイルへ自動パックします。"),
        default=False,
        update=_scene_settings_update,
    )

    auto_restore_on_failure: BoolProperty(
        name="Auto Restore on Failure",
        description=bi(
            "If a major Smart Paint action raises an error after an automatic snapshot was created, restore that snapshot and rebuild the managed stack automatically. This improves safety for rebuild, import, bake and export workflows, but it cannot undo external file changes or every possible image-pixel edit.",
            '主要な Smart Paint 操作で自動スナップショット作成後にエラーが出た場合、そのスナップショットを自動で復元して管理スタックを再構築します。再構築、読み込み、ベイク、書き出しの安全性を高めますが、外部ファイルの変更やすべての画像ピクセル編集までは巻き戻せません。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    auto_snapshot_major_actions: BoolProperty(
        name="Auto Snapshot Major Actions",
        description=bi(
            "Before major destructive or high-impact actions, save a JSON snapshot of the managed stack into a Blender Text datablock so the stack can be restored later.",
            '破壊的、または影響の大きい操作の前に、管理スタックのJSONスナップショットをBlenderのテキストデータブロックへ保存し、あとで復元できるようにします。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    snapshot_text_name: StringProperty(
        name="Snapshot Source",
        description=bi(
            "Optional Blender Text datablock name used as the restore source. Leave empty to use the material's last snapshot.",
            '復元元として使うテキストデータブロック名です。空の場合はマテリアルの最新スナップショットを使います。',
        ),
        default="",
        update=_scene_settings_update,
    )

    last_audit_text_name: StringProperty(
        name="Last Audit Report",
        description=bi(
            "Name of the latest Blender Text datablock generated by the Audit Report utility for quick review and reuse.",
            '監査レポートが最後に生成したテキストデータブロック名です。すぐ確認したり再利用したりするために使います。',
        ),
        default="",
        update=_scene_settings_update,
    )

    last_runtime_log_text_name: StringProperty(
        name="Runtime Log",
        description=bi(
            "Name of the latest Blender Text datablock containing a detailed Smart Paint runtime traceback and recovery notes.",
            'Smart Paint の詳しい実行エラーと復旧メモを保持する、最新のテキストデータブロック名です。',
        ),
        default="",
        update=_scene_settings_update,
    )

    checker_resolution: EnumProperty(
        name="Checker Resolution",
        description=bi("Resolution used when creating helper checker images.", "補助チェッカー画像作成時に使う解像度です。"),
        items=RESOLUTION_ITEMS,
        default='1024',
        update=_scene_settings_update,
    )

    checker_size: IntProperty(
        name="Checker Cells",
        description=bi("Approximate number of checker cells per row and column.", "チェッカーパターンの行列方向のおおよそのセル数です。"),
        default=8,
        min=2,
        max=64,
        update=_scene_settings_update,
    )

    uv_pack_margin: FloatProperty(
        name="UV Pack Margin",
        description=bi("Margin used by the Pack Islands utility.", 'アイランドのパックで使う余白です。'),
        default=0.005,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    auto_unwrap_missing_uvs: BoolProperty(
        name="Auto Unwrap Missing UVs",
        description=bi(
            "When a mesh has no meaningful UV layout yet, Smart Paint can generate a paint-ready UV unwrap automatically during Set Up Stack, Validate, or the dedicated Auto UV action.",
            'メッシュに意味のあるUVレイアウトがまだ無い場合、Smart Paint がスタックの準備、検証、または自動UVの実行時に、描画できるUV展開を自動で生成します。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    texel_density_size: IntProperty(
        name="Texel Density Size",
        description=bi(
            "Texture size used when estimating texel density in pixels per Blender unit. Use the resolution you plan to paint or export at.",
            "Blender単位あたり何ピクセルかを概算するテクセル密度計測で使うテクスチャ解像度です。実際に塗る、または書き出す予定の解像度を指定してください。",
        ),
        default=2048,
        min=16,
        max=32768,
        update=_scene_settings_update,
    )

    measured_texel_density: FloatProperty(
        name="Measured Density",
        description=bi(
            "Last measured texel density in pixels per Blender unit. This is informational and updated by the Measure Density tool.",
            '最後に計測した、Blender単位あたりのピクセル数です。情報表示用で、密度の計測ツールの実行時に更新されます。',
        ),
        default=0.0,
        min=0.0,
        precision=3,
        update=_scene_settings_update,
    )

    target_texel_density: FloatProperty(
        name="Target Density",
        description=bi(
            "Desired texel density in pixels per Blender unit. Use Set Density to scale the active UV layout toward this value.",
            '目標とするテクセル密度です。「密度を設定」を実行すると、アクティブなUVレイアウトをこの値に近づくように拡大縮小します。',
        ),
        default=512.0,
        min=0.001,
        soft_max=8192.0,
        precision=3,
        update=_scene_settings_update,
    )


    export_directory: StringProperty(
        name="Export Directory",
        description=bi(
            "Folder where flattened texture exports and packed-map exports are written. The legacy default resolves to the extension user_default export area.",
            'フラット化テクスチャとパックマップの書き出し先フォルダーです。従来の既定値は拡張機能の書き出し領域を指します。',
        ),
        subtype='DIR_PATH',
        default="//exports",
        update=_scene_settings_update,
    )

    export_set_name: StringProperty(
        name="Export Set Name",
        description=bi(
            "Optional override for the exported texture set name. Leave empty to use the active material name.",
            "書き出しテクスチャセット名の任意上書きです。空ならアクティブマテリアル名を使います。",
        ),
        default="",
        update=_scene_settings_update,
    )

    export_resolution: EnumProperty(
        name="Export Resolution",
        description=bi(
            "Resolution used for flattened export images and packed-map export images.",
            'フラット書き出し画像とパックマップ書き出し画像に使う解像度です。',
        ),
        items=RESOLUTION_ITEMS,
        default='2048',
        update=_scene_settings_update,
    )

    export_format: EnumProperty(
        name="Export Format",
        description=bi(
            "File format used when saving exported textures.",
            "書き出したテクスチャを保存するときのファイル形式です。",
        ),
        items=EXPORT_FORMAT_ITEMS,
        default='PNG',
        update=_scene_settings_update,
    )

    consolidate_directory: StringProperty(
        name="Consolidate Directory",
        description=bi(
            "Folder where the Consolidate Textures utility rewrites every image used by the active Smart Paint material. This is useful for making a project portable before archiving or handoff. The legacy default resolves to the extension user_default texture area.",
            'アクティブな Smart Paint マテリアルが使う全画像を「テクスチャを集約」で書き出し直す保存先フォルダーです。アーカイブや受け渡しの前に、プロジェクトを持ち運びやすく整える用途に向きます。従来の既定値は拡張機能のテクスチャ領域を指します。',
        ),
        subtype='DIR_PATH',
        default="//textures",
        update=_scene_settings_update,
    )

    consolidate_make_relative: BoolProperty(
        name="Make Consolidated Paths Relative",
        description=bi(
            "After consolidating textures, convert their file paths to Blender-relative paths when the current .blend file has already been saved.",
            "テクスチャ集約後、現在の .blend が保存済みであれば、その画像パスを Blender 相対パスへ変換します。",
        ),
        default=True,
        update=_scene_settings_update,
    )

    packed_export_layout: EnumProperty(
        name="Packed Layout",
        description=bi(
            "Channel layout used when exporting a packed PBR helper map.",
            'パックしたPBR補助マップを書き出すときのチャンネル配置です。',
        ),
        items=PACKED_LAYOUT_ITEMS,
        default='ORM',
        update=_scene_settings_update,
    )



    vector_shape: EnumProperty(
        name="Vector Shape",
        description=bi(
            "Parametric shape used by the vector-layer approximation tools. Use this for crisp panel lines, stitches and graphic decals.",
            "ベクトルレイヤー近似ツールで使うパラメトリック形状です。くっきりしたパネルライン、ステッチ、グラフィックデカールに使います。",
        ),
        items=VECTOR_SHAPE_ITEMS,
        default='PANEL_LINE',
        update=_scene_settings_update,
    )

    vector_resolution: EnumProperty(
        name="Vector Resolution",
        description=bi(
            "Resolution used for generated vector-mask and height helper images.",
            "生成されるベクトルマスク画像や高さ補助画像に使う解像度です。",
        ),
        items=RESOLUTION_ITEMS,
        default='1024',
        update=_scene_settings_update,
    )

    vector_color: FloatVectorProperty(
        name="Shape Color",
        description=bi(
            "Tint applied when a new vector decal layer is created.",
            "新しいベクトルデカールレイヤーを作るときに使う色です。",
        ),
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
        update=_scene_settings_update,
    )

    vector_line_width: FloatProperty(
        name="Line Width",
        description=bi(
            "Main thickness of the generated vector feature. Lower values create crisper fine details.",
            "生成するベクトル形状の主な太さです。低い値ほど細くシャープなディテールになります。",
        ),
        min=0.002,
        max=0.45,
        default=0.06,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    vector_softness: FloatProperty(
        name="Edge Softness",
        description=bi(
            "Soft falloff added to the generated shape edge. Use small values for hard-surface details and slightly higher values for fabric or painted graphics.",
            "生成形状のエッジへ加える柔らかさです。ハードサーフェスの細部には小さめ、布や描画的なグラフィックには少し高めが向きます。",
        ),
        min=0.0,
        max=0.25,
        default=0.01,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    vector_padding: FloatProperty(
        name="Padding",
        description=bi(
            "Safe empty border around the generated vector shape.",
            "生成形状の周囲に確保する安全な余白です。",
        ),
        min=0.0,
        max=0.45,
        default=0.12,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    vector_repeat: IntProperty(
        name="Repeat Count",
        description=bi(
            "How many repeated marks are generated for shapes such as stitches or stripes.",
            "ステッチやストライプのような形状で、何個の繰り返しを生成するかです。",
        ),
        min=1,
        max=128,
        default=8,
        update=_scene_settings_update,
    )

    vector_rotation: FloatProperty(
        name="Shape Rotation",
        description=bi(
            "Rotation of the generated vector shape inside the helper image.",
            "補助画像の中で生成されるベクトル形状の回転です。",
        ),
        subtype='ANGLE',
        default=0.0,
        update=_scene_settings_update,
    )

    vector_use_height: BoolProperty(
        name="Add Height Detail",
        description=bi(
            "Generate a matching height image in addition to the mask so the shape can indent or emboss the surface. This is useful for panel lines and seams.",
            "マスクに加えて対応する高さ画像も生成し、形状で表面を彫り込んだり浮かせたりします。パネルラインや縫い目に有効です。",
        ),
        default=False,
        update=_scene_settings_update,
    )

    vector_height_strength: FloatProperty(
        name="Height Strength",
        description=bi(
            "Strength applied to the generated height image when a new vector decal layer is created.",
            "新しいベクトルデカールレイヤー作成時に、生成高さ画像へ掛ける強度です。",
        ),
        min=0.0,
        max=5.0,
        default=0.2,
        update=_scene_settings_update,
    )

    vector_height_invert: BoolProperty(
        name="Invert Height",
        description=bi(
            "Invert the generated height so lines become carved grooves instead of raised details.",
            "生成高さを反転し、線を盛り上げではなく彫り込みの溝として使います。",
        ),
        default=True,
        update=_scene_settings_update,
    )

    last_imported_set_label: StringProperty(
        name="Last Imported PBR Set",
        description=bi(
            "Human-readable label of the last imported PBR set for quick verification.",
            "最後に読み込んだ PBR セットの確認用ラベルです。",
        ),
        default="",
        update=_scene_settings_update,
    )

    last_import_summary: StringProperty(
        name="Last Import Summary",
        description=bi(
            "Compact summary of the most recent PBR import operation, including how many sets or channels were detected.",
            "最後の PBR 読み込み結果の要約です。検出したセット数やチャンネル数の確認に使えます。",
        ),
        default="",
        update=_scene_settings_update,
    )

    last_external_edit_image_name: StringProperty(
        name="Last External Edit",
        description=bi(
            "Name of the last image opened for external editing. This is used by the quick reload helpers so round-trip paint edits are easier to manage.",
            "最後に外部編集で開いた画像名です。再読込補助が参照し、往復編集を管理しやすくします。",
        ),
        default="",
        update=_scene_settings_update,
    )

    preview_light_energy: FloatProperty(
        name="Preview Light Energy",
        description=bi(
            "Energy used by the quick preview-light rig. Increase this when checking roughness, normals, or decals on darker materials.",
            'クイック確認用ライトの強さです。暗いマテリアルでラフネス、ノーマル、デカールを確認するときに上げてください。',
        ),
        min=10.0,
        max=50000.0,
        default=1500.0,
        update=_scene_settings_update,
    )

    height_preview_levels: IntProperty(
        name="Preview Levels",
        description=bi(
            "Subdivision levels used by the Microvertex / Height Preview helper. Higher values show smoother displacement but use more memory and can become heavy very quickly.",
            '高さプレビューの補助で使う細分割レベルです。高いほど滑らかなディスプレイスメントになりますが、メモリ消費が増え、すぐ重くなります。',
        ),
        default=2,
        min=0,
        max=6,
        update=_scene_settings_update,
    )

    height_preview_strength: FloatProperty(
        name="Preview Strength",
        description=bi(
            "Displacement strength used by the mesh preview helper. This is separate from the shader preview so you can exaggerate or reduce the geometry preview without changing the final material stack settings.",
            "メッシュプレビュー補助で使うディスプレイスメント強度です。シェーダープレビューとは独立しているため、最終マテリアル設定を変えずに、ジオメトリ確認だけ強めたり弱めたりできます。",
        ),
        default=0.05,
        min=-10.0,
        max=10.0,
        update=_scene_settings_update,
    )

    height_preview_midlevel: FloatProperty(
        name="Preview Midlevel",
        description=bi(
            "Midlevel used by the displace preview. 0.5 is a good default for typical grayscale height maps where mid-gray means no displacement.",
            "ディスプレイスプレビューで使うミッドレベルです。一般的なグレースケール高さマップでは、0.5 を基準にすると中間グレーが変位なしとして扱われやすくなります。",
        ),
        default=0.5,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_scene_settings_update,
    )


    smart_workflow_profile: EnumProperty(
        name=bi("Smart Profile", "Smartプロファイル"),
        description=bi(
            "Workflow profile used by Smart Paint when building upgraded-equivalent texture-painting setups.",
            'Smart Paint が上位互換相当のテクスチャペイント環境を構築するときに使うワークフロープロファイルです。',
        ),
        items=[
            ('STUDIO_PBR', 'Studio PBR Smart Stack', bi('Balanced PBR stack with layers, anchors, masks, anti-tiling and projection readiness.', 'レイヤー、アンカー、マスク、アンチタイリング、投影準備を含むバランス型PBRスタックです。')),
            ('GAME_FAST', 'Game Asset Fast Prep', bi('Fast game-asset preparation for UVs, mesh maps, vertex baking and export-safe PBR channels.', 'UV、メッシュマップ、頂点ベイク、書き出し向きPBRチャンネルを素早く準備するゲームアセット向けプロファイルです。')),
            ('VFX_UDIM', 'VFX UDIM Projection Stack', bi('UDIM, high-bit image, projection-buffer and material-ingest oriented setup.', 'UDIM、高ビット画像、投影バッファ、マテリアル取込を重視したプロファイルです。')),
            ('CONCEPT_SMART', 'Concept / AI-Ready Stack', bi('Prompt metadata, semantic layers, stylized procedural detail and splat/decal helpers.', 'プロンプトメタデータ、意味別レイヤー、スタイライズ生成ディテール、スプラット/デカール補助向けです。')),
            ('ILLUSTRATION_2D', '2D Creator / advanced image editor-Smart Paint Studio Smart Stack', bi('advanced image editor, advanced illustration software, painting editor, painting editor and design editor-style 2D creator workflow for masks, adjustments, selections, inking, comics and animation.', '高機能な画像編集・イラストソフト風の2D制作ワークフローです。マスク、調整、選択、線画、漫画、アニメーションを扱います。')),
            ('SUPERIOR_PRODUCTION', 'Superior Production Stack', bi('Highest-density production profile with preflight, PBR foundation, anchors, weathering, anti-tiling, semantic metadata, 2D creator support and precision refinement.', '事前診断、PBR土台、アンカー、ウェザリング、反復軽減、意味メタデータ、2D制作補助、精度調整を含む最高密度の制作プロファイルです。')),
        ],
        default='STUDIO_PBR',
        update=_scene_settings_update,
    )

    smart_resolution: EnumProperty(
        name=bi("Smart Resolution", "Smart解像度"),
        description=bi(
            "Default image resolution used by Smart Paint-generated layers, projection sources, semantic scaffolds and bridge metadata.",
            'Smart Paint が生成するレイヤー、投影ソース、意味別土台、ブリッジメタデータで使う既定画像解像度です。',
        ),
        items=RESOLUTION_ITEMS,
        default='2048',
        update=_scene_settings_update,
    )

    smart_use_float_images: BoolProperty(
        name=bi("Smart Float Images", "Smart浮動小数画像"),
        description=bi(
            "Create high-bit float images for Smart Paint height, displacement and VFX-style setups when supported.",
            'Smart Paint の高さ、ディスプレイスメント、VFX系セットアップで、対応時に高ビット浮動小数画像を作成します。',
        ),
        default=False,
        update=_scene_settings_update,
    )

    smart_random_seed: IntProperty(
        name=bi("Smart Seed", "Smartシード"),
        description=bi(
            "Seed value used by Smart Paint randomized splat, texture bombing and semantic layer variations.",
            'Smart Paint のランダムスプラット、テクスチャボンビング、意味別レイヤー変化に使うシード値です。',
        ),
        default=17,
        min=-100000,
        max=100000,
        update=_scene_settings_update,
    )

    smart_bombing_strength: FloatProperty(
        name=bi("Smart Bombing Strength", "Smartボンビング強度"),
        description=bi(
            "Strength used by Smart Paint anti-tiling texture bombing equivalents. Higher values break repetition more aggressively.",
            'Smart Paint のアンチタイリング・テクスチャボンビング相当機能で使う強度です。高いほど反復を強く崩します。',
        ),
        default=0.22,
        min=0.0,
        max=2.0,
        update=_scene_settings_update,
    )

    smart_bombing_cell_scale: FloatProperty(
        name=bi("Smart Bombing Cell Scale", "Smartボンビングセルスケール"),
        description=bi(
            "Cell scale used by Smart Paint anti-tiling and splat-stamp equivalents. Lower values create broader breakup; higher values create finer variation.",
            'Smart Paint のアンチタイリングやスプラットスタンプ相当機能で使うセルスケールです。低い値は広い崩し、高い値は細かな変化になります。',
        ),
        default=5.0,
        min=0.25,
        max=128.0,
        update=_scene_settings_update,
    )

    smart_height_blend_balance: FloatProperty(
        name=bi("Smart Height Blend Balance", "Smart高さブレンドバランス"),
        description=bi(
            "Height-blend balance used by Smart Paint carve-group and microvertex-style equivalents.",
            "Smart Paint のカーブグループやマイクロバーテックス風上位互換で使う高さブレンドのバランスです。",
        ),
        default=1.0,
        min=0.0,
        max=4.0,
        update=_scene_settings_update,
    )

    smart_color_attribute_name: StringProperty(
        name=bi("Smart Color Attribute", "Smartカラー属性"),
        description=bi(
            "Color attribute name used by Smart Paint Vertex Oven, Ptex proxy and Polypaint proxy workflows.",
            'Smart Paint の頂点ベイク、Ptex近似、ポリペイント近似のワークフローで使うカラー属性名です。',
        ),
        default="SPS_Smart_VertexBake",
        update=_scene_settings_update,
    )

    smart_source_directory: StringProperty(
        name=bi("Smart Source Directory", "Smartソースフォルダー"),
        description=bi(
            "Optional manual source directory for Smart Paint material ingest. Leave empty to use the extension user_default staging folder.",
            'Smart Paint のマテリアル取り込みで使う任意の手動ソースフォルダーです。空欄の場合は拡張機能の保存領域を使います。',
        ),
        subtype='DIR_PATH',
        default="",
        update=_scene_settings_update,
    )

    smart_bridge_directory: StringProperty(
        name=bi("Smart Bridge Directory", "Smartブリッジフォルダー"),
        description=bi(
            "Optional manual bridge directory for USD/AppLink-style handoff manifests. Leave empty to keep generated files inside extension user_default storage.",
            'USD などの受け渡しマニフェストで使う任意の手動ブリッジフォルダーです。空欄の場合は生成ファイルを拡張機能の保存領域へ収めます。',
        ),
        subtype='DIR_PATH',
        default="",
        update=_scene_settings_update,
    )

    smart_prompt: StringProperty(
        name=bi("Smart Prompt", "Smartプロンプト"),
        description=bi(
            "Prompt or material brief used by Smart Paint semantic/AI-ready scaffolds. No external AI service is contacted by this add-on.",
            'Smart Paint の意味別/AI準備用土台で使うプロンプトまたはマテリアル指示文です。このアドオンは外部AIサービスへ接続しません。',
        ),
        default="weathered painted metal, edge wear, cavity dirt, fine scratches",
        update=_scene_settings_update,
    )

    smart_negative_prompt: StringProperty(
        name=bi("Smart Negative Prompt", "Smart除外プロンプト"),
        description=bi(
            "Negative prompt or exclusion notes stored in Smart Paint prompt/bridge metadata for external AI or review workflows.",
            '外部AIやレビュー用ワークフローへ渡す Smart Paint のプロンプト/ブリッジメタデータに保存される除外プロンプトまたは除外メモです。',
        ),
        default="low resolution, visible seams, stretched projection, muddy material response",
        update=_scene_settings_update,
    )

    smart_2d_canvas_resolution: EnumProperty(
        name=bi("2D Canvas Resolution", "2Dキャンバス解像度"),
        description=bi(
            "Default image resolution used by Smart Paint 2D creator equivalents such as masks, selection channels, screen tones and retouch layers.",
            'Smart Paint の2D制作系上位互換で使う既定画像解像度です。マスク、選択チャンネル、スクリーントーン、レタッチレイヤーなどに使用します。',
        ),
        items=RESOLUTION_ITEMS,
        default='2048',
        update=_scene_settings_update,
    )

    smart_2d_stabilization: FloatProperty(
        name=bi("2D Stabilization", "2D手ブレ補正"),
        description=bi(
            "Stroke stabilization strength used by Smart Paint vector ink and retouch brush presets. Higher values create smoother but slower-feeling strokes.",
            'Smart Paint のベクター線画やレタッチブラシプリセットで使う手ブレ補正強度です。高い値ほど滑らかになりますが、反応は重く感じやすくなります。',
        ),
        default=0.55,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    smart_2d_gap_close: FloatProperty(
        name=bi("2D Gap Close", "2D隙間閉じ"),
        description=bi(
            "Threshold used by the reference-layer close-gap fill equivalent. Increase it when line art has small breaks; decrease it when fills leak into neighboring areas.",
            "参照レイヤー式の隙間閉じ塗り上位互換で使うしきい値です。線画に小さな切れ目がある場合は上げ、隣接領域へ漏れる場合は下げます。",
        ),
        default=0.35,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    smart_2d_selection_feather: FloatProperty(
        name=bi("2D Selection Feather", "2D選択フェザー"),
        description=bi(
            "Feather amount stored in selection-channel and quick-mask metadata. Use low values for hard comic flats and higher values for photo or painted masks.",
            "選択チャンネルとクイックマスクのメタデータに保存するフェザー量です。漫画のベタ塗りには低め、写真補正やペイントマスクには高めが適します。",
        ),
        default=2.0,
        min=0.0,
        max=128.0,
        update=_scene_settings_update,
    )

    smart_2d_tone_lpi: IntProperty(
        name=bi("2D Tone LPI", "2Dトーン線数"),
        description=bi(
            "Screen-tone line density metadata used by the comic tone equivalent. It is stored in the manifest and used to label generated tone images.",
            "漫画トーン上位互換で使うスクリーントーン線数メタデータです。マニフェストへ保存され、生成トーン画像の識別に使われます。",
        ),
        default=60,
        min=5,
        max=240,
        update=_scene_settings_update,
    )

    smart_2d_tone_angle: FloatProperty(
        name=bi("2D Tone Angle", "2Dトーン角度"),
        description=bi(
            "Screen-tone angle metadata used by the comic tone equivalent. 45 degrees is a common starting point for monochrome print-style tones.",
            "漫画トーン上位互換で使うスクリーントーン角度メタデータです。モノクロ印刷風トーンでは45度が一般的な開始値です。",
        ),
        default=45.0,
        min=-180.0,
        max=180.0,
        update=_scene_settings_update,
    )

    smart_2d_timeline_frames: IntProperty(
        name=bi("2D Timeline Frames", "2Dタイムラインフレーム数"),
        description=bi(
            "Frame count used by the timeline/onion-skin equivalent. The operator sets the scene frame range and creates editable onion-skin guide layers.",
            "タイムライン/オニオンスキン上位互換で使うフレーム数です。実行時にシーンのフレーム範囲を設定し、編集可能なオニオンスキン補助レイヤーを作成します。",
        ),
        default=24,
        min=1,
        max=240,
        update=_scene_settings_update,
    )

    smart_2d_reference_layer_name: StringProperty(
        name=bi("2D Reference Layer", "2D参照レイヤー"),
        description=bi(
            "Name of the most recent reference line layer created by the Smart Paint reference fill / gap-close tool.",
            'Smart Paint の参照塗り/隙間閉じ機能が最後に作成した参照線レイヤー名です。',
        ),
        default="",
        update=_scene_settings_update,
    )

    smart_2d_palette_name: StringProperty(
        name=bi("2D Palette Name", "2Dパレット名"),
        description=bi(
            "Palette name written to Smart Paint 2D material/brush library manifests. Use it to distinguish project-specific color and brush sets.",
            'Smart Paint の2D素材/ブラシライブラリマニフェストへ記録するパレット名です。プロジェクト別の色・ブラシセットを区別するために使います。',
        ),
        default="SPS Creator Palette",
        update=_scene_settings_update,
    )

    smart_2d_last_manifest_path: StringProperty(
        name=bi("Last 2D Manifest", "最新2Dマニフェスト"),
        description=bi(
            "File path of the latest Smart Paint 2D creator manifest. It is stored in user_default unless an explicit manual bridge/source directory is used by another tool.",
            'Smart Paint の2D制作機能が最後に生成したマニフェストのファイルパスです。ほかの機能で手動のブリッジ / ソースフォルダーを使う場合を除き、拡張機能の保存領域へ保存されます。',
        ),
        default="",
        update=_scene_settings_update,
    )



    smart_quality_mode: EnumProperty(
        name=bi("Smart Quality Mode", "Smart品質モード"),
        description=bi(
            "Controls how aggressively Smart Paint analyzes, builds and refines layers. Performance is lighter; Production and VFX prioritize fidelity, higher resolution floors and stronger finishing passes.",
            'Smart Paint が解析、構築、精度調整をどれだけ強く行うかを制御します。パフォーマンスは軽量、プロダクションとVFXは精度、高い解像度下限、強い仕上げパスを優先します。',
        ),
        items=[
            ('PERFORMANCE', 'Performance / Fast', bi('Lower-density setup for quick iteration and weaker hardware.', '素早い反復と軽めの環境向けの低密度設定です。')),
            ('BALANCED', 'Balanced Production', bi('Balanced density and responsiveness for most assets.', '多くのアセットに適した密度と応答性のバランスです。')),
            ('PRODUCTION', 'Production High Fidelity', bi('Higher-density finishing pass for hero/game assets.', 'ヒーローアセットやゲーム本番素材向けの高密度仕上げです。')),
            ('VFX', 'VFX / UDIM Fidelity', bi('Highest fidelity for UDIM, displacement and lookdev-style work.', 'UDIM、ディスプレイスメント、ルックデブ向けの最高精度です。')),
            ('PRINT_2D', '2D Print / Illustration Clean', bi('Cleaner 2D mask, tone and line-art behavior for illustration and comic workflows.', 'イラスト・漫画向けに、2Dマスク、トーン、線画をきれいに扱う設定です。')),
        ],
        default='BALANCED',
        update=_scene_settings_update,
    )

    smart_detail_density: FloatProperty(
        name=bi("Smart Detail Density", "Smartディテール密度"),
        description=bi(
            "Multiplier for procedural detail, splat/decal count, refinement strength and anti-tiling variation. Increase for hero assets; decrease for speed.",
            "プロシージャルディテール、スプラット/デカール数、精度調整強度、反復軽減変化の倍率です。ヒーローアセットでは上げ、速度優先では下げます。",
        ),
        default=1.25,
        min=0.10,
        max=4.0,
        update=_scene_settings_update,
    )

    smart_mask_edge_softness: FloatProperty(
        name=bi("Smart Mask Edge Softness", "Smartマスクエッジ柔らかさ"),
        description=bi(
            "Softness bias used by precision refinement when normalizing smart masks, selection proxies and 2D/3D paint transitions.",
            "スマートマスク、選択近似、2D/3Dペイント境界を精度調整で整える際のエッジの柔らかさです。",
        ),
        default=0.18,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_scene_settings_update,
    )

    smart_live_preflight: BoolProperty(
        name=bi("Live Preflight", "ライブ事前診断"),
        description=bi(
            "Show a compact quality score and important warnings directly in the Smart Paint panel while you work.",
            '作業中に Smart Paint パネルへ品質スコアと重要警告を簡潔に表示します。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    smart_ui_compact: BoolProperty(
        name=bi("Compact Smart UI", "コンパクトSmart UI"),
        description=bi(
            "Use denser two-column feature buttons in Smart Paint child panels. Disable it when you prefer larger one-button-per-row controls.",
            'Smart Paint の子パネルで2列の高密度ボタン表示を使います。1行1ボタンの大きな操作感を優先する場合は無効にします。',
        ),
        default=False,
        update=_scene_settings_update,
    )

    smart_ui_icon_mode: EnumProperty(
        name=bi("Smart Icon UI Mode", "SmartアイコンUIモード"),
        description=bi(
            "Controls the Smart Paint button presentation. Icon Cards uses large borderless generated pictograms; Hybrid keeps compact text buttons with custom icons; Text uses the classic Blender text-heavy controls.",
            'Smart Paint のボタン表示方式です。アイコンカードは枠無しの大きな絵文字、ハイブリッドはカスタムアイコン付きの省スペースボタン、テキストは従来の文字中心の表示です。',
        ),
        items=[
            ('ICON_CARDS', 'Icon Cards / Large', bi('Large borderless generated icon cards with the maximum preview size Blender UI allows.', 'Blender UIで可能な最大級のプレビューサイズを使う、枠無し大型生成アイコンカードです。')),
            ('HYBRID', 'Hybrid Icons + Text', bi('Custom generated icons with normal text buttons for balanced speed and readability.', '生成カスタムアイコンと通常テキストボタンを併用し、速度と視認性を両立します。')),
            ('TEXT', 'Text Only / Classic', bi('Classic text-heavy Blender controls with built-in fallback icons.', '従来型の文字中心Blender操作子と内蔵フォールバックアイコンです。')),
        ],
        default='ICON_CARDS',
        update=_scene_settings_update,
    )

    smart_icon_scale: FloatProperty(
        name=bi("Smart Icon Scale", "Smartアイコン倍率"),
        description=bi(
            "Preview scale for generated Smart Paint icon cards. Increase it when the pictograms feel small; the images themselves have no border and fill the tile as much as possible.",
            'Smart Paint の生成アイコンカードのプレビュー倍率です。図形が小さく感じる場合に上げます。画像自体は枠無しで、タイル内を可能な限り大きく占めるよう作成されています。',
        ),
        default=4.6,
        min=2.0,
        max=8.0,
        update=_scene_settings_update,
    )

    smart_show_reference_hints: BoolProperty(
        name=bi("Show Smart Reference Hints", "Smart参照ヒントを表示"),
        description=bi(
            "Shows concise guidance and enables the generated reference-atlas command in Smart Paint. The atlas is bundled in the extension, not generated in an external folder.",
            'Smart Paint に簡潔な操作ヒントと生成済みリファレンスアトラス表示コマンドを出します。アトラスは拡張機能内に同梱され、外部フォルダーへ自動生成されません。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    smart_superior_include_2d: BoolProperty(
        name=bi("Superior Includes 2D", "最上位に2Dを含める"),
        description=bi(
            "Include advanced image editor/advanced creator 2D creator layers, masks and brush-library metadata when running Superior One-Click Setup or the Superior Production profile.",
            '最上位セットアップまたは上位プロダクションプロファイルの実行時に、2D制作用のレイヤー、マスク、ブラシライブラリのメタデータを含めます。',
        ),
        default=True,
        update=_scene_settings_update,
    )

    smart_quality_score: IntProperty(
        name=bi("Smart Quality Score", "Smart品質スコア"),
        description=bi(
            "Latest Smart Paint quality score from 0 to 100. It is generated by Analyze, Recommended Pass or Refine All and saved with the N-panel settings.",
            'Smart Paint の最新品質スコアです。0から100で表示され、解析、推奨パス、全体を高精度化で生成され、Nパネル設定として保存されます。',
        ),
        default=0,
        min=0,
        max=100,
        update=_scene_settings_update,
    )

    smart_quality_grade: StringProperty(
        name=bi("Smart Quality Grade", "Smart品質グレード"),
        description=bi(
            "Latest Smart Paint quality grade. S/A/B/C/D indicates how complete the current layer, mask, channel, UV and report setup is.",
            'Smart Paint の最新品質グレードです。S/A/B/C/Dで、現在のレイヤー、マスク、チャンネル、UV、レポート構成の完成度を示します。',
        ),
        default="-",
        update=_scene_settings_update,
    )

    smart_last_quality_report: StringProperty(
        name=bi("Last Quality Report", "最新品質レポート"),
        description=bi(
            "Name of the latest Text datablock generated by the Smart Paint quality analyzer or refinement pass.",
            'Smart Paint の品質解析または高精度化パスが最後に生成したテキストデータブロック名です。',
        ),
        default="",
        update=_scene_settings_update,
    )


    smart_last_quality_report_path: StringProperty(
        name=bi("Last Quality Report Path", "最新品質レポートパス"),
        description=bi(
            "File path of the latest Smart Paint quality JSON report. It is written under user_default storage.",
            '最後に生成された Smart Paint 品質JSONレポートのファイルパスです。拡張機能の保存領域へ書き出されます。',
        ),
        default="",
        update=_scene_settings_update,
    )

    smart_last_report_text_name: StringProperty(
        name=bi("Last Smart Report", "最新Smartレポート"),
        description=bi(
            "Name of the latest Text datablock generated by Smart Paint coverage, prompt or bridge tools.",
            'Smart Paint の対応表、プロンプト、ブリッジ機能が最後に生成したテキストデータブロック名です。',
        ),
        default="",
        update=_scene_settings_update,
    )

    smart_last_bridge_path: StringProperty(
        name=bi("Last Smart Bridge Path", "最新Smartブリッジパス"),
        description=bi(
            "File path of the latest Smart Paint bridge manifest. It is stored in user_default unless a manual bridge directory is set.",
            'Smart Paint が最後に生成したブリッジマニフェストのファイルパスです。手動のブリッジフォルダーが未指定なら拡張機能の保存領域へ保存されます。',
        ),
        default="",
        update=_scene_settings_update,
    )

    last_info_message: StringProperty(
        name="Last Info Message",
        description=bi("Last informational message generated by the add-on.", "アドオンが最後に生成した情報メッセージです。"),
        default="",
        update=_scene_settings_update,
    )


CLASSES = (
    SPSBrushstrokeStyleItem,
    SPSBrushstrokeToolPreferences,
    SPSGreasePencilTimelineSettings,
    SPSGreasePencilLayerNavigatorSettings,
    SPSGreasePencilToolPreferences,
    SPSPaintSystemToolPreferences,
    SPSTexturesAutosaveToolPreferences,
    SPSUcupaintToolPreferences,
    SPSAddonPreferences,
    SPSLayerItem,
    SPSMaterialSettings,
    SPSSceneSettings,
)


def register_properties(transaction=None):
    """Acquire Suite PointerProperties through the root transaction only.

    The compatibility entry remains importable for legacy callers, but it no
    longer searches ``bpy.types``, unregisters a prior generation, or assigns
    unjournaled RNA.  Class registration must precede this call.
    """
    if transaction is None or not hasattr(transaction, "add_rna_property_factory"):
        raise RuntimeError("Smart Paint RNA properties require the active registration transaction")
    transaction.add_rna_property_factory(
        bpy.types.Material,
        "smart_paint_suite",
        lambda: PointerProperty(type=SPSMaterialSettings),
        kind="pointer_property",
    )
    transaction.add_rna_property_factory(
        bpy.types.Scene,
        "smart_paint_suite",
        lambda: PointerProperty(type=SPSSceneSettings),
        kind="pointer_property",
    )
    transaction.add_rna_property_factory(
        bpy.types.WindowManager,
        "smart_paint_suite_runtime_preferences",
        lambda: PointerProperty(type=SPSAddonPreferences),
        kind="pointer_property",
    )
    return True


def unregister_properties():
    """Reject partial RNA teardown; the generation journal owns teardown."""
    raise RuntimeError("Smart Paint PointerProperties are released only by root unregister()")
