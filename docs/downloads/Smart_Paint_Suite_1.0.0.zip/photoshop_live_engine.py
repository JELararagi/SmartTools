# SPDX-License-Identifier: GPL-3.0-or-later
"""Pass per-layer metadata updates to the active Photoshop lease."""

from time import time


def _connected(state):
    return state.get("backend") == "PHOTOSHOP" and bool(state.get("connected"))


def is_running_for_context(_context=None):
    from .external_bridge import session

    return _connected(session.snapshot())


def queue_layer_command(context, command_type, *, layer_id, **payload):
    from .external_bridge import session

    if not _connected(session.snapshot()):
        return False, "photoshop_bridge_not_connected"
    operation = str(command_type or "")
    layer = str(layer_id or "")
    if not (operation and layer):
        return False, "invalid_layer_command"
    scalars = (str, bool, int, float, type(None))
    reply = session.queue_layer_command({
        "created_at": time(),
        "type": operation,
        "layer_id": layer,
        "payload": {str(name): argument for name, argument in payload.items()
                    if isinstance(argument, scalars)},
    })
    return bool(reply.get("ok")), str(reply.get("reason") or "")


def clear_commands():
    # Commands are owned by the external session, with no second local queue.
    return None


__all__ = ("clear_commands", "is_running_for_context", "queue_layer_command")
