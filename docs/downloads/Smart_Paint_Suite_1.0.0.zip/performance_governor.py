# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Operation-scoped Smart Paint performance policy.

The governor is deliberately passive.  It does not patch ``bpy.app.timers``,
remove handlers/msgbus owners, alter process priority, inject status-bar draw
callbacks, or mutate resources owned by other modules.  Callers opt into a
finite operation scope and explicitly own every timer they create.
"""
from __future__ import annotations

from contextlib import contextmanager, nullcontext
import os
import threading
import time
from typing import Any, Iterator

_LOCK = threading.RLock()
_ACTIVE: dict[str, int] = {}
_PENDING: dict[str, int] = {}
_LAST_ACTIVITY = 0.0
_STATUS: dict[str, str] = {}


def logical_cpu_count() -> int:
    return max(1, int(os.cpu_count() or 1))


def _increment(mapping: dict[str, int], key: str, amount: int) -> None:
    value = int(mapping.get(key, 0)) + int(amount)
    if value > 0:
        mapping[key] = value
    else:
        mapping.pop(key, None)


def mark_activity(kind: str = "operation") -> None:
    global _LAST_ACTIVITY
    del kind
    with _LOCK:
        _LAST_ACTIVITY = time.monotonic()


def active(kind: str | None = None) -> bool:
    with _LOCK:
        if kind is None:
            return bool(_ACTIVE or _PENDING)
        key = str(kind)
        return bool(_ACTIVE.get(key, 0) or _PENDING.get(key, 0))


def recently_active(seconds: float = 0.25) -> bool:
    with _LOCK:
        return bool(active() or (time.monotonic() - _LAST_ACTIVITY) <= max(0.0, float(seconds)))


@contextmanager
def burst_scope(kind: str = "operation") -> Iterator[None]:
    key = str(kind or "operation")
    with _LOCK:
        _increment(_ACTIVE, key, 1)
        mark_activity(key)
    try:
        yield
    finally:
        with _LOCK:
            _increment(_ACTIVE, key, -1)
            mark_activity(key)


def begin_pending_job(kind: str = "operation") -> None:
    key = str(kind or "operation")
    with _LOCK:
        _increment(_PENDING, key, 1)
        mark_activity(key)


def finish_pending_job(kind: str = "operation") -> None:
    key = str(kind or "operation")
    with _LOCK:
        _increment(_PENDING, key, -1)
        mark_activity(key)


def has_pending_jobs() -> bool:
    with _LOCK:
        return bool(_PENDING)


def begin_status(kind: str, text: str | None = None, **_kwargs) -> None:
    with _LOCK:
        _STATUS[str(kind)] = str(text or kind)


def end_status(kind: str, **_kwargs) -> None:
    with _LOCK:
        _STATUS.pop(str(kind), None)


def clear_status() -> None:
    with _LOCK:
        _STATUS.clear()


def current_status_text() -> str:
    with _LOCK:
        return next(reversed(_STATUS.values()), "") if _STATUS else ""


@contextmanager
def status_scope(kind: str, text: str | None = None, **kwargs) -> Iterator[None]:
    begin_status(kind, text, **kwargs)
    try:
        yield
    finally:
        end_status(kind)


@contextmanager
def allow_timer_scope(_kind: str = "operation") -> Iterator[None]:
    # Ownership remains explicit at the caller.  No global timer API is patched.
    yield


def strict_zero_idle_enabled() -> bool:
    return True


def finalize_operation_zero_idle(*_args, **_kwargs) -> None:
    mark_activity("finalize")


def null_scope():
    return nullcontext()


def available_memory_bytes() -> int:
    try:
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        return max(0, page_size * pages)
    except (AttributeError, OSError, ValueError):
        return 2 * 1024 * 1024 * 1024


def enabled_pixel_layer_count(layers) -> int:
    count = 0
    for layer in tuple(layers or ()):
        try:
            if bool(layer.get("enabled", True)) and not bool(layer.get("is_group", False)):
                count += 1
        except (AttributeError, TypeError):
            count += 1
    return count


def temporary_array_cache_budget_bytes() -> int:
    """Return the operation-local share of the one Suite memory budget.

    Temporary projection arrays are never granted an independent 512 MiB pool.
    Their conservative allowance is the unoccupied part of the shared cache
    budget, capped at 96 MiB, and drops to zero under memory pressure.
    """
    try:
        from . import resource_quota

        if available_memory_bytes() < resource_quota.MEMORY_PRESSURE_FREE_BYTES:
            resource_quota.clear_all_memory(reason="memory_pressure")
            return 0
        stats = resource_quota.memory_stats()
        remaining = max(
            0,
            int(resource_quota.GLOBAL_MEMORY_CACHE_BYTES)
            - int(stats.get("retained_bytes", 0) or 0),
        )
        return int(min(96 * 1024 * 1024, remaining))
    except (ImportError, AttributeError, TypeError, ValueError):
        return 64 * 1024 * 1024


def full_projection_allowed(width: int = 0, height: int = 0, layers=None, **_kwargs) -> bool:
    pixels = max(0, int(width)) * max(0, int(height))
    layer_count = max(1, enabled_pixel_layer_count(layers))
    estimated = pixels * 4 * 4 * min(layer_count, 4)
    return estimated <= temporary_array_cache_budget_bytes()


def dirty_region_direct_write_allowed(width: int = 0, height: int = 0, rect=None, **_kwargs) -> bool:
    if rect is None:
        return False
    try:
        x0, y0, x1, y1 = [int(value) for value in rect[:4]]
    except (TypeError, ValueError, IndexError):
        return False
    total = max(1, int(width) * int(height))
    area = max(0, x1 - x0) * max(0, y1 - y0)
    return 0 < area <= total // 2


def composite_chunk_pixels(width: int = 0, height: int = 0, layers=None, remaining: int = 0, **_kwargs) -> int:
    total = max(1, int(width) * int(height))
    target = min(total, 262_144 if enabled_pixel_layer_count(layers) <= 8 else 131_072)
    if remaining:
        target = min(target, max(1, int(remaining)))
    return max(1, target)


def composite_time_budget_seconds() -> float:
    return 0.020


def active_timer_interval() -> float:
    return 0.020


def idle_timer_stop_after_ticks(_selection_active: bool = False) -> int:
    # Zero means a caller must not keep a periodic scanner alive while idle.
    return 0


def force_status_refresh(*_args, **_kwargs) -> None:
    return None


def force_status_bar_update(*_args, **_kwargs) -> None:
    return None


__all__ = (
    "active", "active_timer_interval", "allow_timer_scope",
    "available_memory_bytes", "begin_pending_job", "begin_status",
    "burst_scope", "clear_status", "composite_chunk_pixels",
    "composite_time_budget_seconds", "current_status_text",
    "dirty_region_direct_write_allowed", "enabled_pixel_layer_count", "end_status",
    "finalize_operation_zero_idle", "finish_pending_job",
    "full_projection_allowed", "has_pending_jobs", "idle_timer_stop_after_ticks",
    "logical_cpu_count", "mark_activity", "null_scope", "recently_active",
    "status_scope", "strict_zero_idle_enabled",
    "temporary_array_cache_budget_bytes",
)
