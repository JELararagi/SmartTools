# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Paint-job accounting and limits for compositor work owned by this suite."""

from collections import Counter
from contextlib import contextmanager, nullcontext
import os
from threading import Lock
from time import monotonic

_MIB = 1024**2
_SLICE_SECONDS = 1 / 50
_guard = Lock()
_counts = Counter()
_labels = {}
_activity = 0.0


def _change(queue, kind, amount):
    global _activity
    token = queue, str(kind or "operation")
    with _guard:
        updated = _counts[token] + amount
        if updated <= 0:
            _counts.pop(token, None)
        else:
            _counts[token] = updated
        _activity = monotonic()


def mark_activity(kind="operation"):
    global _activity
    with _guard:
        _activity = monotonic()


def active(kind=None):
    with _guard:
        return bool(_counts) if kind is None else any(key == str(kind) for _, key in _counts)


def recently_active(seconds=0.25):
    with _guard:
        return bool(_counts) or monotonic() - _activity <= max(0.0, float(seconds))


@contextmanager
def burst_scope(kind="operation"):
    _change("immediate", kind, 1)
    try:
        yield
    finally:
        _change("immediate", kind, -1)


def begin_pending_job(kind="operation"):
    _change("pending", kind, 1)


def finish_pending_job(kind="operation"):
    _change("pending", kind, -1)


def has_pending_jobs():
    with _guard:
        return any(queue == "pending" for queue, _ in _counts)


def begin_status(kind, text=None, **_kwargs):
    with _guard:
        _labels[str(kind)] = str(text or kind)


def end_status(kind, **_kwargs):
    with _guard:
        _labels.pop(str(kind), None)


def clear_status():
    with _guard:
        _labels.clear()


def current_status_text():
    with _guard:
        return next(reversed(_labels.values()), "")


@contextmanager
def status_scope(kind, text=None, **kwargs):
    begin_status(kind, text, **kwargs)
    try:
        yield
    finally:
        end_status(kind)


def allow_timer_scope(_kind="operation"):
    return nullcontext()


def strict_zero_idle_enabled():
    return True


def finalize_operation_zero_idle(*_args, **_kwargs):
    mark_activity()


def null_scope():
    return nullcontext()


def logical_cpu_count():
    return max(1, os.cpu_count() or 1)


def available_memory_bytes():
    try:
        return max(0, int(os.sysconf("SC_PAGE_SIZE")) * int(os.sysconf("SC_AVPHYS_PAGES")))
    except (AttributeError, OSError, ValueError):
        return 2048 * _MIB


def enabled_pixel_layer_count(layers):
    enabled = 0
    for layer in tuple(layers or ()):
        try:
            enabled += bool(layer.get("enabled", True)) and not bool(layer.get("is_group", False))
        except (AttributeError, TypeError):
            enabled += 1
    return enabled


def temporary_array_cache_budget_bytes():
    try:
        from . import resource_quota
        if available_memory_bytes() < resource_quota.MEMORY_PRESSURE_FREE_BYTES:
            resource_quota.clear_all_memory(reason="memory_pressure")
            return 0
        unused = resource_quota.GLOBAL_MEMORY_CACHE_BYTES - int(
            resource_quota.memory_stats().get("retained_bytes", 0) or 0
        )
        return min(96 * _MIB, max(0, int(unused)))
    except (ImportError, AttributeError, TypeError, ValueError):
        return 64 * _MIB


def full_projection_allowed(width=0, height=0, layers=None, **_kwargs):
    pixels = max(0, int(width)) * max(0, int(height))
    buffers = max(1, min(enabled_pixel_layer_count(layers), 4))
    return pixels * buffers * 16 <= temporary_array_cache_budget_bytes()


def dirty_region_direct_write_allowed(width=0, height=0, rect=None, **_kwargs):
    try:
        left, bottom, right, top = map(int, rect[:4])
    except (TypeError, ValueError, IndexError):
        return False
    pixels = max(0, right - left) * max(0, top - bottom)
    return 0 < pixels <= max(1, int(width) * int(height)) // 2


def composite_chunk_pixels(width=0, height=0, layers=None, remaining=0, **_kwargs):
    limit = 2**17 if enabled_pixel_layer_count(layers) > 8 else 2**18
    chunk = min(limit, max(1, int(width) * int(height)))
    return min(chunk, max(1, int(remaining))) if remaining else chunk


def composite_time_budget_seconds():
    return _SLICE_SECONDS


def active_timer_interval():
    return _SLICE_SECONDS


def idle_timer_stop_after_ticks(_selection_active=False):
    return 0


def force_status_refresh(*_args, **_kwargs):
    pass


def force_status_bar_update(*_args, **_kwargs):
    pass


__all__ = (
    "active", "active_timer_interval", "allow_timer_scope", "available_memory_bytes",
    "begin_pending_job", "begin_status", "burst_scope", "clear_status", "composite_chunk_pixels",
    "composite_time_budget_seconds", "current_status_text", "dirty_region_direct_write_allowed",
    "enabled_pixel_layer_count", "end_status", "finalize_operation_zero_idle", "finish_pending_job",
    "full_projection_allowed", "has_pending_jobs", "idle_timer_stop_after_ticks", "logical_cpu_count",
    "mark_activity", "null_scope", "recently_active", "status_scope", "strict_zero_idle_enabled",
    "temporary_array_cache_budget_bytes",
)
