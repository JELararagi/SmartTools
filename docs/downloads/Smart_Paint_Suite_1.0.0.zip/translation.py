# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from .constants import BI_TRANSLATIONS, UI_LABELS
from .translation_en import JAPANESE_SOURCE_ENGLISH
from .translation_generated import GENERATED_SOURCE_TRANSLATIONS


BASE_TRANSLATIONS = {

    "Save completed (merged preview refresh failed). Layers were saved and validated; the PSD keeps its existing merged preview.":
        "保存は完了しました（統合プレビューの更新に失敗）: レイヤーは保存・検証済みです。PSDの統合プレビューは既存のまま維持されます。",
    "Audit": "監査",
    "Auto UV": "自動UV",
    "Brush Preset": "ブラシプリセット",
    "Buffer": "バッファ",
    "Checker": "チェッカー",
    "Consolidate": "集約",
    "Create": "作成",
    "Edit": "編集",
    "External Edit": "外部編集",
    "Health": "健全性",
    "Measure": "計測",
    "More": "詳細",
    "New": "新規",
    "Pack": "パック",
    "Project": "投影",
    "Smart UV": "スマートUV",
    "Workflow Profile": "ワークフロープロファイル",
    "Workspace": "ワークスペース",
    "Brush": "ブラシ",
    "Layers": "レイヤー",
    "Utilities": "ユーティリティ",
    "Quick Actions": "クイック操作",
    "Paint Targets": "ペイント対象",
    "Import / IO": "インポート / 入出力",
    "Projection": "投影",
    "Cleanup": "クリーンアップ",
    "Set Up Stack": "スタックをセットアップ",
    "Validate": "検証",
    "Health Check": "ヘルスチェック",
    "Rebuild": "再構築",
    "Save Dirty": "変更画像を保存",
    "Remove": "削除",
    "Duplicate": "複製",
    "Paint": "ペイント",
    "Fill": "塗りつぶし",
    "Decal": "デカール",
    "Procedural": "プロシージャル",
    "Base Color": "ベースカラー",
    "Roughness": "粗さ",
    "Metallic": "メタリック",
    "Normal": "ノーマル",
    "Height": "高さ",
    "Emission": "発光",
    "Alpha": "アルファ",
    "AO": "AO",
    "UV": "UV",
    "Box": "ボックス",
    "None": "なし",
    "Image": "画像",
    "AO Map": "AOマップ",
    "Curvature Map": "曲率マップ",
    "Thickness Map": "厚みマップ",
    "Position Map": "位置マップ",
    "Color ID": "カラーID",
    "Target Color": "対象色",
    "Color Tolerance": "色許容値",
    "Anchor": "アンカー",
    "Noise": "ノイズ",
    "Grunge": "グランジ",
    "Edge Wear": "エッジ摩耗",
    "Mix": "通常",
    "Add": "加算",
    "Multiply": "乗算",
    "Screen": "スクリーン",
    "Overlay": "オーバーレイ",
    "Subtract": "減算",
    "Difference": "差分",
    "Darken": "暗く",
    "Lighten": "明るく",
    "New Layer": "新規レイヤー",
    "Active Layer": "アクティブレイヤー",
    "Import PBR Set": "PBRセットを読み込み",
    "Pack Islands": "アイランドをパック",

    "Projection Buffer": "投影バッファ",
    "Brush Presets": "ブラシプリセット",
    "Dynamic": "ダイナミック",
    "Weather": "ウェザー",
    "Edge": "エッジ",
    "Commit": "確定",
    "Cancel": "キャンセル",
    "Vertex Color": "頂点カラー",
    "Paths": "パス",
    "Auto Repair Missing Paths": "不足パスを自動修復",
    "Missing Files": "不足ファイル",
    "Repair Missing Paths": "不足パスを修復",
    "Normal Cull": "ノーマルカリング",
    "Mesh Tools": "メッシュツール",
    "Status": "状態",
    "Smart Materials": "スマートマテリアル",
    "Dusty Plastic": "埃プラスチック",
    "Emissive Decal": "発光デカール",
    "Sync Points": "同期ポイント",
    "Sprite Sheet": "スプライトシート",
    "Prev": "前",
    "Next": "次",
    "Vector Shapes": "ベクトル形状",
    "Vector Shape": "ベクトル形状",
    "Vector Resolution": "ベクトル解像度",
    "Shape Color": "形状色",
    "Line Width": "線幅",
    "Edge Softness": "エッジの柔らかさ",
    "Padding": "余白",
    "Repeat Count": "繰り返し数",
    "Shape Rotation": "形状回転",
    "Add Height Detail": "高さディテールを追加",
    "Height Strength": "高さ強度",
    "Invert Height": "高さを反転",
    "UV Scale": "UV拡大率",
    "UV Offset": "UVオフセット",
    "UV Rotation": "UV回転",
    "Export": "書き出し",
    "Export Directory": "書き出し先",
    "Export Set Name": "書き出しセット名",
    "Export Resolution": "書き出し解像度",
    "Export Format": "書き出し形式",
    "Packed Layout": "パック配置",
    "Auto Snapshot Major Actions": "主要操作前に自動スナップショット",
    "Snapshot Source": "スナップショット元",
    "Enabled Channels": "有効チャンネル",
    "Mesh Maps": "メッシュマップ",
    "Auto UV Setup": "自動UVセットアップ",
    "Auto Unwrap Missing UVs": "不足UVを自動展開",
    "Microvertex / Height Preview": "マイクロバーテックス / 高さプレビュー",
    "Last External Edit": "最後の外部編集",
    "Preview Levels": "プレビュー分割数",
    "Preview Strength": "プレビュー強度",
    "Preview Midlevel": "プレビューミッドレベル",

    "Missing": "不足",
    "AO Image": "AO画像",
    "AO Value": "AO値",
    "Active Layer Index": "アクティブレイヤー番号",
    "Active Paint Channel": "アクティブペイントチャンネル",
    "Alpha Image": "アルファ画像",
    "Alpha Value": "アルファ値",
    "Anchor Channel": "アンカーチャンネル",
    "Anchor Layer": "アンカーレイヤー",
    "Anchor Layer ID": "アンカーレイヤーID",
    "Anti-Tiling Warp": "アンチタイリングワープ",
    "Auto Create Missing Images": "不足画像を自動作成",
    "Auto Pack Images": "画像を自動パック",
    "Auto Rebuild After Major Actions": "主要操作後に自動再構築",
    "Auto Restore on Failure": "失敗時に自動復元",
    "Auto Save After Bake": "ベイク後に自動保存",
    "Auto Switch to Texture Paint": "自動でテクスチャペイントへ切替",
    "Bake Margin": "ベイク余白",
    "Bake Resolution": "ベイク解像度",
    "Bake Samples": "ベイクサンプル数",
    "Base Color Image": "ベースカラー画像",
    "Blend Mode": "合成モード",
    "Bombing Cell Scale": "ボンビングセル尺度",
    "Bombing Seed": "ボンビングシード",
    "Brightness": "明るさ",
    "Buffer Nudge %": "バッファ移動率%",
    "Buffer Zoom %": "バッファ拡大量%",
    "Channel": "チャンネル",
    "Channels": "チャンネル",
    "Checker Cells": "チェッカーセル数",
    "Checker Resolution": "チェッカー解像度",
    "Consolidate Directory": "集約先フォルダー",
    "Contrast": "コントラスト",
    "Curvature": "曲率",
    "Data": "データ",
    "Debug Logging": "デバッグログ",
    "Default Image Directory": "既定画像フォルダー",
    "Default Resolution": "既定解像度",
    "Default UV Map": "既定UVマップ",
    "Displacement Scale": "ディスプレイスメント倍率",
    "Edge Balance": "エッジバランス",
    "Emission Color": "発光色",
    "Emission Image": "発光画像",
    "Emission Strength": "発光強度",
    "Enable Displacement Output": "ディスプレイスメント出力を有効化",
    "Enabled": "有効",
    "Fill Color": "塗り色",
    "Gamma": "ガンマ",
    "Global Bump Strength": "全体バンプ強度",
    "Height Blend / Carve": "高さブレンド / カーブ",
    "Height Blend Balance": "高さブレンドバランス",
    "Height Image": "高さ画像",
    "Height Value": "高さ値",
    "Hue Shift": "色相シフト",
    "Import Directory": "インポートフォルダー",
    "Import Mode": "インポートモード",
    "Import Set Index": "インポートセット番号",
    "Invert": "反転",
    "Invert Height Blend": "高さブレンドを反転",
    "Invert Mask": "マスクを反転",
    "Last Audit": "最新監査",
    "Last Audit Report": "最新監査レポート",
    "Last Import Summary": "最後の読込概要",
    "Last Imported PBR Set": "最後に読込んだPBRセット",
    "Last Info Message": "最新情報メッセージ",
    "Last Snapshot Text": "最新スナップショット",
    "Layer ID": "レイヤーID",
    "Layer Kind": "レイヤー種別",
    "Layer Name": "レイヤー名",
    "Layer List Selection": "レイヤー一覧の選択",
    "Make Consolidated Paths Relative": "集約後パスを相対化",
    "Managed Material": "管理マテリアル",
    "Mask": "マスク",
    "Mask Channel": "マスクチャンネル",
    "Mask Image": "マスク画像",
    "Mask Mode": "マスク方式",
    "Mask Strength": "マスク強度",
    "Mask Threshold": "マスク閾値",
    "Measure Density": "密度を計測",
    "Measured Density": "計測密度",
    "Metallic Image": "メタリック画像",
    "Metallic Value": "メタリック値",
    "Mode": "モード",
    "Noise Detail": "ノイズ詳細",
    "Noise Scale": "ノイズ尺度",
    "Normal Image": "ノーマル画像",
    "Normal Map": "ノーマルマップ",
    "Normal Strength": "ノーマル強度",
    "Opacity": "不透明度",
    "Paint Target": "ペイント対象",
    "Position": "位置",
    "Preset": "プリセット",
    "Preview AO in Base Color": "Base ColorへAOをプレビュー合成",
    "Preview Light": "プレビューライト",
    "Preview Light Energy": "プレビューライト強度",
    "Previous Projection Target": "前回の投影対象",
    "Profile": "プロファイル",
    "Projection Camera": "投影カメラ",
    "Projection Image": "投影画像",
    "Projection Previous Enabled": "投影前の有効状態",
    "Projection Previous Layer Kind": "投影前のレイヤー種別",
    "Projection Previous Mode": "投影前のモード",
    "Projection Source Image": "投影元画像",
    "Projection Target Channel": "投影対象チャンネル",
    "Projection Target Layer ID": "投影対象レイヤーID",
    "Reset": "リセット",
    "Resolution": "解像度",
    "Roughness Image": "粗さ画像",
    "Roughness Value": "粗さ値",
    "Runtime Log": "実行ログ",
    "Saturation": "彩度",
    "Selected Map": "選択マップ",
    "Set Density": "密度を設定",
    "Sidebar Category": "サイドバーカテゴリ",
    "Sprite Columns": "スプライト列数",
    "Sprite Frame": "スプライトフレーム",
    "Sprite Rows": "スプライト行数",
    "Sprite Sheet Image": "スプライトシート画像",
    "Target": "対象",
    "Target Density": "目標密度",
    "Texel Density Size": "テクセル密度用解像度",
    "Texture Resolution": "テクスチャ解像度",
    "Thickness": "厚み",
    "Transform": "変形",
    "UV Map": "UVマップ",
    "UV Pack Margin": "UVパック余白",
    "Use AO": "AOを使用",
    "Use Alpha": "Alphaを使用",
    "Use Base Color": "Base Colorを使用",
    "Use Emission": "Emissionを使用",
    "Use Float Images": "Float画像を使用",
    "Use Height": "Heightを使用",
    "Use Height as Bump Preview": "Heightをバンププレビューに使用",
    "Use Metallic": "Metallicを使用",
    "Use Normal": "Normalを使用",
    "Use Roughness": "Roughnessを使用",
    "Use Tiled / UDIM Images": "タイル / UDIM画像を使用",
    "Validation Message": "検証メッセージ",
    "Value": "値",
    "Vertex Color Attribute": "頂点カラー属性",
    "Vertex Color Layer": "頂点カラーレイヤー",
    "Warp Strength": "ワープ強度",
    "Workflow Profiles": "ワークフロープロファイル",
    "Game": "ゲーム",
    'Smart Mask': 'Smart Mask',
    'Projection Paint': 'Projection Paint',
    '3D Texture': '3D Texture',
    "Rectangle": "長方形",
    "Diamond": "菱形",
    "Chevron": "シェブロン",
    "Cross": "十字",
    'Smart Mask Authoring': 'スマートマスク制作',
    'Projection Paint Authoring': '投影ペイント制作',
    'Bake Review Iteration': 'ベイク確認の反復',
    '3D Texture Hybrid': '3Dテクスチャハイブリッド',
    'Node Texture Authoring': 'ノードテクスチャ制作',
    'PBR Paint': 'PBRペイント',
    'Brightness / Contrast': '明るさ / コントラスト',
    'Hue / Saturation / Lightness': '色相 / 彩度 / 明度',
    'Posterize': 'ポスタライズ',
    'Levels': 'レベル',
    'Tone Curve': 'トーンカーブ',
    'Color Balance': 'カラーバランス',
    'Gradient Map': 'グラデーションマップ',
    "Decal Layer": "デカールレイヤー",
    "Game Asset": "ゲームアセット",
    "Concept / Vertex": "コンセプト / 頂点",
    "Realtime Bake": "リアルタイムBake",
    "VFX / UDIM": "VFX / UDIM",
    "Dynamic Stroke": "ダイナミックストローク",
    "Weather / Grunge": "ウェザー / グランジ",
    "Decal / Stamp": "デカール / スタンプ",
    "New Decal Layer": "新規デカールレイヤー",
    "Worn Painted Metal": "摩耗塗装メタル",
    "Panel Line": "パネルライン",
    "Stitch": "ステッチ",
    "Stripes": "ストライプ",
    "Circle / Ring": "円 / リング",
    "Bolt / Rivet": "ボルト / リベット",
    "Scratch": "スクラッチ",
    "Cells": "セル",
    "Red": "赤",
    "Green": "緑",
    "Blue": "青",
    "Luma": "輝度",
    "PNG": "PNG",
    "TIFF": "TIFF",
    "OpenEXR": "OpenEXR",
    "Add Layer": "レイヤーを追加",
    "Discard Unsaved Changes": "未保存の変更を破棄",
    "Scene": "シーン",
    "Settings": "設定",
    "Smart Paint settings are unavailable.": "Smart Paint 設定は利用できません。",
    "ORM": "ORM",
    "RMA": "RMA",
    "MRA": "MRA",
    "ARM": "ARM",
}


# --- Smart Paint bundled tool Japanese localization additions START ---
BASE_TRANSLATIONS.update({
    'Always Snap': '常にスナップ',
    'Auto swap interpolation mode': '補間モードを自動切替',
    'Autosave Directory': '自動保存ディレクトリ',
    'Bake Channel': 'チャンネルをベイク',
    'Box Deform': 'ボックス変形',
    'Brushstroke Tools': 'ブラシストロークツール',
    'Bump': 'バンプ',
    'Bump Strength': 'バンプ強度',
    'Category': 'カテゴリ',
    'Combine With Alt': 'Alt と組み合わせ',
    'Combine With Ctrl': 'Ctrl と組み合わせ',
    'Combine With OS Key': 'OSキーと組み合わせ',
    'Combine With Shift': 'Shift と組み合わせ',
    'Coordinate Type': '座標タイプ',
    'Cursor Color': 'カーソル色',
    'Directory': 'ディレクトリ',
    'Display Timeline Overlay': 'タイムラインオーバーレイを表示',
    'Draw': '描画',
    'Enable': '有効',
    'Frame Interval On Screen': '画面上のフレーム間隔',
    'Frame Lines Size': 'フレーム線サイズ',
    'Grease Pencil': 'グリースペンシル',
    'Hide Overlays': 'オーバーレイを隠す',
    'Hue': '色相',
    'Keyframe Display': 'キーフレーム表示',
    'Keyframes': 'キーフレーム',
    'Label Size': 'ラベルサイズ',
    'Layer Box Height': 'レイヤーボックス高さ',
    'Layer Box Width': 'レイヤーボックス幅',
    'Layer Navigator': 'レイヤーナビゲーター',
    'Left Handed': '左手用',
    'Margin': 'マージン',
    'Materials': 'マテリアル',
    'Mouse button': 'マウスボタン',
    'Normalize': '正規化',
    'Output Directory': '出力ディレクトリ',
    'Overwrite Existing on Autosave': '自動保存時に既存ファイルを上書き',
    'Overwrite Existing on Blendfile Saving': '.blend 保存時に既存ファイルを上書き',
    'Overwrite on Timer': 'タイマー保存時に上書き',
    'Paint System': 'ペイントシステム',
    'Playhead': '再生ヘッド',
    'Playhead Size': '再生ヘッドサイズ',
    'Properties': 'プロパティ',
    'Rolling Mode': 'ローリングモード',
    'Rotate Canvas': 'キャンバス回転',
    'Save On Blendfile Saving': '.blend 保存時にも保存する',
    'Shortcut': 'ショートカット',
    'Shortcut in timeline editors': 'タイムラインエディター内のショートカット',
    'Starting Interpolation': '開始補間',
    'Steps': 'ステップ',
    'Timeline': 'タイムライン',
    'Timeline Color': 'タイムライン色',
    'Type': '種類',
    'Layer Paint Engine': 'Layer Paint Engine',
    'Unknown': '不明',
    'Use Autosave Timer': '自動保存タイマーを使う',
    'Use click drag directly on points': 'ポイント上でクリックドラッグを直接使用',
    'Use Float': 'Floatを使用',
    'Use GPU': 'GPUを使用',
    'Use Extension Storage Root': '拡張機能保存領域を基準にする',
    'Width': '幅',
})
# --- Smart Paint bundled tool Japanese localization additions END ---


# --- Smart Paint integrated visible string localization START ---
BASE_TRANSLATIONS.update({
    '...': '...',
    '3D View': '3Dビュー',
    'Action': '操作',
    'Actions': '操作',
    'Adjustment': '調整',
    'Alt': 'Alt',
    'Angle': '角度',
    'Angle Steps': '角度ステップ',
    'Animated': 'アニメーション',
    'Attribute': '属性',
    'Bake': 'ベイク',
    'Baked': 'ベイク済み',
    'Channels:': 'チャンネル:',
    'Clip': 'クリップ',
    'Cmd': 'Cmd',
    'Color': 'カラー',
    'Color Palette': 'カラーパレット',
    'Color Picker Scale': 'カラーピッカー倍率',
    'Color Picker Settings': 'カラーピッカー設定',
    'Context': 'コンテキスト',
    'Ctrl': 'Ctrl',
    'Depth': '深さ',
    'Developer Mode': '開発者モード',
    'Display': '表示',
    'Distance': '距離',
    'Folder': 'フォルダー',
    'Frame': 'フレーム',
    'Geometry': 'ジオメトリ',
    'Gradient': 'グラデーション',
    'Groups': 'グループ',
    'Hex': 'Hex',
    'Hide Color Attribute Tips': 'カラー属性ヒントを非表示',
    'Hide Normal Painting Tips': 'ノーマルペイントヒントを非表示',
    'Import Method': '読み込み方法',
    'Interpolation': '補間',
    'Loading Donations': '寄付情報を読み込み中',
    'Material': 'マテリアル',
    'Mesh': 'メッシュ',
    'Name': '名前',
    'Open Image': '画像を開く',
    'Preference Tool Tab': '設定ツールタブ',
    'Preferences': '設定',
    'Preferred Coordinate Type': '優先座標タイプ',
    'Preferred coordinate type': '優先座標タイプ',
    'Relative Path': '相対パス',
    'Resource Directory': 'リソースディレクトリ',
    'RMB Color Wheel Scale': '右クリックカラーホイール倍率',
    'Rotate From View Center In Camera': 'カメラ内のビュー中心から回転',
    'Samples': 'サンプル数',
    'Save As': '別名保存',
    'Scale': 'スケール',
    'Shift': 'Shift',
    'Show Active Palette (RMB)': 'アクティブパレットを表示（右クリック）',
    'Show Brush Controls (RMB)': 'ブラシ制御を表示（右クリック）',
    'Show Hex Color': 'Hexカラーを表示',
    'Show HSV sliders under the color wheel in the Texture Paint right-click popover': 'テクスチャペイント右クリックポップオーバーのカラーホイール下に HSV スライダーを表示します',
    'Show Hue/Saturation/Value sliders (RMB)': '色相/彩度/明度スライダーを表示（右クリック）',
    'Show More Color Picker Settings': 'カラーピッカー詳細設定を表示',
    'Show Opacity in Layer List': 'レイヤー一覧に不透明度を表示',
    'Show Tooltips': 'ツールチップを表示',
    'Solid Color': '単色',
    'Space': '空間',
    'Strength': '強度',
    'Support': 'サポート',
    'Text Frame Current': '現在フレームテキスト',
    'Text Frame Offset': 'フレームオフセットテキスト',
    'Texture': 'テクスチャ',
    'Update State': '更新状態',
    'Use Baked': 'ベイク済みを使用',
    'Use Compact Design': 'コンパクトデザインを使用',
    'Use Legacy UI': '旧UIを使用',
    'Use Panel Quick Access': 'パネルクイックアクセスを使用',
    'Version Check Interval (Days)': 'バージョン確認間隔（日）',
    'Version Check Interval (Hours)': 'バージョン確認間隔（時間）',
    'Version Check Interval (Minutes)': 'バージョン確認間隔（分）',
})
# --- Smart Paint integrated visible string localization END ---

# --- Smart Paint Layer Paint Engine Japanese localization START ---
BASE_TRANSLATIONS.update({
    'Ambient Occlusion': 'アンビエントオクルージョン',
    'Assign': '割り当て',
    'Background': '背景',
    'Black': '黒',
    'Blend': 'ブレンド',
    'Color:': '色:',
    'Curve': 'カーブ',
    'Dust': 'ダスト',
    'Erase': '消去',
    'Experimental': '試験的',
    'Extra': '追加',
    'Group': 'グループ',
    'Height:': '高さ:',
    'Input': '入力',
    'Layer Group': 'レイヤーグループ',
    'Magic': 'マジック',
    'Main UV:': 'メインUV:',
    'Math': '数式',
    'Offset': 'オフセット',
    'Parallax': '視差',
    'Pointiness': '尖り',
    'Preview Mode': 'プレビューモード',
    'Ramp': 'ランプ',
    'Rebake': '再ベイク',
    'Rotation': '回転',
    'Select': '選択',
    'Source:': 'ソース:',
    'Tangent': 'タンジェント',
    'Test': 'テスト',
    'Tests': 'テスト',
    'UV Map:': 'UVマップ:',
    'Voronoi': 'ボロノイ',
    'Wave': '波',
    'White': '白',
})
# --- Smart Paint Layer Paint Engine Japanese localization END ---


# --- Smart Paint generated full UI localization START ---
BASE_TRANSLATIONS.update({'1024 x 1024 texture size.': '1024 x 1024 のテクスチャサイズです。', '16384 x 16384 texture size for higher-end UDIM or film-style work.': '高解像度のUDIMや映画向け作業用の 16384 x 16384 テクスチャサイズです。', '2048 x 2048 texture size.': '2048 x 2048 のテクスチャサイズです。', '32768 x 32768 texture size for extreme high-end workflows. Use with care because memory use can be very high.': '極めて高解像度なワークフロー向けの 32768 x 32768 テクスチャサイズです。メモリ消費が非常に大きいため注意して使ってください。', '4096 x 4096 texture size.': '4096 x 4096 のテクスチャサイズです。', '512 x 512 texture size.': '512 x 512 のテクスチャサイズです。', '8192 x 8192 texture size.': '8192 x 8192 のテクスチャサイズです。', 'Active Paint': 'アクティブペイント', 'Active Target': 'アクティブターゲット', 'Additional multiplier applied to the final mask.': '最終マスクへ追加で掛ける倍率です。', 'Adds jitter, smoothing and pressure-friendly settings to mimic more organic strokes.': 'ジッターやスムーズ化、筆圧向け設定を加えて、より有機的なストローク感を作ります。', 'Adjustment layer': '調整レイヤー', 'All': 'すべて', 'Allow parallax without baked textures. This can be very slow.': 'ベイクテクスチャなしでもパララックスを許可します。非常に遅くなる場合があります。', 'Also consider Grease Pencil object keyframes when snapping, not just the active layer frames.': 'スナップ時にアクティブレイヤーのフレームだけでなく、グリースペンシルオブジェクトのキーフレームも対象にします。', 'Always Evaluate on Frame Change': 'フレーム変更時に常に評価', 'Always evaluate Layer Paint Engine keyframe data on frame changes. This can be slow.': 'フレーム変更時に Layer Paint Engine のキーフレームデータを常に評価します。遅くなる場合があります。', 'Always hide update notifications inside Layer Paint Engine.': 'Layer Paint Engine 内の更新通知を常に隠します。', 'Always snap to keyframes when possible. Use the alternate modifier to temporarily disable snapping.': '可能なときは常にキーフレームへスナップします。補助キーで一時的にスナップを外せます。', 'Always use 1024x1024 by default.': '既定で常に 1024x1024 を使います。', 'Always use 2048x2048 by default.': '既定で常に 2048x2048 を使います。', 'Always use 4096x4096 by default.': '既定で常に 4096x4096 を使います。', 'Always use 512x512 by default.': '既定で常に 512x512 を使います。', 'Ambient occlusion helper channel.': 'アンビエントオクルージョン補助チャンネルです。', 'Anchor Dirt': 'アンカー汚れ', 'Angle used for stepped canvas rotation when the alternate snap modifier is pressed.': '代替スナップ修飾キーを押しているときに使う段階回転の角度です。', 'Append': '追加読み込み', 'Append the required data-blocks and keep image data local to this file.': '必要なデータブロックを追加し、画像データを現在のファイル側へ持ち込みます。', 'Approximate number of checker cells per row and column.': 'チェッカーパターンの行列方向のおおよそのセル数です。', 'Assign the generated vector images to the currently active layer.': '生成したベクトル画像を現在のアクティブレイヤーへ割り当てます。', 'Assign the imported textures to the active layer.': '読み込んだテクスチャをアクティブレイヤーへ割り当てます。', 'Auto': '自動', 'Automatically enable UDIM-related options when UDIM tiles are detected.': 'UDIM タイルを検出したとき、関連オプションを自動で有効にします。', 'Automatically rebuild the managed material after important actions such as baking, importing or layer changes.': 'ベイク・読込・レイヤー変更など重要操作のあとに管理マテリアルを自動再構築します。', 'Available': '利用可能', 'Background Services': 'バックグラウンドサービス', 'Bake Device': 'ベイクデバイス', 'Bake a generated/object position style map.': '生成座標／オブジェクト位置風のマップをベイクします。', 'Bake a tangent-space normal image.': 'タンジェント空間ノーマル画像をベイクします。', 'Bake a thickness approximation based on ambient occlusion style sampling.': 'AO系サンプリングを使った厚み近似をベイクします。', 'Bake an ambient occlusion image.': 'AO画像をベイクします。', 'Balanced everyday paint brush preset.': '日常的な描画向けのバランス型ブラシプリセットです。', 'Blend mode used when this layer is composited over the result below.': '下の結果へこのレイヤーを合成するときの合成モードです。', 'Brightening blend similar to image editors.': '画像編集ソフトのスクリーンに近い明るくする合成です。', 'Camera used by the projection helper. If empty, the active scene camera is used.': '投影補助で使うカメラです。空ならシーンのアクティブカメラを使います。', 'Canvas Rotate tool shortcut and related settings.': 'キャンバス回転ツールのショートカットと関連設定です。', 'Channel that will become the active paint target when you click Paint Target buttons.': 'ペイント対象ボタンを押したときに有効化されるチャンネルです。', 'Choose how Layer Paint Engine layer lists are presented.': 'Layer Paint Engine のレイヤー一覧表示方法を選びます。', 'Choose how keyframes are drawn in the overlay.': 'オーバーレイ上でのキーフレーム表示方法を選びます。', 'Choose whether imported PBR textures fill the active layer or create a new layer.': '読み込んだPBRテクスチャをアクティブレイヤーへ割り当てるか、新規レイヤーを作るか選びます。', 'Choose which Grease Pencil tool settings are shown in this settings section.': 'この設定セクションで表示するグリースペンシルツール設定を選びます。', 'Choose which icon set Layer Paint Engine should use.': 'Layer Paint Engine が使うアイコンセットを選びます。', 'Choose which image channel is used as the mask value.': 'どの画像チャンネルをマスク値として使うかを選びます。', 'Classic': 'クラシック', 'Classic layers list.': '従来型のレイヤー一覧です。', 'Color Wheel Scale': 'カラーホイール倍率', 'Color attribute used by the vertex-color approximation workflow and by baking vertex paint back into image textures.': '頂点カラー近似ワークフローや、頂点ペイントを画像テクスチャへベイクし直す際に使うカラー属性です。', 'Color used for the scrub cursor line and related text.': 'スクラブ用カーソル線と関連テキストに使う色です。', 'Color used for the temporary timeline overlay.': '一時的なタイムラインオーバーレイに使う色です。', 'Compact summary of the most recent PBR import operation, including how many sets or channels were detected.': '最後の PBR 読み込み結果の要約です。検出したセット数やチャンネル数の確認に使えます。', 'Connect a displacement node to the material output in addition to the bump preview. This is useful mainly in Cycles setups.': 'バンプ表示に加えてマテリアル出力へディスプレイスメントも接続します。主に Cycles 向けです。', 'Contrast boosting blend.': 'コントラストを強める合成です。', 'Controls how strongly the edge-wear mask focuses on exposed edges.': 'エッジ摩耗マスクが露出エッジへどれくらい集中するかを調整します。', 'Convert the color to grayscale.': '色をグレースケールに変換します。', 'Copy': 'コピー', 'Create a chevron arrow shape for military markings, stripes and directional accents.': 'ミリタリーマーキング、ストライプ、方向アクセント向けのシェブロン形状を作成します。', 'Create a circular or ring-shaped graphic useful for bolts, targets or labels.': 'ボルト、ターゲット、ラベルなどに使いやすい円形・リング形状を作成します。', 'Create a crisp panel-line style strip that can be used as a decal or mask.': 'デカールやマスクとして使える、くっきりしたパネルライン状の帯を作成します。', 'Create a cross or plus sign shape for panels, signs and graphic helpers.': 'パネル、サイン、グラフィック補助に使える十字形状を作成します。', 'Create a diamond-shaped graphic suited for warning marks or stylized decals.': '警告マークやスタイライズドデカールに向く菱形グラフィックを作成します。', 'Create a new decal-style layer and assign the generated vector images to it.': '新しいデカール型レイヤーを作成し、生成したベクトル画像を割り当てます。', 'Create a new layer from the imported PBR texture set.': '読み込んだPBRセットから新規レイヤーを作成します。', 'Create a rectangular plate or decal block useful for labels, vents and trims.': 'ラベル、ベント、トリムに使いやすい長方形プレート形状を作成します。', 'Create a small round bolt or rivet style stamp.': '小さな丸いボルト／リベット風スタンプを作成します。', 'Create repeated short diagonal marks suitable for seams and stitching details.': '縫い目やステッチ表現に向いた、短い斜線の繰り返し形状を作成します。', 'Create repeated stripes for trim sheets, tape, hazard lines or graphic bands.': 'トリムシート、テープ、警告線、グラフィック帯に使える繰り返しストライプを作成します。', "Create tiled images when possible. Basic tiled creation is supported, but exact UDIM workflows still depend on Blender's native image tools.": '可能な場合はタイル画像で作成します。基本的なタイル作成には対応しますが、厳密なUDIM運用は Blender 標準画像機能にも依存します。', 'Creates a decal-style layer stack prepared for projected signs, labels or emissive panels.': '投影看板、ラベル、発光パネル向けのデカール型レイヤースタックを作成します。', 'Creates a plastic base with dusty cavity buildup and mild breakup for properties and hard-surface assets.': 'プラスチック地に埃の堆積と軽い分解感を加えた、プロップやハードサーフェス向けスタックを作成します。', 'Creates a small smart-material stack with painted coat, exposed metal edges and dirt buildup.': '塗装層、露出した金属エッジ、汚れ堆積を組み合わせたスマートマテリアルスタックを作成します。', 'Custom': 'カスタム', 'Custom Default Image Size': 'カスタム既定画像サイズ', 'Custom Resolution': 'カスタム解像度', 'Cycles sample count used for mesh map baking. Lower values are faster, higher values are cleaner.': 'メッシュマップベイクに使う Cycles サンプル数です。少ないと高速、多いと綺麗になります。', 'Days': '日', 'Default': '既定', 'Default Image Size': '既定画像サイズ', 'Default device used for Layer Paint Engine bake operations.': 'Layer Paint Engine のベイク処理で使う既定デバイスです。', 'Default image size behavior used when creating new Layer Paint Engine images.': '新しい Layer Paint Engine 画像を作るときの既定サイズ動作です。', 'Default image size used when Layer Paint Engine is set to use a custom image resolution.': 'Layer Paint Engine でカスタム画像解像度を使うときの既定サイズです。', 'Default resolution used for new images in this material stack.': 'このマテリアルスタックで新規画像を作るときの既定解像度です。', 'Default size for newly created paint images.': '新規ペイント画像を作るときの既定サイズです。', 'Detail of the procedural noise / grunge mask.': 'プロシージャルノイズ／グランジマスクのディテール量です。', 'Difference blend useful for masks and stylized looks.': 'マスクやスタイライズ用途に便利な差分合成です。', 'Diffuse / albedo color channel.': 'ディフューズ／アルベド色チャンネルです。', 'Displacement': 'ディスプレイスメント', 'Displacement strength used by the mesh preview helper. This is separate from the shader preview so you can exaggerate or reduce the geometry preview without changing the final material stack settings.': 'メッシュプレビュー補助で使うディスプレイスメント強度です。シェーダープレビューとは独立しているため、最終マテリアル設定を変えずに、ジオメトリ確認だけ強めたり弱めたりできます。', 'Display angle guides and angle text while rotating the canvas.': 'キャンバス回転中に角度ガイド線と角度表示を出します。', 'Display keyframes as diamonds.': 'キーフレームをひし形で表示します。', 'Display keyframes as squares.': 'キーフレームを四角で表示します。', 'Display keyframes as thick lines.': 'キーフレームを太線で表示します。', 'Display name of the layer. This is also used when images and nodes are named.': 'レイヤーの表示名です。画像やノード名にも使われます。', 'Down': '下', 'Dynamic & Classic (For Debugging)': 'ダイナミック + クラシック（デバッグ用）', 'Dynamic layers list with dropdown support.': 'ドロップダウン対応の動的レイヤー一覧です。', 'Emission color channel.': '発光色チャンネルです。', 'Enable AO helper contribution. AO can optionally be multiplied into base color for viewport preview and export preparation.': 'AO補助寄与を有効にします。AOはビューポート表示や書き出し準備のためにベースカラーへ乗算できます。', 'Enable Auto UDIM Detection': '自動 UDIM 検出を有効', 'Enable Baked Outside': 'ベイク結果を外側に作る設定を有効にします。', 'Enable alpha/opacity contribution.': 'アルファ／不透明度寄与を有効にします。', 'Enable developer-oriented Paint System logging and diagnostics.': '開発者向けのログと診断を有効にします。', 'Enable emission contribution.': '発光寄与を有効にします。', 'Enable height/bump contribution.': '高さ／バンプ寄与を有効にします。', 'Enable metallic contribution.': 'メタリック寄与を有効にします。', 'Enable normal contribution.': 'ノーマル寄与を有効にします。', 'Enable roughness contribution.': '粗さ寄与を有効にします。', 'Enable the Paint System quick-access panel shortcuts.': 'ペイントシステムのクイックアクセス用パネルショートカットを有効にします。', 'Enable the viewport timeline scrub helper.': 'ビューポート用タイムラインスクラブ補助を有効にします。', 'Energy used by the quick preview-light rig. Increase this when checking roughness, normals, or decals on darker materials.': 'クイック確認用ライトの強さです。暗いマテリアルでラフネス、ノーマル、デカールを確認するときに上げてください。', 'Ensure preview mode uses sRGB color handling.': 'プレビューモードで sRGB カラー処理を使うようにします。', 'Error': 'エラー', 'Export images as PNG files. Good default for color and standard texture maps.': '画像を PNG で書き出します。カラーや標準的なテクスチャマップ向けの既定値です。', 'Export images as TIFF files. Useful when a pipeline expects TIFF without switching to EXR.': '画像を TIFF で書き出します。EXR へ切り替えずに TIFF を要求するパイプライン向けです。', 'FAILED': '失敗', 'Failed': '失敗', 'Fallback AO value used when no image is assigned.': '画像がないときに使う代替AO値です。', 'Fallback alpha value used when no image is assigned.': '画像がないときに使う代替アルファ値です。', 'Fallback emission color when no image is assigned.': '画像がないときに使う代替発光色です。', 'Fallback height value used when no image is assigned.': '画像がないときに使う代替高さ値です。', 'Fallback metallic value used when no image is assigned.': '画像がないときに使う代替メタリック値です。', 'Fallback roughness value used when no image is assigned.': '画像がないときに使う代替粗さ値です。', 'Favor height, displacement preview, vertex-color staging and quick bake-back workflows inspired by 3D Texture.': '高さ、ディスプレイスプレビュー、頂点カラーの下描き、素早い焼き戻しを重視します。', 'Favor quick concept iteration, projection helpers and vertex-color staging before final image bake-out.': '最終画像化前の素早いコンセプト反復、投影補助、頂点カラー下描きを重視した設定にします。', 'Feed the assembled height result into a bump node for viewport preview.': '合成した高さ結果をバンプノードへ渡してビューポート確認に使います。', 'File Path': 'ファイルパス', 'File format used when saving exported textures.': '書き出したテクスチャを保存するときのファイル形式です。', 'Font size used for layer names in the navigator overlay.': 'ナビゲーターオーバーレイ内のレイヤー名に使う文字サイズです。', 'GPU Compute': 'GPU計算', 'Generate a matching height image in addition to the mask so the shape can indent or emboss the surface. This is useful for panel lines and seams.': 'マスクに加えて対応する高さ画像も生成し、形状で表面を彫り込んだり浮かせたりします。パネルラインや縫い目に有効です。', 'Generate a thin anisotropic scratch mask that helps break up broad surfaces and roughness.': '広い面の単調さを崩す細い異方性スクラッチマスクを生成します。', 'Height / bump / displacement channel.': '高さ／バンプ／ディスプレイスメント用チャンネルです。', 'Height of each layer entry box. Larger values are easier to click but use more screen space.': '各レイヤー項目ボックスの高さです。大きいほどクリックしやすくなりますが、画面スペースを多く使います。', 'Height of the playhead line in pixels.': '再生ヘッド線の高さをピクセルで指定します。', 'Height of the timeline frame marks in pixels.': 'タイムラインのフレーム目盛り高さをピクセルで指定します。', 'Hide Update Notification': '更新通知を隠す', 'Hide the color attribute tip hints.': 'カラー属性のヒント表示を隠します。', 'Hide the normal painting tip hints.': '法線ペイントのヒント表示を隠します。', 'Hide viewport overlays and gizmos while scrubbing is active.': 'スクラブ中にビューポートオーバーレイとギズモを隠します。', 'Hours': '時間', 'How close an ID color must be to the target color before it is treated as part of the mask. Lower values are stricter, higher values accept a broader range.': 'ID 色がマスク対象として扱われるまでに、対象色へどれくらい近い必要があるかです。低いほど厳密、高いほど広い範囲を許容します。', 'How far the projection buffer is nudged for the arrow-style 2D transforms. The value is a percentage of the current image width or height, which makes the step size resolution independent.': '矢印系の2D変形で投影バッファをどれくらい移動するかの割合です。現在の画像の幅または高さに対する割合なので、解像度に依存しにくい移動量になります。', 'How many frame columns the sprite sheet contains.': 'スプライトシートが何列のフレームで構成されているかです。', 'How many frame rows the sprite sheet contains.': 'スプライトシートが何行のフレームで構成されているかです。', 'How many repeated marks are generated for shapes such as stitches or stripes.': 'ステッチやストライプのような形状で、何個の繰り返しを生成するかです。', 'How strongly the anti-tiling warp distorts the input coordinates.': 'アンチタイリング用ワープが入力座標をどれくらい歪ませるかです。', 'How strongly the height information sharpens or widens the blend between this layer and the result below.': '高さ情報がこのレイヤーと下地のブレンド境界をどれくらい鋭く／広くするかです。', 'Human-readable label of the last imported PBR set for quick verification.': '最後に読み込んだ PBR セットの確認用ラベルです。', 'Icon set from the current Blender version.': '現在の Blender バージョンのアイコンを使います。', 'Icons': 'アイコン', 'Image Atlas Size': '画像アトラスサイズ', 'Image based layer intended for direct painting.': '直接ペイント向けの画像ベースレイヤーです。', 'Image treated as a sprite sheet. Frames can be extracted into projection images or active layer channels as a Blender-native approximation of sprite-sheet brush workflows.': 'スプライトシートとして扱う画像です。フレームを切り出して投影画像やアクティブレイヤーチャンネルへ送ることで、スプライトシートブラシ系ワークフローを Blender ネイティブに近似します。', 'Image used by projection helper actions.': '投影補助アクションで使う画像です。', 'Image used for AO contribution.': 'AO寄与用画像です。', 'Image used for alpha/opacity.': 'アルファ／不透明度用画像です。', 'Image used for emission color.': '発光色用画像です。', 'Image used for height or bump details.': '高さ／バンプ用画像です。', 'Image used for metallic.': 'メタリック用画像です。', 'Image used for roughness.': '粗さ用画像です。', 'Image used for tangent-space normal details.': 'タンジェント空間ノーマルの画像です。', 'Image used for the base color channel.': 'ベースカラー用画像です。', 'Image:': '画像:', 'Index of the currently selected layer in the Smart Paint UI.': 'Smart Paint UI で現在選択中のレイヤー番号です。', 'Internal flag storing whether the target channel was enabled before the projection buffer started.': '投影バッファ開始前に対象チャンネルが有効だったかを保持する内部フラグです。', 'Internal image name used to restore the layer channel when a projection buffer is canceled.': '投影バッファをキャンセルしたときにレイヤーチャンネルを復元するための内部画像名です。', 'Internal layer identifier used by the projection buffer workflow.': '投影バッファワークフローで使う内部レイヤー識別子です。', 'Internal loading flag for donation information.': '寄付情報の内部読み込みフラグです。', 'Internal source image name used to reset the active projection buffer back to its original projection image.': 'アクティブな投影バッファを元の投影画像へ戻すために使う内部ソース画像名です。', 'Internal stable identifier used to keep anchor references valid even when a source layer is renamed.': '元レイヤー名が変わってもアンカー参照を保つための内部IDです。', 'Internal stable identifier used to reconnect nodes and paint targets safely.': 'ノードやペイント対象を安全に再接続するための内部IDです。', 'Internal update-state cache.': '内部の更新状態キャッシュです。', 'Internal value used to restore the layer kind when a projection buffer is canceled.': '投影バッファをキャンセルしたときにレイヤー種別を復元する内部値です。', 'Internal value used to restore the layer projection mode when a projection buffer is canceled.': '投影バッファをキャンセルしたときにレイヤーの投影方式を復元する内部値です。', 'Invert the final mask before opacity is applied.': '不透明度適用前の最終マスクを反転します。', 'Invert the generated height so lines become carved grooves instead of raised details.': '生成高さを反転し、線を盛り上げではなく彫り込みの溝として使います。', 'Invert the height-driven blend so cavities or low areas are favored instead of high areas.': '高さ駆動ブレンドを反転し、高い部分ではなく低い部分や溝を優先します。', "Invert this layer's sampled colors before blending. Useful for quick mask, roughness or decal reversals.": 'このレイヤーのサンプル色を合成前に反転します。マスク、粗さ、デカールの反転を素早く試したいときに便利です。', 'Item': '項目', 'Keep Paint System background callbacks active.': 'ペイントシステムのバックグラウンドコールバックを有効に保ちます。', 'Keep Layer Paint Engine background callbacks active.': 'Layer Paint Engine のバックグラウンドコールバックを有効に保ちます。', 'Keeps the darker result.': '暗い方を保持します。', 'Keeps the lighter result.': '明るい方を保持します。', 'Keymap': 'キーマップ', 'Last informational message generated by the add-on.': 'アドオンが最後に生成した情報メッセージです。', 'Last validation summary message.': '最後の検証結果メッセージです。', 'Layer': 'レイヤー', 'Layer Lists Mode': 'レイヤー一覧モード', 'Layer channel currently used by the projection buffer workflow.': '投影バッファワークフローで現在使われているレイヤーチャンネルです。', 'Lean toward non-destructive PBR authoring with smart masks, anchor-driven detailing and packed exports.': 'スマートマスク、アンカー駆動ディテール、パック書き出しを重視した非破壊PBR制作向けに寄せます。', 'Left click': '左クリック', 'Legacy': '旧互換', 'Legacy icon set from older Blender versions.': '旧 Blender バージョン由来のレガシーアイコンを使います。', 'Line': '線', 'Linear (perspective mode)': 'リニア（透視モード）', 'Linear interpolation similar to corner or perspective style deformations.': 'コーナー変形や遠近変形に近い線形補間です。', 'Link': 'リンク', 'Load': '読み込み', 'Loading': '読み込み中', 'Main': 'メイン', 'Main thickness of the generated vector feature. Lower values create crisper fine details.': '生成するベクトル形状の主な太さです。低い値ほど細くシャープなディテールになります。', 'Make Preview Mode use sRGB': 'プレビューモードを sRGB にする', 'Managed Smart Paint layer collection used by the non-destructive stack.': '非破壊スタックで使われる Smart Paint 管理レイヤーのコレクションです。', 'Marks that this material is controlled by Smart Paint and can be safely rebuilt from stored layer data.': 'このマテリアルが Smart Paint 管理下にあり、保存されたレイヤーデータから安全に再構築できることを示します。', 'Master multiplier for the bump preview built from the height channel.': '高さチャンネルから作るバンプ表示の全体強度です。', 'Master opacity of the layer after masks are evaluated.': 'マスク評価後に適用されるレイヤー全体の不透明度です。', 'Mesh map that will be baked by the generic Bake button.': '汎用のベイクボタンでベイクされるメッシュマップです。', 'Metalness channel.': 'メタルネスチャンネルです。', 'Mid click': '中クリック', 'Midlevel used by the displace preview. 0.5 is a good default for typical grayscale height maps where mid-gray means no displacement.': 'ディスプレイスプレビューで使うミッドレベルです。一般的なグレースケール高さマップでは、0.5 を基準にすると中間グレーが変位なしとして扱われやすくなります。', 'Minutes': '分', 'Mouse Button 4': 'マウスボタン4', 'Mouse Button 5': 'マウスボタン5', 'Mouse button used together with the selected modifiers for canvas rotation.': '選択した修飾キーと組み合わせてキャンバス回転に使うマウスボタンです。', 'Multi-channel image layer intended for full PBR paint sets such as color, roughness, metallic, normal, and height.': 'カラー、粗さ、メタリック、ノーマル、高さなどのフルPBRセット向けマルチチャンネル画像レイヤーです。', 'Multiplies the current result by the layer.': '結果に乗算します。', 'Multiply the assembled AO result into the base color so viewport preview more closely matches common game-texture exports.': '合成したAO結果をベースカラーへ乗算し、ゲーム用書き出しに近い見た目をビューポートで確認しやすくします。', 'Mute or unmute the layer without deleting its images or settings.': '画像や設定を削除せずにレイヤーを有効／無効化します。', 'Name of the last image opened for external editing. This is used by the quick reload helpers so round-trip paint edits are easier to manage.': '最後に外部編集で開いた画像名です。再読込補助が参照し、往復編集を管理しやすくします。', 'Name of the legacy Grease Pencil sidebar category. This is kept for compatibility with the original tool package.': '旧グリースペンシルのサイドバーカテゴリ名です。互換のために維持されています。', 'Name:': '名前:', 'Number of days between automatic version checks.': '自動バージョン確認の間隔（日数）です。', 'Number of hours between automatic version checks.': '自動バージョン確認の間隔（時間）です。', 'Number of minutes between automatic version checks.': '自動バージョン確認の間隔（分）です。', 'Object': 'オブジェクト', 'Offset the popup to the right side of the pointer to reduce hand occlusion while drawing with the left hand.': '左手で描いているときに手で隠れにくいよう、ポップアップをポインター右側へずらして表示します。', 'Opacity / transparency channel.': '不透明度／透明度チャンネルです。', 'Optional override for the exported texture set name. Leave empty to use the active material name.': '書き出しテクスチャセット名の任意上書きです。空ならアクティブマテリアル名を使います。', 'Output': '出力', 'Overlay layer for labels, stains, stickers and projected details.': 'ラベル・汚れ・ステッカー・投影ディテール向けの重ねレイヤーです。', 'Pack AO into Red, Roughness into Green, Metallic into Blue.': 'AOを赤、ラフネスを緑、メタリックを青へパックします。', 'Pack Metallic into Red, Roughness into Green, AO into Blue.': 'メタリックを赤、ラフネスを緑、AOを青へパックします。', 'Pack Roughness into Red, Metallic into Green, AO into Blue.': 'ラフネスを赤、メタリックを緑、AOを青へパックします。', 'Parallax Without Use Baked': 'ベイクなしパララックス', 'Parametric shape used by the vector-layer approximation tools. Use this for crisp panel lines, stitches and graphic decals.': 'ベクトルレイヤー近似ツールで使うパラメトリック形状です。くっきりしたパネルライン、ステッチ、グラフィックデカールに使います。', 'Per-layer UV rotation applied before sampling images or procedural masks.': '画像や生成マスクをサンプリングする前に掛かる、レイヤー単位のUV回転です。', 'Per-layer UV translation in normalized texture space.': '正規化されたテクスチャ空間での、レイヤー単位UV平行移動です。', 'Per-layer brightness adjustment applied before this layer is blended into the stack. Useful for quickly matching imported textures or decals without editing the source image.': 'このレイヤーをスタックへ合成する前に掛ける明るさ補正です。元画像を直接編集せずに、読み込んだテクスチャやデカールの明るさ合わせを素早く行えます。', 'Per-layer contrast adjustment applied before blending. Positive values add punch, negative values flatten the image.': '合成前に掛けるレイヤー単位のコントラスト補正です。正の値でメリハリを増し、負の値で平坦にします。', 'Per-layer gamma correction. Values above 1 darken the midtones, values below 1 brighten them.': 'レイヤー単位のガンマ補正です。1より大きい値は中間調を暗くし、1より小さい値は明るくします。', 'Per-layer hue shift. Small values are usually enough for decal and color-variation work.': 'レイヤー単位の色相シフトです。デカールや色バリエーション用途では小さな値で十分なことが多いです。', 'Per-layer saturation multiplier. 1 keeps the original saturation, 0 removes color.': 'レイヤー単位の彩度倍率です。1で元の彩度を維持し、0で色味を取り除きます。', 'Per-layer value / brightness multiplier in HSV space. Use this for quick decal and albedo intensity matching.': 'HSV空間でのレイヤー単位の明度倍率です。デカールやアルベド強度を手早く合わせる用途に向きます。', 'Pixel margin used for bake operations.': 'ベイク時に使うピクセル余白です。', 'Preferred UV map name for newly created layers.': '新規レイヤーで優先して使うUVマップ名です。', 'Preferred coordinate type used by Paint System tools.': 'ツールで優先する座標タイプです。', 'Prepare': '準備', 'Previous': '前へ', 'Print additional information to the console for troubleshooting.': 'トラブルシュート用に追加情報をコンソールへ表示します。', 'Procedural helper layer that relies on masks and generated data.': 'マスクや生成データを使うプロシージャル補助レイヤーです。', 'Projection Source': '投影元', 'Read a named vertex color or color attribute as a mask.': '指定した頂点カラー／カラー属性をマスクとして読みます。', 'Reference another layer channel similar to anchor points.': 'アンカーポイントのように別レイヤーのチャンネルを参照します。', 'Require Alt for canvas rotation.': 'キャンバス回転に Alt を必須にします。', 'Require Alt for this shortcut.': 'このショートカットに Alt を必須にします。', 'Require Ctrl for canvas rotation.': 'キャンバス回転に Ctrl を必須にします。', 'Require Ctrl for this shortcut.': 'このショートカットに Ctrl を必須にします。', 'Require Shift for canvas rotation.': 'キャンバス回転に Shift を必須にします。', 'Require Shift for this shortcut.': 'このショートカットに Shift を必須にします。', 'Require the operating-system modifier key such as Win, Super, or Cmd.': 'Win、Super、Cmd などの OS 修飾キーを必須にします。', 'Resolution for newly baked mesh maps.': '新しくベイクするメッシュマップの解像度です。', 'Resolution of the regular image atlas created by Layer Paint Engine.': 'Layer Paint Engine が作る通常画像アトラスの解像度です。', 'Resolution used for generated vector-mask and height helper images.': '生成されるベクトルマスク画像や高さ補助画像に使う解像度です。', 'Resolution used when creating helper checker images.': '補助チェッカー画像作成時に使う解像度です。', 'Resolution:': '解像度:', 'Right click': '右クリック', 'Rotation of the generated vector shape inside the helper image.': '補助画像の中で生成されるベクトル形状の回転です。', 'Safe empty border around the generated vector shape.': '生成形状の周囲に確保する安全な余白です。', 'Save baked and newly generated images automatically whenever possible.': '可能な場合はベイクや新規生成のあとに画像を自動保存します。', 'Scale Down': '縮小', 'Scale Up': '拡大', 'Scale applied to the displacement output generated from the height result.': '高さ結果から作るディスプレイスメント出力に掛ける倍率です。', 'Scale of the procedural noise / grunge mask.': 'プロシージャルノイズ／グランジマスクのスケールです。', 'Scale the color wheel shown in the Texture Paint right-click popover.': 'テクスチャペイントの右クリックポップオーバー内に出るカラーホイール倍率です。', 'Scale the main color picker.': 'メインのカラーピッカー倍率です。', 'Screen-space pixel distance that represents one frame while scrubbing.': 'スクラブ中に 1 フレームとして扱う画面上のピクセル間隔です。', 'Seed-like offset for the anti-tiling pattern. Change this to quickly get a different breakup arrangement without touching the source texture.': 'アンチタイリングパターン用の疑似シードです。元テクスチャを変更せずに、ブレイクアップの並びだけを素早く変えられます。', 'Shape': '形状', 'Sharper settings for stencil, decal and logo work.': 'ステンシル、デカール、ロゴ作業向けのシャープな設定です。', 'Shortcut used to start timeline scrubbing from the viewport.': 'ビューポートからタイムラインスクラブを開始するショートカットです。', 'Show': '表示', 'Show Experimental Features': '実験的機能を表示', 'Show HSV sliders under the color wheel in the Texture Paint right-click popover.': 'テクスチャペイントの右クリックポップオーバーで、カラーホイール下に HSV スライダーを表示します。', 'Show both list types for debugging.': 'デバッグ用に両方の一覧を表示します。', 'Show brush radius and strength controls in the right-click popover.': '右クリックポップオーバーにブラシ半径と強さの制御を表示します。', 'Show developer-oriented options inside Layer Paint Engine.': 'Layer Paint Engine 内で開発者向けオプションを表示します。', 'Show helper tooltips in the Paint System UI.': 'ペイントシステム UI 内で補助ツールチップを表示します。', 'Show image previews or thumbnails in Layer Paint Engine layer lists.': 'Layer Paint Engine のレイヤー一覧で画像プレビューやサムネイルを表示します。', 'Show keyframe markers in the overlay.': 'オーバーレイ内にキーフレームマーカーを表示します。', 'Show more color picker controls.': 'カラーピッカーの詳細設定を表示します。', 'Show opacity values in the Paint System layer list.': 'ペイントシステムのレイヤー一覧に不透明度を表示します。', 'Show overlay information while timeline scrubbing is active.': 'タイムラインスクラブ中にオーバーレイ情報を表示します。', 'Show the active palette swatches in the right-click popover.': '右クリックポップオーバーにアクティブパレットのスウォッチを表示します。', 'Show the current frame number as text.': '現在のフレーム番号を文字で表示します。', 'Show the frame offset from the starting point as text.': '開始位置からのフレーム差分を文字で表示します。', 'Show the hexadecimal color field in color settings.': '色設定内に 16 進カラー欄を表示します。', 'Show the playhead line in the overlay.': 'オーバーレイ内に再生ヘッド線を表示します。', 'Show the temporary timeline guide.': '一時的なタイムラインガイドを表示します。', 'Show unfinished experimental Layer Paint Engine features.': '未完成の実験的 Layer Paint Engine 機能を表示します。', 'Skip Property Popups (Hold Shift to Show)': 'プロパティポップアップを省略（Shift で表示）', 'Skip property popups unless Shift is held, and reuse the last values when the popup is skipped.': 'Shift を押している場合を除いてプロパティポップアップを省略し、省略時は前回の値を再利用します。', 'Snapshot': 'スナップショット', 'Soft falloff added to the generated shape edge. Use small values for hard-surface details and slightly higher values for fabric or painted graphics.': '生成形状のエッジへ加える柔らかさです。ハードサーフェスの細部には小さめ、布や描画的なグラフィックには少し高めが向きます。', 'Softer, more random settings for dirt and wear painting.': '汚れや摩耗向けの、柔らかくランダム性の高い設定です。', 'Solid value layer for quickly blocking in color and PBR values.': '色やPBR値を素早く埋める塗りつぶしレイヤーです。', 'Spline (smooth deform)': 'スプライン（滑らか変形）', 'Spline interpolation for smoother deformations, especially with more subdivisions.': '分割数が多い場合に滑らかな変形を作りやすいスプライン補間です。', 'Square': '四角', 'Standard layer blending.': '標準的なレイヤーブレンドです。', 'Stored AO mesh map image name.': '保存されているAOメッシュマップ画像名です。', 'Stored curvature mesh map image name.': '保存されている曲率メッシュマップ画像名です。', 'Stored normal mesh map image name.': '保存されているノーマルメッシュマップ画像名です。', 'Stored position mesh map image name.': '保存されている位置メッシュマップ画像名です。', 'Stored thickness approximation map image name.': '保存されている厚み近似マップ画像名です。', 'Strength applied to the generated height image when a new vector decal layer is created.': '新しいベクトルデカールレイヤー作成時に、生成高さ画像へ掛ける強度です。', 'Strength multiplier for bump or displacement preview.': 'バンプ／ディスプレイスメント表示にかかる強度です。', 'Strength multiplier for emission contribution.': '発光寄与にかかる強度です。', "Strength multiplier for this layer's normal contribution.": 'このレイヤーのノーマル寄与にかかる強度です。', 'Style': 'スタイル', 'Style ID': 'スタイル ID', 'Style Name': 'スタイル名', 'Subtracts the layer from the result.': '結果から減算します。', 'Surface micro roughness channel.': '表面の細かな粗さチャンネルです。', 'Tangent space normal channel.': 'タンジェント空間ノーマルチャンネルです。', 'Temporary image used by the projection buffer workflow.': '投影バッファワークフローで使う一時画像です。', 'Texture size used when estimating texel density in pixels per Blender unit. Use the resolution you plan to paint or export at.': 'Blender単位あたり何ピクセルかを概算するテクセル密度計測で使うテクスチャ解像度です。実際に塗る、または書き出す予定の解像度を指定してください。', 'Threshold used by procedural masks to sharpen or soften the result.': '生成マスクの輪郭を締めたり緩めたりするしきい値です。', 'Timeline Scrub': 'タイムラインスクラブ', 'Tint applied when a new vector decal layer is created.': '新しいベクトルデカールレイヤーを作るときに使う色です。', 'Tools': 'ツール', 'Try to use a separate image atlas for each Layer Paint Engine node tree.': '各 Layer Paint Engine ノードツリーごとに別の画像アトラスを使うようにします。', 'UV map': 'UVマップ', 'UV map name used by this layer when Projection is set to UV.': '投影がUVのときにこのレイヤーが使うUVマップ名です。', 'Unavailable': '利用不可', 'Undetected': '未検出', 'Up': '上', 'Use Blender-timer based periodic autosave for dirty texture images.': '変更済みテクスチャ画像に対し、Blender タイマーを使った定期自動保存を行います。', 'Use CPU by default.': '既定で CPU を使います。', 'Use Grease Pencil Object Keyframes': 'グリースペンシルオブジェクトのキーフレームも使う', 'Use HUD': 'HUD を使う', 'Use Image Preview/Thumbnail': '画像プレビュー/サムネイルを使う', 'Use UV coordinates.': 'UV座標を使います。', 'Use a custom resolution by default.': '既定でカスタム解像度を使います。', 'Use a dedicated mask image.': '専用のマスク画像を使います。', 'Use a denser Paint System layout that saves screen space.': '画面スペースを節約する密度の高いレイアウトを使います。', 'Use a dirt / grunge procedural mask.': '汚れ・グランジ系の生成マスクを使います。', 'Use a gap-less flipbook style scrub mode that always snaps through available keys.': '利用可能なキーを常に順送りする、隙間なしのフリップブック式スクラブを使います。', 'Use generated coordinates with box projection for seam friendly placement.': '継ぎ目に強いボックス投影を使います。', 'Use mouse button 4 (usually Back).': 'マウスボタン4（通常は戻る）を使います。', 'Use mouse button 5 (usually Forward).': 'マウスボタン5（通常は進む）を使います。', 'Use procedural noise as a mask.': 'プロシージャルノイズをマスクに使います。', 'Use the alpha channel.': 'アルファチャンネルを使います。', 'Use the baked ambient occlusion image as a mask.': 'ベイクしたAO画像をマスクに使います。', 'Use the baked/generated position map as a mask.': 'ベイク／生成した位置マップをマスクに使います。', 'Use the blue channel.': '青チャンネルを使います。', 'Use the green channel.': '緑チャンネルを使います。', 'Use the last selected bake device.': '最後に選択したベイクデバイスを使います。', 'Use the last selected image size.': '最後に選択した画像サイズを使います。', 'Use the layer opacity only.': 'レイヤー不透明度のみを使います。', 'Use the left mouse button.': '左マウスボタンを使います。', 'Use the middle mouse button.': '中マウスボタンを使います。', 'Use the older Paint System interface style.': '以前のインターフェース表示を使います。', 'Use the red channel.': '赤チャンネルを使います。', 'Use the right mouse button.': '右マウスボタンを使います。', 'Use the thickness approximation map as a mask.': '厚み近似マップをマスクに使います。', 'Use unique Image Atlas per Layer Paint Engine tree': 'ツリーごとに固有アトラスを使う', 'Version Check Interval': '更新確認間隔', 'View3D': 'View3D', 'Weathering helper layer tuned for dust, leaks, erosion and broad material breakup.': 'ほこり、垂れ、侵食、広い質感崩し向けに調整されたウェザリング補助レイヤーです。', 'When a paint target is activated, automatically switch the active mesh into Texture Paint mode.': 'ペイント対象を有効にしたとき、自動でテクスチャペイントモードへ切り替えます。', 'When in camera view, rotate from the viewport center instead of the camera center.': 'カメラビュー時に、カメラ中心ではなくビューポート中心を基準に回転します。', 'When the source image already exists on disk, allow the timer path to overwrite that file instead of saving only autosave copies.': '元画像がディスク上にある場合、自動保存コピーだけでなくその既存ファイル自体もタイマー保存で上書きできるようにします。', 'Whether this layer contributes to the base color channel.': 'このレイヤーをベースカラーチャンネルへ寄与させるかです。', 'Width of each layer entry box. Larger values make long names easier to read.': '各レイヤー項目ボックスの幅です。大きいほど長いレイヤー名を読みやすくなります。', 'Width:': '幅:', 'Zero-based frame index. Frame 0 is the top-left tile, then it advances left-to-right, top-to-bottom.': '0始まりのフレーム番号です。0 は左上タイルで、その後は左から右、上から下の順に進みます。', 'Hex': '16進', })
# --- Smart Paint generated full UI localization END ---


# --- Smart Paint residual UI localization START ---
BASE_TRANSLATIONS.update({'CPU': 'CPU', 'Smart Paint': 'Smart Paint', 'Cycles': 'Cycles', 'Eevee': 'Eevee', 'Extend': '拡張', 'Flat': 'フラット', 'Transparent': '透明', 'R': 'R', 'G': 'G', 'B': 'B', 'A': 'A', 'Method': '方式', 'Principled': 'プリンシプル', 'Diffuse': 'ディフューズ', 'RGB': 'RGB', 'Both': '両方', 'INIT': '初期化', 'Compression': '圧縮', 'Quality': '品質', 'Log': 'ログ', 'X': 'X', 'Y': 'Y', 'Pending': '保留中', '1024x1024': '1024x1024', '2048x2048': '2048x2048', '4096x4096': '4096x4096', '1x': '1x', '2x': '2x', '3x': '3x', '4x': '4x', 'Skip': 'スキップ', 'Linked': 'リンク済み', 'External application': '外部アプリケーション', 'Z': 'Z', 'Expanded': '展開', 'Point': 'ポイント', 'Vector': 'ベクトル', 'UID': 'UID', 'Shader': 'シェーダー'})
# --- Smart Paint residual UI localization END ---





# --- Toolset exact residual UI localization START ---
BASE_TRANSLATIONS.update({' (Active)': '（アクティブ）', ' (Disabled)': '（無効）', 'Active Image: ': 'アクティブ画像: ', 'Object: ': 'オブジェクト: ', 'Material: ': 'マテリアル: ', 'Source: ': 'ソース: ', 'Fill ': '塗りつぶし ', 'Number of Images: ': '画像数: ', 'Number of Generated Textures: ': '生成テクスチャ数: ', 'Number of Color Ramps: ': 'カラーランプ数: ', 'Number of RGB Curves: ': 'RGBカーブ数: ', 'Test Run Count: ': 'テスト実行数: ', 'Test Error Count: ': 'テストエラー数: ', 'Test Failed Count: ': 'テスト失敗数: ', 'A mesh object must be active.': 'メッシュオブジェクトをアクティブにしてください。', 'Blender text datablocks are not available.': 'Blender テキストデータブロックを利用できません。', 'Color attributes are not available.': 'カラー属性を利用できません。', 'No active object.': 'アクティブオブジェクトがありません。', 'No material to rebuild.': '再構築するマテリアルがありません。', 'No valid search directories were found for path repair.': 'パス修復に使える検索フォルダーが見つかりません。', 'OS': 'OS', 'Win': 'Win', 'Smart Paint properties are not registered.': 'Smart Paint プロパティが登録されていません。', 'Smart Paint scene properties are not registered.': 'Smart Paint シーンプロパティが登録されていません。', 'The active mesh does not support color attributes.': 'アクティブメッシュはカラー属性に対応していません。', 'The active object does not support UV layers.': 'アクティブオブジェクトは UV レイヤーに対応していません。', 'The selected snapshot text is empty.': '選択したスナップショットテキストが空です。', 'The selected text is not a Smart Paint snapshot.': '選択したテキストは Smart Paint スナップショットではありません。', 'donation': '寄付', 'version': 'バージョン', })
# --- Toolset exact residual UI localization END ---

# --- Smart Paint dynamic Layer Paint Engine RNA localization START ---
def _build_dynamic_ucupaint_translations() -> dict[str, str]:
    'Return exact Japanese translations for Layer Paint Engine RNA strings built at import time.\n\n    These source strings are composed with get_vertex_color_label() and\n    get_addon_title() before Blender registers the RNA property.  They must be\n    present as exact English source keys so Blender can show only the active\n    language instead of mixed English/Japanese text.\n    '
    out: dict[str, str] = {}

    def add(en: str, ja: str) -> None:
        if en and ja:
            out[en] = ja

    # Blender 5.x uses Color Attribute.  Vertex Color variants are kept so the
    # same package remains safe if a compatibility path evaluates these helpers
    # differently in a future host.
    vertex_labels = (
        ('Color Attribute', 'Color attribute', 'color attribute', 'カラー属性'),
        ('Vertex Color', 'Vertex color', 'vertex color', '頂点カラー'),
    )
    for title_label, sentence_label, lower_label, ja_label in vertex_labels:
        add(f'Bake channel to {lower_label}', f'{ja_label}へチャンネルをベイク')
        add(f'Bake Channel to {title_label}', f'チャンネルを{ja_label}へベイク')
        add(f'Target {title_label} Name', f'対象{ja_label}名')
        add(f'Target {lower_label} name', f'対象{ja_label}名')
        add(f"Target {lower_label} name, it will create one if it doesn't exist", f'対象{ja_label}名です。存在しない場合は新規作成します。')
        add(f'Force target {lower_label} to be first on the {lower_label}s list (useful for exporting)', f'対象{ja_label}を{ja_label}リストの先頭にします。書き出し時に便利です。')
        add(f'Also delete the {lower_label}', f'{ja_label}も削除')
        add(f'Has any channel enabled Bake As {title_label}', f'{ja_label}としてベイクするチャンネルがあるかを示します。')
        add(f'Force First {title_label} Channel', f'最初の{ja_label}チャンネルを固定')
        add(f'Force the first channel after baking the {title_label}', f'{ja_label}のベイク後に最初のチャンネルを固定します。')
        add(f'New {title_label} to Layer Channel Source', f'新規{ja_label}をレイヤーチャンネルソースに追加')
        add(f'New {title_label} to custom layer channel source', f'新規{ja_label}をカスタムレイヤーチャンネルソースに追加します。')
        add(f'{title_label} Data Type', f'{ja_label}データタイプ')
        add(f'{sentence_label} data type', f'{ja_label}データタイプ')
        add(f'{title_label} Domain', f'{ja_label}ドメイン')
        add(f'{sentence_label} domain', f'{ja_label}ドメイン')
        add(f'Fill Selected Geometry with {title_label} / Color ID Mask', f'選択ジオメトリを{ja_label} / カラーIDマスクで塗りつぶし')
        add(f'Fill selected geometry with {lower_label} or color ID mask', f'選択ジオメトリを{ja_label}またはカラーIDマスクで塗りつぶします。')
        add(f'Fill Selected Geometry with {title_label} / Color ID', f'選択ジオメトリを{ja_label} / カラーIDで塗りつぶし')
        add(f'Fill selected geometry with {lower_label} / color ID', f'選択ジオメトリを{ja_label} / カラーIDで塗りつぶします。')
        add(f'Mask {title_label} Data Type', f'マスク{ja_label}データタイプ')
        add(f'Mask {lower_label} data type', f'マスク{ja_label}データタイプ')
        add(f'Mask {title_label} Domain', f'マスク{ja_label}ドメイン')
        add(f'Mask {lower_label} domain', f'マスク{ja_label}ドメイン')
        add(f'Divide RGB by its alpha value (very recommended for {lower_label} layer)', f'{ja_label}レイヤーでは、RGBをアルファ値で割ることを強く推奨します。')
        add(f'{title_label} Name', f'{ja_label}名')
        add(f'Channel override {lower_label} name', f'チャンネル上書き用の{ja_label}名')
        add(f'Dividing RGB value by its alpha\nThis can be useful remove dark outline on painted image/{lower_label}\nWARNING: This is a hack solution so the result might not looks right', f'RGB値をアルファで除算します。\nペイント画像や{ja_label}の暗い縁取りを減らす場合に役立ちます。\n警告: これは簡易的な対処のため、結果が常に正しく見えるとは限りません。')
        add(f'Also remove baked {lower_label}', f'ベイク済み{ja_label}も削除')
        add(f'Enable Bake to {title_label}', f'{ja_label}へのベイクを有効化')
        add(f'Enable {lower_label} as bake target', f'{ja_label}をベイク対象として有効化します。')
        add(f'Use Baked {title_label}', f'ベイク済み{ja_label}を使用')
        add(f'Use baked {lower_label}', f'ベイク済み{ja_label}を使用します。')
        add(f'Bake To {title_label} Alpha', f'{ja_label}アルファへベイク')
        add(f'When enabled, the channel are baked only to Alpha with {lower_label}', f'有効にすると、チャンネルを{ja_label}のアルファにのみベイクします。')
        add(f'Tangent sign {lower_label} needed to make sure Blender 2.8 Cycles normal and parallax works.\n(This is because Blender 2.8 normal map node has different behavior than Blender 2.7)', f'Blender 2.8 Cycles のノーマルとパララックスを正しく動作させるために、タンジェント符号用の{ja_label}が必要です。\n（Blender 2.8 のノーマルマップノードの挙動が Blender 2.7 と異なるためです）')
        add(f'Bake to {title_label}', f'{ja_label}へベイク')
        add(f'Expand bake to {lower_label} settings', f'{ja_label}へのベイク設定を展開します。')
        add(f'Show {title_label} List', f'{ja_label}リストを表示')
        add(f'Show {lower_label} list', f'{ja_label}リストを表示します。')
        add(f'Maximum {lower_label}s reached! Need at least {{…}} {lower_label}(s) to bake proper normal!', f'{ja_label}の最大数に達しました。正しいノーマルをベイクするには少なくとも{{…}}個の{ja_label}が必要です。')
        add(f'{sentence_label} merge does not works with modifers and masks yet!', f'{ja_label}の結合は、モディファイアーとマスクにはまだ対応していません。')
        add(f'{sentence_label} merge only works with Mix blend type for now!', f'{ja_label}の結合は現在、ミックスブレンドタイプでのみ動作します。')

    addon_titles = ('Layer Paint Engine',)
    for addon_title in addon_titles:
        add(f'Remove {addon_title} Channel', f'{addon_title}チャンネルを削除')
        add(f'Remove {addon_title} channel', f'{addon_title}チャンネルを削除します。')
        add(f'Change Active {addon_title} Node', f'アクティブ{addon_title}ノードを変更')
        add(f'{addon_title} Node Name', f'{addon_title}ノード名')
        add(f'Use unique Image Atlas per {addon_title} tree', f'{addon_title}ツリーごとに固有の画像アトラスを使う')
        add(f'Try to use different image atlas per {addon_title} tree', f'{addon_title}ツリーごとに別の画像アトラスを使うようにします。')
        add(f'Enable baked outside by default when creating new {addon_title} node.\n(Useful for creating game assets)', f'新規{addon_title}ノード作成時に、既定で外部ベイクを有効にします。\n（ゲームアセット作成に便利です）')
        add(f'Always fo frame change evaluation on {addon_title} keyfame data (slow)', f'フレーム変更時に{addon_title}のキーフレームデータを常に評価します（低速）。')
        add(f"{addon_title}'s sponsor is updated daily", f'{addon_title}のスポンサー情報は毎日更新されます。')
        add(f'Active custom data for Blender\'s paint mode and edit mode, or {addon_title}\'s Custom Data preview mode', f'Blenderのペイントモード/編集モード、または{addon_title}のカスタムデータプレビューモードで使用するアクティブなカスタムデータです。')
        add(f'Active custom normal data for Blender\'s paint mode and edit mode, or {addon_title}\'s Custom Data preview mode', f'Blenderのペイントモード/編集モード、または{addon_title}のカスタムデータプレビューモードで使用するアクティブなカスタムノーマルデータです。')
        add(f'Active mask for Blender\'s paint mode and edit mode, or {addon_title}\'s Mask preview mode', f'Blenderのペイントモード/編集モード、または{addon_title}のマスクプレビューモードで使用するアクティブマスクです。')
        add(f'You need to select object that uses {addon_title} node!', f'{addon_title}ノードを使用しているオブジェクトを選択してください。')
        add(f"This {addon_title} node setup isn't baked yet!", f'この{addon_title}ノード構成はまだベイクされていません。')
        add(f'Duplicate Material and {addon_title} nodes', f'マテリアルと{addon_title}ノードを複製')
        add(f'Fix Multi-User {addon_title} Node', f'マルチユーザー{addon_title}ノードを修正')
        add(f'Support {addon_title}!', f'{addon_title}を支援')
        add(f'{addon_title} Discord Server', f'{addon_title} Discord サーバー')
        add(f'{addon_title} Wiki', f'{addon_title} Wiki')
        add(f'{addon_title} GitHub', f'{addon_title} GitHub')
        add(f'{addon_title} is created by:', f'{addon_title} の作成者:')
        add(f'Open Images from Material to single {addon_title} Layer', f'マテリアルの画像を単一{addon_title}レイヤーとして開く')
        add(f'Open images inside material node tree to single {addon_title} layer', f'マテリアルノードツリー内の画像を単一{addon_title}レイヤーとして開きます。')
        add(f'Open Layers from {addon_title} Material', f'{addon_title}マテリアルからレイヤーを開く')
        add(f'Open layers from material to current {addon_title} material', f'マテリアルのレイヤーを現在の{addon_title}マテリアルへ開きます。')
        add(f'New {addon_title} Modifier', f'新規{addon_title}モディファイアー')
        add(f'Move {addon_title} Modifier', f'{addon_title}モディファイアーを移動')
        add(f'Remove {addon_title} Modifier', f'{addon_title}モディファイアーを削除')
        add(f'Quick {addon_title} Node Setup', f'{addon_title}ノードをクイックセットアップ')
        add(f'Add new {addon_title} Node', f'新規{addon_title}ノードを追加')
        add(f'Add new {addon_title} node', f'新規{addon_title}ノードを追加します。')
        add(f'Connect {addon_title} Channel Alpha', f'{addon_title}チャンネルアルファを接続')
        add(f'Connect {addon_title} channel alpha to other nodes', f'{addon_title}チャンネルのアルファを他のノードへ接続します。')
        add(f'Connect {addon_title} Channel', f'{addon_title}チャンネルを接続')
        add(f'Connect {addon_title} channel to other nodes', f'{addon_title}チャンネルを他のノードへ接続します。')
        add(f'Auto setup new {addon_title} Channel', f'新規{addon_title}チャンネルを自動セットアップ')
        add(f'Auto setup new {addon_title} channel', f'新規{addon_title}チャンネルを自動でセットアップします。')
        add(f'Toggle {addon_title} Channel as Alpha', f'{addon_title}チャンネルをアルファとして切り替え')
        add(f'Toggle {addon_title} channel as alpha channel', f'{addon_title}チャンネルをアルファチャンネルとして切り替えます。')
        add(f'Add new {addon_title} Channel', f'新規{addon_title}チャンネルを追加')
        add(f'Add new {addon_title} channel', f'新規{addon_title}チャンネルを追加します。')
        add(f'Move {addon_title} Channel', f'{addon_title}チャンネルを移動')
        add(f'Move {addon_title} channel', f'{addon_title}チャンネルを移動します。')
        add(f'Rename {addon_title} Tree', f'{addon_title}ツリーの名前を変更')
        add(f'Duplicate {addon_title} Nodes', f'{addon_title}ノードを複製')
        add(f"{addon_title} doesn't work with more than one user! Duplicate to make it single user", f'{addon_title}は複数ユーザーでは正しく動作しません。単一ユーザー化するために複製します。')
        add(f'Remove {addon_title} Node', f'{addon_title}ノードを削除')
        add(f'Remove {addon_title} node, but keep all baked channel image(s)', f'ベイク済みチャンネル画像を残したまま、{addon_title}ノードを削除します。')
        add(f'Clean {addon_title} Caches', f'{addon_title}キャッシュを削除')
        add(f'Clean {addon_title} caches', f'{addon_title}のキャッシュを削除します。')
        add(f'{addon_title} Sponsor Menu', f'{addon_title}スポンサーメニュー')
        add(f'Support {addon_title}', f'{addon_title}を支援')
        add(f'{addon_title} Copy the image file path to the system clipboard', f'{addon_title}画像ファイルパスをシステムクリップボードへコピーします。')
        add(f'{addon_title} Open the folder containing the image file and highlight it', f'{addon_title}画像ファイルを含むフォルダーを開き、そのファイルを選択表示します。')
        add(f'{addon_title} Options for copying the image path or opening the containing folder', f'{addon_title}画像パスのコピー、または格納フォルダーを開くためのオプションです。')
        add(f'{addon_title} Asset Browser Menu', f'{addon_title}アセットブラウザーメニュー')
        add(f'{addon_title} asset browser menu', f'{addon_title}アセットブラウザーメニューです。')
        add(f'{addon_title} File Browser Menu', f'{addon_title}ファイルブラウザーメニュー')
        add(f'{addon_title} file browser menu', f'{addon_title}ファイルブラウザーメニューです。')
        add(f'{addon_title} About', f'{addon_title}について')
        add(f'{addon_title} Special Menu', f'{addon_title}特殊メニュー')
        add(f'Update {addon_title} Node Groups', f'{addon_title}ノードグループを更新')
        add(f'Update {addon_title} node groups to newest version', f'{addon_title}ノードグループを最新バージョンへ更新します。')

    add('View3D', '3Dビュー')
    add('Fix missing image/color attribute data', '不足している画像/カラー属性データを修正')
    add('Fix missing image/vertex color data', '不足している画像/頂点カラーデータを修正')
    add('Refresh Tangent Sign Color Attributes', 'タンジェント符号カラー属性を更新')
    add('Refresh Tangent Sign Vertex Colors', 'タンジェント符号頂点カラーを更新')
    add('Refresh tangent sign color attributes to make it work in Blender 2.8', 'Blender 2.8で動作するようにタンジェント符号カラー属性を更新します。')
    add('Refresh tangent sign vertex colors to make it work in Blender 2.8', 'Blender 2.8で動作するようにタンジェント符号頂点カラーを更新します。')

    add('Set Active Color Attribute', 'アクティブカラー属性を設定')
    add('Set Active Vertex Color', 'アクティブ頂点カラーを設定')
    add('Set active color attribute', 'アクティブカラー属性を設定します。')
    add('Set active vertex color', 'アクティブ頂点カラーを設定します。')
    add('Select Faces based on Color Attribute', 'カラー属性を基準に面を選択')
    add('Select Faces based on Vertex Color', '頂点カラーを基準に面を選択')
    add('Select faces based on color attribute', 'カラー属性を基準に面を選択します。')
    add('Select faces based on vertex color', '頂点カラーを基準に面を選択します。')
    add('Color Attribute Fill Face with Custom Color', 'カスタムカラーでカラー属性の面を塗りつぶし')
    add('Vertex Color Fill Face with Custom Color', 'カスタムカラーで頂点カラーの面を塗りつぶし')
    add('Fill selected polygon with color attribute with custom color', '選択ポリゴンのカラー属性をカスタムカラーで塗りつぶします。')
    add('Fill selected polygon with vertex color with custom color', '選択ポリゴンの頂点カラーをカスタムカラーで塗りつぶします。')
    add('Color Attribute Fill', 'カラー属性を塗りつぶし')
    add('Vertex Color Fill', '頂点カラーを塗りつぶし')
    add('Fill selected polygon with color attribute', '選択ポリゴンのカラー属性を塗りつぶします。')
    add('Fill selected polygon with vertex color', '選択ポリゴンの頂点カラーを塗りつぶします。')
    add('Color Attribute Editor', 'カラー属性エディター')
    add('Vertex Color Editor', '頂点カラーエディター')


    return out


BASE_TRANSLATIONS.update(_build_dynamic_ucupaint_translations())


# Localization pass 1.9.288: user-visible sources that had no Japanese entry.
# External bridge N-panel / operators / reports, lightweight MVP layer UI,
# and Smart profile / quality / button-style enum item names.
BASE_TRANSLATIONS.update({
    'External Paint Stroke Observer': '外部ペイントストローク監視',
    'Observe completed native paint strokes while connected. The observer uses only actual mouse/pen events and creates no timer or idle wakeup': '接続中に完了したネイティブペイントストロークを監視します。実際のマウス／ペンイベントのみを使用し、タイマーやアイドル起床は作りません',
    'Connect': '接続',
    'Start the selected external app bridge for the active Smart Paint PSD': 'アクティブな Smart Paint PSD に対して、選択した外部アプリブリッジを開始します',
    'Disconnect': '切断',
    'Stop the isolated exchange worker and disconnect the external app bridge': '分離交換ワーカーを停止し、外部アプリブリッジを切断します',
    'Open Exchange': '交換ファイルを開く',
    'Open or focus the isolated exchange in the connected external app': '接続中の外部アプリで分離交換ファイルを開くか、前面に表示します',
    'Apply External Changes': '外部変更を適用',
    'Apply the latest verified external pixel changes as one baseline transition': '検証済みの最新外部ピクセル変更を、1回のベースライン遷移として適用します',
    'Sync / Open': '同期 / 開く',
    'Retry pending verified changes, then open or focus the exchange': '保留中の検証済み変更を再試行し、続けて交換ファイルを開くか前面に表示します',
    'Backend': 'バックエンド',
    'External paint application': '外部ペイントアプリケーションです',
    'Open and reload the isolated exchange in Adobe Photoshop': 'Adobe Photoshop で分離交換ファイルを開いて再読込します',
    'Open the isolated exchange in Clip Studio Paint': 'Clip Studio Paint で分離交換ファイルを開きます',
    'External app': '外部アプリ',
    'External bridge disconnected': '外部ブリッジを切断しました',
    'Opening exchange': '交換ファイルを開いています',
    'No new external changes': '新しい外部変更はありません',
    'Sync queued': '同期を予約しました',
    'Photoshop / Clip Studio Paint compatible native adjustment layer': 'Photoshop / Clip Studio Paint 互換のネイティブ調整レイヤーです',
    'Drag Layer': 'レイヤーをドラッグ',
    'Hold and drag to reorder this layer or folder within its current group': '押したままドラッグして、このレイヤーまたはフォルダーを現在のグループ内で並べ替えます',
    'Toggle Smart Paint Section': 'Smart Paint セクションを開閉',
    'Open or close one Smart Paint N-panel section without changing Blender data': 'Blender のデータを変更せずに、Smart Paint の N パネルセクションを開閉します',
    'Smart Paint Help': 'Smart Paint ヘルプ',
    'Show detailed usage for this Smart Paint section': 'この Smart Paint セクションの詳しい使い方を表示します',
    'Group Blend': 'グループ合成',
    'Studio PBR Smart Stack': 'スタジオPBRスマートスタック',
    'Game Asset Fast Prep': 'ゲームアセット高速準備',
    'VFX UDIM Projection Stack': 'VFX UDIM投影スタック',
    'Concept / AI-Ready Stack': 'コンセプト / AI対応スタック',
    '2D Creator / advanced image editor-Smart Paint Studio Smart Stack': '2Dクリエイター / 高機能画像エディター・Smart Paint スタジオスマートスタック',
    'Superior Production Stack': '上位プロダクションスタック',
    'Performance / Fast': 'パフォーマンス / 高速',
    'Balanced Production': 'バランス型プロダクション',
    'Production High Fidelity': 'プロダクション高忠実度',
    'VFX / UDIM Fidelity': 'VFX / UDIM忠実度',
    '2D Print / Illustration Clean': '2D印刷 / イラストクリーン',
    'Icon Cards / Large': 'アイコンカード / 大',
    'Hybrid Icons + Text': 'アイコン+テキスト併用',
    'Text Only / Classic': 'テキストのみ / クラシック',
    'Normal OpenGL ↔ DirectX': 'ノーマル OpenGL ↔ DirectX',
    'Roughness ↔ Smoothness': 'ラフネス ↔ スムースネス',
})
# --- Smart Paint dynamic Layer Paint Engine RNA localization END ---

BASE_TRANSLATIONS.update({
    'rebuilt': '再構築',
    'reused': '再利用',
    'color harmony requires a color with visible saturation': '調和色には彩度のある色が必要です',
    'missing GIMP Palette header': 'GIMP パレットのファイルではありません',
    'palette contains no valid colors': 'パレットに有効な色がありません',
    'image contains no visible colors': '画像に見える色がありません',
    'Image Paint settings are unavailable': 'テクスチャペイントの設定がありません',
    'invalid image dimensions': '画像の大きさが正しくありません',
    'source_psd_missing': '元のPSDがありません',
    'material_missing': 'マテリアルがありません',
    'smart_paint_material_not_found': 'Smart Paint のマテリアルがありません',
    'paintable_layer_missing': '描けるレイヤーがありません',
    'layer_not_found': 'レイヤーが見つかりません',
    'uv_layer_missing': 'UVマップがありません',
    'destination_locked': '保存先のファイルが使用中です',
    'overlay_failed': '合成表示を開始できませんでした',
    'uv_select_failed': 'UVマップを選べませんでした',
    'material_restore_failed': 'マテリアルを復元できませんでした',
    'Bridge connect failed': '外部アプリとの接続に失敗しました',
    'External bridge requires psd-tools and Pillow in Blender Python.': '外部ブリッジには Blender の Python 環境に psd-tools と Pillow が必要です。',
    'Bridge stop failed': '外部アプリとの切断に失敗しました',
    'External app launch failed': '外部アプリを起動できませんでした',
    'External import failed': '外部の変更を取り込めませんでした',
    'External sync failed': '外部との同期に失敗しました',
    'PSD Save As: {} ({:.0f} ms)': 'PSDを別名保存: {} ({:.0f} ms)',
    'PSD Save As failed': 'PSDの別名保存に失敗しました',
    'Applied {} patch(es)': '{} 件の変更を適用しました',
    'Applied {} patch(es); external ACK will be retried': '{} 件の変更を適用しました。外部アプリへの通知は再試行します',
    'Applied {} patch(es); opening exchange': '{} 件の変更を適用しました。交換ファイルを開きます',
    '{} exchange {}: {} records': '{} の交換 {}: {} 件',
    'Source Image': '元の画像',
    'no transparent edge pixels are available for padding': 'パディングできる透明な境界の画素がありません',
    'SDF source must contain both inside and outside pixels': 'SDF の元の画像には内側と外側の両方の画素が必要です',
    'no channel split set is available': '分解したチャンネルの組がありません',
    'ambiguous channel split set': '分解したチャンネルの組を 1 つに決められません',
    'channel split set is incomplete': '分解したチャンネルの組が揃っていません',
    'channel split dimensions do not match': '分解したチャンネルの大きさが揃っていません',
    'map conversion requires Non-Color input': 'マップ変換の入力は Non-Color の画像だけです',
    'GBR header is truncated': 'GBR ファイルのヘッダーが途中で切れています',
    'invalid GBR magic': 'GBR ファイルではありません',
    'GBR pixel count exceeds the safety limit': 'GBR の画素数が上限を超えています',
    'failed to create the packed brush image': 'ブラシの画像を作成できませんでした',
})

_TRANSLATION_CONTEXTS = (
    '*',
    'Operator',
    'Property',
    'Menu',
    'Panel',
    'WindowManager',
    'ToolTip',
    'Tooltip',
    'UI',
    'Addon',
    'Text',
    'ID',
)


_LATIN_REPLACEMENTS = (
    ('Base Color', 'ベースカラー'),
    ('Base', 'ベース'),
    ('Alpha', 'アルファ'),
    ('Emission', '発光'),
    ('Height', '高さ'),
    ('Metallic', 'メタリック'),
    ('Normal', 'ノーマル'),
    ('Roughness', 'ラフネス'),
    ('Texture Paint', 'テクスチャペイント'),
    ('Quick Start', 'クイックスタート'),
    ('Realtime Bake', 'リアルタイムベイク'),
    ('Bake', 'ベイク'),
    ('Projection', '投影'),
    ('Iteration', '反復'),
    ('Hybrid', 'ハイブリッド'),
    ('Node', 'ノード'),
    ('Float', '浮動小数点'),
    ('Full Opacity', '完全不透明'),
    ('Packed', 'パック'),
    ('Gloss', 'グロス'),
    ('Rough', 'ラフ'),
    ('Empty', 'エンプティ'),
    ('GPencil', 'グリースペンシル'),
    ('Gpencil', 'グリースペンシル'),
    ('Grease Pencil', 'グリースペンシル'),
    ('Paint System', 'ペイントシステム'),
    ('Property Popup', 'プロパティポップアップ'),
    ('Image Editor', '画像エディター'),
    ('external image editor', '外部画像エディター'),
    ('external', '外部'),
    ('image interpolation type', '画像補間タイプ'),
    ('World Position', 'ワールド位置'),
    ('World Space Coordinates', 'ワールド空間座標'),
    ('Coordinates', '座標'),
    ('Strength', '強度'),
    ('Full', '完全'),
    ('Opacity', '不透明度'),
    ('Space', '空間'),
    ('OFF', 'オフ'),
    ('ON', 'オン'),
    ('AUTO', '自動'),
    ('Tab', 'Tab'),
    ('Linear', 'リニア'),
    ('Spline', 'スプライン'),
    ('Foundation', '財団'),
    ('tweak', '微調整'),
    ('scale', 'スケール'),
    ('blendfile', 'blendファイル'),
    ('blend file', 'blendファイル'),
    ('modifer', 'モディファイアー'),
    ('modifiers', 'モディファイアー'),
    ('modifier', 'モディファイアー'),
    ('pixels', 'ピクセル'),
    ('the ', ''),
    ('The ', ''),
    (' to ', 'へ'),
    (' from ', 'から'),
    (' for ', '用'),
    (' of ', 'の'),
    (' in ', '内'),
    (' and ', 'と'),
    (' or ', 'または'),
)

def _sanitize_japanese_translation(source: str, translated: str) -> str:
    import re
    value = str(translated or '')
    for en, ja in _LATIN_REPLACEMENTS:
        if en in value:
            value = re.sub(r'(?<![A-Za-z])' + re.escape(en) + r'(?![A-Za-z])', ja, value)
    value = value.replace('  ', ' ').strip()
    src_text = str(source or '')
    if src_text.startswith(' ') and value and not value.startswith(' '):
        value = ' ' + value
    if src_text.endswith(' ') and value and not value.endswith(' '):
        value = value + ' '
    return value


# --- Build-time generated source UI localization catalog START ---
# GENERATED_SOURCE_TRANSLATIONS is emitted during package construction.  Importing
# or enabling the Extension performs no source discovery, file reads, AST parsing,
# or recursive package scan.
# --- Build-time generated source UI localization catalog END ---


_FIXED_UNTRANSLATED_SOURCES = frozenset({"Smart Paint"})


def _add_translation_entry(target: dict, key: str, value: str) -> None:
    source = str(key or '')
    if source in _FIXED_UNTRANSLATED_SOURCES:
        return
    translated = _sanitize_japanese_translation(source, str(value or ''))
    if not source or not translated or source == translated:
        return
    for context in _TRANSLATION_CONTEXTS:
        target[(context, source)] = translated


def build_translations() -> dict:
    ja_dict = {}
    for key, value in BASE_TRANSLATIONS.items():
        _add_translation_entry(ja_dict, key, value)
    for key, value in GENERATED_SOURCE_TRANSLATIONS.items():
        _add_translation_entry(ja_dict, key, value)
    for _, pair in UI_LABELS.items():
        en, ja = pair
        _add_translation_entry(ja_dict, en, ja)
    for en, ja in BI_TRANSLATIONS.items():
        _add_translation_entry(ja_dict, en, ja)
    en_dict = {
        (context, source): english
        for source, english in JAPANESE_SOURCE_ENGLISH.items()
        for context in _TRANSLATION_CONTEXTS
    }
    # Translate the control label without translating names of user masks.
    mask_label = "保存マスク"
    en_dict[("SmartPaintFaceMaskName", mask_label)] = JAPANESE_SOURCE_ENGLISH[mask_label]
    catalog = {"ja_JP": ja_dict, "ja": ja_dict, "en_US": en_dict}
    try:
        import bpy
        for locale in bpy.app.translations.locales:
            catalog.setdefault(locale, en_dict)
    except Exception:
        pass
    return catalog


TRANSLATIONS = build_translations()
