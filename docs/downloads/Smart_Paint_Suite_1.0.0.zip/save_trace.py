# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""SPS_TEST_ROOT-gated texture save JSONL trace helpers."""

from __future__ import annotations

import json
import os
from pathlib import Path
import time


def enabled() -> bool:
    try:
        return bool(str(os.environ.get("SPS_TEST_ROOT", "") or ""))
    except Exception:
        return False


def new_trace_id(prefix: str = "save") -> str:
    try:
        return f"{prefix}-{time.time_ns()}"
    except Exception:
        return str(prefix or "save")


def set_trace_id(material, channel: str, trace_id: str) -> None:
    try:
        if material is not None:
            ch = str(channel or "BASE_COLOR").upper()
            material["sps_save_trace_id_" + ch] = str(trace_id or "")
            material["sps_save_trace_active_time_" + ch] = float(time.time())
    except Exception:
        pass


def trace_id(material, channel: str = "") -> str:
    try:
        if material is not None:
            ch = str(channel or "BASE_COLOR").upper()
            value = str(material.get("sps_save_trace_id_" + ch, "") or "")
            if value:
                return value
    except Exception:
        pass
    return ""


def _path_is_psd(path) -> bool:
    try:
        return str(path or "").lower().endswith((".psd", ".psb"))
    except Exception:
        return False


def _fresh_timestamp(value, *, max_age: float = 180.0) -> bool:
    try:
        return (time.time() - float(value)) <= float(max_age)
    except Exception:
        return False


def _psd_write_permission(material, channel: str = "") -> tuple[bool, str]:
    """Return whether a PSD/PSB file write belongs to the current explicit save.

    Some background repair/composite paths can touch PSD files while SPS_TEST_ROOT
    tracing is active.  Only the direct PSD writer's short explicit boundary or
    the legacy write_texture_file nonce may truncate/replace a PSD target.
    """
    try:
        ch = str(channel or "BASE_COLOR").upper()
        if material is not None:
            explicit_key = "sps_explicit_psd_write_active_" + ch
            explicit_time_key = "sps_explicit_psd_write_active_time_" + ch
            if bool(material.get(explicit_key, False)) and _fresh_timestamp(material.get(explicit_time_key, 0.0), max_age=180.0):
                return True, "explicit_psd_write_active"
            nonce_active_key = "sps_texture_save_nonce_active_" + ch
            nonce_key = "sps_texture_save_nonce_" + ch
            if bool(material.get(nonce_active_key, False)):
                try:
                    nonce_seconds = float(int(str(material.get(nonce_key, "0") or "0"))) / 1_000_000_000.0
                except Exception:
                    nonce_seconds = 0.0
                if nonce_seconds > 0.0 and _fresh_timestamp(nonce_seconds, max_age=180.0):
                    return True, "texture_save_nonce_active"
    except Exception:
        pass
    return False, "no_active_save_boundary"


def emit_psd_file_write(event: str, path, *, material=None, channel: str = "", **payload) -> None:
    if not enabled():
        return
    try:
        import traceback
        root = Path(str(os.environ.get("SPS_TEST_ROOT", "") or ""))
        if not root:
            return
        log_dir = root / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ch = str(channel or payload.get("channel") or "BASE_COLOR").upper()
        p = Path(str(path or ""))
        try:
            stat = p.stat() if p.exists() else None
        except Exception:
            stat = None
        record = {
            "ts": time.time(),
            "event": str(event or ""),
            "trace_id": str(payload.pop("trace_id", "") or trace_id(material, ch)),
            "channel": ch,
            "path": str(p),
            "exists": bool(p.exists()),
            "size": int(getattr(stat, "st_size", 0) or 0) if stat is not None else 0,
            "stack": traceback.format_stack(limit=16)[:-1],
        }
        try:
            record["material"] = str(getattr(material, "name", "") or "")
        except Exception:
            record["material"] = ""
        record.update({str(k): _safe(v) for k, v in payload.items()})
        with open(log_dir / "sps_psd_file_write_trace.jsonl", "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    except Exception:
        pass


def guard_psd_file_write(path, *, material=None, channel: str = "", reason: str = "", operation: str = "write") -> bool:
    if not _path_is_psd(path):
        return True
    allowed, allow_reason = _psd_write_permission(material, channel)
    emit_psd_file_write(
        "psd_file_write_gate",
        path,
        material=material,
        channel=channel,
        allowed=bool(allowed),
        allow_reason=str(allow_reason or ""),
        reason=str(reason or ""),
        operation=str(operation or ""),
    )
    if not allowed:
        try:
            if material is not None:
                ch = str(channel or "BASE_COLOR").upper()
                material["sps_last_psd_ghost_write_blocked_" + ch] = str(path or "")
                material["sps_last_psd_ghost_write_blocked_reason_" + ch] = str(reason or operation or "")
        except Exception:
            pass
    return bool(allowed)


def image_markers(image) -> dict:
    if image is None:
        return {}
    out = {}
    for key in (
        "smart_paint_suite_source_file",
        "smart_paint_suite_layered_source_path",
        "sps_psd_source_order",
        "sps_psd_source_ordinal",
        "sps_psd_source_layer_index",
        "sps_psd_original_name",
        "smart_paint_suite_layer_id",
        "smart_paint_suite_lazy_psd_pending",
        "smart_paint_suite_psd_materialized_clean",
        "smart_paint_suite_direct_layer_dirty",
        "smart_paint_suite_user_edited",
        "smart_paint_suite_bodypaint_direct_authoritative",
        "smart_paint_suite_painted_since_last_projection",
        "sps_external_csp_import_authoritative",
        "sps_external_csp_import_bbox",
        "smart_paint_suite_dirty_bbox",
        "smart_paint_suite_sparse_rgba_patch_b64",
        "smart_paint_suite_last_brush_color",
        "smart_paint_suite_dirty_from_master",
        "smart_paint_suite_known_brush_color_commit",
        "smart_paint_suite_fast_visible_write",
        "smart_paint_suite_exact_top_normal_commit",
        "smart_paint_suite_exact_top_sparse_commit",
        "smart_paint_suite_exact_fallback_commit",
        "smart_paint_suite_save_exact_master_delta",
        "smart_paint_suite_authoritative_sparse_rgba_patch",
        "sps_v2_source_overlay_canvas",
        "sps_v2_source_materialize_deferred_for_undo",
        "smart_paint_suite_psd_materialize_deferred_for_undo",
        "sps_v2_native_paint_target",
        "sps_v2_native_paint_dirty",
    ):
        try:
            if key in image:
                value = image.get(key)
                if key == "smart_paint_suite_sparse_rgba_patch_b64":
                    out[key] = f"<len:{len(str(value or ''))}>"
                elif isinstance(value, (str, int, float, bool)) or value is None:
                    out[key] = value
                else:
                    out[key] = str(value)
        except Exception:
            pass
    try:
        out["is_dirty"] = bool(getattr(image, "is_dirty", False))
    except Exception:
        pass
    try:
        out["size"] = [int(image.size[0]), int(image.size[1])]
    except Exception:
        pass
    return out


def _safe(value):
    try:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, dict):
            return {str(_safe(k)): _safe(v) for k, v in list(value.items())[:200]}
        if isinstance(value, (list, tuple, set)):
            return [_safe(v) for v in list(value)[:300]]
        return str(value)
    except Exception:
        return repr(value)


def emit(event: str, *, material=None, channel: str = "", **payload) -> None:
    if not enabled():
        return
    try:
        root = Path(str(os.environ.get("SPS_TEST_ROOT", "") or ""))
        if not root:
            return
        log_dir = root / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ch = str(channel or payload.get("channel") or "BASE_COLOR").upper()
        record = {
            "ts": time.time(),
            "event": str(event or ""),
            "trace_id": str(payload.pop("trace_id", "") or trace_id(material, ch)),
            "channel": ch,
        }
        try:
            record["material"] = str(getattr(material, "name", "") or "")
        except Exception:
            record["material"] = ""
        record.update({str(k): _safe(v) for k, v in payload.items()})
        with open(log_dir / "sps_save_trace.jsonl", "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    except Exception:
        pass
