# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Redraw-only Grease Pencil preference integration."""
from __future__ import annotations

def update_panel(_owner, context):
    screen = getattr(context, "screen", None)
    for area in tuple(getattr(screen, "areas", ()) or ()):
        try:
            area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    return None
