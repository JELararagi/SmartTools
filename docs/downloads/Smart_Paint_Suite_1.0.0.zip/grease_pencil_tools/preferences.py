# SPDX-License-Identifier: GPL-3.0-or-later
"""Refresh editor areas after a Grease Pencil preference changes."""


def update_panel(_owner, context):
    screen = getattr(context, "screen", None)
    editors = getattr(screen, "areas", None)
    if editors is None:
        return
    for editor in list(editors):
        try:
            editor.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            # A screen may change between gathering the editors and repainting.
            pass
