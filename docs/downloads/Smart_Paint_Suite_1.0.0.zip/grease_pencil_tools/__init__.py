# SPDX-License-Identifier: GPL-3.0-or-later
"""Subpackage for Smart Paint Grease Pencil preferences."""
