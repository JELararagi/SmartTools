# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Preference bridge for the bundled brush resource path."""
from __future__ import annotations
import bpy

def update_resource_path(owner, _context):
    path = str(getattr(owner, "brushstroke_resource_path", "") or "")
    bpy.app.driver_namespace["SPS_BRUSHSTROKE_RESOURCE_PATH"] = path
    return None
