# SPDX-License-Identifier: GPL-3.0-or-later
"""Publish the selected brush resource path for the local brush tools."""

import bpy


def update_resource_path(owner, _context):
    selected = getattr(owner, "brushstroke_resource_path", None)
    resources = bpy.app.driver_namespace
    resources.update(SPS_BRUSHSTROKE_RESOURCE_PATH=str(selected) if selected else "")
