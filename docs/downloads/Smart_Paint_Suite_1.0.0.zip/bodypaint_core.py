# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Canonical BodyPaint-style layer/document routing for Smart Paint Suite.

The historical package referenced this module from many final override blocks
but did not ship it.  This implementation owns no RNA classes and imports NumPy
or PSD tooling only inside explicit pixel/save operations.  Private layer Images
remain authoring sources; the document master is a derived display projection.
"""
from __future__ import annotations

import json
from pathlib import Path
import time
import uuid
from typing import Any

import bpy

SUITE_OWNER = "JELararagi:smart_paint_suite"
IMAGE_SCHEMA = 1


def _io():
    from . import psd_io
    return psd_io


def _clean():
    from . import clean_layer_stack_engine
    return clean_layer_stack_engine


def _channel(value: str) -> str:
    try:
        return _io()._safe_channel(value)
    except (AttributeError, ImportError, ValueError):
        return str(value or "BASE_COLOR").upper()


def master_image(material, channel: str = "BASE_COLOR", *, create: bool = True):
    return _clean().get_master_texture_image(material, _channel(channel), create=bool(create))


def _show_master_in_editors(context, master, *, keep_private_canvas: bool = False) -> bool:
    del keep_private_canvas
    from .core_operators import _show_image_in_image_editors
    return _show_image_in_image_editors(context or getattr(bpy, "context", None), master)


def _stack_records(material, channel: str = "BASE_COLOR") -> list[dict[str, Any]]:
    if material is None:
        return []
    try:
        _width, _height, records = _clean().collect_layers(material, _channel(channel))
    except (AttributeError, ImportError, RuntimeError, ValueError):
        return []
    return [dict(item) for item in records or () if isinstance(item, dict)]


def _records_have_authored_visible_edits(records) -> bool:
    for item in records or ():
        if not isinstance(item, dict) or not bool(item.get("enabled", True)):
            continue
        image = item.get("image") or item.get("image_ref")
        try:
            if image is not None and any(bool(image.get(key, False)) for key in (
                "smart_paint_suite_direct_layer_dirty",
                "smart_paint_suite_bodypaint_direct_authoritative",
                "smart_paint_suite_user_edited",
                "smart_paint_suite_painted_since_last_projection",
                "smart_paint_suite_authoritative_sparse_rgba_patch",
            )):
                return True
        except (AttributeError, ReferenceError, TypeError):
            pass
        try:
            if int(item.get("psd_source_record_index", -1) or -1) < 0:
                return True
        except (TypeError, ValueError):
            return True
    return False


def _layer_authoritative_paint_probe(material, channel: str = "BASE_COLOR") -> dict[str, Any]:
    records = _stack_records(material, channel)
    dirty = []
    for item in records:
        image = item.get("image") or item.get("image_ref")
        if image is None:
            continue
        try:
            if bool(image.get("smart_paint_suite_direct_layer_dirty", False)) or bool(image.get("smart_paint_suite_user_edited", False)):
                dirty.append(str(getattr(image, "name", "") or ""))
        except (AttributeError, ReferenceError, TypeError):
            continue
    return {"ok": True, "dirty_images": dirty, "dirty_count": len(dirty), "record_count": len(records)}


def _tag_private_image(image, material, channel: str, layer_id: str) -> None:
    image["smart_paint_suite_layer_image"] = True
    image["smart_paint_suite_material"] = str(getattr(material, "name", "") or "")
    image["smart_paint_suite_layer_id"] = str(layer_id or "")
    image["smart_paint_suite_channel"] = _channel(channel)
    image["sps_suite_owner"] = SUITE_OWNER
    image["sps_suite_owner_uuid"] = str(image.get("sps_suite_owner_uuid", "") or uuid.uuid4())
    image["sps_suite_image_schema"] = IMAGE_SCHEMA
    image["sps_suite_owned_image"] = True
    image["sps_suite_canonical_source"] = False


def ensure_active_layer_image(material, channel: str = "BASE_COLOR", *, create: bool = True, for_paint: bool = False):
    if material is None:
        return None
    io = _io()
    ch = _channel(channel)
    layer, image = io._active_layer_image_for_material(material, ch)
    if image is not None and for_paint:
        try:
            if bool(image.get("smart_paint_suite_lazy_psd_pending", False)):
                if not io.materialize_lazy_psd_layer_image(image):
                    return None
            elif bool(image.get("smart_paint_suite_lazy_blank_layer", False)):
                master = master_image(material, ch, create=False)
                width = int(master.size[0]) if master is not None else 1024
                height = int(master.size[1]) if master is not None else 1024
                if not io._materialize_lazy_blank_layer_for_write(image, width, height):
                    return None
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            return None
    if image is not None:
        try:
            _tag_private_image(image, material, ch, getattr(layer, "layer_id", ""))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        return image
    if not create or layer is None:
        return None
    master = master_image(material, ch, create=False)
    width = int(master.size[0]) if master is not None else 1024
    height = int(master.size[1]) if master is not None else 1024
    layer_id = str(getattr(layer, "layer_id", "") or uuid.uuid4())
    base = str(getattr(layer, "name", "Layer") or "Layer")
    name = f"SPS_{getattr(material, 'name', 'Material')}_{base}_{ch}"
    image = bpy.data.images.new(name=name, width=max(1, width), height=max(1, height), alpha=True, float_buffer=False)
    try:
        image.generated_color = (1.0, 1.0, 1.0, 0.0)
        image.alpha_mode = "STRAIGHT"
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    _tag_private_image(image, material, ch, layer_id)
    attr = io.layer_channel_image_attr(ch)
    setattr(layer, attr, image.name)
    return image


def notify_active_private_layer_bound(material, channel: str, image, *, route: str = "", reason: str = "") -> bool:
    if material is None or image is None:
        return False
    ch = _channel(channel)
    layer_id = str(image.get("smart_paint_suite_layer_id", "") or _io()._active_layer_id(material) or "")
    _tag_private_image(image, material, ch, layer_id)
    material["sps_active_private_layer_image_" + ch] = image.name
    material["sps_native_write_image_" + ch] = image.name
    material["sps_active_private_route_" + ch] = str(route or "")
    material["sps_active_private_reason_" + ch] = str(reason or "")
    material["sps_enable_direct_paint_timer_" + ch] = False
    return True


def _mark_previous_native_private_if_dirty(material, channel: str = "BASE_COLOR") -> bool:
    if material is None:
        return False
    ch = _channel(channel)
    name = str(material.get("sps_active_private_layer_image_" + ch, "") or material.get("sps_native_write_image_" + ch, "") or "")
    image = bpy.data.images.get(name) if name else None
    if image is None:
        return False
    try:
        dirty = bool(getattr(image, "is_dirty", False)) or bool(image.get("smart_paint_suite_direct_layer_dirty", False))
    except (AttributeError, ReferenceError, TypeError):
        dirty = False
    if dirty:
        image["smart_paint_suite_direct_layer_dirty"] = True
        image["smart_paint_suite_bodypaint_direct_authoritative"] = True
        image["smart_paint_suite_painted_since_last_projection"] = True
        image["smart_paint_suite_user_edited"] = True
    return dirty


def _promote_dirty_layer_images_for_projection(material, channel: str = "BASE_COLOR") -> bool:
    changed = False
    for item in _stack_records(material, channel):
        image = item.get("image") or item.get("image_ref")
        if image is None:
            continue
        try:
            dirty = bool(getattr(image, "is_dirty", False)) or bool(image.get("smart_paint_suite_direct_layer_dirty", False))
            if dirty:
                image["smart_paint_suite_bodypaint_direct_authoritative"] = True
                image["smart_paint_suite_user_edited"] = True
                changed = True
        except (AttributeError, ReferenceError, TypeError):
            continue
    if changed:
        try:
            _clean()._invalidate_projection_cache(material, _channel(channel))
        except (AttributeError, RuntimeError, ValueError):
            pass
    return changed


def capture_active_private_layer_pixels(material, channel: str = "BASE_COLOR", context=None, *, write_back: bool = True) -> bool:
    del context
    image = ensure_active_layer_image(material, channel, create=False, for_paint=False)
    if image is None:
        return False
    changed = bool(getattr(image, "is_dirty", False))
    try:
        changed = changed or bool(image.get("smart_paint_suite_direct_layer_dirty", False))
    except (AttributeError, ReferenceError, TypeError):
        pass
    if write_back and changed:
        image["smart_paint_suite_direct_layer_dirty"] = True
        image["smart_paint_suite_bodypaint_direct_authoritative"] = True
        image["smart_paint_suite_painted_since_last_projection"] = True
        image["smart_paint_suite_user_edited"] = True
        try:
            width, height = int(image.size[0]), int(image.size[1])
            image["smart_paint_suite_dirty_bbox"] = (0, 0, width, height)
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
        _promote_dirty_layer_images_for_projection(material, channel)
    return changed


def register_direct_layer_paint_session(material, channel: str = "BASE_COLOR", image=None) -> None:
    """Bind the explicit paint target without starting legacy synchronizers.

    Historical builds delegated this boundary back into a 1.2 MiB legacy
    override in :mod:`psd_io`, which could register a repeating timer and run a
    large synchronous layer reconciliation loop from lightweight UI paths.  A
    direct paint session now consists only of deterministic RNA bindings made
    by the caller's explicit operation.  Pixel capture/composite work remains
    behind explicit save, review and paint-target operators.
    """
    image = image or ensure_active_layer_image(material, channel, create=True, for_paint=True)
    if image is None:
        return
    notify_active_private_layer_bound(
        material,
        channel,
        image,
        route="bodypaint_core",
        reason="register_direct_session",
    )


def flush_direct_layer_session(material, channel: str = "BASE_COLOR", *, force: bool = False, context=None) -> bool:
    changed = capture_active_private_layer_pixels(material, channel, context, write_back=True)
    if not changed and not force:
        return False
    if force:
        _mark_previous_native_private_if_dirty(material, channel)
    return bool(changed or force)


def commit_private_layer_boundary(material, channel: str = "BASE_COLOR", context=None, *, refresh_master: bool = False, force: bool = True, reason: str = "") -> bool:
    changed = flush_direct_layer_session(material, channel, force=force, context=context)
    ch = _channel(channel)
    if material is not None:
        material["sps_bodypaint_last_boundary_reason_" + ch] = str(reason or "")
        material["sps_bodypaint_last_boundary_time_" + ch] = time.time()
    if refresh_master and changed:
        write_composite_to_master(material, ch, force=True)
    return changed


def mark_active_private_layer_for_save(material, channel: str = "BASE_COLOR", context=None) -> bool:
    return commit_private_layer_boundary(material, channel, context, refresh_master=False, force=False, reason="save")


def prepare_pending_post_save_active_private(material, channel: str = "BASE_COLOR", context=None) -> bool:
    return bool(restore_visible_document_paint_binding(material, channel, context, reason="post_save"))


def schedule_prepare_active_private_layer_for_paint(material, channel: str = "BASE_COLOR", context=None):
    # Explicit operation only: no timer is installed.
    return ensure_active_layer_image(material, channel, create=True, for_paint=True)


def trace_post_save_prepare_route_entry(material, channel: str = "BASE_COLOR", *, reason: str = "") -> dict[str, Any]:
    image = ensure_active_layer_image(material, channel, create=False)
    return {"ok": image is not None, "image": str(getattr(image, "name", "") or ""), "reason": str(reason or "")}


def _bind_visible_master_image(material, channel: str = "BASE_COLOR", context=None):
    return sync_document_texture_target(material, channel, context, show_editors=True, switch_to_paint=False)


def _write_image_rgba(image, rgba) -> bool:
    if image is None:
        return False
    try:
        import numpy as np
        array = np.asarray(rgba, dtype=np.float32)
        flat = np.ascontiguousarray(array.reshape((-1,)), dtype=np.float32)
        if len(flat) != len(image.pixels):
            return False
        image.pixels.foreach_set(flat)
        image.update()
        return True
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def restore_visible_document_paint_binding(material, channel: str = "BASE_COLOR", context=None, *, master=None, reason: str = ""):
    del reason
    ch = _channel(channel)
    master = master or master_image(material, ch, create=True)
    if master is None:
        return None
    legacy = getattr(_clean(), "_sps_legacy_sync_document_texture_target_L8201", None)
    result = legacy(material, ch, context, show_editors=True, switch_to_paint=False) if callable(legacy) else master
    _show_master_in_editors(context, result or master, keep_private_canvas=False)
    return result or master


def route_disabled_layer_paint_target(material, channel: str = "BASE_COLOR", context=None):
    return restore_visible_document_paint_binding(material, channel, context, reason="disabled_layer")


def write_composite_to_master(material, channel: str = "BASE_COLOR", *, force: bool = False):
    fn = getattr(_clean(), "_sps_legacy_write_composite_to_master_L7680", None)
    if not callable(fn):
        raise RuntimeError("canonical_composite_writer_missing")
    return fn(material, _channel(channel), force=bool(force))


def install_master_display_node(material, channel: str = "BASE_COLOR", *, recompose: bool = True, force_recompose: bool = False):
    fn = getattr(_clean(), "_sps_legacy_install_master_display_node_L7746", None)
    if not callable(fn):
        raise RuntimeError("canonical_display_node_installer_missing")
    return fn(material, _channel(channel), recompose=bool(recompose), force_recompose=bool(force_recompose))


def sync_document_texture_target(material, channel: str = "BASE_COLOR", context=None, *, show_editors: bool = True, switch_to_paint: bool = False):
    fn = getattr(_clean(), "_sps_legacy_sync_document_texture_target_L8201", None)
    if not callable(fn):
        raise RuntimeError("canonical_document_target_missing")
    result = fn(material, _channel(channel), context, show_editors=bool(show_editors), switch_to_paint=bool(switch_to_paint))
    if result is None:
        raise RuntimeError("document_target_not_created")
    return result


def set_active_layer_recording_target(material, channel: str = "BASE_COLOR") -> bool:
    image = ensure_active_layer_image(material, channel, create=True, for_paint=True)
    if image is None:
        return False
    register_direct_layer_paint_session(material, channel, image)
    return True


def set_native_write_target(material, channel: str = "BASE_COLOR", context=None):
    if not set_active_layer_recording_target(material, channel):
        return None
    sync_document_texture_target(material, channel, context, show_editors=True, switch_to_paint=False)
    return ensure_active_layer_image(material, channel, create=False)


def force_document_texture_view_refresh(material, channel: str = "BASE_COLOR", context=None, *, show_editors: bool = True, switch_to_paint: bool = False):
    fn = getattr(_clean(), "_sps_legacy_force_document_texture_view_refresh_L8387", None)
    if not callable(fn):
        raise RuntimeError("canonical_view_refresh_missing")
    result = fn(material, _channel(channel), context, show_editors=bool(show_editors), switch_to_paint=bool(switch_to_paint))
    if result is None:
        raise RuntimeError("document_view_refresh_failed")
    return result


def ensure_layer_stack_display_matches(material, channel: str = "BASE_COLOR", context=None, *, commit_pending: bool = True, switch_to_paint: bool = False, force_recompose: bool = False, recompose=None, commit_untracked: bool = True):
    fn = getattr(_clean(), "_sps_legacy_ensure_layer_stack_display_matches_L8831", None)
    if not callable(fn):
        raise RuntimeError("canonical_stack_display_missing")
    result = fn(material, _channel(channel), context, commit_pending=bool(commit_pending), switch_to_paint=bool(switch_to_paint), force_recompose=bool(force_recompose), recompose=recompose, commit_untracked=bool(commit_untracked))
    if result is None:
        raise RuntimeError("stack_display_refresh_failed")
    return result


def reload_layer_stack_from_internal_document(material, channel: str = "BASE_COLOR", context=None, *, commit_pending: bool = False, switch_to_paint: bool = False, force_recompose: bool = True):
    fn = getattr(_clean(), "_sps_legacy_reload_layer_stack_from_internal_document_L23634", None)
    if not callable(fn):
        raise RuntimeError("canonical_internal_reload_missing")
    result = fn(material, _channel(channel), context, commit_pending=bool(commit_pending), switch_to_paint=bool(switch_to_paint), force_recompose=bool(force_recompose))
    if result is None:
        raise RuntimeError("internal_document_reload_failed")
    return result


def restore_document_canvas_fast(material, channel: str = "BASE_COLOR", context=None) -> bool:
    fn = getattr(_io(), "_sps_legacy_restore_document_canvas_fast_L13928", None)
    if callable(fn):
        return bool(fn(material, _channel(channel), context))
    return sync_document_texture_target(material, channel, context, show_editors=True, switch_to_paint=False) is not None


def sync_selection_stencil(context=None, material=None, channel: str = "BASE_COLOR") -> bool:
    fn = getattr(_io(), "_sps_legacy_sync_selection_stencil_L13978", None)
    if not callable(fn):
        return False
    return bool(fn(context, material, _channel(channel)))


def prepare_layer_stack_for_substance_style_save(material, channel: str = "BASE_COLOR", context=None, *, force_untracked: bool = False, force_recompose: bool = True) -> bool:
    del force_untracked
    changed = mark_active_private_layer_for_save(material, channel, context)
    if force_recompose and changed:
        write_composite_to_master(material, channel, force=True)
    return True


def ensure_source_psd_stack_loaded(material, channel: str = "BASE_COLOR") -> bool:
    if material is None:
        return False
    ch = _channel(channel)
    resolver = getattr(_clean(), "_clean_lazy_psd_source_path_for_direct_copy", None)
    source = str(resolver(material, ch) or "") if callable(resolver) else ""
    if not source:
        return True
    path = Path(source)
    if path.is_symlink() or not path.is_file():
        return False
    # Opening is deliberately lazy and occurs only at an explicit save/import
    # boundary.  It validates parseability without retaining the PSD document.
    try:
        from psd_tools import PSDImage
        document = PSDImage.open(path)
        width, height = int(document.width), int(document.height)
        material["sps_source_psd_validated_" + ch] = True
        material["sps_source_psd_size_" + ch] = (width, height)
        return width > 0 and height > 0
    except (ImportError, OSError, ValueError, AttributeError):
        material["sps_source_psd_validated_" + ch] = False
        return False


def write_external_layered_psd(material, channel: str, filepath: str | Path) -> bool:
    # Canonical writer has explicit source-splice and atomic replacement logic.
    writer = getattr(_io(), "_sps_legacy_write_layered_psd_L18887", None)
    if not callable(writer):
        writer = getattr(_io(), "_sps_legacy_write_layered_psd_L3720", None)
    if not callable(writer):
        raise RuntimeError("canonical_layered_psd_writer_missing")
    return bool(writer(material, _channel(channel), filepath))


def install_gpu_layer_stack_preview(material, channel: str = "BASE_COLOR", context=None):
    # GPU resources remain owned by the existing overlay modules; this canonical
    # function only refreshes the already-built document projection.
    return force_document_texture_view_refresh(material, channel, context, show_editors=True, switch_to_paint=False)


def refresh_live_layer_stack_preview_fast(material, channel: str = "BASE_COLOR", context=None):
    return force_document_texture_view_refresh(material, channel, context, show_editors=True, switch_to_paint=False)


def restore_layer_pixels_from_shadow(material, channel: str = "BASE_COLOR") -> bool:
    restored = False
    for item in _stack_records(material, channel):
        image = item.get("image") or item.get("image_ref")
        if image is None:
            continue
        try:
            payload = str(image.get("smart_paint_suite_shadow_rgba_json", "") or "")
            if not payload:
                continue
            values = json.loads(payload)
            if _write_image_rgba(image, values):
                restored = True
        except (AttributeError, ReferenceError, TypeError, ValueError, json.JSONDecodeError):
            continue
    return restored


__all__ = (
    "_bind_visible_master_image", "_layer_authoritative_paint_probe",
    "_mark_previous_native_private_if_dirty", "_promote_dirty_layer_images_for_projection",
    "_records_have_authored_visible_edits", "_show_master_in_editors", "_stack_records",
    "_write_image_rgba", "capture_active_private_layer_pixels", "commit_private_layer_boundary",
    "ensure_active_layer_image", "ensure_layer_stack_display_matches",
    "ensure_source_psd_stack_loaded", "flush_direct_layer_session",
    "force_document_texture_view_refresh", "install_gpu_layer_stack_preview",
    "install_master_display_node", "mark_active_private_layer_for_save", "master_image",
    "notify_active_private_layer_bound", "prepare_layer_stack_for_substance_style_save",
    "prepare_pending_post_save_active_private", "refresh_live_layer_stack_preview_fast",
    "register_direct_layer_paint_session", "reload_layer_stack_from_internal_document",
    "restore_document_canvas_fast", "restore_layer_pixels_from_shadow",
    "restore_visible_document_paint_binding", "route_disabled_layer_paint_target",
    "schedule_prepare_active_private_layer_for_paint", "set_active_layer_recording_target",
    "set_native_write_target", "sync_document_texture_target", "sync_selection_stencil",
    "trace_post_save_prepare_route_entry", "write_composite_to_master",
    "write_external_layered_psd",
)
