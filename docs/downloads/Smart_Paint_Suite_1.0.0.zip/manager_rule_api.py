# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Pure Smart Tools Manager placement/runtime bridge for Smart Paint.

Panel polling reads only the already-loaded Manager package from two fixed
``sys.modules`` keys and invokes its public memory-only ``placement_allowed``
function for the exact current workspace/logical-editor cell.  Poll and draw do
not import, enable, reload, scan, cache, write, register, redraw, or mutate the
Manager. Runtime callers use the separate memory-only
``workspace_tool_allowed`` function so a cell can hide its Panel without
stopping the Suite elsewhere in the same workspace.
"""
from __future__ import annotations

import sys
from types import ModuleType
from typing import Any, Callable, Iterable

import bpy

TOOL_KEY = "SMART_PAINT"
PUBLIC_RULE_FUNCTION = "placement_allowed"
PUBLIC_RUNTIME_FUNCTION = "workspace_tool_allowed"
MANAGER_MODULE_NAMES = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
)
EDITOR_KEYS = (
    "VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR", "SHADER_EDITOR", "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR", "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR", "DOPE_SHEET", "GRAPH_EDITOR", "DRIVERS",
    "NLA_EDITOR", "TEXT_EDITOR", "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET",
)
PHYSICAL_EDITOR_KEYS = (
    "VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR", "CLIP_EDITOR",
    "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR", "TEXT_EDITOR",
    "FILE_BROWSER", "SPREADSHEET",
)
PHYSICAL_TO_LOGICAL = {
    "VIEW_3D": ("VIEW_3D",),
    "IMAGE_EDITOR": ("IMAGE_EDITOR", "UV_EDITOR"),
    "NODE_EDITOR": (
        "SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR",
    ),
    "SEQUENCE_EDITOR": ("VIDEO_SEQUENCER",),
    "CLIP_EDITOR": ("MOVIE_CLIP_EDITOR",),
    "DOPESHEET_EDITOR": ("DOPE_SHEET",),
    "GRAPH_EDITOR": ("GRAPH_EDITOR", "DRIVERS"),
    "NLA_EDITOR": ("NLA_EDITOR",),
    "TEXT_EDITOR": ("TEXT_EDITOR",),
    "FILE_BROWSER": ("ASSET_BROWSER", "FILE_BROWSER"),
    "SPREADSHEET": ("SPREADSHEET",),
}
LIFECYCLE_API_KEY = "JELARARAGI_SMART_PAINT_MANAGER_LIFECYCLE_V2"
RULE_MATRIX_SUBSCRIBER_ID = "smart_paint_suite.workspace_runtime_redraw.v1"
_NOT_READY_STATES = frozenset({"NOT_READY", "DISABLED", "UNAVAILABLE", "UNKNOWN"})
_RUNTIME_FAIL_OPEN_STATES = frozenset({
    "NOT_READY", "DISABLED", "UNAVAILABLE", "UNKNOWN", "STALE",
    "STALE_GENERATION", "STALE_REVISION",
})
_WORKSPACE_UNSET = object()
# Last lifecycle notification only. Runtime routing deliberately does not AND
# this advisory flag because missing/disabled Manager state must fail open.
_MANAGER_ENABLED = True
_RULE_MATRIX_SUBSCRIBER_GENERATION = ""
_RULE_MATRIX_SUBSCRIPTION_GENERATION = ""


class _WorkspaceContextProxy:
    """Expose one target workspace while preserving the caller context surface."""

    __slots__ = ("_base", "workspace")

    def __init__(self, base, workspace) -> None:
        self._base = base
        self.workspace = workspace

    def __getattr__(self, name: str):
        return getattr(self._base, name)


def _context_value(context, owner_name: str, attr_name: str) -> str:
    try:
        owner = getattr(context, owner_name, None) if context is not None else None
        return str(getattr(owner, attr_name, "") or "")
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return ""


def _area_type(context) -> str:
    return _context_value(context, "area", "type").upper()


def _space_type(context) -> str:
    return _context_value(context, "space_data", "type").upper()


def physical_root_match(context, physical_space: str) -> bool:
    """Confirm the root's physical editor before any Manager query."""
    expected = str(physical_space or "").upper()
    if expected not in PHYSICAL_TO_LOGICAL or _area_type(context) != expected:
        return False
    space_type = _space_type(context)
    return not space_type or space_type == expected


def current_logical_editor(context) -> str:
    """Resolve the current physical editor to one of Manager's 17 keys."""
    area_type = _area_type(context)
    if not physical_root_match(context, area_type):
        return ""
    area_ui_type = _context_value(context, "area", "ui_type").upper()

    if area_type == "VIEW_3D":
        return "VIEW_3D"
    if area_type == "IMAGE_EDITOR":
        mode = _context_value(context, "space_data", "mode").upper()
        return "UV_EDITOR" if mode == "UV" or area_ui_type in {"UV", "UV_EDITOR"} else "IMAGE_EDITOR"
    if area_type == "NODE_EDITOR":
        tree_type = _context_value(context, "space_data", "tree_type").upper()
        shader_type = _context_value(context, "space_data", "shader_type").upper()
        probe = "|".join((area_ui_type, tree_type, shader_type))
        if "COMPOSITOR" in probe:
            return "COMPOSITOR"
        if "GEOMETRY" in probe:
            return "GEOMETRY_NODE_EDITOR"
        if "TEXTURE" in probe:
            return "TEXTURE_NODE_EDITOR"
        return "SHADER_EDITOR"
    if area_type == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if area_type == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if area_type == "DOPESHEET_EDITOR":
        return "DOPE_SHEET"
    if area_type == "GRAPH_EDITOR":
        mode = _context_value(context, "space_data", "mode").upper()
        return "DRIVERS" if mode in {"DRIVER", "DRIVERS"} or area_ui_type in {"DRIVER", "DRIVERS"} else "GRAPH_EDITOR"
    if area_type == "NLA_EDITOR":
        return "NLA_EDITOR"
    if area_type == "TEXT_EDITOR":
        return "TEXT_EDITOR"
    if area_type == "FILE_BROWSER":
        browse_mode = _context_value(context, "space_data", "browse_mode").upper()
        return "ASSET_BROWSER" if browse_mode in {"ASSET", "ASSETS", "ASSET_BROWSER"} or area_ui_type in {"ASSET", "ASSETS", "ASSET_BROWSER"} else "FILE_BROWSER"
    if area_type == "SPREADSHEET":
        return "SPREADSHEET"
    return ""


def physical_match(context, editor_key: str) -> bool:
    return current_logical_editor(context) == str(editor_key or "").upper()


def _loaded_manager_module() -> ModuleType | None:
    """Return only the first already-loaded fixed-name Manager package."""
    modules = sys.modules
    for module_name in MANAGER_MODULE_NAMES:
        candidate = modules.get(module_name)
        if isinstance(candidate, ModuleType):
            return candidate
    return None


def _manager_loaded_placement_allowed() -> Callable[..., Any] | None:
    module = _loaded_manager_module()
    if module is None:
        return None
    namespace = vars(module)
    if namespace.get("__addon_enabled__", None) is False:
        return None
    callback = namespace.get(PUBLIC_RULE_FUNCTION)
    return callback if callable(callback) else None


def _call_manager_placement_allowed(callback: Callable[..., Any], context, editor_key: str) -> Any:
    return callback(TOOL_KEY, context, editor_key=editor_key)


def _call_manager_workspace_allowed(callback: Callable[..., Any], context) -> Any:
    return callback(TOOL_KEY, context)


def _runtime_result_state(result: Any) -> str:
    if isinstance(result, str):
        return result.strip().upper()
    if isinstance(result, dict):
        return str(result.get("state", result.get("status", "")) or "").strip().upper()
    return str(getattr(result, "state", getattr(result, "status", "")) or "").strip().upper()


def _runtime_result_allowed(result: Any) -> bool:
    """Accept only trusted decisions; transitional/schema drift fails open."""
    if type(result) is bool:
        return result
    if _runtime_result_state(result) in _RUNTIME_FAIL_OPEN_STATES:
        return True
    if isinstance(result, dict):
        allowed = result.get("allowed")
    else:
        allowed = getattr(result, "allowed", None)
    return allowed if type(allowed) is bool else True


def _explicit_not_ready(result: Any) -> bool:
    if result is None:
        return True
    if isinstance(result, str):
        return result.strip().upper() in _NOT_READY_STATES
    if isinstance(result, dict):
        state = str(result.get("state", result.get("status", "")) or "").strip().upper()
        return state in _NOT_READY_STATES and not isinstance(result.get("allowed"), bool)
    state = str(getattr(result, "state", getattr(result, "status", "")) or "").strip().upper()
    return state in _NOT_READY_STATES and not isinstance(getattr(result, "allowed", None), bool)


def _manager_rule_allows(context, editor_key: str) -> bool:
    """Read one authoritative Manager cell, with independent fail-open behavior."""
    key = str(editor_key or "").upper()
    if key not in EDITOR_KEYS:
        return False
    module = _loaded_manager_module()
    if module is None:
        return True
    namespace = vars(module)
    if namespace.get("__addon_enabled__", None) is False:
        return True
    callback = namespace.get(PUBLIC_RULE_FUNCTION)
    if not callable(callback):
        return True
    try:
        result = _call_manager_placement_allowed(callback, context, key)
    except Exception:
        return True
    if type(result) is bool:
        return result
    if isinstance(result, dict):
        allowed = result.get("allowed")
        last_known = result.get("last_known", result.get("last_known_allowed"))
    else:
        allowed = getattr(result, "allowed", None)
        last_known = getattr(result, "last_known", getattr(result, "last_known_allowed", None))
    if type(allowed) is bool:
        return allowed
    if _explicit_not_ready(result):
        return last_known if type(last_known) is bool else True
    return False


def workspace_runtime_allowed(context=None, *, workspace=_WORKSPACE_UNSET) -> bool:
    """Return the Manager workspace OR for runtime, independently of Panel cells.

    The lookup is lazy and memory-only. Missing, disabled, not-ready, stale,
    malformed, or throwing Manager state fails open so an otherwise valid Smart
    Paint session is never unloaded. ``workspace`` is used only by explicit
    cross-window sync/redraw paths; draw callbacks pass their single target
    ``bpy.context`` and never scan windows.
    """
    module = _loaded_manager_module()
    if module is None:
        return True
    namespace = vars(module)
    if namespace.get("__addon_enabled__", None) is False:
        return True
    callback = namespace.get(PUBLIC_RUNTIME_FUNCTION)
    if not callable(callback):
        return True
    resolved_context = context if context is not None else getattr(bpy, "context", None)
    if workspace is _WORKSPACE_UNSET:
        try:
            target_window = getattr(resolved_context, "window", None)
            if target_window is not None:
                target_workspace = getattr(target_window, "workspace", None)
                if target_workspace is None:
                    return True
            else:
                target_workspace = None
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            return True
        if target_workspace is not None:
            # Blender context overrides can retain an ambient context.workspace
            # while context.window already points at another workspace. Runtime
            # follows the callback window; Panel.poll remains exact-cell based.
            resolved_context = _WorkspaceContextProxy(
                resolved_context, target_workspace
            )
    else:
        if workspace is None:
            # An explicit target window whose workspace cannot be read must not
            # inherit the ambient window's potentially all-OFF decision.
            return True
        resolved_context = _WorkspaceContextProxy(resolved_context, workspace)
    try:
        result = _call_manager_workspace_allowed(callback, resolved_context)
    except Exception:
        return True
    return _runtime_result_allowed(result)


def _tag_runtime_areas_for_matrix_commit(event) -> None:
    """Request one transition redraw; draw remains the per-workspace authority."""
    if not isinstance(event, dict):
        return
    if str(event.get("schema", "") or "") != "jelararagi.smart_tools_manager.rule_matrix_commit":
        return
    event_generation = str(event.get("runtime_generation", "") or "")
    current_generation = manager_generation()
    if event_generation and current_generation and event_generation != current_generation:
        return
    try:
        window_managers = tuple(getattr(getattr(bpy, "data", None), "window_managers", ()) or ())
        for window_manager in window_managers:
            for window in tuple(getattr(window_manager, "windows", ()) or ()):
                screen = getattr(window, "screen", None)
                for area in tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ():
                    if str(getattr(area, "type", "") or "") in {"VIEW_3D", "IMAGE_EDITOR"}:
                        # This one redraw is cleanup/activation for a verified
                        # routing transition. The draw callback then returns for
                        # all-OFF targets; ordinary runtime redraws stay filtered.
                        area.tag_redraw()
    except Exception:
        return


def ensure_rule_matrix_subscription() -> bool:
    """Idempotently attach this live Suite generation to the loaded Manager."""
    global _RULE_MATRIX_SUBSCRIPTION_GENERATION
    if not _RULE_MATRIX_SUBSCRIBER_GENERATION:
        return False
    module = _loaded_manager_module()
    if module is None:
        return False
    namespace = vars(module)
    if namespace.get("__addon_enabled__", None) is False:
        return False
    subscribe = namespace.get("subscribe_rule_matrix_commits")
    generation = manager_generation()
    if not callable(subscribe) or not generation:
        return False
    if _RULE_MATRIX_SUBSCRIPTION_GENERATION == generation:
        return True
    try:
        result = subscribe(
            RULE_MATRIX_SUBSCRIBER_ID,
            _tag_runtime_areas_for_matrix_commit,
            runtime_generation=generation,
            subscriber_generation=_RULE_MATRIX_SUBSCRIBER_GENERATION,
        )
    except Exception:
        return False
    if not isinstance(result, dict) or result.get("ok") is not True:
        return False
    _RULE_MATRIX_SUBSCRIPTION_GENERATION = generation
    return True


def _unsubscribe_rule_matrix_subscription() -> None:
    """Remove only this callback from the current/transferred Manager record."""
    global _RULE_MATRIX_SUBSCRIBER_GENERATION, _RULE_MATRIX_SUBSCRIPTION_GENERATION
    module = _loaded_manager_module()
    try:
        namespace = vars(module) if module is not None else {}
        unsubscribe = namespace.get("unsubscribe_rule_matrix_commits")
        generation = manager_generation()
        if callable(unsubscribe) and generation:
            unsubscribe(
                RULE_MATRIX_SUBSCRIBER_ID,
                runtime_generation=generation,
                callback=_tag_runtime_areas_for_matrix_commit,
            )
    except Exception:
        pass
    finally:
        _RULE_MATRIX_SUBSCRIBER_GENERATION = ""
        _RULE_MATRIX_SUBSCRIPTION_GENERATION = ""


def _rule_matrix_subscription_once() -> None:
    """One event-loop retry covers Suite-before-Manager startup order."""
    ensure_rule_matrix_subscription()
    return None


def schedule_rule_matrix_subscription_once() -> bool:
    """Schedule at most one nonpersistent post-registration retry."""
    if ensure_rule_matrix_subscription():
        return True
    try:
        from . import runtime_registry

        runtime_registry.register_timer(
            _rule_matrix_subscription_once,
            first_interval=0.0,
            persistent=False,
            label="manager_rule_api.workspace_runtime_subscription_once",
        )
    except Exception:
        return False
    return False


def _configure_rule_matrix_subscription(transaction) -> None:
    """Journal cleanup before any immediate or delayed subscription attempt."""
    global _RULE_MATRIX_SUBSCRIBER_GENERATION
    _RULE_MATRIX_SUBSCRIBER_GENERATION = str(getattr(transaction, "generation", "") or "")
    transaction.add_cleanup(
        _unsubscribe_rule_matrix_subscription,
        label="manager_rule_api.unsubscribe_workspace_runtime_redraw",
    )
    ensure_rule_matrix_subscription()


def panel_allowed(context, editor_key: str) -> bool:
    """Pure current-cell decision retained for compatibility callers."""
    key = str(editor_key or "").upper()
    if key not in EDITOR_KEYS or current_logical_editor(context) != key:
        return False
    expected_space = next(
        (physical for physical, logical in PHYSICAL_TO_LOGICAL.items() if key in logical),
        "",
    )
    if not physical_root_match(context, expected_space):
        return False
    return _manager_rule_allows(context, key)


def panel_allowed_current(context, physical_space: str, logical_keys: Iterable[str]) -> bool:
    """Pure native-root poll for the registered editor and logical cells."""
    physical = str(physical_space or "").upper()
    supplied = tuple(str(value or "").upper() for value in logical_keys)
    expected = PHYSICAL_TO_LOGICAL.get(physical)
    if physical == "FILE_BROWSER":
        if supplied not in (("ASSET_BROWSER",), ("FILE_BROWSER",)):
            return False
    elif expected is None or supplied != expected:
        return False
    if not physical_root_match(context, physical):
        return False
    editor_key = current_logical_editor(context)
    if editor_key not in supplied:
        return False
    return _manager_rule_allows(context, editor_key)


def manager_generation() -> str:
    module = _loaded_manager_module()
    if module is None:
        return ""
    manager_module = vars(module).get("manager")
    token = vars(manager_module).get("_registration_token", "") if isinstance(manager_module, ModuleType) else ""
    return str(token or "")


def manager_revision() -> str:
    module = _loaded_manager_module()
    if module is None:
        return ""
    info = vars(module).get("bl_info")
    version = info.get("version") if isinstance(info, dict) else None
    return ".".join(str(value) for value in version) if isinstance(version, tuple) else ""


def set_manager_enabled(
    enabled: bool, *, manager_generation_token: str = "", manager_revision_token: str = ""
) -> dict[str, Any]:
    """Explicit Manager lifecycle callback; never called from Panel.poll/draw."""
    global _MANAGER_ENABLED
    actual_generation = manager_generation()
    actual_revision = manager_revision()
    if manager_generation_token and actual_generation and str(manager_generation_token) != actual_generation:
        return {"ok": False, "reason": "stale_manager_generation"}
    if manager_revision_token and actual_revision and str(manager_revision_token) != actual_revision:
        return {"ok": False, "reason": "stale_manager_revision"}
    requested = bool(enabled)
    if requested == _MANAGER_ENABLED:
        return {"ok": True, "reason": "unchanged", "enabled": requested}
    _MANAGER_ENABLED = requested
    # Manager availability is advisory routing state, not Suite ownership.
    # Per-workspace callbacks suspend their own draw/input work. Never tear down
    # handlers, selections, pixels, caches, bridges, or registration here.
    ensure_rule_matrix_subscription()
    return {
        "ok": True,
        "reason": "manager_on" if requested else "manager_off",
        "enabled": requested,
        "runtime_preserved": True,
        "errors": [],
    }


def register_public_lifecycle(transaction) -> None:
    from . import runtime_registry

    payload = {
        "schema": 2,
        "owner": runtime_registry.SUITE_ID,
        "generation": str(transaction.generation),
        "revision": str(transaction.revision),
        "set_enabled": set_manager_enabled,
    }
    transaction.add_namespace_entry(bpy.app.driver_namespace, LIFECYCLE_API_KEY, payload)
    _configure_rule_matrix_subscription(transaction)


__all__ = (
    "EDITOR_KEYS", "LIFECYCLE_API_KEY", "MANAGER_MODULE_NAMES", "PHYSICAL_EDITOR_KEYS",
    "PHYSICAL_TO_LOGICAL", "PUBLIC_RULE_FUNCTION", "PUBLIC_RUNTIME_FUNCTION", "TOOL_KEY", "current_logical_editor",
    "RULE_MATRIX_SUBSCRIBER_ID",
    "ensure_rule_matrix_subscription", "manager_generation", "manager_revision", "panel_allowed", "panel_allowed_current",
    "physical_match", "physical_root_match", "register_public_lifecycle", "set_manager_enabled",
    "schedule_rule_matrix_subscription_once", "workspace_runtime_allowed",
)
