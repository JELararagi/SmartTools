# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

ADDON_ID = "smart_paint_suite"
ADDON_NAME = "Smart Paint"
ADDON_PREFIX = "SPS"
NODE_PREFIX = "SPS_"
GROUP_PREFIX = "SPS_GROUP_"
IMAGE_PREFIX = "SPS_"
TEMP_PREFIX = "SPS_TMP_"


BI_TRANSLATIONS: dict[str, str] = {}

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender module is unavailable outside Blender.
    bpy = None  # type: ignore


def _translation_language_from_context(context=None) -> str:
    # Blender 5.1 can emit RNA warnings when PreferencesView.language holds
    # an invalid enum value during background startup.  Use the translation
    # locale instead; it is stable and does not trigger enum validation noise.
    try:
        value = getattr(getattr(getattr(bpy, 'app', None), 'translations', None), 'locale', '') if bpy is not None else ''
        text = str(value or '').upper()
        if text:
            return text
    except Exception:
        pass
    return ''


def _is_japanese_runtime(context=None) -> bool:
    language = _translation_language_from_context(context)
    return any(token in language for token in ('JA', 'JP', 'JAPANESE'))


def is_japanese_runtime(context=None) -> bool:
    return _is_japanese_runtime(context)


_LOCAL_TRANSLATION_CACHE: dict[str, str] | None = None


def _local_japanese_lookup(source: str) -> str | None:
    """Fallback lookup used before Blender's translation registry is ready."""
    global _LOCAL_TRANSLATION_CACHE
    key = str(source or '')
    if not key:
        return None
    try:
        if _LOCAL_TRANSLATION_CACHE is None:
            from . import translation as _sps_translation
            data = _sps_translation.build_translations().get('ja_JP', {})
            flat: dict[str, str] = {}
            for trans_key, value in data.items():
                if isinstance(trans_key, tuple) and len(trans_key) >= 2:
                    flat.setdefault(str(trans_key[1]), str(value))
            _LOCAL_TRANSLATION_CACHE = flat
        translated = _LOCAL_TRANSLATION_CACHE.get(key)
        return translated if translated and translated != key else None
    except Exception:
        return None


def _register_bi(en: str, ja: str) -> tuple[str, str]:
    en_text = str(en or '')
    ja_text = str(ja or '')
    if en_text and ja_text:
        BI_TRANSLATIONS.setdefault(en_text, ja_text)
    return en_text, ja_text


def bi(en: str, ja: str) -> str:
    """Return the English source string and register its Japanese translation.

    Blender's translation system expects the RNA source text to stay in one
    canonical language.  Returning English here prevents labels, enum names,
    and tooltips from becoming permanently Japanese when the add-on is enabled
    under a Japanese UI.
    """
    en_text, _ja_text = _register_bi(en, ja)
    return en_text


def loc(context, en: str, ja: str) -> str:
    """Return the current UI-language string for runtime-only messages."""
    en_text, ja_text = _register_bi(en, ja)
    return ja_text if _is_japanese_runtime(context) else en_text


def _dynamic_ui_fallback(source: str) -> str:
    """Translate common runtime-composed UI strings that cannot be keyed exactly."""
    import re

    text = str(source or '')
    if not text:
        return text

    vc_map = {
        'Color Attribute': 'カラー属性',
        'Color attribute': 'カラー属性',
        'color attribute': 'カラー属性',
        'Vertex Color': '頂点カラー',
        'Vertex color': '頂点カラー',
        'vertex color': '頂点カラー',
    }

    def tr_vc(value: str) -> str:
        return vc_map.get(value, value)

    exact = {
        'Image': '画像',
        'Color Attribute': 'カラー属性',
        'Color attribute': 'カラー属性',
        'color attribute': 'カラー属性',
        'Vertex Color': '頂点カラー',
        'Vertex color': '頂点カラー',
        'vertex color': '頂点カラー',
        'Discord Server': 'Discord サーバー',
        'Wiki': 'Wiki',
        'GitHub': 'GitHub',
        ' (Active)': '（アクティブ）',
        ' (Disabled)': '（無効）',
        'Fill ': '塗りつぶし ',
        'Object: ': 'オブジェクト: ',
        'Material: ': 'マテリアル: ',
        'Source: ': 'ソース: ',
    }
    if text in exact:
        return exact[text]

    prefix_map = (
        ('Active Image: ', 'アクティブ画像: '),
        ('Active: ', 'アクティブ: '),
        ('Atlas Tile X: ', 'アトラスタイルX: '),
        ('Atlas Tile Y: ', 'アトラスタイルY: '),
        ('Height: ', '高さ: '),
        ('Image: ', '画像: '),
        ('Info: ', '情報: '),
        ('Object: ', 'オブジェクト: '),
        ('Material: ', 'マテリアル: '),
        ('Source: ', 'ソース: '),
        ('Main UV: ', 'メインUV: '),
        ('Number of Color Ramps: ', 'カラーランプ数: '),
        ('Number of Generated Textures: ', '生成テクスチャ数: '),
        ('Number of Images: ', '画像数: '),
        ('Number of RGB Curves: ', 'RGBカーブ数: '),
        ('Path: ', 'パス: '),
        ('Sculpting: ', 'スカルプト中: '),
        ('Test Error Count: ', 'テストエラー数: '),
        ('Test Failed Count: ', 'テスト失敗数: '),
        ('Test Run Count: ', 'テスト実行数: '),
        ('UDIM tiles: ', 'UDIMタイル: '),
        ('Width: ', '幅: '),
        ('Will create a new UV Map: ', '新しいUVマップを作成: '),
        ('Using UV Map: ', '使用中のUVマップ: '),
    )
    for en, ja in prefix_map:
        if text.startswith(en):
            return ja + text[len(en):]

    suffix_map = (
        (' Source', ' ソース'),
        (' Mask:', ' マスク:'),
        (' Channel', ' チャンネル'),
        (' channels', ' チャンネル'),
        (' channel', ' チャンネル'),
    )
    for en, ja in suffix_map:
        if text.endswith(en) and len(text) > len(en):
            return text[:-len(en)] + ja

    patterns = (
        (r'^Number of (.+): $', lambda m: f"{_dynamic_ui_fallback(m.group(1))}数: "),
        (r'^(.+) \(Active\)$', lambda m: f"{ui_text(m.group(1))}（アクティブ）"),
        (r'^(.+) \(Disabled\)$', lambda m: f"{ui_text(m.group(1))}（無効）"),
        (r'^Open Image in (.+)$', lambda m: f"{m.group(1)}で画像を開く"),
        (r'^Rebake (.+)$', lambda m: f"{m.group(1)}を再ベイク"),
        (r'^Bake (.+) as Image$', lambda m: f"{m.group(1)}を画像としてベイク"),
        (r'^Bake (.+) Channel$', lambda m: f"{m.group(1)}チャンネルをベイク"),
        (r'^Bake Channel to (.+) \(Batch All Materials\)$', lambda m: f"チャンネルを{tr_vc(m.group(1))}へベイク（全マテリアル一括）"),
        (r'^Bake Channel to (.+)$', lambda m: f"チャンネルを{tr_vc(m.group(1))}へベイク"),
        (r'^New (Color Attribute|Color attribute|Vertex Color|Vertex color)$', lambda m: f"新規{tr_vc(m.group(1))}"),
        (r'^Open Existing (Color Attribute|Color attribute|Vertex Color|Vertex color)$', lambda m: f"既存{tr_vc(m.group(1))}を開く"),
        (r'^Use Existing (Color Attribute|Color attribute|Vertex Color|Vertex color)$', lambda m: f"既存{tr_vc(m.group(1))}を使用"),
        (r'^Background w/ (Color Attribute|Color attribute|Vertex Color|Vertex color) Mask$', lambda m: f"{tr_vc(m.group(1))}マスク付き背景"),
        (r'^Solid Color w/ (Color Attribute|Color attribute|Vertex Color|Vertex color) Mask$', lambda m: f"{tr_vc(m.group(1))}マスク付き単色"),
        (r'^Fix Active (Color Attribute|Color attribute|Vertex Color|Vertex color) Missmatch!$', lambda m: f"アクティブ{tr_vc(m.group(1))}の不一致を修正!"),
        (r'^Fill (.+):$', lambda m: f"{m.group(1)}を塗りつぶし:"),
        (r'^Target (Color Attribute|Color attribute|Vertex Color|Vertex color):$', lambda m: f"対象{tr_vc(m.group(1))}:"),
        (r'^(Color Attribute|Color attribute|Vertex Color|Vertex color)s$', lambda m: f"{tr_vc(m.group(1))}一覧"),
        (r'^(Color Attribute|Color attribute|Vertex Color|Vertex color): (.+)$', lambda m: f"{tr_vc(m.group(1))}: {m.group(2)}"),
        (r'^Baked (Color Attribute|Color attribute|Vertex Color|Vertex color) is missing!(.*)$', lambda m: f"ベイク済み{tr_vc(m.group(1))}が見つかりません!{m.group(2)}"),
        (r'^Duplicate Material and (.+) nodes$', lambda m: f"マテリアルと{m.group(1)}ノードを複製"),
        (r'^Fix Multi-User (.+) Node$', lambda m: f"マルチユーザー{m.group(1)}ノードを修正"),
        (r'^Support (.+)!$', lambda m: f"{m.group(1)}を支援!"),
        (r'^Update (.+)$', lambda m: f"{m.group(1)}を更新"),
        (r'^Update node to version (.+)$', lambda m: f"ノードをバージョン {m.group(1)} へ更新"),
        (r'^(.+) Discord Server$', lambda m: f"{m.group(1)} Discord サーバー"),
        (r'^(.+) GitHub$', lambda m: f"{m.group(1)} GitHub"),
        (r'^(.+) Wiki$', lambda m: f"{m.group(1)} Wiki"),
        (r'^(.+) is created by:? ?$', lambda m: f"{m.group(1)} の作成者:"),
        (r"^You need to select object that uses (.+) node!$", lambda m: f"{m.group(1)}ノードを使用しているオブジェクトを選択してください!"),
        (r"^This (.+) node setup isn't baked yet!$", lambda m: f"この{m.group(1)}ノード構成はまだベイクされていません!"),
        (r"^No children is using '(.+)' channel!$", lambda m: f"'{m.group(1)}' チャンネルを使用している子はありません!"),
        (r"^Are you sure to use '(.+)' as alpha channel\?$", lambda m: f"'{m.group(1)}' をアルファチャンネルとして使用しますか?"),
        (r'^Remap (.+) to:$', lambda m: f"{m.group(1)} を再マップ:"),
        (r'^(.+) channel is combined to (.+) bake result!$', lambda m: f"{m.group(1)} チャンネルは {m.group(2)} のベイク結果に結合されます!"),
        (r"^(.+) channel hasn't been baked yet!$", lambda m: f"{m.group(1)} チャンネルはまだベイクされていません!"),
        (r'^Active Target: (.+)$', lambda m: f"アクティブ対象: {m.group(1)}"),
        (r'^Snapshot: (.+)$', lambda m: f"スナップショット: {m.group(1)}"),
        (r'^Output Directory: (.+)$', lambda m: f"出力ディレクトリ: {m.group(1)}"),
        (r'^Use Extension Storage Root: (ON|OFF)$', lambda m: f"拡張機能保存領域基準: {'オン' if m.group(1) == 'ON' else 'オフ'}"),
        (r'^Overwrite on Timer: (ON|OFF)$', lambda m: f"タイマー保存時に上書き: {'オン' if m.group(1) == 'ON' else 'オフ'}"),
        (r'^Overwrite on \.blend Save: (ON|OFF)$', lambda m: f".blend保存時に上書き: {'オン' if m.group(1) == 'ON' else 'オフ'}"),
    )
    for pattern, repl in patterns:
        match = re.match(pattern, text)
        if match:
            return repl(match)

    return text


def ui_text(text: str, context=None) -> str:
    """Translate an existing English UI label through Blender's dictionary."""
    source = str(text or '')
    if not source or not _is_japanese_runtime(context):
        return source
    if bpy is not None:
        translations = getattr(getattr(bpy, 'app', None), 'translations', None)
        if translations is not None:
            for getter_name in ('pgettext_iface', 'pgettext_tip', 'pgettext'):
                getter = getattr(translations, getter_name, None)
                if getter is None:
                    continue
                try:
                    translated = getter(source)
                except Exception:
                    continue
                if translated and translated != source:
                    return translated
    local = _local_japanese_lookup(source)
    if local:
        return local
    return _dynamic_ui_fallback(source)


_ENGLISH_SOURCE_CACHE: dict[str, str] | None = None
_INTERNAL_REASON = __import__('re').compile(r"^[A-Za-z0-9_.:/\-]+$")
_JAPANESE_CHARS = __import__('re').compile("[\u3040-\u30ff\u4e00-\u9fff]")


def _runtime_text(source: str) -> str:
    """Return one source string in the active language (Japanese or English)."""
    if not source:
        return source
    translated = source
    if bpy is not None:
        try:
            translated = bpy.app.translations.pgettext_iface(source)
        except Exception:
            translated = source
    if translated != source or _is_japanese_runtime():
        return translated
    global _ENGLISH_SOURCE_CACHE
    if _ENGLISH_SOURCE_CACHE is None:
        try:
            from .translation_en import JAPANESE_SOURCE_ENGLISH
            _ENGLISH_SOURCE_CACHE = dict(JAPANESE_SOURCE_ENGLISH)
        except Exception:
            _ENGLISH_SOURCE_CACHE = {}
    return _ENGLISH_SOURCE_CACHE.get(source, source)


def report_fmt(template: str, *values) -> str:
    """Translate a report/status template, then fill in its values."""
    text = _runtime_text(str(template or ''))
    return text.format(*values) if values else text


def _reason_detail(reason) -> str:
    """A failure reason the user can read, or '' for internal codes and raw exceptions."""
    source = str(reason or '').strip()
    if not source:
        return ''
    code, separator, readable = source.partition(' — ')
    if separator and _INTERNAL_REASON.match(code):
        source = readable.strip()
    translated = _runtime_text(source)
    if translated != source:
        return translated
    if _is_japanese_runtime():
        return source if _JAPANESE_CHARS.search(source) else ''
    if _JAPANESE_CHARS.search(source) or _INTERNAL_REASON.match(source):
        return ''
    return source


def report_fail(head: str, reason=None) -> str:
    """'<what failed>: <why>' with only readable reasons, in the active language."""
    text = _runtime_text(str(head or ''))
    detail = _reason_detail(reason)
    return f"{text}: {detail}"[:400] if detail else text


def report_msg(message) -> str:
    """One whole message in the active language; internal text becomes a plain failure line."""
    return _reason_detail(message) or _runtime_text('処理に失敗しました。')


def report_text(text: str, context=None) -> str:
    """Translate runtime report/status text without changing English output."""
    source = str(text or '')
    if not source or not _is_japanese_runtime(context):
        return source
    translated = ui_text(source, context)
    if translated != source:
        return translated
    # Common dynamic report patterns used by this suite.
    match = __import__('re').match(r"^Smart Paint initialized on '(.+)'\.$", source)
    if match:
        return f"'{match.group(1)}' で Smart Paint を初期化しました。"
    match = __import__('re').match(r"^Rebuilt '(.+)'\.$", source)
    if match:
        return f"'{match.group(1)}' を再構築しました。"
    match = __import__('re').match(r"^Baked (.+) map to '(.+)'\.$", source)
    if match:
        return f"{match.group(1)} マップを '{match.group(2)}' にベイクしました。"
    match = __import__('re').match(r"^Saved (\d+) Smart Paint image\(s\)\.$", source)
    if match:
        return f"Smart Paint 画像を {match.group(1)} 件保存しました。"
    match = __import__('re').match(r"^Packed (\d+) image\(s\)\.$", source)
    if match:
        return f"画像を {match.group(1)} 件パックしました。"
    match = __import__('re').match(r"^Audit report updated: (.+)$", source)
    if match:
        return f"監査レポートを更新しました: {match.group(1)}"
    match = __import__('re').match(r"^Active paint target: (.+) / (.+)$", source)
    if match:
        return f"アクティブなペイント対象: {match.group(1)} / {match.group(2)}"
    if source.startswith('Validation complete.'):
        return source.replace('Validation complete.', '検証が完了しました。').replace('No obvious problems were found.', '明確な問題は見つかりませんでした。')
    if source.startswith('Health check complete.'):
        return source.replace('Health check complete.', 'ヘルスチェックが完了しました。').replace('No obvious problems were found.', '明確な問題は見つかりませんでした。')
    import re
    report_patterns = (
        (r"^/!\\ Box Deform : Cannot find object to target$", lambda m: "ボックス変形: 対象オブジェクトが見つかりません。"),
        (r"^/!\\ No 'tmp_lattice' modifiers on GP object$", lambda m: "GPオブジェクトに 'tmp_lattice' モディファイアーがありません。"),
        (r"^A mesh object must be active\.$", lambda m: "メッシュオブジェクトをアクティブにしてください。"),
        (r"^A projection buffer is already active\. Commit, cancel, or reset it before starting a new one\.$", lambda m: "投影バッファはすでに有効です。新しく開始する前に確定、キャンセル、またはリセットしてください。"),
        (r"^Anchor Dirt needs a lower layer to reference\.$", lambda m: "アンカー汚れには参照元になる下位レイヤーが必要です。"),
        (r"^Save aborted \(validation diff\)\. A verification copy was saved to '(.+)'\.$", lambda m: f"保存を中止しました（検証差分あり）: 検証用コピーを '{m.group(1)}' に保存しました"),
        (r"^Blender brush textures are not available in this build\.$", lambda m: "このビルドでは Blender ブラシテクスチャを利用できません。"),
        (r"^Blender text datablocks are not available\.$", lambda m: "Blender テキストデータブロックを利用できません。"),
        (r"^Color attributes are not available\.$", lambda m: "カラー属性を利用できません。"),
        (r"^Could not assign image '(.+)' to a brush texture\.$", lambda m: f"画像 '{m.group(1)}' をブラシテクスチャへ割り当てられませんでした。"),
        (r"^Could not find the final managed output for channel '(.+)'\. Rebuild the stack first\.$", lambda m: f"チャンネル '{m.group(1)}' の最終管理出力が見つかりません。先にスタックを再構築してください。"),
        (r"^Could not find the image node for (.+)\.$", lambda m: f"{m.group(1)} の画像ノードが見つかりません。"),
        (r"^Could not resize image during transform: (.+)$", lambda m: f"変形中に画像サイズを変更できませんでした: {m.group(1)}"),
        (r"^Empty file path\.$", lambda m: "ファイルパスが空です。"),
        (r"^Failed to save export image '(.+)': (.+)$", lambda m: f"書き出し画像 '{m.group(1)}' の保存に失敗しました: {m.group(2)}"),
        (r"^Failed to save tiled image '(.+)': (.+)$", lambda m: f"タイル画像 '{m.group(1)}' の保存に失敗しました: {m.group(2)}"),
        (r"^File not found: (.+)$", lambda m: f"ファイルが見つかりません: {m.group(1)}"),
        (r"^Image '(.+)' does not point to an existing file yet\.$", lambda m: f"画像 '{m.group(1)}' はまだ既存ファイルを参照していません。"),
        (r"^Image '(.+)' has no readable size\.$", lambda m: f"画像 '{m.group(1)}' のサイズを読み取れません。"),
        (r"^Image '(.+)' has unsaved Blender-side changes\. Save it first or enable Discard Unsaved Changes for this reload\.$", lambda m: f"画像 '{m.group(1)}' には Blender 側の未保存変更があります。先に保存するか、この再読込で「未保存の変更を破棄」を有効にしてください。"),
        (r"^Image has no readable size\.$", lambda m: "画像サイズを読み取れません。"),
        (r"^Import directory not found: (.+)$", lambda m: f"読み込みフォルダーが見つかりません: {m.group(1)}"),
        (r"^Material output node was not found on the temporary export material\.$", lambda m: "一時書き出しマテリアルにマテリアル出力ノードが見つかりません。"),
        (r"^No Smart Paint images are linked to the active material\.$", lambda m: "アクティブマテリアルに Smart Paint 画像がリンクされていません。"),
        (r"^No Smart Paint snapshot text is selected or recorded yet\.$", lambda m: "Smart Paint スナップショットテキストがまだ選択または記録されていません。"),
        (r"^No active layer available for import\.$", lambda m: "読み込み先のアクティブレイヤーがありません。"),
        (r"^No active layer to duplicate\.$", lambda m: "複製するアクティブレイヤーがありません。"),
        (r"^No active layer\.$", lambda m: "アクティブレイヤーがありません。"),
        (r"^No active object\.$", lambda m: "アクティブオブジェクトがありません。"),
        (r"^No image is available for transformation\.$", lambda m: "変形できる画像がありません。"),
        (r"^No images could be consolidated successfully\.$", lambda m: "正常に集約できた画像がありません。"),
        (r"^No layer to remove\.$", lambda m: "削除するレイヤーがありません。"),
        (r"^No material to rebuild\.$", lambda m: "再構築するマテリアルがありません。"),
        (r"^No projection buffer is active\.$", lambda m: "有効な投影バッファがありません。"),
        (r"^No projection buffer or projection image is active\.$", lambda m: "有効な投影バッファまたは投影画像がありません。"),
        (r"^No projection image is available\. Set Projection Image or extract a sprite frame first\.$", lambda m: "投影画像がありません。先に投影画像を設定するか、スプライトフレームを切り出してください。"),
        (r"^No projection image is selected in the scene settings\.$", lambda m: "シーン設定で投影画像が選択されていません。"),
        (r"^No projection image is selected\.$", lambda m: "投影画像が選択されていません。"),
        (r"^No projection-buffer target layer is active\.$", lambda m: "投影バッファの対象レイヤーがアクティブではありません。"),
        (r"^No recognizable PBR texture files were found in the import directory\.$", lambda m: "読み込みフォルダー内に認識可能な PBR テクスチャファイルが見つかりません。"),
        (r"^No recognizable PBR texture sets were found\.$", lambda m: "認識可能な PBR テクスチャセットが見つかりません。"),
        (r"^No source image to duplicate\.$", lambda m: "複製元画像がありません。"),
        (r"^No source image was provided\.$", lambda m: "元画像が指定されていません。"),
        (r"^No source projection image is available for reset\.$", lambda m: "リセットに使える元の投影画像がありません。"),
        (r"^No source sprite sheet image was provided\.$", lambda m: "元のスプライトシート画像が指定されていません。"),
        (r"^No sprite sheet image is set\. Use Sprite Sheet Image, Projection Image, or an active paint canvas\.$", lambda m: "スプライトシート画像が設定されていません。スプライトシート画像、投影画像、またはアクティブなペイントキャンバスを使ってください。"),
        (r"^No suitable image was found for external editing\.$", lambda m: "外部編集に適した画像が見つかりません。"),
        (r"^No suitable image was found to reload\.$", lambda m: "再読込に適した画像が見つかりません。"),
        (r"^No usable height image was found\. Enable a Height channel, create a height image, or activate a height paint target first\.$", lambda m: "使用可能な高さ画像が見つかりません。先に高さチャンネルを有効化するか、高さ画像を作成するか、高さのペイント対象をアクティブにしてください。"),
        (r"^No valid search directories were found for path repair\.$", lambda m: "パス修復に使える検索フォルダーが見つかりません。"),
        (r"^Pixel buffer size mismatch\. Expected (.+), got (.+)\.$", lambda m: f"ピクセルバッファサイズが一致しません。期待値: {m.group(1)}、実際: {m.group(2)}。"),
        (r"^Select a source mesh together with the active target mesh\.$", lambda m: "アクティブな対象メッシュと一緒に元メッシュを選択してください。"),
        (r"^Smart Paint properties are not registered\.$", lambda m: "Smart Paint プロパティが登録されていません。"),
        (r"^Smart Paint scene properties are not registered\.$", lambda m: "Smart Paint シーンプロパティが登録されていません。"),
        (r"^Snapshot JSON could not be parsed: (.+)$", lambda m: f"スナップショット JSON を解析できませんでした: {m.group(1)}"),
        (r"^Sprite sheet '(.+)' has no readable size\.$", lambda m: f"スプライトシート '{m.group(1)}' のサイズを読み取れません。"),
        (r"^Texture Paint brush is not available\.$", lambda m: "テクスチャペイントブラシを利用できません。"),
        (r"^The active mesh does not support color attributes\.$", lambda m: "アクティブメッシュはカラー属性に対応していません。"),
        (r"^The active mesh has no polygons to receive material IDs\.$", lambda m: "アクティブメッシュにはマテリアル ID を受け取るポリゴンがありません。"),
        (r"^The active object does not support UV layers\.$", lambda m: "アクティブオブジェクトは UV レイヤーに対応していません。"),
        (r"^The chosen image must be saved before external editing\.$", lambda m: "選択した画像は外部編集前に保存する必要があります。"),
        (r"^The configured color attribute must use the CORNER domain for material ID baking\.$", lambda m: "マテリアル ID ベイク用のカラー属性は CORNER ドメインである必要があります。"),
        (r"^The selected snapshot text is empty\.$", lambda m: "選択したスナップショットテキストが空です。"),
        (r"^The selected text is not a Smart Paint snapshot\.$", lambda m: "選択したテキストは Smart Paint スナップショットではありません。"),
        (r"^This Blender build does not expose legacy Texture datablocks needed by the Displace modifier preview\.$", lambda m: "この Blender ビルドでは、ディスプレイスモディファイアープレビューに必要な旧式 Texture データブロックが公開されていません。"),
        (r"^Unsupported projection-buffer transform '(.+)'\.$", lambda m: f"未対応の投影バッファ変形です: '{m.group(1)}'。"),
        (r"^Removed (\d+) image\(s\), (\d+) node group\(s\), (\d+) material\(s\)\.$", lambda m: f"画像 {m.group(1)} 件、ノードグループ {m.group(2)} 件、マテリアル {m.group(3)} 件を削除しました。"),
        (r"^No missing enabled channel images on '(.+)'\.$", lambda m: f"'{m.group(1)}' に不足している有効チャンネル画像はありません。"),
        (r"^Skipped Brushstroke layer '(.+)' because it is invisible in this context$", lambda m: f"ブラシストロークレイヤー '{m.group(1)}' は現在のコンテキストで非表示のためスキップしました。"),
        (r"^Baked (\d+) materials in ([0-9.]+) seconds$", lambda m: f"{m.group(1)} 個のマテリアルを {m.group(2)} 秒でベイクしました。"),
        (r"^Transferred image layer UV in ([0-9.]+) seconds$", lambda m: f"画像レイヤーのUVを {m.group(1)} 秒で転送しました。"),
        (r"^Converted to image layer in ([0-9.]+) seconds$", lambda m: f"画像レイヤーへ {m.group(1)} 秒で変換しました。"),
        (r"^Merged down in ([0-9.]+) seconds$", lambda m: f"{m.group(1)} 秒で下へ結合しました。"),
        (r"^Merged up in ([0-9.]+) seconds$", lambda m: f"{m.group(1)} 秒で上へ結合しました。"),
        (r"^Exported (\d+) images to (.+)$", lambda m: f"画像 {m.group(1)} 件を {m.group(2)} へ書き出しました。"),
        (r"^Failed to export (\d+) images$", lambda m: f"画像 {m.group(1)} 件の書き出しに失敗しました。"),
        (r"^Failed to create directory: (.+)$", lambda m: f"フォルダーの作成に失敗しました: {m.group(1)}"),
        (r"^Failed to export (.+): (.+)$", lambda m: f"{m.group(1)} の書き出しに失敗しました: {m.group(2)}"),
        (r"^Completed with (\d+) errors?$", lambda m: f"{m.group(1)} 件のエラーで完了しました。"),
        (r"^Brush folder not found: (.+)$", lambda m: f"ブラシフォルダーが見つかりません: {m.group(1)}"),
        (r"^Brush texture not found: (.+)$", lambda m: f"ブラシテクスチャが見つかりません: {m.group(1)}"),
        (r"^Could not find (.+) installation$", lambda m: f"{m.group(1)} のインストールが見つかりません。"),
        (r"^Could not find node for layer '(.+)'$", lambda m: f"レイヤー '{m.group(1)}' のノードが見つかりません。"),
        (r"^(.+) - (.+)$", lambda m: f"{m.group(1)} - {ui_text(m.group(2), context)}"),
        (r"^All layers and masks using (.+) are transferred to (.+) in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} を使用するすべてのレイヤーとマスクを {m.group(2)} へ {m.group(3)} 秒で転送しました!"),
        (r"^(.+) UV is transferred from (.+) to (.+) in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} のUVを {m.group(2)} から {m.group(3)} へ {m.group(4)} 秒で転送しました!"),
        (r"^Merging layers is done in ([0-9.]+) seconds!$", lambda m: f"レイヤー結合が {m.group(1)} 秒で完了しました!"),
        (r"^Merging masks is done in ([0-9.]+) seconds!$", lambda m: f"マスク結合が {m.group(1)} 秒で完了しました!"),
        (r"^Baking (.+) is done in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} のベイクが {m.group(2)} 秒で完了しました!"),
        (r"^Rebaking all baked layers & masks is done in ([0-9.]+) seconds!$", lambda m: f"すべてのベイク済みレイヤーとマスクの再ベイクが {m.group(1)} 秒で完了しました!"),
        (r"^(.+) channel is baked in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} チャンネルを {m.group(2)} 秒でベイクしました!"),
        (r"^(.+) channels are baked in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} のチャンネルを {m.group(2)} 秒でベイクしました!"),
        (r"^This layer/mask already use (.+)!$", lambda m: f"このレイヤー/マスクはすでに {m.group(1)} を使用しています!"),
        (r"^No layer is using '(.+)' channel!$", lambda m: f"'{m.group(1)}' チャンネルを使用しているレイヤーはありません!"),
        (r"^(.+) cannot be empty!$", lambda m: f"{ui_text(m.group(1), context)} は空にできません!"),
        (r"^(.+) only works with mesh object!$", lambda m: f"{ui_text(m.group(1), context)} はメッシュオブジェクトでのみ使用できます!"),
        (r"^Mesh can only use 8 (.+)!$", lambda m: f"メッシュで使用できる {ui_text(m.group(1), context)} は 8 個までです!"),
        (r"^Cannot use (.+) with object '(.+)'!$", lambda m: f"オブジェクト '{m.group(2)}' では {m.group(1)} を使用できません!"),
        (r"^Material has no (.+) node!$", lambda m: f"マテリアルに {m.group(1)} ノードがありません!"),
        (r"^Image named (.+) is not found!$", lambda m: f"画像 {m.group(1)} が見つかりません!"),
        (r"^Channel named '(.+)' is already available!$", lambda m: f"チャンネル '{m.group(1)}' はすでに存在します!"),
        (r"^Alpha channel is already enabled in '(.+)'!$", lambda m: f"アルファチャンネルは '{m.group(1)}' ですでに有効です!"),
        (r"^Alpha channel already exists \('(.+)'\)!$", lambda m: f"アルファチャンネルはすでに存在します（'{m.group(1)}'）!"),
        (r"^Node named (.+) is not found!$", lambda m: f"ノード {m.group(1)} が見つかりません!"),
        (r"^There's no (.+) named (.+)!$", lambda m: f"{ui_text(m.group(1), context)} '{m.group(2)}' はありません!"),
        (r"^Sculpt mode is entered in ([0-9.]+) seconds!$", lambda m: f"{m.group(1)} 秒でスカルプトモードに入りました!"),
        (r"^Applying sculpt to VDM is done in ([0-9.]+) seconds!$", lambda m: f"VDMへのスカルプト適用が {m.group(1)} 秒で完了しました!"),
        (r"^Copied: (.+)$", lambda m: f"コピーしました: {m.group(1)}"),
    )
    for pattern, repl in report_patterns:
        match = re.match(pattern, source)
        if match:
            return repl(match)
    if 'not found' in source:
        return '対象が見つかりません。内容を確認してから再実行してください。'
    if 'failed' in source.lower() or 'cannot' in source.lower() or 'could not' in source.lower():
        return '処理に失敗しました。対象、設定、ファイルパスを確認してから再実行してください。'
    return _dynamic_ui_fallback(source)


RESOLUTION_ITEMS = [
    ("512", "512", bi("512 x 512 texture size.", "512 x 512 のテクスチャサイズです。")),
    ("1024", "1024", bi("1024 x 1024 texture size.", "1024 x 1024 のテクスチャサイズです。")),
    ("2048", "2048", bi("2048 x 2048 texture size.", "2048 x 2048 のテクスチャサイズです。")),
    ("4096", "4096", bi("4096 x 4096 texture size.", "4096 x 4096 のテクスチャサイズです。")),
    ("8192", "8192", bi("8192 x 8192 texture size.", "8192 x 8192 のテクスチャサイズです。")),
    ("16384", "16384", bi("16384 x 16384 texture size for higher-end UDIM or film-style work.", "高解像度のUDIMや映画向け作業用の 16384 x 16384 テクスチャサイズです。")),
    ("32768", "32768", bi("32768 x 32768 texture size for extreme high-end workflows. Use with care because memory use can be very high.", "極めて高解像度なワークフロー向けの 32768 x 32768 テクスチャサイズです。メモリ消費が非常に大きいため注意して使ってください。")),
]


EXPORT_FORMAT_ITEMS = [
    ("PNG", "PNG", bi("Export images as PNG files. Good default for color and standard texture maps.", "画像を PNG で書き出します。カラーや標準的なテクスチャマップ向けの既定値です。")),
    ("TIFF", "TIFF", bi("Export images as TIFF files. Useful when a pipeline expects TIFF without switching to EXR.", "画像を TIFF で書き出します。EXR へ切り替えずに TIFF を要求するパイプライン向けです。")),
    ("OPEN_EXR", "OpenEXR", bi("Export images as OpenEXR files. Recommended for float / height style outputs.", '画像を OpenEXR で書き出します。浮動小数点や高さの出力に向いています。')),
]

PACKED_LAYOUT_ITEMS = [
    ("ORM", "ORM", bi("Pack AO into Red, Roughness into Green, Metallic into Blue.", "AOを赤、ラフネスを緑、メタリックを青へパックします。")),
    ("ARM", "ARM", bi("Alias of ORM using the Ambient/Roughness/Metallic naming style.", 'アンビエント / ラフネス / メタリックの呼び方に合わせたORMの別名です。')),
    ("RMA", "RMA", bi("Pack Roughness into Red, Metallic into Green, AO into Blue.", "ラフネスを赤、メタリックを緑、AOを青へパックします。")),
    ("MRA", "MRA", bi("Pack Metallic into Red, Roughness into Green, AO into Blue.", "メタリックを赤、ラフネスを緑、AOを青へパックします。")),
]

LAYER_KIND_ITEMS = [
    ("PAINT", "Paint", bi("Image based layer intended for direct painting.", "直接ペイント向けの画像ベースレイヤーです。")),
    ("PBR_PAINT", "PBR Paint", bi("Multi-channel image layer intended for full PBR paint sets such as color, roughness, metallic, normal, and height.", "カラー、粗さ、メタリック、ノーマル、高さなどのフルPBRセット向けマルチチャンネル画像レイヤーです。")),
    ("FILL", "Fill", bi("Solid value layer for quickly blocking in color and PBR values.", "色やPBR値を素早く埋める塗りつぶしレイヤーです。")),
    ("DECAL", "Decal", bi("Overlay layer for labels, stains, stickers and projected details.", "ラベル・汚れ・ステッカー・投影ディテール向けの重ねレイヤーです。")),
    ("PROCEDURAL", "Procedural", bi("Procedural helper layer that relies on masks and generated data.", "マスクや生成データを使うプロシージャル補助レイヤーです。")),
    ("WEATHER", "Weather", bi("Weathering helper layer tuned for dust, leaks, erosion and broad material breakup.", "ほこり、垂れ、侵食、広い質感崩し向けに調整されたウェザリング補助レイヤーです。")),
    ("GROUP", "Group", bi("Layer group / folder marker preserved in PSD import and export.", "PSD読み込み／保存で保持されるレイヤーグループ／フォルダーマーカーです。")),
    ("ADJUSTMENT", "Adjustment", bi("Non-destructive Photoshop/CSP-style adjustment layer applied to the layers below.", "下のレイヤーへ非破壊で作用する Photoshop/CSP 風の調整レイヤーです。")),
]

ADJUSTMENT_TYPE_ITEMS = [
    ("NONE", "None", bi("No adjustment.", "調整なしです。")),
    ("BRIGHTNESS_CONTRAST", "Brightness / Contrast", bi("Brightness and contrast adjustment.", "明るさ・コントラスト調整です。")),
    ("HUE_SATURATION", "Hue / Saturation / Lightness", bi("Hue, saturation and lightness adjustment.", "色相・彩度・明度調整です。")),
    ("POSTERIZE", "Posterize", bi("Posterize / tonal step adjustment.", "階調化です。")),
    ("INVERT", "Invert", bi("Invert colors.", "階調の反転です。")),
    ("LEVELS", "Levels", bi("Input/output levels and gamma correction.", "レベル補正です。")),
    ("CURVES", "Tone Curve", bi("Tone curve adjustment.", "トーンカーブ調整です。")),
    ("COLOR_BALANCE", "Color Balance", bi("Shadows, midtones and highlights color balance.", "シャドウ・中間調・ハイライトのカラーバランスです。")),
    ("THRESHOLD", "Threshold", bi("Binarize by threshold.", "2値化です。")),
    ("GRADIENT_MAP", "Gradient Map", bi("Map luminance to a two-color gradient.", "輝度を2色グラデーションへ割り当てます。")),
]

BLEND_MODE_ITEMS = [
    ("MIX", bi("Mix", "ミックス"), bi("Standard layer blending. The layer is composited over the result below using alpha, mask, and opacity.", "標準的なレイヤーブレンドです。アルファ、マスク、不透明度を使って下の結果へ合成します。")),
    ("PASS_THROUGH", bi("Pass Through", "パススルー"), bi("Substance-style pass-through. Folder contents interact directly with layers below the folder; raster paint without effects behaves like normal paint.", "Substance風のパススルーです。フォルダー内の内容がフォルダー外の下位レイヤーへ直接作用します。エフェクトのない通常描画は通常合成として扱います。")),
    ("DISABLE", bi("Disable", "無効"), bi("Ignore this layer for the current compositing channel without deleting the layer data.", "レイヤーデータを削除せず、この合成チャンネルではこのレイヤーを無視します。")),
    ("REPLACE", bi("Replace", "置き換え"), bi("Overwrite the result below with this layer, including transparent pixels. Transparent pixels can cut through instead of revealing lower layers.", "透明ピクセルを含め、このレイヤーで下の結果を置き換えます。透明部分は下を表示せず透明として切り抜けます。")),
    ("ADD", bi("Add", "加算"), bi("Linear Dodge/Add. Adds the layer color value to the result below.", "覆い焼き（リニア）/加算です。レイヤー色を下の結果へ加算します。")),
    ("MULTIPLY", bi("Multiply", "乗算"), bi("Multiplies the current result by the layer.", "結果に乗算します。")),
    ("SCREEN", bi("Screen", "スクリーン"), bi("Brightening blend similar to image editors.", "画像編集ソフトのスクリーンに近い明るくする合成です。")),
    ("OVERLAY", bi("Overlay", "オーバーレイ"), bi("Contrast boosting blend.", "コントラストを強める合成です。")),
    ("SOFT_LIGHT", bi("Soft Light", "ソフトライト"), bi("Soft contrast blend compatible with common PSD/Painter-style stacks.", "一般的なPSD/Painter系スタックに合わせた、柔らかいコントラスト合成です。")),
    ("HARD_LIGHT", bi("Hard Light", "ハードライト"), bi("Strong contrast blend where the top layer controls multiply or screen behavior.", "上のレイヤーが乗算/スクリーンの切替を制御する強いコントラスト合成です。")),
    ("COLOR_DODGE", bi("Color Dodge", "覆い焼きカラー"), bi("Brightens the result according to the source layer.", "ソースレイヤーに応じて結果を明るくします。")),
    ("COLOR_BURN", bi("Color Burn", "焼き込みカラー"), bi("Darkens the result according to the source layer.", "ソースレイヤーに応じて結果を暗くします。")),
    ("LINEAR_DODGE", bi("Linear Dodge", "覆い焼き（リニア）"), bi("Linear add blend used by many painting applications.", "多くのペイントアプリで使われる線形加算合成です。")),
    ("LINEAR_BURN", bi("Linear Burn", "焼き込み（リニア）"), bi("Linear darkening blend used by many painting applications.", "多くのペイントアプリで使われる線形焼き込み合成です。")),
    ("DIVIDE", bi("Divide", "除算"), bi("Divides the result below by the source layer where possible.", "可能な範囲で下の結果をソースレイヤーで除算します。")),
    ("INVERSE_DIVIDE", bi("Inverse Divide", "逆除算"), bi("Divides the source layer by the result below where possible.", "可能な範囲でソースレイヤーを下の結果で除算します。")),
    ("SUBTRACT", bi("Subtract", "減算"), bi("Subtracts the layer from the result.", "結果から減算します。")),
    ("INVERSE_SUBTRACT", bi("Inverse Subtract", "逆減算"), bi("Subtracts the result below from the source layer.", "ソースレイヤーから下の結果を減算します。")),
    ("DIFFERENCE", bi("Difference", "差の絶対値"), bi("Difference blend useful for masks and stylized looks.", "マスクやスタイライズ用途に便利な差分合成です。")),
    ("EXCLUSION", bi("Exclusion", "除外"), bi("Lower-contrast difference-style blend.", "差分に近い低コントラストの合成です。")),
    ("SIGNED_ADD", bi("Signed Addition", "符号付き加算"), bi("Signed Add/AddSub. Gray has no effect, darker values subtract, and brighter values add.", "符号付き加算です。グレーは無変化、暗い値は減算、明るい値は加算します。")),
    ("DARKEN", bi("Darken", "比較（暗）"), bi("Keeps the darker result.", "暗い方を保持します。")),
    ("LIGHTEN", bi("Lighten", "比較（明）"), bi("Keeps the lighter result.", "明るい方を保持します。")),
    ("VIVID_LIGHT", bi("Vivid Light", "ビビッドライト"), bi("Combines Color Burn and Color Dodge around middle gray.", "中間グレーを基準に焼き込みカラーと覆い焼きカラーを組み合わせます。")),
    ("LINEAR_LIGHT", bi("Linear Light", "リニアライト"), bi("Combines Linear Burn and Linear Dodge around middle gray.", "中間グレーを基準に焼き込み（リニア）と覆い焼き（リニア）を組み合わせます。")),
    ("PIN_LIGHT", bi("Pin Light", "ピンライト"), bi("Keeps darker or lighter extremes from the top layer and removes mid tones.", "上のレイヤーの暗部/明部の極端な値を残し、中間調を落とします。")),
    ("TINT", bi("Tint", "色相"), bi("HSV blend that keeps hue from the top layer and saturation/value from below.", "HSV合成です。上の色相を使い、彩度と明度は下の結果を保持します。")),
    ("SATURATION", bi("Saturation", "彩度"), bi("HSV blend that keeps saturation from the top layer and hue/value from below.", "HSV合成です。上の彩度を使い、色相と明度は下の結果を保持します。")),
    ("COLOR", bi("Color", "カラー"), bi("HSV blend that keeps hue/saturation from the top layer and value from below.", "HSV合成です。上の色相と彩度を使い、明度は下の結果を保持します。")),
    ("VALUE", bi("Value", "明度"), bi("HSV blend that keeps value/brightness from the top layer and hue/saturation from below.", "HSV合成です。上の明度を使い、色相と彩度は下の結果を保持します。")),
    ("NORMAL_MAP_COMBINE", bi("Normal Map Combine", "ノーマルマップ結合"), bi("Whiteout-style normal-map combination for normal channels.", "ノーマルチャンネル向けのホワイトアウト風ノーマル合成です。")),
    ("NORMAL_MAP_DETAIL", bi("Normal Map Detail", "ノーマルマップ詳細"), bi("Detail-oriented normal-map blending for preserving surface detail.", "面のディテール保持を重視するノーマルマップ合成です。")),
    ("NORMAL_MAP_INVERSE_DETAIL", bi("Normal Map Inverse Detail", "ノーマルマップ逆詳細"), bi("Inverse detail-oriented normal-map blending.", "逆方向のディテール保持ノーマルマップ合成です。")),
]


MASK_MODE_ITEMS = [
    ("NONE", "None", bi("Use the layer opacity only.", "レイヤー不透明度のみを使います。")),
    ("IMAGE", "Image", bi("Use a dedicated mask image.", "専用のマスク画像を使います。")),
    ("AO_MAP", "AO Map", bi("Use the baked ambient occlusion image as a mask.", "ベイクしたAO画像をマスクに使います。")),
    ("CURVATURE_MAP", "Curvature Map", bi("Use the curvature/pointiness map as a mask.", '曲率 / 尖り具合のマップをマスクに使います。')),
    ("THICKNESS_MAP", "Thickness Map", bi("Use the thickness approximation map as a mask.", "厚み近似マップをマスクに使います。")),
    ("POSITION_MAP", "Position Map", bi("Use the baked/generated position map as a mask.", "ベイク／生成した位置マップをマスクに使います。")),
    ("NORMAL_CULL", "Normal Cull", bi("Derive a groove / slope mask from the baked normal map, approximating normal-map culling workflows.", 'ベイク済みノーマルマップから溝・傾斜のマスクを作り、ノーマルマップによるカリングを近似します。')),
    ("VERTEX_COLOR", "Vertex Color", bi("Read a named vertex color or color attribute as a mask.", "指定した頂点カラー／カラー属性をマスクとして読みます。")),
    ("COLOR_ID", "Color ID", bi("Select a specific color from a color-attribute ID map, similar to material or color ID masks used in dedicated texturing tools.", '専用テクスチャツールのマテリアル / カラーIDマスクのように、カラー属性のIDマップから特定の色だけを選びます。')),
    ("ANCHOR", "Anchor", bi("Reference another layer channel similar to anchor points.", "アンカーポイントのように別レイヤーのチャンネルを参照します。")),
    ("NOISE", "Noise", bi("Use procedural noise as a mask.", "プロシージャルノイズをマスクに使います。")),
    ("GRUNGE", "Grunge", bi("Use a dirt / grunge procedural mask.", "汚れ・グランジ系の生成マスクを使います。")),
    ("SCRATCH", "Scratch", bi("Generate a thin anisotropic scratch mask that helps break up broad surfaces and roughness.", "広い面の単調さを崩す細い異方性スクラッチマスクを生成します。")),
    ("CELLS", "Cells", bi("Generate a chipped-cell / paint-breakup mask from Voronoi cells for stylized wear and material breakup.", 'ボロノイセルから塗膜の欠けや材質の割れに向くセル状のマスクを生成します。')),
    ("EDGE_WEAR", "Edge Wear", bi("Use a pointiness based edge wear mask.", '尖り具合を使ったエッジ摩耗マスクを使います。')),
]

MASK_CHANNEL_ITEMS = [
    ("LUMA", "Luma", bi("Convert the color to grayscale.", "色をグレースケールに変換します。")),
    ("R", "Red", bi("Use the red channel.", "赤チャンネルを使います。")),
    ("G", "Green", bi("Use the green channel.", "緑チャンネルを使います。")),
    ("B", "Blue", bi("Use the blue channel.", "青チャンネルを使います。")),
    ("A", "Alpha", bi("Use the alpha channel.", "アルファチャンネルを使います。")),
]

CHANNEL_ITEMS = [
    ("BASE_COLOR", "Base Color", bi("Diffuse / albedo color channel.", "ディフューズ／アルベド色チャンネルです。")),
    ("ROUGHNESS", "Roughness", bi("Surface micro roughness channel.", "表面の細かな粗さチャンネルです。")),
    ("METALLIC", "Metallic", bi("Metalness channel.", "メタルネスチャンネルです。")),
    ("NORMAL", "Normal", bi("Tangent space normal channel.", "タンジェント空間ノーマルチャンネルです。")),
    ("HEIGHT", "Height", bi("Height / bump / displacement channel.", "高さ／バンプ／ディスプレイスメント用チャンネルです。")),
    ("EMISSION", "Emission", bi("Emission color channel.", "発光色チャンネルです。")),
    ("ALPHA", "Alpha", bi("Opacity / transparency channel.", "不透明度／透明度チャンネルです。")),
    ("AO", "AO", bi("Ambient occlusion helper channel.", "アンビエントオクルージョン補助チャンネルです。")),
]

PAINT_CHANNEL_ITEMS = CHANNEL_ITEMS

MESH_MAP_ITEMS = [
    ("AO", "AO", bi("Bake an ambient occlusion image.", "AO画像をベイクします。")),
    ("NORMAL", "Normal", bi("Bake a tangent-space normal image.", "タンジェント空間ノーマル画像をベイクします。")),
    ("POSITION", "Position", bi("Bake a generated/object position style map.", "生成座標／オブジェクト位置風のマップをベイクします。")),
    ("CURVATURE", "Curvature", bi("Bake a pointiness based curvature approximation.", '尖り具合を使った曲率の近似をベイクします。')),
    ("THICKNESS", "Thickness", bi("Bake a thickness approximation based on ambient occlusion style sampling.", "AO系サンプリングを使った厚み近似をベイクします。")),
]

IMPORT_MODE_ITEMS = [
    ("NEW_LAYER", "New Layer", bi("Create a new layer from the imported PBR texture set.", "読み込んだPBRセットから新規レイヤーを作成します。")),
    ("ACTIVE_LAYER", "Active Layer", bi("Assign the imported textures to the active layer.", "読み込んだテクスチャをアクティブレイヤーへ割り当てます。")),
]

PROJECTION_ITEMS = [
    ("UV", "UV", bi("Use UV coordinates.", "UV座標を使います。")),
    ("BOX", "Box", bi("Use generated coordinates with box projection for seam friendly placement.", "継ぎ目に強いボックス投影を使います。")),
]


VECTOR_SHAPE_ITEMS = [
    ("PANEL_LINE", "Panel Line", bi("Create a crisp panel-line style strip that can be used as a decal or mask.", "デカールやマスクとして使える、くっきりしたパネルライン状の帯を作成します。")),
    ("STITCH", "Stitch", bi("Create repeated short diagonal marks suitable for seams and stitching details.", "縫い目やステッチ表現に向いた、短い斜線の繰り返し形状を作成します。")),
    ("STRIPES", "Stripes", bi("Create repeated stripes for trim sheets, tape, hazard lines or graphic bands.", "トリムシート、テープ、警告線、グラフィック帯に使える繰り返しストライプを作成します。")),
    ("CIRCLE", "Circle / Ring", bi("Create a circular or ring-shaped graphic useful for bolts, targets or labels.", "ボルト、ターゲット、ラベルなどに使いやすい円形・リング形状を作成します。")),
    ("BOLT", "Bolt / Rivet", bi("Create a small round bolt or rivet style stamp.", "小さな丸いボルト／リベット風スタンプを作成します。")),
    ("RECTANGLE", "Rectangle", bi("Create a rectangular plate or decal block useful for labels, vents and trims.", "ラベル、ベント、トリムに使いやすい長方形プレート形状を作成します。")),
    ("DIAMOND", "Diamond", bi("Create a diamond-shaped graphic suited for warning marks or stylized decals.", "警告マークやスタイライズドデカールに向く菱形グラフィックを作成します。")),
    ("CHEVRON", "Chevron", bi("Create a chevron arrow shape for military markings, stripes and directional accents.", "ミリタリーマーキング、ストライプ、方向アクセント向けのシェブロン形状を作成します。")),
    ("CROSS", "Cross", bi("Create a cross or plus sign shape for panels, signs and graphic helpers.", "パネル、サイン、グラフィック補助に使える十字形状を作成します。")),
]

VECTOR_DESTINATION_ITEMS = [
    ("NEW_DECAL", "New Decal Layer", bi("Create a new decal-style layer and assign the generated vector images to it.", "新しいデカール型レイヤーを作成し、生成したベクトル画像を割り当てます。")),
    ("ACTIVE_LAYER", "Active Layer", bi("Assign the generated vector images to the currently active layer.", "生成したベクトル画像を現在のアクティブレイヤーへ割り当てます。")),
]

DEFAULT_CHANNEL_ORDER = [
    "BASE_COLOR",
    "ROUGHNESS",
    "METALLIC",
    "NORMAL",
    "HEIGHT",
    "EMISSION",
    "ALPHA",
    "AO",
]

CHANNEL_INFO = {
    "BASE_COLOR": {
        "label": "Base Color",
        "suffix": "BaseColor",
        "icon": "COLOR",
        "socket_names": ["Base Color", "BaseColor"],
        "colorspace": "sRGB",
        "default_color": (0.8, 0.8, 0.8, 1.0),
    },
    "ROUGHNESS": {
        "label": "Roughness",
        "suffix": "Roughness",
        "icon": "MOD_NOISE",
        "socket_names": ["Roughness"],
        "colorspace": "Non-Color",
        "default_color": (0.5, 0.5, 0.5, 1.0),
    },
    "METALLIC": {
        "label": "Metallic",
        "suffix": "Metallic",
        "icon": "SHADING_TEXTURE",
        "socket_names": ["Metallic", "Metalness"],
        "colorspace": "Non-Color",
        "default_color": (0.0, 0.0, 0.0, 1.0),
    },
    "NORMAL": {
        "label": "Normal",
        "suffix": "Normal",
        "icon": "NORMALS_FACE",
        "socket_names": ["Normal"],
        "colorspace": "Non-Color",
        "default_color": (0.5, 0.5, 1.0, 1.0),
    },
    "HEIGHT": {
        "label": "Height",
        "suffix": "Height",
        "icon": "DRIVER_DISTANCE",
        "socket_names": ["Height", "Displacement"],
        "colorspace": "Non-Color",
        "default_color": (0.5, 0.5, 0.5, 1.0),
    },
    "EMISSION": {
        "label": "Emission",
        "suffix": "Emission",
        "icon": "LIGHT",
        "socket_names": ["Emission Color", "Emission"],
        "strength_socket_names": ["Emission Strength"],
        "colorspace": "sRGB",
        "default_color": (0.0, 0.0, 0.0, 1.0),
    },
    "ALPHA": {
        "label": "Alpha",
        "suffix": "Alpha",
        "icon": "IMAGE_ALPHA",
        "socket_names": ["Alpha"],
        "colorspace": "Non-Color",
        "default_color": (1.0, 1.0, 1.0, 1.0),
    },
    "AO": {
        "label": "AO",
        "suffix": "AO",
        "icon": "MATSPHERE",
        "socket_names": [],
        "colorspace": "Non-Color",
        "default_color": (1.0, 1.0, 1.0, 1.0),
    },
}

CHANNEL_IMPORT_KEYWORDS = {
    "BASE_COLOR": ["basecolor", "base_color", "albedo", "diffuse", "color", "col", "bc"],
    "ROUGHNESS": ["roughness", "rough", "rgh"],
    "METALLIC": ["metallic", "metalness", "metal", "mtl"],
    "NORMAL": ["normal", "nrm", "nor", "normalgl", "normaldx"],
    "HEIGHT": ["height", "disp", "displacement", "bump"],
    "EMISSION": ["emission", "emissive", "emit"],
    "ALPHA": ["alpha", "opacity", "transparency", "transparent", "opac"],
    "AO": ["ao", "occlusion", "ambientocclusion", "ambient_occlusion"],
    "MASK": ["mask", "opacitymask", "blendmask"],
}

DEFAULT_BAKE_MARGIN = 8
DEFAULT_TEXTURE_COLOR = (0.0, 0.0, 0.0, 0.0)
DEFAULT_FILL_COLOR = (0.8, 0.8, 0.8, 1.0)
DEFAULT_EMISSION_COLOR = (0.0, 0.0, 0.0, 1.0)
DEFAULT_VERTEX_COLOR_NAME = "Col"
DEFAULT_COLOR_ATTRIBUTE_NAME = "SPS_Color"
DEFAULT_UV_NAME = "UVMap"




MATERIAL_PRESET_ITEMS = [
    ("WORN_PAINTED_METAL", "Worn Painted Metal", bi("Creates a small smart-material stack with painted coat, exposed metal edges and dirt buildup.", "塗装層、露出した金属エッジ、汚れ堆積を組み合わせたスマートマテリアルスタックを作成します。")),
    ("DUSTY_PLASTIC", "Dusty Plastic", bi("Creates a plastic base with dusty cavity buildup and mild breakup for properties and hard-surface assets.", "プラスチック地に埃の堆積と軽い分解感を加えた、プロップやハードサーフェス向けスタックを作成します。")),
    ("EMISSIVE_DECAL", "Emissive Decal", bi("Creates a decal-style layer stack prepared for projected signs, labels or emissive panels.", "投影看板、ラベル、発光パネル向けのデカール型レイヤースタックを作成します。")),
]

BRUSH_PRESET_ITEMS = [
    ("PAINT", "Paint", bi("Balanced everyday paint brush preset.", "日常的な描画向けのバランス型ブラシプリセットです。")),
    ("DYNAMIC", "Dynamic Stroke", bi("Adds jitter, smoothing and pressure-friendly settings to mimic more organic strokes.", "ジッターやスムーズ化、筆圧向け設定を加えて、より有機的なストローク感を作ります。")),
    ("DECAL", "Decal / Stamp", bi("Sharper settings for stencil, decal and logo work.", "ステンシル、デカール、ロゴ作業向けのシャープな設定です。")),
    ("WEATHER", "Weather / Grunge", bi("Softer, more random settings for dirt and wear painting.", "汚れや摩耗向けの、柔らかくランダム性の高い設定です。")),
]

WORKFLOW_PROFILE_ITEMS = [
    ("GAME_ASSET", "Game Asset", bi("Tune the stack for compact real-time game-texture authoring with packed exports and non-UDIM defaults.", 'パック書き出しと非UDIM前提の、リアルタイム向けゲームアセット制作に合わせてスタックを調整します。')),
    ("VFX_UDIM", "VFX / UDIM", bi("Bias the stack toward float images, UDIM-friendly defaults and higher-fidelity export settings.", '浮動小数点画像、UDIM向け既定値、高精細な書き出し設定を重視した VFX / UDIM 向けに調整します。')),
    ("CONCEPT_VERTEX", "Concept / Vertex", bi("Favor quick concept iteration, projection helpers and vertex-color staging before final image bake-out.", "最終画像化前の素早いコンセプト反復、投影補助、頂点カラー下描きを重視した設定にします。")),
    ("REALTIME_BAKE", "Realtime Bake", bi("Prepare the stack for fast bake / export loops with conservative samples and game-ready defaults.", '低めのサンプル数とゲーム向け既定値で、ベイクと書き出しの素早い繰り返し向けに調整します。')),
    ("SMART_MASK_AUTHORING", 'Smart Mask Authoring', bi("Lean toward non-destructive PBR authoring with smart masks, anchor-driven detailing and packed exports.", "スマートマスク、アンカー駆動ディテール、パック書き出しを重視した非破壊PBR制作向けに寄せます。")),
    ("LARGE_PROJECTION_PAINT", 'Projection Paint Authoring', bi("Bias the stack toward projection-buffer editing, float images and large-format texture work.", '投影バッファ編集、浮動小数点画像、大判テクスチャ作業を重視したワークフローに調整します。')),
    ("BAKE_REVIEW_ITERATION", 'Bake Review Iteration', bi("Favor rapid bake-paint iteration with sync-point style rebake settings and stencil-friendly defaults.", '同期ポイント風の再ベイク設定とステンシル向け既定値で、ベイクと描画の素早い反復を重視します。')),
    ("HYBRID_HEIGHT_VERTEX", '3D Texture Hybrid', bi('Favor height, displacement preview, vertex-color staging and quick bake-back workflows inspired by 3D Texture.', '高さ、ディスプレイスプレビュー、頂点カラーの下描き、素早い焼き戻しを重視します。')),
    ("NODE_TEXTURE_AUTHORING", 'Node Texture Authoring', bi("Favor node-friendly float/data handling with a balanced GPU-minded texture workflow.", 'ノード向きの浮動小数点 / データ運用と、GPUを意識したバランス型のテクスチャワークフローを重視します。')),
]

WORKFLOW_PROFILE_LABELS = {item[0]: item[1] for item in WORKFLOW_PROFILE_ITEMS}

UI_LABELS = {
    "workspace": ("Workspace", "ワークスペース"),
    "brush": ("Brush", "ブラシ"),
    "layers": ("Layers", "レイヤー"),
    "mesh_maps": ("Mesh Maps", "メッシュマップ"),
    "utilities": ("Utilities", "ユーティリティ"),
    "quick_actions": ("Quick Actions", "クイック操作"),
    "paint_targets": ("Paint Targets", "ペイント対象"),
    "active_layer": ("Active Layer", "アクティブレイヤー"),
    "import_export": ("Import / IO", "インポート / 入出力"),
    "uv": ("UV", "UV"),
    "projection": ("Projection", "投影"),
    "cleanup": ("Cleanup", "クリーンアップ"),
    "projection_buffer": ("Projection Buffer", "投影バッファ"),
    "vertex_color": ("Vertex Color", "頂点カラー"),
    "paths": ("Paths", "パス"),
    "brush_presets": ("Brush Presets", "ブラシプリセット"),
    "mesh_tools": ("Mesh Tools", "メッシュツール"),
    "udim": ("UDIM", "UDIM"),
    "status": ("Status", "状態"),
    "smart_materials": ("Smart Materials", "スマートマテリアル"),
    "sprite_sheet": ("Sprite Sheet", "スプライトシート"),
    "sync_points": ("Sync Points", "同期ポイント"),
    "vector_shapes": ("Vector Shapes", "ベクトル形状"),
    "export": ("Export", "書き出し"),
    "workflow_profiles": ("Workflow Profiles", "ワークフロープロファイル"),
    "audit": ("Audit Report", "監査レポート"),
    "consolidate": ("Consolidate Textures", "テクスチャを集約"),
    "runtime_log": ("Runtime Log", "実行ログ"),
}
