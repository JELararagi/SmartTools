# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from array import array
from pathlib import Path, PureWindowsPath
import json
import os
import struct
import time
import uuid
import zlib
from typing import Iterable

import bpy


from .constants import DEFAULT_CHANNEL_ORDER
from .utils import layer_channel_image_attr, layer_channel_enabled_attr
from . import resource_quota as _sps_quota
from . import runtime_registry as _sps_runtime_registry

# All retained NumPy payloads share one strict count+real-byte LRU.  Cache keys
# contain only stable names, hashes, dimensions and integer revisions; values
# contain data-only arrays/metadata and never Blender RNA/Image/module objects.
# This replaces the historical independent 256+512+1152+768+256 MiB ceilings.
_IMAGE_ARRAY_CACHE = _sps_quota.cache('psd.image_array')
_IMAGE_PIXEL_REV_PROP = 'smart_paint_suite_pixel_revision'
_IMAGE_ARRAY_READ_SCOPE_DEPTH = 0
_IMAGE_ARRAY_READ_SCOPE_LEASE = ''
_IMAGE_ARRAY_READ_SCOPE_CACHE = _sps_quota.cache('psd.read_scope')
_PSD_RECORD_LOCAL_RGBA_CACHE = _sps_quota.cache('psd.record_local_rgba')


def _lazy_image_name_matches_record_name(image_name: str, record_name: str) -> bool:
    try:
        img_name = str(image_name or '')
        rec_name = str(record_name or '')
        if not img_name or not rec_name:
            return False
        def _strip_duplicate_suffix(value: str) -> str:
            try:
                head, dot, tail = str(value or '').rpartition('.')
                if dot and tail.isdigit() and len(tail) == 3:
                    return head
            except Exception:
                pass
            return str(value or '')

        def _compact(value: str) -> str:
            try:
                remove_chars = {'_', '\uff3f'}
                return ''.join(
                    ch for ch in str(value or '')
                    if (not ch.isspace()) and ch not in remove_chars
                )
            except Exception:
                return str(value or '')

        candidates = {img_name, _strip_duplicate_suffix(img_name)}
        for channel in DEFAULT_CHANNEL_ORDER:
            try:
                suffix = '_' + str(channel)
                for candidate in tuple(candidates):
                    if candidate.endswith(suffix):
                        candidates.add(candidate[:-len(suffix)])
            except Exception:
                pass
        for candidate in tuple(candidates):
            if candidate == rec_name or candidate.endswith('_' + rec_name):
                return True
            c_compact = _compact(candidate)
            r_compact = _compact(rec_name)
            if c_compact and r_compact and (c_compact == r_compact or c_compact.endswith(r_compact)):
                return True
    except Exception:
        pass
    return False


def _lazy_record_has_paintable_bounds(record: dict) -> bool:
    try:
        if not isinstance(record, dict):
            return False
        if bool(record.get('is_group', False)):
            return False
        left = int(record.get('left', 0) or 0)
        top = int(record.get('top', 0) or 0)
        right = int(record.get('right', 0) or 0)
        bottom = int(record.get('bottom', 0) or 0)
        if right <= left or bottom <= top:
            return False
        channel_data = record.get('channel_data', {}) or {}
        return bool(channel_data)
    except Exception:
        return False


def _lazy_find_name_matched_record(doc: dict, image_name: str, *, require_paintable: bool = True):
    try:
        layers = list((doc or {}).get('layers', []) or [])
        matches = []
        for candidate in layers:
            try:
                cname = str(candidate.get('name', '') or '')
                if not cname or not _lazy_image_name_matches_record_name(image_name, cname):
                    continue
                paintable = _lazy_record_has_paintable_bounds(candidate)
                if require_paintable and not paintable:
                    continue
                matches.append((0 if paintable else 1, int(candidate.get('record_index', 999999) or 999999), candidate))
            except Exception:
                continue
        if matches:
            return sorted(matches, key=lambda item: (item[0], item[1]))[0][2]
    except Exception:
        pass
    return None


# High-performance layer-stack engine toggle.  This is controlled by the
# crash-safe Operation > Optimization button.  It never registers keymaps or
# touches View3D UI state; it only changes Smart Paint's own commit heuristics.
def _sps_layer_fast_mode_active(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is None:
            return False
        names = (
            'sps_operation_optimization_active_v1950',
            'sps_layer_stack_fast_mode_v1950',
            'sps_operation_optimization_active_v1944',
            'sps_layer_stack_fast_mode_v1944',
        )
        for name in names:
            try:
                if bool(getattr(scene, name, False)) or bool(scene.get(name, False)):
                    return True
            except Exception:
                pass
        try:
            from . import performance_governor as _sps_perf
            return bool(_sps_perf.active())
        except Exception:
            return False
    except (AttributeError, RuntimeError, ReferenceError, TypeError, ValueError):
        return False


def _current_paint_operator_token(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        ops_all = list(getattr(wm, 'operators', ()) or []) if wm is not None else []
        ops = ops_all[-12:]
        for rev_index, op in enumerate(reversed(ops)):
            bid = str(getattr(op, 'bl_idname', '') or '').upper()
            if any(token in bid for token in ('PAINT_OT_IMAGE_PAINT', 'PAINT_OT_TEXTURE_PAINT', 'PAINT_OT_BRUSH_STROKE', 'PAINT_OT_SAMPLE_COLOR', 'IMAGE_PAINT', 'TEXTURE_PAINT', 'BRUSH_STROKE')):
                return f'{len(ops_all)}:{len(ops)-1-rev_index}:{bid}'
    except Exception:
        pass
    return ''


def _recent_operator_was_paint(context=None) -> bool:
    """Return True when Blender reports a recent native paint operator."""
    return bool(_current_paint_operator_token(context))


def _active_texture_paint_brush_is_eraser(context=None) -> bool:
    """Return True when the active Image Paint brush is an eraser/alpha erase brush.

    Blender writes eraser strokes into the public document texture in Material
    mode.  Those strokes must be committed back to the selected Smart Paint
    layer immediately; otherwise the flattened master can look as if all layers
    were erased.  This helper is intentionally cheap and only inspects the
    current brush metadata.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        brush = getattr(ip, 'brush', None) if ip is not None else None
        if brush is None:
            return False
        values = []
        for attr in ('blend', 'image_tool', 'mode', 'name'):
            try:
                values.append(str(getattr(brush, attr, '') or '').upper())
            except Exception:
                pass
        try:
            ws = getattr(ctx, 'workspace', None)
            tools = getattr(ws, 'tools', None) if ws is not None else None
            if tools is not None:
                for mode_name in ('TEXTURE_PAINT', 'IMAGE_PAINT'):
                    try:
                        tool = tools.from_space_view3d_mode(mode_name, create=False)
                        if tool is not None:
                            values.append(str(getattr(tool, 'idname', '') or '').upper())
                            values.append(str(getattr(tool, 'label', '') or '').upper())
                    except Exception:
                        pass
                try:
                    tool = tools.from_space_image_mode('PAINT', create=False)
                    if tool is not None:
                        values.append(str(getattr(tool, 'idname', '') or '').upper())
                        values.append(str(getattr(tool, 'label', '') or '').upper())
                except Exception:
                    pass
        except Exception:
            pass
        joined = ' '.join(values)
        return any(token in joined for token in ('ERASE', 'ERASER', 'ALPHA_ERASE', 'ERASE_ALPHA', 'ERASE ALPHA', 'ALPHA ERASE', '消しゴム', '消去'))
    except Exception:
        return False


def _active_texture_paint_brush_rgb(context=None):
    """Return the current Texture Paint brush RGB when it is safe to use.

    Blender paints the composited document image in Material mode, so the private
    layer alpha often has to be reconstructed.  When the active brush colour is
    available, reconstruct source-over coverage from the colour instead of
    guessing alpha from contrast.  This preserves soft brush alpha/colour after
    layer visibility toggles and PSD saves.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        brush = getattr(ip, 'brush', None) if ip is not None else None
        if brush is None:
            return None
        try:
            if _active_texture_paint_brush_is_eraser(ctx):
                return None
        except Exception:
            pass
        col = getattr(brush, 'color', None)
        if col is None:
            return None
        rgb = tuple(float(col[i]) for i in range(3))
        if not all((v == v and abs(v) < 1.0e6) for v in rgb):
            return None
        return tuple(max(0.0, min(1.0, v)) for v in rgb)
    except Exception:
        return None




def _rgb_tuple_or_none(value):
    try:
        if value is None or len(value) < 3:
            return None
        rgb = tuple(max(0.0, min(1.0, float(value[i]))) for i in range(3))
        if not all((v == v and abs(v) < 1.0e6) for v in rgb):
            return None
        return rgb
    except Exception:
        return None


def _rgb_saturation(rgb) -> float:
    try:
        return float(max(rgb[:3]) - min(rgb[:3]))
    except Exception:
        return 0.0


def _brush_rgb_for_layer_delta(image=None, context=None):
    """Current or remembered brush/source RGB for stable master-delta recovery.

    Visibility toggles often run after Blender has already switched the active
    tool/brush context.  If a previous commit stored the source colour on the
    private layer, that colour is more authoritative than the current UI brush.
    This prevents a later default gray/white brush from being used to reinterpret
    an already coloured master delta as monochrome paint.
    """
    remembered = None
    if image is not None:
        for key in ('smart_paint_suite_last_source_rgb', 'smart_paint_suite_test_brush_rgb', 'smart_paint_suite_inferred_source_rgb'):
            try:
                remembered = _rgb_tuple_or_none(image.get(key, None))
                if remembered is not None:
                    break
            except Exception:
                remembered = None
    try:
        brush_rgb = _active_texture_paint_brush_rgb(context)
    except Exception:
        brush_rgb = None
    brush_rgb = _rgb_tuple_or_none(brush_rgb)
    # Prefer remembered non-gray source colour.  A gray current brush is often an
    # unrelated UI default during layer enable/disable callbacks.
    try:
        if remembered is not None and _rgb_saturation(remembered) > max(0.02, _rgb_saturation(brush_rgb or (0.0, 0.0, 0.0)) * 0.35):
            return remembered
    except Exception:
        pass
    return brush_rgb if brush_rgb is not None else remembered

def _mark_layer_dirty_bbox_from_rows(image, rows) -> None:
    try:
        np = _np_module()
        if image is None or np is None:
            return
        rows = np.asarray(rows, dtype=np.int64).reshape((-1,))
        if rows.size <= 0:
            return
        try:
            w, h = _image_size(image)
        except Exception:
            w, h = int(image.size[0]), int(image.size[1])
        w = int(w); h = int(h)
        if w <= 0 or h <= 0:
            return
        rows = rows[np.logical_and(rows >= 0, rows < w * h)]
        if rows.size <= 0:
            return
        xs = rows % w
        ys = rows // w
        x0 = int(xs.min()); x1 = int(xs.max()) + 1
        y0 = int(ys.min()); y1 = int(ys.max()) + 1
        old = None
        try:
            old = image.get('smart_paint_suite_dirty_bbox', None)
        except Exception:
            old = None
        if old is not None and len(old) >= 4:
            try:
                x0 = min(x0, int(old[0])); y0 = min(y0, int(old[1])); x1 = max(x1, int(old[2])); y1 = max(y1, int(old[3]))
            except Exception:
                pass
        image['smart_paint_suite_dirty_bbox'] = (max(0, x0), max(0, y0), min(w, x1), min(h, y1))
    except Exception:
        pass


def _apply_known_brush_color_to_layer_rows(image, layer_arr, rows, baseline_rgb, current_rgb, old_rgb, old_alpha, *, baseline_alpha=None, current_alpha=None, tolerance: float = 1.0 / 4096.0, context=None):
    """Apply a visible-master brush delta to active-layer rows while preserving colour and soft alpha.

    The primary path uses Blender's current Texture Paint brush colour. When the
    brush colour is unavailable, infer a stable single source colour from the high
    coverage part of the stroke instead of solving each pixel independently. This
    avoids storing mathematically equivalent but visually unstable RGB/alpha pairs
    that change after visibility toggles or PSD round-trips.
    """
    try:
        np = _np_module()
        if np is None:
            return None
        rows = np.asarray(rows, dtype=np.int64).reshape((-1,))
        if rows.size <= 0:
            return np.zeros((0,), dtype=bool)
        B = np.clip(np.asarray(baseline_rgb, dtype=np.float32), 0.0, 1.0)
        T = np.clip(np.asarray(current_rgb, dtype=np.float32), 0.0, 1.0)
        old_rgb = np.clip(np.asarray(old_rgb, dtype=np.float32), 0.0, 1.0)
        old_alpha = np.clip(np.asarray(old_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
        if B.shape != T.shape or B.shape[0] != rows.shape[0]:
            return None
        eps = max(1.0 / 4096.0, 1.0e-6)
        change_tol = max(float(tolerance), eps)
        alpha_locked = None
        alpha_coverage = None
        try:
            if baseline_alpha is not None and current_alpha is not None:
                ba = np.clip(np.asarray(baseline_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
                ca = np.clip(np.asarray(current_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
                if ba.shape[0] == rows.shape[0] and ca.shape[0] == rows.shape[0]:
                    # When Blender's paint target stores straight RGB plus a soft
                    # alpha edge, RGB can remain the full brush colour even where
                    # coverage is 0.1.  Trust the master alpha in that case;
                    # otherwise soft edges are reconstructed as opaque pixels and
                    # later save/reload shows dark/black borders.
                    denom_a = np.maximum(1.0 - ba, eps)
                    cov_a = np.clip((ca - ba) / denom_a, 0.0, 1.0).astype(np.float32, copy=False)
                    alpha_locked = np.logical_and(cov_a > eps, np.logical_and(ca < (1.0 - eps), ba < (1.0 - eps)))
                    alpha_coverage = cov_a
        except Exception:
            alpha_locked = None
            alpha_coverage = None

        brush_rgb = _brush_rgb_for_layer_delta(image, context)

        diff = T - B
        lighten = np.where(diff > 0.0, diff / np.maximum(1.0 - B, eps), 0.0)
        darken = np.where(diff < 0.0, (-diff) / np.maximum(B, eps), 0.0)
        cov_guess = np.clip(np.max(np.maximum(lighten, darken), axis=1), 0.0, 1.0).astype(np.float32, copy=False)

        inferred = False
        if brush_rgb is None:
            try:
                core = cov_guess > max(8.0 / 255.0, eps * 4.0)
                if bool(np.any(core)):
                    src_est = (T[core] - B[core] * (1.0 - cov_guess[core, None])) / np.maximum(cov_guess[core, None], eps)
                    src_est = np.clip(src_est, 0.0, 1.0)
                    spread = np.max(np.abs(T[core] - B[core]), axis=1)
                    good = spread > max(2.0 / 255.0, eps)
                    if bool(np.any(good)):
                        brush_rgb = tuple(float(v) for v in np.median(src_est[good], axis=0))
                        inferred = True
            except Exception:
                brush_rgb = None

        if brush_rgb is None:
            return None

        C = np.clip(np.asarray(brush_rgb, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
        denom = C - B
        valid = np.abs(denom) > eps
        with np.errstate(divide='ignore', invalid='ignore'):
            ratio = (T - B) / np.where(valid, denom, 1.0)
        valid = np.logical_and(valid, np.logical_and(ratio >= -0.05, ratio <= 1.05))
        valid_count = np.sum(valid, axis=1)
        ratio_clamped = np.clip(ratio, 0.0, 1.0)
        coverage_from_brush = np.sum(np.where(valid, ratio_clamped, 0.0), axis=1) / np.maximum(valid_count.astype(np.float32), 1.0)
        coverage = np.where(valid_count > 0, coverage_from_brush, cov_guess)
        coverage = np.clip(coverage, 0.0, 1.0)
        # Do not inflate antialias/pressure coverage from the dirty threshold.
        # The previous max(cov_guess, 2/255) fallback changed soft brush
        # gradients on save and visibility toggles.
        try:
            if alpha_locked is not None and alpha_coverage is not None and bool(np.any(alpha_locked)):
                coverage[alpha_locked] = np.clip(alpha_coverage[alpha_locked], 0.0, 1.0)
        except Exception:
            pass

        # A stale gray/default brush can accidentally validate on one weak
        # channel, then recolour every changed row as monochrome.  Only the rows
        # whose master RGB can be reconstructed by this single source colour are
        # handled here; the remaining rows fall back to the generic solver.
        recon = B + np.clip(coverage, 0.0, 1.0)[:, None] * (C - B)
        recon_err = np.max(np.abs(recon - T), axis=1)
        confident = np.logical_and(valid_count > 0, recon_err <= max(change_tol * 0.5, eps * 8.0))
        if bool(np.any(confident)) and not bool(np.all(confident)):
            try:
                strong = cov_guess > max(12.0 / 255.0, eps * 8.0)
                if bool(np.any(strong)):
                    inferred_saturation = _rgb_saturation(tuple(float(v) for v in C.reshape((3,))))
                    target_chroma = np.max(T[strong], axis=1) - np.min(T[strong], axis=1)
                    if inferred_saturation <= 0.025 and float(np.median(target_chroma)) > 0.035:
                        confident[:] = False
            except Exception:
                pass
        try:
            if alpha_locked is not None and bool(np.any(alpha_locked)):
                confident = np.logical_or(confident, alpha_locked)
        except Exception:
            pass
        handled = np.logical_and(coverage > (0.5 / 255.0), confident)
        if not bool(np.any(handled)):
            return handled
        wr = rows[handled]
        cov = np.clip(coverage[handled], 0.0, 1.0).astype(np.float32, copy=False)
        oa = old_alpha[handled]
        new_alpha = np.clip(cov + oa * (1.0 - cov), 0.0, 1.0)
        premul = C * cov[:, None] + old_rgb[handled] * oa[:, None] * (1.0 - cov[:, None])
        new_rgb = premul / np.maximum(new_alpha[:, None], 1.0e-6)
        layer_arr[wr, :3] = np.clip(new_rgb, 0.0, 1.0)
        layer_arr[wr, 3] = new_alpha
        try:
            _mark_layer_dirty_bbox_from_rows(image, wr)
        except Exception:
            pass
        try:
            if image is not None:
                image['smart_paint_suite_dirty_from_master'] = True
                image['smart_paint_suite_alpha_authoritative'] = True
                image['smart_paint_suite_known_brush_color_commit'] = True
                if inferred:
                    image['smart_paint_suite_inferred_brush_color_commit'] = True
                try:
                    image['smart_paint_suite_last_source_rgb'] = tuple(float(v) for v in brush_rgb[:3])
                    if inferred:
                        image['smart_paint_suite_inferred_source_rgb'] = tuple(float(v) for v in brush_rgb[:3])
                except Exception:
                    pass
                for _prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                    try:
                        if _prop in image:
                            del image[_prop]
                    except Exception:
                        pass
        except Exception:
            pass
        return handled
    except Exception:
        return None



def _sps_image_array_np_no_clip(image):
    """Read Image.pixels into an Nx4 float32 array without extra clip/copy passes."""
    np = _np_module()
    if np is None or image is None:
        return None
    try:
        w, h = _image_size(image)
        if int(w) <= 0 or int(h) <= 0:
            return None
        actual_w = int(image.size[0]); actual_h = int(image.size[1])
        if int(actual_w) != int(w) or int(actual_h) != int(h):
            return _image_array_np(image, use_cache=False)
        buf = np.empty(int(w) * int(h) * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
        return buf.reshape((int(w) * int(h), 4))
    except Exception:
        return None


def _sps_infer_source_rgb_for_master_patch(image, session, baseline_rgb, current_rgb, coverage_hint=None):
    np = _np_module()
    if np is None:
        return None
    candidate_sources = []
    explicit_image_rgb = None
    try:
        if image is not None:
            for _key in ('smart_paint_suite_last_source_rgb', 'smart_paint_suite_test_brush_rgb', 'smart_paint_suite_inferred_source_rgb', 'smart_paint_suite_last_brush_color'):
                explicit_image_rgb = _rgb_tuple_or_none(image.get(_key, None))
                if explicit_image_rgb is not None:
                    break
    except Exception:
        explicit_image_rgb = None
    # Stale session brush colour captured at Add Layer must not win over the
    # actual current/remembered stroke colour at the toggle/save boundary.
    for raw in (
        explicit_image_rgb,
        _brush_rgb_for_layer_delta(image, getattr(bpy, 'context', None)),
        _rgb_tuple_or_none((session or {}).get('brush_rgb', None)) if isinstance(session, dict) else None,
    ):
        try:
            if raw is not None:
                cand = np.clip(np.asarray(raw[:3], dtype=np.float32).reshape((3,)), 0.0, 1.0)
                # Black/dark paint is valid; do not discard it here. Candidate
                # validation below decides whether it matches the visible delta.
                if not any(bool(np.allclose(cand, old, atol=1.0/1024.0)) for old in candidate_sources):
                    candidate_sources.append(cand)
        except Exception:
            pass
    try:
        B = np.clip(np.asarray(baseline_rgb, dtype=np.float32), 0.0, 1.0)
        T = np.clip(np.asarray(current_rgb, dtype=np.float32), 0.0, 1.0)
        if B.shape != T.shape or B.size <= 0:
            return None
        eps = 1.0 / 4096.0
        if coverage_hint is not None:
            cov = np.clip(np.asarray(coverage_hint, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
        else:
            diff = T - B
            lighten = np.where(diff > 0.0, diff / np.maximum(1.0 - B, eps), 0.0)
            darken = np.where(diff < 0.0, (-diff) / np.maximum(B, eps), 0.0)
            cov = np.clip(np.max(np.maximum(lighten, darken), axis=1), 0.0, 1.0)

        # Brush colour hints are validated against the actual visible-master
        # delta.  This prevents the current tool colour from recolouring a stroke
        # that was already painted with a different colour before the layer toggle.
        changed_mag = np.max(np.abs(T - B), axis=1)
        changed_rows = changed_mag > max(eps, 1.0 / 2048.0)
        for cand in candidate_sources:
            try:
                C = np.clip(np.asarray(cand, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
                denom = C - B
                valid = np.abs(denom) > eps
                with np.errstate(divide='ignore', invalid='ignore'):
                    ratio = (T - B) / np.where(valid, denom, 1.0)
                valid = np.logical_and(valid, np.logical_and(ratio >= -0.08, ratio <= 1.08))
                valid_count = np.sum(valid, axis=1)
                cov_c = np.sum(np.where(valid, np.clip(ratio, 0.0, 1.0), 0.0), axis=1) / np.maximum(valid_count.astype(np.float32), 1.0)
                usable = np.logical_and(changed_rows, valid_count > 0)
                if not bool(np.any(usable)):
                    continue
                recon = B[usable] + cov_c[usable, None] * (C - B[usable])
                err = np.max(np.abs(recon - T[usable]), axis=1)
                if int(err.size) >= 1 and float(np.median(err)) <= (6.0 / 255.0) and float(np.percentile(err, 90)) <= (18.0 / 255.0):
                    return C.reshape((3,)).astype(np.float32)
            except Exception:
                pass

        hi = np.logical_and(cov > max(0.30, float(np.max(cov)) * 0.55 if cov.size else 0.30), np.max(T, axis=1) > (8.0 / 255.0))
        if not bool(np.any(hi)):
            hi = np.max(T, axis=1) > max(12.0 / 255.0, float(np.percentile(np.max(T, axis=1), 90)) if T.shape[0] else 12.0/255.0)
        if bool(np.any(hi)):
            src = (T[hi] - B[hi] * (1.0 - cov[hi, None])) / np.maximum(cov[hi, None], eps)
            src = np.clip(src, 0.0, 1.0)
            good = np.max(src, axis=1) > (4.0 / 255.0)
            if bool(np.any(good)):
                return np.clip(np.median(src[good], axis=0), 0.0, 1.0).astype(np.float32)
        nz = np.max(T, axis=1) > (8.0 / 255.0)
        if bool(np.any(nz)):
            return np.clip(np.median(T[nz], axis=0), 0.0, 1.0).astype(np.float32)
        if candidate_sources:
            return np.clip(np.asarray(candidate_sources[0], dtype=np.float32).reshape((3,)), 0.0, 1.0)
    except Exception:
        return None
    return None

def _sps_propagate_dark_edge_coverage(coverage2, dark2, valid2):
    np = _np_module()
    if np is None:
        return coverage2
    try:
        cov = np.asarray(coverage2, dtype=np.float32).copy()
        need = np.asarray(dark2, dtype=bool).copy()
        valid = np.asarray(valid2, dtype=bool).copy()
        if not bool(np.any(need)) or not bool(np.any(valid)):
            return cov
        for _ in range(12):
            if not bool(np.any(need)):
                break
            acc = np.zeros_like(cov, dtype=np.float32)
            cnt = np.zeros_like(cov, dtype=np.float32)
            h, w = cov.shape
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dx == 0 and dy == 0:
                        continue
                    sy0 = max(0, -dy); sy1 = h - max(0, dy)
                    sx0 = max(0, -dx); sx1 = w - max(0, dx)
                    dy0 = max(0, dy); dy1 = dy0 + (sy1 - sy0)
                    dx0 = max(0, dx); dx1 = dx0 + (sx1 - sx0)
                    if sy1 <= sy0 or sx1 <= sx0:
                        continue
                    m = valid[sy0:sy1, sx0:sx1]
                    if not bool(np.any(m)):
                        continue
                    acc[dy0:dy1, dx0:dx1] += cov[sy0:sy1, sx0:sx1] * m.astype(np.float32)
                    cnt[dy0:dy1, dx0:dx1] += m.astype(np.float32)
            fill = np.logical_and(need, cnt > 0.0)
            if not bool(np.any(fill)):
                break
            cov[fill] = np.clip(acc[fill] / np.maximum(cnt[fill], 1.0), 0.02, 1.0)
            valid[fill] = True
            need[fill] = False
        if bool(np.any(need)):
            try:
                fallback = float(np.median(cov[valid])) if bool(np.any(valid)) else 0.18
            except Exception:
                fallback = 0.18
            cov[need] = np.clip(min(max(fallback, 0.04), 0.35), 0.0, 1.0)
        return cov
    except Exception:
        return coverage2


def _sps_store_sparse_top_normal_master_delta(material, channel: str, layer_id: str, baseline, current, rows=None, *, session=None, tolerance: float = 1.0 / 4096.0) -> bool:
    """Store a bounded top-normal visible-master brush delta as an authoritative sparse layer patch.

    This avoids materializing/writing an entire 2K/4K lazy paint layer during a
    visibility toggle.  The patch stores straight RGB and alpha separately; black
    alpha-edge pixels from Blender's public paint buffer are converted to coloured
    straight-RGB coverage instead of being saved as black paint.
    """
    np = _np_module()
    if np is None or material is None or baseline is None or current is None:
        return False
    try:
        channel = _safe_channel(channel)
        layer, image = _layer_image_for_session(material, str(layer_id or ''), channel)
        if layer is None or image is None:
            return False
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        mw, mh = _image_size(master)
        if int(mw) <= 0 or int(mh) <= 0:
            return False
        baseline = np.asarray(baseline, dtype=np.float32).reshape((-1, 4))
        current = np.asarray(current, dtype=np.float32).reshape((-1, 4))
        if baseline.shape != current.shape or baseline.shape[0] != int(mw) * int(mh):
            return False
        # Sparse patch path is only for memory-saving blank/proxy layers or layers
        # already represented by an authoritative sparse patch.  Fully materialized
        # user layers continue through the normal inverse solver below.
        try:
            iw = int(image.size[0]); ih = int(image.size[1])
            sparse_candidate = bool(
                image.get('smart_paint_suite_lazy_blank_layer', False)
                or image.get('smart_paint_suite_intentionally_empty', False)
                or image.get('smart_paint_suite_authoritative_sparse_rgba_patch', False)
                or (iw * ih <= 4 and int(image.get('smart_paint_suite_lazy_width', 0) or 0) > 1)
            )
        except Exception:
            sparse_candidate = True
        if not bool(sparse_candidate):
            return False
        try:
            # Sparse visible-master commits should never materialize the imported
            # PSD stack just to identify the active layer.  Use the RNA stack
            # metadata directly; for this fast path we only accept a normal,
            # non-clipped layer with no visible layer above it.
            settings_raw = getattr(material, 'smart_paint_suite', None)
            raw_layers = list(getattr(settings_raw, 'layers', ()) or [])
            raw_idx = -1
            raw_layer = None
            for _ri, _ly in enumerate(raw_layers):
                try:
                    if str(getattr(_ly, 'layer_id', '') or '') == str(layer_id or ''):
                        raw_idx = int(_ri)
                        raw_layer = _ly
                        break
                except Exception:
                    pass
            if raw_layer is None:
                return False
            _mode_raw = str(getattr(raw_layer, 'blend_mode', 'MIX') or 'MIX').upper()
            if _mode_raw not in {'MIX', 'NORMAL'}:
                return False
            if bool(getattr(raw_layer, 'clip_to_below', False)) or bool(getattr(raw_layer, 'background', False)) or bool(getattr(raw_layer, 'is_group', False)):
                return False
            _enabled_attr_raw = layer_channel_enabled_attr(channel)
            for _upper_raw in raw_layers[raw_idx + 1:]:
                try:
                    if bool(getattr(_upper_raw, 'enabled', True)) and bool(getattr(_upper_raw, _enabled_attr_raw, True)) and float(getattr(_upper_raw, 'opacity', 1.0) or 0.0) > 1.0e-6:
                        return False
                except Exception:
                    return False
        except Exception:
            return False
        tol = max(float(tolerance), 1.0 / 4096.0)
        solve_eps = max(1.0 / 4096.0, 1.0e-6)
        if rows is None:
            delta = np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1)
            rows = np.nonzero(delta > tol)[0]
        rows = np.asarray(rows, dtype=np.int64).reshape((-1,))
        rows = rows[np.logical_and(rows >= 0, rows < int(mw) * int(mh))]
        if rows.size <= 0:
            return False
        if rows.size > max(262144, int(mw) * int(mh) * 0.35):
            return False
        xs = rows % int(mw); ys = rows // int(mw)
        pad = 1
        x0 = max(0, int(xs.min()) - pad); x1 = min(int(mw), int(xs.max()) + pad + 1)
        y0 = max(0, int(ys.min()) - pad); y1 = min(int(mh), int(ys.max()) + pad + 1)
        if x1 <= x0 or y1 <= y0:
            return False
        bw = int(x1 - x0); bh = int(y1 - y0)
        local_rows = ((ys - y0) * bw + (xs - x0)).astype(np.int64, copy=False)
        # JELararagi 1.9.184: sparse top-normal commits must preserve the
        # actual visible document colour.  The previous sparse path inferred a
        # single brush colour plus coverage from the flattened master; for a new
        # layer over an opaque lower projection that can serialize as
        # low-alpha/dark RGB, so toggling the layer changes the visible colour.
        # Store each changed visible-master row exactly, and clear rows only when
        # the same sparse patch already owned alpha there and Blender wrote the
        # document clear colour (eraser-style result).
        try:
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            clear_rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
        except Exception:
            clear_rgba = (1.0, 1.0, 1.0, 0.0)
        try:
            union_x0, union_y0, union_x1, union_y1 = x0, y0, x1, y1
            old_crop = None
            old_box = _sps_parse_bbox4(image.get('smart_paint_suite_sparse_rgba_patch_bbox', None))
            if old_box is not None and str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or ''):
                try:
                    import base64 as _sps_b64_exact, zlib as _sps_zlib_exact
                    ox0, oy0, ox1, oy1 = old_box
                    ox0 = max(0, min(int(mw), ox0)); ox1 = max(0, min(int(mw), ox1)); oy0 = max(0, min(int(mh), oy0)); oy1 = max(0, min(int(mh), oy1))
                    raw_old = _sps_zlib_exact.decompress(_sps_b64_exact.b64decode(str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '').encode('ascii')))
                    old_crop = np.frombuffer(raw_old, dtype=np.float32).reshape((oy1 - oy0, ox1 - ox0, 4)).copy()
                    union_x0 = min(union_x0, ox0); union_y0 = min(union_y0, oy0); union_x1 = max(union_x1, ox1); union_y1 = max(union_y1, oy1)
                    old_box = (ox0, oy0, ox1, oy1)
                except Exception:
                    old_crop = None; old_box = None
            uw = int(union_x1 - union_x0); uh = int(union_y1 - union_y0)
            if uw > 0 and uh > 0:
                patch_exact = np.empty((uh, uw, 4), dtype=np.float32)
                patch_exact[:, :, 0] = clear_rgba[0]; patch_exact[:, :, 1] = clear_rgba[1]; patch_exact[:, :, 2] = clear_rgba[2]; patch_exact[:, :, 3] = clear_rgba[3]
                if old_crop is not None and old_box is not None:
                    ox0, oy0, ox1, oy1 = old_box
                    patch_exact[oy0-union_y0:oy1-union_y0, ox0-union_x0:ox1-union_x0, :] = np.clip(old_crop, 0.0, 1.0)
                yy_exact = (rows // int(mw)) - union_y0
                xx_exact = (rows % int(mw)) - union_x0
                old_alpha_exact = np.clip(patch_exact[yy_exact, xx_exact, 3], 0.0, 1.0)
                target_exact = np.clip(current[rows, :4], 0.0, 1.0)
                try:
                    clear_rgb_exact = np.asarray(clear_rgba[:3], dtype=np.float32).reshape((1, 3))
                    target_rgb_exact = target_exact[:, :3]
                    clear_like_exact = np.logical_or(
                        np.max(np.abs(target_rgb_exact - clear_rgb_exact), axis=1) <= max(8.0 / 255.0, tol),
                        np.logical_or(
                            np.max(np.abs(target_rgb_exact - 1.0), axis=1) <= max(8.0 / 255.0, tol),
                            np.max(np.abs(target_rgb_exact - 0.0), axis=1) <= max(8.0 / 255.0, tol),
                        ),
                    )
                except Exception:
                    clear_like_exact = np.zeros((rows.shape[0],), dtype=bool)
                try:
                    import time as _sps_time_exact
                    _last_clear_exact = float(image.get('smart_paint_suite_exact_top_clear_commit_stamp', 0.0) or 0.0)
                    _recent_clear_duplicate = bool(image.get('smart_paint_suite_exact_top_clear_commit', False)) and (float(_sps_time_exact.time()) - _last_clear_exact) <= 2.0
                except Exception:
                    _recent_clear_duplicate = False
                erase_like_exact = np.logical_and(clear_like_exact, np.logical_or(old_alpha_exact > (1.0 / 4096.0), _recent_clear_duplicate))
                if bool(np.any(erase_like_exact)):
                    patch_exact[yy_exact[erase_like_exact], xx_exact[erase_like_exact], 0] = clear_rgba[0]
                    patch_exact[yy_exact[erase_like_exact], xx_exact[erase_like_exact], 1] = clear_rgba[1]
                    patch_exact[yy_exact[erase_like_exact], xx_exact[erase_like_exact], 2] = clear_rgba[2]
                    patch_exact[yy_exact[erase_like_exact], xx_exact[erase_like_exact], 3] = 0.0
                paint_like_exact = np.logical_not(erase_like_exact)
                if bool(np.any(paint_like_exact)):
                    patch_exact[yy_exact[paint_like_exact], xx_exact[paint_like_exact], :] = target_exact[paint_like_exact, :]
                import base64 as _sps_b64_exact2, zlib as _sps_zlib_exact2
                raw_exact = _sps_zlib_exact2.compress(np.ascontiguousarray(patch_exact.reshape((-1, 4)), dtype=np.float32).tobytes(), 1)
                box_exact = (int(union_x0), int(union_y0), int(union_x1), int(union_y1))
                image['smart_paint_suite_dirty_bbox'] = box_exact
                image['smart_paint_suite_sparse_rgba_patch_bbox'] = box_exact
                image['smart_paint_suite_sparse_rgba_patch_b64'] = _sps_b64_exact2.b64encode(raw_exact).decode('ascii')
                image['smart_paint_suite_authoritative_sparse_rgba_patch'] = True
                image['smart_paint_suite_live_save_patch_v172'] = True
                image['smart_paint_suite_dirty_from_master'] = True
                image['smart_paint_suite_alpha_authoritative'] = True
                image['smart_paint_suite_painted_since_last_projection'] = True
                image['smart_paint_suite_exact_top_sparse_commit'] = True
                image['smart_paint_suite_exact_top_visible_commit'] = True
                if bool(np.any(erase_like_exact)):
                    image['smart_paint_suite_exact_top_clear_commit'] = True
                    try:
                        import time as _sps_time_exact2
                        image['smart_paint_suite_exact_top_clear_commit_stamp'] = float(_sps_time_exact2.time())
                    except Exception:
                        pass
                elif bool(np.any(paint_like_exact)):
                    try:
                        if 'smart_paint_suite_exact_top_clear_commit' in image:
                            del image['smart_paint_suite_exact_top_clear_commit']
                        if 'smart_paint_suite_exact_top_clear_commit_stamp' in image:
                            del image['smart_paint_suite_exact_top_clear_commit_stamp']
                    except Exception:
                        pass
                try:
                    sample_rows = rows[paint_like_exact] if bool(np.any(paint_like_exact)) else rows
                    if sample_rows.size > 0:
                        rgb_med = np.median(np.clip(current[sample_rows, :3], 0.0, 1.0), axis=0)
                        image['smart_paint_suite_last_source_rgb'] = (float(rgb_med[0]), float(rgb_med[1]), float(rgb_med[2]))
                        image['smart_paint_suite_last_brush_color'] = (float(rgb_med[0]), float(rgb_med[1]), float(rgb_med[2]), 1.0)
                except Exception:
                    pass
                try:
                    image['smart_paint_suite_clear_initialized_size'] = (int(mw), int(mh))
                    image['smart_paint_suite_lazy_width'] = int(mw)
                    image['smart_paint_suite_lazy_height'] = int(mh)
                except Exception:
                    pass
                try:
                    iw_sync, ih_sync = _image_size(image)
                    if int(iw_sync) != int(mw) or int(ih_sync) != int(mh):
                        _resize_image_to(image, int(mw), int(mh))
                    row_patch_exact = np.ascontiguousarray(np.clip(patch_exact, 0.0, 1.0), dtype=np.float32)
                    for _yy_sync in range(int(union_y0), int(union_y1)):
                        _src_y = int(_yy_sync) - int(union_y0)
                        _flat0 = (int(_yy_sync) * int(mw) + int(union_x0)) * 4
                        _flat1 = (int(_yy_sync) * int(mw) + int(union_x1)) * 4
                        if _flat1 > _flat0:
                            image.pixels[_flat0:_flat1] = row_patch_exact[_src_y, :, :].reshape((-1,))
                    try:
                        image.update()
                    except Exception:
                        pass
                except Exception as _sps_exact_pixel_exc:
                    try:
                        image['smart_paint_suite_sparse_pixel_sync_error'] = str(_sps_exact_pixel_exc or '')[:256]
                    except Exception:
                        pass
                for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                    try:
                        if prop in image:
                            del image[prop]
                    except Exception:
                        pass
                try:
                    _mark_image_pixels_changed(image, None)
                except Exception:
                    pass
                try:
                    master_done = get_master_texture_image(material, channel, create=False)
                    if master_done is not None:
                        for _mk_done in (
                            'smart_paint_suite_pending_visible_paint',
                            'smart_paint_suite_pending_master_paint',
                            'smart_paint_suite_painted_since_last_projection',
                            'smart_paint_suite_explicit_visible_paint',
                            'smart_paint_suite_dirty_bbox',
                        ):
                            try:
                                if _mk_done in master_done:
                                    del master_done[_mk_done]
                            except Exception:
                                pass
                except Exception:
                    pass
                return True
        except Exception:
            pass

        B = np.clip(baseline[rows, :3], 0.0, 1.0)
        T = np.clip(current[rows, :3], 0.0, 1.0)
        diff = T - B
        eps = solve_eps
        lighten = np.where(diff > 0.0, diff / np.maximum(1.0 - B, eps), 0.0)
        darken = np.where(diff < 0.0, (-diff) / np.maximum(B, eps), 0.0)
        cov_hint = np.clip(np.max(np.maximum(lighten, darken), axis=1), 0.0, 1.0).astype(np.float32, copy=False)

        # Use the explicitly remembered stroke/source colour first.  This is the
        # only colour that is known to belong to the current visible-master paint
        # operation.  The current Blender UI brush can be stale during RNA
        # visibility callbacks, and using it here can recolour the saved layer.
        explicit_source = None
        try:
            for _holder in (image, master):
                if _holder is None:
                    continue
                for _key in (
                    'smart_paint_suite_last_source_rgb',
                    'smart_paint_suite_test_brush_rgb',
                    'smart_paint_suite_inferred_source_rgb',
                    'smart_paint_suite_last_brush_color',
                ):
                    explicit_source = _rgb_tuple_or_none(_holder.get(_key, None))
                    if explicit_source is not None:
                        break
                if explicit_source is not None:
                    break
        except Exception:
            explicit_source = None

        source = explicit_source
        if source is not None:
            try:
                C_test = np.clip(np.asarray(source, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
                denom_test = C_test - B
                valid_test = np.abs(denom_test) > eps
                with np.errstate(divide='ignore', invalid='ignore'):
                    ratio_test = (T - B) / np.where(valid_test, denom_test, 1.0)
                valid_test = np.logical_and(valid_test, np.logical_and(ratio_test >= -0.08, ratio_test <= 1.08))
                valid_count_test = np.sum(valid_test, axis=1)
                ratio_test = np.clip(ratio_test, 0.0, 1.0)
                cov_test = np.sum(np.where(valid_test, ratio_test, 0.0), axis=1) / np.maximum(valid_count_test.astype(np.float32), 1.0)
                changed_test = np.max(np.abs(T - B), axis=1) > max(tol, 1.0 / 255.0)
                explained_test = np.logical_and(changed_test, valid_count_test > 0)
                if not bool(np.any(explained_test)):
                    source = None
                else:
                    recon_test = B * (1.0 - cov_test[:, None]) + C_test * cov_test[:, None]
                    err_test = np.max(np.abs(recon_test - T), axis=1)
                    support = int(np.count_nonzero(np.logical_and(explained_test, err_test <= max(8.0 / 255.0, tol * 4.0))))
                    needed = max(8, int(np.count_nonzero(changed_test) * 0.10))
                    if support < needed:
                        source = None
            except Exception:
                source = None
        if source is None:
            source = _sps_infer_source_rgb_for_master_patch(image, session, B, T, cov_hint)
        if source is None:
            # No reliable remembered brush colour. Estimate a source colour from
            # the highest-coverage rows; pure black/dark strokes are valid and
            # must not fall through to the generic inverse solver.
            try:
                strength = np.clip(cov_hint, 0.0, 1.0)
                sel = strength >= max(float(np.max(strength)) * 0.70, 1.0 / 255.0) if strength.size else np.zeros((0,), dtype=bool)
                if bool(np.any(sel)):
                    a_est = np.maximum(strength[sel][:, None], 1.0 / 255.0)
                    cand = (T[sel] - B[sel] * (1.0 - a_est)) / a_est
                    source = tuple(float(v) for v in np.median(np.clip(cand, 0.0, 1.0), axis=0)[:3])
            except Exception:
                source = None
        if source is None:
            return False
        C = np.clip(np.asarray(source, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
        denom = C - B
        valid = np.abs(denom) > eps
        with np.errstate(divide='ignore', invalid='ignore'):
            ratio = (T - B) / np.where(valid, denom, 1.0)
        valid = np.logical_and(valid, np.logical_and(ratio >= -0.08, ratio <= 1.08))
        valid_count = np.sum(valid, axis=1)
        cov = np.sum(np.where(valid, np.clip(ratio, 0.0, 1.0), 0.0), axis=1) / np.maximum(valid_count.astype(np.float32), 1.0)
        cov = np.where(valid_count > 0, cov, cov_hint)
        try:
            ba = np.clip(baseline[rows, 3], 0.0, 1.0)
            ca = np.clip(current[rows, 3], 0.0, 1.0)
            cov_a = np.clip((ca - ba) / np.maximum(1.0 - ba, eps), 0.0, 1.0)
            alpha_valid = np.logical_and(cov_a > eps, ca < (1.0 - eps))
            cov[alpha_valid] = cov_a[alpha_valid]
        except Exception:
            pass
        cov = np.clip(cov, 0.0, 1.0).astype(np.float32, copy=False)
        # Rows where Blender stored alpha coverage as black RGB should not be saved
        # as black paint.  Use neighbouring non-black coverage and keep source RGB.
        try:
            target_power = np.max(T, axis=1)
            source_is_dark = bool(float(np.max(C)) <= (3.0 / 255.0))
            dark_edge = np.logical_and((not source_is_dark), np.logical_and(target_power <= (3.0 / 255.0), cov > eps))
            if bool(np.any(dark_edge)):
                cov2 = np.zeros((bh, bw), dtype=np.float32)
                valid2 = np.zeros((bh, bw), dtype=bool)
                dark2 = np.zeros((bh, bw), dtype=bool)
                yy = (rows // int(mw)) - y0; xx = (rows % int(mw)) - x0
                cov2[yy, xx] = cov
                valid2[yy, xx] = np.logical_and(np.logical_not(dark_edge), cov > eps)
                dark2[yy, xx] = dark_edge
                cov2 = _sps_propagate_dark_edge_coverage(cov2, dark2, valid2)
                cov = cov2[yy, xx]
        except Exception:
            pass
        try:
            rgb_changed = np.max(np.abs(T - B), axis=1) > max(tol, 1.0 / 255.0)
        except Exception:
            rgb_changed = cov > (0.5 / 255.0)
        keep = np.logical_and(cov > (0.5 / 255.0), rgb_changed)
        if not bool(np.any(keep)):
            return False
        rows = rows[keep]; local_rows = local_rows[keep]; cov = cov[keep]
        # Build/merge the authoritative sparse patch.
        try:
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            clear_rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
        except Exception:
            clear_rgba = (1.0, 1.0, 1.0, 0.0)
        union_x0, union_y0, union_x1, union_y1 = x0, y0, x1, y1
        old_crop = None; old_box = _sps_parse_bbox4(image.get('smart_paint_suite_sparse_rgba_patch_bbox', None))
        if old_box is not None and str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or ''):
            try:
                import base64 as _sps_b64, zlib as _sps_zlib
                ox0, oy0, ox1, oy1 = old_box
                ox0 = max(0, min(int(mw), ox0)); ox1 = max(0, min(int(mw), ox1)); oy0 = max(0, min(int(mh), oy0)); oy1 = max(0, min(int(mh), oy1))
                raw_old = _sps_zlib.decompress(_sps_b64.b64decode(str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '').encode('ascii')))
                old_crop = np.frombuffer(raw_old, dtype=np.float32).reshape((oy1 - oy0, ox1 - ox0, 4)).copy()
                union_x0 = min(union_x0, ox0); union_y0 = min(union_y0, oy0); union_x1 = max(union_x1, ox1); union_y1 = max(union_y1, oy1)
                old_box = (ox0, oy0, ox1, oy1)
            except Exception:
                old_crop = None; old_box = None
        uw = int(union_x1 - union_x0); uh = int(union_y1 - union_y0)
        patch = np.empty((uh, uw, 4), dtype=np.float32)
        patch[:, :, 0] = clear_rgba[0]; patch[:, :, 1] = clear_rgba[1]; patch[:, :, 2] = clear_rgba[2]; patch[:, :, 3] = clear_rgba[3]
        if old_crop is not None and old_box is not None:
            ox0, oy0, ox1, oy1 = old_box
            patch[oy0-union_y0:oy1-union_y0, ox0-union_x0:ox1-union_x0, :] = np.clip(old_crop, 0.0, 1.0)
        yy = (rows // int(mw)) - union_y0; xx = (rows % int(mw)) - union_x0
        old_a = np.clip(patch[yy, xx, 3], 0.0, 1.0)
        old_rgb = np.clip(patch[yy, xx, :3], 0.0, 1.0)
        new_a = np.clip(cov + old_a * (1.0 - cov), 0.0, 1.0)
        premul = C.reshape((3,)) * cov[:, None] + old_rgb * old_a[:, None] * (1.0 - cov[:, None])
        new_rgb = premul / np.maximum(new_a[:, None], 1.0e-6)
        patch[yy, xx, :3] = np.clip(new_rgb, 0.0, 1.0)
        patch[yy, xx, 3] = new_a
        try:
            # Keep straight RGB under every visible-alpha row; alpha remains the only
            # coverage channel.
            a_patch = patch[:, :, 3]
            rgb_power = np.max(patch[:, :, :3], axis=2)
            bad = np.logical_and(a_patch > eps, rgb_power <= (2.0 / 255.0))
            if bool(np.any(bad)):
                patch[bad, :3] = C.reshape((3,))
        except Exception:
            pass
        import base64 as _sps_b64, json as _sps_json, zlib as _sps_zlib
        raw = _sps_zlib.compress(np.ascontiguousarray(patch.reshape((-1, 4)), dtype=np.float32).tobytes(), 1)
        box = (int(union_x0), int(union_y0), int(union_x1), int(union_y1))
        image['smart_paint_suite_dirty_bbox'] = box
        image['smart_paint_suite_sparse_rgba_patch_bbox'] = box
        image['smart_paint_suite_sparse_rgba_patch_b64'] = _sps_b64.b64encode(raw).decode('ascii')
        image['smart_paint_suite_authoritative_sparse_rgba_patch'] = True
        image['smart_paint_suite_live_save_patch_v172'] = True
        image['smart_paint_suite_dirty_from_master'] = True
        image['smart_paint_suite_alpha_authoritative'] = True
        image['smart_paint_suite_painted_since_last_projection'] = True
        image['smart_paint_suite_exact_top_sparse_commit'] = True
        image['smart_paint_suite_last_source_rgb'] = (float(C[0, 0]), float(C[0, 1]), float(C[0, 2]))
        image['smart_paint_suite_last_brush_color'] = (float(C[0, 0]), float(C[0, 1]), float(C[0, 2]), 1.0)
        try:
            image['smart_paint_suite_clear_initialized_size'] = (int(mw), int(mh))
            image['smart_paint_suite_lazy_width'] = int(mw)
            image['smart_paint_suite_lazy_height'] = int(mh)
        except Exception:
            pass
        try:
            # The sparse metadata is the PSD save authority, but Blender's live
            # compositor and later move/toggle operations read Image.pixels.  Keep
            # only the touched rectangle in sync so Save -> Reload/Move cannot see
            # a blank private layer and collapse the stack to black/transparent.
            iw_sync, ih_sync = _image_size(image)
            if int(iw_sync) != int(mw) or int(ih_sync) != int(mh):
                _resize_image_to(image, int(mw), int(mh))
            row_patch = np.ascontiguousarray(np.clip(patch, 0.0, 1.0), dtype=np.float32)
            for _yy_sync in range(int(union_y0), int(union_y1)):
                _src_y = int(_yy_sync) - int(union_y0)
                _flat0 = (int(_yy_sync) * int(mw) + int(union_x0)) * 4
                _flat1 = (int(_yy_sync) * int(mw) + int(union_x1)) * 4
                if _flat1 > _flat0:
                    image.pixels[_flat0:_flat1] = row_patch[_src_y, :, :].reshape((-1,))
            try:
                image.update()
            except Exception:
                pass
        except Exception as _sps_sparse_pixel_exc:
            try:
                image['smart_paint_suite_sparse_pixel_sync_error'] = str(_sps_sparse_pixel_exc or '')[:256]
            except Exception:
                pass
        for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
            try:
                if prop in image:
                    del image[prop]
            except Exception:
                pass
        try:
            _mark_image_pixels_changed(image, None)
        except Exception:
            pass
        try:
            # The exact master delta has now been transferred into the private
            # layer/sparse patch. Leaving public-master paint markers or old save
            # baselines alive makes the next Save/visibility refresh treat the same
            # flattened document as a second new stroke, which can copy lower-layer
            # artwork into this layer.
            master_done = get_master_texture_image(material, channel, create=False)
            if master_done is not None:
                for _mk_done in (
                    'smart_paint_suite_pending_visible_paint',
                    'smart_paint_suite_pending_master_paint',
                    'smart_paint_suite_painted_since_last_projection',
                    'smart_paint_suite_explicit_visible_paint',
                    'smart_paint_suite_dirty_bbox',
                ):
                    try:
                        if _mk_done in master_done:
                            del master_done[_mk_done]
                    except Exception:
                        pass
            # Keep the exact baseline alive until the visibility callback has a
            # chance to restore it for the OFF projection.  Save-time duplicate
            # commits are blocked by the authoritative sparse-layer readiness
            # checks.
        except Exception:
            pass
        return True
    except Exception:
        return False

def _image_sample_stamp(image, samples: int = 96) -> tuple[int, int, int]:
    """Very cheap deterministic image stamp.

    Random Image.pixels indexing is surprisingly slow on large/generated Blender
    images and caused texture loading to appear frozen.  Use metadata only here;
    real paint detection is handled by recent-operator checks and the full commit
    path when needed.
    """
    try:
        import zlib
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return (0, 0, 0)
        try:
            rev = int(image.get(_IMAGE_PIXEL_REV_PROP, 0) or 0)
        except Exception:
            rev = 0
        try:
            dirty = 1 if bool(getattr(image, 'is_dirty', False)) else 0
        except Exception:
            dirty = 0
        try:
            name = str(getattr(image, 'name', '') or '')
        except Exception:
            name = ''
        token = f'{int(w)}x{int(h)}:{rev}:{dirty}:{name}'.encode('utf-8', 'ignore')
        return (int(w), int(h), int(zlib.crc32(token) & 0xffffffff))
    except Exception:
        return (0, 0, 0)


def _image_live_pixel_sample_stamp(image, samples: int = 256) -> tuple[int, int, int]:
    """Pixel-based stamp used only while Texture Paint is actively armed.

    Blender native painting can mutate Image.pixels without changing Smart
    Paint's own revision metadata, and image.is_dirty is sticky.  Keep this
    deliberately tiny: paint operator/dirty transitions are the primary signals,
    while this catches obvious pixel-only changes without stalling 4K textures.
    """
    try:
        import struct
        import zlib

        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return (0, 0, 0)
        total = int(w) * int(h)
        requested_samples = int(samples or 0)
        px = image.pixels
        crc = 0
        # Always include common paint-test points and broad document anchors.
        anchors = (
            0,
            total - 1,
            (int(h) // 2) * int(w) + (int(w) // 2),
            (int(h) // 4) * int(w) + (int(w) // 4),
            (int(h) // 4) * int(w) + (int(w) * 3 // 4),
            (int(h) * 3 // 4) * int(w) + (int(w) // 4),
            (int(h) * 3 // 4) * int(w) + (int(w) * 3 // 4),
        )
        for pix in anchors:
            if 0 <= int(pix) < total:
                base = int(pix) * 4
                crc = zlib.crc32(struct.pack('4f', float(px[base]), float(px[base + 1]), float(px[base + 2]), float(px[base + 3])), crc)
        if requested_samples <= 0:
            return (int(w), int(h), int(crc & 0xffffffff))
        n = max(16, min(requested_samples, total))
        step = max(1, total // n)
        seed = 2166136261
        for i in range(n):
            seed = (1664525 * seed + 1013904223) & 0xFFFFFFFF
            pix = (i * step + (seed % step)) % total
            base = int(pix) * 4
            crc = zlib.crc32(struct.pack('4f', float(px[base]), float(px[base + 1]), float(px[base + 2]), float(px[base + 3])), crc)
        return (int(w), int(h), int(crc & 0xffffffff))
    except Exception:
        return _image_sample_stamp(image, samples)


def _array_sample_stamp(arr, width: int = 0, height: int = 0, samples: int = 96) -> tuple[int, int, int]:
    """Cheap deterministic stamp from an already-read Nx4 array.

    This avoids reading Image.pixels again after a full master read, which was a
    major source of UI stalls on 4K/8K textures.
    """
    try:
        import numpy as np, zlib, struct, math
        a = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
        npx = int(a.shape[0])
        if npx <= 0:
            return (int(width or 0), int(height or 0), 0)
        if width <= 0 or height <= 0:
            width, height = npx, 1
        n = max(8, min(int(samples or 96), npx))
        # Equally spaced indices give stable negative checks without touching all pixels.
        idx = np.linspace(0, npx - 1, n, dtype=np.int64)
        data = np.ascontiguousarray(a[idx].reshape(-1), dtype=np.float32)
        return (int(width), int(height), int(zlib.crc32(data.tobytes()) & 0xffffffff))
    except Exception:
        return (int(width or 0), int(height or 0), 0)

_COMPOSITE_ARRAY_CACHE = _sps_quota.cache('psd.composite')
# Compatibility ordering list contains data-only keys only; the shared cache is
# the authoritative LRU and enforces the Suite-wide budget.
# Keep full-array caches small.  4K PSD layers are common in this add-on;
# caching several 4K float buffers can exceed gigabytes and freeze Blender.
_IMAGE_ARRAY_CACHE_PIXEL_LIMIT = 2048 * 2048
_COMPOSITE_ARRAY_CACHE_PIXEL_LIMIT = 2048 * 2048

def _image_cache_allowed(image) -> bool:
    try:
        if image is None:
            return False
        if not (bool(image.get('smart_paint_suite_layer_image', False)) or bool(image.get('smart_paint_suite_master_texture', False))):
            return False
        w, h = _image_size(image)
        return int(w) * int(h) <= _IMAGE_ARRAY_CACHE_PIXEL_LIMIT
    except Exception:
        return False


_LAZY_PSD_LAYER_RECORDS = _sps_quota.cache('psd.lazy_layer_records')
_LAZY_PSD_SOURCE_DOCS = _sps_quota.cache('psd.lazy_source_docs')
_LAZY_PSD_MASTER_PREVIEW_CACHE = _sps_quota.cache('psd.master_preview')
_SPS_SOURCE_MERGED_BASE_CACHE = _sps_quota.cache('psd.source_merged_base')


def _cross_platform_basename(path_text: str) -> str:
    try:
        raw = str(path_text or '')
        if not raw:
            return ''
        name = Path(raw).name
        if name and name != raw:
            return name
        return PureWindowsPath(raw).name
    except Exception:
        try:
            return Path(str(path_text or '')).name
        except Exception:
            return ''


def _resolve_lazy_psd_source_path(source: str) -> str:
    """Resolve a PSD source path without requiring the original drive letter.

    Production files often store absolute Windows/OneDrive paths inside layer
    proxies.  Linux test runs and moved project folders cannot open those paths,
    but the PSD usually sits beside the .blend or has Blender's duplicate suffix
    such as ``name(1).psd``.  This resolver keeps the original path first and then
    tries local, same-stem PSD/PSB files without any network probing.
    """
    raw = str(source or '')
    if not raw:
        return ''
    candidates = []
    try:
        candidates.append(str(bpy.path.abspath(raw)))
    except Exception:
        pass
    candidates.append(raw)
    for candidate in candidates:
        try:
            if candidate and Path(candidate).exists():
                return str(Path(candidate))
        except Exception:
            pass
    base = _cross_platform_basename(raw)
    if not base:
        return candidates[0] if candidates else raw
    suffix = Path(base).suffix.lower()
    if suffix not in {'.psd', '.psb', '.pdd'}:
        return candidates[0] if candidates else raw
    stem = Path(base).stem
    search_dirs = []
    try:
        blend_path = str(getattr(bpy.data, 'filepath', '') or '')
        if blend_path:
            search_dirs.append(Path(blend_path).parent)
    except Exception:
        pass
    try:
        parent = Path(candidates[0]).parent if candidates else None
        if parent is not None and parent.exists():
            search_dirs.append(parent)
    except Exception:
        pass
    try:
        search_dirs.append(Path.cwd())
    except Exception:
        pass
    seen = set()
    for directory in search_dirs:
        try:
            d = Path(directory)
            key = str(d)
            if key in seen or not d.exists() or not d.is_dir():
                continue
            seen.add(key)
            exact = d / base
            if exact.exists():
                return str(exact)
            matches = []
            for ext in ('.psd', '.psb', '.pdd'):
                try:
                    matches.extend(sorted(d.glob(stem + '*' + ext)))
                except Exception:
                    pass
            for match in matches:
                try:
                    if match.is_file():
                        return str(match)
                except Exception:
                    continue
        except Exception:
            continue
    return candidates[0] if candidates else raw


def register_lazy_psd_layer_image(image, doc: dict, record: dict) -> bool:
    """Attach lazy PSD layer payload to a Blender image without decoding pixels."""
    if image is None or doc is None or record is None:
        return False
    try:
        key = str(getattr(image, 'name', '') or '') + '|' + str(record.get('record_index', ''))
        _LAZY_PSD_LAYER_RECORDS[key] = {
            'record': record,
            'doc_width': int(doc.get('width', 0) or 0),
            'doc_height': int(doc.get('height', 0) or 0),
            'depth': int(doc.get('depth', 8) or 8),
            'color_mode': int(doc.get('color_mode', 3) or 3),
            'psb': bool(doc.get('psb')),
        }
        image['smart_paint_suite_lazy_psd_key'] = key
        image['smart_paint_suite_lazy_psd_pending'] = True
        image['smart_paint_suite_lazy_width'] = int(doc.get('width', 0) or 0)
        image['smart_paint_suite_lazy_height'] = int(doc.get('height', 0) or 0)
        image['smart_paint_suite_layer_image'] = True
        try:
            rec_index = int(record.get('record_index', -1))
            if rec_index >= 0:
                image['sps_psd_source_order'] = int(rec_index)
                image['sps_psd_source_ordinal'] = int(rec_index)
                image['sps_psd_source_layer_index'] = int(rec_index)
            rec_name = str(record.get('name', '') or '')
            if rec_name:
                image['sps_psd_original_name'] = rec_name
        except Exception:
            pass
        try:
            image.use_fake_user = True
        except Exception:
            pass
        return True
    except Exception:
        return False




def lazy_psd_layer_payload_for_image(image):
    """Return the in-memory lazy PSD payload for an imported proxy image."""
    try:
        if image is None:
            return None
        key = str(image.get('smart_paint_suite_lazy_psd_key', '') or '')
        source = _resolve_lazy_psd_source_path(str(image.get('smart_paint_suite_source_file', '') or image.get('smart_paint_suite_layered_source_path', '') or ''))
        layer_name = str(
            image.get('sps_psd_original_name', '')
            or image.get('smart_paint_suite_original_layer_name', '')
            or getattr(image, 'name', '')
            or ''
        )
        cache_key = key or (str(getattr(image, 'name', '') or '') + '|source|' + source if source else '')

        def _make_payload(doc_value, record_value):
            return {
                'record': record_value,
                'doc_width': int(doc_value.get('width', 0) or 0),
                'doc_height': int(doc_value.get('height', 0) or 0),
                'depth': int(doc_value.get('depth', 8) or 8),
                'color_mode': int(doc_value.get('color_mode', 3) or 3),
                'psb': bool(doc_value.get('psb')),
            }

        def _record_needs_name_recovery(record_value) -> bool:
            try:
                if not isinstance(record_value, dict) or not record_value:
                    return True
                rec_name = str(record_value.get('name', '') or '')
                if not _lazy_record_has_paintable_bounds(record_value):
                    return True
                if layer_name and rec_name and not _lazy_image_name_matches_record_name(layer_name, rec_name):
                    return True
            except Exception:
                return True
            return False

        def _load_source_doc():
            if not source:
                return None
            doc_value = _LAZY_PSD_SOURCE_DOCS.get(source)
            if doc_value is None:
                doc_value = read_layered_psd_lazy(source, decode_merged=False)
                try:
                    _LAZY_PSD_SOURCE_DOCS[source] = doc_value
                except Exception:
                    pass
            return doc_value

        def _requested_record_index():
            try:
                return int(str(key).rsplit('|', 1)[-1]) if key else None
            except Exception:
                pass
            for source_key in ('sps_psd_source_order', 'sps_psd_source_ordinal', 'sps_psd_source_layer_index'):
                try:
                    if source_key in image:
                        return int(image.get(source_key, -1))
                except Exception:
                    pass
            return None

        def _record_by_record_index(doc_value, index_value):
            if index_value is None:
                return None
            for candidate in list((doc_value or {}).get('layers', []) or []):
                try:
                    if int(candidate.get('record_index', -999999)) == int(index_value):
                        return candidate
                except Exception:
                    pass
            return None

        def _payload_record_matches_request(record_value, requested_index) -> bool:
            try:
                if requested_index is not None:
                    return int((record_value or {}).get('record_index', -999999)) == int(requested_index)
            except Exception:
                return False
            try:
                rec_name = str((record_value or {}).get('name', '') or '')
                return bool(layer_name and rec_name and _lazy_image_name_matches_record_name(layer_name, rec_name))
            except Exception:
                return False

        def _store_payload(payload_value, record_value, *aliases):
            try:
                rec_index = int(record_value.get('record_index', 0) or 0)
            except Exception:
                rec_index = 0
            try:
                corrected_key = str(layer_name or getattr(image, 'name', '') or 'lazy_psd_layer') + '|' + str(rec_index)
                image['smart_paint_suite_lazy_psd_key'] = corrected_key
                _LAZY_PSD_LAYER_RECORDS[corrected_key] = payload_value
                for alias in aliases:
                    try:
                        if alias:
                            _LAZY_PSD_LAYER_RECORDS[str(alias)] = payload_value
                    except Exception:
                        pass
                image['sps_psd_source_order'] = int(rec_index)
                image['sps_psd_source_ordinal'] = int(rec_index)
                image['sps_psd_source_layer_index'] = int(rec_index)
                rec_name = str(record_value.get('name', '') or '')
                if rec_name:
                    image['sps_psd_original_name'] = rec_name
            except Exception:
                pass

        record_index = _requested_record_index()
        payload = _LAZY_PSD_LAYER_RECORDS.get(cache_key) if cache_key else None
        if payload:
            try:
                record = dict(payload.get('record') or {})
            except Exception:
                record = {}
            if source and (not _payload_record_matches_request(record, record_index) or _record_needs_name_recovery(record)):
                try:
                    doc = _load_source_doc()
                    replacement = _record_by_record_index(doc, record_index) if doc is not None else None
                    if replacement is None:
                        replacement = _lazy_find_name_matched_record(doc, layer_name, require_paintable=True) if doc is not None else None
                    if replacement is not None:
                        payload = _make_payload(doc, replacement)
                        _store_payload(payload, replacement, cache_key, key)
                except Exception:
                    pass
            return payload
        if not source:
            return None
        doc = _load_source_doc()
        if doc is None:
            return None
        rec = _record_by_record_index(doc, record_index)
        if rec is None:
            layer_name = str(getattr(image, 'name', '') or '')
            for candidate in list(doc.get('layers', []) or []):
                cname = str(candidate.get('name', '') or '')
                if cname and _lazy_image_name_matches_record_name(layer_name, cname):
                    rec = candidate
                    break
        if rec is None:
            return None
        if _record_needs_name_recovery(rec):
            try:
                replacement = _lazy_find_name_matched_record(doc, layer_name, require_paintable=True)
                if replacement is not None:
                    rec = replacement
            except Exception:
                pass
        payload = _make_payload(doc, rec)
        try:
            recovered_key = str(key or '')
            _store_payload(payload, rec, recovered_key, cache_key)
        except Exception:
            pass
        return payload
    except Exception:
        return None


def lazy_psd_layer_preencoded_planes_for_image(image, *, prefer_raw: bool = True):
    """Decode a lazy PSD record into local 8-bit PSD plane bytes without full-document RGBA.

    This is used by large PSD save paths so unchanged imported layers can be
    re-emitted without allocating a full 4096/8K float buffer for every layer.
    """
    try:
        for key in (
            'smart_paint_suite_direct_layer_dirty',
            'smart_paint_suite_bodypaint_direct_authoritative',
            'smart_paint_suite_painted_since_last_projection',
            'smart_paint_suite_user_edited',
            'smart_paint_suite_dirty_bbox',
            'smart_paint_suite_sparse_rgba_patch_b64',
            'smart_paint_suite_authoritative_sparse_rgba_patch',
        ):
            try:
                if bool(image.get(key, False)):
                    return None
            except Exception:
                pass
        try:
            if bool(getattr(image, 'is_dirty', False)):
                return None
        except Exception:
            pass
        payload = lazy_psd_layer_payload_for_image(image)
        if not payload:
            return None
        rec = dict(payload.get('record') or {})
        depth = int(payload.get('depth', 8) or 8)
        color_mode = int(payload.get('color_mode', 3) or 3)
        psb = bool(payload.get('psb'))
        left = int(rec.get('left', 0) or 0); top = int(rec.get('top', 0) or 0)
        right = int(rec.get('right', 0) or 0); bottom = int(rec.get('bottom', 0) or 0)
        doc_width = int(payload.get('doc_width', 0) or rec.get('doc_width', 0) or 0)
        doc_height = int(payload.get('doc_height', 0) or rec.get('doc_height', 0) or 0)
        # PSD layer positions may be far outside the document.  Only inverted
        # rectangles are structurally unusable here; oversized local rectangles are
        # handled by the area guard below.
        if int(right) < int(left) or int(bottom) < int(top):
            return {
                'top': 0, 'left': 0, 'bottom': 1, 'right': 1,
                'width': 1, 'height': 1,
                'planes': (b'\x00', b'\x00', b'\x00', b'\x00'),
                'mask_plane': None,
                'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                'sps_sanitized_inverted_bounds': True,
            }
        bw = max(0, right - left); bh = max(0, bottom - top)
        if bool(rec.get('is_group', False)) or int(rec.get('section_type', 0) or 0) in {1, 2, 3}:
            # Folder rows can carry a Photoshop user/vector mask even though they
            # do not have RGB pixels.  Keep those compressed mask channels for
            # PSD round-trip without materialising a full 4K mask in Blender.
            if bw <= 0 or bh <= 0:
                return None
            try:
                chdata = rec.get('channel_data', {}) or {}
                raw_channels = []
                for channel_id, _channel_len in list(rec.get('channel_info', []) or []):
                    cid = int(channel_id)
                    if cid not in {-2, -3}:
                        continue
                    raw = chdata.get(cid)
                    if raw is None or len(raw) < 2:
                        continue
                    comp = struct.unpack_from('>H', raw, 0)[0]
                    if int(comp) not in {0, 1, 2, 3}:
                        continue
                    raw_channels.append((cid, bytes(raw)))
                if raw_channels:
                    return {
                        'top': int(top), 'left': int(left), 'bottom': int(bottom), 'right': int(right),
                        'width': int(bw), 'height': int(bh),
                        'raw_channels': tuple(raw_channels),
                        'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                        'raw_passthrough': True,
                        'mask_only': True,
                    }
            except Exception:
                pass
            return None
        if bw <= 0 or bh <= 0:
            try:
                mask_rect = dict(rec.get('mask_rect', {}) or {})
                mt = int(mask_rect.get('top', 0) or 0)
                ml = int(mask_rect.get('left', 0) or 0)
                mb = int(mask_rect.get('bottom', 0) or 0)
                mr = int(mask_rect.get('right', 0) or 0)
                mw = max(0, mr - ml)
                mh = max(0, mb - mt)
                chdata = rec.get('channel_data', {}) or {}
                raw_channels = []
                if mw > 0 and mh > 0:
                    for channel_id, _channel_len in list(rec.get('channel_info', []) or []):
                        cid = int(channel_id)
                        if cid not in {-2, -3}:
                            continue
                        raw = chdata.get(cid)
                        if raw is None or len(raw) < 2:
                            continue
                        comp = struct.unpack_from('>H', raw, 0)[0]
                        if int(comp) not in {0, 1, 2, 3}:
                            continue
                        raw_channels.append((cid, bytes(raw)))
                if raw_channels:
                    return {
                        'top': int(mt), 'left': int(ml), 'bottom': int(mb), 'right': int(mr),
                        'width': int(mw), 'height': int(mh),
                        'raw_channels': tuple(raw_channels),
                        'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                        'raw_passthrough': True,
                        'mask_only': True,
                    }
            except Exception:
                pass
            return None
        if int(bw) * int(bh) > 268_435_456:
            return {
                'top': 0, 'left': 0, 'bottom': 1, 'right': 1,
                'width': 1, 'height': 1,
                'planes': (b'\x00', b'\x00', b'\x00', b'\x00'),
                'mask_plane': None,
                'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                'sps_sanitized_oversize_bounds': True,
            }
        chdata = rec.get('channel_data', {}) or {}
        # Fast unchanged-layer passthrough: for ordinary 8-bit RGB PSD files,
        # keep each original compressed channel payload instead of expanding it
        # to full float RGBA and then writing it back uncompressed.  This is the
        # critical path for 4K PSDs with many untouched layers; decoding every
        # layer during Save made Blender appear frozen.
        try:
            raw_bounds_inside_document = (
                int(doc_width) > 0 and int(doc_height) > 0
                and 0 <= int(left) <= int(right) <= int(doc_width)
                and 0 <= int(top) <= int(bottom) <= int(doc_height)
            )
            if bool(prefer_raw) and bool(raw_bounds_inside_document) and int(depth) == 8 and int(color_mode) == 3 and not bool(psb):
                raw_channels = []
                for channel_id, _channel_len in list(rec.get('channel_info', []) or []):
                    cid = int(channel_id)
                    raw = chdata.get(cid)
                    if raw is None or len(raw) < 2:
                        raw_channels = []
                        break
                    comp = struct.unpack_from('>H', raw, 0)[0]
                    if int(comp) not in {0, 1, 2, 3}:
                        raw_channels = []
                        break
                    raw_channels.append((cid, bytes(raw)))
                if raw_channels:
                    return {
                        'top': int(top), 'left': int(left), 'bottom': int(bottom), 'right': int(right),
                        'width': int(bw), 'height': int(bh),
                        'raw_channels': tuple(raw_channels),
                        'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                        'raw_passthrough': True,
                    }
        except Exception:
            pass
        np = _np_module()
        if np is None:
            return None
        z = np.zeros((bh, bw), dtype=np.float32)
        o = np.ones((bh, bw), dtype=np.float32)
        def _ch(cid, default):
            raw = chdata.get(int(cid))
            if raw is None:
                return default
            try:
                return _psd_channel_float_array(raw, bw, bh, depth, psb=psb)
            except Exception:
                return default
        if int(color_mode) == 1:
            g = _ch(0, z); r = g; b = g
        elif int(color_mode) == 4:
            c = _ch(0, z); m = _ch(1, z); y = _ch(2, z); k = _ch(3, z)
            r = 1.0 - np.minimum(1.0, c + k)
            g = 1.0 - np.minimum(1.0, m + k)
            b = 1.0 - np.minimum(1.0, y + k)
        else:
            r = _ch(0, z); g = _ch(1, r); b = _ch(2, r)
        a = _ch(-1, o)
        mask_arr = None
        for mask_id in (-2, -3):
            raw_m = chdata.get(mask_id)
            if raw_m is not None:
                try:
                    mask_arr = _psd_channel_float_array(raw_m, bw, bh, depth, psb=psb)
                    break
                except Exception:
                    mask_arr = None
        # Clamp decoded canonical records to the document rectangle.  Some real PSDs
        # contain a few pixels outside the canvas; raw passthrough can preserve those
        # only during an exact source copy.  Once Smart Paint adds a new layer and
        # re-emits the PSD, every emitted record must have ordinary in-document
        # bounds or Blender/Windows save validation can reject the file as having
        # impossible layer bounds.
        try:
            if int(doc_width) > 0 and int(doc_height) > 0:
                new_left = max(0, min(int(doc_width), int(left)))
                new_top = max(0, min(int(doc_height), int(top)))
                new_right = max(0, min(int(doc_width), int(right)))
                new_bottom = max(0, min(int(doc_height), int(bottom)))
                if new_right <= new_left or new_bottom <= new_top:
                    return {
                        'top': 0, 'left': 0, 'bottom': 1, 'right': 1,
                        'width': 1, 'height': 1,
                        'planes': (b'\x00', b'\x00', b'\x00', b'\x00'),
                        'mask_plane': None,
                        'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
                        'sps_sanitized_empty_after_crop': True,
                    }
                crop_x0 = max(0, int(new_left) - int(left))
                crop_y0 = max(0, int(new_top) - int(top))
                crop_x1 = crop_x0 + (int(new_right) - int(new_left))
                crop_y1 = crop_y0 + (int(new_bottom) - int(new_top))
                if (new_left, new_top, new_right, new_bottom) != (left, top, right, bottom):
                    r = np.asarray(r, dtype=np.float32)[crop_y0:crop_y1, crop_x0:crop_x1]
                    g = np.asarray(g, dtype=np.float32)[crop_y0:crop_y1, crop_x0:crop_x1]
                    b = np.asarray(b, dtype=np.float32)[crop_y0:crop_y1, crop_x0:crop_x1]
                    a = np.asarray(a, dtype=np.float32)[crop_y0:crop_y1, crop_x0:crop_x1]
                    if mask_arr is not None:
                        mask_arr = np.asarray(mask_arr, dtype=np.float32)[crop_y0:crop_y1, crop_x0:crop_x1]
                    left, top, right, bottom = int(new_left), int(new_top), int(new_right), int(new_bottom)
                    bw = int(right) - int(left); bh = int(bottom) - int(top)
        except Exception:
            pass
        mask_plane = None
        if mask_arr is not None:
            try:
                vals = np.clip(mask_arr * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8, copy=False)
                mask_plane = vals.tobytes()
            except Exception:
                mask_plane = None
        def _plane(x):
            vals = np.clip(np.asarray(x, dtype=np.float32) * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8, copy=False)
            return vals.tobytes()
        return {
            'top': int(top), 'left': int(left), 'bottom': int(bottom), 'right': int(right),
            'width': int(bw), 'height': int(bh),
            'planes': (_plane(r), _plane(g), _plane(b), _plane(a)),
            'mask_plane': mask_plane,
            'name': str(rec.get('name', '') or getattr(image, 'name', '') or 'Layer'),
            'sps_canonical_clamped_to_document': True,
        }
    except Exception:
        return None

def materialize_lazy_psd_layer_image(image) -> bool:
    """Decode a lazy PSD layer into its Blender image on demand.

    Older saved .blend files can contain 1x1 lazy proxy images whose in-memory
    payload was lost after an extension reload, or whose pending flag was cleared
    even though the full layer pixels were never materialized.  Treat any 1x1
    proxy with a PSD source and declared lazy width/height as materializable.
    """
    if image is None:
        return False
    try:
        if bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
            lazy_w = int(image.get('smart_paint_suite_lazy_width', 0) or image.size[0] or 1)
            lazy_h = int(image.get('smart_paint_suite_lazy_height', 0) or image.size[1] or 1)
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
            try:
                # Set generated_color before scaling.  In Blender generated images,
                # assigning generated_color after image.scale() resets the image
                # back to its generated source dimensions.
                image.generated_color = rgba
            except Exception:
                pass
            try:
                if int(image.size[0]) != lazy_w or int(image.size[1]) != lazy_h:
                    image.scale(lazy_w, lazy_h)
            except Exception:
                pass
            try:
                # Blender's generated-image backing buffer is not guaranteed to be
                # fully initialized after a 1x1 -> full-size scale in every paint
                # workspace.  Fill the materialized layer explicitly so the next
                # active-layer paint commit starts from the real transparent canvas
                # instead of a 1x1 proxy or stale white buffer.
                import numpy as _np
                _arr = _np.empty((max(1, int(lazy_w)) * max(1, int(lazy_h)), 4), dtype=_np.float32)
                _arr[:, 0] = rgba[0]; _arr[:, 1] = rgba[1]; _arr[:, 2] = rgba[2]; _arr[:, 3] = rgba[3]
                image.pixels.foreach_set(_arr.reshape(-1))
                image.update()
            except Exception:
                pass
            try:
                image['smart_paint_suite_clear_initialized'] = True
                image['smart_paint_suite_clear_initialized_size'] = (int(lazy_w), int(lazy_h))
                image['smart_paint_suite_clear_initialized_color'] = rgba
                image['smart_paint_suite_clear_color'] = rgba
                image['smart_paint_suite_initialized_clear_color'] = rgba
                image['smart_paint_suite_intentionally_empty'] = True
                image['smart_paint_suite_clear_deferred'] = True
                image['smart_paint_suite_lazy_materialized_blank'] = True
                if 'smart_paint_suite_lazy_blank_layer' in image:
                    del image['smart_paint_suite_lazy_blank_layer']
            except Exception:
                pass
            return True
        key = str(image.get('smart_paint_suite_lazy_psd_key', '') or '')
        source_order = None
        if '|' in key:
            try:
                source_order = int(str(key).rsplit('|', 1)[-1])
            except Exception:
                source_order = None
        if source_order is None:
            for source_key in ('sps_psd_source_order', 'sps_psd_source_ordinal', 'sps_psd_source_layer_index'):
                try:
                    if source_key in image:
                        source_order = int(image.get(source_key, -1))
                        break
                except Exception:
                    pass
        source = str(image.get('smart_paint_suite_source_file', '') or '')
        lazy_w = int(image.get('smart_paint_suite_lazy_width', 0) or 0)
        lazy_h = int(image.get('smart_paint_suite_lazy_height', 0) or 0)
        try:
            # Older production .blend files can lose the lazy width/height and
            # pending flag while still keeping a PSD source path on a 1x1 proxy.
            # Treat any PSD-sourced 1x1 image as recoverable; the real document
            # dimensions are read from the PSD payload below.
            is_proxy_size = int(image.size[0]) <= 1 and int(image.size[1]) <= 1 and bool(source)
        except Exception:
            is_proxy_size = False
        pending = bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(is_proxy_size)
        if not pending:
            return False
        if not key:
            # Stable synthetic key for old proxies that never got a lazy key.
            key = str(getattr(image, 'name', '') or 'lazy_psd_layer') + '|recovered'
            try:
                image['smart_paint_suite_lazy_psd_key'] = key
            except Exception:
                pass
        payload = _LAZY_PSD_LAYER_RECORDS.get(key)
        try:
            corrected_payload = lazy_psd_layer_payload_for_image(image)
            if corrected_payload:
                payload = corrected_payload
                key = str(image.get('smart_paint_suite_lazy_psd_key', '') or key)
                try:
                    corrected_record = dict(corrected_payload.get('record') or {})
                    corrected_order = int(corrected_record.get('record_index', -1))
                    if corrected_order >= 0:
                        source_order = corrected_order
                except Exception:
                    pass
        except Exception:
            pass
        if not payload:
            # Extension reloads and threaded PSD import can lose the in-memory
            # lazy payload while the Image datablock still carries the source file
            # and a layer-like name. Rebuild the payload from the PSD on demand.
            try:
                record_index = None
                try:
                    record_index = int(str(key).rsplit('|', 1)[-1])
                except Exception:
                    record_index = None
                if record_index is None:
                    for source_key in ('sps_psd_source_order', 'sps_psd_source_ordinal', 'sps_psd_source_layer_index'):
                        try:
                            if source_key in image:
                                record_index = int(image.get(source_key, -1))
                                break
                        except Exception:
                            pass
                if source:
                    doc = read_layered_psd_lazy(source, decode_merged=False)
                    rec = None
                    for candidate in list(doc.get('layers', []) or []):
                        try:
                            if record_index is not None and int(candidate.get('record_index', -999999)) == int(record_index):
                                rec = candidate; break
                        except Exception:
                            pass
                    if rec is None:
                        layer_name = str(getattr(image, 'name', '') or '')
                        # Prefer exact/substring name matches; this recovers
                        # Japanese layer names such as レイヤー 2 / レイヤー 3.
                        for candidate in list(doc.get('layers', []) or []):
                            cname = str(candidate.get('name', '') or '')
                            if cname and _lazy_image_name_matches_record_name(layer_name, cname):
                                rec = candidate; break
                    if rec is None:
                        # Final fallback: use first raster record that has not
                        # been materialized.  Better to display a real layer than
                        # leave a blank 1x1 proxy in production files.
                        for candidate in list(doc.get('layers', []) or []):
                            if not bool(candidate.get('is_group', False)):
                                rec = candidate; break
                    if rec is not None:
                        payload = {
                            'record': rec,
                            'doc_width': int(doc.get('width', 0) or 0),
                            'doc_height': int(doc.get('height', 0) or 0),
                            'depth': int(doc.get('depth', 8) or 8),
                            'color_mode': int(doc.get('color_mode', 3) or 3),
                            'psb': bool(doc.get('psb')),
                        }
                        _LAZY_PSD_LAYER_RECORDS[key] = payload
            except Exception:
                payload = None
        if not payload:
            return False
        if source_order is None:
            try:
                source_order = int(dict(payload.get('record') or {}).get('record_index', -1))
                if source_order < 0:
                    source_order = None
            except Exception:
                source_order = None
        is_mask_payload = bool(image.get('smart_paint_suite_lazy_psd_mask_pending', False))
        if is_mask_payload:
            # Blender regenerates a generated image at its original dimensions
            # when its colorspace changes. Set Non-Color while this is still the
            # cheap 1x1 proxy, before scaling and writing the decoded mask.
            try:
                image.colorspace_settings.name = 'Non-Color'
            except Exception:
                pass
        if is_mask_payload:
            rgba = _psd_layer_mask_to_rgba(
                payload.get('record'),
                doc_width=int(payload.get('doc_width', 0) or 0),
                doc_height=int(payload.get('doc_height', 0) or 0),
                depth=int(payload.get('depth', 8) or 8),
                psb=bool(payload.get('psb')),
            )
        else:
            rgba = decode_lazy_psd_layer_rgba(
                payload.get('record'),
                doc_width=int(payload.get('doc_width', 0) or 0),
                doc_height=int(payload.get('doc_height', 0) or 0),
                depth=int(payload.get('depth', 8) or 8),
                color_mode=int(payload.get('color_mode', 3) or 3),
                psb=bool(payload.get('psb')),
                apply_layer_mask=False,
            )
        if rgba is None:
            return False
        try:
            w = int(payload.get('doc_width', 0) or 0); h = int(payload.get('doc_height', 0) or 0)
            if w > 0 and h > 0 and (int(image.size[0]) != w or int(image.size[1]) != h):
                image.scale(w, h)
        except Exception:
            pass
        image.pixels.foreach_set(rgba.reshape(-1))
        image.update()
        try:
            for _clean_prop in (
                'smart_paint_suite_direct_layer_dirty',
                'smart_paint_suite_painted_since_last_projection',
                'smart_paint_suite_bodypaint_direct_authoritative',
                'smart_paint_suite_dirty_from_master',
                'smart_paint_suite_user_edited',
                'smart_paint_suite_dirty_bbox',
                'smart_paint_suite_sparse_rgba_patch_b64',
                'smart_paint_suite_bodypaint_explicit_capture_time',
                'smart_paint_suite_bodypaint_last_write_time',
            ):
                try:
                    if _clean_prop in image:
                        del image[_clean_prop]
                except Exception:
                    pass
            image['smart_paint_suite_alpha_authoritative'] = True
            image['smart_paint_suite_psd_materialized_clean'] = True
            image['smart_paint_suite_internal_clean_write'] = True
            image['smart_paint_suite_internal_write_reason'] = 'lazy_psd_materialize'
            if source_order is not None:
                image['sps_psd_source_order'] = int(source_order)
                image['sps_psd_source_ordinal'] = int(source_order)
                image['sps_psd_source_layer_index'] = int(source_order)
            for _prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                try:
                    if _prop in image:
                        del image[_prop]
                except Exception:
                    pass
        except Exception:
            pass
        try:
            image['smart_paint_suite_lazy_psd_pending'] = False
            if 'smart_paint_suite_lazy_psd_mask_pending' in image:
                del image['smart_paint_suite_lazy_psd_mask_pending']
            # Keep smart_paint_suite_lazy_psd_key and the decoded record cache
            # after clean materialization.  Visibility/reorder previews still
            # need to identify this as the original PSD layer until a real user
            # paint flag makes the Blender image authoritative.
        except Exception:
            pass
        try:
            image[_IMAGE_PIXEL_REV_PROP] = _image_pixel_revision(image) + 1
            _invalidate_read_scope_image(image)
            if _image_cache_allowed(image):
                _cache_image_array(image, rgba)
            else:
                _IMAGE_ARRAY_CACHE.pop(_image_cache_key(image), None)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _image_cache_key(image):
    try:
        return (str(getattr(image, 'name', '') or ''), int(image.as_pointer()))
    except Exception:
        return (str(getattr(image, 'name', '') or ''), 0)

def _image_pixel_revision(image) -> int:
    try:
        return int(image.get(_IMAGE_PIXEL_REV_PROP, 0) or 0)
    except Exception:
        return 0


def _trim_array_cache(cache, *, max_items: int = 0, max_bytes: int = 0) -> None:
    """Compatibility hook; the shared cache owns all byte/count eviction."""
    del cache, max_items, max_bytes
    _sps_quota.clear_for_memory_pressure()

def _cache_image_array(image, arr) -> None:
    try:
        if image is None or arr is None or not _image_cache_allowed(image):
            return
        import numpy as np
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return
        a = np.asarray(arr, dtype=np.float32).reshape((int(w) * int(h), 4))
        key = _image_cache_key(image)
        _IMAGE_ARRAY_CACHE.pop(key, None)
        _IMAGE_ARRAY_CACHE[key] = {
            'rev': _image_pixel_revision(image),
            'size': (int(w), int(h)),
            'arr': np.ascontiguousarray(a, dtype=np.float32),
        }
        _sps_quota.clear_for_memory_pressure()
    except Exception:
        pass

def _cached_image_array(image, width: int | None = None, height: int | None = None):
    try:
        if image is None or not _image_cache_allowed(image):
            return None
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return None
        if width is not None and int(width) != int(w):
            return None
        if height is not None and int(height) != int(h):
            return None
        key = _image_cache_key(image)
        item = _IMAGE_ARRAY_CACHE.get(key)
        if not item:
            return None
        if tuple(item.get('size', ())) != (int(w), int(h)):
            return None
        if int(item.get('rev', -1)) != _image_pixel_revision(image):
            return None
        _IMAGE_ARRAY_CACHE.pop(key, None)
        _IMAGE_ARRAY_CACHE[key] = item
        return item.get('arr')
    except Exception:
        return None

def begin_image_array_read_scope(label: str = '') -> int:
    global _IMAGE_ARRAY_READ_SCOPE_DEPTH, _IMAGE_ARRAY_READ_SCOPE_LEASE
    _IMAGE_ARRAY_READ_SCOPE_DEPTH = max(0, int(_IMAGE_ARRAY_READ_SCOPE_DEPTH)) + 1
    if _IMAGE_ARRAY_READ_SCOPE_DEPTH == 1:
        lease = f"read:{label or 'operation'}:{time.monotonic_ns()}"
        _IMAGE_ARRAY_READ_SCOPE_LEASE = _sps_quota.begin_cache_lease('psd.read_scope', lease)
    return _IMAGE_ARRAY_READ_SCOPE_DEPTH


def end_image_array_read_scope() -> None:
    global _IMAGE_ARRAY_READ_SCOPE_DEPTH, _IMAGE_ARRAY_READ_SCOPE_LEASE
    _IMAGE_ARRAY_READ_SCOPE_DEPTH = max(0, int(_IMAGE_ARRAY_READ_SCOPE_DEPTH) - 1)
    if _IMAGE_ARRAY_READ_SCOPE_DEPTH == 0:
        _sps_quota.end_cache_lease('psd.read_scope', _IMAGE_ARRAY_READ_SCOPE_LEASE)
        _IMAGE_ARRAY_READ_SCOPE_LEASE = ''


def clear_image_array_read_scope() -> None:
    global _IMAGE_ARRAY_READ_SCOPE_DEPTH, _IMAGE_ARRAY_READ_SCOPE_LEASE
    _IMAGE_ARRAY_READ_SCOPE_DEPTH = 0
    _sps_quota.end_cache_lease('psd.read_scope', _IMAGE_ARRAY_READ_SCOPE_LEASE)
    _IMAGE_ARRAY_READ_SCOPE_LEASE = ''

def _read_scope_cache_allowed(image) -> bool:
    try:
        if image is None:
            return False
        w, h = _image_size(image)
        # Keep scope cache bounded.  4K reads are still cached during a single
        # operation when memory is available, but never across idle frames.
        return int(w) > 0 and int(h) > 0 and int(w) * int(h) <= 4096 * 4096
    except Exception:
        return False

def _read_scope_item(image):
    try:
        if int(_IMAGE_ARRAY_READ_SCOPE_DEPTH) <= 0 or not _read_scope_cache_allowed(image):
            return None
        w, h = _image_size(image)
        key = _image_cache_key(image)
        item = _IMAGE_ARRAY_READ_SCOPE_CACHE.get(key)
        if not item:
            return None
        if tuple(item.get('size', ())) != (int(w), int(h)):
            return None
        if int(item.get('rev', -1)) != _image_pixel_revision(image):
            return None
        _IMAGE_ARRAY_READ_SCOPE_CACHE.pop(key, None)
        _IMAGE_ARRAY_READ_SCOPE_CACHE[key] = item
        return item.get('arr')
    except Exception:
        return None

def _store_read_scope_item(image, arr) -> None:
    try:
        if int(_IMAGE_ARRAY_READ_SCOPE_DEPTH) <= 0 or image is None or arr is None or not _read_scope_cache_allowed(image):
            return
        import numpy as np
        w, h = _image_size(image)
        a = np.asarray(arr, dtype=np.float32).reshape((int(w) * int(h), 4))
        key = _image_cache_key(image)
        _IMAGE_ARRAY_READ_SCOPE_CACHE.pop(key, None)
        _IMAGE_ARRAY_READ_SCOPE_CACHE[key] = {
            'rev': _image_pixel_revision(image),
            'size': (int(w), int(h)),
            'arr': a,
        }
        _sps_quota.clear_for_memory_pressure()
    except Exception:
        pass

def _invalidate_read_scope_image(image) -> None:
    try:
        _IMAGE_ARRAY_READ_SCOPE_CACHE.pop(_image_cache_key(image), None)
    except Exception:
        pass

def _float_alpha_to_plane(values, *, width: int = 0, height: int = 0, psd_scanline_order: bool = False):
    import numpy as np
    vals = np.asarray(values, dtype=np.float32).reshape((-1,))
    try:
        if bool(psd_scanline_order) and int(width or 0) > 0 and int(height or 0) > 0:
            vals = vals.reshape((int(height), int(width)))[::-1, :].reshape((-1,))
    except Exception:
        pass
    vals = np.clip(vals * 255.0 + 0.5, 0.0, 255.0)
    return vals.astype(np.uint8, copy=False).tobytes()

def _mark_image_pixels_changed(image, arr=None) -> None:
    try:
        if image is None:
            return
        image[_IMAGE_PIXEL_REV_PROP] = _image_pixel_revision(image) + 1
        _invalidate_read_scope_image(image)
        if arr is not None and _image_cache_allowed(image):
            _cache_image_array(image, arr)
        else:
            _IMAGE_ARRAY_CACHE.pop(_image_cache_key(image), None)
        # Blender/Image Editor paint can modify RGB while alpha stays zero.  Mark
        # such buffers explicitly so the flat layer compositor and PSD exporter
        # do not treat valid paint as transparent.  Eraser paths clear RGB or set
        # intentionally_empty/alpha_authoritative before this point.
        try:
            _skip_large_mark_scan = False
            try:
                import numpy as np
                if arr is not None and bool(image.get('smart_paint_suite_layer_image', False)):
                    _px_count = int(np.asarray(arr).size // 4)
                    _sps_flagged_pixels = bool(image.get('smart_paint_suite_alpha_authoritative', False) or image.get('smart_paint_suite_dirty_from_master', False) or image.get('smart_paint_suite_fast_visible_write', False))
                    _sps_known_empty = bool(image.get('smart_paint_suite_intentionally_empty', False) or image.get('smart_paint_suite_clear_deferred', False) or image.get('smart_paint_suite_lazy_blank_layer', False))
                    _skip_large_mark_scan = bool(_px_count > 1024 * 1024 and (_sps_flagged_pixels or _sps_known_empty))
                    if _skip_large_mark_scan and _sps_flagged_pixels:
                        image['smart_paint_suite_alpha_authoritative'] = True
                        for key_prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer'):
                            try:
                                if key_prop in image:
                                    del image[key_prop]
                            except Exception:
                                pass
            except Exception:
                _skip_large_mark_scan = False
            if arr is not None and bool(image.get('smart_paint_suite_layer_image', False)) and not _skip_large_mark_scan:
                import numpy as np
                a = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
                alpha = np.clip(a[:, 3], 0.0, 1.0)
                clear_rgb = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
                try:
                    c = image.get('smart_paint_suite_clear_color', None)
                    if c is not None and len(c) >= 3:
                        clear_rgb = np.asarray(tuple(float(v) for v in c[:3]), dtype=np.float32).reshape((1, 3))
                except Exception:
                    pass
                rgb_delta = np.max(np.abs(a[:, :3] - clear_rgb), axis=1)
                has_alpha = bool(np.max(alpha) > (1.0 / 4096.0))
                has_rgb = bool(np.max(rgb_delta) > (1.0 / 1024.0))
                suppress_rgb_fallback = False
                try:
                    suppress_rgb_fallback = bool(image.get('smart_paint_suite_suppress_rgb_alpha_fallback_once', False))
                    if 'smart_paint_suite_suppress_rgb_alpha_fallback_once' in image:
                        del image['smart_paint_suite_suppress_rgb_alpha_fallback_once']
                except Exception:
                    suppress_rgb_fallback = False
                if has_alpha:
                    image['smart_paint_suite_alpha_authoritative'] = True
                    for key_prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer'):
                        try:
                            if key_prop in image:
                                del image[key_prop]
                        except Exception:
                            pass
                elif has_rgb and not suppress_rgb_fallback:
                    # RGB-only pixels are not promoted to visible alpha here.
                    # Native master-delta commits solve real brush coverage before
                    # writing the private layer; raw layer buffers must keep alpha
                    # authoritative to avoid horizontal/banded corruption.
                    image['smart_paint_suite_rgb_only_alpha_zero_seen'] = True
        except Exception:
            pass
        try:
            _COMPOSITE_ARRAY_CACHE.clear()
        except Exception:
            pass
        # A private layer image is the source of truth for the layer.  Whenever
        # its pixels change, any flattened lazy/master preview that was derived
        # from an older state must be dropped; otherwise visibility toggles can
        # resurrect an old public master and re-apply stale brush strokes.
        try:
            if bool(image.get('smart_paint_suite_layer_image', False)):
                try:
                    image['smart_paint_suite_layer_authoritative_revision'] = int(image.get('smart_paint_suite_layer_authoritative_revision', 0) or 0) + 1
                except Exception:
                    pass
                _mat_name = str(image.get('smart_paint_suite_material', '') or '')
                _ch = str(image.get('smart_paint_suite_channel', '') or '').upper()
                if _mat_name and _ch:
                    try:
                        for _mat in getattr(bpy.data, 'materials', ()):  # invalidate the owning material only
                            try:
                                if str(getattr(_mat, 'name', '') or '') == _mat_name:
                                    invalidate_lazy_psd_material_preview_cache(_mat, _ch)
                                    try:
                                        _mat['sps_layer_authoritative_revision_' + _ch] = int(_mat.get('sps_layer_authoritative_revision_' + _ch, 0) or 0) + 1
                                    except Exception:
                                        pass
                                    break
                            except Exception:
                                continue
                    except Exception:
                        invalidate_lazy_psd_material_preview_cache(None, _ch)
        except Exception:
            pass
    except Exception:
        pass

def _invalidate_image_cache(image) -> None:
    try:
        _IMAGE_ARRAY_CACHE.pop(_image_cache_key(image), None)
        _invalidate_read_scope_image(image)
    except Exception:
        pass

def _image_revision_key(image) -> str:
    if image is None:
        return 'none'
    try:
        name = str(getattr(image, 'name', '') or '')
    except Exception:
        name = ''
    try:
        size = f'{int(image.size[0])}x{int(image.size[1])}'
    except Exception:
        size = '0x0'
    return f'{name}:{size}:{_image_pixel_revision(image)}'


def _array_crc_stamp(image, arr) -> tuple[int, int, int]:
    try:
        w, h = _image_size(image)
        import numpy as np
        a4 = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
        # A full CRC over a 4096x4096 RGBA float buffer touches ~256 MiB and can
        # stall Blender during Add Layer / active-layer selection.  Exact pixel
        # deltas are still kept in the session baseline array; the stamp is only a
        # cheap invalidation token, so large documents use the existing sampled
        # stamp path.
        if int(w) * int(h) > int(2048 * 2048):
            return _array_sample_stamp(a4, int(w), int(h), samples=192)
        return (int(w), int(h), int(zlib.crc32(np.ascontiguousarray(a4.reshape(-1), dtype=np.float32).tobytes()) & 0xffffffff))
    except Exception:
        return _image_pixel_crc(image)


def _clamp01(v: float) -> float:
    try:
        return 0.0 if v < 0.0 else (1.0 if v > 1.0 else float(v))
    except Exception:
        return 0.0


def _recover_visible_master_rows_to_layer_array(image, layer_arr, rows, baseline_rgb, current_rgb, baseline_alpha=None, current_alpha=None, *, tolerance: float = 1.0 / 4096.0, context=None):
    """Recover a visible-master brush delta into a private layer buffer.

    The public master image is usually an already-composited target.  Copying its
    RGBA values directly into a private layer destroys source alpha when the
    document/background is opaque.  This helper reconstructs continuous source
    coverage from the master RGB delta, preferring the active Blender brush colour
    when available, and applies that source over the current private-layer pixels.
    """
    try:
        np = _np_module()
        if np is None:
            return False
        rows = np.asarray(rows, dtype=np.int64).reshape((-1,))
        if rows.size <= 0:
            return False
        arr = np.asarray(layer_arr, dtype=np.float32).reshape((-1, 4))
        rows = rows[np.logical_and(rows >= 0, rows < arr.shape[0])]
        if rows.size <= 0:
            return False
        B = np.clip(np.asarray(baseline_rgb, dtype=np.float32).reshape((rows.size, 3)), 0.0, 1.0)
        T = np.clip(np.asarray(current_rgb, dtype=np.float32).reshape((rows.size, 3)), 0.0, 1.0)
        old_rgb = np.clip(arr[rows, :3], 0.0, 1.0)
        old_alpha = np.clip(arr[rows, 3], 0.0, 1.0)
        handled = None
        try:
            handled = _apply_known_brush_color_to_layer_rows(
                image,
                arr,
                rows,
                B,
                T,
                old_rgb,
                old_alpha,
                baseline_alpha=baseline_alpha,
                current_alpha=current_alpha,
                tolerance=tolerance,
                context=context,
            )
        except Exception:
            handled = None
        if handled is None:
            handled = np.zeros((rows.size,), dtype=bool)
        else:
            handled = np.asarray(handled, dtype=bool).reshape((-1,))
            if handled.size != rows.size:
                handled = np.zeros((rows.size,), dtype=bool)
        remaining = np.logical_not(handled)
        if bool(np.any(remaining)):
            idx = np.nonzero(remaining)[0]
            rr = rows[idx]
            B2 = B[idx]
            T2 = T[idx]
            eps = max(1.0 / 4096.0, 1.0e-6)
            change_tol = max(float(tolerance), eps)
            coverage = None
            alpha_locked = None
            # If the master really contains fractional alpha, preserve it.  Do
            # not use saturated document alpha=1 as brush alpha; that is just the
            # opaque composited target.  Solve coverage from alpha-over instead
            # of using current alpha directly, so painting over existing soft
            # pixels keeps the correct incremental brush opacity.
            try:
                if baseline_alpha is not None and current_alpha is not None:
                    ba = np.clip(np.asarray(baseline_alpha, dtype=np.float32).reshape((-1,))[idx], 0.0, 1.0)
                    ca = np.clip(np.asarray(current_alpha, dtype=np.float32).reshape((-1,))[idx], 0.0, 1.0)
                    cov_a = np.clip((ca - ba) / np.maximum(1.0 - ba, eps), 0.0, 1.0).astype(np.float32, copy=False)
                    frac = np.logical_and(cov_a > eps, np.logical_and(ca < (1.0 - eps), ba < (1.0 - eps)))
                    if bool(np.any(frac)):
                        coverage = np.zeros((idx.size,), dtype=np.float32)
                        coverage[frac] = cov_a[frac]
                        alpha_locked = frac
            except Exception:
                coverage = None
                alpha_locked = None
            if coverage is None:
                coverage = np.zeros((idx.size,), dtype=np.float32)
                alpha_locked = np.zeros((idx.size,), dtype=bool)
            elif alpha_locked is None:
                alpha_locked = np.zeros((idx.size,), dtype=bool)
            # Try active brush colour once more for rows that the strict fast path
            # could not handle, then fall back to continuous contrast coverage.
            brush_rgb = None
            try:
                brush_rgb = _brush_rgb_for_layer_delta(image, context)
            except Exception:
                brush_rgb = None
            src_rgb = None
            known_src_rows = None
            if brush_rgb is not None:
                try:
                    C = np.clip(np.asarray(brush_rgb, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
                    denom = C - B2
                    valid = np.abs(denom) > eps
                    with np.errstate(divide='ignore', invalid='ignore'):
                        ratio = (T2 - B2) / np.where(valid, denom, 1.0)
                    valid = np.logical_and(valid, np.logical_and(ratio >= -0.05, ratio <= 1.05))
                    cnt = np.sum(valid, axis=1)
                    rc = np.clip(ratio, 0.0, 1.0)
                    cov = np.sum(np.where(valid, rc, 0.0), axis=1) / np.maximum(cnt.astype(np.float32), 1.0)
                    recon = B2 + np.clip(cov, 0.0, 1.0)[:, None] * (C - B2)
                    err = np.max(np.abs(recon - T2), axis=1)
                    known_src_rows = np.logical_and(cnt > 0, err <= max(change_tol * 0.5, eps * 8.0))
                    if bool(np.any(known_src_rows)):
                        unlocked = np.logical_and(known_src_rows, np.logical_not(alpha_locked))
                        if bool(np.any(unlocked)):
                            coverage[unlocked] = np.maximum(coverage[unlocked], np.clip(cov[unlocked], 0.0, 1.0))
                        src_rgb = np.broadcast_to(C, (idx.size, 3)).copy()
                except Exception:
                    src_rgb = None
                    known_src_rows = None
            unset = coverage <= eps
            if bool(np.any(unset)):
                delta = np.max(np.abs(T2 - B2), axis=1)
                coverage[unset] = np.clip(delta[unset] * 1.5, 0.0, 1.0)
            paint = coverage > (0.5 / 255.0)
            if bool(np.any(paint)):
                cov = np.clip(coverage[paint], 0.0, 1.0)
                wr = rr[paint]
                if src_rgb is not None and known_src_rows is not None:
                    known_paint = np.asarray(known_src_rows, dtype=bool)[paint]
                    alpha_paint = np.asarray(alpha_locked, dtype=bool)[paint]
                    src = (T2[paint] - B2[paint] * (1.0 - cov[:, None])) / np.maximum(cov[:, None], eps)
                    if bool(np.any(known_paint)):
                        src[known_paint] = src_rgb[paint][known_paint]
                    if bool(np.any(alpha_paint)) and src_rgb is not None:
                        src[alpha_paint] = src_rgb[paint][alpha_paint]
                else:
                    alpha_paint = np.asarray(alpha_locked, dtype=bool)[paint]
                    src = (T2[paint] - B2[paint] * (1.0 - cov[:, None])) / np.maximum(cov[:, None], eps)
                    if bool(np.any(alpha_paint)):
                        # Straight-alpha paint targets often store the brush RGB
                        # directly at the soft edge.  In that case inverse RGB
                        # compositing against the baseline creates black/clipped
                        # halos; use the target RGB as the layer colour and the
                        # alpha-derived coverage as opacity.
                        src[alpha_paint] = T2[paint][alpha_paint]
                src = np.clip(src, 0.0, 1.0)
                oa = np.clip(arr[wr, 3], 0.0, 1.0)
                orgb = np.clip(arr[wr, :3], 0.0, 1.0)
                new_a = np.clip(cov + oa * (1.0 - cov), 0.0, 1.0)
                premul = src * cov[:, None] + orgb * (oa * (1.0 - cov))[:, None]
                arr[wr, :3] = np.where(new_a[:, None] > eps, premul / np.maximum(new_a[:, None], eps), src)
                arr[wr, 3] = new_a
                try:
                    _mark_layer_dirty_bbox_from_rows(image, wr)
                except Exception:
                    pass
        changed = False
        try:
            changed = bool(np.any(handled))
        except Exception:
            changed = False
        try:
            if 'paint' in locals():
                changed = bool(changed or np.any(paint))
        except Exception:
            pass
        if changed:
            try:
                if image is not None:
                    image['smart_paint_suite_dirty_from_master'] = True
                    image['smart_paint_suite_alpha_authoritative'] = True
                    for _prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                        if _prop in image:
                            del image[_prop]
            except Exception:
                pass
        return bool(changed)
    except Exception:
        return False



def _image_size(image) -> tuple[int, int]:
    try:
        if image is None:
            return 0, 0
        actual_w = int(image.size[0]); actual_h = int(image.size[1])
        lazy_w = int(image.get('smart_paint_suite_lazy_width', 0) or 0)
        lazy_h = int(image.get('smart_paint_suite_lazy_height', 0) or 0)
        if lazy_w <= 0 or lazy_h <= 0:
            try:
                decl = image.get('smart_paint_suite_clear_initialized_size', None)
                if decl is not None and len(decl) >= 2:
                    lazy_w = int(decl[0]); lazy_h = int(decl[1])
            except Exception:
                pass
        try:
            lazy_pending = bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_blank_layer', False))
        except Exception:
            lazy_pending = False
        if lazy_w > 0 and lazy_h > 0 and (lazy_pending or actual_w * actual_h <= 1 or ((actual_w != lazy_w or actual_h != lazy_h) and actual_w * actual_h <= 4)):
            return lazy_w, lazy_h
        return actual_w, actual_h
    except Exception:
        return 0, 0




def _sps_parse_bbox4(value):
    try:
        if value is None:
            return None
        if isinstance(value, str):
            parts = [p.strip() for p in value.replace(';', ',').split(',') if p.strip()]
        else:
            parts = list(value)
        if len(parts) < 4:
            return None
        x0, y0, x1, y1 = [int(float(v)) for v in parts[:4]]
        return x0, y0, x1, y1
    except Exception:
        return None


def _sps_sparse_rgba_patch_to_canvas(image, width: int | None = None, height: int | None = None):
    """Return a full straight-RGBA canvas synthesized from an authoritative sparse patch.

    The sparse patch is the source of truth for a newly-painted lazy layer until the
    user explicitly materializes it.  Visibility toggles and PSD saves must therefore
    read this patch instead of treating the 1x1 proxy as an empty transparent layer.
    """
    np = _np_module()
    if np is None or image is None:
        return None
    try:
        patch_b64 = str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '')
        patch_box = _sps_parse_bbox4(image.get('smart_paint_suite_sparse_rgba_patch_bbox', None))
        if not patch_b64 or patch_box is None:
            return None
        x0, y0, x1, y1 = patch_box
        w = int(width or 0)
        h = int(height or 0)
        if w <= 0 or h <= 0:
            w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return None
        x0 = max(0, min(int(w), int(x0))); x1 = max(0, min(int(w), int(x1)))
        y0 = max(0, min(int(h), int(y0))); y1 = max(0, min(int(h), int(y1)))
        if x1 <= x0 or y1 <= y0:
            return None
        import base64 as _sps_b64, zlib as _sps_zlib
        raw = _sps_zlib.decompress(_sps_b64.b64decode(patch_b64.encode('ascii')))
        crop = np.frombuffer(raw, dtype=np.float32).reshape(((y1 - y0) * (x1 - x0), 4)).copy()
        crop = np.clip(crop.reshape((y1 - y0, x1 - x0, 4)), 0.0, 1.0)
        try:
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
        except Exception:
            rgba = (1.0, 1.0, 1.0, 0.0)
        out = np.empty((int(h), int(w), 4), dtype=np.float32)
        out[:, :, 0] = rgba[0]; out[:, :, 1] = rgba[1]; out[:, :, 2] = rgba[2]; out[:, :, 3] = rgba[3]
        out[y0:y1, x0:x1, :] = crop
        return out.reshape((int(w) * int(h), 4)).astype(np.float32, copy=False)
    except Exception:
        return None

def _read_image_array(image, width: int | None = None, height: int | None = None):
    """Return an Nx4 float32 array for a Blender image, resized by nearest sample if needed."""
    if image is None:
        return None
    try:
        authoritative = bool(smart_paint_layer_image_has_authoritative_user_pixels(image))
    except Exception:
        authoritative = False
    try:
        dst_w = int(width or image.get('smart_paint_suite_lazy_width', 0) or image.size[0] or 1)
        dst_h = int(height or image.get('smart_paint_suite_lazy_height', 0) or image.size[1] or 1)
        sparse_canvas = _sps_sparse_rgba_patch_to_canvas(image, dst_w, dst_h)
        if sparse_canvas is not None:
            return sparse_canvas
    except Exception:
        pass
    try:
        # Only a still-lazy transparent proxy may be treated as blank without
        # reading Image.pixels.  A materialized image can keep stale
        # smart_paint_suite_intentionally_empty metadata after Blender's native
        # Texture Paint writes directly to RGB/alpha without touching Smart
        # Paint's custom revision counter; skipping the read here exports a
        # white/empty PSD layer.
        try:
            dirty_pixels = bool(getattr(image, 'is_dirty', False))
        except Exception:
            dirty_pixels = False
        known_blank = bool(image.get('smart_paint_suite_lazy_blank_layer', False)) and not dirty_pixels
        if known_blank:
            import numpy as np
            dst_w = int(width or image.get('smart_paint_suite_lazy_width', 0) or image.size[0] or 1)
            dst_h = int(height or image.get('smart_paint_suite_lazy_height', 0) or image.size[1] or 1)
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
            arr = np.empty((max(1, dst_w) * max(1, dst_h), 4), dtype=np.float32)
            arr[:, 0] = rgba[0]; arr[:, 1] = rgba[1]; arr[:, 2] = rgba[2]; arr[:, 3] = rgba[3]
            return arr
    except Exception:
        pass
    try:
        if not authoritative:
            materialize_lazy_psd_layer_image(image)
    except Exception:
        pass
    src_w, src_h = _image_size(image)
    if src_w <= 0 or src_h <= 0:
        return None
    try:
        import numpy as np
        bypass_cache = False
        try:
            bypass_cache = bool(
                getattr(image, 'is_dirty', False)
                or image.get('smart_paint_suite_alpha_authoritative', False)
                or image.get('smart_paint_suite_dirty_from_master', False)
                or image.get('smart_paint_suite_exact_fallback_commit', False)
                or image.get('smart_paint_suite_save_exact_master_delta', False)
                or image.get('smart_paint_suite_direct_layer_dirty', False)
                or image.get('smart_paint_suite_bodypaint_direct_authoritative', False)
                or image.get('smart_paint_suite_painted_since_last_projection', False)
                or image.get('smart_paint_suite_user_edited', False)
                or image.get('smart_paint_suite_dirty_bbox', False)
            )
        except Exception:
            bypass_cache = False
        if not bypass_cache:
            cached = _cached_image_array(image, width, height)
            if cached is not None:
                return cached
        buf = np.empty(src_w * src_h * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
        arr = buf.reshape((src_h, src_w, 4))
        dst_w = int(width or src_w)
        dst_h = int(height or src_h)
        if dst_w != src_w or dst_h != src_h:
            ys = (np.linspace(0, src_h - 1, dst_h)).astype(np.int64)
            xs = (np.linspace(0, src_w - 1, dst_w)).astype(np.int64)
            arr = arr[ys][:, xs]
            return np.clip(arr.reshape((dst_w * dst_h, 4)), 0.0, 1.0).astype(np.float32, copy=False)
        out = np.clip(arr.reshape((dst_w * dst_h, 4)), 0.0, 1.0).astype(np.float32, copy=False)
        _cache_image_array(image, out)
        return out
    except Exception:
        if width is not None and height is not None and (int(width) != src_w or int(height) != src_h):
            return None
        try:
            buf = array('f', [0.0]) * (src_w * src_h * 4)
            image.pixels.foreach_get(buf)
            return buf
        except Exception:
            return None




def _sps_rgb_delta_fallback_mask_for_alpha(arr, image=None, *, threshold: float = 1.0 / 1024.0):
    try:
        import numpy as np
        a = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
        clear_rgb = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
        try:
            if image is not None:
                c = image.get('smart_paint_suite_clear_color', None)
                if c is not None and len(c) >= 3:
                    clear_rgb = np.asarray(tuple(float(v) for v in c[:3]), dtype=np.float32).reshape((1, 3))
        except Exception:
            pass
        delta = np.max(np.abs(a[:, :3] - clear_rgb), axis=1)
        mask = np.clip(delta * 1.5, 0.0, 1.0).astype(np.float32)
        mask[delta <= float(threshold)] = 0.0
        if mask.size and float(np.max(mask)) > 0.0:
            return mask.astype(np.float32, copy=False)
    except Exception:
        pass
    return None

def _sps_rgb_alpha_fallback_allowed_for_image(image, *, for_export: bool = False) -> bool:
    try:
        if image is None:
            return bool(for_export)
        if bool(image.get('smart_paint_suite_rgb_alpha_fallback', False)):
            return True
        if bool(image.get('smart_paint_suite_dirty_from_master', False)):
            return True
        if bool(image.get('smart_paint_suite_export_rgb_alpha_fallback', False)):
            return True
        if for_export and bool(getattr(image, 'is_dirty', False)) and not bool(image.get('smart_paint_suite_intentionally_empty', False)):
            return True
    except Exception:
        pass
    return False


def _sps_layer_alpha_painter_policy(arr, *, background: bool = False, image=None, for_export: bool = False):
    try:
        import numpy as np
        a = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
        if background:
            return np.ones(a.shape[0], dtype=np.float32)
        raw = np.clip(a[:, 3], 0.0, 1.0).astype(np.float32, copy=False)
        # SPS48: alpha is authoritative.  Existing layer buffers are not allowed
        # to synthesize alpha from RGB deltas during composition/export; that was
        # the source of broken bands and changed brush edges after toggling layers.
        if raw.size and float(np.max(raw)) > (1.0 / 4096.0):
            try:
                if image is not None:
                    image['smart_paint_suite_alpha_authoritative'] = True
                    for _prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer'):
                        if _prop in image:
                            del image[_prop]
            except Exception:
                pass
        return raw
    except Exception:
        return None


def _layer_image_alpha_for_paint(arr, *, background: bool = False, image=None):
    """Coverage alpha for Smart Paint layer compositing.

    Uses a Painter-style policy: real alpha is primary, but RGB-only Blender
    brush strokes are preserved when the layer is dirty or has an explicit Smart
    Paint paint-delta marker.  Eraser output remains transparent when RGB has
    been cleared to the layer clear color.
    """
    alpha = _sps_layer_alpha_painter_policy(arr, background=background, image=image, for_export=False)
    if alpha is not None:
        return alpha
    try:
        import numpy as np
        a = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
        return np.ones(a.shape[0], dtype=np.float32) if background else np.clip(a[:, 3], 0.0, 1.0).astype(np.float32, copy=False)
    except Exception:
        return None

def _layer_image_alpha_for_export(item, arr):
    """Return PSD layer alpha while preserving every layer's paint data."""
    try:
        image = item.get('image') if isinstance(item, dict) else None
        background = bool(item.get('background')) if isinstance(item, dict) else False
        alpha = _sps_layer_alpha_painter_policy(arr, background=background, image=image, for_export=True)
        if alpha is not None:
            return alpha
    except Exception:
        pass
    try:
        return _layer_image_alpha_for_paint(arr, background=bool(item.get('background')), image=item.get('image'))
    except Exception:
        return None

def _layer_array_has_visible_data(arr, image=None, *, background: bool = False) -> bool:
    np = _np_module()
    if np is None or arr is None:
        return False
    try:
        a = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
        if a.size <= 0:
            return False
        if bool(np.max(a[:, 3]) > (1.0 / 4096.0)):
            return True
        clear_rgb = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
        try:
            c = image.get('smart_paint_suite_clear_color', None) if image is not None else None
            if c is not None and len(c) >= 3:
                clear_rgb = np.asarray(tuple(float(v) for v in c[:3]), dtype=np.float32).reshape((1, 3))
        except Exception:
            pass
        return bool(np.max(np.abs(a[:, :3] - clear_rgb)) > (1.0 / 1024.0))
    except Exception:
        return False


def _layer_backup_image_name(image) -> str:
    try:
        return str(image.get('smart_paint_suite_backup_image', '') or '')
    except Exception:
        return ''


def _ensure_layer_backup_image(image, width: int, height: int):
    if image is None:
        return None
    try:
        # Do not create persistent 4K/8K backup images.  Older versions saved
        # *_SPS_PixelBackup images into .blend files; they caused huge files,
        # slow startup, and unrelated proxy data accumulation.  Small backups are
        # still allowed transiently for legacy safety, but cleanup removes them
        # before they become saved production data.
        if int(width) * int(height) > 1024 * 1024:
            return None
    except Exception:
        pass
    try:
        name = _layer_backup_image_name(image)
        backup = bpy.data.images.get(name) if name else None
        if backup is None:
            base = str(getattr(image, 'name', 'Layer'))
            name = base + '_SPS_PixelBackup'
            backup = bpy.data.images.get(name) or bpy.data.images.new(name, max(1, int(width)), max(1, int(height)), alpha=True, float_buffer=False)
            try:
                # Pixel backups are transient recovery helpers.  They must not be
                # saved into production .blend files as heavy proxy data.
                backup.use_fake_user = False
            except Exception:
                pass
            try:
                backup['smart_paint_suite_layer_backup'] = True
                backup['smart_paint_suite_source_image'] = base
                image['smart_paint_suite_backup_image'] = backup.name
            except Exception:
                pass
        try:
            if int(backup.size[0]) != int(width) or int(backup.size[1]) != int(height):
                backup.scale(max(1, int(width)), max(1, int(height)))
        except Exception:
            pass
        return backup
    except Exception:
        return None


def protect_layer_image_pixels(image, arr=None) -> bool:
    """Refresh the hidden non-empty backup for one private layer image."""
    if image is None:
        return False
    try:
        if bool(image.get('smart_paint_suite_lazy_psd_pending', False)):
            return False
    except Exception:
        pass
    try:
        if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_selection_mask', False)):
            return False
        if not bool(image.get('smart_paint_suite_layer_image', False)):
            return False
    except Exception:
        return False
    np = _np_module()
    if np is None:
        return False
    try:
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return False
        # Hidden full-size backup images are a recovery aid, not part of the
        # saved layer stack.  Creating/updating them for 2K/4K layers during Save
        # or visibility updates makes Blender appear frozen.  Keep backups only
        # for small layers unless explicitly forced by a diagnostic path.
        try:
            if int(w) * int(h) > 1024 * 1024 and not bool(image.get('smart_paint_suite_force_large_pixel_backup', False)):
                return False
        except Exception:
            pass
        if arr is None:
            arr = _image_array_np(image, use_cache=False)
        if arr is None:
            return False
        a = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
        if not _layer_array_has_visible_data(a, image=image):
            return False
        backup = _ensure_layer_backup_image(image, w, h)
        if backup is None:
            return False
        ok = _write_image_array_np(backup, a)
        if ok:
            try:
                backup['smart_paint_suite_layer_backup'] = True
                backup['smart_paint_suite_source_image'] = getattr(image, 'name', '')
                backup['smart_paint_suite_material'] = image.get('smart_paint_suite_material', '')
                backup['smart_paint_suite_layer_id'] = image.get('smart_paint_suite_layer_id', '')
                backup['smart_paint_suite_channel'] = image.get('smart_paint_suite_channel', '')
                image['smart_paint_suite_backup_image'] = backup.name
                image['smart_paint_suite_last_nonempty_backup'] = backup.name
                if 'smart_paint_suite_intentionally_empty' in image:
                    del image['smart_paint_suite_intentionally_empty']
            except Exception:
                pass
        return bool(ok)
    except Exception:
        return False


def restore_layer_image_pixels_if_lost(image) -> bool:
    """Restore a private layer from its last known non-empty backup if it became empty."""
    if image is None:
        return False
    try:
        if bool(image.get('smart_paint_suite_lazy_psd_pending', False)):
            return False
    except Exception:
        pass
    try:
        if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_selection_mask', False)):
            return False
        if not bool(image.get('smart_paint_suite_layer_image', False)):
            return False
    except Exception:
        return False
    try:
        if bool(image.get('smart_paint_suite_intentionally_empty', False)):
            return False
    except Exception:
        pass
    np = _np_module()
    if np is None:
        return False
    try:
        try:
            w0, h0 = _image_size(image)
            if int(w0) * int(h0) > 1024 * 1024 and not bool(image.get('smart_paint_suite_force_large_pixel_backup', False)):
                return False
        except Exception:
            pass
        cur = _image_array_np(image, use_cache=False)
        if cur is not None and _layer_array_has_visible_data(cur, image=image):
            # Healthy current data: keep the backup fresh.
            protect_layer_image_pixels(image, cur)
            return False
        name = _layer_backup_image_name(image) or str(image.get('smart_paint_suite_last_nonempty_backup', '') or '')
        backup = bpy.data.images.get(name) if name else None
        if backup is None:
            return False
        bw, bh = _image_size(backup)
        if bw <= 0 or bh <= 0:
            return False
        barr = _image_array_np(backup, use_cache=False)
        if barr is None or not _layer_array_has_visible_data(barr, image=backup):
            return False
        _resize_image_to(image, bw, bh)
        ok = _write_image_array_np(image, barr)
        if ok:
            try:
                image['smart_paint_suite_restored_from_backup'] = True
                image['smart_paint_suite_backup_restore_count'] = int(image.get('smart_paint_suite_backup_restore_count', 0) or 0) + 1
            except Exception:
                pass
        return bool(ok)
    except Exception:
        return False


def protect_layer_stack_pixels(material=None, channel: str = 'BASE_COLOR') -> int:
    """Snapshot every non-empty private layer buffer for a material/channel."""
    count = 0
    try:
        if material is None:
            return 0
        channel = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return 0
        attr = layer_channel_image_attr(channel)
        for layer in getattr(settings, 'layers', ()) or ():
            try:
                img = bpy.data.images.get(str(getattr(layer, attr, '') or ''))
                if img is not None and protect_layer_image_pixels(img):
                    count += 1
            except Exception:
                pass
    except Exception:
        pass
    return count


def restore_layer_stack_pixels_if_lost(material=None, channel: str = 'BASE_COLOR') -> int:
    count = 0
    try:
        if material is None:
            return 0
        channel = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return 0
        attr = layer_channel_image_attr(channel)
        for layer in getattr(settings, 'layers', ()) or ():
            try:
                img = bpy.data.images.get(str(getattr(layer, attr, '') or ''))
                if img is not None and restore_layer_image_pixels_if_lost(img):
                    count += 1
            except Exception:
                pass
    except Exception:
        pass
    return count



def mark_layer_stack_pixels_current(material=None, channel: str = 'BASE_COLOR') -> int:
    """Invalidate Smart Paint pixel caches from current Blender Image buffers.

    Native Texture Paint and external image edits can mutate Image.pixels without
    touching Smart Paint's custom revision counter.  Explicit Save and layer
    visibility/mask operations call this once so subsequent composition/export
    reads the pixels that Blender currently holds, not an old transparent cache.
    """
    count = 0
    try:
        if material is None:
            return 0
        channel = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return 0
        attr = layer_channel_image_attr(channel)
        seen = set()
        def _touch(img):
            nonlocal count
            if img is None:
                return
            try:
                key = int(img.as_pointer())
            except Exception:
                key = id(img)
            if key in seen:
                return
            seen.add(key)
            try:
                # Visibility toggles are explicit metadata operations.  The real
                # paint commit has already written the active layer through
                # _write_image_array_np(); doing a full foreach_get()+pixel scan for
                # every layer here is pure overhead on 2K/4K stacks.  Bump the
                # revision and invalidate caches only.  Save paths that need exact
                # current pixels do not set this material flag.
                try:
                    fast_mark = bool(material.get('sps_fast_pixel_mark_only_' + channel, False)) or bool(material.get('sps_stack_metadata_edit_in_progress_' + channel, False))
                except Exception:
                    fast_mark = False
                if fast_mark:
                    try:
                        img[_IMAGE_PIXEL_REV_PROP] = _image_pixel_revision(img) + 1
                        _invalidate_image_cache(img)
                        count += 1
                    except Exception:
                        pass
                    return
                # Save/visibility boundaries must capture Blender's current Image
                # buffer exactly.  Do not route non-lazy images through the normal
                # smart empty/lazy reader here: stale flags such as
                # intentionally_empty can otherwise turn freshly painted private
                # layers or masks back into blank white/transparent arrays during
                # PSD export.
                arr = None
                try:
                    is_lazy = bool(img.get('smart_paint_suite_lazy_psd_pending', False)) or bool(img.get('smart_paint_suite_lazy_blank_layer', False))
                except Exception:
                    is_lazy = False
                np = _np_module()
                if not is_lazy and np is not None:
                    aw = int(img.size[0]); ah = int(img.size[1])
                    if aw > 0 and ah > 0:
                        buf = np.empty(aw * ah * 4, dtype=np.float32)
                        img.pixels.foreach_get(buf)
                        arr = np.clip(buf.reshape((ah, aw, 4)), 0.0, 1.0)
                        dw, dh = _image_size(img)
                        if int(dw) != aw or int(dh) != ah:
                            ys = (np.linspace(0, max(0, ah - 1), int(dh))).astype(np.int64)
                            xs = (np.linspace(0, max(0, aw - 1), int(dw))).astype(np.int64)
                            arr = arr[ys][:, xs]
                        arr = arr.reshape((-1, 4)).astype(np.float32, copy=False)
                if arr is None:
                    arr = _image_array_np(img, use_cache=False)
                if arr is None:
                    return
                _mark_image_pixels_changed(img, arr)
                count += 1
            except Exception:
                return
        for layer in getattr(settings, 'layers', ()) or ():
            try:
                img = bpy.data.images.get(str(getattr(layer, attr, '') or ''))
                _touch(img)
            except Exception:
                pass
            try:
                mask_img = bpy.data.images.get(str(getattr(layer, 'mask_image', '') or ''))
                _touch(mask_img)
            except Exception:
                pass
    except Exception:
        pass
    return count


def _sps_blend_key(mode: str) -> str:
    try:
        key = str(mode or 'MIX').upper().replace('-', '_').replace(' ', '_')
        if key in {'NORMAL', 'SRC_OVER', 'SOURCE_OVER'}:
            return 'MIX'
        if key in {'PASS', 'PASSTHROUGH', 'PASS_THROUGH'}:
            return 'PASS_THROUGH'
        if key in {'DISABLED', 'OFF'}:
            return 'DISABLE'
        if key in {'LINEAR_DODGE_ADD', 'LDODGE'}:
            return 'LINEAR_DODGE'
        if key in {'ADD_SUB', 'ADDSUB', 'SIGNED_ADDITION'}:
            return 'SIGNED_ADD'
        if key in {'HUE'}:
            return 'TINT'
        if key in {'LUMINOSITY', 'LUMINANCE', 'LIGHTNESS'}:
            return 'VALUE'
        return key
    except Exception:
        return 'MIX'


def _rgb_to_hsv_np(rgb):
    import numpy as np
    rgb = np.clip(np.asarray(rgb, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
    r = rgb[:, 0]; g = rgb[:, 1]; b = rgb[:, 2]
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    d = mx - mn
    h = np.zeros_like(mx)
    mask = d > 1.0e-8
    rm = (mx == r) & mask
    gm = (mx == g) & mask
    bm = (mx == b) & mask
    h[rm] = ((g[rm] - b[rm]) / d[rm]) % 6.0
    h[gm] = ((b[gm] - r[gm]) / d[gm]) + 2.0
    h[bm] = ((r[bm] - g[bm]) / d[bm]) + 4.0
    h = (h / 6.0) % 1.0
    s = np.where(mx <= 1.0e-8, 0.0, d / np.maximum(mx, 1.0e-8))
    v = mx
    return np.stack((h, s, v), axis=1).astype(np.float32, copy=False)


def _hsv_to_rgb_np(hsv):
    import numpy as np
    hsv = np.asarray(hsv, dtype=np.float32).reshape((-1, 3))
    h = (hsv[:, 0] % 1.0) * 6.0
    s = np.clip(hsv[:, 1], 0.0, 1.0)
    v = np.clip(hsv[:, 2], 0.0, 1.0)
    i = np.floor(h).astype(np.int32)
    f = h - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    out = np.zeros((hsv.shape[0], 3), dtype=np.float32)
    m = i % 6
    for k, vals in enumerate(((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))):
        mask = m == k
        if np.any(mask):
            out[mask, 0] = vals[0][mask]
            out[mask, 1] = vals[1][mask]
            out[mask, 2] = vals[2][mask]
    return np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)


def _normal_from_rgb_np(rgb):
    import numpy as np
    n = np.clip(np.asarray(rgb, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0) * 2.0 - 1.0
    length = np.linalg.norm(n, axis=1, keepdims=True)
    return n / np.maximum(length, 1.0e-8)


def _rgb_from_normal_np(n):
    import numpy as np
    n = np.asarray(n, dtype=np.float32).reshape((-1, 3))
    length = np.linalg.norm(n, axis=1, keepdims=True)
    n = n / np.maximum(length, 1.0e-8)
    return np.clip(n * 0.5 + 0.5, 0.0, 1.0).astype(np.float32, copy=False)


def _sps_rgb_to_hsv_np(rgb):
    import numpy as np
    rgb = np.clip(np.asarray(rgb, dtype=np.float32), 0.0, 1.0)
    r = rgb[:, 0]; g = rgb[:, 1]; b = rgb[:, 2]
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    d = mx - mn
    h = np.zeros_like(mx)
    mask = d > 1.0e-8
    rm = (mx == r) & mask; gm = (mx == g) & mask; bm = (mx == b) & mask
    h[rm] = ((g[rm] - b[rm]) / d[rm]) % 6.0
    h[gm] = ((b[gm] - r[gm]) / d[gm]) + 2.0
    h[bm] = ((r[bm] - g[bm]) / d[bm]) + 4.0
    h = (h / 6.0) % 1.0
    s = np.where(mx <= 1.0e-8, 0.0, d / np.maximum(mx, 1.0e-8))
    v = mx
    return np.stack((h, s, v), axis=1).astype(np.float32, copy=False)


def _sps_hsv_to_rgb_np(hsv):
    import numpy as np
    hsv = np.asarray(hsv, dtype=np.float32)
    h = (hsv[:, 0] % 1.0) * 6.0
    s = np.clip(hsv[:, 1], 0.0, 1.0)
    v = np.clip(hsv[:, 2], 0.0, 1.0)
    i = np.floor(h).astype(np.int32)
    f = h - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    out = np.zeros((hsv.shape[0], 3), dtype=np.float32)
    m = i % 6
    vals = ((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))
    for k, triple in enumerate(vals):
        mask = m == k
        if bool(np.any(mask)):
            out[mask, 0] = triple[0][mask]
            out[mask, 1] = triple[1][mask]
            out[mask, 2] = triple[2][mask]
    return np.clip(out, 0.0, 1.0)


def _blend_rgb(dst, src, alpha, mode: str):
    try:
        import numpy as np
        mode = str(mode or 'MIX').upper()
        if mode in {'DISABLE', 'OFF', 'NONE'}:
            return np.clip(dst, 0.0, 1.0)
        if mode in {'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH'}:
            mode = 'MIX'
        src = np.clip(src, 0.0, 1.0)
        dst = np.clip(dst, 0.0, 1.0)
        a = np.clip(alpha, 0.0, 1.0)[:, None]
        eps = 1.0e-6

        def _color_dodge(d, s):
            return np.where(s >= 1.0 - eps, 1.0, np.minimum(1.0, d / np.maximum(1.0 - s, eps)))

        def _color_burn(d, s):
            return np.where(s <= eps, 0.0, 1.0 - np.minimum(1.0, (1.0 - d) / np.maximum(s, eps)))

        def _normal_whiteout(d, s, inverse=False):
            dn = np.clip(d * 2.0 - 1.0, -1.0, 1.0)
            sn = np.clip(s * 2.0 - 1.0, -1.0, 1.0)
            if inverse:
                sn[:, :2] *= -1.0
            out = np.empty_like(dn)
            out[:, 0] = dn[:, 0] + sn[:, 0]
            out[:, 1] = dn[:, 1] + sn[:, 1]
            out[:, 2] = dn[:, 2] * sn[:, 2]
            length = np.sqrt(np.maximum(np.sum(out * out, axis=1), eps))[:, None]
            return np.clip((out / length) * 0.5 + 0.5, 0.0, 1.0)

        if mode in {'ADD', 'LINEAR_DODGE'}:
            mixed = np.clip(dst + src, 0.0, 1.0)
        elif mode == 'MULTIPLY':
            mixed = dst * src
        elif mode == 'SCREEN':
            mixed = 1.0 - (1.0 - dst) * (1.0 - src)
        elif mode == 'OVERLAY':
            mixed = np.where(dst <= 0.5, 2.0 * dst * src, 1.0 - 2.0 * (1.0 - dst) * (1.0 - src))
        elif mode == 'SOFT_LIGHT':
            d = np.where(dst <= 0.25, ((16.0 * dst - 12.0) * dst + 4.0) * dst, np.sqrt(np.maximum(dst, 0.0)))
            mixed = np.where(src <= 0.5, dst - (1.0 - 2.0 * src) * dst * (1.0 - dst), dst + (2.0 * src - 1.0) * (d - dst))
        elif mode == 'HARD_LIGHT':
            mixed = np.where(src <= 0.5, 2.0 * dst * src, 1.0 - 2.0 * (1.0 - dst) * (1.0 - src))
        elif mode == 'COLOR_DODGE':
            mixed = _color_dodge(dst, src)
        elif mode == 'COLOR_BURN':
            mixed = _color_burn(dst, src)
        elif mode == 'LINEAR_BURN':
            mixed = np.clip(dst + src - 1.0, 0.0, 1.0)
        elif mode == 'VIVID_LIGHT':
            mixed = np.where(src <= 0.5, _color_burn(dst, 2.0 * src), _color_dodge(dst, 2.0 * (src - 0.5)))
        elif mode == 'LINEAR_LIGHT':
            mixed = np.clip(dst + 2.0 * src - 1.0, 0.0, 1.0)
        elif mode == 'PIN_LIGHT':
            mixed = np.where(src <= 0.5, np.minimum(dst, 2.0 * src), np.maximum(dst, 2.0 * (src - 0.5)))
        elif mode == 'SUBTRACT':
            mixed = np.clip(dst - src, 0.0, 1.0)
        elif mode == 'INVERSE_SUBTRACT':
            mixed = np.clip(src - dst, 0.0, 1.0)
        elif mode == 'DIVIDE':
            mixed = np.clip(dst / np.maximum(src, eps), 0.0, 1.0)
        elif mode == 'INVERSE_DIVIDE':
            mixed = np.clip(src / np.maximum(dst, eps), 0.0, 1.0)
        elif mode == 'SIGNED_ADD':
            mixed = np.clip(dst + (src - 0.5) * 2.0, 0.0, 1.0)
        elif mode == 'DIFFERENCE':
            mixed = np.abs(dst - src)
        elif mode == 'EXCLUSION':
            mixed = dst + src - 2.0 * dst * src
        elif mode == 'DARKEN':
            mixed = np.minimum(dst, src)
        elif mode == 'LIGHTEN':
            mixed = np.maximum(dst, src)
        elif mode in {'TINT', 'HUE', 'SATURATION', 'COLOR', 'VALUE', 'LUMINOSITY'}:
            dh = _sps_rgb_to_hsv_np(dst)
            sh = _sps_rgb_to_hsv_np(src)
            hsv = dh.copy()
            if mode in {'TINT', 'HUE'}:
                hsv[:, 0] = sh[:, 0]
            elif mode == 'SATURATION':
                hsv[:, 1] = sh[:, 1]
            elif mode == 'COLOR':
                hsv[:, 0] = sh[:, 0]; hsv[:, 1] = sh[:, 1]
            else:
                hsv[:, 2] = sh[:, 2]
            mixed = _sps_hsv_to_rgb_np(hsv)
        elif mode in {'NORMAL_MAP_COMBINE', 'NORMAL_MAP_DETAIL'}:
            mixed = _normal_whiteout(dst, src, inverse=False)
        elif mode == 'NORMAL_MAP_INVERSE_DETAIL':
            mixed = _normal_whiteout(dst, src, inverse=True)
        else:
            mixed = src
        if mode == 'REPLACE':
            return np.clip(src * a + dst * (1.0 - a), 0.0, 1.0)
        return np.clip(dst * (1.0 - a) + mixed * a, 0.0, 1.0)
    except Exception:
        return dst


def _composite_blended_source_over(dst_rgb, dst_alpha, src_rgb, src_alpha, blend_rgb):
    """Composite straight-alpha colors using Photoshop's overlap blend model."""
    import numpy as np

    dst_rgb = np.clip(np.asarray(dst_rgb, dtype=np.float32), 0.0, 1.0)
    src_rgb = np.clip(np.asarray(src_rgb, dtype=np.float32), 0.0, 1.0)
    blend_rgb = np.clip(np.asarray(blend_rgb, dtype=np.float32), 0.0, 1.0)
    dst_a = np.clip(np.asarray(dst_alpha, dtype=np.float32), 0.0, 1.0)
    src_a = np.clip(np.asarray(src_alpha, dtype=np.float32), 0.0, 1.0)
    src_a_3d = src_a[..., None]
    dst_a_3d = dst_a[..., None]
    new_a = np.clip(src_a + dst_a * (1.0 - src_a), 0.0, 1.0).astype(np.float32, copy=False)
    numerator = (
        dst_rgb * dst_a_3d * (1.0 - src_a_3d)
        + src_rgb * src_a_3d * (1.0 - dst_a_3d)
        + blend_rgb * src_a_3d * dst_a_3d
    )
    out_rgb = np.where(
        new_a[..., None] > 1.0e-8,
        numerator / np.maximum(new_a[..., None], 1.0e-8),
        blend_rgb,
    )
    return (
        np.clip(out_rgb, 0.0, 1.0).astype(np.float32, copy=False),
        new_a,
    )


def _psd_blend_key(mode: str) -> bytes:
    key = _sps_blend_key(mode)
    return {
        'MIX': b'norm',
        'PASS_THROUGH': b'pass',
        'ADD': b'lddg',
        'LINEAR_DODGE': b'lddg',
        'MULTIPLY': b'mul ',
        'SCREEN': b'scrn',
        'OVERLAY': b'over',
        'SOFT_LIGHT': b'sLit',
        'HARD_LIGHT': b'hLit',
        'COLOR_DODGE': b'div ',
        'COLOR_BURN': b'idiv',
        'LINEAR_BURN': b'lbrn',
        'SUBTRACT': b'fsub',
        'DIVIDE': b'fdiv',
        'DIFFERENCE': b'diff',
        'EXCLUSION': b'smud',
        'DARKEN': b'dark',
        'LIGHTEN': b'lite',
        'VIVID_LIGHT': b'vLit',
        'LINEAR_LIGHT': b'lLit',
        'PIN_LIGHT': b'pLit',
        'TINT': b'hue ',
        'SATURATION': b'sat ',
        'COLOR': b'colr',
        'VALUE': b'lum ',
        # The exact Smart Paint/Substance-style mode is preserved in the SPSi
        # metadata block for modes that have no single Photoshop blend key.
        'DISABLE': b'norm',
        'REPLACE': b'norm',
        'INVERSE_DIVIDE': b'norm',
        'INVERSE_SUBTRACT': b'norm',
        'SIGNED_ADD': b'norm',
        'NORMAL_MAP_COMBINE': b'norm',
        'NORMAL_MAP_DETAIL': b'norm',
        'NORMAL_MAP_INVERSE_DETAIL': b'norm',
    }.get(key, b'norm')

def _safe_layer_name(name: str, fallback: str) -> str:
    text = str(name or '').strip() or fallback
    text = text.replace('\x00', '')
    return text[:255] or fallback


def _pascal_name_block(name: str) -> bytes:
    ascii_name = ''.join(ch if 32 <= ord(ch) <= 126 else '_' for ch in name)[:255].encode('ascii', 'replace')
    data = bytes([len(ascii_name)]) + ascii_name
    pad = (4 - (len(data) % 4)) % 4
    return data + (b'\x00' * pad)


def _unicode_layer_name_block(name: str) -> bytes:
    encoded = name.encode('utf-16be', 'replace')
    data = struct.pack('>I', len(name)) + encoded
    if len(data) % 2:
        data += b'\x00'
    return b'8BIM' + b'luni' + struct.pack('>I', len(data)) + data


def _bytes_planes_from_arr(arr, alpha_override=None, *, width: int = 0, height: int = 0, psd_scanline_order: bool = False):
    """Convert an RGBA float array to PSD byte planes without full-array copies.

    Older code clipped the entire RGBA buffer before extracting each channel.
    On 2K/4K PSD saves that extra 64-256MB temporary could push Blender into
    swapping and look like a hard freeze.  Channel-wise conversion keeps peak
    memory bounded to one 8-bit plane at a time.
    """
    import numpy as np
    rgba = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
    alpha = None if alpha_override is None else np.asarray(alpha_override, dtype=np.float32).reshape((-1,))
    use_scanline = bool(psd_scanline_order) and int(width or 0) > 0 and int(height or 0) > 0
    w = int(width or 0); h = int(height or 0)

    def _plane_from_values(values):
        vals = np.asarray(values, dtype=np.float32)
        # Use arithmetic + clip per plane, not an RGBA-wide clipped copy.
        vals = np.clip(vals * 255.0 + 0.5, 0.0, 255.0)
        return vals.astype(np.uint8, copy=False).tobytes()

    try:
        if use_scanline:
            rgba2 = rgba.reshape((h, w, 4))[::-1, :, :]
            r = _plane_from_values(rgba2[:, :, 0])
            g = _plane_from_values(rgba2[:, :, 1])
            b = _plane_from_values(rgba2[:, :, 2])
            if alpha is None:
                a = _plane_from_values(rgba2[:, :, 3])
            else:
                a = _plane_from_values(alpha.reshape((h, w))[::-1, :])
            return r, g, b, a
    except Exception:
        pass
    r = _plane_from_values(rgba[:, 0])
    g = _plane_from_values(rgba[:, 1])
    b = _plane_from_values(rgba[:, 2])
    if alpha is None:
        a = _plane_from_values(rgba[:, 3])
    else:
        a = _plane_from_values(alpha)
    return r, g, b, a


def _fallback_planes_from_array(buf, alpha_override=None):
    n = len(buf) // 4
    r = bytearray(n); g = bytearray(n); b = bytearray(n); a = bytearray(n)
    for i in range(n):
        j = i * 4
        r[i] = int(_clamp01(buf[j]) * 255 + 0.5)
        g[i] = int(_clamp01(buf[j + 1]) * 255 + 0.5)
        b[i] = int(_clamp01(buf[j + 2]) * 255 + 0.5)
        av = _clamp01(buf[j + 3])
        if alpha_override is not None:
            try:
                av = _clamp01(alpha_override[i])
            except Exception:
                pass
        a[i] = int(av * 255 + 0.5)
    return bytes(r), bytes(g), bytes(b), bytes(a)


def collect_layers(material, channel: str = 'BASE_COLOR') -> tuple[int, int, list[dict]]:
    from . import clean_layer_stack_engine as _clean
    return _clean.collect_layers(material, channel)

def _layer_mask_factor_array(item, width: int, height: int):
    """Return a document-space mask factor for the flat pseudo-layer engine.

    The old shader stack evaluated masks in nodes.  The flat engine must apply at
    least image masks in the CPU compositor so layer visibility, Image Editor and
    3D View remain identical.  Unsupported generated/mesh masks return None and
    therefore leave the layer unmasked rather than destroying pixels.
    """
    np = _np_module()
    if np is None or item is None:
        return None
    try:
        layer = item.get('layer') if isinstance(item, dict) else None
        mode = str(getattr(layer, 'mask_mode', 'NONE') or 'NONE').upper() if layer is not None else 'NONE'
        if mode in {'', 'NONE', 'OFF'}:
            return None
        if mode != 'IMAGE':
            return None
        name = str(getattr(layer, 'mask_image', '') or '')
        mask_img = bpy.data.images.get(name) if name else None
        if mask_img is None:
            return None
        marr = _read_image_array(mask_img, int(width), int(height))
        if marr is None:
            return None
        marr = np.asarray(marr, dtype=np.float32).reshape((-1, 4))
        ch = str(getattr(layer, 'mask_channel', 'LUMA') or 'LUMA').upper()
        if ch == 'R':
            fac = marr[:, 0]
        elif ch == 'G':
            fac = marr[:, 1]
        elif ch == 'B':
            fac = marr[:, 2]
        elif ch in {'A', 'ALPHA'}:
            fac = marr[:, 3]
        else:
            fac = marr[:, 0] * 0.2126 + marr[:, 1] * 0.7152 + marr[:, 2] * 0.0722
        fac = np.clip(fac.astype(np.float32, copy=False), 0.0, 1.0)
        try:
            thr = float(getattr(layer, 'mask_threshold', 0.5) or 0.5)
            # Match the old shader behavior approximately: threshold values above
            # 0.5 tighten the mask, below 0.5 expand it.  Keep it continuous.
            if abs(thr - 0.5) > 1e-5:
                if thr >= 0.5:
                    fac = np.clip(fac - (thr - 0.5) * 2.0, 0.0, 1.0)
                else:
                    fac = np.clip(fac + (0.5 - thr) * 2.0, 0.0, 1.0)
        except Exception:
            pass
        try:
            fac = np.clip(fac * float(getattr(layer, 'mask_strength', 1.0) or 1.0), 0.0, 1.0)
        except Exception:
            pass
        try:
            if bool(getattr(layer, 'invert_mask', False)):
                fac = 1.0 - fac
        except Exception:
            pass
        return fac.astype(np.float32, copy=False)
    except Exception:
        return None



def invalidate_layer_stack_composite(material=None, channel: str = 'BASE_COLOR') -> None:
    from . import clean_layer_stack_engine as _clean
    try:
        _clean._io()._COMPOSITE_ARRAY_CACHE.clear()
    except Exception:
        pass

def stable_recompose_layer_stack(material=None, channel: str = 'BASE_COLOR', context=None, *, switch_to_paint: bool = False):
    from . import clean_layer_stack_engine as _clean
    return _clean.recompose_and_sync(material, channel, context, switch_to_paint=switch_to_paint)

def composite_layer_arrays(material, channel: str = 'BASE_COLOR'):
    from . import clean_layer_stack_engine as _clean
    return _clean.composite_layer_arrays(material, channel)

def find_master_texture_image(material, channel: str = 'BASE_COLOR'):
    """Return the single visible document texture for a material/channel."""
    if material is None:
        return None
    channel = str(channel or 'BASE_COLOR').upper()
    try:
        path = str(material.get(f'sps_texture_path_{channel}', '') or '')
    except Exception:
        path = ''
    mat_name = str(getattr(material, 'name', '') or '')
    # Fast authoritative lookups first.
    try:
        for prop in ('sps_document_file_image_', 'sps_master_texture_image_', 'sps_visible_master_image_', 'sps_document_target_image_'):
            name = str(material.get(prop + channel, '') or '')
            img = bpy.data.images.get(name) if name else None
            if img is not None:
                if not path:
                    return img
                img_path = str(getattr(img, 'filepath_raw', '') or getattr(img, 'filepath', '') or '')
                if not img_path or bpy.path.abspath(img_path) == bpy.path.abspath(path):
                    return img
        if path:
            base = Path(bpy.path.abspath(path)).name
            img = bpy.data.images.get(base) if base else None
            if img is not None:
                return img
    except Exception:
        pass
    best = None
    try:
        if len(getattr(bpy.data, 'images', ())) <= 2000:
            for image in getattr(bpy.data, 'images', ()):  # legacy fallback only
                try:
                    if not bool(image.get('smart_paint_suite_master_texture')):
                        continue
                    if str(image.get('smart_paint_suite_material', '') or '') != mat_name:
                        continue
                    if str(image.get('smart_paint_suite_channel', '') or '').upper() != channel:
                        continue
                    if path:
                        img_path = str(getattr(image, 'filepath_raw', '') or getattr(image, 'filepath', '') or '')
                        if img_path and bpy.path.abspath(img_path) == bpy.path.abspath(path):
                            return image
                    best = image
                except Exception:
                    continue
    except Exception:
        pass
    return best


def sync_composite_to_master_image(material, channel: str = 'BASE_COLOR'):
    """Composite Smart Paint layers into the single document/master image.

    This is the key Photoshop-style display path: the 3D View and Image Editor
    keep showing one document texture while Blender's Single Image Texture Paint canvas
    can still target the selected layer's hidden image node.
    """
    width, height, arr = composite_layer_arrays(material, channel)
    if width <= 0 or height <= 0 or arr is None:
        return None
    image = find_master_texture_image(material, channel)
    if image is None:
        return None
    try:
        if int(image.size[0]) != int(width) or int(image.size[1]) != int(height):
            image.scale(int(width), int(height))
    except Exception:
        pass
    try:
        _write_image_array_np(image, arr)
        image['smart_paint_suite_composited_master'] = True
        material[f'sps_master_composite_image_{str(channel or "BASE_COLOR").upper()}'] = image.name
    except Exception:
        pass
    return image


def update_composite_preview(material, channel: str = 'BASE_COLOR'):
    width, height, arr = composite_layer_arrays(material, channel)
    if width <= 0 or height <= 0 or arr is None:
        return None
    name = 'SPS_' + getattr(material, 'name', 'Material') + '_LayerStackPreview'
    image = bpy.data.images.get(name) or bpy.data.images.new(name, width, height, alpha=True, float_buffer=False)
    try:
        if int(image.size[0]) != width or int(image.size[1]) != height:
            image.scale(width, height)
    except Exception:
        pass
    try:
        _write_image_array_np(image, arr)
        image['smart_paint_suite_composite_preview'] = True
        material['sps_composite_preview_image'] = image.name
    except Exception:
        pass
    return image


def _texture_save_status_key(prefix: str, channel: str) -> str:
    try:
        return str(prefix) + _safe_channel(channel)
    except Exception:
        return str(prefix) + 'BASE_COLOR'

def _clear_texture_save_status(material, channel: str) -> None:
    if material is None:
        return
    for prefix in ('sps_last_texture_save_recovery_', 'sps_last_texture_save_error_'):
        try:
            key = _texture_save_status_key(prefix, channel)
            if key in material:
                del material[key]
        except Exception:
            pass

def _unique_locked_target_recovery_path(final_path: Path) -> Path:
    final_path = Path(final_path)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    suffix = final_path.suffix or '.png'
    base = f"{final_path.stem}_SPS_recovery_{stamp}"
    candidate = final_path.with_name(base + suffix)
    index = 1
    while candidate.exists():
        candidate = final_path.with_name(f"{base}_{index:02d}" + suffix)
        index += 1
    return candidate

def _replace_or_recover_locked_texture_tmp(material, channel: str, tmp_path: Path, final_path: Path) -> bool:
    import os as _os
    tmp_path = Path(tmp_path)
    final_path = Path(final_path)
    try:
        from . import save_trace as _sps_save_trace
        if not _sps_save_trace.guard_psd_file_write(final_path, material=material, channel=channel, reason='psd_io_replace_or_recover_locked_texture_tmp', operation='replace_final'):
            return False
        _sps_save_trace.emit_psd_file_write('psd_file_replace_attempt', final_path, material=material, channel=channel, tmp_path=str(tmp_path), reason='psd_io_replace_or_recover_locked_texture_tmp')
    except Exception:
        pass
    try:
        _os.replace(str(tmp_path), str(final_path))
        return True
    except Exception as replace_exc:
        try:
            recovery = _unique_locked_target_recovery_path(final_path)
            recovery.parent.mkdir(parents=True, exist_ok=True)
            try:
                from . import save_trace as _sps_save_trace
                if not _sps_save_trace.guard_psd_file_write(recovery, material=material, channel=channel, reason='psd_io_replace_recovery_texture_tmp', operation='replace_recovery'):
                    return False
                _sps_save_trace.emit_psd_file_write('psd_file_recovery_replace_attempt', recovery, material=material, channel=channel, tmp_path=str(tmp_path), final_path=str(final_path))
            except Exception:
                pass
            try:
                _os.replace(str(tmp_path), str(recovery))
            except Exception:
                Path(tmp_path).replace(recovery)
            try:
                material[_texture_save_status_key('sps_last_texture_save_recovery_', channel)] = str(recovery)
                material[_texture_save_status_key('sps_last_texture_save_error_', channel)] = str(replace_exc or '')[:512]
            except Exception:
                pass
            return True
        except Exception as recovery_exc:
            try:
                material[_texture_save_status_key('sps_last_texture_save_error_', channel)] = (str(replace_exc or '') + ' / recovery: ' + str(recovery_exc or ''))[:512]
            except Exception:
                pass
            return False

def _current_sps_flattened_preview_from_visible_document(material, channel: str = 'BASE_COLOR'):
    """Return the current monitor-visible composite for flat saves.

    PSD source-record saves keep layers byte-stable and then refresh the PSD main
    image.  Flat formats must use the same current composite instead of the raw
    source PSD preview; otherwise PNG/TIFF/JPEG can miss a newly painted layer.
    """
    try:
        from . import clean_layer_stack_engine as _clean
        ch = _safe_channel(channel)
        width = height = 0
        try:
            width, height, _items = _clean.collect_layers(material, ch)
        except Exception:
            width = height = 0
        if int(width) <= 1 or int(height) <= 1:
            try:
                resolver = getattr(_clean, '_clean_lazy_psd_source_path_for_direct_copy', None)
                src = str(resolver(material, ch) or '') if callable(resolver) else ''
                if src:
                    doc = read_layered_psd_lazy(src, decode_merged=False)
                    width = int(doc.get('width', 0) or 0); height = int(doc.get('height', 0) or 0)
            except Exception:
                pass
        if int(width) <= 1 or int(height) <= 1:
            return None
        maker = getattr(_clean, '_current_document_composite_main_image_data', None)
        if not callable(maker):
            return None
        main = maker(material, ch, int(width), int(height), channels=4)
        if not main or len(main) < 2:
            return None
        import numpy as np
        raw = bytes(main)
        if raw[:2] != b'\x00\x00':
            return None
        plane_len = int(width) * int(height)
        payload = raw[2:]
        if len(payload) < plane_len * 3:
            return None
        planes = []
        off = 0
        for _ in range(4):
            if off + plane_len <= len(payload):
                planes.append(np.frombuffer(payload[off:off + plane_len], dtype=np.uint8).reshape((int(height), int(width))))
            else:
                planes.append(np.full((int(height), int(width)), 255, dtype=np.uint8))
            off += plane_len
        arr = np.stack(planes[:4], axis=2).astype(np.float32) / 255.0
        # PSD main-image planes are stored top-to-bottom; Blender Image.pixels
        # expects bottom-to-top memory order.
        arr = arr[::-1, :, :].copy().reshape((-1, 4))
        return int(width), int(height), np.ascontiguousarray(np.clip(arr, 0.0, 1.0), dtype=np.float32)
    except Exception:
        return None


def _mark_composite_preview_authority(material, channel: str, authority: str, source: str) -> None:
    try:
        if material is None:
            return
        ch = str(channel or 'BASE_COLOR').upper()
        material['sps_composite_preview_authority_' + ch] = str(authority or '')
        material['sps_composite_preview_source_' + ch] = str(source or '')
    except Exception:
        pass


def _clean_lazy_psd_flattened_preview(material, channel: str = 'BASE_COLOR'):
    """Return a flattened array for an unedited lazy PSD stack without materializing layers.

    Flat texture saves used to call composite_layer_arrays(), which decodes every
    lazy PSD proxy into full Blender Image datablocks.  On 4096px production PSDs
    this can force multi-gigabyte Image.pixels traffic and look like a save
    freeze.  When the Smart Paint stack still exactly matches its source PSD, use
    the PSD merged preview plus the layer alpha preview directly.
    """
    try:
        from . import clean_layer_stack_engine as _clean
        src = ''
        resolver = getattr(_clean, '_clean_lazy_psd_source_path_for_direct_copy', None)
        if callable(resolver):
            src = str(resolver(material, channel) or '')
        if not src:
            return None
        doc = read_layered_psd_lazy(src, decode_merged=True)
        width = int(doc.get('width', 0) or 0); height = int(doc.get('height', 0) or 0)
        if width <= 0 or height <= 0:
            return None
        import numpy as np
        arr = doc.get('merged', None)
        if arr is not None:
            arr = np.asarray(arr, dtype=np.float32).reshape((-1, 4)).copy()
            try:
                alpha = build_lazy_psd_alpha_preview(doc, max_layers=64)
                if alpha is not None and int(alpha.size) == width * height:
                    arr[:, 3] = np.clip(np.asarray(alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
            except Exception:
                pass
            if not psd_preview_array_looks_black_or_empty(arr):
                _mark_composite_preview_authority(material, channel, 'ps_merged_preview_inherited', 'psd_merged_preview')
                return width, height, np.ascontiguousarray(np.clip(arr, 0.0, 1.0), dtype=np.float32)
        arr = build_lazy_psd_color_preview(doc, max_layers=64)
        if arr is not None:
            _mark_composite_preview_authority(material, channel, 'sps_cpu_lazy_color_preview', 'psd_lazy_color_preview')
            return width, height, np.ascontiguousarray(np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0), dtype=np.float32)
    except Exception:
        pass
    return None


def build_lazy_psd_source_merged_authored_overlay_preview(material, channel: str = 'BASE_COLOR', *, max_layers: int = 96):
    """Use the Photoshop merged preview as the base and overlay authored top rows.

    Production PSDs can contain groups, masks, clipping and Photoshop adjustment
    rows that are expensive or impossible to reproduce perfectly in Blender on
    every layer click.  The PSD merged preview is the authoritative appearance
    for those untouched source rows.  Smart Paint-created paint layers above the
    source stack still need to appear immediately in the Image Editor and 3D
    View, so composite only those user-authored rows over the merged preview.
    """
    np = _np_module()
    if np is None or material is None:
        return None
    try:
        channel = _safe_channel(channel)
        base = _clean_lazy_psd_flattened_preview(material, channel)
        if base is None:
            src = ''
            for key in (
                'sps_bodypaint_source_stack_path_' + channel,
                'sps_source_psd_path_' + channel,
                'sps_texture_path_' + channel,
            ):
                try:
                    candidate = str(material.get(key, '') or '')
                except Exception:
                    candidate = ''
                if candidate and Path(bpy.path.abspath(candidate)).suffix.lower() in {'.psd', '.psb', '.pdd'} and Path(bpy.path.abspath(candidate)).exists():
                    src = bpy.path.abspath(candidate)
                    break
            if not src:
                try:
                    settings_for_src = getattr(material, 'smart_paint_suite', None)
                    attr_for_src = layer_channel_image_attr(channel)
                    for layer_for_src in list(getattr(settings_for_src, 'layers', []) or []):
                        image_name_for_src = str(getattr(layer_for_src, attr_for_src, '') or '')
                        image_for_src = bpy.data.images.get(image_name_for_src) if image_name_for_src else None
                        candidate = str(image_for_src.get('smart_paint_suite_source_file', '') or '') if image_for_src is not None else ''
                        if candidate and Path(bpy.path.abspath(candidate)).suffix.lower() in {'.psd', '.psb', '.pdd'} and Path(bpy.path.abspath(candidate)).exists():
                            src = bpy.path.abspath(candidate)
                            break
                except Exception:
                    src = ''
            if src:
                cache_key = None
                try:
                    stat = os.stat(src)
                    cache_key = (
                        str(getattr(material, 'name', '') or ''),
                        channel,
                        os.path.normcase(os.path.abspath(src)),
                        int(stat.st_size),
                        float(stat.st_mtime),
                    )
                    cached_base = _SPS_SOURCE_MERGED_BASE_CACHE.get(cache_key)
                    if cached_base:
                        cw, ch_cached, carr = cached_base
                        if int(cw) > 0 and int(ch_cached) > 0 and carr is not None:
                            base = (int(cw), int(ch_cached), np.ascontiguousarray(np.asarray(carr, dtype=np.float32).reshape((int(cw) * int(ch_cached), 4)), dtype=np.float32).copy())
                except Exception:
                    cache_key = None
                if base is None:
                    try:
                        settings_probe = getattr(material, 'smart_paint_suite', None)
                        layers_probe = list(getattr(settings_probe, 'layers', []) or [])
                        prev_rows = []
                        try:
                            prev_sig = str(material.get('sps_lazy_stack_signature_' + channel, '') or '')
                            prev_rows = json.loads(prev_sig) if prev_sig else []
                        except Exception:
                            prev_rows = []
                        source_limit = -1
                        attr_probe = layer_channel_image_attr(channel)
                        for probe_idx, probe_layer in enumerate(layers_probe):
                            try:
                                probe_image_name = str(getattr(probe_layer, attr_probe, '') or '')
                                probe_image = bpy.data.images.get(probe_image_name) if probe_image_name else None
                                probe_payload = lazy_psd_layer_payload_for_image(probe_image) if probe_image is not None else None
                                probe_source_like = bool(probe_payload is not None)
                                probe_source_like = bool(probe_source_like or str(probe_layer.get('sps_psd_original_name', '') or ''))
                                probe_source_like = bool(probe_source_like or str(getattr(probe_layer, 'psd_raw_layer_tags', '') or ''))
                                probe_source_like = bool(probe_source_like or str(getattr(probe_layer, 'psd_raw_adjustment_tags', '') or ''))
                                probe_source_like = bool(probe_source_like or bool(getattr(probe_layer, 'is_group', False)))
                                probe_source_like = bool(probe_source_like or str(getattr(probe_layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT')
                                if probe_source_like:
                                    source_limit = probe_idx
                            except Exception:
                                continue
                        can_reuse_visible_source = bool(prev_rows and len(prev_rows) <= source_limit + 1 and len(layers_probe) > len(prev_rows))
                        if can_reuse_visible_source:
                            master_name = str(material.get('sps_master_texture_image_' + channel, '') or '') if hasattr(material, 'get') else ''
                            master = bpy.data.images.get(master_name) if master_name else None
                            if master is not None:
                                mw, mh = int(master.size[0]), int(master.size[1])
                                if mw > 1 and mh > 1:
                                    mbuf = np.empty(mw * mh * 4, dtype=np.float32)
                                    master.pixels.foreach_get(mbuf)
                                    mbuf = np.ascontiguousarray(np.clip(mbuf.reshape((mw * mh, 4)), 0.0, 1.0), dtype=np.float32)
                                    if not psd_preview_array_looks_black_or_empty(mbuf):
                                        base = (mw, mh, mbuf)
                                        if cache_key is not None:
                                            _SPS_SOURCE_MERGED_BASE_CACHE[cache_key] = (mw, mh, np.ascontiguousarray(mbuf, dtype=np.float32))
                        while len(_SPS_SOURCE_MERGED_BASE_CACHE) > 3:
                            try:
                                _SPS_SOURCE_MERGED_BASE_CACHE.pop(next(iter(_SPS_SOURCE_MERGED_BASE_CACHE)))
                            except Exception:
                                break
                    except Exception:
                        pass
            if src and base is None:
                try:
                    doc = read_layered_psd_lazy(src, decode_merged=True)
                    width0 = int(doc.get('width', 0) or 0); height0 = int(doc.get('height', 0) or 0)
                    merged0 = doc.get('merged', None)
                    if width0 > 0 and height0 > 0 and merged0 is not None:
                        arr0 = np.asarray(merged0, dtype=np.float32).reshape((-1, 4)).copy()
                        try:
                            alpha0 = build_lazy_psd_alpha_preview(doc, max_layers=64)
                            if alpha0 is not None and int(alpha0.size) == width0 * height0:
                                arr0[:, 3] = np.clip(np.asarray(alpha0, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
                        except Exception:
                            pass
                        if not psd_preview_array_looks_black_or_empty(arr0):
                            base = (width0, height0, np.ascontiguousarray(np.clip(arr0, 0.0, 1.0), dtype=np.float32))
                            if cache_key is not None:
                                _SPS_SOURCE_MERGED_BASE_CACHE[cache_key] = (width0, height0, np.ascontiguousarray(base[2], dtype=np.float32))
                                while len(_SPS_SOURCE_MERGED_BASE_CACHE) > 3:
                                    try:
                                        _SPS_SOURCE_MERGED_BASE_CACHE.pop(next(iter(_SPS_SOURCE_MERGED_BASE_CACHE)))
                                    except Exception:
                                        break
                except Exception:
                    base = None
        if base is None:
            return None
        width, height, arr = base
        width = int(width); height = int(height)
        if width <= 0 or height <= 0 or arr is None:
            return None
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return None
        layers = list(getattr(settings, 'layers', []) or [])
        if not layers or len(layers) > int(max_layers or 96):
            return None
        attr = layer_channel_image_attr(channel)
        enabled_attr = layer_channel_enabled_attr(channel)
        highest_source_idx = -1
        authored_indices: list[int] = []
        for idx, layer in enumerate(layers):
            try:
                image_name = str(getattr(layer, attr, '') or '')
                image = bpy.data.images.get(image_name) if image_name else None
                payload = lazy_psd_layer_payload_for_image(image) if image is not None else None
                source_like = bool(payload is not None)
                source_like = bool(source_like or str(layer.get('sps_psd_original_name', '') or ''))
                source_like = bool(source_like or str(getattr(layer, 'psd_raw_layer_tags', '') or ''))
                source_like = bool(source_like or str(getattr(layer, 'psd_raw_adjustment_tags', '') or ''))
                source_like = bool(source_like or bool(getattr(layer, 'is_group', False)))
                source_like = bool(source_like or str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT')
                if source_like:
                    highest_source_idx = idx
                elif image is not None and smart_paint_layer_image_has_authoritative_user_pixels(image):
                    authored_indices.append(idx)
            except Exception:
                continue
        # Only rows above the untouched source PSD can be represented accurately
        # by this cheap path.  Inserted rows below source layers are still saved in
        # the correct stack position, but displaying them through a merged source
        # base would incorrectly place them above Photoshop's source rows.
        overlay_indices = [idx for idx in authored_indices if idx > highest_source_idx]
        if not overlay_indices:
            if not authored_indices:
                _mark_composite_preview_authority(material, channel, 'ps_merged_preview_inherited', 'psd_merged_preview')
                return width, height, np.ascontiguousarray(np.clip(np.asarray(arr, dtype=np.float32).reshape((width * height, 4)), 0.0, 1.0), dtype=np.float32)
            return None
        out = np.asarray(arr, dtype=np.float32).reshape((height, width, 4)).copy()
        made = 0
        for idx in overlay_indices:
            try:
                layer = layers[idx]
                if bool(getattr(layer, 'is_group', False)):
                    continue
                if str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT':
                    continue
                if str(getattr(layer, 'adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                    continue
                if not bool(getattr(layer, 'enabled', True)) or not bool(getattr(layer, enabled_attr, True)):
                    continue
                image_name = str(getattr(layer, attr, '') or '')
                image = bpy.data.images.get(image_name) if image_name else None
                if image is None:
                    continue
                layer_arr = _sps_sparse_rgba_patch_to_canvas(image, width, height)
                if layer_arr is None:
                    try:
                        iw = int(image.size[0]); ih = int(image.size[1])
                        if iw <= 0 or ih <= 0:
                            continue
                        buf = np.empty(iw * ih * 4, dtype=np.float32)
                        image.pixels.foreach_get(buf)
                        layer_arr = np.clip(buf.reshape((ih, iw, 4)), 0.0, 1.0)
                        if iw != width or ih != height:
                            ys = np.clip((np.arange(height) * (ih / float(height))).astype(np.int64), 0, ih - 1)
                            xs = np.clip((np.arange(width) * (iw / float(width))).astype(np.int64), 0, iw - 1)
                            layer_arr = layer_arr[ys[:, None], xs[None, :], :]
                    except Exception:
                        continue
                else:
                    layer_arr = np.asarray(layer_arr, dtype=np.float32).reshape((height, width, 4))
                src_a = np.clip(layer_arr[:, :, 3], 0.0, 1.0)
                if not bool(np.any(src_a > (1.0 / 4096.0))):
                    continue
                try:
                    opacity = max(0.0, min(1.0, float(getattr(layer, 'opacity', 1.0) or 0.0)))
                except Exception:
                    opacity = 1.0
                src_a = np.clip(src_a * opacity, 0.0, 1.0)
                dst_a = np.clip(out[:, :, 3], 0.0, 1.0)
                src_rgb = np.clip(layer_arr[:, :, :3], 0.0, 1.0)
                dst_rgb = np.clip(out[:, :, :3], 0.0, 1.0)
                try:
                    mode = str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper()
                except Exception:
                    mode = 'MIX'
                if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
                    blend_rgb = src_rgb
                else:
                    try:
                        blend_rgb = _blend_rgb(
                            dst_rgb.reshape((-1, 3)),
                            src_rgb.reshape((-1, 3)),
                            np.ones((width * height,), dtype=np.float32),
                            mode,
                        ).reshape((height, width, 3))
                    except Exception:
                        blend_rgb = src_rgb
                out[:, :, :3], new_a = _composite_blended_source_over(
                    dst_rgb, dst_a, src_rgb, src_a, blend_rgb,
                )
                out[:, :, 3] = new_a
                made += 1
            except Exception:
                continue
        if made <= 0:
            return None
        flat = np.ascontiguousarray(np.clip(out.reshape((width * height, 4)), 0.0, 1.0), dtype=np.float32)
        if psd_preview_array_looks_black_or_empty(flat):
            return None
        _mark_composite_preview_authority(material, channel, 'ps_merged_preview_plus_authored_overlay', 'psd_merged_preview_overlay')
        return width, height, flat
    except Exception:
        return None


def write_flattened_texture(material, channel: str, filepath: str | Path, file_format: str = 'PNG') -> bool:
    preview = _current_sps_flattened_preview_from_visible_document(material, channel)
    if preview is None:
        preview = _clean_lazy_psd_flattened_preview(material, channel)
    if preview is not None:
        width, height, arr = preview
    else:
        width, height, arr = composite_layer_arrays(material, channel)
    if width <= 0 or height <= 0 or arr is None:
        return False
    path = Path(filepath)
    _clear_texture_save_status(material, channel)
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix or '.png'
    tmp_path = path.with_name(path.stem + '.sps_tmp' + suffix)
    image_name = 'SPS_' + getattr(material, 'name', 'Material') + '_' + str(channel or 'BASE_COLOR') + '_SaveComposite'
    image = bpy.data.images.new(image_name, width, height, alpha=True, float_buffer=False)
    try:
        image['smart_paint_suite_transient_save_image'] = True
        image['smart_paint_suite_material'] = getattr(material, 'name', '')
        image['smart_paint_suite_channel'] = _safe_channel(channel)
    except Exception:
        pass
    try:
        image.pixels.foreach_set(arr.reshape(-1))
        image.update()
        ext = path.suffix.lower()
        fmt = str(file_format or '').upper().lstrip('.')
        if fmt == 'JPG':
            fmt = 'JPEG'
        elif fmt == 'TIF':
            fmt = 'TIFF'
        elif fmt == 'EXR':
            fmt = 'OPEN_EXR'
        elif fmt == 'TGA':
            fmt = 'TARGA'
        if ext in {'.jpg', '.jpeg'} or fmt == 'JPEG':
            image.file_format = 'JPEG'
        elif ext in {'.tif', '.tiff'} or fmt == 'TIFF':
            image.file_format = 'TIFF'
        elif ext == '.tga' or fmt == 'TARGA':
            image.file_format = 'TARGA'
        elif ext == '.bmp' or fmt == 'BMP':
            image.file_format = 'BMP'
        elif ext in {'.exr', '.hdr'} or fmt == 'OPEN_EXR':
            image.file_format = 'OPEN_EXR'
        else:
            image.file_format = 'PNG'
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except Exception:
            pass
        image.filepath_raw = str(tmp_path)
        image.save()
        if not _replace_or_recover_locked_texture_tmp(material, channel, tmp_path, path):
            return False
        return True
    finally:
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except Exception:
            pass
        try:
            bpy.data.images.remove(image, do_unlink=True)
        except Exception:
            pass



def _flush_direct_layer_session_for_explicit_boundary(material, channel: str = 'BASE_COLOR', *, context=None) -> bool:
    """Flush real direct private-layer paint at Save/stack-edit boundaries.

    Save, layer visibility and mask/group edits are correctness boundaries, so a
    currently armed direct-layer paint session must be finalized even if the
    sparse dirty stamp missed a tiny stroke.  When no direct session exists,
    however, forcing a flush would reinterpret an old RGB-only transparent layer
    as a new native paint stroke and could mark it alpha-authoritative, causing
    PSD export/readback to become white or transparent.  The boundary helper
    therefore forces only an existing session and treats session-less calls as a
    cheap no-op check.
    """
    try:
        if material is None:
            return False
        ch = _safe_channel(channel)
        key = _direct_session_key(material, ch)
        has_session = False
        try:
            has_session = key in _DIRECT_LAYER_PAINT_SESSIONS
        except Exception:
            has_session = False
        if _sps_bodypaint_direct_layer_write_active(material, ch, context):
            return bool(_sps_bodypaint_commit_private_layer_boundary(
                material, ch, context, refresh_master=False, force=bool(has_session), reason='metadata_boundary'
            ))
        return bool(_flush_direct_layer_session(material, ch, force=bool(has_session), context=context))
    except Exception:
        return False



def _preserve_active_private_layer_pixels_for_boundary(material, channel: str = 'BASE_COLOR', *, context=None, reason: str = '') -> bool:
    """Make the active private layer authoritative before Save/visibility edits.

    Native Blender painting can write directly to the selected Image datablock
    without a Smart Paint session token.  If a layer metadata edit runs before we
    mark/protect those pixels, a cached blank/lazy snapshot can be restored and
    the brush stroke disappears.  This helper never invents alpha from RGB; it
    preserves real RGBA currently stored in the active private layer.
    """
    try:
        np = _np_module()
        if np is None or material is None:
            return False
        channel = _safe_channel(channel)
        layer, image = _active_layer_image_for_material(material, channel)
        if layer is None or image is None:
            return False
        try:
            image.update()
        except Exception:
            pass
        try:
            if bool(image.get('smart_paint_suite_authoritative_sparse_rgba_patch', False)) and bool(image.get('smart_paint_suite_sparse_rgba_patch_b64', False)):
                image['smart_paint_suite_alpha_authoritative'] = True
                image['smart_paint_suite_dirty_from_master'] = True
                _mark_image_pixels_changed(image, None)
                # The sparse patch is already the authoritative layer content.
                # Visibility ON/OFF callbacks must not report this as a newly
                # preserved stroke, otherwise the caller runs full-stack pixel
                # protection and can replay old projections or stall on large PSDs.
                return False
        except Exception:
            pass
        try:
            _dirty_probe = bool(getattr(image, 'is_dirty', False))
        except Exception:
            _dirty_probe = False
        try:
            _flagged_probe = bool(image.get('smart_paint_suite_dirty_from_master', False) or image.get('smart_paint_suite_alpha_authoritative', False) or image.get('smart_paint_suite_exact_fallback_commit', False) or image.get('smart_paint_suite_save_exact_master_delta', False))
        except Exception:
            _flagged_probe = False
        try:
            _intentionally_empty_probe = bool(image.get('smart_paint_suite_intentionally_empty', False) or image.get('smart_paint_suite_clear_deferred', False) or image.get('smart_paint_suite_lazy_blank_layer', False))
        except Exception:
            _intentionally_empty_probe = False
        if _intentionally_empty_probe and (not _dirty_probe) and (not _flagged_probe):
            try:
                _sess_probe = _MASTER_PAINT_SESSIONS.get(_session_key(material, channel))
                if isinstance(_sess_probe, dict) and _sess_probe.get('baseline') is not None:
                    return False
            except Exception:
                pass
        try:
            if bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
                materialize_lazy_psd_layer_image(image)
        except Exception:
            pass
        arr = _image_array_np(image, use_cache=False)
        if arr is None:
            return False
        arr = np.clip(np.asarray(arr, dtype=np.float32).reshape((-1, 4)), 0.0, 1.0)
        if arr.size <= 0:
            return False
        alpha = np.clip(arr[:, 3], 0.0, 1.0)
        has_alpha = bool(alpha.size and float(np.max(alpha)) > (1.0 / 4096.0))
        dirty = False
        try:
            dirty = bool(getattr(image, 'is_dirty', False))
        except Exception:
            dirty = False
        flagged = False
        try:
            flagged = bool(image.get('smart_paint_suite_dirty_from_master', False) or image.get('smart_paint_suite_alpha_authoritative', False) or image.get('smart_paint_suite_exact_fallback_commit', False) or image.get('smart_paint_suite_save_exact_master_delta', False))
        except Exception:
            flagged = False
        if not (has_alpha or dirty or flagged):
            return False
        try:
            if has_alpha:
                image['smart_paint_suite_alpha_authoritative'] = True
                for _prop in (
                    'smart_paint_suite_intentionally_empty',
                    'smart_paint_suite_lazy_blank_layer',
                    'smart_paint_suite_clear_deferred',
                    'smart_paint_suite_rgb_alpha_fallback',
                    'smart_paint_suite_export_rgb_alpha_fallback',
                ):
                    if _prop in image:
                        del image[_prop]
        except Exception:
            pass
        try:
            _mark_image_pixels_changed(image, arr)
        except Exception:
            pass
        try:
            protect_layer_stack_pixels(material, channel)
        except Exception:
            pass
        try:
            mark_layer_stack_pixels_current(material, channel)
        except Exception:
            pass
        return bool(has_alpha or dirty or flagged)
    except Exception:
        return False

def _commit_sparse_visible_master_delta_before_stack_metadata_edit(material, channel: str = 'BASE_COLOR', context=None, *, target_layer_id: str = '') -> bool:
    """Recover a brush-sized public-master stroke before a layer metadata edit.

    Layer enable/disable callbacks run after the RNA value has already changed.
    If Texture Paint has written a new stroke only to the composited document
    image, the following projection rebuild would otherwise replace that master
    with the still-blank private layer stack.  This helper commits only a bounded
    brush-like delta to the active/edited layer; broad visibility changes are not
    flattened into private pixels.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    channel = _safe_channel(channel)
    try:
        active_id = str(_active_layer_id(material) or '')
        target_layer_id = str(target_layer_id or active_id or '')
        if not target_layer_id or (active_id and target_layer_id != active_id):
            return False
    except Exception:
        target_layer_id = str(target_layer_id or '')
        if not target_layer_id:
            return False
    try:
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        try:
            mw0, mh0 = _image_size(master)
            # Without an exact paint-session baseline, recovering metadata-edit
            # deltas requires rebuilding the whole stack for comparison.  Do not
            # do that from an RNA property callback on large textures; it is the
            # freeze reported when toggling a freshly added layer.  Real Texture
            # Paint sessions use the exact-baseline branch above.
            if int(mw0) * int(mh0) >= 2048 * 2048:
                return False
        except Exception:
            pass
        current = _image_array_np(master, use_cache=False)
        if current is None:
            return False
        width, height, composite = composite_layer_arrays(material, channel)
        if composite is None or getattr(composite, 'shape', None) != getattr(current, 'shape', None):
            return False
        mw, mh = _image_size(master)
        if int(width) != int(mw) or int(height) != int(mh):
            return False
        tol = 1.0 / 4096.0
        diff = np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1)
        mask = diff > tol
        changed_count = int(np.count_nonzero(mask))
        if changed_count <= 0:
            return False
        total = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
        if total <= 0:
            return False
        brush_like = bool(changed_count <= 262144 or (changed_count / float(total)) <= 0.35)
        if not brush_like:
            return False
        applied = bool(_apply_master_delta_to_layer(
            material,
            channel,
            target_layer_id,
            composite,
            current,
            tolerance=tol,
        ))
        # A just-added layer can still be represented by a 1x1 lazy placeholder.
        # If the inverse solver cannot materialize it from the post-toggle stack
        # context, fall back to the explicit save-boundary delta transfer.  The
        # brush_like guard above prevents broad visibility/projection changes from
        # being flattened into the active layer.
        if not applied:
            try:
                applied = bool(_force_commit_visible_master_delta_to_active_layer_for_save(
                    material,
                    channel,
                    tolerance=tol,
                    force=True,
                ))
            except Exception:
                applied = False
        if applied:
            try:
                _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
            except Exception:
                pass
            try:
                mark_layer_stack_pixels_current(material, channel)
            except Exception:
                pass
            try:
                protect_layer_stack_pixels(material, channel)
            except Exception:
                pass
        return bool(applied)
    except Exception:
        return False



def _commit_toggle_off_visible_master_delta_against_enabled_projection(material, channel: str = 'BASE_COLOR', context=None, *, layer_item=None, tolerance: float = 2.0 / 255.0) -> bool:
    """Recover the current brush stroke before hiding the edited active layer.

    Blender Texture Paint writes to the visible master image.  When the active
    layer is toggled OFF, the RNA value is already disabled by the time the
    property update callback runs.  Comparing the master against the disabled
    projection would treat the layer's existing pixels as a new stroke.  Instead
    we temporarily evaluate the projection with the edited layer forced ON and
    commit only the sparse difference between that projection and the live
    master.  If there is no new brush stroke, the difference is zero and nothing
    is written, so repeated OFF/ON cycles do not thicken alpha or shift colour.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    channel = _safe_channel(channel)
    if layer_item is None:
        return False
    layer_id = ''
    try:
        layer_id = str(getattr(layer_item, 'layer_id', '') or '')
    except Exception:
        layer_id = ''
    if not layer_id:
        try:
            layer_id = _active_layer_id(material)
        except Exception:
            layer_id = ''
    if not layer_id:
        return False
    try:
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        try:
            master.update()
        except Exception:
            pass
        current = _image_array_np(master, use_cache=False)
        if current is None:
            return False
        current = np.asarray(current, dtype=np.float32).reshape((-1, 4))

        # If the active private layer already contains real alpha, the brush
        # stroke is already preserved.  Visibility toggles must never rewrite it
        # from the flattened master, because stale projections can be interpreted
        # as eraser strokes and destroy soft alpha.  No-session recovery below is
        # reserved for blank newly-created layers whose only paint copy is still
        # on the visible master.
        try:
            _layer_probe, _img_probe = _layer_image_for_session(material, layer_id, channel)
            _arr_probe = _image_array_np(_img_probe, use_cache=False) if _img_probe is not None else None
            if _arr_probe is not None and getattr(_arr_probe, 'shape', None) == getattr(current, 'shape', None):
                _alpha_probe = np.clip(np.asarray(_arr_probe, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                if bool(np.any(_alpha_probe > (1.0 / 4096.0))):
                    return False
        except Exception:
            pass

        old_enabled = bool(getattr(layer_item, 'enabled', True))
        enabled_attr = layer_channel_enabled_attr(channel)
        old_channel_enabled = None
        try:
            old_channel_enabled = bool(getattr(layer_item, enabled_attr, True))
        except Exception:
            old_channel_enabled = None
        suspend_old = None
        try:
            from .properties import suspend_layer_rebuilds
            suspend_old = suspend_layer_rebuilds(True)
        except Exception:
            suspend_layer_rebuilds = None
            suspend_old = None
        try:
            try:
                layer_item.enabled = True
            except Exception:
                pass
            try:
                if old_channel_enabled is not None:
                    setattr(layer_item, enabled_attr, True)
            except Exception:
                pass
            try:
                _cw, _ch, enabled_projection = composite_layer_arrays(material, channel)
            except Exception:
                enabled_projection = None
        finally:
            try:
                layer_item.enabled = old_enabled
            except Exception:
                pass
            try:
                if old_channel_enabled is not None:
                    setattr(layer_item, enabled_attr, old_channel_enabled)
            except Exception:
                pass
            try:
                if suspend_layer_rebuilds is not None:
                    suspend_layer_rebuilds(bool(suspend_old))
            except Exception:
                pass
        if enabled_projection is None:
            return False
        enabled_projection = np.asarray(enabled_projection, dtype=np.float32).reshape((-1, 4))
        if getattr(enabled_projection, 'shape', None) != getattr(current, 'shape', None):
            return False
        tol = max(float(tolerance), 2.0 / 255.0)

        # If the private layer already contains authoritative pixels and the
        # public master is merely the disabled projection, the visibility OFF
        # operation itself must not be applied back into the layer.  For a new
        # blank layer, however, the live master may still be the only copy of the
        # stroke, so do not skip recovery just because the RNA value has changed.
        try:
            _has_existing_alpha = False
            _layer_existing, _image_existing = _layer_image_for_session(material, layer_id, channel)
            _arr_existing = _image_array_np(_image_existing, use_cache=False) if _image_existing is not None else None
            if _arr_existing is not None and getattr(_arr_existing, 'shape', None) == getattr(current, 'shape', None):
                _alpha_existing = np.clip(np.asarray(_arr_existing, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                _has_existing_alpha = bool(np.any(_alpha_existing > (1.0 / 4096.0)))
            if _has_existing_alpha:
                _dw, _dh, disabled_projection = composite_layer_arrays(material, channel)
                if disabled_projection is not None and getattr(disabled_projection, 'shape', None) == getattr(current, 'shape', None):
                    disabled_delta = np.max(np.abs(current[:, :3] - disabled_projection[:, :3]), axis=1)
                    if not bool(np.any(disabled_delta > max(tol, 1.0 / 1024.0))):
                        return False
        except Exception:
            pass

        delta = np.max(np.abs(current[:, :3] - enabled_projection[:, :3]), axis=1)
        changed_count = int(np.count_nonzero(delta > tol))
        total = int(delta.shape[0]) if getattr(delta, 'shape', None) is not None else 0
        if changed_count <= 0 or total <= 0:
            return False
        # Only bounded brush-like deltas are eligible.  Full-canvas differences
        # are projection/cache changes and must never be flattened into a layer.
        brush_like = bool(changed_count <= 262144 or (changed_count / float(total)) <= 0.35)
        if not brush_like:
            return False

        # Commit the sparse live-master delta directly against the enabled
        # projection.  This path is used exactly when a visibility OFF edit would
        # otherwise rebuild the master before Blender's native brush stroke has
        # been copied to the active private layer.  Do not reject overlap with
        # existing active alpha: painting over an existing stroke is valid and the
        # enabled projection already contains the old pixels, so only the new
        # visible-master difference is recovered.
        applied = False
        try:
            layer, image = _layer_image_for_session(material, layer_id, channel)
            if layer is not None and image is not None:
                try:
                    if bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
                        materialize_lazy_psd_layer_image(image)
                except Exception:
                    pass
                try:
                    mw, mh = _image_size(master)
                    iw, ih = _image_size(image)
                    if int(iw) != int(mw) or int(ih) != int(mh):
                        _resize_image_to(image, int(mw), int(mh))
                except Exception:
                    pass
                layer_arr = _image_array_np(image, use_cache=False)
                if layer_arr is not None and getattr(layer_arr, 'shape', None) == getattr(current, 'shape', None):
                    out = np.asarray(layer_arr, dtype=np.float32).reshape((-1, 4)).copy()
                    rows = np.nonzero(delta > tol)[0]
                    if rows.size > 0:
                        recovered = bool(_recover_visible_master_rows_to_layer_array(
                            image,
                            out,
                            rows,
                            enabled_projection[rows, :3],
                            current[rows, :3],
                            baseline_alpha=enabled_projection[rows, 3],
                            current_alpha=current[rows, 3],
                            tolerance=tol,
                            context=context,
                        ))
                        if recovered:
                            applied = bool(_write_image_array_np(image, out))
                            if applied:
                                try:
                                    _mark_image_pixels_changed(image, out)
                                except Exception:
                                    pass
        except Exception:
            applied = False
        if not applied:
            applied = bool(_apply_master_delta_to_layer(material, channel, layer_id, enabled_projection, current, tolerance=tol, layers_snapshot=None))
        if applied:
            try:
                layer, image = _layer_image_for_session(material, layer_id, channel)
                if image is not None:
                    image['smart_paint_suite_alpha_authoritative'] = True
                    image['smart_paint_suite_dirty_from_master'] = True
                    for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                        try:
                            if prop in image:
                                del image[prop]
                        except Exception:
                            pass
            except Exception:
                pass
            try:
                mark_layer_stack_pixels_current(material, channel)
            except Exception:
                pass
            try:
                protect_layer_stack_pixels(material, channel)
            except Exception:
                pass
            try:
                _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
            except Exception:
                pass
        return bool(applied)
    except Exception:
        return False

def commit_pending_paint_before_stack_metadata_edit(material, channel: str = 'BASE_COLOR', context=None, *, layer_item=None, metadata_toggle_to_enabled: bool = False, metadata_toggle_to_disabled: bool = False) -> bool:
    """Flush real pending active-layer paint before metadata rebuilds.

    Visibility, group and mask edits can happen while Blender still has an
    uncommitted stroke on the public composited master.  Commit that exact master
    delta first; do not let a stale direct-layer session recompose the master from
    old private pixels and erase the stroke before the solver sees it.
    """
    changed = False
    channel = _safe_channel(channel)
    try:
        if _sps_bodypaint_direct_layer_write_active(material, channel, context):
            try:
                changed = bool(capture_active_private_layer_pixels(material, channel, context, write_back=True)) or changed
            except Exception:
                pass
            _direct_changed = bool(_sps_bodypaint_commit_private_layer_boundary(
                material, channel, context, refresh_master=False, force=True, reason='metadata_edit'
            ))
            try:
                _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
            except Exception:
                pass
            return bool(_direct_changed)
    except Exception:
        pass
    if bool(metadata_toggle_to_enabled):
        # Turning a layer back ON is metadata-only. Any real native Blender paint
        # must already have been committed on the preceding OFF edge or at Save.
        # Re-reading the public master here compares a disabled projection against
        # an enabled stack and can erase/recolour strokes or copy lower layers.
        return False
    try:
        # Metadata-only visibility/opacity edits on an untouched lazy PSD import
        # must not read or protect every 4096px layer before the property setter
        # returns.  If there is no real paint session, the edit is pure metadata
        # and the lazy PSD record can be serialized directly at save time.
        _key = _session_key(material, channel)
        _sess = _MASTER_PAINT_SESSIONS.get(_key)
        _base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_key)
        _base_exact = bool(isinstance(_base_entry, dict) and _base_entry.get('baseline', None) is not None)
        _exact = bool((isinstance(_sess, dict) and _sess.get('baseline') is not None) or _base_exact)
        # Some native Texture Paint sessions only leave their exact baseline in the
        # save cache.  Visibility toggles must still commit that live master delta
        # before rebuilding the stack, otherwise the stroke disappears.
        if (not isinstance(_sess, dict) or _sess.get('baseline') is None) and _base_exact:
            try:
                _MASTER_PAINT_SESSIONS[_key] = {
                    'baseline': _base_entry.get('baseline', None),
                    'master_image': str(_base_entry.get('master_image', '') or ''),
                    'layer_id': str(_base_entry.get('layer_id', '') or _active_layer_id(material) or ''),
                    'lazy': False,
                    'sample_stamp': _base_entry.get('sample_stamp', None),
                    'reason': 'save_baseline_cache_metadata_boundary',
                }
                _sess = _MASTER_PAINT_SESSIONS.get(_key)
            except Exception:
                pass
        _recent = bool(_recent_operator_was_paint(context))
        if (not _exact) and (not _recent):
            try:
                from .clean_layer_stack_engine import _skip_heavy_save_preflight_for_lazy_stack as _sps_lazy_clean
                if bool(_sps_lazy_clean(material, channel, context)):
                    return False
            except Exception:
                pass
    except Exception:
        pass
    # Exact public-master paint must be committed before any preservation/marking
    # helper touches the active private layer. Otherwise a new proxy layer can be
    # materialized first and the later fallback may copy the flattened lower stack.
    try:
        _key_early = _session_key(material, channel)
        _sess_early = _MASTER_PAINT_SESSIONS.get(_key_early)
        if isinstance(_sess_early, dict) and _sess_early.get('baseline') is not None:
            np = _np_module()
            master_early = get_master_texture_image(material, channel, create=False)
            current_early = _sps_image_array_np_no_clip(master_early) if master_early is not None else None
            baseline_early = _sess_early.get('baseline')
            if np is not None and current_early is not None and baseline_early is not None and getattr(baseline_early, 'shape', None) == getattr(current_early, 'shape', None):
                delta_early = np.max(np.abs(current_early[:, :4] - baseline_early[:, :4]), axis=1)
                rows_early = np.nonzero(delta_early > (1.0 / 4096.0))[0]
                total_early = int(delta_early.shape[0]) if getattr(delta_early, 'shape', None) is not None else 0
                brush_like_early = bool(rows_early.size > 0 and (rows_early.size <= 262144 or (total_early > 0 and (rows_early.size / float(total_early)) <= 0.35)))
                if brush_like_early:
                    _layer_id_early = str(_sess_early.get('layer_id', '') or '') or _active_layer_id(material)
                    if _sps_store_sparse_top_normal_master_delta(
                        material, channel, _layer_id_early, baseline_early, current_early, rows_early,
                        session=_sess_early, tolerance=(1.0 / 4096.0),
                    ):
                        changed = True
                        try:
                            _MASTER_PAINT_SESSIONS.pop(_key_early, None)
                        except Exception:
                            pass
                        return True
                elif rows_early.size <= 0:
                    return bool(changed)
    except Exception:
        pass

    _fast_mark_prop = 'sps_fast_pixel_mark_only_' + channel
    try:
        if material is not None:
            material[_fast_mark_prop] = True
    except Exception:
        pass
    private_pixels_preserved = False
    try:
        _preserved = bool(_preserve_active_private_layer_pixels_for_boundary(material, channel, context=context, reason='metadata_pre'))
        private_pixels_preserved = bool(private_pixels_preserved or _preserved)
        changed = bool(_preserved) or changed
    except Exception:
        pass
    try:
        mark_layer_stack_pixels_current(material, channel)
    except Exception:
        pass
    try:
        changed = bool(_flush_direct_layer_session_for_explicit_boundary(material, channel, context=context)) or changed
    except Exception:
        pass
    try:
        _preserved = bool(_preserve_active_private_layer_pixels_for_boundary(material, channel, context=context, reason='metadata_post_flush'))
        private_pixels_preserved = bool(private_pixels_preserved or _preserved)
        changed = bool(_preserved) or changed
    except Exception:
        pass
    # When the user turns a layer back ON, the public master may still show the
    # previous disabled projection.  Comparing that old projection with the newly
    # enabled stack looks like a brush/erase delta, but it is only the visibility
    # change itself.  Skip visible-master recovery only for this specific ON edge;
    # the OFF edge still commits pending strokes before hiding the layer.
    skip_visible_master_recovery = bool(metadata_toggle_to_enabled)
    # Sparse recovery compares the already-painted public master against the
    # *new* metadata state.  On visibility ON/OFF edges that difference is the
    # visibility change itself, not a new brush stroke.  Exact master sessions
    # above still handle real pending strokes before an OFF edge; when there is
    # no exact session, skip sparse recovery to avoid repeatedly applying the
    # same layer pixels and inflating alpha on every toggle cycle.
    # Re-enabling a layer compares the old hidden projection with the newly
    # visible stack, which is metadata only.  Disabling is different: a just-
    # painted layer can still have its only copy on the visible master, so allow
    # bounded sparse recovery there and let the duplicate guard in the helper
    # skip already-committed strokes.
    skip_sparse_visible_master_recovery = bool(metadata_toggle_to_enabled)

    exact_master_pending = False
    try:
        key = _session_key(material, channel)
        session = _MASTER_PAINT_SESSIONS.get(key)
        exact_master_pending = bool((not skip_visible_master_recovery) and session is not None and session.get('baseline') is not None)
    except Exception:
        session = None
        exact_master_pending = False

    if exact_master_pending:
        master_changed = False
        try:
            # Exact baselines are the safe and fast path for Texture Paint.  Do
            # not rebuild the full private stack here just to verify the master;
            # on 2K+ textures that comparison freezes the UI during enable/disable.
            # Instead, compare the live master only against the captured baseline
            # and commit bounded brush-like edits.  Broad differences are treated
            # as projection/visibility changes and are not flattened into a layer.
            np = _np_module()
            master = get_master_texture_image(material, channel, create=False)
            current = _sps_image_array_np_no_clip(master) if master is not None else None
            baseline = session.get('baseline') if isinstance(session, dict) else None
            if np is not None and current is not None and baseline is not None and getattr(baseline, 'shape', None) == getattr(current, 'shape', None):
                delta = np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1)
                changed_count = int(np.count_nonzero(delta > (1.0 / 4096.0)))
                if changed_count <= 0:
                    try:
                        if key in _MASTER_PAINT_SESSIONS:
                            _MASTER_PAINT_SESSIONS[key]['baseline'] = None
                            _MASTER_PAINT_SESSIONS[key]['lazy'] = True
                            _MASTER_PAINT_SESSIONS[key]['sample_stamp'] = _image_sample_stamp(master, 96)
                            _refresh_master_session_signature(_MASTER_PAINT_SESSIONS[key], material, channel)
                    except Exception:
                        pass
                    try:
                        if material is not None and _fast_mark_prop in material:
                            del material[_fast_mark_prop]
                    except Exception:
                        pass
                    return bool(changed)
                total = int(delta.shape[0]) if getattr(delta, 'shape', None) is not None else 0
                brush_like = bool(changed_count <= 262144 or (total > 0 and (changed_count / float(total)) <= 0.35))
                if not brush_like:
                    try:
                        if key in _MASTER_PAINT_SESSIONS:
                            _MASTER_PAINT_SESSIONS[key]['baseline'] = None
                            _MASTER_PAINT_SESSIONS[key]['lazy'] = True
                            _MASTER_PAINT_SESSIONS[key]['sample_stamp'] = _image_sample_stamp(master, 96)
                            _refresh_master_session_signature(_MASTER_PAINT_SESSIONS[key], material, channel)
                    except Exception:
                        pass
                    try:
                        if material is not None and _fast_mark_prop in material:
                            del material[_fast_mark_prop]
                    except Exception:
                        pass
                    return bool(changed)
                try:
                    _layer_id_sparse = (str(session.get('layer_id', '') or '') if isinstance(session, dict) else '') or _active_layer_id(material)
                    _rows_sparse = np.nonzero(delta > (1.0 / 4096.0))[0]
                    if _sps_store_sparse_top_normal_master_delta(
                        material,
                        channel,
                        _layer_id_sparse,
                        baseline,
                        current,
                        _rows_sparse,
                        session=session,
                        tolerance=(1.0 / 4096.0),
                    ):
                        master_changed = True
                        changed = True
                        try:
                            _MASTER_PAINT_SESSIONS.pop(key, None)
                        except Exception:
                            pass
                        try:
                            mark_layer_stack_pixels_current(material, channel)
                        except Exception:
                            pass
                        try:
                            if material is not None and _fast_mark_prop in material:
                                del material[_fast_mark_prop]
                        except Exception:
                            pass
                        return bool(changed)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            _layer_id = (str(session.get('layer_id', '') or '') if isinstance(session, dict) else '') or _active_layer_id(material)
            master_changed = bool(_apply_master_delta_to_layer(
                material,
                channel,
                _layer_id,
                baseline,
                current,
                tolerance=(1.0 / 4096.0),
                layers_snapshot=None,
            ))
            changed = bool(master_changed or changed)
        except Exception:
            master_changed = False
        if bool(master_changed):
            try:
                # The metadata edit itself will rebuild the projection from the
                # private layer stack.  Drop the exact master baseline now so a
                # queued rebuild/sync cannot replay the same flattened delta a
                # second time and thin or erase the just-committed brush stroke.
                _MASTER_PAINT_SESSIONS.pop(key, None)
            except Exception:
                pass
            try:
                mark_layer_stack_pixels_current(material, channel)
            except Exception:
                pass
            try:
                protect_layer_stack_pixels(material, channel)
            except Exception:
                pass
            try:
                if material is not None and _fast_mark_prop in material:
                    del material[_fast_mark_prop]
            except Exception:
                pass
            return bool(changed)
        # An exact/lazy session may be present only because the display target was
        # synchronized, not because the active layer already captured the stroke.
        # If the exact branch did not write pixels, continue into the bounded
        # sparse recovery below.  This is critical for just-added lazy layers:
        # disabling them after a brush stroke must materialize and preserve that
        # stroke before the projection changes.

    # If the active layer is being hidden and no exact session wrote pixels, still
    # recover the live master delta against the projection with that layer forced
    # enabled.  However, if the active private layer already contains real alpha
    # (direct layer painting), the master-vs-projection difference is only the
    # visibility change itself and must not be written back over the layer.
    _active_private_has_visible_alpha = False
    try:
        _layer_obj, _img_obj = _active_layer_image_for_material(material, channel)
        if _img_obj is not None:
            if bool(_img_obj.get('smart_paint_suite_authoritative_sparse_rgba_patch', False)) and bool(_img_obj.get('smart_paint_suite_sparse_rgba_patch_b64', False)):
                _active_private_has_visible_alpha = True
            elif bool(_img_obj.get('smart_paint_suite_intentionally_empty', False) or _img_obj.get('smart_paint_suite_lazy_blank_layer', False) or _img_obj.get('smart_paint_suite_clear_deferred', False)):
                _active_private_has_visible_alpha = False
            else:
                _arr_obj = _image_array_np(_img_obj, use_cache=False)
                if _arr_obj is not None:
                    _active_private_has_visible_alpha = bool(np.max(np.asarray(_arr_obj, dtype=np.float32).reshape((-1, 4))[:, 3]) > (1.0 / 4096.0))
    except Exception:
        _active_private_has_visible_alpha = False
    if False and bool(metadata_toggle_to_disabled) and not bool(_active_private_has_visible_alpha):
        # Disabled in 1.9.172: metadata visibility edges must not synthesize paint
        # from the flattened master.  The exact baseline branch above is the only
        # allowed pre-toggle paint commit.  The generic off-edge recovery was still
        # capable of applying projection deltas back into the active layer, causing
        # color shifts, monochrome source rows, and black soft-alpha fringes.
        try:
            changed = bool(_commit_toggle_off_visible_master_delta_against_enabled_projection(
                material,
                channel,
                context,
                layer_item=layer_item,
                tolerance=(1.0 / 4096.0),
            )) or changed
            if changed:
                try:
                    if material is not None and _fast_mark_prop in material:
                        del material[_fast_mark_prop]
                except Exception:
                    pass
                return bool(changed)
        except Exception:
            pass

    if bool(metadata_toggle_to_disabled):
        # The enabled-projection helper above is the only safe sparse recovery for
        # an OFF edge.  The generic helper below compares against the disabled
        # projection and would source-over existing layer pixels again on every
        # visibility cycle, changing colour/alpha and eventually destroying soft
        # brush gradients.
        skip_sparse_visible_master_recovery = True

    try:
        # Metadata changes such as enable/disable are correctness boundaries for
        # actual paint sessions, but the metadata edit itself also changes the
        # public master image.  When no exact master-paint baseline exists, a
        # forced flattened-master commit would reinterpret the previous visibility
        # result as brush paint and overwrite the active private layer.  Therefore
        # direct sessions are flushed first, then only a brush-sized public-master
        # delta for the edited active layer is recovered.
        changed = bool(_flush_direct_layer_session_for_explicit_boundary(material, channel, context=context)) or changed
    except Exception:
        pass
    if not skip_sparse_visible_master_recovery:
        try:
            edited_layer_id = ''
            if layer_item is not None:
                edited_layer_id = str(getattr(layer_item, 'layer_id', '') or '')
            changed = bool(_commit_sparse_visible_master_delta_before_stack_metadata_edit(material, channel, context, target_layer_id=edited_layer_id)) or changed
        except Exception:
            pass
    if changed:
        try:
            mark_layer_stack_pixels_current(material, channel)
        except Exception:
            pass
        try:
            protect_layer_stack_pixels(material, channel)
        except Exception:
            pass
    try:
        # Pure visibility toggles are represented by the lazy stack signature and
        # can safely use/reuse cached projections.  Invalidate only when a real
        # paint commit changed private pixels; otherwise repeated ON/OFF cycles
        # decode the whole PSD stack every time and can appear to freeze.
        if bool(changed):
            invalidate_lazy_psd_material_preview_cache(material, channel)
    except Exception:
        pass
    try:
        if material is not None and _fast_mark_prop in material:
            del material[_fast_mark_prop]
    except Exception:
        pass
    return bool(changed)

# -----------------------------------------------------------------------------
# Stale internal proxy / legacy backup cleanup
# -----------------------------------------------------------------------------
# Smart Paint went through several proxy strategies while stabilizing PSD/layer
# workflows.  Old .blend files can contain thousands of unrelated internal images:
# *_SPS_PixelBackup, projection stages, temporary selection masks, previousSPS
# placeholders, aborted async proxies, etc.  They are not part of the current
# document state and can make ordinary Blender interaction very slow.  The
# cleanup below is deliberately conservative: it builds a set of currently
# referenced document/layer/node images and removes only known Smart Paint
# temporary data that is not part of the live stack, plus all legacy pixel-backup
# images.

_STALE_PROXY_CLEANUP_CURSOR = 0
_STALE_PROXY_CLEANUP_RUNNING = False
_STALE_PROXY_CLEANUP_LAST = 0.0
_STALE_PROXY_CLEANUP_REPEAT = False
_STALE_PROXY_CLEANUP_REPORT = {'scanned': 0, 'removed': 0, 'cleared': 0}


def _sps_id_name(value) -> str:
    try:
        return str(value or '')
    except Exception:
        return ''


def _live_smart_paint_image_names() -> set[str]:
    live: set[str] = set()
    try:
        # Images explicitly used by UI/tool settings.
        ctx = getattr(bpy, 'context', None)
        scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
        img = getattr(scene_settings, 'active_paint_image', None) if scene_settings is not None else None
        if img is not None:
            live.add(img.name)
        try:
            ip = getattr(getattr(ctx, 'tool_settings', None), 'image_paint', None) if ctx is not None else None
            for attr in ('canvas', 'stencil_image'):
                i = getattr(ip, attr, None) if ip is not None else None
                if i is not None:
                    live.add(i.name)
        except Exception:
            pass
    except Exception:
        pass
    for mat in list(getattr(bpy.data, 'materials', ()) or ()):  # material props/layers/nodes
        try:
            for ch in DEFAULT_CHANNEL_ORDER:
                for prop in (
                    'sps_master_texture_image_', 'sps_document_file_image_', 'sps_visible_master_image_',
                    'sps_selection_mask_image_', 'sps_composite_preview_image_',
                ):
                    name = _sps_id_name(mat.get(prop + ch, ''))
                    if name:
                        live.add(name)
                try:
                    path = _sps_id_name(mat.get('sps_texture_path_' + ch, ''))
                    if path:
                        base = Path(bpy.path.abspath(path)).name
                        if base:
                            live.add(base)
                except Exception:
                    pass
        except Exception:
            pass
        # PropertyGroup layer images, when the add-on is registered.
        try:
            settings = getattr(mat, 'smart_paint_suite', None)
            if settings is not None:
                for layer in getattr(settings, 'layers', ()) or ():
                    for attr in (
                        'base_color_image', 'roughness_image', 'metallic_image', 'normal_image', 'emission_image',
                        'alpha_image', 'height_image', 'ao_image', 'mask_image'
                    ):
                        name = _sps_id_name(getattr(layer, attr, ''))
                        if name:
                            live.add(name)
        except Exception:
            pass
        # Node tree images are public or paint targets and must be retained.
        try:
            if getattr(mat, 'use_nodes', False) and getattr(mat, 'node_tree', None) is not None:
                for node in getattr(mat.node_tree, 'nodes', ()) or ():
                    img = getattr(node, 'image', None)
                    if img is not None:
                        live.add(img.name)
        except Exception:
            pass
    return live


def _remove_image_datablock(image) -> bool:
    try:
        if image is None:
            return False
        bpy.data.images.remove(image, do_unlink=True)
        return True
    except Exception:
        return False


def _clear_legacy_proxy_props(image) -> int:
    cleared = 0
    if image is None:
        return 0
    for key in (
        'smart_paint_suite_backup_image', 'smart_paint_suite_last_nonempty_backup',
        'smart_paint_suite_async_reload_pending', 'smart_paint_suite_projection_uninitialized',
        'smart_paint_suite_restored_from_backup', 'smart_paint_suite_backup_restore_count',
    ):
        try:
            if key in image:
                del image[key]
                cleared += 1
        except Exception:
            pass
    return cleared


def _is_stale_internal_proxy_image(image, live: set[str], *, aggressive: bool = False) -> bool:
    try:
        if image is None:
            return False
        name = str(getattr(image, 'name', '') or '')
        # Legacy backup images are never needed for the current algorithm and are
        # the most common cause of bloated, slow .blend files.
        if bool(image.get('smart_paint_suite_transient_save_image', False)):
            return True
        if bool(image.get('smart_paint_suite_layer_backup', False)) or name.endswith('_SPS_PixelBackup'):
            return True
        # Projection stages are temporary write targets only.  A completed stage
        # is promoted to the public document image; remaining stages are stale.
        if bool(image.get('smart_paint_suite_projection_stage', False)) or '_SPS_ProjectionStage_' in name:
            return True
        if 'previousSPS' in name and name not in live:
            return True
        if bool(image.get('smart_paint_suite_selection_mask', False)) and name not in live:
            return True
        if bool(image.get('smart_paint_suite_external_reload_source', False)) and name not in live:
            return True
        if bool(image.get('smart_paint_suite_layer_image', False)) and name not in live:
            # Private layer image with no live layer/node/material reference.
            return True
        if bool(image.get('smart_paint_suite_master_texture', False)) and name not in live and name.startswith('SPS_'):
            return True
        if aggressive and name not in live:
            if name.startswith('SPS_') and any(token in name for token in ('Composite', 'SaveComposite', 'Selection', 'Background', 'Projection', 'PixelBackup')):
                return True
    except Exception:
        return False
    return False


def cleanup_stale_proxy_data(*, max_images: int = 96, aggressive: bool = False, full: bool = False) -> dict:
    """Remove old Smart Paint proxy/backup data from the current .blend.

    The function is chunkable.  It is safe to call periodically because it only
    removes known temporary Smart Paint images not referenced by materials, layer
    stacks, paint settings or node trees, and all legacy pixel backups.
    """
    global _STALE_PROXY_CLEANUP_CURSOR, _STALE_PROXY_CLEANUP_REPORT
    report = {'scanned': 0, 'removed': 0, 'cleared': 0, 'done': False}
    try:
        images = list(getattr(bpy.data, 'images', ()) or ())
        if not images:
            report['done'] = True
            _STALE_PROXY_CLEANUP_CURSOR = 0
            return report
        live = _live_smart_paint_image_names()
        limit = len(images) if full else max(1, int(max_images or 96))
        start = max(0, min(int(_STALE_PROXY_CLEANUP_CURSOR), len(images) - 1))
        processed = 0
        index = start
        while processed < limit and images:
            if index >= len(images):
                index = 0
            image = images[index]
            processed += 1
            report['scanned'] += 1
            try:
                if _is_stale_internal_proxy_image(image, live, aggressive=aggressive):
                    if _remove_image_datablock(image):
                        report['removed'] += 1
                        images.pop(index)
                        if not images:
                            break
                        continue
                else:
                    report['cleared'] += _clear_legacy_proxy_props(image)
            except ReferenceError:
                images.pop(index)
                if not images:
                    break
                continue
            except Exception:
                pass
            index += 1
            if index >= len(images):
                index = 0
            if full and processed >= len(images):
                break
        if full or index <= start or processed >= len(images):
            report['done'] = True
            _STALE_PROXY_CLEANUP_CURSOR = 0
        else:
            _STALE_PROXY_CLEANUP_CURSOR = index
        try:
            for k in ('scanned', 'removed', 'cleared'):
                _STALE_PROXY_CLEANUP_REPORT[k] = int(_STALE_PROXY_CLEANUP_REPORT.get(k, 0)) + int(report.get(k, 0))
        except Exception:
            pass
    except Exception:
        report['done'] = True
        _STALE_PROXY_CLEANUP_CURSOR = 0
    return report


def _stale_proxy_cleanup_timer():
    """Retired compatibility callback; explicit maintenance only."""
    global _STALE_PROXY_CLEANUP_RUNNING, _STALE_PROXY_CLEANUP_REPEAT
    _STALE_PROXY_CLEANUP_REPEAT = False
    _STALE_PROXY_CLEANUP_RUNNING = False
    return None

def schedule_stale_proxy_cleanup(*, repeat: bool = False, delay: float = 0.25, reset: bool = False) -> None:
    # Zero-idle policy: do not start cleanup timers automatically.  Large .blend
    # files can have tens of thousands of Smart Paint Image datablocks; scanning
    # them in the background makes ordinary Blender interaction heavy.  Explicit
    # maintenance paths may call cleanup_stale_proxy_data() directly.
    global _STALE_PROXY_CLEANUP_RUNNING, _STALE_PROXY_CLEANUP_REPEAT
    _STALE_PROXY_CLEANUP_REPEAT = False
    _STALE_PROXY_CLEANUP_RUNNING = False
    return None



# -----------------------------------------------------------------------------
# Layered PSD / PSB import support
# -----------------------------------------------------------------------------
# This reader intentionally covers the raster layer subset needed by Smart Paint:
# RGB / grayscale / basic CMYK documents, 8/16/32-bit channels, raw/RLE/ZIP channel
# payloads, Unicode layer names, visibility, opacity and common blend modes.  It
# does not execute Photoshop-only adjustment, text, vector or effect descriptors;
# raster channel data found in those records is still imported when present.

_PSD_TO_SPS_BLEND = {
    b'norm': 'MIX', b'pass': 'PASS_THROUGH', b'diss': 'MIX',
    b'mul ': 'MULTIPLY', b'scrn': 'SCREEN', b'over': 'OVERLAY',
    b'sLit': 'SOFT_LIGHT', b'hLit': 'HARD_LIGHT',
    b'div ': 'COLOR_DODGE', b'dodg': 'COLOR_DODGE', b'idiv': 'COLOR_BURN',
    b'lddg': 'LINEAR_DODGE', b'add ': 'ADD', b'lbrn': 'LINEAR_BURN',
    b'subt': 'SUBTRACT', b'fsub': 'SUBTRACT', b'fdiv': 'DIVIDE',
    b'diff': 'DIFFERENCE', b'smud': 'EXCLUSION', b'dark': 'DARKEN', b'lite': 'LIGHTEN',
    b'vLit': 'VIVID_LIGHT', b'lLit': 'LINEAR_LIGHT', b'pLit': 'PIN_LIGHT',
    b'hue ': 'TINT', b'sat ': 'SATURATION', b'colr': 'COLOR', b'lum ': 'VALUE',
}

# Adobe's PSD specification lists adjustment-layer records as additional layer
# information keyed by these 4-byte OSType values.  Smart Paint parses known
# values for display, but preserves every raw payload below so Photoshop-specific
# Descriptor parameters round-trip byte-for-byte.
_PSD_ADJUSTMENT_KEYS = {
    b'SoCo', b'GdFl', b'PtFl', b'brit', b'levl', b'curv', b'expA', b'vibA',
    b'hue ', b'hue2', b'blnc', b'blwh', b'phfl', b'mixr', b'clrL', b'nvrt',
    b'post', b'thrs', b'grdm', b'selc', b'CgEd',
}



class SPSPSDReadError(ValueError):
    """Raised when a PSD/PSB is structurally corrupted or unsafe to import."""


def _psd_corrupt(message: str):
    msg = str(message or 'PSD/PSB data is corrupted.')
    raise SPSPSDReadError('PSD/PSB file is corrupted or unsupported: ' + msg)


def _psd_check_range(data, offset: int, size: int, label: str, *, end: int | None = None) -> int:
    try:
        off = int(offset); sz = int(size)
        bound = len(data) if end is None else min(int(end), len(data))
    except Exception:
        _psd_corrupt(f'{label} has an invalid offset or length.')
    if off < 0 or sz < 0 or off > bound or off + sz > bound:
        _psd_corrupt(f'{label} is outside the file bounds.')
    return off + sz


def _psd_decompress_limited(body: bytes, expected: int) -> bytes:
    """Decompress ZIP PSD data without allowing a corrupted file to balloon memory."""
    expected = max(0, int(expected))
    if expected <= 0:
        return b''
    try:
        decomp = zlib.decompressobj()
        out = decomp.decompress(body, expected + 1)
        if len(out) > expected:
            return bytes(out[:expected])
        # Flush only within the same strict cap; never allocate beyond expected.
        if len(out) < expected:
            out += decomp.flush(expected - len(out))
        return bytes(out[:expected])
    except Exception as exc:
        _psd_corrupt(f'compressed channel data cannot be decoded ({exc}).')


def _psd_validate_document_structure(data, filepath: str | Path | None = None, *, require_layers: bool = False) -> dict:
    """Validate PSD/PSB structural lengths before any expensive decoding.

    Corrupted PSDs often contain impossible section lengths, layer counts, channel
    counts, or channel byte sizes.  The old parser used min() clipping for many
    of these values, which could make Blender spend a long time decoding garbage
    or native fallback previews.  This guard rejects those files before the load
    job starts and reports a clear import failure.
    """
    file_size = len(data)
    if file_size < 26:
        _psd_corrupt('file is shorter than a PSD header.')
    if bytes(data[0:4]) != b'8BPS':
        _psd_corrupt('missing 8BPS signature.')
    version = struct.unpack_from('>H', data, 4)[0]
    if version not in {1, 2}:
        _psd_corrupt('unsupported PSD/PSB version.')
    psb = version == 2
    offset = 12
    _psd_check_range(data, offset, 14, 'PSD header')
    channels = struct.unpack_from('>H', data, offset)[0]; offset += 2
    height = struct.unpack_from('>I', data, offset)[0]; offset += 4
    width = struct.unpack_from('>I', data, offset)[0]; offset += 4
    depth = struct.unpack_from('>H', data, offset)[0]; offset += 2
    color_mode = struct.unpack_from('>H', data, offset)[0]; offset += 2
    if channels <= 0 or channels > 64:
        _psd_corrupt(f'invalid channel count ({channels}).')
    if width <= 0 or height <= 0:
        _psd_corrupt('document has no pixel area.')
    if width > 32768 or height > 32768 or int(width) * int(height) > 268_435_456:
        _psd_corrupt(f'document size is too large for safe import ({width}x{height}).')
    if depth not in {8, 16, 32}:
        _psd_corrupt(f'unsupported bit depth ({depth}).')
    if color_mode not in {1, 3, 4}:
        _psd_corrupt(f'unsupported color mode ({color_mode}).')

    _psd_check_range(data, offset, 4, 'color mode section length')
    color_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
    offset = _psd_check_range(data, offset, color_len, 'color mode section')
    _psd_check_range(data, offset, 4, 'image resources section length')
    resources_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
    offset = _psd_check_range(data, offset, resources_len, 'image resources section')
    len_size = 8 if psb else 4
    _psd_check_range(data, offset, len_size, 'layer and mask section length')
    if psb:
        layer_mask_len = struct.unpack_from('>Q', data, offset)[0]; offset += 8
    else:
        layer_mask_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
    layer_mask_start = offset
    layer_mask_end = _psd_check_range(data, layer_mask_start, layer_mask_len, 'layer and mask section')
    result = {
        'psb': bool(psb), 'width': int(width), 'height': int(height), 'channels': int(channels),
        'depth': int(depth), 'color_mode': int(color_mode), 'layer_mask_start': int(layer_mask_start),
        'layer_mask_end': int(layer_mask_end), 'layer_info_start': int(layer_mask_start),
        'layer_info_end': int(layer_mask_start), 'layer_count': 0,
    }
    if layer_mask_len <= 0:
        if require_layers:
            _psd_corrupt('file contains no layer information.')
        return result
    offset = layer_mask_start
    _psd_check_range(data, offset, len_size, 'layer info section length', end=layer_mask_end)
    if psb:
        layer_info_len = struct.unpack_from('>Q', data, offset)[0]; offset += 8
    else:
        layer_info_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
    layer_info_start = offset
    layer_info_end = _psd_check_range(data, layer_info_start, layer_info_len, 'layer info section', end=layer_mask_end)
    result['layer_info_start'] = int(layer_info_start)
    result['layer_info_end'] = int(layer_info_end)
    if layer_info_len <= 0:
        if require_layers:
            _psd_corrupt('file contains no layer records.')
        return result
    _psd_check_range(data, offset, 2, 'layer count', end=layer_info_end)
    raw_count = struct.unpack_from('>h', data, offset)[0]; offset += 2
    count = abs(int(raw_count))
    result['layer_count'] = int(count)
    if count <= 0:
        if require_layers:
            _psd_corrupt('file contains no readable layer records.')
        return result
    if count > 4096:
        _psd_corrupt(f'layer count is unsafe ({count}).')
    channel_len_size = 8 if psb else 4
    total_channel_bytes = 0
    # Photoshop permits layer rectangles to sit far outside the canvas. Validate
    # local rectangle size, not absolute placement, to avoid false save failures on
    # production PSDs that use large out-of-canvas coordinates.
    for index in range(count):
        _psd_check_range(data, offset, 18, f'layer record {index + 1}', end=layer_info_end)
        top = struct.unpack_from('>i', data, offset)[0]; offset += 4
        left = struct.unpack_from('>i', data, offset)[0]; offset += 4
        bottom = struct.unpack_from('>i', data, offset)[0]; offset += 4
        right = struct.unpack_from('>i', data, offset)[0]; offset += 4
        box_w = int(right) - int(left); box_h = int(bottom) - int(top)
        if box_w < 0 or box_h < 0:
            _psd_corrupt(f'layer record {index + 1} has inverted bounds.')
        if box_w * box_h > 268_435_456:
            _psd_corrupt(f'layer record {index + 1} is too large for safe import.')
        channel_count = struct.unpack_from('>H', data, offset)[0]; offset += 2
        if channel_count < 0 or channel_count > 64:
            _psd_corrupt(f'layer record {index + 1} has invalid channel count ({channel_count}).')
        for channel_index in range(int(channel_count)):
            _psd_check_range(data, offset, 2 + channel_len_size, f'layer {index + 1} channel {channel_index + 1} header', end=layer_info_end)
            _channel_id = struct.unpack_from('>h', data, offset)[0]; offset += 2
            if psb:
                channel_len = struct.unpack_from('>Q', data, offset)[0]; offset += 8
            else:
                channel_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
            if channel_len < 0:
                _psd_corrupt(f'layer {index + 1} channel {channel_index + 1} has a negative byte length.')
            # Channel length includes the 2-byte compression field.  Zero exists
            # in some structural records; otherwise tiny payloads are corrupt.
            if channel_len == 1:
                _psd_corrupt(f'layer {index + 1} channel {channel_index + 1} is truncated.')
            total_channel_bytes += int(channel_len)
            if total_channel_bytes > max(0, layer_info_end - offset):
                # This is a conservative early test; records still have to finish,
                # so the actual available payload area is even smaller.
                _psd_corrupt('layer channel data length exceeds the layer info section.')
        _psd_check_range(data, offset, 12, f'layer record {index + 1} blend/flags', end=layer_info_end)
        offset += 12  # blend signature/key + opacity + clipping + flags + filler
        _psd_check_range(data, offset, 4, f'layer record {index + 1} extra length', end=layer_info_end)
        extra_len = struct.unpack_from('>I', data, offset)[0]; offset += 4
        offset = _psd_check_range(data, offset, extra_len, f'layer record {index + 1} extra data', end=layer_info_end)
    payload_offset = offset
    if payload_offset + total_channel_bytes > layer_info_end:
        _psd_corrupt('layer channel data is truncated or overlaps another PSD section.')
    return result


def validate_layered_psd_file(filepath: str | Path, *, require_layers: bool = False) -> dict:
    path = Path(filepath)
    if not path.exists():
        raise SPSPSDReadError('PSD/PSB file does not exist.')
    try:
        file_size = int(path.stat().st_size)
    except Exception:
        file_size = 0
    # Avoid reading unbounded damaged files into Blender just to discover that
    # their internal length tables are nonsense.  Valid very large production PSDs
    # should be converted externally or split before editable layer import.
    if file_size <= 0:
        raise SPSPSDReadError('PSD/PSB file is empty.')
    if file_size > 2 * 1024 * 1024 * 1024:
        raise SPSPSDReadError('PSD/PSB file is too large for safe editable import.')
    try:
        data_bytes = path.read_bytes()
    except Exception as exc:
        raise SPSPSDReadError('PSD/PSB file cannot be opened: ' + str(exc))
    return _psd_validate_document_structure(memoryview(data_bytes), path, require_layers=require_layers)


def validate_layered_psd_file_for_import(filepath: str | Path, *, require_layers: bool = False) -> tuple[bool, str]:
    """Return a non-throwing PSD/PSB validation result for UI import paths.

    This wrapper is used before Blender's native PSD loader is touched. It
    prevents corrupted files from falling through into native decoding, which can
    freeze Blender on impossible section lengths or channel payloads.
    """
    try:
        validate_layered_psd_file(filepath, require_layers=require_layers)
        return True, ''
    except Exception as exc:
        msg = str(exc or '').strip()
        if not msg:
            msg = 'The file may be corrupted.'
        if not msg.startswith('PSD/PSB import failed'):
            msg = 'PSD/PSB import failed: ' + msg
        return False, msg


def validate_psd_file_for_import(filepath: str | Path, *, require_layers: bool = False) -> tuple[bool, str]:
    """Compatibility alias for callers that validate before native load."""
    return validate_layered_psd_file_for_import(filepath, require_layers=require_layers)


def _psd_u16(data, offset: int) -> tuple[int, int]:
    if offset + 2 > len(data):
        raise ValueError('Unexpected end of PSD data.')
    return struct.unpack_from('>H', data, offset)[0], offset + 2


def _psd_i16(data, offset: int) -> tuple[int, int]:
    if offset + 2 > len(data):
        raise ValueError('Unexpected end of PSD data.')
    return struct.unpack_from('>h', data, offset)[0], offset + 2


def _psd_u32(data, offset: int) -> tuple[int, int]:
    if offset + 4 > len(data):
        raise ValueError('Unexpected end of PSD data.')
    return struct.unpack_from('>I', data, offset)[0], offset + 4


def _psd_i32(data, offset: int) -> tuple[int, int]:
    if offset + 4 > len(data):
        raise ValueError('Unexpected end of PSD data.')
    return struct.unpack_from('>i', data, offset)[0], offset + 4


def _psd_len(data, offset: int, *, psb: bool = False) -> tuple[int, int]:
    if psb:
        if offset + 8 > len(data):
            raise ValueError('Unexpected end of PSB data.')
        return struct.unpack_from('>Q', data, offset)[0], offset + 8
    return _psd_u32(data, offset)


def _psd_bytes(data, offset: int, size: int) -> tuple[bytes, int]:
    size = max(0, int(size))
    end = _psd_check_range(data, offset, size, 'PSD byte block')
    return bytes(data[offset:end]), end


def _psd_pad2(offset: int) -> int:
    return offset + (offset & 1)


def _psd_pascal_name(data, offset: int, end: int) -> tuple[str, int]:
    if offset >= end:
        return '', offset
    length = int(data[offset])
    start = offset + 1
    stop = min(start + length, end)
    raw = bytes(data[start:stop])
    field_len = 1 + length
    field_len += (4 - (field_len % 4)) % 4
    next_offset = min(end, offset + field_len)
    for encoding in ('macroman', 'latin1', 'utf-8'):
        try:
            return raw.decode(encoding, 'replace').replace('\x00', '').strip(), next_offset
        except Exception:
            continue
    return raw.decode('latin1', 'replace').replace('\x00', '').strip(), next_offset


def _psd_unicode_name(block: bytes) -> str:
    try:
        if len(block) < 4:
            return ''
        count = struct.unpack_from('>I', block, 0)[0]
        raw = block[4:4 + max(0, int(count)) * 2]
        return raw.decode('utf-16be', 'replace').rstrip('\x00').strip()
    except Exception:
        return ''



def _psd_adjustment_from_tag(key: bytes, block: bytes) -> dict:
    """Best-effort PSD adjustment-layer decoder.

    Photoshop stores many adjustment settings as tagged layer blocks.  This
    parser covers the common controls requested by the user and keeps unknown
    payloads as metadata.  Values are normalized to Smart Paint adjustment
    properties; unsupported fields remain safely neutral instead of flattening.
    """
    out = {}
    try:
        # Photoshop 2026 stores modern Brightness/Contrast values in CgEd,
        # while brit remains neutral. The shared decoder also handles the
        # versioned Levels and Hue/Saturation offsets used by Photoshop/CSP.
        from .mvp import adjustments as _mvp_adjustments

        native = _mvp_adjustments.decode_tag_payload(key, block)
        if native:
            return native
    except Exception:
        pass
    try:
        k = bytes(key)
        b = bytes(block)
        if k == b'brit' and len(b) >= 6:
            # Brightness/contrast: signed int16 brightness, contrast, mean.
            br = struct.unpack_from('>h', b, 0)[0]
            co = struct.unpack_from('>h', b, 2)[0]
            out.update({'adjustment_type': 'BRIGHTNESS_CONTRAST', 'adj_brightness': max(-1.0, min(1.0, br / 150.0)), 'adj_contrast': max(-1.0, min(1.0, co / 100.0))})
        elif k == b'hue2' and len(b) >= 8:
            # Hue/saturation stores several ranges.  Use the master range which
            # starts after version/colorize fields in common PSDs.
            vals = []
            for off in range(4, min(len(b), 16), 2):
                try: vals.append(struct.unpack_from('>h', b, off)[0])
                except Exception: vals.append(0)
            hue = vals[0] if len(vals) > 0 else 0
            sat = vals[1] if len(vals) > 1 else 0
            lig = vals[2] if len(vals) > 2 else 0
            out.update({'adjustment_type': 'HUE_SATURATION', 'adj_hue': max(-1.0, min(1.0, hue / 180.0)), 'adj_saturation': max(-1.0, min(1.0, sat / 100.0)), 'adj_lightness': max(-1.0, min(1.0, lig / 100.0))})
        elif k == b'post' and len(b) >= 2:
            levels = struct.unpack_from('>H', b, 0)[0]
            out.update({'adjustment_type': 'POSTERIZE', 'adj_posterize_levels': max(2, min(256, int(levels)))})
        elif k == b'nvrt':
            out.update({'adjustment_type': 'INVERT'})
        elif k == b'thrs' and len(b) >= 2:
            value = struct.unpack_from('>H', b, 0)[0]
            out.update({'adjustment_type': 'THRESHOLD', 'adj_threshold': max(0.0, min(1.0, value / 255.0))})
        elif k == b'levl' and len(b) >= 12:
            # Use first levels record: input black, input white, gamma, output black, output white.
            # gamma is stored as fixed-ish 100 = 1.0 in many PSDs.
            ib = struct.unpack_from('>H', b, 0)[0] if len(b) >= 2 else 0
            iw = struct.unpack_from('>H', b, 2)[0] if len(b) >= 4 else 255
            gm = struct.unpack_from('>H', b, 4)[0] if len(b) >= 6 else 100
            ob = struct.unpack_from('>H', b, 6)[0] if len(b) >= 8 else 0
            ow = struct.unpack_from('>H', b, 8)[0] if len(b) >= 10 else 255
            out.update({'adjustment_type': 'LEVELS', 'adj_levels_input_black': ib/255.0, 'adj_levels_input_white': max(ib+1, iw)/255.0, 'adj_levels_gamma': max(0.01, gm/100.0), 'adj_levels_output_black': ob/255.0, 'adj_levels_output_white': ow/255.0})
        elif k == b'curv':
            pts = [(0.0,0.0),(1.0,1.0)]
            try:
                # Very small tolerant parser: search for y/x uint16 pairs in 0..255.
                values = [struct.unpack_from('>H', b, off)[0] for off in range(0, len(b)-1, 2)]
                pairs = []
                for i in range(0, len(values)-1, 2):
                    y, x = values[i], values[i+1]
                    if 0 <= x <= 255 and 0 <= y <= 255:
                        pairs.append((x/255.0, y/255.0))
                if len(pairs) >= 2:
                    pts = sorted(set(pairs))
            except Exception:
                pass
            out.update({'adjustment_type': 'CURVES', 'adj_curve_points': json.dumps(pts, separators=(',', ':'))})
        elif k == b'blnc':
            vals = []
            for off in range(0, min(len(b), 18), 2):
                try: vals.append(struct.unpack_from('>h', b, off)[0] / 100.0)
                except Exception: vals.append(0.0)
            while len(vals) < 9:
                vals.append(0.0)
            out.update({'adjustment_type': 'COLOR_BALANCE', 'adj_color_balance_shadows': vals[0:3], 'adj_color_balance_midtones': vals[3:6], 'adj_color_balance_highlights': vals[6:9]})
        elif k == b'grdm':
            # Full Photoshop gradient descriptors are complex.  Preserve a neutral
            # black-white gradient map and retain the raw tag as metadata.
            out.update({'adjustment_type': 'GRADIENT_MAP'})
    except Exception:
        return {}
    return out

def _psd_parse_layer_extra(data, offset: int, end: int, *, psb: bool = False) -> dict:
    info = {'name': '', 'unicode_name': '', 'section_type': 0, 'tags': [], 'adjustment': {}, 'tag_payloads': {}, 'raw_adjustment_tag_payloads': {}, 'raw_layer_tag_payloads': {}}
    try:
        if offset + 4 <= end:
            mask_len, offset = _psd_u32(data, offset)
            mask_start = offset
            mask_end = min(end, offset + int(mask_len))
            if int(mask_len) > 0:
                try:
                    info['raw_mask_data'] = bytes(data[mask_start:mask_end]).hex()
                except Exception:
                    pass
            if int(mask_len) >= 20 and mask_start + 16 <= mask_end:
                try:
                    mt, ml, mb, mr = struct.unpack_from('>iiii', data, mask_start)
                    if int(mr) >= int(ml) and int(mb) >= int(mt):
                        info['mask_rect'] = {
                            'top': int(mt), 'left': int(ml),
                            'bottom': int(mb), 'right': int(mr),
                        }
                except Exception:
                    pass
            offset = mask_end
        if offset + 4 <= end:
            blend_len, offset = _psd_u32(data, offset)
            offset = min(end, offset + int(blend_len))
        name, offset = _psd_pascal_name(data, offset, end)
        info['name'] = name
        while offset + 12 <= end:
            sig = bytes(data[offset:offset + 4]); offset += 4
            if sig not in {b'8BIM', b'8B64'}:
                break
            key = bytes(data[offset:offset + 4]); offset += 4
            size4, offset = _psd_u32(data, offset)
            size = int(size4)
            # Some PSB tagged blocks use an 8-byte length.  Most PSD/PSB layer
            # name and section blocks remain 4-byte.  If the 4-byte value cannot
            # fit in the remaining record, reinterpret it as the high word of a
            # PSB 8-byte length.
            if psb and size > max(0, end - offset) and offset + 4 <= end:
                low, offset = _psd_u32(data, offset)
                size = (int(size4) << 32) | int(low)
            if size < 0 or offset + size > end:
                break
            block = bytes(data[offset:offset + size])
            offset += size
            offset = min(end, _psd_pad2(offset))
            try:
                key_text = key.decode('ascii', 'replace')
                info['tags'].append(key_text)
            except Exception:
                key_text = repr(key)
            try:
                # Preserve all tagged layer blocks except the ones Smart Paint
                # regenerates structurally.  This includes Photoshop Descriptor
                # payloads that Smart Paint does not expose in the UI.
                if key not in {b'luni', b'lsct', b'lsdk', b'SPSi', b'SPSl'}:
                    info['raw_layer_tag_payloads'][key_text] = block.hex()
                if key in _PSD_ADJUSTMENT_KEYS:
                    info['raw_adjustment_tag_payloads'][key_text] = block.hex()
            except Exception:
                pass
            if key == b'luni':
                text = _psd_unicode_name(block)
                if text:
                    info['unicode_name'] = text
            elif key == b'lyid' and len(block) >= 4:
                try:
                    info['native_layer_id'] = int(struct.unpack_from('>I', block, 0)[0])
                except Exception:
                    pass
            elif key in {b'lsct', b'lsdk'} and len(block) >= 4:
                try:
                    info['section_type'] = int(struct.unpack_from('>I', block, 0)[0])
                except Exception:
                    pass
                if len(block) >= 12 and bytes(block[4:8]) in {b'8BIM', b'8B64'}:
                    try:
                        section_blend_key = bytes(block[8:12])
                        info['section_blend_key'] = section_blend_key
                        section_blend_mode = str(_PSD_TO_SPS_BLEND.get(section_blend_key, '') or '')
                        if section_blend_mode:
                            info['section_blend_mode'] = section_blend_mode
                    except Exception:
                        pass
            elif key == b'SPSi':
                try:
                    payload = block.rstrip(b'\x00').decode('utf-8', 'replace')
                    meta = json.loads(payload) if payload else {}
                    if isinstance(meta, dict):
                        info['sps_layer_info'] = meta
                except Exception:
                    pass
            elif key in _PSD_ADJUSTMENT_KEYS:
                try:
                    adj = _psd_adjustment_from_tag(key, block)
                    if adj:
                        info['adjustment'].update(adj)
                    info['tag_payloads'][key.decode('ascii', 'replace')] = block.hex()
                except Exception:
                    pass
    except Exception:
        pass
    try:
        native_layer_id = int(info.get('native_layer_id', 0) or 0)
        if native_layer_id > 0:
            meta = dict(info.get('sps_layer_info', {}) or {})
            meta.setdefault('layer_id', str(native_layer_id))
            meta['native_layer_id'] = int(native_layer_id)
            info['sps_layer_info'] = meta
    except Exception:
        pass
    return info


def _psd_layer_blend_mode(blend_key: bytes, extra: dict) -> str:
    """Resolve native PSD folder blending before optional Smart Paint metadata."""
    try:
        section_type = int((extra or {}).get('section_type', 0) or 0)
    except Exception:
        section_type = 0
    if section_type in {1, 2}:
        native_group_mode = str((extra or {}).get('section_blend_mode', '') or '').upper()
        if not native_group_mode:
            native_group_mode = str(_PSD_TO_SPS_BLEND.get(bytes(blend_key or b''), '') or '').upper()
        if native_group_mode:
            # Photoshop and CSP author the folder mode in lsct/lsdk or the
            # native record blend key. SPSi may be stale after an external edit.
            return native_group_mode
    try:
        metadata_mode = str(dict((extra or {}).get('sps_layer_info', {}) or {}).get('blend_mode', '') or '').upper()
    except Exception:
        metadata_mode = ''
    native_key = bytes(blend_key or b'')
    native_mode = str(_PSD_TO_SPS_BLEND.get(native_key, '') or '').upper()
    if native_mode:
        if (
            native_key == b'norm'
            and metadata_mode not in {'', 'MIX'}
            and _psd_blend_key(metadata_mode) == native_key
        ):
            # SPS-only modes use a normal PSD carrier and require SPSi to
            # round-trip. Standard Photoshop/CSP keys remain authoritative.
            return metadata_mode
        return native_mode
    return metadata_mode or 'MIX'


def _psd_decode_packbits_row(row: bytes, expected: int) -> bytes:
    out = bytearray()
    i = 0
    expected = max(0, int(expected))
    nrow = len(row)
    while i < nrow and len(out) < expected:
        control = row[i]
        i += 1
        if control <= 127:
            count = control + 1
            out.extend(row[i:i + count])
            i += count
        elif control >= 129:
            count = 257 - control
            if i < nrow:
                out.extend(bytes((row[i],)) * count)
            i += 1
        else:
            # 128 is a no-op in PackBits.
            pass
    if len(out) < expected:
        out.extend(b'\x00' * (expected - len(out)))
    return bytes(out[:expected])


_PSD_FAST_RLE_DECODER = None
_PSD_FAST_RLE_PROBED = False


def _psd_fast_rle_decode(body: bytes, width: int, height: int, depth: int, *, psb: bool = False):
    """Use psd-tools' compiled PackBits decoder when it is available."""
    global _PSD_FAST_RLE_DECODER, _PSD_FAST_RLE_PROBED
    if not _PSD_FAST_RLE_PROBED:
        _PSD_FAST_RLE_PROBED = True
        try:
            from psd_tools.compression import decode_rle
        except Exception:
            try:
                import site
                import sys

                user_site = str(site.getusersitepackages() or "")
                if user_site and Path(user_site).is_dir() and user_site not in sys.path:
                    sys.path.append(user_site)
                from psd_tools.compression import decode_rle
            except Exception:
                decode_rle = None
        _PSD_FAST_RLE_DECODER = decode_rle
    decoder = _PSD_FAST_RLE_DECODER
    if decoder is None:
        return None
    expected = max(0, int(width)) * max(0, int(height)) * max(0, int(depth)) // 8
    try:
        decoded = decoder(
            body,
            int(width),
            int(height),
            int(depth),
            2 if psb else 1,
        )
        if len(decoded) == expected:
            return decoded
    except Exception:
        pass
    return None


def _psd_decode_channel_bytes(raw: bytes, width: int, height: int, depth: int, *, psb: bool = False) -> bytes:
    width = max(0, int(width)); height = max(0, int(height)); depth = int(depth)
    bytes_per_sample = {8: 1, 16: 2, 32: 4}.get(depth)
    if width <= 0 or height <= 0 or bytes_per_sample is None:
        return b''
    expected = width * height * bytes_per_sample
    if len(raw) < 2:
        return b'\x00' * expected
    compression = struct.unpack_from('>H', raw, 0)[0]
    body = raw[2:]
    try:
        if compression == 0:
            out = body[:expected]
            if len(out) < expected:
                out += b'\x00' * (expected - len(out))
            return out
        if compression == 1:
            count_size = 4 if psb else 2
            table_len = height * count_size
            if len(body) < table_len:
                return b'\x00' * expected
            count_code = 'I' if psb else 'H'
            counts = struct.unpack_from(f'>{height}{count_code}', body, 0)
            if table_len + sum(int(count) for count in counts) > len(body):
                _psd_corrupt('RLE channel data is truncated.')
            fast = _psd_fast_rle_decode(body, width, height, depth, psb=psb)
            if fast is not None:
                return fast
            pos = table_len
            out = bytearray(expected)
            row_expected = width * bytes_per_sample
            write_pos = 0
            for count in counts:
                count = int(count)
                if count < 0 or pos + count > len(body):
                    _psd_corrupt('RLE channel data is truncated.')
                row_start = pos
                row_end = pos + count
                row_write_start = write_pos
                target_end = write_pos + row_expected
                read_pos = pos
                malformed = False
                while read_pos < row_end and write_pos < target_end:
                    control = body[read_pos]
                    read_pos += 1
                    if control <= 127:
                        packet_count = control + 1
                        packet_end = read_pos + packet_count
                        write_end = write_pos + packet_count
                        if packet_end > row_end or write_end > target_end:
                            malformed = True
                            break
                        out[write_pos:write_end] = body[read_pos:packet_end]
                        write_pos = write_end
                        read_pos = packet_end
                    elif control >= 129:
                        packet_count = 257 - control
                        write_end = write_pos + packet_count
                        if read_pos >= row_end or write_end > target_end:
                            malformed = True
                            break
                        out[write_pos:write_end] = bytes((body[read_pos],)) * packet_count
                        write_pos = write_end
                        read_pos += 1
                    # 128 is a no-op in PackBits.
                if malformed:
                    decoded = _psd_decode_packbits_row(body[row_start:row_end], row_expected)
                    out[row_write_start:target_end] = decoded
                write_pos = target_end
                pos = row_end
            return bytes(out)
        if compression in {2, 3}:
            out = _psd_decompress_limited(body, expected)
            if len(out) < expected:
                out += b'\x00' * (expected - len(out))
            out = out[:expected]
            if compression == 3 and bytes_per_sample == 1:
                # Reverse Photoshop/TIFF horizontal byte prediction for 8-bit data.
                buf = bytearray(out)
                for y in range(height):
                    row_start = y * width
                    for x in range(1, width):
                        idx = row_start + x
                        buf[idx] = (buf[idx] + buf[idx - 1]) & 0xff
                out = bytes(buf)
            return out
    except SPSPSDReadError:
        raise
    except Exception as exc:
        _psd_corrupt(f'channel data cannot be decoded ({exc}).')
    _psd_corrupt('unsupported PSD channel compression method.')


def _psd_channel_float_array(raw: bytes, width: int, height: int, depth: int, *, psb: bool = False):
    np = _np_module()
    if np is None:
        raise RuntimeError('NumPy is required to import PSD layer pixels.')
    payload = _psd_decode_channel_bytes(raw, width, height, depth, psb=psb)
    n = max(0, int(width)) * max(0, int(height))
    if n <= 0:
        return np.zeros((0,), dtype=np.float32)
    if int(depth) == 8:
        arr = np.frombuffer(payload[:n], dtype=np.uint8).astype(np.float32) / 255.0
    elif int(depth) == 16:
        need = n * 2
        if len(payload) < need:
            payload += b'\x00' * (need - len(payload))
        arr = np.frombuffer(payload[:need], dtype='>u2').astype(np.float32) / 65535.0
    elif int(depth) == 32:
        need = n * 4
        if len(payload) < need:
            payload += b'\x00' * (need - len(payload))
        arr = np.frombuffer(payload[:need], dtype='>f4').astype(np.float32)
    else:
        arr = np.zeros((n,), dtype=np.float32)
    return np.clip(arr.reshape((height, width)), 0.0, 1.0).astype(np.float32, copy=False)



def _psd_layer_mask_to_rgba(record: dict, *, doc_width: int, doc_height: int, depth: int, psb: bool = False):
    np = _np_module()
    if np is None:
        return None
    # A PSD user mask owns an independent rectangle and default value.  Using
    # the pixel-layer bounds here shifts/crops group masks and leaves the area
    # outside a partial mask black even when Photoshop defines it as reveal-all.
    left = int(record.get('left', 0)); top = int(record.get('top', 0))
    right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
    default_color = 0
    mask_flags = 0
    try:
        raw_mask = bytes.fromhex(str(record.get('raw_mask_data', '') or ''))
        if len(raw_mask) >= 18:
            top, left, bottom, right = struct.unpack_from('>iiii', raw_mask, 0)
            default_color = int(raw_mask[16])
            mask_flags = int(raw_mask[17])
    except Exception:
        pass
    box_w = max(0, right - left); box_h = max(0, bottom - top)
    if box_w <= 0 or box_h <= 0:
        return None
    raw = None
    try:
        data = record.get('channel_data', {}) or {}
        raw = data.get(-2, None)
        if raw is None:
            raw = data.get(-3, None)
    except Exception:
        raw = None
    if raw is None:
        return None
    try:
        local = _psd_channel_float_array(raw, box_w, box_h, depth, psb=psb)
    except Exception:
        return None
    default_value = 1.0 if int(default_color) >= 128 else 0.0
    full_mask = np.full((int(doc_height), int(doc_width)), default_value, dtype=np.float32)
    dst_x0 = max(0, left); dst_y0 = max(0, top)
    dst_x1 = min(int(doc_width), right); dst_y1 = min(int(doc_height), bottom)
    if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
        return None
    src_x0 = dst_x0 - left; src_y0 = dst_y0 - top
    src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
    full_mask[dst_y0:dst_y1, dst_x0:dst_x1] = np.clip(
        local[src_y0:src_y1, src_x0:src_x1], 0.0, 1.0
    )
    if int(mask_flags) & 0x04:
        full_mask = 1.0 - full_mask
    full = np.ones((int(doc_height), int(doc_width), 4), dtype=np.float32)
    full[:, :, 0] = full_mask
    full[:, :, 1] = full_mask
    full[:, :, 2] = full_mask
    return np.ascontiguousarray(full[::-1, :, :].reshape((int(doc_width) * int(doc_height), 4)), dtype=np.float32)


def _sps_repair_straight_alpha_rgb_fringes(rgba, *, width: int, height: int, passes: int = 5):
    """Repair RGB on straight-alpha edge pixels without changing coverage.

    Blender stores Image.pixels as straight RGBA.  Some PSD records preserve
    useful alpha coverage in soft edge pixels while leaving their RGB channels
    at zero.  Treat those pixels as colourless coverage: copy RGB from colour-
    bearing pixels, but do not increase alpha or touch fully opaque black paint.
    """
    np = _np_module()
    if np is None or rgba is None:
        return rgba
    try:
        width = int(width); height = int(height)
        if width <= 0 or height <= 0:
            return rgba
        arr = np.asarray(rgba, dtype=np.float32)
        original_shape = arr.shape
        if arr.size != width * height * 4:
            return rgba
        img_full = arr.reshape((height, width, 4))
        alpha_full = np.clip(img_full[:, :, 3], 0.0, 1.0)
        rgb_full = img_full[:, :, :3]
        colour_eps = 3.0 / 255.0
        alpha_eps = 1.0 / 4096.0
        colour_power_full = np.max(np.clip(rgb_full, 0.0, 1.0), axis=2)
        donor_full = (alpha_full > alpha_eps) & (colour_power_full > colour_eps)
        target_full = (alpha_full > alpha_eps) & (alpha_full < (1.0 - alpha_eps)) & (colour_power_full <= colour_eps)
        if not bool(np.any(target_full)):
            return arr.reshape(original_shape)
        if not bool(np.any(donor_full)):
            return arr.reshape(original_shape)

        def _weighted_donor_colour(mask=None):
            try:
                donors = donor_full if mask is None else (donor_full & mask)
                if not bool(np.any(donors)):
                    donors = donor_full
                weights = np.maximum(alpha_full[donors].astype(np.float32, copy=False), alpha_eps)
                colors = np.clip(rgb_full[donors, :].astype(np.float32, copy=False), 0.0, 1.0)
                if colors.size <= 0:
                    return None
                if colors.shape[0] > 1048576:
                    step = max(1, int(colors.shape[0] // 1048576))
                    colors = colors[::step]
                    weights = weights[::step]
                return np.sum(colors * weights[:, None], axis=0) / max(float(np.sum(weights)), alpha_eps)
            except Exception:
                return None

        ys, xs = np.nonzero(target_full)
        if ys.size <= 0 or xs.size <= 0:
            return arr.reshape(original_shape)
        pad = max(2, int(passes) + 3)
        y0 = max(0, int(ys.min()) - pad); y1 = min(height, int(ys.max()) + pad + 1)
        x0 = max(0, int(xs.min()) - pad); x1 = min(width, int(xs.max()) + pad + 1)
        bbox_area = int(y1 - y0) * int(x1 - x0)
        target_count = int(np.count_nonzero(target_full))
        if target_count > 65536 or bbox_area > 1500000:
            colour = _weighted_donor_colour()
            if colour is not None:
                rgb_full[target_full, :] = np.clip(colour.reshape((1, 3)), 0.0, 1.0)
            return arr.reshape(original_shape)

        img = img_full[y0:y1, x0:x1, :]
        h = int(img.shape[0]); w = int(img.shape[1])
        if h <= 0 or w <= 0:
            return arr.reshape(original_shape)
        alpha = np.clip(img[:, :, 3], 0.0, 1.0)
        rgb = img[:, :, :3]
        directions = ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))

        def _shift_slices(dy: int, dx: int):
            if dy < 0:
                dst_y = slice(0, h + dy); src_y = slice(-dy, h)
            elif dy > 0:
                dst_y = slice(dy, h); src_y = slice(0, h - dy)
            else:
                dst_y = slice(0, h); src_y = slice(0, h)
            if dx < 0:
                dst_x = slice(0, w + dx); src_x = slice(-dx, w)
            elif dx > 0:
                dst_x = slice(dx, w); src_x = slice(0, w - dx)
            else:
                dst_x = slice(0, w); src_x = slice(0, w)
            return dst_y, dst_x, src_y, src_x

        for _pass in range(max(1, int(passes))):
            colour_power = np.max(np.clip(rgb, 0.0, 1.0), axis=2)
            donor = (alpha > alpha_eps) & (colour_power > colour_eps)
            target = (alpha > alpha_eps) & (alpha < (1.0 - alpha_eps)) & (colour_power <= colour_eps)
            if not bool(np.any(donor)) or not bool(np.any(target)):
                break
            acc = np.zeros((h, w, 3), dtype=np.float32)
            weight = np.zeros((h, w), dtype=np.float32)
            for dy, dx in directions:
                dst_y, dst_x, src_y, src_x = _shift_slices(int(dy), int(dx))
                m = target[dst_y, dst_x] & donor[src_y, src_x]
                if not bool(np.any(m)):
                    continue
                src_weight = np.maximum(alpha[src_y, src_x], alpha_eps)
                acc_view = acc[dst_y, dst_x, :]
                weight_view = weight[dst_y, dst_x]
                acc_view[m, :] = acc_view[m, :] + rgb[src_y, src_x, :][m, :] * src_weight[m, None]
                weight_view[m] = weight_view[m] + src_weight[m]
            changed = weight > 0.0
            if not bool(np.any(changed)):
                break
            rgb[changed, :] = acc[changed, :] / np.maximum(weight[changed, None], alpha_eps)
        return arr.reshape(original_shape)
    except Exception:
        return rgba


def _sps_prepare_public_master_rgba_for_blender_display(image, shaped):
    """Keep the public document projection visually colour-stable in Blender.

    BodyPaint-style rule: private layer images own alpha and saved pixels; the
    public document image is only a display/projection cache.  Therefore the
    public Base Color/Emission image is always displayed as sRGB straight-alpha
    with opaque alpha, independent of whether its path metadata has already been
    populated.
    """
    np = _np_module()
    if np is None or image is None or shaped is None:
        return shaped
    try:
        is_public = bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_visible_document', False)) or bool(image.get('smart_paint_suite_projection_stage', False))
        if not is_public:
            return shaped
        try:
            ch = str(image.get('smart_paint_suite_channel', '') or '').upper()
        except Exception:
            ch = ''
        if ch not in {'', 'BASE_COLOR', 'EMISSION', 'EMISSION_COLOR'}:
            return shaped
        arr = np.asarray(shaped, dtype=np.float32).reshape((-1, 4))
        if arr.size <= 0:
            return shaped
        try:
            cs = getattr(image, 'colorspace_settings', None)
            if cs is not None and str(getattr(cs, 'name', '') or '') != 'sRGB':
                cs.name = 'sRGB'
                image['smart_paint_suite_public_display_colorspace_forced'] = 'sRGB'
        except Exception:
            pass
        try:
            if str(getattr(image, 'alpha_mode', '') or '') != 'STRAIGHT':
                image.alpha_mode = 'STRAIGHT'
        except Exception:
            pass
        try:
            if hasattr(image, 'use_view_as_render'):
                image.use_view_as_render = False
        except Exception:
            pass
        if bool(np.any(arr[:, 3] < (1.0 - (1.0 / 4096.0)))):
            arr = arr.copy()
            arr[:, 3] = 1.0
            try:
                image['smart_paint_suite_public_display_alpha_forced_opaque'] = True
                image['smart_paint_suite_public_projection_not_export_alpha'] = True
            except Exception:
                pass
        return arr.reshape(np.asarray(shaped).shape)
    except Exception:
        return shaped

def _psd_layer_to_rgba(record: dict, *, doc_width: int, doc_height: int, depth: int, color_mode: int, psb: bool = False, apply_layer_mask: bool = True):
    np = _np_module()
    if np is None:
        raise RuntimeError('NumPy is required to import PSD layer pixels.')
    left = int(record.get('left', 0)); top = int(record.get('top', 0))
    right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
    box_w = max(0, right - left); box_h = max(0, bottom - top)
    if box_w <= 0 or box_h <= 0:
        return None
    channels = {}
    for channel_id, raw in record.get('channel_data', {}).items():
        try:
            channels[int(channel_id)] = _psd_channel_float_array(raw, box_w, box_h, depth, psb=psb)
        except Exception:
            continue
    if not channels:
        return None
    z = np.zeros((box_h, box_w), dtype=np.float32)
    o = np.ones((box_h, box_w), dtype=np.float32)
    if int(color_mode) == 1:  # Grayscale.
        g = channels.get(0, z)
        r = g; b = g
    elif int(color_mode) == 4:  # CMYK, approximate conversion for paint targets.
        c = channels.get(0, z); m = channels.get(1, z); y = channels.get(2, z); k = channels.get(3, z)
        r = 1.0 - np.minimum(1.0, c + k)
        g = 1.0 - np.minimum(1.0, m + k)
        b = 1.0 - np.minimum(1.0, y + k)
    else:  # RGB and common RGB-compatible layer records.
        r = channels.get(0, z)
        g = channels.get(1, r)
        b = channels.get(2, r)
    _has_colour_channels = bool((0 in channels) or (1 in channels) or (2 in channels))
    a = channels.get(-1, o).copy()
    if not _has_colour_channels:
        # Alpha-only PSD records must not become black RGB paint layers.
        a = np.zeros_like(a, dtype=np.float32)
    # User/vector layer masks are preserved as separate Smart Paint mask images.
    # Only preview-oriented callers should request destructive alpha application;
    # import/save roundtrips need the raw layer pixels plus a separate mask to
    # avoid soft masks being squared after Blender <-> PSD <-> Blender.
    if bool(apply_layer_mask):
        if -2 in channels:
            a = a * channels[-2]
        if -3 in channels:
            a = a * channels[-3]
    local = np.dstack((r, g, b, a)).astype(np.float32, copy=False)
    full = np.zeros((int(doc_height), int(doc_width), 4), dtype=np.float32)
    dst_x0 = max(0, left); dst_y0 = max(0, top)
    dst_x1 = min(int(doc_width), right); dst_y1 = min(int(doc_height), bottom)
    if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
        return None
    src_x0 = dst_x0 - left; src_y0 = dst_y0 - top
    src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
    full[dst_y0:dst_y1, dst_x0:dst_x1, :] = local[src_y0:src_y1, src_x0:src_x1, :]
    # PSD RGB and transparency are independent channels.  A covered black pixel
    # is valid colour, including at a soft antialiased edge; inferring a donor
    # colour from unrelated pixels creates visible halos over opaque layers.
    # Keep every decoded source sample exact and handle display filtering at the
    # texture/compositor boundary instead of rewriting authored layer pixels.
    # PSD scanlines are top-to-bottom. Blender Image.pixels are bottom-to-top.
    return np.ascontiguousarray(full[::-1, :, :].reshape((int(doc_width) * int(doc_height), 4)), dtype=np.float32)

def _psd_record_local_cache_identity(record: dict):
    try:
        base_key = str(record.get('_sps_local_cache_key', '') or '')
        if not base_key:
            return None
        ch_sig = []
        for cid, raw in sorted((record.get('channel_data', {}) or {}).items(), key=lambda item: int(item[0])):
            try:
                ch_sig.append((int(cid), int(len(raw) if raw is not None else 0)))
            except Exception:
                ch_sig.append((int(cid), 0))
        return (
            base_key,
            str(record.get('record_index', '') or ''),
            str(record.get('name', '') or ''),
            int(record.get('left', 0) or 0),
            int(record.get('top', 0) or 0),
            int(record.get('right', 0) or 0),
            int(record.get('bottom', 0) or 0),
            tuple(ch_sig),
        )
    except Exception:
        return None


def _psd_record_local_cache_get(record: dict, depth: int, color_mode: int, psb: bool, apply_layer_mask: bool, repair_rgb_fringes: bool):
    np = _np_module()
    if np is None or not isinstance(record, dict):
        return None
    try:
        identity = _psd_record_local_cache_identity(record)
        if identity is None:
            return None
        key = (identity, int(depth), int(color_mode), bool(psb), bool(apply_layer_mask), bool(repair_rgb_fringes))
        hit = _PSD_RECORD_LOCAL_RGBA_CACHE.get(key)
        if hit is None:
            return None
        expected_h = max(0, int(record.get('bottom', 0) or 0) - int(record.get('top', 0) or 0))
        expected_w = max(0, int(record.get('right', 0) or 0) - int(record.get('left', 0) or 0))
        shape = getattr(hit, 'shape', (0, 0, 0))
        if int(shape[0]) != expected_h or int(shape[1]) != expected_w:
            _PSD_RECORD_LOCAL_RGBA_CACHE.pop(key, None)
            return None
        # The cache owns one contiguous payload. Consumers that need mutation
        # explicitly copy at their mutation boundary, avoiding duplicate copies
        # on every cache hit.
        return np.asarray(hit, dtype=np.float32)
    except (TypeError, ValueError, KeyError, _sps_quota.CachePolicyError):
        return None


def _psd_record_local_cache_put(record: dict, depth: int, color_mode: int, psb: bool, apply_layer_mask: bool, repair_rgb_fringes: bool, arr) -> None:
    np = _np_module()
    if np is None or not isinstance(record, dict) or arr is None:
        return
    try:
        identity = _psd_record_local_cache_identity(record)
        if identity is None:
            return
        key = (identity, int(depth), int(color_mode), bool(psb), bool(apply_layer_mask), bool(repair_rgb_fringes))
        payload = np.ascontiguousarray(np.asarray(arr, dtype=np.float32))
        _PSD_RECORD_LOCAL_RGBA_CACHE[key] = payload
    except (TypeError, ValueError, KeyError, _sps_quota.CachePolicyError):
        return

def _psd_record_local_rgba(record: dict, *, depth: int, color_mode: int, psb: bool = False, apply_layer_mask: bool = True, repair_rgb_fringes: bool = True):
    """Decode one PSD layer record to its own bounds, top-to-bottom RGBA."""
    np = _np_module()
    if np is None or not isinstance(record, dict):
        return None
    try:
        cached = _psd_record_local_cache_get(record, depth, color_mode, psb, apply_layer_mask, repair_rgb_fringes)
        if cached is not None:
            return cached
        left = int(record.get('left', 0)); top = int(record.get('top', 0))
        right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
        box_w = max(0, right - left); box_h = max(0, bottom - top)
        if box_w <= 0 or box_h <= 0:
            return None
        channels = {}
        for channel_id, raw in (record.get('channel_data', {}) or {}).items():
            try:
                channels[int(channel_id)] = _psd_channel_float_array(raw, box_w, box_h, depth, psb=psb)
            except Exception:
                continue
        if not channels:
            return None
        z = np.zeros((box_h, box_w), dtype=np.float32)
        o = np.ones((box_h, box_w), dtype=np.float32)
        if int(color_mode) == 1:
            g = channels.get(0, z)
            r = g; b = g
        elif int(color_mode) == 4:
            c = channels.get(0, z); m = channels.get(1, z); y = channels.get(2, z); k = channels.get(3, z)
            r = 1.0 - np.minimum(1.0, c + k)
            g = 1.0 - np.minimum(1.0, m + k)
            b = 1.0 - np.minimum(1.0, y + k)
        else:
            r = channels.get(0, z)
            g = channels.get(1, r)
            b = channels.get(2, r)
        _has_colour_channels = bool((0 in channels) or (1 in channels) or (2 in channels))
        a = channels.get(-1, o).copy()
        if not _has_colour_channels:
            # Alpha-only PSD records must not become black RGB paint layers.
            a = np.zeros_like(a, dtype=np.float32)
        if bool(apply_layer_mask):
            if -2 in channels:
                a = a * channels[-2]
            if -3 in channels:
                a = a * channels[-3]
        local = np.dstack((r, g, b, a)).astype(np.float32, copy=False)
        if bool(repair_rgb_fringes):
            try:
                local = _sps_repair_straight_alpha_rgb_fringes(local, width=box_w, height=box_h)
            except Exception:
                pass
        local = np.ascontiguousarray(local, dtype=np.float32)
        _psd_record_local_cache_put(record, depth, color_mode, psb, apply_layer_mask, repair_rgb_fringes, local)
        return local
    except Exception:
        return None

def _psd_plane_float_array_from_payload(payload: bytes, width: int, height: int, depth: int):
    np = _np_module()
    if np is None:
        return None
    width = max(0, int(width)); height = max(0, int(height)); depth = int(depth)
    n = width * height
    if n <= 0:
        return np.zeros((0,), dtype=np.float32)
    if depth == 8:
        if len(payload) < n:
            payload += b'\x00' * (n - len(payload))
        arr = np.frombuffer(payload[:n], dtype=np.uint8).astype(np.float32) / 255.0
    elif depth == 16:
        need = n * 2
        if len(payload) < need:
            payload += b'\x00' * (need - len(payload))
        arr = np.frombuffer(payload[:need], dtype='>u2').astype(np.float32) / 65535.0
    elif depth == 32:
        need = n * 4
        if len(payload) < need:
            payload += b'\x00' * (need - len(payload))
        arr = np.frombuffer(payload[:need], dtype='>f4').astype(np.float32)
    else:
        arr = np.zeros((n,), dtype=np.float32)
    return np.clip(arr.reshape((height, width)), 0.0, 1.0).astype(np.float32, copy=False)


def _psd_main_composite_to_rgba(data, offset: int, *, doc_width: int, doc_height: int, channels: int, depth: int, color_mode: int, psb: bool = False, output_u8: bool = False):
    """Decode the merged PSD composite image for layer-order validation.

    The PSD layer-record order varies between writers.  Instead of trusting a
    name-based heuristic, Smart Paint compares bottom->top candidates against
    the merged document preview that PSD files store after the Layer and Mask
    section.  The returned array is in Blender Image.pixels order.
    """
    np = _np_module()
    if np is None:
        return None
    width = max(0, int(doc_width)); height = max(0, int(doc_height))
    channel_count = max(0, int(channels)); depth = int(depth)
    if width <= 0 or height <= 0 or channel_count <= 0:
        return None
    bytes_per_sample = {8: 1, 16: 2, 32: 4}.get(depth)
    if bytes_per_sample is None or offset + 2 > len(data):
        return None
    compression = struct.unpack_from('>H', data, offset)[0]
    body = bytes(data[offset + 2:])
    plane_len = width * height * bytes_per_sample
    planes = []
    try:
        if compression == 0:
            expected = plane_len * channel_count
            if len(body) < expected:
                return None
            pos = 0
            for _channel in range(channel_count):
                payload = body[pos:pos + plane_len]
                pos += plane_len
                planes.append(payload[:plane_len])
        elif compression == 1:
            count_size = 4 if psb else 2
            row_total = channel_count * height
            table_len = row_total * count_size
            if len(body) < table_len:
                return None
            fmt = '>I' if psb else '>H'
            counts = []
            pos = 0
            for _row in range(row_total):
                counts.append(struct.unpack_from(fmt, body, pos)[0])
                pos += count_size
            row_expected = width * bytes_per_sample
            for channel_index in range(channel_count):
                out = bytearray()
                for row_index in range(height):
                    count = int(counts[channel_index * height + row_index])
                    if pos + count > len(body):
                        return None
                    row = body[pos:pos + count]
                    pos += count
                    out.extend(_psd_decode_packbits_row(row, row_expected))
                if len(out) < plane_len:
                    out.extend(b'\x00' * (plane_len - len(out)))
                planes.append(bytes(out[:plane_len]))
        elif compression in {2, 3}:
            expected = plane_len * channel_count
            try:
                raw = _psd_decompress_limited(body, expected)
            except SPSPSDReadError:
                return None
            if len(raw) < expected:
                return None
            raw = bytearray(raw[:expected])
            if compression == 3 and bytes_per_sample == 1:
                # Reverse Photoshop/TIFF horizontal byte prediction for 8-bit
                # merged data.  This mirrors the layer-channel decoder.
                row_expected = width * bytes_per_sample
                for channel_index in range(channel_count):
                    plane_start = channel_index * plane_len
                    for row_index in range(height):
                        row_start = plane_start + row_index * row_expected
                        for x in range(1, row_expected):
                            idx = row_start + x
                            raw[idx] = (raw[idx] + raw[idx - 1]) & 0xff
            for channel_index in range(channel_count):
                start = channel_index * plane_len
                planes.append(bytes(raw[start:start + plane_len]))
        else:
            return None
    except Exception:
        return None
    if not planes:
        return None
    try:
        if bool(output_u8) and depth == 8 and int(color_mode) in {1, 3}:
            z8 = np.zeros((height, width), dtype=np.uint8)
            o8 = np.full((height, width), 255, dtype=np.uint8)
            bytes8 = [
                np.frombuffer(payload, dtype=np.uint8, count=width * height).reshape((height, width))
                for payload in planes
            ]
            if int(color_mode) == 1:
                gray = bytes8[0] if bytes8 else z8
                red = green = blue = gray
                alpha = bytes8[1] if len(bytes8) > 1 else o8
            else:
                red = bytes8[0] if len(bytes8) > 0 else z8
                green = bytes8[1] if len(bytes8) > 1 else red
                blue = bytes8[2] if len(bytes8) > 2 else red
                alpha = bytes8[3] if len(bytes8) > 3 else o8
            full8 = np.empty((height, width, 4), dtype=np.uint8)
            full8[:, :, 0] = red
            full8[:, :, 1] = green
            full8[:, :, 2] = blue
            full8[:, :, 3] = alpha
            return np.ascontiguousarray(full8[::-1, :, :].reshape((width * height, 4)))
        z = np.zeros((height, width), dtype=np.float32)
        o = np.ones((height, width), dtype=np.float32)
        floats = [_psd_plane_float_array_from_payload(payload, width, height, depth) for payload in planes]
        floats = [arr if arr is not None else z for arr in floats]
        if int(color_mode) == 1:
            g = floats[0] if len(floats) > 0 else z
            r = g; b = g
            a = floats[1] if len(floats) > 1 else o
        elif int(color_mode) == 4:
            c = floats[0] if len(floats) > 0 else z
            m = floats[1] if len(floats) > 1 else z
            y = floats[2] if len(floats) > 2 else z
            k = floats[3] if len(floats) > 3 else z
            r = 1.0 - np.minimum(1.0, c + k)
            g = 1.0 - np.minimum(1.0, m + k)
            b = 1.0 - np.minimum(1.0, y + k)
            a = floats[4] if len(floats) > 4 else o
        else:
            r = floats[0] if len(floats) > 0 else z
            g = floats[1] if len(floats) > 1 else r
            b = floats[2] if len(floats) > 2 else r
            a = floats[3] if len(floats) > 3 else o
        full = np.dstack((r, g, b, a)).astype(np.float32, copy=False)
        # PSD merged scanlines are top-to-bottom. Blender Image.pixels are
        # bottom-to-top.
        return np.ascontiguousarray(full[::-1, :, :].reshape((width * height, 4)), dtype=np.float32)
    except Exception:
        return None


def read_psd_merged_preview_u8(filepath: str | Path) -> dict:
    """Read only the embedded merged preview, without parsing layer payloads."""
    path = Path(filepath)
    with path.open("rb") as handle:
        header = handle.read(26)
        if len(header) != 26 or header[:4] != b"8BPS":
            raise ValueError("Not a Photoshop PSD/PSB file.")
        version = struct.unpack_from(">H", header, 4)[0]
        if version not in {1, 2}:
            raise ValueError("Unsupported PSD/PSB version.")
        psb = version == 2
        channels = struct.unpack_from(">H", header, 12)[0]
        height = struct.unpack_from(">I", header, 14)[0]
        width = struct.unpack_from(">I", header, 18)[0]
        depth = struct.unpack_from(">H", header, 22)[0]
        color_mode = struct.unpack_from(">H", header, 24)[0]

        def read_length(size: int) -> int:
            payload = handle.read(size)
            if len(payload) != size:
                raise ValueError("PSD section length is truncated.")
            return int.from_bytes(payload, "big", signed=False)

        color_length = read_length(4)
        handle.seek(color_length, 1)
        resource_length = read_length(4)
        handle.seek(resource_length, 1)
        layer_mask_length = read_length(8 if psb else 4)
        handle.seek(layer_mask_length, 1)
        composite = handle.read()

    if len(composite) < 2:
        raise ValueError("PSD merged preview is missing.")
    merged = _psd_main_composite_to_rgba(
        memoryview(composite),
        0,
        doc_width=int(width),
        doc_height=int(height),
        channels=int(channels),
        depth=int(depth),
        color_mode=int(color_mode),
        psb=bool(psb),
        output_u8=True,
    )
    if merged is None:
        raise ValueError("PSD merged preview could not be decoded.")
    return {
        "width": int(width),
        "height": int(height),
        "depth": int(depth),
        "color_mode": int(color_mode),
        "merged": merged,
        "psb": bool(psb),
    }


def _psd_stack_preview_from_layers(layers: list[dict], *, width: int, height: int):
    np = _np_module()
    if np is None or not layers:
        return None
    try:
        out = np.zeros((int(width) * int(height), 4), dtype=np.float32)
        out[:, :3] = 1.0
        out[:, 3] = 1.0
        for layer in layers:
            if not bool(layer.get('enabled', True)):
                continue
            arr = layer.get('rgba')
            if arr is None:
                continue
            arr = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
            if arr.shape[0] != out.shape[0]:
                continue
            alpha = np.clip(arr[:, 3] * max(0.0, min(1.0, float(layer.get('opacity', 1.0) or 0.0))), 0.0, 1.0)
            mask_rgba = layer.get('mask_rgba')
            if mask_rgba is not None:
                try:
                    mask_arr = np.asarray(mask_rgba, dtype=np.float32).reshape((-1, 4))
                    if mask_arr.shape[0] == alpha.shape[0]:
                        alpha = np.clip(alpha * np.clip(mask_arr[:, 0], 0.0, 1.0), 0.0, 1.0)
                except Exception:
                    pass
            out[:, :3] = _blend_rgb(out[:, :3], arr[:, :3], alpha, str(layer.get('blend_mode', 'MIX') or 'MIX'))
        return out
    except Exception:
        return None


def _psd_order_score(layers: list[dict], merged, *, width: int, height: int) -> float | None:
    np = _np_module()
    if np is None or merged is None or not layers:
        return None
    try:
        preview = _psd_stack_preview_from_layers(layers, width=width, height=height)
        if preview is None:
            return None
        target = np.asarray(merged, dtype=np.float32).reshape((-1, 4))
        if target.shape[0] != preview.shape[0]:
            return None
        # Compare RGB.  Merged PSD alpha is optional and many RGB PSDs store no
        # alpha in the flattened preview, so RGB gives a more stable order test.
        diff = np.asarray(preview[:, :3] - target[:, :3], dtype=np.float32)
        return float(np.mean(diff * diff))
    except Exception:
        return None


def _psd_layers_internal_order(layers: list[dict], merged=None, *, width: int = 0, height: int = 0) -> list[dict]:
    raster = [r for r in layers if int(r.get('section_type', 0) or 0) not in {1, 2, 3}]
    if len(raster) <= 1:
        return raster

    def _is_background_name(value: str) -> bool:
        text = str(value or '').strip().lower()
        return (text in {'background', '背景', 'bg', 'back'}
                or text.startswith('background') or text.startswith('背景')
                or text.endswith('/background') or text.endswith('_background'))

    # Do deterministic panel-order normalization before heuristic score tests.
    # Many PSD files, including Smart Paint exports, store records in panel order
    # (top -> bottom).  Smart Paint's internal order is bottom -> top.  If a
    # recognizable background is at the end of the record list, reverse it.
    first = str(raster[0].get('name', '') or '')
    last = str(raster[-1].get('name', '') or '')
    if _is_background_name(first) and not _is_background_name(last):
        return list(raster)
    if _is_background_name(last) and not _is_background_name(first):
        return list(reversed(raster))

    original = list(raster)
    reversed_order = list(reversed(raster))
    score_original = _psd_order_score(original, merged, width=width, height=height)
    score_reversed = _psd_order_score(reversed_order, merged, width=width, height=height)
    if score_original is not None and score_reversed is not None:
        tolerance = max(1.0e-8, min(score_original, score_reversed) * 1.0e-4)
        if score_original + tolerance < score_reversed:
            return original
        if score_reversed + tolerance < score_original:
            return reversed_order
    # PSD/PSB layer records are normally stored in layer-panel order
    # (top -> bottom).  Smart Paint stores layers bottom -> top.  When no merged
    # preview/background heuristic can disambiguate the order, prefer the
    # standards-compatible conversion instead of leaving the record order as-is.
    return reversed_order


def _psd_records_internal_order(records: list[dict]) -> list[dict]:
    # Compatibility wrapper retained for older internal callers.  New PSD import
    # uses _psd_layers_internal_order() after layer pixels are decoded so the
    # merged composite can disambiguate top/bottom order.
    raster = [r for r in records if int(r.get('section_type', 0) or 0) not in {1, 2, 3}]
    if len(raster) <= 1:
        return raster
    return _psd_layers_internal_order(raster)



def _psd_sort_by_sps_stack_position(layers: list[dict]) -> list[dict]:
    """Sort PSD layers to Smart Paint internal bottom->top order.

    Existing PSD layers may not have SPSi metadata, while newly authored layers
    do.  Metadata-free rows keep their observed internal order and metadata rows
    are inserted at their saved stack_position.  This preserves a Photoshop/group
    document after adding one Smart Paint layer instead of reversing all legacy
    rows just because one appended row carries SPS metadata.
    """
    try:
        meta_rows = []
        plain_rows = []
        for fallback, layer in enumerate(layers):
            meta = dict(layer.get('sps_layer_info', {}) or {})
            if 'stack_position' in meta:
                try:
                    pos = int(meta.get('stack_position', fallback) or 0)
                except Exception:
                    pos = int(fallback)
                meta_rows.append((pos, fallback, layer))
            else:
                plain_rows.append((fallback, layer))
        if not meta_rows:
            return layers
        if not plain_rows:
            return [item for _pos, _fallback, item in sorted(meta_rows, key=lambda x: (x[0], x[1]))]
        total = len(layers)
        slots = [None] * total
        overflow = []
        for pos, fallback, layer in sorted(meta_rows, key=lambda x: (x[0], x[1])):
            p = max(0, min(total - 1, int(pos)))
            if slots[p] is None:
                slots[p] = layer
            else:
                overflow.append((p, fallback, layer))
        plain_iter = iter([layer for _fallback, layer in plain_rows])
        out = []
        overflow_by_pos = {}
        for p, fallback, layer in overflow:
            overflow_by_pos.setdefault(int(p), []).append((fallback, layer))
        for idx in range(total):
            if slots[idx] is not None:
                out.append(slots[idx])
                for _fallback, extra in sorted(overflow_by_pos.pop(idx, []), key=lambda x: x[0]):
                    out.append(extra)
            else:
                try:
                    out.append(next(plain_iter))
                except StopIteration:
                    pass
        for rest in plain_iter:
            out.append(rest)
        for _pos, entries in sorted(overflow_by_pos.items(), key=lambda x: x[0]):
            for _fallback, extra in sorted(entries, key=lambda x: x[0]):
                out.append(extra)
        return out
    except Exception:
        return layers


def _psd_assign_derived_group_depths(records: list[dict]) -> None:
    """Assign folder depths for third-party PSDs without Smart Paint metadata.

    Photoshop PSD records are stored in panel order, but group folders are
    represented by a section divider after their child records; a closing marker
    appears before those children.  Smart Paint stores folder rows explicitly, so
    derive depths from those markers before the folder conversion step.
    """
    try:
        depth = 0
        for rec in records:
            section = int(rec.get('section_type', 0) or 0)
            if section == 3:
                depth += 1
                rec['_derived_group_depth'] = int(depth)
            elif section in {1, 2}:
                depth = max(0, depth - 1)
                rec['_derived_group_depth'] = int(depth)
            else:
                rec['_derived_group_depth'] = int(depth)
    except Exception:
        pass


def _psd_apply_section_group_depths(layers: list[dict]) -> None:
    """Prefer the PSD section-divider tree over stale Smart Paint depth tags."""
    try:
        if not any(int(layer.get('section_type', 0) or 0) in {1, 2} for layer in layers):
            return None
        for layer in layers:
            if '_derived_group_depth' in layer:
                layer['group_depth'] = max(0, int(layer.get('_derived_group_depth', 0) or 0))
    except Exception:
        pass
    return None


def _psd_topdown_converted_to_internal(layers: list[dict]) -> list[dict]:
    """Convert third-party top-down PSD panel rows to Smart Paint bottom-up rows.

    Groups are reconstructed as: folder row, then its children in internal
    bottom -> top order.  This avoids the classic reversed-folder bug where a
    PSD from Substance/Painter/Photoshop imports with the group marker under or
    above the wrong children.
    """
    try:
        if not layers:
            return layers
        def depth_of(layer):
            return int(layer.get('group_depth', 0) or 0)
        max_depth = 0
        try:
            max_depth = max(depth_of(layer) for layer in layers)
        except Exception:
            max_depth = 0
        pending: dict[int, list] = {i: [] for i in range(max_depth + 2)}
        for lyr in layers:
            d = max(0, depth_of(lyr))
            if bool(lyr.get('is_group', False)):
                children = list(pending.get(d + 1, []) or [])
                pending[d + 1] = []
                for deeper in range(d + 2, max_depth + 2):
                    pending[deeper] = []
                pending.setdefault(d, []).append(('group', lyr, children))
            else:
                pending.setdefault(d, []).append(('layer', lyr, []))
        def emit_internal(nodes):
            out = []
            for kind, layer, children in reversed(nodes):
                if kind == 'group':
                    out.append(layer)
                    out.extend(emit_internal(children))
                else:
                    out.append(layer)
            return out
        nodes = list(pending.get(0, []) or [])
        for deeper in range(1, max_depth + 2):
            # Keep malformed orphan child rows rather than dropping data.
            nodes.extend(list(pending.get(deeper, []) or []))
        out = emit_internal(nodes)
        return out or layers
    except Exception:
        return layers


def _psd_display_tree_to_internal_order(layers: list[dict]) -> list[dict]:
    """Convert Photoshop panel order to Smart Paint bottom -> top order.

    Smart Paint keeps folder rows before their children, but sibling scopes are
    stored bottom -> top for compositing and movement.  A plain list reversal
    breaks groups by placing children before the folder row, so parse the visible
    tree and reverse only siblings within each scope.
    """
    try:
        items = list(layers or [])
        if not items:
            return items

        def depth_at(i: int, fallback: int = 0) -> int:
            try:
                return max(0, int(items[int(i)].get('group_depth', fallback) or 0))
            except Exception:
                return int(fallback)

        def is_group(item: dict) -> bool:
            try:
                return bool(item.get('is_group', False)) or int(item.get('section_type', 0) or 0) in {1, 2}
            except Exception:
                return False

        def parse_scope(start: int, end: int, depth: int):
            nodes = []
            i = int(start)
            while i < int(end):
                d = depth_at(i, depth)
                if d < depth:
                    break
                if d > depth:
                    nodes.append(('leaf', items[i], []))
                    i += 1
                    continue
                item = items[i]
                if is_group(item):
                    child_start = i + 1
                    j = child_start
                    while j < int(end) and depth_at(j, depth) > d:
                        j += 1
                    nodes.append(('group', item, parse_scope(child_start, j, d + 1)))
                    i = j
                else:
                    nodes.append(('leaf', item, []))
                    i += 1
            return nodes

        def emit_internal(nodes):
            out = []
            for kind, item, children in reversed(list(nodes or [])):
                out.append(item)
                if kind == 'group':
                    out.extend(emit_internal(children))
            return out

        return emit_internal(parse_scope(0, len(items), 0)) or items
    except Exception:
        return layers


def _psd_record_indices_are_display_order(layers: list[dict]) -> bool:
    try:
        indices = []
        for layer in list(layers or []):
            if 'record_index' not in layer:
                continue
            try:
                indices.append(int(layer.get('record_index', 0)))
            except Exception:
                continue
        if len(indices) < 2:
            return False
        pairs = list(zip(indices, indices[1:]))
        descending = sum(1 for a, b in pairs if int(a) > int(b))
        ascending = sum(1 for a, b in pairs if int(a) < int(b))
        return bool(descending > ascending)
    except Exception:
        return False


def _psd_normalize_reader_layers_to_internal(layers: list[dict]) -> list[dict]:
    try:
        items = list(layers or [])
        if not items:
            return items
        if _psd_record_indices_are_display_order(items):
            return _psd_display_tree_to_internal_order(items)
        return items
    except Exception:
        return layers



def read_layered_psd_lazy(filepath: str | Path, *, decode_merged: bool = True, metadata_only: bool = False) -> dict:
    """Parse PSD/PSB layer records without expanding every layer to full RGBA.

    read_layered_psd() returns one full-document float32 RGBA array per layer.
    For 4K PSDs that can allocate gigabytes and make Blender appear frozen.
    This lightweight reader keeps raw channel payloads in each record and lets
    the async importer decode one layer at a time.
    """
    path = Path(filepath)
    data_bytes = path.read_bytes()
    data = memoryview(data_bytes)
    _psd_validate_document_structure(data, path, require_layers=False)
    if len(data) < 26 or bytes(data[0:4]) != b'8BPS':
        raise ValueError('Not a Photoshop PSD/PSB file.')
    version, offset = _psd_u16(data, 4)
    if version not in {1, 2}:
        raise ValueError('Unsupported PSD/PSB version.')
    psb = version == 2
    offset = 12
    channels, offset = _psd_u16(data, offset)
    height, offset = _psd_u32(data, offset)
    width, offset = _psd_u32(data, offset)
    depth, offset = _psd_u16(data, offset)
    color_mode, offset = _psd_u16(data, offset)
    if int(width) <= 0 or int(height) <= 0:
        raise ValueError('PSD document has no pixel area.')
    if int(depth) not in {8, 16, 32}:
        raise ValueError('Only 8/16/32-bit PSD layer channels are supported.')
    if int(color_mode) not in {1, 3, 4}:
        raise ValueError('Only grayscale, RGB and basic CMYK PSD layers are supported.')
    color_len, offset = _psd_u32(data, offset)
    offset += int(color_len)
    resources_len, offset = _psd_u32(data, offset)
    offset += int(resources_len)
    layer_mask_len, offset = _psd_len(data, offset, psb=psb)
    if layer_mask_len <= 0:
        return {'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode), 'layers': [], 'psb': bool(psb)}
    layer_mask_end = min(len(data), offset + int(layer_mask_len))
    layer_info_len, offset = _psd_len(data, offset, psb=psb)
    if layer_info_len <= 0:
        return {'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode), 'layers': [], 'psb': bool(psb)}
    layer_info_end = min(layer_mask_end, offset + int(layer_info_len))
    raw_count, offset = _psd_i16(data, offset)
    count = abs(int(raw_count))
    records = []
    channel_len_size = 8 if psb else 4
    for index in range(count):
        top, offset = _psd_i32(data, offset)
        left, offset = _psd_i32(data, offset)
        bottom, offset = _psd_i32(data, offset)
        right, offset = _psd_i32(data, offset)
        channel_count, offset = _psd_u16(data, offset)
        channel_info = []
        for _ in range(int(channel_count)):
            channel_id, offset = _psd_i16(data, offset)
            if channel_len_size == 8:
                channel_len, offset = _psd_len(data, offset, psb=True)
            else:
                channel_len, offset = _psd_u32(data, offset)
            channel_info.append((int(channel_id), int(channel_len)))
        blend_sig, offset = _psd_bytes(data, offset, 4)
        blend_key, offset = _psd_bytes(data, offset, 4)
        opacity = int(data[offset]) if offset < len(data) else 255; offset += 1
        clipping = int(data[offset]) if offset < len(data) else 0; offset += 1
        flags = int(data[offset]) if offset < len(data) else 0; offset += 1
        offset += 1
        extra_len, offset = _psd_u32(data, offset)
        extra_start = offset
        extra_end = min(layer_info_end, offset + int(extra_len))
        extra = _psd_parse_layer_extra(data, extra_start, extra_end, psb=psb)
        offset = extra_end
        name = str(extra.get('unicode_name') or extra.get('name') or f'PSD Layer {index + 1}').strip()
        records.append({
            'record_index': index,
            'top': int(top), 'left': int(left), 'bottom': int(bottom), 'right': int(right),
            'channel_info': channel_info,
            'blend_sig': blend_sig,
            'blend_key': blend_key,
            'blend_mode': _psd_layer_blend_mode(blend_key, extra),
            'opacity': max(0.0, min(1.0, float(opacity) / 255.0)),
            'enabled': not bool(flags & 0x02),
            'flags': int(flags),
            'clipping': int(clipping),
            'name': name or f'PSD Layer {index + 1}',
            'section_type': int(extra.get('section_type', 0) or 0),
            'mask_rect': dict(extra.get('mask_rect', {}) or {}),
            'raw_mask_data': str(extra.get('raw_mask_data', '') or ''),
            'sps_layer_info': dict(extra.get('sps_layer_info', {}) or {}),
            'adjustment': dict(extra.get('adjustment', {}) or {}),
            'tag_payloads': dict(extra.get('tag_payloads', {}) or {}),
            'raw_adjustment_tag_payloads': dict(extra.get('raw_adjustment_tag_payloads', {}) or {}),
            'raw_layer_tag_payloads': dict(extra.get('raw_layer_tag_payloads', {}) or {}),
            'tags': list(extra.get('tags', []) or []),
            'channel_data': {},
        })
    _psd_assign_derived_group_depths(records)
    if bool(metadata_only):
        for record in records:
            record['channel_data'] = {}
            try:
                record['smart_paint_suite_metadata_only'] = True
            except Exception:
                pass
    else:
        for record in records:
            channel_data = {}
            for channel_id, channel_len in record.get('channel_info', []):
                raw, offset = _psd_bytes(data, offset, channel_len)
                channel_data[int(channel_id)] = raw
            record['channel_data'] = channel_data
    layers = []
    for r in records:
        section = int(r.get('section_type', 0) or 0)
        if section in {1, 2}:
            rec = dict(r)
            meta = dict(rec.get('sps_layer_info', {}) or {})
            rec['is_group'] = bool(meta.get('is_group', True))
            # Photoshop may save a folder as collapsed.  Smart Paint opens
            # third-party PSDs expanded so the imported layer/group structure is
            # immediately visible and editable.  Preserve an explicit Smart Paint
            # metadata value when it exists.
            rec['group_expanded'] = bool(meta.get('group_expanded', True))
            rec['group_depth'] = int(meta.get('group_depth', rec.get('_derived_group_depth', 0)) or 0)
            rec['clip_to_below'] = bool(meta.get('clip_to_below', False))
            if str(meta.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                rec['adjustment'] = dict(meta)
                rec['is_adjustment'] = True
            if dict(rec.get('adjustment', {}) or {}) or dict(rec.get('raw_adjustment_tag_payloads', {}) or {}):
                rec['is_adjustment'] = True
            layers.append(rec)
        elif section == 3:
            continue
        else:
            rec = dict(r)
            meta = dict(rec.get('sps_layer_info', {}) or {})
            rec['is_group'] = bool(meta.get('is_group', False))
            rec['group_depth'] = int(meta.get('group_depth', rec.get('_derived_group_depth', 0)) or 0)
            rec['clip_to_below'] = bool(meta.get('clip_to_below', int(rec.get('clipping', 0) or 0) > 0))
            if str(meta.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                rec['adjustment'] = dict(meta)
                rec['is_adjustment'] = True
            if dict(rec.get('adjustment', {}) or {}) or dict(rec.get('raw_adjustment_tag_payloads', {}) or {}):
                rec['is_adjustment'] = True
            layers.append(rec)
    # This lazy path favors preserving the exact stack order observed in the
    # attached PSD and in Photoshop-saved documents whose merged preview cannot
    # be used for a full order score without expensive per-layer decoding.
    merged = None
    if decode_merged:
        try:
            merged = _psd_main_composite_to_rgba(data, layer_mask_end, doc_width=int(width), doc_height=int(height), channels=int(channels), depth=int(depth), color_mode=int(color_mode), psb=psb)
        except Exception:
            merged = None
    _has_stack_pos = any('stack_position' in dict(l.get('sps_layer_info', {}) or {}) for l in layers)
    _all_stack_pos = bool(layers) and all('stack_position' in dict(l.get('sps_layer_info', {}) or {}) for l in layers)
    _has_groups = any(bool(l.get('is_group', False)) for l in layers)
    if _has_groups:
        # Source-order saves preserve untouched SPSi bytes.  After nesting or
        # reparenting an existing row, its old group_depth tag can therefore be
        # stale even though the emitted PSD section dividers are correct.
        _psd_apply_section_group_depths(layers)
    if _all_stack_pos:
        layers = _psd_sort_by_sps_stack_position(layers)
    elif _has_groups:
        # A metadata-preserving splice can move raw PSD record blocks without
        # rewriting every SPSi tag.  In that case only the authored rows carry
        # stack_position, and those values can be stale or duplicated after a
        # reorder.  Partial positions must not override the PSD section-divider
        # tree; doing so can place children before their folder on self-output
        # reload.  The raw group boundaries remain the durable ordering source.
        layers = _psd_topdown_converted_to_internal(layers)
    elif _has_stack_pos:
        layers = _psd_sort_by_sps_stack_position(layers)
    layers = _psd_normalize_reader_layers_to_internal(layers)
    return {
        'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode),
        'layers': layers, 'raw_records': records, 'merged': merged, 'psb': bool(psb),
    }


def _psd_channel_region_row_u8(record: dict, channel_id: int, raw, width: int, height: int, row: int, depth: int, *, psb: bool = False):
    """Decode one PSD layer-channel scanline without expanding the whole plane."""
    try:
        np = _np_module()
        width = int(width); height = int(height); row = int(row); depth = int(depth)
        if np is None or width <= 0 or height <= 0 or row < 0 or row >= height:
            return None
        data = bytes(raw or b'')
        if len(data) < 2:
            return None
        if depth != 8:
            full = _psd_channel_float_array(data, width, height, depth, psb=psb)
            if full is None:
                return None
            return np.clip(np.floor(np.asarray(full[row], dtype=np.float32) * 255.0 + 0.5), 0, 255).astype(np.uint8, copy=False)
        compression = int(struct.unpack_from('>H', data, 0)[0])
        if compression == 0:
            start = 2 + row * width
            payload = data[start:start + width]
            if len(payload) != width:
                return None
            return np.frombuffer(payload, dtype=np.uint8)
        if compression == 1:
            cache = record.setdefault('_sps_region_channel_tables', {})
            key = (int(channel_id), len(data), width, height, bool(psb))
            table = cache.get(key)
            if table is None:
                count_size = 4 if bool(psb) else 2
                table_end = 2 + height * count_size
                if table_end > len(data):
                    return None
                fmt = '>I' if bool(psb) else '>H'
                counts = [int(struct.unpack_from(fmt, data, 2 + index * count_size)[0]) for index in range(height)]
                offsets = []
                position = int(table_end)
                for count in counts:
                    offsets.append(position)
                    position += int(count)
                if position > len(data):
                    return None
                table = (counts, offsets)
                cache[key] = table
            counts, offsets = table
            count = int(counts[row]); start = int(offsets[row])
            decoded = _psd_decode_packbits_row(data[start:start + count], width)
            if len(decoded) != width:
                return None
            return np.frombuffer(decoded, dtype=np.uint8)
        # ZIP channels are uncommon in Photoshop painting documents. Keep a
        # correct bounded fallback while RAW/RLE take the row-level fast path.
        full = _psd_channel_float_array(data, width, height, depth, psb=psb)
        if full is None:
            return None
        return np.clip(np.floor(np.asarray(full[row], dtype=np.float32) * 255.0 + 0.5), 0, 255).astype(np.uint8, copy=False)
    except Exception:
        return None


def decode_lazy_psd_layer_region_rgba(record: dict, *, doc_width: int, doc_height: int, depth: int, color_mode: int, start: int, count: int, psb: bool = False):
    """Decode a contiguous Blender Image.pixels region from one lazy PSD row.

    The result is bottom-to-top float32 RGBA and does not apply layer masks;
    Smart Paint's compositor applies the separately editable mask exactly once.
    """
    np = _np_module()
    if np is None or not isinstance(record, dict):
        return None
    try:
        doc_width = int(doc_width); doc_height = int(doc_height)
        total = doc_width * doc_height
        start = max(0, int(start)); count = max(0, min(int(count), total - start))
        if doc_width <= 0 or doc_height <= 0 or count <= 0:
            return None
        left = int(record.get('left', 0)); top = int(record.get('top', 0))
        right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
        box_width = max(0, right - left); box_height = max(0, bottom - top)
        if box_width <= 0 or box_height <= 0:
            return np.zeros((count, 4), dtype=np.float32)
        raw_channels = {}
        for key, value in dict(record.get('channel_data', {}) or {}).items():
            try:
                raw_channels[int(key)] = value
            except Exception:
                continue
        if not raw_channels:
            return None
        has_colour = any(channel_id in raw_channels for channel_id in (0, 1, 2))
        output = np.zeros((count, 4), dtype=np.float32)
        position = 0
        while position < count:
            absolute = start + position
            blender_y, x = divmod(absolute, doc_width)
            span = min(count - position, doc_width - x)
            psd_y = doc_height - 1 - blender_y
            inside_left = max(x, left)
            inside_right = min(x + span, right)
            if top <= psd_y < bottom and inside_right > inside_left:
                local_y = psd_y - top
                local_left = inside_left - left
                local_right = inside_right - left
                dst_left = position + inside_left - x
                dst_right = dst_left + inside_right - inside_left

                def values(channel_id: int, default: int):
                    raw = raw_channels.get(int(channel_id))
                    if raw is None:
                        return np.full((local_right - local_left,), int(default), dtype=np.uint8)
                    row_values = _psd_channel_region_row_u8(
                        record, int(channel_id), raw, box_width, box_height,
                        local_y, int(depth), psb=bool(psb),
                    )
                    if row_values is None:
                        return None
                    return np.asarray(row_values, dtype=np.uint8)[local_left:local_right]

                if int(color_mode) == 1:
                    gray = values(0, 0)
                    if gray is None:
                        return None
                    red = green = blue = gray
                elif int(color_mode) == 4:
                    cyan = values(0, 0); magenta = values(1, 0)
                    yellow = values(2, 0); black = values(3, 0)
                    if any(value is None for value in (cyan, magenta, yellow, black)):
                        return None
                    red = 255 - np.minimum(255, cyan.astype(np.uint16) + black.astype(np.uint16)).astype(np.uint8)
                    green = 255 - np.minimum(255, magenta.astype(np.uint16) + black.astype(np.uint16)).astype(np.uint8)
                    blue = 255 - np.minimum(255, yellow.astype(np.uint16) + black.astype(np.uint16)).astype(np.uint8)
                else:
                    red = values(0, 0)
                    if red is None:
                        return None
                    green = values(1, 0) if 1 in raw_channels else red
                    blue = values(2, 0) if 2 in raw_channels else red
                    if green is None or blue is None:
                        return None
                alpha = values(-1, 255)
                if alpha is None:
                    return None
                if not has_colour:
                    alpha = np.zeros_like(alpha, dtype=np.uint8)
                output[dst_left:dst_right, 0] = red.astype(np.float32) / 255.0
                output[dst_left:dst_right, 1] = green.astype(np.float32) / 255.0
                output[dst_left:dst_right, 2] = blue.astype(np.float32) / 255.0
                output[dst_left:dst_right, 3] = alpha.astype(np.float32) / 255.0
            position += span
        return np.ascontiguousarray(output, dtype=np.float32)
    except Exception:
        return None

def decode_lazy_psd_layer_rgba(record: dict, *, doc_width: int, doc_height: int, depth: int, color_mode: int, psb: bool = False, apply_layer_mask: bool = False):
    """Decode one lazy PSD layer record to Blender Image.pixels float32 RGBA.

    Editable Smart Paint layer import must preserve the raw layer alpha channel.
    PSD user/vector masks are imported separately as Smart Paint mask images;
    destructively multiplying them into the layer alpha during lazy decoding can
    make soft alpha look binary or double-applied after reload.  Preview builders
    can explicitly request apply_layer_mask=True when they need a flattened view.
    """
    return _psd_layer_to_rgba(record, doc_width=doc_width, doc_height=doc_height, depth=depth, color_mode=color_mode, psb=psb, apply_layer_mask=apply_layer_mask)




def psd_preview_array_looks_black_or_empty(arr, *, sample_limit: int = 512) -> bool:
    np = _np_module()
    if np is None or arr is None:
        return True
    try:
        a = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
        total = int(a.shape[0])
        if total <= 0:
            return True
        samples = max(8, min(int(sample_limit or 512), total))
        if total <= samples:
            s = a
        else:
            idx = np.linspace(0, total - 1, samples).astype(np.int64)
            s = a[idx]
        alpha_max = float(np.max(s[:, 3]))
        if alpha_max <= (1.0 / 255.0):
            return True
        rgb_max = float(np.max(s[:, :3]))
        rgb_mean = float(np.mean(s[:, :3]))
        return bool(rgb_max <= (2.0 / 255.0) and rgb_mean <= (1.0 / 255.0))
    except Exception:
        return False


def _sps_sparse_patch_preview_record_for_image(image, width: int, height: int, layer=None):
    """Return a lazy-preview record for an authoritative sparse brush patch.

    Newly authored layers on large PSDs may be represented by a tiny proxy Image
    plus a compressed RGBA patch.  Visibility toggles must composite that patch
    directly instead of falling back to a full internal-document rebuild.
    """
    np = _np_module()
    if np is None or image is None:
        return None
    try:
        width = int(width or 0)
        height = int(height or 0)
        if width <= 0:
            try: width = int(image.get('smart_paint_suite_lazy_width', 0) or 0)
            except Exception: width = 0
        if height <= 0:
            try: height = int(image.get('smart_paint_suite_lazy_height', 0) or 0)
            except Exception: height = 0
        if width <= 0 or height <= 0:
            return None
        patch_box = image.get('smart_paint_suite_sparse_rgba_patch_bbox', None)
        patch_b64 = str(image.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '')
        if patch_box is None or not patch_b64:
            return None
        try:
            parts = [int(float(v)) for v in list(patch_box)[:4]]
        except Exception:
            if isinstance(patch_box, str):
                parts = [int(float(v.strip())) for v in patch_box.replace(';', ',').split(',') if v.strip()][:4]
            else:
                return None
        if len(parts) < 4:
            return None
        x0, y0, x1, y1 = parts[:4]
        x0 = max(0, min(width, int(x0))); x1 = max(0, min(width, int(x1)))
        y0 = max(0, min(height, int(y0))); y1 = max(0, min(height, int(y1)))
        if x1 <= x0 or y1 <= y0:
            return None
        bw = int(x1 - x0); bh = int(y1 - y0)
        import base64 as _sps_b64, zlib as _sps_zlib
        raw = _sps_zlib.decompress(_sps_b64.b64decode(patch_b64.encode('ascii')))
        patch = np.frombuffer(raw, dtype=np.float32).reshape((bh, bw, 4)).copy()
        patch = np.clip(patch, 0.0, 1.0).astype(np.float32, copy=False)
        if not bool(np.any(patch[:, :, 3] > (1.0 / 4096.0))):
            return None
        # Sparse patch bboxes use Blender bottom-left coordinates.  Preview
        # records use PSD top-down coordinates, so flip the local patch rows.
        local = np.ascontiguousarray(patch[::-1, :, :], dtype=np.float32)
        try:
            opacity = max(0.0, min(1.0, float(getattr(layer, 'opacity', 1.0) or 0.0))) if layer is not None else 1.0
        except Exception:
            opacity = 1.0
        try:
            mode = str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper() if layer is not None else 'MIX'
        except Exception:
            mode = 'MIX'
        return {
            '_sps_sparse_patch_preview': True,
            '_sps_sparse_patch_rgba': local,
            'left': int(x0),
            'right': int(x1),
            'top': int(height) - int(y1),
            'bottom': int(height) - int(y0),
            'opacity': float(opacity),
            'blend_mode': mode,
            'enabled': True,
            'name': str(getattr(layer, 'name', getattr(image, 'name', 'Layer')) or getattr(image, 'name', 'Layer')),
        }
    except Exception:
        return None


def build_lazy_psd_color_preview(doc: dict, *, max_layers: int = 96):
    """Build a layer-faithful flattened preview from lazy PSD payloads."""
    np = _np_module()
    if np is None or not isinstance(doc, dict):
        return None
    try:
        width = int(doc.get('width', 0) or 0)
        height = int(doc.get('height', 0) or 0)
        depth = int(doc.get('depth', 8) or 8)
        color_mode = int(doc.get('color_mode', 3) or 3)
        psb = bool(doc.get('psb'))
        layers = list(doc.get('layers', []) or [])
        if width <= 0 or height <= 0 or not layers or len(layers) > int(max_layers or 96):
            return None
        normal_modes = {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH'}
        try:
            if all(str(record.get('blend_mode', 'MIX') or 'MIX').upper() in normal_modes for record in layers):
                acc_a = np.zeros((height, width), dtype=np.float32)
                acc_rgb = np.zeros((height, width, 3), dtype=np.float32)
                any_layer = False
                alpha_eps = 1.0 / 4096.0
                for record in reversed(layers):
                    try:
                        section = int(record.get('section_type', 0) or 0)
                    except Exception:
                        section = 0
                    if section in {1, 2, 3} or bool(record.get('is_group', False)) or bool(record.get('is_adjustment', False)):
                        continue
                    if not bool(record.get('enabled', True)):
                        continue
                    try:
                        left = int(record.get('left', 0)); top = int(record.get('top', 0))
                        right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
                    except Exception:
                        continue
                    dst_x0 = max(0, left); dst_y0 = max(0, top)
                    dst_x1 = min(width, right); dst_y1 = min(height, bottom)
                    if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
                        continue
                    if not bool(np.any(acc_a[dst_y0:dst_y1, dst_x0:dst_x1] < (1.0 - alpha_eps))):
                        continue
                    if bool(record.get('_sps_sparse_patch_preview', False)) and record.get('_sps_sparse_patch_rgba') is not None:
                        try:
                            local = np.asarray(record.get('_sps_sparse_patch_rgba'), dtype=np.float32).reshape((max(0, bottom - top), max(0, right - left), 4))
                        except Exception:
                            local = None
                    elif record.get('_sps_full_rgba_preview') is not None:
                        try:
                            local = np.asarray(record.get('_sps_full_rgba_preview'), dtype=np.float32).reshape((max(0, bottom - top), max(0, right - left), 4))
                        except Exception:
                            local = None
                    else:
                        local = _psd_record_local_rgba(record, depth=depth, color_mode=color_mode, psb=psb, apply_layer_mask=True, repair_rgb_fringes=False)
                    if local is None:
                        continue
                    try:
                        src_x0 = dst_x0 - left; src_y0 = dst_y0 - top
                        src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
                        src = local[src_y0:src_y1, src_x0:src_x1, :]
                        if src.size <= 0:
                            continue
                        try:
                            opacity = max(0.0, min(1.0, float(record.get('opacity', 1.0) or 0.0)))
                        except Exception:
                            opacity = 1.0
                        src_a = np.clip(src[:, :, 3] * opacity, 0.0, 1.0).astype(np.float32, copy=False)
                        need = np.clip(1.0 - acc_a[dst_y0:dst_y1, dst_x0:dst_x1], 0.0, 1.0)
                        weight = src_a * need
                        if not bool(np.any(weight > alpha_eps)):
                            continue
                        acc_rgb[dst_y0:dst_y1, dst_x0:dst_x1, :] += np.clip(src[:, :, :3], 0.0, 1.0) * weight[:, :, None]
                        acc_a[dst_y0:dst_y1, dst_x0:dst_x1] = np.clip(acc_a[dst_y0:dst_y1, dst_x0:dst_x1] + weight, 0.0, 1.0)
                        any_layer = True
                    finally:
                        try:
                            del local
                        except Exception:
                            pass
                if any_layer:
                    out_fast = np.zeros((height, width, 4), dtype=np.float32)
                    out_fast[:, :, 3] = acc_a
                    mask = acc_a > alpha_eps
                    out_fast[:, :, :3] = 1.0
                    out_fast[:, :, :3][mask] = np.clip(acc_rgb[mask] / np.maximum(acc_a[mask, None], 1.0e-8), 0.0, 1.0)
                    out_fast = np.ascontiguousarray(out_fast[::-1, :, :].reshape((width * height, 4)), dtype=np.float32)
                    if not psd_preview_array_looks_black_or_empty(out_fast):
                        return out_fast
        except Exception:
            pass
        out = np.zeros((height, width, 4), dtype=np.float32)
        out[:, :, :3] = 1.0
        out[:, :, 3] = 0.0
        for record in layers:
            try:
                section = int(record.get('section_type', 0) or 0)
            except Exception:
                section = 0
            if section in {1, 2, 3} or bool(record.get('is_group', False)) or bool(record.get('is_adjustment', False)):
                continue
            if not bool(record.get('enabled', True)):
                continue
            try:
                left = int(record.get('left', 0)); top = int(record.get('top', 0))
                right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
            except Exception:
                continue
            if bool(record.get('_sps_sparse_patch_preview', False)) and record.get('_sps_sparse_patch_rgba') is not None:
                try:
                    local = np.asarray(record.get('_sps_sparse_patch_rgba'), dtype=np.float32).reshape((max(0, bottom - top), max(0, right - left), 4))
                except Exception:
                    local = None
            elif record.get('_sps_full_rgba_preview') is not None:
                try:
                    local = np.asarray(record.get('_sps_full_rgba_preview'), dtype=np.float32).reshape((max(0, bottom - top), max(0, right - left), 4))
                except Exception:
                    local = None
            else:
                local = _psd_record_local_rgba(record, depth=depth, color_mode=color_mode, psb=psb, apply_layer_mask=True, repair_rgb_fringes=False)
            if local is None:
                continue
            try:
                dst_x0 = max(0, left); dst_y0 = max(0, top)
                dst_x1 = min(width, right); dst_y1 = min(height, bottom)
                if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
                    continue
                src_x0 = dst_x0 - left; src_y0 = dst_y0 - top
                src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
                src = local[src_y0:src_y1, src_x0:src_x1, :]
                if src.size <= 0:
                    continue
                try:
                    opacity = max(0.0, min(1.0, float(record.get('opacity', 1.0) or 0.0)))
                except Exception:
                    opacity = 1.0
                mode = str(record.get('blend_mode', 'MIX') or 'MIX').upper()
                region_h = int(dst_y1 - dst_y0)
                # Full 4K layers can allocate several hundred MB per temporary
                # when flattened at once.  Composite in row chunks so Blender's
                # Python runtime does not swap or appear frozen during layer
                # visibility updates.
                chunk_rows = 512 if int(dst_x1 - dst_x0) >= 2048 else 768
                any_alpha = False
                for cy0 in range(0, region_h, chunk_rows):
                    cy1 = min(region_h, cy0 + chunk_rows)
                    src_chunk = src[cy0:cy1, :, :]
                    src_a_2d = np.clip(src_chunk[:, :, 3] * opacity, 0.0, 1.0).astype(np.float32, copy=False)
                    if not bool(np.any(src_a_2d > (1.0 / 4096.0))):
                        continue
                    any_alpha = True
                    dst_chunk = out[dst_y0 + cy0:dst_y0 + cy1, dst_x0:dst_x1, :]
                    dst_a_2d = np.clip(dst_chunk[:, :, 3], 0.0, 1.0).astype(np.float32, copy=False)
                    src_rgb_3d = src_chunk[:, :, :3]
                    dst_rgb_3d = np.clip(dst_chunk[:, :, :3], 0.0, 1.0)
                    if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
                        blend_rgb_3d = src_rgb_3d
                    else:
                        try:
                            _sa_flat = src_a_2d.reshape((-1,))
                            blend_rgb_3d = _blend_rgb(
                                dst_rgb_3d.reshape((-1, 3)),
                                src_rgb_3d.reshape((-1, 3)),
                                np.ones_like(_sa_flat, dtype=np.float32),
                                mode,
                            ).reshape(src_rgb_3d.shape)
                        except Exception:
                            blend_rgb_3d = src_rgb_3d
                    dst_chunk[:, :, :3], new_a_2d = _composite_blended_source_over(
                        dst_rgb_3d, dst_a_2d, src_rgb_3d, src_a_2d, blend_rgb_3d,
                    )
                    dst_chunk[:, :, 3] = new_a_2d
                if not any_alpha:
                    continue
            finally:
                try:
                    del local
                except Exception:
                    pass
                try:
                    del src
                except Exception:
                    pass
        try:
            # Full 4K visibility previews must remain an interactive display path.
            # Export/private-layer code performs alpha-fringe repair for saved data;
            # doing the neighbourhood repair on every 4096px toggle can block the
            # UI and is not required to preserve the layer source-of-truth.
            if int(width) * int(height) <= 2048 * 2048:
                out = _sps_repair_straight_alpha_rgb_fringes(out, width=width, height=height)
        except Exception:
            pass
        out = np.ascontiguousarray(out[::-1, :, :].reshape((width * height, 4)), dtype=np.float32)
        if psd_preview_array_looks_black_or_empty(out):
            return None
        return out
    except Exception:
        return None



def lazy_psd_material_stack_signature(material, channel: str = 'BASE_COLOR'):
    """Return a compact live signature for lazy PSD layer visibility state."""
    try:
        import json as _json
        if material is None:
            return ''
        channel = str(channel or 'BASE_COLOR').upper()
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return ''
        attr = layer_channel_image_attr(channel)
        enabled_attr = layer_channel_enabled_attr(channel)
        rows = []
        for layer in list(getattr(settings, 'layers', []) or []):
            try:
                _img_name = str(getattr(layer, attr, '') or '')
                _img_rev = 0
                _img_dirty = 0
                _img_pending = False
                _img_author_rev = 0
                _img_sparse_stamp = ''
                try:
                    _img = bpy.data.images.get(_img_name) if _img_name else None
                    if _img is not None:
                        try:
                            _img_rev = int(_img.get(_IMAGE_PIXEL_REV_PROP, 0) or 0)
                        except Exception:
                            _img_rev = 0
                        try:
                            _img_author_rev = int(_img.get('smart_paint_suite_layer_authoritative_revision', 0) or 0)
                        except Exception:
                            _img_author_rev = 0
                        try:
                            _img_dirty = 1 if bool(getattr(_img, 'is_dirty', False)) else 0
                        except Exception:
                            _img_dirty = 0
                        try:
                            _img_pending = bool(_img.get('smart_paint_suite_dirty_from_master', False) or _img.get('smart_paint_suite_alpha_authoritative', False) or _img.get('smart_paint_suite_known_brush_color_commit', False))
                        except Exception:
                            _img_pending = False
                        try:
                            _box = str(_img.get('smart_paint_suite_sparse_rgba_patch_bbox', '') or '')
                            _b64 = str(_img.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '')
                            if _box or _b64:
                                _img_sparse_stamp = str(zlib.crc32((_box + '|' + _b64).encode('utf-8', 'ignore')) & 0xffffffff)
                        except Exception:
                            _img_sparse_stamp = ''
                except Exception:
                    _img_rev = 0
                    _img_dirty = 0
                    _img_pending = False
                    _img_author_rev = 0
                    _img_sparse_stamp = ''
                rows.append([
                    str(getattr(layer, 'layer_id', '') or getattr(layer, 'name', '') or ''),
                    _img_name,
                    bool(getattr(layer, 'enabled', True)),
                    bool(getattr(layer, enabled_attr, False)),
                    bool(getattr(layer, 'is_group', False)),
                    str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper(),
                    float(getattr(layer, 'opacity', 1.0) or 0.0),
                    str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper(),
                    int(_img_rev),
                    int(_img_dirty),
                    bool(_img_pending),
                    int(_img_author_rev),
                    str(_img_sparse_stamp),
                ])
            except Exception:
                rows.append(['', '', True, False, False, 'PAINT', 1.0, 'MIX', 0, 0, False, 0, ''])
        return _json.dumps(rows, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        return ''



def _lazy_psd_master_cache_key(material, channel: str, signature: str):
    try:
        return (str(getattr(material, 'name', '') or ''), str(channel or 'BASE_COLOR').upper(), str(signature or ''))
    except Exception:
        return ('', str(channel or 'BASE_COLOR').upper(), str(signature or ''))






def clear_all_runtime_caches(reason: str = '') -> int:
    """Release every Suite-owned data cache; retains no Blender RNA/Image."""
    clear_image_array_read_scope()
    return _sps_quota.clear_all_memory(reason=str(reason or 'lifecycle'))

def clear_lazy_psd_decode_caches() -> None:
    """Release temporary per-layer decode/read arrays; keep public preview cache."""
    try:
        _PSD_RECORD_LOCAL_RGBA_CACHE.clear()
    except Exception:
        pass
    try:
        clear_image_array_read_scope()
    except Exception:
        pass

def clear_lazy_psd_runtime_caches(material=None, channel: str | None = None) -> None:
    """Clear temporary PSD decode/composite caches without touching layer pixels."""
    try:
        _PSD_RECORD_LOCAL_RGBA_CACHE.clear()
    except Exception:
        pass
    try:
        clear_image_array_read_scope()
    except Exception:
        pass
    try:
        if material is None:
            # These are runtime-only mirrors of PSD source records.  Layer images
            # keep source_file + record_index, so the payload can be reconstructed
            # on demand; clearing them here prevents an old stack from keeping a
            # later import/save in the same Blender session tied to stale records.
            _LAZY_PSD_LAYER_RECORDS.clear()
            _LAZY_PSD_SOURCE_DOCS.clear()
            _LAZY_PSD_MASTER_PREVIEW_CACHE.clear()
            _SPS_SOURCE_MERGED_BASE_CACHE.clear()
        else:
            invalidate_lazy_psd_material_preview_cache(material, channel or 'BASE_COLOR')
    except Exception:
        pass

def invalidate_lazy_psd_material_preview_cache(material=None, channel: str = 'BASE_COLOR') -> None:
    """Drop lazy PSD master previews that can contain stale layer pixels.

    Visibility toggles are metadata edits, but the public master can also contain
    just-committed brush pixels.  Cached/incremental lazy previews are valid only
    for untouched PSD records; after a paint boundary they must be rebuilt from
    the current live image records.
    """
    try:
        ch = str(channel or 'BASE_COLOR').upper()
        mat_name = str(getattr(material, 'name', '') or '') if material is not None else ''
        for _key in list(_LAZY_PSD_MASTER_PREVIEW_CACHE.keys()):
            try:
                if material is None or (str(_key[0]) == mat_name and str(_key[1]).upper() == ch):
                    _LAZY_PSD_MASTER_PREVIEW_CACHE.pop(_key, None)
            except Exception:
                pass
        for _key in list(_SPS_SOURCE_MERGED_BASE_CACHE.keys()):
            try:
                if material is None or (str(_key[0]) == mat_name and str(_key[1]).upper() == ch):
                    _SPS_SOURCE_MERGED_BASE_CACHE.pop(_key, None)
            except Exception:
                pass
    except Exception:
        pass



def smart_paint_layer_image_has_authoritative_user_pixels(image) -> bool:
    """True when a Blender Image, not the original PSD lazy record, owns layer pixels.

    The public master image is only a flattened display target.  Visibility
    toggles and saves may use cached lazy previews only while every layer still
    comes from immutable PSD records.  Once a layer has a sparse brush patch,
    materialized user pixels, a dirty Blender buffer, or an explicit paint commit,
    flattened previews derived from the public master are no longer authoritative.
    """
    try:
        if image is None:
            return False
        try:
            if not bool(image.get('smart_paint_suite_layer_image', False)):
                return False
        except Exception:
            return False
        try:
            if bool(image.get('smart_paint_suite_sparse_rgba_patch_b64', False)):
                return True
        except Exception:
            pass
        try:
            source_file = str(image.get('smart_paint_suite_source_file', '') or image.get('smart_paint_suite_layered_source_path', '') or '')
        except Exception:
            source_file = ''
        # A Photoshop-authored lazy row stops being source-record authoritative as
        # soon as Blender/Smart Paint writes real pixels into its private image.
        # Do not return early merely because source_file is present; the explicit
        # paint markers below are the authority boundary.
        for _key in (
            'smart_paint_suite_dirty_from_master',
            'smart_paint_suite_known_brush_color_commit',
            'smart_paint_suite_fast_visible_write',
            'smart_paint_suite_exact_top_normal_commit',
            'smart_paint_suite_exact_fallback_commit',
            'smart_paint_suite_save_exact_master_delta',
            'smart_paint_suite_user_edited',
            'smart_paint_suite_direct_layer_dirty',
            'smart_paint_suite_bodypaint_direct_authoritative',
            'smart_paint_suite_painted_since_last_projection',
        ):
            try:
                if bool(image.get(_key, False)):
                    return True
            except Exception:
                pass
        try:
            if (not source_file) and bool(image.get('smart_paint_suite_materialized_for_paint', False)):
                return True
        except Exception:
            pass
        if not source_file:
            for _key in (
                'smart_paint_suite_painted_since_last_projection',
                'smart_paint_suite_direct_layer_dirty',
                'smart_paint_suite_bodypaint_direct_authoritative',
            ):
                try:
                    if bool(image.get(_key, False)):
                        return True
                except Exception:
                    pass
        try:
            if (
                (not source_file)
                and bool(image.get('smart_paint_suite_alpha_authoritative', False))
                and not bool(image.get('smart_paint_suite_lazy_psd_pending', False))
            ):
                return True
        except Exception:
            pass
        try:
            if (not source_file) and bool(getattr(image, 'is_dirty', False)):
                return True
        except Exception:
            pass
        try:
            # A full-size non-lazy private image can contain live Blender paint even
            # when no Smart Paint flag was updated.  Treat it as layer-owned data.
            if (
                (not source_file)
                and not bool(image.get('smart_paint_suite_lazy_psd_pending', False))
                and not bool(image.get('smart_paint_suite_lazy_blank_layer', False))
            ):
                w, h = _image_size(image)
                if int(w) > 1 and int(h) > 1:
                    return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def material_has_authoritative_user_layer_pixels(material, channel: str = 'BASE_COLOR') -> bool:
    """Return True if the material/channel contains any layer-owned live pixels.

    Cached/incremental lazy previews are allowed only for untouched PSD-lazy
    stacks.  If this returns True, the compositor must rebuild from each layer's
    current source-of-truth instead of starting from the public master image.
    """
    try:
        if material is None:
            return False
        channel = str(channel or 'BASE_COLOR').upper()
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return False
        attr = layer_channel_image_attr(channel)
        for layer in list(getattr(settings, 'layers', []) or []):
            try:
                if bool(getattr(layer, 'is_group', False)) or str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT':
                    continue
                name = str(getattr(layer, attr, '') or '')
                img = bpy.data.images.get(name) if name else None
                if smart_paint_layer_image_has_authoritative_user_pixels(img):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def reset_master_paint_session_after_stack_metadata_edit(material, channel: str = 'BASE_COLOR') -> None:
    """Make layer visibility edits a hard paint-session boundary.

    Old exact/lazy public-master sessions captured before the visibility edit must
    not be reused after the projection has changed.  Otherwise a later toggle can
    replay the previous projection difference as paint, restoring old strokes or
    changing colour/alpha.  Use a lazy metadata stamp instead of a full 4K copy.
    """
    try:
        channel = _safe_channel(channel)
        key = _session_key(material, channel)
        _MASTER_PAINT_SESSIONS.pop(key, None)
        master = get_master_texture_image(material, channel, create=False)
        if master is not None:
            _MASTER_PAINT_SESSIONS[key] = {
                'baseline': None,
                'layer_id': _active_layer_id(material),
                'stamp': _image_sample_stamp(master, 96),
                'sample_stamp': _image_sample_stamp(master, 96),
                'lazy': True,
                'paint_op_token': _current_paint_operator_token(),
                'stack_signature': _master_session_stack_signature(material, channel),
                'layers_snapshot': _master_paint_layers_snapshot(material, channel),
                'brush_rgb': _rgb_tuple_or_none(_active_texture_paint_brush_rgb(getattr(bpy, 'context', None))),
            }
        try:
            _precommit_key = 'sps_visibility_precommit_pixels_' + channel
            if material is not None and bool(material.get(_precommit_key, False)):
                invalidate_lazy_psd_material_preview_cache(material, channel)
                try:
                    del material[_precommit_key]
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass


def _cache_lazy_psd_master_preview(material, channel: str, signature: str, width: int, height: int, arr) -> None:
    np = _np_module()
    if np is None or material is None or not signature or arr is None:
        return
    try:
        width = int(width); height = int(height)
        if width <= 0 or height <= 0 or width * height > 4096 * 4096:
            return
        key = _lazy_psd_master_cache_key(material, channel, signature)
        _LAZY_PSD_MASTER_PREVIEW_CACHE[key] = (width, height, np.ascontiguousarray(arr.reshape((width * height, 4)), dtype=np.float32))
        try:
            _limit = 4 if int(width) * int(height) <= 2048 * 2048 else 3
        except Exception:
            _limit = 3
        while len(_LAZY_PSD_MASTER_PREVIEW_CACHE) > int(_limit):
            try:
                _LAZY_PSD_MASTER_PREVIEW_CACHE.pop(next(iter(_LAZY_PSD_MASTER_PREVIEW_CACHE)))
            except Exception:
                break
    except Exception:
        pass




def fast_sparse_top_visibility_refresh(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    """Fast ON refresh for a top authoritative sparse paint layer.

    The current public master after an OFF toggle is the lower-stack projection.
    When the same top sparse layer is turned back ON, source-over the layer's
    authoritative patch onto that current master instead of reloading every PSD
    layer or using a generic inverse solver.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    try:
        import base64 as _sps_b64, zlib as _sps_zlib
        ch = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        layers = list(getattr(settings, 'layers', ()) or []) if settings is not None else []
        if not layers:
            return False
        top = layers[-1]
        enabled_attr = layer_channel_enabled_attr(ch)
        top_visible = bool(getattr(top, 'enabled', True)) and bool(getattr(top, enabled_attr, True))
        if bool(getattr(top, 'is_group', False)) or bool(getattr(top, 'background', False)):
            return False
        attr = layer_channel_image_attr(ch)
        img_name = str(getattr(top, attr, '') or '')
        img = bpy.data.images.get(img_name) if img_name else None
        if img is None:
            return False
        patch_b64 = str(img.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '')
        box = _sps_parse_bbox4(img.get('smart_paint_suite_sparse_rgba_patch_bbox', None))
        if not patch_b64 or box is None:
            return False
        if not bool(img.get('smart_paint_suite_authoritative_sparse_rgba_patch', False) or img.get('smart_paint_suite_exact_top_sparse_commit', False)):
            return False
        master = get_master_texture_image(material, ch, create=False)
        if master is None:
            return False
        w, h = _image_size(master)
        w = int(w); h = int(h)
        if w <= 0 or h <= 0:
            return False
        if not bool(top_visible):
            # Fast OFF path for a newly-authored top sparse layer.  The baseline
            # captured when the layer became the Blender paint target is the
            # exact lower-stack projection; restoring it avoids a full PSD
            # recompose and prevents the just-painted stroke from being erased
            # or reinterpreted as lower-layer artwork.
            try:
                base_arr = None
                try:
                    base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_session_key(material, ch))
                    if isinstance(base_entry, dict):
                        cached = base_entry.get('baseline', None)
                        if cached is not None and getattr(cached, 'shape', None) is not None and int(cached.shape[0]) == int(w) * int(h):
                            base_arr = np.asarray(cached, dtype=np.float32).reshape((int(h), int(w), 4)).copy()
                except Exception:
                    base_arr = None
                if base_arr is None:
                    base_name = str(material.get('sps_save_baseline_image_' + ch, '') or '') if hasattr(material, 'get') else ''
                    base_img = bpy.data.images.get(base_name) if base_name else None
                    if base_img is None:
                        return False
                    bw0, bh0 = _image_size(base_img)
                    if int(bw0) != int(w) or int(bh0) != int(h):
                        return False
                    base_flat = np.empty(int(w) * int(h) * 4, dtype=np.float32)
                    base_img.pixels.foreach_get(base_flat)
                    base_arr = base_flat.reshape((int(h), int(w), 4))
                out = base_arr
                if ch in {'BASE_COLOR', 'COLOR', 'EMISSION'}:
                    out[:, :, 3] = 1.0
                master.pixels.foreach_set(np.ascontiguousarray(out.reshape((-1, 4)), dtype=np.float32).reshape(-1))
                try:
                    master.alpha_mode = 'STRAIGHT'
                except Exception:
                    pass
                try:
                    if getattr(getattr(master, 'colorspace_settings', None), 'name', '') != 'sRGB':
                        master.colorspace_settings.name = 'sRGB'
                except Exception:
                    pass
                master.update()
                try:
                    sig = lazy_psd_material_stack_signature(material, ch)
                    if sig:
                        material['sps_lazy_stack_signature_' + ch] = sig
                        if int(w) * int(h) <= 2048 * 2048:
                            _cache_lazy_psd_master_preview(material, ch, sig, int(w), int(h), np.ascontiguousarray(out.reshape((-1, 4)), dtype=np.float32))
                except Exception:
                    pass
                try:
                    material['sps_deferred_composite_dirty_' + ch] = False
                    material['sps_deferred_composite_reason_' + ch] = ''
                    material['sps_layer_stack_dirty_' + ch] = False
                    material['sps_visibility_uncached_preview_' + ch] = False
                except Exception:
                    pass
                try:
                    ctx = context or getattr(bpy, 'context', None)
                    for area in getattr(getattr(ctx, 'screen', None), 'areas', ()) if ctx is not None else ():
                        if getattr(area, 'type', '') in {'VIEW_3D', 'IMAGE_EDITOR'}:
                            area.tag_redraw()
                except Exception:
                    pass
                # Keep the captured baseline across repeated OFF/ON cycles of the
                # same top direct-paint layer.  Removing it here made the second OFF
                # fall back to a full PSD recomposition and could also resurrect stale
                # projection pixels.
                return True
            except Exception:
                return False
        x0, y0, x1, y1 = [int(v) for v in box]
        x0 = max(0, min(w, x0)); x1 = max(0, min(w, x1))
        y0 = max(0, min(h, y0)); y1 = max(0, min(h, y1))
        if x1 <= x0 or y1 <= y0:
            return False
        raw = _sps_zlib.decompress(_sps_b64.b64decode(patch_b64.encode('ascii')))
        patch = np.frombuffer(raw, dtype=np.float32).reshape((y1-y0, x1-x0, 4)).copy()
        patch = np.clip(patch, 0.0, 1.0).astype(np.float32, copy=False)
        if not bool(np.any(patch[:, :, 3] > (1.0 / 4096.0))):
            return False
        base_arr = None
        try:
            base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_session_key(material, ch))
            if isinstance(base_entry, dict):
                cached = base_entry.get('baseline', None)
                if cached is not None and getattr(cached, 'shape', None) is not None and int(cached.shape[0]) == int(w) * int(h):
                    base_arr = np.ascontiguousarray(np.asarray(cached, dtype=np.float32).reshape((int(h), int(w), 4)), dtype=np.float32).copy()
        except Exception:
            base_arr = None
        if base_arr is None:
            try:
                curr_sig = lazy_psd_material_stack_signature(material, ch)
                curr_rows = _sps_json.loads(curr_sig) if curr_sig else []
                if curr_rows:
                    disabled_rows = [list(r) for r in curr_rows]
                    disabled_rows[-1][2] = False
                    disabled_sig = _sps_json.dumps(disabled_rows, ensure_ascii=False, separators=(',', ':'))
                    cached = _LAZY_PSD_MASTER_PREVIEW_CACHE.get(_lazy_psd_master_cache_key(material, ch, disabled_sig))
                    if cached:
                        cw, ch_cached, carr = cached
                        if int(cw) == int(w) and int(ch_cached) == int(h) and carr is not None:
                            base_arr = np.ascontiguousarray(np.asarray(carr, dtype=np.float32).reshape((int(h), int(w), 4)), dtype=np.float32).copy()
            except Exception:
                base_arr = None
        if base_arr is None:
            # The current public master may still contain this top layer from the
            # previous enabled view.  Reapplying the sparse patch over that stale
            # image darkens/thickens the stroke, so fall back to the full
            # recomposer unless a proven lower-stack baseline is available.
            return False
        out = base_arr.reshape((h, w, 4))
        dst = out[y0:y1, x0:x1, :]
        src_a = np.clip(patch[:, :, 3] * max(0.0, min(1.0, float(getattr(top, 'opacity', 1.0) or 0.0))), 0.0, 1.0)
        dst_a = np.clip(dst[:, :, 3], 0.0, 1.0)
        src_rgb = np.clip(patch[:, :, :3], 0.0, 1.0)
        dst_rgb = np.clip(dst[:, :, :3], 0.0, 1.0)
        mode = str(getattr(top, 'blend_mode', 'MIX') or 'MIX').upper()
        if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
            blend_rgb = src_rgb
        else:
            try:
                blend_rgb = _blend_rgb(dst_rgb.reshape((-1, 3)), src_rgb.reshape((-1, 3)), np.ones((src_a.size,), dtype=np.float32), mode).reshape(src_rgb.shape)
            except Exception:
                blend_rgb = src_rgb
        dst[:, :, :3], new_a = _composite_blended_source_over(
            dst_rgb, dst_a, src_rgb, src_a, blend_rgb,
        )
        dst[:, :, 3] = new_a
        # Public display canvas must stay opaque for colour textures.
        try:
            if ch in {'BASE_COLOR', 'COLOR', 'EMISSION'}:
                out[:, :, 3] = 1.0
        except Exception:
            pass
        master.pixels.foreach_set(np.ascontiguousarray(out.reshape((-1, 4)), dtype=np.float32).reshape(-1))
        try:
            master.alpha_mode = 'STRAIGHT'
        except Exception:
            pass
        try:
            if getattr(getattr(master, 'colorspace_settings', None), 'name', '') != 'sRGB':
                # Pixel data was already written in Blender-visible values.
                master.colorspace_settings.name = 'sRGB'
        except Exception:
            pass
        master.update()
        try:
            sig = lazy_psd_material_stack_signature(material, ch)
            if sig:
                material['sps_lazy_stack_signature_' + ch] = sig
                if int(w) * int(h) <= 2048 * 2048:
                    _cache_lazy_psd_master_preview(material, ch, sig, w, h, np.ascontiguousarray(out.reshape((-1, 4)), dtype=np.float32))
        except Exception:
            pass
        try:
            material['sps_deferred_composite_dirty_' + ch] = False
            material['sps_deferred_composite_reason_' + ch] = ''
            material['sps_layer_stack_dirty_' + ch] = False
            material['sps_visibility_uncached_preview_' + ch] = False
        except Exception:
            pass
        try:
            ctx = context or getattr(bpy, 'context', None)
            for area in getattr(getattr(ctx, 'screen', None), 'areas', ()) if ctx is not None else ():
                if getattr(area, 'type', '') in {'VIEW_3D', 'IMAGE_EDITOR'}:
                    area.tag_redraw()
        except Exception:
            pass
        return True
    except Exception:
        return False


def build_lazy_psd_material_sparse_top_preview(material, channel: str = 'BASE_COLOR', *, max_layers: int = 96):
    """Fast exact preview for a user-authored sparse top paint layer.

    The sparse RGBA patch is the top layer's source-of-truth.  When that layer is
    appended to an unchanged imported PSD stack, recomposing every 4K PSD layer is
    unnecessary and can block visibility updates.  Start from the previous public
    master only when the previous stack signature proves it represents the same
    lower layers, then source-over the sparse patch without altering its alpha.
    """
    np = _np_module()
    if np is None or material is None:
        return None
    try:
        import json as _json, base64 as _sps_b64, zlib as _sps_zlib
        channel = str(channel or 'BASE_COLOR').upper()
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return None
        layers = list(getattr(settings, 'layers', []) or [])
        if not layers or len(layers) > int(max_layers or 96):
            return None
        top_layer = layers[-1]
        if bool(getattr(top_layer, 'is_group', False)) or str(getattr(top_layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT':
            return None
        enabled_attr = layer_channel_enabled_attr(channel)
        attr = layer_channel_image_attr(channel)
        img_name = str(getattr(top_layer, attr, '') or '')
        img = bpy.data.images.get(img_name) if img_name else None
        if img is None:
            return None
        patch_b64 = str(img.get('smart_paint_suite_sparse_rgba_patch_b64', '') or '')
        patch_box = _sps_parse_bbox4(img.get('smart_paint_suite_sparse_rgba_patch_bbox', None))
        if not patch_b64 or patch_box is None:
            return None
        curr_sig = lazy_psd_material_stack_signature(material, channel)
        if not curr_sig:
            return None
        curr_rows = _json.loads(curr_sig)
        if not curr_rows:
            return None
        prev_sig = str(material.get('sps_lazy_stack_signature_' + channel, '') or '') if hasattr(material, 'get') else ''
        prev_rows = _json.loads(prev_sig) if prev_sig else []
        top_visible = bool(getattr(top_layer, 'enabled', True)) and bool(getattr(top_layer, enabled_attr, False))
        disabled_rows = [list(r) for r in curr_rows]
        try:
            disabled_rows[-1][2] = False
        except Exception:
            return None
        disabled_sig = _json.dumps(disabled_rows, ensure_ascii=False, separators=(',', ':'))
        master_name = str(material.get('sps_master_texture_image_' + channel, '') or '') if hasattr(material, 'get') else ''
        master = bpy.data.images.get(master_name) if master_name else None
        if master is None:
            for candidate in getattr(bpy.data, 'images', ()):
                try:
                    if bool(candidate.get('smart_paint_suite_master_texture')) and str(candidate.get('smart_paint_suite_material', '')) == str(getattr(material, 'name', '') or '') and str(candidate.get('smart_paint_suite_channel', '')).upper() == channel:
                        master = candidate
                        break
                except Exception:
                    continue
        width = int(img.get('smart_paint_suite_lazy_width', 0) or (master.size[0] if master is not None else 0) or 0)
        height = int(img.get('smart_paint_suite_lazy_height', 0) or (master.size[1] if master is not None else 0) or 0)
        if width <= 0 or height <= 0:
            return None
        # Top layer disabled: exact result is the cached lower-stack master.
        if not top_visible:
            cached = _LAZY_PSD_MASTER_PREVIEW_CACHE.get(_lazy_psd_master_cache_key(material, channel, disabled_sig))
            if cached:
                cw, ch, carr = cached
                if int(cw) == width and int(ch) == height and carr is not None:
                    return width, height, np.ascontiguousarray(carr.reshape((width * height, 4)), dtype=np.float32).copy()
            return None
        base_arr = None
        try:
            base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_session_key(material, channel))
            if isinstance(base_entry, dict):
                cached = base_entry.get('baseline', None)
                if cached is not None and getattr(cached, 'shape', None) is not None and int(cached.shape[0]) == int(width) * int(height):
                    base_arr = np.ascontiguousarray(np.asarray(cached, dtype=np.float32).reshape((width * height, 4)), dtype=np.float32).copy()
                    try:
                        _cache_lazy_psd_master_preview(material, channel, disabled_sig, width, height, base_arr)
                    except Exception:
                        pass
        except Exception:
            base_arr = None
        if base_arr is None:
            try:
                cached = _LAZY_PSD_MASTER_PREVIEW_CACHE.get(_lazy_psd_master_cache_key(material, channel, disabled_sig))
                if cached:
                    cw, ch, carr = cached
                    if int(cw) == width and int(ch) == height and carr is not None:
                        base_arr = np.ascontiguousarray(carr.reshape((width * height, 4)), dtype=np.float32).copy()
            except Exception:
                base_arr = None
        # Case 1: top sparse layer has just been appended.  Current master still
        # represents the previous lower-stack signature.
        if base_arr is None and prev_rows and len(curr_rows) == len(prev_rows) + 1 and curr_rows[:-1] == prev_rows and not bool(img.get('smart_paint_suite_authoritative_sparse_rgba_patch', False) or img.get('smart_paint_suite_exact_top_sparse_commit', False)):
            if master is not None and int(master.size[0]) == width and int(master.size[1]) == height:
                base_arr = np.empty(width * height * 4, dtype=np.float32)
                master.pixels.foreach_get(base_arr)
                try:
                    _cache_lazy_psd_master_preview(material, channel, prev_sig, width, height, base_arr)
                    _cache_lazy_psd_master_preview(material, channel, disabled_sig, width, height, base_arr)
                except Exception:
                    pass
        # Case 2: top sparse layer was disabled and is now enabled.  The current
        # master is the lower-stack result, or the disabled signature is cached.
        if base_arr is None and prev_rows and len(prev_rows) == len(curr_rows):
            cached = _LAZY_PSD_MASTER_PREVIEW_CACHE.get(_lazy_psd_master_cache_key(material, channel, disabled_sig))
            if cached:
                cw, ch, carr = cached
                if int(cw) == width and int(ch) == height and carr is not None:
                    base_arr = np.ascontiguousarray(carr.reshape((width * height, 4)), dtype=np.float32).copy()
        if base_arr is None:
            return None
        x0, y0, x1, y1 = patch_box
        x0 = max(0, min(width, int(x0))); x1 = max(0, min(width, int(x1)))
        y0 = max(0, min(height, int(y0))); y1 = max(0, min(height, int(y1)))
        if x1 <= x0 or y1 <= y0:
            return None
        raw = _sps_zlib.decompress(_sps_b64.b64decode(patch_b64.encode('ascii')))
        patch = np.frombuffer(raw, dtype=np.float32).reshape((int(y1-y0), int(x1-x0), 4)).copy()
        patch = np.clip(patch, 0.0, 1.0).astype(np.float32, copy=False)
        if not bool(np.any(patch[:, :, 3] > (1.0 / 4096.0))):
            return None
        out = base_arr.reshape((height, width, 4))
        dst = out[y0:y1, x0:x1, :]
        src_a = np.clip(patch[:, :, 3] * max(0.0, min(1.0, float(getattr(top_layer, 'opacity', 1.0) or 0.0))), 0.0, 1.0).astype(np.float32, copy=False)
        dst_a = np.clip(dst[:, :, 3], 0.0, 1.0).astype(np.float32, copy=False)
        src_rgb = np.clip(patch[:, :, :3], 0.0, 1.0).astype(np.float32, copy=False)
        dst_rgb = np.clip(dst[:, :, :3], 0.0, 1.0)
        mode = str(getattr(top_layer, 'blend_mode', 'MIX') or 'MIX').upper()
        if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
            blend_rgb = src_rgb
        else:
            try:
                blend_rgb = _blend_rgb(dst_rgb.reshape((-1,3)), src_rgb.reshape((-1,3)), np.ones((src_a.size,), dtype=np.float32), mode).reshape(src_rgb.shape)
            except Exception:
                blend_rgb = src_rgb
        dst[:, :, :3], new_a = _composite_blended_source_over(
            dst_rgb, dst_a, src_rgb, src_a, blend_rgb,
        )
        dst[:, :, 3] = new_a
        arr = np.ascontiguousarray(out.reshape((width * height, 4)), dtype=np.float32)
        if psd_preview_array_looks_black_or_empty(arr):
            return None
        return width, height, arr
    except Exception:
        return None

def build_lazy_psd_material_cached_preview(material, channel: str = 'BASE_COLOR', *, max_layers: int = 96):
    """Return a cached public master for the current lazy visibility signature."""
    try:
        if material is None:
            return None
        channel = str(channel or 'BASE_COLOR').upper()
        sig = lazy_psd_material_stack_signature(material, channel)
        if not sig:
            return None
        cached = _LAZY_PSD_MASTER_PREVIEW_CACHE.get(_lazy_psd_master_cache_key(material, channel, sig))
        if not cached:
            return None
        width, height, arr = cached
        if int(width) <= 0 or int(height) <= 0 or arr is None:
            return None
        return int(width), int(height), arr
    except Exception:
        return None


def build_lazy_psd_material_top_enable_preview(material, channel: str = 'BASE_COLOR', *, max_layers: int = 96):
    """Incrementally restore a newly enabled top lazy PSD layer over the current master.

    This avoids a second full 4K stack recomposition when the user toggles the top
    layer off and then back on.  It is deliberately conservative: if the previous
    and current signatures do not show exactly one top-layer False->True change,
    it returns None and the normal compositor is used.
    """
    np = _np_module()
    if np is None:
        return None
    try:
        import json as _json
        if material is None:
            return None
        channel = str(channel or 'BASE_COLOR').upper()
        # This path starts from the current public master image.  That is safe
        # only for untouched PSD-lazy stacks.  User-authored/sparse/materialized
        # layers must never be carried through this buffer, or old strokes can be
        # resurrected on ON/OFF.
        try:
            if material_has_authoritative_user_layer_pixels(material, channel):
                return None
        except Exception:
            pass
        prop = 'sps_lazy_stack_signature_' + channel
        prev_sig = str(material.get(prop, '') or '') if hasattr(material, 'get') else ''
        if not prev_sig:
            return None
        prev_rows = _json.loads(prev_sig)
        curr_sig = lazy_psd_material_stack_signature(material, channel)
        curr_rows = _json.loads(curr_sig) if curr_sig else []
        if not prev_rows or len(prev_rows) != len(curr_rows) or len(curr_rows) > int(max_layers or 96):
            return None
        changed = []
        for i, (p, c) in enumerate(zip(prev_rows, curr_rows)):
            try:
                pp = list(p); cc = list(c)
                # Compare all fields except enabled first; other changes need a full rebuild.
                if pp[:2] + pp[3:] != cc[:2] + cc[3:]:
                    return None
                if bool(pp[2]) != bool(cc[2]):
                    changed.append(i)
            except Exception:
                return None
        if len(changed) != 1:
            return None
        idx = int(changed[0])
        if not (bool(prev_rows[idx][2]) is False and bool(curr_rows[idx][2]) is True):
            return None
        # Direct restore is safe when no enabled visible paint row sits above the
        # changed layer.  Disabled UV/guide rows may remain above it in PSD imports.
        for _higher in curr_rows[idx + 1:]:
            _hp = list(_higher)
            if len(_hp) >= 4 and bool(_hp[2]) and bool(_hp[3]):
                return None
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return None
        layers = list(getattr(settings, 'layers', []) or [])
        if idx < 0 or idx >= len(layers):
            return None
        layer = layers[idx]
        if bool(getattr(layer, 'is_group', False)) or str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT':
            return None
        enabled_attr = layer_channel_enabled_attr(channel)
        if not bool(getattr(layer, enabled_attr, False)) or not bool(getattr(layer, 'enabled', True)):
            return None
        attr = layer_channel_image_attr(channel)
        img_name = str(getattr(layer, attr, '') or '')
        img = bpy.data.images.get(img_name) if img_name else None
        payload = lazy_psd_layer_payload_for_image(img) if img is not None else None
        master_name = str(material.get('sps_master_texture_image_' + channel, '') or '') if hasattr(material, 'get') else ''
        master = bpy.data.images.get(master_name) if master_name else None
        if master is None:
            # Public document images are also stored as visible document images.
            for candidate in getattr(bpy.data, 'images', ()):
                try:
                    if bool(candidate.get('smart_paint_suite_master_texture')) and str(candidate.get('smart_paint_suite_material', '')) == str(getattr(material, 'name', '') or '') and str(candidate.get('smart_paint_suite_channel', '')).upper() == channel:
                        master = candidate; break
                except Exception:
                    continue
        if payload is not None:
            record = dict(payload.get('record', {}) or {})
            width = int(payload.get('doc_width', 0) or 0); height = int(payload.get('doc_height', 0) or 0)
            depth = int(payload.get('depth', 8) or 8); color_mode = int(payload.get('color_mode', 3) or 3); psb = bool(payload.get('psb'))
        else:
            record = {}
            depth = 8; color_mode = 3; psb = False
            width = int(master.size[0]) if master is not None else (int(img.size[0]) if img is not None else 0)
            height = int(master.size[1]) if master is not None else (int(img.size[1]) if img is not None else 0)
        if width <= 0 or height <= 0:
            return None
        if master is None or int(master.size[0]) != width or int(master.size[1]) != height:
            return None
        try:
            if img is not None and int(img.size[0]) == int(width) and int(img.size[1]) == int(height) and not bool(img.get('smart_paint_suite_lazy_psd_pending', False)):
                payload = None
        except Exception:
            pass
        buf = np.empty(width * height * 4, dtype=np.float32)
        try:
            master.pixels.foreach_get(buf)
        except Exception:
            return None
        # Keep the buffer in Blender Image.pixels orientation (bottom-to-top) and
        # write into it in-place.  Avoiding a second full-canvas top-down copy is
        # important for repeated 4K visibility toggles.
        try:
            _cache_lazy_psd_master_preview(material, channel, prev_sig, width, height, buf)
        except Exception:
            pass
        out = buf.reshape((height, width, 4))
        if payload is None and img is not None and int(img.size[0]) == int(width) and int(img.size[1]) == int(height):
            try:
                layer_buf = np.empty(width * height * 4, dtype=np.float32)
                img.pixels.foreach_get(layer_buf)
                layer_arr = np.clip(layer_buf.reshape((height, width, 4)), 0.0, 1.0).astype(np.float32, copy=False)
                opacity = max(0.0, min(1.0, float(getattr(layer, 'opacity', 1.0) or 0.0)))
                mode = str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper()
                src_a_2d = np.clip(layer_arr[:, :, 3] * opacity, 0.0, 1.0).astype(np.float32, copy=False)
                if bool(np.any(src_a_2d > (1.0 / 4096.0))):
                    dst_a_2d = np.clip(out[:, :, 3], 0.0, 1.0).astype(np.float32, copy=False)
                    src_rgb_3d = np.clip(layer_arr[:, :, :3], 0.0, 1.0).astype(np.float32, copy=False)
                    dst_rgb_3d = np.clip(out[:, :, :3], 0.0, 1.0)
                    if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
                        blend_rgb_3d = src_rgb_3d
                    else:
                        try:
                            _sa_flat = src_a_2d.reshape((-1,))
                            blend_rgb_3d = _blend_rgb(dst_rgb_3d.reshape((-1, 3)), src_rgb_3d.reshape((-1, 3)), np.ones_like(_sa_flat, dtype=np.float32), mode).reshape(src_rgb_3d.shape)
                        except Exception:
                            blend_rgb_3d = src_rgb_3d
                    out[:, :, :3], new_a_2d = _composite_blended_source_over(
                        dst_rgb_3d, dst_a_2d, src_rgb_3d, src_a_2d, blend_rgb_3d,
                    )
                    out[:, :, 3] = new_a_2d
                arr = np.ascontiguousarray(out.reshape((width * height, 4)), dtype=np.float32)
                if psd_preview_array_looks_black_or_empty(arr):
                    return None
                return width, height, arr
            except Exception:
                pass
        if not record:
            return None
        left = int(record.get('left', 0)); top = int(record.get('top', 0))
        right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
        box_w = max(0, right - left); box_h = max(0, bottom - top)
        if box_w <= 0 or box_h <= 0:
            return None
        dst_x0 = max(0, left); dst_y0 = max(0, top); dst_x1 = min(width, right); dst_y1 = min(height, bottom)
        if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
            return None
        src_x0 = dst_x0 - left; src_y0 = dst_y0 - top; src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
        try:
            opacity = max(0.0, min(1.0, float(getattr(layer, 'opacity', record.get('opacity', 1.0)) or 0.0)))
        except Exception:
            opacity = 1.0
        mode = str(getattr(layer, 'blend_mode', record.get('blend_mode', 'MIX')) or 'MIX').upper()
        try:
            raw_channels = {int(k): v for k, v in (record.get('channel_data', {}) or {}).items()}
        except Exception:
            raw_channels = {}
        if not raw_channels:
            return None
        decoded = {}
        for cid, raw in raw_channels.items():
            try:
                decoded[int(cid)] = _psd_decode_channel_bytes(raw, box_w, box_h, depth, psb=psb)
            except Exception:
                pass
        if not decoded:
            return None

        def _plane(cid: int, y0: int, y1: int, x0: int, x1: int, default: float):
            raw = decoded.get(int(cid))
            hh = int(y1 - y0); ww = int(x1 - x0)
            if raw is None:
                return np.full((hh, ww), float(default), dtype=np.float32)
            try:
                if int(depth) == 8:
                    plane = np.frombuffer(raw, dtype=np.uint8).reshape((box_h, box_w))
                    return plane[y0:y1, x0:x1].astype(np.float32) / 255.0
                if int(depth) == 16:
                    plane = np.frombuffer(raw, dtype='>u2').reshape((box_h, box_w))
                    return plane[y0:y1, x0:x1].astype(np.float32) / 65535.0
                if int(depth) == 32:
                    plane = np.frombuffer(raw, dtype='>f4').reshape((box_h, box_w))
                    return np.clip(plane[y0:y1, x0:x1].astype(np.float32), 0.0, 1.0)
            except Exception:
                pass
            return np.full((hh, ww), float(default), dtype=np.float32)

        region_h = int(dst_y1 - dst_y0)
        chunk_rows = 192 if int(dst_x1 - dst_x0) >= 2048 else 384
        for cy0 in range(0, region_h, chunk_rows):
            cy1 = min(region_h, cy0 + chunk_rows)
            py0 = src_y0 + cy0; py1 = src_y0 + cy1
            if int(color_mode) == 1:
                g = _plane(0, py0, py1, src_x0, src_x1, 0.0)
                r = g; b = g
            elif int(color_mode) == 4:
                c = _plane(0, py0, py1, src_x0, src_x1, 0.0)
                m = _plane(1, py0, py1, src_x0, src_x1, 0.0)
                y = _plane(2, py0, py1, src_x0, src_x1, 0.0)
                k = _plane(3, py0, py1, src_x0, src_x1, 0.0)
                r = 1.0 - np.minimum(1.0, c + k)
                g = 1.0 - np.minimum(1.0, m + k)
                b = 1.0 - np.minimum(1.0, y + k)
            else:
                r = _plane(0, py0, py1, src_x0, src_x1, 0.0)
                g = _plane(1, py0, py1, src_x0, src_x1, 0.0) if 1 in decoded else r
                b = _plane(2, py0, py1, src_x0, src_x1, 0.0) if 2 in decoded else r
            a = _plane(-1, py0, py1, src_x0, src_x1, 1.0)
            if -2 in decoded:
                a = a * _plane(-2, py0, py1, src_x0, src_x1, 1.0)
            if -3 in decoded:
                a = a * _plane(-3, py0, py1, src_x0, src_x1, 1.0)
            try:
                src_rgba = np.dstack((r, g, b, a)).astype(np.float32, copy=False)
                src_rgba = _sps_repair_straight_alpha_rgb_fringes(src_rgba, width=int(dst_x1 - dst_x0), height=int(cy1 - cy0))
                src_rgb_3d = src_rgba[:, :, :3]
                src_a_2d = np.clip(src_rgba[:, :, 3] * opacity, 0.0, 1.0).astype(np.float32, copy=False)
            except Exception:
                src_rgb_3d = np.dstack((r, g, b)).astype(np.float32, copy=False)
                src_a_2d = np.clip(a * opacity, 0.0, 1.0).astype(np.float32, copy=False)
            if not bool(np.any(src_a_2d > (1.0 / 4096.0))):
                continue
            # Convert PSD top-down row range to Blender bottom-up row range.
            by0 = height - (dst_y0 + cy1)
            by1 = height - (dst_y0 + cy0)
            dst_chunk = out[by0:by1, dst_x0:dst_x1, :][::-1, :, :]
            dst_a_2d = np.clip(dst_chunk[:, :, 3], 0.0, 1.0).astype(np.float32, copy=False)
            dst_rgb_3d = np.clip(dst_chunk[:, :, :3], 0.0, 1.0)
            if mode in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER', 'PASS', 'PASSTHROUGH', 'PASS_THROUGH', 'REPLACE'}:
                blend_rgb_3d = src_rgb_3d
            else:
                try:
                    _flat_a = src_a_2d.reshape((-1,))
                    blend_rgb_3d = _blend_rgb(dst_rgb_3d.reshape((-1, 3)), src_rgb_3d.reshape((-1, 3)), np.ones_like(_flat_a, dtype=np.float32), mode).reshape(src_rgb_3d.shape)
                except Exception:
                    blend_rgb_3d = src_rgb_3d
            dst_chunk[:, :, :3], new_a_2d = _composite_blended_source_over(
                dst_rgb_3d, dst_a_2d, src_rgb_3d, src_a_2d, blend_rgb_3d,
            )
            dst_chunk[:, :, 3] = new_a_2d
        arr = np.ascontiguousarray(out.reshape((width * height, 4)), dtype=np.float32)
        if psd_preview_array_looks_black_or_empty(arr):
            return None
        return width, height, arr
    except Exception:
        return None


def build_lazy_psd_material_stack_preview(material, channel: str = 'BASE_COLOR', *, max_layers: int = 96):
    """Compose the current visible stack from still-lazy PSD records only.

    This is a safe fast path for visibility/enable toggles immediately after PSD
    import.  It refuses to run as soon as a visible layer has been materialized or
    painted, so edited pixel data cannot be replaced by the original PSD source.
    """
    try:
        if material is None:
            return None
        channel = str(channel or 'BASE_COLOR').upper()
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None:
            return None
        attr = layer_channel_image_attr(channel)
        enabled_attr = layer_channel_enabled_attr(channel)
        metadata_only_layer_tags = {
            'lyid', 'luni', 'lnsr', 'clbl', 'infx', 'knko', 'lspf', 'lclr',
            'shmd', 'fxrp', 'tsly',
        }
        for layer in list(getattr(settings, 'layers', []) or []):
            try:
                if bool(getattr(layer, 'is_group', False)):
                    continue
                if str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT':
                    continue
                if str(getattr(layer, 'adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                    continue
                if bool(getattr(layer, 'clip_to_below', False)):
                    return None
                if str(getattr(layer, 'mask_mode', 'NONE') or 'NONE').upper() not in {'', 'NONE'}:
                    return None
                if str(getattr(layer, 'mask_image', '') or ''):
                    return None
                raw_tags = str(getattr(layer, 'psd_raw_layer_tags', '') or '')
                if raw_tags:
                    try:
                        tag_keys = set((json.loads(raw_tags) or {}).keys())
                    except Exception:
                        tag_keys = set()
                    if tag_keys - metadata_only_layer_tags:
                        return None
            except Exception:
                return None
        records = []
        width = height = 0
        depth = 8
        color_mode = 3
        psb = False
        for layer in list(getattr(settings, 'layers', []) or []):
            try:
                if (
                    bool(getattr(layer, 'is_group', False))
                    or str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper() == 'ADJUSTMENT'
                    or str(getattr(layer, 'adjustment_type', 'NONE') or 'NONE').upper() != 'NONE'
                ):
                    continue
                if not bool(getattr(layer, enabled_attr, False)):
                    continue
                img_name = str(getattr(layer, attr, '') or '')
                img = bpy.data.images.get(img_name) if img_name else None
                visible = bool(getattr(layer, 'enabled', True))
                if img is None:
                    if visible:
                        try:
                            _kind = str(getattr(layer, 'layer_kind', 'PAINT') or 'PAINT').upper()
                            _has_masked_image = any(bool(str(getattr(layer, _attr, '') or '')) for _attr in (
                                'base_color_image', 'emission_image', 'roughness_image', 'metallic_image', 'normal_image', 'height_image', 'alpha_image', 'ao_image', 'mask_image'))
                        except Exception:
                            _kind = 'PAINT'
                            _has_masked_image = False
                        if _kind in {'PAINT', 'PBR_PAINT', 'DECAL'} and not _has_masked_image:
                            # A raster paint row without a channel image is an empty
                            # transparent layer for this channel.  It must not force a
                            # slow internal-document reload after duplicate/move.
                            continue
                        return None
                    continue
                payload = lazy_psd_layer_payload_for_image(img)
                if payload is not None:
                    try:
                        # If this layer has become layer-owned user pixels, the PSD
                        # source payload is no longer authoritative for display.
                        # Do not rebuild a visibility preview from the old source row.
                        if smart_paint_layer_image_has_authoritative_user_pixels(img):
                            if not visible:
                                continue
                            payload = None
                    except Exception:
                        pass
                if payload is None:
                    if not visible:
                        continue
                    if bool(img.get('smart_paint_suite_lazy_blank_layer', False)):
                        continue
                    try:
                        _sps_empty_clear = tuple(float(v) for v in tuple(img.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0)))[:4])
                    except Exception:
                        _sps_empty_clear = (1.0, 1.0, 1.0, 0.0)
                    try:
                        _sps_intentionally_empty = bool(img.get('smart_paint_suite_intentionally_empty', False)) and len(_sps_empty_clear) >= 4 and float(_sps_empty_clear[3]) <= (1.0 / 4096.0)
                    except Exception:
                        _sps_intentionally_empty = False
                    if _sps_intentionally_empty:
                        # A newly-created or duplicated empty transparent layer has no
                        # contribution to the visible projection.  Do not force an
                        # internal-document reload merely because it has a real Blender
                        # Image datablock.  The layer image remains authoritative for
                        # future brush strokes and PSD save; it is simply transparent
                        # for the current composite.
                        continue
                    sparse_w = int(width or 0)
                    sparse_h = int(height or 0)
                    try:
                        sparse_w = int(img.get('smart_paint_suite_lazy_width', sparse_w) or sparse_w)
                        sparse_h = int(img.get('smart_paint_suite_lazy_height', sparse_h) or sparse_h)
                    except Exception:
                        pass
                    rec_sparse = _sps_sparse_patch_preview_record_for_image(img, sparse_w, sparse_h, layer)
                    if rec_sparse is not None:
                        width = int(sparse_w or width)
                        height = int(sparse_h or height)
                        records.append(rec_sparse)
                        continue
                    try:
                        np = _np_module()
                        if np is None:
                            return None
                        iw = int(img.size[0]); ih = int(img.size[1])
                        full_w = int(width or sparse_w or iw)
                        full_h = int(height or sparse_h or ih)
                        if iw <= 0 or ih <= 0 or full_w <= 0 or full_h <= 0:
                            return None
                        buf = np.empty((iw * ih * 4,), dtype=np.float32)
                        img.pixels.foreach_get(buf)
                        rgba = np.clip(buf.reshape((ih, iw, 4)), 0.0, 1.0).astype(np.float32, copy=False)
                        if iw != full_w or ih != full_h:
                            y_idx = np.clip((np.arange(full_h) * (ih / float(full_h))).astype(np.int64), 0, ih - 1)
                            x_idx = np.clip((np.arange(full_w) * (iw / float(full_w))).astype(np.int64), 0, iw - 1)
                            rgba = rgba[y_idx[:, None], x_idx[None, :], :]
                        if not bool(np.any(rgba[:, :, 3] > (1.0 / 4096.0))):
                            continue
                        try:
                            opacity = max(0.0, min(1.0, float(getattr(layer, 'opacity', 1.0) or 0.0)))
                        except Exception:
                            opacity = 1.0
                        try:
                            mode = str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper()
                        except Exception:
                            mode = 'MIX'
                        records.append({
                            '_sps_full_rgba_preview': np.ascontiguousarray(rgba[::-1, :, :], dtype=np.float32),
                            'left': 0,
                            'top': 0,
                            'right': int(full_w),
                            'bottom': int(full_h),
                            'opacity': float(opacity),
                            'blend_mode': mode,
                            'enabled': True,
                            'name': str(getattr(layer, 'name', getattr(img, 'name', 'Layer')) or getattr(img, 'name', 'Layer')),
                        })
                        width = int(full_w)
                        height = int(full_h)
                        continue
                    except Exception:
                        pass
                    return None
                rec = dict(payload.get('record', {}) or {})
                if not rec:
                    return None
                try:
                    rec['_sps_local_cache_key'] = '|'.join((
                        str(img.get('smart_paint_suite_lazy_psd_key', '') or ''),
                        str(img.get('smart_paint_suite_source_file', '') or ''),
                        str(img_name or ''),
                        str(rec.get('record_index', '') or ''),
                        str(rec.get('name', '') or ''),
                        str(rec.get('left', 0) or 0),
                        str(rec.get('top', 0) or 0),
                        str(rec.get('right', 0) or 0),
                        str(rec.get('bottom', 0) or 0),
                    ))
                except Exception:
                    rec['_sps_local_cache_key'] = str(img_name or '') + '|' + str(rec.get('record_index', '') or '')
                width = int(payload.get('doc_width', width) or width or 0)
                height = int(payload.get('doc_height', height) or height or 0)
                depth = int(payload.get('depth', depth) or depth or 8)
                color_mode = int(payload.get('color_mode', color_mode) or color_mode or 3)
                psb = bool(payload.get('psb', psb))
                rec['enabled'] = bool(visible)
                try:
                    rec['opacity'] = max(0.0, min(1.0, float(getattr(layer, 'opacity', rec.get('opacity', 1.0)) or 0.0)))
                except Exception:
                    pass
                try:
                    rec['blend_mode'] = str(getattr(layer, 'blend_mode', rec.get('blend_mode', 'MIX')) or 'MIX').upper()
                except Exception:
                    pass
                records.append(rec)
            except Exception:
                return None
        if width <= 0 or height <= 0 or not records or len(records) > int(max_layers or 96):
            return None
        doc = {'width': width, 'height': height, 'depth': depth, 'color_mode': color_mode, 'psb': psb, 'layers': records, 'merged': None}
        arr = build_lazy_psd_color_preview(doc, max_layers=max_layers)
        if arr is None:
            return None
        try:
            sig = lazy_psd_material_stack_signature(material, channel)
            if sig:
                _cache_lazy_psd_master_preview(material, channel, sig, int(width), int(height), arr)
                material['sps_lazy_stack_signature_' + channel] = sig
        except Exception:
            pass
        return width, height, arr
    except Exception:
        return None

def build_lazy_psd_alpha_preview(doc: dict, *, max_layers: int = 32):
    """Build a display alpha channel from lazy PSD layer records.

    PSD merged previews are often RGB-only.  If used directly, transparent areas
    appear as opaque white in Blender's Image Editor.  This function decodes only
    alpha/mask channels, one layer at a time, to set the master preview alpha
    without materializing full RGB layer buffers.  It intentionally skips very
    large layer counts to preserve the 100-layer fast path.
    """
    np = _np_module()
    if np is None or not isinstance(doc, dict):
        return None
    try:
        width = int(doc.get('width', 0) or 0); height = int(doc.get('height', 0) or 0)
        depth = int(doc.get('depth', 8) or 8); color_mode = int(doc.get('color_mode', 3) or 3)
        psb = bool(doc.get('psb'))
        layers = list(doc.get('layers', []) or [])
        if width <= 0 or height <= 0 or not layers or len(layers) > int(max_layers or 32):
            return None
        out = np.zeros((height, width), dtype=np.float32)  # PSD top-to-bottom order.
        any_alpha = False
        for record in layers:  # internal bottom -> top, correct for alpha over.
            if not bool(record.get('enabled', True)):
                continue
            left = int(record.get('left', 0)); top = int(record.get('top', 0))
            right = int(record.get('right', 0)); bottom = int(record.get('bottom', 0))
            box_w = max(0, right - left); box_h = max(0, bottom - top)
            if box_w <= 0 or box_h <= 0:
                continue
            chdata = record.get('channel_data', {}) or {}
            alpha = None
            raw = chdata.get(-1)
            if raw is not None:
                try:
                    alpha = _psd_channel_float_array(raw, box_w, box_h, depth, psb=psb)
                except Exception:
                    alpha = None
            if alpha is None:
                alpha = np.ones((box_h, box_w), dtype=np.float32)
            for mask_id in (-2, -3):
                raw_m = chdata.get(mask_id)
                if raw_m is not None:
                    try:
                        alpha = alpha * _psd_channel_float_array(raw_m, box_w, box_h, depth, psb=psb)
                    except Exception:
                        pass
            try:
                alpha = np.clip(alpha * max(0.0, min(1.0, float(record.get('opacity', 1.0) or 0.0))), 0.0, 1.0)
            except Exception:
                alpha = np.clip(alpha, 0.0, 1.0)
            dst_x0 = max(0, left); dst_y0 = max(0, top)
            dst_x1 = min(width, right); dst_y1 = min(height, bottom)
            if dst_x1 <= dst_x0 or dst_y1 <= dst_y0:
                continue
            src_x0 = dst_x0 - left; src_y0 = dst_y0 - top
            src_x1 = src_x0 + (dst_x1 - dst_x0); src_y1 = src_y0 + (dst_y1 - dst_y0)
            src = np.clip(alpha[src_y0:src_y1, src_x0:src_x1], 0.0, 1.0)
            dst = out[dst_y0:dst_y1, dst_x0:dst_x1]
            out[dst_y0:dst_y1, dst_x0:dst_x1] = np.clip(src + dst * (1.0 - src), 0.0, 1.0)
            any_alpha = True
        if not any_alpha:
            return None
        return np.ascontiguousarray(out[::-1, :].reshape(-1), dtype=np.float32)  # Blender bottom-to-top.
    except Exception:
        return None


def read_layered_psd(filepath: str | Path) -> dict:
    """Read raster layer records from a PSD/PSB file without external packages.

    Returned layer arrays are in Blender Image.pixels order and can be written
    directly with foreach_set().  Unsupported Photoshop-only semantic features
    are retained as source metadata but not executed.
    """
    path = Path(filepath)
    data_bytes = path.read_bytes()
    data = memoryview(data_bytes)
    _psd_validate_document_structure(data, path, require_layers=False)
    if len(data) < 26 or bytes(data[0:4]) != b'8BPS':
        raise ValueError('Not a Photoshop PSD/PSB file.')
    version, offset = _psd_u16(data, 4)
    if version not in {1, 2}:
        raise ValueError('Unsupported PSD/PSB version.')
    psb = version == 2
    offset = 12
    channels, offset = _psd_u16(data, offset)
    height, offset = _psd_u32(data, offset)
    width, offset = _psd_u32(data, offset)
    depth, offset = _psd_u16(data, offset)
    color_mode, offset = _psd_u16(data, offset)
    if int(width) <= 0 or int(height) <= 0:
        raise ValueError('PSD document has no pixel area.')
    if int(depth) not in {8, 16, 32}:
        raise ValueError('Only 8/16/32-bit PSD layer channels are supported.')
    if int(color_mode) not in {1, 3, 4}:
        raise ValueError('Only grayscale, RGB and basic CMYK PSD layers are supported.')
    color_len, offset = _psd_u32(data, offset)
    offset += int(color_len)
    resources_len, offset = _psd_u32(data, offset)
    offset += int(resources_len)
    layer_mask_len, offset = _psd_len(data, offset, psb=psb)
    if layer_mask_len <= 0:
        return {'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode), 'layers': []}
    layer_mask_end = min(len(data), offset + int(layer_mask_len))
    layer_info_len, offset = _psd_len(data, offset, psb=psb)
    if layer_info_len <= 0:
        return {'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode), 'layers': []}
    layer_info_end = min(layer_mask_end, offset + int(layer_info_len))
    raw_count, offset = _psd_i16(data, offset)
    count = abs(int(raw_count))
    records = []
    channel_len_size = 8 if psb else 4
    for index in range(count):
        top, offset = _psd_i32(data, offset)
        left, offset = _psd_i32(data, offset)
        bottom, offset = _psd_i32(data, offset)
        right, offset = _psd_i32(data, offset)
        channel_count, offset = _psd_u16(data, offset)
        channel_info = []
        for _ in range(int(channel_count)):
            channel_id, offset = _psd_i16(data, offset)
            if channel_len_size == 8:
                channel_len, offset = _psd_len(data, offset, psb=True)
            else:
                channel_len, offset = _psd_u32(data, offset)
            channel_info.append((int(channel_id), int(channel_len)))
        blend_sig, offset = _psd_bytes(data, offset, 4)
        blend_key, offset = _psd_bytes(data, offset, 4)
        opacity = int(data[offset]) if offset < len(data) else 255; offset += 1
        clipping = int(data[offset]) if offset < len(data) else 0; offset += 1
        flags = int(data[offset]) if offset < len(data) else 0; offset += 1
        offset += 1  # filler
        extra_len, offset = _psd_u32(data, offset)
        extra_start = offset
        extra_end = min(layer_info_end, offset + int(extra_len))
        extra = _psd_parse_layer_extra(data, extra_start, extra_end, psb=psb)
        offset = extra_end
        name = str(extra.get('unicode_name') or extra.get('name') or f'PSD Layer {index + 1}').strip()
        records.append({
            'record_index': index,
            'top': int(top), 'left': int(left), 'bottom': int(bottom), 'right': int(right),
            'channel_info': channel_info,
            'blend_sig': blend_sig,
            'blend_key': blend_key,
            'blend_mode': _psd_layer_blend_mode(blend_key, extra),
            'opacity': max(0.0, min(1.0, float(opacity) / 255.0)),
            'enabled': not bool(flags & 0x02),
            'flags': int(flags),
            'clipping': int(clipping),
            'name': name or f'PSD Layer {index + 1}',
            'section_type': int(extra.get('section_type', 0) or 0),
            'mask_rect': dict(extra.get('mask_rect', {}) or {}),
            'raw_mask_data': str(extra.get('raw_mask_data', '') or ''),
            'sps_layer_info': dict(extra.get('sps_layer_info', {}) or {}),
            'adjustment': dict(extra.get('adjustment', {}) or {}),
            'tag_payloads': dict(extra.get('tag_payloads', {}) or {}),
            'raw_adjustment_tag_payloads': dict(extra.get('raw_adjustment_tag_payloads', {}) or {}),
            'raw_layer_tag_payloads': dict(extra.get('raw_layer_tag_payloads', {}) or {}),
            'tags': list(extra.get('tags', []) or []),
            'channel_data': {},
        })
    _psd_assign_derived_group_depths(records)
    for record in records:
        channel_data = {}
        for channel_id, channel_len in record.get('channel_info', []):
            raw, offset = _psd_bytes(data, offset, channel_len)
            channel_data[int(channel_id)] = raw
        record['channel_data'] = channel_data
    merged = None
    try:
        merged = _psd_main_composite_to_rgba(data, layer_mask_end, doc_width=int(width), doc_height=int(height), channels=int(channels), depth=int(depth), color_mode=int(color_mode), psb=psb)
    except Exception:
        merged = None
    converted = []
    for record in records:
        section = int(record.get('section_type', 0) or 0)
        if section in {1, 2}:
            layer = dict(record)
            meta = dict(layer.get('sps_layer_info', {}) or {})
            layer['rgba'] = None
            try:
                mask_rgba = _psd_layer_mask_to_rgba(record, doc_width=int(width), doc_height=int(height), depth=int(depth), psb=psb)
                if mask_rgba is not None:
                    layer['mask_rgba'] = mask_rgba
            except Exception:
                pass
            layer['is_group'] = bool(meta.get('is_group', True))
            layer['group_expanded'] = bool(meta.get('group_expanded', True))
            layer['group_depth'] = int(meta.get('group_depth', layer.get('_derived_group_depth', 0)) or 0)
            layer['clip_to_below'] = bool(meta.get('clip_to_below', False))
            if str(meta.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                layer['adjustment'] = dict(meta)
                layer['is_adjustment'] = True
            layer.pop('channel_data', None)
            converted.append(layer)
            continue
        if section == 3:
            # Closing group dividers are structural markers in PSD.  Smart Paint
            # stores groups as explicit folder rows, so the closing marker is not
            # exposed as a paint layer.
            continue
        try:
            rgba = _psd_layer_to_rgba(record, doc_width=int(width), doc_height=int(height), depth=int(depth), color_mode=int(color_mode), psb=psb, apply_layer_mask=False)
        except Exception:
            rgba = None
        # Keep every visible Photoshop layer row in the Smart Paint stack.
        # Empty/zero-bounds raster layers have no decodable RGBA payload, but they
        # are still real PSD layers and must round-trip as editable transparent
        # rows instead of being silently dropped.
        empty_raster = False
        if rgba is None and not dict(record.get('adjustment', {}) or {}) and not dict(record.get('raw_adjustment_tag_payloads', {}) or {}):
            empty_raster = True
        layer = dict(record)
        meta = dict(layer.get('sps_layer_info', {}) or {})
        layer['rgba'] = rgba
        if empty_raster:
            layer['empty_layer'] = True
        try:
            mask_rgba = _psd_layer_mask_to_rgba(record, doc_width=int(width), doc_height=int(height), depth=int(depth), psb=psb)
            if mask_rgba is not None:
                layer['mask_rgba'] = mask_rgba
        except Exception:
            pass
        if dict(layer.get('adjustment', {}) or {}) or dict(layer.get('raw_adjustment_tag_payloads', {}) or {}):
            layer['is_adjustment'] = True
        layer['is_group'] = bool(meta.get('is_group', False))
        layer['group_depth'] = int(meta.get('group_depth', layer.get('_derived_group_depth', 0)) or 0)
        layer['clip_to_below'] = bool(meta.get('clip_to_below', int(layer.get('clipping', 0) or 0) > 0))
        if str(meta.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
            layer['adjustment'] = dict(meta)
            layer['is_adjustment'] = True
        # Drop raw compressed payloads from the public result to reduce memory use.
        layer.pop('channel_data', None)
        converted.append(layer)
    raster_converted = [l for l in converted if not bool(l.get('is_group', False))]
    ordered_raster = _psd_layers_internal_order(raster_converted, merged, width=int(width), height=int(height))
    _has_stack_pos = any('stack_position' in dict(l.get('sps_layer_info', {}) or {}) for l in converted)
    _all_stack_pos = bool(converted) and all('stack_position' in dict(l.get('sps_layer_info', {}) or {}) for l in converted)
    _has_groups = any(bool(l.get('is_group', False)) for l in converted)
    if _has_groups:
        _psd_apply_section_group_depths(converted)
    if _all_stack_pos:
        layers = _psd_sort_by_sps_stack_position(list(converted))
    elif _has_groups:
        # Match the lazy reader above: partial SPSi positions may be stale after
        # a raw-record splice, while PSD section dividers remain authoritative.
        layers = _psd_topdown_converted_to_internal(list(converted))
    elif _has_stack_pos:
        layers = _psd_sort_by_sps_stack_position(list(converted))
    elif raster_converted and ordered_raster and str(ordered_raster[0].get('record_index', '')) != str(raster_converted[0].get('record_index', '')):
        layers = list(reversed(converted))
    else:
        layers = list(converted)
    layers = _psd_normalize_reader_layers_to_internal(layers)
    return {'width': int(width), 'height': int(height), 'depth': int(depth), 'color_mode': int(color_mode), 'layers': layers, 'merged': merged, 'psb': bool(psb)}


def _remove_replaced_private_layer_images(material, channel: str) -> None:
    try:
        mat_name = str(getattr(material, 'name', '') or '')
        ch = _safe_channel(channel)
        for image in list(getattr(bpy.data, 'images', ())):
            try:
                if not bool(image.get('smart_paint_suite_layer_image')):
                    continue
                if str(image.get('smart_paint_suite_material', '') or '') != mat_name:
                    continue
                if str(image.get('smart_paint_suite_channel', '') or '').upper() != ch:
                    continue
                bpy.data.images.remove(image)
            except Exception:
                continue
    except Exception:
        pass



def _force_public_master_display_opaque_now(material, channel: str = 'BASE_COLOR', image=None) -> bool:
    """Normalize only the public PSD/PSB display texture for Blender's viewport.

    Private layer/export images keep their real alpha. The public master is a
    paint/display canvas, so colour textures must be sRGB/STRAIGHT and opaque;
    otherwise Blender blends the flattened RGB a second time and the Image Editor
    or 3D View looks pale.
    """
    try:
        ch = _safe_channel(channel)
        img = image
        if img is None:
            from . import clean_layer_stack_engine as _clean_get
            img = _clean_get.get_master_texture_image(material, ch, create=False)
        if img is None:
            return False
        from . import clean_layer_stack_engine as _clean
        fn = getattr(_clean, '_force_psd_public_display_alpha_opaque', None)
        if callable(fn):
            return bool(fn(img, material, ch))
    except Exception:
        pass
    return False

def import_layered_psd_to_stack(material, channel: str, filepath: str | Path, *, context=None, replace: bool = True) -> tuple[bool, dict | str]:
    from . import clean_layer_stack_engine as _clean
    _res = _clean.import_layered_psd_to_stack(material, channel, filepath, context=context, replace=replace)
    try:
        _force_public_master_display_opaque_now(material, channel)
    except Exception:
        pass
    return _res

_TEXTURE_SAVE_PRECOMMITTED = set()


def _texture_save_commit_key(material, channel: str = 'BASE_COLOR'):
    try:
        return (str(getattr(material, 'name_full', '') or getattr(material, 'name', '') or ''), _safe_channel(channel))
    except Exception:
        return ('', _safe_channel(channel))


def mark_texture_save_precommitted(material, channel: str = 'BASE_COLOR') -> None:
    try:
        key = _texture_save_commit_key(material, channel)
        if key[0]:
            _TEXTURE_SAVE_PRECOMMITTED.add(key)
    except Exception:
        pass


def _consume_texture_save_precommitted(material, channel: str = 'BASE_COLOR') -> bool:
    try:
        key = _texture_save_commit_key(material, channel)
        if key in _TEXTURE_SAVE_PRECOMMITTED:
            _TEXTURE_SAVE_PRECOMMITTED.discard(key)
            return True
    except Exception:
        pass
    return False



def _commit_visible_master_session_delta_for_texture_save(material, channel: str = 'BASE_COLOR') -> bool:
    """Save-boundary guard for native Blender Texture Paint strokes.

    New SPS paint layers are often represented by a sparse/private layer record,
    while Blender's native brush writes first to the public composited master
    image used by the Image Editor and 3D View.  The PSD writer is allowed to
    skip heavy preflight for clean stacks, but that shortcut must not run before
    a pending master-paint session has been copied back into the active layer.
    This one-shot guard performs that copy before the writer marks the stack as
    prepared, so the layer record -- not only the display preview -- owns the
    stroke that will be serialized to PSD/PSB.
    """
    if material is None:
        return False
    ch = _safe_channel(channel)
    try:
        explicit_force = bool(material.get('sps_save_force_untracked_commit_' + ch, False))
    except Exception:
        explicit_force = False
    try:
        _sess_probe = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
        _has_exact_live_probe = bool(isinstance(_sess_probe, dict) and _sess_probe.get('baseline') is not None)
        if (not bool(explicit_force)) and (not _has_exact_live_probe) and bool(_active_private_layer_image_ready_for_direct_save(material, ch)):
            return False
    except Exception:
        pass
    pending = False
    try:
        pending = bool(_has_pending_master_paint_session(material, ch))
    except Exception:
        pending = False
    master_dirty = False
    active_empty = False
    try:
        active_empty = bool(_active_layer_is_clean_intentionally_empty(material, ch))
    except Exception:
        active_empty = False
    try:
        for prop in (
            'sps_document_file_image_',
            'sps_master_texture_image_',
            'sps_visible_master_image_',
            'sps_document_target_image_',
            'sps_composite_preview_image',
        ):
            if prop.endswith('_'):
                _name = str(material.get(prop + ch, '') or '')
            else:
                _name = str(material.get(prop, '') or '')
            _master_probe = bpy.data.images.get(_name) if _name else None
            if _master_probe is not None and bool(getattr(_master_probe, 'is_dirty', False)):
                master_dirty = True
                break
    except Exception:
        master_dirty = False
    try:
        _base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_session_key(material, ch))
        baseline_ready = isinstance(_base_entry, dict) and (_base_entry.get('baseline', None) is not None)
    except Exception:
        baseline_ready = False
    paint_marker = False
    try:
        paint_marker = bool(_recent_operator_was_paint(getattr(bpy, 'context', None)))
    except Exception:
        paint_marker = False
    if not paint_marker:
        try:
            for prop in (
                'sps_document_file_image_',
                'sps_master_texture_image_',
                'sps_visible_master_image_',
                'sps_document_target_image_',
                'sps_composite_preview_image',
            ):
                if prop.endswith('_'):
                    _name = str(material.get(prop + ch, '') or '')
                else:
                    _name = str(material.get(prop, '') or '')
                _master_probe = bpy.data.images.get(_name) if _name else None
                if _master_probe is None:
                    continue
                for _marker in (
                    'smart_paint_suite_pending_visible_paint',
                    'smart_paint_suite_pending_master_paint',
                    'smart_paint_suite_painted_since_last_projection',
                    'smart_paint_suite_explicit_visible_paint',
                ):
                    try:
                        if bool(_master_probe.get(_marker, False)):
                            paint_marker = True
                            break
                    except Exception:
                        pass
                if paint_marker:
                    break
        except Exception:
            paint_marker = False
    if not (pending or explicit_force or (master_dirty and (active_empty or baseline_ready or paint_marker))):
        return False
    try:
        material['sps_texture_save_visible_master_commit_probe_' + ch] = (
            'pending=%s dirty=%s empty=%s baseline=%s marker=%s' % (bool(pending), bool(master_dirty), bool(active_empty), bool(baseline_ready), bool(paint_marker))
        )
    except Exception:
        pass
    try:
        changed = bool(_force_commit_visible_master_delta_to_active_layer_for_save(
            material,
            ch,
            tolerance=(2.0 / 255.0),
            force=True,
        ))
    except Exception:
        changed = False
    if changed:
        try:
            mark_texture_save_precommitted(material, ch)
        except Exception:
            pass
        try:
            material['sps_texture_save_visible_master_committed_' + ch] = True
        except Exception:
            pass
        try:
            for prop in (
                'sps_document_file_image_',
                'sps_master_texture_image_',
                'sps_visible_master_image_',
                'sps_document_target_image_',
                'sps_composite_preview_image',
            ):
                if prop.endswith('_'):
                    _name = str(material.get(prop + ch, '') or '')
                else:
                    _name = str(material.get(prop, '') or '')
                _master_done = bpy.data.images.get(_name) if _name else None
                if _master_done is None:
                    continue
                for _marker in (
                    'smart_paint_suite_pending_visible_paint',
                    'smart_paint_suite_pending_master_paint',
                    'smart_paint_suite_painted_since_last_projection',
                    'smart_paint_suite_explicit_visible_paint',
                    'smart_paint_suite_dirty_bbox',
                ):
                    try:
                        if _marker in _master_done:
                            del _master_done[_marker]
                    except Exception:
                        pass
        except Exception:
            pass
    return bool(changed)



def _active_layer_is_clean_intentionally_empty(material, channel: str = 'BASE_COLOR') -> bool:
    """True for a newly-added transparent active layer with no paint evidence."""
    try:
        if material is None:
            return False
        ch = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        layers = getattr(settings, 'layers', None) if settings is not None else None
        if layers is None or len(layers) <= 0:
            return False
        idx = int(getattr(settings, 'active_layer_index', -1) or -1)
        if idx < 0 or idx >= len(layers):
            return False
        layer = layers[idx]
        attr = layer_channel_image_attr(ch)
        name = str(getattr(layer, attr, '') or '')
        image = bpy.data.images.get(name) if name else None
        if image is None:
            return False
        if not bool(image.get('smart_paint_suite_intentionally_empty', False)):
            return False
        for marker in (
            'smart_paint_suite_dirty_bbox',
            'smart_paint_suite_sparse_rgba_patch_b64',
            'smart_paint_suite_last_brush_color',
            'smart_paint_suite_painted_since_last_projection',
            'smart_paint_suite_direct_layer_dirty',
            'smart_paint_suite_dirty_from_master',
            'smart_paint_suite_user_edited',
            'smart_paint_suite_texture_needs_save',
        ):
            try:
                if bool(image.get(marker, False)):
                    return False
            except Exception:
                pass
        return True
    except Exception:
        return False


def _image_has_explicit_visible_paint_marker(image) -> bool:
    try:
        if image is None:
            return False
        for marker in (
            'smart_paint_suite_dirty_bbox',
            'smart_paint_suite_pending_visible_paint',
            'smart_paint_suite_pending_master_paint',
            'smart_paint_suite_painted_since_last_projection',
            'smart_paint_suite_dirty_from_master',
            'smart_paint_suite_last_brush_color',
        ):
            try:
                if bool(image.get(marker, False)):
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False

def _master_dirty_is_only_clean_add_layer_baseline(material, channel: str, image) -> bool:
    """True when Image.is_dirty is Blender/parser bookkeeping, not user paint.

    Loading a PSD through the Smart Paint parser and then adding a layer can leave
    the public master Image datablock dirty even though no brush pixels changed.
    Treating that flag as pending paint forces the save-time inverse solver to
    compare/recompose the entire PSD and is the Windows path that produced invalid
    PSD bounds after Add Layer -> Save.
    """
    try:
        if material is None or image is None:
            return False
        ch = _safe_channel(channel)
        for marker in (
            'smart_paint_suite_dirty_bbox',
            'smart_paint_suite_pending_visible_paint',
            'smart_paint_suite_pending_master_paint',
            'smart_paint_suite_painted_since_last_projection',
            'smart_paint_suite_dirty_from_master',
            'smart_paint_suite_last_brush_color',
        ):
            try:
                if bool(image.get(marker, False)):
                    return False
            except Exception:
                pass
        sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
        if isinstance(sess, dict):
            master_name = str(sess.get('master_image', '') or '')
            if master_name and master_name != str(getattr(image, 'name', '') or ''):
                return False
            baseline = sess.get('baseline', None)
            if baseline is not None:
                try:
                    import numpy as np
                    current = _image_array_np(image, use_cache=False)
                    base = np.asarray(baseline, dtype=np.float32).reshape((-1, 4))
                    if current is not None and getattr(current, 'shape', None) == getattr(base, 'shape', None):
                        # Full-array comparison is intentional here: this function is
                        # called only at explicit Save boundaries.  It prevents the
                        # PSD parser-generated master from being misread as a real
                        # brush stroke merely because Blender left Image.is_dirty set.
                        if not bool(np.any(np.max(np.abs(current[:, :4] - base[:, :4]), axis=1) > (2.0 / 255.0))):
                            return True
                        return False
                except Exception:
                    pass
            old_stamp = sess.get('sample_stamp', None)
            if old_stamp is None:
                old_stamp = sess.get('stamp', None)
            if old_stamp is not None:
                try:
                    now_stamp = _image_sample_stamp(image, 96)
                    if tuple(now_stamp) == tuple(old_stamp):
                        return True
                except Exception:
                    pass
        try:
            if bool(image.get('smart_paint_suite_parser_merged_preview', False)) and bool(image.get('smart_paint_suite_layered_source_path', '')):
                return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def _texture_save_needs_pending_paint_commit(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    """Return True only when Texture Save must run expensive paint recovery.

    Ordinary PSD serialization writes private layer images directly.  The costly
    save preflight is necessary only for visible-master paint or direct paint
    sessions that may not yet be reflected in those private images.  This fast
    predicate deliberately avoids path lookups and full layer compositing so a
    clean 2K/4K production stack can save immediately instead of stalling while
    probing stale projection data.
    """
    if material is None:
        return False
    ch = _safe_channel(channel)
    ctx = context or getattr(bpy, 'context', None)
    try:
        if bool(material.get('sps_save_force_untracked_commit_' + ch, False)):
            return True
    except Exception:
        pass
    try:
        if bool(_active_private_layer_image_ready_for_direct_save(material, ch)):
            # The active private layer already contains the stroke pixels.  Saving
            # should serialize layer records directly instead of running visible
            # master recovery, even if Blender's last operator was a brush stroke.
            return False
    except Exception:
        pass
    try:
        # Native Texture Paint writes to the public/master canvas.  In zero-idle
        # mode there may be no live timer/session marker left by the time the user
        # presses Save, but Blender still marks the Image datablock dirty.  Treat a
        # dirty visible document image as a save-boundary commit request so a newly
        # added empty private layer is not serialized while the real stroke remains
        # only on the canvas.  The later commit code still verifies that the master
        # differs from the private stack before copying pixels.
        for prop in (
            'sps_document_file_image_',
            'sps_master_texture_image_',
            'sps_visible_master_image_',
            'sps_document_target_image_',
            'sps_composite_preview_image',
        ):
            if prop.endswith('_'):
                name = str(material.get(prop + ch, '') or '')
            else:
                name = str(material.get(prop, '') or '')
            master = bpy.data.images.get(name) if name else None
            if master is not None and bool(_image_has_explicit_visible_paint_marker(master)):
                if bool(_master_dirty_is_only_clean_add_layer_baseline(material, ch, master)):
                    continue
                return True
            if master is not None and bool(getattr(master, 'is_dirty', False)):
                # Add Layer without any brush stroke can leave the parser-generated
                # master Image dirty. Do not scan/compare a 4K master at Save when
                # the active layer is still intentionally empty and the recent
                # operator was not a paint stroke; this is the add-only freeze/error
                # path reported on Windows. Real visible-master paint is still
                # committed because it has explicit markers or Blender's recent
                # operator is a paint action.
                if bool(_active_layer_is_clean_intentionally_empty(material, ch)) and (not bool(_image_has_explicit_visible_paint_marker(master))) and (not bool(_recent_operator_was_paint(ctx))):
                    continue
                if bool(_master_dirty_is_only_clean_add_layer_baseline(material, ch, master)):
                    continue
                if (not bool(_image_has_explicit_visible_paint_marker(master))) and (not bool(_recent_operator_was_paint(ctx))):
                    continue
                return True
    except Exception:
        pass
    try:
        if bool(_recent_operator_was_paint(ctx)):
            return True
    except Exception:
        pass
    try:
        key = _direct_session_key(material, ch)
        if key in _DIRECT_LAYER_PAINT_SESSIONS:
            return True
    except Exception:
        pass
    try:
        sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
    except Exception:
        sess = None
    if isinstance(sess, dict):
        try:
            if str(sess.get('paint_op_token', '') or ''):
                return True
        except Exception:
            pass
        try:
            if bool(sess.get('baseline') is not None):
                master_name = str(sess.get('master_image', '') or '')
                master = bpy.data.images.get(master_name) if master_name else None
                if master is None:
                    return False
                try:
                    _active_empty_no_marker = bool(_active_layer_is_clean_intentionally_empty(material, ch)) and (not bool(_image_has_explicit_visible_paint_marker(master))) and (not bool(_recent_operator_was_paint(ctx)))
                    if _active_empty_no_marker:
                        try:
                            np = _np_module()
                            base = sess.get('baseline', None)
                            cur = _sps_image_array_np_no_clip(master)
                            if np is not None and base is not None and cur is not None:
                                base = np.asarray(base, dtype=np.float32).reshape((-1, 4))
                                cur = np.asarray(cur, dtype=np.float32).reshape((-1, 4))
                                if getattr(base, 'shape', None) == getattr(cur, 'shape', None):
                                    d = np.max(np.abs(cur[:, :4] - base[:, :4]), axis=1)
                                    changed = int(np.count_nonzero(d > (1.0 / 4096.0)))
                                    total = int(d.shape[0]) if getattr(d, 'shape', None) is not None else 0
                                    if changed > 0 and (changed <= 262144 or (total > 0 and (changed / float(total)) <= 0.35)):
                                        return True
                        except Exception:
                            pass
                        return False
                    if bool(_master_dirty_is_only_clean_add_layer_baseline(material, ch, master)):
                        return False
                except Exception:
                    pass
                old_stamp = sess.get('sample_stamp', None)
                if old_stamp is None:
                    old_stamp = sess.get('stamp', None)
                try:
                    now_stamp = _image_sample_stamp(master, 96)
                    if old_stamp is not None and tuple(now_stamp) == tuple(old_stamp):
                        return False
                except Exception:
                    pass
                return True
        except Exception:
            pass
        try:
            # A lazy session created by target/display synchronization is not by
            # itself pending paint.  It becomes pending only when a paint token or
            # explicit image marker is present; those cases are handled above/below.
            if bool(sess.get('lazy', False)) and bool(sess.get('baseline') is None):
                pass
        except Exception:
            pass
    try:
        for prop in (
            'sps_document_file_image_',
            'sps_master_texture_image_',
            'sps_visible_master_image_',
            'sps_document_target_image_',
            'sps_composite_preview_image',
        ):
            if prop.endswith('_'):
                name = str(material.get(prop + ch, '') or '')
            else:
                name = str(material.get(prop, '') or '')
            image = bpy.data.images.get(name) if name else None
            if image is None:
                continue
            for marker in (
                'smart_paint_suite_pending_visible_paint',
                'smart_paint_suite_pending_master_paint',
                'smart_paint_suite_painted_since_last_projection',
            ):
                try:
                    if bool(image.get(marker, False)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def _live_master_image_for_paint_commit(material, channel: str = 'BASE_COLOR', session=None):
    """Return the live composited paint target for commit/save recovery.

    During Texture > Save, assigning the destination PSD path can create or select
    a file-named public Image datablock.  That image may be a clean/blank file
    target, while the uncommitted brush stroke still exists on the composited
    master used when the paint session was armed.  Save-time recovery must read
    that live session image, not the newly selected save-path image.
    """
    try:
        ch = _safe_channel(channel)
        sess = session
        if sess is None:
            try:
                sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
            except Exception:
                sess = None
        if isinstance(sess, dict):
            name = str(sess.get('master_image', '') or sess.get('image', '') or '')
            img = bpy.data.images.get(name) if name else None
            if img is not None:
                try:
                    if bool(img.get('smart_paint_suite_master_texture', False)):
                        return img
                except Exception:
                    return img
        # Prefer material properties that point to an already-rendered composite and
        # ignore the save path.  This avoids _ensure_document_file_image() creating a
        # blank file-named image before pending paint is committed.
        for prop in ('sps_visible_master_image_', 'sps_master_texture_image_', 'sps_document_target_image_', 'sps_composite_preview_image'):
            try:
                name = str(material.get(prop + ch if prop.endswith('_') else prop, '') or '') if material is not None else ''
            except Exception:
                name = ''
            img = bpy.data.images.get(name) if name else None
            if img is None:
                continue
            try:
                if bool(img.get('smart_paint_suite_projection_uninitialized', False)):
                    continue
            except Exception:
                pass
            try:
                if bool(img.get('smart_paint_suite_master_texture', False)):
                    return img
            except Exception:
                return img
    except Exception:
        pass
    try:
        return get_master_texture_image(material, channel, create=False)
    except Exception:
        return None



def _sps_save_untracked_master_delta_allowed(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    """Return True only when Save may recover master-only paint without a baseline.

    A correct layer stack can differ from the public master for non-paint reasons
    (stale preview, RGB-only fallback, mask/group/adjustment recomposition, file
    identity swaps).  Treating that difference as a brush stroke is destructive:
    it flattens other visible layers into the active private layer during Save.
    Therefore untracked recovery is allowed only for an explicit paint context or
    an existing Smart Paint paint session.  Ordinary PSD serialization must use
    private layer images as the source of truth.
    """
    try:
        channel = _safe_channel(channel)
    except Exception:
        channel = str(channel or 'BASE_COLOR').upper()
    try:
        if bool(_recent_operator_was_paint(context)):
            return True
    except Exception:
        pass
    try:
        sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, channel))
        if isinstance(sess, dict):
            # A baseline alone is not proof of a user stroke; Smart Paint may
            # create exact baselines during target synchronization.  The exact
            # baseline commit path above already handles real deltas safely.
            # Untracked fallback needs a direct paint token or explicit marker.
            if str(sess.get('paint_op_token', '') or ''):
                return True
            # A lazy visible-master paint session is an explicit save-boundary
            # signal: Blender has a live public paint target but no exact baseline
            # was captured yet.  The later brush-like-delta test still prevents
            # full-canvas stale projections from being flattened into a private
            # layer, but Save must be allowed to inspect this session or the active
            # stroke can serialize as an empty/white PSD layer.
            if bool(sess.get('lazy', False)) and not bool(sess.get('baseline') is not None):
                try:
                    if bool(_recent_operator_was_paint(context)) or str(sess.get('paint_op_token', '') or ''):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    try:
        master = get_master_texture_image(material, channel, create=False)
        if master is not None:
            # A dirty public/master image is often just a freshly recomposited
            # display target.  It is not layer-authoritative paint by itself.
            # Save-time untracked recovery is allowed only for explicit pending
            # paint markers or a current paint operator/session; otherwise stale
            # flattened previews can be copied into the active private layer.
            for prop in (
                'smart_paint_suite_pending_visible_paint',
                'smart_paint_suite_pending_master_paint',
                'smart_paint_suite_painted_since_last_projection',
            ):
                try:
                    if bool(master.get(prop, False)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def _sps_bodypaint_direct_layer_write_active(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    """True when native paint should be trusted only from the selected layer image.

    In this mode visible-master deltas are projection/cache artifacts unless the
    user explicitly enabled all-layers painting.  This prevents lower PSD layers
    from being copied into a newly created top paint layer at Save/toggle time.
    """
    try:
        if material is None:
            return False
        ch = _safe_channel(channel)
        # Ignore the retired all-layers runtime flag.  A private active layer
        # image is the source of truth whenever it is the native write image.
        layer, image = _active_layer_image_for_material(material, ch)
        if layer is None or image is None:
            return False
        if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_visible_document', False)):
            return False
        native_name = str(material.get('sps_native_write_image_' + ch, '') or '')
        if native_name and native_name == str(getattr(image, 'name', '') or ''):
            return True
        obj = getattr(context or getattr(bpy, 'context', None), 'object', None)
        if obj is not None and getattr(obj, 'mode', '') == 'TEXTURE_PAINT':
            return True
        return False
    except Exception:
        return False



def _safe_commit_pending_paint_for_texture_save(material, channel: str = 'BASE_COLOR', context=None, *, force_untracked: bool = False, refresh_master: bool = True) -> bool:
    """Commit trustworthy pending paint before Texture > Save/PSD export.

    Save is the one path that must prefer correctness over debounce/idle safety.
    Commit visible-master paint first, before any direct-layer flush or projection
    refresh can rebuild the public master and erase the only copy of the stroke.
    """
    if material is None:
        return False
    channel = _safe_channel(channel)
    ctx = context or getattr(bpy, 'context', None)
    key = _session_key(material, channel)
    changed = False

    # BodyPaint-style direct-layer mode: Blender writes to the selected private
    # layer.  At Save/toggle boundaries the public master must not be inverse-
    # solved back into that layer, because it is a flattened projection and can
    # contain all lower PSD layers.  Flush the private layer session and discard
    # stale visible-master sessions.
    try:
        if _sps_bodypaint_direct_layer_write_active(material, channel, ctx):
            direct_changed = False
            try:
                large_or_lazy = False
                try:
                    from .core_operators import _sps_stack_is_large_or_lazy_for_add_layer as _sps_is_large
                    large_or_lazy = bool(_sps_is_large(material, channel))
                except Exception:
                    large_or_lazy = False
                if large_or_lazy:
                    direct_changed = bool(_mark_previous_native_private_if_dirty(material, channel)) or direct_changed
                    direct_changed = bool(_promote_dirty_layer_images_for_projection(material, channel)) or direct_changed
                else:
                    direct_changed = bool(capture_active_private_layer_pixels(material, channel, ctx, write_back=True)) or direct_changed
            except Exception:
                pass
            if not bool(locals().get('large_or_lazy', False)):
                try:
                    direct_changed = bool(_flush_direct_layer_session(material, channel, force=True, context=ctx)) or direct_changed
                except Exception:
                    direct_changed = bool(direct_changed)
            try:
                _MASTER_PAINT_SESSIONS.pop(key, None)
            except Exception:
                pass
            if direct_changed:
                try:
                    if bool(refresh_master):
                        write_composite_to_master(material, channel)
                    else:
                        for prop in (_stack_signature_prop(channel), 'sps_projection_cache_signature_' + channel):
                            try:
                                if prop in material:
                                    del material[prop]
                            except Exception:
                                pass
                except Exception:
                    pass
                try:
                    protect_layer_stack_pixels(material, channel)
                except Exception:
                    pass
            return bool(direct_changed)
    except Exception:
        pass

    def _commit_exact_visible_master_delta() -> bool:
        try:
            import numpy as np
            sess = _MASTER_PAINT_SESSIONS.get(key)
            master = _live_master_image_for_paint_commit(material, channel, _MASTER_PAINT_SESSIONS.get(key))
            if master is None:
                return False
            current = _image_array_np(master, use_cache=False)
            if current is None:
                return False
            baseline = None
            layers_snapshot = None
            layer_id = ''
            if isinstance(sess, dict):
                baseline = sess.get('baseline')
                layers_snapshot = sess.get('layers_snapshot')
                layer_id = str(sess.get('layer_id', '') or '')
            if baseline is None or getattr(baseline, 'shape', None) != getattr(current, 'shape', None):
                return False
            # Exact baselines are also created during ordinary target/display
            # synchronization.  During Save those baselines must not be treated
            # as proof of a brush stroke, otherwise the flattened preview can be
            # replayed into the active private layer and PSD export will contain
            # mixed/whitened layer pixels.  Commit an exact master delta only
            # when a native paint operator or an explicit Smart Paint pending
            # marker says the master is holding uncommitted paint.
            try:
                _save_delta_allowed = bool(force_untracked) or _sps_save_untracked_master_delta_allowed(material, channel, ctx)
            except Exception:
                _save_delta_allowed = bool(force_untracked)
            if not _save_delta_allowed:
                try:
                    # Save is a correctness boundary.  Exact master baselines are
                    # also created by harmless display synchronization, so they are
                    # not automatically paint.  However, when the current public
                    # master differs from the exact baseline only in a bounded,
                    # brush-like region and also differs from the current private
                    # stack projection, the master is the only copy of an unflushed
                    # Texture Paint stroke.  Commit that sparse delta even when a
                    # Blender paint operator token is unavailable, instead of saving
                    # a blank/white private layer.
                    _tol = 1.0 / 4096.0
                    _base_delta = np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1) > _tol
                    _changed_count = int(np.count_nonzero(_base_delta))
                    _total_count = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
                    _brush_like = bool(
                        _changed_count > 0
                        and _total_count > 0
                        and (
                            _changed_count <= 262144
                            or (_changed_count / float(_total_count)) <= 0.35
                        )
                    )
                    if not _brush_like:
                        return False
                    try:
                        _cw, _ch, _stack_probe = composite_layer_arrays(material, channel)
                    except Exception:
                        _stack_probe = None
                    if _stack_probe is None or getattr(_stack_probe, 'shape', None) != getattr(current, 'shape', None):
                        return False
                    _stack_delta = np.max(np.abs(current[:, :4] - _stack_probe[:, :4]), axis=1) > (2.0 / 255.0)
                    if not bool(np.any(_stack_delta)):
                        return False
                    _save_delta_allowed = True
                except Exception:
                    return False
            try:
                cached_current = _cached_image_array(master)
                if cached_current is None:
                    try:
                        m_name = str(getattr(master, 'name', '') or '')
                        m_w, m_h = _image_size(master)
                        best_cached = None
                        best_score = -1
                        for _ckey, _item in list(_IMAGE_ARRAY_CACHE.items()):
                            try:
                                if str(_ckey[0]) != m_name:
                                    continue
                                if tuple(_item.get('size', ())) != (int(m_w), int(m_h)):
                                    continue
                                cand = _item.get('arr')
                                if cand is None or getattr(cand, 'shape', None) != getattr(current, 'shape', None):
                                    continue
                                cand_delta = np.max(np.abs(cand[:, :4] - baseline[:, :4]), axis=1)
                                cand_vs_raw = np.max(np.abs(cand[:, :4] - current[:, :4]), axis=1)
                                if not bool(np.any(cand_delta > (1.0 / 4096.0))) or not bool(np.any(cand_vs_raw > (1.0 / 4096.0))):
                                    continue
                                changed = cand_delta > (1.0 / 4096.0)
                                changed_count = int(np.count_nonzero(changed))
                                score = changed_count
                                # Prefer a cache that looks like a bounded brush
                                # stroke over a full-canvas stale projection.  This
                                # fixes Texture Save losing active-layer paint when
                                # Blender replaces the file-backed master image just
                                # before the operator body starts.
                                try:
                                    total_px = int(current.shape[0])
                                    rgb = np.clip(cand[changed, :3], 0.0, 1.0) if bool(np.any(changed)) else cand[:, :3]
                                    colorfulness = float(np.mean(np.max(rgb, axis=1) - np.min(rgb, axis=1))) if rgb.size else 0.0
                                    bounded_bonus = 10000000 if changed_count <= max(16, int(total_px * 0.35)) else 0
                                    score = int(bounded_bonus + round(colorfulness * 100000.0) - changed_count)
                                except Exception:
                                    score = -changed_count
                                if score > best_score:
                                    best_score = score
                                    best_cached = cand
                            except Exception:
                                continue
                        cached_current = best_cached
                    except Exception:
                        cached_current = None
                if cached_current is not None and getattr(cached_current, 'shape', None) == getattr(current, 'shape', None):
                    cached_delta = np.max(np.abs(cached_current[:, :4] - baseline[:, :4]), axis=1)
                    raw_vs_cached = np.max(np.abs(cached_current[:, :4] - current[:, :4]), axis=1)
                    if bool(np.any(cached_delta > (1.0 / 4096.0))) and bool(np.any(raw_vs_cached > (1.0 / 4096.0))):
                        current = np.asarray(cached_current, dtype=np.float32).reshape(current.shape)
            except Exception:
                pass
            # A stale exact baseline can differ from the current master even
            # when the current master is already the correct projection of the
            # private layer stack.  Save must not replay such stale deltas into
            # the active layer.  Commit only when master != current stack.
            try:
                _cw, _ch, stack_comp = composite_layer_arrays(material, channel)
                if stack_comp is not None and getattr(stack_comp, 'shape', None) == getattr(current, 'shape', None):
                    stack_delta = np.max(np.abs(current[:, :4] - stack_comp[:, :4]), axis=1)
                    if not bool(np.any(stack_delta > (1.0 / 4096.0))):
                        return False
            except Exception:
                pass
            delta = np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1)
            delta_mask = delta > (1.0 / 4096.0)
            if not bool(np.any(delta_mask)):
                return False
            applied_layer_id = layer_id or _active_layer_id(material)
            try:
                if bool(_direct_commit_baseline_master_delta_to_active_layer_for_save(
                    material,
                    channel,
                    applied_layer_id,
                    baseline,
                    current,
                    delta_mask,
                    tolerance=(1.0 / 4096.0),
                    reason='safe_exact_session',
                )):
                    return True
            except Exception:
                pass
            applied = bool(_apply_master_delta_to_layer(
                material,
                channel,
                applied_layer_id,
                baseline,
                current,
                tolerance=(1.0 / 4096.0),
                layers_snapshot=layers_snapshot,
            ))
            if applied:
                # Texture Save may be invoked through an operator wrapper before
                # the PSD writer.  Mark/protect the just-updated private layer so
                # later save preflight, stack snapshots, or restoration code cannot
                # restore the old blank layer from the previous internal document.
                try:
                    _layer_obj, _img_obj = _layer_image_for_session(material, applied_layer_id, channel)
                    if _img_obj is not None:
                        _arr_obj = _image_array_np(_img_obj, use_cache=False)
                        if _arr_obj is not None:
                            _mark_image_pixels_changed(_img_obj, _arr_obj)
                        _img_obj['smart_paint_suite_dirty_from_master'] = True
                        _img_obj['smart_paint_suite_alpha_authoritative'] = True
                        _img_obj['smart_paint_suite_save_exact_master_delta'] = True
                except Exception:
                    pass
                try:
                    protect_layer_stack_pixels(material, channel)
                except Exception:
                    pass
                try:
                    _MASTER_PAINT_SESSIONS.pop(key, None)
                except Exception:
                    pass
            return bool(applied)
        except Exception:
            return False

    def _commit_untracked_master_delta(*, force: bool = False) -> bool:
        try:
            recent = bool(_recent_operator_was_paint())
        except Exception:
            recent = False
        if not (force or _sps_save_untracked_master_delta_allowed(material, channel, context)):
            return False
        try:
            master = _live_master_image_for_paint_commit(material, channel, _MASTER_PAINT_SESSIONS.get(key))
            pixels = 0
            if master is not None:
                mw, mh = _image_size(master)
                pixels = int(mw) * int(mh)
            try:
                selection_active = bool(has_selection_mask(material, channel))
            except Exception:
                selection_active = False
            paint_like_delta = False
            try:
                # Without an exact captured baseline, the public master may already
                # be a correct composited preview.  Recover only when the master
                # differs from the current stack in a brush-like dirty region.
                # This preserves strokes that reached the public Texture Paint
                # target before the live timer ran, while avoiding the old
                # small-document fallback that flattened masks/groups or other
                # visible layers into the active layer during Save.
                np = _np_module()
                if np is not None and master is not None:
                    current = _image_array_np(master, use_cache=False)
                    _cw, _ch, composite = composite_layer_arrays(material, channel)
                    if current is not None and composite is not None and getattr(current, 'shape', None) == getattr(composite, 'shape', None):
                        delta = np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1)
                        changed_count = int(np.count_nonzero(delta > (1.0 / 4096.0)))
                        total_count = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
                        if changed_count > 0 and total_count > 0:
                            # Brush strokes and small fill edits are sparse.  If
                            # nearly the whole document differs, it is more likely
                            # a stale projection/cache mismatch than uncommitted
                            # active-layer paint.
                            paint_like_delta = bool((changed_count <= 262144) or ((changed_count / float(total_count)) <= 0.35))
            except Exception:
                paint_like_delta = False
            if not (force or recent or selection_active or paint_like_delta):
                return False
            saved_session = _MASTER_PAINT_SESSIONS.pop(key, None)
            try:
                layer_id = ''
                try:
                    if isinstance(saved_session, dict):
                        layer_id = str(saved_session.get('layer_id', '') or '')
                except Exception:
                    layer_id = ''
                return bool(commit_untracked_master_paint_to_active_layer(
                    material,
                    channel,
                    allow_session=True,
                    layer_id_override=layer_id or _active_layer_id(material),
                    tolerance=(1.0 / 4096.0),
                ))
            finally:
                try:
                    if saved_session is not None and key not in _MASTER_PAINT_SESSIONS:
                        _MASTER_PAINT_SESSIONS[key] = saved_session
                except Exception:
                    pass
        except Exception:
            return False

    if bool(force_untracked):
        try:
            # If the live-paint session signature is stale, the exact baseline
            # branch can replay a projected/white value and lose the active brush
            # pixels.  In that specific save-boundary case, compare the current
            # visible master against the current stack first and recover only the
            # unresolved delta into the active layer.  Non-stale exact sessions
            # continue through the inverse solver below.
            _sess = _MASTER_PAINT_SESSIONS.get(key)
            _cur_sig = _master_session_stack_signature(material, channel)
            _old_sig = str(_sess.get('stack_signature', '') or '') if isinstance(_sess, dict) else ''
            _stale_for_save = bool(_old_sig and _cur_sig and _old_sig != _cur_sig)
            if _stale_for_save:
                changed = bool(_force_commit_visible_master_delta_to_active_layer_for_save(material, channel, tolerance=(2.0 / 255.0), force=True)) or changed
        except Exception:
            pass

    if not bool(changed):
        try:
            # 1) Preserve Blender-native paint that exists only on the public master.
            changed = bool(_commit_exact_visible_master_delta()) or changed
        except Exception:
            pass

    visible_master_committed = bool(changed)
    if not visible_master_committed:
        try:
            # 2) Save-specific recovery must run before direct-session cleanup.  Some
            # direct-session cleanup paths rebuild the public projection and would erase
            # the only copy of a just-painted visible-master stroke.
            visible_master_committed = bool(_force_commit_visible_master_delta_to_active_layer_for_save(material, channel, tolerance=(2.0 / 255.0)))
            changed = visible_master_committed or changed
        except Exception:
            visible_master_committed = False

    if visible_master_committed:
        try:
            # A visible-master stroke has just been written into the selected
            # private layer.  UI target/status callbacks may immediately ask the
            # direct-layer synchronizer to flush an older direct session; that stale
            # session must be re-armed from the committed pixels, not replayed.
            material['sps_visible_master_committed_guard_' + channel] = True
        except Exception:
            pass

    if not visible_master_committed:
        try:
            # 3) Preserve direct private-layer paint only when no visible-master
            # save recovery was needed.  This prevents stale direct sessions from
            # overwriting the active layer that has just received the Save delta.
            changed = bool(_flush_direct_layer_session(material, channel, force=False, context=ctx)) or changed
        except Exception:
            pass

    if not changed:
        try:
            # 4) If there was no exact baseline/session, compare the visible master
            # against the current stack and transfer the difference to the intended
            # active layer before serializing PSD records.
            changed = bool(_commit_untracked_master_delta(force=bool(force_untracked))) or changed
        except Exception:
            pass

    if changed:
        if bool(refresh_master):
            try:
                write_composite_to_master(material, channel)
            except Exception:
                pass
        else:
            try:
                for prop in (_stack_signature_prop(channel), 'sps_projection_cache_signature_' + _safe_channel(channel)):
                    try:
                        if prop in material:
                            del material[prop]
                    except Exception:
                        pass
            except Exception:
                pass
        try:
            protect_layer_stack_pixels(material, channel)
        except Exception:
            pass
    return bool(changed)


def _promote_dirty_master_rgb_to_alpha(material, channel: str = 'BASE_COLOR') -> bool:
    """Make save-recovered RGB brush pixels visible on their source layer.

    Some Blender Texture Paint paths and some GPU/readback races leave RGB paint
    in the private layer while alpha remains zero.  These pixels are not hidden
    artist data: they are marked as coming from a visible-master paint recovery,
    and must be serialized as actual layer paint instead of becoming a blank
    white/transparent PSD layer.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    channel = _safe_channel(channel)
    changed = False
    try:
        width, height, layers = collect_layers(material, channel)
    except Exception:
        return False
    for item in list(layers or []):
        image = item.get('image') if isinstance(item, dict) else None
        if image is None:
            continue
        try:
            marked = bool(image.get('smart_paint_suite_dirty_from_master', False)) or bool(image.get('smart_paint_suite_save_forced_master_delta', False))
        except Exception:
            marked = False
        if not marked:
            continue
        arr = _image_array_np(image, use_cache=False)
        if arr is None or getattr(arr, 'shape', None) is None or int(arr.shape[1]) < 4:
            continue
        out = np.asarray(arr, dtype=np.float32).reshape((-1, 4)).copy()
        try:
            # Once a layer has real authoritatively recovered brush alpha, Save must
            # not promote neighbouring RGB-only transparent rows to alpha=1.  That
            # was repeatedly inflating soft brush edges on save, especially for
            # materialized lazy layers larger than the proxy threshold.
            if bool(image.get('smart_paint_suite_alpha_authoritative', False)) and bool(np.any(out[:, 3] > (2.0 / 255.0))):
                continue
        except Exception:
            pass
        try:
            clear = image.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0))
            clear_rgb = np.asarray(tuple(float(v) for v in clear[:3]), dtype=np.float32).reshape((1, 3))
        except Exception:
            clear_rgb = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
        tol = 2.0 / 255.0
        rgb_visible = np.max(np.abs(out[:, :3] - clear_rgb), axis=1) > tol
        alpha_zero = out[:, 3] <= tol
        mask = np.logical_and(rgb_visible, alpha_zero)
        if not bool(np.any(mask)):
            continue
        try:
            total_px = int(out.shape[0])
            mask_count = int(np.count_nonzero(mask))
            raw_count = int(np.count_nonzero(out[:, 3] > tol))
            mask_ratio = float(mask_count) / float(max(1, total_px))
            # Never promote a broad transparent clear field merely because its
            # stored RGB differs from stale clear-color metadata.  That was the
            # direct cause of PSD layers becoming full-canvas opaque black/white
            # after Save.  RGB-only recovery is for bounded brush deltas; real
            # alpha already remains authoritative for existing painted pixels.
            if raw_count > 0 and mask_ratio > 0.35:
                continue
            if raw_count <= 0 and mask_ratio > 0.35 and not bool(image.get('smart_paint_suite_export_rgb_alpha_fallback', False)):
                continue
        except Exception:
            pass
        # Preserve continuous brush coverage instead of promoting every RGB-only
        # touched pixel to fully opaque alpha.  This path is a compatibility
        # fallback for marked save-recovered pixels only.
        try:
            rgb_delta_amount = np.max(np.abs(out[:, :3] - clear_rgb), axis=1)
            promoted_alpha = np.clip(rgb_delta_amount * 1.5, 0.0, 1.0).astype(np.float32, copy=False)
            out[mask, 3] = np.maximum(out[mask, 3], promoted_alpha[mask])
        except Exception:
            out[mask, 3] = np.maximum(out[mask, 3], 1.0 / 255.0)
        if bool(_write_image_array_np(image, out)):
            changed = True
            try:
                image['smart_paint_suite_alpha_authoritative'] = True
                image['smart_paint_suite_rgb_alpha_promoted_for_save'] = True
            except Exception:
                pass
    return bool(changed)


# -----------------------------------------------------------------------------
# Photoshop-style live paint target support
# -----------------------------------------------------------------------------
# Blender Texture Paint can only write to one Image data-block at a time.  Smart
# Paint keeps a stable visible document image and commits private-layer edits only
# at explicit operator/stroke/save boundaries.  No live scanner, heartbeat or
# repeating timer is used.

_MASTER_PAINT_SESSIONS = _sps_quota.cache('paint.master_sessions')
_SAVE_MASTER_BASELINE_CACHE = _sps_quota.cache('paint.save_master_baseline')
_MASTER_TIMER_RUNNING = False
_MASTER_TIMER_INTERVAL = 0.0
_MASTER_LIVE_EXACT_BASELINE_PIXEL_LIMIT = 4096 * 4096
_SELECTION_EXACT_BASELINE_PIXEL_LIMIT = 2048 * 2048
_SELECTION_MASK_IMAGE_WRITE_PIXEL_LIMIT = 2048 * 2048
_SELECTION_STENCIL_MAX_DIMENSION = 512
_SELECTION_MASK_CACHE = _sps_quota.cache('paint.selection_mask')
_SELECTION_LIVE_TIMER_REQUESTED = False

_DIRECT_LAYER_PAINT_TIMER_RUNNING = False
_DIRECT_LAYER_PAINT_INTERVAL_ACTIVE = 0.0
_DIRECT_LAYER_PAINT_INTERVAL_IDLE = 0.0
_DIRECT_LAYER_PAINT_SESSIONS = _sps_quota.cache('paint.direct_layer_sessions')
# Exact direct-layer baselines up to this size allow brush-sized dirty-region
# projection instead of full-stack recomposition after every stroke.
_DIRECT_LAYER_DIRTY_REGION_BASELINE_PIXEL_LIMIT = 2048 * 2048
_LAZY_WRITE_SLOT_JOBS = set()
_LAZY_WRITE_SLOT_TIMER_RUNNING = False
_SPS_PENDING_STATUS_FLAGS = set()

# One-shot UI/display repair for Blender Image Editor/Texture Paint contexts.
# Some native operators update the active Image Editor image after our operator
# has finished.  A deferred pass re-applies the invariant without registering a
# permanent timer: Image Editor, Image Paint canvas, material paint slot and 3D
# View all point at the same composited master texture.
_DEFERRED_MASTER_VIEW_SYNC = set()
_DEFERRED_MASTER_VIEW_TIMER_RUNNING = False
_MASTER_TIMER_IDLE_TICKS = 0
_DIRECT_LAYER_PAINT_IDLE_TICKS = 0
_DIRECT_LAYER_PAINT_HEARTBEAT_RUNNING = False
_DIRECT_LAYER_PAINT_HANDLER_RUNNING = False


def _sps_paint_idle_stop_after_ticks(selection_active: bool = False) -> int:
    del selection_active
    return 0


def _sps_strict_zero_idle_enabled() -> bool:
    try:
        from . import performance_governor as _sps_perf
        return bool(getattr(_sps_perf, 'strict_zero_idle_enabled', lambda: True)())
    except Exception:
        return True



def _sps_resource_burst_scope(kind: str = 'paint_sync'):
    try:
        from . import performance_governor as _sps_perf
        return _sps_perf.burst_scope(kind)
    except Exception:
        try:
            from contextlib import nullcontext
            return nullcontext()
        except Exception:
            class _Null:
                def __enter__(self): return self
                def __exit__(self, exc_type, exc, tb): return False
            return _Null()


def _sps_mark_activity(kind: str = 'paint_sync') -> None:
    try:
        from . import performance_governor as _sps_perf
        _sps_perf.mark_activity(kind)
    except Exception:
        pass


def _trace_paint_busy(event: str, **payload) -> None:
    try:
        root = os.environ.get('SPS_TEST_ROOT', '')
        if not root:
            return
        log_dir = os.path.join(root, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        record = {
            'ts': time.time(),
            'event': str(event or ''),
            'direct_sessions': int(len(_DIRECT_LAYER_PAINT_SESSIONS)),
            'master_sessions': int(len(_MASTER_PAINT_SESSIONS)),
            'direct_timer_running': bool(_DIRECT_LAYER_PAINT_TIMER_RUNNING),
            'direct_idle_ticks': int(_DIRECT_LAYER_PAINT_IDLE_TICKS),
            'master_timer_running': bool(_MASTER_TIMER_RUNNING),
        }
        try:
            ctx = getattr(bpy, 'context', None)
            obj = getattr(ctx, 'object', None) if ctx is not None else None
            record['object_mode'] = str(getattr(obj, 'mode', '') or '') if obj is not None else ''
        except Exception:
            pass
        payload.pop('stack', None)
        record.update(payload)
        with open(os.path.join(log_dir, 'sps_paint_busy_trace.jsonl'), 'a', encoding='utf-8') as handle:
            handle.write(json.dumps(record, ensure_ascii=False, default=str, sort_keys=True) + '\n')
    except Exception:
        pass


def _sps_active_timer_interval() -> float:
    return 0.0


def _sps_begin_pending_status(kind: str) -> None:
    key = str(kind or 'paint_sync')
    try:
        if key in _SPS_PENDING_STATUS_FLAGS:
            return
        _SPS_PENDING_STATUS_FLAGS.add(key)
        from . import performance_governor as _sps_perf
        _sps_perf.begin_pending_job(key)
    except Exception:
        pass


def _sps_finish_pending_status(kind: str) -> None:
    key = str(kind or 'paint_sync')
    try:
        if key not in _SPS_PENDING_STATUS_FLAGS:
            return
        _SPS_PENDING_STATUS_FLAGS.discard(key)
        from . import performance_governor as _sps_perf
        _sps_perf.finish_pending_job(key)
    except Exception:
        pass


def _sps_allow_timer_scope(kind: str):
    try:
        from . import performance_governor as _sps_perf
        return _sps_perf.allow_timer_scope(kind)
    except Exception:
        try:
            from contextlib import nullcontext
            return nullcontext()
        except Exception:
            class _Null:
                def __enter__(self): return self
                def __exit__(self, exc_type, exc, tb): return False
            return _Null()


def _sps_texture_paint_context_active(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        obj = getattr(ctx, 'object', None) if ctx is not None else None
        return bool(obj is not None and getattr(obj, 'mode', '') == 'TEXTURE_PAINT')
    except Exception:
        return False


def _sps_register_direct_layer_paint_timer() -> bool:
    """Compatibility API: direct paint is committed only at explicit boundaries.

    Smart Paint 1.9.277 never registers a repeating direct-paint timer.  Layer
    baselines remain available for an explicit Save/Review/stack operator, which
    performs one transaction and one Undo boundary.
    """
    global _DIRECT_LAYER_PAINT_TIMER_RUNNING
    _DIRECT_LAYER_PAINT_TIMER_RUNNING = False
    _sps_finish_pending_status('direct_layer_paint_sync')
    return False


def _scene_layer_all_layers_enabled(context=None) -> bool:
    # The legacy All Layers Target mode is retired.  Flattened public/master
    # textures are display caches only; native strokes and destructive edits must
    # resolve to explicit layer buffers.
    return False



def _sps_operation_optimization_active(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is None:
            return False
        for name in (
            'sps_operation_optimization_active_v1950',
            'sps_layer_stack_fast_mode_v1950',
            'sps_operation_optimization_active_v1944',
            'sps_layer_stack_fast_mode_v1944',
        ):
            try:
                if bool(getattr(scene, name, False)) or bool(scene.get(name, False)):
                    return True
            except Exception:
                pass
        try:
            from . import performance_governor as _sps_perf
            return bool(_sps_perf.active())
        except Exception:
            return False
    except Exception:
        return False

def _active_layer_private_image(material, channel: str = 'BASE_COLOR'):
    try:
        layer, image = _active_layer_image_for_material(material, channel)
    except Exception:
        layer = image = None
    if layer is None or image is None:
        return None
    try:
        if bool(image.get('smart_paint_suite_master_texture')):
            ensure_private_layer_images(material, channel)
            layer, image = _active_layer_image_for_material(material, channel)
    except Exception:
        pass
    return image


def _image_pixel_crc(image) -> tuple[int, int, int]:
    # Fast path: use a deterministic sample stamp.  Full image reads are handled
    # by commit_master_paint_session only when a real paint delta is likely.
    return _image_sample_stamp(image, 1024)



def _array_pixel_crc(arr, width: int = 0, height: int = 0) -> tuple[int, int, int]:
    try:
        import numpy as np, zlib
        a = np.asarray(arr, dtype=np.float32).reshape((-1, 4))
        if width <= 0 or height <= 0:
            n = int(a.shape[0])
            width = n
            height = 1
        return (int(width), int(height), int(zlib.crc32(a.tobytes()) & 0xffffffff))
    except Exception:
        return (int(width or 0), int(height or 0), 0)

def _delta_bbox_from_mask(mask, width: int, height: int, *, pad: int = 0):
    try:
        import numpy as np
        w = int(width); h = int(height)
        m = np.asarray(mask, dtype=bool).reshape((-1,))
        if w <= 0 or h <= 0 or m.size != w * h or not bool(np.any(m)):
            return None, 0
        idx = np.flatnonzero(m)
        ys = idx // w
        xs = idx - ys * w
        p = max(0, int(pad or 0))
        x0 = max(0, int(xs.min()) - p); x1 = min(w, int(xs.max()) + 1 + p)
        y0 = max(0, int(ys.min()) - p); y1 = min(h, int(ys.max()) + 1 + p)
        return (x0, y0, x1, y1), int(idx.size)
    except Exception:
        return None, 0


def _delta_bbox_from_arrays(before, after, width: int, height: int, tolerance: float = 1.0 / 4096.0, *, pad: int = 2):
    try:
        import numpy as np
        if before is None or after is None or getattr(before, 'shape', None) != getattr(after, 'shape', None):
            return None, 0
        b = np.asarray(before, dtype=np.float32).reshape((-1, 4))
        a = np.asarray(after, dtype=np.float32).reshape((-1, 4))
        mask = np.max(np.abs(a[:, :4] - b[:, :4]), axis=1) > float(tolerance)
        return _delta_bbox_from_mask(mask, int(width), int(height), pad=pad)
    except Exception:
        return None, 0


def _display_state_is_master(material, channel: str = 'BASE_COLOR', master=None) -> bool:
    try:
        channel = _safe_channel(channel)
        image = master or get_master_texture_image(material, channel, create=False)
        if material is None or image is None or not getattr(material, 'use_nodes', False):
            return False
        nt = getattr(material, 'node_tree', None)
        node = nt.nodes.get(_master_node_name(channel)) if nt is not None else None
        if node is None or getattr(node, 'type', '') != 'TEX_IMAGE' or getattr(node, 'image', None) != image:
            return False
        principled = _find_principled(material)
        socket = _socket_for_channel(principled, channel)
        if socket is None:
            return False
        for link in getattr(socket, 'links', ()) or ():
            try:
                if getattr(link, 'from_node', None) == node:
                    return True
            except Exception:
                pass
        return False
    except Exception:
        return False

def _refresh_master_paint_session_after_display(material, channel: str, master, *, force: bool = False) -> None:
    """Refresh paint-session metadata without reading the full master image.

    A full 4096/8192 texture read from this display-maintenance path is a
    visible freeze.  The session is therefore lazy: it records only a cheap
    sample stamp and the active destination layer.  Commit paths perform full
    reads only when a real paint delta is likely.
    """
    try:
        key = _session_key(material, channel)
        sample = _image_sample_stamp(master, 96) if master is not None else (0, 0, 0)
        session = _MASTER_PAINT_SESSIONS.get(key)
        if session is None or force:
            _MASTER_PAINT_SESSIONS[key] = {
                'baseline': None,
                'layer_id': _active_layer_id(material),
                'stamp': sample,
                'sample_stamp': sample,
                'lazy': True,
                'stack_signature': _master_session_stack_signature(material, channel),
            }
        else:
            session['layer_id'] = _active_layer_id(material)
            session['sample_stamp'] = sample
            session['stamp'] = sample
            session['lazy'] = True
            session['baseline'] = None
            _refresh_master_session_signature(session, material, channel)
    except Exception:
        pass


def clear_transient_paint_save_state(material=None, channel: str = 'BASE_COLOR') -> None:
    """Release explicit-operation paint/session caches after Save Texture.

    Smart Paint is intentionally zero-idle: once a user-triggered save finishes,
    no master-paint baselines or stale direct-layer sessions should remain and
    influence the next texture edited in the same Blender session.
    """
    try:
        ch = _safe_channel(channel)
    except Exception:
        ch = str(channel or 'BASE_COLOR').upper()
    mat_name = ''
    try:
        mat_name = str(getattr(material, 'name_full', '') or getattr(material, 'name', '') or '')
    except Exception:
        mat_name = ''
    try:
        if mat_name:
            _MASTER_PAINT_SESSIONS.pop((mat_name, ch), None)
            _DIRECT_LAYER_PAINT_SESSIONS.pop((mat_name, ch), None)
            _SAVE_MASTER_BASELINE_CACHE.pop((mat_name, ch), None)
        else:
            _MASTER_PAINT_SESSIONS.clear()
            _DIRECT_LAYER_PAINT_SESSIONS.clear()
            _SAVE_MASTER_BASELINE_CACHE.clear()
    except Exception:
        pass
    try:
        keys = []
        for _k in list(_MASTER_PAINT_SESSIONS.keys()):
            try:
                if (not mat_name or str(_k[0]) == mat_name) and (not ch or str(_k[1]).upper() == ch):
                    keys.append(_k)
            except Exception:
                pass
        for _k in keys:
            _MASTER_PAINT_SESSIONS.pop(_k, None)
    except Exception:
        pass
    try:
        keys = []
        for _k in list(_DIRECT_LAYER_PAINT_SESSIONS.keys()):
            try:
                if (not mat_name or str(_k[0]) == mat_name) and (not ch or str(_k[1]).upper() == ch):
                    keys.append(_k)
            except Exception:
                pass
        for _k in keys:
            _DIRECT_LAYER_PAINT_SESSIONS.pop(_k, None)
    except Exception:
        pass
    try:
        keys = []
        for _k in list(_SAVE_MASTER_BASELINE_CACHE.keys()):
            try:
                if (not mat_name or str(_k[0]) == mat_name) and (not ch or str(_k[1]).upper() == ch):
                    keys.append(_k)
            except Exception:
                pass
        for _k in keys:
            _SAVE_MASTER_BASELINE_CACHE.pop(_k, None)
    except Exception:
        pass
    try:
        prop = 'sps_save_baseline_image_' + ch
        base_name = str(material.get(prop, '') or '') if material is not None else ''
        if base_name:
            img = bpy.data.images.get(base_name)
            if img is not None and str(getattr(img, 'name', '') or '').startswith('SPS_SaveBaseline_'):
                bpy.data.images.remove(img)
            try:
                if prop in material:
                    del material[prop]
            except Exception:
                pass
    except Exception:
        pass
    try:
        if material is not None:
            for _prop in (
                'sps_save_force_untracked_commit_',
                'sps_texture_save_prepared_stack_',
                'sps_bodypaint_active_private_captured_for_save_',
                'sps_bodypaint_active_private_capture_time_',
            ):
                try:
                    _name = _prop + ch
                    if _name in material:
                        del material[_name]
                except Exception:
                    pass
    except Exception:
        pass
    try:
        _IMAGE_ARRAY_CACHE.clear()
    except Exception:
        pass
    try:
        _IMAGE_ARRAY_READ_SCOPE_CACHE.clear()
    except Exception:
        pass
    try:
        _COMPOSITE_ARRAY_CACHE.clear()
    except Exception:
        pass
    try:
        _SELECTION_MASK_CACHE.clear()
    except Exception:
        pass
    try:
        import gc as _sps_gc
        _sps_gc.collect()
    except Exception:
        pass

def _direct_session_key(material, channel: str = 'BASE_COLOR'):
    try:
        return (str(getattr(material, 'name', '') or ''), _safe_channel(channel))
    except Exception:
        return ('', _safe_channel(channel))


def _schedule_lazy_write_slot_materialization(material, channel: str, image) -> bool:
    """Do not decode a lazy PSD layer from a UI/property callback.

    Lazy layer pixels are materialized only by an explicit paint/open/edit
    operator (``materialize_lazy_psd_layer_image`` or BodyPaint target setup).
    The compatibility scheduler deliberately leaves the source image untouched
    and creates no timer, synchronous drain loop, or pending background job.
    """
    del material, channel, image
    return False


def _lazy_write_slot_materialize_timer():
    """Retired compatibility callback; never registered in 1.9.277+."""
    global _LAZY_WRITE_SLOT_TIMER_RUNNING
    _LAZY_WRITE_SLOT_TIMER_RUNNING = False
    _LAZY_WRITE_SLOT_JOBS.clear()
    _sps_finish_pending_status('lazy_write_slot')
    return None

def _set_image_paint_canvas_to_public_master(material, channel: str = 'BASE_COLOR', context=None) -> None:
    """Keep Image Editor/ImagePaint canvas on the composited document image.

    Blender's Material Texture Paint slot can be a hidden private layer image,
    but assigning ImagePaint.canvas to that private image makes the Image Editor
    and Texture Paint workspace look like only the active layer exists.  Smart
    Paint's invariant is: private image = write target, public master = view.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            try:
                master = _find_document_file_image(material, channel)
            except Exception:
                master = None
        if master is None:
            try:
                name = str(material.get('sps_visible_master_image_' + _safe_channel(channel), '') or '')
                master = bpy.data.images.get(name) if name else None
            except Exception:
                master = None
        if master is None:
            return
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        if ip is not None:
            try:
                ip.mode = 'MATERIAL'
            except Exception:
                pass
            try:
                if hasattr(ip, 'canvas'):
                    ip.canvas = master
            except Exception:
                pass
        try:
            from .core_operators import _show_image_in_image_editors
            _show_image_in_image_editors(ctx, master)
        except Exception:
            pass
        try:
            material['sps_visible_master_image_' + _safe_channel(channel)] = master.name
            material['sps_document_target_image_' + _safe_channel(channel)] = master.name
        except Exception:
            pass
    except Exception:
        pass

def _set_image_paint_canvas_to_private_layer(material, channel: str = 'BASE_COLOR', image=None, context=None) -> bool:
    """Record the selected Smart Paint layer without replacing the visible canvas.

    Smart Paint's direct brush operator writes to the private layer.  Setting
    ImagePaint.canvas here makes the Image Editor show that private layer PNG
    instead of the Photoshop-style composited document.
    """
    try:
        ch = _safe_channel(channel)
        if image is None:
            try:
                _layer, image = _active_layer_image_for_material(material, ch)
            except Exception:
                image = None
        if material is None or image is None:
            return False
        try:
            if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_visible_document', False)):
                return False
        except Exception:
            pass
        ctx = context or getattr(bpy, 'context', None)
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        ok = False
        if ip is not None:
            try:
                ip.mode = 'MATERIAL'
                ok = True
            except Exception:
                pass
        try:
            material['sps_active_private_layer_image_' + ch] = image.name
            material['sps_native_write_image_' + ch] = image.name
            material['sps_enable_direct_paint_timer_' + ch] = False
        except Exception:
            pass
        try:
            notify_active_private_layer_bound(
                material,
                ch,
                image,
                route='psd_io._set_image_paint_canvas_to_private_layer',
                reason='private_canvas_bind',
            )
        except Exception:
            pass
        try:
            scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
            if scene_settings is not None:
                scene_settings.active_paint_material = material
                scene_settings.active_paint_image = image
        except Exception:
            pass
        return bool(ok)
    except Exception:
        return False

def _direct_layer_session_baseline(material, channel: str, image):
    """Capture a baseline for direct layer painting when it is useful.

    The baseline is required for selection clipping and for distinguishing a real
    erase-to-transparent stroke from an RGB-only paint stroke whose alpha was not
    written by Blender.  To avoid huge allocations on very large textures without
    a selection, baseline capture is skipped unless a selection exists or the
    image is reasonably small.
    """
    try:
        if image is None:
            return None
        w, h = _image_size(image)
        pixels = int(max(0, w) * max(0, h))
        # Selection correctness has priority: Blender native 3D Texture Paint
        # can write outside the Smart Paint document-space selection.  The only
        # reliable way to remove those pixels after the stroke is to preserve an
        # exact pre-stroke baseline.  Capture it once per selection version /
        # active layer session, not on every redraw.
        try:
            if has_selection_mask(material, channel):
                return _image_array_np(image, use_cache=False)
        except Exception:
            pass
        # Without a Smart Paint selection, capture an exact baseline for moderate
        # documents.  This costs one bounded read when native painting is armed, but
        # it lets brush strokes update only their dirty rectangle instead of forcing
        # a full-stack projection after every stroke.  Larger 4K/8K documents keep
        # the sparse-stamp path and use the deferred burst projector.
        if pixels > 0 and pixels <= _DIRECT_LAYER_DIRTY_REGION_BASELINE_PIXEL_LIMIT:
            return _image_array_np(image, use_cache=False)
        return None
    except Exception:
        pass
    return None


def _direct_layer_paint_timer():
    """Retired compatibility callback; never repeats or self-registers."""
    global _DIRECT_LAYER_PAINT_TIMER_RUNNING, _DIRECT_LAYER_PAINT_IDLE_TICKS
    _DIRECT_LAYER_PAINT_TIMER_RUNNING = False
    _DIRECT_LAYER_PAINT_IDLE_TICKS = 0
    _sps_finish_pending_status('direct_layer_paint_sync')
    return None



def _direct_layer_paint_heartbeat_timer():
    """Retired compatibility callback; no heartbeat or periodic wake remains."""
    global _DIRECT_LAYER_PAINT_HEARTBEAT_RUNNING
    _DIRECT_LAYER_PAINT_HEARTBEAT_RUNNING = False
    return None



def _direct_layer_paint_depsgraph_handler(_scene=None, _depsgraph=None):
    global _DIRECT_LAYER_PAINT_HANDLER_RUNNING
    if _DIRECT_LAYER_PAINT_HANDLER_RUNNING:
        _trace_paint_busy('direct_depsgraph_skip_reentrant')
        return None
    try:
        if not _DIRECT_LAYER_PAINT_SESSIONS:
            _trace_paint_busy('direct_depsgraph_skip_no_sessions')
            return None
        _DIRECT_LAYER_PAINT_HANDLER_RUNNING = True
        _trace_paint_busy('direct_depsgraph_entry')
        try:
            _direct_layer_paint_timer()
        except Exception:
            pass
    finally:
        _DIRECT_LAYER_PAINT_HANDLER_RUNNING = False
        _trace_paint_busy('direct_depsgraph_exit')
    return None


def _deferred_master_view_sync_timer():
    """Retired compatibility callback; display repair is operation-local."""
    global _DEFERRED_MASTER_VIEW_TIMER_RUNNING
    _DEFERRED_MASTER_VIEW_SYNC.clear()
    _DEFERRED_MASTER_VIEW_TIMER_RUNNING = False
    _sps_finish_pending_status('master_view_sync')
    return None



def schedule_deferred_master_view_sync(material, channel: str = 'BASE_COLOR') -> None:
    """Retained API with zero deferred work.

    The caller has already rebound the master display and tagged redraw.  A
    delayed callback previously repeated the same RNA mutations after native UI
    updates.  It is intentionally retired so UI/update paths create no timer or
    pending background job.
    """
    del material, channel
    global _DEFERRED_MASTER_VIEW_TIMER_RUNNING
    _DEFERRED_MASTER_VIEW_SYNC.clear()
    _DEFERRED_MASTER_VIEW_TIMER_RUNNING = False
    _sps_finish_pending_status('master_view_sync')



def image_for_image_editor_display(context, image):
    """Return the image that should be visible in Image Editors.

    Visibility is now always the composited document/master image passed by the
    caller.  Active-layer isolation is handled by the material paint slot and
    direct-layer session, not by replacing the editor display image.
    """
    return image


def _tag_paint_views_redraw(context=None) -> None:
    try:
        ctx = context or getattr(bpy, 'context', None)
        screen = getattr(ctx, 'screen', None) if ctx is not None else None
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR'}:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass

_CHANNEL_SOCKET_NAMES = {
    'BASE_COLOR': ('Base Color', 'Color'),
    'ROUGHNESS': ('Roughness',),
    'METALLIC': ('Metallic',),
    'NORMAL': ('Normal',),
    'EMISSION': ('Emission Color', 'Emission'),
    'ALPHA': ('Alpha',),
    'HEIGHT': ('Height',),
    'AO': ('Ambient Occlusion', 'AO'),
}


def _np_module():
    try:
        import numpy as np
        return np
    except Exception:
        return None


def _image_array_np(image, *, use_cache: bool = True):
    np = _np_module()
    if np is None or image is None:
        return None
    try:
        authoritative = bool(smart_paint_layer_image_has_authoritative_user_pixels(image))
    except Exception:
        authoritative = False
    try:
        if bool(image.get('smart_paint_suite_lazy_psd_pending', False)) and not authoritative:
            # Explicit full-array read means the caller really needs pixels.
            # Materialize one layer on demand instead of reading a 1x1 proxy as
            # if it were 4096x4096.
            materialize_lazy_psd_layer_image(image)
    except Exception:
        pass
    try:
        bypass_cache = False
        try:
            bypass_cache = bool(
                getattr(image, 'is_dirty', False)
                or image.get('smart_paint_suite_alpha_authoritative', False)
                or image.get('smart_paint_suite_dirty_from_master', False)
                or image.get('smart_paint_suite_exact_fallback_commit', False)
                or image.get('smart_paint_suite_save_exact_master_delta', False)
                or image.get('smart_paint_suite_direct_layer_dirty', False)
                or image.get('smart_paint_suite_bodypaint_direct_authoritative', False)
                or image.get('smart_paint_suite_painted_since_last_projection', False)
                or image.get('smart_paint_suite_user_edited', False)
                or image.get('smart_paint_suite_dirty_bbox', False)
            )
        except Exception:
            bypass_cache = False
        if use_cache and not bypass_cache:
            cached = _cached_image_array(image)
            if cached is not None:
                return cached
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return None
        try:
            sparse_canvas = _sps_sparse_rgba_patch_to_canvas(image, int(w), int(h))
            if sparse_canvas is not None:
                if use_cache:
                    _cache_image_array(image, sparse_canvas)
                _store_read_scope_item(image, sparse_canvas)
                return sparse_canvas
        except Exception:
            pass
        # New large transparent layers are stored as 1x1 lazy proxies until the
        # first stroke.  A normal full-array read must see the declared document
        # canvas, not fail by trying to read 4096x4096 floats from a 1x1 Blender
        # image.  This is the critical path behind Texture > Save and visibility
        # toggles: before committing a master-paint delta, the active layer needs a
        # real transparent source array.
        try:
            try:
                dirty_pixels = bool(getattr(image, 'is_dirty', False))
            except Exception:
                dirty_pixels = False
            known_blank = bool(image.get('smart_paint_suite_lazy_blank_layer', False)) and not dirty_pixels
            if known_blank:
                clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
                rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
                arr = np.empty((int(w) * int(h), 4), dtype=np.float32)
                arr[:, 0] = rgba[0]; arr[:, 1] = rgba[1]; arr[:, 2] = rgba[2]; arr[:, 3] = rgba[3]
                if use_cache:
                    _cache_image_array(image, arr)
                _store_read_scope_item(image, arr)
                return arr
        except Exception:
            pass
        if use_cache:
            scoped = _read_scope_item(image)
            if scoped is not None:
                return scoped
        actual_w = actual_h = 0
        try:
            actual_w, actual_h = int(image.size[0]), int(image.size[1])
        except Exception:
            actual_w, actual_h = int(w), int(h)
        try:
            if actual_w <= 0 or actual_h <= 0:
                return None
            buf = np.empty(actual_w * actual_h * 4, dtype=np.float32)
            image.pixels.foreach_get(buf)
            arr2 = np.clip(buf.reshape((actual_h, actual_w, 4)), 0.0, 1.0)
            if int(actual_w) != int(w) or int(actual_h) != int(h):
                ys = (np.linspace(0, max(0, actual_h - 1), int(h))).astype(np.int64)
                xs = (np.linspace(0, max(0, actual_w - 1), int(w))).astype(np.int64)
                arr2 = arr2[ys][:, xs]
            arr = np.clip(arr2.reshape((int(w) * int(h), 4)), 0.0, 1.0).astype(np.float32, copy=False)
        except Exception:
            return None
        if use_cache:
            _cache_image_array(image, arr)
        _store_read_scope_item(image, arr)
        return arr
    except Exception:
        return None


def _write_image_array_np(image, arr) -> bool:
    np = _np_module()
    if np is None or image is None or arr is None:
        return False
    try:
        shaped = np.clip(arr, 0.0, 1.0).astype(np.float32, copy=False).reshape((-1, 4))
        pixel_count = int(shaped.shape[0])
        # If this layer is still a 1x1 lazy blank proxy, the first real write must
        # expand the Blender image datablock to the declared canvas size before
        # foreach_set.  Without this, the write silently fails and PSD save exports
        # a white/empty layer.
        try:
            actual_count = int(image.size[0]) * int(image.size[1])
        except Exception:
            actual_count = pixel_count
        if actual_count != pixel_count:
            try:
                w, h = _image_size(image)
                if int(w) * int(h) != pixel_count:
                    # Prefer declared canvas metadata on lazy/new layers even if
                    # the memory-saving empty flag was already removed before the
                    # first write.  Falling back directly to the 1px proxy width
                    # infers a 1xN image and corrupts brush strokes into stripes.
                    declared = None
                    try:
                        lw = int(image.get('smart_paint_suite_lazy_width', 0) or 0)
                        lh = int(image.get('smart_paint_suite_lazy_height', 0) or 0)
                        if lw > 0 and lh > 0 and lw * lh == pixel_count:
                            declared = (lw, lh)
                    except Exception:
                        declared = None
                    if declared is None:
                        try:
                            cs = image.get('smart_paint_suite_clear_initialized_size', None)
                            if cs is not None and len(cs) >= 2:
                                cw = int(cs[0]); ch = int(cs[1])
                                if cw > 0 and ch > 0 and cw * ch == pixel_count:
                                    declared = (cw, ch)
                        except Exception:
                            declared = None
                    if declared is not None:
                        w, h = declared
                    else:
                        # Fallback for legacy buffers without lazy metadata.
                        aw = max(1, int(getattr(image, 'size', (pixel_count, 1))[0] or pixel_count))
                        if aw <= 4 and pixel_count > 4096:
                            aw = pixel_count
                        if pixel_count % aw == 0:
                            w, h = aw, pixel_count // aw
                        else:
                            w, h = pixel_count, 1
                if int(image.size[0]) != int(w) or int(image.size[1]) != int(h):
                    image.scale(max(1, int(w)), max(1, int(h)))
            except Exception:
                pass
        try:
            _rw = int(image.size[0]); _rh = int(image.size[1])
            if _rw > 0 and _rh > 0 and int(_rw) * int(_rh) == pixel_count:
                try:
                    _is_public_display_target = bool(
                        image.get('smart_paint_suite_master_texture', False)
                        or image.get('smart_paint_suite_visible_document', False)
                        or image.get('smart_paint_suite_projection_stage', False)
                    )
                except Exception:
                    _is_public_display_target = False
                # Public PSD projections are flattened display/paint targets and
                # are forced opaque below.  Running the straight-alpha fringe
                # repair over every full 2K/4K public master during each layer
                # visibility toggle is unnecessary and can stall Blender.
                # Keep the repair for private layer buffers and export paths,
                # where soft-alpha RGB correction is actually required.
                try:
                    _skip_live_repair = bool(
                        image.get('smart_paint_suite_direct_layer_write_target', False)
                        or image.get('smart_paint_suite_bodypaint_direct_authoritative', False)
                        or image.get('smart_paint_suite_skip_live_fringe_repair', False)
                    )
                except Exception:
                    _skip_live_repair = False
                if not _is_public_display_target and not _skip_live_repair:
                    shaped = _sps_repair_straight_alpha_rgb_fringes(shaped, width=_rw, height=_rh)
                shaped = _sps_prepare_public_master_rgba_for_blender_display(image, shaped)
                if (not _is_public_display_target) and _skip_live_repair:
                    # Direct-layer brush writes are layer-local source pixels.
                    # Store a bounded authoritative patch immediately so visibility
                    # toggles and Save do not have to synchronously read the whole
                    # Blender Image datablock from RNA callbacks.
                    try:
                        clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
                        cr = np.asarray([float(clear[0]), float(clear[1]), float(clear[2])], dtype=np.float32).reshape((1, 3))
                    except Exception:
                        cr = np.asarray([1.0, 1.0, 1.0], dtype=np.float32).reshape((1, 3))
                    try:
                        _a = np.clip(shaped[:, 3], 0.0, 1.0)
                        _rgb_delta = np.max(np.abs(shaped[:, :3] - cr), axis=1) if shaped.size else np.zeros((0,), dtype=np.float32)
                        _mask = (_a > (1.0 / 4096.0)) | (_rgb_delta > (1.0 / 1024.0))
                        _rect, _cnt = _delta_bbox_from_mask(_mask, int(_rw), int(_rh), pad=2)
                        if _rect is not None:
                            x0, y0, x1, y1 = [int(v) for v in _rect]
                            image['smart_paint_suite_dirty_bbox'] = [x0, y0, x1, y1]
                            image['smart_paint_suite_dirty_pixel_count'] = int(_cnt or 0)
                            _patch_px = max(0, x1 - x0) * max(0, y1 - y0)
                            if _patch_px > 0 and _patch_px <= 2_000_000:
                                import base64 as _sps_b64, zlib as _sps_zlib
                                _layer_arr = np.asarray(shaped, dtype=np.float32).reshape((int(_rh), int(_rw), 4))
                                _patch = np.ascontiguousarray(_layer_arr[y0:y1, x0:x1, :], dtype=np.float32)
                                image['smart_paint_suite_sparse_rgba_patch_bbox'] = [x0, y0, x1, y1]
                                image['smart_paint_suite_sparse_rgba_patch_b64'] = _sps_b64.b64encode(_sps_zlib.compress(_patch.tobytes(), 6)).decode('ascii')
                                image['smart_paint_suite_authoritative_sparse_rgba_patch'] = True
                                image['smart_paint_suite_exact_top_sparse_commit'] = True
                                image['smart_paint_suite_patch_canvas_size'] = [int(_rw), int(_rh)]
                    except Exception:
                        pass
        except Exception:
            pass
        out = np.ascontiguousarray(shaped.reshape(-1), dtype=np.float32)
        try:
            image.alpha_mode = 'STRAIGHT'
        except Exception:
            pass
        image.pixels.foreach_set(out)
        image.update()
        _mark_image_pixels_changed(image, shaped)
        try:
            protect_layer_image_pixels(image, shaped)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _fill_image_color_np(image, rgba=(0.0, 0.0, 0.0, 0.0)) -> bool:
    """Fill a Blender image using a vectorized buffer instead of Python lists."""
    np = _np_module()
    if np is None or image is None:
        return False
    try:
        w, h = _image_size(image)
        if w <= 0 or h <= 0:
            return False
        rgba = tuple(float(v) for v in rgba)
        if len(rgba) < 4:
            rgba = (rgba[0] if rgba else 0.0, rgba[1] if len(rgba) > 1 else 0.0, rgba[2] if len(rgba) > 2 else 0.0, 1.0)
        arr = np.empty((int(w) * int(h), 4), dtype=np.float32)
        arr[:, 0] = rgba[0]; arr[:, 1] = rgba[1]; arr[:, 2] = rgba[2]; arr[:, 3] = rgba[3]
        return _write_image_array_np(image, arr)
    except Exception:
        return False


def _resize_image_to(image, width: int, height: int) -> None:
    if image is None:
        return
    try:
        if int(image.size[0]) != int(width) or int(image.size[1]) != int(height):
            image.scale(int(width), int(height))
            _mark_image_pixels_changed(image)
    except Exception:
        pass


def _materialize_lazy_blank_layer_for_write(image, width: int, height: int) -> bool:
    """Expand a 1x1 deferred transparent layer before real paint is written.

    New BASE_COLOR layers are deliberately created as 1x1 lazy transparent
    proxies for speed.  Native Texture Paint writes into the public composite
    master, and Save/visibility rebuild then transfers that delta back into the
    selected private layer.  If the private layer remains a 1x1 lazy proxy at
    that point, the transfer silently fails and PSD export writes a white/empty
    layer.  Materialize only the target layer being edited, fill it with its
    declared clear color, and clear the lazy/empty flags so the following write
    is authoritative.
    """
    np = _np_module()
    if np is None or image is None:
        return False
    try:
        width = max(1, int(width)); height = max(1, int(height))
    except Exception:
        return False
    try:
        lazy = bool(image.get('smart_paint_suite_lazy_blank_layer', False))
        lazy = bool(lazy or (int(image.size[0]) == 1 and int(image.size[1]) == 1 and (int(image.get('smart_paint_suite_lazy_width', 0) or 0) > 1 or int(image.get('smart_paint_suite_lazy_height', 0) or 0) > 1)))
        if not lazy and int(image.size[0]) == width and int(image.size[1]) == height:
            return False
    except Exception:
        lazy = False
    try:
        if int(image.size[0]) != width or int(image.size[1]) != height:
            image.scale(width, height)
        try:
            clear = image.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0))
            clear = tuple(float(v) for v in tuple(clear)[:4])
            if len(clear) < 4:
                clear = (clear[0] if len(clear) > 0 else 1.0, clear[1] if len(clear) > 1 else 1.0, clear[2] if len(clear) > 2 else 1.0, 0.0)
        except Exception:
            clear = (1.0, 1.0, 1.0, 0.0)
        arr = np.empty((width * height, 4), dtype=np.float32)
        arr[:, 0] = clear[0]; arr[:, 1] = clear[1]; arr[:, 2] = clear[2]; arr[:, 3] = clear[3]
        image.pixels.foreach_set(arr.reshape(-1))
        image.update()
        for key_prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_lazy_blank_layer'):
            try:
                if key_prop in image:
                    del image[key_prop]
            except Exception:
                pass
        try:
            image['smart_paint_suite_clear_initialized'] = True
            image['smart_paint_suite_clear_initialized_size'] = (width, height)
            image['smart_paint_suite_materialized_for_paint'] = True
            if 'smart_paint_suite_lazy_width' in image:
                del image['smart_paint_suite_lazy_width']
            if 'smart_paint_suite_lazy_height' in image:
                del image['smart_paint_suite_lazy_height']
        except Exception:
            pass
        _mark_image_pixels_changed(image, arr)
        return True
    except Exception:
        return False


def _safe_channel(channel: str) -> str:
    channel = str(channel or 'BASE_COLOR').upper()
    return channel if channel in set(DEFAULT_CHANNEL_ORDER) else 'BASE_COLOR'


def _master_prop(channel: str) -> str:
    return 'sps_master_texture_image_' + _safe_channel(channel)


def _master_node_name(channel: str) -> str:
    return 'SPS_MasterPaint_' + _safe_channel(channel)


def _find_layer_by_id(material, layer_id: str):
    settings = getattr(material, 'smart_paint_suite', None) if material is not None else None
    if settings is None:
        return None
    layer_id = str(layer_id or '')
    if layer_id:
        for layer in getattr(settings, 'layers', ()) or ():
            try:
                if str(getattr(layer, 'layer_id', '') or '') == layer_id:
                    return layer
            except Exception:
                continue
    try:
        if len(settings.layers):
            idx = max(0, min(int(getattr(settings, 'active_layer_index', 0) or 0), len(settings.layers) - 1))
            return settings.layers[idx]
    except Exception:
        pass
    return None


def _active_layer_id(material) -> str:
    layer = _find_layer_by_id(material, '')
    try:
        return str(getattr(layer, 'layer_id', '') or '')
    except Exception:
        return ''


def _copy_image_pixels(src, dst) -> bool:
    if src is None or dst is None:
        return False
    try:
        w, h = _image_size(src)
        _resize_image_to(dst, w, h)
        arr = _image_array_np(src)
        return _write_image_array_np(dst, arr)
    except Exception:
        return False


def _stack_signature(material, channel: str = 'BASE_COLOR') -> str:
    """Small non-pixel signature for visible stack state.

    It lets visibility/opacity changes recompose exactly once, while active-layer
    switching avoids full image recomposition when the visible stack did not
    actually change.
    """
    try:
        channel = _safe_channel(channel)
        settings = getattr(material, 'smart_paint_suite', None)
        attr = layer_channel_image_attr(channel)
        parts = []
        for index, layer in enumerate(getattr(settings, 'layers', ()) or ()):  # bottom -> top
            name = str(getattr(layer, attr, '') or '')
            img = bpy.data.images.get(name) if name else None
            try:
                size = f'{int(img.size[0])}x{int(img.size[1])}' if img is not None else ''
            except Exception:
                size = ''
            parts.append('|'.join((
                str(getattr(layer, 'layer_id', '') or index),
                '1' if bool(getattr(layer, 'enabled', True)) else '0',
                f'{float(getattr(layer, "opacity", 1.0) or 0.0):.5f}',
                str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper(),
                name,
                size,
                str(_image_pixel_revision(img) if img is not None else 0),
            )))
        return '::'.join(parts)
    except Exception:
        return ''


def _stack_signature_prop(channel: str = 'BASE_COLOR') -> str:
    return 'sps_layer_stack_signature_' + _safe_channel(channel)


def _stored_stack_signature(material, channel: str = 'BASE_COLOR') -> str:
    try:
        return str(material.get(_stack_signature_prop(channel), '') or '')
    except Exception:
        return ''


def _store_stack_signature(material, channel: str = 'BASE_COLOR') -> None:
    try:
        material[_stack_signature_prop(channel)] = _stack_signature(material, channel)
    except Exception:
        pass


def get_master_texture_image(material, channel: str = 'BASE_COLOR', *, create: bool = True, width: int = 0, height: int = 0):
    from . import clean_layer_stack_engine as _clean
    return _clean.get_master_texture_image(material, channel, create=create, width=width, height=height)

def ensure_private_layer_images(material, channel: str = 'BASE_COLOR') -> None:
    """Split legacy stacks where the visible master was reused as a layer image."""
    if material is None:
        return
    channel = _safe_channel(channel)
    settings = getattr(material, 'smart_paint_suite', None)
    if settings is None:
        return
    attr = layer_channel_image_attr(channel)
    master = get_master_texture_image(material, channel, create=False)
    for index, layer in enumerate(getattr(settings, 'layers', ()) or ()):  # bottom to top
        try:
            name = str(getattr(layer, attr, '') or '')
            image = bpy.data.images.get(name) if name else None
            if image is None:
                continue
            needs_split = (master is not None and image == master) or bool(image.get('smart_paint_suite_master_texture'))
            if not needs_split:
                try:
                    image['smart_paint_suite_layer_image'] = True
                    image['smart_paint_suite_material'] = getattr(material, 'name', '')
                    image['smart_paint_suite_layer_id'] = getattr(layer, 'layer_id', '')
                    image['smart_paint_suite_channel'] = channel
                except Exception:
                    pass
                # Do not refresh hidden pixel backups from this lightweight
                # legacy-split check.  Save/toggle operations call this often; on
                # large textures the backup copy was the primary freeze source.
                continue
            w, h = _image_size(image)
            layer_name = str(getattr(layer, 'name', '') or f'Layer_{index + 1}')
            new_name = 'SPS_' + str(getattr(material, 'name', 'Material')) + '_' + layer_name + '_' + channel
            private = bpy.data.images.new(new_name, max(1, w), max(1, h), alpha=True, float_buffer=False)
            _copy_image_pixels(image, private)
            try:
                private['smart_paint_suite_layer_image'] = True
                private['smart_paint_suite_material'] = getattr(material, 'name', '')
                private['smart_paint_suite_layer_id'] = getattr(layer, 'layer_id', '')
                private['smart_paint_suite_channel'] = channel
                private['smart_paint_suite_clear_color'] = (1.0, 1.0, 1.0, 0.0)
            except Exception:
                pass
            setattr(layer, attr, private.name)
            try:
                protect_layer_image_pixels(private)
            except Exception:
                pass
        except Exception:
            continue


def _find_principled(material):
    try:
        if not material.use_nodes:
            material.use_nodes = True
        for node in material.node_tree.nodes:
            if getattr(node, 'type', '') == 'BSDF_PRINCIPLED':
                return node
        return material.node_tree.nodes.new('ShaderNodeBsdfPrincipled')
    except Exception:
        return None


def _socket_for_channel(principled, channel: str):
    if principled is None:
        return None
    names = _CHANNEL_SOCKET_NAMES.get(_safe_channel(channel), _CHANNEL_SOCKET_NAMES['BASE_COLOR'])
    for name in names:
        try:
            sock = principled.inputs.get(name)
            if sock is not None:
                return sock
        except Exception:
            pass
    try:
        return principled.inputs[0]
    except Exception:
        return None


def _mark_master_as_view_target(material, channel: str = 'BASE_COLOR', master=None) -> None:
    """Store lightweight state used by tests/UI to verify display invariants."""
    try:
        channel = _safe_channel(channel)
        image = master or get_master_texture_image(material, channel, create=False)
        if material is not None and image is not None:
            material['sps_visible_master_image_' + channel] = image.name
            image['smart_paint_suite_visible_document'] = True
    except Exception:
        pass

def _force_single_image_canvas(context, material, channel: str = 'BASE_COLOR', image=None) -> None:
    from . import clean_layer_stack_engine as _clean
    try:
        master = image or _clean.get_master_texture_image(material, channel, create=True)
        if master is not None:
            _clean.install_master_display_node(material, channel, recompose=False)
        _clean.set_native_write_target(material, channel, context)
        _clean.show_master_in_editors(context, master)
    except Exception:
        pass

def _selection_prop(channel: str) -> str:
    return 'sps_selection_mask_' + _safe_channel(channel)


def _selection_active_prop(channel: str) -> str:
    return 'sps_selection_active_' + _safe_channel(channel)


def _selection_version_prop(channel: str) -> str:
    return 'sps_selection_version_' + _safe_channel(channel)


def _selection_cache_key(material, channel: str, width: int = 0, height: int = 0):
    return (str(getattr(material, 'name', '') or ''), _safe_channel(channel), int(width or 0), int(height or 0))


def _selection_mask_bbox_np(mask):
    np = _np_module()
    if np is None or mask is None:
        return None
    try:
        arr = np.asarray(mask, dtype=np.float32)
        if arr.ndim == 1:
            return None
        ys, xs = np.nonzero(arr > (1.0 / 1024.0))
        if len(xs) <= 0:
            return None
        return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
    except Exception:
        return None


def _selection_cache_set(material, channel: str, mask, width: int, height: int) -> None:
    np = _np_module()
    if np is None or material is None or mask is None:
        return
    try:
        ch = _safe_channel(channel)
        arr = np.clip(np.asarray(mask, dtype=np.float32).reshape((int(height), int(width))), 0.0, 1.0)
        has = bool(np.max(arr) > (1.0 / 1024.0)) if arr.size else False
        key = _selection_cache_key(material, ch, int(width), int(height))
        _SELECTION_MASK_CACHE.pop(key, None)
        _SELECTION_MASK_CACHE[key] = {'mask': np.ascontiguousarray(arr, dtype=np.float32), 'has': has, 'bbox': _selection_mask_bbox_np(arr)}
        _sps_quota.clear_for_memory_pressure()
        material[_selection_active_prop(ch)] = bool(has)
    except Exception:
        pass


def _selection_cache_clear(material, channel: str) -> None:
    try:
        ch = _safe_channel(channel)
        mat_name = str(getattr(material, 'name', '') or '')
        for key in list(_SELECTION_MASK_CACHE.keys()):
            if key[0] == mat_name and key[1] == ch:
                _SELECTION_MASK_CACHE.pop(key, None)
        material[_selection_active_prop(ch)] = False
    except Exception:
        pass


def _bump_selection_version(material, channel: str = 'BASE_COLOR') -> None:
    try:
        key = _selection_version_prop(channel)
        material[key] = int(material.get(key, 0) or 0) + 1
    except Exception:
        pass


def selection_version(material, channel: str = 'BASE_COLOR') -> int:
    try:
        return int(material.get(_selection_version_prop(channel), 0) or 0)
    except Exception:
        return 0


def selection_mask_bbox(material, channel: str = 'BASE_COLOR', width: int = 0, height: int = 0):
    if material is None:
        return None
    ch = _safe_channel(channel)
    cached = _SELECTION_MASK_CACHE.get(_selection_cache_key(material, ch, int(width or 0), int(height or 0)))
    if cached is not None:
        return cached.get('bbox')
    mask = selection_mask_array(material, ch, width, height)
    if mask is None:
        return None
    np = _np_module()
    if np is None:
        return None
    try:
        return _selection_mask_bbox_np(np.asarray(mask, dtype=np.float32).reshape((int(height), int(width))))
    except Exception:
        return None


def get_selection_mask_image(material, channel: str = 'BASE_COLOR', *, create: bool = False, width: int = 0, height: int = 0):
    """Return the current 2D selection mask image for a material/channel.

    The mask stores the allowed paint/edit area in its red and alpha channels.
    A missing mask means no selection restriction, matching Photoshop's normal
    "no active selection" state.
    """
    if material is None:
        return None
    channel = _safe_channel(channel)
    name = ''
    try:
        name = str(material.get(_selection_prop(channel), '') or '')
    except Exception:
        name = ''
    image = bpy.data.images.get(name) if name else None
    if image is None and create:
        if width <= 0 or height <= 0:
            master = get_master_texture_image(material, channel, create=False)
            width, height = _image_size(master)
        if width <= 0 or height <= 0:
            width = height = 1024
        name = 'SPS_' + str(getattr(material, 'name', 'Material')) + '_' + channel + '_Selection'
        image = bpy.data.images.get(name) or bpy.data.images.new(name, int(width), int(height), alpha=True, float_buffer=False)
        # Do not clear-fill here. set_selection_mask_array() immediately writes
        # the actual mask, and a redundant 4K/8K zero pass is a visible freeze.
        try:
            image.generated_color = (0.0, 0.0, 0.0, 0.0)
        except Exception:
            pass
    if image is not None:
        try:
            image['smart_paint_suite_selection_mask'] = True
            image['smart_paint_suite_material'] = str(getattr(material, 'name', '') or '')
            image['smart_paint_suite_channel'] = channel
            material[_selection_prop(channel)] = image.name
        except Exception:
            pass
    return image


def has_selection_mask(material, channel: str = 'BASE_COLOR') -> bool:
    if material is None:
        return False
    channel = _safe_channel(channel)
    try:
        if bool(material.get(_selection_active_prop(channel), False)):
            return True
    except Exception:
        pass
    img = get_selection_mask_image(material, channel, create=False)
    if img is None:
        return False
    np = _np_module()
    if np is None:
        return True
    try:
        w, h = _image_size(img)
        cached = _SELECTION_MASK_CACHE.get(_selection_cache_key(material, channel, int(w), int(h)))
        if cached is not None:
            return bool(cached.get('has'))
        arr = _read_image_array(img, w, h)
        if arr is None:
            return False
        vals = np.maximum(arr[:, 0], arr[:, 3]).astype(np.float32, copy=False)
        if vals.size:
            _selection_cache_set(material, channel, vals.reshape((int(h), int(w))), int(w), int(h))
        return bool(np.max(vals) > (1.0 / 1024.0)) if vals.size else False
    except Exception:
        return True


def selection_mask_array(material, channel: str = 'BASE_COLOR', width: int = 0, height: int = 0):
    np = _np_module()
    if np is None or material is None:
        return None
    channel = _safe_channel(channel)
    img = get_selection_mask_image(material, channel, create=False)
    if img is None:
        return None
    try:
        iw, ih = _image_size(img)
        if width <= 0 or height <= 0:
            width, height = iw, ih
        cached = _SELECTION_MASK_CACHE.get(_selection_cache_key(material, channel, int(width), int(height)))
        if cached is not None:
            if not bool(cached.get('has')):
                return None
            return np.asarray(cached.get('mask'), dtype=np.float32).reshape(-1)
        try:
            if bool(img.get('smart_paint_suite_selection_proxy_mask', False)):
                return None
        except Exception:
            pass
        arr = _read_image_array(img, width, height)
        if arr is None:
            return None
        vals = np.maximum(arr[:, 0], arr[:, 3]).astype(np.float32, copy=False)
        try:
            if bool(img.get('smart_paint_suite_selection_stencil_inverted', False)):
                vals = 1.0 - vals
        except Exception:
            pass
        shaped = vals.reshape((int(height), int(width)))
        _selection_cache_set(material, channel, shaped, int(width), int(height))
        if not bool(np.max(vals) > (1.0 / 1024.0)):
            return None
        return np.clip(vals, 0.0, 1.0)
    except Exception:
        return None



def _selection_stencil_resolution(width: int, height: int) -> tuple[int, int]:
    try:
        w = max(1, int(width)); h = max(1, int(height))
        limit = max(256, int(_SELECTION_STENCIL_MAX_DIMENSION))
        longest = max(w, h)
        if longest <= limit:
            return w, h
        scale = float(limit) / float(longest)
        return max(1, int(round(w * scale))), max(1, int(round(h * scale)))
    except Exception:
        return max(1, int(width or 1)), max(1, int(height or 1))


def _selection_downsample_nearest(mask, src_width: int, src_height: int, dst_width: int, dst_height: int):
    np = _np_module()
    if np is None:
        return mask
    try:
        src = np.asarray(mask, dtype=np.float32).reshape((int(src_height), int(src_width)))
        if int(src_width) == int(dst_width) and int(src_height) == int(dst_height):
            return src
        ys = np.minimum((np.arange(int(dst_height), dtype=np.float32) * (float(src_height) / float(dst_height))).astype(np.int64), int(src_height) - 1)
        xs = np.minimum((np.arange(int(dst_width), dtype=np.float32) * (float(src_width) / float(dst_width))).astype(np.int64), int(src_width) - 1)
        return src[ys[:, None], xs[None, :]].astype(np.float32, copy=False)
    except Exception:
        try:
            return np.asarray(mask, dtype=np.float32).reshape((int(src_height), int(src_width)))
        except Exception:
            return None


def _write_selection_stencil_image(material, channel: str, selected_mask, width: int, height: int):
    """Create/update the Blender-native stencil image.

    Smart Paint's authoritative mask stores selected pixels as 1.0.  Blender's
    native ImagePaint stencil treats white as protected on several 5.x builds,
    so the stencil image stores the inverse: selected = black, outside = white.
    For large documents a bounded-resolution stencil is used for interactive
    speed; the full-resolution mask stays in _SELECTION_MASK_CACHE for exact
    post-commit clipping and editing operators.
    """
    np = _np_module()
    if np is None or material is None or selected_mask is None:
        return None, False
    channel = _safe_channel(channel)
    try:
        sw, sh = _selection_stencil_resolution(int(width), int(height))
        sm = _selection_downsample_nearest(selected_mask, int(width), int(height), sw, sh)
        if sm is None:
            return None, False
        # Inverted stencil: black means editable selected area, white protects.
        inv = 1.0 - np.clip(sm.reshape((int(sh), int(sw))), 0.0, 1.0)
        img = get_selection_mask_image(material, channel, create=True, width=int(sw), height=int(sh))
        if img is None:
            return None, False
        _resize_image_to(img, int(sw), int(sh))
        arr = np.empty((int(sw) * int(sh), 4), dtype=np.float32)
        flat = inv.reshape(-1).astype(np.float32, copy=False)
        arr[:, 0] = flat; arr[:, 1] = flat; arr[:, 2] = flat; arr[:, 3] = flat
        ok = _write_image_array_np(img, arr)
        try:
            img['smart_paint_suite_selection_stencil_inverted'] = True
            img['smart_paint_suite_selection_width'] = int(width)
            img['smart_paint_suite_selection_height'] = int(height)
            img['smart_paint_suite_selection_stencil_width'] = int(sw)
            img['smart_paint_suite_selection_stencil_height'] = int(sh)
            img['smart_paint_suite_selection_proxy_mask'] = bool(int(sw) != int(width) or int(sh) != int(height))
        except Exception:
            pass
        return img, bool(ok)
    except Exception:
        return None, False

def set_selection_mask_array(material, channel: str, mask, width: int, height: int) -> bool:
    np = _np_module()
    if np is None or material is None or mask is None:
        return False
    channel = _safe_channel(channel)
    try:
        w = int(width); h = int(height)
        m = np.asarray(mask, dtype=np.float32).reshape((h, w))
        m = np.clip(m, 0.0, 1.0)
        img, ok = _write_selection_stencil_image(material, channel, m, w, h)
        if img is None:
            return False
        try:
            material[_selection_prop(channel)] = img.name
        except Exception:
            pass
        if ok:
            try:
                # Authoritative full-resolution document mask.  Do not derive
                # correctness from the lower-resolution native stencil.
                _selection_cache_set(material, channel, m, w, h)
                _bump_selection_version(material, channel)
            except Exception:
                pass
            try:
                ensure_selection_live_paint_timer(material, channel)
            except Exception:
                pass
            # Selection creation must be metadata/stencil-only.  Rebinding or
            # recreating the active private paint image here can replace a freshly
            # painted layer with a blank "intentionally empty" buffer before
            # Photoshop-style commands such as Layer Via Copy read it.
        return bool(ok)
    except Exception:
        return False

def clear_selection_mask(material, channel: str = 'BASE_COLOR') -> bool:
    if material is None:
        return False
    channel = _safe_channel(channel)
    try:
        commit_master_paint_session(material, channel, restart=True, force=True)
    except Exception:
        pass
    try:
        # Do not clear-fill the mask image.  On 4K/8K selections that is a full
        # RGBA write and causes visible freezes.  Removing the material reference
        # and clearing the cache is sufficient; sync_selection_stencil() disables
        # any Smart Paint-owned stencil.
        img = get_selection_mask_image(material, channel, create=False)
        if _selection_prop(channel) in material:
            del material[_selection_prop(channel)]
        try:
            _selection_cache_clear(material, channel)
            _bump_selection_version(material, channel)
        except Exception:
            pass
        try:
            refresh_selection_live_paint_timer()
        except Exception:
            pass
        try:
            _restore_document_canvas_fast(material, channel, getattr(bpy, 'context', None))
        except Exception:
            pass
        return True
    except Exception:
        return False



def _restore_document_canvas_fast(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    """Cheap target repair used by selection paths.

    Full sync_document_texture_target() touches node trees and view layers.  A
    selection mask update only needs to ensure Blender's current paint canvas and
    material paint slot still point at the public document texture, so avoid the
    expensive full synchronization here.
    """
    try:
        channel = _sps182_channel(channel)
        ctx = context or getattr(bpy, 'context', None)
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        try:
            ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
            ip = getattr(ts, 'image_paint', None) if ts is not None else None
            if ip is not None:
                try:
                    ip.mode = 'MATERIAL'
                except Exception:
                    pass
                try:
                    if hasattr(ip, 'canvas'):
                        ip.canvas = master
                except Exception:
                    pass
        except Exception:
            pass
        try:
            for index, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):  # Material mode slots
                if candidate == master:
                    material.paint_active_slot = int(index)
                    break
        except Exception:
            pass
        try:
            scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
            if scene_settings is not None:
                scene_settings.active_paint_material = material
                scene_settings.active_paint_image = master
        except Exception:
            pass
        try:
            material['sps_native_write_image_' + _safe_channel(channel)] = master.name
        except Exception:
            pass
        return True
    except Exception:
        return False


def sync_selection_stencil(context=None, material=None, channel: str = 'BASE_COLOR') -> bool:
    """Use Blender's native ImagePaint stencil as the fast selection mask.

    The public paint target stays on the document texture.  The stencil is an
    internal clipping mask only; after assigning it, Smart Paint immediately
    reasserts the Layer > Paint Texture Path / Save image as the Image Editor,
    canvas and Material paint slot target.  A Smart Paint post-commit clip remains
    as the exact safety pass.
    """
    try:
        channel = _sps182_channel(channel)
        ctx = context or getattr(bpy, 'context', None)
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        changed = False
        active = False
        try:
            active = bool(material is not None and has_selection_mask(material, channel))
        except Exception:
            active = False
        if ip is not None:
            if active:
                mask_img = get_selection_mask_image(material, channel, create=False)
                if mask_img is not None:
                    try:
                        if getattr(ip, 'stencil_image', None) != mask_img:
                            ip.stencil_image = mask_img
                            changed = True
                    except Exception:
                        pass
                    try:
                        if hasattr(ip, 'use_stencil_layer') and not bool(getattr(ip, 'use_stencil_layer')):
                            ip.use_stencil_layer = True
                            changed = True
                    except Exception:
                        pass
                    try:
                        if hasattr(ip, 'invert_stencil') and bool(getattr(ip, 'invert_stencil')):
                            ip.invert_stencil = False
                            changed = True
                    except Exception:
                        pass
                    try:
                        # Avoid the reported white 3D overlay.  The mask still
                        # clips brush writes; Smart Paint draws its own marching
                        # ants overlay for user feedback.
                        if hasattr(ip, 'stencil_color'):
                            ip.stencil_color = (0.0, 0.0, 0.0)
                    except Exception:
                        pass
            else:
                try:
                    cur = getattr(ip, 'stencil_image', None)
                except Exception:
                    cur = None
                try:
                    if cur is None or bool(getattr(cur, 'get', lambda *_: False)('smart_paint_suite_selection_mask', False)):
                        if hasattr(ip, 'use_stencil_layer') and bool(getattr(ip, 'use_stencil_layer')):
                            ip.use_stencil_layer = False
                            changed = True
                        if cur is not None:
                            try:
                                ip.stencil_image = None
                                changed = True
                            except Exception:
                                pass
                except Exception:
                    pass
            try:
                ip.mode = 'MATERIAL'
            except Exception:
                pass
        if active:
            try:
                ensure_selection_master_paint_session(material, channel)
            except Exception:
                pass
            try:
                img = _active_layer_private_image(material, channel)
                if img is not None:
                    _register_direct_layer_paint_session(material, channel, img)
            except Exception:
                pass
        try:
            if material is not None:
                _restore_document_canvas_fast(material, channel, ctx)
        except Exception:
            pass
        return bool(changed)
    except Exception:
        return False


def _session_key(material, channel: str):
    return (str(getattr(material, 'name', '') or ''), _safe_channel(channel))


def _master_session_stack_signature(material, channel: str = 'BASE_COLOR') -> str:
    """Return the current private-layer stack signature for paint-session safety.

    A visible-master paint session is only safe to replay when it was armed
    against the same private layer stack.  Texture Save used to force a commit
    from stale master sessions; if the layer stack had changed meanwhile, the
    exporter could treat the already-composited document preview as a new brush
    delta and write upper-layer pixels into the active or bottom layer.
    """
    try:
        from . import clean_layer_stack_engine as _clean
        _w, _h, layers = _clean.collect_layers(material, channel)
        return str(_clean._layer_stack_signature(material, channel, layers=layers) or '')
    except Exception:
        return ''


def _master_session_matches_current_stack(session, material, channel: str = 'BASE_COLOR') -> bool:
    try:
        if session is None:
            return False
        old_sig = str(session.get('stack_signature', '') or '')
        new_sig = _master_session_stack_signature(material, channel)
        return bool(old_sig and new_sig and old_sig == new_sig)
    except Exception:
        return False


def _refresh_master_session_signature(session, material, channel: str = 'BASE_COLOR') -> None:
    try:
        if session is not None:
            session['stack_signature'] = _master_session_stack_signature(material, channel)
    except Exception:
        pass


def _layer_image_for_session(material, layer_id: str, channel: str):
    layer = _find_layer_by_id(material, layer_id)
    if layer is None:
        return None, None
    attr = layer_channel_image_attr(_safe_channel(channel))
    try:
        image = bpy.data.images.get(str(getattr(layer, attr, '') or ''))
    except Exception:
        image = None
    return layer, image


def _master_paint_layers_snapshot(material, channel: str = 'BASE_COLOR'):
    """Capture the layer context used by the visible-master paint baseline.

    Visibility, mask, group, opacity, and blend-mode edits can happen before the
    pending master stroke is committed back to the private active layer.  When an
    exact baseline exists, the inverse solver must use the stack context from the
    moment that baseline was captured, not the already-edited stack.  Otherwise a
    visibility toggle can flatten lower-layer colors into the active layer.
    """
    try:
        width, height, layers = collect_layers(material, channel)
    except Exception:
        return None
    try:
        snap_layers = []
        for item in list(layers or []):
            try:
                image = item.get('image')
                layer = item.get('layer')
                snap_layers.append({
                    'index': int(item.get('index', 0) or 0),
                    'stack_position': int(item.get('stack_position', item.get('index', 0)) or 0),
                    'layer_id': str(item.get('layer_id', '') or ''),
                    'name': str(item.get('name', '') or ''),
                    'image': image,
                    'image_name': str(getattr(image, 'name', '') if image is not None else ''),
                    'layer': layer,
                    'enabled': bool(item.get('enabled', True)),
                    'opacity': float(item.get('opacity', 1.0) or 0.0),
                    'blend_mode': str(item.get('blend_mode', 'MIX') or 'MIX'),
                    'background': bool(item.get('background', False)),
                    'is_group': bool(item.get('is_group', False)),
                    'group_depth': int(item.get('group_depth', 0) or 0),
                    'clip_to_below': bool(item.get('clip_to_below', False)),
                    'adjustment_type': str(item.get('adjustment_type', 'NONE') or 'NONE'),
                })
            except Exception:
                continue
        if not snap_layers:
            return None
        return {'width': int(width), 'height': int(height), 'layers': snap_layers}
    except Exception:
        return None


def _use_master_paint_layers_snapshot(snapshot, expected_width: int, expected_height: int):
    try:
        if not isinstance(snapshot, dict):
            return None
        sw = int(snapshot.get('width', 0) or 0)
        sh = int(snapshot.get('height', 0) or 0)
        layers = list(snapshot.get('layers', []) or [])
        if sw == int(expected_width) and sh == int(expected_height) and layers:
            return sw, sh, layers
    except Exception:
        pass
    return None


def _apply_master_delta_to_layer(material, channel: str, layer_id: str, baseline, current, *, tolerance: float = 1.0 / 1024.0, layers_snapshot=None) -> bool:
    """Transfer visible-master paint into the active Smart Paint layer only.

    Native Blender Texture Paint modifies the visible composited master image.
    To keep Photoshop-style display while still recording the stroke on the
    selected layer only, reconstruct the active-layer pixels against the stable
    stack context:

    * upper visible layers stay unchanged,
    * lower layers stay unchanged,
    * only the selected layer image is edited,
    * unsupported / fully blocked pixels are discarded and restored by the
      subsequent master recomposition.

    This specifically fixes eraser / mask-like brushes which previously looked
    as if they erased the whole composited stack when ``All Layers Target`` was
    off.
    """
    np = _np_module()
    if np is None or material is None or baseline is None or current is None:
        return False

    def _direct_project_to_active(layer_arr, write_mask, image_ref):
        """Fallback for active-layer painting when inverse solving is impossible.

        Never copy the already-composited master alpha directly into the private
        layer.  On an opaque document that alpha is usually 1.0 and would destroy
        the brush's soft source alpha.  Recover continuous coverage from the
        visible-master delta instead.
        """
        if not bool(np.any(write_mask)):
            return False
        try:
            rows = np.nonzero(write_mask)[0]
            ok_rows = _recover_visible_master_rows_to_layer_array(
                image_ref,
                layer_arr,
                rows,
                baseline[rows, :3],
                current[rows, :3],
                baseline_alpha=baseline[rows, 3],
                current_alpha=current[rows, 3],
                tolerance=float(tolerance),
                context=getattr(bpy, 'context', None),
            )
            if not ok_rows:
                return False
            ok_local = _write_image_array_np(image_ref, layer_arr)
            if ok_local:
                try:
                    image_ref['smart_paint_suite_dirty_from_master'] = True
                    image_ref['smart_paint_suite_alpha_authoritative'] = True
                except Exception:
                    pass
            return bool(ok_local)
        except Exception:
            return False

    def _apply_alpha_erase_to_active(layer_arr, erase_mask, image_ref):
        """Apply Blender alpha/eraser master delta to the selected layer only.

        The public master receives alpha loss first.  Treat that alpha loss as
        an eraser stroke and reduce only the active layer alpha.  Keep RGB for
        partially erased pixels and clear RGB for fully erased pixels so RGB
        fallback code cannot resurrect deleted pixels as black paint.
        """
        if not bool(np.any(erase_mask)):
            return False
        try:
            base_a = np.clip(baseline[erase_mask, 3], 0.0, 1.0)
            cur_a = np.clip(current[erase_mask, 3], 0.0, 1.0)
            old_a = np.clip(layer_arr[erase_mask, 3], 0.0, 1.0)
            ratio = np.ones_like(old_a, dtype=np.float32)
            valid = base_a > (1.0 / 4096.0)
            ratio[valid] = np.clip(cur_a[valid] / np.maximum(base_a[valid], 1.0 / 4096.0), 0.0, 1.0)
            ratio[np.logical_not(valid)] = 0.0
            new_a = np.clip(old_a * ratio, 0.0, 1.0)
            layer_arr[erase_mask, 3] = new_a
            try:
                clear = image_ref.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0))
                clear_rgb = np.asarray(tuple(float(v) for v in clear[:3]), dtype=np.float32).reshape((1, 3))
            except Exception:
                clear_rgb = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
            # Some Blender/Image Editor eraser paths write the layer clear color
            # into the public document while leaving alpha unchanged.  Treat
            # those pixels as an erase request for the active layer.
            try:
                cur_rgb_local = np.clip(current[erase_mask, :3], 0.0, 1.0)
                clear_like = np.logical_or(
                    np.max(np.abs(cur_rgb_local - clear_rgb), axis=1) <= (8.0 / 255.0),
                    np.logical_or(
                        np.max(np.abs(cur_rgb_local - 1.0), axis=1) <= (8.0 / 255.0),
                        np.max(np.abs(cur_rgb_local - 0.0), axis=1) <= (8.0 / 255.0),
                    ),
                )
                no_alpha_loss = cur_a >= (base_a - (1.0 / 4096.0))
                if bool(np.any(np.logical_and(clear_like, no_alpha_loss))):
                    ratio[np.logical_and(clear_like, no_alpha_loss)] = 0.0
                    new_a = np.clip(old_a * ratio, 0.0, 1.0)
                    layer_arr[erase_mask, 3] = new_a
            except Exception:
                pass
            zero_local = new_a <= (1.0 / 4096.0)
            if bool(np.any(zero_local)):
                rows = np.nonzero(erase_mask)[0][zero_local]
                layer_arr[rows, :3] = clear_rgb
            ok_local = _write_image_array_np(image_ref, layer_arr)
            if ok_local:
                try:
                    image_ref['smart_paint_suite_dirty_from_master'] = True
                    image_ref['smart_paint_suite_alpha_authoritative'] = True
                    material['sps_last_master_delta_alpha_erase_' + channel] = float(time.time())
                    if 'smart_paint_suite_rgb_alpha_fallback' in image_ref:
                        del image_ref['smart_paint_suite_rgb_alpha_fallback']
                except Exception:
                    pass
            return bool(ok_local)
        except Exception:
            return False

    def _refresh_master_pixels_from_stack(local_mask):
        """Immediately repair the public master on pixels touched by eraser.

        Without this, Image Editor can keep the flattened-master alpha hole until
        a deferred projection finishes, while the 3D View can keep the old GPU
        texture.  Reprojecting only touched pixels gives Photoshop-like active-
        layer eraser feedback without rewriting the whole document in common
        brush-sized cases.
        """
        if not bool(np.any(local_mask)):
            return False
        try:
            master_img = get_master_texture_image(material, channel, create=False)
            if master_img is None:
                return False
            use_fallback = False
            try:
                from . import clean_layer_stack_engine as _clean
                use_fallback = bool(_clean._stack_has_lazy_layers(material, channel) or _clean._is_heavy_stack_for_sync(material, channel))
            except Exception:
                use_fallback = False
            exact_repair = False
            if use_fallback:
                # For ordinary PSDs such as the attached 2048px hair texture, an
                # exact immediate repair is more important than keeping every
                # lazy layer deferred: otherwise Image Editor shows the flattened
                # eraser hole and 3D View appears unchanged until a later update.
                # Limit this eager path to moderate documents/layer counts.
                try:
                    mw, mh = _image_size(master_img)
                    _tw, _th, _layers_for_count = collect_layers(material, channel)
                    if int(mw) * int(mh) <= 2048 * 2048 and len(_layers_for_count or []) <= 12:
                        _cw, _ch, comp = composite_layer_arrays(material, channel)
                        exact_repair = comp is not None
                    else:
                        comp = baseline
                except Exception:
                    comp = baseline
                if not exact_repair:
                    try:
                        from . import clean_layer_stack_engine as _clean
                        _clean._schedule_deferred_composite(material, channel)
                    except Exception:
                        pass
            else:
                _cw, _ch, comp = composite_layer_arrays(material, channel)
                exact_repair = comp is not None
            if comp is None or getattr(comp, 'shape', None) != current.shape:
                return False
            repaired = current.copy()
            repaired[local_mask, :4] = np.clip(comp[local_mask, :4], 0.0, 1.0)
            ok_master = _write_image_array_np(master_img, repaired)
            if ok_master:
                try:
                    master_img['smart_paint_suite_eraser_active_layer_repaired'] = True
                    material['sps_visible_master_image_' + channel] = master_img.name
                    material['sps_document_target_image_' + channel] = master_img.name
                    if exact_repair and not bool(has_selection_mask(material, channel)):
                        material['sps_skip_full_recompose_after_active_eraser_' + channel] = True
                except Exception:
                    pass
                try:
                    from .clean_layer_stack_engine import force_document_texture_refresh
                    force_document_texture_refresh(material, channel, getattr(bpy, 'context', None), master_img, show_editors=True, switch_to_paint=False, force_gpu=True)
                except Exception:
                    try:
                        sync_document_texture_target(material, channel, getattr(bpy, 'context', None), show_editors=True, switch_to_paint=False)
                    except Exception:
                        pass
            return bool(ok_master)
        except Exception:
            return False

    def _legacy_apply(layer_arr, mask, base_rgb_all, cur_rgb_all, current_alpha, baseline_alpha, image_ref):
        if not bool(np.any(mask)):
            return False
        base_rgb = base_rgb_all[mask]
        cur_rgb = cur_rgb_all[mask]
        diff_rgb = cur_rgb - base_rgb
        eps_local = 1e-6
        lighten = np.where(diff_rgb > 0.0, diff_rgb / np.maximum(1.0 - base_rgb, eps_local), 0.0)
        darken = np.where(diff_rgb < 0.0, (-diff_rgb) / np.maximum(base_rgb, eps_local), 0.0)
        required = np.max(np.maximum(lighten, darken), axis=1)
        required = np.maximum(required, np.abs(current_alpha[mask] - baseline_alpha[mask]))
        coverage = np.clip(required, 1.0 / 255.0, 1.0).astype(np.float32, copy=False)
        src_rgb = (cur_rgb - base_rgb * (1.0 - coverage[:, None])) / np.maximum(coverage[:, None], eps_local)
        src_rgb = np.clip(src_rgb, 0.0, 1.0)
        existing_alpha = np.clip(layer_arr[mask, 3], 0.0, 1.0)
        old_rgb = np.clip(layer_arr[mask, :3], 0.0, 1.0)
        new_alpha = np.clip(coverage + existing_alpha * (1.0 - coverage), 0.0, 1.0)
        try:
            master_alpha = np.clip(current_alpha[mask], 0.0, 1.0)
            base_alpha = np.clip(baseline_alpha[mask], 0.0, 1.0)
            alpha_changed = np.abs(master_alpha - base_alpha) > max(1.0 / 4096.0, float(tolerance))
            if bool(np.any(alpha_changed)):
                new_alpha[alpha_changed] = master_alpha[alpha_changed]
        except Exception:
            pass
        old_pm = old_rgb * existing_alpha[:, None]
        new_pm = src_rgb * coverage[:, None]
        merged_pm = new_pm + old_pm * (1.0 - coverage[:, None])
        merged_rgb = merged_pm / np.maximum(new_alpha[:, None], eps_local)
        layer_arr[mask, :3] = np.clip(merged_rgb, 0.0, 1.0)
        layer_arr[mask, 3] = np.clip(new_alpha, 0.0, 1.0)
        ok_local = _write_image_array_np(image_ref, layer_arr)
        if ok_local:
            try:
                image_ref['smart_paint_suite_dirty_from_master'] = True
                image_ref['smart_paint_suite_alpha_authoritative'] = True
            except Exception:
                pass
        return bool(ok_local)

    def _invert_upper_step(target_rgb, src_rgb, alpha, mode: str, fallback_rgb):
        """Invert one stack step for supported blend modes.

        Returns (previous_rgb, solvable_mask).  Unsupported / fully occluded
        pixels fall back to ``fallback_rgb`` and are marked unsolved so they can
        be restored by recomposition instead of corrupting the selected layer.
        """
        desired = np.clip(np.asarray(fallback_rgb, dtype=np.float32), 0.0, 1.0).copy()
        alpha = np.clip(np.asarray(alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
        target_rgb = np.clip(np.asarray(target_rgb, dtype=np.float32), 0.0, 1.0)
        src_rgb = np.clip(np.asarray(src_rgb, dtype=np.float32), 0.0, 1.0)
        mode = str(mode or 'MIX').upper()
        eps_local = 1e-6
        tol = 2.5 / 255.0
        solvable = alpha <= eps_local
        if bool(np.any(solvable)):
            desired[solvable] = target_rgb[solvable]
        work = np.logical_not(solvable)
        if not bool(np.any(work)):
            return desired, np.ones(alpha.shape[0], dtype=bool)
        idx = np.nonzero(work)[0]
        a = alpha[idx]
        tgt = target_rgb[idx]
        src = src_rgb[idx]
        prev = None
        ok = np.zeros(idx.shape[0], dtype=bool)
        if mode in {'MIX', 'NORMAL'}:
            denom = 1.0 - a
            ok = denom > eps_local
            prev = desired[idx].copy()
            if bool(np.any(ok)):
                prev[ok] = np.clip((tgt[ok] - src[ok] * a[ok, None]) / denom[ok, None], 0.0, 1.0)
        elif mode == 'ADD':
            prev = np.clip(tgt - src * a[:, None], 0.0, 1.0)
            ok[:] = True
        elif mode == 'MULTIPLY':
            factor = (1.0 - a)[:, None] + a[:, None] * src
            prev = desired[idx].copy()
            ok = np.min(np.abs(factor), axis=1) > eps_local
            if bool(np.any(ok)):
                prev[ok] = np.clip(tgt[ok] / factor[ok], 0.0, 1.0)
        elif mode == 'SCREEN':
            factor = 1.0 - (a[:, None] * src)
            prev = desired[idx].copy()
            ok = np.min(np.abs(factor), axis=1) > eps_local
            if bool(np.any(ok)):
                prev[ok] = np.clip((tgt[ok] - a[ok, None] * src[ok]) / factor[ok], 0.0, 1.0)
        else:
            return desired, solvable
        if prev is not None and bool(np.any(ok)):
            recon = _blend_rgb(prev[ok], src[ok], a[ok], mode)
            err = np.max(np.abs(recon - tgt[ok]), axis=1)
            ok_valid = err <= tol
            if bool(np.any(ok_valid)):
                ok_idx = idx[ok][ok_valid]
                desired[ok_idx] = prev[ok][ok_valid]
                solvable[ok_idx] = True
        return desired, solvable

    def _solve_active_pixels(under_rgb, target_rgb, opacity: float, mode: str, background: bool, old_rgb, old_alpha):
        mode = str(mode or 'MIX').upper()
        opacity = float(max(0.0, min(1.0, opacity)))
        n = int(target_rgb.shape[0])
        src_out = np.clip(np.asarray(old_rgb, dtype=np.float32), 0.0, 1.0).copy()
        alpha_out = np.clip(np.asarray(old_alpha, dtype=np.float32).reshape((n,)), 0.0, 1.0).copy()
        solvable = np.zeros(n, dtype=bool)
        if background:
            src_out[:] = np.clip(target_rgb, 0.0, 1.0)
            alpha_out[:] = 1.0
            solvable[:] = True
            return src_out, alpha_out, solvable
        if opacity <= 1e-6:
            return src_out, alpha_out, solvable
        eps_local = 1e-6
        U = np.clip(np.asarray(under_rgb, dtype=np.float32), 0.0, 1.0)
        T = np.clip(np.asarray(target_rgb, dtype=np.float32), 0.0, 1.0)
        if mode in {'MIX', 'NORMAL'}:
            diff = T - U
            lighten = np.where(diff > 0.0, diff / np.maximum(1.0 - U, eps_local), 0.0)
            darken = np.where(diff < 0.0, (-diff) / np.maximum(U, eps_local), 0.0)
            eff = np.max(np.maximum(lighten, darken), axis=1)
            eff = np.clip(eff, 0.0, opacity)
            nonzero = eff > (1.0 / 255.0)
            zero = np.logical_not(nonzero)
            if bool(np.any(zero)):
                alpha_out[zero] = 0.0
                src_out[zero] = 1.0
                solvable[zero] = True
            if bool(np.any(nonzero)):
                eff_nz = eff[nonzero]
                src = (T[nonzero] - U[nonzero] * (1.0 - eff_nz[:, None])) / np.maximum(eff_nz[:, None], eps_local)
                src_out[nonzero] = np.clip(src, 0.0, 1.0)
                alpha_out[nonzero] = np.clip(eff_nz / opacity, 0.0, 1.0)
                solvable[nonzero] = True
            return src_out, alpha_out, solvable
        if mode == 'ADD':
            diff = np.clip(T - U, 0.0, 1.0)
            eff = np.max(diff, axis=1)
            eff = np.clip(eff, 0.0, opacity)
            nonzero = eff > (1.0 / 255.0)
            zero = np.logical_not(nonzero)
            if bool(np.any(zero)):
                alpha_out[zero] = 0.0
                src_out[zero] = 0.0
                solvable[zero] = True
            if bool(np.any(nonzero)):
                eff_nz = eff[nonzero]
                src = diff[nonzero] / np.maximum(eff_nz[:, None], eps_local)
                src_out[nonzero] = np.clip(src, 0.0, 1.0)
                alpha_out[nonzero] = np.clip(eff_nz / opacity, 0.0, 1.0)
                solvable[nonzero] = True
            return src_out, alpha_out, solvable
        if mode == 'MULTIPLY':
            with np.errstate(divide='ignore', invalid='ignore'):
                ratio = np.where(U > eps_local, np.clip(T / np.maximum(U, eps_local), 0.0, 1.0), 1.0)
            needed = np.clip(1.0 - ratio, 0.0, 1.0)
            eff = np.clip(needed, 0.0, opacity)
            nonzero = eff > (1.0 / 255.0)
            zero = np.logical_not(nonzero)
            if bool(np.any(zero)):
                alpha_out[zero] = 0.0
                src_out[zero] = 1.0
                solvable[zero] = True
            if bool(np.any(nonzero)):
                eff_nz = eff[nonzero]
                src = (ratio[nonzero] - (1.0 - eff_nz[:, None])) / np.maximum(eff_nz[:, None], eps_local)
                src_out[nonzero] = np.clip(src, 0.0, 1.0)
                alpha_out[nonzero] = np.clip(eff_nz / opacity, 0.0, 1.0)
                solvable[nonzero] = True
            return src_out, alpha_out, solvable
        if mode == 'SCREEN':
            diff = np.clip(T - U, 0.0, 1.0)
            denom = np.maximum(1.0 - U, eps_local)
            needed = diff / denom
            eff = np.max(needed, axis=1)
            eff = np.clip(eff, 0.0, opacity)
            nonzero = eff > (1.0 / 255.0)
            zero = np.logical_not(nonzero)
            if bool(np.any(zero)):
                alpha_out[zero] = 0.0
                src_out[zero] = 0.0
                solvable[zero] = True
            if bool(np.any(nonzero)):
                eff_nz = eff[nonzero]
                src = (T[nonzero] - U[nonzero]) / np.maximum((1.0 - U[nonzero]) * eff_nz[:, None], eps_local)
                src_out[nonzero] = np.clip(src, 0.0, 1.0)
                alpha_out[nonzero] = np.clip(eff_nz / opacity, 0.0, 1.0)
                solvable[nonzero] = True
            return src_out, alpha_out, solvable
        return src_out, alpha_out, solvable

    channel = _safe_channel(channel)
    layer, image = _layer_image_for_session(material, layer_id, channel)
    if layer is None or image is None:
        return False
    try:
        _sess_rgb = None
        _sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, channel))
        if isinstance(_sess, dict):
            _sess_rgb = _rgb_tuple_or_none(_sess.get('brush_rgb', None))
        if _sess_rgb is not None:
            image['smart_paint_suite_last_source_rgb'] = tuple(float(v) for v in _sess_rgb[:3])
    except Exception:
        pass
    try:
        # PSD/PSB imports use 1x1 lazy proxy images for layer pixels.  Before a
        # native brush/eraser delta is written back to an active imported PSD layer,
        # materialize that one PSD layer only.  New blank paint layers are handled
        # as sparse in-memory buffers below so the first stroke does not require an
        # extra full-canvas clear write before the real stroke write.
        if bool(image.get('smart_paint_suite_lazy_psd_pending', False)):
            materialize_lazy_psd_layer_image(image)
    except Exception:
        pass
    w, h = _image_size(image)
    master = get_master_texture_image(material, channel, create=False)
    mw, mh = _image_size(master)
    try:
        actual_w = int(image.size[0]); actual_h = int(image.size[1])
    except Exception:
        actual_w = int(w); actual_h = int(h)
    try:
        lazy_blank_first_write = bool(image.get('smart_paint_suite_lazy_blank_layer', False))
        lazy_blank_first_write = bool(lazy_blank_first_write or (actual_w == 1 and actual_h == 1 and (int(image.get('smart_paint_suite_lazy_width', 0) or 0) > 1 or int(image.get('smart_paint_suite_lazy_height', 0) or 0) > 1)))
    except Exception:
        lazy_blank_first_write = False
    if lazy_blank_first_write:
        try:
            w, h = max(1, int(mw)), max(1, int(mh))
            clear = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
            rgba = tuple(float(clear[i]) if i < len(clear) else (1.0 if i == 3 else 0.0) for i in range(4))
            layer_arr = np.empty((int(w) * int(h), 4), dtype=np.float32)
            layer_arr[:, 0] = rgba[0]; layer_arr[:, 1] = rgba[1]; layer_arr[:, 2] = rgba[2]; layer_arr[:, 3] = rgba[3]
        except Exception:
            return False
    else:
        try:
            if actual_w != int(mw) or actual_h != int(mh):
                _materialize_lazy_blank_layer_for_write(image, max(1, int(mw)), max(1, int(mh)))
                w, h = _image_size(image)
        except Exception:
            pass
        if w != mw or h != mh:
            try:
                image.scale(max(1, mw), max(1, mh))
                w, h = mw, mh
            except Exception:
                return False
        layer_arr = _image_array_np(image)
        if layer_arr is None or layer_arr.shape != current.shape:
            return False

    try:
        delta_tolerance = max(1.0 / 4096.0, float(tolerance))
    except Exception:
        delta_tolerance = 1.0 / 1024.0
    try:
        # Compute the visible master delta once.  Older code clipped RGB and alpha
        # into multiple full-canvas temporaries before common top-layer strokes could
        # take the fast path.  One RGBA reduction is enough to discover the changed
        # rows; complex paths below allocate the heavier arrays only when needed.
        raw_mask = (np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1) > delta_tolerance)
    except Exception:
        return False
    if not bool(np.any(raw_mask)):
        return False
    mask = raw_mask.copy()
    selection = selection_mask_array(material, channel, mw, mh)
    if selection is not None:
        mask = np.logical_and(raw_mask, selection > (1.0 / 1024.0))
        if not bool(np.any(mask)):
            return True

    try:
        all_layers_fast_probe = bool(_scene_layer_all_layers_enabled(getattr(bpy, 'context', None)))
    except Exception:
        all_layers_fast_probe = False
    # Exact-baseline, active-top, normal-paint fast path.  This is the usual case
    # when the user paints on a newly added layer and then toggles visibility or
    # saves.  It avoids full-canvas RGB clipping, clear-color erase classification,
    # and stage_before/stage_after construction.
    if selection is None:
        try:
            eraser_brush_fast_probe = bool(_active_texture_paint_brush_is_eraser(getattr(bpy, 'context', None)))
        except Exception:
            eraser_brush_fast_probe = False
        try:
            rows_fast0 = np.nonzero(mask)[0]
        except Exception:
            rows_fast0 = np.asarray([], dtype=np.int64)
        try:
            alpha_loss_fast0 = bool(rows_fast0.size and np.any(current[rows_fast0, 3] < (baseline[rows_fast0, 3] - delta_tolerance)))
        except Exception:
            alpha_loss_fast0 = True
        clear_like_fast0 = False
        try:
            if rows_fast0.size:
                clear = image.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0)) if image is not None else (1.0, 1.0, 1.0, 0.0)
                clear_rgb0 = np.asarray(tuple(float(v) for v in clear[:3]), dtype=np.float32).reshape((1, 3))
                cur_rows0 = current[rows_fast0, :3]
                clear_like_fast0 = bool(np.any(np.logical_or(
                    np.max(np.abs(cur_rows0 - clear_rgb0), axis=1) <= (8.0 / 255.0),
                    np.logical_or(
                        np.max(np.abs(cur_rows0 - 1.0), axis=1) <= (8.0 / 255.0),
                        np.max(np.abs(cur_rows0 - 0.0), axis=1) <= (8.0 / 255.0),
                    ),
                )))
        except Exception:
            clear_like_fast0 = False
        # JELararagi 1.9.184: exact visible-master transfer for the common
        # top normal active-layer path.  Blender paints the public document
        # texture first; if the active layer is topmost and uses normal blend,
        # storing an inferred low-alpha/dark source is mathematically possible
        # but visibly wrong after visibility OFF/ON and PSD save/reload.  Store
        # the visible result exactly, and treat a clear/eraser-like master row as
        # an active-layer clear so black opaque pixels cannot be resurrected.
        try:
            if rows_fast0.size and (not all_layers_fast_probe) and (not alpha_loss_fast0):
                width_exact0, height_exact0, layers_exact0 = collect_layers(material, channel)
                if int(width_exact0) == int(mw) and int(height_exact0) == int(mh) and layers_exact0:
                    active_idx_exact0 = -1
                    active_item_exact0 = None
                    for _idx_exact0, _item_exact0 in enumerate(layers_exact0):
                        try:
                            _ly_exact0 = _item_exact0.get('layer')
                            if str(getattr(_ly_exact0, 'layer_id', '') or '') == str(layer_id or '') or _item_exact0.get('image') == image:
                                active_idx_exact0 = int(_idx_exact0)
                                active_item_exact0 = _item_exact0
                                break
                        except Exception:
                            pass
                    if active_item_exact0 is not None and active_idx_exact0 >= 0:
                        upper_blocking_exact0 = False
                        for _upper_exact0 in layers_exact0[active_idx_exact0 + 1:]:
                            try:
                                if bool(_upper_exact0.get('enabled', True)) and float(_upper_exact0.get('opacity', 1.0) or 0.0) > 1.0e-6:
                                    upper_blocking_exact0 = True
                                    break
                            except Exception:
                                upper_blocking_exact0 = True
                                break
                        mode_exact0 = str(active_item_exact0.get('blend_mode', 'MIX') or 'MIX').upper()
                        if (not upper_blocking_exact0) and mode_exact0 in {'MIX', 'NORMAL'} and not bool(active_item_exact0.get('clip_to_below', False)) and not bool(active_item_exact0.get('background', False)):
                            rows_exact0 = rows_fast0
                            if bool(clear_like_fast0 or eraser_brush_fast_probe):
                                try:
                                    clear0 = image.get('smart_paint_suite_clear_color', image.get('smart_paint_suite_initialized_clear_color', (1.0, 1.0, 1.0, 0.0)))
                                    clear_rgb0b = np.asarray(tuple(float(v) for v in clear0[:3]), dtype=np.float32).reshape((1, 3))
                                except Exception:
                                    clear_rgb0b = np.asarray((1.0, 1.0, 1.0), dtype=np.float32).reshape((1, 3))
                                layer_arr[rows_exact0, :3] = clear_rgb0b
                                layer_arr[rows_exact0, 3] = 0.0
                                _exact_flag0 = 'smart_paint_suite_exact_top_clear_commit'
                            else:
                                layer_arr[rows_exact0, :4] = np.clip(current[rows_exact0, :4], 0.0, 1.0)
                                _exact_flag0 = 'smart_paint_suite_exact_top_visible_commit'
                            ok_exact0 = bool(_write_image_array_np(image, layer_arr))
                            if ok_exact0:
                                try:
                                    xs0 = rows_exact0 % int(_image_size(image)[0] or 1)
                                    ys0 = rows_exact0 // int(_image_size(image)[0] or 1)
                                    image['smart_paint_suite_dirty_bbox'] = (int(np.min(xs0)), int(np.min(ys0)), int(np.max(xs0)) + 1, int(np.max(ys0)) + 1)
                                except Exception:
                                    pass
                                try:
                                    image['smart_paint_suite_dirty_from_master'] = True
                                    image['smart_paint_suite_alpha_authoritative'] = True
                                    image['smart_paint_suite_fast_visible_write'] = True
                                    image[_exact_flag0] = True
                                    image['smart_paint_suite_save_exact_baseline_delta'] = True
                                    image['smart_paint_suite_painted_since_last_projection'] = True
                                    image['smart_paint_suite_direct_layer_dirty'] = True
                                    for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                                        if prop in image:
                                            del image[prop]
                                except Exception:
                                    pass
                                return True
        except Exception:
            pass

        if rows_fast0.size and (not eraser_brush_fast_probe) and (not alpha_loss_fast0) and (not clear_like_fast0):
            try:
                width_fast, height_fast, layers_fast = collect_layers(material, channel)
                if int(width_fast) == int(mw) and int(height_fast) == int(mh) and layers_fast:
                    active_idx_fast = -1
                    active_item_fast = None
                    for _idx_fast, _item_fast in enumerate(layers_fast):
                        try:
                            _ly_fast = _item_fast.get('layer')
                            if str(getattr(_ly_fast, 'layer_id', '') or '') == str(layer_id or '') or _item_fast.get('image') == image:
                                active_idx_fast = int(_idx_fast)
                                active_item_fast = _item_fast
                        except Exception:
                            pass
                    if active_item_fast is not None and active_idx_fast >= 0:
                        upper_blocking = False
                        for _upper in layers_fast[active_idx_fast + 1:]:
                            try:
                                if bool(_upper.get('enabled', True)) and float(_upper.get('opacity', 1.0) or 0.0) > 1.0e-6:
                                    upper_blocking = True; break
                            except Exception:
                                upper_blocking = True; break
                        mode_fast = str(active_item_fast.get('blend_mode', 'MIX') or 'MIX').upper()
                        if (not upper_blocking) and mode_fast in {'MIX', 'NORMAL'} and not bool(active_item_fast.get('clip_to_below', False)):
                            under_rgb_fast = np.clip(baseline[rows_fast0, :3], 0.0, 1.0)
                            target_rgb_fast = np.clip(current[rows_fast0, :3], 0.0, 1.0)
                            old_rgb_fast = np.clip(layer_arr[rows_fast0, :3], 0.0, 1.0)
                            old_alpha_fast = np.clip(layer_arr[rows_fast0, 3], 0.0, 1.0)
                            try:
                                handled_brush_fast0 = _apply_known_brush_color_to_layer_rows(
                                    image,
                                    layer_arr,
                                    rows_fast0,
                                    under_rgb_fast,
                                    target_rgb_fast,
                                    old_rgb_fast,
                                    old_alpha_fast,
                                    baseline_alpha=np.clip(baseline[rows_fast0, 3], 0.0, 1.0),
                                    current_alpha=np.clip(current[rows_fast0, 3], 0.0, 1.0),
                                    tolerance=delta_tolerance,
                                    context=getattr(bpy, 'context', None),
                                )
                                if handled_brush_fast0 is not None and bool(np.any(handled_brush_fast0)):
                                    if bool(np.all(handled_brush_fast0)):
                                        ok_brush = bool(_write_image_array_np(image, layer_arr))
                                        if ok_brush:
                                            try:
                                                image['smart_paint_suite_exact_top_known_brush_commit'] = True
                                            except Exception:
                                                pass
                                        return bool(ok_brush)
                                    keep_brush = np.logical_not(handled_brush_fast0)
                                    rows_fast0 = rows_fast0[keep_brush]
                                    if rows_fast0.size <= 0:
                                        ok_brush = bool(_write_image_array_np(image, layer_arr))
                                        return bool(ok_brush)
                                    under_rgb_fast = under_rgb_fast[keep_brush]
                                    target_rgb_fast = target_rgb_fast[keep_brush]
                                    old_rgb_fast = old_rgb_fast[keep_brush]
                                    old_alpha_fast = old_alpha_fast[keep_brush]
                            except Exception:
                                pass
                            # SPS47: when Blender's master carries real alpha for a
                            # top normal active-layer brush stroke, use that alpha
                            # directly.  Do not re-infer coverage from RGB contrast;
                            # RGB inference turns soft brush edges into hard 1.0
                            # alpha and changes painted colours after toggles/saves.
                            try:
                                cur_alpha_fast = np.clip(current[rows_fast0, 3], 0.0, 1.0)
                                base_alpha_fast = np.clip(baseline[rows_fast0, 3], 0.0, 1.0)
                                pure_alpha_fast = cur_alpha_fast > (base_alpha_fast + delta_tolerance)
                                # Use visible-master alpha directly only for real
                                # fractional alpha strokes.  Some master images
                                # jump from alpha 0 to 1 while RGB still contains
                                # the brush coverage; treating that as source
                                # alpha=1 turns soft strokes into broken hard
                                # horizontal bands after visibility toggles.
                                pure_alpha_fast = np.logical_and(pure_alpha_fast, cur_alpha_fast < (1.0 - delta_tolerance))
                                if bool(np.any(pure_alpha_fast)):
                                    wr_alpha = rows_fast0[pure_alpha_fast]
                                    layer_arr[wr_alpha, :3] = np.clip(current[wr_alpha, :3], 0.0, 1.0)
                                    layer_arr[wr_alpha, 3] = np.clip(cur_alpha_fast[pure_alpha_fast], 0.0, 1.0)
                                    try:
                                        image['smart_paint_suite_dirty_from_master'] = True
                                        image['smart_paint_suite_alpha_authoritative'] = True
                                        image['smart_paint_suite_fast_visible_write'] = True
                                        image['smart_paint_suite_exact_top_alpha_commit'] = True
                                    except Exception:
                                        pass
                                    # If the whole brush footprint is pure alpha,
                                    # committing here is safe.  Mixed alpha/RGB
                                    # footprints must continue into the solver;
                                    # returning after only the alpha subset left
                                    # partially written scanlines, which appeared
                                    # as broken horizontal strokes after layer
                                    # visibility toggles.
                                    if bool(np.all(pure_alpha_fast)):
                                        ok_alpha = bool(_write_image_array_np(image, layer_arr))
                                        return bool(ok_alpha)
                                    keep_fast = np.logical_not(pure_alpha_fast)
                                    rows_fast0 = rows_fast0[keep_fast]
                                    if rows_fast0.size <= 0:
                                        ok_alpha = bool(_write_image_array_np(image, layer_arr))
                                        return bool(ok_alpha)
                                    under_rgb_fast = np.clip(baseline[rows_fast0, :3], 0.0, 1.0)
                                    target_rgb_fast = np.clip(current[rows_fast0, :3], 0.0, 1.0)
                                    old_rgb_fast = np.clip(layer_arr[rows_fast0, :3], 0.0, 1.0)
                                    old_alpha_fast = np.clip(layer_arr[rows_fast0, 3], 0.0, 1.0)
                            except Exception:
                                pass
                            src_rgb_fast, new_alpha_fast, solved_fast = _solve_active_pixels(
                                under_rgb_fast,
                                target_rgb_fast,
                                float(active_item_fast.get('opacity', 1.0) or 0.0),
                                mode_fast,
                                bool(active_item_fast.get('background', False)),
                                old_rgb_fast,
                                old_alpha_fast,
                            )
                            if bool(np.any(solved_fast)):
                                wr_fast = rows_fast0[solved_fast]
                                layer_arr[wr_fast, :3] = np.clip(src_rgb_fast[solved_fast], 0.0, 1.0)
                                layer_arr[wr_fast, 3] = np.clip(new_alpha_fast[solved_fast], 0.0, 1.0)
                                try:
                                    # If Blender wrote an actual alpha gradient to the
                                    # visible master, treat that alpha as authoritative.
                                    # The RGB inverse solver may otherwise infer full
                                    # coverage from color difference and destroy soft
                                    # brush edges when toggling/saving.
                                    alpha_changed_fast = np.abs(current[wr_fast, 3] - baseline[wr_fast, 3]) > delta_tolerance
                                    # Only overwrite solver coverage with master
                                    # alpha when that alpha is genuinely fractional.
                                    # Saturated 1.0 master alpha commonly represents
                                    # an opaque document target, not the brush's
                                    # source alpha.
                                    alpha_fractional_fast = np.logical_and(alpha_changed_fast, current[wr_fast, 3] < (1.0 - delta_tolerance))
                                    if bool(np.any(alpha_fractional_fast)):
                                        alpha_rows_fast = wr_fast[alpha_fractional_fast]
                                        layer_arr[alpha_rows_fast, :3] = np.clip(current[alpha_rows_fast, :3], 0.0, 1.0)
                                        layer_arr[alpha_rows_fast, 3] = np.clip(current[alpha_rows_fast, 3], 0.0, 1.0)
                                except Exception:
                                    pass
                                try:
                                    rgb_changed_fast = np.max(np.abs(current[wr_fast, :3] - baseline[wr_fast, :3]), axis=1) > delta_tolerance
                                    alpha_zero_fast = layer_arr[wr_fast, 3] <= delta_tolerance
                                    alpha_changed_fast = np.abs(current[wr_fast, 3] - baseline[wr_fast, 3]) > delta_tolerance
                                    rgb_only_fast = np.logical_and(rgb_changed_fast, np.logical_and(alpha_zero_fast, np.logical_not(alpha_changed_fast)))
                                    if bool(np.any(rgb_only_fast)):
                                        try:
                                            image['smart_paint_suite_rgb_only_master_delta_seen'] = True
                                        except Exception:
                                            pass
                                except Exception:
                                    pass
                                try:
                                    image['smart_paint_suite_dirty_from_master'] = True
                                    image['smart_paint_suite_alpha_authoritative'] = True
                                    image['smart_paint_suite_fast_visible_write'] = True
                                except Exception:
                                    pass
                                ok_fast = bool(_write_image_array_np(image, layer_arr))
                                if ok_fast:
                                    try:
                                        image['smart_paint_suite_dirty_from_master'] = True
                                        image['smart_paint_suite_alpha_authoritative'] = True
                                        image['smart_paint_suite_exact_top_commit_fastpath'] = True
                                    except Exception:
                                        pass
                                return bool(ok_fast)
            except Exception:
                pass

    base_rgb_all = np.clip(baseline[:, :3], 0.0, 1.0)
    cur_rgb_all = np.clip(current[:, :3], 0.0, 1.0)
    color_delta = np.max(np.abs(cur_rgb_all - base_rgb_all), axis=1)
    alpha_delta = np.abs(current[:, 3] - baseline[:, 3])

    try:
        all_layers_target = bool(_scene_layer_all_layers_enabled(getattr(bpy, 'context', None)))
    except Exception:
        all_layers_target = False
    changed_any = False
    if not all_layers_target:
        # Public Blender paint target is the document/master texture, but Smart
        # Paint's normal mode records the stroke on the active layer.  Eraser /
        # Alpha Erase is alpha loss on the master: apply that loss to the active
        # layer only, then recomposition restores all other layers in both the
        # Image Editor and the 3D View.
        try:
            eraser_brush_active = bool(_active_texture_paint_brush_is_eraser(getattr(bpy, 'context', None)))
        except Exception:
            eraser_brush_active = False
        alpha_loss_mask = np.logical_and(mask, current[:, 3] < (baseline[:, 3] - max(1.0 / 4096.0, float(tolerance))))
        try:
            clear = image.get('smart_paint_suite_clear_color', (1.0, 1.0, 1.0, 0.0)) if image is not None else (1.0, 1.0, 1.0, 0.0)
            clear_rgb_all = np.asarray(tuple(float(v) for v in clear[:3]), dtype=np.float32).reshape((1, 3))
            near_layer_clear = np.max(np.abs(current[:, :3] - clear_rgb_all), axis=1) <= (8.0 / 255.0)
            near_white_clear = np.max(np.abs(current[:, :3] - 1.0), axis=1) <= (8.0 / 255.0)
            near_black_clear = np.max(np.abs(current[:, :3] - 0.0), axis=1) <= (8.0 / 255.0)
            clear_color_mask = np.logical_and(mask, np.logical_or(near_layer_clear, np.logical_or(near_white_clear, near_black_clear)))
            clear_color_mask = np.logical_and(clear_color_mask, color_delta > max(1.0 / 4096.0, float(tolerance)))
        except Exception:
            clear_color_mask = np.zeros(mask.shape, dtype=bool)
        # Blender's eraser-like brushes do not always reduce alpha on the public
        # document texture on every platform/workspace; some erase by writing the
        # document clear color while keeping alpha unchanged.  If the active brush
        # is eraser/alpha-erase, treat the whole native master delta as an erase
        # request.  Even if brush metadata is unavailable, a delta that writes the
        # document clear color is handled as erase, because this is how Blender's
        # Texture Paint eraser appears in some workspaces.
        erase_mask = mask.copy() if eraser_brush_active else np.logical_or(alpha_loss_mask, clear_color_mask)
        paint_mask = np.logical_and(mask, np.logical_not(erase_mask))
        if bool(np.any(erase_mask)):
            erased = bool(_apply_alpha_erase_to_active(layer_arr, erase_mask, image))
            changed_any = erased or changed_any
            if erased:
                # Repairing the public document by a full stack composite can
                # materialize every lazy PSD layer and freeze Blender.  Do the
                # immediate per-pixel repair only for already-materialized light
                # stacks; lazy/heavy stacks restore the stable projection below
                # and update through the deferred projector.
                try:
                    from . import clean_layer_stack_engine as _clean
                    _lazy_or_heavy = bool(_clean._stack_has_lazy_layers(material, channel) or _clean._is_heavy_stack_for_sync(material, channel))
                except Exception:
                    _lazy_or_heavy = False
                # Always repair the public document image after an eraser
                # transfer.  The attached real PSD hair stack is a moderate
                # lazy-PSD stack; skipping this left the Image Editor with a
                # flattened alpha hole while the 3D View kept the old GPU
                # texture.  _refresh_master_pixels_from_stack() already uses
                # exact repair only for moderate stacks and falls back to a
                # deferred projection for truly heavy documents.
                _refresh_master_pixels_from_stack(erase_mask)
            # Re-read in case the eraser path wrote the buffer before a mixed
            # draw+erase stroke also needs direct paint transfer.
            try:
                fresh = _image_array_np(image)
                if fresh is not None and fresh.shape == layer_arr.shape:
                    layer_arr = fresh
            except Exception:
                pass
        if not bool(np.any(paint_mask)):
            return bool(changed_any)
        # Continue into the stack-aware inverse solver for normal paint deltas.
        # Directly copying the public master pixel into the active layer records
        # already-composited lower/upper layer colors as brush paint, which is
        # exactly what corrupts PSD layer saves.  The solver below reconstructs
        # the active layer source against the unchanged surrounding stack.
        mask = paint_mask
        try:
            fresh = _image_array_np(image)
            if fresh is not None and fresh.shape == layer_arr.shape:
                layer_arr = fresh
        except Exception:
            pass

        # Ultra-fast exact-baseline path for the common case: the selected paint
        # layer is topmost (or has no enabled upper layers) and uses normal blend.
        # This avoids building full per-layer stage_before/stage_after arrays just
        # to commit a small brush stroke before visibility toggle/save.
        try:
            if selection is None:
                width_fast, height_fast, layers_fast = collect_layers(material, channel)
                if int(width_fast) == int(mw) and int(height_fast) == int(mh) and layers_fast:
                    active_idx_fast = -1
                    active_item_fast = None
                    for _idx_fast, _item_fast in enumerate(layers_fast):
                        try:
                            _ly_fast = _item_fast.get('layer')
                            if str(getattr(_ly_fast, 'layer_id', '') or '') == str(layer_id or '') or _item_fast.get('image') == image:
                                active_idx_fast = int(_idx_fast)
                                active_item_fast = _item_fast
                        except Exception:
                            pass
                    if active_item_fast is not None and active_idx_fast >= 0:
                        upper_blocking = False
                        for _upper in layers_fast[active_idx_fast + 1:]:
                            try:
                                if bool(_upper.get('enabled', True)) and float(_upper.get('opacity', 1.0) or 0.0) > 1.0e-6:
                                    upper_blocking = True; break
                            except Exception:
                                upper_blocking = True; break
                        mode_fast = str(active_item_fast.get('blend_mode', 'MIX') or 'MIX').upper()
                        if (not upper_blocking) and mode_fast in {'MIX', 'NORMAL'} and not bool(active_item_fast.get('clip_to_below', False)):
                            rows_fast = np.nonzero(mask)[0]
                            if rows_fast.size > 0:
                                under_rgb_fast = np.clip(baseline[rows_fast, :3], 0.0, 1.0)
                                target_rgb_fast = np.clip(current[rows_fast, :3], 0.0, 1.0)
                                old_rgb_fast = np.clip(layer_arr[rows_fast, :3], 0.0, 1.0)
                                old_alpha_fast = np.clip(layer_arr[rows_fast, 3], 0.0, 1.0)
                                try:
                                    handled_brush_fast = _apply_known_brush_color_to_layer_rows(
                                        image,
                                        layer_arr,
                                        rows_fast,
                                        under_rgb_fast,
                                        target_rgb_fast,
                                        old_rgb_fast,
                                        old_alpha_fast,
                                        baseline_alpha=np.clip(baseline[rows_fast, 3], 0.0, 1.0),
                                        current_alpha=np.clip(current[rows_fast, 3], 0.0, 1.0),
                                        tolerance=tolerance,
                                        context=getattr(bpy, 'context', None),
                                    )
                                    if handled_brush_fast is not None and bool(np.any(handled_brush_fast)):
                                        if bool(np.all(handled_brush_fast)):
                                            ok_brush = bool(_write_image_array_np(image, layer_arr))
                                            if ok_brush:
                                                try:
                                                    image['smart_paint_suite_exact_top_known_brush_commit'] = True
                                                except Exception:
                                                    pass
                                            return bool(ok_brush)
                                        keep_brush = np.logical_not(handled_brush_fast)
                                        rows_fast = rows_fast[keep_brush]
                                        if rows_fast.size <= 0:
                                            ok_brush = bool(_write_image_array_np(image, layer_arr))
                                            return bool(ok_brush)
                                        under_rgb_fast = under_rgb_fast[keep_brush]
                                        target_rgb_fast = target_rgb_fast[keep_brush]
                                        old_rgb_fast = old_rgb_fast[keep_brush]
                                        old_alpha_fast = old_alpha_fast[keep_brush]
                                except Exception:
                                    pass
                                # SPS47: prefer real master alpha over RGB-derived
                                # coverage when committing a top normal brush stroke.
                                try:
                                    cur_alpha_fast = np.clip(current[rows_fast, 3], 0.0, 1.0)
                                    base_alpha_fast = np.clip(baseline[rows_fast, 3], 0.0, 1.0)
                                    tol_fast_alpha = max(1.0 / 4096.0, float(tolerance))
                                    pure_alpha_fast = cur_alpha_fast > (base_alpha_fast + tol_fast_alpha)
                                    pure_alpha_fast = np.logical_and(pure_alpha_fast, cur_alpha_fast < (1.0 - tol_fast_alpha))
                                    if bool(np.any(pure_alpha_fast)):
                                        wr_alpha = rows_fast[pure_alpha_fast]
                                        layer_arr[wr_alpha, :3] = np.clip(current[wr_alpha, :3], 0.0, 1.0)
                                        layer_arr[wr_alpha, 3] = np.clip(cur_alpha_fast[pure_alpha_fast], 0.0, 1.0)
                                        try:
                                            image['smart_paint_suite_dirty_from_master'] = True
                                            image['smart_paint_suite_alpha_authoritative'] = True
                                            image['smart_paint_suite_fast_visible_write'] = True
                                            image['smart_paint_suite_exact_top_alpha_commit'] = True
                                        except Exception:
                                            pass
                                        # Do not return after committing only
                                        # alpha-changing rows.  Mixed brush
                                        # footprints must continue solving the
                                        # remaining rows, otherwise visibility
                                        # toggles can expose horizontal bands.
                                        if bool(np.all(pure_alpha_fast)):
                                            ok_alpha = bool(_write_image_array_np(image, layer_arr))
                                            return bool(ok_alpha or changed_any)
                                        keep_fast = np.logical_not(pure_alpha_fast)
                                        rows_fast = rows_fast[keep_fast]
                                        if rows_fast.size <= 0:
                                            ok_alpha = bool(_write_image_array_np(image, layer_arr))
                                            return bool(ok_alpha or changed_any)
                                        under_rgb_fast = np.clip(baseline[rows_fast, :3], 0.0, 1.0)
                                        target_rgb_fast = np.clip(current[rows_fast, :3], 0.0, 1.0)
                                        old_rgb_fast = np.clip(layer_arr[rows_fast, :3], 0.0, 1.0)
                                        old_alpha_fast = np.clip(layer_arr[rows_fast, 3], 0.0, 1.0)
                                except Exception:
                                    pass
                                src_rgb_fast, new_alpha_fast, solved_fast = _solve_active_pixels(
                                    under_rgb_fast,
                                    target_rgb_fast,
                                    float(active_item_fast.get('opacity', 1.0) or 0.0),
                                    mode_fast,
                                    bool(active_item_fast.get('background', False)),
                                    old_rgb_fast,
                                    old_alpha_fast,
                                )
                                if bool(np.any(solved_fast)):
                                    wr_fast = rows_fast[solved_fast]
                                    layer_arr[wr_fast, :3] = np.clip(src_rgb_fast[solved_fast], 0.0, 1.0)
                                    layer_arr[wr_fast, 3] = np.clip(new_alpha_fast[solved_fast], 0.0, 1.0)
                                    try:
                                        tol_fast = max(1.0 / 4096.0, float(tolerance))
                                        alpha_changed_fast = np.abs(current[wr_fast, 3] - baseline[wr_fast, 3]) > tol_fast
                                        alpha_fractional_fast = np.logical_and(alpha_changed_fast, current[wr_fast, 3] < (1.0 - tol_fast))
                                        if bool(np.any(alpha_fractional_fast)):
                                            alpha_rows_fast = wr_fast[alpha_fractional_fast]
                                            layer_arr[alpha_rows_fast, :3] = np.clip(current[alpha_rows_fast, :3], 0.0, 1.0)
                                            layer_arr[alpha_rows_fast, 3] = np.clip(current[alpha_rows_fast, 3], 0.0, 1.0)
                                    except Exception:
                                        pass
                                    try:
                                        tol_fast = max(1.0 / 4096.0, float(tolerance))
                                        rgb_changed_fast = np.max(np.abs(current[wr_fast, :3] - baseline[wr_fast, :3]), axis=1) > tol_fast
                                        alpha_zero_fast = layer_arr[wr_fast, 3] <= tol_fast
                                        alpha_changed_fast = np.abs(current[wr_fast, 3] - baseline[wr_fast, 3]) > tol_fast
                                        rgb_only_fast = np.logical_and(rgb_changed_fast, np.logical_and(alpha_zero_fast, np.logical_not(alpha_changed_fast)))
                                        if bool(np.any(rgb_only_fast)):
                                            try:
                                                image['smart_paint_suite_rgb_only_master_delta_seen'] = True
                                            except Exception:
                                                pass
                                    except Exception:
                                        pass
                                    try:
                                        image['smart_paint_suite_dirty_from_master'] = True
                                        image['smart_paint_suite_alpha_authoritative'] = True
                                        image['smart_paint_suite_fast_visible_write'] = True
                                    except Exception:
                                        pass
                                    ok_fast = bool(_write_image_array_np(image, layer_arr))
                                    if ok_fast:
                                        try:
                                            image['smart_paint_suite_dirty_from_master'] = True
                                            image['smart_paint_suite_alpha_authoritative'] = True
                                            image['smart_paint_suite_exact_top_commit_fastpath'] = True
                                        except Exception:
                                            pass
                                    return bool(ok_fast or changed_any)
        except Exception:
            pass

    # Build explicit stack context so alpha-affecting strokes can be solved
    # against the selected layer only instead of being merged as if they came
    # from the flattened document.
    try:
        _snapshot_ctx = _use_master_paint_layers_snapshot(layers_snapshot, int(mw), int(mh))
        if _snapshot_ctx is not None:
            width, height, layers = _snapshot_ctx
        else:
            width, height, layers = collect_layers(material, channel)
    except Exception:
        width = height = 0
        layers = []
    if int(width) != int(mw) or int(height) != int(mh) or not layers:
        return bool(changed_any or _legacy_apply(layer_arr, mask, base_rgb_all, cur_rgb_all, current[:, 3], baseline[:, 3], image))

    base = np.zeros((int(width) * int(height), 3), dtype=np.float32)
    base[:, :] = 1.0
    stage_before = []
    stage_after = []
    compiled = []
    active_index = -1
    out = base.copy()
    for idx, item in enumerate(layers):
        arr_i = _read_image_array(item['image'], width, height)
        if arr_i is None or getattr(arr_i, 'shape', None) != (int(width) * int(height), 4):
            arr_i = np.zeros((int(width) * int(height), 4), dtype=np.float32)
        alpha_i = _layer_image_alpha_for_paint(arr_i, background=bool(item.get('background')), image=item.get('image'))
        if alpha_i is None:
            alpha_i = np.zeros((int(width) * int(height),), dtype=np.float32)
        alpha_i = np.clip(alpha_i.astype(np.float32, copy=False) * float(item.get('opacity', 1.0) or 0.0), 0.0, 1.0)
        src_i = np.clip(arr_i[:, :3], 0.0, 1.0).astype(np.float32, copy=False)
        stage_before.append(out.copy())
        if bool(item.get('enabled', True)):
            out = _blend_rgb(out, src_i, alpha_i, item.get('blend_mode', 'MIX'))
        stage_after.append(out.copy())
        rec = dict(item)
        rec['arr'] = arr_i
        rec['alpha'] = alpha_i
        rec['src'] = src_i
        compiled.append(rec)
        try:
            item_layer = rec.get('layer')
            item_layer_id = str(getattr(item_layer, 'layer_id', '') or '') if item_layer is not None else ''
            if item_layer_id == str(layer_id or '') or rec.get('image') == image:
                active_index = idx
        except Exception:
            pass
    if active_index < 0 or active_index >= len(compiled):
        return bool(changed_any or _legacy_apply(layer_arr, mask, base_rgb_all, cur_rgb_all, current[:, 3], baseline[:, 3], image))

    target_mid = cur_rgb_all.copy()
    solvable = mask.copy()
    for idx in range(len(compiled) - 1, active_index, -1):
        item = compiled[idx]
        desired_before, solved_here = _invert_upper_step(target_mid, item['src'], item['alpha'], item.get('blend_mode', 'MIX'), stage_before[idx])
        # Only pixels that remain mathematically reachable through unchanged
        # upper layers may modify the selected layer.
        target_mid[solvable] = desired_before[solvable]
        solvable = np.logical_and(solvable, solved_here)
        if not bool(np.any(solvable)):
            break

    mod_mask = np.logical_and(mask, solvable)
    if not bool(np.any(mod_mask)):
        # The active layer may be hidden below opaque upper layers.  A Photoshop-
        # style layer stack still records the stroke on the active layer even if
        # the visible composite will not show it until upper layers are hidden.
        return bool(changed_any or _direct_project_to_active(layer_arr, mask, image) or True)

    active_item = compiled[active_index]
    under_rgb = stage_before[active_index][mod_mask]
    desired_rgb = target_mid[mod_mask]
    old_rgb = np.clip(layer_arr[mod_mask, :3], 0.0, 1.0)
    old_alpha = np.clip(layer_arr[mod_mask, 3], 0.0, 1.0)
    src_rgb, new_alpha, solved_active = _solve_active_pixels(
        under_rgb,
        desired_rgb,
        float(active_item.get('opacity', 1.0) or 0.0),
        active_item.get('blend_mode', 'MIX'),
        bool(active_item.get('background')),
        old_rgb,
        old_alpha,
    )
    if not bool(np.any(solved_active)):
        return bool(changed_any or _direct_project_to_active(layer_arr, mod_mask, image) or _legacy_apply(layer_arr, mod_mask, base_rgb_all, cur_rgb_all, current[:, 3], baseline[:, 3], image))

    write_mask = np.zeros(layer_arr.shape[0], dtype=bool)
    write_mask_indices = np.nonzero(mod_mask)[0]
    write_mask[write_mask_indices[solved_active]] = True
    if not bool(np.any(write_mask)):
        return True

    layer_arr[write_mask, :3] = np.clip(src_rgb[solved_active], 0.0, 1.0)
    layer_arr[write_mask, 3] = np.clip(new_alpha[solved_active], 0.0, 1.0)
    # Save/paint correctness guard: if the solved active-source color changed
    # but the solver ended at zero alpha, Blender would serialize that brush as
    # a white/transparent PSD layer.  For normal paint deltas, RGB change means
    # the active layer must own visible alpha.  Eraser strokes are handled above
    # and do not pass through this branch.
    try:
        _rows = np.nonzero(write_mask)[0]
        _rgb_changed = np.max(np.abs(cur_rgb_all[_rows, :3] - base_rgb_all[_rows, :3]), axis=1) > max(1.0 / 4096.0, float(tolerance))
        _alpha_zero = layer_arr[_rows, 3] <= max(1.0 / 4096.0, float(tolerance))
        if bool(np.any(np.logical_and(_rgb_changed, _alpha_zero))):
            # Alpha is authoritative in the current layer pipeline.  Do not
            # synthesize opacity from RGB-only deltas here; that fallback produced
            # white or horizontal broken bands after visibility toggles on new
            # layers.  RGB-only deltas are only marked for diagnostics.
            try:
                image['smart_paint_suite_rgb_only_master_delta_seen'] = True
            except Exception:
                pass
    except Exception:
        pass
    ok = _write_image_array_np(image, layer_arr)
    if ok:
        try:
            image['smart_paint_suite_dirty_from_master'] = True
            image['smart_paint_suite_alpha_authoritative'] = True
        except Exception:
            pass
    return bool(ok or changed_any)


def _restore_master_projection_snapshot_if_heavy(material, channel: str, fallback_arr) -> bool:
    """Prevent native eraser strokes from leaving the flattened master erased.

    Heavy/lazy stacks are recomposed asynchronously.  If the public master keeps
    the native eraser's alpha hole until that async job finishes, the user sees
    all layers disappear.  Restore the last stable projection immediately; the
    queued projection then displays the active-layer-only erase result.
    """
    if material is None or fallback_arr is None:
        return False
    try:
        from . import clean_layer_stack_engine as _clean
        heavy = bool(_clean._is_heavy_stack_for_sync(material, channel) or _clean._stack_has_lazy_layers(material, channel))
    except Exception:
        heavy = False
    if not heavy:
        return False
    try:
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        import numpy as np
        arr = np.asarray(fallback_arr, dtype=np.float32).reshape((-1, 4))
        mw, mh = _image_size(master)
        if int(arr.shape[0]) != int(mw) * int(mh):
            return False
        ok = bool(_write_image_array_np(master, arr))
        if ok:
            try:
                master['smart_paint_suite_restored_projection_after_native_paint'] = True
            except Exception:
                pass
        return ok
    except Exception:
        return False

def commit_master_paint_session(material, channel: str = 'BASE_COLOR', *, restart: bool = True, recompose: bool = True, force: bool = False, tolerance: float = 1.0 / 1024.0, allow_stack_mismatch_exact_baseline: bool = False) -> bool:
    """Commit visible-master paint into the selected Smart Paint layer.

    Freeze-safe algorithm:
    - UI layer switches never force a full pixel read when the sampled master did
      not change.
    - Lazy sessions avoid storing a full master copy after every display sync.
    - If a paint-like operator or a sample change is detected, the expensive
      compare is performed exactly once and only then recomposited.
    """
    _j2_t0 = time.perf_counter()
    _j2_channel = _safe_channel(channel)
    _j2_applied = None
    _j2_changed = False

    def _j2_callers():
        # Structured diagnostics intentionally avoid traceback capture in normal
        # operation.  Tests can correlate the explicit event/reason fields.
        return []

    def _j2_exit(result: bool, reason: str):
        try:
            _trace_paint_busy(
                'commit_master_paint_session_exit',
                material=str(getattr(material, 'name', '') or ''),
                channel=_j2_channel,
                result=bool(result),
                reason=str(reason or ''),
                duration_ms=round((time.perf_counter() - _j2_t0) * 1000.0, 3),
                applied=_j2_applied,
                changed=bool(_j2_changed),
                restart=bool(restart),
                recompose=bool(recompose),
                force=bool(force),
                callers=_j2_callers(),
            )
        except Exception:
            pass
        return bool(result)

    try:
        _trace_paint_busy(
            'commit_master_paint_session_entry',
            material=str(getattr(material, 'name', '') or ''),
            channel=_j2_channel,
            restart=bool(restart),
            recompose=bool(recompose),
            force=bool(force),
            tolerance=float(tolerance),
            allow_stack_mismatch_exact_baseline=bool(allow_stack_mismatch_exact_baseline),
            callers=_j2_callers(),
        )
    except Exception:
        pass
    if material is None:
        return _j2_exit(False, 'no_material')
    channel = _j2_channel
    key = _session_key(material, channel)
    session = _MASTER_PAINT_SESSIONS.get(key)
    master = get_master_texture_image(material, channel, create=False)
    if master is None:
        return _j2_exit(False, 'no_master')
    # Local exact-baseline request flag.  Older optimized builds referenced this
    # name without initializing it, causing the save/toggle commit path to fall
    # through a broad exception before setting up deterministic live baselines.
    capture_pixels = False

    sample = _image_sample_stamp(master, 96)
    paint_token = _current_paint_operator_token()
    paint_event = bool(paint_token and (session is None or str(session.get('paint_op_token', '') or '') != paint_token))
    if session is not None:
        try:
            old_sample = tuple(session.get('sample_stamp', ()))
            if old_sample and tuple(sample) == old_sample and not paint_event and not bool(force):
                if restart:
                    session['layer_id'] = _active_layer_id(material)
                    session['sample_stamp'] = sample
                    session['stamp'] = sample
                    session['baseline'] = None
                    session['lazy'] = True
                    if paint_token:
                        session['paint_op_token'] = paint_token
                return _j2_exit(False, 'same_sample_no_paint_event')
        except Exception:
            pass
    elif not paint_event and not bool(force):
        if restart:
            _MASTER_PAINT_SESSIONS[key] = {'baseline': None, 'layer_id': _active_layer_id(material), 'stamp': sample, 'sample_stamp': sample, 'lazy': True, 'paint_op_token': paint_token, 'stack_signature': _master_session_stack_signature(material, channel), 'layers_snapshot': _master_paint_layers_snapshot(material, channel), 'brush_rgb': _rgb_tuple_or_none(_active_texture_paint_brush_rgb(getattr(bpy, 'context', None)))}
        return _j2_exit(False, 'new_lazy_session_no_paint_event')

    current = _image_array_np(master, use_cache=False)
    if current is None:
        return _j2_exit(False, 'master_read_failed')
    current_stamp = _array_sample_stamp(current, *(_image_size(master) if master is not None else (0, 0)), samples=96)

    changed = False
    baseline = session.get('baseline') if session is not None else None
    # Resolve the intended private layer before any stack-signature guard.  A
    # visibility/mask/group toggle changes the signature, but an exact baseline
    # session is still a real active-layer brush delta and must be preserved.
    layer_id = (str(session.get('layer_id', '') or '') if session is not None else '') or _active_layer_id(material)
    layers_snapshot = None
    try:
        if session is not None and baseline is not None:
            layers_snapshot = session.get('layers_snapshot')
    except Exception:
        layers_snapshot = None
    try:
        if session is not None:
            old_stack_sig = str(session.get('stack_signature', '') or '')
            new_stack_sig = _master_session_stack_signature(material, channel)
            # Never replay a visible-master delta against a different private layer
            # stack.  The flattened preview may legitimately differ after layer
            # add/remove/reorder/visibility changes, and applying that difference
            # to a layer corrupts PSD export.
            if old_stack_sig and new_stack_sig and old_stack_sig != new_stack_sig:
                exact_baseline_safe = False
                try:
                    exact_baseline_safe = bool(
                        allow_stack_mismatch_exact_baseline
                        and baseline is not None
                        and str(layer_id or '') == str(_active_layer_id(material) or '')
                    )
                except Exception:
                    exact_baseline_safe = False
                if not exact_baseline_safe:
                    if restart:
                        _MASTER_PAINT_SESSIONS[key] = {
                            'baseline': None,
                            'layer_id': _active_layer_id(material),
                            'stamp': sample,
                            'sample_stamp': sample,
                            'lazy': True,
                            'paint_op_token': paint_token,
                            'stack_signature': new_stack_sig,
                            'layers_snapshot': _master_paint_layers_snapshot(material, channel),
                        }
                    return _j2_exit(False, 'stack_signature_changed')
            if not old_stack_sig and new_stack_sig and session.get('baseline') is None and bool(force):
                if restart:
                    _MASTER_PAINT_SESSIONS[key] = {
                        'baseline': None,
                        'layer_id': _active_layer_id(material),
                        'stamp': sample,
                        'sample_stamp': sample,
                        'lazy': True,
                        'paint_op_token': paint_token,
                        'stack_signature': new_stack_sig,
                    }
                return _j2_exit(False, 'force_without_exact_baseline')
    except Exception:
        pass
    try:
        import numpy as np
        if baseline is not None and getattr(baseline, 'shape', None) == current.shape:
            delta_mask = np.max(np.abs(current[:, :4] - baseline[:, :4]), axis=1) > max(1.0 / 4096.0, float(tolerance))
            if bool(np.any(delta_mask)):
                applied = bool(_apply_master_delta_to_layer(material, channel, layer_id, baseline, current, tolerance=tolerance, layers_snapshot=layers_snapshot))
                _j2_applied = bool(applied)
                changed = bool(applied)
                _j2_changed = bool(changed)
        else:
            width, height, composite = composite_layer_arrays(material, channel)
            if composite is not None and composite.shape == current.shape:
                delta_mask = np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1) > max(1.0 / 4096.0, float(tolerance))
                if bool(np.any(delta_mask)):
                    applied = bool(_apply_master_delta_to_layer(material, channel, layer_id, composite, current, tolerance=tolerance))
                    _j2_applied = bool(applied)
                    changed = bool(applied)
                    _j2_changed = bool(changed)
    except Exception:
        changed = False
        _j2_changed = False

    if changed and recompose:
        try:
            # Selection safety: Blender may have written outside the Smart Paint
            # selection to the public master before our post-clip pass runs.  Even
            # when the active-layer delta is handled as an eraser and the touched
            # selected pixels are locally repaired, outside-selection pixels must
            # be rebuilt from the stack.  Do this synchronously for moderate docs;
            # large docs fall back to the deferred projection queue.
            if has_selection_mask(material, channel):
                from . import clean_layer_stack_engine as _clean
                try:
                    for _prop in (_stack_signature_prop(channel), 'sps_projection_cache_signature_' + _safe_channel(channel)):
                        if _prop in material:
                            del material[_prop]
                except Exception:
                    pass
                if not bool(_clean._is_heavy_stack_for_sync(material, channel) or _clean._stack_has_lazy_layers(material, channel)):
                    # Force an exact projection write.  The projection cache can
                    # legitimately still match when the only visible change was a
                    # rejected outside-selection master stroke, so bypass the
                    # cache and write the freshly composited stack to the public
                    # document image directly.
                    try:
                        _cw, _ch, _comp = composite_layer_arrays(material, channel)
                        _master = get_master_texture_image(material, channel, create=False)
                        if _master is not None and _comp is not None and getattr(_comp, 'shape', None) == current.shape:
                            _write_image_array_np(_master, _comp)
                        else:
                            _clean._write_composite_to_master_sync(material, channel)
                    except Exception:
                        _clean._write_composite_to_master_sync(material, channel)
                else:
                    _clean._schedule_deferred_composite(material, channel)
        except Exception:
            pass
        skip_full_recompose = False
        try:
            skip_key = 'sps_skip_full_recompose_after_active_eraser_' + channel
            skip_full_recompose = bool(material.get(skip_key, False))
            if skip_key in material:
                del material[skip_key]
        except Exception:
            skip_full_recompose = False
        try:
            for prop in (_stack_signature_prop(channel), 'sps_projection_cache_signature_' + _safe_channel(channel)):
                try:
                    if prop in material:
                        del material[prop]
                except Exception:
                    pass
        except Exception:
            pass
        if not skip_full_recompose:
            try:
                fallback_projection = baseline if baseline is not None and getattr(baseline, 'shape', None) == current.shape else None
                if fallback_projection is None:
                    try:
                        _fw, _fh, _fc = composite_layer_arrays(material, channel)
                        if _fc is not None and getattr(_fc, 'shape', None) == current.shape:
                            fallback_projection = _fc
                    except Exception:
                        fallback_projection = None
                _restore_master_projection_snapshot_if_heavy(material, channel, fallback_projection)
            except Exception:
                pass
        try:
            if not skip_full_recompose:
                try:
                    recent_eraser = (time.time() - float(material.get('sps_last_master_delta_alpha_erase_' + channel, 0.0) or 0.0)) < 2.0
                except Exception:
                    recent_eraser = False
                if recent_eraser:
                    try:
                        from . import clean_layer_stack_engine as _clean
                        if bool(_clean._stack_has_lazy_layers(material, channel) or _clean._is_heavy_stack_for_sync(material, channel)):
                            write_composite_to_master(material, channel)
                        else:
                            _clean._write_composite_to_master_sync(material, channel)
                    except Exception:
                        write_composite_to_master(material, channel)
                else:
                    write_composite_to_master(material, channel)
            master = get_master_texture_image(material, channel, create=False)
            if master is not None:
                current_stamp = _image_sample_stamp(master, 96)
            try:
                from .clean_layer_stack_engine import force_document_texture_refresh
                force_document_texture_refresh(material, channel, getattr(bpy, 'context', None), show_editors=True, switch_to_paint=False, force_gpu=True)
            except Exception:
                try:
                    sync_document_texture_target(material, channel, getattr(bpy, 'context', None), show_editors=True, switch_to_paint=False)
                except Exception:
                    pass
        except Exception:
            pass
    if restart:
        baseline_next = None
        lazy_next = True
        try:
            master_next = get_master_texture_image(material, channel, create=False)
            need_exact = False
            try:
                need_exact = bool(has_selection_mask(material, channel))
            except Exception:
                need_exact = False
            try:
                # While the document image is an active Image Editor / Texture Paint
                # target, keep an exact baseline for moderate documents.  This is
                # essential for consecutive eraser strokes: otherwise the next
                # alpha erase can only be compared against a lazily rebuilt stack
                # and may remain as a flattened hole in the Image Editor or be
                # invisible in the 3D View.
                need_exact = bool(need_exact or (_live_master_session_active(master_next) and _live_master_exact_baseline_allowed(master_next)))
            except Exception:
                pass
            if need_exact:
                baseline_next = _image_array_np(master_next, use_cache=False) if master_next is not None else None
                if baseline_next is not None:
                    current_stamp = _array_crc_stamp(master_next, baseline_next)
                    lazy_next = False
        except Exception:
            baseline_next = None
            lazy_next = True
        _MASTER_PAINT_SESSIONS[key] = {
            'baseline': baseline_next.copy() if baseline_next is not None else None,
            'layer_id': _active_layer_id(material),
            'stamp': current_stamp,
            'sample_stamp': _array_sample_stamp(baseline_next, *(_image_size(master)), samples=96) if baseline_next is not None and master is not None else current_stamp,
            'lazy': lazy_next,
            'paint_op_token': paint_token,
            'stack_signature': _master_session_stack_signature(material, channel),
            'layers_snapshot': _master_paint_layers_snapshot(material, channel),
            'brush_rgb': _rgb_tuple_or_none(_active_texture_paint_brush_rgb(getattr(bpy, 'context', None))),
        }
    _j2_changed = bool(changed)
    return _j2_exit(bool(changed), 'done')


def _visible_master_is_stale_active_layer_hidden_projection(material, channel: str, current, composite, layer_id: str = '', *, tolerance: float = 2.0 / 255.0) -> bool:
    """Return True when the live master is an old preview with the active layer hidden.

    Save/toggle preflight must not interpret this stale preview as an eraser
    stroke.  This happens after users disable/re-enable a layer: the private layer
    pixels are correct, but the public master can still contain the previous
    hidden-layer projection until the next redraw.  Flattening that delta into the
    active layer clears the brush alpha.
    """
    np = _np_module()
    if np is None or material is None or current is None or composite is None:
        return False
    try:
        ch = _safe_channel(channel)
        target_id = str(layer_id or '') or _active_layer_id(material)
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None or not target_id:
            return False
        layer_item = None
        for layer in getattr(settings, 'layers', ()) or ():
            try:
                if str(getattr(layer, 'layer_id', '') or '') == str(target_id):
                    layer_item = layer
                    break
            except Exception:
                continue
        if layer_item is None:
            return False
        current = np.asarray(current, dtype=np.float32).reshape((-1, 4))
        composite = np.asarray(composite, dtype=np.float32).reshape((-1, 4))
        if getattr(current, 'shape', None) != getattr(composite, 'shape', None):
            return False
        # Only a real mismatch is relevant.
        tol = max(float(tolerance), 2.0 / 255.0)
        if not bool(np.any(np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1) > tol)):
            return False
        enabled_attr = layer_channel_enabled_attr(ch)
        old_enabled = bool(getattr(layer_item, 'enabled', True))
        try:
            old_ch_enabled = bool(getattr(layer_item, enabled_attr, True))
        except Exception:
            old_ch_enabled = None
        suspend_old = None
        try:
            from .properties import suspend_layer_rebuilds
            suspend_old = suspend_layer_rebuilds(True)
        except Exception:
            suspend_layer_rebuilds = None
            suspend_old = None
        try:
            try:
                layer_item.enabled = False
            except Exception:
                pass
            try:
                if old_ch_enabled is not None:
                    setattr(layer_item, enabled_attr, False)
            except Exception:
                pass
            _dw, _dh, disabled_projection = composite_layer_arrays(material, ch)
        finally:
            try:
                layer_item.enabled = old_enabled
            except Exception:
                pass
            try:
                if old_ch_enabled is not None:
                    setattr(layer_item, enabled_attr, old_ch_enabled)
            except Exception:
                pass
            try:
                if suspend_layer_rebuilds is not None:
                    suspend_layer_rebuilds(bool(suspend_old))
            except Exception:
                pass
        if disabled_projection is None or getattr(disabled_projection, 'shape', None) != getattr(current, 'shape', None):
            return False
        hidden_diff = float(np.max(np.abs(np.asarray(disabled_projection, dtype=np.float32).reshape((-1, 4))[:, :4] - current[:, :4])))
        return bool(hidden_diff <= tol)
    except Exception:
        return False


def commit_untracked_master_paint_to_active_layer(material, channel: str = 'BASE_COLOR', *, allow_session: bool = False, layer_id_override: str = '', tolerance: float = 1.0 / 1024.0) -> bool:
    """Preserve master-texture paint that was made outside an active session.

    Blender's native Texture Paint writes into the visible master image.  If a
    Shift-line helper starts while a normal stroke has not yet been committed to
    the selected Smart Paint layer, rebuilding the master from the layer stack
    would erase that normal stroke.  When no tracked session exists, compare the
    current master against the layer-stack composite and transfer only the
    difference to the active layer before any rebuild happens.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    channel = _safe_channel(channel)
    key = _session_key(material, channel)
    session = _MASTER_PAINT_SESSIONS.get(key)
    if session is not None and not bool(allow_session):
        return False
    master = _live_master_image_for_paint_commit(material, channel, session)
    if master is None:
        return False
    current = _image_array_np(master, use_cache=False)
    if current is None:
        return False
    width, height, composite = composite_layer_arrays(material, channel)
    if composite is None:
        return False
    try:
        mw, mh = _image_size(master)
        if int(width) != int(mw) or int(height) != int(mh):
            return False
        if composite.shape != current.shape:
            return False
        # Treat untracked master recovery as a save/toggle safety net, not as a
        # projection quantization corrector.  Sub-8-bit differences between the
        # master and stack are expected after PSD roundtrips and must not be
        # inverse-solved into the active layer.
        tol = max(2.0 / 255.0, float(tolerance))
        diff = np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1)
        if not bool(np.any(diff > tol)):
            return False
        layer_id = str(layer_id_override or '') or (str(session.get('layer_id', '') or '') if session is not None else '') or _active_layer_id(material)
        if _visible_master_is_stale_active_layer_hidden_projection(material, channel, current, composite, layer_id, tolerance=tol):
            return False
        try:
            _layer_existing, _image_existing = _layer_image_for_session(material, layer_id, channel)
            _arr_existing = _image_array_np(_image_existing, use_cache=False) if _image_existing is not None else None
            if _arr_existing is not None and getattr(_arr_existing, 'shape', None) == getattr(current, 'shape', None):
                _alpha_existing = np.clip(np.asarray(_arr_existing, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                _delta_mask = diff > tol
                _delta_count = int(np.count_nonzero(_delta_mask))
                if _delta_count > 0 and int(np.count_nonzero(_alpha_existing > (1.0 / 4096.0))) > 0:
                    _overlap = int(np.count_nonzero(np.logical_and(_delta_mask, _alpha_existing > (1.0 / 4096.0))))
                    if (_overlap / float(max(1, _delta_count))) >= 0.80:
                        return False
        except Exception:
            pass
        try:
            _layer_existing, _image_existing = _layer_image_for_session(material, layer_id, channel)
            _arr_existing = _image_array_np(_image_existing, use_cache=False) if _image_existing is not None else None
            if _arr_existing is not None and getattr(_arr_existing, 'shape', None) == getattr(current, 'shape', None):
                _alpha_existing = np.clip(np.asarray(_arr_existing, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                _has_private_alpha = bool(np.any(_alpha_existing > (1.0 / 4096.0)))
                _delta_mask = diff > tol
                _changed_count = int(np.count_nonzero(_delta_mask))
                _total_count = int(_delta_mask.shape[0]) if getattr(_delta_mask, 'shape', None) is not None else 0
                if _has_private_alpha and _total_count > 0 and (_changed_count / float(_total_count)) > 0.35:
                    return False
        except Exception:
            pass
        _apply_master_delta_to_layer(material, channel, layer_id, composite, current, tolerance=tol)
        # A visible-master delta must never be left on the master when All Layers
        # Target is OFF.  Return True so callers recomposite from the stack even
        # if the selected layer could not accept the delta.
        return True
    except Exception:
        return False


def _direct_commit_baseline_master_delta_to_active_layer_for_save(material, channel: str, layer_id: str, baseline, current, mask, *, tolerance: float = 2.0 / 255.0, reason: str = '') -> bool:
    """Commit a bounded exact master-baseline delta directly into the active layer.

    This is used only at explicit Save boundaries.  It avoids the generic inverse
    solver for the Add Layer -> native Texture Paint -> Save workflow, where the
    public/master image contains the new stroke but the layer stack projection can
    differ broadly from the flattened PSD preview on production files.
    """
    try:
        np = _np_module()
        if np is None or material is None or baseline is None or current is None or mask is None:
            return False
        ch = _safe_channel(channel)
        tol = max(1.0 / 4096.0, float(tolerance))
        base = np.asarray(baseline, dtype=np.float32).reshape((-1, 4))
        cur = np.asarray(current, dtype=np.float32).reshape((-1, 4))
        if getattr(base, 'shape', None) != getattr(cur, 'shape', None):
            return False
        m = np.asarray(mask, dtype=bool).reshape((-1,))
        if int(m.shape[0]) != int(cur.shape[0]):
            return False
        rows = np.nonzero(m)[0]
        if rows.size <= 0:
            return False
        total = int(cur.shape[0])
        # This path is exact-baseline based, so it may safely handle strokes larger
        # than the old sparse fallback.  Still reject near-full-canvas differences;
        # those are normally display/projection mismatches rather than a new brush.
        broad_limit = max(262144, min(total, int(total * 0.35)))
        if rows.size > broad_limit:
            return False
        layer, image = _layer_image_for_session(material, layer_id or _active_layer_id(material), ch)
        if layer is None or image is None:
            return False
        # First try the exact sparse writer while a new/empty layer is still a
        # proxy. Materializing first destroys the metadata that tells Save this is
        # a top-layer brush delta and can make the fallback solver copy lower layers.
        try:
            _sess_sparse = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
            if _sps_store_sparse_top_normal_master_delta(
                material,
                ch,
                layer_id or _active_layer_id(material),
                base,
                cur,
                rows,
                session=_sess_sparse,
                tolerance=tol,
            ):
                try:
                    _MASTER_PAINT_SESSIONS.pop(_session_key(material, ch), None)
                except Exception:
                    pass
                return True
        except Exception:
            pass
        try:
            if bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
                materialize_lazy_psd_layer_image(image)
        except Exception:
            pass
        try:
            master = get_master_texture_image(material, ch, create=False)
            mw, mh = _image_size(master) if master is not None else (0, 0)
            if mw > 0 and mh > 0:
                iw, ih = _image_size(image)
                if int(iw) != int(mw) or int(ih) != int(mh):
                    _resize_image_to(image, int(mw), int(mh))
        except Exception:
            pass
        arr = _image_array_np(image, use_cache=False)
        if arr is None or getattr(arr, 'shape', None) != getattr(cur, 'shape', None):
            return False
        out = np.asarray(arr, dtype=np.float32).reshape((-1, 4)).copy()
        _recovery_brush_rgb = None
        try:
            _recovery_brush_rgb = _brush_rgb_for_layer_delta(image, getattr(bpy, 'context', None))
        except Exception:
            _recovery_brush_rgb = None
        if _recovery_brush_rgb is None:
            try:
                master = get_master_texture_image(material, ch, create=False)
                raw = master.get('smart_paint_suite_last_brush_color', None) if master is not None else None
                if raw is None and master is not None:
                    raw = master.get('smart_paint_suite_test_brush_rgb', None)
                if raw is not None:
                    _recovery_brush_rgb = tuple(float(raw[i]) for i in range(3))
            except Exception:
                _recovery_brush_rgb = None
        if _recovery_brush_rgb is None:
            try:
                sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
                if isinstance(sess, dict):
                    _recovery_brush_rgb = _rgb_tuple_or_none(sess.get('brush_rgb', None))
            except Exception:
                _recovery_brush_rgb = None
        if _recovery_brush_rgb is not None:
            try:
                _rgb_prop = (float(_recovery_brush_rgb[0]), float(_recovery_brush_rgb[1]), float(_recovery_brush_rgb[2]))
                image['smart_paint_suite_last_brush_color'] = (_rgb_prop[0], _rgb_prop[1], _rgb_prop[2], 1.0)
                image['smart_paint_suite_last_source_rgb'] = _rgb_prop
                image['smart_paint_suite_inferred_source_rgb'] = _rgb_prop
                image['smart_paint_suite_test_brush_rgb'] = _rgb_prop
            except Exception:
                pass

        # JELararagi 1.9.184: when the active layer is the top normal paint layer,
        # a native Blender stroke stored on the public document texture should be
        # persisted as the exact visible brush colour.  The generic inverse solver
        # may choose a mathematically equivalent low-alpha/dark RGB pair against a
        # white lower projection; after visibility OFF/ON or PSD round-trip that
        # visibly changes the stroke colour.  Detect the top-layer save boundary
        # and either copy the opaque brush result exactly, or clear the layer when
        # the current master matches the projection with the active layer hidden.
        try:
            _settings_exact = getattr(material, 'smart_paint_suite', None)
            _layers_exact = list(getattr(_settings_exact, 'layers', ()) or []) if _settings_exact is not None else []
            _idx_exact = -1
            for _i_exact, _ly_exact in enumerate(_layers_exact):
                try:
                    if str(getattr(_ly_exact, 'layer_id', '') or '') == str(getattr(layer, 'layer_id', '') or ''):
                        _idx_exact = int(_i_exact)
                        break
                except Exception:
                    pass
            _top_normal_exact = bool(_idx_exact >= 0)
            if _top_normal_exact:
                try:
                    _mode_exact = str(getattr(layer, 'blend_mode', 'MIX') or 'MIX').upper()
                    _top_normal_exact = _mode_exact in {'MIX', 'NORMAL'} and not bool(getattr(layer, 'clip_to_below', False)) and not bool(getattr(layer, 'is_group', False))
                except Exception:
                    _top_normal_exact = False
            if _top_normal_exact:
                _enabled_attr_exact = layer_channel_enabled_attr(ch)
                for _upper_exact in _layers_exact[_idx_exact + 1:]:
                    try:
                        if bool(getattr(_upper_exact, 'enabled', True)) and bool(getattr(_upper_exact, _enabled_attr_exact, True)) and float(getattr(_upper_exact, 'opacity', 1.0) or 0.0) > 1.0e-6:
                            _top_normal_exact = False
                            break
                    except Exception:
                        _top_normal_exact = False
                        break
            if _top_normal_exact:
                _disabled_proj_exact = None
                _old_enabled_exact = bool(getattr(layer, 'enabled', True))
                try:
                    _old_channel_enabled_exact = bool(getattr(layer, _enabled_attr_exact, True))
                except Exception:
                    _old_channel_enabled_exact = None
                _suspend_exact = None
                try:
                    from .properties import suspend_layer_rebuilds as _suspend_layer_rebuilds_exact
                    _suspend_exact = _suspend_layer_rebuilds_exact(True)
                except Exception:
                    _suspend_layer_rebuilds_exact = None
                try:
                    try:
                        layer.enabled = False
                    except Exception:
                        pass
                    try:
                        if _old_channel_enabled_exact is not None:
                            setattr(layer, _enabled_attr_exact, False)
                    except Exception:
                        pass
                    _dw_exact, _dh_exact, _disabled_proj_exact = composite_layer_arrays(material, ch)
                finally:
                    try:
                        layer.enabled = _old_enabled_exact
                    except Exception:
                        pass
                    try:
                        if _old_channel_enabled_exact is not None:
                            setattr(layer, _enabled_attr_exact, _old_channel_enabled_exact)
                    except Exception:
                        pass
                    try:
                        if _suspend_layer_rebuilds_exact is not None:
                            _suspend_layer_rebuilds_exact(bool(_suspend_exact))
                    except Exception:
                        pass
                _exact_done = False
                if _disabled_proj_exact is not None and getattr(_disabled_proj_exact, 'shape', None) == getattr(cur, 'shape', None):
                    _disabled_proj_exact = np.asarray(_disabled_proj_exact, dtype=np.float32).reshape(cur.shape)
                    _disabled_diff_exact = np.max(np.abs(cur[rows, :4] - _disabled_proj_exact[rows, :4]), axis=1)
                    if bool(_disabled_diff_exact.size) and float(np.max(_disabled_diff_exact)) <= max(float(tol), 2.0 / 255.0):
                        # Eraser result: the visible document equals the lower stack.
                        out[rows, :4] = 0.0
                        _exact_done = True
                if not _exact_done:
                    try:
                        _opaque_rows_exact = cur[rows, 3] >= (1.0 - max(float(tol), 1.0 / 255.0))
                        if bool(np.any(_opaque_rows_exact)):
                            _rows_exact = rows[_opaque_rows_exact]
                            out[_rows_exact, :4] = cur[_rows_exact, :4]
                            out[_rows_exact, 3] = np.maximum(out[_rows_exact, 3], cur[_rows_exact, 3])
                            _exact_done = True
                    except Exception:
                        _exact_done = False
                if _exact_done:
                    if not bool(_write_image_array_np(image, out)):
                        return False
                    try:
                        xs = rows % int(_image_size(image)[0] or 1)
                        ys = rows // int(_image_size(image)[0] or 1)
                        image['smart_paint_suite_dirty_bbox'] = (int(np.min(xs)), int(np.min(ys)), int(np.max(xs)) + 1, int(np.max(ys)) + 1)
                    except Exception:
                        pass
                    try:
                        image['smart_paint_suite_dirty_from_master'] = True
                        image['smart_paint_suite_alpha_authoritative'] = True
                        image['smart_paint_suite_save_exact_baseline_delta'] = True
                        image['smart_paint_suite_exact_top_visible_commit'] = True
                        image['smart_paint_suite_save_baseline_delta_reason'] = str(reason or 'top_exact')[:64]
                        image['smart_paint_suite_painted_since_last_projection'] = True
                        image['smart_paint_suite_direct_layer_dirty'] = True
                        for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                            if prop in image:
                                del image[prop]
                    except Exception:
                        pass
                    try:
                        _mark_image_pixels_changed(image, out)
                    except Exception:
                        pass
                    try:
                        _MASTER_PAINT_SESSIONS.pop(_session_key(material, ch), None)
                    except Exception:
                        pass
                    return True
        except Exception:
            pass

        recovered = bool(_recover_visible_master_rows_to_layer_array(
            image,
            out,
            rows,
            base[rows, :3],
            cur[rows, :3],
            baseline_alpha=base[rows, 3],
            current_alpha=cur[rows, 3],
            tolerance=tol,
            context=getattr(bpy, 'context', None),
        ))
        if not recovered:
            return False
        if not bool(_write_image_array_np(image, out)):
            return False
        try:
            xs = rows % int(_image_size(image)[0] or 1)
            ys = rows // int(_image_size(image)[0] or 1)
            image['smart_paint_suite_dirty_bbox'] = (int(np.min(xs)), int(np.min(ys)), int(np.max(xs)) + 1, int(np.max(ys)) + 1)
        except Exception:
            pass
        try:
            brush_rgb = _brush_rgb_for_layer_delta(image, getattr(bpy, 'context', None))
            if brush_rgb is None:
                sess = _MASTER_PAINT_SESSIONS.get(_session_key(material, ch))
                if isinstance(sess, dict):
                    brush_rgb = _rgb_tuple_or_none(sess.get('brush_rgb', None))
            if brush_rgb is not None:
                image['smart_paint_suite_last_brush_color'] = (float(brush_rgb[0]), float(brush_rgb[1]), float(brush_rgb[2]), 1.0)
        except Exception:
            pass
        try:
            image['smart_paint_suite_dirty_from_master'] = True
            image['smart_paint_suite_alpha_authoritative'] = True
            image['smart_paint_suite_save_exact_baseline_delta'] = True
            image['smart_paint_suite_save_baseline_delta_reason'] = str(reason or '')[:64]
            image['smart_paint_suite_painted_since_last_projection'] = True
            image['smart_paint_suite_direct_layer_dirty'] = True
            for prop in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred', 'smart_paint_suite_rgb_alpha_fallback', 'smart_paint_suite_export_rgb_alpha_fallback'):
                if prop in image:
                    del image[prop]
        except Exception:
            pass
        try:
            _mark_image_pixels_changed(image, out)
        except Exception:
            pass
        try:
            _MASTER_PAINT_SESSIONS.pop(_session_key(material, ch), None)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _force_commit_visible_master_delta_to_active_layer_for_save(material, channel: str = 'BASE_COLOR', *, tolerance: float = 2.0 / 255.0, force: bool = False) -> bool:
    """Save-only recovery for visible-master paint with no live session.

    Texture Paint normally writes into the public composited document image.
    If the user presses Save before the post-paint timer records the stroke on
    the selected private layer, rebuilding the master from the stack would
    erase the only copy of the stroke and the PSD layer becomes blank/white.
    This explicit Save path compares the current master against the current
    stack projection and writes the changed pixels into the active layer before
    PSD serialization.  It never runs from idle/timer code.
    """
    np = _np_module()
    if np is None or material is None:
        return False
    channel = _safe_channel(channel)
    if not (bool(force) or _sps_save_untracked_master_delta_allowed(material, channel, getattr(bpy, 'context', None))):
        return False
    try:
        master = _live_master_image_for_paint_commit(material, channel, _MASTER_PAINT_SESSIONS.get(_session_key(material, channel)))
        if master is None:
            master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        current = _image_array_np(master, use_cache=False)
        if current is None:
            return False
        mw, mh = _image_size(master)
        # Exact Blender Image.pixels baselines must use sub-8bit tolerance so soft
        # brush gradients are not collapsed to a binary patch.  The looser fallback
        # tolerance is retained only for non-exact projection/file comparisons.
        fallback_tol = max(2.0 / 255.0, float(tolerance))
        exact_tol = max(1.0 / 4096.0, min(float(tolerance), 0.5 / 255.0))
        tol = fallback_tol
        width = int(mw)
        height = int(mh)
        composite = None
        mask = None
        _baseline_exact_for_save = False
        _baseline_exact_reason = ''
        _exact_baseline_compared = False
        _exact_baseline_changed = 0

        # First try the Add Layer / target-selection save baseline.  It is
        # captured once during the explicit operation and kept without any timer.
        # This is the fastest and safest source for the reported new-layer ->
        # brush -> save workflow on real 4K PSD stacks.
        try:
            _base_entry = _SAVE_MASTER_BASELINE_CACHE.get(_session_key(material, channel))
        except Exception:
            _base_entry = None
        try:
            _base_arr = None
            _base_master = ''
            if isinstance(_base_entry, dict):
                _base_arr = _base_entry.get('baseline', None)
                _base_master = str(_base_entry.get('master_image', '') or '')
                if _base_arr is not None:
                    _baseline_exact_reason = 'save_baseline_cache'
            if _base_arr is None:
                try:
                    _sess_entry = _MASTER_PAINT_SESSIONS.get(_session_key(material, channel))
                    if isinstance(_sess_entry, dict):
                        _sess_arr = _sess_entry.get('baseline', None)
                        _sess_master = str(_sess_entry.get('master_image', '') or '')
                        if _sess_arr is not None:
                            _base_arr = _sess_arr
                            _base_master = _sess_master
                            _baseline_exact_reason = 'master_paint_session'
                except Exception:
                    _base_arr = None
            if _base_arr is None:
                try:
                    _base_img_name = str(material.get('sps_save_baseline_image_' + channel, '') or '')
                    _base_img = bpy.data.images.get(_base_img_name) if _base_img_name else None
                    if _base_img is not None:
                        _base_arr = _image_array_np(_base_img, use_cache=False)
                        _base_master = str(getattr(master, 'name', '') or '')
                        _baseline_exact_reason = 'baseline_image'
                except Exception:
                    _base_arr = None
            if _base_arr is not None and (not _base_master or _base_master == str(getattr(master, 'name', '') or '')):
                _base_arr = np.asarray(_base_arr, dtype=np.float32).reshape((-1, 4))
                if getattr(_base_arr, 'shape', None) == getattr(current, 'shape', None):
                    _base_total = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
                    _base_mask = None
                    try:
                        _bbox_raw = master.get('smart_paint_suite_dirty_bbox', None)
                    except Exception:
                        _bbox_raw = None
                    try:
                        _parts = []
                        if isinstance(_bbox_raw, str):
                            _parts = [p.strip() for p in _bbox_raw.replace(';', ',').split(',') if p.strip()]
                        elif _bbox_raw is not None:
                            _parts = list(_bbox_raw)
                        if len(_parts) >= 4:
                            _x0, _y0, _x1, _y1 = [int(float(v)) for v in _parts[:4]]
                            _x0 = max(0, min(int(mw), _x0)); _x1 = max(0, min(int(mw), _x1))
                            _y0 = max(0, min(int(mh), _y0)); _y1 = max(0, min(int(mh), _y1))
                            if _x1 > _x0 and _y1 > _y0:
                                _base_mask = np.zeros((_base_total,), dtype=np.bool_)
                                for _yy in range(int(_y0), int(_y1)):
                                    _start = int(_yy) * int(mw) + int(_x0)
                                    _end = int(_yy) * int(mw) + int(_x1)
                                    _base_mask[_start:_end] = (np.max(np.abs(current[_start:_end, :4] - _base_arr[_start:_end, :4]), axis=1) > exact_tol)
                    except Exception:
                        _base_mask = None
                    if _base_mask is None:
                        _base_diff = np.max(np.abs(current[:, :4] - _base_arr[:, :4]), axis=1)
                        _base_mask = _base_diff > exact_tol
                    _base_changed = int(np.count_nonzero(_base_mask))
                    _exact_baseline_compared = True
                    _exact_baseline_changed = int(_base_changed)
                    if _base_changed > 0 and (_base_total > 0) and (_base_changed <= max(262144, int(_base_total * 0.35))):
                        composite = _base_arr
                        mask = _base_mask
                        _baseline_exact_for_save = True
                        if not _baseline_exact_reason:
                            _baseline_exact_reason = 'exact_baseline'
        except Exception:
            composite = None
            mask = None

        if composite is None and mask is None and bool(_exact_baseline_compared) and int(_exact_baseline_changed) <= 0:
            return False

        if composite is None or mask is None:
            # New Layer -> native Texture Paint -> Save on Windows can leave the
            # brush stroke on the public composited master.  Do not build a full
            # lazy-stack composite first on production PSDs: use the exact source
            # file preview captured at Add Layer time, and restrict the compare to
            # Blender's dirty bbox when available.  This keeps existing artwork
            # visible at Add Layer and avoids the broad inverse-solver path that
            # produced invalid PSD records on some Windows systems.
            try:
                try:
                    _source_fallback_active_empty = bool(_active_layer_is_clean_intentionally_empty(material, channel))
                except Exception:
                    _source_fallback_active_empty = False
                _source_path = str(material.get('sps_new_layer_master_source_path_' + channel, '') or material.get('sps_texture_source_path_' + channel, '') or '')
                _source_layer_id = str(material.get('sps_new_layer_master_baseline_layer_id_' + channel, '') or '')
                if (not bool(_source_fallback_active_empty)) and _source_path and (not _source_layer_id or _source_layer_id == str(_active_layer_id(material) or '')):
                    _abs_source = bpy.path.abspath(_source_path)
                    _doc_source = read_layered_psd_lazy(_abs_source, decode_merged=True)
                    _merged_source = _doc_source.get('merged', None) if isinstance(_doc_source, dict) else None
                    if _merged_source is not None:
                        _source_arr = np.asarray(_merged_source, dtype=np.float32).reshape((-1, 4))
                        if getattr(_source_arr, 'shape', None) == getattr(current, 'shape', None):
                            _source_mask = None
                            try:
                                _bbox_raw = master.get('smart_paint_suite_dirty_bbox', None)
                            except Exception:
                                _bbox_raw = None
                            try:
                                _parts = []
                                if isinstance(_bbox_raw, str):
                                    _parts = [p.strip() for p in _bbox_raw.replace(';', ',').split(',') if p.strip()]
                                elif _bbox_raw is not None:
                                    _parts = list(_bbox_raw)
                                if len(_parts) >= 4:
                                    _x0, _y0, _x1, _y1 = [int(float(v)) for v in _parts[:4]]
                                    _x0 = max(0, min(int(mw), _x0)); _x1 = max(0, min(int(mw), _x1))
                                    _y0 = max(0, min(int(mh), _y0)); _y1 = max(0, min(int(mh), _y1))
                                    if _x1 > _x0 and _y1 > _y0:
                                        _source_mask = np.zeros((int(mw) * int(mh),), dtype=np.bool_)
                                        for _yy in range(int(_y0), int(_y1)):
                                            _start = int(_yy) * int(mw) + int(_x0)
                                            _end = int(_yy) * int(mw) + int(_x1)
                                            _d = np.max(np.abs(current[_start:_end, :4] - _source_arr[_start:_end, :4]), axis=1) > tol
                                            _source_mask[_start:_end] = _d
                            except Exception:
                                _source_mask = None
                            if _source_mask is None:
                                _source_diff = np.max(np.abs(current[:, :4] - _source_arr[:, :4]), axis=1)
                                _source_mask = _source_diff > tol
                            _source_changed = int(np.count_nonzero(_source_mask))
                            _source_total = int(_source_mask.shape[0]) if getattr(_source_mask, 'shape', None) is not None else 0
                            _exact_baseline_compared = True
                            _exact_baseline_changed = int(_source_changed)
                            if _source_changed > 0 and _source_total > 0 and (_source_changed <= max(262144, int(_source_total * 0.35))):
                                composite = _source_arr
                                mask = _source_mask
                                _baseline_exact_for_save = True
                                _baseline_exact_reason = 'source_file_preview'
                                try:
                                    material['sps_last_master_delta_recovery_' + channel] = 'source_file_preview'
                                except Exception:
                                    pass
            except Exception:
                composite = None
                mask = None
        if composite is None and mask is None and bool(_exact_baseline_compared) and int(_exact_baseline_changed) <= 0:
            return False
        if composite is None or mask is None:
            try:
                _active_clean_empty = bool(_active_layer_is_clean_intentionally_empty(material, channel))
            except Exception:
                _active_clean_empty = False
            if bool(_active_clean_empty):
                try:
                    _allow_empty_composite_probe = bool(get_master_texture_image(material, channel, create=False).get('smart_paint_suite_dirty_bbox', None))
                except Exception:
                    _allow_empty_composite_probe = False
                if not bool(_allow_empty_composite_probe):
                    # Do not recover a new empty/top layer from a broad stale
                    # projection without a paint dirty-bbox hint.
                    return False
            width, height, composite = composite_layer_arrays(material, channel)
            if composite is None or getattr(composite, 'shape', None) != getattr(current, 'shape', None):
                return False
            if int(width) != int(mw) or int(height) != int(mh):
                return False
            diff = np.max(np.abs(current[:, :4] - composite[:, :4]), axis=1)
            mask = diff > tol
        if not bool(np.any(mask)):
            return False
        try:
            changed_count = int(np.count_nonzero(mask))
            total_count = int(mask.shape[0]) if getattr(mask, 'shape', None) is not None else 0
            # A broad full-canvas difference at Save time is almost always a stale
            # display/projection target (for example a black or hidden master image),
            # not an uncommitted brush stroke.  Do not flatten such projections into
            # the active private layer; otherwise saving turns soft layer pixels into
            # a full-canvas opaque layer and the PSD is corrupted.  Real large edits
            # are captured by exact master/direct paint sessions before reaching this
            # save-only untracked fallback.
            if total_count > 0 and (changed_count / float(total_count)) > 0.35:
                try:
                    _lid_probe = _active_layer_id(material)
                    _layer_probe, _img_probe = _layer_image_for_session(material, _lid_probe, channel)
                    _arr_probe = _image_array_np(_img_probe, use_cache=False) if _img_probe is not None else None
                    if _arr_probe is not None and getattr(_arr_probe, 'shape', None) == getattr(current, 'shape', None):
                        _alpha_probe = np.clip(np.asarray(_arr_probe, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                        if bool(np.any(_alpha_probe > (1.0 / 4096.0))):
                            return False
                except Exception:
                    pass
                if changed_count > 262144:
                    # The live stack projection can legitimately differ from an
                    # existing production PSD across the whole canvas even before
                    # the new stroke (legacy layer order, packed preview, hidden
                    # layer metadata, or old scene state).  For the exact reported
                    # workflow the on-disk texture is still the pre-stroke master.
                    # Compare the dirty public canvas against that file preview; if
                    # that delta is brush-sized, use it as the recovery baseline
                    # instead of entering the broad/freezing untracked solver.
                    try:
                        _src_path = str(material.get('sps_texture_path_' + channel, '') or '')
                    except Exception:
                        _src_path = ''
                    if not _src_path:
                        try:
                            _src_path = str(getattr(master, 'filepath_raw', '') or getattr(master, 'filepath', '') or '')
                        except Exception:
                            _src_path = ''
                    _file_merged = None
                    try:
                        _abs_src = bpy.path.abspath(_src_path) if _src_path else ''
                        if _abs_src:
                            _doc_src = read_layered_psd_lazy(_abs_src, decode_merged=True)
                            _file_merged = _doc_src.get('merged', None)
                    except Exception:
                        _file_merged = None
                    try:
                        if _file_merged is not None:
                            _file_base = np.asarray(_file_merged, dtype=np.float32).reshape((-1, 4))
                            if getattr(_file_base, 'shape', None) == getattr(current, 'shape', None):
                                _file_total = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
                                _file_mask = np.zeros((_file_total,), dtype=np.bool_)
                                _chunk = 1048576
                                _file_changed = 0
                                for _start in range(0, _file_total, _chunk):
                                    _end = min(_file_total, _start + _chunk)
                                    _m = np.max(np.abs(current[_start:_end, :4] - _file_base[_start:_end, :4]), axis=1) > tol
                                    _file_mask[_start:_end] = _m
                                    _file_changed += int(np.count_nonzero(_m))
                                if _file_changed > 0 and (_file_changed <= 262144 or (_file_total > 0 and (_file_changed / float(_file_total)) <= 0.35)):
                                    composite = _file_base
                                    mask = _file_mask
                                    changed_count = _file_changed
                                else:
                                    return False
                            else:
                                return False
                        else:
                            return False
                    except Exception:
                        return False
        except Exception:
            pass
        try:
            _active_clean_empty = bool(_active_layer_is_clean_intentionally_empty(material, channel))
        except Exception:
            _active_clean_empty = False
        if bool(_active_clean_empty) and not bool(_baseline_exact_for_save):
            try:
                _clean_empty_changed = int(np.count_nonzero(mask))
            except Exception:
                _clean_empty_changed = 0
            if _clean_empty_changed <= 0 or _clean_empty_changed > 262144:
                return False

        layer_id = _active_layer_id(material)

        if bool(_baseline_exact_for_save):
            try:
                if bool(_direct_commit_baseline_master_delta_to_active_layer_for_save(
                    material,
                    channel,
                    layer_id,
                    composite,
                    current,
                    mask,
                    tolerance=exact_tol if bool(_baseline_exact_for_save) else tol,
                    reason=_baseline_exact_reason or 'save',
                )):
                    return True
            except Exception:
                pass

        # Fast save-boundary recovery for the common production workflow:
        # Add a new layer, paint with Blender Texture Paint on the public/master
        # canvas, then press Save before any idle timer exists.  Do not require the
        # new layer to be the absolute top layer; Photoshop-style stacks often add
        # the row above the selected layer while other enabled rows remain above it.
        # The changed master pixels are still the user's active-layer stroke.
        try:
            rows_sparse = np.nonzero(mask)[0]
            if rows_sparse.size > 0 and rows_sparse.size <= 262144:
                _layer_sparse, _image_sparse = _layer_image_for_session(material, layer_id, channel)
                if _layer_sparse is not None and _image_sparse is not None:
                    try:
                        if bool(_image_sparse.get('smart_paint_suite_lazy_psd_pending', False)) or bool(_image_sparse.get('smart_paint_suite_lazy_blank_layer', False)):
                            materialize_lazy_psd_layer_image(_image_sparse)
                    except Exception:
                        pass
                    try:
                        iw_sparse, ih_sparse = _image_size(_image_sparse)
                        if int(iw_sparse) != int(mw) or int(ih_sparse) != int(mh):
                            _resize_image_to(_image_sparse, int(mw), int(mh))
                    except Exception:
                        pass
                    layer_arr_sparse = _image_array_np(_image_sparse, use_cache=False)
                    if layer_arr_sparse is not None and getattr(layer_arr_sparse, 'shape', None) == getattr(current, 'shape', None):
                        out_sparse = np.asarray(layer_arr_sparse, dtype=np.float32).reshape((-1, 4)).copy()
                        under_sparse = np.clip(composite[rows_sparse, :3], 0.0, 1.0)
                        target_sparse = np.clip(current[rows_sparse, :3], 0.0, 1.0)
                        eps_sparse = 1.0e-6
                        brush_rgb_sparse = None
                        try:
                            brush_rgb_sparse = _sps_infer_source_rgb_for_master_patch(
                                _image_sparse,
                                _MASTER_PAINT_SESSIONS.get(_session_key(material, channel)),
                                under_sparse,
                                target_sparse,
                            )
                        except Exception:
                            brush_rgb_sparse = None
                        if brush_rgb_sparse is None:
                            try:
                                brush_rgb_sparse = _brush_rgb_for_layer_delta(_image_sparse, getattr(bpy, 'context', None))
                            except Exception:
                                brush_rgb_sparse = None
                        if brush_rgb_sparse is None:
                            try:
                                raw_sparse = _image_sparse.get('smart_paint_suite_last_brush_color', None)
                                if raw_sparse is None:
                                    raw_sparse = _image_sparse.get('smart_paint_suite_test_brush_rgb', None)
                                if raw_sparse is not None:
                                    brush_rgb_sparse = tuple(float(raw_sparse[i]) for i in range(3))
                            except Exception:
                                brush_rgb_sparse = None
                        if brush_rgb_sparse is None:
                            try:
                                diff_sparse = np.max(np.abs(target_sparse - under_sparse), axis=1)
                                if diff_sparse.size and float(np.max(diff_sparse)) > tol:
                                    high_sparse = diff_sparse >= max(float(np.max(diff_sparse)) * 0.75, float(tol))
                                    if bool(np.any(high_sparse)):
                                        brush_rgb_sparse = tuple(float(v) for v in np.median(target_sparse[high_sparse], axis=0)[:3])
                            except Exception:
                                brush_rgb_sparse = None
                        if brush_rgb_sparse is not None:
                            try:
                                C_sparse = np.clip(np.asarray(brush_rgb_sparse, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
                                denom_sparse = C_sparse - under_sparse
                                valid_sparse = np.abs(denom_sparse) > eps_sparse
                                with np.errstate(divide='ignore', invalid='ignore'):
                                    ratios_sparse = (target_sparse - under_sparse) / np.where(valid_sparse, denom_sparse, 1.0)
                                valid_sparse = np.logical_and(valid_sparse, np.logical_and(ratios_sparse >= -0.05, ratios_sparse <= 1.05))
                                valid_count_sparse = np.sum(valid_sparse, axis=1)
                                ratios_sparse = np.clip(ratios_sparse, 0.0, 1.0)
                                cov_sparse = np.sum(np.where(valid_sparse, ratios_sparse, 0.0), axis=1) / np.maximum(valid_count_sparse.astype(np.float32), 1.0)
                                fallback_sparse = np.max(np.abs(target_sparse - under_sparse), axis=1)
                                cov_sparse = np.where(valid_count_sparse > 0, cov_sparse, np.clip(fallback_sparse * 1.5, 0.0, 1.0))
                                src_sparse = np.broadcast_to(C_sparse, target_sparse.shape).copy()
                            except Exception:
                                brush_rgb_sparse = None
                        if brush_rgb_sparse is None:
                            diff_rgb_sparse = target_sparse - under_sparse
                            lighten_sparse = np.where(diff_rgb_sparse > 0.0, diff_rgb_sparse / np.maximum(1.0 - under_sparse, eps_sparse), 0.0)
                            darken_sparse = np.where(diff_rgb_sparse < 0.0, (-diff_rgb_sparse) / np.maximum(under_sparse, eps_sparse), 0.0)
                            cov_sparse = np.clip(np.max(np.maximum(lighten_sparse, darken_sparse), axis=1), 0.0, 1.0).astype(np.float32, copy=False)
                            src_sparse = (target_sparse - under_sparse * (1.0 - cov_sparse[:, None])) / np.maximum(cov_sparse[:, None], eps_sparse)
                        alpha_delta_sparse = np.clip(current[rows_sparse, 3] - composite[rows_sparse, 3], 0.0, 1.0)
                        fractional_sparse = np.logical_and(alpha_delta_sparse > (1.0 / 4096.0), alpha_delta_sparse < (1.0 - (1.0 / 4096.0)))
                        if bool(np.any(fractional_sparse)):
                            cov_sparse[fractional_sparse] = np.maximum(cov_sparse[fractional_sparse], alpha_delta_sparse[fractional_sparse])
                        paint_sparse = cov_sparse > (0.5 / 255.0)
                        if bool(np.any(paint_sparse)):
                            rows_apply_sparse = rows_sparse[paint_sparse]
                            cov_apply_sparse = np.clip(cov_sparse[paint_sparse], 0.0, 1.0).astype(np.float32, copy=False)
                            src_apply_sparse = np.clip(src_sparse[paint_sparse], 0.0, 1.0).astype(np.float32, copy=False)
                            old_a_sparse = np.clip(out_sparse[rows_apply_sparse, 3], 0.0, 1.0)
                            old_rgb_sparse = np.clip(out_sparse[rows_apply_sparse, :3], 0.0, 1.0)
                            new_a_sparse = np.clip(cov_apply_sparse + old_a_sparse * (1.0 - cov_apply_sparse), 0.0, 1.0)
                            merged_pm_sparse = src_apply_sparse * cov_apply_sparse[:, None] + old_rgb_sparse * old_a_sparse[:, None] * (1.0 - cov_apply_sparse[:, None])
                            out_sparse[rows_apply_sparse, :3] = np.clip(merged_pm_sparse / np.maximum(new_a_sparse[:, None], eps_sparse), 0.0, 1.0)
                            out_sparse[rows_apply_sparse, 3] = new_a_sparse
                            ok_sparse = bool(_write_image_array_np(_image_sparse, out_sparse))
                            if ok_sparse:
                                try:
                                    xs_sparse = rows_apply_sparse % int(mw)
                                    ys_sparse = rows_apply_sparse // int(mw)
                                    _image_sparse['smart_paint_suite_dirty_bbox'] = (int(np.min(xs_sparse)), int(np.min(ys_sparse)), int(np.max(xs_sparse)) + 1, int(np.max(ys_sparse)) + 1)
                                except Exception:
                                    pass
                                try:
                                    if brush_rgb_sparse is not None:
                                        _image_sparse['smart_paint_suite_last_brush_color'] = (float(brush_rgb_sparse[0]), float(brush_rgb_sparse[1]), float(brush_rgb_sparse[2]), 1.0)
                                    _image_sparse['smart_paint_suite_dirty_from_master'] = True
                                    _image_sparse['smart_paint_suite_alpha_authoritative'] = True
                                    _image_sparse['smart_paint_suite_save_sparse_master_delta'] = True
                                    _image_sparse['smart_paint_suite_painted_since_last_projection'] = True
                                    _image_sparse['smart_paint_suite_direct_layer_dirty'] = True
                                    for _empty_prop_sparse in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred'):
                                        if _empty_prop_sparse in _image_sparse:
                                            del _image_sparse[_empty_prop_sparse]
                                except Exception:
                                    pass
                                try:
                                    _mark_image_pixels_changed(_image_sparse, out_sparse)
                                except Exception:
                                    pass
                                try:
                                    protect_layer_stack_pixels(material, channel)
                                except Exception:
                                    pass
                                try:
                                    _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
                                except Exception:
                                    pass
                                return True
        except Exception:
            pass

        _sps_skip_stale_projection_probe = False
        try:
            _changed_count_probe = int(np.count_nonzero(mask))
            if 0 < _changed_count_probe <= 262144:
                _cw_probe, _ch_probe, _layers_probe = collect_layers(material, channel)
                _active_idx_probe = -1
                _active_item_probe = None
                for _idx_probe, _item_probe in enumerate(_layers_probe or ()): 
                    try:
                        _ly_probe = _item_probe.get('layer')
                        if str(getattr(_ly_probe, 'layer_id', '') or '') == str(layer_id or ''):
                            _active_idx_probe = int(_idx_probe)
                            _active_item_probe = _item_probe
                            break
                    except Exception:
                        continue
                if _active_item_probe is not None and int(_cw_probe) == int(width) and int(_ch_probe) == int(height):
                    _upper_probe = False
                    for _up_probe in list(_layers_probe or ())[_active_idx_probe + 1:]:
                        try:
                            if bool(_up_probe.get('enabled', True)) and float(_up_probe.get('opacity', 1.0) or 0.0) > 1.0e-6:
                                _upper_probe = True
                                break
                        except Exception:
                            _upper_probe = True
                            break
                    _mode_probe = str(_active_item_probe.get('blend_mode', 'MIX') or 'MIX').upper()
                    if (not _upper_probe) and _mode_probe in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER'} and not bool(_active_item_probe.get('clip_to_below', False)):
                        # For a brush-sized delta on the current top paint layer,
                        # the expensive hidden-layer stale-preview probe can
                        # materialize lazy PSD layers and freeze Save.  The direct
                        # row commit below is the authoritative check for this case.
                        _sps_skip_stale_projection_probe = True
        except Exception:
            _sps_skip_stale_projection_probe = False
        if (not _sps_skip_stale_projection_probe) and _visible_master_is_stale_active_layer_hidden_projection(material, channel, current, composite, layer_id, tolerance=tol):
            return False
        # If this save-boundary delta is already covered by the active private
        # layer alpha, it is an ordinary projection/quantization mismatch rather
        # than missing paint.  Skipping here makes Save idempotent and preserves
        # existing soft alpha instead of repeatedly source-overing the same
        # stroke into itself.
        try:
            _layer_existing, _image_existing = _layer_image_for_session(material, layer_id, channel)
            _arr_existing = _image_array_np(_image_existing, use_cache=False) if _image_existing is not None else None
            if _arr_existing is not None and getattr(_arr_existing, 'shape', None) == getattr(current, 'shape', None):
                _alpha_existing = np.clip(np.asarray(_arr_existing, dtype=np.float32).reshape((-1, 4))[:, 3], 0.0, 1.0)
                _mask_count = int(np.count_nonzero(mask))
                if _mask_count > 0 and int(np.count_nonzero(_alpha_existing > (1.0 / 4096.0))) > 0:
                    _overlap = int(np.count_nonzero(np.logical_and(mask, _alpha_existing > (1.0 / 4096.0))))
                    if (_overlap / float(max(1, _mask_count))) >= 0.80:
                        return False
        except Exception:
            pass
        # Save-time fast path for the reported workflow: a new top paint
        # layer receives Blender Texture Paint strokes on the public/master
        # document image, then the user immediately presses Save.  The generic
        # inverse solver below is intentionally broad, but on production PSDs it
        # can materialize surrounding lazy layers and appear to freeze before the
        # PSD writer starts.  When the active layer is the uppermost ordinary
        # normal layer and the visible-master delta is brush-sized, reconstruct
        # the changed rows directly into that active private layer.
        try:
            rows_fast = np.nonzero(mask)[0]
            if rows_fast.size > 0 and rows_fast.size <= 262144:
                _cw_fast, _ch_fast, _layers_fast = collect_layers(material, channel)
                active_item_fast = None
                active_idx_fast = -1
                for _idx_fast, _item_fast in enumerate(_layers_fast or ()): 
                    try:
                        _ly_fast = _item_fast.get('layer')
                        if str(getattr(_ly_fast, 'layer_id', '') or '') == str(layer_id or ''):
                            active_idx_fast = int(_idx_fast)
                            active_item_fast = _item_fast
                            break
                    except Exception:
                        continue
                if active_item_fast is not None and int(_cw_fast) == int(width) and int(_ch_fast) == int(height):
                    upper_blocking_fast = False
                    for _upper_fast in list(_layers_fast or ())[active_idx_fast + 1:]:
                        try:
                            if bool(_upper_fast.get('enabled', True)) and float(_upper_fast.get('opacity', 1.0) or 0.0) > 1.0e-6:
                                upper_blocking_fast = True
                                break
                        except Exception:
                            upper_blocking_fast = True
                            break
                    mode_fast = str(active_item_fast.get('blend_mode', 'MIX') or 'MIX').upper()
                    if (not upper_blocking_fast) and mode_fast in {'MIX', 'NORMAL', 'SRC_OVER', 'SOURCE_OVER'} and not bool(active_item_fast.get('clip_to_below', False)):
                        _layer_fast, _image_fast = _layer_image_for_session(material, layer_id, channel)
                        if _layer_fast is not None and _image_fast is not None:
                            try:
                                if bool(_image_fast.get('smart_paint_suite_lazy_psd_pending', False)) or bool(_image_fast.get('smart_paint_suite_lazy_blank_layer', False)):
                                    materialize_lazy_psd_layer_image(_image_fast)
                            except Exception:
                                pass
                            try:
                                iw_fast, ih_fast = _image_size(_image_fast)
                                if int(iw_fast) != int(mw) or int(ih_fast) != int(mh):
                                    _resize_image_to(_image_fast, int(mw), int(mh))
                            except Exception:
                                pass
                            layer_arr_fast = _image_array_np(_image_fast, use_cache=False)
                            if layer_arr_fast is not None and getattr(layer_arr_fast, 'shape', None) == getattr(current, 'shape', None):
                                layer_arr_fast = np.asarray(layer_arr_fast, dtype=np.float32).reshape((-1, 4)).copy()
                                recovered_fast = bool(_recover_visible_master_rows_to_layer_array(
                                    _image_fast,
                                    layer_arr_fast,
                                    rows_fast,
                                    composite[rows_fast, :3],
                                    current[rows_fast, :3],
                                    baseline_alpha=composite[rows_fast, 3],
                                    current_alpha=current[rows_fast, 3],
                                    tolerance=tol,
                                    context=getattr(bpy, 'context', None),
                                ))
                                if recovered_fast and bool(_write_image_array_np(_image_fast, layer_arr_fast)):
                                    try:
                                        _image_fast['smart_paint_suite_dirty_from_master'] = True
                                        _image_fast['smart_paint_suite_alpha_authoritative'] = True
                                        _image_fast['smart_paint_suite_save_fast_master_delta'] = True
                                        for _prop_fast in ('smart_paint_suite_intentionally_empty', 'smart_paint_suite_lazy_blank_layer', 'smart_paint_suite_clear_deferred'):
                                            if _prop_fast in _image_fast:
                                                del _image_fast[_prop_fast]
                                    except Exception:
                                        pass
                                    try:
                                        _mark_image_pixels_changed(_image_fast, layer_arr_fast)
                                    except Exception:
                                        pass
                                    try:
                                        protect_layer_stack_pixels(material, channel)
                                    except Exception:
                                        pass
                                    try:
                                        _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
                                    except Exception:
                                        pass
                                    return True
        except Exception:
            pass

        applied = False
        try:
            applied = bool(_apply_master_delta_to_layer(material, channel, layer_id, composite, current, tolerance=tol))
        except Exception:
            applied = False
        if applied:
            try:
                _aw, _ah, after_composite = composite_layer_arrays(material, channel)
                if after_composite is not None and getattr(after_composite, 'shape', None) == getattr(current, 'shape', None):
                    still_dirty = np.max(np.abs(after_composite[:, :4] - current[:, :4]), axis=1) > tol
                    mask = np.logical_and(mask, still_dirty)
                # If the inverse solver made the layer stack reproduce the visible
                # master, no save-only fallback is needed.
                if not bool(np.any(mask)):
                    return True
            except Exception:
                pass
        layer, image = _layer_image_for_session(material, layer_id, channel)
        if layer is None or image is None:
            return False
        try:
            if bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
                materialize_lazy_psd_layer_image(image)
        except Exception:
            pass
        try:
            iw, ih = _image_size(image)
            if int(iw) != int(mw) or int(ih) != int(mh):
                _resize_image_to(image, int(mw), int(mh))
        except Exception:
            return False
        layer_arr = _image_array_np(image, use_cache=False)
        if layer_arr is None or getattr(layer_arr, 'shape', None) != getattr(current, 'shape', None):
            return False
        out = np.asarray(layer_arr, dtype=np.float32).reshape((-1, 4)).copy()

        # The public master is usually the fully composited document, so its alpha
        # is often 1.0 even for a soft brush stroke on a transparent active layer.
        # Do not copy current[:, 3] into the private layer.  Reconstruct source
        # coverage from the RGB transition over the previous stack projection,
        # using a source colour that validates against the actual changed rows.
        rows = np.nonzero(mask)[0]
        under = np.clip(composite[rows, :3], 0.0, 1.0)
        target = np.clip(current[rows, :3], 0.0, 1.0)
        eps = 1.0e-6
        brush_rgb = None
        try:
            brush_rgb = _sps_infer_source_rgb_for_master_patch(
                image,
                _MASTER_PAINT_SESSIONS.get(_session_key(material, channel)),
                under,
                target,
            )
        except Exception:
            brush_rgb = None
        try:
            if brush_rgb is None and image is not None and image.get('smart_paint_suite_test_brush_rgb', None) is not None:
                raw = image.get('smart_paint_suite_test_brush_rgb')
                brush_rgb = tuple(float(raw[i]) for i in range(3))
        except Exception:
            pass

        if brush_rgb is not None:
            try:
                C = np.clip(np.asarray(brush_rgb, dtype=np.float32).reshape((1, 3)), 0.0, 1.0)
                denom = C - under
                solve_eps = max(1.0 / 4096.0, 1.0e-6)
                valid = np.abs(denom) > solve_eps
                with np.errstate(divide='ignore', invalid='ignore'):
                    ratios = (target - under) / np.where(valid, denom, 1.0)
                valid = np.logical_and(valid, np.logical_and(ratios >= -0.05, ratios <= 1.05))
                valid_count = np.sum(valid, axis=1)
                ratios = np.clip(ratios, 0.0, 1.0)
                cov = np.sum(np.where(valid, ratios, 0.0), axis=1) / np.maximum(valid_count.astype(np.float32), 1.0)
                fallback_diff = np.max(np.abs(target - under), axis=1)
                cov = np.where(valid_count > 0, cov, np.clip(fallback_diff * 1.5, 0.0, 1.0))
                src = np.broadcast_to(C, target.shape).copy()
            except Exception:
                brush_rgb = None
        if brush_rgb is None:
            diff_rgb = target - under
            lighten = np.where(diff_rgb > 0.0, diff_rgb / np.maximum(1.0 - under, eps), 0.0)
            darken = np.where(diff_rgb < 0.0, (-diff_rgb) / np.maximum(under, eps), 0.0)
            cov = np.clip(np.max(np.maximum(lighten, darken), axis=1), 0.0, 1.0).astype(np.float32, copy=False)
            solve_eps = max(1.0 / 4096.0, 1.0e-6)
            src = (target - under * (1.0 - cov[:, None])) / np.maximum(cov[:, None], solve_eps)

        alpha_delta = np.clip(current[rows, 3] - composite[rows, 3], 0.0, 1.0)
        fractional = np.logical_and(alpha_delta > (1.0 / 4096.0), alpha_delta < (1.0 - (1.0 / 4096.0)))
        if bool(np.any(fractional)):
            cov[fractional] = np.maximum(cov[fractional], alpha_delta[fractional])
        paint = cov > (0.5 / 255.0)
        if not bool(np.any(paint)):
            return False
        rows = rows[paint]
        cov = np.clip(cov[paint], 0.0, 1.0).astype(np.float32, copy=False)
        src = np.clip(src[paint], 0.0, 1.0).astype(np.float32, copy=False)
        old_a = np.clip(out[rows, 3], 0.0, 1.0)
        old_rgb = np.clip(out[rows, :3], 0.0, 1.0)
        new_a = np.clip(cov + old_a * (1.0 - cov), 0.0, 1.0)
        merged_pm = src * cov[:, None] + old_rgb * old_a[:, None] * (1.0 - cov[:, None])
        out[rows, :3] = np.clip(merged_pm / np.maximum(new_a[:, None], eps), 0.0, 1.0)
        out[rows, 3] = new_a
        ok = bool(_write_image_array_np(image, out))
        if ok:
            try:
                image['smart_paint_suite_dirty_from_master'] = True
                image['smart_paint_suite_alpha_authoritative'] = True
                image['smart_paint_suite_save_forced_master_delta'] = True
            except Exception:
                pass
            try:
                _mark_image_pixels_changed(image, out)
            except Exception:
                pass
            try:
                protect_layer_stack_pixels(material, channel)
            except Exception:
                pass
            try:
                _MASTER_PAINT_SESSIONS.pop(_session_key(material, channel), None)
            except Exception:
                pass
        return ok
    except Exception:
        return False


def _live_master_exact_baseline_allowed(master) -> bool:
    try:
        w, h = _image_size(master)
        limit = min(max(1, int(_MASTER_LIVE_EXACT_BASELINE_PIXEL_LIMIT)), 2048 * 2048)
        return bool(int(w) * int(h) <= int(limit))
    except Exception:
        return False


def _live_master_session_active(master=None) -> bool:
    try:
        ctx = getattr(bpy, 'context', None)
        obj = getattr(ctx, 'object', None) if ctx is not None else None
        if obj is not None and getattr(obj, 'mode', '') == 'TEXTURE_PAINT':
            return True
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        if ip is not None:
            canvas = getattr(ip, 'canvas', None)
            if master is not None and canvas == master:
                return True
            if canvas is not None and bool(canvas.get('smart_paint_suite_master_texture', False)):
                return True
        scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
        active_img = getattr(scene_settings, 'active_paint_image', None) if scene_settings is not None else None
        if master is not None and active_img == master:
            return True
        if active_img is not None and bool(active_img.get('smart_paint_suite_master_texture', False)):
            return True
    except Exception:
        pass
    return False

def _defer_exact_master_baseline_for_large_image(material, channel: str, master) -> bool:
    """Avoid full 4K/8K baseline allocations at lightweight layer operations."""
    try:
        if material is None or master is None:
            return False
        w, h = _image_size(master)
        pixels = int(w) * int(h)
        interactive_limit = min(max(1, int(_MASTER_LIVE_EXACT_BASELINE_PIXEL_LIMIT)), 2048 * 2048)
        if pixels <= interactive_limit:
            return False
        try:
            material['sps_save_baseline_deferred_' + _safe_channel(channel)] = True
            material['sps_save_baseline_deferred_size_' + _safe_channel(channel)] = (int(w), int(h))
        except Exception:
            pass
        try:
            src = str(material.get('sps_texture_path_' + _safe_channel(channel), '') or material.get('sps_texture_source_path_' + _safe_channel(channel), '') or '')
            if not src:
                src = str(getattr(master, 'filepath_raw', '') or getattr(master, 'filepath', '') or '')
            if src:
                material['sps_new_layer_master_source_path_' + _safe_channel(channel)] = bpy.path.abspath(src)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _trim_named_array_cache(cache, value_key: str, *, max_items: int = 0, max_bytes: int = 0) -> None:
    """Compatibility hook for call sites migrated to the shared data LRU."""
    del cache, value_key, max_items, max_bytes
    _sps_quota.clear_for_memory_pressure()

def capture_master_save_baseline(material, channel: str = 'BASE_COLOR') -> bool:
    """Capture the current public/master canvas for the next explicit Save.

    This is a finite Add Layer / target-selection operation, not an idle timer.
    It preserves the pre-stroke canvas so Save Texture can recover native Blender
    brush strokes without recomposing a large PSD stack or relying on live timers.
    """
    try:
        if material is None:
            return False
        channel = _safe_channel(channel)
        master = get_master_texture_image(material, channel, create=False)
        if master is None:
            return False
        if _defer_exact_master_baseline_for_large_image(material, channel, master):
            return False
        try:
            _force_public_master_display_opaque_now(material, channel, master)
        except Exception:
            pass
        key = _session_key(material, channel)
        arr = None
        baseline_copy = None
        try:
            sess = _MASTER_PAINT_SESSIONS.get(key)
            if isinstance(sess, dict) and sess.get('baseline') is not None and str(sess.get('master_image', '') or '') == str(getattr(master, 'name', '') or ''):
                baseline_copy = sess.get('baseline')
                arr = baseline_copy
        except Exception:
            baseline_copy = None
            arr = None
        if baseline_copy is None:
            arr = _image_array_np(master, use_cache=False)
            if arr is None:
                return False
            baseline_copy = np.ascontiguousarray(arr, dtype=np.float32) if (np := _np_module()) is not None else arr
        _SAVE_MASTER_BASELINE_CACHE.pop(key, None)
        _SAVE_MASTER_BASELINE_CACHE[key] = {
            'baseline': baseline_copy,
            'master_image': str(getattr(master, 'name', '') or ''),
            'layer_id': _active_layer_id(material),
            'stamp': _array_crc_stamp(master, arr),
            'sample_stamp': _array_sample_stamp(arr, *(_image_size(master)), samples=96),
        }
        _sps_quota.clear_for_memory_pressure()
        try:
            old_name = str(material.get('sps_save_baseline_image_' + channel, '') or '')
            old_img = bpy.data.images.get(old_name) if old_name else None
            if old_img is not None and old_img.users <= 0:
                bpy.data.images.remove(old_img)
        except Exception:
            pass
        try:
            _reuse_session_baseline = bool(isinstance(_MASTER_PAINT_SESSIONS.get(key), dict) and _MASTER_PAINT_SESSIONS.get(key).get('baseline') is baseline_copy)
        except Exception:
            _reuse_session_baseline = False
        if bool(_reuse_session_baseline):
            return True
        try:
            w, h = _image_size(master)
            _base_name = 'SPS_SaveBaseline_' + str(getattr(material, 'name', 'Material')) + '_' + channel
            _name = _base_name
            _idx = 1
            while bpy.data.images.get(_name) is not None:
                _idx += 1
                _name = _base_name + '.' + str(_idx).zfill(3)
            base_img = bpy.data.images.new(_name, int(w), int(h), alpha=True, float_buffer=False)
            try:
                base_img.alpha_mode = 'STRAIGHT'
            except Exception:
                pass
            try:
                base_img.colorspace_settings.name = getattr(getattr(master, 'colorspace_settings', None), 'name', 'sRGB') or 'sRGB'
            except Exception:
                pass
            base_img.pixels.foreach_set(baseline_copy.reshape(-1))
            base_img.update()
            base_img['smart_paint_suite_save_baseline_image'] = True
            base_img['smart_paint_suite_material'] = getattr(material, 'name', '')
            base_img['smart_paint_suite_channel'] = channel
            material['sps_save_baseline_image_' + channel] = base_img.name
        except Exception:
            pass
        return True
    except Exception:
        return False

def start_master_paint_session(material, channel: str = 'BASE_COLOR', *, capture_pixels: bool = False):
    """Start or refresh a master paint session without losing pending deltas.

    The public document texture is Blender's paint target.  For eraser strokes we
    need a stable pre-stroke baseline; otherwise an alpha hole on the flattened
    master looks like "all layers were erased" and cannot be mapped back to only
    the active layer.  Existing sessions are therefore never overwritten by
    ordinary UI target synchronization.  They only update the destination layer
    id, while explicit commits/restarts create the next baseline after the delta
    has been processed.
    """
    if material is None:
        return None
    channel = _safe_channel(channel)
    master = get_master_texture_image(material, channel, create=False)
    if master is None:
        return None
    try:
        _force_public_master_display_opaque_now(material, channel, master)
    except Exception:
        pass
    key = _session_key(material, channel)
    layer_id = _active_layer_id(material)
    try:
        existing = _MASTER_PAINT_SESSIONS.get(key)
        current_stack_sig = _master_session_stack_signature(material, channel)
        if existing is not None:
            old_stack_sig = str(existing.get('stack_signature', '') or '')
            if (current_stack_sig and old_stack_sig and current_stack_sig != old_stack_sig) or (current_stack_sig and not old_stack_sig):
                # Stale sessions are unsafe: the public master is a flattened
                # preview, so replaying it against a newer layer stack can move
                # upper-layer pixels into the active/bottom layer.
                _MASTER_PAINT_SESSIONS.pop(key, None)
                existing = None
            else:
                existing['layer_id'] = layer_id
                try:
                    existing['master_image'] = str(getattr(master, 'name', '') or '')
                except Exception:
                    pass
                try:
                    if existing.get('layers_snapshot') is None:
                        existing['layers_snapshot'] = _master_paint_layers_snapshot(material, channel)
                except Exception:
                    pass
                if existing.get('baseline') is not None or not bool(capture_pixels):
                    return master
                # Existing lazy session but caller now requests exact safety baseline.
                # Continue below and replace it with an exact snapshot.
    except Exception:
        pass
    try:
        mw, mh = _image_size(master)
        pixels = int(mw) * int(mh)
        _explicit_capture_request = bool(capture_pixels)
        interactive_limit = min(max(1, int(_MASTER_LIVE_EXACT_BASELINE_PIXEL_LIMIT)), 2048 * 2048)
        if has_selection_mask(material, channel) and not _explicit_capture_request:
            capture_pixels = bool(pixels <= _SELECTION_EXACT_BASELINE_PIXEL_LIMIT)
        elif pixels > 0 and pixels <= interactive_limit:
            # Moderate documents get an exact baseline immediately.  This makes
            # Image Editor and 3D Texture Paint eraser strokes deterministic.
            capture_pixels = True
        # For small/medium documents an explicit request gets an exact baseline.
        # On 4K/8K production PSDs this allocation is hundreds of MiB and made
        # Add Layer appear frozen.  Large documents defer exact recovery to the
        # save/metadata boundary, comparing the public master against the on-disk
        # PSD preview or a bounded dirty region instead.
        if _explicit_capture_request and pixels <= interactive_limit:
            capture_pixels = True
        elif _explicit_capture_request:
            capture_pixels = False
            try:
                _defer_exact_master_baseline_for_large_image(material, channel, master)
            except Exception:
                pass
    except Exception:
        pass
    sample = _image_sample_stamp(master, 96)
    _session_brush_rgb = _rgb_tuple_or_none(_active_texture_paint_brush_rgb(getattr(bpy, 'context', None)))
    item = {'baseline': None, 'layer_id': layer_id, 'master_image': str(getattr(master, 'name', '') or ''), 'stamp': sample, 'sample_stamp': sample, 'lazy': True, 'paint_op_token': _current_paint_operator_token(), 'stack_signature': _master_session_stack_signature(material, channel), 'layers_snapshot': _master_paint_layers_snapshot(material, channel), 'brush_rgb': _session_brush_rgb}
    try:
        if _session_brush_rgb is not None:
            _ly, _img = _layer_image_for_session(material, layer_id, channel)
            if _img is not None:
                _img['smart_paint_suite_last_source_rgb'] = tuple(float(v) for v in _session_brush_rgb[:3])
    except Exception:
        pass
    if bool(capture_pixels):
        # Exact master baselines are a critical paint-boundary operation.  Read the
        # Blender pixel buffer without an extra clip/copy pass; 2K/4K PSD targets
        # otherwise doubled transient memory and could be killed before layer
        # visibility changes had a chance to commit the stroke.
        arr = _sps_image_array_np_no_clip(master)
        if arr is not None:
            item.update({'baseline': np.ascontiguousarray(arr, dtype=np.float32) if (np := _np_module()) is not None else arr, 'stamp': _array_crc_stamp(master, arr), 'sample_stamp': _array_sample_stamp(arr, *(_image_size(master)), samples=96), 'lazy': False})
    _MASTER_PAINT_SESSIONS[key] = item
    return master


def ensure_selection_master_paint_session(material, channel: str = 'BASE_COLOR') -> bool:
    """Ensure the visible master has a pixel baseline while a selection exists."""
    if material is None:
        return False
    channel = _safe_channel(channel)
    try:
        if not has_selection_mask(material, channel):
            return False
        key = _session_key(material, channel)
        session = _MASTER_PAINT_SESSIONS.get(key)
        if session is not None:
            if session.get('baseline') is not None:
                return True
            # A lazy session is acceptable for large textures when native stencil
            # is active; it avoids a 4K/8K full read at selection creation time.
            try:
                master = get_master_texture_image(material, channel, create=False)
                mw, mh = _image_size(master)
                if int(mw) * int(mh) > _SELECTION_EXACT_BASELINE_PIXEL_LIMIT:
                    return True
            except Exception:
                pass
        return start_master_paint_session(material, channel, capture_pixels=True) is not None
    except Exception:
        return False





def _commit_master_session_before_active_layer_switch(material, channel: str = 'BASE_COLOR') -> bool:
    """Commit real public-master paint to the old layer before selection changes.

    Exact master sessions are also created by display/target synchronization.  A
    layer click must not treat those harmless baselines as brush strokes; doing
    so flattens the current composite into the newly selected private layer and
    later makes PSD export look white or cross-contaminated.  Commit only when
    the live master actually differs from the current private stack projection,
    or an explicit paint marker says Blender still owns an uncommitted stroke.
    """
    try:
        channel = _safe_channel(channel)
        key = _session_key(material, channel)
        session = _MASTER_PAINT_SESSIONS.get(key)
        if session is None:
            return False
        if not str(session.get('layer_id', '') or ''):
            return False
        allow_commit = False
        try:
            allow_commit = bool(_recent_operator_was_paint(getattr(bpy, 'context', None)))
        except Exception:
            allow_commit = False
        try:
            if str(session.get('paint_op_token', '') or ''):
                allow_commit = True
        except Exception:
            pass
        try:
            master = get_master_texture_image(material, channel, create=False)
            if master is not None:
                for _prop in (
                    'smart_paint_suite_pending_visible_paint',
                    'smart_paint_suite_pending_master_paint',
                    'smart_paint_suite_painted_since_last_projection',
                ):
                    try:
                        if bool(master.get(_prop, False)):
                            allow_commit = True
                            break
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            np = _np_module()
            master = get_master_texture_image(material, channel, create=False)
            current = _image_array_np(master, use_cache=False) if master is not None else None
            _cw, _ch, stack_comp = composite_layer_arrays(material, channel)
            if np is not None and current is not None and stack_comp is not None and getattr(stack_comp, 'shape', None) == getattr(current, 'shape', None):
                delta = np.max(np.abs(current[:, :4] - stack_comp[:, :4]), axis=1)
                changed = int(np.count_nonzero(delta > (2.0 / 255.0)))
                total = int(current.shape[0]) if getattr(current, 'shape', None) is not None else 0
                if changed <= 0:
                    # Current display already equals the private stack.  This is
                    # a stale baseline, not pending paint.  Re-arm the session for
                    # the new active layer without touching pixels.
                    try:
                        session['baseline'] = None
                        session['lazy'] = True
                        session['layer_id'] = _active_layer_id(material)
                        session['sample_stamp'] = _image_sample_stamp(master, 96)
                        session['stamp'] = session.get('sample_stamp')
                        _refresh_master_session_signature(session, material, channel)
                    except Exception:
                        pass
                    return False
                # If no explicit paint marker exists, accept only bounded deltas.
                # Full-document mismatches are usually projection/cache changes.
                if total > 0 and (changed <= 262144 or (changed / float(total)) <= 0.35):
                    allow_commit = True
        except Exception:
            pass
        if not allow_commit:
            try:
                session['baseline'] = None
                session['lazy'] = True
                session['layer_id'] = _active_layer_id(material)
                _refresh_master_session_signature(session, material, channel)
            except Exception:
                pass
            return False
        return bool(commit_master_paint_session(material, channel, restart=True, recompose=True, force=False, tolerance=1.0 / 1024.0))
    except Exception:
        return False

def commit_all_master_paint_sessions(*, restart: bool = True, selection_only: bool = False, force: bool = False, tolerance: float = 1.0 / 1024.0) -> int:
    count = 0
    for mat_name, channel in list(_MASTER_PAINT_SESSIONS.keys()):
        mat = bpy.data.materials.get(mat_name)
        if mat is None:
            _MASTER_PAINT_SESSIONS.pop((mat_name, channel), None)
            continue
        try:
            if selection_only and not has_selection_mask(mat, channel):
                continue
            if commit_master_paint_session(mat, channel, restart=restart, force=force, tolerance=tolerance):
                count += 1
        except Exception:
            pass
    return count




def _active_layer_image_for_material(material, channel: str = 'BASE_COLOR'):
    """Return the private image buffer for the currently selected layer/channel."""
    if material is None:
        return None, None
    channel = _safe_channel(channel)
    try:
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is None or not len(getattr(settings, 'layers', ())):
            return None, None
        idx = max(0, min(int(getattr(settings, 'active_layer_index', 0) or 0), len(settings.layers) - 1))
        layer = settings.layers[idx]
        attr = layer_channel_image_attr(channel)
        name = str(getattr(layer, attr, '') or '')
        img = bpy.data.images.get(name) if name else None
        return layer, img
    except Exception:
        return None, None




def save_internal_layer_stack_document(material=None, channel: str = 'BASE_COLOR'):
    from . import clean_layer_stack_engine as _clean
    return _clean.save_internal_layer_stack_document(material, channel)


def adopt_current_projection_without_recompose(material, channel: str = 'BASE_COLOR'):
    from . import clean_layer_stack_engine as _clean
    return _clean.adopt_current_projection_without_recompose(material, channel)

def activate_master_paint_target(context, material, channel: str = 'BASE_COLOR', *, switch_to_paint: bool = True):
    """Make the whole stack visible through material mode and a selected paint slot."""
    channel = _safe_channel(channel)
    try:
        return ensure_layer_stack_display_matches(material, channel, context, commit_pending=True, switch_to_paint=switch_to_paint)
    except Exception:
        pass
    try:
        master = install_master_display_node(material, channel)
    except Exception:
        master = None
    if master is None:
        try:
            master = write_composite_to_master(material, channel)
        except Exception:
            master = get_master_texture_image(material, channel, create=False)
    if master is None:
        return None
    try:
        start_master_paint_session(material, channel)
    except Exception:
        pass
    ctx = context or getattr(bpy, 'context', None)
    try:
        set_material_paint_slot_to_master(material, channel)
    except Exception:
        pass
    try:
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        suite_settings = getattr(scene, 'smart_paint_suite_integrated', None) if scene is not None else None
        if suite_settings is not None:
            try:
                suite_settings.active_paint_image = master
            except Exception:
                pass
            try:
                suite_settings.active_paint_material = material
            except Exception:
                pass
    except Exception:
        pass
    try:
        _force_single_image_canvas(ctx, material, channel, master)
    except Exception:
        pass
    try:
        ts = getattr(ctx, 'tool_settings', None)
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        if ip is not None:
            try:
                ip.mode = 'MATERIAL'
            except Exception:
                pass
            try:
                sync_selection_stencil(ctx, material, channel)
            except Exception:
                pass
    except Exception:
        pass
    try:
        obj = getattr(ctx, 'object', None)
        if switch_to_paint and obj is not None and getattr(obj, 'type', None) == 'MESH':
            if getattr(obj, 'mode', 'OBJECT') != 'TEXTURE_PAINT':
                try:
                    if getattr(obj, 'mode', 'OBJECT') != 'OBJECT':
                        bpy.ops.object.mode_set(mode='OBJECT')
                except Exception:
                    pass
                try:
                    bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
                except Exception:
                    pass
        set_material_paint_slot_to_master(material, channel)
    except Exception:
        pass
    try:
        # The Image Editor also shows the same master texture, never a private
        # layer buffer.  This makes every layer selection look like the same PSD.
        from .core_operators import _show_image_in_image_editors
        _show_image_in_image_editors(ctx, master)
    except Exception:
        pass
    try:
        for area in getattr(getattr(ctx, 'screen', None), 'areas', ()):
            if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR'}:
                area.tag_redraw()
    except Exception:
        pass
    return master


def _selection_live_sessions_exist() -> bool:
    """Return True when a master paint session has an active selection mask."""
    try:
        for mat_name, channel in list(_MASTER_PAINT_SESSIONS.keys()):
            mat = bpy.data.materials.get(mat_name)
            if mat is not None and has_selection_mask(mat, channel):
                return True
    except Exception:
        pass
    return False


def _commit_selection_master_paint_sessions(*, restart: bool = True) -> int:
    count = 0
    for mat_name, channel in list(_MASTER_PAINT_SESSIONS.keys()):
        mat = bpy.data.materials.get(mat_name)
        if mat is None:
            _MASTER_PAINT_SESSIONS.pop((mat_name, channel), None)
            continue
        try:
            if has_selection_mask(mat, channel):
                if commit_master_paint_session(mat, channel, restart=restart, force=True):
                    count += 1
        except Exception:
            pass
    return count


def _master_paint_timer():
    """Retired compatibility callback; no master-image polling remains."""
    global _MASTER_TIMER_RUNNING, _MASTER_TIMER_IDLE_TICKS
    _MASTER_TIMER_RUNNING = False
    _MASTER_TIMER_IDLE_TICKS = 0
    _sps_finish_pending_status('master_paint_sync')
    return None



def register_live_paint_timer():
    """Compatibility API: live paint uses explicit operation/save boundaries."""
    global _MASTER_TIMER_RUNNING, _MASTER_TIMER_IDLE_TICKS
    _MASTER_TIMER_RUNNING = False
    _MASTER_TIMER_IDLE_TICKS = 0
    try:
        if _sps_runtime_registry.timer_registered(_master_paint_timer):
            _sps_runtime_registry.unregister_timer(_master_paint_timer)
    except (_sps_runtime_registry.RegistrationError, RuntimeError, ReferenceError):
        pass
    _sps_finish_pending_status('master_paint_sync')
    return None


def unregister_live_paint_timer():
    global _MASTER_TIMER_RUNNING, _SELECTION_LIVE_TIMER_REQUESTED, _DIRECT_LAYER_PAINT_TIMER_RUNNING, _DIRECT_LAYER_PAINT_HEARTBEAT_RUNNING, _DEFERRED_MASTER_VIEW_TIMER_RUNNING, _MASTER_TIMER_IDLE_TICKS, _DIRECT_LAYER_PAINT_IDLE_TICKS
    try:
        if _sps_runtime_registry.timer_registered(_master_paint_timer):
            _sps_runtime_registry.unregister_timer(_master_paint_timer)
    except Exception:
        pass
    try:
        if _sps_runtime_registry.timer_registered(_direct_layer_paint_timer):
            _sps_runtime_registry.unregister_timer(_direct_layer_paint_timer)
    except Exception:
        pass
    try:
        if _sps_runtime_registry.timer_registered(_direct_layer_paint_heartbeat_timer):
            _sps_runtime_registry.unregister_timer(_direct_layer_paint_heartbeat_timer)
    except Exception:
        pass
    try:
        post = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
        if post is not None:
            _sps_runtime_registry.remove_handler(post, _direct_layer_paint_depsgraph_handler)
    except (_sps_runtime_registry.RegistrationError, RuntimeError, ReferenceError, AttributeError):
        pass
    # Zero-idle means no timers or callbacks are left running; it must not throw
    # away pending save-boundary paint baselines.  Add Layer captures the public
    # master before the user paints, and Save Texture consumes that finite session.
    # Clearing it here made the next save report 「テクスチャ保存に失敗しました。、E    # or fall back to a broad, freezing stack comparison.
    try:
        _DEFERRED_MASTER_VIEW_SYNC.clear()
    except Exception:
        pass
    _DEFERRED_MASTER_VIEW_TIMER_RUNNING = False
    _MASTER_TIMER_RUNNING = False
    _DIRECT_LAYER_PAINT_HEARTBEAT_RUNNING = False
    _MASTER_TIMER_IDLE_TICKS = 0
    _DIRECT_LAYER_PAINT_IDLE_TICKS = 0
    _SELECTION_LIVE_TIMER_REQUESTED = False
    _DIRECT_LAYER_PAINT_TIMER_RUNNING = False
    try:
        for _kind in ('master_paint_sync', 'direct_layer_paint_sync', 'master_view_sync', 'lazy_write_slot'):
            _sps_finish_pending_status(_kind)
    except Exception:
        pass



# -----------------------------------------------------------------------------
# Smart Paint Suite 1.9.59 flat layer-stack engine
# -----------------------------------------------------------------------------
# This overrides the old per-layer shader stack with a constant-size material
# graph.  Layers live as private Image datablocks managed by the add-on.  The
# viewport and Image Editor display a single composited master texture, while a
# single hidden Image Texture node is reused as Blender's native write slot for
# the active layer.  PSD import/export remains layered.

_FLAT_ACTIVE_WRITE_NODE_PREFIX = 'SPS_FlatActiveLayerWrite_'


def _sps_remove_heavy_layer_nodes(material) -> None:
    """Remove legacy Smart Paint shader-stack nodes without touching user nodes.

    The previous node architecture created a TexImage/Mix chain for each layer.
    In flat-engine mode the material needs only: Output, Principled, composited
    master TexImage, and one hidden active-layer write TexImage.  This cleanup is
    intentionally conservative: it removes nodes explicitly marked by Smart Paint
    or named with the Smart Paint prefix, and preserves ordinary user nodes.
    """
    try:
        if material is None or not getattr(material, 'use_nodes', False):
            return
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return
        for node in list(getattr(nt, 'nodes', ()) or ()):
            try:
                ntype = getattr(node, 'type', '')
                if ntype == 'OUTPUT_MATERIAL':
                    continue
                remove = False
                try:
                    remove = bool(node.get('sps_node')) or bool(node.get('sps_master_display_node')) or bool(node.get('sps_flat_write_node'))
                except Exception:
                    remove = False
                nm = str(getattr(node, 'name', '') or '')
                if nm.startswith('SPS_') or nm.startswith('.SPS_') or nm.startswith(_FLAT_ACTIVE_WRITE_NODE_PREFIX):
                    remove = True
                if remove:
                    try:
                        nt.nodes.remove(node)
                    except Exception:
                        pass
            except Exception:
                continue
    except Exception:
        pass


def _sps_get_or_create_output_node(material):
    try:
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return None
        outputs = [n for n in nt.nodes if getattr(n, 'type', '') == 'OUTPUT_MATERIAL']
        if outputs:
            node = next((n for n in outputs if getattr(n, 'is_active_output', False)), outputs[0])
        else:
            node = nt.nodes.new('ShaderNodeOutputMaterial')
            node.name = 'SPS_Output'
            node.label = 'Smart Paint Output'
        try:
            node.is_active_output = True
        except Exception:
            pass
        return node
    except Exception:
        return None


def _sps_get_or_create_principled_node(material):
    try:
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return None
        for n in nt.nodes:
            try:
                if getattr(n, 'type', '') == 'BSDF_PRINCIPLED' and bool(n.get('sps_flat_principled')):
                    return n
            except Exception:
                pass
        for n in nt.nodes:
            if getattr(n, 'type', '') == 'BSDF_PRINCIPLED':
                try:
                    n['sps_flat_principled'] = True
                except Exception:
                    pass
                return n
        node = nt.nodes.new('ShaderNodeBsdfPrincipled')
        node.name = 'SPS_Flat_Principled'
        node.label = 'Smart Paint Flat Principled'
        node.location = (300.0, 0.0)
        try:
            node['sps_node'] = True
            node['sps_flat_principled'] = True
        except Exception:
            pass
        return node
    except Exception:
        return None


def _sps_socket_by_names(inputs, names):
    try:
        for name in names:
            sock = inputs.get(name)
            if sock is not None:
                return sock
    except Exception:
        pass
    try:
        return inputs[0]
    except Exception:
        return None


def _ensure_master_display_node_minimal(material, channel: str = 'BASE_COLOR', master=None):
    """Create the single shader-visible composite texture node."""
    try:
        if material is None:
            return None
        channel = _safe_channel(channel)
        if not getattr(material, 'use_nodes', False):
            material.use_nodes = True
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return master
        master = master or get_master_texture_image(material, channel, create=False) or write_composite_to_master(material, channel)
        if master is None:
            return None
        output = _sps_get_or_create_output_node(material)
        bsdf = _sps_get_or_create_principled_node(material)
        if output is not None and bsdf is not None:
            try:
                # Keep exactly one BSDF -> Surface link for the flat engine.
                surf = output.inputs[0]
                linked = False
                for link in list(getattr(surf, 'links', ()) or ()):
                    if getattr(link, 'from_node', None) == bsdf:
                        linked = True
                    else:
                        try: nt.links.remove(link)
                        except Exception: pass
                if not linked:
                    nt.links.new(bsdf.outputs[0], surf)
            except Exception:
                pass
        node_name = _master_node_name(channel)
        node = nt.nodes.get(node_name)
        if node is None or getattr(node, 'type', '') != 'TEX_IMAGE':
            node = nt.nodes.new('ShaderNodeTexImage')
            node.name = node_name
            node.label = 'Smart Paint Composite Display'
            node.location = (-260.0, 120.0)
        node.image = master
        try:
            node['sps_node'] = True
            node['sps_master_display_node'] = True
            node['sps_flat_display_node'] = True
            node['sps_channel'] = channel
        except Exception:
            pass
        try:
            if bsdf is not None:
                sock = _sps_socket_by_names(bsdf.inputs, _CHANNEL_SOCKET_NAMES.get(channel, _CHANNEL_SOCKET_NAMES['BASE_COLOR']))
                out = node.outputs.get('Alpha') if channel == 'ALPHA' else node.outputs.get('Color')
                if sock is not None and out is not None:
                    existing_ok = False
                    for link in list(getattr(sock, 'links', ()) or ()):
                        if getattr(link, 'from_node', None) == node:
                            existing_ok = True
                        else:
                            try: nt.links.remove(link)
                            except Exception: pass
                    if not existing_ok:
                        nt.links.new(out, sock)
        except Exception:
            pass
        try:
            _mark_master_as_view_target(material, channel, master)
        except Exception:
            pass
        return master
    except Exception:
        return master


def _ensure_layer_paint_node(material, layer_id: str, channel: str, image):
    """Reuse one hidden write node instead of creating one node per layer.

    This is the core performance change.  The native Texture Paint slot points to
    this node, and the node's image is swapped to the current active layer.  The
    shader-connected display node remains the composited master, so layer count no
    longer increases material graph complexity.
    """
    if material is None or image is None:
        return None
    try:
        channel = _safe_channel(channel)
        if not getattr(material, 'use_nodes', False):
            material.use_nodes = True
        nt = getattr(material, 'node_tree', None)
        if nt is None:
            return None
        name = _FLAT_ACTIVE_WRITE_NODE_PREFIX + channel
        node = nt.nodes.get(name)
        if node is None or getattr(node, 'type', '') != 'TEX_IMAGE':
            # Remove old per-layer direct-write nodes so paint slot count stays bounded.
            for old in list(getattr(nt, 'nodes', ()) or ()):
                try:
                    oname = str(getattr(old, 'name', '') or '')
                    if oname.startswith('SPS_DirectLayerPaint_') or oname.startswith('.SPS_DirectLayerPaint_'):
                        nt.nodes.remove(old)
                except Exception:
                    pass
            node = nt.nodes.new('ShaderNodeTexImage')
            node.name = name
            node.label = 'Smart Paint Active Layer Write'
            node.location = (-260.0, -260.0)
        node.image = image
        try:
            node.hide = True
        except Exception:
            pass
        try:
            node['sps_node'] = True
            node['sps_flat_write_node'] = True
            node['sps_layer_id'] = str(layer_id or '')
            node['sps_channel'] = channel
        except Exception:
            pass
        try:
            nt.nodes.active = node
        except Exception:
            pass
        return node
    except Exception:
        return None


def install_flat_layer_stack_material(material, channel: str = 'BASE_COLOR', context=None, *, force_recompose: bool = True, switch_to_paint: bool = False):
    """Install the constant-size pseudo-layer material engine.

    Visible display is one master texture produced by CPU/vectorized layer
    compositing.  Layer images are never shader-chain nodes.  PSD saving writes
    those private layer images as real PSD layers.
    """
    if material is None:
        return None
    channel = _safe_channel(channel)
    ctx = context or getattr(bpy, 'context', None)
    try:
        material.use_nodes = True
    except Exception:
        pass
    try:
        ensure_private_layer_images(material, channel)
    except Exception:
        pass
    if force_recompose:
        master = write_composite_to_master(material, channel)
    else:
        master = get_master_texture_image(material, channel, create=False) or write_composite_to_master(material, channel)
    if master is None:
        return None
    _sps_remove_heavy_layer_nodes(material)
    _ensure_master_display_node_minimal(material, channel, master)
    try:
        set_material_paint_slot_to_master(material, channel)
    except Exception:
        pass
    try:
        _force_single_image_canvas(ctx, material, channel, master)
    except Exception:
        pass
    try:
        settings = getattr(material, 'smart_paint_suite', None)
        if settings is not None:
            settings.managed = True
    except Exception:
        pass
    try:
        material['sps_flat_layer_stack_engine'] = True
        material['sps_flat_layer_stack_version'] = '1.9.59'
        material['sps_visible_master_image_' + channel] = master.name
    except Exception:
        pass
    if switch_to_paint:
        try:
            obj = getattr(ctx, 'object', None)
            if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', 'OBJECT') != 'TEXTURE_PAINT':
                bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
        except Exception:
            pass
    return material


# Override the previous display installer with the constant-size flat variant.
# -----------------------------------------------------------------------------
# Clean layer-stack engine override (1.9.277)
# -----------------------------------------------------------------------------
# This module is shipped as a required dependency.  Import failures are fatal at
# module initialization instead of silently leaving public APIs bound to stale
# or missing legacy helpers.
from . import clean_layer_stack_engine as _sps_clean_layer_stack_engine

_sps_clean_layer_stack_install = _sps_clean_layer_stack_engine.install
_sps_clean_layer_stack_install(globals())
_connect_target_uv_to_node = _sps_clean_layer_stack_engine._connect_target_uv_to_node
_find_document_file_image = _sps_clean_layer_stack_engine._find_document_file_image
_find_or_create_principled = _sps_clean_layer_stack_engine._find_or_create_principled
_has_pending_master_paint_session = _sps_clean_layer_stack_engine._has_pending_master_paint_session
_target_uv_map_name = _sps_clean_layer_stack_engine._target_uv_map_name
_sps_json = json


def force_document_texture_refresh(material, channel: str = 'BASE_COLOR', context=None, master=None, *, show_editors: bool = True, switch_to_paint: bool = False, force_gpu: bool = True):
    try:
        from .clean_layer_stack_engine import force_document_texture_refresh as _f
        return _f(material, channel, context, master, show_editors=show_editors, switch_to_paint=switch_to_paint, force_gpu=force_gpu)
    except Exception:
        try:
            return sync_document_texture_target(material, channel, context, show_editors=show_editors, switch_to_paint=switch_to_paint)
        except Exception:
            return None


# -----------------------------------------------------------------------------
# JELararagi patch 1.9.182: document texture UI target + master-delta save guard
# -----------------------------------------------------------------------------
# Requirements covered here:
# * Smart Paint never changes View3D viewport shading through this target path.
# * Image Editor canvas and Material Texture Paint active slot remain the document
#   texture chosen by Smart Paint Suite's Layer > Paint Texture Path/Save > Texture.
# * Blender brush pixels written to that document texture are committed into the
#   active Smart Paint layer before PSD/PSB export.

def _sps182_channel(channel: str = 'BASE_COLOR') -> str:
    try:
        return _safe_channel(channel)
    except Exception:
        return str(channel or 'BASE_COLOR').upper()


def _sps182_document_master(material, channel: str = 'BASE_COLOR', *, create: bool = False):
    ch = _sps182_channel(channel)
    master = None
    try:
        master = get_master_texture_image(material, ch, create=bool(create))
    except Exception:
        master = None
    if master is None:
        try:
            name = str(material.get('sps_document_target_image_' + ch, '') or material.get('sps_visible_master_image_' + ch, '') or material.get('sps_master_texture_image_' + ch, '') or '')
            master = bpy.data.images.get(name) if name else None
        except Exception:
            master = None
    if master is None:
        try:
            master = _find_document_file_image(material, ch)
        except Exception:
            master = None
    if master is None and create:
        try:
            master = write_composite_to_master(material, ch, force=False)
        except Exception:
            master = None
    return master


def _sps182_private_native_image(material, channel: str = 'BASE_COLOR'):
    try:
        if material is None:
            return None
        ch = _sps182_channel(channel)
        name = str(material.get('sps_native_write_image_' + ch, '') or '')
        image = bpy.data.images.get(name) if name else None
        if image is None:
            return None
        if bool(image.get('smart_paint_suite_layer_image', False)) and not bool(image.get('smart_paint_suite_master_texture', False)) and not bool(image.get('smart_paint_suite_visible_document', False)):
            return image
    except Exception:
        pass
    return None


def _sps182_is_document_master_image(material, channel: str = 'BASE_COLOR', image=None) -> bool:
    try:
        if material is None or image is None:
            return False
        ch = _sps182_channel(channel)
        try:
            if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_visible_document', False)):
                return True
        except Exception:
            pass
        try:
            master = _sps182_document_master(material, ch, create=False)
            if master is not None and master == image:
                return True
        except Exception:
            pass
        try:
            image_name = str(getattr(image, 'name', '') or '')
            for key in (
                'sps_document_target_image_',
                'sps_visible_master_image_',
                'sps_master_texture_image_',
                'sps_document_file_image_',
            ):
                if image_name and str(material.get(key + ch, '') or '') == image_name:
                    return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def _sps182_active_private_layer_image(material, channel: str = 'BASE_COLOR'):
    try:
        ch = _sps182_channel(channel)
        image = _sps182_private_native_image(material, ch)
        if image is not None:
            return image
        try:
            image = _active_layer_private_image(material, ch)
        except Exception:
            image = None
        if image is None:
            try:
                _layer, image = _active_layer_image_for_material(material, ch)
            except Exception:
                image = None
        if image is None or _sps182_is_document_master_image(material, ch, image):
            return None
        return image
    except Exception:
        pass
    return None


def _sps182_restore_private_material_slot(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    try:
        ch = _sps182_channel(channel)
        image = _sps182_private_native_image(material, ch)
        if image is None:
            return False
        layer_id = ''
        try:
            layer_id = str(image.get('smart_paint_suite_layer_id', '') or _active_layer_id(material) or '')
        except Exception:
            layer_id = ''
        node = _ensure_layer_paint_node(material, layer_id, ch, image)
        try:
            nt = getattr(material, 'node_tree', None)
            if nt is not None and node is not None:
                nt.nodes.active = node
        except Exception:
            pass
        selected = False
        try:
            for idx, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):
                if candidate == image:
                    material.paint_active_slot = int(idx)
                    selected = True
                    break
        except Exception:
            selected = False
        if not selected:
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
            try:
                for idx, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):
                    if candidate == image:
                        material.paint_active_slot = int(idx)
                        selected = True
                        break
            except Exception:
                selected = False
        try:
            master = _sps182_document_master(material, ch, create=False)
            _set_image_paint_canvas_to_private_layer(material, ch, image, context or getattr(bpy, 'context', None))
            if master is not None:
                material['sps_visible_master_image_' + ch] = master.name
                material['sps_document_target_image_' + ch] = master.name
        except Exception:
            pass
        return bool(selected)
    except Exception:
        return False


def _sps182_mark_document_master(material, channel: str = 'BASE_COLOR', master=None) -> None:
    ch = _sps182_channel(channel)
    try:
        master = master or _sps182_document_master(material, ch, create=False)
        if material is not None and master is not None:
            material['sps_master_texture_image_' + ch] = master.name
            material['sps_document_target_image_' + ch] = master.name
            material['sps_visible_master_image_' + ch] = master.name
            material['sps_document_file_image_' + ch] = master.name
            # The native Blender UI slot is intentionally the same document image.
            material['sps_native_write_image_' + ch] = master.name
            material['sps_all_layers_target_runtime_' + ch] = False
    except Exception:
        pass
    try:
        if master is not None:
            master['smart_paint_suite_master_texture'] = True
            master['smart_paint_suite_visible_document'] = True
            master['smart_paint_suite_material'] = str(getattr(material, 'name', '') or '')
            master['smart_paint_suite_channel'] = ch
            try:
                if str(getattr(master.colorspace_settings, 'name', '') or '') != 'sRGB':
                    master.colorspace_settings.name = 'sRGB'
            except Exception:
                pass
            try:
                master.alpha_mode = 'STRAIGHT'
            except Exception:
                pass
    except Exception:
        pass


def _sps182_show_master_in_image_editors(context, master) -> None:
    if master is None:
        return
    try:
        _show_master_in_editors(context or getattr(bpy, 'context', None), master, keep_private_canvas=False)
        return
    except Exception:
        pass
    try:
        from .core_operators import _show_image_in_image_editors
        _show_image_in_image_editors(context or getattr(bpy, 'context', None), master)
        return
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, 'context', None)
        for area in getattr(getattr(ctx, 'screen', None), 'areas', ()) if ctx is not None else ():
            if getattr(area, 'type', '') != 'IMAGE_EDITOR':
                continue
            for space in getattr(area, 'spaces', ()) or ():
                if getattr(space, 'type', '') == 'IMAGE_EDITOR':
                    try:
                        space.image = master
                    except Exception:
                        pass
            try:
                area.tag_redraw()
            except Exception:
                pass
    except Exception:
        pass


def _sps182_set_master_material_slot(material, channel: str = 'BASE_COLOR', master=None, context=None, *, show_editors: bool = True) -> bool:
    ch = _sps182_channel(channel)
    if material is None:
        return False
    master = master or _sps182_document_master(material, ch, create=True)
    if master is None:
        return False
    _sps182_mark_document_master(material, ch, master)
    try:
        if not getattr(material, 'use_nodes', False):
            material.use_nodes = True
        nt = getattr(material, 'node_tree', None)
        if nt is not None:
            node_name = f'SPS_MasterPaint_{ch}'
            node = nt.nodes.get(node_name)
            if node is None or getattr(node, 'type', '') != 'TEX_IMAGE':
                node = nt.nodes.new('ShaderNodeTexImage')
                node.name = node_name
                node.label = 'Smart Paint Composite Display'
            node.image = master
            try:
                node['sps_master_display_node'] = True
                node['sps_flat_display_node'] = True
                node['sps_channel'] = ch
            except Exception:
                pass
            try:
                _connect_target_uv_to_node(nt, node, _target_uv_map_name(material))
            except Exception:
                pass
            try:
                principled = _find_or_create_principled(material)
                socket = _socket_for_channel(principled, ch)
                out_socket = node.outputs.get('Alpha') if ch == 'ALPHA' else node.outputs.get('Color')
                if socket is not None and out_socket is not None:
                    already = False
                    for link in list(getattr(socket, 'links', ()) or ()):  # remove competing SPS/user paint links for this target socket only
                        if getattr(link, 'from_node', None) == node and getattr(link, 'from_socket', None) == out_socket:
                            already = True
                        else:
                            try:
                                nt.links.remove(link)
                            except Exception:
                                pass
                    if not already:
                        try:
                            nt.links.new(out_socket, socket)
                        except Exception:
                            pass
            except Exception:
                pass
            try:
                nt.nodes.active = node
            except Exception:
                pass
    except Exception:
        pass
    try:
        material.update_tag()
        nt = getattr(material, 'node_tree', None)
        if nt is not None:
            nt.update_tag()
        bpy.context.view_layer.update()
    except Exception:
        pass
    try:
        for idx, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):  # Blender Material paint slots.
            if candidate == master:
                material.paint_active_slot = int(idx)
                break
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, 'context', None)
        ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
        ip = getattr(ts, 'image_paint', None) if ts is not None else None
        if ip is not None:
            try:
                ip.mode = 'MATERIAL'
            except Exception:
                pass
            try:
                if hasattr(ip, 'canvas'):
                    ip.canvas = master
            except Exception:
                pass
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
        if scene_settings is not None:
            try:
                scene_settings.active_paint_material = material
            except Exception:
                pass
            try:
                scene_settings.active_paint_image = master
            except Exception:
                pass
    except Exception:
        pass
    if show_editors:
        _sps182_show_master_in_image_editors(context or getattr(bpy, 'context', None), master)
    try:
        # Capture the clean pre-paint baseline only when Blender has not dirtied
        # the document image.  This prevents a post-stroke target sync from
        # overwriting the exact baseline needed for PSD save.
        _sps_skip_master_baseline = False
        try:
            _sps_skip_master_baseline = bool(material.get('sps_skip_master_slot_baseline_' + ch, False))
        except Exception:
            _sps_skip_master_baseline = False
        if not _sps_skip_master_baseline and not bool(getattr(master, 'is_dirty', False)):
            _sps183_preserved_baseline = False
            try:
                capture_master_save_baseline(material, ch)
                _sps183_preserved_baseline = bool(material.get('sps_save_baseline_preserved_after_target_sync_' + ch, False))
            except Exception:
                _sps183_preserved_baseline = False
            try:
                # If a target sync happened after Blender wrote visible pixels, do
                # not take a new exact session from the already-painted master.
                # Save will consume the preserved pre-stroke baseline cache instead.
                start_master_paint_session(material, ch, capture_pixels=(not _sps183_preserved_baseline))
            except Exception:
                pass
        else:
            try:
                start_master_paint_session(material, ch, capture_pixels=False)
            except Exception:
                pass
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, 'context', None)
        for area in getattr(getattr(ctx, 'screen', None), 'areas', ()) if ctx is not None else ():
            if getattr(area, 'type', '') in {'IMAGE_EDITOR', 'VIEW_3D'}:
                area.tag_redraw()
    except Exception:
        pass
    return True


def _sps183_should_precommit_visible_master_delta_for_save(material, channel: str = 'BASE_COLOR') -> bool:
    """Return True only when Save should scan the public master for brush deltas.

    Imported PSD masters are often marked Image.is_dirty by Blender/add-on setup even
    when the user has not painted.  The old unconditional force path read the full
    4K master on every PSD save and could stall unedited production files.  Save-time
    delta recovery is still armed for real paint markers and for the Add Layer ->
    native Texture Paint workflow where a private active layer is recorded.
    """
    try:
        if material is None:
            return False
        ch = _safe_channel(channel)
        master = get_master_texture_image(material, ch, create=False)
        master_name = str(getattr(master, 'name', '') or '') if master is not None else ''
        try:
            for _prop in (
                'smart_paint_suite_dirty_bbox',
                'smart_paint_suite_pending_visible_paint',
                'smart_paint_suite_pending_master_paint',
                'smart_paint_suite_painted_since_last_projection',
                'smart_paint_suite_last_brush_color',
                'smart_paint_suite_test_brush_rgb',
            ):
                if master is not None and master.get(_prop, None) not in (None, False, '', 0):
                    return True
        except Exception:
            pass
        key = _session_key(material, ch)
        base_entry = None
        try:
            base_entry = _SAVE_MASTER_BASELINE_CACHE.get(key)
        except Exception:
            base_entry = None
        sess = None
        try:
            sess = _MASTER_PAINT_SESSIONS.get(key)
        except Exception:
            sess = None
        private_name = ''
        native_name = ''
        try:
            private_name = str(material.get('sps_active_private_layer_image_' + ch, '') or '')
            native_name = str(material.get('sps_native_write_image_' + ch, '') or '')
        except Exception:
            pass
        active_private = bool((private_name and private_name != master_name) or (native_name and native_name != master_name))
        if not active_private:
            return False
        baseline_ready = False
        try:
            baseline_ready = bool(isinstance(base_entry, dict) and base_entry.get('baseline', None) is not None)
        except Exception:
            baseline_ready = False
        try:
            baseline_ready = bool(baseline_ready or (isinstance(sess, dict) and sess.get('baseline', None) is not None))
        except Exception:
            pass
        if not baseline_ready:
            return False
        try:
            if bool(_active_layer_is_clean_intentionally_empty(material, ch)):
                return True
        except Exception:
            pass
        # Existing-layer paint still needs recovery when Blender dirtied the document
        # and Smart Paint is explicitly recording to a private layer image.
        try:
            if master is not None and bool(getattr(master, 'is_dirty', False)):
                _layer_id = str(_active_layer_id(material) or '')
                if _layer_id:
                    return True
        except Exception:
            pass
    except Exception:
        pass
    return False

# -----------------------------------------------------------------------------
# Smart Paint Suite 1.9.64 BodyPaint core reboot
# -----------------------------------------------------------------------------
# The previous tail override intentionally kept Blender's native write slot on the
# flattened document texture and later tried to infer edited layer pixels from that
# master.  That path is the source of disappearing strokes, lightness shifts, and
# merged layer saves.  These final definitions make the installed add-on follow a
# BodyPaint-style projection split: Blender Texture Paint writes to the visible
# document image, while Smart Paint records which private layer receives that
# visible-master delta at save/layer-operation boundaries.

SUITE_OWNER = 'JELararagi:smart_paint_suite'
IMAGE_SCHEMA = 1


def _show_master_in_editors(context, master, *, keep_private_canvas: bool = False) -> bool:
    del keep_private_canvas
    from .core_operators import _show_image_in_image_editors
    return _show_image_in_image_editors(context or getattr(bpy, 'context', None), master)


def _stack_records(material, channel: str = 'BASE_COLOR') -> list:
    if material is None:
        return []
    try:
        _width, _height, records = _sps_clean_layer_stack_engine.collect_layers(material, _sps182_channel(channel))
    except (AttributeError, ImportError, RuntimeError, ValueError):
        return []
    return [dict(item) for item in records or () if isinstance(item, dict)]


def _tag_private_image(image, material, channel: str, layer_id: str) -> None:
    image['smart_paint_suite_layer_image'] = True
    image['smart_paint_suite_material'] = str(getattr(material, 'name', '') or '')
    image['smart_paint_suite_layer_id'] = str(layer_id or '')
    image['smart_paint_suite_channel'] = _sps182_channel(channel)
    image['sps_suite_owner'] = SUITE_OWNER
    image['sps_suite_owner_uuid'] = str(image.get('sps_suite_owner_uuid', '') or uuid.uuid4())
    image['sps_suite_image_schema'] = IMAGE_SCHEMA
    image['sps_suite_owned_image'] = True
    image['sps_suite_canonical_source'] = False


def ensure_active_layer_image(material, channel: str = 'BASE_COLOR', *, create: bool = True, for_paint: bool = False):
    if material is None:
        return None
    ch = _sps182_channel(channel)
    layer, image = _active_layer_image_for_material(material, ch)
    if image is not None and for_paint:
        try:
            if bool(image.get('smart_paint_suite_lazy_psd_pending', False)):
                if not materialize_lazy_psd_layer_image(image):
                    return None
            elif bool(image.get('smart_paint_suite_lazy_blank_layer', False)):
                master = _sps_clean_layer_stack_engine.get_master_texture_image(material, ch, create=False)
                width = int(master.size[0]) if master is not None else 1024
                height = int(master.size[1]) if master is not None else 1024
                if not _materialize_lazy_blank_layer_for_write(image, width, height):
                    return None
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            return None
    if image is not None:
        try:
            _tag_private_image(image, material, ch, getattr(layer, 'layer_id', ''))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        return image
    if not create or layer is None:
        return None
    master = _sps_clean_layer_stack_engine.get_master_texture_image(material, ch, create=False)
    width = int(master.size[0]) if master is not None else 1024
    height = int(master.size[1]) if master is not None else 1024
    layer_id = str(getattr(layer, 'layer_id', '') or uuid.uuid4())
    base = str(getattr(layer, 'name', 'Layer') or 'Layer')
    name = f"SPS_{getattr(material, 'name', 'Material')}_{base}_{ch}"
    image = bpy.data.images.new(name=name, width=max(1, width), height=max(1, height), alpha=True, float_buffer=False)
    try:
        image.generated_color = (1.0, 1.0, 1.0, 0.0)
        image.alpha_mode = 'STRAIGHT'
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    _tag_private_image(image, material, ch, layer_id)
    attr = layer_channel_image_attr(ch)
    setattr(layer, attr, image.name)
    return image


def notify_active_private_layer_bound(material, channel: str, image, *, route: str = '', reason: str = '') -> bool:
    if material is None or image is None:
        return False
    ch = _sps182_channel(channel)
    layer_id = str(image.get('smart_paint_suite_layer_id', '') or _active_layer_id(material) or '')
    _tag_private_image(image, material, ch, layer_id)
    material['sps_active_private_layer_image_' + ch] = image.name
    material['sps_native_write_image_' + ch] = image.name
    material['sps_active_private_route_' + ch] = str(route or '')
    material['sps_active_private_reason_' + ch] = str(reason or '')
    material['sps_enable_direct_paint_timer_' + ch] = False
    return True


def _mark_previous_native_private_if_dirty(material, channel: str = 'BASE_COLOR') -> bool:
    if material is None:
        return False
    ch = _sps182_channel(channel)
    name = str(material.get('sps_active_private_layer_image_' + ch, '') or material.get('sps_native_write_image_' + ch, '') or '')
    image = bpy.data.images.get(name) if name else None
    if image is None:
        return False
    try:
        dirty = bool(getattr(image, 'is_dirty', False)) or bool(image.get('smart_paint_suite_direct_layer_dirty', False))
    except (AttributeError, ReferenceError, TypeError):
        dirty = False
    if dirty:
        image['smart_paint_suite_direct_layer_dirty'] = True
        image['smart_paint_suite_bodypaint_direct_authoritative'] = True
        image['smart_paint_suite_painted_since_last_projection'] = True
        image['smart_paint_suite_user_edited'] = True
    return dirty


def _promote_dirty_layer_images_for_projection(material, channel: str = 'BASE_COLOR') -> bool:
    changed = False
    for item in _stack_records(material, channel):
        image = item.get('image') or item.get('image_ref')
        if image is None:
            continue
        try:
            dirty = bool(getattr(image, 'is_dirty', False)) or bool(image.get('smart_paint_suite_direct_layer_dirty', False))
            if dirty:
                image['smart_paint_suite_bodypaint_direct_authoritative'] = True
                image['smart_paint_suite_user_edited'] = True
                changed = True
        except (AttributeError, ReferenceError, TypeError):
            continue
    if changed:
        try:
            _sps_clean_layer_stack_engine._invalidate_projection_cache(material, _sps182_channel(channel))
        except (AttributeError, RuntimeError, ValueError):
            pass
    return changed


def capture_active_private_layer_pixels(material, channel: str = 'BASE_COLOR', context=None, *, write_back: bool = True) -> bool:
    del context
    image = ensure_active_layer_image(material, channel, create=False, for_paint=False)
    if image is None:
        return False
    changed = bool(getattr(image, 'is_dirty', False))
    try:
        changed = changed or bool(image.get('smart_paint_suite_direct_layer_dirty', False))
    except (AttributeError, ReferenceError, TypeError):
        pass
    if write_back and changed:
        image['smart_paint_suite_direct_layer_dirty'] = True
        image['smart_paint_suite_bodypaint_direct_authoritative'] = True
        image['smart_paint_suite_painted_since_last_projection'] = True
        image['smart_paint_suite_user_edited'] = True
        try:
            width, height = int(image.size[0]), int(image.size[1])
            image['smart_paint_suite_dirty_bbox'] = (0, 0, width, height)
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
        _promote_dirty_layer_images_for_projection(material, channel)
    return changed


def register_direct_layer_paint_session(material, channel: str = 'BASE_COLOR', image=None) -> None:
    # 描き込み先の明示の結び付けだけを行う。タイマーや旧い同期は始めない。
    image = image or ensure_active_layer_image(material, channel, create=True, for_paint=True)
    if image is None:
        return
    notify_active_private_layer_bound(
        material,
        channel,
        image,
        route='psd_io.register_direct_layer_paint_session',
        reason='register_direct_session',
    )


def mark_active_private_layer_for_save(material, channel: str = 'BASE_COLOR', context=None) -> bool:
    # 保存の境目：作業中の層の画素を記録し、境目の理由と時刻を残す。
    changed = capture_active_private_layer_pixels(material, channel, context, write_back=True)
    ch = _sps182_channel(channel)
    if material is not None:
        material['sps_bodypaint_last_boundary_reason_' + ch] = 'save'
        material['sps_bodypaint_last_boundary_time_' + ch] = time.time()
    return bool(changed)


def restore_visible_document_paint_binding(material, channel: str = 'BASE_COLOR', context=None, *, master=None, reason: str = ''):
    del reason
    ch = _sps182_channel(channel)
    master = master or _sps_clean_layer_stack_engine.get_master_texture_image(material, ch, create=True)
    if master is None:
        return None
    try:
        result = _sps_clean_layer_stack_engine.sync_document_texture_target(material, ch, context, show_editors=True, switch_to_paint=False)
    except RuntimeError as exc:
        # 文書の画像が作れなかった時は、元どおり master を表示して返す。
        if str(exc) != 'document_target_not_created':
            raise
        result = None
    _show_master_in_editors(context, result or master, keep_private_canvas=False)
    return result or master


def route_disabled_layer_paint_target(material, channel: str = 'BASE_COLOR', context=None):
    return restore_visible_document_paint_binding(material, channel, context, reason='disabled_layer')


def ensure_source_psd_stack_loaded(material, channel: str = 'BASE_COLOR') -> bool:
    if material is None:
        return False
    ch = _sps182_channel(channel)
    source = str(_sps_clean_layer_stack_engine._clean_lazy_psd_source_path_for_direct_copy(material, ch) or '')
    if not source:
        return True
    path = Path(source)
    if path.is_symlink() or not path.is_file():
        return False
    # Opening is deliberately lazy and occurs only at an explicit save/import
    # boundary.  It validates parseability without retaining the PSD document.
    try:
        from psd_tools import PSDImage
        document = PSDImage.open(path)
        width, height = int(document.width), int(document.height)
        material['sps_source_psd_validated_' + ch] = True
        material['sps_source_psd_size_' + ch] = (width, height)
        return width > 0 and height > 0
    except (ImportError, OSError, ValueError, AttributeError):
        material['sps_source_psd_validated_' + ch] = False
        return False


def _sps_bodypaint_validate_external_document(material, channel: str = 'BASE_COLOR', *, reason: str = 'save') -> bool:
    del reason
    try:
        if not ensure_source_psd_stack_loaded(material, channel):
            return False
        return _sps_clean_layer_stack_engine.ensure_layer_stack_display_matches(
            material, channel, None,
            commit_pending=False,
            switch_to_paint=False,
            force_recompose=False,
            commit_untracked=False,
        ) is not None
    except Exception:
        return False


def arm_direct_layer_paint_sync(material, channel: str = 'BASE_COLOR', image=None, *, force: bool = False) -> bool:
    try:
        ch = _sps182_channel(channel)
        image = image or _sps1965_active_private_image(material, ch, create=True)
        if material is not None:
            material['sps_active_recording_layer_id_' + ch] = str(_active_layer_id(material) or '')
        _set_active_layer_native_write_slot(material, ch)
        if image is not None:
            _register_direct_layer_paint_session(material, ch, image)
        shown = bool(_sps182_set_master_material_slot(material, ch, context=getattr(bpy, 'context', None), show_editors=True))
        return bool(shown or image is not None)
    except Exception:
        return False


def write_composite_to_master(material, channel: str = 'BASE_COLOR', *, force: bool = False):
    try:
        return _sps_clean_layer_stack_engine.write_composite_to_master(material, channel, force=force)
    except Exception:
        return None


def install_master_display_node(material, channel: str = 'BASE_COLOR', *, recompose: bool = True, force_recompose: bool = False):
    try:
        return _sps_clean_layer_stack_engine.install_master_display_node(material, channel, recompose=recompose, force_recompose=force_recompose)
    except RuntimeError as exc:
        # 親画像が無い時は、元どおり None を返す。
        if str(exc) == 'install_master_display_node_failed':
            return None
        return _sps182_document_master(material, channel, create=True)
    except Exception:
        return _sps182_document_master(material, channel, create=True)


def force_document_texture_view_refresh(material, channel: str = 'BASE_COLOR', context=None, *, show_editors: bool = True, switch_to_paint: bool = False):
    return sync_document_texture_target(material, channel, context, show_editors=show_editors, switch_to_paint=switch_to_paint)


def write_texture_file(material, channel: str, filepath: str | Path, file_format: str = '', *, commit_pending: bool = True) -> bool:
    ch = _sps182_channel(channel)
    _sps_psd_save_display_state = None
    try:
        from . import lightweight_mvp as _sps_lightweight_mvp

        _sps_psd_save_display_state = _sps_lightweight_mvp._capture_psd_save_display_state(
            material,
            getattr(bpy, 'context', None),
        )
    except Exception:
        _sps_lightweight_mvp = None

    def _sps_restore_psd_save_display(_ok: bool) -> None:
        try:
            if _sps_lightweight_mvp is not None:
                _sps_lightweight_mvp._restore_psd_save_display_state(
                    material,
                    getattr(bpy, 'context', None),
                    _sps_psd_save_display_state,
                    reason='psd_save_success' if bool(_ok) else 'psd_save_not_completed',
                )
        except Exception:
            pass

    try:
        large_or_lazy = False
        try:
            from .core_operators import _sps_stack_is_large_or_lazy_for_add_layer as _sps_is_large
            large_or_lazy = bool(_sps_is_large(material, ch))
        except Exception:
            large_or_lazy = False
        if large_or_lazy:
            _mark_previous_native_private_if_dirty(material, ch)
            _promote_dirty_layer_images_for_projection(material, ch)
        else:
            mark_active_private_layer_for_save(material, ch)
        # Save must be a lightweight BodyPaint-style boundary.  The PSD writer
        # below preserves source records and reads only edited/new layer pixels; a
        # full document recomposite here can freeze 4K Photoshop-authored stacks
        # before any file bytes are written.
        material['sps_texture_save_prepared_stack_' + ch] = True
    except Exception:
        pass
    try:
        if str(filepath).lower().endswith(('.psd', '.psb', '.pdd')):
            try:
                if bool(material.get('sps_block_legacy_psd_fallback_' + ch, False)):
                    _sps_restore_psd_save_display(False)
                    return False
            except Exception:
                pass
            _sps_ok = bool(write_layered_psd(material, ch, filepath))
            _sps_restore_psd_save_display(_sps_ok)
            return _sps_ok
    except Exception:
        pass
    # PSD 以外の書き出し。保存の境目は上で済ませたので、層の走査はしない。
    _sps_status_scope = None
    _sps_read_scope = False
    try:
        begin_image_array_read_scope('texture_save')
        _sps_read_scope = True
    except Exception:
        _sps_read_scope = False
    try:
        from . import performance_governor as _sps_perf
        _sps_status_scope = _sps_perf.status_scope('texture_save')
        _sps_status_scope.__enter__()
        updater = getattr(_sps_perf, 'force_status_bar_update', None) or getattr(_sps_perf, 'force_status_refresh', None)
        if callable(updater):
            updater('texture_save')
    except Exception:
        _sps_status_scope = None
    path = Path(filepath)
    channel = _safe_channel(ch)
    try:
        material['sps_texture_save_nonce_' + channel] = str(int(time.time_ns()))
        material['sps_texture_save_nonce_active_' + channel] = True
    except Exception:
        pass
    _clear_texture_save_status(material, channel)
    try:
        _prep_key = 'sps_live_save_patches_prepared_' + channel
        if material is not None and _prep_key in material:
            del material[_prep_key]
    except Exception:
        pass
    fmt = str(file_format or '').upper().lstrip('.')
    if fmt == 'JPG':
        fmt = 'JPEG'
    elif fmt == 'TIF':
        fmt = 'TIFF'
    elif fmt == 'EXR':
        fmt = 'OPEN_EXR'
    elif fmt == 'TGA':
        fmt = 'TARGA'
    ext = path.suffix.lower()
    if not fmt:
        if ext == '.psb':
            fmt = 'PSB'
        elif ext in {'.psd', '.pdd'}:
            fmt = 'PSD'
        elif ext in {'.jpg', '.jpeg'}:
            fmt = 'JPEG'
        elif ext in {'.tif', '.tiff'}:
            fmt = 'TIFF'
        elif ext == '.tga':
            fmt = 'TARGA'
        elif ext in {'.exr', '.hdr'}:
            fmt = 'OPEN_EXR'
        elif ext == '.bmp':
            fmt = 'BMP'
        else:
            fmt = 'PNG'
    try:
        material['sps_texture_save_prepared_stack_' + channel] = True
    except Exception:
        pass
    try:
        _consume_texture_save_precommitted(material, channel)
    except Exception:
        pass
    try:
        try:
            _sps_clean_layer_stack_engine._sps_refresh_live_save_patches(material, channel, reason='texture_save')
        except Exception:
            pass
        if fmt in {'PSD', 'PSB'} or path.suffix.lower() in {'.psd', '.psb', '.pdd'}:
            _ok = bool(write_layered_psd(material, channel, path))
        else:
            _ok = bool(write_flattened_texture(material, channel, path, fmt))
        if _ok:
            try:
                _sps_clean_layer_stack_engine._sps_clear_live_save_patch_caches_after_write(material, channel)
            except Exception:
                pass
            for _prop in (f'sps_texture_needs_save_{channel}', f'sps_layer_stack_dirty_{channel}'):
                try:
                    if _prop in material:
                        del material[_prop]
                except Exception:
                    pass
            # Texture Save must return immediately after the file writer succeeds.
            # The previous full proxy_cleanup scan walked every material/node/image in
            # production .blend files and could keep Blender busy after the PSD had
            # already been written, surfacing to the user as "Texture save failed" or
            # a frozen Save button on 4K/new-layer paint.  Keep cleanup zero-idle and
            # bounded here; explicit maintenance commands can still run a full scan.
            try:
                cleanup_stale_proxy_data(max_images=32, aggressive=False, full=False)
            except Exception:
                pass
        _sps_ok = bool(_ok)
    finally:
        try:
            if material is not None and ('sps_save_force_untracked_commit_' + channel) in material:
                del material['sps_save_force_untracked_commit_' + channel]
        except Exception:
            pass
        try:
            if material is not None and ('sps_texture_save_prepared_stack_' + channel) in material:
                del material['sps_texture_save_prepared_stack_' + channel]
        except Exception:
            pass
        try:
            _prep_key = 'sps_live_save_patches_prepared_' + channel
            if material is not None and _prep_key in material:
                del material[_prep_key]
        except Exception:
            pass
        try:
            if material is not None and ('sps_texture_save_nonce_active_' + channel) in material:
                del material['sps_texture_save_nonce_active_' + channel]
        except Exception:
            pass
        try:
            if _sps_status_scope is not None:
                _sps_status_scope.__exit__(None, None, None)
        except Exception:
            pass
        try:
            if _sps_read_scope:
                end_image_array_read_scope()
        except Exception:
            pass
    _sps_restore_psd_save_display(_sps_ok)
    return _sps_ok


def _sps_bodypaint_prefers_source_record_psd_writer(material, channel: str = 'BASE_COLOR') -> bool:
    """Use the byte-preserving writer for Photoshop-authored PSD stacks.

    The small external writer is useful for pure Smart Paint raster stacks, but
    Photoshop adjustment layers, groups, masks and lazy source records must keep
    their original PSD records whenever possible.  Re-emitting those records from
    simplified metadata is what caused Photoshop warning dialogs and dropped
    Photoshop-only rows.
    """
    try:
        from . import clean_layer_stack_engine as _clean
        ch = _sps182_channel(channel)
        _w, _h, layers = _clean.collect_layers(material, ch)
        for item in layers or ():
            try:
                if bool(item.get('is_group', False)):
                    return True
                if str(item.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE':
                    return True
                if str(item.get('psd_raw_adjustment_tags', '') or '') or str(item.get('psd_raw_layer_tags', '') or ''):
                    return True
                image = item.get('image')
                if image is not None:
                    try:
                        source = str(image.get('smart_paint_suite_source_file', '') or '')
                    except Exception:
                        source = ''
                    if source.lower().endswith(('.psd', '.psb', '.pdd')):
                        return True
                    for key in (
                        'smart_paint_suite_lazy_psd_pending',
                        'smart_paint_suite_lazy_psd_layer',
                        'smart_paint_suite_lazy_blank_layer',
                    ):
                        try:
                            if bool(image.get(key, False)):
                                return True
                        except Exception:
                            pass
            except Exception:
                continue
    except Exception:
        return False
    return False


def _sps_bodypaint_copy_compare_name(value: object) -> str:
    try:
        text = str(value or '').strip()
    except Exception:
        text = ''
    if not text:
        return ''
    unavailable = '\u4f7f\u7528\u4e0d\u53ef'
    # UI labels may mark Photoshop-only rows as unavailable, but exact-copy
    # round-trips must still compare against the original PSD row name.
    markers = (
        f'[{unavailable}] ',
        f'\uff08{unavailable}',
        f'({unavailable}',
        f'{unavailable}:',
        '[Unsupported] ',
        'Unsupported:',
        '[Unavailable] ',
        'Unavailable:',
    )
    for marker in markers:
        idx = text.find(marker)
        if idx == 0:
            text = text[len(marker):].strip()
            break
        if idx > 0:
            text = text[:idx].strip()
            break
    if ':' in text:
        # Handles "[Unavailable] Original: reason" after the prefix is removed.
        head, tail = text.split(':', 1)
        if tail.strip():
            text = head.strip()
    return text


def _sps_bodypaint_layer_original_name(item: dict) -> str:
    try:
        layer = item.get('layer')
        if layer is not None:
            original = str(layer.get('sps_psd_original_name', '') or '')
            if original:
                return _sps_bodypaint_copy_compare_name(original)
    except Exception:
        pass
    return _sps_bodypaint_copy_compare_name((item or {}).get('name', ''))


def _sps_bodypaint_image_has_authored_changes(image, src: Path | None = None) -> bool:
    if image is None:
        return False
    strong_dirty_keys = (
        'smart_paint_suite_dirty_bbox',
        'smart_paint_suite_dirty_rects_json',
        'smart_paint_suite_sparse_rgba_patch_b64',
        'smart_paint_suite_sparse_rgba_patch_bbox',
        'smart_paint_suite_last_brush_color',
        'smart_paint_suite_painted_since_last_projection',
        'smart_paint_suite_direct_layer_dirty',
        'smart_paint_suite_dirty_from_master',
        'smart_paint_suite_user_edited',
        'smart_paint_suite_known_brush_color_commit',
        'smart_paint_suite_save_exact_master_delta',
        'smart_paint_suite_exact_fallback_commit',
    )
    for key in strong_dirty_keys:
        try:
            if bool(image.get(key, False)):
                return True
        except Exception:
            pass
    try:
        source_file = str(image.get('smart_paint_suite_source_file', '') or '')
    except Exception:
        source_file = ''
    source_matches = False
    if source_file and src is not None:
        try:
            source_matches = (
                os.path.normcase(os.path.abspath(bpy.path.abspath(source_file))) ==
                os.path.normcase(os.path.abspath(str(src)))
            )
        except Exception:
            source_matches = False
    try:
        lazy_source = bool(image.get('smart_paint_suite_lazy_psd_pending', False)) or bool(image.get('smart_paint_suite_lazy_psd_layer', False))
    except Exception:
        lazy_source = False
    try:
        if bool(getattr(image, 'is_dirty', False)):
            return True
    except Exception:
        pass
    return False


def _sps_bodypaint_source_stack_matches_current(material, channel: str, src: Path, layers: list[dict]) -> bool:
    try:
        doc = read_layered_psd_lazy(str(src), decode_merged=False)
        source_layers = list(doc.get('layers', []) or []) if isinstance(doc, dict) else []
    except Exception:
        return False
    if not source_layers or len(source_layers) != len(layers or []):
        return False
    for item, spec in zip(list(layers or []), source_layers):
        try:
            current_name = _sps_bodypaint_layer_original_name(item)
            source_name = _sps_bodypaint_copy_compare_name(spec.get('name', ''))
            if current_name != source_name:
                return False
            current_group = bool(item.get('is_group', False))
            source_group = bool(spec.get('is_group', False) or int(spec.get('section_type', 0) or 0) in {1, 2})
            if current_group != source_group:
                return False
            if current_group:
                if int(item.get('group_depth', 0) or 0) != int(spec.get('group_depth', 0) or 0):
                    return False
            if bool(item.get('enabled', True)) != bool(spec.get('enabled', True)):
                return False
            if abs(float(item.get('opacity', 1.0) or 0.0) - float(spec.get('opacity', 1.0) or 0.0)) > (1.0 / 255.0 + 1.0e-4):
                return False
            if _sps_blend_key(str(item.get('blend_mode', 'MIX') or 'MIX')) != _sps_blend_key(str(spec.get('blend_mode', 'MIX') or 'MIX')):
                return False
            if _sps_bodypaint_image_has_authored_changes(item.get('image'), src):
                return False
        except Exception:
            return False
    return True


def _sps_bodypaint_copy_untouched_source_psd(material, channel: str, filepath: str | Path) -> bool:
    """Fast exact round-trip for an unchanged Photoshop PSD.

    When the user only loads a PSD and saves it under another name, the only
    correct and fastest result is a byte-for-byte source copy.  This preserves
    Photoshop-only adjustment records, masks, groups, resource blocks and layer
    metadata without re-serializing them in Python.
    """
    try:
        ch = _sps182_channel(channel)
        def _copy_fail(reason: str) -> bool:
            try:
                material['sps_last_psd_source_copy_skip_' + ch] = str(reason)[:512]
            except Exception:
                pass
            return False
        try:
            if bool(material.get('sps_bodypaint_active_private_captured_for_save_' + ch, False)):
                return _copy_fail('active_private_captured_for_save')
        except Exception:
            pass
        dst = Path(filepath)
        try:
            dst_norm = os.path.normcase(os.path.abspath(str(dst)))
        except Exception:
            dst_norm = ''

        def _candidate_source_paths():
            seen = set()

            def _add(value):
                try:
                    text = str(value or '')
                except Exception:
                    text = ''
                if not text:
                    return
                try:
                    path = Path(bpy.path.abspath(text))
                except Exception:
                    path = Path(text)
                try:
                    full = os.path.abspath(str(path))
                    norm = os.path.normcase(full)
                except Exception:
                    return
                if norm in seen:
                    return
                seen.add(norm)
                if dst_norm and norm == dst_norm:
                    return
                if path.exists() and path.suffix.lower() in {'.psd', '.psb', '.pdd'}:
                    yield path

            # sps_texture_path_* is also the Save As destination.  Prefer stable
            # source-path fields and layer image metadata before falling back to it.
            for key in (
                'sps_texture_source_path_' + ch,
                'sps_bodypaint_source_stack_path_' + ch,
                'sps_source_psd_path_' + ch,
                'sps_document_file_path_' + ch,
                'sps_new_layer_master_source_path_' + ch,
            ):
                try:
                    yield from _add(material.get(key, ''))
                except Exception:
                    pass
            try:
                from . import clean_layer_stack_engine as _clean
                _w0, _h0, layer_items = _clean.collect_layers(material, ch)
            except Exception:
                layer_items = []
            for item in list(layer_items or []):
                try:
                    image = item.get('image')
                except Exception:
                    image = None
                if image is None:
                    continue
                for img_key in ('smart_paint_suite_layered_source_path', 'smart_paint_suite_source_file'):
                    try:
                        yield from _add(image.get(img_key, ''))
                    except Exception:
                        pass
            try:
                settings = getattr(material, 'smart_paint_suite', None)
                prop_layers = getattr(settings, 'layers', None) if settings is not None else None
                attr_map = {
                    'BASE_COLOR': 'base_color_image',
                    'COLOR': 'base_color_image',
                    'ALPHA': 'base_color_image',
                    'ROUGHNESS': 'roughness_image',
                    'METALLIC': 'metallic_image',
                    'NORMAL': 'normal_image',
                    'HEIGHT': 'height_image',
                    'EMISSION': 'emission_image',
                }
                image_attr = attr_map.get(str(ch or 'BASE_COLOR').upper(), 'base_color_image')
                for prop_layer in list(prop_layers or ()):
                    image_name = str(getattr(prop_layer, image_attr, '') or '')
                    image = bpy.data.images.get(image_name) if image_name else None
                    if image is None:
                        continue
                    for img_key in ('smart_paint_suite_layered_source_path', 'smart_paint_suite_source_file'):
                        try:
                            yield from _add(image.get(img_key, ''))
                        except Exception:
                            pass
            except Exception:
                pass
            for key in (
                'sps_bodypaint_master_image_',
                'sps_document_target_image_',
                'sps_master_texture_image_',
                'sps_visible_master_image_',
            ):
                try:
                    image = bpy.data.images.get(str(material.get(key + ch, '') or ''))
                except Exception:
                    image = None
                if image is None:
                    continue
                for img_key in ('smart_paint_suite_layered_source_path', 'smart_paint_suite_source_file'):
                    try:
                        yield from _add(image.get(img_key, ''))
                    except Exception:
                        pass
            try:
                yield from _add(material.get('sps_texture_path_' + ch, ''))
            except Exception:
                pass

        src = None
        for candidate in _candidate_source_paths():
            src = candidate
            break
        if src is None:
            return _copy_fail('no_source_path')
        if not src.exists() or src.suffix.lower() not in {'.psd', '.psb', '.pdd'}:
            return _copy_fail('source_missing_or_not_psd')
        same_path = False
        try:
            same_path = (
                os.path.normcase(os.path.abspath(str(src))) ==
                os.path.normcase(os.path.abspath(str(dst)))
            )
        except Exception:
            return _copy_fail('same_path_compare_failed')

        from . import clean_layer_stack_engine as _clean
        _w, _h, layers = _clean.collect_layers(material, ch)
        if not layers:
            return _copy_fail('no_layers')
        try:
            settings = getattr(material, 'smart_paint_suite', None)
            prop_layers = getattr(settings, 'layers', None) if settings is not None else None
            attr_map = {
                'BASE_COLOR': 'base_color_image',
                'COLOR': 'base_color_image',
                'ALPHA': 'base_color_image',
                'ROUGHNESS': 'roughness_image',
                'METALLIC': 'metallic_image',
                'NORMAL': 'normal_image',
                'HEIGHT': 'height_image',
                'EMISSION': 'emission_image',
            }
            image_attr = attr_map.get(str(ch or 'BASE_COLOR').upper(), 'base_color_image')
            for prop_layer in list(prop_layers or ()):
                image_name = str(getattr(prop_layer, image_attr, '') or '')
                image = bpy.data.images.get(image_name) if image_name else None
                if image is None:
                    continue
                try:
                    if bool(image.get('smart_paint_suite_layer_image', False)) and not bool(image.get('smart_paint_suite_master_texture', False)) and not str(image.get('smart_paint_suite_source_file', '') or ''):
                        return _copy_fail('property_layer_new_non_source:' + str(getattr(prop_layer, 'name', ''))[:160])
                except Exception:
                    pass
                if _sps_bodypaint_image_has_authored_changes(image, src):
                    return _copy_fail('property_layer_authored_changes:' + str(getattr(prop_layer, 'name', ''))[:160])
        except Exception:
            pass
        deferred_copy_ok = False
        if not _sps_bodypaint_source_stack_matches_current(material, ch, src, layers):
            try:
                deferred_source = bool(material.get('sps_bodypaint_source_stack_deferred_' + ch, False)) or bool(material.get('sps_bodypaint_load_preview_pending_' + ch, False))
            except Exception:
                deferred_source = False
            if not deferred_source:
                return _copy_fail('source_stack_mismatch')
            try:
                doc = read_layered_psd_lazy(str(src), decode_merged=False)
                source_count = int(len(doc.get('layers', []) or [])) if isinstance(doc, dict) else 0
                if source_count > 0 and len(layers) != source_count:
                    return _copy_fail('current_layer_count_differs_source')
            except Exception:
                return _copy_fail('source_count_read_failed')
            for item in list(layers or []):
                try:
                    if _sps_bodypaint_image_has_authored_changes(item.get('image'), src):
                        return _copy_fail('authored_changes_in_deferred_stack')
                except Exception:
                    return _copy_fail('authored_change_check_failed')
            deferred_copy_ok = True
        source_like = 0
        if deferred_copy_ok:
            source_like = 1
        else:
            for item in layers:
                try:
                    layer_obj = item.get('layer')
                    layer_kind = ''
                    try:
                        layer_kind = str(getattr(layer_obj, 'layer_kind', '') or item.get('layer_kind', '') or '').upper()
                    except Exception:
                        layer_kind = str(item.get('layer_kind', '') or '').upper()
                    if (bool(item.get('is_group', False))
                            or str(item.get('adjustment_type', 'NONE') or 'NONE').upper() != 'NONE'
                            or layer_kind == 'ADJUSTMENT'):
                        source_like += 1
                        continue
                    image = item.get('image')
                    if image is None:
                        return _copy_fail('source_like_image_missing:' + str(item.get('name', ''))[:160])
                    if _sps_bodypaint_image_has_authored_changes(image, src):
                        return _copy_fail('source_like_authored_changes:' + str(item.get('name', ''))[:160])
                    try:
                        source_file = str(image.get('smart_paint_suite_source_file', '') or '')
                    except Exception:
                        source_file = ''
                    if source_file:
                        try:
                            if os.path.normcase(os.path.abspath(bpy.path.abspath(source_file))) == os.path.normcase(os.path.abspath(str(src))):
                                source_like += 1
                                continue
                        except Exception:
                            pass
                    if str(item.get('psd_raw_layer_tags', '') or ''):
                        source_like += 1
                        continue
                    for lazy_key in (
                        'smart_paint_suite_lazy_psd_pending',
                        'smart_paint_suite_lazy_psd_layer',
                        'smart_paint_suite_lazy_blank_layer',
                    ):
                        try:
                            if bool(image.get(lazy_key, False)):
                                source_like += 1
                                break
                        except Exception:
                            pass
                    else:
                        return _copy_fail('not_source_like:' + str(item.get('name', ''))[:160])
                except Exception:
                    return _copy_fail('source_like_loop_exception:' + str(item.get('name', ''))[:160])
        if source_like <= 0:
            return _copy_fail('source_like_zero')
        if same_path:
            try:
                material['sps_last_psd_save_algorithm_' + ch] = 'source_noop_untouched_psd'
                material['sps_last_psd_copy_source_' + ch] = str(src)
            except Exception:
                pass
            return True
        dst.parent.mkdir(parents=True, exist_ok=True)
        import shutil
        try:
            from . import save_trace as _sps_save_trace
            if not _sps_save_trace.guard_psd_file_write(dst, material=material, channel=ch, reason='psd_io_copy_untouched_source_psd', operation='copy2'):
                return _copy_fail('ghost_write_blocked')
            _sps_save_trace.emit_psd_file_write('psd_file_copy2_attempt', dst, material=material, channel=ch, source=str(src), reason='psd_io_copy_untouched_source_psd')
        except Exception:
            pass
        shutil.copy2(str(src), str(dst))
        try:
            material['sps_last_psd_save_algorithm_' + ch] = 'source_copy_untouched_psd'
            material['sps_last_psd_copy_source_' + ch] = str(src)
        except Exception:
            pass
        return bool(dst.exists()) or _copy_fail('copy2_no_destination')
    except Exception:
        return False


def write_layered_psd(material, channel: str, filepath: str | Path) -> bool:
    ch = _sps182_channel(channel)
    try:
        if bool(material.get('sps_block_legacy_psd_fallback_' + ch, False)):
            return False
    except Exception:
        pass
    captured_private = False
    def _has_bodypaint_authored_changes() -> bool:
        try:
            settings = getattr(material, 'smart_paint_suite', None)
            prop_layers = getattr(settings, 'layers', None) if settings is not None else None
            attr_map = {
                'BASE_COLOR': 'base_color_image',
                'COLOR': 'base_color_image',
                'ALPHA': 'base_color_image',
                'ROUGHNESS': 'roughness_image',
                'METALLIC': 'metallic_image',
                'NORMAL': 'normal_image',
                'HEIGHT': 'height_image',
                'EMISSION': 'emission_image',
            }
            image_attr = attr_map.get(str(ch or 'BASE_COLOR').upper(), 'base_color_image')
            for prop_layer in list(prop_layers or ()):
                image_name = str(getattr(prop_layer, image_attr, '') or '')
                image = bpy.data.images.get(image_name) if image_name else None
                if image is None:
                    continue
                try:
                    if bool(image.get('smart_paint_suite_layer_image', False)) and not bool(image.get('smart_paint_suite_master_texture', False)) and not str(image.get('smart_paint_suite_source_file', '') or ''):
                        return True
                except Exception:
                    pass
                if _sps_bodypaint_image_has_authored_changes(image, None):
                    return True
        except Exception:
            pass
        return False
    # 保存の下ごしらえ：描いた層の画素を保存の境目として記録する。
    try:
        large_or_lazy = False
        try:
            from .core_operators import _sps_stack_is_large_or_lazy_for_add_layer as _sps_is_large
            large_or_lazy = bool(_sps_is_large(material, ch))
        except Exception:
            large_or_lazy = False
        if large_or_lazy:
            captured_private = bool(_mark_previous_native_private_if_dirty(material, ch)) or captured_private
            captured_private = bool(_promote_dirty_layer_images_for_projection(material, ch)) or captured_private
        else:
            captured_private = bool(mark_active_private_layer_for_save(material, ch))
        material['sps_texture_save_prepared_stack_' + ch] = True
        if captured_private:
            material['sps_bodypaint_active_private_captured_for_save_' + ch] = True
            try:
                import time as _sps_time
                material['sps_bodypaint_active_private_capture_time_' + ch] = float(_sps_time.time())
            except Exception:
                pass
            try:
                _sps_clean_layer_stack_engine._sps_refresh_live_save_patches(material, ch, reason='psd_save_preflight')
            except Exception:
                pass
    except Exception:
        pass
    authored_changes = bool(_has_bodypaint_authored_changes())
    # 1. 描き変えが無ければ、元の PSD をそのまま写す。
    try:
        if (not authored_changes) and _sps_bodypaint_copy_untouched_source_psd(material, ch, filepath):
            return True
    except Exception:
        pass
    # 2. 描き変えが無ければ、正準の書き手（clean の write_layered_psd）に速い道を選ばせる。
    try:
        # Let the clean/source-record writer decide the fast path.  It can still
        # byte-copy a truly unchanged Photoshop PSD, but it runs after the explicit
        # paint boundary above, so new layers and brush patches cannot be skipped as
        # "untouched" source data.
        if (not authored_changes) and bool(_sps_clean_layer_stack_engine.write_layered_psd(material, ch, filepath)):
            return True
    except Exception:
        pass
    # 3. 見えている親画像の差分を作業中の層へ先に記録してから、正準の書き手を呼ぶ
    #    （旧い外部の書き手の段が行っていた処理を、ここで直接行う）。
    try:
        if bool(_sps183_should_precommit_visible_master_delta_for_save(material, ch)):
            try:
                _force_commit_visible_master_delta_to_active_layer_for_save(material, ch, tolerance=1.0 / 4096.0, force=True)
            except Exception:
                pass
            try:
                mark_texture_save_precommitted(material, ch)
            except Exception:
                pass
        if bool(_sps_clean_layer_stack_engine.write_layered_psd(material, ch, filepath)):
            return True
    except Exception:
        pass
    # 4. 最後にもう一度、正準の書き手を呼ぶ。
    return bool(_sps_clean_layer_stack_engine.write_layered_psd(material, ch, filepath))


def prepare_layer_stack_for_substance_style_save(material, channel: str = 'BASE_COLOR', context=None, *, force_untracked: bool = False, force_recompose: bool = True) -> bool:
    try:
        changed = mark_active_private_layer_for_save(material, channel, context)
        if force_recompose and changed:
            try:
                _sps_clean_layer_stack_engine.write_composite_to_master(material, channel, force=True)
            except RuntimeError as exc:
                # 合成の結果が None の時は、元どおり保存の準備を続ける。
                if str(exc) != 'write_composite_to_master_failed':
                    raise
        return True
    except Exception:
        return False


def ensure_layer_stack_display_matches(material, channel: str = 'BASE_COLOR', context=None, *, commit_pending: bool = True, switch_to_paint: bool = False, force_recompose: bool = False, recompose=None, commit_untracked: bool = True):
    return _sps_clean_layer_stack_engine.ensure_layer_stack_display_matches(
        material, channel, context, commit_pending=commit_pending,
        switch_to_paint=switch_to_paint, force_recompose=force_recompose,
        recompose=recompose, commit_untracked=commit_untracked,
    )


def reload_layer_stack_from_internal_document(material=None, channel: str = 'BASE_COLOR', context=None, *, commit_pending: bool = False, switch_to_paint: bool = False, force_recompose: bool = True):
    return _sps_clean_layer_stack_engine.reload_layer_stack_from_internal_document(
        material, channel, context, commit_pending=commit_pending,
        switch_to_paint=switch_to_paint, force_recompose=force_recompose,
    )


def ensure_selection_live_paint_timer(material=None, channel: str = 'BASE_COLOR') -> None:
    """BodyPaint-core selection path: native stencil, no idle scanner."""
    global _MASTER_TIMER_RUNNING, _SELECTION_LIVE_TIMER_REQUESTED, _MASTER_TIMER_IDLE_TICKS
    _SELECTION_LIVE_TIMER_REQUESTED = False
    _MASTER_TIMER_RUNNING = False
    _MASTER_TIMER_IDLE_TICKS = 0
    try:
        if _sps_runtime_registry.timer_registered(_master_paint_timer):
            _sps_runtime_registry.unregister_timer(_master_paint_timer)
    except Exception:
        pass
    try:
        sync_selection_stencil(getattr(bpy, 'context', None), material, channel)
    except Exception:
        pass


def refresh_selection_live_paint_timer() -> None:
    """Refresh native selection stencil and keep Smart Paint idle."""
    global _MASTER_TIMER_RUNNING, _SELECTION_LIVE_TIMER_REQUESTED, _MASTER_TIMER_IDLE_TICKS
    _SELECTION_LIVE_TIMER_REQUESTED = False
    _MASTER_TIMER_RUNNING = False
    _MASTER_TIMER_IDLE_TICKS = 0
    try:
        if _sps_runtime_registry.timer_registered(_master_paint_timer):
            _sps_runtime_registry.unregister_timer(_master_paint_timer)
    except Exception:
        pass
    try:
        ctx = getattr(bpy, 'context', None)
        mat = None
        ch = 'BASE_COLOR'
        scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
        mat = getattr(scene_settings, 'active_paint_material', None) if scene_settings is not None else None
        if mat is not None:
            ch = str(getattr(scene_settings, 'active_channel', ch) or ch)
        sync_selection_stencil(ctx, mat, ch)
    except Exception:
        try:
            sync_selection_stencil(getattr(bpy, 'context', None), None, 'BASE_COLOR')
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Smart Paint Suite 1.9.65 live-paint final routing
# -----------------------------------------------------------------------------
# Final override for the installed build.  Older tail patches kept Blender's live
# brush target on the flattened PSD preview and tried to recover layer edits by
# scanning that master image.  On real Photoshop PSD stacks that is both slow and
# lossy.  The invariant here is BodyPaint-style:
#   * Image Editor / material preview show the composited document.
#   * Blender's native brush canvas writes to the active private layer image.
#   * Save / layer-boundary operations mark that private layer authoritative.

def _sps1965_active_private_image(material, channel: str = 'BASE_COLOR', *, create: bool = True):
    try:
        if material is None:
            return None
        ch = _sps182_channel(channel)
        image = None
        try:
            name = str(material.get('sps_active_private_layer_image_' + ch, '') or material.get('sps_native_write_image_' + ch, '') or '')
            image = bpy.data.images.get(name) if name else None
        except Exception:
            image = None
        try:
            active_id = str(_active_layer_id(material) or '')
            image_id = str(image.get('smart_paint_suite_layer_id', '') or '') if image is not None else ''
            if active_id and image_id and image_id != active_id:
                try:
                    _mark_previous_native_private_if_dirty(material, ch)
                except Exception:
                    pass
                image = None
                try:
                    material['sps_active_private_layer_image_' + ch] = ''
                    material['sps_native_write_image_' + ch] = ''
                except Exception:
                    pass
        except Exception:
            pass
        if image is None:
            image = ensure_active_layer_image(material, ch, create=bool(create), for_paint=True)
        if image is None:
            return None
        try:
            if bool(image.get('smart_paint_suite_master_texture', False)) or bool(image.get('smart_paint_suite_visible_document', False)):
                return None
        except Exception:
            pass
        try:
            if int(image.size[0]) <= 1 or int(image.size[1]) <= 1:
                recovered = ensure_active_layer_image(material, ch, create=bool(create), for_paint=True)
                if recovered is not None:
                    image = recovered
                if image is None or int(image.size[0]) <= 1 or int(image.size[1]) <= 1:
                    return None
        except Exception:
            pass
        return image
    except Exception:
        return None


def _sps1965_layer_id_for_image(material, channel: str, image=None) -> str:
    try:
        active_id = str(_active_layer_id(material) or '')
    except Exception:
        active_id = ''
    try:
        if image is not None:
            lid = str(image.get('smart_paint_suite_layer_id', '') or '')
            if lid:
                if active_id and lid != active_id:
                    return active_id
                return lid
    except Exception:
        pass
    try:
        return str(active_id or _active_layer_id(material) or '')
    except Exception:
        return ''


def _sps1965_show_document_preview(material, channel: str = 'BASE_COLOR', context=None):
    try:
        ch = _sps182_channel(channel)
        master = None
        try:
            master = _sps_clean_layer_stack_engine.install_master_display_node(material, ch, recompose=False, force_recompose=False)
        except Exception:
            master = None
        if master is None:
            master = _sps182_document_master(material, ch, create=True)
        if master is not None:
            try:
                _show_master_in_editors(context or getattr(bpy, 'context', None), master, keep_private_canvas=False)
            except Exception:
                try:
                    _sps182_show_master_in_image_editors(context or getattr(bpy, 'context', None), master)
                except Exception:
                    pass
        return master
    except Exception:
        return None


def _sps1965_clear_legacy_live_scanners(material=None, channel: str = 'BASE_COLOR') -> None:
    try:
        ch = _sps182_channel(channel)
    except Exception:
        ch = str(channel or 'BASE_COLOR')
    try:
        if material is not None:
            _MASTER_PAINT_SESSIONS.pop(_session_key(material, ch), None)
    except Exception:
        pass
    try:
        if material is not None:
            _DIRECT_LAYER_PAINT_SESSIONS.pop(_direct_session_key(material, ch), None)
    except Exception:
        pass
    try:
        if _sps_runtime_registry.timer_registered(_master_paint_timer):
            _sps_runtime_registry.unregister_timer(_master_paint_timer)
    except Exception:
        pass
    try:
        if _sps_runtime_registry.timer_registered(_direct_layer_paint_timer):
            _sps_runtime_registry.unregister_timer(_direct_layer_paint_timer)
    except Exception:
        pass
    try:
        if _sps_runtime_registry.timer_registered(_direct_layer_paint_heartbeat_timer):
            _sps_runtime_registry.unregister_timer(_direct_layer_paint_heartbeat_timer)
    except Exception:
        pass


def _sps1965_restore_private_canvas(material, channel: str = 'BASE_COLOR', context=None, image=None) -> bool:
    try:
        ch = _sps182_channel(channel)
        ctx = context or getattr(bpy, 'context', None)
        image = image or _sps1965_active_private_image(material, ch, create=True)
        if material is None or image is None:
            return False
        layer_id = _sps1965_layer_id_for_image(material, ch, image)
        try:
            material['sps_active_recording_layer_id_' + ch] = str(layer_id or '')
            material['sps_active_private_layer_image_' + ch] = image.name
            material['sps_native_write_image_' + ch] = image.name
            material['sps_enable_direct_paint_timer_' + ch] = False
            material['sps_all_layers_target_runtime_' + ch] = False
        except Exception:
            pass
        try:
            image['smart_paint_suite_layer_image'] = True
            image['smart_paint_suite_material'] = str(getattr(material, 'name', '') or '')
            image['smart_paint_suite_layer_id'] = str(layer_id or '')
            image['smart_paint_suite_channel'] = ch
            image['smart_paint_suite_direct_layer_write_target'] = True
        except Exception:
            pass
        try:
            node = _ensure_layer_paint_node(material, layer_id, ch, image)
            nt = getattr(material, 'node_tree', None)
            if nt is not None and node is not None:
                nt.nodes.active = node
        except Exception:
            pass
        try:
            for idx, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):
                if candidate == image:
                    material.paint_active_slot = int(idx)
                    break
        except Exception:
            pass
        try:
            bpy.context.view_layer.update()
            for idx, candidate in enumerate(getattr(material, 'texture_paint_images', ()) or ()):
                if candidate == image:
                    material.paint_active_slot = int(idx)
                    break
        except Exception:
            pass
        try:
            ts = getattr(ctx, 'tool_settings', None) if ctx is not None else None
            ip = getattr(ts, 'image_paint', None) if ts is not None else None
            if ip is not None:
                try:
                    ip.mode = 'MATERIAL'
                except Exception:
                    pass
                # Blender's native Texture Paint stroke target is still tied to
                # ImagePaint.canvas in several 5.1 paths.  The document/master
                # image remains visible in Image Editors and the shader, but the
                # actual brush write target must be the active private layer.
                try:
                    if hasattr(ip, 'canvas') and getattr(ip, 'canvas', None) is not image:
                        ip.canvas = image
                except Exception:
                    pass
        except Exception:
            pass
        try:
            scene_settings = getattr(getattr(ctx, 'scene', None), 'smart_paint_suite_integrated', None) if ctx is not None else None
            if scene_settings is not None:
                scene_settings.active_paint_material = material
                scene_settings.active_paint_image = image
        except Exception:
            pass
        _sps1965_clear_legacy_live_scanners(material, ch)
        try:
            _sps1965_show_document_preview(material, ch, ctx)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _active_private_layer_image_ready_for_direct_save(material, channel: str = 'BASE_COLOR') -> bool:
    return _sps1965_active_private_image(material, channel, create=False) is not None


def _set_active_layer_native_write_slot(material, channel: str = 'BASE_COLOR'):
    ch = _sps182_channel(channel)
    image = _sps1965_active_private_image(material, ch, create=True)
    if image is not None:
        _sps1965_show_document_preview(material, ch, getattr(bpy, 'context', None))
        _sps1965_restore_private_canvas(material, ch, getattr(bpy, 'context', None), image)
        _sps1965_show_document_preview(material, ch, getattr(bpy, 'context', None))
    return image


def _register_direct_layer_paint_session(material, channel: str = 'BASE_COLOR', image=None) -> None:
    ch = _sps182_channel(channel)
    image = image or _sps1965_active_private_image(material, ch, create=True)
    if material is None or image is None:
        return None
    try:
        material['sps_active_recording_layer_id_' + ch] = _sps1965_layer_id_for_image(material, ch, image)
        material['sps_active_private_layer_image_' + ch] = image.name
        material['sps_native_write_image_' + ch] = image.name
        material['sps_enable_direct_paint_timer_' + ch] = True
    except Exception:
        pass
    try:
        notify_active_private_layer_bound(
            material,
            ch,
            image,
            route='psd_io._register_direct_layer_paint_session',
            reason='direct_layer_session_register',
        )
    except Exception:
        pass
    try:
        _DIRECT_LAYER_PAINT_SESSIONS.pop(_direct_session_key(material, ch), None)
    except Exception:
        pass
    try:
        register_direct_layer_paint_session(material, ch, image)
    except Exception:
        pass
    # Direct layer authoring writes to the active private layer and refreshes the
    # affected composite region at the explicit stroke/edit boundary.  Do not
    # arm the legacy master-delta timer here; it can wake repeatedly on large PSD
    # stacks and was a source of idle freezes.
    try:
        material['sps_enable_direct_paint_timer_' + ch] = False
    except Exception:
        pass
    return None


def _flush_direct_layer_session(material, channel: str = 'BASE_COLOR', *, force: bool = False, context=None) -> bool:
    try:
        image = _sps1965_active_private_image(material, channel, create=False)
        if image is None:
            return False
        captured = bool(capture_active_private_layer_pixels(
            material,
            _sps182_channel(channel),
            context or getattr(bpy, 'context', None),
            write_back=True,
        ))
        if captured or force:
            try:
                image['smart_paint_suite_direct_layer_dirty'] = True
                image['smart_paint_suite_painted_since_last_projection'] = True
            except Exception:
                pass
        return bool(captured or force)
    except Exception:
        return False


def _target_canvas_for_layer_mode(context, material, channel: str = 'BASE_COLOR', visible_master=None):
    return _sps1965_active_private_image(material, channel, create=True) or visible_master or _sps182_document_master(material, channel, create=False)


def set_material_paint_slot_to_master(material, channel: str = 'BASE_COLOR') -> bool:
    master = _sps1965_show_document_preview(material, channel, getattr(bpy, 'context', None))
    image = _sps1965_active_private_image(material, channel, create=False)
    if image is not None:
        ok = bool(_sps1965_restore_private_canvas(material, channel, getattr(bpy, 'context', None), image))
        try:
            _sps1965_show_document_preview(material, channel, getattr(bpy, 'context', None))
        except Exception:
            pass
        return bool(ok or master is not None)
    return master is not None


def _set_material_paint_slot_to_image(material, image, channel: str = 'BASE_COLOR', layer_id: str = '') -> bool:
    ch = _sps182_channel(channel)
    if material is None or image is None:
        return False
    try:
        is_private = bool(image.get('smart_paint_suite_layer_image', False)) and not bool(image.get('smart_paint_suite_master_texture', False)) and not bool(image.get('smart_paint_suite_visible_document', False))
    except Exception:
        is_private = False
    if is_private:
        if layer_id:
            try:
                image['smart_paint_suite_layer_id'] = str(layer_id)
                material['sps_active_recording_layer_id_' + ch] = str(layer_id)
            except Exception:
                pass
        _sps1965_show_document_preview(material, ch, getattr(bpy, 'context', None))
        ok = bool(_sps1965_restore_private_canvas(material, ch, getattr(bpy, 'context', None), image))
        try:
            _sps1965_show_document_preview(material, ch, getattr(bpy, 'context', None))
        except Exception:
            pass
        return ok
    return bool(_sps1965_show_document_preview(material, ch, getattr(bpy, 'context', None)) is not None)


def set_active_layer_recording_target_fast(material, channel: str = 'BASE_COLOR') -> bool:
    image = _set_active_layer_native_write_slot(material, channel)
    return image is not None


def set_active_layer_recording_target(material, channel: str = 'BASE_COLOR') -> bool:
    return set_active_layer_recording_target_fast(material, channel)


def sync_document_texture_target(material, channel: str = 'BASE_COLOR', context=None, *, show_editors: bool = True, switch_to_paint: bool = False):
    ch = _sps182_channel(channel)
    ctx = context or getattr(bpy, 'context', None)
    if switch_to_paint:
        try:
            obj = getattr(ctx, 'object', None) if ctx is not None else None
            if obj is not None and getattr(obj, 'type', '') == 'MESH' and getattr(obj, 'mode', '') != 'TEXTURE_PAINT':
                if getattr(obj, 'mode', '') != 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode='OBJECT')
                    except Exception:
                        pass
                try:
                    bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
                except Exception:
                    pass
        except Exception:
            pass
    master = _sps1965_show_document_preview(material, ch, ctx) if show_editors else _sps182_document_master(material, ch, create=True)
    _set_active_layer_native_write_slot(material, ch)
    if show_editors:
        try:
            _sps1965_show_document_preview(material, ch, ctx)
        except Exception:
            pass
    try:
        restore_visible_document_paint_binding(material, ch, ctx, master=master, reason='psd_io_sync_document_texture_target')
    except Exception:
        pass
    return master


def force_master_single_image_paint_target(context=None, material=None, channel: str = 'BASE_COLOR', *, switch_to_paint: bool = False):
    return sync_document_texture_target(material, channel, context or getattr(bpy, 'context', None), show_editors=True, switch_to_paint=switch_to_paint)


def activate_active_layer_paint_target(context, material, channel: str = 'BASE_COLOR', *, switch_to_paint: bool = True):
    ch = _sps182_channel(channel)
    try:
        _mark_previous_native_private_if_dirty(material, ch)
    except Exception:
        pass
    sync_document_texture_target(material, ch, context, show_editors=True, switch_to_paint=switch_to_paint)
    image = _sps1965_active_private_image(material, ch, create=True)
    if image is None:
        try:
            route_disabled_layer_paint_target(material, ch, context or getattr(bpy, 'context', None))
        except Exception:
            pass
        return None
    if image is not None:
        _register_direct_layer_paint_session(material, ch, image)
        _sps1965_show_document_preview(material, ch, context or getattr(bpy, 'context', None))
        try:
            from . import suite_features as _sps_suite_features
            register_keymaps = getattr(_sps_suite_features, '_register_layer_brush_keymaps', None)
            start_router = getattr(_sps_suite_features, '_start_layer_brush_event_router_later', None)
            if callable(register_keymaps):
                register_keymaps()
            if callable(start_router):
                start_router(context or getattr(bpy, 'context', None))
        except Exception:
            pass
    return image


def _sps_bodypaint_commit_private_layer_boundary(material, channel: str = 'BASE_COLOR', context=None, *, refresh_master: bool = False, force: bool = True, reason: str = '') -> bool:
    ch = _sps182_channel(channel)
    large_or_lazy = False
    try:
        from .core_operators import _sps_stack_is_large_or_lazy_for_add_layer as _sps_is_large
        large_or_lazy = bool(_sps_is_large(material, ch))
    except Exception:
        large_or_lazy = False
    if large_or_lazy:
        ok = False
        try:
            ok = bool(_mark_previous_native_private_if_dirty(material, ch)) or ok
            ok = bool(_promote_dirty_layer_images_for_projection(material, ch)) or ok
        except Exception:
            ok = False
    else:
        ok = bool(_flush_direct_layer_session(material, ch, force=force, context=context))
    if refresh_master:
        try:
            _sps1965_show_document_preview(material, ch, context or getattr(bpy, 'context', None))
        except Exception:
            pass
    try:
        if material is not None:
            material['sps_bodypaint_last_boundary_reason_' + ch] = str(reason or '')
            material['sps_bodypaint_last_boundary_time_' + ch] = time.time()
    except Exception:
        pass
    return bool(ok)
