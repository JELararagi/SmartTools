# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Exact-generation resource ownership for Smart Paint Suite.

The registry records every process-global Blender/native resource immediately
at acquisition.  Each row contains the Suite owner UUID, generation UUID,
exact Python/native identity and the remover captured at registration time.
Registration is transactional; failure rolls back only the current generation
in reverse acquisition order.  Unregister is finite and idempotent.

This module never patches Blender APIs, registered Operator methods, Panel.poll,
timers, draw APIs, ``sys.modules`` or foreign/user resources.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
import inspect
import os
import sys
import threading
import time
import types
import uuid
from typing import Any, Callable, Iterable

import bpy
from bpy.app.handlers import persistent

SUITE_ID = "smart_paint_suite"
SUITE_LABEL = "Smart Paint Suite"
SUITE_OWNER_UUID = "a57946f8-8f20-4e88-b304-6d6fc0e3ee7a"
REVISION = "1.9.300"
LEDGER_KEY = "JELARARAGI_SMART_PAINT_RUNTIME_LEDGER_V4"
LEDGER_SCHEMA = 4

# Process-lifetime anchor for the runtime ledger.  Blender REPLACES
# ``bpy.app.driver_namespace`` with a fresh dict on every file load (measured
# on 5.1.2 ec6e62d40fa9), which destroyed the only reference to the ledger and
# left the suite permanently dormant: every ``_record_row(require_ready=True)``
# acquisition raised ``RegistrationError("Smart Paint has no active
# resource-owning generation")`` from persistent boundary handlers and from
# the PSD save/preview pipeline.  A synthetic ``sys.modules`` entry survives
# both file loads and this package's own live-update submodule purge (the
# purge removes only ``<package>.`` keys), so the authoritative ledger can be
# re-published into the fresh driver namespace deterministically.
_ANCHOR_MODULE_NAME = "jelararagi_smart_paint_runtime_ledger_anchor_v1"


def _anchor_store() -> dict[str, Any]:
    module = sys.modules.get(_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart Paint Suite runtime-ledger anchor. Keeps the exact ledger "
            "object reachable across Blender file loads, which replace "
            "bpy.app.driver_namespace. Not an importable module."
        )
        module.SPS_LEDGERS = {}
        sys.modules[_ANCHOR_MODULE_NAME] = module
    store = getattr(module, "SPS_LEDGERS", None)
    if not isinstance(store, dict):
        store = {}
        module.SPS_LEDGERS = store
    return store

_OWNED_POINTER_RNA_CONTRACTS = frozenset({
    ("Material", "smart_paint_suite", "SPSMaterialSettings"),
    ("Object", "smart_paint_workspace", "SPSTemporaryPaintState"),
    ("Scene", "smart_paint_suite", "SPSSceneSettings"),
    ("WindowManager", "smart_paint_suite_runtime_preferences", "SPSAddonPreferences"),
})

_OWNED_VALUE_RNA_CONTRACTS = frozenset({
    ("WindowManager", "sps_external_bridge_backend", "ENUM"),
})

_RNA_PROPERTY_FACTORY_NAMES = frozenset({
    "BoolProperty",
    "CollectionProperty",
    "EnumProperty",
    "FloatProperty",
    "FloatVectorProperty",
    "IntProperty",
    "IntVectorProperty",
    "PointerProperty",
    "StringProperty",
})

# Blender validates the concrete Python callable stored on the class.  It does
# not follow ``__wrapped__`` when counting arguments, therefore these checks use
# the code object Blender will receive rather than ``inspect.signature`` alone.
_OPERATOR_METHOD_ARITY = {
    "execute": (2, False),
    "invoke": (3, False),
    "modal": (3, False),
    "cancel": (2, False),
    "draw": (2, False),
    "check": (2, False),
    "poll": (2, True),
    "description": (3, True),
}


class RegistrationError(RuntimeError):
    """Registration or exact-resource ownership failed."""


class LiveReloadBlocked(RegistrationError):
    """A READY generation still owns displayed RNA/resources."""


def _namespace() -> dict[str, Any]:
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    if not isinstance(namespace, dict):
        raise RegistrationError("bpy.app.driver_namespace is unavailable")
    return namespace


def _new_ledger() -> dict[str, Any]:
    return {
        "schema": LEDGER_SCHEMA,
        "suite": SUITE_ID,
        "owner_uuid": SUITE_OWNER_UUID,
        "active": None,
        "last_failure": None,
        "restart_required": False,
    }


def _ledger(create: bool = True) -> dict[str, Any] | None:
    namespace = _namespace()
    value = namespace.get(LEDGER_KEY)
    if value is None:
        anchored = _anchor_store().get(LEDGER_KEY)
        if isinstance(anchored, dict):
            # A file load replaced driver_namespace; the ledger (and its
            # journal of process-global resources, which all survive a file
            # load) is still authoritative.  Re-publish it deterministically.
            namespace[LEDGER_KEY] = anchored
            value = anchored
    if value is None and create:
        value = _new_ledger()
        namespace[LEDGER_KEY] = value
    if value is not None:
        if not isinstance(value, dict) or int(value.get("schema", -1)) != LEDGER_SCHEMA:
            raise RegistrationError("Smart Paint runtime ledger schema mismatch")
        if value.get("suite") != SUITE_ID or value.get("owner_uuid") != SUITE_OWNER_UUID:
            raise RegistrationError("Smart Paint runtime ledger owner mismatch")
        # Keep the anchor pointing at the exact live ledger object, including
        # one created or adopted by a prior/foreign generation of this suite.
        _anchor_store()[LEDGER_KEY] = value
    return value


def _active_record(*, require_state: Iterable[str] = ()) -> dict[str, Any] | None:
    ledger = _ledger(create=False)
    active = ledger.get("active") if isinstance(ledger, dict) else None
    if not isinstance(active, dict):
        return None
    allowed = set(require_state)
    if allowed and str(active.get("state", "")) not in allowed:
        return None
    if active.get("owner_uuid") != SUITE_OWNER_UUID:
        return None
    return active


@persistent
def _rearm_after_load(*_args):
    """Re-publish the anchored ledger after Blender replaces driver_namespace.

    Registered on ``load_post`` by the root registration transaction, so the
    lifecycle event itself re-establishes the resource-owning generation
    before any overlay boundary handler, autosave, or PSD save runs.  Never
    raises: a persistent handler must not fail foreign handlers or user work.
    """
    try:
        _ledger(create=False)
    except Exception:
        pass


def ensure_runtime_ready() -> bool:
    """Best-effort re-arm; True iff a READY generation owns resources now.

    Reading the ledger re-publishes the anchored record into a freshly
    replaced ``bpy.app.driver_namespace`` (see ``_ledger``).  This never
    creates a new generation and never raises; user-work-first entry points
    (PSD save) call it to guarantee registry dormancy cannot refuse them.
    """
    try:
        return _active_record(require_state={"READY"}) is not None
    except Exception:
        return False


def snapshot() -> dict[str, Any]:
    ledger = _ledger(create=False)
    active = ledger.get("active") if isinstance(ledger, dict) else None
    active = active if isinstance(active, dict) else None
    failure = ledger.get("last_failure") if isinstance(ledger, dict) else None
    failure = failure if isinstance(failure, dict) else {}
    journal = list(active.get("journal", ())) if active else []
    return {
        "state": str(active.get("state", "OFF") if active else "OFF"),
        "owner_uuid": SUITE_OWNER_UUID,
        "generation": str(active.get("generation", "") if active else ""),
        "revision": str(active.get("revision", REVISION) if active else REVISION),
        "journal_count": sum(1 for row in journal if not bool(row.get("released"))),
        "restart_required": bool(ledger.get("restart_required", False)) if isinstance(ledger, dict) else False,
        "failure": str(failure.get("error", "") or ""),
        "component_states": dict(active.get("component_states", {})) if active else {},
    }


def _fault_requested(kind: str, ordinal: int) -> bool:
    requested = str(os.environ.get("SPS_REGISTER_FAULT", "") or "").strip()
    try:
        requested = str(_namespace().get("SPS_REGISTER_FAULT", requested) or requested).strip()
    except RegistrationError:
        pass
    if not requested:
        return False
    target_kind, _, target_ordinal = requested.partition(":")
    if target_kind not in {"*", str(kind)}:
        return False
    if not target_ordinal:
        return True
    try:
        return int(target_ordinal) == int(ordinal)
    except ValueError:
        return False


def _callable_identity(callback: Any) -> tuple[str, str, int]:
    return (
        str(getattr(callback, "__module__", "") or ""),
        str(getattr(callback, "__qualname__", getattr(callback, "__name__", "")) or ""),
        id(callback),
    )


def _exact_attribute(owner: Any, name: str) -> Any:
    """Read only an attribute stored directly on *owner*, including mappingproxy."""
    try:
        mapping = vars(owner)
        getter = getattr(mapping, "get", None)
        return getter(str(name)) if callable(getter) else None
    except (TypeError, AttributeError):
        return None


def _positive_native_pointer(value: Any) -> int:
    try:
        pointer = int(value.as_pointer())
    except Exception:
        return 0
    return pointer if pointer > 0 else 0


def _deferred_pointer_target(descriptor: Any) -> type | None:
    """Return the type recorded by Blender's class-dict PointerProperty value."""
    function = getattr(descriptor, "function", None)
    keywords = getattr(descriptor, "keywords", None)
    pointer_property = getattr(getattr(bpy, "props", None), "PointerProperty", None)
    if function is not pointer_property or not isinstance(keywords, dict):
        return None
    target = keywords.get("type")
    return target if isinstance(target, type) else None


def _safe_python_metadata_signature(value: Any, depth: int = 0) -> tuple[Any, ...]:
    """Describe deferred-property metadata without entering any RNA wrapper."""
    if depth > 8:
        return ("DEPTH_LIMIT",)
    if value is None or isinstance(value, (bool, int, float, str)):
        return (type(value).__name__, value)
    if isinstance(value, type):
        return (
            "TYPE",
            str(getattr(value, "__module__", "") or ""),
            str(getattr(value, "__qualname__", getattr(value, "__name__", "")) or ""),
        )
    if isinstance(value, dict):
        items = [
            (str(key), _safe_python_metadata_signature(item, depth + 1))
            for key, item in value.items()
        ]
        return ("DICT", tuple(sorted(items, key=lambda item: item[0])))
    if isinstance(value, (tuple, list)):
        return (
            type(value).__name__.upper(),
            tuple(_safe_python_metadata_signature(item, depth + 1) for item in value),
        )
    if isinstance(value, (set, frozenset)):
        items = [_safe_python_metadata_signature(item, depth + 1) for item in value]
        return (
            type(value).__name__.upper(),
            tuple(sorted(items, key=lambda item: str(item))),
        )
    if callable(value):
        return (
            "CALLABLE",
            str(getattr(value, "__module__", "") or ""),
            str(getattr(value, "__qualname__", getattr(value, "__name__", "")) or ""),
        )
    value_type = type(value)
    return (
        "OBJECT",
        str(getattr(value_type, "__module__", "") or ""),
        str(getattr(value_type, "__qualname__", getattr(value_type, "__name__", "")) or ""),
    )


def _deferred_rna_schema_signature(cls: type) -> tuple[Any, ...]:
    """Return the safe Python declaration shape for one PropertyGroup class."""
    annotations = _exact_attribute(cls, "__annotations__")
    if not isinstance(annotations, dict):
        return ()
    result = []
    for name, value in annotations.items():
        if isinstance(value, str):
            factory_name = _annotation_property_factory_name(value)
            if factory_name in _RNA_PROPERTY_FACTORY_NAMES:
                result.append((str(name), ("POSTPONED", factory_name)))
            continue
        function = getattr(value, "function", None)
        keywords = getattr(value, "keywords", None)
        if not callable(function) or not isinstance(keywords, dict):
            continue
        result.append((
            str(name),
            (
                "DEFERRED",
                str(getattr(function, "__module__", "") or ""),
                str(getattr(function, "__qualname__", getattr(function, "__name__", "")) or ""),
                _safe_python_metadata_signature(keywords),
            ),
        ))
    return tuple(result)


def _existing_owned_pointer_record(owner: Any, name: str, rna_type: type) -> dict[str, Any] | None:
    """Validate ownership using only safe owner/property and Python metadata.

    Blender stores the exact ``_PropertyDeferred`` assignment in the owner
    class dictionary after registering a dynamic property.  Its callable and
    ``keywords['type']`` remain ordinary Python objects even when the old
    StructRNA has been unregistered.  The bound target's native RNA metadata is
    intentionally never entered on this boundary: an invalid native wrapper can
    access-violate before Python can catch an exception.
    """
    descriptor = _exact_attribute(owner, str(name))
    if descriptor is None:
        return None
    try:
        property_name = str(name)
        owner_rna = getattr(owner, "bl_rna", None)
        owner_identifier = str(getattr(owner_rna, "identifier", "") or "")
        canonical_owner = getattr(getattr(bpy, "types", None), owner_identifier, None)
        canonical_owner_rna = getattr(canonical_owner, "bl_rna", None)
        owner_pointer = _positive_native_pointer(owner_rna)
        canonical_owner_pointer = _positive_native_pointer(canonical_owner_rna)
        properties = getattr(owner_rna, "properties", None)
        property_get = getattr(properties, "get", None)
        rna_property = property_get(property_name) if callable(property_get) else None
        expected_rna = getattr(rna_type, "bl_rna", None)
        expected_identifier = str(getattr(expected_rna, "identifier", "") or "")
        expected_pointer = _positive_native_pointer(expected_rna)
        target_type = _deferred_pointer_target(descriptor)
        target_identifier = str(getattr(target_type, "__name__", "") or "")
        target_module = str(getattr(target_type, "__module__", "") or "")
        target_qualname = str(
            getattr(target_type, "__qualname__", getattr(target_type, "__name__", "")) or ""
        )
        expected_module = str(getattr(rna_type, "__module__", "") or "")
        expected_qualname = str(
            getattr(rna_type, "__qualname__", getattr(rna_type, "__name__", "")) or ""
        )
        property_group_base = getattr(getattr(bpy, "types", None), "PropertyGroup", None)
        try:
            target_is_property_group = bool(
                target_type is not None
                and property_group_base is not None
                and issubclass(target_type, property_group_base)
            )
        except TypeError:
            target_is_property_group = False
        target_schema = _deferred_rna_schema_signature(target_type) if target_type is not None else ()
        expected_schema = _deferred_rna_schema_signature(rna_type)
        exact_owned_pointer = bool(
            owner_rna is not None
            and canonical_owner_rna is not None
            and owner_pointer > 0
            and owner_pointer == canonical_owner_pointer
            and (owner_identifier, property_name, expected_identifier) in _OWNED_POINTER_RNA_CONTRACTS
            and rna_property is not None
            and str(getattr(rna_property, "type", "") or "") == "POINTER"
            and str(getattr(rna_property, "identifier", "") or "") == property_name
            and bool(getattr(rna_property, "is_runtime", False))
            and _positive_native_pointer(rna_property) > 0
            and target_is_property_group
            and target_identifier == expected_identifier
            and target_module == expected_module
            and target_qualname == expected_qualname
            and bool(target_schema)
            and target_schema == expected_schema
            and expected_pointer > 0
        )
    except Exception:
        return None
    if not exact_owned_pointer:
        return None
    return {
        "descriptor": descriptor,
        "target_type": target_type,
        "property_pointer": _positive_native_pointer(rna_property),
        "expected_pointer": expected_pointer,
        "current": target_type is rna_type,
    }


def _retire_stale_owned_pointer(owner: Any, name: str, rna_type: type) -> str:
    """Adopt an exact current pointer or retire an exact stale declaration."""
    first = _existing_owned_pointer_record(owner, name, rna_type)
    if first is None:
        return ""
    if bool(first.get("current")):
        return "CURRENT"
    second = _existing_owned_pointer_record(owner, name, rna_type)
    if (
        second is None
        or bool(second.get("current"))
        or second.get("descriptor") is not first.get("descriptor")
        or second.get("target_type") is not first.get("target_type")
        or second.get("property_pointer") != first.get("property_pointer")
    ):
        return ""
    try:
        delattr(owner, str(name))
    except Exception as exc:
        raise RegistrationError(
            f"stale Smart Paint pointer could not be retired: {owner!r}.{name}: "
            f"{type(exc).__name__}:{exc}"
        ) from exc
    if _exact_attribute(owner, name) is not None:
        raise RegistrationError(f"stale Smart Paint pointer remained after retirement: {owner!r}.{name}")
    try:
        if owner.bl_rna.properties.get(str(name)) is not None:
            raise RegistrationError(f"stale Smart Paint RNA metadata remained after retirement: {owner!r}.{name}")
    except RegistrationError:
        raise
    except Exception as exc:
        raise RegistrationError(
            f"stale Smart Paint RNA retirement could not be verified: {owner!r}.{name}: "
            f"{type(exc).__name__}:{exc}"
        ) from exc
    return "RETIRED"


def _existing_owned_value_record(owner: Any, name: str, expected: Any) -> dict[str, Any] | None:
    """Validate one exact Smart Paint non-pointer runtime RNA declaration."""
    descriptor = _exact_attribute(owner, str(name))
    if descriptor is None:
        return None
    try:
        property_name = str(name)
        owner_rna = getattr(owner, "bl_rna", None)
        owner_identifier = str(getattr(owner_rna, "identifier", "") or "")
        canonical_owner = getattr(getattr(bpy, "types", None), owner_identifier, None)
        canonical_owner_rna = getattr(canonical_owner, "bl_rna", None)
        owner_pointer = _positive_native_pointer(owner_rna)
        canonical_owner_pointer = _positive_native_pointer(canonical_owner_rna)
        properties = getattr(owner_rna, "properties", None)
        property_get = getattr(properties, "get", None)
        rna_property = property_get(property_name) if callable(property_get) else None

        descriptor_function = getattr(descriptor, "function", None)
        descriptor_keywords = getattr(descriptor, "keywords", None)
        expected_function = getattr(expected, "function", None)
        expected_keywords = getattr(expected, "keywords", None)
        factory_name = str(getattr(expected_function, "__name__", "") or "")
        expected_rna_type = {
            "BoolProperty": "BOOLEAN",
            "EnumProperty": "ENUM",
            "FloatProperty": "FLOAT",
            "FloatVectorProperty": "FLOAT",
            "IntProperty": "INT",
            "IntVectorProperty": "INT",
            "StringProperty": "STRING",
        }.get(factory_name, "")
        descriptor_signature = _safe_python_metadata_signature(
            {key: value for key, value in descriptor_keywords.items() if str(key) != "attr"}
        ) if isinstance(descriptor_keywords, dict) else ()
        expected_signature = _safe_python_metadata_signature(
            {key: value for key, value in expected_keywords.items() if str(key) != "attr"}
        ) if isinstance(expected_keywords, dict) else ()
        exact_owned_value = bool(
            owner_rna is not None
            and canonical_owner_rna is not None
            and owner_pointer > 0
            and owner_pointer == canonical_owner_pointer
            and expected_rna_type
            and (owner_identifier, property_name, expected_rna_type) in _OWNED_VALUE_RNA_CONTRACTS
            and rna_property is not None
            and str(getattr(rna_property, "type", "") or "") == expected_rna_type
            and str(getattr(rna_property, "identifier", "") or "") == property_name
            and bool(getattr(rna_property, "is_runtime", False))
            and _positive_native_pointer(rna_property) > 0
            and callable(descriptor_function)
            and descriptor_function is expected_function
            and isinstance(descriptor_keywords, dict)
            and isinstance(expected_keywords, dict)
            and bool(descriptor_signature)
            and descriptor_signature == expected_signature
        )
    except Exception:
        return None
    if not exact_owned_value:
        return None
    return {
        "descriptor": descriptor,
        "property_pointer": _positive_native_pointer(rna_property),
        "signature": descriptor_signature,
        "current": descriptor is expected,
    }


def _retire_stale_owned_value(owner: Any, name: str, expected: Any) -> str:
    """Adopt an exact descriptor or retire an exact prior-generation value property."""
    first = _existing_owned_value_record(owner, name, expected)
    if first is None:
        return ""
    if bool(first.get("current")):
        return "CURRENT"
    second = _existing_owned_value_record(owner, name, expected)
    if (
        second is None
        or bool(second.get("current"))
        or second.get("descriptor") is not first.get("descriptor")
        or second.get("property_pointer") != first.get("property_pointer")
        or second.get("signature") != first.get("signature")
    ):
        return ""
    try:
        delattr(owner, str(name))
    except Exception as exc:
        raise RegistrationError(
            f"stale Smart Paint RNA property could not be retired: {owner!r}.{name}: "
            f"{type(exc).__name__}:{exc}"
        ) from exc
    if _exact_attribute(owner, name) is not None:
        raise RegistrationError(
            f"stale Smart Paint RNA property remained after retirement: {owner!r}.{name}"
        )
    try:
        if owner.bl_rna.properties.get(str(name)) is not None:
            raise RegistrationError(
                f"stale Smart Paint RNA metadata remained after retirement: {owner!r}.{name}"
            )
    except RegistrationError:
        raise
    except Exception as exc:
        raise RegistrationError(
            f"stale Smart Paint RNA retirement could not be verified: {owner!r}.{name}: "
            f"{type(exc).__name__}:{exc}"
        ) from exc
    return "RETIRED"


def _registered_ui_class_category(cls: type) -> str:
    for name in ("Operator", "Panel", "UIList"):
        base = getattr(getattr(bpy, "types", None), name, None)
        try:
            if base is not None and issubclass(cls, base):
                return name
        except TypeError:
            continue
    return ""


def _registered_ui_class_identifier(cls: type, category: str) -> str:
    if category == "Operator":
        category_name, separator, operator_name = str(getattr(cls, "bl_idname", "") or "").partition(".")
        if separator and category_name and operator_name:
            return f"{category_name.upper()}_OT_{operator_name}"
    return str(getattr(cls, "__name__", "") or "")


def _registered_ui_class_collision(cls: type) -> type | None:
    category = _registered_ui_class_category(cls)
    if not category:
        return None
    identifier = _registered_ui_class_identifier(cls, category)
    existing = getattr(getattr(bpy, "types", None), identifier, None)
    if not isinstance(existing, type) or existing is cls or not _class_is_registered(existing):
        return None
    return existing


def _stale_owned_ui_class(cls: type, existing: type | None = None) -> type | None:
    """Return only an exact prior-generation Smart Paint UI/input class."""
    category = _registered_ui_class_category(cls)
    if not category:
        return None
    existing = existing if isinstance(existing, type) else _registered_ui_class_collision(cls)
    if existing is None:
        return None
    try:
        exact_owned = bool(
            _registered_ui_class_category(existing) == category
            and str(getattr(existing, "__module__", "") or "")
            == str(getattr(cls, "__module__", "") or "")
            and str(getattr(existing, "__qualname__", "") or "")
            == str(getattr(cls, "__qualname__", "") or "")
            and str(getattr(existing, "__name__", "") or "")
            == str(getattr(cls, "__name__", "") or "")
            and str(getattr(existing, "bl_idname", "") or "")
            == str(getattr(cls, "bl_idname", "") or "")
        )
    except Exception:
        return None
    return existing if exact_owned else None


def _class_is_registered(cls: type) -> bool:
    """Return registration state for this exact class object only."""
    checker = getattr(getattr(bpy, "utils", None), "is_registered_class", None)
    if callable(checker):
        try:
            return bool(checker(cls))
        except (RuntimeError, ReferenceError, TypeError, ValueError):
            return False
    return _exact_attribute(cls, "bl_rna") is not None


def _package_prefix() -> str:
    """Dotted module prefix of this suite's installed package."""
    name = str(__name__ or "")
    return name.rpartition(".")[0] if "." in name else name


def _owned_module_name(module_name: Any) -> bool:
    """True only for modules inside this exact installed package."""
    prefix = _package_prefix()
    name = str(module_name or "")
    return bool(prefix) and (name == prefix or name.startswith(prefix + "."))


def _retire_owned_pointer_contracts(*, targeting: type | None = None) -> tuple[list[type], list[str]]:
    """Detach this suite's contracted RNA properties; return their target types.

    Only the exact ``_OWNED_POINTER_RNA_CONTRACTS`` / ``_OWNED_VALUE_RNA_CONTRACTS``
    declarations are touched, and a pointer is removed only when its deferred
    target type belongs to this package (or is the specific *targeting* class).
    Foreign RNA is never entered.
    """
    targets: list[type] = []
    errors: list[str] = []
    for owner_identifier, name, _expected in sorted(_OWNED_POINTER_RNA_CONTRACTS):
        owner = getattr(getattr(bpy, "types", None), owner_identifier, None)
        if owner is None:
            continue
        descriptor = _exact_attribute(owner, name)
        if descriptor is None:
            continue
        target = _deferred_pointer_target(descriptor)
        owned = target is not None and _owned_module_name(getattr(target, "__module__", ""))
        if targeting is not None:
            if target is not targeting:
                continue
        elif not owned:
            continue
        try:
            delattr(owner, name)
            if target is not None and target not in targets:
                targets.append(target)
        except Exception as exc:
            errors.append(f"pointer:{owner_identifier}.{name}:{type(exc).__name__}:{exc}")
    if targeting is None:
        for owner_identifier, name, _kind in sorted(_OWNED_VALUE_RNA_CONTRACTS):
            owner = getattr(getattr(bpy, "types", None), owner_identifier, None)
            if owner is None:
                continue
            descriptor = _exact_attribute(owner, name)
            if descriptor is None:
                continue
            function = getattr(descriptor, "function", None)
            if str(getattr(function, "__name__", "") or "") not in _RNA_PROPERTY_FACTORY_NAMES:
                continue
            try:
                delattr(owner, name)
            except Exception as exc:
                errors.append(f"value:{owner_identifier}.{name}:{type(exc).__name__}:{exc}")
    return targets, errors


def _orphaned_package_classes(extra: Iterable[type] = ()) -> list[type]:
    """Every still-registered class that belongs to this exact package."""
    property_group_base = getattr(getattr(bpy, "types", None), "PropertyGroup", None)
    found: list[type] = []
    seen: set[int] = set()

    def _collect(value: Any) -> None:
        if (
            isinstance(value, type)
            and id(value) not in seen
            and _owned_module_name(getattr(value, "__module__", ""))
            and _class_is_registered(value)
        ):
            seen.add(id(value))
            found.append(value)

    for module_name, module in list(sys.modules.items()):
        if module is None or not _owned_module_name(module_name):
            continue
        for value in list(vars(module).values()):
            _collect(value)
    for name in dir(bpy.types):
        _collect(getattr(bpy.types, name, None))
    for value in extra:
        _collect(value)
    # Unregister UI/operator classes before PropertyGroups so pointer targets
    # outlive their users inside this best-effort pass.
    def _is_property_group(cls: type) -> bool:
        try:
            return property_group_base is not None and issubclass(cls, property_group_base)
        except TypeError:
            return False

    return sorted(found, key=_is_property_group)


def _sweep_dormant_leftovers() -> dict[str, Any]:
    """Module-prefix-owned fallback teardown when no journal can drive it.

    USER EVIDENCE 2 (2026-08-20): with the ledger unreachable, 1.9.289's
    ``unregister`` skipped everything, and the next enable failed with
    ``RegistrationError: Exact class identity is already registered outside
    this acquisition``.  This sweep removes ONLY resources whose identity is
    inside this installed package: handlers whose callback module is ours,
    the suite's contracted RNA properties, classes whose ``__module__`` is
    ours, and this package's translation catalog.  Draw handlers and timers
    cannot be enumerated by Blender's API and are left to their own
    generation-guarded callbacks.
    """
    result: dict[str, Any] = {
        "handlers": 0, "pointers": 0, "classes": 0, "errors": [],
    }
    handlers_root = getattr(getattr(bpy, "app", None), "handlers", None)
    for list_name in dir(handlers_root):
        handler_list = getattr(handlers_root, list_name, None)
        if not isinstance(handler_list, list):
            continue
        for callback in list(handler_list):
            if not _owned_module_name(getattr(callback, "__module__", "")):
                continue
            try:
                handler_list.remove(callback)
                result["handlers"] += 1
            except (ValueError, RuntimeError) as exc:
                result["errors"].append(f"handler:{list_name}:{type(exc).__name__}:{exc}")
    targets, pointer_errors = _retire_owned_pointer_contracts()
    result["pointers"] = len(targets)
    result["errors"].extend(pointer_errors)
    for cls in _orphaned_package_classes(extra=targets):
        try:
            bpy.utils.unregister_class(cls)
            result["classes"] += 1
        except (RuntimeError, ReferenceError, ValueError, TypeError) as exc:
            result["errors"].append(
                f"class:{getattr(cls, '__name__', cls)!s}:{type(exc).__name__}:{exc}"
            )
    try:
        bpy.app.translations.unregister(_package_prefix())
    except Exception:
        pass
    return result


def _assert_registered_rna_type(cls: type, *, label: str = "RNA type") -> None:
    if not isinstance(cls, type) or not _class_is_registered(cls):
        raise RegistrationError(
            f"{label} must be registered before PointerProperty publication: "
            f"{getattr(cls, '__module__', '')}.{getattr(cls, '__name__', repr(cls))}"
        )
    rna = getattr(cls, "bl_rna", None)
    if rna is None:
        raise RegistrationError(
            f"{label} is registered without bl_rna: "
            f"{getattr(cls, '__module__', '')}.{getattr(cls, '__name__', repr(cls))}"
        )


def _annotation_property_factory_name(expression: str) -> str:
    try:
        node = ast.parse(str(expression), mode="eval").body
    except (SyntaxError, ValueError):
        return ""
    if not isinstance(node, ast.Call):
        return ""
    function = node.func
    if isinstance(function, ast.Name):
        return str(function.id)
    if isinstance(function, ast.Attribute):
        return str(function.attr)
    return ""


def _declared_rna_property_names(cls: type) -> tuple[str, ...]:
    annotations = _exact_attribute(cls, "__annotations__")
    if not isinstance(annotations, dict):
        return ()
    result: list[str] = []
    for name, value in annotations.items():
        if isinstance(value, str):
            factory_name = _annotation_property_factory_name(value)
            if factory_name in _RNA_PROPERTY_FACTORY_NAMES:
                result.append(str(name))
            continue
        # Blender's deferred property values are intentionally opaque.  Their
        # stable public traits are a ``function`` and keyword mapping; avoid a
        # dependency on private bpy implementation classes.
        function = getattr(value, "function", None)
        keywords = getattr(value, "keywords", None)
        if callable(function) and isinstance(keywords, dict):
            result.append(str(name))
    return tuple(result)


def _materialize_deferred_rna_annotations(cls: type) -> tuple[str, ...]:
    """Reject postponed ``bpy.props`` annotations before global registration.

    Blender 5.1's RNA metaclass captures ``_PropertyDeferred`` objects while
    the class body is created.  Replacing a postponed string in
    ``__annotations__`` later does not publish that property to RNA.  Therefore
    every shipping RNA module must keep Blender property annotations eager;
    this guard fails during the pure class preflight instead of allowing a
    partially registered class with missing properties.
    """
    annotations = _exact_attribute(cls, "__annotations__")
    if not isinstance(annotations, dict):
        return ()
    postponed = []
    for name, value in annotations.items():
        if not isinstance(value, str):
            continue
        if _annotation_property_factory_name(value) in _RNA_PROPERTY_FACTORY_NAMES:
            postponed.append(str(name))
    if postponed:
        raise RegistrationError(
            f"Postponed Blender RNA properties are unsupported in Blender 5.1: "
            f"{cls.__module__}.{cls.__name__}: {', '.join(postponed)}"
        )
    return ()


def _property_group_dependencies(cls: type) -> tuple[type, ...]:
    """Return exact custom PropertyGroup targets declared by *cls*."""
    annotations = _exact_attribute(cls, "__annotations__")
    if not isinstance(annotations, dict):
        return ()
    property_group_base = getattr(getattr(bpy, "types", None), "PropertyGroup", None)
    found: list[type] = []
    seen: set[int] = set()
    for value in annotations.values():
        function = getattr(value, "function", None)
        keywords = getattr(value, "keywords", None)
        function_name = str(getattr(function, "__name__", "") or "")
        if function_name not in {"PointerProperty", "CollectionProperty"} or not isinstance(keywords, dict):
            continue
        target = keywords.get("type")
        try:
            is_property_group = (
                isinstance(target, type)
                and property_group_base is not None
                and issubclass(target, property_group_base)
            )
        except TypeError:
            is_property_group = False
        if not is_property_group or target is cls or id(target) in seen:
            continue
        seen.add(id(target))
        found.append(target)
    return tuple(found)


def _custom_descriptor(cls: type, name: str) -> tuple[Any, type] | tuple[None, None]:
    """Find the concrete Python descriptor Blender resolves for an Operator.

    ``ImportHelper``/``ExportHelper`` can appear after ``bpy.types.Operator`` in
    the MRO, so skipping only Blender's built-in base is required.  Stopping at
    it would miss an inherited ``invoke`` implementation and leave part of the
    registered callback surface unvalidated.
    """
    operator_base = getattr(getattr(bpy, "types", None), "Operator", None)
    for base in getattr(cls, "__mro__", (cls,)):
        if base in {object, operator_base}:
            continue
        mapping = vars(base)
        if name in mapping:
            return mapping[name], base
    return None, None


def _validate_operator_method(cls: type, method_name: str) -> dict[str, Any] | None:
    descriptor, owner = _custom_descriptor(cls, method_name)
    if descriptor is None:
        return None
    expected_arity, require_classmethod = _OPERATOR_METHOD_ARITY[method_name]
    is_classmethod = isinstance(descriptor, classmethod)
    if isinstance(descriptor, staticmethod):
        raise RegistrationError(
            f"Operator {cls.__name__}.{method_name} must not be a staticmethod"
        )
    if require_classmethod != is_classmethod:
        required = "classmethod" if require_classmethod else "instance method"
        raise RegistrationError(
            f"Operator {cls.__name__}.{method_name} must be a {required}"
        )
    if isinstance(descriptor, (classmethod, staticmethod)):
        function = descriptor.__func__
    else:
        function = descriptor
    code = getattr(function, "__code__", None)
    if code is None:
        raise RegistrationError(
            f"Operator {cls.__name__}.{method_name} has no inspectable Python code object"
        )
    has_varargs = bool(code.co_flags & inspect.CO_VARARGS)
    has_varkw = bool(code.co_flags & inspect.CO_VARKEYWORDS)
    actual_arity = int(code.co_argcount)
    if (
        actual_arity != int(expected_arity)
        or int(code.co_kwonlyargcount) != 0
        or has_varargs
        or has_varkw
    ):
        raise RegistrationError(
            f"Operator {cls.__name__}.{method_name} signature invalid: "
            f"expected {expected_arity} positional args, got {actual_arity}; "
            f"kwonly={code.co_kwonlyargcount}, varargs={has_varargs}, varkw={has_varkw}"
        )
    return {
        "class": str(cls.__name__),
        "method": str(method_name),
        "owner": str(getattr(owner, "__name__", "")),
        "arity": actual_arity,
        "classmethod": is_classmethod,
        "varargs": has_varargs,
        "varkw": has_varkw,
    }


def validate_operator_class(cls: type) -> list[dict[str, Any]]:
    """Fail-fast validation of every Blender Operator callback signature."""
    operator_base = getattr(getattr(bpy, "types", None), "Operator", None)
    try:
        is_operator = operator_base is not None and issubclass(cls, operator_base)
    except TypeError:
        is_operator = False
    if not is_operator:
        return []
    report: list[dict[str, Any]] = []
    for method_name in _OPERATOR_METHOD_ARITY:
        row = _validate_operator_method(cls, method_name)
        if row is not None:
            report.append(row)
    return report


def validate_registration_classes(classes: Iterable[type]) -> dict[str, Any]:
    """Pure preflight for a complete static registration manifest."""
    seen_identity: set[int] = set()
    operator_idnames: dict[str, str] = {}
    method_rows: list[dict[str, Any]] = []
    class_count = 0
    operator_count = 0
    for cls in tuple(classes):
        if not isinstance(cls, type):
            raise RegistrationError(f"Registration manifest contains a non-class: {cls!r}")
        if id(cls) in seen_identity:
            raise RegistrationError(f"Registration manifest repeats exact class identity: {cls.__name__}")
        seen_identity.add(id(cls))
        class_count += 1
        _materialize_deferred_rna_annotations(cls)
        rows = validate_operator_class(cls)
        if rows:
            operator_count += 1
            bl_idname = str(getattr(cls, "bl_idname", "") or "")
            previous = operator_idnames.get(bl_idname)
            if bl_idname and previous is not None:
                raise RegistrationError(
                    f"Duplicate Operator bl_idname {bl_idname}: {previous}, {cls.__name__}"
                )
            if bl_idname:
                operator_idnames[bl_idname] = str(cls.__name__)
            method_rows.extend(rows)
    return {
        "class_count": class_count,
        "operator_count": operator_count,
        "method_count": len(method_rows),
        "methods": method_rows,
    }


def _registered_property_table(cls: type) -> Any:
    """Return the concrete RNA property table produced for *cls*.

    Blender stores custom Operator properties on the callable returned through
    ``bpy.ops`` rather than on ``cls.bl_rna`` (which describes the shared
    ``Operator`` base).  PropertyGroups and the remaining RNA classes expose
    their concrete table directly on ``cls.bl_rna``.
    """
    operator_base = getattr(getattr(bpy, "types", None), "Operator", None)
    try:
        is_operator = operator_base is not None and issubclass(cls, operator_base)
    except TypeError:
        is_operator = False
    if is_operator:
        bl_idname = str(getattr(cls, "bl_idname", "") or "")
        category, separator, operator_name = bl_idname.partition(".")
        if not separator or not category or not operator_name:
            raise RegistrationError(f"Operator has invalid bl_idname: {cls.__name__}:{bl_idname!r}")
        try:
            operator = getattr(getattr(bpy.ops, category), operator_name)
            rna = operator.get_rna_type()
        except (AttributeError, RuntimeError, ReferenceError, TypeError, ValueError) as exc:
            raise RegistrationError(
                f"Registered Operator RNA is unavailable: {cls.__name__}:{type(exc).__name__}:{exc}"
            ) from exc
    else:
        rna = getattr(cls, "bl_rna", None)
    properties = getattr(rna, "properties", None) if rna is not None else None
    if properties is None:
        raise RegistrationError(f"Registered class has no RNA property table: {cls.__name__}")
    return properties


def _verify_registered_properties(cls: type, names: Iterable[str]) -> None:
    expected = tuple(dict.fromkeys(str(name) for name in names if str(name)))
    if not expected:
        return
    properties = _registered_property_table(cls)
    missing = []
    for name in expected:
        try:
            present = properties.get(name) is not None
        except (AttributeError, TypeError):
            try:
                present = name in properties.keys()
            except (AttributeError, TypeError):
                present = False
        if not present:
            missing.append(name)
    if missing:
        raise RegistrationError(
            f"Registered class dropped declared RNA properties: {cls.__name__}: {', '.join(missing)}"
        )


def _timer_registered(callback: Callable[..., Any]) -> bool:
    checker = getattr(getattr(getattr(bpy, "app", None), "timers", None), "is_registered", None)
    if not callable(checker):
        return False
    try:
        return bool(checker(callback))
    except (RuntimeError, ReferenceError):
        return False


def _record_row(entry: dict[str, Any], *, require_ready: bool) -> dict[str, Any]:
    states = {"READY"} if require_ready else {"REGISTERING", "READY"}
    active = _active_record(require_state=states)
    if active is None:
        raise RegistrationError("Smart Paint has no active resource-owning generation")
    row = dict(entry)
    row.update({
        "owner_uuid": SUITE_OWNER_UUID,
        "generation": str(active.get("generation", "")),
        "ordinal": len(active.setdefault("journal", [])) + 1,
        "released": False,
    })
    active["journal"].append(row)
    return row


def _remove_rows(predicate: Callable[[dict[str, Any]], bool]) -> list[dict[str, Any]]:
    active = _active_record()
    if active is None:
        return []
    rows = []
    for row in active.setdefault("journal", []):
        if not bool(row.get("released")) and predicate(row):
            row["released"] = True
            rows.append(row)
    return rows


def _run_native_remover(row: dict[str, Any], errors: list[str]) -> bool:
    """Invoke the exact remover captured when *row* was acquired."""
    if bool(row.get("released")):
        return True
    remover = row.get("native_remover")
    try:
        if callable(remover):
            remover()
        row["released"] = True
        return True
    except (RuntimeError, ReferenceError, AttributeError, ValueError, TypeError, OSError) as exc:
        errors.append(
            f"{row.get('kind', '')}:{row.get('name', '')}:"
            f"{type(exc).__name__}:{exc}"
        )
        return False
    except Exception as exc:  # native wrappers can expose platform-specific exceptions
        errors.append(
            f"{row.get('kind', '')}:{row.get('name', '')}:"
            f"{type(exc).__name__}:{exc}"
        )
        return False


def _stop_runtime_resources(active: dict[str, Any], *, timeout: float = 8.0) -> list[str]:
    """Finite teardown while retaining all handles until completion.

    Order: timers -> shared cancel -> I/O unblock -> thread join -> process
    wait/terminate/kill -> draw/handler/msgbus/RNA/classes/callbacks.
    """
    errors: list[str] = []
    rows = list(active.get("journal", ()))

    for row in reversed(rows):
        if row.get("kind") in {"timer", "event_timer"}:
            _run_native_remover(row, errors)

    cancel_event = active.get("cancel_event")
    if isinstance(cancel_event, threading.Event):
        try:
            cancel_event.set()
        except Exception as exc:
            errors.append(f"cancel:{type(exc).__name__}:{exc}")

    # Resource-specific stop callbacks run after the shared cancel has been set.
    for row in reversed(rows):
        if bool(row.get("released")):
            continue
        if row.get("kind") in {"thread", "process"}:
            stop = row.get("stop")
            if callable(stop):
                try:
                    stop()
                except Exception as exc:
                    errors.append(f"{row.get('kind')}_stop:{row.get('name','')}:{type(exc).__name__}:{exc}")

    for row in reversed(rows):
        if row.get("kind") == "io":
            _run_native_remover(row, errors)

    deadline = time.monotonic() + max(0.25, float(timeout))
    for row in reversed(rows):
        if row.get("kind") != "thread" or bool(row.get("released")):
            continue
        thread = row.get("handle")
        try:
            if thread is not None and thread is not threading.current_thread() and thread.is_alive():
                thread.join(max(0.0, deadline - time.monotonic()))
            if thread is not None and thread.is_alive():
                errors.append(f"thread_alive:{row.get('name', getattr(thread, 'name', ''))}")
            else:
                row["released"] = True
        except Exception as exc:
            errors.append(f"thread:{row.get('name','')}:{type(exc).__name__}:{exc}")

    for row in reversed(rows):
        if row.get("kind") != "process" or bool(row.get("released")):
            continue
        process = row.get("handle")
        if process is None:
            row["released"] = True
            continue
        poll = getattr(process, "poll", None)
        wait = getattr(process, "wait", None)
        try:
            running = callable(poll) and poll() is None
            if running and callable(wait):
                try:
                    wait(timeout=max(0.0, deadline - time.monotonic()))
                except Exception as exc:
                    if type(exc).__name__ != "TimeoutExpired":
                        errors.append(f"process_wait:{row.get('name','')}:{type(exc).__name__}:{exc}")
            running = callable(poll) and poll() is None
            if running:
                terminate = getattr(process, "terminate", None)
                if callable(terminate):
                    terminate()
                if callable(wait):
                    try:
                        wait(timeout=min(2.0, max(0.0, deadline - time.monotonic())))
                    except Exception as exc:
                        if type(exc).__name__ != "TimeoutExpired":
                            errors.append(f"process_terminate_wait:{row.get('name','')}:{type(exc).__name__}:{exc}")
            running = callable(poll) and poll() is None
            if running:
                kill = getattr(process, "kill", None)
                if callable(kill):
                    kill()
                if callable(wait):
                    try:
                        wait(timeout=1.0)
                    except Exception as exc:
                        if type(exc).__name__ != "TimeoutExpired":
                            errors.append(f"process_kill_wait:{row.get('name','')}:{type(exc).__name__}:{exc}")
            if callable(poll) and poll() is None:
                errors.append(f"process_alive:{row.get('name','')}")
            else:
                row["released"] = True
        except Exception as exc:
            errors.append(f"process:{row.get('name','')}:{type(exc).__name__}:{exc}")

    # Everything else is exact reverse-order removal.
    for row in reversed(rows):
        if row.get("kind") not in {"timer", "event_timer", "thread", "process", "io"}:
            _run_native_remover(row, errors)
    return errors


@dataclass
class RegistrationTransaction:
    revision: str = REVISION
    generation: str = field(default_factory=lambda: str(uuid.uuid4()))
    journal: list[dict[str, Any]] = field(default_factory=list)
    acquisition_count: int = 0
    state: str = "NEW"
    cancel_event: threading.Event = field(default_factory=threading.Event)

    def begin(self) -> "RegistrationTransaction":
        ledger = _ledger(create=True)
        active = ledger.get("active")
        if isinstance(active, dict):
            state = str(active.get("state", ""))
            if state in {"REGISTERING", "ROLLING_BACK", "UNREGISTERING", "RELOADING"}:
                raise RegistrationError(f"Smart Paint transaction busy: {state}")
            if state in {
                "READY", "ROLLBACK_CLEANUP_FAILED", "UNREGISTER_CLEANUP_FAILED",
                "RELOAD_CLEANUP_FAILED", "FAILED",
            }:
                # A reload is a synchronous lifecycle boundary: stop the exact
                # generation recorded in the persistent ledger before creating
                # any new RNA or process-global resource.  No module-name scan,
                # class-name lookup, interpreter module-table deletion, or foreign cleanup is
                # performed.  Displayed RNA is fully removed before replacement.
                active["state"] = "RELOADING"
                cleanup_errors = _stop_runtime_resources(active, timeout=10.0)
                if cleanup_errors:
                    active["state"] = "RELOAD_CLEANUP_FAILED"
                    ledger["restart_required"] = True
                    ledger["last_failure"] = {
                        "generation": str(active.get("generation", "")),
                        "revision": str(active.get("revision", REVISION)),
                        "error": "old generation cleanup failed before reload",
                        "cleanup_errors": list(cleanup_errors),
                        "time": time.time(),
                    }
                    raise RegistrationError("; ".join(cleanup_errors))
                active["state"] = "UNREGISTERED"
                ledger["active"] = None
            elif state == "UNREGISTERED":
                ledger["active"] = None
            else:
                raise RegistrationError(f"Smart Paint transaction state invalid: {state or 'UNKNOWN'}")
        # Fallback for a predecessor whose ledger died entirely (a dormant
        # 1.9.289 generation lost to a driver_namespace replacement): sweep
        # this package's own leftover handlers/classes/contracted RNA before
        # acquiring anew.  After a normal ledger-driven teardown this finds
        # nothing and is a no-op.
        sweep = _sweep_dormant_leftovers()
        if sweep.get("handlers") or sweep.get("classes") or sweep.get("pointers") or sweep.get("errors"):
            ledger["last_sweep"] = {**sweep, "time": time.time()}
        record = {
            "schema": LEDGER_SCHEMA,
            "suite": SUITE_ID,
            "owner_uuid": SUITE_OWNER_UUID,
            "revision": str(self.revision),
            "generation": str(self.generation),
            "state": "REGISTERING",
            "created_at": time.time(),
            "journal": self.journal,
            "cancel_event": self.cancel_event,
            "component_states": {},
            "error": "",
        }
        ledger["active"] = record
        ledger["last_failure"] = None
        ledger["restart_required"] = False
        self.state = "REGISTERING"
        # The generation's first acquisition is its own lifecycle re-arm:
        # Blender replaces driver_namespace on every file load, and this exact
        # persistent callback re-publishes the anchored ledger on load_post.
        # Journaled like every other resource, so unregister removes it.
        self.add_handler(
            bpy.app.handlers.load_post,
            _rearm_after_load,
            label="runtime_registry.rearm_after_load",
        )
        return self

    @property
    def record(self) -> dict[str, Any]:
        active = _active_record()
        if active is None or str(active.get("generation", "")) != self.generation:
            raise RegistrationError("Registration transaction lost ledger ownership")
        return active

    def _before_acquire(self, kind: str) -> None:
        if self.state != "REGISTERING":
            raise RegistrationError(f"Cannot acquire {kind} while transaction is {self.state}")
        self.acquisition_count += 1
        if _fault_requested(kind, self.acquisition_count):
            raise RegistrationError(f"Injected registration fault at {kind}:{self.acquisition_count}")

    def _append(self, entry: dict[str, Any]) -> None:
        row = dict(entry)
        row.update({
            "owner_uuid": SUITE_OWNER_UUID,
            "generation": self.generation,
            "ordinal": len(self.journal) + 1,
            "released": False,
        })
        self.journal.append(row)

    def preflight_classes(self, classes: Iterable[type]) -> dict[str, Any]:
        if self.state != "REGISTERING":
            raise RegistrationError(f"Cannot preflight classes while transaction is {self.state}")
        report = validate_registration_classes(tuple(classes))
        self.record["class_preflight"] = report
        return report

    def register_class(self, cls: type) -> type:
        validate_operator_class(cls)
        declared_properties = _declared_rna_property_names(cls)
        _materialize_deferred_rna_annotations(cls)
        self._before_acquire("class")

        if _class_is_registered(cls):
            if not _owned_module_name(getattr(cls, "__module__", "")):
                raise RegistrationError(
                    f"Exact class identity is already registered outside this acquisition: "
                    f"{cls.__module__}.{cls.__name__}"
                )
            # USER EVIDENCE 2 (2026-08-20): a dormant generation's skipped
            # teardown left this package's classes registered, and a plain
            # Preferences off->on then failed here.  The identity is provably
            # this package's own current module tree, so ADOPT by retiring the
            # stale registration (detaching our contracted pointers that
            # target it first, so no half-dead PointerProperty window remains)
            # and registering it fresh under the new generation.  Refusal
            # stays in force for genuinely foreign classes above.
            _retire_owned_pointer_contracts(targeting=cls)
            try:
                bpy.utils.unregister_class(cls)
            except (RuntimeError, ReferenceError, ValueError, TypeError) as exc:
                raise RegistrationError(
                    f"dormant Smart Paint class could not be retired for adoption: "
                    f"{cls.__module__}.{cls.__name__}: {type(exc).__name__}:{exc}"
                ) from exc
            if _class_is_registered(cls):
                raise RegistrationError(
                    f"dormant Smart Paint class remained registered after retirement: "
                    f"{cls.__module__}.{cls.__name__}"
                )

        class_collision = _registered_ui_class_collision(cls)
        retired_stale = _stale_owned_ui_class(cls, class_collision)
        if class_collision is not None and retired_stale is None:
            raise RegistrationError(
                f"Refusing to replace foreign RNA class: "
                f"{class_collision.__module__}.{class_collision.__name__}"
            )
        if retired_stale is not None:
            try:
                bpy.utils.unregister_class(retired_stale)
            except (RuntimeError, ReferenceError, ValueError, TypeError) as exc:
                raise RegistrationError(
                    f"stale Smart Paint class could not be retired: "
                    f"{retired_stale.__module__}.{retired_stale.__name__}: "
                    f"{type(exc).__name__}:{exc}"
                ) from exc
            if _class_is_registered(retired_stale):
                raise RegistrationError(
                    f"stale Smart Paint class remained registered: "
                    f"{retired_stale.__module__}.{retired_stale.__name__}"
                )

        try:
            bpy.utils.register_class(cls)
            if not _class_is_registered(cls):
                raise RegistrationError(
                    f"bpy.utils.register_class returned without exact registration: "
                    f"{cls.__module__}.{cls.__name__}"
                )
            _verify_registered_properties(cls, declared_properties)
        except BaseException:
            # Blender can fail after partially publishing an RNA class.  Remove
            # only this exact class identity before propagating so a second
            # addon_utils.enable attempt starts from a clean state.
            if _class_is_registered(cls):
                try:
                    bpy.utils.unregister_class(cls)
                except (RuntimeError, ReferenceError, ValueError, TypeError):
                    pass
            raise

        def _remove(cls=cls):
            if _class_is_registered(cls):
                bpy.utils.unregister_class(cls)

        try:
            self._append({
                "kind": "class", "handle": cls, "identity": id(cls), "name": cls.__name__,
                "declared_property_count": len(declared_properties),
                "retired_stale_existing": retired_stale is not None,
                "native_remover": _remove,
            })
        except BaseException:
            _remove()
            raise
        return cls

    def register_property_group(self, cls: type, *, dependencies: Iterable[type] = ()) -> type:
        property_group_base = getattr(getattr(bpy, "types", None), "PropertyGroup", None)
        try:
            valid = property_group_base is not None and issubclass(cls, property_group_base)
        except TypeError:
            valid = False
        if not valid:
            raise RegistrationError(f"Not a Blender PropertyGroup: {cls!r}")
        declared_dependencies = _property_group_dependencies(cls)
        ordered_dependencies: list[type] = []
        seen_dependencies: set[int] = set()
        for dependency in (*tuple(dependencies), *declared_dependencies):
            if id(dependency) in seen_dependencies:
                continue
            seen_dependencies.add(id(dependency))
            ordered_dependencies.append(dependency)
        for dependency in ordered_dependencies:
            _assert_registered_rna_type(
                dependency,
                label=f"PropertyGroup dependency for {cls.__name__}",
            )
        return self.register_class(cls)

    def add_rna_property_factory(
        self,
        owner: Any,
        name: str,
        factory: Callable[[], Any],
        *,
        kind: str = "rna_property",
    ) -> Any:
        self._before_acquire(kind)
        if _exact_attribute(owner, name) is not None:
            raise RegistrationError(f"RNA property already exists: {owner!r}.{name}")
        try:
            value = factory()
        except Exception as exc:
            raise RegistrationError(
                f"RNA property factory failed: {owner!r}.{name}: {type(exc).__name__}:{exc}"
            ) from exc
        try:
            setattr(owner, name, value)
            acquired = _exact_attribute(owner, name)
            if acquired is None:
                raise RegistrationError(f"RNA property publication failed: {owner!r}.{name}")
        except BaseException:
            if _exact_attribute(owner, name) is not None:
                try:
                    delattr(owner, name)
                except (AttributeError, RuntimeError, ReferenceError, TypeError):
                    pass
            raise

        def _remove(owner=owner, name=str(name), acquired=acquired):
            if _exact_attribute(owner, name) is acquired:
                delattr(owner, name)

        try:
            self._append({
                "kind": str(kind), "handle": acquired, "owner": owner, "name": str(name),
                "owner_identity": id(owner), "identity": id(acquired), "native_remover": _remove,
            })
        except BaseException:
            _remove()
            raise
        return acquired

    def add_rna_property(self, owner: Any, name: str, value: Any, *, kind: str = "rna_property") -> Any:
        return self.add_rna_property_factory(
            owner,
            name,
            lambda value=value: value,
            kind=kind,
        )

    def add_owned_rna_property(
        self,
        owner: Any,
        name: str,
        value: Any,
        *,
        kind: str = "rna_property",
    ) -> Any:
        """Replace only an exact prior-generation Smart Paint value property."""
        existing = _exact_attribute(owner, name)
        existing_action = ""
        if existing is not None:
            existing_action = _retire_stale_owned_value(owner, name, value)
            if not existing_action:
                raise RegistrationError(f"RNA property already exists: {owner!r}.{name}")
        if existing_action == "CURRENT":
            self._before_acquire(kind)
            current_record = _existing_owned_value_record(owner, name, value)
            if current_record is None or current_record.get("descriptor") is not existing:
                raise RegistrationError(
                    f"current Smart Paint RNA property could not be adopted: {owner!r}.{name}"
                )
            captured_pointer = int(current_record.get("property_pointer", 0) or 0)

            def _remove_adopted(
                owner=owner,
                name=str(name),
                value=value,
                existing=existing,
                captured_pointer=captured_pointer,
            ):
                record = _existing_owned_value_record(owner, name, value)
                if (
                    record is not None
                    and record.get("descriptor") is existing
                    and int(record.get("property_pointer", 0) or 0) == captured_pointer
                ):
                    delattr(owner, name)

            try:
                self._append({
                    "kind": str(kind),
                    "handle": existing,
                    "owner": owner,
                    "name": str(name),
                    "owner_identity": id(owner),
                    "identity": id(existing),
                    "native_property_pointer": captured_pointer,
                    "adopted_existing_exact": True,
                    "retired_stale_existing": False,
                    "native_remover": _remove_adopted,
                })
            except BaseException:
                _remove_adopted()
                raise
            return existing
        acquired = self.add_rna_property(owner, name, value, kind=kind)
        if self.journal and self.journal[-1].get("handle") is acquired:
            self.journal[-1]["adopted_existing_exact"] = False
            self.journal[-1]["retired_stale_existing"] = existing_action == "RETIRED"
        return acquired

    def add_pointer_property(self, owner: Any, name: str, rna_type: type, **keywords: Any) -> Any:
        _assert_registered_rna_type(rna_type, label=f"PointerProperty target for {name}")
        existing = _exact_attribute(owner, name)
        existing_action = ""
        if existing is not None:
            existing_action = _retire_stale_owned_pointer(owner, name, rna_type)
            if not existing_action:
                raise RegistrationError(f"RNA property already exists: {owner!r}.{name}")
        if existing_action == "CURRENT":
            self._before_acquire("pointer_property")
            property_name = str(name)
            current_record = _existing_owned_pointer_record(owner, property_name, rna_type)
            if (
                current_record is None
                or not bool(current_record.get("current"))
                or current_record.get("descriptor") is not existing
                or current_record.get("target_type") is not rna_type
                or int(current_record.get("property_pointer", 0) or 0) <= 0
                or int(current_record.get("expected_pointer", 0) or 0) <= 0
            ):
                raise RegistrationError(
                    f"current Smart Paint pointer could not be adopted: {owner!r}.{name}"
                )
            captured_descriptor = existing
            captured_property_pointer = int(current_record["property_pointer"])
            captured_target_pointer = int(current_record["expected_pointer"])

            def _remove_adopted(
                owner=owner,
                property_name=property_name,
                rna_type=rna_type,
                captured_descriptor=captured_descriptor,
                captured_property_pointer=captured_property_pointer,
                captured_target_pointer=captured_target_pointer,
            ):
                current_record = _existing_owned_pointer_record(owner, property_name, rna_type)
                if (
                    current_record is None
                    or not bool(current_record.get("current"))
                    or current_record.get("descriptor") is not captured_descriptor
                    or current_record.get("target_type") is not rna_type
                    or int(current_record.get("property_pointer", 0) or 0) != captured_property_pointer
                    or int(current_record.get("expected_pointer", 0) or 0) != captured_target_pointer
                ):
                    return
                delattr(owner, property_name)

            try:
                self._append({
                    "kind": "pointer_property",
                    "handle": existing,
                    "owner": owner,
                    "name": property_name,
                    "owner_identity": id(owner),
                    "identity": id(existing),
                    "native_property_pointer": captured_property_pointer,
                    "native_target_type_pointer": captured_target_pointer,
                    "adopted_existing_exact": True,
                    "retired_stale_existing": False,
                    "native_remover": _remove_adopted,
                })
            except BaseException:
                _remove_adopted()
                raise
            return existing
        property_factory = getattr(bpy.props, "PointerProperty")
        acquired = self.add_rna_property_factory(
            owner,
            name,
            lambda: property_factory(type=rna_type, **keywords),
            kind="pointer_property",
        )
        if self.journal and self.journal[-1].get("handle") is acquired:
            self.journal[-1]["adopted_existing_exact"] = False
            self.journal[-1]["retired_stale_existing"] = existing_action == "RETIRED"
        return acquired

    def add_namespace_entry(
        self,
        namespace: dict[str, Any],
        name: str,
        value: Any,
        *,
        adopt_existing_exact: bool = False,
    ) -> Any:
        """Acquire one exact namespace entry and journal its native remover.

        ``adopt_existing_exact`` is restricted to upgrade migration of this
        Suite's own namespaced scalar markers.  The existing value must have
        the same concrete type and value as the requested marker; unexpected
        or foreign values fail registration instead of being overwritten.
        """
        self._before_acquire("namespace_entry")
        key = str(name)
        adopted = False
        if key in namespace:
            acquired = namespace.get(key)
            if (
                not adopt_existing_exact
                or type(acquired) is not type(value)
                or acquired != value
            ):
                raise RegistrationError(f"Namespace entry already exists: {key}")
            adopted = True
        else:
            namespace[key] = value
            acquired = namespace.get(key)

        def _remove(namespace=namespace, key=key, acquired=acquired):
            if namespace.get(key) is acquired:
                namespace.pop(key, None)

        self._append({
            "kind": "namespace_entry", "handle": acquired, "name": key,
            "identity": id(acquired), "native_remover": _remove,
            "adopted_existing_exact": adopted,
        })
        return acquired

    def add_handler(self, handler_list: Any, callback: Callable[..., Any], *, label: str = "") -> None:
        self._before_acquire("handler")
        if callback in handler_list:
            raise RegistrationError(f"Handler already registered: {_callable_identity(callback)}")
        handler_list.append(callback)

        def _remove(handler_list=handler_list, callback=callback):
            # Remove this exact callback object at most once; never match by name/module.
            for index, item in enumerate(tuple(handler_list)):
                if item is callback:
                    del handler_list[index]
                    break

        self._append({
            "kind": "handler", "handle": callback, "name": str(label),
            "identity": _callable_identity(callback), "native_remover": _remove,
        })

    def add_msgbus(self, *, key: Any, owner: Any, args: tuple[Any, ...], notify: Callable[..., Any], options: set[str] | None = None) -> None:
        self._before_acquire("msgbus")
        bpy.msgbus.subscribe_rna(key=key, owner=owner, args=args, notify=notify, options=options or set())

        def _remove(owner=owner):
            bpy.msgbus.clear_by_owner(owner)

        self._append({
            "kind": "msgbus", "handle": owner, "name": str(getattr(notify, "__name__", "")),
            "identity": id(owner), "native_remover": _remove,
        })

    def add_translation(self, key: str, catalog: dict[str, Any]) -> None:
        self._before_acquire("translation")
        key = str(key)
        # Cross-version live reinstall tolerance: when an already-shipped old
        # generation's teardown left this addon key in Blender's translations
        # message cache, ``register`` raises ValueError ("translations message
        # cache already contains some data").  ``unregister`` of a missing key
        # is a no-op on this build (verified on 5.1.2 ec6e62d40fa9), so
        # clearing the stale entry first is always safe and keeps exactly one
        # live catalog: the current generation's.
        try:
            bpy.app.translations.unregister(key)
        except Exception:
            pass
        bpy.app.translations.register(key, catalog)

        def _remove(key=str(key)):
            bpy.app.translations.unregister(key)

        self._append({
            "kind": "translation", "handle": catalog, "name": str(key),
            "identity": id(catalog), "native_remover": _remove,
        })

    def add_cleanup(self, cleanup: Callable[[], Any], *, label: str) -> None:
        self._before_acquire("callback")
        self._append({
            "kind": "callback", "handle": cleanup, "name": str(label),
            "identity": id(cleanup), "native_remover": cleanup,
        })

    def component(self, name: str, state: str, error: str = "") -> None:
        self.record.setdefault("component_states", {})[str(name)] = {
            "state": str(state), "error": str(error)[:1000], "time": time.time(),
        }

    def commit(self) -> None:
        record = self.record
        record["state"] = "READY"
        record["ready_at"] = time.time()
        self.state = "READY"

    def rollback(self, error: BaseException | str) -> list[str]:
        if self.state not in {"REGISTERING", "READY"}:
            return []
        record = self.record
        record["state"] = "ROLLING_BACK"
        record["error"] = str(error)[:2000]
        errors = _stop_runtime_resources(record)
        ledger = _ledger(create=True)
        failure = {
            "generation": self.generation,
            "revision": self.revision,
            "error": str(error)[:2000],
            "cleanup_errors": list(errors),
            "time": time.time(),
        }
        if errors:
            record["state"] = "ROLLBACK_CLEANUP_FAILED"
        elif isinstance(ledger.get("active"), dict) and ledger["active"].get("generation") == self.generation:
            ledger["active"] = None
        ledger["last_failure"] = failure
        self.state = "FAILED"
        return errors


def begin_registration(revision: str = REVISION) -> RegistrationTransaction:
    return RegistrationTransaction(revision=str(revision)).begin()


def shared_cancel_event() -> threading.Event:
    active = _active_record(require_state={"REGISTERING", "READY"})
    event = active.get("cancel_event") if isinstance(active, dict) else None
    if isinstance(event, threading.Event):
        return event
    stopped = threading.Event()
    stopped.set()
    return stopped


def component_state(name: str, state: str, error: str = "") -> None:
    active = _active_record(require_state={"REGISTERING", "READY"})
    if active is not None:
        active.setdefault("component_states", {})[str(name)] = {
            "state": str(state), "error": str(error)[:1000], "time": time.time(),
        }


def add_namespace_entry(namespace: dict[str, Any], name: str, value: Any) -> Any:
    key = str(name)
    if key in namespace:
        raise RegistrationError(f"Namespace entry already exists: {key}")
    namespace[key] = value
    acquired = namespace.get(key)

    def _remove(namespace=namespace, key=key, acquired=acquired):
        if namespace.get(key) is acquired:
            namespace.pop(key, None)

    try:
        _record_row({
            "kind": "namespace_entry", "handle": acquired, "name": key,
            "identity": id(acquired), "native_remover": _remove,
        }, require_ready=True)
    except BaseException:
        _remove()
        raise
    return acquired


def remove_namespace_entry(namespace: dict[str, Any], name: str, value: Any = None) -> bool:
    key = str(name)
    rows = _remove_rows(
        lambda row: row.get("kind") == "namespace_entry"
        and row.get("name") == key
        and (value is None or row.get("handle") is value)
    )
    removed = False
    for row in rows:
        row["released"] = False
        errors: list[str] = []
        removed = _run_native_remover(row, errors) or removed
        if errors:
            raise RegistrationError("; ".join(errors))
    return removed


def add_handler(handler_list: Any, callback: Callable[..., Any], *, label: str = "") -> None:
    if callback in handler_list:
        active = _active_record(require_state={"READY"})
        owned = any(
            not bool(row.get("released"))
            and row.get("kind") == "handler"
            and row.get("handle") is callback
            for row in (active.get("journal", ()) if active else ())
        )
        if owned:
            return
        raise RegistrationError(f"Handler already exists without current-generation ownership: {_callable_identity(callback)}")
    handler_list.append(callback)

    def _remove(handler_list=handler_list, callback=callback):
        for index, item in enumerate(tuple(handler_list)):
            if item is callback:
                del handler_list[index]
                break

    try:
        _record_row({
            "kind": "handler", "handle": callback, "name": str(label),
            "identity": _callable_identity(callback), "native_remover": _remove,
        }, require_ready=True)
    except BaseException:
        # Never leave an untracked callback in Blender's handler list when
        # the journal refuses the row (measured 1.9.289 defect: dormant
        # registry leaked persistent boundary handlers one call at a time).
        _remove()
        raise


def remove_handler(handler_list: Any, callback: Callable[..., Any]) -> bool:
    rows = _remove_rows(lambda row: row.get("kind") == "handler" and row.get("handle") is callback)
    removed = False
    for row in rows:
        row["released"] = False
        errors: list[str] = []
        removed = _run_native_remover(row, errors) or removed
        if errors:
            raise RegistrationError("; ".join(errors))
    return removed


def _timer_row(callback: Callable[..., Any]) -> dict[str, Any] | None:
    active = _active_record(require_state={"REGISTERING", "READY"})
    if active is None:
        return None
    for row in active.get("journal", ()):
        if (
            not bool(row.get("released"))
            and row.get("kind") == "timer"
            and row.get("handle") is callback
            and row.get("owner_uuid") == SUITE_OWNER_UUID
            and row.get("generation") == active.get("generation")
        ):
            return row
    return None


def timer_registered(callback: Callable[..., Any]) -> bool:
    """Return whether this exact callback owns a live native timer.

    Callers never inspect Blender's global timer registry with a name/module
    match.  The journal maps the public callback identity to the private native
    dispatch function acquired for the current generation.
    """
    row = _timer_row(callback)
    native = row.get("registered_handle") if row is not None else None
    return bool(native is not None and _timer_registered(native))


def register_timer(callback: Callable[..., Any], *, first_interval: float = 0.0, persistent: bool = False, label: str = "") -> None:
    existing = _timer_row(callback)
    if existing is not None:
        native = existing.get("registered_handle")
        if native is not None and _timer_registered(native):
            return
        existing["released"] = True

    active = _active_record(require_state={"READY"})
    if active is None:
        raise RegistrationError("Timer registration requires a READY Smart Paint generation")
    generation = str(active.get("generation", ""))

    def _dispatch(callback=callback, generation=generation):
        current = _active_record(require_state={"READY"})
        if current is None or str(current.get("generation", "")) != generation:
            _remove_rows(
                lambda row: row.get("kind") == "timer"
                and row.get("handle") is callback
                and row.get("generation") == generation
            )
            return None
        try:
            result = callback()
        except (RuntimeError, ReferenceError, AttributeError, ValueError, TypeError, OSError) as exc:
            component_state(str(label or getattr(callback, "__name__", "timer")), "FAILED", f"{type(exc).__name__}:{exc}")
            result = None
        except Exception as exc:
            # A timer callback is a process-global boundary.  Contain the fault
            # once, publish it through structured runtime state, and terminate
            # the timer without a repeating console traceback.
            component_state(str(label or getattr(callback, "__name__", "timer")), "FAILED", f"{type(exc).__name__}:{exc}")
            result = None
        if result is None:
            _remove_rows(
                lambda row: row.get("kind") == "timer"
                and row.get("handle") is callback
                and row.get("generation") == generation
            )
        return result

    bpy.app.timers.register(
        _dispatch,
        first_interval=max(0.0, float(first_interval)),
        persistent=bool(persistent),
    )

    def _remove(native=_dispatch):
        if _timer_registered(native):
            bpy.app.timers.unregister(native)

    try:
        _record_row({
            "kind": "timer", "handle": callback, "registered_handle": _dispatch,
            "name": str(label), "identity": _callable_identity(callback),
            "registered_identity": _callable_identity(_dispatch),
            "native_remover": _remove,
        }, require_ready=True)
    except BaseException:
        _remove()
        raise


def unregister_timer(callback: Callable[..., Any]) -> bool:
    rows = _remove_rows(lambda row: row.get("kind") == "timer" and row.get("handle") is callback)
    removed = False
    for row in rows:
        row["released"] = False
        errors: list[str] = []
        removed = _run_native_remover(row, errors) or removed
        if errors:
            raise RegistrationError("; ".join(errors))
    return removed


def timer_finished(callback: Callable[..., Any]) -> None:
    _remove_rows(lambda row: row.get("kind") == "timer" and row.get("handle") is callback)


def track_event_timer(window_manager: Any, handle: Any, *, label: str = "") -> None:
    def _remove(window_manager=window_manager, handle=handle):
        window_manager.event_timer_remove(handle)

    _record_row({
        "kind": "event_timer", "handle": handle, "name": str(label),
        "identity": id(handle), "native_remover": _remove,
    }, require_ready=True)


def untrack_event_timer(window_manager: Any, handle: Any, *, remove: bool = True) -> None:
    del window_manager
    rows = _remove_rows(lambda row: row.get("kind") == "event_timer" and row.get("handle") is handle)
    if remove:
        for row in rows:
            row["released"] = False
            errors: list[str] = []
            _run_native_remover(row, errors)
            if errors:
                raise RegistrationError("; ".join(errors))


def track_draw_handler(remove: Callable[..., Any], handle: Any, region_type: str, *, label: str = "") -> None:
    def _remove(remove=remove, handle=handle, region_type=str(region_type)):
        remove(handle, region_type)

    _record_row({
        "kind": "draw_handler", "handle": handle, "name": str(label),
        "identity": id(handle), "native_remover": _remove,
    }, require_ready=True)


def untrack_draw_handler(handle: Any, *, remove: bool = False) -> None:
    rows = _remove_rows(lambda row: row.get("kind") == "draw_handler" and row.get("handle") is handle)
    if remove:
        for row in rows:
            row["released"] = False
            errors: list[str] = []
            _run_native_remover(row, errors)
            if errors:
                raise RegistrationError("; ".join(errors))


def track_thread(thread: threading.Thread, *, label: str = "", stop: Callable[[], Any] | None = None) -> None:
    _record_row({
        "kind": "thread", "handle": thread, "name": str(label or thread.name),
        "identity": id(thread), "stop": stop, "native_remover": None,
    }, require_ready=True)


def untrack_thread(thread: threading.Thread) -> None:
    _remove_rows(lambda row: row.get("kind") == "thread" and row.get("handle") is thread)


def track_process(process: Any, *, label: str = "", stop: Callable[[], Any] | None = None) -> None:
    _record_row({
        "kind": "process", "handle": process, "name": str(label),
        "identity": id(process), "stop": stop, "native_remover": None,
    }, require_ready=True)


def untrack_process(process: Any) -> None:
    _remove_rows(lambda row: row.get("kind") == "process" and row.get("handle") is process)


def track_io(handle: Any, *, label: str = "", close: Callable[[], Any] | None = None) -> None:
    closer = close if callable(close) else getattr(handle, "close", None)
    _record_row({
        "kind": "io", "handle": handle, "name": str(label),
        "identity": id(handle), "native_remover": closer,
    }, require_ready=True)


def untrack_io(handle: Any, *, close: bool = False) -> None:
    rows = _remove_rows(lambda row: row.get("kind") == "io" and row.get("handle") is handle)
    if close:
        for row in rows:
            row["released"] = False
            errors: list[str] = []
            _run_native_remover(row, errors)
            if errors:
                raise RegistrationError("; ".join(errors))


def unregister(*, timeout: float = 8.0) -> dict[str, Any]:
    ledger = _ledger(create=False)
    active = ledger.get("active") if isinstance(ledger, dict) else None
    if not isinstance(active, dict):
        # DORMANT-SAFE UNREGISTER (USER EVIDENCE 2, 2026-08-20): with no
        # journal to drive teardown, 1.9.289 skipped everything here and the
        # next enable failed on the still-registered class set.  Fall back to
        # the module-prefix-owned sweep so disable always leaves Blender
        # clean of this package's classes, handlers and contracted RNA.
        sweep = _sweep_dormant_leftovers()
        return {"ok": True, "state": "OFF", "cleanup_errors": [], "dormant_sweep": sweep}
    generation = str(active.get("generation", ""))
    if str(active.get("state", "")) == "UNREGISTERED":
        sweep = _sweep_dormant_leftovers()
        return {
            "ok": True, "state": "OFF", "generation": generation,
            "cleanup_errors": [], "dormant_sweep": sweep,
        }
    active["state"] = "UNREGISTERING"
    errors = _stop_runtime_resources(active, timeout=timeout)
    if errors:
        active["state"] = "UNREGISTER_CLEANUP_FAILED"
        ledger["last_failure"] = {
            "generation": generation,
            "revision": str(active.get("revision", REVISION)),
            "error": "resource cleanup failed",
            "cleanup_errors": list(errors),
            "time": time.time(),
        }
        return {
            "ok": False,
            "state": "UNREGISTER_CLEANUP_FAILED",
            "generation": generation,
            "cleanup_errors": list(errors),
        }
    active["state"] = "UNREGISTERED"
    if isinstance(ledger.get("active"), dict) and ledger["active"].get("generation") == generation:
        ledger["active"] = None
    return {"ok": True, "state": "OFF", "generation": generation, "cleanup_errors": []}


def resource_counts() -> dict[str, int]:
    kinds = (
        "class", "pointer_property", "rna_property", "handler", "timer",
        "event_timer", "draw_handler", "thread", "process", "io", "msgbus",
        "translation", "callback", "namespace_entry",
    )
    counts = {kind: 0 for kind in kinds}
    active = _active_record()
    if active is not None:
        for row in active.get("journal", ()):
            if not bool(row.get("released")):
                kind = str(row.get("kind", ""))
                counts[kind] = counts.get(kind, 0) + 1
    return counts


__all__ = (
    "LEDGER_KEY", "REVISION", "SUITE_ID", "SUITE_LABEL", "SUITE_OWNER_UUID",
    "LiveReloadBlocked", "RegistrationError", "RegistrationTransaction",
    "add_handler", "add_namespace_entry", "begin_registration", "component_state",
    "ensure_runtime_ready",
    "register_timer", "remove_handler", "remove_namespace_entry", "resource_counts",
    "shared_cancel_event", "snapshot", "timer_finished", "timer_registered", "track_draw_handler",
    "track_event_timer", "track_io", "track_process", "track_thread", "unregister",
    "unregister_timer", "untrack_draw_handler", "untrack_event_timer", "untrack_io",
    "untrack_process", "untrack_thread",
)
