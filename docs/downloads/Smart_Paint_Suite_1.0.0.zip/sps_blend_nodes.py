# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Photoshop-style blend mode groundwork for the future GPU layer stack.

This module is intentionally standalone for A-Step1.  It does not register UI,
replace the current compositor, or modify save paths.  The first milestone is a
stable CPU oracle and deterministic golden vectors; GPU node groups can then be
validated against the same data without touching the working C-line pipeline.
"""

from __future__ import annotations

import math

from dataclasses import dataclass
from typing import Iterable


SEPARABLE_BLEND_MODES: tuple[str, ...] = (
    "MIX",
    "ADD",
    "LINEAR_DODGE",
    "MULTIPLY",
    "SCREEN",
    "OVERLAY",
    "SOFT_LIGHT",
    "HARD_LIGHT",
    "COLOR_DODGE",
    "COLOR_BURN",
    "LINEAR_BURN",
    "VIVID_LIGHT",
    "LINEAR_LIGHT",
    "PIN_LIGHT",
    "SUBTRACT",
    "INVERSE_SUBTRACT",
    "DIVIDE",
    "INVERSE_DIVIDE",
    "SIGNED_ADD",
    "DIFFERENCE",
    "EXCLUSION",
    "DARKEN",
    "LIGHTEN",
    "REPLACE",
)

NON_SEPARABLE_BLEND_MODES: tuple[str, ...] = (
    "TINT",
    "HUE",
    "SATURATION",
    "COLOR",
    "VALUE",
    "LUMINOSITY",
)

NORMAL_MAP_BLEND_MODES: tuple[str, ...] = (
    "NORMAL_MAP_COMBINE",
    "NORMAL_MAP_DETAIL",
    "NORMAL_MAP_INVERSE_DETAIL",
)

PHOTOSHOP_BLEND_MODES_27: tuple[str, ...] = (
    "MIX",
    "PASS_THROUGH",
    "ADD",
    "LINEAR_DODGE",
    "MULTIPLY",
    "SCREEN",
    "OVERLAY",
    "SOFT_LIGHT",
    "HARD_LIGHT",
    "COLOR_DODGE",
    "COLOR_BURN",
    "LINEAR_BURN",
    "VIVID_LIGHT",
    "LINEAR_LIGHT",
    "PIN_LIGHT",
    "SUBTRACT",
    "DIVIDE",
    "DIFFERENCE",
    "EXCLUSION",
    "DARKEN",
    "LIGHTEN",
    "TINT",
    "HUE",
    "SATURATION",
    "COLOR",
    "VALUE",
    "REPLACE",
)

SPS_EXTRA_BLEND_MODES: tuple[str, ...] = (
    "DISABLE",
    "INVERSE_SUBTRACT",
    "INVERSE_DIVIDE",
    "SIGNED_ADD",
    "LUMINOSITY",
) + NORMAL_MAP_BLEND_MODES

PSD_BLEND_MODES: tuple[str, ...] = tuple(
    dict.fromkeys(PHOTOSHOP_BLEND_MODES_27 + SPS_EXTRA_BLEND_MODES)
)

MODE_ALIASES: dict[str, str] = {
    "NORMAL": "MIX",
    "SRC_OVER": "MIX",
    "SOURCE_OVER": "MIX",
    "PASS": "MIX",
    "PASSTHROUGH": "MIX",
    "PASS_THROUGH": "MIX",
    "DISABLE": "DISABLE",
    "OFF": "DISABLE",
    "NONE": "DISABLE",
    "LUMINOSITY": "VALUE",
}


@dataclass(frozen=True)
class BlendGoldenCase:
    mode: str
    opacity: float
    dst: tuple[float, float, float]
    src: tuple[float, float, float]
    alpha: float


@dataclass(frozen=True)
class GPUReadbackResult:
    ok: bool
    reason: str
    width: int
    height: int
    color: tuple[float, float, float, float] | None = None
    max_abs_error: float | None = None


@dataclass(frozen=True)
class GPUFormulaResult:
    ok: bool
    reason: str
    cases: int
    max_abs_error: float | None = None
    first_failure: dict[str, object] | None = None


@dataclass(frozen=True)
class AStep1SmokeResult:
    oracle_ok: bool
    oracle_message: str
    node_groups_created: int
    gpu_readback: GPUReadbackResult
    gpu_formula: GPUFormulaResult
    gpu_limits: dict[str, object]


def normalize_mode(mode: str) -> str:
    key = str(mode or "MIX").upper()
    return MODE_ALIASES.get(key, key)


def blend_rgb_oracle(dst, src, alpha, mode: str):
    """Return the CPU oracle matching psd_io._blend_rgb.

    The math is copied one-for-one from the v11 compositor oracle, including the
    HSV approximation for non-separable Photoshop modes.  Inputs are expected in
    sRGB-encoded 0..1 space.
    """
    import numpy as np

    mode = normalize_mode(mode)
    dst = np.clip(np.asarray(dst, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
    src = np.clip(np.asarray(src, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
    a = np.clip(np.asarray(alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)[:, None]
    eps = 1.0e-6

    if mode == "DISABLE":
        return np.clip(dst, 0.0, 1.0)

    def color_dodge(d, s):
        return np.where(s >= 1.0 - eps, 1.0, np.minimum(1.0, d / np.maximum(1.0 - s, eps)))

    def color_burn(d, s):
        return np.where(s <= eps, 0.0, 1.0 - np.minimum(1.0, (1.0 - d) / np.maximum(s, eps)))

    def rgb_to_hsv(rgb):
        rgb = np.clip(np.asarray(rgb, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
        r, g, b = rgb[:, 0], rgb[:, 1], rgb[:, 2]
        mx = np.maximum(np.maximum(r, g), b)
        mn = np.minimum(np.minimum(r, g), b)
        delta = mx - mn
        h = np.zeros_like(mx)
        mask = delta > eps
        rmask = mask & (mx == r)
        gmask = mask & (mx == g)
        bmask = mask & (mx == b)
        h[rmask] = ((g[rmask] - b[rmask]) / delta[rmask]) % 6.0
        h[gmask] = ((b[gmask] - r[gmask]) / delta[gmask]) + 2.0
        h[bmask] = ((r[bmask] - g[bmask]) / delta[bmask]) + 4.0
        h = (h / 6.0) % 1.0
        s = np.where(mx <= eps, 0.0, delta / np.maximum(mx, eps))
        return np.stack([h, s, mx], axis=1).astype(np.float32)

    def hsv_to_rgb(hsv):
        hsv = np.asarray(hsv, dtype=np.float32).reshape((-1, 3))
        h = (hsv[:, 0] % 1.0) * 6.0
        s = np.clip(hsv[:, 1], 0.0, 1.0)
        v = np.clip(hsv[:, 2], 0.0, 1.0)
        i = np.floor(h).astype(np.int32)
        f = h - i
        p = v * (1.0 - s)
        q = v * (1.0 - s * f)
        t = v * (1.0 - s * (1.0 - f))
        out = np.zeros((hsv.shape[0], 3), dtype=np.float32)
        vals = ((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))
        for idx, triple in enumerate(vals):
            mask = (i % 6) == idx
            if bool(np.any(mask)):
                out[mask, 0] = triple[0][mask]
                out[mask, 1] = triple[1][mask]
                out[mask, 2] = triple[2][mask]
        return np.clip(out, 0.0, 1.0)

    def normal_whiteout(d, s, inverse=False):
        dn = np.clip(d * 2.0 - 1.0, -1.0, 1.0)
        sn = np.clip(s * 2.0 - 1.0, -1.0, 1.0)
        if inverse:
            sn[:, :2] *= -1.0
        out = np.empty_like(dn)
        out[:, 0] = dn[:, 0] + sn[:, 0]
        out[:, 1] = dn[:, 1] + sn[:, 1]
        out[:, 2] = dn[:, 2] * sn[:, 2]
        length = np.sqrt(np.maximum(np.sum(out * out, axis=1), eps))[:, None]
        return np.clip((out / length) * 0.5 + 0.5, 0.0, 1.0)

    if mode in {"ADD", "LINEAR_DODGE"}:
        mixed = np.clip(dst + src, 0.0, 1.0)
    elif mode == "MULTIPLY":
        mixed = dst * src
    elif mode == "SCREEN":
        mixed = 1.0 - (1.0 - dst) * (1.0 - src)
    elif mode == "OVERLAY":
        mixed = np.where(dst <= 0.5, 2.0 * dst * src, 1.0 - 2.0 * (1.0 - dst) * (1.0 - src))
    elif mode == "SOFT_LIGHT":
        d = np.where(dst <= 0.25, ((16.0 * dst - 12.0) * dst + 4.0) * dst, np.sqrt(np.maximum(dst, 0.0)))
        mixed = np.where(src <= 0.5, dst - (1.0 - 2.0 * src) * dst * (1.0 - dst), dst + (2.0 * src - 1.0) * (d - dst))
    elif mode == "HARD_LIGHT":
        mixed = np.where(src <= 0.5, 2.0 * dst * src, 1.0 - 2.0 * (1.0 - dst) * (1.0 - src))
    elif mode == "COLOR_DODGE":
        mixed = color_dodge(dst, src)
    elif mode == "COLOR_BURN":
        mixed = color_burn(dst, src)
    elif mode == "LINEAR_BURN":
        mixed = np.clip(dst + src - 1.0, 0.0, 1.0)
    elif mode == "VIVID_LIGHT":
        mixed = np.where(src <= 0.5, color_burn(dst, 2.0 * src), color_dodge(dst, 2.0 * (src - 0.5)))
    elif mode == "LINEAR_LIGHT":
        mixed = np.clip(dst + 2.0 * src - 1.0, 0.0, 1.0)
    elif mode == "PIN_LIGHT":
        mixed = np.where(src <= 0.5, np.minimum(dst, 2.0 * src), np.maximum(dst, 2.0 * (src - 0.5)))
    elif mode == "SUBTRACT":
        mixed = np.clip(dst - src, 0.0, 1.0)
    elif mode == "INVERSE_SUBTRACT":
        mixed = np.clip(src - dst, 0.0, 1.0)
    elif mode == "DIVIDE":
        mixed = np.clip(dst / np.maximum(src, eps), 0.0, 1.0)
    elif mode == "INVERSE_DIVIDE":
        mixed = np.clip(src / np.maximum(dst, eps), 0.0, 1.0)
    elif mode == "SIGNED_ADD":
        mixed = np.clip(dst + (src - 0.5) * 2.0, 0.0, 1.0)
    elif mode == "DIFFERENCE":
        mixed = np.abs(dst - src)
    elif mode == "EXCLUSION":
        mixed = dst + src - 2.0 * dst * src
    elif mode == "DARKEN":
        mixed = np.minimum(dst, src)
    elif mode == "LIGHTEN":
        mixed = np.maximum(dst, src)
    elif mode in {"TINT", "HUE", "SATURATION", "COLOR", "VALUE", "LUMINOSITY"}:
        dh = rgb_to_hsv(dst)
        sh = rgb_to_hsv(src)
        hsv = dh.copy()
        if mode in {"TINT", "HUE"}:
            hsv[:, 0] = sh[:, 0]
        elif mode == "SATURATION":
            hsv[:, 1] = sh[:, 1]
        elif mode == "COLOR":
            hsv[:, 0] = sh[:, 0]
            hsv[:, 1] = sh[:, 1]
        else:
            hsv[:, 2] = sh[:, 2]
        mixed = hsv_to_rgb(hsv)
    elif mode in {"NORMAL_MAP_COMBINE", "NORMAL_MAP_DETAIL"}:
        mixed = normal_whiteout(dst, src, inverse=False)
    elif mode == "NORMAL_MAP_INVERSE_DETAIL":
        mixed = normal_whiteout(dst, src, inverse=True)
    else:
        mixed = src
    if mode == "REPLACE":
        return np.clip(src * a + dst * (1.0 - a), 0.0, 1.0)
    return np.clip(dst * (1.0 - a) + mixed * a, 0.0, 1.0)


def golden_cases(modes: Iterable[str] = PSD_BLEND_MODES) -> list[BlendGoldenCase]:
    """Build deterministic boundary-heavy vectors for CPU/GPU comparison."""
    values = (0.0, 1.0 / 255.0, 0.125, 0.5, 0.875, 254.0 / 255.0, 1.0)
    alphas = (0.0, 1.0 / 255.0, 0.25, 0.5, 0.75, 1.0)
    cases: list[BlendGoldenCase] = []
    for mode in modes:
        for alpha in alphas:
            for i, d0 in enumerate(values):
                s0 = values[(i * 3 + 1) % len(values)]
                cases.append(
                    BlendGoldenCase(
                        mode=str(mode),
                        opacity=float(alpha),
                        dst=(float(d0), float(values[(i + 2) % len(values)]), float(values[(i + 4) % len(values)])),
                        src=(float(s0), float(values[(i + 3) % len(values)]), float(values[(i + 5) % len(values)])),
                        alpha=float(alpha),
                    )
                )
    return cases


def verify_against_psd_io() -> tuple[bool, str]:
    """Smoke-test this oracle against the current psd_io._blend_rgb."""
    import numpy as np

    from . import psd_io

    cases = golden_cases()
    for case in cases:
        dst = np.asarray([case.dst], dtype=np.float32)
        src = np.asarray([case.src], dtype=np.float32)
        alpha = np.asarray([case.alpha], dtype=np.float32)
        expected = psd_io._blend_rgb(dst, src, alpha, case.mode)
        actual = blend_rgb_oracle(dst, src, alpha, case.mode)
        if not np.allclose(expected, actual, atol=1.0e-7, rtol=0.0):
            return False, f"mismatch mode={case.mode} alpha={case.alpha}"
    return True, f"ok cases={len(cases)}"


def composite_one_layer_oracle(
    dst_rgb,
    dst_alpha,
    src_rgb,
    src_alpha,
    opacity,
    clip_alpha,
    mode: str,
):
    """Composite a single source layer over a destination buffer.

    This mirrors clean_layer_stack_engine._blend_into for the node-group
    contract.  Color math stays in sRGB-encoded space; alpha is straight alpha.
    """
    import numpy as np

    mode_key = normalize_mode(mode)
    dst_rgb = np.clip(np.asarray(dst_rgb, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
    src_rgb = np.clip(np.asarray(src_rgb, dtype=np.float32).reshape((-1, 3)), 0.0, 1.0)
    dst_a = np.clip(np.asarray(dst_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
    src_raw_a = np.clip(np.asarray(src_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
    op = np.clip(np.asarray(opacity, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
    clip = np.clip(np.asarray(clip_alpha, dtype=np.float32).reshape((-1,)), 0.0, 1.0)
    eps = 1.0e-8

    if mode_key == "DISABLE":
        return np.concatenate((dst_rgb, dst_a[:, None]), axis=1).astype(np.float32, copy=False)

    if mode_key == "REPLACE":
        cov = np.clip(op * clip, 0.0, 1.0)
        new_a = np.clip(dst_a * (1.0 - cov) + src_raw_a * cov, 0.0, 1.0)
        dst_pm = dst_rgb * dst_a[:, None] * (1.0 - cov[:, None])
        src_pm = src_rgb * src_raw_a[:, None] * cov[:, None]
        out_rgb = np.where(new_a[:, None] > eps, (dst_pm + src_pm) / np.maximum(new_a[:, None], eps), src_rgb)
        return np.clip(np.concatenate((out_rgb, new_a[:, None]), axis=1), 0.0, 1.0).astype(np.float32, copy=False)

    src_a = np.clip(src_raw_a * op * clip, 0.0, 1.0)
    if mode_key == "MIX":
        blend_rgb = src_rgb
    else:
        blend_rgb = blend_rgb_oracle(dst_rgb, src_rgb, np.ones_like(src_a, dtype=np.float32), mode_key)
    new_a = np.clip(src_a + dst_a * (1.0 - src_a), 0.0, 1.0)
    src_a_2d = src_a[:, None]
    dst_a_2d = dst_a[:, None]
    # Photoshop applies the blend function only where source and backdrop
    # overlap. Outside the backdrop, the authored source color passes through
    # unchanged. This is observable for partially transparent Multiply rows.
    dst_pm = dst_rgb * dst_a_2d * (1.0 - src_a_2d)
    src_outside_pm = src_rgb * src_a_2d * (1.0 - dst_a_2d)
    overlap_pm = blend_rgb * src_a_2d * dst_a_2d
    out_rgb = np.where(
        new_a[:, None] > eps,
        (dst_pm + src_outside_pm + overlap_pm) / np.maximum(new_a[:, None], eps),
        blend_rgb,
    )
    return np.clip(np.concatenate((out_rgb, new_a[:, None]), axis=1), 0.0, 1.0).astype(np.float32, copy=False)


def measure_gpu_limits(*, probe_offscreen: bool = False, max_probe_size: int = 4096) -> dict[str, object]:
    """Return GPU sampler/texture limits and conservative VRAM estimates.

    Background Blender sessions often expose capability getters while disallowing
    drawing and GPUOffScreen allocation.  The optional probe is therefore best
    effort and reports the precise failure reason instead of raising.
    """
    result: dict[str, object] = {
        "gpu_module": False,
        "context_available": False,
        "capabilities": {},
        "offscreen_probe": {"enabled": bool(probe_offscreen), "ok": False, "sizes": []},
        "vram_estimates": {},
    }
    try:
        import gpu
    except Exception as exc:
        result["error"] = f"import_gpu_failed:{exc!r}"
        return result

    result["gpu_module"] = True
    caps: dict[str, object] = {}
    for name in (
        "max_texture_size_get",
        "max_texture_layers_get",
        "max_textures_get",
        "max_textures_frag_get",
        "max_textures_vert_get",
        "max_textures_geom_get",
        "max_images_get",
        "max_uniforms_frag_get",
        "max_uniforms_vert_get",
        "max_varying_floats_get",
        "max_vertex_attribs_get",
        "max_batch_vertices_get",
        "max_batch_indices_get",
        "compute_shader_support_get",
        "shader_image_load_store_support_get",
        "hdr_support_get",
    ):
        fn = getattr(gpu.capabilities, name, None)
        if not callable(fn):
            continue
        try:
            caps[name[:-4] if name.endswith("_get") else name] = fn()
        except Exception as exc:
            caps[name] = f"error:{exc!r}"
    result["capabilities"] = caps

    max_texture_size = caps.get("max_texture_size")
    if isinstance(max_texture_size, int) and max_texture_size > 0:
        side = int(max_texture_size)
        result["vram_estimates"] = {
            "max_rgba8_bytes": side * side * 4,
            "max_rgba32f_bytes": side * side * 16,
            "4096_rgba8_bytes": 4096 * 4096 * 4,
            "4096_rgba32f_bytes": 4096 * 4096 * 16,
        }

    if probe_offscreen:
        probe: dict[str, object] = {"enabled": True, "ok": False, "sizes": []}
        size = 64
        while size <= max(64, int(max_probe_size)):
            try:
                offscreen = gpu.types.GPUOffScreen(size, size)
                offscreen.free()
                result["context_available"] = True
                probe["sizes"].append(size)  # type: ignore[index]
                probe["ok"] = True
                size *= 2
            except Exception as exc:
                probe["failure_size"] = size
                probe["failure"] = repr(exc)
                break
        result["offscreen_probe"] = probe
    return result


def _node_group_name(mode: str, *, prefix: str = "SPS_PSBlend_") -> str:
    return f"{prefix}{normalize_mode(mode)}"


def _socket_default(socket, value: float) -> None:
    try:
        socket.default_value = float(value)
    except Exception:
        pass


def _add_group_socket(group, name: str, in_out: str, socket_type: str):
    if hasattr(group, "interface"):
        try:
            sock = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
            if socket_type == "NodeSocketFloat":
                _socket_default(sock, 1.0 if name in {"Opacity", "Clip Alpha"} else 0.0)
            return sock
        except TypeError:
            sock = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
            if socket_type == "NodeSocketFloat":
                _socket_default(sock, 1.0 if name in {"Opacity", "Clip Alpha"} else 0.0)
            return sock
    collection = group.inputs if in_out == "INPUT" else group.outputs
    sock = collection.new(socket_type, name)
    if socket_type == "NodeSocketFloat":
        _socket_default(sock, 1.0 if name in {"Opacity", "Clip Alpha"} else 0.0)
    return sock


class _MathNodeBuilder:
    def __init__(self, group):
        self.group = group
        self.x = -260
        self.y = 240

    def _is_socket(self, value) -> bool:
        return hasattr(value, "is_output") and hasattr(value, "links")

    def _set_input(self, socket, value) -> None:
        if self._is_socket(value):
            self.group.links.new(value, socket)
        else:
            socket.default_value = float(value)

    def math(self, operation: str, a=0.0, b=0.0, c=0.0):
        node = self.group.nodes.new("ShaderNodeMath")
        node.operation = operation
        node.location = (self.x, self.y)
        self.y -= 36
        if self.y < -900:
            self.y = 240
            self.x += 180
        self._set_input(node.inputs[0], a)
        if len(node.inputs) > 1:
            self._set_input(node.inputs[1], b)
        if len(node.inputs) > 2:
            self._set_input(node.inputs[2], c)
        return node.outputs[0]

    def add(self, a, b): return self.math("ADD", a, b)
    def sub(self, a, b): return self.math("SUBTRACT", a, b)
    def mul(self, a, b): return self.math("MULTIPLY", a, b)
    def div(self, a, b): return self.math("DIVIDE", a, b)
    def minimum(self, a, b): return self.math("MINIMUM", a, b)
    def maximum(self, a, b): return self.math("MAXIMUM", a, b)
    def sqrt(self, a): return self.math("SQRT", a)
    def abs(self, a): return self.math("ABSOLUTE", a)
    def floor(self, a): return self.math("FLOOR", a)
    def fract(self, a): return self.math("FRACT", a)
    def modulo(self, a, b): return self.math("MODULO", a, b)
    def greater(self, a, b): return self.math("GREATER_THAN", a, b)
    def less(self, a, b): return self.math("LESS_THAN", a, b)

    def clamp01(self, a):
        return self.minimum(self.maximum(a, 0.0), 1.0)

    def one_minus(self, a):
        return self.sub(1.0, a)

    def mix(self, a, b, t):
        return self.add(a, self.mul(t, self.sub(b, a)))

    def where(self, mask, true_value, false_value):
        return self.mix(false_value, true_value, mask)

    def color_dodge(self, d, s):
        eps = 1.0e-6
        raw = self.minimum(1.0, self.div(d, self.maximum(self.sub(1.0, s), eps)))
        return self.where(self.greater(s, 1.0 - eps), 1.0, raw)

    def color_burn(self, d, s):
        eps = 1.0e-6
        raw = self.sub(1.0, self.minimum(1.0, self.div(self.sub(1.0, d), self.maximum(s, eps))))
        return self.where(self.less(s, eps), 0.0, raw)

    def rgb_to_hsv(self, r, g, b):
        eps = 1.0e-6
        mx = self.maximum(self.maximum(r, g), b)
        mn = self.minimum(self.minimum(r, g), b)
        delta = self.sub(mx, mn)
        safe_delta = self.maximum(delta, eps)
        sat = self.where(self.less(mx, eps), 0.0, self.div(delta, self.maximum(mx, eps)))
        # Math-node MODULO is C fmod (sign of the dividend); (g-b)/delta can be
        # negative when max==r, so normalize into [0, 6) to match numpy's `%`.
        hr = self.modulo(self.add(self.modulo(self.div(self.sub(g, b), safe_delta), 6.0), 6.0), 6.0)
        hg = self.add(self.div(self.sub(b, r), safe_delta), 2.0)
        hb = self.add(self.div(self.sub(r, g), safe_delta), 4.0)
        # Deterministic approximate max-channel selection.  Exact tie behavior is
        # not material for production textures and remains covered by CPU oracle.
        b_is_max = self.mul(self.greater(b, r), self.greater(b, g))
        g_is_max = self.mul(self.greater(g, r), self.one_minus(b_is_max))
        h6 = self.where(b_is_max, hb, self.where(g_is_max, hg, hr))
        hue = self.where(self.less(delta, eps), 0.0, self.div(h6, 6.0))
        return self.clamp01(hue), self.clamp01(sat), self.clamp01(mx)

    def hsv_to_rgb(self, h, s, v):
        c = self.mul(v, s)
        hp = self.mul(self.modulo(h, 1.0), 6.0)
        x = self.mul(c, self.sub(1.0, self.abs(self.sub(self.modulo(hp, 2.0), 1.0))))
        m = self.sub(v, c)
        i = self.floor(hp)

        def mask_for(k: int):
            return self.less(self.abs(self.sub(i, float(k))), 0.5)

        vals = (
            (c, x, 0.0),
            (x, c, 0.0),
            (0.0, c, x),
            (0.0, x, c),
            (x, 0.0, c),
            (c, 0.0, x),
        )
        out = [0.0, 0.0, 0.0]
        for k, triple in enumerate(vals):
            mk = mask_for(k)
            for idx in range(3):
                out[idx] = self.add(out[idx], self.mul(triple[idx], mk))
        return tuple(self.clamp01(self.add(ch, m)) for ch in out)

    def normal_whiteout(self, d_rgb, s_rgb, *, inverse: bool = False):
        dn = [self.sub(self.mul(c, 2.0), 1.0) for c in d_rgb]
        sn = [self.sub(self.mul(c, 2.0), 1.0) for c in s_rgb]
        if inverse:
            sn[0] = self.mul(sn[0], -1.0)
            sn[1] = self.mul(sn[1], -1.0)
        out = [self.add(dn[0], sn[0]), self.add(dn[1], sn[1]), self.mul(dn[2], sn[2])]
        length = self.sqrt(self.maximum(self.add(self.add(self.mul(out[0], out[0]), self.mul(out[1], out[1])), self.mul(out[2], out[2])), 1.0e-6))
        return tuple(self.clamp01(self.add(self.mul(self.div(ch, length), 0.5), 0.5)) for ch in out)


def _separate_color(group, color_socket, *, location):
    node = group.nodes.new("ShaderNodeSeparateColor")
    node.location = location
    group.links.new(color_socket, node.inputs["Color"])
    return node.outputs["Red"], node.outputs["Green"], node.outputs["Blue"]


def _combine_color(group, rgb, *, location):
    node = group.nodes.new("ShaderNodeCombineColor")
    node.location = location
    for name, sock in zip(("Red", "Green", "Blue"), rgb):
        group.links.new(sock, node.inputs[name])
    return node.outputs["Color"]


def _pure_blend_rgb_nodes(builder: _MathNodeBuilder, mode_key: str, dst_rgb, src_rgb):
    d = dst_rgb
    s = src_rgb
    if mode_key in {"MIX", "PASS_THROUGH"}:
        return s
    if mode_key in {"ADD", "LINEAR_DODGE"}:
        return tuple(builder.clamp01(builder.add(d[i], s[i])) for i in range(3))
    if mode_key == "MULTIPLY":
        return tuple(builder.mul(d[i], s[i]) for i in range(3))
    if mode_key == "SCREEN":
        return tuple(builder.sub(1.0, builder.mul(builder.one_minus(d[i]), builder.one_minus(s[i]))) for i in range(3))
    if mode_key == "OVERLAY":
        return tuple(
            builder.where(
                builder.greater(d[i], 0.5),
                builder.sub(1.0, builder.mul(2.0, builder.mul(builder.one_minus(d[i]), builder.one_minus(s[i])))),
                builder.mul(2.0, builder.mul(d[i], s[i])),
            )
            for i in range(3)
        )
    if mode_key == "SOFT_LIGHT":
        out = []
        for i in range(3):
            low_d = builder.add(builder.mul(builder.add(builder.mul(builder.sub(builder.mul(16.0, d[i]), 12.0), d[i]), 4.0), d[i]), 0.0)
            high_d = builder.sqrt(builder.maximum(d[i], 0.0))
            dd = builder.where(builder.greater(d[i], 0.25), high_d, low_d)
            low = builder.sub(d[i], builder.mul(builder.mul(builder.one_minus(builder.mul(2.0, s[i])), d[i]), builder.one_minus(d[i])))
            high = builder.add(d[i], builder.mul(builder.sub(builder.mul(2.0, s[i]), 1.0), builder.sub(dd, d[i])))
            out.append(builder.where(builder.greater(s[i], 0.5), high, low))
        return tuple(out)
    if mode_key == "HARD_LIGHT":
        return tuple(
            builder.where(
                builder.greater(s[i], 0.5),
                builder.sub(1.0, builder.mul(2.0, builder.mul(builder.one_minus(d[i]), builder.one_minus(s[i])))),
                builder.mul(2.0, builder.mul(d[i], s[i])),
            )
            for i in range(3)
        )
    if mode_key == "COLOR_DODGE":
        return tuple(builder.color_dodge(d[i], s[i]) for i in range(3))
    if mode_key == "COLOR_BURN":
        return tuple(builder.color_burn(d[i], s[i]) for i in range(3))
    if mode_key == "LINEAR_BURN":
        return tuple(builder.clamp01(builder.sub(builder.add(d[i], s[i]), 1.0)) for i in range(3))
    if mode_key == "VIVID_LIGHT":
        return tuple(
            builder.where(
                builder.greater(s[i], 0.5),
                builder.color_dodge(d[i], builder.mul(2.0, builder.sub(s[i], 0.5))),
                builder.color_burn(d[i], builder.mul(2.0, s[i])),
            )
            for i in range(3)
        )
    if mode_key == "LINEAR_LIGHT":
        return tuple(builder.clamp01(builder.sub(builder.add(d[i], builder.mul(2.0, s[i])), 1.0)) for i in range(3))
    if mode_key == "PIN_LIGHT":
        return tuple(
            builder.where(
                builder.greater(s[i], 0.5),
                builder.maximum(d[i], builder.mul(2.0, builder.sub(s[i], 0.5))),
                builder.minimum(d[i], builder.mul(2.0, s[i])),
            )
            for i in range(3)
        )
    if mode_key == "SUBTRACT":
        return tuple(builder.clamp01(builder.sub(d[i], s[i])) for i in range(3))
    if mode_key == "INVERSE_SUBTRACT":
        return tuple(builder.clamp01(builder.sub(s[i], d[i])) for i in range(3))
    if mode_key == "DIVIDE":
        return tuple(builder.clamp01(builder.div(d[i], builder.maximum(s[i], 1.0e-6))) for i in range(3))
    if mode_key == "INVERSE_DIVIDE":
        return tuple(builder.clamp01(builder.div(s[i], builder.maximum(d[i], 1.0e-6))) for i in range(3))
    if mode_key == "SIGNED_ADD":
        return tuple(builder.clamp01(builder.add(d[i], builder.mul(builder.sub(s[i], 0.5), 2.0))) for i in range(3))
    if mode_key == "DIFFERENCE":
        return tuple(builder.abs(builder.sub(d[i], s[i])) for i in range(3))
    if mode_key == "EXCLUSION":
        return tuple(builder.sub(builder.add(d[i], s[i]), builder.mul(2.0, builder.mul(d[i], s[i]))) for i in range(3))
    if mode_key == "DARKEN":
        return tuple(builder.minimum(d[i], s[i]) for i in range(3))
    if mode_key == "LIGHTEN":
        return tuple(builder.maximum(d[i], s[i]) for i in range(3))
    if mode_key in {"TINT", "HUE", "SATURATION", "COLOR", "VALUE", "LUMINOSITY"}:
        dh = builder.rgb_to_hsv(d[0], d[1], d[2])
        sh = builder.rgb_to_hsv(s[0], s[1], s[2])
        h, sat, val = dh
        if mode_key in {"TINT", "HUE"}:
            h = sh[0]
        elif mode_key == "SATURATION":
            sat = sh[1]
        elif mode_key == "COLOR":
            h, sat = sh[0], sh[1]
        else:
            val = sh[2]
        return builder.hsv_to_rgb(h, sat, val)
    if mode_key in {"NORMAL_MAP_COMBINE", "NORMAL_MAP_DETAIL"}:
        return builder.normal_whiteout(d, s, inverse=False)
    if mode_key == "NORMAL_MAP_INVERSE_DETAIL":
        return builder.normal_whiteout(d, s, inverse=True)
    return s


def _link_blend_group_formula(group, mode_key: str, group_input, group_output) -> None:
    builder = _MathNodeBuilder(group)
    dst_rgb = _separate_color(group, group_input.outputs["Dst Color"], location=(-620, 180))
    src_rgb = _separate_color(group, group_input.outputs["Src Color"], location=(-620, -40))
    dst_a = group_input.outputs["Dst Alpha"]
    src_a = group_input.outputs["Src Alpha"]
    opacity = group_input.outputs["Opacity"]
    clip_alpha = group_input.outputs["Clip Alpha"]

    pure = _pure_blend_rgb_nodes(builder, mode_key, dst_rgb, src_rgb)
    eff = builder.clamp01(builder.mul(builder.mul(src_a, opacity), clip_alpha))
    cov = builder.clamp01(builder.mul(opacity, clip_alpha))
    inv_eff = builder.one_minus(eff)
    inv_cov = builder.one_minus(cov)

    if mode_key == "DISABLE":
        out_alpha = dst_a
        out_rgb = dst_rgb
        effective = 0.0
    elif mode_key == "REPLACE":
        out_alpha = builder.clamp01(builder.add(builder.mul(dst_a, inv_cov), builder.mul(src_a, cov)))
        denom = builder.maximum(out_alpha, 1.0e-8)
        out_rgb = tuple(
            builder.where(
                builder.greater(out_alpha, 1.0e-8),
                builder.div(builder.add(builder.mul(builder.mul(src_rgb[i], src_a), cov), builder.mul(builder.mul(dst_rgb[i], dst_a), inv_cov)), denom),
                src_rgb[i],
            )
            for i in range(3)
        )
        effective = cov
    else:
        out_alpha = builder.clamp01(builder.add(eff, builder.mul(dst_a, inv_eff)))
        denom = builder.maximum(out_alpha, 1.0e-8)
        out_rgb = tuple(
            builder.where(
                builder.greater(out_alpha, 1.0e-8),
                builder.div(
                    builder.add(
                        builder.add(
                            builder.mul(builder.mul(dst_rgb[i], dst_a), inv_eff),
                            builder.mul(
                                builder.mul(src_rgb[i], eff),
                                builder.one_minus(dst_a),
                            ),
                        ),
                        builder.mul(builder.mul(pure[i], eff), dst_a),
                    ),
                    denom,
                ),
                pure[i],
            )
            for i in range(3)
        )
        effective = eff

    color = _combine_color(group, tuple(builder.clamp01(ch) for ch in out_rgb), location=(580, 140))
    blend_color = _combine_color(group, tuple(builder.clamp01(ch) for ch in pure), location=(580, -80))
    group.links.new(color, group_output.inputs["Color"])
    group.links.new(builder.clamp01(out_alpha), group_output.inputs["Alpha"])
    group.links.new(blend_color, group_output.inputs["Blend Color"])
    if builder._is_socket(effective):
        group.links.new(builder.clamp01(effective), group_output.inputs["Effective Alpha"])
    else:
        group_output.inputs["Effective Alpha"].default_value = float(effective)


def create_blend_node_group(mode: str, *, force: bool = False, prefix: str = "SPS_PSBlend_"):
    """Create an A-Step1 Photoshop-style blend node group.

    The graph uses ShaderNodeMath/SeparateColor/CombineColor only.  Built-in
    MixRGB is intentionally forbidden so the generated network remains a direct
    expression of the psd_io/composite_layer_arrays oracle.
    """
    import bpy

    mode_key = normalize_mode(mode)
    name = _node_group_name(mode_key, prefix=prefix)
    existing = bpy.data.node_groups.get(name)
    if existing is not None:
        if not force:
            if (
                str(existing.get("sps_formula_status", "") or "") == "math_nodes"
                and str(existing.get("sps_formula_version", "") or "") == "a_step1_v3_alpha_overlap"
            ):
                return existing
        bpy.data.node_groups.remove(existing)

    group = bpy.data.node_groups.new(name, "ShaderNodeTree")
    group["sps_blend_mode"] = mode_key
    group["sps_formula_status"] = "math_nodes"
    group["sps_formula_version"] = "a_step1_v3_alpha_overlap"
    group["sps_expected_color_space"] = "srgb_encoded"
    group["sps_builtin_mixrgb_forbidden"] = True
    group["sps_cpu_oracle"] = "sps_blend_nodes.blend_rgb_oracle"

    _add_group_socket(group, "Dst Color", "INPUT", "NodeSocketColor")
    _add_group_socket(group, "Src Color", "INPUT", "NodeSocketColor")
    _add_group_socket(group, "Dst Alpha", "INPUT", "NodeSocketFloat")
    _add_group_socket(group, "Src Alpha", "INPUT", "NodeSocketFloat")
    _add_group_socket(group, "Opacity", "INPUT", "NodeSocketFloat")
    _add_group_socket(group, "Clip Alpha", "INPUT", "NodeSocketFloat")
    _add_group_socket(group, "Color", "OUTPUT", "NodeSocketColor")
    _add_group_socket(group, "Alpha", "OUTPUT", "NodeSocketFloat")
    _add_group_socket(group, "Blend Color", "OUTPUT", "NodeSocketColor")
    _add_group_socket(group, "Effective Alpha", "OUTPUT", "NodeSocketFloat")

    group_input = group.nodes.new("NodeGroupInput")
    group_output = group.nodes.new("NodeGroupOutput")
    group_input.location = (-900, 60)
    group_output.location = (820, 60)
    _link_blend_group_formula(group, mode_key, group_input, group_output)
    return group


def ensure_blend_node_groups(
    modes: Iterable[str] = PHOTOSHOP_BLEND_MODES_27,
    *,
    force: bool = False,
    prefix: str = "SPS_PSBlend_",
) -> list[object]:
    """Create all A-Step1 Photoshop blend-mode node-group contracts."""
    return [create_blend_node_group(mode, force=force, prefix=prefix) for mode in modes]


def _blender_math_eval(operation: str, a: float, b: float, c: float) -> float:
    """Scalar evaluation of ShaderNodeMath with Blender's safe-math semantics."""
    if operation == "ADD":
        return a + b
    if operation == "SUBTRACT":
        return a - b
    if operation == "MULTIPLY":
        return a * b
    if operation == "DIVIDE":
        return a / b if b != 0.0 else 0.0
    if operation == "MULTIPLY_ADD":
        return a * b + c
    if operation == "MINIMUM":
        return min(a, b)
    if operation == "MAXIMUM":
        return max(a, b)
    if operation == "SQRT":
        return math.sqrt(a) if a > 0.0 else 0.0
    if operation == "ABSOLUTE":
        return abs(a)
    if operation == "FLOOR":
        return math.floor(a)
    if operation == "FRACT":
        return a - math.floor(a)
    if operation == "MODULO":
        # Blender's Math node MODULO is C fmod (sign of the dividend), NOT
        # numpy/GLSL floored mod.  Formula code must not rely on non-negative
        # results without normalizing.
        return math.fmod(a, b) if b != 0.0 else 0.0
    if operation == "GREATER_THAN":
        return 1.0 if a > b else 0.0
    if operation == "LESS_THAN":
        return 1.0 if a < b else 0.0
    raise ValueError(f"unsupported math operation: {operation}")


def evaluate_blend_group_cpu(
    group,
    *,
    dst: tuple[float, float, float],
    src: tuple[float, float, float],
    dst_alpha: float = 1.0,
    src_alpha: float = 1.0,
    opacity: float = 1.0,
    clip_alpha: float = 1.0,
) -> dict[str, object]:
    """CPU-evaluate the actual generated node graph.

    Walks the real node network (Math / SeparateColor / CombineColor in RGB
    mode only) with Blender's per-node semantics, so wiring or operation
    mistakes are caught numerically in background Blender without any GPU
    context.  The GLSL path shares formulas but not wiring; this is the only
    check that exercises the node graphs themselves.
    """
    inputs = {
        "Dst Color": tuple(float(v) for v in tuple(dst)[:3]),
        "Src Color": tuple(float(v) for v in tuple(src)[:3]),
        "Dst Alpha": float(dst_alpha),
        "Src Alpha": float(src_alpha),
        "Opacity": float(opacity),
        "Clip Alpha": float(clip_alpha),
    }
    link_from = {link.to_socket.as_pointer(): link.from_socket for link in group.links}
    cache: dict[int, object] = {}

    def input_value(socket):
        upstream = link_from.get(socket.as_pointer())
        if upstream is not None:
            return output_value(upstream)
        default = getattr(socket, "default_value", 0.0)
        if socket.type == "RGBA":
            return tuple(float(v) for v in default)[:3]
        return float(default)

    def output_value(socket):
        key = socket.as_pointer()
        if key not in cache:
            evaluate_node(socket.node)
            if key not in cache:
                raise ValueError(f"socket {socket.name!r} on {socket.node.bl_idname} not evaluated")
        return cache[key]

    def evaluate_node(node):
        idname = node.bl_idname
        if idname == "NodeGroupInput":
            for out in node.outputs:
                if out.name in inputs:
                    cache[out.as_pointer()] = inputs[out.name]
            return
        if idname == "ShaderNodeMath":
            a = float(input_value(node.inputs[0]))
            b = float(input_value(node.inputs[1])) if len(node.inputs) > 1 else 0.0
            c = float(input_value(node.inputs[2])) if len(node.inputs) > 2 else 0.0
            value = _blender_math_eval(node.operation, a, b, c)
            if getattr(node, "use_clamp", False):
                value = min(max(value, 0.0), 1.0)
            cache[node.outputs[0].as_pointer()] = float(value)
            return
        if idname == "ShaderNodeSeparateColor":
            if node.mode != "RGB":
                raise ValueError(f"unsupported SeparateColor mode: {node.mode}")
            color = input_value(node.inputs[0])
            for index, out in enumerate(node.outputs[:3]):
                cache[out.as_pointer()] = float(color[index])
            return
        if idname == "ShaderNodeCombineColor":
            if node.mode != "RGB":
                raise ValueError(f"unsupported CombineColor mode: {node.mode}")
            rgb = tuple(float(input_value(node.inputs[index])) for index in range(3))
            cache[node.outputs[0].as_pointer()] = rgb
            return
        raise ValueError(f"unsupported node in blend group: {idname}")

    output_node = next(n for n in group.nodes if n.bl_idname == "NodeGroupOutput")
    result: dict[str, object] = {}
    for name in ("Color", "Alpha", "Blend Color", "Effective Alpha"):
        socket = output_node.inputs.get(name)
        if socket is not None:
            result[name] = input_value(socket)
    return result


def verify_groups_against_oracle_cpu(
    modes: Iterable[str] = PSD_BLEND_MODES,
    *,
    prefix: str = "SPS_PSBlend_",
    tolerance: float = 1.0e-4,
) -> tuple[bool, str]:
    """Numerically verify the real node graphs against blend_rgb_oracle on CPU.

    With dst_alpha=1, src_alpha=1, clip_alpha=1 and opacity=case.alpha the
    group's straight-alpha compositing reduces to the RGB oracle for every mode
    (including REPLACE and DISABLE), so the actual node wiring can be validated
    numerically without a GPU.  Output Alpha must stay 1.0 under this mapping.
    """
    import numpy as np

    max_err = 0.0
    worst = ""
    checked = 0
    for mode in dict.fromkeys(normalize_mode(m) for m in modes):
        group = create_blend_node_group(mode, prefix=prefix)
        for case in golden_cases([mode]):
            expected = blend_rgb_oracle(
                np.asarray([case.dst], dtype=np.float32),
                np.asarray([case.src], dtype=np.float32),
                np.asarray([case.alpha], dtype=np.float32),
                mode,
            )[0]
            outputs = evaluate_blend_group_cpu(group, dst=case.dst, src=case.src, opacity=case.alpha)
            actual = outputs["Color"]
            err = max(abs(float(e) - float(a)) for e, a in zip(expected, actual))
            err = max(err, abs(float(outputs.get("Alpha", 1.0)) - 1.0))
            checked += 1
            if err > max_err:
                max_err = err
                worst = (
                    f"mode={mode} dst={case.dst} src={case.src} alpha={case.alpha} "
                    f"expected={tuple(round(float(v), 6) for v in expected)} "
                    f"actual={tuple(round(float(v), 6) for v in actual)}"
                )
    if max_err > float(tolerance):
        return False, f"max_err={max_err:.6e} cases={checked} worst: {worst}"
    return True, f"ok cases={checked} max_err={max_err:.6e}"


_FORBIDDEN_BLEND_NODE_IDNAMES = ("ShaderNodeMixRGB", "ShaderNodeMix")


def audit_blend_node_groups(
    modes: Iterable[str] = PSD_BLEND_MODES,
    *,
    prefix: str = "SPS_PSBlend_",
) -> dict[str, object]:
    """Background-safe structural audit of the generated blend groups."""
    import bpy

    report: dict[str, object] = {"ok": True, "missing": [], "violations": [], "groups": {}}
    for mode in dict.fromkeys(normalize_mode(m) for m in modes):
        name = _node_group_name(mode, prefix=prefix)
        group = bpy.data.node_groups.get(name)
        if group is None:
            report["missing"].append(name)
            report["ok"] = False
            continue
        violations = [
            f"{name}:{node.bl_idname}"
            for node in group.nodes
            if node.bl_idname in _FORBIDDEN_BLEND_NODE_IDNAMES
        ]
        color_linked = any(
            link.to_node.bl_idname == "NodeGroupOutput" and link.to_socket.name == "Color"
            for link in group.links
        )
        entry = {
            "status": str(group.get("sps_formula_status", "")),
            "version": str(group.get("sps_formula_version", "")),
            "nodes": len(group.nodes),
            "links": len(group.links),
            "color_linked": bool(color_linked),
            "violations": violations,
        }
        report["groups"][name] = entry
        if violations:
            report["violations"].extend(violations)
        if entry["status"] != "math_nodes" or violations or not color_linked or len(group.nodes) <= 4:
            report["ok"] = False
    return report


def _glsl_blend_source(mode: str) -> str:
    mode_key = normalize_mode(mode)
    if mode_key in {"MIX", "PASS_THROUGH"}:
        mixed = "s"
    elif mode_key in {"ADD", "LINEAR_DODGE"}:
        mixed = "sat(d + s)"
    elif mode_key == "MULTIPLY":
        mixed = "d * s"
    elif mode_key == "SCREEN":
        mixed = "1.0 - (1.0 - d) * (1.0 - s)"
    elif mode_key == "OVERLAY":
        mixed = "mix(2.0 * d * s, 1.0 - 2.0 * (1.0 - d) * (1.0 - s), step(vec3(0.5000001), d))"
    elif mode_key == "SOFT_LIGHT":
        mixed = "softLight(d, s)"
    elif mode_key == "HARD_LIGHT":
        mixed = "mix(2.0 * d * s, 1.0 - 2.0 * (1.0 - d) * (1.0 - s), step(vec3(0.5000001), s))"
    elif mode_key == "COLOR_DODGE":
        mixed = "colorDodge(d, s)"
    elif mode_key == "COLOR_BURN":
        mixed = "colorBurn(d, s)"
    elif mode_key == "LINEAR_BURN":
        mixed = "sat(d + s - 1.0)"
    elif mode_key == "VIVID_LIGHT":
        mixed = "mix(colorBurn(d, 2.0 * s), colorDodge(d, 2.0 * (s - 0.5)), step(vec3(0.5000001), s))"
    elif mode_key == "LINEAR_LIGHT":
        mixed = "sat(d + 2.0 * s - 1.0)"
    elif mode_key == "PIN_LIGHT":
        mixed = "mix(min(d, 2.0 * s), max(d, 2.0 * (s - 0.5)), step(vec3(0.5000001), s))"
    elif mode_key == "SUBTRACT":
        mixed = "sat(d - s)"
    elif mode_key == "INVERSE_SUBTRACT":
        mixed = "sat(s - d)"
    elif mode_key == "DIVIDE":
        mixed = "sat(d / max(s, vec3(EPS)))"
    elif mode_key == "INVERSE_DIVIDE":
        mixed = "sat(s / max(d, vec3(EPS)))"
    elif mode_key == "SIGNED_ADD":
        mixed = "sat(d + (s - 0.5) * 2.0)"
    elif mode_key == "DIFFERENCE":
        mixed = "abs(d - s)"
    elif mode_key == "EXCLUSION":
        mixed = "d + s - 2.0 * d * s"
    elif mode_key == "DARKEN":
        mixed = "min(d, s)"
    elif mode_key == "LIGHTEN":
        mixed = "max(d, s)"
    elif mode_key in {"TINT", "HUE"}:
        mixed = "hsvReplace(d, s, 1, 0, 0)"
    elif mode_key == "SATURATION":
        mixed = "hsvReplace(d, s, 0, 1, 0)"
    elif mode_key == "COLOR":
        mixed = "hsvReplace(d, s, 1, 1, 0)"
    elif mode_key in {"VALUE", "LUMINOSITY"}:
        mixed = "hsvReplace(d, s, 0, 0, 1)"
    elif mode_key in {"NORMAL_MAP_COMBINE", "NORMAL_MAP_DETAIL"}:
        mixed = "normalWhiteout(d, s, 0)"
    elif mode_key == "NORMAL_MAP_INVERSE_DETAIL":
        mixed = "normalWhiteout(d, s, 1)"
    elif mode_key == "DISABLE":
        mixed = "d"
    else:
        mixed = "s"
    return f"""
const float EPS = 0.000001;
vec3 sat(vec3 v) {{ return clamp(v, vec3(0.0), vec3(1.0)); }}
vec3 colorDodge(vec3 d, vec3 s) {{
    vec3 raw = min(vec3(1.0), d / max(vec3(EPS), 1.0 - s));
    return mix(raw, vec3(1.0), step(vec3(1.0 - EPS), s));
}}
vec3 colorBurn(vec3 d, vec3 s) {{
    vec3 raw = 1.0 - min(vec3(1.0), (1.0 - d) / max(s, vec3(EPS)));
    return mix(raw, vec3(0.0), 1.0 - step(vec3(EPS), s));
}}
vec3 softLight(vec3 d, vec3 s) {{
    vec3 dd = mix(((16.0 * d - 12.0) * d + 4.0) * d, sqrt(max(d, vec3(0.0))), step(vec3(0.2500001), d));
    vec3 low = d - (1.0 - 2.0 * s) * d * (1.0 - d);
    vec3 high = d + (2.0 * s - 1.0) * (dd - d);
    return mix(low, high, step(vec3(0.5000001), s));
}}
vec3 rgb2hsv(vec3 c) {{
    float mx = max(max(c.r, c.g), c.b);
    float mn = min(min(c.r, c.g), c.b);
    float delta = mx - mn;
    float h = 0.0;
    if (delta > EPS) {{
        if (mx == c.r) h = mod((c.g - c.b) / delta, 6.0);
        if (mx == c.g) h = ((c.b - c.r) / delta) + 2.0;
        if (mx == c.b) h = ((c.r - c.g) / delta) + 4.0;
        h = mod(h / 6.0, 1.0);
    }}
    float satv = (mx <= EPS) ? 0.0 : delta / max(mx, EPS);
    return vec3(h, satv, mx);
}}
vec3 hsv2rgb(vec3 hsv) {{
    float h = mod(hsv.x, 1.0) * 6.0;
    float s = clamp(hsv.y, 0.0, 1.0);
    float v = clamp(hsv.z, 0.0, 1.0);
    int i = int(floor(h));
    float f = h - float(i);
    float p = v * (1.0 - s);
    float q = v * (1.0 - s * f);
    float t = v * (1.0 - s * (1.0 - f));
    int m = i - (i / 6) * 6;
    if (m == 0) return vec3(v, t, p);
    if (m == 1) return vec3(q, v, p);
    if (m == 2) return vec3(p, v, t);
    if (m == 3) return vec3(p, q, v);
    if (m == 4) return vec3(t, p, v);
    return vec3(v, p, q);
}}
vec3 hsvReplace(vec3 d, vec3 s, int hueFlag, int satFlag, int valFlag) {{
    vec3 dh = rgb2hsv(clamp(d, 0.0, 1.0));
    vec3 sh = rgb2hsv(clamp(s, 0.0, 1.0));
    if (hueFlag != 0) dh.x = sh.x;
    if (satFlag != 0) dh.y = sh.y;
    if (valFlag != 0) dh.z = sh.z;
    return clamp(hsv2rgb(dh), 0.0, 1.0);
}}
vec3 normalWhiteout(vec3 d, vec3 s, int inverse) {{
    vec3 dn = clamp(d * 2.0 - 1.0, -1.0, 1.0);
    vec3 sn = clamp(s * 2.0 - 1.0, -1.0, 1.0);
    if (inverse != 0) sn.xy *= -1.0;
    vec3 outn = vec3(dn.x + sn.x, dn.y + sn.y, dn.z * sn.z);
    outn = outn / max(length(outn), EPS);
    return clamp(outn * 0.5 + 0.5, 0.0, 1.0);
}}
vec3 blend_formula(vec3 d, vec3 s, float a) {{
    vec3 mixed = {mixed};
    return clamp(mix(d, mixed, clamp(a, 0.0, 1.0)), 0.0, 1.0);
}}
"""


def _gpu_formula_shader(mode: str):
    import gpu

    # Blender 5.x removed direct GPUShader construction; build via
    # GPUShaderCreateInfo (works on both Vulkan and OpenGL backends).
    try:
        info = gpu.types.GPUShaderCreateInfo()
    except (AttributeError, TypeError):
        info = None
    if info is not None:
        info.vertex_in(0, "VEC2", "pos")
        info.push_constant("VEC3", "u_dst")
        info.push_constant("VEC3", "u_src")
        info.push_constant("FLOAT", "u_alpha")
        info.fragment_out(0, "VEC4", "fragColor")
        info.vertex_source("void main() { gl_Position = vec4(pos, 0.0, 1.0); }\n")
        info.fragment_source(
            _glsl_blend_source(mode)
            + "void main() { fragColor = vec4(blend_formula(u_dst, u_src, u_alpha), 1.0); }\n"
        )
        return gpu.shader.create_from_info(info)

    vertex = """
    in vec2 pos;
    void main()
    {
        gl_Position = vec4(pos, 0.0, 1.0);
    }
    """
    fragment = (
        "uniform vec3 u_dst;\n"
        "uniform vec3 u_src;\n"
        "uniform float u_alpha;\n"
        "out vec4 fragColor;\n"
        + _glsl_blend_source(mode)
        + """
    void main()
    {
        fragColor = vec4(blend_formula(u_dst, u_src, u_alpha), 1.0);
    }
    """
    )
    return gpu.types.GPUShader(vertex, fragment)


def gpu_formula_case_readback(case: BlendGoldenCase, *, tolerance: float = 1.0 / 255.0) -> tuple[bool, float, tuple[float, float, float] | None, str]:
    try:
        import gpu
        import numpy as np
        from gpu_extras.batch import batch_for_shader
    except Exception as exc:
        return False, float("inf"), None, f"import_failed:{exc!r}"

    offscreen = None
    try:
        shader = _gpu_formula_shader(case.mode)
        batch = batch_for_shader(shader, "TRI_FAN", {"pos": [(-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)]})
        offscreen = gpu.types.GPUOffScreen(1, 1)
        with offscreen.bind():
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 1.0))
            shader.bind()
            shader.uniform_float("u_dst", case.dst)
            shader.uniform_float("u_src", case.src)
            shader.uniform_float("u_alpha", float(case.alpha))
            batch.draw(shader)
            buffer = fb.read_color(0, 0, 1, 1, 4, 0, "FLOAT")
        actual = np.asarray(buffer, dtype=np.float32).reshape((1, 4))[0, :3]
        expected = blend_rgb_oracle(
            np.asarray([case.dst], dtype=np.float32),
            np.asarray([case.src], dtype=np.float32),
            np.asarray([case.alpha], dtype=np.float32),
            case.mode,
        )[0]
        max_err = float(np.max(np.abs(actual - expected)))
        return max_err <= float(tolerance), max_err, tuple(float(v) for v in actual), "ok"
    except Exception as exc:
        return False, float("inf"), None, f"gpu_unavailable:{exc!r}"
    finally:
        if offscreen is not None:
            try:
                offscreen.free()
            except Exception:
                pass


def run_gpu_formula_golden(
    modes: Iterable[str] = PHOTOSHOP_BLEND_MODES_27,
    *,
    tolerance: float = 1.0 / 255.0,
    max_cases_per_mode: int | None = 8,
) -> GPUFormulaResult:
    cases_all = golden_cases(modes)
    if max_cases_per_mode is not None:
        buckets: dict[str, int] = {}
        selected: list[BlendGoldenCase] = []
        for case in cases_all:
            count = buckets.get(case.mode, 0)
            if count >= int(max_cases_per_mode):
                continue
            selected.append(case)
            buckets[case.mode] = count + 1
        cases = selected
    else:
        cases = cases_all
    max_err = 0.0
    for idx, case in enumerate(cases):
        ok, err, actual, reason = gpu_formula_case_readback(case, tolerance=tolerance)
        if err != float("inf"):
            max_err = max(max_err, float(err))
        if not ok:
            expected = None
            try:
                import numpy as np
                expected = tuple(float(v) for v in blend_rgb_oracle(
                    np.asarray([case.dst], dtype=np.float32),
                    np.asarray([case.src], dtype=np.float32),
                    np.asarray([case.alpha], dtype=np.float32),
                    case.mode,
                )[0])
            except Exception:
                expected = None
            return GPUFormulaResult(
                False,
                reason,
                idx + 1,
                None if err == float("inf") else float(err),
                {
                    "mode": case.mode,
                    "dst": case.dst,
                    "src": case.src,
                    "alpha": case.alpha,
                    "actual": actual,
                    "expected": expected,
                },
            )
    return GPUFormulaResult(True, f"ok cases={len(cases)}", len(cases), max_err, None)


def gpu_offscreen_clear_readback(
    *,
    width: int = 2,
    height: int = 2,
    color: tuple[float, float, float, float] = (0.25, 0.5, 0.75, 1.0),
    tolerance: float = 1.0 / 255.0,
) -> GPUReadbackResult:
    """Smoke-test GPUOffScreen readback with a clear color.

    This is the lowest-risk probe for GUI Blender: it validates allocation,
    framebuffer clear, and readback without depending on production materials.
    It returns ``ok=False`` in background sessions where GPU drawing is not
    available.
    """
    try:
        import gpu
        import numpy as np
    except Exception as exc:
        return GPUReadbackResult(False, f"import_failed:{exc!r}", width, height)

    offscreen = None
    try:
        offscreen = gpu.types.GPUOffScreen(int(width), int(height))
        with offscreen.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.clear(color=color)
            buffer = framebuffer.read_color(0, 0, int(width), int(height), 4, 0, "FLOAT")
        arr = np.asarray(buffer, dtype=np.float32).reshape((-1, 4))
        expected = np.asarray(color, dtype=np.float32).reshape((1, 4))
        max_err = float(np.max(np.abs(arr - expected))) if arr.size else float("inf")
        sample = tuple(float(v) for v in arr[0]) if arr.size else None
        return GPUReadbackResult(max_err <= float(tolerance), "ok" if max_err <= float(tolerance) else "mismatch", int(width), int(height), sample, max_err)
    except Exception as exc:
        return GPUReadbackResult(False, f"gpu_unavailable:{exc!r}", int(width), int(height))
    finally:
        if offscreen is not None:
            try:
                offscreen.free()
            except Exception:
                pass


def run_a_step1_smoke(*, create_groups: bool = True, probe_offscreen: bool = True) -> AStep1SmokeResult:
    """Run the standalone A-Step1 checks that do not touch the C-line pipeline."""
    oracle_ok, oracle_message = verify_against_psd_io()
    groups = ensure_blend_node_groups() if create_groups else []
    readback = gpu_offscreen_clear_readback() if probe_offscreen else GPUReadbackResult(False, "disabled", 0, 0)
    formula = run_gpu_formula_golden() if probe_offscreen else GPUFormulaResult(False, "disabled", 0)
    limits = measure_gpu_limits(probe_offscreen=probe_offscreen)
    return AStep1SmokeResult(
        oracle_ok=bool(oracle_ok),
        oracle_message=str(oracle_message),
        node_groups_created=len(groups),
        gpu_readback=readback,
        gpu_formula=formula,
        gpu_limits=limits,
    )
