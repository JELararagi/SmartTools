# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import bpy

try:
    from bpy.app.handlers import persistent as _blender_persistent
except Exception:  # pragma: no cover - outside Blender
    def _blender_persistent(func):  # type: ignore
        return func

from .translation import t


@dataclass(frozen=True)
class PersistentFeature:
    feature_id: str
    suite_property: str
    label_ja: str
    label_en: str
    description_ja: str
    description_en: str
    default: bool = False


_FEATURES: tuple[PersistentFeature, ...] = (
    PersistentFeature(
        "ui_asset_cache",
        "persistent_ui_asset_cache",
        "UIアイコンキャッシュ",
        "UI Icon Cache",
        "機能: SCS独自PNGアイコンと画像リファレンスのプレビュー使用を切り替えます。Blender 5.1ではUIパネル安定性を優先し、標準アイコン表示へ安全フォールバックします。",
        "Function: toggles preview use for SCS original PNG icons and visual references. In Blender 5.1, UI panel stability is prioritized and the UI safely falls back to built-in icons.",
        False,
    ),
    PersistentFeature(
        "auto_enable_compositor",
        "persistent_auto_enable_compositor",
        "コンポジター自動維持",
        "Compositor Keep-Alive",
        "機能: Blender起動時、.blend読込後、この項目を有効にした時、またはSCS操作前に、現在シーンのコンポジター使用状態とレンダー合成状態だけを確認し、無効なら有効化します。常時タイマー監視は行いません。使い方: ショット読込時にコンポジターを自動で準備したい場合だけ有効にします。",
        "Function: checks the current scene on Blender startup, after .blend load, when enabling this item, or before SCS operations, and enables only compositor-use and render-compositing flags when disabled. It does not use a continuous timer. How to use: enable only when shots should be prepared for compositing on load.",
        False,
    ),
    PersistentFeature(
        "auto_render_pass_guard",
        "persistent_auto_render_pass_guard",
        "レンダーパス自動維持",
        "Render Pass Guard",
        "機能: Blender起動時、.blend読込後、この項目を有効にした時、またはSCS操作前に、AOV、Z、ミスト、法線、ベクトル、クリプトマットなどSCS診断に必要なレンダーパスを補助的に有効化します。常時タイマー監視は行いません。使い方: SCS前提のマルチパス制作で読込時にパスを揃えたい時だけ有効にします。",
        "Function: enables Render Passes needed by SCS diagnostics, such as AOV, Z, Mist, Normal, Vector, and Cryptomatte, on Blender startup, after .blend load, when enabling this item, or before SCS operations. It does not use a continuous timer. How to use: enable only for multipass production that should be SCS-ready on load.",
        False,
    ),
    PersistentFeature(
        "auto_precision_output_guard",
        "persistent_auto_precision_output_guard",
        "精度出力自動維持",
        "Precision Output Guard",
        "機能: Blender起動時、.blend読込後、この項目を有効にした時、またはSCS操作前に、OpenEXR Multilayer、RGBA、高ビット深度、ZIP圧縮など高精度コンポジット向けの出力設定を確認し、不足時だけ補います。常時タイマー監視は行いません。使い方: 納品前の.blendを開いた時に出力設定の戻りを防ぎたい場合だけ有効にします。",
        "Function: checks high-precision compositing output settings such as OpenEXR Multilayer, RGBA, high bit depth, and ZIP compression on Blender startup, after .blend load, when enabling this item, or before SCS operations, and fills only missing values. It does not use a continuous timer. How to use: enable only for delivery files that should be corrected on load.",
        False,
    ),
    PersistentFeature(
        "auto_node_tree_sanity",
        "persistent_auto_node_tree_sanity",
        "ノード健全性ガード",
        "Node Sanity Guard",
        "機能: Blender起動時、.blend読込後、この項目を有効にした時、またはSCS操作前に、コンポジターのノードツリー、レンダーレイヤー、ビューアー、コンポジットの最低限の存在確認を行い、不足時だけ安全に補います。常時タイマー監視は行いません。使い方: テンプレート、教育用ファイル、レビュー用シーンを読込時に確認表示へ整えたい場合に有効にします。",
        "Function: checks the compositor node tree and minimum Render Layers, Viewer, and Composite availability on Blender startup, after .blend load, when enabling this item, or before SCS operations, adding only missing safe basics. It does not use a continuous timer. How to use: enable for templates, learning files, or review scenes that should be made reviewable on load.",
        False,
    ),
    PersistentFeature(
        "live_quality_status",
        "persistent_live_quality_status",
        "品質ステータス自動更新",
        "Auto Quality Status",
        "機能: Blender起動時、.blend読込後、この項目を有効にした時、またはSCSの診断・品質系操作後に、ノード数、SCSノード、出力ノード、主要レンダーパスの状態を軽量に読み取り、品質スコアを計算して記録します。常時タイマー監視は行いません。使い方: 最終確認時に読込後・操作後の品質スコアを自動で残したい場合だけ有効にします。",
        "Function: reads node count, SCS nodes, output nodes, and major Render Pass state on Blender startup, after .blend load, when enabling this item, or after SCS audit/quality operations, then calculates and records a quality score. It does not use a continuous timer. How to use: enable only when final review should keep an automatic score after load or operation.",
        False,
    ),
)

_FEATURE_BY_ID = {feature.feature_id: feature for feature in _FEATURES}
_FEATURE_BY_PROP = {feature.suite_property: feature for feature in _FEATURES}
_SCENE_GUARD_FEATURE_IDS = frozenset({
    "auto_enable_compositor",
    "auto_render_pass_guard",
    "auto_precision_output_guard",
    "auto_node_tree_sanity",
})
_REGISTERED = bool(globals().get("_REGISTERED", False))
_REGISTER_TOKEN = str(globals().get("_REGISTER_TOKEN", "") or "")
_REGISTER_GENERATION = int(globals().get("_REGISTER_GENERATION", 0) or 0)


def feature_definitions() -> tuple[PersistentFeature, ...]:
    return _FEATURES


def get_feature(feature_id: str) -> PersistentFeature | None:
    return _FEATURE_BY_ID.get(str(feature_id or ""))


def get_feature_by_property(prop_name: str) -> PersistentFeature | None:
    return _FEATURE_BY_PROP.get(str(prop_name or ""))


def localized_label(feature: PersistentFeature, settings=None) -> str:
    return t(feature.label_ja, feature.label_en, settings)


def localized_description(feature: PersistentFeature, settings=None) -> str:
    return t(feature.description_ja, feature.description_en, settings)


def _settings(context=None):
    try:
        from .properties import get_settings
        return get_settings(context)
    except Exception:
        return None


def feature_value(feature_or_id: PersistentFeature | str, context=None) -> bool:
    feature = feature_or_id if isinstance(feature_or_id, PersistentFeature) else get_feature(str(feature_or_id))
    if feature is None:
        return False
    settings = _settings(context)
    if settings is not None and hasattr(settings, feature.suite_property):
        try:
            return bool(getattr(settings, feature.suite_property))
        except Exception:
            pass
    # Never fall back to disk here. This helper is used by panel drawing and
    # event guards; a missing exact RNA settings instance keeps the feature at
    # its declared default until properties.py explicitly loads persisted JSON.
    return bool(feature.default)


def _active_context():
    try:
        return bpy.context
    except Exception:
        return None


def _scene_guard_enabled(context=None) -> bool:
    settings = _settings(context)
    if settings is not None:
        return any(
            bool(getattr(settings, feature.suite_property, False))
            for feature_id in _SCENE_GUARD_FEATURE_IDS
            for feature in (get_feature(feature_id),)
            if feature is not None
        )
    return False


def _sync_proxy_cleanup_load_handler(context=None) -> None:
    from . import proxy_cleanup
    if not proxy_cleanup.set_load_cleanup_enabled(_scene_guard_enabled(context)):
        raise RuntimeError("Smart Composite proxy-cleanup resource transition failed")


def _transactional(label: str, callback: Callable[[], Any]) -> Any:
    from . import transaction
    with transaction.operation_transaction(label) as (active, owner):
        result = callback()
        if owner:
            active.commit()
        return result


def _run_auto_enable_compositor(context=None) -> None:
    ctx = context or _active_context()
    scene = getattr(ctx, "scene", None) if ctx is not None else None
    if scene is None:
        return

    def apply() -> None:
        from .node_utils import ensure_compositor_tree, safe_set
        ensure_compositor_tree(ctx)
        render = getattr(scene, "render", None)
        if render is not None and hasattr(render, "use_compositing") and not bool(getattr(render, "use_compositing", False)):
            safe_set(render, "use_compositing", True)

    _transactional("persistent.auto_enable_compositor", apply)


def _run_auto_render_pass_guard(context=None) -> None:
    ctx = context or _active_context()

    def apply() -> None:
        from .builders import enable_render_passes
        enable_render_passes(ctx)

    _transactional("persistent.auto_render_pass_guard", apply)


def _run_auto_precision_output_guard(context=None) -> None:
    ctx = context or _active_context()

    def apply() -> None:
        from .quality import apply_scene_precision
        apply_scene_precision(ctx, _settings(ctx))

    _transactional("persistent.auto_precision_output_guard", apply)


def _run_auto_node_tree_sanity(context=None) -> None:
    ctx = context or _active_context()

    def apply() -> None:
        from .builders import enable_compositor
        enable_compositor(ctx)

    _transactional("persistent.auto_node_tree_sanity", apply)


def _run_live_quality_status(context=None) -> None:
    ctx = context or _active_context()
    settings = _settings(ctx)
    if settings is None:
        return
    from .quality import quality_report
    from .transaction import set_attr
    report = quality_report(ctx, settings)
    score = int(report.get("quality_score", 0) or 0)
    total = int(report.get("node_summary", {}).get("total_nodes", 0) or 0)
    smart = int(report.get("node_summary", {}).get("smart_nodes", 0) or 0)
    set_attr(
        settings,
        "last_message",
        t(
            f"品質ステータス自動更新: 品質スコア {score}/100、ノード {total}、SCS {smart}。",
            f"Auto Quality Status: quality score {score}/100, nodes {total}, SCS {smart}.",
            settings,
        ),
    )


def refresh_live_quality_status(context=None) -> None:
    if feature_value("live_quality_status", context):
        _transactional("persistent.live_quality_status", lambda: _run_live_quality_status(context))


# Compatibility callback names retained. They are never registered directly;
# properties.py owns one exact load_post handler and invokes all enabled features.
@_blender_persistent
def _scs_auto_enable_compositor_load(_dummy=None):
    if feature_value("auto_enable_compositor"):
        _run_auto_enable_compositor()


@_blender_persistent
def _scs_auto_render_pass_guard_load(_dummy=None):
    if feature_value("auto_render_pass_guard"):
        _run_auto_render_pass_guard()


@_blender_persistent
def _scs_auto_precision_output_guard_load(_dummy=None):
    if feature_value("auto_precision_output_guard"):
        _run_auto_precision_output_guard()


@_blender_persistent
def _scs_auto_node_tree_sanity_load(_dummy=None):
    if feature_value("auto_node_tree_sanity"):
        _run_auto_node_tree_sanity()


def _apply_ui_asset_cache(enabled: bool) -> None:
    try:
        from . import visual_assets
        visual_assets.set_custom_icons_enabled(bool(enabled))
    except Exception:
        pass


def _cleanup_legacy_runtime_hooks() -> None:
    """Compatibility no-op; current generation never scans/removes old hooks."""
    return None


def _apply_auto_enable_compositor(enabled: bool, context=None) -> None:
    if enabled:
        _run_auto_enable_compositor(context)


def _apply_auto_render_pass_guard(enabled: bool, context=None) -> None:
    if enabled:
        _run_auto_render_pass_guard(context)


def _apply_auto_precision_output_guard(enabled: bool, context=None) -> None:
    if enabled:
        _run_auto_precision_output_guard(context)


def _apply_auto_node_tree_sanity(enabled: bool, context=None) -> None:
    if enabled:
        _run_auto_node_tree_sanity(context)


def _apply_live_quality_status(enabled: bool, context=None) -> None:
    if enabled:
        _transactional("persistent.live_quality_status", lambda: _run_live_quality_status(context))


def apply_enabled_event_guards(context=None, *, include_quality: bool = False) -> None:
    """Apply enabled event guards once without timer/watchdog/polling."""
    ctx = context or _active_context()

    def apply() -> None:
        if feature_value("auto_enable_compositor", ctx):
            _run_auto_enable_compositor(ctx)
        if feature_value("auto_render_pass_guard", ctx):
            _run_auto_render_pass_guard(ctx)
        if feature_value("auto_precision_output_guard", ctx):
            _run_auto_precision_output_guard(ctx)
        if feature_value("auto_node_tree_sanity", ctx):
            _run_auto_node_tree_sanity(ctx)
        if include_quality and feature_value("live_quality_status", ctx):
            _run_live_quality_status(ctx)

    _transactional("persistent.enabled_event_guards", apply)


def apply_feature(
    feature_or_id: PersistentFeature | str,
    context=None,
    *,
    sync_proxy_cleanup: bool = True,
) -> None:
    feature = feature_or_id if isinstance(feature_or_id, PersistentFeature) else get_feature(str(feature_or_id))
    if feature is None:
        return
    enabled = feature_value(feature, context)
    if feature.feature_id == "ui_asset_cache":
        _apply_ui_asset_cache(enabled)
    elif feature.feature_id == "auto_enable_compositor":
        _apply_auto_enable_compositor(enabled, context)
    elif feature.feature_id == "auto_render_pass_guard":
        _apply_auto_render_pass_guard(enabled, context)
    elif feature.feature_id == "auto_precision_output_guard":
        _apply_auto_precision_output_guard(enabled, context)
    elif feature.feature_id == "auto_node_tree_sanity":
        _apply_auto_node_tree_sanity(enabled, context)
    elif feature.feature_id == "live_quality_status":
        _apply_live_quality_status(enabled, context)
    if sync_proxy_cleanup:
        _sync_proxy_cleanup_load_handler(context)


def apply_all_persistent_features(context=None) -> None:
    for feature in _FEATURES:
        apply_feature(feature, context, sync_proxy_cleanup=False)
    _sync_proxy_cleanup_load_handler(context)


def disable_all_runtime_hooks() -> None:
    try:
        from . import proxy_cleanup
        proxy_cleanup.set_load_cleanup_enabled(False)
    except Exception:
        pass
    try:
        from . import visual_assets
        visual_assets.set_custom_icons_enabled(False)
    except Exception:
        pass


def _current_lifecycle_identity() -> tuple[str, int]:
    try:
        from . import registration
        token = str(registration.current_owner_token() or "")
        generation = int(registration.current_generation() or 0)
    except Exception:
        return "", 0
    if not token or token == "unregistered" or generation <= 0:
        return "", 0
    return token, generation


def registration_identity_valid() -> bool:
    token, generation = _current_lifecycle_identity()
    return bool(
        _REGISTERED
        and token
        and token == _REGISTER_TOKEN
        and generation == _REGISTER_GENERATION
    )


def register() -> bool:
    global _REGISTERED, _REGISTER_TOKEN, _REGISTER_GENERATION
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return False
    if registration_identity_valid():
        return True
    # This module owns no permanent Blender callback itself. Exact external
    # resources are released before adopting a replacement generation.
    disable_all_runtime_hooks()
    _REGISTER_TOKEN = token
    _REGISTER_GENERATION = generation
    _REGISTERED = True
    # No settings file read, catalog load, handler, timer, or scene traversal is
    # performed here. properties.register/load_post applies enabled features.
    return registration_identity_valid()


def unregister() -> bool:
    global _REGISTERED, _REGISTER_TOKEN, _REGISTER_GENERATION
    disable_all_runtime_hooks()
    try:
        from . import visual_assets
        visual_assets.unregister()
    except Exception:
        pass
    _REGISTERED = False
    _REGISTER_TOKEN = ""
    _REGISTER_GENERATION = 0
    return True
