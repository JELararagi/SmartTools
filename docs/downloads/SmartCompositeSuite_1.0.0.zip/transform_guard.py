# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

from contextlib import contextmanager
from typing import Any


def _iter_scene_objects(context=None):
    try:
        import bpy  # type: ignore
        ctx = context or getattr(bpy, "context", None)
    except Exception:
        ctx = context
    try:
        scene = getattr(ctx, "scene", None)
        if scene is None:
            return ()
        return tuple(getattr(scene, "objects", ()) or ())
    except Exception:
        return ()


def _as_tuple(value: Any) -> tuple[float, ...] | tuple[tuple[float, ...], ...] | str | None:
    try:
        if isinstance(value, str):
            return value
        rows = getattr(value, "row", None)
        if rows is not None:
            return tuple(tuple(float(item) for item in row) for row in value)
        return tuple(float(item) for item in value)
    except Exception:
        return None


def _same_value(left: Any, right: Any, *, epsilon: float = 1e-7) -> bool:
    if isinstance(left, str) or isinstance(right, str):
        return left == right
    if left is None or right is None:
        return left is right
    try:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if isinstance(a, tuple) or isinstance(b, tuple):
                if not _same_value(a, b, epsilon=epsilon):
                    return False
            elif abs(float(a) - float(b)) > epsilon:
                return False
        return True
    except Exception:
        return False


def _assign_sequence(target: Any, value: Any) -> bool:
    try:
        if isinstance(value, str):
            return False
        for index, item in enumerate(value):
            if isinstance(item, tuple):
                for sub_index, sub_value in enumerate(item):
                    target[index][sub_index] = float(sub_value)
            else:
                target[index] = float(item)
        return True
    except Exception:
        return False


_TRANSFORM_ATTRS = (
    "location",
    "rotation_mode",
    "rotation_euler",
    "rotation_quaternion",
    "rotation_axis_angle",
    "scale",
    "delta_location",
    "delta_rotation_euler",
    "delta_rotation_quaternion",
    "delta_scale",
    "matrix_parent_inverse",
)


def snapshot_object_transforms(context=None) -> dict[int, tuple[Any, dict[str, Any]]]:
    """Capture object transform fields before an SCS scene operation.

    Smart Composite is a compositor/node tool and must never change object
    transforms.  This snapshot is used as a safety fence around the few SCS
    operations that touch scene render settings, render passes, or compositor
    nodes.
    """
    snapshot: dict[int, tuple[Any, dict[str, Any]]] = {}
    for obj in _iter_scene_objects(context):
        try:
            pointer_fn = getattr(obj, "as_pointer", None)
            key = int(pointer_fn()) if callable(pointer_fn) else id(obj)
        except Exception:
            key = id(obj)
        values: dict[str, Any] = {}
        for attr in _TRANSFORM_ATTRS:
            try:
                if hasattr(obj, attr):
                    value = _as_tuple(getattr(obj, attr))
                    if value is not None:
                        values[attr] = value
            except Exception:
                continue
        if values:
            snapshot[key] = (obj, values)
    return snapshot


def restore_object_transforms(snapshot: dict[int, tuple[Any, dict[str, Any]]]) -> int:
    """Restore transforms only when an SCS operation changed them."""
    restored = 0
    for obj, values in tuple(snapshot.values()):
        for attr, stored in values.items():
            try:
                if not hasattr(obj, attr):
                    continue
                current_obj = getattr(obj, attr)
                current = _as_tuple(current_obj)
                if _same_value(current, stored):
                    continue
                if isinstance(stored, str):
                    setattr(obj, attr, stored)
                elif _assign_sequence(current_obj, stored):
                    pass
                else:
                    setattr(obj, attr, stored)
                restored += 1
            except Exception:
                continue
    return restored


@contextmanager
def preserve_object_transforms(context=None):
    snapshot = snapshot_object_transforms(context)
    try:
        yield
    finally:
        restore_object_transforms(snapshot)
