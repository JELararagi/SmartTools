# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Pure Smart Tools Manager placement bridge for native Smart Composite roots.

Only two fixed, already-loaded Manager package names are consulted.  The hot
path performs no import, module scan, cache, file I/O, timer, redraw request,
class mutation, or Manager lifecycle operation.
"""

from __future__ import annotations

import sys
from typing import Any

TOOL_KEY = "SMART_COMPOSITE"

LOGICAL_EDITOR_KEYS = (
    "VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR", "SHADER_EDITOR", "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR", "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR", "DOPE_SHEET", "GRAPH_EDITOR", "DRIVERS",
    "NLA_EDITOR", "TEXT_EDITOR", "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET",
)
LOGICAL_EDITOR_KEY_SET = frozenset(LOGICAL_EDITOR_KEYS)

PHYSICAL_SPACE_BY_EDITOR = {
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
}

LOGICAL_EDITORS_BY_PHYSICAL = {
    "VIEW_3D": ("VIEW_3D",),
    "IMAGE_EDITOR": ("IMAGE_EDITOR", "UV_EDITOR"),
    "NODE_EDITOR": ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR"),
    "SEQUENCE_EDITOR": ("VIDEO_SEQUENCER",),
    "CLIP_EDITOR": ("MOVIE_CLIP_EDITOR",),
    "DOPESHEET_EDITOR": ("DOPE_SHEET",),
    "GRAPH_EDITOR": ("GRAPH_EDITOR", "DRIVERS"),
    "NLA_EDITOR": ("NLA_EDITOR",),
    "TEXT_EDITOR": ("TEXT_EDITOR",),
    "FILE_BROWSER": ("ASSET_BROWSER", "FILE_BROWSER"),
    "SPREADSHEET": ("SPREADSHEET",),
}
PHYSICAL_SPACE_TYPES = frozenset(LOGICAL_EDITORS_BY_PHYSICAL)

# Required fixed lookups.  Do not add repository guesses, submodules, or a
# sys.modules scan: poll/draw must never discover or import Manager dynamically.
_MANAGER_MODULE_NAMES = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
)
_MANAGER_API_NAME = "placement_allowed"

_READY_PHASES = frozenset({"READY", "ACTIVE", "REGISTERED"})
_NOT_READY_PHASES = frozenset({
    "IDLE", "DISABLED", "UNREGISTERED", "REGISTERING", "UNREGISTERING",
    "NOT_READY", "MIGRATING", "RELOADING", "ROLLBACK", "FAILED", "ERROR",
})
_PHASE_ATTRIBUTE_NAMES = (
    "registration_phase",
    "manager_phase",
    "runtime_phase",
    "lifecycle_phase",
)
_READY_ATTRIBUTE_NAMES = (
    "registration_ready",
    "manager_ready",
    "runtime_ready",
)
_GENERATION_ATTRIBUTE_NAMES = (
    "registration_generation",
    "manager_registration_generation",
    "runtime_generation",
    "generation",
)


def _normalized(value: Any) -> str:
    try:
        return str(value or "").strip().upper()
    except Exception:
        return ""


def _attribute_text(value: Any, *names: str) -> str:
    for name in names:
        try:
            text = _normalized(getattr(value, name, None))
        except Exception:
            text = ""
        if text:
            return text
    return ""


def _active_space(area: Any) -> Any:
    try:
        spaces = getattr(area, "spaces", None)
        return getattr(spaces, "active", None)
    except Exception:
        return None


def physical_area_type(area: Any) -> str:
    """Return Blender's real area type without borrowing a logical subtype."""
    return _attribute_text(area, "type") if area is not None else ""


def detect_editor_key(area: Any) -> str | None:
    """Classify one Manager logical editor from its physical Blender area.

    An unresolved Node Editor is deliberately ``None``; it never falls back to
    Shader Editor and therefore cannot borrow that Manager cell.
    """
    if area is None:
        return None
    physical = physical_area_type(area)
    if physical not in PHYSICAL_SPACE_TYPES:
        return None

    space = _active_space(area)
    area_ui_type = _attribute_text(area, "ui_type")

    if physical == "VIEW_3D":
        return "VIEW_3D"

    if physical == "IMAGE_EDITOR":
        mode = _attribute_text(space, "mode", "ui_mode") or area_ui_type
        return "UV_EDITOR" if mode in {"UV", "UV_EDIT", "UVS", "UV_EDITOR"} else "IMAGE_EDITOR"

    if physical == "NODE_EDITOR":
        tree_type = _attribute_text(space, "tree_type") or area_ui_type
        return {
            "SHADERNODETREE": "SHADER_EDITOR",
            "SHADER_NODE_TREE": "SHADER_EDITOR",
            "SHADER": "SHADER_EDITOR",
            "COMPOSITORNODETREE": "COMPOSITOR",
            "COMPOSITOR_NODE_TREE": "COMPOSITOR",
            "COMPOSITOR": "COMPOSITOR",
            "GEOMETRYNODETREE": "GEOMETRY_NODE_EDITOR",
            "GEOMETRY_NODE_TREE": "GEOMETRY_NODE_EDITOR",
            "GEOMETRY": "GEOMETRY_NODE_EDITOR",
            "TEXTURENODETREE": "TEXTURE_NODE_EDITOR",
            "TEXTURE_NODE_TREE": "TEXTURE_NODE_EDITOR",
            "TEXTURE": "TEXTURE_NODE_EDITOR",
        }.get(tree_type)

    if physical == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if physical == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"

    if physical == "DOPESHEET_EDITOR":
        mode = _attribute_text(space, "mode", "ui_mode") or area_ui_type
        if mode in {"DRIVER", "DRIVERS", "TIMELINE"}:
            return None
        return "DOPE_SHEET"

    if physical == "GRAPH_EDITOR":
        mode = _attribute_text(space, "mode", "ui_mode") or area_ui_type
        return "DRIVERS" if mode in {"DRIVER", "DRIVERS"} else "GRAPH_EDITOR"

    if physical == "NLA_EDITOR":
        return "NLA_EDITOR"
    if physical == "TEXT_EDITOR":
        return "TEXT_EDITOR"

    if physical == "FILE_BROWSER":
        params = getattr(space, "params", None) if space is not None else None
        mode = (
            _attribute_text(space, "browse_mode", "mode")
            or _attribute_text(params, "browse_mode")
            or area_ui_type
        )
        return "ASSET_BROWSER" if mode in {"ASSET_BROWSER", "ASSETS"} else "FILE_BROWSER"

    if physical == "SPREADSHEET":
        return "SPREADSHEET"
    return None


def physical_matches(area: Any, editor_key: str) -> bool:
    """Return True only when physical area and classified logical key agree."""
    logical = _normalized(editor_key)
    expected_physical = PHYSICAL_SPACE_BY_EDITOR.get(logical)
    return bool(
        expected_physical
        and physical_area_type(area) == expected_physical
        and detect_editor_key(area) == logical
    )


def _public_manager_state(module: Any) -> str:
    """Return READY, NOT_READY, DISABLED, or UNKNOWN from public primitives."""
    try:
        enabled_marker = getattr(module, "__addon_enabled__", None)
    except Exception:
        enabled_marker = None
    if enabled_marker is False:
        return "DISABLED"

    for name in _PHASE_ATTRIBUTE_NAMES:
        try:
            value = getattr(module, name, None)
        except Exception:
            value = None
        if callable(value):
            # Poll calls only placement_allowed(); do not execute another Manager
            # callback merely to infer readiness.
            continue
        phase = _normalized(value)
        if phase in _READY_PHASES:
            return "READY"
        if phase in _NOT_READY_PHASES:
            return "NOT_READY"

    for name in _READY_ATTRIBUTE_NAMES:
        try:
            value = getattr(module, name, None)
        except Exception:
            value = None
        if isinstance(value, bool):
            return "READY" if value else "NOT_READY"

    if enabled_marker is True:
        return "READY"
    return "UNKNOWN"


def _public_generation_primitive(module: Any) -> tuple[str, Any]:
    """Read one primitive generation value without retaining Manager objects."""
    for name in _GENERATION_ATTRIBUTE_NAMES:
        try:
            value = getattr(module, name, None)
        except Exception:
            value = None
        if callable(value):
            continue
        if isinstance(value, (str, int, float, bool)):
            return name, value
    return "", None


def _authoritative_manager_decision(context: Any, editor_key: str, tool_key: str) -> bool | None:
    """Ask a fixed already-loaded Manager package for one exact current cell.

    ``None`` means that no verified authority was available.  Callers fail open
    only in that standalone/disabled/NOT_READY condition.
    """
    for module_name in _MANAGER_MODULE_NAMES:
        module = sys.modules.get(module_name)
        if module is None:
            continue

        state = _public_manager_state(module)
        if state in {"DISABLED", "NOT_READY"}:
            continue

        try:
            api = getattr(module, _MANAGER_API_NAME, None)
        except Exception:
            api = None
        if not callable(api):
            continue

        module_identity = id(module)
        api_identity = id(api)
        generation_before = _public_generation_primitive(module)
        try:
            raw = api(tool_key, context=context, editor_key=editor_key)
        except Exception:
            # A reload/migration boundary is not authoritative.  Do not reuse a
            # previous cell and do not fail closed for an unavailable Manager.
            continue

        module_after = sys.modules.get(module_name)
        if module_after is not module or id(module_after) != module_identity:
            continue
        try:
            api_after = getattr(module_after, _MANAGER_API_NAME, None)
        except Exception:
            api_after = None
        if not callable(api_after) or id(api_after) != api_identity:
            continue
        generation_after = _public_generation_primitive(module_after)
        if generation_before[0] and generation_after[0] and generation_before != generation_after:
            continue
        if isinstance(raw, bool):
            return raw
    return None


def placement_allowed(context: Any, editor_key: str, tool_key: str = TOOL_KEY) -> bool:
    """Resolve one valid physical/logical cell and apply Manager authority."""
    logical = _normalized(editor_key)
    tool = _normalized(tool_key)
    if logical not in LOGICAL_EDITOR_KEY_SET or tool != TOOL_KEY:
        return False
    area = getattr(context, "area", None) if context is not None else None
    if not physical_matches(area, logical):
        return False

    decision = _authoritative_manager_decision(context, logical, tool)
    # Manager absent, explicitly disabled, or genuinely NOT_READY: standalone
    # Smart Composite remains usable.  A verified READY boolean is exact.
    return True if decision is None else bool(decision)


def panel_allowed(context: Any, editor_key: str, tool_key: str = TOOL_KEY) -> bool:
    """Backward-compatible name for exact logical placement checks."""
    return placement_allowed(context, editor_key, tool_key)


def root_panel_allowed(context: Any, physical_space: str, tool_key: str = TOOL_KEY) -> bool:
    """Classify a physical native root and query its current logical cell."""
    expected_physical = _normalized(physical_space)
    if expected_physical not in PHYSICAL_SPACE_TYPES or context is None:
        return False
    area = getattr(context, "area", None)
    if physical_area_type(area) != expected_physical:
        return False
    logical = detect_editor_key(area)
    if logical is None or PHYSICAL_SPACE_BY_EDITOR.get(logical) != expected_physical:
        return False
    return placement_allowed(context, logical, tool_key)


def clear_cache() -> None:
    """Compatibility no-op: this bridge intentionally owns no decision cache."""
    return None
