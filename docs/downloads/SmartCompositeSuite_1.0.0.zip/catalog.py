# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Lazy Smart Composite catalog.

The 655 KiB / 601-row seed is not opened or parsed during add-on import,
registration, panel polling, or idle operation.  It is loaded only by the first
catalog/search/export/enum request and is fully releasable at unregister.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterator, Sequence
from dataclasses import asdict, dataclass
from functools import lru_cache
from importlib import resources
import json
from pathlib import Path
from typing import Generic, TypeVar


@dataclass(frozen=True)
class FeatureEntry:
    id: str
    category: str
    source: str
    feature: str
    tier: str
    summary_en: str
    summary_ja: str
    preset_id: str = ""
    family: str = ""
    implementation: str = ""
    reference_source: str = ""
    reference_feature: str = ""
    reference_family: str = ""
    reference_implementation: str = ""


_FEATURES_CACHE: tuple[FeatureEntry, ...] | None = None
_CATEGORIES_CACHE: tuple[str, ...] | None = None
_SOURCES_CACHE: tuple[str, ...] | None = None
_SEARCH_HAYSTACKS_CACHE: tuple[str, ...] | None = None
_PRESET_IDS_CACHE: tuple[str, ...] | None = None
_LOAD_COUNT = 0

# Small immutable index embedded at build time. Enum callbacks use these tuples
# without opening the 655 KiB catalog from panel draw/registration paths.
_STATIC_CATEGORIES: tuple[str, ...] = ('3D / Depth', 'AI / Bridge', 'AI / ML', 'AOV / Channel', 'Blur', 'Blur / Focus', 'Blur / Motion', 'Color', 'Color / Grade', 'Color / Look', 'Composite', 'Depth / 3D', 'Depth / Geometry', 'Distort / Stylize', 'Distortion / Stylize', 'Key / Matte', 'Lens', 'Lens / Light', 'Light / Glow / Flare', 'Light / Lens', 'Matte', 'Matte / Key', 'Motion / Temporal', 'Pipeline', 'Pipeline / Delivery', 'Precision', 'Precision / QC', 'Restoration', 'Temporal', 'Time / Retiming', 'UI / Operation', 'UI / Workflow', 'Utility')
_STATIC_SOURCES: tuple[str, ...] = ('SCS ApertureFlow Engine', 'SCS Apex UX Engine', 'SCS ChromaForge Engine', 'SCS CleanRoom Engine', 'SCS DeliveryForge Engine', 'SCS DepthSpace Engine', 'SCS FidelityCore Engine', 'SCS GeometrySignal Engine', 'SCS InsightBridge Engine', 'SCS LayerForge Engine', 'SCS LensLab Engine', 'SCS MatteForge Engine', 'SCS MatteFusion Engine', 'SCS MotionGuard Engine', 'SCS Orchestrator Engine', 'SCS PerceptionMatch Engine', 'SCS PrecisionCore Engine', 'SCS PrismPass Engine', 'SCS ProfileRestore Engine', 'SCS RangeSculpt Engine', 'SCS SignalScope Engine', 'SCS SpectraLight Engine', 'SCS SurpassCore Engine', 'SCS TemporalForge Engine', 'SCS WarpField Engine', 'SCS_UIForge Engine')
_STATIC_PRESET_IDS: tuple[str, ...] = ('HEIGHT_TO_NORMAL_PROXY', 'APEX_COMMAND_WORKSPACE', 'AOV_DELTA_VERIFIER', 'DEEP_MATTE_FUSION_LAB', 'LENS_APERTURE_DESIGNER', 'DYNAMIC_RANGE_SCULPTOR', 'PERCEPTION_MATCH_ASSISTANT', 'ADAPTIVE_DENOISE_PROFILE_LAB', 'MOTION_FLOW_GUARD', 'GEOMETRY_SIGNAL_BRIDGE', 'DELIVERY_SANITY_CHECK', 'APEX_VISUAL_GUIDE_BOARD', 'SCS_ULTRA_LAUNCHPAD', 'PERCEPTUAL_FINISHING_HUB', 'AOV_INTEGRITY_MATRIX', 'ADAPTIVE_RESTORE_ENGINE', 'PHYSICAL_OPTICS_ENGINE', 'MATTE_MICROSURGERY_ENGINE', 'AOV_SHUFFLE_MATRIX', 'CRYPTOMATTE_EXTRACTOR', 'FILE_OUTPUT_PIPELINE', 'SMART_MERGE', 'MATTE_REFINER', 'CHROMA_KEY_STUDIO', 'AI_MASK_BRIDGE', 'ADVANCED_GLOW', 'EDGE_RAYS', 'LENS_FLARE_BUILDER', 'BOKEH_DEPTH_BLUR', 'VECTOR_MOTION_BLUR', 'COLOR_GRADE_PANEL', 'FILM_LOOK_BUILDER', 'COLOR_MATCH_LOOK', 'LUT_MANAGER', 'VIGNETTE_FINISH', 'DEBAND_DENOISE_RESTORE', 'BEAUTY_RETOUCH', 'SHARPEN_DETAIL', 'OPTICAL_DISTORT', 'HEAT_HAZE_DISTORT', 'GLITCH_STYLIZE', 'DEPTH_FOG_RELIGHT', 'NORMAL_RELIGHT', 'PARTICLE_LIGHTS', 'TIME_ECHO', 'SLAP_COMP', 'ASSET_SHELF_PREP', 'PRECISION_QC_SUITE', 'MATTE_EDGE_LAB', 'SPECTRAL_LIGHT_LAB', 'DEPTH_NORMALIZER', 'COLOR_WARPER_LAB', 'CLEANROOM_PLUS', 'SURPASS_MASTER_WORKSPACE', 'BUILD_MASTER_WORKSPACE', 'PRECISION_MASTER_WORKSPACE', 'PRECISION_QC_LAB', 'HDR_HIGHLIGHT_GUARD', 'SUBPIXEL_MATTE_LAB', 'OPTICAL_BLOOM_LAB', 'RESTORATION_LAB', 'DEPTH_VECTOR_AUDIT', 'PRECISION_OVERDRIVE_WORKSPACE', 'PRECISION_DIAGNOSTICS_HUB', 'SIGNAL_INTEGRITY_GUARD', 'UI_ICON_LAUNCHPAD', 'VISUAL_REFERENCE_BOARD')


def _data_file() -> Path:
    return Path(__file__).resolve().parent / "data" / "compatibility_catalog_seed.json"


def _read_data_text() -> str:
    path = _data_file()
    try:
        if path.exists():
            return path.read_text(encoding="utf-8")
    except Exception:
        pass
    try:
        package = __package__ or __name__.rpartition(".")[0] or "smart_composite_suite"
        return resources.files(package).joinpath("data", "compatibility_catalog_seed.json").read_text(encoding="utf-8")
    except Exception:
        return "[]"


def _load_features() -> tuple[FeatureEntry, ...]:
    global _FEATURES_CACHE, _CATEGORIES_CACHE, _SOURCES_CACHE
    global _SEARCH_HAYSTACKS_CACHE, _LOAD_COUNT
    if _FEATURES_CACHE is not None:
        return _FEATURES_CACHE
    try:
        raw = json.loads(_read_data_text())
    except Exception:
        raw = []
    rows: list[FeatureEntry] = []
    for item in raw if isinstance(raw, list) else ():
        if not isinstance(item, dict):
            continue
        rows.append(FeatureEntry(
            id=str(item.get("id", "")),
            category=str(item.get("category", "")),
            source=str(item.get("source", "")),
            feature=str(item.get("feature", "")),
            tier=str(item.get("tier", "")),
            summary_en=str(item.get("summary_en", "")),
            summary_ja=str(item.get("summary_ja", "")),
            preset_id=str(item.get("preset_id", "")),
            family=str(item.get("family", "")),
            implementation=str(item.get("implementation", "")),
            reference_source=str(item.get("reference_source", "")),
            reference_feature=str(item.get("reference_feature", "")),
            reference_family=str(item.get("reference_family", "")),
            reference_implementation=str(item.get("reference_implementation", "")),
        ))
    _FEATURES_CACHE = tuple(rows)
    _CATEGORIES_CACHE = tuple(sorted({entry.category for entry in rows if entry.category}))
    _SOURCES_CACHE = tuple(sorted({entry.source for entry in rows if entry.source}))
    _SEARCH_HAYSTACKS_CACHE = tuple(
        " ".join((
            entry.id, entry.category, entry.source, entry.family, entry.feature,
            entry.tier, entry.implementation, entry.preset_id, entry.summary_en,
            entry.summary_ja, entry.reference_source, entry.reference_feature,
            entry.reference_family, entry.reference_implementation,
        )).lower()
        for entry in rows
    )
    _LOAD_COUNT += 1
    return _FEATURES_CACHE


def _categories() -> tuple[str, ...]:
    return _STATIC_CATEGORIES


def _sources() -> tuple[str, ...]:
    return _STATIC_SOURCES


def _haystacks() -> tuple[str, ...]:
    _load_features()
    return _SEARCH_HAYSTACKS_CACHE or ()


T = TypeVar("T")


class _LazySequence(Sequence[T], Generic[T]):
    __slots__ = ("_loader",)

    def __init__(self, loader):
        self._loader = loader

    def __len__(self) -> int:
        return len(self._loader())

    def __getitem__(self, index):
        return self._loader()[index]

    def __iter__(self) -> Iterator[T]:
        return iter(self._loader())

    def __repr__(self) -> str:
        return repr(self._loader())


FEATURES: Sequence[FeatureEntry] = _LazySequence(_load_features)
CATEGORIES: Sequence[str] = _STATIC_CATEGORIES
SOURCES: Sequence[str] = _STATIC_SOURCES


def feature_count_by_category() -> dict[str, int]:
    return dict(Counter(entry.category for entry in _load_features()))


def feature_count_by_source() -> dict[str, int]:
    return dict(Counter(entry.source for entry in _load_features()))


def feature_count_by_reference_source() -> dict[str, int]:
    return dict(Counter(entry.reference_source for entry in _load_features() if entry.reference_source))


def feature_count_by_implementation() -> dict[str, int]:
    return dict(Counter(entry.implementation for entry in _load_features()))


def preset_ids() -> tuple[str, ...]:
    return _STATIC_PRESET_IDS


def is_loaded() -> bool:
    return _FEATURES_CACHE is not None


def ensure_loaded() -> bool:
    _load_features()
    return _FEATURES_CACHE is not None


@lru_cache(maxsize=128)
def find_preset(preset_id: str) -> tuple[FeatureEntry, ...]:
    key = str(preset_id or "").strip().upper()
    return tuple(entry for entry in _load_features() if entry.preset_id.upper() == key)


@lru_cache(maxsize=256)
def _search_features_cached(q: str, cat: str, src: str, limit_value: int) -> tuple[FeatureEntry, ...]:
    result: list[FeatureEntry] = []
    haystacks = _haystacks()
    for index, entry in enumerate(_load_features()):
        if cat not in {"", "ALL"} and entry.category != cat:
            continue
        if src not in {"", "ALL"} and entry.source != src:
            continue
        if q and q not in haystacks[index]:
            continue
        result.append(entry)
        if limit_value >= 0 and len(result) >= limit_value:
            break
    return tuple(result)


def search_features(query: str = "", category: str = "ALL", source: str = "ALL", limit: int | None = None) -> tuple[FeatureEntry, ...]:
    q = str(query or "").strip().lower()
    cat = str(category or "ALL").strip()
    src = str(source or "ALL").strip()
    try:
        limit_value = -1 if limit is None else max(0, int(limit))
    except Exception:
        limit_value = -1
    return _search_features_cached(q, cat, src, limit_value)


@lru_cache(maxsize=256)
def search_feature_count(query: str = "", category: str = "ALL", source: str = "ALL") -> int:
    q = str(query or "").strip().lower()
    cat = str(category or "ALL").strip()
    src = str(source or "ALL").strip()
    count = 0
    haystacks = _haystacks()
    for index, entry in enumerate(_load_features()):
        if cat not in {"", "ALL"} and entry.category != cat:
            continue
        if src not in {"", "ALL"} and entry.source != src:
            continue
        if q and q not in haystacks[index]:
            continue
        count += 1
    return count


def source_items(language: str = "EN"):
    lang = str(language or "EN").upper()
    all_label = "全エンジン" if lang.startswith("JA") else "All Engines"
    all_desc = "すべてのSCS独自エンジンを表示します。" if lang.startswith("JA") else "Show all SCS original engines."
    return tuple([("ALL", all_label, all_desc)] + [(source, source, source) for source in _sources()])


def feature_dicts() -> list[dict]:
    return [asdict(entry) for entry in _load_features()]


def export_dict() -> dict:
    features = _load_features()
    return {
        "addon": "Smart Composite Suite",
        "author": "JELararagi",
        "version": "1.0.0",
        "copyright": "Copyright (C) 2026 JELararagi. All Rights Reserved.",
        "feature_count": len(features),
        "categories": feature_count_by_category(),
        "scs_engines": feature_count_by_source(),
        "reference_sources": feature_count_by_reference_source(),
        "implementations": feature_count_by_implementation(),
        "preset_ids": list(preset_ids()),
        "features": feature_dicts(),
    }


def clear_cache() -> None:
    global _FEATURES_CACHE, _CATEGORIES_CACHE, _SOURCES_CACHE
    global _SEARCH_HAYSTACKS_CACHE, _PRESET_IDS_CACHE
    _FEATURES_CACHE = None
    _CATEGORIES_CACHE = None
    _SOURCES_CACHE = None
    _SEARCH_HAYSTACKS_CACHE = None
    _PRESET_IDS_CACHE = None
    find_preset.cache_clear()
    _search_features_cached.cache_clear()
    search_feature_count.cache_clear()


def cache_state() -> dict[str, int | bool]:
    return {
        "loaded": _FEATURES_CACHE is not None,
        "feature_count": len(_FEATURES_CACHE or ()),
        "load_count": _LOAD_COUNT,
    }
