# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Explicit bounded mutation transactions for Smart Composite operations.

Every scene/RNA mutation performed by an SCS operator is registered before it is
applied.  An exception, Esc, or ``CANCELLED`` path rolls changes back in reverse
order.  Nested feature helpers join the active operator transaction instead of
creating an independently committed inner transaction.
"""

from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator


_STACK: list["MutationTransaction"] = []
_MISSING = object()


def _copy_value(value: Any) -> Any:
    try:
        return deepcopy(value)
    except Exception:
        return value


@dataclass
class MutationTransaction:
    label: str
    undo_actions: list[Callable[[], None]] = field(default_factory=list)
    commit_actions: list[Callable[[], None]] = field(default_factory=list)
    _seen_attrs: set[tuple[int, str]] = field(default_factory=set)
    _seen_items: set[tuple[int, str]] = field(default_factory=set)
    _once_keys: set[str] = field(default_factory=set)
    committed: bool = False
    closed: bool = False

    def add_undo(self, callback: Callable[[], None]) -> None:
        if self.closed:
            raise RuntimeError("Cannot add rollback work to a closed transaction")
        self.undo_actions.append(callback)

    def add_commit(self, callback: Callable[[], None]) -> None:
        if self.closed:
            raise RuntimeError("Cannot add commit work to a closed transaction")
        self.commit_actions.append(callback)

    def mark_once(self, key: str) -> bool:
        token = str(key or "")
        if token in self._once_keys:
            return False
        self._once_keys.add(token)
        return True

    def record_attr(self, obj: Any, name: str) -> None:
        key = (id(obj), str(name))
        if key in self._seen_attrs:
            return
        self._seen_attrs.add(key)
        try:
            old = _copy_value(getattr(obj, name))
            existed = True
        except Exception:
            old = _MISSING
            existed = False

        def restore() -> None:
            try:
                if existed:
                    setattr(obj, name, old)
                else:
                    delattr(obj, name)
            except Exception:
                pass

        self.add_undo(restore)

    def set_attr(self, obj: Any, name: str, value: Any) -> bool:
        self.record_attr(obj, name)
        setattr(obj, name, value)
        return True

    def record_item(self, obj: Any, key_name: str) -> None:
        key = (id(obj), str(key_name))
        if key in self._seen_items:
            return
        self._seen_items.add(key)
        try:
            old = _copy_value(obj[key_name])
            existed = True
        except Exception:
            old = _MISSING
            existed = False

        def restore() -> None:
            try:
                if existed:
                    obj[key_name] = old
                else:
                    del obj[key_name]
            except Exception:
                pass

        self.add_undo(restore)

    def set_item(self, obj: Any, key_name: str, value: Any) -> bool:
        self.record_item(obj, key_name)
        obj[key_name] = value
        return True

    def commit(self) -> None:
        if self.closed:
            if self.committed:
                return
            raise RuntimeError("Cannot commit a rolled-back transaction")
        try:
            for callback in tuple(self.commit_actions):
                callback()
        except BaseException:
            self.rollback()
            raise
        self.committed = True
        self.closed = True
        self.undo_actions.clear()
        self.commit_actions.clear()
        self._once_keys.clear()

    def rollback(self) -> None:
        if self.closed:
            return
        for callback in reversed(tuple(self.undo_actions)):
            try:
                callback()
            except Exception:
                pass
        self.closed = True
        self.committed = False
        self.undo_actions.clear()
        self.commit_actions.clear()
        self._once_keys.clear()


def current() -> MutationTransaction | None:
    return _STACK[-1] if _STACK else None


@contextmanager
def mutation_transaction(label: str) -> Iterator[MutationTransaction]:
    transaction = MutationTransaction(str(label or "Smart Composite operation"))
    _STACK.append(transaction)
    try:
        yield transaction
        if not transaction.committed:
            transaction.rollback()
    except BaseException:
        transaction.rollback()
        raise
    finally:
        if _STACK and _STACK[-1] is transaction:
            _STACK.pop()
        else:
            try:
                _STACK.remove(transaction)
            except ValueError:
                pass


@contextmanager
def operation_transaction(label: str) -> Iterator[tuple[MutationTransaction, bool]]:
    """Join the active operation transaction, or own a new one.

    The yielded boolean is ``True`` only for the caller that created the outer
    transaction.  Only that caller may call :meth:`MutationTransaction.commit`.
    """
    parent = current()
    if parent is not None:
        yield parent, False
        return
    with mutation_transaction(label) as transaction:
        yield transaction, True


def set_attr(obj: Any, name: str, value: Any) -> bool:
    active = current()
    if active is not None:
        return active.set_attr(obj, name, value)
    setattr(obj, name, value)
    return True


def set_item(obj: Any, key_name: str, value: Any) -> bool:
    active = current()
    if active is not None:
        return active.set_item(obj, key_name, value)
    obj[key_name] = value
    return True


def record_collection_created(collection: Any, item: Any) -> None:
    """Register exact removal of one newly-created collection item."""
    active = current()
    if active is None:
        return

    def remove_created() -> None:
        try:
            collection.remove(item)
        except Exception:
            pass

    active.add_undo(remove_created)


def rollback_all() -> int:
    """Rollback and release every exact in-process SCS transaction.

    This is used only at disable/reload/exit boundaries. It never scans Blender
    data and holds no transaction/RNA references after returning.
    """
    transactions = tuple(_STACK)
    for active in reversed(transactions):
        try:
            active.rollback()
        except Exception:
            pass
    _STACK.clear()
    return len(transactions)
