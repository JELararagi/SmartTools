# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

from typing import Any

import bpy

from .node_utils import existing_compositor_tree, tree_summary
from .translation import t

_PASS_JA = {"z": "深度", "normal": "法線", "vector": "ベクトル", "mist": "ミスト"}

VERSION = "1.0.0"


def precision_mode(settings: Any = None) -> str:
    value = str(getattr(settings, "precision_mode", "FINAL") or "FINAL").upper()
    return value if value in {"PREVIEW", "BALANCED", "FINAL", "EXTREME", "SURPASS"} else "FINAL"


def artifact_guard(settings: Any = None) -> str:
    value = str(getattr(settings, "artifact_guard", "STRONG") or "STRONG").upper()
    return value if value in {"SAFE", "STRONG", "SURPASS"} else "STRONG"


def qc_density(settings: Any = None) -> str:
    value = str(getattr(settings, "qc_density", "DEEP") or "DEEP").upper()
    return value if value in {"LIGHT", "STANDARD", "DEEP", "EXHAUSTIVE"} else "DEEP"


def _safe_set(obj: Any, name: str, value: Any) -> bool:
    try:
        from .transaction import set_attr
        set_attr(obj, name, value)
        return True
    except Exception:
        return False


def _get(obj: Any, name: str, default: Any = None) -> Any:
    try:
        return getattr(obj, name, default)
    except Exception:
        return default


def apply_scene_precision(context=None, settings=None) -> dict[str, Any]:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    mode = precision_mode(settings)
    guard = artifact_guard(settings)
    changed: list[str] = []
    skipped: list[str] = []
    if scene is None:
        return {"profile": mode, "artifact_guard": guard, "changed": changed, "skipped": ["scene"]}
    try:
        if existing_compositor_tree(ctx) is not None:
            changed.append("scene.compositor_tree")
    except Exception as exc:
        skipped.append(f"scene.compositor_tree:{exc}")
    render = getattr(scene, "render", None)
    if render is not None:
        if _safe_set(render, "use_compositing", True):
            changed.append("render.use_compositing")
        image_settings = getattr(render, "image_settings", None)
        if image_settings is not None:
            color_depth = "32" if mode in {"FINAL", "EXTREME", "SURPASS"} else "16"
            for attr, value in (("media_type", "MULTI_LAYER_IMAGE"), ("file_format", "OPEN_EXR_MULTILAYER"), ("color_mode", "RGBA"), ("color_depth", color_depth), ("exr_codec", "ZIP")):
                if _safe_set(image_settings, attr, value):
                    changed.append(f"image_settings.{attr}")
                else:
                    skipped.append(f"image_settings.{attr}")
    view_settings = getattr(scene, "view_settings", None)
    if view_settings is not None:
        # Do not force a look; only set stable high-dynamic-range friendly exposure/gamma defaults where Blender allows it.
        for attr, value in (("exposure", 0.0), ("gamma", 1.0)):
            if _safe_set(view_settings, attr, value):
                changed.append(f"view_settings.{attr}")
            else:
                skipped.append(f"view_settings.{attr}")
    return {"profile": mode, "artifact_guard": guard, "changed": changed, "skipped": skipped}


def _enabled_passes(view_layer: Any) -> list[str]:
    pass_names: list[str] = []
    for attr in (
        "use_pass_z", "use_pass_mist", "use_pass_normal", "use_pass_vector",
        "use_pass_position", "use_pass_ambient_occlusion", "use_pass_shadow",
        "use_pass_cryptomatte_object", "use_pass_cryptomatte_material", "use_pass_cryptomatte_asset",
        "use_pass_diffuse_direct", "use_pass_diffuse_indirect", "use_pass_diffuse_color",
        "use_pass_glossy_direct", "use_pass_glossy_indirect", "use_pass_glossy_color",
        "use_pass_transmission_direct", "use_pass_transmission_indirect", "use_pass_transmission_color",
        "use_pass_emit", "use_pass_environment",
    ):
        try:
            if view_layer is not None and bool(getattr(view_layer, attr, False)):
                pass_names.append(attr.replace("use_pass_", ""))
        except Exception:
            pass
    return pass_names


def _image_settings(scene: Any) -> dict[str, Any]:
    render = getattr(scene, "render", None)
    image = getattr(render, "image_settings", None) if render is not None else None
    return {
        "file_format": _get(image, "file_format", ""),
        "color_mode": _get(image, "color_mode", ""),
        "color_depth": _get(image, "color_depth", ""),
        "exr_codec": _get(image, "exr_codec", ""),
    }


def _view_settings(scene: Any) -> dict[str, Any]:
    view = getattr(scene, "view_settings", None)
    return {
        "view_transform": _get(view, "view_transform", ""),
        "look": _get(view, "look", ""),
        "exposure": _get(view, "exposure", None),
        "gamma": _get(view, "gamma", None),
        "view_transform_note": "reported only; Smart Composite does not force a look transform",
    }


def _score(scene: Any, summary: dict[str, int], passes: list[str], image: dict[str, Any]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    if scene is not None:
        try:
            if getattr(scene, "compositing_node_group", None) is not None:
                score += 15
            elif bool(getattr(scene, "use_nodes", False)):
                score += 15
        except Exception:
            pass
    else:
        reasons.append(t("コンポジターのノードが無効です。", "Compositor nodes are disabled."))
    required = {"z", "normal", "vector", "mist"}
    present = required.intersection(set(passes))
    score += int(25 * (len(present) / max(1, len(required))))
    for missing in sorted(required.difference(set(passes))):
        reasons.append(t(f"レンダーパス「{_PASS_JA.get(missing, missing)}」がありません。", f"Render pass missing: {missing}."))
    if any(name.startswith("cryptomatte") for name in passes):
        score += 10
    else:
        reasons.append(t("クリプトマットのパスが無効です。オブジェクトや材質を分けるには、手作業のマスクかレンダーのやり直しが要ります。", "Cryptomatte passes are not enabled; object/material isolation will require manual masks or re-rendered passes."))
    if summary.get("output_nodes", 0) > 0:
        score += 10
    else:
        reasons.append(t("ビューアー・出力・ファイル出力のノードが見つかりません。", "No Viewer/Composite/File Output node was detected."))
    smart_nodes = int(summary.get("smart_nodes", 0) or 0)
    if smart_nodes >= 12:
        score += 15
    elif smart_nodes > 0:
        score += 8
    else:
        reasons.append(t("SCSのノードがありません。最終の確認の前に、作業台かQCツールセットを追加してください。", "No SCS nodes were detected; add a precision workbench or QC suite before final review."))
    if image.get("file_format") == "OPEN_EXR_MULTILAYER":
        score += 10
    else:
        reasons.append(t("出力形式がOpenEXRマルチレイヤーではありません。AOVの確認が限られます。", "Output format is not OpenEXR Multilayer; multilayer AOV review will be limited."))
    if str(image.get("color_depth")) == "32":
        score += 10
    else:
        reasons.append(t("出力の色深度が32ビットではありません。グロー・色調整・段差の緩和の余裕が減ることがあります。", "Output color depth is not 32-bit; HDR glow, grading, and debanding headroom may be reduced."))
    if image.get("color_mode") == "RGBA":
        score += 5
    else:
        reasons.append(t("出力のカラーモードがRGBAではありません。アルファの確認が不完全になることがあります。", "Output color mode is not RGBA; alpha review may be incomplete."))
    return min(100, score), reasons




def _always_on_feature_state(settings: Any = None) -> dict[str, bool]:
    try:
        from .persistent_features import feature_definitions
        return {
            feature.suite_property: bool(getattr(settings, feature.suite_property, feature.default)) if settings is not None else bool(feature.default)
            for feature in feature_definitions()
        }
    except Exception:
        return {}

def quality_report(context=None, settings=None) -> dict[str, Any]:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    view_layer = getattr(ctx, "view_layer", None)
    try:
        tree = existing_compositor_tree(ctx)
        summary = tree_summary(tree) if tree is not None else {"total_nodes": 0, "smart_nodes": 0, "output_nodes": 0, "frames": 0}
    except Exception:
        summary = {"total_nodes": 0, "smart_nodes": 0, "output_nodes": 0, "frames": 0}
    pass_names = _enabled_passes(view_layer)
    image = _image_settings(scene)
    view = _view_settings(scene)
    score, recommendations = _score(scene, summary, pass_names, image)
    if qc_density(settings) in {"DEEP", "EXHAUSTIVE"} and summary.get("smart_nodes", 0) < 20:
        recommendations.append(t("最終の確認には、精度QCツールセット、スペクトル光学ラボ、マット縁精度ラボ、深度正規化ラボ、CleanRoom Plus を追加してください。", "For a final check, add Precision QC Toolset, Spectral Light Lab, Matte Edge Lab, Depth Normalizer, and CleanRoom Plus."))
    try:
        from .catalog import feature_count_by_category, feature_count_by_source, feature_count_by_implementation
        coverage = {
            "categories": feature_count_by_category(),
            "scs_engines": feature_count_by_source(),
            "implementations": feature_count_by_implementation(),
        }
    except Exception:
        coverage = {}
    return {
        "addon": "Smart Composite Suite",
        "author": "JELararagi",
        "version": VERSION,
        "precision_mode": precision_mode(settings),
        "artifact_guard": artifact_guard(settings),
        "qc_density": qc_density(settings),
        "quality_score": score,
        "node_summary": summary,
        "enabled_passes": pass_names,
        "image_settings": image,
        "view_settings": view,
        "catalog_coverage": coverage,
        "recommendations": recommendations,
        "artifact_guard_strength": float(getattr(settings, "artifact_guard_strength", 0.78) or 0.78) if settings is not None else 0.78,
        "edge_protection": float(getattr(settings, "edge_protection", 0.72) or 0.72) if settings is not None else 0.72,
        "diagnostic_viewers": bool(getattr(settings, "create_diagnostic_viewers", True)) if settings is not None else True,
        "artifact_diagnostics": bool(getattr(settings, "artifact_diagnostics", True)) if settings is not None else True,
        "always_on_features": _always_on_feature_state(settings),
        "ui_settings": {
            "ui_launcher_style": getattr(settings, "ui_launcher_style", "HERO") if settings is not None else "HERO",
            "large_icon_scale": float(getattr(settings, "large_icon_scale", 6.5) or 6.5) if settings is not None else 6.5,
            "hero_icon_scale": float(getattr(settings, "hero_icon_scale", 7.5) or 7.5) if settings is not None else 7.5,
            "reference_preview_scale": float(getattr(settings, "reference_preview_scale", 5.4) or 5.4) if settings is not None else 5.4,
            "reference_columns": int(getattr(settings, "reference_columns", 1) or 1) if settings is not None else 1,
            "workflow_guidance_level": getattr(settings, "workflow_guidance_level", "GUIDED") if settings is not None else "GUIDED",
        },
    }
