# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

import re
import time

_JA_RE = re.compile(r"[ぁ-んァ-ヴー一-龠々]")
_REGISTERED = bool(globals().get("_REGISTERED", False))
_REGISTER_TOKEN = str(globals().get("_REGISTER_TOKEN", "") or "")
_REGISTER_GENERATION = int(globals().get("_REGISTER_GENERATION", 0) or 0)
_LOCALE_CACHE_VALUE = str(globals().get("_LOCALE_CACHE_VALUE", "") or "")
_LOCALE_CACHE_TIME = float(globals().get("_LOCALE_CACHE_TIME", 0.0) or 0.0)
_LOCALE_CACHE_TTL = 0.25


def blender_locale() -> str:
    global _LOCALE_CACHE_VALUE, _LOCALE_CACHE_TIME
    try:
        now = time.monotonic()
        if (now - _LOCALE_CACHE_TIME) <= _LOCALE_CACHE_TTL:
            return _LOCALE_CACHE_VALUE
    except Exception:
        now = 0.0
    try:
        import bpy  # type: ignore
        prefs = getattr(getattr(getattr(bpy, "context", None), "preferences", None), "view", None)
        language = str(getattr(prefs, "language", "") or "").strip()
        if language and language.upper() not in {"DEFAULT", "AUTO", "DEFAULT_AUTO"}:
            value = language
        else:
            value = str(getattr(bpy.app.translations, "locale", "") or "")
    except Exception:
        value = ""
    _LOCALE_CACHE_VALUE = value
    try:
        _LOCALE_CACHE_TIME = now or time.monotonic()
    except Exception:
        _LOCALE_CACHE_TIME = 0.0
    return value


def settings_language(settings=None) -> str:
    # Kept for compatibility with older internal calls. SCS no longer stores or
    # reads a suite-specific language setting; UI language always follows Blender.
    return "JA" if blender_locale().lower().startswith("ja") else "EN"


def locale_mode(settings=None) -> str:
    return "ja" if blender_locale().lower().startswith("ja") else "en"

def is_japanese(settings=None) -> bool:
    return locale_mode(settings) == "ja"


def _interface_translation_enabled() -> bool:
    try:
        import bpy  # type: ignore
        prefs = getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
        return bool(getattr(view, "use_translate_interface", True))
    except Exception:
        return True


def choose_text(en: str, ja: str, settings=None) -> str:
    en_text = str(en or "").strip()
    ja_text = str(ja or "").strip()
    if is_japanese(settings) and _interface_translation_enabled():
        return ja_text or en_text
    return en_text or ja_text


def t(ja: str, en: str, settings=None) -> str:
    return choose_text(en, ja, settings)


def contains_japanese(text: str) -> bool:
    return bool(_JA_RE.search(str(text or "")))


def tooltip(ja: str, en: str, *, usage_ja: str = "", usage_en: str = "", tip_ja: str = "", tip_en: str = "", settings=None) -> str:
    if is_japanese(settings):
        parts = [str(ja or "").strip(), str(usage_ja or "").strip(), str(tip_ja or "").strip()]
    else:
        parts = [str(en or "").strip(), str(usage_en or "").strip(), str(tip_en or "").strip()]
    return "\n".join(part for part in parts if part)


def _current_lifecycle_identity() -> tuple[str, int]:
    try:
        from . import registration
        token = str(registration.current_owner_token() or "")
        generation = int(registration.current_generation() or 0)
    except Exception:
        return "", 0
    if not token or token == "unregistered" or generation <= 0:
        return "", 0
    return token, generation


def registration_identity_valid() -> bool:
    token, generation = _current_lifecycle_identity()
    return bool(_REGISTERED and token == _REGISTER_TOKEN and generation == _REGISTER_GENERATION)


def register() -> bool:
    global _REGISTERED, _REGISTER_TOKEN, _REGISTER_GENERATION
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return False
    _REGISTERED = True
    _REGISTER_TOKEN = token
    _REGISTER_GENERATION = generation
    return registration_identity_valid()


def unregister() -> bool:
    global _REGISTERED, _REGISTER_TOKEN, _REGISTER_GENERATION
    global _LOCALE_CACHE_VALUE, _LOCALE_CACHE_TIME
    _REGISTERED = False
    _REGISTER_TOKEN = ""
    _REGISTER_GENERATION = 0
    _LOCALE_CACHE_VALUE = ""
    _LOCALE_CACHE_TIME = 0.0
    return True
