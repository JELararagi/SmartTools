# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_composite_suite'
USER_DATA_DIRNAME = 'user_data'
CONFIG_SETTINGS_DIRNAME = 'Smart_Composite_Suite'
CONFIG_SETTINGS_FILENAME = 'Smart_Composite_Suite.json'
LEGACY_N_PANEL_SETTINGS_FILENAME = 'n_panel_settings.json'
MUTABLE_SIDECAR_DIRNAME = 'sidecars'


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'



def blender_config_dir(create: bool = True) -> Path:
    """Return Blender's versioned user config directory.

    For Blender 5.1 on Windows this resolves to:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config
    """
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', path='', create=create)
            except TypeError:
                try:
                    value = user_resource('CONFIG', create=create)
                except Exception:
                    value = ''
            except Exception:
                value = ''
            if value:
                path = Path(value)
                try:
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                    return path
                except Exception:
                    pass
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def blender_config_file(filename: object = CONFIG_SETTINGS_FILENAME, *, create: bool = True) -> Path:
    clean = _clean_part(filename)
    if not clean:
        raise ValueError('blender_config_file requires a filename')
    path = blender_config_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def blender_config_addon_dir(create: bool = True) -> Path:
    """Return the Smart Composite settings folder inside Blender's config directory.

    For Blender 5.1 on Windows this resolves to:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Composite_Suite
    """
    path = blender_config_dir(create=create) / CONFIG_SETTINGS_DIRNAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except FileExistsError:
            # If an unexpected file blocks the folder name, keep the package usable
            # by removing only this add-on-owned zero-length placeholder file.
            try:
                if path.is_file() and path.stat().st_size == 0:
                    path.unlink()
                    path.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        except Exception:
            pass
    return path


def blender_config_addon_file(filename: object = CONFIG_SETTINGS_FILENAME, *, create: bool = True) -> Path:
    clean = _clean_part(filename)
    if not clean:
        raise ValueError('blender_config_addon_file requires a filename')
    path = blender_config_addon_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_composite_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Return the installed Extension root for read-only legacy discovery."""
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def mutable_settings_root(package: object | None = None, *, create: bool = True) -> Path:
    """Return the CONFIG-owned root for every automatically written sidecar."""
    pkg = package_id(package)
    root = blender_config_addon_dir(create=create) / MUTABLE_SIDECAR_DIRNAME
    if pkg != PACKAGE_ID:
        root = root / _clean_part(pkg)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def legacy_extension_user_data_dir(*parts: object) -> Path:
    """Return the old package-local data location without creating it."""
    path = extension_user_root(PACKAGE_ID, create=False) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    return path.joinpath(*clean) if clean else path


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = mutable_settings_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = mutable_settings_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root




def default_export_dir(create: bool = True) -> Path:
    """Return the default export directory below CONFIG/Smart_Composite_Suite."""
    return user_data_dir('exports', create=create)


def n_panel_settings_file(create: bool = True) -> Path:
    """Persistent N-panel settings JSON path in Blender's config/Smart_Composite_Suite directory."""
    target = blender_config_addon_file(CONFIG_SETTINGS_FILENAME, create=create)
    if not create:
        # Read/restore callers must never migrate or write as a side effect.
        return target
    for legacy in legacy_n_panel_settings_candidates(target):
        try:
            if legacy is not None and not target.exists():
                migrate_legacy_file(legacy, target, remove_legacy=False)
        except Exception:
            pass
    return target


def legacy_n_panel_settings_candidates(target: Path | None = None) -> tuple[Path, ...]:
    """Return read-only legacy candidates; discovery never mutates them."""
    canonical = target or blender_config_addon_file(CONFIG_SETTINGS_FILENAME, create=False)
    legacy_candidates: list[Path] = []
    # Previous public build path: config/Smart_Composite_Suite.json
    try:
        old_config_file = blender_config_file(CONFIG_SETTINGS_FILENAME, create=False)
        if old_config_file != canonical:
            legacy_candidates.append(old_config_file)
    except Exception:
        pass
    # Older extension-private path: extensions/user_default/.../settings/n_panel_settings.json
    try:
        legacy_candidates.append(legacy_extension_user_data_dir('settings', LEGACY_N_PANEL_SETTINGS_FILENAME))
    except Exception:
        pass
    return tuple(legacy_candidates)

def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def _fsync_directory(path: Path) -> None:
    try:
        fd = os.open(str(path), os.O_RDONLY)
    except Exception:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _unique_temp_path(target: Path) -> Path:
    return target.with_name(f".{target.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")


def _generation_backup_path(target: Path, generation: int) -> Path:
    return target.with_name(f"{target.name}.bak.{max(0, int(generation)):020d}")


def _candidate_generation(data: Any) -> int:
    try:
        if isinstance(data, dict):
            return max(0, int(data.get("generation", 0) or 0))
    except Exception:
        pass
    return 0


def _read_json_strict(path: Path, validator=None) -> Any:
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)
    if validator is not None and not bool(validator(data)):
        raise ValueError(f"JSON schema validation failed: {path}")
    return data


def json_backup_candidates(path: str | Path) -> tuple[Path, ...]:
    target = Path(path)
    try:
        items = tuple(sorted(target.parent.glob(target.name + ".bak.*"), reverse=True))
    except Exception:
        items = ()
    return items


def load_json_recovering(
    path: str | Path,
    *,
    validator=None,
    central_paths: Iterable[str | Path] = (),
    default: Any = None,
    repair_main: bool = False,
) -> tuple[Any, Path | None, int]:
    """Choose the highest-generation valid main/central/backup candidate.

    A corrupt main file never outranks a valid central mirror or generation
    backup.  Corrupt candidates are retained for diagnostics.
    """
    target = Path(path)
    candidates: list[Path] = [target]
    for item in central_paths:
        candidate = Path(item)
        if candidate not in candidates:
            candidates.append(candidate)
    candidates.extend(candidate for candidate in json_backup_candidates(target) if candidate not in candidates)
    valid: list[tuple[int, int, Path, Any]] = []
    for priority, candidate in enumerate(candidates):
        try:
            if not candidate.exists() or candidate.stat().st_size <= 0:
                continue
            data = _read_json_strict(candidate, validator)
            valid.append((_candidate_generation(data), -priority, candidate, data))
        except Exception:
            continue
    if not valid:
        return default, None, 0
    generation, _priority, source, data = max(valid, key=lambda row: (row[0], row[1]))
    if repair_main and source != target:
        try:
            atomic_write_json(
                target, data, validator=validator, generation=generation,
                make_backup=False, max_backups=3,
            )
        except Exception:
            pass
    return data, source, generation


def atomic_write_text(path: str | Path, text: str, *, encoding: str = "utf-8", readback_validator=None) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = _unique_temp_path(target)
    try:
        with temp.open("w", encoding=encoding, newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if readback_validator is not None:
            readback_validator(temp)
        os.replace(temp, target)
        _fsync_directory(target.parent)
        if readback_validator is not None:
            readback_validator(target)
    except Exception:
        try:
            temp.unlink()
        except OSError:
            pass
        raise


def atomic_write_json(
    path: str | Path,
    data: Any,
    *,
    indent: int = 2,
    ensure_ascii: bool = False,
    sort_keys: bool = False,
    validator=None,
    generation: int | None = None,
    make_backup: bool = True,
    max_backups: int = 3,
) -> Any:
    """Unique-temp, fsync, atomic-replace, strict readback JSON write.

    The previous *valid* main is copied to a generation-named backup before the
    replace. Failed validation or I/O raises and never reports success.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = data
    if generation is not None and isinstance(data, dict):
        payload = dict(data)
        payload["generation"] = max(0, int(generation))
    if validator is not None and not bool(validator(payload)):
        raise ValueError("JSON payload failed schema validation before write")
    text = json.dumps(payload, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str) + "\n"
    temp = _unique_temp_path(target)
    old_valid = None
    old_generation = 0
    if make_backup and target.exists():
        try:
            old_valid = _read_json_strict(target, validator)
            old_generation = _candidate_generation(old_valid)
        except Exception:
            old_valid = None
    try:
        with temp.open("w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        parsed_temp = _read_json_strict(temp, validator)
        if make_backup and old_valid is not None:
            backup = _generation_backup_path(target, old_generation)
            backup_temp = _unique_temp_path(backup)
            try:
                backup_text = json.dumps(old_valid, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str) + "\n"
                with backup_temp.open("w", encoding="utf-8", newline="") as handle:
                    handle.write(backup_text); handle.flush(); os.fsync(handle.fileno())
                _read_json_strict(backup_temp, validator)
                os.replace(backup_temp, backup)
            finally:
                try:
                    backup_temp.unlink()
                except OSError:
                    pass
        os.replace(temp, target)
        _fsync_directory(target.parent)
        parsed_main = _read_json_strict(target, validator)
        if parsed_main != parsed_temp:
            raise ValueError("JSON readback differs from validated temporary payload")
        backups = json_backup_candidates(target)
        for stale in backups[max(0, int(max_backups)):]:
            try:
                stale.unlink()
            except OSError:
                pass
        return parsed_main
    except Exception:
        try:
            temp.unlink()
        except OSError:
            pass
        raise

def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy one legacy file to CONFIG while retaining the source by default."""
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        package_local = False
        try:
            legacy.resolve(strict=False).relative_to(_package_root().resolve(strict=False))
            package_local = True
        except Exception:
            package_local = False
        if remove_legacy and not package_local:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
