# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

from .translation import tooltip


def build_tooltip(key: str, settings=None) -> str:
    data = TOOLTIP_TEXT.get(key, TOOLTIP_TEXT["generic"])
    return tooltip(settings=settings, **data)


TOOLTIP_TEXT = {
    "generic": dict(
        ja="Smart Composite の操作です。現在のコンポジターノードツリーに、非破壊で使えるノード構成または診断結果を追加します。",
        en="A Smart Composite operation. It adds a non-destructive node setup or diagnostic result to the current compositor node tree.",
        usage_ja="コンポジターを開いた状態で実行してください。既存ノードは既定では削除せず、Smart Composite専用のフレーム名で追加します。",
        usage_en="Run it with the Compositor open. Existing nodes are not removed by default; new nodes are added under Smart Composite frame labels.",
        tip_ja="結果が見えない場合は、シーンのノード使用が有効か、ビューアー／コンポジットへ接続されているかを確認してください。",
        tip_en="If the result is not visible, check that scene node usage is enabled and that the output is linked to Viewer or Composite.",
    ),
    "enable_compositor": dict(
        ja="現在のシーンでコンポジターを有効化し、ノードツリーが未作成の場合は基本ツリーを生成します。",
        en="Enables the compositor for the current scene and creates a basic node tree if it does not exist yet.",
        usage_ja="最初に押す安全な準備ボタンです。レンダーレイヤー、コンポジット、ビューアーが無い場合だけ補います。",
        usage_en="Use this as the safe first preparation button. It only adds Render Layers, Composite, and Viewer nodes when they are missing.",
        tip_ja="既存の合成ツリーを壊さないため、ノードの全削除やUI設定変更は行いません。",
        tip_en="It does not clear existing compositor nodes or change editor UI settings, so your existing node tree remains intact.",
    ),
    "build_workspace": dict(
        ja="AOV確認、カラー補正、グロー、深度ブラー、ビューアー／コンポジット出力までを含む総合コンポジット作業台を作成します。",
        en="Creates a complete compositor workbench containing AOV inspection, color correction, glow, depth blur, and Viewer/Composite outputs.",
        usage_ja="新規シーンやレンダー直後の標準テンプレートとして使用します。既存ノードの右側にまとまったフレームとして配置します。",
        usage_en="Use it as a standard template for a new scene or after rendering. It is placed as grouped frames to the right of existing nodes.",
        tip_ja="AOVやZパスを使うプリセットは、レンダーパス有効化ボタンと併用すると安定します。",
        tip_en="Presets using AOV or Z-depth are more reliable when used together with the Render Pass enable button.",
    ),
    "add_preset": dict(
        ja="選択したコンポジット機能を、Blender標準ノードで構成したSmartノードスタックとして追加します。",
        en="Adds the selected compositing function as a Smart node stack built from Blender's native compositor nodes.",
        usage_ja="「追加プリセット」で選び、「選択した効果を適用」を押します。追加したノードは枠でまとめられます。",
        usage_en="Choose one in Preset to Add, then press Apply Selected Effect. The added nodes are grouped inside a frame.",
        tip_ja="追加したノードは普通のノードなので、後から自由に調整できます。",
        tip_en="The added nodes are normal nodes, so they can be adjusted freely afterward.",
    ),
    "passes": dict(
        ja="現在のビューレイヤーで、Z、ミスト、法線、ベクトル、ディフューズ、光沢、放射、AO、クリプトマットなどの合成用パスを有効化します。",
        en="Enables compositor-friendly passes on the current View Layer, including Z, Mist, Normal, Vector, Diffuse, Glossy, Emission, AO, and Cryptomatte where available.",
        usage_ja="レンダー前に実行します。既に有効なパスは維持し、存在しないプロパティは安全にスキップします。",
        usage_en="Run before rendering. Existing enabled passes are preserved, and unavailable properties are skipped safely.",
        tip_ja="EEVEE／CyclesやBlenderバージョンで利用できるパス名が異なるため、最後に診断ボタンで確認してください。",
        tip_en="Available pass names vary by render engine and Blender version, so use the audit button afterward if needed.",
    ),
    "audit": dict(
        ja="コンポジター設定、ビューレイヤーパス、ノード数、Smart Compositeノード、出力ノードの有無を点検します。",
        en="Audits compositor settings, View Layer passes, node counts, Smart Composite nodes, and output node availability.",
        usage_ja="セットアップ後やレンダー前の確認に使います。要約は完了のメッセージに表示され、詳細は品質レポートとしてJSONへ書き出せます。",
        usage_en="Use it after setup or before rendering. A summary appears in the completion message, and detailed results can be exported as a JSON quality report.",
        tip_ja="不足項目がある場合は、コンポジターを有効化、レンダーパスを有効化の順に実行し、必要な診断ビューアーを持つプリセットまたは総合作業台を追加してください。",
        tip_en="When something is missing, run Enable Compositor and Enable Render Passes, then add a preset or master workspace containing the diagnostic viewers you need.",
    ),
    "export_manifest": dict(
        ja="参照ソフト・プラグイン機能の独自ツールカタログと現在のSmart Composite設定をJSONとして書き出します。",
        en="Exports the original tool catalog for reference applications/plugins and the current Smart Composite settings as JSON.",
        usage_ja="仕様確認、外部管理、次回開発のチェックリスト化に使います。出力先はNパネルの出力パスで指定できます。",
        usage_en="Use this for specification review, external tracking, or as a checklist for later development. The output path is controlled from the N-panel Output Path setting.",
        tip_ja="未指定時と初期値はBlender 5.1のCONFIG/Smart_Composite_Suite内にあるSCS専用exportsフォルダーです。手動で指定した場合のみ、そのフォルダーへ書き出します。",
        tip_en="When blank or left at the default, output goes to the dedicated SCS exports folder inside Blender 5.1 CONFIG/Smart_Composite_Suite. It writes elsewhere only when you manually choose another folder.",
    ),
    "save_preferences": dict(
        ja="Nパネルで設定したSmart Composite項目をBlender 5.1 config内のSmart_Composite_Suite/Smart_Composite_Suite.jsonへ保存し、Blender本体のプリファレンス保存も実行します。",
        en="Saves Smart Composite N-panel settings to Smart_Composite_Suite/Smart_Composite_Suite.json in Blender 5.1 config and also runs Blender's Save Preferences operation.",
        usage_ja="Nパネル状態保存が有効な時に、検索、カテゴリ、精度、出力パス、常時機能切り替えなどの現在値を確定保存します。保存を無効にしている間はJSONを書き換えません。",
        usage_en="When N-panel State Save is enabled, explicitly commits current values such as search, category, precision, output path, and resident toggles. It does not rewrite JSON while state save is OFF.",
        tip_ja="通常は各項目の変更イベントでも自動保存します。保存を無効にしている間はBlender本体のプリファレンス保存だけが実行され、SCS設定JSONは不変です。",
        tip_en="Settings normally autosave on each change event. While state save is OFF, only Blender preferences are saved and the SCS settings JSON remains unchanged.",
    ),
    "apply_precision": dict(
        ja="現在のシーンに、高精度コンポジット向けの安全な出力設定を明示的に適用します。",
        en="Explicitly applies safe output settings for high-precision compositing to the current scene.",
        usage_ja="コンポジターを有効化し、可能な場合はOpenEXRマルチレイヤー、RGBA、高ビット深度、ZIP圧縮を設定します。",
        usage_en="Enables compositing and, where available, sets OpenEXR multilayer, RGBA, high bit depth, and ZIP compression.",
        tip_ja="表示変換や既存ノードは勝手に変更しません。納品前の明示的な準備操作として使います。",
        tip_en="It does not silently alter display transforms or existing nodes. Use it as an explicit pre-delivery preparation step.",
    ),
    "quality_report": dict(
        ja="現在のノード数、SCSノード数、出力ノード、レンダーパス、精度モード、破綻抑制、EXR設定、品質スコアをJSONとして書き出します。",
        en="Exports current node counts, SCS node counts, output nodes, render passes, precision mode, artifact guard, EXR settings, and quality score as JSON.",
        usage_ja="ショットごとの設定漏れ確認、納品前レビュー、次回修正のチェックリスト化に使います。",
        usage_en="Use it to find missing per-shot setup, review before delivery, or create a checklist for later fixes.",
        tip_ja="不足しているZ／法線／ベクトルや出力ノードがあれば、レポートの推奨事項に表示されます。",
        tip_en="Missing Z/Normal/Vector or output nodes are listed in the report recommendations.",
    ),
    "clear_scs": dict(
        ja="Smart Compositeが作成したフレームとノードだけを削除します。通常の手作業ノードは削除対象にしません。",
        en="Deletes only frames and nodes created by Smart Composite. Manually-created normal nodes are not targeted.",
        usage_ja="同じプリセットを何度も試した後の整理に使います。削除対象はSCS識別ラベルを持つノードに限定されます。",
        usage_en="Use it to clean up repeated preset experiments. It only targets nodes carrying SCS identification labels.",
        tip_ja="完全なノードツリー初期化ではありません。安全性を優先しています。",
        tip_en="This is not a full node-tree reset. It prioritizes safety.",
    ),
}
