# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Non-invasive operation status bookkeeping.

No RNA methods or Blender global APIs are patched. Shared driver-namespace
state contains primitive data plus the exact lifecycle owner/generation only.
"""

from __future__ import annotations

from contextlib import contextmanager
import time
import uuid
from typing import Any

import bpy

_NAMESPACE_KEY = "_jelararagi_smart_composite_status_v4"


def _namespace() -> dict[str, Any] | None:
    try:
        namespace = bpy.app.driver_namespace
        return namespace if isinstance(namespace, dict) else None
    except Exception:
        return None


def _runtime_identity() -> tuple[str, int]:
    try:
        from . import registration
        return str(registration.current_owner_token()), int(registration.current_generation())
    except Exception:
        return "unregistered", 0


def _base(operator_id: str, token: str, state: str) -> dict[str, Any]:
    owner_token, generation = _runtime_identity()
    return {
        "schema": 4,
        "suite": "smart_composite_suite",
        "owner": "JELararagi",
        "owner_token": owner_token,
        "generation": generation,
        "operator": str(operator_id),
        "token": str(token),
        "state": str(state),
    }


def _write(payload: dict[str, Any]) -> None:
    namespace = _namespace()
    if namespace is not None:
        namespace[_NAMESPACE_KEY] = dict(payload)


def begin_operation(operator_id: str, label: str = "Smart Composite Suite") -> str:
    token = uuid.uuid4().hex
    payload = _base(operator_id, token, "RUNNING")
    payload.update({"label": str(label), "started_monotonic": float(time.monotonic())})
    _write(payload)
    return token


def finish_operation(token: str, operator_id: str, message: str = "") -> None:
    payload = _base(operator_id, token, "FINISHED")
    payload.update({"message": str(message or ""), "finished_monotonic": float(time.monotonic())})
    _write(payload)


def cancel_operation(token: str, operator_id: str, message: str = "") -> None:
    payload = _base(operator_id, token, "CANCELLED")
    payload.update({"message": str(message or ""), "finished_monotonic": float(time.monotonic())})
    _write(payload)


def fail_operation(token: str, operator_id: str, message: str = "") -> None:
    payload = _base(operator_id, token, "FAILED")
    payload.update({"message": str(message or ""), "finished_monotonic": float(time.monotonic())})
    _write(payload)


def clear_prefix(_prefix: str = "") -> None:
    namespace = _namespace()
    if namespace is None:
        return
    value = namespace.get(_NAMESPACE_KEY)
    if not isinstance(value, dict):
        return
    owner_token, generation = _runtime_identity()
    if str(value.get("owner_token", "")) == owner_token and int(value.get("generation", -1)) == generation:
        namespace.pop(_NAMESPACE_KEY, None)


# Compatibility surfaces retained for older integrations. They are inert
# and never wrap classes, callbacks, timers, draw handlers, or bpy.props.
@contextmanager
def capture_registration_callbacks(*_args, **_kwargs):
    yield


@contextmanager
def capture_runtime_resources(*_args, **_kwargs):
    yield


def instrument_loaded_package_operators(*_args, **_kwargs) -> int:
    return 0


def instrument_loaded_package_handlers(*_args, **_kwargs) -> int:
    return 0


def restore_package_handlers(*_args, **_kwargs) -> int:
    return 0
