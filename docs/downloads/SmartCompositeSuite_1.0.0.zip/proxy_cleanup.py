# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Generation-owned event-only cleanup controller.

No resource is selected by name, label, prefix, user count, disconnection, or a
legacy marker. Node/data cleanup delegates to the UUID/owner/file/session ledger
in :mod:`node_utils`. The optional load_post hook is owned and released by exact
callback identity plus the outer lifecycle token/generation.
"""

from __future__ import annotations

from typing import Any

import bpy

try:
    from bpy.app.handlers import persistent as _blender_persistent
except Exception:
    def _blender_persistent(fn):
        return fn

_REGISTERED = bool(globals().get("_REGISTERED", False))
_LOAD_CLEANUP_ENABLED = bool(globals().get("_LOAD_CLEANUP_ENABLED", False))
_REGISTER_TOKEN = str(globals().get("_REGISTER_TOKEN", "") or "")
_REGISTER_GENERATION = int(globals().get("_REGISTER_GENERATION", 0) or 0)
_HANDLER_RECORDS: list[dict[str, Any]] = (
    globals().get("_HANDLER_RECORDS")
    if isinstance(globals().get("_HANDLER_RECORDS"), list)
    else []
)
# Exact compatibility residue from an older load is recoverable without a handler-name
# scan because importlib.reload preserves these object references.
_LEGACY_HANDLER_CALLBACK = globals().get("_HANDLER_CALLBACK")
_LEGACY_HANDLER_OWNED = bool(globals().get("_HANDLER_OWNED", False))
_HANDLER_OWNED = False


def cleanup_scene_proxy_data(context=None) -> dict[str, int]:
    try:
        from .node_utils import cleanup_owned_orphans
        return cleanup_owned_orphans(context)
    except Exception:
        return {"node_groups": 0, "images": 0, "nodes": 0}


@_blender_persistent
def _scs_cleanup_load_post(_dummy=None):
    if _REGISTERED and _LOAD_CLEANUP_ENABLED:
        cleanup_scene_proxy_data()


_HANDLER_CALLBACK = _scs_cleanup_load_post


def _current_lifecycle_identity() -> tuple[str, int]:
    try:
        from . import registration
        token = str(registration.current_owner_token() or "")
        generation = int(registration.current_generation() or 0)
    except Exception:
        return "", 0
    if not token or token == "unregistered" or generation <= 0:
        return "", 0
    return token, generation


def _load_post_handlers():
    try:
        return bpy.app.handlers.load_post
    except Exception:
        return None


def _remove_exact_callback(callback) -> bool:
    handlers = _load_post_handlers()
    if callback is None:
        return True
    if handlers is None:
        return False
    while True:
        try:
            handlers.remove(callback)
        except ValueError:
            break
        except (RuntimeError, AttributeError):
            return False
    return not any(item is callback for item in handlers)


def _record_is_ours(record: object) -> bool:
    return bool(
        isinstance(record, dict)
        and str(record.get("owner", "")) == "JELararagi"
        and str(record.get("package", "")) == "smart_composite_suite"
        and record.get("callback") is not None
    )


def _remove_record(record: dict[str, Any]) -> bool:
    if not _remove_exact_callback(record.get("callback")):
        record["active"] = True
        return False
    record["active"] = False
    try:
        _HANDLER_RECORDS.remove(record)
    except ValueError:
        pass
    return True


def _release_legacy_exact() -> bool:
    global _LEGACY_HANDLER_OWNED
    if _LEGACY_HANDLER_OWNED and _LEGACY_HANDLER_CALLBACK is not None:
        if not _remove_exact_callback(_LEGACY_HANDLER_CALLBACK):
            return False
    _LEGACY_HANDLER_OWNED = False
    return True


def _release_stale_records(token: str, generation: int) -> bool:
    clean = True
    for record in tuple(_HANDLER_RECORDS):
        if not _record_is_ours(record):
            continue
        if str(record.get("token", "")) != token or int(record.get("generation", -1)) != generation:
            clean = _remove_record(record) and clean
    return clean


def _attach_exact_handler() -> bool:
    global _HANDLER_OWNED
    token, generation = _current_lifecycle_identity()
    handlers = _load_post_handlers()
    if not token or generation <= 0 or handlers is None:
        return False
    if not _release_legacy_exact() or not _release_stale_records(token, generation):
        return False
    current = [
        record for record in _HANDLER_RECORDS
        if _record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
        and record.get("callback") is _HANDLER_CALLBACK
    ]
    if not _remove_exact_callback(_HANDLER_CALLBACK):
        return False
    try:
        handlers.append(_HANDLER_CALLBACK)
    except Exception:
        _HANDLER_OWNED = False
        return False
    if current:
        keep = current[0]
        for duplicate in current[1:]:
            try:
                _HANDLER_RECORDS.remove(duplicate)
            except ValueError:
                pass
        keep["active"] = True
    else:
        _HANDLER_RECORDS.append({
            "owner": "JELararagi",
            "package": "smart_composite_suite",
            "token": token,
            "generation": generation,
            "callback": _HANDLER_CALLBACK,
            "active": True,
        })
    _HANDLER_OWNED = sum(1 for item in handlers if item is _HANDLER_CALLBACK) == 1
    return _HANDLER_OWNED


def _detach_exact_handler() -> bool:
    global _HANDLER_OWNED
    clean = True
    for record in reversed(tuple(_HANDLER_RECORDS)):
        if _record_is_ours(record):
            clean = _remove_record(record) and clean
    clean = _release_legacy_exact() and clean
    _HANDLER_OWNED = not clean
    return clean


def load_cleanup_enabled() -> bool:
    return bool(_REGISTERED and _LOAD_CLEANUP_ENABLED)


def set_load_cleanup_enabled(enabled: bool) -> bool:
    global _LOAD_CLEANUP_ENABLED
    _LOAD_CLEANUP_ENABLED = bool(enabled)
    if _REGISTERED and _LOAD_CLEANUP_ENABLED:
        if not _attach_exact_handler():
            _LOAD_CLEANUP_ENABLED = False
            return False
    else:
        if not _detach_exact_handler():
            return False
    return True


def register() -> bool:
    global _REGISTERED, _REGISTER_TOKEN, _REGISTER_GENERATION
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return False
    if registration_identity_valid():
        return True
    if not _detach_exact_handler():
        return False
    _REGISTER_TOKEN = token
    _REGISTER_GENERATION = generation
    _REGISTERED = True
    if _LOAD_CLEANUP_ENABLED and not _attach_exact_handler():
        _REGISTERED = False
        _REGISTER_TOKEN = ""
        _REGISTER_GENERATION = 0
        return False
    return registration_identity_valid()


def unregister() -> bool:
    global _REGISTERED, _LOAD_CLEANUP_ENABLED, _REGISTER_TOKEN, _REGISTER_GENERATION
    clean = _detach_exact_handler()
    _LOAD_CLEANUP_ENABLED = False
    _REGISTERED = False
    _REGISTER_TOKEN = ""
    _REGISTER_GENERATION = 0
    return clean


def registration_identity_valid() -> bool:
    token, generation = _current_lifecycle_identity()
    if not _REGISTERED or token != _REGISTER_TOKEN or generation != _REGISTER_GENERATION:
        return False
    handlers = _load_post_handlers()
    current = [
        record for record in _HANDLER_RECORDS
        if _record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
        and record.get("callback") is _HANDLER_CALLBACK
    ]
    if _LOAD_CLEANUP_ENABLED:
        return bool(
            _HANDLER_OWNED
            and handlers is not None
            and len(current) == 1
            and sum(1 for item in handlers if item is _HANDLER_CALLBACK) == 1
        )
    return not current and not _HANDLER_OWNED
