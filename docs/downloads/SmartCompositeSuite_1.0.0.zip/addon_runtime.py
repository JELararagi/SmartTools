# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Top-level runtime bridge.

Registration is event-driven.  Panel registration itself invalidates Blender's UI;
this module deliberately performs no window/screen/area scan and does not request
unconditional redraws during enable, disable, reload, or idle operation.
"""

from __future__ import annotations

_REGISTERED = bool(globals().get("_REGISTERED", False))


def _tag_sidebar_editors_redraw() -> None:
    """Compatibility no-op retained for callers from earlier builds."""
    return None


def _tag_node_editors_redraw() -> None:
    """Compatibility no-op retained for callers from earlier builds."""
    return None


def register() -> bool:
    global _REGISTERED
    from . import registration
    if registration.is_active():
        _REGISTERED = True
        return True
    acquired = bool(registration.register())
    _REGISTERED = acquired and registration.is_active()
    return _REGISTERED


def unregister() -> bool:
    global _REGISTERED
    from . import registration
    released = bool(registration.unregister())
    _REGISTERED = False
    try:
        from . import status_runtime
        status_runtime.clear_prefix("smart_composite_suite")
    except Exception:
        pass
    return released


def is_full_runtime_loaded() -> bool:
    try:
        from . import registration
        return bool(registration.is_active())
    except Exception:
        return False


def ensure_full_runtime_loaded() -> bool:
    return bool(is_full_runtime_loaded() or register())


def release_full_runtime() -> bool:
    return unregister() if is_full_runtime_loaded() else False
