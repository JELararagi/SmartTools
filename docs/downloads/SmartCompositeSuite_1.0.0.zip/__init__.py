# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Smart Composite Suite Blender Extension entry point."""

from __future__ import annotations

import importlib

__version__ = "1.0.0"

bl_info = {
    "name": 'Smart Composite',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Editor Sidebar > Smart Composite",
    "description": "Compositor node-suite launcher, audit tools, and persistent N-panel workflow settings.",
    "category": "Compositing",
    "support": "COMMUNITY",
    "license": "LicenseRef-JELararagi-Proprietary",
}

_REGISTERED = False


def _runtime_module():
    return importlib.import_module(f"{__package__ or __name__}.addon_runtime")


def register() -> None:
    global _REGISTERED
    runtime = _runtime_module()
    acquired = bool(runtime.register())
    _REGISTERED = acquired or bool(runtime.is_full_runtime_loaded())


def unregister() -> None:
    global _REGISTERED
    try:
        runtime = _runtime_module()
        runtime.unregister()
    finally:
        _REGISTERED = False


__all__ = ["bl_info", "register", "unregister"]

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
