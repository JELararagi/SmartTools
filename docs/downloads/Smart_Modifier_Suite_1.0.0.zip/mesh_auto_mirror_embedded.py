# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from __future__ import annotations 

import bmesh 
import bpy 
from .translation import choose_text 
from bpy .props import BoolProperty ,EnumProperty ,FloatProperty 
from bpy .types import Operator 
from mathutils import Vector 

from .import pseudo_properties 
from .core import ms_register_plugin ,ms_unregister_plugin 

_PLUGIN_ID ="mesh_auto_mirror_modifier"
_OPERATOR_ID ="smsm.mesh_auto_mirror_modifier"


def _axis_index (axis :str )->int :
    return {'X':0 ,'Y':1 ,'Z':2 }.get (str (axis or 'X').upper (),0 )


def _world_plane_normal (obj ,axis :str ,orientation :str )->Vector :
    sign =1.0 if str (orientation or 'POSITIVE').upper ()=='POSITIVE'else -1.0 
    local ={
    'X':Vector ((1.0 ,0.0 ,0.0 )),
    'Y':Vector ((0.0 ,1.0 ,0.0 )),
    'Z':Vector ((0.0 ,0.0 ,1.0 )),
    }.get (str (axis or 'X').upper (),Vector ((1.0 ,0.0 ,0.0 )))*sign 
    try :
        return (obj .matrix_world .to_3x3 ()@local ).normalized ()
    except Exception :
        return local 


def _restore_mode_safe (obj ,mode :str ):
    mode =str (mode or 'OBJECT').upper ()
    target ='EDIT'if mode in {'EDIT','EDIT_MESH'}else 'OBJECT'
    try :
        if bpy .context .object is not obj :
            bpy .context .view_layer .objects .active =obj 
        bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode =target )
    except Exception :
        pass 


class SMSM_OT_mesh_auto_mirror_modifier (Operator ):
    bl_idname =_OPERATOR_ID 
    bl_label ='Mesh Auto Mirror'
    bl_description =(
    "Bisect the active mesh on a chosen local axis, weld the center line, and add a Mirror modifier in one guided step. "
    "Use it from Smart Modifier > Modifier Stack > Add Modifier > User when you want fast symmetry setup without leaving the stack workflow."
    )
    bl_options ={'UNDO'}

    axis :EnumProperty (
    name ='Mirror Axis',
    items =(
    ('X','X','Mirror across the object local X axis.'),
    ('Y','Y','Mirror across the object local Y axis.'),
    ('Z','Z','Mirror across the object local Z axis.'),
    ),
    default ='X',
    description ='Choose which local axis becomes the symmetry plane.',
    )
    orientation :EnumProperty (
    name ='Keep Side',
    items =(
    ('POSITIVE','Positive','Keep the positive side of the chosen axis and mirror from it.'),
    ('NEGATIVE','Negative','Keep the negative side of the chosen axis and mirror from it.'),
    ),
    default ='POSITIVE',
    description ='Select which side of the axis remains after the cut.',
    )
    threshold :FloatProperty (
    name ='Bisect Threshold',
    default =0.001 ,
    min =0.0 ,
    soft_max =0.1 ,
    description ='Vertices close to the cut plane are treated as center-line vertices.',
    )
    toggle_edit :BoolProperty (
    name ='Stay in Edit Mode',
    default =False ,
    description ='Return to Edit Mode after creation so you can continue symmetry cleanup immediately.',
    )
    cut :BoolProperty (
    name ='Cut and Mirror',
    default =True ,
    description ='Delete one side and add a Mirror modifier. Disable it when you only want the bisect and center weld.',
    )
    clipping :BoolProperty (
    name ='Use Clipping',
    default =True ,
    description ='Prevent mirrored vertices from crossing the center plane while editing.',
    )
    show_on_cage :BoolProperty (
    name ='Editable On Cage',
    default =False ,
    description ='Allow cage editing through the generated Mirror modifier.',
    )
    apply_mirror :BoolProperty (
    name ='Apply Mirror',
    default =False ,
    description ='Apply the generated Mirror modifier immediately after creation.',
    )

    @classmethod 
    def poll (cls ,context ):
        obj =getattr (context ,'active_object',None )
        return bool (obj and obj .type =='MESH')

    def invoke (self ,context ,event ):
        try :
            return pseudo_properties .invoke_props_dialog_preferred_window (self ,context ,width =420 )
        except Exception :
            return context .window_manager .invoke_props_dialog (self ,width =420 )

    def draw (self ,context ):
        layout =self .layout 
        layout .use_property_split =True 
        layout .use_property_decorate =False 
        layout .prop (self ,'axis',expand =True )
        layout .prop (self ,'orientation')
        layout .prop (self ,'threshold')
        layout .prop (self ,'toggle_edit')
        layout .prop (self ,'cut')
        if self .cut :
            layout .prop (self ,'clipping')
            layout .prop (self ,'show_on_cage')
            layout .prop (self ,'apply_mirror')

    def execute (self ,context ):
        obj =getattr (context ,'active_object',None )
        if obj is None or obj .type !='MESH':
            self .report ({'ERROR'},choose_text ('Active mesh required','アクティブメッシュが必要です。'))
            return {'CANCELLED'}

        try :
            context .view_layer .objects .active =obj 
            obj .select_set (True )
        except Exception :
            pass 

        initial_mode =str (getattr (obj ,'mode','OBJECT')or 'OBJECT')
        try :
            if initial_mode not in {'EDIT','EDIT_MESH'}:
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
            bpy .ops .mesh .select_all ('EXEC_DEFAULT', False, action ='SELECT')
        except Exception as exc :
            self .report ({'ERROR'},choose_text (f'Could not enter Edit Mode: {exc }',f'編集モードへ入れませんでした: {exc }'))
            return {'CANCELLED'}

        try :
            bpy .ops .mesh .bisect ('EXEC_DEFAULT', False, 
            plane_co =obj .matrix_world .translation .copy (),
            plane_no =_world_plane_normal (obj ,self .axis ,self .orientation ),
            use_fill =False ,
            clear_inner =bool (self .cut ),
            clear_outer =False ,
            threshold =float (self .threshold ),
            )
        except Exception as exc :
            _restore_mode_safe (obj ,initial_mode )
            self .report ({'ERROR'},choose_text (f'Bisect failed: {exc }',f'切断に失敗しました: {exc }'))
            return {'CANCELLED'}

        try :
            bm =bmesh .from_edit_mesh (obj .data )
            axis_idx =_axis_index (self .axis )
            for vert in bm .verts :
                if vert .select :
                    vert .co [axis_idx ]=0.0 
            bmesh .update_edit_mesh (obj .data ,loop_triangles =False ,destructive =False )
        except Exception :
            pass 

        if self .cut :
            try :
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :
                pass 
            try :
                mod =obj .modifiers .new (name ='Auto Mirror',type ='MIRROR')
                mod .use_axis [0 ]=self .axis =='X'
                mod .use_axis [1 ]=self .axis =='Y'
                mod .use_axis [2 ]=self .axis =='Z'
                mod .use_clip =bool (self .clipping )
                mod .show_on_cage =bool (self .show_on_cage )
                if bool (self .apply_mirror ):
                    bpy .ops .object .modifier_apply ('EXEC_DEFAULT', False, modifier =mod .name )
            except Exception as exc :
                self .report ({'WARNING'},choose_text (f'Mirror setup was partial: {exc }',f'Mirror 設定の一部に失敗しました: {exc }'))

        final_mode ='EDIT'if (bool (self .toggle_edit )or initial_mode in {'EDIT','EDIT_MESH'})else initial_mode 
        _restore_mode_safe (obj ,final_mode )
        return {'FINISHED'}


def _draw_add_menu (layout ,context ):
    layout .operator (_OPERATOR_ID ,text ='Mesh Auto Mirror',icon ='MOD_MIRROR')


_CLASSES =(
SMSM_OT_mesh_auto_mirror_modifier ,
)


def register ():
    for cls in _CLASSES :
        try :
            bpy .utils .register_class (cls )
        except Exception :
            pass 
    try :
        ms_register_plugin (_PLUGIN_ID ,{
        'id':_PLUGIN_ID ,
        'label':'Mesh Auto Mirror',
        'operator_id':_OPERATOR_ID ,
        'icon':'MOD_MIRROR',
        'priority':107 ,
        'group':'precision_symmetry',
        'group_label':'Precision / Symmetry',
        'group_icon':'MOD_MIRROR',
        'group_priority':84 ,
        'description_en':'Bisect the active mesh, weld the cut to center, and add a Mirror modifier in one guided step.',
        'description_ja':'アクティブメッシュを切断して中央へ揃えた後、Mirror モディファイアを1手順で追加します。',
        'usage_en':'Use it from Smart Modifier > Modifier Stack > Add Modifier > User with an active mesh object.',
        'usage_ja':'アクティブメッシュを選んだ状態で Smart Modifier > モディファイアスタック > モディファイアを追加 > ユーザー から使います。',
        'stack_addable':True ,
        'modeling_side':False ,
        'draw_add_menu':_draw_add_menu ,
        })
    except Exception :
        pass 


def unregister ():
    try :
        ms_unregister_plugin (_PLUGIN_ID )
    except Exception :
        pass 
    for cls in reversed (_CLASSES ):
        try :
            bpy .utils .unregister_class (cls )
        except Exception :
            pass 
