# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import importlib
import os
from typing import Any

import bpy

_STATE_VERSION = 5
_SAVE_TIMER_ARMED = False
_APPLYING = False
_LAST_STATE_TEXT = ''
_PENDING_STATE_TEXT = ''
_INITIAL_RESTORE_DONE = False
_PENDING_INITIAL_PANEL_STATE: dict[str, Any] | None = None
_AUTO_SAVE_TIMER_ARMED = False
_DEFERRED_SAVE_RETRY_ARMED = False
_DEFERRED_SAVE_RETRY_COUNT = 0
_AUTO_SAVE_INTERVAL = 1.25
_SAVE_SUSPEND_COUNT = 0
_LAST_SCENE_POINTER = 0
_SCENE_RESTORE_PENDING = False
_PENDING_SCOPE_COLLECTION_NAME = ''

_WM_BOOL_PROPS = (
    'sms_runtime_core_state_persistence',
    'sms_runtime_stack_live_sync',
)


_SHIFT_DRAG_CLONE_SETTINGS = {
    'shift_drag_clone_use_shift',
    'shift_drag_clone_use_ctrl',
    'shift_drag_clone_use_alt',
    'shift_drag_clone_use_oskey',
    'shift_drag_clone_trigger_key',
    'shift_drag_clone_default_clone_type',
    'shift_drag_clone_default_copy_count',
    'shift_drag_clone_transform_source',
}

_WM_SETTINGS_PROPS = (
    'use_modifier_stack',
    'use_modifier_switcher',
    'use_edit_poly_modifier',
    'use_smart_lattice_modifier',
    'stack_order',
    'auto_disable_restore_mode',
    'auto_disable_force_enable_cage',
    'auto_disable_force_enable_editmode',
    'auto_disable_force_enable_viewport',
    'auto_disable_force_enable_render',
    'show_always_on_toggles',
    'ui_section_always_on',
    'ui_section_modifier_stack',
    'ui_section_modifier_switcher',
    'ui_section_settings',
    'ui_section_hub',
    'ui_section_precision',
    'ui_section_advanced',
    'ui_section_tool_catalog',
    # Integrated Drag Clone settings live in the N-panel Settings
    # section, so persist them with the same panel-state payload as well as the
    # top-level settings payload.
    'shift_drag_clone_use_shift',
    'shift_drag_clone_use_ctrl',
    'shift_drag_clone_use_alt',
    'shift_drag_clone_use_oskey',
    'shift_drag_clone_trigger_key',
    'shift_drag_clone_default_clone_type',
    'shift_drag_clone_default_copy_count',
    'shift_drag_clone_transform_source',
)

_SCENE_SIMPLE_PROPS = (
    'modswitch_manage_mode',
    'modswitch_mode',
    'modswitch_scope',
    'modswitch_visible_only',
    'modswitch_filter_targets',
    'modswitch_filter_objects',
    'modswitch_show_objects',
    'modswitch_show_stack_instances',
    'modswitch_selection_behavior',
    'modswitch_affect_on_cage',
    'modswitch_affect_editmode',
    'modswitch_affect_viewport',
    'modswitch_affect_render',
    'modswitch_affect_expanded',
    'modswitch_new_state_set_name',
    'modswitch_target_index',
    'modswitch_obj_index',
    'modswitch_state_set_index',
    'modswitch_refresh_mode',
    'modswitch_auto_refresh',
    'modswitch_refresh_interval',
    'modswitch_ui_show_modlist',
    'modswitch_ui_show_objlist',
    'modswitch_ui_show_statesets',
    'modswitch_ui_show_details',
    'modswitch_ui_show_settings',
)

_SCENE_POINTER_GROUPS = (
    'hub_props',
    'smsp_props',
    'smsa_props',
)

_OBJECT_SIMPLE_PROPS = (
    'ms_show_end_result',
    'ms_auto_disable_modifiers',
    'ms_show_properties',
)

# Only suite-owned Object controls are global preferences.  Native Object
# datablock values (Empty display, instance collection, viewport color, etc.)
# are already saved per object in the .blend.  Applying the active object's
# native fields globally on startup is both semantically wrong and can produce
# Blender errors such as assigning an instance collection to a mesh object.
_OBJECT_NPANEL_SETTING_PROPS = set(_OBJECT_SIMPLE_PROPS)

# Dynamic child foldout states are stored as WindowManager IDProperties by
# ui._ms_dynamic_section_storage_key().  They must be persisted alongside the
# fixed N-panel settings, otherwise child foldouts under modifier/data property
# groups reset after scene changes or Blender restart.
_WM_DYNAMIC_IDPROP_PREFIXES = (
    '_smart_modifier_suite_ui_section_',
)

_SKIP_IDENTIFIERS = {'rna_type'}
_SIMPLE_RNA_TYPES = {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}

_GENERIC_PROP_PREFIXES = (
    'ms_', 'sms_', 'smsm_', 'smart_modifier_', '_smart_modifier_suite_',
    'modswitch_', 'smsp_', 'smsa_', 'hub_', 'ui_',
)
_EXPLICIT_WM_SIMPLE_PROPS = set(_WM_BOOL_PROPS) | {
    'ms_target_mod',
    'ms_target_obj',
    'ms_move_up',
    'ms_move_down',
    'sms_show_end_result_keymap_id',
    'sms_instance_copy_keymap_id',
    'sms_instance_make_unique_keymap_id',
    'sms_shift_drag_clone_keymap_id',
}
_EXPLICIT_SCENE_SIMPLE_PROPS = set(_SCENE_SIMPLE_PROPS)


# Prefixes used by Smart Modifier Suite runtime/N-panel properties.  Fixed lists
# above remain for backwards compatibility, while these generic collectors catch
# newly added settings without requiring another persistence patch.  Built-in
# Blender properties are intentionally excluded unless they use an add-on prefix.
_ADDON_PROP_PREFIXES = (
    'sms_', 'ms_', 'modswitch_', 'hub_', 'smsp_', 'smsa_', 'ui_',
    'smart_modifier_', '_smart_modifier_suite_',
    'smsm_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_',
    'sf_', 'sfs_', 'sas_', 'scsmart_', 'scs_', 'sgn_',
)

_SKIP_GENERIC_PROP_NAMES = {
    'rna_type',
    # Live caches / generated list data.  These are rebuilt from scene contents
    # and should not be restored from the global JSON preference file.
    'modswitch_last_signature',
    'ms_instance_map',
    'ms_instance_map_items',
    # Edit Poly / Smart Lattice live sync are no longer N-panel toggles.
    # Never restore an old saved True, or it could not be switched off.
    'sms_runtime_edit_poly_live_sync',
    'sms_runtime_smart_lattice_live_sync',
}


def _settings_directory() -> str:
    try:
        from .storage import config_dir
        return str(config_dir(create=True))
    except Exception:
        try:
            return str(bpy.utils.user_resource('CONFIG', path='', create=True) or '')
        except Exception:
            return ''


def _state_path() -> str:
    try:
        from .storage import suite_config_path
        return str(suite_config_path(create=True))
    except Exception:
        base = _settings_directory()
        return os.path.join(base, 'Smart_Modifier_Suite', 'Smart_Modifier_Suite.json') if base else ''


def _suite_config_has_panel_state() -> bool:
    try:
        from .storage import read_suite_config
        payload = read_suite_config()
    except Exception:
        payload = None
    if not isinstance(payload, dict):
        return False
    panel_state = payload.get('panel_state')
    return isinstance(panel_state, dict) and bool(panel_state)


def _defer_initial_panel_write() -> bool:
    # Registration and lazy RNA setup can fire update callbacks before the
    # previous Smart_Modifier_Suite.json panel state has been restored.  Blocking
    # those first writes prevents saved scene/object settings from being replaced
    # by default values during Blender startup or extension enable.
    return (not bool(_INITIAL_RESTORE_DONE)) and _suite_config_has_panel_state()


def _panel_state_ready_for_apply(context=None, data: dict[str, Any] | None = None) -> bool:
    if not isinstance(data, dict):
        return True
    scene = _scene(context)
    wm = _window_manager(context)
    try:
        scene_keys = set()
        for section_name in ('scene', 'scene_auto'):
            section = data.get(section_name)
            if isinstance(section, dict):
                scene_keys.update(str(key) for key in section.keys())
        if scene_keys and scene is None:
            return False
        # Lazy integrated tools intentionally register some Scene RNA only when
        # their N-panel section is opened. Missing lazy properties must not
        # prevent already available core settings from being restored.
    except Exception:
        return False
    try:
        if isinstance(data.get('settings'), dict):
            if wm is None or getattr(wm, 'sms_settings_state', None) is None:
                return False
    except Exception:
        return False
    return True


def begin_registration() -> None:
    """Prime panel state and suspend every registration-time write."""
    global _PENDING_INITIAL_PANEL_STATE, _INITIAL_RESTORE_DONE
    _PENDING_INITIAL_PANEL_STATE = _read_json()
    _INITIAL_RESTORE_DONE = False
    push_save_suspension()


def end_registration(context=None) -> None:
    """Replay core values after registration and release the write barrier."""
    try:
        load_panel_state(context or getattr(bpy, 'context', None))
    finally:
        pop_save_suspension()
    try:
        if not bpy.app.timers.is_registered(_post_register_restore_once):
            bpy.app.timers.register(_post_register_restore_once, first_interval=0.0, persistent=False)
    except Exception:
        pass


def _post_register_restore_once():
    context = getattr(bpy, 'context', None)
    # end_registration already performs a synchronous canonical replay.  The
    # queued callback exists only for RNA that was not ready yet, or for a real
    # Scene/load boundary reached before the callback runs.  Reapplying the
    # same completed profile to the same Scene would overwrite legitimate user
    # edits made while persistence is OFF before a later ON snapshot.
    if (
        _INITIAL_RESTORE_DONE
        and _PENDING_INITIAL_PANEL_STATE is None
        and not _SCENE_RESTORE_PENDING
    ):
        try:
            scene = _scene(context)
            pointer = int(scene.as_pointer()) if scene is not None else 0
        except Exception:
            pointer = 0
        if _LAST_SCENE_POINTER and pointer == _LAST_SCENE_POINTER:
            return None
    try:
        load_panel_state(context)
    except Exception:
        pass
    return None


def _legacy_state_paths() -> list[str]:
    paths: list[str] = []
    try:
        from .storage import storage_dir
        base = storage_dir(create=False)
        if base is not None:
            paths.append(os.path.join(str(base), 'smart_modifier_suite_npanel_state.json'))
    except Exception:
        pass
    try:
        base = bpy.utils.user_resource('CONFIG', create=False) or ''
    except Exception:
        base = ''
    if base:
        paths.append(os.path.join(base, 'smart_modifier_suite_npanel_state.json'))
        paths.append(os.path.join(base, 'smart_modifier_suite', 'smart_modifier_suite_npanel_state.json'))
    return [p for p in paths if p]


def _legacy_state_path() -> str:
    paths = _legacy_state_paths()
    return paths[0] if paths else ''

def _read_json() -> dict[str, Any]:
    # Primary unified config file: <Blender config>/Smart_Modifier_Suite/Smart_Modifier_Suite.json
    try:
        from .storage import read_suite_config
        data = read_suite_config()
        if isinstance(data, dict):
            section = data.get('panel_state')
            if isinstance(section, dict):
                return section
            # Accept direct old state only if the file does not look like the
            # unified schema.
            if data and not any(key in data for key in ('settings', 'panel_state', 'feature_toggles', 'common_state')):
                return data
    except Exception:
        pass
    for path in _legacy_state_paths():
        try:
            if not path or not os.path.isfile(path):
                continue
            with open(path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                try:
                    _write_json(data)
                except Exception:
                    pass
                return data
        except Exception:
            continue
    return {}

def _state_to_text(data: dict[str, Any]) -> str:
    try:
        return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return ''


def _write_json(data: dict[str, Any]) -> bool:
    global _LAST_STATE_TEXT
    # Direct/fallback callers must pass the same authoritative gate as public
    # writers.  Missing imports or predicate errors fail closed.
    try:
        from .save_policy import should_write_config as _write_allowed
    except Exception:
        _write_allowed = globals().get('should_write_config')
    try:
        context = getattr(globals().get('bpy'), 'context', None)
        if not callable(_write_allowed) or not bool(_write_allowed(context, force=False)):
            return False
    except Exception:
        return False
    if not isinstance(data, dict):
        data = {}
    text = _state_to_text(data)
    try:
        from .storage import read_suite_config, write_suite_config
        payload = read_suite_config()
        if not isinstance(payload, dict):
            payload = {}
        payload.setdefault('version', _STATE_VERSION)
        payload.setdefault('addon_id', 'smart_modifier_suite')
        payload['panel_state'] = data
        ok = bool(write_suite_config(payload))
        if ok:
            _LAST_STATE_TEXT = text
        return ok
    except Exception:
        pass
    path = _state_path()
    if not path:
        return False
    try:
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        payload = {}
        if os.path.isfile(path):
            try:
                with open(path, 'r', encoding='utf-8') as handle:
                    payload = json.load(handle)
            except Exception:
                payload = {}
        if not isinstance(payload, dict):
            payload = {}
        payload.setdefault('version', _STATE_VERSION)
        payload.setdefault('addon_id', 'smart_modifier_suite')
        payload['panel_state'] = data
        from . import storage
        storage.atomic_write_json(path, payload, ensure_ascii=False, indent=2, sort_keys=True)
        _LAST_STATE_TEXT = text
        return True
    except Exception:
        return False

_JSON_UNSAFE = object()


def _json_safe_copy(value: Any) -> Any:
    """Return a detached JSON-safe value for scalar and RNA array settings."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        sequence = list(value)
    except Exception:
        return _JSON_UNSAFE
    if len(sequence) > 256:
        return _JSON_UNSAFE
    if not all(isinstance(item, (str, int, float, bool)) or item is None for item in sequence):
        return _JSON_UNSAFE
    return list(sequence)


def _value_is_json_safe(value: Any) -> bool:
    return _json_safe_copy(value) is not _JSON_UNSAFE


def _is_addon_prop_name(name: object) -> bool:
    text = str(name or '').strip()
    if not text:
        return False
    lower = text.lower()
    if lower in _SKIP_GENERIC_PROP_NAMES:
        return False
    return any(lower.startswith(prefix) for prefix in _ADDON_PROP_PREFIXES)


def _prop_has_skip_save(prop: object) -> bool:
    try:
        options = getattr(prop, 'options', set()) or set()
        return 'SKIP_SAVE' in options
    except Exception:
        return False


def _simple_rna_values(obj: object | None, *, addon_only: bool = True) -> dict[str, Any]:
    """Serialize simple RNA values from an add-on root/property group.

    This is deliberately conservative for WindowManager/Scene/Object roots: only
    add-on-prefixed properties are collected.  For known Smart Modifier property
    groups, callers can pass addon_only=False so every simple child setting is
    saved even when the child name itself has no prefix.
    """
    if obj is None:
        return {}
    result: dict[str, Any] = {}
    try:
        props = getattr(getattr(obj, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in _SKIP_IDENTIFIERS or ident in _SKIP_GENERIC_PROP_NAMES:
                continue
            if bool(getattr(prop, 'is_readonly', False)) or _prop_has_skip_save(prop):
                continue
            if str(getattr(prop, 'type', '') or '') not in _SIMPLE_RNA_TYPES:
                continue
            if addon_only and not _is_addon_prop_name(ident):
                continue
            value = getattr(obj, ident)
        except Exception:
            continue
        normalized = _json_safe_copy(value)
        if normalized is not _JSON_UNSAFE:
            result[ident] = normalized
    return result


def _apply_simple_rna_values(obj: object | None, values: dict[str, Any] | None, *, addon_only: bool = True) -> None:
    if obj is None or not isinstance(values, dict):
        return
    for ident, value in values.items():
        name = str(ident or '')
        if not name or name in _SKIP_IDENTIFIERS or name in _SKIP_GENERIC_PROP_NAMES:
            continue
        if addon_only and not _is_addon_prop_name(name):
            continue
        if not _value_is_json_safe(value):
            continue
        try:
            if hasattr(obj, name):
                setattr(obj, name, value)
        except Exception:
            pass


def _iter_addon_pointer_group_names(root: object | None) -> list[str]:
    """Return pointer-property names owned by this add-on on a root object."""
    if root is None:
        return []
    result: list[str] = []
    seen: set[str] = set()
    try:
        props = getattr(getattr(root, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in _SKIP_IDENTIFIERS or ident in seen:
                continue
            if str(getattr(prop, 'type', '') or '') != 'POINTER':
                continue
            if not _is_addon_prop_name(ident):
                continue
            value = getattr(root, ident, None)
            if value is None:
                continue
            module_name = str(getattr(type(value), '__module__', '') or '')
            # Prefer package-owned property groups, but keep prefix-named groups
            # even when Blender reports a generic RNA wrapper module.
            if module_name and ('smart_modifier_suite' in module_name or module_name.startswith(__package__ or '')):
                pass
            result.append(ident)
            seen.add(ident)
        except Exception:
            continue
    return result


def _simple_group_values(group: object | None) -> dict[str, Any]:
    return _simple_rna_values(group, addon_only=False)


def _apply_simple_group_values(group: object | None, values: dict[str, Any] | None) -> None:
    _apply_simple_rna_values(group, values, addon_only=False)


def _collection_items_clear(collection) -> None:
    if collection is None:
        return
    try:
        collection.clear()
        return
    except Exception:
        pass
    try:
        while len(collection):
            collection.remove(0)
    except Exception:
        pass


def _collection_pointer_name(scene: object | None) -> str:
    if scene is None:
        return ''
    try:
        collection = getattr(scene, 'modswitch_scope_collection', None)
    except Exception:
        collection = None
    try:
        resolved = str(getattr(collection, 'name', '') or '') if collection is not None else ''
    except Exception:
        resolved = ''
    # A saved Collection can be temporarily unavailable while Blender is still
    # on its startup scene and has not read the requested .blend datablocks.
    # Preserve that portable name through load_pre; otherwise the forced
    # boundary snapshot replaces the valid JSON pointer with null before
    # load_post gets a chance to resolve it.
    return resolved or str(_PENDING_SCOPE_COLLECTION_NAME or '')


def clear_pending_scope_collection_name() -> None:
    """Forget an unresolved saved pointer after an explicit user edit/clear."""
    global _PENDING_SCOPE_COLLECTION_NAME
    _PENDING_SCOPE_COLLECTION_NAME = ''


def _modswitch_pins_to_list(scene: object | None) -> list[dict[str, Any]]:
    if scene is None or not hasattr(scene, 'modswitch_pins'):
        return []
    result: list[dict[str, Any]] = []
    try:
        for item in getattr(scene, 'modswitch_pins'):
            key = str(getattr(item, 'key', '') or '')
            if key:
                result.append({'key': key})
    except Exception:
        pass
    return result


def _modswitch_state_sets_to_list(scene: object | None) -> list[dict[str, Any]]:
    if scene is None or not hasattr(scene, 'modswitch_state_sets'):
        return []
    sets: list[dict[str, Any]] = []
    try:
        for state_set in getattr(scene, 'modswitch_state_sets'):
            records: list[dict[str, Any]] = []
            try:
                source_records = getattr(state_set, 'records')
            except Exception:
                source_records = ()
            for record in source_records:
                item: dict[str, Any] = {}
                for name in (
                    'obj_name', 'mod_type', 'mod_name', 'ordinal',
                    'show_viewport', 'show_render', 'show_in_editmode',
                    'show_on_cage', 'show_expanded',
                ):
                    try:
                        value = getattr(record, name)
                    except Exception:
                        continue
                    if _value_is_json_safe(value):
                        item[name] = value
                if item:
                    records.append(item)
            sets.append({'name': str(getattr(state_set, 'name', '') or 'State'), 'records': records})
    except Exception:
        pass
    return sets


def _apply_modswitch_collections(scene: object | None, data: dict[str, Any]) -> None:
    global _PENDING_SCOPE_COLLECTION_NAME
    if scene is None or not isinstance(data, dict):
        return

    pointer_values = data.get('scene_pointers') if isinstance(data.get('scene_pointers'), dict) else {}
    pointer_value = pointer_values.get('modswitch_scope_collection')
    if isinstance(pointer_value, dict):
        pointer_type = str(pointer_value.get('__pointer__') or '')
        collection_name = (
            str(pointer_value.get('name') or '')
            if pointer_type in {'Collection', 'COLLECTION', 'collection'} else ''
        )
    else:
        # Backward-compatible read of v4.32.21 and earlier bare-name payloads.
        collection_name = str(pointer_value or '')
    _PENDING_SCOPE_COLLECTION_NAME = collection_name
    if collection_name and hasattr(scene, 'modswitch_scope_collection'):
        try:
            collection = bpy.data.collections.get(collection_name)
            if collection is not None:
                setattr(scene, 'modswitch_scope_collection', collection)
                _PENDING_SCOPE_COLLECTION_NAME = ''
        except Exception:
            pass

    try:
        version = int(data.get('version', 0) or 0)
    except Exception:
        version = 0
    collections = data.get('scene_collections') if isinstance(data.get('scene_collections'), dict) else None
    if collections is None:
        return

    apply_pins = version >= 2 or 'modswitch_pins' in collections
    pin_values = collections.get('modswitch_pins') if isinstance(collections.get('modswitch_pins'), list) else []
    if apply_pins and hasattr(scene, 'modswitch_pins'):
        try:
            pins = getattr(scene, 'modswitch_pins')
            _collection_items_clear(pins)
            seen: set[str] = set()
            for item in pin_values:
                if not isinstance(item, dict):
                    continue
                key = str(item.get('key') or '')
                if not key or key in seen:
                    continue
                seen.add(key)
                new_item = pins.add()
                new_item.key = key
        except Exception:
            pass

    apply_state_sets = version >= 2 or 'modswitch_state_sets' in collections
    state_values = collections.get('modswitch_state_sets') if isinstance(collections.get('modswitch_state_sets'), list) else []
    if apply_state_sets and hasattr(scene, 'modswitch_state_sets'):
        try:
            state_sets = getattr(scene, 'modswitch_state_sets')
            _collection_items_clear(state_sets)
            for item in state_values:
                if not isinstance(item, dict):
                    continue
                state_set = state_sets.add()
                state_set.name = str(item.get('name') or 'State')
                records = item.get('records') if isinstance(item.get('records'), list) else []
                for record_values in records:
                    if not isinstance(record_values, dict):
                        continue
                    record = state_set.records.add()
                    for name in (
                        'obj_name', 'mod_type', 'mod_name', 'ordinal',
                        'show_viewport', 'show_render', 'show_in_editmode',
                        'show_on_cage', 'show_expanded',
                    ):
                        if name not in record_values:
                            continue
                        try:
                            setattr(record, name, record_values.get(name))
                        except Exception:
                            pass
            if hasattr(scene, 'modswitch_state_set_index'):
                current = int(getattr(scene, 'modswitch_state_set_index', 0) or 0)
                maximum = max(0, len(state_sets) - 1)
                setattr(scene, 'modswitch_state_set_index', min(max(0, current), maximum))
        except Exception:
            pass


def _active_object(context=None):
    try:
        return getattr(context, 'active_object', None) if context is not None else getattr(bpy.context, 'active_object', None)
    except Exception:
        return None


def _object_state_to_dict(scene: object | None) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if scene is None:
        return result
    try:
        objects = list(getattr(scene, 'objects', ()) or ())
    except Exception:
        objects = []
    for obj in objects:
        try:
            obj_name = str(getattr(obj, 'name', '') or '')
        except Exception:
            obj_name = ''
        if not obj_name:
            continue
        values: dict[str, Any] = {}
        for name in _OBJECT_SIMPLE_PROPS:
            try:
                if hasattr(obj, name):
                    values[name] = bool(getattr(obj, name))
            except Exception:
                pass
        if values:
            result[obj_name] = values
    return result


def _object_defaults_to_dict(context=None) -> dict[str, Any]:
    obj = _active_object(context)
    values: dict[str, Any] = {}
    if obj is None:
        return values
    for name in _OBJECT_SIMPLE_PROPS:
        try:
            if hasattr(obj, name):
                values[name] = bool(getattr(obj, name))
        except Exception:
            pass
    return values


def _apply_object_values(obj, values: dict[str, Any] | None) -> None:
    if obj is None or not isinstance(values, dict):
        return
    for name in _OBJECT_SIMPLE_PROPS:
        if name not in values:
            continue
        try:
            if hasattr(obj, name):
                new_value = bool(values.get(name))
                if bool(getattr(obj, name)) != new_value:
                    setattr(obj, name, new_value)
        except Exception:
            pass


def _window_manager(context=None):
    try:
        return getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
    except Exception:
        return None


def _scene(context=None):
    """Return the scene selected by the active Blender Window.

    Context.scene can lag behind Window.scene at the exact message-bus boundary
    in background Blender, so it is only a fallback for windowless contexts.
    """
    try:
        ctx = context if context is not None else getattr(bpy, 'context', None)
        window = getattr(ctx, 'window', None) if ctx is not None else None
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
        return getattr(ctx, 'scene', None) if ctx is not None else None
    except Exception:
        return None


def _wm_dynamic_idprops_to_dict(wm: object | None) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if wm is None:
        return result
    try:
        keys = list(wm.keys()) if hasattr(wm, 'keys') else []
    except Exception:
        keys = []
    for key in keys:
        try:
            name = str(key or '')
            if not (any(name.startswith(prefix) for prefix in _WM_DYNAMIC_IDPROP_PREFIXES) or _is_addon_prop_name(name)):
                continue
            value = wm.get(name) if hasattr(wm, 'get') else None
            if _value_is_json_safe(value):
                result[name] = value
        except Exception:
            continue
    return result


def _apply_wm_dynamic_idprops(wm: object | None, values: dict[str, Any] | None) -> None:
    if wm is None or not isinstance(values, dict):
        return
    for key, value in values.items():
        try:
            name = str(key or '')
            if not (any(name.startswith(prefix) for prefix in _WM_DYNAMIC_IDPROP_PREFIXES) or _is_addon_prop_name(name)):
                continue
            if _value_is_json_safe(value):
                wm[name] = value
        except Exception:
            continue


def _addon_idprops_to_dict(owner: object | None) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if owner is None:
        return result
    try:
        keys = list(owner.keys()) if hasattr(owner, 'keys') else []
    except Exception:
        keys = []
    for key in keys:
        try:
            name = str(key or '')
            if not _is_addon_prop_name(name):
                continue
            value = owner.get(name) if hasattr(owner, 'get') else None
            if _value_is_json_safe(value):
                result[name] = value
        except Exception:
            continue
    return result


def _apply_addon_idprops(owner: object | None, values: dict[str, Any] | None) -> None:
    if owner is None or not isinstance(values, dict):
        return
    for key, value in values.items():
        try:
            name = str(key or '')
            if not _is_addon_prop_name(name) or not _value_is_json_safe(value):
                continue
            owner[name] = value
        except Exception:
            continue


def _prop_has_skip_save(prop: object) -> bool:
    try:
        if bool(getattr(prop, 'is_skip_save', False)):
            return True
    except Exception:
        pass
    try:
        options = getattr(prop, 'options', set()) or set()
        return 'SKIP_SAVE' in options
    except Exception:
        return False


def _generic_prop_relevant(name: str, *, explicit: set[str] | None = None) -> bool:
    text = str(name or '').strip()
    if not text or text in _SKIP_IDENTIFIERS or text in _SKIP_GENERIC_PROP_NAMES:
        return False
    if explicit and text in explicit:
        return True
    lower = text.lower()
    return any(lower.startswith(prefix) for prefix in _GENERIC_PROP_PREFIXES)


def _generic_simple_values(root: object | None, *, explicit: set[str] | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if root is None:
        return result
    try:
        props = getattr(getattr(root, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not _generic_prop_relevant(ident, explicit=explicit):
                continue
            if bool(getattr(prop, 'is_readonly', False)) or _prop_has_skip_save(prop):
                continue
            if str(getattr(prop, 'type', '') or '') not in _SIMPLE_RNA_TYPES:
                continue
            value = getattr(root, ident)
        except Exception:
            continue
        normalized = _json_safe_copy(value)
        if normalized is not _JSON_UNSAFE:
            result[ident] = normalized
    try:
        keys = list(root.keys()) if hasattr(root, 'keys') else []
    except Exception:
        keys = []
    for key in keys:
        try:
            ident = str(key or '')
            if not _generic_prop_relevant(ident, explicit=explicit):
                continue
            value = root.get(ident) if hasattr(root, 'get') else None
            normalized = _json_safe_copy(value)
            if normalized is not _JSON_UNSAFE:
                result[ident] = normalized
        except Exception:
            continue
    return result


def _apply_generic_simple_values(root: object | None, values: dict[str, Any] | None, *, explicit: set[str] | None = None) -> None:
    if root is None or not isinstance(values, dict):
        return
    for ident, value in values.items():
        name = str(ident or '')
        if not _generic_prop_relevant(name, explicit=explicit):
            continue
        if not _value_is_json_safe(value):
            continue
        try:
            if hasattr(root, name):
                current = getattr(root, name)
                if current != value:
                    setattr(root, name, value)
            elif hasattr(root, '__setitem__'):
                root[name] = value
        except Exception:
            pass


def _scene_pointer_group_names(scene: object | None) -> tuple[str, ...]:
    names = set(_SCENE_POINTER_GROUPS)
    if scene is None:
        return tuple(sorted(names))
    try:
        props = getattr(getattr(scene, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in _SKIP_IDENTIFIERS:
                continue
            if str(getattr(prop, 'type', '') or '') != 'POINTER':
                continue
            if _generic_prop_relevant(ident, explicit=set(_SCENE_POINTER_GROUPS)):
                # ID datablocks are selectors, not nested settings groups.
                # Serializing every property of a selected Collection created
                # hundreds of false preference keys and lost the pointer type.
                value = getattr(scene, ident, None)
                try:
                    if value is not None and isinstance(value, bpy.types.ID):
                        continue
                except Exception:
                    pass
                names.add(ident)
        except Exception:
            continue
    return tuple(sorted(names))


_SCENE_GROUP_MODULES = {
    'hub_props': 'hub',
    'smsp_props': 'precision_tools',
    'smsa_props': 'advanced_tools',
}


def _missing_scene_groups(scene: object | None, group_values: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for group_name in group_values:
        name = str(group_name or '')
        if not name:
            continue
        try:
            group = getattr(scene, name, None) if scene is not None else None
        except Exception:
            group = None
        if group is None:
            result.append(name)
    return result


def _materialize_saved_scene_groups(context, group_values: dict[str, Any]):
    """Synchronously expose every saved dynamic Scene group.

    Runtime's normal lazy-component entry point is preferred so its teardown
    inventory remains complete.  The exact module fallback handles a partially
    registered live session whose lazy-state marker survived while one Scene
    PointerProperty did not.
    """
    scene = _scene(context)
    missing = _missing_scene_groups(scene, group_values)
    if not missing:
        return scene, []
    try:
        from . import runtime as _runtime_module
        ensure = getattr(_runtime_module, '_ms_ensure_deferred_components', None)
        if callable(ensure):
            ensure(
                reason='canonical_scene_restore',
                include_optional=True,
                context=context or getattr(bpy, 'context', None),
            )
    except Exception:
        pass
    scene = _scene(context)
    missing = _missing_scene_groups(scene, group_values)
    for group_name in tuple(missing):
        module_suffix = _SCENE_GROUP_MODULES.get(group_name)
        if not module_suffix:
            continue
        try:
            module = importlib.import_module(f'.{module_suffix}', package=__package__)
            register = getattr(module, 'register', None)
            if callable(register):
                register()
        except Exception:
            pass
    scene = _scene(context)
    return scene, _missing_scene_groups(scene, group_values)


def collect_panel_state(context=None) -> dict[str, Any]:
    wm = _window_manager(context)
    scene = _scene(context)
    data: dict[str, Any] = {
        'version': _STATE_VERSION,
        'window_manager': {},
        'window_manager_auto': {},
        'window_manager_idprops': {},
        'settings': {},
        'scene': {},
        'scene_auto': {},
        'scene_groups': {},
        'scene_pointers': {},
        'scene_collections': {},
        'objects': {},
        'object_auto': {},
        'object_defaults': {},
        'object_defaults_auto': {},
    }
    if wm is not None:
        for name in _WM_BOOL_PROPS:
            try:
                if hasattr(wm, name):
                    data['window_manager'][name] = bool(getattr(wm, name))
            except Exception:
                pass
        wm_auto = _generic_simple_values(wm, explicit=_EXPLICIT_WM_SIMPLE_PROPS)
        if wm_auto:
            data['window_manager_auto'] = wm_auto
        try:
            settings = getattr(wm, 'sms_settings_state', None)
        except Exception:
            settings = None
        if settings is not None:
            try:
                for name, value in _simple_group_values(settings).items():
                    if _value_is_json_safe(value):
                        data['settings'][name] = value
            except Exception:
                pass
            for name in _WM_SETTINGS_PROPS:
                try:
                    if hasattr(settings, name):
                        value = getattr(settings, name)
                        if _value_is_json_safe(value):
                            data['settings'][name] = value
                except Exception:
                    pass
        dynamic_idprops = _wm_dynamic_idprops_to_dict(wm)
        if dynamic_idprops:
            data['window_manager_idprops'] = dynamic_idprops
    if scene is not None:
        for name in _SCENE_SIMPLE_PROPS:
            try:
                if hasattr(scene, name):
                    value = getattr(scene, name)
                    if _value_is_json_safe(value):
                        data['scene'][name] = value
            except Exception:
                pass
        scene_auto = _generic_simple_values(scene, explicit=_EXPLICIT_SCENE_SIMPLE_PROPS)
        if scene_auto:
            data['scene_auto'] = scene_auto
        for group_name in _scene_pointer_group_names(scene):
            try:
                group = getattr(scene, group_name, None)
            except Exception:
                group = None
            values = _simple_group_values(group)
            if values:
                data['scene_groups'][group_name] = values
        collection_name = _collection_pointer_name(scene)
        data['scene_pointers']['modswitch_scope_collection'] = (
            {'__pointer__': 'Collection', 'name': collection_name}
            if collection_name else None
        )
        pins = _modswitch_pins_to_list(scene)
        if pins:
            data['scene_collections']['modswitch_pins'] = pins
        state_sets = _modswitch_state_sets_to_list(scene)
        if state_sets:
            data['scene_collections']['modswitch_state_sets'] = state_sets
        object_values = _object_state_to_dict(scene)
        if object_values:
            data['objects'] = object_values
        # Object ID properties such as instance maps and modifier caches belong
        # to the .blend file. Persist only the explicit N-panel booleans here;
        # replaying scene metadata from a global JSON file corrupts newer files.
        object_auto_values = _object_state_to_dict(scene)
        if object_auto_values:
            data['object_auto'] = object_auto_values
    object_defaults = _object_defaults_to_dict(context)
    if object_defaults:
        data['object_defaults'] = object_defaults
    default_auto_values = _object_defaults_to_dict(context)
    if default_auto_values:
        data['object_defaults_auto'] = default_auto_values
    return data



def _canonical_settings_values() -> dict[str, Any]:
    try:
        from .storage import read_suite_config
        payload = read_suite_config()
    except Exception:
        payload = None
    if not isinstance(payload, dict):
        return {}
    section = payload.get('settings')
    return dict(section) if isinstance(section, dict) else {}


def apply_panel_state(context=None, data: dict[str, Any] | None = None) -> bool:
    global _LAST_SCENE_POINTER, _SCENE_RESTORE_PENDING
    global _APPLYING
    if data is None:
        data = _read_json()
    if not isinstance(data, dict):
        return False
    wm = _window_manager(context)
    scene = _scene(context)
    # Canonical replay can assign the saved OFF value to the persistence RNA.
    # That assignment invokes the normal user update callback, which opens the
    # one-write OFF transition exception.  Establish the stronger restore
    # barrier before lazy PointerProperty materialisation or any RNA assignment
    # so replay callbacks cannot consume that exception and rewrite the file.
    try:
        from . import save_policy
        save_policy.begin_scene_restore(context)
    except Exception:
        _SCENE_RESTORE_PENDING = True
        return False
    _APPLYING = True
    try:
        # Hub / Precision / Advanced use lazily registered Scene
        # PointerProperty groups. Materialise them inside the same barrier as
        # the following RNA replay. Any missing group, partial result, or
        # exception intentionally leaves the barrier closed for a later retry.
        group_values = data.get('scene_groups') if isinstance(data.get('scene_groups'), dict) else {}
        scene, missing_saved_groups = _materialize_saved_scene_groups(context, group_values)
        if missing_saved_groups:
            _SCENE_RESTORE_PENDING = True
            return False
        wm_values = data.get('window_manager') if isinstance(data.get('window_manager'), dict) else {}
        if wm is not None:
            for name in _WM_BOOL_PROPS:
                if name in wm_values:
                    try:
                        if hasattr(wm, name):
                            # Explicit saved values are authoritative. Fresh
                            # installs still use each RNA property's default.
                            setattr(wm, name, bool(wm_values.get(name)))
                    except Exception:
                        pass
            wm_auto_values = data.get('window_manager_auto') if isinstance(data.get('window_manager_auto'), dict) else {}
            _apply_generic_simple_values(wm, wm_auto_values, explicit=_EXPLICIT_WM_SIMPLE_PROPS)
            settings_values = data.get('settings') if isinstance(data.get('settings'), dict) else {}
            canonical_settings_values = _canonical_settings_values()
            try:
                settings = getattr(wm, 'sms_settings_state', None)
            except Exception:
                settings = None
            if settings is not None:
                for name in _WM_SETTINGS_PROPS:
                    # The canonical top-level settings payload is the source of truth
                    # for N-panel/drag-clone preferences.  Do not let stale
                    # panel_state.settings values from a previous startup overwrite
                    # the user's saved setting and immediately write the old default
                    # back through update callbacks.
                    if name in canonical_settings_values:
                        continue
                    if name in settings_values:
                        try:
                            setattr(settings, name, settings_values.get(name))
                        except Exception:
                            pass
                for name, value in settings_values.items():
                    if name in _WM_SETTINGS_PROPS or name in canonical_settings_values:
                        continue
                    if not _value_is_json_safe(value):
                        continue
                    try:
                        if hasattr(settings, name):
                            setattr(settings, name, value)
                    except Exception:
                        pass
            dynamic_idprops = data.get('window_manager_idprops') if isinstance(data.get('window_manager_idprops'), dict) else {}
            _apply_wm_dynamic_idprops(wm, dynamic_idprops)
        scene_values = data.get('scene') if isinstance(data.get('scene'), dict) else {}
        if scene is not None:
            for name in _SCENE_SIMPLE_PROPS:
                if name not in scene_values:
                    continue
                try:
                    if hasattr(scene, name):
                        setattr(scene, name, scene_values.get(name))
                except Exception:
                    pass
            scene_auto_values = data.get('scene_auto') if isinstance(data.get('scene_auto'), dict) else {}
            _apply_generic_simple_values(scene, scene_auto_values, explicit=_EXPLICIT_SCENE_SIMPLE_PROPS)
            for group_name, values in group_values.items():
                try:
                    group = getattr(scene, str(group_name), None)
                except Exception:
                    group = None
                _apply_simple_group_values(group, values if isinstance(values, dict) else None)
            _apply_modswitch_collections(scene, data)
            object_values = data.get('objects') if isinstance(data.get('objects'), dict) else {}
            try:
                objects = list(getattr(scene, 'objects', ()) or ())
            except Exception:
                objects = []
            for obj in objects:
                try:
                    values = object_values.get(str(getattr(obj, 'name', '') or ''))
                except Exception:
                    values = None
                _apply_object_values(obj, values if isinstance(values, dict) else None)
            object_auto_values = data.get('object_auto') if isinstance(data.get('object_auto'), dict) else {}
            for obj in objects:
                try:
                    values = object_auto_values.get(str(getattr(obj, 'name', '') or ''))
                except Exception:
                    values = None
                _apply_object_values(obj, values if isinstance(values, dict) else None)
        default_values = data.get('object_defaults') if isinstance(data.get('object_defaults'), dict) else {}
        active = _active_object(context)
        if active is not None and default_values:
            named_values = data.get('objects') if isinstance(data.get('objects'), dict) else {}
            try:
                active_name = str(getattr(active, 'name', '') or '')
            except Exception:
                active_name = ''
            if active_name not in named_values:
                _apply_object_values(active, default_values)
        default_auto_values = data.get('object_defaults_auto') if isinstance(data.get('object_defaults_auto'), dict) else {}
        if active is not None and default_auto_values:
            named_values = data.get('object_auto') if isinstance(data.get('object_auto'), dict) else {}
            try:
                active_name = str(getattr(active, 'name', '') or '')
            except Exception:
                active_name = ''
            if active_name not in named_values:
                _apply_object_values(active, default_auto_values)
    finally:
        _APPLYING = False
    try:
        scene = _scene(context)
        _LAST_SCENE_POINTER = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        _LAST_SCENE_POINTER = 0
    try:
        save_policy.mark_scene_restored(context)
        if save_policy.scene_restore_pending(context):
            _SCENE_RESTORE_PENDING = True
            return False
    except Exception:
        _SCENE_RESTORE_PENDING = True
        return False
    _SCENE_RESTORE_PENDING = False
    return True



def push_save_suspension() -> None:
    global _SAVE_SUSPEND_COUNT
    _SAVE_SUSPEND_COUNT += 1


def pop_save_suspension() -> None:
    global _SAVE_SUSPEND_COUNT
    _SAVE_SUSPEND_COUNT = max(0, _SAVE_SUSPEND_COUNT - 1)


def saves_suspended() -> bool:
    return bool(_SAVE_SUSPEND_COUNT > 0)


def _finish_zero_idle_work_if_runtime_off(context=None) -> None:
    """Drain finite cleanup work and remove polling when all live modes are off.

    Ordinary N-panel edits can legitimately request an EndPreview cleanup or
    rebuild a Modifier Switcher list.  Those actions must complete, but they
    must not leave a timer behind when every control in ``Always-on Toggles``
    is disabled.  Run the finite cleanup callbacks synchronously and explicitly
    stop the switcher poller; button operators can still perform the same work
    on demand without installing an idle service.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None)
        scene = _scene(ctx)
        all_off = bool(
            wm is not None
            and not bool(getattr(wm, 'sms_runtime_stack_live_sync', False))
            and not bool(getattr(wm, 'sms_runtime_edit_poly_live_sync', False))
            and not bool(getattr(wm, 'sms_runtime_smart_lattice_live_sync', False))
            and (scene is None or not bool(getattr(scene, 'modswitch_auto_refresh', False)))
        )
        if not all_off:
            return
    except Exception:
        return

    try:
        from . import modswitcher
        ensure = getattr(modswitcher, 'ensure_autorefresh_timer_state', None)
        if callable(ensure):
            ensure(force_rebuild=False)
    except Exception:
        pass

    try:
        from . import core
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        for name in ('_ms_endpreview_cleanup_timer', '_ms_endpreview_global_purge_timer'):
            callback = getattr(core, name, None)
            if not callable(callback) or timers is None:
                continue
            try:
                registered = bool(timers.is_registered(callback))
            except Exception:
                registered = False
            if not registered:
                continue
            # Both callbacks normally finish in one pass.  The small bound also
            # handles a cleanup queue larger than one batch without introducing
            # a recurrent idle timer.
            for _index in range(32):
                try:
                    if callback() is None:
                        break
                except Exception:
                    break
            try:
                if timers.is_registered(callback):
                    timers.unregister(callback)
            except Exception:
                pass
    except Exception:
        pass


def _arm_deferred_save_retry() -> None:
    """Retry an early startup save for a bounded period only.

    The former persistent retry could remain registered forever when Blender
    never exposed a writable UI context.  Eight startup attempts are sufficient
    for normal file loading and guarantee that no idle polling remains.
    """
    global _DEFERRED_SAVE_RETRY_ARMED, _DEFERRED_SAVE_RETRY_COUNT
    if _DEFERRED_SAVE_RETRY_ARMED:
        return
    _DEFERRED_SAVE_RETRY_ARMED = True
    _DEFERRED_SAVE_RETRY_COUNT = 0

    def _retry():
        global _DEFERRED_SAVE_RETRY_ARMED, _DEFERRED_SAVE_RETRY_COUNT
        ctx = getattr(bpy, 'context', None)
        try:
            _DEFERRED_SAVE_RETRY_COUNT += 1
            if not bool(_INITIAL_RESTORE_DONE):
                try:
                    load_panel_state(ctx)
                except Exception:
                    pass
            if _defer_initial_panel_write():
                if _DEFERRED_SAVE_RETRY_COUNT < 8:
                    return 0.5
                _DEFERRED_SAVE_RETRY_ARMED = False
                _DEFERRED_SAVE_RETRY_COUNT = 0
                return None
            _DEFERRED_SAVE_RETRY_ARMED = False
            _DEFERRED_SAVE_RETRY_COUNT = 0
            try:
                from . import preferences as _preferences_module
                save_settings = getattr(_preferences_module, 'save_settings', None)
                if callable(save_settings):
                    save_settings(context=ctx, force=True)
            except Exception:
                pass
            try:
                save_panel_state(ctx, force=True)
            except Exception:
                pass
            try:
                from . import feature_toggle as _feature_toggle_module
                save_state = getattr(_feature_toggle_module, 'save_state', None)
                if callable(save_state):
                    save_state(context=ctx, force=True)
            except Exception:
                pass
            try:
                from . import common as _common_module
                save_common = getattr(_common_module, 'save_persistent_settings', None)
                if callable(save_common):
                    save_common(ctx, force=True)
            except Exception:
                pass
            return None
        except Exception:
            _DEFERRED_SAVE_RETRY_ARMED = False
            _DEFERRED_SAVE_RETRY_COUNT = 0
            return None

    try:
        bpy.app.timers.register(_retry, first_interval=0.5, persistent=False)
    except Exception:
        _DEFERRED_SAVE_RETRY_ARMED = False
        _DEFERRED_SAVE_RETRY_COUNT = 0


def _accept_current_panel_state_after_force_save() -> None:
    global _INITIAL_RESTORE_DONE, _PENDING_INITIAL_PANEL_STATE
    _INITIAL_RESTORE_DONE = True
    _PENDING_INITIAL_PANEL_STATE = None


def save_panel_state(context=None, *, force: bool = False) -> bool:
    global _SCENE_RESTORE_PENDING
    if _APPLYING:
        return False
    if saves_suspended():
        return False
    try:
        scene = _scene(context)
        pointer = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        pointer = 0
    if _LAST_SCENE_POINTER and pointer and pointer != _LAST_SCENE_POINTER:
        _SCENE_RESTORE_PENDING = True
        try:
            from . import save_policy
            save_policy.begin_scene_restore(context)
        except Exception:
            pass
        return False
    if _defer_initial_panel_write() and not force:
        _arm_deferred_save_retry()
        return False
    try:
        from .save_policy import should_write_config
        if not should_write_config(context, force=force):
            return False
    except Exception:
        return False
    ok = _write_json(collect_panel_state(context))
    if ok and force:
        _accept_current_panel_state_after_force_save()
    return ok


def load_panel_state(context=None) -> bool:
    global _LAST_STATE_TEXT, _INITIAL_RESTORE_DONE, _PENDING_INITIAL_PANEL_STATE
    data = _PENDING_INITIAL_PANEL_STATE if isinstance(_PENDING_INITIAL_PANEL_STATE, dict) else _read_json()
    _LAST_STATE_TEXT = _state_to_text(data)
    if not _panel_state_ready_for_apply(context, data):
        _PENDING_INITIAL_PANEL_STATE = data if isinstance(data, dict) else None
        _INITIAL_RESTORE_DONE = False
        return False
    result = apply_panel_state(context, data)
    _INITIAL_RESTORE_DONE = bool(result)
    _PENDING_INITIAL_PANEL_STATE = None if result else data
    return result


def restore_saved_state_save_off(context=None) -> bool:
    """Put the saved OFF switch back after a file load replaced the WindowManager.

    Only the switch is restored, and the restore barrier keeps the callback from
    writing this file's fresh values over the saved state.
    """
    from . import save_policy
    name = save_policy.STATE_SAVE_PROP
    wm = _window_manager(context)
    if wm is None or not bool(getattr(wm, name, False)):
        return False
    values = _read_json().get('window_manager')
    if not isinstance(values, dict) or values.get(name) is not False:
        return False
    save_policy.begin_scene_restore(context)
    try:
        setattr(wm, name, False)
    finally:
        save_policy.mark_scene_restored(context)
    return True


def _save_timer():
    global _SAVE_TIMER_ARMED, _PENDING_STATE_TEXT
    _SAVE_TIMER_ARMED = False
    _PENDING_STATE_TEXT = ''
    try:
        save_panel_state(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def request_save(context=None, *, immediate: bool = False, force: bool = False) -> None:
    global _SAVE_TIMER_ARMED, _PENDING_STATE_TEXT, _SCENE_RESTORE_PENDING
    # Resource cleanup is independent of whether persistence itself is gated.
    # Run it first so changing a setting while N-panel State Save is OFF cannot
    # accidentally leave a polling/cleanup timer resident.
    _finish_zero_idle_work_if_runtime_off(context)
    if _APPLYING:
        return
    if saves_suspended():
        return
    try:
        scene = _scene(context)
        pointer = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        pointer = 0
    if _LAST_SCENE_POINTER and pointer and pointer != _LAST_SCENE_POINTER:
        _SCENE_RESTORE_PENDING = True
        try:
            from . import save_policy
            save_policy.begin_scene_restore(context)
        except Exception:
            pass
        return
    if _defer_initial_panel_write() and not force:
        _arm_deferred_save_retry()
        return
    try:
        from .save_policy import should_write_config
        if not should_write_config(context, force=force):
            return
    except Exception:
        return
    try:
        current_state = collect_panel_state(context)
        current_text = _state_to_text(current_state)
    except Exception:
        current_state = {}
        current_text = ''
    if current_text and current_text == _LAST_STATE_TEXT:
        return
    # Every user-facing edit is committed synchronously when state saving is
    # enabled.  This is event-driven and leaves no debounce timer resident.
    try:
        ok = _write_json(current_state if current_state else collect_panel_state(context))
        if ok and force:
            _accept_current_panel_state_after_force_save()
    except Exception:
        pass
    _SAVE_TIMER_ARMED = False
    _PENDING_STATE_TEXT = ''


def _auto_save_timer():
    """Terminate a recurring autosave left by an older build."""
    global _AUTO_SAVE_TIMER_ARMED
    _AUTO_SAVE_TIMER_ARMED = False
    return None


def ensure_auto_save_timer() -> None:
    """Keep state persistence event-driven and remove legacy polling.

    Property update callbacks, explicit preference saving, and file/add-on
    lifecycle handlers already write the same unified state.
    """
    global _AUTO_SAVE_TIMER_ARMED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_auto_save_timer):
            timers.unregister(_auto_save_timer)
    except Exception:
        pass
    _AUTO_SAVE_TIMER_ARMED = False


def disable_auto_save_timer() -> None:
    global _AUTO_SAVE_TIMER_ARMED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_auto_save_timer):
            timers.unregister(_auto_save_timer)
    except Exception:
        pass
    _AUTO_SAVE_TIMER_ARMED = False


def is_applying() -> bool:
    return bool(_APPLYING)
