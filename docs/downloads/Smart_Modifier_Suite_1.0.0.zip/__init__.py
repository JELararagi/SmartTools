# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

# Add-on bootstrap: Smart Modifier
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Blender Extension policy: do not publish package aliases as top-level modules.
# The add-on is loaded as its extension package (for example
# bl_ext.user_default.smart_modifier_suite); all internal imports must stay
# package-relative.  Remove stale aliases left by older builds so Blender's
# extension policy scanner does not report them as top-level modules.
import sys as _sys
from pathlib import Path as _Path

_CURRENT_MODULE = _sys.modules.get(__name__)


def _drop_legacy_top_level_aliases() -> None:
    current_file = ''
    try:
        current_file = str(_Path(__file__).resolve()).casefold()
    except Exception:
        current_file = str(__file__ or '').casefold()
    for _legacy_name in ('smart_modifier_suite', 'Smart_Modifier_Suite'):
        _legacy_module = _sys.modules.get(_legacy_name)
        if _legacy_module is None:
            continue
        if _legacy_module is _CURRENT_MODULE:
            # Keep the module when it is intentionally imported under the same
            # legacy name outside Blender's extension loader.  Extension-policy
            # cleanup only removes aliases that point at the extension package.
            remove = (__name__ != _legacy_name)
        else:
            remove = False
            try:
                legacy_file = str(_Path(getattr(_legacy_module, '__file__', '') or '').resolve()).casefold()
                remove = bool(legacy_file and (legacy_file == current_file or 'smart_modifier_suite' in legacy_file))
            except Exception:
                legacy_file = str(getattr(_legacy_module, '__file__', '') or '').casefold()
                remove = bool(legacy_file and (legacy_file == current_file or 'smart_modifier_suite' in legacy_file))
        if remove:
            try:
                _sys.modules.pop(_legacy_name, None)
            except Exception:
                pass


_drop_legacy_top_level_aliases()


import importlib
import sys

import bpy


bl_info = {
    "name": 'Smart Modifier',
    "author": 'JELararagi',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "N-panel > Smart Modifier / Smart Tools Manager controlled editors",
    "description": "Smart Modifier is shown as a standard N-panel category named Smart Modifier in Smart Tools Manager controlled editors.",
    "category": 'Smart Modifier',
}

_RUNTIME_MODULE_NAME = f"{__package__}.runtime"
_PREFS_MODULE_NAME = f"{__package__}.preferences"


def _runtime_module():
    module = sys.modules.get(_RUNTIME_MODULE_NAME)
    if module is not None:
        return module
    return importlib.import_module('.runtime', __package__)


def _prefs_module():
    module = sys.modules.get(_PREFS_MODULE_NAME)
    if module is not None:
        return module
    return importlib.import_module('.preferences', __package__)


def _install_console_cleanup() -> None:
    try:
        from . import console_clean
        console_clean.install()
    except Exception:
        pass


def _sanitize_console_cleanup() -> None:
    try:
        from . import console_clean
        console_clean.sanitize_panel_draws()
    except Exception:
        pass


def register():
    """Register Smart Modifier as a normal 3D View N-panel add-on."""
    _install_console_cleanup()

    prefs = _prefs_module()
    try:
        prefs.register()
    except Exception:
        pass

    runtime = _runtime_module()
    try:
        cleanup = getattr(runtime, 'preflight_cleanup', None)
        if callable(cleanup):
            cleanup(package_name=__package__, module_name=__name__, module_file=__file__)
    except Exception:
        pass

    register_runtime = getattr(runtime, 'register_runtime', None)
    if callable(register_runtime):
        register_runtime(context=getattr(bpy, 'context', None))
    else:
        runtime.register()

    try:
        sync = getattr(runtime, 'sync_runtime_from_prefs', None)
        if callable(sync):
            sync(getattr(bpy, 'context', None))
    except Exception:
        pass

    _install_console_cleanup()


def unregister():
    runtime = sys.modules.get(_RUNTIME_MODULE_NAME)
    if runtime is not None:
        try:
            unregister_runtime = getattr(runtime, 'unregister_runtime', None)
            if callable(unregister_runtime):
                unregister_runtime()
            else:
                runtime.unregister()
        except Exception:
            pass

    prefs = sys.modules.get(_PREFS_MODULE_NAME)
    if prefs is not None:
        try:
            prefs.unregister()
        except Exception:
            pass

    if runtime is not None:
        try:
            finalize = getattr(runtime, 'finalize_package_teardown', None)
            if callable(finalize):
                finalize()
        except Exception:
            pass

    _sanitize_console_cleanup()

    # Final exact fallback after runtime Panels, menus, preferences, draw
    # handlers, and compatibility hooks have been detached.  runtime's
    # finalize_package_teardown() normally releases the collection first; this
    # idempotent call covers a partial teardown without issuing a second native
    # remove.
    try:
        from . import icons as _sms_icons
        _sms_icons.unregister()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')


def register():
    _modifier_persistent_state = None
    _modifier_save_policy = None
    try:
        from . import persistent_state as _modifier_persistent_state
        from . import save_policy as _modifier_save_policy
        _modifier_save_policy.begin_registration()
        _modifier_persistent_state.begin_registration()
    except Exception:
        _modifier_persistent_state = None
    try:
        from . import transform_guard as _SMART_TRANSFORM_GUARD
        # Register save/load handlers only. Do not start a transient transform
        # restore timer while the add-on is merely being installed/enabled; that
        # timer can immediately undo normal View3D transforms and make Blender
        # feel locked.
        _SMART_TRANSFORM_GUARD.register()
    except Exception:
        pass
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        if _SMART_COMMON is not None:
            _SMART_COMMON.register()
        try:
            from . import persistent_state as _SMART_PERSISTENT_STATE
            _SMART_PERSISTENT_STATE.load_panel_state(getattr(bpy, 'context', None))
            _SMART_PERSISTENT_STATE.ensure_auto_save_timer()
        except Exception:
            pass
    finally:
        if _modifier_persistent_state is not None:
            try:
                _modifier_persistent_state.end_registration(getattr(bpy, 'context', None))
            except Exception:
                pass
        if _modifier_save_policy is not None:
            try:
                _modifier_save_policy.end_registration(getattr(bpy, 'context', None))
            except Exception:
                pass
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass


def unregister():
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.unregister()
        except Exception:
            pass
    if callable(_SMART_ORIGINAL_UNREGISTER):
        _SMART_ORIGINAL_UNREGISTER()
    try:
        from . import transform_guard as _SMART_TRANSFORM_GUARD
        _SMART_TRANSFORM_GUARD.unregister()
    except Exception:
        pass
# --- Smart common extension patch END ---


# --- JELararagi shared single-slot status integration v2 ---
try:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = register
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = unregister
except Exception:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = None
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = None


def _jel_status_instrument_class_v2(cls):
    try:
        from . import status_runtime as _jel_status_runtime_v2
        return _jel_status_runtime_v2.instrument_operator_class(
            cls, 'smart_modifier_suite', 'Smart Modifier Suite'
        )
    except Exception:
        return cls


def register():
    if not callable(_JEL_STATUS_ORIGINAL_REGISTER_V2):
        return None
    try:
        import bpy as _jel_bpy_v2
        from . import status_runtime as _jel_status_runtime_v2
        _jel_original_register_class_v2 = _jel_bpy_v2.utils.register_class
    except Exception:
        _jel_bpy_v2 = None
        _jel_status_runtime_v2 = None
        _jel_original_register_class_v2 = None

    def _jel_register_class_v2(cls):
        _jel_status_instrument_class_v2(cls)
        return _jel_original_register_class_v2(cls)

    if _jel_bpy_v2 is not None and callable(_jel_original_register_class_v2):
        try:
            _jel_bpy_v2.utils.register_class = _jel_register_class_v2
        except Exception:
            pass
    try:
        if _jel_status_runtime_v2 is not None:
            with _jel_status_runtime_v2.capture_registration_callbacks('smart_modifier_suite', 'Smart Modifier Suite'):
                result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
        else:
            result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
    finally:
        if _jel_bpy_v2 is not None and callable(_jel_original_register_class_v2):
            try:
                _jel_bpy_v2.utils.register_class = _jel_original_register_class_v2
            except Exception:
                pass
    try:
        if _jel_status_runtime_v2 is None:
            from . import status_runtime as _jel_status_runtime_v2
        _jel_status_runtime_v2.instrument_loaded_package_operators(
            'smart_modifier_suite', 'smart_modifier_suite', 'Smart Modifier Suite'
        )
        _jel_status_runtime_v2.instrument_loaded_package_handlers(
            'smart_modifier_suite', 'smart_modifier_suite', 'Smart Modifier Suite'
        )
    except Exception:
        pass
    return result


_SMART_MODIFIER_OWNED_DRIVER_NAMESPACE_KEYS = (
    "_EP_ACTIVE_MODULE",
    "_EP_ENTER_EDIT_MULTI_MAP_V1",
    "_EP_ENTER_EDIT_MULTI_V1",
    "_EP_ENTER_EDIT_SINGLE_V1",
    "_EP_HELPERS_FOR_MAIN_V1",
    "_EP_REBAKE_STACK_UPTO",
    "_EP_RUNTIME_ENABLED_V1",
    "_EP_TOPO_POLL_RUNNING_V1",
    "_EP_TOUCHED_RESTORE_PENDING_V1",
    "_EP_TOUCHED_RESTORE_REASON_V1",
    "_MODSYS_CLEANUP_LOCK",
    "_MODSYS_CLEANUP_PENDING",
    "_MS_APPLY_STATE_SIG_V1",
    "_MS_ENDPREVIEW_CLEANUP_ARMED_V1",
    "_MS_ENDPREVIEW_CLEANUP_SET_V1",
    "_MS_ENDPREVIEW_ALLOWED_MAP_V1",
    "_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_V1",
    "_MS_ENDPREVIEW_GLOBAL_PURGE_REQ_V1",
    "_MS_LAST_APPLY_T_V1",
    "_MS_MODIFIER_INSTANCE_GROUP_CACHE_V1",
    "_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_V1",
    "_MS_MODIFIER_STACK_SYNC_LOCK",
    "_MS_REDRAW_LAST_V1",
    "_MS_REDRAW_PENDING_V1",
    "_MS_SEL_CACHE",
    "_MS_SEL_HASH",
    "_MS_SHAPE_PROXY_CLEANUP_LAST_T_V1",
    "_MS_SHAPE_PROXY_CLEANUP_REQ_V1",
    "_MS_SHAPE_PROXY_LAST_REPORT_V1",
    "_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL",
    "_SL_ACTIVE_MODULE",
    "_SL_RUNTIME_ENABLED_V1",
)


def _clear_owned_driver_namespace_state(status_runtime=None):
    """Release only Smart Modifier state at the outermost unregister boundary."""
    try:
        core_module = _sys.modules.get(f"{__package__}.core")
        for timer_name in ("_ms_endpreview_cleanup_timer", "_ms_endpreview_global_purge_timer"):
            cleanup_timer = getattr(core_module, timer_name, None)
            if cleanup_timer is not None and bpy.app.timers.is_registered(cleanup_timer):
                bpy.app.timers.unregister(cleanup_timer)
    except Exception:
        pass
    namespace = bpy.app.driver_namespace
    for key in _SMART_MODIFIER_OWNED_DRIVER_NAMESPACE_KEYS:
        try:
            namespace.pop(key, None)
        except Exception:
            pass

    # The status runtime is shared by every SmartTools add-on.  Remove this
    # suite's passive accounting, then release the shared container only when
    # no other suite or live status resource remains.
    shared_key = "JELARARAGI_SMARTTOOLS_STATUS_RUNTIME_V2"
    state = namespace.get(shared_key)
    if not isinstance(state, dict):
        return
    try:
        lock = state.get("lock")
        if lock is None:
            return
        with lock:
            for field in ("stats", "registration_depth"):
                mapping = state.get(field)
                if isinstance(mapping, dict):
                    mapping.pop("smart_modifier_suite", None)

            active_mappings = (
                "entries",
                "stats",
                "registration_depth",
                "timer_records",
                "draw_records",
                "handler_wrappers",
            )
            if any(bool(state.get(field)) for field in active_mappings):
                return
            if bool(state.get("resource_context_stack")):
                return
            active_flags = (
                "timer_registered",
                "resource_monitor_registered",
                "resource_monitor_running",
                "rna_boundary_handlers_installed",
            )
            if any(bool(state.get(field)) for field in active_flags):
                return
            if int(state.get("resource_capture_depth", 0) or 0) != 0:
                return
            if int(state.get("rna_boundary_depth", 0) or 0) != 0:
                return
        if namespace.get(shared_key) is state:
            namespace.pop(shared_key, None)
    except Exception:
        pass


def unregister():
    try:
        from . import status_runtime as _jel_status_runtime_v2
        # Restore the package's original handler function objects first so its
        # own unregister() routine can remove them by identity.
        _jel_status_runtime_v2.restore_package_handlers('smart_modifier_suite')
    except Exception:
        _jel_status_runtime_v2 = None
    try:
        if callable(_JEL_STATUS_ORIGINAL_UNREGISTER_V2):
            if _jel_status_runtime_v2 is not None:
                with _jel_status_runtime_v2.capture_runtime_resources('smart_modifier_suite', 'Smart Modifier Suite'):
                    return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()
            return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()
        return None
    finally:
        try:
            if _jel_status_runtime_v2 is None:
                from . import status_runtime as _jel_status_runtime_v2
            _jel_status_runtime_v2.clear_prefix('smart_modifier_suite')
        except Exception:
            pass
        _clear_owned_driver_namespace_state(_jel_status_runtime_v2)
# --- JELararagi shared single-slot status integration v2 --- END

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
