# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Central save policy for Smart Modifier N-panel state.

The WindowManager property ``sms_runtime_core_state_persistence`` is the one
authoritative real-time persistence switch shown as ``N-panel State Save``.
Forced lifecycle snapshots never bypass the user's switch.  Only the bounded
switch transition itself may commit while changing to OFF.
"""
from __future__ import annotations

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender-only runtime
    bpy = None  # type: ignore

STATE_SAVE_PROP = 'sms_runtime_core_state_persistence'
_REGISTRATION_GUARD = False
_SCENE_RESTORE_GUARD = False
_RESTORED_WINDOW_SCENE_POINTER = 0
_STATE_SAVE_TRANSITION_DEPTH = 0


def begin_state_save_transition() -> None:
    """Permit only the one commit that records the N-panel save switch itself."""
    global _STATE_SAVE_TRANSITION_DEPTH
    _STATE_SAVE_TRANSITION_DEPTH += 1


def end_state_save_transition() -> None:
    global _STATE_SAVE_TRANSITION_DEPTH
    _STATE_SAVE_TRANSITION_DEPTH = max(0, _STATE_SAVE_TRANSITION_DEPTH - 1)


def _window_scene(context=None):
    """Return the Scene selected by the active Window, never a stale context.

    ``Context.scene`` can still refer to the previous Scene at the exact
    ``Window.scene`` message-bus boundary.  Persistence boundaries therefore
    use it only when Blender has no Window (for example a windowless unit
    harness).
    """
    try:
        ctx = context if context is not None else getattr(bpy, 'context', None)
        window = getattr(ctx, 'window', None) if ctx is not None else None
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
        return getattr(ctx, 'scene', None) if ctx is not None else None
    except Exception:
        return None


def _window_scene_pointer(context=None) -> int:
    try:
        scene = _window_scene(context)
        return int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        return 0


def begin_scene_restore(context=None) -> None:
    """Close the write barrier before replaying the canonical JSON profile."""
    del context
    global _SCENE_RESTORE_GUARD
    _SCENE_RESTORE_GUARD = True


def mark_scene_restored(context=None) -> None:
    """Release the boundary only after the complete canonical replay succeeds."""
    global _SCENE_RESTORE_GUARD, _RESTORED_WINDOW_SCENE_POINTER
    pointer = _window_scene_pointer(context)
    if not pointer:
        return
    _RESTORED_WINDOW_SCENE_POINTER = pointer
    _SCENE_RESTORE_GUARD = False


def scene_restore_pending(context=None) -> bool:
    """Detect a Window.scene boundary before any update callback can write.

    A newly selected Scene materialises PointerProperty groups with their class
    defaults.  Some of those assignments invoke forced lifecycle saves before
    the Window.scene subscriber runs.  Comparing the active Window pointer here
    makes *every* writer fail closed, including ``force=True`` writers, until
    ``mark_scene_restored`` confirms that the external profile was replayed.
    """
    global _SCENE_RESTORE_GUARD
    current = _window_scene_pointer(context)
    if (
        _RESTORED_WINDOW_SCENE_POINTER
        and current
        and current != _RESTORED_WINDOW_SCENE_POINTER
    ):
        _SCENE_RESTORE_GUARD = True
    return bool(_SCENE_RESTORE_GUARD)


def begin_registration() -> None:
    global _REGISTRATION_GUARD, _SCENE_RESTORE_GUARD
    _REGISTRATION_GUARD = True
    _SCENE_RESTORE_GUARD = True


def end_registration(context=None) -> None:
    del context
    global _REGISTRATION_GUARD
    _REGISTRATION_GUARD = False
    # Do not release the Scene barrier here.  Only the successful canonical
    # replay in persistent_state.apply_panel_state is allowed to do that.


def _window_manager(context=None):
    """Return the authoritative WindowManager that owns the save switch.

    Preference update callbacks can receive a fallback Context whose
    ``window_manager`` proxy does not expose newly registered RNA, or still
    exposes a stale value during startup replay.  Never let that proxy's
    absence fall through to the ON default.  Resolve Blender's live context
    and data-blocks first, and use the callback context only as a windowless
    test/runtime fallback.
    """
    candidates = []
    if bpy is not None:
        try:
            wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
            if wm is not None:
                candidates.append(wm)
        except Exception:
            pass
        try:
            candidates.extend(list(getattr(getattr(bpy, 'data', None), 'window_managers', ()) or ()))
        except Exception:
            pass
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else None
        if wm is not None:
            candidates.append(wm)
    except Exception:
        pass
    seen = set()
    for wm in candidates:
        key = id(wm)
        if key in seen:
            continue
        seen.add(key)
        try:
            getattr(wm, STATE_SAVE_PROP)
        except Exception:
            continue
        return wm
    return None


def n_panel_state_save_enabled(context=None, *, default: bool = False) -> bool:
    wm = _window_manager(context)
    if wm is None:
        return bool(default)
    try:
        if hasattr(wm, STATE_SAVE_PROP):
            return bool(getattr(wm, STATE_SAVE_PROP))
    except Exception:
        pass
    return bool(default)


def should_write_config(context=None, *, force: bool = False, default: bool = False) -> bool:
    if _REGISTRATION_GUARD:
        return False
    # A forced save is not permission to serialize fresh Scene defaults over
    # the canonical external profile.  The Window.scene/load boundary is the
    # stronger invariant and remains closed until canonical replay completes.
    if scene_restore_pending(context):
        return False
    if _STATE_SAVE_TRANSITION_DEPTH > 0:
        return True
    # ``force`` means synchronous/full snapshot, never permission to bypass the
    # user's OFF state.  Save-preferences, save_pre and unregister therefore
    # cannot write after the final OFF transition commit.
    del force
    return n_panel_state_save_enabled(context, default=default)
