# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from __future__ import annotations 

import json
import bpy 
from bpy .props import StringProperty 
from bpy .types import Operator 

from .plugin_catalog import PLUGIN_CATALOG ,build_bilingual_tooltip ,get_plugin_meta ,get_plugin_short_hint ,is_stack_addable_plugin ,iter_plugins_grouped 
from .translation import choose_text ,pgettext_iface ,ui_language 
from .context_checks import get_tool_runtime_status 
try:
    from .icons import icon_name_for_plugin as _sms_icon_for_plugin, operator as _sms_icon_operator, large_icon_button_row as _sms_large_icon_row
except Exception:
    def _sms_icon_for_plugin(plugin, fallback='modifier'): return fallback
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)
    def _sms_large_icon_row(layout, *, align=True, scale_y=1.08):
        row=layout.row(align=align)
        try: row.scale_y=scale_y
        except Exception: pass
        return row
from .utils import (
call_operator_safe ,
get_operator_callable ,
operator_available ,
)
from .core import (
_ms_plugins_dict ,
get_main_object,
ms_apply_auto_selection_to_new_modifiers,
ms_apply_state_post_action,
ms_capture_mode_bridge_state,
ms_collect_new_modifiers,
ms_enter_object_mode_bridge,
ms_get_selected_main_meshes,
ms_get_ui_active_id,
ms_promote_new_modifiers_to_instances,
ms_restore_mode_bridge,
ms_snapshot_modifier_names,
ms_resolve_modifier_add_targets,
ms_original_sources_for_stack_targets,
ms_begin_temporary_stack_target_selection,
ms_end_temporary_stack_target_selection,
ms_is_shape_mesh_proxy,
ms_is_shape_source_object,
ms_normalize_shape_proxy_visibility_selection,
ms_shape_proxy_names,
ms_discard_unused_shape_proxies,
_ms_modifier_set_object_instance_unique,
)


def _lazy_register_operator_module(operator_id: str, context=None) -> bool:
    op_id = str(operator_id or '').strip()
    if not op_id or '.' not in op_id:
        return False
    try:
        if op_id.startswith('sms.'):
            from . import hub as module
            register = getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsp.'):
            from . import precision_tools as module
            register = getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsa.'):
            from . import advanced_tools as module
            register = getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('ep.'):
            try:
                from . import runtime
                loader = getattr(runtime, '_ms_register_deferred_edit_poly', None)
                if callable(loader):
                    loader(context)
                    return True
            except Exception:
                pass
            from .subtools import edit_poly_modifier as module
            register = getattr(module, 'register_embedded', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smart_lattice.'):
            try:
                from . import runtime
                loader = getattr(runtime, '_ms_register_deferred_smart_lattice', None)
                if callable(loader):
                    loader(context)
                    return True
            except Exception:
                pass
            from .subtools import lattice_modifier as module
            register = getattr(module, 'register_embedded', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsm.reset_xform_modifier'):
            from .subtools import reset_xform_modifier as module
            register = getattr(module, 'register_embedded', None) or getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsm.unwrap_uvw_modifier') or op_id.startswith('smsm.unwrap_uvw_edit_modifier') or op_id.startswith('smsm.unwrap_uvw_restore_backup'):
            from .subtools import unwrap_uvw_modifier as module
            register = getattr(module, 'register_embedded', None) or getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsm.uvw_map_modifier') or op_id.startswith('smsm.uvw_map_edit_modifier') or op_id.startswith('smsm.uvw_map_restore_backup'):
            from .subtools import uvw_map_modifier as module
            register = getattr(module, 'register_embedded', None) or getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsm.max_'):
            from .subtools import max_modifier_library as module
            register = getattr(module, 'register_embedded', None) or getattr(module, 'register', None)
            if callable(register):
                register()
            return True
        if op_id.startswith('smsm.mesh_auto_mirror_modifier'):
            from . import mesh_auto_mirror_embedded as module
            register = getattr(module, 'register', None)
            if callable(register):
                register()
            return True
    except Exception:
        return False
    return False


_DEFERRED_OPERATOR_PREFIXES =(
'sms.',
'smsp.',
'smsa.',
'ep.',
'smart_lattice.',
'smsm.reset_xform_modifier',
'smsm.unwrap_uvw_modifier',
'smsm.unwrap_uvw_edit_modifier',
'smsm.unwrap_uvw_restore_backup',
'smsm.uvw_map_modifier',
'smsm.uvw_map_edit_modifier',
'smsm.uvw_map_restore_backup',
'smsm.max_',
'smsm.mesh_auto_mirror_modifier',
)


_USER_TOOL_DEFAULTS_PLUGIN_IDS = {
    'boolean_stack_modifier',
    'smart_cleanup_repair_tool',
    'pipe_modifier',
    'array_along_curve_modifier',
    'scatter_modifier',
    'conform_to_surface_tool',
    'floor_modifier',
    'stack_selected_modifier',
    'align_to_active_modifier',
    'distribute_selected_modifier',
    'drop_to_floor_modifier',
    'quad_checker_modifier',
    'workplane_modifier',
    'project_to_active_plane_modifier',
    'instances_along_path_modifier',
    'replace_modifier',
    'randomize_modifier',
    'projection_modifier',
    'rebuild_curve_modifier',
    'axis_slice_modifier',
    'vertices_path_modifier',
    'path_modifier',
    'profile_primitive_modifier',
    'helix_path_modifier',
    'loft_modifier',
    'sweep_modifier',
    'face_component_array_modifier',
    'cad_intersect_modifier',
    'audit_selected_modifier',
    'audit_select_issues_modifier',
    'surface_box_detail_modifier',
    'extrude_modifier',
    'slice_panel_modifier',
    'combine_join_clean_modifier',
    'drop_to_surface_modifier',
}

_USER_TOOL_DEFAULTS_OPERATOR_IDS = {
    'sms.smart_boolean_stack',
    'sms.smart_cleanup_repair',
    'sms.smart_pipe_from_selection',
    'sms.smart_array_along_curve',
    'sms.scatter_instances_bake',
    'sms.conform_to_surface',
    'sms.floor_generator',
    'smsp.stack_selected',
    'smsp.align_to_active',
    'smsp.distribute_selected_axis',
    'smsp.drop_to_floor',
    'smsp.quad_checker',
    'smsp.workplane_from_active',
    'smsp.project_to_active_plane',
    'smsp.instances_along_path',
    'smsp.replace_with_active',
    'smsp.randomize_selected',
    'smsp.project_to_selected_surface',
    'smsp.rebuild_active_curve',
    'smsp.axis_slice_edit',
    'smsp.selected_vertices_to_path',
    'smsp.selected_objects_to_path',
    'smsp.add_profile_primitive',
    'smsp.add_helix_path',
    'smsp.loft_bridge_paths',
    'smsp.sweep_active_profile',
    'smsp.face_component_array',
    'smsp.cad_intersect_extend',
    'smsp.audit_selected',
    'smsp.audit_select_issues',
    'smsa.surface_box_detail',
    'smsa.smart_extrude_clean',
    'smsa.slice_panel_stack',
    'smsa.combine_join_clean',
    'smsa.drop_to_surface',
}


def _user_tool_uses_shared_defaults(plugin_id: str, operator_id: str) -> bool:
    pid = str(plugin_id or '').strip()
    op_id = str(operator_id or '').strip()
    return bool(pid in _USER_TOOL_DEFAULTS_PLUGIN_IDS or op_id in _USER_TOOL_DEFAULTS_OPERATOR_IDS)


def _stamp_shared_defaults_owner(new_by_obj, plugin_id: str, operator_id: str) -> None:
    if not _user_tool_uses_shared_defaults(plugin_id, operator_id):
        return
    pid = str(plugin_id or '').strip()
    op_id = str(operator_id or '').strip()
    try:
        items = list((new_by_obj or {}).items())
    except Exception:
        items = []
    for _obj_name, mods in items:
        obj = None
        try:
            obj = bpy.data.objects.get(str(_obj_name or ''))
        except Exception:
            obj = None
        mapping = {}
        if obj is not None:
            try:
                raw = obj.get('smsm_internal_user_tool_defaults_map', '')
                if isinstance(raw, dict):
                    mapping = dict(raw)
                elif str(raw or '').strip():
                    data = json.loads(str(raw))
                    if isinstance(data, dict):
                        mapping = data
            except Exception:
                mapping = {}
        changed = False
        for mod in list(mods or []):
            mod_name = str(getattr(mod, 'name', '') or '')
            if not mod_name:
                continue
            if obj is not None:
                mapping[mod_name] = {'plugin_id': pid, 'operator_id': op_id}
                changed = True
            # Geometry Nodes and some custom modifier types can carry ID properties.
            # Standard Blender modifiers may reject them, so object-level mapping above
            # is the persistent source of truth.
            try:
                mod['smsm_internal_user_tool_defaults'] = True
                if pid:
                    mod['smsm_internal_user_tool_id'] = pid
                if op_id:
                    mod['smsm_internal_user_tool_operator_id'] = op_id
            except Exception:
                pass
        if obj is not None and changed:
            try:
                obj['smsm_internal_user_tool_defaults_map'] = json.dumps(mapping, ensure_ascii=False, sort_keys=True)
            except Exception:
                try:
                    obj['smsm_internal_user_tool_defaults_map'] = dict(mapping)
                except Exception:
                    pass


def _maybe_lazy_register_operator_module(operator_id: str, context=None) -> bool:
    op_id =str(operator_id or '').strip()
    if not op_id or not any(op_id.startswith(prefix) for prefix in _DEFERRED_OPERATOR_PREFIXES):
        return False
    try:
        return bool(_lazy_register_operator_module(op_id, context))
    except Exception:
        return False


def _operator_registered(op_callable) -> bool:
    """Return True only when the Blender operator is actually registered.

    ``bpy.ops`` may expose a callable wrapper even before the real operator class
    has been registered. Deferred Smart Modifier subtools rely on lazy loading, so
    we must distinguish a syntactically resolvable wrapper from a live operator.
    """
    if op_callable is None:
        return False
    try:
        rna = op_callable.get_rna_type()
        ident = str(getattr(rna, 'identifier', '') or '')
        return bool(ident)
    except Exception:
        return False


def _user_plugin_operator_kwargs(plugin_id: str, operator_id: str) -> dict:
    return {}


def _new_modifier_count_from_snapshot(targets, before_snapshot) -> int:
    total = 0
    try:
        after = ms_collect_new_modifiers(targets or [], before_snapshot or {})
    except Exception:
        after = {}
    try:
        for mods in (after or {}).values():
            total += len(list(mods or []))
    except Exception:
        pass
    return int(total)

def _call_operator_preserving_cancel(runner):
    """Execute an operator runner and keep explicit CANCELLED results.

    This lets the underlying operator report its own detailed warning instead of
    replacing it with the generic "did not complete successfully" wrapper.
    """
    try:
        return runner()
    except Exception:
        return None


def _stack_add_should_use_shape_mesh_proxy(plugin_id: str, operator_id: str, meta=None) -> bool:
    pid = str(plugin_id or '').strip()
    op_id = str(operator_id or '').strip()
    mesh_proxy_ids = {
        'slice_panel_modifier',
        'axis_slice_modifier',
        'edit_poly',
        'smart_lattice',
        'boolean_stack_modifier',
        'projection_modifier',
        'floor_modifier',
        'surface_box_detail_modifier',
        'quad_checker_modifier',
        'unwrap_uvw_modifier',
        'uvw_map_modifier',
    }
    mesh_proxy_ops = {
        'smsa.slice_panel_stack',
        'smsp.axis_slice_edit',
        'ep.add_layer',
        'smart_lattice.add_layer',
        'sms.smart_boolean_stack',
        'sms.floor_generator',
        'smsp.project_to_selected_surface',
        'smsp.quad_checker',
        'smsm.unwrap_uvw_modifier',
        'smsm.uvw_map_modifier',
    }
    # These tools work on existing Curve objects directly in Object Mode, so the
    # active curve must not be swapped for a generated mesh proxy.
    if op_id in {'sms.smart_pipe_from_selection', 'smsm.max_sweep_modifier', 'sms.smart_array_along_curve'}:
        return False
    if pid.startswith('max_') or op_id.startswith('smsm.max_'):
        return True
    if pid in mesh_proxy_ids or op_id in mesh_proxy_ops:
        return True
    try:
        label_blob = ' '.join(str((meta or {}).get(k, '') or '') for k in ('label', 'description_en', 'usage_en')).lower()
        if 'mesh' in label_blob and 'curve object' not in label_blob and 'path curve' not in label_blob:
            return True
    except Exception:
        pass
    return False



def _stack_single_modifier_scene_overrides(plugin_id: str = '', operator_id: str = '', definition_key: str = '') -> list[tuple[object, str, object]]:
    """Return temporary scene-property overrides for stack entries that wrap multi-generator tools.

    Some migrated Max-style stack modifiers are implemented by delegating to panel generators.
    Those generators can intentionally create multiple modifiers when run from their own tool
    panel.  From the modifier stack, however, one list entry must create one modifier entry.
    """
    pid = str(plugin_id or '').strip()
    op_id = str(operator_id or '').strip()
    key = str(definition_key or '').strip()
    if pid != 'slice_panel_modifier' and key != 'slice_panel_modifier' and op_id != 'smsa.slice_panel_stack':
        return []
    return [('smsa_props', 'slice_count', 1)]


def _begin_stack_single_modifier_overrides(context, plugin_id: str = '', operator_id: str = '', definition_key: str = ''):
    changes = []
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    if scene is None:
        return changes
    for group_name, attr, value in _stack_single_modifier_scene_overrides(plugin_id, operator_id, definition_key):
        try:
            group = getattr(scene, group_name, None)
        except Exception:
            group = None
        if group is None or not hasattr(group, attr):
            continue
        try:
            old = getattr(group, attr)
            if old != value:
                setattr(group, attr, value)
            changes.append((group, attr, old))
        except Exception:
            pass
    return changes


def _end_stack_single_modifier_overrides(changes) -> None:
    for group, attr, old in reversed(list(changes or [])):
        try:
            setattr(group, attr, old)
        except Exception:
            pass

def _context_has_shape_source_for_proxy(context) -> bool:
    try:
        objs = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        objs = []
    try:
        active = getattr(context, 'active_object', None)
        if active is not None and active not in objs:
            objs.append(active)
    except Exception:
        pass
    for obj in objs:
        try:
            main = get_main_object(obj) or obj
        except Exception:
            main = obj
        try:
            if ms_is_shape_source_object(main):
                return True
        except Exception:
            pass
    return False


class SMSM_OT_run_user_plugin (Operator ):
    bl_idname ="smsm.run_user_plugin"
    bl_label ='Run User Tool'
    bl_description ='Run a Smart Modifier user tool from the migrated modifier catalog.'
    bl_options ={'INTERNAL', 'UNDO'}

    plugin_id :StringProperty (name ="Plugin ID")
    operator_id :StringProperty (name ="Operator ID")
    label :StringProperty (name ="Label")

    @classmethod 
    def description (cls ,context ,properties ):
        plugin_id =getattr (properties ,'plugin_id','')or ''
        operator_id =getattr (properties ,'operator_id','')or ''
        label =getattr (properties ,'label','')or ''
        try:
            lang =ui_language(context)
        except Exception:
            lang =''
        cache_key =(str(plugin_id),str(operator_id),str(label),str(lang))
        try:
            cached =_SMSM_ADD_MENU_TOOLTIP_CACHE.get(cache_key)
            if cached:
                return cached
        except Exception:
            pass
        meta =get_plugin_meta (plugin_id =plugin_id ,operator_id =operator_id )
        text =build_bilingual_tooltip (meta ,fallback_label =label ,context =context )
        try:
            if len(_SMSM_ADD_MENU_TOOLTIP_CACHE)>512:
                _SMSM_ADD_MENU_TOOLTIP_CACHE.clear()
            _SMSM_ADD_MENU_TOOLTIP_CACHE[cache_key]=text
        except Exception:
            pass
        return text

    def _resolve_operator (self ):
        op_id =(self .operator_id or '').strip ()
        if '.'not in op_id :
            return None ,op_id 
        return get_operator_callable (op_id ),op_id 

    def _dispatch (self ,context ):
        op ,op_id =self ._resolve_operator ()
        if not op_id :
            self .report ({'WARNING'},choose_text (
                "No Smart Modifier user tool was selected.",
                "Smart Modifier のユーザーツールが選択されていません。",
                context =context ,
            ))
            return {'CANCELLED'}
        plugin_id =(self .plugin_id or '')
        _maybe_lazy_register_operator_module (op_id ,context )
        op =get_operator_callable (op_id )or op 
        meta =get_plugin_meta (plugin_id =plugin_id ,operator_id =op_id )
        short_hint =get_plugin_short_hint (plugin_id =plugin_id ,operator_id =op_id )
        status =get_tool_runtime_status (context ,plugin_id =plugin_id ,operator_id =op_id )
        lang =ui_language (context )
        if (op is None )or (not _operator_registered (op )):
            if _lazy_register_operator_module (op_id ,context):
                op =get_operator_callable (op_id )
                status =get_tool_runtime_status (context ,plugin_id =plugin_id ,operator_id =op_id )
        if (op is None )or (not _operator_registered (op )):
            missing_msg =choose_text (f"Operator not found: {op_id }",f"オペレーターが見つかりません: {op_id }",context =context )
            if short_hint :
                missing_msg +=choose_text (f" | Hint: {short_hint }",f" | ヒント: {short_hint }",context =context )
            self .report ({'ERROR'},missing_msg )
            return {'CANCELLED'}
        if status .get ('bucket')=='context':
            _allow_shape_proxy_context =False
            try :
                _allow_shape_proxy_context =bool (is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =op_id ,plugin_meta =meta )and _stack_add_should_use_shape_mesh_proxy (plugin_id ,op_id ,meta )and _context_has_shape_source_for_proxy (context ))
            except Exception :
                _allow_shape_proxy_context =False
            if not _allow_shape_proxy_context :
                usage_text =''
                if isinstance (meta ,dict ):
                    usage_text =choose_text (meta .get ('usage_en',''),meta .get ('usage_ja',''),context =context )
                blocker_text =str (status .get ('blockers_ja'if lang =='ja'else 'blockers_en','')or '').strip ()
                msg =choose_text (f"Current context cannot run: {op_id }",f"現在のコンテキストでは実行できません: {op_id }",context =context )
                if blocker_text :
                    msg +=choose_text (f" | Blockers: {blocker_text }",f" | 不足条件: {blocker_text }",context =context )
                elif short_hint :
                    msg +=choose_text (f" | Hint: {short_hint }",f" | ヒント: {short_hint }",context =context )
                elif usage_text :
                    msg +=choose_text (f" | Hint: {usage_text }",f" | ヒント: {usage_text }",context =context )
                self .report ({'WARNING'},msg )
                return {'CANCELLED'}
        instance_targets =[]
        source_targets =[]
        before_snapshot ={}
        pre_effective_id_by_obj ={}
        stack_addable =False
        bridge_state =None
        proxy_selection_state =None
        use_shape_proxy_targets =False
        single_modifier_override_state =[]
        known_proxy_names =ms_shape_proxy_names ()
        dispatch_succeeded =False
        try :
            stack_addable =bool (is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =op_id ,plugin_meta =meta ))
            if stack_addable :
                instance_targets =list (ms_get_selected_main_meshes (context )or [])
                if not instance_targets :
                    try :
                        _seen =set ()
                        for _obj in list (getattr (context ,'selected_objects',[])or []):
                            try :_main =get_main_object (_obj )or _obj
                            except Exception :_main =_obj
                            if _main is not None and hasattr (_main ,'modifiers')and getattr (_main ,'name','')not in _seen :
                                _seen .add (getattr (_main ,'name',''))
                                instance_targets .append (_main )
                    except Exception :
                        pass 
                if not instance_targets :
                    _main =get_main_object (getattr (context ,'active_object',None ))
                    if _main is not None :
                        instance_targets =[_main ]
                try :
                    _active_main =get_main_object (getattr (context ,'active_object',None ))
                except Exception :
                    _active_main =None
                try :
                    if plugin_id in {'surface_conform_modifier','normal_transfer_modifier','conform_to_surface_tool'}or op_id in {'smsp.surface_conform_modifier','smsp.normal_transfer_to_selected','sms.conform_to_surface'}:
                        instance_targets =[_obj for _obj in instance_targets if _obj and _obj !=_active_main ]
                    elif plugin_id =='boolean_stack_modifier'or op_id in {'sms.smart_boolean_stack','smsm.max_sweep_modifier','smsp.sweep_active_profile','sms.smart_array_along_curve'}:
                        instance_targets =([_active_main ]if _active_main is not None else [])
                except Exception :
                    pass 
                source_targets =list (instance_targets or [])
                use_shape_proxy_targets =bool (_stack_add_should_use_shape_mesh_proxy (plugin_id ,op_id ,meta ))
                if use_shape_proxy_targets and instance_targets :
                    try :
                        instance_targets =ms_resolve_modifier_add_targets (instance_targets ,context =context ,create_shape_proxies =True ,migrate =True )or instance_targets
                        source_targets =ms_original_sources_for_stack_targets (instance_targets )or source_targets
                    except Exception :
                        pass
                if instance_targets :
                    before_snapshot =ms_snapshot_modifier_names (instance_targets )
                for _obj in instance_targets :
                    try :
                        _main_for_ui =get_main_object (_obj )or _obj
                        pre_effective_id_by_obj [_obj .name ]=ms_get_ui_active_id (_main_for_ui )
                    except Exception :
                        pass 
                if str (getattr (context ,'mode','')or '').startswith ('EDIT'):
                    try :
                        _needs_bridge =not bool (op .poll ())
                    except Exception :
                        _needs_bridge =True 
                    if _needs_bridge :
                        bridge_state =ms_capture_mode_bridge_state (context )
        except Exception :
            instance_targets =[]
            source_targets =[]
            before_snapshot ={}
            pre_effective_id_by_obj ={}
            stack_addable =False
            bridge_state =None
            proxy_selection_state =None
            use_shape_proxy_targets =False
            single_modifier_override_state =[]
        try :
            if bridge_state is not None :
                try :ms_enter_object_mode_bridge (context ,bridge_state )
                except Exception :pass 
            if use_shape_proxy_targets and instance_targets :
                try :
                    _active_main =get_main_object (getattr (context ,'active_object',None ))
                except Exception :
                    _active_main =None
                _active_exec =None
                try :
                    for _target in instance_targets :
                        _src =get_main_object (_target )or _target
                        if _active_main is not None and _src ==_active_main :
                            _active_exec =_target
                            break
                except Exception :
                    _active_exec =None
                if _active_exec is None and instance_targets :
                    try :_active_exec =instance_targets [0]
                    except Exception :_active_exec =None
                try :
                    if any (ms_is_shape_mesh_proxy (_t )for _t in instance_targets ):
                        proxy_selection_state =ms_begin_temporary_stack_target_selection (context ,instance_targets ,_active_exec )
                except Exception :
                    proxy_selection_state =None
            single_modifier_override_state =_begin_stack_single_modifier_overrides (context ,plugin_id ,op_id )
            op_kwargs =_user_plugin_operator_kwargs (plugin_id ,op_id )
            runners =(
            (lambda :op ('EXEC_DEFAULT',**op_kwargs)),
            (lambda :op (**op_kwargs)),
            )if bridge_state is not None else (
            (lambda :op ('INVOKE_DEFAULT',**op_kwargs)),
            (lambda :op ('EXEC_DEFAULT',**op_kwargs)),
            (lambda :op (**op_kwargs)),
            )
            last_cancelled =None
            for runner in runners :
                result =_call_operator_preserving_cancel (runner )
                if result is None :
                    continue 
                if isinstance (result ,set )and 'CANCELLED'in result :
                    last_cancelled =result
                    if stack_addable and _new_modifier_count_from_snapshot (instance_targets ,before_snapshot )>0 :
                        result ={'FINISHED'}
                    elif bridge_state is not None :
                        continue 
                    else :
                        continue 
                if result is not None :
                    try :
                        if stack_addable and isinstance (result ,set )and 'FINISHED'in result :
                            if len (instance_targets )>1 :
                                ms_promote_new_modifiers_to_instances (context ,instance_targets ,before_snapshot ,allow_copy_missing =True ,effective_id_by_obj =pre_effective_id_by_obj )
                            ms_apply_auto_selection_to_new_modifiers (instance_targets ,before_snapshot ,pre_effective_id_by_obj ,context =context )
                            try :
                                _new_after =ms_collect_new_modifiers (instance_targets ,before_snapshot )
                            except Exception :
                                _new_after ={}
                            try :
                                if len (instance_targets )>1:
                                    for _mods in (_new_after or {}).values ():
                                        for _mod in list (_mods or []):
                                            try :_ms_modifier_set_object_instance_unique (_mod ,True )
                                            except Exception :pass
                            except Exception :
                                pass
                            try :
                                _stamp_shared_defaults_owner (_new_after ,plugin_id ,op_id )
                            except Exception :
                                pass
                            _state_targets =source_targets or ms_original_sources_for_stack_targets (instance_targets )or instance_targets
                            for _obj in _state_targets :
                                try :
                                    ms_apply_state_post_action (context ,_obj ,interactive_default =False )
                                except Exception :
                                    pass 
                    except Exception :
                        pass
                    dispatch_succeeded =True
                    return result
            if last_cancelled is not None :
                return last_cancelled
        finally :
            if single_modifier_override_state :
                try :_end_stack_single_modifier_overrides (single_modifier_override_state )
                except Exception :pass
            if proxy_selection_state is not None :
                try :ms_end_temporary_stack_target_selection (context ,proxy_selection_state )
                except Exception :pass
            try :
                if source_targets :
                    ms_normalize_shape_proxy_visibility_selection (context ,source_targets )
            except Exception :pass
            if bridge_state is not None :
                try :ms_restore_mode_bridge (context ,bridge_state )
                except Exception :pass
            if not dispatch_succeeded :
                ms_discard_unused_shape_proxies (known_proxy_names )
        fail_msg =choose_text (f"Operator did not complete successfully: {op_id }",f"オペレーターが正常終了しませんでした: {op_id }",context =context )
        blocker_text =str (status .get ('blockers_ja'if lang =='ja'else 'blockers_en','')or '').strip ()
        if blocker_text :
            fail_msg +=choose_text (f" | Blockers: {blocker_text }",f" | 不足条件: {blocker_text }",context =context )
        elif short_hint :
            fail_msg +=choose_text (f" | Hint: {short_hint }",f" | ヒント: {short_hint }",context =context )
        self .report ({'WARNING'},fail_msg )
        return {'CANCELLED'}

    def execute (self ,context ):
        return self ._dispatch (context )

    def invoke (self ,context ,event ):
        return self ._dispatch (context )


classes =(
SMSM_OT_run_user_plugin ,
)


def register ():
    for cls in classes :
        try :
            bpy .utils .register_class (cls )
        except Exception :
            pass 


def unregister ():
    for cls in reversed (classes ):
        try :
            bpy .utils .unregister_class (cls )
        except Exception :
            pass 



_SMSM_AVAILABLE_USER_PLUGIN_GROUPS_CACHE = {'sig': None, 'groups': []}


def _smsm_available_user_plugin_groups_cached():
    """Return stack-addable plugin groups using a small signature cache.

    This mirrors the Add Modifier popup cache from ui.py but is kept in the
    plugin module so diagnostics and external callers can verify the lightweight
    path without forcing a popup redraw.
    """
    try:
        dn = getattr(getattr(bpy, 'app', None), 'driver_namespace', {}) or {}
        reg = _ms_plugins_dict()
        reg_len = len(reg) if isinstance(reg, dict) else 0
        sig = (id(reg), reg_len, len(PLUGIN_CATALOG))
        cache = _SMSM_AVAILABLE_USER_PLUGIN_GROUPS_CACHE
        if cache.get('sig') == sig and isinstance(cache.get('groups'), list):
            return list(cache.get('groups') or [])
        plugins = []
        seen = set()
        if isinstance(reg, dict):
            for plugin in reg.values():
                if not isinstance(plugin, dict):
                    continue
                if not plugin.get('stack_addable'):
                    continue
                pid = str(plugin.get('id') or plugin.get('plugin_id') or plugin.get('operator_id') or '')
                if pid and pid in seen:
                    continue
                if pid:
                    seen.add(pid)
                plugins.append(dict(plugin))
        for pid, meta in PLUGIN_CATALOG.items():
            key = str(pid or '')
            if key in seen:
                continue
            try:
                if not is_stack_addable_plugin(plugin_id=pid, operator_id=meta.get('operator_id'), plugin_meta=meta):
                    continue
            except Exception:
                continue
            item = dict(meta)
            item.setdefault('id', key)
            item['stack_addable'] = True
            plugins.append(item)
            seen.add(key)
        try:
            groups = [(gid, group_plugins) for gid, group_plugins in iter_plugins_grouped(plugins) if group_plugins]
        except Exception:
            groups = []
        cache['sig'] = sig
        cache['groups'] = list(groups)
        return groups
    except Exception:
        return []


_SMSM_ADD_MENU_OP_CACHE = {}
_SMSM_ADD_MENU_TOOLTIP_CACHE = {}


def _smsm_add_menu_operator_available_cached(operator_id: str) -> bool:
    op_id = str(operator_id or '').strip()
    if not op_id:
        return False
    try:
        if op_id in _SMSM_ADD_MENU_OP_CACHE:
            return bool(_SMSM_ADD_MENU_OP_CACHE[op_id])
    except Exception:
        pass
    available = True
    try:
        available = bool(operator_available(op_id))
    except Exception:
        available = True
    try:
        _SMSM_ADD_MENU_OP_CACHE[op_id] = bool(available)
    except Exception:
        pass
    return bool(available)


def _build_draw_fn (plugin_id ,label ,operator_id ,icon ='MODIFIER'):
    def _draw (layout ,context ):
        try :
            row =_sms_large_icon_row (layout ,align =True ,scale_y =1.08 )
            label_text =pgettext_iface (label ,context =context )
            available =_smsm_add_menu_operator_available_cached (operator_id )
            if not available:
                row .alert =True
            # Keep the add-popup draw path intentionally lightweight.  Full
            # context validation still runs inside SMSM_OT_run_user_plugin before
            # the tool executes, so functionality and safety are unchanged while
            # opening/navigating the popup no longer performs every validator.
            op =_sms_icon_operator (row ,"smsm.run_user_plugin",text =label_text ,icon_name =_sms_icon_for_plugin ({'id':plugin_id ,'operator_id':operator_id ,'icon':icon},'modifier'),fallback_icon =icon )
            op .plugin_id =plugin_id
            op .operator_id =operator_id
            op .label =label
        except Exception :
            pass
    safe_name =str (plugin_id or operator_id or 'plugin').replace ('.','_').replace ('-','_')
    _draw .__name__ =f"draw_{safe_name }"
    return _draw


def register_simple_plugin (plugin_id ,label =None ,operator_id =None ,icon ='MODIFIER',priority =80 ,**extra_meta ):
    dn =bpy .app .driver_namespace 
    meta =get_plugin_meta (plugin_id =plugin_id ,operator_id =operator_id )or {}
    label =label or meta .get ('label')or str (plugin_id )
    operator_id =operator_id or meta .get ('operator_id')or ''
    icon =icon or meta .get ('icon')or 'MODIFIER'
    try :
        priority =int (meta .get ('priority',priority )or priority )
    except Exception :
        priority =80 
    stack_addable =is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =operator_id ,plugin_meta =meta )
    plugin ={
    'id':plugin_id ,
    'label':label ,
    'operator_id':operator_id ,
    'icon':icon ,
    'priority':priority ,
    'group':extra_meta .get ('group')or meta .get ('group','other'),
    'group_label':extra_meta .get ('group_label')or meta .get ('group_label',''),
    'group_icon':extra_meta .get ('group_icon')or meta .get ('group_icon','TOOL_SETTINGS'),
    'group_priority':extra_meta .get ('group_priority')or meta .get ('group_priority',0 ),
    'description_en':extra_meta .get ('description_en')or meta .get ('description_en',''),
    'description_ja':extra_meta .get ('description_ja')or meta .get ('description_ja',''),
    'usage_en':extra_meta .get ('usage_en')or meta .get ('usage_en',''),
    'usage_ja':extra_meta .get ('usage_ja')or meta .get ('usage_ja',''),
    'stack_addable':bool (stack_addable ),
    'modeling_side':not bool (stack_addable ),
    'draw_add_menu':_build_draw_fn (plugin_id ,label ,operator_id ,icon ),
    }
    reg =_ms_plugins_dict ()
    reg [plugin_id ]=plugin 
    fn =dn .get ('_MS_REGISTER_PLUGIN_V1')
    if callable (fn ):
        try :
            fn (plugin_id ,plugin )
        except Exception :
            pass 


def unregister_simple_plugin (plugin_id ):
    dn =bpy .app .driver_namespace 
    reg =_ms_plugins_dict ()
    reg .pop (plugin_id ,None )
    fn =dn .get ('_MS_UNREGISTER_PLUGIN_V1')
    if callable (fn ):
        try :
            fn (plugin_id )
        except Exception :
            pass 
