# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Controls that open the installed modifier help operator on demand."""
from .translation import pgettext_iface


def _preview_icon(name, standard):
    try:
        from .icons import icon_value
        return icon_value(name, standard)
    except (ImportError, AttributeError, ValueError, RuntimeError, TypeError):
        return 0


def draw_help_button(layout, help_id, *, context=None, compact=False, text=None, icon='QUESTION'):
    """Add one compact help button to the supplied Blender layout."""
    topic = str(help_id or '').strip()
    if layout is None or not topic:
        return False
    original_context = getattr(layout, "operator_context", None)
    try:
        if original_context is not None:
            layout.operator_context = "INVOKE_DEFAULT"
        row = layout.row(align=True)
        row.scale_x = 0.82
        preview = _preview_icon("help", "QUESTION")
        icon_args = {"icon_value": preview} if preview else {"icon": "QUESTION"}
        action = row.operator("smart_modifier_suite.show_help", text="", **icon_args)
        action.help_id = topic
        return True
    except (AttributeError, TypeError, ValueError, RuntimeError):
        return False
    finally:
        if original_context is not None:
            layout.operator_context = original_context


def draw_help_header(layout, context, label, icon, help_id, *, compact_help=True):
    """Draw a localizable title and its help affordance in one row."""
    row = layout.row(align=True)
    try:
        columns = row.split(factor=0.86, align=True)
    except (AttributeError, TypeError, RuntimeError):
        columns = row
    title = columns.row(align=True)
    help_slot = columns.row(align=True)
    if hasattr(help_slot, "alignment"):
        help_slot.alignment = "RIGHT"
    text = pgettext_iface(label, context=context)
    standard = str(icon or "TOOL_SETTINGS")
    preview = _preview_icon(standard, standard)
    if preview:
        try:
            title.label(text=text, icon_value=preview)
        except (TypeError, ValueError, RuntimeError):
            title.label(text=text, icon="TOOL_SETTINGS")
    else:
        try:
            title.label(text=text, icon=standard)
        except (TypeError, ValueError, RuntimeError):
            title.label(text=text, icon="TOOL_SETTINGS")
    draw_help_button(help_slot, help_id, context=context, compact=compact_help)
    return row
