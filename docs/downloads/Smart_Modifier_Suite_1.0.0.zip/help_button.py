# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

"""Lightweight help-button drawing helpers.

The detailed popup text and drawing logic are intentionally not imported here.
They live in help.py and are imported only by the help operator after
users click a Help button.
"""
from __future__ import annotations

from .translation import pgettext_iface

try:
    from .icons import icon_value as _sms_icon_value
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0


def draw_help_button(layout, help_id: str, *, context=None, compact: bool = False, text: str | None = None, icon: str = 'QUESTION') -> bool:
    """Draw a lazy, icon-only help button and assign the requested help topic id.

    Keep every help affordance compact in the N-panel.  The detailed text still
    lives in the operator tooltip and in the lazy popup, but the visible control
    is always a single question-mark icon button.
    """
    if layout is None:
        return False
    help_id = str(help_id or '').strip()
    if not help_id:
        return False
    try:
        # Always render help controls as a compact question-mark icon.  Some
        # callers intentionally pass text or compact=False for legacy layouts;
        # those arguments are kept for API compatibility but no longer affect
        # the visible N-panel button size.
        label = ''
        help_icon = 'QUESTION'
        previous_context = None
        try:
            previous_context = layout.operator_context
            layout.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            previous_context = None
        try:
            button_layout = layout.row(align=True)
            try:
                button_layout.scale_x = 0.82
                button_layout.scale_y = 1.0
            except Exception:
                pass
            icon_id = _sms_icon_value('help', help_icon)
            if icon_id:
                op = button_layout.operator('smart_modifier_suite.show_help', text=label, icon_value=icon_id)
            else:
                op = button_layout.operator('smart_modifier_suite.show_help', text=label, icon=help_icon)
            op.help_id = help_id
        finally:
            try:
                if previous_context is not None:
                    layout.operator_context = previous_context
            except Exception:
                pass
        return True
    except Exception:
        return False


def draw_help_header(layout, context, label: str, icon: str, help_id: str, *, compact_help: bool = True):
    """Draw a Smart Rig-style compact group header with a right-side lazy Help button."""
    row = layout.row(align=True)
    localized = pgettext_iface(label, context=context)
    fallback_icon = str(icon or 'TOOL_SETTINGS')
    try:
        split = row.split(factor=0.86, align=True)
        left = split.row(align=True)
        right = split.row(align=True)
        right.alignment = 'RIGHT'
    except Exception:
        left = row.row(align=True)
        right = row.row(align=True)
        try:
            right.alignment = 'RIGHT'
        except Exception:
            pass
    try:
        icon_id = _sms_icon_value(fallback_icon, fallback_icon)
    except Exception:
        icon_id = 0
    if icon_id:
        try:
            left.label(text=localized, icon_value=icon_id)
        except Exception:
            try:
                left.label(text=localized, icon='TOOL_SETTINGS')
            except Exception:
                left.label(text=localized)
    else:
        try:
            left.label(text=localized, icon=fallback_icon)
        except Exception:
            try:
                left.label(text=localized, icon='TOOL_SETTINGS')
            except Exception:
                left.label(text=localized)
    try:
        draw_help_button(right, help_id, context=context, compact=compact_help)
    except Exception:
        try:
            draw_help_button(row, help_id, context=context, compact=compact_help)
        except Exception:
            pass
    return row

