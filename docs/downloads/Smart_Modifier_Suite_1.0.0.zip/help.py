# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

"""Lazy-loaded help popup content for Smart Modifier.

This module is intentionally imported only when a Help button is clicked.  It
keeps detailed help text, popup drawing, and longer setting explanations out of
normal Blender startup and routine N-panel drawing paths.
"""
from __future__ import annotations

import unicodedata
from typing import Iterable

try:
    import bpy
except Exception:  # pragma: no cover - Blender runtime only
    bpy = None

from .translation import choose_text, pgettext_iface


def _t(en: str, ja: str, context=None) -> str:
    return choose_text(en, ja, context=context)


_DEFAULT_POPUP_WIDTH_PX = 860
_POPUP_TEXT_GUTTER_PX = 112
_MIN_WRAP_TEXT_PX = 260
_CURRENT_HELP_CONTEXT = None
_CURRENT_HELP_WRAP_PX = float(_DEFAULT_POPUP_WIDTH_PX - _POPUP_TEXT_GUTTER_PX)


def _ui_scale(context=None) -> float:
    try:
        scale = float(getattr(getattr(getattr(context, 'preferences', None), 'system', None), 'ui_scale', 1.0))
    except Exception:
        scale = 1.0
    if scale <= 0.0:
        scale = 1.0
    return scale


def _font_points(context=None) -> int:
    try:
        styles = getattr(getattr(context, 'preferences', None), 'ui_styles', None)
        if styles:
            widget = getattr(styles[0], 'widget', None)
            points = int(round(float(getattr(widget, 'points', 11))))
            return max(8, points)
    except Exception:
        pass
    return 11


def _dpi(context=None) -> int:
    try:
        system = getattr(getattr(context, 'preferences', None), 'system', None)
        value = int(round(float(getattr(system, 'dpi', 72))))
        return max(36, value)
    except Exception:
        return 72


def _pixel_size(context=None) -> float:
    try:
        system = getattr(getattr(context, 'preferences', None), 'system', None)
        value = float(getattr(system, 'pixel_size', 1.0))
        if value > 0.0:
            return value
    except Exception:
        pass
    return 1.0


def _set_draw_wrap_context(context=None, popup_width_px: int | None = None) -> None:
    """Store popup-width-derived wrapping data for the current draw call."""
    global _CURRENT_HELP_CONTEXT, _CURRENT_HELP_WRAP_PX
    _CURRENT_HELP_CONTEXT = context
    try:
        popup_px = int(popup_width_px or _DEFAULT_POPUP_WIDTH_PX)
    except Exception:
        popup_px = _DEFAULT_POPUP_WIDTH_PX
    scale = _ui_scale(context)
    gutter = max(72.0, _POPUP_TEXT_GUTTER_PX * scale)
    minimum = max(180.0, _MIN_WRAP_TEXT_PX * scale)
    _CURRENT_HELP_WRAP_PX = max(minimum, float(popup_px) - gutter)


def _char_width(char: str) -> int:
    """Return a conservative display-cell width fallback for Blender UI labels."""
    if not char:
        return 0
    if unicodedata.combining(char):
        return 0
    if unicodedata.east_asian_width(char) in {'F', 'W', 'A'}:
        return 2
    return 1


def _visual_width(text: str) -> int:
    return sum(_char_width(ch) for ch in str(text or ''))


def _fallback_text_width_px(text: str, context=None) -> float:
    scale = _ui_scale(context)
    # Approximate one Latin display cell at a little over half of the UI font size.
    # Full-width Japanese characters are already counted as two visual cells.
    cell_px = max(5.0, _font_points(context) * 0.58 * scale * _pixel_size(context))
    return float(_visual_width(text) * cell_px)


def _text_width_px(text: str, context=None) -> float:
    raw = str(text or '')
    if not raw:
        return 0.0
    context = context or _CURRENT_HELP_CONTEXT
    try:
        import blf
        font_id = 0
        points = _font_points(context)
        try:
            blf.size(font_id, points)
        except TypeError:
            blf.size(font_id, points, _dpi(context))
        dims = blf.dimensions(font_id, raw)
        return max(0.0, float(dims[0]))
    except Exception:
        return _fallback_text_width_px(raw, context)


def _fits_popup_width(text: str, max_px: float, context=None) -> bool:
    return _text_width_px(text, context) <= max(1.0, float(max_px))


def _split_line_to_popup_width(text: str, max_px: float, context=None) -> list[str]:
    """Wrap one logical line only when its measured width exceeds the popup body.

    The first implementation checked every character with full text-width
    measurement, which became unnecessarily expensive for large generated help
    topics such as the 3ds Max modifier catalog.  This version uses a binary
    search for the longest fitting prefix, then backs up to a word boundary when
    possible.  It preserves popup-width-aware wrapping while keeping help loading
    strictly click-time and responsive.
    """
    source = str(text or '').strip()
    if not source:
        return []
    max_px = max(1.0, float(max_px))
    if _fits_popup_width(source, max_px, context):
        return [source]

    lines: list[str] = []
    remaining = source
    safety = 0
    while remaining and safety < 4096:
        safety += 1
        if _fits_popup_width(remaining, max_px, context):
            lines.append(remaining)
            break

        lo = 1
        hi = len(remaining)
        best = 1
        while lo <= hi:
            mid = (lo + hi) // 2
            candidate = remaining[:mid].rstrip()
            if not candidate:
                lo = mid + 1
                continue
            if _fits_popup_width(candidate, max_px, context):
                best = max(1, mid)
                lo = mid + 1
            else:
                hi = mid - 1

        cut_index = max(1, best)
        # Prefer a word boundary near the measured cut for English text.  For
        # Japanese or other no-space text, the measured character cut is used.
        boundary = remaining.rfind(' ', 0, cut_index + 1)
        if boundary > max(1, int(cut_index * 0.55)):
            cut_index = boundary
        chunk = remaining[:cut_index].strip()
        if not chunk:
            chunk = remaining[:1]
            cut_index = 1
        lines.append(chunk)
        remaining = remaining[cut_index:].lstrip()
    if remaining and safety >= 4096:
        lines.append(remaining)
    return [line for line in lines if line]

def _wrap_text(text: str) -> list[str]:
    raw = str(text or '').strip()
    if not raw:
        return []
    context = _CURRENT_HELP_CONTEXT
    max_px = _CURRENT_HELP_WRAP_PX
    lines: list[str] = []
    for part in raw.splitlines():
        part = part.strip()
        if not part:
            lines.append('')
            continue
        lines.extend(_split_line_to_popup_width(part, max_px, context))
    return lines


def _line(layout, text: str, *, icon: str = 'NONE') -> None:
    first = True
    wrapped = _wrap_text(text)
    if not wrapped:
        layout.separator(factor=0.35)
        return
    for line in wrapped:
        if line:
            draw_icon = icon if first else 'BLANK1'
            try:
                from .icons import label as _sms_icon_label
                _sms_icon_label(layout, text=line, icon_name=draw_icon, fallback_icon=draw_icon)
            except Exception:
                layout.label(text=line, icon=draw_icon)
        else:
            layout.separator(factor=0.35)
        first = False


def _section(layout, title: str, *, icon: str = 'QUESTION'):
    box = layout.box()
    _line(box, title, icon=icon)
    return box.column(align=True)


def _bullet(layout, text: str, *, icon: str = 'DOT') -> None:
    _line(layout, text, icon=icon)


def _entry(layout, name: str, desc: str, *, icon: str = 'DOT') -> None:
    _line(layout, str(name or '').strip(), icon=icon)
    if desc:
        _line(layout, str(desc).strip(), icon='BLANK1')


def _pairs_section(layout, title: str, pairs: Iterable[tuple[str, str]], *, icon: str = 'TOOL_SETTINGS', context=None) -> None:
    col = _section(layout, title, icon=icon)
    drew = False
    for name, desc in pairs or ():
        name = str(name or '').strip()
        desc = str(desc or '').strip()
        if not name and not desc:
            continue
        _entry(col, name, desc, icon='DOT')
        drew = True
    if not drew:
        _line(col, _t('No items are available for this help topic.', 'このヘルプ項目で表示できる項目はありません。', context=context), icon='NONE')

def _enum_runtime_pairs(context=None) -> list[tuple[str, str]]:
    return [
        (_t('N-panel State Save', 'Nパネル状態保存', context=context), _t('Controls whether Smart Modifier writes N-panel settings to Smart_Modifier_Suite/Smart_Modifier_Suite.json. ON saves each change immediately. Turning OFF records OFF once, then prevents normal, forced, save, and shutdown writes until ON is restored.', 'Smart_Modifier_Suite.json へのNパネル設定保存を制御します。ONでは変更ごとに即時保存します。OFFへの切り替え自体を最後に1回保存し、その後は再びONにするまで通常・強制・ファイル保存・終了時の書き込みを行いません。', context=context)),
        (_t('Modifier Stack Live Sync', 'モディファイアスタック ライブ同期', context=context), _t('Enables dependency-graph callbacks and the realtime property timer used by the main stack display, end-result state, and inline parameter refresh. Disable it when you do not need automatic stack synchronization.', 'メインスタック表示、最終結果状態、インラインパラメータ更新に使う依存グラフコールバックとリアルタイムプロパティタイマーを有効にします。自動スタック同期が不要な時は無効にしてください。', context=context)),
        (_t('Edit Polygon Live Sync', '編集ポリゴンライブ同期', context=context), _t('Enables Edit Polygon selection tracking and edit-layer stack callbacks only while needed. When disabled, the live handlers remain stopped and the tool does not turn them on automatically.', '必要な間だけ 編集ポリゴンの選択追跡と編集レイヤースタックコールバックを有効にします。無効時はライブハンドラーを停止したままにし、ツール側から勝手に有効化しません。', context=context)),
        (_t('Smart Lattice Live Sync', 'Smart Lattice ライブ同期', context=context), _t('Enables Smart Lattice / FFD viewport overlay drawing, cleanup, and dependency-graph synchronization. Disable it when you are not editing lattice or FFD-style deformation layers.', 'Smart Lattice / FFD のビューポートオーバーレイ描画、クリーンアップ、依存グラフ同期を有効にします。ラティスや FFD 形式の変形レイヤーを編集していない時は無効にしてください。', context=context)),
        (_t('Modifier Switcher Auto Update', 'モディファイア管理 自動更新', context=context), _t('Keeps Modifier Switcher target and object lists refreshed by timer. Disable it in heavy scenes and use Update manually when needed.', 'タイマーで Modifier Switcher の対象リストとオブジェクトリストを更新し続けます。重いシーンでは無効にし、必要な時だけ手動で Update を使用してください。', context=context)),
        (_t('Captured Runtime Features', '検出された常時起動機能', context=context), _t('Shows captured handlers, timers, message-bus subscriptions, keymaps, or draw handlers registered by integrated tools. Each entry is drawn as a real checkbox toggle so enabled items consistently show Blender’s native active highlight.', '統合ツールが登録したハンドラー、タイマー、メッセージバス購読、キーマップ、描画ハンドラーを検出して表示します。各項目は実体のあるチェックボックストグルとして描画されるため、有効項目には Blender 標準のアクティブ表示が安定して表示されます。', context=context)),
    ]



def _core_settings_pairs(context=None) -> list[tuple[str, str]]:
    return [
        (_t('Enable Smart Modifier', 'Smart Modifier を使用', context=context), _t('Shows or hides the main Modifier Stack workspace. It does not delete existing modifiers; it only controls this add-on UI and related controls.', 'メインのモディファイアスタック作業領域を表示 / 非表示にします。既存モディファイアは削除せず、このアドオンのUIと関連操作のみを制御します。', context=context)),
        (_t('Enable Modifier Switcher', 'モディファイア管理を使用', context=context), _t('Shows the Modifier Switcher panel and registers the list tools used to batch-toggle Viewport, Render, Edit Mode, On Cage, and Expanded states.', 'Modifier Switcher パネルを表示し、Viewport、Render、Edit Mode、On Cage、Expanded などをまとめて切り替える一覧ツールを有効にします。', context=context)),
        (_t('Enable Edit Polygon Modifier (Bundled)', 'Edit Polygon Modifier（同梱サブツール）', context=context), _t('Allows Edit Polygon entries to appear in the bundled tool catalog and Add Modifier user tools. Runtime synchronization is still controlled separately by the Always-on Toggles group.', '編集ポリゴンの項目を同梱ツール一覧と Add Modifier のユーザーツールに表示できるようにします。常駐同期は別途「常時機能切り替え」で制御します。', context=context)),
        (_t('Enable Smart Lattice Modifier (Bundled)', 'Smart Lattice Modifier（同梱サブツール）', context=context), _t('Allows Smart Lattice entries to appear in the bundled tool catalog and Add Modifier user tools. Its overlay and live callbacks remain off unless enabled in Always-on Toggles.', 'Smart Lattice の項目を同梱ツール一覧と Add Modifier のユーザーツールに表示できるようにします。オーバーレイとライブコールバックは、常時機能切り替えで有効にするまで無効です。', context=context)),
        (_t('Stack Order', 'スタック表示順', context=context), _t('Controls only the display order in the N-panel. Base Object Top follows Blender-style top-down reading; Base Object Bottom is useful when you prefer the final modifiers near the top.', 'Nパネル内の表示順だけを変更します。Base Object Top は Blender 風の上から読む並び、Base Object Bottom は最終側モディファイアを上に見たい場合に便利です。', context=context)),
        (_t('Auto Disable Restore Behavior', '自動無効からの復元動作', context=context), _t('Choose Preserve Current States to restore the four modifier-header states exactly, or Force Enable Selected States to turn ON only the channels selected by the On Cage, Edit Mode, Realtime Viewport, and Render icon buttons when a row leaves temporary suppression.', '「現在の有効・無効状態を維持」では4つのモディファイアヘッダー状態を正確に復元します。「選択項目を強制有効」では、一時無効から戻る時に、ケージ、編集モード、リアルタイム、レンダーのアイコンボタンで選んだ項目だけをONにします。', context=context)),
        (_t('Force-enable display icons', '強制有効の表示アイコン', context=context), _t('The four icon buttons are shown only in Force Enable Selected States mode. Each button is independent, and its state is stored by N-panel State Save together with the other Smart Modifier settings.', '4つのアイコンボタンは「選択項目を強制有効」モードの時だけ表示されます。各項目は個別に選択でき、その状態は他の Smart Modifier 設定と一緒に「Nパネル状態保存」で保存されます。', context=context)),
        (_t('Always-on Toggles open state', '常時機能切り替えの開閉状態', context=context), _t('Stores whether the Always-on Toggles group is open or closed. The default is closed, and the state is saved immediately.', '常時機能切り替えグループを開いているか閉じているかを保存します。初期状態は閉じた状態で、変更は即時保存されます。', context=context)),
    ]


def _modifier_stack_settings_pairs(context=None) -> list[tuple[str, str]]:
    return [
        (_t('Add Modifier', 'モディファイアを追加', context=context), _t('Opens the Smart Modifier add popup. It includes Blender standard modifier categories and bundled user tools without loading each heavy tool until it is executed.', 'Smart Modifier の追加ポップアップを開きます。Blender標準モディファイア分類と同梱ユーザーツールを表示しますが、重いツール本体は実行時まで読み込みません。', context=context)),
        (_t('Modifier Auto Disable', 'モディファイア自動無効', context=context), _t('When enabled, Smart Modifier temporarily turns OFF On Cage, Edit Mode, Realtime Viewport, and Render for modifiers below/later than the active stack item so the selected edit level is isolated. The four manual states are saved before suppression and restored according to Auto Disable Restore Behavior.', '有効時は、アクティブなスタック項目より下/後段のモディファイアについて、ケージ、編集モード、リアルタイム、レンダーを一時的にOFFにし、選択中の編集階層だけを分離します。4つの手動状態は一時無効化前に保存され、「自動無効からの復元」の設定に従って復元されます。', context=context)),
        (_t('Show End Result', '最終結果を表示', context=context), _t('When enabled, EndPreview shows the final evaluated stack while Modifier Auto Disable isolates the active edit level. When disabled, EndPreview is not generated.', '有効時は、モディファイア自動無効でアクティブ編集階層を分離しながら、EndPreview で最終評価スタックを表示します。無効時は EndPreview を生成しません。', context=context)),
        (_t('Property Items Display', 'プロパティ項目の表示', context=context), _t('Expands or collapses the modifier property area inside the stack panel. Turning it off keeps the N-panel compact without changing modifier values.', 'スタックパネル内のモディファイア設定欄を開閉します。OFFにしても値は変わらず、Nパネルをコンパクトに保てます。', context=context)),
        (_t('Modifier visibility icons', 'モディファイア表示アイコン', context=context), _t('Controls On Cage, Edit Mode, Viewport, and Render states using the same semantics as Blender modifier headers.', 'Blender標準のモディファイアヘッダーと同じ意味で、On Cage、Edit Mode、Viewport、Render の状態を切り替えます。', context=context)),
        (_t('UVW Map', 'UVWマップ', context=context), _t('Adds a non-destructive Smart Connect UVW Planar mapping entry driven by an Empty gizmo. Move, rotate, scale, or animate the gizmo to update UVMap in real time.', 'Emptyギズモで制御する非破壊のSmart Connect UVW平面マッピング項目を追加します。ギズモの移動・回転・スケール・アニメーションでUVMapをリアルタイム更新します。', context=context)),
        (_t('Unwrap UVW', 'UVアンラップ', context=context), _t('Adds a stack-managed Unwrap UVW entry for angle-based, conformal, smart flatten, planar, box, cylindrical, spherical, and packing workflows. Manual seam and island edits continue through Blender UV tools.', '角度ベース、コンフォーマル、スマート展開、平面、ボックス、円柱、球、パックのワークフロー用に、スタック管理式の Unwrap UVW 項目を追加します。シームやアイランドの手動編集は Blender のUVツールで行います。', context=context)),
        (_t('Workflow custom modifier categories', 'ワークフロー別独自モディファイアカテゴリ', context=context), _t('Smart Modifier custom tools and Max-compatible entries are shown by function, such as Deform, Generate, UV, Surface, Rigging, Simulation, and Utility, instead of a separate 3ds Max category.', 'Smart Modifier の独自ツールと Max 互換項目は、独立した 3ds Max カテゴリではなく、Deform、Generate、UV、Surface、Rigging、Simulation、Utility などの機能別カテゴリに表示されます。', context=context)),
        (_t('Base Object row', 'ベースオブジェクト行', context=context), _t('Switches the active edit level back to the original object before stack modifiers. Use this when you want to edit or inspect the base mesh.', 'アクティブな編集レベルをスタック前の元オブジェクトへ戻します。ベースメッシュを編集・確認したい時に使います。', context=context)),
        (_t('Modifier row menu', 'モディファイア行メニュー', context=context), _t('Opens per-level actions such as rename, move, selection, and modifier-specific operations when available.', '名称変更、移動、選択、利用可能なモディファイア固有操作など、各レベルごとのメニューを開きます。', context=context)),
    ]


def _modswitch_settings_pairs(context=None) -> list[tuple[str, str]]:
    return [
        (_t('Modifier List', 'モディファイア一覧', context=context), _t('Displays all scene modifier targets by modifier name/type with batch action buttons. Use the filter field to narrow targets before toggling.', 'シーン内の全モディファイア対象を、モディファイア名/タイプ単位で一括操作ボタンと共に表示します。切り替え前にフィルター欄で対象を絞り込めます。', context=context)),
        (_t('Affect Viewport / Render / Edit Mode / On Cage', 'Viewport / Render / Edit Mode / On Cage 反映', context=context), _t('Chooses which visibility flags the batch operations should change. This lets you update render-only, viewport-only, or edit-mode states separately.', '一括操作で変更する表示フラグを選びます。レンダー専用、ビューポート専用、編集モード表示などを分けて制御できます。', context=context)),
        (_t('Object List', 'オブジェクト一覧', context=context), _t('Shows every object that owns the selected scene modifier. The LINKED toggle switches this list to objects instanced with the active Modifier Stack item.', '選択中のシーンモディファイアを持つ全オブジェクトを表示します。LINKEDトグルをONにすると、モディファイアスタックのアクティブ項目とインスタンス関係にあるオブジェクト一覧へ切り替わります。', context=context)),
        (_t('State Sets', '状態セット', context=context), _t('Saves named visibility states and reapplies them later. Use this for modeling, preview, export, or render variants.', '表示状態を名前付きで保存し、後から再適用します。モデリング、プレビュー、書き出し、レンダー用バリエーションに使えます。', context=context)),
        (_t('Refresh Interval', '更新間隔', context=context), _t('Timer interval used only when Modifier Switcher Auto Update is enabled in Always-on Toggles. Higher values reduce background refresh frequency.', '「常時機能切り替え」で Modifier Switcher Auto Update が有効な場合だけ使うタイマー間隔です。大きい値ほどバックグラウンド更新頻度が下がります。', context=context)),
        (_t('Mode / Scope', 'モード / 対象範囲', context=context), _t('Kept for saved layout compatibility. The renewed switcher scans all scene modifiers and lists objects by the selected modifier target.', '保存済みレイアウト互換のため残されています。新しい切り替え機能ではシーン内の全モディファイアをスキャンし、選択したモディファイア対象ごとにオブジェクトを一覧表示します。', context=context)),
        (_t('Visible Only', '表示中のみ', context=context), _t('Kept for saved layout compatibility. The renewed switcher scans the full scene so all scene modifiers can appear in the Modifier List.', '保存済みレイアウト互換のため残されています。新しい切り替え機能では、全シーンモディファイアを一覧に出すためシーン全体をスキャンします。', context=context)),
        (_t('Expanded', '展開状態', context=context), _t('Includes modifier expanded/collapsed state in batch operations when supported.', '対応している場合、モディファイアの展開 / 折りたたみ状態も一括操作に含めます。', context=context)),
    ]


_TOPIC_BASE = {
    'always_on': {
        'icon': 'TIME',
        'title': ('Always-on Toggles', '常時機能切り替え'),
        'overview': [
            ('Central switchboard for every function that can keep handlers, timers, message-bus subscriptions, keymaps, overlays, or synchronization callbacks alive while Blender is idle.', 'Blender待機中もハンドラー、タイマー、メッセージバス購読、キーマップ、オーバーレイ、同期コールバックを維持し得る機能をまとめた中央スイッチです。'),
            ('Disabled entries are kept fully inactive so startup and idle behavior stay light.', '無効の項目は完全に停止状態に保ち、起動時と待機時の動作を軽くします。'),
        ],
        'usage': [
            ('Open the group only when you need to change background behavior, then enable only the entries required for your current workflow.', 'バックグラウンド動作を変更したい時だけグループを開き、現在の作業に必要な項目だけ有効にします。'),
            ('Use the right-side Enabled / Disabled checkbox button. The state is saved immediately, restored after Blender restarts or another file is opened, and enabled entries use Blender’s native blue active highlight.', '右側の「有効 / 無効」チェックボックスボタンで切り替えます。状態は即時保存され、Blender再起動後や別ファイル読み込み後も復元され、有効項目には Blender 標準の青いアクティブ表示が出ます。'),
        ],
        'functions': [
            ('Enable / Disable each always-on item', '各常時起動項目の有効 / 無効', 'Switches the selected background service without changing unrelated tools.', '選択したバックグラウンドサービスだけを切り替え、関係ないツールは変更しません。'),
            ('Persist runtime state', '常時起動状態を保存', 'Stores the selected state immediately so it is restored after restart or file changes.', '選択状態を即時保存し、再起動後やファイル変更後にも復元します。'),
        ],
        'settings_func': _enum_runtime_pairs,
    },
    'settings': {
        'icon': 'PREFERENCES',
        'title': ('Settings', '設定項目'),
        'overview': [
            ('Central configuration for which Smart Modifier panels and bundled subtools are available.', 'Smart Modifier の各パネルと同梱サブツールを利用可能にするかを管理する中央設定です。'),
            ('These settings control UI and feature availability. Always-running behavior is controlled separately in Always-on Toggles.', 'これらの設定はUIと機能の利用可否を制御します。常時起動する動作は別途「常時機能切り替え」で制御します。'),
        ],
        'usage': [
            ('Turn off a bundled subtool when you do not want it shown or loaded by the suite.', '表示や読み込みを行いたくない同梱サブツールはOFFにします。'),
            ('Change Stack Order if you prefer Base Object at the top or bottom of the modifier stack list.', 'モディファイアスタック一覧でベースオブジェクトを上に置くか下に置くかは、スタック表示順で変更します。'),
        ],
        'settings_func': _core_settings_pairs,
    },
    'modifier_stack': {
        'icon': 'MODIFIER',
        'title': ('Modifier Stack', 'モディファイアスタック'),
        'overview': [
            ('Main Smart Modifier workspace for adding modifiers, switching edit levels, toggling visibility states, and editing modifier properties inside the N-panel.', 'Nパネル内でモディファイア追加、編集レベル切り替え、表示状態切り替え、モディファイア設定編集を行うメイン作業領域です。'),
            ('Bundled user tools are exposed through Add Modifier but remain lazy-loaded until executed.', '同梱ユーザーツールは「モディファイアを追加」から表示されますが、実行するまで本体は遅延読み込みのままです。'),
        ],
        'usage': [
            ('Select one or more mesh objects, press Add Modifier, then choose a Blender standard modifier or a bundled User tool. When multiple objects are selected, supported stack items are linked as one instanced modifier group.', 'メッシュオブジェクトを1つ以上選択し、「モディファイアを追加」からBlender標準モディファイアまたは同梱ユーザーツールを選びます。複数選択時、対応スタック項目は1つのインスタンス化モディファイアグループとしてリンクされます。'),
            ('Click Base Object or a modifier row to switch the active editing level. The row icons next to each modifier control On Cage, Edit Mode, Realtime Viewport, and Render directly in the stack list, without opening Blender’s Properties editor.', 'Base Object または各モディファイア行をクリックして編集レベルを切り替えます。各モディファイア行のアイコンで、ゲージ、編集モード、リアルタイム表示、レンダーをプロパティエディターを開かずに直接操作できます。'),
            ('Use Select Instances to select every linked member, or Release Instance to break one modifier out of the instance group while keeping its current settings.', '「インスタンスを選択」でリンクされた全メンバーを選択し、「インスタンス解除」で現在の設定を維持したまま1つのモディファイアだけインスタンスグループから切り離せます。'),
        ],
        'functions': [
            ('Add Modifier', 'モディファイアを追加', 'Opens the modifier/user-tool add popup.', 'モディファイア / ユーザーツール追加ポップアップを開きます。'),
            ('Reset XForm', 'Xフォームをリセット', 'Adds a stack entry that carries object rotation and scale, then resets the object rotation to 0 and scale to 1 while preserving the visible shape.', 'オブジェクトの回転とスケールを保持するスタック項目を追加し、見た目を維持したままオブジェクト側の回転を0、スケールを1に戻します。'),
            ('UVW Map', 'UVWマップ', 'Adds a stack entry that generates non-destructive planar UVMap coordinates through Geometry Nodes and a transformable Empty gizmo.', 'Geometry Nodesと変形可能なEmptyギズモで、非破壊の平面UVMap座標を生成するスタック項目を追加します。'),
            ('Unwrap UVW', 'UVアンラップ', 'Adds a stack entry that assigns and rebuilds UV coordinates using unwrap, flatten, planar, box, cylindrical, spherical, and pack workflows; detailed hand edits are done in Blender UV Editor.', 'アンラップ、展開、平面、ボックス、円柱、球、パックのワークフローでUV座標を割り当て・再生成するスタック項目を追加します。詳細な手動編集は Blender のUVエディターで行います。'),
            ('Max-compatible custom modifiers', 'Max 互換独自モディファイア', 'Adds Max-compatible modifier and stack-binding entries such as Chamfer, Shell, PathDeform, Skin, Cloth, Point Cache, Material, Selection, Mapping, World-Space, and Space Warp binding variants. They are distributed into the same workflow categories as other custom tools. Direct Blender equivalents create native modifiers; unsupported legacy items create stack-visible Geometry Nodes compatibility wrappers.', 'Chamfer、Shell、PathDeform、Skin、Cloth、Point Cache、Material、Selection、Mapping、World-Space、Space Warp Binding 系などの Max 互換モディファイア / スタックバインディング項目を追加します。これらは他の独自ツールと同じワークフロー別カテゴリへ分散表示されます。Blender に直接対応するものは標準モディファイアを作成し、未対応の旧項目はスタック表示可能な Geometry Nodes 互換ラッパーを作成します。'),
            ('Switch edit level', '編集レベル切り替え', 'Switches between Base Object and individual modifier levels.', 'Base Object と各モディファイアレベルを切り替えます。'),
            ('Display flags in stack rows', 'スタック行の表示フラグ', 'Toggles On Cage, Edit Mode, Realtime Viewport, and Render from the modifier row. When Modifier Auto Disable is ON, all four states on rows below the active slot are temporarily forced OFF. Their saved manual states are restored exactly or selected channels are forced ON according to Auto Disable Restore Behavior. The icons of a running row show its actual current state: a modifier added outside Smart Modifier stays active, with its icons ON, until the next time you switch the active row. A row Auto Disable has stopped is drawn faded; its icons show the state it returns to, and pressing one changes that state.', 'モディファイア行から、ケージ、編集モード、リアルタイム表示、レンダーを切り替えます。「モディファイア自動無効」がONのとき、アクティブスロットより下層の行は4項目すべてが一時的にOFFになります。保存した手動状態を正確に復元するか、選択項目を強制的にONにするかは「自動無効からの復元」で設定します。動いている行のアイコンは今の実際の状態を示します。Smart Modifier を通さずに足したモディファイアは、次に行を切り替えるまで動いたままで、アイコンもONです。自動無効で止まっている行は薄く出て、アイコンは動き出した時の状態を示し、押すとその状態が切り替わります。'),
            ('Edit selected modifier settings', '選択モディファイア設定編集', 'Shows editable parameters for the selected stack item when supported. Instanced groups synchronize compatible property edits across their linked objects.', '対応している場合、選択したスタック項目のパラメータを表示して編集します。インスタンスグループでは、対応するプロパティ編集がリンク先オブジェクトへ同期されます。'),
            ('Select Instances / Release Instance', 'インスタンスを選択 / インスタンス解除', 'Selects all objects sharing the same linked modifier, or converts only the chosen row into an independent modifier.', '同じリンクモディファイアを共有する全オブジェクトを選択、または選択行だけを独立したモディファイアへ変換します。'),
            ('Per-item actions', '項目別操作', 'Opens row menus for rename, move, selection, instance, and level-specific operations.', '名称変更、移動、選択、インスタンス、レベル固有操作などの行メニューを開きます。'),
        ],
        'settings_func': _modifier_stack_settings_pairs,
    },
    'modifier_switcher': {
        'icon': 'RESTRICT_VIEW_OFF',
        'title': ('Modifier Management', 'モディファイア管理'),
        'overview': [
            ('Batch manager for modifier visibility and saved visibility states across objects.', '複数オブジェクトにまたがるモディファイア表示状態と保存済み状態セットをまとめて管理する機能です。'),
            ('Auto Update is controlled in Always-on Toggles so the panel can stay idle when you do not need live list refresh.', '自動更新は「常時機能切り替え」で制御されるため、ライブ一覧更新が不要な時は待機負荷を抑えられます。'),
        ],
        'usage': [
            ('Use Update to build the lists manually, or enable Auto Update when you need the lists to stay synchronized while editing.', '手動で一覧を作る場合は「更新」を使い、編集しながら一覧同期が必要な場合だけ自動更新を有効にします。'),
            ('Choose the affect flags, select targets, then use ON / OFF / INVERT or apply a saved State Set.', '反映対象フラグを選び、対象を選択してから ON / OFF / 反転、または保存済み状態セットを適用します。'),
        ],
        'functions': [
            ('Update List', '一覧を更新', 'Scans objects and modifiers according to the current scope settings.', '現在の対象範囲設定に従ってオブジェクトとモディファイアをスキャンします。'),
            ('Toggle All ON / OFF / INVERT', '全てON / OFF / 反転', 'Batch-applies selected visibility states to listed modifier targets.', '一覧のモディファイア対象へ選択した表示状態を一括適用します。'),
            ('Object List', 'オブジェクト一覧', 'Shows and selects objects included in the current switcher scan.', '現在の切り替えスキャンに含まれるオブジェクトを表示・選択します。'),
            ('State Sets', '状態セット', 'Saves, overwrites, applies, or deletes named modifier visibility states.', '名前付きのモディファイア表示状態を保存、上書き、適用、削除します。'),
            ('Advanced Stack Operations', '高度なスタック操作', 'Moves, applies, or removes selected modifiers when the corresponding operator is available.', '対応オペレーターが利用可能な場合、選択モディファイアを移動、適用、削除します。'),
        ],
        'settings_func': _modswitch_settings_pairs,
    },
    'bundled_catalog': {
        'icon': 'OUTLINER_COLLECTION',
        'title': ('Bundled Tool Catalog', '同梱ツール一覧'),
        'overview': [
            ('Lists every bundled user tool that is available to Smart Modifier, grouped by workflow area.', 'Smart Modifier で利用できる同梱ユーザーツールを、ワークフロー別に一覧表示します。'),
            ('The catalog draws lightweight launch rows. Tool code is loaded only when that specific tool is executed.', 'カタログは軽量な起動行だけを描画します。各ツール本体は、そのツールを実行した時だけ読み込まれます。'),
            ('Max-compatible entries are merged into the same workflow categories as other custom modifiers, so there is no separate Max-only category in Add Modifier.', 'Max 互換項目は他の独自モディファイアと同じワークフロー別カテゴリへ統合されるため、「モディファイアを追加」内に独立した 3ds Max モディファイアカテゴリは表示されません。'),
        ],
        'usage': [
            ('Open a group and click the tool you need. The active object, selection, and mode requirements are shown in tooltips and reports when a tool cannot run.', 'グループを開いて必要なツールをクリックします。アクティブオブジェクト、選択、モード条件はツールチップや実行不可時のレポートで確認できます。'),
            ('Use this panel when a bundled function exists as code but does not need a dedicated standalone N-panel.', '同梱機能のコードは存在するが専用Nパネルを持たない場合、このパネルからアクセスします。'),
            ('For Max-compatible entries, choose the matching workflow category in Add Modifier, then tune the generated native modifier or compatibility wrapper in the stack row.', 'Max 互換項目は、「モディファイアを追加」内の対応するワークフロー別カテゴリから選び、生成された標準モディファイアまたは互換ラッパーをスタック行で調整します。'),
        ],
        'settings': [
            ('Tool-specific settings', 'ツール固有設定', 'Many bundled tools use the settings in Smart Modifier Hub, Precision / Layout / Path, or Advanced / Surface Modeling. Tools without persistent settings run from the current selection and operator defaults.', '多くの同梱ツールは Smart Modifier Hub、Precision / Layout / Path、Advanced / Surface Modeling 内の設定を使います。永続設定を持たないツールは、現在の選択状態とオペレーター初期値で実行されます。'),
        ],
        'catalog': True,
    },
    'smart_modifier_hub': {
        'icon': 'MODIFIER',
        'title': ('Smart Modifier Hub', 'スマートモディファイアハブ'),
        'overview': [
            ('Compact hub for common hard-surface, cleanup, curve, conform, scatter, and floor-generation workflows.', 'ハードサーフェス、クリーンアップ、カーブ、面追従、散布、床生成の主要ワークフローをまとめたコンパクトなハブです。'),
        ],
        'usage': [
            ('Choose the section that matches the current task, adjust only the visible parameters you need, then run the tool button in that section.', '現在の作業に合うセクションを選び、必要な表示パラメータだけ調整して、そのセクション内のツールボタンを実行します。'),
        ],
        'functions': [
            ('Build HS Boolean Stack', 'HSブーリアンスタックを構築', 'Creates a non-destructive boolean stack using selected cutters.', '選択カッターを使って非破壊ブーリアンスタックを作成します。'),
            ('Weighted Normal', '重み付き法線', 'Adds or refreshes Weighted Normal modifiers for clean hard-surface shading.', 'ハードサーフェスの陰影を整える重み付き法線モディファイアを追加 / 更新します。'),
            ('Quick Repair / Cleanup', 'クイック修復 / クリーンアップ', 'Runs conservative mesh cleanup using the hub cleanup settings.', 'Hub のクリーンアップ設定で保守的なメッシュ整理を実行します。'),
            ('Smart Fill / Quad Repair', 'スマートフィル / 四角面修復', 'Runs fill and quad-repair helpers for selected topology.', '選択トポロジーにフィル / 四角面修復補助を実行します。'),
            ('Make Pipe / Cable', 'パイプ / ケーブル作成', 'Builds beveled curve pipes from selected edges or curves.', '選択辺またはカーブからベベル付きパイプを作成します。'),
            ('Array Along Curve', 'カーブに沿って配列', 'Creates an Array + Curve setup for repeating objects along paths.', 'パスに沿って反復配置する Array + Curve 構成を作成します。'),
            ('Conform / Stitch To Surface', 'サーフェス追従 / 縫い合わせ', 'Adds or refreshes surface-conform modifiers for detail objects.', 'ディテールオブジェクト用のサーフェス追従モディファイアを追加 / 更新します。'),
            ('Scatter Instances (Bake)', 'インスタンス散布（ベイク）', 'Scatters linked instances across the active surface.', 'アクティブサーフェス上へリンクインスタンスを散布します。'),
            ('Floor Generator', '床生成', 'Generates floorboard pattern meshes from the active footprint.', 'アクティブ形状を基準に床板パターンメッシュを生成します。'),
        ],
        'settings_owner': ('scene', 'hub_props'),
    },
    'precision_layout_path': {
        'icon': 'ORIENTATION_CURSOR',
        'title': ('Precision / Layout / Path', '精密 / レイアウト / パス'),
        'overview': [
            ('Precision utilities for workplanes, projection, curve/path generation, layout alignment, replacement, randomization, audit, and CAD-like editing helpers.', '作業平面、投影、カーブ / パス生成、配置整列、置換、ランダム化、監査、CAD風編集を扱う精密作業用ツール群です。'),
        ],
        'usage': [
            ('Use it when placement, projection, path extraction, mesh QA, or predictable layout operations matter more than broad modeling presets.', '広いモデリングプリセットよりも、配置、投影、パス抽出、メッシュ品質確認、正確なレイアウト操作が重要な場合に使います。'),
        ],
        'functions': [
            ('Workplane From Active', 'アクティブから作業平面', 'Builds a cursor-oriented workplane from the active selection.', 'アクティブ選択からカーソル基準の作業平面を作成します。'),
            ('Projection tools', '投影ツール', 'Projects vertices to the active plane or selected surface.', '頂点をアクティブ平面または選択サーフェスへ投影します。'),
            ('Curve and path tools', 'カーブ / パスツール', 'Creates, rebuilds, lofts, and sweeps reusable curves and paths.', '再利用可能なカーブやパスを作成、再構築、ロフト、スイープします。'),
            ('Layout tools', 'レイアウトツール', 'Aligns, distributes, stacks, replaces, randomizes, solos, and floor-snaps selected objects.', '選択オブジェクトの整列、分布、積み重ね、置換、ランダム化、ソロ表示、床スナップを行います。'),
            ('CAD / Audit tools', 'CAD / 監査ツール', 'Runs face arrays, edge intersection/extension, axis slicing, mesh audit, repair, and issue selection.', '面配列、辺の交差 / 延長、軸スライス、メッシュ監査、修復、問題箇所選択を実行します。'),
        ],
        'settings_owner': ('scene', 'smsp_props'),
    },
    'advanced_surface_modeling': {
        'icon': 'MOD_BEVEL',
        'title': ('Advanced / Surface Modeling', '高度 / サーフェスモデリング'),
        'overview': [
            ('Advanced surface-first helpers for detail boxes, smart extrusion, slice helpers, clean joining, solidify, bend, twist, taper, lattice, cast, and surface dropping.', 'ディテール箱、スマート押し出し、スライス補助、結合整理、ソリッド化、ベンド、ツイスト、テーパー、ラティス、キャスト、面への配置を扱う高度なサーフェスモデリング補助です。'),
        ],
        'usage': [
            ('Use these tools after the broad shape exists and you need secondary forms, deformation helpers, panel cuts, thickness, or placement against another surface.', '大まかな形状ができた後、二次形状、変形補助、パネルカット、厚み付け、別サーフェスへの配置が必要な時に使います。'),
        ],
        'functions': [
            ('Surface Box Detail', 'サーフェス箱ディテール', 'Creates aligned helper boxes for kitbash and boolean detail work.', 'キットバッシュやブーリアンディテール用の整列済み補助ボックスを作成します。'),
            ('Smart Extrude Clean', 'スマート押し出し整理', 'Runs an inset/extrude/shrink-fatten helper for selected faces.', '選択面にインセット、押し出し、シュリンク / ファットン補助を実行します。'),
            ('Slice / Panel Stack', 'スライス / パネルスタック', 'Creates evenly spaced boolean helper boxes for grooves and panels.', '溝やパネル用に等間隔のブーリアン補助ボックスを作成します。'),
            ('Combine / Join Clean', '結合 / ジョイン整理', 'Joins selected meshes and optionally runs cleanup.', '選択メッシュを結合し、必要に応じてクリーンアップします。'),
            ('Deform / Thickness helpers', '変形 / 厚み補助', 'Creates Solidify, Bend, Twist, Taper, Lattice, and Cast modifier setups.', 'Solidify、Bend、Twist、Taper、Lattice、Cast のモディファイア構成を作成します。'),
            ('Drop To Surface', 'サーフェスへ落とす', 'Drops selected objects to a hit surface with optional alignment and bounds handling.', '選択オブジェクトをヒットしたサーフェスへ落とし、必要に応じて向き合わせやバウンド基準配置を行います。'),
        ],
        'settings_owner': ('scene', 'smsa_props'),
    },
}


_TOPIC_BASE.update({
    'settings_stack': {
        'icon': 'MODIFIER',
        'title': ('Modifier Stack Availability', 'モディファイアスタック利用可否'),
        'overview': [
            ('Controls whether the main Modifier Stack workspace is available in the N-panel.', 'Nパネルでメインのモディファイアスタック作業領域を利用できるかを制御します。'),
        ],
        'usage': [
            ('Enable it for normal Smart Modifier stack workflows. Disable it only when you want the stack UI hidden without removing existing modifiers.', '通常の Smart Modifier スタック作業では有効にします。既存モディファイアを削除せずスタックUIだけを非表示にしたい場合のみ無効にします。'),
        ],
        'settings': [
            ('Enable Smart Modifier', 'Smart Modifier を使用', 'Shows or hides the main stack workspace and its related controls. It does not delete modifiers or generated objects.', 'メインスタック作業領域と関連操作を表示 / 非表示にします。モディファイアや生成オブジェクトは削除しません。'),
        ],
    },
    'settings_bundled': {
        'icon': 'PREFERENCES',
        'title': ('Bundled Subtools', '同梱サブツール'),
        'overview': [
            ('Controls which bundled tool families are available from the N-panel and Add Modifier user-tool catalog.', 'Nパネルと「モディファイアを追加」のユーザーツール一覧で利用できる同梱ツール群を制御します。'),
        ],
        'usage': [
            ('Turn off a family when you do not need it displayed. This keeps the UI simpler and avoids loading that tool family until explicitly re-enabled.', '不要なツール群はOFFにします。UIを簡潔に保ち、そのツール群を明示的に再有効化するまで読み込みを避けます。'),
        ],
        'settings': [
            ('Enable Modifier Switcher', 'モディファイア管理を使用', 'Shows the batch visibility manager for modifier states. Its automatic refresh remains controlled by Always-on Toggles.', 'モディファイア状態の一括表示管理ツールを表示します。自動更新は「常時機能切り替え」で別管理します。'),
            ('Enable Edit Polygon Modifier (Bundled)', 'Edit Polygon Modifier（同梱サブツール）', 'Allows Edit Polygon stack entries and related maintenance tools to appear in the suite.', '編集ポリゴンスタック項目と関連メンテナンスツールをツールセット内に表示できるようにします。'),
            ('Enable Smart Lattice Modifier (Bundled)', 'Smart Lattice Modifier（同梱サブツール）', 'Allows Smart Lattice / FFD-style tools to appear. Live overlay and synchronization still obey the Always-on Toggles setting.', 'Smart Lattice / FFD 形式ツールを表示できるようにします。ライブオーバーレイと同期は「常時機能切り替え」に従います。'),
        ],
    },
    'settings_instance_copy': {
        'icon': 'LINKED',
        'title': ('Instance Copy', 'インスタンスコピー'),
        'overview': [
            ('Creates normal copies or 3ds Max-style object instances from the current object selection.', '現在のオブジェクト選択から、通常コピーまたは 3ds Max 風のオブジェクトインスタンスを作成します。'),
            ('Instance mode shares object data and uses Smart Modifier object-instance groups so modifier additions and compatible modifier settings stay synchronized across the group.', 'インスタンス方式ではオブジェクトデータを共有し、Smart Modifier のオブジェクトインスタンスグループを使って、モディファイア追加や対応する設定変更をグループ全体で同期します。'),
        ],
        'usage': [
            ('Select one or more objects, press Instance Copy, choose Normal or Instance, then set count and offset.', 'オブジェクトを1つ以上選択し、「インスタンスコピー」を押して、通常またはインスタンスを選び、コピー数とオフセットを設定します。'),
            ('Use Release Instance when selected instance objects should become independent while keeping their current stack state.', '選択中のインスタンスオブジェクトを現在のスタック状態のまま独立させたい場合は「インスタンス解除」を使います。'),
            ('Drag Clone uses manual keymap registration only; copy the operator ID from the shortcut section and assign the desired key/mouse combination in Blender Preferences.', 'ドラッグクローンは手動キーマップ登録だけを使用します。ショートカット項目の登録IDをコピーし、Blender のプリファレンスで使いたいキー / マウス操作へ割り当てます。'),
        ],
        'settings': [
            ('Instance Copy', 'インスタンスコピー', 'Opens the copy/instance dialog. Instance mode also links Smart Modifier modifier instances.', 'コピー / インスタンスのダイアログを開きます。インスタンス方式では Smart Modifier のモディファイアインスタンスもリンクします。'),
            ('Release Instance', 'インスタンス解除', 'Makes selected instance objects independent by copying their object data and clearing Smart Modifier instance IDs.', '選択中のインスタンスオブジェクトのデータをコピーし、Smart Modifier のインスタンスIDを解除して独立化します。'),
        ],
    },
    'settings_max_shift_drag_clone': {
        'icon': 'MOUSE_LMB_DRAG',
        'title': ('Drag Clone', 'ドラッグクローン'),
        'overview': [
            ("Starts a clone from a manually registered shortcut, typically Shift + left-drag, and applies the drag transform directly so the clone does not lock when Blender's active tool does not take over the event.", '手動登録したショートカット、通常は Shift + 左ドラッグからクローンを開始し、ドラッグ変形をアドオン側で直接適用します。Blender のアクティブツールがイベントを引き継がない場合でもクローンがロックされません。'),
            ("Object Mode supports Copy and Instance. Instance keeps Smart Modifier object-instance groups and modifier-instance synchronization, matching this suite\'s existing instance-copy behavior.", 'オブジェクトモードではコピーとインスタンスに対応します。インスタンスでは本スイート既存のインスタンスコピーと同じく、オブジェクトインスタンスグループとモディファイアインスタンス同期を維持します。'),
        ],
        'usage': [
            ('Manually register the Drag Clone operator ID in Blender Preferences > Keymap. For 3ds Max-style use, assign it to Shift + Left Mouse in 3D View, then drag. After releasing the mouse, choose clone type and number of copies.', 'Drag Clone の登録IDを Blender のプリファレンス > キーマップへ手動登録します。3ds Max 風に使う場合は、3Dビューで Shift + 左マウスに割り当ててからドラッグします。マウスを離した後、クローン方式とコピー数を選びます。'),
            ('In Edit Mesh, vertex mode duplicates selected vertices, boundary-edge mode extrudes bridged contour edges, and face mode duplicates selected faces at drag start.', 'Edit Mesh では、頂点モードは選択頂点、輪郭線の辺モードはブリッジ面付きの輪郭辺、面モードは選択面をドラッグ開始時に複製します。'),
        ],
        'settings': [
            ('Default Clone Type', '既定のクローン方式', 'Sets the initial Copy or Instance choice shown in the confirmation dialog.', '確定ダイアログで最初に表示されるコピー / インスタンス方式を設定します。'),
            ('Default Number of Copies', '既定のコピー数', 'Sets the initial total number of repeated clones. The dragged clone counts as the first copy.', '繰り返しクローンの初期総数を設定します。ドラッグしたクローンが1個目として数えられます。'),
        ],
    },
    'settings_instance_copy_shortcuts': {
        'icon': 'KEYINGSET',
        'title': ('Instance Copy Shortcut IDs', 'インスタンスコピーのショートカットID'),
        'overview': [
            ('Shows operator IDs that can be copied into Blender keymap items.', 'Blender のキーマップ項目へコピーできるオペレーターIDを表示します。'),
        ],
        'usage': [
            ('For the dialog-based buttons, use Preferences > Keymap > 3D View > Object Mode.', 'ダイアログ式のボタンは、プリファレンス > キーマップ > 3Dビュー > オブジェクトモード に登録します。'),
            ('Drag Clone uses only manually registered keymap items. Copy the Drag Clone ID from the bottom of this section and add it in Blender Preferences > Keymap. Recommended assignment: 3D View > 3D View (Global) > Shift + Left Mouse.', 'ドラッグクローンは手動登録されたキーマップ項目だけを使用します。このセクション最下部のドラッグクローンIDをコピーし、Blender のプリファレンス > キーマップへ追加してください。推奨割り当ては 3Dビュー > 3Dビュー（グローバル） > Shift + 左マウスです。'),
        ],
        'settings': [
            ('Instance Copy ID', 'インスタンスコピーID', 'object.sms_instance_copy', 'object.sms_instance_copy'),
            ('Release Instance ID', 'インスタンス解除ID', 'object.sms_instance_make_unique', 'object.sms_instance_make_unique'),
            ('Drag Clone ID', 'ドラッグクローンID', 'view3d.max_shift_drag_clone', 'view3d.max_shift_drag_clone'),
        ],
    },
    'settings_show_end_result_shortcut': {
        'icon': 'KEYINGSET',
        'title': ('Show End Result Shortcut', '最終結果を表示ショートカット'),
        'overview': [
            ('Shows the operator ID used to register a keyboard shortcut for toggling Show End Result.', '「最終結果を表示」のON/OFFをショートカット登録するためのオペレーターIDを表示します。'),
        ],
        'usage': [
            ('Open Blender Preferences > Keymap > 3D View > 3D View (Global), add a new keymap item, then paste the displayed operator ID.', 'Blender の プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）を開き、新規キーマップ項目を追加して、表示されているオペレーターIDを貼り付けます。'),
            ('The shortcut toggles EndPreview only for the active Smart Modifier base mesh. When the setting is OFF, EndPreview is removed and not regenerated.', 'ショートカットはアクティブな Smart Modifier ベースメッシュの EndPreview 表示だけを切り替えます。OFF時は EndPreview を削除し、再生成しません。'),
        ],
        'settings': [
            ('Registration ID', '登録ID', 'Copy this exact operator ID into the keymap item: object.ms_toggle_show_end_result', 'この正確なオペレーターIDをキーマップ項目にコピーします: object.ms_toggle_show_end_result'),
            ('Recommended location', '推奨登録場所', 'Preferences > Keymap > 3D View > 3D View (Global)', 'プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）'),
        ],
    },
    'settings_stack_display': {
        'icon': 'SORTSIZE',
        'title': ('Modifier Stack Display', 'モディファイアスタック表示'),
        'overview': [
            ('Controls only how the stack list is displayed in the N-panel.', 'Nパネル内のスタックリスト表示方法だけを制御します。'),
        ],
        'usage': [
            ('Choose the order that matches your preferred reading direction. This does not reorder Blender modifiers; it only changes the N-panel presentation.', '好みの読み順に合わせて表示順を選びます。Blender本体のモディファイア順序は変更せず、Nパネル上の見え方だけを変えます。'),
        ],
        'settings': [
            ('Base Object Top', 'ベースオブジェクトを上', 'Shows the Base Object row before modifier rows, matching a top-down source-to-result reading style.', 'Base Object 行をモディファイア行より上に表示し、上から下へ元形状から結果へ読む形式にします。'),
            ('Base Object Bottom', 'ベースオブジェクトを下', 'Shows the Base Object row below modifier rows, useful when you want the latest or final modifier rows closer to the top.', 'Base Object 行をモディファイア行より下に表示し、最新または最終側モディファイア行を上の方で見たい場合に使います。'),
            ('Stack Order', 'スタック表示順', 'Persistent setting saved with the N-panel state and restored after restart or file changes.', 'Nパネル状態として保存され、再起動後やファイル変更後にも復元される永続設定です。'),
        ],
    },
    'settings_auto_disable_restore': {
        'icon': 'MODIFIER',
        'title': ('Auto Disable Restore', '自動無効からの復元'),
        'overview': [
            ('Controls how the four modifier-header display states are restored when a modifier leaves temporary suppression caused by Modifier Auto Disable.', '「モディファイア自動無効」で一時的に無効化されたモディファイアが有効範囲へ戻る時、4つのモディファイアヘッダー表示状態をどのように復元するかを制御します。'),
            ('The saved channels are On Cage, Edit Mode, Realtime Viewport, and Render. The policy applies to Blender standard modifiers, Geometry Nodes modifiers, bundled/custom modifiers, and Smart Modifier modifier instances.', '保存対象は、ケージ、編集モード、リアルタイム、レンダーです。Blender標準モディファイア、Geometry Nodesモディファイア、同梱・独自モディファイア、Smart Modifierのインスタンスモディファイアへ共通して適用されます。'),
        ],
        'usage': [
            ('Choose Preserve Current States when each modifier must return to exactly the same ON/OFF combination it had before temporary suppression.', '一時無効化前と完全に同じON/OFFの組み合わせへ戻したい場合は「現在の有効・無効状態を維持」を選びます。'),
            ('Choose Force Enable Selected States, then press the icon buttons for the channels that must always become ON when the modifier becomes active again. Unselected channels keep their saved state.', 'モディファイアが再びアクティブになった時に必ずONにしたい項目がある場合は「選択項目を強制有効」を選び、対象のアイコンボタンを押します。選択していない項目は保存状態を維持します。'),
            ('The force policy is applied only when a row actually leaves Auto Disable suppression. After restoration, you can manually change the row icons without the setting continuously turning them back ON.', '強制有効は、行が実際に自動無効状態から戻る瞬間だけ適用されます。復元後に行アイコンを手動変更しても、設定が継続的にONへ戻すことはありません。'),
            ('If Modifier Auto Disable itself is turned OFF while rows are suppressed, the original saved states are restored without force-enabling channels.', '行が一時無効の状態で「モディファイア自動無効」自体をOFFにした場合は、強制有効を適用せず、元の保存状態を復元します。'),
        ],
        'settings': [
            ('Preserve Current States', '現在の有効・無効状態を維持', 'Restores On Cage, Edit Mode, Realtime Viewport, and Render exactly as saved before temporary suppression.', 'ケージ、編集モード、リアルタイム、レンダーを、一時無効化前に保存した状態へ正確に戻します。'),
            ('Force Enable Selected States', '選択項目を強制有効', 'Restores the saved states, then turns ON only the channels selected by the four icon buttons.', '保存状態を復元した後、4つのアイコンボタンで選択した項目だけをONにします。'),
            ('On Cage icon', 'ケージアイコン', 'When selected, On Cage is forced ON during restoration.', '選択時、復元時に「ケージで表示」を強制的にONにします。'),
            ('Edit Mode icon', '編集モードアイコン', 'When selected, Show in Edit Mode is forced ON during restoration.', '選択時、復元時に「編集モードで表示」を強制的にONにします。'),
            ('Realtime Viewport icon', 'リアルタイムアイコン', 'When selected, Realtime Viewport is forced ON during restoration.', '選択時、復元時に「リアルタイムで表示」を強制的にONにします。'),
            ('Render icon', 'レンダーアイコン', 'When selected, Render is forced ON during restoration.', '選択時、復元時に「レンダーで表示」を強制的にONにします。'),
            ('N-panel State Save', 'Nパネル状態保存', 'Saves the restore mode and all four force-enable icon states together with the other Smart Modifier N-panel settings.', '復元モードと4つの強制有効アイコン状態を、他の Smart Modifier Nパネル設定と一緒に保存します。'),
        ],
    },
    'modifier_stack_add_modifier': {
        'icon': 'ADD',
        'title': ('Add Modifier Controls', 'モディファイア追加操作'),
        'overview': [
            ('Adds Blender standard modifiers, bundled Smart Modifier tools, and 3ds Max-compatible modifiers from one stack-oriented popup.', 'Blender標準モディファイア、同梱 Smart Modifier ツール、3ds Max 互換モディファイアを、1つのスタック指向ポップアップから追加します。'),
        ],
        'usage': [
            ('Select one or more mesh objects, click Add Modifier, then choose the target category and tool. Multi-object additions use instance-linking when supported.', 'メッシュオブジェクトを1つ以上選択し、「モディファイアを追加」をクリックして、カテゴリとツールを選びます。複数オブジェクトへの追加では、対応項目はインスタンスリンクされます。'),
            ('Use Modifier Auto Disable beside the button to decide whether switching the active stack item temporarily mutes below/later modifiers. Use Show End Result to display the final evaluated result through EndPreview while that isolation is active.', 'ボタン横の「モディファイア自動無効」で、アクティブなスタック項目を切り替えた時に下/後段モディファイアを一時ミュートするかを決めます。「最終結果を表示」は、その分離中に EndPreview で最終評価結果を表示します。'),
        ],
        'settings': [
            ('Add Modifier', 'モディファイアを追加', 'Opens the category popup without loading heavy subtool modules until a tool is executed.', 'ツール実行時まで重いサブツールモジュールを読み込まず、カテゴリポップアップを開きます。'),
            ('Modifier Auto Disable', 'モディファイア自動無効', 'When enabled, only modifiers up to the active stack item are evaluated on the editable object. When disabled, Smart Modifier does not auto-mute modifiers because of the active slot.', '有効時は、編集対象オブジェクト上でアクティブなスタック項目までのモディファイアだけを評価します。無効時は、アクティブスロットを理由にモディファイアを自動ミュートしません。'),
            ('Show End Result', '最終結果を表示', 'When enabled, EndPreview displays the final evaluated stack while Modifier Auto Disable isolates the active edit level. When disabled, EndPreview is not generated.', '有効時は、モディファイア自動無効でアクティブ編集階層を分離しながら、EndPreview で最終評価スタックを表示します。無効時は EndPreview を生成しません。'),
            ('Multi-object instance add', '複数オブジェクトのインスタンス追加', 'Supported modifiers added to several selected objects share a logical instance group so compatible property changes synchronize.', '複数選択へ追加した対応モディファイアは論理インスタンスグループを共有し、対応プロパティ変更を同期します。'),
        ],
    },
    'modifier_stack_properties': {
        'icon': 'PREFERENCES',
        'title': ('Modifier Stack Properties', 'モディファイアスタックプロパティ'),
        'overview': [
            ('Shows editable properties for the selected stack item directly inside the N-panel.', '選択したスタック項目の編集可能プロパティをNパネル内に直接表示します。'),
        ],
        'usage': [
            ('Select a modifier row, open Property Items Display, then adjust the shown values. Instance-linked modifiers synchronize compatible values to their linked objects.', 'モディファイア行を選択し、「プロパティ項目の表示」を開いて表示値を調整します。インスタンスリンクされたモディファイアは、対応値をリンク先オブジェクトへ同期します。'),
        ],
        'settings': [
            ('Property Items Display', 'プロパティ項目の表示', 'Expands or collapses the selected stack item property area without changing any value.', '値を変更せず、選択スタック項目のプロパティ欄だけを開閉します。'),
            ('Viewport / Render / Edit Mode / On Cage', 'Viewport / Render / Edit Mode / On Cage', 'These buttons mirror Blender modifier header states and can be edited from the stack row.', 'Blender標準モディファイアヘッダーの状態と同じ意味を持ち、スタック行から編集できます。'),
            ('Max Parameters', 'Maxパラメータ', '3ds Max-compatible wrapper rows expose supported fields such as Amount, Strength, Angle, Radius, Segments, Map Channel, tiling, offset, seed, and material ID.', '3ds Max互換ラッパー行では、Amount、Strength、Angle、Radius、Segments、Map Channel、タイリング、オフセット、シード、マテリアルIDなど対応項目を表示します。'),
            ('Release Instance', 'インスタンス解除', 'Detaches the selected modifier row from its instance group while preserving current values.', '現在値を保持したまま、選択モディファイア行をインスタンスグループから切り離します。'),
        ],
    },
    'edit_poly_maintenance': {
        'icon': 'FILE_REFRESH',
        'title': ('Edit Polygon Maintenance', '編集ポリゴンメンテナンス'),
        'overview': [
            ('Maintenance commands for Edit Polygon stack layers that need rebaking or edit-level synchronization after topology changes.', 'トポロジー変更後に再ベイクや編集レベル同期が必要な 編集ポリゴンスタックレイヤー用のメンテナンス操作です。'),
        ],
        'usage': [
            ('Use Re-bake All after heavy mesh edits or when Edit Polygon preview data no longer matches the underlying mesh.', '大きなメッシュ編集後、または 編集ポリゴンのプレビューデータが元メッシュと合わなくなった時に「全て再ベイク」を使います。'),
            ('Use Switch Level Hijack only for the active Edit Polygon row when you need to force the edit level back onto that layer.', 'アクティブな編集ポリゴン行へ編集レベルを強制的に戻したい場合のみ、「レベル切り替えハイジャック」を使います。'),
        ],
        'settings': [
            ('Re-bake All', '全て再ベイク', 'Refreshes stored Edit Polygon layer data from the current mesh state.', '現在のメッシュ状態から保存済み編集ポリゴンレイヤーデータを更新します。'),
            ('Switch Level Hijack', 'レベル切り替えハイジャック', 'Forces the selected Edit Polygon layer to become the active edit level when normal switching cannot recover the state.', '通常の切り替えで状態を復帰できない場合に、選択編集ポリゴンレイヤーをアクティブ編集レベルへ強制します。'),
        ],
    },
})

_SUBTOPICS = {
    'hub_hard_surface': ('smart_modifier_hub', ('boolean_operation', 'boolean_solver', 'hs_auto_bevel', 'hs_bevel_width', 'hs_bevel_segments', 'hs_weighted_normal', 'hs_organize_cutters'), [('Build HS Boolean Stack', 'HSブーリアンスタックを構築')]),
    'hub_topology_repair': ('smart_modifier_hub', ('cleanup_merge_distance', 'cleanup_fill_holes', 'cleanup_join_tris', 'cleanup_recalc_normals'), [('Quick Repair / Cleanup', 'クイック修復 / クリーンアップ'), ('Smart Fill / Quad Repair', 'スマートフィル / 四角面修復'), ('Detach / Separate Clean', '分離 / セパレート整理'), ('Relax Selection', '選択をリラックス'), ('Circle Selection', '選択を円形化'), ('Straighten Selection', '選択を直線化')]),
    'hub_curves_repetition': ('smart_modifier_hub', ('pipe_radius', 'pipe_resolution', 'pipe_fill_caps', 'array_offset_x', 'array_count', 'array_merge_vertices'), [('Make Pipe / Cable', 'パイプ / ケーブル作成'), ('Array Along Curve', 'カーブに沿って配列')]),
    'hub_conform_surface': ('smart_modifier_hub', ('conform_mode', 'conform_offset', 'conform_parent', 'conform_organize'), [('Conform / Stitch To Surface', 'サーフェス追従 / 縫い合わせ')]),
    'hub_scatter_environment': ('smart_modifier_hub', ('scatter_count', 'scatter_seed', 'scatter_scale_min', 'scatter_scale_max', 'scatter_random_z_deg', 'scatter_align_normal', 'scatter_surface_offset'), [('Scatter Instances (Bake)', 'インスタンス散布（ベイク）')]),
    'hub_floor_generator': ('smart_modifier_hub', ('floor_board_width', 'floor_board_length', 'floor_gap', 'floor_thickness', 'floor_stagger', 'floor_axis'), [('Floor Generator', '床生成')]),
    'precision_workplane_projection': ('precision_layout_path', ('workplane_use_cursor_pivot', 'workplane_use_cursor_orientation', 'project_offset'), [('Workplane From Active', 'アクティブから作業平面'), ('Project To Active Plane', 'アクティブ平面へ投影')]),
    'precision_surface_retopo': ('precision_layout_path', ('surface_project_offset', 'curve_rebuild_count', 'curve_rebuild_keep_original'), [('Project To Selected Surface', '選択サーフェスへ投影'), ('Rebuild Active Curve', 'アクティブカーブ再構築')]),
    'precision_curves_paths': ('precision_layout_path', ('curve_rebuild_count', 'curve_rebuild_keep_original', 'profile_primitive_type', 'profile_width', 'profile_height', 'profile_points', 'profile_star_inner', 'helix_radius', 'helix_height', 'helix_turns', 'helix_points_per_turn', 'helix_taper', 'helix_clockwise', 'objects_to_path_use_nearest', 'objects_to_path_cyclic', 'vertices_to_path_use_nearest', 'vertices_to_path_cyclic', 'sweep_duplicate_path', 'sweep_fill_caps', 'sweep_resolution_u', 'loft_sample_count', 'loft_shade_smooth'), [('Rebuild Active Curve', 'アクティブカーブ再構築'), ('Selected Edges To Curve', '選択辺をカーブへ'), ('Selected Vertices To Path', '選択頂点をパスへ'), ('Selected Objects To Path', '選択オブジェクトをパスへ'), ('Loft / Bridge Paths', 'ロフト / パスブリッジ'), ('Sweep Active Profile', 'アクティブ断面をスイープ'), ('Add Profile Primitive', '断面プリミティブ追加'), ('Add Helix Path', 'ヘリックスパス追加')]),
    'precision_cad_audit': ('precision_layout_path', ('face_component_selected_faces_only', 'face_component_scale_to_face', 'face_component_scale', 'face_component_offset', 'face_component_linked_data', 'cad_mode', 'audit_merge_distance', 'audit_issue_filter', 'axis_slice_axis', 'axis_slice_count', 'axis_slice_use_selection_bounds', 'axis_slice_select_new', 'axis_slice_tolerance'), [('Face Component Array', '面コンポーネント配列'), ('CAD Intersect / Extend', 'CAD交差 / 延長'), ('Audit Selected', '選択を監査'), ('Select Issues', '問題箇所を選択'), ('Axis Slice Edit', '軸スライス編集')]),
    'precision_path_layout': ('precision_layout_path', ('path_count', 'path_include_ends', 'path_follow_tangent', 'path_random_roll_deg', 'path_linked_data', 'path_organize', 'align_location', 'align_rotation', 'align_scale', 'align_axis_x', 'align_axis_y', 'align_axis_z', 'distribute_axis', 'stack_axis', 'stack_gap', 'replace_linked_data', 'replace_delete_targets', 'replace_preserve_collections', 'random_seed', 'random_xy_offset', 'random_z_offset', 'random_z_rotation_deg', 'random_scale_min', 'random_scale_max', 'drop_to_floor_use_cursor_z', 'drop_to_floor_z'), [('Instances Along Path', 'パスに沿ってインスタンス'), ('Align To Active', 'アクティブに整列'), ('Distribute Selected', '選択を分布'), ('Stack Selected', '選択を積み重ね'), ('Replace With Active', 'アクティブで置換'), ('Randomize Selected', '選択をランダム化'), ('Solo Selected', '選択だけ表示'), ('Drop To Floor', '床へ落とす')]),
    'advanced_surface_detail': ('advanced_surface_modeling', ('surface_box_width', 'surface_box_length', 'surface_box_height', 'surface_box_operation', 'surface_box_wire', 'surface_box_parent'), [('Surface Box Detail', 'サーフェス箱ディテール')]),
    'advanced_extrude_slice': ('advanced_surface_modeling', ('smart_extrude_inset', 'smart_extrude_distance', 'smart_extrude_even', 'smart_extrude_recalc', 'slice_axis', 'slice_count', 'slice_thickness', 'slice_operation', 'slice_wire', 'slice_organize'), [('Smart Extrude Clean', 'スマート押し出し整理'), ('Slice / Panel Stack', 'スライス / パネルスタック')]),
    'advanced_assembly_drop': ('advanced_surface_modeling', ('combine_cleanup', 'combine_cleanup_normals', 'drop_offset', 'drop_align_to_surface', 'drop_use_bounds'), [('Combine / Join Clean', '結合 / ジョイン整理'), ('Drop To Surface', 'サーフェスへ落とす')]),
    'switcher_modifier_list': ('modifier_switcher', ('modswitch_filter_targets', 'modswitch_affect_viewport', 'modswitch_affect_render', 'modswitch_affect_editmode', 'modswitch_affect_on_cage', 'modswitch_affect_expanded'), [('Modifier List', 'モディファイア一覧'), ('Target Filter', 'ターゲットフィルター'), ('Batch ON / OFF / Invert', '一括 ON / OFF / 反転')]),
    'switcher_object_list': ('modifier_switcher', ('modswitch_filter_objects', 'modswitch_show_stack_instances', 'modswitch_visible_only', 'modswitch_scope', 'modswitch_scope_collection'), [('Object List', 'オブジェクト一覧'), ('Select All Listed', '一覧を全選択')]),
    'switcher_state_sets': ('modifier_switcher', ('modswitch_new_state_set_name', 'modswitch_state_set_index'), [('State Sets', '状態セット'), ('Save New / Overwrite / Apply / Delete', '新規保存 / 上書き / 適用 / 削除')]),
    'switcher_details': ('modifier_switcher', ('modswitch_mode', 'modswitch_scope', 'modswitch_visible_only', 'modswitch_selection_behavior', 'modswitch_refresh_interval', 'modswitch_affect_expanded'), [('Details', '詳細'), ('Update List', '一覧更新'), ('Move / Apply / Remove modifiers', '移動 / 適用 / 削除')]),
}




_TOPIC_BASE.update({
    'reset_xform_modifier': {
        'icon': 'MODIFIER',
        'title': ('Reset XForm', 'Xフォームをリセット'),
        'overview': [
            ('Stack-managed 3ds Max-style Reset XForm. It transfers rotation and scale into an editable stack row, then resets the object transform to clean values while preserving the visible shape.', '3ds Max 風のスタック管理式 Reset XForm です。回転とスケールを編集可能なスタック行へ移し、見た目を維持したままオブジェクト変換をクリーンな値へ戻します。'),
        ],
        'usage': [
            ('Add it from Add Modifier > Transform / XForm > Reset XForm, then edit Translation, Rotation, and Scale from the stack property area.', 'モディファイアを追加 > Transform / XForm > Reset XForm から追加し、スタックプロパティ欄で移動・回転・スケールを編集します。'),
            ('When added to multiple selected objects, supported rows are instance-linked. Use Release Instance to detach only one object.', '複数選択へ追加した場合、対応行はインスタンスリンクされます。1つだけ切り離す場合は「インスタンス解除」を使います。'),
        ],
        'settings': [
            ('Translation', '移動', 'Optional stack-level offset applied by the Reset XForm row. The initial Reset XForm operation keeps this at zero unless an offset is needed.', 'Reset XForm 行で適用する任意のスタックレベル移動量です。通常の初期リセットでは、必要がない限り0のままです。'),
            ('Rotation', '回転', 'Rotation stored on the stack row after the object transform is reset.', 'オブジェクト変換をリセットした後、スタック行に保持される回転値です。'),
            ('Scale', 'スケール', 'Scale stored on the stack row after the object transform is reset.', 'オブジェクト変換をリセットした後、スタック行に保持されるスケール値です。'),
        ],
    },
    'uvw_map_modifier': {
        'icon': 'MOD_UVPROJECT',
        'title': ('UVW Map', 'UVWマップ'),
        'overview': [
            ('Stack-managed 3ds Max-style UVW Map generated non-destructively from a Smart_Connect_UVW_Gizmo Empty.', 'Smart_Connect_UVW_Gizmo Empty から非破壊で UV を生成する、3ds Max 風のスタック管理式 UVW マップです。'),
        ],
        'usage': [
            ('Choose the Mapping, then move, rotate or scale the gizmo. The gizmo scale is the map length, width and height. Select Gizmo selects the Empty.', 'マッピングを選び、ギズモを移動・回転・スケールします。ギズモのスケールがマップの長さ・幅・高さです。「ギズモを選択」で Empty を選びます。'),
        ],
        'settings': [
            ('Mapping', 'マッピング', 'Planar, Cylindrical, Spherical, Shrink Wrap, Box, Face or XYZ to UVW. XYZ to UVW uses the object coordinates and ignores the gizmo.', '平面・円柱・球・シュリンクラップ・ボックス・フェース・XYZ to UVW から選びます。XYZ to UVW はオブジェクトの座標を使い、ギズモは使いません。'),
            ('Cap', 'キャップ', 'Cylindrical only. Faces that look along the gizmo Z axis get planar mapping.', '円柱のときだけ使います。ギズモの Z 軸を向く面に平面の投影を使います。'),
            ('U Tile / V Tile', 'U タイル / V タイル', 'Repeats the map along U and V.', 'U 方向と V 方向の繰り返し回数です。'),
            ('Flip U / Flip V', 'U 反転 / V 反転', 'Mirrors the map along U or V.', 'U 方向または V 方向に反転します。'),
            ('UV Map', 'UV マップ', 'Name of the UV map to write. It corresponds to the 3ds Max map channel.', '書き込む UV マップの名前です。3ds Max のマップチャンネルに当たります。'),
            ('Gizmo', 'ギズモ', 'Location, rotation and scale place the projection. W is not stored because Blender UV maps are 2D.', '位置・回転・スケールで投影を決めます。Blender の UV は 2 次元なので W は保存しません。'),
        ],
    },
    'unwrap_uvw_modifier': {
        'icon': 'GROUP_UVS',
        'title': ('Unwrap UVW', 'UVアンラップ'),
        'overview': [
            ('Stack-managed 3ds Max-style Unwrap UVW entry for assigning, rebuilding, packing, and later manually editing UV coordinates.', 'UV座標の割り当て、再生成、パック、後続の手動編集を扱う 3ds Max 風のスタック管理式 Unwrap UVW です。'),
        ],
        'usage': [
            ('Choose an unwrap method, set map channel and options, then press Edit / Rebuild. Fine island and seam edits are still performed in Blender UV Editor.', 'アンラップ方式、マップチャンネル、各オプションを設定して「編集 / 再生成」を押します。アイランドやシームの細かな編集は Blender のUVエディターで行います。'),
            ('Use Restore to return to the UV backup captured before the stack row changed the map.', '「復元」は、このスタック行がUVを変更する前に取得したバックアップへ戻します。'),
        ],
        'settings': [
            ('Unwrap Method', 'アンラップ方式', 'Angle Based, Conformal, Smart Project / Flatten, Quick Planar, Box, Cylindrical, Spherical, or Pack workflow.', '角度ベース、コンフォーマル、スマート投影 / 展開、クイック平面、ボックス、円柱、球、パックのワークフローです。'),
            ('Map Channel / UV Map', 'マップチャンネル / UVマップ', 'Target Blender UV layer used as the editable map channel.', '編集対象マップチャンネルとして使う Blender UV レイヤーです。'),
            ('Selected Faces Only', '選択フェースのみ', 'Restricts UV generation to the current face selection when possible.', '可能な場合、現在のフェース選択だけにUV生成を限定します。'),
            ('Island Margin', 'アイランド余白', 'Spacing between islands during packing and smart projection.', 'パックやスマート投影時のアイランド間隔です。'),
            ('Pack Islands', 'アイランドをパック', 'Packs generated islands into the 0-1 UV range after creation.', '生成後のアイランドを0-1のUV範囲へ配置します。'),
            ('Angle Limit', '角度制限', 'Cut threshold used by smart flatten-style unwrapping.', 'スマート展開系で切れ目を判断する角度しきい値です。'),
            ('Area Weight', '面積ウェイト', 'Weights UV generation by polygon area when the method supports it.', '対応方式でポリゴン面積を考慮してUV生成します。'),
            ('Correct Aspect', 'アスペクト補正', 'Compensates for image or texture aspect ratio during UV generation.', 'UV生成時に画像またはテクスチャの縦横比を補正します。'),
            ('Scale / Clip To Bounds', '範囲へスケール / クリップ', 'Controls whether generated UVs are scaled or clipped into the 0-1 area.', '生成UVを0-1範囲へスケールまたはクリップするかを制御します。'),
            ('Cube Size / Projection Radius', 'ボックスサイズ / 投影半径', 'Projection dimensions used by box, cylindrical, and spherical methods.', 'ボックス、円柱、球方式で使う投影寸法です。'),
        ],
    },
    'max_modifier_parameters': {
        'icon': 'MODIFIER',
        'title': ('3ds Max Modifier Parameters', '3ds Max モディファイアパラメータ'),
        'overview': [
            ('Editable parameter area for 3ds Max-compatible modifiers created by the compatibility library.', '互換ライブラリで作成した 3ds Max 互換モディファイアの編集可能パラメータ欄です。'),
        ],
        'usage': [
            ('Edit the exposed values directly in the stack row. If the modifier is instance-linked across objects, compatible values synchronize to the other members.', '表示された値をスタック行内で直接編集します。モディファイアが複数オブジェクトでインスタンスリンクされている場合、対応値は他メンバーへ同期されます。'),
            ('Use Release Instance from the modifier row menu when only one object should stop sharing synchronized parameters.', '1つのオブジェクトだけ同期パラメータ共有をやめる場合は、モディファイア行メニューの「インスタンス解除」を使います。'),
        ],
        'settings': [
            ('3ds Max equivalent', '3ds Max 相当', 'Shows the original 3ds Max modifier concept represented by this Blender stack row.', 'この Blender スタック行が表す元の 3ds Max モディファイア概念を表示します。'),
            ('Category', 'カテゴリ', 'Shows the Max-compatible modifier group such as Deform, Mapping, Selection, World-Space, Space Warp Binding, or Utility.', 'Deform、Mapping、Selection、World-Space、Space Warp Binding、Utility などの Max 互換分類を表示します。'),
            ('Amount / Strength / Angle / Radius', '量 / 強度 / 角度 / 半径', 'Common generated parameters for deformers, offsets, displacements, and falloff-style wrappers.', '変形、オフセット、ディスプレイス、フォールオフ系ラッパーでよく使う生成パラメータです。'),
            ('Segments / Iterations / Tolerance', 'セグメント / 反復 / 許容値', 'Controls subdivision, smoothing, cleanup, or approximation quality when supported.', '対応項目で分割、スムージング、クリーンアップ、近似品質を制御します。'),
            ('Map Channel / Tiling / Offset / Rotation', 'マップチャンネル / タイリング / オフセット / 回転', 'Mapping-oriented values for UV, material, and projection compatibility entries.', 'UV、マテリアル、投影互換項目向けのマッピング系値です。'),
            ('Seed / Material ID / Preserve Boundaries', 'シード / マテリアルID / 境界保持', 'Category-specific values used by randomization, material, and topology-preserving wrappers.', 'ランダム化、マテリアル、トポロジー保持系ラッパーで使うカテゴリ固有値です。'),
            ('Mirror: Scale / Offset / Copy / Center / Rotation / Weld Seam / Threshold', 'ミラー：スケール / オフセット / コピー / 中心 / 回転 / 継ぎ目を溶接 / しきい値', 'Axes to mirror (-1 mirrors that axis), the distance the mirrored side moves along the mirrored axes, keeping the original as a copy, the center and rotation of the mirror gizmo, and welding vertices on the mirror plane within the threshold distance. Welding is an extra that matches the Symmetry modifier in 3ds Max.', '反転する軸（-1 で反転）、反転した側を反転軸に沿ってずらす距離、元を残すコピー、ミラーのギズモの中心と回転、ミラー平面上の頂点をしきい値の距離内で溶接する設定です。溶接は 3ds Max の Symmetry モディファイアに当たる追加機能です。'),
        ],
    },
    'max_squeeze_modifier': {
        'icon': 'MOD_SIMPLEDEFORM',
        'title': ('Squeeze Parameters', 'スクイーズパラメーター'),
        'overview': [
            ('Squeezes the object around the gizmo local Z axis and bulges it along that axis, like the 3ds Max Squeeze modifier.', '3ds Max の Squeeze と同じく、ギズモのローカル Z 軸のまわりで物体を絞り、その軸に沿ってふくらませます。'),
        ],
        'usage': [
            ('Move, rotate or scale the gizmo to change the squeeze center and axis. Values can be animated.', 'ギズモを移動・回転・拡大すると、絞る中心と軸が変わります。値はアニメーションできます。'),
        ],
        'settings': [
            ('Squeeze / Squeeze Curve', 'スクイーズ / スクイーズカーブ', 'Radial squeeze amount in percent. Positive pinches the waist, negative pushes it out. A small curve is sharp, a large curve is gradual.', '半径方向に絞る量（パーセント）。正でくびれ、負でふくらみます。カーブが小さいと鋭く、大きいと緩やかです。'),
            ('Bulge / Bulge Curve', 'バルジ / バルジカーブ', 'Axial bulge amount in percent along the gizmo local Z axis, and its multiplier.', 'ギズモのローカル Z 軸に沿ってふくらませる量（パーセント）とその倍率です。'),
            ('Use Limits / Lower / Upper', '制限を使用 / 下限 / 上限', 'Limits the effect to the local Z range between Lower and Upper.', '効果をローカル Z の下限から上限までの範囲に限ります。'),
            ('Bias', 'バイアス', 'Effect Balance. Moves the effect between Bulge (positive) and Squeeze (negative) while keeping their total. 100 gives Bulge only at double strength, -100 Squeeze only.', '効果のバランス。合計を保ったまま、効果をバルジ（正）とスクイーズ（負）の間で寄せます。100 でバルジだけが 2 倍、-100 でスクイーズだけになります。'),
            ('Volume', 'ボリューム', 'Effect Balance. Scales Squeeze and Bulge together in percent. 100 is the normal strength.', '効果のバランス。スクイーズとバルジを同じ割合で強めたり弱めたりします（パーセント）。100 が通常の強さです。'),
            ('Influence', '影響', 'Overall strength of the whole modifier.', 'モディファイア全体の強さです。'),
        ],
    },
})

def _resolve_owner(context, owner_spec):
    try:
        root, attr = owner_spec
    except Exception:
        return None
    try:
        if root == 'scene':
            base = getattr(context, 'scene', None)
        elif root == 'window_manager':
            base = getattr(context, 'window_manager', None)
        elif root == 'object':
            base = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        else:
            base = None
        if base is None:
            return None
        if str(attr) in {'', '__self__', 'self'}:
            return base
        return getattr(base, attr, None)
    except Exception:
        return None


def _rna_pairs(context, owner_spec, identifiers: Iterable[str] | None = None) -> list[tuple[str, str]]:
    owner = _resolve_owner(context, owner_spec)
    if owner is None:
        return []
    allowed = {str(x) for x in identifiers or () if str(x)}
    pairs: list[tuple[str, str]] = []
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', [])
        for prop in props:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type':
                continue
            if allowed and ident not in allowed:
                continue
            try:
                if bool(getattr(prop, 'is_hidden', False)):
                    continue
            except Exception:
                pass
            name = pgettext_iface(getattr(prop, 'name', ident), context=context)
            desc = pgettext_iface(getattr(prop, 'description', ''), context=context)
            if not desc:
                desc = _t('No additional explanation is registered for this setting.', 'この設定には追加説明が登録されていません。', context=context)
            pairs.append((name, desc))
    except Exception:
        return []
    if allowed:
        order = {value: idx for idx, value in enumerate(tuple(identifiers or ())) }
        pairs_with_ids = []
        try:
            for prop in getattr(getattr(owner, 'bl_rna', None), 'properties', []):
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident in allowed:
                    name = pgettext_iface(getattr(prop, 'name', ident), context=context)
                    desc = pgettext_iface(getattr(prop, 'description', ''), context=context) or _t('No additional explanation is registered for this setting.', 'この設定には追加説明が登録されていません。', context=context)
                    pairs_with_ids.append((order.get(ident, 9999), name, desc))
            return [(name, desc) for _idx, name, desc in sorted(pairs_with_ids, key=lambda item: item[0])]
        except Exception:
            pass
    return pairs


def _catalog_pairs(context=None) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    try:
        from .plugin_catalog import PLUGIN_CATALOG, GROUP_META
    except Exception:
        PLUGIN_CATALOG, GROUP_META = {}, {}
    # Preserve catalog priority order without importing tool operator modules.
    try:
        ordered = sorted(PLUGIN_CATALOG.items(), key=lambda item: int((item[1] or {}).get('priority', 0)), reverse=True)
    except Exception:
        ordered = list(getattr(PLUGIN_CATALOG, 'items', lambda: [])())
    for _pid, meta in ordered:
        if not isinstance(meta, dict):
            continue
        label = str(meta.get('label') or '').strip()
        if not label:
            continue
        desc = choose_text(meta.get('description_en', ''), meta.get('description_ja', ''), context=context)
        usage = choose_text(meta.get('usage_en', ''), meta.get('usage_ja', ''), context=context)
        text = desc
        if usage:
            text = f"{text}\n{_t('How to use:', '使用方法:', context=context)} {usage}"
        pairs.append((pgettext_iface(label, context=context), text))
    return pairs


def _catalog_group_summary_pairs(context=None) -> list[tuple[str, str]]:
    """Return compact group summaries for the top-level bundled catalog help."""
    try:
        from .plugin_catalog import GROUP_META, PLUGIN_CATALOG, PLUGIN_GROUPS
    except Exception:
        return []
    counts: dict[str, int] = {}
    for pid, meta in (PLUGIN_CATALOG or {}).items():
        try:
            gid = str((meta or {}).get('group') or PLUGIN_GROUPS.get(pid) or 'other')
        except Exception:
            gid = 'other'
        counts[gid] = counts.get(gid, 0) + 1
    try:
        ordered = sorted((GROUP_META or {}).items(), key=lambda item: int((item[1] or {}).get('priority', 0)), reverse=True)
    except Exception:
        ordered = list((GROUP_META or {}).items())
    rows: list[tuple[str, str]] = []
    for gid, meta in ordered:
        count = counts.get(str(gid), 0)
        if count <= 0:
            continue
        label = pgettext_iface(str((meta or {}).get('label') or gid), context=context)
        rows.append((label, _t('Contains {count} bundled entries. Use the Help icon on that catalog group to see every function, usage note, and setting item for that group.', '{count}件の同梱項目を含みます。そのカタロググループ右側のヘルプアイコンから、グループ内の全機能、使用方法、設定項目を確認できます。', context=context).format(count=count)))
    return rows



# Additional compact subtopics for grouped sections that live inside existing panels.
# Kept here so help metadata remains in the lazy help module and is not imported
# during Blender startup or normal N-panel drawing.
_EXTRA_SUBTOPICS = {
    'modifier_switcher_targets': ('modifier_switcher', ('modswitch_filter_targets', 'modswitch_affect_viewport', 'modswitch_affect_render', 'modswitch_affect_editmode', 'modswitch_affect_on_cage', 'modswitch_affect_expanded'), [('Modifier List', 'モディファイア一覧'), ('Affect Buttons', '反映ボタン'), ('ON / OFF / INVERT', 'ON / OFF / 反転')]),
    'modifier_switcher_objects': ('modifier_switcher', ('modswitch_filter_objects', 'modswitch_show_stack_instances', 'modswitch_visible_only', 'modswitch_scope', 'modswitch_scope_collection'), [('Object List', 'オブジェクト一覧'), ('Select All Listed', '一覧を全選択')]),
    'modifier_switcher_states': ('modifier_switcher', ('modswitch_new_state_set_name', 'modswitch_state_set_index'), [('State Sets', '状態セット'), ('Save New / Overwrite', '新規保存 / 上書き'), ('Apply / Delete', '適用 / 削除')]),
    'modifier_switcher_details': ('modifier_switcher', ('modswitch_refresh_interval', 'modswitch_mode', 'modswitch_scope', 'modswitch_visible_only', 'modswitch_selection_behavior', 'modswitch_affect_expanded'), [('Update List', '一覧を更新'), ('Move Up / Down', '上へ / 下へ移動'), ('Apply / Remove', '適用 / 削除')]),
    'switcher_details': ('modifier_switcher', ('modswitch_refresh_interval', 'modswitch_mode', 'modswitch_scope', 'modswitch_visible_only', 'modswitch_selection_behavior', 'modswitch_affect_expanded'), [('Settings', '設定'), ('Update List', '一覧を更新'), ('Move Up / Down', '上へ / 下へ移動'), ('Apply / Remove', '適用 / 削除')]),
}

_CATALOG_GROUP_SETTING_MAP = {
    'hard_surface': [
        ('scene', 'hub_props', ('boolean_operation', 'boolean_solver', 'hs_auto_bevel', 'hs_bevel_width', 'hs_bevel_segments', 'hs_weighted_normal', 'hs_organize_cutters')),
    ],
    'topology_repair': [
        ('scene', 'hub_props', ('cleanup_merge_distance', 'cleanup_fill_holes', 'cleanup_join_tris', 'cleanup_recalc_normals')),
        ('scene', 'smsp_props', ('audit_merge_distance', 'audit_issue_filter', 'axis_slice_tolerance')),
    ],
    'curves_paths': [
        ('scene', 'hub_props', ('pipe_radius', 'pipe_resolution', 'pipe_fill_caps', 'array_offset_x', 'array_count', 'array_merge_vertices')),
        ('scene', 'smsp_props', ('curve_rebuild_count', 'curve_rebuild_keep_original', 'profile_primitive_type', 'profile_width', 'profile_height', 'profile_points', 'profile_star_inner', 'helix_radius', 'helix_height', 'helix_turns', 'helix_points_per_turn', 'helix_taper', 'helix_clockwise', 'objects_to_path_use_nearest', 'objects_to_path_cyclic', 'vertices_to_path_use_nearest', 'vertices_to_path_cyclic', 'sweep_duplicate_path', 'sweep_fill_caps', 'sweep_resolution_u', 'loft_sample_count', 'loft_shade_smooth')),
    ],
    'surface_normals': [
        ('scene', 'hub_props', ('conform_mode', 'conform_offset', 'conform_parent', 'conform_organize')),
        ('scene', 'smsp_props', ('surface_project_offset', 'conform_offset', 'conform_method', 'conform_add_normals', 'normal_transfer_mix')),
    ],
    'precision_cad': [
        ('scene', 'smsp_props', ('workplane_use_cursor_pivot', 'workplane_use_cursor_orientation', 'project_offset', 'cad_mode', 'face_component_selected_faces_only', 'face_component_scale_to_face', 'face_component_scale', 'face_component_offset', 'face_component_linked_data', 'audit_merge_distance', 'audit_issue_filter', 'axis_slice_axis', 'axis_slice_count', 'axis_slice_use_selection_bounds', 'axis_slice_select_new', 'axis_slice_tolerance')),
    ],
    'deformers': [
        ('scene', 'smsa_props', ('solidify_thickness', 'solidify_offset', 'solidify_even', 'solidify_quality_normals', 'solidify_rim', 'bend_angle_deg', 'bend_axis', 'bend_lower_limit', 'bend_upper_limit', 'bend_use_cursor_origin', 'lattice_points_u', 'lattice_points_v', 'lattice_points_w', 'lattice_padding', 'lattice_use_outside', 'cast_factor', 'cast_type', 'cast_radius', 'cast_use_x', 'cast_use_y', 'cast_use_z', 'cast_use_cursor_origin')),
    ],
    'advanced_surface': [
        ('scene', 'smsa_props', ('surface_box_width', 'surface_box_length', 'surface_box_height', 'surface_box_operation', 'surface_box_wire', 'surface_box_parent', 'smart_extrude_inset', 'smart_extrude_distance', 'smart_extrude_even', 'smart_extrude_recalc', 'slice_axis', 'slice_count', 'slice_thickness', 'slice_operation', 'slice_wire', 'slice_organize', 'combine_cleanup', 'combine_cleanup_normals')),
        ('scene', 'smsp_props', ('face_component_selected_faces_only', 'face_component_scale_to_face', 'face_component_scale', 'face_component_offset', 'face_component_linked_data')),
    ],
    'layout_scatter': [
        ('scene', 'hub_props', ('scatter_count', 'scatter_seed', 'scatter_scale_min', 'scatter_scale_max', 'scatter_random_z_deg', 'scatter_align_normal', 'scatter_surface_offset', 'floor_board_width', 'floor_board_length', 'floor_gap', 'floor_thickness', 'floor_stagger', 'floor_axis')),
        ('scene', 'smsp_props', ('path_count', 'path_include_ends', 'path_follow_tangent', 'path_random_roll_deg', 'path_linked_data', 'path_organize', 'align_location', 'align_rotation', 'align_scale', 'align_axis_x', 'align_axis_y', 'align_axis_z', 'distribute_axis', 'stack_axis', 'stack_gap', 'replace_linked_data', 'replace_delete_targets', 'replace_preserve_collections', 'random_seed', 'random_xy_offset', 'random_z_offset', 'random_z_rotation_deg', 'random_scale_min', 'random_scale_max', 'drop_to_floor_use_cursor_z', 'drop_to_floor_z')),
    ],
}


def _fallback_settings_pairs(context=None) -> list[tuple[str, str]]:
    return [
        (_t('No persistent setting is exposed for this group.', 'このグループには常時表示される永続設定はありません。', context=context), _t('The tool runs from the current object, selection, mode, or modifier-row state. Detailed run-time parameters appear in the operator redo panel, the relevant N-panel group, or the generated modifier row only when that tool is used.', 'このツールは現在のオブジェクト、選択状態、モード、またはモディファイア行の状態から実行されます。実行時パラメータは、そのツールを使った時だけ、オペレーター再実行パネル、該当Nパネルグループ、または生成されたモディファイア行に表示されます。', context=context))
    ]


def _draw_feature_overview(layout, context, topic: dict, functions: list[tuple[str, str]]) -> None:
    col = _section(layout, _t('1. Feature Overview', '1. 機能概要', context=context), icon='NONE')
    drew = False
    for en, ja in topic.get('overview') or []:
        _bullet(col, _t(en, ja, context=context))
        drew = True
    if functions:
        if drew:
            col.separator(factor=0.35)
        for name, desc in functions:
            _entry(col, name, desc, icon='DOT')
            drew = True
    if not drew:
        _bullet(col, _t('This help topic describes the selected Smart Modifier tool group.', 'このヘルプ項目は、選択した Smart Modifier ツールグループを説明します。', context=context))


def _draw_usage(layout, context, topic: dict) -> None:
    col = _section(layout, _t('2. Usage', '2. 使用方法', context=context), icon='PLAY')
    usage = topic.get('usage') or []
    if usage:
        for en, ja in usage:
            _bullet(col, _t(en, ja, context=context))
    else:
        _bullet(col, _t('Adjust the visible settings if available, confirm the active object and selection, then run the button in this group.', '表示されている設定があれば調整し、アクティブオブジェクトと選択状態を確認してから、このグループ内のボタンを実行します。', context=context))


def _collect_topic_settings(context, topic: dict) -> list[tuple[str, str]]:
    settings_func = topic.get('settings_func')
    if callable(settings_func):
        try:
            pairs = list(settings_func(context) or [])
            return pairs or _fallback_settings_pairs(context)
        except Exception:
            return _fallback_settings_pairs(context)
    if topic.get('settings_owner'):
        pairs = _rna_pairs(context, topic.get('settings_owner'))
        return pairs or _fallback_settings_pairs(context)
    settings = []
    for item in topic.get('settings') or []:
        try:
            n_en, n_ja, d_en, d_ja = item
            settings.append((_t(n_en, n_ja, context=context), _t(d_en, d_ja, context=context)))
        except Exception:
            continue
    return settings or _fallback_settings_pairs(context)


def _draw_settings(layout, context, pairs: Iterable[tuple[str, str]]) -> None:
    _pairs_section(layout, _t('3. Settings', '3. 設定項目', context=context), pairs or _fallback_settings_pairs(context), icon='PREFERENCES', context=context)


def _topic_functions(context, topic: dict) -> list[tuple[str, str]]:
    functions: list[tuple[str, str]] = []
    for item in topic.get('functions') or []:
        try:
            n_en, n_ja, d_en, d_ja = item
            functions.append((_t(n_en, n_ja, context=context), _t(d_en, d_ja, context=context)))
        except Exception:
            continue
    return functions




def _draw_topic_base(layout, context, topic_id: str, topic: dict) -> None:
    title_en, title_ja = topic.get('title', ('Help', 'ヘルプ'))
    title = _t(title_en, title_ja, context=context)
    icon = str(topic.get('icon') or 'QUESTION')
    header = layout.box()
    _line(header, title, icon=icon)

    functions = _topic_functions(context, topic)
    if bool(topic.get('catalog')):
        functions.extend(_catalog_group_summary_pairs(context))
    _draw_feature_overview(layout, context, topic, functions)
    _draw_usage(layout, context, topic)
    _draw_settings(layout, context, _collect_topic_settings(context, topic))


def _draw_subtopic(layout, context, topic_id: str, subtopic) -> None:
    parent_id, prop_ids, func_pairs = subtopic
    parent = _TOPIC_BASE.get(parent_id, {})
    title_en, title_ja = parent.get('title', ('Help', 'ヘルプ'))
    func_names = [_t(en, ja, context=context) for en, ja in (func_pairs or [])]
    subtitle = ', '.join(func_names[:3]) if func_names else _t(title_en, title_ja, context=context)
    if len(func_names) > 3:
        subtitle += _t(' and related tools', ' ほか関連ツール', context=context)

    header = layout.box()
    _line(header, subtitle or _t(title_en, title_ja, context=context), icon=str(parent.get('icon') or 'QUESTION'))

    functions: list[tuple[str, str]] = []
    for en, ja in (func_pairs or []):
        functions.append((_t(en, ja, context=context), _t('Runs this function using the current selection and the settings shown in this tool group.', '現在の選択状態とこのツールグループに表示されている設定を使って、この機能を実行します。', context=context)))
    topic = {
        'overview': [
            ('Focused subgroup of the parent tool panel. It keeps only the controls needed for this workflow visible in the N-panel, while detailed explanations stay in this popup.', '親ツールパネル内の集中サブグループです。このワークフローに必要な操作だけをNパネルに表示し、詳細説明はこのポップアップへ集約します。'),
        ],
        'usage': [
            ('Adjust the settings in this group, confirm the active object and selection, then click the function button in the N-panel.', 'このグループ内の設定を調整し、アクティブオブジェクトと選択状態を確認してから、Nパネルの機能ボタンをクリックします。'),
            ('If a tool reports that the context is invalid, switch to the required object mode or edit mode and check the tooltip for that button.', 'ツールがコンテキスト不一致を報告した場合は、必要なオブジェクトモードまたは編集モードへ切り替え、そのボタンのツールチップを確認します。'),
        ],
    }
    _draw_feature_overview(layout, context, topic, functions)
    _draw_usage(layout, context, topic)
    owner_spec = parent.get('settings_owner')
    if owner_spec:
        pairs = _rna_pairs(context, owner_spec, prop_ids)
    elif callable(parent.get('settings_func')):
        try:
            pairs = list(parent.get('settings_func')(context) or [])
        except Exception:
            pairs = []
    else:
        pairs = []
    _draw_settings(layout, context, pairs or _fallback_settings_pairs(context))


def _catalog_group_pairs(context, group_id: str) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    functions: list[tuple[str, str]] = []
    usage_pairs: list[tuple[str, str]] = []
    try:
        from .plugin_catalog import PLUGIN_CATALOG, PLUGIN_GROUPS
    except Exception:
        return functions, usage_pairs
    for pid, meta in sorted((PLUGIN_CATALOG or {}).items(), key=lambda item: int((item[1] or {}).get('priority', 0)), reverse=True):
        try:
            gid = str((meta or {}).get('group') or PLUGIN_GROUPS.get(pid) or 'other')
        except Exception:
            gid = 'other'
        if gid != group_id:
            continue
        label = pgettext_iface((meta or {}).get('label') or str(pid), context=context)
        desc = choose_text((meta or {}).get('description_en', ''), (meta or {}).get('description_ja', ''), context=context)
        usage = choose_text((meta or {}).get('usage_en', ''), (meta or {}).get('usage_ja', ''), context=context)
        if desc:
            functions.append((label, desc))
        if usage:
            usage_pairs.append((label, usage))
    return functions, usage_pairs


def _catalog_group_settings(context, group_id: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for root_name, attr, identifiers in _CATALOG_GROUP_SETTING_MAP.get(group_id, []):
        owner_spec = (root_name, attr)
        try:
            if identifiers:
                pairs.extend(_rna_pairs(context, owner_spec, identifiers))
            else:
                pairs.extend(_rna_pairs(context, owner_spec))
        except Exception:
            continue
    if group_id == 'compatibility_utilities':
        pairs.extend([
            (_t('Max Parameters', 'Maxパラメータ', context=context), _t('Generated 3ds Max-compatible stack rows expose editable parameters such as Amount, Strength, Angle, Radius, Segments, Map Channel, UV tiling, Seed, Material ID, and category-specific values when the compatibility wrapper supports them.', '生成された 3ds Max 互換スタック行では、互換ラッパーが対応している場合、Amount、Strength、Angle、Radius、Segments、Map Channel、UVタイリング、Seed、Material ID、カテゴリ固有値などを編集できます。', context=context)),
            (_t('Instance / Release Instance', 'インスタンス / インスタンス解除', context=context), _t('Multi-object additions are linked as one logical instance group when possible. Use Release Instance from the row menu to detach only the selected object from shared parameter synchronization.', '複数オブジェクトへの追加は、可能な場合1つの論理インスタンスグループとしてリンクされます。行メニューの「インスタンス解除」で、選択オブジェクトだけを共有パラメータ同期から切り離せます。', context=context)),
        ])
    return pairs or _fallback_settings_pairs(context)


def _draw_catalog_group(layout, context, group_id: str) -> None:
    try:
        from .plugin_catalog import GROUP_META
    except Exception:
        GROUP_META = {}
    meta = GROUP_META.get(group_id, GROUP_META.get('other', {})) if isinstance(GROUP_META, dict) else {}
    label = pgettext_iface(str(meta.get('label') or group_id or 'Tool Group'), context=context)
    icon = str(meta.get('icon') or 'OUTLINER_COLLECTION')
    header = layout.box()
    _line(header, label, icon=icon)

    function_pairs, usage_pairs = _catalog_group_pairs(context, group_id)
    topic = {
        'overview': [
            ('Bundled tools in this group are shown as lightweight launcher rows. Their implementation modules are kept unloaded until the selected tool is executed.', 'このグループ内の同梱ツールは軽量な起動行として表示されます。実装モジュールは、選択したツールを実行するまで読み込まれません。'),
        ],
        'usage': [],
    }
    _draw_feature_overview(layout, context, topic, function_pairs)

    col = _section(layout, _t('2. Usage', '2. 使用方法', context=context), icon='PLAY')
    if usage_pairs:
        for name, desc in usage_pairs:
            _entry(col, name, desc, icon='DOT')
    else:
        _bullet(col, _t('Open the group, select the target object or edit selection required by the tool, then click the desired function button.', 'グループを開き、ツールが要求する対象オブジェクトまたは編集選択を用意してから、目的の機能ボタンをクリックします。', context=context))
    _draw_settings(layout, context, _catalog_group_settings(context, group_id))


def draw_help(layout, context, help_id: str, *, popup_width_px: int | None = None) -> None:
    _set_draw_wrap_context(context, popup_width_px)
    layout.use_property_split = False
    layout.use_property_decorate = False
    topic_id = str(help_id or '').strip()
    if topic_id.startswith('catalog_group:'):
        _draw_catalog_group(layout, context, topic_id.split(':', 1)[1].strip() or 'other')
        return
    if topic_id.startswith('catalog_group_'):
        _draw_catalog_group(layout, context, topic_id[len('catalog_group_'):].strip() or 'other')
        return
    if topic_id in _EXTRA_SUBTOPICS:
        _draw_subtopic(layout, context, topic_id, _EXTRA_SUBTOPICS[topic_id])
        return
    if topic_id in _SUBTOPICS:
        _draw_subtopic(layout, context, topic_id, _SUBTOPICS[topic_id])
        return
    topic = _TOPIC_BASE.get(topic_id)
    if not topic:
        box = layout.box()
        _line(box, _t('Help content was not found.', 'ヘルプ内容が見つかりませんでした。', context=context), icon='ERROR')
        _line(box, _t('The selected Help button points to an unknown topic. Reload the add-on if this persists.', '選択したヘルプボタンが不明な項目を参照しています。この状態が続く場合はアドオンを再読み込みしてください。', context=context), icon='NONE')
        return
    _draw_topic_base(layout, context, topic_id, topic)
