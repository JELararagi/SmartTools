# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

"""Additional high-coverage modeling operators for Smart Modifier.

This module expands the hub with practical upper-compatible tools inspired by
surface-kitbash workflows, smart extrusion, slice/panel generators, bend/twist/taper/lattice deformation, solidify helpers, safe
combine utilities, and drop-to-surface helpers.
"""

import math 

import bmesh 
import bpy 
from bpy .props import BoolProperty ,EnumProperty ,FloatProperty ,IntProperty ,PointerProperty 
from bpy .types import Operator ,Panel ,PropertyGroup 
from mathutils import Matrix ,Vector 

from .utils import (
call_operator_safe ,
operator_available ,
operator_runnable ,
safe_activate_only ,
safe_join_selected ,
safe_mode_set ,
safe_select_all ,
)
from .context import capture_object_context ,restore_object_context 
from .translation import pgettext as _sms_pgettext
from .help_button import draw_help_button, draw_help_header

PANEL_CATEGORY ="Smart Modifier"


def _persist_panel_state(_self=None, context=None) -> None:
    try:
        if context is None:
            context = getattr(bpy, 'context', None)
        from . import persistent_state
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass


def _persistent_property_factory(factory):
    def _wrapped(*args, **kwargs):
        kwargs.setdefault('update', _persist_panel_state)
        return factory(*args, **kwargs)
    return _wrapped


_BpyBoolProperty = BoolProperty
_BpyEnumProperty = EnumProperty
_BpyFloatProperty = FloatProperty
_BpyIntProperty = IntProperty
_BpyPointerProperty = PointerProperty
BoolProperty = _persistent_property_factory(_BpyBoolProperty)
EnumProperty = _persistent_property_factory(_BpyEnumProperty)
FloatProperty = _persistent_property_factory(_BpyFloatProperty)
IntProperty = _persistent_property_factory(_BpyIntProperty)
PointerProperty = _persistent_property_factory(_BpyPointerProperty)

translation_catalog_dict ={
"ja_JP":{
("*","Advanced / Surface Modeling"):"高度 / サーフェスモデリング",
("*","Surface Detail / Layout"):"サーフェスディテール / レイアウト",
("*","Surface Box Detail"):"サーフェス箱型ディテール",
("*","Create a detail box aligned to the active face. This is useful for kitbash details, panel blocks, trim pieces, and quick boolean helpers inspired by KIT OPS, Primo Kit, NitroDraw, and surface-first hard-surface workflows."):"アクティブ面に揃った箱型ディテールを生成します。キットバッシュ部品、パネルブロック、トリム、簡易ブーリアン補助など、KIT OPS、Primo Kit、NitroDraw、面基準のハードサーフェス制作を意識した機能です。",
("*","Smart Extrude Clean"):"スマート押し出しクリーン",
("*","Run a compact face-modeling helper that optionally insets first, then extrudes and shrink-fattens the current selection. This acts as a practical Blender-native helper inspired by Maya Smart Extrude and ZModeler QMesh style workflows."):"必要に応じて先にインセットし、その後に押し出しと Shrink/Fatten を行う、コンパクトな面モデリング補助です。Maya の Smart Extrude や ZModeler の QMesh 系ワークフローを Blender ネイティブに寄せた実装です。",
("*","Slice / Panel Stack"):"スライス / パネルスタック",
("*","Create evenly spaced boolean helper boxes across the active mesh bounds to build grooves, slots, layered cuts, and contour-like panel patterns. This is a practical non-destructive generator inspired by Slicer, NitroBoxTool, and panel-line boolean workflows."):"アクティブメッシュの範囲に沿って等間隔のブーリアン補助ボックスを生成し、溝、スロット、多段カット、等高線的なパネルパターンを作ります。Slicer、NitroBoxTool、パネルライン用ブーリアン作業を意識した非破壊ジェネレーターです。",
("*","Combine / Join Clean"):"結合 / クリーン結合",
("*","Join the selected mesh objects while keeping the active object as the pivot/origin owner, then optionally run a light cleanup pass. This acts as a Blender-friendly helper inspired by FB combine and clean combine scripts."):"選択メッシュを結合し、アクティブオブジェクトの原点/ピボットを維持したまま、必要に応じて軽いクリーンアップを行います。FB combine などのクリーン結合系スクリプトを意識した Blender 向け補助です。",
("*","Drop To Surface"):"面へドロップ",
("*","Drop the selected objects onto the active surface along world -Z using bounding-box based placement, with optional normal alignment. This is useful for DropIt / Drop to Floor style scene dressing and layout work."):"選択オブジェクトを、ワールド -Z 方向へアクティブ面へ落とし、バウンディングボックス基準で接地します。必要に応じて法線合わせも行います。DropIt / Drop to Floor 系のレイアウト作業に便利です。",
("*","Width of the generated surface detail box."):"生成するサーフェスディテール箱の幅です。",
("*","Length of the generated surface detail box."):"生成するサーフェスディテール箱の長さです。",
("*","Height of the generated surface detail box measured away from the source face."):"元の面から外側へ立ち上がるサーフェスディテール箱の高さです。",
("*","Surface Box Width"):"サーフェス箱の幅",
("*","Surface Box Length"):"サーフェス箱の長さ",
("*","Surface Box Height"):"サーフェス箱の高さ",
("*","Surface Box Operation"):"サーフェス箱の演算",
("*","Leave the new detail as a standalone object"):"新規ディテールを単独オブジェクトとして残します",
("*","Use the new detail as a boolean difference helper on the source mesh"):"新規ディテールを元メッシュへの差分ブーリアン補助として使います",
("*","Use the new detail as a boolean union helper on the source mesh"):"新規ディテールを元メッシュへの合成ブーリアン補助として使います",
("*","Standalone"):"単独",
("*","Difference"):"差分",
("*","Union"):"合成",
("*","Display the generated detail as wire for helper-style workflows."):"補助オブジェクト用途向けに、生成ディテールをワイヤ表示にします。",
("*","Surface Box Wire"):"サーフェス箱をワイヤ表示",
("*","Parent the generated detail to the source object for easier scene organization."):"シーン整理しやすいよう、生成ディテールを元オブジェクトの子にします。",
("*","Parent To Source"):"元オブジェクトへ親子付け",
("*","Inset amount applied before the extrusion step."):"押し出し前に行うインセット量です。",
("*","Extrude distance applied by the helper."):"この補助で行う押し出し距離です。",
("*","Try to keep offset more even during shrink/fatten."):"Shrink/Fatten 中にオフセットをより均一に保つよう試みます。",
("*","Recalculate normals after the helper finishes."):"処理後に法線を再計算します。",
("*","Smart Extrude Inset"):"スマート押し出しのインセット量",
("*","Smart Extrude Distance"):"スマート押し出し距離",
("*","Even Offset"):"均一オフセット",
("*","Recalculate Normals"):"法線再計算",
("*","Axis used to distribute slice helper boxes across the active mesh bounds."):"アクティブメッシュ範囲にスライス補助ボックスを並べる軸です。",
("*","Slice Axis"):"スライス軸",
("*","Number of evenly spaced slice helper boxes to create."):"生成する等間隔スライス補助ボックス数です。",
("*","Slice Count"):"スライス数",
("*","Thickness of each slice helper box."):"各スライス補助ボックスの厚みです。",
("*","Slice Thickness"):"スライス厚み",
("*","How the generated slice helpers should affect the active mesh."):"生成されたスライス補助がアクティブメッシュへ与える演算方法です。",
("*","Slice Operation"):"スライス演算",
("*","Show generated slice helpers as wire objects."):"生成スライス補助をワイヤ表示にします。",
("*","Slice Helpers Wire"):"スライス補助をワイヤ表示",
("*","Organize generated slice helpers into a dedicated collection."):"生成スライス補助を専用コレクションへ整理します。",
("*","Organize Slice Helpers"):"スライス補助を整理",
("*","Run a light cleanup pass after joining meshes."):"メッシュ結合後に軽いクリーンアップを実行します。",
("*","Cleanup After Join"):"結合後に整理",
("*","Also recalculate normals during the cleanup pass."):"クリーンアップ時に法線再計算も行います。",
("*","Cleanup Normals"):"法線も整理",
("*","Offset kept above the hit surface after dropping."):"ドロップ後にヒット面から少し浮かせて保つ距離です。",
("*","Drop Offset"):"ドロップオフセット",
("*","Align dropped objects so their local Z follows the hit surface normal."):"ドロップ後、オブジェクトのローカル Z をヒット面法線に揃えます。",
("*","Align To Surface Normal"):"面法線に揃える",
("*","Use the object bounds to place the lowest point on the hit surface. When disabled, the object origin is placed on the surface instead."):"オブジェクトのバウンディングボックスを使って最下点をヒット面へ置きます。無効時はオブジェクト原点を面上へ置きます。",
("*","Use Bounds"):"バウンズを使う",
("*","Need an active mesh face in Edit Mode"):"編集モードでアクティブなメッシュ面が必要です",
("*","Created surface detail helper"):"サーフェスディテール補助を作成しました",
("*","Smart extrude complete"):"スマート押し出しが完了しました",
("*","Created slice/panel boolean helpers"):"スライス / パネル用ブーリアン補助を作成しました",
("*","Join / cleanup complete"):"結合 / クリーンアップが完了しました",
("*","Dropped selected objects to active surface"):"選択オブジェクトをアクティブ面へドロップしました",
("*","No selected object lies over the active surface"):"アクティブ面の上に重なる選択オブジェクトがありません",
("*","Select at least one other object besides the active surface"):"アクティブ面以外に少なくとも1つのオブジェクトを選択してください",
("*","Select at least one other mesh object to join"):"結合する他のメッシュオブジェクトを少なくとも1つ選択してください",
("*","Need a face selection to run Smart Extrude Clean"):"Smart Extrude Clean の実行には面選択が必要です",
("*","Suggested advanced workflows"):"おすすめ高度ワークフロー",
("*","• Surface kitbash: Surface Box Detail → Conform / Stitch To Surface → Boolean Stack."):"• サーフェスキットバッシュ: サーフェス箱型ディテール → 面へ追従 / ステッチ → Boolean Stack。",
("*","• Panel lines: Slice / Panel Stack for fast layered grooves and contour cuts."):"• パネルライン: スライス / パネルスタックで多段の溝や輪郭カットを高速作成。",
("*","• Face modeling: Smart Extrude Clean for QMesh / Smart Extrude style blockouts."):"• 面モデリング: Smart Extrude Clean で QMesh / Smart Extrude 風のブロックアウト。",
("*","• Layout: Drop To Surface and Combine / Join Clean for fast environment assembly."):"• レイアウト: Drop To Surface と Combine / Join Clean で環境アセンブリを高速化。",
}
}

translation_catalog_dict ["ja_JP"].update ({
("*","Deform / Thickness"):"変形 / 厚み",
("*","Quick Solidify Plus"):"クイック厚み付けプラス",
("*","Create or update a non-destructive Solidify modifier on the active mesh with even-thickness and quality-normal options. Useful for shelling, panel thickness, CAD-style wall offsets, Solidify Plus style workflows, and quick hard-surface thickness passes."):"アクティブメッシュに、均一厚みや高品質法線設定を含む非破壊 Solidify モディファイアを作成または更新します。シェル化、パネル厚み、CAD 風の壁厚オフセット、Solidify Plus 系ワークフロー、ハードサーフェスの素早い厚み付けに便利です。",
("*","Quick Bend Deformer"):"クイックベンドデフォーマ",
("*","Create or update a non-destructive Simple Deform Bend setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for Simple Bend, Scroll/Roll style shaping, signage, cables, and fast concept deformation without committing destructive edits."):"アクティブオブジェクトに、必要に応じて 3D カーソル位置の専用 Empty を原点として使う、非破壊 Simple Deform Bend セットアップを作成または更新します。Simple Bend、Scroll / Roll 系の変形、看板、ケーブル、ラフコンセプトの素早い変形に便利です。",
("*","Solidify Thickness"):"厚み付け厚さ",
("*","Final thickness used by the generated or updated Solidify modifier."):"生成または更新した Solidify モディファイアで使う最終厚さです。",
("*","Solidify Offset"):"厚み付けオフセット",
("*","Offset direction for the Solidify shell. Use 0 for centered shells, 1 for outward, and -1 for inward bias."):"Solidify シェルのオフセット方向です。0 は中央、1 は外側寄り、-1 は内側寄りです。",
("*","Solidify Even Thickness"):"厚みを均一化",
("*","Keep shell thickness more even across angled surfaces when the modifier supports it."):"モディファイアが対応している場合、傾いた面でも厚みがより均一になるようにします。",
("*","Solidify Quality Normals"):"高品質法線",
("*","Enable higher-quality solidify normal handling for cleaner shading on complex shells."):"複雑なシェルでもよりクリーンなシェーディングになるよう、高品質な法線処理を有効にします。",
("*","Solidify Rim"):"側面を閉じる",
("*","Create rim faces so the thickened shell is closed instead of leaving open borders."):"厚み付け後のシェルが開いた境界にならないよう、側面を生成して閉じます。",
("*","Bend Angle (deg)"):"ベンド角度（度）",
("*","Angle in degrees applied by the Bend deformer. Positive and negative values bend in opposite directions."):"Bend デフォーマで適用する角度です。正負で曲がる向きが変わります。",
("*","Bend Axis"):"ベンド軸",
("*","Primary axis used by the Bend deformer."):"Bend デフォーマで使う主軸です。",
("*","Bend Lower Limit"):"ベンド下限",
("*","Lower normalized limit for the Bend modifier, useful for partial roll and localized deformation."):"Bend モディファイアの正規化下限で、部分的な巻きや局所変形に使います。",
("*","Bend Upper Limit"):"ベンド上限",
("*","Upper normalized limit for the Bend modifier, useful for partial roll and localized deformation."):"Bend モディファイアの正規化上限で、部分的な巻きや局所変形に使います。",
("*","Use Cursor Origin"):"カーソル原点を使う",
("*","Create or update a dedicated origin empty at the 3D cursor and use it as the Bend modifier origin."):"3D カーソル位置に専用 Empty を作成または更新し、Bend モディファイアの原点として使います。",
("*","Configured Solidify helper"):"厚み付け補助を設定しました",
("*","Configured Bend helper"):"ベンド補助を設定しました",
("*","Need an active mesh object"):"アクティブなメッシュオブジェクトが必要です",
("*","Need an active mesh or curve object"):"アクティブなメッシュまたはカーブオブジェクトが必要です",
("*","Could not switch to Object Mode"):"オブジェクトモードへ切り替えられませんでした",
("*","Could not switch to Edit Mode"):"編集モードへ切り替えられませんでした",
("*","• Thickness: Quick Solidify Plus adds or updates a safe non-destructive shell for panels, walls, and trims."):"• 厚み: クイック厚み付けプラスで、パネル、壁、トリム向けの安全な非破壊シェルを追加 / 更新。",
("*","• Deform: Quick Bend Deformer sets up fast bend/roll style shaping around the cursor or object space."):"• 変形: クイックベンドデフォーマで、カーソル基準またはオブジェクト空間での素早い Bend / Roll 変形を設定。",
})

translation_catalog_dict ["ja_JP"].update ({
("*","Quick Twist Deformer"):"クイックツイストデフォーマ",
("*","Create or update a non-destructive Simple Deform Twist setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for torsion, twisted trims, cables, screw-like shaping, and fast modifier-stack twist workflows without destructive edits."):"アクティブオブジェクトに、必要に応じて 3D カーソル位置の専用 Empty を原点として使う、非破壊 Simple Deform Twist セットアップを作成または更新します。ねじり、ツイストしたトリム、ケーブル、スクリュー風の造形、破壊的編集を行わないモディファイアスタック型の高速ツイスト作業に便利です。",
("*","Quick Lattice Cage"):"クイックラティスケージ",
("*","Create or update a lattice cage around the active object and wire it through a Lattice modifier. Useful for broad-form FFD-style shaping, silhouette blocking, gentle organic cleanup, and non-destructive cage edits inspired by modifier-stack / FFD workflows."):"アクティブオブジェクトの周囲にラティスケージを作成または更新し、Lattice モディファイアで接続します。FFD 風の大まかな変形、シルエットのブロック調整、やわらかい有機的修正、非破壊ケージ編集に便利です。",
("*","Twist Angle (deg)"):"ツイスト角度（度）",
("*","Angle in degrees applied by the Twist deformer. Positive and negative values twist in opposite directions."):"Twist デフォーマで適用する角度です。正負でねじる方向が変わります。",
("*","Twist Axis"):"ツイスト軸",
("*","Primary axis used by the Twist deformer."):"Twist デフォーマで使う主軸です。",
("*","Twist Lower Limit"):"ツイスト下限",
("*","Lower normalized limit for the Twist modifier, useful for partial torsion and localized twisting."):"Twist モディファイアの正規化下限で、部分的なねじりや局所的なツイストに使います。",
("*","Twist Upper Limit"):"ツイスト上限",
("*","Upper normalized limit for the Twist modifier, useful for partial torsion and localized twisting."):"Twist モディファイアの正規化上限で、部分的なねじりや局所的なツイストに使います。",
("*","Create or update a dedicated origin empty at the 3D cursor and use it as the Twist modifier origin."):"3D カーソル位置に専用 Empty を作成または更新し、Twist モディファイアの原点として使います。",
("*","Lattice U"):"ラティス U",
("*","Lattice V"):"ラティス V",
("*","Lattice W"):"ラティス W",
("*","Number of lattice control points along the local U axis."):"ローカル U 軸方向のラティス制御点数です。",
("*","Number of lattice control points along the local V axis."):"ローカル V 軸方向のラティス制御点数です。",
("*","Number of lattice control points along the local W axis."):"ローカル W 軸方向のラティス制御点数です。",
("*","Lattice Padding"):"ラティス余白",
("*","Extra scale added around the active object when fitting the generated lattice cage."):"生成するラティスケージをアクティブオブジェクトへ合わせる際に追加する余白スケールです。",
("*","Outside Only"):"外側のみ",
("*","Use only the outer lattice points when the generated lattice supports it."):"生成したラティスが対応している場合、外側のラティス点のみを使います。",
("*","Configured Twist helper"):"ツイスト補助を設定しました",
("*","Configured Lattice helper"):"ラティス補助を設定しました",
("*","• Deform stack: Quick Bend / Twist / Taper provide reusable non-destructive shaping helpers."):"• 変形スタック: クイック Bend / Twist / Taper で、再利用しやすい非破壊シェイプ補助を作成。",
("*","• FFD style setup: Quick Lattice Cage creates a reusable cage around the active object for broad-form edits."):"• FFD 風セットアップ: クイックラティスケージで、アクティブオブジェクトの周囲に大まかな形状編集用ケージを作成。",
})



def _safe_register_class (cls ):
    try :
        bpy .utils .register_class (cls )
    except ValueError :
        pass 


def _safe_unregister_class (cls ):
    try :
        bpy .utils .unregister_class (cls )
    except Exception :
        pass 




translation_catalog_dict ["ja_JP"].update ({
("*","Cast Modifier"):"Cast Modifier",
("*","Create or update a non-destructive Cast modifier on the active mesh. Useful for sphere/cylinder/cuboid fitting, quick circle/spherify shaping, and upper-compatible max-style form correction inside the modifier stack."):"アクティブメッシュに、非破壊の Cast モディファイアを作成または更新します。球 / 円柱 / 立方体への近似、素早い円形化 / 球形化、3ds Max 風のフォーム補正をモディファイアスタック内で扱う用途に便利です。",
("*","Cast Factor"):"Cast 係数",
("*","Strength of the Cast deformation. Larger values push the mesh further toward the chosen primitive type."):"Cast 変形の強さです。値を大きくすると、選択したプリミティブ形状へより強く寄せます。",
("*","Cast Type"):"Cast 種類",
("*","Primitive type used by the Cast modifier."):"Cast モディファイアで使用するプリミティブ形状です。",
("*","Cast Radius"):"Cast 半径",
("*","Optional radius limit used by the Cast modifier when supported. Set 0 to let Blender manage it automatically."):"対応している場合に Cast モディファイアで使う任意の半径制限です。0 なら Blender 側に任せます。",
("*","Cast X"):"Cast X",
("*","Allow the Cast modifier to affect the local X direction."):"Cast モディファイアがローカル X 方向へ作用するようにします。",
("*","Cast Y"):"Cast Y",
("*","Allow the Cast modifier to affect the local Y direction."):"Cast モディファイアがローカル Y 方向へ作用するようにします。",
("*","Cast Z"):"Cast Z",
("*","Allow the Cast modifier to affect the local Z direction."):"Cast モディファイアがローカル Z 方向へ作用するようにします。",
("*","Use Cursor Origin for Cast"):"Cast にカーソル原点を使う",
("*","Create or update a dedicated origin empty at the 3D cursor and use it as the Cast modifier control object when supported."):"3D カーソル位置に専用 Empty を作成または更新し、対応している場合は Cast モディファイアの制御オブジェクトとして使います。",
("*","Sphere"):"球",
("*","Cylinder"):"円柱",
("*","Cuboid"):"直方体",
("*","Relax complete"):"Relax が完了しました",
("*","Cast setup complete"):"Cast セットアップが完了しました",
("*","Need an active mesh object in Object Mode"):"オブジェクトモードでアクティブなメッシュオブジェクトが必要です",
("*","• Primitive fitting: Cast Modifier helps recover cylinders, spheres, and rounded blockouts inside the stack."):"• プリミティブ補正: Cast Modifier は、円柱、球、丸みを持つブロックアウト形状をスタック内で補正するのに役立ちます。",
})


def _t (msg :str )->str :
    try :
        return _sms_pgettext (msg )
    except Exception :
        return msg 


def _draw_panel_operator (layout ,context ,operator_id :str ,*,text =None ,icon ='NONE',missing_icon ='ERROR'):
    available =operator_available (operator_id )
    runnable =operator_runnable (operator_id )if available else False 
    row =layout .row (align =True )
    row .enabled =runnable 
    if available :
        try :
            from .icons import operator as _sms_icon_operator
            return _sms_icon_operator (row ,operator_id ,text =text ,icon_name =operator_id ,fallback_icon =icon )
        except Exception :
            if text is None :
                return row .operator (operator_id ,icon =icon )
            return row .operator (operator_id ,text =text ,icon =icon )
    row .alert =True 
    row .enabled =False 
    label =text if text is not None else operator_id 
    try :
        from .icons import label as _sms_icon_label
        _sms_icon_label (row ,text =label ,icon_name =missing_icon ,fallback_icon =missing_icon )
    except Exception :
        row .label (text =label ,icon =missing_icon )
    return None 


def _active_mesh_object (context ):
    obj =getattr (context ,"active_object",None )
    return obj if obj and obj .type =='MESH'else None 


def _ensure_collection (context ,name :str ):
    col =bpy .data .collections .get (name )
    if col is None :
        col =bpy .data .collections .new (name )
        context .scene .collection .children .link (col )
    return col 


def _link_object_to_collection (obj ,col ):
    if obj is None or col is None :
        return 
    try :
        if col .objects .get (obj .name )is None :
            col .objects .link (obj )
    except Exception :
        pass 


def _link_to_same_collections (obj ,ref_obj ,context ):
    linked =False 
    try :
        for col in list (getattr (ref_obj ,'users_collection',[])or []):
            _link_object_to_collection (obj ,col )
            linked =True 
    except Exception :
        pass 
    if not linked :
        _link_object_to_collection (obj ,context .scene .collection )


def _unlink_object_from_all_scene_collections (obj ):
    try :
        for col in list (obj .users_collection ):
            try :
                col .objects .unlink (obj )
            except Exception :
                pass 
    except Exception :
        pass 


def _make_target_active (context ,obj ):
    if obj is None :
        return 
    safe_activate_only (context ,obj )


def _find_modifier (obj ,mod_type :str ,name_prefix :str ):
    for mod in getattr (obj ,'modifiers',[])or []:
        try :
            if mod .type ==mod_type and mod .name .startswith (name_prefix ):
                return mod 
        except Exception :
            pass 
    return None 


def _ensure_cursor_origin_empty (context ,ref_obj ,base_name :str ):
    origin_name =f"{base_name }_{ref_obj .name }"
    origin =bpy .data .objects .get (origin_name )
    if origin is None or origin .type !='EMPTY':
        origin =bpy .data .objects .new (origin_name ,None )
        try :
            origin .empty_display_type ='PLAIN_AXES'
        except Exception :
            pass 
        _link_to_same_collections (origin ,ref_obj ,context )
    try :
        origin .matrix_world =context .scene .cursor .matrix .copy ()
    except Exception :
        try :
            origin .location =context .scene .cursor .location .copy ()
        except Exception :
            pass 
    return origin 


def _configure_simple_deform (obj ,name_prefix :str ,method :str ,axis :str ,amount :float ,lower :float ,upper :float ,origin =None ):
    mod =_find_modifier (obj ,'SIMPLE_DEFORM',name_prefix )
    if mod is None :
        mod =obj .modifiers .new (name =name_prefix ,type ='SIMPLE_DEFORM')
    try :
        mod .deform_method =method 
    except Exception :
        pass 
    try :
        mod .deform_axis =axis 
    except Exception :
        pass 
    try :
        if method in {'BEND','TWIST'}and hasattr (mod ,'angle'):
            mod .angle =math .radians (float (amount ))
        elif hasattr (mod ,'factor'):
            mod .factor =float (amount )
    except Exception :
        pass 
    try :
        lo =min (float (lower ),float (upper ))
        hi =max (float (lower ),float (upper ))
        mod .limits [0 ]=lo 
        mod .limits [1 ]=hi 
    except Exception :
        pass 
    if origin is not None and hasattr (mod ,'origin'):
        try :
            mod .origin =origin 
        except Exception :
            pass 
    return mod 



def _configure_cast_modifier (obj ,name_prefix :str ,cast_type :str ,factor :float ,radius :float ,use_x :bool ,use_y :bool ,use_z :bool ,control_obj =None ):
    mod =_find_modifier (obj ,'CAST',name_prefix )
    if mod is None :
        mod =obj .modifiers .new (name =name_prefix ,type ='CAST')
    try :
        mod .cast_type =cast_type 
    except Exception :
        pass 
    try :
        mod .factor =float (factor )
    except Exception :
        pass 
    if hasattr (mod ,'radius'):
        try :
            mod .radius =max (0.0 ,float (radius ))
        except Exception :
            pass 
    for attr ,value in (('use_x',use_x ),('use_y',use_y ),('use_z',use_z )):
        if hasattr (mod ,attr ):
            try :
                setattr (mod ,attr ,bool (value ))
            except Exception :
                pass 
    if control_obj is not None and hasattr (mod ,'object'):
        try :
            mod .object =control_obj 
        except Exception :
            pass 
    return mod 


def _bbox_world_points (obj ):
    return [obj .matrix_world @Vector (corner )for corner in obj .bound_box ]


def _new_box_mesh (name :str ,width :float ,length :float ,height :float ):
    hw =width *0.5 
    hl =length *0.5 
    verts =[
    (-hw ,-hl ,0.0 ),(hw ,-hl ,0.0 ),(hw ,hl ,0.0 ),(-hw ,hl ,0.0 ),
    (-hw ,-hl ,height ),(hw ,-hl ,height ),(hw ,hl ,height ),(-hw ,hl ,height ),
    ]
    faces =[
    (0 ,1 ,2 ,3 ),
    (4 ,5 ,6 ,7 ),
    (0 ,1 ,5 ,4 ),
    (1 ,2 ,6 ,5 ),
    (2 ,3 ,7 ,6 ),
    (3 ,0 ,4 ,7 ),
    ]
    mesh =bpy .data .meshes .new (name )
    mesh .from_pydata (verts ,[],faces )
    mesh .update (calc_edges =True )
    return mesh 


def _new_bbox_box_mesh (name :str ,min_corner :Vector ,max_corner :Vector ):
    x0 ,y0 ,z0 =min_corner 
    x1 ,y1 ,z1 =max_corner 
    verts =[
    (x0 ,y0 ,z0 ),(x1 ,y0 ,z0 ),(x1 ,y1 ,z0 ),(x0 ,y1 ,z0 ),
    (x0 ,y0 ,z1 ),(x1 ,y0 ,z1 ),(x1 ,y1 ,z1 ),(x0 ,y1 ,z1 ),
    ]
    faces =[
    (0 ,1 ,2 ,3 ),
    (4 ,5 ,6 ,7 ),
    (0 ,1 ,5 ,4 ),
    (1 ,2 ,6 ,5 ),
    (2 ,3 ,7 ,6 ),
    (3 ,0 ,4 ,7 ),
    ]
    mesh =bpy .data .meshes .new (name )
    mesh .from_pydata (verts ,[],faces )
    mesh .update (calc_edges =True )
    return mesh 


class SMSA_Props (PropertyGroup ):
    surface_box_width :FloatProperty (name ="Surface Box Width",description ="Width of the generated surface detail box.",default =0.2 ,min =0.0001 ,soft_max =100.0 )
    surface_box_length :FloatProperty (name ="Surface Box Length",description ="Length of the generated surface detail box.",default =0.2 ,min =0.0001 ,soft_max =100.0 )
    surface_box_height :FloatProperty (name ="Surface Box Height",description ="Height of the generated surface detail box measured away from the source face.",default =0.06 ,min =0.0001 ,soft_max =100.0 )
    surface_box_operation :EnumProperty (
    name ="Surface Box Operation",
    description ="How the generated surface detail box should be used.",
    items =[
    ('NONE','Standalone','Leave the new detail as a standalone object'),
    ('DIFFERENCE','Difference','Use the new detail as a boolean difference helper on the source mesh'),
    ('UNION','Union','Use the new detail as a boolean union helper on the source mesh'),
    ],
    default ='NONE',
    )
    surface_box_wire :BoolProperty (name ="Surface Box Wire",description ="Display the generated detail as wire for helper-style workflows.",default =True )
    surface_box_parent :BoolProperty (name ="Parent To Source",description ="Parent the generated detail to the source object for easier scene organization.",default =True )

    smart_extrude_inset :FloatProperty (name ="Smart Extrude Inset",description ="Inset amount applied before the extrusion step.",default =0.0 ,min =0.0 ,soft_max =10.0 )
    smart_extrude_distance :FloatProperty (name ="Smart Extrude Distance",description ="Extrude distance applied by the helper.",default =0.1 ,soft_min =-10.0 ,soft_max =10.0 )
    smart_extrude_even :BoolProperty (name ="Even Offset",description ="Try to keep offset more even during shrink/fatten.",default =True )
    smart_extrude_recalc :BoolProperty (name ="Recalculate Normals",description ="Recalculate normals after the helper finishes.",default =True )

    slice_axis :EnumProperty (
    name ="Slice Axis",
    description ="Axis used to distribute slice helper boxes across the active mesh bounds.",
    items =[('X','X',''),('Y','Y',''),('Z','Z','')],
    default ='X',
    )
    slice_count :IntProperty (name ="Slice Count",description ="Number of evenly spaced slice helper boxes to create.",default =4 ,min =1 ,soft_max =128 )
    slice_thickness :FloatProperty (name ="Slice Thickness",description ="Thickness of each slice helper box.",default =0.02 ,min =0.0001 ,soft_max =10.0 )
    slice_operation :EnumProperty (
    name ="Slice Operation",
    description ="How the generated slice helpers should affect the active mesh.",
    items =[
    ('DIFFERENCE','Difference',''),
    ('UNION','Union',''),
    ('INTERSECT','Intersect',''),
    ],
    default ='DIFFERENCE',
    )
    slice_wire :BoolProperty (name ="Slice Helpers Wire",description ="Show generated slice helpers as wire objects.",default =True )
    slice_organize :BoolProperty (name ="Organize Slice Helpers",description ="Organize generated slice helpers into a dedicated collection.",default =True )

    combine_cleanup :BoolProperty (name ="Cleanup After Join",description ="Run a light cleanup pass after joining meshes.",default =True )
    combine_cleanup_normals :BoolProperty (name ="Cleanup Normals",description ="Also recalculate normals during the cleanup pass.",default =True )

    drop_offset :FloatProperty (name ="Drop Offset",description ="Offset kept above the hit surface after dropping.",default =0.0 ,soft_min =-10.0 ,soft_max =10.0 )
    drop_align_to_surface :BoolProperty (name ="Align To Surface Normal",description ="Align dropped objects so their local Z follows the hit surface normal.",default =False )
    drop_use_bounds :BoolProperty (name ="Use Bounds",description ="Use the object bounds to place the lowest point on the hit surface. When disabled, the object origin is placed on the surface instead.",default =True )

    solidify_thickness :FloatProperty (name ="Solidify Thickness",description ="Final thickness used by the generated or updated Solidify modifier.",default =0.02 ,min =0.0001 ,soft_max =100.0 )
    solidify_offset :FloatProperty (name ="Solidify Offset",description ="Offset direction for the Solidify shell. Use 0 for centered shells, 1 for outward, and -1 for inward bias.",default =1.0 ,min =-1.0 ,max =1.0 )
    solidify_even :BoolProperty (name ="Solidify Even Thickness",description ="Keep shell thickness more even across angled surfaces when the modifier supports it.",default =True )
    solidify_quality_normals :BoolProperty (name ="Solidify Quality Normals",description ="Enable higher-quality solidify normal handling for cleaner shading on complex shells.",default =True )
    solidify_rim :BoolProperty (name ="Solidify Rim",description ="Create rim faces so the thickened shell is closed instead of leaving open borders.",default =True )

    bend_angle_deg :FloatProperty (name ="Bend Angle (deg)",description ="Angle in degrees applied by the Bend deformer. Positive and negative values bend in opposite directions.",default =45.0 ,soft_min =-360.0 ,soft_max =360.0 )
    bend_axis :EnumProperty (name ="Bend Axis",description ="Primary axis used by the Bend deformer.",items =[('X','X',''),('Y','Y',''),('Z','Z','')],default ='Z')
    bend_lower_limit :FloatProperty (name ="Bend Lower Limit",description ="Lower normalized limit for the Bend modifier, useful for partial roll and localized deformation.",default =0.0 ,min =0.0 ,max =1.0 )
    bend_upper_limit :FloatProperty (name ="Bend Upper Limit",description ="Upper normalized limit for the Bend modifier, useful for partial roll and localized deformation.",default =1.0 ,min =0.0 ,max =1.0 )
    bend_use_cursor_origin :BoolProperty (name ="Use Cursor Origin",description ="Create or update a dedicated origin empty at the 3D cursor and use it as the Bend modifier origin.",default =True )

    lattice_points_u :IntProperty (name ="Lattice U",description ="Number of lattice control points along the local U axis.",default =3 ,min =2 ,soft_max =16 )
    lattice_points_v :IntProperty (name ="Lattice V",description ="Number of lattice control points along the local V axis.",default =3 ,min =2 ,soft_max =16 )
    lattice_points_w :IntProperty (name ="Lattice W",description ="Number of lattice control points along the local W axis.",default =4 ,min =2 ,soft_max =16 )
    lattice_padding :FloatProperty (name ="Lattice Padding",description ="Extra scale added around the active object when fitting the generated lattice cage.",default =0.08 ,min =0.0 ,soft_max =2.0 )
    lattice_use_outside :BoolProperty (name ="Outside Only",description ="Use only the outer lattice points when the generated lattice supports it.",default =False )


    cast_factor :FloatProperty (name ="Cast Factor",description ="Strength of the Cast deformation. Larger values push the mesh further toward the chosen primitive type.",default =1.0 ,soft_min =-10.0 ,soft_max =10.0 )
    cast_type :EnumProperty (name ="Cast Type",description ="Primitive type used by the Cast modifier.",items =[('SPHERE','Sphere',''),('CYLINDER','Cylinder',''),('CUBOID','Cuboid','')],default ='SPHERE')
    cast_radius :FloatProperty (name ="Cast Radius",description ="Optional radius limit used by the Cast modifier when supported. Set 0 to let Blender manage it automatically.",default =0.0 ,min =0.0 ,soft_max =100.0 )
    cast_use_x :BoolProperty (name ="Cast X",description ="Allow the Cast modifier to affect the local X direction.",default =True )
    cast_use_y :BoolProperty (name ="Cast Y",description ="Allow the Cast modifier to affect the local Y direction.",default =True )
    cast_use_z :BoolProperty (name ="Cast Z",description ="Allow the Cast modifier to affect the local Z direction.",default =True )
    cast_use_cursor_origin :BoolProperty (name ="Use Cursor Origin for Cast",description ="Create or update a dedicated origin empty at the 3D cursor and use it as the Cast modifier control object when supported.",default =False )


BoolProperty = _BpyBoolProperty
EnumProperty = _BpyEnumProperty
FloatProperty = _BpyFloatProperty
IntProperty = _BpyIntProperty
PointerProperty = _BpyPointerProperty

class SMSA_OT_surface_box_detail (Operator ):
    bl_idname ="smsa.surface_box_detail"
    bl_label ="Surface Box Detail"
    bl_description ="Create a detail box aligned to the active face. This is useful for kitbash details, panel blocks, trim pieces, and quick boolean helpers inspired by KIT OPS, Primo Kit, NitroDraw, and surface-first hard-surface workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =_active_mesh_object (context )
        return obj is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        target =_active_mesh_object (context )
        if target is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh face in Edit Mode"))
            return {'CANCELLED'}

        props =context .scene .smsa_props 
        bm =bmesh .from_edit_mesh (target .data )
        face =bm .faces .active 
        if face is None or not face .select :
            selected_faces =[f for f in bm .faces if f .select ]
            face =selected_faces [0 ]if selected_faces else None 
        if face is None :
            self .report ({'WARNING'},_t ("Need an active mesh face in Edit Mode"))
            return {'CANCELLED'}

        center_local =face .calc_center_median ()
        normal_local =face .normal .normalized ()
        longest =None 
        longest_len =-1.0 
        for edge in face .edges :
            vec =edge .verts [1 ].co -edge .verts [0 ].co 
            length =vec .length 
            if length >longest_len :
                longest =vec .copy ()
                longest_len =length 
        tangent_local =longest if longest is not None else normal_local .orthogonal ()
        tangent_local =tangent_local -normal_local *tangent_local .dot (normal_local )
        if tangent_local .length <1e-8 :
            tangent_local =normal_local .orthogonal ()
        tangent_local .normalize ()
        bitangent_local =normal_local .cross (tangent_local ).normalized ()

        world_m3 =target .matrix_world .to_3x3 ()
        center_world =target .matrix_world @center_local 
        normal_world =(world_m3 @normal_local ).normalized ()
        tangent_world =(world_m3 @tangent_local ).normalized ()
        bitangent_world =normal_world .cross (tangent_world ).normalized ()

        width =max (1e-6 ,float (props .surface_box_width ))
        length =max (1e-6 ,float (props .surface_box_length ))
        height =max (1e-6 ,float (props .surface_box_height ))
        embed =height *0.35 if props .surface_box_operation =='DIFFERENCE'else 0.0 

        old_mode =context .mode 
        if old_mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        try :
            mesh =_new_box_mesh ("SMS_SurfaceDetail",width ,length ,height )
            detail =bpy .data .objects .new (mesh .name ,mesh )
            basis =Matrix ((
            tangent_world .to_4d (),
            bitangent_world .to_4d (),
            normal_world .to_4d (),
            Vector ((0.0 ,0.0 ,0.0 ,1.0 )),
            )).transposed ()
            basis .translation =center_world -(normal_world *embed )
            detail .matrix_world =basis 

            for col in target .users_collection :
                _link_object_to_collection (detail ,col )
            if not detail .users_collection :
                _link_object_to_collection (detail ,context .scene .collection )

            if props .surface_box_wire :
                try :
                    detail .display_type ='WIRE'
                except Exception :
                    pass 
            if props .surface_box_parent :
                try :
                    detail .parent =target 
                    detail .matrix_parent_inverse =target .matrix_world .inverted ()
                except Exception :
                    pass 

            if props .surface_box_operation !='NONE':
                mod =target .modifiers .new (name =f"SMS_Detail_{props .surface_box_operation .title ()}",type ='BOOLEAN')
                mod .object =detail 
                mod .operation =props .surface_box_operation 
                try :
                    mod .solver ='EXACT'
                except Exception :
                    pass 

            _make_target_active (context ,target )
            if old_mode =='EDIT_MESH':
                safe_mode_set ('EDIT')
        except Exception :
            _make_target_active (context ,target )
            if old_mode =='EDIT_MESH':
                safe_mode_set ('EDIT')
            raise 

        self .report ({'INFO'},_t ("Created surface detail helper"))
        return {'FINISHED'}


class SMSA_OT_smart_extrude_clean (Operator ):
    bl_idname ="smsa.smart_extrude_clean"
    bl_label ="Smart Extrude Clean"
    bl_description ="Run a compact face-modeling helper that optionally insets first, then extrudes and shrink-fattens the current selection. This acts as a practical Blender-native helper inspired by Maya Smart Extrude and ZModeler QMesh style workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =_active_mesh_object (context )
        return obj is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        props =context .scene .smsa_props 
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need a face selection to run Smart Extrude Clean"))
            return {'CANCELLED'}

        bm =bmesh .from_edit_mesh (obj .data )
        if not any (f .select for f in bm .faces ):
            self .report ({'WARNING'},_t ("Need a face selection to run Smart Extrude Clean"))
            return {'CANCELLED'}

        inset =max (0.0 ,float (props .smart_extrude_inset ))
        distance =float (props .smart_extrude_distance )

        if inset >0.0 :
            call_operator_safe (lambda :bpy .ops .mesh .inset ('EXEC_DEFAULT', False, thickness =inset ,depth =0.0 ,use_even_offset =True ,use_boundary =True ))

        extrude_result =call_operator_safe (
        lambda :bpy .ops .mesh .extrude_region_move ('EXEC_DEFAULT', False, 
        MESH_OT_extrude_region ={"use_dissolve_ortho_edges":False ,"mirror":False },
        TRANSFORM_OT_translate ={"value":(0.0 ,0.0 ,0.0 )},
        )
        )
        if extrude_result is None :
            self .report ({'WARNING'},_t ("Need a face selection to run Smart Extrude Clean"))
            return {'CANCELLED'}
        if call_operator_safe (lambda :bpy .ops .transform .shrink_fatten ('EXEC_DEFAULT', False, value =distance ,use_even_offset =bool (props .smart_extrude_even )))is None :
            self .report ({'WARNING'},_t ("Need a face selection to run Smart Extrude Clean"))
            return {'CANCELLED'}

        if props .smart_extrude_recalc :
            call_operator_safe (lambda :bpy .ops .mesh .normals_make_consistent ('EXEC_DEFAULT', False, inside =False ))

        self .report ({'INFO'},_t ("Smart extrude complete"))
        return {'FINISHED'}


class SMSA_OT_slice_panel_stack (Operator ):
    bl_idname ="smsa.slice_panel_stack"
    bl_label ="Slice / Panel Stack"
    bl_description ="Create evenly spaced boolean helper boxes across the active mesh bounds to build grooves, slots, layered cuts, and contour-like panel patterns. This is a practical non-destructive generator inspired by Slicer, NitroBoxTool, and panel-line boolean workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =_active_mesh_object (context )
        return obj is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        target =_active_mesh_object (context )
        if target is None :
            return {'CANCELLED'}
        props =context .scene .smsa_props 

        local_points =[Vector (corner )for corner in target .bound_box ]
        mins =Vector ((min (v .x for v in local_points ),min (v .y for v in local_points ),min (v .z for v in local_points )))
        maxs =Vector ((max (v .x for v in local_points ),max (v .y for v in local_points ),max (v .z for v in local_points )))
        axis_map ={'X':0 ,'Y':1 ,'Z':2 }
        axis =axis_map .get (props .slice_axis ,0 )
        extent =maxs [axis ]-mins [axis ]
        if extent <=1e-6 :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}

        thickness =min (max (1e-6 ,float (props .slice_thickness )),max (1e-6 ,extent *0.95 ))
        margin =max (0.01 ,max ((maxs [i ]-mins [i ])for i in range (3 )if i !=axis )*0.05 )
        collection =_ensure_collection (context ,f"SMS_Slice_{target .name }")if props .slice_organize else None 

        for idx in range (int (props .slice_count )):
            t =(idx +1 )/(float (props .slice_count )+1.0 )
            center =mins [axis ]+extent *t 
            min_corner =mins .copy ()
            max_corner =maxs .copy ()
            min_corner [axis ]=center -thickness *0.5 
            max_corner [axis ]=center +thickness *0.5 
            for i in range (3 ):
                if i !=axis :
                    min_corner [i ]-=margin 
                    max_corner [i ]+=margin 

            mesh =_new_bbox_box_mesh (f"SMS_Slice_{idx :03d}",min_corner ,max_corner )
            cutter =bpy .data .objects .new (mesh .name ,mesh )
            cutter .matrix_world =target .matrix_world .copy ()
            if collection is not None :
                _link_object_to_collection (cutter ,collection )
            else :
                for col in target .users_collection :
                    _link_object_to_collection (cutter ,col )
                if not cutter .users_collection :
                    _link_object_to_collection (cutter ,context .scene .collection )

            if props .slice_wire :
                try :
                    cutter .display_type ='WIRE'
                except Exception :
                    pass 

            mod =target .modifiers .new (name =f"SMS_Slice_{idx :03d}",type ='BOOLEAN')
            mod .object =cutter 
            mod .operation =props .slice_operation 
            try :
                mod .solver ='EXACT'
            except Exception :
                pass 

        self .report ({'INFO'},_t ("Created slice/panel boolean helpers"))
        return {'FINISHED'}


class SMSA_OT_combine_join_clean (Operator ):
    bl_idname ="smsa.combine_join_clean"
    bl_label ="Combine / Join Clean"
    bl_description ="Join the selected mesh objects while keeping the active object as the pivot/origin owner, then optionally run a light cleanup pass. This acts as a Blender-friendly helper inspired by FB combine and clean combine scripts."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        active =_active_mesh_object (context )
        return active is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        active =_active_mesh_object (context )
        if active is None :
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        meshes =[o for o in context .selected_objects if o and o .type =='MESH']
        if len (meshes )<2 :
            self .report ({'WARNING'},_t ("Select at least one other mesh object to join"))
            return {'CANCELLED'}

        state =capture_object_context (context )
        safe_select_all ('DESELECT')
        for obj in meshes :
            obj .select_set (True )
        context .view_layer .objects .active =active 
        if safe_join_selected ()is None :
            restore_object_context (context ,state ,restore_mode =False )
            self .report ({'WARNING'},_t ("Select at least one other mesh object to join"))
            return {'CANCELLED'}
        joined =context .view_layer .objects .active 

        cleanup_skipped =False 
        if props .combine_cleanup and joined and joined .type =='MESH':
            if safe_mode_set ('EDIT')is None :
                cleanup_skipped =True 
            else :
                bm =bmesh .from_edit_mesh (joined .data )
                verts =list (bm .verts )
                if verts :
                    try :
                        bmesh .ops .remove_doubles (bm ,verts =verts ,dist =1e-6 )
                    except Exception :
                        pass 
                    try :
                        bmesh .ops .dissolve_degenerate (bm ,edges =list (bm .edges ),dist =1e-6 )
                    except Exception :
                        pass 
                    if props .combine_cleanup_normals :
                        try :
                            bmesh .ops .recalc_face_normals (bm ,faces =list (bm .faces ))
                        except Exception :
                            pass 
                bmesh .update_edit_mesh (joined .data ,loop_triangles =True ,destructive =True )
                if safe_mode_set ('OBJECT')is None :
                    self .report ({'WARNING'},_t ('Join succeeded, but returning to Object Mode failed after cleanup.'))
        if cleanup_skipped :
            self .report ({'WARNING'},_t ('Join succeeded, but cleanup was skipped because Edit Mode was unavailable.'))

        self .report ({'INFO'},_t ("Join / cleanup complete"))
        return {'FINISHED'}


class SMSA_OT_drop_to_surface (Operator ):
    bl_idname ="smsa.drop_to_surface"
    bl_label ="Drop To Surface"
    bl_description ="Drop the selected objects onto the active surface along world -Z using bounding-box based placement, with optional normal alignment. This is useful for DropIt / Drop to Floor style scene dressing and layout work."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        active =_active_mesh_object (context )
        return active is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        surface =_active_mesh_object (context )
        if surface is None :
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        others =[o for o in context .selected_objects if o and o !=surface ]
        if not others :
            self .report ({'WARNING'},_t ("Select at least one other object besides the active surface"))
            return {'CANCELLED'}

        depsgraph =context .evaluated_depsgraph_get ()
        eval_surface =surface .evaluated_get (depsgraph )
        surface_inv =surface .matrix_world .inverted ()
        surface_inv_rot =surface .matrix_world .to_3x3 ().inverted ()
        placed =0 
        direction_world =Vector ((0.0 ,0.0 ,-1.0 ))
        direction_local =(surface_inv_rot @direction_world ).normalized ()
        surface_world_points =_bbox_world_points (surface )
        world_top =max (p .z for p in surface_world_points )+10000.0 

        for obj in others :
            bbox =_bbox_world_points (obj )
            center =sum (bbox ,Vector ())/8.0 
            sample_points =[center ]
            minx =min (p .x for p in bbox );maxx =max (p .x for p in bbox )
            miny =min (p .y for p in bbox );maxy =max (p .y for p in bbox )
            sample_points .extend ([
            Vector ((minx ,miny ,center .z )),
            Vector ((minx ,maxy ,center .z )),
            Vector ((maxx ,miny ,center .z )),
            Vector ((maxx ,maxy ,center .z )),
            ])
            best_hit =None 
            for p in sample_points :
                origin_world =Vector ((p .x ,p .y ,world_top ))
                origin_local =surface_inv @origin_world 
                hit ,hit_local ,normal_local ,face_index =eval_surface .ray_cast (origin_local ,direction_local )
                if hit :
                    hit_world =surface .matrix_world @hit_local 
                    normal_world =(surface .matrix_world .to_3x3 ()@normal_local ).normalized ()
                    if best_hit is None or hit_world .z >best_hit [0 ].z :
                        best_hit =(hit_world ,normal_world )
            if best_hit is None :
                continue 

            placed +=1 
            hit_world ,normal_world =best_hit 
            if props .drop_use_bounds :
                min_obj_z =min (p .z for p in bbox )
                delta =(hit_world .z +props .drop_offset )-min_obj_z 
                obj .location .z +=delta 
            else :
                new_loc =obj .location .copy ()
                new_loc .x =hit_world .x 
                new_loc .y =hit_world .y 
                new_loc .z =hit_world .z +props .drop_offset 
                obj .location =new_loc 

            if props .drop_align_to_surface :
                try :
                    up =Vector ((0.0 ,0.0 ,1.0 ))
                    quat =up .rotation_difference (normal_world )
                    obj .rotation_mode ='QUATERNION'
                    obj .rotation_quaternion =quat @obj .rotation_quaternion 
                except Exception :
                    pass 

        if placed <=0 :
            self .report ({'WARNING'},_t ("No selected object lies over the active surface"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Dropped selected objects to active surface"))
        return {'FINISHED'}


class SMSA_OT_quick_solidify_plus (Operator ):
    bl_idname ="smsa.quick_solidify_plus"
    bl_label ="Quick Solidify Plus"
    bl_description ="Create or update a non-destructive Solidify modifier on the active mesh with even-thickness and quality-normal options. Useful for shelling, panel thickness, CAD-style wall offsets, Solidify Plus style workflows, and quick hard-surface thickness passes."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None 

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None :
            self .report ({'WARNING'},_t ("Need an active mesh object"))
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        old_mode =context .mode 
        if old_mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        try :
            mod =_find_modifier (obj ,'SOLIDIFY','SMS_Solidify')
            if mod is None :
                mod =obj .modifiers .new (name ='SMS_Solidify',type ='SOLIDIFY')
            try :
                mod .thickness =max (0.0001 ,float (props .solidify_thickness ))
            except Exception :
                pass 
            try :
                mod .offset =float (props .solidify_offset )
            except Exception :
                pass 
            for attr ,value in (
            ('use_even_offset',bool (props .solidify_even )),
            ('use_quality_normals',bool (props .solidify_quality_normals )),
            ('use_rim',bool (props .solidify_rim )),
            ):
                if hasattr (mod ,attr ):
                    try :
                        setattr (mod ,attr ,value )
                    except Exception :
                        pass 
            self .report ({'INFO'},_t ("Configured Solidify helper"))
            return {'FINISHED'}
        finally :
            if old_mode .startswith ('EDIT_'):
                try :
                    safe_mode_set ('EDIT')
                except Exception :
                    pass 


class SMSA_OT_quick_bend_deformer (Operator ):
    bl_idname ="smsa.quick_bend_deformer"
    bl_label ="Quick Bend Deformer"
    bl_description ="Create or update a non-destructive Simple Deform Bend setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for Simple Bend, Scroll/Roll style shaping, signage, cables, and fast concept deformation without committing destructive edits."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =getattr (context ,'active_object',None )
        return obj is not None and obj .type in {'MESH','CURVE'}

    def execute (self ,context ):
        obj =getattr (context ,'active_object',None )
        if obj is None or obj .type not in {'MESH','CURVE'}:
            self .report ({'WARNING'},_t ("Need an active mesh or curve object"))
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        old_mode =context .mode 
        if old_mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        try :
            origin =_ensure_cursor_origin_empty (context ,obj ,'SMS_BendOrigin')if props .bend_use_cursor_origin else None 
            _configure_simple_deform (
            obj ,
            'SMS_Bend',
            'BEND',
            props .bend_axis ,
            props .bend_angle_deg ,
            props .bend_lower_limit ,
            props .bend_upper_limit ,
            origin =origin ,
            )
            self .report ({'INFO'},_t ("Configured Bend helper"))
            return {'FINISHED'}
        finally :
            if old_mode .startswith ('EDIT_'):
                try :
                    safe_mode_set ('EDIT')
                except Exception :
                    pass 


class SMSA_OT_quick_lattice_cage (Operator ):
    bl_idname ="smsa.quick_lattice_cage"
    bl_label ="Quick Lattice Cage"
    bl_description ="Create or update a lattice cage around the active object and wire it through a Lattice modifier. Useful for broad-form FFD-style shaping, silhouette blocking, gentle organic cleanup, and non-destructive cage edits inspired by modifier-stack / FFD workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =getattr (context ,'active_object',None )
        return obj is not None and obj .type in {'MESH','CURVE'}

    def execute (self ,context ):
        obj =getattr (context ,'active_object',None )
        if obj is None or obj .type not in {'MESH','CURVE'}:
            self .report ({'WARNING'},_t ("Need an active mesh or curve object"))
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        old_mode =context .mode 
        if old_mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        try :
            lat_name =f"SMS_Lattice_{obj .name }"
            lat_obj =bpy .data .objects .get (lat_name )
            if lat_obj is None or lat_obj .type !='LATTICE':
                lat_data =bpy .data .lattices .new (f"{lat_name }_Data")
                lat_obj =bpy .data .objects .new (lat_name ,lat_data )
                _link_to_same_collections (lat_obj ,obj ,context )
            else :
                _link_to_same_collections (lat_obj ,obj ,context )
            lat =lat_obj .data 
            try :
                lat .points_u =max (2 ,int (props .lattice_points_u ))
                lat .points_v =max (2 ,int (props .lattice_points_v ))
                lat .points_w =max (2 ,int (props .lattice_points_w ))
            except Exception :
                pass 
            if hasattr (lat ,'use_outside'):
                try :
                    lat .use_outside =bool (props .lattice_use_outside )
                except Exception :
                    pass 

            bbox_local =[Vector (corner )for corner in obj .bound_box ]
            min_corner =Vector ((min (v .x for v in bbox_local ),min (v .y for v in bbox_local ),min (v .z for v in bbox_local )))
            max_corner =Vector ((max (v .x for v in bbox_local ),max (v .y for v in bbox_local ),max (v .z for v in bbox_local )))
            center_local =(min_corner +max_corner )*0.5 
            half_local =(max_corner -min_corner )*0.5 
            world_loc ,world_rot ,world_scale =obj .matrix_world .decompose ()
            world_scale_abs =Vector ((abs (world_scale .x ),abs (world_scale .y ),abs (world_scale .z )))
            pad =1.0 +max (0.0 ,float (props .lattice_padding ))
            half_world =Vector ((
            max (0.001 ,half_local .x *max (1e-6 ,world_scale_abs .x )*pad ),
            max (0.001 ,half_local .y *max (1e-6 ,world_scale_abs .y )*pad ),
            max (0.001 ,half_local .z *max (1e-6 ,world_scale_abs .z )*pad ),
            ))
            center_world =obj .matrix_world @center_local 
            lat_obj .matrix_world =Matrix .Translation (center_world )@world_rot .to_matrix ().to_4x4 ()
            lat_obj .scale =half_world 
            try :
                lat_obj .hide_render =True 
            except Exception :
                pass 

            mod =_find_modifier (obj ,'LATTICE','SMS_Lattice')
            if mod is None :
                mod =obj .modifiers .new (name ='SMS_Lattice',type ='LATTICE')
            if hasattr (mod ,'object'):
                try :
                    mod .object =lat_obj 
                except Exception :
                    pass 
            self .report ({'INFO'},_t ("Configured Lattice helper"))
            return {'FINISHED'}
        finally :
            if old_mode .startswith ('EDIT_'):
                try :
                    safe_mode_set ('EDIT')
                except Exception :
                    pass 


class SMSA_OT_quick_cast_modifier (Operator ):
    bl_idname ="smsa.quick_cast_modifier"
    bl_label ="Cast Modifier"
    bl_description ="Create or update a non-destructive Cast modifier on the active mesh. Useful for sphere/cylinder/cuboid fitting, quick circle/spherify shaping, and upper-compatible max-style form correction inside the modifier stack."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Need an active mesh object in Object Mode"))
            return {'CANCELLED'}
        props =context .scene .smsa_props 
        control =None 
        if bool (props .cast_use_cursor_origin ):
            control =_ensure_cursor_origin_empty (context ,obj ,"SMS_CastOrigin")
        _configure_cast_modifier (
        obj ,
        "SMS_Cast",
        props .cast_type ,
        float (props .cast_factor ),
        float (props .cast_radius ),
        bool (props .cast_use_x ),
        bool (props .cast_use_y ),
        bool (props .cast_use_z ),
        control_obj =control ,
        )
        self .report ({'INFO'},_t ("Cast setup complete"))
        return {'FINISHED'}



class VIEW3D_PT_sms_advanced (Panel ):
    bl_label ="Advanced / Surface Modeling"
    bl_description ='Advanced / Surface Modeling panel in the Smart Modifier workspace.'
    bl_idname ="VIEW3D_PT_sms_advanced"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}
    bl_order =55

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'advanced_surface_modeling', context=context)

    def draw (self ,context ):
        layout =self .layout 
        layout .use_property_split =True 
        layout .use_property_decorate =False 
        props =context .scene .smsa_props 
        draw_help_header (layout ,context ,'Advanced / Surface Modeling','MESH_CUBE','advanced_surface_modeling')

        box =layout .box ()
        draw_help_header (box ,context ,"Surface Detail / Layout",'MESH_CUBE','advanced_surface_detail')
        row =box .row (align =True )
        row .prop (props ,'surface_box_width')
        row .prop (props ,'surface_box_length')
        row .prop (props ,'surface_box_height')
        row =box .row (align =True )
        row .prop (props ,'surface_box_operation')
        row =box .row (align =True )
        row .prop (props ,'surface_box_wire')
        row .prop (props ,'surface_box_parent')
        row =box .row (align =True )
        row .scale_y =1.15 
        _draw_panel_operator (row ,context ,'smsa.surface_box_detail',icon ='MESH_CUBE')

        box =layout .box ()
        draw_help_header (box ,context ,"Smart Extrude Clean",'FACESEL','advanced_extrude_slice')
        row =box .row (align =True )
        row .prop (props ,'smart_extrude_inset')
        row .prop (props ,'smart_extrude_distance')
        row =box .row (align =True )
        row .prop (props ,'smart_extrude_even')
        row .prop (props ,'smart_extrude_recalc')
        row =box .row (align =True )
        row .scale_y =1.15 
        _draw_panel_operator (row ,context ,'smsa.smart_extrude_clean',icon ='FACESEL')

        box =layout .box ()
        draw_help_header (box ,context ,"Slice / Panel Stack",'MOD_BOOLEAN','advanced_extrude_slice')
        row =box .row (align =True )
        row .prop (props ,'slice_axis')
        row .prop (props ,'slice_count')
        row .prop (props ,'slice_thickness')
        row =box .row (align =True )
        row .prop (props ,'slice_operation')
        row =box .row (align =True )
        row .prop (props ,'slice_wire')
        row .prop (props ,'slice_organize')
        row =box .row (align =True )
        row .scale_y =1.15 
        _draw_panel_operator (row ,context ,'smsa.slice_panel_stack',icon ='MOD_BOOLEAN')

        box =layout .box ()
        draw_help_header (box ,context ,"Combine / Join Clean",'AUTOMERGE_ON','advanced_assembly_drop')
        row =box .row (align =True )
        row .prop (props ,'combine_cleanup')
        row .prop (props ,'combine_cleanup_normals')
        row =box .row (align =True )
        row .scale_y =1.15 
        _draw_panel_operator (row ,context ,'smsa.combine_join_clean',icon ='AUTOMERGE_ON')

        box =layout .box ()
        draw_help_header (box ,context ,"Drop To Surface",'SNAP_ON','advanced_assembly_drop')
        row =box .row (align =True )
        row .prop (props ,'drop_offset')
        row .prop (props ,'drop_align_to_surface')
        row .prop (props ,'drop_use_bounds')
        row =box .row (align =True )
        row .scale_y =1.15 
        _draw_panel_operator (row ,context ,'smsa.drop_to_surface',icon ='SNAP_ON')


class VIEW3D_PT_sms_advanced_help (Panel ):
    bl_label ="Guide / Tips"
    bl_description ='Retired compact guide panel. Use the Help icon buttons for detailed localized help.'
    bl_idname ="VIEW3D_PT_sms_advanced_help"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}

    def draw (self ,context ):
        layout =self .layout
        draw_help_header (layout ,context ,'Advanced / Surface Modeling','MESH_CUBE','advanced_surface_modeling')




def _sms_root_only_panel_poll (cls ,context):
    # This panel body is rendered by Smart Modifier's unified root section UI.
    # Hide the separate Blender child-panel header to avoid duplicate section names.
    return False

def _sms_panel_draw_guard (draw_fn ,label ):
    def _wrapped (self ,context ):
        try :
            return draw_fn (self ,context )
        except Exception :
            try :
                layout =getattr (self ,'layout',None )
                if layout is not None :
                    box =layout .box ()
                    box .label (text =_t ('Smart Modifier UI could not be drawn safely.'),icon ='ERROR')
                    box .label (text =_t ('Close and reopen the N-panel, or reload the add-on if this message persists.'),icon='NONE')
            except Exception :
                pass
            return None
    return _wrapped

VIEW3D_PT_sms_advanced .poll =classmethod (_sms_root_only_panel_poll)
VIEW3D_PT_sms_advanced_help .poll =classmethod (_sms_root_only_panel_poll)

VIEW3D_PT_sms_advanced .draw =_sms_panel_draw_guard (VIEW3D_PT_sms_advanced .draw ,'VIEW3D_PT_sms_advanced')
VIEW3D_PT_sms_advanced_help .draw =_sms_panel_draw_guard (VIEW3D_PT_sms_advanced_help .draw ,'VIEW3D_PT_sms_advanced_help')

classes =(
SMSA_Props ,
SMSA_OT_surface_box_detail ,
SMSA_OT_smart_extrude_clean ,
SMSA_OT_slice_panel_stack ,
SMSA_OT_combine_join_clean ,
SMSA_OT_quick_solidify_plus ,
SMSA_OT_quick_bend_deformer ,
SMSA_OT_quick_lattice_cage ,
SMSA_OT_quick_cast_modifier ,
SMSA_OT_drop_to_surface ,
)


def _unregister_retired_panel (class_name :str ):
    cls =getattr (bpy .types ,str (class_name or ''),None )
    if cls is None :
        return 
    try :
        pass  # session-stable: keep classes registered during live UI
    except Exception :
        pass 


def register ():
    _unregister_retired_panel ("VIEW3D_PT_sms_advanced")
    _unregister_retired_panel ("VIEW3D_PT_sms_advanced_help")
    try :
        bpy .app .translations .register (__name__ ,translation_catalog_dict )
    except ValueError :
        try :
            bpy .app .translations .unregister (__name__ )
        except Exception :
            pass 
        try :
            bpy .app .translations .register (__name__ ,translation_catalog_dict )
        except Exception :
            pass 
    except Exception :
        pass 

    for cls in classes :
        _safe_register_class (cls )
    try :
        bpy .types .Scene .smsa_props =PointerProperty (type =SMSA_Props ,description ='Stores settings for the Advanced / Surface Modeling panel.')
    except Exception :
        pass 


def unregister ():
    _unregister_retired_panel ("VIEW3D_PT_sms_advanced")
    _unregister_retired_panel ("VIEW3D_PT_sms_advanced_help")
    try :
        del bpy .types .Scene .smsa_props 
    except Exception :
        pass 
    for cls in reversed (classes ):
        _safe_unregister_class (cls )
    try :
        bpy .app .translations .unregister (__name__ )
    except Exception :
        pass 


        # --- Tooltip completion (advanced panels) ---
VIEW3D_PT_sms_advanced .bl_description ='Compact advanced panel for surface-first hard-surface helpers, slice panels, bend/twist/taper/lattice/cast deformation, thickness, clean combine, and surface drop utilities.'
VIEW3D_PT_sms_advanced_help .bl_description ='Beginner-friendly workflow notes for the advanced surface modeling helpers.'
# --- Toolset complete i18n override START ---
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', 'Beginner-friendly workflow notes for the advanced surface modeling helpers.'): '高度サーフェスモデリング補助の初心者向けワークフローメモです。',
 ('*', 'Cast X'): 'X方向キャスト',
 ('*', 'Cast Y'): 'Y方向キャスト',
 ('*', 'Cast Z'): 'Z方向キャスト',
 ('*', 'How the generated surface detail box should be used.'): '生成するサーフェスディテール箱の使用方法です。',
 ('*', 'Stores settings for the Advanced / Surface Modeling panel.'): 'Advanced / Surface Modeling パネル用の設定を保持します。'})
# --- Toolset complete i18n override END ---


# Final Japanese overrides for entries that should not remain English in Japanese UI.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Cast Modifier'): 'キャストモディファイア',
    ('*', 'Cast X'): 'X方向キャスト',
    ('*', 'Cast Y'): 'Y方向キャスト',
    ('*', 'Cast Z'): 'Z方向キャスト',
})


translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Smart Modifier UI could not be drawn safely.'): 'Smart Modifier UIを安全に描画できませんでした。',
    ('*', 'Close and reopen the N-panel, or reload the add-on if this message persists.'): 'この表示が続く場合は、Nパネルを閉じて開き直すか、アドオンを再読み込みしてください。',
})
