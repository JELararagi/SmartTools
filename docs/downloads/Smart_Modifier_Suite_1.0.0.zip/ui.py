# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from .translation import pgettext_iface as pgettext 
import importlib
import json
import sys
import time
import bpy 
from bpy.props import StringProperty
from .core import *
from .import modswitcher 
from . import feature_toggle 
from . import persistent_state 
from .plugin_catalog import GROUP_META ,PLUGIN_CATALOG ,get_plugin_group_icon ,get_plugin_group_label ,get_plugin_meta ,iter_plugins_grouped ,is_stack_addable_plugin 
from .translation import choose_text ,pgettext_iface as locale_pgettext_iface 
from .preferences import draw_smart_tools_preferences ,get_preferences 
from .help_button import draw_help_button, draw_help_header 

try:
    from .icons import icon_value as _sms_icon_value, icon_name_for_modifier as _sms_icon_for_modifier, icon_name_for_plugin as _sms_icon_for_plugin, operator as _sms_icon_operator, prop as _sms_icon_prop, large_icon_button_row as _sms_large_icon_row
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0
    def _sms_icon_for_modifier(mod, fallback='modifier'): return fallback
    def _sms_icon_for_plugin(plugin, fallback='modifier'): return fallback
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None, translate=None):
        kwargs={'text': text}
        if translate is not None: kwargs['translate']=bool(translate)
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)
    def _sms_icon_prop(layout, data, prop_name, *, text='', icon_name='', fallback_icon='NONE', **kwargs):
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        try:
            return layout.prop(data, prop_name, text=text, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.prop(data, prop_name, text=text, **kwargs)
    def _sms_large_icon_row(layout, *, align=True, scale_y=1.18):
        row=layout.row(align=align)
        try: row.scale_y=scale_y
        except Exception: pass
        return row


def _sms_draw_menu(layout, menu_idname, *, text='', icon_name='', fallback_icon='NONE'):
    try:
        icon_id = _sms_icon_value(icon_name, fallback_icon)
        if icon_id:
            try:
                return layout.menu(menu_idname, text=text, icon_value=icon_id)
            except Exception:
                pass
    except Exception:
        pass
    if fallback_icon and fallback_icon != 'NONE':
        try:
            return layout.menu(menu_idname, text=text, icon=fallback_icon)
        except Exception:
            pass
    return layout.menu(menu_idname, text=text)



def _sms_icon_name_for_modifier_type(mod_type: str) -> str:
    # Blender 5.1.x exposes more specific modifier enum icons than the older
    # Smart Modifier mapping.  Keep this draw-safe and string-only so it can be
    # used both in the stack rows and in add menus without touching RNA during
    # every redraw.
    mapping = {
        'GREASE_PENCIL_VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
        'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
        'MESH_CACHE': 'MOD_MESHDEFORM',
        'MESH_SEQUENCE_CACHE': 'MOD_MESHDEFORM',
        'NORMAL_EDIT': 'MOD_NORMALEDIT',
        'WEIGHTED_NORMAL': 'MOD_NORMALEDIT',
        'UV_PROJECT': 'MOD_UVPROJECT',
        'UV_WARP': 'MOD_UVPROJECT',
        'VERTEX_WEIGHT_EDIT': 'MOD_VERTEX_WEIGHT',
        'VERTEX_WEIGHT_MIX': 'MOD_VERTEX_WEIGHT',
        'VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
        'GREASE_PENCIL_COLOR': 'MOD_HUE_SATURATION',
        'GREASE_PENCIL_TINT': 'MOD_TINT',
        'GREASE_PENCIL_OPACITY': 'MOD_OPACITY',
        'GREASE_PENCIL_VERTEX_WEIGHT_ANGLE': 'MOD_VERTEX_WEIGHT',
        'GREASE_PENCIL_TIME': 'MOD_TIME',
        'GREASE_PENCIL_TEXTURE': 'MOD_UVPROJECT',
        'ARRAY': 'MOD_ARRAY',
        'BEVEL': 'MOD_BEVEL',
        'BOOLEAN': 'MOD_BOOLEAN',
        'BUILD': 'MOD_BUILD',
        'DECIMATE': 'MOD_DECIM',
        'EDGE_SPLIT': 'MOD_EDGESPLIT',
        'NODES': 'GEOMETRY_NODES',
        'MASK': 'MOD_MASK',
        'MIRROR': 'MOD_MIRROR',
        'MESH_TO_VOLUME': 'VOLUME_DATA',
        'MULTIRES': 'MOD_MULTIRES',
        'REMESH': 'MOD_REMESH',
        'SCREW': 'MOD_SCREW',
        'SKIN': 'MOD_SKIN',
        'SOLIDIFY': 'MOD_SOLIDIFY',
        'SUBSURF': 'MOD_SUBSURF',
        'TRIANGULATE': 'MOD_TRIANGULATE',
        'VOLUME_TO_MESH': 'VOLUME_DATA',
        'WELD': 'AUTOMERGE_OFF',
        'WIREFRAME': 'MOD_WIREFRAME',
        'GREASE_PENCIL_ARRAY': 'MOD_ARRAY',
        'GREASE_PENCIL_BUILD': 'MOD_BUILD',
        'GREASE_PENCIL_LENGTH': 'MOD_LENGTH',
        'LINEART': 'MOD_LINEART',
        'GREASE_PENCIL_MIRROR': 'MOD_MIRROR',
        'GREASE_PENCIL_MULTIPLY': 'GP_MULTIFRAME_EDITING',
        'GREASE_PENCIL_SIMPLIFY': 'MOD_SIMPLIFY',
        'GREASE_PENCIL_SUBDIV': 'MOD_SUBSURF',
        'GREASE_PENCIL_ENVELOPE': 'MOD_ENVELOPE',
        'GREASE_PENCIL_OUTLINE': 'MOD_OUTLINE',
        'ARMATURE': 'MOD_ARMATURE',
        'CAST': 'MOD_CAST',
        'CURVE': 'MOD_CURVE',
        'DISPLACE': 'MOD_DISPLACE',
        'HOOK': 'HOOK',
        'LAPLACIANDEFORM': 'MOD_MESHDEFORM',
        'LATTICE': 'MOD_LATTICE',
        'MESH_DEFORM': 'MOD_MESHDEFORM',
        'SHRINKWRAP': 'MOD_SHRINKWRAP',
        'SIMPLE_DEFORM': 'MOD_SIMPLEDEFORM',
        'SMOOTH': 'MOD_SMOOTH',
        'CORRECTIVE_SMOOTH': 'MOD_SMOOTH',
        'LAPLACIANSMOOTH': 'MOD_SMOOTH',
        'SURFACE_DEFORM': 'MOD_MESHDEFORM',
        'WARP': 'MOD_WARP',
        'WAVE': 'MOD_WAVE',
        'VOLUME_DISPLACE': 'VOLUME_DATA',
        'GREASE_PENCIL_HOOK': 'HOOK',
        'GREASE_PENCIL_NOISE': 'MOD_NOISE',
        'GREASE_PENCIL_OFFSET': 'MOD_OFFSET',
        'GREASE_PENCIL_SMOOTH': 'SMOOTHCURVE',
        'GREASE_PENCIL_THICKNESS': 'MOD_THICKNESS',
        'GREASE_PENCIL_LATTICE': 'MOD_LATTICE',
        'GREASE_PENCIL_DASH': 'MOD_DASH',
        'GREASE_PENCIL_ARMATURE': 'MOD_ARMATURE',
        'GREASE_PENCIL_SHRINKWRAP': 'MOD_SHRINKWRAP',
        'CLOTH': 'MOD_CLOTH',
        'COLLISION': 'MOD_PHYSICS',
        'DYNAMIC_PAINT': 'MOD_DYNAMICPAINT',
        'EXPLODE': 'MOD_EXPLODE',
        'FLUID': 'MOD_FLUIDSIM',
        'OCEAN': 'MOD_OCEAN',
        'PARTICLE_INSTANCE': 'MOD_PARTICLE_INSTANCE',
        'PARTICLE_SYSTEM': 'MOD_PARTICLES',
        'SOFT_BODY': 'MOD_SOFT',
        'SURFACE': 'SURFACE_DATA',
    }
    return mapping.get(str(mod_type or ''), 'MODIFIER')



def _sms_stack_modifier_icon(mod) -> str:
    """Return the stack-row icon for both standard and custom modifiers."""
    try:
        fallback = _sms_icon_name_for_modifier_type(getattr(mod, 'type', ''))
    except Exception:
        fallback = 'MODIFIER'
    try:
        return _sms_icon_for_modifier(mod, fallback=fallback) or fallback or 'MODIFIER'
    except Exception:
        return fallback or 'MODIFIER'


def _sms_object_icon_for_stack(obj):
    try:
        typ = str(getattr(obj, 'type', '') or '')
    except Exception:
        typ = ''
    return {
        'MESH': 'OUTLINER_OB_MESH',
        'CURVE': 'OUTLINER_OB_CURVE',
        'FONT': 'OUTLINER_OB_FONT',
        'SURFACE': 'OUTLINER_OB_SURFACE',
        'LATTICE': 'OUTLINER_OB_LATTICE',
        'EMPTY': 'OUTLINER_OB_EMPTY',
        'GPENCIL': 'OUTLINER_OB_GREASEPENCIL',
        'GREASEPENCIL': 'OUTLINER_OB_GREASEPENCIL',
        'VOLUME': 'OUTLINER_OB_VOLUME',
    }.get(typ, 'OBJECT_DATA')


def _sms_modifier_count_label(stack_obj):
    try:
        return str(len([m for m in getattr(stack_obj, 'modifiers', []) if not ms_modifier_is_internal_stack_helper(m)]))
    except Exception:
        try:
            return str(len(getattr(stack_obj, 'modifiers', [])))
        except Exception:
            return '0'


def _sms_active_modifier_for_stack(main_obj, stack_obj, active_ui_id):
    try:
        if str(active_ui_id or '') == 'BASE':
            return None
        if not ms_object_has_modifier_collection(stack_obj):
            return None
        mod = stack_obj.modifiers.get(str(active_ui_id or ''))
        if mod and _ms_modifier_is_live_on_object(stack_obj, mod):
            return mod
    except Exception:
        pass
    return None


def _sms_draw_stack_header(layout, context, main_obj, stack_obj, active_mod, is_multi, selected_mains, auto_disable_modifiers, is_end):
    box = layout.box()
    head = box.row(align=True)
    try:
        head.label(text=str(getattr(main_obj, 'name', '') or ''), icon=_sms_object_icon_for_stack(main_obj), translate=False)
    except Exception:
        head.label(text='', icon='OBJECT_DATA')
    info = head.row(align=True)
    try:
        info.alignment = 'RIGHT'
    except Exception:
        pass
    info.label(text=_sms_modifier_count_label(stack_obj), icon='MODIFIER')
    if is_multi:
        try:
            info.label(text=str(len(selected_mains or [])), icon='GROUP')
        except Exception:
            pass

    primary = box.row(align=True)
    primary.operator_context = 'INVOKE_DEFAULT'
    if ms_object_has_modifier_collection(stack_obj):
        _sms_icon_operator(primary, "object.ms_open_add_modifier_popup", text=pgettext('Add Modifier'), icon_name='add', fallback_icon='ADD')
    else:
        disabled = primary.row(align=True)
        disabled.enabled = False
        disabled.label(text=pgettext('Add Modifier'), icon='ADD')
    if getattr(main_obj, 'type', '') == 'MESH':
        _sms_icon_prop(primary, main_obj, "ms_auto_disable_modifiers", text='', icon_name='MODIFIER_ON' if auto_disable_modifiers else 'MODIFIER_OFF', fallback_icon='MODIFIER_ON' if auto_disable_modifiers else 'MODIFIER_OFF', toggle=True)
        _sms_icon_prop(primary, main_obj, "ms_show_end_result", text='', icon_name='visible_on' if is_end else 'visible_off', fallback_icon='HIDE_OFF' if is_end else 'HIDE_ON', toggle=True)
    try:
        help_part = primary.row(align=True)
        help_part.alignment = 'RIGHT'
        draw_help_button(help_part, 'modifier_stack_add_modifier', context=context)
    except Exception:
        pass


def _sms_draw_stack_action_bar(layout, context, stack_obj, active_mod):
    col = layout.column(align=True)
    col.operator_context = 'INVOKE_DEFAULT'
    if ms_object_has_modifier_collection(stack_obj):
        _sms_icon_operator(col, "object.ms_open_add_modifier_popup", text='', icon_name='add', fallback_icon='ADD')
    else:
        sub = col.row(align=True); sub.enabled = False; sub.label(text='', icon='ADD')
    col.separator()
    active_col = col.column(align=True)
    active_col.enabled = bool(active_mod)
    op = _sms_icon_operator(active_col, "object.ms_duplicate_active_modifier", text='', icon_name='copy', fallback_icon='DUPLICATE')
    try:
        op.target_obj_name = stack_obj.name; op.modifier_name = active_mod.name if active_mod else ''
    except Exception:
        pass
    op = _sms_icon_operator(active_col, "object.ms_item_action", text='', icon_name='delete', fallback_icon='X')
    try:
        op.action, op.modifier_name, op.target_obj_name = 'DELETE', (active_mod.name if active_mod else ''), stack_obj.name
    except Exception:
        pass
    col.separator()
    move_col = col.column(align=True)
    move_col.enabled = bool(active_mod)
    op = _sms_icon_operator(move_col, "object.ms_move_active_modifier", text='', icon_name='move_up', fallback_icon='TRIA_UP')
    try:
        op.direction = 'UP'; op.target_obj_name = stack_obj.name; op.modifier_name = active_mod.name if active_mod else ''
    except Exception:
        pass
    op = _sms_icon_operator(move_col, "object.ms_move_active_modifier", text='', icon_name='move_down', fallback_icon='TRIA_DOWN')
    try:
        op.direction = 'DOWN'; op.target_obj_name = stack_obj.name; op.modifier_name = active_mod.name if active_mod else ''
    except Exception:
        pass
    col.separator()
    focus_col = col.column(align=True)
    focus_col.enabled = bool(active_mod)
    op = _sms_icon_operator(focus_col, "object.ms_expand_selected_modifier_only", text='', icon_name='properties_open', fallback_icon='FULLSCREEN_ENTER')
    try:
        op.target_obj_name = stack_obj.name; op.modifier_name = active_mod.name if active_mod else ''
    except Exception:
        pass
    col.separator()
    # Bulk expand / collapse for the custom stack rows.  This is independent of
    # ms_expand_selected_modifier_only above, which drives Blender's native
    # show_expanded flag rather than the Smart Modifier row state.
    bulk_col = col.column(align=True)
    bulk_col.enabled = bool(ms_object_has_modifier_collection(stack_obj))
    op = _sms_icon_operator(bulk_col, "object.ms_set_all_rows_expanded", text='', icon_name='', fallback_icon='DISCLOSURE_TRI_DOWN')
    try:
        op.action = 'EXPAND_ALL'; op.target_obj_name = stack_obj.name
    except Exception:
        pass
    op = _sms_icon_operator(bulk_col, "object.ms_set_all_rows_expanded", text='', icon_name='', fallback_icon='DISCLOSURE_TRI_RIGHT')
    try:
        op.action = 'COLLAPSE_ALL'; op.target_obj_name = stack_obj.name
    except Exception:
        pass

ADDON_ID =_ms_addon_id ()


_SMS_SUPPORTED_NPANEL_SPACE_TYPES = {
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
}

_SMS_CANONICAL_ROOT_PANEL_ID = 'VIEW3D_PT_smart_modifier_root_panel'
_SMS_RETIRED_CROSS_EDITOR_ROOT_PANEL_IDS = (
    'IMAGE_PT_smart_modifier_root_panel',
    'NODE_PT_smart_modifier_root_panel',
    'SEQUENCER_PT_smart_modifier_root_panel',
    'CLIP_PT_smart_modifier_root_panel',
    'DOPESHEET_PT_smart_modifier_root_panel',
    'GRAPH_PT_smart_modifier_root_panel',
    'NLA_PT_smart_modifier_root_panel',
    'TEXT_PT_smart_modifier_root_panel',
    'FILEBROWSER_PT_smart_modifier_root_panel',
    'SPREADSHEET_PT_smart_modifier_root_panel',
)


def _ms_is_view3d_ui_context (context )->bool :
    # Compatibility name kept for existing callers. Smart Tools Manager owns the
    # workspace/editor display rule, so Smart Modifier must not hard-limit its
    # N-panel to only the 3D View when another supported editor has a UI region.
    try :
        area =getattr (context ,'area',None )
        region =getattr (context ,'region',None )
        if area is not None and str (getattr (area ,'type','')or '') not in _SMS_SUPPORTED_NPANEL_SPACE_TYPES:
            return False
        if region is not None and str (getattr (region ,'type','')or '')!='UI':
            return False
    except Exception :
        return False
    return True




def _ms_rna_is_valid (value )->bool :
    """Reject None and invalid Blender RNA wrappers before passing them to UI calls."""
    if value is None :
        return False
    try :
        ptr =getattr (value ,'as_pointer',None )
        if callable (ptr ):
            return bool (int (ptr ()or 0 ))
    except ReferenceError :
        return False
    except Exception :
        return True
    return True


def _ms_object_is_live (obj )->bool :
    if not _ms_rna_is_valid (obj ):
        return False
    try :
        name =str (getattr (obj ,'name','')or '')
        if not name :
            return False
        return bpy .data .objects .get (name )is obj
    except ReferenceError :
        return False
    except Exception :
        return True


def _ms_active_context_object (context ):
    # Selection changes across object data types can leave context.active_object /
    # context.object one redraw behind in the N-panel.  The ViewLayer active RNA is
    # the authoritative source Blender updates for object selection, so prefer it
    # before the convenience context aliases.
    try :
        obj =getattr (getattr (getattr (context ,'view_layer',None ),'objects',None ),'active',None )
        if _ms_object_is_live (obj ):
            return obj
    except Exception :
        pass
    for attr in ('active_object','object','edit_object'):
        try :
            obj =getattr (context ,attr ,None )
            if _ms_object_is_live (obj ):
                return obj
        except Exception :
            pass
    return None


def _ms_context_main_mesh_for_panel (context ,*, allow_edit_helper =True ,require_selected_object_mode =True ):
    # Compatibility name: now resolves any scene object supported by the generic
    # stack UI, not only meshes.  Mesh-only helpers still filter explicitly.
    if not _ms_is_view3d_ui_context (context ):
        return None
    obj =_ms_active_context_object (context )
    if not _ms_object_is_live (obj ):
        return None
    try :
        main_obj =get_main_object (obj )or obj
    except Exception :
        main_obj =obj
    if not _ms_object_is_live (main_obj )or not ms_object_supports_modifier_stack (main_obj ):
        return None
    try :
        mode =str (getattr (context ,'mode','OBJECT')or 'OBJECT')
    except Exception :
        mode ='OBJECT'
    if mode .startswith ('EDIT')and allow_edit_helper :
        return main_obj
    if mode !='OBJECT':
        return None
    if not require_selected_object_mode :
        return main_obj
    try :
        selected =list (getattr (context ,'selected_objects',[])or [])
    except Exception :
        selected =[]
    for selected_obj in selected :
        try :
            mo =get_main_object (selected_obj )or selected_obj
            if _ms_object_is_live (mo )and getattr (mo ,'name','')==getattr (main_obj ,'name',''):
                return main_obj
        except Exception :
            pass
    try :
        if bool (getattr (main_obj ,'select_get',lambda :False )()):
            return main_obj
    except Exception :
        pass
    return None


def _ms_stack_panel_empty_message (context )->str :
    try :
        mode =str (getattr (context ,'mode','OBJECT')or 'OBJECT')
        if mode !='OBJECT'and not mode .startswith ('EDIT')and _ms_object_is_live (_ms_active_context_object (context )):
            return 'Not available in this mode.'
    except Exception :
        pass
    return 'Select an object.'


def _ms_context_has_safe_stack_main (context )->bool :
    return _ms_context_main_mesh_for_panel (context ,allow_edit_helper =True ,require_selected_object_mode =True )is not None


def _ms_modifier_is_live_on_object (obj ,mod )->bool :
    if not _ms_object_is_live (obj )or not _ms_rna_is_valid (mod ):
        return False
    try :
        name =str (getattr (mod ,'name','')or '')
        return bool (name and getattr (obj ,'modifiers',None )and obj .modifiers .get (name )is not None )
    except ReferenceError :
        return False
    except Exception :
        return False


def _ms_safe_prop (layout ,data ,prop ,**kwargs ):
    try :
        if layout is None or not prop or not _ms_rna_is_valid (data ):
            return None
        if not hasattr (data ,prop ):
            return None
        return layout .prop (data ,prop ,**kwargs )
    except Exception :
        return None

def _ms_section_safe_key (*parts )->str :
    text ='_'.join (str (part or '')for part in parts )
    out =[]
    for ch in text:
        if ch .isalnum ():
            out .append (ch .lower ())
        else:
            out .append ('_')
    key ='_'.join (chunk for chunk in ''.join (out ).split ('_')if chunk )
    return key or 'section'


def _ms_child_section_key (*parts )->str :
    return 'ui_child_section_' + _ms_section_safe_key (*parts )


def _ms_set_layout_props_compact (layout ,*, split =False ,decorate =False ):
    try:
        layout .use_property_split =bool (split )
        layout .use_property_decorate =bool (decorate )
    except Exception:
        pass


def _ms_panel_default_open (panel_cls )->bool :
    try:
        options =set (getattr (panel_cls ,'bl_options',set ())or set ())
        return 'DEFAULT_CLOSED' not in options
    except Exception:
        return True


def _ms_draw_child_section (layout ,context ,section_key ,label ,*, icon ='NONE' ,default_open =True ,draw_body =None ,help_topic ='modifier_stack_properties'):
    """Draw a real Blender native child panel.

    Top-level Smart Modifier sections keep their existing custom headers.  Every
    nested section uses ``UILayout.panel()`` so Blender itself owns the thin
    chevron, hit target, and per-region expanded state.  The previous stored
    state is read only as the initial default for a region; subsequent toggles
    are handled entirely by Blender's native panel state.
    """
    del icon
    if layout is None:
        return False
    label_text =pgettext (str (label or ''))
    key =str (section_key or _ms_child_section_key (label_text ))
    try:
        initial_open =_ms_get_section_state (context ,key ,bool (default_open ))
    except Exception:
        initial_open =bool (default_open )
    try:
        header ,panel_body =layout .panel (key ,default_closed =not bool (initial_open ))
        _ms_set_layout_props_compact (header ,split =False ,decorate =False )
        header .label (text =label_text )
        if help_topic :
            try :
                help_row =header .row (align =True )
                help_row .alignment ='RIGHT'
                draw_help_button (help_row ,str (help_topic ),context =context )
            except Exception :
                pass
        if panel_body is not None:
            body =panel_body .column (align =True )
            _ms_set_layout_props_compact (body ,split =False ,decorate =False )
            if callable (draw_body ):
                try:
                    draw_body (body )
                except Exception:
                    try:
                        body .label (text =pgettext ('This section could not be drawn safely.'),icon ='ERROR')
                    except Exception:
                        pass
        return True
    except Exception:
        return False


def _ms_draw_panel_exception (layout ,context ,panel_label ,exc )->None :
    del context ,exc
    try :
        box =layout .box ()
        box .label (text =pgettext ('Smart Modifier UI could not be drawn safely.'),icon ='ERROR')
        box .label (text =pgettext ('Close and reopen the N-panel, or reload the add-on if this message persists.'),icon='NONE')
    except Exception :
        pass


def _ms_guard_panel_draw (draw_fn ,panel_label ):
    def _wrapped (self ,context ):
        try :
            draw_fn (self ,context )
        except Exception as exc :
            _ms_draw_panel_exception (getattr (self ,'layout',None ),context ,panel_label ,exc )
        return None
    try :
        _wrapped .__name__ =getattr (draw_fn ,'__name__','draw')
        _wrapped .__doc__ =getattr (draw_fn ,'__doc__',None )
    except Exception :
        pass
    return _wrapped

def safe_prop (layout ,data ,prop ,**kwargs ):
    _ms_safe_prop (layout ,data ,prop ,**kwargs )

_MS_DATA_INTERNAL_PROP_IDS = {
    'rna_type', 'users', 'use_fake_user', 'is_embedded_data', 'is_evaluated',
    'original', 'override_library', 'preview', 'library', 'asset_data', 'tag',
}
_MS_DATA_HEAVY_COLLECTION_IDS = {
    'vertices', 'edges', 'loops', 'loop_triangles', 'polygons', 'splines',
    'points', 'bezier_points', 'bones', 'edit_bones', 'animation_data',
}


def _ms_base_icon_for_object (obj ):
    typ =str (getattr (obj ,'type','')or '')
    mapping ={
        'MESH':'MESH_DATA','CURVE':'CURVE_DATA','SURFACE':'SURFACE_DATA','META':'META_BALL','FONT':'OUTLINER_DATA_FONT',
        'CURVES':'CURVES_DATA','POINTCLOUD':'POINTCLOUD_DATA','VOLUME':'VOLUME_DATA','GREASEPENCIL':'OUTLINER_DATA_GREASEPENCIL','GPENCIL':'OUTLINER_DATA_GREASEPENCIL',
        'ARMATURE':'ARMATURE_DATA','LATTICE':'LATTICE_DATA','EMPTY':'EMPTY_AXIS','IMAGE':'IMAGE_DATA','LIGHT':'LIGHT_DATA','LIGHT_PROBE':'LIGHTPROBE_SPHERE','LIGHTPROBE':'LIGHTPROBE_SPHERE',
        'CAMERA':'CAMERA_DATA','SPEAKER':'OUTLINER_DATA_SPEAKER',
    }
    try:
        if typ == 'EMPTY' and getattr (obj ,'instance_collection',None )is not None:
            return 'OUTLINER_COLLECTION_INSTANCE'
        if typ == 'EMPTY' and getattr (obj ,'field',None )is not None:
            return 'FORCE_FORCE'
    except Exception:
        pass
    return mapping.get (typ ,'OBJECT_DATA')


def _ms_data_prop_is_user_facing (prop ):
    try:
        identifier =str (getattr (prop ,'identifier','')or '')
        if not identifier or identifier in _MS_DATA_INTERNAL_PROP_IDS:
            return False
        if identifier in _MS_DATA_HEAVY_COLLECTION_IDS:
            return False
        if bool (getattr (prop ,'is_hidden',False )):
            return False
    except Exception:
        return False
    return True


def _ms_draw_rna_owner_properties (layout ,owner ,*, title ='' ,icon ='NONE' ,include_readonly =False ):
    if not _ms_rna_is_valid (owner):
        return False
    if title:
        result ={'drawn':False}
        def _body (body_layout ):
            result ['drawn']=_ms_draw_rna_owner_properties (body_layout ,owner ,title ='' ,icon =icon ,include_readonly =include_readonly )
        _ms_draw_child_section (
            layout ,getattr (bpy ,'context',None ),
            _ms_child_section_key ('rna',type (owner ).__name__,title ),
            title ,icon =icon ,default_open =False ,draw_body =_body,
        )
        return True if result ['drawn']or True else False
    drawn =False
    col =layout .column (align =True )
    try:
        col .use_property_split =True
        col .use_property_decorate =True
    except Exception:
        pass
    try:
        props =list (getattr (getattr (owner ,'bl_rna',None ),'properties',[])or [])
    except Exception:
        props =[]
    for prop in props:
        try:
            pid =str (getattr (prop ,'identifier','')or '')
            if not pid or not hasattr (owner ,pid):
                continue
            if not _ms_data_prop_is_user_facing (prop):
                continue
            readonly =bool (getattr (prop ,'is_readonly',False ))
            ptype =str (getattr (prop ,'type','')or '')
            if readonly and not include_readonly:
                continue
            if ptype =='COLLECTION':
                try:
                    coll =getattr (owner ,pid )
                    n =len (coll )if coll is not None else 0
                    row =col .row (align =True )
                    row .label (text =pgettext (getattr (prop ,'name',pid )or pid),icon ='OUTLINER_COLLECTION')
                    row .label (text =str (n))
                    drawn =True
                except Exception:
                    pass
                continue
            if _ms_safe_prop (col ,owner ,pid )is not None:
                drawn =True
        except Exception:
            continue
    return drawn


def _ms_safe_template_list (layout ,listtype ,dataptr ,propname ,activeptr ,activeprop ,*, rows =3 ):
    try:
        layout .template_list (listtype ,'' ,dataptr ,propname ,activeptr ,activeprop ,rows =rows )
        return True
    except Exception:
        return False


def _ms_draw_common_object_data_lists (layout ,context ,obj ,data ):
    # These templates mirror common Object Data tab lists where Blender exposes
    # a stable Python UIList.  They are nested foldouts to avoid a very tall Base
    # Object property body.
    try:
        if getattr (obj ,'type','')=='MESH' and hasattr (obj ,'vertex_groups'):
            def _body (body):
                _ms_safe_template_list (body ,'MESH_UL_vgroups',obj ,'vertex_groups',obj .vertex_groups ,'active_index',rows =3 )
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'vertex_groups'),pgettext ('Vertex Groups'),icon ='GROUP_VERTEX',default_open =False,draw_body =_body )
    except Exception: pass
    try:
        sk =getattr (data ,'shape_keys',None )if data is not None else None
        if sk is not None and hasattr (sk ,'key_blocks'):
            def _body (body):
                _ms_safe_template_list (body ,'MESH_UL_shape_keys',sk ,'key_blocks',obj ,'active_shape_key_index',rows =3 )
                _ms_draw_rna_owner_properties (body ,sk ,title =pgettext ('Shape Key Data'),icon ='SHAPEKEY_DATA')
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'shape_keys'),pgettext ('Shape Keys'),icon ='SHAPEKEY_DATA',default_open =False,draw_body =_body )
    except Exception: pass
    try:
        if data is not None and hasattr (data ,'uv_layers'):
            def _body (body):
                if not _ms_safe_template_list (body ,'MESH_UL_uvmaps',data ,'uv_layers',data .uv_layers ,'active_index',rows =3 ):
                    row =body .row (align =True); row .label (text =pgettext ('UV Maps')); row .label (text =str (len (data .uv_layers)))
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'uv_maps'),pgettext ('UV Maps'),icon ='GROUP_UVS',default_open =False,draw_body =_body )
    except Exception: pass
    try:
        if data is not None and hasattr (data ,'color_attributes'):
            def _body (body):
                if not _ms_safe_template_list (body ,'MESH_UL_color_attributes',data ,'color_attributes',data .color_attributes ,'active_color_index',rows =3 ):
                    row =body .row (align =True); row .label (text =pgettext ('Color Attributes')); row .label (text =str (len (data .color_attributes)))
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'color_attributes'),pgettext ('Color Attributes'),icon ='GROUP_VCOL',default_open =False,draw_body =_body )
    except Exception: pass
    try:
        if data is not None and hasattr (data ,'attributes'):
            def _body (body):
                if not _ms_safe_template_list (body ,'MESH_UL_attributes',data ,'attributes',data .attributes ,'active_index',rows =3 ):
                    row =body .row (align =True); row .label (text =pgettext ('Attributes')); row .label (text =str (len (data .attributes)))
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'attributes'),pgettext ('Attributes'),icon ='GEOMETRY_NODES',default_open =False,draw_body =_body )
    except Exception: pass
    try:
        if data is not None and hasattr (data ,'materials'):
            def _body (body):
                _ms_safe_template_list (body ,'MATERIAL_UL_matslots',obj ,'material_slots',obj ,'active_material_index',rows =3 )
            _ms_draw_child_section (layout ,context ,_ms_child_section_key ('data_list',getattr (obj ,'type',''),'materials'),pgettext ('Material Slots'),icon ='MATERIAL_DATA',default_open =False,draw_body =_body )
    except Exception: pass



_MS_DATA_TAB_MODULES_BY_OBJECT_TYPE ={
    'MESH':'bl_ui.properties_data_mesh',
    'CURVE':'bl_ui.properties_data_curve',
    'SURFACE':'bl_ui.properties_data_curve',
    'FONT':'bl_ui.properties_data_curve',
    'META':'bl_ui.properties_data_metaball',
    'CURVES':'bl_ui.properties_data_curves',
    'POINTCLOUD':'bl_ui.properties_data_pointcloud',
    'VOLUME':'bl_ui.properties_data_volume',
    'GREASEPENCIL':'bl_ui.properties_data_grease_pencil',
    'GPENCIL':'bl_ui.properties_data_grease_pencil',
    'ARMATURE':'bl_ui.properties_data_armature',
    'LATTICE':'bl_ui.properties_data_lattice',
    'EMPTY':'bl_ui.properties_data_empty',
    'IMAGE':'bl_ui.properties_data_empty',
    'CAMERA':'bl_ui.properties_data_camera',
    'LIGHT':'bl_ui.properties_data_light',
    'LIGHT_PROBE':'bl_ui.properties_data_lightprobe',
    'LIGHTPROBE':'bl_ui.properties_data_lightprobe',
    'SPEAKER':'bl_ui.properties_data_speaker',
}
_MS_DATA_TAB_PANEL_CACHE ={}


class _MSDataTabContext:
    """Small proxy used to draw Blender's native Object Data panels in the N-panel.

    Blender's Properties editor context exposes shortcuts such as context.mesh,
    context.curve, context.camera, etc.  View3D sidebar contexts usually do not.
    Native bl_ui data panels rely on those shortcuts, so this proxy supplies them
    while delegating every other attribute to the original context.
    """
    def __init__ (self ,context ,obj ):
        self._context =context
        self.object =obj
        self.active_object =obj
        self.edit_object =getattr (context ,'edit_object',None )if context is not None else None
        self.scene =getattr (context ,'scene',None )if context is not None else getattr (bpy ,'context',None ).scene if getattr (bpy ,'context',None )else None
        self.view_layer =getattr (context ,'view_layer',None )if context is not None else getattr (getattr (bpy ,'context',None ),'view_layer',None )
        self.window_manager =getattr (context ,'window_manager',None )if context is not None else getattr (getattr (bpy ,'context',None ),'window_manager',None )
        self.tool_settings =getattr (context ,'tool_settings',None )if context is not None else getattr (getattr (bpy ,'context',None ),'tool_settings',None )
        self.preferences =getattr (context ,'preferences',None )if context is not None else getattr (getattr (bpy ,'context',None ),'preferences',None )
        self.space_data =getattr (context ,'space_data',None )if context is not None else None
        self.region =getattr (context ,'region',None )if context is not None else None
        self.area =getattr (context ,'area',None )if context is not None else None
        try :self.mode =str (getattr (context ,'mode','OBJECT')or 'OBJECT')
        except Exception :self.mode ='OBJECT'
        try :self.engine =str (getattr (context ,'engine','')or getattr (self.scene .render ,'engine','')or 'BLENDER_EEVEE')
        except Exception :self.engine ='BLENDER_EEVEE'
        data =getattr (obj ,'data',None )if obj is not None else None
        typ =str (getattr (obj ,'type','')or '')if obj is not None else ''
        self.data =data
        self.mesh =data if typ =='MESH'else None
        self.curve =data if typ in {'CURVE','SURFACE','FONT'}else None
        self.meta_ball =data if typ =='META'else None
        self.curves =data if typ =='CURVES'else None
        self.pointcloud =data if typ =='POINTCLOUD'else None
        self.volume =data if typ =='VOLUME'else None
        self.grease_pencil =data if typ in {'GREASEPENCIL','GPENCIL'}else None
        self.armature =data if typ =='ARMATURE'else None
        self.lattice =data if typ =='LATTICE'else None
        self.camera =data if typ =='CAMERA'else None
        self.light =data if typ =='LIGHT'else None
        self.lightprobe =data if typ in {'LIGHT_PROBE','LIGHTPROBE'}else None
        self.light_probe =self.lightprobe
        self.speaker =data if typ =='SPEAKER'else None
        try :self.active_pose_bone =getattr (context ,'active_pose_bone',None )
        except Exception :self.active_pose_bone =None
        try :self.active_bone =getattr (context ,'active_bone',None )
        except Exception :self.active_bone =None

    def __getattr__ (self ,name ):
        ctx =object .__getattribute__ (self ,'_context')
        if ctx is not None:
            try :return getattr (ctx ,name )
            except Exception :pass
        raise AttributeError (name)


def _ms_data_tab_module_name_for_object (obj ):
    typ =str (getattr (obj ,'type','')or '')
    if typ =='EMPTY':
        try:
            if getattr (obj ,'empty_display_type','')=='IMAGE':
                return 'bl_ui.properties_data_empty'
        except Exception: pass
        return 'bl_ui.properties_data_empty'
    return _MS_DATA_TAB_MODULES_BY_OBJECT_TYPE .get (typ ,'')


def _ms_data_tab_panel_classes (module_name ):
    if not module_name:
        return ()
    cached =_MS_DATA_TAB_PANEL_CACHE .get (module_name )
    if cached is not None:
        return cached
    panels =[]
    try:
        module =importlib .import_module (module_name )
        for _name ,cls in list (getattr (module ,'__dict__',{}) .items ()):
            try:
                if not isinstance (cls ,type )or not issubclass (cls ,bpy .types .Panel ):
                    continue
                if cls is bpy .types .Panel:
                    continue
                if str (getattr (cls ,'__module__','')or '')!=module_name:
                    continue
                if not callable (getattr (cls ,'draw',None )):
                    continue
                # Only Object Data tab panels.  Preset popovers and unrelated
                # panels are intentionally skipped here.
                bl_context =str (getattr (cls ,'bl_context','')or '')
                if bl_context and bl_context !='data':
                    continue
                if not bl_context:
                    # Abstract helper classes and preset panels do not carry the
                    # data-tab context and are not part of the ordinary data body.
                    continue
                panels .append (cls )
            except Exception:
                continue
    except Exception:
        panels =[]
    _MS_DATA_TAB_PANEL_CACHE [module_name]=tuple (panels )
    return _MS_DATA_TAB_PANEL_CACHE [module_name]


def _ms_native_panel_poll (panel_cls ,proxy_context ):
    try:
        poll =getattr (panel_cls ,'poll',None )
        if callable (poll ):
            return bool (poll (proxy_context ))
    except Exception:
        return False
    return True


class _MSNativePanelShim:
    def __init__(self, panel_cls, layout):
        self._panel_cls = panel_cls
        self.layout = layout
        self.is_popover = False

    def __getattr__(self, name):
        for base in self._panel_cls.__mro__:
            if name in vars(base):
                value = vars(base)[name]
                descriptor = getattr(value, '__get__', None)
                return descriptor(self, self._panel_cls) if descriptor else value
        raise AttributeError(name)


def _ms_draw_native_data_tab_panel (layout ,panel_cls ,proxy_context ):
    try:
        label =str (getattr (panel_cls ,'bl_label','')or '')
        hide_header =False
        try: hide_header ='HIDE_HEADER'in set (getattr (panel_cls ,'bl_options',set ())or set ())
        except Exception: hide_header =False
        obj =getattr (proxy_context ,'object',None )
        if not label:
            label =choose_text ('Object Data','オブジェクトデータ',context =proxy_context )
        default_open =bool (_ms_panel_default_open (panel_cls ))
        # Context panels are tiny ID rows in the Properties editor; keep them open
        # but still give them a collapsible child group in the N-panel.
        if hide_header:
            default_open =True
        def _body (target_layout):
            try:
                target_layout .use_property_split =False
                target_layout .use_property_decorate =True
            except Exception:
                pass
            shim =_MSNativePanelShim (panel_cls ,target_layout)
            panel_cls .draw (shim ,proxy_context )
        return _ms_draw_child_section (
            layout ,proxy_context ,
            _ms_child_section_key ('native_data',getattr (obj ,'type',''),getattr (panel_cls ,'__name__','')),
            label ,icon =_ms_base_icon_for_object (obj ),default_open =default_open ,draw_body =_body,
        )
    except Exception:
        return False


def _ms_draw_native_object_data_tab (layout ,context ,obj ):
    """Draw Blender's own Object Data panels as closely as possible.

    This function is deliberately conservative: every native panel is isolated in
    its own guarded box, and if no native panel can be drawn the caller falls back
    to the generic RNA drawer.  This prevents the Base Object properties area from
    becoming empty when a panel refuses the View3D sidebar context.
    """
    if layout is None or not _ms_object_is_live (obj ):
        return False
    module_name =_ms_data_tab_module_name_for_object (obj )
    panels =_ms_data_tab_panel_classes (module_name )
    if not panels:
        return False
    proxy =_MSDataTabContext (context ,obj )
    drawn =False
    for panel_cls in panels:
        if not _ms_native_panel_poll (panel_cls ,proxy ):
            continue
        if _ms_draw_native_data_tab_panel (layout ,panel_cls ,proxy ):
            drawn =True
    return drawn

def _ms_draw_object_fallback_data (layout ,context ,obj ):
    drawn =False
    try:
        fields =(
            'empty_display_type','empty_display_size','empty_image_offset','empty_image_depth','empty_image_side',
            'show_empty_image_perspective','show_empty_image_orthographic','use_empty_image_alpha','empty_image_visibility_mode',
            'instance_type','instance_collection','instance_faces_scale','use_instance_faces_scale','show_name','show_axis','color',
        )
        def _body (body):
            nonlocal drawn
            col =body .column (align =True); col .use_property_split =True; col .use_property_decorate =True
            for pid in fields:
                if hasattr (obj ,pid) and _ms_safe_prop (col ,obj ,pid )is not None:
                    drawn =True
        _ms_draw_child_section (layout ,context ,_ms_child_section_key ('object_fallback',getattr (obj ,'type',''),'object_data'),pgettext ('Object Data'),icon =_ms_base_icon_for_object (obj ),default_open =True,draw_body =_body )
        drawn =True
    except Exception:
        pass
    try:
        field =getattr (obj ,'field',None )
        if _ms_rna_is_valid (field):
            drawn =_ms_draw_rna_owner_properties (layout ,field ,title =pgettext ('Force Field'),icon ='FORCE_FORCE')or drawn
    except Exception:
        pass
    return drawn


def draw_base_object_data_properties (layout ,context ,obj ):
    """Draw Base Object data using Blender's Object Data tab panels first.

    When the virtual Base Object row is active, the property body should not be a
    mesh-only placeholder.  It mirrors Blender's standard Properties > Data tab
    by reusing the relevant bl_ui.properties_data_* panel module for the active
    object type.  If a native panel refuses to draw in the View3D sidebar, a
    complete guarded RNA fallback is drawn instead so the area is never blank.
    """
    if layout is None or not _ms_object_is_live (obj ):
        return
    try:
        layout .use_property_split =False
        layout .use_property_decorate =False
    except Exception:
        pass

    drawn_native =False
    try:
        drawn_native =_ms_draw_native_object_data_tab (layout ,context ,obj )
    except Exception:
        drawn_native =False

    data =getattr (obj ,'data',None )
    drawn_fallback =False
    # If Blender's native data panels draw successfully, they are the canonical
    # layout and must not be duplicated.  The guarded RNA/list fallback is used
    # only when those native panels cannot be drawn in the View3D sidebar.
    try:
        if _ms_rna_is_valid (data ) and not drawn_native:
            drawn_fallback =_ms_draw_rna_owner_properties (layout ,data ,title =pgettext ('Data Properties'),icon =_ms_base_icon_for_object (obj ))or drawn_fallback
            _ms_draw_common_object_data_lists (layout ,context ,obj ,data )
            drawn_fallback =True
    except Exception:
        pass
    try:
        if data is None or getattr (obj ,'type','')=='EMPTY' or getattr (obj ,'instance_collection',None )is not None or getattr (obj ,'field',None )is not None:
            drawn_fallback =_ms_draw_object_fallback_data (layout ,context ,obj )or drawn_fallback
    except Exception:
        pass
    if not drawn_native and not drawn_fallback:
        # Last-resort body: object identity and user-facing object properties.
        try:
            box =layout .box ()
            box .label (text =pgettext ('Object Data'),icon =_ms_base_icon_for_object (obj ))
            col =box .column (align =True )
            col .use_property_split =True
            col .use_property_decorate =True
            for pid in ('name','type','data','instance_type','instance_collection','empty_display_type','empty_display_size','color'):
                _ms_safe_prop (col ,obj ,pid )
        except Exception:
            try: layout .label (text =choose_text ('No editable properties.','編集できるプロパティはありません。',context =context ),icon='NONE')
            except Exception: pass

def draw_modifier_properties (layout ,context ,obj ,mod ,minimal =False ):
    if layout is None or not _ms_modifier_is_live_on_object (obj ,mod ):
        return
    supports_vg =_ms_modifier_supports_vertex_group (mod )
    if supports_vg :
        icon_box =layout .box ()
        # Ensure the influence-range utility row is not affected by property-split layouts.
        try :
            icon_box .use_property_split =False 
            icon_box .use_property_decorate =False 
        except Exception :
            pass 
        row =icon_box .row (align =True )
        try :
            row .alignment ='EXPAND'
        except Exception :
            pass
        try :
            opu =_sms_icon_operator (row ,"object.ms_update_influence_range",text =pgettext ('Update Influence Range'),icon_name ='refresh',fallback_icon ='FILE_REFRESH')
            opu .modifier_name =mod .name 
            opu .target_obj_name =obj .name 
        except Exception :
            pass

    # For suppressed/custom modifiers (e.g. EditPoly), we may want to show only the standard visibility toggles.
    if minimal :
        return 

    col =layout .column (align =True )
    col .use_property_split =True 
    col .use_property_decorate =True 

    try :
        _plugin_handled =False
        _can_use_generic_plugin_draw =getattr (mod ,"type","")== 'NODES'
        for _p in (ms_get_plugins_sorted () if _can_use_generic_plugin_draw else ()): 
            _mfn =_p .get ("match_modifier")
            if not callable (_mfn ):
                continue
            try :
                if not _mfn (mod ):
                    continue
            except Exception :
                continue
            _fn =_p .get ("draw_modifier_properties_extra")
            if not callable (_fn ):
                continue
            try :
                _res =_fn (col ,mod ,obj ,context )
            except TypeError :
                try :
                    _res =_fn (col ,mod ,obj )
                except TypeError :
                    _res =_fn (col ,mod )
            except Exception :
                _res =False
            if bool (_res ):
                _plugin_handled =True
        if _plugin_handled :
            return
    except Exception :
        pass

    try :
        # Blender's native Properties editor draws modifier bodies through
        # UILayout.template_modifiers(), which is an all-stack C-side template and
        # does not expose a Python API for drawing exactly one modifier body in an
        # N-panel.  To keep Smart Modifier stack properties complete and editable,
        # draw every writable RNA property exposed by the active modifier with
        # Blender's own property widgets and labels.  This includes properties that
        # earlier hand-written subsets missed, such as Subdivision Surface
        # show_only_control_edges / use_limit_surface and advanced/adaptive options.
        if getattr (mod ,'type','')=='LATTICE':
            _draw_lattice (col ,mod ,obj ,context )
        elif not _draw_standard_modifier_properties (col ,obj ,mod ,context ):
            _draw_auto (col ,mod )
    except Exception :
        _draw_auto (col ,mod )


_MS_MODIFIER_HEADER_PROP_IDS = {
    'rna_type',
    'name',
    'type',
    'show_viewport',
    'show_render',
    'show_in_editmode',
    'show_on_cage',
    'show_expanded',
    'is_active',
    'use_pin_to_last',
    'is_override_data',
    'execution_time',
    'persistent_uid',
}

_MS_MODIFIER_INTERNAL_PANEL_PROP_PREFIXES = (
    'open_',
)

_MS_MODIFIER_VECTOR_AXIS_LABELS = ('X', 'Y', 'Z', 'W')


_MS_MODIFIER_REF_PROP_KEYWORDS = (
    'object','target','source','camera','texture','material','collection','node_group','curve','lattice','armature','mesh','uv_layer','data_block'
)
_MS_MODIFIER_INFLUENCE_PROP_KEYWORDS = (
    'vertex_group','weight','factor','strength','influence','invert_vertex_group'
)
_MS_MODIFIER_ADVANCED_PROP_KEYWORDS = (
    'quality','limit','threshold','smooth','boundary','crease','normal','offset','merge','bisect','profile','random','seed','use_','show_','display','mode'
)


def _ms_modifier_property_group_key (prop_id ,prop_type ,mod_type ):
    pid =str (prop_id or '').lower ()
    ptype =str (prop_type or '').upper ()
    if ptype =='POINTER' or any (key in pid for key in _MS_MODIFIER_REF_PROP_KEYWORDS ):
        return 'references'
    if any (key in pid for key in _MS_MODIFIER_INFLUENCE_PROP_KEYWORDS ):
        return 'influence'
    if any (key in pid for key in _MS_MODIFIER_ADVANCED_PROP_KEYWORDS ):
        return 'advanced'
    return 'main'


def _ms_modifier_group_label (group_key ):
    return {
        'main':pgettext ('Modifier Properties'),
        'references':pgettext ('References'),
        'influence':pgettext ('Influence'),
        'advanced':pgettext ('Advanced'),
        'idprops':pgettext ('Node Inputs / Custom Properties'),
    }.get (str (group_key or ''),pgettext ('Modifier Properties'))


def _ms_modifier_group_icon (group_key ):
    return {
        'main':'MODIFIER',
        'references':'LINKED',
        'influence':'MOD_VERTEX_WEIGHT',
        'advanced':'PREFERENCES',
        'idprops':'GEOMETRY_NODES',
    }.get (str (group_key or ''),'MODIFIER')


_MS_MODIFIER_INTERNAL_IDPROP_KEYS = {
    'ms_instance_id',
    'smsm_instance_id',
    'ms_instance_master',
    'smsm_plugin_id',
    'smsm_max_modifier_key',
    'smsm_unique_id',
    'smsm_internal_user_tool_defaults',
    'smsm_internal_user_tool_id',
    'smsm_internal_user_tool_operator_id',
    'jel_max_generator_id',
    'jel_max_generator_name',
    'jel_max_generator_category',
    'jel_max_socket_map',
    'smsm_slice_modifier',
    'smsm_slice_gizmo_name',
    'smsm_slice_plane_socket',
    'smsm_slice_remove_bottom_socket',
    'smsm_slice_cutter_size_socket',
    'smsm_slice_node_group',
    'smsm_slice_cutter_size',
}

_MS_MODIFIER_INTERNAL_IDPROP_PREFIXES = (
    'ms_internal_',
    'smsm_internal_',
    'jel_internal_',
)

_MS_MODIFIER_INTERNAL_IDPROP_SUFFIXES = (
    '_attribute_name',
    '_use_attribute',
)

_MS_GEOMETRY_SOCKET_LABELS = {'Geometry', 'ジオメトリ'}


def _ms_is_japanese_ui (context =None ):
    try:
        return choose_text ('en','ja',context =context )=='ja'
    except Exception:
        return False


def _ms_json_dict (value ):
    if isinstance (value ,dict ):
        return dict (value )
    try:
        if isinstance (value ,str )and value .strip ():
            data =json .loads (value )
            return data if isinstance (data ,dict )else {}
    except Exception:
        pass
    return {}


def _ms_find_loaded_module (suffix ):
    try:
        for name ,module in tuple (sys .modules .items ()):
            if str (name ).endswith (suffix )and module is not None:
                return module
    except Exception:
        pass
    return None


def _ms_import_optional_module (*names ):
    for name in names:
        try:
            return importlib .import_module (name )
        except Exception:
            continue
    return None


def _ms_max_primitive_specs_module ():
    module =_ms_find_loaded_module ('.max_procedural_primitives.specs')
    if module is not None:
        return module
    return _ms_import_optional_module (
        'smart_modeling_suite.max_procedural_primitives.specs',
        'bl_ext.user_default.smart_modeling_suite.max_procedural_primitives.specs',
        'bl_ext.blender_org.smart_modeling_suite.max_procedural_primitives.specs',
    )


def _ms_modifier_generator_id (obj ,mod ):
    for data in (mod ,obj ):
        try:
            value =data .get ('jel_max_generator_id')
            if value:
                return str (value )
        except Exception:
            pass
    try:
        tree =getattr (mod ,'node_group',None )
        value =tree .get ('jel_max_generator_id') if tree is not None else ''
        if value:
            return str (value )
    except Exception:
        pass
    return ''


def _ms_modifier_socket_map (obj ,mod ):
    for data ,key in ((obj ,'jel_max_socket_map'),):
        try:
            found =_ms_json_dict (data .get (key ))
            if found:
                return {str (k):str (v) for k ,v in found .items ()}
        except Exception:
            pass
    try:
        tree =getattr (mod ,'node_group',None )
        found =_ms_json_dict (tree .get ('jel_socket_map')) if tree is not None else {}
        if found:
            return {str (k):str (v) for k ,v in found .items ()}
    except Exception:
        pass
    return {}


def _ms_iter_node_interface_sockets (tree ):
    if tree is None:
        return
    try:
        items_tree =getattr (getattr (tree ,'interface',None ),'items_tree',None )
        if items_tree is not None:
            for item in items_tree:
                try:
                    if getattr (item ,'item_type',None )=='SOCKET':
                        yield item
                except Exception:
                    continue
            return
    except Exception:
        pass
    try:
        items =getattr (getattr (tree ,'interface',None ),'items',None )
        if callable (items ):
            for item in items ():
                try:
                    if getattr (item ,'item_type',None )=='SOCKET':
                        yield item
                except Exception:
                    continue
    except Exception:
        return


def _ms_node_socket_is_input (sock ):
    try:
        in_out =str (getattr (sock ,'in_out','')or '')
        return not in_out or in_out =='INPUT'
    except Exception:
        return True


def _ms_label_from_socket_name (name ,fallback ):
    text =str (name or '').strip ()
    if not text or text in _MS_GEOMETRY_SOCKET_LABELS:
        return pgettext (str (fallback or ''))
    return pgettext (text )


def _ms_build_node_socket_metadata (obj ,mod ,context =None ):
    meta ={}
    try:
        tree =getattr (mod ,'node_group',None )
    except Exception:
        tree =None
    order =0
    for sock in _ms_iter_node_interface_sockets (tree ):
        if not _ms_node_socket_is_input (sock ):
            continue
        try:
            identifier =str (getattr (sock ,'identifier','')or '')
        except Exception:
            identifier =''
        if not identifier:
            continue
        try:
            name =str (getattr (sock ,'name','')or '')
        except Exception:
            name =''
        if name in _MS_GEOMETRY_SOCKET_LABELS or identifier.lower ()=='geometry':
            continue
        try:
            description =str (getattr (sock ,'description','')or '')
        except Exception:
            description =''
        meta [identifier ]={
            'label':_ms_label_from_socket_name (name ,identifier ),
            'description':pgettext (description ) if description else '',
            'order':order,
            'is_socket':True,
        }
        order +=1
    return meta


def _ms_build_max_primitive_metadata (obj ,mod ,context =None ):
    generator_id =_ms_modifier_generator_id (obj ,mod )
    if not generator_id:
        return {}
    socket_map =_ms_modifier_socket_map (obj ,mod )
    if not socket_map:
        return {}
    specs_module =_ms_max_primitive_specs_module ()
    specs =getattr (specs_module ,'GENERATOR_SPECS',{}) if specs_module is not None else {}
    spec =specs .get (generator_id ) if isinstance (specs ,dict )else None
    if not isinstance (spec ,dict ):
        return {}
    ja =_ms_is_japanese_ui (context )
    meta ={}
    for order ,param in enumerate (spec .get ('params',[])or []):
        try:
            param_id =str ((param or {}).get ('id')or '')
            identifier =socket_map .get (param_id )
        except Exception:
            continue
        if not identifier:
            continue
        if ja:
            label =str ((param or {}).get ('ja')or (param or {}).get ('en')or identifier )
            desc =str ((param or {}).get ('desc_ja')or (param or {}).get ('desc_en')or label )
        else:
            label =str ((param or {}).get ('en')or (param or {}).get ('ja')or identifier )
            desc =str ((param or {}).get ('desc_en')or (param or {}).get ('desc_ja')or label )
        meta [str (identifier )]={
            'label':label,
            'description':desc,
            'order':order,
            'is_socket':True,
            'is_max_primitive':True,
        }
    return meta


def _ms_humanize_id_property_key (key ):
    text =str (key or '').strip ()
    if not text:
        return ''
    if text.startswith ('Socket_'):
        return text .replace ('_',' ')
    parts =text .replace ('-','_').split ('_')
    return pgettext (' '.join (part [:1].upper ()+part [1:] for part in parts if part ))


def _ms_build_modifier_id_property_metadata (obj ,mod ,context =None ):
    meta =_ms_build_node_socket_metadata (obj ,mod ,context )
    try:
        # Max Primitives keeps the authoritative bilingual parameter labels in
        # Smart Modeling Suite.  Prefer them when available so language changes
        # update the Smart Modifier property body even if the Geometry Nodes
        # group was originally created in another UI language.
        meta .update (_ms_build_max_primitive_metadata (obj ,mod ,context ))
    except Exception:
        pass
    return meta


def _ms_id_property_is_hidden (key ,metadata =None ):
    skey =str (key or '')
    if not skey or skey .startswith ('_'):
        return True
    if skey in _MS_MODIFIER_INTERNAL_IDPROP_KEYS:
        return True
    if skey .startswith (_MS_MODIFIER_INTERNAL_IDPROP_PREFIXES):
        return True
    if skey .endswith (_MS_MODIFIER_INTERNAL_IDPROP_SUFFIXES):
        return True
    if metadata is not None:
        try:
            data =metadata .get (skey )or {}
            if bool (data .get ('hidden',False )):
                return True
        except Exception:
            pass
    return False


def _ms_id_property_is_drawable_value (value ):
    if isinstance (value ,(bool ,int ,float ,str)):
        return True
    if value is None or isinstance (value ,(dict ,set )):
        return False
    if isinstance (value ,(list ,tuple )):
        return True
    try:
        cls_name =str (getattr (getattr (value ,'__class__',None ),'__name__','')or '')
        if cls_name in {'IDPropertyArray','bpy_prop_array'}:
            return True
    except Exception:
        pass
    try:
        if hasattr (value ,'bl_rna'):
            return _ms_rna_is_valid (value )
    except Exception:
        pass
    return False


def _ms_collect_modifier_id_properties (mod ,obj =None ,context =None ):
    metadata =_ms_build_modifier_id_property_metadata (obj ,mod ,context )
    items =[]
    try:
        for key in list (mod .keys ()):  # Geometry Nodes inputs and Smart Modifier custom state.
            skey =str (key or '')
            if _ms_id_property_is_hidden (skey ,metadata ):
                continue
            value =mod .get (skey )
            if not _ms_id_property_is_drawable_value (value ):
                continue
            # Raw Geometry Nodes socket identifiers are only user-facing when
            # we can resolve them back to a socket/interface label.  This keeps
            # Socket_2 / Socket_2_attribute_name style internal names out of the
            # N-panel while still exposing ordinary custom properties.
            if skey .startswith ('Socket_') and skey not in metadata:
                continue
            items .append (skey )
    except Exception:
        pass
    def _sort_key (key ):
        data =metadata .get (key )or {}
        order =data .get ('order',999999 )
        try:
            order =int (order )
        except Exception:
            order =999999
        return (0 if data .get ('is_socket')else 1,order,str (key ))
    try:
        items .sort (key =_sort_key )
    except Exception:
        pass
    return items ,metadata


def _ms_draw_modifier_id_property (layout ,mod ,key ,metadata =None ):
    skey =str (key or '')
    data =(metadata or {}).get (skey )or {}
    label =str (data .get ('label')or _ms_humanize_id_property_key (skey )or skey )
    try:
        layout .prop (mod ,'["%s"]'%skey .replace ('"','\\"') ,text =label )
        return True
    except Exception:
        try:
            row =layout .row (align =True)
            row .label (text =label )
            row .label (text =str (mod .get (skey )))
            return True
        except Exception:
            return False


def _ms_modifier_prop_is_user_facing (prop )->bool :
    try :
        identifier =str (getattr (prop ,'identifier','')or '')
        if not identifier or identifier in _MS_MODIFIER_HEADER_PROP_IDS :
            return False
        if any (identifier .startswith (prefix )for prefix in _MS_MODIFIER_INTERNAL_PANEL_PROP_PREFIXES ):
            # Native template panel open/close state.  It is not a modifier setting.
            return False
        if bool (getattr (prop ,'is_hidden',False )):
            return False
        if bool (getattr (prop ,'is_readonly',False )):
            # Some readonly data-block pointers are still represented by native
            # templates.  Keep explicit exceptions below.
            return identifier in {'custom_profile'}
    except Exception :
        return False
    return True


def _ms_property_display_name (prop ,fallback =''):
    try :
        name =str (getattr (prop ,'name','')or '')
        if name :
            return pgettext (name )
    except Exception :
        pass
    return pgettext (str (fallback or ''))


def _ms_safe_template_curveprofile (layout ,data ,prop_name ):
    try :
        fn =getattr (layout ,'template_curveprofile',None )
        if callable (fn ):
            fn (data ,prop_name )
            return True
    except Exception :
        pass
    return False


def _ms_draw_vertex_group_search (layout ,obj ,mod ,prop_id ,prop_name ):
    try :
        if obj is not None and hasattr (obj ,'vertex_groups'):
            layout .prop_search (mod ,prop_id ,obj ,'vertex_groups',text =prop_name )
            return True
    except Exception :
        pass
    return False


def _ms_draw_modifier_property (layout ,obj ,mod ,prop ):
    try :
        prop_id =str (getattr (prop ,'identifier','')or '')
        if not prop_id or not hasattr (mod ,prop_id ):
            return False
        prop_type =str (getattr (prop ,'type','')or '')
        prop_name =_ms_property_display_name (prop ,prop_id )
        array_len =int (getattr (prop ,'array_length',0 )or 0 )

        if prop_id =='custom_profile':
            box =layout .box ()
            try :
                box .label (text =prop_name ,icon ='IPO_BEZIER')
            except Exception :
                pass
            return _ms_safe_template_curveprofile (box ,mod ,prop_id )

        # Vertex group string fields should behave like Blender's modifier panel:
        # search the active object's vertex_groups instead of requiring users to
        # type exact names manually.
        if prop_type =='STRING' and 'vertex_group' in prop_id:
            if _ms_draw_vertex_group_search (layout ,obj ,mod ,prop_id ,prop_name ):
                return True

        # Boolean vector properties such as Mirror Axis / Bisect Axis are clearer
        # as compact toggle rows and match Blender's axis-button convention.
        if prop_type =='BOOLEAN' and array_len and array_len <=4:
            split =layout .split (factor =0.42 ,align =True )
            split .label (text =prop_name )
            row =split .row (align =True )
            for index in range (array_len ):
                label =_MS_MODIFIER_VECTOR_AXIS_LABELS [index ]if index <len (_MS_MODIFIER_VECTOR_AXIS_LABELS )else str (index +1 )
                _ms_safe_prop (row ,mod ,prop_id ,index =index ,text =pgettext (label ),toggle =True )
            return True

        _ms_safe_prop (layout ,mod ,prop_id )
        return True
    except Exception :
        return False


def _draw_standard_modifier_properties (col ,obj ,mod ,context =None ):
    """Draw a complete RNA-based modifier body split into child foldouts."""
    if not _ms_rna_is_valid (mod ):
        return False
    try :
        col .use_property_split =False
        col .use_property_decorate =False
    except Exception :
        pass

    try :
        properties =list (getattr (getattr (mod ,'bl_rna',None ),'properties',[])or [])
    except Exception :
        properties =[]
    groups ={'main':[],'references':[],'influence':[],'advanced':[]}
    mod_type =str (getattr (mod ,'type','')or '')
    for prop in properties :
        if not _ms_modifier_prop_is_user_facing (prop ):
            continue
        try :
            prop_id =str (getattr (prop ,'identifier','')or '')
            prop_type =str (getattr (prop ,'type','')or '')
            group_key =_ms_modifier_property_group_key (prop_id ,prop_type ,mod_type )
            groups .setdefault (group_key ,[]) .append (prop )
        except Exception :
            groups ['main'].append (prop )

    idprops ,idprop_meta =_ms_collect_modifier_id_properties (mod ,obj ,context )
    drawn =False
    for group_key ,default_open in (('main',True),('references',False),('influence',False),('advanced',False)):
        props =groups .get (group_key )or []
        if not props:
            continue
        def _body (body ,_props =tuple (props)):
            try:
                body .use_property_split =True
                body .use_property_decorate =True
            except Exception:
                pass
            for _prop in _props:
                try:
                    _ms_draw_modifier_property (body ,obj ,mod ,_prop )
                except Exception:
                    continue
        _ms_draw_child_section (
            col ,context or getattr (bpy ,'context',None ),
            _ms_child_section_key ('modifier',mod_type,group_key),
            _ms_modifier_group_label (group_key),
            icon =_ms_modifier_group_icon (group_key),default_open =default_open,draw_body =_body,
        )
        drawn =True
    if idprops:
        def _body (body ,_keys =tuple (idprops)):
            try:
                body .use_property_split =True
                body .use_property_decorate =True
            except Exception:
                pass
            for _key in _keys:
                _ms_draw_modifier_id_property (body ,mod ,_key ,idprop_meta )
        _ms_draw_child_section (
            col ,context or getattr (bpy ,'context',None ),
            _ms_child_section_key ('modifier',mod_type,'idprops'),
            _ms_modifier_group_label ('idprops'),
            icon =_ms_modifier_group_icon ('idprops'),default_open =False,draw_body =_body,
        )
        drawn =True
    return drawn

def _draw_lattice (col ,mod ,obj =None ,context =None ):
    try :
        mo =None 
        try :
            o =getattr (mod ,"object",None )
            if o :mo =get_main_object (o )
        except Exception :mo =None 
        for p in ms_get_plugins_sorted ():
            fn =p .get ("draw_modifier_properties_extra")
            if callable (fn ):
                try :fn (col ,mod ,mo )
                except Exception :pass 
    except Exception :pass 
    if not _draw_standard_modifier_properties (col ,obj ,mod ,context ):
        safe_prop (col ,mod ,"object")
        safe_prop (col ,mod ,"vertex_group")
        if getattr (mod ,"vertex_group",None ):safe_prop (col ,mod ,"invert_vertex_group")
        safe_prop (col ,mod ,"strength")

def _draw_mirror (col ,mod ):
    col .use_property_split =False 
    split =col .split (factor =0.4 ,align =True );split .label (text =pgettext ('Axis'))
    row =split .row (align =True )
    safe_prop (row ,mod ,"use_axis",index =0 ,text =pgettext ("X"),toggle =True )
    safe_prop (row ,mod ,"use_axis",index =1 ,text =pgettext ("Y"),toggle =True )
    safe_prop (row ,mod ,"use_axis",index =2 ,text =pgettext ("Z"),toggle =True )

    split =col .split (factor =0.4 ,align =True );split .label (text =pgettext ('Bisect'))
    row =split .row (align =True )
    safe_prop (row ,mod ,"use_bisect_axis",index =0 ,text =pgettext ("X"),toggle =True )
    safe_prop (row ,mod ,"use_bisect_axis",index =1 ,text =pgettext ("Y"),toggle =True )
    safe_prop (row ,mod ,"use_bisect_axis",index =2 ,text =pgettext ("Z"),toggle =True )

    split =col .split (factor =0.4 ,align =True );split .label (text =pgettext ('Reverse'))
    row =split .row (align =True )
    safe_prop (row ,mod ,"use_bisect_flip_axis",index =0 ,text =pgettext ("X"),toggle =True )
    safe_prop (row ,mod ,"use_bisect_flip_axis",index =1 ,text =pgettext ("Y"),toggle =True )
    safe_prop (row ,mod ,"use_bisect_flip_axis",index =2 ,text =pgettext ("Z"),toggle =True )

    col .use_property_split =True 
    safe_prop (col ,mod ,"mirror_object",text =pgettext ('Mirror Object'))
    safe_prop (col ,mod ,"use_clip",text =pgettext ('Clipping'))

    col .use_property_split =False 
    split =col .split (factor =0.4 ,align =True );row_label =split .row (align =True )
    safe_prop (row_label ,mod ,"use_mirror_merge",text =pgettext ('Merge'))
    if getattr (mod ,"use_mirror_merge",False ):
        safe_prop (split ,mod ,"merge_threshold",text ="")
    else :
        split .label (text ="")
    col .use_property_split =True 

    safe_prop (col ,mod ,"bisect_threshold",text =pgettext ('Distance to Bisect Plane'))

    data_box =col .box ();data_box .label (text =pgettext ('Data'))
    dcol =data_box .column (align =True );dcol .use_property_split =False 
    split =dcol .split (factor =0.4 ,align =True );row_label =split .row (align =True )
    safe_prop (row_label ,mod ,"use_mirror_u",text =pgettext ('Mirror U'))
    safe_prop (row_label ,mod ,"use_mirror_v",text =pgettext ("V"))
    split .label (text ="")
    dcol .use_property_split =True 
    safe_prop (dcol ,mod ,"mirror_offset_u",text =pgettext ('Offset U'))
    safe_prop (dcol ,mod ,"mirror_offset_v",text =pgettext ("V"))
    safe_prop (dcol ,mod ,"use_mirror_vertex_groups",text =pgettext ('Vertex Group'))
    safe_prop (dcol ,mod ,"use_mirror_udim",text =pgettext ('Flip UDIM'))

def _draw_subsurf (col ,mod ):
    safe_prop (col ,mod ,"subdivision_type",text =pgettext ('Subdivision Type'))
    safe_prop (col ,mod ,"levels",text =pgettext ('Viewport Level'))
    safe_prop (col ,mod ,"render_levels",text =pgettext ('Render Level'))
    safe_prop (col ,mod ,"use_limit_surface",text =pgettext ('Optimized Display'))
    safe_prop (col ,mod ,"quality",text =pgettext ('Quality'))
    safe_prop (col ,mod ,"uv_smooth",text =pgettext ('UV Smooth'))
    safe_prop (col ,mod ,"boundary_smooth",text =pgettext ('Boundary Smooth'))
    safe_prop (col ,mod ,"use_creases",text =pgettext ('Use Creases'))
    safe_prop (col ,mod ,"use_custom_normals",text =pgettext ('Custom Normals'))

def _draw_solidify (col ,mod ):
    safe_prop (col ,mod ,"thickness",text =pgettext ('Thickness'))
    safe_prop (col ,mod ,"offset",text =pgettext ('Offset'))
    safe_prop (col ,mod ,"use_even_offset",text =pgettext ('Even Thickness'))
    safe_prop (col ,mod ,"use_quality_normals",text =pgettext ('High Quality Normals'))
    safe_prop (col ,mod ,"use_flip_normals",text =pgettext ('Flip Normals'))
    safe_prop (col ,mod ,"solidify_mode",text =pgettext ('Mode'))
    safe_prop (col ,mod ,"vertex_group",text =pgettext ('Vertex Group'))
    if getattr (mod ,"vertex_group",None ):
        safe_prop (col ,mod ,"invert_vertex_group",text =pgettext ('Invert'))
        safe_prop (col ,mod ,"thickness_vertex_group",text =pgettext ('Factor'))

def _draw_bevel (col ,mod ):
    safe_prop (col ,mod ,"width",text =pgettext ('Amount'))
    safe_prop (col ,mod ,"segments",text =pgettext ('Segments'))
    safe_prop (col ,mod ,"limit_method",text =pgettext ('Limit Method'))
    limit_method =getattr (mod ,"limit_method","")
    if limit_method =='ANGLE':safe_prop (col ,mod ,"angle_limit",text =pgettext ('Angle'))
    elif limit_method =='VGROUP':safe_prop (col ,mod ,"vertex_group",text =pgettext ('Vertex Group'))
    safe_prop (col ,mod ,"profile",text =pgettext ('Profile Shape'))
    safe_prop (col ,mod ,"use_clamp_overlap",text =pgettext ('Avoid Duplicates'))
    safe_prop (col ,mod ,"miter_outer",text =pgettext ('Outer Miter'))
    safe_prop (col ,mod ,"miter_inner",text =pgettext ('Inner Miter'))

def _draw_array (col ,mod ):
    safe_prop (col ,mod ,"fit_type",text =pgettext ('Fit Type'))
    fit_type =getattr (mod ,"fit_type","")
    if fit_type =='FIXED_COUNT':safe_prop (col ,mod ,"count",text =pgettext ('Count'))
    elif fit_type =='FIT_LENGTH':safe_prop (col ,mod ,"fit_length",text =pgettext ('Length'))
    elif fit_type =='FIT_CURVE':safe_prop (col ,mod ,"curve",text =pgettext ('Curve'))

    safe_prop (col ,mod ,"use_relative_offset",text =pgettext ('Offset (Factor)'))
    if getattr (mod ,"use_relative_offset",False ):safe_prop (col ,mod ,"relative_offset_displace",text ="")
    safe_prop (col ,mod ,"use_constant_offset",text =pgettext ('Offset (Constant)'))
    if getattr (mod ,"use_constant_offset",False ):safe_prop (col ,mod ,"constant_offset_displace",text ="")
    safe_prop (col ,mod ,"use_object_offset",text =pgettext ('Offset (Object)'))
    if getattr (mod ,"use_object_offset",False ):safe_prop (col ,mod ,"offset_object",text =pgettext ('Object'))

    safe_prop (col ,mod ,"use_merge_vertices",text =pgettext ('Merge'))
    if getattr (mod ,"use_merge_vertices",False ):
        safe_prop (col ,mod ,"merge_threshold",text =pgettext ('Distance'))
        safe_prop (col ,mod ,"use_merge_vertices_cap",text =pgettext ('First & Last'))

def _draw_auto (col ,mod ):
    skip_props ={'rna_type','name','type','show_viewport','show_render','show_in_editmode','show_on_cage','show_expanded','is_active','use_apply_on_spline','execution_time','is_override_data'}
    for prop in mod .bl_rna .properties :
        if prop .identifier in skip_props or prop .is_readonly :continue 
        safe_prop (col ,mod ,prop .identifier )

_MS_STANDARD_MODIFIER_ENUM_CACHE = None
_MS_STACK_ADDABLE_PLUGIN_CACHE = {'sig': None, 'plugins': None, 'groups': None}


def _ms_get_standard_modifier_enum_items_cached():
    global _MS_STANDARD_MODIFIER_ENUM_CACHE
    if _MS_STANDARD_MODIFIER_ENUM_CACHE is not None:
        return _MS_STANDARD_MODIFIER_ENUM_CACHE
    items = {}
    try:
        enum_items = bpy.types.Modifier.bl_rna.properties['type'].enum_items
        for item in enum_items:
            try:
                items[str(item.identifier)] = (str(item.name), str(item.description or ''), str(item.icon or ''))
            except Exception:
                items[str(getattr(item, 'identifier', ''))] = (str(getattr(item, 'name', '') or ''), '', '')
    except Exception:
        items = {}
    _MS_STANDARD_MODIFIER_ENUM_CACHE = items
    return items


def _ms_stack_addable_plugin_signature():
    keys = []
    try:
        # Adopts the anchored registry when a file load replaced the namespace,
        # otherwise the Add Modifier menu silently falls back to PLUGIN_CATALOG
        # alone and every registered plugin entry disappears for the session.
        reg = _ms_plugins_dict()
        if isinstance(reg, dict):
            for key, plugin in reg.items():
                if not isinstance(plugin, dict):
                    continue
                keys.append((
                    str(key or plugin.get('id') or plugin.get('operator_id') or ''),
                    str(plugin.get('operator_id') or ''),
                    str(plugin.get('group') or ''),
                    str(plugin.get('label') or plugin.get('display_name') or ''),
                    str(plugin.get('icon') or ''),
                    bool(plugin.get('stack_addable', False)),
                    int(plugin.get('priority', 0) or 0),
                ))
    except Exception:
        pass
    try:
        keys.extend(('catalog', str(k)) for k in PLUGIN_CATALOG.keys())
    except Exception:
        pass
    try:
        return tuple(sorted(k for k in keys if k))
    except Exception:
        return tuple(keys)


def _ms_clear_add_menu_cache():
    try:
        _MS_STACK_ADDABLE_PLUGIN_CACHE['sig'] = None
        _MS_STACK_ADDABLE_PLUGIN_CACHE['plugins'] = None
        _MS_STACK_ADDABLE_PLUGIN_CACHE['groups'] = None
    except Exception:
        pass


def _ms_draw_modifier_list (layout ,ids ):
    enum_items = _ms_get_standard_modifier_enum_items_cached()
    for mid in ids :
        it =enum_items .get (mid )
        if not it :
            continue
        name = it[0] if isinstance(it, tuple) and it else str(mid)
        localized = bpy.app.translations.pgettext_iface(name)
        name = localized if localized != name else bpy.app.translations.pgettext_iface(name, 'Operator')
        icon = ''
        try:
            icon = str(it[2] or '') if isinstance(it, tuple) and len(it) >= 3 else ''
        except Exception:
            icon = ''
        op =_sms_icon_operator (layout ,"object.ms_add_modifier",text =name ,icon_name =icon or _sms_icon_name_for_modifier_type (mid ),fallback_icon =icon or _sms_icon_name_for_modifier_type (mid ) or 'MODIFIER')
        op .mod_type =mid


_MS_USER_TOOL_SETTINGS_PLUGIN_IDS = {
    'boolean_stack_modifier',
    'smart_cleanup_repair_tool',
    'pipe_modifier',
    'array_along_curve_modifier',
    'scatter_modifier',
    'conform_to_surface_tool',
    'floor_modifier',
    'stack_selected_modifier',
    'align_to_active_modifier',
    'distribute_selected_modifier',
    'drop_to_floor_modifier',
    'quad_checker_modifier',
    'workplane_modifier',
    'project_to_active_plane_modifier',
    'instances_along_path_modifier',
    'replace_modifier',
    'randomize_modifier',
    'projection_modifier',
    'rebuild_curve_modifier',
    'axis_slice_modifier',
    'vertices_path_modifier',
    'path_modifier',
    'profile_primitive_modifier',
    'helix_path_modifier',
    'loft_modifier',
    'sweep_modifier',
    'face_component_array_modifier',
    'cad_intersect_modifier',
    'audit_selected_modifier',
    'audit_select_issues_modifier',
    'surface_box_detail_modifier',
    'extrude_modifier',
    'slice_panel_modifier',
    'combine_join_clean_modifier',
    'drop_to_surface_modifier',
}

_MS_USER_TOOL_SETTINGS_OPERATOR_IDS = {
    'sms.smart_boolean_stack',
    'sms.smart_cleanup_repair',
    'sms.smart_pipe_from_selection',
    'sms.smart_array_along_curve',
    'sms.scatter_instances_bake',
    'sms.conform_to_surface',
    'sms.floor_generator',
    'smsp.stack_selected',
    'smsp.align_to_active',
    'smsp.distribute_selected_axis',
    'smsp.drop_to_floor',
    'smsp.quad_checker',
    'smsp.workplane_from_active',
    'smsp.project_to_active_plane',
    'smsp.instances_along_path',
    'smsp.replace_with_active',
    'smsp.randomize_selected',
    'smsp.project_to_selected_surface',
    'smsp.rebuild_active_curve',
    'smsp.axis_slice_edit',
    'smsp.selected_vertices_to_path',
    'smsp.selected_objects_to_path',
    'smsp.add_profile_primitive',
    'smsp.add_helix_path',
    'smsp.loft_bridge_paths',
    'smsp.sweep_active_profile',
    'smsp.face_component_array',
    'smsp.cad_intersect_extend',
    'smsp.audit_selected',
    'smsp.audit_select_issues',
    'smsa.surface_box_detail',
    'smsa.smart_extrude_clean',
    'smsa.slice_panel_stack',
    'smsa.combine_join_clean',
    'smsa.drop_to_surface',
}

_MS_USER_TOOL_SETTINGS_LEGACY_PREFIXES = (
    'SMS_',
    'Smart Pipe',
)


def _ms_user_tool_settings_entry_from_object (obj ,mod ):
    if obj is None or mod is None:
        return None
    try:
        raw =obj .get ('smsm_internal_user_tool_defaults_map','')
    except Exception:
        raw =''
    data ={}
    try:
        if isinstance (raw ,dict):
            data =dict (raw )
        elif str (raw or '').strip ():
            parsed =json .loads (str (raw ))
            if isinstance (parsed ,dict):
                data =parsed
    except Exception:
        data ={}
    if not data:
        return None
    try:
        return data .get (str (getattr (mod ,'name','')or ''))
    except Exception:
        return None



_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_PLUGIN = {
    'boolean_stack_modifier': {'hub_boolean'},
    'smart_cleanup_repair_tool': {'hub_cleanup'},
    'pipe_modifier': {'hub_pipe'},
    'array_along_curve_modifier': {'hub_array'},
    'scatter_modifier': {'hub_scatter'},
    'conform_to_surface_tool': {'hub_conform'},
    'floor_modifier': {'hub_floor'},
    'stack_selected_modifier': {'precision_layout'},
    'align_to_active_modifier': {'precision_layout'},
    'distribute_selected_modifier': {'precision_layout'},
    'drop_to_floor_modifier': {'precision_layout'},
    'quad_checker_modifier': {'precision_topology'},
    'workplane_modifier': {'precision_workplane'},
    'project_to_active_plane_modifier': {'precision_workplane'},
    'instances_along_path_modifier': {'precision_layout'},
    'replace_modifier': {'precision_layout'},
    'randomize_modifier': {'precision_layout'},
    'projection_modifier': {'precision_workplane'},
    'rebuild_curve_modifier': {'precision_curve'},
    'axis_slice_modifier': {'precision_axis_slice'},
    'vertices_path_modifier': {'precision_curve'},
    'path_modifier': {'precision_curve'},
    'profile_primitive_modifier': {'precision_curve'},
    'helix_path_modifier': {'precision_curve'},
    'loft_modifier': {'precision_curve'},
    'sweep_modifier': {'precision_curve'},
    'face_component_array_modifier': {'precision_topology'},
    'cad_intersect_modifier': {'precision_workplane'},
    'audit_selected_modifier': {'precision_topology'},
    'audit_select_issues_modifier': {'precision_topology'},
    'surface_box_detail_modifier': {'advanced_surface_box'},
    'extrude_modifier': {'advanced_extrude'},
    'slice_panel_modifier': {'advanced_slice'},
    'combine_join_clean_modifier': {'advanced_combine'},
    'drop_to_surface_modifier': {'advanced_drop'},
}

_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_OPERATOR = {
    'sms.smart_boolean_stack': {'hub_boolean'},
    'sms.smart_cleanup_repair': {'hub_cleanup'},
    'sms.smart_pipe_from_selection': {'hub_pipe'},
    'sms.smart_array_along_curve': {'hub_array'},
    'sms.scatter_instances_bake': {'hub_scatter'},
    'sms.conform_to_surface': {'hub_conform'},
    'sms.floor_generator': {'hub_floor'},
    'smsp.stack_selected': {'precision_layout'},
    'smsp.align_to_active': {'precision_layout'},
    'smsp.distribute_selected_axis': {'precision_layout'},
    'smsp.drop_to_floor': {'precision_layout'},
    'smsp.quad_checker': {'precision_topology'},
    'smsp.workplane_from_active': {'precision_workplane'},
    'smsp.project_to_active_plane': {'precision_workplane'},
    'smsp.instances_along_path': {'precision_layout'},
    'smsp.replace_with_active': {'precision_layout'},
    'smsp.randomize_selected': {'precision_layout'},
    'smsp.project_to_selected_surface': {'precision_workplane'},
    'smsp.rebuild_active_curve': {'precision_curve'},
    'smsp.axis_slice_edit': {'precision_axis_slice'},
    'smsp.selected_vertices_to_path': {'precision_curve'},
    'smsp.selected_objects_to_path': {'precision_curve'},
    'smsp.add_profile_primitive': {'precision_curve'},
    'smsp.add_helix_path': {'precision_curve'},
    'smsp.loft_bridge_paths': {'precision_curve'},
    'smsp.sweep_active_profile': {'precision_curve'},
    'smsp.face_component_array': {'precision_topology'},
    'smsp.cad_intersect_extend': {'precision_workplane'},
    'smsp.audit_selected': {'precision_topology'},
    'smsp.audit_select_issues': {'precision_topology'},
    'smsa.surface_box_detail': {'advanced_surface_box'},
    'smsa.smart_extrude_clean': {'advanced_extrude'},
    'smsa.slice_panel_stack': {'advanced_slice'},
    'smsa.combine_join_clean': {'advanced_combine'},
    'smsa.drop_to_surface': {'advanced_drop'},
}



_MS_USER_TOOL_SETTINGS_ALL_GROUPS = set()
for _groups in list(_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_PLUGIN.values()) + list(_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_OPERATOR.values()):
    try:
        _MS_USER_TOOL_SETTINGS_ALL_GROUPS.update(_groups)
    except Exception:
        pass


def _ms_normalize_user_tool_settings_groups(value):
    groups = set()
    if value is None:
        return groups
    if isinstance(value, (set, list, tuple)):
        items = list(value)
    else:
        text = str(value or '').strip()
        if not text:
            return groups
        try:
            parsed = json.loads(text)
            if isinstance(parsed, (list, tuple, set)):
                items = list(parsed)
            elif isinstance(parsed, str):
                items = [parsed]
            else:
                items = [text]
        except Exception:
            items = text.replace(';', ',').replace('|', ',').split(',')
    for item in items:
        group = str(item or '').strip()
        if group in _MS_USER_TOOL_SETTINGS_ALL_GROUPS:
            groups.add(group)
    return groups


def _ms_truthy_user_tool_setting_flag(value):
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    text = str(value).strip().lower()
    return text in {'1', 'true', 'yes', 'on', 'required', 'show'}


def _ms_user_tool_settings_requirement(mod, obj=None):
    """Return (required, explicit_groups) for the active modifier settings block.

    Ownership alone is not enough.  The User Tool Settings block is only useful
    when the active modifier explicitly marks that shared user-tool settings are
    required, or when explicit valid setting groups are stored for that exact
    modifier.
    """
    required = False
    groups = set()
    try:
        entry = _ms_user_tool_settings_entry_from_object(obj, mod)
        if isinstance(entry, dict):
            for key in ('settings_groups', 'user_tool_settings_groups', 'groups'):
                groups.update(_ms_normalize_user_tool_settings_groups(entry.get(key)))
            for key in ('show_settings', 'settings_required', 'user_tool_settings_required', 'requires_user_tool_settings'):
                if _ms_truthy_user_tool_setting_flag(entry.get(key)):
                    required = True
                    break
    except Exception:
        pass
    for key in ('smsm_internal_user_tool_settings_groups', 'smsm_user_tool_settings_groups'):
        try:
            groups.update(_ms_normalize_user_tool_settings_groups(mod.get(key, None)))
        except Exception:
            pass
    for key in ('smsm_internal_user_tool_settings_required', 'smsm_user_tool_settings_required', 'smsm_requires_user_tool_settings'):
        try:
            if _ms_truthy_user_tool_setting_flag(mod.get(key, None)):
                required = True
                break
        except Exception:
            pass
    if groups:
        required = True
    return required, groups


def _ms_modifier_user_tool_identity(mod, obj=None, context=None):
    """Return the explicit user-tool owner IDs for this exact modifier.

    The property display must stay quiet for normal modifiers.  Therefore this
    intentionally ignores broad catalog/name inference and only accepts markers
    stored on the active modifier itself or in the object-level modifier map.
    """
    if mod is None:
        return '', ''
    pid = ''
    op_id = ''
    try:
        entry = _ms_user_tool_settings_entry_from_object(obj, mod)
        if isinstance(entry, dict):
            pid = str(entry.get('plugin_id', '') or '').strip()
            op_id = str(entry.get('operator_id', '') or '').strip()
        elif isinstance(entry, str):
            pid = str(entry or '').strip()
    except Exception:
        pass
    # Modifier ID properties are used by generated custom/Max-style modifiers and
    # by tools that cannot be reliably tracked by the object-level map alone.
    for key in ('smsm_internal_user_tool_id', 'smsm_user_tool_id', 'smsm_plugin_id'):
        if pid:
            break
        try:
            val = str(mod.get(key, '') or '').strip()
            if val:
                pid = val
        except Exception:
            pass
    if not op_id:
        try:
            op_id = str(mod.get('smsm_internal_user_tool_operator_id', '') or '').strip()
        except Exception:
            op_id = ''
    return pid, op_id


def _ms_user_tool_setting_groups_for_modifier(mod, obj=None, context=None):
    if mod is None:
        return set()
    required, explicit_groups = _ms_user_tool_settings_requirement(mod, obj)
    if not required:
        return set()
    if explicit_groups:
        return set(explicit_groups)
    pid, op_id = _ms_modifier_user_tool_identity(mod, obj, context)
    groups = set()
    if pid:
        groups.update(_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_PLUGIN.get(pid, set()))
    if op_id:
        groups.update(_MS_USER_TOOL_SETTINGS_PROFILE_GROUPS_BY_OPERATOR.get(op_id, set()))
    return groups


def _ms_modifier_should_show_user_tool_settings(mod, obj=None, context=None):
    return bool(_ms_user_tool_setting_groups_for_modifier(mod, obj, context))


def _ms_draw_migrated_user_tool_defaults(layout, context, active_mod=None, active_obj=None):
    groups = _ms_user_tool_setting_groups_for_modifier(active_mod, active_obj, context)
    if not groups:
        return
    scene = getattr(context, 'scene', None)
    hub = getattr(scene, 'hub_props', None)
    precision = getattr(scene, 'smsp_props', None)
    advanced = getattr(scene, 'smsa_props', None)
    has_available_group = (
        (hub is not None and any(g.startswith('hub_') for g in groups)) or
        (precision is not None and any(g.startswith('precision_') for g in groups)) or
        (advanced is not None and any(g.startswith('advanced_') for g in groups))
    )
    if not has_available_group:
        return

    root = layout.box()
    root.use_property_split = True
    try:
        root.use_property_decorate = True
    except Exception:
        pass
    root.label(text=pgettext('User Tool Settings'), icon='TOOL_SETTINGS')

    if hub is not None and 'hub_boolean' in groups:
        box = root.box()
        box.label(text=pgettext('Hard Surface / Boolean'), icon='MOD_BOOLEAN')
        row = box.row(align=True)
        safe_prop(row, hub, 'boolean_operation', text='')
        safe_prop(row, hub, 'boolean_solver', text='')
        row = box.row(align=True)
        safe_prop(row, hub, 'hs_auto_bevel')
        safe_prop(row, hub, 'hs_weighted_normal')
        row = box.row(align=True)
        safe_prop(row, hub, 'hs_bevel_width')
        safe_prop(row, hub, 'hs_bevel_segments')
        safe_prop(box, hub, 'hs_organize_cutters')

    if hub is not None and 'hub_cleanup' in groups:
        box = root.box()
        box.label(text=pgettext('Topology / Repair'), icon='MOD_REMESH')
        row = box.row(align=True)
        safe_prop(row, hub, 'cleanup_merge_distance')
        safe_prop(row, hub, 'cleanup_fill_holes')
        row = box.row(align=True)
        safe_prop(row, hub, 'cleanup_join_tris')
        safe_prop(row, hub, 'cleanup_recalc_normals')

    if hub is not None and ('hub_pipe' in groups or 'hub_array' in groups):
        box = root.box()
        box.label(text=pgettext('Curves / Path / Sweep'), icon='CURVE_DATA')
        if 'hub_pipe' in groups:
            row = box.row(align=True)
            safe_prop(row, hub, 'pipe_radius')
            safe_prop(row, hub, 'pipe_resolution')
            safe_prop(box, hub, 'pipe_fill_caps')
        if 'hub_array' in groups:
            row = box.row(align=True)
            safe_prop(row, hub, 'array_offset_x')
            safe_prop(row, hub, 'array_count')
            safe_prop(box, hub, 'array_merge_vertices')

    if hub is not None and 'hub_conform' in groups:
        box = root.box()
        box.label(text=pgettext('Surface / Conform'), icon='MOD_SHRINKWRAP')
        row = box.row(align=True)
        safe_prop(row, hub, 'conform_mode', text='')
        safe_prop(row, hub, 'conform_offset')
        row = box.row(align=True)
        safe_prop(row, hub, 'conform_parent')
        safe_prop(row, hub, 'conform_organize')

    if hub is not None and ('hub_scatter' in groups or 'hub_floor' in groups):
        box = root.box()
        box.label(text=pgettext('Layout / Scatter / Replacement'), icon='OUTLINER_COLLECTION')
        if 'hub_scatter' in groups:
            row = box.row(align=True)
            safe_prop(row, hub, 'scatter_count')
            safe_prop(row, hub, 'scatter_seed')
            row = box.row(align=True)
            safe_prop(row, hub, 'scatter_scale_min')
            safe_prop(row, hub, 'scatter_scale_max')
            row = box.row(align=True)
            safe_prop(row, hub, 'scatter_random_z_deg')
            safe_prop(row, hub, 'scatter_align_normal')
            safe_prop(box, hub, 'scatter_surface_offset')
        if 'hub_floor' in groups:
            box.separator()
            row = box.row(align=True)
            safe_prop(row, hub, 'floor_board_width')
            safe_prop(row, hub, 'floor_board_length')
            row = box.row(align=True)
            safe_prop(row, hub, 'floor_gap')
            safe_prop(row, hub, 'floor_thickness')
            row = box.row(align=True)
            safe_prop(row, hub, 'floor_stagger')
            safe_prop(row, hub, 'floor_axis', text='')

    if precision is not None and 'precision_workplane' in groups:
        box = root.box()
        box.label(text=pgettext('Precision / CAD / Workplane'), icon='ORIENTATION_CURSOR')
        safe_prop(box, precision, 'workplane_use_cursor_pivot')
        safe_prop(box, precision, 'workplane_use_cursor_orientation')
        safe_prop(box, precision, 'project_offset')
        safe_prop(box, precision, 'surface_project_offset')
        row = box.row(align=True)
        safe_prop(row, precision, 'symmetry_direction')
        safe_prop(row, precision, 'symmetry_merge_threshold')
        row = box.row(align=True)
        safe_prop(row, precision, 'symmetry_use_modifier')
        safe_prop(row, precision, 'symmetry_clip')
        safe_prop(box, precision, 'cad_mode')

    if precision is not None and 'precision_axis_slice' in groups:
        box = root.box()
        box.label(text=pgettext('Precision / CAD / Workplane'), icon='ORIENTATION_CURSOR')
        row = box.row(align=True)
        safe_prop(row, precision, 'axis_slice_axis')
        safe_prop(row, precision, 'axis_slice_count')
        row = box.row(align=True)
        safe_prop(row, precision, 'axis_slice_use_selection_bounds')
        safe_prop(row, precision, 'axis_slice_select_new')
        safe_prop(box, precision, 'axis_slice_tolerance')

    if precision is not None and 'precision_curve' in groups:
        box = root.box()
        box.label(text=pgettext('Curves / Loft / Prep'), icon='CURVE_DATA')
        row = box.row(align=True)
        safe_prop(row, precision, 'curve_rebuild_count')
        safe_prop(row, precision, 'curve_rebuild_keep_original')
        row = box.row(align=True)
        safe_prop(row, precision, 'profile_primitive_type')
        safe_prop(row, precision, 'profile_points')
        row = box.row(align=True)
        safe_prop(row, precision, 'profile_width')
        safe_prop(row, precision, 'profile_height')
        if getattr(precision, 'profile_primitive_type', '') == 'STAR':
            safe_prop(box, precision, 'profile_star_inner')
        row = box.row(align=True)
        safe_prop(row, precision, 'helix_radius')
        safe_prop(row, precision, 'helix_height')
        row = box.row(align=True)
        safe_prop(row, precision, 'helix_turns')
        safe_prop(row, precision, 'helix_points_per_turn')
        row = box.row(align=True)
        safe_prop(row, precision, 'helix_taper')
        safe_prop(row, precision, 'helix_clockwise')
        row = box.row(align=True)
        safe_prop(row, precision, 'objects_to_path_use_nearest')
        safe_prop(row, precision, 'objects_to_path_cyclic')
        row = box.row(align=True)
        safe_prop(row, precision, 'vertices_to_path_use_nearest')
        safe_prop(row, precision, 'vertices_to_path_cyclic')
        row = box.row(align=True)
        safe_prop(row, precision, 'sweep_duplicate_path')
        safe_prop(row, precision, 'sweep_fill_caps')
        row = box.row(align=True)
        safe_prop(row, precision, 'loft_sample_count')
        safe_prop(row, precision, 'sweep_resolution_u')
        safe_prop(box, precision, 'loft_shade_smooth')

    if precision is not None and 'precision_topology' in groups:
        box = root.box()
        box.label(text=pgettext('Topology / Repair'), icon='MOD_REMESH')
        row = box.row(align=True)
        safe_prop(row, precision, 'audit_merge_distance')
        safe_prop(row, precision, 'audit_issue_filter')
        row = box.row(align=True)
        safe_prop(row, precision, 'face_component_selected_faces_only')
        safe_prop(row, precision, 'face_component_scale_to_face')
        row = box.row(align=True)
        safe_prop(row, precision, 'face_component_scale')
        safe_prop(row, precision, 'face_component_offset')
        safe_prop(box, precision, 'face_component_linked_data')
        if getattr(precision, 'audit_report', ''):
            report_box = box.box()
            report_box.operator('smsp.audit_show_report', text=pgettext('Last Audit Report'), icon='TEXT')

    if precision is not None and 'precision_layout' in groups:
        box = root.box()
        box.label(text=pgettext('Layout / Scatter / Replacement'), icon='OUTLINER_COLLECTION')
        safe_prop(box, precision, 'path_count')
        row = box.row(align=True)
        safe_prop(row, precision, 'path_include_ends')
        safe_prop(row, precision, 'path_follow_tangent')
        safe_prop(box, precision, 'path_random_roll_deg')
        row = box.row(align=True)
        safe_prop(row, precision, 'path_linked_data')
        safe_prop(row, precision, 'path_organize')
        row = box.row(align=True)
        safe_prop(row, precision, 'stack_axis')
        safe_prop(row, precision, 'stack_gap')
        row = box.row(align=True)
        safe_prop(row, precision, 'align_location')
        safe_prop(row, precision, 'align_rotation')
        safe_prop(row, precision, 'align_scale')
        row = box.row(align=True)
        safe_prop(row, precision, 'align_axis_x')
        safe_prop(row, precision, 'align_axis_y')
        safe_prop(row, precision, 'align_axis_z')
        safe_prop(row, precision, 'distribute_axis')
        row = box.row(align=True)
        safe_prop(row, precision, 'replace_linked_data')
        safe_prop(row, precision, 'replace_delete_targets')
        safe_prop(box, precision, 'replace_preserve_collections')
        box.separator()
        safe_prop(box, precision, 'random_seed')
        row = box.row(align=True)
        safe_prop(row, precision, 'random_xy_offset')
        safe_prop(row, precision, 'random_z_offset')
        safe_prop(box, precision, 'random_z_rotation_deg')
        row = box.row(align=True)
        safe_prop(row, precision, 'random_scale_min')
        safe_prop(row, precision, 'random_scale_max')
        row = box.row(align=True)
        safe_prop(row, precision, 'drop_to_floor_use_cursor_z')
        safe_prop(row, precision, 'drop_to_floor_z')

    if advanced is not None and 'advanced_surface_box' in groups:
        box = root.box()
        box.label(text=pgettext('Surface Detail / Layout'), icon='MESH_CUBE')
        row = box.row(align=True)
        safe_prop(row, advanced, 'surface_box_width')
        safe_prop(row, advanced, 'surface_box_length')
        safe_prop(row, advanced, 'surface_box_height')
        row = box.row(align=True)
        safe_prop(row, advanced, 'surface_box_operation')
        row = box.row(align=True)
        safe_prop(row, advanced, 'surface_box_wire')
        safe_prop(row, advanced, 'surface_box_parent')

    if advanced is not None and 'advanced_extrude' in groups:
        box = root.box()
        box.label(text=pgettext('Smart Extrude Clean'), icon='FACESEL')
        row = box.row(align=True)
        safe_prop(row, advanced, 'smart_extrude_inset')
        safe_prop(row, advanced, 'smart_extrude_distance')
        row = box.row(align=True)
        safe_prop(row, advanced, 'smart_extrude_even')
        safe_prop(row, advanced, 'smart_extrude_recalc')

    if advanced is not None and 'advanced_slice' in groups:
        box = root.box()
        box.label(text=pgettext('Slice / Panel Stack'), icon='MOD_BOOLEAN')
        row = box.row(align=True)
        safe_prop(row, advanced, 'slice_axis')
        safe_prop(row, advanced, 'slice_count')
        safe_prop(row, advanced, 'slice_thickness')
        row = box.row(align=True)
        safe_prop(row, advanced, 'slice_operation')
        row = box.row(align=True)
        safe_prop(row, advanced, 'slice_wire')
        safe_prop(row, advanced, 'slice_organize')

    if advanced is not None and 'advanced_combine' in groups:
        box = root.box()
        box.label(text=pgettext('Combine / Join Clean'), icon='AUTOMERGE_ON')
        row = box.row(align=True)
        safe_prop(row, advanced, 'combine_cleanup')
        safe_prop(row, advanced, 'combine_cleanup_normals')

    if advanced is not None and 'advanced_drop' in groups:
        box = root.box()
        box.label(text=pgettext('Drop To Surface'), icon='SNAP_ON')
        row = box.row(align=True)
        safe_prop(row, advanced, 'drop_offset')
        safe_prop(row, advanced, 'drop_align_to_surface')
        safe_prop(row, advanced, 'drop_use_bounds')


        # Add menu categories are intentionally conservative.
        # Only direct native modifiers that stay on the selected object and remain
        # practical to inspect/tune from Property Items Display are exposed here.
        # Helper-driven, target-driven, generator-style, and custom wrapper tools are
        # surfaced from Smart Modeling instead.
MS_ADD_STANDARD ={
"edit":(
'DATA_TRANSFER','MESH_CACHE','MESH_SEQUENCE_CACHE','UV_PROJECT',
'UV_WARP','VERTEX_WEIGHT_EDIT','VERTEX_WEIGHT_MIX',
'VERTEX_WEIGHT_PROXIMITY',
),
"generate":(
'ARRAY','BEVEL','BOOLEAN','BUILD','DECIMATE','EDGE_SPLIT',
'MASK','MIRROR','MULTIRES','REMESH','SCREW','SKIN',
'SOLIDIFY','SUBSURF','TRIANGULATE','WELD','WIREFRAME',
),
"deform":(
'ARMATURE','CAST','CURVE','DISPLACE','HOOK','LAPLACIANDEFORM',
'LATTICE','MESH_DEFORM','SHRINKWRAP','SIMPLE_DEFORM','SMOOTH',
'CORRECTIVE_SMOOTH','LAPLACIANSMOOTH','SURFACE_DEFORM','WARP',
'WAVE','VOLUME_DISPLACE',
),
"normals":(
'NORMAL_EDIT','WEIGHTED_NORMAL',
),
"physics":(
'CLOTH','COLLISION','DYNAMIC_PAINT','EXPLODE','FLUID','OCEAN',
'PARTICLE_INSTANCE','PARTICLE_SYSTEM','SOFT_BODY',
),
"geometry":(
'MESH_TO_VOLUME','VOLUME_TO_MESH',
),
"hair":(
'PARTICLE_SYSTEM',
),
"instances":(
'PARTICLE_INSTANCE',
),
"geometry_nodes":(
'NODES',
),
}


def _ms_operator_exists (operator_id ):
    op_id =str (operator_id or '').strip ()
    if '.'not in op_id :
        return False 
    head ,tail =op_id .split ('.',1 )
    group =getattr (bpy .ops ,head ,None )
    if group is None :
        return False 
    return callable (getattr (group ,tail ,None ))


def _ms_build_catalog_fallback_draw_fn (plugin_id ,label ,operator_id ,icon ='MODIFIER'):
    safe_name =str (plugin_id or operator_id or 'plugin').replace ('.','_').replace ('-','_')
    def _draw (layout ,_context ):
        row =_sms_large_icon_row (layout ,align =True ,scale_y =1.08 )
        icon_name =_sms_icon_for_plugin ({'id':plugin_id ,'operator_id':operator_id ,'icon':icon},'modifier')
        op =_sms_icon_operator (row ,"smsm.run_user_plugin",text =locale_pgettext_iface (label ,context =_context ),icon_name =icon_name ,fallback_icon =icon )
        op .plugin_id =str (plugin_id or '')
        op .operator_id =str (operator_id or '')
        op .label =str (label or operator_id or plugin_id or 'Plugin')
    _draw .__name__ =f'draw_catalog_fallback_{safe_name }'
    return _draw 


def _ms_collect_stack_addable_user_plugins ():
    sig = _ms_stack_addable_plugin_signature()
    try:
        cached_sig = _MS_STACK_ADDABLE_PLUGIN_CACHE.get('sig')
        cached_plugins = _MS_STACK_ADDABLE_PLUGIN_CACHE.get('plugins')
        if cached_sig == sig and isinstance(cached_plugins, list):
            return list(cached_plugins)
    except Exception:
        pass
    plugins =[]
    seen =set ()
    try :
        for p in ms_get_plugins_sorted ():
            if not isinstance (p ,dict ):
                continue
            if not is_stack_addable_plugin (
            plugin_id =p .get ('id'),
            operator_id =p .get ('operator_id'),
            plugin_meta =p ,
            ):
                continue
            key =str (p .get ('id')or p .get ('operator_id')or '').strip ()
            if not key or key in seen :
                continue
            seen .add (key )
            plugins .append (dict (p ))
    except Exception :
        pass

    try :
        for plugin_id in PLUGIN_CATALOG .keys ():
            meta =get_plugin_meta (plugin_id =plugin_id )
            if not isinstance (meta ,dict ):
                continue
            if not is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =meta .get ('operator_id'),plugin_meta =meta ):
                continue
            operator_id =str (meta .get ('operator_id')or '').strip ()
            key =str (plugin_id or operator_id ).strip ()
            if not key or key in seen :
                continue
            fallback =dict (meta )
            fallback ['id']=str (plugin_id )
            fallback ['stack_addable']=True
            fallback ['modeling_side']=False
            fallback .setdefault ('icon','MODIFIER')
            fallback .setdefault ('label',str (meta .get ('label')or meta .get ('display_name')or plugin_id ))
            fallback .setdefault ('draw_add_menu',_ms_build_catalog_fallback_draw_fn (plugin_id ,fallback ['label'],operator_id ,fallback ['icon']))
            plugins .append (fallback )
            seen .add (key )
    except Exception :
        pass

    try :
        plugins .sort (key =lambda p :int (p .get ('priority',0 )or 0 ),reverse =True )
    except Exception :
        pass
    try:
        _MS_STACK_ADDABLE_PLUGIN_CACHE['sig'] = sig
        _MS_STACK_ADDABLE_PLUGIN_CACHE['plugins'] = list(plugins)
        _MS_STACK_ADDABLE_PLUGIN_CACHE['groups'] = None
    except Exception:
        pass
    return plugins


def _ms_has_stack_addable_user_plugins ():
    try :
        return bool (_ms_collect_stack_addable_user_plugins ())
    except Exception :
        return False 


def _ms_get_available_user_plugin_groups ():
    sig = _ms_stack_addable_plugin_signature()
    try:
        if _MS_STACK_ADDABLE_PLUGIN_CACHE.get('sig') == sig and isinstance(_MS_STACK_ADDABLE_PLUGIN_CACHE.get('groups'), list):
            return list(_MS_STACK_ADDABLE_PLUGIN_CACHE.get('groups') or [])
    except Exception:
        pass
    try :
        plugins =list (_ms_collect_stack_addable_user_plugins ())
    except Exception :
        plugins =[]
    if not plugins :
        groups = []
    else:
        groups =[(group_id ,group_plugins )for group_id ,group_plugins in iter_plugins_grouped (plugins )if group_plugins ]
    try:
        _MS_STACK_ADDABLE_PLUGIN_CACHE['sig'] = sig
        _MS_STACK_ADDABLE_PLUGIN_CACHE['groups'] = list(groups)
    except Exception:
        pass
    return groups


def _ms_user_group_menu_idname (group_id :str )->str :
    safe_group =str (group_id or 'other').replace ('-','_')
    return f"OBJECT_MT_ms_add_user_group_{safe_group }"


def _ms_user_group_menu_label (group_id :str )->str :
    return get_plugin_group_label (group_id )


def _ms_user_group_menu_title (group_id :str )->str :
    try :
        return str (GROUP_META .get (group_id ,GROUP_META ['other'])['label']or GROUP_META ['other']['label'])
    except Exception :
        return str (GROUP_META ['other']['label'])



def _ms_draw_stack_add_plugin_entry (layout ,context ,plugin ):
    if not isinstance (plugin ,dict ):
        return False
    plugin_id =str (plugin .get ('id')or '').strip ()
    operator_id =str (plugin .get ('operator_id')or '').strip ()
    label_en =str (plugin .get ('label')or plugin .get ('display_name')or operator_id or plugin_id or '').strip ()
    label_ja =str (plugin .get ('label_ja')or plugin .get ('display_name_ja')or label_en ).strip ()
    label =label_en or label_ja
    if not (plugin_id or operator_id or label ):
        return False
    fallback_icon =str (plugin .get ('icon')or 'MODIFIER')
    try :
        icon_name =_sms_icon_for_plugin (plugin ,'modifier')
    except Exception :
        icon_name =fallback_icon
    try :
        text =choose_text (label_en ,label_ja ,context =context )
    except Exception :
        try :
            text =locale_pgettext_iface (label ,context =context )
        except Exception :
            text =label
    try :
        row =_sms_large_icon_row (layout ,align =True ,scale_y =1.08 )
    except Exception :
        row =layout .row (align =True )
    try :
        op =_sms_icon_operator (row ,"smsm.run_user_plugin",text =text ,icon_name =icon_name ,fallback_icon =fallback_icon )
        op .plugin_id =plugin_id
        op .operator_id =operator_id
        op .label =label or operator_id or plugin_id or 'Plugin'
        return True
    except Exception :
        return False

def _ms_draw_user_group_menu (layout ,context ,group_id :str ):
    groups ={gid :group_plugins for gid ,group_plugins in _ms_get_available_user_plugin_groups ()}
    group_plugins =groups .get (group_id ,[])
    if not group_plugins :
        layout .label (text =pgettext ('No tools are currently available in this group'),icon='NONE')
        return 
    drew =False
    for plugin in group_plugins :
        try :
            drew =bool (_ms_draw_stack_add_plugin_entry (layout ,context ,plugin ))or drew
        except Exception :
            continue
    if not drew :
        layout .label (text =pgettext ('No tools are currently available in this group'),icon='NONE')


def _ms_make_user_group_menu_class (group_id :str ):
    class_name =_ms_user_group_menu_idname (group_id )
    label =_ms_user_group_menu_title (group_id )
    desc =(
    f"Grouped user submenu for {GROUP_META .get (group_id ,GROUP_META ['other'])['label']} inside Add Modifier. "
    f"Use this to keep the custom modifier catalog split by genre instead of one very long User list."
    )

    def draw (self ,context ):
        _ms_draw_user_group_menu (self .layout ,context ,group_id )

    return type (
    class_name ,
    (bpy .types .Menu ,),
    {
    '__module__':__name__ ,
    'bl_label':label ,
    'bl_idname':class_name ,
    'bl_description':desc ,
    '_ms_user_group_id':group_id ,
    'draw':draw ,
    },
    )


_MS_USER_GROUP_ORDER =tuple (
gid for gid in sorted (
GROUP_META .keys (),
key =lambda _gid :int (GROUP_META .get (_gid ,GROUP_META ['other']).get ('priority',0 )),
reverse =True ,
)
)
MS_USER_GROUP_MENU_CLASSES =tuple (_ms_make_user_group_menu_class (group_id )for group_id in _MS_USER_GROUP_ORDER )
MS_USER_GROUP_MENU_IDNAME_BY_GROUP ={
str (getattr (cls ,'_ms_user_group_id','')or ''):str (getattr (cls ,'bl_idname','')or '')
for cls in MS_USER_GROUP_MENU_CLASSES 
}


class VIEW3D_MT_ms_add_edit_menu (bpy .types .Menu ):
    bl_label ='Edit';bl_idname ="VIEW3D_MT_ms_add_edit_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['edit'])


class VIEW3D_MT_ms_add_generate_menu (bpy .types .Menu ):
    bl_label ='Generate';bl_idname ="VIEW3D_MT_ms_add_generate_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['generate'])


class VIEW3D_MT_ms_add_deform_menu (bpy .types .Menu ):
    bl_label ='Deform';bl_idname ="VIEW3D_MT_ms_add_deform_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['deform'])


class VIEW3D_MT_ms_add_normals_menu (bpy .types .Menu ):
    bl_label ='Normals';bl_idname ="VIEW3D_MT_ms_add_normals_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['normals'])


class VIEW3D_MT_ms_add_physics_menu (bpy .types .Menu ):
    bl_label ='Physics';bl_idname ="VIEW3D_MT_ms_add_physics_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['physics'])


class VIEW3D_MT_ms_add_geometry_menu (bpy .types .Menu ):
    bl_label ='Geometry';bl_idname ="VIEW3D_MT_ms_add_geometry_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['geometry'])


class VIEW3D_MT_ms_add_hair_menu (bpy .types .Menu ):
    bl_label ='Hair';bl_idname ="VIEW3D_MT_ms_add_hair_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['hair'])


class VIEW3D_MT_ms_add_instances_menu (bpy .types .Menu ):
    bl_label ='Instances';bl_idname ="VIEW3D_MT_ms_add_instances_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['instances'])


class VIEW3D_MT_ms_add_geometry_nodes_menu (bpy .types .Menu ):
    bl_label ='Geometry Nodes';bl_idname ="VIEW3D_MT_ms_add_geometry_nodes_menu"
    def draw (self ,context ):
        _ms_draw_modifier_list (self .layout ,MS_ADD_STANDARD ['geometry_nodes'])

class OBJECT_MT_ms_add_user (bpy .types .Menu ):
    bl_label ='User';bl_idname ="OBJECT_MT_ms_add_user"
    def draw (self ,context ):
        layout =self .layout 
        groups =_ms_get_available_user_plugin_groups ()
        if not groups :
            layout .label (text =pgettext ('No user tools are currently available'),icon='NONE')
            return 
        for group_id ,_group_plugins in groups :
            menu_idname =MS_USER_GROUP_MENU_IDNAME_BY_GROUP .get (str (group_id or ''))
            if menu_idname :
                _sms_draw_menu (layout ,menu_idname ,text =_ms_user_group_menu_label (group_id ),icon_name =str (group_id or ''),fallback_icon =get_plugin_group_icon (group_id ))
            else :
                _ms_draw_user_group_menu (layout ,context ,group_id )

class VIEW3D_MT_ms_master_add_menu (bpy .types .Menu ):
    bl_label ='Add Modifier';bl_idname ="VIEW3D_MT_ms_master_add_menu"
    def draw (self ,context ):
        layout =self .layout 
        layout .label (text =choose_text ('Blender modifiers + User tools','Blender標準 + ユーザーツール',context =context ),icon ='MODIFIER')
        user_groups =_ms_get_available_user_plugin_groups ()
        for group_id ,_group_plugins in user_groups :
            menu_idname =MS_USER_GROUP_MENU_IDNAME_BY_GROUP .get (str (group_id or ''))
            if menu_idname :
                _sms_draw_menu (layout ,menu_idname ,text =_ms_user_group_menu_label (group_id ),icon_name =str (group_id or ''),fallback_icon =get_plugin_group_icon (group_id ))
        if user_groups :
            layout .separator ()
        layout .menu ("VIEW3D_MT_ms_add_edit_menu")
        layout .menu ("VIEW3D_MT_ms_add_generate_menu")
        layout .menu ("VIEW3D_MT_ms_add_deform_menu")
        layout .menu ("VIEW3D_MT_ms_add_normals_menu")
        layout .menu ("VIEW3D_MT_ms_add_physics_menu")
        layout .menu ("VIEW3D_MT_ms_add_geometry_menu")
        layout .menu ("VIEW3D_MT_ms_add_hair_menu")
        layout .menu ("VIEW3D_MT_ms_add_instances_menu")
        layout .menu ("VIEW3D_MT_ms_add_geometry_nodes_menu")

def _ms_request_panel_state_save (context=None):
    """Draw-safe placeholder for legacy panel-state save calls.

    Older builds called persistent_state.request_save() from panel draw methods.
    That routine collects scene/object state and can run every sidebar redraw,
    including during 3D View orbit/pan/zoom.  Section/property updates already
    save through their update callbacks or explicit toggle operators, so draw
    calls must stay side-effect free for viewport responsiveness.
    """
    del context
    return None


def _ms_enabled_text (enabled )->str :
    msgid = 'Enabled' if bool(enabled) else 'Disabled'
    text = pgettext(msgid)
    if text == msgid:
        return 'On' if bool(enabled) else 'Off'
    return text


def _ms_draw_always_on_toggle_row (layout ,context ,label ,*, owner =None ,prop_name ='', icon ='CHECKBOX_HLT', operator_id ='', alias ='', feature_key ='', enabled =False ,active =True )->bool :
    label_text =pgettext (label )
    try :
        row =layout .row (align =True )
        try :
            row .scale_y =0.95
            row .enabled =bool (active )
        except Exception :
            pass
        split =row .split (factor =0.72 ,align =True )
        left =split .row (align =True )
        left .label (text =label_text )
        right =split .row (align =True )
        try :
            right .alignment ='RIGHT'
            right .use_property_split =False
            right .use_property_decorate =False
        except Exception :
            pass
        if owner is not None and prop_name and hasattr (owner ,prop_name ):
            current =bool (getattr (owner ,prop_name ,False ))
            right.row(align=True) .prop (owner ,prop_name ,text =_ms_enabled_text (current ),toggle =True ,icon ='CHECKBOX_HLT'if current else 'CHECKBOX_DEHLT')
            return True
        if operator_id :
            current =bool (enabled )
            op =right.row(align=True) .operator (operator_id ,text =_ms_enabled_text (current ),icon ='CHECKBOX_HLT'if current else 'CHECKBOX_DEHLT',depress =current )
            try :
                op .alias =str (alias or '')
                op .feature_key =str (feature_key or '')
            except Exception :
                pass
            return True
        disabled_row =right .row (align =True )
        disabled_row .enabled =False
        disabled_row .label (text =_ms_enabled_text (enabled ),icon ='CHECKBOX_HLT'if enabled else 'CHECKBOX_DEHLT')
        return True
    except Exception :
        try :
            layout .label (text =label_text )
        except Exception :
            pass
    return False


def _ms_draw_runtime_bool_toggle (layout ,owner ,prop_name ,label ,icon ='CHECKBOX_HLT',context =None ,active =True ):
    return _ms_draw_always_on_toggle_row (layout ,context ,label ,owner =owner ,prop_name =prop_name ,icon =icon ,active =active )


def _ms_runtime_entry_label (entry ,context ):
    try :
        label_en =str ((entry or {}).get ('label_en')or (entry or {}).get ('label')or '')
        label_ja =str ((entry or {}).get ('label_ja')or label_en )
        return choose_text (label_en ,label_ja ,context =context )
    except Exception :
        return ''


def _ms_runtime_tool_label (entry ,context ):
    try :
        label =str ((entry or {}).get ('tool_label')or (entry or {}).get ('alias')or '')
        if not label :
            return pgettext ('Captured Runtime Features')
        known ={
        'Sms Hub':'Smart Modifier Hub',
        'Sms Precision Tools':'Precision / Layout / Path',
        'Sms Advanced Tools':'Advanced Modeling Tools',
        }
        label =known .get (label ,label )
        return pgettext (label )
    except Exception :
        return pgettext ('Captured Runtime Features')


def _ms_feature_operator_id ():
    try :
        getter =getattr (feature_toggle ,'toggle_operator_id',None )
        if callable (getter ):
            return str (getter ()or '')
        configure =getattr (feature_toggle ,'configure',None )
        if callable (configure ):
            configure (suite_key ='smart_modifier_suite',suite_label ='Smart Modifier',category ='Smart Modifier')
    except Exception :
        pass
    return str (getattr (feature_toggle ,'_OPERATOR_ID','')or 'smart_modifier_suite.toggle_persistent_feature')


def _ms_draw_captured_runtime_toggles (layout ,context )->bool :
    try :
        entries =list (feature_toggle .feature_entries ()or [])
    except Exception :
        entries =[]
    if not entries :
        return False

    op_id =_ms_feature_operator_id ()
    can_toggle =_ms_operator_exists (op_id )
    wm =getattr (context ,'window_manager',None )if context is not None else getattr (getattr (bpy ,'context',None ),'window_manager',None )
    drew =False
    for entry in entries :
        try :
            alias =str ((entry or {}).get ('alias')or '')
            key =str ((entry or {}).get ('key')or '')
        except Exception :
            alias =key =''
        if not alias or not key :
            continue
        tool_label =_ms_runtime_tool_label (entry ,context )
        entry_label =_ms_runtime_entry_label (entry ,context )or pgettext ('Runtime Feature')
        label =f"{tool_label}: {entry_label}" if tool_label else entry_label
        enabled =bool ((entry or {}).get ('enabled'))
        prop_name =str ((entry or {}).get ('property_name')or '')
        try :
            ensure_prop =getattr (feature_toggle ,'ensure_feature_property',None )
            if callable (ensure_prop ):
                prop_name =prop_name or str (ensure_prop (entry ,context =context )or '')
        except Exception :
            prop_name =prop_name or ''
        if wm is not None and prop_name and hasattr (wm ,prop_name ):
            drew =_ms_draw_always_on_toggle_row (layout ,context ,label ,owner =wm ,prop_name =prop_name ,enabled =enabled )or drew
        elif can_toggle :
            drew =_ms_draw_always_on_toggle_row (layout ,context ,label ,operator_id =op_id ,alias =alias ,feature_key =key ,enabled =enabled )or drew
        else :
            drew =_ms_draw_always_on_toggle_row (layout ,context ,label ,enabled =enabled )or drew
    return drew


def _ms_draw_always_on_toggles (layout ,context ):
    wm =getattr (context ,"window_manager",None )
    scene =getattr (context ,"scene",None )
    layout .use_property_split =False 
    layout .use_property_decorate =False 
    col =layout .column (align =True )
    drew =False

    if wm is not None :
        # Keep persistence and list refresh controls in the Always-on Toggles section.
        drew =_ms_draw_runtime_bool_toggle (col ,wm ,"sms_runtime_core_state_persistence",choose_text('N-panel State Save','Nパネル状態保存',context=context),context =context )or drew
        try:
            col.separator(factor=0.5)
        except Exception:
            pass
        for prop_name, label_en, label_ja in (
            ('sms_runtime_stack_live_sync', 'Modifier Stack Live Sync', 'モディファイアスタック ライブ同期'),
        ):
            if hasattr(wm, prop_name):
                drew = _ms_draw_runtime_bool_toggle(
                    col,
                    wm,
                    prop_name,
                    choose_text(label_en, label_ja, context=context),
                    context=context,
                ) or drew
        try:
            if scene is not None and hasattr(scene, 'modswitch_auto_refresh'):
                drew = _ms_draw_runtime_bool_toggle(
                    col,
                    scene,
                    'modswitch_auto_refresh',
                    choose_text('Modifier Management List Update', 'モディファイア管理リスト更新', context=context),
                    context=context,
                ) or drew
        except Exception:
            pass
        # Captured implementation hooks are governed by the fixed feature-level
        # switches above.  Do not expose unstable per-handler rows in the public
        # contract: OFF deactivates every captured hook owned by that feature.
    else :
        col .label (text =pgettext ('Window manager is not available.'),icon='NONE')


    if not drew :
        col .label (text =pgettext ('No always-on features are currently registered.'),icon='NONE')


def _ms_draw_live_runtime (layout ,context ):
    _ms_draw_always_on_toggles (layout ,context )



# -----------------------------------------------------------------------------
# Smart Modeling-style unified section UI
# -----------------------------------------------------------------------------

_MSM_INLINE_SECTION_BODY = False
_MSM_DYNAMIC_SECTION_PREFIX = '_smart_modifier_suite_ui_section_'


def _ms_tag_view3d_ui_redraw():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', []) or []:
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', []) or []:
                if getattr(area, 'type', '') == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _ms_dynamic_section_storage_key(section_key: str) -> str:
    safe = str(section_key or '').strip().replace(' ', '_').replace('-', '_').replace(':', '_').replace('/', '_')
    key = _MSM_DYNAMIC_SECTION_PREFIX + safe
    if len(key) <= 63:
        return key
    # WindowManager IDProperty names are limited to 63 bytes/characters.  Nested
    # child foldouts may use long native panel class names, so compress them with
    # a deterministic small hash instead of silently failing to save the state.
    checksum = 0
    for ch in safe:
        checksum = ((checksum * 131) + ord(ch)) & 0xFFFFFFFF
    short = (safe[:20].rstrip('_') or 'section') + '_' + format(checksum, '08x')
    return (_MSM_DYNAMIC_SECTION_PREFIX + short)[:63]


def _ms_get_section_state(context, section_key: str, default=False) -> bool:
    section_key = str(section_key or '').strip()
    if not section_key:
        return bool(default)
    try:
        prefs = get_preferences(context)
    except Exception:
        prefs = None
    try:
        if prefs is not None and hasattr(prefs, section_key):
            return bool(getattr(prefs, section_key))
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None)
        key = _ms_dynamic_section_storage_key(section_key)
        if wm is not None and key in wm:
            return bool(wm.get(key, default))
    except Exception:
        pass
    return bool(default)


def _ms_set_section_state(context, section_key: str, value) -> None:
    section_key = str(section_key or '').strip()
    if not section_key:
        return
    value = bool(value)
    saved_to_prefs = False
    try:
        prefs = get_preferences(context)
    except Exception:
        prefs = None
    try:
        if prefs is not None and hasattr(prefs, section_key):
            if bool(getattr(prefs, section_key)) != value:
                setattr(prefs, section_key, value)
            saved_to_prefs = True
    except Exception:
        saved_to_prefs = False
    if not saved_to_prefs:
        try:
            wm = getattr(context, 'window_manager', None)
            if wm is not None:
                wm[_ms_dynamic_section_storage_key(section_key)] = value
        except Exception:
            pass
    try:
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass
    _ms_tag_view3d_ui_redraw()


class SMSM_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'smart_modifier_suite.toggle_ui_section'
    bl_label = 'Toggle UI Section'
    bl_description = 'Open or close this Smart Modifier section.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    section_key: StringProperty(options={'SKIP_SAVE'})
    label: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'section_key', '') or '').strip()
        if label:
            return choose_text(
                f'Open or close the {label} section.',
                f'{label} セクションを開閉します。',
                context=context,
            )
        return choose_text('Open or close this section.', 'このセクションを開閉します。', context=context)

    def execute(self, context):
        key = str(self.section_key or '').strip()
        if not key:
            return {'CANCELLED'}
        current = _ms_get_section_state(context, key, False)
        _ms_set_section_state(context, key, not current)
        return {'FINISHED'}


class _MSMFakePanelSelf:
    def __init__(self, layout):
        self.layout = layout


def _ms_call_panel_draw_body(panel_cls, layout, context):
    """Draw a registered panel body inside a unified section.

    Only the panel's own first/top help header is suppressed so the section title
    appears once in the Smart Modeling-style row.  Subsection headers inside the
    body remain visible.
    """
    if panel_cls is None:
        return False
    module = sys.modules.get(str(getattr(panel_cls, '__module__', '') or ''))
    had_header = False
    old_header = None
    global _MSM_INLINE_SECTION_BODY
    old_inline = _MSM_INLINE_SECTION_BODY
    panel_label = str(getattr(panel_cls, 'bl_label', '') or '').strip()
    alternate_skip_labels = {
        panel_label,
        'Precision / Layout' if panel_label.startswith('Precision') else '',
    }
    skipped_once = {'done': False}

    def _section_body_header(layout_arg, context_arg, label_arg, icon_arg, help_id_arg, **kwargs):
        label_text = str(label_arg or '').strip()
        if not skipped_once['done'] and label_text in alternate_skip_labels:
            skipped_once['done'] = True
            return None
        try:
            return old_header(layout_arg, context_arg, label_arg, icon_arg, help_id_arg, **kwargs)
        except Exception:
            return None

    try:
        try:
            poll = getattr(panel_cls, 'poll', None)
            # When the original child panel poll was replaced by the unified-root
            # wrapper, ignore it; otherwise respect real poll failures.
            if callable(poll) and getattr(poll, '__func__', None) is not _ms_root_only_child_panel_poll:
                if not bool(poll(context)):
                    return False
        except Exception:
            return False
        if module is not None and hasattr(module, 'draw_help_header'):
            had_header = True
            old_header = getattr(module, 'draw_help_header')
            setattr(module, 'draw_help_header', _section_body_header)
        _MSM_INLINE_SECTION_BODY = True
        panel_cls.draw(_MSMFakePanelSelf(layout), context)
        return True
    finally:
        _MSM_INLINE_SECTION_BODY = old_inline
        if had_header and module is not None:
            try:
                setattr(module, 'draw_help_header', old_header)
            except Exception:
                pass


def _ms_import_panel_class(module_suffix: str, class_name: str):
    try:
        module = importlib.import_module('.' + str(module_suffix).strip('.'), __package__)
        return getattr(module, class_name, None)
    except Exception:
        return None


def _ms_section_label(text_value: str, context=None) -> str:
    raw = str(text_value or '')
    normalized = raw.replace('Always-' + 'On', 'Always-on')
    if normalized in {'Always-on Toggles', 'Always-on Toggle'}:
        return choose_text('Always-on Toggles', '常時機能切り替え', context=context)
    return pgettext(raw, context=context)


def _ms_section_icon_operator(layout, section_key: str, label: str, icon_name: str, fallback_icon: str, expanded: bool):
    icon_id = 0
    try:
        icon_id = int(_sms_icon_value(icon_name, fallback_icon) or 0)
    except Exception:
        icon_id = 0
    kwargs = {'text': _ms_section_label(label), 'emboss': False, 'depress': bool(expanded)}
    if icon_id:
        kwargs['icon_value'] = icon_id
    elif fallback_icon and fallback_icon != 'NONE':
        kwargs['icon'] = fallback_icon
    try:
        op = layout.operator('smart_modifier_suite.toggle_ui_section', **kwargs)
    except Exception:
        kwargs.pop('icon_value', None)
        kwargs.pop('icon', None)
        op = layout.operator('smart_modifier_suite.toggle_ui_section', **kwargs)
    op.section_key = str(section_key)
    op.label = _ms_section_label(label)
    return op


def _ms_unified_section_body_allowed(context, section_key: str) -> bool:
    """Keep unified section bodies visible on every redraw.

    Older builds temporarily returned ``False`` during mode/context transition
    windows.  That made the section headers stay visible while the body controls
    were omitted for one or more redraws, which is perceived as N-panel flicker
    during viewport orbit/pan/zoom and Smart Tools Manager proxy refreshes.  The
    body draw functions are already individually guarded, and failure cases are
    rendered as stable warning rows by ``_ms_draw_unified_section``.  Therefore
    the unified root must not hide bodies from this central gate.
    """
    del context, section_key
    return True


def _ms_draw_unified_section(layout, context, *, section_key: str, label: str, icon_name: str = '', fallback_icon: str = 'TOOL_SETTINGS', help_topic: str = '', default_open: bool = False, draw_body=None):
    box = layout.box()
    try:
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        pass
    expanded = _ms_get_section_state(context, section_key, default_open)
    row = box.row(align=True)
    op = row.operator(
        'smart_modifier_suite.toggle_ui_section',
        text='',
        icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
        emboss=True,
        depress=bool(expanded),
    )
    op.section_key = str(section_key)
    op.label = _ms_section_label(label)
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    _ms_section_icon_operator(row, section_key, label, icon_name, fallback_icon, expanded)
    try:
        if help_topic:
            try:
                row.separator(factor=0.35)
            except Exception:
                pass
            draw_help_button(row, help_topic, context=context)
    except Exception:
        pass
    if expanded and callable(draw_body) and _ms_unified_section_body_allowed(context, section_key):
        body = box.column(align=False)
        try:
            body.use_property_split = False
            body.use_property_decorate = False
        except Exception:
            pass
        try:
            draw_body(body, context)
        except Exception as exc:
            warn = body.box()
            warn.alert = True
            warn.label(text=choose_text('Could not draw this section.', 'このセクションを描画できません。', context=context), icon='ERROR')
            warn.label(
                text=pgettext(
                    'Error details: {detail}',
                    context=context,
                ).format(detail=str(exc)[:180]),
                icon='ERROR',
            )
    return box


def _ms_draw_always_on_unified_body(layout, context):
    _ms_draw_always_on_toggles(layout, context)
    _ms_request_panel_state_save(context)


def _ms_draw_settings_unified_body(layout, context):
    draw_smart_tools_preferences(layout, context)
    _ms_request_panel_state_save(context)


def _ms_draw_panel_unified_body(panel_cls):
    def _draw(layout, context):
        if panel_cls is not None:
            _ms_call_panel_draw_body(panel_cls, layout, context)
    return _draw


def _ms_draw_deferred_panel_unified_body(module_suffix: str, class_name: str):
    def _draw(layout, context):
        panel_cls = _ms_import_panel_class(module_suffix, class_name)
        if panel_cls is None:
            layout.label(text=choose_text('This section is not available.', 'このセクションは利用できません。', context=context), icon='NONE')
            return
        _ms_call_panel_draw_body(panel_cls, layout, context)
    return _draw


def _ms_draw_smart_modifier_unified_sections(layout, context):
    _ms_draw_unified_section(
        layout,
        context,
        # Use the canonical persisted foldout property shared with the legacy
        # panel and unified contract; keeping two independent booleans made the
        # heading open while its controls stayed hidden.
        section_key='show_always_on_toggles',
        label='Always-on Toggles',
        icon_name='TIME',
        fallback_icon='TIME',
        help_topic='always_on',
        default_open=False,
        draw_body=_ms_draw_always_on_unified_body,
    )
    _ms_draw_unified_section(
        layout,
        context,
        section_key='ui_section_modifier_stack',
        label='Modifier Stack',
        icon_name='modifier',
        fallback_icon='MODIFIER',
        help_topic='modifier_stack',
        default_open=True,
        draw_body=_ms_draw_panel_unified_body(VIEW3D_PT_modifier_stack_panel),
    )
    _ms_draw_unified_section(
        layout,
        context,
        section_key='ui_section_modifier_switcher',
        label='Modifier Management',
        icon_name='MODIFIER',
        fallback_icon='MODIFIER',
        help_topic='modifier_switcher',
        default_open=False,
        draw_body=_ms_draw_panel_unified_body(VIEW3D_PT_ms_modswitcher_main),
    )
    _ms_draw_unified_section(
        layout,
        context,
        section_key='ui_section_settings',
        label='Settings',
        icon_name='PREFERENCES',
        fallback_icon='PREFERENCES',
        help_topic='settings',
        default_open=False,
        draw_body=_ms_draw_settings_unified_body,
    )


def _ms_root_only_child_panel_poll(cls, context):
    # Child panels are rendered inside the unified root panel sections.  Returning
    # False here prevents duplicated Blender child-panel headers while keeping the
    # original draw methods available to the root section renderer.
    return False


_SMS_DUPLICATE_CHILD_PANEL_IDS = (
    'VIEW3D_PT_ms_settings_panel',
    'VIEW3D_PT_modifier_stack_panel',
    'VIEW3D_PT_ms_modswitcher_main',
    'VIEW3D_PT_ms_tool_catalog_panel',
    # The following panels were previously mirrored as top-level unified root
    # sections.  They are no longer valid top-level Smart Modifier sections and
    # must stay hidden if older sessions or deferred modules register them.
    'VIEW3D_PT_msm_hub',
    'VIEW3D_PT_msm_hub_help',
    'SMSP_PT_precision_layout',
    'SMSP_PT_precision_guide',
    'VIEW3D_PT_sms_advanced',
    'VIEW3D_PT_sms_advanced_help',
    'VIEW3D_PT_sms_preflight',
    'VIEW3D_PT_sms_catalog_browser',
)


def _ms_hide_registered_duplicate_child_panels(context=None):
    """Hide legacy registered child panels that duplicate unified sections.

    Older builds registered these classes as Blender child panels under the root
    panel.  The current UI draws their bodies manually inside Smart
    Modeling-style root sections, so leaving the registered child panels visible
    creates the duplicate lower ">" rows shown in the sidebar.  Do not
    unregister those classes in a live session because Blender 5.1 can keep C++
    panel blocks alive; instead, patch their poll callbacks to return False.
    """
    del context
    try:
        target_ids = set(_SMS_DUPLICATE_CHILD_PANEL_IDS)
        for name in tuple(dir(getattr(bpy, 'types', object()))):
            try:
                cls = getattr(bpy.types, name, None)
            except Exception:
                continue
            if not isinstance(cls, type):
                continue
            try:
                bl_idname = str(getattr(cls, 'bl_idname', '') or '')
                class_name = str(getattr(cls, '__name__', '') or name)
            except Exception:
                continue
            if bl_idname not in target_ids and class_name not in target_ids:
                continue
            try:
                cls.poll = classmethod(_ms_root_only_child_panel_poll)
                cls._smart_modifier_suite_hidden_duplicate_child_panel = True
            except Exception:
                pass
    except Exception:
        pass
    return None


def _sms_panel_identifier_set(panel_cls):
    identifiers = set()
    for attr_name in ('__name__', 'bl_idname'):
        try:
            value = str(getattr(panel_cls, attr_name, '') or '').strip()
        except Exception:
            value = ''
        if value:
            identifiers.add(value)
    return identifiers


def _sms_proxy_source_identifier(panel_cls):
    try:
        source = getattr(panel_cls, '_smart_tools_manager_source', None)
    except Exception:
        source = None
    if source is None:
        return ''
    for attr_name in ('bl_idname', '__name__'):
        try:
            value = str(getattr(source, attr_name, '') or '').strip()
        except Exception:
            value = ''
        if value:
            return value
    return ''


def _ms_hide_duplicate_smart_modifier_root_panels(context=None):
    """Hide retired multi-editor source panels and their Manager proxies.

    Smart Tools Manager creates one proxy per source Panel and target editor.
    Registering a native Smart Modifier root panel in every editor lets the
    manager mirror every root into every other editor, producing stacked
    duplicate Smart Modifier groups in one sidebar. Keep only the canonical
    VIEW_3D root as the source panel; Manager may proxy that single source to
    other editors. Retired same-content roots and proxies based on them are
    hidden by poll=False instead of unregistering, because Blender can keep live
    C-side panel references during N-panel redraw.
    """
    del context
    retired = set(_SMS_RETIRED_CROSS_EDITOR_ROOT_PANEL_IDS)
    canonical = _SMS_CANONICAL_ROOT_PANEL_ID
    try:
        panel_names = tuple(dir(getattr(bpy, 'types', object())))
    except Exception:
        panel_names = ()
    for name in panel_names:
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            cls = None
        if cls is None or not isinstance(cls, type):
            continue
        hide_panel = False
        retired_source = False
        stale_proxy = False
        try:
            identifiers = _sms_panel_identifier_set(cls)
            if identifiers.intersection(retired):
                retired_source = True
                hide_panel = True
            elif bool(getattr(cls, '_smart_tools_manager_proxy', False)):
                proxy_tool_key = str(getattr(cls, '_smart_tools_manager_tool_key', '') or '').strip()
                source_id = _sms_proxy_source_identifier(cls)
                if proxy_tool_key == 'SMART_MODIFIER':
                    stale_proxy = bool(not source_id or source_id != canonical)
                    hide_panel = stale_proxy
                elif source_id in retired:
                    stale_proxy = True
                    hide_panel = True
        except Exception:
            hide_panel = False
        if not hide_panel:
            continue
        try:
            setattr(cls, '_smart_modifier_suite_hidden_duplicate_root_panel', True)
        except Exception:
            pass
        if retired_source:
            # Prevent Smart Tools Manager from treating retired same-content native
            # roots as additional Smart Modifier proxy sources in later refreshes.
            try:
                cls.bl_category = '_Smart Modifier Retired'
            except Exception:
                pass
            try:
                cls.__module__ = '_smart_modifier_suite_retired_panel'
            except Exception:
                pass
        if stale_proxy:
            # Make already-registered duplicate Manager proxies permanently inert
            # unless the Manager recreates metadata for the canonical source.
            try:
                setattr(cls, '_smart_tools_manager_tool_key', '')
            except Exception:
                pass
            try:
                setattr(cls, '_smart_tools_manager_source', None)
            except Exception:
                pass
            try:
                cls.bl_category = '_Smart Modifier Retired'
            except Exception:
                pass
        try:
            cls.poll = classmethod(_ms_root_only_child_panel_poll)
        except Exception:
            pass
    return None


def _ms_hide_registered_duplicate_smart_modifier_panels(context=None):
    try:
        _ms_hide_registered_duplicate_child_panels(context)
    except Exception:
        pass
    try:
        _ms_hide_duplicate_smart_modifier_root_panels(context)
    except Exception:
        pass
    return None


def _ms_schedule_hide_duplicate_child_panels():
    try:
        _ms_hide_registered_duplicate_smart_modifier_panels(getattr(bpy, 'context', None))
    except Exception:
        pass
    # Registration is deterministic now; one synchronous ownership pass is
    # sufficient and avoids three delayed timers in an otherwise idle suite.
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_ms_hide_registered_duplicate_smart_modifier_panels):
            timers.unregister(_ms_hide_registered_duplicate_smart_modifier_panels)
    except Exception:
        pass





def _sms_draw_root_panel_body (panel_self ,context ):
    layout =panel_self .layout
    try:
        layout .use_property_split =False
        layout .use_property_decorate =False
    except Exception:
        pass
    _ms_draw_smart_modifier_unified_sections (layout ,context )


def _sms_make_cross_editor_root_panel_class (class_name ,space_type ,description_suffix ):
    @classmethod
    def _poll (cls ,context ):
        return _ms_is_view3d_ui_context (context )

    def _draw (self ,context ):
        _sms_draw_root_panel_body (self ,context )

    attrs ={
        '__module__':__name__,
        'bl_space_type':space_type,
        'bl_region_type':'UI',
        'bl_category':'Smart Modifier',
        'bl_label':'Smart Modifier',
        'bl_idname':class_name,
        'bl_order':0,
        'bl_description':'Root group that contains every Smart Modifier N-panel tool. Smart Tools Manager can place this panel in ' + str (description_suffix or space_type) + '.',
        'poll':_poll,
        'draw':_draw,
    }
    return type (class_name ,(bpy .types .Panel ,),attrs )


_SMS_CROSS_EDITOR_ROOT_PANEL_SPECS = (
    ('IMAGE_PT_smart_modifier_root_panel','IMAGE_EDITOR','Image Editor / UV Editor'),
    ('NODE_PT_smart_modifier_root_panel','NODE_EDITOR','Shader / Compositor / Geometry Node / Texture Node editors'),
    ('SEQUENCER_PT_smart_modifier_root_panel','SEQUENCE_EDITOR','Video Sequencer'),
    ('CLIP_PT_smart_modifier_root_panel','CLIP_EDITOR','Movie Clip Editor'),
    ('DOPESHEET_PT_smart_modifier_root_panel','DOPESHEET_EDITOR','Dope Sheet'),
    ('GRAPH_PT_smart_modifier_root_panel','GRAPH_EDITOR','Graph Editor / Drivers'),
    ('NLA_PT_smart_modifier_root_panel','NLA_EDITOR','Nonlinear Animation'),
    ('TEXT_PT_smart_modifier_root_panel','TEXT_EDITOR','Text Editor'),
    ('FILEBROWSER_PT_smart_modifier_root_panel','FILE_BROWSER','File Browser / Asset Browser'),
    ('SPREADSHEET_PT_smart_modifier_root_panel','SPREADSHEET','Spreadsheet'),
)
# Specification only. Register exactly one native Smart Modifier root panel and
# let Smart Tools Manager proxy that single source into the requested editor.
# Registering a real root in every editor makes the manager clone every root into
# every other editor, which duplicates the complete N-panel stack.
SMS_CROSS_EDITOR_ROOT_PANEL_CLASSES =()


class VIEW3D_PT_smart_modifier_root_panel (bpy .types .Panel ):
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'modifier_stack_properties', context=context)

    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_label ='Smart Modifier'
    bl_idname ="VIEW3D_PT_smart_modifier_root_panel"
    bl_order =0

    @classmethod
    def poll (cls ,context ):
        return _ms_is_view3d_ui_context (context )

    def draw (self ,context ):
        _sms_draw_root_panel_body (self ,context )


class VIEW3D_PT_ms_settings_panel (bpy .types .Panel ):
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_label ='Settings'
    bl_idname ="VIEW3D_PT_ms_settings_panel"
    bl_order =30

    @classmethod
    def poll (cls ,context ):
        return _ms_is_view3d_ui_context (context )

    def draw (self ,context ):
        layout =self .layout
        draw_help_header (layout ,context ,'Settings','PREFERENCES','settings')
        draw_smart_tools_preferences (layout ,context )
        _ms_request_panel_state_save (context )



class VIEW3D_PT_modifier_stack_panel (bpy .types .Panel ):
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_label ="Modifier Stack"
    bl_order =10 
    @classmethod 
    def poll (cls ,context ):
        if not _ms_is_view3d_ui_context (context ):
            return False
        try :
            prefs =get_preferences (context )
            if hasattr (prefs ,"use_modifier_stack")and not prefs .use_modifier_stack :
                return False 
        except Exception :
            pass 
        return _ms_context_has_safe_stack_main (context )

    def draw (self ,context ):
        layout =self .layout 
        main_obj =_ms_context_main_mesh_for_panel (context ,allow_edit_helper =True ,require_selected_object_mode =True )
        if not _ms_object_is_live (main_obj ):
            layout .label (text =pgettext (_ms_stack_panel_empty_message (context )),icon='NONE')
            return 
        # Panel.draw is strictly read-only.  End-result preview lifetime is
        # driven by the explicit Show End Result update callback and edit-mode
        # events, never by sidebar redraw frequency.
        try:
            stack_obj =ms_get_modifier_stack_object (main_obj ,context =context ,create =False )or main_obj
        except Exception:
            stack_obj =main_obj
        draw_help_header (layout ,context ,'Modifier Stack','modifier','modifier_stack')
        _ms_request_panel_state_save (context )

        selected_mains =ms_get_selected_main_meshes (context )
        is_multi =(len (selected_mains )>1 )
        active_ui_id =main_obj .get ("ui_active_item","BASE")
        effective_active_id =ms_get_effective_active_id (main_obj ,active_ui_id )
        active_idx =stack_obj .modifiers .find (effective_active_id )if (effective_active_id !="BASE"and ms_object_has_modifier_collection (stack_obj ))else -1 

        prefs =get_preferences (context )
        order =prefs .stack_order if prefs and hasattr (prefs ,"stack_order")else 'TOP_DOWN'

        is_end =bool (getattr (main_obj ,"ms_show_end_result",False ))if getattr (main_obj ,'type','')=='MESH'else False
        auto_disable_modifiers =bool (ms_auto_disable_modifiers_enabled (main_obj ))if getattr (main_obj ,'type','')=='MESH'else False
        active_mod_for_actions =_sms_active_modifier_for_stack (main_obj ,stack_obj ,active_ui_id )
        _sms_draw_stack_header (layout ,context ,main_obj ,stack_obj ,active_mod_for_actions ,is_multi ,selected_mains ,auto_disable_modifiers ,is_end )

        list_box =layout .box ()
        list_col =list_box .column (align =True )

        selected_stack_objs =[]
        common_instance_ids =set ()
        if is_multi :
            try :
                _seen_stack =set ()
                for o in selected_mains :
                    try:_stack_o =ms_get_modifier_stack_object (o ,context =context ,create =False )or o
                    except Exception:_stack_o =o
                    try:_name =str (getattr (_stack_o ,'name','')or '')
                    except Exception:_name =''
                    if _stack_o is not None and _name and _name not in _seen_stack:
                        _seen_stack .add (_name )
                        selected_stack_objs .append (_stack_o )
                id_sets =[]
                for _stack_o in selected_stack_objs :
                    s =set ()
                    for m in ms_get_object_modifiers (_stack_o ):
                        try :iid =ms_get_instance_id (m ,_stack_o )
                        except Exception :iid =None 
                        if iid :s .add (str (iid ))
                    id_sets .append (s )
                common_instance_ids =set .intersection (*id_sets )if id_sets else set ()
            except Exception :
                selected_stack_objs =[]
                common_instance_ids =set ()

        def _ms_stack_row_is_auto_suppressed (internal_index):
            try:
                if not bool (auto_disable_modifiers):
                    return False
                if effective_active_id =="BASE":
                    return True
                return int (internal_index )>int (active_idx )
            except Exception:
                return False

        def _ms_draw_stack_display_icons (row ,obj ,mod ,internal_index):
            try:
                is_enabled =bool (get_mod_enabled_state (obj ,mod .name ))
            except Exception:
                is_enabled =True
            # A live row reports what the modifier is doing right now. A modifier
            # added outside Smart Modifier stays live below the selected row until
            # the next level switch, so the row position alone must not draw it off.
            # A row Auto Disable is holding OFF is drawn faded with the state it
            # returns to, which is what pressing its icon changes.
            effective_vp =bool (ms_mod_display_row_state (obj ,mod ,'vp'))
            effective_render =bool (ms_mod_display_row_state (obj ,mod ,'render'))
            effective_edit =bool (ms_mod_display_row_state (obj ,mod ,'edit'))
            effective_cage =bool (ms_mod_display_row_state (obj ,mod ,'cage'))
            auto_suppressed =bool (_ms_stack_row_is_auto_suppressed (internal_index )and not getattr (mod ,"show_viewport",True ))

            icon_row =row

            # On Cage: follows Blender header semantics. Always draw the icon so
            # there is no blank leading slot and the gauge button remains visible.
            sub =icon_row .row (align =True )
            if hasattr (mod ,"show_on_cage"):
                try:
                    sub .active =bool (effective_vp and effective_edit and not auto_suppressed )
                except Exception:
                    pass
                op =_sms_icon_operator (sub ,"object.ms_toggle_modifier_display_flag",text ="",icon_name ='cage',fallback_icon ='MESH_DATA',depress =effective_cage )
                op .modifier_name =mod .name ;op .target_obj_name =obj .name ;op .flag_name ="show_on_cage"
            else:
                try:
                    sub .enabled =False
                except Exception:
                    pass
                sub .label (text ="",icon ='MESH_DATA')

            sub =icon_row .row (align =True )
            if hasattr (mod ,"show_in_editmode"):
                try:
                    sub .active =bool (effective_vp and not auto_suppressed )
                except Exception:
                    pass
                op =_sms_icon_operator (sub ,"object.ms_toggle_modifier_display_flag",text ="",icon_name ='edit',fallback_icon ='EDITMODE_HLT',depress =effective_edit )
                op .modifier_name =mod .name ;op .target_obj_name =obj .name ;op .flag_name ="show_in_editmode"
            else:
                try:
                    sub .enabled =False
                except Exception:
                    pass
                sub .label (text ="",icon ='EDITMODE_HLT')

            sub =icon_row .row (align =True )
            try:
                sub .active =bool (is_enabled and not auto_suppressed )
            except Exception:
                pass
            op =_sms_icon_operator (sub ,"object.ms_toggle_viewport_state",text ="",icon_name ='visible_on'if effective_vp else 'visible_off',fallback_icon ='RESTRICT_VIEW_OFF',depress =bool (effective_vp ))
            op .modifier_name =mod .name ;op .target_obj_name =obj .name

            sub =icon_row .row (align =True )
            if hasattr (mod ,"show_render"):
                try:
                    sub .active =bool (is_enabled and not auto_suppressed )
                except Exception:
                    pass
                op =_sms_icon_operator (sub ,"object.ms_toggle_modifier_display_flag",text ="",icon_name ='render_on'if effective_render else 'render_off',fallback_icon ='RESTRICT_RENDER_OFF',depress =bool (effective_render ))
                op .modifier_name =mod .name ;op .target_obj_name =obj .name ;op .flag_name ="show_render"
            else:
                try:
                    sub .enabled =False
                except Exception:
                    pass
                sub .label (text ="",icon ='RESTRICT_RENDER_OFF')

        def draw_mod_row (col ,mod ,obj ,is_instance =False ,ui_row_index =-1 ,internal_index =-1 ):
            if not _ms_modifier_is_live_on_object (obj ,mod ):
                return
            disp_name =ms_obj_get_disp_name (obj ,mod .name )or mod .name 
            is_selected =(active_ui_id ==mod .name )
            if is_selected:
                row_holder =col .box ()
                row =_sms_large_icon_row (row_holder ,align =True ,scale_y =1.08 )
            else:
                row =_sms_large_icon_row (col ,align =True ,scale_y =1.08 )

            try:
                if not is_instance:
                    gid =ms_get_object_instance_id (obj )
                    if gid:
                        members =ms_get_object_instance_members (obj ,context )
                        is_instance =bool (len ([m for m in members if m is not None])>1 )
            except Exception:
                pass
            if is_instance:
                # Base Object row style: modifier-type icon, LINKED, then the name.
                op_icon =_sms_icon_operator (row ,"object.ms_switch_level",text ="",icon_name =_sms_stack_modifier_icon (mod ),fallback_icon =_sms_stack_modifier_icon (mod ),depress =is_selected )
                op_icon .target_mod_name =mod .name ;op_icon .target_obj_name =obj .name
                try :op_icon .ui_row_index =int (ui_row_index )
                except Exception :pass
                try:
                    _sms_icon_label(row, text='', icon_name='', fallback_icon='LINKED')
                except Exception:
                    row.label(text='', icon='LINKED')
                _name_fallback_icon ='NONE'
            else:
                _name_fallback_icon =_sms_stack_modifier_icon (mod )
            op_select =_sms_icon_operator (row ,"object.ms_switch_level",text =ms_modifier_row_display_name (disp_name ,context =context ),icon_name ='',fallback_icon =_name_fallback_icon ,depress =is_selected ,translate =False )
            op_select .target_mod_name =mod .name ;op_select .target_obj_name =obj .name
            try :op_select .ui_row_index =int (ui_row_index )
            except Exception :pass

            _ms_draw_stack_display_icons (row ,obj ,mod ,internal_index )
            row_menu =row .row (align =True )
            row_menu .operator_context ='INVOKE_DEFAULT'
            op_menu =_sms_icon_operator (row_menu ,"object.ms_item_menu_call",text ="",icon_name ='menu',fallback_icon ='TRIA_DOWN',emboss =False )
            op_menu .modifier_name =mod .name ;op_menu .target_obj_name =obj .name
            # The one properties-display control below the stack owns all row
            # property visibility. Compact rows never duplicate a body.

        def draw_base_row (row ,obj ,ui_row_index =-1 ):
            is_base_selected =(active_ui_id =="BASE")
            base_is_instance =False
            try:
                base_is_instance =bool (ms_object_has_linked_base_instance (obj ,context ))
            except Exception:
                base_is_instance =False
            if base_is_instance:
                op_icon =_sms_icon_operator (row ,"object.ms_switch_level",text ="",icon_name ='MESH_CUBE',fallback_icon ='MESH_CUBE',depress =is_base_selected )
                op_icon .target_mod_name ="BASE";op_icon .target_obj_name =obj .name
                try :op_icon .ui_row_index =int (ui_row_index )
                except Exception :pass
                op_select =_sms_icon_operator (row ,"object.ms_switch_level",text =pgettext ("Base Object"),icon_name ='',fallback_icon ='LINKED',depress =is_base_selected )
            else:
                op_select =_sms_icon_operator (row ,"object.ms_switch_level",text =pgettext ("Base Object"),icon_name ='MESH_CUBE',fallback_icon ='MESH_CUBE',depress =is_base_selected )
            op_select .target_mod_name ="BASE";op_select .target_obj_name =obj .name 
            try :op_select .ui_row_index =int (ui_row_index )
            except Exception :pass 
            row_menu =row .row (align =True )
            row_menu .operator_context ='INVOKE_DEFAULT'
            op_menu =_sms_icon_operator (row_menu ,"object.ms_base_menu_call",text ="",icon_name ='menu',fallback_icon ='TRIA_DOWN',emboss =False )
            op_menu .target_obj_name =obj .name 

        if order =='BOTTOM_UP':
            if is_multi :
                for _i ,mod in enumerate (reversed (list (ms_get_object_modifiers (stack_obj )))):
                    try :iid =ms_get_instance_id (mod ,stack_obj )
                    except Exception :iid =None 
                    if iid and str (iid )in common_instance_ids :
                        draw_mod_row (list_col ,mod ,stack_obj ,is_instance =True ,ui_row_index =_i ,internal_index =stack_obj .modifiers .find (mod .name ))
            else :
                for _i ,mod in enumerate (reversed (list (ms_get_object_modifiers (stack_obj )))):
                    draw_mod_row (list_col ,mod ,stack_obj ,is_instance =ms_is_instance_modifier (mod ,stack_obj ),ui_row_index =_i ,internal_index =stack_obj .modifiers .find (mod .name ))

            if active_ui_id =="BASE":
                _base_holder =list_col .box ()
                row =_sms_large_icon_row (_base_holder ,align =True ,scale_y =1.08 )
            else:
                row =_sms_large_icon_row (list_col ,align =True ,scale_y =1.08 )
            try :_base_ui_row_index =len (list (ms_get_object_modifiers (stack_obj )))
            except Exception :_base_ui_row_index =-1
            draw_base_row (row ,main_obj ,_base_ui_row_index )
        else :
            if active_ui_id =="BASE":
                _base_holder =list_col .box ()
                row =_sms_large_icon_row (_base_holder ,align =True ,scale_y =1.08 )
            else:
                row =_sms_large_icon_row (list_col ,align =True ,scale_y =1.08 )
            draw_base_row (row ,main_obj ,-1 )

            if is_multi :
                for _i ,mod in enumerate (list (ms_get_object_modifiers (stack_obj ))):
                    try :iid =ms_get_instance_id (mod ,stack_obj )
                    except Exception :iid =None 
                    if iid and str (iid )in common_instance_ids :
                        draw_mod_row (list_col ,mod ,stack_obj ,is_instance =True ,ui_row_index =_i ,internal_index =stack_obj .modifiers .find (mod .name ) )
            else :
                for _i ,mod in enumerate (list (ms_get_object_modifiers (stack_obj ))):
                    draw_mod_row (list_col ,mod ,stack_obj ,is_instance =ms_is_instance_modifier (mod ,stack_obj ),ui_row_index =_i ,internal_index =stack_obj .modifiers .find (mod .name ) )

        can_show_props =False 
        active_mod =None 
        show_props_minimal =False 
        if active_ui_id =="BASE":
            can_show_props =True
        elif ms_object_has_modifier_collection (stack_obj ):
            active_mod =stack_obj .modifiers .get (active_ui_id )
            if active_mod and _ms_modifier_is_live_on_object (stack_obj ,active_mod ):
            # Normally, plugin modifiers can suppress the default properties UI.
            # However, EditPoly should still show the standard visibility toggles (cage/edit/realtime/render).
                if ms_should_suppress_properties (active_mod ):
                    p =ms_find_plugin_for_modifier (active_mod )
                    if p and p .get ("id")=="edit_poly":
                        show_props_minimal =True 
                        if not is_multi :can_show_props =True 
                        else :
                            try :iid =ms_get_instance_id (active_mod ,stack_obj )
                            except Exception :iid =None 
                            can_show_props =bool (iid and str (iid )in common_instance_ids )
                else :
                    if not is_multi :can_show_props =True 
                    else :
                        try :iid =ms_get_instance_id (active_mod ,stack_obj )
                        except Exception :iid =None 
                        can_show_props =bool (iid and str (iid )in common_instance_ids )
        if can_show_props :
            row_prop ,prop_body =layout .panel_prop (main_obj ,"ms_show_properties")
            row_prop .label (text =pgettext ('Property Items Display'))
            try :
                help_part =row_prop .row (align =True )
                help_part .alignment ='RIGHT'
                draw_help_button (help_part ,'modifier_stack_properties',context =context )
            except Exception :
                pass
            if prop_body is not None :
                prop_col =prop_body .column (align =True )
                if active_ui_id =="BASE":
                    draw_base_object_data_properties (prop_col ,context ,main_obj )
                elif active_mod:
                    draw_modifier_properties (prop_col ,context ,stack_obj ,active_mod ,minimal =bool (show_props_minimal ))
                    _ms_draw_migrated_user_tool_defaults (prop_col ,context ,active_mod ,stack_obj )


        try :
            has_edit_poly =False 
            active_is_edit_poly =False 
            for _mod in ms_get_object_modifiers (stack_obj ):
                _plugin =ms_find_plugin_for_modifier (_mod )
                if not _plugin or str (_plugin .get ("id")or "")!="edit_poly":
                    continue 
                has_edit_poly =True 
                if str (_mod .name )==str (active_ui_id ):
                    active_is_edit_poly =True 
            if has_edit_poly and (_ms_operator_exists ("ep.rebake_all")or _ms_operator_exists ("ep.switch_level_hijack")):
                def _draw_edit_poly_maintenance (_body):
                    if _ms_operator_exists ("ep.rebake_all"):
                        _body .operator ("ep.rebake_all",icon ='FILE_REFRESH')
                    if active_is_edit_poly and _ms_operator_exists ("ep.switch_level_hijack"):
                        op =_body .operator ("ep.switch_level_hijack",icon ='UV_SYNC_SELECT')
                        op .target_mod_name =str (active_ui_id or "")
                _ms_draw_child_section (
                    layout ,context ,_ms_child_section_key ('maintenance','edit_poly'),
                    pgettext ('Edit Polygon Maintenance'),icon ='FILE_REFRESH',default_open =False,draw_body =_draw_edit_poly_maintenance,
                    help_topic ='edit_poly_maintenance',
                )
        except Exception :
            pass 


            # ============================================================
            # Embedded: Modifier Switcher (compact, collapsible sections)
            # ============================================================

class VIEW3D_PT_ms_modswitcher_main (bpy .types .Panel ):
    bl_label ='Modifier Management'
    bl_idname ="VIEW3D_PT_ms_modswitcher_main"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}
    bl_order =20 
    # Keep this tool as a separate root section placed below Modifier Stack.

    @classmethod 
    def poll (cls ,context ):
        if not _ms_is_view3d_ui_context (context ):
            return False
        try :
            prefs =get_preferences (context )
            if hasattr (prefs ,'use_modifier_switcher')and not bool (prefs .use_modifier_switcher ):
                return False
        except Exception :
            pass
        try :
            scene =getattr (context ,'scene',None )
            required =(
            'modswitch_targets',
            'modswitch_objects',
            'modswitch_state_sets',
            'modswitch_ui_show_modlist',
            )
            if scene is None or not all (hasattr (scene ,name )for name in required ):
                return False 
            return True
        except Exception :
            return False 

    def draw (self ,context ):
        pgettext =locale_pgettext_iface 
        layout =self .layout 
        draw_help_header (layout ,context ,'Modifier Management','switcher','modifier_switcher')
        _ms_request_panel_state_save (context )
        layout .use_property_split =False 
        layout .use_property_decorate =False 
        scene =context .scene 

        # List rebuilding performs object/modifier scans and mutates Scene
        # collections.  It is intentionally limited to the explicit Refresh
        # operator or the canonical Auto Refresh runtime while that toggle is
        # enabled; drawing this panel only displays the latest snapshot.

        row = layout.row(align=True)
        try:
            op = row.operator('modswitch.set_manage_mode', text=choose_text('Object', 'オブジェクト', context=context), icon='OBJECT_DATA', depress=(str(getattr(scene, 'modswitch_manage_mode', 'OBJECT')) == 'OBJECT'))
            op.mode = 'OBJECT'
            op = row.operator('modswitch.set_manage_mode', text=choose_text('Modifier', 'モディファイア', context=context), icon='MODIFIER', depress=(str(getattr(scene, 'modswitch_manage_mode', 'OBJECT')) == 'MODIFIER'))
            op.mode = 'MODIFIER'
        except Exception:
            try:
                row.prop(scene, "modswitch_manage_mode", text="", expand=True)
            except Exception:
                row.label(text=pgettext("Modifier Management"), icon='MODIFIER')
        row.operator("modswitch.update_list", text="", icon='FILE_REFRESH')

        def _draw_object_list(parent):
            box = parent.box()
            header = box.row(align=True)
            header.label(text=pgettext('Object List'), icon='OBJECT_DATA')
            right = header.row(align=True)
            try:
                right.alignment = 'RIGHT'
            except Exception:
                pass
            right.operator("modswitch.select_all_listed", text="", icon='RESTRICT_SELECT_OFF')
            row = box.row(align=True)
            row.prop(scene, "modswitch_filter_objects", text="", icon='VIEWZOOM')
            if len(scene.modswitch_objects) == 0:
                box.label(text=pgettext("No objects."))
            else:
                box.template_list(
                    "MODSWITCH_UL_Objects", "",
                    scene, "modswitch_objects",
                    scene, "modswitch_obj_index",
                    rows=6,
                )

        def _draw_modifier_list(parent):
            box = parent.box()
            _target_key = ''
            try:
                if 0 <= scene.modswitch_target_index < len(scene.modswitch_targets):
                    _target_key = str(scene.modswitch_targets[scene.modswitch_target_index].key or '')
            except Exception:
                _target_key = ''
            header = box.row(align=True)
            header.label(text=pgettext('Modifier List'), icon='MODIFIER')
            right = header.row(align=True)
            try:
                right.alignment = 'RIGHT'
            except Exception:
                pass
            try:
                if str(getattr(scene, "modswitch_manage_mode", "OBJECT") or "OBJECT") == 'OBJECT':
                    op = right.operator('modswitch.select_instance_modifier_objects', text='', icon='LINKED')
                    op.key = _target_key
            except Exception:
                pass
            row = box.row(align=True)
            row.prop(scene, "modswitch_filter_targets", text="", icon='VIEWZOOM')
            try:
                op = row.operator('modswitch.target_bulk_action', text='', icon='RESTRICT_VIEW_OFF')
                op.action = 'VIEWPORT_ON'; op.key = _target_key
                op = row.operator('modswitch.target_bulk_action', text='', icon='RESTRICT_VIEW_ON')
                op.action = 'VIEWPORT_OFF'; op.key = _target_key
                op = row.operator('modswitch.target_bulk_action', text='', icon='TRASH')
                op.action = 'DELETE'; op.key = _target_key
            except Exception:
                pass
            if len(scene.modswitch_targets) == 0:
                box.label(text=pgettext("No modifiers."))
            else:
                box.template_list(
                    "MODSWITCH_UL_Targets", "",
                    scene, "modswitch_targets",
                    scene, "modswitch_target_index",
                    rows=6,
                )

        if str(getattr(scene, "modswitch_manage_mode", "OBJECT") or "OBJECT") == 'MODIFIER':
            _draw_modifier_list(layout)
            _draw_object_list(layout)
        else:
            _draw_object_list(layout)
            _draw_modifier_list(layout)





class VIEW3D_PT_ms_tool_catalog_panel (bpy .types .Panel ):
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_label ='Bundled Tool Catalog'
    bl_idname ="VIEW3D_PT_ms_tool_catalog_panel"
    bl_order =60
    bl_options ={'DEFAULT_CLOSED'}

    @classmethod
    def poll (cls ,context ):
        return _ms_is_view3d_ui_context (context )

    def draw (self ,context ):
        layout =self .layout
        draw_help_header (layout ,context ,'Bundled Tool Catalog','plugin','bundled_catalog')
        _ms_request_panel_state_save (context )
        groups =_ms_get_available_user_plugin_groups ()
        if not groups :
            layout .label (text =choose_text ('No tools available.','利用できるツールはありません。',context =context ),icon='NONE')
            return
        for group_id ,group_plugins in groups :
            group_label =_ms_user_group_menu_label (group_id )
            group_icon =get_plugin_group_icon (group_id )
            def _draw_catalog_group_body (col ,context ,_plugins =tuple (group_plugins or ())):
                drew =False
                for plugin in _plugins :
                    draw_fn =plugin .get ('draw_add_menu')if isinstance (plugin ,dict )else None
                    if not callable (draw_fn ):
                        continue
                    try :
                        draw_fn (col ,context )
                        drew =True
                    except Exception :
                        continue
                if not drew :
                    col .label (text =choose_text ('No tools available.','利用できるツールはありません。',context =context ),icon='NONE')
            _ms_draw_child_section (
            layout ,context ,
            _ms_child_section_key ('catalog_group',str (group_id or 'other')),
            group_label ,
            icon =group_icon ,
            default_open =False ,
            draw_body =lambda _body ,_fn =_draw_catalog_group_body:_fn (_body ,context ),
            help_topic ='catalog_group:%s'%str (group_id or 'other'),
            )


            # --- Tooltip completion ---
VIEW3D_MT_ms_add_edit_menu .bl_description ="Add Blender's standard edit / data-transfer / weight style modifier entries."
VIEW3D_MT_ms_add_generate_menu .bl_description ="Add Blender's standard generate modifiers."
VIEW3D_MT_ms_add_deform_menu .bl_description ="Add Blender's standard deform modifiers."
VIEW3D_MT_ms_add_normals_menu .bl_description ="Add Blender's standard normal modifiers."
VIEW3D_MT_ms_add_physics_menu .bl_description ='Add physics-style modifiers from the Smart Modifier add menu.'
VIEW3D_MT_ms_add_geometry_menu .bl_description ='Add geometry / remesh style modifiers from the Smart Modifier add menu.'
VIEW3D_MT_ms_add_hair_menu .bl_description ='Add hair-related modifiers from the Smart Modifier add menu.'
VIEW3D_MT_ms_add_instances_menu .bl_description ='Add instancing-style modifiers from the Smart Modifier add menu.'
VIEW3D_MT_ms_add_geometry_nodes_menu .bl_description ='Add geometry-nodes based entries from the Smart Modifier add menu.'
OBJECT_MT_ms_add_user .bl_description ='Grouped root submenu for Smart Modifier user tools. It fans out into workflow categories so the migrated custom modifier catalog stays easier to scan than one long flat list.'
VIEW3D_MT_ms_master_add_menu .bl_description ="Master add menu for Smart Modifier. It restores Blender's standard modifier categories and also exposes bundled custom tools as split workflow-category menus so migrated functions can be started from one place without an oversized flat list."
VIEW3D_PT_smart_modifier_root_panel .bl_description ='Root group that contains every Smart Modifier N-panel tool. Smart Tools Manager can place this panel in the 3D View.'
VIEW3D_PT_ms_settings_panel .bl_description ='Central N-panel settings for Smart Modifier.'
VIEW3D_PT_modifier_stack_panel .bl_description ="Main modifier stack panel. Add Modifier restores Blender's standard modifier categories and centralizes bundled custom tools under workflow categories so old side-panel workflows are handled from this stack entry point."
VIEW3D_PT_ms_modswitcher_main .bl_description ='Modifier visibility switcher panel shown inside the Smart Modifier group.'
VIEW3D_PT_ms_tool_catalog_panel .bl_description ='All registered user tools are shown here by group. Use this panel to access bundled tool code that is not visible as a standalone panel.'


# Render these panels through the unified root panel only.  The draw methods are
# still used by _ms_draw_smart_modifier_unified_sections; only the separate
# Blender child-panel headers are suppressed.
VIEW3D_PT_ms_settings_panel.poll = classmethod(_ms_root_only_child_panel_poll)
VIEW3D_PT_modifier_stack_panel.poll = classmethod(_ms_root_only_child_panel_poll)
VIEW3D_PT_ms_modswitcher_main.poll = classmethod(_ms_root_only_child_panel_poll)
VIEW3D_PT_ms_tool_catalog_panel.poll = classmethod(_ms_root_only_child_panel_poll)
_ms_schedule_hide_duplicate_child_panels()

# Install guards before Blender registers the panel classes.  This is a static
# class setup step, not a runtime mutation of already-registered panel callbacks.
VIEW3D_PT_smart_modifier_root_panel .draw =_ms_guard_panel_draw (VIEW3D_PT_smart_modifier_root_panel .draw ,'Smart Modifier')
for _sms_cross_editor_root_panel_class in SMS_CROSS_EDITOR_ROOT_PANEL_CLASSES:
    try:
        _sms_cross_editor_root_panel_class .draw =_ms_guard_panel_draw (_sms_cross_editor_root_panel_class .draw ,'Smart Modifier')
    except Exception:
        pass
VIEW3D_PT_ms_settings_panel .draw =_ms_guard_panel_draw (VIEW3D_PT_ms_settings_panel .draw ,'Settings')
VIEW3D_PT_modifier_stack_panel .draw =_ms_guard_panel_draw (VIEW3D_PT_modifier_stack_panel .draw ,'Modifier Stack')
VIEW3D_PT_ms_modswitcher_main .draw =_ms_guard_panel_draw (VIEW3D_PT_ms_modswitcher_main .draw ,'Modifier Management')
VIEW3D_PT_ms_tool_catalog_panel .draw =_ms_guard_panel_draw (VIEW3D_PT_ms_tool_catalog_panel .draw ,'Bundled Tool Catalog')
