# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from __future__ import annotations

import bpy

from .utils import safe_activate_only, safe_mode_set, safe_select_all


def _existing_object(obj):
    if obj is None:
        return None
    name = getattr(obj, "name", None)
    if not name:
        return None
    try:
        return bpy.data.objects.get(name)
    except Exception:
        return obj


def capture_object_context(context):
    """Capture object selection / active object / mode for best-effort restoration."""
    selected = []
    try:
        selected = [obj for obj in (getattr(context, "selected_objects", []) or []) if obj is not None]
    except Exception:
        selected = []
    return {
        "mode": getattr(context, "mode", "OBJECT") or "OBJECT",
        "active": getattr(context, "active_object", None),
        "selected": selected,
    }


def restore_object_context(context, state, *, restore_mode: bool = True, fallback_active=None) -> bool:
    """Best-effort restoration of object selection, active object, and mode."""
    if not isinstance(state, dict):
        return False

    target_mode = str(state.get("mode") or "OBJECT")
    active = _existing_object(fallback_active if fallback_active is not None else state.get("active"))
    selected = []
    for obj in state.get("selected") or []:
        obj2 = _existing_object(obj)
        if obj2 is not None:
            selected.append(obj2)

    try:
        if getattr(context, "mode", "OBJECT") != "OBJECT":
            safe_mode_set("OBJECT")
    except Exception:
        pass

    safe_select_all("DESELECT")

    for obj in selected:
        try:
            obj.select_set(True)
        except Exception:
            pass

    if active is None and selected:
        active = selected[0]

    if active is not None:
        safe_activate_only(context, active, select=True)

    if restore_mode and target_mode != "OBJECT":
        mode_token = "EDIT" if str(target_mode).startswith("EDIT_") else str(target_mode)
        if active is not None:
            safe_activate_only(context, active, select=True)
        safe_mode_set(mode_token)
    return True


def ensure_object_mode(context, active_obj=None) -> bool:
    """Return True when the caller can safely continue in Object Mode."""
    obj = _existing_object(active_obj) if active_obj is not None else None
    if obj is not None:
        safe_activate_only(context, obj, select=True)
    current_mode = getattr(context, "mode", "OBJECT") or "OBJECT"
    if current_mode == "OBJECT":
        return True
    return safe_mode_set("OBJECT") is not None
