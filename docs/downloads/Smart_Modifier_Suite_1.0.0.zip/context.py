# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Preserve the active object, layer selection, and editing mode across an action."""

from contextlib import suppress

import bpy


_CONTEXT_MODES = {
    "PAINT_WEIGHT": "WEIGHT_PAINT",
    "PAINT_VERTEX": "VERTEX_PAINT",
    "PAINT_TEXTURE": "TEXTURE_PAINT",
}


def _in_layer(layer, obj):
    if obj is not None:
        # The original RNA object can be gone even when its name has been reused.
        with suppress(AttributeError, ReferenceError):
            existing = layer.objects.get(obj.name)
            if existing is not None and existing.as_pointer() == obj.as_pointer():
                return existing
    return None


def _change_mode(mode):
    operation = bpy.ops.object.mode_set
    try:
        return operation.poll() and "FINISHED" in operation(mode=mode)
    except (RuntimeError, TypeError, ValueError):
        return False


def capture_object_context(context):
    return {
        "mode": context.mode,
        "active": context.view_layer.objects.active,
        "selected": [obj for obj in context.selected_objects],
    }


def restore_object_context(context, state, *, restore_mode=True, fallback_active=None):
    if not isinstance(state, dict):
        return False
    if context.mode != "OBJECT" and not _change_mode("OBJECT"):
        return False

    layer = context.view_layer
    selected = {
        obj for saved in (state.get("selected") or ())
        if (obj := _in_layer(layer, saved)) is not None
    }
    active = _in_layer(layer, fallback_active) or _in_layer(layer, state.get("active"))
    if active is None:
        active = next((obj for obj in layer.objects if obj in selected), None)
    if active is not None:
        selected.add(active)

    try:
        for obj in layer.objects:
            should_select = obj in selected
            if obj.select_get(view_layer=layer) != should_select:
                obj.select_set(should_select, view_layer=layer)
        layer.objects.active = active
    except (RuntimeError, ReferenceError):
        return False

    mode = state.get("mode") or "OBJECT"
    if restore_mode and mode != "OBJECT":
        token = "EDIT" if mode.startswith("EDIT_") else _CONTEXT_MODES.get(mode, mode)
        return active is not None and _change_mode(token)
    return True


def ensure_object_mode(context, active_obj=None):
    """Switch the current active object out of its mode before adopting a target."""
    layer = context.view_layer
    target = _in_layer(layer, active_obj)
    if active_obj is not None and target is None:
        return False
    if context.mode != "OBJECT" and not _change_mode("OBJECT"):
        return False
    if target is not None:
        try:
            for obj in layer.objects:
                if obj != target and obj.select_get(view_layer=layer):
                    obj.select_set(False, view_layer=layer)
            target.select_set(True, view_layer=layer)
            layer.objects.active = target
        except (RuntimeError, ReferenceError):
            return False
    return True
