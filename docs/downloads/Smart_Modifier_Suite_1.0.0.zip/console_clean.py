# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Safe compatibility shim for older SmartTools cleanup hooks.

This module deliberately does not replace registered Panel.draw methods, start
background timers, save user preferences, or reset the active Workspace Tool.
Those operations are unsafe around Blender's 3D View sidebar layout path.

Only a narrow, one-time keymap cleanup remains: stale SmartTools N-panel
shortcuts and invalid empty ``wm.tool_set_by_id`` entries are removed from the
current session so older user keymaps do not emit View3D tool warnings.  The
cleanup is non-persistent unless Blender saves preferences through normal user
action.
"""

import bpy

_INSTALLED = False

_TOOL_SET_BY_ID_OPERATOR = 'wm.tool_set_by_id'
_TOOL_ID_PROP_NAMES = ('name', 'idname', 'tool_name', 'tool_id')
_STALE_TOOL_ID_PREFIXES = (
    'smart_tools',
    'smart_tools.',
    'smart_tools_',
    'smarttools.',
    'smarttools_',
    'bl_ext.user_default.smart_tools',
    'smart_modifier_suite.tool',
    'smart_modifier_suite.workspace_tool',
    'bl_ext.user_default.smart_modifier_suite.tool',
)
_LEGACY_NPANEL_OPERATOR_IDS = (
    'wm.bl_ext_npanel_popup_menu',
    'wm.bl_ext_npanel_operator_enum_popup',
    'wm.bl_ext_npanel_call_menu_pie',
)
_STALE_OPERATOR_PREFIXES = (
    'wm.smart_tools_',
    'wm.smart_tools_window',
    'wm.smart_tools_browser',
    'wm.bl_ext_npanel_',
)


def _iter_keyconfigs():
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    except Exception:
        keyconfigs = None
    if keyconfigs is None:
        return ()
    result = []
    for name in ('user', 'addon', 'active'):
        try:
            kc = getattr(keyconfigs, name, None)
        except Exception:
            kc = None
        if kc is not None:
            result.append((name, kc))
    return tuple(result)


def _tool_id_from_keymap_item(_kmi) -> str:
    # Do not inspect KeyMapItem.properties.  Accessing keymap operator property
    # RNA has triggered native Blender 5.1.x crashes during add-on reload/exit.
    return ''


def _is_stale_or_empty_tool_id(tool_id: str) -> bool:
    text = str(tool_id or '').strip()
    if not text:
        return True
    lowered = text.lower()
    return any(lowered == prefix or lowered.startswith(prefix) for prefix in _STALE_TOOL_ID_PREFIXES)


def _keymap_item_should_remove(kmi) -> bool:
    try:
        idname = str(getattr(kmi, 'idname', '') or '')
    except Exception:
        idname = ''
    if not idname:
        return False
    if idname == _TOOL_SET_BY_ID_OPERATOR:
        # Leave workspace-tool shortcuts untouched.  Deciding whether they are
        # stale requires reading KeyMapItem.properties, which is unsafe on
        # Blender 5.1.x during reload/shutdown.
        return False
    if idname in _LEGACY_NPANEL_OPERATOR_IDS:
        return True
    return idname.startswith(_STALE_OPERATOR_PREFIXES)


def sanitize_panel_draws() -> int:
    """Do not wrap or replace Panel draw callbacks."""
    return 0


def register_legacy_operator_compatibility() -> None:
    """Compatibility placeholder; no operators are registered automatically."""
    return None


def clean_keymaps_and_preferences(*, save: bool = False) -> bool:
    """Remove only stale SmartTools keymap items; do not save preferences."""
    del save
    changed = False
    for _config_name, kc in _iter_keyconfigs():
        try:
            maps = list(getattr(kc, 'keymaps', ()) or ())
        except Exception:
            maps = []
        for km in maps:
            try:
                items = list(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                items = []
            for kmi in items:
                if not _keymap_item_should_remove(kmi):
                    continue
                # Do not call native keymap item removal here.  Blender 5.1.0 can
                # crash in native UI-data teardown when an add-on frees keymap
                # item operator properties during unregister/exit.  Deactivating
                # stale entries is sufficient and keeps shutdown safe.
                try:
                    kmi.active = False
                    changed = True
                except Exception:
                    pass
    return changed


def install() -> None:
    """Run safe one-time compatibility cleanup without timers or UI mutation."""
    global _INSTALLED
    try:
        clean_keymaps_and_preferences(save=False)
    except Exception:
        pass
    _INSTALLED = True
    return None


def uninstall() -> None:
    """No runtime resources are installed by this shim."""
    global _INSTALLED
    _INSTALLED = False
    return None
