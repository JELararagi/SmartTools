# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Disable retired shortcut bindings without mutating workspace tools or saving preferences."""

from contextlib import suppress

import bpy

_INSTALLED = False
_KEYCONFIG_NAMES = ("user", "addon", "active")
_RETIRED_OPERATORS = ("wm.smart_tools_", "wm.bl_ext_npanel_")
_STALE_TOOL_PREFIXES = (
    "smart_tools", "smarttools.", "smarttools_", "bl_ext.user_default.smart_tools",
    "smart_modifier_suite.tool", "smart_modifier_suite.workspace_tool",
    "bl_ext.user_default.smart_modifier_suite.tool",
)


def _iter_keyconfigs():
    configurations = getattr(getattr(bpy.context, "window_manager", None), "keyconfigs", None)
    return tuple((name, config) for name in _KEYCONFIG_NAMES
                 if (config := getattr(configurations, name, None)) is not None)


def _tool_id_from_keymap_item(_kmi):
    return ""


def _is_stale_or_empty_tool_id(tool_id):
    identifier = str(tool_id or "").strip().casefold()
    return not identifier or identifier.startswith(_STALE_TOOL_PREFIXES)


def _keymap_item_should_remove(item):
    identifier = getattr(item, "idname", None)
    return isinstance(identifier, str) and identifier.startswith(_RETIRED_OPERATORS)


def sanitize_panel_draws():
    return 0


def register_legacy_operator_compatibility():
    return None


def clean_keymaps_and_preferences(*, save=False):
    touched = False
    with suppress(ReferenceError, RuntimeError):
        for _, configuration in _iter_keyconfigs():
            with suppress(ReferenceError, RuntimeError):
                for keymap in configuration.keymaps:
                    with suppress(ReferenceError, RuntimeError):
                        for item in keymap.keymap_items:
                            with suppress(ReferenceError, RuntimeError, AttributeError):
                                if _keymap_item_should_remove(item):
                                    item.active = False
                                    touched = True
    return touched


def install():
    global _INSTALLED
    clean_keymaps_and_preferences()
    _INSTALLED = True


def uninstall():
    global _INSTALLED
    _INSTALLED = False
