# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Japanese source strings and their English text."""

JA_EN = {
 'Back Transform / 二重変換を防止': 'Back Transform',
 'Bind / Rebind Control — 制御をバインド': 'Bind / Rebind Control',
 'Control Object / 制御オブジェクト': 'Control Object',
 'Modifier / モディファイア': 'Modifier',
 'POINT Boolean Mask / 頂点Booleanマスク': 'POINT Boolean Mask',
 'Target / 対象': 'Target',
 'この登録IDを Blender プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへコピーすると、Smart Modifierスタックのアクティブ階層を1つ上へ切り替えるショートカットを設定できます。': 'Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Up.',
 'この登録IDを Blender プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへコピーすると、Smart Modifierスタックのアクティブ階層を1つ下へ切り替えるショートカットを設定できます。': 'Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Down.',
 'アクティブなベースメッシュの Smart Modifier Stack「最終結果を表示」を切り替えます。Blender プリファレンス > キーマップ > 3Dビュー にこのオペレーターを登録すると、ショートカットから EndPreview の最終結果表示を切り替えられます。': 'Toggle Smart Modifier Stack "Show End Result" on the active base mesh. Register this operator in Preferences > Keymap > 3D View to toggle it from a shortcut.',
}
