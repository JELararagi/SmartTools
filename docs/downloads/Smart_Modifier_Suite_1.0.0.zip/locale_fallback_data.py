# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""English labels for Smart Modifier controls with bilingual source labels."""

JA_EN = {
    "Back Transform / 二重変換を防止": "Back Transform",
    "Bind / Rebind Control — 制御をバインド": "Bind or Rebind Control",
    "Control Object / 制御オブジェクト": "Control Object",
    "Modifier / モディファイア": "Modifier",
    "POINT Boolean Mask / 頂点Booleanマスク": "Point Boolean Mask",
    "Target / 対象": "Target",
    "アクティブなベースメッシュの Smart Modifier Stack「最終結果を表示」を切り替えます。Blender プリファレンス > キーマップ > 3Dビュー にこのオペレーターを登録すると、ショートカットから EndPreview の最終結果表示を切り替えられます。":
        "Show or hide the active base mesh's final result in Smart Modifier Stack. To assign a shortcut, add the operator under Preferences > Keymap > 3D View.",
}

for direction, english in (("上", "up"), ("下", "down")):
    key = (
        "この登録IDを Blender プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへコピーすると、"
        f"Smart Modifierスタックのアクティブ階層を1つ{direction}へ切り替えるショートカットを設定できます。"
    )
    JA_EN[key] = (
        f"Move one level {english} in the Smart Modifier stack. Paste this operator ID into "
        "Preferences > Keymap under 3D View > Object Mode and Mesh > Edit Mode to assign a shortcut."
    )
