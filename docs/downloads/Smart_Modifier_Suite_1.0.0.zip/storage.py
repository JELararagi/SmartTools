# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

try:
    from .save_policy import should_write_config
except Exception:  # fail closed if the canonical policy cannot be imported
    should_write_config = None

PACKAGE_ID = 'smart_modifier_suite'
SUITE_DATA_DIRNAME = 'Smart_Modifier_Suite'
USER_DATA_DIRNAME = 'user_data'
SUITE_CONFIG_FILENAME = 'Smart_Modifier_Suite.json'
_MIGRATION_DONE = False
_MIGRATION_ACTIVE = False
_LAST_VALID_SUITE_CONFIG: dict[str, Any] | None = None
_SUITE_CONFIG_ERROR = ''


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    # Package lookup is read-only; mutable callers use suite_config_dir().
    del create
    create = False
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    # Package lookup is read-only; never create extension repository paths.
    del create
    create = False
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_modifier_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    # Compatibility locator for legacy package data; strictly read-only.
    del create
    create = False
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Compatibility name for Smart Modifier's writable CONFIG root.

    Older releases returned the installed extension package and wrote mutable
    data beside Python source.  Extension packages are immutable; callers of
    this historical helper now receive ``CONFIG/Smart_Modifier_Suite``.
    """
    del package
    return suite_config_dir(create=create)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    root = extension_user_root(package_id or PACKAGE_ID, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    """Return the read-only installed/source package directory."""
    del create
    return _package_root()


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = extension_user_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = extension_user_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = extension_user_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = mutable_output_path(path, create_parent=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        if target.exists() and target.read_text(encoding=encoding) == text:
            return
    except Exception:
        pass
    tmp = target.with_name(target.name + '.tmp')
    try:
        tmp.write_text(text, encoding=encoding)
        os.replace(str(tmp), str(target))
    except Exception:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
        raise


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    # This low-level helper is also used by compatibility fallbacks.  Guard the
    # canonical suite JSON here so an import failure in an upper writer cannot
    # bypass N-panel State Save OFF.  Other product data files are unaffected.
    try:
        canonical = Path(suite_config_path(create=False)).resolve()
        requested = Path(path).resolve()
    except Exception:
        canonical = requested = None
    if canonical is not None and requested == canonical:
        checker = globals().get('should_write_config')
        try:
            context = getattr(bpy, 'context', None) if bpy is not None else None
            allowed = bool(callable(checker) and checker(context, force=False))
        except Exception:
            allowed = False
        if not allowed:
            globals()['_SUITE_CONFIG_ERROR'] = 'N-panel State Save is OFF; canonical config write blocked.'
            raise PermissionError(globals()['_SUITE_CONFIG_ERROR'])
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


# -----------------------------------------------------------------------------
# Shared versioned Blender config JSON
# -----------------------------------------------------------------------------
def config_dir(create: bool = True) -> Path:
    """Return Blender's versioned config directory.

    Windows resolves this to:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/<version>/config

    Smart Modifier stores all N-panel runtime settings under the suite folder:
    <config>/Smart_Modifier_Suite/Smart_Modifier_Suite.json
    """
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': create}),
                (('CONFIG', ''), {'create': create}),
                (('CONFIG',), {'create': create}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    continue
                if value:
                    path = Path(value)
                    if create:
                        try:
                            path.mkdir(parents=True, exist_ok=True)
                        except Exception:
                            pass
                    return path
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _legacy_package_roots() -> tuple[Path, ...]:
    """Return existing package roots strictly as read-only migration sources."""
    candidates: list[Path] = [_package_root()]
    for resolver in (_extension_path_user_root, _user_resource_root):
        try:
            candidate = resolver(PACKAGE_ID, False)
        except Exception:
            candidate = None
        if candidate is not None:
            candidates.append(Path(candidate))
    try:
        candidates.append(_platform_user_default_package_root(PACKAGE_ID, False))
    except Exception:
        pass
    result: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            key = str(candidate.resolve(strict=False))
        except Exception:
            key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        try:
            if candidate.exists() and candidate.is_dir():
                result.append(candidate)
        except Exception:
            continue
    return tuple(result)


def is_legacy_package_path(path: str | Path) -> bool:
    try:
        value = str(path or '')
        if bpy is not None:
            value = str(bpy.path.abspath(value))
        target = Path(value).expanduser().resolve(strict=False)
        for root in _legacy_package_roots():
            base = root.resolve(strict=False)
            if target == base or base in target.parents:
                return True
    except Exception:
        pass
    return False


def mutable_output_path(path: str | Path, *, create_parent: bool = False) -> Path:
    """Redirect stale package-local mutable paths into the suite CONFIG root."""
    value = str(path or '')
    if bpy is not None:
        try:
            value = str(bpy.path.abspath(value))
        except Exception:
            pass
    target = Path(value).expanduser().resolve(strict=False)
    for root in _legacy_package_roots():
        try:
            base = root.resolve(strict=False)
            if target != base and base not in target.parents:
                continue
            relative = target.relative_to(base)
            parts = relative.parts
            if parts and parts[0] == SUITE_DATA_DIRNAME:
                relative = Path(*parts[1:]) if len(parts) > 1 else Path()
            elif parts and parts[0] in {'storage', 'settings', 'runtime', 'data'}:
                relative = Path(USER_DATA_DIRNAME) / relative
            target = config_dir(create=True) / SUITE_DATA_DIRNAME / relative
            break
        except Exception:
            continue
    if create_parent:
        target.parent.mkdir(parents=True, exist_ok=True)
    return target


def _merge_legacy_tree(source: Path, target: Path) -> bool:
    """Copy missing files without changing or deleting the package source."""
    try:
        if not source.exists() or source.is_symlink():
            return False
        if source.is_file():
            if target.exists():
                return False
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            return True
        if not source.is_dir():
            return False
        copied = False
        target.mkdir(parents=True, exist_ok=True)
        for item in source.iterdir():
            if item.name in {'__pycache__', '.DS_Store', 'Thumbs.db'} or item.is_symlink():
                continue
            destination = target / item.name
            if item.is_dir():
                copied = _merge_legacy_tree(item, destination) or copied
            elif item.is_file() and not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, destination)
                copied = True
        return copied
    except Exception:
        return False


def migrate_legacy_package_data(target_root: Path | None = None) -> bool:
    global _MIGRATION_DONE, _MIGRATION_ACTIVE
    if _MIGRATION_DONE or _MIGRATION_ACTIVE:
        return False
    _MIGRATION_ACTIVE = True
    copied = False
    try:
        target = Path(target_root) if target_root is not None else config_dir(create=True) / SUITE_DATA_DIRNAME
        target.mkdir(parents=True, exist_ok=True)
        mappings = (
            (USER_DATA_DIRNAME, target / USER_DATA_DIRNAME),
            ('storage', target / USER_DATA_DIRNAME / 'storage'),
            ('settings', target / USER_DATA_DIRNAME / 'settings'),
            ('runtime', target / USER_DATA_DIRNAME / 'runtime'),
            ('data', target / USER_DATA_DIRNAME / 'data'),
            (SUITE_DATA_DIRNAME, target),
        )
        for root in _legacy_package_roots():
            for source_name, destination in mappings:
                copied = _merge_legacy_tree(root / source_name, destination) or copied
        _MIGRATION_DONE = True
        return copied
    finally:
        _MIGRATION_ACTIVE = False


def suite_config_dir(create: bool = True) -> Path:
    """Return the Smart Modifier config subfolder inside Blender's config dir."""
    path = config_dir(create=create) / SUITE_DATA_DIRNAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        try:
            migrate_legacy_package_data(path)
        except Exception:
            pass
    return path


def suite_config_path(create: bool = True) -> Path:
    path = suite_config_dir(create=create) / SUITE_CONFIG_FILENAME
    if create:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _legacy_suite_config_paths() -> list[Path]:
    """Old locations used before the dedicated Smart_Modifier_Suite folder."""
    paths: list[Path] = []
    try:
        paths.append(config_dir(create=False) / SUITE_CONFIG_FILENAME)
    except Exception:
        pass
    try:
        paths.append(config_dir(create=False) / 'smart_modifier_suite' / SUITE_CONFIG_FILENAME)
    except Exception:
        pass
    for root in _legacy_package_roots():
        paths.extend(
            (
                root / SUITE_CONFIG_FILENAME,
                root / SUITE_DATA_DIRNAME / SUITE_CONFIG_FILENAME,
                root / USER_DATA_DIRNAME / 'settings' / SUITE_CONFIG_FILENAME,
                root / 'storage' / 'settings' / 'n_panel_settings.json',
            )
        )
    # De-duplicate while preserving order.
    result: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        try:
            key = str(path.resolve())
        except Exception:
            key = str(path)
        if key and key not in seen:
            seen.add(key)
            result.append(path)
    return result


def _read_json_file(path: Path) -> dict[str, Any] | None:
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return None


def _migrate_legacy_suite_config(target: Path) -> dict[str, Any] | None:
    for legacy in _legacy_suite_config_paths():
        try:
            if legacy == target or not legacy.exists() or target.exists():
                continue
            data = _read_json_file(legacy)
            if isinstance(data, dict):
                try:
                    atomic_write_json(target, data, indent=2, ensure_ascii=False, sort_keys=True)
                except Exception:
                    pass
                return data
        except Exception:
            continue
    return None


def read_suite_config(default: Any = None) -> dict[str, Any]:
    global _LAST_VALID_SUITE_CONFIG, _SUITE_CONFIG_ERROR
    target = suite_config_path(create=False)
    try:
        data = _read_json_file(target)
        if isinstance(data, dict):
            _LAST_VALID_SUITE_CONFIG = dict(data)
            _SUITE_CONFIG_ERROR = ''
            return dict(data)
        if target.exists():
            _SUITE_CONFIG_ERROR = f'Invalid Smart Modifier JSON: {target}'
            print(f'[Smart Modifier] {_SUITE_CONFIG_ERROR}')
            if _LAST_VALID_SUITE_CONFIG is not None:
                return dict(_LAST_VALID_SUITE_CONFIG)
            return dict(default or {}) if isinstance(default, dict) else {}
        migrated = _migrate_legacy_suite_config(suite_config_path(create=True))
        if isinstance(migrated, dict):
            _LAST_VALID_SUITE_CONFIG = dict(migrated)
            _SUITE_CONFIG_ERROR = ''
            return dict(migrated)
    except Exception as exc:
        _SUITE_CONFIG_ERROR = str(exc)
        print(f'[Smart Modifier] Config read failed: {_SUITE_CONFIG_ERROR}')
        if _LAST_VALID_SUITE_CONFIG is not None:
            return dict(_LAST_VALID_SUITE_CONFIG)
    return dict(default or {}) if isinstance(default, dict) else {}


def write_suite_config(data: dict[str, Any]) -> bool:
    global _LAST_VALID_SUITE_CONFIG, _SUITE_CONFIG_ERROR
    checker = globals().get('should_write_config')
    try:
        context = getattr(bpy, 'context', None) if bpy is not None else None
        allowed = bool(callable(checker) and checker(context, force=False))
    except Exception:
        allowed = False
    if not allowed:
        _SUITE_CONFIG_ERROR = 'N-panel State Save is OFF; suite config write blocked.'
        return False
    if not isinstance(data, dict):
        data = {}
    payload = dict(data)
    payload.setdefault('version', 1)
    payload.setdefault('addon_id', PACKAGE_ID)
    try:
        target = suite_config_path(create=True)
        # Never replace a corrupt/unreadable existing file with defaults. The
        # last valid in-memory snapshot remains available for this process.
        if target.exists() and not isinstance(_read_json_file(target), dict):
            _SUITE_CONFIG_ERROR = f'Refusing to replace invalid Smart Modifier JSON: {target}'
            print(f'[Smart Modifier] {_SUITE_CONFIG_ERROR}')
            return False
        atomic_write_json(target, payload, indent=2, ensure_ascii=False, sort_keys=True)
        _LAST_VALID_SUITE_CONFIG = dict(payload)
        _SUITE_CONFIG_ERROR = ''
        return True
    except Exception as exc:
        _SUITE_CONFIG_ERROR = str(exc)
        print(f'[Smart Modifier] Config save failed: {_SUITE_CONFIG_ERROR}')
        return False


def suite_config_error() -> str:
    """Last observable config read/write failure; empty after a valid commit."""
    return str(_SUITE_CONFIG_ERROR or '')


def read_suite_config_section(section: str, default: Any = None) -> Any:
    data = read_suite_config()
    value = data.get(str(section or ''))
    if value is None:
        return default
    return value


def write_suite_config_section(section: str, value: Any) -> bool:
    checker = globals().get('should_write_config')
    try:
        context = getattr(bpy, 'context', None) if bpy is not None else None
        allowed = bool(callable(checker) and checker(context, force=False))
    except Exception:
        allowed = False
    if not allowed:
        globals()['_SUITE_CONFIG_ERROR'] = 'N-panel State Save is OFF; suite config section write blocked.'
        return False
    data = read_suite_config()
    data[str(section or '')] = value
    return write_suite_config(data)


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy one legacy file into CONFIG without mutating the source.

    ``remove_legacy`` remains in the signature for compatibility but is ignored;
    installed extension packages are always treated as immutable.
    """
    del remove_legacy
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        return True
    except Exception:
        return False
