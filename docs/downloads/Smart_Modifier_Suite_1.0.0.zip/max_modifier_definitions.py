# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from __future__ import annotations

# Legacy constants are kept for older compatibility imports, but Max-compatible
# entries are no longer exposed as one top-level Max-only menu.
# Each entry is assigned to a workflow category below.
MAX_MODIFIER_GROUP_ID = 'compatibility_utilities'
MAX_MODIFIER_GROUP_META = {'label': 'Compatibility / Utility', 'icon': 'TOOL_SETTINGS', 'priority': 6}

MAX_MODIFIER_CATEGORY_GROUPS = {
    'Transform': 'transform_xform',
    'Edit / Select': 'edit_selection',
    'Normals': 'normals_shading',
    'Deform': 'deform_ffd',
    'Generate': 'generate_geometry',
    'World Space': 'world_space',
    'Curves / Surface': 'curves_paths',
    'Subdivision': 'subdivision',
    'Topology': 'topology_repair',
    'Topology / Repair': 'topology_repair',
    'Precision / Symmetry': 'precision_symmetry',
    'UV / Mapping': 'uv_mapping',
    'Transfer / Projection': 'surface_projection',
    'Rigging': 'rigging_skin',
    'Simulation': 'simulation_physics',
    'Animation / Cache': 'animation_cache',
    'Materials': 'materials_attributes',
    'Legacy / Compatibility': 'compatibility_utilities',
    'Utility': 'compatibility_utilities',
    'Conversion': 'compatibility_utilities',
    'Surface': 'surface_projection',
    'Space Warp Binding': 'space_warp',
}

def max_modifier_group_for_category(category):
    return MAX_MODIFIER_CATEGORY_GROUPS.get(str(category or ''), 'compatibility_utilities')

def max_modifier_group_for_definition(defn):
    try:
        return max_modifier_group_for_category(defn.get('category'))
    except Exception:
        return 'compatibility_utilities'


MAX_MODIFIER_CATEGORY_JA = {'Transform': '変換', 'Edit / Select': '編集 / 選択', 'Normals': '法線', 'Deform': '変形', 'Generate': '生成', 'World Space': 'ワールドスペース', 'Curves / Surface': 'カーブ / サーフェス', 'Subdivision': 'サブディビジョン', 'Topology': 'トポロジー', 'Topology / Repair': 'トポロジー / 修復', 'Precision / Symmetry': '精密 / シンメトリ', 'UV / Mapping': 'UV / マッピング', 'Transfer / Projection': '転送 / プロジェクション', 'Rigging': 'リギング', 'Simulation': 'シミュレーション', 'Animation / Cache': 'アニメーション / キャッシュ', 'Materials': 'マテリアル', 'Legacy / Compatibility': '旧形式 / 互換', 'Utility': 'ユーティリティ', 'Conversion': '変換', 'Surface': 'サーフェス', 'Space Warp Binding': 'スペースワープ バインディング'}

def _d(key, label, label_ja, category, backend='builtin', modifier_type='', delegate='', properties=None, object_types=('MESH',), priority=10):
    return {
        'key': str(key),
        'plugin_id': 'max_' + str(key),
        'operator_id': 'smsm.max_' + str(key),
        'label': str(label),
        'label_ja': str(label_ja),
        'category': str(category),
        'category_ja': MAX_MODIFIER_CATEGORY_JA.get(str(category), str(category)),
        'description_en': _description_en(label, backend, modifier_type),
        'description_ja': _description_ja(label_ja, backend, modifier_type),
        'usage_en': _BASE_USAGE_EN,
        'usage_ja': _BASE_USAGE_JA,
        'icon': 'MODIFIER',
        'backend': str(backend),
        'modifier_type': str(modifier_type or ''),
        'properties': dict(properties or {}),
        'delegate': str(delegate or ''),
        'priority': int(priority),
        'object_types': tuple(object_types or ('MESH',)),
    }

def _description_en(label, backend, modifier_type):
    backend = str(backend or '')
    if backend == 'delegate':
        return f'Uses the upgraded Smart Modifier implementation as a stack-addable upper-compatible counterpart for the 3ds Max {label}.'
    if backend == 'builtin':
        mt = str(modifier_type or 'modifier')
        return f"Adds Blender's native {mt} stack item with 3ds Max-oriented defaults as an upper-compatible counterpart for the 3ds Max {label}."
    if backend == 'xform_nodes':
        return f'Creates an editable Geometry Nodes transform wrapper for 3ds Max {label} style stack-level move, rotation, and scale control.'
    if backend == 'mirror_nodes':
        return f'Creates a Max-style Mirror modifier from Geometry Nodes: Transform Geometry with a negative axis scale, then Flip Faces to restore normals.'
    if backend == 'noise_nodes':
        return f'Creates a non-destructive Smart Connect Noise Geometry Nodes modifier driven by an animatable Empty gizmo, matching the 3ds Max Noise modifier workflow.'
    if backend == 'push_nodes':
        return 'Creates a dedicated topology-preserving Push Geometry Nodes stack row with iterative current-normal displacement, separate normal/vertex relaxation, collision references and collided-vertex selection, falloff, axis multipliers, and Scale Normals.'
    if backend == 'face_extrude_nodes':
        return 'Creates a dedicated Face Extrude Geometry Nodes stack row that extrudes the captured face selection along averaged normals or radially from an animatable center, then scales each connected selected-face cluster independently.'
    if backend == 'skew_nodes':
        return f'Creates a dedicated Geometry Nodes Skew modifier with explicit amount, direction, primary axis, limits, and gizmo-space center behavior as a 3ds Max-compatible stack row.'
    if backend == 'melt_nodes':
        return f'Creates a dedicated gizmo-space Geometry Nodes Melt modifier with amount, spread, solidity presets, local axis, and flip-axis controls corresponding to the 3ds Max {label}.'
    return f'Creates a Smart Connect Geometry Nodes modifier for the 3ds Max {label}, with a dedicated helper collection, animatable gizmo where applicable, stack visibility control, and cleanup on apply/delete.'

def _description_ja(label_ja, backend, modifier_type):
    backend = str(backend or '')
    if backend == 'delegate':
        return f'3ds Max の {label_ja} に対応する上位互換スタック項目として、アップグレード済み Smart Modifier 実装を使用します。'
    if backend == 'builtin':
        mt = str(modifier_type or 'モディファイア')
        return f'3ds Max の {label_ja} に対応する上位互換スタック項目として、Blender 標準の {mt} を Max 向け初期値で追加します。'
    if backend == 'xform_nodes':
        return f'3ds Max の {label_ja} 風に、スタック内の移動・回転・スケールを制御する編集可能な Geometry Nodes 変換ラッパーを作成します。'
    if backend == 'mirror_nodes':
        return f'Geometry Nodes の Transform Geometry で軸スケールをマイナスにし、Flip Faces で法線を戻す Max 互換ミラーを作成します。'
    if backend == 'noise_nodes':
        return f'アニメーション可能な Empty ギズモで制御する非破壊の Smart Connect Noise Geometry Nodes モディファイアを作成し、3ds Max の Noise モディファイア相当のワークフローにします。'
    if backend == 'push_nodes':
        return '現在の法線を反復評価する変位、法線 / 頂点リラックス、衝突参照と衝突頂点選択、フォールオフ、軸倍率、法線スケールを備えた、トポロジーを維持する専用 Push Geometry Nodes スタック行を作成します。'
    if backend == 'face_extrude_nodes':
        return '取得した面選択を平均法線方向またはアニメーション可能な中心から放射方向へ押し出し、連結した選択面群ごとに独立してスケールする専用 Geometry Nodes スタック行を作成します。'
    if backend == 'skew_nodes':
        return f'量、方向、主軸、制限、ギズモ空間の中心挙動を明示した専用 Geometry Nodes スキューを作成し、3ds Max 互換のスタック行として追加します。'
    if backend == 'affect_region_nodes':
        return f'開始点と終点、フォールオフ、ピンチ、バブル、背面除外を持つ専用 Geometry Nodes 変形を作成し、3ds Max の {label_ja} と同じ非破壊スタック操作を提供します。'
    if backend == 'melt_nodes':
        return f'量、広がり、ソリディティプリセット、ローカル軸、軸反転を持つ専用ギズモ空間 Geometry Nodes 変形を作成し、3ds Max の {label_ja} に対応する非破壊スタック操作を提供します。'
    return f'3ds Max の {label_ja} に対応する Smart Connect Geometry Nodes モディファイアを作成し、専用補助コレクション、対応時のアニメーション可能ギズモ、スタック連動表示、適用/削除時クリーンアップを備えます。'

_BASE_USAGE_EN = 'Select one or more supported objects, then run this entry from the matching workflow category in Add Modifier. The created stack item can be reordered, copied, disabled, applied, or deleted like the other Smart Modifier entries.'
_BASE_USAGE_JA = '対応オブジェクトを1つ以上選択し、モディファイアを追加内の対応するワークフローカテゴリから実行します。作成されたスタック項目は、他の Smart Modifier 項目と同様に並べ替え、コピー、無効化、適用、削除できます。'

MAX_MODIFIER_DEFINITIONS = (
    _d('reset_xform_modifier', 'Reset XForm', 'Xフォームをリセット', 'Transform', 'delegate', '', 'smsm.reset_xform_modifier', {}, ('MESH',), 250),
    _d('xform_modifier', 'XForm Modifier', 'Xフォーム', 'Transform', 'xform_nodes', '', '', {}, ('MESH', 'CURVE', 'FONT', 'SURFACE'), 249),
    _d('linked_xform_modifier', 'Linked XForm Modifier', 'リンク Xフォーム', 'Transform', 'linked_xform_nodes', '', '', {}, ('MESH',), 248),
    _d('skew_modifier', 'Skew Modifier', 'スキュー', 'Deform', 'skew_nodes', '', '', {}, ('MESH', 'CURVE'), 240),
    _d('squeeze_modifier', 'Squeeze Modifier', 'スクイーズ', 'Deform', 'squeeze_nodes', '', '', {}, ('MESH', 'CURVE'), 238),
    _d('affect_region_modifier', 'Affect Region Modifier', '影響領域', 'Deform', 'affect_region_nodes', '', '', {}, ('MESH',), 237),
    _d('melt_modifier', 'Melt Modifier', 'メルト', 'Deform', 'melt_nodes', '', '', {}, ('MESH',), 229),
    _d('noise_modifier', 'Noise Modifier', 'ノイズ', 'Deform', 'noise_nodes', '', '', {}, ('MESH',), 228),
    _d('push_modifier', 'Push Modifier', 'プッシュ', 'Deform', 'push_nodes', '', '', {}, ('MESH',), 227),
    _d('preserve_modifier', 'Preserve Modifier', '保持', 'Deform', 'preserve_nodes', '', '', {}, ('MESH',), 226),
    _d('face_extrude_modifier', 'Face Extrude Modifier', 'フェース押し出し', 'Generate', 'face_extrude_nodes', '', '', {}, ('MESH',), 212),
    _d('sweep_modifier', 'Sweep Modifier', 'スイープ', 'Curves / Surface', 'delegate', '', 'smsp.sweep_active_profile', {}, ('CURVE',), 208),
    _d('mirror_modifier', 'Mirror Modifier', 'ミラー', 'Precision / Symmetry', 'mirror_nodes', '', '', {}, ('MESH',), 190),
    _d('uvw_map_modifier', 'UVW Map Modifier', 'UVWマップ', 'UV / Mapping', 'delegate', '', 'smsm.uvw_map_modifier', {}, ('MESH',), 188),
    _d('unwrap_uvw_modifier', 'Unwrap UVW Modifier', 'UVアンラップ', 'UV / Mapping', 'delegate', '', 'smsm.unwrap_uvw_modifier', {}, ('MESH',), 187),
    _d('normalize_spline_modifier', 'Normalize Spline Modifier', 'スプライン正規化', 'Curves / Surface', 'normalize_spline_nodes', '', '', {}, ('CURVE',), 134),

    _d('ffd_binding_modifier', 'FFD Binding Modifier', 'FFD バインディング', 'Space Warp Binding', 'delegate', '', 'smart_lattice.add_layer', {}, ('MESH',), 116),

)

MAX_MODIFIER_BY_KEY = {item['key']: item for item in MAX_MODIFIER_DEFINITIONS}
MAX_MODIFIER_BY_PLUGIN_ID = {item['plugin_id']: item for item in MAX_MODIFIER_DEFINITIONS}

def iter_max_modifier_definitions():
    return iter(MAX_MODIFIER_DEFINITIONS)

def get_max_modifier_definition(key=None, plugin_id=None):
    if key:
        return MAX_MODIFIER_BY_KEY.get(str(key))
    if plugin_id:
        return MAX_MODIFIER_BY_PLUGIN_ID.get(str(plugin_id))
    return None

def catalog_entry_for_definition(defn):
    return {
        'id': defn.get('plugin_id') or '',
        'plugin_id': defn.get('plugin_id') or '',
        'max_modifier_key': defn.get('key') or '',
        'label': defn['label'],
        'label_ja': defn.get('label_ja', defn['label']),
        'operator_id': defn['operator_id'],
        'icon': defn.get('icon') or 'MODIFIER',
        'priority': int(defn.get('priority', 0) or 0),
        'description_en': defn.get('description_en', ''),
        'description_ja': defn.get('description_ja', ''),
        'usage_en': defn.get('usage_en', ''),
        'usage_ja': defn.get('usage_ja', ''),
        'group': max_modifier_group_for_definition(defn),
        'stack_addable': True,
        'modeling_side': False,
    }

def short_hint_for_definition(defn):
    types = '/'.join(defn.get('object_types') or ('MESH',))
    return {
        'en': f'Object Mode · selected {types.lower()} object(s)',
        'ja': f'オブジェクトモード・選択 {types} オブジェクト',
    }

def translation_entries():
    entries = {'3ds Max Modifier Library': '3ds Max モディファイアライブラリ'}
    entries.update(MAX_MODIFIER_CATEGORY_JA)
    for d in MAX_MODIFIER_DEFINITIONS:
        entries[d['label']] = d.get('label_ja') or d['label']
    return entries
