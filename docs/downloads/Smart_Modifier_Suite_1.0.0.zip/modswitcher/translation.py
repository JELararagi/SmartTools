# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

translation_catalog_dict = {'ja_JP': {('*', 'Actions'): '操作',
           ('*', 'Active Collection'): 'アクティブコレクション',
           ('*', 'Active Only'): 'アクティブのみ',
           ('*', 'Advanced'): '高度な操作',
           ('*', 'Affect Flags'): '反映フラグ',
           ('*', "Affect the modifier's 'On Cage' flag when applying operations.\nThis is mainly meaningful for deforming modifiers in Edit Mode."): '操作を実行するときにモディファイアの「ケージ '
                                                                                                                                                     '(On '
                                                                                                                                                     'Cage)」フラグも変更します。\n'
                                                                                                                                                     '主に編集モードで変形系モディファイアを使う場合に意味があります。',
           ('*', "Affect the modifier's 'Show in Edit Mode' flag when applying operations.\nUseful for deforming modifiers you want active while editing the mesh."): '操作を実行するときにモディファイアの「編集モードで表示」フラグも変更します。\n'
                                                                                                                                                                      '編集しながら変形結果を見たいときに便利です。',
           ('*', "Affect the modifier's Render visibility flag when applying operations.\nTurn this ON if you want changes to affect final renders as well."): '操作を実行するときにモディファイアの「レンダー」フラグも変更します。\n'
                                                                                                                                                               '最終レンダーにも反映したい場合はONにしてください。',
           ('*', "Affect the modifier's Viewport visibility flag when applying operations.\nThis does NOT toggle the modifier by itself; it defines which flags\nare changed by Enable/Disable/Invert and State Sets."): '操作を実行するときにモディファイアの「ビューポート」フラグも変更します。\n'
                                                                                                                                                                                                                         'このボタン自体はモディファイアを切り替えません。どのフラグを変更対象にするかを指定します。\n'
                                                                                                                                                                                                                         '有効/無効/反転やステートセット適用時に、このフラグが変更されます。',
           ('*', 'All'): '全て',
           ('*', 'All objects in the scene'): 'シーン内の全オブジェクト',
           ('*', "Also affect the UI expanded/collapsed state of the modifier in Blender's\nmodifier panel (triangle open/closed). Useful to tidy long stacks."): '操作を実行するときに、Blenderのモディファイアパネルの展開/折りたたみ状態も変更します。\n'
                                                                                                                                                                  '長いスタックを整理したいときに便利です。',
           ('*', 'Applied Objects'): '適用オブジェクト一覧',
           ('*', 'Applied state set: {}'): '状態セットを適用しました: {}',
           ('*', 'Applied {} modifiers.'): '{} 個のモディファイアーを適用しました。',
           ('*', 'Applied {}. Not applied: {}'): '{} 個を適用しました。適用できなかった物: {}',
           ('*', 'Apply'): '適用',
           ('*', 'Apply (bake) the matching modifiers for all objects in the current scope.\nThis permanently changes geometry and removes the applied modifiers afterward.\nBeginner tip: If you only want to preview, use OFF/ON instead. Duplicate objects before applying if needed.'): '指定範囲の全オブジェクトで一致するモディファイアを適用（ベイク）します。\n'
                                                                                                                                                                                                                                                                                            '形状が確定し、適用したモディファイアは削除されます。\n'
                                                                                                                                                                                                                                                                                            '初心者ヒント：プレビューだけならON/OFFを使い、必要なら複製してから適用してください。',
           ('*', 'Apply (bake) the matching modifiers for all objects in the current scope.\nThis permanently changes geometry. Consider duplicating objects first.'): '指定範囲の全オブジェクトで一致するモディファイアを適用（ベイク）します。\n'
                                                                                                                                                                       '形状が確定する破壊的操作です。必要なら複製してから実行してください。',
           ('*', 'Apply Modifiers'): '適用',
           ('*', 'Apply matching modifiers (scope). This is destructive.'): '一致するモディファイアを適用します(指定範囲)。破壊的操作です。',
           ('*', 'Apply selected state set'): '選択中の状態セットを適用します',
           ('*', 'Auto Refresh'): '自動更新',
           ('*', "Automatically rebuild the Modifier/Object lists while you work.\nTurn this OFF in heavy scenes and use 'Update' manually when needed."): '作業中にモディファイア/オブジェクトのリストを自動で更新します。\n'
                                                                                                                                                           '重いシーンではOFFにして、必要なときだけ「更新」を押すと軽くなります。',
           ('*', 'Batch modifier management tool. Supports multi-language tooltips. Launched from the N-panel.'): 'モディファイアの一括管理ツール。多言語ツールチップ対応。Nパネルから起動',
           ('*', 'Change the N-panel tab name'): 'Nパネルのタブ名を変更します',
           ('*', 'Choose how targets are grouped in the Modifier List:\n- Type: one entry per modifier type (Mirror, Bevel, ...)\n- Name: one entry per modifier name (Bevel.001, ...)\nTip: Use Type for quick global toggles; use Name to distinguish duplicates.'): 'モディファイアリストのターゲットをどの単位でまとめるかを選びます。\n'
                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                       'タイプ: '
                                                                                                                                                                                                                                                                       'Mirror '
                                                                                                                                                                                                                                                                       '/ '
                                                                                                                                                                                                                                                                       'Bevel '
                                                                                                                                                                                                                                                                       'など種類ごと\n'
                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                       '名前: '
                                                                                                                                                                                                                                                                       'Bevel.001 '
                                                                                                                                                                                                                                                                       'などモディファイア名ごと\n'
                                                                                                                                                                                                                                                                       'ヒント: '
                                                                                                                                                                                                                                                                       'ざっくり切り替えるなら「タイプ」、複数コピーを区別するなら「名前」。',
           ('*', 'Choose which objects are listed and affected by operations:\n- Scene: all objects in the current scene\n- Selected: currently selected objects\n- Selected + Children: selected objects and their children\n- Active Collection: objects in the active collection\n- Collection: objects in a specific collection (set below)\nTip: Start with Selected to avoid changing unintended objects.'): '操作対象となるオブジェクト範囲を選びます。\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   '- '
                                                                                                                                                                                                                                                                                                                                                                                                                   'シーン: '
                                                                                                                                                                                                                                                                                                                                                                                                                   '現在のシーン内の全オブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   '- '
                                                                                                                                                                                                                                                                                                                                                                                                                   '選択: '
                                                                                                                                                                                                                                                                                                                                                                                                                   '選択中のオブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   '- '
                                                                                                                                                                                                                                                                                                                                                                                                                   '選択＋子: '
                                                                                                                                                                                                                                                                                                                                                                                                                   '選択中とその子オブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   '- '
                                                                                                                                                                                                                                                                                                                                                                                                                   'アクティブコレクション: '
                                                                                                                                                                                                                                                                                                                                                                                                                   'アクティブなコレクション内\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   '- '
                                                                                                                                                                                                                                                                                                                                                                                                                   'コレクション: '
                                                                                                                                                                                                                                                                                                                                                                                                                   '指定したコレクション内\n'
                                                                                                                                                                                                                                                                                                                                                                                                                   'ヒント: '
                                                                                                                                                                                                                                                                                                                                                                                                                   'まずは「選択」から始めると事故が起きにくいです。',
           ('*', 'Collapsible Sections'): '折りたたみセクション',
           ('*', 'Collection'): 'コレクション指定',
           ('*', 'Combined state indicator (ON / OFF / MIXED).\nThis is calculated automatically based on the selected visibility scope.'): '状態の総合表示（ON／OFF／MIXED）です。\n'
                                                                                                                                            '選択中の反映範囲に基づいて自動計算されます。',
           ('*', 'Count'): '数',
           ('*', 'Create a NEW State Set (a snapshot) of modifier ON/OFF + display flags.\nThis records the current modifier states of objects in the current scope, so you can restore them later.\nBeginner tip: Use State Sets to switch between setups (e.g. modeling vs render, high vs low).\nNote: This does NOT save modifier parameters or order — only the visibility/display states.'): '新しいステートセット（スナップショット）を作成します。\n'
                                                                                                                                                                                                                                                                                                                                                                                                   '指定範囲のオブジェクトのモディファイアON/OFFや表示フラグを記録し、後から復元できます。\n'
                                                                                                                                                                                                                                                                                                                                                                                                   '初心者ヒント：モデリング用/レンダー用、高/低など、状態の切り替えに便利です。\n'
                                                                                                                                                                                                                                                                                                                                                                                                   '注意：パラメータや順番は保存しません（表示/有効状態のみ）。',
           ('*', 'Currently selected objects'): '現在選択中のオブジェクト',
           ('*', 'Delete'): '削除',
           ('*', 'Delete selected state set'): '選択中の状態セットを削除します',
           ('*', 'Delete the selected State Set preset.\nThis only removes the preset; it does not change current modifier states.'): '選択中のステートセット（プリセット）を削除します。\n'
                                                                                                                                      'プリセットを消すだけで、現在のモディファイア状態は変更しません。',
           ('*', 'Delete the selected State Set preset.\nThis only removes the preset; it does not change current modifier states.\nTip: If you delete by mistake, Undo can restore it.'): '選択中のステートセット（プリセット）を削除します。\n'
                                                                                                                                                                                           'プリセットを消すだけで、現在の状態は変更しません。\n'
                                                                                                                                                                                           'ヒント：間違えて削除した場合はUndoで戻せます。',
           ('*', 'Deleted state set: {}'): '状態セットを削除しました: {}',
           ('*', 'Disable selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで無効(OFF)にします',
           ('*', 'Disable the selected target on all objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): '指定範囲の全オブジェクトでターゲットを無効(OFF)にします。\n'
                                                                                                                                                                            '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
           ('*', 'Disabled Only'): '無効のみ',
           ('*', 'Do not change viewport selection'): 'ビューポートの選択を変更しない',
           ('*', 'Drag & Drop'): 'ドラッグ＆ドロップ',
           ('*', 'Edit / Cage'): '編集 / ケージ',
           ('*', 'Edit Mode'): '編集モード',
           ('*', 'Enable selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで有効(ON)にします',
           ('*', 'Enable the selected target on all objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): '指定範囲の全オブジェクトでターゲットを有効(ON)にします。\n'
                                                                                                                                                                           '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
           ('*', 'Enabled Only'): '有効のみ',
           ('*', 'Expand/collapse the Details section to save vertical space.'): '縦スペース節約のため「詳細」セクションを展開/折りたたみします。',
           ('*', 'Expand/collapse the Modifier List section to save vertical space.'): '縦スペース節約のため「モディファイアリスト」セクションを展開/折りたたみします。',
           ('*', 'Expand/collapse the Object List section to save vertical space.'): '縦スペース節約のため「オブジェクトリスト」セクションを展開/折りたたみします。',
           ('*', 'Expand/collapse the Settings section to save vertical space.'): '縦スペース節約のため「設定」セクションを展開/折りたたみします。',
           ('*', 'Expand/collapse the State Sets section to save vertical space.'): '縦スペース節約のため「ステートセット」セクションを展開/折りたたみします。',
           ('*', 'Expanded'): '展開状態',
           ('*', 'Filter / Search'): 'フィルター / 検索',
           ('*', 'Filter Objects'): 'オブジェクトフィルタ',
           ('*', 'Filter Targets'): 'ターゲットフィルタ',
           ('*', 'Filter the Object List by the ON/OFF state of the selected target.\nThe state is evaluated using the primary visibility flag (usually Viewport).'): 'オブジェクトリストをターゲットのON/OFF状態で絞り込みます。\n'
                                                                                                                                                                      '状態は主となる可視フラグ（通常はビューポート）で判定します。',
           ('*', 'Group targets by modifier name (e.g. Bevel.001)'): 'モディファイア名でターゲットをまとめる（例: Bevel.001）',
           ('*', 'Group targets by modifier type (Mirror, Bevel, ...)'): 'モディファイアの種類でターゲットをまとめる（Mirror / Bevel など）',
           ('*', 'How clicking an item in the Object List affects viewport selection:\n- None: do not change the current selection\n- Single: deselect others and select the clicked object\n- Active Only: set active/selected without deselecting others'): 'オブジェクトリストをクリックしたときの選択挙動を設定します。\n'
                                                                                                                                                                                                                                                              '- '
                                                                                                                                                                                                                                                              'なし: '
                                                                                                                                                                                                                                                              '現在の選択を変えない\n'
                                                                                                                                                                                                                                                              '- '
                                                                                                                                                                                                                                                              '単一: '
                                                                                                                                                                                                                                                              'それ以外を解除してクリックした物だけ選択\n'
                                                                                                                                                                                                                                                              '- '
                                                                                                                                                                                                                                                              'アクティブのみ: '
                                                                                                                                                                                                                                                              '他の選択を残したままアクティブ化/選択',
           ('*', 'How many matching modifiers exist on this object for the current target.\nThis is calculated automatically.'): '現在のターゲットに一致するモディファイアが、このオブジェクトにいくつあるかです。\n'
                                                                                                                                 '自動計算されます。',
           ('*', 'How many matching modifiers were found for this target.\nThis is calculated automatically when the list is rebuilt.'): 'このターゲットに一致するモディファイア数です。\n'
                                                                                                                                         'リスト更新時に自動計算されます。',
           ('*', 'How many objects contain matching modifiers for this target.\nThis is calculated automatically when the list is rebuilt.'): 'このターゲットに一致するモディファイアを持つオブジェクト数です。\n'
                                                                                                                                              'リスト更新時に自動計算されます。',
           ('*', 'How often Auto Refresh runs (seconds).\nIncrease this value to reduce CPU usage in heavy scenes.'): '自動更新の実行間隔（秒）です。\n'
                                                                                                                      '重いシーンでは値を大きくしてCPU負荷を下げられます。',
           ('*', 'How the target is defined (by modifier TYPE or by modifier NAME).\nThis is managed automatically based on the current target mode.'): 'ターゲットの指定方法（モディファイアのタイプ指定／名前指定）です。\n'
                                                                                                                                                        '現在のターゲットモードに応じて自動管理されます。',
           ('*', 'Instance'): 'インスタンス',
           ('*', 'Internal key used to identify a pinned modifier target.\nThis value is managed automatically.'): '内部キー：ピン留めしたターゲットを識別するためのキーです。\n'
                                                                                                                   '自動管理されるため、通常は編集不要です。',
           ('*', 'Internal key used to identify this target entry.\nThis value is managed automatically.'): '内部キー：このターゲット項目を識別するためのキーです。\n'
                                                                                                            '自動管理されるため、通常は編集不要です。',
           ('*', 'Invert'): '反転',
           ('*', 'Invert (toggle) the active target for ALL objects in the current scope.\nObjects that are ON become OFF (and vice versa). Useful for quick comparisons.'): '指定範囲の全オブジェクトで、アクティブターゲットを反転（トグル）します。\n'
                                                                                                                                                                             'ONの物はOFFに、OFFの物はONになります。差分チェックに便利です。',
           ('*', 'Invert selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで反転します',
           ('*', 'Invert the selected target on all objects in the current scope.\nObjects that are ON become OFF (and vice versa).'): '指定範囲の全オブジェクトでターゲットを反転します。\n'
                                                                                                                                       'ONの物はOFFに、OFFの物はONになります。',
           ('*', 'Key'): 'キー',
           ('*', 'Label'): 'ラベル',
           ('*', 'Load/apply the selected State Set to objects in the current scope.\nThis restores the saved ON/OFF + display flags from that snapshot.\nNote: It does not add/remove modifiers or change their order — it only restores states.'): '選択中のステートセットを、指定範囲のオブジェクトへ読み込み/適用します。\n'
                                                                                                                                                                                                                                                     '保存されたON/OFF・表示フラグを復元します。\n'
                                                                                                                                                                                                                                                     '注意：モディファイアの追加/削除や順番変更は行いません（状態の復元のみ）。',
           ('*', 'Load/apply the selected State Set.\nThis sets the target visibility on objects according to the saved preset.'): '選択中のステートセットを読み込み/適用します。\n'
                                                                                                                                   '保存されたプリセット通りにターゲットの表示状態を設定します。',
           ('*', 'Mixed'): '混在のみ',
           ('*', 'Mode'): 'モード',
           ('*', 'Modifier Switcher'): 'モディファイア切り替え',
           ('*', 'Modifier Targets'): 'モディファイアターゲット',
           ('*', 'Modifier management tool...'): 'モディファイアの一括管理ツール。多言語ツールチップ対応。',
           ('*', 'Modifier name used when targeting by NAME.\nThis is managed automatically.'): '名前指定時に使われるモディファイア名です。\n'
                                                                                                '自動管理されます。',
           ('*', 'Modifier type used when targeting by TYPE (example: SUBSURF, MIRROR).\nThis is managed automatically.'): 'タイプ指定時に使われるモディファイアの種類です（例：サブサーフ、ミラー）。\n'
                                                                                                                           '自動管理されます。',
           ('*', 'Modifiers'): 'モディファイア',
           ('*', 'Mods'): 'モディファイア',
           ('*', 'Move'): '移動',
           ('*', 'Move Down'): '下に移動',
           ('*', 'Move Up'): '上に移動',
           ('*', 'Move matching modifiers down (toward the bottom of the stack)'): '一致するモディファイアを下へ移動します（スタックの末尾方向）',
           ('*', 'Move matching modifiers down one step in the stack (scope)'): '一致するモディファイアをスタック内で1つ下へ移動します(指定範囲)',
           ('*', 'Move matching modifiers up (toward the top of the stack)'): '一致するモディファイアを上へ移動します（スタックの先頭方向）',
           ('*', 'Move matching modifiers up one step in the stack (scope)'): '一致するモディファイアをスタック内で1つ上へ移動します(指定範囲)',
           ('*', 'Move the matching modifiers DOWN by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.'): '指定範囲の全オブジェクトで一致するモディファイアを1段下へ移動します。\n'
                                                                                                                                                                          '複数オブジェクトの順番を揃えたいときに便利です。',
           ('*', 'Move the matching modifiers DOWN by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): '指定範囲の全オブジェクトで一致するモディファイアを1段下へ移動します。\n'
                                                                                                                                                                                                                                             '複数オブジェクトの順番を揃えたいときに便利です。\n'
                                                                                                                                                                                                                                             'ヒント：順番は結果に影響します。移動すると形状が変わることがあります。',
           ('*', 'Move the matching modifiers UP by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.'): '指定範囲の全オブジェクトで一致するモディファイアを1段上へ移動します。\n'
                                                                                                                                                                        '複数オブジェクトの順番を揃えたいときに便利です。',
           ('*', 'Move the matching modifiers UP by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): '指定範囲の全オブジェクトで一致するモディファイアを1段上へ移動します。\n'
                                                                                                                                                                                                                                           '複数オブジェクトの順番を揃えたいときに便利です。\n'
                                                                                                                                                                                                                                           'ヒント：順番は結果に影響します。移動すると形状が変わることがあります。',
           ('*', 'Name'): '名前',
           ('*', 'New Set Name'): '新規セット名',
           ('*', 'No dependency enforcement (match Smart Modifier UI behavior).'): '依存関係を自動で強制しない（Smart Modifier '
                                                                                  '側の挙動に合わせる）。',
           ('*', 'No modifiers found in scope.'): '指定範囲にモディファイアが見つかりませんでした。',
           ('*', 'No objects.'): 'オブジェクトがありません。',
           ('*', 'No targets.'): 'ターゲットがありません。',
           ('*', 'None'): 'なし',
           ('*', 'OFF'): 'OFF',
           ('*', 'ON'): 'ON',
           ('*', 'Object'): 'オブジェクト',
           ('*', 'Object Filter'): 'オブジェクト検索',
           ('*', 'Object name in the applied object list.\nThis is generated automatically.'): '適用オブジェクトリストに表示されるオブジェクト名です。\n'
                                                                                               '自動生成されます。',
           ('*', 'Objects'): 'オブジェクト',
           ('*', 'Objects in a specific collection'): '指定コレクション内のオブジェクト',
           ('*', 'Objects in the active collection'): 'アクティブコレクション内のオブジェクト',
           ('*', 'On Cage'): 'ケージ',
           ('*', 'Overlay'): '表示',
           ('*', 'Overwrite'): '上書き',
           ('*', 'Overwrite selected state set'): '選択中の状態セットを上書き保存します',
           ('*', 'Overwrite the selected State Set with the current ON/OFF state.\nUse this to update a preset after you make changes.'): '選択中のステートセットを現在の状態で上書きします。\n'
                                                                                                                                          'プリセットを更新したいときに使います。',
           ('*', 'Overwrite the selected State Set with the current modifier ON/OFF + display states.\nUse this to update a preset after you make changes.\nCaution: This replaces the saved snapshot (Undo can revert).'): '選択中のステートセットを、現在のモディファイア状態で上書きします。\n'
                                                                                                                                                                                                                            '変更後にプリセットを更新したいときに使います。\n'
                                                                                                                                                                                                                            '注意：保存内容を置き換えます（Undoで戻せます）。',
           ('*', 'Pin'): 'ピン',
           ('*', 'Pin/unpin the selected target.\nPinned targets stay at the top of the Modifier List for quick access, and are kept even if temporarily missing.\nBeginner tip: Use Pin for important modifiers you always want to see/control.'): '選択中のターゲットをピン留め/解除します。\n'
                                                                                                                                                                                                                                                    'ピン留めしたターゲットは先頭に固定され、一時的に見つからない状態でもリストに残ります。\n'
                                                                                                                                                                                                                                                    '初心者ヒント：常に見たい/操作したい重要なモディファイアはピン留めしておくと便利です。',
           ('*', 'Pin/unpin the selected target.\nPinned targets stay at the top of the Modifier List for quick access.'): '選択中のターゲットをピン留め/解除します。\n'
                                                                                                                           'ピン留めしたターゲットはモディファイアリストの先頭に固定されます。',
           ('*', 'Pin/unpin this target'): 'このターゲットをピン留め/解除します',
           ('*', 'Pinned'): 'ピン留め',
           ('*', 'Rebuild the Modifier List and Object List based on the current Scope/Mode.\nUse this after adding/removing/renaming modifiers, or when Auto Refresh is OFF.'): '現在の範囲/モードに基づいて、モディファイアリストとオブジェクトリストを再構築します。\n'
                                                                                                                                                                                 'モディファイアの追加/削除/リネーム後や、自動更新OFF時に使います。',
           ('*', 'Rebuild the Modifier List and Object List based on the current Scope/Mode.\nUse this after adding/removing/renaming modifiers, or when the UI looks out of date.\nTip: When Auto Refresh is ON, this runs automatically at the interval you set.'): '現在の範囲/モードに基づいて、モディファイアリストとオブジェクトリストを再構築します。\n'
                                                                                                                                                                                                                                                                      'モディファイアの追加/削除/リネーム後や、表示が古いと感じたときに使います。\n'
                                                                                                                                                                                                                                                                      'ヒント：自動更新がONの場合は、設定した間隔で自動的に実行されます。',
           ('*', 'Refresh'): '更新',
           ('*', 'Refresh Interval'): '更新間隔',
           ('*', 'Remove Modifiers'): '削除',
           ('*', 'Remove matching modifiers (scope). This is destructive.'): '一致するモディファイアを削除します(指定範囲)。破壊的操作です。',
           ('*', 'Remove the matching modifiers from all objects in the current scope.\nThis is destructive (it deletes the modifiers).'): '指定範囲の全オブジェクトから一致するモディファイアを削除します。\n'
                                                                                                                                           'モディファイア自体を消す破壊的操作です。',
           ('*', 'Remove the matching modifiers from all objects in the current scope.\nThis is destructive (it deletes the modifiers).\nTip: If you might need them later, use OFF (disable) instead of removing.'): '指定範囲の全オブジェクトから一致するモディファイアを削除します。\n'
                                                                                                                                                                                                                      'モディファイア自体を消す破壊的操作です。\n'
                                                                                                                                                                                                                      'ヒント：後で必要になるかもなら、削除ではなくOFF（無効化）がおすすめです。',
           ('*', 'Render'): 'レンダー',
           ('*', 'Render visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'レンダー表示の状態（ON／OFF／MIXED）です。\n'
                                                                                                                        '自動計算されます。',
           ('*', 'Save New'): '新規保存',
           ('*', 'Save a new state set'): '状態セットを新規保存します',
           ('*', 'Save the current ON/OFF state of the selected target as a new State Set.\nLater you can Load it to restore the same visibility across objects.'): '選択中ターゲットのON/OFF状態を新しいステートセットとして保存します。\n'
                                                                                                                                                                    '後で読み込むと同じ表示状態を素早く復元できます。',
           ('*', 'Saved state set: {}'): '状態セットを保存しました: {}',
           ('*', 'Scan scope for modifiers and rebuild lists'): '指定範囲のモディファイアをスキャンしてリストを更新します',
           ('*', 'Scene'): 'シーン全体',
           ('*', 'Scope'): '範囲',
           ('*', 'Search filter for the Modifier List.\nType part of a modifier type/name to narrow the list (case-insensitive).'): 'モディファイアリストの検索フィルタです。\n'
                                                                                                                                    'モディファイアの種類/名前の一部を入力すると絞り込めます（大文字小文字は区別しません）。',
           ('*', 'Search filter for the Object List.\nType part of an object name to narrow the list (case-insensitive).'): 'オブジェクトリストの検索フィルタです。\n'
                                                                                                                            'オブジェクト名の一部を入力すると絞り込めます（大文字小文字は区別しません）。',
           ('*', 'Select All Listed'): 'リスト内を全選択',
           ('*', 'Select all objects listed'): 'リスト内のオブジェクトを全て選択します',
           ('*', 'Select every object currently shown in the Object List.\nTip: Combine with Scope/filters to quickly build a selection set.'): '現在オブジェクトリストに表示されている物をまとめて選択します。\n'
                                                                                                                                                '範囲やフィルタと組み合わせると素早く選択セットを作れます。',
           ('*', 'Select every object currently shown in the Object List.\nTip: Combine with Scope/filters to quickly build a selection set.\nNote: This only changes the viewport selection; it does not edit the Object List itself.'): '現在オブジェクトリストに表示されている物をまとめて選択します。\n'
                                                                                                                                                                                                                                          '範囲やフィルタと組み合わせると素早く選択セットを作れます。\n'
                                                                                                                                                                                                                                          '補足：これはビューポートの選択を変えるだけで、オブジェクトリスト自体は編集しません。',
           ('*', 'Select only the clicked object (deselect others)'): 'クリックしたオブジェクトだけ選択する（他は解除）',
           ('*', 'Selected'): '選択のみ',
           ('*', 'Selected + Children'): '選択+子階層',
           ('*', 'Selected objects and their children'): '選択中のオブジェクトとその子',
           ('*', 'Selected {} objects.'): '{} 個のオブジェクトを選択しました。',
           ('*', 'Selection Behavior'): '選択挙動',
           ('*', 'Selection Sync'): '選択同期',
           ('*', 'Set active object without clearing selection'): '選択を解除せずにアクティブ化する',
           ('*', 'Show Details'): '詳細を表示',
           ('*', 'Show Modifier List'): 'モディファイアリストを表示',
           ('*', 'Show Object List'): 'オブジェクトリストを表示',
           ('*', 'Show Objects'): '表示フィルタ',
           ('*', 'Show Settings'): '設定を表示',
           ('*', 'Show State Sets'): 'ステートセットを表示',
           ('*', 'Show all objects in the current scope'): '現在の範囲内の全オブジェクトを表示',
           ('*', 'Show objects with a mixed state (multiple matches)'): '状態が混在しているオブジェクトを表示（複数一致など）',
           ('*', 'Show only objects that are currently visible in the viewport.\nHidden or excluded objects are ignored (useful to skip helper objects).'): 'ビューポートで現在表示されているオブジェクトだけを一覧に出します。\n'
                                                                                                                                                            '非表示/除外されている物は無視されます（補助オブジェクトを除外したい時に便利）。',
           ('*', 'Show only objects where the target is OFF'): 'ターゲットがOFFのオブジェクトだけ表示',
           ('*', 'Show only objects where the target is ON'): 'ターゲットがONのオブジェクトだけ表示',
           ('*', 'Show/hide the Details section.\n\nThis only folds the UI to save space.'): '詳細 セクションの表示/非表示。\n'
                                                                                             '\n'
                                                                                             'UIを折りたたんで省スペースにするだけです。',
           ('*', 'Show/hide the Modifier List section.\n\nThis only folds the UI to save space; it does not change any modifiers.'): 'モディファイアリスト '
                                                                                                                                     'セクションの表示/非表示。\n'
                                                                                                                                     '\n'
                                                                                                                                     'UIを折りたたんで省スペースにするだけで、モディファイア自体は変更しません。',
           ('*', 'Show/hide the Object List section.\n\nThis only folds the UI to save space; it does not change selection or objects.'): 'オブジェクトリスト '
                                                                                                                                          'セクションの表示/非表示。\n'
                                                                                                                                          '\n'
                                                                                                                                          'UIを折りたたむだけで、選択状態やオブジェクト自体は変更しません。',
           ('*', 'Show/hide the Settings section.\n\nThis only folds the UI to save space.'): '設定 セクションの表示/非表示。\n'
                                                                                              '\n'
                                                                                              'UIを折りたたんで省スペースにするだけです。',
           ('*', 'Show/hide the State Sets section.\n\nThis only folds the UI to save space; it does not apply any state sets by itself.'): '状態セット '
                                                                                                                                            'セクションの表示/非表示。\n'
                                                                                                                                            '\n'
                                                                                                                                            'UIを折りたたむだけで、状態セットの適用は行いません。',
           ('*', 'Single'): '単一選択',
           ('*', 'Single Select'): '単一選択',
           ('*', 'State'): '状態',
           ('*', 'State Sets'): '状態セット',
           ('*', 'Swap ON/OFF for the target (applies the selected flags)'): '対象のON/OFFを反転します（選択中のフラグに適用）',
           ('*', 'Tab Category Name'): 'タブカテゴリー名',
           ('*', 'Target Filter'): 'ターゲット検索',
           ('*', 'Toggle'): '切替',
           ('*', 'Toggle All'): '一括切替',
           ('*', 'Toggle target for this object'): 'このオブジェクトのターゲット表示を切り替えます',
           ('*', 'Toggle the ACTIVE target for the object you click (one object at a time).\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: Use the big ON/OFF buttons to change ALL objects at once.'): 'クリックしたオブジェクトだけ、アクティブターゲットを切り替えます（1オブジェクトずつ）。\n'
                                                                                                                                                                                                                                                     '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                                     'ヒント：全オブジェクトをまとめて変えるなら上の大きいON/OFFボタンを使ってください。',
           ('*', 'Toggle the selected target for the currently highlighted object.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): 'オブジェクトリストで選択中のオブジェクトだけ、ターゲットを切り替えます。\n'
                                                                                                                                                                            '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
           ('*', 'True when this object shares its data (an instance) with another object in the list.\nInstances often share the same modifier stack.'): 'このオブジェクトが他のオブジェクトとデータを共有している（インスタンス）場合にTrueになります。\n'
                                                                                                                                                          'インスタンスは同じモディファイアスタックを共有することが多いです。',
           ('*', 'Turn OFF (disable) the active target for ALL objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: OFF is non-destructive; you can turn it ON again later.'): '指定範囲の全オブジェクトで、アクティブターゲットを無効(OFF)にします。\n'
                                                                                                                                                                                                                                                    '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                                    'ヒント：OFFは破壊的ではありません。あとでONに戻せます。',
           ('*', 'Turn ON (enable) the active target for ALL objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: This does not add/remove modifiers — it only changes their ON/OFF and display states.'): '指定範囲の全オブジェクトで、アクティブターゲットを有効(ON)にします。\n'
                                                                                                                                                                                                                                                                                '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                                                                'ヒント：モディファイアの追加/削除は行わず、ON/OFFと表示フラグだけを変更します。',
           ('*', 'Turn the target OFF (applies the selected flags)'): '対象をOFFにします（選択中のフラグに適用）',
           ('*', 'Turn the target ON (applies the selected flags)'): '対象をONにします（選択中のフラグに適用）',
           ('*', 'Type'): 'タイプ',
           ('*', "Type a name for the new State Set.\nUse a short, clear name such as 'Preview OFF' or 'Render ON' so you can find it later easily.\nAfter typing, click '+' to save it as a new preset, or select an existing set and use Overwrite.\nState Sets only remember visibility/display buttons; they do not store modifier values or order."): '新しい状態セットの名前を入力します。\n'
                                                                                                                                                                                                                                                                                                                                                           'あとで見つけやすいように『Preview '
                                                                                                                                                                                                                                                                                                                                                           'OFF』『Render '
                                                                                                                                                                                                                                                                                                                                                           'ON』のような短く分かりやすい名前がおすすめです。\n'
                                                                                                                                                                                                                                                                                                                                                           '入力後は『+』で新規保存、既存セットを更新したい時は対象を選んで『上書き』を使います。\n'
                                                                                                                                                                                                                                                                                                                                                           '状態セットが保存するのは表示/有効状態だけで、モディファイアの数値や順番は保存しません。',
           ('*', "Type a name for the new State Set. State Sets are presets that remember each modifier's visibility buttons (Viewport / Edit Mode / Real-time / Render) for the objects in the list. After typing, click 'Add State Set' to create it."): '新しい状態セットの名前を入力します。状態セットは、リスト内のオブジェクトの各モディファイアについて、表示ボタン（ビューポート／編集モード／リアルタイム／レンダー）のON/OFF状態を記憶するプリセットです。名前を入力したら「状態セットを追加」を押して作成します。',
           ('*', 'UI label shown in the target list.\nThis is generated automatically.'): 'ターゲットリストに表示されるラベルです。\n'
                                                                                          '自動生成されます。',
           ('*', 'Update List'): 'リスト更新',
           ('*', 'Updated targets.'): 'ターゲットを更新しました。',
           ('*', 'Updated {} modifiers ({}).'): '{} 個のモディファイアを更新しました ({})。',
           ('*', 'Viewport'): 'ビューポート',
           ('*', 'Viewport visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'ビューポート表示の状態（ON／OFF／MIXED）です。\n'
                                                                                                                          '自動計算されます。',
           ('*', 'Visible Only'): '表示中のみ',
           ('*', "When Scope is set to 'Collection', pick the collection to use.\nOnly objects in this collection will be listed/affected."): '範囲を「コレクション」にした場合、使用するコレクションを選択します。\n'
                                                                                                                                              'このコレクションに含まれるオブジェクトだけが一覧/操作対象になります。',
           ('*', 'Whether this target is pinned (kept) even if it is not found in the current selection.\nPinned targets stay in the list so you can reuse them quickly.'): '選択中に見つからなくてもターゲットをリストに残す（ピン留め）かどうかです。\n'
                                                                                                                                                                            'ピン留めすると、後で素早く再利用できます。'}}


# --- Smart Modifier Switcher scene-wide/instance-list translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Stack Instances'): 'スタックインスタンス',
        ('*', 'Function: switches the Object List to the instance objects linked to the active item in the Modifier Stack.\nHow to use: select a modifier row in the Modifier Stack, then turn this ON to list every object sharing that modifier instance. When Base Object is active, the list shows objects sharing the base object instance or linked object data instead. Turn it OFF to return to the objects that own the selected Modifier List target.'): '機能：オブジェクト一覧を、モディファイアスタックでアクティブな項目とインスタンス関係にあるオブジェクトの表示へ切り替えます。\n使い方：モディファイアスタックでモディファイア行を選択してからONにすると、そのモディファイアインスタンスを共有している全オブジェクトを一覧表示します。ベースオブジェクトがアクティブな場合は、ベースオブジェクトのインスタンスまたはリンクデータを共有しているオブジェクトを表示します。OFFにすると、モディファイア一覧で選択した対象を持つオブジェクト一覧へ戻ります。',
        ('*', 'Modifier List now scans all modifiers in the scene and displays entries by modifier name/type.\nThis setting is kept for compatibility with saved layouts; scene-wide name/type listing is used for the renewed switcher.'): 'モディファイア一覧は、現在シーン内の全モディファイアをスキャンし、モディファイア名とタイプ単位で表示します。\nこの設定は保存済みレイアウトとの互換性のため残されていますが、新しい切り替え機能ではシーン全体の名前/タイプ一覧が使用されます。',
        ('*', 'Legacy scope selector kept for saved layouts.\nThe renewed Modifier Switcher lists all modifiers in the scene and shows every object that owns the selected modifier target.'): '保存済みレイアウトとの互換性のため残されている旧対象範囲セレクターです。\n新しいモディファイア切り替えでは、シーン内の全モディファイアを一覧化し、選択したモディファイア対象を持つ全オブジェクトを表示します。',
        ('*', 'Legacy visibility filter kept for saved layouts.\nThe renewed Modifier Switcher scans the full scene so the Modifier List can show all scene modifiers.'): '保存済みレイアウトとの互換性のため残されている旧表示フィルターです。\n新しいモディファイア切り替えでは、モディファイア一覧にシーン内の全モディファイアを表示するため、シーン全体をスキャンします。',
        ('*', 'Show all objects that own the selected scene modifier'): '選択中のシーンモディファイアを持つ全オブジェクトを表示します',
        ('*', 'Rebuild the scene-wide Modifier List and Object List.\nUse this after adding/removing/renaming modifiers, or when the UI looks out of date.\nTip: When Auto Refresh is ON, this runs automatically at the interval you set.'): 'シーン全体のモディファイア一覧とオブジェクト一覧を再構築します。\nモディファイアを追加・削除・リネームした後や、UI表示が古い場合に使用してください。\n自動更新がONの場合は、設定した間隔で自動実行されます。',
        ('*', 'No modifiers found in scene.'): 'シーン内にモディファイアが見つかりません。',
        ('*', 'Turn ON (enable) the active target for ALL matching objects in the scene.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: This does not add/remove modifiers — it only changes their ON/OFF and display states.'): 'シーン内で一致する全オブジェクトのアクティブ対象をON（有効）にします。\n有効化されている表示フラグ（ビューポート/編集/ケージ/レンダー/展開）のみ変更されます。\nモディファイアの追加や削除は行わず、ON/OFFと表示状態だけを変更します。',
        ('*', 'Turn OFF (disable) the active target for ALL matching objects in the scene.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: OFF is non-destructive; you can turn it ON again later.'): 'シーン内で一致する全オブジェクトのアクティブ対象をOFF（無効）にします。\n有効化されている表示フラグ（ビューポート/編集/ケージ/レンダー/展開）のみ変更されます。\nOFFは非破壊なので、後から再びONにできます。',
        ('*', 'Invert (toggle) the active target for ALL matching objects in the scene.\nObjects that are ON become OFF (and vice versa). Useful for quick comparisons.'): 'シーン内で一致する全オブジェクトのアクティブ対象を反転します。\nONの物はOFFに、OFFの物はONになります。素早い比較に便利です。',
        ('*', 'Tip: Combine with filters to quickly build a selection set.\n'): 'ヒント：フィルターと組み合わせると、選択セットを素早く作成できます。\n',
        ('*', 'This records the current modifier states of matching scene objects, so you can restore them later.\n'): 'シーン内で一致するオブジェクトの現在のモディファイア状態を記録し、後で復元できるようにします。\n',
        ('*', 'Load/apply the selected State Set to matching scene objects.\n'): '選択中の状態セットをシーン内で一致するオブジェクトへ読み込み/適用します。\n',
        ('*', 'Move the matching modifiers UP by one step for every matching object in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを1段上へ移動します。\n',
        ('*', 'Move the matching modifiers DOWN by one step for every matching object in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを1段下へ移動します。\n',
        ('*', 'Apply (bake) the matching modifiers for all matching objects in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを適用（ベイク）します。\n',
        ('*', 'Remove the matching modifiers from all matching objects in the scene.\n'): 'シーン内で一致する全オブジェクトから対象モディファイアを削除します。\n',
    })
except Exception:
    pass
# --- Smart Modifier Switcher scene-wide/instance-list translations END ---

# --- Modifier Management renewal translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Modifier Management'): 'モディファイア管理',
        ('*', 'Manage by Object'): 'オブジェクトから管理',
        ('*', 'Manage by Modifier'): 'モディファイアから管理',
        ('*', 'Management Mode'): '管理モード',
        ('*', "Switch how Modifier Management is organized.\nObject mode shows selected objects first and then their instance-related objects; the modifier list shows the selected objects' stack entries.\nModifier mode shows all scene modifiers first and then the objects that own the selected modifier."): 'モディファイア管理の構成を切り替えます。\nオブジェクトから管理では、選択中オブジェクトを先頭に、その下へ関連インスタンスオブジェクトを表示し、モディファイア一覧には選択中オブジェクトのスタック項目を表示します。\nモディファイアから管理では、シーン内の全モディファイアを先に表示し、選択中モディファイアを持つオブジェクトを下に表示します。',
        ('*', 'Show Object List above Modifier List and manage modifiers from the current object selection'): 'オブジェクト一覧をモディファイア一覧の上に表示し、現在のオブジェクト選択からモディファイアを管理します',
        ('*', 'Show Modifier List above Object List and manage objects from the selected scene modifier'): 'モディファイア一覧をオブジェクト一覧の上に表示し、選択中のシーンモディファイアからオブジェクトを管理します',
        ('*', 'No modifiers.'): 'モディファイアがありません。',
        ('*', 'Select Object'): 'オブジェクトを選択',
        ('*', 'Toggle Modifier Flag'): 'モディファイア表示を切り替え',
        ('*', 'Toggle the On Cage display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のケージ表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle whether this modifier row is visible in Edit Mode. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行を編集モードで表示するかを切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle the realtime Viewport display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のリアルタイムビューポート表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle the Render display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のレンダー表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
    })
except Exception:
    pass
# --- Modifier Management renewal translations END ---

# --- Modifier Management preference translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Enable Modifier Management'): 'モディファイア管理を使用',
        ('*', 'Modifier Management Section'): 'モディファイア管理セクション',
        ('*', 'Enable the Modifier Management panel/features.'): 'モディファイア管理のパネル/機能を有効にします。',
        ('*', 'Open or close the Modifier Management section in the unified Smart Modifier N-panel.'): '統合Smart Modifier Nパネル内のモディファイア管理セクションを開閉します。',
        ('*', 'Modifier Management Auto Update'): 'モディファイア管理 自動更新',
    })
except Exception:
    pass
# --- Modifier Management preference translations END ---

# --- Modifier Management verification/fix translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Object'): 'オブジェクト',
        ('*', 'Modifier'): 'モディファイア',
        ('*', 'Manual'): '手動',
        ('*', 'Realtime'): 'リアルタイム',
        ('*', 'Modifier Management List Update'): 'モディファイア管理リスト更新',
        ('*', 'Set Management Mode'): '管理モードを設定',
        ('*', 'Set Selected Modifier Viewport'): '選択モディファイアのビューポート表示を設定',
        ('*', 'Remove Selected Modifiers'): '選択モディファイアを削除',
        ('*', 'Turn ON viewport visibility for the selected Modifier List row on every object that owns that modifier. Instanced modifiers update together.'): 'モディファイア一覧で選択中の行を持つ全オブジェクトで、ビューポート表示をONにします。インスタンス化モディファイアは同時に更新されます。',
        ('*', 'Turn OFF viewport visibility for the selected Modifier List row on every object that owns that modifier. Instanced modifiers update together.'): 'モディファイア一覧で選択中の行を持つ全オブジェクトで、ビューポート表示をOFFにします。インスタンス化モディファイアは同時に更新されます。',
    })
except Exception:
    pass
# --- Modifier Management verification/fix translations END ---

# --- Modifier Management instance modifier selection translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Select Instance Modifier Objects'): 'インスタンスモディファイアを全選択',
        ('*', 'Select all objects that use the same instanced modifier as the selected Modifier List row.\nUse this from Object management mode when you want the viewport selection and Object List to switch to every object sharing that modifier instance.'): '機能：モディファイア一覧で選択中の行と同じインスタンスモディファイアを使用している全オブジェクトを選択します。\n使い方：オブジェクト管理モードで、同じモディファイアインスタンスを共有するオブジェクトへビューポート選択とオブジェクト一覧を切り替えたい時に使用します。',
        ('*', 'Select all objects that use the same instanced modifier as the selected Modifier List row.\nHow to use: select an instanced modifier in the Modifier List, then click this button. The objects are selected in the 3D View, and in Object management mode the Object List rebuilds from the current viewport selection.'): '機能：モディファイア一覧で選択中の行と同じインスタンスモディファイアを使用している全オブジェクトを選択します。\n使い方：モディファイア一覧でインスタンス化されたモディファイアを選び、このボタンをクリックします。対象オブジェクトが3Dビューで選択され、オブジェクト管理モードではオブジェクト一覧が現在のビューポート選択から再構築されます。',
        ('*', 'No instanced modifier objects.'): 'インスタンス化されたモディファイアを持つオブジェクトがありません。',
    })
except Exception:
    pass
# --- Modifier Management instance modifier selection translations END ---
