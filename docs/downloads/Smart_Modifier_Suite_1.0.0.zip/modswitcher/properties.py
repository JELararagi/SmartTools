# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - ライセンス: GPL-3.0-or-later（GNU 一般公衆利用許諾書 第 3 版以降）
# ------------------------------------------------------------------------------

# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import bpy

from . import core


def _persist_panel_state(context) -> None:
    try:
        from .. import persistent_state
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass


def _persist_only_update(self, context) -> None:
    _persist_panel_state(context)

# ------------------------------------------------------------
# Update callbacks
# ------------------------------------------------------------

def _rebuild_on_setting_change(self, context):
    _persist_panel_state(context)
    if context is None:
        return
    try:
        core.rebuild_lists(context, context.scene, force=True)
    except Exception:
        pass

def _update_object_list_only(self, context):
    _persist_panel_state(context)
    if context is None:
        return
    try:
        core.update_object_list(context, context.scene)
    except Exception:
        pass

def _on_target_index_change(self, context):
    _persist_panel_state(context)
    if context is None:
        return
    try:
        core.update_object_list(context, context.scene)
    except Exception:
        pass

def _on_obj_index_change(self, context):
    # Viewport selection is handled by modswitch.select_object_item so Shift/Ctrl
    # additive clicks can be detected from the UI event.  Keep this update
    # callback side-effect free to avoid changing selection during list rebuilds.
    _persist_panel_state(context)
    return


def _on_affect_editmode(self, context):
    """No dependency enforcement (match Smart Modifier UI behavior)."""
    _persist_panel_state(context)
    return

def _on_affect_on_cage(self, context):
    """No dependency enforcement (match Smart Modifier UI behavior)."""
    _persist_panel_state(context)
    return


def _on_auto_refresh_change(self, context):
    _persist_panel_state(context)
    try:
        desired = 'REALTIME' if bool(getattr(self, 'modswitch_auto_refresh', False)) else 'MANUAL'
        if hasattr(self, 'modswitch_refresh_mode') and str(getattr(self, 'modswitch_refresh_mode', '') or '') != desired:
            setattr(self, 'modswitch_refresh_mode', desired)
    except Exception:
        pass
    try:
        from . import ensure_autorefresh_timer_state
        ensure_autorefresh_timer_state(force_rebuild=bool(getattr(self, "modswitch_auto_refresh", False)))
    except Exception:
        pass


def _on_refresh_mode_change(self, context):
    _persist_panel_state(context)
    if context is None:
        return
    try:
        scene = context.scene
    except Exception:
        scene = None
    if scene is None:
        return
    try:
        # ``modswitch_auto_refresh`` is the canonical Always-on toggle.  The
        # legacy mode selector is a saved presentation choice and must not
        # silently reactivate polling while the canonical toggle is OFF.
        realtime = bool(getattr(scene, "modswitch_auto_refresh", False))
        from . import ensure_autorefresh_timer_state
        ensure_autorefresh_timer_state(force_rebuild=realtime)
    except Exception:
        pass

# ------------------------------------------------------------
# Property Groups
# ------------------------------------------------------------

class ModSwitchPinItem(bpy.types.PropertyGroup):
    key: bpy.props.StringProperty(
        name="Key",
        description=(
            "Internal key used to identify a pinned modifier target.\n"
            "This value is managed automatically."
        ),
        default="",
    )

class ModSwitchTargetItem(bpy.types.PropertyGroup):
    key: bpy.props.StringProperty(
        name="Key",
        description=(
            "Internal key used to identify this target entry.\n"
            "This value is managed automatically."
        ),
        default="",
    )
    mode: bpy.props.StringProperty(
        name="Mode",
        description=(
            "How the target is defined (by modifier TYPE or by modifier NAME).\n"
            "This is managed automatically based on the current target mode."
        ),
        default="TYPE",
    )
    mod_type: bpy.props.StringProperty(
        name="Type",
        description=(
            "Modifier type used when targeting by TYPE (example: SUBSURF, MIRROR).\n"
            "This is managed automatically."
        ),
        default="",
    )
    mod_name: bpy.props.StringProperty(
        name="Name",
        description=(
            "Modifier name used when targeting by NAME.\n"
            "This is managed automatically."
        ),
        default="",
    )
    label: bpy.props.StringProperty(
        name="Label",
        description=(
            "UI label shown in the target list.\n"
            "This is generated automatically."
        ),
        default="",
    )
    object_name: bpy.props.StringProperty(
        name="Object",
        description=(
            "Object that owns this modifier entry when Modifier Management is in object-based mode.\n"
            "This is generated automatically."
        ),
        default="",
    )
    modifier_index: bpy.props.IntProperty(
        name="Modifier Index",
        description=(
            "Stack index of the modifier when Modifier Management is in object-based mode.\n"
            "This is generated automatically."
        ),
        default=-1,
    )
    is_instance: bpy.props.BoolProperty(
        name="Instance",
        description=(
            "True when this modifier is part of an instanced modifier group.\n"
            "Instanced rows show the LINKED icon and state changes are synchronized across the group."
        ),
        default=False,
    )
    pinned: bpy.props.BoolProperty(
        name="Pinned",
        description=(
            "Whether this target is pinned (kept) even if it is not found in the current selection.\n"
            "Pinned targets stay in the list so you can reuse them quickly."
        ),
        default=False,
    )
    count_mods: bpy.props.IntProperty(
        name="Mods",
        description=(
            "How many matching modifiers were found for this target.\n"
            "This is calculated automatically when the list is rebuilt."
        ),
        default=0,
    )
    count_objects: bpy.props.IntProperty(
        name="Objects",
        description=(
            "How many objects contain matching modifiers for this target.\n"
            "This is calculated automatically when the list is rebuilt."
        ),
        default=0,
    )

class ModSwitchObjectItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="Object",
        description=(
            "Object name in the applied object list.\n"
            "This is generated automatically."
        ),
        default="",
    )
    count: bpy.props.IntProperty(
        name="Count",
        description=(
            "How many matching modifiers exist on this object for the current target.\n"
            "This is calculated automatically."
        ),
        default=0,
    )
    state: bpy.props.StringProperty(
        name="State",
        description=(
            "Combined state indicator (ON / OFF / MIXED).\n"
            "This is calculated automatically based on the selected visibility scope."
        ),
        default="OFF",
    )          # ON/OFF/MIXED
    viewport_state: bpy.props.StringProperty(
        name="Viewport",
        description=(
            "Viewport visibility indicator for this object (ON / OFF / MIXED).\n"
            "This is calculated automatically."
        ),
        default="",
    ) # ON/OFF/MIXED
    render_state: bpy.props.StringProperty(
        name="Render",
        description=(
            "Render visibility indicator for this object (ON / OFF / MIXED).\n"
            "This is calculated automatically."
        ),
        default="",
    )     # ON/OFF/MIXED
    is_instance: bpy.props.BoolProperty(
        name="Instance",
        description=(
            "True when this object shares its data (an instance) with another object in the list.\n"
            "Instances often share the same modifier stack."
        ),
        default=False,
    )

class ModSwitchStateRecord(bpy.types.PropertyGroup):
    obj_name: bpy.props.StringProperty()
    mod_type: bpy.props.StringProperty()
    mod_name: bpy.props.StringProperty()
    ordinal: bpy.props.IntProperty(default=0)

    show_viewport: bpy.props.BoolProperty(default=True)
    show_render: bpy.props.BoolProperty(default=True)
    show_in_editmode: bpy.props.BoolProperty(default=True)
    show_on_cage: bpy.props.BoolProperty(default=False)
    show_expanded: bpy.props.BoolProperty(default=False)

class ModSwitchStateSet(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(default="State")
    records: bpy.props.CollectionProperty(type=ModSwitchStateRecord)

# ------------------------------------------------------------
# Scene Properties
# ------------------------------------------------------------

def register_scene_props():
    bpy.types.Scene.modswitch_targets = bpy.props.CollectionProperty(type=ModSwitchTargetItem)
    bpy.types.Scene.modswitch_target_index = bpy.props.IntProperty(default=0, update=_on_target_index_change)

    bpy.types.Scene.modswitch_objects = bpy.props.CollectionProperty(type=ModSwitchObjectItem)
    bpy.types.Scene.modswitch_obj_index = bpy.props.IntProperty(default=0, update=_on_obj_index_change)


    bpy.types.Scene.modswitch_manage_mode = bpy.props.EnumProperty(
        name="Management Mode",
        description=(
            "Switch how Modifier Management is organized.\n"
            "Object mode shows selected objects first and then their instance-related objects; the modifier list shows the selected objects' stack entries.\n"
            "Modifier mode shows all scene modifiers first and then the objects that own the selected modifier."
        ),
        items=[
            ('OBJECT', "Object", "Show Object List above Modifier List and manage modifiers from the current object selection"),
            ('MODIFIER', "Modifier", "Show Modifier List above Object List and manage objects from the selected scene modifier"),
        ],
        default='OBJECT',
        update=_rebuild_on_setting_change,
    )

    bpy.types.Scene.modswitch_mode = bpy.props.EnumProperty(
        name="Mode",
        description=(
            "Modifier List now scans all modifiers in the scene and displays entries by modifier name/type.\n"
            "This setting is kept for compatibility with saved layouts; scene-wide name/type listing is used for the renewed switcher."
        ),
        items=[
            ('TYPE', "Type", "Group targets by modifier type (Mirror, Bevel, ...)"),
            ('NAME', "Name", "Group targets by modifier name (e.g. Bevel.001)"),
        ],
        default='TYPE',
        update=_rebuild_on_setting_change,
    )


    bpy.types.Scene.modswitch_scope = bpy.props.EnumProperty(
        name="Scope",
        description=(
            "Legacy scope selector kept for saved layouts.\n"
            "The renewed Modifier Switcher lists all modifiers in the scene and shows every object that owns the selected modifier target."
        ),
        items=[
            ('SCENE', "Scene", "All objects in the scene"),
            ('SELECTED', "Selected", "Currently selected objects"),
            ('SELECTED_CHILDREN', "Selected + Children", "Selected objects and their children"),
            ('ACTIVE_COLLECTION', "Active Collection", "Objects in the active collection"),
            ('COLLECTION', "Collection", "Objects in a specific collection"),
        ],
        default='SELECTED',
        update=_rebuild_on_setting_change,
    )


    def _scope_collection_setting_update(self, context):
        # A pending portable name is retained only while a saved Collection is
        # unavailable during file startup.  A direct user selection/clear is
        # authoritative and must discard that fallback before saving.
        try:
            from .. import persistent_state as _persistent_state
            clear_pending = getattr(_persistent_state, 'clear_pending_scope_collection_name', None)
            if callable(clear_pending):
                clear_pending()
        except Exception:
            pass
        _rebuild_on_setting_change(self, context)

    bpy.types.Scene.modswitch_scope_collection = bpy.props.PointerProperty(
        name="Collection",
        type=bpy.types.Collection,
        description=(
            "When Scope is set to 'Collection', pick the collection to use.\n"
            "Only objects in this collection will be listed/affected."
        ),
        update=_scope_collection_setting_update,
    )


    bpy.types.Scene.modswitch_visible_only = bpy.props.BoolProperty(
        name="Visible Only",
        description=(
            "Legacy visibility filter kept for saved layouts.\n"
            "The renewed Modifier Switcher scans the full scene so the Modifier List can show all scene modifiers."
        ),
        default=False,
        update=_rebuild_on_setting_change,
    )


    bpy.types.Scene.modswitch_filter_targets = bpy.props.StringProperty(
        name="Filter Targets",
        description=(
            "Search filter for the Modifier List.\n"
            "Type part of a modifier type/name to narrow the list (case-insensitive)."
        ),
        default="",
        update=_persist_only_update,
    )


    bpy.types.Scene.modswitch_filter_objects = bpy.props.StringProperty(
        name="Filter Objects",
        description=(
            "Search filter for the Object List.\n"
            "Type part of an object name to narrow the list (case-insensitive)."
        ),
        default="",
        update=_persist_only_update,
    )


    bpy.types.Scene.modswitch_show_objects = bpy.props.EnumProperty(
        name="Show Objects",
        description=(
            "Filter the Object List by the ON/OFF state of the selected target.\n"
            "The state is evaluated using the primary visibility flag (usually Viewport)."
        ),
        items=[
            ('ALL', "All", "Show all objects that own the selected scene modifier"),
            ('ENABLED', "Enabled Only", "Show only objects where the target is ON"),
            ('DISABLED', "Disabled Only", "Show only objects where the target is OFF"),
            ('MIXED', "Mixed", "Show objects with a mixed state (multiple matches)"),
        ],
        default='ALL',
        update=_update_object_list_only,
    )


    bpy.types.Scene.modswitch_show_stack_instances = bpy.props.BoolProperty(
        name="Stack Instances",
        description=(
            "Function: switches the Object List to the instance objects linked to the active item in the Modifier Stack.\n"
            "How to use: select a modifier row in the Modifier Stack, then turn this ON to list every object sharing that modifier instance. "
            "When Base Object is active, the list shows objects sharing the base object instance or linked object data instead. "
            "Turn it OFF to return to the objects that own the selected Modifier List target."
        ),
        default=False,
        update=_update_object_list_only,
    )


    bpy.types.Scene.modswitch_selection_behavior = bpy.props.EnumProperty(
        name="Selection Behavior",
        description=(
            "How clicking an item in the Object List affects viewport selection:\n"
            "- None: do not change the current selection\n"
            "- Single: deselect others and select the clicked object\n"
            "- Active Only: set active/selected without deselecting others"
        ),
        items=[
            ('NONE', "None", "Do not change viewport selection"),
            ('SINGLE', "Single", "Select only the clicked object (deselect others)"),
            ('ACTIVE_ONLY', "Active Only", "Set active object without clearing selection"),
        ],
        default='ACTIVE_ONLY',
        update=_persist_only_update,
    )

    # Affect flags (aligned with Smart Modifier's property buttons)

    bpy.types.Scene.modswitch_affect_on_cage = bpy.props.BoolProperty(
        name="On Cage",
        description=(
            "Affect the modifier's 'On Cage' flag when applying operations.\n"
            "This is mainly meaningful for deforming modifiers in Edit Mode."
        ),
        default=False,
        update=_update_object_list_only,
    )

    bpy.types.Scene.modswitch_affect_editmode = bpy.props.BoolProperty(
        name="Edit Mode",
        description=(
            "Affect the modifier's 'Show in Edit Mode' flag when applying operations.\n"
            "Useful for deforming modifiers you want active while editing the mesh."
        ),
        default=False,
        update=_update_object_list_only,
    )

    bpy.types.Scene.modswitch_affect_viewport = bpy.props.BoolProperty(
        name="Viewport",
        description=(
            "Affect the modifier's Viewport visibility flag when applying operations.\n"
            "This does NOT toggle the modifier by itself; it defines which flags\n"
            "are changed by Enable/Disable/Invert and State Sets."
        ),
        default=True,
        update=_update_object_list_only,
    )

    bpy.types.Scene.modswitch_affect_render = bpy.props.BoolProperty(
        name="Render",
        description=(
            "Affect the modifier's Render visibility flag when applying operations.\n"
            "Turn this ON if you want changes to affect final renders as well."
        ),
        default=False,
        update=_update_object_list_only,
    )

    bpy.types.Scene.modswitch_affect_expanded = bpy.props.BoolProperty(
        name="Expanded",
        description=(
            "Also affect the UI expanded/collapsed state of the modifier in Blender's\n"
            "modifier panel (triangle open/closed). Useful to tidy long stacks."
        ),
        default=False,
        update=_update_object_list_only,
    )

    # Pins
    bpy.types.Scene.modswitch_pins = bpy.props.CollectionProperty(type=ModSwitchPinItem)

    # State sets
    bpy.types.Scene.modswitch_state_sets = bpy.props.CollectionProperty(type=ModSwitchStateSet)
    bpy.types.Scene.modswitch_state_set_index = bpy.props.IntProperty(default=0, update=_persist_only_update)
    bpy.types.Scene.modswitch_new_state_set_name = bpy.props.StringProperty(
        name="New Set Name",
        description=(
            "Type a name for the new State Set.\n"
            "Use a short, clear name such as 'Preview OFF' or 'Render ON' so you can find it later easily.\n"
            "After typing, click '+' to save it as a new preset, or select an existing set and use Overwrite.\n"
            "State Sets only remember visibility/display buttons; they do not store modifier values or order."
        ),
        default="",
        update=_persist_only_update,
    )

    # Auto refresh

    bpy.types.Scene.modswitch_auto_refresh = bpy.props.BoolProperty(
        name="Auto Refresh",
        description=(
            "Function: keeps the Modifier Switcher target and object lists synchronized by running its auto-refresh timer while you work.\n"
            "How to use: enable it when selected objects and modifiers must be detected automatically. Disable it in heavy scenes or when you prefer pressing Update manually; the timer is stopped while disabled."
        ),
        default=False,
        update=_on_auto_refresh_change,
    )

    bpy.types.Scene.modswitch_refresh_mode = bpy.props.EnumProperty(
        name="Modifier Management List Update",
        description=(
            "Choose how Modifier Management refreshes its Object List and Modifier List.\n"
            "Manual updates only when you press Update List. Realtime refreshes automatically while object selection or modifier state changes."
        ),
        items=[
            ('MANUAL', "Manual", "Refresh lists only when Update List is pressed"),
            ('REALTIME', "Realtime", "Refresh lists automatically while the selection or stack contents change"),
        ],
        default='MANUAL',
        update=_on_refresh_mode_change,
    )

    bpy.types.Scene.modswitch_refresh_interval = bpy.props.FloatProperty(
        name="Refresh Interval",
        description=(
            "How often Auto Refresh runs (seconds).\n"
            "Increase this value to reduce CPU usage in heavy scenes."
        ),
        default=0.5,
        min=0.1,
        max=10.0,
        subtype='TIME',
        update=_persist_only_update,
    )

    # UI fold states (compact groups)

    bpy.types.Scene.modswitch_ui_show_modlist = bpy.props.BoolProperty(
        name="Show Modifier List",
        description=("Show/hide the Modifier List section.\n\nThis only folds the UI to save space; it does not change any modifiers."),
        default=True,
        update=_persist_only_update,
    )
    bpy.types.Scene.modswitch_ui_show_objlist = bpy.props.BoolProperty(
        name="Show Object List",
        description=("Show/hide the Object List section.\n\nThis only folds the UI to save space; it does not change selection or objects."),
        default=True,
        update=_persist_only_update,
    )
    bpy.types.Scene.modswitch_ui_show_statesets = bpy.props.BoolProperty(
        name="Show State Sets",
        description=("Show/hide the State Sets section.\n\nThis only folds the UI to save space; it does not apply any state sets by itself."),
        default=False,
        update=_persist_only_update,
    )
    bpy.types.Scene.modswitch_ui_show_details = bpy.props.BoolProperty(
        name="Show Details",
        description=("Show/hide the Details section.\n\nThis only folds the UI to save space."),
        default=False,
        update=_persist_only_update,
    )
    bpy.types.Scene.modswitch_ui_show_settings = bpy.props.BoolProperty(
        name="Show Settings",
        description=("Show/hide the Settings section.\n\nThis only folds the UI to save space."),
        default=False,
        update=_persist_only_update,
    )

    # Internal cache (do not store in .blend)
    bpy.types.Scene.modswitch_last_signature = bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})

def unregister_scene_props():
    for attr in [
        "modswitch_targets", "modswitch_target_index",
        "modswitch_objects", "modswitch_obj_index", "modswitch_manage_mode",
        "modswitch_mode", "modswitch_scope", "modswitch_scope_collection",
        "modswitch_visible_only", "modswitch_filter_targets", "modswitch_filter_objects",
        "modswitch_show_objects", "modswitch_show_stack_instances", "modswitch_selection_behavior",
        "modswitch_affect_on_cage", "modswitch_affect_editmode",
        "modswitch_affect_viewport", "modswitch_affect_render", "modswitch_affect_expanded",
        "modswitch_pins",
        "modswitch_state_sets", "modswitch_state_set_index", "modswitch_new_state_set_name",
        "modswitch_auto_refresh", "modswitch_refresh_mode", "modswitch_refresh_interval",
        "modswitch_ui_show_modlist", "modswitch_ui_show_objlist", "modswitch_ui_show_statesets",
        "modswitch_ui_show_details", "modswitch_ui_show_settings",
        "modswitch_last_signature",
    ]:
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
