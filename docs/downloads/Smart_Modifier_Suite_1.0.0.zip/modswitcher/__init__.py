# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

# ------------------------------------------------------------------------------
#  Modifier Switcher (embedded into Smart Modifier)
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  NOTE:
#  - This module is embedded into Smart Modifier and does NOT register its own N-panel tab.
#  - Panels are provided by Smart Modifier (ui.py) as child panels at the bottom.
# ------------------------------------------------------------------------------

# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
from __future__ import annotations

import bpy

from .. import feature_toggle as _feature_toggle
# i18n (Japanese/English)
_translation_catalogs = getattr(bpy.app, "translations", None)
from .translation import translation_catalog_dict as _translation_catalog_dict
import time

from . import translation as i18n, properties as props, core, operators as ops, ui

# ------------------------------------------------------------
# Auto refresh
# ------------------------------------------------------------

_TIMER_RUNNING = False
_last_refresh = {}

def _pref_allows_modswitcher() -> bool:
    """Return False when the Smart Modifier N-panel setting disables Modifier Switcher."""
    try:
        from ..preferences import get_preferences
        prefs = get_preferences(getattr(bpy, 'context', None))
        if prefs is not None and hasattr(prefs, "use_modifier_switcher"):
            return bool(prefs.use_modifier_switcher)
    except Exception:
        pass
    try:
        from ..core import _ms_get_addon_prefs
        prefs = _ms_get_addon_prefs(bpy.context)
        if prefs and hasattr(prefs, "use_modifier_switcher"):
            return bool(prefs.use_modifier_switcher)
    except Exception:
        pass
    return True



def _scene_requests_autorefresh(scene) -> bool:
    try:
        mode = str(getattr(scene, "modswitch_refresh_mode", "") or "")
        if mode:
            return mode == "REALTIME"
    except Exception:
        pass
    try:
        return bool(getattr(scene, "modswitch_auto_refresh", False))
    except Exception:
        return False


def _any_scene_requests_autorefresh() -> bool:
    try:
        if not _pref_allows_modswitcher():
            return False
    except Exception:
        return False
    try:
        for scene in getattr(bpy.data, "scenes", []):
            try:
                # The centralized Always-on toggle is the sole authority for
                # background polling.  ``modswitch_refresh_mode`` is retained
                # only as a saved presentation/compatibility choice.
                if bool(getattr(scene, "modswitch_auto_refresh", False)):
                    return True
            except Exception:
                continue
    except Exception:
        return False
    return False


def _render_or_viewport_job_running() -> bool:
    """Avoid Modifier Switcher RNA list writes while Blender is rendering."""
    try:
        is_job_running = getattr(getattr(bpy, 'app', None), 'is_job_running', None)
        if not callable(is_job_running):
            return False
        for job_name in ('RENDER', 'VIEWPORT_RENDER', 'RENDER_PREVIEW', 'COMPOSITE'):
            try:
                if bool(is_job_running(job_name)):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _scene_refresh_interval(scene) -> float:
    try:
        return max(0.25, min(10.0, float(getattr(scene, 'modswitch_refresh_interval', 0.7))))
    except Exception:
        return 0.7


def ensure_autorefresh_timer_state(force_rebuild: bool = False):
    global _TIMER_RUNNING
    want = bool(_any_scene_requests_autorefresh())
    _TIMER_RUNNING = want

    is_registered = False
    try:
        if hasattr(bpy.app.timers, "is_registered"):
            is_registered = bool(bpy.app.timers.is_registered(_autorefresh_timer))
    except Exception:
        is_registered = False

    if want and not is_registered:
        try:
            bpy.app.timers.register(_autorefresh_timer, persistent=True)
            is_registered = True
        except Exception:
            is_registered = False
    elif (not want) and is_registered:
        try:
            bpy.app.timers.unregister(_autorefresh_timer)
        except Exception:
            pass
        is_registered = False

    if force_rebuild and want:
        try:
            ctx = bpy.context
            if getattr(ctx, "scene", None) is not None:
                core.rebuild_lists(ctx, ctx.scene, force=True)
        except Exception:
            pass

    return is_registered


def _autorefresh_timer():
    global _TIMER_RUNNING, _last_refresh
    if (not _TIMER_RUNNING) or (not _any_scene_requests_autorefresh()):
        _TIMER_RUNNING = False
        return None

    next_interval = 1.0
    try:
        if not _pref_allows_modswitcher():
            return 1.0
        ctx = bpy.context
        scene = ctx.scene
        if scene and (bool(getattr(scene, "modswitch_auto_refresh", False)) or str(getattr(scene, "modswitch_refresh_mode", "MANUAL") or "MANUAL") == "REALTIME"):
            interval = _scene_refresh_interval(scene)
            next_interval = interval
            if _render_or_viewport_job_running():
                return max(0.5, interval)
            now = time.time()
            key = scene.as_pointer()
            last = _last_refresh.get(key, 0.0)
            remaining = interval - (now - last)
            if remaining <= 0.0:
                # Rebuild lists only if a tracked signature actually changed.
                # The rebuild path must not clear/refill RNA collections while idle,
                # because those writes invalidate active render previews.
                core.rebuild_lists(ctx, scene, force=False)
                _last_refresh[key] = now
                remaining = interval
            next_interval = max(0.25, min(interval, remaining))
    except Exception:
        pass

    return max(0.25, float(next_interval))

# ------------------------------------------------------------
# Registration
# ------------------------------------------------------------

CLASSES = [
    # props
    props.ModSwitchPinItem,
    props.ModSwitchTargetItem,
    props.ModSwitchObjectItem,
    props.ModSwitchStateRecord,
    props.ModSwitchStateSet,

    # operators
    ops.MODSWITCH_OT_SetManageMode,
    ops.MODSWITCH_OT_TargetBulkAction,
    ops.MODSWITCH_OT_TargetViewportState,
    ops.MODSWITCH_OT_UpdateList,
    ops.MODSWITCH_OT_RemoveSelectedTargetModifiers,
    ops.MODSWITCH_OT_SetSelectedTargetViewport,
    ops.MODSWITCH_OT_SelectObjectItem,
    ops.MODSWITCH_OT_ToggleModifierFlag,
    ops.MODSWITCH_OT_ToggleAll,
    ops.MODSWITCH_OT_ToggleOne,
    ops.MODSWITCH_OT_SelectAllListed,
    ops.MODSWITCH_OT_SelectInstanceModifierObjects,
    ops.MODSWITCH_OT_TogglePin,
    ops.MODSWITCH_OT_SaveStateNew,
    ops.MODSWITCH_OT_SaveStateOverwrite,
    ops.MODSWITCH_OT_ApplyState,
    ops.MODSWITCH_OT_DeleteState,
    ops.MODSWITCH_OT_MoveMods,
    ops.MODSWITCH_OT_ApplyMods,
    ops.MODSWITCH_OT_RemoveMods,

    # UILists
    ui.MODSWITCH_UL_Targets,
    ui.MODSWITCH_UL_Objects,
    ui.MODSWITCH_UL_StateSets,
]



def _expand_translation_catalog_contexts(translation_catalog_dict):
    """Mirror translation_catalogs between default and operator contexts if missing."""
    try:
        from bpy.app.translations import contexts as i18n_contexts
    except Exception:
        return translation_catalog_dict

    ctx_default = i18n_contexts.default
    ctx_operator = i18n_contexts.operator_default

    expanded = {}
    for lang, table in (translation_catalog_dict or {}).items():
        if not isinstance(table, dict):
            continue
        new_table = dict(table)
        for key, value in list(table.items()):
            if not (isinstance(key, tuple) and len(key) == 2 and isinstance(key[1], str)):
                continue
            ctx, msgid = key
            if ctx == ctx_default and (ctx_operator, msgid) not in new_table:
                new_table[(ctx_operator, msgid)] = value
            elif ctx == ctx_operator and (ctx_default, msgid) not in new_table:
                new_table[(ctx_default, msgid)] = value
        expanded[lang] = new_table
    return expanded

def register():
    # Register translation_catalogs for this submodule.
    try:
        _translation_catalogs.register(__name__, _expand_translation_catalog_contexts(_translation_catalog_dict))
    except Exception:
        pass

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass

    try:
        props.register_scene_props()
    except Exception:
        pass


    try:
        with _feature_toggle.capture_runtime('modswitcher', 'Modifier Switcher'):
            ensure_autorefresh_timer_state(force_rebuild=False)
    except Exception:
        pass

def unregister():
    # Stop timer (it will self-terminate on next tick)
    global _TIMER_RUNNING
    _TIMER_RUNNING = False
    try:
        if hasattr(bpy.app.timers, "is_registered") and bpy.app.timers.is_registered(_autorefresh_timer):
            bpy.app.timers.unregister(_autorefresh_timer)
    except Exception:
        pass

    try:
        props.unregister_scene_props()
    except Exception:
        pass

    # Unregister translation_catalogs.
    try:
        _translation_catalogs.unregister(__name__)
    except Exception:
        pass

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
