# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - ライセンス: GPL-3.0-or-later（GNU 一般公衆利用許諾書 第 3 版以降）
# ------------------------------------------------------------------------------

# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import bpy
import time
import zlib
from typing import Dict, List, Optional, Tuple, Iterable, Set
from ..translation import pgettext as _sms_pgettext

# ------------------------------------------------------------
# Helpers (safe attribute set)
# ------------------------------------------------------------

def _safe_set_attr(obj, attr: str, value: bool) -> None:
    if hasattr(obj, attr):
        try:
            setattr(obj, attr, value)
        except Exception:
            pass

def _safe_get_attr(obj, attr: str, default=None):
    if hasattr(obj, attr):
        try:
            return getattr(obj, attr)
        except Exception:
            return default
    return default

def type_label(mod_type: str) -> str:
    return mod_type.replace("_", " ").title()


def modifier_icon_for_target(target) -> str:
    """Return a lightweight Blender icon name for a Modifier Management target."""
    try:
        mod_type = str(getattr(target, 'mod_type', '') or '')
        mod_name = str(getattr(target, 'mod_name', '') or '')
        key_text = (mod_name + ' ' + str(getattr(target, 'label', '') or '')).casefold()
        # Custom Smart Modifier / Max-equivalent hints first.
        if 'slice' in key_text or 'スライス' in key_text:
            return 'SNAP_FACE' if False else 'MOD_BOOLEAN'
        if 'lattice' in key_text or 'ffd' in key_text or 'ラティス' in key_text:
            return 'MOD_LATTICE'
        if 'edit polygon' in key_text or '編集ポリゴン' in key_text or 'edit poly' in key_text:
            return 'MESH_DATA'
        if 'mirror' in key_text or 'ミラー' in key_text or 'symmetry' in key_text:
            return 'MOD_MIRROR'
    except Exception:
        mod_type = ''
    mapping = {
        'ARRAY': 'MOD_ARRAY', 'BEVEL': 'MOD_BEVEL', 'BOOLEAN': 'MOD_BOOLEAN', 'BUILD': 'MODIFIER',
        'DECIMATE': 'MOD_DECIM', 'EDGE_SPLIT': 'MOD_EDGESPLIT', 'MASK': 'MOD_MASK', 'MIRROR': 'MOD_MIRROR',
        'MULTIRES': 'MOD_MULTIRES', 'REMESH': 'MOD_REMESH', 'SCREW': 'MOD_SCREW', 'SKIN': 'MOD_SKIN',
        'SOLIDIFY': 'MOD_SOLIDIFY', 'SUBSURF': 'MOD_SUBSURF', 'TRIANGULATE': 'MOD_TRIANGULATE',
        'WELD': 'AUTOMERGE_ON', 'WIREFRAME': 'MOD_WIREFRAME', 'ARMATURE': 'MOD_ARMATURE',
        'CAST': 'MOD_CAST', 'CURVE': 'MOD_CURVE', 'DISPLACE': 'MOD_DISPLACE', 'HOOK': 'HOOK',
        'LAPLACIANDEFORM': 'MOD_MESHDEFORM', 'LATTICE': 'MOD_LATTICE', 'MESH_DEFORM': 'MOD_MESHDEFORM',
        'SHRINKWRAP': 'MOD_SHRINKWRAP', 'SIMPLE_DEFORM': 'MOD_SIMPLEDEFORM', 'SMOOTH': 'MOD_SMOOTH',
        'CORRECTIVE_SMOOTH': 'MOD_SMOOTH', 'LAPLACIANSMOOTH': 'MOD_SMOOTH', 'SURFACE_DEFORM': 'MOD_MESHDEFORM',
        'WARP': 'MOD_SIMPLEDEFORM', 'WAVE': 'MOD_WAVE', 'VOLUME_DISPLACE': 'MOD_DISPLACE',
        'WEIGHTED_NORMAL': 'MOD_NORMALEDIT', 'NORMAL_EDIT': 'MOD_NORMALEDIT', 'NODES': 'MOD_NODES',
        'CLOTH': 'MOD_CLOTH', 'COLLISION': 'MOD_PHYSICS', 'DYNAMIC_PAINT': 'MOD_DYNAMICPAINT',
        'EXPLODE': 'MOD_EXPLODE', 'FLUID': 'MOD_FLUIDSIM', 'OCEAN': 'MOD_OCEAN',
        'PARTICLE_INSTANCE': 'MOD_PARTICLES', 'PARTICLE_SYSTEM': 'PARTICLES', 'SOFT_BODY': 'MOD_SOFT',
        'MESH_TO_VOLUME': 'VOLUME_DATA', 'VOLUME_TO_MESH': 'MESH_DATA', 'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
        'MESH_CACHE': 'MESH_DATA', 'MESH_SEQUENCE_CACHE': 'MESH_DATA', 'UV_PROJECT': 'MOD_UVPROJECT',
        'UV_WARP': 'MOD_UVPROJECT', 'VERTEX_WEIGHT_EDIT': 'GROUP_VERTEX', 'VERTEX_WEIGHT_MIX': 'GROUP_VERTEX',
        'VERTEX_WEIGHT_PROXIMITY': 'GROUP_VERTEX',
    }
    return mapping.get(str(mod_type or ''), 'MODIFIER')

def target_key_from_modifier(mode: str, mod) -> str:
    """Return the scene-wide Modifier Switcher target key.

    The renewed Modifier Switcher lists actual modifier entries that exist in
    the scene, not only the active selection/scope.  Grouping is therefore by
    modifier type + name so duplicate objects that share the same modifier entry
    name are collected together, while different modifier names of the same type
    remain separate list entries.
    """
    try:
        return f"N|{mod.type}|{mod.name}"
    except Exception:
        return "N||"

def parse_target_key(key: str) -> Tuple[str, str, str]:
    # returns (mode, mod_type, mod_name)
    parts = key.split("|", 2)
    if not parts:
        return ('TYPE', '', '')
    if parts[0] == 'N':
        mod_type = parts[1] if len(parts) > 1 else ''
        rest = parts[2] if len(parts) > 2 else ''
        return ('NAME', mod_type, rest)
    # 'T'
    mod_type = parts[1] if len(parts) > 1 else ''
    return ('TYPE', mod_type, '')

def get_active_collection(context) -> Optional[bpy.types.Collection]:
    try:
        lc = context.view_layer.active_layer_collection
        if lc:
            return lc.collection
    except Exception:
        pass
    return None

def is_obj_visible(obj, view_layer) -> bool:
    # robust visible check
    try:
        return obj.visible_get(view_layer=view_layer)
    except Exception:
        try:
            # fallback
            return (not obj.hide_viewport) and (not obj.hide_get())
        except Exception:
            return True

def _iter_scene_modifier_switcher_objects(context, scene) -> List[bpy.types.Object]:
    """Return all scene objects that can participate in Modifier Switcher lists.

    The list intentionally ignores the old Scope setting.  The current design is
    scene-wide: the Modifier List shows all modifiers found in the scene, and the
    Object List shows every object that owns the selected modifier target.
    """
    try:
        raw_objects = list(getattr(scene, "objects", []) or [])
    except Exception:
        try:
            raw_objects = list(getattr(bpy.data, "objects", []) or [])
        except Exception:
            raw_objects = []

    out = []
    seen = set()
    for obj in raw_objects:
        if obj is None:
            continue
        try:
            name = str(getattr(obj, "name", "") or "")
        except Exception:
            name = ""
        if name and name in seen:
            continue
        try:
            mods = getattr(obj, "modifiers", None)
        except Exception:
            mods = None
        if mods is None:
            continue
        if name:
            seen.add(name)
        out.append(obj)
    return out


def iter_scope_objects(context, scene) -> List[bpy.types.Object]:
    # Compatibility wrapper retained for existing operators/state-set code.
    # Modifier Switcher now scans the full scene rather than a user scope.
    return _iter_scene_modifier_switcher_objects(context, scene)

def compute_scope_signature(mode: str, objects: Iterable[bpy.types.Object]) -> int:
    # Stable across session using adler32 of bytes
    pieces = []
    pieces.append(mode)
    for obj in sorted(objects, key=lambda x: x.name):
        try:
            mods = obj.modifiers
        except Exception:
            continue
        pieces.append(obj.name)
        for m in mods:
            pieces.append(m.type)
            pieces.append(m.name)
    data = "\n".join(pieces).encode("utf-8", errors="ignore")
    # NOTE: Blender RNA IntProperty is a signed 32-bit int.
    # adler32 returns an unsigned 32-bit value which can exceed 2,147,483,647.
    # Keep it within signed range to avoid ValueError on assignment.
    return int(zlib.adler32(data) & 0x7fffffff)

def is_pinned(scene, key: str) -> bool:
    for p in scene.modswitch_pins:
        if p.key == key:
            return True
    return False

def set_pinned(scene, key: str, pinned: bool) -> None:
    if pinned:
        if is_pinned(scene, key):
            return
        p = scene.modswitch_pins.add()
        p.key = key
        return
    # remove
    for i, p in enumerate(scene.modswitch_pins):
        if p.key == key:
            scene.modswitch_pins.remove(i)
            break

def build_target_label(mode: str, mod_type: str, mod_name: str) -> str:
    if mode == 'NAME':
        return f"{mod_name} ({type_label(mod_type)})"
    return type_label(mod_type)


# ------------------------------------------------------------
# Renewed Modifier Management helpers
# ------------------------------------------------------------

def management_mode(scene) -> str:
    try:
        mode = str(getattr(scene, "modswitch_manage_mode", "OBJECT") or "OBJECT")
    except Exception:
        mode = "OBJECT"
    return "MODIFIER" if mode == "MODIFIER" else "OBJECT"


def _selected_main_objects(context, scene) -> List[bpy.types.Object]:
    smart_core = _smart_core_module()
    raw = []
    try:
        raw = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        raw = []
    try:
        active = getattr(context, "active_object", None) or getattr(getattr(getattr(context, "view_layer", None), "objects", None), "active", None)
    except Exception:
        active = None
    if active is not None and active not in raw:
        raw.insert(0, active)
    if active is not None and active in raw:
        raw = [active] + [o for o in raw if o is not active]
    out = []
    seen = set()
    for obj in raw:
        if obj is None:
            continue
        main = obj
        if smart_core is not None:
            try:
                fn = getattr(smart_core, "get_main_object", None)
                if callable(fn):
                    main = fn(obj) or obj
            except Exception:
                main = obj
        try:
            name = str(getattr(main, "name", "") or "")
        except Exception:
            name = ""
        if not name or name in seen:
            continue
        try:
            if not hasattr(main, "modifiers"):
                continue
        except Exception:
            continue
        seen.add(name)
        out.append(main)
    return out


def _stack_owner_for_object(obj, context=None, *, create=False):
    if obj is None:
        return None
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "ms_get_modifier_stack_object", None)
            if callable(fn):
                stack_obj = fn(obj, context=context, create=bool(create))
                if stack_obj is not None:
                    return stack_obj
        except Exception:
            pass
    return obj


def _display_object_for_stack_owner(obj):
    """Return the user-facing source object for a Smart Modifier stack owner."""
    if obj is None:
        return None
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            is_proxy = getattr(smart_core, "ms_is_shape_mesh_proxy", None)
            source_fn = getattr(smart_core, "ms_shape_proxy_source", None)
            if callable(is_proxy) and callable(source_fn) and is_proxy(obj):
                source = source_fn(obj)
                if source is not None:
                    return source
        except Exception:
            pass
    return _main_object_for_display(obj) or obj


def _iter_scene_display_stack_pairs(context, scene):
    """Yield (display_object, stack_owner) pairs for scene-wide management."""
    seen = set()
    for obj in _iter_scene_modifier_switcher_objects(context, scene):
        display_obj = _display_object_for_stack_owner(obj)
        if display_obj is None:
            continue
        try:
            dname = str(getattr(display_obj, "name", "") or "")
        except Exception:
            dname = ""
        if not dname or dname in seen:
            continue
        stack_obj = _stack_owner_for_object(display_obj, context=context, create=False) or obj
        if stack_obj is None or not hasattr(stack_obj, "modifiers"):
            continue
        seen.add(dname)
        yield display_obj, stack_obj


def _iter_stack_modifiers_for_object(obj, context=None):
    stack_obj = _stack_owner_for_object(obj, context=context, create=False) or obj
    if stack_obj is None or not hasattr(stack_obj, "modifiers"):
        return []
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "ms_iter_visible_stack_modifiers", None)
            if callable(fn):
                mods = list(fn(stack_obj, context=context) or [])
                return [(stack_obj, mod, stack_obj.modifiers.find(mod.name)) for mod in mods if mod is not None]
        except Exception:
            pass
    out = []
    try:
        for i, mod in enumerate(list(getattr(stack_obj, "modifiers", []) or [])):
            if smart_core is not None:
                try:
                    skip = getattr(smart_core, "ms_modifier_is_internal_stack_helper", None)
                    if callable(skip) and skip(mod):
                        continue
                except Exception:
                    pass
            out.append((stack_obj, mod, i))
    except Exception:
        pass
    return out


def _modifier_instance_id(obj, mod) -> str:
    smart_core = _smart_core_module()
    if smart_core is None or obj is None or mod is None:
        return ""
    try:
        fn = getattr(smart_core, "ms_get_instance_id", None)
        if callable(fn):
            return str(fn(mod, obj) or "")
    except Exception:
        pass
    return ""


def _modifier_is_instanced(obj, mod) -> bool:
    smart_core = _smart_core_module()
    if smart_core is None or obj is None or mod is None:
        return False
    try:
        fn = getattr(smart_core, "ms_is_instance_modifier", None)
        if callable(fn) and fn(mod, obj):
            return True
    except Exception:
        pass
    return bool(_modifier_instance_id(obj, mod))


def _main_object_for_display(obj):
    if obj is None:
        return None
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "get_main_object", None)
            if callable(fn):
                return fn(obj) or obj
        except Exception:
            pass
    return obj


def _modswitch_modifier_state_signature(mod) -> str:
    try:
        return "|".join((
            str(getattr(mod, "type", "") or ""),
            str(getattr(mod, "name", "") or ""),
            "V1" if bool(getattr(mod, "show_viewport", True)) else "V0",
            "R1" if bool(getattr(mod, "show_render", True)) else "R0",
            "E1" if bool(getattr(mod, "show_in_editmode", False)) else "E0",
            "C1" if bool(getattr(mod, "show_on_cage", False)) else "C0",
            "X1" if bool(getattr(mod, "show_expanded", False)) else "X0",
        ))
    except Exception:
        return ""


def _object_mode_signature(context, scene, objects: Iterable[bpy.types.Object]) -> int:
    pieces = ["OBJECT"]
    try:
        active = getattr(context, "active_object", None)
        pieces.append("ACTIVE:" + str(getattr(active, "name", "") or ""))
    except Exception:
        pass
    try:
        selected = [str(getattr(o, "name", "") or "") for o in (getattr(context, "selected_objects", []) or [])]
        pieces.append("SELECTED:" + ",".join(sorted(selected)))
    except Exception:
        pass
    try:
        pieces.append("TARGET_INDEX:" + str(int(getattr(scene, "modswitch_target_index", 0) or 0)))
        pieces.append("OBJ_FILTER:" + str(getattr(scene, "modswitch_filter_objects", "") or ""))
        pieces.append("SHOW_OBJECTS:" + str(getattr(scene, "modswitch_show_objects", "") or ""))
        pieces.append("STACK_INSTANCES:" + str(bool(getattr(scene, "modswitch_show_stack_instances", False))))
    except Exception:
        pass
    for obj in objects:
        try:
            pieces.append("OBJ:" + obj.name)
        except Exception:
            continue
        try:
            for rel in _collect_active_base_instance_objects(context, scene, obj):
                pieces.append("BASE_REL:" + str(getattr(rel, "name", "") or ""))
        except Exception:
            pass
        try:
            smart_core = _smart_core_module()
            pieces.append("BASE_IID:" + str((smart_core.ms_get_object_instance_id(obj) if smart_core is not None else "") or ""))
        except Exception:
            pass
        try:
            data_block = getattr(obj, "data", None)
            pieces.append("DATA_PTR:" + (str(data_block.as_pointer()) if data_block is not None and hasattr(data_block, "as_pointer") else ""))
            pieces.append("DATA_USERS:" + str(int(getattr(data_block, "users", 0) or 0)) if data_block is not None else "DATA_USERS:0")
        except Exception:
            pass
        for stack_obj, mod, idx in _iter_stack_modifiers_for_object(obj, context=context):
            try:
                pieces.append(f"MOD:{getattr(stack_obj,'name','')}:{idx}:{_modswitch_modifier_state_signature(mod)}:{_modifier_instance_id(stack_obj, mod)}")
            except Exception:
                pass
    data = "\n".join(pieces).encode("utf-8", errors="ignore")
    return int(zlib.adler32(data) & 0x7fffffff)


def _add_target_item(scene, *, key, mode, mod_type, mod_name, label, object_name="", modifier_index=-1, count_mods=1, count_objects=1, is_instance=False):
    item = scene.modswitch_targets.add()
    item.key = str(key or "")
    item.mode = str(mode or "")
    item.mod_type = str(mod_type or "")
    item.mod_name = str(mod_name or "")
    item.label = str(label or mod_name or type_label(mod_type))
    try:
        item.object_name = str(object_name or "")
    except Exception:
        pass
    try:
        item.modifier_index = int(modifier_index)
    except Exception:
        pass
    try:
        item.count_mods = int(count_mods)
        item.count_objects = int(count_objects)
    except Exception:
        pass
    try:
        item.is_instance = bool(is_instance)
    except Exception:
        pass
    try:
        item.pinned = False
    except Exception:
        pass
    return item


def _collect_related_instance_objects(context, scene, selected_main_objs):
    """Return only object/base-instance relatives for Object management mode.

    Modifier Management's Object mode must mirror the viewport object selection:
    selected objects are listed first, followed only by objects that are instanced
    from those objects at the object/base-data level.  Modifier-instance groups are
    intentionally ignored here; they are selected explicitly through
    select_target_instance_modifier_objects().
    """
    selected_names = {str(getattr(o, "name", "") or "") for o in selected_main_objs if o is not None}
    out = []
    seen = set(selected_names)

    def add(obj):
        main = _main_object_for_display(obj)
        if main is None:
            return
        try:
            name = str(getattr(main, "name", "") or "")
        except Exception:
            name = ""
        if not name or name in seen:
            return
        seen.add(name)
        out.append(main)

    for obj in selected_main_objs:
        for rel in _collect_active_base_instance_objects(context, scene, obj):
            add(rel)
    return sorted(out, key=lambda o: str(getattr(o, "name", "") or "").lower())


def _rebuild_object_mode_lists(context, scene, force: bool = False) -> bool:
    selected = _selected_main_objects(context, scene)
    sig = _object_mode_signature(context, scene, selected)
    old_key = ""
    try:
        if 0 <= scene.modswitch_target_index < len(scene.modswitch_targets):
            old_key = scene.modswitch_targets[scene.modswitch_target_index].key
    except Exception:
        old_key = ""

    if (not force) and int(getattr(scene, "modswitch_last_signature", 0) or 0) == sig:
        return False

    scene.modswitch_targets.clear()
    seen_instance_ids = set()
    seen_plain = set()
    for obj in selected:
        for stack_obj, mod, idx in _iter_stack_modifiers_for_object(obj, context=context):
            if mod is None:
                continue
            iid = _modifier_instance_id(stack_obj, mod)
            if iid:
                if iid in seen_instance_ids:
                    continue
                seen_instance_ids.add(iid)
            else:
                plain_key = (str(getattr(stack_obj, "name", "") or ""), int(idx), str(getattr(mod, "name", "") or ""))
                if plain_key in seen_plain:
                    continue
                seen_plain.add(plain_key)
            key = f"O|{getattr(stack_obj, 'name', '')}|{int(idx)}|{getattr(mod, 'type', '')}|{getattr(mod, 'name', '')}"
            _add_target_item(
                scene,
                key=key,
                mode="OBJECT",
                mod_type=getattr(mod, "type", ""),
                mod_name=getattr(mod, "name", ""),
                label=getattr(mod, "name", "") or type_label(getattr(mod, "type", "")),
                object_name=getattr(stack_obj, "name", ""),
                modifier_index=int(idx),
                count_mods=1,
                count_objects=1,
                is_instance=bool(iid),
            )

    new_index = 0
    if old_key:
        for i, it in enumerate(scene.modswitch_targets):
            if it.key == old_key:
                new_index = i
                break
    try:
        scene.modswitch_target_index = min(max(0, new_index), max(0, len(scene.modswitch_targets) - 1))
    except Exception:
        pass
    scene.modswitch_last_signature = sig
    update_object_list(context, scene)
    return True

def _rebuild_modifier_mode_lists(context, scene, force: bool = False) -> bool:
    """Rebuild the scene-wide modifier list and the dependent object list."""
    # Modifier Management's modifier-first mode lists concrete modifier entries by
    # modifier name + type.  The legacy modswitch_mode setting is kept only for
    # compatibility with saved layouts and must not collapse the list to TYPE.
    mode = "NAME"
    pairs = list(_iter_scene_display_stack_pairs(context, scene))

    pieces = [str(mode), str(management_mode(scene))]
    try:
        pieces.append("TARGET_INDEX:" + str(int(getattr(scene, "modswitch_target_index", 0) or 0)))
        pieces.append("OBJ_FILTER:" + str(getattr(scene, "modswitch_filter_objects", "") or ""))
        pieces.append("TARGET_FILTER:" + str(getattr(scene, "modswitch_filter_targets", "") or ""))
        pieces.append("SHOW_OBJECTS:" + str(getattr(scene, "modswitch_show_objects", "") or ""))
        pieces.append("SCOPE:" + str(getattr(scene, "modswitch_scope", "") or ""))
        pieces.append("VISIBLE_ONLY:" + str(bool(getattr(scene, "modswitch_visible_only", False))))
    except Exception:
        pass
    for display_obj, stack_obj in sorted(pairs, key=lambda p: getattr(p[0], "name", "")):
        try:
            pieces.append("D:" + display_obj.name + "|S:" + stack_obj.name)
        except Exception:
            pass
        for owner, mod, idx in _iter_stack_modifiers_for_object(display_obj, context=context):
            try:
                pieces.append("M:%s|%s|%s|%s" % (owner.name, idx, _modswitch_modifier_state_signature(mod), _modifier_instance_id(owner, mod)))
            except Exception:
                pass
    sig = int(zlib.adler32("\n".join(pieces).encode("utf-8", errors="ignore")) & 0x7fffffff)

    if (not force) and (scene.modswitch_last_signature == sig):
        return False

    old_key = ""
    if 0 <= scene.modswitch_target_index < len(scene.modswitch_targets):
        old_key = scene.modswitch_targets[scene.modswitch_target_index].key

    target_info: Dict[str, Dict] = {}
    for display_obj, stack_obj in pairs:
        for owner, mod, idx in _iter_stack_modifiers_for_object(display_obj, context=context):
            key = target_key_from_modifier(mode, mod)
            info = target_info.get(key)
            if not info:
                t_mode, t_type, t_name = parse_target_key(key)
                info = {
                    "key": key,
                    "mode": t_mode,
                    "type": t_type,
                    "name": t_name,
                    "mods": 0,
                    "objects": set(),
                    "is_instance": False,
                }
                target_info[key] = info
            info["mods"] += 1
            try:
                info["objects"].add(display_obj.name)
            except Exception:
                pass
            try:
                if _modifier_is_instanced(owner, mod):
                    info["is_instance"] = True
            except Exception:
                pass

    scene.modswitch_targets.clear()
    if not target_info:
        scene.modswitch_objects.clear()
        scene.modswitch_target_index = 0
        scene.modswitch_obj_index = 0
        scene.modswitch_last_signature = sig
        return True

    def sort_key(info):
        label = build_target_label(info["mode"], info["type"], info["name"])
        return (0 if is_pinned(scene, info["key"]) else 1, label.lower())

    for info in sorted(target_info.values(), key=sort_key):
        item = scene.modswitch_targets.add()
        item.key = info["key"]
        item.mode = info["mode"]
        item.mod_type = info["type"]
        item.mod_name = info["name"]
        item.label = build_target_label(info["mode"], info["type"], info["name"])
        item.count_mods = int(info["mods"])
        item.count_objects = len(info["objects"])
        try:
            item.is_instance = bool(info.get("is_instance", False))
        except Exception:
            pass
        item.pinned = is_pinned(scene, info["key"])

    new_index = 0
    if old_key:
        for i, it in enumerate(scene.modswitch_targets):
            if it.key == old_key:
                new_index = i
                break
    scene.modswitch_target_index = new_index
    scene.modswitch_last_signature = sig
    update_object_list(context, scene)
    return True

def rebuild_lists(context, scene, force: bool = False) -> bool:
    if management_mode(scene) == "MODIFIER":
        return _rebuild_modifier_mode_lists(context, scene, force=force)
    return _rebuild_object_mode_lists(context, scene, force=force)

def get_active_target(scene):
    if 0 <= scene.modswitch_target_index < len(scene.modswitch_targets):
        return scene.modswitch_targets[scene.modswitch_target_index]
    return None

def get_matching_modifiers(obj, target) -> List:
    if not obj or not target or not hasattr(obj, "modifiers"):
        return []
    try:
        if str(getattr(target, "mode", "") or "") == "OBJECT":
            if str(getattr(target, "object_name", "") or "") and str(getattr(obj, "name", "") or "") != str(getattr(target, "object_name", "") or ""):
                return []
            idx = int(getattr(target, "modifier_index", -1) or -1)
            if 0 <= idx < len(obj.modifiers):
                mod = obj.modifiers[idx]
                if mod and mod.name == target.mod_name and mod.type == target.mod_type:
                    return [mod]
            mod = obj.modifiers.get(str(getattr(target, "mod_name", "") or ""))
            if mod and mod.type == target.mod_type:
                return [mod]
            return []
    except Exception:
        pass
    if target.mode == 'NAME':
        return [m for m in obj.modifiers if (m.type == target.mod_type and m.name == target.mod_name)]
    return [m for m in obj.modifiers if (m.type == target.mod_type)]

def primary_flag(scene) -> str:
    # Determine which flag to use as "primary" for toggle/invert logic
    if scene.modswitch_affect_viewport:
        return "show_viewport"
    if scene.modswitch_affect_render:
        return "show_render"
    if scene.modswitch_affect_editmode:
        return "show_in_editmode"
    if scene.modswitch_affect_on_cage:
        return "show_on_cage"
    if scene.modswitch_affect_expanded:
        return "show_expanded"
    return "show_viewport"

def apply_state_to_modifier(scene, mod, new_state: bool) -> None:
    # Apply selected flags only
    if scene.modswitch_affect_viewport:
        _safe_set_attr(mod, "show_viewport", new_state)
    if scene.modswitch_affect_render:
        _safe_set_attr(mod, "show_render", new_state)
    if scene.modswitch_affect_editmode:
        _safe_set_attr(mod, "show_in_editmode", new_state)
    if scene.modswitch_affect_on_cage:
        _safe_set_attr(mod, "show_on_cage", new_state)
    if scene.modswitch_affect_expanded:
        _safe_set_attr(mod, "show_expanded", new_state)

def get_modifier_flag(mod, flag_attr: str) -> bool:
    v = _safe_get_attr(mod, flag_attr, None)
    return bool(v) if v is not None else False

def compute_mods_state(scene, mods: List) -> str:
    if not mods:
        return "NONE"
    flag_attr = primary_flag(scene)
    values = [get_modifier_flag(m, flag_attr) for m in mods]
    if all(values):
        return "ON"
    if not any(values):
        return "OFF"
    return "MIXED"


def _smart_core_module():
    try:
        from .. import core as smart_core
        return smart_core
    except Exception:
        return None


def _object_has_base_instance_marker(obj, context=None) -> bool:
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "ms_object_has_linked_base_instance", None)
            if callable(fn) and fn(obj, context):
                return True
        except Exception:
            pass
    try:
        data = getattr(obj, "data", None)
        if data is not None and int(getattr(data, "users", 0) or 0) > 1:
            return True
    except Exception:
        pass
    return False


def _modifiers_have_instance_marker(obj, mods, context=None) -> bool:
    smart_core = _smart_core_module()
    if smart_core is None:
        return False
    try:
        for mod in list(mods or []):
            try:
                if bool(smart_core.ms_is_instance_modifier(mod, obj)):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _object_list_instance_marker(obj, mods=None, context=None) -> bool:
    return bool(_object_has_base_instance_marker(obj, context) or _modifiers_have_instance_marker(obj, mods, context))


def _add_modswitch_object_item(scene, obj, *, mods=None, count=None, state="ON", force_instance=False) -> None:
    if obj is None:
        return
    item = scene.modswitch_objects.add()
    item.name = str(getattr(obj, "name", "") or "")
    try:
        item.count = int(count if count is not None else len(list(mods or [])))
    except Exception:
        item.count = 1
    item.state = str(state or "ON")
    try:
        mod_list = list(mods or [])
    except Exception:
        mod_list = []
    if mod_list:
        item.render_state = compute_state_for_attr(mod_list, "show_render")
        item.viewport_state = compute_state_for_attr(mod_list, "show_viewport")
    else:
        item.render_state = "ON"
        item.viewport_state = "ON"
    try:
        item.is_instance = bool(force_instance or _object_list_instance_marker(obj, mod_list, getattr(bpy, "context", None)))
    except Exception:
        item.is_instance = bool(force_instance)


def _active_stack_object(context):
    try:
        obj = getattr(context, "active_object", None)
    except Exception:
        obj = None
    try:
        if obj is None:
            obj = getattr(getattr(context, "view_layer", None), "objects", None).active
    except Exception:
        pass
    smart_core = _smart_core_module()
    if smart_core is not None and obj is not None:
        try:
            get_main = getattr(smart_core, "get_main_object", None)
            if callable(get_main):
                main = get_main(obj)
                if main is not None:
                    obj = main
        except Exception:
            pass
    return obj


def _active_stack_effective_id(obj):
    if obj is None:
        return "BASE"
    try:
        ui_id = str(obj.get("ui_active_item", "BASE") or "BASE")
    except Exception:
        ui_id = "BASE"
    smart_core = _smart_core_module()
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "ms_get_effective_active_id", None)
            if callable(fn):
                return str(fn(obj, ui_id) or "BASE")
        except Exception:
            pass
    if ui_id != "BASE":
        try:
            if getattr(obj, "modifiers", None) and obj.modifiers.get(ui_id):
                return ui_id
        except Exception:
            pass
    return "BASE"


def _scene_objects_sharing_data(context, scene, source_obj):
    if source_obj is None:
        return []
    try:
        data = getattr(source_obj, "data", None)
    except Exception:
        data = None
    if data is None:
        return []
    out = []
    for obj in list(getattr(scene, "objects", []) or []):
        try:
            if obj is not None and getattr(obj, "data", None) is data:
                out.append(obj)
        except Exception:
            continue
    return out if len(out) > 1 else []


def _collect_active_base_instance_objects(context, scene, main_obj):
    smart_core = _smart_core_module()
    found = []
    seen = set()

    def add(obj):
        if obj is None:
            return
        try:
            name = str(getattr(obj, "name", "") or "")
        except Exception:
            name = ""
        if not name or name in seen:
            return
        seen.add(name)
        found.append(obj)

    if smart_core is not None:
        try:
            gid = str(smart_core.ms_get_object_instance_id(main_obj) or "")
        except Exception:
            gid = ""
        if gid:
            try:
                members = [m for m in smart_core.ms_iter_object_instance_members(gid, context=context) if m is not None]
            except Exception:
                members = []
            if len(members) > 1:
                for obj in members:
                    add(obj)

    for obj in _scene_objects_sharing_data(context, scene, main_obj):
        add(obj)

    return sorted(found, key=lambda o: getattr(o, "name", ""))


def _collect_active_modifier_instance_map(context, scene, main_obj, active_id):
    smart_core = _smart_core_module()
    if smart_core is None or main_obj is None or active_id == "BASE":
        return {}
    try:
        active_mod = main_obj.modifiers.get(active_id)
    except Exception:
        active_mod = None
    if active_mod is None:
        return {}
    try:
        iid = str(smart_core.ms_get_instance_id(active_mod, main_obj) or "")
    except Exception:
        iid = ""
    if not iid:
        return {}

    obj_mods = {}
    try:
        pairs = list(smart_core.ms_iter_instance_members(iid, context=context) or [])
    except Exception:
        pairs = []

    # Fallback scan for newly created/stale groups before the cache refreshes.
    if not pairs:
        for obj in _iter_scene_modifier_switcher_objects(context, scene):
            try:
                for mod in list(getattr(obj, "modifiers", []) or []):
                    if str(smart_core.ms_get_instance_id(mod, obj) or "") == iid:
                        pairs.append((obj, mod))
            except Exception:
                continue

    for obj, mod in pairs:
        if obj is None or mod is None:
            continue
        try:
            name = str(getattr(obj, "name", "") or "")
        except Exception:
            name = ""
        if not name:
            continue
        obj_mods.setdefault(obj, []).append(mod)

    # Only show this special list when the active stack item is actually shared.
    if len(obj_mods) <= 1:
        return {}
    return obj_mods


def update_active_stack_instance_object_list(context, scene) -> None:
    """Build Object List from the active Modifier Stack item instance group."""
    scene.modswitch_objects.clear()
    main_obj = _active_stack_object(context)
    if main_obj is None:
        return

    active_id = _active_stack_effective_id(main_obj)
    if active_id == "BASE":
        for obj in _collect_active_base_instance_objects(context, scene, main_obj):
            flt = (getattr(scene, "modswitch_filter_objects", "") or "").strip().lower()
            if flt and flt not in str(getattr(obj, "name", "") or "").lower():
                continue
            _add_modswitch_object_item(scene, obj, mods=[], count=1, state="ON", force_instance=True)
        return

    obj_mods = _collect_active_modifier_instance_map(context, scene, main_obj, active_id)
    for obj in sorted(obj_mods.keys(), key=lambda o: getattr(o, "name", "")):
        flt = (getattr(scene, "modswitch_filter_objects", "") or "").strip().lower()
        if flt and flt not in str(getattr(obj, "name", "") or "").lower():
            continue
        mods = obj_mods.get(obj) or []
        _add_modswitch_object_item(
            scene,
            obj,
            mods=mods,
            count=max(1, len(mods)),
            state=compute_mods_state(scene, mods) if mods else "ON",
            force_instance=True,
        )


def _update_modifier_mode_object_list(context, scene) -> None:
    scene.modswitch_objects.clear()
    try:
        if bool(getattr(scene, "modswitch_show_stack_instances", False)):
            setattr(scene, "modswitch_show_stack_instances", False)
    except Exception:
        pass

    target = get_active_target(scene)
    if not target:
        return

    show_mode = scene.modswitch_show_objects
    flt = (scene.modswitch_filter_objects or "").strip().lower()
    rows = []
    seen = set()
    for display_obj, stack_obj in _iter_scene_display_stack_pairs(context, scene):
        mods = get_matching_modifiers(stack_obj, target)
        if not mods:
            continue
        try:
            dname = str(display_obj.name)
        except Exception:
            continue
        if dname in seen:
            continue
        st = compute_mods_state(scene, mods)
        if show_mode != 'ALL' and st != show_mode:
            continue
        if flt and flt not in dname.lower():
            continue
        seen.add(dname)
        rows.append((dname, display_obj, stack_obj, mods, st))

    for dname, display_obj, stack_obj, mods, st in sorted(rows, key=lambda r: r[0].lower()):
        item = scene.modswitch_objects.add()
        item.name = dname
        item.count = len(mods)
        item.state = st
        item.render_state = compute_state_for_attr(mods, "show_render")
        item.viewport_state = compute_state_for_attr(mods, "show_viewport")
        try:
            item.is_instance = bool(_object_list_instance_marker(display_obj, mods, context) or _object_list_instance_marker(stack_obj, mods, context))
        except Exception:
            item.is_instance = False

def _update_object_mode_object_list(context, scene) -> None:
    scene.modswitch_objects.clear()
    selected = _selected_main_objects(context, scene)
    flt = (getattr(scene, "modswitch_filter_objects", "") or "").strip().lower()

    for obj in selected:
        try:
            if flt and flt not in obj.name.lower():
                continue
        except Exception:
            pass
        try:
            force_inst = bool(_object_list_instance_marker(obj, [], context))
        except Exception:
            force_inst = False
        _add_modswitch_object_item(scene, obj, mods=[], count=1, state="ON", force_instance=force_inst)

    for obj in _collect_related_instance_objects(context, scene, selected):
        try:
            if flt and flt not in obj.name.lower():
                continue
        except Exception:
            pass
        _add_modswitch_object_item(scene, obj, mods=[], count=1, state="ON", force_instance=True)


def update_object_list(context, scene) -> None:
    if management_mode(scene) == "MODIFIER":
        _update_modifier_mode_object_list(context, scene)
    else:
        _update_object_mode_object_list(context, scene)


def compute_state_for_attr(mods: List, attr: str) -> str:
    if not mods:
        return "NONE"
    vals = [get_modifier_flag(m, attr) for m in mods]
    if all(vals):
        return "ON"
    if not any(vals):
        return "OFF"
    return "MIXED"


def find_target_by_key(scene, key: str):
    key = str(key or "")
    try:
        for it in scene.modswitch_targets:
            if str(getattr(it, "key", "") or "") == key:
                return it
    except Exception:
        pass
    return get_active_target(scene)


def iter_target_modifier_pairs(context, scene, target):
    if target is None:
        return []
    mode = str(getattr(target, "mode", "") or "")
    if mode == "OBJECT":
        obj = None
        try:
            obj = scene.objects.get(str(getattr(target, "object_name", "") or ""))
        except Exception:
            obj = None
        if obj is None:
            return []
        stack_obj = _stack_owner_for_object(obj, context=context, create=False) or obj
        return [(stack_obj, m) for m in get_matching_modifiers(stack_obj, target)]
    pairs = []
    seen = set()
    for display_obj, stack_obj in _iter_scene_display_stack_pairs(context, scene):
        for mod in get_matching_modifiers(stack_obj, target):
            try:
                key = (stack_obj.name, mod.name)
            except Exception:
                key = (id(stack_obj), id(mod))
            if key in seen:
                continue
            seen.add(key)
            pairs.append((stack_obj, mod))
    return pairs

def _get_display_flag_state(obj, mod, flag_attr: str) -> bool:
    smart_core = _smart_core_module()
    if flag_attr == "show_viewport" and smart_core is not None:
        try:
            fn = getattr(smart_core, "get_mod_viewport_state", None)
            if callable(fn):
                return bool(fn(obj, mod.name))
        except Exception:
            pass
    if flag_attr == "show_render" and smart_core is not None:
        try:
            fn = getattr(smart_core, "get_mod_render_state", None)
            if callable(fn):
                return bool(fn(obj, mod.name))
        except Exception:
            pass
    return bool(_safe_get_attr(mod, flag_attr, False))


def _set_display_flag_state(obj, mod, flag_attr: str, value: bool) -> None:
    smart_core = _smart_core_module()
    done = False
    if flag_attr == "show_viewport" and smart_core is not None:
        try:
            fn = getattr(smart_core, "set_mod_viewport_state", None)
            if callable(fn):
                fn(obj, mod.name, bool(value))
                done = True
        except Exception:
            done = False
    elif flag_attr == "show_render" and smart_core is not None:
        try:
            fn = getattr(smart_core, "set_mod_render_state", None)
            if callable(fn):
                fn(obj, mod.name, bool(value))
                done = True
        except Exception:
            done = False
    if not done:
        _safe_set_attr(mod, flag_attr, bool(value))
    try:
        obj.update_tag()
    except Exception:
        pass


def compute_target_flag_state(context, scene, target, flag_attr: str) -> str:
    vals = []
    for obj, mod in iter_target_modifier_pairs(context, scene, target):
        if mod is None or not hasattr(mod, flag_attr):
            if flag_attr not in {"show_viewport", "show_render"}:
                continue
        vals.append(_get_display_flag_state(obj, mod, flag_attr))
    if not vals:
        return "NONE"
    if all(vals):
        return "ON"
    if not any(vals):
        return "OFF"
    return "MIXED"


def set_target_display_flag(context, scene, key: str, flag_attr: str, value: bool) -> int:
    """Set one display flag for the selected target across all owning objects.

    Instance modifiers are updated as a group, matching the Modifier Stack row
    buttons.  This is used by the Modifier Management search-row buttons.
    """
    if flag_attr not in {"show_on_cage", "show_in_editmode", "show_viewport", "show_render"}:
        return 0
    target = find_target_by_key(scene, key)
    if target is None:
        return 0
    pairs = iter_target_modifier_pairs(context, scene, target)
    smart_core = _smart_core_module()
    affected = 0
    touched_instance_ids = set()
    new_state = bool(value)
    for obj, mod in pairs:
        if obj is None or mod is None:
            continue
        iid = _modifier_instance_id(obj, mod)
        if iid and smart_core is not None:
            if iid in touched_instance_ids:
                continue
            touched_instance_ids.add(iid)
            try:
                members = list(smart_core.ms_iter_instance_members(iid, context=context) or [])
            except Exception:
                members = []
            if not members:
                members = [(obj, mod)]
            for member_obj, member_mod in members:
                _set_display_flag_state(member_obj, member_mod, flag_attr, new_state)
                affected += 1
            continue
        _set_display_flag_state(obj, mod, flag_attr, new_state)
        affected += 1
    try:
        main = _main_object_for_display(getattr(context, "active_object", None))
        if smart_core is not None and main is not None:
            fn = getattr(smart_core, "ms_apply_state_post_action", None)
            if callable(fn):
                fn(context, main, interactive_default=False)
    except Exception:
        pass
    try:
        update_object_list(context, scene)
    except Exception:
        pass
    return affected


def toggle_target_display_flag(context, scene, key: str, flag_attr: str) -> int:
    if flag_attr not in {"show_on_cage", "show_in_editmode", "show_viewport", "show_render"}:
        return 0
    target = find_target_by_key(scene, key)
    if target is None:
        return 0
    state = compute_target_flag_state(context, scene, target, flag_attr)
    new_state = False if state == "ON" else True
    pairs = iter_target_modifier_pairs(context, scene, target)
    smart_core = _smart_core_module()
    affected = 0
    touched_instance_ids = set()
    for obj, mod in pairs:
        if obj is None or mod is None:
            continue
        iid = _modifier_instance_id(obj, mod)
        if iid and smart_core is not None:
            if iid in touched_instance_ids:
                continue
            touched_instance_ids.add(iid)
            try:
                members = list(smart_core.ms_iter_instance_members(iid, context=context) or [])
            except Exception:
                members = []
            if not members:
                members = [(obj, mod)]
            for member_obj, member_mod in members:
                _set_display_flag_state(member_obj, member_mod, flag_attr, new_state)
                affected += 1
            continue
        _set_display_flag_state(obj, mod, flag_attr, new_state)
        affected += 1
    try:
        main = _main_object_for_display(getattr(context, "active_object", None))
        if smart_core is not None and main is not None:
            fn = getattr(smart_core, "ms_apply_state_post_action", None)
            if callable(fn):
                fn(context, main, interactive_default=False)
    except Exception:
        pass
    try:
        update_object_list(context, scene)
    except Exception:
        pass
    return affected


def select_object_by_name(context, scene, obj_name: str, additive: bool = False) -> bool:
    obj = None
    try:
        obj = scene.objects.get(str(obj_name or ""))
    except Exception:
        obj = None
    if obj is None:
        return False
    try:
        if not additive:
            bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
    except Exception:
        try:
            for o in list(getattr(scene, "objects", []) or []):
                o.select_set(False)
        except Exception:
            pass
    try:
        obj.select_set(True)
        context.view_layer.objects.active = obj
    except Exception:
        return False
    try:
        rebuild_lists(context, scene, force=True)
    except Exception:
        pass
    return True

def toggle_target_for_objects(context, scene, action: str) -> int:
    """
    action: 'ON','OFF','INVERT'
    returns number of modifiers affected
    """
    target = get_active_target(scene)
    if not target:
        return 0

    objs = iter_scope_objects(context, scene)
    affected = 0
    flag_attr = primary_flag(scene)

    for obj in objs:
        mods = get_matching_modifiers(obj, target)
        if not mods:
            continue
        if action == 'INVERT':
            # Invert based on primary flag of first modifier
            current = get_modifier_flag(mods[0], flag_attr)
            new_state = (not current)
        else:
            new_state = (action == 'ON')

        for m in mods:
            apply_state_to_modifier(scene, m, new_state)
            affected += 1

    # refresh object list for new states
    update_object_list(context, scene)
    return affected

def toggle_target_for_object(context, scene, obj_name: str) -> int:
    target = get_active_target(scene)
    if not target:
        return 0
    obj = scene.objects.get(obj_name)
    if not obj:
        return 0
    mods = get_matching_modifiers(obj, target)
    if not mods:
        return 0
    flag_attr = primary_flag(scene)
    current = get_modifier_flag(mods[0], flag_attr)
    new_state = not current
    for m in mods:
        apply_state_to_modifier(scene, m, new_state)
    update_object_list(context, scene)
    return len(mods)

# ------------------------------------------------------------
# State Sets
# ------------------------------------------------------------

def _default_stateset_name(scene) -> str:
    base = _sms_pgettext("State") or "State"
    existing = {s.name for s in scene.modswitch_state_sets}
    idx = 1
    while True:
        name = f"{base} {idx:03d}"
        if name not in existing:
            return name
        idx += 1

def capture_state_set(scene, context) -> List[Tuple]:
    """
    Capture current flags for all modifiers in scope objects.
    Returns list of tuples for records:
      (obj_name, mod_type, mod_name, ordinal, show_viewport, show_render, show_in_editmode, show_on_cage, show_expanded)
    """
    objs = iter_scope_objects(context, scene)
    records = []
    for obj in objs:
        if not hasattr(obj, "modifiers"):
            continue
        # ordinal per (type,name)
        counter: Dict[Tuple[str,str], int] = {}
        for mod in obj.modifiers:
            key = (mod.type, mod.name)
            ord_ = counter.get(key, 0)
            counter[key] = ord_ + 1
            records.append((
                obj.name,
                mod.type,
                mod.name,
                ord_,
                bool(_safe_get_attr(mod, "show_viewport", True)),
                bool(_safe_get_attr(mod, "show_render", True)),
                bool(_safe_get_attr(mod, "show_in_editmode", True)),
                bool(_safe_get_attr(mod, "show_on_cage", False)),
                bool(_safe_get_attr(mod, "show_expanded", False)),
            ))
    return records

def write_state_set_to_scene(scene, set_item, records: List[Tuple]) -> None:
    set_item.records.clear()
    for (obj_name, mod_type, mod_name, ord_, sv, sr, se, sc, sx) in records:
        r = set_item.records.add()
        r.obj_name = obj_name
        r.mod_type = mod_type
        r.mod_name = mod_name
        r.ordinal = int(ord_)
        r.show_viewport = bool(sv)
        r.show_render = bool(sr)
        r.show_in_editmode = bool(se)
        r.show_on_cage = bool(sc)
        r.show_expanded = bool(sx)

def apply_state_set(scene, context, set_item) -> int:
    objs = iter_scope_objects(context, scene)
    obj_map = {o.name: o for o in objs}
    affected = 0
    for rec in set_item.records:
        obj = obj_map.get(rec.obj_name)
        if not obj or not hasattr(obj, "modifiers"):
            continue
        # find matching modifier occurrence
        matches = [m for m in obj.modifiers if (m.type == rec.mod_type and m.name == rec.mod_name)]
        if rec.ordinal < 0 or rec.ordinal >= len(matches):
            continue
        m = matches[rec.ordinal]
        _safe_set_attr(m, "show_viewport", rec.show_viewport)
        _safe_set_attr(m, "show_render", rec.show_render)
        _safe_set_attr(m, "show_in_editmode", rec.show_in_editmode)
        _safe_set_attr(m, "show_on_cage", rec.show_on_cage)
        _safe_set_attr(m, "show_expanded", rec.show_expanded)
        affected += 1
    update_object_list(context, scene)
    return affected


def set_active_target_viewport_state(context, scene, value: bool) -> int:
    target = get_active_target(scene)
    if target is None:
        return 0
    smart_core = _smart_core_module()
    touched_instance_ids = set()
    affected = 0
    for obj, mod in iter_target_modifier_pairs(context, scene, target):
        if obj is None or mod is None:
            continue
        iid = _modifier_instance_id(obj, mod)
        if iid and smart_core is not None:
            if iid in touched_instance_ids:
                continue
            touched_instance_ids.add(iid)
            try:
                members = list(smart_core.ms_iter_instance_members(iid, context=context) or [])
            except Exception:
                members = []
            if not members:
                members = [(obj, mod)]
            for member_obj, member_mod in members:
                if member_obj is None or member_mod is None:
                    continue
                _set_display_flag_state(member_obj, member_mod, "show_viewport", bool(value))
                affected += 1
        else:
            _set_display_flag_state(obj, mod, "show_viewport", bool(value))
            affected += 1
    try:
        rebuild_lists(context, scene, force=True)
    except Exception:
        try:
            update_object_list(context, scene)
        except Exception:
            pass
    return affected


def _remove_modifier_with_smart_cleanup(context, obj, mod) -> bool:
    if obj is None or mod is None:
        return False
    smart_core = _smart_core_module()
    main_obj = obj
    if smart_core is not None:
        try:
            fn = getattr(smart_core, "get_main_object", None)
            if callable(fn):
                main_obj = fn(obj) or obj
        except Exception:
            main_obj = obj
    action = 'DELETE'
    clipboard = {}
    hook_states = {}
    if smart_core is not None:
        try:
            call_plugins = getattr(smart_core, "ms_call_plugins", None)
            if callable(call_plugins):
                for pid, state in call_plugins("before_item_action", main_obj, context, obj, mod, action, clipboard):
                    hook_states[str(pid or '')] = state
        except Exception:
            pass
        try:
            find_plugin = getattr(smart_core, "ms_find_plugin_for_modifier", None)
            plugin = find_plugin(mod) if callable(find_plugin) else None
            fn = plugin.get("cleanup_before_remove") if isinstance(plugin, dict) else None
            if callable(fn):
                fn(main_obj, context, obj, mod)
        except Exception:
            pass
    try:
        mod_name = str(getattr(mod, "name", "") or "")
        mod_type = str(getattr(mod, "type", "") or "")
    except Exception:
        mod_name = mod_type = ""
    try:
        if smart_core is not None:
            clear_iid = getattr(smart_core, "ms_obj_clear_instance_id", None)
            if callable(clear_iid):
                clear_iid(obj, mod_name)
    except Exception:
        pass
    try:
        obj.modifiers.remove(mod)
    except Exception:
        return False
    if smart_core is not None:
        try:
            cleanup_map = getattr(smart_core, "ms_obj_cleanup_instance_map", None)
            if callable(cleanup_map):
                cleanup_map(obj)
        except Exception:
            pass
        try:
            for plugin in getattr(smart_core, "ms_get_plugins_sorted", lambda: [])() or []:
                fn = plugin.get("after_item_action") if isinstance(plugin, dict) else None
                if callable(fn):
                    fn(main_obj, context, obj, None, action, clipboard, hook_states.get(str(plugin.get("id", "") or "")))
        except Exception:
            pass
        try:
            norm = getattr(smart_core, "ms_normalize_default_modifier_names", None)
            if callable(norm) and mod_type:
                norm(obj, mod_type)
        except Exception:
            pass
    try:
        obj.update_tag()
    except Exception:
        pass
    return True


def remove_active_target_modifiers(context, scene) -> int:
    target = get_active_target(scene)
    if target is None:
        return 0
    pairs = list(iter_target_modifier_pairs(context, scene, target) or [])
    # De-duplicate by owner/modifier name and remove from lower stack rows first.
    unique = {}
    for obj, mod in pairs:
        if obj is None or mod is None:
            continue
        try:
            key = (obj.name, mod.name)
        except Exception:
            key = (id(obj), id(mod))
        unique[key] = (obj, mod)
    ordered = list(unique.values())
    def _idx(pair):
        obj, mod = pair
        try:
            return int(obj.modifiers.find(mod.name))
        except Exception:
            return -1
    affected = 0
    for obj, mod in sorted(ordered, key=_idx, reverse=True):
        if _remove_modifier_with_smart_cleanup(context, obj, mod):
            affected += 1
    try:
        scene.modswitch_last_signature = 0
        rebuild_lists(context, scene, force=True)
    except Exception:
        pass
    return affected

# ------------------------------------------------------------
# Stack operations (advanced)
# ------------------------------------------------------------

def move_target_modifiers(context, scene, direction: str) -> int:
    target = get_active_target(scene)
    if not target:
        return 0
    objs = iter_scope_objects(context, scene)
    moved = 0
    for obj in objs:
        mods = get_matching_modifiers(obj, target)
        if not mods:
            continue
        # get indices in current order
        idxs = [list(obj.modifiers).index(m) for m in mods]
        if direction == 'UP':
            for idx in sorted(idxs):
                to_idx = max(0, idx - 1)
                if to_idx != idx:
                    try:
                        obj.modifiers.move(idx, to_idx)
                        moved += 1
                    except Exception:
                        pass
        else:  # DOWN
            for idx in sorted(idxs, reverse=True):
                to_idx = min(len(obj.modifiers) - 1, idx + 1)
                if to_idx != idx:
                    try:
                        obj.modifiers.move(idx, to_idx)
                        moved += 1
                    except Exception:
                        pass
    # rebuild signature because order changed
    scene.modswitch_last_signature = 0
    rebuild_lists(context, scene, force=True)
    return moved

def _ensure_object_mode(context) -> None:
    try:
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
    except Exception:
        pass


def _plugin_before_remove_state(context, obj, mod, action='DELETE'):
    states = {}
    smart_core = _smart_core_module()
    if smart_core is None or obj is None or mod is None:
        return states
    try:
        main_obj = smart_core.get_main_object(obj) or obj
    except Exception:
        main_obj = obj
    try:
        plugin = smart_core.ms_find_plugin_for_modifier(mod)
        if plugin and callable(plugin.get('cleanup_before_remove')):
            plugin.get('cleanup_before_remove')(main_obj, context, obj, mod)
    except Exception:
        pass
    try:
        for pid, state in smart_core.ms_call_plugins('before_item_action', main_obj, context, obj, mod, action, {}):
            states[str(pid or '')] = state
    except Exception:
        pass
    return states


def _plugin_after_remove_state(context, obj, mod, states, action='DELETE'):
    smart_core = _smart_core_module()
    if smart_core is None:
        return
    try:
        main_obj = smart_core.get_main_object(obj) or obj
    except Exception:
        main_obj = obj
    try:
        for plugin in smart_core.ms_get_plugins_sorted():
            fn = plugin.get('after_item_action') if isinstance(plugin, dict) else None
            if callable(fn):
                pid = str(plugin.get('id', '') or '')
                try:
                    fn(main_obj, context, obj, mod, action, {}, (states or {}).get(pid))
                except Exception:
                    pass
    except Exception:
        pass


def _iter_target_pairs_with_instance_dedup(context, scene, target):
    """Return concrete (object, modifier) pairs for a target, expanding instanced modifiers once."""
    pairs = []
    seen = set()
    smart_core = _smart_core_module()
    touched_iids = set()
    for obj, mod in iter_target_modifier_pairs(context, scene, target):
        if obj is None or mod is None:
            continue
        try:
            iid = _modifier_instance_id(obj, mod)
        except Exception:
            iid = ''
        if iid and smart_core is not None:
            if iid in touched_iids:
                continue
            touched_iids.add(iid)
            try:
                members = list(smart_core.ms_iter_instance_members(iid, context=context) or [])
            except Exception:
                members = []
            if not members:
                members = [(obj, mod)]
            for member_obj, member_mod in members:
                if member_obj is None or member_mod is None:
                    continue
                try:
                    key = (member_obj.name, member_mod.name)
                except Exception:
                    key = (id(member_obj), id(member_mod))
                if key in seen:
                    continue
                seen.add(key)
                pairs.append((member_obj, member_mod))
            continue
        try:
            key = (obj.name, mod.name)
        except Exception:
            key = (id(obj), id(mod))
        if key in seen:
            continue
        seen.add(key)
        pairs.append((obj, mod))
    return pairs



def _iter_instance_members_for_id(context, scene, instance_id: str):
    """Return concrete (stack_owner, modifier) members for one modifier instance id."""
    iid = str(instance_id or "")
    if not iid:
        return []
    smart_core = _smart_core_module()
    members = []
    seen = set()

    def add(obj, mod):
        if obj is None or mod is None:
            return
        try:
            key = (str(getattr(obj, "name", "") or ""), str(getattr(mod, "name", "") or ""), int(mod.as_pointer()))
        except Exception:
            key = (id(obj), id(mod))
        if key in seen:
            return
        seen.add(key)
        members.append((obj, mod))

    if smart_core is not None:
        try:
            for member_obj, member_mod in list(smart_core.ms_iter_instance_members(iid, context=context) or []):
                add(member_obj, member_mod)
        except Exception:
            pass

    # The instance-member cache can be stale immediately after duplication, deletion,
    # or manual edits.  Always scan the current scene as a fallback/completion pass.
    try:
        for display_obj, _stack_obj in _iter_scene_display_stack_pairs(context, scene):
            for owner, mod, _idx in _iter_stack_modifiers_for_object(display_obj, context=context):
                try:
                    if str(_modifier_instance_id(owner, mod) or "") == iid:
                        add(owner, mod)
                except Exception:
                    continue
    except Exception:
        pass
    return members


def collect_target_instance_modifier_objects(context, scene, key: str = '') -> List[bpy.types.Object]:
    """Collect display objects that own the active Modifier List row's instance modifiers."""
    target = find_target_by_key(scene, key) if key else get_active_target(scene)
    if target is None:
        return []

    instance_ids = []
    seen_iids = set()
    for obj, mod in iter_target_modifier_pairs(context, scene, target):
        if obj is None or mod is None:
            continue
        iid = str(_modifier_instance_id(obj, mod) or "")
        if not iid or iid in seen_iids:
            continue
        seen_iids.add(iid)
        instance_ids.append(iid)

    if not instance_ids:
        return []

    objects = []
    seen_names = set()

    def add_selectable(obj):
        if obj is None:
            return
        display_obj = _display_object_for_stack_owner(obj) or obj
        main_obj = _main_object_for_display(display_obj) or display_obj
        try:
            name = str(getattr(main_obj, "name", "") or "")
        except Exception:
            name = ""
        if not name or name in seen_names:
            return
        try:
            scene_obj = scene.objects.get(name)
        except Exception:
            scene_obj = None
        final_obj = scene_obj or main_obj
        seen_names.add(name)
        objects.append(final_obj)

    for iid in instance_ids:
        for member_obj, _member_mod in _iter_instance_members_for_id(context, scene, iid):
            add_selectable(member_obj)

    try:
        active = getattr(context, "active_object", None) or getattr(getattr(getattr(context, "view_layer", None), "objects", None), "active", None)
        active = _main_object_for_display(_display_object_for_stack_owner(active) or active) or active
        active_name = str(getattr(active, "name", "") or "")
    except Exception:
        active_name = ""
    if active_name:
        objects = [o for o in objects if str(getattr(o, "name", "") or "") == active_name] + [o for o in objects if str(getattr(o, "name", "") or "") != active_name]

    return objects


def select_target_instance_modifier_objects(context, scene, key: str = '') -> int:
    """Select every object that owns the selected Modifier List row's instance group."""
    objects = collect_target_instance_modifier_objects(context, scene, key=key)
    if not objects:
        return 0

    try:
        bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
    except Exception:
        try:
            for obj in list(getattr(scene, "objects", []) or []):
                try:
                    obj.select_set(False)
                except Exception:
                    continue
        except Exception:
            pass

    selected = 0
    first_selected = None
    for obj in objects:
        if obj is None:
            continue
        try:
            obj.select_set(True)
            selected += 1
            if first_selected is None:
                first_selected = obj
        except Exception:
            continue

    if first_selected is not None:
        try:
            context.view_layer.objects.active = first_selected
        except Exception:
            pass

    try:
        scene.modswitch_last_signature = 0
    except Exception:
        pass
    try:
        rebuild_lists(context, scene, force=True)
    except Exception:
        try:
            update_object_list(context, scene)
        except Exception:
            pass
    return selected

def set_target_viewport_state(context, scene, key: str = '', enabled: bool = True) -> int:
    target = find_target_by_key(scene, key) if key else get_active_target(scene)
    if not target:
        return 0
    affected = 0
    for obj, mod in _iter_target_pairs_with_instance_dedup(context, scene, target):
        try:
            _set_display_flag_state(obj, mod, 'show_viewport', bool(enabled))
            affected += 1
        except Exception:
            continue
    try:
        update_object_list(context, scene)
    except Exception:
        pass
    return affected

def apply_target_modifiers(context, scene, failures=None) -> int:
    target = get_active_target(scene)
    if not target:
        return 0
    _ensure_object_mode(context)
    objs = iter_scope_objects(context, scene)

    affected = 0
    if failures is None:
        failures = []
    for obj in objs:
        mods = get_matching_modifiers(obj, target)
        if not mods:
            continue
        # Apply in reverse order to keep indices stable
        for mod in list(mods)[::-1]:
            mod_name = mod.name
            try:
                with context.temp_override(object=obj, active_object=obj, selected_objects=[obj], selected_editable_objects=[obj]):
                    bpy.ops.object.modifier_apply('EXEC_DEFAULT', False, modifier=mod_name, single_user=True)
                affected += 1
            except RuntimeError as exc:
                failures.append(f"{obj.name} / {mod_name}: {str(exc).strip()}")

    scene.modswitch_last_signature = 0
    rebuild_lists(context, scene, force=True)
    return affected

def remove_target_modifiers(context, scene, key: str = '') -> int:
    target = find_target_by_key(scene, key) if key else get_active_target(scene)
    if not target:
        return 0

    pairs = _iter_target_pairs_with_instance_dedup(context, scene, target)
    affected = 0
    smart_core = _smart_core_module()
    for obj, mod in list(pairs)[::-1]:
        if obj is None or mod is None:
            continue
        try:
            mod_name = str(getattr(mod, 'name', '') or '')
        except Exception:
            mod_name = ''
        if not mod_name:
            continue
        try:
            states = _plugin_before_remove_state(context, obj, mod, action='DELETE')
        except Exception:
            states = {}
        try:
            removed_iid = _modifier_instance_id(obj, mod)
        except Exception:
            removed_iid = ''
        try:
            obj.modifiers.remove(mod)
            affected += 1
        except Exception:
            continue
        try:
            if smart_core is not None:
                try:
                    smart_core.ms_obj_clear_instance_id(obj, mod_name)
                except Exception:
                    pass
                try:
                    smart_core.ms_obj_cleanup_instance_map(obj)
                except Exception:
                    pass
                if removed_iid:
                    try:
                        smart_core.ms_instance_post_remove_cleanup(removed_iid, context=context)
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            _plugin_after_remove_state(context, obj, mod, states, action='DELETE')
        except Exception:
            pass
        try:
            obj.update_tag()
        except Exception:
            pass

    scene.modswitch_last_signature = 0
    rebuild_lists(context, scene, force=True)
    return affected
