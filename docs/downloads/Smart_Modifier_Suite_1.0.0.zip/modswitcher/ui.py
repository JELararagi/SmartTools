# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - ライセンス: GPL-3.0-or-later（GNU 一般公衆利用許諾書 第 3 版以降）
# ------------------------------------------------------------------------------

# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations 
import bpy 

from .import core 
from ..translation import pgettext as _sms_pgettext

try:
    from ..icons import icon_value as _sms_icon_value, operator as _sms_icon_operator, prop as _sms_icon_prop, large_icon_button_row as _sms_large_icon_row
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)
    def _sms_icon_prop(layout, data, prop_name, *, text='', icon_name='', fallback_icon='NONE', **kwargs):
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        try:
            return layout.prop(data, prop_name, text=text, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.prop(data, prop_name, text=text, **kwargs)
    def _sms_large_icon_row(layout, *, align=True, scale_y=1.16):
        row=layout.row(align=align)
        try: row.scale_y=scale_y
        except Exception: pass
        return row

def _sms_icon_label(layout, icon_name, fallback_icon='NONE', text=''):
    try:
        iv = _sms_icon_value(icon_name, fallback_icon)
        if iv:
            layout.label(text=text, icon_value=iv)
            return
    except Exception:
        pass
    try:
        if fallback_icon and fallback_icon != 'NONE':
            layout.label(text=text, icon=fallback_icon)
        else:
            layout.label(text=text)
    except Exception:
        layout.label(text=text)



def _sms_rna_is_valid(value):
    if value is None:
        return False
    try:
        ptr = getattr(value, 'as_pointer', None)
        if callable(ptr):
            return bool(int(ptr() or 0))
    except ReferenceError:
        return False
    except Exception:
        return True
    return True


def _sms_is_view3d_ui_context(context):
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if area is not None and str(getattr(area, 'type', '') or '') != 'VIEW_3D':
            return False
        if region is not None and str(getattr(region, 'type', '') or '') != 'UI':
            return False
    except Exception:
        return False
    return True


def _sms_safe_active_mesh_context(context):
    if not _sms_is_view3d_ui_context(context):
        return False
    try:
        mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        if mode != 'OBJECT':
            return False
    except Exception:
        return False
    try:
        obj = getattr(context, 'active_object', None) or getattr(getattr(getattr(context, 'view_layer', None), 'objects', None), 'active', None)
        if not _sms_rna_is_valid(obj):
            return False
        try:
            from ..core import ms_object_supports_modifier_stack
            if not ms_object_supports_modifier_stack(obj):
                return False
        except Exception:
            if getattr(obj, 'type', '') not in {'MESH','CURVE','SURFACE','FONT','LATTICE','ARMATURE','EMPTY','CAMERA','LIGHT','SPEAKER','VOLUME','POINTCLOUD','CURVES','GREASEPENCIL','GPENCIL'}:
                return False
        selected = list(getattr(context, 'selected_objects', []) or [])
        if obj in selected:
            return True
        try:
            return bool(getattr(obj, 'select_get', lambda: False)())
        except Exception:
            return False
    except Exception:
        return False


def _draw_modifier_flag_buttons(row, context, scene, item):
    flags = [
        ("show_on_cage", "cage", "MESH_DATA"),
        ("show_in_editmode", "edit", "EDITMODE_HLT"),
        ("show_viewport", "visible_on", "RESTRICT_VIEW_OFF"),
        ("show_render", "render_on", "RESTRICT_RENDER_OFF"),
    ]
    key = str(getattr(item, "key", "") or "")
    for flag, icon_name, fallback in flags:
        try:
            state = core.compute_target_flag_state(context, scene, item, flag)
        except Exception:
            state = "NONE"
        use_fallback = fallback
        use_icon_name = icon_name
        if flag == "show_viewport" and state == "OFF":
            use_icon_name = "visible_off"
            use_fallback = "RESTRICT_VIEW_ON"
        elif flag == "show_render" and state == "OFF":
            use_icon_name = "render_off"
            use_fallback = "RESTRICT_RENDER_ON"
        elif state == "MIXED":
            use_icon_name = "help"
            use_fallback = "QUESTION"
        sub = row.row(align=True)
        try:
            if state == "NONE":
                sub.enabled = False
        except Exception:
            pass
        op = _sms_icon_operator(sub, "modswitch.toggle_modifier_flag", text="", icon_name=use_icon_name, fallback_icon=use_fallback, emboss=False, depress=(state == "ON"))
        try:
            op.key = key
            op.flag_name = flag
        except Exception:
            pass

# ------------------------------------------------------------
# UILists
# ------------------------------------------------------------

class MODSWITCH_UL_Targets (bpy .types .UIList ):
    def filter_items (self ,context ,data ,propname ):
        scene =context .scene 
        flt =(scene .modswitch_filter_targets or "").strip ().lower ()
        items =getattr (data ,propname )
        flags =[]
        neworder =[]

        if not flt :
            flags =[self .bitflag_filter_item ]*len (items )
            return flags ,neworder 

        for it in items :
            txt =(it .label or "").lower ()
            if flt in txt :
                flags .append (self .bitflag_filter_item )
            else :
                flags .append (0 )
        return flags ,neworder 

    def draw_item (self ,context ,layout ,data ,item ,icon ,active_data ,active_propname ,index ):
        if not _sms_rna_is_valid (item ):
            return
        scene =context .scene
        row =_sms_large_icon_row (layout ,align =True ,scale_y =1.10 )
        _draw_modifier_flag_buttons(row, context, scene, item)
        try:
            mod_icon = core.modifier_icon_for_target(item)
        except Exception:
            mod_icon = 'MODIFIER'
        try:
            row.label(text='', icon=mod_icon or 'MODIFIER')
        except Exception:
            row.label(text='', icon='MODIFIER')
        if getattr(item, "is_instance", False):
            _sms_icon_label(row, '', 'LINKED')
        row.label(text=getattr(item, "label", "") or getattr(item, "mod_name", ""), translate=(getattr(item, "mode", "") == 'TYPE'))

class MODSWITCH_UL_Objects (bpy .types .UIList ):
    def draw_item (self ,context ,layout ,data ,item ,icon ,active_data ,active_propname ,index ):
        if not _sms_rna_is_valid (item ):
            return
        row =_sms_large_icon_row (layout ,align =True ,scale_y =1.10 )
        if getattr (item ,"is_instance",False ):
            _sms_icon_label (row ,'','LINKED')
        op = row.operator("modswitch.select_object_item", text=getattr(item, "name", ""), icon='OBJECT_DATA', emboss=False, translate=False)
        try:
            op.obj_name = getattr(item, "name", "")
        except Exception:
            pass

class MODSWITCH_UL_StateSets (bpy .types .UIList ):
    def draw_item (self ,context ,layout ,data ,item ,icon ,active_data ,active_propname ,index ):
        if not _sms_rna_is_valid (item ):
            return
        layout .label (text =item .name ,translate =False )

        # ------------------------------------------------------------
        # Panels
        # ------------------------------------------------------------

class MODSWITCH_PT_MainPanel (bpy .types .Panel ):
    bl_label ="Modifier Management"
    bl_idname ="MODSWITCH_PT_main"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'

    @classmethod
    def poll (cls ,context ):
        return _sms_safe_active_mesh_context (context )

    def draw (self ,context ):
        pgettext =_sms_pgettext 
        layout =self .layout 
        scene =context .scene 

        # Update. Auto refresh is centralized in Smart Modifier > Always-on Toggles.
        row =_sms_large_icon_row (layout ,align =True ,scale_y =1.10 )
        _sms_icon_operator (row ,"modswitch.update_list",text =pgettext ("Update List"),icon_name ='refresh',fallback_icon ='FILE_REFRESH')

            # Settings
        box =layout .box ()
        box .label (text =pgettext ("Mode")+" / "+pgettext ("Scope"))
        row =box .row (align =True )
        row .prop (scene ,"modswitch_mode",text ="")
        row .prop (scene ,"modswitch_scope",text ="")
        if scene .modswitch_scope =='COLLECTION':
            box .prop (scene ,"modswitch_scope_collection",text =pgettext ("Collection"))
        row =box .row (align =True )
        row .prop (scene ,"modswitch_visible_only",text =pgettext ("Visible Only"))
        row .prop (scene ,"modswitch_selection_behavior",text =pgettext ("Selection Sync"))

        # Targets
        box =layout .box ()
        _target_key = ''
        try:
            if 0 <= scene.modswitch_target_index < len(scene.modswitch_targets):
                _target_key = str(scene.modswitch_targets[scene.modswitch_target_index].key or '')
        except Exception:
            _target_key = ''
        header =box .row (align =True )
        header .label (text =pgettext ("Modifier List"))
        right =header .row (align =True )
        try:
            right .alignment ='RIGHT'
        except Exception:
            pass
        try:
            if str(getattr(scene, "modswitch_manage_mode", "OBJECT") or "OBJECT") == 'OBJECT':
                op =_sms_icon_operator (right ,"modswitch.select_instance_modifier_objects",text ="",icon_name ='select_instances',fallback_icon ='LINKED')
                op .key =_target_key
        except Exception:
            pass
        box .prop (scene ,"modswitch_filter_targets",text =pgettext ("Target Filter"),icon ='VIEWZOOM')
        if len (scene .modswitch_targets )==0 :
            box .label (text =pgettext ("No targets."))
        else :
            box .template_list ("MODSWITCH_UL_Targets","",scene ,"modswitch_targets",scene ,"modswitch_target_index",rows =8 )

            # Actions
        box =layout .box ()
        box .label (text =pgettext ("Actions"))
        col =box .column (align =True )
        col .label (text =pgettext ("Affect Flags"))
        row =col .row (align =True )
        row .prop (scene ,"modswitch_affect_viewport",text =pgettext ("Viewport"))
        row .prop (scene ,"modswitch_affect_render",text =pgettext ("Render"))
        row =col .row (align =True )
        row .prop (scene ,"modswitch_affect_editmode",text =pgettext ("Edit Mode"))
        row .prop (scene ,"modswitch_affect_on_cage",text =pgettext ("On Cage"))
        row .prop (scene ,"modswitch_affect_expanded",text =pgettext ("Expanded"))

        row =box .row (align =True )
        _sms_icon_operator (row ,"modswitch.toggle_all",text =pgettext ("ON"),icon_name ='enabled_on',fallback_icon ='CHECKBOX_HLT').action ='ON'
        _sms_icon_operator (row ,"modswitch.toggle_all",text =pgettext ("OFF"),icon_name ='enabled_off',fallback_icon ='CHECKBOX_DEHLT').action ='OFF'
        _sms_icon_operator (row ,"modswitch.toggle_all",text =pgettext ("Invert"),icon_name ='refresh',fallback_icon ='FILE_REFRESH').action ='INVERT'

        # State Sets
        box =layout .box ()
        box .label (text =pgettext ("State Sets"))
        row =box .row (align =True )
        row .template_list ("MODSWITCH_UL_StateSets","",scene ,"modswitch_state_sets",scene ,"modswitch_state_set_index",rows =3 )
        col =box .column (align =True )
        col .prop (scene ,"modswitch_new_state_set_name",text =pgettext ("New Set Name"))
        row =col .row (align =True )
        _sms_icon_operator (row ,"modswitch.save_state_new",text =pgettext ("Save New"),icon_name ='add',fallback_icon ='ADD')
        _sms_icon_operator (row ,"modswitch.save_state_overwrite",text =pgettext ("Overwrite"),icon_name ='refresh',fallback_icon ='FILE_TICK')
        row =_sms_large_icon_row (col ,align =True ,scale_y =1.10 )
        _sms_icon_operator (row ,"modswitch.apply_state",text =pgettext ("Apply"),icon_name ='apply',fallback_icon ='CHECKMARK')
        _sms_icon_operator (row ,"modswitch.delete_state",text =pgettext ("Delete"),icon_name ='delete',fallback_icon ='TRASH')

class MODSWITCH_PT_ObjectListPanel (bpy .types .Panel ):
    bl_label ="Applied Objects"
    bl_idname ="MODSWITCH_PT_objects"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""

    @classmethod
    def poll (cls ,context ):
        return _sms_safe_active_mesh_context (context )

    def draw (self ,context ):
        pgettext =_sms_pgettext 
        layout =self .layout 
        scene =context .scene 

        try:
            if bool (getattr (scene ,"modswitch_show_stack_instances",False )):
                core .update_object_list (context ,scene )
        except Exception:
            pass

        row =layout .row (align =True )
        row .prop (scene ,"modswitch_filter_objects",text =pgettext ("Object Filter"),icon ='VIEWZOOM')
        _sms_icon_operator (row ,"modswitch.select_all_listed",text ="",icon_name ='select_instances',fallback_icon ='RESTRICT_SELECT_OFF')

        if len (scene .modswitch_objects )==0 :
            layout .label (text =pgettext ("No objects."))
            return 

        layout .template_list ("MODSWITCH_UL_Objects","",scene ,"modswitch_objects",scene ,"modswitch_obj_index",rows =8 )

        _sms_icon_operator (layout ,"modswitch.select_all_listed",text =pgettext ("Select All Listed"),icon_name ='select_instances',fallback_icon ='RESTRICT_SELECT_OFF')

class MODSWITCH_PT_AdvancedPanel (bpy .types .Panel ):
    bl_label ="Advanced"
    bl_idname ="MODSWITCH_PT_advanced"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}

    @classmethod
    def poll (cls ,context ):
        return _sms_safe_active_mesh_context (context )

    def draw (self ,context ):
        pgettext =_sms_pgettext 
        layout =self .layout 

        col =layout .column (align =True )
        row =col .row (align =True )
        _sms_icon_operator (row ,"modswitch.move_mods",text =pgettext ("Move Up"),icon_name ='move_up',fallback_icon ='TRIA_UP').direction ='UP'
        _sms_icon_operator (row ,"modswitch.move_mods",text =pgettext ("Move Down"),icon_name ='move_down',fallback_icon ='TRIA_DOWN').direction ='DOWN'

        col .separator ()
        row =col .row (align =True )
        _sms_icon_operator (row ,"modswitch.apply_mods",text =pgettext ("Apply Modifiers"),icon_name ='apply',fallback_icon ='MODIFIER')
        _sms_icon_operator (row ,"modswitch.remove_mods",text =pgettext ("Remove Modifiers"),icon_name ='delete',fallback_icon ='X')


        # --- Tooltip completion ---
MODSWITCH_PT_MainPanel .bl_description ='Main panel for the modifier switcher helper.'
MODSWITCH_PT_ObjectListPanel .bl_description ='Object list panel for selecting and batching modifier switcher targets.'
MODSWITCH_PT_AdvancedPanel .bl_description ='Advanced settings panel for the modifier switcher helper.'



def _modswitch_root_only_panel_poll(cls, context):
    # The Modifier Switcher UI is hosted inside Smart Modifier's unified root
    # section. Hide standalone child panels to avoid duplicate section headers.
    return False

MODSWITCH_PT_MainPanel.poll = classmethod(_modswitch_root_only_panel_poll)
MODSWITCH_PT_ObjectListPanel.poll = classmethod(_modswitch_root_only_panel_poll)
MODSWITCH_PT_AdvancedPanel.poll = classmethod(_modswitch_root_only_panel_poll)
