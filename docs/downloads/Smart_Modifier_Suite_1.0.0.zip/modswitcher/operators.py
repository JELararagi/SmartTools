# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi
#  Official Contact: 
#  Video Tutorials: 
#
#  【ライセンス】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - ライセンス: GNU General Public License v3.0 以降（GPL-3.0-or-later）で配布します。
# ------------------------------------------------------------------------------

# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations 
import bpy 

from .import core 
from ..translation import pgettext as _sms_pgettext


def _persist_panel_state(context) -> None:
    try:
        from .. import persistent_state
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass

# -------------------------------------------------------------------
# Operators
# -------------------------------------------------------------------


class MODSWITCH_OT_SetManageMode(bpy.types.Operator):
    bl_idname = "modswitch.set_manage_mode"
    bl_label = "Set Management Mode"
    bl_description = (
        "Switch Modifier Management between Object-based and Modifier-based management.\n"
        "Object shows selected objects first; Modifier shows all scene modifiers first."
    )
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        items=[
            ('OBJECT', "Object", "Manage from the current object selection"),
            ('MODIFIER', "Modifier", "Manage from all modifiers in the scene"),
        ],
        default='OBJECT',
    )

    def execute(self, context):
        scene = context.scene
        try:
            scene.modswitch_manage_mode = self.mode
        except Exception:
            return {'CANCELLED'}
        try:
            core.rebuild_lists(context, scene, force=True)
        except Exception:
            pass
        _persist_panel_state(context)
        return {'FINISHED'}


class MODSWITCH_OT_TargetBulkAction(bpy.types.Operator):
    bl_idname = "modswitch.target_bulk_action"
    bl_label = "Modifier List Target Action"
    bl_description = (
        "Apply the requested action to the selected modifier in the Modifier List on every object that owns it.\n"
        "Use Viewport ON/OFF for bulk display control, or Delete to remove the selected target from all listed owners."
    )
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        items=[
            ('VIEWPORT_ON', "Viewport ON", "Turn viewport display ON for the selected modifier target on all owning objects"),
            ('VIEWPORT_OFF', "Viewport OFF", "Turn viewport display OFF for the selected modifier target on all owning objects"),
            ('DELETE', "Delete", "Delete the selected modifier target from all owning objects"),
        ],
        default='VIEWPORT_ON',
    )
    key: bpy.props.StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        pgettext = _sms_pgettext
        action = str(getattr(properties, "action", "") or "")
        if action == 'VIEWPORT_ON':
            return pgettext("Turn viewport display ON for the modifier currently selected in Modifier Management on every object that owns it. Instanced modifiers are updated together.")
        if action == 'VIEWPORT_OFF':
            return pgettext("Turn viewport display OFF for the modifier currently selected in Modifier Management on every object that owns it. Instanced modifiers are updated together.")
        if action == 'DELETE':
            return pgettext("Delete the modifier currently selected in Modifier Management from every object that owns it. This also runs Smart Modifier cleanup for custom modifiers such as Slice.")
        return pgettext("Run a bulk action on the selected Modifier Management target.")

    def invoke(self, context, event):
        if self.action == 'DELETE':
            try:
                return context.window_manager.invoke_confirm(self, event)
            except Exception:
                pass
        return self.execute(context)

    def execute(self, context):
        scene = context.scene
        action = str(self.action or '')
        key = str(self.key or '')
        changed = 0
        if action == 'VIEWPORT_ON':
            changed = core.set_target_viewport_state(context, scene, key, True)
        elif action == 'VIEWPORT_OFF':
            changed = core.set_target_viewport_state(context, scene, key, False)
        elif action == 'DELETE':
            changed = core.remove_target_modifiers(context, scene, key=key)
        else:
            return {'CANCELLED'}
        try:
            core.rebuild_lists(context, scene, force=True)
        except Exception:
            pass
        _persist_panel_state(context)
        return {'FINISHED'} if changed >= 0 else {'CANCELLED'}



class MODSWITCH_OT_TargetViewportState(bpy.types.Operator):
    bl_idname = "modswitch.target_viewport_state"
    bl_label = "Set Target Viewport State"
    bl_description = "Turn viewport display ON or OFF for the modifier currently selected in Modifier Management on every object that owns it."
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        items=[
            ('ON', "ON", "Turn viewport display ON"),
            ('OFF', "OFF", "Turn viewport display OFF"),
        ],
        default='ON',
    )
    key: bpy.props.StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        key = str(self.key or '')
        enabled = (str(self.action or 'ON') == 'ON')
        changed = core.set_target_viewport_state(context, scene, key, enabled)
        try:
            core.rebuild_lists(context, scene, force=True)
        except Exception:
            pass
        _persist_panel_state(context)
        return {'FINISHED'} if changed >= 0 else {'CANCELLED'}


class MODSWITCH_OT_UpdateList (bpy .types .Operator ):
    bl_idname ="modswitch.update_list"
    bl_label ="Update List"
    bl_description =(
    "Rebuild the scene-wide Modifier List and Object List.\n"
    "Use this after adding/removing/renaming modifiers, or when the UI looks out of date.\n"
    "Tip: When Auto Refresh is ON, this runs automatically at the interval you set."
    )
    bl_options ={'UNDO'}

    force :bpy .props .BoolProperty (default =True )

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        rebuilt =core .rebuild_lists (context ,scene ,force =self .force )
        if not scene .modswitch_targets :
            self .report ({'WARNING'},pgettext ("No modifiers found in scene."))
            return {'FINISHED'}
        if rebuilt :
            self .report ({'INFO'},pgettext ("Updated targets."))
        return {'FINISHED'}


class MODSWITCH_OT_SelectObjectItem(bpy.types.Operator):
    bl_idname = "modswitch.select_object_item"
    bl_label = "Select Object"
    bl_description = (
        "Select the clicked object from the Modifier Management Object List.\n"
        "Normal click replaces the current viewport selection. Shift+click or Ctrl+click adds the object to the current selection."
    )
    bl_options = {'UNDO'}

    obj_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        additive = False
        try:
            additive = bool(getattr(event, "shift", False) or getattr(event, "ctrl", False))
        except Exception:
            additive = False
        ok = core.select_object_by_name(context, context.scene, self.obj_name, additive=additive)
        _persist_panel_state(context)
        return {'FINISHED'} if ok else {'CANCELLED'}

    def execute(self, context):
        ok = core.select_object_by_name(context, context.scene, self.obj_name, additive=False)
        _persist_panel_state(context)
        return {'FINISHED'} if ok else {'CANCELLED'}


class MODSWITCH_OT_SetSelectedTargetViewport(bpy.types.Operator):
    bl_idname = "modswitch.set_selected_target_viewport"
    bl_label = "Set Target Viewport"
    bl_description = (
        "Set Viewport visibility for the modifier selected in Modifier Management on every object that owns that modifier.\n"
        "Instanced modifier groups are updated together, the same as the Modifier Stack buttons."
    )
    bl_options = {'UNDO'}

    value: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        scene = context.scene
        target = core.get_active_target(scene)
        if target is None:
            self.report({'WARNING'}, _sms_pgettext("No modifiers."))
            return {'CANCELLED'}
        count = core.set_target_display_flag(context, scene, getattr(target, 'key', ''), 'show_viewport', bool(self.value))
        try:
            core.rebuild_lists(context, scene, force=True)
        except Exception:
            pass
        _persist_panel_state(context)
        return {'FINISHED'} if count else {'CANCELLED'}


class MODSWITCH_OT_RemoveSelectedTargetModifiers(bpy.types.Operator):
    bl_idname = "modswitch.remove_selected_target_modifiers"
    bl_label = "Remove Selected Modifier"
    bl_description = (
        "Delete the modifier selected in Modifier Management from every object that owns that modifier.\n"
        "This uses the same cleanup hooks as the Modifier Stack so Slice helpers, node groups, vertex groups, and empty collections are removed when they are no longer needed."
    )
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        target = core.get_active_target(scene)
        if target is None:
            self.report({'WARNING'}, _sms_pgettext("No modifiers."))
            return {'CANCELLED'}
        count = core.remove_target_modifiers(context, scene)
        _persist_panel_state(context)
        return {'FINISHED'} if count else {'CANCELLED'}


class MODSWITCH_OT_ToggleModifierFlag(bpy.types.Operator):
    bl_idname = "modswitch.toggle_modifier_flag"
    bl_label = "Toggle Modifier Flag"
    bl_description = (
        "Toggle the clicked modifier display flag in Modifier Management.\n"
        "When the row is an instanced modifier, the same flag is changed on every modifier in that instance group."
    )
    bl_options = {'UNDO'}

    key: bpy.props.StringProperty()
    flag_name: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        pgettext = _sms_pgettext
        flag = str(getattr(properties, "flag_name", "") or "")
        if flag == "show_on_cage":
            return pgettext("Toggle the On Cage display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.")
        if flag == "show_in_editmode":
            return pgettext("Toggle whether this modifier row is visible in Edit Mode. If this modifier is instanced, every linked instance row is updated together.")
        if flag == "show_viewport":
            return pgettext("Toggle the realtime Viewport display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.")
        if flag == "show_render":
            return pgettext("Toggle the Render display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.")
        return pgettext("Toggle this modifier display flag.")

    def execute(self, context):
        changed = core.toggle_target_display_flag(context, context.scene, self.key, self.flag_name)
        try:
            core.rebuild_lists(context, context.scene, force=True)
        except Exception:
            pass
        _persist_panel_state(context)
        return {'FINISHED'} if changed else {'CANCELLED'}


class MODSWITCH_OT_ToggleAll (bpy .types .Operator ):
    bl_idname ="modswitch.toggle_all"
    bl_label ="Toggle All"
    bl_options ={'UNDO'}

    action :bpy .props .EnumProperty (
    items =[
    ('ON',"ON","Turn the target ON (applies the selected flags)"),
    ('OFF',"OFF","Turn the target OFF (applies the selected flags)"),
    ('INVERT',"Invert","Swap ON/OFF for the target (applies the selected flags)"),
    ],
    default ='ON'
    )

    @classmethod 
    def description (cls ,context ,properties ):
    # Blender expects this as a classmethod with (cls, context, properties).
        pgettext =_sms_pgettext 
        action =getattr (properties ,"action",'ON')
        if action =='ON':
            return pgettext (
            "Turn ON (enable) the active target for ALL matching objects in the scene.\n"
            "Only the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\n"
            "Tip: This does not add/remove modifiers — it only changes their ON/OFF and display states."
            )
        if action =='OFF':
            return pgettext (
            "Turn OFF (disable) the active target for ALL matching objects in the scene.\n"
            "Only the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\n"
            "Tip: OFF is non-destructive; you can turn it ON again later."
            )
        return pgettext (
        "Invert (toggle) the active target for ALL matching objects in the scene.\n"
        "Objects that are ON become OFF (and vice versa). Useful for quick comparisons."
        )

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        if not core .get_active_target (scene ):
            self .report ({'WARNING'},pgettext ("No targets."))
            return {'CANCELLED'}
        count =core .toggle_target_for_objects (context ,scene ,self .action )
        msg =pgettext ("Updated {} modifiers ({}).").format (count ,self .action )
        self .report ({'INFO'},msg )
        return {'FINISHED'}

class MODSWITCH_OT_ToggleOne (bpy .types .Operator ):
    bl_idname ="modswitch.toggle_one"
    bl_label ="Toggle"
    bl_description =(
    "Toggle the ACTIVE target for the object you click (one object at a time).\n"
    "Only the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\n"
    "Tip: Use the big ON/OFF buttons to change ALL objects at once."
    )
    bl_options ={'UNDO'}

    obj_name :bpy .props .StringProperty ()

    def execute (self ,context ):
        scene =context .scene 
        core .toggle_target_for_object (context ,scene ,self .obj_name )
        return {'FINISHED'}

class MODSWITCH_OT_SelectAllListed (bpy .types .Operator ):
    bl_idname ="modswitch.select_all_listed"
    bl_label ="Select All Listed"
    bl_description =(
    "Select every object currently shown in the Object List.\n"
    "Tip: Combine with filters to quickly build a selection set.\n"
    "Note: This only changes the viewport selection; it does not edit the Object List itself."
    )
    bl_options ={'UNDO'}

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        names =[it .name for it in scene .modswitch_objects ]
        if not names :
            self .report ({'WARNING'},pgettext ("No objects."))
            return {'CANCELLED'}
        try :
            bpy .ops .object .select_all ('EXEC_DEFAULT', False, action ='DESELECT')
        except Exception :
            pass 
        selected =0 
        for n in names :
            obj =scene .objects .get (n )
            if obj :
                try :
                    obj .select_set (True )
                    selected +=1 
                except Exception :
                    pass 
        if selected:
            try:
                context .view_layer .objects .active =scene .objects .get (names [0 ])
            except Exception:
                pass
        self .report ({'INFO'},pgettext ("Selected {} objects.").format (selected ))
        return {'FINISHED'}

class MODSWITCH_OT_SelectInstanceModifierObjects(bpy.types.Operator):
    bl_idname = "modswitch.select_instance_modifier_objects"
    bl_label = "Select Instance Modifier Objects"
    bl_description = (
        "Select all objects that use the same instanced modifier as the selected Modifier List row.\n"
        "Use this from Object management mode when you want the viewport selection and Object List to switch to every object sharing that modifier instance."
    )
    bl_options = {'UNDO'}

    key: bpy.props.StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _sms_pgettext(
            "Select all objects that use the same instanced modifier as the selected Modifier List row.\n"
            "How to use: select an instanced modifier in the Modifier List, then click this button. The objects are selected in the 3D View, and in Object management mode the Object List rebuilds from the current viewport selection."
        )

    def execute(self, context):
        pgettext = _sms_pgettext
        scene = context.scene
        count = core.select_target_instance_modifier_objects(context, scene, key=str(self.key or ""))
        _persist_panel_state(context)
        if count <= 0:
            self.report({'WARNING'}, pgettext("No instanced modifier objects."))
            return {'CANCELLED'}
        self.report({'INFO'}, pgettext("Selected {} objects.").format(count))
        return {'FINISHED'}


class MODSWITCH_OT_TogglePin (bpy .types .Operator ):
    bl_idname ="modswitch.toggle_pin"
    bl_label ="Pin"
    bl_description =(
    "Pin/unpin the selected target.\n"
    "Pinned targets stay at the top of the Modifier List for quick access, and are kept even if temporarily missing.\n"
    "Beginner tip: Use Pin for important modifiers you always want to see/control."
    )
    bl_options ={'UNDO'}

    key :bpy .props .StringProperty ()

    def execute (self ,context ):
        scene =context .scene 
        current =core .is_pinned (scene ,self .key )
        core .set_pinned (scene ,self .key ,not current )
        # force rebuild so pinned order updates
        core .rebuild_lists (context ,scene ,force =True )
        _persist_panel_state (context )
        return {'FINISHED'}

        # ------------------------------------------------------------
        # State set operators
        # ------------------------------------------------------------

class MODSWITCH_OT_SaveStateNew (bpy .types .Operator ):
    bl_idname ="modswitch.save_state_new"
    bl_label ="Save New"
    bl_description =(
    "Create a NEW State Set (a snapshot) of modifier ON/OFF + display flags.\n"
    "This records the current modifier states of matching scene objects, so you can restore them later.\n"
    "Beginner tip: Use State Sets to switch between setups (e.g. modeling vs render, high vs low).\n"
    "Note: This does NOT save modifier parameters or order — only the visibility/display states."
    )
    bl_options ={'UNDO'}

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        name =(scene .modswitch_new_state_set_name or "").strip ()
        if not name :
            name =core ._default_stateset_name (scene )

        ss =scene .modswitch_state_sets .add ()
        ss .name =name 
        records =core .capture_state_set (scene ,context )
        core .write_state_set_to_scene (scene ,ss ,records )

        scene .modswitch_state_set_index =max (0 ,len (scene .modswitch_state_sets )-1 )
        scene .modswitch_new_state_set_name =""
        _persist_panel_state (context )
        self .report ({'INFO'},pgettext ("Saved state set: {}").format (name ))
        return {'FINISHED'}

class MODSWITCH_OT_SaveStateOverwrite (bpy .types .Operator ):
    bl_idname ="modswitch.save_state_overwrite"
    bl_label ="Overwrite"
    bl_description =(
    "Overwrite the selected State Set with the current modifier ON/OFF + display states.\n"
    "Use this to update a preset after you make changes.\n"
    "Caution: This replaces the saved snapshot (Undo can revert)."
    )
    bl_options ={'UNDO'}

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        idx =scene .modswitch_state_set_index 
        if idx <0 or idx >=len (scene .modswitch_state_sets ):
            return {'CANCELLED'}
        ss =scene .modswitch_state_sets [idx ]
        records =core .capture_state_set (scene ,context )
        core .write_state_set_to_scene (scene ,ss ,records )
        _persist_panel_state (context )
        self .report ({'INFO'},pgettext ("Saved state set: {}").format (ss .name ))
        return {'FINISHED'}

class MODSWITCH_OT_ApplyState (bpy .types .Operator ):
    bl_idname ="modswitch.apply_state"
    bl_label ="Apply"
    bl_description =(
    "Load/apply the selected State Set to matching scene objects.\n"
    "This restores the saved ON/OFF + display flags from that snapshot.\n"
    "Note: It does not add/remove modifiers or change their order — it only restores states."
    )
    bl_options ={'UNDO'}

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        idx =scene .modswitch_state_set_index 
        if idx <0 or idx >=len (scene .modswitch_state_sets ):
            return {'CANCELLED'}
        ss =scene .modswitch_state_sets [idx ]
        core .apply_state_set (scene ,context ,ss )
        _persist_panel_state (context )
        self .report ({'INFO'},pgettext ("Applied state set: {}").format (ss .name ))
        return {'FINISHED'}

class MODSWITCH_OT_DeleteState (bpy .types .Operator ):
    bl_idname ="modswitch.delete_state"
    bl_label ="Delete"
    bl_description =(
    "Delete the selected State Set preset.\n"
    "This only removes the preset; it does not change current modifier states.\n"
    "Tip: If you delete by mistake, Undo can restore it."
    )
    bl_options ={'UNDO'}

    def invoke (self ,context ,event ):
        return context .window_manager .invoke_confirm (self ,event )

    def execute (self ,context ):
        pgettext =_sms_pgettext 
        scene =context .scene 
        idx =scene .modswitch_state_set_index 
        if idx <0 or idx >=len (scene .modswitch_state_sets ):
            return {'CANCELLED'}
        name =scene .modswitch_state_sets [idx ].name 
        scene .modswitch_state_sets .remove (idx )
        scene .modswitch_state_set_index =min (max (0 ,idx -1 ),max (0 ,len (scene .modswitch_state_sets )-1 ))
        _persist_panel_state (context )
        self .report ({'INFO'},pgettext ("Deleted state set: {}").format (name ))
        return {'FINISHED'}

        # ------------------------------------------------------------
        # Advanced stack ops
        # ------------------------------------------------------------

class MODSWITCH_OT_MoveMods (bpy .types .Operator ):
    bl_idname ="modswitch.move_mods"
    bl_label ="Move"
    bl_options ={'UNDO'}

    direction :bpy .props .EnumProperty (
    items =[
    ('UP',"Move Up","Move matching modifiers up (toward the top of the stack)"),
    ('DOWN',"Move Down","Move matching modifiers down (toward the bottom of the stack)"),
    ],
    default ='UP'
    )

    @classmethod 
    def description (cls ,context ,props ):
    # NOTE:
    # Blender calls Operator.description as a *classmethod*.
    # If this is defined as an instance method, tooltips can break
    # or show wrong text depending on Blender version.
        pgettext =_sms_pgettext 
        if props .direction =='UP':
            return pgettext (
            "Move the matching modifiers UP by one step for every matching object in the scene.\n"
            "Use this to keep modifier order consistent across many objects.\n"
            "Tip: Modifier order matters — moving can change the final result."
            )
        return pgettext (
        "Move the matching modifiers DOWN by one step for every matching object in the scene.\n"
        "Use this to keep modifier order consistent across many objects.\n"
        "Tip: Modifier order matters — moving can change the final result."
        )

    def execute (self ,context ):
        scene =context .scene 
        core .move_target_modifiers (context ,scene ,self .direction )
        return {'FINISHED'}

class MODSWITCH_OT_ApplyMods (bpy .types .Operator ):
    bl_idname ="modswitch.apply_mods"
    bl_label ="Apply Modifiers"
    bl_description =(
    "Apply (bake) the matching modifiers for all matching objects in the scene.\n"
    "This permanently changes geometry and removes the applied modifiers afterward.\n"
    "Beginner tip: If you only want to preview, use OFF/ON instead. Duplicate objects before applying if needed."
    )
    bl_options ={'UNDO'}

    def invoke (self ,context ,event ):
        return context .window_manager .invoke_confirm (self ,event )

    def execute (self ,context ):
        scene =context .scene
        if core .get_active_target (scene )is None :
            self .report ({'WARNING'},_sms_pgettext ("No targets."))
            return {'CANCELLED'}
        failures =[]
        applied =core .apply_target_modifiers (context ,scene ,failures )
        if failures :
            self .report ({'WARNING'},_sms_pgettext ("Applied {}. Not applied: {}").format (applied ," | ".join (failures )))
        else :
            self .report ({'INFO'},_sms_pgettext ("Applied {} modifiers.").format (applied ))
        return {'FINISHED'}if applied else {'CANCELLED'}

class MODSWITCH_OT_RemoveMods (bpy .types .Operator ):
    bl_idname ="modswitch.remove_mods"
    bl_label ="Remove Modifiers"
    bl_description =(
    "Remove the matching modifiers from all matching objects in the scene.\n"
    "This is destructive (it deletes the modifiers).\n"
    "Tip: If you might need them later, use OFF (disable) instead of removing."
    )
    bl_options ={'UNDO'}

    def invoke (self ,context ,event ):
        return context .window_manager .invoke_confirm (self ,event )

    def execute (self ,context ):
        scene =context .scene 
        core .remove_target_modifiers (context ,scene )
        return {'FINISHED'}


        # --- Tooltip completion ---
MODSWITCH_OT_ToggleAll .bl_description ='Toggle the enabled/disabled state of many modifiers at once inside the modifier switcher workflow.'
MODSWITCH_OT_MoveMods .bl_description ='Move grouped modifiers up or down together inside the modifier switcher workflow.'
