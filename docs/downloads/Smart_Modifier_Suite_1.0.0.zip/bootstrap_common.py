# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable, Sequence

import sys

import bpy

# The former Window-menu SmartTools bootstrap is intentionally disabled because
# SmartTools is now hosted entirely in each suite's 3D View N-panel category.

_STALE_EXTERNAL_ADDONS = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)


def _schedule_userpref_save() -> None:
    # Smart Modifier must not create or overwrite Blender user preference
    # files from install/startup cleanup paths. User settings are stored in the
    # Blender CONFIG/Smart_Modifier_Suite directory instead.
    return None


def cleanup_stale_external_addons(*, save_preferences: bool = False) -> bool:
    changed = False
    try:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        addons = getattr(prefs, 'addons', None) if prefs is not None else None
    except Exception:
        addons = None
    if addons is not None:
        for module_name in _STALE_EXTERNAL_ADDONS:
            addon_entry = None
            try:
                addon_entry = addons.get(module_name)
            except Exception:
                addon_entry = None
            if addon_entry is None:
                try:
                    addon_entry = addons[module_name]
                except Exception:
                    addon_entry = None
            if addon_entry is not None:
                try:
                    addons.remove(addon_entry)
                    changed = True
                except Exception:
                    try:
                        del addons[module_name]
                        changed = True
                    except Exception:
                        pass
            try:
                sys.modules.pop(module_name, None)
            except Exception:
                pass
    if changed and save_preferences:
        _schedule_userpref_save()
    return changed



def cleanup_empty_user_interface_keymaps() -> bool:
    # Compatibility cleanup used to remove empty keymaps.  Native keymap removal
    # is not worth the shutdown risk on Blender 5.1.x, so this function is now
    # intentionally non-destructive.  Leaving an empty keymap is safer than
    # freeing Blender-owned keymap/UI data during add-on reload or application
    # exit.
    return False


def ensure_user_interface_keymap() -> bool:
    # Do not create an empty "User Interface" keymap. Blender 5.x reports a
    # console warning for every empty keymap during event handling, so the safe
    # behavior is to remove only stale empty copies left by older builds.
    return cleanup_empty_user_interface_keymaps()

def safe_register_class(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if existing is cls:
            return True
        if isinstance(existing, type):
            try:
                pass  # session-stable: keep classes registered during live UI
            except Exception:
                pass
    except Exception:
        pass
    try:
        bpy.utils.register_class(cls)
        return True
    except (RuntimeError, ValueError):
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if isinstance(existing, type) and existing is not cls:
            try:
                pass  # session-stable: keep classes registered during live UI
                bpy.utils.register_class(cls)
                return True
            except Exception:
                return False
        return True
    except Exception:
        return False

def safe_unregister_class(cls: type) -> None:
    if not isinstance(cls, type):
        return
    try:
        pass  # session-stable: keep classes registered during live UI
    except Exception:
        pass


def safe_register_classes(classes: Iterable[type], *, registered: list[type] | None = None) -> tuple[type, ...]:
    out: list[type] = []
    for cls in classes:
        if safe_register_class(cls):
            out.append(cls)
            if isinstance(registered, list):
                registered.append(cls)
    return tuple(out)


def safe_unregister_classes(classes: Iterable[type]) -> None:
    for cls in reversed(tuple(classes)):
        safe_unregister_class(cls)


def iter_window_menu_classes(menu_names: Sequence[str] | None = None):
    del menu_names
    return iter(())


def iter_window_menu_draw_functions(menu_cls) -> tuple[object, ...]:
    del menu_cls
    return ()


def purge_window_menu_callbacks(menu_cls, matcher, *, keep=None) -> int:
    del menu_cls, matcher, keep
    return 0


def install_window_menu_entry(draw_fn, *, matcher=None, menu_names=None, install_all=False, redraw_area_types=None) -> tuple[str, ...]:
    del draw_fn, matcher, menu_names, install_all, redraw_area_types
    return ()


def remove_window_menu_entry(draw_fn=None, *, matcher=None, menu_names=None, redraw_area_types=None) -> None:
    del draw_fn, matcher, menu_names, redraw_area_types
    return None


def remove_window_menu_entry_if_unused(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_shared_window_menu_button_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_window_menu_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def tag_redraw_window_menu_areas(area_types: Sequence[str] | None = None) -> None:
    del area_types
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass
