# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

try:
    from .pseudo_properties import *  # noqa: F401,F403
except Exception:
    from pseudo_properties import *  # type: ignore # noqa: F401,F403
