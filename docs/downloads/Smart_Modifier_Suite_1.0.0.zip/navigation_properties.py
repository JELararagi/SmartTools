# SPDX-License-Identifier: GPL-3.0-or-later
"""Compatibility import for the modifier navigation settings."""

if __package__:
    from . import pseudo_properties as _source
else:
    import pseudo_properties as _source

__all__ = getattr(_source, "__all__", [name for name in vars(_source) if not name.startswith("_")])
globals().update((name, getattr(_source, name)) for name in __all__)
