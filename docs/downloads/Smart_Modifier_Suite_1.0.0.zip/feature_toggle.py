# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
import sys
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

try:
    from .icons import operator as _sms_icon_operator
except Exception:
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_DYNAMIC_PROP_NAMES: dict[tuple[str, str], str] = {}
_DYNAMIC_PROP_GUARD = False
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_PATCH_DEPTH = 0
_ORIGINALS: dict[str, Any] = {}
_ORIGINAL_DRAW_ADDS: dict[str, Any] = {}
_ORIGINAL_DRAW_REMOVES: dict[str, Any] = {}
_DUMMY_COUNTER = 0
_TOOL_SET_BY_ID_OPERATOR = 'wm.tool_set_by_id'
_STALE_TOOL_ID_PREFIXES = (
    'smart_tools',
    'smart_tools.',
    'smart_tools_',
    'smarttools.',
    'smarttools_',
    'bl_ext.user_default.smart_tools',
    'smart_modifier_suite.tool',
    'smart_modifier_suite.workspace_tool',
    'bl_ext.user_default.smart_modifier_suite.tool',
)

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The setting follows the N-panel State Save policy and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo / Redo、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。設定は「Nパネル状態保存」の保存方針に従い、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting follows the N-panel State Save policy and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は「Nパネル状態保存」の保存方針に従い、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'RNAメッセージバス監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The setting follows the N-panel State Save policy and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する msgbus 購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。設定は「Nパネル状態保存」の保存方針に従い、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Keymap auto-registration is disabled by Smart Modifier policy. Register shortcut operator IDs manually in Blender Preferences > Keymap when a tool section lists an ID.',
        'description_ja': 'Smart Modifier の方針としてキーマップ自動登録は無効です。ツールのセクションに登録IDが表示されている場合だけ、Blender のプリファレンス > キーマップへ手動登録してください。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting follows the N-panel State Save policy and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は「Nパネル状態保存」の保存方針に従い、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)


def _clean_identifier(value: str, fallback: str = 'smart_tools') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Modifier'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_tools'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def toggle_operator_id() -> str:
    configure(suite_key='smart_modifier_suite', suite_label='Smart Modifier', category='Smart Modifier')
    return str(_OPERATOR_ID or 'smart_modifier_suite.toggle_persistent_feature')


def _is_ja(context=None) -> bool:
    try:
        from .translation import ui_language
        return ui_language(context) == 'ja'
    except Exception:
        pass
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        if prefs is not None and not bool(getattr(prefs, 'use_translate_interface', True)):
            return False
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return str(ja if _is_ja(None) else en)


def _settings_path() -> Path | None:
    configure()
    try:
        from .storage import suite_config_path
        return suite_config_path(create=True)
    except Exception:
        try:
            base = Path(bpy.utils.user_resource('CONFIG', path='Smart_Modifier_Suite', create=True) or '')
            return base / 'Smart_Modifier_Suite.json' if str(base) else None
        except Exception:
            return None


def _legacy_settings_path() -> Path | None:
    configure()
    try:
        base = Path(bpy.utils.user_resource('CONFIG', create=False) or '')
        if not str(base):
            return None
        return base / 'smart_modifier_suite' / f'{_SUITE_KEY}_persistent_feature_toggles.json'
    except Exception:
        return None


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    paths: list[Path] = []
    primary = _settings_path()
    legacy = _legacy_settings_path()
    for path in (primary, legacy):
        if path is not None and path not in paths:
            paths.append(path)
    for path in paths:
        if path is None or not path.exists():
            continue
        try:
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                payload = raw.get('feature_toggles') if isinstance(raw.get('feature_toggles'), dict) else None
                if payload is None:
                    payload = raw.get('features') if isinstance(raw.get('features'), dict) else None
                if payload is None and not any(key in raw for key in ('settings', 'panel_state', 'common_state', 'feature_toggles')):
                    payload = raw
                if isinstance(payload, dict):
                    for alias, values in payload.items():
                        if isinstance(values, dict):
                            data[str(alias)] = {str(k): bool(v) for k, v in values.items()}
                if data:
                    break
        except Exception:
            data = {}
    _STATE_CACHE = data
    return _STATE_CACHE

def _save_state(*, force: bool = False, context=None) -> None:
    try:
        from .save_policy import should_write_config
        if not should_write_config(context, force=force):
            return
    except Exception:
        if not force:
            return
    path = _settings_path()
    if path is None:
        return
    try:
        payload = {}
        try:
            if path.exists():
                payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        payload.setdefault('version', 1)
        payload.setdefault('addon_id', _SUITE_KEY or 'smart_modifier_suite')
        payload['feature_toggles'] = _load_state()
        path.parent.mkdir(parents=True, exist_ok=True)
        from . import storage
        storage.atomic_write_json(path, payload, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        pass


def save_state(context=None, *, force: bool = False) -> None:
    _save_state(force=force, context=context)


def _dynamic_feature_prop_name(alias: str, feature_key: str) -> str:
    alias_slug = _clean_identifier(alias, 'tool')[:36]
    key_slug = _clean_identifier(feature_key, 'feature')[:32]
    return f"sms_runtime_feature_{alias_slug}_{key_slug}"


def _feature_by_alias_key(alias: str, feature_key: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return None
    return _FEATURES.get(alias, {}).get(feature_key)


def _sync_dynamic_feature_property(alias: str, feature_key: str, enabled: bool) -> None:
    global _DYNAMIC_PROP_GUARD
    key = (str(alias or '').strip(), str(feature_key or '').strip())
    prop_name = _DYNAMIC_PROP_NAMES.get(key)
    if not prop_name:
        return
    _DYNAMIC_PROP_GUARD = True
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and hasattr(wm, prop_name):
            try:
                setattr(wm, prop_name, bool(enabled))
            except Exception:
                pass
    finally:
        _DYNAMIC_PROP_GUARD = False


def _make_feature_property_update(alias: str, feature_key: str, prop_name: str):
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    prop_name = str(prop_name or '').strip()

    def _update(self, context):
        del context
        if _DYNAMIC_PROP_GUARD:
            return
        try:
            set_feature_enabled(alias, feature_key, bool(getattr(self, prop_name, False)))
        except Exception:
            pass

    return _update


def ensure_feature_property(entry_or_alias: Any, feature_key: str | None = None, context=None) -> str:
    """Return no dynamic property during UI drawing.

    Adding or deleting WindowManager RNA properties while the N-panel is being
    redrawn can leave Blender's C++ panel handler with stale property pointers.
    The always-on list therefore uses operator buttons instead of creating
    per-feature BoolProperty instances dynamically.
    """
    del entry_or_alias, feature_key, context
    return ''

def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    _sync_dynamic_feature_property(alias, feature_key, bool(enabled))
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    feature.setdefault('actions', []).append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            item['property_name'] = ''
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _is_required_xform_load_handler(list_name: str, fn: Any) -> bool:
    """Exclude only exact live deformation restoration callbacks on required lists.

    Its owning library registers/unregisters it. It is not a continuous feature,
    and excluding it neither enables other callbacks nor grants group ownership.
    """
    module_name = str(__package__ or '') + '.subtools.max_modifier_library'
    module = sys.modules.get(module_name)
    required_lists = {
        '_rehydrate_xform_load_post': ('load_post', 'undo_post', 'redo_post'),
        '_rehydrate_skew_undo_redo_post': ('undo_post', 'redo_post'),
        '_rehydrate_noise_load_post': ('load_post',),
        '_rehydrate_noise_undo_redo_post': ('undo_post', 'redo_post'),
        '_rehydrate_push_load_undo_redo_post': ('load_post', 'undo_post', 'redo_post'),
        '_rehydrate_preserve_load_undo_redo_post': ('load_post', 'undo_post', 'redo_post'),
        '_rehydrate_sweep_load_undo_redo_post': ('load_post', 'undo_post', 'redo_post'),
    }
    function_name = getattr(fn, '__name__', '')
    return (
        list_name in required_lists.get(function_name, ())
        and module is not None
        and callable(fn)
        and getattr(fn, '__module__', '') == module_name
        and fn is getattr(module, function_name, None)
    )


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                if _is_required_xform_load_handler(name, fn):
                    continue
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _snapshot_keymaps() -> set[int]:
    ids: set[int] = set()
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                ids.add(id(kmi))
    except Exception:
        pass
    return ids


def _copy_keymap_properties(_kmi) -> dict[str, Any]:
    # Do not touch KeyMapItem.properties here.  On Blender 5.1.x the operator
    # property RNA for keymap items can be partially torn down during add-on
    # reload/exit, and merely reading bl_rna has produced native crashes before
    # Python can catch anything.  Feature-toggle bookkeeping only needs to know
    # that a shortcut exists; it must not deep-copy Blender-owned UI property
    # data.
    return {}



def _is_stale_or_empty_tool_id(tool_id: str) -> bool:
    text = str(tool_id or '').strip()
    if not text:
        return True
    lowered = text.lower()
    return any(lowered == prefix or lowered.startswith(prefix) for prefix in _STALE_TOOL_ID_PREFIXES)


def _is_drag_clone_selection_tool_keymap_action(action: dict[str, Any]) -> bool:
    try:
        if str(action.get('idname') or '') not in {'view3d.max_shift_drag_clone', 'view3d.max_shift_drag_clone_confirm'}:
            return False
        km_name = str(action.get('km_name') or '').lower()
        if not km_name.startswith('3d view tool:'):
            return False
        return 'select' in km_name or 'tweak' in km_name
    except Exception:
        return False


def _invalid_tool_keymap_action(action: dict[str, Any]) -> bool:
    try:
        if str(action.get('idname') or '') != _TOOL_SET_BY_ID_OPERATOR:
            return False
        props = action.get('properties') or {}
        tool_id = str(props.get('name') or props.get('idname') or props.get('tool_name') or props.get('tool_id') or '').strip()
        return _is_stale_or_empty_tool_id(tool_id)
    except Exception:
        return False


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'km': km,
        'kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(_before: set[int]) -> list[dict[str, Any]]:
    """Never capture keymaps for later auto-reapply. Shortcut IDs are manual-only."""
    return []


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = _ORIGINAL_DRAW_REMOVES.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            if km is not None and kmi is not None:
                # Blender 5.1 can crash in rna_KeyMap_item_remove() when a
                # stale KeyMapItem is removed during application shutdown.
                # Disabling the item provides the same user-facing inactive
                # state without calling the unsafe native remove path.
                try:
                    kmi.active = False
                except Exception:
                    pass
            action['active_km'] = None
            action['active_kmi'] = None
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    """No-op: the add-on must never create keymap entries automatically."""
    try:
        action['active'] = False
        action['active_km'] = None
        action['active_kmi'] = None
    except Exception:
        pass


def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and fn not in seq:
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = _ORIGINALS.get('timer_register') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = _ORIGINALS.get('msgbus_subscribe') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = _ORIGINAL_DRAW_ADDS.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER += 1
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')


def _timer_register_proxy(function, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['timer_register'](function, *args, **kwargs)
    action = {'kind': 'timers', 'fn': function, 'args': tuple(args), 'kwargs': dict(kwargs), 'active': False}
    cap.record_action('timers', action)
    if cap.kind_enabled('timers'):
        result = _ORIGINALS['timer_register'](function, *args, **kwargs)
        action['active'] = True
        return result
    return None


def _msgbus_subscribe_proxy(*args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
    owner = kwargs.get('owner')
    if owner is None and len(args) >= 2:
        owner = args[1]
    action = {'kind': 'msgbus', 'args': tuple(args), 'kwargs': dict(kwargs), 'owner': owner, 'active': False}
    cap.record_action('msgbus', action)
    if cap.kind_enabled('msgbus'):
        result = _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
        action['active'] = True
        return result
    return None


def _make_draw_add_proxy(space_name: str, space_cls, original_add):
    def _proxy(*args, **kwargs):
        cap = _current_capture()
        if cap is None:
            return original_add(*args, **kwargs)
        region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
        action = {
            'kind': 'draw_handlers',
            'space_name': space_name,
            'space_cls': space_cls,
            'args': tuple(args),
            'kwargs': dict(kwargs),
            'region_type': region_type,
            'handle': None,
            'active': False,
        }
        cap.record_action('draw_handlers', action)
        if cap.kind_enabled('draw_handlers'):
            action['handle'] = original_add(*args, **kwargs)
            action['active'] = True
            return action['handle']
        return _next_dummy_handle()
    return _proxy


def _install_patches() -> None:
    """Startup-safe capture mode.

    Blender 5.x can become unstable when add-ons monkey-patch timer, msgbus,
    or draw-handler functions while UI panels are being registered or drawn.
    This suite therefore avoids global API patching entirely. Explicit
    always-on switches control the known runtime services. Keymap auto-capture
    and auto-reapply are disabled; shortcut operator IDs are manual-only.
    """
    global _PATCH_DEPTH
    _PATCH_DEPTH += 1
    return None


def _uninstall_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH = max(0, _PATCH_DEPTH - 1)
    if _PATCH_DEPTH > 0:
        return None
    _ORIGINALS.clear()
    _ORIGINAL_DRAW_ADDS.clear()
    _ORIGINAL_DRAW_REMOVES.clear()
    return None


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        _install_patches()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
                if not self.kind_enabled('handlers'):
                    _remove_action(action)
            for action in _collect_new_keymaps(self._before_keymaps):
                self.record_action('keymaps', action)
                if not self.kind_enabled('keymaps'):
                    _remove_action(action)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _uninstall_patches()
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass




def _operator_id_is_registered(operator_id: str) -> bool:
    """Return True when Blender already has this operator bl_idname registered.

    Blender 5.1 logs an Info line and silently unregisters the previous operator
    when bpy.utils.register_class() is called again for an already registered
    bl_idname.  During add-on disable/re-enable we intentionally keep the small
    feature-toggle operator class alive for UI safety, so use the operator RNA
    lookup instead of class-name lookup to avoid duplicate registration noise.
    """
    try:
        category, name = str(operator_id or '').split('.', 1)
    except Exception:
        return False
    try:
        op_category = getattr(bpy.ops, category, None)
        if op_category is None:
            return False
        op = getattr(op_category, name, None)
        if op is None:
            return False
        try:
            op.get_rna_type()
        except Exception:
            return False
        return True
    except Exception:
        return False


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効 / 無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Modifier feature. The setting follows the N-panel State Save policy.', 'Smart Modifier の常時起動機能を切り替えます。設定は「Nパネル状態保存」の保存方針に従います。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID
    if _operator_id_is_registered(operator_id):
        return

    class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = 'Toggle Feature'
        bl_description = 'Switch an always-on feature on or off. Saving follows the N-panel State Save policy.'
        bl_options = {'UNDO'}

        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting saved.', '機能設定を保存しました。'))
            return {'FINISHED'}

    SMARTTOOLS_OT_toggle_persistent_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_toggle_persistent_feature.__qualname__ = SMARTTOOLS_OT_toggle_persistent_feature.__name__
    SMARTTOOLS_OT_toggle_persistent_feature.__module__ = __name__
    try:
        existing = getattr(bpy.types, SMARTTOOLS_OT_toggle_persistent_feature.__name__, None)
        if isinstance(existing, type) and existing is not SMARTTOOLS_OT_toggle_persistent_feature:
            _REGISTERED_CLASSES.append(existing)
            return
    except Exception:
        pass
    try:
        bpy.utils.register_class(SMARTTOOLS_OT_toggle_persistent_feature)
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except RuntimeError:
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except Exception:
        raise


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> None:
    # Registration is owned exclusively by the add-on lifecycle.  Draw never
    # repairs classes, and disable must release the operator so repeated
    # enable/disable cycles cannot retain stale extension module types.
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _DYNAMIC_PROP_NAMES.clear()
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(_kmi, _prop_name, _value) -> bool:
    # Keymap auto-reapply is disabled.  Keep this helper inert so older captured
    # metadata cannot mutate Blender-owned KeyMapItem property memory.
    return False
