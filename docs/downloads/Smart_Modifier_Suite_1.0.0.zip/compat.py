# SPDX-License-Identifier: GPL-3.0-or-later
"""Select a builtin uniform-color shader on supported Blender GPU versions."""

import gpu


def get_uniform_color_shader(dimension="3D"):
    try:
        return gpu.shader.from_builtin("UNIFORM_COLOR")
    except Exception:
        fallback = "2D_UNIFORM_COLOR" if str(dimension).startswith("2") else "3D_UNIFORM_COLOR"
        return gpu.shader.from_builtin(fallback)
