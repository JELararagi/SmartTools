# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from __future__ import annotations 

import bpy 

try :
    import bmesh 
except Exception :# pragma: no cover - Blender runtime only
    bmesh =None 

from .utils import operator_available ,operator_runnable 

_STATUS_TEXT ={
"ready":('Ready',"CHECKMARK"),
"context":('Needs context',"NONE"),
"missing":('Missing',"ERROR"),
}


def _block (en :str ,ja :str )->tuple [str ,str ]:
    return (str (en ).strip (),str (ja ).strip ())


    # -----------------------------------------------------------------------------
    # Context snapshot helpers
    # -----------------------------------------------------------------------------

def _context_mode (context )->str :
    try :
        mode =getattr (context ,"mode","")or ""
        if mode :
            return str (mode )
    except Exception :
        pass 
    obj =_active_object (context )
    try :
        return str (getattr (obj ,"mode","")or "")
    except Exception :
        return ""


def _active_object (context ):
    try :
        return getattr (context ,"active_object",None )
    except Exception :
        return None 



def _selected_objects (context )->list :
    try :
        return list (getattr (context ,"selected_objects",[])or [])
    except Exception :
        return []



def _obj_type (obj )->str :
    try :
        return str (getattr (obj ,"type","")or "")
    except Exception :
        return ""



def _selected_of_type (context ,obj_types :set [str ]|tuple [str ,...],*,exclude_active :bool =False )->list :
    active =_active_object (context )
    types =set (obj_types or [])
    result =[]
    for obj in _selected_objects (context ):
        if exclude_active and active is not None and obj ==active :
            continue 
        if _obj_type (obj )in types :
            result .append (obj )
    return result 



def _selection_counts (context )->dict :
    active =_active_object (context )
    counts ={
    "verts":0 ,
    "edges":0 ,
    "faces":0 ,
    "active_face":False ,
    }
    if _context_mode (context )!="EDIT_MESH":
        return counts 
    if active is None or _obj_type (active )!="MESH":
        return counts 
    if bmesh is None :
        return counts 
    try :
        bm =bmesh .from_edit_mesh (active .data )
    except Exception :
        return counts 
    try :
        counts ["verts"]=sum (1 for v in bm .verts if getattr (v ,"select",False ))
        counts ["edges"]=sum (1 for e in bm .edges if getattr (e ,"select",False ))
        counts ["faces"]=sum (1 for f in bm .faces if getattr (f ,"select",False ))
        counts ["active_face"]=bool (getattr (getattr (bm ,"faces",None ),"active",None ))
    except Exception :
        pass 
    return counts 


    # -----------------------------------------------------------------------------
    # Blocker helpers
    # -----------------------------------------------------------------------------

def _ensure_object_mode (context ,blockers :list [tuple [str ,str ]]):
    if _context_mode (context )!="OBJECT":
        blockers .append (_block ("Switch to Object Mode.","オブジェクトモードに切り替えてください。"))



def _ensure_edit_mesh_mode (context ,blockers :list [tuple [str ,str ]]):
    if _context_mode (context )!="EDIT_MESH":
        blockers .append (_block ("Switch to Edit Mesh mode.","編集メッシュモードに切り替えてください。"))



def _ensure_mode_any (context ,blockers :list [tuple [str ,str ]],modes :tuple [str ,...],en :str ,ja :str ):
    if _context_mode (context )not in set (modes or ()):
        blockers .append (_block (en ,ja ))



def _ensure_active_any (context ,blockers :list [tuple [str ,str ]]):
    if _active_object (context )is None :
        blockers .append (_block ("Set an active object.","アクティブオブジェクトを設定してください。"))



def _ensure_active_mesh (context ,blockers :list [tuple [str ,str ]],*,label_en :str ="active mesh",label_ja :str ="アクティブメッシュ"):
    obj =_active_object (context )
    if obj is None :
        blockers .append (_block (f"Set an {label_en }.",f"{label_ja }を設定してください。"))
        return 
    if _obj_type (obj )!="MESH":
        blockers .append (_block (f"Make the {label_en } a mesh object.",f"{label_ja }をメッシュオブジェクトにしてください。"))



def _ensure_active_curve (context ,blockers :list [tuple [str ,str ]],*,label_en :str ="active curve",label_ja :str ="アクティブカーブ"):
    obj =_active_object (context )
    if obj is None :
        blockers .append (_block (f"Set an {label_en }.",f"{label_ja }を設定してください。"))
        return 
    if _obj_type (obj )!="CURVE":
        blockers .append (_block (f"Make the {label_en } a curve object.",f"{label_ja }をカーブオブジェクトにしてください。"))



def _ensure_active_mesh_or_curve (context ,blockers :list [tuple [str ,str ]]):
    obj =_active_object (context )
    if obj is None :
        blockers .append (_block ("Set an active mesh or curve object.","アクティブなメッシュまたはカーブを設定してください。"))
        return 
    if _obj_type (obj )not in {"MESH","CURVE"}:
        blockers .append (_block ("Use a mesh or curve as the active object.","アクティブオブジェクトにはメッシュまたはカーブを使ってください。"))



def _ensure_selected_count (context ,blockers :list [tuple [str ,str ]],count :int ,*,types :set [str ]|None =None ,exclude_active :bool =False ,en :str |None =None ,ja :str |None =None ):
    if types :
        selected =_selected_of_type (context ,types ,exclude_active =exclude_active )
    else :
        selected =_selected_objects (context )
        if exclude_active :
            active =_active_object (context )
            selected =[obj for obj in selected if active is None or obj !=active ]
    if len (selected )<int (count ):
        blockers .append (_block (en or f"Select at least {count } more object(s).",ja or f"追加オブジェクトを少なくとも{count }個選択してください。"))



def _ensure_selected_exact_edges (context ,blockers :list [tuple [str ,str ]],count :int ):
    counts =_selection_counts (context )
    if counts ["edges"]!=int (count ):
        blockers .append (_block (f"Select exactly {count } edge(s).",f"ちょうど{count }本の辺を選択してください。"))



def _ensure_selected_components (context ,blockers :list [tuple [str ,str ]],*,verts_min :int =0 ,edges_min :int =0 ,faces_min :int =0 ,any_min :int =0 ):
    counts =_selection_counts (context )
    total =counts ["verts"]+counts ["edges"]+counts ["faces"]
    if any_min and total <int (any_min ):
        blockers .append (_block ("Select mesh components before running the tool.","実行前にメッシュ要素を選択してください。"))
    if verts_min and counts ["verts"]<int (verts_min ):
        blockers .append (_block (f"Select at least {verts_min } vertex/vertices.",f"頂点を少なくとも{verts_min }個選択してください。"))
    if edges_min and counts ["edges"]<int (edges_min ):
        blockers .append (_block (f"Select at least {edges_min } edge(s).",f"辺を少なくとも{edges_min }本選択してください。"))
    if faces_min and counts ["faces"]<int (faces_min ):
        blockers .append (_block (f"Select at least {faces_min } face(s).",f"フェースを少なくとも{faces_min }枚選択してください。"))



def _ensure_active_face (context ,blockers :list [tuple [str ,str ]]):
    counts =_selection_counts (context )
    if not counts .get ("active_face"):
        blockers .append (_block ("Set an active face on the edit mesh.","編集メッシュでアクティブフェースを設定してください。"))


        # -----------------------------------------------------------------------------
        # Per-tool validators
        # -----------------------------------------------------------------------------


def _v_pivot_to_selection (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,any_min =1 )
    return b 



def _v_pivot_to_bottom (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (
    context ,
    b ,
    1 ,
    en ="Select one or more objects.",
    ja ="1つ以上のオブジェクトを選択してください。",
    )
    return b 


def _v_drop_to_floor (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (
    context ,
    b ,
    1 ,
    en ="Select one or more objects.",
    ja ="1つ以上のオブジェクトを選択してください。",
    )
    return b 


def _v_align_to_active (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_any (context ,b )
    _ensure_selected_count (
    context ,
    b ,
    1 ,
    exclude_active =True ,
    en ="Select at least one target object in addition to the active source object.",
    ja ="アクティブな基準オブジェクトに加えて、ターゲットを1つ以上選択してください。",
    )
    return b 


def _v_distribute_selected (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (
    context ,
    b ,
    3 ,
    exclude_active =False ,
    en ="Select at least three objects to distribute.",
    ja ="均等配置するには少なくとも3つのオブジェクトを選択してください。",
    )
    return b 


def _v_stack_selected (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (
    context ,
    b ,
    2 ,
    exclude_active =False ,
    en ="Select at least two objects to stack.",
    ja ="スタック配置するには少なくとも2つのオブジェクトを選択してください。",
    )
    return b 


def _v_quad_checker (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 


def _v_boolean_stack (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active target mesh",label_ja ="アクティブなターゲットメッシュ")
    _ensure_selected_count (context ,b ,1 ,types ={"MESH"},exclude_active =True ,
    en ="Select at least one additional mesh to use as a cutter.",
    ja ="カッターとして使う追加メッシュを1つ以上選択してください。")
    return b 



def _v_hard_surface (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,1 ,types ={"MESH"},exclude_active =False ,
    en ="Select at least one mesh object.",
    ja ="メッシュオブジェクトを1つ以上選択してください。")
    return b 



def _v_audit_repair (context ):
    b =[]
    _ensure_mode_any (context ,b ,("OBJECT","EDIT_MESH"),"Use Object Mode or Edit Mesh mode.","オブジェクトモードまたは編集メッシュモードで使ってください。")
    _ensure_active_mesh (context ,b )
    return b 



def _v_curve (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,edges_min =1 )
    return b 



def _v_path (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,2 ,exclude_active =False ,
    en ="Select at least two objects to build a path.",
    ja ="パス化するオブジェクトを少なくとも2つ選択してください。")
    return b 



def _v_vertices_path (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,verts_min =1 )
    return b 



def _v_pipe (context ):
    if _context_mode (context )=="EDIT_MESH"and _obj_type (_active_object (context ))=="MESH":
        b =[]
        _ensure_active_mesh (context ,b )
        _ensure_selected_components (context ,b ,edges_min =1 )
        return b 
    if _context_mode (context )=="OBJECT"and _obj_type (_active_object (context ))=="CURVE":
        return []
    return [
    _block (
    "Either use Edit Mesh mode with selected edges, or use Object Mode with an active curve.",
    "編集メッシュモードで辺を選択するか、オブジェクトモードでアクティブカーブを使ってください。",
    )
    ]



def _v_array_along_curve (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_count (context ,b ,1 ,types ={"CURVE"},exclude_active =True ,
    en ="Select at least one curve path in addition to the active mesh.",
    ja ="アクティブメッシュに加えて、カーブパスを1本以上選択してください。")
    return b 



def _v_instances_along_path (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_curve (context ,b )
    _ensure_selected_count (context ,b ,1 ,exclude_active =True ,
    en ="Select at least one source object in addition to the active curve.",
    ja ="アクティブカーブに加えて、ソースオブジェクトを1つ以上選択してください。")
    return b 



def _v_loft (context ):
    if _context_mode (context )=="OBJECT":
        curves =_selected_of_type (context ,{"CURVE"},exclude_active =False )
        if len (curves )>=2 :
            return []
    if _context_mode (context )=="EDIT_MESH"and _obj_type (_active_object (context ))=="MESH":
        counts =_selection_counts (context )
        if counts ["edges"]>=2 :
            return []
    return [
    _block (
    "Use either Object Mode with two curves selected, or Edit Mesh mode with two edge paths selected.",
    "オブジェクトモードで2本のカーブを選択するか、編集メッシュモードで2本の辺パスを選択してください。",
    )
    ]



def _v_sweep (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_curve (context ,b ,label_en ="active path curve",label_ja ="アクティブなパスカーブ")
    _ensure_selected_count (context ,b ,1 ,types ={"CURVE"},exclude_active =True ,
    en ="Select one profile curve in addition to the active path curve.",
    ja ="アクティブなパスカーブに加えて、断面カーブを1本選択してください。")
    return b 



def _v_profile_primitive (context ):
    b =[]
    _ensure_object_mode (context ,b )
    return b 



def _v_helix_path (context ):
    b =[]
    _ensure_object_mode (context ,b )
    return b 



def _v_projection (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active source mesh",label_ja ="アクティブなソースメッシュ")
    _ensure_selected_components (context ,b ,verts_min =1 )
    _ensure_selected_count (context ,b ,1 ,types ={"MESH"},exclude_active =True ,
    en ="Keep at least one target surface mesh selected in addition to the source mesh.",
    ja ="ソースメッシュに加えて、投影先サーフェスメッシュを1つ以上選択したままにしてください。")
    return b 



def _v_surface_conform (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active surface mesh",label_ja ="アクティブなサーフェスメッシュ")
    _ensure_selected_count (context ,b ,1 ,exclude_active =True ,
    en ="Select at least one detail object in addition to the active surface.",
    ja ="アクティブなサーフェスに加えて、ディテールオブジェクトを1つ以上選択してください。")
    return b 



def _v_normal_transfer (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active source mesh",label_ja ="アクティブな元メッシュ")
    _ensure_selected_count (context ,b ,1 ,types ={"MESH"},exclude_active =True ,
    en ="Select at least one target mesh in addition to the active source mesh.",
    ja ="アクティブな元メッシュに加えて、ターゲットメッシュを1つ以上選択してください。")
    return b 



def _v_symmetry (context ):
    b =[]
    _ensure_mode_any (context ,b ,("OBJECT","EDIT_MESH"),"Use Object Mode or Edit Mesh mode.","オブジェクトモードまたは編集メッシュモードで使ってください。")
    _ensure_active_mesh (context ,b )
    return b 



def _v_floor (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_replace (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_any (context ,b )
    _ensure_selected_count (context ,b ,1 ,exclude_active =True ,
    en ="Select at least one target object in addition to the active source object.",
    ja ="アクティブな元オブジェクトに加えて、置換対象オブジェクトを1つ以上選択してください。")
    return b 



def _v_randomize (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,1 ,exclude_active =False ,
    en ="Select one or more objects.",
    ja ="オブジェクトを1つ以上選択してください。")
    return b 



def _v_quick_solidify (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_smart_lattice (context ):
    b =[]
    _ensure_mode_any (context ,b ,("OBJECT","EDIT_MESH"),"Use Object Mode or Edit Mesh mode.","オブジェクトモードまたは編集メッシュモードで使ってください。")
    _ensure_active_mesh (context ,b )
    return b 



def _v_mesh_or_curve_active (context ):
    b =[]
    _ensure_active_mesh_or_curve (context ,b )
    return b 



def _v_reset_xform (context ):
    b =[]
    _ensure_mode_any (context ,b ,("OBJECT","EDIT_MESH"),"Use Object Mode or Edit Mesh mode.","オブジェクトモードまたは編集メッシュモードで使ってください。")
    if _context_mode (context )=="OBJECT":
        _ensure_selected_count (context ,b ,1 ,types ={ "MESH" },exclude_active =False ,
        en ="Select one or more mesh objects.",
        ja ="メッシュオブジェクトを1つ以上選択してください。")
    else:
        _ensure_active_mesh (context ,b )
    return b 



def _v_relax (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_cast (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_scatter (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active surface mesh",label_ja ="アクティブなサーフェスメッシュ")
    _ensure_selected_count (context ,b ,1 ,exclude_active =True ,
    en ="Select at least one source object to scatter in addition to the active surface.",
    ja ="アクティブなサーフェスに加えて、散布するソースオブジェクトを1つ以上選択してください。")
    return b 



def _v_smart_fill (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,any_min =1 )
    return b 



def _v_straighten (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    counts =_selection_counts (context )
    if counts ["verts"]<1 and counts ["edges"]<1 :
        b .append (_block ("Select vertices or edges to straighten.","整列する頂点または辺を選択してください。"))
    return b 



def _v_circle (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,verts_min =1 )
    return b 



def _v_smart_extrude (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,faces_min =1 )
    return b 



def _v_slice_panel (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_surface_box_detail (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_active_face (context ,b )
    return b 



def _v_axis_slice (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    return b 



def _v_workplane (context ):
    b =[]
    _ensure_mode_any (context ,b ,("OBJECT","EDIT_MESH"),"Use Object Mode or Edit Mesh mode.","オブジェクトモードまたは編集メッシュモードで使ってください。")
    _ensure_active_mesh (context ,b )
    return b 



def _v_cad_intersect (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_exact_edges (context ,b ,2 )
    return b 



def _v_face_component_array (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_mesh (context ,b ,label_en ="active component mesh",label_ja ="アクティブな部品メッシュ")
    _ensure_selected_count (context ,b ,1 ,types ={"MESH"},exclude_active =True ,
    en ="Select at least one target mesh in addition to the active component mesh.",
    ja ="アクティブな部品メッシュに加えて、ターゲットメッシュを1つ以上選択してください。")
    return b 



def _v_rebuild_curve (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_active_curve (context ,b )
    return b 



def _v_project_to_active_plane (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    counts =_selection_counts (context )
    if counts ["faces"]<1 and counts ["edges"]<1 :
        b .append (_block ("Select a face or an edge to define the active plane.","アクティブ平面を定義するフェースまたは辺を選択してください。"))
    return b 



def _v_audit_selected (context ):
    b =[]
    _ensure_active_mesh (context ,b )
    return b 



def _v_detach_separate_clean (context ):
    b =[]
    _ensure_edit_mesh_mode (context ,b )
    _ensure_active_mesh (context ,b )
    _ensure_selected_components (context ,b ,any_min =1 )
    return b 



def _v_solo_selected (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,1 ,exclude_active =False ,
    en ="Select one or more objects to solo.",
    ja ="ソロ表示するオブジェクトを1つ以上選択してください。")
    return b 



def _v_drop_to_surface (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,2 ,exclude_active =False ,
    en ="Select movable object(s) and a surface target.",
    ja ="移動するオブジェクトとサーフェスターゲットを選択してください。")
    _ensure_active_mesh (context ,b ,label_en ="active surface target",label_ja ="アクティブなサーフェスターゲット")
    return b 



def _v_combine_join_clean (context ):
    b =[]
    _ensure_object_mode (context ,b )
    _ensure_selected_count (context ,b ,2 ,types ={"MESH"},exclude_active =False ,
    en ="Select at least two mesh objects to combine.",
    ja ="結合するメッシュオブジェクトを少なくとも2つ選択してください。")
    return b 


PLUGIN_CONTEXT_VALIDATORS ={
"boolean_stack_modifier":_v_boolean_stack ,
"curve_modifier":_v_curve ,
"path_modifier":_v_path ,
"vertices_path_modifier":_v_vertices_path ,
"pipe_modifier":_v_pipe ,
"array_along_curve_modifier":_v_array_along_curve ,
"instances_along_path_modifier":_v_instances_along_path ,
"loft_modifier":_v_loft ,
"sweep_modifier":_v_sweep ,
"profile_primitive_modifier":_v_profile_primitive ,
"helix_path_modifier":_v_helix_path ,
"projection_modifier":_v_projection ,
"floor_modifier":_v_floor ,
"replace_modifier":_v_replace ,
"randomize_modifier":_v_randomize ,
"edit_poly":_v_smart_lattice ,
"smart_lattice":_v_smart_lattice ,
"reset_xform_modifier":_v_reset_xform ,
"unwrap_uvw_modifier":_v_reset_xform ,
"uvw_map_modifier":_v_reset_xform ,
"scatter_modifier":_v_scatter ,
"fill_modifier":_v_smart_fill ,
"straighten_modifier":_v_straighten ,
"circle_modifier":_v_circle ,
"extrude_modifier":_v_smart_extrude ,
"slice_panel_modifier":_v_slice_panel ,
"surface_box_detail_modifier":_v_surface_box_detail ,
"axis_slice_modifier":_v_axis_slice ,
"workplane_modifier":_v_workplane ,
"cad_intersect_modifier":_v_cad_intersect ,
"face_component_array_modifier":_v_face_component_array ,
"rebuild_curve_modifier":_v_rebuild_curve ,
"project_to_active_plane_modifier":_v_project_to_active_plane ,
"audit_select_issues_modifier":_v_audit_selected ,
"audit_selected_modifier":_v_audit_selected ,
"detach_separate_clean_modifier":_v_detach_separate_clean ,
"solo_selected_modifier":_v_solo_selected ,
"drop_to_surface_modifier":_v_drop_to_surface ,
"combine_join_clean_modifier":_v_combine_join_clean ,
"pivot_to_selection_modifier":_v_pivot_to_selection ,
"pivot_to_bottom_modifier":_v_pivot_to_bottom ,
"drop_to_floor_modifier":_v_drop_to_floor ,
"align_to_active_modifier":_v_align_to_active ,
"distribute_selected_modifier":_v_distribute_selected ,
"stack_selected_modifier":_v_stack_selected ,
"quad_checker_modifier":_v_quad_checker ,
}


def _max_modifier_context_blockers(context, plugin_id: str | None):
    pid = str(plugin_id or '')
    if not pid.startswith('max_'):
        return []
    try:
        from .max_modifier_definitions import get_max_modifier_definition
        defn = get_max_modifier_definition(plugin_id=pid)
    except Exception:
        defn = None
    if not isinstance(defn, dict):
        return []
    blockers = []
    _ensure_object_mode(context, blockers)
    types = {str(t) for t in (defn.get('object_types') or ('MESH',)) if str(t)}
    selected = _selected_of_type(context, types)
    active = _active_object(context)
    if not selected and (active is None or _obj_type(active) not in types):
        type_text = '/'.join(sorted(types)) or 'supported'
        blockers.append(_block(f'Select at least one {type_text} object.', f'{type_text} オブジェクトを少なくとも1つ選択してください。'))
    return blockers


_OBJECT_MODE_BRIDGE_BLOCKERS = {
    _block('Switch to Object Mode.', 'オブジェクトモードに切り替えてください。'),
}


def _supports_edit_mode_bridge(plugin_id: str | None, operator_id: str | None = None) -> bool:
    pid = str(plugin_id or '').strip()
    if not pid:
        return False
    if pid.startswith('max_'):
        return True
    try:
        from .plugin_catalog import is_stack_addable_plugin
        return bool(is_stack_addable_plugin(plugin_id=pid, operator_id=str(operator_id or '').strip()))
    except Exception:
        return False


def _filter_edit_mode_bridge_blockers(context, plugin_id: str | None, operator_id: str | None, blockers):
    if not str(_context_mode(context) or '').startswith('EDIT'):
        return list(blockers or [])
    if not _supports_edit_mode_bridge(plugin_id, operator_id):
        return list(blockers or [])
    out = []
    for blocker in (blockers or []):
        key = (str(blocker[0]).strip(), str(blocker[1]).strip()) if isinstance(blocker, (tuple, list)) and len(blocker) >= 2 else None
        if key in _OBJECT_MODE_BRIDGE_BLOCKERS:
            continue
        out.append(key if key else blocker)
    return out


def plugin_has_context_validation (plugin_id :str |None )->bool :
    pid = str(plugin_id or '')
    return bool (pid and (pid in PLUGIN_CONTEXT_VALIDATORS or pid.startswith('max_')))



def get_plugin_context_blockers (context ,plugin_id :str |None =None ,operator_id :str |None =None )->list [tuple [str ,str ]]:
    if not plugin_id :
        return []
    validator =PLUGIN_CONTEXT_VALIDATORS .get (plugin_id )
    if not callable (validator ):
        blockers =_max_modifier_context_blockers (context ,plugin_id )
    else :
        try :
            blockers =validator (context )or []
        except Exception :
            blockers =[_block ("Validate the current mode, selection, and active object before running this tool.","実行前に現在のモード、選択状態、アクティブオブジェクトを確認してください。")]
    blockers =_filter_edit_mode_bridge_blockers (context ,plugin_id ,operator_id ,blockers )
    result =[]
    seen =set ()
    for en ,ja in blockers :
        key =(str (en ).strip (),str (ja ).strip ())
        if key in seen :
            continue 
        seen .add (key )
        result .append (key )
    return result 



def summarize_blockers (blockers :list [tuple [str ,str ]]|None ,*,lang :str ="en",limit :int =3 )->str :
    items =blockers or []
    if not items :
        return ""
    texts =[]
    index =0 if lang =="en"else 1 
    for blocker in items [:max (1 ,int (limit ))]:
        try :
            text =str (blocker [index ]).strip ()
        except Exception :
            text =""
        if text :
            texts .append (text )
    remainder =max (0 ,len (items )-max (1 ,int (limit )))
    if remainder >0 :
        texts .append (f"+{remainder } more"if lang =="en"else f"ほか{remainder }件")
    return " | ".join (texts )



def get_tool_runtime_status (context ,plugin_id :str |None ,operator_id :str |None )->dict :
    op_id =str (operator_id or "").strip ()
    available =operator_available (op_id )if op_id else False 
    runnable =operator_runnable (op_id )if available else False 
    if available and str (_context_mode (context )or '').startswith ('EDIT')and _supports_edit_mode_bridge (plugin_id ,op_id ):
        runnable =True 
    blockers =get_plugin_context_blockers (context ,plugin_id =plugin_id ,operator_id =op_id )
    has_validation =plugin_has_context_validation (plugin_id )
    if not available :
        bucket ="missing"
    elif runnable and not blockers :
        bucket ="ready"
    else :
        bucket ="context"
    text ,icon =_STATUS_TEXT [bucket ]
    return {
    "bucket":bucket ,
    "text":text ,
    "icon":icon ,
    "available":bool (available ),
    "runnable":bool (runnable ),
    "has_validation":bool (has_validation ),
    "blockers":blockers ,
    "blockers_en":summarize_blockers (blockers ,lang ="en",limit =3 ),
    "blockers_ja":summarize_blockers (blockers ,lang ="ja",limit =3 ),
    }



def get_context_validation_coverage_count ()->int :
    return len (PLUGIN_CONTEXT_VALIDATORS )
