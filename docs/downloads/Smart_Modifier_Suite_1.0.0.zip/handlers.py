# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy
import time
from .core import *


def _ms_selection_stack_signature(ctx, selected_mains=None):
    """Selection signature that also includes active object identity/type.

    Object-type switching can keep the same selected-object name set briefly while
    Blender updates active_object/context.object aliases.  Including the ViewLayer
    active object prevents Smart Modifier from reusing a previous mesh decision
    when the user activates a curve/font/surface/Geometry Nodes object.
    """
    try:
        if selected_mains is None:
            selected_mains = ms_get_selected_main_meshes(ctx) or []
    except Exception:
        selected_mains = []
    try:
        active = getattr(getattr(getattr(ctx, "view_layer", None), "objects", None), "active", None)
    except Exception:
        active = None
    try:
        active_main = get_main_object(active) or active
    except Exception:
        active_main = active
    try:
        active_key = (str(getattr(active_main, "name", "") or ""), str(getattr(active_main, "type", "") or ""))
    except Exception:
        active_key = ("", "")
    try:
        selected_key = tuple(sorted((str(getattr(o, "name", "") or ""), str(getattr(o, "type", "") or "")) for o in (selected_mains or []) if getattr(o, "name", "")))
    except Exception:
        selected_key = ()
    return (active_key, selected_key)


def _ms_apply_bg(main_obj, ctx):
    """Background-safe apply: never touches selection/visibility/mode."""
    if not main_obj:
        return
    dn = _ms__dn()
    try:
        dn['_MS_BG_SYNC_V1'] = True
        apply_modifier_stack_state(main_obj, ctx, interactive=False)
    finally:
        try:
            dn.pop('_MS_BG_SYNC_V1', None)
        except Exception:
            pass


def _ms_ep_switch_edit_target_timer():
    'Right after switching OBJECT->EDIT, if EditPoly is active, switch the edit target to the EP helper (single selection only).'
    try:
        ctx = bpy.context
        if getattr(ctx, "mode", "") != 'EDIT_MESH':
            return None

        vl = ctx.view_layer
        ao = vl.objects.active
        if not ao:
            return None

        main_obj = get_main_object(ao)
        if not main_obj or getattr(main_obj, "type", "") != 'MESH':
            return None
        # Preserve user's object selection. Do not force-keep the main object selected,
        # because EditPoly may hide/unselect it while editing the helper.
        _orig_sel_names, _orig_active_name = _ms_snapshot_object_selection(vl)
        preserve_names = []
        try:
            preserve_names = [n for n in (_orig_sel_names or []) if n and n != main_obj.name]
        except Exception:
            preserve_names = []


        # 既存機能を壊さないため、単一メイン選択の時だけ行う
        try:
            mains = ms_get_selected_main_meshes(ctx) or []
        except Exception:
            mains = []
        if len(mains) != 1 or mains[0] != main_obj:
            return None

        ui_active_id = ms_get_ui_active_id(main_obj)
        effective_active_id = ms_get_effective_active_id(main_obj, ui_active_id)
        active_idx = main_obj.modifiers.find(effective_active_id) if effective_active_id != "BASE" else -1
        edit_effective_id = ms_find_nearest_edit_source_id(main_obj, effective_active_id, active_idx)
        if edit_effective_id == "BASE":
            return None

        mod = main_obj.modifiers.get(edit_effective_id)
        p = ms_find_plugin_for_modifier(mod) if mod else None
        if not (p and p.get("id") == "edit_poly"):
            return None

        carrier_key = ms_get_carrier_key_for_effective(main_obj, edit_effective_id)
        show_end = bool(getattr(main_obj, "ms_show_end_result", False))

        # プラグインから編集ターゲットを取得
        res = None
        try:
            fn = p.get("sync_objects")
            if callable(fn):
                res = fn(main_obj, ctx, edit_effective_id, carrier_key, show_end, False)
        except Exception:
            res = None

        target_obj = res.get("target_obj") if isinstance(res, dict) else None
        hide_main = bool(res.get("hide_main")) if isinstance(res, dict) else False

        if not target_obj or target_obj == main_obj:
            return None

        # すでにそのヘルパーを編集中なら何もしない
        try:
            if ctx.edit_object == target_obj:
                return None
        except Exception:
            pass

        ms_capture_selection_to_cache(ctx)

        # 安全に切替（タイマーなので bpy.ops OK）
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        except Exception:
            return None

                # ヘルパーをアクティブ化してEditへ（選択は保持）
        try:
            if preserve_names:
                _ms_ensure_object_selection(vl, preserve_names)
        except Exception:
            pass

        try:
            _ms_set_obj_hidden(target_obj, False, False)
            target_obj.select_set(True)
            vl.objects.active = target_obj
        except Exception:
            return None

        try:
            ms__safe_mode_set(ctx, target_obj, 'EDIT')
        except Exception:
            pass

        # BaseObjectを見せない（EP編集中は非表示）
        if hide_main:
            try:
                _ms_set_obj_hidden(main_obj, True, True)
            except Exception:
                pass

        # 選択復元（キャリアの選択をEPヘルパーへ適用）
        try:
            ms_apply_selection_for_carrier(main_obj, target_obj, carrier_key)
        except Exception:
            pass

    except Exception:
        pass
    finally:
        try:
            bpy.app.driver_namespace.pop("_MS_EP_SWITCH_PENDING_V1", None)
        except Exception:
            pass
    return None

# ------------------------------------------------------------
# Depsgraph-safe deferred sync
# ------------------------------------------------------------

_MS_DEFERRED_TIMER_LOCK = False


def _ms_deferred_selection_sync_timer():
    """Run selection/state sync outside depsgraph callbacks (stability).

    depsgraph_update_post can be called while Blender is rebuilding relations;
    mutating object/modifier state there can cause rare instability.
    This timer performs the same work shortly after, on the main loop.
    """
    global _MS_DEFERRED_TIMER_LOCK
    try:
        dn = _ms__dn()
        if not dn.pop('_MS_DG_PENDING_V1', False):
            dn.pop('_MS_DG_TIMER_ARMED_V1', None)
            return None
        # Prevent re-entrancy
        if _MS_DEFERRED_TIMER_LOCK:
            return 0.05
        _MS_DEFERRED_TIMER_LOCK = True
        try:
            # Call the original logic (moved into _ms_selection_handler_impl)
            _ms_selection_handler_impl()
        finally:
            _MS_DEFERRED_TIMER_LOCK = False
    except Exception:
        try:
            dn = _ms__dn()
            dn.pop('_MS_DG_TIMER_ARMED_V1', None)
        except Exception:
            pass
        return None
    # Keep timer alive if the implementation deliberately queued another pass
    # (for example after a mode-transition grace period).
    try:
        dn = _ms__dn()
        if dn.get('_MS_DG_PENDING_V1'):
            return 0.05
        dn.pop('_MS_DG_TIMER_ARMED_V1', None)
    except Exception:
        pass
    return None




def _ms_quick_context_signature(ctx):
    try:
        mode = str(getattr(ctx, "mode", "") or "")
        view_layer = getattr(ctx, "view_layer", None)
        active_obj = getattr(getattr(view_layer, "objects", None), "active", None)
        active_name = getattr(active_obj, "name", "") if active_obj else ""
        sel_names = tuple(sorted(
            getattr(obj, "name", "")
            for obj in (getattr(ctx, "selected_objects", []) or [])
            if getattr(obj, "name", "")
        ))
        return (mode, active_name, sel_names)
    except Exception:
        return ("", "", ())

@bpy.app.handlers.persistent
def ms_selection_handler(scene, depsgraph):
    """Depsgraph callback: only schedule deferred sync (stability)."""
    try:
        try:
            _rt = _ms_api("_MS_RUNTIME_API_V1")
            _fn = _rt.get("stack_live_enabled")
            if callable(_fn) and not bool(_fn()):
                dn = _ms__dn()
                dn.pop('_MS_DG_PENDING_V1', None)
                dn.pop('_MS_DG_TIMER_ARMED_V1', None)
                return
        except Exception:
            pass
        dn = _ms__dn()
        ctx = bpy.context
        active_obj = getattr(getattr(getattr(ctx, "view_layer", None), "objects", None), "active", None)
        main_obj = get_main_object(active_obj) if active_obj else None
        if main_obj is None:
            main_obj = active_obj
        quick_sig = _ms_quick_context_signature(ctx)
        related = _ms_has_relevant_depsgraph_updates(depsgraph, main_obj=main_obj, active_obj=active_obj)
        if related and main_obj and getattr(main_obj, "type", "") == 'MESH':
            try:
                root = dn.get("_MS_OBJ_DIRTY_REV_V1")
                if not isinstance(root, dict):
                    root = {}
                root[main_obj.name] = int(root.get(main_obj.name, 0) or 0) + 1
                dn["_MS_OBJ_DIRTY_REV_V1"] = root
                names = dn.get("_MS_DG_DIRTY_MAIN_NAMES_V1")
                if not isinstance(names, list):
                    names = []
                if main_obj.name not in names:
                    names.append(main_obj.name)
                dn["_MS_DG_DIRTY_MAIN_NAMES_V1"] = names
            except Exception:
                pass
        if quick_sig == dn.get('_MS_DG_QUICK_SIG_V1') and not related:
            return
        dn['_MS_DG_QUICK_SIG_V1'] = quick_sig
        dn['_MS_DG_PENDING_V1'] = True
        if not dn.get('_MS_DG_TIMER_ARMED_V1'):
            dn['_MS_DG_TIMER_ARMED_V1'] = True
            try:
                # A tiny delay avoids running stack mutations inside the same UI
                # event that is rebuilding or handling sidebar panels.  This is
                # especially important after select-all-deselect and rapid mode
                # toggles where Blender can keep stale panel blocks alive briefly.
                bpy.app.timers.register(_ms_deferred_selection_sync_timer, first_interval=0.05)
            except Exception:
                # Fallback: run soon, but still outside the current handler.
                try:
                    bpy.app.timers.register(_ms_deferred_selection_sync_timer, first_interval=0.10)
                except Exception:
                    pass
    except Exception:
        pass


def _ms_selection_handler_impl():
    global _MS_SYNC_LOCK, _MS_ACTION_LOCK
    if _MS_ACTION_LOCK: return
    if _MS_SYNC_LOCK: return
    try:
        ctx = bpy.context
        vl = ctx.view_layer
        active_obj = vl.objects.active
        dn = _ms__dn()
        # During file load / runtime registration, never let automatic stack sync
        # mutate object state. The transform guard restores real scene object
        # transforms after all load handlers and short timers have settled.
        if dn.get('_SMSM_TRANSFORM_GUARD_ACTIVE_V1'):
            return
        # If a deterministic level-switch transition is running, avoid interfering with selection/mode changes.
        if dn.get('_MS_TRANSITION_ACTIVE_V1'):
            return


        # Debounce depsgraph spam (mode switches / selection changes can trigger many calls)
        try:
            now = time.time()
            last = float(dn.get("_MS_DG_THROTTLE_T", 0.0) or 0.0)
            if (now - last) < 0.02:
                return
            dn["_MS_DG_THROTTLE_T"] = now
        except Exception:
            pass
        # --- Mode/selection based EndPreview cleanup (event-driven) ---
        try:
            now_mode = time.time()
            cur_mode = str(getattr(ctx, "mode", "OBJECT") or "OBJECT")
            last_mode = str(dn.get("_MS_LAST_MODE_V1", "") or "")
            if cur_mode != last_mode:
                dn["_MS_LAST_MODE_V1"] = cur_mode
                dn["_MS_MODE_GRACE_UNTIL_V1"] = now_mode + 0.20
                # Blender 5.1 can keep stale sidebar panel blocks alive during
                # sculpt/edit/workspace transitions.  Suppress heavy unified
                # section bodies for a short window; section headers remain
                # visible but template_list/layout.prop bodies are skipped.
                dn["_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL"] = max(float(dn.get("_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL", 0.0) or 0.0), now_mode + 0.35)
                if (last_mode.startswith("EDIT") and (not cur_mode.startswith("EDIT"))):
                    dn["_MS_MODE_EXIT_NEEDS_PURGE_V1"] = True
                dn['_MS_DG_PENDING_V1'] = True
                if not dn.get('_MS_DG_TIMER_ARMED_V1'):
                    dn['_MS_DG_TIMER_ARMED_V1'] = True
                    try:
                        bpy.app.timers.register(_ms_deferred_selection_sync_timer, first_interval=0.20)
                    except Exception:
                        pass
                return
            grace_until = float(dn.get("_MS_MODE_GRACE_UNTIL_V1", 0.0) or 0.0)
            if grace_until and now_mode < grace_until:
                dn['_MS_DG_PENDING_V1'] = True
                if not dn.get('_MS_DG_TIMER_ARMED_V1'):
                    dn['_MS_DG_TIMER_ARMED_V1'] = True
                    try:
                        bpy.app.timers.register(_ms_deferred_selection_sync_timer, first_interval=max(0.05, grace_until - now_mode))
                    except Exception:
                        pass
                return
            if grace_until:
                dn.pop("_MS_MODE_GRACE_UNTIL_V1", None)
            if dn.pop("_MS_MODE_EXIT_NEEDS_PURGE_V1", False):
                try:
                    dn["_MS_ENDPREVIEW_ALLOWED_MAP_V1"] = {}
                except Exception:
                    pass
                try:
                    ms_request_endpreview_global_purge("mode_exit")
                except Exception:
                    pass
        except Exception:
            pass

        try:
            ms_sanitize_unapproved_object_instance_copies(ctx)
        except Exception:
            pass
        try:
            ms_request_shape_proxy_cleanup("selection_sync", force=False)
        except Exception:
            pass

        # --- Selection-change default active enforcement (robust v66) ---
        # Must run even when Blender temporarily reports a stale/unselected active object
        # during subtract/deselect operations. This must not change object selection.
        try:
            selected_mains = ms_get_selected_main_meshes(ctx) or []
            # In EDIT_* modes, the main mesh can be hidden/unselected while a helper (EditPoly/Lattice) is active.
            # Treat the active chain's main object as selected for internal stability (does NOT change actual selection).
            try:
                _mode = str(getattr(ctx, "mode", "") or "")
                if _mode.startswith("EDIT"):
                    _ao = vl.objects.active
                    _am = get_main_object(_ao) if _ao else None
                    if _am and _am not in selected_mains and ms_object_supports_modifier_stack(_am):
                        selected_mains = list(selected_mains) + [_am]
            except Exception:
                pass
            sel_sig = _ms_selection_stack_signature(ctx, selected_mains)
            last_sig = dn.get("_MS_LAST_SELECTION_SIG")
            if last_sig != sel_sig:
                dn["_MS_LAST_SELECTION_SIG"] = sel_sig

                # EndPreview cleanup: if mains were deselected, delete their EndPreview objects and disallow.
                try:
                    removed = set(last_sig or ()) - set(sel_sig or ())
                    for _n in removed:
                        _o = bpy.data.objects.get(_n)
                        if _o:
                            ms_endpreview_set_allowed(_o, False)
                            ms_request_endpreview_cleanup(_o)
                except Exception:
                    pass

                # If nothing selected, clear caches and bail.
                if not selected_mains:
                    dn.pop("_MS_LAST_SELECTED_MAIN", None)
                    try:
                        ms_request_endpreview_global_purge("selection_empty")
                    except Exception:
                        pass
                    return

                # Determine a reasonable main object for applying state decisions.
                main_obj_for_apply = None
                try:
                    _ao = vl.objects.active
                    if _ao and getattr(_ao, "select_get", lambda: False)():
                        main_obj_for_apply = get_main_object(_ao)
                except Exception:
                    main_obj_for_apply = None
                if not main_obj_for_apply:
                    main_obj_for_apply = selected_mains[0]

                # Apply per selected object so internal state matches UI across multi-select.
                for o in selected_mains:
                    if not o or not ms_object_supports_modifier_stack(o):
                        continue
                    desired = ms_get_top_enabled_ui_id(o)  # bottom-most enabled (or BASE)
                    current = ms_get_ui_active_id(o)
                    changed = (desired != current)
                    if changed:
                        o["ui_active_item"] = desired
                        if desired == "BASE":
                            ms_set_ui_active_index(o, -1)
                        else:
                            ms_set_ui_active_index(o, o.modifiers.find(desired))
                            try:
                                am = o.modifiers.get(desired)
                                if am:
                                    o.modifiers.active = am
                            except Exception:
                                pass

                    # Ensure viewport/stack state matches the new active item.
                    # Apply for the active main object always; for other selected objects only when it changed.
                    if changed or (main_obj_for_apply and o == main_obj_for_apply):
                        _ms_apply_bg(o, ctx)

                dn["_MS_LAST_SELECTED_MAIN"] = getattr(main_obj_for_apply, "name", "")
                return
        except Exception:
            pass

        sel_objs = getattr(ctx, "selected_objects", [])
        if not sel_objs:
            dn.pop("_MS_LAST_SELECTED_MAIN", None)
            dn.pop("_MS_LAST_SELECTION_SIG", None)
            return
        # Blender may temporarily keep a stale active object during subtract/deselect.
        # Do not bail out just because active_obj is unselected; use a selected fallback for computation.
        if (not active_obj) or (active_obj and not getattr(active_obj, "select_get", lambda: False)()):
            try:
                active_obj = sel_objs[0]
            except Exception:
                active_obj = None
            if not active_obj:
                dn.pop("_MS_LAST_SELECTED_MAIN", None)
                return
        main_obj = get_main_object(active_obj)
        if not main_obj:
            dn.pop("_MS_LAST_SELECTED_MAIN", None)
            dn.pop("_MS_LAST_SELECTION_SIG", None)
            return


        # --- SmartLattice UI flicker guard ---
        # SmartLattice may temporarily make the lattice object active during sync.
        # Do NOT let that transient active object flip ui_active_item (modifier list flicker),
        # unless the user is actually editing the lattice (EDIT_LATTICE) or explicitly engaged SmartLattice.
        try:
            engaged = bool(main_obj.get("ms_sl_engaged", False))
            if (not engaged) and active_obj and getattr(active_obj, "type", "") == 'LATTICE':
                if ("sl_main_target" in active_obj) and (getattr(ctx, "mode", "") != 'EDIT_LATTICE'):
                    active_obj = main_obj
        except Exception:
            pass
        if not ms_object_supports_modifier_stack(main_obj):
            dn.pop("_MS_LAST_SELECTED_MAIN", None)
            return
        if not ms_object_has_modifier_collection(main_obj):
            try:
                main_obj["ui_active_item"] = "BASE"
                ms_set_ui_active_index(main_obj, -1)
            except Exception:
                pass
            try:
                ms_endpreview_set_allowed(main_obj, False)
                ms_request_endpreview_global_purge("non_modifier_asset_selection")
            except Exception:
                pass
            dn["_MS_LAST_SELECTED_MAIN"] = getattr(main_obj, 'name', '')
            return

        try:
            if active_obj == main_obj:
                am = getattr(main_obj.modifiers, "active", None)
                if am and ms_is_instance_modifier(am, main_obj): ms_sync_instance_group_from(main_obj, am, context=ctx)
            else:
                ui_id = ms_get_ui_active_id(main_obj)
                if ui_id and ui_id != "BASE":
                    um = main_obj.modifiers.get(ui_id)
                    if um and ms_is_instance_modifier(um, main_obj): ms_sync_instance_group_from(main_obj, um, context=ctx)
        except Exception: pass



        # Mark object dirty when the depsgraph callback recorded relevant updates.
        # The actual depsgraph object is not used here because this function runs on a
        # deferred timer; using a compact object-name queue avoids mutating Blender data
        # directly inside depsgraph_update_post while still refreshing live previews.
        _ms_obj_dirty = False
        try:
            dirty_names = dn.get("_MS_DG_DIRTY_MAIN_NAMES_V1")
            if isinstance(dirty_names, list) and main_obj.name in dirty_names:
                _ms_obj_dirty = True
                dirty_names = [n for n in dirty_names if n != main_obj.name]
                if dirty_names:
                    dn["_MS_DG_DIRTY_MAIN_NAMES_V1"] = dirty_names
                else:
                    dn.pop("_MS_DG_DIRTY_MAIN_NAMES_V1", None)
        except Exception:
            _ms_obj_dirty = False

        if getattr(ctx, "mode", "") == 'EDIT_MESH':
            # NOTE (R12): Do NOT auto-switch edit targets on OBJECT->EDIT.
            # Auto-switching can race with deterministic level switching and cause
            # persistent EDIT/OBJECT toggling. Edit target switching is handled
            # only by explicit Smart Modifier UI actions.

            # Preview collections exist only while the base mesh itself is active
            # and the Modifier Stack panel is open.  This also covers normal Tab
            # switching into/out of Edit Mode.
            try:
                if ms_preview_context_allows_collections(main_obj, ctx):
                    ms_endpreview_set_allowed(main_obj, True)
                    ms_request_endpreview_live_sync()
                else:
                    ms_endpreview_set_allowed(main_obj, False)
                    ms_request_endpreview_global_purge("edit_mesh_context_not_live")
            except Exception:
                pass

            # Capture edit selection to cache, but throttle to avoid full-mesh scans on every depsgraph tick.
            try:
                now = time.time()
                last = float(dn.get("_MS_EDIT_SEL_CAP_T", 0.0) or 0.0)
                if (now - last) >= 0.18:
                    dn["_MS_EDIT_SEL_CAP_T"] = now
                    ms_capture_selection_to_cache(ctx)
            except Exception:
                try:
                    ms_capture_selection_to_cache(ctx)
                except Exception:
                    pass

            # Realtime refresh of the edit-mode EndPreview mesh when modifier properties change.
            # (Without this, the preview may lag behind until selection/mode changes.)
            try:
                if _ms_obj_dirty:
                    now2 = time.time()
                    last2 = float(dn.get("_MS_EDIT_PREVIEW_UPD_T", 0.0) or 0.0)
                    if (now2 - last2) >= 0.05:
                        dn["_MS_EDIT_PREVIEW_UPD_T"] = now2
                        _ms_apply_bg(main_obj, ctx)
                        _ms_tag_redraw_active_view3d(ctx)
            except Exception:
                pass
            return

        if getattr(ctx, "mode", "") == 'EDIT_LATTICE':
            # Smart Lattice edits happen on the lattice helper, not on the mesh object.
            # Refresh the editable level mesh and the final-result preview whenever
            # the lattice datablock changes so the stack remains strictly layered:
            # Base -> active modifier level on the mesh overlay, and full stack on EndPreview.
            try:
                if active_obj and getattr(active_obj, "type", "") == 'LATTICE':
                    desired_ui = None
                    try:
                        for p in ms_get_plugins_sorted():
                            fn = p.get("ui_active_from_object")
                            if callable(fn):
                                mid = fn(main_obj, active_obj)
                                if mid:
                                    desired_ui = mid
                                    break
                    except Exception:
                        desired_ui = None
                    if desired_ui and desired_ui != main_obj.get("ui_active_item", "BASE"):
                        main_obj["ui_active_item"] = desired_ui
                        try:
                            ms_set_ui_active_index(main_obj, main_obj.modifiers.find(desired_ui))
                        except Exception:
                            pass
                    try:
                        # Latest preview lifetime rule: EndPreview/Smart Modifier
                        # collections are not generated while editing lattice helpers.
                        ms_endpreview_set_allowed(main_obj, False)
                        ms_request_endpreview_global_purge("edit_lattice_context")
                    except Exception:
                        pass
                    if _ms_obj_dirty:
                        now2 = time.time()
                        last2 = float(dn.get("_MS_LATTICE_PREVIEW_UPD_T", 0.0) or 0.0)
                        if (now2 - last2) >= 0.04:
                            dn["_MS_LATTICE_PREVIEW_UPD_T"] = now2
                            _ms_apply_bg(main_obj, ctx)
                            _ms_tag_redraw_active_view3d(ctx)
            except Exception:
                pass
            return



        # Realtime refresh when modifier properties are edited via "Show Properties" in OBJECT mode.
        # This updates the EndPreview result immediately without requiring a mode/selection change.
        try:
            if _ms_obj_dirty and bool(getattr(main_obj, "ms_show_properties", False)):
                now2 = time.time()
                last2 = float(dn.get("_MS_PROP_PREVIEW_UPD_T", 0.0) or 0.0)
                if (now2 - last2) >= 0.05:
                    dn["_MS_PROP_PREVIEW_UPD_T"] = now2
                    _ms_apply_bg(main_obj, ctx)
                    _ms_tag_redraw_active_view3d(ctx)
        except Exception:
            pass

        try: ms_call_plugins("on_stack_change", main_obj, ctx, False)
        except Exception: pass

        # --- Selection-change default active enforcement (v1.64 patch) ---
        # When object selection changes (select/add/subtract/deselect), force the active stack item
        # to the bottom-most enabled modifier (or BASE if none). This must not change object selection.
        try:
            selected_mains = ms_get_selected_main_meshes(ctx)
            sel_sig = _ms_selection_stack_signature(ctx, selected_mains)
            last_sig = dn.get("_MS_LAST_SELECTION_SIG")
            if last_sig != sel_sig:
                dn["_MS_LAST_SELECTION_SIG"] = sel_sig
                # Apply per selected object so internal state matches UI across multi-select.
                for o in selected_mains:
                    if not o or not ms_object_supports_modifier_stack(o):
                        continue
                    desired = ms_get_top_enabled_ui_id(o)
                    current = ms_get_ui_active_id(o)
                    changed = (desired != current)
                    if changed:
                        o["ui_active_item"] = desired
                        if desired == "BASE":
                            ms_set_ui_active_index(o, -1)
                        else:
                            ms_set_ui_active_index(o, o.modifiers.find(desired))
                            try:
                                am = o.modifiers.get(desired)
                                if am: o.modifiers.active = am
                            except Exception:
                                pass
                    # Ensure viewport/stack state matches the new active item.
                    # Apply for the active main object always; for other selected objects only when it changed.
                    if changed or o == main_obj:
                        _ms_apply_bg(o, ctx)
                # Keep last selected main in sync so downstream logic doesn't override.
                dn["_MS_LAST_SELECTED_MAIN"] = main_obj.name
                return
        except Exception:
            pass

        current_ui = main_obj.get("ui_active_item", "BASE")
        desired_ui = None
        
        try:
            if active_obj == main_obj:
                last_main = dn.get("_MS_LAST_SELECTED_MAIN")
                if last_main != main_obj.name:
                    dn["_MS_LAST_SELECTED_MAIN"] = main_obj.name
                    desired_ui = ms_get_top_enabled_ui_id(main_obj)
                    main_obj["ui_active_item"] = desired_ui
                    if desired_ui != "BASE":
                        am = main_obj.modifiers.get(desired_ui)
                        if am:
                            try: main_obj.modifiers.active = am
                            except Exception: pass
                    _ms_apply_bg(main_obj, ctx)
                    try:
                        if desired_ui != "BASE":
                            _m = main_obj.modifiers.get(desired_ui)
                            _p = ms_find_plugin_for_modifier(_m) if _m else None
                            if _p and _p.get("id") == "smart_lattice":
                                main_obj["ms_sl_engaged"] = False; main_obj["ms_sl_engaged_mod"] = desired_ui
                            else:
                                main_obj.pop("ms_sl_engaged", None)
                                main_obj.pop("ms_sl_engaged_mod", None)
                        else:
                            main_obj.pop("ms_sl_engaged", None)
                            main_obj.pop("ms_sl_engaged_mod", None)
                    except Exception: pass
                    return
        except Exception: pass

        if active_obj != main_obj:
            try:
                for p in ms_get_plugins_sorted():
                    fn = p.get("ui_active_from_object")
                    if callable(fn):
                        mid = fn(main_obj, active_obj)
                        if mid: desired_ui = mid; break
            except Exception: desired_ui = None

        if active_obj == main_obj:
            try:
                ui_id = ms_get_ui_active_id(main_obj)
                if ui_id == "BASE": desired_ui = None
                else:
                    ui_mod = main_obj.modifiers.get(ui_id)
                    if ui_mod and not get_mod_enabled_state(main_obj, ui_mod.name): desired_ui = None
                    else:
                        am = getattr(main_obj.modifiers, "active", None)
                        if am and main_obj.modifiers.get(am.name): desired_ui = am.name
            except Exception: desired_ui = None

        if desired_ui and desired_ui != current_ui:
            main_obj["ui_active_item"] = desired_ui
            try:
                if (getattr(ctx, "mode", "") == 'EDIT_LATTICE') and active_obj and getattr(active_obj, "type", "") == 'LATTICE':
                    _m = main_obj.modifiers.get(desired_ui)
                    _p = ms_find_plugin_for_modifier(_m) if _m else None
                    if _p and _p.get("id") == "smart_lattice":
                        main_obj["ms_sl_engaged"] = True
                        main_obj["ms_sl_engaged_mod"] = desired_ui
            except Exception:
                pass
            _ms_apply_bg(main_obj, ctx)

        try:
            ui_id2 = ms_get_ui_active_id(main_obj)
            if ui_id2 and ui_id2 != "BASE":
                m2 = main_obj.modifiers.get(ui_id2)
                if m2 and ms_is_instance_modifier(m2, main_obj): ms_sync_instance_group_from(main_obj, m2, context=ctx)
        except Exception: pass
    except Exception: pass