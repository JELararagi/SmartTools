# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Compatibility helpers for older Smart Modifier entry points.

This module intentionally does not create panels, proxy panels, custom headers,
Properties-editor pages, custom headers, theme/color edits, or window-menu
entries. The visible UI is registered by runtime as normal VIEW_3D / UI
Blender panels in the Smart Modifier sidebar category.
"""

from __future__ import annotations

import bpy


_REGISTRY = {
    'nav_entries': {},
    'panel_sources': {},
    'launcher_callbacks': {},
    'launcher_draw_callbacks': {},
    'legacy_operators': {},
    'popup_operators': {},
    'preferred_owner': None,
    'active_owner': None,
    'shutdown': False,
    'runtime_teardown': False,
}

_STARTUP_SAFE_STUB = True
_MISSING = object()


def _registry() -> dict:
    return _REGISTRY


def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip()


def _clean_label(value: object) -> str:
    text = str(value or '').replace('_', ' ').strip()
    while '  ' in text:
        text = text.replace('  ', ' ')
    for suffix in (' Toolset', ' suite', '_Toolset', '_suite'):
        if text.endswith(suffix):
            text = text[:-len(suffix)].strip()
    return text


def _category_for(addon_key: str, label: object = '') -> str:
    key = _normalize_owner(addon_key)
    if key == 'smart_modifier_suite':
        return 'Smart Modifier'
    label_text = _clean_label(label)
    if label_text:
        return label_text
    return _clean_label(key) if key else 'Smart Modifier'


def _iter_valid_panel_classes(panel_classes) -> tuple[type, ...]:
    """Return existing panel classes without registering or cloning them."""
    seen: set[type] = set()
    result: list[type] = []
    base = getattr(bpy.types, 'Panel', None)
    for cls in tuple(panel_classes or ()):  # type: ignore[arg-type]
        if not isinstance(cls, type) or cls in seen:
            continue
        if base is not None:
            try:
                if not issubclass(cls, base):
                    continue
            except Exception:
                continue
        seen.add(cls)
        result.append(cls)
    return tuple(result)


def prepare_panel_classes(panel_classes, addon_key: str | None = None, **_kwargs):
    del addon_key, _kwargs
    return _iter_valid_panel_classes(panel_classes)


def _call_poll(raw_poll, panel_cls, context, default: bool = True) -> bool:
    if raw_poll is None or raw_poll is _MISSING:
        return bool(default)
    for call in (
        lambda: raw_poll(context),
        lambda: raw_poll(panel_cls, context),
        lambda: raw_poll.__func__(panel_cls, context),
    ):
        try:
            return bool(call())
        except TypeError:
            continue
        except Exception:
            return bool(default)
    return bool(default)


def _make_panel_draw_shim(panel_cls, layout):
    del panel_cls
    shim = type('_SMART_MODIFIER_LAYOUT_DRAW_SHIM', (), {})()
    try:
        shim.layout = layout
    except Exception:
        pass
    try:
        shim.is_popover = False
    except Exception:
        pass
    return shim


def _draw_panel_class_fallback_contents(layout, context, panel_cls) -> bool:
    del layout, context, panel_cls
    return False


def _draw_launcher_fallback_contents(layout, context, addon_key: str) -> int:
    del layout, context, addon_key
    return 0


def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _REGISTRY.setdefault('panel_sources', {})[addon_key] = tuple(_iter_valid_panel_classes(panel_classes))
    _REGISTRY.setdefault('nav_entries', {})[addon_key] = {
        'label': _category_for(addon_key, label),
        'icon': str(icon or ''),
        'operator_id': str(operator_id or ''),
        'button_operator_id': '',
        'order': int(order or 0),
        'category': _category_for(addon_key, label),
    }
    if not _REGISTRY.get('preferred_owner'):
        _REGISTRY['preferred_owner'] = addon_key
    _REGISTRY['active_owner'] = addon_key
    _REGISTRY['shutdown'] = False
    _REGISTRY['runtime_teardown'] = False
    _tag_redraw_all_npanel_areas()
    return True


def refresh_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, reopen_window: bool = False, **kwargs) -> bool:
    del reopen_window
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def uninstall(addon_key: str, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    for key in ('nav_entries', 'panel_sources', 'launcher_callbacks', 'launcher_draw_callbacks'):
        mapping = _REGISTRY.get(key)
        if isinstance(mapping, dict):
            mapping.pop(addon_key, None)
    if _REGISTRY.get('preferred_owner') == addon_key:
        remaining = tuple(_REGISTRY.get('nav_entries', {}).keys())
        _REGISTRY['preferred_owner'] = remaining[0] if remaining else None
    if _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = _REGISTRY.get('preferred_owner')
    _tag_redraw_all_npanel_areas()
    return True


def set_launcher_draw_callback(addon_key: str, callback) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    if callable(callback):
        _REGISTRY.setdefault('launcher_callbacks', {})[addon_key] = callback
        _REGISTRY.setdefault('launcher_draw_callbacks', {})[addon_key] = callback
    else:
        _REGISTRY.setdefault('launcher_callbacks', {}).pop(addon_key, None)
        _REGISTRY.setdefault('launcher_draw_callbacks', {}).pop(addon_key, None)
    _tag_redraw_all_npanel_areas()
    return True


def clear_launcher_draw_callback(addon_key: str) -> bool:
    return set_launcher_draw_callback(addon_key, None)


def is_active(context=None, addon_key: str = '') -> bool:
    del context
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return True
    active = _REGISTRY.get('active_owner') or _REGISTRY.get('preferred_owner')
    return active in (None, addon_key)


def set_active_owner(context=None, addon_key: str = '') -> bool:
    del context
    addon_key = _normalize_owner(addon_key)
    if addon_key:
        _REGISTRY['active_owner'] = addon_key
        if not _REGISTRY.get('preferred_owner'):
            _REGISTRY['preferred_owner'] = addon_key
    _tag_redraw_all_npanel_areas()
    return True


def clear_active_owner(addon_key: str = '') -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key or _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = _REGISTRY.get('preferred_owner')
    _tag_redraw_all_npanel_areas()
    return True


def is_smart_tools_context(context=None) -> bool:
    return _is_smart_tools_context(context)


def _is_smart_tools_context(context=None) -> bool:
    context = context or getattr(bpy, 'context', None)
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        return str(getattr(area, 'type', '') or '') == 'VIEW_3D' and str(getattr(region, 'type', '') or 'UI') == 'UI'
    except Exception:
        return False


def runtime_has_existing_host_candidates(addon_key: str = '') -> bool:
    del addon_key
    return False


def runtime_needs_refresh(addon_key: str = '') -> bool:
    del addon_key
    return False


def refresh_ui_runtime(context=None, addon_key: str = '', activate_if_properties: bool = True) -> bool:
    del context, activate_if_properties
    if addon_key:
        set_active_owner(addon_key=addon_key)
    _tag_redraw_all_npanel_areas()
    return True


def sync_live_runtime_from_prefs(context=None) -> bool:
    del context
    _tag_redraw_all_npanel_areas()
    return True


def force_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    if preferred_owner:
        owner = _normalize_owner(preferred_owner)
        _REGISTRY['preferred_owner'] = owner
        _REGISTRY['active_owner'] = owner
    _tag_redraw_all_npanel_areas()
    return True


def _smart_tools_light_activate_runtime(context=None) -> bool:
    del context
    return True


def _open_or_reuse_smart_tools_window(context=None, preferred_owner: str | None = None, reuse_existing: bool = True) -> bool:
    return open_smart_tools_window(context=context, preferred_owner=preferred_owner, reuse_existing=reuse_existing)


def open_or_reuse_smart_tools_window(context=None, preferred_owner: str | None = None, reuse_existing: bool = True) -> bool:
    return open_smart_tools_window(context=context, preferred_owner=preferred_owner, reuse_existing=reuse_existing)


def open_smart_tools_window(context=None, preferred_owner: str | None = None, reuse_existing: bool = True) -> bool:
    del reuse_existing
    if preferred_owner:
        set_active_owner(context=context, addon_key=preferred_owner)
    _tag_redraw_all_npanel_areas()
    return True


def invoke_props_dialog_preferred_window(operator, context, width: int = 420):
    try:
        return context.window_manager.invoke_props_dialog(operator, width=width)
    except Exception:
        try:
            return context.window_manager.invoke_props_dialog(operator)
        except Exception:
            return {'CANCELLED'}


def invoke_props_dialog_outside_smart_tools(operator, context, width: int = 420):
    return invoke_props_dialog_preferred_window(operator, context, width=width)


def invoke_popup_outside_smart_tools(operator, context, width: int = 420):
    try:
        return context.window_manager.invoke_popup(operator, width=width)
    except Exception:
        try:
            return context.window_manager.invoke_popup(operator)
        except Exception:
            return {'CANCELLED'}


def _ensure_host_window_popup_capacity(*_args, **_kwargs) -> bool:
    return True


def _verified_host_window_keys() -> tuple:
    return ()


def schedule_shared_window_menu_button_refresh(*_args, **_kwargs) -> None:
    return None


def _ensure_host_watch_timer(*_args, **_kwargs) -> bool:
    return True


def ensure_shared_nav_button_operators(*_args, **_kwargs) -> None:
    return None


def is_startup_safe_stub() -> bool:
    return True


def describe_startup_behavior() -> str:
    return 'Smart Modifier uses standard 3D View Sidebar N-panel classes only.'


def toggle_active(context=None, addon_key: str = '') -> bool:
    if addon_key:
        set_active_owner(context=context, addon_key=addon_key)
    return True


def popup_menu_operator_id() -> str:
    return ''


def popup_operator_enum_operator_id() -> str:
    return ''


def popup_menu_pie_proxy_operator_id() -> str:
    return ''


def _tag_redraw_all_npanel_areas() -> None:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):  # type: ignore[arg-type]
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):  # type: ignore[arg-type]
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _tag_redraw_all_properties_areas() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_host_windows() -> None:
    _tag_redraw_all_npanel_areas()


def _set_runtime_teardown(value: bool) -> None:
    _REGISTRY['runtime_teardown'] = bool(value)
    if value:
        _REGISTRY['shutdown'] = True


install_window_menu_entry = lambda *args, **kwargs: ()
remove_window_menu_entry = lambda *args, **kwargs: None
remove_window_menu_entry_if_unused = lambda *args, **kwargs: None
schedule_window_menu_refresh = lambda *args, **kwargs: None


__all__ = (
    '_call_poll',
    '_draw_launcher_fallback_contents',
    '_draw_panel_class_fallback_contents',
    '_ensure_host_watch_timer',
    '_ensure_host_window_popup_capacity',
    '_is_smart_tools_context',
    '_make_panel_draw_shim',
    '_open_or_reuse_smart_tools_window',
    '_registry',
    '_set_runtime_teardown',
    '_smart_tools_light_activate_runtime',
    '_tag_redraw_all_properties_areas',
    '_tag_redraw_host_windows',
    '_verified_host_window_keys',
    'clear_active_owner',
    'clear_launcher_draw_callback',
    'describe_startup_behavior',
    'ensure_shared_nav_button_operators',
    'force_runtime_refresh',
    'install',
    'install_window_menu_entry',
    'invoke_popup_outside_smart_tools',
    'invoke_props_dialog_outside_smart_tools',
    'invoke_props_dialog_preferred_window',
    'is_active',
    'is_smart_tools_context',
    'is_startup_safe_stub',
    'open_or_reuse_smart_tools_window',
    'open_smart_tools_window',
    'popup_menu_operator_id',
    'popup_menu_pie_proxy_operator_id',
    'popup_operator_enum_operator_id',
    'prepare_panel_classes',
    'refresh_entry',
    'refresh_runtime',
    'refresh_ui_runtime',
    'remove_window_menu_entry',
    'remove_window_menu_entry_if_unused',
    'runtime_has_existing_host_candidates',
    'runtime_needs_refresh',
    'schedule_shared_window_menu_button_refresh',
    'schedule_window_menu_refresh',
    'set_active_owner',
    'set_launcher_draw_callback',
    'sync_live_runtime_from_prefs',
    'toggle_active',
    'uninstall',
)
