# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bisect 
import math 
import random 

import bpy 
import bmesh 
from bpy .props import BoolProperty ,EnumProperty ,FloatProperty ,IntProperty ,PointerProperty ,StringProperty 
from bpy .types import Operator ,Panel ,PropertyGroup 
from mathutils import Euler ,Matrix ,Quaternion ,Vector ,geometry 
from mathutils.bvhtree import BVHTree 

from .utils import (
call_operator_safe ,
operator_available ,
operator_runnable ,
safe_activate_only ,
safe_mode_set ,
safe_select_all ,
)
from .context import capture_object_context ,ensure_object_mode ,restore_object_context 
from .translation import pgettext as _sms_pgettext
from .help_button import draw_help_button, draw_help_header

PANEL_CATEGORY ="Smart Modifier"


def _persist_panel_state(_self=None, context=None) -> None:
    try:
        if context is None:
            context = getattr(bpy, 'context', None)
        from . import persistent_state
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass


def _persistent_property_factory(factory):
    def _wrapped(*args, **kwargs):
        kwargs.setdefault('update', _persist_panel_state)
        return factory(*args, **kwargs)
    return _wrapped


_BpyBoolProperty = BoolProperty
_BpyEnumProperty = EnumProperty
_BpyFloatProperty = FloatProperty
_BpyIntProperty = IntProperty
_BpyPointerProperty = PointerProperty
_BpyStringProperty = StringProperty
BoolProperty = _persistent_property_factory(_BpyBoolProperty)
EnumProperty = _persistent_property_factory(_BpyEnumProperty)
FloatProperty = _persistent_property_factory(_BpyFloatProperty)
IntProperty = _persistent_property_factory(_BpyIntProperty)
PointerProperty = _persistent_property_factory(_BpyPointerProperty)
StringProperty = _persistent_property_factory(_BpyStringProperty)

translation_catalog_dict ={
"ja_JP":{
("*","Precision / Layout / Path"):"精密 / レイアウト / パス",
("*","Precision / Layout Guide"):"精密 / レイアウト ガイド",
("*","Workplane / Projection"):"ワークプレーン / 投影",
("*","Path / Replace / Randomize"):"パス / 置換 / ランダム化",
("*","Workplane From Active"):"アクティブからワークプレーン作成",
("*","Project To Active Plane"):"アクティブ面へ投影",
("*","Instances Along Path"):"パスに沿ってインスタンス配置",
("*","Replace With Active"):"アクティブで置換",
("*","Randomize Selected"):"選択をランダム化",
("*","Align To Active"):"アクティブへ整列",
("*","Distribute Selected"):"選択を均等配置",
("*","Stack Selected"):"選択をスタック配置",
("*","Build a cursor-based local workplane from the active face or selected edge. Useful for Modo-style Workplane / Action Center style editing on angled surfaces."):"アクティブ面または選択辺から、カーソル基準のローカルワークプレーンを作成します。Modo の Workplane / Action Center のように、傾いた面での精密編集に便利です。",
("*","Project selected vertices onto the active face plane with an optional offset. Useful for projection modeling, CAD-like flattening, and keeping panel details flush to a surface."):"選択頂点をアクティブ面の平面へ、必要に応じたオフセット付きで投影します。Projection Modeling や CAD ライクな平坦化、面へ揃えたパネルディテール作成に便利です。",
("*","Scatter linked copies of the selected source objects along the active curve using even distance sampling. Useful for Duplicate Along Path, MASH-style path layouts, trims, railing, and RailClone-like path-driven blocking."):"アクティブカーブに沿って、選択ソースのリンクコピーを等間隔サンプリングで配置します。Duplicate Along Path、MASH 的なパス配置、トリム、手すり、RailClone ライクなパス駆動ブロックアウトに便利です。",
("*","Replace the selected target objects with copies of the active object while preserving each target transform. Useful for instance replacement, kitbash swaps, and proxy-to-final workflows."):"選択ターゲットを、アクティブオブジェクトのコピーで置換し、各ターゲットの変換を維持します。インスタンス置換、キットバッシュ差し替え、プロキシから本番資産への置換に便利です。",
("*","Apply controlled random location / rotation / uniform scale variation to the selected objects for faster environment dressing and layout iteration."):"選択オブジェクトへ、位置・回転・一様スケールの制御されたランダム差分を適用します。環境レイアウトやドレッシングの試行を高速化できます。",
("*","Align the selected objects to the active object using per-channel toggles for location, rotation, and scale. Useful for 3ds Max style align workflows, layout cleanup, and archviz placement passes."):"位置・回転・スケールの各チャンネル切替を使って、選択オブジェクトをアクティブオブジェクトへ整列します。3ds Max 風の Align ワークフロー、レイアウト整理、Archviz の配置調整に便利です。",
("*","Evenly distribute selected object origins between the current minimum and maximum positions on the chosen world axis. Useful for shelf dressing, facade spacing, modular blocking, and quick layout cleanup."):"選択したワールド軸上の現在の最小位置と最大位置の間で、選択オブジェクト原点を均等配置します。棚配置、ファサード間隔調整、モジュラーなブロックアウト、素早いレイアウト整理に便利です。",
("*","Stack selected objects one after another along the chosen world axis using their world-space bounds plus a configurable gap. Useful for shelf dressing, prop lineup, packing previews, and quick contact-free layout stacking."):"選択オブジェクトを、指定ワールド軸上でワールド空間の境界ボックスと設定ギャップを使って順番に接触配置します。棚配置、小物の整列、梱包プレビュー、素早い非接触スタック配置に便利です。",
("*","Use Cursor Pivot"):"カーソルピボットを使う",
("*","After building the workplane, switch the transform pivot to the 3D cursor for immediate local editing."):"ワークプレーン作成後、変換ピボットを3Dカーソルへ切り替え、すぐローカル編集できるようにします。",
("*","Use Cursor Orientation"):"カーソル向きを使う",
("*","After building the workplane, switch the active transform orientation to Cursor when supported."):"ワークプレーン作成後、可能であればアクティブ変換方向を Cursor に切り替えます。",
("*","Project Offset"):"投影オフセット",
("*","Keep projected vertices slightly above or below the active plane."):"投影頂点をアクティブ平面から少し浮かせる / めり込ませる距離です。",
("*","Path Count"):"パス配置数",
("*","Number of instances to place along the active curve."):"アクティブカーブに沿って配置するインスタンス数です。",
("*","Include Ends"):"両端を含める",
("*","Sample the first and last points of the path as placement positions."):"配置位置としてパスの始点と終点を含めます。",
("*","Follow Tangent"):"接線方向に揃える",
("*","Rotate instances so their local X axis follows the sampled path tangent."):"インスタンスのローカル X 軸が、サンプリングしたパス接線方向に沿うよう回転させます。",
("*","Random Roll (deg)"):"ランダムロール（度）",
("*","Maximum extra rotation around the path tangent."):"パス接線方向まわりに加える追加ランダム回転の最大角度です。",
("*","Linked Data"):"データをリンク",
("*","Use linked object data instead of full data copies."):"完全コピーではなく、オブジェクトデータをリンクして複製します。",
("*","Organize Path Instances"):"パス配置を整理",
("*","Link generated path instances into a dedicated collection with a root empty."):"生成したパス配置インスタンスを、専用コレクションとルート Empty に整理します。",
("*","Random Seed"):"ランダムシード",
("*","Seed used for deterministic randomization."):"再現可能なランダム化に使うシードです。",
("*","Random XY Offset"):"ランダムXYオフセット",
("*","Maximum extra random offset in X/Y for each selected object."):"各選択オブジェクトに対して加える、X/Y 方向の最大ランダムオフセットです。",
("*","Random Z Offset"):"ランダムZオフセット",
("*","Maximum extra random offset in Z for each selected object."):"各選択オブジェクトに対して加える、Z 方向の最大ランダムオフセットです。",
("*","Random Z Rotation (deg)"):"ランダムZ回転（度）",
("*","Maximum extra random Z rotation in degrees."):"追加で与える Z 軸ランダム回転の最大角度です。",
("*","Uniform Scale Min"):"一様スケール最小",
("*","Minimum uniform scale multiplier."):"一様スケール倍率の最小値です。",
("*","Uniform Scale Max"):"一様スケール最大",
("*","Maximum uniform scale multiplier."):"一様スケール倍率の最大値です。",
("*","Delete Targets"):"元ターゲットを削除",
("*","Remove target objects after the replacement copies are created."):"置換コピー作成後に元ターゲットを削除します。",
("*","Preserve Collections"):"コレクションを維持",
("*","Link replacement objects into the same collections as the replaced targets."):"置換オブジェクトを、置換元ターゲットと同じコレクションへリンクします。",
("*","Align Location"):"位置を整列",
("*","Match the selected objects' world-space location to the active object on the enabled axes."):"有効な軸について、選択オブジェクトのワールド空間位置をアクティブオブジェクトへ揃えます。",
("*","Align Rotation"):"回転を整列",
("*","Match the selected objects' world-space rotation to the active object."):"選択オブジェクトのワールド空間回転をアクティブオブジェクトへ揃えます。",
("*","Align Scale"):"スケールを整列",
("*","Match the selected objects' world-space scale to the active object on the enabled axes."):"有効な軸について、選択オブジェクトのワールド空間スケールをアクティブオブジェクトへ揃えます。",
("*","Affect X"):"X を反映",
("*","Enable X-axis alignment or distribution."):"X 軸方向の整列または均等配置を有効にします。",
("*","Affect Y"):"Y を反映",
("*","Enable Y-axis alignment or distribution."):"Y 軸方向の整列または均等配置を有効にします。",
("*","Affect Z"):"Z を反映",
("*","Enable Z-axis alignment or distribution."):"Z 軸方向の整列または均等配置を有効にします。",
("*","Distribute Axis"):"均等配置軸",
("*","Stack Axis"):"スタック軸",
("*","World axis used by Distribute Selected."):"Distribute Selected で使用するワールド軸です。",
("*","World axis used by Stack Selected."):"Stack Selected で使用するワールド軸です。",
("*","Stack Gap"):"スタック間隔",
("*","Extra gap inserted between stacked object bounds."):"スタック配置時にオブジェクト境界の間へ追加する余白です。",
("*","Need an active mesh in Edit Mode"):"編集モードのアクティブメッシュが必要です",
("*","Need an active face or a selected edge"):"アクティブ面または選択辺が必要です",
("*","Workplane ready"):"ワークプレーンを作成しました",
("*","Projected selected vertices to the active plane"):"選択頂点をアクティブ平面へ投影しました",
("*","Active curve and at least one source object are required"):"アクティブカーブと少なくとも1つのソースオブジェクトが必要です",
("*","Failed to evaluate a usable path from the active curve"):"アクティブカーブから使用可能なパスを取得できませんでした",
("*","Created instances along the active path"):"アクティブパスに沿ってインスタンスを作成しました",
("*","Select at least one target besides the active source object"):"アクティブソース以外に少なくとも1つのターゲットを選択してください",
("*","Replacement complete"):"置換が完了しました",
("*","Select at least one object to randomize"):"ランダム化するオブジェクトを少なくとも1つ選択してください",
("*","Randomize complete"):"ランダム化が完了しました",
("*","Need an active source object plus at least one other selected object"):"アクティブな基準オブジェクトと、他に少なくとも1つの選択オブジェクトが必要です",
("*","Enable at least one of location, rotation, or scale alignment"):"位置・回転・スケール整列のいずれかを少なくとも1つ有効にしてください",
("*","Enabled at least one axis is required"):"有効な軸を少なくとも1つ指定してください",
("*","Aligned selected objects to the active object"):"選択オブジェクトをアクティブオブジェクトへ整列しました",
("*","Select at least three objects to distribute"):"均等配置するには少なくとも3つのオブジェクトを選択してください",
("*","Distributed selected objects evenly on the chosen axis"):"選択オブジェクトを指定軸上で均等配置しました",
("*","Select at least two objects to stack"):"スタック配置するには少なくとも2つのオブジェクトを選択してください",
("*","Stacked selected objects along the chosen axis"):"選択オブジェクトを指定軸上でスタック配置しました",
("*","Suggested precision workflows"):"おすすめ精密ワークフロー",
("*","• Angled surface editing: Workplane From Active → standard move/scale/extrude with Cursor orientation."):"• 傾斜面編集: アクティブからワークプレーン作成 → Cursor 向きで通常の移動/拡大縮小/押し出し。",
("*","• Panel cleanup: Project To Active Plane to keep selected loops flush to a reference surface."):"• パネル整理: アクティブ面へ投影で、選択ループを基準面へぴったり揃える。",
("*","• Path layouts: Instances Along Path for railing, trims, repeated props, and blockout arrays."):"• パス配置: パスに沿ってインスタンス配置で、手すり、トリム、反復小物、ブロックアウト配列を作成。",
("*","• Kitbash swaps: Replace With Active to swap many placeholders at once without losing transforms."):"• キットバッシュ差し替え: アクティブで置換で、多数のプレースホルダーを変換を維持したまま一括差し替え。",
("*","• Scene dressing: Randomize Selected for fast natural variation after scatter or manual placement."):"• シーンドレッシング: 散布後や手配置後に選択をランダム化で自然なバリエーションを追加。",
("*","• Layout cleanup: Align To Active and Distribute Selected cover quick archviz-style lineup and spacing fixes without leaving Object Mode."):"• レイアウト整理: アクティブへ整列 と 選択を均等配置 で、オブジェクトモードのまま Archviz 風の整列と間隔調整を素早く行えます。",
("*","• Contact stacking: Stack Selected packs props, books, panels, and modular pieces one after another using real bounds plus a custom gap."):"• 接触スタック配置: 選択をスタック配置 で、実際の境界ボックスと任意ギャップを使って小物、本、パネル、モジュラー部品を順番に並べます。",
("*","Pivot / Origin Helpers"):"ピボット / 原点ヘルパー",
("*","Pivot To Selection"):"選択へピボット移動",
("*","Move the active mesh object's origin to the center of the current edit selection without changing the visible shape. Useful for local bend / twist control, kitbash pivots, and temporary action-center style edits."):"アクティブメッシュオブジェクトの原点を、見た目の形状を変えずに現在の編集選択の中心へ移動します。ローカルな Bend / Twist 制御、キットバッシュのピボット調整、一時的な Action Center 的編集に便利です。",
("*","Pivot To Bottom"):"下端へピボット移動",
("*","Move each selected object's origin to the world-space bottom center of its bounds without changing the visible shape. Useful for layout, DropIt-style dressing, stacking, and easier floor placement."):"各選択オブジェクトの原点を、見た目の形状を変えずにワールド空間での境界ボックス下端中央へ移動します。レイアウト、DropIt 風の配置、積み重ね、床置き作業をしやすくする用途に便利です。",
("*","Need selected mesh components on the active object"):"アクティブオブジェクト上で選択メッシュ要素が必要です",
("*","Pivot moved to the current selection center"):"ピボットを現在の選択中心へ移動しました",
("*","Select one or more objects"):"1つ以上のオブジェクトを選択してください",
("*","Pivot moved to object bottom bounds"):"ピボットをオブジェクト下端へ移動しました",
("*","• Pivot edits: Pivot To Selection or Pivot To Bottom help prepare bend / twist / drop workflows without destructive repositioning."):"• ピボット調整: 選択へピボット移動 / 下端へピボット移動で、Bend / Twist / ドロップ系の前準備を破壊的再配置なしで行えます。",
("*","Drop To Floor"):"床へドロップ",
("*","Drop selected objects vertically so their world-space bounds sit on a shared floor height. Useful for DropToFloor style layout cleanup, shelf dressing, and zero-target placement prep."):"選択オブジェクトを垂直移動し、ワールド空間の境界ボックス下端が共通の床高さへ接するようにします。DropToFloor 風のレイアウト整理、棚配置、ターゲット不要の設置準備に便利です。",
("*","Use 3D Cursor Z"):"3DカーソルZを使う",
("*","Use the 3D cursor Z value as the target floor height instead of the manual Floor Z field."):"手動の Floor Z の代わりに、3Dカーソルの Z 値を床高さとして使います。",
("*","Floor Z"):"床Z",
("*","World-space floor height used by Drop To Floor when 3D Cursor Z is disabled."):"Drop To Floor で 3D カーソル Z を使わない場合に使用するワールド空間の床高さです。",
("*","Dropped selected objects to floor height"):"選択オブジェクトを床高さへ配置しました",
("*","Quad Checker"):"クアッドチェッカー",
("*","Select quads, non-quads, triangles, or ngons on the active edit mesh for fast topology inspection before subdivision, export, bevel, or retopo cleanup."):"アクティブな編集メッシュ上で、クアッド、非クアッド、三角形、Nゴンを素早く選択し、サブディビジョン、書き出し、ベベル、リトポ整理前のトポロジー確認を行います。",
("*","Quad Filter"):"クアッドフィルター",
("*","Choose which face type to select on the active edit mesh."):"アクティブ編集メッシュ上で選択するフェース種別を選びます。",
("*","Selected Faces Only"):"選択面のみ",
("*","When enabled, Quad Checker only inspects the currently selected faces. Disable it to inspect the whole active edit mesh."):"有効時は現在選択中の面のみを対象に確認します。無効時はアクティブ編集メッシュ全体を確認します。",
("*","Need an active mesh in Edit Mode"):"編集モードのアクティブメッシュが必要です",
("*","Quad Checker selected matching faces"):"Quad Checker で一致する面を選択しました",
}
}

translation_catalog_dict ["ja_JP"].update ({
("*","Surface / Retopo / Utility"):"サーフェス / リトポ / 補助",
("*","Project To Selected Surface"):"選択面へサーフェス投影",
("*","Project selected vertices of the active mesh onto the nearest points of another selected mesh. Useful for retopo, shrinkwrap-style cleanup, panel wrapping, and keeping blockout strips glued to a target surface."):"アクティブメッシュの選択頂点を、別の選択メッシュ上の最近接点へ投影します。リトポ、Shrinkwrap 風の調整、パネル貼り付け、ブロックアウト帯の面追従に便利です。",
("*","Surface Project Offset"):"サーフェス投影オフセット",
("*","Keep projected vertices slightly above or below the target surface."):"投影頂点を対象面から少し浮かせる / めり込ませる距離です。",
("*","Rebuild Active Curve"):"アクティブカーブを再構築",
("*","Resample the active curve into a cleaner evenly spaced poly spline. Useful for MoI/ CAD-style curve rebuild workflows before pipes, sweeps, and path arrays."):"アクティブカーブを、間隔の揃ったよりクリーンなポリスプラインへ再サンプリングします。パイプ、スイープ、パス配列の前処理として、MoI / CAD 系のカーブ再構築ワークフローに便利です。",
("*","Rebuild Count"):"再構築点数",
("*","Number of sampled points used to rebuild the active curve."):"アクティブカーブを再構築するために使用するサンプル点数です。",
("*","Keep Original"):"元カーブを保持",
("*","Create a rebuilt duplicate instead of overwriting the active curve object data."):"アクティブカーブのデータを上書きせず、再構築した複製を作成します。",
("*","Quick Symmetry"):"クイック対称化",
("*","In Edit Mode, run destructive symmetrize with the chosen direction. In Object Mode, create or update a Mirror modifier for a non-destructive symmetry setup."):"編集モードでは選択方向で破壊的 Symmetrize を実行し、オブジェクトモードでは非破壊の Mirror モディファイアを作成 / 更新します。",
("*","Symmetry Direction"):"対称方向",
("*","Axis and source side used by the symmetry operator."):"対称処理で使う軸とコピー元側を指定します。",
("*","Symmetry Merge Threshold"):"対称結合しきい値",
("*","Merge threshold used by symmetry operations."):"対称処理で使用する結合しきい値です。",
("*","Object Mode = Mirror Modifier"):"オブジェクトモードでは Mirror 使用",
("*","In Object Mode, create or reuse a Mirror modifier instead of doing a destructive edit operation."):"オブジェクトモードでは、破壊的編集の代わりに Mirror モディファイアを作成 / 再利用します。",
("*","Mirror Clip"):"Mirror のクリップ",
("*","Enable clipping on the created Mirror modifier to keep the center seam closed."):"作成した Mirror モディファイアでクリップを有効にし、中央シームを閉じやすくします。",
("*","Solo Selected"):"選択をソロ表示",
("*","Hide all unselected objects for focused modeling, then restore the previous visibility when run again. Useful for MagicSolo-style focus workflows."):"未選択オブジェクトをすべて隠して集中作業用の表示にし、再実行で元の可視状態へ戻します。MagicSolo 系の集中ワークフロー向けです。",
("*","Need another selected target mesh besides the active source mesh"):"アクティブな元メッシュ以外に、選択された対象メッシュが必要です",
("*","Select at least one vertex to project"):"投影する頂点を少なくとも1つ選択してください",
("*","Projected selected vertices to the selected target surface"):"選択頂点を選択対象サーフェスへ投影しました",
("*","Active curve required"):"アクティブカーブが必要です",
("*","Need a usable active curve with at least two points"):"少なくとも2点以上を持つ使用可能なアクティブカーブが必要です",
("*","Rebuilt the active curve"):"アクティブカーブを再構築しました",
("*","Need an active mesh object"):"アクティブなメッシュオブジェクトが必要です",
("*","Symmetry complete"):"対称化が完了しました",
("*","Solo mode enabled"):"ソロ表示を有効化しました",
("*","Solo mode restored"):"ソロ表示を解除して復元しました",
("*","• Retopo / wrap: Project To Selected Surface keeps selected verts glued to a target mesh."):"• リトポ / ラップ: 選択面へサーフェス投影で、選択頂点を対象メッシュへ貼り付け維持。",
("*","• Curve cleanup: Rebuild Active Curve resamples uneven paths before pipes, sweeps, and arrays."):"• カーブ整理: アクティブカーブを再構築で、不均一なパスをパイプ / スイープ / 配列前に再サンプリング。",
("*","• Symmetry: Quick Symmetry runs destructive cleanup in Edit Mode or a non-destructive Mirror setup in Object Mode."):"• 対称化: クイック対称化で、編集モードでは破壊的整理、オブジェクトモードでは非破壊 Mirror を実行。",
("*","• Focus mode: Solo Selected isolates the current working set and restores visibility on the next run."):"• 集中表示: 選択をソロ表示で、現在の作業対象だけを残し、次回実行で可視状態を復元。",
})



translation_catalog_dict ["ja_JP"].update ({
("*","CAD / Tessellate / Audit"):"CAD / テッセレーション / 監査",
("*","Face Component Array"):"面コンポーネント配列",
("*","Duplicate the active mesh object onto the faces of the other selected mesh objects. Useful as a compact Tissue-style face component workflow for paneling, tiles, vents, and kitbash repetition."):"アクティブメッシュを、他の選択メッシュの各面へ複製配置します。Tissue 系の面コンポーネント配置を、パネル、タイル、ベント、キットバッシュ反復向けにコンパクト化したワークフローです。",
("*","Selected Faces Only"):"選択面のみ",
("*","If the target mesh stores selected polygons, use only those faces. Otherwise all faces are used."):"対象メッシュに選択ポリゴン情報があればその面だけを使い、無ければ全ての面を使用します。",
("*","Scale To Face"):"面サイズへ合わせる",
("*","Uniformly scale each placed component by the square-root of the target face area."):"各配置コンポーネントを、対象面の面積の平方根を基準に一様スケールします。",
("*","Component Scale"):"コンポーネント倍率",
("*","Additional uniform multiplier applied after face-based scaling."):"面基準のスケーリング後に適用する追加の一様倍率です。",
("*","Face Offset"):"面オフセット",
("*","Offset the placed component along the target face normal."):"配置したコンポーネントを対象面法線方向へオフセットします。",
("*","Use linked mesh data for each placed component instead of making full data copies."):"各配置コンポーネントで完全コピーではなく、メッシュデータをリンクして使います。",
("*","CAD Intersect / Extend"):"CAD 交点 / 延長",
("*","Resolve exactly two selected edges in Edit Mode. Intersect inserts a shared intersection point when the line crossing lies on both segments. Extend moves the nearest endpoints so the edges meet at the resolved point. Useful as a tinyCAD-style precision helper."):"編集モードで選択した 2 本の辺を解決します。Intersect は交点が両セグメント上にある場合に共有交点を挿入し、Extend は最近接端点を移動して辺同士を交わらせます。tinyCAD 系の精密補助として便利です。",
("*","CAD Mode"):"CAD モード",
("*","Choose whether to insert an intersection point or extend the selected endpoints to the resolved meeting point."):"交点を挿入するか、選択端点を解決された交点まで延長するかを選びます。",
("*","Insert Intersection"):"交点を挿入",
("*","Extend Endpoints"):"端点を延長",
("*","Audit Selected"):"選択を監査",
("*","Analyze the active or selected mesh objects and summarize common production risks such as non-manifold edges, loose elements, ngons, degenerate geometry, and possible doubles. Inspired by 3D Print Toolbox style validation."):"アクティブまたは選択メッシュを解析し、非多様体辺、ルーズ要素、N ゴン、退化ジオメトリ、重複候補などの典型的な制作上のリスクを要約します。3D Print Toolbox 系の検証を意識した監査です。",
("*","Audit + Repair"):"監査 + 修復",
("*","Run a conservative cleanup pass on the active or selected mesh objects, then refresh the audit summary. The repair focuses on merge-by-distance, degenerate cleanup, loose removal, and normal recalculation instead of risky topology rewrites."):"アクティブまたは選択メッシュへ保守的なクリーンアップを実行し、その後に監査要約を更新します。危険なトポロジー改変ではなく、距離結合、退化解消、ルーズ削除、法線再計算を中心にした修復です。",
("*","Audit Merge Distance"):"監査結合距離",
("*","Distance used for potential double detection and for the conservative merge-by-distance repair step."):"重複候補検出と、保守的な距離結合修復で使用する距離です。",
("*","Last Audit Report"):"直近の監査レポート",
("*","Need an active component mesh and at least one other selected target mesh"):"アクティブなコンポーネント用メッシュと、他に少なくとも1つの対象メッシュが必要です",
("*","No target faces were found"):"対象面が見つかりませんでした",
("*","Created face component array"):"面コンポーネント配列を作成しました",
("*","Need an active mesh in Edit Mode with exactly 2 selected edges"):"編集モードのアクティブメッシュと、ちょうど2本の選択辺が必要です",
("*","Selected edges are parallel or could not be resolved"):"選択辺が平行か、交点を解決できませんでした",
("*","Intersection lies outside one or both selected segments; use Extend mode"):"交点が片方または両方のセグメント外にあります。Extend モードを使ってください",
("*","Inserted intersection on selected edges"):"選択辺へ交点を挿入しました",
("*","Extended selected edges to the resolved meeting point"):"選択辺の端点を解決された交点まで延長しました",
("*","No mesh objects selected for audit"):"監査対象のメッシュオブジェクトが選択されていません",
("*","Audit complete"):"監査が完了しました",
("*","Audit + Repair complete"):"監査 + 修復が完了しました",
("*","No valid surface hit was found for the selected vertices on the target mesh"):"対象メッシュ上で、選択頂点に対する有効なサーフェスヒットが見つかりませんでした",
("*","Object Mode destructive symmetry is not supported; enable Object Mode = Mirror Modifier or switch to Edit Mode"):"オブジェクトモードでの破壊的対称化は未対応です。Object Mode = Mirror Modifier を有効にするか、編集モードへ切り替えてください",
("*","Targets"):"対象",
("*","Objects"):"オブジェクト数",
("*","Vertices"):"頂点数",
("*","Edges"):"辺数",
("*","Faces"):"面数",
("*","Non-manifold Edges"):"非多様体辺",
("*","Loose Vertices"):"ルーズ頂点",
("*","Loose Edges"):"ルーズ辺",
("*","Ngons"):"Nゴン",
("*","Triangles"):"三角形",
("*","Degenerate Edges"):"退化辺",
("*","Zero-area Faces"):"面積ゼロ面",
("*","Potential Doubles"):"重複候補",
("*","• Face arrays: Face Component Array duplicates an active detail mesh across target faces for panels, tiles, and vents."):"• 面配置: 面コンポーネント配列で、アクティブなディテールメッシュを対象面へ複製し、パネル・タイル・ベントを高速配置。",
("*","• CAD cleanup: CAD Intersect / Extend resolves two selected edges like tinyCAD-style intersection helpers."):"• CAD 整理: CAD 交点 / 延長で、tinyCAD 系の交点補助のように2本の選択辺を解決。",
("*","• Mesh QA: Audit Selected reports manifold, loose, ngon, degenerate, and duplicate risks before export or print."):"• メッシュ QA: 選択を監査で、書き出しやプリント前に多様体・ルーズ・Nゴン・退化・重複リスクを確認。",
("*","• Safe repair: Audit + Repair runs conservative cleanup, then refreshes the audit report."):"• 安全修復: 監査 + 修復で保守的なクリーンアップを行い、監査レポートを更新。",
})

translation_catalog_dict ["ja_JP"].update ({
("*","Curves / Loft / Prep"):"カーブ / ロフト / 下準備",
("*","Selected Edges To Curve"):"選択エッジをカーブ化",
("*","Convert selected mesh edges into one or more curve splines without duplicating or separating the source mesh. Useful for Vertices to Splines, sweep prep, path extraction, trim routing, and safer pipe workflows."):"選択メッシュエッジを、元メッシュを複製・分離せずに1本以上のカーブスプラインへ変換します。Vertices to Splines、スイープ準備、パス抽出、トリム配線、より安全なパイプ作成ワークフローに便利です。",
("*","Loft / Bridge Paths"):"ロフト / パスブリッジ",
("*","Create a loft mesh between exactly two paths. Works with two selected curve objects in Object Mode, or with exactly two selected edge paths in Edit Mode. Useful for PolyBridge, spline patch, loft surfacing, trims, and strip modeling workflows."):"ちょうど2本のパス間にロフトメッシュを生成します。オブジェクトモードでは2つの選択カーブ、編集モードではちょうど2本の選択エッジパスに対応します。PolyBridge、スプラインパッチ、ロフト面生成、トリム、帯状モデリングに便利です。",
("*","Loft Samples"):"ロフト分割数",
("*","Number of sampled points used when lofting between two paths."):"2本のパス間をロフトする際に使用するサンプル点数です。",
("*","Shade Smooth Loft"):"ロフトをスムーズシェード",
("*","Enable smooth shading on the generated loft mesh."):"生成したロフトメッシュでスムーズシェードを有効にします。",
("*","Need selected mesh edges in Edit Mode"):"編集モードで選択されたメッシュエッジが必要です",
("*","Need exactly two selected curve objects or exactly two selected edge paths"):"ちょうど2つの選択カーブ、またはちょうど2本の選択エッジパスが必要です",
("*","Created curve object from selected edges"):"選択エッジからカーブオブジェクトを作成しました",
("*","Created loft mesh from two paths"):"2本のパスからロフトメッシュを作成しました",
("*","Failed to create curve data from the selected edges"):"選択エッジからカーブデータを作成できませんでした",
("*","Failed to create loft mesh from the resolved paths"):"解決したパスからロフトメッシュを作成できませんでした",
("*","• Curve extraction: Selected Edges To Curve builds clean splines from edge selections without duplicate/separate steps."):"• カーブ抽出: 選択エッジをカーブ化で、複製/分離なしにエッジ選択からクリーンなスプラインを作成します。",
("*","• Lofting: Loft / Bridge Paths creates quick strip and patch surfaces between two curves or two selected edge paths."):"• ロフト: ロフト / パスブリッジで、2本のカーブまたは2本の選択エッジパス間に素早く帯状・パッチ面を作成します。",
})


translation_catalog_dict ["ja_JP"].update ({
("*","Sweep Active Profile"):"アクティブパスへプロファイルをスイープ",
("*","Add a non-destructive Sweep modifier that pushes the selected profile curve along the active path curve."):"選択したプロファイルカーブをアクティブなパスカーブに沿って押し出す、非破壊のスイープモディファイアを追加します。",
("*","Duplicate Path"):"パスを複製",
("*","Create a duplicated path object before adding the Sweep modifier, so the original path remains unchanged."):"スイープモディファイアを追加する前にパスオブジェクトを複製し、元のパスを変更せずに残します。",
("*","Sweep Fill Caps"):"スイープ端面を閉じる",
("*","Close the open ends of the generated Sweep mesh."):"生成したスイープメッシュの開いた端面を閉じます。",
("*","Sweep Resolution"):"スイープ解像度",
("*","Evaluation resolution used inside the Sweep modifier without changing the source path curve."):"元のパスカーブを変更せず、スイープモディファイア内部で使用する評価解像度です。",
("*","Sweep X Offset"):"スイープ X オフセット",
("*","Offset the profile along its local X axis."):"プロファイルをローカル X 軸方向へオフセットします。",
("*","Sweep Y Offset"):"スイープ Y オフセット",
("*","Offset the profile along its local Y axis."):"プロファイルをローカル Y 軸方向へオフセットします。",
("*","Sweep Angle"):"スイープ角度",
("*","Rotate the profile around its local Z axis."):"プロファイルをローカル Z 軸まわりに回転します。",
("*","Mirror Sweep X"):"スイープを X 反転",
("*","Mirror the profile across its local X axis."):"プロファイルをローカル X 軸で反転します。",
("*","Mirror Sweep Y"):"スイープを Y 反転",
("*","Mirror the profile across its local Y axis."):"プロファイルをローカル Y 軸で反転します。",
("*","Active path curve and one selected profile curve are required"):"アクティブなパスカーブと、選択された1本のプロファイルカーブが必要です",
("*","Added a non-destructive Sweep modifier using the selected profile curve"):"選択したプロファイルカーブを使用する非破壊スイープモディファイアを追加しました",
("*","Could not create the Sweep modifier"):"スイープモディファイアを作成できませんでした",
("*","• Profile sweeps: Sweep Active Profile turns an active path plus one selected profile curve into a reusable molding / trim / rail workflow."):"• プロファイルスイープ: アクティブパスへプロファイルをスイープで、アクティブなパスと選択した1本の断面カーブから、モール / トリム / レールの再利用可能なワークフローを構築します。",
})


translation_catalog_dict ["ja_JP"].update ({
("*","Selected Objects To Path"):"選択オブジェクトをパス化",
("*","Create a curve path from the world-space origins of the selected objects. Useful for trajectory-to-spline style workflows, blocking guide curves, layout splines, and quickly turning placed empties/objects into reusable paths."):"選択オブジェクトのワールド座標原点からカーブパスを作成します。Trajectory to Spline 系ワークフロー、ガイドカーブ、レイアウトスプライン、配置済み Empty / オブジェクトを再利用可能なパスへ素早く変換する用途に便利です。",
("*","Path From Objects"):"オブジェクトからパス作成",
("*","Use Nearest Chain"):"最近接チェーンを使う",
("*","Start from the active object, then order the remaining selected objects by nearest-neighbor distance so the generated path follows the placed layout more naturally."):"アクティブオブジェクトを始点にし、残りの選択オブジェクトを最近接距離で並べて、配置されたレイアウトに沿いやすい自然なパスを生成します。",
("*","Close Object Path"):"オブジェクトパスを閉じる",
("*","Close the generated path so the last sampled object links back to the first."):"生成したパスを閉じ、最後のオブジェクトから最初のオブジェクトへ戻るようにします。",
("*","Need at least two selected objects in Object Mode"):"オブジェクトモードで少なくとも2つの選択オブジェクトが必要です",
("*","Created curve path from selected objects"):"選択オブジェクトからカーブパスを作成しました",
("*","Failed to create curve path from the selected objects"):"選択オブジェクトからカーブパスを作成できませんでした",
("*","• Object paths: Selected Objects To Path turns placed objects or empties into reusable guide curves for sweeps, arrays, layout, and trajectory-style workflows."):"• オブジェクトパス: 選択オブジェクトをパス化で、配置済みオブジェクトや Empty を、スイープ、配列、レイアウト、Trajectory 系ワークフローに使える再利用可能なガイドカーブへ変換します。",
})



translation_catalog_dict ["ja_JP"].update ({
("*","Profile / Path Primitives"):"断面 / パス プリミティブ",
("*","Add Profile Primitive"):"断面プリミティブを追加",
("*","Create a reusable 2D curve profile at the 3D cursor. Useful for Sweep Mesh, molding, trim, rail sections, cable trays, and CAD-style profile workflows."):"3Dカーソル位置に再利用可能な2Dカーブ断面を作成します。Sweep Mesh、モール、トリム、手すり断面、ケーブルトレイ、CAD系プロファイルワークフローに便利です。",
("*","Add Helix Path"):"ヘリックスパスを追加",
("*","Create a helix/spiral curve path at the 3D cursor. Useful for springs, spiral cables, wrapped trims, and guide curves for sweep or array workflows."):"3Dカーソル位置にヘリックス / スパイラルのカーブパスを作成します。バネ、螺旋ケーブル、巻き付きトリム、スイープや配列のガイドカーブに便利です。",
("*","Profile Type"):"断面タイプ",
("*","Choose which reusable 2D curve profile to create at the 3D cursor."):"3Dカーソル位置に作成する再利用可能な2Dカーブ断面の種類を選びます。",
("*","Circle"):"円",
("*","Rectangle"):"矩形",
("*","N-gon"):"N角形",
("*","Star"):"星形",
("*","Profile Width"):"断面幅",
("*","Overall width of the generated profile primitive. Circle and N-gon types use this as the X diameter."):"生成する断面プリミティブの全幅です。円形とN角形ではX方向の直径として使われます。",
("*","Profile Height"):"断面高さ",
("*","Overall height of the generated profile primitive. Circle and N-gon types use this as the Y diameter."):"生成する断面プリミティブの全高です。円形とN角形ではY方向の直径として使われます。",
("*","Profile Points"):"断面ポイント数",
("*","Point count used for circle, N-gon, and star profile generation."):"円形、N角形、星形プロファイルの生成に使うポイント数です。",
("*","Star Inner Ratio"):"星形内側比率",
("*","Inner radius ratio used when the profile type is Star."):"断面タイプが星形のときに使う内側半径の比率です。",
("*","Helix Radius"):"ヘリックス半径",
("*","Base radius of the generated helix path."):"生成するヘリックスパスの基本半径です。",
("*","Helix Height"):"ヘリックス高さ",
("*","Total height of the generated helix path."):"生成するヘリックスパスの全高です。",
("*","Helix Turns"):"ヘリックス巻数",
("*","Number of turns used by the generated helix path. Fractional values are allowed."):"生成するヘリックスパスの巻数です。小数値も使えます。",
("*","Points / Turn"):"1周あたりポイント数",
("*","Number of sampled points used for each helix turn. Higher values create a smoother path."):"ヘリックス1周ごとに使うサンプル点数です。高いほど滑らかなパスになります。",
("*","Helix Taper"):"ヘリックステーパー",
("*","Change the end radius relative to the start radius. Negative values tighten the spiral; positive values widen it."):"開始半径に対して終端半径を変化させます。負の値で先細り、正の値で末広がりになります。",
("*","Clockwise"):"時計回り",
("*","Generate the helix in clockwise direction around the local Z axis."):"ローカルZ軸まわりに時計回り方向でヘリックスを生成します。",
("*","Created profile primitive"):"断面プリミティブを作成しました",
("*","Created helix path"):"ヘリックスパスを作成しました",
("*","Object Mode required"):"オブジェクトモードが必要です",
("*","• Profile primitives: Add Profile Primitive creates reusable 2D curve sections for sweeps, trims, rails, and cable profiles."):"• 断面プリミティブ: 断面プリミティブを追加で、スイープ、トリム、レール、ケーブル断面に使える再利用可能な2Dカーブを作成。",
("*","• Helix paths: Add Helix Path creates spring and spiral guide curves for cable, sweep, and motion-path style setups."):"• ヘリックスパス: ヘリックスパスを追加で、ケーブル、スイープ、モーションパス風セットアップ向けのバネ / 螺旋ガイドカーブを作成。",
})


translation_catalog_dict ["ja_JP"].update ({
("*","Selected Vertices To Path"):"選択頂点をパス化",
("*","Need selected vertices in Edit Mode"):"編集モードで選択された頂点が必要です",
("*","Failed to create curve path from selected vertices"):"選択頂点からカーブパスを作成できませんでした",
("*","Created curve path from selected vertices"):"選択頂点からカーブパスを作成しました",
("*","Use Nearest Vertex Chain"):"最近接頂点チェーンを使う",
("*","When converting selected vertices to a path, start from the active vertex when possible and order the remaining vertices by nearest-neighbor distance."):"選択頂点をパス化する際、可能ならアクティブ頂点から開始し、残りを最近接距離順に並べます。",
("*","Close Vertex Path"):"頂点パスを閉じる",
("*","Close the generated vertex path so the last sampled point links back to the first."):"生成した頂点パスを閉じ、最後の点を最初の点へつなぎます。",
})

translation_catalog_dict ["ja_JP"].update ({
("*","Axis Slice Edit"):"軸スライス編集",
("*","Bisect the active edit mesh by one or more evenly spaced local axis planes. Useful for SliceIt XYZ / Slicer style numeric cuts, panel segmentation, contour prep, and quick retopo guides."):"アクティブな編集メッシュを、ローカル軸に沿った等間隔の1枚以上の平面で分割します。SliceIt XYZ / Slicer 系の数値カット、パネル分割、等高線準備、簡易リトポガイドに便利です。",
("*","Slice Axis"):"スライス軸",
("*","Local axis used by Axis Slice Edit when creating evenly spaced bisect planes."):"Axis Slice Edit が等間隔の分割平面を作るときに使うローカル軸です。",
("*","Slice Count"):"スライス数",
("*","Number of evenly spaced slice planes inserted between the local minimum and maximum bounds."):"ローカル最小値と最大値の間に挿入する等間隔スライス平面の数です。",
("*","Use Selection Bounds"):"選択範囲の境界を使う",
("*","When enabled, Axis Slice Edit derives the slice range from the current selection when possible. The cuts still pass through the mesh like a numeric slice helper."):"有効時、Axis Slice Edit は可能なら現在の選択範囲からスライス範囲を求めます。カット自体は数値スライス補助のようにメッシュ全体を通過します。",
("*","Select New Cuts"):"新しいカットを選択",
("*","Select the newly generated cut edges after Axis Slice Edit runs."):"Axis Slice Edit 実行後に、新しく生成されたカットエッジを選択します。",
("*","Slice Tolerance"):"スライス許容値",
("*","Distance tolerance used by Axis Slice Edit when resolving plane/mesh intersections."):"Axis Slice Edit が平面とメッシュの交差を解決する際に使う距離許容値です。",
("*","Axis slice complete"):"軸スライスが完了しました",
("*","Need a mesh with non-zero extent along the chosen slice axis"):"選択したスライス軸方向に十分な大きさを持つメッシュが必要です",
("*","Select one or more vertices / edges / faces first, or disable Use Selection Bounds"):"先に頂点 / 辺 / 面を1つ以上選択するか、選択範囲の境界を使う を無効にしてください",
("*","No new slice edges were generated"):"新しいスライスエッジは生成されませんでした",
("*","Select Issues"):"問題要素を選択",
("*","Issue Filter"):"問題フィルター",
("*","Choose which audit issue type should be selected on the active mesh."):"アクティブメッシュ上でどの監査問題タイプを選択するかを選びます。",
("*","Non-manifold"):"非多様体",
("*","Select non-manifold edges on the active mesh."):"アクティブメッシュの非多様体エッジを選択します。",
("*","Loose Geometry"):"ルーズジオメトリ",
("*","Select loose vertices and wire edges on the active mesh."):"アクティブメッシュのルーズ頂点とワイヤエッジを選択します。",
("*","Degenerate Edges"):"退化エッジ",
("*","Select zero-length or near-zero-length edges on the active mesh."):"アクティブメッシュの長さゼロまたは極小長のエッジを選択します。",
("*","Potential Doubles"):"重複候補",
("*","Select vertices that look like double candidates within the configured audit merge distance."):"設定した監査マージ距離内で重複候補に見える頂点を選択します。",
("*","Select the chosen audit issue type on the active mesh so you can inspect or repair it directly."):"選んだ監査問題タイプをアクティブメッシュ上で選択し、直接確認や修復ができるようにします。",
("*","No matching issues were found on the active mesh"):"アクティブメッシュ上に一致する問題は見つかりませんでした",
("*","Selected issue elements"):"問題要素を選択しました",
("*","Could not switch to Edit Mode"):"編集モードへ切り替えられませんでした",
("*","• Numeric slicing: Axis Slice Edit adds evenly spaced local cuts for panel segmentation, contour layers, and SliceIt XYZ style blocking."):"• 数値スライス: 軸スライス編集で、パネル分割、等高線レイヤー、SliceIt XYZ 風のブロックアウト向けに等間隔のローカルカットを追加します。",
("*","• Visual QA: Select Issues highlights non-manifold, loose, ngon, triangle, degenerate, zero-area, or double-candidate elements for direct cleanup."):"• 可視QA: 問題要素を選択で、非多様体、ルーズ、Nゴン、三角形、退化、面積ゼロ、重複候補を直接クリーンアップしやすいようにハイライトします。",
})

def _t (msg :str )->str :
    try :
        return _sms_pgettext (msg )
    except Exception :
        return msg 


def _draw_panel_operator (layout ,context ,operator_id :str ,*,text =None ,icon ='NONE',missing_icon ='ERROR'):
    available =operator_available (operator_id )
    runnable =operator_runnable (operator_id )if available else False 
    row =layout .row (align =True )
    row .enabled =runnable 
    if available :
        try :
            from .icons import operator as _sms_icon_operator
            return _sms_icon_operator (row ,operator_id ,text =text ,icon_name =operator_id ,fallback_icon =icon )
        except Exception :
            if text is None :
                return row .operator (operator_id ,icon =icon )
            return row .operator (operator_id ,text =text ,icon =icon )
    row .alert =True 
    row .enabled =False 
    label =text if text is not None else operator_id 
    try :
        from .icons import label as _sms_icon_label
        _sms_icon_label (row ,text =label ,icon_name =missing_icon ,fallback_icon =missing_icon )
    except Exception :
        row .label (text =label ,icon =missing_icon )
    return None 


def _ensure_collection (context ,name :str ):
    col =bpy .data .collections .get (name )
    if col is None :
        col =bpy .data .collections .new (name )
        context .scene .collection .children .link (col )
    return col 


_SMS_FACTORY_OWNER_KEY ="_sms_factory_owner"


def _ensure_owned_collection (context ,name :str ,owner :str ):
    col =bpy .data .collections .get (name )
    if col is not None and col .get (_SMS_FACTORY_OWNER_KEY )==owner :
        return col ,False 
    actual_name =_unique_name (set (bpy .data .collections .keys ()),name )
    col =bpy .data .collections .new (actual_name )
    try :
        col [_SMS_FACTORY_OWNER_KEY ]=owner 
        context .scene .collection .children .link (col )
    except Exception :
        bpy .data .collections .remove (col )
        raise 
    return col ,True 


def _link_object_to_collection (obj ,col ):
    if obj is None or col is None :
        return 
    try :
        if col .objects .get (obj .name )is None :
            col .objects .link (obj )
    except Exception :
        pass 


def _link_to_same_collections (new_obj ,ref_obj ,context ):
    linked =False 
    try :
        for col in list (ref_obj .users_collection ):
            _link_object_to_collection (new_obj ,col )
            linked =True 
    except Exception :
        pass 
    if not linked :
        _link_object_to_collection (new_obj ,context .scene .collection )


def _active_mesh_object (context ):
    obj =getattr (context ,'active_object',None )
    return obj if obj and obj .type =='MESH'else None 


def _active_curve_object (context ):
    obj =getattr (context ,'active_object',None )
    return obj if obj and obj .type =='CURVE'else None 


def _get_or_create_modifier (obj ,name :str ,mod_type :str ):
    try :
        mod =obj .modifiers .get (name )
        if mod is not None and getattr (mod ,'type',None )==mod_type :
            return mod 
    except Exception :
        mod =None 
    try :
        return obj .modifiers .new (name =name ,type =mod_type )
    except Exception :
        return None 


def _set_shrinkwrap_mode (mod ,mode :str ):
    for attr in ('wrap_method','wrap_mode'):
        try :
            setattr (mod ,attr ,mode )
            return True 
        except Exception :
            pass 
    return False 


def _configure_data_transfer_normals (mod ,source_obj ,mix_factor :float =1.0 ):
    if mod is None :
        return 
    try :
        mod .object =source_obj 
    except Exception :
        pass 
    try :
        mod .use_loop_data =True 
    except Exception :
        pass 
    for attr ,value in (('loop_mapping','POLYINTERP_NEAREST'),('mix_mode','REPLACE')):
        try :
            setattr (mod ,attr ,value )
        except Exception :
            pass 
    try :
        mod .mix_factor =float (mix_factor )
    except Exception :
        pass 
    # RNA enum flags return a set copy; assign it back to enable transfer.
    mod .data_types_loops ={'CUSTOM_NORMAL'}


def _orientation_matrix_from_vectors (origin :Vector ,normal :Vector ,tangent :Vector ):
    normal =normal .normalized ()if normal .length >1e-12 else Vector ((0.0 ,0.0 ,1.0 ))
    tangent =tangent -normal *tangent .dot (normal )
    if tangent .length <1e-12 :
        tangent =normal .orthogonal ()
    tangent .normalize ()
    bitangent =normal .cross (tangent )
    if bitangent .length <1e-12 :
        bitangent =tangent .orthogonal ()
    bitangent .normalize ()
    tangent =bitangent .cross (normal ).normalized ()
    mat =Matrix ((tangent ,bitangent ,normal )).transposed ().to_4x4 ()
    mat .translation =origin 
    return mat 


def _extract_active_face_or_edge (bm ):
    face =bm .faces .active 
    if face and face .select :
        return face ,None 
    selected_faces =[f for f in bm .faces if f .select ]
    if selected_faces :
        return selected_faces [0 ],None 
    selected_edges =[e for e in bm .edges if e .select ]
    if selected_edges :
        return None ,selected_edges [0 ]
    return None ,None 


def _unique_name (existing ,base :str )->str :
    if base not in existing :
        return base 
    i =2 
    while f"{base }.{i :03d}"in existing :
        i +=1 
    return f"{base }.{i :03d}"


def _edge_key (a :int ,b :int ):
    return (a ,b )if a <b else (b ,a )


def _selected_edge_paths_world_from_bmesh (obj ,bm ):
    selected_edges =[e for e in bm .edges if e .select ]
    if not selected_edges :
        return []
    adjacency ={}
    coords ={}
    world =obj .matrix_world 
    for e in selected_edges :
        a ,b =e .verts 
        adjacency .setdefault (a .index ,[]).append (b .index )
        adjacency .setdefault (b .index ,[]).append (a .index )
        coords [a .index ]=world @a .co .copy ()
        coords [b .index ]=world @b .co .copy ()
    visited =set ()
    paths =[]
    starts =[idx for idx ,links in adjacency .items ()if len (links )==1 ]
    starts .extend (idx for idx in adjacency .keys ()if idx not in starts )
    for start in starts :
        if not adjacency .get (start ):
            continue 
        if all (_edge_key (start ,n )in visited for n in adjacency [start ]):
            continue 
        path =[start ]
        prev =None 
        cur =start 
        while True :
            candidates =[n for n in adjacency [cur ]if _edge_key (cur ,n )not in visited ]
            if prev is not None :
                non_prev =[n for n in candidates if n !=prev ]
                if non_prev :
                    candidates =non_prev 
            if not candidates :
                break 
            nxt =candidates [0 ]
            visited .add (_edge_key (cur ,nxt ))
            path .append (nxt )
            prev ,cur =cur ,nxt 
            if cur ==start :
                break 
        if len (path )>1 :
            paths .append ([coords [i ].copy ()for i in path ])
    return paths 


def _path_is_cyclic (points ,epsilon :float =1.0e-6 )->bool :
    return len (points )>=3 and (points [0 ]-points [-1 ]).length <=epsilon 


def _sample_path (points ,count :int ,cyclic :bool =False ):
    pts =[p .copy ()for p in points ]
    if cyclic and len (pts )>1 and (pts [0 ]-pts [-1 ]).length <=1.0e-6 :
        pts =pts [:-1 ]
    if len (pts )<2 :
        return []
    count =max (2 ,int (count ))
    pairs =[]
    if cyclic :
        for i in range (len (pts )):
            pairs .append ((pts [i ],pts [(i +1 )%len (pts )]))
    else :
        for i in range (len (pts )-1 ):
            pairs .append ((pts [i ],pts [i +1 ]))
    seg_lens =[]
    accum =[0.0 ]
    total =0.0 
    for p0 ,p1 in pairs :
        seg =(p1 -p0 ).length 
        seg_lens .append (seg )
        total +=seg 
        accum .append (total )
    if total <=1.0e-12 :
        tangent =(pts [-1 ]-pts [0 ]).normalized ()if (pts [-1 ]-pts [0 ]).length >1.0e-12 else Vector ((1.0 ,0.0 ,0.0 ))
        return [(pts [0 ].copy (),tangent )]*count 
    if cyclic :
        distances =[i *total /float (count )for i in range (count )]
    elif count ==2 :
        distances =[0.0 ,total ]
    else :
        step =total /float (count -1 )
        distances =[i *step for i in range (count )]
    samples =[]
    for d in distances :
        d =max (0.0 ,min (total ,d ))
        seg_idx =max (0 ,min (len (seg_lens )-1 ,bisect .bisect_right (accum ,d )-1 ))
        seg_start =accum [seg_idx ]
        seg_len =seg_lens [seg_idx ]
        alpha =0.0 if seg_len <=1.0e-12 else (d -seg_start )/seg_len 
        p0 ,p1 =pairs [seg_idx ]
        point =p0 .lerp (p1 ,alpha )
        tangent =(p1 -p0 ).normalized ()if (p1 -p0 ).length >1.0e-12 else Vector ((1.0 ,0.0 ,0.0 ))
        samples .append ((point ,tangent ))
    return samples 



def _ordered_selected_objects_for_path (context ,use_nearest :bool =True ):
    objs =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj is not None ]
    if len (objs )<2 :
        return []
    active =getattr (context ,'active_object',None )
    if active not in objs :
        active =objs [0 ]
    if not use_nearest :
        ordered =[active ]+[obj for obj in objs if obj !=active ]
        return ordered 
    remaining =[obj for obj in objs if obj !=active ]
    ordered =[active ]
    current =active 
    while remaining :
        current_loc =current .matrix_world .translation 
        next_obj =min (remaining ,key =lambda obj :(obj .matrix_world .translation -current_loc ).length )
        ordered .append (next_obj )
        remaining .remove (next_obj )
        current =next_obj 
    return ordered 



def _activate_only (context ,obj ):
    safe_activate_only (context ,obj )


def _new_curve_object_from_world_paths (context ,name :str ,world_paths ,reference_obj =None ,bevel_depth :float =0.0 ,bevel_resolution :int =0 ,fill_caps :bool =False ):
    valid_paths =[path for path in world_paths if len (path )>=2 ]
    if not valid_paths :
        return None 
    curve_data =None 
    curve_obj =None 
    try :
        curve_data =bpy .data .curves .new (name =name ,type ='CURVE')
        curve_data .dimensions ='3D'
        try :
            curve_data .bevel_depth =max (0.0 ,float (bevel_depth ))
        except Exception :
            pass 
        try :
            curve_data .bevel_resolution =max (0 ,int (bevel_resolution ))
        except Exception :
            pass 
        if hasattr (curve_data ,'use_fill_caps'):
            try :
                curve_data .use_fill_caps =bool (fill_caps )
            except Exception :
                pass 
        base_matrix =Matrix .Identity (4 )
        inv =Matrix .Identity (4 )
        if reference_obj is not None :
            try :
                base_matrix =reference_obj .matrix_world .copy ()
                inv =base_matrix .inverted ()
            except Exception :
                base_matrix =Matrix .Identity (4 )
                inv =Matrix .Identity (4 )
        for path in valid_paths :
            cyclic =_path_is_cyclic (path )
            points =path [:-1 ]if cyclic and len (path )>2 else path 
            spline =curve_data .splines .new ('POLY')
            spline .points .add (max (0 ,len (points )-1 ))
            for i ,point in enumerate (points ):
                local =inv @point 
                spline .points [i ].co =(local .x ,local .y ,local .z ,1.0 )
            try :
                spline .use_cyclic_u =bool (cyclic )
            except Exception :
                pass 
        curve_obj =bpy .data .objects .new (name ,curve_data )
        curve_obj .matrix_world =base_matrix 
        if reference_obj is not None :
            _link_to_same_collections (curve_obj ,reference_obj ,context )
        else :
            _link_object_to_collection (curve_obj ,_context_collection (context ))
        if not tuple (getattr (curve_obj ,'users_collection',())or ()):
            raise RuntimeError ('New pipe curve was not linked to a collection')
        return curve_obj 
    except Exception :
        try :
            if curve_obj is not None :
                bpy .data .objects .remove (curve_obj ,do_unlink =True )
        except Exception :
            pass 
        try :
            if curve_data is not None :
                bpy .data .curves .remove (curve_data )
        except Exception :
            pass 
        return None 


def _context_collection (context ):
    col =getattr (context ,'collection',None )
    if col is not None :
        return col 
    try :
        return context .view_layer .active_layer_collection .collection 
    except Exception :
        return context .scene .collection 


def _cursor_matrix (context ):
    cursor =context .scene .cursor 
    try :
        return cursor .matrix .copy ()
    except Exception :
        pass 
    loc =Matrix .Translation (cursor .location .copy ())
    try :
        mode =getattr (cursor ,'rotation_mode','XYZ')
        if mode =='QUATERNION':
            rot =cursor .rotation_quaternion .to_matrix ().to_4x4 ()
        elif mode =='AXIS_ANGLE':
            axis =Vector (cursor .rotation_axis_angle [1 :4 ])
            if axis .length <=1.0e-12 :
                rot =Matrix .Identity (4 )
            else :
                rot =Quaternion (axis .normalized (),cursor .rotation_axis_angle [0 ]).to_matrix ().to_4x4 ()
        else :
            rot =cursor .rotation_euler .to_matrix ().to_4x4 ()
    except Exception :
        rot =Matrix .Identity (4 )
    return loc @rot 


def _new_local_curve_object (context ,name :str ,local_paths ,dimensions :str ='3D',cyclic :bool =False ,fill_mode :str ='NONE',resolution_u :int =12 ,use_path :bool =True ):
    valid_paths =[list (path )for path in local_paths if len (path )>=2 ]
    if not valid_paths :
        return None 
    curve_data =bpy .data .curves .new (name =name ,type ='CURVE')
    curve_data .dimensions =dimensions 
    try :
        curve_data .resolution_u =max (1 ,int (resolution_u ))
    except Exception :
        pass 
    try :
        curve_data .use_path =bool (use_path )
    except Exception :
        pass 
    try :
        curve_data .fill_mode =fill_mode 
    except Exception :
        pass 
    for path in valid_paths :
        spline =curve_data .splines .new ('POLY')
        spline .points .add (max (0 ,len (path )-1 ))
        for i ,point in enumerate (path ):
            spline .points [i ].co =(point .x ,point .y ,point .z ,1.0 )
        try :
            spline .use_cyclic_u =bool (cyclic )
        except Exception :
            pass 
    obj =bpy .data .objects .new (name ,curve_data )
    obj .matrix_world =_cursor_matrix (context )
    _link_object_to_collection (obj ,_context_collection (context ))
    return obj 


def _profile_points (profile_type :str ,width :float ,height :float ,point_count :int ,star_inner :float ):
    width =max (1.0e-6 ,float (width ))
    height =max (1.0e-6 ,float (height ))
    rx =width *0.5 
    ry =height *0.5 
    if profile_type =='RECTANGLE':
        return [
        Vector ((rx ,ry ,0.0 )),
        Vector ((-rx ,ry ,0.0 )),
        Vector ((-rx ,-ry ,0.0 )),
        Vector ((rx ,-ry ,0.0 )),
        ]
    if profile_type =='STAR':
        count =max (3 ,int (point_count ))
        inner =max (0.01 ,min (0.99 ,float (star_inner )))
        points =[]
        for i in range (count *2 ):
            angle =(math .tau *i )/float (count *2 )
            scale =1.0 if (i %2 ==0 )else inner 
            points .append (Vector ((math .cos (angle )*rx *scale ,math .sin (angle )*ry *scale ,0.0 )))
        return points 
    count =max (3 ,int (point_count ))
    if profile_type =='CIRCLE':
        count =max (8 ,count )
    return [
    Vector ((math .cos ((math .tau *i )/float (count ))*rx ,math .sin ((math .tau *i )/float (count ))*ry ,0.0 ))
    for i in range (count )
    ]


def _helix_points (radius :float ,height :float ,turns :float ,points_per_turn :int ,taper :float ,clockwise :bool ):
    radius =max (1.0e-6 ,float (radius ))
    turns =max (0.05 ,float (turns ))
    points_per_turn =max (3 ,int (points_per_turn ))
    steps =max (2 ,int (math .ceil (turns *points_per_turn )))
    direction =-1.0 if clockwise else 1.0 
    points =[]
    for step in range (steps +1 ):
        t =step /float (steps )
        scale =max (0.01 ,1.0 +float (taper )*t )
        angle =direction *math .tau *turns *t 
        points .append (Vector ((math .cos (angle )*radius *scale ,math .sin (angle )*radius *scale ,float (height )*t )))
    return points 


def _new_loft_object_from_paths (context ,name :str ,path_a ,path_b ,sample_count :int ,shade_smooth :bool =True ,reference_obj =None ):
    use_cyclic =_path_is_cyclic (path_a )and _path_is_cyclic (path_b )
    sample_count =max (3 if use_cyclic else 2 ,int (sample_count ))
    samples_a =_sample_path (path_a ,sample_count ,cyclic =use_cyclic )
    samples_b =_sample_path (path_b ,sample_count ,cyclic =use_cyclic )
    if not samples_a or not samples_b :
        return None 
    bm =None 
    mesh =None 
    obj =None 
    try :
        bm =bmesh .new ()
        verts_a =[bm .verts .new (point .copy ())for point ,_ in samples_a ]
        verts_b =[bm .verts .new (point .copy ())for point ,_ in samples_b ]
        bm .verts .ensure_lookup_table ()
        face_count =sample_count if use_cyclic else (sample_count -1 )
        for i in range (face_count ):
            j =(i +1 )%sample_count if use_cyclic else i +1 
            try :
                bm .faces .new ((verts_a [i ],verts_a [j ],verts_b [j ],verts_b [i ]))
            except ValueError :
                pass 
        mesh =bpy .data .meshes .new (name )
        bm .to_mesh (mesh )
        mesh .update ()
        if shade_smooth :
            try :
                for poly in mesh .polygons :
                    poly .use_smooth =True 
            except Exception :
                pass 
        obj =bpy .data .objects .new (name ,mesh )
        if reference_obj is not None :
            _link_to_same_collections (obj ,reference_obj ,context )
        else :
            _link_object_to_collection (obj ,_context_collection (context ))
        if not tuple (getattr (obj ,'users_collection',())or ()):
            raise RuntimeError ('New loft mesh was not linked to a collection')
        return obj 
    except Exception :
        try :
            if obj is not None :
                bpy .data .objects .remove (obj ,do_unlink =True )
        except Exception :
            pass 
        try :
            if mesh is not None :
                bpy .data .meshes .remove (mesh )
        except Exception :
            pass 
        return None 
    finally :
        try :
            if bm is not None :
                bm .free ()
        except Exception :
            pass 


def _curve_to_longest_polyline_world (curve_obj ,depsgraph ):
    temp_mesh =None 
    try :
        eval_obj =curve_obj .evaluated_get (depsgraph )
    except Exception :
        eval_obj =curve_obj 
    try :
        temp_mesh =bpy .data .meshes .new_from_object (eval_obj ,preserve_all_data_layers =False ,depsgraph =depsgraph )
    except TypeError :
        try :
            temp_mesh =bpy .data .meshes .new_from_object (eval_obj ,depsgraph =depsgraph )
        except Exception :
            temp_mesh =None 
    except Exception :
        temp_mesh =None 
    if temp_mesh is None :
        return []
    try :
        if len (temp_mesh .vertices )<2 or len (temp_mesh .edges )<1 :
            return []
        world_verts =[curve_obj .matrix_world @v .co for v in temp_mesh .vertices ]
        adjacency ={i :[]for i in range (len (temp_mesh .vertices ))}
        for e in temp_mesh .edges :
            a ,b =e .vertices [:]
            adjacency [a ].append (b )
            adjacency [b ].append (a )
        visited_edges =set ()
        paths =[]

        def edge_key (a ,b ):
            return (a ,b )if a <b else (b ,a )

        def walk (start_idx ):
            path =[start_idx ]
            prev =None 
            cur =start_idx 
            while True :
                candidates =[n for n in adjacency [cur ]if edge_key (cur ,n )not in visited_edges ]
                if prev is not None :
                    not_prev =[n for n in candidates if n !=prev ]
                    if not_prev :
                        candidates =not_prev 
                if not candidates :
                    break 
                nxt =candidates [0 ]
                visited_edges .add (edge_key (cur ,nxt ))
                path .append (nxt )
                prev ,cur =cur ,nxt 
                if cur ==start_idx :
                    break 
            return path 

        endpoints =[i for i ,links in adjacency .items ()if len (links )==1 ]
        starts =endpoints +[i for i in adjacency .keys ()if i not in endpoints ]
        for start in starts :
            if not adjacency [start ]:
                continue 
            if all (edge_key (start ,n )in visited_edges for n in adjacency [start ]):
                continue 
            path =walk (start )
            if len (path )>1 :
                paths .append (path )
        if not paths :
            return []

        def path_length (path ):
            total =0.0 
            for i in range (len (path )-1 ):
                total +=(world_verts [path [i +1 ]]-world_verts [path [i ]]).length 
            return total 

        best =max (paths ,key =path_length )
        return [world_verts [i ]for i in best ]
    finally :
        try :
            bpy .data .meshes .remove (temp_mesh )
        except Exception :
            pass 


def _sample_polyline (points ,count :int ,include_ends :bool ):
    if len (points )<2 :
        return []
    seg_lens =[]
    accum =[0.0 ]
    total =0.0 
    for i in range (len (points )-1 ):
        seg =(points [i +1 ]-points [i ]).length 
        seg_lens .append (seg )
        total +=seg 
        accum .append (total )
    if total <=1e-12 :
        tangent =(points [-1 ]-points [0 ]).normalized ()if (points [-1 ]-points [0 ]).length >1e-12 else Vector ((1.0 ,0.0 ,0.0 ))
        return [(points [0 ].copy (),tangent )]*max (1 ,count )
    count =max (1 ,int (count ))
    if count ==1 :
        distances =[0.0 if include_ends else total *0.5 ]
    elif include_ends :
        step =total /max (1 ,count -1 )
        distances =[i *step for i in range (count )]
    else :
        step =total /float (count )
        distances =[(i +0.5 )*step for i in range (count )]
    samples =[]
    for d in distances :
        d =max (0.0 ,min (total ,d ))
        seg_idx =max (0 ,min (len (seg_lens )-1 ,bisect .bisect_right (accum ,d )-1 ))
        seg_start =accum [seg_idx ]
        seg_len =seg_lens [seg_idx ]
        alpha =0.0 if seg_len <=1e-12 else (d -seg_start )/seg_len 
        p0 =points [seg_idx ]
        p1 =points [seg_idx +1 ]
        point =p0 .lerp (p1 ,alpha )
        tangent =(p1 -p0 ).normalized ()if (p1 -p0 ).length >1e-12 else Vector ((1.0 ,0.0 ,0.0 ))
        samples .append ((point ,tangent ))
    return samples 


SOLO_SCENE_KEY ="_smsp_solo_active"
SOLO_OBJ_KEY ="_smsp_solo_prev_hidden"


def _other_selected_mesh_object (context ):
    active =_active_mesh_object (context )
    if active is None :
        return None 
    for obj in getattr (context ,'selected_objects',[])or []:
        if obj and obj .type =='MESH'and obj !=active :
            return obj 
    return None 


def _closest_point_on_mesh_safe (target, depsgraph, world_co):
    """Return a stable nearest point on target even while another selected object is in Edit Mode.

    Blender 5.1 can fail Object.closest_point_on_mesh on a non-active selected target
    while the active source is in Edit Mesh.  The fallback builds a lightweight
    BVH from the target mesh data so the projection tool remains functional.
    """
    if target is None or getattr(target, 'type', '') != 'MESH':
        return (False, None, None, -1)
    try:
        inv = target.matrix_world.inverted()
        local_co = inv @ world_co
    except Exception:
        return (False, None, None, -1)
    try:
        eval_target = target.evaluated_get(depsgraph) if depsgraph is not None else target
        hit, loc_local, nor_local, face_index = eval_target.closest_point_on_mesh(local_co)
        if hit and loc_local is not None:
            return (True, loc_local, nor_local, face_index)
    except Exception:
        pass
    try:
        mesh = getattr(target, 'data', None)
        if mesh is None:
            return (False, None, None, -1)
        verts = [v.co.copy() for v in mesh.vertices]
        polys = [tuple(p.vertices) for p in mesh.polygons if len(p.vertices) >= 3]
        if not verts or not polys:
            return (False, None, None, -1)
        tree = BVHTree.FromPolygons(verts, polys, all_triangles=False)
        if tree is None:
            return (False, None, None, -1)
        found = tree.find_nearest(local_co)
        if not found:
            return (False, None, None, -1)
        loc_local, nor_local, face_index, _dist = found
        if loc_local is None:
            return (False, None, None, -1)
        return (True, loc_local, nor_local, face_index)
    except Exception:
        return (False, None, None, -1)


def _direction_to_axis (direction :str )->str :
    if direction .endswith ('_X'):
        return 'X'
    if direction .endswith ('_Y'):
        return 'Y'
    return 'Z'


def _replace_curve_with_polyline (context ,curve_obj ,world_points ,cyclic :bool ,keep_original :bool ):
    curve_data =bpy .data .curves .new (name =f"{curve_obj .name }_Rebuilt",type ='CURVE')
    curve_data .dimensions ='3D'
    spline =curve_data .splines .new ('POLY')
    spline .points .add (max (0 ,len (world_points )-1 ))
    inv =curve_obj .matrix_world .inverted ()
    for i ,point in enumerate (world_points ):
        local =inv @point 
        spline .points [i ].co =(local .x ,local .y ,local .z ,1.0 )
    try :
        spline .use_cyclic_u =bool (cyclic )
    except Exception :
        pass 
    try :
        curve_data .resolution_u =max (1 ,getattr (curve_obj .data ,'resolution_u',12 ))
    except Exception :
        pass 

    if keep_original :
        new_obj =curve_obj .copy ()
        new_obj .data =curve_data 
        try :
            new_obj .animation_data_clear ()
        except Exception :
            pass 
        _link_to_same_collections (new_obj ,curve_obj ,context )
        new_obj .matrix_world =curve_obj .matrix_world .copy ()
        new_obj .name =f"{curve_obj .name }_Rebuilt"
        return new_obj 

    old_data =curve_obj .data 
    curve_obj .data =curve_data 
    try :
        if old_data and old_data .users ==0 :
            bpy .data .curves .remove (old_data )
    except Exception :
        pass 
    return curve_obj 


def _restore_solo_visibility (context ):
    for obj in getattr (context .view_layer ,'objects',[])or []:
        if SOLO_OBJ_KEY in obj :
            try :
                obj .hide_set (bool (obj [SOLO_OBJ_KEY ]))
            except Exception :
                pass 
            try :
                del obj [SOLO_OBJ_KEY ]
            except Exception :
                pass 
    try :
        if SOLO_SCENE_KEY in context .scene :
            del context .scene [SOLO_SCENE_KEY ]
    except Exception :
        pass 


def _selected_target_mesh_objects (context ):
    active =_active_mesh_object (context )
    return [obj for obj in getattr (context ,'selected_objects',[])or []if obj and obj .type =='MESH'and obj !=active ]


def _iter_target_polygons (obj ,selected_only =False ):
    polygons =list (getattr (obj .data ,'polygons',[])or [])
    if not selected_only :
        return polygons 
    selected =[poly for poly in polygons if getattr (poly ,'select',False )]
    return selected or polygons 


def _polygon_world_data (obj ,poly ):
    mesh =obj .data 
    mw =obj .matrix_world 
    mw3 =mw .to_3x3 ()
    coords =[mw @mesh .vertices [i ].co for i in poly .vertices ]
    if coords :
        center =Vector ((0.0 ,0.0 ,0.0 ))
        for co in coords :
            center +=co 
        center /=len (coords )
    else :
        center =mw .translation .copy ()
    try :
        normal =(mw3 @poly .normal ).normalized ()
    except Exception :
        normal =Vector ((0.0 ,0.0 ,1.0 ))
    longest =None 
    longest_len =-1.0 
    for i ,co in enumerate (coords ):
        nxt =coords [(i +1 )%len (coords )]
        vec =nxt -co 
        length =vec .length 
        if length >longest_len :
            longest =vec 
            longest_len =length 
    tangent =longest if longest is not None and longest .length >1e-12 else normal .orthogonal ()
    area =0.0 
    if len (coords )>=3 :
        root =coords [0 ]
        for i in range (1 ,len (coords )-1 ):
            area +=((coords [i ]-root ).cross (coords [i +1 ]-root )).length *0.5 
    return center ,normal ,tangent ,area 


def _component_reference_size (obj ):
    try :
        bbox =[Vector (corner )for corner in obj .bound_box ]
        if bbox :
            min_v =bbox [0 ].copy ()
            max_v =bbox [0 ].copy ()
            for co in bbox [1 :]:
                min_v .x =min (min_v .x ,co .x )
                min_v .y =min (min_v .y ,co .y )
                min_v .z =min (min_v .z ,co .z )
                max_v .x =max (max_v .x ,co .x )
                max_v .y =max (max_v .y ,co .y )
                max_v .z =max (max_v .z ,co .z )
            dims =max_v -min_v 
            ref =max (1e-8 ,(abs (dims .x )+abs (dims .y ))*0.5 )
            if ref >1e-8 :
                return ref 
    except Exception :
        pass 
    try :
        return max (1e-8 ,(abs (obj .dimensions .x )+abs (obj .dimensions .y ))*0.5 )
    except Exception :
        return 1.0 


def _line_factor (point ,start ,end ):
    delta =end -start 
    denom =delta .length_squared 
    if denom <=1e-20 :
        return 0.0 
    return (point -start ).dot (delta )/denom 


def _edge_meeting_point (edge_a ,edge_b ):
    result =geometry .intersect_line_line (edge_a .verts [0 ].co ,edge_a .verts [1 ].co ,edge_b .verts [0 ].co ,edge_b .verts [1 ].co )
    if result is None :
        return None ,None ,None ,None 
    pa ,pb =result 
    point =(pa +pb )*0.5 
    fa =_line_factor (pa ,edge_a .verts [0 ].co ,edge_a .verts [1 ].co )
    fb =_line_factor (pb ,edge_b .verts [0 ].co ,edge_b .verts [1 ].co )
    return point ,fa ,fb ,(pa -pb ).length 


def _edge_insert_or_use_endpoint (edge ,point ,fac ,epsilon =1e-6 ):
    if fac <=epsilon :
        vert =edge .verts [0 ]
        vert .co =point .copy ()
        return vert 
    if fac >=1.0 -epsilon :
        vert =edge .verts [1 ]
        vert .co =point .copy ()
        return vert 
    if fac <0.0 or fac >1.0 :
        return None 
    _new_edge ,new_vert =bmesh .utils .edge_split (edge ,edge .verts [0 ],fac )
    new_vert .co =point .copy ()
    return new_vert 


def _move_nearest_edge_endpoint (edge ,point ):
    vert =min (edge .verts ,key =lambda v :(v .co -point ).length_squared )
    vert .co =point .copy ()
    return vert 


def _collect_audit_from_bmesh (bm ,merge_dist ,obj_name =''):
    bm .verts .ensure_lookup_table ()
    bm .edges .ensure_lookup_table ()
    bm .faces .ensure_lookup_table ()
    bm .normal_update ()
    stats ={
    'name':obj_name ,
    'objects':1 ,
    'verts':len (bm .verts ),
    'edges':len (bm .edges ),
    'faces':len (bm .faces ),
    'non_manifold_edges':sum (1 for e in bm .edges if not e .is_manifold ),
    'loose_vertices':sum (1 for v in bm .verts if not v .link_edges ),
    'loose_edges':sum (1 for e in bm .edges if e .is_wire ),
    'ngons':sum (1 for f in bm .faces if len (f .verts )>4 ),
    'triangles':sum (1 for f in bm .faces if len (f .verts )==3 ),
    'degenerate_edges':sum (1 for e in bm .edges if (e .verts [0 ].co -e .verts [1 ].co ).length <=1e-9 ),
    'zero_area_faces':sum (1 for f in bm .faces if f .calc_area ()<=1e-12 ),
    'potential_doubles':0 ,
    }
    if merge_dist >0.0 and bm .verts :
        try :
            target_map =bmesh .ops .find_doubles (bm ,verts =list (bm .verts ),dist =merge_dist ).get ('targetmap',{})
            stats ['potential_doubles']=sum (1 for src ,dst in target_map .items ()if src !=dst )
        except Exception :
            pass 
    return stats 


def _collect_mesh_audit (obj ,merge_dist ):
    bm =bmesh .new ()
    try :
        bm .from_mesh (obj .data )
        return _collect_audit_from_bmesh (bm ,merge_dist ,obj .name )
    finally :
        bm .free ()


def _merge_audit_stats (stats_list ):
    merged ={
    'objects':len (stats_list ),
    'targets':[stats .get ('name','')for stats in stats_list if stats .get ('name')],
    'verts':0 ,
    'edges':0 ,
    'faces':0 ,
    'non_manifold_edges':0 ,
    'loose_vertices':0 ,
    'loose_edges':0 ,
    'ngons':0 ,
    'triangles':0 ,
    'degenerate_edges':0 ,
    'zero_area_faces':0 ,
    'potential_doubles':0 ,
    }
    for stats in stats_list :
        for key in ('verts','edges','faces','non_manifold_edges','loose_vertices','loose_edges','ngons','triangles','degenerate_edges','zero_area_faces','potential_doubles'):
            merged [key ]+=int (stats .get (key ,0 )or 0 )
    return merged 


def _format_audit_report (stats ,merge_dist ):
    names =', '.join (stats .get ('targets',[])[:3 ])
    if len (stats .get ('targets',[]))>3 :
        names +=', ...'
    lines =[
    f"{_t ('Objects')}: {stats .get ('objects',0 )}",
    ]
    if names :
        lines .append (f"{_t ('Targets')}: {names }")
    lines .extend ([
    f"{_t ('Vertices')}: {stats .get ('verts',0 )} | {_t ('Edges')}: {stats .get ('edges',0 )} | {_t ('Faces')}: {stats .get ('faces',0 )}",
    f"{_t ('Non-manifold Edges')}: {stats .get ('non_manifold_edges',0 )}",
    f"{_t ('Loose Vertices')}: {stats .get ('loose_vertices',0 )} | {_t ('Loose Edges')}: {stats .get ('loose_edges',0 )}",
    f"{_t ('Ngons')}: {stats .get ('ngons',0 )} | {_t ('Triangles')}: {stats .get ('triangles',0 )}",
    f"{_t ('Degenerate Edges')}: {stats .get ('degenerate_edges',0 )} | {_t ('Zero-area Faces')}: {stats .get ('zero_area_faces',0 )}",
    f"{_t ('Potential Doubles')} (≤ {merge_dist :.6g}): {stats .get ('potential_doubles',0 )}",
    ])
    return "\n".join (lines )


def _audit_targets_from_context (context ,merge_dist ):
    active =_active_mesh_object (context )
    if context .mode =='EDIT_MESH'and active is not None :
        bm =bmesh .from_edit_mesh (active .data )
        return _merge_audit_stats ([_collect_audit_from_bmesh (bm ,merge_dist ,active .name )])
    targets =[obj for obj in getattr (context ,'selected_objects',[])or []if obj and obj .type =='MESH']
    if not targets and active is not None :
        targets =[active ]
    return _merge_audit_stats ([_collect_mesh_audit (obj ,merge_dist )for obj in targets ])if targets else None 


def _selected_vertices_from_any_selection (bm ):
    verts ={v for v in bm .verts if v .select }
    for edge in bm .edges :
        if edge .select :
            verts .update (edge .verts )
    for face in bm .faces :
        if face .select :
            verts .update (face .verts )
    return list (verts )


def _axis_index (axis :str )->int :
    return {'X':0 ,'Y':1 ,'Z':2 }.get (str (axis or 'X').upper (),0 )


def _axis_vector (axis :str )->Vector :
    idx =_axis_index (axis )
    vec =[0.0 ,0.0 ,0.0 ]
    vec [idx ]=1.0 
    return Vector (vec )


def _slice_positions_from_verts (verts ,axis :str ,count :int ):
    if not verts :
        return []
    idx =_axis_index (axis )
    coords =[float (v .co [idx ])for v in verts ]
    lo =min (coords )
    hi =max (coords )
    span =hi -lo 
    if span <=1e-9 :
        return []
    count =max (1 ,int (count ))
    if count ==1 :
        return [lo +span *0.5 ]
    return [lo +span *((i +1 )/float (count +1 ))for i in range (count )]


def _clear_bmesh_selection (bm ):
    for seq in (bm .verts ,bm .edges ,bm .faces ):
        for elem in seq :
            try :
                elem .select =False 
            except Exception :
                pass 


def _set_mesh_select_mode (context ,*,vert =False ,edge =False ,face =False ):
    try :
        context .tool_settings .mesh_select_mode =(bool (vert ),bool (edge ),bool (face ))
    except Exception :
        pass 


def _repair_bmesh_in_place (bm ,merge_dist ):
    changes =0 
    bm .verts .ensure_lookup_table ()
    bm .edges .ensure_lookup_table ()
    bm .faces .ensure_lookup_table ()
    if merge_dist >0.0 and bm .verts :
        before =len (bm .verts )
        try :
            bmesh .ops .remove_doubles (bm ,verts =list (bm .verts ),dist =merge_dist )
            bm .verts .ensure_lookup_table ()
            changes +=max (0 ,before -len (bm .verts ))
        except Exception :
            pass 
    try :
        if bm .edges :
            bmesh .ops .dissolve_degenerate (bm ,dist =max (merge_dist ,1e-6 ),edges =list (bm .edges ))
    except Exception :
        pass 
    bm .verts .ensure_lookup_table ()
    bm .edges .ensure_lookup_table ()
    bm .faces .ensure_lookup_table ()
    zero_faces =[f for f in bm .faces if f .calc_area ()<=1e-12 ]
    if zero_faces :
        changes +=len (zero_faces )
        bmesh .ops .delete (bm ,geom =zero_faces ,context ='FACES')
    bm .verts .ensure_lookup_table ()
    bm .edges .ensure_lookup_table ()
    bm .faces .ensure_lookup_table ()
    wire_edges =[e for e in bm .edges if e .is_wire ]
    if wire_edges :
        changes +=len (wire_edges )
        bmesh .ops .delete (bm ,geom =wire_edges ,context ='EDGES')
    bm .verts .ensure_lookup_table ()
    bm .edges .ensure_lookup_table ()
    bm .faces .ensure_lookup_table ()
    loose_verts =[v for v in bm .verts if not v .link_edges ]
    if loose_verts :
        changes +=len (loose_verts )
        bmesh .ops .delete (bm ,geom =loose_verts ,context ='VERTS')
    try :
        if bm .faces :
            bmesh .ops .recalc_face_normals (bm ,faces =list (bm .faces ))
    except Exception :
        pass 
    return changes 


def _repair_object_mesh (obj ,merge_dist ):
    bm =bmesh .new ()
    try :
        bm .from_mesh (obj .data )
        changes =_repair_bmesh_in_place (bm ,merge_dist )
        bm .to_mesh (obj .data )
        obj .data .update ()
        return changes 
    finally :
        bm .free ()


def _repair_targets_from_context (context ,merge_dist ):
    active =_active_mesh_object (context )
    if context .mode =='EDIT_MESH'and active is not None :
        bm =bmesh .from_edit_mesh (active .data )
        changes =_repair_bmesh_in_place (bm ,merge_dist )
        bmesh .update_edit_mesh (active .data ,loop_triangles =True ,destructive =True )
        return changes 
    targets =[obj for obj in getattr (context ,'selected_objects',[])or []if obj and obj .type =='MESH']
    if not targets and active is not None :
        targets =[active ]
    changes =0 
    for obj in targets :
        changes +=_repair_object_mesh (obj ,merge_dist )
    return changes 


def _safe_register_class (cls ):
    try :
        bpy .utils .register_class (cls )
    except ValueError :
        pass 


def _safe_unregister_class (cls ):
    try :
        bpy .utils .unregister_class (cls )
    except Exception :
        pass 


def _matrix_from_loc_rot_scale (loc ,rot ,scale ):
    try :
        return Matrix .LocRotScale (loc ,rot ,scale )
    except Exception :
        return Matrix .Translation (loc )@rot .to_matrix ().to_4x4 ()@Matrix .Diagonal ((scale .x ,scale .y ,scale .z ,1.0 ))


class SMSP_Props (PropertyGroup ):
    workplane_use_cursor_pivot :BoolProperty (name ="Use Cursor Pivot",description ="After building the workplane, switch the transform pivot to the 3D cursor for immediate local editing.",default =True )
    workplane_use_cursor_orientation :BoolProperty (name ="Use Cursor Orientation",description ="After building the workplane, switch the active transform orientation to Cursor when supported.",default =True )
    project_offset :FloatProperty (name ="Project Offset",description ="Keep projected vertices slightly above or below the active plane.",default =0.0 ,soft_min =-10.0 ,soft_max =10.0 )
    path_count :IntProperty (name ="Path Count",description ="Number of instances to place along the active curve.",default =8 ,min =1 ,soft_max =1000 )
    path_include_ends :BoolProperty (name ="Include Ends",description ="Sample the first and last points of the path as placement positions.",default =True )
    path_follow_tangent :BoolProperty (name ="Follow Tangent",description ="Rotate instances so their local X axis follows the sampled path tangent.",default =True )
    path_random_roll_deg :FloatProperty (name ="Random Roll (deg)",description ="Maximum extra rotation around the path tangent.",default =0.0 ,min =0.0 ,soft_max =360.0 )
    path_linked_data :BoolProperty (name ="Linked Data",description ="Use linked object data instead of full data copies.",default =True )
    path_organize :BoolProperty (name ="Organize Path Instances",description ="Link generated path instances into a dedicated collection with a root empty.",default =True )
    objects_to_path_use_nearest :BoolProperty (name ="Use Nearest Chain",description ="Start from the active object, then order the remaining selected objects by nearest-neighbor distance so the generated path follows the placed layout more naturally.",default =True )
    objects_to_path_cyclic :BoolProperty (name ="Close Object Path",description ="Close the generated path so the last sampled object links back to the first.",default =False )
    vertices_to_path_use_nearest :BoolProperty (name ="Use Nearest Vertex Chain",description ="When converting selected vertices to a path, start from the active vertex when possible and order the remaining vertices by nearest-neighbor distance.",default =True )
    vertices_to_path_cyclic :BoolProperty (name ="Close Vertex Path",description ="Close the generated vertex path so the last sampled point links back to the first.",default =False )
    random_seed :IntProperty (name ="Random Seed",description ="Seed used for deterministic randomization.",default =1 ,min =0 ,soft_max =999999 )
    random_xy_offset :FloatProperty (name ="Random XY Offset",description ="Maximum extra random offset in X/Y for each selected object.",default =0.0 ,min =0.0 ,soft_max =100.0 )
    random_z_offset :FloatProperty (name ="Random Z Offset",description ="Maximum extra random offset in Z for each selected object.",default =0.0 ,min =0.0 ,soft_max =100.0 )
    random_z_rotation_deg :FloatProperty (name ="Random Z Rotation (deg)",description ="Maximum extra random Z rotation in degrees.",default =0.0 ,min =0.0 ,soft_max =360.0 )
    random_scale_min :FloatProperty (name ="Uniform Scale Min",description ="Minimum uniform scale multiplier.",default =1.0 ,min =0.001 ,soft_max =100.0 )
    random_scale_max :FloatProperty (name ="Uniform Scale Max",description ="Maximum uniform scale multiplier.",default =1.0 ,min =0.001 ,soft_max =100.0 )
    align_location :BoolProperty (name ="Align Location",description ="Match the selected objects' world-space location to the active object on the enabled axes.",default =True )
    align_rotation :BoolProperty (name ="Align Rotation",description ="Match the selected objects' world-space rotation to the active object.",default =False )
    align_scale :BoolProperty (name ="Align Scale",description ="Match the selected objects' world-space scale to the active object on the enabled axes.",default =False )
    align_axis_x :BoolProperty (name ="Affect X",description ="Enable X-axis alignment or distribution.",default =True )
    align_axis_y :BoolProperty (name ="Affect Y",description ="Enable Y-axis alignment or distribution.",default =True )
    align_axis_z :BoolProperty (name ="Affect Z",description ="Enable Z-axis alignment or distribution.",default =True )
    distribute_axis :EnumProperty (
    name ="Distribute Axis",
    description ="World axis used by Distribute Selected.",
    items =[
    ('X','X','Distribute along world X.'),
    ('Y','Y','Distribute along world Y.'),
    ('Z','Z','Distribute along world Z.'),
    ],
    default ='X',
    )
    stack_axis :EnumProperty (
    name ="Stack Axis",
    description ="World axis used by Stack Selected.",
    items =[
    ('X','X','Stack along world X.'),
    ('Y','Y','Stack along world Y.'),
    ('Z','Z','Stack along world Z.'),
    ],
    default ='X',
    )
    stack_gap :FloatProperty (name ="Stack Gap",description ="Extra gap inserted between stacked object bounds.",default =0.0 ,soft_min =-1000.0 ,soft_max =1000.0 )
    drop_to_floor_use_cursor_z :BoolProperty (name ="Use 3D Cursor Z",description ="Use the 3D cursor Z value as the target floor height instead of the manual Floor Z field.",default =True )
    drop_to_floor_z :FloatProperty (name ="Floor Z",description ="World-space floor height used by Drop To Floor when 3D Cursor Z is disabled.",default =0.0 ,soft_min =-10000.0 ,soft_max =10000.0 )
    quad_checker_filter :EnumProperty (
    name ="Quad Filter",
    description ="Choose which face type to select on the active edit mesh.",
    items =[
    ('NON_QUADS',"Non-Quads","Select every non-quad face."),
    ('QUADS',"Quads","Select every quad face."),
    ('TRIS',"Triangles","Select only triangles."),
    ('NGONS',"Ngons","Select only faces with 5 or more sides."),
    ],
    default ='NON_QUADS',
    )
    quad_checker_selected_only :BoolProperty (name ="Selected Faces Only",description ="When enabled, Quad Checker only inspects the currently selected faces. Disable it to inspect the whole active edit mesh.",default =False )
    replace_linked_data :BoolProperty (name ="Linked Data",description ="Use linked object data instead of full data copies.",default =True )
    replace_delete_targets :BoolProperty (name ="Delete Targets",description ="Remove target objects after the replacement copies are created.",default =True )
    replace_preserve_collections :BoolProperty (name ="Preserve Collections",description ="Link replacement objects into the same collections as the replaced targets.",default =True )
    surface_project_offset :FloatProperty (name ="Surface Project Offset",description ="Keep projected vertices slightly above or below the target surface.",default =0.0 ,soft_min =-10.0 ,soft_max =10.0 )
    conform_offset :FloatProperty (name ="Conform Offset",description ='Offset used by the shrinkwrap-based surface conform modifier. Useful for decals, kitbash panels, straps, and surface-mounted parts that should stay slightly above the target.',default =0.0 ,soft_min =-1.0 ,soft_max =1.0 )
    conform_method :EnumProperty (
    name ="Conform Method",
    description ='Shrinkwrap mode used by Surface Conform Modifier.',
    items =[
    ('NEAREST_SURFACEPOINT','Nearest Surface','Snap to the nearest point on the target surface'),
    ('PROJECT','Project','Project along target directions when supported'),
    ],
    default ='NEAREST_SURFACEPOINT',
    )
    conform_add_normals :BoolProperty (name ="Add Normal Transfer",description ='After surface conform, also add / update a Data Transfer modifier so custom normals follow the active source mesh.',default =True )
    normal_transfer_mix :FloatProperty (name ="Normal Mix",description ='Mix factor used by the created Data Transfer modifier.',default =1.0 ,min =0.0 ,max =1.0 )
    curve_rebuild_count :IntProperty (name ="Rebuild Count",description ="Number of sampled points used to rebuild the active curve.",default =24 ,min =2 ,soft_max =4096 )
    curve_rebuild_keep_original :BoolProperty (name ="Keep Original",description ="Create a rebuilt duplicate instead of overwriting the active curve object data.",default =True )
    loft_sample_count :IntProperty (name ="Loft Samples",description ="Number of sampled points used when lofting between two paths.",default =24 ,min =2 ,soft_max =2048 )
    loft_shade_smooth :BoolProperty (name ="Shade Smooth Loft",description ="Enable smooth shading on the generated loft mesh.",default =True )
    profile_primitive_type :EnumProperty (
    name ="Profile Type",
    description ="Choose which reusable 2D curve profile to create at the 3D cursor.",
    items =[
    ('CIRCLE','Circle',''),
    ('RECTANGLE','Rectangle',''),
    ('NGON','N-gon',''),
    ('STAR','Star',''),
    ],
    default ='CIRCLE',
    )
    profile_width :FloatProperty (name ="Profile Width",description ="Overall width of the generated profile primitive. Circle and N-gon types use this as the X diameter.",default =0.25 ,min =0.0001 ,soft_max =100.0 )
    profile_height :FloatProperty (name ="Profile Height",description ="Overall height of the generated profile primitive. Circle and N-gon types use this as the Y diameter.",default =0.25 ,min =0.0001 ,soft_max =100.0 )
    profile_points :IntProperty (name ="Profile Points",description ="Point count used for circle, N-gon, and star profile generation.",default =16 ,min =3 ,soft_max =256 )
    profile_star_inner :FloatProperty (name ="Star Inner Ratio",description ="Inner radius ratio used when the profile type is Star.",default =0.5 ,min =0.01 ,max =0.99 )
    helix_radius :FloatProperty (name ="Helix Radius",description ="Base radius of the generated helix path.",default =0.25 ,min =0.0001 ,soft_max =100.0 )
    helix_height :FloatProperty (name ="Helix Height",description ="Total height of the generated helix path.",default =1.0 ,min =0.0001 ,soft_max =1000.0 )
    helix_turns :FloatProperty (name ="Helix Turns",description ="Number of turns used by the generated helix path. Fractional values are allowed.",default =3.0 ,min =0.05 ,soft_max =100.0 )
    helix_points_per_turn :IntProperty (name ="Points / Turn",description ="Number of sampled points used for each helix turn. Higher values create a smoother path.",default =24 ,min =3 ,soft_max =512 )
    helix_taper :FloatProperty (name ="Helix Taper",description ="Change the end radius relative to the start radius. Negative values tighten the spiral; positive values widen it.",default =0.0 ,soft_min =-0.95 ,soft_max =4.0 )
    helix_clockwise :BoolProperty (name ="Clockwise",description ="Generate the helix in clockwise direction around the local Z axis.",default =False )
    sweep_duplicate_path :BoolProperty (name ="Duplicate Path",description ="Create a duplicated path object before adding the Sweep modifier, so the original path remains unchanged.",default =True )
    sweep_fill_caps :BoolProperty (name ="Sweep Fill Caps",description ="Close the open ends of the generated Sweep mesh.",default =True )
    sweep_resolution_u :IntProperty (name ="Sweep Resolution",description ="Evaluation resolution used inside the Sweep modifier without changing the source path curve.",default =12 ,min =1 ,soft_max =128 )
    sweep_x_offset :FloatProperty (name ="Sweep X Offset",description ="Offset the profile along its local X axis.",default =0.0 )
    sweep_y_offset :FloatProperty (name ="Sweep Y Offset",description ="Offset the profile along its local Y axis.",default =0.0 )
    sweep_angle :FloatProperty (name ="Sweep Angle",description ="Rotate the profile around its local Z axis.",default =0.0 ,subtype ='ANGLE',unit ='ROTATION')
    sweep_mirror_x :BoolProperty (name ="Mirror Sweep X",description ="Mirror the profile across its local X axis.",default =False )
    sweep_mirror_y :BoolProperty (name ="Mirror Sweep Y",description ="Mirror the profile across its local Y axis.",default =False )
    symmetry_direction :EnumProperty (
    name ="Symmetry Direction",
    description ="Axis and source side used by the symmetry operator.",
    items =[
    ('NEGATIVE_X','-X to +X',''),
    ('POSITIVE_X','+X to -X',''),
    ('NEGATIVE_Y','-Y to +Y',''),
    ('POSITIVE_Y','+Y to -Y',''),
    ('NEGATIVE_Z','-Z to +Z',''),
    ('POSITIVE_Z','+Z to -Z',''),
    ],
    default ='NEGATIVE_X',
    )
    symmetry_merge_threshold :FloatProperty (name ="Symmetry Merge Threshold",description ="Merge threshold used by symmetry operations.",default =0.0001 ,min =0.0 ,soft_max =1.0 )
    symmetry_use_modifier :BoolProperty (name ="Object Mode = Mirror Modifier",description ="In Object Mode, create or reuse a Mirror modifier instead of doing a destructive edit operation.",default =True )
    symmetry_clip :BoolProperty (name ="Mirror Clip",description ="Enable clipping on the created Mirror modifier to keep the center seam closed.",default =True )
    face_component_selected_faces_only :BoolProperty (name ="Selected Faces Only",description ="If the target mesh stores selected polygons, use only those faces. Otherwise all faces are used.",default =True )
    face_component_scale_to_face :BoolProperty (name ="Scale To Face",description ="Uniformly scale each placed component by the square-root of the target face area.",default =True )
    face_component_scale :FloatProperty (name ="Component Scale",description ="Additional uniform multiplier applied after face-based scaling.",default =1.0 ,min =0.0001 ,soft_max =100.0 )
    face_component_offset :FloatProperty (name ="Face Offset",description ="Offset the placed component along the target face normal.",default =0.0 ,soft_min =-10.0 ,soft_max =10.0 )
    face_component_linked_data :BoolProperty (name ="Linked Data",description ="Use linked mesh data for each placed component instead of making full data copies.",default =True )
    cad_mode :EnumProperty (
    name ="CAD Mode",
    description ="Choose whether to insert an intersection point or extend the selected endpoints to the resolved meeting point.",
    items =[
    ('INTERSECT','Insert Intersection',''),
    ('EXTEND','Extend Endpoints',''),
    ],
    default ='INTERSECT',
    )
    audit_merge_distance :FloatProperty (name ="Audit Merge Distance",description ="Distance used for potential double detection and for the conservative merge-by-distance repair step.",default =0.0001 ,min =0.0 ,soft_max =1.0 )
    audit_report :StringProperty (name ="Last Audit Report",description ="Stores the latest compact mesh audit summary for display in the panel.",default ="")
    audit_issue_filter :EnumProperty (
    name ="Issue Filter",
    description ="Choose which audit issue type should be selected on the active mesh.",
    items =[
    ('NON_MANIFOLD','Non-manifold','Select non-manifold edges on the active mesh.'),
    ('LOOSE','Loose Geometry','Select loose vertices and wire edges on the active mesh.'),
    ('NGONS','Ngons','Select ngon faces on the active mesh.'),
    ('TRIANGLES','Triangles','Select triangle faces on the active mesh.'),
    ('DEGENERATE','Degenerate Edges','Select zero-length or near-zero-length edges on the active mesh.'),
    ('ZERO_AREA','Zero-area Faces','Select zero-area faces on the active mesh.'),
    ('DOUBLES','Potential Doubles','Select vertices that look like double candidates within the configured audit merge distance.'),
    ],
    default ='NON_MANIFOLD',
    )
    axis_slice_axis :EnumProperty (
    name ="Slice Axis",
    description ="Local axis used by Axis Slice Edit when creating evenly spaced bisect planes.",
    items =[('X','X',''),('Y','Y',''),('Z','Z','')],
    default ='X',
    )
    axis_slice_count :IntProperty (name ="Slice Count",description ="Number of evenly spaced slice planes inserted between the local minimum and maximum bounds.",default =1 ,min =1 ,soft_max =128 )
    axis_slice_use_selection_bounds :BoolProperty (name ="Use Selection Bounds",description ="When enabled, Axis Slice Edit derives the slice range from the current selection when possible. The cuts still pass through the mesh like a numeric slice helper.",default =True )
    axis_slice_select_new :BoolProperty (name ="Select New Cuts",description ="Select the newly generated cut edges after Axis Slice Edit runs.",default =True )
    axis_slice_tolerance :FloatProperty (name ="Slice Tolerance",description ="Distance tolerance used by Axis Slice Edit when resolving plane/mesh intersections.",default =0.0001 ,min =0.0 ,soft_max =1.0 )



def _editable_object_data_transform (obj ,local_delta :Vector )->bool :
    data =getattr (obj ,'data',None )
    if data is None or not hasattr (data ,'transform'):
        return False 
    try :
        data .transform (Matrix .Translation (-local_delta ))
        if hasattr (data ,'update'):
            data .update ()
        return True 
    except Exception :
        return False 



def _set_object_origin_world (obj ,target_world :Vector )->bool :
    if obj is None :
        return False 
    try :
        current_world =obj .matrix_world .translation .copy ()
        delta_world =Vector (target_world )-current_world 
    except Exception :
        return False 
    try :
        delta_local =obj .matrix_world .inverted_safe ().to_3x3 ()@delta_world 
    except Exception :
        try :
            delta_local =Vector (delta_world )
        except Exception :
            return False 
    obj_type =str (getattr (obj ,'type','')or '')
    if obj_type !='EMPTY'and not _editable_object_data_transform (obj ,delta_local ):
        return False 
    try :
        mw =obj .matrix_world .copy ()
        mw .translation =Vector (target_world )
        obj .matrix_world =mw 
    except Exception :
        try :
            obj .location =Vector (target_world )
        except Exception :
            return False 
    return True 



def _selection_center_world_from_edit_mesh (obj ):
    if obj is None or getattr (obj ,'type',None )!='MESH':
        return None 
    try :
        bm =bmesh .from_edit_mesh (obj .data )
    except Exception :
        return None 
    verts =_selected_vertices_from_any_selection (bm )
    if not verts :
        return None 
    try :
        center_local =sum ((v .co .copy ()for v in verts ),Vector ((0.0 ,0.0 ,0.0 )))/float (len (verts ))
    except Exception :
        return None 
    try :
        return obj .matrix_world @center_local 
    except Exception :
        return None 



def _bottom_center_world_from_bounds (obj ):
    if obj is None :
        return None 
    corners =[]
    try :
        for co in getattr (obj ,'bound_box',[])or []:
            corners .append (obj .matrix_world @Vector (co ))
    except Exception :
        corners =[]
    if not corners :
        try :
            return obj .matrix_world .translation .copy ()
        except Exception :
            return None 
    min_x =min (v .x for v in corners )
    max_x =max (v .x for v in corners )
    min_y =min (v .y for v in corners )
    max_y =max (v .y for v in corners )
    min_z =min (v .z for v in corners )
    return Vector (((min_x +max_x )*0.5 ,(min_y +max_y )*0.5 ,min_z ))


def _axis_bounds_world (obj ,axis_index :int ):
    if obj is None :
        return None 
    coords =[]
    try :
        for co in getattr (obj ,'bound_box',[])or []:
            coords .append (obj .matrix_world @Vector (co ))
    except Exception :
        coords =[]
    if coords :
        values =[float (v [axis_index ])for v in coords ]
        return min (values ),max (values )
    try :
        value =float (obj .matrix_world .translation [axis_index ])
        return value ,value 
    except Exception :
        return None 


BoolProperty = _BpyBoolProperty
EnumProperty = _BpyEnumProperty
FloatProperty = _BpyFloatProperty
IntProperty = _BpyIntProperty
PointerProperty = _BpyPointerProperty
StringProperty = _BpyStringProperty

class SMSP_OT_stack_selected (Operator ):
    bl_idname ="smsp.stack_selected"
    bl_label ="Stack Selected"
    bl_description ="Stack selected objects one after another along the chosen world axis using their world-space bounds plus a configurable gap. Useful for shelf dressing, prop lineup, packing previews, and quick contact-free layout stacking."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        selected =[o for o in getattr (context ,'selected_objects',[])or []if o ]
        return context .mode =='OBJECT'and len (selected )>=2 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        selected =[o for o in getattr (context ,'selected_objects',[])or []if o ]
        if len (selected )<2 :
            self .report ({'WARNING'},_t ("Select at least two objects to stack"))
            return {'CANCELLED'}
        axis =str (getattr (props ,'stack_axis','X')or 'X').upper ()
        axis_index ={'X':0 ,'Y':1 ,'Z':2 }.get (axis ,0 )
        gap =float (getattr (props ,'stack_gap',0.0 )or 0.0 )

        ordered =[]
        for obj in selected :
            bounds =_axis_bounds_world (obj ,axis_index )
            if bounds is None :
                continue 
            center =(bounds [0 ]+bounds [1 ])*0.5 
            ordered .append ((center ,obj ,bounds ))
        if len (ordered )<2 :
            self .report ({'WARNING'},_t ("Select at least two objects to stack"))
            return {'CANCELLED'}
        ordered .sort (key =lambda item :item [0 ])

        moved =0 
        prev_max =ordered [0 ][2 ][1 ]
        for _center ,obj ,bounds in ordered [1 :]:
            current_min ,current_max =bounds 
            delta =(prev_max +gap )-current_min 
            try :
                mw =obj .matrix_world .copy ()
                loc =mw .translation .copy ()
                loc [axis_index ]+=delta 
                mw .translation =loc 
                obj .matrix_world =mw 
                moved +=1 
                prev_max =current_max +delta 
            except Exception :
                prev_max =current_max 
                continue 
        if moved <=0 :
            self .report ({'WARNING'},_t ("Select at least two objects to stack"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Stacked selected objects along the chosen axis"))
        return {'FINISHED'}


class SMSP_OT_align_to_active (Operator ):
    bl_idname ="smsp.align_to_active"
    bl_label ="Align To Active"
    bl_description ="Align the selected objects to the active object using per-channel toggles for location, rotation, and scale. Useful for 3ds Max style align workflows, layout cleanup, and archviz placement passes."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        active =getattr (context ,'active_object',None )
        selected =[o for o in getattr (context ,'selected_objects',[])or []if o ]
        return context .mode =='OBJECT'and active is not None and len (selected )>=2 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        active =getattr (context ,'active_object',None )
        targets =[o for o in getattr (context ,'selected_objects',[])or []if o and o !=active ]
        if active is None or not targets :
            self .report ({'WARNING'},_t ("Need an active source object plus at least one other selected object"))
            return {'CANCELLED'}
        if not (props .align_location or props .align_rotation or props .align_scale ):
            self .report ({'WARNING'},_t ("Enable at least one of location, rotation, or scale alignment"))
            return {'CANCELLED'}
        axes =[bool (props .align_axis_x ),bool (props .align_axis_y ),bool (props .align_axis_z )]
        if not any (axes ):
            self .report ({'WARNING'},_t ("Enabled at least one axis is required"))
            return {'CANCELLED'}

        active_loc ,active_rot ,active_scale =active .matrix_world .decompose ()
        moved =0 
        for obj in targets :
            try :
                loc ,rot ,scale =obj .matrix_world .decompose ()
                if props .align_location :
                    loc =Vector ((active_loc .x if axes [0 ]else loc .x ,active_loc .y if axes [1 ]else loc .y ,active_loc .z if axes [2 ]else loc .z ))
                if props .align_rotation :
                    rot =active_rot .copy ()
                if props .align_scale :
                    scale =Vector ((active_scale .x if axes [0 ]else scale .x ,active_scale .y if axes [1 ]else scale .y ,active_scale .z if axes [2 ]else scale .z ))
                obj .matrix_world =_matrix_from_loc_rot_scale (loc ,rot ,scale )
                moved +=1 
            except Exception :
                continue 
        if moved ==0 :
            self .report ({'WARNING'},_t ("Need an active source object plus at least one other selected object"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Aligned selected objects to the active object"))
        return {'FINISHED'}


class SMSP_OT_distribute_selected_axis (Operator ):
    bl_idname ="smsp.distribute_selected_axis"
    bl_label ="Distribute Selected"
    bl_description ="Evenly distribute selected object origins between the current minimum and maximum positions on the chosen world axis. Useful for shelf dressing, facade spacing, modular blocking, and quick layout cleanup."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        selected =[o for o in getattr (context ,'selected_objects',[])or []if o ]
        return context .mode =='OBJECT'and len (selected )>=3 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        selected =[o for o in getattr (context ,'selected_objects',[])or []if o ]
        if len (selected )<3 :
            self .report ({'WARNING'},_t ("Select at least three objects to distribute"))
            return {'CANCELLED'}
        axis =str (getattr (props ,'distribute_axis','X')or 'X').upper ()
        axis_index ={'X':0 ,'Y':1 ,'Z':2 }.get (axis ,0 )
        ordered =sorted (selected ,key =lambda o :float (o .matrix_world .translation [axis_index ]))
        min_val =float (ordered [0 ].matrix_world .translation [axis_index ])
        max_val =float (ordered [-1 ].matrix_world .translation [axis_index ])
        step =0.0 if len (ordered )<=1 else (max_val -min_val )/float (len (ordered )-1 )
        moved =0 
        for index ,obj in enumerate (ordered ):
            try :
                mw =obj .matrix_world .copy ()
                loc =mw .translation .copy ()
                loc [axis_index ]=min_val +(step *index )
                mw .translation =loc 
                obj .matrix_world =mw 
                moved +=1 
            except Exception :
                continue 
        if moved ==0 :
            self .report ({'WARNING'},_t ("Select at least three objects to distribute"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Distributed selected objects evenly on the chosen axis"))
        return {'FINISHED'}


class SMSP_OT_pivot_to_selection (Operator ):
    bl_idname ="smsp.pivot_to_selection"
    bl_label ="Pivot To Selection"
    bl_description ="Move the active mesh object's origin to the center of the current edit selection without changing the visible shape. Useful for local bend / twist control, kitbash pivots, and temporary action-center style edits."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}
        target_world =_selection_center_world_from_edit_mesh (obj )
        if target_world is None :
            self .report ({'WARNING'},_t ("Need selected mesh components on the active object"))
            return {'CANCELLED'}
        state =capture_object_context (context )
        if not ensure_object_mode (context ,obj ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        ok =_set_object_origin_world (obj ,target_world )
        restore_object_context (context ,state ,fallback_active =obj )
        if not ok :
            self .report ({'WARNING'},_t ("Operation failed"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Pivot moved to the current selection center"))
        return {'FINISHED'}


class SMSP_OT_pivot_to_bottom (Operator ):
    bl_idname ="smsp.pivot_to_bottom"
    bl_label ="Pivot To Bottom"
    bl_description ="Move each selected object's origin to the world-space bottom center of its bounds without changing the visible shape. Useful for layout, DropIt-style dressing, stacking, and easier floor placement."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return bool (getattr (context ,'selected_objects',[])or [])

    def execute (self ,context ):
        selected =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj is not None ]
        if not selected :
            self .report ({'WARNING'},_t ("Select one or more objects"))
            return {'CANCELLED'}
        active =getattr (context ,'active_object',None )
        state =capture_object_context (context )
        if not ensure_object_mode (context ,active ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        processed =0 
        for obj in selected :
            target_world =_bottom_center_world_from_bounds (obj )
            if target_world is None :
                continue 
            if _set_object_origin_world (obj ,target_world ):
                processed +=1 
        restore_object_context (context ,state ,fallback_active =active )
        if processed <=0 :
            self .report ({'WARNING'},_t ("Operation failed"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Pivot moved to object bottom bounds"))
        return {'FINISHED'}


class SMSP_OT_drop_to_floor (Operator ):
    bl_idname ="smsp.drop_to_floor"
    bl_label ="Drop To Floor"
    bl_description ="Drop selected objects vertically so their world-space bounds sit on a shared floor height. Useful for DropToFloor style layout cleanup, shelf dressing, and zero-target placement prep."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return bool (getattr (context ,'selected_objects',[])or [])

    def execute (self ,context ):
        selected =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj is not None ]
        if not selected :
            self .report ({'WARNING'},_t ("Select one or more objects"))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        floor_z =context .scene .cursor .location .z if bool (getattr (props ,'drop_to_floor_use_cursor_z',True ))else float (getattr (props ,'drop_to_floor_z',0.0 ))
        active =getattr (context ,'active_object',None )
        state =capture_object_context (context )
        if not ensure_object_mode (context ,active ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        moved =0 
        for obj in selected :
            bottom =_bottom_center_world_from_bounds (obj )
            if bottom is None :
                continue 
            target =Vector ((obj .matrix_world .translation .x ,obj .matrix_world .translation .y ,obj .matrix_world .translation .z +(floor_z -bottom .z )))
            try :
                obj .location .z +=(floor_z -bottom .z )
                moved +=1 
            except Exception :
                try :
                    mw =obj .matrix_world .copy ()
                    mw .translation .z +=(floor_z -bottom .z )
                    obj .matrix_world =mw 
                    moved +=1 
                except Exception :
                    pass 
        restore_object_context (context ,state ,fallback_active =active )
        if moved <=0 :
            self .report ({'WARNING'},_t ("Operation failed"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Dropped selected objects to floor height"))
        return {'FINISHED'}


class SMSP_OT_quad_checker (Operator ):
    bl_idname ="smsp.quad_checker"
    bl_label ="Quad Checker"
    bl_description ="Select quads, non-quads, triangles, or ngons on the active edit mesh for fast topology inspection before subdivision, export, bevel, or retopo cleanup."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        candidates =list (bm .faces )
        if bool (getattr (props ,'quad_checker_selected_only',False )):
            sel_faces =[f for f in bm .faces if f .select ]
            if sel_faces :
                candidates =sel_faces 
        mode =str (getattr (props ,'quad_checker_filter','NON_QUADS')or 'NON_QUADS')
        def _match (face ):
            n =len (face .verts )
            if mode =='QUADS':
                return n ==4 
            if mode =='TRIS':
                return n ==3 
            if mode =='NGONS':
                return n >=5 
            return n !=4 
        matches =[f for f in candidates if _match (f )]
        if not matches :
            # Nothing to report on: keep the user's selection as it was.
            self .report ({'INFO'},_t ("No matching faces were found"))
            return {'CANCELLED'}
        for f in bm .faces :
            f .select =False 
        matched =0 
        for f in matches :
            f .select =True 
            matched +=1 
        try :
            bm .faces .active =matches [0 ]
        except Exception :
            pass 
        bmesh .update_edit_mesh (obj .data ,loop_triangles =False ,destructive =False )
        self .report ({'INFO'},f"{_t ('Quad Checker selected matching faces')}: {matched }")
        return {'FINISHED'}


class SMSP_OT_workplane_from_active (Operator ):
    bl_idname ="smsp.workplane_from_active"
    bl_label ="Workplane From Active"
    bl_description ="Build a cursor-based local workplane from the active face or selected edge. Useful for Modo-style Workplane / Action Center style editing on angled surfaces."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        face ,edge =_extract_active_face_or_edge (bm )
        if face is None and edge is None :
            self .report ({'WARNING'},_t ("Need an active face or a selected edge"))
            return {'CANCELLED'}
        if face is not None :
            center_local =face .calc_center_median ()
            normal_local =face .normal .copy ()
            longest =None 
            longest_len =-1.0 
            for e in face .edges :
                vec =e .verts [1 ].co -e .verts [0 ].co 
                if vec .length >longest_len :
                    longest =vec .copy ()
                    longest_len =vec .length 
            tangent_local =longest if longest is not None else normal_local .orthogonal ()
        else :
            v0 ,v1 =edge .verts 
            center_local =(v0 .co +v1 .co )*0.5 
            tangent_local =(v1 .co -v0 .co )
            normal_local =Vector ((0.0 ,0.0 ,0.0 ))
            for lf in edge .link_faces :
                normal_local +=lf .normal 
            if normal_local .length <1e-12 :
                normal_local =Vector ((0.0 ,0.0 ,1.0 ))
        mw3 =obj .matrix_world .to_3x3 ()
        center_world =obj .matrix_world @center_local 
        normal_world =(mw3 @normal_local ).normalized ()
        tangent_world =(mw3 @tangent_local ).normalized ()
        matrix =_orientation_matrix_from_vectors (center_world ,normal_world ,tangent_world )
        cursor =context .scene .cursor 
        try :
            cursor .matrix =matrix 
        except Exception :
            try :
                cursor .location =matrix .translation 
                quat =matrix .to_quaternion ()
                cursor .rotation_mode ='QUATERNION'
                cursor .rotation_quaternion =quat 
            except Exception :
                pass 
        try :
            if props .workplane_use_cursor_pivot :
                context .scene .tool_settings .transform_pivot_point ='CURSOR'
        except Exception :
            pass 
        try :
            if props .workplane_use_cursor_orientation :
                context .scene .transform_orientation_slots [0 ].type ='CURSOR'
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Workplane ready"))
        return {'FINISHED'}


class SMSP_OT_project_to_active_plane (Operator ):
    bl_idname ="smsp.project_to_active_plane"
    bl_label ="Project To Active Plane"
    bl_description ="Project selected vertices onto the active face plane with an optional offset. Useful for projection modeling, CAD-like flattening, and keeping panel details flush to a surface."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        face ,_edge =_extract_active_face_or_edge (bm )
        if face is None :
            self .report ({'WARNING'},_t ("Need an active face or a selected edge"))
            return {'CANCELLED'}
        origin =face .calc_center_median ().copy ()
        normal =face .normal .normalized ()
        selected_verts =[v for v in bm .verts if v .select ]
        if not selected_verts :
            selected_verts =list (face .verts )
        for v in selected_verts :
            dist =(v .co -origin ).dot (normal )
            v .co =v .co -normal *dist +normal *props .project_offset 
        bmesh .update_edit_mesh (obj .data ,loop_triangles =False ,destructive =False )
        self .report ({'INFO'},_t ("Projected selected vertices to the active plane"))
        return {'FINISHED'}


class SMSP_OT_instances_along_path (Operator ):
    bl_idname ="smsp.instances_along_path"
    bl_label ="Instances Along Path"
    bl_description ="Scatter linked copies of the selected source objects along the active curve using even distance sampling. Useful for Duplicate Along Path, MASH-style path layouts, trims, railing, and RailClone-like path-driven blocking."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_curve_object (context )is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        curve =_active_curve_object (context )
        props =context .scene .smsp_props 
        if curve is None or context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Active curve and at least one source object are required"))
            return {'CANCELLED'}
        sources =[o for o in context .selected_objects if o and o !=curve ]
        if not sources :
            self .report ({'WARNING'},_t ("Active curve and at least one source object are required"))
            return {'CANCELLED'}
        depsgraph =context .evaluated_depsgraph_get ()
        points =_curve_to_longest_polyline_world (curve ,depsgraph )
        if len (points )<2 :
            self .report ({'WARNING'},_t ("Failed to evaluate a usable path from the active curve"))
            return {'CANCELLED'}
        samples =_sample_polyline (points ,props .path_count ,props .path_include_ends )
        if not samples :
            self .report ({'WARNING'},_t ("Failed to evaluate a usable path from the active curve"))
            return {'CANCELLED'}
        rng =random .Random (hash ((curve .name ,props .path_count ,props .path_random_roll_deg ))&0xFFFFFFFF )
        target_col =None 
        root_empty =None 
        if props .path_organize :
            owner ="instances_along_path"
            target_col ,_target_col_created =_ensure_owned_collection (context ,f"SMS_Path_{curve .name }",owner )
            root_empty =bpy .data .objects .new (_unique_name (set (bpy .data .objects .keys ()),f"SMS_PathRoot_{curve .name }"),None )
            root_empty [_SMS_FACTORY_OWNER_KEY ]=owner 
            root_empty .empty_display_type ='PLAIN_AXES'
            _link_object_to_collection (root_empty ,target_col )
        created =[]
        for idx ,(point ,tangent )in enumerate (samples ):
            src =sources [idx %len (sources )]
            inst =src .copy ()
            try :
                if getattr (src ,'data',None )is not None :
                    inst .data =src .data if props .path_linked_data else src .data .copy ()
            except Exception :
                pass 
            try :
                inst .animation_data_clear ()
            except Exception :
                pass 
            if target_col is not None :
                _link_object_to_collection (inst ,target_col )
                try :
                    inst .parent =root_empty 
                except Exception :
                    pass 
            else :
                _link_to_same_collections (inst ,src ,context )
            _loc ,rot ,scale =src .matrix_world .decompose ()
            if props .path_follow_tangent and tangent .length >1e-12 :
                rot =tangent .normalized ().to_track_quat ('X','Z')
                if props .path_random_roll_deg >0.0 :
                    roll =math .radians (rng .uniform (-props .path_random_roll_deg ,props .path_random_roll_deg ))
                    rot =Quaternion (tangent .normalized (),roll )@rot 
            inst .location =point 
            inst .rotation_mode ='QUATERNION'
            inst .rotation_quaternion =rot 
            inst .scale =scale 
            created .append (inst )
        try :
            safe_select_all ('DESELECT')
            for obj in created :
                obj .select_set (True )
            if created :
                context .view_layer .objects .active =created [0 ]
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Created instances along the active path"))
        return {'FINISHED'}


class SMSP_OT_replace_with_active (Operator ):
    bl_idname ="smsp.replace_with_active"
    bl_label ="Replace With Active"
    bl_description ="Replace the selected target objects with copies of the active object while preserving each target transform. Useful for instance replacement, kitbash swaps, and proxy-to-final workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return getattr (context ,'active_object',None )is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        source =context .active_object 
        props =context .scene .smsp_props 
        targets =[o for o in context .selected_objects if o and o !=source ]
        if not targets :
            self .report ({'WARNING'},_t ("Select at least one target besides the active source object"))
            return {'CANCELLED'}
        created =[]
        for tgt in targets :
            new_obj =source .copy ()
            try :
                if getattr (source ,'data',None )is not None :
                    new_obj .data =source .data if props .replace_linked_data else source .data .copy ()
            except Exception :
                pass 
            try :
                new_obj .animation_data_clear ()
            except Exception :
                pass 
            if props .replace_preserve_collections :
                _link_to_same_collections (new_obj ,tgt ,context )
            else :
                _link_object_to_collection (new_obj ,context .scene .collection )
            try :
                new_obj .matrix_world =tgt .matrix_world .copy ()
            except Exception :
                pass 
            created .append (new_obj )
        if props .replace_delete_targets :
            for tgt in targets :
                try :
                    bpy .data .objects .remove (tgt ,do_unlink =True )
                except Exception :
                    pass 
        try :
            safe_select_all ('DESELECT')
            for obj in created :
                obj .select_set (True )
            if created :
                context .view_layer .objects .active =created [0 ]
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Replacement complete"))
        return {'FINISHED'}


class SMSP_OT_randomize_selected (Operator ):
    bl_idname ="smsp.randomize_selected"
    bl_label ="Randomize Selected"
    bl_description ="Apply controlled random location / rotation / uniform scale variation to the selected objects for faster environment dressing and layout iteration."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='OBJECT'and bool (context .selected_objects )

    def execute (self ,context ):
        props =context .scene .smsp_props 
        selected =[o for o in context .selected_objects if o ]
        if not selected :
            self .report ({'WARNING'},_t ("Select at least one object to randomize"))
            return {'CANCELLED'}
        rng =random .Random (props .random_seed )
        scale_min =min (props .random_scale_min ,props .random_scale_max )
        scale_max =max (props .random_scale_min ,props .random_scale_max )
        for obj in selected :
            try :
                delta =Vector ((
                rng .uniform (-props .random_xy_offset ,props .random_xy_offset ),
                rng .uniform (-props .random_xy_offset ,props .random_xy_offset ),
                rng .uniform (-props .random_z_offset ,props .random_z_offset ),
                ))
                obj .location +=delta 
            except Exception :
                pass 
            try :
                rot =Euler ((0.0 ,0.0 ,math .radians (rng .uniform (-props .random_z_rotation_deg ,props .random_z_rotation_deg ))),'XYZ')
                if obj .rotation_mode =='QUATERNION':
                    obj .rotation_quaternion =rot .to_quaternion ()@obj .rotation_quaternion 
                else :
                    if obj .rotation_mode not in {'XYZ','XZY','YXZ','YZX','ZXY','ZYX'}:
                        obj .rotation_mode ='XYZ'
                    eul =obj .rotation_euler .copy ()
                    eul .rotate (rot )
                    obj .rotation_euler =eul 
            except Exception :
                pass 
            try :
                s =rng .uniform (scale_min ,scale_max )
                obj .scale *=s 
            except Exception :
                pass 
        self .report ({'INFO'},_t ("Randomize complete"))
        return {'FINISHED'}


class SMSP_OT_project_to_selected_surface (Operator ):
    bl_idname ="smsp.project_to_selected_surface"
    bl_label ="Project To Selected Surface"
    bl_description ="Project selected vertices of the active mesh onto the nearest points of another selected mesh. Useful for retopo, shrinkwrap-style cleanup, panel wrapping, and keeping blockout strips glued to a target surface."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'and _other_selected_mesh_object (context )is not None 

    def execute (self ,context ):
        source =_active_mesh_object (context )
        target =_other_selected_mesh_object (context )
        props =context .scene .smsp_props 
        if source is None or context .mode !='EDIT_MESH'or target is None :
            self .report ({'WARNING'},_t ("Need another selected target mesh besides the active source mesh"))
            return {'CANCELLED'}

        bm =bmesh .from_edit_mesh (source .data )
        verts =[v for v in bm .verts if v .select ]
        if not verts :
            self .report ({'WARNING'},_t ("Select at least one vertex to project"))
            return {'CANCELLED'}

        depsgraph =context .evaluated_depsgraph_get ()
        source_inv =source .matrix_world .inverted ()
        target_m3 =target .matrix_world .to_3x3 ()
        moved =0 

        for vert in verts :
            world_co =source .matrix_world @vert .co 
            hit ,loc_local ,nor_local ,_face_index =_closest_point_on_mesh_safe (target ,depsgraph ,world_co )
            if not hit or loc_local is None :
                continue 
            loc_world =target .matrix_world @loc_local 
            try :
                nor_world =(target_m3 @nor_local ).normalized ()
            except Exception :
                nor_world =Vector ((0.0 ,0.0 ,1.0 ))
            loc_world =loc_world +nor_world *props .surface_project_offset 
            vert .co =source_inv @loc_world 
            moved +=1 

        bmesh .update_edit_mesh (source .data ,loop_triangles =False ,destructive =False )
        if moved ==0 :
            self .report ({'WARNING'},_t ("No valid surface hit was found for the selected vertices on the target mesh"))
            return {'CANCELLED'}
        self .report ({'INFO'},_t ("Projected selected vertices to the selected target surface"))
        return {'FINISHED'}


class SMSP_OT_rebuild_active_curve (Operator ):
    bl_idname ="smsp.rebuild_active_curve"
    bl_label ="Rebuild Active Curve"
    bl_description ="Resample the active curve into a cleaner evenly spaced poly spline. Useful for MoI/ CAD-style curve rebuild workflows before pipes, sweeps, and path arrays."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_curve_object (context )is not None and context .mode =='OBJECT'

    def execute (self ,context ):
        curve =_active_curve_object (context )
        props =context .scene .smsp_props 
        if curve is None or context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Active curve required"))
            return {'CANCELLED'}

        depsgraph =context .evaluated_depsgraph_get ()
        points =_curve_to_longest_polyline_world (curve ,depsgraph )
        if len (points )<2 :
            self .report ({'WARNING'},_t ("Need a usable active curve with at least two points"))
            return {'CANCELLED'}

        cyclic =len (points )>2 and (points [0 ]-points [-1 ]).length <=1.0e-5 
        if cyclic :
            base_points =points [:-1 ]
            closed_points =list (base_points )+[base_points [0 ]]
            samples =_sample_polyline (closed_points ,props .curve_rebuild_count ,False )
        else :
            samples =_sample_polyline (points ,props .curve_rebuild_count ,True )
        rebuilt_points =[p for p ,_tan in samples ]
        if len (rebuilt_points )<2 :
            self .report ({'WARNING'},_t ("Need a usable active curve with at least two points"))
            return {'CANCELLED'}

        result_obj =_replace_curve_with_polyline (context ,curve ,rebuilt_points ,cyclic ,props .curve_rebuild_keep_original )
        try :
            safe_select_all ('DESELECT')
            result_obj .select_set (True )
            context .view_layer .objects .active =result_obj 
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Rebuilt the active curve"))
        return {'FINISHED'}


class SMSP_OT_quick_symmetry (Operator ):
    bl_idname ="smsp.quick_symmetry"
    bl_label ="Quick Symmetry"
    bl_description ="In Edit Mode, run destructive symmetrize with the chosen direction. In Object Mode, create or update a Mirror modifier for a non-destructive symmetry setup."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode in {'OBJECT','EDIT_MESH'}

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        props =context .scene .smsp_props 
        if obj is None :
            self .report ({'WARNING'},_t ("Need an active mesh object"))
            return {'CANCELLED'}

        if context .mode =='EDIT_MESH':
            result =call_operator_safe (lambda :bpy .ops .mesh .symmetrize ('EXEC_DEFAULT', False, direction =props .symmetry_direction ,threshold =props .symmetry_merge_threshold ))
            if result is None :
                result =call_operator_safe (lambda :bpy .ops .mesh .symmetrize ('EXEC_DEFAULT', False, direction =props .symmetry_direction ))
            if result is None :
                self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
                return {'CANCELLED'}
            self .report ({'INFO'},_t ("Symmetry complete"))
            return {'FINISHED'}

        if not props .symmetry_use_modifier :
            self .report ({'WARNING'},_t ("Object Mode destructive symmetry is not supported; enable Object Mode = Mirror Modifier or switch to Edit Mode"))
            return {'CANCELLED'}

        axis =_direction_to_axis (props .symmetry_direction )
        mod =None 
        for existing in obj .modifiers :
            if existing .type =='MIRROR'and existing .name .startswith ('SMS_Mirror'):
                mod =existing 
                break 
        if mod is None :
            mod =obj .modifiers .new (name ='SMS_Mirror',type ='MIRROR')
        try :
            mod .use_axis =(axis =='X',axis =='Y',axis =='Z')
        except Exception :
            pass 
        try :
            mod .use_clip =props .symmetry_clip 
        except Exception :
            pass 
        try :
            mod .use_mirror_merge =True 
            mod .merge_threshold =props .symmetry_merge_threshold 
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Symmetry complete"))
        return {'FINISHED'}


class SMSP_OT_toggle_solo_selected (Operator ):
    bl_idname ="smsp.toggle_solo_selected"
    bl_label ="Solo Selected"
    bl_description ="Hide all unselected objects for focused modeling, then restore the previous visibility when run again. Useful for MagicSolo-style focus workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        solo_active =bool (getattr (context .scene ,'get',lambda _k ,_d =None :None )(SOLO_SCENE_KEY ,False ))
        return context .mode =='OBJECT'and (solo_active or bool (context .selected_objects ))

    def execute (self ,context ):
        try :
            solo_active =bool (context .scene .get (SOLO_SCENE_KEY ,False ))
        except Exception :
            solo_active =False 
        if solo_active :
            _restore_solo_visibility (context )
            self .report ({'INFO'},_t ("Solo mode restored"))
            return {'FINISHED'}

        selected =set (o for o in context .selected_objects if o )
        if not selected :
            return {'CANCELLED'}
        for obj in getattr (context .view_layer ,'objects',[])or []:
            try :
                obj [SOLO_OBJ_KEY ]=bool (obj .hide_get ())
            except Exception :
                pass 
            try :
                obj .hide_set (obj not in selected )
            except Exception :
                pass 
        try :
            context .scene [SOLO_SCENE_KEY ]=True 
        except Exception :
            pass 
        self .report ({'INFO'},_t ("Solo mode enabled"))
        return {'FINISHED'}


class SMSP_OT_face_component_array (Operator ):
    bl_idname ="smsp.face_component_array"
    bl_label ="Face Component Array"
    bl_description ="Duplicate the active mesh object onto the faces of the other selected mesh objects. Useful as a compact Tissue-style face component workflow for paneling, tiles, vents, and kitbash repetition."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='OBJECT'and bool (_selected_target_mesh_objects (context ))

    def execute (self ,context ):
        source =_active_mesh_object (context )
        targets =_selected_target_mesh_objects (context )
        props =context .scene .smsp_props 
        if source is None or context .mode !='OBJECT'or not targets :
            self .report ({'WARNING'},_t ("Need an active component mesh and at least one other selected target mesh"))
            return {'CANCELLED'}

        source_rotation =source .matrix_world .to_quaternion ()
        base_scale =source .scale .copy ()
        ref_size =max (1e-8 ,_component_reference_size (source ))
        created =[]

        for target in targets :
            polygons =_iter_target_polygons (target ,props .face_component_selected_faces_only )
            for poly in polygons :
                center ,normal ,tangent ,area =_polygon_world_data (target ,poly )
                face_mat =_orientation_matrix_from_vectors (center +normal *props .face_component_offset ,normal ,tangent )
                scale_factor =props .face_component_scale 
                if props .face_component_scale_to_face :
                    scale_factor *=max (1e-8 ,math .sqrt (max (area ,1e-12 ))/ref_size )
                new_obj =source .copy ()
                if props .face_component_linked_data :
                    new_obj .data =source .data 
                else :
                    try :
                        new_obj .data =source .data .copy ()
                    except Exception :
                        new_obj .data =source .data 
                try :
                    new_obj .animation_data_clear ()
                except Exception :
                    pass 
                _link_to_same_collections (new_obj ,target ,context )
                scale_vec =Vector ((
                max (1e-8 ,abs (base_scale .x )*scale_factor ),
                max (1e-8 ,abs (base_scale .y )*scale_factor ),
                max (1e-8 ,abs (base_scale .z )*scale_factor ),
                ))
                final_quat =face_mat .to_quaternion ()@source_rotation 
                new_obj .matrix_world =Matrix .Translation (face_mat .translation )@final_quat .to_matrix ().to_4x4 ()@Matrix .Diagonal ((scale_vec .x ,scale_vec .y ,scale_vec .z ,1.0 ))
                new_obj .name =f"{source .name }_Face_{target .name }_{poly .index :03d}"
                created .append (new_obj )

        if not created :
            self .report ({'WARNING'},_t ("No target faces were found"))
            return {'CANCELLED'}

        try :
            safe_select_all ('DESELECT')
            for obj in created :
                obj .select_set (True )
            context .view_layer .objects .active =created [0 ]
        except Exception :
            pass 
        self .report ({'INFO'},f"{_t ('Created face component array')}: {len (created )}")
        return {'FINISHED'}


class SMSP_OT_cad_intersect_extend (Operator ):
    bl_idname ="smsp.cad_intersect_extend"
    bl_label ="CAD Intersect / Extend"
    bl_description ="Resolve exactly two selected edges in Edit Mode. Intersect inserts a shared intersection point when the line crossing lies on both segments. Extend moves the nearest endpoints so the edges meet at the resolved point. Useful as a tinyCAD-style precision helper."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        props =context .scene .smsp_props 
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode with exactly 2 selected edges"))
            return {'CANCELLED'}
        bm =bmesh .from_edit_mesh (obj .data )
        selected_edges =[edge for edge in bm .edges if edge .select ]
        if len (selected_edges )!=2 :
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode with exactly 2 selected edges"))
            return {'CANCELLED'}

        point ,fac_a ,fac_b ,skew_distance =_edge_meeting_point (selected_edges [0 ],selected_edges [1 ])
        if point is None :
            self .report ({'WARNING'},_t ("Selected edges are parallel or could not be resolved"))
            return {'CANCELLED'}

        avg_len =max (1e-8 ,(selected_edges [0 ].calc_length ()+selected_edges [1 ].calc_length ())*0.5 )
        if skew_distance is not None and skew_distance >avg_len *1e-4 :
            point =point .copy ()

        if props .cad_mode =='INTERSECT':
            if fac_a is None or fac_b is None or fac_a <-1e-6 or fac_a >1.0 +1e-6 or fac_b <-1e-6 or fac_b >1.0 +1e-6 :
                self .report ({'WARNING'},_t ("Intersection lies outside one or both selected segments; use Extend mode"))
                return {'CANCELLED'}
            vert_a =_edge_insert_or_use_endpoint (selected_edges [0 ],point ,max (0.0 ,min (1.0 ,fac_a )))
            vert_b =_edge_insert_or_use_endpoint (selected_edges [1 ],point ,max (0.0 ,min (1.0 ,fac_b )))
            if vert_a is None or vert_b is None :
                self .report ({'WARNING'},_t ("Intersection lies outside one or both selected segments; use Extend mode"))
                return {'CANCELLED'}
            try :
                bmesh .ops .remove_doubles (bm ,verts =[vert_a ,vert_b ],dist =max (props .audit_merge_distance ,1e-6 ))
            except Exception :
                pass 
            bmesh .update_edit_mesh (obj .data ,loop_triangles =True ,destructive =True )
            self .report ({'INFO'},_t ("Inserted intersection on selected edges"))
            return {'FINISHED'}

        _move_nearest_edge_endpoint (selected_edges [0 ],point )
        _move_nearest_edge_endpoint (selected_edges [1 ],point )
        try :
            bmesh .ops .remove_doubles (bm ,verts =list ({v for e in selected_edges for v in e .verts }),dist =max (props .audit_merge_distance ,1e-6 ))
        except Exception :
            pass 
        bmesh .update_edit_mesh (obj .data ,loop_triangles =False ,destructive =False )
        self .report ({'INFO'},_t ("Extended selected edges to the resolved meeting point"))
        return {'FINISHED'}


class SMSP_OT_audit_selected (Operator ):
    bl_idname ="smsp.audit_selected"
    bl_label ="Audit Selected"
    bl_description ="Analyze the active or selected mesh objects and summarize common production risks such as non-manifold edges, loose elements, ngons, degenerate geometry, and possible doubles. Inspired by 3D Print Toolbox style validation."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None or any (obj for obj in getattr (context ,'selected_objects',[])or []if getattr (obj ,'type',None )=='MESH')

    def execute (self ,context ):
        props =context .scene .smsp_props 
        stats =_audit_targets_from_context (context ,props .audit_merge_distance )
        if not stats :
            self .report ({'WARNING'},_t ("No mesh objects selected for audit"))
            return {'CANCELLED'}
        props .audit_report =_format_audit_report (stats ,props .audit_merge_distance )
        self .report ({'INFO'},_t ("Audit complete"))
        return {'FINISHED'}


class SMSP_OT_audit_repair (Operator ):
    bl_idname ="smsp.audit_repair"
    bl_label ="Audit + Repair"
    bl_description ="Run a conservative cleanup pass on the active or selected mesh objects, then refresh the audit summary. The repair focuses on merge-by-distance, degenerate cleanup, loose removal, and normal recalculation instead of risky topology rewrites."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return SMSP_OT_audit_selected .poll (context )

    def execute (self ,context ):
        props =context .scene .smsp_props 
        stats_before =_audit_targets_from_context (context ,props .audit_merge_distance )
        if not stats_before :
            self .report ({'WARNING'},_t ("No mesh objects selected for audit"))
            return {'CANCELLED'}
        _repair_targets_from_context (context ,props .audit_merge_distance )
        stats_after =_audit_targets_from_context (context ,props .audit_merge_distance )
        if stats_after :
            props .audit_report =_format_audit_report (stats_after ,props .audit_merge_distance )
        self .report ({'INFO'},_t ("Audit + Repair complete"))
        return {'FINISHED'}


class SMSP_OT_audit_select_issues (Operator ):
    bl_idname ="smsp.audit_select_issues"
    bl_label ="Select Issues"
    bl_description ="Select the chosen audit issue type on the active mesh so you can inspect or repair it directly."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None 

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None :
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}
        if context .mode !='EDIT_MESH'and safe_mode_set ('EDIT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Edit Mode"))
            return {'CANCELLED'}

        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        bm .verts .ensure_lookup_table ()
        bm .edges .ensure_lookup_table ()
        bm .faces .ensure_lookup_table ()
        _clear_bmesh_selection (bm )

        issue =str (props .audit_issue_filter or 'NON_MANIFOLD')
        count =0 
        if issue =='NON_MANIFOLD':
            _set_mesh_select_mode (context ,edge =True )
            matches =[edge for edge in bm .edges if not edge .is_manifold ]
            for edge in matches :
                edge .select =True 
            count =len (matches )
        elif issue =='LOOSE':
            _set_mesh_select_mode (context ,vert =True ,edge =True )
            loose_verts =[vert for vert in bm .verts if not vert .link_edges ]
            loose_edges =[edge for edge in bm .edges if edge .is_wire ]
            for vert in loose_verts :
                vert .select =True 
            for edge in loose_edges :
                edge .select =True 
            count =len (loose_verts )+len (loose_edges )
        elif issue =='NGONS':
            _set_mesh_select_mode (context ,face =True )
            matches =[face for face in bm .faces if len (face .verts )>4 ]
            for face in matches :
                face .select =True 
            count =len (matches )
        elif issue =='TRIANGLES':
            _set_mesh_select_mode (context ,face =True )
            matches =[face for face in bm .faces if len (face .verts )==3 ]
            for face in matches :
                face .select =True 
            count =len (matches )
        elif issue =='DEGENERATE':
            _set_mesh_select_mode (context ,edge =True )
            matches =[edge for edge in bm .edges if (edge .verts [0 ].co -edge .verts [1 ].co ).length <=1e-9 ]
            for edge in matches :
                edge .select =True 
            count =len (matches )
        elif issue =='ZERO_AREA':
            _set_mesh_select_mode (context ,face =True )
            matches =[face for face in bm .faces if face .calc_area ()<=1e-12 ]
            for face in matches :
                face .select =True 
            count =len (matches )
        else :
            _set_mesh_select_mode (context ,vert =True )
            matched_verts =set ()
            try :
                target_map =bmesh .ops .find_doubles (
                bm ,
                verts =list (bm .verts ),
                dist =max (0.0 ,float (props .audit_merge_distance )),
                ).get ('targetmap',{})
                for src ,dst in target_map .items ():
                    if src !=dst :
                        matched_verts .add (src )
                        matched_verts .add (dst )
            except Exception :
                matched_verts =set ()
            for vert in matched_verts :
                vert .select =True 
            count =len (matched_verts )

        bmesh .update_edit_mesh (obj .data ,loop_triangles =False ,destructive =False )
        if count <=0 :
            self .report ({'INFO'},_t ("No matching issues were found on the active mesh"))
            return {'CANCELLED'}
        self .report ({'INFO'},f"{_t ('Selected issue elements')}: {count }")
        return {'FINISHED'}


class SMSP_OT_axis_slice_edit (Operator ):
    bl_idname ="smsp.axis_slice_edit"
    bl_label ="Axis Slice Edit"
    bl_description ="Bisect the active edit mesh by one or more evenly spaced local axis planes. Useful for SliceIt XYZ / Slicer style numeric cuts, panel segmentation, contour prep, and quick retopo guides."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need an active mesh in Edit Mode"))
            return {'CANCELLED'}

        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        bm .verts .ensure_lookup_table ()
        bm .edges .ensure_lookup_table ()
        bm .faces .ensure_lookup_table ()

        source_verts =list (bm .verts )
        if bool (props .axis_slice_use_selection_bounds ):
            selected_verts =_selected_vertices_from_any_selection (bm )
            if not selected_verts :
                self .report ({'WARNING'},_t ("Select one or more vertices / edges / faces first, or disable Use Selection Bounds"))
                return {'CANCELLED'}
            source_verts =selected_verts 

        positions =_slice_positions_from_verts (source_verts ,props .axis_slice_axis ,props .axis_slice_count )
        if not positions :
            self .report ({'WARNING'},_t ("Need a mesh with non-zero extent along the chosen slice axis"))
            return {'CANCELLED'}

        plane_no =_axis_vector (props .axis_slice_axis )
        dist =max (1.0e-9 ,float (props .axis_slice_tolerance ))
        cut_edges =[]
        for position in positions :
            plane_co =Vector ((0.0 ,0.0 ,0.0 ))
            plane_co [_axis_index (props .axis_slice_axis )]=float (position )
            geom =list (bm .verts )+list (bm .edges )+list (bm .faces )
            result =bmesh .ops .bisect_plane (
            bm ,
            geom =geom ,
            dist =dist ,
            plane_co =plane_co ,
            plane_no =plane_no ,
            use_snap_center =False ,
            clear_inner =False ,
            clear_outer =False ,
            )
            for elem in result .get ('geom_cut',[]):
                if isinstance (elem ,bmesh .types .BMEdge ):
                    cut_edges .append (elem )

        if not cut_edges :
            bmesh .update_edit_mesh (obj .data ,loop_triangles =True ,destructive =True )
            self .report ({'INFO'},_t ("No new slice edges were generated"))
            return {'CANCELLED'}

        if bool (props .axis_slice_select_new ):
            _clear_bmesh_selection (bm )
            _set_mesh_select_mode (context ,edge =True )
            for edge in cut_edges :
                try :
                    edge .select =True 
                except Exception :
                    pass 

        bmesh .update_edit_mesh (obj .data ,loop_triangles =True ,destructive =True )
        self .report ({'INFO'},f"{_t ('Axis slice complete')}: {len (positions )}")
        return {'FINISHED'}


def _ordered_points_nearest (points ,start_index =0 ):
    if not points :
        return []
    pts =list (points )
    start_index =max (0 ,min (int (start_index ),len (pts )-1 ))
    used =[False ]*len (pts )
    order =[start_index ]
    used [start_index ]=True 
    while len (order )<len (pts ):
        last =pts [order [-1 ]]
        best_i =None 
        best_d =None 
        for i ,p in enumerate (pts ):
            if used [i ]:
                continue 
            d =(p -last ).length_squared 
            if best_i is None or d <best_d :
                best_i =i 
                best_d =d 
        if best_i is None :
            break 
        used [best_i ]=True 
        order .append (best_i )
    return [pts [i ]for i in order ]


class SMSP_OT_selected_vertices_to_path (Operator ):
    bl_idname ="smsp.selected_vertices_to_path"
    bl_label ="Selected Vertices To Path"
    bl_description ='Create a curve path from the currently selected edit-mesh vertices. Useful for spline blocking, strip routing, loft / sweep preparation, and 3ds Max style path extraction from direct mesh edits.'
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need selected vertices in Edit Mode"))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        bm =bmesh .from_edit_mesh (obj .data )
        selected =[v for v in bm .verts if v .select ]
        if len (selected )<2 :
            self .report ({'WARNING'},_t ("Need selected vertices in Edit Mode"))
            return {'CANCELLED'}
        active_v =getattr (bm .select_history ,'active',None )
        active_index =None 
        if active_v is not None and isinstance (active_v ,bmesh .types .BMVert )and active_v .select :
            try :
                active_index =selected .index (active_v )
            except ValueError :
                active_index =None 
        points =[obj .matrix_world @v .co .copy ()for v in selected ]
        if bool (props .vertices_to_path_use_nearest ):
            ordered =_ordered_points_nearest (points ,active_index if active_index is not None else 0 )
        else :
            ordered =list (points )
            if active_index is not None and active_index !=0 :
                ordered =ordered [active_index :]+ordered [:active_index ]
        if bool (props .vertices_to_path_cyclic )and len (ordered )>=3 :
            ordered .append (ordered [0 ].copy ())
        state =capture_object_context (context )
        if not ensure_object_mode (context ,obj ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        name =_unique_name (set (bpy .data .objects .keys ()),f"{obj .name }_VertexPath")
        curve_obj =_new_curve_object_from_world_paths (context ,name ,[ordered ],reference_obj =obj )
        if curve_obj is None :
            restore_object_context (context ,state )
            self .report ({'ERROR'},_t ("Failed to create curve path from selected vertices"))
            return {'CANCELLED'}
        _activate_only (context ,curve_obj )
        self .report ({'INFO'},_t ("Created curve path from selected vertices"))
        return {'FINISHED'}


class SMSP_OT_selected_objects_to_path (Operator ):
    bl_idname ="smsp.selected_objects_to_path"
    bl_label ="Selected Objects To Path"
    bl_description ="Create a curve path from the world-space origins of the selected objects. Useful for trajectory-to-spline style workflows, blocking guide curves, layout splines, and quickly turning placed empties/objects into reusable paths."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='OBJECT'and len (getattr (context ,'selected_objects',[])or [])>=2 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        ordered =_ordered_selected_objects_for_path (context ,bool (props .objects_to_path_use_nearest ))
        if len (ordered )<2 :
            self .report ({'WARNING'},_t ("Need at least two selected objects in Object Mode"))
            return {'CANCELLED'}
        points =[obj .matrix_world .translation .copy ()for obj in ordered ]
        if bool (props .objects_to_path_cyclic )and len (points )>=3 :
            points .append (points [0 ].copy ())
        active =getattr (context ,'active_object',None )
        base_name =f"{active .name if active else 'Selection'}_Path"
        curve_obj =_new_curve_object_from_world_paths (context ,base_name ,[points ],reference_obj =active if active else None )
        if curve_obj is None :
            self .report ({'WARNING'},_t ("Failed to create curve path from the selected objects"))
            return {'CANCELLED'}
        _activate_only (context ,curve_obj )
        self .report ({'INFO'},_t ("Created curve path from selected objects"))
        return {'FINISHED'}



class SMSP_OT_add_profile_primitive (Operator ):
    bl_idname ="smsp.add_profile_primitive"
    bl_label ="Add Profile Primitive"
    bl_description ="Create a reusable 2D curve profile at the 3D cursor. Useful for Sweep Mesh, molding, trim, rail sections, cable trays, and CAD-style profile workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='OBJECT'

    def execute (self ,context ):
        props =context .scene .smsp_props 
        if context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Object Mode required"))
            return {'CANCELLED'}
        points =_profile_points (
        props .profile_primitive_type ,
        props .profile_width ,
        props .profile_height ,
        props .profile_points ,
        props .profile_star_inner ,
        )
        base_name =f"SMS_{props .profile_primitive_type .title ()}_Profile"
        name =_unique_name (set (bpy .data .objects .keys ()),base_name )
        obj =_new_local_curve_object (
        context ,
        name ,
        [points ],
        dimensions ='2D',
        cyclic =True ,
        fill_mode ='FULL',
        resolution_u =max (1 ,int (props .profile_points )),
        use_path =False ,
        )
        if obj is None :
            self .report ({'WARNING'},_t ("Object Mode required"))
            return {'CANCELLED'}
        _activate_only (context ,obj )
        self .report ({'INFO'},_t ("Created profile primitive"))
        return {'FINISHED'}


class SMSP_OT_add_helix_path (Operator ):
    bl_idname ="smsp.add_helix_path"
    bl_label ="Add Helix Path"
    bl_description ="Create a helix/spiral curve path at the 3D cursor. Useful for springs, spiral cables, wrapped trims, and guide curves for sweep or array workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='OBJECT'

    def execute (self ,context ):
        props =context .scene .smsp_props 
        if context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Object Mode required"))
            return {'CANCELLED'}
        points =_helix_points (
        props .helix_radius ,
        props .helix_height ,
        props .helix_turns ,
        props .helix_points_per_turn ,
        props .helix_taper ,
        props .helix_clockwise ,
        )
        name =_unique_name (set (bpy .data .objects .keys ()),"SMS_Helix_Path")
        obj =_new_local_curve_object (
        context ,
        name ,
        [points ],
        dimensions ='3D',
        cyclic =False ,
        fill_mode ='NONE',
        resolution_u =max (1 ,int (props .helix_points_per_turn )),
        use_path =True ,
        )
        if obj is None :
            self .report ({'WARNING'},_t ("Object Mode required"))
            return {'CANCELLED'}
        _activate_only (context ,obj )
        self .report ({'INFO'},_t ("Created helix path"))
        return {'FINISHED'}



class SMSP_OT_selected_edges_to_curve (Operator ):
    bl_idname ="smsp.selected_edges_to_curve"
    bl_label ="Selected Edges To Curve"
    bl_description ="Convert selected mesh edges into one or more curve splines without duplicating or separating the source mesh. Useful for Vertices to Splines, sweep prep, path extraction, trim routing, and safer pipe workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return _active_mesh_object (context )is not None and context .mode =='EDIT_MESH'

    def execute (self ,context ):
        obj =_active_mesh_object (context )
        if obj is None or context .mode !='EDIT_MESH':
            self .report ({'WARNING'},_t ("Need selected mesh edges in Edit Mode"))
            return {'CANCELLED'}
        bm =bmesh .from_edit_mesh (obj .data )
        paths =_selected_edge_paths_world_from_bmesh (obj ,bm )
        if not paths :
            self .report ({'WARNING'},_t ("Need selected mesh edges in Edit Mode"))
            return {'CANCELLED'}
        state =capture_object_context (context )
        if not ensure_object_mode (context ,obj ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}
        name =_unique_name (set (bpy .data .objects .keys ()),f"{obj .name }_Curves")
        curve_obj =_new_curve_object_from_world_paths (context ,name ,paths ,reference_obj =obj )
        if curve_obj is None :
            restore_object_context (context ,state )
            self .report ({'ERROR'},_t ("Failed to create curve data from the selected edges"))
            return {'CANCELLED'}
        _activate_only (context ,curve_obj )
        self .report ({'INFO'},_t ("Created curve object from selected edges"))
        return {'FINISHED'}


class SMSP_OT_loft_bridge_paths (Operator ):
    bl_idname ="smsp.loft_bridge_paths"
    bl_label ="Loft / Bridge Paths"
    bl_description ="Create a loft mesh between exactly two paths. Works with two selected curve objects in Object Mode, or with exactly two selected edge paths in Edit Mode. Useful for PolyBridge, spline patch, loft surfacing, trims, and strip modeling workflows."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        if context .mode =='EDIT_MESH':
            return _active_mesh_object (context )is not None 
        if context .mode =='OBJECT':
            curves =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj and obj .type =='CURVE']
            return len (curves )>=2 
        return False 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        ref_obj =getattr (context ,'active_object',None )
        path_a =None 
        path_b =None 

        state =None 
        if context .mode =='EDIT_MESH':
            obj =_active_mesh_object (context )
            bm =bmesh .from_edit_mesh (obj .data )
            paths =_selected_edge_paths_world_from_bmesh (obj ,bm )
            if len (paths )!=2 :
                self .report ({'WARNING'},_t ("Need exactly two selected curve objects or exactly two selected edge paths"))
                return {'CANCELLED'}
            path_a ,path_b =paths 
            state =capture_object_context (context )
            if not ensure_object_mode (context ,obj ):
                self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
                return {'CANCELLED'}
            ref_obj =obj 
        else :
            curves =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj and obj .type =='CURVE']
            if len (curves )!=2 :
                self .report ({'WARNING'},_t ("Need exactly two selected curve objects or exactly two selected edge paths"))
                return {'CANCELLED'}
            depsgraph =context .evaluated_depsgraph_get ()
            path_a =_curve_to_longest_polyline_world (curves [0 ],depsgraph )
            path_b =_curve_to_longest_polyline_world (curves [1 ],depsgraph )
            ref_obj =context .active_object if context .active_object in curves else curves [0 ]

        if not path_a or not path_b :
            self .report ({'WARNING'},_t ("Need exactly two selected curve objects or exactly two selected edge paths"))
            return {'CANCELLED'}

        name =_unique_name (set (bpy .data .objects .keys ()),"SMS_Loft")
        loft_obj =_new_loft_object_from_paths (context ,name ,path_a ,path_b ,props .loft_sample_count ,props .loft_shade_smooth ,reference_obj =ref_obj )
        if loft_obj is None :
            if state is not None :
                restore_object_context (context ,state )
            self .report ({'ERROR'},_t ("Failed to create loft mesh from the resolved paths"))
            return {'CANCELLED'}
        _activate_only (context ,loft_obj )
        self .report ({'INFO'},_t ("Created loft mesh from two paths"))
        return {'FINISHED'}


_SWEEP_GROUP_NAME ="SMS Sweep Modifier"
_SWEEP_GROUP_SCHEMA =1
_SWEEP_GROUP_SCHEMA_PROP ="sms_sweep_schema"


def _sweep_socket (sockets ,name ,index =0 ):
    try :
        socket =sockets .get (name )
        if socket is not None :
            return socket
    except Exception :
        pass
    try :
        return sockets [index ]
    except Exception :
        return None


def _sweep_link (group ,from_socket ,to_socket ):
    if from_socket is None or to_socket is None :
        raise RuntimeError ("Sweep node socket is unavailable")
    group .links .new (from_socket ,to_socket )


def _sweep_add_interface_socket (group ,name ,in_out ,socket_type ,default =None ):
    socket =group .interface .new_socket (name =name ,in_out =in_out ,socket_type =socket_type )
    if default is not None :
        try :
            socket .default_value =default
        except Exception :
            pass
    return socket


def _sweep_find_group ():
    for group in bpy .data .node_groups :
        try :
            if group .bl_idname =='GeometryNodeTree'and int (group .get (_SWEEP_GROUP_SCHEMA_PROP ,0 )or 0 )==_SWEEP_GROUP_SCHEMA :
                return group
        except Exception :
            continue
    return None


def _sweep_make_group ():
    existing =_sweep_find_group ()
    if existing is not None :
        return existing
    group =bpy .data .node_groups .new (_SWEEP_GROUP_NAME ,'GeometryNodeTree')
    try :
        group [_SWEEP_GROUP_SCHEMA_PROP ]=_SWEEP_GROUP_SCHEMA
        group ["sms_owned_node_group"]=True
        group .is_modifier =True

        geometry_in =_sweep_add_interface_socket (group ,"Geometry",'INPUT','NodeSocketGeometry')
        profile_in =_sweep_add_interface_socket (group ,"Profile Curve",'INPUT','NodeSocketObject')
        resolution_in =_sweep_add_interface_socket (group ,"Sweep Resolution",'INPUT','NodeSocketInt',12 )
        fill_caps_in =_sweep_add_interface_socket (group ,"Sweep Fill Caps",'INPUT','NodeSocketBool',True )
        x_offset_in =_sweep_add_interface_socket (group ,"Sweep X Offset",'INPUT','NodeSocketFloat',0.0 )
        y_offset_in =_sweep_add_interface_socket (group ,"Sweep Y Offset",'INPUT','NodeSocketFloat',0.0 )
        angle_in =_sweep_add_interface_socket (group ,"Sweep Angle",'INPUT','NodeSocketFloat',0.0 )
        mirror_x_in =_sweep_add_interface_socket (group ,"Mirror Sweep X",'INPUT','NodeSocketBool',False )
        mirror_y_in =_sweep_add_interface_socket (group ,"Mirror Sweep Y",'INPUT','NodeSocketBool',False )
        _sweep_add_interface_socket (group ,"Geometry",'OUTPUT','NodeSocketGeometry')
        try :
            resolution_in .min_value =1
            resolution_in .max_value =1024
            angle_in .subtype ='ANGLE'
        except Exception :
            pass

        nodes =group .nodes
        group_input =nodes .new ('NodeGroupInput')
        group_output =nodes .new ('NodeGroupOutput')
        set_resolution =nodes .new ('GeometryNodeSetSplineResolution')
        object_info =nodes .new ('GeometryNodeObjectInfo')
        transform_profile =nodes .new ('GeometryNodeTransform')
        offset =nodes .new ('ShaderNodeCombineXYZ')
        rotation =nodes .new ('ShaderNodeCombineXYZ')
        scale =nodes .new ('ShaderNodeCombineXYZ')
        mirror_x =nodes .new ('GeometryNodeSwitch')
        mirror_y =nodes .new ('GeometryNodeSwitch')
        curve_to_mesh =nodes .new ('GeometryNodeCurveToMesh')

        group_input .location =(-900 ,160 )
        set_resolution .location =(-620 ,280 )
        object_info .location =(-900 ,-220 )
        offset .location =(-620 ,-120 )
        rotation .location =(-620 ,-300 )
        mirror_x .location =(-620 ,-480 )
        mirror_y .location =(-620 ,-620 )
        scale .location =(-360 ,-500 )
        transform_profile .location =(-100 ,-220 )
        curve_to_mesh .location =(180 ,120 )
        group_output .location =(480 ,120 )

        object_info .transform_space ='RELATIVE'
        mirror_x .input_type ='FLOAT'
        mirror_y .input_type ='FLOAT'
        _sweep_socket (mirror_x .inputs ,"False",1 ).default_value =1.0
        _sweep_socket (mirror_x .inputs ,"True",2 ).default_value =-1.0
        _sweep_socket (mirror_y .inputs ,"False",1 ).default_value =1.0
        _sweep_socket (mirror_y .inputs ,"True",2 ).default_value =-1.0
        _sweep_socket (scale .inputs ,"Z",2 ).default_value =1.0
        as_instance =_sweep_socket (object_info .inputs ,"As Instance",1 )
        if as_instance is not None :
            as_instance .default_value =False

        _sweep_link (group ,_sweep_socket (group_input .outputs ,geometry_in .name ,0 ),_sweep_socket (set_resolution .inputs ,"Curve",0 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,resolution_in .name ,2 ),_sweep_socket (set_resolution .inputs ,"Resolution",1 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,profile_in .name ,1 ),_sweep_socket (object_info .inputs ,"Object",0 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,x_offset_in .name ,4 ),_sweep_socket (offset .inputs ,"X",0 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,y_offset_in .name ,5 ),_sweep_socket (offset .inputs ,"Y",1 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,angle_in .name ,6 ),_sweep_socket (rotation .inputs ,"Z",2 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,mirror_x_in .name ,7 ),_sweep_socket (mirror_x .inputs ,"Switch",0 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,mirror_y_in .name ,8 ),_sweep_socket (mirror_y .inputs ,"Switch",0 ))
        _sweep_link (group ,_sweep_socket (mirror_x .outputs ,"Output",0 ),_sweep_socket (scale .inputs ,"X",0 ))
        _sweep_link (group ,_sweep_socket (mirror_y .outputs ,"Output",0 ),_sweep_socket (scale .inputs ,"Y",1 ))
        _sweep_link (group ,_sweep_socket (object_info .outputs ,"Geometry",4 ),_sweep_socket (transform_profile .inputs ,"Geometry",0 ))
        _sweep_link (group ,_sweep_socket (offset .outputs ,"Vector",0 ),_sweep_socket (transform_profile .inputs ,"Translation",1 ))
        _sweep_link (group ,_sweep_socket (rotation .outputs ,"Vector",0 ),_sweep_socket (transform_profile .inputs ,"Rotation",2 ))
        _sweep_link (group ,_sweep_socket (scale .outputs ,"Vector",0 ),_sweep_socket (transform_profile .inputs ,"Scale",3 ))
        _sweep_link (group ,_sweep_socket (set_resolution .outputs ,"Curve",0 ),_sweep_socket (curve_to_mesh .inputs ,"Curve",0 ))
        _sweep_link (group ,_sweep_socket (transform_profile .outputs ,"Geometry",0 ),_sweep_socket (curve_to_mesh .inputs ,"Profile Curve",1 ))
        _sweep_link (group ,_sweep_socket (group_input .outputs ,fill_caps_in .name ,3 ),_sweep_socket (curve_to_mesh .inputs ,"Fill Caps",2 ))
        _sweep_link (group ,_sweep_socket (curve_to_mesh .outputs ,"Mesh",0 ),_sweep_socket (group_output .inputs ,"Geometry",0 ))
        return group
    except Exception :
        try :
            bpy .data .node_groups .remove (group )
        except Exception :
            pass
        raise


def _sweep_set_modifier_input (modifier ,group ,name ,value ):
    try :
        for item in group .interface .items_tree :
            if getattr (item ,"item_type","")=='SOCKET'and getattr (item ,"in_out","")=='INPUT'and item .name ==name :
                modifier [item .identifier ]=value
                return True
    except Exception :
        pass
    return False


def _sweep_remove_created_modifier (sweep_obj ,modifier ):
    if sweep_obj is None or modifier is None :
        return False
    try :
        modifier_pointer =int (modifier .as_pointer ())
    except Exception :
        return False
    for candidate in tuple (getattr (sweep_obj ,'modifiers',())or ()):
        try :
            if int (candidate .as_pointer ())==modifier_pointer :
                sweep_obj .modifiers .remove (candidate )
                return True
        except Exception :
            continue
    return False


class SMSP_OT_sweep_active_profile (Operator ):
    bl_idname ="smsp.sweep_active_profile"
    bl_label ="Sweep Active Profile"
    bl_description ="Add a non-destructive Sweep modifier that pushes the selected profile curve along the active path curve."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        if context .mode !='OBJECT':
            return False 
        active =_active_curve_object (context )
        if active is None :
            return False 
        others =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj and obj .type =='CURVE'and obj !=active ]
        return len (others )==1 

    def execute (self ,context ):
        props =context .scene .smsp_props 
        path_obj =_active_curve_object (context )
        if path_obj is None or context .mode !='OBJECT':
            self .report ({'WARNING'},_t ("Active path curve and one selected profile curve are required"))
            return {'CANCELLED'}
        profiles =[obj for obj in (getattr (context ,'selected_objects',[])or [])if obj and obj .type =='CURVE'and obj !=path_obj ]
        if len (profiles )!=1 :
            self .report ({'WARNING'},_t ("Active path curve and one selected profile curve are required"))
            return {'CANCELLED'}
        profile =profiles [0 ]

        sweep_obj =path_obj 
        if props .sweep_duplicate_path :
            sweep_obj =path_obj .copy ()
            sweep_obj .data =path_obj .data .copy ()
            sweep_obj .name =_unique_name (set (bpy .data .objects .keys ()),f"SMS_Sweep_{path_obj .name }")
            _link_to_same_collections (sweep_obj ,path_obj ,context )

        try :
            group =_sweep_make_group ()
            modifier =sweep_obj .modifiers .new (name =_t ("Sweep Modifier"),type ='NODES')
            modifier .node_group =group
            modifier ["sms_sweep_modifier"]=True
            modifier ["sms_curve_source_modifier"]=True
            modifier ["sms_sweep_profile_name"]=str (profile .name )
            values ={
            "Profile Curve":profile ,
            "Sweep Resolution":max (1 ,int (props .sweep_resolution_u )),
            "Sweep Fill Caps":bool (props .sweep_fill_caps ),
            "Sweep X Offset":float (props .sweep_x_offset ),
            "Sweep Y Offset":float (props .sweep_y_offset ),
            "Sweep Angle":float (props .sweep_angle ),
            "Mirror Sweep X":bool (props .sweep_mirror_x ),
            "Mirror Sweep Y":bool (props .sweep_mirror_y ),
            }
            for name ,value in values .items ():
                if not _sweep_set_modifier_input (modifier ,group ,name ,value ):
                    raise RuntimeError (f"Could not bind Sweep input: {name}")
        except Exception :
            try :
                _sweep_remove_created_modifier (sweep_obj ,locals ().get ('modifier'))
            except Exception :
                pass
            if sweep_obj is not path_obj :
                sweep_data =getattr (sweep_obj ,"data",None )
                try :
                    bpy .data .objects .remove (sweep_obj ,do_unlink =True )
                except Exception :
                    pass
                try :
                    if sweep_data is not None and int (getattr (sweep_data ,"users",0 )or 0 )==0 :
                        bpy .data .curves .remove (sweep_data )
                except Exception :
                    pass
            self .report ({'ERROR'},_t ("Could not create the Sweep modifier"))
            return {'CANCELLED'}
        try :
            sweep_obj .update_tag ()
        except Exception :
            pass
        _activate_only (context ,sweep_obj )
        self .report ({'INFO'},_t ("Added a non-destructive Sweep modifier using the selected profile curve"))
        return {'FINISHED'}




class SMSP_OT_surface_conform_modifier (Operator ):
    bl_idname ="smsp.surface_conform_modifier"
    bl_label ="Surface Conform Modifier"
    bl_description ='Add or update a shrinkwrap-based conform modifier on the selected detail meshes so they follow the active surface mesh in a 3ds Max style modifier workflow.'
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        source =_active_mesh_object (context )
        if source is None or context .mode !='OBJECT':
            return False 
        return any (obj for obj in context .selected_objects if obj .type =='MESH'and obj !=source )

    def execute (self ,context ):
        source =_active_mesh_object (context )
        targets =[obj for obj in context .selected_objects if obj .type =='MESH'and obj !=source ]
        if source is None or not targets :
            self .report ({'WARNING'},_t ('Need an active source mesh and at least one other selected target mesh'))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        count =0 
        for obj in targets :
            sw =_get_or_create_modifier (obj ,'SMS Surface Conform','SHRINKWRAP')
            if sw is None :
                continue 
            try :
                sw .target =source 
            except Exception :
                pass 
            try :
                sw .offset =float (props .conform_offset )
            except Exception :
                pass 
            _set_shrinkwrap_mode (sw ,props .conform_method )
            for attr ,value in (('wrap_mode','OUTSIDE_SURFACE'),('show_on_cage',True ),('show_in_editmode',True )):
                try :
                    setattr (sw ,attr ,value )
                except Exception :
                    pass 
            if bool (props .conform_add_normals ):
                dt =_get_or_create_modifier (obj ,'SMS Normal Transfer','DATA_TRANSFER')
                _configure_data_transfer_normals (dt ,source ,props .normal_transfer_mix )
            count +=1 
        if count ==0 :
            self .report ({'ERROR'},_t ('Failed to add conform modifiers to the selected targets'))
            return {'CANCELLED'}
        self .report ({'INFO'},f"{_t ('Configured surface conform modifiers on selected targets')}: {count }")
        return {'FINISHED'}


class SMSP_OT_normal_transfer_to_selected (Operator ):
    bl_idname ="smsp.normal_transfer_to_selected"
    bl_label ="Normal Transfer Modifier"
    bl_description ='Add or update a Data Transfer modifier on the selected target meshes so custom normals follow the active source mesh. Useful for hard-surface shading, floating details, bevel support parts, and keeping kitbash pieces visually welded.'
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        source =_active_mesh_object (context )
        if source is None or context .mode !='OBJECT':
            return False 
        return any (obj for obj in context .selected_objects if obj .type =='MESH'and obj !=source )

    def execute (self ,context ):
        source =_active_mesh_object (context )
        targets =[obj for obj in context .selected_objects if obj .type =='MESH'and obj !=source ]
        if source is None or not targets :
            self .report ({'WARNING'},_t ('Need an active source mesh and at least one other selected target mesh'))
            return {'CANCELLED'}
        props =context .scene .smsp_props 
        count =0 
        for obj in targets :
            dt =_get_or_create_modifier (obj ,'SMS Normal Transfer','DATA_TRANSFER')
            if dt is None :
                continue 
            _configure_data_transfer_normals (dt ,source ,props .normal_transfer_mix )
            count +=1 
        if count ==0 :
            self .report ({'ERROR'},_t ('Failed to add normal transfer modifiers to the selected targets'))
            return {'CANCELLED'}
        self .report ({'INFO'},f"{_t ('Configured normal transfer modifiers on selected targets')}: {count }")
        return {'FINISHED'}


class SMSP_PT_precision_layout (Panel ):
    bl_label ="Precision / Layout / Path"
    bl_idname ="SMSP_PT_precision_layout"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}
    bl_order =50 
    bl_description ='Compact precision panel for workplane, projection, retopo helpers, path instancing, replacements, and curve-based modeling tasks.'

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'precision_layout_path', context=context)

    def draw (self ,context ):
        layout =self .layout 
        props =context .scene .smsp_props 
        draw_help_header (layout ,context ,'Precision / Layout','ORIENTATION_CURSOR','precision_layout_path')
        box =layout .box ()
        draw_help_header (box ,context ,"Workplane / Projection",'ORIENTATION_CURSOR','precision_workplane_projection')
        _draw_panel_operator (box ,context ,'smsp.workplane_from_active',icon ='EMPTY_AXIS')
        box .prop (props ,"workplane_use_cursor_pivot")
        box .prop (props ,"workplane_use_cursor_orientation")
        box .separator ()
        _draw_panel_operator (box ,context ,'smsp.project_to_active_plane',icon ='FACESEL')
        box .prop (props ,"project_offset")

        box =layout .box ()
        draw_help_header (box ,context ,"Surface / Retopo / Utility",'SNAP_FACE','precision_surface_retopo')
        _draw_panel_operator (box ,context ,'smsp.project_to_selected_surface',icon ='MOD_SHRINKWRAP')
        box .prop (props ,"surface_project_offset")
        box .separator ()
        _draw_panel_operator (box ,context ,'smsp.rebuild_active_curve',icon ='CURVE_DATA')
        row =box .row (align =True )
        row .prop (props ,"curve_rebuild_count")
        row .prop (props ,"curve_rebuild_keep_original")
        box .separator ()
        draw_help_header (box ,context ,"Curves / Loft / Prep",'CURVE_DATA','precision_curves_paths')
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.selected_edges_to_curve',icon ='CURVE_DATA')
        _draw_panel_operator (row ,context ,'smsp.selected_vertices_to_path',icon ='CURVES_DATA')
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.selected_objects_to_path',icon ='OUTLINER_OB_CURVE')
        _draw_panel_operator (row ,context ,'smsp.loft_bridge_paths',icon ='SURFACE_NSURFACE')
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.sweep_active_profile',icon ='MOD_CURVE')
        box .label (text =_t ("Profile / Path Primitives"),icon ='ADD')
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.add_profile_primitive',icon ='MESH_CIRCLE')
        _draw_panel_operator (row ,context ,'smsp.add_helix_path',icon ='CURVE_DATA')
        row =box .row (align =True )
        row .prop (props ,"profile_primitive_type")
        row .prop (props ,"profile_points")
        row =box .row (align =True )
        row .prop (props ,"profile_width")
        row .prop (props ,"profile_height")
        if props .profile_primitive_type =='STAR':
            box .prop (props ,"profile_star_inner")
        row =box .row (align =True )
        row .prop (props ,"helix_radius")
        row .prop (props ,"helix_height")
        row =box .row (align =True )
        row .prop (props ,"helix_turns")
        row .prop (props ,"helix_points_per_turn")
        row =box .row (align =True )
        row .prop (props ,"helix_taper")
        row .prop (props ,"helix_clockwise")
        row =box .row (align =True )
        row .prop (props ,"objects_to_path_use_nearest")
        row .prop (props ,"objects_to_path_cyclic")
        row =box .row (align =True )
        row .prop (props ,"vertices_to_path_use_nearest")
        row .prop (props ,"vertices_to_path_cyclic")
        row =box .row (align =True )
        row .prop (props ,"sweep_duplicate_path")
        row .prop (props ,"sweep_fill_caps")
        row =box .row (align =True )
        row .prop (props ,"sweep_x_offset")
        row .prop (props ,"sweep_y_offset")
        row =box .row (align =True )
        row .prop (props ,"sweep_angle")
        row .prop (props ,"sweep_mirror_x",toggle =True )
        row .prop (props ,"sweep_mirror_y",toggle =True )
        row =box .row (align =True )
        row .prop (props ,"loft_sample_count")
        row .prop (props ,"sweep_resolution_u")
        row =box .row (align =True )
        row .prop (props ,"loft_shade_smooth")
        box .separator ()
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.toggle_solo_selected',icon ='HIDE_OFF')
        _draw_panel_operator (row ,context ,'smsp.drop_to_floor',icon ='TRIA_DOWN')
        row =box .row (align =True )
        row .prop (props ,"drop_to_floor_use_cursor_z")
        row .prop (props ,"drop_to_floor_z")

        box =layout .box ()
        draw_help_header (box ,context ,"CAD / Tessellate / Audit",'MOD_EDGESPLIT','precision_cad_audit')
        _draw_panel_operator (box ,context ,'smsp.face_component_array',icon ='MOD_ARRAY')
        row =box .row (align =True )
        row .prop (props ,"face_component_selected_faces_only")
        row .prop (props ,"face_component_scale_to_face")
        row =box .row (align =True )
        row .prop (props ,"face_component_scale")
        row .prop (props ,"face_component_offset")
        box .prop (props ,"face_component_linked_data")
        box .separator ()
        _draw_panel_operator (box ,context ,'smsp.cad_intersect_extend',icon ='SNAP_VERTEX')
        box .prop (props ,"cad_mode")
        box .separator ()
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.audit_selected',icon ='CHECKMARK')
        _draw_panel_operator (row ,context ,'smsp.audit_repair',icon ='TOOL_SETTINGS')
        box .prop (props ,"audit_merge_distance")
        row =box .row (align =True )
        row .prop (props ,"audit_issue_filter")
        _draw_panel_operator (row ,context ,'smsp.audit_select_issues',icon ='RESTRICT_SELECT_OFF')
        box .separator ()
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.axis_slice_edit',icon ='MOD_EDGESPLIT')
        row .prop (props ,"axis_slice_axis")
        row .prop (props ,"axis_slice_count")
        row =box .row (align =True )
        row .prop (props ,"axis_slice_use_selection_bounds")
        row .prop (props ,"axis_slice_select_new")
        box .prop (props ,"axis_slice_tolerance")

        if props .audit_report :
            report_box =layout .box ()
            report_box .label (text =_t ("Last Audit Report"),icon='NONE')
            for line in props .audit_report .splitlines ():
                report_box .label (text =line )

        box =layout .box ()
        draw_help_header (box ,context ,"Path / Replace / Randomize",'CURVE_DATA','precision_path_layout')
        _draw_panel_operator (box ,context ,'smsp.instances_along_path',icon ='MOD_ARRAY')
        col =box .column (align =True )
        col .prop (props ,"path_count")
        row =col .row (align =True )
        row .prop (props ,"path_include_ends")
        row .prop (props ,"path_follow_tangent")
        col .prop (props ,"path_random_roll_deg")
        row =col .row (align =True )
        row .prop (props ,"path_linked_data")
        row .prop (props ,"path_organize")
        box .separator ()
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.align_to_active',icon ='ORIENTATION_GLOBAL')
        _draw_panel_operator (row ,context ,'smsp.distribute_selected_axis',icon ='MOD_ARRAY')
        row =box .row (align =True )
        _draw_panel_operator (row ,context ,'smsp.stack_selected',icon ='ALIGN_JUSTIFY')
        row .prop (props ,"stack_axis")
        row .prop (props ,"stack_gap")
        row =box .row (align =True )
        row .prop (props ,"align_location")
        row .prop (props ,"align_rotation")
        row .prop (props ,"align_scale")
        row =box .row (align =True )
        row .prop (props ,"align_axis_x")
        row .prop (props ,"align_axis_y")
        row .prop (props ,"align_axis_z")
        row .prop (props ,"distribute_axis")
        box .separator ()
        _draw_panel_operator (box ,context ,'smsp.replace_with_active',icon ='DUPLICATE')
        row =box .row (align =True )
        row .prop (props ,"replace_linked_data")
        row .prop (props ,"replace_delete_targets")
        box .prop (props ,"replace_preserve_collections")
        box .separator ()
        _draw_panel_operator (box ,context ,'smsp.randomize_selected',icon ='RNDCURVE')
        col =box .column (align =True )
        col .prop (props ,"random_seed")
        row =col .row (align =True )
        row .prop (props ,"random_xy_offset")
        row .prop (props ,"random_z_offset")
        col .prop (props ,"random_z_rotation_deg")
        row =col .row (align =True )
        row .prop (props ,"random_scale_min")
        row .prop (props ,"random_scale_max")


class SMSP_PT_precision_guide (Panel ):
    bl_label ="Precision / Layout Guide"
    bl_description ='Retired compact guide panel. Use the Help icon buttons for detailed localized help.'
    bl_idname ="SMSP_PT_precision_guide"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}

    def draw (self ,context ):
        layout =self .layout
        draw_help_header (layout ,context ,'Precision / Layout','ORIENTATION_CURSOR','precision_layout_path')




def _sms_root_only_panel_poll (cls ,context):
    # This panel body is rendered by Smart Modifier's unified root section UI.
    # Hide the separate Blender child-panel header to avoid duplicate section names.
    return False

def _sms_panel_draw_guard (draw_fn ,label ):
    def _wrapped (self ,context ):
        try :
            return draw_fn (self ,context )
        except Exception :
            try :
                layout =getattr (self ,'layout',None )
                if layout is not None :
                    box =layout .box ()
                    box .label (text =_t ('Smart Modifier UI could not be drawn safely.'),icon ='ERROR')
                    box .label (text =_t ('Close and reopen the N-panel, or reload the add-on if this message persists.'),icon='NONE')
            except Exception :
                pass
            return None
    return _wrapped

SMSP_PT_precision_layout .poll =classmethod (_sms_root_only_panel_poll)
SMSP_PT_precision_guide .poll =classmethod (_sms_root_only_panel_poll)

SMSP_PT_precision_layout .draw =_sms_panel_draw_guard (SMSP_PT_precision_layout .draw ,'SMSP_PT_precision_layout')
SMSP_PT_precision_guide .draw =_sms_panel_draw_guard (SMSP_PT_precision_guide .draw ,'SMSP_PT_precision_guide')

classes =(
SMSP_Props ,
SMSP_OT_workplane_from_active ,
SMSP_OT_project_to_active_plane ,
SMSP_OT_instances_along_path ,
SMSP_OT_replace_with_active ,
SMSP_OT_randomize_selected ,
SMSP_OT_stack_selected ,
SMSP_OT_align_to_active ,
SMSP_OT_distribute_selected_axis ,
SMSP_OT_pivot_to_selection ,
SMSP_OT_pivot_to_bottom ,
SMSP_OT_drop_to_floor ,
SMSP_OT_quad_checker ,
SMSP_OT_project_to_selected_surface ,
SMSP_OT_surface_conform_modifier ,
SMSP_OT_normal_transfer_to_selected ,
SMSP_OT_rebuild_active_curve ,
SMSP_OT_add_profile_primitive ,
SMSP_OT_add_helix_path ,
SMSP_OT_selected_vertices_to_path ,
SMSP_OT_selected_objects_to_path ,
SMSP_OT_selected_edges_to_curve ,
SMSP_OT_loft_bridge_paths ,
SMSP_OT_sweep_active_profile ,
SMSP_OT_quick_symmetry ,
SMSP_OT_toggle_solo_selected ,
SMSP_OT_face_component_array ,
SMSP_OT_cad_intersect_extend ,
SMSP_OT_audit_selected ,
SMSP_OT_audit_repair ,
SMSP_OT_audit_select_issues ,
SMSP_OT_axis_slice_edit ,
)


def _unregister_retired_panel (class_name :str ):
    cls =getattr (bpy .types ,str (class_name or ''),None )
    if cls is None :
        return 
    try :
        pass  # session-stable: keep classes registered during live UI
    except Exception :
        pass 


def register ():
    _unregister_retired_panel ("SMSP_PT_precision_layout")
    _unregister_retired_panel ("SMSP_PT_precision_guide")
    try :
        bpy .app .translations .register (__name__ ,translation_catalog_dict )
    except ValueError :
        try :
            bpy .app .translations .unregister (__name__ )
        except Exception :
            pass 
        try :
            bpy .app .translations .register (__name__ ,translation_catalog_dict )
        except Exception :
            pass 
    except Exception :
        pass 
    for cls in classes :
        _safe_register_class (cls )
    try :
        bpy .types .Scene .smsp_props =PointerProperty (type =SMSP_Props ,description ='Stores settings used by the Precision / Layout / Path operators and their Add Modifier entry points.')
    except Exception :
        pass 


def unregister ():
    _unregister_retired_panel ("SMSP_PT_precision_layout")
    _unregister_retired_panel ("SMSP_PT_precision_guide")
    try :
        _restore_solo_visibility (bpy .context )
    except Exception :
        pass 
    if hasattr (bpy .types .Scene ,'smsp_props'):
        del bpy .types .Scene .smsp_props 
    for cls in reversed (classes ):
        _safe_unregister_class (cls )
    for group in list (bpy .data .node_groups ):
        try :
            if (int (group .get (_SWEEP_GROUP_SCHEMA_PROP ,0 )or 0 )==_SWEEP_GROUP_SCHEMA 
            and bool (group .get ("sms_owned_node_group",False ))
            and int (getattr (group ,"users",0 )or 0 )==0 ):
                bpy .data .node_groups .remove (group )
        except Exception :
            pass
    try :
        bpy .app .translations .unregister (__name__ )
    except Exception :
        pass
# --- Toolset complete i18n override START ---
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', '+X to -X'): '+X から -X',
 ('*', '+Y to -Y'): '+Y から -Y',
 ('*', '+Z to -Z'): '+Z から -Z',
 ('*', '-X to +X'): '-X から +X',
 ('*', '-Y to +Y'): '-Y から +Y',
 ('*', '-Z to +Z'): '-Z から +Z',
 ('*', 'Add Normal Transfer'): '法線転送を追加',
 ('*', 'Configured normal transfer modifiers on selected targets'): '選択ターゲットに法線転送モディファイアを設定しました',
 ('*', 'Configured surface conform modifiers on selected targets'): '選択ターゲットに面追従モディファイアを設定しました',
 ('*', 'Conform Method'): '追従方法',
 ('*', 'Distribute along world X.'): 'ワールドX方向に均等配置します。',
 ('*', 'Distribute along world Y.'): 'ワールドY方向に均等配置します。',
 ('*', 'Distribute along world Z.'): 'ワールドZ方向に均等配置します。',
 ('*', 'Failed to add conform modifiers to the selected targets'): '選択ターゲットへ追従モディファイアを追加できませんでした。',
 ('*', 'Failed to add normal transfer modifiers to the selected targets'): '選択ターゲットへ法線転送モディファイアを追加できませんでした。',
 ('*', 'Need an active source mesh and at least one other selected target mesh'): 'アクティブなソースメッシュと、他に1つ以上の選択ターゲットメッシュが必要です。',
 ('*', 'Non-Quads'): '非四角面',
 ('*', 'Normal Mix'): '法線ミックス',
 ('*', 'Quads'): '四角面',
 ('*', 'Select every non-quad face.'): 'すべての非四角面を選択します。',
 ('*', 'Select every quad face.'): 'すべての四角面を選択します。',
 ('*', 'Select ngon faces on the active mesh.'): 'アクティブメッシュのNゴン面を選択します。',
 ('*', 'Select only faces with 5 or more sides.'): '5辺以上の面だけを選択します。',
 ('*', 'Select only triangles.'): '三角面だけを選択します。',
 ('*', 'Select triangle faces on the active mesh.'): 'アクティブメッシュの三角面を選択します。',
 ('*', 'Select zero-area faces on the active mesh.'): 'アクティブメッシュの面積ゼロの面を選択します。',
 ('*', 'Stack along world X.'): 'ワールドX方向にスタック配置します。',
 ('*', 'Stack along world Y.'): 'ワールドY方向にスタック配置します。',
 ('*', 'Stack along world Z.'): 'ワールドZ方向にスタック配置します。',
 ('*', 'Stores settings used by the Precision / Layout / Path operators and their Add Modifier entry points.'): 'Precision / Layout / Path '
                                                                                                                'オペレーターと「モディファイアを追加」側の実行設定を保持します。',
 ('*', 'Stores the latest compact mesh audit summary for display in the panel.'): 'パネル表示用の最新の簡易メッシュ監査サマリーを保持します。',
 ('*', '• Floor placement: Drop To Floor snaps selected objects to a shared floor height without needing a surface target.'): '• 床配置: Drop '
                                                                                                                              'To Floor '
                                                                                                                              'は、面ターゲットを使わずに選択オブジェクトを共通の床高へスナップします。',
 ('*', '• Shading weld: Normal Transfer Modifier keeps floating details visually welded to the active source.'): '• 陰影の一体化: Normal '
                                                                                                                 'Transfer Modifier '
                                                                                                                 'で浮かせた部品の陰影をアクティブなソースへ揃えられます。',
 ('*', '• Surface conform: Surface Conform Modifier adds shrinkwrap-style follow and optional normal transfer.'): '• 面追従: Surface Conform '
                                                                                                                  'Modifier で Shrinkwrap '
                                                                                                                  '追従と任意の法線転送を追加できます。',
 ('*', '• Topology spot-check: Quad Checker highlights quads / non-quads / tris / ngons before bevel, export, or subdivision.'): '• '
                                                                                                                                 'トポロジー確認: '
                                                                                                                                 'Quad '
                                                                                                                                 'Checker '
                                                                                                                                 'は、ベベル、書き出し、サブディビジョン前に四角面 '
                                                                                                                                 '/ 非四角面 / '
                                                                                                                                 '三角面 / '
                                                                                                                                 'Nゴンを強調表示します。'})
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', 'Operation failed'): '操作に失敗しました'})
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', 'No matching faces were found'): '条件に合う面はありませんでした'})
# --- Toolset complete i18n override END ---


translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Smart Modifier UI could not be drawn safely.'): 'Smart Modifier UIを安全に描画できませんでした。',
    ('*', 'Close and reopen the N-panel, or reload the add-on if this message persists.'): 'この表示が続く場合は、Nパネルを閉じて開き直すか、アドオンを再読み込みしてください。',
})
