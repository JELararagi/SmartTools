# Smart Modifier 1.0.0

Blender 5.1.2 対応。モディファイアの設定を状態セットに保存し、あとから比較や復元ができます。画面例と操作手順は [Smart Modifier 解説・ヘルプ](https://jelararagi.github.io/SmartTools/manuals/SmartModifier/) をご覧ください。

For Blender 5.1.2. Save modifier settings as a state set to compare or restore them later. See the [Smart Modifier guide](https://jelararagi.github.io/SmartTools/en/manuals/SmartModifier/) for screenshots and step-by-step instructions.
