# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

try :
    from .translation import choose_text as _sms_choose_text
except Exception :
    def _sms_choose_text (en ,ja ='' ,context =None ):
        return str (en or ja or '')

bl_info ={
"name":"Smart Modifier Suite",
"author":"JELararagi",
    "version": (4, 32, 47),
"blender":(5, 1, 0),
"location":_sms_choose_text ("N-panel > Smart Modifier / Smart Tools Manager controlled editors","Nパネル > Smart Modifier / Smart Tools Manager 管理対象エディター"),
"description":_sms_choose_text ("Smart Modifier is shown as a standard N-panel category named Smart Modifier in all supported editor sidebars controlled by Smart Tools Manager.","Smart Modifier を、Smart Tools Manager が制御する対応エディターの標準Nパネルカテゴリ Smart Modifier に表示します。"),
"category":"3D View",
}

import importlib 
import sys 
import time 
import gc
import types
import bpy 
from . import feature_toggle as _feature_toggle
from . import persistent_state
from . import transform_guard as _transform_guard
from . import icons as _sms_icons
from bpy .app .handlers import persistent 

ADDON_ROOT_MODULE =str (__package__ or __name__ .rpartition ('.')[0 ]or __name__ )


def _ms_suppress_ui_panel_bodies(seconds: float = 0.5) -> None:
    try:
        dn = bpy.app.driver_namespace
        until = time.time() + max(0.05, float(seconds or 0.0))
        dn['_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL'] = max(float(dn.get('_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL', 0.0) or 0.0), until)
    except Exception:
        pass


def _sms_patch_loaded_smart_modifier_body_gates() -> bool:
    """Force all loaded Smart Modifier UI modules to keep section bodies visible.

    This also covers live-update sessions where Blender keeps an older registered
    Panel class or Smart Tools Manager wrapper alive after a new ZIP has been
    installed.  Old draw functions still resolve this global name in their own
    module dictionary, so replacing the body gate removes header-only redraws
    without unregistering panel classes during an active UI session.
    """
    patched_any = False

    def _stable_body_allowed(context, section_key):
        del context, section_key
        return True

    try:
        setattr(_stable_body_allowed, '_sms_smart_modifier_no_flicker_body_gate', True)
    except Exception:
        pass
    for module_name, module in tuple(sys.modules.items()):
        if module is None:
            continue
        try:
            current_gate = getattr(module, '_ms_unified_section_body_allowed', None)
        except Exception:
            current_gate = None
        if not callable(current_gate):
            continue
        if bool(getattr(current_gate, '_sms_smart_modifier_no_flicker_body_gate', False)):
            patched_any = True
            continue
        try:
            marker_blob = ' '.join(str(value or '').lower() for value in (
                module_name,
                getattr(module, '__name__', ''),
                getattr(module, '__package__', ''),
                getattr(module, '__file__', ''),
            ))
        except Exception:
            marker_blob = str(module_name or '').lower()
        if 'smart_modifier' not in marker_blob and 'smart modifier' not in marker_blob:
            continue
        try:
            setattr(module, '_ms_unified_section_body_allowed', _stable_body_allowed)
            patched_any = True
        except Exception:
            pass
    return bool(patched_any)


def _sms_iter_loaded_smart_tools_manager_modules():
    """Yield loaded Smart Tools Manager modules that own panel proxy gating."""
    for module_name, module in tuple(sys.modules.items()):
        if module is None:
            continue
        try:
            ready = getattr(module, '_panel_draw_context_is_ready', None)
        except Exception:
            ready = None
        if not callable(ready):
            continue
        try:
            marker_blob = ' '.join(str(value or '').lower() for value in (
                module_name,
                getattr(module, '__name__', ''),
                getattr(module, '__package__', ''),
                getattr(module, '__file__', ''),
            ))
        except Exception:
            marker_blob = str(module_name or '').lower()
        if 'smart_tools_manager' not in marker_blob and 'smart tools manager' not in marker_blob:
            continue
        try:
            tool_by_key = getattr(module, '_TOOL_BY_KEY', {}) or {}
            if 'SMART_MODIFIER' not in tool_by_key and not hasattr(module, '_OBJECT_CONTEXT_PANEL_TOOLS'):
                continue
        except Exception:
            pass
        yield module


def _sms_patch_smart_tools_manager_panel_stability(context=None) -> bool:
    """Keep Smart Modifier bodies drawn inside Smart Tools Manager proxies.

    Smart Tools Manager intentionally waits for a quiet context before drawing
    object-context panels.  For Smart Modifier that delay makes the root header
    remain visible while section bodies are skipped during viewport orbit/pan/
    zoom, which appears as a flickering N-panel.  Smart Modifier's own panel draw
    path is guarded and renders stable warnings when a sub-section is invalid, so
    only the Manager-side quiet wait for the SMART_MODIFIER tool is bypassed.
    """
    del context
    _sms_patch_loaded_smart_modifier_body_gates()
    patched_any = False
    for manager_module in _sms_iter_loaded_smart_tools_manager_modules():
        try:
            current_ready = getattr(manager_module, '_panel_draw_context_is_ready', None)
        except Exception:
            current_ready = None
        if not callable(current_ready):
            continue
        if bool(getattr(current_ready, '_sms_smart_modifier_no_flicker_wrapper', False)):
            patched_any = True
            continue
        original_ready = current_ready

        def _sms_smart_modifier_stable_draw_ready(tool_key, context_arg, *, source_cls=None, editor_key=None, _orig=original_ready, _module=manager_module):
            try:
                key = str(tool_key or '')
            except Exception:
                key = ''
            if key == 'SMART_MODIFIER':
                try:
                    is_registered = getattr(_module, '_panel_is_registered', None)
                    if callable(is_registered) and source_cls is not None and not bool(is_registered(source_cls)):
                        return False
                except Exception:
                    pass
                try:
                    if source_cls is not None and bool(getattr(source_cls, 'is_registered', True)) is False:
                        return False
                except Exception:
                    pass
                return True
            try:
                return bool(_orig(tool_key, context_arg, source_cls=source_cls, editor_key=editor_key))
            except TypeError:
                try:
                    return bool(_orig(tool_key, context_arg))
                except Exception:
                    return False
            except Exception:
                return False

        try:
            _sms_smart_modifier_stable_draw_ready._sms_smart_modifier_no_flicker_wrapper = True
            _sms_smart_modifier_stable_draw_ready._sms_smart_modifier_original_ready = original_ready
            setattr(manager_module, '_panel_draw_context_is_ready', _sms_smart_modifier_stable_draw_ready)
            try:
                setattr(manager_module, '_sms_smart_modifier_no_flicker_patch', True)
            except Exception:
                pass
            patched_any = True
        except Exception:
            pass
    return bool(patched_any)


def _sms_smart_tools_manager_panel_stability_timer():
    """Terminate the old permanent loaded-module scan timer."""
    try:
        _sms_patch_smart_tools_manager_panel_stability(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _sms_register_smart_tools_manager_panel_stability_patch():
    """Apply the integration patch once, with no background polling."""
    try:
        _sms_patch_loaded_smart_modifier_body_gates()
    except Exception:
        pass
    try:
        _sms_patch_smart_tools_manager_panel_stability(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_sms_smart_tools_manager_panel_stability_timer):
            timers.unregister(_sms_smart_tools_manager_panel_stability_timer)
    except Exception:
        pass


def _sms_unregister_smart_tools_manager_panel_stability_patch():
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_sms_smart_tools_manager_panel_stability_timer):
            timers.unregister(_sms_smart_tools_manager_panel_stability_timer)
    except Exception:
        pass


def _addon_root_from_package (package_name =None ,module_name =None ,suite_basename ="smart_modifier_suite"):
    candidates =[]
    for value in (package_name ,module_name ,__package__ ,__name__ .rpartition ('.')[0 ],__name__ ):
        text =str (value or '').strip ().strip ('.')
        if text and text not in candidates :
            candidates .append (text )
    suite_token =str (suite_basename or '').strip ().lower ()
    for text in candidates :
        parts =[part for part in text .split ('.')if part ]
        if not parts :
            continue 
        if suite_token :
            for index ,part in enumerate (parts ):
                if str (part or '').strip ().lower ()==suite_token :
                    return '.'.join (parts [:index +1 ])
        return text 
    return str (ADDON_ROOT_MODULE or suite_basename )


def get_addon_preferences (context =None ,package_name =None ,module_name =None ,module_file =None ):
    # Smart Modifier does not expose or read Addon Preferences properties.
    # All configurable UI state is owned by the N-panel WindowManager settings.
    del package_name ,module_name ,module_file
    try :
        from .preferences import get_preferences as _ms_get_window_settings 
        prefs =_ms_get_window_settings (context )
        if prefs is not None and hasattr (prefs ,"use_modifier_stack"):
            return prefs 
    except Exception :
        pass 
    return None 


def _ms_clear_transform_guard_driver_namespace() -> None:
    try:
        dn = getattr(getattr(bpy, 'app', None), 'driver_namespace', {})
        for key in (
            '_SMSM_TRANSFORM_GUARD_ACTIVE_V1',
            '_SMSM_TRANSFORM_GUARD_SESSION_V1',
            '_SMSM_TRANSFORM_GUARD_UNTIL_V1',
            '_SMSM_TRANSFORM_GUARD_TIMER_ARMED_V1',
            '_SMSM_TRANSFORM_GUARD_REASON_V1',
        ):
            try:
                dn.pop(key, None)
            except Exception:
                pass
    except Exception:
        pass


def _ms_neutralize_legacy_input_runtime(root_id=None) -> None:
    """Disable stale runtime hooks from older package names before registration.

    Older builds could leave a persistent Drag Clone modal watcher or transform
    restore timer alive when the add-on was reinstalled under a different package
    name.  Those resources see raw View3D input and can make Blender's native
    selection, viewport navigation, or transform controls appear unusable.  This
    cleanup is intentionally non-destructive: it flips old module flags off and
    unregisters known timers/handlers when their Python function object is still
    available.
    """
    root = str(root_id or '').strip()
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    except Exception:
        timers = None
    for module_name, module in list(sys.modules.items()):
        try:
            if module is None:
                continue
            name = str(module_name or '')
            if root and (name == root or name.startswith(root + '.')):
                continue
            lower = name.lower()
            if not (
                'smart_modifier_suite' in lower
                or lower.endswith('max_shift_drag_clone')
                or lower.endswith('transform_guard')
            ):
                continue
            if lower.endswith('max_shift_drag_clone'):
                for attr in ('_MSDC_MODAL_ACTIVE', '_MSDC_WATCHER_ENABLED', '_MSDC_WATCHER_RUNNING', '_MSDC_FORCE_START'):
                    try:
                        setattr(module, attr, False)
                    except Exception:
                        pass
                for fn_name in ('_manual_key_modifier_watcher_timer', '_start_manual_key_modifier_watcher'):
                    try:
                        fn = getattr(module, fn_name, None)
                        if fn is not None and timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(fn):
                            timers.unregister(fn)
                    except Exception:
                        pass
            for owner_name in ('_MS_RUNTIME_SCENE_MSGBUS_OWNER', '_MS_INSTANCE_MSGBUS_OWNER'):
                try:
                    owner = getattr(module, owner_name, None)
                    if owner is not None:
                        bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
            if lower.endswith('transform_guard'):
                try:
                    fn = getattr(module, '_restore_timer', None)
                    if fn is not None and timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    pass
                try:
                    unregister_fn = getattr(module, 'unregister', None)
                    if callable(unregister_fn):
                        unregister_fn()
                except Exception:
                    pass
        except Exception:
            continue
    _ms_clear_transform_guard_driver_namespace()

_MS_IDLE_POLL_TIMER_NAMES = {
    '_auto_save_timer',
    '_autosave_timer',
    '_ms_userpref_save_observer_timer',
    '_ms_instance_sync_timer',
    '_ms_shape_proxy_maintenance_timer',
    '_sms_smart_tools_manager_panel_stability_timer',
    '_autorefresh_timer',
    '_ms_realtime_properties_timer',
    '_manual_key_modifier_watcher_timer',
    '_restore_timer',
    '_event_save_timer',
    '_autorefresh_event_timer',
    '_ms_instance_event_sync_timer',
    '_ms_shape_proxy_cleanup_timer',
}

_MS_STALE_HANDLER_NAMES = {
    'ms_selection_handler',
    '_ms_properties_runtime_scene_change_post',
    '_ms_properties_runtime_load_pre',
    '_ms_properties_runtime_load_post',
    '_ms_core_services_load_post',
    '_ms_instance_nodes_depsgraph_post',
    '_ms_properties_runtime_save_pre',
    '_ms_properties_runtime_undo_redo_post',
    '_load_post_handler',
    '_ms_instance_sync_depsgraph_handler',
    '_autorefresh_depsgraph_handler',
}


def _ms_is_smart_modifier_callable(fn) -> bool:
    try:
        module_name = str(getattr(fn, '__module__', '') or '').lower()
        code_file = str(getattr(getattr(fn, '__code__', None), 'co_filename', '') or '').lower()
        return ('smart_modifier_suite' in module_name or 'smart_modifier_suite' in code_file)
    except Exception:
        return False


def _ms_unregister_stale_idle_polling_runtime() -> None:
    """Remove recurring callbacks left by current or older package builds.

    Blender can retain a timer's old function object through an in-session ZIP
    replacement.  The GC scan is performed once during registration and targets
    only known Smart Modifier polling callbacks.
    """
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    except Exception:
        timers = None
    candidates = set()
    try:
        for module_name, module in tuple(sys.modules.items()):
            if module is None:
                continue
            blob = ' '.join((str(module_name or ''), str(getattr(module, '__name__', '') or ''), str(getattr(module, '__file__', '') or ''))).lower()
            if 'smart_modifier_suite' not in blob:
                continue
            for fn_name in _MS_IDLE_POLL_TIMER_NAMES:
                try:
                    fn = getattr(module, fn_name, None)
                    if isinstance(fn, types.FunctionType):
                        candidates.add(fn)
                except Exception:
                    pass
    except Exception:
        pass
    try:
        for obj in gc.get_objects():
            try:
                if not isinstance(obj, types.FunctionType):
                    continue
                if str(getattr(obj, '__name__', '') or '') not in _MS_IDLE_POLL_TIMER_NAMES:
                    continue
                if _ms_is_smart_modifier_callable(obj):
                    candidates.add(obj)
            except Exception:
                continue
    except Exception:
        pass
    if timers is not None and hasattr(timers, 'is_registered'):
        for fn in tuple(candidates):
            try:
                if timers.is_registered(fn):
                    timers.unregister(fn)
            except Exception:
                pass

    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            for seq_name in ('depsgraph_update_post', 'load_pre', 'load_post', 'save_pre', 'undo_post', 'redo_post'):
                sequence = getattr(handlers, seq_name, None)
                if sequence is None:
                    continue
                for fn in tuple(sequence):
                    try:
                        if str(getattr(fn, '__name__', '') or '') in _MS_STALE_HANDLER_NAMES and _ms_is_smart_modifier_callable(fn):
                            sequence.remove(fn)
                    except Exception:
                        pass
    except Exception:
        pass

def preflight_cleanup (package_name =None ,module_name =None ,module_file =None ):
    root_id =_addon_root_from_package (package_name ,module_name )
    try :
        _ms_neutralize_legacy_input_runtime(root_id)
    except Exception :
        pass
    try:
        _ms_unregister_stale_idle_polling_runtime()
    except Exception:
        pass
    current_file =str (module_file or __file__ or '')
    current_dir =''
    try :
        import os 
        current_dir =os .path .dirname (current_file )
    except Exception :
        current_dir =''

    legacy_names =(
    "smart_modifier_suite",
    "Smart_Modifier_Suite",
    "runtime",
    "core",
    "handlers",
    "operators",
    "preferences",
    "properties",
    "pseudo_properties",
    "navigation_properties",
    "ui",
    "advanced_tools",
    "hub",
    "precision_tools",
    "bootstrap_common",
    )
    for legacy_name in legacy_names :
        if legacy_name ==root_id or legacy_name .startswith (str (root_id or '')+'.'):
            continue 
        module =sys .modules .get (legacy_name )
        if module is None :
            continue 
        module_path =str (getattr (module ,'__file__','')or '')
        if current_dir and module_path and current_dir not in module_path :
            continue 
        try :
            sys .modules .pop (legacy_name ,None )
        except Exception :
            pass 



# -----------------------------------------------------------------------------
# Standard N-panel mode
# -----------------------------------------------------------------------------
# Earlier builds could bridge Smart Modifier into a shared SmartTools /
# Properties-style host. That bridge is intentionally disabled here. The add-on
# registers normal Blender VIEW_3D / UI panel classes directly in the Smart
# Modifier sidebar category, and the code below only removes stale generated
# panels left in an already-running Blender session.

_MS_EXTERNAL_SHARED_NAV_INSTALLED = False


def _ms_safe_unregister_class(cls) -> bool:
    try:
        pass  # session-stable: keep classes registered during live UI
        return True
    except Exception:
        return False


def _ms_unregister_external_proxy_panels_from_registry(reg: dict, addon_key: str = 'smart_modifier_suite') -> None:
    if not isinstance(reg, dict):
        return
    for key in ('proxy_panels', 'generated_panels'):
        generated = reg.get(key)
        if not isinstance(generated, dict):
            continue
        classes = generated.pop(addon_key, ())
        for cls in reversed(tuple(classes or ())) :
            _ms_safe_unregister_class(cls)


def _ms_unregister_misplaced_external_smart_modifier_panels(addon_key: str = 'smart_modifier_suite') -> None:
    for name in tuple(dir(getattr(bpy, 'types', object()))):
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        if str(getattr(cls, 'bl_category', '') or '').strip() == 'Smart Modifier':
            continue
        owner = str(
            getattr(cls, '_smart_suite_clone_owner', '')
            or getattr(cls, '_smart_tools_clone_owner', '')
            or ''
        ).strip()
        blob = ' '.join(str(value or '').lower() for value in (
            getattr(cls, '__name__', ''),
            getattr(cls, 'bl_idname', ''),
            getattr(cls, '__module__', ''),
        ))
        if owner == addon_key or (addon_key in blob and str(getattr(cls, 'bl_category', '') or '').strip() == 'Smart File'):
            _ms_safe_unregister_class(cls)


def _ms_iter_loaded_external_nav_modules():
    current_root = str(ADDON_ROOT_MODULE or '')
    for module_name, module in tuple(sys.modules.items()):
        name = str(module_name or '')
        if name == 'navigation_properties' or name.endswith('.navigation_properties'):
            if current_root and (name == current_root + '.navigation_properties' or name.startswith(current_root + '.')):
                continue
            yield module


def _ms_purge_external_shared_nav_registration(context=None) -> bool:
    del context
    removed = False
    addon_key = 'smart_modifier_suite'
    for module in _ms_iter_loaded_external_nav_modules():
        for attr_name in ('clear_launcher_draw_callback', 'remove_launcher_draw_callback', 'uninstall', 'remove_entry', 'unregister_entry'):
            fn = getattr(module, attr_name, None)
            if not callable(fn):
                continue
            for call in (
                lambda fn=fn: fn(addon_key),
                lambda fn=fn: fn(addon_key=addon_key),
            ):
                try:
                    call()
                    removed = True
                    break
                except TypeError:
                    continue
                except Exception:
                    removed = True
                    break
        try:
            reg_fn = getattr(module, '_registry', None) or getattr(module, '_v9_registry_prepare', None)
            reg = reg_fn() if callable(reg_fn) else None
        except Exception:
            reg = None
        if isinstance(reg, dict):
            _ms_unregister_external_proxy_panels_from_registry(reg, addon_key)
            for key in ('nav_entries', 'panel_sources', 'launcher_callbacks', 'launcher_draw_callbacks'):
                mapping = reg.get(key)
                if isinstance(mapping, dict) and addon_key in mapping:
                    mapping.pop(addon_key, None)
                    removed = True
            for owner_key in ('preferred_owner', 'active_owner'):
                if reg.get(owner_key) == addon_key:
                    reg[owner_key] = None
                    removed = True
    _ms_unregister_misplaced_external_smart_modifier_panels(addon_key)
    return removed


def _ms_register_external_shared_nav(context=None, refresh=False) -> bool:
    global _MS_EXTERNAL_SHARED_NAV_INSTALLED
    del refresh
    _ms_purge_external_shared_nav_registration(context)
    _MS_EXTERNAL_SHARED_NAV_INSTALLED = False
    return False


def _ms_unregister_external_shared_nav(context=None) -> bool:
    global _MS_EXTERNAL_SHARED_NAV_INSTALLED
    removed = _ms_purge_external_shared_nav_registration(context)
    _MS_EXTERNAL_SHARED_NAV_INSTALLED = False
    return bool(removed)


def _ms_sync_shared_window_integration(context=None, force=False) -> bool:
    del force
    _ms_purge_external_shared_nav_registration(context)
    return False


from .import translation_catalog 
from .import translation_generated 
from .import modswitcher 
from .import user_plugins 
try :
    from .subtools.edit_poly_modifier.translation import translation_dict as _ep_translation_catalog_dict 
except Exception :
    _ep_translation_catalog_dict ={}
try :
    from .subtools.lattice_modifier.translation import translation_dict as _sl_translation_catalog_dict 
except Exception :
    _sl_translation_catalog_dict ={}
from .core import *
from .operators import *
from .ui import *
from .handlers import ms_selection_handler 
from .properties import MS_InstanceMapItem 
from .import pseudo_properties 

_MIGRATED_SUBTOOLS =(
"boolean_stack_modifier",
"fill_modifier","straighten_modifier","circle_modifier",
"curve_modifier","path_modifier","vertices_path_modifier",
"pipe_modifier","array_along_curve_modifier","instances_along_path_modifier",
"loft_modifier","sweep_modifier","profile_primitive_modifier","helix_path_modifier",
"projection_modifier","project_to_active_plane_modifier",
"workplane_modifier","cad_intersect_modifier","axis_slice_modifier","rebuild_curve_modifier",
"audit_selected_modifier","audit_select_issues_modifier",
"face_component_array_modifier","floor_modifier","scatter_modifier",
"replace_modifier","randomize_modifier","align_to_active_modifier","distribute_selected_modifier","stack_selected_modifier","pivot_to_selection_modifier","pivot_to_bottom_modifier","drop_to_floor_modifier","quad_checker_modifier","solo_selected_modifier",
"extrude_modifier","slice_panel_modifier","surface_box_detail_modifier",
"drop_to_surface_modifier","detach_separate_clean_modifier","combine_join_clean_modifier",


"reset_xform_modifier","unwrap_uvw_modifier","uvw_map_modifier","max_modifier_library",
)

_CORE_STACK_SUBTOOLS =(
"reset_xform_modifier","unwrap_uvw_modifier","uvw_map_modifier","max_modifier_library",
)

_MS_RUNTIME_REFRESH_ENABLED =False 
_MS_RUNTIME_REFRESH_GENERATION =0 
_MS_RUNTIME_REFRESH_PENDING =False 
_MS_RUNTIME_LAST_REFRESH_AT =0.0 
_MS_RUNTIME_LAST_SCENE_POINTER =0 
_MS_STACK_LIVE_ACTIVE =False 
_MS_RETIRED_N_PANEL_CLASS_NAMES =(
"VIEW3D_PT_ms_live_runtime_panel",
"VIEW3D_PT_modifier_stack_panel",
"VIEW3D_PT_ms_modswitcher_main",
"VIEW3D_PT_msm_hub",
"VIEW3D_PT_msm_hub_help",
"SMSP_PT_precision_layout",
"SMSP_PT_precision_guide",
"VIEW3D_PT_sms_advanced",
"VIEW3D_PT_sms_advanced_help",
"VIEW3D_PT_sms_preflight",
"VIEW3D_PT_sms_catalog_browser",
"MODSWITCH_PT_MainPanel",
"MODSWITCH_PT_ObjectListPanel",
"MODSWITCH_PT_AdvancedPanel",
"VIEW3D_PT_edit_poly_standalone",
"VIEW3D_PT_smart_lattice_standalone",
"IMAGE_PT_smart_modifier_root_panel",
"NODE_PT_smart_modifier_root_panel",
"SEQUENCER_PT_smart_modifier_root_panel",
"CLIP_PT_smart_modifier_root_panel",
"DOPESHEET_PT_smart_modifier_root_panel",
"GRAPH_PT_smart_modifier_root_panel",
"NLA_PT_smart_modifier_root_panel",
"TEXT_PT_smart_modifier_root_panel",
"FILEBROWSER_PT_smart_modifier_root_panel",
"SPREADSHEET_PT_smart_modifier_root_panel",
)
_MS_RETIRED_N_PANEL_CATEGORY_NAMES =(
"smart modifier",
"スマート モディファイア",
)
_MS_RETIRED_N_PANEL_TOKEN_FRAGMENTS =(
"modifier stack",
"modifier_stack",
"modifier switcher",
"live runtime",
"ms modswitcher",
"modswitch",
"smart modifier hub",
"msm hub",
"precision",
"preflight",
"catalog browser",
"edit poly",
"edit_poly",
"smart lattice",
"smart_lattice",
"sms_",
)
_MS_STALE_N_PANEL_GUARD_BURST_INTERVALS =(0.25 ,0.75 ,1.50 ,3.00 ,6.00 ,12.00 )
_MS_STALE_N_PANEL_GUARD_GENERATION =0 

_DEFERRED_MIGRATED_MODULE_NAMES =(
"hub","precision_tools","advanced_tools",
)
_MS_DEFERRED_COMPONENT_STATE_KEY ="_MS_DEFERRED_COMPONENT_STATE_V1"
_MS_DEFERRED_COMPONENT_BOOTSTRAP_KEY ="_MS_ENSURE_DEFERRED_COMPONENTS_V1"
_MS_DEFERRED_COMPONENT_LOCK =False 


def _ms_package_prefixes ():
    names =[]
    for value in (__package__ ,__name__ .rpartition ('.')[0 ]):
        text =str (value or '').strip ().strip ('.')
        if not text :
            continue 
        if text not in names :
            names .append (text )
    return tuple (names )


def _ms_panel_owned_by_current_package (panel_cls )->bool :
    owner =str (getattr (panel_cls ,'__module__','')or '')
    if not owner :
        return False 
    for prefix in _ms_package_prefixes ():
        if owner ==prefix or owner .startswith (prefix +'.'):
            return True 
    return False 


def _ms_normalize_ui_text (value )->str :
    text =str (value or '').replace ('_',' ').replace ('-',' ').strip ()
    if not text :
        return ''
    return ' '.join (text .split ()).casefold ()


def _ms_loaded_module (module_suffix :str ):
    module_name =f"{ADDON_ROOT_MODULE }.{str (module_suffix or '').strip ('.')}"
    return sys .modules .get (module_name )


def _ms_import_local_module (module_suffix :str ):
    return importlib .import_module (f".{str (module_suffix or '').strip ('.')}",package =ADDON_ROOT_MODULE )


def _ms_import_subtool_module (module_name :str ):
    return importlib .import_module (f".{str (module_name or '').strip ('.')}",package =f"{ADDON_ROOT_MODULE }.subtools")


def _ms_get_deferred_component_state ():
    defaults ={
    "migrated_modules":False ,
    "migrated_subtools":False ,
    "edit_poly":False ,
    "smart_lattice":False ,
    }
    try :
        dn =bpy .app .driver_namespace 
        state =dn .get (_MS_DEFERRED_COMPONENT_STATE_KEY )
        if not isinstance (state ,dict ):
            state =dict (defaults )
            dn [_MS_DEFERRED_COMPONENT_STATE_KEY ]=state 
        else :
            for key ,value in defaults .items ():
                state .setdefault (key ,value )
        return state 
    except Exception :
        return dict (defaults )


def _ms_reset_deferred_component_state ():
    try :
        bpy .app .driver_namespace [_MS_DEFERRED_COMPONENT_STATE_KEY ]={
        "migrated_modules":False ,
        "migrated_subtools":False ,
        "edit_poly":False ,
        "smart_lattice":False ,
        }
    except Exception :
        pass 


def _ms_pref_enabled (pref_name :str ,default =True ,context =None )->bool :
    try :
        prefs =_ms_get_suite_prefs (context )
        if prefs is not None and hasattr (prefs ,pref_name ):
            return bool (getattr (prefs ,pref_name ))
    except Exception :
        pass 
    return bool (default )


def _ms_loaded_or_enabled_subtool_module (module_name :str ,enabled :bool ):
    module =_ms_loaded_module (f"subtools.{module_name }")
    if module is not None :
        return module 
    if not enabled :
        return None 
    try :
        return _ms_import_subtool_module (module_name )
    except Exception :
        return None 


def _ms_iter_retired_panel_classes ():
    modswitcher_ui =_ms_loaded_module ('modswitcher.ui')or getattr (modswitcher ,'ui',None )
    modules =(
    _ms_loaded_module ('ui'),
    _ms_loaded_module ('hub'),
    _ms_loaded_module ('precision_tools'),
    _ms_loaded_module ('advanced_tools'),
    modswitcher_ui ,
    _ms_loaded_module ('subtools.edit_poly_modifier'),
    _ms_loaded_module ('subtools.lattice_modifier'),
    )
    attrs =(
    'VIEW3D_PT_ms_live_runtime_panel',
    'VIEW3D_PT_modifier_stack_panel',
    'VIEW3D_PT_ms_modswitcher_main',
    'VIEW3D_PT_msm_hub',
    'VIEW3D_PT_msm_hub_help',
    'SMSP_PT_precision_layout',
    'SMSP_PT_precision_guide',
    'VIEW3D_PT_sms_advanced',
    'VIEW3D_PT_sms_advanced_help',
    'VIEW3D_PT_sms_preflight',
    'VIEW3D_PT_sms_catalog_browser',
    'MODSWITCH_PT_MainPanel',
    'MODSWITCH_PT_ObjectListPanel',
    'MODSWITCH_PT_AdvancedPanel',
    'VIEW3D_PT_edit_poly_standalone',
    'VIEW3D_PT_smart_lattice_standalone',
    )
    panel_classes =[]
    seen =set ()
    for module in modules :
        if module is None :
            continue 
        for attr_name in attrs :
            cls =getattr (module ,attr_name ,None )
            if cls is None :
                continue 
            key =id (cls )
            if key in seen :
                continue 
            seen .add (key )
            panel_classes .append (cls )
    return tuple (panel_classes )


def _ms_panel_matches_retired_smart_modifier_npanel (panel_cls )->bool :
    try :
        class_name =str (getattr (panel_cls ,'__name__','')or '')
        bl_idname =str (getattr (panel_cls ,'bl_idname','')or '')
        owner =str (getattr (panel_cls ,'_smart_suite_clone_owner','')or getattr (panel_cls ,'_smart_tools_clone_owner','')or '')
        if bool (getattr (panel_cls ,'_smart_suite_npanel_proxy',False ))or bool (getattr (panel_cls ,'_smart_suite_host_panel',False )):
            return True
        if owner == 'smart_modifier_suite':
            return True
        if class_name .startswith ('SMARTTOOLS_NPANEL_PT_')or class_name .startswith ('SMART_TOOLS_NPANEL_PT_'):
            token =(class_name +' '+bl_idname ).casefold ()
            return 'smart_modifier' in token or 'smart_modifier_suite' in token
    except Exception :
        pass

    space =str (getattr (panel_cls ,'bl_space_type','')or '')
    region =str (getattr (panel_cls ,'bl_region_type','')or '')
    if (space ,region )!=('VIEW_3D','UI'):
        return False

    if _ms_panel_owned_by_current_package (panel_cls ):
        return False

    class_name =str (getattr (panel_cls ,'__name__','')or '')
    bl_idname =str (getattr (panel_cls ,'bl_idname','')or '')
    category =_ms_normalize_ui_text (getattr (panel_cls ,'bl_category',''))
    if category not in _MS_RETIRED_N_PANEL_CATEGORY_NAMES :
        return False

    module_name =_ms_normalize_ui_text (getattr (panel_cls ,'__module__',''))
    label =_ms_normalize_ui_text (getattr (panel_cls ,'bl_label',''))
    name_tokens =_ms_normalize_ui_text (class_name )
    id_tokens =_ms_normalize_ui_text (bl_idname )
    token_blob =' | '.join (token for token in (module_name ,category ,label ,name_tokens ,id_tokens )if token )
    for fragment in _MS_RETIRED_N_PANEL_TOKEN_FRAGMENTS :
        if str (fragment )and str (fragment )in token_blob :
            return True
    return False



def _ms_unregister_local_smart_modifier_n_panels_by_name ():
    # Never unregister sidebar panel classes from the active UI session.  Blender
    # can retain panel button blocks across Smart Tools Manager refreshes, mode
    # toggles, and workspace switches; removing the class during that interval can
    # crash in blender::ui::ui_handler_panel.
    return False


def _ms_unregister_stale_n_panels ():
    # Class removal from inside runtime refresh is intentionally disabled for
    # crash resistance.  Stale generated panels are harmless compared with a C++
    # UI-panel access violation caused by unregistering classes during layout.
    return False 




def _ms_get_suite_prefs (context =None ):
    try :
        return get_addon_preferences (context ,__package__ ,__name__ ,__file__ )
    except Exception :
        return None 


def _ms_legacy_panels_enabled (context =None )->bool :
    """The standard N-panel path is always used for this package."""
    return False 


def _ms_wrap_panel_poll (panel_cls ):
    del panel_cls
    return None


def _ms_iter_legacy_panel_classes ():
    return []


def _ms_wrap_legacy_panel_polls ():
    return None



def _ms_cleanup_user_menu_duplicates ():
    try :
        mt =bpy .types .OBJECT_MT_ms_add_user 
        funcs =list (getattr (mt ,"_draw_funcs",[])or [])
        seen =set ()
        for fn in funcs :
            key =(getattr (fn ,"__module__",""),getattr (fn ,"__name__",""))
            if key in seen :
                try :
                    mt .remove (fn )
                except Exception :
                    try :
                        mt ._draw_funcs .remove (fn )
                    except Exception :
                        pass 
            else :
                seen .add (key )
    except Exception :
        pass 
    return None 


def _ms_merge_translation_catalog_dicts (*dicts ):
    merged ={}
    for d in dicts :
        if not isinstance (d ,dict ):
            continue 
        for lang ,table in d .items ():
            if not isinstance (table ,dict ):
                continue 
            merged .setdefault (lang ,{}).update (table )
    return merged 



def _ms_expand_translation_catalog_contexts (translation_catalog_dict ):
    try :
        from bpy .app .translations import contexts as i18n_contexts 
    except Exception :
        return translation_catalog_dict 

    ctx_default =i18n_contexts .default 
    ctx_operator =i18n_contexts .operator_default 
    expanded ={}
    for lang ,table in (translation_catalog_dict or {}).items ():
        if not isinstance (table ,dict ):
            continue 
        new_table =dict (table )
        for key ,value in list (table .items ()):
            if not (isinstance (key ,tuple )and len (key )==2 and isinstance (key [1 ],str )):
                continue 
            ctx ,msgid =key 
            if ctx ==ctx_default and (ctx_operator ,msgid )not in new_table :
                new_table [(ctx_operator ,msgid )]=value 
            elif ctx ==ctx_operator and (ctx_default ,msgid )not in new_table :
                new_table [(ctx_default ,msgid )]=value 
        expanded [lang ]=new_table 
    return expanded 


class MS_OT_toggle_properties_pseudo_tab (bpy .types .Operator ):
    bl_idname ="smart_modifier_suite.toggle_properties_pseudo_tab"
    bl_label ="Smart Modifier"
    bl_description ='Refresh and focus the Smart Modifier N-panel entry. Use this compatibility operator when an older shortcut still points to the previous Smart Tools command.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod 
    def poll (cls ,context ):
        return getattr (getattr (context ,"window_manager",None ),"windows",None )is not None

    def execute (self ,context ):
        return {'FINISHED'}if open_smart_tools_window (context =context ,reuse_existing =True )else {'CANCELLED'}


def _ms_properties_panel_classes ():
# The Smart Modifier N-panel uses a single standard Blender parent panel.
# The root panel draws the collapsed Always-on Toggles box at the top.
# Child panels are ordered as Modifier Stack, Modifier Switcher, Settings, then the bundled tool catalog.
    panels =[
    VIEW3D_PT_smart_modifier_root_panel ,
    ]
    ordered =[]
    seen =set ()
    for cls in panels :
        if cls is None or cls in seen :
            continue 
        seen .add (cls )
        ordered .append (cls )
    return ordered 


def _ms_prepare_properties_panels ():
    return tuple (_ms_properties_panel_classes ())


def _ms_install_properties_pseudo_tab ():
    try :
        _ms_purge_external_shared_nav_registration (getattr (bpy ,'context',None ))
    except Exception :
        pass
    try :
        pseudo_properties .uninstall ('smart_modifier_suite')
    except Exception :
        pass
    try :
        _ms_unregister_stale_n_panels ()
    except Exception :
        pass
    try :
        _ms_hide_registered_unified_child_panels()
    except Exception :
        pass


def _ms_uninstall_properties_pseudo_tab ():
    try :
        _ms_unregister_external_shared_nav (getattr (bpy ,'context',None ))
    except Exception :
        pass
    try :
        pseudo_properties .uninstall ('smart_modifier_suite')
    except Exception :
        pass
    try :
        _ms_unregister_stale_n_panels ()
    except Exception :
        pass


def _ms_refresh_properties_pseudo_runtime ():
    global _MS_RUNTIME_LAST_REFRESH_AT
    try :
        _ms_purge_external_shared_nav_registration (getattr (bpy ,'context',None ))
    except Exception :
        pass
    try :
        pseudo_properties .uninstall ('smart_modifier_suite')
    except Exception :
        pass
    try :
        _ms_unregister_stale_n_panels ()
    except Exception :
        pass
    try :
        _ms_tag_view3d_npanel_redraw ()
    except Exception :
        pass
    try :_MS_RUNTIME_LAST_REFRESH_AT =time .time ()
    except Exception :pass



def _ms_tag_view3d_npanel_redraw ():
    try :
        wm =getattr (getattr (bpy ,'context',None ),'window_manager',None )
    except Exception :
        wm =None
    for window in tuple (getattr (wm ,'windows',())or ()):
        screen =getattr (window ,'screen',None )
        for area in tuple (getattr (screen ,'areas',())or ()):
            try :
                if str (getattr (area ,'type','')or '')=='VIEW_3D':
                    area .tag_redraw ()
            except Exception :
                pass


def _ms_schedule_runtime_refresh_burst ():
    # Standard N-panel mode has no generated proxy panels to refresh.  Do not
    # schedule delayed panel cleanup while Blender may be laying out Panel.draw
    # callbacks; unregistering or mutating panel classes during layout can make
    # Blender unstable.
    return None


def _ms_get_runtime_window_manager (context =None ):
    try :
        ctx =context or bpy .context 
        return getattr (ctx ,"window_manager",None )
    except Exception :
        return None 


def _ms_runtime_core_state_persistence_enabled (context =None )->bool :
    wm =_ms_get_runtime_window_manager (context )
    if wm is None :
        return True 
    try :
        return bool (getattr (wm ,"sms_runtime_core_state_persistence",True ))
    except Exception :
        return True 


def _ms_runtime_stack_live_enabled (context =None )->bool :
    """Enable stack callbacks only during an explicit edit session.

    Keeping the sidebar open in Object Mode must not install a timer or a
    dependency-graph callback. Stack operators apply their state directly.
    """
    wm = _ms_get_runtime_window_manager(context)
    try:
        if wm is None or not bool(getattr(wm, 'sms_runtime_stack_live_sync', False)):
            return False
    except Exception:
        return False
    try:
        ctx = context or bpy.context
        mode = str(getattr(ctx, 'mode', '') or '')
    except Exception:
        mode = ''
    if not mode.startswith('EDIT'):
        return False
    try :
        if ms_modifier_stack_panel_is_recent (None ,max_age =1.50 ):
            return True
    except Exception :
        pass
    try :
        dn = bpy.app.driver_namespace
        if float(dn.get('_MS_STACK_ON_DEMAND_UNTIL', 0.0) or 0.0) > time.time():
            return True
    except Exception :
        pass
    return False


def _ms_runtime_edit_poly_live_enabled (context =None )->bool :
    wm = _ms_get_runtime_window_manager(context)
    try :
        return bool (wm is not None and getattr(wm, 'sms_runtime_edit_poly_live_sync', False))
    except Exception :
        return False 


def _ms_runtime_smart_lattice_live_enabled (context =None )->bool :
    wm = _ms_get_runtime_window_manager(context)
    try :
        return bool (wm is not None and getattr(wm, 'sms_runtime_smart_lattice_live_sync', False))
    except Exception :
        return False 


def _ms_has_loaded_optional_modifier (kind :str )->bool :
    """Detect only durable Edit Polygon or Smart Lattice rows after a file load."""
    try :
        for obj in tuple (getattr (bpy .data ,"objects",())or ()):
            for mod in tuple (getattr (obj ,"modifiers",())or ()):
                if kind =='edit_poly':
                    group =getattr (mod ,"node_group",None )
                    if group is not None and group .get ("ep_edit_mesh")is not None and group .get ("ep_frozen_mesh")is not None :
                        return True
                elif kind =='smart_lattice':
                    lattice =getattr (mod ,"object",None )
                    if str (getattr (mod ,"type","")or "")=='LATTICE'and lattice is not None and "sl_main_target"in lattice :
                        return True
    except Exception :
        pass
    return False 


def _ms_enable_runtime_flag (attr_name :str ,context =None ):
    wm =_ms_get_runtime_window_manager (context )
    if wm is None or not hasattr (wm ,attr_name ):
        return False 
    try :
        if bool (getattr (wm ,attr_name ,False )):
            return True 
        setattr (wm ,attr_name ,True )
        return True 
    except Exception :
        return False 


def _ms_disable_runtime_flag (attr_name :str ,context =None ):
    wm =_ms_get_runtime_window_manager (context )
    if wm is None or not hasattr (wm ,attr_name ):
        return False 
    try :
        if not bool (getattr (wm ,attr_name ,False )):
            return True 
        setattr (wm ,attr_name ,False )
        return True 
    except Exception :
        return False 


def _ms_update_stack_live_runtime (context =None ):
    global _MS_STACK_LIVE_ACTIVE
    enabled = bool(_ms_runtime_stack_live_enabled(context))
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
    except Exception:
        handlers = None

    # The old realtime-properties timer woke Blender continuously whenever the
    # panel stayed visible. EndPreview owns its active-edit timer, while actual
    # data changes are handled by the event callback below.
    try:
        if hasattr(bpy.app.timers, 'is_registered') and bpy.app.timers.is_registered(_ms_realtime_properties_timer):
            bpy.app.timers.unregister(_ms_realtime_properties_timer)
    except Exception:
        pass

    registered = bool(handlers is not None and ms_selection_handler in handlers)
    if not enabled:
        if registered and handlers is not None:
            try:
                while ms_selection_handler in handlers:
                    handlers.remove(ms_selection_handler)
            except Exception:
                pass
        _MS_STACK_LIVE_ACTIVE = False
        # Instance value linking does not depend on this switch: its message-bus
        # subscriptions stay dormant until a linked modifier value really changes.
        try:
            ms_register_instance_sync_timer()
        except Exception:
            pass
        return

    if handlers is not None and not registered:
        try:
            handlers.append(ms_selection_handler)
            registered = True
        except Exception:
            pass
    _MS_STACK_LIVE_ACTIVE = bool(registered)
    try:
        ms_register_instance_sync_timer()
    except Exception:
        pass


def _ms_update_edit_poly_runtime (context =None ):
    # A live request may arm the operator while it creates a row, but it must
    # never keep an owned handler alive after the final Edit Poly row is gone.
    # The durable row itself is the sole service-activation authority.
    enabled =bool (_ms_runtime_edit_poly_live_enabled(context) and _ms_has_loaded_optional_modifier ('edit_poly'))
    module =_ms_loaded_module ("subtools.edit_poly_modifier")
    if module is None and enabled :
        if _ms_register_deferred_edit_poly (context ):
            try :
                _ms_get_deferred_component_state ()["edit_poly"]=True
            except Exception :
                pass
            module =_ms_loaded_module ("subtools.edit_poly_modifier")
    if module is None :
        return 
    try :
        if hasattr (module ,"set_runtime_enabled"):
            module .set_runtime_enabled (enabled )
    except Exception :
        pass 


def _ms_update_smart_lattice_runtime (context =None ):
    # Match Edit Poly: activation follows the actual Smart Lattice modifier,
    # not a stale legacy request flag left behind by a removed row.
    enabled =bool (_ms_runtime_smart_lattice_live_enabled(context) and _ms_has_loaded_optional_modifier ('smart_lattice'))
    module =_ms_loaded_module ("subtools.lattice_modifier")
    if module is None and enabled :
        if _ms_register_deferred_smart_lattice (context ):
            try :
                _ms_get_deferred_component_state ()["smart_lattice"]=True
            except Exception :
                pass
            module =_ms_loaded_module ("subtools.lattice_modifier")
    if module is None :
        return 
    try :
        if hasattr (module ,"set_runtime_enabled"):
            module .set_runtime_enabled (enabled )
    except Exception :
        pass 


def _ms_update_core_persistence_runtime (context =None ):
    if _ms_runtime_core_state_persistence_enabled(context):
        _ms_register_load_post_handler ()
        _ms_register_userpref_save_observer ()
    else:
        _ms_unregister_load_post_handler ()


def _ms_update_runtime_services (context =None ):
    _ms_update_core_persistence_runtime (context )
    _ms_update_stack_live_runtime (context )
    _ms_update_edit_poly_runtime (context )
    _ms_update_smart_lattice_runtime (context )
    try :
        if hasattr (modswitcher ,"ensure_autorefresh_timer_state"):
            modswitcher .ensure_autorefresh_timer_state (force_rebuild =False )
    except Exception :
        pass 


def _ms_disable_all_runtime_services ():
    try :
        _ms_unregister_load_post_handler ()
    except Exception :
        pass
    try :
        persistent_state .disable_auto_save_timer ()
    except Exception :
        pass
    try :
        while ms_selection_handler in bpy .app .handlers .depsgraph_update_post :
            bpy .app .handlers .depsgraph_update_post .remove (ms_selection_handler )
    except Exception :
        pass 
    try :
        if hasattr (bpy .app .timers ,"is_registered")and bpy .app .timers .is_registered (_ms_realtime_properties_timer ):
            bpy .app .timers .unregister (_ms_realtime_properties_timer )
    except Exception :
        pass 
    for module_name in ("edit_poly_modifier","lattice_modifier"):
        module =_ms_loaded_module (f"subtools.{module_name }")
        if module is None :
            continue 
        try :
            if hasattr (module ,"set_runtime_enabled"):
                module .set_runtime_enabled (False )
        except Exception :
            pass 
    try :
        if hasattr (modswitcher ,"ensure_autorefresh_timer_state"):
            modswitcher .ensure_autorefresh_timer_state (force_rebuild =False )
    except Exception :
        pass 


def _ms_enable_stack_live_runtime (context =None ):
    try :
        bpy .app .driver_namespace ["_MS_STACK_ON_DEMAND_UNTIL"]=time .time ()+3.0
    except Exception :
        pass
    _ms_update_runtime_services (context )
    return True 


def _ms_enable_edit_poly_live_runtime (context =None ):
    try :
        bpy .app .driver_namespace ["_MS_STACK_ON_DEMAND_UNTIL"]=time .time ()+3.0
    except Exception :
        pass
    if not _ms_runtime_edit_poly_live_enabled(context):
        return False
    module =_ms_loaded_module ("subtools.edit_poly_modifier")or _ms_import_subtool_module ("edit_poly_modifier")
    try :
        if module is not None and hasattr (module ,"set_runtime_enabled"):
            module .set_runtime_enabled (True )
    except Exception :
        pass
    _ms_update_runtime_services (context )
    return True 


def _ms_enable_smart_lattice_live_runtime (context =None ):
    try :
        bpy .app .driver_namespace ["_MS_STACK_ON_DEMAND_UNTIL"]=time .time ()+3.0
    except Exception :
        pass
    if not _ms_runtime_smart_lattice_live_enabled(context):
        return False
    module =_ms_loaded_module ("subtools.lattice_modifier")or _ms_import_subtool_module ("lattice_modifier")
    try :
        if module is not None and hasattr (module ,"set_runtime_enabled"):
            module .set_runtime_enabled (True )
    except Exception :
        pass
    _ms_update_runtime_services (context )
    return True 


def _ms_wm_runtime_core_state_persistence_update (self ,context ):
    enabled = bool(getattr(self, 'sms_runtime_core_state_persistence', True))
    if enabled:
        _ms_force_save_all_npanel_state(context)
    else:
        # OFF itself is the final committed value. Afterwards even force/save
        # lifecycle paths are blocked by save_policy.
        from . import save_policy as _save_policy
        _save_policy.begin_state_save_transition()
        try:
            _ms_force_save_all_npanel_state(context)
        finally:
            _save_policy.end_state_save_transition()
    _ms_update_runtime_services (context )


def _ms_wm_runtime_stack_live_sync_update (self ,context ):
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass
    _ms_update_runtime_services (context )


def _ms_wm_runtime_edit_poly_live_sync_update (self ,context ):
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass
    _ms_update_runtime_services (context )


def _ms_wm_runtime_smart_lattice_live_sync_update (self ,context ):
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass
    _ms_update_runtime_services (context )


def _ms_object_show_end_result_update (self ,context ):
    try :
        update_show_end_result_prop (self ,context )
    except Exception :
        pass
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass


def _ms_object_auto_disable_modifiers_update (self ,context ):
    try :
        update_auto_disable_modifiers_prop (self ,context )
    except Exception :
        pass
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass


def _ms_object_show_properties_update (self ,context ):
    try :
        persistent_state .request_save (context ,immediate =True )
    except Exception :
        pass


def _ms_schedule_stale_n_panel_guard_burst ():
    return None 


_MS_USERPREF_OBSERVER_TIMER_REGISTERED =False
_MS_USERPREF_LAST_MTIME =None


def _ms_stale_n_panel_guard_timer ():
    return None 


def _ms_userpref_file_path (create =False ):
    """Return Blender's userpref.blend file path without creating a directory named userpref.blend."""
    try :
        import os
        user_resource =getattr (getattr (bpy ,'utils',None ),'user_resource',None )
        base =''
        if callable (user_resource ):
            for args ,kwargs in ((("CONFIG",),{"path":"","create":create}),(("CONFIG",),{"create":create}),):
                try :
                    value =user_resource (*args ,**kwargs )
                except TypeError :
                    continue
                except Exception :
                    continue
                if value :
                    base =str (value )
                    break
        if base :
            return os .path .join (base ,'userpref.blend')
    except Exception :
        pass
    return ''


def _ms_userpref_file_mtime ():
    try :
        import os
        path =_ms_userpref_file_path (False )
        if path and os .path .exists (path ):
            return float (os .path .getmtime (path ))
    except Exception :
        pass
    return None


def _ms_userpref_save_observer_timer ():
    """Terminate the former recurring userpref-file mtime poller."""
    global _MS_USERPREF_OBSERVER_TIMER_REGISTERED
    _MS_USERPREF_OBSERVER_TIMER_REGISTERED = False
    return None


def _ms_register_userpref_save_observer ():
    """Use property updates and lifecycle handlers, never mtime polling."""
    global _MS_USERPREF_LAST_MTIME, _MS_USERPREF_OBSERVER_TIMER_REGISTERED
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_ms_userpref_save_observer_timer):
            timers.unregister(_ms_userpref_save_observer_timer)
    except Exception:
        pass
    try:
        _MS_USERPREF_LAST_MTIME = _ms_userpref_file_mtime()
    except Exception:
        _MS_USERPREF_LAST_MTIME = None
    _MS_USERPREF_OBSERVER_TIMER_REGISTERED = False


def _ms_unregister_userpref_save_observer ():
    global _MS_USERPREF_OBSERVER_TIMER_REGISTERED
    try :
        timers =getattr (getattr (bpy ,'app',None ),'timers',None )
        if timers is not None and hasattr (timers ,'is_registered')and timers .is_registered (_ms_userpref_save_observer_timer ):
            timers .unregister (_ms_userpref_save_observer_timer )
    except Exception :
        pass
    _MS_USERPREF_OBSERVER_TIMER_REGISTERED =False


def _ms_active_scene_pointer (context =None )->int :
    try :
        ctx =context if context is not None else getattr (bpy ,'context',None )
        window =getattr (ctx ,'window',None )if ctx is not None else None
        scene =getattr (window ,'scene',None )if window is not None else None
        if scene is None and ctx is not None :
            scene =getattr (ctx ,'scene',None )
        return int (scene .as_pointer ())if scene is not None else 0
    except Exception :
        return 0


def _ms_refresh_shift_drag_clone_keymaps(ctx=None):
    try:
        from . import max_shift_drag_clone as _msdc_module
        refresh = getattr(_msdc_module, 'refresh_keymaps', None)
        if callable(refresh):
            refresh(ctx)
    except Exception:
        pass


_MS_RUNTIME_SCENE_MSGBUS_OWNER = object()
_MS_RUNTIME_MODE_MSGBUS_OWNER = object()


def _ms_runtime_scene_msgbus_notify(*_args):
    try:
        _ms_properties_runtime_scene_change_post(None, None)
    except Exception:
        pass


def _ms_register_scene_change_msgbus():
    """Observe Window.scene changes without a dependency-graph callback."""
    try:
        bpy.msgbus.clear_by_owner(_MS_RUNTIME_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, 'scene'),
            owner=_MS_RUNTIME_SCENE_MSGBUS_OWNER,
            args=(),
            notify=_ms_runtime_scene_msgbus_notify,
            options={'PERSISTENT'},
        )
        return True
    except Exception:
        return False


def _ms_unregister_scene_change_msgbus():
    try:
        bpy.msgbus.clear_by_owner(_MS_RUNTIME_SCENE_MSGBUS_OWNER)
    except Exception:
        pass


@persistent 
def _ms_properties_runtime_load_post (_dummy =None ):
    global _MS_RUNTIME_LAST_SCENE_POINTER
    # Blender just replaced bpy.app.driver_namespace.  Re-publish the shared API
    # and the subtool bridges FIRST, before anything below (or any UI redraw that
    # follows this handler) can read an empty namespace and silently no-op.
    _ms_rearm_driver_namespace_after_load ()
    # NODES modifiers preserve interface values but can discard non-interface
    # row metadata on file reload. Rehydrate only positively owned Noise groups
    # before stack instance/state restoration reads those row properties.
    try :
        from .subtools import max_modifier_library as _max_modifier_library
        _rehydrate_noise =getattr (_max_modifier_library ,'_rehydrate_noise_once_for_load',None )
        if callable (_rehydrate_noise ):
            _rehydrate_noise ()
    except Exception :
        pass
    # Lightweight restore only. It must not unregister panels or schedule panel
    # cleanup because the 3D View sidebar may redraw immediately after loading.
    ctx =getattr (bpy ,'context',None )
    try :
        from . import preferences as _preferences_module
        _preferences_module .begin_file_load (ctx )
    except Exception :
        pass
    try :
        _transform_guard.enter_transient_guard(ctx, reason="runtime_load_post", duration=1.5, use_saved_props=True)
    except Exception :
        pass
    try :
        from . import preferences as _preferences_module
        _preferences_module .load_settings (context =ctx ,force =True )
    except Exception :
        pass
    try :
        _ms_refresh_shift_drag_clone_keymaps(ctx)
    except Exception:
        pass
    try :
        persistent_state .load_panel_state (ctx)
    except Exception :
        pass
    try :
        ms_normalize_show_end_result_defaults ()
    except Exception :
        pass
    try :
        persistent_state .ensure_auto_save_timer ()
    except Exception :
        pass
    try :
        _ms_refresh_shift_drag_clone_keymaps(ctx)
    except Exception:
        pass
    _MS_RUNTIME_LAST_SCENE_POINTER =_ms_active_scene_pointer (ctx )
    try :
        _ms_register_scene_change_msgbus ()
    except Exception :
        pass
    try :
        ms_rebuild_instance_sync_after_file_load (ctx)
    except Exception :
        pass
    try :
        _ms_update_runtime_services (ctx)
    except Exception :
        pass
    try :
        ms_request_shape_proxy_cleanup ("load_post" ,force =True )
    except Exception :
        pass
    try :
        _transform_guard.enter_transient_guard(ctx, reason="runtime_load_post_complete", duration=1.0, use_saved_props=True)
    except Exception :
        pass 
    try :
        from . import preferences as _preferences_module
        _preferences_module .end_file_load (ctx )
    except Exception :
        pass


@persistent 
def _ms_properties_runtime_scene_change_post (_scene =None ,_depsgraph =None ):
    global _MS_RUNTIME_LAST_SCENE_POINTER
    ctx =getattr (bpy ,'context',None )
    current =_ms_active_scene_pointer (ctx )
    if not current or current ==_MS_RUNTIME_LAST_SCENE_POINTER :
        return
    # Close the shared write barrier before any forced preference/panel writer
    # can serialize the freshly selected Scene's defaults.  The barrier is
    # released by persistent_state.apply_panel_state only after all dynamic
    # Scene groups have been materialised and replayed synchronously.
    try :
        from . import save_policy as _save_policy_module
        _save_policy_module .begin_scene_restore (ctx )
    except Exception :
        pass
    _MS_RUNTIME_LAST_SCENE_POINTER =current 
    try :
        from . import preferences as _preferences_module
        _preferences_module .load_settings (context =ctx ,force =True )
    except Exception :
        pass
    try :
        _ms_refresh_shift_drag_clone_keymaps(ctx)
    except Exception:
        pass
    try :
        persistent_state .load_panel_state (ctx)
    except Exception :
        pass
    try :
        persistent_state .ensure_auto_save_timer ()
    except Exception :
        pass
    try :
        _ms_refresh_shift_drag_clone_keymaps(ctx)
    except Exception:
        pass
    try :
        ms_rebuild_instance_sync_after_file_load (ctx)
    except Exception :
        pass
    try :
        _ms_update_runtime_services (ctx)
    except Exception :
        pass
    try :
        ms_request_shape_proxy_cleanup ("scene_change" ,force =True )
    except Exception :
        pass


def _ms_force_save_all_npanel_state (ctx =None ):
    if ctx is None:
        ctx =getattr (bpy ,'context',None )
    try :
        from . import preferences as _preferences_module
        _preferences_module .save_settings (context =ctx ,force =True )
    except Exception :
        pass
    try :
        persistent_state .request_save (ctx ,immediate =True ,force =True )
    except Exception :
        pass
    try :
        from . import feature_toggle as _feature_toggle_module
        save_state =getattr (_feature_toggle_module ,'save_state',None )
        if callable (save_state ):
            save_state (context =ctx ,force =True )
    except Exception :
        pass
    try :
        from . import common as _common_module
        save_common =getattr (_common_module ,'save_persistent_settings',None )
        if callable (save_common ):
            save_common (ctx ,force =True )
    except Exception :
        pass


@persistent 
def _ms_properties_runtime_load_pre (_dummy =None ):
    # Never snapshot Blender RNA from ``load_pre``.  At this point Blender can
    # already expose a reset/partially detached WindowManager, so a forced write
    # would replace the canonical external settings with class defaults just
    # before ``load_post`` tries to restore them.  Every user edit is committed
    # synchronously by the property update callbacks; explicit file saves still
    # use ``_ms_properties_runtime_save_pre`` below.
    try :
        from . import preferences as _preferences_module
        _preferences_module .begin_file_load ()
    except Exception :
        pass
    return None


@persistent 
def _ms_properties_runtime_save_pre (_dummy =None ):
    _ctx =getattr (bpy ,'context',None )
    try :
        ms_cleanup_stale_shape_proxy_data (_ctx ,force =True )
    except Exception :
        pass
    try :
        ms_request_endpreview_global_purge ("save_pre")
    except Exception :
        pass
    _ms_force_save_all_npanel_state (_ctx )


def _ms_register_load_post_handler ():
    handlers =getattr (bpy .app ,'handlers',None )
    if handlers is None :
        return
    try :
        if _ms_properties_runtime_load_pre not in handlers .load_pre :
            handlers .load_pre .append (_ms_properties_runtime_load_pre)
    except Exception :
        pass
    try :
        if _ms_properties_runtime_load_post not in handlers .load_post :
            handlers .load_post .append (_ms_properties_runtime_load_post)
    except Exception :
        pass
    try :
        for _fn in tuple (handlers .depsgraph_update_post ):
            try :
                if _fn is _ms_properties_runtime_scene_change_post or (
                    str (getattr (_fn ,'__name__','')or '')=='_ms_properties_runtime_scene_change_post'
                    and 'smart_modifier_suite' in str (getattr (_fn ,'__module__','')or '').lower ()
                ):
                    handlers .depsgraph_update_post .remove (_fn)
            except Exception :
                pass
    except Exception :
        pass
    try :
        _ms_register_scene_change_msgbus ()
    except Exception :
        pass
    try :
        if _ms_properties_runtime_save_pre not in handlers .save_pre :
            handlers .save_pre .append (_ms_properties_runtime_save_pre)
    except Exception :
        pass


def _ms_register_mode_msgbus():
    """Observe Object.mode changes for Show End Result."""
    try:
        bpy.msgbus.clear_by_owner(_MS_RUNTIME_MODE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Object, 'mode'),
            owner=_MS_RUNTIME_MODE_MSGBUS_OWNER,
            args=(),
            notify=ms_endpreview_mode_msgbus_notify,
            options={'PERSISTENT'},
        )
    except Exception:
        pass


@persistent
def _ms_core_services_load_post(_dummy=None):
    """Keep services unrelated to N-panel State Save alive across file loads.

    Subscriptions and driver_namespace do not survive a load. With State Save ON
    _ms_properties_runtime_load_post rebuilds the instance services.
    """
    _ms_register_mode_msgbus()
    if _ms_properties_runtime_load_post in bpy.app.handlers.load_post:
        return
    _ms_rearm_driver_namespace_after_load()
    ctx = getattr(bpy, 'context', None)
    try:
        from .subtools import max_modifier_library as _max_modifier_library
        _max_modifier_library._rehydrate_noise_once_for_load()
    except Exception:
        pass
    try:
        persistent_state.restore_saved_state_save_off(ctx)
    except Exception:
        pass
    try:
        ms_rebuild_instance_sync_after_file_load(ctx)
    except Exception:
        pass
    try:
        _ms_update_runtime_services(ctx)
    except Exception:
        pass


def _ms_register_core_services():
    _ms_register_mode_msgbus()
    if _ms_core_services_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_ms_core_services_load_post)


def _ms_unregister_core_services():
    try:
        bpy.msgbus.clear_by_owner(_MS_RUNTIME_MODE_MSGBUS_OWNER)
    except Exception:
        pass
    while _ms_core_services_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_ms_core_services_load_post)


def _ms_unregister_load_post_handler ():
    handlers =getattr (bpy .app ,'handlers',None )
    if handlers is not None :
        for sequence ,callback in ((getattr (handlers ,'load_pre',None ),_ms_properties_runtime_load_pre ),(getattr (handlers ,'load_post',None ),_ms_properties_runtime_load_post ),(getattr (handlers ,'save_pre',None ),_ms_properties_runtime_save_pre )):
            try :
                if sequence is None :
                    continue
                while callback in sequence :
                    sequence .remove (callback)
            except Exception :
                pass
        try :
            for _fn in tuple (handlers .depsgraph_update_post ):
                if _fn is _ms_properties_runtime_scene_change_post or (
                    str (getattr (_fn ,'__name__','')or '')=='_ms_properties_runtime_scene_change_post'
                    and 'smart_modifier_suite' in str (getattr (_fn ,'__module__','')or '').lower ()
                ):
                    handlers .depsgraph_update_post .remove (_fn)
        except Exception :
            pass
    _ms_unregister_scene_change_msgbus ()
    _ms_unregister_userpref_save_observer ()


classes =(
MS_OT_toggle_properties_pseudo_tab ,
SMSM_OT_toggle_ui_section ,
MS_InstanceMapItem ,
SMS_OT_show_help ,
OBJECT_OT_ms_open_add_modifier_popup ,
OBJECT_OT_ms_copy_keymap_id ,
OBJECT_OT_ms_toggle_show_end_result ,
OBJECT_OT_sms_instance_copy ,
OBJECT_OT_sms_instance_make_unique ,
OBJECT_OT_ms_add_modifier ,
OBJECT_OT_ms_toggle_vis ,
OBJECT_OT_ms_toggle_viewport_state ,
OBJECT_OT_ms_toggle_modifier_display_flag ,
OBJECT_OT_ms_update_influence_range ,
OBJECT_OT_ms_rename_modifier ,
OBJECT_OT_ms_item_action ,
OBJECT_OT_ms_activate_stack_level_relative ,
OBJECT_OT_ms_active_stack_level_up ,
OBJECT_OT_ms_active_stack_level_down ,
OBJECT_OT_ms_move_active_modifier ,
OBJECT_OT_ms_duplicate_active_modifier ,
OBJECT_OT_ms_expand_selected_modifier_only ,
OBJECT_OT_ms_drag_reorder_modifier ,
OBJECT_OT_ms_toggle_row_expanded ,
OBJECT_OT_ms_set_all_rows_expanded ,
OBJECT_OT_ms_drag_modifier_to_object ,
OBJECT_OT_ms_begin_inline_rename ,
OBJECT_OT_ms_cancel_inline_rename ,
OBJECT_OT_ms_apply_all_stack_modifiers ,
OBJECT_OT_ms_item_menu_call ,
OBJECT_OT_ms_select_instance_members ,
OBJECT_OT_ms_make_modifier_unique ,
OBJECT_OT_ms_base_menu_call ,
VIEW3D_MT_ms_base_menu ,
VIEW3D_MT_ms_item_menu ,
OBJECT_OT_ms_switch_level ,
VIEW3D_MT_ms_add_edit_menu ,
VIEW3D_MT_ms_add_generate_menu ,
VIEW3D_MT_ms_add_deform_menu ,
VIEW3D_MT_ms_add_normals_menu ,
VIEW3D_MT_ms_add_physics_menu ,
VIEW3D_MT_ms_add_geometry_menu ,
VIEW3D_MT_ms_add_hair_menu ,
VIEW3D_MT_ms_add_instances_menu ,
VIEW3D_MT_ms_add_geometry_nodes_menu ,
*MS_USER_GROUP_MENU_CLASSES ,
OBJECT_MT_ms_add_user ,
VIEW3D_MT_ms_master_add_menu ,
VIEW3D_PT_smart_modifier_root_panel ,
)


def _safe_register_class (cls ):
    try :
        bpy .utils .register_class (cls )
        return True 
    except Exception :
        return False 


def _safe_unregister_class (cls ):
    try :
        bpy .utils .unregister_class (cls )
        return True 
    except Exception :
        return False 


def _safe_del_attr (owner ,attr_name ):
    try :
        if hasattr (owner ,attr_name ):
            delattr (owner ,attr_name )
        return True
    except Exception :
        return False




_UNIFIED_CHILD_PANEL_CLASS_NAMES = (
    'VIEW3D_PT_ms_settings_panel',
    'VIEW3D_PT_modifier_stack_panel',
    'VIEW3D_PT_ms_modswitcher_main',
    'VIEW3D_PT_ms_tool_catalog_panel',
)


def _ms_hide_registered_unified_child_panels():
    """Hide duplicate child-panel rows without unregistering classes.

    The unified root panel draws these bodies as Smart Modeling-style sections.
    Older sessions can still have the old child Panel classes registered, and
    unregistering sidebar classes during a live Blender UI session can make
    Blender's C++ panel handler read stale pointers.  poll=False removes the
    duplicate collapsed rows while keeping class objects alive.
    """
    def _hidden_child_panel_poll(cls, context):
        return False

    names = tuple(dict.fromkeys(
        tuple(_UNIFIED_CHILD_PANEL_CLASS_NAMES)
        + tuple(globals().get('_MS_RETIRED_N_PANEL_CLASS_NAMES', ()))
    ))
    for class_name in names:
        try:
            cls = getattr(bpy.types, class_name, None)
        except Exception:
            cls = None
        if cls is None or not isinstance(cls, type):
            continue
        try:
            setattr(cls, '_smart_modifier_unified_child_hidden', True)
        except Exception:
            pass
        try:
            cls.bl_category = '_Smart Modifier Retired'
        except Exception:
            pass
        try:
            cls.__module__ = '_smart_modifier_suite_retired_panel'
        except Exception:
            pass
        try:
            cls.poll = classmethod(_hidden_child_panel_poll)
        except Exception:
            pass
    try:
        from . import ui as _sms_ui_module
        hide_roots = getattr(_sms_ui_module, '_ms_hide_duplicate_smart_modifier_root_panels', None)
        if callable(hide_roots):
            hide_roots(getattr(bpy, 'context', None))
    except Exception:
        pass

def _register_builtin_classes ():
    _ms_hide_registered_unified_child_panels()
    for cls in classes :
        _safe_register_class (cls )
    _ms_hide_registered_unified_child_panels()
    try:
        from . import ui as _sms_ui_module
        hide_duplicate_panels = getattr(_sms_ui_module, '_ms_schedule_hide_duplicate_child_panels', None)
        if callable(hide_duplicate_panels):
            hide_duplicate_panels()
    except Exception:
        pass


def _unregister_builtin_classes ():
    for cls in reversed (classes ):
        _safe_unregister_class (cls )



def _ms_ensure_keymap_reference_props ():
    """Register copyable keymap-reference fields without touching existing RNA."""
    refs = (
        (
            "sms_show_end_result_keymap_id",
            "object.ms_toggle_show_end_result",
            "Copy this operator ID into Blender Preferences > Keymap to bind Show End Result on/off.",
        ),
        (
            "sms_instance_copy_keymap_id",
            "object.sms_instance_copy",
            "Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode to bind Smart Modifier Instance Copy.",
        ),
        (
            "sms_instance_make_unique_keymap_id",
            "object.sms_instance_make_unique",
            "Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode to bind Smart Modifier Instance Release.",
        ),
        (
            "sms_shift_drag_clone_keymap_id",
            "view3d.max_shift_drag_clone",
            "Copy this operator ID into Blender Preferences > Keymap to bind integrated Drag Clone manually. Smart Modifier never creates keymap items automatically.",
        ),
        (
            "sms_active_stack_level_up_keymap_id",
            "object.ms_active_stack_level_up",
            _sms_choose_text(
                "Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Up.",
                "この登録IDを Blender プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへコピーすると、Smart Modifierスタックのアクティブ階層を1つ上へ切り替えるショートカットを設定できます。",
            ),
        ),
        (
            "sms_active_stack_level_down_keymap_id",
            "object.ms_active_stack_level_down",
            _sms_choose_text(
                "Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Down.",
                "この登録IDを Blender プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへコピーすると、Smart Modifierスタックのアクティブ階層を1つ下へ切り替えるショートカットを設定できます。",
            ),
        ),
    )
    for prop_name, operator_id, desc in refs:
        try:
            if not hasattr(bpy.types.WindowManager, prop_name):
                setattr(bpy.types.WindowManager, prop_name, bpy.props.StringProperty(
                    name="Registration ID",
                    description=desc,
                    default=operator_id,
                    options={'SKIP_SAVE'},
                ))
        except Exception:
            pass
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        if wm is not None:
            for prop_name, operator_id, _desc in refs:
                if hasattr(wm, prop_name):
                    current = str(getattr(wm, prop_name, "") or "")
                    if current != operator_id:
                        setattr(wm, prop_name, operator_id)
    except Exception:
        pass


def _register_core_props ():
    _ms_ensure_keymap_reference_props()
    try:
        wm_type = bpy .types .WindowManager
        obj_type = bpy .types .Object
        existing_wm = any(hasattr(wm_type, name) for name in (
            "ms_target_mod", "ms_target_obj", "ms_move_up", "ms_move_down",
            "sms_runtime_core_state_persistence", "sms_runtime_stack_live_sync",
            "sms_runtime_edit_poly_live_sync", "sms_runtime_smart_lattice_live_sync",
        ))
        existing_obj = any(hasattr(obj_type, name) for name in (
            "ms_show_end_result", "ms_auto_disable_modifiers", "ms_show_properties", "ms_instance_map_items",
        ))
        if existing_wm or existing_obj:
            return
    except Exception:
        pass
    try :
        if hasattr (bpy .types .WindowManager ,"sms_runtime_core_state_persistence")and hasattr (bpy .types .Object ,"ms_show_end_result")and hasattr (bpy .types .Object ,"ms_instance_map_items"):
            return
    except Exception :
        pass
    _safe_del_attr (bpy .types .WindowManager ,"ms_target_mod")
    bpy .types .WindowManager .ms_target_mod =bpy .props .StringProperty ()

    _safe_del_attr (bpy .types .WindowManager ,"ms_target_obj")
    bpy .types .WindowManager .ms_target_obj =bpy .props .StringProperty ()

    _safe_del_attr (bpy .types .WindowManager ,"ms_move_up")
    bpy .types .WindowManager .ms_move_up =bpy .props .BoolProperty (
    name ="Up",
    description =(
    "Move the modifier up (change the stack order).\nHow to use: Turn this ON while the menu is open to move the modifier one step up.\nTip: Changing the order can greatly change the final result (shape)."
    ),
    update =_ms_popup_move_up_update ,
    )

    _safe_del_attr (bpy .types .WindowManager ,"ms_move_down")
    bpy .types .WindowManager .ms_move_down =bpy .props .BoolProperty (
    name ="Down",
    description =(
    "Move the modifier down (change the stack order).\nHow to use: Turn this ON while the menu is open to move the modifier one step down.\nTip: Changing the order can greatly change the final result (shape)."
    ),
    update =_ms_popup_move_down_update ,
    )

    _safe_del_attr (bpy .types .WindowManager ,"sms_runtime_core_state_persistence")
    bpy .types .WindowManager .sms_runtime_core_state_persistence =bpy .props .BoolProperty (
    name ='N-panel State Save',
    description =(
    "Function: controls whether Smart Modifier writes N-panel settings to Smart_Modifier_Suite/Smart_Modifier_Suite.json in Blender's versioned config folder. How to use: ON saves each change immediately. Turning OFF commits that OFF value once, then blocks normal, forced, save, and shutdown writes until ON is restored."
    ),
    default =True ,
    update =_ms_wm_runtime_core_state_persistence_update ,
    )

    _safe_del_attr (bpy .types .WindowManager ,"sms_runtime_stack_live_sync")
    bpy .types .WindowManager .sms_runtime_stack_live_sync =bpy .props .BoolProperty (
    name ='Modifier Stack Live Sync',
    description =(
    "Function: enables the main Modifier Stack live synchronization service, including dependency-graph callbacks and the realtime property update timer used for stack display, end-result state, and inline parameter refresh. How to use: enable it only when you want the stack panel to track changes automatically while you edit. Disable it for lighter idle performance; the related handlers and timers are removed completely."
    ),
    default =False ,
    update =_ms_wm_runtime_stack_live_sync_update ,
    )

    _safe_del_attr (bpy .types .WindowManager ,"sms_runtime_edit_poly_live_sync")
    bpy .types .WindowManager .sms_runtime_edit_poly_live_sync =bpy .props .BoolProperty (
    name ='Edit Polygon Live Sync',
    description =(
    "Function: enables Edit Polygon live synchronization, including selection tracking and edit-layer stack callbacks. How to use: enable it only while working with Edit Polygon layers that must react automatically. Disable it when not editing polygons; the live handlers remain fully stopped and the tool will not auto-enable them in the background."
    ),
    default =False ,
    update =_ms_wm_runtime_edit_poly_live_sync_update ,
    )

    _safe_del_attr (bpy .types .WindowManager ,"sms_runtime_smart_lattice_live_sync")
    bpy .types .WindowManager .sms_runtime_smart_lattice_live_sync =bpy .props .BoolProperty (
    name ='Smart Lattice Live Sync',
    description =(
    "Function: enables Smart Lattice / FFD live services, including viewport overlay drawing, lattice cleanup, and dependency-graph synchronization. How to use: enable it only while editing lattice or FFD-style deformation layers. Disable it to remove the overlay and live callbacks completely from idle operation."
    ),
    default =False ,
    update =_ms_wm_runtime_smart_lattice_live_sync_update ,
    )

    _safe_del_attr (bpy .types .Object ,"ms_show_end_result")
    bpy .types .Object .ms_show_end_result =bpy .props .BoolProperty (
    name ='Show End Result',
    description =(
    'Choose how the final evaluated stack is previewed while Modifier Auto Disable is controlling the active edit level.\nON: show the final stack result through EndPreview while the editable object stays up to the active level.\nOFF: do not generate EndPreview. When Modifier Auto Disable is ON, the viewport shows only up to the active stack level; when it is OFF, enabled modifiers remain visible.'
    ),
    default =False ,
    update =_ms_object_show_end_result_update ,
    )

    _safe_del_attr (bpy .types .Object ,"ms_auto_disable_modifiers")
    bpy .types .Object .ms_auto_disable_modifiers =bpy .props .BoolProperty (
    name ='Modifier Auto Disable',
    description =(
    'Function: temporarily turns OFF On Cage, Show in Edit Mode, Realtime Viewport, and Render for modifiers below/later than the active Smart Modifier stack item, so only the result up to the selected edit level affects the editable object.\nHow to use: turn ON for 3ds Max-style edit-level work. Before muting a row, Smart Modifier saves all four manual display states. When the row becomes active again, the Settings > Auto Disable Restore policy either restores the saved states exactly or force-enables only the display channels selected there. Turn OFF to restore the saved states without force-enabling them.'
    ),
    default =True ,
    update =_ms_object_auto_disable_modifiers_update ,
    )

    _safe_del_attr (bpy .types .Object ,"ms_show_properties")
    bpy .types .Object .ms_show_properties =bpy .props .BoolProperty (
    name ='Show Properties',
    description =(
    'Show modifier settings (numbers/sliders, etc.) inside this panel.\nON: Adjust parameters directly here.\nOFF: Keep the UI compact (settings are not changed).\nNote: Depending on the visibility state of BaseObject / EditPoly / EndPreview, changes may update in real time.'
    ),
    default =True ,
    update =_ms_object_show_properties_update ,
    )

    _safe_del_attr (bpy .types .Object ,"ms_instance_map_items")
    bpy .types .Object .ms_instance_map_items =bpy .props .CollectionProperty (type =MS_InstanceMapItem )


def _unregister_core_props ():
    for owner ,attr_name in (
    (bpy .types .Object ,"ms_instance_map_items"),
    (bpy .types .Object ,"ms_show_properties"),
    (bpy .types .Object ,"ms_auto_disable_modifiers"),
    (bpy .types .Object ,"ms_show_end_result"),
    (bpy .types .WindowManager ,"sms_runtime_smart_lattice_live_sync"),
    (bpy .types .WindowManager ,"sms_runtime_edit_poly_live_sync"),
    (bpy .types .WindowManager ,"sms_runtime_stack_live_sync"),
    (bpy .types .WindowManager ,"sms_runtime_core_state_persistence"),
    (bpy .types .WindowManager ,"ms_inline_rename_value"),
    (bpy .types .WindowManager ,"ms_inline_rename_mod"),
    (bpy .types .WindowManager ,"ms_inline_rename_obj"),
    (bpy .types .WindowManager ,"ms_move_down"),
    (bpy .types .WindowManager ,"ms_move_up"),
    (bpy .types .WindowManager ,"ms_target_obj"),
    (bpy .types .WindowManager ,"ms_target_mod"),
    ):
        _safe_del_attr (owner ,attr_name )

def _ensure_driver_namespace_api ():
    """Publish the cross-module API into ``bpy.app.driver_namespace``.

    Blender replaces that dict on every file load, so this is called both from
    registration and from the persistent ``load_post`` re-arm.  Every write is
    unconditional or adopted, which makes it idempotent.
    """
    try :
        dn =bpy .app .driver_namespace
        # The registry holds the 160 stack plugins contributed by the bundled
        # subtools and by other suites through _MS_REGISTER_PLUGIN_V1.  None of
        # that can be rebuilt from this module, so adopt the anchored dict
        # instead of minting an empty one over it.
        _ms_ns_adopt_dict (dn ,"_MS_MODIFIER_STACK_PLUGINS_V1")
        dn ["_MS_REGISTER_PLUGIN_V1"]=ms_register_plugin
        dn ["_MS_UNREGISTER_PLUGIN_V1"]=ms_unregister_plugin 
        dn ["_MS_API_V1"]={
        "get_main_object":get_main_object ,
        "get_layer_key_from_active_object":ms_get_layer_key_from_active_object ,
        "sel_cache":ms_sel_cache ,
        "sel_set":ms_sel_set ,
        "sel_get":ms_sel_get ,
        "sel_snapshot":_ms_sel_cache_snapshot ,
        "sel_restore":_ms_sel_cache_restore ,
        "capture_edit_mesh_selection_obj":_ms_capture_edit_mesh_selection_obj ,
        "apply_edit_mesh_selection":_ms_apply_edit_mesh_selection ,
        "safe_move_modifier":safe_move_modifier ,
        "calc_insert_index_above_active":ms_calc_insert_index_above_active ,
        "calc_insert_index_bottom":ms_calc_insert_index_bottom ,
        "get_stack_order":ms_get_stack_order ,
        "shared_lock_set":_ms_set_shared_lock ,
        "calc_target_insert_index":ms_calc_target_insert_index ,
        "position_new_modifiers_to_active_slot":ms_position_new_modifiers_to_active_slot ,
        "get_ui_active_id":ms_get_ui_active_id ,
        "obj_set_disp_name":ms_obj_set_disp_name ,
        "obj_set_instance_id":ms_obj_set_instance_id ,
        "group_modifiers_as_instance":ms_group_modifiers_as_instance ,
        "promote_new_modifiers_to_instances":ms_promote_new_modifiers_to_instances ,
        "sync_instance_group_from":ms_sync_instance_group_from ,
        "sync_all_instance_groups":ms_sync_all_instance_groups ,
        "next_logical_default_name":ms_next_logical_default_name ,
        "next_logical_default_name_across_objects":ms_next_logical_default_name_across_objects ,
        "endpreview_set_allowed":ms_endpreview_set_allowed ,
        "endpreview_request_cleanup":ms_request_endpreview_cleanup ,
        "apply_modifier_stack_state":apply_modifier_stack_state ,
        }
        dn ["_MS_RUNTIME_API_V1"]={
        "core_persistence_enabled":_ms_runtime_core_state_persistence_enabled ,
        "stack_live_enabled":_ms_runtime_stack_live_enabled ,
        "edit_poly_live_enabled":_ms_runtime_edit_poly_live_enabled ,
        "smart_lattice_live_enabled":_ms_runtime_smart_lattice_live_enabled ,
        "enable_stack_live":_ms_enable_stack_live_runtime ,
        "enable_edit_poly_live":_ms_enable_edit_poly_live_runtime ,
        "enable_smart_lattice_live":_ms_enable_smart_lattice_live_runtime ,
        "sync_runtime_services":_ms_update_runtime_services ,
        }
        dn [_MS_DEFERRED_COMPONENT_BOOTSTRAP_KEY ]=_ms_ensure_deferred_components
        # The deferred-component state records which subtool modules this process
        # already migrated and imported.  Minting a zeroed one after a file load
        # would contradict sys.modules and re-run the bootstrap, so adopt it.
        _state =_ms_ns_adopt_dict (dn ,_MS_DEFERRED_COMPONENT_STATE_KEY )
        for _flag in ("migrated_modules","migrated_subtools","edit_poly","smart_lattice"):
            _state .setdefault (_flag ,False )
        # Anchor this generation's re-arm entry point so any consumer, in any
        # module, can heal a wiped namespace on first touch without importing
        # runtime (see core._ms_ns_rearm / core._ms_api).
        _ms_ns_anchor_store ()[_MS_NS_REARM_KEY ]=_ensure_driver_namespace_api
    except Exception :
        pass


def _ms_rearm_driver_namespace_after_load ():
    """Re-publish the cross-module API into a freshly replaced namespace.

    Blender replaces ``bpy.app.driver_namespace`` on every file load, which
    destroyed the only reference to ``_MS_API_V1`` / ``_MS_RUNTIME_API_V1`` /
    the stack-plugin registry / the ``_EP_*`` and ``_SL_*`` bridges.  Everything
    republished here is either derived from live module state or adopted from
    the process-lifetime anchor, so running it on every load is idempotent.

    Never raises: this runs from a persistent handler and must not break foreign
    handlers or the user's file load.
    """
    try :
        _ensure_driver_namespace_api ()
    except Exception :
        pass
    for _subname in ("subtools.edit_poly_modifier","subtools.lattice_modifier"):
        try :
            _sub =sys .modules .get ("%s.%s"%(__package__ ,_subname ))
            _fn =getattr (_sub ,"ensure_driver_namespace_bridges",None )
            if callable (_fn ):
                _fn ()
        except Exception :
            pass


def _clear_driver_namespace_api ():
    try :
        dn =bpy .app .driver_namespace
        for key in (
        "_MS_REGISTER_PLUGIN_V1",
        "_MS_UNREGISTER_PLUGIN_V1",
        "_MS_MODIFIER_STACK_PLUGINS_V1",
        "_MS_API_V1",
        "_MS_RUNTIME_API_V1",
        _MS_DEFERRED_COMPONENT_BOOTSTRAP_KEY ,
        _MS_DEFERRED_COMPONENT_STATE_KEY ,
        ):
            dn .pop (key ,None )
    except Exception :
        pass
    try :
        # Release this generation's re-arm entry point, plugin registry, and
        # derived state so a disabled add-on cannot retain or republish resources
        # through the process-lifetime synthetic module.
        _store =_ms_ns_anchor_store ()
        _store .pop (_MS_NS_REARM_KEY ,None )
        _store .pop ("_MS_MODIFIER_STACK_PLUGINS_V1",None )
        _store .pop (_MS_DEFERRED_COMPONENT_STATE_KEY ,None )
        # Dormant-safe sweep of the bridge ownership marks.  The subtools drop
        # their own mark from unregister_embedded(), but that path does not run
        # on every disable, so this generation removes any mark that belongs to
        # its own module tree.  A mark left by a foreign package is never touched.
        for _owner_key in ("_EP_BRIDGE_OWNER_V1","_SL_BRIDGE_OWNER_V1"):
            _owner =_store .get (_owner_key )
            if isinstance (_owner ,str )and _owner .startswith (__package__ ):
                _store .pop (_owner_key ,None )
        _anchor_module =sys .modules .get (_MS_NS_ANCHOR_MODULE_NAME )
        if (not _store and
            getattr (_anchor_module ,_MS_NS_ANCHOR_ATTR ,None )is _store ):
            sys .modules .pop (_MS_NS_ANCHOR_MODULE_NAME ,None )
    except Exception :
        pass


def _clear_transition_state ():
    try :
        dn =bpy .app .driver_namespace 
        for _k in (
        '_MS_LEVEL_SWITCH_REQ_V1','_MS_LEVEL_SWITCH_STATE_V1','_MS_LEVEL_SWITCH_ARMED_V1',
        '_MS_TRANSITION_ACTIVE_V1','_MS_DG_PENDING_V1','_MS_DG_TIMER_ARMED_V1','_MS_DG_QUICK_SIG_V1',
        '_MS_EP_SWITCH_PENDING_V1',
        '_MS_ALLOW_MODESET_V1','_MS_ALLOW_MODESET_TOKEN_V1','_MS_ALLOW_MODESET_T_V1',
        ):
            dn .pop (_k ,None )
    except Exception :
        pass 


def _register_optional_bundled_tools ():
    if not _ms_pref_enabled ("use_modifier_switcher",True ):
        return 
    try :
        with _feature_toggle.capture_runtime('modswitcher', 'Modifier Switcher'):
            modswitcher .register ()
    except Exception as e :
        print ("[Smart Modifier] Failed to register modswitcher:",e )


def _unregister_optional_bundled_tools ():
    try :
        modswitcher .unregister ()
    except Exception :
        pass

def _register_core_stack_subtools ():
    for name in _CORE_STACK_SUBTOOLS :
        try :
            mod =_ms_import_subtool_module (name )
            if hasattr (mod ,"register_embedded"):
                with _feature_toggle.capture_runtime(str(name), str(name).replace('_', ' ').title()):
                    mod .register_embedded ()
        except Exception as e :
            print (f"[Smart Modifier] Failed to register core stack subtool {name }:",e )


def _unregister_core_stack_subtools ():
    for name in reversed (_CORE_STACK_SUBTOOLS ):
        try :
            mod =_ms_loaded_module (f"subtools.{name }")
            if mod is not None and hasattr (mod ,"unregister_embedded"):
                mod .unregister_embedded ()
        except Exception :
            pass


def _register_migrated_modules ():
    labels ={
    'hub':'Smart Modifier Hub',
    'precision_tools':'Precision / Layout / Path',
    'advanced_tools':'Advanced / Surface Modeling',
    }
    for module_name in _DEFERRED_MIGRATED_MODULE_NAMES :
        try :
            mod =_ms_import_local_module (module_name )
            with _feature_toggle.capture_runtime(str(module_name), labels .get (str (module_name ),str(module_name).replace('_', ' ').title())):
                mod .register ()
        except Exception as e :
            print (f"[Smart Modifier] Failed to register {module_name }:",e )


def _unregister_migrated_modules ():
    for module_name in reversed (_DEFERRED_MIGRATED_MODULE_NAMES ):
        try :
            mod =_ms_loaded_module (module_name )
            if mod is not None and hasattr (mod ,"unregister"):
                mod .unregister ()
        except Exception :
            pass

def _register_migrated_subtools ():
    for name in _MIGRATED_SUBTOOLS :
        try :
            mod =_ms_import_subtool_module (name )
            if hasattr (mod ,"register_embedded"):
                with _feature_toggle.capture_runtime(str(name), str(name).replace('_', ' ').title()):
                    mod .register_embedded ()
        except Exception as e :
            print (f"[Smart Modifier] Failed to register {name }:",e )


def _unregister_migrated_subtools ():
    for name in reversed (_MIGRATED_SUBTOOLS ):
        if name in _CORE_STACK_SUBTOOLS :
            continue
        try :
            mod =_ms_loaded_module (f"subtools.{name }")
            if mod is not None and hasattr (mod ,"unregister_embedded"):
                mod .unregister_embedded ()
        except Exception :
            pass

def _ms_register_deferred_edit_poly (context =None )->bool :
    try :
        module =_ms_loaded_module ("subtools.edit_poly_modifier")or _ms_import_subtool_module ("edit_poly_modifier")
        if hasattr (module ,"register_embedded"):
            with _feature_toggle.capture_runtime('edit_poly_modifier', 'Edit Polygon Modifier'):
                module .register_embedded ()
            return True 
    except Exception as e :
        print ("[Smart Modifier] Failed to lazily register Edit Poly subtool:",e )
    return False 


def _ms_register_deferred_smart_lattice (context =None )->bool :
    try :
        module =_ms_loaded_module ("subtools.lattice_modifier")or _ms_import_subtool_module ("lattice_modifier")
        if hasattr (module ,"register_embedded"):
            with _feature_toggle.capture_runtime('lattice_modifier', 'Smart Lattice Modifier'):
                module .register_embedded ()
            return True 
    except Exception as e :
        print ("[Smart Modifier] Failed to lazily register Smart Lattice subtool:",e )
    return False 


def _ms_ensure_deferred_components (reason ="" ,include_optional =True ,context =None ):
    global _MS_DEFERRED_COMPONENT_LOCK ,_MS_REGISTERED_RNA_PROPERTIES
    if _MS_DEFERRED_COMPONENT_LOCK :
        return False 
    _rna_before =_ms_rna_root_snapshot ()
    _MS_DEFERRED_COMPONENT_LOCK =True 
    changed =False 
    try :
        state =_ms_get_deferred_component_state ()
        if not bool (state .get ("migrated_modules")):
            if bool (include_optional ):
                _register_migrated_modules ()
                state ["migrated_modules"]=True 
                changed =True 
            # Hub / Precision / Advanced are now UI-catalog only at startup.
            # Their operator modules are registered lazily by smsm.run_user_plugin
            # when the user launches an entry, so non always-on tools do not load
            # panels, properties, or handlers before they are used.
        if not bool (state .get ("migrated_subtools")):
            # Thin migrated subtool wrappers are intentionally not imported at
            # startup. PLUGIN_CATALOG supplies lightweight UI rows and
            # smsm.run_user_plugin lazy-loads the real operator module only
            # when the user launches that tool.
            state ["migrated_subtools"]=True 
        if bool (include_optional ):
            if not bool (state .get ("edit_poly")):
                if _ms_register_deferred_edit_poly (context ):
                    state ["edit_poly"]=True 
                    changed =True 
            if not bool (state .get ("smart_lattice")):
                if _ms_register_deferred_smart_lattice (context ):
                    state ["smart_lattice"]=True 
                    changed =True 
    finally :
        _MS_DEFERRED_COMPONENT_LOCK =False 

    _rna_after =_ms_rna_root_snapshot ()
    known ={tuple (item )for item in (_MS_REGISTERED_RNA_PROPERTIES or ())}
    for owner_name ,after_names in _rna_after .items ():
        for prop_name in sorted (after_names -_rna_before .get (owner_name ,set ())):
            item =(owner_name ,prop_name )
            if item not in known :
                _MS_REGISTERED_RNA_PROPERTIES .append (item )
                known .add (item )

    if changed :
        try :
            _ms_wrap_legacy_panel_polls ()
        except Exception :
            pass 
        try :
            _ms_hide_registered_unified_child_panels()
        except Exception :
            pass
        # Do not unregister panel classes from this runtime path.  Optional
        # components can be enabled from UI property updates, and class removal
        # during sidebar layout can destabilize Blender.
    return changed 


def _reregister_user_plugins_timer ():
    return None 


def _register_translation_catalogs ():
    try :
        from . import common as common_i18n
        common_catalog ={"ja_JP":dict (getattr (common_i18n ,"_TRANSLATIONS",{}))}
    except Exception :
        common_catalog ={}
    try :
        bpy .app .translations .unregister (ADDON_ROOT_MODULE )
    except Exception :
        pass 
    try :
        from .modswitcher import i18n as modswitcher_i18n 
        merged =_ms_merge_translation_catalog_dicts (
        common_catalog ,
        translation_catalog .translation_catalog_dict ,
        translation_generated .translation_catalog_dict ,
        getattr (modswitcher_i18n ,"translation_catalog_dict",{}),
        _ep_translation_catalog_dict ,
        _sl_translation_catalog_dict ,
        )
        merged =_ms_expand_translation_catalog_contexts (merged )
        bpy .app .translations .register (ADDON_ROOT_MODULE ,merged )
    except Exception :
        try :
            bpy .app .translations .register (ADDON_ROOT_MODULE ,_ms_expand_translation_catalog_contexts (_ms_merge_translation_catalog_dicts (common_catalog ,translation_catalog .translation_catalog_dict ,translation_generated .translation_catalog_dict )))
        except Exception :
            pass 


def _unregister_translation_catalogs ():
    try :
        bpy .app .translations .unregister (ADDON_ROOT_MODULE )
    except Exception :
        pass 


def _register_max_shift_drag_clone (context=None):
    try:
        from . import max_shift_drag_clone as _msdc
        if hasattr(_msdc, 'register'):
            _msdc.register()
        return True
    except Exception as exc:
        try:
            print('[Smart Modifier] Failed to register Drag Clone:', exc)
        except Exception:
            pass
        return False


def _unregister_max_shift_drag_clone ():
    try:
        from . import max_shift_drag_clone as _msdc
        if hasattr(_msdc, 'unregister'):
            _msdc.unregister()
        return True
    except Exception:
        return False


def _register_runtime_impl (context =None ):
    global _MS_RUNTIME_REFRESH_ENABLED ,_MS_RUNTIME_REFRESH_GENERATION ,_MS_RUNTIME_REFRESH_PENDING ,_MS_RUNTIME_LAST_REFRESH_AT 
    _ms_suppress_ui_panel_bodies(1.0)
    _MS_RUNTIME_REFRESH_ENABLED =True 
    _MS_RUNTIME_REFRESH_GENERATION +=1 
    _MS_RUNTIME_REFRESH_PENDING =False 
    _MS_RUNTIME_LAST_REFRESH_AT =0.0 

    try :
        persistent_state .push_save_suspension ()
    except Exception :
        pass
    try :
        # Register save/load handlers only. Never activate transform restoration
        # during add-on/runtime registration, because it can revert normal user
        # transforms right after enabling the add-on.
        _transform_guard.register ()
    except Exception :
        pass
    try :
        _sms_icons.register ()
    except Exception :
        pass
    _register_translation_catalogs ()
    _clear_transition_state ()
    _sms_register_smart_tools_manager_panel_stability_patch()
    _ensure_driver_namespace_api ()
    _ms_prepare_properties_panels ()
    _ms_unregister_local_smart_modifier_n_panels_by_name ()
    _register_builtin_classes ()
    _register_core_props ()
    try :
        ms_normalize_show_end_result_defaults ()
    except Exception :
        pass

    _ms_disable_all_runtime_services ()
    try :
        from . import preferences as _preferences_module
        _preferences_module .load_settings (context =context ,force =True )
    except Exception :
        pass
    try:
        _register_max_shift_drag_clone(context)
    except Exception:
        pass
    _ms_reset_deferred_component_state ()
    user_plugins .register ()
    _register_core_stack_subtools ()
    # Mesh Auto Mirror stays UI-only until launched through smsm.run_user_plugin.
    _register_optional_bundled_tools ()

    # Register bundled stack operators at startup so direct UI/operator calls such
    # as bpy.ops.ep.add_layer() and bpy.ops.smart_lattice.add_layer() are always
    # resolvable immediately after the extension is enabled.  Their live handlers
    # remain dormant; register_embedded() only exposes operator classes, plugin
    # catalog hooks, and driver-namespace APIs.  This avoids the Blender 5.1 lazy
    # operator lookup state where hasattr(bpy.ops.smart_lattice, "add_layer") can
    # appear true while the actual call still raises "operator could not be found".
    try :
        state =_ms_get_deferred_component_state ()
        if _ms_register_deferred_edit_poly (context ):
            state ["edit_poly"]=True
        if _ms_register_deferred_smart_lattice (context ):
            state ["smart_lattice"]=True
    except Exception as e :
        print ("[Smart Modifier] Failed to register bundled stack operators at startup:",e )

    # Register only lightweight catalog-facing components during add-on registration.
    # Hub / Precision / Advanced and thin migrated wrappers remain lazy.
    try :
        _ms_ensure_deferred_components (reason ="register",include_optional =False ,context =context )
    except Exception :
        pass
    try :
        persistent_state .load_panel_state (context)
    except Exception :
        pass
    try :
        persistent_state .pop_save_suspension ()
    except Exception :
        pass
    try :
        persistent_state .ensure_auto_save_timer ()
    except Exception :
        pass
    try:
        _ms_refresh_shift_drag_clone_keymaps(context)
    except Exception:
        pass
    _ms_unregister_stale_n_panels ()
    _ms_install_properties_pseudo_tab ()
    _ms_wrap_legacy_panel_polls ()
    try:
        from . import ui as _sms_ui_module
        hide_duplicate_panels = getattr(_sms_ui_module, '_ms_schedule_hide_duplicate_child_panels', None)
        if callable(hide_duplicate_panels):
            hide_duplicate_panels()
    except Exception:
        pass

    try :
        _ms_register_core_services ()
    except Exception :
        pass
    try :
        _ms_update_runtime_services (context )
    except Exception :
        pass
    try :
        _ms_update_core_persistence_runtime (context )
    except Exception :
        pass
    # Do not immediately write panel/runtime state during add-on registration.
    # Registration runs before every scene/file has completed its own restore
    # pass; writing here can overwrite Smart_Modifier_Suite.json with default
    # values before the persisted scene/object settings are applied.  The normal
    # update callbacks, explicit Save Preferences operator, load/save handlers,
    # and the persistent auto-save timer handle durable writes after restore.

    try :
        _ms_cleanup_user_menu_duplicates ()
    except Exception :
        pass 

    try :
        ms_request_endpreview_global_purge ("register_cleanup")
    except Exception :
        pass 
    try :
        ms_request_shape_proxy_cleanup ("register_cleanup" ,force =True )
    except Exception :
        pass
    try :
        ms_register_shape_proxy_cleanup_maintenance ()
    except Exception :
        pass


def _unregister_runtime_impl ():
    global _MS_RUNTIME_REFRESH_ENABLED ,_MS_RUNTIME_REFRESH_GENERATION ,_MS_RUNTIME_REFRESH_PENDING ,_MS_RUNTIME_LAST_REFRESH_AT 
    _ms_suppress_ui_panel_bodies(1.0)
    _MS_RUNTIME_REFRESH_ENABLED =False 
    _MS_RUNTIME_REFRESH_GENERATION +=1 
    _MS_RUNTIME_REFRESH_PENDING =False 
    _MS_RUNTIME_LAST_REFRESH_AT =0.0 
    _sms_unregister_smart_tools_manager_panel_stability_patch()

    # Every user-facing setting is persisted synchronously by its update
    # callback.  Do not take another full snapshot during teardown: Blender can
    # already have invalidated PointerProperty RNA at this point, which used to
    # replace a valid collection selector in Smart_Modifier_Suite.json with
    # ``null`` while closing or disabling the extension.
    _ms_unregister_load_post_handler ()
    try :
        _ms_unregister_core_services ()
    except Exception :
        pass
    try :
        ms_unregister_instance_sync_timer ()
    except Exception :
        pass
    try :
        ms_unregister_shape_proxy_cleanup_maintenance ()
    except Exception :
        pass
    _ms_uninstall_properties_pseudo_tab ()
    _ms_disable_all_runtime_services ()
    try:
        _unregister_max_shift_drag_clone()
    except Exception:
        pass

    for timer_fn in (_reregister_user_plugins_timer ,_ms_cleanup_user_menu_duplicates ):
        try :
            if hasattr (bpy .app .timers ,'is_registered')and bpy .app .timers .is_registered (timer_fn ):
                bpy .app .timers .unregister (timer_fn )
        except Exception :
            pass 

    _unregister_migrated_subtools ()
    _unregister_migrated_modules ()
    _unregister_optional_bundled_tools ()
    _unregister_core_stack_subtools ()
    _ms_reset_deferred_component_state ()
    _ms_unregister_stale_n_panels ()
    try :
        module =_ms_loaded_module ('mesh_auto_mirror_embedded')
        if module is not None and hasattr (module ,'unregister'):
            module .unregister ()
    except Exception :
        pass
    user_plugins .unregister ()
    _unregister_core_props ()
    _unregister_builtin_classes ()
    _clear_driver_namespace_api ()
    _unregister_translation_catalogs ()
    # Preview collections are released only by finalize_package_teardown(),
    # after runtime panels, menus, draw handlers, and Add-on Preferences have
    # all been detached.

_MS_FULL_RUNTIME_REGISTERED =False 
_MS_REGISTERED_RNA_PROPERTIES =[]


def _ms_rna_root_snapshot ():
    result ={}
    for owner_name in ('Scene','WindowManager','Object','Mesh','Material','Collection'):
        owner =getattr (bpy .types ,owner_name ,None )
        if owner is None :continue
        try :
            result [owner_name ]={str (prop .identifier )for prop in owner .bl_rna .properties if str (getattr (prop ,'identifier','')or '')}
        except Exception :
            result [owner_name ]=set ()
    return result


def _ms_remove_registered_rna_properties ():
    global _MS_REGISTERED_RNA_PROPERTIES
    for owner_name ,attr_name in reversed (list (_MS_REGISTERED_RNA_PROPERTIES or ())):
        owner =getattr (bpy .types ,str (owner_name or ''),None )
        if owner is None :continue
        try :
            if hasattr (owner ,attr_name ):
                delattr (owner ,attr_name )
        except Exception :
            pass
    _MS_REGISTERED_RNA_PROPERTIES =[]


def _ms_remove_owned_callbacks ():
    prefix =str (__package__ or '')
    for handler_name in dir (bpy .app .handlers ):
        collection =getattr (bpy .app .handlers ,handler_name ,None )
        if not isinstance (collection ,list ):continue
        for fn in list (collection ):
            if str (getattr (fn ,'__module__','')or '').startswith (prefix ):
                try :collection .remove (fn )
                except Exception :pass
    timers =getattr (bpy .app ,'timers',None )
    if timers is None :return
    seen =set ()
    for module_name ,module in list (sys .modules .items ()):
        if not str (module_name or '').startswith (prefix )or module is None :continue
        for value in tuple (getattr (module ,'__dict__',{}).values ()):
            if not callable (value )or id (value )in seen :continue
            seen .add (id (value ))
            try :
                if timers .is_registered (value ):
                    timers .unregister (value )
            except Exception :
                pass


def finalize_package_teardown ():
    """Final symmetric teardown after preferences/common removed their roots."""
    _ms_remove_owned_callbacks ()
    prefix =str (__package__ or '')
    owned =[]
    for identifier in dir (bpy .types ):
        try :cls =getattr (bpy .types ,identifier )
        except Exception :continue
        if isinstance (cls ,type )and str (getattr (cls ,'__module__','')or '').startswith (prefix ):
            owned .append (cls )
    def _rank (cls ):
        try :
            if issubclass (cls ,bpy .types .PropertyGroup ):return (2 ,-len (getattr (cls ,'__mro__',())))
        except Exception :pass
        try :
            if issubclass (cls ,bpy .types .AddonPreferences ):return (1 ,-len (getattr (cls ,'__mro__',())))
        except Exception :pass
        return (0 ,-len (getattr (cls ,'__mro__',())))
    for cls in sorted (owned ,key =_rank ):
        try :bpy .utils .unregister_class (cls )
        except Exception :pass
    # All known Panel/Menu/draw users have now been detached.  Release only the
    # exact ImagePreviewCollection recorded by icons.register(); unregister() is
    # idempotent and never scans or removes foreign preview collections.
    try :
        _sms_icons .unregister ()
    except Exception :
        pass


def is_runtime_registered ()->bool :
    return bool (_MS_FULL_RUNTIME_REGISTERED )


def ensure_runtime_registered (context =None )->bool :
    if is_runtime_registered ():
        return True 
    register_runtime (context =context )
    return is_runtime_registered ()


def _ms_modswitcher_registered ()->bool :
    try :
        scene_type =getattr (bpy .types ,'Scene',None )
        required =(
        'modswitch_targets',
        'modswitch_objects',
        'modswitch_state_sets',
        'modswitch_ui_show_modlist',
        )
        if scene_type is None :
            return False
        if not all (hasattr (scene_type ,name )for name in required ):
            return False
        return getattr (bpy .types ,'MODSWITCH_UL_Targets',None )is not None
    except Exception :
        return False


def _ms_sync_optional_components_from_prefs (context =None ):
    try :
        want_switcher =bool (_ms_pref_enabled ('use_modifier_switcher',True ,context ))
    except Exception :
        want_switcher =True

    switcher_registered =_ms_modswitcher_registered ()
    if want_switcher and not switcher_registered :
        try :
            modswitcher .register ()
        except Exception :
            pass
    elif (not want_switcher )and switcher_registered :
        # Do not unregister UI classes during a live sidebar session.  The panel
        # poll/draw path already respects the preference state.
        pass

    # Legacy optional-subtool preference values are intentionally not consulted:
    # they must neither hide Add Modifier entries nor shut down loaded rows.


def sync_runtime_from_prefs (context =None )->bool :
    ctx =context or getattr (bpy ,'context',None )
    try :
        _ms_sync_optional_components_from_prefs (ctx )
    except Exception :
        pass
    try :
        _ms_update_runtime_services (ctx )
    except Exception :
        pass
    try :
        _ms_tag_view3d_npanel_redraw ()
    except Exception :
        pass
    return True

def open_smart_tools_window (context =None ,reuse_existing =True )->bool :
    del reuse_existing
    _ms_suppress_ui_panel_bodies(0.8)
    ensure_runtime_registered (context =context )
    try :
        _ms_tag_view3d_npanel_redraw ()
    except Exception :
        pass
    return True

def register_runtime (context =None ):
    global _MS_FULL_RUNTIME_REGISTERED ,_MS_REGISTERED_RNA_PROPERTIES
    if _MS_FULL_RUNTIME_REGISTERED :
        return 
    _rna_before =_ms_rna_root_snapshot ()
    try:
        _feature_toggle.register_ui()
    except Exception:
        pass
    _register_runtime_impl (context =context )
    _rna_after =_ms_rna_root_snapshot ()
    _MS_REGISTERED_RNA_PROPERTIES =[
    (owner_name ,prop_name )
    for owner_name ,after_names in _rna_after .items ()
    for prop_name in sorted (after_names -_rna_before .get (owner_name ,set ()))
    ]
    _MS_FULL_RUNTIME_REGISTERED =True 


def unregister_runtime ():
    global _MS_FULL_RUNTIME_REGISTERED 
    if not _MS_FULL_RUNTIME_REGISTERED :
        return 
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    _unregister_runtime_impl ()
    _ms_remove_registered_rna_properties ()
    _ms_remove_owned_callbacks ()
    _MS_FULL_RUNTIME_REGISTERED =False 


def register ():
    register_runtime ()


def unregister ():
    unregister_runtime ()


# -----------------------------------------------------------------------------
# Blender 5.1 live-session safe core RNA registration override
# -----------------------------------------------------------------------------
def _sms_ensure_rna_property(owner, attr_name, factory):
    """Add an RNA property only when missing.

    Updating an add-on inside an active Blender UI session can leave some Smart
    Modifier RNA fields registered while newer fields are missing.  The original
    all-or-nothing guard skipped registration in that partial state, which broke
    modifier instance maps after upgrade.  This helper keeps existing properties
    alive and only fills missing fields.
    """
    try:
        if hasattr(owner, attr_name):
            return True
    except Exception:
        return False
    try:
        setattr(owner, attr_name, factory())
        return True
    except Exception:
        return False


def _register_core_props():
    _ms_ensure_keymap_reference_props()
    try:
        wm_type = bpy.types.WindowManager
        obj_type = bpy.types.Object
    except Exception:
        return

    _sms_ensure_rna_property(wm_type, 'ms_target_mod', lambda: bpy.props.StringProperty())
    _sms_ensure_rna_property(wm_type, 'ms_target_obj', lambda: bpy.props.StringProperty())
    _sms_ensure_rna_property(wm_type, 'ms_move_up', lambda: bpy.props.BoolProperty(
        name='Up',
        description=(
            'Move the modifier up (change the stack order).\n'
            'How to use: Turn this ON while the menu is open to move the modifier one step up.\n'
            'Tip: Changing the order can greatly change the final result (shape).'
        ),
        update=_ms_popup_move_up_update,
    ))
    _sms_ensure_rna_property(wm_type, 'ms_move_down', lambda: bpy.props.BoolProperty(
        name='Down',
        description=(
            'Move the modifier down (change the stack order).\n'
            'How to use: Turn this ON while the menu is open to move the modifier one step down.\n'
            'Tip: Changing the order can greatly change the final result (shape).'
        ),
        update=_ms_popup_move_down_update,
    ))
    # 4.32.49 inline stack-row rename.  The value field is the commit point: its
    # update callback delegates to object.ms_rename_modifier in EXEC_DEFAULT so the
    # existing disp_name / instance-propagation path stays the only rename logic.
    _sms_ensure_rna_property(wm_type, 'ms_inline_rename_obj', lambda: bpy.props.StringProperty(
        options={'HIDDEN', 'SKIP_SAVE'},
    ))
    _sms_ensure_rna_property(wm_type, 'ms_inline_rename_mod', lambda: bpy.props.StringProperty(
        options={'HIDDEN', 'SKIP_SAVE'},
    ))
    _sms_ensure_rna_property(wm_type, 'ms_inline_rename_value', lambda: bpy.props.StringProperty(
        name='Name',
        description=(
            'Edit the modifier display name directly in the stack row.\n'
            'Press Enter to confirm, or clear the field to cancel.\n'
            'Linked/instanced modifiers are renamed together, exactly as the Rename dialog does.'
        ),
        options={'SKIP_SAVE'},
        update=_ms_inline_rename_value_update,
    ))
    _sms_ensure_rna_property(wm_type, 'sms_runtime_core_state_persistence', lambda: bpy.props.BoolProperty(
        name='N-panel State Save',
        description=(
            "Function: controls whether Smart Modifier writes N-panel settings to Smart_Modifier_Suite/Smart_Modifier_Suite.json in Blender's versioned config folder. "
            'How to use: ON saves each change immediately. Turning OFF commits that OFF value once, then blocks normal, forced, save, and shutdown writes until ON is restored.'
        ),
        default=True,
        update=_ms_wm_runtime_core_state_persistence_update,
    ))
    _sms_ensure_rna_property(wm_type, 'sms_runtime_stack_live_sync', lambda: bpy.props.BoolProperty(
        name='Modifier Stack Live Sync',
        description=(
            'Function: enables the main Modifier Stack live synchronization service, including dependency-graph callbacks and the realtime property update timer used for stack display, end-result state, and inline parameter refresh. '
            'How to use: enable it only when you want the stack panel to track changes automatically while you edit. Disable it for lighter idle performance; the related handlers and timers are removed completely.'
        ),
        default=False,
        update=_ms_wm_runtime_stack_live_sync_update,
    ))
    _sms_ensure_rna_property(wm_type, 'sms_runtime_edit_poly_live_sync', lambda: bpy.props.BoolProperty(
        name='Edit Polygon Live Sync',
        description=(
            'Function: enables Edit Polygon live synchronization, including selection tracking and edit-layer stack callbacks. '
            'How to use: enable it only while working with Edit Polygon layers that must react automatically. Disable it when not editing polygons; the live handlers remain fully stopped and the tool will not auto-enable them in the background.'
        ),
        default=False,
        update=_ms_wm_runtime_edit_poly_live_sync_update,
    ))
    _sms_ensure_rna_property(wm_type, 'sms_runtime_smart_lattice_live_sync', lambda: bpy.props.BoolProperty(
        name='Smart Lattice Live Sync',
        description=(
            'Function: enables Smart Lattice / FFD live services, including viewport overlay drawing, lattice cleanup, and dependency-graph synchronization. '
            'How to use: enable it only while editing lattice or FFD-style deformation layers. Disable it to remove the overlay and live callbacks completely from idle operation.'
        ),
        default=False,
        update=_ms_wm_runtime_smart_lattice_live_sync_update,
    ))
    _sms_ensure_rna_property(obj_type, 'ms_show_end_result', lambda: bpy.props.BoolProperty(
        name='Show End Result',
        description=(
            'Choose how the final evaluated stack is previewed while Modifier Auto Disable is controlling the active edit level.\n'
            'ON: show the final stack result through EndPreview while the editable object stays up to the active level.\n'
            'OFF: do not generate EndPreview. When Modifier Auto Disable is ON, the viewport shows only up to the active stack level; when it is OFF, enabled modifiers remain visible.'
        ),
        default=False,
        update=_ms_object_show_end_result_update,
    ))
    _sms_ensure_rna_property(obj_type, 'ms_auto_disable_modifiers', lambda: bpy.props.BoolProperty(
        name='Modifier Auto Disable',
        description=(
            'Function: automatically disables Realtime Viewport and Render evaluation for modifiers below/later than the active Smart Modifier stack item, so only the result up to the selected edit level affects the editable object.\n'
            'How to use: turn ON for 3ds Max-style edit-level work where below/later modifiers are temporarily muted. Turn OFF to keep every manually enabled Realtime/Render state visible even when another stack slot is active. Manual Realtime/Render states are stored and restored.'
        ),
        default=True,
        update=_ms_object_auto_disable_modifiers_update,
    ))
    _sms_ensure_rna_property(obj_type, 'ms_show_properties', lambda: bpy.props.BoolProperty(
        name='Show Properties',
        description=(
            'Show modifier settings (numbers/sliders, etc.) inside this panel.\n'
            'ON: Adjust parameters directly here.\n'
            'OFF: Keep the UI compact (settings are not changed).\n'
            'Note: Depending on the visibility state of BaseObject / EditPoly / EndPreview, changes may update in real time.'
        ),
        default=True,
        update=_ms_object_show_properties_update,
    ))
    _sms_ensure_rna_property(obj_type, 'ms_instance_map_items', lambda: bpy.props.CollectionProperty(type=MS_InstanceMapItem))
