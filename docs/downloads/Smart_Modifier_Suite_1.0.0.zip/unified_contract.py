# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Persistent settings identifiers used by Smart Modifier and existing saved projects."""

CONTRACT_VERSION = 1
EXTENSION_ID = "smart_modifier_suite"
CONFIG_FOLDER = "Smart_Modifier_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"

_WINDOW = "window_manager"
_RUNTIME = f"{_WINDOW}.sms_runtime"
_UI_SETTINGS = f"{_WINDOW}.sms_settings_state"
STATE_SAVE_PATH = f"{_RUNTIME}_core_state_persistence"
SECTION_OPEN_PATH = f"{_UI_SETTINGS}.show_always_on_toggles"

RUNTIME_TOGGLE_PATHS = (
    *(f"{_RUNTIME}_{feature}_live_sync" for feature in ("stack", "edit_poly", "smart_lattice")),
    "scene.modswitch_auto_refresh",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()

_WINDOW_SELECTION = tuple(f"{_WINDOW}.ms_{key}" for key in (
    "target_mod", "target_obj", "move_up", "move_down",
))
PERSISTENCE_ROOTS = (
    f"{_RUNTIME}_*", _UI_SETTINGS, *_WINDOW_SELECTION, "scene.modswitch_*",
    "object.ms_auto_disable_modifiers", "object.ms_show_end_result", "object.ms_show_properties",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = tuple(f"scene.{name}_props" for name in ("hub", "smsp", "smsa"))
EXCLUDED_TRANSIENT_PATHS = (
    f"{_UI_SETTINGS}.name",
    *(f"{name}.name" for name in PERSISTED_DYNAMIC_RNA_PATTERNS),
    *_WINDOW_SELECTION, f"{_WINDOW}.sms_*_keymap_id",
    *(f"scene.modswitch_{name}" for name in (
        "targets", "objects", "last_signature", "state_set_index", "target_index",
        "show_stack_instances", "refresh_mode",
    )),
    "object.ms_instance_map_items",
)

# These values belong to Blender's data blocks and are saved with the project.
BLEND_OWNED_NPANEL_PATHS = tuple(f"object.{name}" for name in (
    "add_rest_position_attribute", "empty_display_type", "empty_display_size",
    "empty_image_offset", "empty_image_depth", "empty_image_side",
    "show_empty_image_perspective", "show_empty_image_orthographic", "use_empty_image_alpha",
    "instance_type", "instance_collection", "instance_faces_scale", "use_instance_faces_scale",
    "show_name", "show_axis", "color", "vertex_groups", "material_slots",
    "active_material_index", "active_shape_key_index", "data.shape_keys.key_blocks",
    "data.uv_layers", "data.color_attributes", "data.attributes",
))
ROOT_PANEL_IDS = ("VIEW3D_PT_smart_modifier_root_panel",)
