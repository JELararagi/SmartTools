CONTRACT_VERSION = 1
EXTENSION_ID = "smart_modifier_suite"
CONFIG_FOLDER = "Smart_Modifier_Suite"
CONFIG_FILE = "Smart_Modifier_Suite.json"
STATE_SAVE_PATH = "window_manager.sms_runtime_core_state_persistence"
SECTION_OPEN_PATH = "window_manager.sms_settings_state.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.sms_runtime_stack_live_sync",
    "window_manager.sms_runtime_edit_poly_live_sync",
    "window_manager.sms_runtime_smart_lattice_live_sync",
    "scene.modswitch_auto_refresh",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (
    "window_manager.sms_runtime_*",
    "window_manager.sms_settings_state",
    "window_manager.ms_target_mod",
    "window_manager.ms_target_obj",
    "window_manager.ms_move_up",
    "window_manager.ms_move_down",
    "scene.modswitch_*",
    "object.ms_auto_disable_modifiers",
    "object.ms_show_end_result",
    "object.ms_show_properties",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    # These integrated setting groups exist only after the corresponding tool
    # is explicitly loaded.  The root panel remains usable without them.
    "scene.hub_props",
    "scene.smsp_props",
    "scene.smsa_props",
)
EXCLUDED_TRANSIENT_PATHS = (
    "window_manager.sms_settings_state.name",
    # Blender's built-in PropertyGroup name field is identity metadata, not an
    # N-panel preference.  It is synthesized again when each lazy group is
    # materialized and must not be round-tripped through the suite JSON.
    "scene.hub_props.name",
    "scene.smsp_props.name",
    "scene.smsa_props.name",
    # Operator scratch state.  These values exist only while the modifier-row
    # move popover is running and are never user preferences.
    "window_manager.ms_target_mod",
    "window_manager.ms_target_obj",
    "window_manager.ms_move_up",
    "window_manager.ms_move_down",
    # Read-only copy aids for manual Blender keymap registration.
    "window_manager.sms_*_keymap_id",
    "scene.modswitch_targets",
    "scene.modswitch_objects",
    "scene.modswitch_last_signature",
    # UI-list cursors and a contextual view option are derived from the current
    # scene/list rebuild.  Re-applying them globally can point past the rebuilt
    # collection and Blender immediately normalizes them again.
    "scene.modswitch_state_set_index",
    "scene.modswitch_target_index",
    "scene.modswitch_show_stack_instances",
    # Compatibility mirror of the canonical modswitch_auto_refresh toggle.
    # It is not drawn as an independent N-panel setting and is normalized to
    # MANUAL whenever the canonical always-on switch is OFF.
    "scene.modswitch_refresh_mode",
    # Generated per-object instance mapping/cache.  This is document runtime
    # data, not an N-panel preference, and must never be copied globally.
    "object.ms_instance_map_items",
)

# These fields are visible in the Modifier N-panel, but they are native Object
# datablock/document values rather than suite settings.  Blender's .blend is the
# authoritative store.  Copying the active object's values to a global config
# would overwrite unrelated objects/scenes (and can assign Empty-only instance
# data to a mesh), so the probe audits them as visible .blend-owned controls
# without requiring global JSON persistence.
BLEND_OWNED_NPANEL_PATHS = (
    "object.add_rest_position_attribute",
    "object.empty_display_type",
    "object.empty_display_size",
    "object.empty_image_offset",
    "object.empty_image_depth",
    "object.empty_image_side",
    "object.show_empty_image_perspective",
    "object.show_empty_image_orthographic",
    "object.use_empty_image_alpha",
    "object.instance_type",
    "object.instance_collection",
    "object.instance_faces_scale",
    "object.use_instance_faces_scale",
    "object.show_name",
    "object.show_axis",
    "object.color",
    # Native Object/Data collections displayed for convenient editing remain
    # .blend-owned.  Their rows and active indices must never be copied from
    # one object/scene into the suite-wide preference JSON.
    "object.vertex_groups",
    "object.material_slots",
    "object.active_material_index",
    "object.active_shape_key_index",
    "object.data.shape_keys.key_blocks",
    "object.data.uv_layers",
    "object.data.color_attributes",
    "object.data.attributes",
)
ROOT_PANEL_IDS = (
    "VIEW3D_PT_smart_modifier_root_panel",
)
