# SPDX-License-Identifier: GPL-3.0-or-later
"""RNA properties that identify an entry in the modifier list."""

import bpy

from . import core as _core


def __getattr__(name):
    if name.startswith("_"):
        raise AttributeError(name)
    return getattr(_core, name)


class MS_InstanceMapItem(bpy.types.PropertyGroup):
    mod_name: bpy.props.StringProperty(
        name="Modifier Name",
        description="Name of the modifier linked to this automatically generated entry",
    )
    instance_id: bpy.props.StringProperty(
        name="Instance ID",
        description="Identifier that distinguishes modifiers with the same name",
    )
    disp_name: bpy.props.StringProperty(
        name="Display Name",
        description="Label shown for this modifier entry, including a suffix when needed",
    )


__all__ = [*getattr(_core, "__all__", (name for name in vars(_core) if not name.startswith("_"))),
           "MS_InstanceMapItem"]
