# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy
from .core import *

class MS_InstanceMapItem(bpy.types.PropertyGroup):
    mod_name: bpy.props.StringProperty(
        name="Modifier Name",
        description=(
            "Internal data: the modifier name referenced by this list item.\n"
            "This is generated automatically and normally does not need to be edited."
        ),
        default="",
    )
    instance_id: bpy.props.StringProperty(
        name="Instance ID",
        description=(
            "Internal data: an identifier used to distinguish same-named modifiers.\n"
            "This is generated automatically and normally does not need to be edited."
        ),
        default="",
    )
    disp_name: bpy.props.StringProperty(
        name="Display Name",
        description=(
            "Internal data: UI display label for the modifier.\n"
            "When duplicate modifier names exist, a disambiguated label is generated."
        ),
        default="",
    )

