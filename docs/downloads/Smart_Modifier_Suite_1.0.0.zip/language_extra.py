# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Supplemental UI translations generated from static source labels."""

EXTRA_TRANSLATIONS = {('*', "Add Blender's standard deform modifiers."): "追加 Blender's standard deform モディファイア.",
 ('*', "Add Blender's standard edit / data-transfer / weight style modifier entries."): "追加 Blender's standard edit / data transfer / "
                                                                                        'weight style モディファイア entries.',
 ('*', "Add Blender's standard generate modifiers."): "追加 Blender's standard generate モディファイア.",
 ('*', "Add Blender's standard normal modifiers."): "追加 Blender's standard normal モディファイア.",
 ('*', 'Add Edit Poly Layer'): '編集ポリゴンレイヤーを追加',
 ('*', 'Add Helix Path'): '追加 Helix パス',
 ('*', 'Add Modifier'): '追加 モディファイア',
 ('*', 'Add Normal Transfer'): '追加 Normal Transfer',
 ('*', 'Add Profile Primitive'): '追加 Profile Primitive',
 ('*', 'Add Smart Lattice'): '追加 スマート Lattice',
 ('*', 'Add Smart Lattice (a helper system that makes lattice deformation easier) to the selected mesh.\n\n- Automatically creates a Lattice and the required helper objects/collections.\n- Places the lattice to fit the mesh size.\n- Lets you choose the resolution (U/V/W divisions) to control deformation detail.\n\nTip: Higher resolution is heavier—start low and increase only if needed.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add a Weighted Normal modifier after the hard-surface stack for cleaner shading.'): '追加 a Weighted Normal モディファイア after the hard '
                                                                                            'surface stack for cleaner shading.',
 ('*', 'Add a modifier (see tooltip for beginner-friendly details)'): '追加 a モディファイア (see tooltip for beginner friendly details)',
 ('*', 'Add a non-destructive shrinkwrap-based conform setup to the selected detail meshes so they follow the active surface. This is useful for kitbash details, decals, trim pieces, and surface-mounted parts inspired by xyShrinkWrap, Polystein Kit, NitroDraw, and similar surface placement workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add a stack-managed UVW Map entry that generates map-channel coordinates from planar, cylindrical, spherical, shrink wrap, box, face, or XYZ to UVW projection settings.'): 'スマートモディファイア '
                                                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add a stack-managed Unwrap UVW entry for assigning, rebuilding, packing, and manually editing UV coordinates through Blender UV tools.'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add a support bevel modifier after the boolean stack to stabilize highlights in hard-surface workflows.'): 'スマートモディファイア '
                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add an EditPoly layer to selected objects. You edit by adding a displacement offset on top of the evaluated result of the modifiers above. With multiple selection, it adds as an instance (same name/settings) and immediately enters multi-object Edit Mode.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add geometry / remesh style modifiers from the Smart Modifier add menu.'): '追加 ジオメトリ / remesh style モディファイア from the スマート モディファイア '
                                                                                   '追加 menu.',
 ('*', 'Add geometry-nodes based entries from the Smart Modifier add menu.'): '追加 ジオメトリ ノード based entries from the スマート モディファイア 追加 menu.',
 ('*', 'Add hair-related modifiers from the Smart Modifier add menu.'): '追加 hair related モディファイア from the スマート モディファイア 追加 menu.',
 ('*', 'Add instancing-style modifiers from the Smart Modifier add menu.'): '追加 instancing style モディファイア from the スマート モディファイア 追加 menu.',
 ('*', 'Add or update a Data Transfer modifier on the selected target meshes so custom normals follow the active source mesh. Useful for hard-surface shading, floating details, bevel support parts, and keeping kitbash pieces visually welded.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add or update a shrinkwrap-based conform modifier on the selected detail meshes so they follow the active surface mesh in a 3ds Max style modifier workflow.'): 'スマートモディファイア '
                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Add physics-style modifiers from the Smart Modifier add menu.'): '追加 physics style モディファイア from the スマート モディファイア 追加 menu.',
 ('*', 'Additional uniform multiplier applied after face-based scaling.'): 'Additional uniform multiplier applied after 面 based scaling.',
 ('*', 'Advanced'): '詳細',
 ('*', 'Advanced / Surface Modeling'): '詳細 / Surface モデリング',
 ('*', 'Advanced / Surface Modeling panel in the Smart Modifier workspace.'): '詳細 / Surface モデリング panel in the スマート モディファイア ワークスペース.',
 ('*', 'Advanced settings panel for the modifier switcher helper.'): '詳細 設定項目 panel for the モディファイア switcher helper.',
 ('*', 'Affect X'): '項目 Affect X',
 ('*', 'Affect Y'): '項目 Affect Y',
 ('*', 'Affect Z'): '項目 Affect Z',
 ('*', "Affect the modifier's 'On Cage' flag when applying operations.\nThis is mainly meaningful for deforming modifiers in Edit Mode."): 'スマートモディファイア '
                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Affect the modifier's 'Show in Edit Mode' flag when applying operations.\nUseful for deforming modifiers you want active while editing the mesh."): 'スマートモディファイア '
                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Affect the modifier's Render visibility flag when applying operations.\nTurn this ON if you want changes to affect final renders as well."): 'スマートモディファイア '
                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Affect the modifier's Viewport visibility flag when applying operations.\nThis does NOT toggle the modifier by itself; it defines which flags\nare changed by Enable/Disable/Invert and State Sets."): 'スマートモディファイア '
                                                                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'After building the workplane, switch the active transform orientation to Cursor when supported.'): 'スマートモディファイア '
                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'After building the workplane, switch the transform pivot to the 3D cursor for immediate local editing.'): 'スマートモディファイア '
                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'After surface conform, also add / update a Data Transfer modifier so custom normals follow the active source mesh.'): 'スマートモディファイア '
                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Align Location'): 'Align 位置',
 ('*', 'Align Rotation'): 'Align 回転',
 ('*', 'Align Scale'): 'Align スケール',
 ('*', 'Align To Active'): 'Align To アクティブ',
 ('*', 'Align To Surface Normal'): '項目 Align To Surface Normal',
 ('*', 'Align dropped objects so their local Z follows the hit surface normal.'): 'Align dropped オブジェクト so their local Z follows the hit '
                                                                                  'surface normal.',
 ('*', 'Align scattered instances to the surface normal.'): '項目 Align scattered instances to the surface normal.',
 ('*', 'Align the selected objects to the active object using per-channel toggles for location, rotation, and scale. Useful for 3ds Max style align workflows, layout cleanup, and archviz placement passes.'): 'スマートモディファイア '
                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Align to Surface'): '項目 Align to Surface',
 ('*', 'All registered user tools are shown here by group. Use this panel to access bundled tool code that is not visible as a standalone panel.'): 'スマートモディファイア '
                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Allow cage editing through the generated Mirror modifier.'): 'Allow cage editing through the generated Mirror モディファイア.',
 ('*', 'Allow the Cast modifier to affect the local X direction.'): 'Allow the Cast モディファイア to affect the local X direction.',
 ('*', 'Allow the Cast modifier to affect the local Y direction.'): 'Allow the Cast モディファイア to affect the local Y direction.',
 ('*', 'Allow the Cast modifier to affect the local Z direction.'): 'Allow the Cast モディファイア to affect the local Z direction.',
 ('*', 'Allows the unwrap solver to treat holes as filled while calculating islands. This often gives cleaner results on meshes with internal borders.'): 'スマートモディファイア '
                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Also affect the UI expanded/collapsed state of the modifier in Blender's\nmodifier panel (triangle open/closed). Useful to tidy long stacks."): 'スマートモディファイア '
                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Also recalculate normals during the cleanup pass.'): '項目 Also recalculate normals during the cleanup pass.',
 ('*', 'Always-on Toggles'): '常時機能切り替え',
 ('*', 'Amount used by the Taper deformer. Positive and negative values widen or narrow opposite sides.'): 'スマートモディファイア '
                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Analyze the active or selected mesh objects and summarize common production risks such as non-manifold edges, loose elements, ngons, degenerate geometry, and possible doubles. Inspired by 3D Print Toolbox style validation.'): 'スマートモディファイア '
                                                                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Angle Limit'): '項目 Angle Limit',
 ('*', 'Angle in degrees applied by the Bend deformer. Positive and negative values bend in opposite directions.'): 'スマートモディファイア '
                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Angle in degrees applied by the Twist deformer. Positive and negative values twist in opposite directions.'): 'スマートモディファイア '
                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Angle threshold used by Smart Project to decide where automatic UV cuts are created. Lower values create more islands; higher values keep larger islands together.'): 'スマートモディファイア '
                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Applied Objects'): 'Applied オブジェクト',
 ('*', 'Apply'): '適用',
 ('*', 'Apply (bake) the matching modifiers for all objects in the current scope.\nThis permanently changes geometry and removes the applied modifiers afterward.\nBeginner tip: If you only want to preview, use OFF/ON instead. Duplicate objects before applying if needed.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Apply Mirror'): '適用 Mirror',
 ('*', 'Apply Modifiers'): '適用 モディファイア',
 ('*', 'Apply controlled random location / rotation / uniform scale variation to the selected objects for faster environment dressing and layout iteration.'): 'スマートモディファイア '
                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Apply or refresh a Weighted Normal modifier on the selected mesh objects for cleaner hard-surface shading. Works well after boolean, bevel, or kitbash-style detail stacking and keeps the modifier stack editable.'): 'スマートモディファイア '
                                                                                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Apply the generated Mirror modifier immediately after creation.'): '適用 the generated Mirror モディファイア immediately after creation.',
 ('*', 'Area Weight'): '項目 Area Weight',
 ('*', 'Area weighting used by Smart Project. Higher values give larger faces more influence when automatic islands are generated.'): 'スマートモディファイア '
                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Array Along Curve'): 'Array Along カーブ',
 ('*', 'Array Count'): '項目 Array Count',
 ('*', 'Array Offset X'): '項目 Array Offset X',
 ('*', 'Attempt triangle-to-quad conversion after fill to keep the result cleaner for subdivision and retopo cleanup.'): 'スマートモディファイア '
                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Audit + Repair'): 'Audit + 修復',
 ('*', 'Audit Merge Distance'): '項目 Audit Merge Distance',
 ('*', 'Audit Selected'): 'Audit 選択中',
 ('*', 'Auto Bevel'): '自動 Bevel',
 ('*', 'Auto Mirror'): '自動 Mirror',
 ('*', 'Auto Refresh'): '自動 更新',
 ('*', 'Auto Weighted Normal'): '自動 Weighted Normal',
 ('*', 'Axis'): '項目 Axis',
 ('*', 'Axis Slice Edit'): '項目 Axis Slice Edit',
 ('*', 'Axis and source side used by the symmetry operator.'): 'Axis and ソース side used by the symmetry operator.',
 ('*', 'Axis used to distribute slice helper boxes across the active mesh bounds.'): 'Axis used to distribute slice helper boxes across '
                                                                                     'the アクティブ メッシュ bounds.',
 ('*', 'Base Object Menu'): 'Base オブジェクト Menu',
 ('*', 'Base radius of the generated helix path.'): 'Base radius of the generated helix パス.',
 ('*', 'Beautify Fill'): '項目 Beautify Fill',
 ('*', 'Beginner-friendly workflow notes for the Smart Modifier Hub.'): 'Beginner friendly workflow notes for the スマート モディファイア Hub.',
 ('*', 'Beginner-friendly workflow notes for the advanced surface modeling helpers.'): 'Beginner friendly workflow notes for the 詳細 '
                                                                                       'surface モデリング helpers.',
 ('*', 'Bend Angle (deg)'): '項目 Bend Angle (deg)',
 ('*', 'Bend Axis'): '項目 Bend Axis',
 ('*', 'Bend Lower Limit'): '項目 Bend Lower Limit',
 ('*', 'Bend Upper Limit'): '項目 Bend Upper Limit',
 ('*', 'Bevel Segments'): '項目 Bevel Segments',
 ('*', 'Bevel Width'): 'Bevel 幅',
 ('*', 'Bevel depth applied to the generated pipe curve.'): 'Bevel depth applied to the generated pipe カーブ.',
 ('*', 'Bisect Threshold'): '項目 Bisect Threshold',
 ('*', 'Bisect the active edit mesh by one or more evenly spaced local axis planes. Useful for SliceIt XYZ / Slicer style numeric cuts, panel segmentation, contour prep, and quick retopo guides.'): 'スマートモディファイア '
                                                                                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Bisect the active mesh on a chosen local axis, weld the center line, and add a Mirror modifier in one guided step. Use it from Smart Modifier > Modifier Stack > Add Modifier > User when you want fast symmetry setup without leaving the stack workflow.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Board Axis'): '項目 Board Axis',
 ('*', 'Boolean Operation'): '項目 Boolean Operation',
 ('*', 'Boolean solver used for newly created modifiers. Exact is safer for complex intersections; Fast is lighter.'): 'スマートモディファイア '
                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Break the instance link for this modifier and make this object independent.'): 'Break the instance link for this モディファイア and make '
                                                                                       'this オブジェクト independent.',
 ('*', 'Build HS Boolean Stack'): '項目 Build HS Boolean Stack',
 ('*', 'Build a cursor-based local workplane from the active face or selected edge. Useful for Modo-style Workplane / Action Center style editing on angled surfaces.'): 'スマートモディファイア '
                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Build an Array + Curve modifier stack on the active mesh using the selected curve as the path. Useful for RailClone-like repetition, trims, railing, modular walls, and architectural detailing.'): 'スマートモディファイア '
                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Bundled Tool Catalog'): 'Bundled ツール カタログ',
 ('*', 'CAD Intersect / Extend'): '項目 CAD Intersect / Extend',
 ('*', 'CAD Mode'): 'CAD モード',
 ('*', 'Cast Factor'): '項目 Cast Factor',
 ('*', 'Cast Modifier'): 'Cast モディファイア',
 ('*', 'Cast Radius'): '項目 Cast Radius',
 ('*', 'Cast Type'): '項目 Cast Type',
 ('*', 'Cast X'): '項目 Cast X',
 ('*', 'Cast Y'): '項目 Cast Y',
 ('*', 'Cast Z'): '項目 Cast Z',
 ('*', 'Central N-panel settings for Smart Modifier.'): 'Central N panel 設定項目 for スマート モディファイア.',
 ('*', 'Change the end radius relative to the start radius. Negative values tighten the spiral; positive values widen it.'): 'スマートモディファイア '
                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Choose how cutter meshes affect the active target mesh.'): 'Choose how cutter meshes affect the アクティブ 対象 メッシュ.',
 ('*', 'Choose how selected detail meshes should conform to the active surface.'): 'Choose how 選択中 detail meshes should conform to the '
                                                                                   'アクティブ surface.',
 ('*', 'Choose how targets are grouped in the Modifier List:\n- Type: one entry per modifier type (Mirror, Bevel, ...)\n- Name: one entry per modifier name (Bevel.001, ...)\nTip: Use Type for quick global toggles; use Name to distinguish duplicates.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Choose whether boards mainly run along the local X axis or Y axis of the active object.'): 'Choose whether boards mainly 実行 along '
                                                                                                   'the local X axis or Y axis of the '
                                                                                                   'アクティブ オブジェクト.',
 ('*', 'Choose whether to insert an intersection point or extend the selected endpoints to the resolved meeting point.'): 'スマートモディファイア '
                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Choose which audit issue type should be selected on the active mesh.'): 'Choose which audit issue type should be 選択中 on the アクティブ '
                                                                                'メッシュ.',
 ('*', 'Choose which face type to select on the active edit mesh.'): 'Choose which 面 type to 選択 on the アクティブ edit メッシュ.',
 ('*', 'Choose which local axis becomes the symmetry plane.'): '項目 Choose which local axis becomes the symmetry plane.',
 ('*', 'Choose which reusable 2D curve profile to create at the 3D cursor.'): 'Choose which reusable 2D カーブ profile to create at the 3D '
                                                                              'cursor.',
 ('*', 'Chooses how UV coordinates are generated. Planar projects from one direction, Box uses the closest box side per face, Cylindrical and Spherical wrap around the mesh, Face maps each polygon independently, and XYZ to UVW uses local coordinates.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Chooses the UV generation workflow. Angle Based and Conformal solve seams, Smart Project creates automatic islands, projection modes map from a view/box/cylinder/sphere, and Pack arranges existing islands.'): 'スマートモディファイア '
                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Circle Selection'): '項目 Circle Selection',
 ('*', 'Cleanup After Join'): '項目 Cleanup After Join',
 ('*', 'Cleanup New Object'): 'Cleanup New オブジェクト',
 ('*', 'Cleanup Normals'): '項目 Cleanup Normals',
 ('*', 'Clip To Bounds'): '項目 Clip To Bounds',
 ('*', 'Clips projected UVs to the 0-1 tile when supported. Use this when projection should stay inside the main texture area instead of extending outside.'): 'スマートモディファイア '
                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Clockwise'): '項目 Clockwise',
 ('*', 'Close Object Path'): '閉じる オブジェクト パス',
 ('*', 'Close Vertex Path'): '閉じる 頂点 パス',
 ('*', 'Close the generated path so the last sampled object links back to the first.'): '閉じる the generated パス so the last sampled オブジェクト '
                                                                                        'links back to the first.',
 ('*', 'Close the generated vertex path so the last sampled point links back to the first.'): '閉じる the generated 頂点 パス so the last sampled '
                                                                                              'point links back to the first.',
 ('*', 'Close the pipe ends when the curve supports cap filling.'): '閉じる the pipe ends when the カーブ supports cap filling.',
 ('*', 'Collection'): 'コレクション',
 ('*', 'Combine / Join Clean'): 'Combine / Join クリーン',
 ('*', 'Combined state indicator (ON / OFF / MIXED).\nThis is calculated automatically based on the selected visibility scope.'): 'スマートモディファイア '
                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Compact advanced panel for surface-first hard-surface helpers, slice panels, bend/twist/taper/lattice/cast deformation, thickness, clean combine, and surface drop utilities.'): 'スマートモディファイア '
                                                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Compact precision panel for workplane, projection, retopo helpers, path instancing, replacements, and curve-based modeling tasks.'): 'スマートモディファイア '
                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Component Scale'): 'Component スケール',
 ('*', 'Conform / Stitch To Surface'): '項目 Conform / Stitch To Surface',
 ('*', 'Conform Method'): '項目 Conform Method',
 ('*', 'Conform Mode'): 'Conform モード',
 ('*', 'Conform Offset'): '項目 Conform Offset',
 ('*', 'Context menu for per-modifier actions in Smart Modifier.'): 'Context menu for per モディファイア actions in スマート モディファイア.',
 ('*', 'Context menu for stack-level actions in Smart Modifier.'): 'Context menu for stack level actions in スマート モディファイア.',
 ('*', 'Convert To Quads'): '項目 Convert To Quads',
 ('*', 'Convert selected mesh edges into one or more curve splines without duplicating or separating the source mesh. Useful for Vertices to Splines, sweep prep, path extraction, trim routing, and safer pipe workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Convert the current selected edge path into a beveled curve pipe. This is useful for cable, hose, trim, and sweep-style workflows inspired by Sweep Mesh, Cablerator, ReeperX, and curve-based modeling tools.'): 'スマートモディファイア '
                                                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Correct Aspect'): '項目 Correct Aspect',
 ('*', 'Count'): '項目 Count',
 ('*', 'Create a NEW State Set (a snapshot) of modifier ON/OFF + display flags.\nThis records the current modifier states of objects in the current scope, so you can restore them later.\nBeginner tip: Use State Sets to switch between setups (e.g. modeling vs render, high vs low).\nNote: This does NOT save modifier parameters or order — only the visibility/display states.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a compact non-destructive hard-surface stack on the active object using the other selected mesh objects as cutters. Adds Boolean modifiers per cutter, optional bevel support, optional weighted normals, and optional cutter organization for a Hard Ops / Boxcutter / Hard Mesh / MeshFusion style workflow.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a curve path from the currently selected edit-mesh vertices. Useful for spline blocking, strip routing, loft / sweep preparation, and 3ds Max style path extraction from direct mesh edits.'): 'スマートモディファイア '
                                                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a curve path from the world-space origins of the selected objects. Useful for trajectory-to-spline style workflows, blocking guide curves, layout splines, and quickly turning placed empties/objects into reusable paths.'): 'スマートモディファイア '
                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a detail box aligned to the active face. This is useful for kitbash details, panel blocks, trim pieces, and quick boolean helpers inspired by KIT OPS, Primo Kit, NitroDraw, and surface-first hard-surface workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a duplicated path object before assigning the selected profile, so the original path remains unchanged.'): 'スマートモディファイア '
                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a helix/spiral curve path at the 3D cursor. Useful for springs, spiral cables, wrapped trims, and guide curves for sweep or array workflows.'): 'スマートモディファイア '
                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a loft mesh between exactly two paths. Works with two selected curve objects in Object Mode, or with exactly two selected edge paths in Edit Mode. Useful for PolyBridge, spline patch, loft surfacing, trims, and strip modeling workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create a rebuilt duplicate instead of overwriting the active curve object data.'): 'Create a rebuilt 複製 instead of overwriting the '
                                                                                           'アクティブ カーブ オブジェクト data.',
 ('*', 'Create a reusable 2D curve profile at the 3D cursor. Useful for Sweep Mesh, molding, trim, rail sections, cable trays, and CAD-style profile workflows.'): 'スマートモディファイア '
                                                                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create evenly spaced boolean helper boxes across the active mesh bounds to build grooves, slots, layered cuts, and contour-like panel patterns. This is a practical non-destructive generator inspired by Slicer, NitroBoxTool, and panel-line boolean workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Bend modifier origin.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Cast modifier control object when supported.'): 'スマートモディファイア '
                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Taper modifier origin.'): 'スマートモディファイア '
                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Twist modifier origin.'): 'スマートモディファイア '
                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a lattice cage around the active object and wire it through a Lattice modifier. Useful for broad-form FFD-style shaping, silhouette blocking, gentle organic cleanup, and non-destructive cage edits inspired by modifier-stack / FFD workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a non-destructive Cast modifier on the active mesh. Useful for sphere/cylinder/cuboid fitting, quick circle/spherify shaping, and upper-compatible max-style form correction inside the modifier stack.'): 'スマートモディファイア '
                                                                                                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a non-destructive Simple Deform Bend setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for Simple Bend, Scroll/Roll style shaping, signage, cables, and fast concept deformation without committing destructive edits.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a non-destructive Simple Deform Taper setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for bottle shapes, wedge forms, architectural narrowing, silhouette control, and fast modifier-stack taper workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a non-destructive Simple Deform Twist setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for torsion, twisted trims, cables, screw-like shaping, and fast modifier-stack twist workflows without destructive edits.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create or update a non-destructive Solidify modifier on the active mesh with even-thickness and quality-normal options. Useful for shelling, panel thickness, CAD-style wall offsets, Solidify Plus style workflows, and quick hard-surface thickness passes.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Create rim faces so the thickened shell is closed instead of leaving open borders.'): 'Create rim 面 so the thickened shell is '
                                                                                              'closed instead of leaving 開く borders.',
 ('*', 'Cube Size'): '項目 Cube Size',
 ('*', 'Curve bevel resolution used for the generated pipe.'): 'カーブ bevel 解像度 used for the generated pipe.',
 ('*', 'Cut and Mirror'): '項目 Cut and Mirror',
 ('*', 'Deform'): '項目 Deform',
 ('*', 'Delete'): '削除',
 ('*', 'Delete Targets'): '削除 対象',
 ('*', 'Delete one side and add a Mirror modifier. Disable it when you only want the bisect and center weld.'): 'スマートモディファイア '
                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Delete the selected State Set preset.\nThis only removes the preset; it does not change current modifier states.\nTip: If you delete by mistake, Undo can restore it.'): 'スマートモディファイア '
                                                                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Detach / Separate Clean'): 'Detach / Separate クリーン',
 ('*', 'Display Name'): 'Display 名前',
 ('*', 'Display the generated detail as wire for helper-style workflows.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Distance tolerance used by Axis Slice Edit when resolving plane/mesh intersections.'): 'Distance tolerance used by Axis Slice Edit '
                                                                                               'when resolving plane/メッシュ intersections.',
 ('*', 'Distance used for potential double detection and for the conservative merge-by-distance repair step.'): 'スマートモディファイア '
                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Distance used when merging overlapping vertices during cleanup.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Distribute Axis'): '項目 Distribute Axis',
 ('*', 'Distribute Selected'): 'Distribute 選択中',
 ('*', 'Down'): '項目 Down',
 ('*', 'Drop Offset'): '項目 Drop Offset',
 ('*', 'Drop To Floor'): '項目 Drop To Floor',
 ('*', 'Drop To Surface'): '項目 Drop To Surface',
 ('*', 'Drop selected objects vertically so their world-space bounds sit on a shared floor height. Useful for DropToFloor style layout cleanup, shelf dressing, and zero-target placement prep.'): 'スマートモディファイア '
                                                                                                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Drop the selected objects onto the active surface along world -Z using bounding-box based placement, with optional normal alignment. This is useful for DropIt / Drop to Floor style scene dressing and layout work.'): 'スマートモディファイア '
                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Duplicate First'): '複製 First',
 ('*', 'Duplicate Path'): '複製 パス',
 ('*', 'Duplicate the active mesh object onto the faces of the other selected mesh objects. Useful as a compact Tissue-style face component workflow for paneling, tiles, vents, and kitbash repetition.'): 'スマートモディファイア '
                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Duplicate the selected geometry before separating it, so the source object keeps the original polygons.'): 'スマートモディファイア '
                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Edit'): '項目 Edit',
 ('*', 'Edit Mode'): 'Edit モード',
 ('*', 'Edit Poly (Standalone)'): '編集ポリゴン（単体）',
 ('*', 'Edit Polygon Live Sync'): '項目 Edit Polygon Live Sync',
 ('*', 'Edit UVW Map'): '項目 Edit UVW Map',
 ('*', 'Edit Unwrap UVW'): '項目 Edit Unwrap UVW',
 ('*', 'Edit the saved UVW Map projection settings on this stack entry and rebuild the UV map coordinates on the target mesh.'): 'スマートモディファイア '
                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Edit the saved Unwrap UVW method and rebuild the selected UV map coordinates on the target mesh.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Editable On Cage'): '項目 Editable On Cage',
 ('*', 'Enable Edit Polygon Modifier (Bundled)'): '編集ポリゴン Modifier（同梱）',
 ('*', 'Enable Modifier Switcher'): '有効化 モディファイア Switcher',
 ('*', 'Enable Smart Lattice Modifier (Bundled)'): '有効化 スマート Lattice モディファイア (Bundled)',
 ('*', 'Enable Smart Modifier'): '有効化 スマート モディファイア',
 ('*', 'Enable X-axis alignment or distribution.'): '有効化 X axis alignment or distribution.',
 ('*', 'Enable Y-axis alignment or distribution.'): '有効化 Y axis alignment or distribution.',
 ('*', 'Enable Z-axis alignment or distribution.'): '有効化 Z axis alignment or distribution.',
 ('*', 'Enable clipping on the created Mirror modifier to keep the center seam closed.'): '有効化 clipping on the created Mirror モディファイア to '
                                                                                          'keep the center seam closed.',
 ('*', 'Enable end caps on the configured sweep when the curve data supports cap filling.'): '有効化 end caps on the configured sweep when '
                                                                                             'the カーブ data supports cap filling.',
 ('*', 'Enable higher-quality solidify normal handling for cleaner shading on complex shells.'): '有効化 higher 品質 solidify normal handling '
                                                                                                 'for cleaner shading on complex shells.',
 ('*', 'Enable smooth shading on the generated loft mesh.'): '有効化 smooth shading on the generated loft メッシュ.',
 ('*', "Enter the new display name.\nTip: Use a short, descriptive name (e.g., 'Hair_Volume') so it is easier to manage."): 'スマートモディファイア '
                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Even Offset'): '項目 Even Offset',
 ('*', 'Evenly distribute selected object origins between the current minimum and maximum positions on the chosen world axis. Useful for shelf dressing, facade spacing, modular blocking, and quick layout cleanup.'): 'スマートモディファイア '
                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Expanded'): '項目 Expanded',
 ('*', 'Extra gap inserted between stacked object bounds.'): 'Extra gap inserted between stacked オブジェクト bounds.',
 ('*', 'Extra scale added around the active object when fitting the generated lattice cage.'): 'Extra スケール added around the アクティブ オブジェクト '
                                                                                               'when fitting the generated lattice cage.',
 ('*', 'Extrude distance applied by the helper.'): '項目 Extrude distance applied by the helper.',
 ('*', 'Face Component Array'): '面 Component Array',
 ('*', 'Face Influence'): '面 Influence',
 ('*', 'Face Offset'): '面 Offset',
 ('*', 'Fallback count used when fit-curve mode is unavailable or disabled.'): 'Fallback count used when fit カーブ モード is unavailable or 無効.',
 ('*', 'Fill Caps'): '項目 Fill Caps',
 ('*', 'Fill Holes'): '項目 Fill Holes',
 ('*', 'Fill, cap, or bridge the current edit-mode boundary with a smarter fallback chain. The operator tries boundary-aware bridge, grid fill, EdgeNet preparation/fill, and then standard face creation tools before optional beautify / quad cleanup. This acts as a more failure-resistant helper inspired by F2, Quad Adder, Quad Cap Tool, NitroCap, and day-to-day patch repair workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Filter Objects'): 'フィルター オブジェクト',
 ('*', 'Filter Targets'): 'フィルター 対象',
 ('*', 'Filter the Object List by the ON/OFF state of the selected target.\nThe state is evaluated using the primary visibility flag (usually Viewport).'): 'スマートモディファイア '
                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Final thickness used by the generated or updated Solidify modifier.'): 'Final thickness used by the generated or updated Solidify '
                                                                               'モディファイア.',
 ('*', 'Fit To Object'): 'Fit To オブジェクト',
 ('*', "Fit the current selected vertices into a circular shape. Uses LoopTools Circle when available, and otherwise falls back to Blender's To Sphere transform for a practical circle helper inspired by LoopTools and NitroCycle."): 'スマートモディファイア '
                                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Fits the mapping gizmo to the target mesh bounds before generating UVs. Keep this on for automatic one-object fitting; turn it off when you want world-like local coordinates.'): 'スマートモディファイア '
                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Flip U'): '項目 Flip U',
 ('*', 'Flip V'): '項目 Flip V',
 ('*', 'Floor Board Length'): '項目 Floor Board Length',
 ('*', 'Floor Board Width'): 'Floor Board 幅',
 ('*', 'Floor Gap'): '項目 Floor Gap',
 ('*', 'Floor Generator'): '項目 Floor Generator',
 ('*', 'Floor Stagger'): '項目 Floor Stagger',
 ('*', 'Floor Thickness'): '項目 Floor Thickness',
 ('*', 'Floor Z'): '項目 Floor Z',
 ('*', 'Follow Tangent'): '項目 Follow Tangent',
 ('*', 'Gap placed between generated floor boards.'): '項目 Gap placed between generated floor boards.',
 ('*', 'Generate'): '項目 Generate',
 ('*', "Generate a procedural floorboard mesh inside the active object's local footprint using board width, length, gap, thickness, and stagger settings. This is a compact Blender-native helper inspired by FloorGenerator and architectural pattern tools."): 'スマートモディファイア '
                                                                                                                                                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Generate the helix in clockwise direction around the local Z axis.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Geometry'): 'ジオメトリ',
 ('*', 'Geometry Nodes'): 'ジオメトリ ノード',
 ('*', 'Gizmo Offset X'): '項目 Gizmo Offset X',
 ('*', 'Gizmo Offset Y'): '項目 Gizmo Offset Y',
 ('*', 'Gizmo Offset Z'): '項目 Gizmo Offset Z',
 ('*', 'Gizmo Rotation X'): 'Gizmo 回転 X',
 ('*', 'Gizmo Rotation Y'): 'Gizmo 回転 Y',
 ('*', 'Gizmo Rotation Z'): 'Gizmo 回転 Z',
 ('*', 'Grouped root submenu for Smart Modifier user tools. It fans out into workflow-category entries so the migrated custom modifier catalog stays easier to scan than one long flat list.'): 'スマートモディファイア '
                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Guide / Tips'): '項目 Guide / Tips',
 ('*', 'Hair'): '項目 Hair',
 ('*', 'Height'): '高さ',
 ('*', 'Height of the UVW mapping gizmo in local object space. This controls the vertical dimension for cylindrical, spherical, shrink-wrap, and box-style mapping.'): 'スマートモディファイア '
                                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Height of the generated surface detail box measured away from the source face.'): '高さ of the generated surface detail box measured '
                                                                                          'away from the ソース 面.',
 ('*', 'Helix Height'): 'Helix 高さ',
 ('*', 'Helix Radius'): '項目 Helix Radius',
 ('*', 'Helix Taper'): '項目 Helix Taper',
 ('*', 'Helix Turns'): '項目 Helix Turns',
 ('*', 'Help'): 'ヘルプ',
 ('*', 'Help Topic'): 'ヘルプ Topic',
 ('*', 'Hide all unselected objects for focused modeling, then restore the previous visibility when run again. Useful for MagicSolo-style focus workflows.'): 'スマートモディファイア '
                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How clicking an item in the Object List affects viewport selection:\n- None: do not change the current selection\n- Single: deselect others and select the clicked object\n- Active Only: set active/selected without deselecting others'): 'スマートモディファイア '
                                                                                                                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How many matching modifiers exist on this object for the current target.\nThis is calculated automatically.'): 'スマートモディファイア '
                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How many matching modifiers were found for this target.\nThis is calculated automatically when the list is rebuilt.'): 'スマートモディファイア '
                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How many objects contain matching modifiers for this target.\nThis is calculated automatically when the list is rebuilt.'): 'スマートモディファイア '
                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How many smoothing passes to run when a fallback method is used.'): 'How many smoothing passes to 実行 when a fallback method is '
                                                                            'used.',
 ('*', 'How often Auto Refresh runs (seconds).\nIncrease this value to reduce CPU usage in heavy scenes.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'How the generated slice helpers should affect the active mesh.'): 'How the generated slice helpers should affect the アクティブ メッシュ.',
 ('*', 'How the generated surface detail box should be used.'): '項目 How the generated surface detail box should be used.',
 ('*', 'How the target is defined (by modifier TYPE or by modifier NAME).\nThis is managed automatically based on the current target mode.'): 'スマートモディファイア '
                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'If a Weighted Normal modifier already exists on the object, update it instead of creating duplicates.'): 'スマートモディファイア '
                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'If the target mesh stores selected polygons, use only those faces. Otherwise all faces are used.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'In Edit Mode, run destructive symmetrize with the chosen direction. In Object Mode, create or update a Mirror modifier for a non-destructive symmetry setup.'): 'スマートモディファイア '
                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'In Object Mode, create or reuse a Mirror modifier instead of doing a destructive edit operation.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Include Ends'): '項目 Include Ends',
 ('*', 'Inner radius ratio used when the profile type is Star.'): '項目 Inner radius ratio used when the profile type is Star.',
 ('*', 'Inset amount applied before the extrusion step.'): '項目 Inset amount applied before the extrusion step.',
 ('*', 'Instance'): '項目 Instance',
 ('*', 'Instance ID'): '項目 Instance ID',
 ('*', 'Instances'): '項目 Instances',
 ('*', 'Instances Along Path'): 'Instances Along パス',
 ('*', 'Internal data: UI display label for the modifier.\nWhen duplicate modifier names exist, a disambiguated label is generated.'): 'スマートモディファイア '
                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Internal data: an identifier used to distinguish same-named modifiers.\nThis is generated automatically and normally does not need to be edited.'): 'スマートモディファイア '
                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Internal data: the modifier name referenced by this list item.\nThis is generated automatically and normally does not need to be edited.'): 'スマートモディファイア '
                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Internal identifier for the Smart Modifier help topic to open.'): 'Internal identifier for the スマート モディファイア ヘルプ topic to 開く.',
 ('*', 'Internal key used to identify a pinned modifier target.\nThis value is managed automatically.'): 'スマートモディファイア '
                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Internal key used to identify this target entry.\nThis value is managed automatically.'): 'Internal key used to identify this 対象 '
                                                                                                  'entry. This value is managed '
                                                                                                  'automatically.',
 ('*', 'Island Margin'): '項目 Island Margin',
 ('*', 'Issue Filter'): 'Issue フィルター',
 ('*', 'Iterations'): '項目 Iterations',
 ('*', 'Join Triangles'): '項目 Join Triangles',
 ('*', 'Join the selected mesh objects while keeping the active object as the pivot/origin owner, then optionally run a light cleanup pass. This acts as a Blender-friendly helper inspired by FB combine and clean combine scripts.'): 'スマートモディファイア '
                                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Keep Original'): '項目 Keep Original',
 ('*', 'Keep Sharp'): '項目 Keep Sharp',
 ('*', 'Keep Side'): '項目 Keep Side',
 ('*', 'Keep projected vertices slightly above or below the active plane.'): 'Keep projected vertices slightly above or below the アクティブ '
                                                                             'plane.',
 ('*', 'Keep projected vertices slightly above or below the target surface.'): 'Keep projected vertices slightly above or below the 対象 '
                                                                               'surface.',
 ('*', 'Keep shell thickness more even across angled surfaces when the modifier supports it.'): 'Keep shell thickness more even across '
                                                                                                'angled surfaces when the モディファイア supports '
                                                                                                'it.',
 ('*', 'Key'): '項目 Key',
 ('*', 'Label'): '項目 Label',
 ('*', 'Last Audit Report'): 'Last Audit レポート',
 ('*', 'Lattice Padding'): '項目 Lattice Padding',
 ('*', 'Lattice U'): '項目 Lattice U',
 ('*', 'Lattice V'): '項目 Lattice V',
 ('*', 'Lattice W'): '項目 Lattice W',
 ('*', 'Length'): '項目 Length',
 ('*', 'Length of the UVW mapping gizmo in local object space. Increase it to make the texture pattern appear smaller when Real-World Scale is enabled.'): 'スマートモディファイア '
                                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Length of the generated surface detail box.'): '項目 Length of the generated surface detail box.',
 ('*', 'Link conformed detail objects into a dedicated helper collection.'): 'Link conformed detail オブジェクト into a dedicated helper コレクション.',
 ('*', 'Link cutters into a dedicated collection so boolean helper objects stay organized in the Outliner.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Link generated path instances into a dedicated collection with a root empty.'): 'Link generated パス instances into a dedicated '
                                                                                        'コレクション with a root empty.',
 ('*', 'Link replacement objects into the same collections as the replaced targets.'): 'Link replacement オブジェクト into the same コレクション as '
                                                                                       'the replaced 対象.',
 ('*', 'Linked Data'): '項目 Linked Data',
 ('*', 'Load/apply the selected State Set to objects in the current scope.\nThis restores the saved ON/OFF + display flags from that snapshot.\nNote: It does not add/remove modifiers or change their order — it only restores states.'): 'スマートモディファイア '
                                                                                                                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Local axis used by Axis Slice Edit when creating evenly spaced bisect planes.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Loft / Bridge Paths'): 'Loft / Bridge パス',
 ('*', 'Loft Samples'): '項目 Loft Samples',
 ('*', 'Lower normalized limit for the Bend modifier, useful for partial roll and localized deformation.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Lower normalized limit for the Taper modifier, useful for partial narrowing and localized silhouette edits.'): 'スマートモディファイア '
                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Lower normalized limit for the Twist modifier, useful for partial torsion and localized twisting.'): 'スマートモディファイア '
                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Main compact modifier hub that groups hard-surface, repair, curve, scatter, and workflow entry points in one place.'): 'スマートモディファイア '
                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Main modifier stack panel. Add Modifier restores Blender's standard modifier categories and also centralizes the bundled user tools under User so the old side-panel workflows are handled from this stack entry point."): 'スマートモディファイア '
                                                                                                                                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Main object name (internal)'): 'Main オブジェクト 名前 (internal)',
 ('*', 'Main panel for the modifier switcher helper.'): 'Main panel for the モディファイア switcher helper.',
 ('*', 'Make Pipe / Cable'): '項目 Make Pipe / Cable',
 ('*', 'Make Unique'): '項目 Make Unique',
 ('*', 'Mapping Type'): '項目 Mapping Type',
 ('*', 'Mark all faces smooth before or while applying the modifier.'): 'Mark すべて 面 smooth before or while applying the モディファイア.',
 ('*', "Master add menu for Smart Modifier. It restores Blender's standard modifier categories and also exposes the bundled custom tools as split workflow-category menus so migrated functions can be started from one place without an oversized flat User list."): 'スマートモディファイア '
                                                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Match the selected objects' world-space location to the active object on the enabled axes."): "Match the 選択中 オブジェクト' ワールド space 位置 "
                                                                                                      'to the アクティブ オブジェクト on the 有効 axes.',
 ('*', "Match the selected objects' world-space rotation to the active object."): "Match the 選択中 オブジェクト' ワールド space 回転 to the アクティブ "
                                                                                  'オブジェクト.',
 ('*', "Match the selected objects' world-space scale to the active object on the enabled axes."): "Match the 選択中 オブジェクト' ワールド space スケール "
                                                                                                   'to the アクティブ オブジェクト on the 有効 axes.',
 ('*', 'Maximum extra random Z rotation in degrees.'): 'Maximum extra random Z 回転 in degrees.',
 ('*', 'Maximum extra random offset in X/Y for each selected object.'): 'Maximum extra random offset in X/Y for each 選択中 オブジェクト.',
 ('*', 'Maximum extra random offset in Z for each selected object.'): 'Maximum extra random offset in Z for each 選択中 オブジェクト.',
 ('*', 'Maximum extra rotation around the path tangent.'): 'Maximum extra 回転 around the パス tangent.',
 ('*', 'Maximum random rotation around the local up axis in degrees.'): 'Maximum random 回転 around the local up axis in degrees.',
 ('*', 'Maximum random scale used by the scatter operator.'): 'Maximum random スケール used by the scatter operator.',
 ('*', 'Maximum uniform scale multiplier.'): 'Maximum uniform スケール multiplier.',
 ('*', 'Merge Array Vertices'): '項目 Merge Array Vertices',
 ('*', 'Merge Distance'): '項目 Merge Distance',
 ('*', 'Merge threshold used by symmetry operations.'): '項目 Merge threshold used by symmetry operations.',
 ('*', 'Merge touching vertices in the generated array when the modifier supports it.'): 'Merge touching vertices in the generated array '
                                                                                         'when the モディファイア supports it.',
 ('*', 'Mesh Auto Mirror'): 'メッシュ 自動 Mirror',
 ('*', 'Minimum random scale used by the scatter operator.'): 'Minimum random スケール used by the scatter operator.',
 ('*', 'Minimum uniform scale multiplier.'): 'Minimum uniform スケール multiplier.',
 ('*', 'Mirror Axis'): '項目 Mirror Axis',
 ('*', 'Mirror Clip'): '項目 Mirror Clip',
 ('*', 'Mirrors the generated coordinates horizontally before tiling and offset are applied. Use it when the texture appears reversed left to right.'): 'スマートモディファイア '
                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Mirrors the generated coordinates vertically before tiling and offset are applied. Use it when the texture appears upside down.'): 'スマートモディファイア '
                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Mix factor used by the created Data Transfer modifier.'): 'Mix factor used by the created Data Transfer モディファイア.',
 ('*', 'Mode'): 'モード',
 ('*', 'Modifier Action'): 'モディファイア Action',
 ('*', 'Modifier Menu'): 'モディファイア Menu',
 ('*', 'Modifier Name'): 'モディファイア 名前',
 ('*', 'Modifier Stack'): 'モディファイア Stack',
 ('*', 'Modifier Stack Live Sync'): 'モディファイア Stack Live Sync',
 ('*', 'Modifier Switcher'): 'モディファイア Switcher',
 ('*', 'Modifier name (internal)'): 'モディファイア 名前 (internal)',
 ('*', 'Modifier name used when targeting by NAME.\nThis is managed automatically.'): 'モディファイア 名前 used when targeting by 名前. This is '
                                                                                      'managed automatically.',
 ('*', 'Modifier type used when targeting by TYPE (example: SUBSURF, MIRROR).\nThis is managed automatically.'): 'スマートモディファイア '
                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Modifier visibility switcher panel shown inside the Smart Modifier group.'): 'モディファイア visibility switcher panel shown inside the '
                                                                                     'スマート モディファイア group.',
 ('*', 'Mods'): '項目 Mods',
 ('*', 'Move'): '項目 Move',
 ('*', "Move each selected object's origin to the world-space bottom center of its bounds without changing the visible shape. Useful for layout, DropIt-style dressing, stacking, and easier floor placement."): 'スマートモディファイア '
                                                                                                                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Move grouped modifiers up or down together inside the modifier switcher workflow.'): 'Move grouped モディファイア up or down together '
                                                                                             'inside the モディファイア switcher workflow.',
 ('*', "Move the active mesh object's origin to the center of the current edit selection without changing the visible shape. Useful for local bend / twist control, kitbash pivots, and temporary action-center style edits."): 'スマートモディファイア '
                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Move the modifier down (change the stack order).\nHow to use: Turn this ON while the menu is open to move the modifier one step down.\nTip: Changing the order can greatly change the final result (shape).'): 'スマートモディファイア '
                                                                                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Move the modifier up (change the stack order).\nHow to use: Turn this ON while the menu is open to move the modifier one step up.\nTip: Changing the order can greatly change the final result (shape).'): 'スマートモディファイア '
                                                                                                                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Moves the generated UVs horizontally in texture space without changing the mesh. Use it to slide the texture left or right.'): 'スマートモディファイア '
                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Moves the generated UVs vertically in texture space without changing the mesh. Use it to slide the texture up or down.'): 'スマートモディファイア '
                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Moves the virtual UVW mapping gizmo along local X before projection. Use it to shift where the projection starts without moving the object.'): 'スマートモディファイア '
                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Moves the virtual UVW mapping gizmo along local Y before projection. Use it to align the generated mapping to a different local position.'): 'スマートモディファイア '
                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Moves the virtual UVW mapping gizmo along local Z before projection. Use it to align vertical mapping starts or seams.'): 'スマートモディファイア '
                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'N-panel State Persistence'): 'Nパネル状態保存',
    ('*', 'N-panel State Save'): 'Nパネル状態保存',
 ('*', 'Name'): '名前',
 ('*', 'Name of the Blender UV map used as the map channel. Use UVMap for channel 1 or enter another UV map name when the object needs multiple mapping channels.'): 'スマートモディファイア '
                                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Name of the modifier whose influence range you want to update.\nNormally this is filled automatically when you press the buttons, so you don't need to edit it manually."): 'スマートモディファイア '
                                                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Name of the target object.\nNormally this is filled automatically when you press the buttons, so you don't need to edit it manually."): 'スマートモディファイア '
                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'New Name'): 'New 名前',
 ('*', 'New Set Name'): 'New Set 名前',
 ('*', 'Normal Mix'): '項目 Normal Mix',
 ('*', 'Normal Transfer Modifier'): 'Normal Transfer モディファイア',
 ('*', 'Normals'): '項目 Normals',
 ('*', 'Number of divisions in U (mainly X) direction.'): '項目 Number of divisions in U (mainly X) direction.',
 ('*', 'Number of divisions in V (mainly Y) direction.'): '項目 Number of divisions in V (mainly Y) direction.',
 ('*', 'Number of divisions in W (mainly Z) direction.'): '項目 Number of divisions in W (mainly Z) direction.',
 ('*', 'Number of evenly spaced slice helper boxes to create.'): '項目 Number of evenly spaced slice helper boxes to create.',
 ('*', 'Number of evenly spaced slice planes inserted between the local minimum and maximum bounds.'): 'スマートモディファイア '
                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Number of instances to place along the active curve.'): 'Number of instances to place along the アクティブ カーブ.',
 ('*', 'Number of lattice control points along the local U axis.'): '項目 Number of lattice control points along the local U axis.',
 ('*', 'Number of lattice control points along the local V axis.'): '項目 Number of lattice control points along the local V axis.',
 ('*', 'Number of lattice control points along the local W axis.'): '項目 Number of lattice control points along the local W axis.',
 ('*', 'Number of linked instances to scatter across the active surface.'): 'Number of linked instances to scatter across the アクティブ '
                                                                            'surface.',
 ('*', 'Number of sampled points used for each helix turn. Higher values create a smoother path.'): 'Number of sampled points used for '
                                                                                                    'each helix turn. Higher values create '
                                                                                                    'a smoother パス.',
 ('*', 'Number of sampled points used to rebuild the active curve.'): 'Number of sampled points used to rebuild the アクティブ カーブ.',
 ('*', 'Number of sampled points used when lofting between two paths.'): 'Number of sampled points used when lofting between two パス.',
 ('*', 'Number of turns used by the generated helix path. Fractional values are allowed.'): 'Number of turns used by the generated helix '
                                                                                            'パス. Fractional values are allowed.',
 ('*', 'Object'): 'オブジェクト',
 ('*', 'Object Mode = Mirror Modifier'): 'オブジェクト モード = Mirror モディファイア',
 ('*', 'Object list panel for selecting and batching modifier switcher targets.'): 'オブジェクト list panel for selecting and batching モディファイア '
                                                                                   'switcher 対象.',
 ('*', 'Object name in the applied object list.\nThis is generated automatically.'): 'オブジェクト 名前 in the applied オブジェクト list. This is '
                                                                                     'generated automatically.',
 ('*', 'Objects'): 'オブジェクト',
 ('*', 'Offset direction for the Solidify shell. Use 0 for centered shells, 1 for outward, and -1 for inward bias.'): 'スマートモディファイア '
                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Offset kept above the hit surface after dropping.'): '項目 Offset kept above the hit surface after dropping.',
 ('*', 'Offset kept between the conformed detail and the target surface.'): 'Offset kept between the conformed detail and the 対象 surface.',
 ('*', 'Offset the placed component along the target face normal.'): 'Offset the placed component along the 対象 面 normal.',
 ('*', 'Offset used by the shrinkwrap-based surface conform modifier. Useful for decals, kitbash panels, straps, and surface-mounted parts that should stay slightly above the target.'): 'スマートモディファイア '
                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'On Cage'): '項目 On Cage',
 ('*', 'Open or close the Always-on Toggles group at the top of the Smart Modifier N-panel. The default is closed to keep normal sidebar drawing light. This UI state is saved immediately and restored after Blender restarts or a different scene is opened.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Open the Add Modifier popup (see tooltip for beginner-friendly details)'): '開く the 追加 モディファイア popup (see tooltip for beginner '
                                                                                   'friendly details)',
 ('*', 'Open the Base Object menu (see tooltip for details)'): '開く the Base オブジェクト menu (see tooltip for details)',
 ('*', 'Open the detailed help popup for this Smart Modifier tool group. The long help content is loaded only when this button is clicked.'): 'スマートモディファイア '
                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Open this modifier item menu (see tooltip for details)'): '開く this モディファイア item menu (see tooltip for details)',
 ('*', 'Operator ID'): '項目 Operator ID',
 ('*', 'Optional radius limit used by the Cast modifier when supported. Set 0 to let Blender manage it automatically.'): 'スマートモディファイア '
                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Organize Cutters'): '項目 Organize Cutters',
 ('*', 'Organize Details'): '項目 Organize Details',
 ('*', 'Organize Path Instances'): 'Organize パス Instances',
 ('*', 'Organize Slice Helpers'): '項目 Organize Slice Helpers',
 ('*', 'Organize generated slice helpers into a dedicated collection.'): 'Organize generated slice helpers into a dedicated コレクション.',
 ('*', 'Outside Only'): '項目 Outside Only',
 ('*', 'Overall height of the generated profile primitive. Circle and N-gon types use this as the Y diameter.'): 'スマートモディファイア '
                                                                                                                 'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Overall width of the generated profile primitive. Circle and N-gon types use this as the X diameter.'): 'スマートモディファイア '
                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Overwrite'): '項目 Overwrite',
 ('*', 'Overwrite the selected State Set with the current modifier ON/OFF + display states.\nUse this to update a preset after you make changes.\nCaution: This replaces the saved snapshot (Undo can revert).'): 'スマートモディファイア '
                                                                                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Pack Islands'): '項目 Pack Islands',
 ('*', 'Packs UV islands after the unwrap or projection method finishes. Disable this when you want to keep the generated islands in their raw position for manual layout.'): 'スマートモディファイア '
                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Padding between UV islands during Smart Project or Pack. Increase it to reduce texture bleeding; decrease it to use more of the UV tile.'): 'スマートモディファイア '
                                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Parent To Source'): 'Parent To ソース',
 ('*', 'Parent To Surface'): '項目 Parent To Surface',
 ('*', 'Parent the conformed detail objects to the active surface for easier scene organization.'): 'Parent the conformed detail オブジェクト to '
                                                                                                    'the アクティブ surface for easier シーン '
                                                                                                    'organization.',
 ('*', 'Parent the generated detail to the source object for easier scene organization.'): 'Parent the generated detail to the ソース オブジェクト '
                                                                                           'for easier シーン organization.',
 ('*', 'Path Count'): 'パス Count',
 ('*', 'Physics'): '項目 Physics',
 ('*', 'Pin'): '項目 Pin',
 ('*', 'Pin/unpin the selected target.\nPinned targets stay at the top of the Modifier List for quick access, and are kept even if temporarily missing.\nBeginner tip: Use Pin for important modifiers you always want to see/control.'): 'スマートモディファイア '
                                                                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Pinned'): '項目 Pinned',
 ('*', 'Pipe Radius'): '項目 Pipe Radius',
 ('*', 'Pipe Resolution'): 'Pipe 解像度',
 ('*', 'Pivot To Bottom'): '項目 Pivot To Bottom',
 ('*', 'Pivot To Selection'): '項目 Pivot To Selection',
 ('*', 'Plugin ID'): '項目 Plugin ID',
 ('*', 'Point count used for circle, N-gon, and star profile generation.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Points / Turn'): '項目 Points / Turn',
 ('*', 'Precision / Layout / Path'): 'Precision / Layout / パス',
 ('*', 'Precision / Layout Guide'): '項目 Precision / Layout Guide',
 ('*', 'Prefer Grid Fill'): '項目 Prefer Grid Fill',
 ('*', 'Prefer LoopTools'): 'Prefer Loop ツール',
 ('*', 'Preserve Collections'): 'Preserve コレクション',
 ('*', 'Preserve existing sharp-edge shading when the modifier supports it.'): 'Preserve existing sharp 辺 shading when the モディファイア '
                                                                               'supports it.',
 ('*', 'Preserves the active image aspect ratio when Blender UV operators support it. Keep this on when UVs should match a non-square texture image.'): 'スマートモディファイア '
                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Prevent mirrored vertices from crossing the center plane while editing.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Primary axis used by the Bend deformer.'): '項目 Primary axis used by the Bend deformer.',
 ('*', 'Primary axis used by the Taper deformer.'): '項目 Primary axis used by the Taper deformer.',
 ('*', 'Primary axis used by the Twist deformer.'): '項目 Primary axis used by the Twist deformer.',
 ('*', 'Primitive type used by the Cast modifier.'): 'Primitive type used by the Cast モディファイア.',
 ('*', 'Profile Height'): 'Profile 高さ',
 ('*', 'Profile Points'): '項目 Profile Points',
 ('*', 'Profile Type'): '項目 Profile Type',
 ('*', 'Profile Width'): 'Profile 幅',
 ('*', 'Project Offset'): '項目 Project Offset',
 ('*', 'Project To Active Plane'): 'Project To アクティブ Plane',
 ('*', 'Project To Selected Surface'): 'Project To 選択中 Surface',
 ('*', 'Project selected vertices of the active mesh onto the nearest points of another selected mesh. Useful for retopo, shrinkwrap-style cleanup, panel wrapping, and keeping blockout strips glued to a target surface.'): 'スマートモディファイア '
                                                                                                                                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Project selected vertices onto the active face plane with an optional offset. Useful for projection modeling, CAD-like flattening, and keeping panel details flush to a surface.'): 'スマートモディファイア '
                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Project the current selected vertices onto the best line defined by the farthest selected pair. Useful for fast edge straightening and mesh unbending inspired by Align Edges and Unbend Mesh style tools.'): 'スマートモディファイア '
                                                                                                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Projection Radius'): '項目 Projection Radius',
 ('*', 'Projection or wrap axis. For Planar it is the direction used to flatten the mesh; for Cylindrical, Spherical, and Shrink Wrap it becomes the vertical wrap axis.'): 'スマートモディファイア '
                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Push scattered instances away from the surface along the normal.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Quad Checker'): '項目 Quad Checker',
 ('*', 'Quad Filter'): 'Quad フィルター',
 ('*', 'Quick Bend Deformer'): '項目 Quick Bend Deformer',
 ('*', 'Quick Lattice Cage'): '項目 Quick Lattice Cage',
 ('*', 'Quick Repair / Cleanup'): 'Quick 修復 / Cleanup',
 ('*', 'Quick Solidify Plus'): '項目 Quick Solidify Plus',
 ('*', 'Quick Symmetry'): '項目 Quick Symmetry',
 ('*', 'Quick Taper Deformer'): '項目 Quick Taper Deformer',
 ('*', 'Quick Twist Deformer'): '項目 Quick Twist Deformer',
 ('*', 'Random Roll (deg)'): '項目 Random Roll (deg)',
 ('*', 'Random Seed'): '項目 Random Seed',
 ('*', 'Random XY Offset'): '項目 Random XY Offset',
 ('*', 'Random Z (deg)'): '項目 Random Z (deg)',
 ('*', 'Random Z Offset'): '項目 Random Z Offset',
 ('*', 'Random Z Rotation (deg)'): 'Random Z 回転 (deg)',
 ('*', 'Random seed used for scatter placement.'): '項目 Random seed used for scatter placement.',
 ('*', 'Randomize Selected'): 'Randomize 選択中',
 ('*', 'Real-World Scale'): 'Real ワールド スケール',
 ('*', 'Realtime Viewport'): '項目 Realtime Viewport',
 ('*', 'Rebake All'): 'Rebake すべて',
 ('*', 'Rebuild Active Curve'): 'Rebuild アクティブ カーブ',
 ('*', 'Rebuild Count'): '項目 Rebuild Count',
 ('*', 'Rebuild the Modifier List and Object List based on the current Scope/Mode.\nUse this after adding/removing/renaming modifiers, or when the UI looks out of date.\nTip: When Auto Refresh is ON, this runs automatically at the interval you set.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Recalculate Normals'): '項目 Recalculate Normals',
 ('*', 'Recalculate Smart Lattice influence (the lattice-to-mesh deformation range).\n\n- Use this after changing the lattice size/position if deformation is offset or not working.\n- Automatically detects and updates the target Smart Lattice.\n\nTip: Applying/confirming lattice edits first tends to be more stable.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Recalculate normals after cleanup to reduce shading glitches.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Recalculate normals after the helper finishes.'): '項目 Recalculate normals after the helper finishes.',
 ('*', "Recompute all EditPoly layers. After stack changes, it rebuilds consistency between each layer's Frozen base and Edit mesh."): 'スマートモディファイア '
                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Refresh Interval'): '更新 Interval',
 ('*', 'Refresh and focus the Smart Modifier N-panel entry. Use this compatibility operator when an older shortcut still points to the previous Smart Tools command.'): 'スマートモディファイア '
                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Relative X offset used by the Array modifier.'): 'Relative X offset used by the Array モディファイア.',
 ('*', 'Relax Selection'): '項目 Relax Selection',
 ('*', 'Relax the current selected vertices or edge loop. Uses LoopTools Relax when available, and otherwise falls back to Blender smoothing for a safer all-in-one cleanup pass inspired by LoopTools, NitroRelax, and oaRelaxVerts.'): 'スマートモディファイア '
                                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Remove Modifiers'): '削除 モディファイア',
 ('*', 'Remove target objects after the replacement copies are created.'): '削除 対象 オブジェクト after the replacement copies are created.',
 ('*', 'Remove the matching modifiers from all objects in the current scope.\nThis is destructive (it deletes the modifiers).\nTip: If you might need them later, use OFF (disable) instead of removing.'): 'スマートモディファイア '
                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Rename'): '項目 Rename',
 ('*', 'Rename the modifier (display name) (see tooltip for beginner-friendly details)'): 'Rename the モディファイア (display 名前) (see tooltip '
                                                                                          'for beginner friendly details)',
 ('*', 'Render'): 'レンダー',
 ('*', 'Render visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Repair common mesh issues on the selected mesh objects: merge doubles, dissolve degenerates, delete loose geometry, optionally fill holes, optionally join triangles to quads, and recalculate normals. Designed as a safe recovery pass for imported assets, boolean-heavy meshes, and messy kitbash data.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Repeats the generated coordinates in the U direction. Values above 1 repeat the texture more often; values below 1 stretch it.'): 'スマートモディファイア '
                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Repeats the generated coordinates in the V direction. Values above 1 repeat the texture more often; values below 1 stretch it.'): 'スマートモディファイア '
                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Replace With Active'): 'Replace With アクティブ',
 ('*', 'Replace the selected target objects with copies of the active object while preserving each target transform. Useful for instance replacement, kitbash swaps, and proxy-to-final workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Resample the active curve into a cleaner evenly spaced poly spline. Useful for MoI/ CAD-style curve rebuild workflows before pipes, sweeps, and path arrays.'): 'スマートモディファイア '
                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Reset object rotation and scale into a stack modifier.'): 'リセット オブジェクト 回転 and スケール into a stack モディファイア.',
 ('*', 'Resolution'): '解像度',
 ('*', 'Resolve exactly two selected edges in Edit Mode. Intersect inserts a shared intersection point when the line crossing lies on both segments. Extend moves the nearest endpoints so the edges meet at the resolved point. Useful as a tinyCAD-style precision helper.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Restore UVW Map Backup'): '項目 Restore UVW Map Backup',
 ('*', 'Restore Unwrap UVW Backup'): '項目 Restore Unwrap UVW Backup',
 ('*', 'Restore the UV coordinates that were backed up before this UVW Map stack entry first generated or rebuilt the selected UV map.'): 'スマートモディファイア '
                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Restore the UV coordinates that were backed up before this Unwrap UVW stack entry first generated or rebuilt the selected UV map.'): 'スマートモディファイア '
                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Retired compact guide panel. Use the Help icon buttons for detailed localized help.'): 'Retired compact guide panel. Use the ヘルプ '
                                                                                               'icon buttons for detailed localized ヘルプ.',
 ('*', 'Return to Edit Mode after creation so you can continue symmetry cleanup immediately.'): 'Return to Edit モード after creation so you '
                                                                                                'can continue symmetry cleanup '
                                                                                                'immediately.',
 ('*', 'Reuse Existing'): '項目 Reuse Existing',
 ('*', 'Root group that contains every Smart Modifier N-panel tool.'): 'Root group that contains every スマート モディファイア N panel ツール.',
 ('*', 'Rotate instances so their local X axis follows the sampled path tangent.'): 'Rotate instances so their local X axis follows the '
                                                                                    'sampled パス tangent.',
 ('*', 'Rotates the generated UV coordinates around the center of the 0-1 tile. Use it to align the texture direction after projection.'): 'スマートモディファイア '
                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Rotates the virtual UVW mapping gizmo around local X before projection. Use it when the projection plane or wrap direction needs to be tilted.'): 'スマートモディファイア '
                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Rotates the virtual UVW mapping gizmo around local Y before projection. Use it to align the mapping to slanted geometry.'): 'スマートモディファイア '
                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Rotates the virtual UVW mapping gizmo around local Z before projection. Use it to turn planar, box, or wrap mapping around the object.'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Row-to-row offset ratio used to stagger floor boards.'): '項目 Row to row offset ratio used to stagger floor boards.',
 ('*', 'Run EdgeNet Prepare / Fill before generic face fill. This improves success on branchy edge networks and patch-like selections.'): 'スマートモディファイア '
                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Run User Tool'): '実行 User ツール',
 ('*', 'Run a Smart Modifier user tool from the migrated modifier catalog.'): '実行 a スマート モディファイア user ツール from the migrated モディファイア カタログ.',
 ('*', 'Run a beautify pass after filling to reduce awkward internal diagonals when Blender can improve them safely.'): 'スマートモディファイア '
                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Run a compact face-modeling helper that optionally insets first, then extrudes and shrink-fattens the current selection. This acts as a practical Blender-native helper inspired by Maya Smart Extrude and ZModeler QMesh style workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                      'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Run a conservative cleanup pass on the active or selected mesh objects, then refresh the audit summary. The repair focuses on merge-by-distance, degenerate cleanup, loose removal, and normal recalculation instead of risky topology rewrites.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Run a light cleanup pass after joining meshes.'): '実行 a ライト cleanup pass after joining meshes.',
 ('*', 'Run a light cleanup pass on the newly separated object to reduce loose elements and normal issues.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Run a stack item action such as reorder, isolate, or maintenance from the Smart Modifier stack UI.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'SMS_Lattice'): '項目 SMS Lattice',
 ('*', 'SMS_Mirror'): '項目 SMS Mirror',
 ('*', 'SMS_Solidify'): '項目 SMS Solidify',
 ('*', 'Sample the first and last points of the path as placement positions.'): 'Sample the first and last points of the パス as placement '
                                                                                'positions.',
 ('*', 'Save New'): '保存 New',
 ('*', 'Scale Max'): 'スケール Max',
 ('*', 'Scale Min'): 'スケール Min',
 ('*', 'Scale To Bounds'): 'スケール To Bounds',
 ('*', 'Scale To Face'): 'スケール To 面',
 ('*', 'Scales generated UVs into the 0-1 tile when the selected unwrap/projection method supports it. Use this for texture-ready coordinates inside the main tile.'): 'スマートモディファイア '
                                                                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Scatter Count'): '項目 Scatter Count',
 ('*', 'Scatter Instances (Bake)'): 'Scatter Instances (ベイク)',
 ('*', 'Scatter Seed'): '項目 Scatter Seed',
 ('*', 'Scatter linked copies of the selected source objects along the active curve using even distance sampling. Useful for Duplicate Along Path, MASH-style path layouts, trims, railing, and RailClone-like path-driven blocking.'): 'スマートモディファイア '
                                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Scatter linked object instances over the active surface using weighted triangle-area sampling. Creates a dedicated scatter collection and a root empty, making it useful for environment blocking, vegetation placement, debris, and kitbash dressing inspired by Forest Pack / Geo-Scatter style workflows.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Scope'): '項目 Scope',
 ('*', 'Search filter for the Modifier List.\nType part of a modifier type/name to narrow the list (case-insensitive).'): 'スマートモディファイア '
                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Search filter for the Object List.\nType part of an object name to narrow the list (case-insensitive).'): 'スマートモディファイア '
                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Seed used for deterministic randomization.'): '項目 Seed used for deterministic randomization.',
 ('*', 'Segment count used by the auto-created bevel modifier.'): 'Segment count used by the 自動 created bevel モディファイア.',
 ('*', 'Select All Listed'): '選択 すべて Listed',
 ('*', 'Select Instances'): '選択 Instances',
 ('*', 'Select Issues'): '選択 Issues',
 ('*', 'Select New Cuts'): '選択 New Cuts',
 ('*', 'Select every object currently shown in the Object List.\nTip: Combine with Scope/filters to quickly build a selection set.\nNote: This only changes the viewport selection; it does not edit the Object List itself.'): 'スマートモディファイア '
                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Select objects in the same instance (linked) group (see tooltip for details)'): '選択 オブジェクト in the same instance (linked) group '
                                                                                        '(see tooltip for details)',
 ('*', 'Select quads, non-quads, triangles, or ngons on the active edit mesh for fast topology inspection before subdivision, export, bevel, or retopo cleanup.'): 'スマートモディファイア '
                                                                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Select the chosen audit issue type on the active mesh so you can inspect or repair it directly.'): 'スマートモディファイア '
                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Select the newly generated cut edges after Axis Slice Edit runs.'): '選択 the newly generated cut 辺 after Axis Slice Edit 実行.',
 ('*', 'Select which side of the axis remains after the cut.'): '選択 which side of the axis remains after the cut.',
 ('*', 'Selected Edges To Curve'): '選択中 辺 To カーブ',
 ('*', 'Selected Faces Only'): '選択中 面 Only',
 ('*', 'Selected Objects To Path'): '選択中 オブジェクト To パス',
 ('*', 'Selected Vertices To Path'): '選択中 Vertices To パス',
 ('*', 'Selection Behavior'): '項目 Selection Behavior',
 ('*', 'Separate the current selection into a new object with an optional duplicate-first step and a light cleanup pass. This acts as a safe Blender-friendly helper inspired by Maya detachSeparate and similar clean detachment utilities.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Set the lattice divisions (U/V/W).\nChoose a preset (2/3/4) or Custom.\n\nNote: Higher values allow finer deformation but are heavier.'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Settings'): '設定項目',
 ('*', 'Shade Smooth'): '項目 Shade Smooth',
 ('*', 'Shade Smooth Loft'): '項目 Shade Smooth Loft',
 ('*', 'Show Details'): '項目 Show Details',
 ('*', 'Show End Result'): '項目 Show End Result',
 ('*', 'Show Modifier List'): 'Show モディファイア List',
 ('*', 'Show Object List'): 'Show オブジェクト List',
 ('*', 'Show Objects'): 'Show オブジェクト',
 ('*', 'Show Properties'): '項目 Show Properties',
 ('*', 'Show Settings'): 'Show 設定項目',
 ('*', 'Show State Sets'): '項目 Show State Sets',
 ('*', 'Show a lightweight standalone panel inside the Smart Modifier tab so you can still add/rebake layers without Smart Modifier.\nNormally, managing layers from Smart Modifier is recommended. Turn this ON only when you want standalone operation.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Show a lightweight standalone panel inside the Smart Modifier tab so you can still use Smart Lattice without Smart Modifier.\nNormally, managing it from Smart Modifier is recommended. Turn this ON only for standalone use.'): 'スマートモディファイア '
                                                                                                                                                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Show generated slice helpers as wire objects.'): 'Show generated slice helpers as wire オブジェクト.',
 ('*', 'Show only objects that are currently visible in the viewport.\nHidden or excluded objects are ignored (useful to skip helper objects).'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Show standalone panel in Smart Modifier tab'): 'Show standalone panel in スマート モディファイア tab',
 ('*', 'Show/hide the Details section.\n\nThis only folds the UI to save space.'): 'Show/hide the Details section. This only folds the UI '
                                                                                   'to 保存 space.',
 ('*', 'Show/hide the Modifier List section.\n\nThis only folds the UI to save space; it does not change any modifiers.'): 'スマートモディファイア '
                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Show/hide the Object List section.\n\nThis only folds the UI to save space; it does not change selection or objects.'): 'スマートモディファイア '
                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Show/hide the Settings section.\n\nThis only folds the UI to save space.'): 'Show/hide the 設定項目 section. This only folds the UI to '
                                                                                    '保存 space.',
 ('*', 'Show/hide the State Sets section.\n\nThis only folds the UI to save space; it does not apply any state sets by itself.'): 'スマートモディファイア '
                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Shrinkwrap mode used by Surface Conform Modifier.'): 'Shrinkwrap モード used by Surface Conform モディファイア.',
 ('*', 'Slice / Panel Stack'): '項目 Slice / Panel Stack',
 ('*', 'Slice Axis'): '項目 Slice Axis',
 ('*', 'Slice Count'): '項目 Slice Count',
 ('*', 'Slice Helpers Wire'): '項目 Slice Helpers Wire',
 ('*', 'Slice Operation'): '項目 Slice Operation',
 ('*', 'Slice Thickness'): '項目 Slice Thickness',
 ('*', 'Slice Tolerance'): '項目 Slice Tolerance',
 ('*', 'Smart Extrude Clean'): 'スマート Extrude クリーン',
 ('*', 'Smart Extrude Distance'): 'スマート Extrude Distance',
 ('*', 'Smart Extrude Inset'): 'スマート Extrude Inset',
 ('*', 'Smart Fill / Quad Repair'): 'スマート Fill / Quad 修復',
 ('*', 'Smart Lattice Live Sync'): 'スマート Lattice Live Sync',
 ('*', 'Smart Modifier'): 'スマートモディファイア',
 ('*', 'Smart Modifier Hub'): 'スマート モディファイア Hub',
 ('*', 'Smart Modifier Hub panel in the Smart Modifier workspace.'): 'スマート モディファイア Hub panel in the スマート モディファイア ワークスペース.',
 ('*', 'Smart Modifier'): 'スマートモディファイア',
 ('*', 'SmartLattice Standalone'): 'スマート Lattice Standalone',
 ('*', 'Solidify Even Thickness'): '項目 Solidify Even Thickness',
 ('*', 'Solidify Offset'): '項目 Solidify Offset',
 ('*', 'Solidify Quality Normals'): 'Solidify 品質 Normals',
 ('*', 'Solidify Rim'): '項目 Solidify Rim',
 ('*', 'Solidify Thickness'): '項目 Solidify Thickness',
 ('*', 'Solo Selected'): 'Solo 選択中',
 ('*', 'Solver'): '項目 Solver',
 ('*', 'Stack Axis'): '項目 Stack Axis',
 ('*', 'Stack Gap'): '項目 Stack Gap',
 ('*', 'Stack Order'): '項目 Stack Order',
 ('*', 'Stack Selected'): 'Stack 選択中',
 ('*', 'Stack selected objects one after another along the chosen world axis using their world-space bounds plus a configurable gap. Useful for shelf dressing, prop lineup, packing previews, and quick contact-free layout stacking.'): 'スマートモディファイア '
                                                                                                                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Standalone panel for Edit Polygon Modifier when it is used outside the main Smart Modifier stack.'): 'スマートモディファイア '
                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Standalone panel for Smart Lattice Modifier when it is used outside the main Smart Modifier stack.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Star Inner Ratio'): '項目 Star Inner Ratio',
 ('*', 'Start from the active object, then order the remaining selected objects by nearest-neighbor distance so the generated path follows the placed layout more naturally.'): 'スマートモディファイア '
                                                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'State'): '項目 State',
 ('*', 'Stay in Edit Mode'): 'Stay in Edit モード',
 ('*', 'Stores settings for the Advanced / Surface Modeling panel.'): 'Stores 設定項目 for the 詳細 / Surface モデリング panel.',
 ('*', 'Stores settings used by the Precision / Layout / Path operators and their Add Modifier entry points.'): 'スマートモディファイア '
                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Stores settings used by the Smart Modifier Hub operators and their Add Modifier entry points.'): 'スマートモディファイア '
                                                                                                         'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Stores the latest compact mesh audit summary for display in the panel.'): 'Stores the latest compact メッシュ audit summary for '
                                                                                  'display in the panel.',
 ('*', 'Straighten Selection'): '項目 Straighten Selection',
 ('*', 'Strength of the Cast deformation. Larger values push the mesh further toward the chosen primitive type.'): 'スマートモディファイア '
                                                                                                                   'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Surface Box Detail'): '項目 Surface Box Detail',
 ('*', 'Surface Box Height'): 'Surface Box 高さ',
 ('*', 'Surface Box Length'): '項目 Surface Box Length',
 ('*', 'Surface Box Operation'): '項目 Surface Box Operation',
 ('*', 'Surface Box Width'): 'Surface Box 幅',
 ('*', 'Surface Box Wire'): '項目 Surface Box Wire',
 ('*', 'Surface Conform Modifier'): 'Surface Conform モディファイア',
 ('*', 'Surface Offset'): '項目 Surface Offset',
 ('*', 'Surface Project Offset'): '項目 Surface Project Offset',
 ('*', 'Sweep Active Profile'): 'Sweep アクティブ Profile',
 ('*', 'Sweep Fill Caps'): '項目 Sweep Fill Caps',
 ('*', 'Sweep Resolution'): 'Sweep 解像度',
 ('*', 'Switch Level'): '項目 Switch Level',
 ('*', 'Switch an always-on feature on or off. N-panel State Save controls whether the change is saved immediately or deferred.'): '常時起動機能の有効 / 無効を切り替えます。保存タイミングは「Nパネル状態保存」に従います。'
                                                                                   'setting immediately.',
 ('*', 'Symmetry Direction'): '項目 Symmetry Direction',
 ('*', 'Symmetry Merge Threshold'): '項目 Symmetry Merge Threshold',
 ('*', 'Sync EditPoly edit state safely when Smart Modifier switches the active level.'): 'Sync Edit Polygon edit state safely when スマート '
                                                                                          'モディファイア switches the アクティブ level.',
 ('*', 'Sync Level Switch'): '項目 Sync Level Switch',
 ('*', 'Target Object'): '対象 オブジェクト',
 ('*', 'Target length of each floor board segment.'): '対象 length of each floor board segment.',
 ('*', 'Thickness of each slice helper box.'): '項目 Thickness of each slice helper box.',
 ('*', 'Thickness of the generated floor boards.'): '項目 Thickness of the generated floor boards.',
 ('*', 'Toggle'): '項目 Toggle',
 ('*', 'Toggle All'): 'Toggle すべて',
 ('*', 'Toggle Feature'): '項目 Toggle Feature',
 ('*', 'Toggle Visibility'): '項目 Toggle Visibility',
 ('*', 'Toggle edit levels (see tooltip for beginner-friendly details)'): 'スマートモディファイア の設定項目です。',
 ('*', 'Toggle modifier enabled/disabled (see tooltip for beginner-friendly details)'): 'Toggle モディファイア 有効/無効 (see tooltip for beginner '
                                                                                        'friendly details)',
 ('*', 'Toggle the ACTIVE target for the object you click (one object at a time).\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: Use the big ON/OFF buttons to change ALL objects at once.'): 'スマートモディファイア '
                                                                                                                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Toggle the enabled/disabled state of many modifiers at once inside the modifier switcher workflow.'): 'スマートモディファイア '
                                                                                                              'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Toggle viewport visibility (monitor) (see tooltip for beginner-friendly details)'): 'スマートモディファイア の設定項目です。',
 ('*', 'Total height of the generated helix path.'): 'Total 高さ of the generated helix パス.',
 ('*', 'True when this object shares its data (an instance) with another object in the list.\nInstances often share the same modifier stack.'): 'スマートモディファイア '
                                                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Try Bridge Loops'): '項目 Try Bridge Loops',
 ('*', 'Try EdgeNet Fill'): 'Try 辺 Net Fill',
 ('*', 'Try Grid Fill early when a single boundary loop is selected so patch results stay quad-friendly when possible.'): 'スマートモディファイア '
                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Try Holes Fill'): '項目 Try Holes Fill',
 ('*', 'Try to fill open boundaries after cleanup.'): 'Try to fill 開く boundaries after cleanup.',
 ('*', 'Try to join adjacent triangles into quads after cleanup or fill.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Try to keep offset more even during shrink/fatten.'): '項目 Try to keep offset more even during shrink/fatten.',
 ('*', 'Twist Angle (deg)'): '項目 Twist Angle (deg)',
 ('*', 'Twist Axis'): '項目 Twist Axis',
 ('*', 'Twist Lower Limit'): '項目 Twist Lower Limit',
 ('*', 'Twist Upper Limit'): '項目 Twist Upper Limit',
 ('*', 'Type'): '項目 Type',
 ('*', 'U'): '項目 U',
 ('*', 'U Offset'): '項目 U Offset',
 ('*', 'U Tile'): '項目 U Tile',
 ('*', 'UI label shown in the target list.\nThis is generated automatically.'): 'UI label shown in the 対象 list. This is generated '
                                                                                'automatically.',
 ('*', 'UV Rotation'): 'UV 回転',
 ('*', 'Uniform Scale Max'): 'Uniform スケール Max',
 ('*', 'Uniform Scale Min'): 'Uniform スケール Min',
 ('*', 'Uniformly scale each placed component by the square-root of the target face area.'): 'Uniformly スケール each placed component by the '
                                                                                             'square root of the 対象 面 area.',
 ('*', 'Unwrap Method'): '項目 Unwrap Method',
 ('*', 'Up'): '項目 Up',
 ('*', 'Update Influence'): '更新 Influence',
 ('*', 'Update Influence Range'): '更新 Influence Range',
 ('*', 'Update List'): '更新 List',
 ('*', 'Update influence range (vertex group) (see tooltip for beginner-friendly details)'): '更新 influence range (頂点 group) (see tooltip '
                                                                                             'for beginner friendly details)',
 ('*', 'Upper normalized limit for the Bend modifier, useful for partial roll and localized deformation.'): 'スマートモディファイア '
                                                                                                            'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Upper normalized limit for the Taper modifier, useful for partial narrowing and localized silhouette edits.'): 'スマートモディファイア '
                                                                                                                       'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Upper normalized limit for the Twist modifier, useful for partial torsion and localized twisting.'): 'スマートモディファイア '
                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Use 3D Cursor Z'): '項目 Use 3D Cursor Z',
 ('*', 'Use Bounds'): '項目 Use Bounds',
 ('*', 'Use Clipping'): '項目 Use Clipping',
 ('*', 'Use Cursor Orientation'): '項目 Use Cursor Orientation',
 ('*', 'Use Cursor Origin'): '項目 Use Cursor Origin',
 ('*', 'Use Cursor Origin for Cast'): '項目 Use Cursor Origin for Cast',
 ('*', 'Use Cursor Pivot'): '項目 Use Cursor Pivot',
 ('*', 'Use Fill Holes as a late fallback for open boundary cleanup when other fill methods do not succeed.'): 'スマートモディファイア '
                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', "Use LoopTools when available before falling back to Blender's To Sphere transform."): 'Use Loop ツール when available before falling '
                                                                                              "back to Blender's To Sphere トランスフォーム.",
 ('*', 'Use LoopTools when available before falling back to built-in Blender smoothing.'): 'Use Loop ツール when available before falling '
                                                                                           'back to built in Blender smoothing.',
 ('*', 'Use Nearest Chain'): '項目 Use Nearest Chain',
 ('*', 'Use Nearest Vertex Chain'): 'Use Nearest 頂点 Chain',
 ('*', 'Use Selection Bounds'): '項目 Use Selection Bounds',
 ('*', 'Use Subdivision Surface'): '項目 Use Subdivision Surface',
 ('*', 'Use face strength / influence information when available for stronger hard-surface shading control.'): 'スマートモディファイア '
                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Use linked mesh data for each placed component instead of making full data copies.'): 'Use linked メッシュ data for each placed '
                                                                                              'component instead of making full data '
                                                                                              'copies.',
 ('*', 'Use linked object data instead of full data copies.'): 'Use linked オブジェクト data instead of full data copies.',
 ('*', 'Use only the outer lattice points when the generated lattice supports it.'): 'スマートモディファイア の設定項目です。',
 ('*', 'Use the 3D cursor Z value as the target floor height instead of the manual Floor Z field.'): 'Use the 3D cursor Z value as the 対象 '
                                                                                                     'floor 高さ instead of the 手動 Floor Z '
                                                                                                     'field.',
 ('*', 'Use the object bounds to place the lowest point on the hit surface. When disabled, the object origin is placed on the surface instead.'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Use the selected profile curve as a bevel object on the active path curve. This is useful for Sweep Mesh, trim profiles, moldings, cable trays, rail sections, and CAD-style spline workflows where a reusable 2D profile is pushed along a path.'): 'スマートモディファイア '
                                                                                                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'User'): '項目 User',
 ('*', 'Uses Length, Width, and Height as explicit texture scale values instead of fitting to the object. This is useful when multiple objects need the same texel density.'): 'スマートモディファイア '
                                                                                                                                                                               'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Uses subdivision-surface evaluation data while unwrapping when Blender supports it. Enable this when the UVs should better match a smoothed subdivision result.'): 'スマートモディファイア '
                                                                                                                                                                           'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'V'): '項目 V',
 ('*', 'V Offset'): '項目 V Offset',
 ('*', 'V Tile'): '項目 V Tile',
 ('*', 'VIEW3D_MT_ms_base_menu'): '項目 VIEW3D MT ms base menu',
 ('*', 'VIEW3D_MT_ms_item_menu'): '項目 VIEW3D MT ms item menu',
 ('*', 'Vertices close to the cut plane are treated as center-line vertices.'): 'Vertices 閉じる to the cut plane are treated as center line '
                                                                                'vertices.',
 ('*', 'Viewport'): '項目 Viewport',
 ('*', 'Viewport visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'スマートモディファイア '
                                                                                                                'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Viewport/path resolution applied to the path curve when configuring the sweep.'): 'Viewport/パス 解像度 applied to the パス カーブ when '
                                                                                          'configuring the sweep.',
 ('*', 'Virtual cube size used by Box Map projection. Increase it to make projected UVs cover a smaller portion of the texture tile.'): 'スマートモディファイア '
                                                                                                                                        'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Virtual radius used by Cylindrical Map projection. Adjust it when cylindrical mapping appears too compressed or too stretched.'): 'スマートモディファイア '
                                                                                                                                          'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Visible Only'): '項目 Visible Only',
 ('*', 'W'): '項目 W',
 ('*', 'Weight'): '項目 Weight',
 ('*', 'Weighted Normal'): '項目 Weighted Normal',
 ('*', 'Weighted Normal mode used by the modifier when Blender exposes the option.'): 'Weighted Normal モード used by the モディファイア when '
                                                                                      'Blender exposes the option.',
 ('*', "When Scope is set to 'Collection', pick the collection to use.\nOnly objects in this collection will be listed/affected."): 'スマートモディファイア '
                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'When converting selected vertices to a path, start from the active vertex when possible and order the remaining vertices by nearest-neighbor distance.'): 'スマートモディファイア '
                                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'When enabled, Axis Slice Edit derives the slice range from the current selection when possible. The cuts still pass through the mesh like a numeric slice helper.'): 'スマートモディファイア '
                                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'When enabled, Quad Checker only inspects the currently selected faces. Disable it to inspect the whole active edit mesh.'): 'スマートモディファイア '
                                                                                                                                    'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'When enabled, unwraps only the current Edit Mode face selection. When disabled, all faces on each target mesh are selected before generating UVs.'): 'スマートモディファイア '
                                                                                                                                                             'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'When the selection resolves to two disconnected edge groups, try Bridge Edge Loops first so strips and caps can be generated in-place.'): 'スマートモディファイア '
                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Whether this target is pinned (kept) even if it is not found in the current selection.\nPinned targets stay in the list so you can reuse them quickly.'): 'スマートモディファイア '
                                                                                                                                                                  'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Width'): '幅',
 ('*', 'Width of each generated floor board row.'): '幅 of each generated floor board row.',
 ('*', 'Width of the UVW mapping gizmo in local object space. This controls the second planar or box dimension used to calculate U/V coordinates.'): 'スマートモディファイア '
                                                                                                                                                     'の機能説明です。対象を選択し、Nパネルの設定を確認してから実行してください。',
 ('*', 'Width of the generated surface detail box.'): '幅 of the generated surface detail box.',
 ('*', 'Width used by the auto-created bevel modifier.'): '幅 used by the 自動 created bevel モディファイア.',
 ('*', 'Workplane From Active'): 'Workplane From アクティブ',
 ('*', 'World axis used by Distribute Selected.'): 'ワールド axis used by Distribute 選択中.',
 ('*', 'World axis used by Stack Selected.'): 'ワールド axis used by Stack 選択中.',
 ('*', 'World-space floor height used by Drop To Floor when 3D Cursor Z is disabled.'): 'ワールド space floor 高さ used by Drop To Floor when 3D '
                                                                                        'Cursor Z is 無効.'}


# Explicit section-label override. Keep the top-level N-panel section name stable
# even when supplemental auto-generated translations are registered after the
# main catalog.
EXTRA_TRANSLATIONS.update({
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Edit Polygon'): '編集ポリゴン',
    ('*', 'Add Edit Polygon'): '編集ポリゴンを追加',
    ('*', 'Edit Polygon Modifier'): '編集ポリゴン',
})
