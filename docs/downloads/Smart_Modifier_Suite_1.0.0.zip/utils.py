# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy

SUITE_BASENAME = "smart_modifier_suite"


def _root_id_from_package(pkg: str, suite_basename: str = SUITE_BASENAME) -> str:
    """
    Resolve the add-on root id robustly.
    - Normal add-on: "smart_modifier_suite.*" -> "smart_modifier_suite"
    - Extension add-on: "bl_ext.user_default.smart_modifier_suite.*" -> "bl_ext.user_default.smart_modifier_suite"
    """
    if not pkg:
        return suite_basename
    parts = pkg.split(".")
    if suite_basename in parts:
        idx = parts.index(suite_basename)
        return ".".join(parts[:idx + 1])
    return parts[0]


def get_addon_prefs(context=None, suite_basename: str = SUITE_BASENAME):
    """Return Smart Modifier N-panel runtime settings. Addon Preferences are not used."""
    del suite_basename
    try:
        from .preferences import get_preferences as _ms_get_window_settings
        prefs = _ms_get_window_settings(context)
        if prefs is not None and hasattr(prefs, 'use_modifier_stack'):
            return prefs
    except Exception:
        pass
    return None


def get_suite_prefs(context=None):
    """Return Smart Modifier N-panel runtime settings, or None."""
    return get_addon_prefs(context=context, suite_basename=SUITE_BASENAME)


def feature_enabled(context, flag_name: str, default=True) -> bool:
    prefs = get_suite_prefs(context)
    if not prefs:
        return default
    return bool(getattr(prefs, flag_name, default))


def external_feature_enabled(context, suite_basename: str, flag_name: str, default=True, when_missing=False) -> bool:
    """Check another add-on's preference flag safely.

    Args:
        suite_basename: e.g. "smart_modeling_suite"
        flag_name: preference attribute to read
        default: fallback when the add-on exists but the flag is absent
        when_missing: value to return when the add-on itself is not installed/enabled
    """
    prefs = get_addon_prefs(context=context, suite_basename=suite_basename)
    if not prefs:
        return bool(when_missing)
    return bool(getattr(prefs, flag_name, default))



def get_operator_callable(operator_id: str):
    """Resolve a bpy.ops callable from a string like ``module.operator``."""
    try:
        module_name, op_name = str(operator_id or '').split('.', 1)
        module = getattr(bpy.ops, module_name)
        return getattr(module, op_name)
    except Exception:
        return None


def operator_available(operator_id: str) -> bool:
    """Return True only when Blender has registered the operator RNA.

    ``getattr(bpy.ops, ...)`` returns a lazy proxy even for unknown operator
    identifiers.  Treating that proxy as an installed operator caused optional
    compatibility branches to call removed Blender operators such as
    ``mesh.edgenet_fill``.  ``get_rna_type()`` is the authoritative check in
    Blender 5.1.
    """
    op = get_operator_callable(operator_id)
    if op is None:
        return False
    try:
        op.get_rna_type()
        return True
    except Exception:
        return False


def operator_runnable(operator_id: str) -> bool:
    """Return True when the operator exists and poll() currently passes.

    When poll() is unavailable or raises unexpectedly, availability is treated
    as runnable so the caller can still fall back to execution-time handling.
    """
    if not operator_available(operator_id):
        return False
    op = get_operator_callable(operator_id)
    if op is None:
        return False
    try:
        return bool(op.poll())
    except Exception:
        return True


def operator_result_succeeded(result) -> bool:
    """Return True when a Blender operator result indicates success.

    Blender operators usually return a set such as {'FINISHED'},
    {'RUNNING_MODAL'}, or {'CANCELLED'}. Some older/custom wrappers may
    return tuples/lists. This helper normalizes those cases so callers do not
    accidentally treat {'CANCELLED'} as success.
    """
    if isinstance(result, set):
        return bool({'FINISHED', 'RUNNING_MODAL'} & result)
    if isinstance(result, (tuple, list)):
        try:
            return bool({'FINISHED', 'RUNNING_MODAL'} & set(result))
        except Exception:
            return False
    if isinstance(result, bool):
        return result
    return False


def call_operator_safe(op_callable, *args, **kwargs):
    """Call a Blender operator and return its result only when it succeeded.

    Returns:
        The operator result set when it contains FINISHED/RUNNING_MODAL.
        Returns None when the operator raised or returned CANCELLED/PASS_THROUGH.
    """
    try:
        result = op_callable(*args, **kwargs)
    except Exception:
        return None
    return result if operator_result_succeeded(result) else None


def safe_mode_set(mode: str):
    """Best-effort wrapper around ``bpy.ops.object.mode_set``.

    Returns the successful Blender operator result, or None when the operator
    is unavailable / cancelled. Callers can treat ``None`` as failure without
    accidentally promoting ``{'CANCELLED'}`` to success.
    """
    return call_operator_safe(lambda: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode=mode))


def safe_select_all(action: str = 'DESELECT'):
    """Best-effort wrapper around ``bpy.ops.object.select_all``."""
    return call_operator_safe(lambda: bpy.ops.object.select_all('EXEC_DEFAULT', False, action=action))


def safe_join_selected():
    """Best-effort wrapper around ``bpy.ops.object.join``."""
    return call_operator_safe(lambda: bpy.ops.object.join('EXEC_DEFAULT', False, ))


def safe_call_menu(name: str):
    """Best-effort wrapper around ``bpy.ops.wm.call_menu``."""
    return call_operator_safe(lambda: bpy.ops.wm.call_menu(name=name))


def safe_activate_only(context, obj, *, select: bool = True) -> bool:
    """Activate one object while gracefully handling selection/operator issues.

    This is intentionally tolerant because many workflow helpers need to keep
    working even when Blender temporarily rejects one part of the context.
    The function returns True when the target could be made active, even if the
    deselect step had to be skipped.
    """
    if context is None or obj is None:
        return False
    safe_select_all('DESELECT')
    success = False
    try:
        if select:
            obj.select_set(True)
        success = True
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
        success = True
    except Exception:
        pass
    return success

