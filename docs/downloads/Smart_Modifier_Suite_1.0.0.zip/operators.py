# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy 
import time 
import uuid 
import copy
from array import array
from mathutils import Vector 
from bpy .props import StringProperty ,BoolProperty ,IntProperty 
from .core import *
from .translation import choose_text ,pgettext 

try:
    from .icons import operator as _sms_icon_operator, prop as _sms_icon_prop
except Exception:
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)
    def _sms_icon_prop(layout, data, prop_name, *, text='', icon_name='', fallback_icon='NONE', **kwargs):
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        try:
            return layout.prop(data, prop_name, text=text, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.prop(data, prop_name, text=text, **kwargs)


# ------------------------------------------------------------
# Deterministic level switch (analog, robust):
# Serialize stack switching (Base / standard / EditPoly / SmartLattice)
# using a two-phase timer so Blender has time to commit mode/selection changes.
# This avoids "needs two clicks", selection loss, and stale lattice visibility.
# ------------------------------------------------------------

# ------------------------------------------------------------
# Deterministic level switch (analog, robust):
# Serialize stack switching (Base / standard / EditPoly / SmartLattice)
# using a two-phase timer so Blender has time to commit mode/selection changes.
#
# IMPORTANT FIX (R7):
# - Use a tokenized request+state model so rapid re-clicks cannot be overwritten
#   by an in-flight timer tick (race condition).
# - New clicks always win and are applied deterministically.
# ------------------------------------------------------------



def _ms_runtime_api ():
    # Heals a driver_namespace that a file load replaced (core._ms_api).
    return _ms_api ("_MS_RUNTIME_API_V1")


def _ms_request_plugin_live_runtime (plugin_id :str ):
    # Do not auto-enable always-on services from a modifier click.  The N-panel
    # Always-on Toggles are the single source of truth; when a service is OFF it
    # stays fully inactive and the tool remains manual/UI-only.
    plugin_id =str (plugin_id or "").strip ()
    if not plugin_id :
        return 
    api =_ms_runtime_api ()
    try :
        if plugin_id =="edit_poly":
            fn =api .get ("edit_poly_live_enabled")
            if callable (fn )and not bool (fn ()):return
        elif plugin_id =="smart_lattice":
            fn =api .get ("smart_lattice_live_enabled")
            if callable (fn )and not bool (fn ()):return
        else :
            fn =api .get ("stack_live_enabled")
            if callable (fn )and not bool (fn ()):return
        sync =api .get ("sync_runtime_services")
        if callable (sync ):sync ()
    except Exception :
        pass 


def _ms_try_clear_lattice_point_selection_once (target_obj )->bool :
    try :
        if not target_obj or getattr (target_obj ,"type","")!='LATTICE':
            return False 
        if not bool (target_obj .get ("_ms_deselect_lattice_points_once",False )):
            return False 
        lat_data =getattr (target_obj ,"data",None )
        points =getattr (lat_data ,"points",None )
        if points is None :
            target_obj .pop ("_ms_deselect_lattice_points_once",None )
            return False 

        changed =False 
        for point in points :
            for attr in ("select","select_control_point","select_u","select_v","select_w"):
                if not hasattr (point ,attr ):
                    continue 
                try :
                    if bool (getattr (point ,attr )):
                        setattr (point ,attr ,False )
                        changed =True 
                except Exception :
                    continue 
        try :
            if changed and hasattr (lat_data ,"update"):
                lat_data .update ()
        except Exception :
            pass 
        target_obj .pop ("_ms_deselect_lattice_points_once",None )
        return changed 
    except Exception :
        return False 


def _ms_queue_level_switch (main_obj ,clicked :str ,ui_row_index :int ,want_edit_mode :bool ):
    dn =_ms__dn ()
    try :
        vl =bpy .context .view_layer 
    except Exception :
        vl =None 

        # Snapshot object selection (exclude lattice helpers)
    sel_names ,active_name =([],"")
    try :
        if vl :
            sel_names ,active_name =_ms_snapshot_object_selection (vl )
            sel_names =[n for n in (sel_names or [])if not (bpy .data .objects .get (n )and bpy .data .objects [n ].type =='LATTICE')]
    except Exception :
        sel_names ,active_name =([],"")

        # Force SmartLattice shared-active cache refresh for this transition.
    try :
        bpy .app .driver_namespace ["_MS_FORCE_SL_SHARED_REFRESH_T"]=time .time ()
    except Exception :
        pass 

        # Force apply_modifier_stack_state to not skip during this transition.
    try :
        fm =dn .get ("_MS_FORCE_APPLY_ONCE_V1")
        if not isinstance (fm ,dict ):
            fm ={}
        fm [main_obj .name ]=time .time ()
        dn ["_MS_FORCE_APPLY_ONCE_V1"]=fm 
    except Exception :
        pass 

        # Arm EndPreview only for Smart Modifier-driven Edit operations.
    try :
        ms_endpreview_set_allowed (main_obj ,bool (want_edit_mode ))
        if not bool (want_edit_mode ):
            ms_request_endpreview_cleanup (main_obj )
    except Exception :
        pass 

        # Capture last apply timestamp so we can detect lock-skips.
    last_apply_t =0.0 
    try :
        mp =dn .get ('_MS_LAST_APPLY_T_V1')
        if isinstance (mp ,dict ):
            last_apply_t =float (mp .get (main_obj .name ,0.0 )or 0.0 )
    except Exception :
        last_apply_t =0.0 

        # Tokenized request (new clicks always win)
    try :
        tok =int (dn .get ('_MS_LEVEL_SWITCH_TOKEN_V1',0 )or 0 )+1 
    except Exception :
        tok =1 
    dn ['_MS_LEVEL_SWITCH_TOKEN_V1']=tok 

    # Allow mode switching only for this user-initiated transition.
    try :
        dn ["_MS_ALLOW_MODESET_V1"]=True 
        dn ["_MS_ALLOW_MODESET_TOKEN_V1"]=int (tok )
        dn ["_MS_ALLOW_MODESET_T_V1"]=float (time .time ())
    except Exception :
        pass 

    dn ['_MS_LEVEL_SWITCH_REQ_V1']={
    'token':tok ,
    'main':main_obj .name ,
    'clicked':clicked ,
    'ui_row':int (ui_row_index ),
    'want_edit':bool (want_edit_mode ),
    'sel':list (sel_names or []),
    'active':str (active_name or ''),
    't':time .time (),
    'last_apply_t':float (last_apply_t or 0.0 ),
    }

    dn ['_MS_TRANSITION_ACTIVE_V1']=True 
    try:
        dn ['_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL']=max(float(dn.get('_MS_UI_SUPPRESS_PANEL_BODIES_UNTIL',0.0)or 0.0), time.time()+0.45)
    except Exception:
        pass
    if not dn .get ('_MS_LEVEL_SWITCH_ARMED_V1'):
        dn ['_MS_LEVEL_SWITCH_ARMED_V1']=True 
        try :
            bpy .app .timers .register (_ms_level_switch_timer ,first_interval =0.03 )
        except Exception :
            try :
                bpy .app .timers .register (_ms_level_switch_timer ,first_interval =0.02 )
            except Exception :
                pass 


def _ms_level_switch_timer ():
    dn =_ms__dn ()
    req =dn .get ('_MS_LEVEL_SWITCH_REQ_V1')
    if not isinstance (req ,dict ):
        dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
        dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
        dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
        return None 



        # Safety: if mode switching is not currently allowed, cancel any pending request.
    try :
        if not bool (dn .get ('_MS_ALLOW_MODESET_V1',False )):
            dn .pop ('_MS_LEVEL_SWITCH_REQ_V1',None )
            dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
            dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
            dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
            return None 
    except Exception :
        return None 

        # Stale request guard: cancel any request that doesn't converge quickly to avoid endless mode toggling.
    try :
        t0 =float (req .get ('t',0.0 )or 0.0 )
        if t0 and (time .time ()-t0 )>5.0 :
            dn .pop ('_MS_LEVEL_SWITCH_REQ_V1',None )
            dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
            dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
            dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
            dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
            return None 
    except Exception :
        pass 

    def _cur_token ()->int :
        try :
            return int (dn .get ('_MS_LEVEL_SWITCH_TOKEN_V1',0 )or 0 )
        except Exception :
            return 0 

            # Start / restart state if token changed (new click)
    st =dn .get ('_MS_LEVEL_SWITCH_STATE_V1')
    if (not isinstance (st ,dict ))or (int (st .get ('token',-1 ))!=int (req .get ('token',-2 ))):
        st =dict (req )
        st .update ({
        'phase':0 ,
        'attempt':0 ,
        'target':'',
        })
        dn ['_MS_LEVEL_SWITCH_STATE_V1']=st 

        # If a newer request came in, restart immediately.
    if _cur_token ()!=int (st .get ('token',0 )or 0 ):
        dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
        return 0.0 

    ctx =bpy .context 
    vl =getattr (ctx ,'view_layer',None )
    main_obj =bpy .data .objects .get (st .get ('main',''))
    if not main_obj or not ms_object_supports_modifier_stack (main_obj):
        dn .pop ('_MS_LEVEL_SWITCH_REQ_V1',None )
        dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
        dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
        dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
        return None 

    clicked =st .get ('clicked','BASE')or 'BASE'
    try:
        stack_obj =ms_get_modifier_stack_object (main_obj ,context =ctx ,create =bool (clicked !='BASE'))or main_obj
    except Exception:
        stack_obj =main_obj
    ui_row =int (st .get ('ui_row',-1 ))
    want_edit =bool (st .get ('want_edit',False ))
    phase =int (st .get ('phase',0 ))
    attempt =int (st .get ('attempt',0 ))

    def _last_apply_t (name :str )->float :
        try :
            mp =dn .get ('_MS_LAST_APPLY_T_V1')
            if isinstance (mp ,dict ):
                return float (mp .get (name ,0.0 )or 0.0 )
        except Exception :
            pass 
        return 0.0 

    def _write_state ():
    # Never overwrite newer clicks.
        if _cur_token ()!=int (st .get ('token',0 )or 0 ):
            return False 
        dn ['_MS_LEVEL_SWITCH_STATE_V1']=st 
        return True 

        # Safety: limit retries (analog / robust)
    if attempt >80 :
    # Give up safely but do not clobber newer requests.
        if _cur_token ()==int (st .get ('token',0 )or 0 ):
            dn .pop ('_MS_LEVEL_SWITCH_REQ_V1',None )
        dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
        dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
        dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
        dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
        return None 

        # Phase 0/1: ensure OBJECT mode is truly committed (hard barrier)
    if phase in (0 ,1 ):
        st ['phase']=1 
        st ['attempt']=attempt 
        if not _write_state ():
            return 0.0 

            # Analog safety: require OBJECT stability for 2 consecutive timer ticks.
        if 'stable_obj'not in st :
            st ['stable_obj']=0 

            # We must be in *pure* OBJECT before applying any switch (mode == OBJECT and edit_object == None).
        try :
            cur_mode =str (getattr (ctx ,'mode','OBJECT'))
            eo =getattr (ctx ,'edit_object',None )
            need_obj =(cur_mode .startswith ('EDIT')or eo is not None )
        except Exception :
            need_obj =True 

        if need_obj :
        # Capture selection before leaving edit, then force OBJECT via safe override.
            try :
                ms_capture_selection_to_cache (ctx )
            except Exception :
                pass 
            try :
                ao =None 
                try :
                    ao =getattr (vl .objects ,'active',None )if vl else None 
                except Exception :
                    ao =None 
                if ao is None or (vl and getattr (ao ,'name','')not in vl .objects ):
                    ao =main_obj 
                ms__safe_mode_set (ctx ,ao ,'OBJECT')
            except Exception :
                try :
                    if bpy .ops .object .mode_set .poll ():
                        bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
                except Exception :
                    pass 

                    # Ensure main is selectable/visible and active.
            try :
                _ms_set_obj_hidden (main_obj ,False ,False )
                if vl :
                    try :
                        main_obj .select_set (True )
                    except Exception :
                        pass 
                    vl .objects .active =main_obj 
                    try :
                        vl .update ()
                    except Exception :
                        pass 
            except Exception :
                pass 

                # Wait for Blender to commit the mode change (edit_object cleared).
            st ['stable_obj']=0 
            st ['attempt']=attempt +1 
            if not _write_state ():
                return 0.0 
            return 0.06 

            # Already in pure OBJECT (require 2 stable ticks before proceeding)
        try :
            st ['stable_obj']=int (st .get ('stable_obj',0 )or 0 )+1 
        except Exception :
            st ['stable_obj']=1 
        if st ['stable_obj']<2 :
            st ['attempt']=attempt +1 
            if not _write_state ():
                return 0.0 
            return 0.06 

        st ['phase']=2 
        if not _write_state ():
            return 0.0 
        return 0.0 

        # Phase 2: apply requested active item and stack state (force), then enter edit mode if needed
    if phase ==2 :
    # Abort if new click arrived
        if _cur_token ()!=int (st .get ('token',0 )or 0 ):
            dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
            return 0.0 

            # HARD BARRIER: do not proceed until Blender is in pure OBJECT (this matches the user's manual workaround).
        try :
            cur_mode =str (getattr (ctx ,'mode','OBJECT'))
            eo =getattr (ctx ,'edit_object',None )
            if cur_mode .startswith ('EDIT')or eo is not None :
                st ['attempt']=attempt +1 
                st ['phase']=1 
                if not _write_state ():
                    return 0.0 
                return 0.06 
        except Exception :
            pass 

        try :
        # Apply UI active
            main_obj ['ui_active_item']=clicked 
            main_obj ['ui_active_row']=ui_row 
            if clicked =='BASE':
                ms_set_ui_active_index (main_obj ,-1 )
            else :
                ms_set_ui_active_index (main_obj ,stack_obj .modifiers .find (clicked ))
                m =stack_obj .modifiers .get (clicked )
                if m :
                    stack_obj .modifiers .active =m 

                    # SmartLattice engaged flag
            is_clicked_sl =False 
            try :
                if clicked !='BASE':
                    _m =stack_obj .modifiers .get (clicked )
                    _p =ms_find_plugin_for_modifier (_m )if _m else None 
                    is_clicked_sl =bool (_p and _p .get ('id')=='smart_lattice')
            except Exception :
                is_clicked_sl =False 
            if is_clicked_sl and want_edit :
                main_obj ['ms_sl_engaged']=True 
                main_obj ['ms_sl_engaged_mod']=clicked 
            else :
                main_obj .pop ('ms_sl_engaged',None )
                main_obj .pop ('ms_sl_engaged_mod',None )

                # Force SL cache refresh on every switch
            try :
                bpy .app .driver_namespace ['_MS_FORCE_SL_SHARED_REFRESH_T']=time .time ()
            except Exception :
                pass 

                # Apply stack state now (interactive=True to capture/restore selection safely)
            try :
                apply_modifier_stack_state (main_obj ,ctx ,interactive =False )# NOTE: avoid auto-edit re-entry; timer handles mode explicitly
            except Exception :
                pass 

                # If apply was skipped due to sync lock, wait and retry.
            try :
                prev_t =float (st .get ('last_apply_t',0.0 )or 0.0 )
                cur_t =_last_apply_t (main_obj .name )
                if cur_t <=prev_t +1e-9 :
                    st ['attempt']=attempt +1 
                    st ['phase']=2 
                    if not _write_state ():
                        return 0.0 
                    return 0.02 
                st ['last_apply_t']=cur_t 
            except Exception :
                pass 

            try :
                if vl :
                    vl .update ()
            except Exception :
                pass 

                # Restore object selection (exclude lattice helpers), keep main active
            try :
                if vl :
                    sel =st .get ('sel',[])or []
                    if sel :
                        _ms_ensure_object_selection (vl ,sel )
                    try:
                        _shape_level_target =ms_shape_sync_visibility_for_active (main_obj ,context =ctx ,active_id =clicked )if ms_is_shape_source_object (main_obj )else None
                    except Exception:
                        _shape_level_target =None
                    if _shape_level_target is not None and clicked !='BASE':
                        try:main_obj .select_set (False )
                        except Exception:pass
                        try:_shape_level_target .select_set (True )
                        except Exception:pass
                        try:vl .objects .active =_shape_level_target
                        except Exception:pass
                    else:
                        _ms_set_obj_hidden (main_obj ,False ,False )
                        main_obj .select_set (True )
                        vl .objects .active =main_obj 
            except Exception :
                pass 

                # Enter desired edit mode deterministically
            if want_edit :
                target_obj =main_obj 
                hide_main =False 
                try :
                    if clicked !='BASE':
                        mod =stack_obj .modifiers .get (clicked )
                        p =ms_find_plugin_for_modifier (mod )if mod else None 
                        plugin_target =None
                        if p and callable (p .get ('sync_objects')):
                            carrier_key_eff =ms_get_carrier_key_for_effective (stack_obj if ms_is_shape_source_object (main_obj )else main_obj ,clicked )
                            res =p .get ('sync_objects')(stack_obj if ms_is_shape_source_object (main_obj )else main_obj ,ctx ,clicked ,carrier_key_eff ,bool (getattr (main_obj ,'ms_show_end_result',False )),False )
                            if isinstance (res ,dict ):
                                plugin_target =res .get ('target_obj')or None
                                if plugin_target:
                                    target_obj =plugin_target
                                    hide_main =bool (res .get ('hide_main',False ))
                        try:
                            _shape_target =ms_shape_sync_visibility_for_active (main_obj ,context =ctx ,active_id =clicked )
                        except Exception:
                            _shape_target =None
                        if _shape_target is not None and _shape_target !=main_obj:
                            if not plugin_target:
                                target_obj =_shape_target
                            hide_main =True
                    else:
                        try:
                            ms_shape_sync_visibility_for_active (main_obj ,context =ctx ,active_id ='BASE')
                        except Exception:
                            pass
                except Exception :
                    target_obj =main_obj 
                    hide_main =False 

                    # Temporarily select only the actual edit target to avoid accidental multi-object edit.
                try :
                    if vl :
                        for o in list (getattr (ctx ,'selected_objects',[])or []):
                            try :
                                if o !=target_obj :
                                    o .select_set (False )
                            except Exception :
                                pass 
                        try :
                            _ms_set_obj_hidden (target_obj ,False ,False )
                        except Exception :
                            pass 
                        try :
                            target_obj .select_set (True )
                        except Exception :
                            pass 
                        try :
                            vl .objects .active =target_obj 
                        except Exception :
                            pass 
                except Exception :
                    pass 

                try :
                    if target_obj :
                        _ms_set_obj_hidden (target_obj ,False ,False )
                        target_obj .select_set (True )
                        if vl :
                            vl .objects .active =target_obj 
                        ms__safe_mode_set (ctx ,target_obj ,'EDIT')
                        # When editing a helper, hide main if requested
                        if hide_main and target_obj !=main_obj :
                            try :
                                _ms_set_obj_hidden (main_obj ,True ,True )
                            except Exception :
                                pass 
                                # Apply stored selection for carrier if possible (mesh helpers)
                        try :
                            if getattr (target_obj ,'type','')=='MESH':
                                c_key =ms_get_carrier_key_for_effective (main_obj ,clicked )
                                ms_apply_selection_for_carrier (main_obj ,target_obj ,c_key )
                        except Exception :
                            pass 
                        try :
                            st ['target']=getattr (target_obj ,'name','')if target_obj else ''
                        except Exception :
                            pass 
                except Exception :
                    pass 

                    # Prepare post-edit stabilization (prevents partial transitions after entering EDIT).
            if want_edit :
                st ['stable_edit']=0 
                st ['post_edit_applied']=False 

            st ['phase']=3 
            st ['attempt']=attempt 
            if not _write_state ():
                return 0.0 
            return 0.0 
        except Exception :
            st ['attempt']=attempt +1 
            st ['phase']=1 
            if not _write_state ():
                return 0.0 
            return 0.02 

            # Phase 3: verify and finish (or retry)
    if phase ==3 :
    # Abort if new click arrived
        if _cur_token ()!=int (st .get ('token',0 )or 0 ):
            dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
            return 0.0 

        ok =True 
        try :
        # UI active matches
            if ms_get_ui_active_id (main_obj )!=clicked :
                ok =False 

                # Active modifier pointer matches when applicable
            if clicked !='BASE':
                try :
                    m =stack_obj .modifiers .get (clicked )
                    if m and getattr (stack_obj .modifiers ,'active',None )!=m :
                        ok =False 
                except Exception :
                    pass 
                    # Mode + edit target verification (stable, analog)
            if want_edit :
                mode_ok =False 
                try :
                    mode_ok =bool (str (getattr (ctx ,'mode','OBJECT')).startswith ('EDIT'))
                except Exception :
                    mode_ok =False 
                if mode_ok :
                    try :
                        tgt =st .get ('target','')or ''
                        if tgt :
                            eo =getattr (ctx ,'edit_object',None )
                            if (eo is None )or (eo .name !=tgt ):
                                mode_ok =False 
                    except Exception :
                        mode_ok =False 
                        # Accumulate stability across ticks; require 2 consecutive stable ticks.
                try :
                    if mode_ok :
                        st ['stable_edit']=int (st .get ('stable_edit',0 )or 0 )+1 
                    else :
                        st ['stable_edit']=0 
                except Exception :
                    st ['stable_edit']=0 
                    # After first stable tick in EDIT, apply stack state once so edit-level view is correct.
                try :
                    if mode_ok and (not bool (st .get ('post_edit_applied',False ))):
                        apply_modifier_stack_state (main_obj ,ctx ,interactive =False )
                        st ['post_edit_applied']=True 
                except Exception :
                    pass 
                    # New Smart Lattice layers enter Edit Mode with all points selected by default.
                    # Clear that one-shot selection so transforming a control point does not translate the whole cage.
                try :
                    if mode_ok :
                        tgt_name =st .get ('target','')or ''
                        if tgt_name :
                            _ms_try_clear_lattice_point_selection_once (bpy .data .objects .get (tgt_name ))
                except Exception :
                    pass 
                if int (st .get ('stable_edit',0 )or 0 )<2 :
                    ok =False 
                try :
                    _write_state ()
                except Exception :
                    pass 
            else :
                if str (getattr (ctx ,'mode','OBJECT'))!='OBJECT':
                    ok =False 

                    # If not engaged in SmartLattice, hide lattice helpers for this main (do not block completion).
            if not bool (main_obj .get ('ms_sl_engaged',False )):
                try :
                    for ob in bpy .data .objects :
                        if getattr (ob ,'type','')=='LATTICE'and ob .get ('sl_main_target')==main_obj .name :
                            try :
                                if hasattr (ob ,'hide_viewport') and bool (ob .hide_viewport):
                                    ob .hide_viewport =False
                            except Exception :
                                pass 
                            try :
                                if hasattr (ob ,'hide_set'):
                                    ob .hide_set (True )
                            except Exception :
                                pass 
                            try :
                                ob .hide_select =True 
                            except Exception :
                                pass 
                except Exception :
                    pass 
        except Exception :
            ok =False 

        if ok :
        # Finish only if no newer request exists.
            if _cur_token ()==int (st .get ('token',0 )or 0 ):
                dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
                dn .pop ('_MS_LEVEL_SWITCH_REQ_V1',None )
                dn .pop ('_MS_LEVEL_SWITCH_ARMED_V1',None )
                dn .pop ('_MS_TRANSITION_ACTIVE_V1',None )
                dn .pop ('_MS_ALLOW_MODESET_V1',None )
                dn .pop ('_MS_ALLOW_MODESET_TOKEN_V1',None )
                dn .pop ('_MS_ALLOW_MODESET_T_V1',None )
                return None 
                # New request arrived; restart.
            dn .pop ('_MS_LEVEL_SWITCH_STATE_V1',None )
            return 0.0 

        st ['attempt']=attempt +1 
        if want_edit :
        # Stay in phase 3 while Blender settles into the requested edit target.
        # Going back to phase 1 re-enters OBJECT and causes visible OBJECT/EDIT flicker.
            try :
                tgt =st .get ('target','')or ''
                eo =getattr (ctx ,'edit_object',None )
                in_edit =bool (str (getattr (ctx ,'mode','OBJECT')).startswith ('EDIT'))
                if (not in_edit )or (tgt and ((eo is None )or (getattr (eo ,'name','')!=tgt ))):
                    target_obj =bpy .data .objects .get (tgt )if tgt else main_obj 
                    if target_obj :
                        try :
                            _ms_set_obj_hidden (target_obj ,False ,False )
                        except Exception :
                            pass 
                        try :
                            if vl :
                                for o in list (getattr (ctx ,'selected_objects',[])or []):
                                    try :
                                        if o !=target_obj :
                                            o .select_set (False )
                                    except Exception :
                                        pass 
                                target_obj .select_set (True )
                                vl .objects .active =target_obj 
                        except Exception :
                            pass 
                        try :
                            ms__safe_mode_set (ctx ,target_obj ,'EDIT')
                        except Exception :
                            pass 
            except Exception :
                pass 
            st ['phase']=3 
            if not _write_state ():
                return 0.0 
            return 0.03 
        st ['phase']=1 
        if not _write_state ():
            return 0.0 
        return 0.02 

        # Unknown phase
    st ['attempt']=attempt +1 
    st ['phase']=1 
    if not _write_state ():
        return 0.0 
    return 0.02 



class SMS_OT_show_help (bpy .types .Operator ):
    _POPUP_WIDTH =860

    bl_idname ="smart_modifier_suite.show_help"
    bl_label ="Help"
    bl_description ="Open the detailed help popup for this Smart Modifier tool group. The long help content is loaded only when this button is clicked."
    bl_options ={'INTERNAL'}

    help_id :StringProperty (
    name ="Help Topic",
    description ="Internal identifier for the Smart Modifier help topic to open.",
    default ="",
    options ={'SKIP_SAVE'},
    )

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Open detailed help for this Smart Modifier tool group. The help catalog is loaded only after this button is clicked.',
        'このSmart Modifierツールグループの詳細ヘルプを開きます。ヘルプカタログはこのボタンを押した後だけ読み込まれます。',
        context =context
        )

    def invoke (self ,context ,event ):
        del event
        try :
            from . import help  # Lazy: import detailed help only after a Help click.
            del help
        except Exception as exc :
            try :
                self .report ({'ERROR'},pgettext ('Help content could not be loaded.'))
            except Exception :
                pass
            return {'CANCELLED'}
        try :
            return context .window_manager .invoke_popup (self ,width =int (self ._POPUP_WIDTH ))
        except Exception :
            return self .execute (context )

    def draw (self ,context ):
        layout =self .layout
        try :
            from . import help  # Lazy popup content module.
            help .draw_help (layout ,context ,self .help_id ,popup_width_px =int (self ._POPUP_WIDTH ))
        except Exception :
            try :
                layout .label (text =pgettext ('Help content could not be loaded.'),icon ='ERROR')
            except Exception :
                pass

    def execute (self ,context ):
        # The popup lifecycle is owned by invoke().  execute() is called only
        # when Blender confirms/finishes the popup or when the operator is
        # invoked explicitly with EXEC_DEFAULT.  Re-opening the popup here
        # creates recursive popup ownership and empty Undo steps.
        try :
            from . import help  # Validate lazy help availability without opening UI.
            del help
        except Exception :
            try :
                self .report ({'ERROR'},pgettext ('Help content could not be loaded.'))
            except Exception :
                pass
            return {'CANCELLED'}
        return {'FINISHED'}




class OBJECT_OT_ms_copy_keymap_id (bpy .types .Operator ):
    bl_idname ="object.ms_copy_keymap_id"
    bl_label ="Copy Keymap ID"
    bl_description =choose_text (
    "Copy the ID used to register this command in Preferences > Keymap.",
    "プリファレンスのキーマップへ登録する時に使う ID をコピーします。",
    )
    bl_options ={'INTERNAL'}

    text :StringProperty (options ={'SKIP_SAVE','HIDDEN'})

    def execute (self ,context ):
        context .window_manager .clipboard =str (self .text or '')
        self .report ({'INFO'},choose_text ('Copied.','コピーしました。',context =context ))
        return {'FINISHED'}


class OBJECT_OT_ms_toggle_show_end_result (bpy .types .Operator ):
    bl_idname ="object.ms_toggle_show_end_result"
    bl_label ="Toggle Show End Result"
    bl_description =choose_text (
    "Toggle Smart Modifier Stack's Show End Result setting for the active base mesh. Register this operator in Blender Preferences > Keymap > 3D View to switch the EndPreview final-result display from a shortcut.",
    "アクティブなベースメッシュの Smart Modifier Stack「最終結果を表示」を切り替えます。Blender プリファレンス > キーマップ > 3Dビュー にこのオペレーターを登録すると、ショートカットから EndPreview の最終結果表示を切り替えられます。",
    )
    bl_options = {'UNDO'}

    target_obj :StringProperty (
    name ="Target Object",
    description ="Optional object name. When empty, the active object and its Smart Modifier base object are used.",
    default ="",
    )

    @classmethod
    def poll (cls ,context ):
        try :
            obj =getattr (context ,"active_object",None )
            if obj is None :
                return False
            main =get_main_object (obj )
            if main is None :
                main =obj
            return getattr (main ,"type","")== 'MESH'
        except Exception :
            return False

    def execute (self ,context ):
        main_obj =None
        try :
            name =str (getattr (self ,"target_obj","")or "")
            if name :
                main_obj =bpy .data .objects .get (name )
        except Exception :
            main_obj =None
        if main_obj is None :
            try :
                obj =getattr (context ,"active_object",None )
                main_obj =get_main_object (obj )if obj is not None else None
                if main_obj is None :
                    main_obj =obj
            except Exception :
                main_obj =None
        if main_obj is None or getattr (main_obj ,"type","")!='MESH':
            self .report ({'WARNING'},choose_text ("No active mesh object for Smart Modifier Show End Result.","Smart Modifier の「最終結果を表示」を切り替える有効なメッシュがありません。",context))
            return {'CANCELLED'}
        try :
            current =bool (getattr (main_obj ,"ms_show_end_result",False ))
            setattr (main_obj ,"ms_show_end_result",not current )
        except Exception :
            return {'CANCELLED'}
        try :
            if bool (getattr (main_obj ,"ms_show_end_result",False )):
                if ms_preview_context_allows_collections (main_obj ,context):
                    ms_endpreview_set_allowed (main_obj ,True )
                    ms_request_endpreview_live_sync ()
            else:
                ms_endpreview_set_allowed (main_obj ,False )
                ms_request_endpreview_cleanup (main_obj )
                ms_request_endpreview_global_purge ("shortcut_toggle_off")
        except Exception :
            pass
        try :
            apply_modifier_stack_state (main_obj ,context ,interactive =False )
        except Exception :
            pass
        try :
            wm =getattr (context ,"window_manager",None )
            for window in getattr (wm ,"windows",[])or []:
                screen =getattr (window ,"screen",None )
                for area in getattr (screen ,"areas",[])or []:
                    if getattr (area ,"type","")=='VIEW_3D':
                        area .tag_redraw ()
        except Exception :
            pass
        return {'FINISHED'}


class OBJECT_OT_ms_open_add_modifier_popup (bpy .types .Operator ):
    bl_idname ="object.ms_open_add_modifier_popup"
    bl_label ='Add Modifier'
    bl_description ='Open the Add Modifier popup (see tooltip for beginner-friendly details)'
    # Opening this transient menu must not create an undo step or snapshot scene state.
    # The actual modifier/user-tool execution operators keep their own UNDO flags.
    bl_options ={'INTERNAL'}
    _POPUP_WIDTH =440
    _POPUP_ROWS =18
    _MENU_IDNAME ="VIEW3D_MT_ms_master_add_menu"

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        """Open the Add Modifier popup at the button position as a front popup.
- Opens Blender's transient Add Modifier menu from the clicked button.
- After you choose one modifier or user tool, the menu closes automatically.
- Category submenus still expand normally for readability.""",
        """［モディファイアを追加］ボタン位置から、前面ポップアップとして一覧を開きます。
・クリックした［モディファイアを追加］ボタンから、Blender標準の一時メニューとして開きます。
・モディファイアまたはユーザーツールを1つ選ぶと、メニュー全体が自動で閉じます。
・カテゴリのサブメニューは、見やすいよう通常どおり展開されます。""",
        context =context ,
        )

    def _prepare_popup_host (self ,context ):
        try :
            from .import pseudo_properties
        except Exception :
            pseudo_properties =None
        if pseudo_properties is None :
            return
        try :
            ensure_fn =getattr (pseudo_properties ,'_ensure_host_window_popup_capacity',None )
            if callable (ensure_fn ):
                ensure_fn (
                window =getattr (context ,'window',None ),
                context =context ,
                entry_count =int (self ._POPUP_ROWS ),
                )
        except Exception :
            pass

    def _draw_add_menu_contents (self ,layout ,context ):
        menu_contents =getattr (layout ,'menu_contents',None )
        if callable (menu_contents ):
            try :
                menu_contents (self ._MENU_IDNAME )
                return True
            except Exception :
                pass
        menu_cls =getattr (bpy .types ,self ._MENU_IDNAME ,None )
        draw_fn =getattr (menu_cls ,'draw',None )if isinstance (menu_cls ,type )else None
        if callable (draw_fn ):
            try :
                shim =type ('_MS_ADD_MENU_DRAW_SHIM',(),{})()
                shim .layout =layout
                draw_fn (shim ,context )
                return True
            except Exception :
                pass
        return False

    def _invoke_popup (self ,context ):
        """Open the Add Modifier selector as Blender's normal transient menu.

        The previous implementation embedded the master menu inside this
        operator's invoke_popup().  Blender keeps an operator-owned popup alive
        after child operators finish, so choosing a modifier from the popup left
        the Add Modifier popup visible.  Using wm.call_menu() lets Blender own
        the menu stack; after one modifier/user-tool operator is executed, the
        whole menu stack closes automatically like the standard Add Modifier
        menu.
        """
        try :
            return bpy .ops .wm .call_menu ('INVOKE_DEFAULT',name =self ._MENU_IDNAME )
        except Exception :
            pass
        wm =getattr (context ,'window_manager',None )or getattr (bpy .context ,'window_manager',None )
        if wm is None :
            return {'CANCELLED'}
        self ._prepare_popup_host (context )
        try :
            return wm .invoke_popup (self ,width =max (220 ,int (self ._POPUP_WIDTH )or 220 ))
        except Exception :
            return {'CANCELLED'}

    def draw (self ,context ):
        layout =self .layout
        try :
            layout .use_property_split =False
            layout .use_property_decorate =False
            layout .operator_context ='INVOKE_DEFAULT'
        except Exception :
            pass
        if self ._draw_add_menu_contents (layout ,context ):
            return
        try :
            op =_sms_icon_operator (layout ,'wm.call_menu',text =choose_text ('Add Modifier','モディファイアを追加',context =context ),icon_name ='add',fallback_icon ='DOWNARROW_HLT')
            op .name =self ._MENU_IDNAME
        except Exception :
            layout .label (text =choose_text ('Add Modifier menu is unavailable.','モディファイア追加メニューを開けません。',context =context ),icon='NONE')

    def execute (self ,context ):
        return self ._invoke_popup (context )

    def invoke (self ,context ,event ):
        return self ._invoke_popup (context )

class OBJECT_OT_sms_instance_copy (bpy .types .Operator ):
    bl_idname ="object.sms_instance_copy"
    bl_label ="Instance Copy"
    bl_description ="Create copy/instance objects and link Smart Modifier stacks across object instances"
    bl_options ={'UNDO'}

    clone_type :bpy .props .EnumProperty (
        name ="Object",
        description ="Choose whether to create independent copies or linked object instances.",
        items =[
            ('COPY',"Copy","Create independent object and object-data copies."),
            ('INSTANCE',"Instance","Create linked object instances that share object data and Smart Modifier instance stacks."),
        ],
        default ='INSTANCE',
    )
    number_of_copies :bpy .props .IntProperty (
        name ="Number of Copies",
        description ="Set how many copies or instances are created from each selected object.",
        min =1,
        max =1000,
        default =1,
    )
    offset :bpy .props .FloatVectorProperty (
        name ="Offset",
        description ="Set the XYZ movement added to each successive copy or instance.",
        default =(0.0,0.0,0.0),
        subtype ='TRANSLATION',
    )

    @classmethod
    def description (cls ,context ,properties ):
        return pgettext (
            'Create copy or instance objects. Instance mode shares object data and links Smart Modifier stacks so adding a modifier to one instance adds the same instanced modifier to every object in the instance group.'
        )

    def invoke (self ,context ,event ):
        try :
            return context .window_manager .invoke_props_dialog (self )
        except Exception :
            return self .execute (context )

    def draw (self ,context ):
        layout =self .layout
        layout .use_property_split =False
        layout .use_property_decorate =False
        box =layout .box ()
        box .label (text =choose_text ('Clone Type','複製タイプ',context =context),icon ='LINKED')
        try :
            box .use_property_split =False
            box .use_property_decorate =False
        except Exception :
            pass
        row =box .row (align =True)
        try :
            row .use_property_split =False
            row .use_property_decorate =False
        except Exception :
            pass
        regular_label =choose_text ('Normal','通常',context =context)
        instance_label =choose_text ('Instance','インスタンス',context =context)
        try :
            row .prop_enum (self ,'clone_type','COPY',text =regular_label,translate =False)
            row .prop_enum (self ,'clone_type','INSTANCE',text =instance_label,translate =False)
        except TypeError :
            row .prop_enum (self ,'clone_type','COPY',text =regular_label)
            row .prop_enum (self ,'clone_type','INSTANCE',text =instance_label)
        except Exception :
            box .prop (self ,'clone_type',text ='',expand =True)
        col =layout .column (align =True)
        col .use_property_split =True
        col .use_property_decorate =False
        col .prop (self ,'number_of_copies',text =choose_text ('Number of Copies','コピー数',context =context))
        col .prop (self ,'offset',text =choose_text ('Offset','オフセット',context =context))

    def _link_to_source_collections (self ,src ,new_obj ,context ):
        linked =False
        try :
            collections =list (getattr (src ,'users_collection',())or [])
        except Exception :
            collections =[]
        for coll in collections :
            try :
                coll .objects .link (new_obj)
                linked =True
            except Exception :
                pass
        if not linked :
            try :
                context .collection .objects .link (new_obj)
                linked =True
            except Exception :
                pass
        return linked

    def execute (self ,context ):
        try :
            originals =list (getattr (context ,'selected_objects',[])or [])
        except Exception :
            originals =[]
        originals =[o for o in originals if o and ms_object_supports_modifier_stack (o)]
        if not originals :
            self .report ({'WARNING'},choose_text ('No object is selected.','オブジェクトが選択されていません。',context =context))
            return {'CANCELLED'}

        is_instance =(self .clone_type =='INSTANCE')
        created =[]
        affected_groups =set ()
        prefer_by_group ={}
        offset_vec =Vector (self .offset)

        for i in range (int (self .number_of_copies ) ):
            factor =i +1
            for src in originals :
                try :
                    new_obj =src .copy ()
                except Exception :
                    continue
                try :
                    if is_instance :
                        new_obj .data =src .data
                    elif getattr (src ,'data',None )is not None :
                        new_obj .data =src .data .copy ()
                except Exception :
                    pass
                try :
                    suffix ="Instance" if is_instance else "Copy"
                    new_obj .name =f"{src.name}_{suffix}"
                except Exception :
                    pass
                if not self ._link_to_source_collections (src ,new_obj ,context ):
                    continue
                try :
                    new_obj .location =src .location +offset_vec *factor
                except Exception :
                    try :
                        new_obj .location +=offset_vec *factor
                    except Exception :
                        pass

                if is_instance :
                    try :
                        existing_gid =ms_get_object_instance_id (src )
                        gid =existing_gid or uuid .uuid4 ().hex
                        if not existing_gid :
                            try :
                                for _mod in list (getattr (src ,'modifiers',())or []):
                                    _ms_modifier_set_object_instance_unique (_mod ,False )
                            except Exception :
                                pass
                            try :
                                for _mod in list (getattr (new_obj ,'modifiers',())or []):
                                    _ms_modifier_set_object_instance_unique (_mod ,False )
                            except Exception :
                                pass
                        ms_set_object_instance_id (src ,gid )
                        ms_set_object_instance_id (new_obj ,gid )
                        # The source may be newer than the last membership snapshot too.
                        ms_allow_new_object_instance_member (src ,gid )
                        ms_allow_new_object_instance_member (new_obj ,gid )
                        affected_groups .add (gid )
                        prefer_by_group [gid ]=src
                    except Exception :
                        pass
                else :
                    try :
                        ms_clear_object_instance_id (new_obj )
                    except Exception :
                        pass
                    try :
                        for mod in list (getattr (new_obj ,'modifiers',())or []):
                            try :
                                ms_obj_clear_instance_id (new_obj ,mod .name )
                                _ms_modifier_set_object_instance_unique (mod ,False )
                            except Exception :
                                pass
                    except Exception :
                        pass
                created .append (new_obj )

        if is_instance and affected_groups :
            for gid in tuple (affected_groups ):
                try :
                    ms_group_object_instance_modifier_stacks (gid ,context =context ,prefer_obj =prefer_by_group .get (gid ),force =True )
                except Exception :
                    pass
            try :
                ms_sync_object_instance_modifier_additions (context ,force =True )
                ms_sync_all_instance_groups (context ,prefer_active =True ,force =True )
            except Exception :
                pass

        try :
            bpy .ops .object .select_all ('EXEC_DEFAULT', False, action ='DESELECT')
        except Exception :
            pass
        for obj in created :
            try :
                obj .select_set (True )
            except Exception :
                pass
        if created :
            try :
                context .view_layer .objects .active =created [-1]
            except Exception :
                pass
        self .report ({'INFO'},choose_text ('Created instance/copy object(s).','インスタンス/コピーオブジェクトを作成しました。',context =context))
        return {'FINISHED'} if created else {'CANCELLED'}


class OBJECT_OT_sms_instance_make_unique (bpy .types .Operator ):
    bl_idname ="object.sms_instance_make_unique"
    bl_label ="Release Instance"
    bl_description ="Release selected object instances and convert them to independent objects"
    bl_options ={'UNDO'}
    target_obj_name :StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
            'Release the selected object instance(s).\nUse this when linked/instanced objects should become independent while keeping the current modifier stack.\nThe selected object data is copied, Smart Modifier object-instance IDs are cleared, and only the selected object(s) are detached.',
            '選択中のオブジェクトのインスタンスを解除します。\nリンク / インスタンス化されたオブジェクトを、現在のモディファイアスタックを保ったまま独立させたい場合に使います。\n選択中オブジェクトのデータをコピーし、Smart Modifier のオブジェクトインスタンスIDを解除して、選択中オブジェクトだけを切り離します。',
            context =context
        )

    def execute (self ,context ):
        bridge_state = ms_stack_popup_prepare_object_mode(context)
        try:
            return self._execute_core(context)
        finally:
            ms_stack_popup_restore_mode(context, bridge_state)

    def _execute_core (self ,context ):
        target_name =str (getattr (self ,'target_obj_name',"")or "")
        try :
            targets =list (getattr (context ,'selected_objects',[])or [])
        except Exception :
            targets =[]
        if not targets and target_name :
            try :
                obj =bpy .data .objects .get (target_name )
            except Exception :
                obj =None
            targets =[obj ]if obj else []
        targets =[o for o in targets if o and ms_object_supports_modifier_stack (o)]
        if not targets :
            self .report ({'WARNING'},choose_text ('No object is selected.','オブジェクトが選択されていません。',context =context))
            return {'CANCELLED'}
        changed =0
        affected_groups =set ()
        for obj in targets :
            gid =ms_get_object_instance_id (obj )
            if gid :
                affected_groups .add (gid )
            obj_changed =False
            try :
                has_object_instance =bool (gid )or bool (ms_object_has_linked_base_instance (obj ,context ))
            except Exception :
                has_object_instance =bool (gid )
            if not has_object_instance :
                continue
            try :
                data =getattr (obj ,'data',None )
                data_is_shared =False
                if data is not None:
                    try :
                        objects =list ((context .scene .objects if context and hasattr (context ,'scene')else bpy .data .objects )or [])
                    except Exception :
                        objects =list (getattr (bpy .data ,'objects',[])or [])
                    count =0
                    for other in objects :
                        try :
                            if other is not None and getattr (other ,'data',None )is data:
                                count +=1
                                if count >1:
                                    data_is_shared =True
                                    break
                        except Exception :
                            continue
                if data is not None and data_is_shared:
                    try :
                        obj .data =data .copy ()
                        obj_changed =True
                    except Exception :
                        pass
            except Exception :
                pass
            try :
                if gid :
                    ms_clear_object_instance_id (obj )
                    obj_changed =True
            except Exception :
                pass
            try :
                for mod in list (getattr (obj ,'modifiers',())or []):
                    try :
                        if ms_get_instance_id (mod ,obj ):
                            try :
                                if ms_make_modifier_unique (obj ,mod ,context =context ):
                                    obj_changed =True
                            except Exception :
                                pass
                        if gid :
                            ms_obj_clear_instance_id (obj ,mod .name )
                            _ms_modifier_set_object_instance_unique (mod ,False )
                            obj_changed =True
                    except Exception :
                        pass
            except Exception :
                pass
            try :
                obj .update_tag ()
            except Exception :
                pass
            if obj_changed :
                changed +=1
        for gid in tuple (affected_groups ):
            try :
                ms_cleanup_object_instance_group_after_release (gid ,context =context )
            except Exception :
                pass
        if changed :
            self .report ({'INFO'},choose_text ('Released selected object instance(s).','選択オブジェクトのインスタンスを解除しました。',context =context))
            return {'FINISHED'}
        self .report ({'WARNING'},choose_text ('No releasable instance object was found.','解除できるインスタンスオブジェクトが見つかりません。',context =context))
        return {'CANCELLED'}



class OBJECT_OT_ms_add_modifier (bpy .types .Operator ):

    bl_idname ="object.ms_add_modifier"
    bl_label ='Add Modifier'
    bl_description ='Add a modifier (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}
    mod_type :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        'Add a modifier.\n- Insert position: it is added directly below the currently active item in the stack.\n  (Base Object active: directly under Base Object / before the first modifier. Modifier active: directly under that modifier.)\n- After adding, use the buttons to the right of the modifier name to toggle visibility states and edit settings.'





        )

    def execute (self ,context ):
        main_obj =get_main_object (context .active_object )or context .active_object
        if not main_obj or not ms_object_supports_modifier_stack (main_obj ):
            return {'CANCELLED'}

            # Preserve user's object selection across add (do not deselect on mode switches / helper hides).
        vl =getattr (context ,"view_layer",None )
        _orig_sel_names ,_orig_active_name =_ms_snapshot_object_selection (vl )if vl else ([],"")

        raw_targets =ms_get_selected_main_meshes (context )or [main_obj ]
        try:
            _raw_unique =[]
            _raw_seen =set ()
            for _t in (raw_targets or []):
                try:
                    _name =str (getattr (_t ,'name','')or '')
                except Exception:
                    _name =''
                if _t is not None and _name and _name not in _raw_seen:
                    _raw_seen .add (_name )
                    _raw_unique .append (_t )
            raw_targets =_raw_unique or raw_targets
        except Exception:
            pass
        _raw_multi_selected =len (raw_targets )>1
        if _raw_multi_selected:
            # Multi-object Add Modifier affects only the explicitly selected stack owners.
            # Do not implicitly expand object-instance groups here; otherwise selected
            # instances can receive duplicate rows through both explicit add and sync paths.
            targets =list (raw_targets or [])
        else:
            targets =ms_expand_targets_for_object_instance_groups (raw_targets ,context )or raw_targets
        try:
            _shape_stack_targets =[]
            _shape_stack_seen =set ()
            for _t in targets:
                if ms_is_shape_source_object (_t):
                    _proxy =ms_shape_get_mesh_proxy (_t ,context =context ,create =True ,migrate =True )
                    _target =_proxy or _t
                else:
                    _target =_t
                try:
                    _key =str (getattr (_target ,'name','')or '')
                except Exception:
                    _key =''
                if _target is not None and _key and _key not in _shape_stack_seen:
                    _shape_stack_seen .add (_key )
                    _shape_stack_targets .append (_target )
            targets =_shape_stack_targets or targets
        except Exception:
            pass
        _ms_object_instance_implicit_expand =(not _raw_multi_selected )and len (targets )>len (raw_targets )
        is_multi =len (targets )>1 

        # 追加前のUIアクティブ階層を保持（部分選択→頂点グループ用）
        pre_effective_id_by_obj ={}
        try :
            for _o in targets :
                if _o and getattr (_o ,"type","")=='MESH':
                    pre_effective_id_by_obj [_o .name ]=ms_get_ui_active_id (_o )
        except Exception :
            pre_effective_id_by_obj ={}
        new_mods_by_objname ={}

        # 追加は安全のため Object モードで実行（v1.64 の方針維持）
        if context .mode !='OBJECT':
        # 編集モード中の部分選択を保持（Base / Edit Poly 用）
            try :
                ms_capture_selection_to_cache_all (context )
            except Exception :
                try :ms_capture_selection_to_cache (context )
                except Exception :pass 
            try :
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :
                pass 

        if not is_multi :
        # 単体追加は非表示/選択不可状態を解除（v1.64 MASTERFIXの挙動維持）
            try :
                _ms_set_obj_hidden (main_obj ,False ,False )
            except Exception :
                pass 

        try:
            _main_stack_obj =ms_get_modifier_stack_object (main_obj ,context =context ,create =ms_is_shape_source_object (main_obj ))or main_obj
        except Exception:
            _main_stack_obj =main_obj
        master_obj =_main_stack_obj if _main_stack_obj in targets else (main_obj if main_obj in targets else targets [0 ])

        # --- 【最重要】ループ前にすべての追加位置を事前計算（Modifier_Stack.py から移植） ---
        insert_indices ={}
        for obj in targets :
            if ms_object_has_modifier_collection (obj ):
                insert_indices [obj .name ]=ms_calc_target_insert_index (master_obj ,obj ,context )

        iid =ms_instance_paste_id ()if is_multi else ""
        master_new_mod =None 

        base_c =ms_modifier_type_display_name (self .mod_type )or "Modifier"
        shared_disp_name =(
        ms_next_logical_default_name_across_objects (targets ,base_c )
        if is_multi else 
        ms_next_logical_default_name (master_obj ,self .mod_type )
        )

        order =ms_get_stack_order ()

        for obj in targets :
            if not obj or not ms_object_has_modifier_collection (obj ):
                continue 

            insert_idx =insert_indices .get (obj .name ,len (obj .modifiers ))
            ui_pos =(len (obj .modifiers )-insert_idx )if order =='BOTTOM_UP'else insert_idx 

            try :
                new_mod =obj .modifiers .new (name =shared_disp_name ,type =self .mod_type )
            except Exception :
                continue 
            if new_mod is None :
                continue 

            try :
                if hasattr (new_mod ,'show_in_editmode'):
                    new_mod .show_in_editmode =True 
            except Exception :
                pass 

            safe_move_modifier (obj ,new_mod .name ,insert_idx )
            ms_obj_set_disp_name (obj ,new_mod .name ,shared_disp_name )
            # New add must always start enabled regardless of stale cached states.
            set_mod_enabled_state (obj ,new_mod .name ,True )
            set_mod_viewport_state (obj ,new_mod .name ,True )
            if iid :
                ms_obj_set_instance_id (obj ,new_mod .name ,iid ,disp_name =shared_disp_name )
                try:
                    if bool (_raw_multi_selected ):
                        _ms_modifier_set_object_instance_unique (new_mod ,True )
                except Exception:
                    pass

            _ui_owner =get_main_object (obj )or obj
            _ui_owner ["ui_active_item"]=new_mod .name 
            _ui_owner ["ui_active_row"]=ui_pos 
            ms_set_ui_active_index (_ui_owner ,obj .modifiers .find (new_mod .name ))
            obj .modifiers .active =new_mod 


            # For auto-selection vertex-group feature
            try :new_mods_by_objname [obj .name ]=new_mod .name 
            except Exception :pass 

            if obj ==master_obj :
                master_new_mod =new_mod 

            obj .update_tag ()

        if iid and master_obj and master_new_mod :
            try:
                _src_vp ,_src_rd ,_src_edit ,_src_cage =_ms_get_modifier_manual_display_for_sync (master_obj ,master_new_mod ,context =context )
            except Exception:
                _src_vp ,_src_rd ,_src_edit ,_src_cage =True ,True ,False ,False
            for o ,m in ms_iter_instance_members (iid ):
                if o ==master_obj and m ==master_new_mod :
                    continue 
                ms_copy_modifier_settings (master_new_mod ,m ,include_name =False ,skip_display_flags =True )
                _ms_set_modifier_display_state_for_instance_sync (o ,m ,viewport =_src_vp ,render =_src_rd ,editmode =_src_edit ,cage =_src_cage ,context =context )
                ms_obj_set_instance_id (o ,m .name ,iid )
                o .update_tag ()


                # --- Auto Vertex Group (partial apply) for Base / Edit Poly selection ---
        try :
            if (not is_multi )and master_obj and master_new_mod :
                _eff =pre_effective_id_by_obj .get (master_obj .name ,"BASE")
                _ms_auto_sel_try_apply_single (master_obj ,master_obj ,master_new_mod ,_eff )
            elif is_multi and iid :
                _ms_auto_sel_apply_instance_for_new_mods (iid ,new_mods_by_objname ,pre_effective_id_by_obj )
        except Exception :
            pass 

        if is_multi :
            ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
        else :
            ms_apply_state_post_action (context ,main_obj ,interactive_default =False )

        try :
            ms_mark_object_instance_targets_synced (targets ,context =context )
            if bool (_raw_multi_selected ):
                # The newly added modifier group is already explicitly assigned to
                # the selected targets: one linked modifier per selected stack owner.
                # Do not run base-object instance expansion here; it can duplicate
                # rows on selected objects or add rows to unselected instances.
                try:
                    _ms_modifier_instance_cache_mark_dirty ()
                except Exception:
                    pass
            else:
                ms_sync_object_instance_modifier_additions (context ,force =True )
                ms_sync_all_instance_groups (context ,prefer_active =True ,force =True )
        except Exception :
            pass

            # Restore selection (never deselect). Ensure main object stays selected/active.
        try :
            if vl and _orig_sel_names :
                safe_names =[]
                for n in (_orig_sel_names or []):
                    try :
                        o =bpy .data .objects .get (n )
                        if o and o .type !='LATTICE':
                            safe_names .append (n )
                    except Exception :
                        pass 
                if safe_names :
                    _ms_ensure_object_selection (vl ,safe_names )
            if vl :
                if not _ms_object_instance_implicit_expand :
                    for o in targets :
                        try :
                            if not ms_is_shape_mesh_proxy (o ):
                                o .select_set (True )
                        except Exception :pass 
                try :
                    vl .objects .active =main_obj 
                except Exception :
                    pass 
        except Exception :
            pass 

        try :
            ms_normalize_shape_proxy_visibility_selection (context ,[main_obj ])
        except Exception :
            pass

        return {'FINISHED'}



class OBJECT_OT_ms_toggle_vis (bpy .types .Operator ):
    bl_idname ="object.ms_toggle_vis"
    bl_label ='Toggle Visibility'
    bl_description ='Toggle modifier enabled/disabled (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        'Enable/disable this modifier in the stack.\n- OFF: Stop computing this modifier; it will not affect the result.\n- ON: Compute normally.\nTip: Useful for temporarily disabling heavy modifiers while working.'




        )

    def execute (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )
        if not obj :return {'FINISHED'}
        cur =get_mod_enabled_state (obj ,self .modifier_name )
        new_st =not cur 
        set_mod_enabled_state (obj ,self .modifier_name ,new_st )
        mod =obj .modifiers .get (self .modifier_name )
        def _ms_call_enabled_hook (_obj ,_mod ,_state ):
            if not _obj or not _mod :return
            try :
                _p =ms_find_plugin_for_modifier (_mod )
                _fn =_p .get ("enabled_state_changed")if _p else None
                if callable (_fn ):_fn (get_main_object (_obj ),context ,_obj ,_mod ,bool (_state ))
            except Exception :
                pass
        if mod and ms_is_instance_modifier (mod ,obj ):
            iid =ms_get_instance_id (mod ,obj )
            for o ,m in ms_iter_instance_members (iid ):
                set_mod_enabled_state (o ,m .name ,new_st )
                _ms_call_enabled_hook (o ,m ,new_st )
                o .update_tag ()
            main_obj =get_main_object (obj )
            if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
            return {'FINISHED'}
        _ms_call_enabled_hook (obj ,mod ,new_st )
        main_obj =get_main_object (obj )
        # Force SmartLattice helper visibility to update immediately on this click.
        # This avoids cases where the lattice stays visible until a second click.
        try :
            bpy .app .driver_namespace ["_MS_FORCE_SL_SHARED_REFRESH_T"]=time .time ()
        except Exception :
            pass 
        if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =True )
        return {'FINISHED'}

class OBJECT_OT_ms_toggle_viewport_state (bpy .types .Operator ):
    bl_idname ="object.ms_toggle_viewport_state"
    bl_label ='Realtime Viewport'
    bl_description ='Toggle viewport visibility (monitor) (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        "Toggle whether this modifier is evaluated in the viewport (monitor icon).\n- OFF: Disable in the viewport temporarily (may not affect renders).\n- ON: Show in the viewport.\nNote: This is different from the modifier's overall enable/disable state."




        )

    def execute (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )
        if not obj :return {'FINISHED'}
        mod =obj .modifiers .get (self .modifier_name )
        cur =ms_mod_display_row_state (obj ,mod ,'vp')if mod else get_mod_viewport_state (obj ,self .modifier_name )
        new_st =not cur 
        if mod and ms_is_instance_modifier (mod ,obj ):
            iid =ms_get_instance_id (mod ,obj )
            for o ,m in ms_iter_instance_members (iid ):
                _ms_set_modifier_display_state_for_instance_sync (o ,m ,viewport =new_st ,context =context )
                o .update_tag ()
            main_obj =get_main_object (obj )
            if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
            return {'FINISHED'}
        set_mod_viewport_state (obj ,self .modifier_name ,new_st )
        main_obj =get_main_object (obj )
        if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =True )
        return {'FINISHED'}


class OBJECT_OT_ms_toggle_modifier_display_flag (bpy .types .Operator ):
    bl_idname ="object.ms_toggle_modifier_display_flag"
    bl_label ='Toggle Modifier Display Flag'
    bl_description ='Toggle a modifier display flag (cage, edit mode, render) (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()
    flag_name :bpy .props .StringProperty ()

    @classmethod
    def description (cls ,context ,properties ):
        flag =getattr (properties ,"flag_name","")or ""
        if flag =="show_on_cage":
            return pgettext ("Toggle On Cage for this modifier. When Realtime Viewport or Edit Mode display is OFF, Blender shows this control as inactive because cage display cannot be used for that row.")
        if flag =="show_in_editmode":
            return pgettext ("Toggle whether this modifier is visible while editing the object. When Realtime Viewport is OFF, Blender shows this control as inactive because edit-mode display cannot be evaluated.")
        if flag =="show_render":
            return pgettext ("Toggle whether this modifier is enabled for final rendering. With Modifier Auto Disable ON, modifiers below the active stack slot are temporarily forced OFF for render as well.")
        return pgettext ("Toggle this modifier display flag.")

    def execute (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )
        if not obj :return {'FINISHED'}
        mod =obj .modifiers .get (self .modifier_name )if hasattr (obj ,"modifiers")else None
        if not mod :return {'FINISHED'}
        flag =(self .flag_name or "").strip ()
        if flag not in {"show_render","show_in_editmode","show_on_cage"}:
            return {'CANCELLED'}

        def _get_state (_obj ,_mod ):
            if flag =="show_render":
                return bool (ms_mod_display_row_state (_obj ,_mod ,'render'))
            if flag =="show_in_editmode":
                return bool (ms_mod_display_row_state (_obj ,_mod ,'edit'))
            if flag =="show_on_cage":
                return bool (ms_mod_display_row_state (_obj ,_mod ,'cage'))
            return bool (getattr (_mod ,flag ,False ))

        def _set_state (_obj ,_mod ,_state ):
            try:
                if flag =="show_render":
                    set_mod_render_state (_obj ,_mod .name ,bool (_state ))
                elif flag =="show_in_editmode":
                    set_mod_editmode_state (_obj ,_mod .name ,bool (_state ))
                elif flag =="show_on_cage":
                    set_mod_cage_state (_obj ,_mod .name ,bool (_state ))
            except Exception:
                pass

        new_st =not _get_state (obj ,mod )
        if mod and ms_is_instance_modifier (mod ,obj ):
            iid =ms_get_instance_id (mod ,obj )
            for o ,m in ms_iter_instance_members (iid ):
                if flag =="show_render":
                    _ms_set_modifier_display_state_for_instance_sync (o ,m ,render =new_st ,context =context )
                elif flag =="show_in_editmode":
                    _ms_set_modifier_display_state_for_instance_sync (o ,m ,editmode =new_st ,context =context )
                elif flag =="show_on_cage":
                    _ms_set_modifier_display_state_for_instance_sync (o ,m ,cage =new_st ,context =context )
                try:o .update_tag ()
                except Exception:pass
            main_obj =get_main_object (obj )
            if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
            return {'FINISHED'}

        _set_state (obj ,mod ,new_st )
        main_obj =get_main_object (obj )
        if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =True )
        return {'FINISHED'}


class OBJECT_OT_ms_update_influence_range (bpy .types .Operator ):
    bl_idname ="object.ms_update_influence_range"
    bl_label ='Update Influence Range'
    bl_description ='Update influence range (vertex group) (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}

    modifier_name :bpy .props .StringProperty (
    name ="Modifier Name",
    description =(
    "Name of the modifier whose influence range you want to update.\nNormally this is filled automatically when you press the buttons, so you don't need to edit it manually."

    ),
    default ="",
    )
    target_obj_name :bpy .props .StringProperty (
    name ="Target Object",
    description =(
    "Name of the target object.\nNormally this is filled automatically when you press the buttons, so you don't need to edit it manually."

    ),
    default ="",
    )

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        'Update the influence range (vertex group).\nThis is useful for modifiers that can affect only part of the mesh via a vertex group (e.g., mask/weight based modifiers).\nHow to use: Select the target object and modifier, then press this button to auto-assign (and sometimes create) the vertex group, depending on the modifier type.'






        )

    def execute (self ,context ):
        try :
            obj =bpy .data .objects .get (self .target_obj_name )if self .target_obj_name else context .object 
            if not obj or getattr (obj ,"type","")!='MESH':
                return {'CANCELLED'}
            main_obj =get_main_object (obj )or obj 
            mod =obj .modifiers .get (self .modifier_name )if self .modifier_name else None 
            if not mod or not _ms_modifier_supports_vertex_group (mod ):
                return {'CANCELLED'}


                # Smart Lattice: use Smart_Lattice_Modifier's influence update behavior via operator.
                # (We keep identical behavior by delegating to smart_lattice.update_influence.)
            try :
                if getattr (mod ,"type","")=='LATTICE':
                    lat_obj =getattr (mod ,"object",None )
                    if lat_obj and ("sl_main_target"in lat_obj ):
                    # Try to resolve canonical main object and modifier name for correct parenting behavior.
                        mo =None 
                        try :
                            mo =bpy .data .objects .get (lat_obj .get ("sl_main_target"))
                        except Exception :
                            mo =None 
                        if not mo :
                            mo =obj 
                        main_mod_name =""
                        try :
                            for mm in mo .modifiers :
                                if getattr (mm ,"type","")=='LATTICE'and getattr (mm ,"object",None )==lat_obj :
                                    main_mod_name =mm .name 
                                    break 
                        except Exception :
                            main_mod_name =""
                        if not main_mod_name :
                            main_mod_name =mod .name 

                            # Refresh selection cache first (cheap when throttled elsewhere)
                        try :
                            if getattr (context ,"mode","")=='EDIT_MESH':
                                ms_capture_selection_to_cache_all (context )
                        except Exception :
                            pass 

                            # Execute SmartLattice update (no redo popup)
                        try :
                            bpy .ops .smart_lattice .update_influence ('EXEC_DEFAULT', False,
                            main_obj_name =mo .name ,
                            modifier_name =main_mod_name )
                            _ms_tag_redraw_all_view3d ()
                            return {'FINISHED'}
                        except Exception :
                        # Fallback to standard vertex-group update if operator is unavailable
                            pass 
            except Exception :
                pass 

                # Refresh selection cache first (cheap when throttled elsewhere)
            try :
                if getattr (context ,"mode","")=='EDIT_MESH':
                    ms_capture_selection_to_cache_all (context )
            except Exception :
                pass 

                # Determine target set: instance group or this modifier only
            targets =[(obj ,mod )]
            try :
                if ms_is_instance_modifier (mod ,obj ):
                    iid =ms_get_instance_id (mod ,obj )
                    if iid :
                        targets =list (ms_iter_instance_members (iid ,context ))
            except Exception :
                targets =[(obj ,mod )]

            order =None 
            try :
                order =ms_get_stack_order ()
            except Exception :
                order ='TOP_DOWN'

                # Use a stable group name across the group (if exists)
            vg_seed_name =_ms_auto_sel_get_vg_from_modifier (mod )or getattr (mod ,"vertex_group","")or ""
            vg_name_global =vg_seed_name if vg_seed_name else _ms_auto_sel_make_group_name (self .modifier_name or mod .name )

            updated_any =False 
            for tobj ,tmod in targets :
                if not tobj or not tmod :
                    continue 
                if getattr (tobj ,"type","")!='MESH':
                    continue 
                if not _ms_modifier_supports_vertex_group (tmod ):
                    continue 
                tmain =get_main_object (tobj )or tobj
                ms_auto_sel_sync_edit_mesh (tobj )

                # Find nearest carrier (towards BaseObject side) for THIS modifier position
                carrier_eff =_ms_find_nearest_carrier_effective_id_for_modifier (tmain ,tmod .name ,order =order )
                if not _ms_auto_sel_is_base_or_editpoly_effective (tmain ,carrier_eff ):
                # Not eligible: do nothing (keep standard behavior)
                    continue 

                carrier_key =ms_get_carrier_key_for_effective (tmain ,carrier_eff )
                sel =ms_sel_get (tmain ,carrier_key )

                # Fallback: inherit selection if carrier has none
                if not sel :
                    try :
                        inherit_key =ms_find_inherit_key_for_carrier (tmain ,carrier_key )
                        sel =ms_sel_get (tmain ,inherit_key )
                    except Exception :
                        sel =None 

                        # Convert to vertex indices and apply weights (empty selection => empty VG)
                v_idx =[]
                try :
                    if sel and not _ms_auto_sel_is_empty (sel ):
                        v_idx =_ms_auto_sel_sel_to_vert_indices (getattr (tobj ,"data",None ),sel )
                except Exception :
                    v_idx =[]
                # Nothing selected means the whole mesh is the influence range.
                if not v_idx :
                    v_idx =list (range (len (tobj .data .vertices )))

                vg_name =_ms_auto_sel_get_vg_from_modifier (tmod )or getattr (tmod ,"vertex_group","")or vg_name_global
                _ms_auto_sel_apply_vgroup_weights (tobj ,vg_name ,v_idx )
                ms_auto_sel_bind_vgroup (tmod ,vg_name )
                updated_any =True

            if updated_any :
                try :
                    context .view_layer .update ()
                except Exception :
                    pass 
                try :
                # Re-apply stack state to refresh EndPreview in Edit Mode immediately.
                    apply_modifier_stack_state (main_obj ,context ,interactive =False )
                except Exception :
                    pass 
                _ms_tag_redraw_all_view3d ()
            return {'FINISHED'}
        except Exception :
            return {'CANCELLED'}


class OBJECT_OT_ms_switch_level (bpy .types .Operator ):
    bl_idname ="object.ms_switch_level"
    bl_label ="Switch Level"
    bl_description ='Toggle edit levels (see tooltip for beginner-friendly details)'
    bl_options = {'UNDO'}
    target_mod_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty (default ="")
    ui_row_index :bpy .props .IntProperty (default =-1 )

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        "Set this item as the active 'edit level' in the stack.\n- Click: Makes that level active (and selects the object if needed).\n- Purpose: Edit the mesh at an intermediate stage, or temporarily disable modifiers above it to work more easily."





        )

    def execute (self ,context ):
        base_obj =bpy .data .objects .get (self .target_obj_name )if self .target_obj_name else context .active_object 
        main_obj =get_main_object (base_obj )
        if not main_obj or not ms_object_supports_modifier_stack (main_obj):return {'CANCELLED'}

        clicked =self .target_mod_name 
        try:
            stack_obj =ms_get_modifier_stack_object (main_obj ,context =context ,create =bool (clicked !="BASE"))or main_obj
        except Exception:
            stack_obj =main_obj
        if clicked !="BASE" and not ms_object_has_modifier_collection (stack_obj):
            clicked ="BASE"
        if not ms_object_has_modifier_collection (stack_obj):
            try:
                main_obj ["ui_active_item"]="BASE"
                main_obj ["ui_active_row"]=-1
                ms_set_ui_active_index (main_obj ,-1 )
                apply_modifier_stack_state (main_obj ,context ,interactive =False )
            except Exception:
                pass
            return {'FINISHED'}

        clicked_plugin_id =""
        if clicked !="BASE":
            try :
                _clicked_mod =stack_obj .modifiers .get (clicked )
                _clicked_plugin =ms_find_plugin_for_modifier (_clicked_mod )if _clicked_mod else None 
                if _clicked_plugin :
                    clicked_plugin_id =str (_clicked_plugin .get ("id")or "")
            except Exception :
                clicked_plugin_id =""
        if clicked_plugin_id :
            _ms_request_plugin_live_runtime (clicked_plugin_id )
        current_ui =ms_get_ui_active_id (main_obj )
        is_repeat_click =(clicked ==current_ui )
        is_edit_mode =bool (str (getattr (context ,"mode","OBJECT")).startswith ("EDIT"))
        # Keep Edit Mode alive when switching to a different stack level from any edit context.
        # Repeat-click still acts as the explicit toggle for the already-active item.
        want_edit_mode =(not is_edit_mode )if is_repeat_click else is_edit_mode 
        # Deterministic switching: queue a two-phase transition so Blender can commit mode/selection changes.
        # This is the most robust way to avoid 'needs two clicks' and selection/lattice glitches.
        if not ms_is_multi_mode (context ):
            try :
                _ms_queue_level_switch (main_obj ,clicked ,int (self .ui_row_index ),bool (want_edit_mode ))
            except Exception :
                pass 
            return {'FINISHED'}

            # When switching from one stack item to another while already in any Edit Mode (EDIT_MESH / EDIT_LATTICE),
            # exit to OBJECT once before applying the new state. This prevents "needs two clicks" and selection loss.
        if (not is_repeat_click )and is_edit_mode :
            vl =getattr (context ,"view_layer",None )
            _orig_sel_names ,_orig_active_name =_ms_snapshot_object_selection (vl )if vl else ([],"")
            try :
                _orig_sel_names =[n for n in (_orig_sel_names or [])if not (bpy .data .objects .get (n )and bpy .data .objects [n ].type =='LATTICE')]
            except Exception :
                pass 
            try :
                ms_capture_selection_to_cache (context )
            except Exception :
                pass 
            try :
                if bpy .ops .object .mode_set .poll ():
                    bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :
                pass 
            try :
                if vl and _orig_sel_names :
                    _ms_ensure_object_selection (vl ,_orig_sel_names )
                if vl :
                    _ms_set_obj_hidden (main_obj ,False ,False )
                    main_obj .select_set (True )
                    vl .objects .active =main_obj 
            except Exception :
                pass 


                # If we're already in Edit Mode and switching to a different stack item (not a repeat click),
                # we must exit to OBJECT once so Blender can switch the edit_object on re-enter.
        _need_restart_edit =bool (is_edit_mode and want_edit_mode and (not is_repeat_click ))

        if ms_is_multi_mode (context ):
            targets =ms_get_selected_main_meshes (context )or [main_obj ]
            iid ="";ordinal =0 
            if clicked !="BASE":
                _mm =stack_obj .modifiers .get (clicked )
                if _mm and ms_is_instance_modifier (_mm ,stack_obj ):
                    iid =ms_get_instance_id (_mm ,stack_obj )
                    lst =ms_list_instance_modifiers_in_stack_order (stack_obj ,iid )
                    for i ,mmx in enumerate (lst ):
                        if mmx .name ==clicked :
                            ordinal =i ;break 

            if (is_edit_mode and not want_edit_mode )or _need_restart_edit :
                ms_capture_selection_to_cache (context )
                try :
                    if bpy .ops .object .mode_set .poll ():bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
                except Exception :pass 

            for o in targets :
                if not o or not ms_object_supports_modifier_stack (o):continue 
                try:_o_stack =ms_get_modifier_stack_object (o ,context =context ,create =bool (clicked !="BASE"))or o
                except Exception:_o_stack =o
                if clicked !="BASE" and not ms_object_has_modifier_collection (_o_stack):continue
                if clicked =="BASE":
                    o ["ui_active_item"]="BASE"
                    o ["ui_active_row"]=int (self .ui_row_index )
                    ms_set_ui_active_index (o ,-1 )
                else :
                    if iid :
                        m2 =ms_find_modifier_by_instance_id_and_ordinal (_o_stack ,iid ,ordinal )
                        o ["ui_active_item"]=(m2 .name if m2 else clicked )
                        o ["ui_active_row"]=int (self .ui_row_index )
                        ms_set_ui_active_index (o ,_o_stack .modifiers .find (o ["ui_active_item"]))
                        if m2 :_o_stack .modifiers .active =m2 
                    else :
                        o ["ui_active_item"]=clicked 
                        o ["ui_active_row"]=int (self .ui_row_index )
                        ms_set_ui_active_index (o ,_o_stack .modifiers .find (clicked ))
                        am =_o_stack .modifiers .get (clicked )
                        if am :_o_stack .modifiers .active =am 
                apply_modifier_stack_state (o ,context ,interactive =False )

            if want_edit_mode :
                vl =getattr (context ,"view_layer",None )
                if vl :
                # Preserve user's selection: never deselect existing objects.
                    _orig_sel_names ,_orig_active_name =_ms_snapshot_object_selection (vl )
                    if _orig_sel_names :
                        _ms_ensure_object_selection (vl ,_orig_sel_names )
                    for o in targets :
                        try :o .hide_set (False )
                        except Exception :pass 
                        try :
                            if _ms_is_internal_visibility_helper_object (o):
                                if hasattr (o ,'hide_viewport') :o .hide_viewport =False
                                if hasattr (o ,'hide_select') :o .hide_select =False
                        except Exception :pass 
                        o .select_set (True )
                    vl .objects .active =main_obj 
                try :
                    if getattr (context ,"mode","OBJECT")!='EDIT_MESH':
                        # Multi-object row/keymap switching is synchronous rather
                        # than timer-driven, so explicitly mark this short mode
                        # transition as user initiated.  Without this guard the
                        # safety check in ms__safe_mode_set rejects re-entering
                        # Edit Mode and the up/down keymap leaves Blender in
                        # Object Mode even though the same edit level was meant
                        # to stay active.
                        _dn_mode =_ms__dn ()
                        _had_allow ="_MS_ALLOW_MODESET_V1" in _dn_mode
                        _prev_allow =_dn_mode .get ("_MS_ALLOW_MODESET_V1")
                        _dn_mode ["_MS_ALLOW_MODESET_V1"]=True
                        try :
                            ms__safe_mode_set (context ,main_obj ,'EDIT')
                        finally :
                            if _had_allow :
                                _dn_mode ["_MS_ALLOW_MODESET_V1"]=_prev_allow
                            else :
                                _dn_mode .pop ("_MS_ALLOW_MODESET_V1",None )
                    for o in targets :
                        c_key =ms_get_carrier_key_for_effective (o ,o .get ("ui_active_item","BASE"))
                        ms_apply_selection_for_carrier (o ,o ,c_key )
                        o .update_tag ()
                except Exception :pass 
            return {'FINISHED'}

        is_clicked_smart_lattice =bool (clicked_plugin_id =="smart_lattice")

        if is_repeat_click and not want_edit_mode :
            ms_capture_selection_to_cache (context )
            try :
                if bpy .ops .object .mode_set .poll ():bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :pass 
            if is_clicked_smart_lattice :
                main_obj ["ms_sl_engaged"]=False 
                main_obj ["ms_sl_engaged_mod"]=clicked 
            else :
                main_obj .pop ("ms_sl_engaged",None )
                main_obj .pop ("ms_sl_engaged_mod",None )
            vl =getattr (context ,"view_layer",None )
            if vl :
            # Preserve user's selection: never deselect existing objects.
                _orig_sel_names ,_orig_active_name =_ms_snapshot_object_selection (vl )
                if _orig_sel_names :
                    _ms_ensure_object_selection (vl ,_orig_sel_names )
                _ms_set_obj_hidden (main_obj ,False ,False )
                main_obj .select_set (True )
                vl .objects .active =main_obj 
            apply_modifier_stack_state (main_obj ,context ,interactive =False )
            return {'FINISHED'}

        main_obj ["ui_active_item"]=clicked 
        main_obj ["ui_active_row"]=int (self .ui_row_index )
        if clicked =="BASE":ms_set_ui_active_index (main_obj ,-1 )
        else :ms_set_ui_active_index (main_obj ,stack_obj .modifiers .find (clicked ))

        if clicked !="BASE":
            m =stack_obj .modifiers .get (clicked )
            if m :stack_obj .modifiers .active =m 

        if is_clicked_smart_lattice :
            main_obj ["ms_sl_engaged"]=True 
            main_obj ["ms_sl_engaged_mod"]=clicked 
        else :
            main_obj .pop ("ms_sl_engaged",None )
            main_obj .pop ("ms_sl_engaged_mod",None )

        ms_apply_state_post_action (context ,main_obj ,interactive_default =True )
        return {'FINISHED'}

class OBJECT_OT_ms_rename_modifier (bpy .types .Operator ):
    bl_idname ="object.ms_rename_modifier"
    bl_label ='Rename'
    bl_description ='Rename the modifier (display name) (see tooltip for beginner-friendly details)'
    bl_options ={'UNDO'}
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()
    new_name :bpy .props .StringProperty (
    name ='New Name',
    description =(
    "Enter the new display name.\nTip: Use a short, descriptive name (e.g., 'Hair_Volume') so it is easier to manage."

    ),
    )

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        'Rename the modifier (display name).\nUse this to make items easier to identify in the stack.\nNote: If the modifier is linked/instanced, the name change may affect linked instances too.'



        )

    def invoke (self ,context ,event ):
        self .new_name =ms_obj_get_disp_name (bpy .data .objects .get (self .target_obj_name ),self .modifier_name )or self .modifier_name 
        return context .window_manager .invoke_props_dialog (self )

    def execute (self ,context ):
        bridge_state = ms_stack_popup_prepare_object_mode(context)
        try:
            return self._execute_core(context)
        finally:
            ms_stack_popup_restore_mode(context, bridge_state)

    def _execute_core (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )
        if not obj :return {'CANCELLED'}
        mod =obj .modifiers .get (self .modifier_name )
        if not mod :return {'CANCELLED'}
        if ms_is_instance_modifier (mod ,obj ):
            iid =ms_get_instance_id (mod ,obj )
            pairs =list (ms_iter_instance_members (iid ,context =context )or [])
            if not pairs:
                pairs =[(obj ,mod )]
            for o ,m in pairs:
                try:
                    old_name =m .name
                    renamed =ms_safe_rename_modifier (o ,m ,self .new_name )
                    # If Blender refuses a real RNA rename because of a local name
                    # collision, keep the Smart Modifier display name synchronized.
                    ms_obj_set_disp_name (o ,m .name ,self .new_name )
                    if renamed:
                        ms_obj_rename_instance_key (o ,old_name ,m .name )
                    ms_obj_set_instance_id (o ,m .name ,iid ,disp_name =self .new_name )
                except Exception:
                    pass
            main_obj =get_main_object (obj )
            if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
            return {'FINISHED'}
        try:
            ms_safe_rename_modifier (obj ,mod ,self .new_name )
            # A refused rename keeps the real name; the display name still changes.
            ms_obj_set_disp_name (obj ,mod .name ,self .new_name )
        except Exception:
            try:ms_obj_set_disp_name (obj ,mod .name ,self .new_name )
            except Exception:pass
        main_obj =get_main_object (obj )
        if main_obj :ms_apply_state_post_action (context ,main_obj ,interactive_default =False )
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# Shape-key-safe modifier application
# -----------------------------------------------------------------------------

_MS_SHAPE_KEY_APPLY_CURRENT_MIX = "CURRENT_MIX"
_MS_SHAPE_KEY_APPLY_BASIS = "BASIS"
_MS_SHAPE_KEY_APPLY_MODES = {
    _MS_SHAPE_KEY_APPLY_CURRENT_MIX,
    _MS_SHAPE_KEY_APPLY_BASIS,
}
_MS_SHAPE_KEY_APPLY_MODE_ITEMS = (
    (_MS_SHAPE_KEY_APPLY_CURRENT_MIX, "Current Mix", ""),
    (_MS_SHAPE_KEY_APPLY_BASIS, "Basis", ""),
)


class _MSShapeKeyApplyError(RuntimeError):
    pass


def _ms_report_operator(operator, level, message):
    reporter = getattr(operator, "report", None)
    if callable(reporter):
        try:
            reporter({str(level or "ERROR")}, str(message or ""))
        except Exception:
            pass


def _ms_shape_key_choice_required_message(context):
    return choose_text(
        "This apply action contains shape keys. Invoke the operator interactively and choose how the new Basis should be created.",
        "この適用対象にはシェイプキーがあります。対話実行し、新しいBasisの作成方法を選択してください。",
        context=context,
    )


def _ms_invoke_shape_key_apply_dialog(operator, context):
    operator.shape_key_choice_confirmed = True
    wm = getattr(context, "window_manager", None)
    if wm is None:
        _ms_report_operator(operator, "ERROR", _ms_shape_key_choice_required_message(context))
        return {"CANCELLED"}
    title = choose_text(
        "Apply Modifier with Shape Keys",
        "シェイプキーを保全してモディファイアを適用",
        context=context,
    )
    confirm_text = choose_text("Apply", "適用", context=context)
    try:
        return wm.invoke_props_dialog(
            operator,
            width=560,
            title=title,
            confirm_text=confirm_text,
            cancel_default=True,
        )
    except TypeError:
        return wm.invoke_props_dialog(operator, width=560)


def _ms_draw_shape_key_apply_dialog(operator, context):
    layout = operator.layout
    col = layout.column(align=True)
    col.label(
        text=choose_text(
            "The object has shape keys. Choose the Basis used for this apply action.",
            "対象オブジェクトにシェイプキーがあります。今回の適用で使用するBasisを選択してください。",
            context=context,
        ),
        icon="SHAPEKEY_DATA",
    )
    col.label(
        text=choose_text(
            "The selected choice is reused for every object and every modifier in this operation.",
            "複数オブジェクトや「ここまでを適用」でも、最初の選択を全対象へ共通使用します。",
            context=context,
        )
    )
    layout.separator()
    choices = layout.column(align=True)
    choices.prop_enum(
        operator,
        "shape_key_apply_mode",
        _MS_SHAPE_KEY_APPLY_CURRENT_MIX,
        text=choose_text(
            "Use Current Shape as New Basis",
            "現在のシェイプキーの形状をベースにして適用",
            context=context,
        ),
    )
    choices.prop_enum(
        operator,
        "shape_key_apply_mode",
        _MS_SHAPE_KEY_APPLY_BASIS,
        text=choose_text(
            "Return to Basis and Apply",
            "ベースに戻して適用",
            context=context,
        ),
    )
    layout.separator()
    layout.label(
        text=choose_text(
            "Cancel leaves the complete stack unchanged.",
            "キャンセルした場合、スタック全体は変更されません。",
            context=context,
        ),
        icon="NONE",
    )


def _ms_find_corresponding_modifier_for_apply(source_obj, source_mod, target_obj, context):
    if not target_obj or not source_mod or not ms_object_has_modifier_collection(target_obj):
        return None
    try:
        if target_obj == source_obj:
            return target_obj.modifiers.get(source_mod.name)
    except Exception:
        pass
    source_instance_id = ""
    try:
        if ms_is_instance_modifier(source_mod, source_obj):
            source_instance_id = str(ms_get_instance_id(source_mod, source_obj) or "")
    except Exception:
        source_instance_id = ""
    if source_instance_id:
        try:
            return ms_find_modifier_by_instance_id(target_obj, source_instance_id)
        except Exception:
            return None
    source_type = str(getattr(source_mod, "type", "") or "")
    source_name = str(getattr(source_mod, "name", "") or "")
    try:
        candidate = target_obj.modifiers.get(source_name) if source_name else None
        if candidate and str(getattr(candidate, "type", "") or "") == source_type:
            return candidate
    except Exception:
        pass
    logical_name = ""
    try:
        logical_name = str(ms_get_logical_modifier_name(source_obj, source_mod) or "")
    except Exception:
        logical_name = ""
    if logical_name:
        try:
            for candidate in target_obj.modifiers:
                if str(getattr(candidate, "type", "") or "") != source_type:
                    continue
                try:
                    if str(ms_get_logical_modifier_name(target_obj, candidate) or "") == logical_name:
                        return candidate
                except Exception:
                    continue
        except Exception:
            pass
    try:
        source_index = source_obj.modifiers.find(source_name) if source_obj and source_name else -1
        if 0 <= source_index < len(target_obj.modifiers):
            candidate = target_obj.modifiers[source_index]
            if candidate and str(getattr(candidate, "type", "") or "") == source_type:
                return candidate
    except Exception:
        pass
    return None


def _ms_collect_apply_pairs_for_choice(context, action, modifier_name, target_obj_name):
    action = str(action or "")
    if action not in {"APPLY", "APPLY_BELOW"}:
        return []
    source_obj = bpy.data.objects.get(str(target_obj_name or ""))
    main_obj = get_main_object(source_obj) if source_obj else None
    if not source_obj or not main_obj or not ms_object_has_modifier_collection(source_obj):
        return []
    source_mod = source_obj.modifiers.get(str(modifier_name or "")) if modifier_name else None
    if source_mod is None:
        return []
    try:
        targets = (
            ms_get_selected_main_meshes(context)
            if ms_is_multi_mode(context)
            else [source_obj]
        )
    except Exception:
        targets = [source_obj]
    try:
        if ms_is_shape_mesh_proxy(source_obj):
            targets = [source_obj]
    except Exception:
        pass
    pairs = []
    seen = set()
    for target_obj in list(targets or []):
        target_mod = _ms_find_corresponding_modifier_for_apply(
            source_obj, source_mod, target_obj, context
        )
        if target_mod is None:
            continue
        key = (str(getattr(target_obj, "name", "") or ""), str(getattr(target_mod, "name", "") or ""))
        if key in seen:
            continue
        seen.add(key)
        pairs.append((target_obj, target_mod))
    return pairs


def _ms_object_has_shape_key_blocks(obj):
    try:
        shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
        return bool(shape_keys is not None and len(shape_keys.key_blocks) > 0)
    except Exception:
        return False


def _ms_apply_action_needs_shape_key_choice(context, action, modifier_name, target_obj_name):
    for target_obj, target_mod in _ms_collect_apply_pairs_for_choice(
        context, action, modifier_name, target_obj_name
    ):
        if not _ms_object_has_shape_key_blocks(target_obj):
            continue
        if str(action or "") == "APPLY":
            return True
        try:
            target_index = target_obj.modifiers.find(target_mod.name)
            if target_index < 0:
                continue
            for candidate in target_obj.modifiers[: target_index + 1]:
                if not ms_modifier_is_internal_stack_helper(candidate):
                    return True
        except Exception:
            return True
    return False


def _ms_idprop_snapshot(owner):
    result = {}
    try:
        keys = list(owner.keys())
    except Exception:
        return result
    for key in keys:
        try:
            result[str(key)] = copy.deepcopy(owner[key])
        except Exception:
            try:
                result[str(key)] = owner[key]
            except Exception:
                pass
    return result


def _ms_idprop_restore(owner, values):
    for key, value in dict(values or {}).items():
        try:
            owner[key] = copy.deepcopy(value)
        except Exception:
            try:
                owner[key] = value
            except Exception:
                pass


def _ms_shape_key_point_coords(key_block):
    count = len(key_block.data)
    coords = array("f", [0.0]) * (count * 3)
    key_block.data.foreach_get("co", coords)
    return coords


def _ms_mesh_vertex_coords(mesh):
    count = len(mesh.vertices)
    coords = array("f", [0.0]) * (count * 3)
    mesh.vertices.foreach_get("co", coords)
    return coords


def _ms_mesh_topology_signature(mesh):
    edge_vertices = array("i", [0]) * (len(mesh.edges) * 2)
    loop_vertices = array("i", [0]) * len(mesh.loops)
    polygon_starts = array("i", [0]) * len(mesh.polygons)
    polygon_totals = array("i", [0]) * len(mesh.polygons)
    if edge_vertices:
        mesh.edges.foreach_get("vertices", edge_vertices)
    if loop_vertices:
        mesh.loops.foreach_get("vertex_index", loop_vertices)
    if polygon_starts:
        mesh.polygons.foreach_get("loop_start", polygon_starts)
        mesh.polygons.foreach_get("loop_total", polygon_totals)
    return (
        len(mesh.vertices),
        len(mesh.edges),
        len(mesh.loops),
        len(mesh.polygons),
        edge_vertices.tobytes(),
        loop_vertices.tobytes(),
        polygon_starts.tobytes(),
        polygon_totals.tobytes(),
    )


def _ms_simple_rna_snapshot(owner, excluded=()):
    excluded = set(excluded or ()) | {"rna_type"}
    result = {}
    try:
        properties = owner.bl_rna.properties
    except Exception:
        return result
    for prop in properties:
        identifier = str(getattr(prop, "identifier", "") or "")
        if not identifier or identifier in excluded or bool(getattr(prop, "is_readonly", False)):
            continue
        if str(getattr(prop, "type", "") or "") not in {"BOOLEAN", "INT", "FLOAT", "STRING", "ENUM"}:
            continue
        try:
            value = getattr(owner, identifier)
            if bool(getattr(prop, "is_array", False)):
                value = tuple(value)
            result[identifier] = value
        except Exception:
            continue
    return result


def _ms_simple_rna_restore(owner, values, *, strict=()):
    strict = set(strict or ())
    failures = []
    for identifier, value in dict(values or {}).items():
        try:
            setattr(owner, identifier, value)
        except Exception as exc:
            if identifier in strict:
                failures.append(f"{identifier}: {exc}")
    if failures:
        raise _MSShapeKeyApplyError("; ".join(failures))


def _ms_driver_snapshot(fcurve, owner_shape_keys=None):
    driver = fcurve.driver
    variables = []
    for variable in driver.variables:
        targets = []
        for target in variable.targets:
            target_id = getattr(target, "id", None)
            targets.append(
                {
                    "simple": _ms_simple_rna_snapshot(target, excluded={"id"}),
                    "id": target_id,
                    "self_id": bool(owner_shape_keys is not None and target_id is owner_shape_keys),
                }
            )
        variables.append(
            {
                "simple": _ms_simple_rna_snapshot(variable, excluded={"targets"}),
                "targets": targets,
            }
        )
    modifiers = []
    for modifier in fcurve.modifiers:
        modifiers.append(
            {
                "type": str(getattr(modifier, "type", "") or ""),
                "simple": _ms_simple_rna_snapshot(modifier, excluded={"type"}),
            }
        )
    points = []
    for point in fcurve.keyframe_points:
        points.append(_ms_simple_rna_snapshot(point))
    return {
        "data_path": str(fcurve.data_path or ""),
        "array_index": int(fcurve.array_index),
        "fcurve": _ms_simple_rna_snapshot(
            fcurve,
            excluded={"data_path", "array_index", "driver", "modifiers", "keyframe_points", "group"},
        ),
        "driver": _ms_simple_rna_snapshot(driver, excluded={"variables"}),
        "variables": variables,
        "modifiers": modifiers,
        "points": points,
    }


def _ms_shape_key_animation_snapshot(shape_keys):
    animation_data = getattr(shape_keys, "animation_data", None)
    if animation_data is None:
        return None
    try:
        if any(len(track.strips) > 0 for track in animation_data.nla_tracks):
            raise _MSShapeKeyApplyError(
                "Shape-key NLA tracks cannot be rebuilt safely by this operation."
            )
    except _MSShapeKeyApplyError:
        raise
    except Exception:
        pass
    return {
        "action": getattr(animation_data, "action", None),
        "simple": _ms_simple_rna_snapshot(
            animation_data,
            excluded={"action", "drivers", "nla_tracks"},
        ),
        "drivers": [_ms_driver_snapshot(fc, shape_keys) for fc in animation_data.drivers],
    }


def _ms_driver_add_restored(shape_keys, data_path, array_index):
    try:
        resolved_value = shape_keys.path_resolve(data_path)
    except Exception as exc:
        raise _MSShapeKeyApplyError(
            f"Failed to resolve shape-key driver path {data_path}: {exc}"
        ) from exc
    if isinstance(resolved_value, (str, bytes)):
        array_length = None
    else:
        try:
            array_length = len(resolved_value)
        except TypeError:
            array_length = None
    if array_length is None:
        if array_index not in (0, -1):
            raise _MSShapeKeyApplyError(
                f"Scalar shape-key driver path {data_path} has invalid array index {array_index}."
            )
        return shape_keys.driver_add(data_path)
    if array_index < 0 or array_index >= array_length:
        raise _MSShapeKeyApplyError(
            f"Shape-key driver path {data_path} has invalid array index "
            f"{array_index} for length {array_length}."
        )
    return shape_keys.driver_add(data_path, array_index)


def _ms_driver_restore(shape_keys, snapshots):
    for snapshot in list(snapshots or []):
        data_path = str(snapshot.get("data_path", "") or "")
        array_index = int(snapshot.get("array_index", 0) or 0)
        try:
            fcurve = _ms_driver_add_restored(shape_keys, data_path, array_index)
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to restore shape-key driver {data_path}[{array_index}]: {exc}"
            ) from exc
        _ms_simple_rna_restore(fcurve.driver, snapshot.get("driver", {}))
        for variable_snapshot in snapshot.get("variables", []):
            variable = fcurve.driver.variables.new()
            _ms_simple_rna_restore(variable, variable_snapshot.get("simple", {}))
            for target, target_snapshot in zip(variable.targets, variable_snapshot.get("targets", [])):
                _ms_simple_rna_restore(target, target_snapshot.get("simple", {}))
                target_id = shape_keys if bool(target_snapshot.get("self_id", False)) else target_snapshot.get("id")
                if target_id is not None:
                    try:
                        target.id = target_id
                    except Exception as exc:
                        raise _MSShapeKeyApplyError(
                            f"Failed to restore a shape-key driver target: {exc}"
                        ) from exc
        for modifier_snapshot in snapshot.get("modifiers", []):
            modifier_type = str(modifier_snapshot.get("type", "") or "")
            if not modifier_type:
                continue
            try:
                modifier = fcurve.modifiers.new(type=modifier_type)
                _ms_simple_rna_restore(modifier, modifier_snapshot.get("simple", {}))
            except Exception as exc:
                raise _MSShapeKeyApplyError(
                    f"Failed to restore shape-key driver modifier {modifier_type}: {exc}"
                ) from exc
        points = list(snapshot.get("points", []) or [])
        if points:
            try:
                fcurve.keyframe_points.add(len(points))
                for point, point_snapshot in zip(fcurve.keyframe_points, points):
                    _ms_simple_rna_restore(point, point_snapshot)
            except Exception as exc:
                raise _MSShapeKeyApplyError(
                    f"Failed to restore shape-key driver points: {exc}"
                ) from exc
        _ms_simple_rna_restore(fcurve, snapshot.get("fcurve", {}))


def _ms_shape_key_animation_restore(shape_keys, snapshot):
    if not snapshot:
        return
    animation_data = shape_keys.animation_data_create()
    action = snapshot.get("action")
    if action is not None:
        try:
            animation_data.action = action
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to restore the shape-key action: {exc}"
            ) from exc
    _ms_simple_rna_restore(animation_data, snapshot.get("simple", {}))
    _ms_driver_restore(shape_keys, snapshot.get("drivers", []))


def _ms_shape_key_state_snapshot(obj):
    mesh = getattr(obj, "data", None)
    shape_keys = getattr(mesh, "shape_keys", None) if mesh is not None else None
    if shape_keys is None or len(shape_keys.key_blocks) == 0:
        return None
    blocks = []
    key_blocks = list(shape_keys.key_blocks)
    index_by_pointer = {block.as_pointer(): index for index, block in enumerate(key_blocks)}
    for index, block in enumerate(key_blocks):
        relative_index = 0
        try:
            relative_index = index_by_pointer.get(block.relative_key.as_pointer(), 0)
        except Exception:
            relative_index = 0
        blocks.append(
            {
                "name": str(block.name or ""),
                "coords": _ms_shape_key_point_coords(block),
                "relative_index": int(relative_index),
                "simple": _ms_simple_rna_snapshot(
                    block,
                    excluded={"name", "data", "relative_key"},
                ),
                "idprops": _ms_idprop_snapshot(block),
            }
        )
    return {
        "mesh_name": str(mesh.name or ""),
        "shape_keys_name": str(shape_keys.name or ""),
        "shape_keys_simple": _ms_simple_rna_snapshot(
            shape_keys,
            excluded={"name", "key_blocks", "reference_key", "animation_data"},
        ),
        "shape_keys_idprops": _ms_idprop_snapshot(shape_keys),
        "blocks": blocks,
        "active_index": int(getattr(obj, "active_shape_key_index", 0) or 0),
        "show_only": bool(getattr(obj, "show_only_shape_key", False)),
        "edit_mode": bool(getattr(obj, "use_shape_key_edit_mode", False)),
        "animation": _ms_shape_key_animation_snapshot(shape_keys),
    }


def _ms_link_temp_object(temp_obj, context):
    collection = getattr(context, "collection", None)
    if collection is not None:
        try:
            collection.objects.link(temp_obj)
            return
        except Exception:
            pass
    scene = getattr(context, "scene", None) or getattr(bpy.context, "scene", None)
    if scene is None:
        raise _MSShapeKeyApplyError("No writable scene collection is available for staging.")
    scene.collection.objects.link(temp_obj)


def _ms_create_shape_key_temp_object(obj, context, token):
    if str(getattr(obj, "type", "") or "") != "MESH":
        raise _MSShapeKeyApplyError("Only mesh shape keys can be rebuilt safely.")
    temp_obj = obj.copy()
    temp_mesh = obj.data.copy()
    temp_obj.data = temp_mesh
    suffix = str(token or uuid.uuid4().hex)[:12]
    temp_obj.name = f"__SMS_SK_APPLY_OBJ_{suffix}"
    temp_mesh.name = f"__SMS_SK_APPLY_MESH_{suffix}"
    try:
        temp_obj.hide_render = True
        temp_obj.hide_viewport = False
        temp_obj.hide_select = False
    except Exception:
        pass
    _ms_link_temp_object(temp_obj, context)
    try:
        temp_obj.hide_set(False)
    except Exception:
        pass
    return temp_obj


def _ms_remove_exact_shape_key_temp(temp_obj):
    if temp_obj is None:
        return
    try:
        temp_mesh = temp_obj.data
    except Exception:
        temp_mesh = None
    try:
        temp_keys = temp_mesh.shape_keys if temp_mesh is not None else None
    except Exception:
        temp_keys = None
    try:
        bpy.data.objects.remove(temp_obj, do_unlink=True)
    except Exception:
        try:
            for collection in tuple(getattr(temp_obj, "users_collection", ()) or ()):
                collection.objects.unlink(temp_obj)
        except Exception:
            pass
    if temp_mesh is not None:
        try:
            if int(getattr(temp_mesh, "users", 0) or 0) == 0:
                bpy.data.meshes.remove(temp_mesh)
        except Exception:
            pass
    if temp_keys is not None:
        try:
            if int(getattr(temp_keys, "users", 0) or 0) == 0:
                bpy.data.shape_keys.remove(temp_keys)
        except Exception:
            pass


def _ms_remove_all_temp_shape_keys(temp_obj):
    guard = 0
    while True:
        shape_keys = getattr(getattr(temp_obj, "data", None), "shape_keys", None)
        if shape_keys is None or len(shape_keys.key_blocks) == 0:
            return
        guard += 1
        if guard > 100000:
            raise _MSShapeKeyApplyError("Shape-key staging did not converge.")
        try:
            temp_obj.shape_key_remove(shape_keys.key_blocks[-1])
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to remove staging shape keys: {exc}"
            ) from exc


def _ms_capture_current_shape_key_mix(obj, context):
    temp_obj = None
    try:
        temp_obj = _ms_create_shape_key_temp_object(obj, context, uuid.uuid4().hex)
        try:
            mix_key = temp_obj.shape_key_add(
                name="__SMS_CURRENT_MIX__", from_mix=True
            )
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to capture the current shape-key mix: {exc}"
            ) from exc
        return _ms_shape_key_point_coords(mix_key)
    finally:
        _ms_remove_exact_shape_key_temp(temp_obj)


def _ms_apply_modifier_to_staging_object(temp_obj, modifier_name, context):
    modifier = temp_obj.modifiers.get(str(modifier_name or ""))
    if modifier is None:
        raise _MSShapeKeyApplyError(
            f"The staging copy does not contain modifier '{modifier_name}'."
        )
    try:
        modifier.show_viewport = True
        modifier.show_render = True
    except Exception:
        pass
    view_layer = getattr(context, "view_layer", None)
    if view_layer is None:
        raise _MSShapeKeyApplyError("No active view layer is available for modifier application.")
    previous_active = None
    try:
        previous_active = view_layer.objects.active
    except Exception:
        previous_active = None
    try:
        view_layer.objects.active = temp_obj
        temp_obj.select_set(True)
        override_kwargs = {
            "object": temp_obj,
            "active_object": temp_obj,
            "selected_objects": [temp_obj],
            "selected_editable_objects": [temp_obj],
            "view_layer": view_layer,
        }
        with context.temp_override(**override_kwargs):
            result = bpy.ops.object.modifier_apply(
                "EXEC_DEFAULT", False, modifier=modifier.name
            )
        if result is not None and "FINISHED" not in result:
            raise _MSShapeKeyApplyError(
                f"Blender rejected modifier '{modifier_name}' ({sorted(result)})."
            )
        if temp_obj.modifiers.get(str(modifier_name or "")) is not None:
            raise _MSShapeKeyApplyError(
                f"Modifier '{modifier_name}' remained on the staging object after apply."
            )
    finally:
        try:
            temp_obj.select_set(False)
        except Exception:
            pass
        try:
            if previous_active is not None:
                view_layer.objects.active = previous_active
        except Exception:
            pass


def _ms_stage_shape_key_modifier_result(obj, modifier, context, apply_mode):
    apply_mode = str(apply_mode or _MS_SHAPE_KEY_APPLY_BASIS)
    if apply_mode not in _MS_SHAPE_KEY_APPLY_MODES:
        raise _MSShapeKeyApplyError("A valid shape-key apply mode was not supplied.")
    state = _ms_shape_key_state_snapshot(obj)
    if not state:
        raise _MSShapeKeyApplyError("The object no longer has shape keys.")
    blocks = state["blocks"]
    if not blocks:
        raise _MSShapeKeyApplyError("The shape-key stack is empty.")
    basis_coords = blocks[0]["coords"]
    rebase_delta = None
    if apply_mode == _MS_SHAPE_KEY_APPLY_CURRENT_MIX:
        current_mix = _ms_capture_current_shape_key_mix(obj, context)
        if len(current_mix) != len(basis_coords):
            raise _MSShapeKeyApplyError(
                "The current mixed shape does not match the Basis vertex count."
            )
        rebase_delta = array(
            "f", (current_mix[index] - basis_coords[index] for index in range(len(basis_coords)))
        )
    output_mesh = None
    output_coords = []
    topology_signature = None
    try:
        for block_index, block in enumerate(blocks):
            source_coords = block["coords"]
            if rebase_delta is not None:
                source_coords = array(
                    "f",
                    (
                        source_coords[index] + rebase_delta[index]
                        for index in range(len(source_coords))
                    ),
                )
            temp_obj = None
            try:
                temp_obj = _ms_create_shape_key_temp_object(
                    obj, context, f"{uuid.uuid4().hex}_{block_index}"
                )
                _ms_remove_all_temp_shape_keys(temp_obj)
                if len(temp_obj.data.vertices) * 3 != len(source_coords):
                    raise _MSShapeKeyApplyError(
                        f"Shape key '{block['name']}' has an incompatible vertex count."
                    )
                temp_obj.data.vertices.foreach_set("co", source_coords)
                temp_obj.data.update()
                _ms_apply_modifier_to_staging_object(
                    temp_obj, str(getattr(modifier, "name", "") or ""), context
                )
                current_signature = _ms_mesh_topology_signature(temp_obj.data)
                if topology_signature is None:
                    topology_signature = current_signature
                    output_mesh = temp_obj.data.copy()
                elif current_signature != topology_signature:
                    raise _MSShapeKeyApplyError(
                        "The modifier produces different topology for shape key "
                        f"'{block['name']}'. All reconstructed keys must have identical topology."
                    )
                output_coords.append(_ms_mesh_vertex_coords(temp_obj.data))
            finally:
                _ms_remove_exact_shape_key_temp(temp_obj)
        if output_mesh is None or len(output_coords) != len(blocks):
            raise _MSShapeKeyApplyError("The shape-key staging result is incomplete.")
        return {
            "mesh": output_mesh,
            "coords": output_coords,
            "state": state,
        }
    except Exception:
        if output_mesh is not None:
            try:
                if int(getattr(output_mesh, "users", 0) or 0) == 0:
                    bpy.data.meshes.remove(output_mesh)
            except Exception:
                pass
        raise


def _ms_restore_shape_key_block_properties(new_block, block):
    values = dict(block.get("simple", {}) or {})
    required = (
        "slider_min",
        "slider_max",
        "interpolation",
        "vertex_group",
        "mute",
        "frame",
        "lock_shape",
    )
    for identifier in required:
        if identifier not in values:
            continue
        try:
            setattr(new_block, identifier, values[identifier])
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to restore '{identifier}' for shape key '{block['name']}': {exc}"
            ) from exc
    extras = {
        identifier: value
        for identifier, value in values.items()
        if identifier not in set(required) | {"value"}
    }
    _ms_simple_rna_restore(new_block, extras)
    if "value" in values:
        try:
            new_block.value = values["value"]
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to restore the value for shape key '{block['name']}': {exc}"
            ) from exc


def _ms_shape_key_values_equal(expected, actual):
    if isinstance(expected, float) or isinstance(actual, float):
        try:
            return abs(float(expected) - float(actual)) <= 1.0e-6
        except Exception:
            return False
    if isinstance(expected, (tuple, list)) or isinstance(actual, (tuple, list)):
        try:
            left = tuple(expected)
            right = tuple(actual)
        except Exception:
            return False
        return len(left) == len(right) and all(
            _ms_shape_key_values_equal(a, b) for a, b in zip(left, right)
        )
    return expected == actual


def _ms_verify_restored_shape_key_stack(obj, state):
    shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
    blocks = list(getattr(shape_keys, "key_blocks", ()) or ()) if shape_keys is not None else []
    expected_blocks = list(state.get("blocks", []) or [])
    if shape_keys is None or len(blocks) != len(expected_blocks):
        raise _MSShapeKeyApplyError("The rebuilt shape-key count does not match the original stack.")
    for index, (block, expected) in enumerate(zip(blocks, expected_blocks)):
        if str(block.name or "") != str(expected.get("name", "") or ""):
            raise _MSShapeKeyApplyError(
                f"Shape-key order/name mismatch at index {index}."
            )
        relative_index = int(expected.get("relative_index", 0) or 0)
        relative_index = max(0, min(relative_index, len(blocks) - 1))
        try:
            actual_relative_pointer = int(block.relative_key.as_pointer())
            expected_relative_pointer = int(blocks[relative_index].as_pointer())
        except Exception:
            actual_relative_pointer = -1
            expected_relative_pointer = -2
        if actual_relative_pointer != expected_relative_pointer:
            raise _MSShapeKeyApplyError(
                f"Relative-key relationship mismatch for '{block.name}'."
            )
        expected_simple = dict(expected.get("simple", {}) or {})
        for identifier in (
            "value",
            "slider_min",
            "slider_max",
            "interpolation",
            "vertex_group",
            "mute",
            "frame",
            "lock_shape",
        ):
            if identifier not in expected_simple or not hasattr(block, identifier):
                continue
            actual = getattr(block, identifier)
            if not _ms_shape_key_values_equal(expected_simple[identifier], actual):
                raise _MSShapeKeyApplyError(
                    f"Shape-key property '{identifier}' was not preserved for '{block.name}'."
                )
    expected_key_props = dict(state.get("shape_keys_simple", {}) or {})
    for identifier in ("use_relative", "eval_time"):
        if identifier not in expected_key_props or not hasattr(shape_keys, identifier):
            continue
        if not _ms_shape_key_values_equal(
            expected_key_props[identifier], getattr(shape_keys, identifier)
        ):
            raise _MSShapeKeyApplyError(
                f"Shape-key data property '{identifier}' was not preserved."
            )


def _ms_restore_shape_key_stack(obj, stage):
    state = stage["state"]
    coords_by_block = stage["coords"]
    blocks = state["blocks"]
    if len(coords_by_block) != len(blocks):
        raise _MSShapeKeyApplyError("The staged shape-key count changed before commit.")
    created_blocks = []
    for block, coords in zip(blocks, coords_by_block):
        try:
            new_block = obj.shape_key_add(name=block["name"], from_mix=False)
            if len(new_block.data) * 3 != len(coords):
                raise _MSShapeKeyApplyError(
                    f"Rebuilt shape key '{block['name']}' has an incompatible vertex count."
                )
            new_block.data.foreach_set("co", coords)
            created_blocks.append(new_block)
        except _MSShapeKeyApplyError:
            raise
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to rebuild shape key '{block['name']}': {exc}"
            ) from exc
    shape_keys = getattr(obj.data, "shape_keys", None)
    if shape_keys is None or len(created_blocks) != len(blocks):
        raise _MSShapeKeyApplyError("Blender did not create the complete shape-key stack.")
    try:
        shape_keys.name = state["shape_keys_name"]
    except Exception:
        pass
    _ms_simple_rna_restore(
        shape_keys,
        state.get("shape_keys_simple", {}),
        strict={"use_relative", "eval_time"},
    )
    _ms_idprop_restore(shape_keys, state.get("shape_keys_idprops", {}))
    for index, (new_block, block) in enumerate(zip(created_blocks, blocks)):
        try:
            relative_index = int(block.get("relative_index", 0) or 0)
            relative_index = max(0, min(relative_index, len(created_blocks) - 1))
            new_block.relative_key = created_blocks[relative_index]
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to restore the relative key for '{block['name']}': {exc}"
            ) from exc
        _ms_restore_shape_key_block_properties(new_block, block)
        _ms_idprop_restore(new_block, block.get("idprops", {}))
        if str(new_block.name or "") != str(block["name"] or ""):
            raise _MSShapeKeyApplyError(
                f"Shape-key name '{block['name']}' could not be restored exactly."
            )
    _ms_verify_restored_shape_key_stack(obj, state)
    _ms_shape_key_animation_restore(shape_keys, state.get("animation"))
    try:
        obj.active_shape_key_index = max(
            0, min(int(state.get("active_index", 0)), len(created_blocks) - 1)
        )
    except Exception:
        pass
    try:
        obj.show_only_shape_key = bool(state.get("show_only", False))
    except Exception:
        pass
    try:
        obj.use_shape_key_edit_mode = bool(state.get("edit_mode", False))
    except Exception:
        pass


def _ms_remove_replaced_target_mesh(old_mesh, desired_name):
    if old_mesh is None:
        return
    try:
        if int(getattr(old_mesh, "users", 0) or 0) != 0:
            return
        if getattr(old_mesh, "library", None) is not None:
            return
        if getattr(old_mesh, "override_library", None) is not None:
            return
        if getattr(old_mesh, "asset_data", None) is not None:
            return
        if bool(getattr(old_mesh, "use_fake_user", False)):
            return
        bpy.data.meshes.remove(old_mesh)
    except Exception:
        return


def _ms_commit_shape_key_modifier_result(obj, modifier, stage):
    old_mesh = getattr(obj, "data", None)
    result_mesh = stage.get("mesh")
    if old_mesh is None or result_mesh is None:
        raise _MSShapeKeyApplyError("The staged mesh is unavailable at commit time.")
    modifier_name = str(getattr(modifier, "name", "") or "")
    try:
        modifier_pointer = int(modifier.as_pointer())
    except Exception as exc:
        raise _MSShapeKeyApplyError(
            f"The target modifier identity is no longer valid: {exc}"
        ) from exc
    original_mesh_name = str(stage["state"].get("mesh_name", "") or "")
    assigned = False
    try:
        obj.data = result_mesh
        assigned = True
        _ms_restore_shape_key_stack(obj, stage)
        current_modifier = None
        for candidate in obj.modifiers:
            try:
                if int(candidate.as_pointer()) == modifier_pointer:
                    current_modifier = candidate
                    break
            except Exception:
                continue
        if current_modifier is None:
            raise _MSShapeKeyApplyError(
                f"Modifier '{modifier_name}' disappeared before the commit completed."
            )
        try:
            obj.modifiers.remove(current_modifier)
        except Exception as exc:
            raise _MSShapeKeyApplyError(
                f"Failed to remove applied modifier '{modifier_name}': {exc}"
            ) from exc
        stage["mesh"] = None
        _ms_remove_replaced_target_mesh(old_mesh, original_mesh_name)
        if original_mesh_name:
            try:
                result_mesh.name = original_mesh_name
            except Exception:
                pass
        return True
    except Exception:
        if assigned:
            try:
                obj.data = old_mesh
            except Exception:
                pass
        try:
            if int(getattr(result_mesh, "users", 0) or 0) == 0:
                bpy.data.meshes.remove(result_mesh)
        except Exception:
            pass
        raise

def _ms_apply_modifier_preserving_shape_keys(obj, modifier, context, apply_mode):
    stage = None
    try:
        stage = _ms_stage_shape_key_modifier_result(
            obj, modifier, context, apply_mode
        )
        _ms_commit_shape_key_modifier_result(obj, modifier, stage)
        return True, ""
    except _MSShapeKeyApplyError as exc:
        return False, str(exc)
    except Exception as exc:
        return False, f"Unexpected shape-key apply failure: {exc}"
    finally:
        if stage is not None:
            stage_mesh = stage.get("mesh")
            if stage_mesh is not None:
                try:
                    if int(getattr(stage_mesh, "users", 0) or 0) == 0:
                        bpy.data.meshes.remove(stage_mesh)
                except Exception:
                    pass


def _ms_format_apply_failure(context, object_name, modifier_name, reason):
    return choose_text(
        f"Failed to apply '{modifier_name}' on '{object_name}': {reason}",
        f"「{object_name}」の「{modifier_name}」を適用できませんでした: {reason}",
        context=context,
    )

class OBJECT_OT_ms_item_action (bpy .types .Operator ):
    bl_idname ="object.ms_item_action"
    bl_label ="Modifier Action"
    bl_options ={'UNDO'}
    action :bpy .props .StringProperty ()
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()
    shape_key_apply_mode :bpy .props .EnumProperty (
        name ="Shape Key Apply Mode",
        description ="Choose how the Basis is prepared before applying modifiers to all shape-key shapes",
        items =_MS_SHAPE_KEY_APPLY_MODE_ITEMS,
        default =_MS_SHAPE_KEY_APPLY_CURRENT_MIX,
        options ={'HIDDEN','SKIP_SAVE'},
    )
    shape_key_choice_confirmed :bpy .props .BoolProperty (
        default =False,
        options ={'HIDDEN','SKIP_SAVE'},
    )

    def invoke (self ,context ,event ):
        if self .action in ('APPLY','APPLY_BELOW')and _ms_apply_action_needs_shape_key_choice (
            context ,self .action ,self .modifier_name ,self .target_obj_name
        )and not bool (getattr (self ,'shape_key_choice_confirmed',False )):
            return _ms_invoke_shape_key_apply_dialog (self ,context )
        return self .execute (context )

    def draw (self ,context ):
        _ms_draw_shape_key_apply_dialog (self ,context )

    @classmethod 
    def description (cls ,context ,properties ):
        act =getattr (properties ,"action","")or ""
        if act =='APPLY':
            return pgettext (
            'Apply (bake) this modifier and remove it.\nThis is a destructive operation that makes the result permanent (use Undo to revert).\nBeginner tip: After applying, you can no longer edit the modifier settings.'


            )
        if act =='APPLY_BELOW':
            return pgettext (
            'Apply (bake) from the Base Object up to this modifier (intermediate stage).\nUse this when you want to make the lower part permanent but keep the modifiers above.\nExample: Bake the base deformations, but keep the final finishing modifiers.'


            )
        if act =='DELETE':
            return pgettext (
            'Remove this modifier from the object.\nRemove is not the same as disabling—this deletes it completely. Use when you no longer need the modifier.'

            )
        if act =='COPY':
            return pgettext (
            "Copy this modifier's settings (store in the clipboard).\nThen use 'Paste' to add the same modifier to another object.\nTip: Handy when you want to reuse the same setup on multiple objects."

            )
        if act =='CUT':
            return pgettext (
            'Copy, then remove this modifier (Cut).\nUseful when you want to move a modifier setup to another object.'

            )
        if act =='PASTE':
            return pgettext (
            'Paste the copied modifier.\nIt will be added as an independent modifier on the target, so you can edit it separately afterward.'


            )
        if act =='PASTE_INSTANCE':
            return pgettext (
            'Paste the copied modifier as an instanced (linked) modifier.\nLinked modifiers stay synchronized—editing one will update the other.'


            )
        return ""

    def execute (self ,context ):
        if self .action in ('APPLY','APPLY_BELOW')and _ms_apply_action_needs_shape_key_choice (
            context ,self .action ,self .modifier_name ,self .target_obj_name
        )and not bool (getattr (self ,'shape_key_choice_confirmed',False )):
            _ms_report_operator (self ,'ERROR',_ms_shape_key_choice_required_message (context ))
            return {'CANCELLED'}
        bridge_state = ms_stack_popup_prepare_object_mode(context)
        try:
            return self._execute_core(context)
        finally:
            ms_stack_popup_restore_mode(context, bridge_state)

    def _execute_core (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )
        main_obj =get_main_object (obj )if obj else None 
        if not obj or not main_obj :return {'CANCELLED'}
        mod =obj .modifiers .get (self .modifier_name )if self .modifier_name else None 
        _shape_key_apply_mode =str (getattr (self ,'shape_key_apply_mode',_MS_SHAPE_KEY_APPLY_BASIS )or _MS_SHAPE_KEY_APPLY_BASIS )
        _shape_key_choice_confirmed =bool (getattr (self ,'shape_key_choice_confirmed',False ))
        if self .action in ('APPLY','APPLY_BELOW')and _ms_apply_action_needs_shape_key_choice (
            context ,self .action ,self .modifier_name ,self .target_obj_name
        )and not _shape_key_choice_confirmed :
            _ms_report_operator (self ,'ERROR',_ms_shape_key_choice_required_message (context ))
            return {'CANCELLED'}

        if context .mode !='OBJECT':
            try :ms_capture_selection_to_cache_all (context )
            except Exception :
                try :ms_capture_selection_to_cache (context )
                except Exception :pass 
            try :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :pass 

        src_iid =ms_get_instance_id (mod ,obj )if mod and ms_is_instance_modifier (mod ,obj )else ""
        multi_targets =ms_get_selected_main_meshes (context )if ms_is_multi_mode (context )and self .action in ('APPLY','APPLY_BELOW','DELETE','CUT','PASTE','PASTE_INSTANCE')else [main_obj ]
        try:
            if ms_is_shape_mesh_proxy (obj):
                multi_targets =[obj ]
        except Exception:
            pass
        shared_logical_paste_name =""
        c_name =(MS_Clipboard .get ("name","")or "").strip ()

        def _ms_action_find_corresponding_modifier(target_obj):
            if not target_obj or not mod or not ms_object_has_modifier_collection(target_obj):
                return None
            try:
                if target_obj == obj:
                    return target_obj.modifiers.get(mod.name)
            except Exception:
                pass
            if src_iid:
                try:
                    return ms_find_modifier_by_instance_id(target_obj, src_iid)
                except Exception:
                    return None
            src_type =str(getattr(mod, "type", "") or "")
            src_name =str(getattr(mod, "name", "") or "")
            try:
                cand =target_obj.modifiers.get(src_name) if src_name else None
                if cand and str(getattr(cand, "type", "") or "") ==src_type:
                    return cand
            except Exception:
                pass
            src_logical =""
            try:
                src_logical =str(ms_get_logical_modifier_name(obj, mod) or "")
            except Exception:
                src_logical =""
            if src_logical:
                try:
                    for cand in target_obj.modifiers:
                        if str(getattr(cand, "type", "") or "") !=src_type:
                            continue
                        try:
                            if str(ms_get_logical_modifier_name(target_obj, cand) or "") ==src_logical:
                                return cand
                        except Exception:
                            continue
                except Exception:
                    pass
            try:
                src_index =obj.modifiers.find(src_name) if obj and src_name else -1
                if 0 <=src_index < len(target_obj.modifiers):
                    cand =target_obj.modifiers[src_index]
                    if cand and str(getattr(cand, "type", "") or "") ==src_type:
                        return cand
            except Exception:
                pass
            return None


        def _ms_base_instance_delete_targets(source_obj):
            """Return every object that must lose the row when the Base Object itself is instanced.

            Modifier-instance rows are handled separately.  This path is for the
            Base Object row's own instance relationship, including Smart Modifier
            object instances and Blender-native linked-data duplicates.
            """
            out = []
            seen = set()

            def _add(candidate):
                if not candidate or not ms_object_has_modifier_collection(candidate):
                    return
                try:
                    name = str(getattr(candidate, "name", "") or "")
                except Exception:
                    name = ""
                if not name or name in seen:
                    return
                seen.add(name)
                out.append(candidate)

            _add(source_obj)
            try:
                gid = ms_get_object_instance_id(source_obj)
            except Exception:
                gid = ""
            if gid:
                try:
                    for member in ms_iter_object_instance_members(gid, context=context):
                        _add(member)
                except Exception:
                    pass
            try:
                data = getattr(source_obj, "data", None)
            except Exception:
                data = None
            if data is not None:
                try:
                    objects = list((context.scene.objects if context is not None and hasattr(context, "scene") else bpy.data.objects) or [])
                except Exception:
                    objects = list(getattr(bpy.data, "objects", []) or [])
                for member in objects:
                    try:
                        if member is not None and getattr(member, "data", None) is data:
                            _add(member)
                    except Exception:
                        continue
            return out if len(out) > 1 else [source_obj]

        def _ms_expand_delete_targets_for_base_instances(targets):
            expanded = []
            seen = set()
            for target in list(targets or []):
                try:
                    members = _ms_base_instance_delete_targets(target)
                except Exception:
                    members = [target]
                for member in members:
                    if not member:
                        continue
                    try:
                        name = str(getattr(member, "name", "") or "")
                    except Exception:
                        name = ""
                    if not name or name in seen:
                        continue
                    seen.add(name)
                    expanded.append(member)
            return expanded or list(targets or [])

        if self .action in ('PASTE','PASTE_INSTANCE')and not MS_Clipboard .get ("is_empty",True ):
            m_suf =_MS_NAME_SUFFIX_RE .match (c_name )
            base_c =m_suf .group (1 ).strip ()if m_suf else c_name 
            if not base_c :base_c =ms_modifier_type_display_name (MS_Clipboard .get ("mod_type",""))or "Modifier"
            check_targets =list (multi_targets )
            so_name =MS_Clipboard .get ("source_obj_name","")
            if self .action =='PASTE_INSTANCE'and so_name :
                so =bpy .data .objects .get (so_name )
                if so and so not in check_targets :check_targets .append (so )
            shared_logical_paste_name =ms_next_logical_default_name_across_objects (check_targets ,base_c )

        action_pairs =[]
        affected_objects =set ()

        if self .action in ('APPLY','APPLY_BELOW','DELETE','CUT'):
            if not mod :return {'CANCELLED'}
            action_targets =list (multi_targets )if ms_is_multi_mode (context )else [obj ]
            if self .action =='DELETE':
                action_targets =_ms_expand_delete_targets_for_base_instances (action_targets )
            seen_action_pairs =set ()
            for o in action_targets :
                m =_ms_action_find_corresponding_modifier (o )
                if not m :continue
                try :key =(getattr (o ,"name","")or "",getattr (m ,"name","")or "")
                except Exception :key =("","")
                if key in seen_action_pairs :continue
                seen_action_pairs .add (key )
                action_pairs .append ((o ,m ));affected_objects .add (o )
            if not action_pairs :return {'CANCELLED'}
        elif self .action =='COPY':
            if not mod :return {'CANCELLED'}
            action_pairs =[(obj ,mod )];affected_objects .add (obj )
        elif self .action in ('PASTE','PASTE_INSTANCE'):
            for o in multi_targets :
                if not ms_object_has_modifier_collection (o):continue 
                action_pairs .append ((o ,None ));affected_objects .add (o )
        else :return {'CANCELLED'}

        # UIアクティブ階層（Base / Edit Poly 判定用）を事前保持
        pre_effective_id_by_obj ={}
        try :
            for _o in (affected_objects or set ()):
                if _o and getattr (_o ,'type','')=='MESH':
                    pre_effective_id_by_obj [_o .name ]=ms_get_ui_active_id (_o )
        except Exception :
            pre_effective_id_by_obj ={}

        paste_new_mods_by_objname ={}

        vl =getattr (context ,"view_layer",None )
        prev_active_main =get_main_object (vl .objects .active )if (vl and getattr (vl ,'objects',None )and getattr (vl .objects ,'active',None ))else None 
        # Preserve user's selection/active object (Smart Modifier operations should not clear or switch selection).
        prev_active_obj_name =""
        prev_sel_all =[]
        try :
            prev_active_obj_name =vl .objects .active .name if (vl and getattr (vl ,'objects',None )and getattr (vl .objects ,'active',None ))else ""
        except Exception :
            prev_active_obj_name =""
        try :
            prev_sel_all =[o .name for o in (getattr (context ,'selected_objects',None )or [])if o ]
        except Exception :
            prev_sel_all =[]
        prev_sel_main =set ()
        try :
            for _o0 in (getattr (context ,'selected_objects',None )or []):
                _mo0 =get_main_object (_o0 )
                if _mo0 and getattr (_mo0 ,'type','')=='MESH':
                    prev_sel_main .add (_mo0 .name )
        except Exception :prev_sel_main =set ()

        hook_states_by_obj ={}
        last_mod_by_obj ={}
        force_enter_edit_for_main =False 
        ep_enter_pairs =[]

        def _call_before_hooks (mo ,o ,m ):
            st ={}
            for pid ,s in ms_call_plugins ("before_item_action",mo ,context ,o ,m ,self .action ,MS_Clipboard ):st [pid ]=s 
            return st 

        def _call_after_hooks (mo ,o ,m ,st ):
            for p in ms_get_plugins_sorted ():
                fn =p .get ("after_item_action")
                if callable (fn ):
                    try :fn (mo ,context ,o ,m ,self .action ,MS_Clipboard ,st .get (p .get ("id","")))
                    except Exception :pass 

        for o ,m in action_pairs :
            mo =get_main_object (o )
            if mo :hook_states_by_obj [o .name ]=_call_before_hooks (mo ,o ,m )

        next_active_by_obj ={}
        for o ,m in action_pairs :
            mo =get_main_object (o )
            if not mo :continue 
            next_active_name ="BASE"
            if m and (o ==mo or ms_is_shape_mesh_proxy (o ))and self .action in ('APPLY','DELETE','CUT'):
                target_idx =o .modifiers .find (m .name )
                if target_idx >0 :next_active_name =o .modifiers [target_idx -1 ].name 
            if self .action =='APPLY_BELOW'and (o ==mo or ms_is_shape_mesh_proxy (o )):next_active_name ="BASE"
            next_active_by_obj [o .name ]=next_active_name 

        instance_paste_id =""
        instance_paste_name =None 
        instance_display_name =None 
        src_obj_for_instance =None 
        src_mod_for_instance =None 

        if self .action =='PASTE_INSTANCE':
            so_name =MS_Clipboard .get ("source_obj_name","")
            sm_name =MS_Clipboard .get ("source_mod_name","")
            src_obj_for_instance =bpy .data .objects .get (so_name )if so_name else None 
            src_mod_for_instance =src_obj_for_instance .modifiers .get (sm_name )if src_obj_for_instance and sm_name else None 
            clip_iid =MS_Clipboard .get ("source_instance_id","")
            if clip_iid :instance_paste_id =str (clip_iid )
            if not instance_paste_id and src_obj_for_instance and src_mod_for_instance :
                existing =ms_get_instance_id (src_mod_for_instance ,src_obj_for_instance )
                if existing :instance_paste_id =str (existing )
            if not instance_paste_id :instance_paste_id =ms_instance_paste_id ()
            MS_Clipboard ["source_instance_id"]=instance_paste_id 
            instance_display_name =c_name if c_name else (ms_modifier_type_display_name (MS_Clipboard .get ("mod_type",""))or "Modifier")
            instance_paste_name =instance_display_name 

        master_new_mod =None ;master_obj_for_paste =None 
        if self .action =='PASTE_INSTANCE'and src_obj_for_instance and src_mod_for_instance and instance_paste_id :
            for k ,v in (MS_Clipboard .get ("settings")or {}).items ():
                if hasattr (src_mod_for_instance ,k ):setattr (src_mod_for_instance ,k ,v )
            ms_obj_set_instance_id (src_obj_for_instance ,src_mod_for_instance .name ,instance_paste_id ,disp_name =instance_display_name )
            ms_obj_set_disp_name (src_obj_for_instance ,src_mod_for_instance .name ,instance_display_name )
            MS_Clipboard ["source_mod_name"]=src_mod_for_instance .name 
            MS_Clipboard ["source_instance_id"]=instance_paste_id 
            master_new_mod =src_mod_for_instance ;master_obj_for_paste =src_obj_for_instance 
            # --- 事前計算 (ペースト用 / Modifier_Stack.py から移植) ---
        insert_indices ={}
        master_ui_override =self .modifier_name if self .modifier_name else None 
        if self .action in ('PASTE','PASTE_INSTANCE'):
            master_obj_temp =main_obj if main_obj in multi_targets else multi_targets [0 ]
            for o in multi_targets :
                if getattr (o ,"type","")=='MESH':
                    insert_indices [o .name ]=ms_calc_target_insert_index (master_obj_temp ,o ,context ,master_ui_id_override =master_ui_override )



        _ms_apply_failures =[]
        _ms_apply_any_changed =False
        _ms_shape_key_rebased_objects =set ()

        try :
            for o ,m in action_pairs :
                mo =get_main_object (o )
                if not o or not mo :continue 
                last_mod_by_obj [o .name ]=m 
                if vl :vl .objects .active =o 
                o .select_set (True )

                if self .action in ('APPLY','APPLY_BELOW'):
                    if not m :continue 

                    def _ms_apply_one_modifier_for_action(mm):
                        nonlocal _ms_apply_any_changed
                        if not mm :return False
                        m_name =getattr (mm ,"name","")or ""
                        if not m_name :return False
                        removed_iid =""
                        removed_type =""
                        try :removed_iid =ms_get_instance_id (mm ,o )if ms_is_instance_modifier (mm ,o )else ""
                        except Exception :removed_iid =""
                        try :removed_type =getattr (mm ,"type","")or ""
                        except Exception :removed_type =""
                        _ms_apply_any_changed =True
                        failure_reason =""
                        p =ms_find_plugin_for_modifier (mm )
                        if p and callable (p .get ("cleanup_before_apply")):
                            try :
                                p .get ("cleanup_before_apply")(mo ,context ,o ,mm )
                            except Exception as exc :
                                failure_reason =choose_text (
                                    f"The modifier preparation hook failed: {exc}",
                                    f"モディファイア適用前の準備処理に失敗しました: {exc}",
                                    context =context,
                                )
                        _vg =""
                        try :_vg =_ms_auto_sel_get_vg_from_modifier (mm )
                        except Exception :_vg =""
                        applied_ok =False
                        removed_now =False
                        try :removed_now =(o .modifiers .get (m_name )is None )
                        except Exception :removed_now =False
                        if removed_now and not failure_reason :
                            applied_ok =True
                        elif not failure_reason and _ms_object_has_shape_key_blocks (o):
                            try :_object_key =int (o .as_pointer ())
                            except Exception :_object_key =str (getattr (o ,'name','')or '')
                            effective_mode =_shape_key_apply_mode
                            if effective_mode ==_MS_SHAPE_KEY_APPLY_CURRENT_MIX and _object_key in _ms_shape_key_rebased_objects :
                                effective_mode =_MS_SHAPE_KEY_APPLY_BASIS
                            if effective_mode not in _MS_SHAPE_KEY_APPLY_MODES :
                                failure_reason =_ms_shape_key_choice_required_message (context )
                            else :
                                applied_ok ,shape_key_error =_ms_apply_modifier_preserving_shape_keys (
                                    o ,mm ,context ,effective_mode
                                )
                                if not applied_ok :
                                    failure_reason =str (shape_key_error or choose_text (
                                        'The shape-key reconstruction failed.',
                                        'シェイプキーの再構築に失敗しました。',
                                        context =context,
                                    ))
                                elif effective_mode ==_MS_SHAPE_KEY_APPLY_CURRENT_MIX :
                                    _ms_shape_key_rebased_objects .add (_object_key )
                            try :removed_now =(o .modifiers .get (m_name )is None )
                            except Exception :removed_now =applied_ok
                        elif not failure_reason :
                            try :mm .show_viewport =True ;mm .show_render =True
                            except Exception :pass
                            try :
                                _res =bpy .ops .object .modifier_apply ('EXEC_DEFAULT', False, modifier =m_name )
                                applied_ok =('FINISHED'in _res )if _res is not None else True
                                if not applied_ok :
                                    failure_reason =choose_text (
                                        f"Blender returned {sorted (_res )if _res is not None else 'CANCELLED'}.",
                                        f"Blenderが{sorted (_res )if _res is not None else 'CANCELLED'}を返しました。",
                                        context =context,
                                    )
                            except Exception as exc :
                                applied_ok =False
                                failure_reason =choose_text (
                                    f"Blender raised an exception while applying the modifier: {exc}",
                                    f"モディファイア適用中にBlender例外が発生しました: {exc}",
                                    context =context,
                                )
                            try :removed_now =(o .modifiers .get (m_name )is None )
                            except Exception :removed_now =applied_ok
                        if applied_ok or removed_now :
                            _ms_apply_any_changed =True
                            try :ms_obj_clear_instance_id (o ,m_name )
                            except Exception :pass
                            try :ms_obj_cleanup_instance_map (o )
                            except Exception :pass
                            if removed_iid :
                                try :ms_instance_post_remove_cleanup (removed_iid ,context =context )
                                except Exception :pass
                            if removed_type :
                                try :ms_normalize_default_modifier_names (o ,removed_type )
                                except Exception :pass
                            try :_ms_auto_sel_cleanup_vgroup_if_unused (o ,_vg )
                            except Exception :pass 
                            return True
                        if not failure_reason :
                            failure_reason =choose_text (
                                'The modifier was not applied and remained in the stack.',
                                'モディファイアを適用できず、スタック内に残りました。',
                                context =context,
                            )
                        _ms_apply_failures .append (_ms_format_apply_failure (
                            context ,str (getattr (o ,'name','')or ''),m_name ,failure_reason
                        ))
                        return False

                    pair_apply_ok =True
                    target_idx =o .modifiers .find (m .name )
                    if target_idx <0 :
                        pair_apply_ok =False
                        _ms_apply_failures .append (_ms_format_apply_failure (
                            context ,str (getattr (o ,'name','')or ''),str (getattr (m ,'name','')or ''),
                            choose_text ('The target modifier is no longer in the stack.','対象モディファイアがスタック内に存在しません。',context =context )
                        ))
                    elif self .action =='APPLY_BELOW':
                        mod_names_to_apply =[mm .name for mm in o .modifiers [:target_idx +1 ]if not ms_modifier_is_internal_stack_helper (mm )]
                        if not mod_names_to_apply :
                            pair_apply_ok =False
                            _ms_apply_failures .append (_ms_format_apply_failure (
                                context ,str (getattr (o ,'name','')or ''),str (getattr (m ,'name','')or ''),
                                choose_text ('No applicable modifier was found in the requested range.','指定範囲に適用可能なモディファイアがありません。',context =context )
                            ))
                        for m_name in mod_names_to_apply :
                            if not pair_apply_ok :break
                            mm =o .modifiers .get (m_name )
                            if not mm :
                                pair_apply_ok =False
                                _ms_apply_failures .append (_ms_format_apply_failure (
                                    context ,str (getattr (o ,'name','')or ''),m_name ,
                                    choose_text ('The modifier disappeared before it could be applied.','適用前にモディファイアが見つからなくなりました。',context =context )
                                ))
                                break
                            if not _ms_apply_one_modifier_for_action (mm ):
                                pair_apply_ok =False
                                break
                    else :
                        pair_apply_ok =_ms_apply_one_modifier_for_action (m )
                    if pair_apply_ok and mo and (o ==mo or ms_is_shape_mesh_proxy (o )):
                        mo ["ui_active_item"]=next_active_by_obj .get (o .name ,"BASE")

                elif self .action in ('DELETE','CUT'):
                    if not m :continue 
                    if self .action =='CUT'and o ==obj :
                        clear_clipboard_meshes ()
                        MS_Clipboard ["is_empty"]=False 
                        MS_Clipboard ["name"]=ms_get_logical_modifier_name (o ,m )or m .name 
                        MS_Clipboard ["mod_type"]=m .type 
                        MS_Clipboard ["settings"]={}
                        MS_Clipboard ["payload"]={}
                        MS_Clipboard ["plugin_id"]=""
                        MS_Clipboard ["source_obj_name"]=o .name 
                        MS_Clipboard ["source_mod_name"]=m .name 
                        MS_Clipboard ["source_instance_id"]=ms_get_instance_id (m ,o )
                        MS_Clipboard ["enabled_state"]=get_mod_enabled_state (o ,m .name )
                        MS_Clipboard ["viewport_state"]=get_mod_viewport_state (o ,m .name )
                        p =ms_find_plugin_for_modifier (m )
                        if p :
                            MS_Clipboard ["plugin_id"]=p .get ("id","")or ""
                            if callable (p .get ("clipboard_copy")):
                                payload =p .get ("clipboard_copy")(mo ,context ,o ,m )or {}
                                if isinstance (payload ,dict ):MS_Clipboard ["payload"]=payload 
                        if not MS_Clipboard ["payload"]:
                            for prop in m .bl_rna .properties :
                                if not prop .is_readonly and prop .identifier not in {"rna_type","name","type"}:
                                    MS_Clipboard ["settings"][prop .identifier ]=getattr (m ,prop .identifier )

                    old_mod_name =m .name 
                    removed_iid =ms_get_instance_id (m ,o )if ms_is_instance_modifier (m ,o )else ""
                    removed_type =m .type 
                    removed_vg =""
                    try :removed_vg =_ms_auto_sel_get_vg_from_modifier (m )
                    except Exception :removed_vg =""
                    p =ms_find_plugin_for_modifier (m )
                    if p and callable (p .get ("cleanup_before_remove")):
                        p .get ("cleanup_before_remove")(mo ,context ,o ,m )

                    ms_obj_clear_instance_id (o ,old_mod_name )
                    o .modifiers .remove (m )
                    ms_obj_cleanup_instance_map (o )
                    try :_ms_auto_sel_cleanup_vgroup_if_unused (o ,removed_vg )
                    except Exception :pass 

                    if removed_iid :ms_instance_post_remove_cleanup (removed_iid ,context =context )
                    if removed_type :ms_normalize_default_modifier_names (o ,removed_type )

                    if mo and (o ==mo or ms_is_shape_mesh_proxy (o )):mo ["ui_active_item"]=next_active_by_obj .get (o .name ,"BASE")

                elif self .action =='COPY':
                    if not m :continue 
                    clear_clipboard_meshes ()
                    MS_Clipboard ["is_empty"]=False 
                    MS_Clipboard ["name"]=ms_get_logical_modifier_name (o ,m )or m .name 
                    MS_Clipboard ["mod_type"]=m .type 
                    MS_Clipboard ["settings"]={}
                    MS_Clipboard ["payload"]={}
                    MS_Clipboard ["plugin_id"]=""
                    MS_Clipboard ["source_obj_name"]=o .name 
                    MS_Clipboard ["source_mod_name"]=m .name 
                    MS_Clipboard ["source_instance_id"]=ms_get_instance_id (m ,o )
                    MS_Clipboard ["enabled_state"]=get_mod_enabled_state (o ,m .name )
                    MS_Clipboard ["viewport_state"]=get_mod_viewport_state (o ,m .name )
                    p =ms_find_plugin_for_modifier (m )
                    if p :
                        MS_Clipboard ["plugin_id"]=p .get ("id","")or ""
                        if callable (p .get ("clipboard_copy")):
                            payload =p .get ("clipboard_copy")(mo ,context ,o ,m )or {}
                            if isinstance (payload ,dict ):MS_Clipboard ["payload"]=payload 
                    if not MS_Clipboard ["payload"]:
                        for prop in m .bl_rna .properties :
                            if not prop .is_readonly and prop .identifier not in {"rna_type","name","type"}:
                                MS_Clipboard ["settings"][prop .identifier ]=getattr (m ,prop .identifier )

                elif self .action in ('PASTE','PASTE_INSTANCE'):
                    if MS_Clipboard .get ("is_empty",True ):continue 
                    insert_idx =insert_indices .get (o .name ,len (o .modifiers ))
                    order =ms_get_stack_order ()
                    ui_insert_pos =(len (o .modifiers )-insert_idx )if order =='BOTTOM_UP'else insert_idx 
                    new_mod_name =None 
                    pid =MS_Clipboard .get ("plugin_id","")
                    if pid :
                        p =_ms_plugins_dict ().get (pid )
                        if p and callable (p .get ("clipboard_paste")):
                            new_mod_name =p .get ("clipboard_paste")(mo ,context ,o ,insert_idx ,MS_Clipboard )
                    logical_name =instance_display_name if self .action =='PASTE_INSTANCE'else shared_logical_paste_name 
                    if not new_mod_name :
                        try :
                            new_mod =o .modifiers .new (name =logical_name ,type =MS_Clipboard ["mod_type"])
                            for k ,v in (MS_Clipboard .get ("settings")or {}).items ():
                                if hasattr (new_mod ,k ):setattr (new_mod ,k ,v )
                            new_mod_name =new_mod .name 
                        except Exception :pass 
                    if new_mod_name :
                        nm =o .modifiers .get (new_mod_name )
                        if nm :
                            try :
                                if ms_plugin_requires_bottom_insert (o ,nm ):
                                    insert_idx ,ui_insert_pos =ms_calc_insert_index_bottom (o ,pre_add =False )
                            except Exception :pass 

                            ms_obj_set_disp_name (o ,new_mod_name ,logical_name )
                            safe_move_modifier (o ,new_mod_name ,insert_idx )

                            if self .action =='PASTE_INSTANCE':
                                ms_obj_set_instance_id (o ,nm .name ,instance_paste_id ,disp_name =instance_display_name )
                                if master_new_mod is None :
                                    master_new_mod =nm ;master_obj_for_paste =o 
                                    # Paste should inherit enabled/viewport states from the source.
                            _en =bool (MS_Clipboard .get ("enabled_state",True ))
                            _vp =bool (MS_Clipboard .get ("viewport_state",True ))
                            set_mod_enabled_state (o ,nm .name ,_en )
                            set_mod_viewport_state (o ,nm .name ,_vp )

                            # Auto vertex group from selection (Base / Edit Poly only)
                            try :
                                _eff =pre_effective_id_by_obj .get (o .name ,"BASE")
                                if self .action =='PASTE_INSTANCE':
                                    _ms_auto_sel_try_apply_single (o ,o ,nm ,_eff ,vg_seed =instance_paste_id )
                                else :
                                    _ms_auto_sel_try_apply_single (o ,o ,nm ,_eff )
                                paste_new_mods_by_objname [o .name ]=nm .name 
                            except Exception :
                                pass 

                            _ui_owner =get_main_object (o )or o
                            _ui_owner ["ui_active_item"]=nm .name 
                            _ui_owner ["ui_active_row"]=ui_insert_pos 
                            ms_set_ui_active_index (_ui_owner ,o .modifiers .find (nm .name ))
                            o .modifiers .active =nm 
                            try :
                                if ms_is_multi_mode (context )and ms_plugin_is_edit_source (o ,nm ):
                                    ep_enter_pairs .append ((o ,nm .name ))
                            except Exception :pass 
                            try :
                                if o ==main_obj and ms_plugin_is_edit_source (o ,nm ):
                                    force_enter_edit_for_main =True 
                            except Exception :pass 
        finally :
        # Restore (ensure) original selection without deselecting anything.
            try :
                vlr =getattr (context ,'view_layer',None )
                if vlr :
                    for _n in prev_sel_all :
                        try :
                            _o =bpy .data .objects .get (_n )
                            if _o :
                                try :
                                    _o .hide_set (False )
                                    if _ms_is_internal_visibility_helper_object (_o):
                                        if hasattr (_o ,'hide_viewport') :_o .hide_viewport =False
                                        if hasattr (_o ,'hide_select') :_o .hide_select =False
                                except Exception :
                                    pass 
                                _o .select_set (True )
                        except Exception :
                            pass 
                    if prev_active_obj_name :
                        try :
                            _ao =bpy .data .objects .get (prev_active_obj_name )
                            if _ao :vlr .objects .active =_ao 
                        except Exception :
                            pass 
            except Exception :
                pass 
            try :
                if main_obj :
                    try :main_obj .hide_set (False )
                    except Exception :pass
                    try :
                        if _ms_is_internal_visibility_helper_object (main_obj):
                            if hasattr (main_obj ,'hide_select') :main_obj .hide_select =False
                            if hasattr (main_obj ,'hide_viewport') :main_obj .hide_viewport =False
                    except Exception :pass
                    main_obj .select_set (True )
            except ReferenceError :pass 
            if vl :
                try :
                    if prev_active_main and prev_active_main .name in prev_sel_main :
                        vl .objects .active =prev_active_main 
                    elif main_obj :
                        vl .objects .active =main_obj 
                    else :
                        sel =context .selected_objects 
                        if sel :vl .objects .active =sel [0 ]
                except ReferenceError :
                    sel =context .selected_objects 
                    if sel :vl .objects .active =sel [0 ]
            _ms_set_shared_lock (False )
            _MS_ACTION_LOCK =False 

        if self .action =='PASTE_INSTANCE'and master_new_mod and instance_paste_id :
            try:
                _src_vp ,_src_rd ,_src_edit ,_src_cage =_ms_get_modifier_manual_display_for_sync (master_obj_for_paste ,master_new_mod ,context =context )
            except Exception:
                _src_vp ,_src_rd ,_src_edit ,_src_cage =True ,True ,False ,False
            for o ,m in ms_iter_instance_members (instance_paste_id ):
                if master_obj_for_paste and o ==master_obj_for_paste and m ==master_new_mod :continue 
                old_name =m .name 
                ms_copy_modifier_settings (master_new_mod ,m ,include_name =False ,skip_display_flags =True )
                _ms_set_modifier_display_state_for_instance_sync (o ,m ,viewport =_src_vp ,render =_src_rd ,editmode =_src_edit ,cage =_src_cage ,context =context )
                ms_obj_rename_instance_key (o ,old_name ,m .name )
                ms_obj_set_instance_id (o ,m .name ,instance_paste_id ,disp_name =instance_display_name )

                # Ensure shared selection vertex group exists across all members after instance paste sync
        if self .action =='PASTE_INSTANCE'and instance_paste_id :
            try :
                _ms_auto_sel_apply_instance_for_new_mods (instance_paste_id ,paste_new_mods_by_objname ,pre_effective_id_by_obj )
            except Exception :
                pass 


        if self .action =='DELETE':
            try:
                _synced_gids =set ()
                for _o_sync in list (affected_objects or []):
                    try:
                        _gid_sync =ms_get_object_instance_id (_o_sync )
                    except Exception:
                        _gid_sync =""
                    if _gid_sync:
                        _synced_gids .add (str (_gid_sync ))
                for _gid_sync in _synced_gids:
                    try:
                        _members_sync =[m for m in ms_iter_object_instance_members (_gid_sync ,context =context )if m is not None]
                        ms_mark_object_instance_targets_synced (_members_sync ,context =context )
                    except Exception:
                        pass
            except Exception:
                pass

        for o in affected_objects :
            try:
                mo =get_main_object (o )
                _oname =o .name
            except ReferenceError:
                continue
            except Exception:
                mo =None ;_oname =""
            if mo :_call_after_hooks (mo ,o ,last_mod_by_obj .get (_oname ),hook_states_by_obj .get (_oname ,{}))
        done =set ()
        for o in affected_objects :
            try:
                mo =get_main_object (o )
                _moname =mo .name if mo else ""
            except ReferenceError:
                continue
            except Exception:
                mo =None ;_moname =""
            if mo and _moname not in done :
                done .add (_moname )
                ms_apply_state_post_action (context ,mo ,interactive_default =(not ms_is_multi_mode (context )and not src_iid ))

        if force_enter_edit_for_main and main_obj and (not ms_is_multi_mode (context )):
            try :apply_modifier_stack_state (main_obj ,context ,interactive =True )
            except Exception :pass 

        if ms_is_multi_mode (context )and self .action in ('PASTE','PASTE_INSTANCE')and ep_enter_pairs :
            try :
                dn =bpy .app .driver_namespace 
                fn_map =dn .get ('_EP_ENTER_EDIT_MULTI_MAP_V1')
                if callable (fn_map ):fn_map (context ,ep_enter_pairs ,active_main =main_obj )
                else :
                    fn =dn .get ('_EP_ENTER_EDIT_MULTI_V1')
                    if callable (fn ):
                        common =ep_enter_pairs [0 ][1 ]
                        fn (context ,[p [0 ]for p in ep_enter_pairs ],common ,active_main =main_obj )
            except Exception :pass 
        if _ms_apply_failures :
            _ms_report_operator (self ,'ERROR','\n'.join (str (item )for item in _ms_apply_failures if item ))
            return {'FINISHED'}if _ms_apply_any_changed else {'CANCELLED'}
        return {'FINISHED'}



class _MSDirectItemActionRequest:
    """Lightweight request used by compound Smart Modifier operators.

    Calling ``OBJECT_OT_ms_item_action`` through ``bpy.ops`` would create a
    nested operator boundary.  Compound commands use this request to execute
    the already-validated core directly, so the outer user command owns the
    single Undo/Redo step.
    """

    __slots__ = (
        "action",
        "modifier_name",
        "target_obj_name",
        "shape_key_apply_mode",
        "shape_key_choice_confirmed",
        "_report_callback",
    )

    def __init__(
        self,
        action,
        modifier_name,
        target_obj_name,
        *,
        shape_key_apply_mode=_MS_SHAPE_KEY_APPLY_BASIS,
        shape_key_choice_confirmed=False,
        report_callback=None,
    ):
        self.action = str(action or "")
        self.modifier_name = str(modifier_name or "")
        self.target_obj_name = str(target_obj_name or "")
        self.shape_key_apply_mode = str(shape_key_apply_mode or _MS_SHAPE_KEY_APPLY_BASIS)
        self.shape_key_choice_confirmed = bool(shape_key_choice_confirmed)
        self._report_callback = report_callback

    def report(self, levels, message):
        callback = self._report_callback
        if callable(callback):
            callback(set(levels or {"ERROR"}), str(message or ""))


def _ms_run_item_action_direct(
    context,
    *,
    action,
    modifier_name="",
    target_obj_name="",
    shape_key_apply_mode=_MS_SHAPE_KEY_APPLY_BASIS,
    shape_key_choice_confirmed=False,
    report_callback=None,
):
    request = _MSDirectItemActionRequest(
        action,
        modifier_name,
        target_obj_name,
        shape_key_apply_mode=shape_key_apply_mode,
        shape_key_choice_confirmed=shape_key_choice_confirmed,
        report_callback=report_callback,
    )
    return OBJECT_OT_ms_item_action._execute_core(request, context)


class OBJECT_OT_ms_item_menu_call (bpy .types .Operator ):
    bl_idname ="object.ms_item_menu_call"
    bl_label ='Modifier Menu'
    bl_description ='Open this modifier item menu (see tooltip for details)'
    bl_options = set()
    _sms_no_undo = True
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return choose_text (
        "Open the action menu for this modifier.\nFrom here you can apply, apply up to this row, release this row from an instance group, delete, copy, cut, paste, rename, or select linked instance members.\nBeginner note: Apply makes the result permanent; Release Instance only breaks the shared instance link while keeping the current settings.",
        "このモディファイア行の操作メニューを開きます。\nここから、適用、ここまでを適用、この行のインスタンス解除、削除、コピー、カット、貼り付け、リネーム、リンク中インスタンスの選択を実行できます。\n初心者向け補足：適用は結果を確定します。インスタンス解除は現在の設定を保ったまま共有リンクだけを切り離します。",
        context =context
        )
    def execute (self ,context ):
        context .window_manager .ms_target_mod =self .modifier_name 
        context .window_manager .ms_target_obj =self .target_obj_name 
        bpy .ops .wm .call_menu (name ="VIEW3D_MT_ms_item_menu")
        return {'FINISHED'}

class OBJECT_OT_ms_select_instance_members (bpy .types .Operator ):
    bl_idname ="object.ms_select_instance_members"
    bl_label ='Select Instances'
    bl_description ='Select objects in the same instance (linked) group (see tooltip for details)'
    bl_options ={'UNDO'}
    instance_id :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return pgettext (
        "Select all objects that share the same instanced/linked group.\nWhat 'Instance/Link' means: multiple objects share the same modifier settings.\nUse this when you want to quickly select and edit all related objects at once."






        )
    def execute (self ,context ):
        bridge_state = ms_stack_popup_prepare_object_mode(context)
        result = {'CANCELLED'}
        try:
            result = self._execute_core(context)
            return result
        finally:
            ms_stack_popup_restore_mode(context, bridge_state, use_current_selection=bool(result and 'FINISHED' in result))

    def _execute_core (self ,context ):
        iid =self .instance_id or ""
        if not iid :return {'CANCELLED'}
        vl =getattr (context ,"view_layer",None )
        if not vl :return {'CANCELLED'}
        # Do not clear existing selection; extend selection instead.
        first =None 
        for o in vl .objects :
            if not ms_object_supports_modifier_stack (o):continue 
            if ms_find_modifier_by_instance_id (o ,iid )is not None :
                try :o .hide_set (False )
                except Exception :pass
                try :
                    if _ms_is_internal_visibility_helper_object (o):
                        if hasattr (o ,'hide_viewport') :o .hide_viewport =False
                        if hasattr (o ,'hide_select') :o .hide_select =False
                except Exception :pass
                o .select_set (True )
                if first is None :first =o 
        if first :vl .objects .active =first 
        return {'FINISHED'}

class OBJECT_OT_ms_make_modifier_unique (bpy .types .Operator ):
    bl_idname ="object.ms_make_modifier_unique"
    bl_label ='Release Instance'
    bl_description ='Release the instance link for this modifier and make this row independent.'
    bl_options ={'UNDO'}
    modifier_name :bpy .props .StringProperty ()
    target_obj_name :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return choose_text (
        "Release this modifier instance.\nUse this when only the modifier row opened from this menu should stop sharing its instanced settings with other objects.\nThe current modifier settings are kept, and later changes affect only this object/row.",
        "このモディファイア行のインスタンスを解除します。\nこのメニューを開いた行だけを、他オブジェクトと共有しているインスタンス設定から切り離したい場合に使います。\n現在のモディファイア設定は維持され、以後の変更はこのオブジェクト / この行だけに反映されます。",
        context =context 
        )

    def execute (self ,context ):
        bridge_state = ms_stack_popup_prepare_object_mode(context)
        try:
            return self._execute_core(context)
        finally:
            ms_stack_popup_restore_mode(context, bridge_state)

    def _execute_core (self ,context ):
        obj =bpy .data .objects .get (self .target_obj_name )or get_main_object (getattr (context ,'active_object',None ))
        mod =obj .modifiers .get (self .modifier_name )if obj and self .modifier_name else None 
        if not obj or not mod :
            return {'CANCELLED'}
        if not ms_make_modifier_unique (obj ,mod ,context =context ):
            self .report ({'WARNING'},choose_text ('Could not release this modifier instance.','このモディファイアのインスタンスを解除できませんでした。',context =context ))
            return {'CANCELLED'}
        ms_apply_state_post_action (context ,obj ,interactive_default =False )
        return {'FINISHED'}



def _ms_resolve_stack_quick_target(context, target_obj_name="", modifier_name=""):
    obj = bpy.data.objects.get(str(target_obj_name or "")) if target_obj_name else getattr(context, 'active_object', None)
    if obj is None:
        obj = getattr(context, 'active_object', None)
    main_obj = get_main_object(obj) if obj else None
    if not main_obj:
        return None, None, None
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    mod_name = str(modifier_name or "")
    if not mod_name:
        try:
            mod_name = str(ms_get_ui_active_id(main_obj) or "")
        except Exception:
            mod_name = ""
    if mod_name == "BASE":
        mod_name = ""
    mod = None
    try:
        if mod_name and ms_object_has_modifier_collection(stack_obj):
            mod = stack_obj.modifiers.get(mod_name)
    except Exception:
        mod = None
    return main_obj, stack_obj, mod


def _ms_resolve_active_stack_level_items(context):
    """Return (main_obj, stack_obj, visible_items, current_pos) for stack-level key navigation.

    ``visible_items`` follows the same visual order used by the Smart Modifier
    stack panel, including Bottom-Up display mode.  This keeps keyboard level
    movement equivalent to clicking the adjacent visible stack row.
    """
    candidates = []

    def _add_candidate(candidate):
        if candidate is None:
            return
        try:
            if candidate not in candidates:
                candidates.append(candidate)
        except Exception:
            candidates.append(candidate)

    try:
        _add_candidate(getattr(getattr(getattr(context, 'view_layer', None), 'objects', None), 'active', None))
    except Exception:
        pass
    for attr_name in ('active_object', 'object', 'edit_object'):
        try:
            _add_candidate(getattr(context, attr_name, None))
        except Exception:
            pass
    try:
        for selected_obj in getattr(context, 'selected_objects', ()) or ():
            _add_candidate(selected_obj)
    except Exception:
        pass

    main_obj = None
    for obj in candidates:
        try:
            resolved = get_main_object(obj) if obj else None
        except Exception:
            resolved = obj
        try:
            if resolved and ms_object_supports_modifier_stack(resolved):
                main_obj = resolved
                break
        except Exception:
            pass
    if not main_obj:
        return None, None, [], -1

    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
    except Exception:
        stack_obj = main_obj

    modifier_names = []
    try:
        if ms_object_has_modifier_collection(stack_obj):
            for mod in stack_obj.modifiers:
                if ms_modifier_is_internal_stack_helper(mod):
                    continue
                modifier_names.append(mod.name)
    except Exception:
        modifier_names = []

    try:
        order = str(ms_get_stack_order() or 'TOP_DOWN')
    except Exception:
        order = 'TOP_DOWN'
    if order == 'BOTTOM_UP':
        items = list(reversed(modifier_names)) + ['BASE']
    else:
        items = ['BASE'] + list(modifier_names)

    try:
        active_id = str(ms_get_ui_active_id(main_obj) or 'BASE')
    except Exception:
        active_id = str(main_obj.get('ui_active_item', 'BASE') or 'BASE')
    if active_id not in items:
        active_id = 'BASE'

    try:
        pos = items.index(active_id)
    except Exception:
        pos = 0
    return main_obj, stack_obj, items, pos


def _ms_stack_level_ui_row_index(stack_obj, target_name):
    if target_name == 'BASE':
        try:
            return len([m for m in ms_get_object_modifiers(stack_obj) if not ms_modifier_is_internal_stack_helper(m)]) if str(ms_get_stack_order() or 'TOP_DOWN') == 'BOTTOM_UP' else -1
        except Exception:
            return -1
    try:
        names = [m.name for m in ms_get_object_modifiers(stack_obj) if not ms_modifier_is_internal_stack_helper(m)]
    except Exception:
        names = []
    try:
        order = str(ms_get_stack_order() or 'TOP_DOWN')
    except Exception:
        order = 'TOP_DOWN'
    if order == 'BOTTOM_UP':
        try:
            return list(reversed(names)).index(target_name)
        except Exception:
            return -1
    try:
        return names.index(target_name)
    except Exception:
        return -1


def _ms_execute_relative_stack_level(context, direction):
    """Use the same deterministic level-switch request as a stack-row click."""
    main_obj, stack_obj, items, pos = _ms_resolve_active_stack_level_items(context)
    if not main_obj or not items or pos < 0:
        return {'CANCELLED'}
    direction = str(direction or 'UP').upper()
    delta = 1 if direction == 'DOWN' else -1
    new_pos = max(0, min(len(items) - 1, int(pos) + delta))
    if new_pos == int(pos):
        return {'CANCELLED'}
    target = items[new_pos]
    ui_row = _ms_stack_level_ui_row_index(stack_obj, target)

    # Multi-object Edit Mode uses the existing row-click implementation because it
    # resolves per-object instance ordinals.  Single-object Object/Edit Mode goes
    # directly through the exact same tokenized queue used by a row click, avoiding
    # nested bpy.ops dispatch from manually registered keymaps.
    if ms_is_multi_mode(context):
        try:
            return bpy.ops.object.ms_switch_level(
                'EXEC_DEFAULT',
                target_mod_name=target,
                target_obj_name=main_obj.name,
                ui_row_index=int(ui_row),
            )
        except Exception:
            pass

    clicked_plugin_id = ''
    if target != 'BASE':
        try:
            clicked_mod = stack_obj.modifiers.get(target)
            clicked_plugin = ms_find_plugin_for_modifier(clicked_mod) if clicked_mod else None
            if clicked_plugin:
                clicked_plugin_id = str(clicked_plugin.get('id') or '')
        except Exception:
            clicked_plugin_id = ''
    if clicked_plugin_id:
        _ms_request_plugin_live_runtime(clicked_plugin_id)

    try:
        want_edit_mode = bool(str(getattr(context, 'mode', 'OBJECT')).startswith('EDIT'))
        _ms_queue_level_switch(main_obj, target, int(ui_row), want_edit_mode)
        return {'FINISHED'}
    except Exception:
        pass

    # Last-resort equivalent state application for unusual non-window contexts.
    try:
        main_obj['ui_active_item'] = target
        main_obj['ui_active_row'] = int(ui_row)
        if target == 'BASE':
            ms_set_ui_active_index(main_obj, -1)
        else:
            active_index = stack_obj.modifiers.find(target)
            ms_set_ui_active_index(main_obj, active_index)
            try:
                mod = stack_obj.modifiers.get(target)
                if mod:
                    stack_obj.modifiers.active = mod
            except Exception:
                pass
        apply_modifier_stack_state(main_obj, context, interactive=False)
        return {'FINISHED'}
    except Exception:
        return {'CANCELLED'}


class OBJECT_OT_ms_activate_stack_level_relative (bpy.types.Operator):
    bl_idname = 'object.ms_activate_stack_level_relative'
    bl_label = 'Activate Stack Level Relative'
    bl_description = 'Switch the active Smart Modifier stack level one step up or down without changing modifier order.'
    bl_options = {'UNDO'}
    direction: bpy.props.StringProperty(default='UP')

    @classmethod
    def poll(cls, context):
        try:
            main_obj, _stack_obj, items, _pos = _ms_resolve_active_stack_level_items(context)
            return bool(main_obj and items)
        except Exception:
            return False

    @classmethod
    def description(cls, context, properties):
        direction = str(getattr(properties, 'direction', 'UP') or 'UP').upper()
        if direction == 'DOWN':
            return choose_text(
                'Switch the active Smart Modifier stack level one row downward. It works while an object is selected in Object Mode or Edit Mode, and it applies Modifier Auto Disable / Show End Result through the same deterministic transition used when clicking a stack row.',
                'Smart Modifierスタックのアクティブ階層を1段下へ切り替えます。オブジェクト選択中のオブジェクトモード・編集モードで動作し、スタック行クリックと同一の確定的な切り替え処理で「モディファイア自動無効」「最終結果を表示」を反映します。',
                context=context,
            )
        return choose_text(
            'Switch the active Smart Modifier stack level one row upward. It works while an object is selected in Object Mode or Edit Mode, and it applies Modifier Auto Disable / Show End Result through the same deterministic transition used when clicking a stack row.',
            'Smart Modifierスタックのアクティブ階層を1段上へ切り替えます。オブジェクト選択中のオブジェクトモード・編集モードで動作し、スタック行クリックと同一の確定的な切り替え処理で「モディファイア自動無効」「最終結果を表示」を反映します。',
            context=context,
        )

    def execute(self, context):
        return _ms_execute_relative_stack_level(context, self.direction)


class OBJECT_OT_ms_active_stack_level_up (bpy.types.Operator):
    bl_idname = 'object.ms_active_stack_level_up'
    bl_label = 'Active Stack Level Up'
    bl_description = 'Switch the active Smart Modifier stack level one step up.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return OBJECT_OT_ms_activate_stack_level_relative.poll(context)

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Switch the active Smart Modifier stack level one row upward and apply Modifier Auto Disable / Show End Result exactly like clicking that row. Register this in Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode.',
            'Smart Modifierスタックのアクティブ階層を1段上へ切り替え、対象行をクリックした時と同じように「モディファイア自動無効」「最終結果を表示」を適用します。プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへの登録を推奨します。',
            context=context,
        )

    def execute(self, context):
        return _ms_execute_relative_stack_level(context, 'UP')


class OBJECT_OT_ms_active_stack_level_down (bpy.types.Operator):
    bl_idname = 'object.ms_active_stack_level_down'
    bl_label = 'Active Stack Level Down'
    bl_description = 'Switch the active Smart Modifier stack level one step down.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return OBJECT_OT_ms_activate_stack_level_relative.poll(context)

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Switch the active Smart Modifier stack level one row downward and apply Modifier Auto Disable / Show End Result exactly like clicking that row. Register this in Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode.',
            'Smart Modifierスタックのアクティブ階層を1段下へ切り替え、対象行をクリックした時と同じように「モディファイア自動無効」「最終結果を表示」を適用します。プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モードへの登録を推奨します。',
            context=context,
        )

    def execute(self, context):
        return _ms_execute_relative_stack_level(context, 'DOWN')


class OBJECT_OT_ms_move_active_modifier (bpy .types .Operator ):
    bl_idname ="object.ms_move_active_modifier"
    bl_label ="Move Active Modifier"
    bl_description ="Move the active modifier row up or down in the Smart Modifier stack."
    bl_options ={'UNDO'}
    direction :bpy .props .StringProperty (default ="UP")
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        direction =str (getattr (properties ,'direction','UP')or 'UP')
        if direction =='DOWN':
            return choose_text (
            'Move the active modifier one step down. The operation uses the same safe stack logic as the row menu, so instanced modifiers move together when required.',
            'アクティブなモディファイアを1段下へ移動します。行メニューと同じ安全なスタック処理を使うため、必要な場合はインスタンス化されたモディファイアも一緒に移動します。',
            context =context )
        return choose_text (
        'Move the active modifier one step up. The operation uses the same safe stack logic as the row menu, so instanced modifiers move together when required.',
        'アクティブなモディファイアを1段上へ移動します。行メニューと同じ安全なスタック処理を使うため、必要な場合はインスタンス化されたモディファイアも一緒に移動します。',
        context =context )

    def execute (self ,context ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod:
            return {'CANCELLED'}
        try:
            context .window_manager .ms_target_obj =stack_obj .name
            context .window_manager .ms_target_mod =mod .name
        except Exception:
            return {'CANCELLED'}
        try:
            _ms_popup_do_move (self ,context ,str (self .direction or 'UP'))
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}


class OBJECT_OT_ms_duplicate_active_modifier (bpy .types .Operator ):
    bl_idname ="object.ms_duplicate_active_modifier"
    bl_label ="Duplicate Active Modifier"
    bl_description ="Duplicate the active modifier row in the Smart Modifier stack."
    bl_options ={'UNDO'}
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Duplicate the active modifier as an independent copy. This is a quick Copy + Paste operation that keeps the original modifier unchanged and inserts the copied modifier at the stack position.',
        'アクティブなモディファイアを独立コピーとして複製します。元のモディファイアは変更せず、コピー + 貼り付けを一括で行い、スタック位置に複製を挿入します。',
        context =context )

    def execute (self ,context ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod:
            return {'CANCELLED'}
        bridge_state =ms_stack_popup_prepare_object_mode (context)
        try:
            res1 =_ms_run_item_action_direct (context ,action ='COPY',modifier_name =mod .name,target_obj_name =stack_obj .name)
            if res1 is not None and 'CANCELLED' in res1:
                return {'CANCELLED'}
            res2 =_ms_run_item_action_direct (context ,action ='PASTE',modifier_name =mod .name,target_obj_name =stack_obj .name)
            if res2 is not None and 'CANCELLED' in res2:
                return {'CANCELLED'}
        except Exception:
            return {'CANCELLED'}
        finally:
            ms_stack_popup_restore_mode (context ,bridge_state)
        return {'FINISHED'}


class OBJECT_OT_ms_expand_selected_modifier_only (bpy .types .Operator ):
    bl_idname ="object.ms_expand_selected_modifier_only"
    bl_label ="Expand Selected Only"
    bl_description ="Expand only the active modifier row and collapse the other modifier rows."
    bl_options =set ()
    _sms_no_undo =True
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Show only the active modifier properties and fold the other modifier rows. Use this to keep long stacks readable while editing one modifier.',
        'アクティブなモディファイアのプロパティだけを展開し、他のモディファイア行を折りたたみます。長いスタックで1つのモディファイアを編集しやすくするために使います。',
        context =context )

    def execute (self ,context ):
        main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod:
            return {'CANCELLED'}
        try:
            for m in stack_obj .modifiers:
                try:
                    m .show_expanded =bool (m ==mod)
                except Exception:
                    pass
        except Exception:
            return {'CANCELLED'}
        try:
            if main_obj and hasattr (main_obj ,'ms_show_properties'):
                main_obj .ms_show_properties =True
        except Exception:
            pass
        try:
            _ms_tag_redraw_all_view3d ()
        except Exception:
            pass
        return {'FINISHED'}


# =============================================================================
# 4.32.49 modifier-stack container gestures
#
# Four container-level gaps against the 3ds Max-style stack contract are closed
# here.  Every one of them delegates to an already-shipped primitive rather than
# reimplementing stack semantics:
#
#   drag reorder       -> object.ms_move_active_modifier  (undo + instance sync)
#   row expand state   -> core.set_mod_row_expanded       (bounded ID-property)
#   drag Copy/Instance -> _ms_run_item_action_direct COPY / PASTE / PASTE_INSTANCE
#   inline rename      -> object.ms_rename_modifier       (disp_name propagation)
# =============================================================================

_MS_DRAG_ROW_HEIGHT_PX = 24.0


def _ms_ui_scale (context ):
    try :
        return max (0.25 ,float (context .preferences .system .ui_scale ))
    except Exception :
        return 1.0


def _ms_stack_display_is_bottom_up (context ):
    try :
        from .preferences import get_preferences as _get_prefs
    except Exception :
        return False
    try :
        prefs =_get_prefs (context )
        return str (getattr (prefs ,"stack_order","TOP_DOWN")or "TOP_DOWN")=="BOTTOM_UP"
    except Exception :
        return False


def _ms_default_drag_clone_type (context ):
    try :
        from .preferences import get_preferences as _get_prefs
    except Exception :
        return "COPY"
    try :
        prefs =_get_prefs (context )
        value =str (getattr (prefs ,"shift_drag_clone_default_clone_type","COPY")or "COPY")
    except Exception :
        return "COPY"
    return "INSTANCE"if value =="INSTANCE"else "COPY"


class OBJECT_OT_ms_drag_reorder_modifier (bpy .types .Operator ):
    """Drag a stack row vertically to reorder it.

    The gesture only decides *when* and *which way* to step; every step is executed
    by ``object.ms_move_active_modifier`` so undo behaviour and instance-group
    co-movement are inherited from the shipped move primitive, not rebuilt here.
    """
    bl_idname ="object.ms_drag_reorder_modifier"
    bl_label ="Drag Reorder Modifier"
    bl_description ="Drag this row up or down to reorder it in the Smart Modifier stack."
    bl_options ={'UNDO','GRAB_CURSOR','BLOCKING'}
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Drag this row to move the modifier through the stack. Each step uses the same safe move logic as the Move Up / Move Down buttons, so instanced modifiers move together and every step can be undone. Release to keep the new order, or press Escape or right-click to put the modifier back where it started.',
        'この行をドラッグしてモディファイアをスタック内で移動します。各ステップは「上へ移動 / 下へ移動」ボタンと同じ安全な移動処理を使うため、インスタンス化されたモディファイアも一緒に移動し、各ステップは元に戻せます。離すと新しい順序を確定し、Escape または右クリックで元の位置に戻します。',
        context =context )

    def _threshold (self ,context ):
        return max (8.0 ,_MS_DRAG_ROW_HEIGHT_PX *_ms_ui_scale (context ))

    def _apply_step (self ,context ,internal_direction ):
        try :
            result =bpy .ops .object .ms_move_active_modifier (
            'EXEC_DEFAULT',
            direction =str (internal_direction ),
            target_obj_name =self .target_obj_name ,
            modifier_name =self .modifier_name ,
            )
        except Exception :
            return False
        return bool (result and 'FINISHED'in result )

    def invoke (self ,context ,event ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod :
            return {'CANCELLED'}
        self .target_obj_name =stack_obj .name
        self .modifier_name =mod .name
        self ._anchor_y =int (getattr (event ,'mouse_y',0 )or 0 )
        self ._net_up =0
        try :
            context .window_manager .modal_handler_add (self )
        except Exception :
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _revert (self ,context ):
        net =int (getattr (self ,'_net_up',0 ))
        if not net :
            return
        back ='DOWN'if net >0 else 'UP'
        for _i in range (abs (net )):
            if not self ._apply_step (context ,back ):
                break
        self ._net_up =0

    def _end (self ,context ):
        try :
            _ms_tag_redraw_all_view3d ()
        except Exception :
            pass

    def modal (self ,context ,event ):
        etype =str (getattr (event ,'type','')or '')
        evalue =str (getattr (event ,'value','')or '')

        if etype in {'RIGHTMOUSE','ESC'}:
            self ._revert (context )
            self ._end (context )
            return {'CANCELLED'}

        if etype =='MOUSEMOVE':
            threshold =self ._threshold (context )
            delta =int (getattr (event ,'mouse_y',0 )or 0 )-int (getattr (self ,'_anchor_y',0 ))
            guard =0
            while abs (delta )>=threshold and guard <256 :
                guard +=1
                screen_dir ='UP'if delta >0 else 'DOWN'
                # object.ms_move_active_modifier already performs the single
                # BOTTOM_UP inversion (see _ms_popup_do_move_impl in core.py), so
                # the raw on-screen direction is passed straight through; a second
                # conversion here would double-invert BOTTOM_UP drags.
                if not self ._apply_step (context ,screen_dir ):
                    # Already at the end of the stack: stop consuming this drag so
                    # the pointer must travel back before another step is taken.
                    self ._anchor_y =int (getattr (event ,'mouse_y',0 )or 0 )
                    break
                self ._net_up +=1 if screen_dir =='UP'else -1
                step =threshold if delta >0 else -threshold
                self ._anchor_y =int (self ._anchor_y +step )
                delta =int (delta -step )
            self ._end (context )
            return {'RUNNING_MODAL'}

        if etype in {'LEFTMOUSE','RET','NUMPAD_ENTER'}and evalue =='RELEASE':
            self ._end (context )
            return {'FINISHED'}

        return {'RUNNING_MODAL'}


class OBJECT_OT_ms_toggle_row_expanded (bpy .types .Operator ):
    bl_idname ="object.ms_toggle_row_expanded"
    bl_label ="Toggle Row"
    bl_description ="Expand or collapse this modifier row in the Smart Modifier stack."
    bl_options =set ()
    _sms_no_undo =True
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Expand or collapse the settings of this modifier row without changing which row is active. This affects only how the stack is displayed; it never changes the modifier result.',
        'アクティブな行を変えずに、このモディファイア行の設定を展開または折りたたみます。表示だけの変更で、モディファイアの結果には影響しません。',
        context =context )

    def execute (self ,context ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod :
            return {'CANCELLED'}
        try :
            set_mod_row_expanded (stack_obj ,mod .name ,not get_mod_row_expanded (stack_obj ,mod .name ))
            ms_prune_row_expanded_state (stack_obj )
        except Exception :
            return {'CANCELLED'}
        try :
            _ms_tag_redraw_all_view3d ()
        except Exception :
            pass
        return {'FINISHED'}


class OBJECT_OT_ms_set_all_rows_expanded (bpy .types .Operator ):
    bl_idname ="object.ms_set_all_rows_expanded"
    bl_label ="Expand / Collapse All Rows"
    bl_description ="Expand or collapse every modifier row in the Smart Modifier stack."
    bl_options =set ()
    _sms_no_undo =True
    target_obj_name :bpy .props .StringProperty (default ="")
    action :bpy .props .EnumProperty (
        name ="Action",
        items =(
            ('EXPAND_ALL',"Expand All","Expand every modifier row"),
            ('COLLAPSE_ALL',"Collapse All","Collapse every modifier row"),
        ),
        default ='EXPAND_ALL',
        options ={'HIDDEN','SKIP_SAVE'},
    )

    @classmethod
    def description (cls ,context ,properties ):
        if str (getattr (properties ,'action','EXPAND_ALL')or 'EXPAND_ALL')=='COLLAPSE_ALL':
            return choose_text (
            'Collapse every modifier row so a long stack stays readable. Display only; modifier results are unchanged.',
            'すべてのモディファイア行を折りたたみ、長いスタックを見やすくします。表示だけの変更で、モディファイアの結果は変わりません。',
            context =context )
        return choose_text (
        'Expand every modifier row so all stack settings are visible at once. Display only; modifier results are unchanged.',
        'すべてのモディファイア行を展開し、スタックの設定を一度に表示します。表示だけの変更で、モディファイアの結果は変わりません。',
        context =context )

    def execute (self ,context ):
        _main_obj ,stack_obj ,_mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,"")
        if not stack_obj or not ms_object_has_modifier_collection (stack_obj ):
            return {'CANCELLED'}
        try :
            ms_set_all_rows_expanded (stack_obj ,str (self .action )=='EXPAND_ALL')
        except Exception :
            return {'CANCELLED'}
        try :
            _ms_tag_redraw_all_view3d ()
        except Exception :
            pass
        return {'FINISHED'}


def _ms_view3d_window_region (context ):
    """Return (region, region_3d) for a VIEW_3D window region, or (None, None)."""
    area =getattr (context ,'area',None )
    try :
        if area is None or str (getattr (area ,'type','')or '')!='VIEW_3D':
            area =None
    except Exception :
        area =None
    if area is None :
        try :
            screen =context .window .screen
        except Exception :
            screen =None
        for candidate in (getattr (screen ,'areas',None )or []):
            try :
                if str (getattr (candidate ,'type','')or '')=='VIEW_3D':
                    area =candidate
                    break
            except Exception :
                continue
    if area is None :
        return None ,None
    region =None
    for candidate in (getattr (area ,'regions',None )or []):
        try :
            if str (getattr (candidate ,'type','')or '')=='WINDOW':
                region =candidate
        except Exception :
            continue
    try :
        rv3d =area .spaces .active .region_3d
    except Exception :
        rv3d =None
    return region ,rv3d


def _ms_pick_main_object_at_mouse (context ,event ):
    """Object under the pointer in the 3D viewport, without touching selection.

    Uses a scene ray cast rather than ``view3d.select`` so the drop gesture never
    mutates the user's selection just to discover a target.
    """
    try :
        from bpy_extras import view3d_utils
    except Exception :
        return None
    region ,rv3d =_ms_view3d_window_region (context )
    if region is None or rv3d is None :
        return None
    try :
        x =float (getattr (event ,'mouse_x',0 )or 0 )-float (region .x )
        y =float (getattr (event ,'mouse_y',0 )or 0 )-float (region .y )
        if x <0 or y <0 or x >float (region .width )or y >float (region .height ):
            return None
    except Exception :
        return None
    try :
        origin =view3d_utils .region_2d_to_origin_3d (region ,rv3d ,(x ,y ))
        direction =view3d_utils .region_2d_to_vector_3d (region ,rv3d ,(x ,y ))
    except Exception :
        return None
    if origin is None or direction is None :
        return None
    try :
        depsgraph =context .evaluated_depsgraph_get ()
        hit ,_loc ,_nrm ,_idx ,hit_obj ,_mat =context .scene .ray_cast (depsgraph ,origin ,direction )
    except Exception :
        return None
    if not hit or hit_obj is None :
        return None
    try :
        original =hit_obj .original
    except Exception :
        original =hit_obj
    try :
        return get_main_object (original )or original
    except Exception :
        return original


def _ms_capture_selection_state (context ):
    try :
        view_layer =context .view_layer
    except Exception :
        return None
    try :
        names =[o .name for o in (getattr (context ,'selected_objects',None )or [])if o ]
    except Exception :
        names =[]
    try :
        active =view_layer .objects .active .name if view_layer .objects .active else ""
    except Exception :
        active =""
    return (names ,active )


def _ms_iter_view_layer_objects (context ):
    try :
        return list (context .view_layer .objects )
    except Exception :
        return []


def _ms_restore_selection_state (context ,state ):
    if not state :
        return
    names ,active =state
    wanted =set (names or [])
    for obj in _ms_iter_view_layer_objects (context ):
        try :
            obj .select_set (obj .name in wanted )
        except Exception :
            pass
    try :
        context .view_layer .objects .active =bpy .data .objects .get (active )if active else None
    except Exception :
        pass


def _ms_isolate_selection (context ,obj ):
    """Make ``obj`` the only selected and active object.

    ``OBJECT_OT_ms_item_action`` fans PASTE out across every selected main mesh in
    multi mode.  A drop gesture targets exactly one object, so the selection is
    narrowed for the duration of the paste and restored by the caller.
    """
    for other in _ms_iter_view_layer_objects (context ):
        try :
            other .select_set (False )
        except Exception :
            pass
    try :
        obj .select_set (True )
        context .view_layer .objects .active =obj
    except Exception :
        return False
    return True


class OBJECT_OT_ms_drag_modifier_to_object (bpy .types .Operator ):
    """Drag one modifier row onto another object to Copy or Instance it there.

    This is the modifier-granularity counterpart of the object-level shift-drag
    clone gesture.  Shift held at release selects Instance, matching that object
    clone convention; the drop itself reuses the shipped COPY / PASTE /
    PASTE_INSTANCE item actions, so a dropped Instance is a real linked modifier.
    """
    bl_idname ="object.ms_drag_modifier_to_object"
    bl_label ="Drag Modifier To Object"
    bl_description ="Drag this modifier onto another object to copy or instance it there."
    bl_options ={'UNDO','GRAB_CURSOR','BLOCKING'}
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")
    clone_type :bpy .props .EnumProperty (
        name ="Clone Type",
        items =(
            ('COPY',"Copy","Drop an independent copy of the modifier"),
            ('INSTANCE',"Instance","Drop a linked instance of the modifier"),
        ),
        default ='COPY',
        options ={'HIDDEN','SKIP_SAVE'},
    )

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Drag this modifier onto another object in the viewport to add it there. Release over the target to drop a copy, or hold Shift while releasing to drop a linked instance that keeps sharing settings with the original. Release over empty space, or press Escape, to cancel.',
        'このモディファイアをビューポート上の別のオブジェクトへドラッグして追加します。ターゲットの上で離すとコピーを、Shift を押しながら離すと元と設定を共有するリンクインスタンスを作成します。何もない場所で離すか Escape を押すとキャンセルします。',
        context =context )

    def _hint (self ,context ):
        return choose_text (
        'Drop the modifier on an object. Shift = Instance, Escape = Cancel.',
        'モディファイアをオブジェクトの上でドロップします。Shift = インスタンス、Escape = キャンセル。',
        context =context )

    def _set_header (self ,context ,text ):
        try :
            context .area .header_text_set (text )
        except Exception :
            pass

    def _clear_header (self ,context ):
        try :
            context .area .header_text_set (None )
        except Exception :
            pass

    def invoke (self ,context ,event ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod :
            return {'CANCELLED'}
        self .target_obj_name =stack_obj .name
        self .modifier_name =mod .name
        self ._source_stack_name =stack_obj .name
        try :
            context .window_manager .modal_handler_add (self )
        except Exception :
            return {'CANCELLED'}
        self ._set_header (context ,self ._hint (context ))
        return {'RUNNING_MODAL'}

    def _drop (self ,context ,target_main_obj ,clone_type ):
        source =bpy .data .objects .get (str (getattr (self ,'_source_stack_name','')or ''))
        if source is None or target_main_obj is None :
            return False
        if not ms_object_has_modifier_collection (source ):
            return False
        mod =source .modifiers .get (self .modifier_name )
        if mod is None :
            return False
        try :
            target_stack =ms_get_modifier_stack_object (target_main_obj ,context =context ,create =False )or target_main_obj
        except Exception :
            target_stack =target_main_obj
        if target_stack is None or not ms_object_has_modifier_collection (target_stack ):
            return False
        if target_stack .name ==source .name :
            return False
        result =_ms_run_item_action_direct (
        context ,
        action ='COPY',
        modifier_name =mod .name ,
        target_obj_name =source .name ,
        )
        if result is not None and 'CANCELLED'in result :
            return False
        action ='PASTE_INSTANCE'if str (clone_type )=='INSTANCE'else 'PASTE'
        saved =_ms_capture_selection_state (context )
        try :
            _ms_isolate_selection (context ,target_main_obj )
            result =_ms_run_item_action_direct (
            context ,
            action =action ,
            modifier_name ="",
            target_obj_name =target_main_obj .name ,
            )
        finally :
            _ms_restore_selection_state (context ,saved )
        return bool (result is not None and 'FINISHED'in result )

    def modal (self ,context ,event ):
        etype =str (getattr (event ,'type','')or '')
        evalue =str (getattr (event ,'value','')or '')

        if etype in {'RIGHTMOUSE','ESC'}:
            self ._clear_header (context )
            return {'CANCELLED'}

        if etype =='MOUSEMOVE':
            hovered =_ms_pick_main_object_at_mouse (context ,event )
            source_name =str (getattr (self ,'_source_stack_name','')or '')
            if hovered is not None and hovered .name !=source_name :
                label ='INSTANCE'if getattr (event ,'shift',False )else 'COPY'
                self ._set_header (context ,"%s  ->  %s"%(label ,hovered .name ))
            else :
                self ._set_header (context ,self ._hint (context ))
            return {'RUNNING_MODAL'}

        if etype =='LEFTMOUSE'and evalue =='RELEASE':
            target =_ms_pick_main_object_at_mouse (context ,event )
            clone_type ='INSTANCE'if getattr (event ,'shift',False )else str (self .clone_type or _ms_default_drag_clone_type (context ))
            self ._clear_header (context )
            if target is None :
                return {'CANCELLED'}
            bridge_state =ms_stack_popup_prepare_object_mode (context )
            try :
                dropped =self ._drop (context ,target ,clone_type )
            except Exception :
                dropped =False
            finally :
                ms_stack_popup_restore_mode (context ,bridge_state )
            try :
                _ms_tag_redraw_all_view3d ()
            except Exception :
                pass
            return {'FINISHED'}if dropped else {'CANCELLED'}

        return {'RUNNING_MODAL'}


class OBJECT_OT_ms_begin_inline_rename (bpy .types .Operator ):
    bl_idname ="object.ms_begin_inline_rename"
    bl_label ="Rename In Row"
    bl_description ="Edit this modifier name directly in the stack row."
    bl_options =set ()
    _sms_no_undo =True
    target_obj_name :bpy .props .StringProperty (default ="")
    modifier_name :bpy .props .StringProperty (default ="")

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Rename this modifier directly in the row instead of opening a dialog. Press Enter to confirm, or clear the field to cancel. Linked instances are renamed together, exactly as the Rename dialog does.',
        'ダイアログを開かずに、この行で直接モディファイア名を変更します。Enter で確定し、フィールドを空にするとキャンセルします。リネームダイアログと同様に、リンクされたインスタンスも一緒に名前が変更されます。',
        context =context )

    def execute (self ,context ):
        _main_obj ,stack_obj ,mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,self .modifier_name )
        if not stack_obj or not mod :
            return {'CANCELLED'}
        if not ms_inline_rename_begin (context .window_manager ,stack_obj ,mod .name ):
            return {'CANCELLED'}
        try :
            _ms_tag_redraw_all_view3d ()
        except Exception :
            pass
        return {'FINISHED'}


class OBJECT_OT_ms_cancel_inline_rename (bpy .types .Operator ):
    bl_idname ="object.ms_cancel_inline_rename"
    bl_label ="Cancel Rename"
    bl_description ="Leave inline rename without changing the modifier name."
    bl_options =set ()
    _sms_no_undo =True

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Close the inline rename field without applying a new name.',
        '新しい名前を適用せずに、行内リネームのフィールドを閉じます。',
        context =context )

    def execute (self ,context ):
        ms_inline_rename_clear (context .window_manager )
        try :
            _ms_tag_redraw_all_view3d ()
        except Exception :
            pass
        return {'FINISHED'}


class OBJECT_OT_ms_apply_all_stack_modifiers (bpy .types .Operator ):
    bl_idname ="object.ms_apply_all_stack_modifiers"
    bl_label ="Apply All Stack Modifiers"
    bl_description ="Apply every non-internal modifier in the Smart Modifier stack."
    bl_options ={'UNDO'}
    target_obj_name :bpy .props .StringProperty (default ="")
    shape_key_apply_mode :bpy .props .EnumProperty (
        name ="Shape Key Apply Mode",
        description ="Choose how the Basis is prepared before applying all stack modifiers to shape keys",
        items =_MS_SHAPE_KEY_APPLY_MODE_ITEMS,
        default =_MS_SHAPE_KEY_APPLY_CURRENT_MIX,
        options ={'HIDDEN','SKIP_SAVE'},
    )
    shape_key_choice_confirmed :bpy .props .BoolProperty (
        default =False,
        options ={'HIDDEN','SKIP_SAVE'},
    )

    @classmethod
    def description (cls ,context ,properties ):
        return choose_text (
        'Apply every visible stack modifier from the base object up to the last modifier. This is destructive, so use Undo if you need to revert.',
        'ベースオブジェクトから最後のモディファイアまで、スタック内の通常モディファイアを全て適用します。破壊的な処理のため、戻す場合はUndoを使ってください。',
        context =context )

    def _resolve_target (self ,context ):
        _main_obj ,stack_obj ,_mod =_ms_resolve_stack_quick_target (context ,self .target_obj_name ,"")
        if not stack_obj or not ms_object_has_modifier_collection (stack_obj):
            return None ,None
        target_mod =None
        try:
            for candidate in stack_obj .modifiers:
                try:
                    if ms_modifier_is_internal_stack_helper (candidate):
                        continue
                except Exception:
                    pass
                target_mod =candidate
        except Exception:
            target_mod =None
        return stack_obj ,target_mod

    def invoke (self ,context ,event ):
        stack_obj ,target_mod =self ._resolve_target (context )
        if not stack_obj or not target_mod:
            return {'CANCELLED'}
        if _ms_apply_action_needs_shape_key_choice (
            context ,'APPLY_BELOW',target_mod .name,stack_obj .name
        )and not bool (getattr (self ,'shape_key_choice_confirmed',False )):
            return _ms_invoke_shape_key_apply_dialog (self ,context )
        return self .execute (context )

    def draw (self ,context ):
        _ms_draw_shape_key_apply_dialog (self ,context )

    def execute (self ,context ):
        stack_obj ,target_mod =self ._resolve_target (context )
        if not stack_obj or not target_mod:
            return {'CANCELLED'}
        needs_choice =_ms_apply_action_needs_shape_key_choice (
            context ,'APPLY_BELOW',target_mod .name,stack_obj .name
        )
        if needs_choice and not bool (getattr (self ,'shape_key_choice_confirmed',False )):
            _ms_report_operator (self ,'ERROR',_ms_shape_key_choice_required_message (context ))
            return {'CANCELLED'}
        try:
            result =_ms_run_item_action_direct (
                context,
                action ='APPLY_BELOW',
                modifier_name =target_mod .name,
                target_obj_name =stack_obj .name,
                shape_key_apply_mode =self .shape_key_apply_mode,
                shape_key_choice_confirmed =(bool (self .shape_key_choice_confirmed )or not needs_choice),
                report_callback =self .report,
            )
            if result is not None and 'CANCELLED' in result:
                return {'CANCELLED'}
        except Exception as exc:
            _ms_report_operator (self ,'ERROR',choose_text (
                f"Failed to apply the modifier stack: {exc}",
                f"モディファイアスタックの適用に失敗しました: {exc}",
                context =context,
            ))
            return {'CANCELLED'}
        return {'FINISHED'}

class OBJECT_OT_ms_base_menu_call (bpy .types .Operator ):
    bl_idname ="object.ms_base_menu_call"
    bl_label ='Base Object Menu'
    bl_description ='Open the Base Object menu (see tooltip for details)'
    _sms_no_undo = True
    bl_options = set()
    target_obj_name :bpy .props .StringProperty ()

    @classmethod 
    def description (cls ,context ,properties ):
        return choose_text (
        'Open the Base Object action menu.\nWhen the base object is linked/instanced, this menu can release the selected object instance.\nIt also provides Paste and Paste Instance operations, using the Base Object as the source position in the stack.',
        'ベースオブジェクトの操作メニューを開きます。\nベースオブジェクトがリンク / インスタンス化されている場合は、選択中オブジェクトのインスタンス解除を実行できます。\nそのほか、Base Object をスタック上の基準位置として、貼り付け / インスタンス貼り付けを実行できます。',
        context =context
        )
    def execute (self ,context ):
        context .window_manager .ms_target_mod =""
        context .window_manager .ms_target_obj =self .target_obj_name 
        bpy .ops .wm .call_menu (name ="VIEW3D_MT_ms_base_menu")
        return {'FINISHED'}

class VIEW3D_MT_ms_base_menu (bpy .types .Menu ):
    bl_idname ="VIEW3D_MT_ms_base_menu"
    bl_label ='Base Object Menu'
    def draw (self ,context ):
        layout =self .layout 
        obj_name =context .window_manager .ms_target_obj 
        layout .label (text =pgettext ("Base Object"))
        try :
            obj =bpy .data .objects .get (obj_name )
            if ms_object_has_linked_base_instance (obj ,context ):
                op =_sms_icon_operator (layout ,"object.sms_instance_make_unique",text =choose_text ('Release Instance','インスタンス解除',context =context ),icon_name ='unique',fallback_icon ='UNLINKED')
                op .target_obj_name =obj_name
        except Exception :
            pass
        layout .separator ()
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Paste'),icon_name ='paste',fallback_icon ='PASTEDOWN')
        op .action ,op .modifier_name ,op .target_obj_name ='PASTE','BASE',obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Paste (Instance)'),icon_name ='paste_instance',fallback_icon ='LINKED')
        op .action ,op .modifier_name ,op .target_obj_name ='PASTE_INSTANCE','BASE',obj_name 

class VIEW3D_MT_ms_item_menu (bpy .types .Menu ):
    bl_idname ="VIEW3D_MT_ms_item_menu"
    bl_label ='Modifier Menu'
    def draw (self ,context ):
        layout =self .layout 
        try: layout.operator_context = 'INVOKE_DEFAULT'
        except Exception: pass
        mod_name =context .window_manager .ms_target_mod 
        obj_name =context .window_manager .ms_target_obj 
        disp =mod_name 
        try :
            o =bpy .data .objects .get (obj_name )
            dn =ms_obj_get_disp_name (o ,mod_name )
            if dn :disp =dn 
        except Exception :pass 
        layout .label (text =disp )
        instanced_mod =False
        try :
            _row_obj =bpy .data .objects .get (obj_name )
            _row_mod =_row_obj .modifiers .get (mod_name )if _row_obj and mod_name else None
            instanced_mod =bool (_row_mod and ms_is_instance_modifier (_row_mod ,_row_obj ))
        except Exception :
            instanced_mod =False
        layout .separator ()
        _sms_icon_prop (layout ,context .window_manager ,"ms_move_up",text =pgettext ('Move Up'),icon_name ='RIA_UP',fallback_icon ='TRIA_UP',toggle =True )
        _sms_icon_prop (layout ,context .window_manager ,"ms_move_down",text =pgettext ('Move Down'),icon_name ='TRIA_DOWN',fallback_icon ='TRIA_DOWN',toggle =True )
        layout .separator ()
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Apply'),icon_name ='apply',fallback_icon ='CHECKMARK')
        op .action ,op .modifier_name ,op .target_obj_name ='APPLY',mod_name ,obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Apply to Here'),icon_name ='stack',fallback_icon ='MODIFIER_ON')
        op .action ,op .modifier_name ,op .target_obj_name ='APPLY_BELOW',mod_name ,obj_name 
        if instanced_mod :
            op =_sms_icon_operator (layout ,"object.ms_make_modifier_unique",text =choose_text ('Release Instance','インスタンス解除',context =context ),icon_name ='unique',fallback_icon ='UNLINKED')
            op .modifier_name ,op .target_obj_name =mod_name ,obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Delete'),icon_name ='delete',fallback_icon ='X')
        op .action ,op .modifier_name ,op .target_obj_name ='DELETE',mod_name ,obj_name 
        layout .separator ()
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Copy'),icon_name ='copy',fallback_icon ='COPYDOWN')
        op .action ,op .modifier_name ,op .target_obj_name ='COPY',mod_name ,obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Cut'),icon_name ='cut',fallback_icon ='SNAP_PEEL_OBJECT')
        op .action ,op .modifier_name ,op .target_obj_name ='CUT',mod_name ,obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Paste'),icon_name ='paste',fallback_icon ='PASTEDOWN')
        op .action ,op .modifier_name ,op .target_obj_name ='PASTE',mod_name ,obj_name 
        op =_sms_icon_operator (layout ,"object.ms_item_action",text =pgettext ('Paste (Instance)'),icon_name ='paste_instance',fallback_icon ='LINKED')
        op .action ,op .modifier_name ,op .target_obj_name ='PASTE_INSTANCE',mod_name ,obj_name 
        layout .separator ()
        try:
            layout.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            pass
        op =_sms_icon_operator (layout ,"object.ms_rename_modifier",text =pgettext ('Rename'),icon_name ='edit',fallback_icon ='OUTLINER_DATA_FONT')
        op .modifier_name ,op .target_obj_name =mod_name ,obj_name 
        try :
            o =bpy .data .objects .get (obj_name )
            m =o .modifiers .get (mod_name )if o and mod_name else None 
            if m and ms_is_instance_modifier (m ,o ):
                iid =ms_get_instance_id (m ,o )
                if iid :
                    layout .separator ()
                    op =_sms_icon_operator (layout ,"object.ms_select_instance_members",text =pgettext ('Select Instances'),icon_name ='select_instances',fallback_icon ='RESTRICT_SELECT_OFF')
                    op .instance_id =iid 
        except Exception :pass 


        # --- Tooltip completion ---
OBJECT_OT_ms_item_action .bl_description ='Run a stack item action such as reorder, isolate, or maintenance from the Smart Modifier stack UI.'
VIEW3D_MT_ms_base_menu .bl_description ='Context menu for stack-level actions in Smart Modifier.'
VIEW3D_MT_ms_item_menu .bl_description ='Context menu for per-modifier actions in Smart Modifier.'
