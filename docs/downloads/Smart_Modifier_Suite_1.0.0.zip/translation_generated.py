# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

"""Generated Japanese translation_catalogs for English-only UI source strings.

This file is generated during the package cleanup that removed inline
dual-language display strings from the source code.
"""

translation_catalog_dict = {'ja_JP': {('*', '+X to -X'): '+X から -X',
           ('*', '+Y to -Y'): '+Y から -Y',
           ('*', '+Z to -Z'): '+Z から -Z',
           ('*', '-X to +X'): '-X から +X',
           ('*', '-Y to +Y'): '-Y から +Y',
           ('*', '-Z to +Z'): '-Z から +Z',
           ('*', '2 x 2 x 2'): '2 × 2 × 2',
           ('*', '3 x 3 x 3'): '3 × 3 × 3',
           ('*', '4 x 4 x 4'): '4 × 4 × 4',
           ('*', 'Active mesh required'): 'アクティブメッシュが必要です。',
           ('*', "Add Blender's standard deform modifiers."): 'Blender 標準の変形系モディファイアを追加します。',
           ('*', "Add Blender's standard edit / data-transfer / weight style modifier entries."): 'Blender '
                                                                                                  '標準の編集・転送・頂点ウェイト系モディファイアを追加します。',
           ('*', "Add Blender's standard generate modifiers."): 'Blender 標準の生成系モディファイアを追加します。',
           ('*', "Add Blender's standard normal modifiers."): 'Blender 標準の法線系モディファイアを追加します。',
           ('*', 'Add Normal Transfer'): '法線転送を追加',
           ('*', 'Add geometry / remesh style modifiers from the Smart Modifier add menu.'): 'Smart Modifier '
                                                                                                   'Toolset '
                                                                                                   'の追加メニューから、ジオメトリ / '
                                                                                                   'リメッシュ系モディファイアを追加します。',
           ('*', 'Add geometry-nodes based entries from the Smart Modifier add menu.'): 'Smart Modifier '
                                                                                              'の追加メニューから、Geometry '
                                                                                              'Nodes 系エントリを追加します。',
           ('*', 'Add hair-related modifiers from the Smart Modifier add menu.'): 'Smart Modifier '
                                                                                        'の追加メニューから、ヘア系モディファイアを追加します。',
           ('*', 'Add instancing-style modifiers from the Smart Modifier add menu.'): 'Smart Modifier '
                                                                                            'の追加メニューから、インスタンス系モディファイアを追加します。',
           ('*', 'Add or update a Data Transfer modifier on the selected target meshes so custom normals follow the active source mesh. Useful for hard-surface shading, floating details, bevel support parts, and keeping kitbash pieces visually welded.'): '選択したターゲットメッシュへ '
                                                                                                                                                                                                                                                               'Data '
                                                                                                                                                                                                                                                               'Transfer '
                                                                                                                                                                                                                                                               'モディファイアを追加 '
                                                                                                                                                                                                                                                               '/ '
                                                                                                                                                                                                                                                               '更新し、カスタム法線をアクティブ元メッシュへ追従させます。ハードサーフェスの陰影、浮かせたディテール、ベベル補助パーツ、キットバッシュ部品を視覚的に一体化させる用途に便利です。',
           ('*', 'Add or update a shrinkwrap-based conform modifier on the selected detail meshes so they follow the active surface mesh in a 3ds Max style modifier workflow.'): '選択したディテールメッシュへ '
                                                                                                                                                                                  'Shrinkwrap '
                                                                                                                                                                                  'ベースの追従モディファイアを追加 '
                                                                                                                                                                                  '/ '
                                                                                                                                                                                  '更新し、3ds '
                                                                                                                                                                                  'Max '
                                                                                                                                                                                  '風のモディファイアワークフローでアクティブ面へ追従させます。',
           ('*', 'Add physics-style modifiers from the Smart Modifier add menu.'): 'Smart Modifier '
                                                                                         'の追加メニューから、物理系モディファイアを追加します。',
           ('*', 'Advanced / Surface Modeling panel in the Smart Modifier workspace.'): 'Smart Modifier ワークスペース内の '
                                                                                        'Advanced / Surface Modeling '
                                                                                        'パネルです。',
           ('*', 'Advanced Surface / Kitbash'): '高度サーフェス / キットバッシュ',
           ('*', 'Advanced settings panel for the modifier switcher helper.'): 'モディファイアスイッチャー補助の詳細設定パネルです。',
           ('*', 'After surface conform, also add / update a Data Transfer modifier so custom normals follow the active source mesh.'): '面追従の後で、カスタム法線もアクティブ元メッシュに追従するよう '
                                                                                                                                        'Data '
                                                                                                                                        'Transfer '
                                                                                                                                        'モディファイアも追加 '
                                                                                                                                        '/ '
                                                                                                                                        '更新します。',
           ('*', 'Align To Active Modifier'): 'アクティブ整列モディファイア',
           ('*', 'Allow cage editing through the generated Mirror modifier.'): '生成された Mirror '
                                                                               'モディファイア越しにケージ編集を行えるようにします。',
           ('*', 'Apply Mirror'): 'ミラーを適用',
           ('*', 'Apply the generated Mirror modifier immediately after creation.'): '生成した Mirror モディファイアをすぐに適用します。',
           ('*', 'Area + Angle'): '面積 + 角度',
           ('*', 'Array Along Curve Modifier'): 'カーブ配列モディファイア',
           ('*', 'Attempt triangle-to-quad conversion after fill to keep the result cleaner for subdivision and retopo cleanup.'): 'フィル後に三角形から四角形への変換を試み、サブディビジョンやリトポ整理に向いた結果にします。',
           ('*', 'Audit Repair Modifier'): '監査修復モディファイア',
           ('*', 'Audit Select Issues'): '監査問題選択',
           ('*', 'Audit Selected Modifier'): '監査モディファイア',
           ('*', 'Axis Slice Modifier'): '軸スライスモディファイア',
           ('*', 'Base Object'): 'ベースオブジェクト',
           ('*', 'Base Object Bottom'): 'ベース下',
           ('*', 'Base Object Top'): 'ベース上',
           ('*', 'Beautify Fill'): 'フィルを整形',
           ('*', 'Beginner-friendly workflow notes for the Smart Modifier Hub.'): 'Smart Modifier Hub '
                                                                                  '向けの初心者用ワークフローガイドです。',
           ('*', 'Beginner-friendly workflow notes for the advanced surface modeling helpers.'): '高度サーフェスモデリング補助の初心者向けワークフローメモです。',
           ('*', 'Beginner-friendly workflow notes for the advanced surface modeling helpers. / Advanced'): 'Surface '
                                                                                                            'Modeling '
                                                                                                            '向けの初心者用ガイドです。',
           ('*', 'Beginner-friendly workflow notes for the precision, path, sweep, CAD, and audit tools in this panel.'): '精密、パス、スイープ、CAD、監査ツール向けの初心者用ガイドです。',
           ('*', 'Bend Modifier'): '曲げモディファイア',
           ('*', 'Bisect Threshold'): '切断しきい値',
           ('*', 'Blender modifiers + User tools'): 'Blender標準 + ユーザーツール',
           ('*', 'Boolean Stack Modifier'): 'ブーリアンスタックモディファイア',
           ('*', 'Browser properties unavailable'): 'ブラウザー設定を初期化できませんでした',
           ('*', 'Bundled Subtools'): '同梱サブツール',
           ('*', 'CAD'): 'CAD',
           ('*', 'CAD / Tessellate / Audit'): 'CAD / テッセレーション / 監査',
           ('*', 'CAD Intersect Modifier'): 'CAD交差モディファイア',
           ('*', 'Cast Modifier'): 'キャストモディファイア',
           ('*', 'Cast X'): 'X方向キャスト',
           ('*', 'Cast Y'): 'Y方向キャスト',
           ('*', 'Cast Z'): 'Z方向キャスト',
           ('*', 'Catalog summary'): 'カタログ概要',
           ('*', 'Choose which local axis becomes the symmetry plane.'): 'どのローカル軸を対称面にするか選びます。',
           ('*', 'Circle Modifier'): '円形化モディファイア',
           ('*', 'Clipboard access failed'): 'クリップボードへのアクセスに失敗しました。',
           ('*', 'Clipboard is not available.'): 'クリップボードを利用できません。',
           ('*', 'Combine Join Clean Modifier'): '結合クリーンモディファイア',
           ('*', 'Compact advanced panel for surface-first hard-surface helpers, slice panels, bend/twist/taper/lattice/cast deformation, thickness, clean combine, and surface drop utilities.'): 'サーフェス起点のハードサーフェス補助、スライスパネル、ベンド/ツイスト/テーパー/ラティス/キャスト変形、厚み付け、クリーン結合、面ドロップ系をまとめたコンパクトな上級パネルです。',
           ('*', 'Compact entry point to the bundled modifier visibility switcher.'): '同梱のモディファイア表示切替ツールへのコンパクトな入口です。',
           ('*', 'Compact precision panel for workplane, projection, retopo helpers, path instancing, replacements, and curve-based modeling tasks.'): '作業平面、投影、リトポ補助、パス配置、置換、カーブ系モデリングをまとめた精密ツールパネル。',
           ('*', 'Companion tools'): '連携ツール',
           ('*', 'Configured normal transfer modifiers on selected targets'): '選択ターゲットに法線転送モディファイアを設定しました',
           ('*', 'Configured surface conform modifiers on selected targets'): '選択ターゲットに面追従モディファイアを設定しました',
           ('*', 'Conform Method'): '追従方法',
           ('*', 'Conform To Surface'): '面へ追従',
           ('*', 'Context menu for per-modifier actions in Smart Modifier.'): 'Smart Modifier '
                                                                                    'の各モディファイア項目向けコンテキストメニューです。',
           ('*', 'Context menu for stack-level actions in Smart Modifier.'): 'Smart Modifier '
                                                                                   'のスタック全体向けコンテキストメニューです。',
           ('*', 'Context quick picks highlight tools that are ready right now and tools unlocked by simple mode / selection fixes.'): 'Context '
                                                                                                                                       'quick '
                                                                                                                                       'picks '
                                                                                                                                       'は今すぐ使えるツールと、簡単なモード '
                                                                                                                                       '/ '
                                                                                                                                       '選択調整で使えるツールを示します。',
           ('*', 'Copy Full'): '全体コピー',
           ('*', 'Copy ID'): 'IDコピー',
           ('*', 'Copy Preflight Report'): '診断レポートをコピー',
           ('*', 'Copy Props'): '追加値コピー',
           ('*', 'Copy Tool Browser Report'): 'ツールブラウザーレポートをコピー',
           ('*', 'Copy a compact compatibility / readiness report to the clipboard so you can quickly audit this installation.'): 'このインストールの互換性・準備状況を素早く監査できるよう、コンパクトな診断レポートをクリップボードへコピーします。',
           ('*', 'Copy browser report'): 'ブラウザーレポートをコピー',
           ('*', 'Copy report'): 'レポートをコピー',
           ('*', 'Copy the current filtered tool-browser status report to the clipboard.'): '現在のフィルタ状態を反映したツールブラウザーの状態レポートをクリップボードへコピーします。',
           ('*', 'Core coverage'): 'コア監査',
           ('*', 'Corner Angle'): '角度',
           ('*', 'Create a curve path from the currently selected edit-mesh vertices. Useful for spline blocking, strip routing, loft / sweep preparation, and 3ds Max style path extraction from direct mesh edits.'): '現在選択している編集メッシュ頂点からカーブパスを作成します。スプラインブロックアウト、帯状配線、ロフト '
                                                                                                                                                                                                                        '/ '
                                                                                                                                                                                                                        'スイープ前処理、3ds '
                                                                                                                                                                                                                        'Max '
                                                                                                                                                                                                                        '風のメッシュ編集起点パス抽出に便利です。',
           ('*', 'Curve Modifier'): 'カーブモディファイア',
           ('*', 'Curves / Loft / Prep'): 'カーブ / ロフト / 下準備',
           ('*', 'Curves / Path / Sweep'): 'カーブ / パス / スイープ',
           ('*', 'Cut and Mirror'): '切断してミラー',
           ('*', 'Deform / Thickness'): '変形 / 厚み',
           ('*', 'Delete one side and add a Mirror modifier. Disable it when you only want the bisect and center weld.'): '片側を削除して '
                                                                                                                          'Mirror '
                                                                                                                          'モディファイアを追加します。無効にすると切断と中央合わせだけを行います。',
           ('*', 'Detach Separate Clean Modifier'): '分離クリーンモディファイア',
           ('*', 'Distribute Selected Modifier'): '選択均等配置モディファイア',
           ('*', 'Distribute along world X.'): 'ワールドX方向に均等配置します。',
           ('*', 'Distribute along world Y.'): 'ワールドY方向に均等配置します。',
           ('*', 'Distribute along world Z.'): 'ワールドZ方向に均等配置します。',
           ('*', 'Drop To Floor Modifier'): '床へドロップモディファイア',
           ('*', 'Drop To Surface Modifier'): '面ドロップモディファイア',
           ('*', 'Edit Poly'): '編集ポリゴン',
           ('*', 'Edit Polygon Live Sync'): '編集ポリゴンライブ同期',
           ('*', 'Edit Polygon Maintenance'): '編集ポリゴンメンテナンス',
           ('*', 'Editable On Cage'): 'ケージ上で編集',
           ('*', 'Enabled Features'): '有効機能',
           ('*', 'Exact'): '正確',
           ('*', 'FFD Modifier'): 'FFDモディファイア',
           ('*', 'Face Area'): '面積',
           ('*', 'Face Component Array Modifier'): '面コンポーネント配列モディファイア',
           ('*', 'Failed to add conform modifiers to the selected targets'): '選択ターゲットへ追従モディファイアを追加できませんでした。',
           ('*', 'Failed to add normal transfer modifiers to the selected targets'): '選択ターゲットへ法線転送モディファイアを追加できませんでした。',
           ('*', 'Failed to load Smart Modifier sections'): 'Smart Modifier セクションの読み込みに失敗しました',
           ('*', 'Fallback-aware helpers'): '代替経路付きヘルパー',
           ('*', 'Fallback: Circle Selection uses Blender To Sphere when LoopTools is unavailable.'): '代替: LoopTools '
                                                                                                      'が無い場合は Circle '
                                                                                                      'Selection が '
                                                                                                      'Blender 標準 To '
                                                                                                      'Sphere '
                                                                                                      'へフォールバックします。',
           ('*', 'Fallback: Relax Selection uses Blender smoothing when LoopTools is unavailable.'): '代替: LoopTools '
                                                                                                     'が無い場合は Relax '
                                                                                                     'Selection が '
                                                                                                     'Blender '
                                                                                                     '標準スムージングへフォールバックします。',
           ('*', 'Fast'): '高速',
           ('*', 'Filter'): 'フィルター',
           ('*', 'Filter migrated tools by label, operator id, or tooltip text.'): 'ラベル、operator '
                                                                                   'id、ツールチップ文で移行ツールを絞り込みます。',
           ('*', 'Floor Modifier'): 'フロアモディファイア',
           ('*', 'Fuse cutters into the target'): 'カッターをターゲットへ合成します。',
           ('*', 'Grouped browser for migrated Smart Modifier tools with compact readiness states, search, and live blocker summaries.'): '移行済み '
                                                                                                                                          'Smart '
                                                                                                                                          'Modifier '
                                                                                                                                          'ツールを、検索・状態表示・現在の不足条件付きでグループ閲覧するパネルです。',
           ('*', 'Grouped root submenu for Smart Modifier user tools. It fans out into workflow-category entries so the migrated custom modifier catalog stays easier to scan than one long flat list.'): 'Smart '
                                                                                                                                                                                                          'Modifier '
                                                                                                                                                                                                          'Toolset '
                                                                                                                                                                                                          'のユーザーツール用グループ化ルートサブメニューです。移行済みの独自モディファイア群をワークフロー別カテゴリへ'
                                                                                                                                                                                                          'へ分岐させ、長い1本リストより選びやすくします。',
           ('*', 'Guide / Tips help panel with workflow notes and beginner guidance.'): 'ワークフローの補足と初心者向けガイドを表示するヘルプパネルです。',
           ('*', 'Hard Surface / Boolean'): 'ハードサーフェス / ブーリアン',
           ('*', 'Hard Surface / Weighted Normal'): 'ハードサーフェス / 重み付き法線',
           ('*', 'Helix Path Modifier'): 'ヘリックスパスモディファイア',
           ('*', 'How the generated surface detail box should be used.'): '生成するサーフェスディテール箱の使用方法です。',
           ('*', 'Installed (context-limited)'): '導入済み（現在コンテキスト制限あり）',
           ('*', 'Instances Along Path Modifier'): 'パス配置モディファイア',
           ('*', 'Interpretation'): '見方',
           ('*', 'Join succeeded, but cleanup was skipped because Edit Mode was unavailable.'): '結合は成功しましたが、編集モードへ入れないためクリーンアップはスキップされました。',
           ('*', 'Join succeeded, but returning to Object Mode failed after cleanup.'): '結合は成功しましたが、クリーンアップ後にオブジェクトモードへ戻れませんでした。',
           ('*', "Keep Edit Polygon's live selection and stack callbacks active so helper objects and layer synchronization work immediately.\nON: Edit Poly responds live while you work.\nOFF: disables the live callbacks when you need to troubleshoot or reduce overhead."): 'Edit '
                                                                                                                                                                                                                                                                               'Poly '
                                                                                                                                                                                                                                                                               'のライブ選択とスタック同期コールバックを有効にし、補助オブジェクトとレイヤー同期をすぐ動作させます。\n'
                                                                                                                                                                                                                                                                               'ON：作業中に '
                                                                                                                                                                                                                                                                               'Edit '
                                                                                                                                                                                                                                                                               'Poly '
                                                                                                                                                                                                                                                                               'がリアルタイムで反応します。\n'
                                                                                                                                                                                                                                                                               'OFF：トラブルシュートや負荷軽減が必要な場合にライブコールバックを無効化します。',
           ('*', 'Keep Side'): '残す側',
           ('*', "Keep Smart Lattice's overlay and live depsgraph callbacks active so the lattice overlay and helper synchronization work immediately.\nON: Smart Lattice updates live while you work.\nOFF: disables the live callbacks when you need to troubleshoot or reduce overhead."): 'Smart '
                                                                                                                                                                                                                                                                                              'Lattice '
                                                                                                                                                                                                                                                                                              'のオーバーレイとライブ依存グラフコールバックを有効にし、ラティス表示と補助同期をすぐ動作させます。\n'
                                                                                                                                                                                                                                                                                              'ON：作業中に '
                                                                                                                                                                                                                                                                                              'Smart '
                                                                                                                                                                                                                                                                                              'Lattice '
                                                                                                                                                                                                                                                                                              'がリアルタイムで更新されます。\n'
                                                                                                                                                                                                                                                                                              'OFF：トラブルシュートや負荷軽減が必要な場合にライブコールバックを無効化します。',
           ('*', 'Keep only overlapping volume'): '重なった体積だけを残します。',
           ('*', 'Keep the main modifier stack live callbacks active so selection changes, level switching, and property edits stay in sync.\nON: the stack updates immediately while you work.\nOFF: disables the live callbacks when you need to troubleshoot or reduce overhead.'): 'メインのモディファイアスタックのライブコールバックを有効にし、選択変更、レベル切替、プロパティ編集を同期します。\n'
                                                                                                                                                                                                                                                                                       'ON：作業中にスタックがすぐ更新されます。\n'
                                                                                                                                                                                                                                                                                       'OFF：トラブルシュートや負荷軽減が必要な場合にライブコールバックを無効化します。',
           ('*', 'Keep the negative side of the chosen axis and mirror from it.'): '選択軸の負方向側を残して反転します。',
           ('*', 'Keep the positive side of the chosen axis and mirror from it.'): '選択軸の正方向側を残して反転します。',
           ('*', 'Last Audit Report'): '最終監査レポート',
           ('*', 'Launch the migrated tools from Add Modifier, then adjust their shared defaults here.'): '移行済みツールは『モディファイアを追加』から実行し、共有設定はここで調整します。',
           ('*', 'Layout / Scatter / Replacement'): 'レイアウト / 散布 / 置換',
           ('*', 'Lighter and faster for simpler cases'): '単純なケースで軽量・高速です。',
           ('*', 'Live Runtime'): 'ライブランタイム',
           ('*', 'Load Smart Modifier only when needed and open the Smart Tools N-panel.\nHow to use: choose this from 3D View Sidebar > SmartTools when you want to start working with the modifier stack.\nThis keeps Blender startup and idle performance as light as possible until you actually use the tool.'): '必要になった時だけ '
                                                                                                                                                                                                                                                                                                                            'Smart '
                                                                                                                                                                                                                                                                                                                            'Modifier '
                                                                                                                                                                                                                                                                                                                            'Toolset '
                                                                                                                                                                                                                                                                                                                            'を読み込み、Smart '
                                                                                                                                                                                                                                                                                                                            'Tools '
                                                                                                                                                                                                                                                                                                                            'Nパネルを開きます。\n'
                                                                                                                                                                                                                                                                                                                            '使い方：モディファイアスタックの作業を始めたい時に、3Dビューサイドバー '
                                                                                                                                                                                                                                                                                                                            '> '
                                                                                                                                                                                                                                                                                                                            'SmartTools '
                                                                                                                                                                                                                                                                                                                            'から選択します。\n'
                                                                                                                                                                                                                                                                                                                            '実際に使うまでは、Blender '
                                                                                                                                                                                                                                                                                                                            'の起動時と待機時の負荷をできるだけ軽く保ちます。',
           ('*', 'Loft Modifier'): 'ロフトモディファイア',
           ('*', 'Main compact modifier hub that groups hard-surface, repair, curve, scatter, and workflow entry points in one place.'): 'ハードサーフェス、修復、カーブ、散布、各種入口を1か所にまとめたメインのコンパクトハブです。',
           ('*', "Main modifier stack panel. Add Modifier restores Blender's standard modifier categories and also centralizes the bundled user tools under User so the old side-panel workflows are handled from this stack entry point. Settings are adjusted below the stack."): 'メインのモディファイアスタックパネルです。『モディファイアを追加』では '
                                                                                                                                                                                                                                                                                    'Blender '
                                                                                                                                                                                                                                                                                    '標準カテゴリを復帰しつつ、同梱ユーザーツールも『ユーザー』へ集約するため、旧サイドパネル系ワークフローもこのスタック入口から扱えます。設定調整はスタック下部で行います。',
           ('*', "Main modifier stack panel. Add Modifier restores Blender's standard modifier categories and also centralizes the bundled user tools under User so the old side-panel workflows are handled from this stack entry point. The bundled modifier switcher is shown as a separate panel below this stack."): 'メインのモディファイアスタックパネルです。「モディファイアを追加」では '
                                                                                                                                                                                                                                                                                                                          'Blender '
                                                                                                                                                                                                                                                                                                                          '標準のモディファイアカテゴリを復元し、同梱ユーザーツールも「ユーザー」に集約します。従来のサイドパネル系ワークフローは、このスタック入口から扱えます。同梱のモディファイアスイッチャーは、このスタック下の別パネルに表示されます。',
           ('*', 'Main panel for the modifier switcher helper.'): 'モディファイアスイッチャー補助のメインパネルです。',
           ('*', "Master add menu for Smart Modifier. It restores Blender's standard modifier categories and also exposes the bundled custom tools as split workflow-category menus so migrated functions can be started from one place without an oversized flat User list."): 'Smart '
                                                                                                                                                                                                                                                                                'Modifier '
                                                                                                                                                                                                                                                                                'Toolset '
                                                                                                                                                                                                                                                                                'のマスター追加メニューです。Blender '
                                                                                                                                                                                                                                                                                '標準モディファイアカテゴリを復帰しつつ、同梱の独自ツールもワークフロー別カテゴリへ'
                                                                                                                                                                                                                                                                                'へ分割表示することで、大き過ぎる単一一覧を避けながら1か所から開始できるようにします。',
           ('*', 'Menu'): 'メニュー',
           ('*', 'Mesh Align。'): 'Mesh Align',
           ('*', 'Mesh Auto Mirror'): 'メッシュ自動ミラー',
           ('*', 'Mirror Axis'): 'ミラー軸',
           ('*', 'Mirror across the object local X axis.'): 'オブジェクトのローカル X 軸で対称化します。',
           ('*', 'Mirror across the object local Y axis.'): 'オブジェクトのローカル Y 軸で対称化します。',
           ('*', 'Mirror across the object local Z axis.'): 'オブジェクトのローカル Z 軸で対称化します。',
           ('*', 'Missing'): '未検出',
           ('*', 'Missing companion tools do not break the modifier stack itself.'): '連携ツールが無くても、モディファイアスタック本体が壊れるわけではありません。',
           ('*', 'Missing, fallback path stays available'): '未導入でも代替経路あり',
           ('*', 'Mix factor used by the created Data Transfer modifier.'): '生成する Data Transfer モディファイアで使うミックス係数です。',
           ('*', 'Modifier Stack Display'): 'モディファイアスタック表示',
           ('*', 'Modifier Stack Live Sync'): 'モディファイアスタック ライブ同期',
           ('*', 'Move grouped modifiers up or down together inside the modifier switcher workflow.'): 'モディファイアスイッチャーの流れの中で、グループ化されたモディファイアをまとめて上下移動します。',
           ('*', 'Need an active source mesh and at least one other selected target mesh'): 'アクティブなソースメッシュと、他に1つ以上の選択ターゲットメッシュが必要です。',
           ('*', 'Needs context'): 'コンテキスト調整が必要',
           ('*', 'Negative'): '負',
           ('*', 'No entries matched the current filter.'): '現在のフィルターに一致する項目はありません。',
           ('*', 'No tools are currently available in this group'): '現在このグループで利用できるツールはありません',
           ('*', 'No tools matched the current filter'): '現在のフィルタに一致するツールはありません',
           ('*', 'No user tools are currently available'): '現在利用できるユーザーツールはありません',
           ('*', 'Non-Quads'): '非四角面',
           ('*', 'Normal Mix'): '法線ミックス',
           ('*', 'Normal Transfer Modifier'): '法線転送モディファイア',
           ('*', 'Not detected'): '未検出',
           ('*', 'Object list panel for selecting and batching modifier switcher targets.'): 'モディファイアスイッチャー対象を選択・一括管理するオブジェクト一覧パネルです。',
           ('*', 'Offset used by the shrinkwrap-based surface conform modifier. Useful for decals, kitbash panels, straps, and surface-mounted parts that should stay slightly above the target.'): 'Shrinkwrap '
                                                                                                                                                                                                    'ベースの面追従モディファイアで使うオフセットです。デカール、キットバッシュパネル、ストラップ、面上に少し浮かせたい部品に便利です。',
           ('*', "Open or close the Smart Modifier page in the Properties editor. Use it to switch between the compact modifier workflow and Blender's normal Properties tabs."): 'Properties '
                                                                                                                                                                                  'エディターで '
                                                                                                                                                                                  'Smart '
                                                                                                                                                                                  'Modifier '
                                                                                                                                                                                  'ページを開閉します。コンパクトなモディファイア作業画面と '
                                                                                                                                                                                  'Blender '
                                                                                                                                                                                  '標準の '
                                                                                                                                                                                  'Properties '
                                                                                                                                                                                  'タブを切り替える時に使います。',
           ('*', 'Open or close the Smart Modifier page inside the Properties editor. Use this when you want the compact modifier-stack workspace instead of the standard Properties tabs.'): 'Properties '
                                                                                                                                                                                              'エディター内で '
                                                                                                                                                                                              'Smart '
                                                                                                                                                                                              'Modifier '
                                                                                                                                                                                              'ページを開閉します。標準の '
                                                                                                                                                                                              'Properties '
                                                                                                                                                                                              'タブの代わりに、コンパクトなモディファイアスタック作業画面を使いたい時に使います。',
           ('*', "Open or close the Smart Tools page in the Properties editor. Use it to switch between the compact modifier workflow and Blender's normal Properties tabs."): 'Properties '
                                                                                                                                                                               'エディターで '
                                                                                                                                                                               'Smart '
                                                                                                                                                                               'Tools '
                                                                                                                                                                               'ページを開閉します。コンパクトなモディファイア作業画面と '
                                                                                                                                                                               'Blender '
                                                                                                                                                                               '標準の '
                                                                                                                                                                               'Properties '
                                                                                                                                                                               'タブを切り替える時に使います。',
           ('*', 'Open or close the Smart Tools page inside the Properties editor. Use this when you want the compact modifier-stack workspace instead of the standard Properties tabs.'): 'Properties '
                                                                                                                                                                                           'エディター内で '
                                                                                                                                                                                           'Smart '
                                                                                                                                                                                           'Tools '
                                                                                                                                                                                           'ページを開閉します。標準の '
                                                                                                                                                                                           'Properties '
                                                                                                                                                                                           'タブの代わりに、コンパクトなモディファイアスタック作業画面を使いたい時に使います。',
           ('*', 'Open or reuse the Smart Tools N-panel and lazily load Smart Modifier only when you actually use it.'): 'Smart '
                                                                                                                               'Tools '
                                                                                                                               'Nパネルを開くか再利用し、実際に使う瞬間だけ '
                                                                                                                               'Smart '
                                                                                                                               'Modifier '
                                                                                                                               'Toolset '
                                                                                                                               '本体を遅延読み込みします。',
           ('*', 'Open the Add Modifier popup (see tooltip for beginner-friendly details)'): 'モディファイア追加ポップアップを開きます（初心者向けの詳細はツールチップ参照）',
           ('*', 'Operation failed'): '操作に失敗しました',
           ('*', 'Operator'): 'オペレーター',
           ('*', 'Operator ID'): 'オペレーターID',
           ('*', 'Other'): 'その他',
           ('*', 'Path Modifier'): 'パスモディファイア',
           ('*', 'Pipe Modifier'): 'パイプモディファイア',
           ('*', 'Pivot To Bottom Modifier'): '下端へピボット移動モディファイア',
           ('*', 'Pivot To Selection Modifier'): '選択へピボット移動モディファイア',
           ('*', 'Plugin ID'): 'プラグインID',
           ('*', 'Positive'): '正',
           ('*', 'Precision / CAD / Workplane'): '精密 / CAD / ワークプレーン',
           ('*', 'Preflight report copied'): '診断レポートをコピーしました。',
           ('*', 'Prevent mirrored vertices from crossing the center plane while editing.'): '編集中に反転側頂点が中心面を越えないようにします。',
           ('*', 'Profile Primitive Modifier'): '断面プリミティブモディファイア',
           ('*', 'Project To Active Plane Modifier'): 'アクティブ平面投影モディファイア',
           ('*', 'Project along target directions when supported'): '対応時は対象方向へ投影します。',
           ('*', 'Projection Modifier'): '投影モディファイア',
           ('*', 'Quad Checker Modifier'): 'クアッドチェッカーモディファイア',
           ('*', 'Quads'): '四角面',
           ('*', 'Quick Repair / Cleanup'): 'クイック修復 / クリーンアップ',
           ('*', 'Quick Solidify Modifier'): '厚み付けモディファイア',
           ('*', 'Quick readiness check for internal operators, fallback-aware helpers, and companion tools.'): '内部オペレーター、代替経路付きヘルパー、連携ツールの準備状況をすばやく確認します。',
           ('*', 'Randomize Modifier'): 'ランダム化モディファイア',
           ('*', 'Ready'): '使用可能',
           ('*', 'Ready only'): '実行可能のみ',
           ('*', 'Rebuild Curve Modifier'): 'カーブ再構築モディファイア',
           ('*', 'Refresh'): '更新',
           ('*', 'Registration'): '登録情報',
           ('*', 'Relax Selection'): '選択をリラックス',
           ('*', 'Replace Modifier'): '置換モディファイア',
           ('*', 'Return to Edit Mode after creation so you can continue symmetry cleanup immediately.'): '実行後に編集モードへ戻り、そのまま対称編集を続けられます。',
           ('*', 'Run User Tool'): 'ユーザーツール実行',
           ('*', 'Run a Smart Modifier user tool from the migrated modifier catalog.'): 'Smart Modifier '
                                                                                              'の移行済みモディファイアカタログからユーザーツールを実行します。',
           ('*', 'Run a beautify pass after filling to reduce awkward internal diagonals when Blender can improve them safely.'): 'フィル後に安全に改善できる場合は '
                                                                                                                                  'Beautify '
                                                                                                                                  '処理を実行し、不自然な内部対角線を減らします。',
           ('*', 'Run a stack item action such as reorder, isolate, or maintenance from the Smart Modifier stack UI.'): 'Smart '
                                                                                                                              'Modifier '
                                                                                                                              'Toolset '
                                                                                                                              'のスタック '
                                                                                                                              'UI '
                                                                                                                              'から、並べ替え・分離・保守などのスタック項目アクションを実行します。',
           ('*', 'Run the selected Smart Modifier user tool.'): '選択した Smart Modifier のユーザーツールを実行します。',
           ('*', 'Safer for complex hard-surface intersections'): '複雑なハードサーフェス交差に安全です。',
           ('*', 'Scatter Modifier'): '散布モディファイア',
           ('*', 'Search'): '検索',
           ('*', 'Select every non-quad face.'): 'すべての非四角面を選択します。',
           ('*', 'Select every quad face.'): 'すべての四角面を選択します。',
           ('*', 'Select ngon faces on the active mesh.'): 'アクティブメッシュのNゴン面を選択します。',
           ('*', 'Select only faces with 5 or more sides.'): '5辺以上の面だけを選択します。',
           ('*', 'Select only triangles.'): '三角面だけを選択します。',
           ('*', 'Select triangle faces on the active mesh.'): 'アクティブメッシュの三角面を選択します。',
           ('*', 'Select which side of the axis remains after the cut.'): '切断後に残す側を選びます。',
           ('*', 'Select zero-area faces on the active mesh.'): 'アクティブメッシュの面積ゼロの面を選択します。',
           ('*', 'Separate modifier visibility switcher panel shown below the Modifier Stack panel.'): 'Modifier Stack '
                                                                                                       'パネルの下に表示される、独立したモディファイア表示切替パネルです。',
           ('*', 'Separated selection, but could not switch to Object Mode for final object handoff.'): '分離は完了しましたが、最終オブジェクト選択のためにオブジェクトモードへ切り替えられませんでした。',
           ('*', 'Show a lightweight standalone panel inside the Smart Modifier tab so you can still add/rebake layers without Smart Modifier.\nNormally, managing layers from Smart Modifier is recommended. Turn this ON only when you want standalone operation.'): 'Smart '
                                                                                                                                                                                                                                                                                   'Modifier '
                                                                                                                                                                                                                                                                                   'Toolset '
                                                                                                                                                                                                                                                                                   'が無い環境でもレイヤーの追加 '
                                                                                                                                                                                                                                                                                   '/ '
                                                                                                                                                                                                                                                                                   '再計算を行えるように、Smart '
                                                                                                                                                                                                                                                                                   'Modifier '
                                                                                                                                                                                                                                                                                   'タブ内へ軽量な単体パネルを表示します。\n'
                                                                                                                                                                                                                                                                                   '通常は '
                                                                                                                                                                                                                                                                                   'Smart '
                                                                                                                                                                                                                                                                                   'Modifier '
                                                                                                                                                                                                                                                                                   'Toolset '
                                                                                                                                                                                                                                                                                   'からレイヤー管理することを推奨します。単体運用したい場合だけ '
                                                                                                                                                                                                                                                                                   'ON '
                                                                                                                                                                                                                                                                                   'にしてください。',
           ('*', 'Show a lightweight standalone panel inside the Smart Modifier tab so you can still use Smart Lattice without Smart Modifier.\nNormally, managing it from Smart Modifier is recommended. Turn this ON only for standalone use.'): 'Smart '
                                                                                                                                                                                                                                                               'Modifier '
                                                                                                                                                                                                                                                               'Toolset '
                                                                                                                                                                                                                                                               'が無い環境でも '
                                                                                                                                                                                                                                                               'Smart '
                                                                                                                                                                                                                                                               'Lattice '
                                                                                                                                                                                                                                                               'を使えるように、Smart '
                                                                                                                                                                                                                                                               'Modifier '
                                                                                                                                                                                                                                                               'タブ内へ軽量な単体パネルを表示します。\n'
                                                                                                                                                                                                                                                               '通常は '
                                                                                                                                                                                                                                                               'Smart '
                                                                                                                                                                                                                                                               'Modifier '
                                                                                                                                                                                                                                                               'Toolset '
                                                                                                                                                                                                                                                               'から管理することを推奨します。単体運用したい場合だけ '
                                                                                                                                                                                                                                                               'ON '
                                                                                                                                                                                                                                                               'にしてください。',
           ('*', 'Show compact context hints and live blocker summaries for tools that are currently missing or context-limited.'): '現在未検出またはコンテキスト不足のツールに、短いヒントと現在の不足条件を表示します。',
           ('*', 'Show hints'): 'ヒント表示',
           ('*', 'Show only tools whose operators are currently available, runnable, and pass the current context checks.'): '現在利用可能で実行可能、かつ現在のコンテキストチェックを通過するツールだけ表示します。',
           ('*', 'Show standalone panel in Smart Modifier tab'): 'Smart Modifier タブに単体パネルを表示',
           ('*', 'Show the base object at the bottom and place modifiers above it.'): 'ベースオブジェクトを下に表示し、上方向へモディファイアを並べます。',
           ('*', 'Show the base object at the top and place modifiers below it.'): 'ベースオブジェクトを上に表示し、下方向へモディファイアを並べます。',
           ('*', 'Shrinkwrap mode used by Surface Conform Modifier.'): 'Surface Conform Modifier で使う Shrinkwrap の方式です。',
           ('*', 'Slice Panel Modifier'): 'スライスパネルモディファイア',
           ('*', 'Smart Extrude Modifier'): 'スマート押し出しモディファイア',
           ('*', 'Smart Fill Modifier'): 'スマート面張りモディファイア',
           ('*', 'Smart Lattice'): 'スマートラティス',
           ('*', 'Smart Lattice Live Sync'): 'Smart Lattice ライブ同期',
           ('*', 'Smart Modeling companion'): 'Smart Modeling 連携',
           ('*', 'Smart Modifier Hub panel in the Smart Modifier workspace.'): 'Smart Modifier ワークスペース内の Smart '
                                                                               'Modifier Hub パネルです。',
           ('*', 'Smart Modifier Preflight'): 'Smart Modifier 事前診断',
           ('*', 'Smart Modifier Tool'): 'Smart Modifier ツール',
           ('*', 'Smart Modifier Tool Browser Report'): 'Smart Modifier ツールブラウザーレポート',
           ('*', 'Smart Tools N-panel could not be opened.'): 'Smart Tools Nパネルを開けませんでした。',
           ('*', 'Snap to the nearest point on the target surface'): '対象面の最近接点へ追従します。',
           ('*', 'Solo Selected Modifier'): '選択ソロモディファイア',
           ('*', 'Stack Selected Modifier'): '選択スタック配置モディファイア',
           ('*', 'Stack along world X.'): 'ワールドX方向にスタック配置します。',
           ('*', 'Stack along world Y.'): 'ワールドY方向にスタック配置します。',
           ('*', 'Stack along world Z.'): 'ワールドZ方向にスタック配置します。',
           ('*', 'Standalone panel for Edit Polygon Modifier when it is used outside the main Smart Modifier stack.'): 'Edit '
                                                                                                                          'Poly '
                                                                                                                          'Modifier '
                                                                                                                          'を '
                                                                                                                          'Smart '
                                                                                                                          'Modifier '
                                                                                                                          'Toolset '
                                                                                                                          '本体外で使うときの単独パネルです。',
           ('*', 'Standalone panel for Smart Lattice Modifier when it is used outside the main Smart Modifier stack.'): 'Smart '
                                                                                                                              'Lattice '
                                                                                                                              'Modifier '
                                                                                                                              'を '
                                                                                                                              'Smart '
                                                                                                                              'Modifier '
                                                                                                                              'Toolset '
                                                                                                                              '本体外で使うときの単独パネルです。',
           ('*', 'Stay in Edit Mode'): '編集モードを維持',
           ('*', 'Stores settings for the Advanced / Surface Modeling panel.'): 'Advanced / Surface Modeling '
                                                                                'パネル用の設定を保持します。',
           ('*', 'Stores settings for the Advanced / Surface Modeling panel. / Advanced'): 'Surface Modeling '
                                                                                           'パネル用の設定を保持します。',
           ('*', 'Stores settings used by the Precision / Layout / Path operators and their Add Modifier entry points.'): 'Precision '
                                                                                                                          '/ '
                                                                                                                          'Layout '
                                                                                                                          '/ '
                                                                                                                          'Path '
                                                                                                                          'オペレーターと「モディファイアを追加」側の実行設定を保持します。',
           ('*', 'Stores settings used by the Precision / Layout / Path operators and their Add Modifier entry points. / Precision / Layout'): 'Path '
                                                                                                                                               '系オペレーターおよび『モディファイアを追加』側の実行設定を保持します。',
           ('*', 'Stores settings used by the Smart Modifier Hub operators and their Add Modifier entry points.'): 'Smart '
                                                                                                                   'Modifier '
                                                                                                                   'Hub '
                                                                                                                   '系オペレーターおよび『モディファイアを追加』側の実行設定を保持します。',
           ('*', 'Stores the latest compact mesh audit summary for display in the panel.'): 'パネル表示用の最新の簡易メッシュ監査サマリーを保持します。',
           ('*', 'Straighten Modifier'): '直線化モディファイア',
           ('*', 'Subtract cutters from the target'): 'カッターをターゲットから差し引きます。',
           ('*', 'Surface / Conform'): '面追従',
           ('*', 'Surface / Conform / Normals'): '面追従 / 法線',
           ('*', 'Surface Box Detail Modifier'): '面ボックスディテールモディファイア',
           ('*', 'Surface Conform Modifier'): '面追従モディファイア',
           ('*', 'Sweep Modifier'): 'スイープモディファイア',
           ('*', 'Switch an always-on feature on or off. N-panel State Save controls whether the change is saved immediately or deferred.'): '常時発動機能の有効 / '
                                                                                             '無効を切り替え、設定を即時保存します。',
           ('*', 'Symmetry Modifier'): 'シンメトリモディファイア',
           ('*', 'Toggle Feature'): '機能を切り替え',
           ('*', 'Toggle the enabled/disabled state of many modifiers at once inside the modifier switcher workflow.'): 'モディファイアスイッチャーの流れの中で、多数のモディファイアの有効 '
                                                                                                                        '/ '
                                                                                                                        '無効を一括切り替えします。',
           ('*', 'Tool Browser now includes live blocker summaries so invalid mode / selection setups are easier to fix before running tools.'): 'Tool '
                                                                                                                                                 'Browser '
                                                                                                                                                 'では現在の不足条件も表示されるため、実行前にモードや選択の不足を直しやすくなりました。',
           ('*', 'Tool browser report copied'): 'ツールブラウザーレポートをコピーしました。',
           ('*', 'Topology / Repair'): 'トポロジー / 修復',
           ('*', 'Try Grid Fill early when a single boundary loop is selected so patch results stay quad-friendly when possible.'): '単一の境界ループが選択されている場合は早めに '
                                                                                                                                    'Grid '
                                                                                                                                    'Fill '
                                                                                                                                    'を試し、可能な範囲で四角面に向いたパッチ結果にします。',
           ('*', 'Use Clipping'): 'クリッピングを使う',
           ('*', 'Use Tool Browser / Search to inspect grouped per-tool readiness and context hints. / Tool Browser'): 'Search '
                                                                                                                       'で各ツールの状態と前提ヒントを確認できます。',
           ('*', 'User'): 'ユーザー',
           ('*', 'User Tool Settings'): 'ユーザーツール設定',
           ('*', 'Vertices Path Modifier'): '頂点パスモディファイア',
           ('*', 'Vertices close to the cut plane are treated as center-line vertices.'): '切断面に近い頂点を中央線頂点として扱います。',
           ('*', 'Weight'): 'ウェイト',
           ('*', 'Weight by both face area and corner angle.'): '面積と角度の両方で重み付けします。',
           ('*', 'Weight by corner angle.'): '角度で重み付けします。',
           ('*', 'Weight by face area.'): '面積で重み付けします。',
           ('*', 'Weighted Normal'): '重み付き法線',
           ('*', 'Weighted Normal mode used by the modifier when Blender exposes the option.'): 'Blender '
                                                                                                'が項目を公開している場合に、モディファイアで使用する '
                                                                                                'Weighted Normal '
                                                                                                'モードです。',
           ('*', 'Where fallback routes exist, the suite keeps safer built-in alternatives active.'): '代替経路がある箇所は、より安全な標準機能へフォールバックします。',
           ('*', 'Window manager is not available.'): 'ウィンドウマネージャーを利用できません。',
           ('*', 'Workplane Modifier'): 'ワークプレーンモディファイア',
           ('*', '• Floor placement: Drop To Floor snaps selected objects to a shared floor height without needing a surface target.'): '• '
                                                                                                                                        '床配置: '
                                                                                                                                        'Drop '
                                                                                                                                        'To '
                                                                                                                                        'Floor '
                                                                                                                                        'は、面ターゲットを使わずに選択オブジェクトを共通の床高へスナップします。',
           ('*', '• Retopo / repair: Smart Fill → Quick Repair / Cleanup → Smart Vertex Slide / Mesh Align.'): '• リトポ '
                                                                                                               '/ 修復: '
                                                                                                               'Smart '
                                                                                                               'Fill → '
                                                                                                               'Quick '
                                                                                                               'Repair '
                                                                                                               '/ '
                                                                                                               'Cleanup '
                                                                                                               '→ '
                                                                                                               'Smart '
                                                                                                               'Vertex '
                                                                                                               'Slide '
                                                                                                               '/ Mesh '
                                                                                                               'Align '
                                                                                                               'で整理します。',
           ('*', '• Shading weld: Normal Transfer Modifier keeps floating details visually welded to the active source.'): '• '
                                                                                                                           '陰影の一体化: '
                                                                                                                           'Normal '
                                                                                                                           'Transfer '
                                                                                                                           'Modifier '
                                                                                                                           'で浮かせた部品の陰影をアクティブなソースへ揃えられます。',
           ('*', '• Surface conform: Surface Conform Modifier adds shrinkwrap-style follow and optional normal transfer.'): '• '
                                                                                                                            '面追従: '
                                                                                                                            'Surface '
                                                                                                                            'Conform '
                                                                                                                            'Modifier '
                                                                                                                            'で '
                                                                                                                            'Shrinkwrap '
                                                                                                                            '追従と任意の法線転送を追加できます。',
           ('*', '• Topology spot-check: Quad Checker highlights quads / non-quads / tris / ngons before bevel, export, or subdivision.'): '• '
                                                                                                                                           'トポロジー確認: '
                                                                                                                                           'Quad '
                                                                                                                                           'Checker '
                                                                                                                                           'は、ベベル、書き出し、サブディビジョン前に四角面 '
                                                                                                                                           '/ '
                                                                                                                                           '非四角面 '
                                                                                                                                           '/ '
                                                                                                                                           '三角面 '
                                                                                                                                           '/ '
                                                                                                                                           'Nゴンを強調表示します。'}}

# Centralized supplemental translation_catalogs for lazily registered panels, operators,
# properties, enum items, reports, and tooltips. Keeping these in the root
# dictionary prevents English-only fallback before deferred modules register.
translation_catalog_dict.setdefault('ja_JP', {}).update(
{('*', '* For stack management, please use Smart Modifier.'): '※スタック管理は Smart Modifierをご利用ください',
 ('*', '* Please use Smart Modifier for layer management.'): '※スタック管理は Smart Modifierをご利用ください',
 ('*', '2 x 3 x 2'): '2 x 3 x 2',
 ('*', 'Actions'): '操作',
 ('*', 'Active Collection'): 'アクティブコレクション',
 ('*', 'Active Only'): 'アクティブのみ',
 ('*', 'Active curve and at least one source object are required'): 'アクティブカーブと少なくとも1つのソースオブジェクトが必要です',
 ('*', 'Active curve required'): 'アクティブカーブが必要です',
 ('*', 'Active mesh object required'): 'アクティブなメッシュオブジェクトが必要です',
 ('*', 'Active mesh object with a usable footprint is required'): '有効な占有範囲を持つアクティブなメッシュオブジェクトが必要です',
 ('*', 'Active path curve and one selected profile curve are required'): 'アクティブなパスカーブと、選択された1本のプロファイルカーブが必要です',
 ('*', 'Add Edit Poly'): '編集ポリゴンを追加',
 ('*', 'Add Edit Poly Layer'): '編集ポリゴンレイヤーを追加',
 ('*', 'Add Helix Path'): 'ヘリックスパスを追加',
 ('*', 'Add Profile Primitive'): '断面プリミティブを追加',
 ('*', 'Add Smart Lattice'): 'Smart Latticeを追加',
 ('*', 'Add Smart Lattice (a helper system that makes lattice deformation easier) to the selected mesh.\n\n- Automatically creates a Lattice and the required helper objects/collections.\n- Places the lattice to fit the mesh size.\n- Lets you choose the resolution (U/V/W divisions) to control deformation detail.\n\nTip: Higher resolution is heavier—start low and increase only if needed.'): '選択中のメッシュに '
                                                                                                                                                                                                                                                                                                                                                                                                        'Smart '
                                                                                                                                                                                                                                                                                                                                                                                                        'Lattice（ラティス変形を扱いやすくする補助システム）を追加します。\n'
                                                                                                                                                                                                                                                                                                                                                                                                        '\n'
                                                                                                                                                                                                                                                                                                                                                                                                        '・自動で '
                                                                                                                                                                                                                                                                                                                                                                                                        'Lattice '
                                                                                                                                                                                                                                                                                                                                                                                                        'と必要な補助オブジェクト/コレクションを作成します。\n'
                                                                                                                                                                                                                                                                                                                                                                                                        '・メッシュの大きさに合わせてラティスを配置します。\n'
                                                                                                                                                                                                                                                                                                                                                                                                        '・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n'
                                                                                                                                                                                                                                                                                                                                                                                                        '\n'
                                                                                                                                                                                                                                                                                                                                                                                                        'ヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。',
 ('*', 'Add a Weighted Normal modifier after the hard-surface stack for cleaner shading.'): 'ハードサーフェススタックの最後に Weighted '
                                                                                            'Normal を追加し、シェーディングを整えます。',
 ('*', 'Add a non-destructive shrinkwrap-based conform setup to the selected detail meshes so they follow the active surface. This is useful for kitbash details, decals, trim pieces, and surface-mounted parts inspired by xyShrinkWrap, Polystein Kit, NitroDraw, and similar surface placement workflows.'): '選択したディテールメッシュへ、Shrinkwrapベースの非破壊追従設定を追加し、アクティブ面に沿わせます。キットバッシュ部品、デカール的な貼り物、トリム、面上に載せる機械パーツなど、xyShrinkWrap、Polystein '
                                                                                                                                                                                                                                                                                                                 'Kit、NitroDraw '
                                                                                                                                                                                                                                                                                                                 '系ワークフローを意識した機能です。',
 ('*', 'Add a support bevel modifier after the boolean stack to stabilize highlights in hard-surface workflows.'): 'ブーリアン後に補助ベベルモディファイアを追加し、ハードサーフェスでハイライトを安定させます。',
 ('*', "Add an Edit Polygon layer to the selected object(s).\n\n- Automatically manages 'Frozen' (base) and 'Edit' (result) so you can edit deltas non-destructively.\n- Layers stack from top to bottom, letting you keep lower layers while adding more edits.\n\nUsage: After adding, make the layer active and edit in Edit Mode.\nUse 'Rebake All Layers' if you need to resync."): '選択したオブジェクトに '
                                                                                                                                                                                                                                                                                                                                                                                      'Edit '
                                                                                                                                                                                                                                                                                                                                                                                      'Poly '
                                                                                                                                                                                                                                                                                                                                                                                      'レイヤーを追加します。\n'
                                                                                                                                                                                                                                                                                                                                                                                      '\n'
                                                                                                                                                                                                                                                                                                                                                                                      '・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n'
                                                                                                                                                                                                                                                                                                                                                                                      '・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n'
                                                                                                                                                                                                                                                                                                                                                                                      '\n'
                                                                                                                                                                                                                                                                                                                                                                                      '使い方：追加後はレイヤーをアクティブにして '
                                                                                                                                                                                                                                                                                                                                                                                      'Edit '
                                                                                                                                                                                                                                                                                                                                                                                      'モードで編集してください。\n'
                                                                                                                                                                                                                                                                                                                                                                                      '必要なら『全レイヤー再計算』で整合を取り直せます。',
 ('*', 'Add an EditPoly layer to selected objects. You edit by adding a displacement offset on top of the evaluated result of the modifiers above. With multiple selection, it adds as an instance (same name/settings) and immediately enters multi-object Edit Mode.'): '選択オブジェクトにEditPolyレイヤーを追加します。上（手前）階層のモディファイア適用済み形状を基準に、差分（オフセット）を加算して編集できます。複数選択時はインスタンスとして同名で追加し、追加直後に複数オブジェクト編集モードへ入ります。',
 ('*', 'Additional uniform multiplier applied after face-based scaling.'): '面基準のスケーリング後に適用する追加の一様倍率です。',
 ('*', 'Advanced'): '高度な操作',
 ('*', 'Advanced / Surface Modeling'): '高度 / サーフェスモデリング',
 ('*', 'Advanced Surface / Deform'): '高度サーフェス / デフォーム',
 ('*', 'Affect Flags'): '反映フラグ',
 ('*', 'Affect X'): 'X を反映',
 ('*', 'Affect Y'): 'Y を反映',
 ('*', 'Affect Z'): 'Z を反映',
 ('*', "Affect the modifier's 'On Cage' flag when applying operations.\nThis is mainly meaningful for deforming modifiers in Edit Mode."): '操作を実行するときにモディファイアの「ケージ '
                                                                                                                                           '(On '
                                                                                                                                           'Cage)」フラグも変更します。\n'
                                                                                                                                           '主に編集モードで変形系モディファイアを使う場合に意味があります。',
 ('*', "Affect the modifier's 'Show in Edit Mode' flag when applying operations.\nUseful for deforming modifiers you want active while editing the mesh."): '操作を実行するときにモディファイアの「編集モードで表示」フラグも変更します。\n'
                                                                                                                                                            '編集しながら変形結果を見たいときに便利です。',
 ('*', "Affect the modifier's Render visibility flag when applying operations.\nTurn this ON if you want changes to affect final renders as well."): '操作を実行するときにモディファイアの「レンダー」フラグも変更します。\n'
                                                                                                                                                     '最終レンダーにも反映したい場合はONにしてください。',
 ('*', "Affect the modifier's Viewport visibility flag when applying operations.\nThis does NOT toggle the modifier by itself; it defines which flags\nare changed by Enable/Disable/Invert and State Sets."): '操作を実行するときにモディファイアの「ビューポート」フラグも変更します。\n'
                                                                                                                                                                                                               'このボタン自体はモディファイアを切り替えません。どのフラグを変更対象にするかを指定します。\n'
                                                                                                                                                                                                               '有効/無効/反転やステートセット適用時に、このフラグが変更されます。',
 ('*', 'After building the workplane, switch the active transform orientation to Cursor when supported.'): 'ワークプレーン作成後、可能であればアクティブ変換方向を '
                                                                                                           'Cursor '
                                                                                                           'に切り替えます。',
 ('*', 'After building the workplane, switch the transform pivot to the 3D cursor for immediate local editing.'): 'ワークプレーン作成後、変換ピボットを3Dカーソルへ切り替え、すぐローカル編集できるようにします。',
 ('*', 'Align Location'): '位置を整列',
 ('*', 'Align Rotation'): '回転を整列',
 ('*', 'Align Scale'): 'スケールを整列',
 ('*', 'Align To Active'): 'アクティブへ整列',
 ('*', 'Align To Surface Normal'): '面法線に揃える',
 ('*', 'Align dropped objects so their local Z follows the hit surface normal.'): 'ドロップ後、オブジェクトのローカル Z をヒット面法線に揃えます。',
 ('*', 'Align scattered instances to the surface normal.'): '散布インスタンスを面法線方向へ揃えます。',
 ('*', 'Align the selected objects to the active object using per-channel toggles for location, rotation, and scale. Useful for 3ds Max style align workflows, layout cleanup, and archviz placement passes.'): '位置・回転・スケールの各チャンネル切替を使って、選択オブジェクトをアクティブオブジェクトへ整列します。3ds '
                                                                                                                                                                                                                'Max '
                                                                                                                                                                                                                '風の '
                                                                                                                                                                                                                'Align '
                                                                                                                                                                                                                'ワークフロー、レイアウト整理、Archviz '
                                                                                                                                                                                                                'の配置調整に便利です。',
 ('*', 'Align to Surface'): '面法線に揃える',
 ('*', 'Aligned selected objects to the active object'): '選択オブジェクトをアクティブオブジェクトへ整列しました',
 ('*', 'All'): '全て',
 ('*', 'All objects in the scene'): 'シーン内の全オブジェクト',
 ('*', 'Allow the Cast modifier to affect the local X direction.'): 'Cast モディファイアがローカル X 方向へ作用するようにします。',
 ('*', 'Allow the Cast modifier to affect the local Y direction.'): 'Cast モディファイアがローカル Y 方向へ作用するようにします。',
 ('*', 'Allow the Cast modifier to affect the local Z direction.'): 'Cast モディファイアがローカル Z 方向へ作用するようにします。',
 ('*', "Also affect the UI expanded/collapsed state of the modifier in Blender's\nmodifier panel (triangle open/closed). Useful to tidy long stacks."): '操作を実行するときに、Blenderのモディファイアパネルの展開/折りたたみ状態も変更します。\n'
                                                                                                                                                        '長いスタックを整理したいときに便利です。',
 ('*', 'Also recalculate normals during the cleanup pass.'): 'クリーンアップ時に法線再計算も行います。',
 ('*', 'Amount used by the Taper deformer. Positive and negative values widen or narrow opposite sides.'): 'Taper '
                                                                                                           'デフォーマで使う量です。正負で広がる側と絞られる側が変わります。',
 ('*', 'Analyze the active or selected mesh objects and summarize common production risks such as non-manifold edges, loose elements, ngons, degenerate geometry, and possible doubles. Inspired by 3D Print Toolbox style validation.'): 'アクティブまたは選択メッシュを解析し、非多様体辺、ルーズ要素、N '
                                                                                                                                                                                                                                          'ゴン、退化ジオメトリ、重複候補などの典型的な制作上のリスクを要約します。3D '
                                                                                                                                                                                                                                          'Print '
                                                                                                                                                                                                                                          'Toolbox '
                                                                                                                                                                                                                                          '系の検証を意識した監査です。',
 ('*', 'Angle in degrees applied by the Bend deformer. Positive and negative values bend in opposite directions.'): 'Bend '
                                                                                                                    'デフォーマで適用する角度です。正負で曲がる向きが変わります。',
 ('*', 'Angle in degrees applied by the Twist deformer. Positive and negative values twist in opposite directions.'): 'Twist '
                                                                                                                      'デフォーマで適用する角度です。正負でねじる方向が変わります。',
 ('*', 'Applied Objects'): '適用オブジェクト一覧',
 ('*', 'Applied state set: {}'): '状態セットを適用しました: {}',
 ('*', 'Apply (bake) the matching modifiers for all objects in the current scope.\nThis permanently changes geometry and removes the applied modifiers afterward.\nBeginner tip: If you only want to preview, use OFF/ON instead. Duplicate objects before applying if needed.'): '指定範囲の全オブジェクトで一致するモディファイアを適用（ベイク）します。\n'
                                                                                                                                                                                                                                                                                  '形状が確定し、適用したモディファイアは削除されます。\n'
                                                                                                                                                                                                                                                                                  '初心者ヒント：プレビューだけならON/OFFを使い、必要なら複製してから適用してください。',
 ('*', 'Apply (bake) the matching modifiers for all objects in the current scope.\nThis permanently changes geometry. Consider duplicating objects first.'): '指定範囲の全オブジェクトで一致するモディファイアを適用（ベイク）します。\n'
                                                                                                                                                             '形状が確定する破壊的操作です。必要なら複製してから実行してください。',
 ('*', 'Apply Modifiers'): '適用',
 ('*', 'Apply controlled random location / rotation / uniform scale variation to the selected objects for faster environment dressing and layout iteration.'): '選択オブジェクトへ、位置・回転・一様スケールの制御されたランダム差分を適用します。環境レイアウトやドレッシングの試行を高速化できます。',
 ('*', 'Apply matching modifiers (scope). This is destructive.'): '一致するモディファイアを適用します(指定範囲)。破壊的操作です。',
 ('*', 'Apply or refresh a Weighted Normal modifier on the selected mesh objects for cleaner hard-surface shading. Works well after boolean, bevel, or kitbash-style detail stacking and keeps the modifier stack editable.'): '選択メッシュへ '
                                                                                                                                                                                                                               'Weighted '
                                                                                                                                                                                                                               'Normal '
                                                                                                                                                                                                                               'モディファイアを適用または更新し、ハードサーフェスの陰影を整えます。ブーリアン、ベベル、キットバッシュ的な積層後に有効で、スタックも編集可能なまま保てます。',
 ('*', 'Apply selected state set'): '選択中の状態セットを適用します',
 ('*', 'Array Along Curve'): 'カーブに沿って配列',
 ('*', 'Array Count'): '配列数',
 ('*', 'Array Offset X'): '配列オフセット X',
 ('*', 'Audit + Repair'): '監査 + 修復',
 ('*', 'Audit + Repair complete'): '監査 + 修復が完了しました',
 ('*', 'Audit Merge Distance'): '監査結合距離',
 ('*', 'Audit Selected'): '選択を監査',
 ('*', 'Audit complete'): '監査が完了しました',
 ('*', 'Auto Bevel'): '自動ベベル',
 ('*', 'Auto Refresh'): '自動更新',
 ('*', 'Auto Weighted Normal'): '自動重み付き法線',
 ('*', "Automatically rebuild the Modifier/Object lists while you work.\nTurn this OFF in heavy scenes and use 'Update' manually when needed."): '作業中にモディファイア/オブジェクトのリストを自動で更新します。\n'
                                                                                                                                                 '重いシーンではOFFにして、必要なときだけ「更新」を押すと軽くなります。',
 ('*', 'Axis Slice Edit'): '軸スライス編集',
 ('*', 'Axis and source side used by the symmetry operator.'): '対称処理で使う軸とコピー元側を指定します。',
 ('*', 'Axis slice complete'): '軸スライスが完了しました',
 ('*', 'Axis used to distribute slice helper boxes across the active mesh bounds.'): 'アクティブメッシュ範囲にスライス補助ボックスを並べる軸です。',
 ('*', 'Base radius of the generated helix path.'): '生成するヘリックスパスの基本半径です。',
 ('*', 'Batch modifier management tool. Supports multi-language tooltips. Launched from the N-panel.'): 'モディファイアの一括管理ツール。多言語ツールチップ対応。Nパネルから起動',
 ('*', 'Begin with the compact hub, then dive into the specialized tools only when you need deeper control.'): 'まずはコンパクトなハブから始め、より深い制御が必要なときだけ専門ツールへ進むのがおすすめです。',
 ('*', 'Bend Angle (deg)'): 'ベンド角度（度）',
 ('*', 'Bend Axis'): 'ベンド軸',
 ('*', 'Bend Lower Limit'): 'ベンド下限',
 ('*', 'Bend Upper Limit'): 'ベンド上限',
 ('*', 'Bevel Segments'): 'ベベル分割数',
 ('*', 'Bevel Width'): 'ベベル幅',
 ('*', 'Bevel depth applied to the generated pipe curve.'): '生成されるパイプカーブに設定するベベル深度です。',
 ('*', 'Bisect the active edit mesh by one or more evenly spaced local axis planes. Useful for SliceIt XYZ / Slicer style numeric cuts, panel segmentation, contour prep, and quick retopo guides.'): 'アクティブな編集メッシュを、ローカル軸に沿った等間隔の1枚以上の平面で分割します。SliceIt '
                                                                                                                                                                                                      'XYZ '
                                                                                                                                                                                                      '/ '
                                                                                                                                                                                                      'Slicer '
                                                                                                                                                                                                      '系の数値カット、パネル分割、等高線準備、簡易リトポガイドに便利です。',
 ('*', 'Board Axis'): '板方向',
 ('*', 'Boards X'): 'X方向',
 ('*', 'Boards Y'): 'Y方向',
 ('*', 'Boards run mainly along the local X axis'): '床板を主にローカル X 軸方向へ走らせます。',
 ('*', 'Boards run mainly along the local Y axis'): '床板を主にローカル Y 軸方向へ走らせます。',
 ('*', 'Boolean Operation'): 'ブーリアン演算',
 ('*', 'Boolean solver used for newly created modifiers. Exact is safer for complex intersections; Fast is lighter.'): '新規Booleanモディファイアに使用するソルバーです。複雑な交差には '
                                                                                                                       'Exact '
                                                                                                                       'が安全で、Fast '
                                                                                                                       'は軽量です。',
 ('*', 'Bridge Edge Loops'): 'Bridge Edge Loops',
 ('*', 'Build HS Boolean Stack'): 'HSブーリアンスタック構築',
 ('*', 'Build a cursor-based local workplane from the active face or selected edge. Useful for Modo-style Workplane / Action Center style editing on angled surfaces.'): 'アクティブ面または選択辺から、カーソル基準のローカルワークプレーンを作成します。Modo '
                                                                                                                                                                         'の '
                                                                                                                                                                         'Workplane '
                                                                                                                                                                         '/ '
                                                                                                                                                                         'Action '
                                                                                                                                                                         'Center '
                                                                                                                                                                         'のように、傾いた面での精密編集に便利です。',
 ('*', 'Build an Array + Curve modifier stack on the active mesh using the selected curve as the path. Useful for RailClone-like repetition, trims, railing, modular walls, and architectural detailing.'): '選択カーブをパスとして、アクティブメッシュに '
                                                                                                                                                                                                            'Array '
                                                                                                                                                                                                            '+ '
                                                                                                                                                                                                            'Curve '
                                                                                                                                                                                                            'モディファイア構成を自動作成します。RailClone '
                                                                                                                                                                                                            '的な反復、トリム、手すり、モジュラー壁、建築ディテールに便利です。',
 ('*', 'CAD Intersect / Extend'): 'CAD 交点 / 延長',
 ('*', 'CAD Mode'): 'CAD モード',
 ('*', 'Cast Factor'): 'Cast 係数',
 ('*', 'Cast Radius'): 'Cast 半径',
 ('*', 'Cast Type'): 'Cast 種類',
 ('*', 'Cast setup complete'): 'Cast セットアップが完了しました',
 ('*', 'Change the N-panel tab name'): 'Nパネルのタブ名を変更します',
 ('*', 'Change the end radius relative to the start radius. Negative values tighten the spiral; positive values widen it.'): '開始半径に対して終端半径を変化させます。負の値で先細り、正の値で末広がりになります。',
 ('*', 'Choose how cutter meshes affect the active target mesh.'): 'カッターメッシュがアクティブターゲットへ与える演算方法を選びます。',
 ('*', 'Choose how selected detail meshes should conform to the active surface.'): '選択ディテールメッシュをアクティブ面へどのように追従させるかを選びます。',
 ('*', 'Choose how targets are grouped in the Modifier List:\n- Type: one entry per modifier type (Mirror, Bevel, ...)\n- Name: one entry per modifier name (Bevel.001, ...)\nTip: Use Type for quick global toggles; use Name to distinguish duplicates.'): 'モディファイアリストのターゲットをどの単位でまとめるかを選びます。\n'
                                                                                                                                                                                                                                                             '- '
                                                                                                                                                                                                                                                             'タイプ: '
                                                                                                                                                                                                                                                             'Mirror '
                                                                                                                                                                                                                                                             '/ '
                                                                                                                                                                                                                                                             'Bevel '
                                                                                                                                                                                                                                                             'など種類ごと\n'
                                                                                                                                                                                                                                                             '- '
                                                                                                                                                                                                                                                             '名前: '
                                                                                                                                                                                                                                                             'Bevel.001 '
                                                                                                                                                                                                                                                             'などモディファイア名ごと\n'
                                                                                                                                                                                                                                                             'ヒント: '
                                                                                                                                                                                                                                                             'ざっくり切り替えるなら「タイプ」、複数コピーを区別するなら「名前」。',
 ('*', 'Choose whether boards mainly run along the local X axis or Y axis of the active object.'): '床板がアクティブオブジェクトのローカル '
                                                                                                   'X 軸方向か Y '
                                                                                                   '軸方向のどちらへ主に伸びるかを選びます。',
 ('*', 'Choose whether to insert an intersection point or extend the selected endpoints to the resolved meeting point.'): '交点を挿入するか、選択端点を解決された交点まで延長するかを選びます。',
 ('*', 'Choose which audit issue type should be selected on the active mesh.'): 'アクティブメッシュ上でどの監査問題タイプを選択するかを選びます。',
 ('*', 'Choose which face type to select on the active edit mesh.'): 'アクティブ編集メッシュ上で選択するフェース種別を選びます。',
 ('*', 'Choose which objects are listed and affected by operations:\n- Scene: all objects in the current scene\n- Selected: currently selected objects\n- Selected + Children: selected objects and their children\n- Active Collection: objects in the active collection\n- Collection: objects in a specific collection (set below)\nTip: Start with Selected to avoid changing unintended objects.'): '操作対象となるオブジェクト範囲を選びます。\n'
                                                                                                                                                                                                                                                                                                                                                                                                         '- '
                                                                                                                                                                                                                                                                                                                                                                                                         'シーン: '
                                                                                                                                                                                                                                                                                                                                                                                                         '現在のシーン内の全オブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                         '- '
                                                                                                                                                                                                                                                                                                                                                                                                         '選択: '
                                                                                                                                                                                                                                                                                                                                                                                                         '選択中のオブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                         '- '
                                                                                                                                                                                                                                                                                                                                                                                                         '選択＋子: '
                                                                                                                                                                                                                                                                                                                                                                                                         '選択中とその子オブジェクト\n'
                                                                                                                                                                                                                                                                                                                                                                                                         '- '
                                                                                                                                                                                                                                                                                                                                                                                                         'アクティブコレクション: '
                                                                                                                                                                                                                                                                                                                                                                                                         'アクティブなコレクション内\n'
                                                                                                                                                                                                                                                                                                                                                                                                         '- '
                                                                                                                                                                                                                                                                                                                                                                                                         'コレクション: '
                                                                                                                                                                                                                                                                                                                                                                                                         '指定したコレクション内\n'
                                                                                                                                                                                                                                                                                                                                                                                                         'ヒント: '
                                                                                                                                                                                                                                                                                                                                                                                                         'まずは「選択」から始めると事故が起きにくいです。',
 ('*', 'Choose which reusable 2D curve profile to create at the 3D cursor.'): '3Dカーソル位置に作成する再利用可能な2Dカーブ断面の種類を選びます。',
 ('*', 'Circle'): '円',
 ('*', 'Circle Selection'): '選択を円形化',
 ('*', 'Circle alignment complete'): '円形化が完了しました',
 ('*', 'Cleanup After Join'): '結合後に整理',
 ('*', 'Cleanup New Object'): '新規オブジェクトを整理',
 ('*', 'Cleanup Normals'): '法線も整理',
 ('*', 'Cleanup complete'): 'クリーンアップが完了しました',
 ('*', 'Clockwise'): '時計回り',
 ('*', 'Close Object Path'): 'オブジェクトパスを閉じる',
 ('*', 'Close Vertex Path'): '頂点パスを閉じる',
 ('*', 'Close the generated path so the last sampled object links back to the first.'): '生成したパスを閉じ、最後のオブジェクトから最初のオブジェクトへ戻るようにします。',
 ('*', 'Close the generated vertex path so the last sampled point links back to the first.'): '生成した頂点パスを閉じ、最後の点を最初の点へつなぎます。',
 ('*', 'Close the pipe ends when the curve supports cap filling.'): 'カーブが対応している場合に、パイプ両端を閉じます。',
 ('*', 'Coarse (lightweight)'): '粗い（軽い）',
 ('*', 'Collapsible Sections'): '折りたたみセクション',
 ('*', 'Collection'): 'コレクション指定',
 ('*', 'Combine / Join Clean'): '結合 / クリーン結合',
 ('*', 'Combined state indicator (ON / OFF / MIXED).\nThis is calculated automatically based on the selected visibility scope.'): '状態の総合表示（ON／OFF／MIXED）です。\n'
                                                                                                                                  '選択中の反映範囲に基づいて自動計算されます。',
 ('*', 'Component Scale'): 'コンポーネント倍率',
 ('*', 'Configured Bend helper'): 'ベンド補助を設定しました',
 ('*', 'Configured Lattice helper'): 'ラティス補助を設定しました',
 ('*', 'Configured Solidify helper'): '厚み付け補助を設定しました',
 ('*', 'Configured Twist helper'): 'ツイスト補助を設定しました',
 ('*', 'Configured sweep using the selected profile curve'): '選択したプロファイルカーブでスイープを設定しました',
 ('*', 'Conform / Stitch To Surface'): '面へ追従 / ステッチ',
 ('*', 'Conform Mode'): '追従モード',
 ('*', 'Conform Offset'): '追従オフセット',
 ('*', 'Conformed selected detail meshes to active surface'): '選択ディテールメッシュをアクティブ面へ追従させました',
 ('*', 'Convert To Quads'): '四角化',
 ('*', 'Convert selected mesh edges into one or more curve splines without duplicating or separating the source mesh. Useful for Vertices to Splines, sweep prep, path extraction, trim routing, and safer pipe workflows.'): '選択メッシュエッジを、元メッシュを複製・分離せずに1本以上のカーブスプラインへ変換します。Vertices '
                                                                                                                                                                                                                              'to '
                                                                                                                                                                                                                              'Splines、スイープ準備、パス抽出、トリム配線、より安全なパイプ作成ワークフローに便利です。',
 ('*', 'Convert the current selected edge path into a beveled curve pipe. This is useful for cable, hose, trim, and sweep-style workflows inspired by Sweep Mesh, Cablerator, ReeperX, and curve-based modeling tools.'): '現在選択中のエッジパスを、ベベル付きカーブパイプへ変換します。ケーブル、ホース、モール、スイープ系モデリングに有効で、Sweep '
                                                                                                                                                                                                                          'Mesh、Cablerator、ReeperX、各種カーブ系ツールを参考にした実装です。',
 ('*', 'Could not switch to Edit Mode'): '編集モードへ切り替えられませんでした',
 ('*', 'Could not switch to Object Mode'): 'オブジェクトモードへ切り替えられませんでした',
 ('*', 'Crease Preset'): 'Crease Preset',
 ('*', 'Create a NEW State Set (a snapshot) of modifier ON/OFF + display flags.\nThis records the current modifier states of objects in the current scope, so you can restore them later.\nBeginner tip: Use State Sets to switch between setups (e.g. modeling vs render, high vs low).\nNote: This does NOT save modifier parameters or order — only the visibility/display states.'): '新しいステートセット（スナップショット）を作成します。\n'
                                                                                                                                                                                                                                                                                                                                                                                         '指定範囲のオブジェクトのモディファイアON/OFFや表示フラグを記録し、後から復元できます。\n'
                                                                                                                                                                                                                                                                                                                                                                                         '初心者ヒント：モデリング用/レンダー用、高/低など、状態の切り替えに便利です。\n'
                                                                                                                                                                                                                                                                                                                                                                                         '注意：パラメータや順番は保存しません（表示/有効状態のみ）。',
 ('*', 'Create a compact non-destructive hard-surface stack on the active object using the other selected mesh objects as cutters. Adds Boolean modifiers per cutter, optional bevel support, optional weighted normals, and optional cutter organization for a Hard Ops / Boxcutter / Hard Mesh / MeshFusion style workflow.'): '選択中の他メッシュをカッターとして使用し、アクティブオブジェクトにコンパクトな非破壊ハードサーフェススタックを構築します。各カッターごとにBooleanモディファイアを追加し、必要に応じてベベル補助・重み付き法線・カッター整理を自動設定して、Hard '
                                                                                                                                                                                                                                                                                                                                 'Ops '
                                                                                                                                                                                                                                                                                                                                 '/ '
                                                                                                                                                                                                                                                                                                                                 'Boxcutter '
                                                                                                                                                                                                                                                                                                                                 '/ '
                                                                                                                                                                                                                                                                                                                                 'Hard '
                                                                                                                                                                                                                                                                                                                                 'Mesh '
                                                                                                                                                                                                                                                                                                                                 '/ '
                                                                                                                                                                                                                                                                                                                                 'MeshFusion '
                                                                                                                                                                                                                                                                                                                                 '風のワークフローを実現します。',
 ('*', 'Create a curve path from the world-space origins of the selected objects. Useful for trajectory-to-spline style workflows, blocking guide curves, layout splines, and quickly turning placed empties/objects into reusable paths.'): '選択オブジェクトのワールド座標原点からカーブパスを作成します。Trajectory '
                                                                                                                                                                                                                                             'to '
                                                                                                                                                                                                                                             'Spline '
                                                                                                                                                                                                                                             '系ワークフロー、ガイドカーブ、レイアウトスプライン、配置済み '
                                                                                                                                                                                                                                             'Empty '
                                                                                                                                                                                                                                             '/ '
                                                                                                                                                                                                                                             'オブジェクトを再利用可能なパスへ素早く変換する用途に便利です。',
 ('*', 'Create a detail box aligned to the active face. This is useful for kitbash details, panel blocks, trim pieces, and quick boolean helpers inspired by KIT OPS, Primo Kit, NitroDraw, and surface-first hard-surface workflows.'): 'アクティブ面に揃った箱型ディテールを生成します。キットバッシュ部品、パネルブロック、トリム、簡易ブーリアン補助など、KIT '
                                                                                                                                                                                                                                         'OPS、Primo '
                                                                                                                                                                                                                                         'Kit、NitroDraw、面基準のハードサーフェス制作を意識した機能です。',
 ('*', 'Create a duplicated path object before assigning the selected profile, so the original path remains unchanged.'): '選択プロファイルを割り当てる前にパスオブジェクトを複製し、元のパスを変更せずに残します。',
 ('*', 'Create a helix/spiral curve path at the 3D cursor. Useful for springs, spiral cables, wrapped trims, and guide curves for sweep or array workflows.'): '3Dカーソル位置にヘリックス '
                                                                                                                                                               '/ '
                                                                                                                                                               'スパイラルのカーブパスを作成します。バネ、螺旋ケーブル、巻き付きトリム、スイープや配列のガイドカーブに便利です。',
 ('*', 'Create a loft mesh between exactly two paths. Works with two selected curve objects in Object Mode, or with exactly two selected edge paths in Edit Mode. Useful for PolyBridge, spline patch, loft surfacing, trims, and strip modeling workflows.'): 'ちょうど2本のパス間にロフトメッシュを生成します。オブジェクトモードでは2つの選択カーブ、編集モードではちょうど2本の選択エッジパスに対応します。PolyBridge、スプラインパッチ、ロフト面生成、トリム、帯状モデリングに便利です。',
 ('*', 'Create a rebuilt duplicate instead of overwriting the active curve object data.'): 'アクティブカーブのデータを上書きせず、再構築した複製を作成します。',
 ('*', 'Create a reusable 2D curve profile at the 3D cursor. Useful for Sweep Mesh, molding, trim, rail sections, cable trays, and CAD-style profile workflows.'): '3Dカーソル位置に再利用可能な2Dカーブ断面を作成します。Sweep '
                                                                                                                                                                   'Mesh、モール、トリム、手すり断面、ケーブルトレイ、CAD系プロファイルワークフローに便利です。',
 ('*', 'Create evenly spaced boolean helper boxes across the active mesh bounds to build grooves, slots, layered cuts, and contour-like panel patterns. This is a practical non-destructive generator inspired by Slicer, NitroBoxTool, and panel-line boolean workflows.'): 'アクティブメッシュの範囲に沿って等間隔のブーリアン補助ボックスを生成し、溝、スロット、多段カット、等高線的なパネルパターンを作ります。Slicer、NitroBoxTool、パネルライン用ブーリアン作業を意識した非破壊ジェネレーターです。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Bend modifier origin.'): '3D '
                                                                                                              'カーソル位置に専用 '
                                                                                                              'Empty '
                                                                                                              'を作成または更新し、Bend '
                                                                                                              'モディファイアの原点として使います。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Cast modifier control object when supported.'): '3D '
                                                                                                                                     'カーソル位置に専用 '
                                                                                                                                     'Empty '
                                                                                                                                     'を作成または更新し、対応している場合は '
                                                                                                                                     'Cast '
                                                                                                                                     'モディファイアの制御オブジェクトとして使います。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Taper modifier origin.'): '3D '
                                                                                                               'カーソル位置に専用 '
                                                                                                               'Empty '
                                                                                                               'を作成または更新し、Taper '
                                                                                                               'モディファイアの原点として使います。',
 ('*', 'Create or update a dedicated origin empty at the 3D cursor and use it as the Twist modifier origin.'): '3D '
                                                                                                               'カーソル位置に専用 '
                                                                                                               'Empty '
                                                                                                               'を作成または更新し、Twist '
                                                                                                               'モディファイアの原点として使います。',
 ('*', 'Create or update a lattice cage around the active object and wire it through a Lattice modifier. Useful for broad-form FFD-style shaping, silhouette blocking, gentle organic cleanup, and non-destructive cage edits inspired by modifier-stack / FFD workflows.'): 'アクティブオブジェクトの周囲にラティスケージを作成または更新し、Lattice '
                                                                                                                                                                                                                                                                             'モディファイアで接続します。FFD '
                                                                                                                                                                                                                                                                             '風の大まかな変形、シルエットのブロック調整、やわらかい有機的修正、非破壊ケージ編集に便利です。',
 ('*', 'Create or update a non-destructive Cast modifier on the active mesh. Useful for sphere/cylinder/cuboid fitting, quick circle/spherify shaping, and upper-compatible max-style form correction inside the modifier stack.'): 'アクティブメッシュに、非破壊の '
                                                                                                                                                                                                                                    'Cast '
                                                                                                                                                                                                                                    'モディファイアを作成または更新します。球 '
                                                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                                                    '円柱 '
                                                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                                                    '立方体への近似、素早い円形化 '
                                                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                                                    '球形化、3ds '
                                                                                                                                                                                                                                    'Max '
                                                                                                                                                                                                                                    '風のフォーム補正をモディファイアスタック内で扱う用途に便利です。',
 ('*', 'Create or update a non-destructive Simple Deform Bend setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for Simple Bend, Scroll/Roll style shaping, signage, cables, and fast concept deformation without committing destructive edits.'): 'アクティブオブジェクトに、必要に応じて '
                                                                                                                                                                                                                                                                                                '3D '
                                                                                                                                                                                                                                                                                                'カーソル位置の専用 '
                                                                                                                                                                                                                                                                                                'Empty '
                                                                                                                                                                                                                                                                                                'を原点として使う、非破壊 '
                                                                                                                                                                                                                                                                                                'Simple '
                                                                                                                                                                                                                                                                                                'Deform '
                                                                                                                                                                                                                                                                                                'Bend '
                                                                                                                                                                                                                                                                                                'セットアップを作成または更新します。Simple '
                                                                                                                                                                                                                                                                                                'Bend、Scroll '
                                                                                                                                                                                                                                                                                                '/ '
                                                                                                                                                                                                                                                                                                'Roll '
                                                                                                                                                                                                                                                                                                '系の変形、看板、ケーブル、ラフコンセプトの素早い変形に便利です。',
 ('*', 'Create or update a non-destructive Simple Deform Taper setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for bottle shapes, wedge forms, architectural narrowing, silhouette control, and fast modifier-stack taper workflows.'): 'アクティブオブジェクトに、必要に応じて '
                                                                                                                                                                                                                                                                                       '3D '
                                                                                                                                                                                                                                                                                       'カーソル位置の専用 '
                                                                                                                                                                                                                                                                                       'Empty '
                                                                                                                                                                                                                                                                                       'を原点として使う、非破壊 '
                                                                                                                                                                                                                                                                                       'Simple '
                                                                                                                                                                                                                                                                                       'Deform '
                                                                                                                                                                                                                                                                                       'Taper '
                                                                                                                                                                                                                                                                                       'セットアップを作成または更新します。ボトル形状、くさび形、建築物の絞り込み、シルエット調整、モディファイアスタック型の高速テーパー作業に便利です。',
 ('*', 'Create or update a non-destructive Simple Deform Twist setup on the active object, optionally using a dedicated origin empty at the 3D cursor. Useful for torsion, twisted trims, cables, screw-like shaping, and fast modifier-stack twist workflows without destructive edits.'): 'アクティブオブジェクトに、必要に応じて '
                                                                                                                                                                                                                                                                                            '3D '
                                                                                                                                                                                                                                                                                            'カーソル位置の専用 '
                                                                                                                                                                                                                                                                                            'Empty '
                                                                                                                                                                                                                                                                                            'を原点として使う、非破壊 '
                                                                                                                                                                                                                                                                                            'Simple '
                                                                                                                                                                                                                                                                                            'Deform '
                                                                                                                                                                                                                                                                                            'Twist '
                                                                                                                                                                                                                                                                                            'セットアップを作成または更新します。ねじり、ツイストしたトリム、ケーブル、スクリュー風の造形、破壊的編集を行わないモディファイアスタック型の高速ツイスト作業に便利です。',
 ('*', 'Create or update a non-destructive Solidify modifier on the active mesh with even-thickness and quality-normal options. Useful for shelling, panel thickness, CAD-style wall offsets, Solidify Plus style workflows, and quick hard-surface thickness passes.'): 'アクティブメッシュに、均一厚みや高品質法線設定を含む非破壊 '
                                                                                                                                                                                                                                                                         'Solidify '
                                                                                                                                                                                                                                                                         'モディファイアを作成または更新します。シェル化、パネル厚み、CAD '
                                                                                                                                                                                                                                                                         '風の壁厚オフセット、Solidify '
                                                                                                                                                                                                                                                                         'Plus '
                                                                                                                                                                                                                                                                         '系ワークフロー、ハードサーフェスの素早い厚み付けに便利です。',
 ('*', 'Create rim faces so the thickened shell is closed instead of leaving open borders.'): '厚み付け後のシェルが開いた境界にならないよう、側面を生成して閉じます。',
 ('*', 'Created array-along-curve stack'): 'カーブ沿い配列スタックを作成しました',
 ('*', 'Created curve object from selected edges'): '選択エッジからカーブオブジェクトを作成しました',
 ('*', 'Created curve path from selected objects'): '選択オブジェクトからカーブパスを作成しました',
 ('*', 'Created curve path from selected vertices'): '選択頂点からカーブパスを作成しました',
 ('*', 'Created face component array'): '面コンポーネント配列を作成しました',
 ('*', 'Created hard-surface boolean stack'): 'ハードサーフェス用ブーリアンスタックを作成しました',
 ('*', 'Created helix path'): 'ヘリックスパスを作成しました',
 ('*', 'Created instances along the active path'): 'アクティブパスに沿ってインスタンスを作成しました',
 ('*', 'Created loft mesh from two paths'): '2本のパスからロフトメッシュを作成しました',
 ('*', 'Created profile primitive'): '断面プリミティブを作成しました',
 ('*', 'Created slice/panel boolean helpers'): 'スライス / パネル用ブーリアン補助を作成しました',
 ('*', 'Created surface detail helper'): 'サーフェスディテール補助を作成しました',
 ('*', 'Cuboid'): '直方体',
 ('*', 'Curated high-coverage modeling workflow that unifies hard-surface, topology, CAD-like, array, scatter, cleanup, shading, and organization tools in one place.'): 'ハードサーフェス、トポロジー、CADライク、配列、散布、クリーンアップ、シェーディング、整理を1か所に統合した高網羅ワークフローハブです。',
 ('*', 'Currently selected objects'): '現在選択中のオブジェクト',
 ('*', 'Curve bevel resolution used for the generated pipe.'): '生成されるパイプのカーブベベル解像度です。',
 ('*', 'Curves / Repetition'): 'カーブ / 反復配置',
 ('*', 'Custom'): 'カスタム',
 ('*', 'Cylinder'): '円柱',
 ('*', 'Deep tools'): '詳細ツール',
 ('*', 'Degenerate Edges'): '退化エッジ',
 ('*', 'Delete Targets'): '元ターゲットを削除',
 ('*', 'Delete selected state set'): '選択中の状態セットを削除します',
 ('*', 'Delete the selected State Set preset.\nThis only removes the preset; it does not change current modifier states.'): '選択中のステートセット（プリセット）を削除します。\n'
                                                                                                                            'プリセットを消すだけで、現在のモディファイア状態は変更しません。',
 ('*', 'Delete the selected State Set preset.\nThis only removes the preset; it does not change current modifier states.\nTip: If you delete by mistake, Undo can restore it.'): '選択中のステートセット（プリセット）を削除します。\n'
                                                                                                                                                                                 'プリセットを消すだけで、現在の状態は変更しません。\n'
                                                                                                                                                                                 'ヒント：間違えて削除した場合はUndoで戻せます。',
 ('*', 'Deleted state set: {}'): '状態セットを削除しました: {}',
 ('*', 'Detach / Separate Clean'): 'デタッチ / クリーン分離',
 ('*', 'Detached selection into a clean new object'): '選択をクリーンな新規オブジェクトへ分離しました',
 ('*', 'Difference'): '差分',
 ('*', 'Direct Delete'): 'Direct Delete',
 ('*', 'Disable selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで無効(OFF)にします',
 ('*', 'Disable the selected target on all objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): '指定範囲の全オブジェクトでターゲットを無効(OFF)にします。\n'
                                                                                                                                                                  '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
 ('*', 'Disabled Only'): '無効のみ',
 ('*', 'Display the generated detail as wire for helper-style workflows.'): '補助オブジェクト用途向けに、生成ディテールをワイヤ表示にします。',
 ('*', 'Distance tolerance used by Axis Slice Edit when resolving plane/mesh intersections.'): 'Axis Slice Edit '
                                                                                               'が平面とメッシュの交差を解決する際に使う距離許容値です。',
 ('*', 'Distance used for potential double detection and for the conservative merge-by-distance repair step.'): '重複候補検出と、保守的な距離結合修復で使用する距離です。',
 ('*', 'Distance used when merging overlapping vertices during cleanup.'): 'クリーンアップ時に重複頂点を統合する距離です。',
 ('*', 'Distribute Axis'): '均等配置軸',
 ('*', 'Distribute Selected'): '選択を均等配置',
 ('*', 'Distributed selected objects evenly on the chosen axis'): '選択オブジェクトを指定軸上で均等配置しました',
 ('*', 'Do not change viewport selection'): 'ビューポートの選択を変更しない',
 ('*', 'Drag & Drop'): 'ドラッグ＆ドロップ',
 ('*', 'Drop Offset'): 'ドロップオフセット',
 ('*', 'Drop To Floor'): '床へドロップ',
 ('*', 'Drop To Surface'): '面へドロップ',
 ('*', 'Drop selected objects vertically so their world-space bounds sit on a shared floor height. Useful for DropToFloor style layout cleanup, shelf dressing, and zero-target placement prep.'): '選択オブジェクトを垂直移動し、ワールド空間の境界ボックス下端が共通の床高さへ接するようにします。DropToFloor '
                                                                                                                                                                                                   '風のレイアウト整理、棚配置、ターゲット不要の設置準備に便利です。',
 ('*', 'Drop the selected objects onto the active surface along world -Z using bounding-box based placement, with optional normal alignment. This is useful for DropIt / Drop to Floor style scene dressing and layout work.'): '選択オブジェクトを、ワールド '
                                                                                                                                                                                                                                '-Z '
                                                                                                                                                                                                                                '方向へアクティブ面へ落とし、バウンディングボックス基準で接地します。必要に応じて法線合わせも行います。DropIt '
                                                                                                                                                                                                                                '/ '
                                                                                                                                                                                                                                'Drop '
                                                                                                                                                                                                                                'to '
                                                                                                                                                                                                                                'Floor '
                                                                                                                                                                                                                                '系のレイアウト作業に便利です。',
 ('*', 'Dropped selected objects to active surface'): '選択オブジェクトをアクティブ面へドロップしました',
 ('*', 'No selected object lies over the active surface'): 'アクティブ面の上に重なる選択オブジェクトがありません',
 ('*', 'Dropped selected objects to floor height'): '選択オブジェクトを床高さへ配置しました',
 ('*', 'Duplicate First'): '先に複製',
 ('*', 'Duplicate Path'): 'パスを複製',
 ('*', 'Duplicate the active mesh object onto the faces of the other selected mesh objects. Useful as a compact Tissue-style face component workflow for paneling, tiles, vents, and kitbash repetition.'): 'アクティブメッシュを、他の選択メッシュの各面へ複製配置します。Tissue '
                                                                                                                                                                                                            '系の面コンポーネント配置を、パネル、タイル、ベント、キットバッシュ反復向けにコンパクト化したワークフローです。',
 ('*', 'Duplicate the selected geometry before separating it, so the source object keeps the original polygons.'): '分離前に選択ジオメトリを複製し、元オブジェクト側にも元のポリゴンを残します。',
 ('*', 'Edge / Face Add'): 'Edge / Face Add',
 ('*', 'EdgeNet Fill'): 'EdgeNet Fill',
 ('*', 'Edges'): '辺数',
 ('*', 'Edit / Cage'): '編集 / ケージ',
 ('*', 'Edit Mode'): '編集モード',
 ('*', 'Edit Poly (Standalone)'): '編集ポリゴン（単体）',
 ('*', '編集ポリゴンレイヤーを追加'): 'ポリ編集レイヤーを追加',
 ('*', '編集ポリゴンを追加'): 'ポリ編集を追加',
 ('*', '編集ポリゴン（単体）'): 'ポリ編集（単体）',
 ('*', 'EditPoly'): '編集ポリゴン',
 ('*', 'Enable X-axis alignment or distribution.'): 'X 軸方向の整列または均等配置を有効にします。',
 ('*', 'Enable Y-axis alignment or distribution.'): 'Y 軸方向の整列または均等配置を有効にします。',
 ('*', 'Enable Z-axis alignment or distribution.'): 'Z 軸方向の整列または均等配置を有効にします。',
 ('*', 'Enable at least one of location, rotation, or scale alignment'): '位置・回転・スケール整列のいずれかを少なくとも1つ有効にしてください',
 ('*', 'Enable clipping on the created Mirror modifier to keep the center seam closed.'): '作成した Mirror '
                                                                                          'モディファイアでクリップを有効にし、中央シームを閉じやすくします。',
 ('*', 'Enable end caps on the configured sweep when the curve data supports cap filling.'): 'カーブデータが対応している場合、設定したスイープの端面キャップを有効にします。',
 ('*', 'Enable higher-quality solidify normal handling for cleaner shading on complex shells.'): '複雑なシェルでもよりクリーンなシェーディングになるよう、高品質な法線処理を有効にします。',
 ('*', 'Enable selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで有効(ON)にします',
 ('*', 'Enable smooth shading on the generated loft mesh.'): '生成したロフトメッシュでスムーズシェードを有効にします。',
 ('*', 'Enable the selected target on all objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): '指定範囲の全オブジェクトでターゲットを有効(ON)にします。\n'
                                                                                                                                                                 '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
 ('*', 'Enabled Only'): '有効のみ',
 ('*', 'Enabled at least one axis is required'): '有効な軸を少なくとも1つ指定してください',
 ('*', 'Even Offset'): '均一オフセット',
 ('*', 'Evenly distribute selected object origins between the current minimum and maximum positions on the chosen world axis. Useful for shelf dressing, facade spacing, modular blocking, and quick layout cleanup.'): '選択したワールド軸上の現在の最小位置と最大位置の間で、選択オブジェクト原点を均等配置します。棚配置、ファサード間隔調整、モジュラーなブロックアウト、素早いレイアウト整理に便利です。',
 ('*', 'Expand/collapse the Details section to save vertical space.'): '縦スペース節約のため「詳細」セクションを展開/折りたたみします。',
 ('*', 'Expand/collapse the Modifier List section to save vertical space.'): '縦スペース節約のため「モディファイアリスト」セクションを展開/折りたたみします。',
 ('*', 'Expand/collapse the Object List section to save vertical space.'): '縦スペース節約のため「オブジェクトリスト」セクションを展開/折りたたみします。',
 ('*', 'Expand/collapse the Settings section to save vertical space.'): '縦スペース節約のため「設定」セクションを展開/折りたたみします。',
 ('*', 'Expand/collapse the State Sets section to save vertical space.'): '縦スペース節約のため「ステートセット」セクションを展開/折りたたみします。',
 ('*', 'Expanded'): '展開状態',
 ('*', 'Expose the migrated surface-detail, smart-extrude, slice, deform, and cleanup helpers directly in the hub so the suite stays compact for beginners and fast for experts.'): '移行済みの面ディテール、スマート押し出し、スライス、デフォーム、クリーンアップ補助をハブへ直接表示し、初心者にはコンパクトに、熟練者には高速に使える構成にしています。',
 ('*', 'Extend Endpoints'): '端点を延長',
 ('*', 'Extended selected edges to the resolved meeting point'): '選択辺の端点を解決された交点まで延長しました',
 ('*', 'Extra gap inserted between stacked object bounds.'): 'スタック配置時にオブジェクト境界の間へ追加する余白です。',
 ('*', 'Extra scale added around the active object when fitting the generated lattice cage.'): '生成するラティスケージをアクティブオブジェクトへ合わせる際に追加する余白スケールです。',
 ('*', 'Extrude distance applied by the helper.'): 'この補助で行う押し出し距離です。',
 ('*', 'FFD lattice tool integrated with Smart Modifier'): 'Smart Modifier連動のFFDラティスツール',
 ('*', 'Face Component Array'): '面コンポーネント配列',
 ('*', 'Face Influence'): '面影響',
 ('*', 'Face Offset'): '面オフセット',
 ('*', 'Faces'): '面数',
 ('*', 'Failed to build curve data from the selected edges'): '選択エッジからカーブデータを構築できませんでした',
 ('*', 'Failed to create curve data from the selected edges'): '選択エッジからカーブデータを作成できませんでした',
 ('*', 'Failed to create curve path from selected vertices'): '選択頂点からカーブパスを作成できませんでした',
 ('*', 'Failed to create curve path from the selected objects'): '選択オブジェクトからカーブパスを作成できませんでした',
 ('*', 'Failed to create loft mesh from the resolved paths'): '解決したパスからロフトメッシュを作成できませんでした',
 ('*', 'Failed to evaluate a usable path from the active curve'): 'アクティブカーブから使用可能なパスを取得できませんでした',
 ('*', 'Failed to isolate the duplicated edge selection'): '複製したエッジ選択部分を新規オブジェクトとして分離できませんでした',
 ('*', 'Failed to separate the current selection into a new object'): '現在の選択を新規オブジェクトとして分離できませんでした',
 ('*', 'Fallback count used when fit-curve mode is unavailable or disabled.'): 'Fit Curve が使えない場合や無効な場合の予備配列数です。',
 ('*', 'Fill / repair complete'): '面張り / 修復が完了しました',
 ('*', 'Fill Caps'): '端面を閉じる',
 ('*', 'Fill Holes'): '穴埋め',
 ('*', 'Fill the current edit-mode boundary with a grid-first strategy, then fall back to standard face creation and fill tools. Optionally beautifies and converts triangles to quads. This acts as a practical upper-compatible helper inspired by F2, Quad Adder, and manual patch tools.'): '編集モード中の境界を、まずグリッドフィル優先で埋め、失敗時は標準の面生成やFillへフォールバックします。必要に応じて '
                                                                                                                                                                                                                                                                                                'Beautify '
                                                                                                                                                                                                                                                                                                'と三角形の四角化も行います。F2、Quad '
                                                                                                                                                                                                                                                                                                'Adder、各種パッチ系ツールを実務向けに統合した上位互換補助です。',
 ('*', 'Fill, cap, or bridge the current edit-mode boundary with a smarter fallback chain. The operator tries boundary-aware bridge, grid fill, EdgeNet preparation/fill, and then standard face creation tools before optional beautify / quad cleanup. This acts as a more failure-resistant helper inspired by F2, Quad Adder, Quad Cap Tool, NitroCap, and day-to-day patch repair workflows.'): '編集モードの境界選択を、より賢いフォールバック連鎖で埋め・キャップ・ブリッジします。境界に応じた '
                                                                                                                                                                                                                                                                                                                                                                                                     'Bridge、Grid '
                                                                                                                                                                                                                                                                                                                                                                                                     'Fill、EdgeNet '
                                                                                                                                                                                                                                                                                                                                                                                                     'Prepare '
                                                                                                                                                                                                                                                                                                                                                                                                     '/ '
                                                                                                                                                                                                                                                                                                                                                                                                     'Fill、その後に通常の面生成系を順に試し、必要に応じて '
                                                                                                                                                                                                                                                                                                                                                                                                     'Beautify '
                                                                                                                                                                                                                                                                                                                                                                                                     '/ '
                                                                                                                                                                                                                                                                                                                                                                                                     'Quad '
                                                                                                                                                                                                                                                                                                                                                                                                     '化まで行います。F2、Quad '
                                                                                                                                                                                                                                                                                                                                                                                                     'Adder、Quad '
                                                                                                                                                                                                                                                                                                                                                                                                     'Cap '
                                                                                                                                                                                                                                                                                                                                                                                                     'Tool、NitroCap、日常的なパッチ修復ワークフローを意識した、失敗しにくい補助です。',
 ('*', 'Filter / Search'): 'フィルター / 検索',
 ('*', 'Filter Objects'): 'オブジェクトフィルタ',
 ('*', 'Filter Targets'): 'ターゲットフィルタ',
 ('*', 'Filter the Object List by the ON/OFF state of the selected target.\nThe state is evaluated using the primary visibility flag (usually Viewport).'): 'オブジェクトリストをターゲットのON/OFF状態で絞り込みます。\n'
                                                                                                                                                            '状態は主となる可視フラグ（通常はビューポート）で判定します。',
 ('*', 'Final thickness used by the generated or updated Solidify modifier.'): '生成または更新した Solidify モディファイアで使う最終厚さです。',
 ('*', 'Fine (heavier)'): '細かい（やや重い）',
 ('*', "Fit the current selected vertices into a circular shape. Uses LoopTools Circle when available, and otherwise falls back to Blender's To Sphere transform for a practical circle helper inspired by LoopTools and NitroCycle."): '現在の選択頂点を円形に整えます。LoopTools '
                                                                                                                                                                                                                                        'Circle '
                                                                                                                                                                                                                                        'が使える場合はそれを使い、使えない場合は '
                                                                                                                                                                                                                                        'Blender '
                                                                                                                                                                                                                                        '標準の '
                                                                                                                                                                                                                                        'To '
                                                                                                                                                                                                                                        'Sphere '
                                                                                                                                                                                                                                        'へフォールバックします。LoopTools '
                                                                                                                                                                                                                                        'や '
                                                                                                                                                                                                                                        'NitroCycle '
                                                                                                                                                                                                                                        'を参考にした実務向け円形化補助です。',
 ('*', 'Floor Board Length'): '床板の長さ',
 ('*', 'Floor Board Width'): '床板の幅',
 ('*', 'Floor Gap'): '目地幅',
 ('*', 'Floor Generator'): 'フロア生成',
 ('*', 'Floor Stagger'): '床板のずらし量',
 ('*', 'Floor Thickness'): '床板の厚み',
 ('*', 'Floor Z'): '床Z',
 ('*', 'Follow Tangent'): '接線方向に揃える',
 ('*', 'Gap placed between generated floor boards.'): '生成する床板同士の間に入る目地幅です。',
 ('*', "Generate a procedural floorboard mesh inside the active object's local footprint using board width, length, gap, thickness, and stagger settings. This is a compact Blender-native helper inspired by FloorGenerator and architectural pattern tools."): 'アクティブオブジェクトのローカルな占有範囲に合わせて、板幅・長さ・目地・厚み・ずらし量を使ったフロアボードメッシュを生成します。FloorGenerator '
                                                                                                                                                                                                                                                                 'などの建築系パターンツールを意識した、Blenderネイティブのコンパクト実装です。',
 ('*', 'Generate the helix in clockwise direction around the local Z axis.'): 'ローカルZ軸まわりに時計回り方向でヘリックスを生成します。',
 ('*', 'Generated floor pattern mesh'): 'フロアパターンメッシュを生成しました',
 ('*', 'Generated pipe curve from selected edges'): '選択エッジからパイプカーブを生成しました',
 ('*', 'Grid Fill'): 'Grid Fill',
 ('*', 'Group targets by modifier name (e.g. Bevel.001)'): 'モディファイア名でターゲットをまとめる（例: Bevel.001）',
 ('*', 'Group targets by modifier type (Mirror, Bevel, ...)'): 'モディファイアの種類でターゲットをまとめる（Mirror / Bevel など）',
 ('*', 'Guide / Tips'): 'ガイド / ヒント',
 ('*', 'Height of the generated surface detail box measured away from the source face.'): '元の面から外側へ立ち上がるサーフェスディテール箱の高さです。',
 ('*', 'Helix Height'): 'ヘリックス高さ',
 ('*', 'Helix Radius'): 'ヘリックス半径',
 ('*', 'Helix Taper'): 'ヘリックステーパー',
 ('*', 'Helix Turns'): 'ヘリックス巻数',
 ('*', 'Hide all unselected objects for focused modeling, then restore the previous visibility when run again. Useful for MagicSolo-style focus workflows.'): '未選択オブジェクトをすべて隠して集中作業用の表示にし、再実行で元の可視状態へ戻します。MagicSolo '
                                                                                                                                                              '系の集中ワークフロー向けです。',
 ('*', 'How clicking an item in the Object List affects viewport selection:\n- None: do not change the current selection\n- Single: deselect others and select the clicked object\n- Active Only: set active/selected without deselecting others'): 'オブジェクトリストをクリックしたときの選択挙動を設定します。\n'
                                                                                                                                                                                                                                                    '- '
                                                                                                                                                                                                                                                    'なし: '
                                                                                                                                                                                                                                                    '現在の選択を変えない\n'
                                                                                                                                                                                                                                                    '- '
                                                                                                                                                                                                                                                    '単一: '
                                                                                                                                                                                                                                                    'それ以外を解除してクリックした物だけ選択\n'
                                                                                                                                                                                                                                                    '- '
                                                                                                                                                                                                                                                    'アクティブのみ: '
                                                                                                                                                                                                                                                    '他の選択を残したままアクティブ化/選択',
 ('*', 'How many matching modifiers exist on this object for the current target.\nThis is calculated automatically.'): '現在のターゲットに一致するモディファイアが、このオブジェクトにいくつあるかです。\n'
                                                                                                                       '自動計算されます。',
 ('*', 'How many matching modifiers were found for this target.\nThis is calculated automatically when the list is rebuilt.'): 'このターゲットに一致するモディファイア数です。\n'
                                                                                                                               'リスト更新時に自動計算されます。',
 ('*', 'How many objects contain matching modifiers for this target.\nThis is calculated automatically when the list is rebuilt.'): 'このターゲットに一致するモディファイアを持つオブジェクト数です。\n'
                                                                                                                                    'リスト更新時に自動計算されます。',
 ('*', 'How many smoothing passes to run when a fallback method is used.'): 'フォールバック方式を使うときに実行するスムージング回数です。',
 ('*', 'How often Auto Refresh runs (seconds).\nIncrease this value to reduce CPU usage in heavy scenes.'): '自動更新の実行間隔（秒）です。\n'
                                                                                                            '重いシーンでは値を大きくしてCPU負荷を下げられます。',
 ('*', 'How the generated slice helpers should affect the active mesh.'): '生成されたスライス補助がアクティブメッシュへ与える演算方法です。',
 ('*', 'How the target is defined (by modifier TYPE or by modifier NAME).\nThis is managed automatically based on the current target mode.'): 'ターゲットの指定方法（モディファイアのタイプ指定／名前指定）です。\n'
                                                                                                                                              '現在のターゲットモードに応じて自動管理されます。',
 ('*', 'If a Weighted Normal modifier already exists on the object, update it instead of creating duplicates.'): 'オブジェクトに既存の '
                                                                                                                 'Weighted '
                                                                                                                 'Normal '
                                                                                                                 'モディファイアがある場合、重複追加せず更新します。',
 ('*', 'If the target mesh stores selected polygons, use only those faces. Otherwise all faces are used.'): '対象メッシュに選択ポリゴン情報があればその面だけを使い、無ければ全ての面を使用します。',
 ('*', 'In Edit Mode, run destructive symmetrize with the chosen direction. In Object Mode, create or update a Mirror modifier for a non-destructive symmetry setup.'): '編集モードでは選択方向で破壊的 '
                                                                                                                                                                        'Symmetrize '
                                                                                                                                                                        'を実行し、オブジェクトモードでは非破壊の '
                                                                                                                                                                        'Mirror '
                                                                                                                                                                        'モディファイアを作成 '
                                                                                                                                                                        '/ '
                                                                                                                                                                        '更新します。',
 ('*', 'In Object Mode, create or reuse a Mirror modifier instead of doing a destructive edit operation.'): 'オブジェクトモードでは、破壊的編集の代わりに '
                                                                                                            'Mirror '
                                                                                                            'モディファイアを作成 '
                                                                                                            '/ 再利用します。',
 ('*', 'Include Ends'): '両端を含める',
 ('*', 'Inner radius ratio used when the profile type is Star.'): '断面タイプが星形のときに使う内側半径の比率です。',
 ('*', 'Insert Intersection'): '交点を挿入',
 ('*', 'Inserted intersection on selected edges'): '選択辺へ交点を挿入しました',
 ('*', 'Inset amount applied before the extrusion step.'): '押し出し前に行うインセット量です。',
 ('*', 'Instance'): 'インスタンス',
 ('*', 'Instances Along Path'): 'パスに沿ってインスタンス配置',
 ('*', 'Internal key used to identify a pinned modifier target.\nThis value is managed automatically.'): '内部キー：ピン留めしたターゲットを識別するためのキーです。\n'
                                                                                                         '自動管理されるため、通常は編集不要です。',
 ('*', 'Internal key used to identify this target entry.\nThis value is managed automatically.'): '内部キー：このターゲット項目を識別するためのキーです。\n'
                                                                                                  '自動管理されるため、通常は編集不要です。',
 ('*', 'Intersect'): '交差',
 ('*', 'Intersection lies outside one or both selected segments; use Extend mode'): '交点が片方または両方のセグメント外にあります。Extend '
                                                                                    'モードを使ってください',
 ('*', 'Invert (toggle) the active target for ALL objects in the current scope.\nObjects that are ON become OFF (and vice versa). Useful for quick comparisons.'): '指定範囲の全オブジェクトで、アクティブターゲットを反転（トグル）します。\n'
                                                                                                                                                                   'ONの物はOFFに、OFFの物はONになります。差分チェックに便利です。',
 ('*', 'Invert selected target for objects in scope'): '選択中ターゲットを、指定範囲のオブジェクトで反転します',
 ('*', 'Invert the selected target on all objects in the current scope.\nObjects that are ON become OFF (and vice versa).'): '指定範囲の全オブジェクトでターゲットを反転します。\n'
                                                                                                                             'ONの物はOFFに、OFFの物はONになります。',
 ('*', 'Issue Filter'): '問題フィルター',
 ('*', 'Iterations'): '反復回数',
 ('*', 'Join / cleanup complete'): '結合 / クリーンアップが完了しました',
 ('*', 'Join Triangles'): '三角形を結合',
 ('*', 'Join the selected mesh objects while keeping the active object as the pivot/origin owner, then optionally run a light cleanup pass. This acts as a Blender-friendly helper inspired by FB combine and clean combine scripts.'): '選択メッシュを結合し、アクティブオブジェクトの原点/ピボットを維持したまま、必要に応じて軽いクリーンアップを行います。FB '
                                                                                                                                                                                                                                        'combine '
                                                                                                                                                                                                                                        'などのクリーン結合系スクリプトを意識した '
                                                                                                                                                                                                                                        'Blender '
                                                                                                                                                                                                                                        '向け補助です。',
 ('*', 'Keep Original'): '元カーブを保持',
 ('*', 'Keep Sharp'): 'シャープを保持',
 ('*', 'Keep projected vertices slightly above or below the active plane.'): '投影頂点をアクティブ平面から少し浮かせる / めり込ませる距離です。',
 ('*', 'Keep projected vertices slightly above or below the target surface.'): '投影頂点を対象面から少し浮かせる / めり込ませる距離です。',
 ('*', 'Keep shell thickness more even across angled surfaces when the modifier supports it.'): 'モディファイアが対応している場合、傾いた面でも厚みがより均一になるようにします。',
 ('*', 'Key'): 'キー',
 ('*', 'Label'): 'ラベル',
 ('*', 'Lattice Padding'): 'ラティス余白',
 ('*', 'Lattice U'): 'ラティス U',
 ('*', 'Lattice V'): 'ラティス V',
 ('*', 'Lattice W'): 'ラティス W',
 ('*', 'Layout / Replacement'): 'レイアウト / 置換',
 ('*', 'Leave the new detail as a standalone object'): '新規ディテールを単独オブジェクトとして残します',
 ('*', 'Length of the generated surface detail box.'): '生成するサーフェスディテール箱の長さです。',
 ('*', 'Link conformed detail objects into a dedicated helper collection.'): '追従ディテールを専用の補助コレクションへリンクして整理します。',
 ('*', 'Link cutters into a dedicated collection so boolean helper objects stay organized in the Outliner.'): 'Boolean補助オブジェクトをアウトライナーで整理しやすいよう、専用コレクションへリンクします。',
 ('*', 'Link generated path instances into a dedicated collection with a root empty.'): '生成したパス配置インスタンスを、専用コレクションとルート '
                                                                                        'Empty に整理します。',
 ('*', 'Link replacement objects into the same collections as the replaced targets.'): '置換オブジェクトを、置換元ターゲットと同じコレクションへリンクします。',
 ('*', 'Linked Data'): 'データをリンク',
 ('*', 'Load/apply the selected State Set to objects in the current scope.\nThis restores the saved ON/OFF + display flags from that snapshot.\nNote: It does not add/remove modifiers or change their order — it only restores states.'): '選択中のステートセットを、指定範囲のオブジェクトへ読み込み/適用します。\n'
                                                                                                                                                                                                                                           '保存されたON/OFF・表示フラグを復元します。\n'
                                                                                                                                                                                                                                           '注意：モディファイアの追加/削除や順番変更は行いません（状態の復元のみ）。',
 ('*', 'Load/apply the selected State Set.\nThis sets the target visibility on objects according to the saved preset.'): '選択中のステートセットを読み込み/適用します。\n'
                                                                                                                         '保存されたプリセット通りにターゲットの表示状態を設定します。',
 ('*', 'Local axis used by Axis Slice Edit when creating evenly spaced bisect planes.'): 'Axis Slice Edit '
                                                                                         'が等間隔の分割平面を作るときに使うローカル軸です。',
 ('*', 'Loft / Bridge Paths'): 'ロフト / パスブリッジ',
 ('*', 'Loft Samples'): 'ロフト分割数',
 ('*', 'Loose Edges'): 'ルーズ辺',
 ('*', 'Loose Geometry'): 'ルーズジオメトリ',
 ('*', 'Loose Vertices'): 'ルーズ頂点',
 ('*', 'Lower normalized limit for the Bend modifier, useful for partial roll and localized deformation.'): 'Bend '
                                                                                                            'モディファイアの正規化下限で、部分的な巻きや局所変形に使います。',
 ('*', 'Lower normalized limit for the Taper modifier, useful for partial narrowing and localized silhouette edits.'): 'Taper '
                                                                                                                       'モディファイアの正規化下限で、部分的な絞りや局所的なシルエット調整に使います。',
 ('*', 'Lower normalized limit for the Twist modifier, useful for partial torsion and localized twisting.'): 'Twist '
                                                                                                             'モディファイアの正規化下限で、部分的なねじりや局所的なツイストに使います。',
 ('*', 'Main object name (internal)'): '対象メインオブジェクト名（内部用）',
 ('*', 'Make Pipe / Cable'): 'パイプ / ケーブル化',
 ('*', 'Mark all faces smooth before or while applying the modifier.'): 'モディファイア適用前または適用時に全フェースをスムーズ表示にします。',
 ('*', "Match the selected objects' world-space location to the active object on the enabled axes."): '有効な軸について、選択オブジェクトのワールド空間位置をアクティブオブジェクトへ揃えます。',
 ('*', "Match the selected objects' world-space rotation to the active object."): '選択オブジェクトのワールド空間回転をアクティブオブジェクトへ揃えます。',
 ('*', "Match the selected objects' world-space scale to the active object on the enabled axes."): '有効な軸について、選択オブジェクトのワールド空間スケールをアクティブオブジェクトへ揃えます。',
 ('*', 'Max-style Edit Poly Layer functionality (integrates with Smart Modifier).'): 'Max風編集ポリゴンレイヤー機能（Smart '
                                                                                           'Modifier Toolsetと連携）',
 ('*', 'Maximum extra random Z rotation in degrees.'): '追加で与える Z 軸ランダム回転の最大角度です。',
 ('*', 'Maximum extra random offset in X/Y for each selected object.'): '各選択オブジェクトに対して加える、X/Y 方向の最大ランダムオフセットです。',
 ('*', 'Maximum extra random offset in Z for each selected object.'): '各選択オブジェクトに対して加える、Z 方向の最大ランダムオフセットです。',
 ('*', 'Maximum extra rotation around the path tangent.'): 'パス接線方向まわりに加える追加ランダム回転の最大角度です。',
 ('*', 'Maximum random rotation around the local up axis in degrees.'): 'ローカル上方向まわりに加えるランダム回転の最大角度（度）です。',
 ('*', 'Maximum random scale used by the scatter operator.'): '散布時に使用するランダムスケールの最大値です。',
 ('*', 'Maximum uniform scale multiplier.'): '一様スケール倍率の最大値です。',
 ('*', 'Max風編集ポリゴンレイヤー機能（Smart Modifierと連携）'): 'Max風ポリ編集レイヤー機能（Smart Modifierと連携）',
 ('*', 'Merge / Snap'): 'マージ / スナップ',
 ('*', 'Merge Array Vertices'): '配列頂点を結合',
 ('*', 'Merge Distance'): '結合距離',
 ('*', 'Merge threshold used by symmetry operations.'): '対称処理で使用する結合しきい値です。',
 ('*', 'Merge touching vertices in the generated array when the modifier supports it.'): 'モディファイアが対応している場合、配列で接触する頂点を結合します。',
 ('*', 'Mesh Align'): 'Mesh Align',
 ('*', 'Minimum random scale used by the scatter operator.'): '散布時に使用するランダムスケールの最小値です。',
 ('*', 'Minimum uniform scale multiplier.'): '一様スケール倍率の最小値です。',
 ('*', 'Mirror Clip'): 'Mirror のクリップ',
 ('*', 'Mixed'): '混在のみ',
 ('*', 'Modifier Targets'): 'モディファイアターゲット',
 ('*', 'Modifier management tool...'): 'モディファイアの一括管理ツール。多言語ツールチップ対応。',
 ('*', 'Modifier name (internal)'): '対象モディファイア名（内部用）',
 ('*', 'Modifier name used when targeting by NAME.\nThis is managed automatically.'): '名前指定時に使われるモディファイア名です。\n'
                                                                                      '自動管理されます。',
 ('*', 'Modifier type used when targeting by TYPE (example: SUBSURF, MIRROR).\nThis is managed automatically.'): 'タイプ指定時に使われるモディファイアの種類です（例：サブサーフ、ミラー）。\n'
                                                                                                                 '自動管理されます。',
 ('*', 'Modifiers'): 'モディファイア',
 ('*', 'Mods'): 'モディファイア',
 ('*', 'Move'): '移動',
 ('*', "Move each selected object's origin to the world-space bottom center of its bounds without changing the visible shape. Useful for layout, DropIt-style dressing, stacking, and easier floor placement."): '各選択オブジェクトの原点を、見た目の形状を変えずにワールド空間での境界ボックス下端中央へ移動します。レイアウト、DropIt '
                                                                                                                                                                                                                 '風の配置、積み重ね、床置き作業をしやすくする用途に便利です。',
 ('*', 'Move matching modifiers down (toward the bottom of the stack)'): '一致するモディファイアを下へ移動します（スタックの末尾方向）',
 ('*', 'Move matching modifiers down one step in the stack (scope)'): '一致するモディファイアをスタック内で1つ下へ移動します(指定範囲)',
 ('*', 'Move matching modifiers up (toward the top of the stack)'): '一致するモディファイアを上へ移動します（スタックの先頭方向）',
 ('*', 'Move matching modifiers up one step in the stack (scope)'): '一致するモディファイアをスタック内で1つ上へ移動します(指定範囲)',
 ('*', "Move the active mesh object's origin to the center of the current edit selection without changing the visible shape. Useful for local bend / twist control, kitbash pivots, and temporary action-center style edits."): 'アクティブメッシュオブジェクトの原点を、見た目の形状を変えずに現在の編集選択の中心へ移動します。ローカルな '
                                                                                                                                                                                                                                'Bend '
                                                                                                                                                                                                                                '/ '
                                                                                                                                                                                                                                'Twist '
                                                                                                                                                                                                                                '制御、キットバッシュのピボット調整、一時的な '
                                                                                                                                                                                                                                'Action '
                                                                                                                                                                                                                                'Center '
                                                                                                                                                                                                                                '的編集に便利です。',
 ('*', 'Move the matching modifiers DOWN by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.'): '指定範囲の全オブジェクトで一致するモディファイアを1段下へ移動します。\n'
                                                                                                                                                                '複数オブジェクトの順番を揃えたいときに便利です。',
 ('*', 'Move the matching modifiers DOWN by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): '指定範囲の全オブジェクトで一致するモディファイアを1段下へ移動します。\n'
                                                                                                                                                                                                                                   '複数オブジェクトの順番を揃えたいときに便利です。\n'
                                                                                                                                                                                                                                   'ヒント：順番は結果に影響します。移動すると形状が変わることがあります。',
 ('*', 'Move the matching modifiers UP by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.'): '指定範囲の全オブジェクトで一致するモディファイアを1段上へ移動します。\n'
                                                                                                                                                              '複数オブジェクトの順番を揃えたいときに便利です。',
 ('*', 'Move the matching modifiers UP by one step for every object in the current scope.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): '指定範囲の全オブジェクトで一致するモディファイアを1段上へ移動します。\n'
                                                                                                                                                                                                                                 '複数オブジェクトの順番を揃えたいときに便利です。\n'
                                                                                                                                                                                                                                 'ヒント：順番は結果に影響します。移動すると形状が変わることがあります。',
 ('*', 'N-gon'): 'N角形',
 ('*', 'Name'): '名前',
 ('*', 'Nearest Surface'): '最近接面',
 ('*', 'Need a face selection to run Smart Extrude Clean'): 'Smart Extrude Clean の実行には面選択が必要です',
 ('*', 'Need a mesh with non-zero extent along the chosen slice axis'): '選択したスライス軸方向に十分な大きさを持つメッシュが必要です',
 ('*', 'Need a usable active curve with at least two points'): '少なくとも2点以上を持つ使用可能なアクティブカーブが必要です',
 ('*', 'Need an active component mesh and at least one other selected target mesh'): 'アクティブなコンポーネント用メッシュと、他に少なくとも1つの対象メッシュが必要です',
 ('*', 'Need an active face or a selected edge'): 'アクティブ面または選択辺が必要です',
 ('*', 'Need an active mesh face in Edit Mode'): '編集モードでアクティブなメッシュ面が必要です',
 ('*', 'Need an active mesh in Edit Mode'): '編集モードのアクティブメッシュが必要です',
 ('*', 'Need an active mesh in Edit Mode with exactly 2 selected edges'): '編集モードのアクティブメッシュと、ちょうど2本の選択辺が必要です',
 ('*', 'Need an active mesh object'): 'アクティブなメッシュオブジェクトが必要です',
 ('*', 'Need an active mesh object in Object Mode'): 'オブジェクトモードでアクティブなメッシュオブジェクトが必要です',
 ('*', 'Need an active mesh or curve object'): 'アクティブなメッシュまたはカーブオブジェクトが必要です',
 ('*', 'Need an active source object plus at least one other selected object'): 'アクティブな基準オブジェクトと、他に少なくとも1つの選択オブジェクトが必要です',
 ('*', 'Need another selected target mesh besides the active source mesh'): 'アクティブな元メッシュ以外に、選択された対象メッシュが必要です',
 ('*', 'Need at least 2 selected vertices to straighten'): '直線化には少なくとも2つの選択頂点が必要です',
 ('*', 'Need at least 3 selected vertices for circle fitting'): '円形化には少なくとも3つの選択頂点が必要です',
 ('*', 'Need at least two selected objects in Object Mode'): 'オブジェクトモードで少なくとも2つの選択オブジェクトが必要です',
 ('*', 'Need exactly two selected curve objects or exactly two selected edge paths'): 'ちょうど2つの選択カーブ、またはちょうど2本の選択エッジパスが必要です',
 ('*', 'Need selected mesh components on the active object'): 'アクティブオブジェクト上で選択メッシュ要素が必要です',
 ('*', 'Need selected mesh edges in Edit Mode'): '編集モードで選択されたメッシュエッジが必要です',
 ('*', 'Need selected vertices in Edit Mode'): '編集モードで選択された頂点が必要です',
 ('*', 'New Set Name'): '新規セット名',
 ('*', 'Ngons'): 'Nゴン',
 ('*', 'No dependency enforcement (match Smart Modifier UI behavior).'): '依存関係を自動で強制しない（Smart Modifier '
                                                                         '側の挙動に合わせる）。',
 ('*', 'No matching issues were found on the active mesh'): 'アクティブメッシュ上に一致する問題は見つかりませんでした',
 ('*', 'No mesh objects selected for audit'): '監査対象のメッシュオブジェクトが選択されていません',
 ('*', 'No modifiers found in scope.'): '指定範囲にモディファイアが見つかりませんでした。',
 ('*', 'No new slice edges were generated'): '新しいスライスエッジは生成されませんでした',
 ('*', 'No objects.'): 'オブジェクトがありません。',
 ('*', 'No target faces were found'): '対象面が見つかりませんでした',
 ('*', 'No targets.'): 'ターゲットがありません。',
 ('*', 'No valid lattice found.'): '有効なラティスが見つかりません。',
 ('*', 'No valid surface hit was found for the selected vertices on the target mesh'): '対象メッシュ上で、選択頂点に対する有効なサーフェスヒットが見つかりませんでした',
 ('*', 'No valid surface triangles were found on the active object'): 'アクティブオブジェクト上に有効な面三角形が見つかりませんでした',
 ('*', 'Non-manifold'): '非多様体',
 ('*', 'Non-manifold Edges'): '非多様体辺',
 ('*', 'None'): 'なし',
 ('*', 'Number of divisions in U (mainly X) direction.'): 'U方向（主にX方向）の分割数です。',
 ('*', 'Number of divisions in V (mainly Y) direction.'): 'V方向（主にY方向）の分割数です。',
 ('*', 'Number of divisions in W (mainly Z) direction.'): 'W方向（主にZ方向）の分割数です。',
 ('*', 'Number of evenly spaced slice helper boxes to create.'): '生成する等間隔スライス補助ボックス数です。',
 ('*', 'Number of evenly spaced slice planes inserted between the local minimum and maximum bounds.'): 'ローカル最小値と最大値の間に挿入する等間隔スライス平面の数です。',
 ('*', 'Number of instances to place along the active curve.'): 'アクティブカーブに沿って配置するインスタンス数です。',
 ('*', 'Number of lattice control points along the local U axis.'): 'ローカル U 軸方向のラティス制御点数です。',
 ('*', 'Number of lattice control points along the local V axis.'): 'ローカル V 軸方向のラティス制御点数です。',
 ('*', 'Number of lattice control points along the local W axis.'): 'ローカル W 軸方向のラティス制御点数です。',
 ('*', 'Number of linked instances to scatter across the active surface.'): 'アクティブ面へ散布するリンクインスタンス数です。',
 ('*', 'Number of sampled points used for each helix turn. Higher values create a smoother path.'): 'ヘリックス1周ごとに使うサンプル点数です。高いほど滑らかなパスになります。',
 ('*', 'Number of sampled points used to rebuild the active curve.'): 'アクティブカーブを再構築するために使用するサンプル点数です。',
 ('*', 'Number of sampled points used when lofting between two paths.'): '2本のパス間をロフトする際に使用するサンプル点数です。',
 ('*', 'Number of turns used by the generated helix path. Fractional values are allowed.'): '生成するヘリックスパスの巻数です。小数値も使えます。',
 ('*', 'OFF'): 'OFF',
 ('*', 'ON'): 'ON',
 ('*', 'Object Filter'): 'オブジェクト検索',
 ('*', 'Object Mode = Mirror Modifier'): 'オブジェクトモードでは Mirror 使用',
 ('*', 'Object Mode destructive symmetry is not supported; enable Object Mode = Mirror Modifier or switch to Edit Mode'): 'オブジェクトモードでの破壊的対称化は未対応です。Object '
                                                                                                                          'Mode '
                                                                                                                          '= '
                                                                                                                          'Mirror '
                                                                                                                          'Modifier '
                                                                                                                          'を有効にするか、編集モードへ切り替えてください',
 ('*', 'Object Mode required'): 'オブジェクトモードが必要です',
 ('*', 'Object name in the applied object list.\nThis is generated automatically.'): '適用オブジェクトリストに表示されるオブジェクト名です。\n'
                                                                                     '自動生成されます。',
 ('*', 'Objects'): 'オブジェクト数',
 ('*', 'Objects in a specific collection'): '指定コレクション内のオブジェクト',
 ('*', 'Objects in the active collection'): 'アクティブコレクション内のオブジェクト',
 ('*', 'Offset direction for the Solidify shell. Use 0 for centered shells, 1 for outward, and -1 for inward bias.'): 'Solidify '
                                                                                                                      'シェルのオフセット方向です。0 '
                                                                                                                      'は中央、1 '
                                                                                                                      'は外側寄り、-1 '
                                                                                                                      'は内側寄りです。',
 ('*', 'Offset kept above the hit surface after dropping.'): 'ドロップ後にヒット面から少し浮かせて保つ距離です。',
 ('*', 'Offset kept between the conformed detail and the target surface.'): '追従させたディテールと対象面の間に保つ距離です。',
 ('*', 'Offset the placed component along the target face normal.'): '配置したコンポーネントを対象面法線方向へオフセットします。',
 ('*', 'On Cage'): 'ケージ',
 ('*', 'Optional radius limit used by the Cast modifier when supported. Set 0 to let Blender manage it automatically.'): '対応している場合に '
                                                                                                                         'Cast '
                                                                                                                         'モディファイアで使う任意の半径制限です。0 '
                                                                                                                         'なら '
                                                                                                                         'Blender '
                                                                                                                         '側に任せます。',
 ('*', 'Organize'): '整理',
 ('*', 'Organize Cutters'): 'カッターを整理',
 ('*', 'Organize Details'): 'ディテールを整理',
 ('*', 'Organize Path Instances'): 'パス配置を整理',
 ('*', 'Organize Slice Helpers'): 'スライス補助を整理',
 ('*', 'Organize generated slice helpers into a dedicated collection.'): '生成スライス補助を専用コレクションへ整理します。',
 ('*', 'Outside Only'): '外側のみ',
 ('*', 'Overall height of the generated profile primitive. Circle and N-gon types use this as the Y diameter.'): '生成する断面プリミティブの全高です。円形とN角形ではY方向の直径として使われます。',
 ('*', 'Overall width of the generated profile primitive. Circle and N-gon types use this as the X diameter.'): '生成する断面プリミティブの全幅です。円形とN角形ではX方向の直径として使われます。',
 ('*', 'Overlay'): '表示',
 ('*', 'Overwrite'): '上書き',
 ('*', 'Overwrite selected state set'): '選択中の状態セットを上書き保存します',
 ('*', 'Overwrite the selected State Set with the current ON/OFF state.\nUse this to update a preset after you make changes.'): '選択中のステートセットを現在の状態で上書きします。\n'
                                                                                                                                'プリセットを更新したいときに使います。',
 ('*', 'Overwrite the selected State Set with the current modifier ON/OFF + display states.\nUse this to update a preset after you make changes.\nCaution: This replaces the saved snapshot (Undo can revert).'): '選択中のステートセットを、現在のモディファイア状態で上書きします。\n'
                                                                                                                                                                                                                  '変更後にプリセットを更新したいときに使います。\n'
                                                                                                                                                                                                                  '注意：保存内容を置き換えます（Undoで戻せます）。',
 ('*', 'Parent To Source'): '元オブジェクトへ親子付け',
 ('*', 'Parent To Surface'): '面へ親子付け',
 ('*', 'Parent the conformed detail objects to the active surface for easier scene organization.'): '追従させたディテールオブジェクトをアクティブ面の子にして整理しやすくします。',
 ('*', 'Parent the generated detail to the source object for easier scene organization.'): 'シーン整理しやすいよう、生成ディテールを元オブジェクトの子にします。',
 ('*', 'Path / Replace / Randomize'): 'パス / 置換 / ランダム化',
 ('*', 'Path Count'): 'パス配置数',
 ('*', 'Path From Objects'): 'オブジェクトからパス作成',
 ('*', 'Pattern / Architecture'): 'パターン / 建築',
 ('*', 'Pin'): 'ピン',
 ('*', 'Pin/unpin the selected target.\nPinned targets stay at the top of the Modifier List for quick access, and are kept even if temporarily missing.\nBeginner tip: Use Pin for important modifiers you always want to see/control.'): '選択中のターゲットをピン留め/解除します。\n'
                                                                                                                                                                                                                                          'ピン留めしたターゲットは先頭に固定され、一時的に見つからない状態でもリストに残ります。\n'
                                                                                                                                                                                                                                          '初心者ヒント：常に見たい/操作したい重要なモディファイアはピン留めしておくと便利です。',
 ('*', 'Pin/unpin the selected target.\nPinned targets stay at the top of the Modifier List for quick access.'): '選択中のターゲットをピン留め/解除します。\n'
                                                                                                                 'ピン留めしたターゲットはモディファイアリストの先頭に固定されます。',
 ('*', 'Pin/unpin this target'): 'このターゲットをピン留め/解除します',
 ('*', 'Pinned'): 'ピン留め',
 ('*', 'Pipe Radius'): 'パイプ半径',
 ('*', 'Pipe Resolution'): 'パイプ解像度',
 ('*', 'Pivot / Origin Helpers'): 'ピボット / 原点ヘルパー',
 ('*', 'Pivot To Bottom'): '下端へピボット移動',
 ('*', 'Pivot To Selection'): '選択へピボット移動',
 ('*', 'Pivot moved to object bottom bounds'): 'ピボットをオブジェクト下端へ移動しました',
 ('*', 'Pivot moved to the current selection center'): 'ピボットを現在の選択中心へ移動しました',
 ('*', 'Point count used for circle, N-gon, and star profile generation.'): '円形、N角形、星形プロファイルの生成に使うポイント数です。',
 ('*', 'Points / Turn'): '1周あたりポイント数',
 ('*', 'Potential Doubles'): '重複候補',
 ('*', 'Precision / Layout / Path'): '精密 / レイアウト / パス',
 ('*', 'Precision / Layout Guide'): '精密 / レイアウト ガイド',
 ('*', 'Prefer Grid Fill'): 'Grid Fill優先',
 ('*', 'Prefer LoopTools'): 'LoopTools を優先',
 ('*', 'Preserve Collections'): 'コレクションを維持',
 ('*', 'Preserve existing sharp-edge shading when the modifier supports it.'): 'モディファイアが対応している場合、既存のシャープエッジの陰影を保持します。',
 ('*', 'Primary axis used by the Bend deformer.'): 'Bend デフォーマで使う主軸です。',
 ('*', 'Primary axis used by the Taper deformer.'): 'Taper デフォーマで使う主軸です。',
 ('*', 'Primary axis used by the Twist deformer.'): 'Twist デフォーマで使う主軸です。',
 ('*', 'Primitive type used by the Cast modifier.'): 'Cast モディファイアで使用するプリミティブ形状です。',
 ('*', 'Profile / Helix'): '断面 / ヘリックス',
 ('*', 'Profile / Path Primitives'): '断面 / パス プリミティブ',
 ('*', 'Profile Height'): '断面高さ',
 ('*', 'Profile Points'): '断面ポイント数',
 ('*', 'Profile Type'): '断面タイプ',
 ('*', 'Profile Width'): '断面幅',
 ('*', 'Project'): '投影',
 ('*', 'Project Offset'): '投影オフセット',
 ('*', 'Project To Active Plane'): 'アクティブ面へ投影',
 ('*', 'Project To Selected Surface'): '選択面へサーフェス投影',
 ('*', 'Project onto the surface along the object local Z axis when supported'): '対応している場合はオブジェクトのローカル Z '
                                                                                 '軸方向へ投影して面へ追従させます。',
 ('*', 'Project selected vertices of the active mesh onto the nearest points of another selected mesh. Useful for retopo, shrinkwrap-style cleanup, panel wrapping, and keeping blockout strips glued to a target surface.'): 'アクティブメッシュの選択頂点を、別の選択メッシュ上の最近接点へ投影します。リトポ、Shrinkwrap '
                                                                                                                                                                                                                              '風の調整、パネル貼り付け、ブロックアウト帯の面追従に便利です。',
 ('*', 'Project selected vertices onto the active face plane with an optional offset. Useful for projection modeling, CAD-like flattening, and keeping panel details flush to a surface.'): '選択頂点をアクティブ面の平面へ、必要に応じたオフセット付きで投影します。Projection '
                                                                                                                                                                                            'Modeling '
                                                                                                                                                                                            'や '
                                                                                                                                                                                            'CAD '
                                                                                                                                                                                            'ライクな平坦化、面へ揃えたパネルディテール作成に便利です。',
 ('*', 'Project the current selected vertices onto the best line defined by the farthest selected pair. Useful for fast edge straightening and mesh unbending inspired by Align Edges and Unbend Mesh style tools.'): '選択頂点のうち最も離れた2点で定義される直線へ投影し、直線化します。乱れたエッジの整列やメッシュの矯正など、Align '
                                                                                                                                                                                                                      'Edges '
                                                                                                                                                                                                                      '/ '
                                                                                                                                                                                                                      'Unbend '
                                                                                                                                                                                                                      'Mesh '
                                                                                                                                                                                                                      '系の用途に向いています。',
 ('*', 'Projected selected vertices to the active plane'): '選択頂点をアクティブ平面へ投影しました',
 ('*', 'Projected selected vertices to the selected target surface'): '選択頂点を選択対象サーフェスへ投影しました',
 ('*', 'Push scattered instances away from the surface along the normal.'): '散布インスタンスを法線方向へ少し浮かせます。',
 ('*', 'Quad Checker'): 'クアッドチェッカー',
 ('*', 'Quad Checker selected matching faces'): 'Quad Checker で一致する面を選択しました',
 ('*', 'Quad Filter'): 'クアッドフィルター',
 ('*', 'Quick Bend Deformer'): 'クイックベンドデフォーマ',
 ('*', 'Quick Lattice Cage'): 'クイックラティスケージ',
 ('*', 'Quick Solidify Plus'): 'クイック厚み付けプラス',
 ('*', 'Quick Symmetry'): 'クイック対称化',
 ('*', 'Quick Taper Deformer'): 'クイックテーパーデフォーマ',
 ('*', 'Quick Twist Deformer'): 'クイックツイストデフォーマ',
 ('*', 'Quick access to the deeper suite tools is kept below so beginners can start from the hub and advanced users can still jump to the specialized operators.'): '初心者はこのハブから始められ、熟練者は下のボタンから既存の専門ツールへすぐ移動できるようにしています。',
 ('*', 'Quick profile and helix primitives for sweep, trim, cable, and spring workflows.'): 'スイープ、トリム、ケーブル、バネ向けの断面 / '
                                                                                            'ヘリックスの簡易プリミティブです。',
 ('*', 'Random Roll (deg)'): 'ランダムロール（度）',
 ('*', 'Random Seed'): 'ランダムシード',
 ('*', 'Random XY Offset'): 'ランダムXYオフセット',
 ('*', 'Random Z (deg)'): 'ランダムZ回転（度）',
 ('*', 'Random Z Offset'): 'ランダムZオフセット',
 ('*', 'Random Z Rotation (deg)'): 'ランダムZ回転（度）',
 ('*', 'Random seed used for scatter placement.'): '散布配置に使う乱数シードです。',
 ('*', 'Randomize Selected'): '選択をランダム化',
 ('*', 'Randomize complete'): 'ランダム化が完了しました',
 ('*', 'Rebake All'): '全レイヤー再計算',
 ('*', 'Rebuild Active Curve'): 'アクティブカーブを再構築',
 ('*', 'Rebuild Count'): '再構築点数',
 ('*', 'Rebuild the Modifier List and Object List based on the current Scope/Mode.\nUse this after adding/removing/renaming modifiers, or when Auto Refresh is OFF.'): '現在の範囲/モードに基づいて、モディファイアリストとオブジェクトリストを再構築します。\n'
                                                                                                                                                                       'モディファイアの追加/削除/リネーム後や、自動更新OFF時に使います。',
 ('*', 'Rebuild the Modifier List and Object List based on the current Scope/Mode.\nUse this after adding/removing/renaming modifiers, or when the UI looks out of date.\nTip: When Auto Refresh is ON, this runs automatically at the interval you set.'): '現在の範囲/モードに基づいて、モディファイアリストとオブジェクトリストを再構築します。\n'
                                                                                                                                                                                                                                                            'モディファイアの追加/削除/リネーム後や、表示が古いと感じたときに使います。\n'
                                                                                                                                                                                                                                                            'ヒント：自動更新がONの場合は、設定した間隔で自動的に実行されます。',
 ('*', 'Rebuilt the active curve'): 'アクティブカーブを再構築しました',
 ('*', 'Recalculate Normals'): '法線再計算',
 ('*', 'Recalculate Smart Lattice influence (the lattice-to-mesh deformation range).\n\n- Use this after changing the lattice size/position if deformation is offset or not working.\n- Automatically detects and updates the target Smart Lattice.\n\nTip: Applying/confirming lattice edits first tends to be more stable.'): 'Smart '
                                                                                                                                                                                                                                                                                                                                'Lattice '
                                                                                                                                                                                                                                                                                                                                'の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n'
                                                                                                                                                                                                                                                                                                                                '\n'
                                                                                                                                                                                                                                                                                                                                '・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n'
                                                                                                                                                                                                                                                                                                                                '・対象の '
                                                                                                                                                                                                                                                                                                                                'Smart '
                                                                                                                                                                                                                                                                                                                                'Lattice（ラティス）を自動で検出して更新します。\n'
                                                                                                                                                                                                                                                                                                                                '\n'
                                                                                                                                                                                                                                                                                                                                'ヒント：まずラティス側の変形を確定してから実行すると安定します。',
 ('*', 'Recalculate normals after cleanup to reduce shading glitches.'): 'クリーンアップ後に法線を再計算し、シェーディング乱れを抑えます。',
 ('*', 'Recalculate normals after the helper finishes.'): '処理後に法線を再計算します。',
 ('*', "Recompute all EditPoly layers. After stack changes, it rebuilds consistency between each layer's Frozen base and Edit mesh."): 'すべてのEditPolyレイヤーを再計算します。スタック構成変更後に、各レイヤーの基準形状（Frozen）と編集形状（Edit）の整合を取り直します。',
 ('*', 'Rectangle'): '矩形',
 ('*', 'Relative X offset used by the Array modifier.'): 'Arrayモディファイアで使用する相対Xオフセットです。',
 ('*', 'Relax complete'): 'リラックスが完了しました',
 ('*', 'Relax the current selected vertices or edge loop. Uses LoopTools Relax when available, and otherwise falls back to Blender smoothing for a safer all-in-one cleanup pass inspired by LoopTools, NitroRelax, and oaRelaxVerts.'): '現在の選択頂点やエッジループをリラックスします。LoopTools '
                                                                                                                                                                                                                                         'Relax '
                                                                                                                                                                                                                                         'が使える場合はそれを使い、使えない場合は '
                                                                                                                                                                                                                                         'Blender '
                                                                                                                                                                                                                                         '標準のスムージングへ安全にフォールバックします。LoopTools、NitroRelax、oaRelaxVerts '
                                                                                                                                                                                                                                         '系の用途をまとめた補助です。',
 ('*', 'Remove Modifiers'): '削除',
 ('*', 'Remove matching modifiers (scope). This is destructive.'): '一致するモディファイアを削除します(指定範囲)。破壊的操作です。',
 ('*', 'Remove target objects after the replacement copies are created.'): '置換コピー作成後に元ターゲットを削除します。',
 ('*', 'Remove the matching modifiers from all objects in the current scope.\nThis is destructive (it deletes the modifiers).'): '指定範囲の全オブジェクトから一致するモディファイアを削除します。\n'
                                                                                                                                 'モディファイア自体を消す破壊的操作です。',
 ('*', 'Remove the matching modifiers from all objects in the current scope.\nThis is destructive (it deletes the modifiers).\nTip: If you might need them later, use OFF (disable) instead of removing.'): '指定範囲の全オブジェクトから一致するモディファイアを削除します。\n'
                                                                                                                                                                                                            'モディファイア自体を消す破壊的操作です。\n'
                                                                                                                                                                                                            'ヒント：後で必要になるかもなら、削除ではなくOFF（無効化）がおすすめです。',
 ('*', 'Render visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'レンダー表示の状態（ON／OFF／MIXED）です。\n'
                                                                                                              '自動計算されます。',
 ('*', 'Repair common mesh issues on the selected mesh objects: merge doubles, dissolve degenerates, delete loose geometry, optionally fill holes, optionally join triangles to quads, and recalculate normals. Designed as a safe recovery pass for imported assets, boolean-heavy meshes, and messy kitbash data.'): '選択メッシュのよくある問題をまとめて修復します。重複頂点の統合、縮退要素の削除、ルーズジオメトリ削除、必要に応じた穴埋め、三角形の四角化、法線再計算を行います。インポート資産、ブーリアン多用メッシュ、荒れたキットバッシュデータの安全な復旧処理向けです。',
 ('*', 'Replace With Active'): 'アクティブで置換',
 ('*', 'Replace the selected target objects with copies of the active object while preserving each target transform. Useful for instance replacement, kitbash swaps, and proxy-to-final workflows.'): '選択ターゲットを、アクティブオブジェクトのコピーで置換し、各ターゲットの変換を維持します。インスタンス置換、キットバッシュ差し替え、プロキシから本番資産への置換に便利です。',
 ('*', 'Replacement complete'): '置換が完了しました',
 ('*', 'Replacement, randomization, face-based component placement, drop-to-surface, isolation, and audit helpers for archviz, kitbash layout, and environment dressing.'): '置換、ランダム化、面ベース配置、面へのドロップ、孤立表示、監査をまとめ、Archviz、キットバッシュ配置、環境ドレッシングを素早く行えるようにします。',
 ('*', 'Resample the active curve into a cleaner evenly spaced poly spline. Useful for MoI/ CAD-style curve rebuild workflows before pipes, sweeps, and path arrays.'): 'アクティブカーブを、間隔の揃ったよりクリーンなポリスプラインへ再サンプリングします。パイプ、スイープ、パス配列の前処理として、MoI '
                                                                                                                                                                        '/ '
                                                                                                                                                                        'CAD '
                                                                                                                                                                        '系のカーブ再構築ワークフローに便利です。',
 ('*', 'Resolution'): '解像度',
 ('*', 'Resolve exactly two selected edges in Edit Mode. Intersect inserts a shared intersection point when the line crossing lies on both segments. Extend moves the nearest endpoints so the edges meet at the resolved point. Useful as a tinyCAD-style precision helper.'): '編集モードで選択した '
                                                                                                                                                                                                                                                                                '2 '
                                                                                                                                                                                                                                                                                '本の辺を解決します。Intersect '
                                                                                                                                                                                                                                                                                'は交点が両セグメント上にある場合に共有交点を挿入し、Extend '
                                                                                                                                                                                                                                                                                'は最近接端点を移動して辺同士を交わらせます。tinyCAD '
                                                                                                                                                                                                                                                                                '系の精密補助として便利です。',
 ('*', 'Reuse Existing'): '既存を再利用',
 ('*', 'Rotate instances so their local X axis follows the sampled path tangent.'): 'インスタンスのローカル X '
                                                                                    '軸が、サンプリングしたパス接線方向に沿うよう回転させます。',
 ('*', 'Row-to-row offset ratio used to stagger floor boards.'): '各列の床板をずらす比率です。',
 ('*', 'Run EdgeNet Prepare / Fill before generic face fill. This improves success on branchy edge networks and patch-like selections.'): '汎用的な面生成の前に '
                                                                                                                                          'EdgeNet '
                                                                                                                                          'Prepare '
                                                                                                                                          '/ '
                                                                                                                                          'Fill '
                                                                                                                                          'を実行します。枝分かれしたエッジネットワークやパッチ状の選択で成功率が上がります。',
 ('*', 'Run a compact face-modeling helper that optionally insets first, then extrudes and shrink-fattens the current selection. This acts as a practical Blender-native helper inspired by Maya Smart Extrude and ZModeler QMesh style workflows.'): '必要に応じて先にインセットし、その後に押し出しと '
                                                                                                                                                                                                                                                      'Shrink/Fatten '
                                                                                                                                                                                                                                                      'を行う、コンパクトな面モデリング補助です。Maya '
                                                                                                                                                                                                                                                      'の '
                                                                                                                                                                                                                                                      'Smart '
                                                                                                                                                                                                                                                      'Extrude '
                                                                                                                                                                                                                                                      'や '
                                                                                                                                                                                                                                                      'ZModeler '
                                                                                                                                                                                                                                                      'の '
                                                                                                                                                                                                                                                      'QMesh '
                                                                                                                                                                                                                                                      '系ワークフローを '
                                                                                                                                                                                                                                                      'Blender '
                                                                                                                                                                                                                                                      'ネイティブに寄せた実装です。',
 ('*', 'Run a conservative cleanup pass on the active or selected mesh objects, then refresh the audit summary. The repair focuses on merge-by-distance, degenerate cleanup, loose removal, and normal recalculation instead of risky topology rewrites.'): 'アクティブまたは選択メッシュへ保守的なクリーンアップを実行し、その後に監査要約を更新します。危険なトポロジー改変ではなく、距離結合、退化解消、ルーズ削除、法線再計算を中心にした修復です。',
 ('*', 'Run a light cleanup pass after joining meshes.'): 'メッシュ結合後に軽いクリーンアップを実行します。',
 ('*', 'Run a light cleanup pass on the newly separated object to reduce loose elements and normal issues.'): '分離後の新規オブジェクトに軽いクリーンアップを行い、ルーズ要素や法線の乱れを減らします。',
 ('*', 'Sample the first and last points of the path as placement positions.'): '配置位置としてパスの始点と終点を含めます。',
 ('*', 'Save New'): '新規保存',
 ('*', 'Save a new state set'): '状態セットを新規保存します',
 ('*', 'Save the current ON/OFF state of the selected target as a new State Set.\nLater you can Load it to restore the same visibility across objects.'): '選択中ターゲットのON/OFF状態を新しいステートセットとして保存します。\n'
                                                                                                                                                          '後で読み込むと同じ表示状態を素早く復元できます。',
 ('*', 'Saved state set: {}'): '状態セットを保存しました: {}',
 ('*', 'Scale Max'): '最大スケール',
 ('*', 'Scale Min'): '最小スケール',
 ('*', 'Scale To Face'): '面サイズへ合わせる',
 ('*', 'Scan scope for modifiers and rebuild lists'): '指定範囲のモディファイアをスキャンしてリストを更新します',
 ('*', 'Scatter / Environment'): '散布 / 環境構築',
 ('*', 'Scatter Count'): '散布数',
 ('*', 'Scatter Instances (Bake)'): 'インスタンス散布（ベイク）',
 ('*', 'Scatter Seed'): '散布シード',
 ('*', 'Scatter bake complete'): '散布ベイクが完了しました',
 ('*', 'Scatter linked copies of the selected source objects along the active curve using even distance sampling. Useful for Duplicate Along Path, MASH-style path layouts, trims, railing, and RailClone-like path-driven blocking.'): 'アクティブカーブに沿って、選択ソースのリンクコピーを等間隔サンプリングで配置します。Duplicate '
                                                                                                                                                                                                                                        'Along '
                                                                                                                                                                                                                                        'Path、MASH '
                                                                                                                                                                                                                                        '的なパス配置、トリム、手すり、RailClone '
                                                                                                                                                                                                                                        'ライクなパス駆動ブロックアウトに便利です。',
 ('*', 'Scatter linked object instances over the active surface using weighted triangle-area sampling. Creates a dedicated scatter collection and a root empty, making it useful for environment blocking, vegetation placement, debris, and kitbash dressing inspired by Forest Pack / Geo-Scatter style workflows.'): '三角形面積に基づく重み付きサンプリングで、アクティブ面上にリンクインスタンスを散布します。専用コレクションとルートEmptyを作成するため、環境レイアウト、植生配置、デブリ配置、キットバッシュ装飾など、Forest '
                                                                                                                                                                                                                                                                                                                        'Pack '
                                                                                                                                                                                                                                                                                                                        '/ '
                                                                                                                                                                                                                                                                                                                        'Geo-Scatter '
                                                                                                                                                                                                                                                                                                                        '系ワークフローのベイク版として有効です。',
 ('*', 'Scope'): '範囲',
 ('*', 'Search filter for the Modifier List.\nType part of a modifier type/name to narrow the list (case-insensitive).'): 'モディファイアリストの検索フィルタです。\n'
                                                                                                                          'モディファイアの種類/名前の一部を入力すると絞り込めます（大文字小文字は区別しません）。',
 ('*', 'Search filter for the Object List.\nType part of an object name to narrow the list (case-insensitive).'): 'オブジェクトリストの検索フィルタです。\n'
                                                                                                                  'オブジェクト名の一部を入力すると絞り込めます（大文字小文字は区別しません）。',
 ('*', 'Seed used for deterministic randomization.'): '再現可能なランダム化に使うシードです。',
 ('*', 'Segment count used by the auto-created bevel modifier.'): '自動作成されるベベルモディファイアの分割数です。',
 ('*', 'Select All Listed'): 'リスト内を全選択',
 ('*', 'Select Issues'): '問題要素を選択',
 ('*', 'Select New Cuts'): '新しいカットを選択',
 ('*', 'Select all objects listed'): 'リスト内のオブジェクトを全て選択します',
 ('*', 'Select at least one component in Edit Mode first'): '先に編集モードで少なくとも1つの要素を選択してください',
 ('*', 'Select at least one cutter mesh besides the active object'): 'アクティブ以外に少なくとも1つのカッターメッシュを選択してください',
 ('*', 'Select at least one detail mesh besides the active surface'): 'アクティブ面以外に少なくとも1つのディテールメッシュを選択してください',
 ('*', 'Select at least one object to randomize'): 'ランダム化するオブジェクトを少なくとも1つ選択してください',
 ('*', 'Select at least one other mesh object to join'): '結合する他のメッシュオブジェクトを少なくとも1つ選択してください',
 ('*', 'Select at least one other object besides the active surface'): 'アクティブ面以外に少なくとも1つのオブジェクトを選択してください',
 ('*', 'Select at least one scatter source object besides the active surface'): 'アクティブ面以外に、少なくとも1つの散布元オブジェクトを選択してください',
 ('*', 'Select at least one target besides the active source object'): 'アクティブソース以外に少なくとも1つのターゲットを選択してください',
 ('*', 'Select at least one vertex to project'): '投影する頂点を少なくとも1つ選択してください',
 ('*', 'Select at least three objects to distribute'): '均等配置するには少なくとも3つのオブジェクトを選択してください',
 ('*', 'Select at least two objects to stack'): 'スタック配置するには少なくとも2つのオブジェクトを選択してください',
 ('*', 'Select every object currently shown in the Object List.\nTip: Combine with Scope/filters to quickly build a selection set.'): '現在オブジェクトリストに表示されている物をまとめて選択します。\n'
                                                                                                                                      '範囲やフィルタと組み合わせると素早く選択セットを作れます。',
 ('*', 'Select every object currently shown in the Object List.\nTip: Combine with Scope/filters to quickly build a selection set.\nNote: This only changes the viewport selection; it does not edit the Object List itself.'): '現在オブジェクトリストに表示されている物をまとめて選択します。\n'
                                                                                                                                                                                                                                '範囲やフィルタと組み合わせると素早く選択セットを作れます。\n'
                                                                                                                                                                                                                                '補足：これはビューポートの選択を変えるだけで、オブジェクトリスト自体は編集しません。',
 ('*', 'Select loose vertices and wire edges on the active mesh.'): 'アクティブメッシュのルーズ頂点とワイヤエッジを選択します。',
 ('*', 'Select non-manifold edges on the active mesh.'): 'アクティブメッシュの非多様体エッジを選択します。',
 ('*', 'Select one curve object together with the active mesh object'): 'アクティブメッシュと一緒に、1つのカーブオブジェクトを選択してください',
 ('*', 'Select one or more objects'): '1つ以上のオブジェクトを選択してください',
 ('*', 'Select one or more vertices / edges / faces first, or disable Use Selection Bounds'): '先に頂点 / 辺 / '
                                                                                              '面を1つ以上選択するか、選択範囲の境界を使う '
                                                                                              'を無効にしてください',
 ('*', 'Select only the clicked object (deselect others)'): 'クリックしたオブジェクトだけ選択する（他は解除）',
 ('*', 'Select quads, non-quads, triangles, or ngons on the active edit mesh for fast topology inspection before subdivision, export, bevel, or retopo cleanup.'): 'アクティブな編集メッシュ上で、クアッド、非クアッド、三角形、Nゴンを素早く選択し、サブディビジョン、書き出し、ベベル、リトポ整理前のトポロジー確認を行います。',
 ('*', 'Select some edges in Edit Mode first'): '先に編集モードでエッジを選択してください',
 ('*', 'Select the chosen audit issue type on the active mesh so you can inspect or repair it directly.'): '選んだ監査問題タイプをアクティブメッシュ上で選択し、直接確認や修復ができるようにします。',
 ('*', 'Select the newly generated cut edges after Axis Slice Edit runs.'): 'Axis Slice Edit '
                                                                            '実行後に、新しく生成されたカットエッジを選択します。',
 ('*', 'Select vertices that look like double candidates within the configured audit merge distance.'): '設定した監査マージ距離内で重複候補に見える頂点を選択します。',
 ('*', 'Select zero-length or near-zero-length edges on the active mesh.'): 'アクティブメッシュの長さゼロまたは極小長のエッジを選択します。',
 ('*', 'Selected'): '選択のみ',
 ('*', 'Selected + Children'): '選択+子階層',
 ('*', 'Selected Edges To Curve'): '選択エッジをカーブ化',
 ('*', 'Selected Faces Only'): '選択面のみ',
 ('*', 'Selected Objects To Path'): '選択オブジェクトをパス化',
 ('*', 'Selected Vertices To Path'): '選択頂点をパス化',
 ('*', 'Selected edges are parallel or could not be resolved'): '選択辺が平行か、交点を解決できませんでした',
 ('*', 'Selected issue elements'): '問題要素を選択しました',
 ('*', 'Selected objects and their children'): '選択中のオブジェクトとその子',
 ('*', 'Selected {} objects.'): '{} 個のオブジェクトを選択しました。',
 ('*', 'Selection Behavior'): '選択挙動',
 ('*', 'Selection Sync'): '選択同期',
 ('*', 'Separate the current selection into a new object with an optional duplicate-first step and a light cleanup pass. This acts as a safe Blender-friendly helper inspired by Maya detachSeparate and similar clean detachment utilities.'): '現在の選択を新しいオブジェクトへ分離します。必要なら複製してから分離し、軽いクリーンアップも行います。Maya '
                                                                                                                                                                                                                                                'の '
                                                                                                                                                                                                                                                'detachSeparate '
                                                                                                                                                                                                                                                'などを意識した、Blender向けの安全な分離補助です。',
 ('*', 'Set active object without clearing selection'): '選択を解除せずにアクティブ化する',
 ('*', 'Set the lattice divisions (U/V/W).\nChoose a preset (2/3/4) or Custom.\n\nNote: Higher values allow finer deformation but are heavier.'): 'ラティスの分割数（U/V/W）を指定します。\n'
                                                                                                                                                  'プリセット（2/3/4）またはカスタムを選択できます。\n'
                                                                                                                                                  '\n'
                                                                                                                                                  '※値が大きいほど細かく変形できますが処理が重くなります。',
 ('*', 'Shade Smooth'): 'スムーズシェード',
 ('*', 'Shade Smooth Loft'): 'ロフトをスムーズシェード',
 ('*', 'Show Details'): '詳細を表示',
 ('*', 'Show Modifier List'): 'モディファイアリストを表示',
 ('*', 'Show Object List'): 'オブジェクトリストを表示',
 ('*', 'Show Objects'): '表示フィルタ',
 ('*', 'Show Settings'): '設定を表示',
 ('*', 'Show State Sets'): 'ステートセットを表示',
 ('*', 'Show a lightweight standalone N-panel tab so you can still add/rebake layers without Smart Modifier.\nNormally, managing layers from Smart Modifier is recommended. Turn this ON only when you want standalone operation.'): 'Smart '
                                                                                                                                                                                                                                                 'Modifier '
                                                                                                                                                                                                                                                 'Toolset '
                                                                                                                                                                                                                                                 'を使わない環境でも最低限の追加/再計算を行えるように、Nパネルに単体用の簡易タブを表示します。\n'
                                                                                                                                                                                                                                                 '通常は '
                                                                                                                                                                                                                                                 'Smart '
                                                                                                                                                                                                                                                 'Modifier '
                                                                                                                                                                                                                                                 'Toolset '
                                                                                                                                                                                                                                                 'から管理するのがおすすめです。単体運用時だけ '
                                                                                                                                                                                                                                                 'ON '
                                                                                                                                                                                                                                                 'にしてください。',
 ('*', 'Show a lightweight standalone N-panel tab so you can still use Smart Lattice without Smart Modifier.\nNormally, managing it from Smart Modifier is recommended. Turn this ON only for standalone use.'): 'Smart '
                                                                                                                                                                                                                             'Modifier '
                                                                                                                                                                                                                             'Toolset '
                                                                                                                                                                                                                             'が無い環境でも '
                                                                                                                                                                                                                             'Smart '
                                                                                                                                                                                                                             'Lattice '
                                                                                                                                                                                                                             'を最低限操作できるように、N '
                                                                                                                                                                                                                             'パネルに単体用の簡易タブを表示します。\n'
                                                                                                                                                                                                                             '通常は '
                                                                                                                                                                                                                             'Smart '
                                                                                                                                                                                                                             'Modifier '
                                                                                                                                                                                                                             'Toolset '
                                                                                                                                                                                                                             'から管理するのがおすすめです。単体運用時だけ '
                                                                                                                                                                                                                             'ON '
                                                                                                                                                                                                                             'にしてください。',
 ('*', 'Show a minimal UI in the N-panel so the tool can be used without Smart Modifier. Normally, manage layers with Smart Modifier.'): 'Smart '
                                                                                                                                                     'Modifier '
                                                                                                                                                     'Toolsetが無い環境でも最低限操作できるよう、Nパネルに簡易UIを表示します。通常はSmart '
                                                                                                                                                     'Modifier '
                                                                                                                                                     'Toolsetで管理してください。',
 ('*', 'Show a standalone N-panel tab even without Smart Modifier.'): 'Smart Modifier '
                                                                            'Toolsetがない環境でも使えるように、独自のNパネルタブを表示します',
 ('*', 'Show all objects in the current scope'): '現在の範囲内の全オブジェクトを表示',
 ('*', 'Show dedicated N-panel tab'): 'Nパネルに専用タブを表示',
 ('*', 'Show dedicated tab in N-panel'): 'Nパネルに専用タブを表示',
 ('*', 'Show generated slice helpers as wire objects.'): '生成スライス補助をワイヤ表示にします。',
 ('*', 'Show objects with a mixed state (multiple matches)'): '状態が混在しているオブジェクトを表示（複数一致など）',
 ('*', 'Show only objects that are currently visible in the viewport.\nHidden or excluded objects are ignored (useful to skip helper objects).'): 'ビューポートで現在表示されているオブジェクトだけを一覧に出します。\n'
                                                                                                                                                  '非表示/除外されている物は無視されます（補助オブジェクトを除外したい時に便利）。',
 ('*', 'Show only objects where the target is OFF'): 'ターゲットがOFFのオブジェクトだけ表示',
 ('*', 'Show only objects where the target is ON'): 'ターゲットがONのオブジェクトだけ表示',
 ('*', 'Show/hide the Details section.\n\nThis only folds the UI to save space.'): '詳細 セクションの表示/非表示。\n'
                                                                                   '\n'
                                                                                   'UIを折りたたんで省スペースにするだけです。',
 ('*', 'Show/hide the Modifier List section.\n\nThis only folds the UI to save space; it does not change any modifiers.'): 'モディファイアリスト '
                                                                                                                           'セクションの表示/非表示。\n'
                                                                                                                           '\n'
                                                                                                                           'UIを折りたたんで省スペースにするだけで、モディファイア自体は変更しません。',
 ('*', 'Show/hide the Object List section.\n\nThis only folds the UI to save space; it does not change selection or objects.'): 'オブジェクトリスト '
                                                                                                                                'セクションの表示/非表示。\n'
                                                                                                                                '\n'
                                                                                                                                'UIを折りたたむだけで、選択状態やオブジェクト自体は変更しません。',
 ('*', 'Show/hide the Settings section.\n\nThis only folds the UI to save space.'): '設定 セクションの表示/非表示。\n'
                                                                                    '\n'
                                                                                    'UIを折りたたんで省スペースにするだけです。',
 ('*', 'Show/hide the State Sets section.\n\nThis only folds the UI to save space; it does not apply any state sets by itself.'): '状態セット '
                                                                                                                                  'セクションの表示/非表示。\n'
                                                                                                                                  '\n'
                                                                                                                                  'UIを折りたたむだけで、状態セットの適用は行いません。',
 ('*', 'Single'): '単一選択',
 ('*', 'Single Select'): '単一選択',
 ('*', 'Slice / Panel Stack'): 'スライス / パネルスタック',
 ('*', 'Slice Axis'): 'スライス軸',
 ('*', 'Slice Count'): 'スライス数',
 ('*', 'Slice Helpers Wire'): 'スライス補助をワイヤ表示',
 ('*', 'Slice Operation'): 'スライス演算',
 ('*', 'Slice Thickness'): 'スライス厚み',
 ('*', 'Slice Tolerance'): 'スライス許容値',
 ('*', 'Smart Extrude Clean'): 'スマート押し出しクリーン',
 ('*', 'Smart Extrude Distance'): 'スマート押し出し距離',
 ('*', 'Smart Extrude Inset'): 'スマート押し出しのインセット量',
 ('*', 'Smart Fill / Quad Repair'): 'スマート面張り / 四角化補助',
 ('*', 'Smart Lattice Resolution'): 'Smart Lattice 解像度',
 ('*', 'Smart Lattice updated: synced selection state for all linked users.'): 'SmartLattice 更新: 全共有ユーザーの選択状態を反映',
 ('*', 'Smart Lattice の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n\n・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n・対象の Smart Lattice（ラティス）を自動で検出して更新します。\n\nヒント：まずラティス側の変形を確定してから実行すると安定します。'): 'スマートラティス '
                                                                                                                                                                               'の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n'
                                                                                                                                                                               '\n'
                                                                                                                                                                               '・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n'
                                                                                                                                                                               '・対象の '
                                                                                                                                                                               'スマートラティス（ラティス）を自動で検出して更新します。\n'
                                                                                                                                                                               '\n'
                                                                                                                                                                               'ヒント：まずラティス側の変形を確定してから実行すると安定します。',
 ('*', 'Smart Lattice 解像度'): 'スマートラティス 解像度',
 ('*', 'Smart Latticeを追加'): 'スマートラティスを追加',
 ('*', 'Smart Lattice（単体）'): 'スマートラティス（単体）',
 ('*', 'Smart Modifier Hub'): 'スマートモディファイアハブ',
 ('*', 'Smart extrude complete'): 'スマート押し出しが完了しました',
 ('*', 'SmartLattice'): 'スマートラティス',
 ('*', 'SmartLattice Standalone'): 'スマートラティス（単体）',
 ('*', 'SmartLattice Update: reflect selection state of all shared users'): 'SmartLattice 更新: 全共有ユーザーの選択状態を反映',
 ('*', 'Solidify Even Thickness'): '厚みを均一化',
 ('*', 'Solidify Offset'): '厚み付けオフセット',
 ('*', 'Solidify Quality Normals'): '高品質法線',
 ('*', 'Solidify Rim'): '側面を閉じる',
 ('*', 'Solidify Thickness'): '厚み付け厚さ',
 ('*', 'Solo Selected'): '選択をソロ表示',
 ('*', 'Solo mode enabled'): 'ソロ表示を有効化しました',
 ('*', 'Solo mode restored'): 'ソロ表示を解除して復元しました',
 ('*', 'Solver'): 'ソルバー',
 ('*', 'Specify U/V/W separately'): 'U/V/W を個別に指定',
 ('*', 'Sphere'): '球',
 ('*', 'Stack Axis'): 'スタック軸',
 ('*', 'Stack Gap'): 'スタック間隔',
 ('*', 'Stack Selected'): '選択をスタック配置',
 ('*', 'Stack selected objects one after another along the chosen world axis using their world-space bounds plus a configurable gap. Useful for shelf dressing, prop lineup, packing previews, and quick contact-free layout stacking.'): '選択オブジェクトを、指定ワールド軸上でワールド空間の境界ボックスと設定ギャップを使って順番に接触配置します。棚配置、小物の整列、梱包プレビュー、素早い非接触スタック配置に便利です。',
 ('*', 'Stacked selected objects along the chosen axis'): '選択オブジェクトを指定軸上でスタック配置しました',
 ('*', 'Standalone'): '単独',
 ('*', 'Standard'): '標準',
 ('*', 'Star'): '星形',
 ('*', 'Star Inner Ratio'): '星形内側比率',
 ('*', 'Start from the active object, then order the remaining selected objects by nearest-neighbor distance so the generated path follows the placed layout more naturally.'): 'アクティブオブジェクトを始点にし、残りの選択オブジェクトを最近接距離で並べて、配置されたレイアウトに沿いやすい自然なパスを生成します。',
 ('*', 'State'): '状態',
 ('*', 'Straighten Selection'): '選択を直線化',
 ('*', 'Straighten complete'): '直線化が完了しました',
 ('*', 'Strength of the Cast deformation. Larger values push the mesh further toward the chosen primitive type.'): 'Cast '
                                                                                                                   '変形の強さです。値を大きくすると、選択したプリミティブ形状へより強く寄せます。',
 ('*', 'Suggested advanced workflows'): 'おすすめ高度ワークフロー',
 ('*', 'Suggested precision workflows'): 'おすすめ精密ワークフロー',
 ('*', 'Suggested workflows'): 'おすすめワークフロー',
 ('*', 'Surface / Kitbash'): 'サーフェス / キットバッシュ',
 ('*', 'Surface / Retopo / Utility'): 'サーフェス / リトポ / 補助',
 ('*', 'Surface Box Detail'): 'サーフェス箱型ディテール',
 ('*', 'Surface Box Height'): 'サーフェス箱の高さ',
 ('*', 'Surface Box Length'): 'サーフェス箱の長さ',
 ('*', 'Surface Box Operation'): 'サーフェス箱の演算',
 ('*', 'Surface Box Width'): 'サーフェス箱の幅',
 ('*', 'Surface Box Wire'): 'サーフェス箱をワイヤ表示',
 ('*', 'Surface Detail / Layout'): 'サーフェスディテール / レイアウト',
 ('*', 'Surface Offset'): '面オフセット',
 ('*', 'Surface Project Offset'): 'サーフェス投影オフセット',
 ('*', 'Swap ON/OFF for the target (applies the selected flags)'): '対象のON/OFFを反転します（選択中のフラグに適用）',
 ('*', 'Sweep Active Profile'): 'アクティブパスへプロファイルをスイープ',
 ('*', 'Sweep Fill Caps'): 'スイープ端面を閉じる',
 ('*', 'Sweep Resolution'): 'スイープ解像度',
 ('*', 'Symmetry Direction'): '対称方向',
 ('*', 'Symmetry Merge Threshold'): '対称結合しきい値',
 ('*', 'Symmetry complete'): '対称化が完了しました',
 ('*', 'Sync EditPoly edit state safely when Smart Modifier switches the active level.'): 'Smart Modifier '
                                                                                                'からのレベル切替（アクティブ段変更）を受け取り、EditPoly '
                                                                                                'の編集状態を安全に同期します。',
 ('*', 'Sync Level Switch'): 'レベル切替同期',
 ('*', 'Tab Category Name'): 'タブカテゴリー名',
 ('*', 'Target Filter'): 'ターゲット検索',
 ('*', 'Target length of each floor board segment.'): '各床板セグメントの目標長さです。',
 ('*', 'Targets'): '対象',
 ('*', 'Thickness of each slice helper box.'): '各スライス補助ボックスの厚みです。',
 ('*', 'Thickness of the generated floor boards.'): '生成する床板の厚みです。',
 ('*', 'Toggle'): '切替',
 ('*', 'Toggle All'): '一括切替',
 ('*', 'Toggle target for this object'): 'このオブジェクトのターゲット表示を切り替えます',
 ('*', 'Toggle the ACTIVE target for the object you click (one object at a time).\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: Use the big ON/OFF buttons to change ALL objects at once.'): 'クリックしたオブジェクトだけ、アクティブターゲットを切り替えます（1オブジェクトずつ）。\n'
                                                                                                                                                                                                                                           '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                           'ヒント：全オブジェクトをまとめて変えるなら上の大きいON/OFFボタンを使ってください。',
 ('*', 'Toggle the selected target for the currently highlighted object.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.'): 'オブジェクトリストで選択中のオブジェクトだけ、ターゲットを切り替えます。\n'
                                                                                                                                                                  '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。',
 ('*', 'Total height of the generated helix path.'): '生成するヘリックスパスの全高です。',
 ('*', 'Triangles'): '三角形',
 ('*', 'True when this object shares its data (an instance) with another object in the list.\nInstances often share the same modifier stack.'): 'このオブジェクトが他のオブジェクトとデータを共有している（インスタンス）場合にTrueになります。\n'
                                                                                                                                                'インスタンスは同じモディファイアスタックを共有することが多いです。',
 ('*', 'Try Bridge Loops'): 'ブリッジループを試す',
 ('*', 'Try EdgeNet Fill'): 'EdgeNet Fill を試す',
 ('*', 'Try Holes Fill'): 'Fill Holes を試す',
 ('*', 'Try to fill open boundaries after cleanup.'): 'クリーンアップ後に開いた境界を可能な範囲で埋めます。',
 ('*', 'Try to join adjacent triangles into quads after cleanup or fill.'): 'クリーンアップや穴埋め後に隣接三角形を四角形へまとめるよう試みます。',
 ('*', 'Try to keep offset more even during shrink/fatten.'): 'Shrink/Fatten 中にオフセットをより均一に保つよう試みます。',
 ('*', 'Turn OFF (disable) the active target for ALL objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: OFF is non-destructive; you can turn it ON again later.'): '指定範囲の全オブジェクトで、アクティブターゲットを無効(OFF)にします。\n'
                                                                                                                                                                                                                                          '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                          'ヒント：OFFは破壊的ではありません。あとでONに戻せます。',
 ('*', 'Turn ON (enable) the active target for ALL objects in the current scope.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: This does not add/remove modifiers — it only changes their ON/OFF and display states.'): '指定範囲の全オブジェクトで、アクティブターゲットを有効(ON)にします。\n'
                                                                                                                                                                                                                                                                      '有効な反映フラグ（ビュー/編集/ケージ/レンダー/展開）のみ変更されます。\n'
                                                                                                                                                                                                                                                                      'ヒント：モディファイアの追加/削除は行わず、ON/OFFと表示フラグだけを変更します。',
 ('*', 'Turn the target OFF (applies the selected flags)'): '対象をOFFにします（選択中のフラグに適用）',
 ('*', 'Turn the target ON (applies the selected flags)'): '対象をONにします（選択中のフラグに適用）',
 ('*', 'Twist Angle (deg)'): 'ツイスト角度（度）',
 ('*', 'Twist Axis'): 'ツイスト軸',
 ('*', 'Twist Lower Limit'): 'ツイスト下限',
 ('*', 'Twist Upper Limit'): 'ツイスト上限',
 ('*', 'Type'): 'タイプ',
 ('*', "Type a name for the new State Set.\nUse a short, clear name such as 'Preview OFF' or 'Render ON' so you can find it later easily.\nAfter typing, click '+' to save it as a new preset, or select an existing set and use Overwrite.\nState Sets only remember visibility/display buttons; they do not store modifier values or order."): '新しい状態セットの名前を入力します。\n'
                                                                                                                                                                                                                                                                                                                                                 'あとで見つけやすいように『Preview '
                                                                                                                                                                                                                                                                                                                                                 'OFF』『Render '
                                                                                                                                                                                                                                                                                                                                                 'ON』のような短く分かりやすい名前がおすすめです。\n'
                                                                                                                                                                                                                                                                                                                                                 '入力後は『+』で新規保存、既存セットを更新したい時は対象を選んで『上書き』を使います。\n'
                                                                                                                                                                                                                                                                                                                                                 '状態セットが保存するのは表示/有効状態だけで、モディファイアの数値や順番は保存しません。',
 ('*', "Type a name for the new State Set. State Sets are presets that remember each modifier's visibility buttons (Viewport / Edit Mode / Real-time / Render) for the objects in the list. After typing, click 'Add State Set' to create it."): '新しい状態セットの名前を入力します。状態セットは、リスト内のオブジェクトの各モディファイアについて、表示ボタン（ビューポート／編集モード／リアルタイム／レンダー）のON/OFF状態を記憶するプリセットです。名前を入力したら「状態セットを追加」を押して作成します。',
 ('*', 'U'): 'U',
 ('*', 'UI label shown in the target list.\nThis is generated automatically.'): 'ターゲットリストに表示されるラベルです。\n自動生成されます。',
 ('*', 'Uniform Scale Max'): '一様スケール最大',
 ('*', 'Uniform Scale Min'): '一様スケール最小',
 ('*', 'Uniformly scale each placed component by the square-root of the target face area.'): '各配置コンポーネントを、対象面の面積の平方根を基準に一様スケールします。',
 ('*', 'Union'): '合成',
 ('*', 'Update Influence'): '影響範囲の更新',
 ('*', 'Update List'): 'リスト更新',
 ('*', 'Updated active curve with pipe settings'): 'アクティブカーブへパイプ設定を適用しました',
 ('*', 'Updated targets.'): 'ターゲットを更新しました。',
 ('*', 'Updated {} modifiers ({}).'): '{} 個のモディファイアを更新しました ({})。',
 ('*', 'Upper normalized limit for the Bend modifier, useful for partial roll and localized deformation.'): 'Bend '
                                                                                                            'モディファイアの正規化上限で、部分的な巻きや局所変形に使います。',
 ('*', 'Upper normalized limit for the Taper modifier, useful for partial narrowing and localized silhouette edits.'): 'Taper '
                                                                                                                       'モディファイアの正規化上限で、部分的な絞りや局所的なシルエット調整に使います。',
 ('*', 'Upper normalized limit for the Twist modifier, useful for partial torsion and localized twisting.'): 'Twist '
                                                                                                             'モディファイアの正規化上限で、部分的なねじりや局所的なツイストに使います。',
 ('*', 'Use 3D Cursor Z'): '3DカーソルZを使う',
 ('*', 'Use Bounds'): 'バウンズを使う',
 ('*', 'Use Cursor Orientation'): 'カーソル向きを使う',
 ('*', 'Use Cursor Origin'): 'カーソル原点を使う',
 ('*', 'Use Cursor Origin for Cast'): 'Cast にカーソル原点を使う',
 ('*', 'Use Cursor Pivot'): 'カーソルピボットを使う',
 ('*', 'Use Fill Holes as a late fallback for open boundary cleanup when other fill methods do not succeed.'): '他の埋め処理が成功しない場合の遅い段階のフォールバックとして '
                                                                                                               'Fill '
                                                                                                               'Holes '
                                                                                                               'を使い、開いた境界のクリーンアップを試みます。',
 ('*', "Use LoopTools when available before falling back to Blender's To Sphere transform."): '利用可能なら LoopTools '
                                                                                              'を優先し、使えない場合のみ Blender '
                                                                                              '標準の To Sphere '
                                                                                              'へフォールバックします。',
 ('*', 'Use LoopTools when available before falling back to built-in Blender smoothing.'): '利用可能なら LoopTools '
                                                                                           'を優先し、使えない場合のみ Blender '
                                                                                           '標準のスムージングへフォールバックします。',
 ('*', 'Use Nearest Chain'): '最近接チェーンを使う',
 ('*', 'Use Nearest Vertex Chain'): '最近接頂点チェーンを使う',
 ('*', 'Use Selection Bounds'): '選択範囲の境界を使う',
 ('*', 'Use face strength / influence information when available for stronger hard-surface shading control.'): '利用可能な場合、面の強度 '
                                                                                                               '/ '
                                                                                                               '影響情報を使ってハードサーフェスの陰影制御を強めます。',
 ('*', 'Use linked mesh data for each placed component instead of making full data copies.'): '各配置コンポーネントで完全コピーではなく、メッシュデータをリンクして使います。',
 ('*', 'Use linked object data instead of full data copies.'): '完全コピーではなく、オブジェクトデータをリンクして複製します。',
 ('*', 'Use only the outer lattice points when the generated lattice supports it.'): '生成したラティスが対応している場合、外側のラティス点のみを使います。',
 ('*', 'Use selected edges/faces/objects as a high-level guide, then drop into the specialized precision panels only when you need deeper parameters.'): '選択したエッジ・面・オブジェクトを高レベルなガイドとして使い、より細かい調整が必要な時だけ専門パネルへ入れるようにしています。',
 ('*', 'Use the 3D cursor Z value as the target floor height instead of the manual Floor Z field.'): '手動の Floor Z '
                                                                                                     'の代わりに、3Dカーソルの Z '
                                                                                                     '値を床高さとして使います。',
 ('*', 'Use the closest surface point for each detail mesh'): '各ディテールメッシュを最近接面へ追従させます。',
 ('*', 'Use the new detail as a boolean difference helper on the source mesh'): '新規ディテールを元メッシュへの差分ブーリアン補助として使います',
 ('*', 'Use the new detail as a boolean union helper on the source mesh'): '新規ディテールを元メッシュへの合成ブーリアン補助として使います',
 ('*', 'Use the object bounds to place the lowest point on the hit surface. When disabled, the object origin is placed on the surface instead.'): 'オブジェクトのバウンディングボックスを使って最下点をヒット面へ置きます。無効時はオブジェクト原点を面上へ置きます。',
 ('*', 'Use the selected profile curve as a bevel object on the active path curve. This is useful for Sweep Mesh, trim profiles, moldings, cable trays, rail sections, and CAD-style spline workflows where a reusable 2D profile is pushed along a path.'): '選択したプロファイル用カーブを、アクティブなパスカーブのベベルオブジェクトとして設定します。Sweep '
                                                                                                                                                                                                                                                             'Mesh、トリム断面、モール、ケーブルトレイ、手すり断面、CAD系スプラインワークフローのように、再利用可能な2Dプロファイルをパスに沿って押し出す用途に便利です。',
 ('*', 'Vertex Copy'): '頂点コピー',
 ('*', 'Vertex Slide'): 'Vertex Slide',
 ('*', 'Vertices'): '頂点数',
 ('*', 'Viewport visibility indicator for this object (ON / OFF / MIXED).\nThis is calculated automatically.'): 'ビューポート表示の状態（ON／OFF／MIXED）です。\n'
                                                                                                                '自動計算されます。',
 ('*', 'Viewport/path resolution applied to the path curve when configuring the sweep.'): 'スイープ設定時にパスカーブへ適用する、ビューポート / '
                                                                                          'パス解像度です。',
 ('*', 'Visible Only'): '表示中のみ',
 ('*', 'W'): 'W',
 ('*', 'Weighted normal applied / updated'): 'Weighted Normal を適用 / 更新しました',
 ('*', "When Scope is set to 'Collection', pick the collection to use.\nOnly objects in this collection will be listed/affected."): '範囲を「コレクション」にした場合、使用するコレクションを選択します。\n'
                                                                                                                                    'このコレクションに含まれるオブジェクトだけが一覧/操作対象になります。',
 ('*', 'When converting selected vertices to a path, start from the active vertex when possible and order the remaining vertices by nearest-neighbor distance.'): '選択頂点をパス化する際、可能ならアクティブ頂点から開始し、残りを最近接距離順に並べます。',
 ('*', 'When enabled, Axis Slice Edit derives the slice range from the current selection when possible. The cuts still pass through the mesh like a numeric slice helper.'): '有効時、Axis '
                                                                                                                                                                             'Slice '
                                                                                                                                                                             'Edit '
                                                                                                                                                                             'は可能なら現在の選択範囲からスライス範囲を求めます。カット自体は数値スライス補助のようにメッシュ全体を通過します。',
 ('*', 'When enabled, Quad Checker only inspects the currently selected faces. Disable it to inspect the whole active edit mesh.'): '有効時は現在選択中の面のみを対象に確認します。無効時はアクティブ編集メッシュ全体を確認します。',
 ('*', 'When the selection resolves to two disconnected edge groups, try Bridge Edge Loops first so strips and caps can be generated in-place.'): '選択が2つの分離したエッジ群に解決される場合、まず '
                                                                                                                                                  'Bridge '
                                                                                                                                                  'Edge '
                                                                                                                                                  'Loops '
                                                                                                                                                  'を試して、帯状面やキャップをその場で生成しやすくします。',
 ('*', 'Whether this target is pinned (kept) even if it is not found in the current selection.\nPinned targets stay in the list so you can reuse them quickly.'): '選択中に見つからなくてもターゲットをリストに残す（ピン留め）かどうかです。\n'
                                                                                                                                                                  'ピン留めすると、後で素早く再利用できます。',
 ('*', 'Width of each generated floor board row.'): '生成する各床板列の幅です。',
 ('*', 'Width of the generated surface detail box.'): '生成するサーフェスディテール箱の幅です。',
 ('*', 'Width used by the auto-created bevel modifier.'): '自動作成されるベベルモディファイアの幅です。',
 ('*', 'Workflow / Existing Tools'): 'ワークフロー / 既存ツール',
 ('*', 'Workplane / Projection'): 'ワークプレーン / 投影',
 ('*', 'Workplane From Active'): 'アクティブからワークプレーン作成',
 ('*', 'Workplane ready'): 'ワークプレーンを作成しました',
 ('*', 'World axis used by Distribute Selected.'): 'Distribute Selected で使用するワールド軸です。',
 ('*', 'World axis used by Stack Selected.'): 'Stack Selected で使用するワールド軸です。',
 ('*', 'World-space floor height used by Drop To Floor when 3D Cursor Z is disabled.'): 'Drop To Floor で 3D カーソル Z '
                                                                                        'を使わない場合に使用するワールド空間の床高さです。',
 ('*', 'Zero-area Faces'): '面積ゼロ面',
 ('*', '• Angled surface editing: Workplane From Active → standard move/scale/extrude with Cursor orientation.'): '• '
                                                                                                                  '傾斜面編集: '
                                                                                                                  'アクティブからワークプレーン作成 '
                                                                                                                  '→ '
                                                                                                                  'Cursor '
                                                                                                                  '向きで通常の移動/拡大縮小/押し出し。',
 ('*', '• Archviz patterns: Floor Generator for quick floorboard blockouts and layout previews.'): '• Archviz パターン: '
                                                                                                   'Floor Generator '
                                                                                                   'で床板のラフ作成やレイアウト確認を素早く実行。',
 ('*', '• CAD cleanup: CAD Intersect / Extend resolves two selected edges like tinyCAD-style intersection helpers.'): '• '
                                                                                                                      'CAD '
                                                                                                                      '整理: '
                                                                                                                      'CAD '
                                                                                                                      '交点 '
                                                                                                                      '/ '
                                                                                                                      '延長で、tinyCAD '
                                                                                                                      '系の交点補助のように2本の選択辺を解決。',
 ('*', '• Cables / trims: Make Pipe / Cable, then Array Along Curve for repeating details.'): '• ケーブル / トリム: Make Pipe '
                                                                                              '/ Cable の後に Array Along '
                                                                                              'Curve で反復ディテール化。',
 ('*', '• Contact stacking: Stack Selected packs props, books, panels, and modular pieces one after another using real bounds plus a custom gap.'): '• '
                                                                                                                                                    '接触スタック配置: '
                                                                                                                                                    '選択をスタック配置 '
                                                                                                                                                    'で、実際の境界ボックスと任意ギャップを使って小物、本、パネル、モジュラー部品を順番に並べます。',
 ('*', '• Curve cleanup: Rebuild Active Curve resamples uneven paths before pipes, sweeps, and arrays.'): '• カーブ整理: '
                                                                                                          'アクティブカーブを再構築で、不均一なパスをパイプ '
                                                                                                          '/ スイープ / '
                                                                                                          '配列前に再サンプリング。',
 ('*', '• Curve extraction: Selected Edges To Curve builds clean splines from edge selections without duplicate/separate steps.'): '• '
                                                                                                                                   'カーブ抽出: '
                                                                                                                                   '選択エッジをカーブ化で、複製/分離なしにエッジ選択からクリーンなスプラインを作成します。',
 ('*', '• Curve prep: Add Profile Primitive and Add Helix Path provide reusable sweep sections and spring/spiral guide curves directly from the hub.'): '• '
                                                                                                                                                        'カーブ準備: '
                                                                                                                                                        '断面プリミティブを追加 '
                                                                                                                                                        'と '
                                                                                                                                                        'ヘリックスパスを追加 '
                                                                                                                                                        'で、再利用可能な断面とバネ '
                                                                                                                                                        '/ '
                                                                                                                                                        '螺旋ガイドカーブをハブから直接作成。',
 ('*', '• Deform stack: Quick Bend / Twist / Taper provide reusable non-destructive shaping helpers.'): '• 変形スタック: '
                                                                                                        'クイック Bend / '
                                                                                                        'Twist / Taper '
                                                                                                        'で、再利用しやすい非破壊シェイプ補助を作成。',
 ('*', '• Deform: Quick Bend Deformer sets up fast bend/roll style shaping around the cursor or object space.'): '• '
                                                                                                                 '変形: '
                                                                                                                 'クイックベンドデフォーマで、カーソル基準またはオブジェクト空間での素早い '
                                                                                                                 'Bend '
                                                                                                                 '/ '
                                                                                                                 'Roll '
                                                                                                                 '変形を設定。',
 ('*', '• Environment dressing: Scatter Instances (Bake) for rocks, foliage, debris, and kitbash details.'): '• 環境装飾: '
                                                                                                             'Scatter '
                                                                                                             'Instances '
                                                                                                             '(Bake) '
                                                                                                             'で岩、植生、デブリ、キットバッシュを配置。',
 ('*', '• FFD style setup: Quick Lattice Cage creates a reusable cage around the active object for broad-form edits.'): '• '
                                                                                                                        'FFD '
                                                                                                                        '風セットアップ: '
                                                                                                                        'クイックラティスケージで、アクティブオブジェクトの周囲に大まかな形状編集用ケージを作成。',
 ('*', '• Face arrays: Face Component Array duplicates an active detail mesh across target faces for panels, tiles, and vents.'): '• '
                                                                                                                                  '面配置: '
                                                                                                                                  '面コンポーネント配列で、アクティブなディテールメッシュを対象面へ複製し、パネル・タイル・ベントを高速配置。',
 ('*', '• Face modeling: Smart Extrude Clean for QMesh / Smart Extrude style blockouts.'): '• 面モデリング: Smart Extrude '
                                                                                           'Clean で QMesh / Smart '
                                                                                           'Extrude 風のブロックアウト。',
 ('*', '• Focus mode: Solo Selected isolates the current working set and restores visibility on the next run.'): '• '
                                                                                                                 '集中表示: '
                                                                                                                 '選択をソロ表示で、現在の作業対象だけを残し、次回実行で可視状態を復元。',
 ('*', '• Hard-surface blockout: Boolean Stack → Crease / Weighted Normal → Direct Delete for cleanup.'): '• '
                                                                                                          'ハードサーフェスのブロックアウト: '
                                                                                                          'Boolean '
                                                                                                          'Stack → '
                                                                                                          'Crease / '
                                                                                                          'Weighted '
                                                                                                          'Normal → '
                                                                                                          'Direct '
                                                                                                          'Delete で整理。',
 ('*', '• Helix paths: Add Helix Path creates spring and spiral guide curves for cable, sweep, and motion-path style setups.'): '• '
                                                                                                                                'ヘリックスパス: '
                                                                                                                                'ヘリックスパスを追加で、ケーブル、スイープ、モーションパス風セットアップ向けのバネ '
                                                                                                                                '/ '
                                                                                                                                '螺旋ガイドカーブを作成。',
 ('*', '• Kitbash swaps: Replace With Active to swap many placeholders at once without losing transforms.'): '• '
                                                                                                             'キットバッシュ差し替え: '
                                                                                                             'アクティブで置換で、多数のプレースホルダーを変換を維持したまま一括差し替え。',
 ('*', '• Layout cleanup: Align To Active and Distribute Selected cover quick archviz-style lineup and spacing fixes without leaving Object Mode.'): '• '
                                                                                                                                                     'レイアウト整理: '
                                                                                                                                                     'アクティブへ整列 '
                                                                                                                                                     'と '
                                                                                                                                                     '選択を均等配置 '
                                                                                                                                                     'で、オブジェクトモードのまま '
                                                                                                                                                     'Archviz '
                                                                                                                                                     '風の整列と間隔調整を素早く行えます。',
 ('*', '• Layout: Drop To Surface and Combine / Join Clean for fast environment assembly.'): '• レイアウト: Drop To Surface '
                                                                                             'と Combine / Join Clean '
                                                                                             'で環境アセンブリを高速化。',
 ('*', '• Lofting: Loft / Bridge Paths creates quick strip and patch surfaces between two curves or two selected edge paths.'): '• '
                                                                                                                                'ロフト: '
                                                                                                                                'ロフト '
                                                                                                                                '/ '
                                                                                                                                'パスブリッジで、2本のカーブまたは2本の選択エッジパス間に素早く帯状・パッチ面を作成します。',
 ('*', '• Mesh QA: Audit Selected reports manifold, loose, ngon, degenerate, and duplicate risks before export or print.'): '• '
                                                                                                                            'メッシュ '
                                                                                                                            'QA: '
                                                                                                                            '選択を監査で、書き出しやプリント前に多様体・ルーズ・Nゴン・退化・重複リスクを確認。',
 ('*', '• Numeric slicing: Axis Slice Edit adds evenly spaced local cuts for panel segmentation, contour layers, and SliceIt XYZ style blocking.'): '• '
                                                                                                                                                    '数値スライス: '
                                                                                                                                                    '軸スライス編集で、パネル分割、等高線レイヤー、SliceIt '
                                                                                                                                                    'XYZ '
                                                                                                                                                    '風のブロックアウト向けに等間隔のローカルカットを追加します。',
 ('*', '• Object paths: Selected Objects To Path turns placed objects or empties into reusable guide curves for sweeps, arrays, layout, and trajectory-style workflows.'): '• '
                                                                                                                                                                           'オブジェクトパス: '
                                                                                                                                                                           '選択オブジェクトをパス化で、配置済みオブジェクトや '
                                                                                                                                                                           'Empty '
                                                                                                                                                                           'を、スイープ、配列、レイアウト、Trajectory '
                                                                                                                                                                           '系ワークフローに使える再利用可能なガイドカーブへ変換します。',
 ('*', '• Panel cleanup: Project To Active Plane to keep selected loops flush to a reference surface.'): '• パネル整理: '
                                                                                                         'アクティブ面へ投影で、選択ループを基準面へぴったり揃える。',
 ('*', '• Panel lines: Slice / Panel Stack for fast layered grooves and contour cuts.'): '• パネルライン: スライス / '
                                                                                         'パネルスタックで多段の溝や輪郭カットを高速作成。',
 ('*', '• Path layouts: Instances Along Path for railing, trims, repeated props, and blockout arrays.'): '• パス配置: '
                                                                                                         'パスに沿ってインスタンス配置で、手すり、トリム、反復小物、ブロックアウト配列を作成。',
 ('*', '• Pivot edits: Pivot To Selection or Pivot To Bottom help prepare bend / twist / drop workflows without destructive repositioning.'): '• '
                                                                                                                                              'ピボット調整: '
                                                                                                                                              '選択へピボット移動 '
                                                                                                                                              '/ '
                                                                                                                                              '下端へピボット移動で、Bend '
                                                                                                                                              '/ '
                                                                                                                                              'Twist '
                                                                                                                                              '/ '
                                                                                                                                              'ドロップ系の前準備を破壊的再配置なしで行えます。',
 ('*', '• Primitive fitting: Cast Modifier helps recover cylinders, spheres, and rounded blockouts inside the stack.'): '• '
                                                                                                                        'プリミティブ補正: '
                                                                                                                        'Cast '
                                                                                                                        'Modifier '
                                                                                                                        'は、円柱、球、丸みを持つブロックアウト形状をスタック内で補正するのに役立ちます。',
 ('*', '• Profile primitives: Add Profile Primitive creates reusable 2D curve sections for sweeps, trims, rails, and cable profiles.'): '• '
                                                                                                                                        '断面プリミティブ: '
                                                                                                                                        '断面プリミティブを追加で、スイープ、トリム、レール、ケーブル断面に使える再利用可能な2Dカーブを作成。',
 ('*', '• Profile sweeps: Sweep Active Profile turns an active path plus one selected profile curve into a reusable molding / trim / rail workflow.'): '• '
                                                                                                                                                       'プロファイルスイープ: '
                                                                                                                                                       'アクティブパスへプロファイルをスイープで、アクティブなパスと選択した1本の断面カーブから、モール '
                                                                                                                                                       '/ '
                                                                                                                                                       'トリム '
                                                                                                                                                       '/ '
                                                                                                                                                       'レールの再利用可能なワークフローを構築します。',
 ('*', '• Retopo / wrap: Project To Selected Surface keeps selected verts glued to a target mesh.'): '• リトポ / ラップ: '
                                                                                                     '選択面へサーフェス投影で、選択頂点を対象メッシュへ貼り付け維持。',
 ('*', '• Safe repair: Audit + Repair runs conservative cleanup, then refreshes the audit report.'): '• 安全修復: 監査 + '
                                                                                                     '修復で保守的なクリーンアップを行い、監査レポートを更新。',
 ('*', '• Scene dressing: Randomize Selected for fast natural variation after scatter or manual placement.'): '• '
                                                                                                              'シーンドレッシング: '
                                                                                                              '散布後や手配置後に選択をランダム化で自然なバリエーションを追加。',
 ('*', '• Surface detailing: Conform / Stitch To Surface for kitbash parts and layered details.'): '• 面上ディテール: Conform '
                                                                                                   '/ Stitch To '
                                                                                                   'Surface '
                                                                                                   'でキットバッシュ部品や重ねディテールを面へ追従配置。',
 ('*', '• Surface kitbash: Surface Box Detail → Conform / Stitch To Surface → Boolean Stack.'): '• サーフェスキットバッシュ: '
                                                                                                'サーフェス箱型ディテール → 面へ追従 / '
                                                                                                'ステッチ → Boolean Stack。',
 ('*', '• Symmetry: Quick Symmetry runs destructive cleanup in Edit Mode or a non-destructive Mirror setup in Object Mode.'): '• '
                                                                                                                              '対称化: '
                                                                                                                              'クイック対称化で、編集モードでは破壊的整理、オブジェクトモードでは非破壊 '
                                                                                                                              'Mirror '
                                                                                                                              'を実行。',
 ('*', '• Thickness: Quick Solidify Plus adds or updates a safe non-destructive shell for panels, walls, and trims.'): '• '
                                                                                                                       '厚み: '
                                                                                                                       'クイック厚み付けプラスで、パネル、壁、トリム向けの安全な非破壊シェルを追加 '
                                                                                                                       '/ '
                                                                                                                       '更新。',
 ('*', '• Visual QA: Select Issues highlights non-manifold, loose, ngon, triangle, degenerate, zero-area, or double-candidate elements for direct cleanup.'): '• '
                                                                                                                                                              '可視QA: '
                                                                                                                                                              '問題要素を選択で、非多様体、ルーズ、Nゴン、三角形、退化、面積ゼロ、重複候補を直接クリーンアップしやすいようにハイライトします。',
 ('*', '選択したオブジェクトに 編集ポリゴンレイヤーを追加します。\n\n・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n\n使い方：追加後はレイヤーをアクティブにして Edit モードで編集してください。\n必要なら『全レイヤー再計算』で整合を取り直せます。'): '選択したオブジェクトに '
                                                                                                                                                                                                                 'ポリ編集 '
                                                                                                                                                                                                                 'レイヤーを追加します。\n'
                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                 '・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n'
                                                                                                                                                                                                                 '・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n'
                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                 '使い方：追加後はレイヤーをアクティブにして「編集モード」で編集してください。\n'
                                                                                                                                                                                                                 '必要なら『全レイヤー再計算』で整合を取り直せます。',
 ('*', '選択中のメッシュに Smart Lattice（ラティス変形を扱いやすくする補助システム）を追加します。\n\n・自動で Lattice と必要な補助オブジェクト/コレクションを作成します。\n・メッシュの大きさに合わせてラティスを配置します。\n・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n\nヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。'): '選択中のメッシュに '
                                                                                                                                                                                                                       'スマートラティス（ラティス変形を扱いやすくする補助システム）を追加します。\n'
                                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                                       '・自動で '
                                                                                                                                                                                                                       'Lattice '
                                                                                                                                                                                                                       'と必要な補助オブジェクト/コレクションを作成します。\n'
                                                                                                                                                                                                                       '・メッシュの大きさに合わせてラティスを配置します。\n'
                                                                                                                                                                                                                       '・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n'
                                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                                       'ヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。'}
)


# Additional localization coverage for runtime metadata, reports, and dynamic helper text.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'View3D > Sidebar > Smart Modifier'): '3Dビュー > サイドバー > Smart Modifier',
    ('*', 'Smart Modifier is shown as a standard 3D View Sidebar N-panel category named Smart Modifier.'): 'Smart Modifier を、通常の3DビューサイドバーNパネルカテゴリ Smart Modifier に表示します。',
    ('*', 'Smart Modifier runtime load failed: {}'): 'Smart Modifier ランタイムの読み込みに失敗しました: {}',
    ('*', 'Smart Modifier runtime registration failed: {}'): 'Smart Modifier ランタイムの登録に失敗しました: {}',
    ('*', 'Smart Tools N-panel could not be opened: {}'): 'Smart Tools Nパネルを開けませんでした: {}',
    ('*', 'Could not enter Edit Mode: {}'): '編集モードへ入れませんでした: {}',
    ('*', 'Bisect failed: {}'): '二分割に失敗しました: {}',
    ('*', 'Mirror setup was partial: {}'): 'ミラー設定は一部のみ完了しました: {}',
    ('*', 'Open the Add Modifier popup at the button position as a front popup.\n- The root popup opens directly from the clicked Add Modifier button so it does not jump to another window.\n- Category entries stay in the popup, and the next modifier-name popup still expands sideways for readability.\n- In Smart Tools, the popup keeps using the compact-window safety path so it remains stable.'): 'クリックしたボタン位置で、モディファイア追加ポップアップを前面表示します。\n・ルートポップアップは、クリックした「モディファイアを追加」ボタンから直接開くため、別ウィンドウへ飛びません。\n・カテゴリ項目はポップアップ内に残り、次のモディファイア名ポップアップは読みやすいよう横方向へ展開します。\n・Smart Tools 内では、安定性のためコンパクトウィンドウ用の安全経路を使います。',
    ('*', 'Add Modifier menu is unavailable.'): 'モディファイア追加メニューを開けません。',
    ('*', 'Context'): '前提',
    ('*', 'Use'): '使い方',
    ('*', 'Current blockers'): '現在の不足条件',
    ('*', 'Operator not found: {}'): 'オペレーターが見つかりません: {}',
    ('*', ' | Hint: {}'): ' | ヒント: {}',
    ('*', 'Current context cannot run: {}'): '現在のコンテキストでは実行できません: {}',
    ('*', ' | Blockers: {}'): ' | 不足条件: {}',
    ('*', 'Operator did not complete successfully: {}'): 'オペレーターが正常完了しませんでした: {}',
    ('*', 'Smart Modifier User Menu / View3D > N-panel (Optional)'): 'Smart Modifier ユーザーメニュー / 3Dビュー > Nパネル（任意）',
    ('*', 'FFD lattice tool integrated with Smart Modifier'): 'Smart Modifier に統合された FFD ラティスツールです。',
    ('*', 'Max-style Edit Poly Layer functionality (integrates with Smart Modifier).'): 'Smart Modifier と統合する Max 風の 編集ポリゴンレイヤー機能です。',
    ('*', 'Exact'): '正確',
    ('*', 'Fast'): '高速',
    ('*', 'Weighted Normal'): '重み付き法線',
    ('*', 'Beautify Fill'): 'フィルを整形',
    ('*', 'Crease Preset'): 'クリースプリセット',
    ('*', 'Mesh Align'): 'メッシュ整列',
    ('*', 'Direct Delete'): '直接削除',
    ('*', 'Vertex Slide'): '頂点スライド',
    ('*', 'Bridge Edge Loops'): 'ブリッジエッジループ',
    ('*', 'Grid Fill'): 'グリッドフィル',
    ('*', 'EdgeNet Fill'): 'エッジネットフィル',
    ('*', 'Edge / Face Add'): '辺 / 面を追加',
    ('*', 'Cast Modifier'): 'キャストモディファイア',
    ('*', 'Cast X'): 'X方向キャスト',
    ('*', 'Cast Y'): 'Y方向キャスト',
    ('*', 'Cast Z'): 'Z方向キャスト',
    ('*', 'Base Object'): 'ベースオブジェクト',
})

# Supplemental crash-safe panel messages are registered in translation_catalog_2.py if this generated table layout changes.

translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Smart Modifier UI could not be drawn safely.'): 'Smart Modifier UI を安全に描画できませんでした。',
    ('*', 'Close and reopen the N-panel, or reload the add-on if this message persists.'): 'この表示が続く場合は、Nパネルを閉じて開き直すか、アドオンを再読み込みしてください。',
})

# Supplemental coverage for centralized always-on toggles and full bundled tool catalog panels.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Enable or disable always-running handlers, timers, auto-update loops, live overlays, and background synchronization from one central place.'): '常時動作するハンドラー、タイマー、自動更新ループ、ライブ表示、バックグラウンド同期を一か所で有効化・無効化します。',
    ('*', 'Modifier Stack Live Sync'): 'モディファイアスタック ライブ同期',
    ('*', 'Edit Polygon Live Sync'): '編集ポリゴンライブ同期',
    ('*', 'Smart Lattice Live Sync'): 'Smart Lattice ライブ同期',
    ('*', 'Modifier Switcher Auto Update'): 'モディファイア切り替え 自動更新',
    ('*', 'Captured Runtime Features'): '検出された常時起動機能',
    ('*', 'Runtime Feature'): '常時起動機能',
    ('*', 'No always-on features are currently registered.'): '現在登録されている常時起動機能はありません。',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Bundled Tool Catalog'): '同梱ツール一覧',
    ('*', 'All registered user tools are shown here by group. Use this panel to access bundled tool code that is not visible as a standalone panel.'): '登録済みユーザーツールをグループ別に表示します。単独パネルとして表示されない同梱ツールコードにも、このパネルからアクセスできます。',
    ('*', 'No bundled tools are currently available.'): '現在利用できる同梱ツールはありません。',
    ('*', 'Central N-panel settings for Smart Modifier.'): 'Smart Modifier のNパネル設定をまとめた中央設定パネルです。',
    ('*', 'Advanced Modeling Tools'): '高度なモデリングツール',
})

# Supplemental localization for startup-safe lazy runtime controls and persistent N-panel state.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Toggle Feature'): '機能を切り替え',
    ('*', 'Switch an always-on feature on or off. N-panel State Save controls whether the change is saved immediately or deferred.'): '常時起動機能の有効 / 無効を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
    ('*', 'Toggle an always-on Smart Modifier feature. The save timing follows N-panel State Save.'): 'Smart Modifier の常時起動機能を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
    ('*', 'Feature setting saved.'): '機能設定を保存しました。',
    ('*', 'The selected feature could not be changed.'): '選択した機能を変更できませんでした。',
    ('*', 'Enable the live callbacks used by the main modifier stack. Leave this OFF for lighter startup and idle performance. When OFF, the related handlers and timers are fully disabled. The setting is saved immediately and restored after Blender restarts or a different scene is opened.'): 'メインのモディファイアスタックで使うライブコールバックを有効にします。起動時と待機時を軽くするにはOFFのままにしてください。OFFのとき、関連ハンドラーとタイマーは完全に無効化されます。設定は即時保存され、Blender再起動後や別シーンを開いた後も復元されます。',
    ('*', 'Enable Edit Poly live selection and stack callbacks only while you need them. When OFF, Edit Polygon remains dormant and its live handler is fully disabled. The setting is saved immediately and restored after Blender restarts or a different scene is opened.'): '必要な時だけ編集ポリゴンのライブ選択・スタックコールバックを有効にします。OFFのとき、編集ポリゴンは休止状態になりライブハンドラーは完全に無効化されます。設定は即時保存され、Blender再起動後や別シーンを開いた後も復元されます。',
    ('*', 'Enable Smart Lattice overlay and dependency-graph callbacks only while you need them. When OFF, the overlay/live handlers are fully disabled. The setting is saved immediately and restored after Blender restarts or a different scene is opened.'): '必要な時だけSmart Latticeのオーバーレイと依存グラフコールバックを有効にします。OFFのとき、オーバーレイ / ライブハンドラーは完全に無効化されます。設定は即時保存され、Blender再起動後や別シーンを開いた後も復元されます。',
    ('*', 'Open or close the Always-on Toggles group at the top of the Smart Modifier N-panel. The default is closed to keep normal sidebar drawing light. This UI state is saved immediately and restored after Blender restarts or a different scene is opened.'): 'Smart Modifier Nパネル最上部の常時機能切り替えグループを開閉します。通常のサイドバー描画を軽く保つため、初期状態は閉じています。このUI状態は即時保存され、Blender再起動後や別シーンを開いた後も復元されます。',
})
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'No tools are currently available in this group'): 'このグループで現在利用できるツールはありません。',
    ('*', 'No user tools are currently available'): '現在利用できるユーザーツールはありません。',
    ('*', 'Edit Polygon Maintenance'): '編集ポリゴンメンテナンス',
})

# Supplemental localization for restored Settings panel bundled-tool toggles.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Bundled Subtools'): 'サブツール（同梱）',
    ('*', 'Enable Modifier Switcher'): 'モディファイア管理を使用',
    ('*', 'Enable Edit Polygon Modifier (Bundled)'): 'Edit Polygon Modifier（同梱サブツール）',
    ('*', 'Enable Smart Lattice Modifier (Bundled)'): 'Smart Lattice Modifier（同梱サブツール）',
})

# Supplemental localization for lazy-loaded help popup buttons and operator metadata.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open the detailed help popup for this Smart Modifier tool group. The long help content is loaded only when this button is clicked.'): 'この Smart Modifier ツールグループの詳細ヘルプポップアップを開きます。長いヘルプ内容は、このボタンをクリックした時だけ読み込まれます。',
    ('*', 'Help Topic'): 'ヘルプ項目',
    ('*', 'Internal identifier for the Smart Modifier help topic to open.'): '開く Smart Modifier ヘルプ項目の内部識別子です。',
    ('*', 'Help content could not be loaded.'): 'ヘルプ内容を読み込めませんでした。',
})

# Supplemental localization for the integrated 3ds Max modifier library.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', '3ds Max Modifier Library'): '3ds Max モディファイアライブラリ',
    ('*', '3ds Max equivalent'): '3ds Max 相当',
    ('*', 'Affect Region Modifier'): '影響領域',
    ('*', 'Animation / Cache'): 'アニメーション / キャッシュ',
    ('*', 'Bend Modifier'): 'ベンド',
    ('*', 'Category'): 'カテゴリ',
    ('*', 'Compatibility wrapper: keeps the stack step editable when Blender has no direct native modifier.'): '互換ラッパー: Blender 標準に直接対応がない処理を、編集可能なスタック段階として保持します。',
    ('*', 'Conform Modifier'): 'コンフォーム',
    ('*', 'Conversion'): '変換',
    ('*', 'Curves / Surface'): 'カーブ / サーフェス',
    ('*', 'Deform'): '変形',
    ('*', 'Edit / Select'): '編集 / 選択',
    ('*', 'Edit Mesh Modifier'): '編集ポリゴン',
    ('*', 'Edit Polygon'): '編集ポリゴン',
    ('*', 'Add Edit Polygon'): '編集ポリゴンを追加',
    ('*', 'Edit Polygon Modifier'): '編集ポリゴン',
    ('*', 'Edit Polygon Modifier'): '編集ポリゴン',
    ('*', 'Face Extrude Modifier'): 'フェース押し出し',
    ('*', 'Generate'): '生成',
    ('*', 'Geometry Nodes Transform wrapper. Expand the modifier sockets to edit translation, rotation, and scale.'): 'Geometry Nodes Transform ラッパーです。モディファイアのソケットを展開して移動・回転・スケールを編集します。',
    ('*', 'Legacy / Compatibility'): '旧形式 / 互換',
    ('*', 'Linked XForm Modifier'): 'リンク Xフォーム',
    ('*', 'Materials'): 'マテリアル',
    ('*', 'Melt Modifier'): 'メルト',
    ('*', 'Mirror Modifier'): 'ミラー',
    ('*', 'Node Group'): 'ノードグループ',
    ('*', 'Noise Modifier'): 'ノイズ',
    # Ordinal51 alias removed: prior WEIGHTED_NORMAL mapping changed shading normals, not face orientation.
    ('*', 'Normalize Spline Modifier'): 'スプライン正規化',
    ('*', 'Normals'): '法線',
    ('*', 'Precision / Symmetry'): '精密 / シンメトリ',
    ('*', 'Preserve Modifier'): '保持',
    ('*', 'Projection Modifier'): 'プロジェクション',
    ('*', 'Push Modifier'): 'プッシュ',
    ('*', 'Push 2026.1 Controls'): 'Push 2026.1 制御',
    ('*', 'Face Extrude Controls'): 'フェース押し出し制御',
    ('*', 'Extrude From Center'): '中心から押し出し',
    ('*', 'Capture Selected Faces'): '選択面を取得',
    ('*', 'Capture Face Extrude Selection'): 'フェース押し出し選択を取得',
    ('*', 'Clear Face Extrude Selection'): 'フェース押し出し選択を解除',
    ('*', 'Captures the exact current face selection for this Face Extrude stack row.'): 'このフェース押し出しスタック行に現在の面選択を正確に取得します。',
    ('*', 'Clears only the face selection owned by this Face Extrude stack row.'): 'このフェース押し出しスタック行が所有する面選択だけを解除します。',
    ('*', 'Face Extrude row was not found.'): 'フェース押し出し行が見つかりません。',
    ('*', 'Face selection cleared.'): '面選択を解除しました。',
    ('*', 'Axis Multiplier'): '軸倍率',
    ('*', 'Collision Objects'): '衝突オブジェクト',
    ('*', 'Falloff'): 'フォールオフ',
    ('*', 'Normal Relax Iterations'): '法線リラックス反復',
    ('*', 'Scale Normals'): '法線をスケール',
    ('*', 'Select Collided Vertices'): '衝突頂点を選択',
    ('*', 'Steps'): 'ステップ',
    ('*', 'Vertex Relax Iterations'): '頂点リラックス反復',
    ('*', 'Reset XForm'): 'Xフォームをリセット',
    ('*', 'Rigging'): 'リギング',
    ('*', 'Simulation'): 'シミュレーション',
    ('*', 'Skew Modifier'): 'スキュー',
    ('*', 'Squeeze Modifier'): 'スクイーズ',
    ('*', 'Subdivision'): 'サブディビジョン',
    ('*', 'Sweep Modifier'): 'スイープ',
    ('*', 'Symmetry Modifier'): 'シンメトリ',
    ('*', 'Topology'): 'トポロジー',
    ('*', 'Topology / Repair'): 'トポロジー / 修復',
    ('*', 'Transfer / Projection'): '転送 / プロジェクション',
    ('*', 'Transform'): '変換',
    ('*', 'UV / Mapping'): 'UV / マッピング',
    ('*', 'UVW Map Modifier'): 'UVWマップ',
    ('*', 'Unwrap UVW Modifier'): 'UVアンラップ',
    ('*', 'Utility'): 'ユーティリティ',
    ('*', 'World Space'): 'ワールドスペース',
    ('*', 'XForm Modifier'): 'Xフォーム',
})

translation_catalog_dict.setdefault('ja_JP', {}).update({
})

# 3ds Max modifier library supplemental translations (complete set)
try:
    _smsm_max_modifier_library_extra_translations.update({
        'Surface': 'サーフェス',
        'Space Warp Binding': 'スペースワープ バインディング',
        'FFD Binding Modifier': 'FFD バインディング',
        'Space Conform Modifier': 'スペースコンフォーム',
    })
except NameError:
    _smsm_max_modifier_library_extra_translations = {
        'Surface': 'サーフェス',
        'Space Warp Binding': 'スペースワープ バインディング',
        'FFD Binding Modifier': 'FFD バインディング',
        'Space Conform Modifier': 'スペースコンフォーム',
    }
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update(
        {('*', _k): _v for _k, _v in _smsm_max_modifier_library_extra_translations.items()})
except Exception:
    pass

# 3ds Max modifier library supplemental translations (tuple-key catalog)
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Surface'): 'サーフェス',
    ('*', 'Space Warp Binding'): 'スペースワープ バインディング',
    ('*', 'FFD Binding Modifier'): 'FFD バインディング',
    ('*', 'Space Conform Modifier'): 'スペースコンフォーム',
})

# 3ds Max modern modifier supplemental translations
translation_catalog_dict.setdefault('ja_JP', {}).update({
})
# --- Lazy help refinement translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Modifier Stack Availability'): 'モディファイアスタック利用可否',
        ('*', 'Bundled Subtools'): '同梱サブツール',
        ('*', 'Modifier Stack Display'): 'モディファイアスタック表示',
        ('*', 'Add Modifier Controls'): 'モディファイア追加操作',
        ('*', 'Modifier Stack Properties'): 'モディファイアスタックプロパティ',
        ('*', 'Edit Polygon Maintenance'): '編集ポリゴンメンテナンス',
        ('*', 'Feature Overview'): '機能概要',
        ('*', 'Usage'): '使用方法',
        ('*', 'Settings'): '設定項目',
        ('*', 'Base Object Top'): 'ベースオブジェクトを上',
        ('*', 'Base Object Bottom'): 'ベースオブジェクトを下',
        ('*', 'Attributes'): '属性',
        ('*', 'Color Attributes'): 'カラー属性',
        ('*', 'Data Properties'): 'データプロパティ',
        ('*', 'Force Field'): 'フォースフィールド',
        ('*', 'Material Slots'): 'マテリアルスロット',
        ('*', 'No editable object-data properties are exposed for this asset type.'): 'このアセットタイプには編集可能なオブジェクトデータプロパティがありません。',
        ('*', 'Object Data'): 'オブジェクトデータ',
        ('*', 'Select an object.'): 'オブジェクトを選択してください。',
        ('*', 'Not available in this mode.'): 'このモードでは使えません。',
        ('*', 'Shape Key Data'): 'シェイプキーデータ',
        ('*', 'Property Items Display'): 'プロパティ項目の表示',
        ('*', 'Show End Result'): '最終結果を表示',
        ('*', 'Multi-object instance add'): '複数オブジェクトのインスタンス追加',
        ('*', 'Re-bake All'): '全て再ベイク',
        ('*', 'Switch Level Hijack'): 'レベル切り替えハイジャック',
        ('*', 'Max Parameters'): 'Maxパラメータ',
        ('*', 'Make Unique'): '一意化',
    })
except Exception:
    pass
# --- Lazy help refinement translations END ---
# --- Lazy help UI label translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Always-on Toggles'): '常時機能切り替え',
        ('*', 'Modifier Stack'): 'モディファイアスタック',
        ('*', 'Modifier Switcher'): 'モディファイア切り替え',
        ('*', 'Bundled Tool Catalog'): '同梱ツール一覧',
        ('*', 'Smart Modifier Hub'): 'スマートモディファイアハブ',
        ('*', 'Precision / Layout'): '精密 / レイアウト',
        ('*', 'Precision / Layout / Path'): '精密 / レイアウト / パス',
        ('*', 'Advanced / Surface Modeling'): '高度 / サーフェスモデリング',
        ('*', 'Hard Surface / Boolean'): 'ハードサーフェス / ブーリアン',
        ('*', 'Topology / Repair'): 'トポロジー / 修復',
        ('*', 'Curves / Repetition'): 'カーブ / 反復',
        ('*', 'Conform / Stitch To Surface'): 'サーフェス追従 / 縫い合わせ',
        ('*', 'Scatter / Environment'): '散布 / 環境',
        ('*', 'Floor Generator'): '床生成',
        ('*', 'Workplane / Projection'): '作業平面 / 投影',
        ('*', 'Surface / Retopo / Utility'): 'サーフェス / リトポ / ユーティリティ',
        ('*', 'Curves / Loft / Prep'): 'カーブ / ロフト / 準備',
        ('*', 'CAD / Tessellate / Audit'): 'CAD / 分割 / 監査',
        ('*', 'Path / Replace / Randomize'): 'パス / 置換 / ランダム化',
        ('*', 'Surface Detail / Layout'): 'サーフェスディテール / レイアウト',
        ('*', 'Smart Extrude Clean'): 'スマート押し出し整理',
        ('*', 'Slice / Panel Stack'): 'スライス / パネルスタック',
        ('*', 'Combine / Join Clean'): '結合 / ジョイン整理',
        ('*', 'Deform / Thickness'): '変形 / 厚み',
        ('*', 'Drop To Surface'): 'サーフェスへ落とす',
        ('*', 'Modifier Stack Availability'): 'モディファイアスタック利用可否',
        ('*', 'Bundled Subtools'): '同梱サブツール',
        ('*', 'Modifier Stack Display'): 'モディファイアスタック表示',
        ('*', 'Add Modifier Controls'): 'モディファイア追加操作',
        ('*', 'Modifier Stack Properties'): 'モディファイアスタックプロパティ',
        ('*', 'Edit Polygon Maintenance'): '編集ポリゴンメンテナンス',
        ('*', 'Feature Overview'): '機能概要',
        ('*', 'Usage'): '使用方法',
        ('*', 'Settings'): '設定項目',
        ('*', '1. Feature Overview'): '1. 機能概要',
        ('*', '2. Usage'): '2. 使用方法',
        ('*', '3. Settings'): '3. 設定項目',
        ('*', 'Base Object Top'): 'ベースオブジェクトを上',
        ('*', 'Base Object Bottom'): 'ベースオブジェクトを下',
        ('*', 'Property Items Display'): 'プロパティ項目の表示',
        ('*', 'Show End Result'): '最終結果を表示',
        ('*', 'Multi-object instance add'): '複数オブジェクトのインスタンス追加',
        ('*', 'Re-bake All'): '全て再ベイク',
        ('*', 'Switch Level Hijack'): 'レベル切り替えハイジャック',
        ('*', 'Max Parameters'): 'Maxパラメータ',
        ('*', 'Make Unique'): '一意化',
        ('*', 'Object List'): 'オブジェクト一覧',
        ('*', 'Modifier List'): 'モディファイア一覧',
        ('*', 'State Sets'): '状態セット',
        ('*', 'Details'): '詳細',
        ('*', 'Refresh Interval'): '更新間隔',
        ('*', 'Update'): '更新',
        ('*', 'Collection'): 'コレクション',
    })
except Exception:
    pass
# --- Lazy help UI label translations END ---
# --- Stack modifier help translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Reset XForm'): 'Xフォームをリセット',
        ('*', 'UVW Map'): 'UVWマップ',
        ('*', 'Unwrap UVW'): 'UVアンラップ',
        ('*', '3ds Max Modifier Parameters'): '3ds Max モディファイアパラメータ',
        ('*', 'Translation'): '移動',
        ('*', 'Rotation'): '回転',
        ('*', 'Scale'): 'スケール',
        ('*', 'Node Group'): 'ノードグループ',
        ('*', 'Mapping Type'): 'マッピング方式',
        ('*', 'Axis'): '軸',
        ('*', 'Map Channel / UV Map'): 'マップチャンネル / UVマップ',
        ('*', 'Fit To Object'): 'オブジェクトにフィット',
        ('*', 'Real-World Scale'): '実寸スケール',
        ('*', 'Length / Width / Height'): '長さ / 幅 / 高さ',
        ('*', 'U/V Tile'): 'U/V タイル',
        ('*', 'U/V Offset'): 'U/V オフセット',
        ('*', 'UV Rotation'): 'UV 回転',
        ('*', 'Flip U / Flip V'): 'U反転 / V反転',
        ('*', 'Gizmo Offset / Rotation'): 'ギズモオフセット / 回転',
        ('*', 'Unwrap Method'): 'アンラップ方式',
        ('*', 'Selected Faces Only'): '選択フェースのみ',
        ('*', 'Island Margin'): 'アイランド余白',
        ('*', 'Pack Islands'): 'アイランドをパック',
        ('*', 'Angle Limit'): '角度制限',
        ('*', 'Area Weight'): '面積ウェイト',
        ('*', 'Correct Aspect'): 'アスペクト補正',
        ('*', 'Scale / Clip To Bounds'): '範囲へスケール / クリップ',
        ('*', 'Cube Size / Projection Radius'): 'ボックスサイズ / 投影半径',
        ('*', '3ds Max equivalent'): '3ds Max 相当',
        ('*', 'Category'): 'カテゴリ',
        ('*', 'Amount / Strength / Angle / Radius'): '量 / 強度 / 角度 / 半径',
        ('*', 'Segments / Iterations / Tolerance'): 'セグメント / 反復 / 許容値',
        ('*', 'Map Channel / Tiling / Offset / Rotation'): 'マップチャンネル / タイリング / オフセット / 回転',
        ('*', 'Seed / Material ID / Preserve Boundaries'): 'シード / マテリアルID / 境界保持',
        ('*', 'Edit / Rebuild'): '編集 / 再生成',
        ('*', 'Restore'): '復元',
    })
except Exception:
    pass
# --- Stack modifier help translations END ---


# --- Modifier Auto Disable UI translations ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Modifier Auto Disable'): 'モディファイア自動無効',
        ('*', 'Function: automatically disables viewport evaluation of modifiers below/later than the active Smart Modifier stack item, so only the result up to the selected edit level affects the editable object.\nHow to use: turn ON for 3ds Max-style edit-level work where below/later modifiers are temporarily muted. Turn OFF to keep every manually enabled modifier visible even when another stack slot is active. Manual Enable/Disable states are not changed.'): '機能：アクティブな Smart Modifier スタック項目より下/後段のモディファイアのビューポート評価を自動的に一時無効化し、選択中の編集階層までの結果だけが編集対象オブジェクトに反映されるようにします。\n使い方：3ds Max 風に編集階層を分離して作業したい場合は ON にします。別のスタックスロットがアクティブでも、手動で有効にしている全モディファイアを表示したままにしたい場合は OFF にします。手動の有効 / 無効状態は変更しません。',
        ('*', 'Choose how the final evaluated stack is previewed while Modifier Auto Disable is controlling the active edit level.\nON: show the final stack result through EndPreview while the editable object stays up to the active level.\nOFF: do not generate EndPreview. When Modifier Auto Disable is ON, the viewport shows only up to the active stack level; when it is OFF, enabled modifiers remain visible.'): 'モディファイア自動無効がアクティブ編集階層を制御している間、最終評価スタックをどのようにプレビューするかを選びます。\nON：編集対象オブジェクトはアクティブ階層までに留めたまま、EndPreview で最終スタック結果を表示します。\nOFF：EndPreview を生成しません。モディファイア自動無効が ON の場合はアクティブなスタック階層までを表示し、OFF の場合は有効なモディファイアを表示したままにします。',
    })
except Exception:
    pass
# --- Modifier Auto Disable UI translations END ---

# --- v4.32.2 workflow category translation patch ---
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Edit / Selection'): '編集 / 選択',
    ('*', 'Transform / XForm'): '変換 / Xフォーム',
    ('*', 'Deform / FFD / Shape'): '変形 / FFD / 形状',
    ('*', 'Generate / Geometry'): '生成 / ジオメトリ',
    ('*', 'Precision / Symmetry'): '精密 / シンメトリ',
    ('*', 'Surface / Projection / Conform'): 'サーフェス / 投影 / コンフォーム',
    ('*', 'Subdivision / Smoothing'): 'サブディビジョン / スムージング',
    ('*', 'Normals / Shading'): '法線 / シェーディング',
    ('*', 'UV / Mapping'): 'UV / マッピング',
    ('*', 'CAD / Workplane'): 'CAD / 作業平面',
    ('*', 'Layout / Scatter / Placement'): 'レイアウト / 散布 / 配置',
    ('*', 'Rigging / Skin'): 'リギング / スキン',
    ('*', 'Simulation / Physics'): 'シミュレーション / 物理',
    ('*', 'Animation / Cache'): 'アニメーション / キャッシュ',
    ('*', 'Materials / Attributes'): 'マテリアル / 属性',
    ('*', 'World Space / WSM'): 'ワールドスペース / WSM',
    ('*', 'Space Warp / Binding'): 'スペースワープ / バインディング',
    ('*', 'Compatibility / Utility'): '互換 / ユーティリティ',
    ('*', 'Workflow custom modifier categories'): 'ワークフロー別独自モディファイアカテゴリ',
    ('*', 'Max-compatible custom modifiers'): 'Max 互換独自モディファイア',
})


# --- Smart Modifier Switcher scene-wide/instance-list translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Stack Instances'): 'スタックインスタンス',
        ('*', 'Function: switches the Object List to the instance objects linked to the active item in the Modifier Stack.\nHow to use: select a modifier row in the Modifier Stack, then turn this ON to list every object sharing that modifier instance. When Base Object is active, the list shows objects sharing the base object instance or linked object data instead. Turn it OFF to return to the objects that own the selected Modifier List target.'): '機能：オブジェクト一覧を、モディファイアスタックでアクティブな項目とインスタンス関係にあるオブジェクトの表示へ切り替えます。\n使い方：モディファイアスタックでモディファイア行を選択してからONにすると、そのモディファイアインスタンスを共有している全オブジェクトを一覧表示します。ベースオブジェクトがアクティブな場合は、ベースオブジェクトのインスタンスまたはリンクデータを共有しているオブジェクトを表示します。OFFにすると、モディファイア一覧で選択した対象を持つオブジェクト一覧へ戻ります。',
        ('*', 'Modifier List now scans all modifiers in the scene and displays entries by modifier name/type.\nThis setting is kept for compatibility with saved layouts; scene-wide name/type listing is used for the renewed switcher.'): 'モディファイア一覧は、現在シーン内の全モディファイアをスキャンし、モディファイア名とタイプ単位で表示します。\nこの設定は保存済みレイアウトとの互換性のため残されていますが、新しい切り替え機能ではシーン全体の名前/タイプ一覧が使用されます。',
        ('*', 'Legacy scope selector kept for saved layouts.\nThe renewed Modifier Switcher lists all modifiers in the scene and shows every object that owns the selected modifier target.'): '保存済みレイアウトとの互換性のため残されている旧対象範囲セレクターです。\n新しいモディファイア切り替えでは、シーン内の全モディファイアを一覧化し、選択したモディファイア対象を持つ全オブジェクトを表示します。',
        ('*', 'Legacy visibility filter kept for saved layouts.\nThe renewed Modifier Switcher scans the full scene so the Modifier List can show all scene modifiers.'): '保存済みレイアウトとの互換性のため残されている旧表示フィルターです。\n新しいモディファイア切り替えでは、モディファイア一覧にシーン内の全モディファイアを表示するため、シーン全体をスキャンします。',
        ('*', 'Show all objects that own the selected scene modifier'): '選択中のシーンモディファイアを持つ全オブジェクトを表示します',
        ('*', 'Rebuild the scene-wide Modifier List and Object List.\nUse this after adding/removing/renaming modifiers, or when the UI looks out of date.\nTip: When Auto Refresh is ON, this runs automatically at the interval you set.'): 'シーン全体のモディファイア一覧とオブジェクト一覧を再構築します。\nモディファイアを追加・削除・リネームした後や、UI表示が古い場合に使用してください。\n自動更新がONの場合は、設定した間隔で自動実行されます。',
        ('*', 'No modifiers found in scene.'): 'シーン内にモディファイアが見つかりません。',
        ('*', 'Turn ON (enable) the active target for ALL matching objects in the scene.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: This does not add/remove modifiers — it only changes their ON/OFF and display states.'): 'シーン内で一致する全オブジェクトのアクティブ対象をON（有効）にします。\n有効化されている表示フラグ（ビューポート/編集/ケージ/レンダー/展開）のみ変更されます。\nモディファイアの追加や削除は行わず、ON/OFFと表示状態だけを変更します。',
        ('*', 'Turn OFF (disable) the active target for ALL matching objects in the scene.\nOnly the enabled visibility flags (Viewport/Edit/Cage/Render/Expanded) are affected.\nTip: OFF is non-destructive; you can turn it ON again later.'): 'シーン内で一致する全オブジェクトのアクティブ対象をOFF（無効）にします。\n有効化されている表示フラグ（ビューポート/編集/ケージ/レンダー/展開）のみ変更されます。\nOFFは非破壊なので、後から再びONにできます。',
        ('*', 'Invert (toggle) the active target for ALL matching objects in the scene.\nObjects that are ON become OFF (and vice versa). Useful for quick comparisons.'): 'シーン内で一致する全オブジェクトのアクティブ対象を反転します。\nONの物はOFFに、OFFの物はONになります。素早い比較に便利です。',
        ('*', 'Tip: Combine with filters to quickly build a selection set.\n'): 'ヒント：フィルターと組み合わせると、選択セットを素早く作成できます。\n',
        ('*', 'This records the current modifier states of matching scene objects, so you can restore them later.\n'): 'シーン内で一致するオブジェクトの現在のモディファイア状態を記録し、後で復元できるようにします。\n',
        ('*', 'Load/apply the selected State Set to matching scene objects.\n'): '選択中の状態セットをシーン内で一致するオブジェクトへ読み込み/適用します。\n',
        ('*', 'Move the matching modifiers UP by one step for every matching object in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを1段上へ移動します。\n',
        ('*', 'Move the matching modifiers DOWN by one step for every matching object in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを1段下へ移動します。\n',
        ('*', 'Apply (bake) the matching modifiers for all matching objects in the scene.\n'): 'シーン内で一致する全オブジェクトの対象モディファイアを適用（ベイク）します。\n',
        ('*', 'Remove the matching modifiers from all matching objects in the scene.\n'): 'シーン内で一致する全オブジェクトから対象モディファイアを削除します。\n',
    })
except Exception:
    pass
# --- Smart Modifier Switcher scene-wide/instance-list translations END ---

# --- Modifier Management renewal translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Modifier Management'): 'モディファイア管理',
        ('*', 'Manage by Object'): 'オブジェクトから管理',
        ('*', 'Manage by Modifier'): 'モディファイアから管理',
        ('*', 'Management Mode'): '管理モード',
        ('*', "Switch how Modifier Management is organized.\nObject mode shows selected objects first and then their instance-related objects; the modifier list shows the selected objects' stack entries.\nModifier mode shows all scene modifiers first and then the objects that own the selected modifier."): 'モディファイア管理の構成を切り替えます。\nオブジェクトから管理では、選択中オブジェクトを先頭に、その下へ関連インスタンスオブジェクトを表示し、モディファイア一覧には選択中オブジェクトのスタック項目を表示します。\nモディファイアから管理では、シーン内の全モディファイアを先に表示し、選択中モディファイアを持つオブジェクトを下に表示します。',
        ('*', 'Show Object List above Modifier List and manage modifiers from the current object selection'): 'オブジェクト一覧をモディファイア一覧の上に表示し、現在のオブジェクト選択からモディファイアを管理します',
        ('*', 'Show Modifier List above Object List and manage objects from the selected scene modifier'): 'モディファイア一覧をオブジェクト一覧の上に表示し、選択中のシーンモディファイアからオブジェクトを管理します',
        ('*', 'No modifiers.'): 'モディファイアがありません。',
        ('*', 'Select Object'): 'オブジェクトを選択',
        ('*', 'Toggle Modifier Flag'): 'モディファイア表示を切り替え',
        ('*', 'Toggle the On Cage display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のケージ表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle whether this modifier row is visible in Edit Mode. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行を編集モードで表示するかを切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle the realtime Viewport display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のリアルタイムビューポート表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
        ('*', 'Toggle the Render display flag for this modifier row. If this modifier is instanced, every linked instance row is updated together.'): 'このモディファイア行のレンダー表示を切り替えます。インスタンス化されている場合は、リンクされた全インスタンス行を同時に更新します。',
    })
except Exception:
    pass
# --- Modifier Management renewal translations END ---

# --- Modifier Management preference translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Enable Modifier Management'): 'モディファイア管理を使用',
        ('*', 'Modifier Management Section'): 'モディファイア管理セクション',
        ('*', 'Enable the Modifier Management panel/features.'): 'モディファイア管理のパネル/機能を有効にします。',
        ('*', 'Open or close the Modifier Management section in the unified Smart Modifier N-panel.'): '統合Smart Modifier Nパネル内のモディファイア管理セクションを開閉します。',
        ('*', 'Modifier Management Auto Update'): 'モディファイア管理 自動更新',
    })
except Exception:
    pass
# --- Modifier Management preference translations END ---

# --- Modifier Management verification/fix translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Object'): 'オブジェクト',
        ('*', 'Modifier'): 'モディファイア',
        ('*', 'Manual'): '手動',
        ('*', 'Realtime'): 'リアルタイム',
        ('*', 'Modifier Management List Update'): 'モディファイア管理リスト更新',
        ('*', 'Set Management Mode'): '管理モードを設定',
        ('*', 'Set Selected Modifier Viewport'): '選択モディファイアのビューポート表示を設定',
        ('*', 'Remove Selected Modifiers'): '選択モディファイアを削除',
        ('*', 'Turn ON viewport visibility for the selected Modifier List row on every object that owns that modifier. Instanced modifiers update together.'): 'モディファイア一覧で選択中の行を持つ全オブジェクトで、ビューポート表示をONにします。インスタンス化モディファイアは同時に更新されます。',
        ('*', 'Turn OFF viewport visibility for the selected Modifier List row on every object that owns that modifier. Instanced modifiers update together.'): 'モディファイア一覧で選択中の行を持つ全オブジェクトで、ビューポート表示をOFFにします。インスタンス化モディファイアは同時に更新されます。',
    })
except Exception:
    pass
# --- Modifier Management verification/fix translations END ---

# --- Active stack level keymap translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Activate Stack Level Relative'): 'アクティブ階層を相対切替',
        ('*', 'Switch the active Smart Modifier stack level one step up or down without changing modifier order.'): 'モディファイアの並び順を変更せず、Smart Modifierスタックのアクティブ階層を1段上または下へ切り替えます。',
        ('*', 'Active Stack Level Up'): 'アクティブ階層を上へ',
        ('*', 'Switch the active Smart Modifier stack level one step up.'): 'Smart Modifierスタックのアクティブ階層を1つ上へ切り替えます。',
        ('*', 'Active Stack Level Down'): 'アクティブ階層を下へ',
        ('*', 'Switch the active Smart Modifier stack level one step down.'): 'Smart Modifierスタックのアクティブ階層を1つ下へ切り替えます。',
        ('*', 'Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Up.'): 'このオペレーターIDを Blender の プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モード にコピーして、アクティブ階層を上へ切り替えるショートカットとして登録します。',
        ('*', 'Copy this operator ID into Blender Preferences > Keymap > 3D View > Object Mode and Mesh > Edit Mode to bind Active Stack Level Down.'): 'このオペレーターIDを Blender の プリファレンス > キーマップ > 3Dビュー > オブジェクトモード、および Mesh > 編集モード にコピーして、アクティブ階層を下へ切り替えるショートカットとして登録します。',
    })
except Exception:
    pass
# --- Active stack level keymap translations END ---

# --- Modifier Auto Disable restore policy translations START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Auto Disable Restore Behavior'): '自動無効からの復元動作',
        ('*', 'Preserve Current States'): '現在の有効・無効状態を維持',
        ('*', 'Force Enable Selected States'): '選択項目を強制有効',
        ('*', 'Force On Cage'): 'ケージで表示を強制有効',
        ('*', 'Force Edit Mode'): '編集モードで表示を強制有効',
        ('*', 'Force Realtime Viewport'): 'リアルタイムで表示を強制有効',
        ('*', 'Force Render'): 'レンダーで表示を強制有効',
        ('*', 'Choose what happens to the four modifier-header display states when a modifier leaves temporary suppression caused by Modifier Auto Disable. Preserve Current States restores exactly the On Cage, Edit Mode, Realtime Viewport, and Render states saved before suppression. Force Enable Selected States restores the saved states and then turns ON only the channels selected by the four icon buttons below.'): '「モディファイア自動無効」による一時無効状態からモディファイアが戻る時、4つのモディファイアヘッダー表示状態をどう復元するか選択します。「現在の有効・無効状態を維持」は一時無効化前に保存したケージ、編集モード、リアルタイム、レンダーの状態を正確に復元します。「選択項目を強制有効」は保存状態を復元した後、下の4つのアイコンボタンで選択した項目だけをONにします。',
        ('*', 'Restore each modifier to the exact On Cage, Edit Mode, Realtime Viewport, and Render states it had before Modifier Auto Disable temporarily turned it off.'): '「モディファイア自動無効」で一時的にOFFになる前の、ケージ、編集モード、リアルタイム、レンダーの状態へ各モディファイアを正確に戻します。',
        ('*', 'After restoring a modifier that was temporarily suppressed, turn ON the display channels selected by the four icon buttons below. Unselected channels keep their saved states.'): '一時的に無効化されたモディファイアを復元した後、下の4つのアイコンボタンで選択した表示項目をONにします。選択していない項目は保存状態を維持します。',
        ('*', 'When Auto Disable Restore Behavior is Force Enable Selected States, turn On Cage ON when a temporarily suppressed modifier becomes active again. Use this when you want the editable cage to resume automatically. This setting affects only restoration after Modifier Auto Disable; it does not continuously override later manual changes.'): '「自動無効からの復元動作」が「選択項目を強制有効」の時、一時無効化されたモディファイアが再びアクティブになった際に「ケージで表示」をONにします。編集用ケージを自動的に再開したい場合に使用します。この設定は「モディファイア自動無効」からの復元時だけ作用し、その後の手動変更を継続的に上書きしません。',
        ('*', 'When Auto Disable Restore Behavior is Force Enable Selected States, turn Show in Edit Mode ON when a temporarily suppressed modifier becomes active again. Use this when you always want the restored modifier evaluated while editing. This setting affects only the restoration transition and does not continuously override later manual changes.'): '「自動無効からの復元動作」が「選択項目を強制有効」の時、一時無効化されたモディファイアが再びアクティブになった際に「編集モードで表示」をONにします。復元したモディファイアを編集中も常に評価したい場合に使用します。この設定は復元の切り替え時だけ作用し、その後の手動変更を継続的に上書きしません。',
        ('*', 'When Auto Disable Restore Behavior is Force Enable Selected States, turn Realtime Viewport ON when a temporarily suppressed modifier becomes active again. Use this when restored modifiers must immediately appear in the 3D View. This setting affects only the restoration transition and does not continuously override later manual changes.'): '「自動無効からの復元動作」が「選択項目を強制有効」の時、一時無効化されたモディファイアが再びアクティブになった際に「リアルタイムで表示」をONにします。復元したモディファイアを3Dビューへすぐ表示したい場合に使用します。この設定は復元の切り替え時だけ作用し、その後の手動変更を継続的に上書きしません。',
        ('*', 'When Auto Disable Restore Behavior is Force Enable Selected States, turn Render ON when a temporarily suppressed modifier becomes active again. Use this when restored modifiers must be included in final rendering. This setting affects only the restoration transition and does not continuously override later manual changes.'): '「自動無効からの復元動作」が「選択項目を強制有効」の時、一時無効化されたモディファイアが再びアクティブになった際に「レンダーで表示」をONにします。復元したモディファイアを最終レンダーへ含めたい場合に使用します。この設定は復元の切り替え時だけ作用し、その後の手動変更を継続的に上書きしません。',
        ('*', 'Restore Behavior'): '復元動作',
        ('*', 'Force ON'): '強制有効',
        ('*', 'Function: temporarily turns OFF On Cage, Show in Edit Mode, Realtime Viewport, and Render for modifiers below/later than the active Smart Modifier stack item, so only the result up to the selected edit level affects the editable object.\nHow to use: turn ON for 3ds Max-style edit-level work. Before muting a row, Smart Modifier saves all four manual display states. When the row becomes active again, the Settings > Auto Disable Restore policy either restores the saved states exactly or force-enables only the display channels selected there. Turn OFF to restore the saved states without force-enabling them.'): '機能: アクティブな Smart Modifier スタック項目より下／後段のモディファイアについて、「ケージで表示」「編集モードで表示」「リアルタイムで表示」「レンダーで表示」を一時的にOFFにし、選択した編集階層までの結果だけを編集対象へ反映します。\n使い方: 3ds Max風に編集階層を切り替えて作業する場合にONにします。行を一時無効化する前に4項目の手動状態を保存し、その行が再び有効範囲へ戻った時は「設定 > 自動無効からの復元」に従って保存状態を正確に復元するか、そこで選択した項目だけを強制的にONにします。OFFにすると強制有効を行わず、保存状態を復元します。',
    })
except Exception:
    pass
# --- Modifier Auto Disable restore policy translations END ---
# --- Stable dynamic exception templates START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Always-on setting update failed: {detail}'): '常時起動設定の更新に失敗しました: {detail}',
        ('*', 'Mesh repair could not start: {detail}'): 'メッシュ修復を開始できませんでした: {detail}',
        ('*', 'Detach / Separate Clean failed: {detail}'): 'デタッチ / クリーン分離に失敗しました: {detail}',
        ('*', 'Error details: {detail}'): 'エラー詳細: {detail}',
    })
except Exception:
    pass
# --- Stable dynamic exception templates END ---

# --- Localization successor proven reachable coverage START ---
try:
    translation_catalog_dict.setdefault('ja_JP', {}).update({
        ('*', 'Smart Modifier is shown as a standard N-panel category named Smart Modifier in Smart Tools Manager controlled editors.'): 'Smart Modifier は、Smart Tools Manager が制御するエディターで「Smart Modifier」という標準Nパネルカテゴリとして表示されます。',
        ('*', 'Open the detailed help popup for this tool group. The help content is loaded only when this button is clicked.'): 'このツールグループの詳細ヘルプポップアップを開きます。ヘルプ内容は、このボタンをクリックした時だけ読み込まれます。',
        ('*', 'Set an always-on feature to enabled or disabled. The N-panel State Save option controls whether the change is written immediately or deferred to scene close / preferences save.'): '常時起動機能を有効または無効にします。Nパネルの「状態保存」設定により、変更を即時保存するか、シーンを閉じる時／プリファレンス保存時まで延期するかが決まります。',
        ('*', 'Switch an always-on feature on or off. Saving follows the N-panel State Save policy.'): '常時起動機能のオン／オフを切り替えます。保存方法はNパネルの「状態保存」設定に従います。',
        ('*', 'Fill'): 'フィル',
        ('*', 'Switch Modifier Management between Object-based and Modifier-based management.\nObject shows selected objects first; Modifier shows all scene modifiers first.'): 'モディファイア管理を、オブジェクト基準とモディファイア基準で切り替えます。\nオブジェクトでは選択中のオブジェクトを先に表示し、モディファイアではシーン内の全モディファイアを先に表示します。',
        ('*', 'Manage from all modifiers in the scene'): 'シーン内の全モディファイアから管理',
        ('*', 'Manage from the current object selection'): '現在のオブジェクト選択から管理',
        ('*', 'Modifier List Target Action'): 'モディファイア一覧の対象操作',
        ('*', 'Apply the requested action to the selected modifier in the Modifier List on every object that owns it.\nUse Viewport ON/OFF for bulk display control, or Delete to remove the selected target from all listed owners.'): 'モディファイア一覧で選択中のモディファイアに対し、そのモディファイアを持つ全オブジェクトで指定操作を実行します。\n一括表示制御には「ビューポート ON/OFF」を使い、一覧中の全所有オブジェクトから対象を削除するには「削除」を使います。',
        ('*', 'Delete the selected modifier target from all owning objects'): '選択中のモディファイアを持つ全オブジェクトから対象を削除',
        ('*', 'Turn viewport display OFF for the selected modifier target on all owning objects'): '選択中のモディファイアを持つ全オブジェクトでビューポート表示をOFF',
        ('*', 'Turn viewport display ON for the selected modifier target on all owning objects'): '選択中のモディファイアを持つ全オブジェクトでビューポート表示をON',
        ('*', 'Viewport OFF'): 'ビューポート OFF',
        ('*', 'Viewport ON'): 'ビューポート ON',
        ('*', 'Turn viewport display ON for the modifier currently selected in Modifier Management on every object that owns it. Instanced modifiers are updated together.'): 'モディファイア管理で現在選択中のモディファイアを持つ全オブジェクトで、ビューポート表示をONにします。インスタンス化されたモディファイアは同時に更新されます。',
        ('*', 'Turn viewport display OFF for the modifier currently selected in Modifier Management on every object that owns it. Instanced modifiers are updated together.'): 'モディファイア管理で現在選択中のモディファイアを持つ全オブジェクトで、ビューポート表示をOFFにします。インスタンス化されたモディファイアは同時に更新されます。',
        ('*', 'Delete the modifier currently selected in Modifier Management from every object that owns it. This also runs Smart Modifier cleanup for custom modifiers such as Slice.'): 'モディファイア管理で現在選択中のモディファイアを持つ全オブジェクトから、そのモディファイアを削除します。Slice などのカスタムモディファイアでは、Smart Modifier のクリーンアップも実行します。',
        ('*', 'Run a bulk action on the selected Modifier Management target.'): '選択中のモディファイア管理対象に一括操作を実行します。',
        ('*', 'Set Target Viewport State'): '対象のビューポート状態を設定',
        ('*', 'Turn viewport display ON or OFF for the modifier currently selected in Modifier Management on every object that owns it.'): 'モディファイア管理で現在選択中のモディファイアを持つ全オブジェクトに対して、ビューポート表示をONまたはOFFにします。',
        ('*', 'Turn viewport display OFF'): 'ビューポート表示をOFFにする',
        ('*', 'Turn viewport display ON'): 'ビューポート表示をONにする',
        ('*', 'Select the clicked object from the Modifier Management Object List.\nNormal click replaces the current viewport selection. Shift+click or Ctrl+click adds the object to the current selection.'): 'モディファイア管理のオブジェクト一覧でクリックしたオブジェクトを選択します。\n通常クリックでは現在のビューポート選択を置き換え、Shift+クリックまたはCtrl+クリックでは現在の選択へ追加します。',
        ('*', 'Set Target Viewport'): '対象のビューポート表示を設定',
        ('*', 'Set Viewport visibility for the modifier selected in Modifier Management on every object that owns that modifier.\nInstanced modifier groups are updated together, the same as the Modifier Stack buttons.'): 'モディファイア管理で選択中のモディファイアを持つ全オブジェクトに、そのモディファイアのビューポート表示状態を設定します。\nインスタンスグループは、モディファイアスタックのボタンと同様に一括更新されます。',
        ('*', 'Remove Selected Modifier'): '選択中のモディファイアを削除',
        ('*', 'Delete the modifier selected in Modifier Management from every object that owns that modifier.\nThis uses the same cleanup hooks as the Modifier Stack so Slice helpers, node groups, vertex groups, and empty collections are removed when they are no longer needed.'): 'モディファイア管理で選択中のモディファイアを持つ全オブジェクトから、そのモディファイアを削除します。\nモディファイアスタックと同じクリーンアップフックを使うため、Slice のヘルパー、ノードグループ、頂点グループ、Empty コレクションは、不要になった時に削除されます。',
        ('*', 'Toggle the clicked modifier display flag in Modifier Management.\nWhen the row is an instanced modifier, the same flag is changed on every modifier in that instance group.'): 'モディファイア管理でクリックしたモディファイアの表示フラグを切り替えます。\nインスタンス化された行では、同じインスタンスグループの全モディファイアで同じフラグを切り替えます。',
        ('*', 'Toggle this modifier display flag.'): 'このモディファイアの表示フラグを切り替えます。',
        ('*', 'Select every object currently shown in the Object List.\nTip: Combine with filters to quickly build a selection set.\nNote: This only changes the viewport selection; it does not edit the Object List itself.'): 'オブジェクト一覧に現在表示されている全オブジェクトを選択します。\nヒント: フィルターと組み合わせると、選択セットをすばやく作成できます。\n注意: 変更するのはビューポート選択だけで、オブジェクト一覧自体は編集しません。',
        ('*', 'Create a NEW State Set (a snapshot) of modifier ON/OFF + display flags.\nThis records the current modifier states of matching scene objects, so you can restore them later.\nBeginner tip: Use State Sets to switch between setups (e.g. modeling vs render, high vs low).\nNote: This does NOT save modifier parameters or order — only the visibility/display states.'): '新しいステートセット（モディファイアのON/OFFと表示フラグのスナップショット）を作成します。\n現在のシーンで条件に一致するオブジェクトのモディファイア状態を記録し、後で復元できます。\n初心者向け: モデリング用／レンダー用、高／低などの設定切替にステートセットを使います。\n注意: モディファイアのパラメータや順序は保存せず、表示／有効状態だけを保存します。',
        ('*', 'Load/apply the selected State Set to matching scene objects.\nThis restores the saved ON/OFF + display flags from that snapshot.\nNote: It does not add/remove modifiers or change their order — it only restores states.'): '選択中のステートセットを、条件に一致するシーンオブジェクトへ読み込み／適用します。\nスナップショットに保存されたON/OFFと表示フラグを復元します。\n注意: モディファイアの追加／削除や順序変更は行わず、状態だけを復元します。',
        ('*', 'Move the matching modifiers UP by one step for every matching object in the scene.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): 'シーン内の条件に一致する各オブジェクトで、対象モディファイアを1段上へ移動します。\n複数オブジェクト間でモディファイア順を揃える時に使います。\nヒント: モディファイアの順序は重要で、移動すると最終結果が変わる場合があります。',
        ('*', 'Move the matching modifiers DOWN by one step for every matching object in the scene.\nUse this to keep modifier order consistent across many objects.\nTip: Modifier order matters — moving can change the final result.'): 'シーン内の条件に一致する各オブジェクトで、対象モディファイアを1段下へ移動します。\n複数オブジェクト間でモディファイア順を揃える時に使います。\nヒント: モディファイアの順序は重要で、移動すると最終結果が変わる場合があります。',
        ('*', 'Apply (bake) the matching modifiers for all matching objects in the scene.\nThis permanently changes geometry and removes the applied modifiers afterward.\nBeginner tip: If you only want to preview, use OFF/ON instead. Duplicate objects before applying if needed.'): 'シーン内の条件に一致する全オブジェクトで、対象モディファイアを適用（ベイク）します。\n形状を恒久的に変更し、適用後はモディファイアを削除します。\n初心者向け: プレビューだけならOFF/ONを使ってください。必要に応じて適用前にオブジェクトを複製してください。',
        ('*', 'Remove the matching modifiers from all matching objects in the scene.\nThis is destructive (it deletes the modifiers).\nTip: If you might need them later, use OFF (disable) instead of removing.'): 'シーン内の条件に一致する全オブジェクトから、対象モディファイアを削除します。\nこれはモディファイアを削除する破壊的操作です。\nヒント: 後で必要になる可能性がある場合は、削除せずOFF（無効）を使ってください。',
        ('*', 'Choose how Modifier Management refreshes its Object List and Modifier List.\nManual updates only when you press Update List. Realtime refreshes automatically while object selection or modifier state changes.'): 'モディファイア管理のオブジェクト一覧とモディファイア一覧の更新方法を選択します。\n「手動」は「リストを更新」を押した時だけ更新し、「リアルタイム」はオブジェクト選択やモディファイア状態の変更中に自動更新します。',
        ('*', 'Refresh lists automatically while the selection or stack contents change'): '選択内容またはスタック内容の変更中に一覧を自動更新',
        ('*', 'Refresh lists only when Update List is pressed'): '「リストを更新」を押した時だけ一覧を更新',
        ('*', 'Toggle Show End Result'): '最終結果表示を切り替え',
        ('*', 'Optional object name. When empty, the active object and its Smart Modifier base object are used.'): 'オブジェクト名を任意で指定します。空欄の場合は、アクティブオブジェクトとその Smart Modifier ベースオブジェクトを使用します。',
        ('*', 'Create copy/instance objects and link Smart Modifier stacks across object instances'): 'オブジェクトをコピー／インスタンス化し、オブジェクトインスタンス間で Smart Modifier スタックをリンクします',
        ('*', 'Choose whether to create independent copies or linked object instances.'): '独立コピーを作成するか、リンクされたオブジェクトインスタンスを作成するか選択します。',
        ('*', 'Create independent object and object-data copies.'): '独立したオブジェクトとオブジェクトデータのコピーを作成します。',
        ('*', 'Create linked object instances that share object data and Smart Modifier instance stacks.'): 'オブジェクトデータを共有し、Smart Modifier のインスタンススタックを同期するリンクインスタンスを作成します。',
        ('*', 'Set how many copies or instances are created from each selected object.'): '選択した各オブジェクトから作成するコピーまたはインスタンスの数を設定します。',
        ('*', 'Set the XYZ movement added to each successive copy or instance.'): '連続するコピーまたはインスタンスごとに加算するXYZ移動量を設定します。',
        ('*', 'Create copy or instance objects. Instance mode shares object data and links Smart Modifier stacks so adding a modifier to one instance adds the same instanced modifier to every object in the instance group.'): 'コピーまたはインスタンスオブジェクトを作成します。インスタンスモードではオブジェクトデータと Smart Modifier スタックを共有するため、1つのインスタンスへモディファイアを追加すると、インスタンスグループ内の全オブジェクトへ同じモディファイアが追加されます。',
        ('*', 'Release selected object instances and convert them to independent objects'): '選択中のオブジェクトインスタンスのリンクを解除し、独立したオブジェクトへ変換します',
        ('*', 'Toggle Modifier Display Flag'): 'モディファイア表示フラグを切り替え',
        ('*', 'Toggle a modifier display flag (cage, edit mode, render) (see tooltip for beginner-friendly details)'): 'モディファイアの表示フラグ（ケージ、編集モード、レンダー）を切り替えます（初心者向けの詳細はツールチップ参照）。',
        ('*', 'Toggle On Cage for this modifier. When Realtime Viewport or Edit Mode display is OFF, Blender shows this control as inactive because cage display cannot be used for that row.'): 'このモディファイアの「ケージで表示」を切り替えます。リアルタイムビューポートまたは編集モード表示がOFFの場合、この行ではケージ表示を使えないため、Blender はこの操作を無効表示します。',
        ('*', 'Toggle whether this modifier is visible while editing the object. When Realtime Viewport is OFF, Blender shows this control as inactive because edit-mode display cannot be evaluated.'): '編集中にこのモディファイアを表示するか切り替えます。リアルタイムビューポートがOFFの場合は編集モード表示を評価できないため、Blender はこの操作を無効表示します。',
        ('*', 'Toggle whether this modifier is enabled for final rendering. With Modifier Auto Disable ON, modifiers below the active stack slot are temporarily forced OFF for render as well.'): '最終レンダーでこのモディファイアを有効にするか切り替えます。「モディファイア自動無効」がONの場合、アクティブなスタック項目より下のモディファイアはレンダーでも一時的にOFFになります。',
        ('*', 'Choose how the Basis is prepared before applying modifiers to all shape-key shapes'): '全シェイプキーの形状へモディファイアを適用する前に、ベーシスをどのように準備するか選択します',
        ('*', 'Shape Key Apply Mode'): 'シェイプキー適用モード',
        ('*', 'Release the instance link for this modifier and make this row independent.'): 'このモディファイアのインスタンスリンクを解除し、この行を独立させます。',
        ('*', 'Move Active Modifier'): 'アクティブモディファイアを移動',
        ('*', 'Move the active modifier row up or down in the Smart Modifier stack.'): 'Smart Modifier スタック内でアクティブなモディファイア行を上または下へ移動します。',
        ('*', 'Duplicate Active Modifier'): 'アクティブモディファイアを複製',
        ('*', 'Duplicate the active modifier row in the Smart Modifier stack.'): 'Smart Modifier スタック内のアクティブなモディファイア行を複製します。',
        ('*', 'Expand Selected Only'): '選択中のみ展開',
        ('*', 'Expand only the active modifier row and collapse the other modifier rows.'): 'アクティブなモディファイア行だけを展開し、他のモディファイア行を折りたたみます。',
        ('*', 'Apply All Stack Modifiers'): 'スタック内の全モディファイアを適用',
        ('*', 'Apply every non-internal modifier in the Smart Modifier stack.'): 'Smart Modifier スタック内の内部用ではない全モディファイアを適用します。',
        ('*', 'Choose how the Basis is prepared before applying all stack modifiers to shape keys'): '全スタックモディファイアをシェイプキーへ適用する前に、ベーシスをどのように準備するか選択します',
        ('*', 'Always-on Toggles Section'): '常時機能切り替えセクション',
        ('*', 'Open or close the Always-on Toggles section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の常時機能切り替えセクションを開閉します。',
        ('*', 'Modifier Stack Section'): 'モディファイアスタックセクション',
        ('*', 'Open or close the Modifier Stack section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内のモディファイアスタックセクションを開閉します。',
        ('*', 'Open or close the Settings section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の設定セクションを開閉します。',
        ('*', 'Settings Section'): '設定セクション',
        ('*', 'Open or close the Smart Modifier Hub section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の Smart Modifier ハブセクションを開閉します。',
        ('*', 'Smart Modifier Hub Section'): 'Smart Modifier ハブセクション',
        ('*', 'Open or close the Precision / Layout / Path section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の精度／レイアウト／パスセクションを開閉します。',
        ('*', 'Precision / Layout / Path Section'): '精度 / レイアウト / パスセクション',
        ('*', 'Advanced / Surface Modeling Section'): '高度 / サーフェスモデリングセクション',
        ('*', 'Open or close the Advanced / Surface Modeling section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の高度／サーフェスモデリングセクションを開閉します。',
        ('*', 'Bundled Tool Catalog Section'): '同梱ツールカタログセクション',
        ('*', 'Open or close the Bundled Tool Catalog section in the unified Smart Modifier N-panel.'): '統合 Smart Modifier Nパネル内の同梱ツールカタログセクションを開閉します。',
        ('*', 'Require the Shift key after the Drag Clone operator is invoked from a manually registered keymap item. Smart Modifier never registers this shortcut automatically.'): '手動登録したキーマップ項目からドラッグクローンオペレーターを呼び出した後、Shift キーを必須にします。Smart Modifier がこのショートカットを自動登録することはありません。',
        ('*', 'Require the Ctrl key after the Drag Clone operator is invoked from a manually registered keymap item. During the transform itself Blender still uses Ctrl for snapping.'): '手動登録したキーマップ項目からドラッグクローンオペレーターを呼び出した後、Ctrl キーを必須にします。変形中は、Blender が引き続き Ctrl をスナップに使用します。',
        ('*', 'Require the Alt key after the Drag Clone operator is invoked from a manually registered keymap item. This keeps Shift and Ctrl free for precision and snapping after the clone is created.'): '手動登録したキーマップ項目からドラッグクローンオペレーターを呼び出した後、Alt キーを必須にします。これにより、クローン作成後も Shift と Ctrl を精密操作とスナップに使用できます。',
        ('*', 'Require the operating-system modifier key after the Drag Clone operator is invoked from a manually registered keymap item. On Windows this is the Windows key; on macOS this is Command; use it only when the OS and Blender keymap allow it.'): '手動登録したキーマップ項目からドラッグクローンオペレーターを呼び出した後、OS修飾キーを必須にします。Windows では Windows キー、macOS では Command キーです。OSとBlenderのキーマップで許可されている場合だけ使用してください。',
        ('*', 'Optionally require one non-modifier keyboard key in addition to the enabled modifier keys after the manually registered Drag Clone operator is invoked. Set this to No Extra Key for modifier-only behavior.'): '手動登録したドラッグクローンオペレーターを呼び出した後、有効な修飾キーに加えて修飾キー以外のキーを1つ任意で必須にします。修飾キーだけで操作する場合は「追加キーなし」に設定します。',
        ('*', 'Trigger Key'): 'トリガーキー',
        ('*', "Function: controls how Smart Modifier writes N-panel settings to Smart_Modifier_Suite/Smart_Modifier_Suite.json in Blender's versioned config folder. How to use: ON saves changes immediately or through the lightweight queue. OFF suppresses per-change autosave and writes only when the current file/scene is closed, when the add-on is disabled, or when Smart Modifier Save Preferences is executed."): '機能: Blender のバージョン別設定フォルダーにある Smart_Modifier_Suite/Smart_Modifier_Suite.json へ Smart Modifier のNパネル設定を書き込む方法を制御します。使い方: ONでは変更を即時または軽量キュー経由で保存します。OFFでは変更ごとの自動保存を抑止し、現在のファイル／シーンを閉じる時、アドオンを無効化する時、または「Smart Modifier プリファレンスを保存」を実行した時だけ書き込みます。',
        ('*', 'Function: enables Edit Polygon live synchronization, including selection tracking and edit-layer stack callbacks. How to use: enable it only while working with Edit Polygon layers that must react automatically. Disable it when not editing polygons; the live handlers remain fully stopped and the tool will not auto-enable them in the background.'): '機能: 選択追跡や編集レイヤースタックのコールバックを含む、Edit Polygon のライブ同期を有効にします。使い方: 自動的な反応が必要な Edit Polygon レイヤーで作業している間だけ有効にしてください。ポリゴン編集中でない時は無効にしてください。ライブハンドラーは完全に停止したままで、このツールがバックグラウンドで自動的に有効化することはありません。',
        ('*', 'Function: automatically disables Realtime Viewport and Render evaluation for modifiers below/later than the active Smart Modifier stack item, so only the result up to the selected edit level affects the editable object.\nHow to use: turn ON for 3ds Max-style edit-level work where below/later modifiers are temporarily muted. Turn OFF to keep every manually enabled Realtime/Render state visible even when another stack slot is active. Manual Realtime/Render states are stored and restored.'): '機能: アクティブな Smart Modifier スタック項目より下／後のモディファイアについて、リアルタイムビューポートとレンダーの評価を自動的に無効化し、選択中の編集レベルまでの結果だけが編集対象オブジェクトに影響するようにします。\n使い方: 下／後のモディファイアを一時的にミュートする3ds Max式の編集レベル作業ではONにします。別のスタックスロットがアクティブでも、手動で有効にしたリアルタイム／レンダー状態をすべて表示し続けるにはOFFにします。手動のリアルタイム／レンダー状態は保存され、復元されます。',
        ('*', 'Add an Edit Polygon layer to selected objects. You edit by adding a displacement offset on top of the evaluated result of the modifiers above. With multiple selection, it adds as an instance (same name/settings) and immediately enters multi-object Edit Mode.'): '選択中のオブジェクトへ Edit Polygon レイヤーを追加します。上のモディファイアの評価結果に変位オフセットを重ねて編集します。複数選択時はインスタンス（同じ名前／設定）として追加し、すぐにマルチオブジェクト編集モードへ入ります。',
        ('*', 'No valid selection found.'): '有効な選択が見つかりません。',
        ('*', 'No valid lattice users found.'): 'ラティスを使用する有効なオブジェクトが見つかりません。',
        ('*', 'Please select vertices, edges, or faces.'): '頂点、辺、または面を選択してください。',
        ('*', 'Smart Lattice updated: synced selection state for selected carriers.'): 'Smart Lattice を更新しました: 選択中のキャリアの選択状態を同期しました。',
        ('*', 'Select Noise Gizmo'): 'ノイズギズモを選択',
        ('*', 'Selects the Empty used as the Smart Connect Noise gizmo for this Noise modifier.'): 'このノイズモディファイアの Smart Connect Noise ギズモとして使用するEmptyを選択します。',
        ('*', 'Select Smart Connect Gizmo'): 'Smart Connect ギズモを選択',
        ('*', 'Selects the Empty used as the Smart Connect gizmo for this Max-compatible custom modifier.'): 'このMax互換カスタムモディファイアの Smart Connect ギズモとして使用するEmptyを選択します。',
        ('*', 'Add a non-destructive Smart Connect UVW Geometry Nodes modifier with a transformable planar mapping Empty gizmo.'): '変形可能な平面マッピング用Emptyギズモを備えた、非破壊の Smart Connect UVW Geometry Nodes モディファイアを追加します。',
        ('*', 'Select UVW Gizmo'): 'UVWギズモを選択',
        ('*', 'Select the Smart Connect UVW Empty gizmo for the active UVW Map modifier.'): 'アクティブな UVW Map モディファイア用の Smart Connect UVW Empty ギズモを選択します。',
        ('*', 'Clean UVW Map Helpers'): 'UVW Map ヘルパーをクリーンアップ',
        ('*', 'Clean unused Smart Connect UVW helper objects and node groups.'): '使用されていない Smart Connect UVW ヘルパーオブジェクトとノードグループをクリーンアップします。',
        ('*', 'Vertex Groups'): '頂点グループ',
        ('*', 'Shape Keys'): 'シェイプキー',
        ('*', 'UV Maps'): 'UVマップ',
        ('*', 'Modifier Properties'): 'モディファイアプロパティ',
        ('*', 'References'): '参照',
        ('*', 'Influence'): '影響',
        ('*', 'Toggle UI Section'): 'UIセクションを切り替え',
        ('*', 'Open or close this Smart Modifier section.'): 'この Smart Modifier セクションを開閉します。',
        ('*', 'Grouped root submenu for Smart Modifier user tools. It fans out into workflow categories so the migrated custom modifier catalog stays easier to scan than one long flat list.'): 'Smart Modifier ユーザーツールをまとめたルートサブメニューです。移行したカスタムモディファイアカタログを長い単一一覧より見やすく保つため、ワークフローカテゴリへ展開します。',
        ('*', "Master add menu for Smart Modifier. It restores Blender's standard modifier categories and also exposes bundled custom tools as split workflow-category menus so migrated functions can be started from one place without an oversized flat list."): 'Smart Modifier のマスター追加メニューです。Blender標準のモディファイアカテゴリを復元し、同梱カスタムツールもワークフローカテゴリ別の分割メニューとして表示するため、巨大な単一一覧を使わず1か所から移行済み機能を開始できます。',
        ('*', 'Root group that contains every Smart Modifier N-panel tool. Smart Tools Manager can place this panel in the 3D View.'): 'すべての Smart Modifier Nパネルツールを含むルートグループです。Smart Tools Manager はこのパネルを3Dビューに配置できます。',
        ('*', "Main modifier stack panel. Add Modifier restores Blender's standard modifier categories and centralizes bundled custom tools under workflow categories so old side-panel workflows are handled from this stack entry point."): 'メインのモディファイアスタックパネルです。「モディファイアを追加」はBlender標準のモディファイアカテゴリを復元し、同梱カスタムツールをワークフローカテゴリの下へ集約するため、従来のサイドパネルワークフローをこのスタック入口から利用できます。',
    })
except Exception:
    pass
# --- Localization successor proven reachable coverage END ---

translation_catalog_dict.setdefault('ja_JP', {})[(
    '*',
    "Function: controls whether Smart Modifier writes N-panel settings to Smart_Modifier_Suite/Smart_Modifier_Suite.json in Blender's versioned config folder. How to use: ON saves each change immediately. Turning OFF commits that OFF value once, then blocks normal, forced, save, and shutdown writes until ON is restored.",
)] = '機能：Blender のバージョン別設定フォルダー内にある Smart_Modifier_Suite/Smart_Modifier_Suite.json へ Smart Modifier のNパネル設定を書き込むかを制御します。使い方：ONでは変更ごとに即時保存します。OFFへの切り替え自体を最後に1回保存し、その後は再びONにするまで通常・強制・ファイル保存・終了時の書き込みを行いません。'
translation_catalog_dict.setdefault('ja_JP', {})[('*', 'Always-on Toggles')] = '常時機能切り替え'
