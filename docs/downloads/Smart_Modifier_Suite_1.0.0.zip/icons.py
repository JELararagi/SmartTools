# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

"""Icon routing for Smart Modifier Suite.

The add-on uses Blender's native UI icons first whenever a built-in glyph
matches the button's actual function.  Function-specific custom artwork is used
only for migrated tools, 3ds Max-style tools, and stack operations that do not
have an equivalent Blender default icon.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender-only runtime
    bpy = None  # type: ignore

# Preserve the exact collection across an in-place module reload.  Older
# Smart Modifier builds intentionally retained this object, so resetting the
# module global here would make that already-owned collection unreachable.
_PREVIEWS = globals().get('_PREVIEWS', None)
_PREVIEW_GENERATION = int(globals().get('_PREVIEW_GENERATION', 0) or 0)
_PREVIEW_LEDGER_KEY = '_JELARARAGI_SMART_MODIFIER_PREVIEW_LEDGER_V1'
_PREVIEW_OWNER_ID = 'JELararagi.smart_modifier_suite.icons.preview_collection.v1'
_ICON_DIR = Path(__file__).resolve().parent / 'icons'
_AVAILABLE_ICON_KEYS: set[str] | None = None


def _normalize(name: str | None) -> str:
    raw = str(name or '').strip().lower()
    for ch in (' ', '-', '.', '/', '\\'):
        raw = raw.replace(ch, '_')
    while '__' in raw:
        raw = raw.replace('__', '_')
    return raw.strip('_')


def _stem_from_icon_token(value: str | None) -> str:
    raw = str(value or '').strip().replace('\\', '/')
    if not raw:
        return ''
    if raw.lower().endswith('.png'):
        raw = raw[:-4]
    if '/' in raw:
        raw = raw.rsplit('/', 1)[-1]
    return _normalize(raw)




def _is_live_rna(data: Any) -> bool:
    """Return False for None or already-invalid Blender RNA wrappers.

    Passing an invalid RNA object to layout.prop can crash Blender in C++ before
    Python receives an exception, especially during rapid mode switches and
    selection-clear redraws.  Keep this check intentionally conservative.
    """
    if data is None:
        return False
    try:
        ptr = getattr(data, 'as_pointer', None)
        if callable(ptr):
            return bool(int(ptr() or 0))
    except ReferenceError:
        return False
    except Exception:
        return True
    return True

def _available_icon_keys() -> set[str]:
    global _AVAILABLE_ICON_KEYS
    if _AVAILABLE_ICON_KEYS is None:
        keys: set[str] = set()
        try:
            for path in _ICON_DIR.glob('*.png'):
                keys.add(_normalize(path.stem))
        except Exception:
            keys = set()
        _AVAILABLE_ICON_KEYS = keys
    return _AVAILABLE_ICON_KEYS


# -----------------------------------------------------------------------------
# Blender standard icons used by preference when they already communicate the
# action clearly.  Values are Blender icon tokens; keys may be legacy custom
# names, add-on semantic names, or fallback tokens.
# -----------------------------------------------------------------------------
STANDARD_ICON_ALIASES = {
    # Generic UI actions and status.
    'none': 'NONE',
    'blank': 'BLANK1',
    'info': 'QUESTION',
    'error': 'ERROR',
    'warning': 'ERROR',
    'help': 'QUESTION',
    'question': 'QUESTION',
    'add': 'ADD',
    'apply': 'CHECKMARK',
    'check': 'CHECKMARK',
    'delete': 'X',
    'remove': 'X',
    'trash': 'TRASH',
    'refresh': 'FILE_REFRESH',
    'reload': 'FILE_REFRESH',
    'copy': 'COPYDOWN',
    'paste': 'PASTEDOWN',
    'search': 'VIEWZOOM',
    'enabled_on': 'CHECKBOX_HLT',
    'enabled_off': 'CHECKBOX_DEHLT',
    'visible_on': 'HIDE_OFF',
    'visible_off': 'HIDE_ON',
    'render_on': 'RESTRICT_RENDER_OFF',
    'render_off': 'RESTRICT_RENDER_ON',
    'properties_open': 'TRIA_DOWN',
    'properties_closed': 'TRIA_RIGHT',
    'edit': 'EDITMODE_HLT',
    'cage': 'MESH_DATA',
    'menu': 'TRIA_DOWN',
    'move_transform_arrows': 'EMPTY_ARROWS',
    'axis_reset': 'EMPTY_AXIS',
    'base': 'MESH_CUBE',
    'curve': 'CURVE_DATA',
    'modifier': 'MODIFIER',
    'generic_modifier': 'MODIFIER',
    'topology': 'MOD_REMESH',
    'surface': 'MOD_SHRINKWRAP',
    'boolean': 'MOD_BOOLEAN',
    'bevel': 'MOD_BEVEL',
    'mirror': 'MOD_MIRROR',
    'array': 'MOD_ARRAY',
    'solidify': 'MOD_SOLIDIFY',
    'subsurf': 'MOD_SUBSURF',
    'lattice': 'MOD_LATTICE',
    'deform': 'MOD_SIMPLEDEFORM',
    'uvw': 'GROUP_UVS',
    'uv': 'GROUP_UVS',
    'normal_transfer_standard': 'MOD_DATA_TRANSFER',
    'hard_surface': 'MOD_NORMALEDIT',
    'topology_repair': 'MOD_REMESH',
    'curves_paths': 'CURVE_DATA',
    'surface_normals': 'MOD_SHRINKWRAP',
    'deformers': 'MOD_SIMPLEDEFORM',
    'other': 'TOOL_SETTINGS',

    # Common Blender tokens from legacy code and catalogs.
    'ADD': 'ADD',
    'ALIGN_JUSTIFY': 'ALIGN_JUSTIFY',
    'ARROW_LEFTRIGHT': 'ARROW_LEFTRIGHT',
    'AUTOMERGE_ON': 'AUTOMERGE_ON',
    'BLANK1': 'BLANK1',
    'CHECKBOX_HLT': 'CHECKBOX_HLT',
    'CHECKBOX_DEHLT': 'CHECKBOX_DEHLT',
    'CHECKMARK': 'CHECKMARK',
    'COPYDOWN': 'COPYDOWN',
    'CURVE_DATA': 'CURVE_DATA',
    'CURVE_PATH': 'CURVE_PATH',
    'CURVES_DATA': 'CURVES_DATA',
    'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
    'DOT': 'DOT',
    'DOWNARROW_HLT': 'DOWNARROW_HLT',
    'DUPLICATE': 'DUPLICATE',
    'EDITMODE_HLT': 'EDITMODE_HLT',
    'EMPTY_AXIS': 'EMPTY_AXIS',
    'EMPTY_ARROWS': 'EMPTY_ARROWS',
    'ERROR': 'ERROR',
    'EXTRUDE_REGION': 'FACESEL',
    'FACESEL': 'FACESEL',
    'FILE_REFRESH': 'FILE_REFRESH',
    'FILE_TICK': 'FILE_TICK',
    'GROUP_UVS': 'GROUP_UVS',
    'HIDE_OFF': 'HIDE_OFF',
    'HIDE_ON': 'HIDE_ON',
    'INFO': 'QUESTION',
    'IPO_LINEAR': 'IPO_LINEAR',
    'LATTICE_DATA': 'LATTICE_DATA',
    'LINKED': 'LINKED',
    'LOOP_BACK': 'LOOP_BACK',
    'MESH_CIRCLE': 'MESH_CIRCLE',
    'MESH_CUBE': 'MESH_CUBE',
    'MESH_DATA': 'MESH_DATA',
    'MESH_GRID': 'MESH_GRID',
    'META_CAPSULE': 'META_CAPSULE',
    'MODIFIER': 'MODIFIER',
    'MODIFIER_ON': 'MODIFIER_ON',
    'MODIFIER_OFF': 'MODIFIER_OFF',
    'MODIFIER_ON_CAGE': 'MODIFIER_ON',
    'MOD_ARRAY': 'MOD_ARRAY',
    'MOD_BUILD': 'MOD_BUILD',
    'MOD_DECIM': 'MOD_DECIM',
    'MOD_MASK': 'MOD_MASK',
    'MOD_MULTIRES': 'MOD_MULTIRES',
    'MOD_SCREW': 'MOD_SCREW',
    'MOD_SKIN': 'MOD_SKIN',
    'MOD_TRIANGULATE': 'MOD_TRIANGULATE',
    'MOD_WIREFRAME': 'MOD_WIREFRAME',
    'MOD_ARMATURE': 'MOD_ARMATURE',
    'MOD_MESHDEFORM': 'MOD_MESHDEFORM',
    'MOD_WARP': 'MOD_WARP',
    'MOD_CLOTH': 'MOD_CLOTH',
    'MOD_DYNAMICPAINT': 'MOD_DYNAMICPAINT',
    'MOD_EXPLODE': 'MOD_EXPLODE',
    'MOD_FLUIDSIM': 'MOD_FLUIDSIM',
    'MOD_OCEAN': 'MOD_OCEAN',
    'MOD_PARTICLE_INSTANCE': 'MOD_PARTICLE_INSTANCE',
    'MOD_PARTICLES': 'MOD_PARTICLES',
    'MOD_SOFT': 'MOD_SOFT',
    'MOD_VERTEX_WEIGHT': 'MOD_VERTEX_WEIGHT',
    'MOD_BEVEL': 'MOD_BEVEL',
    'MOD_BOOLEAN': 'MOD_BOOLEAN',
    'MOD_CAST': 'MOD_CAST',
    'MOD_CURVE': 'MOD_CURVE',
    'MOD_DATA_TRANSFER': 'MOD_DATA_TRANSFER',
    'MOD_DISPLACE': 'MOD_DISPLACE',
    'MOD_EDGESPLIT': 'MOD_EDGESPLIT',
    'MOD_LATTICE': 'MOD_LATTICE',
    'MOD_MIRROR': 'MOD_MIRROR',
    'MOD_NODES': 'MOD_NODES',
    'MOD_NORMALEDIT': 'MOD_NORMALEDIT',
    'MOD_REMESH': 'MOD_REMESH',
    'MOD_SHRINKWRAP': 'MOD_SHRINKWRAP',
    'MOD_SIMPLEDEFORM': 'MOD_SIMPLEDEFORM',
    'MOD_SMOOTH': 'MOD_SMOOTH',
    'MOD_SOLIDIFY': 'MOD_SOLIDIFY',
    'MOD_SUBSURF': 'MOD_SUBSURF',
    'MOD_UVPROJECT': 'MOD_UVPROJECT',
    'MOD_WAVE': 'MOD_WAVE',
    'NONE': 'NONE',
    'ORIENTATION_CURSOR': 'ORIENTATION_CURSOR',
    'ORIENTATION_GLOBAL': 'ORIENTATION_GLOBAL',
    'OUTLINER_COLLECTION': 'OUTLINER_COLLECTION',
    'OUTLINER_DATA_FONT': 'OUTLINER_DATA_FONT',
    'OUTLINER_OB_CURVE': 'OUTLINER_OB_CURVE',
    'PARTICLES': 'PARTICLES',
    'PASTEDOWN': 'PASTEDOWN',
    'PREFERENCES': 'PREFERENCES',
    'QUESTION': 'QUESTION',
    'RADIOBUT_ON': 'RADIOBUT_ON',
    'RADIOBUT_OFF': 'RADIOBUT_OFF',
    'RESTRICT_RENDER_OFF': 'RESTRICT_RENDER_OFF',
    'RESTRICT_RENDER_ON': 'RESTRICT_RENDER_ON',
    'RESTRICT_SELECT_OFF': 'RESTRICT_SELECT_OFF',
    'RESTRICT_VIEW_OFF': 'RESTRICT_VIEW_OFF',
    'RESTRICT_VIEW_ON': 'RESTRICT_VIEW_ON',
    'RNDCURVE': 'RNDCURVE',
    'SNAP_FACE': 'SNAP_FACE',
    'SNAP_ON': 'SNAP_ON',
    'SNAP_PEEL_OBJECT': 'SNAP_PEEL_OBJECT',
    'SNAP_VERTEX': 'SNAP_VERTEX',
    'SURFACE_NCURVE': 'SURFACE_NCURVE',
    'SURFACE_NSURFACE': 'SURFACE_NSURFACE',
    'TIME': 'TIME',
    'TOOL_SETTINGS': 'TOOL_SETTINGS',
    'TRASH': 'TRASH',
    'TRIA_DOWN': 'TRIA_DOWN',
    'TRIA_RIGHT': 'TRIA_RIGHT',
    'TRIA_UP': 'TRIA_UP',
    'RIA_UP': 'TRIA_UP',
    'UV': 'GROUP_UVS',
    'UV_SYNC_SELECT': 'UV_SYNC_SELECT',
    'UNLINKED': 'UNLINKED',
    'VIEWZOOM': 'VIEWZOOM',
    'X': 'X',
}

# Native modifier type -> Blender standard icon token.  This covers the custom
# Add Modifier menu and Max-library entries whose backend is a real Blender
# modifier.
MODIFIER_TYPE_ICONS = {
    'ARRAY': 'MOD_ARRAY',
    'BEVEL': 'MOD_BEVEL',
    'BOOLEAN': 'MOD_BOOLEAN',
    'BUILD': 'MOD_BUILD',
    'DECIMATE': 'MOD_DECIM',
    'EDGE_SPLIT': 'MOD_EDGESPLIT',
    'MASK': 'MOD_MASK',
    'MIRROR': 'MOD_MIRROR',
    'MULTIRES': 'MOD_MULTIRES',
    'REMESH': 'MOD_REMESH',
    'SCREW': 'MOD_SCREW',
    'SKIN': 'MOD_SKIN',
    'SOLIDIFY': 'MOD_SOLIDIFY',
    'SUBSURF': 'MOD_SUBSURF',
    'TRIANGULATE': 'MOD_TRIANGULATE',
    'WELD': 'AUTOMERGE_ON',
    'WIREFRAME': 'MOD_WIREFRAME',
    'ARMATURE': 'MOD_ARMATURE',
    'CAST': 'MOD_CAST',
    'CURVE': 'MOD_CURVE',
    'DISPLACE': 'MOD_DISPLACE',
    'HOOK': 'HOOK',
    'LAPLACIANDEFORM': 'MOD_MESHDEFORM',
    'LATTICE': 'MOD_LATTICE',
    'MESH_DEFORM': 'MOD_MESHDEFORM',
    'SHRINKWRAP': 'MOD_SHRINKWRAP',
    'SIMPLE_DEFORM': 'MOD_SIMPLEDEFORM',
    'SMOOTH': 'MOD_SMOOTH',
    'CORRECTIVE_SMOOTH': 'MOD_SMOOTH',
    'LAPLACIANSMOOTH': 'MOD_SMOOTH',
    'SURFACE_DEFORM': 'MOD_SHRINKWRAP',
    'WARP': 'MOD_WARP',
    'WAVE': 'MOD_WAVE',
    'VOLUME_DISPLACE': 'MOD_DISPLACE',
    'WEIGHTED_NORMAL': 'MOD_NORMALEDIT',
    'NORMAL_EDIT': 'MOD_NORMALEDIT',
    'NODES': 'MOD_NODES',
    'CLOTH': 'MOD_CLOTH',
    'COLLISION': 'MOD_PHYSICS',
    'DYNAMIC_PAINT': 'MOD_DYNAMICPAINT',
    'EXPLODE': 'MOD_EXPLODE',
    'FLUID': 'MOD_FLUIDSIM',
    'OCEAN': 'MOD_OCEAN',
    'PARTICLE_INSTANCE': 'MOD_PARTICLE_INSTANCE',
    'PARTICLE_SYSTEM': 'MOD_PARTICLES',
    'SOFT_BODY': 'MOD_SOFT',
    'MESH_TO_VOLUME': 'VOLUME_DATA',
    'VOLUME_TO_MESH': 'MOD_REMESH',
    'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
    'MESH_CACHE': 'MESH_DATA',
    'MESH_SEQUENCE_CACHE': 'MESH_DATA',
    'UV_PROJECT': 'MOD_UVPROJECT',
    'UV_WARP': 'MOD_UVPROJECT',
    'VERTEX_WEIGHT_EDIT': 'MOD_VERTEX_WEIGHT',
    'VERTEX_WEIGHT_MIX': 'MOD_VERTEX_WEIGHT',
    'VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
}

# Function-specific custom icons.  Keys can be semantic names, group ids,
# plugin ids, operator ids, or normalized Max modifier keys.
CUSTOM_ICON_ALIASES = {
    # Stack operations without a precise Blender default.
    'paste_instance': 'paste_instance_linked',
    'paste_instance_linked': 'paste_instance_linked',
    'move_up': 'move_up_stack',
    'move_down': 'move_down_stack',
    'stack': 'stack_layers',
    'stack_layers': 'stack_layers',
    'select_instances': 'select_linked_instances',
    'select_linked_instances': 'select_linked_instances',
    'make_unique': 'linked_unique_instances',
    'unique': 'linked_unique_instances',
    'linked': 'linked_unique_instances',
    'pin_on': 'pin_on',
    'pin_off': 'pin_off',
    'cut': 'cut_separate',
    'slice': 'cut_separate',
    'slice_panel': 'cut_separate',
    'axis_slice': 'cut_separate',
    'floor_generator': 'drop_to_floor',
    'stack_selected': 'stack_layers',
    'replace_with_active': 'linked_unique_instances',

    # Non-standard Smart Modifier groups.
    'precision_cad': 'workplane',
    'max_modifiers': 'max_modifier_library',
    'advanced_surface': 'surface_box_detail',
    'layout_scatter': 'scatter_layout',

    # Bundled plugin ids.    'smart_cleanup_repair_tool': 'audit_repair',
    'path_modifier': 'path_from_objects',
    'vertices_path_modifier': 'vertices_path',
    'pipe_modifier': 'pipe_path',
    'array_along_curve_modifier': 'array_along_curve',
    'instances_along_path_modifier': 'array_along_curve',
    'loft_modifier': 'loft_paths',
    'sweep_modifier': 'sweep_profile',
    'profile_primitive_modifier': 'profile_primitive',
    'helix_path_modifier': 'helix_path',
    'projection_modifier': 'projection_surface',    'conform_to_surface_tool': 'surface_conform',    'floor_modifier': 'drop_to_floor',
    'replace_modifier': 'linked_unique_instances',
    'randomize_modifier': 'randomize_selected',    'smart_lattice': 'ffd_lattice',
    'reset_xform_modifier': 'reset_xform',
    'unwrap_uvw_modifier': 'unwrap_uvw',
    'max_modifier_library': 'max_modifier_library',
    'scatter_modifier': 'scatter_layout',    'relax_selection_tool': 'relax_deform',
    'straighten_modifier': 'straighten_deform',
    'surface_box_detail_modifier': 'surface_box_detail',
    'slice_panel_modifier': 'cut_separate',
    'axis_slice_modifier': 'cut_separate',
    'workplane_modifier': 'workplane',
    'project_to_active_plane_modifier': 'project_to_active_plane',
    'face_component_array_modifier': 'face_component_array',
    'rebuild_curve_modifier': 'rebuild_curve',
    'audit_select_issues_modifier': 'audit_select_issues',
    'audit_selected_modifier': 'audit_selected',
    'detach_separate_clean_modifier': 'detach_separate_clean',
    'pivot_to_selection_modifier': 'pivot_to_selection',
    'pivot_to_bottom_modifier': 'pivot_to_bottom',
    'drop_to_floor_modifier': 'drop_to_floor',
    'drop_to_surface_modifier': 'drop_to_surface',
    'align_to_active_modifier': 'align_to_active',
    'distribute_selected_modifier': 'distribute_selected',
    'stack_selected_modifier': 'stack_layers',
    'quad_checker_modifier': 'quad_checker',
    'combine_join_clean_modifier': 'combine_join_clean',
    'mesh_auto_mirror_modifier': 'MOD_MIRROR',
    'edit_poly': 'edit_poly',

    # Direct semantic aliases.
    'unwrap': 'unwrap_uvw',
    'reset_xform': 'reset_xform',
    'max': 'max_modifier_library',
    'scatter': 'scatter_layout',
    'path_objects': 'path_from_objects',
    'path_vertices': 'vertices_path',
    'pipe': 'pipe_path',
    'loft': 'loft_paths',
    'sweep': 'sweep_profile',
    'profile': 'profile_primitive',
    'helix': 'helix_path',
    'projection': 'projection_surface',
    'surface_conform': 'surface_conform',
    'normal_transfer': 'normal_transfer',
    'bend': 'bend_deform',
    'twist': 'twist_deform',
    'taper': 'taper_deform',
    'ffd': 'ffd_lattice',
    'relax': 'relax_deform',
    'straighten': 'straighten_deform',
    'quad_checker': 'quad_checker',
    'audit_selected': 'audit_selected',
    'audit_issues': 'audit_select_issues',
    'audit_repair': 'audit_repair',
    'combine_join_clean': 'combine_join_clean',
    'detach_separate_clean': 'detach_separate_clean',
    'fill': 'fill_tool',
    'surface_box_detail': 'surface_box_detail',
    'workplane': 'workplane',
    'randomize': 'randomize_selected',
    'drop_floor': 'drop_to_floor',
    'drop_surface': 'drop_to_surface',

    # Hub / Advanced / Precision operator ids.
    'sms.smart_cleanup_repair': 'audit_repair',
    'sms.smart_fill_topology': 'fill_tool',
    'sms.detach_separate_clean': 'detach_separate_clean',
    'sms.relax_selection': 'relax_deform',
    'sms.straighten_selection': 'straighten_deform',
    'sms.smart_pipe_from_selection': 'pipe_path',
    'sms.smart_array_along_curve': 'array_along_curve',
    'sms.conform_to_surface': 'surface_conform',
    'sms.scatter_instances_bake': 'scatter_layout',
    'sms.floor_generator': 'drop_to_floor',
    'smsa.surface_box_detail': 'surface_box_detail',
    'smsa.slice_panel_stack': 'cut_separate',
    'smsa.combine_join_clean': 'combine_join_clean',
    'smsa.quick_bend_deformer': 'bend_deform',
    'smsa.quick_lattice_cage': 'ffd_lattice',
    'smsa.drop_to_surface': 'drop_to_surface',
    'smsp.workplane_from_active': 'workplane',
    'smsp.project_to_active_plane': 'project_to_active_plane',
    'smsp.project_to_selected_surface': 'projection_surface',
    'smsp.rebuild_active_curve': 'rebuild_curve',
    'smsp.selected_vertices_to_path': 'vertices_path',
    'smsp.selected_objects_to_path': 'path_from_objects',
    'smsp.loft_bridge_paths': 'loft_paths',
    'smsp.sweep_active_profile': 'sweep_profile',
    'smsp.add_profile_primitive': 'profile_primitive',
    'smsp.add_helix_path': 'helix_path',
    'smsp.drop_to_floor': 'drop_to_floor',
    'smsp.face_component_array': 'face_component_array',
    'smsp.audit_selected': 'audit_selected',
    'smsp.audit_repair': 'audit_repair',
    'smsp.audit_select_issues': 'audit_select_issues',
    'smsp.axis_slice_edit': 'cut_separate',
    'smsp.instances_along_path': 'array_along_curve',
    'smsp.align_to_active': 'align_to_active',
    'smsp.distribute_selected_axis': 'distribute_selected',
    'smsp.stack_selected': 'stack_layers',
    'smsp.replace_with_active': 'linked_unique_instances',
    'smsp.randomize_selected': 'randomize_selected',
}

# Plugin-level choices.  Standard tokens here deliberately stay standard.
PLUGIN_ICON_NAMES = {
    'boolean_stack_modifier': 'MOD_BOOLEAN',    'smart_cleanup_repair_tool': 'audit_repair',
    'curve_modifier': 'CURVE_DATA',
    'path_modifier': 'path_from_objects',
    'vertices_path_modifier': 'vertices_path',
    'pipe_modifier': 'pipe_path',
    'array_along_curve_modifier': 'array_along_curve',
    'instances_along_path_modifier': 'array_along_curve',
    'loft_modifier': 'loft_paths',
    'sweep_modifier': 'sweep_profile',
    'profile_primitive_modifier': 'profile_primitive',
    'helix_path_modifier': 'helix_path',
    'projection_modifier': 'projection_surface',    'conform_to_surface_tool': 'surface_conform',    'floor_modifier': 'drop_to_floor',
    'replace_modifier': 'linked_unique_instances',
    'randomize_modifier': 'randomize_selected',    'edit_poly': 'MESH_DATA',
    'smart_lattice': 'ffd_lattice',
    'mesh_auto_mirror_modifier': 'MOD_MIRROR',
    'reset_xform_modifier': 'reset_xform',
    'unwrap_uvw_modifier': 'unwrap_uvw',
    'uvw_map_modifier': 'GROUP_UVS',
    'noise_modifier': 'MOD_NOISE',
    'scatter_modifier': 'scatter_layout',
    'fill_modifier': 'fill_tool',
    'relax_selection_tool': 'relax_deform',
    'straighten_modifier': 'straighten_deform',
    'circle_modifier': 'MESH_CIRCLE',
    'extrude_modifier': 'FACESEL',
    'slice_panel_modifier': 'cut_separate',
    'surface_box_detail_modifier': 'surface_box_detail',
    'axis_slice_modifier': 'cut_separate',
    'workplane_modifier': 'workplane',
    'cad_intersect_modifier': 'MOD_BOOLEAN',
    'face_component_array_modifier': 'face_component_array',
    'rebuild_curve_modifier': 'rebuild_curve',
    'project_to_active_plane_modifier': 'project_to_active_plane',
    'audit_select_issues_modifier': 'audit_select_issues',
    'audit_selected_modifier': 'audit_selected',
    'detach_separate_clean_modifier': 'detach_separate_clean',
    'pivot_to_selection_modifier': 'pivot_to_selection',
    'pivot_to_bottom_modifier': 'pivot_to_bottom',
    'drop_to_floor_modifier': 'drop_to_floor',
    'align_to_active_modifier': 'align_to_active',
    'distribute_selected_modifier': 'distribute_selected',
    'stack_selected_modifier': 'stack_layers',
    'quad_checker_modifier': 'quad_checker',
    'solo_selected_modifier': 'HIDE_OFF',
    'drop_to_surface_modifier': 'drop_to_surface',
    'combine_join_clean_modifier': 'combine_join_clean',
    'max_modifier_library': 'max_modifier_library',
}

CATEGORY_ICONS = {
    'Max-compatible custom modifiers': 'max_modifier_library',
    'Generate': 'MODIFIER',
    'Deform': 'MOD_SIMPLEDEFORM',
    'Surface': 'MOD_SHRINKWRAP',
    'Subdivision': 'MOD_SUBSURF',
    'Topology': 'MOD_REMESH',
    'UV / Mapping': 'GROUP_UVS',
    'Edit / Select': 'MESH_DATA',
    'Topology / Repair': 'MOD_REMESH',
    'Curves / Surface': 'CURVE_DATA',
    'World Space': 'workplane',
    'Space Warp Binding': 'wind_binding',
    'Simulation': 'MODIFIER',
    'Materials': 'MATERIAL',
    'Animation / Cache': 'TIME',
    'Rigging': 'MODIFIER',
    'Utility': 'TOOL_SETTINGS',
    'Conversion': 'MODIFIER',
    'Transform': 'reset_xform',
    'Normals': 'MOD_NORMALEDIT',
    'Transfer / Projection': 'projection_surface',
    'Precision / Symmetry': 'MOD_MIRROR',
}

MAX_KEY_ICON_NAMES = {
    'reset_xform_modifier': 'reset_xform',
    'xform_modifier': 'reset_xform',
    'linked_xform_modifier': 'linked_unique_instances',
    'edit_poly_modifier': 'MESH_DATA',
    'edit_mesh_modifier': 'MESH_DATA',
    'skew_modifier': 'deform_modifier_custom',
    'squeeze_modifier': 'deform_modifier_custom',
    'affect_region_modifier': 'deform_modifier_custom',
    'melt_modifier': 'deform_modifier_custom',
    'face_extrude_modifier': 'FACESEL',
    'sweep_modifier': 'sweep_profile',
    'uvw_map_modifier': 'GROUP_UVS',
    'unwrap_uvw_modifier': 'unwrap_uvw',
    'projection_modifier': 'projection_surface',
    'conform_modifier': 'surface_conform',
    'normalize_spline_modifier': 'rebuild_curve',
    'ffd_binding_modifier': 'ffd_lattice',
    'space_conform_modifier': 'surface_conform',
}


# Blender 5.1.x-specific native modifier icons.  These tokens come from the
# Modifier.type enum itself and keep the stack/add menu from falling back to the
# generic MODIFIER glyph for standard modifier categories.
MODIFIER_TYPE_ICONS.update({
    'GREASE_PENCIL_VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
    'MESH_CACHE': 'MOD_MESHDEFORM',
    'MESH_SEQUENCE_CACHE': 'MOD_MESHDEFORM',
    'VERTEX_WEIGHT_EDIT': 'MOD_VERTEX_WEIGHT',
    'VERTEX_WEIGHT_MIX': 'MOD_VERTEX_WEIGHT',
    'VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
    'GREASE_PENCIL_COLOR': 'MOD_HUE_SATURATION',
    'GREASE_PENCIL_TINT': 'MOD_TINT',
    'GREASE_PENCIL_OPACITY': 'MOD_OPACITY',
    'GREASE_PENCIL_VERTEX_WEIGHT_ANGLE': 'MOD_VERTEX_WEIGHT',
    'GREASE_PENCIL_TIME': 'MOD_TIME',
    'GREASE_PENCIL_TEXTURE': 'MOD_UVPROJECT',
    'BUILD': 'MOD_BUILD',
    'DECIMATE': 'MOD_DECIM',
    'NODES': 'GEOMETRY_NODES',
    'MASK': 'MOD_MASK',
    'MESH_TO_VOLUME': 'VOLUME_DATA',
    'MULTIRES': 'MOD_MULTIRES',
    'SCREW': 'MOD_SCREW',
    'SKIN': 'MOD_SKIN',
    'TRIANGULATE': 'MOD_TRIANGULATE',
    'VOLUME_TO_MESH': 'VOLUME_DATA',
    'WELD': 'AUTOMERGE_OFF',
    'WIREFRAME': 'MOD_WIREFRAME',
    'GREASE_PENCIL_ARRAY': 'MOD_ARRAY',
    'GREASE_PENCIL_BUILD': 'MOD_BUILD',
    'GREASE_PENCIL_LENGTH': 'MOD_LENGTH',
    'LINEART': 'MOD_LINEART',
    'GREASE_PENCIL_MIRROR': 'MOD_MIRROR',
    'GREASE_PENCIL_MULTIPLY': 'GP_MULTIFRAME_EDITING',
    'GREASE_PENCIL_SIMPLIFY': 'MOD_SIMPLIFY',
    'GREASE_PENCIL_SUBDIV': 'MOD_SUBSURF',
    'GREASE_PENCIL_ENVELOPE': 'MOD_ENVELOPE',
    'GREASE_PENCIL_OUTLINE': 'MOD_OUTLINE',
    'ARMATURE': 'MOD_ARMATURE',
    'LAPLACIANDEFORM': 'MOD_MESHDEFORM',
    'MESH_DEFORM': 'MOD_MESHDEFORM',
    'SURFACE_DEFORM': 'MOD_MESHDEFORM',
    'SURFACE': 'SURFACE_DATA',
    'WARP': 'MOD_WARP',
    'VOLUME_DISPLACE': 'VOLUME_DATA',
    'GREASE_PENCIL_HOOK': 'HOOK',
    'GREASE_PENCIL_NOISE': 'MOD_NOISE',
    'GREASE_PENCIL_OFFSET': 'MOD_OFFSET',
    'GREASE_PENCIL_SMOOTH': 'SMOOTHCURVE',
    'GREASE_PENCIL_THICKNESS': 'MOD_THICKNESS',
    'GREASE_PENCIL_LATTICE': 'MOD_LATTICE',
    'GREASE_PENCIL_DASH': 'MOD_DASH',
    'GREASE_PENCIL_ARMATURE': 'MOD_ARMATURE',
    'GREASE_PENCIL_SHRINKWRAP': 'MOD_SHRINKWRAP',
    'CLOTH': 'MOD_CLOTH',
    'COLLISION': 'MOD_PHYSICS',
    'DYNAMIC_PAINT': 'MOD_DYNAMICPAINT',
    'EXPLODE': 'MOD_EXPLODE',
    'FLUID': 'MOD_FLUIDSIM',
    'OCEAN': 'MOD_OCEAN',
    'PARTICLE_INSTANCE': 'MOD_PARTICLE_INSTANCE',
    'PARTICLE_SYSTEM': 'MOD_PARTICLES',
    'SOFT_BODY': 'MOD_SOFT',
})

# Max-compatible/custom stack entries that do not have a native Blender
# modifier type.  These are assigned by operation semantics rather than by the
# generic NODES backend so the stack communicates the actual role of the item.
_MAX_CUSTOM_ICON_EXTENSIONS = {
    'noise_modifier': 'MOD_NOISE',
    'push_modifier': 'deform_modifier_custom',
    'preserve_modifier': 'deform_modifier_custom',
    'mirror_modifier': 'MOD_MIRROR',
    'symmetry_modifier': 'MOD_MIRROR',
}
MAX_KEY_ICON_NAMES.update(_MAX_CUSTOM_ICON_EXTENSIONS)
PLUGIN_ICON_NAMES.update({'max_' + key: value for key, value in MAX_KEY_ICON_NAMES.items()})
CUSTOM_ICON_ALIASES.update({
    'replace_modifier': 'linked_unique_instances',
    'shape_key': 'SHAPEKEY_DATA',
    'vertex_paint': 'VPAINT_HLT',
})


def _dict_lookup(table: dict[str, str], value: str | None) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    norm = _normalize(raw)
    return str(table.get(raw) or table.get(raw.upper()) or table.get(raw.lower()) or table.get(norm) or table.get(norm.upper()) or '')


def _resolve_custom_icon_key(*names: str | None) -> str:
    available = _available_icon_keys()
    queue: list[str] = []
    for value in names:
        if value is None:
            continue
        raw = str(value).strip()
        if raw:
            queue.append(raw)
    seen: set[str] = set()
    while queue:
        raw = queue.pop(0)
        stem = _stem_from_icon_token(raw)
        if not stem or stem == 'none' or stem in seen:
            continue
        seen.add(stem)
        alias = _dict_lookup(CUSTOM_ICON_ALIASES, raw)
        standard = _dict_lookup(STANDARD_ICON_ALIASES, raw)
        # When callers pass an explicit Blender icon token (for example LINKED),
        # never divert it through a semantic custom-icon alias such as
        # linked_unique_instances.  This keeps stack row status icons identical to
        # Blender's native icon names.
        if standard and raw.upper() == raw:
            continue
        # Alias values may intentionally be Blender standard tokens.  Let the
        # standard resolver handle those rather than treating them as files.
        if alias and alias != raw:
            alias_stem = _stem_from_icon_token(alias)
            if alias_stem in available:
                return alias_stem
            if alias_stem and alias_stem not in seen and not alias.isupper():
                queue.insert(0, alias)
                continue
        # If a name has an explicit Blender-standard mapping and no custom alias,
        # do not grab a same-named PNG by accident.  This enforces the standard
        # icon preference requested for native Blender functions.
        if stem in available and not (standard and not alias):
            return stem
    return ''


def _resolve_standard_icon(*names: str | None) -> str:
    for value in names:
        if value is None:
            continue
        raw = str(value).strip()
        if not raw or raw.upper() == 'NONE':
            continue
        alias = _dict_lookup(CUSTOM_ICON_ALIASES, raw)
        if alias and alias.isupper():
            return alias
        std = _dict_lookup(STANDARD_ICON_ALIASES, raw)
        if std:
            return std
        # Existing code already uses Blender tokens as fallbacks.  Preserve them
        # when no custom artwork is assigned.
        if raw.replace('_', '').replace('0', '').replace('1', '').isalnum() and raw.upper() == raw:
            return raw
    return ''


def canonical_icon_name(name: str | None, fallback: str | None = None) -> str:
    """Return a usable icon selector: custom key first, else Blender token.

    Fallbacks are consulted only after the primary name fails.  This prevents a
    custom fallback such as ``max_modifier_library`` from overriding a valid
    Blender-standard icon like ``MOD_ARRAY``.
    """
    return (
        _resolve_custom_icon_key(name)
        or _resolve_standard_icon(name)
        or _resolve_custom_icon_key(fallback)
        or _resolve_standard_icon(fallback)
    )


def _preview_driver_namespace():
    """Return Blender's shared namespace without scanning foreign resources."""
    if bpy is None:
        return None
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    except Exception:
        namespace = None
    return namespace if hasattr(namespace, 'get') else None


def _owned_preview_record():
    namespace = _preview_driver_namespace()
    if namespace is None:
        return None
    try:
        record = namespace.get(_PREVIEW_LEDGER_KEY)
    except Exception:
        return None
    if not isinstance(record, dict):
        return None
    if record.get('owner_id') != _PREVIEW_OWNER_ID:
        return None
    return record


def _preview_remove_callable():
    if bpy is None:
        return None
    try:
        from bpy.utils import previews as previews
    except Exception:
        try:
            previews = bpy.utils.previews
        except Exception:
            previews = None
    remove = getattr(previews, 'remove', None) if previews is not None else None
    return remove if callable(remove) else None


def _publish_owned_preview_collection(pcoll, remove_callable) -> int:
    """Publish only the exact collection created or inherited by this module."""
    global _PREVIEW_GENERATION
    namespace = _preview_driver_namespace()
    previous = _owned_preview_record()
    try:
        previous_generation = int((previous or {}).get('generation', 0) or 0)
    except Exception:
        previous_generation = 0
    _PREVIEW_GENERATION = max(_PREVIEW_GENERATION, previous_generation) + 1
    if namespace is not None:
        try:
            current = namespace.get(_PREVIEW_LEDGER_KEY)
        except Exception:
            current = None
        # The key is intentionally private, but still never overwrite a value
        # that was not published by this Suite.  Module-local exact ownership
        # remains sufficient for the current enable/disable cycle.
        can_publish = current is None or (
            isinstance(current, dict)
            and current.get('owner_id') == _PREVIEW_OWNER_ID
        )
        if can_publish:
            try:
                namespace[_PREVIEW_LEDGER_KEY] = {
                    'owner_id': _PREVIEW_OWNER_ID,
                    'generation': _PREVIEW_GENERATION,
                    'state': 'ACTIVE',
                    'collection': pcoll,
                    'collection_id': id(pcoll),
                    'remove': remove_callable,
                }
            except Exception:
                pass
    return _PREVIEW_GENERATION


def _adopt_existing_owned_preview_collection() -> bool:
    """Adopt this package's exact collection across disable/reload boundaries."""
    global _PREVIEWS, _PREVIEW_GENERATION
    record = _owned_preview_record()

    if _PREVIEWS is not None:
        if record is not None:
            try:
                record_generation = int(record.get('generation', 0) or 0)
            except Exception:
                record_generation = 0
            if (
                record.get('state') == 'REMOVED'
                and int(record.get('collection_id', 0) or 0) == id(_PREVIEWS)
                and record_generation == _PREVIEW_GENERATION
            ):
                # A newer module generation already removed this exact object.
                _PREVIEWS = None
                return False
            if record.get('state') == 'ACTIVE' and record.get('collection') is _PREVIEWS:
                _PREVIEW_GENERATION = record_generation
                return True
        remove = _preview_remove_callable()
        if remove is not None:
            _publish_owned_preview_collection(_PREVIEWS, remove)
        return True

    if record is None or record.get('state') != 'ACTIVE':
        return False
    pcoll = record.get('collection')
    if pcoll is None:
        return False
    _PREVIEWS = pcoll
    try:
        _PREVIEW_GENERATION = int(record.get('generation', 0) or 0)
    except Exception:
        _PREVIEW_GENERATION = 0
    return True


def register() -> None:
    global _PREVIEWS, _AVAILABLE_ICON_KEYS
    if bpy is None:
        return
    if _adopt_existing_owned_preview_collection():
        return
    _AVAILABLE_ICON_KEYS = None
    try:
        from bpy.utils import previews as previews  # Blender preview collection API.
    except Exception:
        try:
            previews = bpy.utils.previews
        except Exception:
            previews = None
    if previews is None:
        return
    try:
        pcoll = previews.new()
    except Exception:
        return
    loaded = False
    try:
        for path in sorted(_ICON_DIR.glob('*.png')):
            key = _normalize(path.stem)
            try:
                pcoll.load(key, str(path), 'IMAGE')
                loaded = True
            except Exception:
                pass
    except Exception:
        pass
    if not loaded:
        try:
            previews.remove(pcoll)
        except Exception:
            pass
        return
    _PREVIEWS = pcoll
    _publish_owned_preview_collection(pcoll, previews.remove)


def unregister() -> bool:
    """Remove exactly this Suite's collection after all UI users are detached.

    The caller owns teardown ordering.  No timer, global resource scan, name
    matching, or foreign collection handling is performed here.
    """
    global _PREVIEWS, _PREVIEW_GENERATION
    if bpy is None:
        _PREVIEWS = None
        _PREVIEW_GENERATION = 0
        return False

    record = _owned_preview_record()
    pcoll = _PREVIEWS
    if pcoll is None and record is not None and record.get('state') == 'ACTIVE':
        pcoll = record.get('collection')
        try:
            _PREVIEW_GENERATION = int(record.get('generation', 0) or 0)
        except Exception:
            _PREVIEW_GENERATION = 0
    if pcoll is None:
        return False

    if record is not None:
        try:
            record_generation = int(record.get('generation', 0) or 0)
        except Exception:
            record_generation = 0
        if (
            record.get('state') == 'REMOVED'
            and int(record.get('collection_id', 0) or 0) == id(pcoll)
            and record_generation == _PREVIEW_GENERATION
        ):
            _PREVIEWS = None
            return False
    else:
        record_generation = _PREVIEW_GENERATION

    remove = None
    if record is not None and record.get('state') == 'ACTIVE' and record.get('collection') is pcoll:
        candidate = record.get('remove')
        if callable(candidate):
            remove = candidate
    if remove is None:
        remove = _preview_remove_callable()
    if remove is None:
        return False

    try:
        remove(pcoll)
    except Exception:
        # Keep the exact reference so a later, correctly ordered teardown can
        # retry.  Hiding the warning without releasing the collection is not an
        # acceptable fallback.
        return False

    _PREVIEWS = None
    namespace = _preview_driver_namespace()
    if namespace is not None:
        try:
            current = namespace.get(_PREVIEW_LEDGER_KEY)
        except Exception:
            current = None
        if (
            isinstance(current, dict)
            and current.get('owner_id') == _PREVIEW_OWNER_ID
            and current.get('collection') is pcoll
        ):
            try:
                namespace.pop(_PREVIEW_LEDGER_KEY, None)
            except Exception:
                pass
    return True

def icon_value(name: str | None, fallback: str | None = None) -> int:
    """Return a preview icon id for custom artwork only.

    Built-in Blender icons deliberately return 0 here so callers can fall back to
    Blender's native icon drawing path.
    """
    if _PREVIEWS is None:
        return 0
    key = _resolve_custom_icon_key(name, fallback)
    if not key:
        return 0
    try:
        item = _PREVIEWS.get(key)
        if item is not None:
            return int(getattr(item, 'icon_id', 0) or 0)
    except Exception:
        pass
    return 0


def _safe_modifier_custom_prop(mod: Any, key: str, default: str = '') -> str:
    """Read modifier ID properties without breaking on Blender built-in modifiers.

    Some Blender 5.1 modifier RNA types expose a get attribute but raise
    TypeError when IDProperties are unavailable.  Falling back silently keeps
    standard modifiers on the icon map path instead of returning the generic
    fallback icon.
    """
    try:
        getter = getattr(mod, 'get', None)
        if callable(getter):
            value = getter(key, default)
            return str(value or default)
    except Exception:
        pass
    try:
        value = mod[key]
        return str(value or default)
    except Exception:
        return str(default or '')


def icon_name_for_modifier(mod: Any, fallback: str = 'MODIFIER') -> str:
    try:
        plugin_id = _safe_modifier_custom_prop(mod, 'smsm_plugin_id', '')
        if plugin_id in PLUGIN_ICON_NAMES:
            return canonical_icon_name(PLUGIN_ICON_NAMES[plugin_id], fallback) or fallback
        key = _safe_modifier_custom_prop(mod, 'smsm_max_modifier_key', '')
        if not key and plugin_id.startswith('max_'):
            key = plugin_id[4:]
        if key:
            chosen = MAX_KEY_ICON_NAMES.get(key) or MAX_KEY_ICON_NAMES.get(_normalize(key))
            if chosen:
                return canonical_icon_name(chosen, fallback) or fallback
            key_norm = _normalize(key)
            if 'xform' in key_norm:
                return canonical_icon_name('reset_xform', fallback) or fallback
            if 'uvw' in key_norm or 'map' in key_norm:
                return canonical_icon_name('GROUP_UVS', fallback) or fallback
            if 'unwrap' in key_norm:
                return canonical_icon_name('unwrap_uvw', fallback) or fallback
        typ = str(getattr(mod, 'type', '') or '')
        return canonical_icon_name(MODIFIER_TYPE_ICONS.get(typ, fallback), fallback) or fallback
    except Exception:
        return fallback


def icon_name_for_plugin(plugin: dict | None, fallback: str = 'MODIFIER') -> str:
    try:
        if not isinstance(plugin, dict):
            return fallback
        pid = str(plugin.get('id') or plugin.get('plugin_id') or '')
        if pid in PLUGIN_ICON_NAMES:
            return canonical_icon_name(PLUGIN_ICON_NAMES[pid], fallback) or fallback
        if pid.startswith('max_'):
            chosen = MAX_KEY_ICON_NAMES.get(pid[4:]) or MAX_KEY_ICON_NAMES.get(_normalize(pid[4:]))
            if chosen:
                return canonical_icon_name(chosen, fallback) or fallback
        key = str(plugin.get('max_modifier_key') or plugin.get('key') or '')
        if key:
            chosen = MAX_KEY_ICON_NAMES.get(key) or MAX_KEY_ICON_NAMES.get(_normalize(key))
            if chosen:
                return canonical_icon_name(chosen, fallback) or fallback
        custom = str(plugin.get('custom_icon') or '')
        if custom:
            return canonical_icon_name(custom, fallback) or fallback
        icon = str(plugin.get('icon') or '')
        if icon:
            resolved = canonical_icon_name(icon, '')
            if resolved and resolved != 'MODIFIER':
                return resolved
        cat = str(plugin.get('category') or plugin.get('group_label') or '')
        if cat in CATEGORY_ICONS:
            resolved = canonical_icon_name(CATEGORY_ICONS[cat], fallback) or fallback
            if resolved and resolved != 'MODIFIER':
                return resolved
        group = str(plugin.get('group') or '')
        if group:
            resolved = canonical_icon_name(group, fallback) or fallback
            if resolved and resolved != 'MODIFIER':
                return resolved
        label = str(plugin.get('label') or plugin.get('label_ja') or '')
        norm_label = _normalize(label)
        for token, chosen in MAX_KEY_ICON_NAMES.items():
            if token and token.replace('_modifier', '') in norm_label:
                resolved = canonical_icon_name(chosen, fallback) or fallback
                if resolved and resolved != 'MODIFIER':
                    return resolved
        return canonical_icon_name(fallback, 'MODIFIER') or fallback
    except Exception:
        return fallback


def icon_name_for_max_definition(defn: dict | None, fallback: str = 'max_modifier_library') -> str:
    try:
        if not isinstance(defn, dict):
            return canonical_icon_name(fallback, 'MODIFIER') or 'MODIFIER'
        key = str(defn.get('key') or '')
        key_norm = _normalize(key)
        chosen = MAX_KEY_ICON_NAMES.get(key) or MAX_KEY_ICON_NAMES.get(key_norm)
        if chosen:
            return canonical_icon_name(chosen, fallback) or fallback
        label_text = str(defn.get('label') or '').casefold()
        if 'reset xform' in label_text or 'xform' in label_text:
            return canonical_icon_name('reset_xform', fallback) or fallback
        if 'unwrap' in label_text:
            return canonical_icon_name('unwrap_uvw', fallback) or fallback
        if 'uvw' in label_text or 'map' in label_text:
            return canonical_icon_name('GROUP_UVS', fallback) or fallback
        mt = str(defn.get('modifier_type') or '')
        if mt in MODIFIER_TYPE_ICONS:
            return canonical_icon_name(MODIFIER_TYPE_ICONS[mt], fallback) or fallback
        backend = str(defn.get('backend') or '')
        if backend == 'builtin':
            return canonical_icon_name(str(defn.get('icon') or 'MODIFIER'), fallback) or fallback
        category = str(defn.get('category') or '')
        if category in CATEGORY_ICONS:
            return canonical_icon_name(CATEGORY_ICONS[category], fallback) or fallback
    except Exception:
        pass
    return canonical_icon_name(fallback, 'MODIFIER') or 'MODIFIER'


def _without_icon_keywords(kwargs: dict) -> dict:
    clean = dict(kwargs)
    clean.pop('icon_value', None)
    clean.pop('icon', None)
    return clean


def _with_icon_kwargs(kwargs: dict, icon_name: str | None, fallback_icon: str | None) -> dict:
    call_kwargs = dict(kwargs)
    iv = icon_value(icon_name, None)
    if iv:
        call_kwargs['icon_value'] = iv
        return call_kwargs
    builtin = _resolve_standard_icon(icon_name, fallback_icon)
    if builtin and builtin != 'NONE':
        call_kwargs['icon'] = builtin
        return call_kwargs
    iv = icon_value(fallback_icon, None)
    if iv:
        call_kwargs['icon_value'] = iv
    return call_kwargs


def _should_keep_default_emboss(kwargs: dict, emboss: bool | None) -> bool:
    if emboss is not False:
        return False
    text_value = kwargs.get('text', None)
    return text_value == '' and ('icon_value' in kwargs or 'icon' in kwargs)


def operator(layout, operator_id: str, *, text: str | None = '', icon_name: str = '', fallback_icon: str = 'NONE', emboss: bool | None = None, depress: bool | None = None, translate: bool | None = None):
    kwargs: dict[str, Any] = {}
    if text is not None:
        kwargs['text'] = text
    if translate is not None:
        kwargs['translate'] = bool(translate)
    kwargs = _with_icon_kwargs(kwargs, icon_name, fallback_icon)
    if emboss is not None and not _should_keep_default_emboss(kwargs, emboss):
        kwargs['emboss'] = bool(emboss)
    if depress is not None:
        kwargs['depress'] = bool(depress)
    try:
        return layout.operator(operator_id, **kwargs)
    except Exception:
        return layout.operator(operator_id, **_without_icon_keywords(kwargs))


def prop(layout, data: Any, prop_name: str, *, text: str | None = '', icon_name: str = '', fallback_icon: str = 'NONE', **kwargs):
    # Do not pass stale/invalid RNA pointers to Blender's UI C API.  In fast
    # selection-clear and mode-switch sequences Blender can keep a UI panel
    # alive for one more redraw while the data block it referenced is gone.
    if layout is None or not prop_name or not _is_live_rna(data):
        return None
    try:
        if not hasattr(data, prop_name):
            return None
    except ReferenceError:
        return None
    except Exception:
        pass
    call_kwargs = dict(kwargs)
    if text is not None:
        call_kwargs['text'] = text
    call_kwargs = _with_icon_kwargs(call_kwargs, icon_name, fallback_icon)
    emboss = call_kwargs.get('emboss', None)
    if _should_keep_default_emboss(call_kwargs, emboss):
        call_kwargs.pop('emboss', None)
    try:
        return layout.prop(data, prop_name, **call_kwargs)
    except Exception:
        try:
            return layout.prop(data, prop_name, **_without_icon_keywords(call_kwargs))
        except Exception:
            return None


def label(layout, *, text: str | None = '', icon_name: str = '', fallback_icon: str = 'NONE') -> None:
    call_kwargs: dict[str, Any] = {}
    if text is not None:
        call_kwargs['text'] = text
    call_kwargs = _with_icon_kwargs(call_kwargs, icon_name, fallback_icon)
    try:
        layout.label(**call_kwargs)
    except Exception:
        try:
            layout.label(**_without_icon_keywords(call_kwargs))
        except Exception:
            pass


def large_icon_button_row(layout, *, align: bool = True, scale_y: float = 1.18):
    row = layout.row(align=align)
    try:
        row.scale_y = float(scale_y)
    except Exception:
        pass
    return row
