# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

"""Catalog for Smart Modifier user-facing subtools.

This centralizes menu labels, icons, priorities, and beginner-friendly localized
tooltip guidance for migrated modifier-style tools.
The modifier stack UI itself remains unchanged; this file only enriches the
User menu and keeps thin subtool wrappers manageable.
"""
from __future__ import annotations 

from .context_checks import get_plugin_context_blockers ,summarize_blockers 
from .translation import choose_text ,pgettext_iface ,ui_language 

def _e (label ,operator_id ,icon ,priority ,description_en ,description_ja ,usage_en ,usage_ja ):
    return {
    "label":label ,
    "operator_id":operator_id ,
    "icon":icon ,
    "priority":int (priority ),
    "description_en":description_en .strip (),
    "description_ja":description_ja .strip (),
    "usage_en":usage_en .strip (),
    "usage_ja":usage_ja .strip (),
    }


PLUGIN_CATALOG ={
# Existing migrated wrappers
"boolean_stack_modifier":_e (
'Boolean Stack Modifier',
"sms.smart_boolean_stack",
"MOD_BOOLEAN",
110 ,
"Build a non-destructive hard-surface boolean stack on the active mesh using the other selected meshes as cutters. Good for blockouts, panel cuts, kitbash carving, and upper-compatible Boxcutter / Hard Ops style workflows.",
"他の選択メッシュをカッターとして使い、アクティブメッシュへ非破壊のハードサーフェス用ブーリアンスタックを構築します。ブロックアウト、パネルカット、キットバッシュ削り出し、Boxcutter / Hard Ops 系の上位互換ワークフロー向けです。",
"Select the target mesh as active, select one or more cutter meshes, then run this in Object Mode.",
"オブジェクトモードで、ターゲットメッシュをアクティブにし、カッターにするメッシュを1つ以上選択して実行します。",
),
"smart_cleanup_repair_tool":_e (
'Quick Repair / Cleanup',
"sms.smart_cleanup_repair",
"TOOL_SETTINGS",
105 ,
"Run the Smart Modifier Hub style cleanup pass directly from Add Modifier. It merges doubles, removes loose and degenerate geometry, optionally fills holes, optionally joins triangles, and can recalculate normals for a safer imported-asset recovery pass.",
"Smart Modifier Hub 系のクリーンアップを『モディファイアを追加』から直接実行します。重複頂点の結合、ルーズ / 退化ジオメトリ除去、必要に応じた穴埋め、三角面結合、法線再計算を行い、インポート資産の安全な回復処理に使えます。",
"Select one or more mesh objects, then run it in Object Mode or Edit Mesh when you want a quick conservative repair pass using the Hub cleanup settings.",
"Hub のクリーンアップ設定を使って保守的な修復を素早く行いたい時に、1つ以上のメッシュを選択してオブジェクトモードまたは編集メッシュで実行します。",
),
"curve_modifier":_e (
'Curve Modifier',
"smsp.selected_edges_to_curve",
"CURVE_DATA",
101 ,
"Convert selected mesh edges into reusable curve splines for pipes, sweeps, trim routing, and path extraction workflows.",
"選択メッシュの辺を、パイプ、スイープ、トリム配線、パス抽出に再利用できるカーブスプラインへ変換します。",
"In Edit Mode, select the edge path(s) you want to convert, then run the tool.",
"編集モードで変換したい辺パスを選択して実行します。",
),
"path_modifier":_e (
'Path Modifier',
"smsp.selected_objects_to_path",
"CURVE_PATH",
99 ,
"Create a curve path from the world-space origins of the selected objects. Useful for layout guides, trajectory splines, and reusable path generation.",
"選択オブジェクトのワールド座標原点からカーブパスを作成します。レイアウトガイド、軌跡スプライン、再利用可能なパス生成に便利です。",
"Select objects in the order or layout you want, keep the most important object active, then run the tool in Object Mode.",
"パス化したいレイアウトでオブジェクトを選択し、重要なオブジェクトをアクティブにした状態でオブジェクトモードから実行します。",
),
"vertices_path_modifier":_e (
'Vertices Path Modifier',
"smsp.selected_vertices_to_path",
"CURVE_PATH",
98 ,
"Create a curve path directly from selected edit-mesh vertices. Useful for strip routing, sweep preparation, and 3ds Max style path extraction.",
"選択した編集メッシュ頂点から直接カーブパスを作成します。帯状配線、スイープ準備、3ds Max 風のパス抽出に便利です。",
"In Edit Mode, select the vertices that define the route, then run the tool.",
"編集モードでルートを定義する頂点を選択して実行します。",
),
"pipe_modifier":_e (
'Pipe Modifier',
"sms.smart_pipe_from_selection",
"META_CAPSULE",
104 ,
"Turn a selected edge path into a beveled curve pipe for cables, hoses, rails, and trim workflows.",
"選択した辺パスを、ケーブル、ホース、レール、トリム向けのベベル付きカーブパイプへ変換します。",
"Either select mesh edges in Edit Mode and create a new pipe, or select an existing curve in Object Mode to update its pipe settings.",
"編集モードでメッシュ辺を選んで新しいパイプを作るか、オブジェクトモードで既存カーブを選んでパイプ設定を更新します。",
),
"array_along_curve_modifier":_e (
'Array Along Curve Modifier',
"sms.smart_array_along_curve",
"MOD_ARRAY",
102 ,
"Create an Array + Curve modifier stack on the active mesh using the selected curve as the path. Useful for rails, trims, facade repetition, and modular detail passes.",
"選択カーブをパスとして、アクティブメッシュへ Array + Curve モディファイア構成を作成します。レール、トリム、ファサード反復、モジュラーなディテール配置に便利です。",
"Select one mesh and one curve together, keep the mesh active, then run it in Object Mode.",
"メッシュ1つとカーブ1つを同時に選択し、メッシュをアクティブにしてオブジェクトモードで実行します。",
),
"instances_along_path_modifier":_e (
'Instances Along Path Modifier',
"smsp.instances_along_path",
"DUPLICATE",
97 ,
"Place linked copies of the selected source objects along an active curve path using even sampling and optional tangent following.",
"均等サンプリングと必要に応じた接線追従を使って、選択ソースのリンクコピーをアクティブカーブに沿って配置します。",
"Select one or more source objects plus a target curve, make the curve active, then run the tool.",
"ソースにするオブジェクトを1つ以上とターゲットカーブを選択し、カーブをアクティブにして実行します。",
),
"loft_modifier":_e (
'Loft Modifier',
"smsp.loft_bridge_paths",
"SURFACE_NCURVE",
100 ,
"Build a loft mesh between two paths or edge strips for strip surfaces, trims, patching, and spline bridge style workflows.",
"2本のパスまたは辺ストリップの間にロフトメッシュを作成します。帯面生成、トリム、パッチング、スプライン橋渡し系ワークフロー向けです。",
"Use two selected curve objects in Object Mode, or exactly two selected edge paths in Edit Mode.",
"オブジェクトモードではカーブ2本、編集モードではちょうど2本の選択辺パスを使います。",
),
"sweep_modifier":_e (
'Sweep Modifier',
"smsp.sweep_active_profile",
"SURFACE_NCURVE",
100 ,
"Use a selected profile curve as a bevel object for the active path curve. Great for moldings, cable trays, trim profiles, and CAD-like sweep modeling.",
"選択した断面カーブを、アクティブなパスカーブのベベル断面として使います。モール、ケーブルトレイ、トリム断面、CADライクなスイープ向けです。",
"Select a path curve and a profile curve together, keep the path active, then run the tool in Object Mode.",
"パスカーブと断面カーブを同時に選択し、パスをアクティブにしてオブジェクトモードで実行します。",
),
"profile_primitive_modifier":_e (
'Profile Primitive Modifier',
"smsp.add_profile_primitive",
"MESH_CIRCLE",
96 ,
"Create a reusable 2D curve profile at the 3D cursor for sweep, molding, rail section, and CAD-style profile workflows.",
"3Dカーソル位置に、スイープ、モール、レール断面、CAD風断面ワークフロー向けの再利用可能な2Dカーブ断面を作成します。",
"Run it in Object Mode, then use the created profile with Sweep Active Profile or other curve-based tools.",
"オブジェクトモードで実行し、生成された断面を Sweep Active Profile などのカーブ系ツールで使用します。",
),
"helix_path_modifier":_e (
'Helix Path Modifier',
"smsp.add_helix_path",
"CURVE_DATA",
95 ,
"Create a helix / spiral guide curve for springs, wrapped cables, spiral trims, and path-driven arrays.",
"バネ、巻き付きケーブル、螺旋トリム、パス駆動配列向けのヘリックス / スパイラルガイドカーブを作成します。",
"Run it in Object Mode at the 3D cursor, then use the resulting curve in sweep or array workflows.",
"オブジェクトモードで3Dカーソル位置に作成し、その後スイープや配列ワークフローで使います。",
),
"projection_modifier":_e (
'Projection Modifier',
"smsp.project_to_selected_surface",
"SNAP_FACE",
94 ,
"Project the selected vertices of the active mesh onto another selected surface mesh. Useful for retopo strips, surface wrapping, and panel placement.",
"アクティブメッシュの選択頂点を、別の選択サーフェスメッシュへ投影します。リトポストリップ、面への追従、パネル配置に便利です。",
"Select the source mesh and a target surface mesh together, keep the source active, go to Edit Mode on the source, select vertices, then run the tool.",
"ソースメッシュとターゲット面メッシュを同時に選択し、ソースをアクティブにして編集モードへ入り、頂点を選択して実行します。",
),
"conform_to_surface_tool":_e (
'Conform To Surface',
"sms.conform_to_surface",
"MOD_SHRINKWRAP",
92 ,
"Run the Smart Modifier Hub style surface-conform setup directly from Add Modifier. It adds or refreshes shrinkwrap-based conform modifiers on the selected detail meshes so they follow the active surface, with optional parenting and helper collection organization.",
"Smart Modifier Hub 系の面追従セットアップを『モディファイアを追加』から直接実行します。選択ディテールメッシュへ Shrinkwrap ベースの追従モディファイアを追加 / 更新し、必要に応じて親子付けやヘルパーコレクション整理も行います。",
"Select one active surface mesh and one or more detail meshes in Object Mode, then run it when you want the Hub conform workflow instead of the compact precision conform helper.",
"オブジェクトモードで、追従先サーフェスをアクティブにし、1つ以上のディテールメッシュを選択して実行します。コンパクトな Precision 側ではなく Hub 方式の追従ワークフローを使いたい時に向いています。",
),
"floor_modifier":_e (
'Floor Modifier',
"sms.floor_generator",
"MESH_GRID",
89 ,
"Generate a procedural floorboard mesh inside the active footprint for archviz, decking, parquet, and pattern blockouts.",
"アクティブオブジェクトの足元形状内に、建築ビジュアライゼーション、デッキ、寄木、パターンブロックアウト向けのフロア板メッシュを生成します。",
"Select a mesh object that defines the footprint, then run the tool in Object Mode and adjust board settings in the panel as needed.",
"フットプリントを定義するメッシュを選択し、オブジェクトモードで実行します。必要に応じてパネル内で板設定を調整します。",
),
"replace_modifier":_e (
'Replace Modifier',
"smsp.replace_with_active",
"ARROW_LEFTRIGHT",
88 ,
"Replace selected targets with copies of the active object while preserving each target transform. Useful for proxy swaps and kitbash replacements.",
"各ターゲットの変形を保ったまま、選択ターゲットをアクティブオブジェクトのコピーへ置換します。プロキシ置換やキットバッシュ差し替えに便利です。",
"Keep the source object active, select the targets you want to replace, then run the tool in Object Mode.",
"元にするオブジェクトをアクティブにし、置換したいターゲットを選択してオブジェクトモードで実行します。",
),
"randomize_modifier":_e (
'Randomize Modifier',
"smsp.randomize_selected",
"RNDCURVE",
87 ,
"Apply controlled random translation, rotation, and uniform scale variation to selected objects for faster layout iteration.",
"選択オブジェクトへ制御可能なランダム移動、回転、均一スケール変化を適用し、レイアウト反復を高速化します。",
"Select objects in Object Mode, run the tool, then fine-tune the random ranges in the panel or redo settings.",
"オブジェクトモードで対象を選択して実行し、必要に応じてパネルや再実行設定でランダム幅を調整します。",
),
"edit_poly":_e (
'Edit Polygon',
"ep.add_layer",
"MESH_DATA",
84 ,
"Add a stack-managed Edit Polygon layer that behaves like a dedicated editable polygon level inside Smart Modifier. Use it when you want Max-style per-layer polygon editing while keeping higher modifiers live above the current edit level.",
"Smart Modifier 内で専用の編集ポリゴンレベルとして扱える、スタック管理付き編集ポリゴンレイヤーを追加します。上位モディファイアを残したまま 3ds Max 風の段階編集をしたい時に使います。",
"Use Object Mode or Edit Mesh on the active mesh object, then run Edit Polygon to insert an editable layer into the stack.",
"オブジェクトモードまたは編集メッシュでアクティブメッシュを対象に実行し、スタックへ編集ポリゴンレイヤーを挿入します。",
),
"smart_lattice":_e (
'Smart Lattice',
"smart_lattice.add_layer",
"MOD_LATTICE",
83 ,
"Add a stack-managed Smart Lattice layer that creates a fitted lattice cage and keeps its settings editable from the modifier stack. This is the higher-level FFD style option for broad silhouette work, cage-based shaping, and 3ds Max inspired free-form deformation workflows.",
"フィット済みラティスケージを作成し、設定をモディファイアスタックから管理できる Smart Lattice レイヤーを追加します。大きなシルエット調整、ケージベースの変形、3ds Max 風のフリーフォーム変形ワークフロー向けの上位 FFD オプションです。",
"Select a mesh in Object Mode or stay in Edit Mesh on the target object, then run the tool to add a stack-managed lattice helper layer.",
"オブジェクトモードでメッシュを選択するか、対象オブジェクトの編集メッシュのまま実行して、スタック管理されるラティス補助レイヤーを追加します。",
),
"mesh_auto_mirror_modifier":_e (
'Mesh Auto Mirror',
"smsm.mesh_auto_mirror_modifier",
"MOD_MIRROR",
107 ,
"Bisect the active mesh, weld the center line, and add a Mirror modifier in one guided step for fast symmetry setup inside Smart Modifier.",
"アクティブメッシュを切断して中央線を揃えた後、Mirror モディファイアを1手順で追加し、Smart Modifier 内で素早く対称化を開始できます。",
"Use Object Mode or Edit Mesh on the active mesh object, then run Mesh Auto Mirror from the User tab to create a stack-managed symmetry setup.",
"アクティブメッシュのオブジェクトモードまたは編集メッシュで、ユーザータブの Mesh Auto Mirror を実行して、スタック管理された対称セットアップを追加します。",
),
"reset_xform_modifier":_e (
'Reset XForm',
"smsm.reset_xform_modifier",
"MOD_NODES",
106 ,
"Move the selected object rotation and scale into a generated XForm-style Geometry Nodes modifier, then reset the object rotation to 0 and scale to 1 while preserving the visible result. This mirrors the 3ds Max Reset XForm workflow inside the Smart Modifier stack.",
"選択オブジェクトの回転とスケールを生成済みの XForm 風 Geometry Nodes モディファイアへ移し、見た目を維持したままオブジェクト側の回転を 0、スケールを 1 に戻します。3ds Max の Reset XForm ワークフローを Smart Modifier のスタック内で再現します。",
"Select one or more mesh objects in Object Mode or Edit Mesh, then run it from Add Modifier > User > Transform / XForm. The generated Reset XForm modifier can be moved, disabled, deleted, or applied like other stack entries.",
"オブジェクトモードまたは編集メッシュでメッシュオブジェクトを1つ以上選択し、モディファイアを追加 > ユーザー > Transform / XForm から実行します。生成された Reset XForm モディファイアは、他のスタック項目と同様に移動・無効化・削除・適用できます。",
),
"unwrap_uvw_modifier":_e (
'Unwrap UVW',
"smsm.unwrap_uvw_modifier",
"UV",
104 ,
"Create a stack-managed Unwrap UVW entry for assigning, rebuilding, packing, and manually editing UV map coordinates. It exposes angle-based, conformal, smart flatten, quick planar, box, cylindrical, spherical, and pack workflows through the modifier stack.",
"UVマップ座標の割り当て、再生成、パック、手動編集を行うスタック管理式の Unwrap UVW 項目を作成します。角度ベース、コンフォーマル、スマート展開、クイック平面、ボックス、円柱、球、パックのワークフローをモディファイアスタックから扱えます。",
"Select one or more mesh objects in Object Mode or Edit Mesh, then run it from Add Modifier > User > UV / Mapping. Use Edit / Rebuild on the modifier row to regenerate UVs, and use Blender's UV Editor for hand editing of UV vertices, edges, faces, seams, and islands.",
"オブジェクトモードまたは編集メッシュでメッシュオブジェクトを1つ以上選択し、モディファイアを追加 > ユーザー > UV / Mapping から実行します。モディファイア行の「編集 / 再生成」でUVを再生成し、UV頂点・辺・面・シーム・アイランドの手動編集は Blender のUVエディターで行います。",
),
"uvw_map_modifier":_e (
'UVW Map',
"smsm.uvw_map_modifier",
"GROUP_UVS",
105 ,
"Generate a non-destructive Smart Connect UVW planar projection driven by an Empty gizmo. Moving, rotating, scaling, or animating the gizmo updates the UVMap attribute through Geometry Nodes.",
"Emptyギズモで制御する非破壊のSmart Connect UVW平面投影を生成します。ギズモの移動・回転・スケール・アニメーションにGeometry Nodes側のUVMap属性が追従します。",
"Select one or more mesh objects, run Add Modifier > User > UV / Mapping > UVW Map, then transform the Smart_Connect_UVW_Gizmo Empty to control the planar UV projection.",
"メッシュオブジェクトを1つ以上選択し、モディファイアを追加 > ユーザー > UV / Mapping > UVWマップを実行します。Smart_Connect_UVW_Gizmo Emptyを変形して平面UV投影を制御します。",
),
"scatter_modifier":_e (
'Scatter Modifier',
"sms.scatter_instances_bake",
"PARTICLES",
79 ,
"Scatter linked instances over the active surface for vegetation, debris, kitbash dressing, and environment blocking.",
"アクティブ面上へリンクインスタンスを散布し、植生、デブリ、キットバッシュ装飾、環境ブロッキングに使えます。",
"Select one surface object and one or more source objects, keep the surface active, then run it in Object Mode.",
"サーフェス1つとソースオブジェクトを1つ以上選び、サーフェスをアクティブにしてオブジェクトモードで実行します。",
),

# New wrapper coverage added in this patch
"fill_modifier":_e (
'Smart Fill Modifier',
"sms.smart_fill_topology",
"MESH_GRID",
105 ,
"Fill and repair open boundaries with a grid-first fallback chain. Useful for F2-style face creation, quad patching, caps, and day-to-day topology repair.",
"グリッド優先のフォールバック連鎖で開いた境界を面張り・修復します。F2 風の面作成、四角パッチ、キャップ、日常的なトポロジー修復に便利です。",
"In Edit Mode, select the edge boundary or loops you want to patch, then run the tool.",
"編集モードで埋めたい境界エッジやループを選択して実行します。",
),
"relax_selection_tool":_e (
'Relax Selection',
"sms.relax_selection",
"MOD_SMOOTH",
91 ,
"Run the edit-mode selection relax helper from Add Modifier. It smooths the current component selection in-place for quick manual cleanup when you need a direct edit instead of a stack-based Smooth modifier.",
"編集モード用の選択リラックス補助を『モディファイアを追加』から実行します。スタック型 Smooth モディファイアではなく、現在の要素選択をその場で直接ならしたい時の手早い整理向けです。",
"In Edit Mode, select the vertices you want to relax, then run the tool for a direct one-shot relax pass.",
"編集モードでリラックスしたい頂点を選択し、直接実行型のワンショット Relax として使います。",
),
"straighten_modifier":_e (
'Straighten Modifier',
"sms.straighten_selection",
"EMPTY_ARROWS",
90 ,
"Project selected vertices onto their best straight line for Align Edges / Unbend style cleanup.",
"選択頂点を最適な直線へ投影し、Align Edges / Unbend 系の整理を行います。",
"In Edit Mode, select the vertices you want to straighten, then run the tool.",
"編集モードで直線化したい頂点を選択して実行します。",
),
"circle_modifier":_e (
'Circle Modifier',
"sms.circle_selection",
"MESH_CIRCLE",
89 ,
"Fit the current selection to a circular shape using LoopTools when available, or Blender's To Sphere as a fallback.",
"LoopTools が利用可能ならそれを優先し、無い場合は Blender の To Sphere を使って現在の選択を円形へ整えます。",
"In Edit Mode, select a ring or vertex loop that should become circular, then run the tool.",
"編集モードで円形にしたいリングや頂点ループを選択して実行します。",
),
"extrude_modifier":_e (
'Smart Extrude Modifier',
"smsa.smart_extrude_clean",
"MESH_DATA",
103 ,
"Run a compact inset + extrude helper for QMesh / Smart Extrude style face modeling without leaving Blender's native workflow.",
"Blender ネイティブの流れのまま、QMesh / Smart Extrude 風の面モデリングを行うコンパクトな inset + extrude 補助です。",
"In Edit Mode, select faces, then run the tool and adjust inset / extrude values in the redo panel.",
"編集モードで面を選択して実行し、再実行パネルで inset / extrude 値を調整します。",
),
"slice_panel_modifier":_e (
'Slice Panel Modifier',
"smsa.slice_panel_stack",
"MOD_BOOLEAN",
102 ,
"Generate evenly spaced boolean helper boxes for panel lines, grooves, slot cuts, and layered contour details.",
"パネルライン、溝、スロット切削、段差ディテール向けに、等間隔のブーリアン補助ボックスを生成します。",
"Select the target mesh in Object Mode and run the tool, then adjust spacing and count in the redo panel.",
"オブジェクトモードで対象メッシュを選んで実行し、再実行パネルで間隔や数を調整します。",
),
"surface_box_detail_modifier":_e (
'Surface Box Detail Modifier',
"smsa.surface_box_detail",
"MESH_DATA",
101 ,
"Create a face-aligned detail box for panel blocks, floating details, and quick boolean helpers on hard-surface models.",
"面に揃ったディテールボックスを作成し、パネルブロック、浮かせたディテール、簡易ブーリアン補助に使えます。",
"In Edit Mode, keep a target face active and run the tool to spawn a detail object aligned to that surface.",
"編集モードでターゲット面をアクティブにし、その面へ揃ったディテールオブジェクトを生成します。",
),
"axis_slice_modifier":_e (
'Axis Slice Modifier',
"smsp.axis_slice_edit",
"MOD_MULTIRES",
85 ,
"Insert one or more evenly spaced local-axis slice cuts through the active edit mesh. Useful for SliceIt XYZ / Slicer style numeric cuts, panel segmentation, contour preparation, and fast guide edges.",
"アクティブな編集メッシュへ、ローカル軸に沿った等間隔のスライスカットを1本以上挿入します。SliceIt XYZ / Slicer 系の数値カット、パネル分割、輪郭準備、ガイドエッジ作成に便利です。",
"Enter Edit Mode on a mesh, choose the slice axis and count in the Precision panel, optionally restrict the bounds with a selection, then run the tool.",
"メッシュの編集モードで、Precision パネルから軸と本数を選び、必要なら選択範囲で対象範囲を絞って実行します。",
),
"workplane_modifier":_e (
'Workplane Modifier',
"smsp.workplane_from_active",
"EMPTY_ARROWS",
96 ,
"Build a cursor-based local workplane from the active face or edge for Modo-style angled-surface editing.",
"アクティブ面または辺からカーソル基準のローカル作業平面を作成し、Modo 風の傾いた面編集をしやすくします。",
"Use Edit Mode, make a face or edge active, then run the tool before moving / rotating / scaling on a local surface orientation.",
"編集モードで面または辺をアクティブにし、ローカルな面方向で移動・回転・拡縮する前に実行します。",
),
"cad_intersect_modifier":_e (
'CAD Intersect Modifier',
"smsp.cad_intersect_extend",
"MESH_GRID",
95 ,
"Resolve two selected edges by intersection or extension for tinyCAD-style precision editing.",
"選択した2本の辺を交差または延長で解決し、tinyCAD 風の精密編集を行います。",
"In Edit Mode, select exactly two edges that should meet, then run the tool and choose the desired method.",
"編集モードで交わらせたい辺をちょうど2本選び、実行後に方法を選択します。",
),
"face_component_array_modifier":_e (
'Face Component Array Modifier',
"smsp.face_component_array",
"DUPLICATE",
94 ,
"Duplicate the active object onto the faces of the other selected meshes for paneling, tiles, vents, and Tissue-like repetition.",
"アクティブオブジェクトを、他の選択メッシュの面上へ複製配置します。パネル貼り、タイル、通気孔、Tissue 風の反復に使えます。",
"Select one source object and one or more target meshes, keep the source active, then run it in Object Mode.",
"ソースオブジェクト1つとターゲットメッシュを1つ以上選び、ソースをアクティブにしてオブジェクトモードで実行します。",
),
"rebuild_curve_modifier":_e (
'Rebuild Curve Modifier',
"smsp.rebuild_active_curve",
"CURVE_DATA",
93 ,
"Resample the active curve into cleaner, evenly spaced points for better sweep, pipe, and path-array results.",
"アクティブカーブを、より均一でクリーンな点配置へ再サンプリングし、スイープ、パイプ、パス配列の結果を安定させます。",
"Select a curve object in Object Mode and run it before downstream pipe, sweep, or path-instancing tools.",
"オブジェクトモードでカーブを選択し、後段のパイプ、スイープ、パス配置ツールの前に実行します。",
),
"project_to_active_plane_modifier":_e (
'Project To Active Plane Modifier',
"smsp.project_to_active_plane",
"EMPTY_ARROWS",
92 ,
"Project selected vertices onto the active face plane with an optional offset for CAD-like flattening, panel alignment, and precise repair work.",
"選択頂点を、必要に応じたオフセット付きでアクティブ面の平面へ投影します。CAD ライクな平坦化、パネル整列、精密な修復作業に便利です。",
"In Edit Mode, keep one face active, select the vertices to flatten or align, then run the tool.",
"編集モードで1枚の面をアクティブにし、平坦化や整列したい頂点を選択して実行します。",
),
"audit_select_issues_modifier":_e (
'Audit Select Issues',
"smsp.audit_select_issues",
"VIEWZOOM",
105 ,
"Select a specific problem class from the mesh audit on the active edit mesh so you can inspect, isolate, and repair only the failing elements.",
"アクティブな編集メッシュ上で、メッシュ監査の特定問題種別だけを選択し、問題要素を確認・切り分け・修復しやすくします。",
"Run Audit Selected first if needed, pick the issue filter in the Precision panel, then use this tool in Edit Mode to highlight the matching components.",
"必要なら先に Audit Selected を実行し、Precision パネルで問題フィルターを選んでから、編集モードでこのツールを使って該当コンポーネントを強調表示します。",
),
"audit_selected_modifier":_e (
'Audit Selected Modifier',
"smsp.audit_selected",
"CHECKMARK",
89 ,
"Run a read-only mesh audit on the active or selected mesh objects and summarize common production risks such as non-manifold edges, loose elements, ngons, degenerates, and double candidates.",
"アクティブまたは選択したメッシュへ読み取り専用の監査を実行し、非多様体辺、ルーズ要素、Nゴン、縮退、重複候補など、制作で問題になりやすい項目を要約します。",
"Select one or more mesh objects and run it before cleanup, export, printing, or final review.",
"1つ以上のメッシュを選択し、クリーンアップ前、書き出し前、3Dプリント前、最終確認前に実行します。",
),
"detach_separate_clean_modifier":_e (
'Detach Separate Clean Modifier',
"sms.detach_separate_clean",
"MESH_DATA",
88 ,
"Separate the current component selection into a clean new object with optional duplicate-first behavior, inspired by Maya detachSeparate style workflows.",
"現在の要素選択を、必要なら複製を挟みつつクリーンな新規オブジェクトへ分離します。Maya の detachSeparate 系ワークフロー向けです。",
"In Edit Mode, select the components to detach, then run the tool and adjust duplicate/cleanup options in the redo panel.",
"編集モードで分離したい要素を選択し、実行後に再実行パネルで複製やクリーンアップ設定を調整します。",
),

"pivot_to_selection_modifier":_e (
'Pivot To Selection Modifier',
"smsp.pivot_to_selection",
"PIVOT_CURSOR",
58 ,
"Move the active mesh object's origin to the center of the current edit selection without changing the visible shape. Useful for local bend / twist control, kitbash pivots, and temporary action-center style edits.",
"アクティブメッシュオブジェクトの原点を、見た目の形状を変えずに現在の編集選択の中心へ移動します。ローカルな Bend / Twist 制御、キットバッシュのピボット調整、一時的な Action Center 的編集に便利です。",
"Enter Edit Mesh mode on the active mesh, select one or more vertices / edges / faces, then run the tool.",
"アクティブメッシュで編集メッシュモードに入り、1つ以上の頂点 / 辺 / 面を選択して実行します。",
),
"pivot_to_bottom_modifier":_e (
'Pivot To Bottom Modifier',
"smsp.pivot_to_bottom",
"TRIA_DOWN",
57 ,
"Move each selected object's origin to the world-space bottom center of its bounds without changing the visible shape. Useful for layout, DropIt-style dressing, stacking, and easier floor placement.",
"各選択オブジェクトの原点を、見た目の形状を変えずにワールド空間での境界ボックス下端中央へ移動します。レイアウト、DropIt 風の配置、積み重ね、床置き作業をしやすくする用途に便利です。",
"Select one or more objects in Object Mode and run the tool to prepare cleaner placement pivots.",
"オブジェクトモードで1つ以上のオブジェクトを選択し、配置しやすいピボットへ整えるために実行します。",
),
"drop_to_floor_modifier":_e (
'Drop To Floor Modifier',
"smsp.drop_to_floor",
"TRIA_DOWN",
56 ,
"Drop the selected objects vertically so their world-space bounds sit on a shared floor height. Useful for DropToFloor style layout cleanup, shelf dressing, and zero-target placement prep.",
"選択オブジェクトを垂直移動し、ワールド空間の境界ボックス下端が共通の床高さへ接するようにします。DropToFloor 風のレイアウト整理、棚配置、ターゲット不要の設置準備に便利です。",
"Select one or more objects in Object Mode, choose a floor height or enable 3D Cursor Z, then run the tool.",
"オブジェクトモードで1つ以上のオブジェクトを選択し、床高さを指定するか 3D カーソルZ を有効にして実行します。",
),
"align_to_active_modifier":_e (
'Align To Active Modifier',
"smsp.align_to_active",
"ORIENTATION_GLOBAL",
55 ,
"Align the selected objects to the active object using per-channel toggles for location, rotation, and scale. Useful for 3ds Max style align workflows, layout cleanup, and archviz placement passes.",
"位置・回転・スケールの各チャンネル切替を使って、選択オブジェクトをアクティブオブジェクトへ整列します。3ds Max 風の Align ワークフロー、レイアウト整理、Archviz の配置調整に便利です。",
"In Object Mode, make the reference object active, select one or more targets, choose the channels and axes, then run the tool.",
"オブジェクトモードで基準オブジェクトをアクティブにし、ターゲットを1つ以上選択して、反映するチャンネルと軸を指定して実行します。",
),
"distribute_selected_modifier":_e (
'Distribute Selected Modifier',
"smsp.distribute_selected_axis",
"MOD_ARRAY",
54 ,
"Evenly distribute selected object origins between the current minimum and maximum positions on the chosen world axis. Useful for shelf dressing, facade spacing, modular blocking, and quick layout cleanup.",
"選択したワールド軸上の現在の最小位置と最大位置の間で、選択オブジェクト原点を均等配置します。棚配置、ファサード間隔調整、モジュラーなブロックアウト、素早いレイアウト整理に便利です。",
"In Object Mode, select at least three objects, choose the axis, then run the tool to preserve the endpoints and even out the spacing between them.",
"オブジェクトモードで少なくとも3つのオブジェクトを選択し、軸を指定して実行すると、端点を保ったまま間隔を均等化します。",
),
"stack_selected_modifier":_e (
'Stack Selected Modifier',
"smsp.stack_selected",
"ALIGN_JUSTIFY",
53 ,
"Stack selected objects one after another along the chosen world axis using their world-space bounds plus a configurable gap. Useful for shelf dressing, prop lineup, packing previews, and quick contact-free layout stacking.",
"選択オブジェクトを、指定ワールド軸上でワールド空間の境界ボックスと設定ギャップを使って順番に接触配置します。棚配置、小物の整列、梱包プレビュー、素早い非接触スタック配置に便利です。",
"In Object Mode, select at least two objects, choose the axis and gap, then run the tool to pack them one after another based on their real bounds.",
"オブジェクトモードで少なくとも2つのオブジェクトを選択し、軸とギャップを指定して実行すると、実際の境界ボックスに基づいて順番に詰めて配置します。",
),
"quad_checker_modifier":_e (
'Quad Checker Modifier',
"smsp.quad_checker",
"FACESEL",
87 ,
"Select quads, non-quads, triangles, or ngons on the active edit mesh for fast topology inspection before subdivision, export, bevel, or retopo cleanup.",
"アクティブな編集メッシュ上で、クアッド、非クアッド、三角形、Nゴンを素早く選択し、サブディビジョン、書き出し、ベベル、リトポ整理前のトポロジー確認を行います。",
"Enter Edit Mesh mode on the active mesh, choose a Quad Filter in the Precision panel, optionally limit it to selected faces, then run the tool.",
"アクティブメッシュで編集メッシュモードに入り、Precision パネルでクアッドフィルターを選び、必要なら選択面のみに限定して実行します。",
),
"solo_selected_modifier":_e (
'Solo Selected Modifier',
"smsp.toggle_solo_selected",
"HIDE_OFF",
85 ,
"Temporarily isolate the current selection for focused modeling, then restore the previous scene visibility when run again. Great for MagicSolo-style concentration workflows.",
"現在の選択だけを一時的に隔離表示し、再実行で以前の表示状態へ戻します。MagicSolo 風の集中作業ワークフローに便利です。",
"Select the objects you want to focus on in Object Mode, run it once to isolate them, then run it again to restore visibility.",
"オブジェクトモードで集中したい対象を選択し、1回目で隔離、2回目で表示を復帰します。",
),
"drop_to_surface_modifier":_e (
'Drop To Surface Modifier',
"smsa.drop_to_surface",
"SNAP_FACE",
84 ,
"Drop selected objects onto the active surface along world -Z with optional normal alignment. Useful for DropIt-style layout work.",
"選択オブジェクトをワールド -Z 方向でアクティブ面へ落とし、必要に応じて法線へ整列させます。DropIt 風の配置作業に便利です。",
"Select one or more objects plus a destination surface, keep the surface active, then run the tool in Object Mode.",
"1つ以上のオブジェクトと配置先サーフェスを選び、サーフェスをアクティブにしてオブジェクトモードで実行します。",
),
"combine_join_clean_modifier":_e (
'Combine Join Clean Modifier',
"smsa.combine_join_clean",
"MESH_DATA",
83 ,
"Join selected meshes while keeping the active object's origin as the owner, then optionally run a light cleanup pass.",
"選択メッシュを結合しつつ、アクティブオブジェクトの原点を保持し、必要に応じて軽いクリーンアップを行います。",
"Select two or more mesh objects, keep the pivot owner active, then run the tool in Object Mode.",
"2つ以上のメッシュを選択し、原点を保持したいオブジェクトをアクティブにしてオブジェクトモードで実行します。",
),
}


try:
    from .max_modifier_definitions import catalog_entry_for_definition as _max_catalog_entry_for_definition, iter_max_modifier_definitions as _iter_max_modifier_definitions
    for _max_def in _iter_max_modifier_definitions():
        try:
            PLUGIN_CATALOG.setdefault(str(_max_def.get('plugin_id') or ''), _max_catalog_entry_for_definition(_max_def))
        except Exception:
            pass
except Exception:
    pass

STACK_ADDABLE_PLUGIN_IDS =set (PLUGIN_CATALOG .keys ())

NATIVE_STACK_ADDABLE_PLUGIN_IDS ={
"edit_poly",
"smart_lattice",
}

NATIVE_MODELING_SIDE_PLUGIN_IDS =set ()

# Canonical Max-compatible variants expose these legacy implementations through
# functional Add Modifier workflow categories.  Legacy entries remain available
# for delegate execution and stack matching, but are hidden from stack-add menus.
MAX_CANONICAL_ONLY_PLUGIN_IDS ={
"reset_xform_modifier",
"unwrap_uvw_modifier",
"ffd_modifier",
"symmetry_modifier",
"relax_modifier",
"cast_modifier",
"extrude_modifier",
"projection_modifier",
"normal_transfer_modifier",
"surface_conform_modifier",
}


def is_stack_addable_plugin (*,plugin_id :str |None =None ,operator_id :str |None =None ,plugin_meta :dict |None =None )->bool :
    meta =plugin_meta if isinstance (plugin_meta ,dict )else None 
    pid =""
    op_id =""
    if isinstance (meta ,dict ):
        pid =str (meta .get ("id")or meta .get ("plugin_id")or plugin_id or "").strip ()
        op_id =str (meta .get ("operator_id")or operator_id or "").strip ()
        if pid in MAX_CANONICAL_ONLY_PLUGIN_IDS :
            return False 
        if "stack_addable"in meta :
            try :
                return bool (meta .get ("stack_addable"))
            except Exception :
                pass 
    else :
        pid =str (plugin_id or "").strip ()
        op_id =str (operator_id or "").strip ()
    if not pid and op_id :
        for _pid ,_meta in PLUGIN_CATALOG .items ():
            try :
                if str (_meta .get ("operator_id")or "").strip ()==op_id :
                    pid =str (_pid )
                    break 
            except Exception :
                continue 
    if pid in MAX_CANONICAL_ONLY_PLUGIN_IDS :
        return False 
    if pid in NATIVE_STACK_ADDABLE_PLUGIN_IDS :
        return True 
    if pid in NATIVE_MODELING_SIDE_PLUGIN_IDS :
        return False 
    return pid in STACK_ADDABLE_PLUGIN_IDS 


def is_modeling_side_plugin (*,plugin_id :str |None =None ,operator_id :str |None =None ,plugin_meta :dict |None =None )->bool :
    return not is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =operator_id ,plugin_meta =plugin_meta )

PLUGIN_GROUPS ={
"boolean_stack_modifier":"hard_surface",
"slice_panel_modifier":"hard_surface",
"surface_box_detail_modifier":"hard_surface",
"extrude_modifier":"hard_surface",
"mesh_auto_mirror_modifier":"precision_symmetry",
"fill_modifier":"topology_repair",
"smart_cleanup_repair_tool":"topology_repair",
"relax_selection_tool":"topology_repair",
"straighten_modifier":"topology_repair",
"circle_modifier":"topology_repair",
"detach_separate_clean_modifier":"topology_repair",
"audit_selected_modifier":"topology_repair",
"audit_select_issues_modifier":"topology_repair",
"quad_checker_modifier":"topology_repair",
"curve_modifier":"curves_paths",
"path_modifier":"curves_paths",
"vertices_path_modifier":"curves_paths",
"pipe_modifier":"curves_paths",
"array_along_curve_modifier":"curves_paths",
"instances_along_path_modifier":"curves_paths",
"loft_modifier":"curves_paths",
"sweep_modifier":"curves_paths",
"profile_primitive_modifier":"curves_paths",
"helix_path_modifier":"curves_paths",
"rebuild_curve_modifier":"curves_paths",
"projection_modifier":"surface_projection",
"conform_to_surface_tool":"surface_projection",
"drop_to_surface_modifier":"surface_projection",
"workplane_modifier":"precision_cad",
"cad_intersect_modifier":"precision_cad",
"axis_slice_modifier":"precision_cad",
"project_to_active_plane_modifier":"precision_cad",
"reset_xform_modifier":"transform_xform",
"edit_poly":"edit_selection",
"smart_lattice":"deform_ffd",
"uvw_map_modifier":"uv_mapping",
"unwrap_uvw_modifier":"uv_mapping",
"scatter_modifier":"layout_scatter",
"floor_modifier":"layout_scatter",
"replace_modifier":"layout_scatter",
"randomize_modifier":"layout_scatter",
"pivot_to_selection_modifier":"layout_scatter",
"pivot_to_bottom_modifier":"layout_scatter",
"drop_to_floor_modifier":"layout_scatter",
"align_to_active_modifier":"layout_scatter",
"distribute_selected_modifier":"layout_scatter",
"stack_selected_modifier":"layout_scatter",
"face_component_array_modifier":"layout_scatter",
"combine_join_clean_modifier":"generate_geometry",
"solo_selected_modifier":"layout_scatter",
}

GROUP_META ={
"hard_surface":{
"label":'Hard Surface / Boolean',
"icon":"MOD_BOOLEAN",
"priority":100 ,
},
"topology_repair":{
"label":'Topology / Repair',
"icon":"MOD_REMESH",
"priority":95 ,
},
"edit_selection":{
"label":'Edit / Selection',
"icon":"EDITMODE_HLT",
"priority":92 ,
},
"transform_xform":{
"label":'Transform / XForm',
"icon":"EMPTY_ARROWS",
"priority":90 ,
},
"deform_ffd":{
"label":'Deform / FFD / Shape',
"icon":"MOD_SIMPLEDEFORM",
"priority":88 ,
},
"generate_geometry":{
"label":'Generate / Geometry',
"icon":"MESH_CUBE",
"priority":86 ,
},
"precision_symmetry":{
"label":'Precision / Symmetry',
"icon":"MOD_MIRROR",
"priority":84 ,
},
"curves_paths":{
"label":'Curves / Path / Sweep',
"icon":"CURVE_DATA",
"priority":82 ,
},
"surface_projection":{
"label":'Surface / Projection / Conform',
"icon":"MOD_SHRINKWRAP",
"priority":80 ,
},
"subdivision":{
"label":'Subdivision / Smoothing',
"icon":"MOD_SUBSURF",
"priority":76 ,
},
"normals_shading":{
"label":'Normals / Shading',
"icon":"MOD_NORMALEDIT",
"priority":74 ,
},
"uv_mapping":{
"label":'UV / Mapping',
"icon":"GROUP_UVS",
"priority":72 ,
},
"precision_cad":{
"label":'CAD / Workplane',
"icon":"ORIENTATION_CURSOR",
"priority":70 ,
},
"layout_scatter":{
"label":'Layout / Scatter / Placement',
"icon":"OUTLINER_COLLECTION",
"priority":64 ,
},
"rigging_skin":{
"label":'Rigging / Skin',
"icon":"ARMATURE_DATA",
"priority":58 ,
},
"simulation_physics":{
"label":'Simulation / Physics',
"icon":"PHYSICS",
"priority":54 ,
},
"animation_cache":{
"label":'Animation / Cache',
"icon":"TIME",
"priority":50 ,
},
"materials_attributes":{
"label":'Materials / Attributes',
"icon":"MATERIAL",
"priority":46 ,
},
"world_space":{
"label":'World Space / WSM',
"icon":"WORLD",
"priority":42 ,
},
"space_warp":{
"label":'Space Warp / Binding',
"icon":"FORCE_FORCE",
"priority":38 ,
},
"compatibility_utilities":{
"label":'Compatibility / Utility',
"icon":"TOOL_SETTINGS",
"priority":34 ,
},
"other":{
"label":'Other',
"icon":"TOOL_SETTINGS",
"priority":0 ,
},
}



def _augment_plugin_meta (meta :dict |None ):
    if not isinstance (meta ,dict ):
        return None 
    out =dict (meta )
    plugin_id =out .get ("id")or out .get ("plugin_id")or ""
    group_id =out .get ("group")or PLUGIN_GROUPS .get (plugin_id )or "other"
    group_meta =GROUP_META .get (group_id ,GROUP_META ["other"])
    out ["group"]=group_id 
    out .setdefault ("group_label",group_meta ["label"])
    out .setdefault ("group_icon",group_meta ["icon"])
    out .setdefault ("group_priority",int (group_meta ["priority"]))
    out ["stack_addable"]=is_stack_addable_plugin (plugin_id =plugin_id ,operator_id =out .get ("operator_id"),plugin_meta =out )
    out ["modeling_side"]=not bool (out ["stack_addable"])
    return out 


def get_plugin_group_label (group_id :str )->str :
    return pgettext_iface (str (GROUP_META .get (group_id ,GROUP_META ["other"])["label"]))


def get_plugin_group_icon (group_id :str )->str :
    return str (GROUP_META .get (group_id ,GROUP_META ["other"])["icon"])


def iter_plugins_grouped (plugins ):
    grouped ={}
    for plugin in plugins or []:
        meta =_augment_plugin_meta (plugin )
        if not isinstance (meta ,dict ):
            continue 
        grouped .setdefault (meta .get ("group","other"),[]).append (meta )
    ordered_groups =sorted (
    grouped .keys (),
    key =lambda gid :int (GROUP_META .get (gid ,GROUP_META ["other"]).get ("priority",0 )),
    reverse =True ,
    )
    return [(gid ,grouped [gid ])for gid in ordered_groups ]


def get_plugin_meta (plugin_id :str |None =None ,operator_id :str |None =None ):
    if plugin_id and plugin_id in PLUGIN_CATALOG :
        return _augment_plugin_meta (dict (PLUGIN_CATALOG [plugin_id ],id =plugin_id ))
    if operator_id :
        for pid ,meta in PLUGIN_CATALOG .items ():
            if meta .get ("operator_id")==operator_id :
                return _augment_plugin_meta (dict (meta ,id =pid ))
    return None 



PLUGIN_SHORT_HINTS ={
"boolean_stack_modifier":{"en":"Object Mode · active mesh + 1+ cutter meshes","ja":"オブジェクトモード・アクティブメッシュ + 1個以上のカッターメッシュ"},
"smart_cleanup_repair_tool":{"en":"Object Mode or Edit Mesh · 1+ mesh objects","ja":"オブジェクトモードまたは編集メッシュ・1個以上のメッシュ"},
"curve_modifier":{"en":"Edit Mesh · selected edges","ja":"編集メッシュ・選択辺"},
"path_modifier":{"en":"Object Mode · 2+ selected objects","ja":"オブジェクトモード・2個以上の選択オブジェクト"},
"vertices_path_modifier":{"en":"Edit Mesh · selected vertices","ja":"編集メッシュ・選択頂点"},
"pipe_modifier":{"en":"Edit Mesh · selected edges, or Object Mode · active curve","ja":"編集メッシュ・選択辺、またはオブジェクトモード・アクティブカーブ"},
"array_along_curve_modifier":{"en":"Object Mode · active mesh + selected curve","ja":"オブジェクトモード・アクティブメッシュ + 選択カーブ"},
"instances_along_path_modifier":{"en":"Object Mode · active curve + 1+ source objects","ja":"オブジェクトモード・アクティブカーブ + 1個以上のソースオブジェクト"},
"loft_modifier":{"en":"Object Mode · 2 curves, or Edit Mesh · 2 edge paths","ja":"オブジェクトモード・2本のカーブ、または編集メッシュ・2本の辺パス"},
"sweep_modifier":{"en":"Object Mode · active path curve + 1 profile curve","ja":"オブジェクトモード・アクティブパスカーブ + 1本の断面カーブ"},
"profile_primitive_modifier":{"en":"Object Mode · 3D cursor position","ja":"オブジェクトモード・3Dカーソル位置"},
"helix_path_modifier":{"en":"Object Mode · 3D cursor position","ja":"オブジェクトモード・3Dカーソル位置"},
"projection_modifier":{"en":"Edit Mesh · selected vertices + target surface mesh","ja":"編集メッシュ・選択頂点 + ターゲットサーフェスメッシュ"},
"conform_to_surface_tool":{"en":"Object Mode · active surface mesh + 1+ detail meshes","ja":"オブジェクトモード・アクティブ面メッシュ + 1個以上のディテールメッシュ"},
"floor_modifier":{"en":"Object Mode · active mesh footprint","ja":"オブジェクトモード・アクティブメッシュのフットプリント"},
"replace_modifier":{"en":"Object Mode · active source object + target objects","ja":"オブジェクトモード・アクティブ元オブジェクト + ターゲットオブジェクト"},
"randomize_modifier":{"en":"Object Mode · selected objects","ja":"オブジェクトモード・選択オブジェクト"},
"pivot_to_selection_modifier":{"en":"Edit Mesh · active mesh + selected components","ja":"編集メッシュ・アクティブメッシュ + 選択要素"},
"pivot_to_bottom_modifier":{"en":"Object Mode · 1+ selected objects","ja":"オブジェクトモード・1個以上の選択オブジェクト"},
"drop_to_floor_modifier":{"en":"Object Mode · 1+ selected objects","ja":"オブジェクトモード・1個以上の選択オブジェクト"},
"align_to_active_modifier":{"en":"Object Mode · active source + 1+ target objects","ja":"オブジェクトモード・アクティブ基準 + 1個以上のターゲット"},
"distribute_selected_modifier":{"en":"Object Mode · 3+ selected objects","ja":"オブジェクトモード・3個以上の選択オブジェクト"},
"stack_selected_modifier":{"en":"Object Mode · 2+ selected objects","ja":"オブジェクトモード・2個以上の選択オブジェクト"},
"quad_checker_modifier":{"en":"Edit Mesh · active mesh (optional face subset)","ja":"編集メッシュ・アクティブメッシュ（必要なら選択面のみ）"},
"edit_poly":{"en":"Object Mode or Edit Mesh · active mesh","ja":"オブジェクトモードまたは編集メッシュ・アクティブメッシュ"},
"smart_lattice":{"en":"Object Mode or Edit Mesh · active mesh","ja":"オブジェクトモードまたは編集メッシュ・アクティブメッシュ"},
"mesh_auto_mirror_modifier":{"en":"Object Mode or Edit Mesh · active mesh","ja":"オブジェクトモードまたは編集メッシュ・アクティブメッシュ"},
"reset_xform_modifier":{"en":"Object Mode or Edit Mesh · 1+ selected mesh objects","ja":"オブジェクトモードまたは編集メッシュ・1個以上の選択メッシュ"},
"unwrap_uvw_modifier":{"en":"Object Mode or Edit Mesh · 1+ selected mesh objects","ja":"オブジェクトモードまたは編集メッシュ・1個以上の選択メッシュ"},
"uvw_map_modifier":{"en":"Object Mode or Edit Mesh · 1+ selected mesh objects","ja":"オブジェクトモードまたは編集メッシュ・1個以上の選択メッシュ"},
"relax_selection_tool":{"en":"Edit Mesh · selected vertices","ja":"編集メッシュ・選択頂点"},
"scatter_modifier":{"en":"Object Mode · active surface + 1+ source objects","ja":"オブジェクトモード・アクティブ面 + 1個以上のソースオブジェクト"},
"fill_modifier":{"en":"Edit Mesh · open border or useful selection","ja":"編集メッシュ・開いた境界または有効な選択"},
"straighten_modifier":{"en":"Edit Mesh · selected vertices or edges","ja":"編集メッシュ・選択頂点または辺"},
"circle_modifier":{"en":"Edit Mesh · selected vertices","ja":"編集メッシュ・選択頂点"},
"extrude_modifier":{"en":"Edit Mesh · selected faces","ja":"編集メッシュ・選択フェース"},
"slice_panel_modifier":{"en":"Object Mode · active mesh","ja":"オブジェクトモード・アクティブメッシュ"},
"surface_box_detail_modifier":{"en":"Edit Mesh · active face on the target mesh","ja":"編集メッシュ・ターゲットメッシュのアクティブフェース"},
"axis_slice_modifier":{"en":"Edit Mesh · active mesh","ja":"編集メッシュ・アクティブメッシュ"},
"workplane_modifier":{"en":"Object or Edit Mesh · active mesh / face / edge","ja":"オブジェクトまたは編集メッシュ・アクティブメッシュ / フェース / 辺"},
"cad_intersect_modifier":{"en":"Edit Mesh · exactly 2 selected edges","ja":"編集メッシュ・ちょうど2本の選択辺"},
"face_component_array_modifier":{"en":"Object Mode · active component mesh + target meshes","ja":"オブジェクトモード・アクティブ部品メッシュ + ターゲットメッシュ"},
"rebuild_curve_modifier":{"en":"Object Mode · active curve","ja":"オブジェクトモード・アクティブカーブ"},
"project_to_active_plane_modifier":{"en":"Edit Mesh · active face or selected edge","ja":"編集メッシュ・アクティブフェースまたは選択辺"},
"audit_select_issues_modifier":{"en":"Active mesh object","ja":"アクティブメッシュ"},
"audit_selected_modifier":{"en":"Active mesh object","ja":"アクティブメッシュ"},
"detach_separate_clean_modifier":{"en":"Edit Mesh · selected components","ja":"編集メッシュ・選択コンポーネント"},
"solo_selected_modifier":{"en":"Object Mode · selected objects","ja":"オブジェクトモード・選択オブジェクト"},
"drop_to_surface_modifier":{"en":"Object Mode · movable objects + surface target","ja":"オブジェクトモード・移動するオブジェクト + サーフェスターゲット"},
"combine_join_clean_modifier":{"en":"Object Mode · 2+ selected mesh objects","ja":"オブジェクトモード・2個以上の選択メッシュ"},
}



try:
    from .max_modifier_definitions import iter_max_modifier_definitions as _iter_max_hint_defs, short_hint_for_definition as _max_short_hint_for_definition
    for _max_def in _iter_max_hint_defs():
        try:
            PLUGIN_SHORT_HINTS.setdefault(str(_max_def.get('plugin_id') or ''), _max_short_hint_for_definition(_max_def))
        except Exception:
            pass
except Exception:
    pass

def get_plugin_short_hint (plugin_id :str |None =None ,operator_id :str |None =None ,lang :str |None =None )->str :
    meta =get_plugin_meta (plugin_id =plugin_id ,operator_id =operator_id )
    if not isinstance (meta ,dict ):
        return ""
    pid =meta .get ("id")or plugin_id or ""
    hint =PLUGIN_SHORT_HINTS .get (pid )
    if not isinstance (hint ,dict ):
        return ""
    resolved_lang =str (lang or '').strip ().lower ()or ui_language ()
    en =str (hint .get ("en","")).strip ()
    ja =str (hint .get ("ja","")).strip ()
    return ja if resolved_lang =='ja'and ja else en or ja 


def build_bilingual_tooltip (meta :dict |None ,fallback_label :str ="",context =None )->str :
    if not isinstance (meta ,dict ):
        return pgettext_iface (fallback_label or 'Run the selected Smart Modifier user tool.',context =context )
    lang =ui_language (context )
    label =pgettext_iface (meta .get ("label")or fallback_label or 'Smart Modifier Tool',context =context )
    lines =[str (label )]
    desc =choose_text (meta .get ("description_en"),meta .get ("description_ja"),context =context )
    usage =choose_text (meta .get ("usage_en"),meta .get ("usage_ja"),context =context )
    pid =meta .get ("id")
    op_id =meta .get ("operator_id")
    hint =get_plugin_short_hint (plugin_id =pid ,operator_id =op_id ,lang =lang )
    blockers =get_plugin_context_blockers (context ,plugin_id =pid )if context is not None else []
    blocker_text =summarize_blockers (blockers ,lang =lang ,limit =3 )if blockers else ''
    if desc :
        lines .append ("")
        lines .append (str (desc ))
    if hint :
        lines .append (f"{choose_text ('Context','前提',context =context )}: {hint }")
    if usage :
        lines .append (f"{choose_text ('Use','使い方',context =context )}: {usage }")
    if blocker_text :
        lines .append (f"{choose_text ('Current blockers','現在の不足条件',context =context )}: {blocker_text }")
    return "\n".join (lines ).strip ()
