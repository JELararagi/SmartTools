# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Use English translations for the Japanese defaults outside Japanese UI."""

from contextlib import suppress

import bpy


def _payload():
    from .locale_fallback_data import JA_EN

    locales = {"en_US", *(locale for locale in bpy.app.translations.locales
                           if not str(locale).startswith("ja"))}
    index = {(context, text): english for context in ("*", "Operator")
             for text, english in JA_EN.items()}
    return dict.fromkeys(locales, index)


def _clear():
    with suppress(Exception):
        bpy.app.translations.unregister(__name__)


def wrap(enable, disable):
    def register(*args, **kwargs):
        outcome = enable(*args, **kwargs)
        _clear()
        bpy.app.translations.register(__name__, _payload())
        return outcome

    def unregister(*args, **kwargs):
        _clear()
        return disable(*args, **kwargs)

    return register, unregister
