# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""One persistent Blender handler per event list for the whole suite.

Every part of the suite (stack runtime, bundled subtools, save guards) used to
append its own callbacks to ``load_pre`` / ``load_post`` / ``save_pre`` /
``undo_post`` / ``redo_post``.  They now register here instead, and this module
owns exactly one persistent dispatcher per Blender list.  The callbacks run in
registration order, each isolated from the failures of the others.

The Undo / Redo dispatchers are added to Blender only while at least one
callback is registered, so a session that never needs them pays nothing on Undo.
"""
from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

_SUITE_ID = 'smart_modifier_suite'
_SUITE_LABEL = 'Smart Modifier Suite'

_REGISTRY: dict[str, list] = {
    'load_pre': [],
    'load_post': [],
    'save_pre': [],
    'undo_post': [],
    'redo_post': [],
}
_WARNED: set = set()


def _warn_once(key, exc):
    """Report a failing callback once per key."""
    if key not in _WARNED:
        _WARNED.add(key)
        print(f"[Smart Modifier] {key}: {exc}")


def _announce(list_name, fn, args):
    try:
        from . import status_runtime
        status_runtime.announce_handler_callback(_SUITE_ID, _SUITE_LABEL, list_name, fn, args)
    except Exception:
        pass


_NPARAMS: dict = {}


def _fit_args(fn, args):
    """Blender passes a different number of arguments per Blender version; give fn only what it accepts."""
    n = _NPARAMS.get(fn)
    if n is None:
        n = -1
        try:
            import inspect
            params = list(inspect.signature(fn).parameters.values())
            if not any(p.kind == p.VAR_POSITIONAL for p in params):
                n = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])
        except Exception:
            n = -1
        _NPARAMS[fn] = n
    return args if n < 0 else args[:n]


def _run(list_name, args, announce):
    for fn in tuple(_REGISTRY[list_name]):
        if announce:
            _announce(list_name, fn, args)
        try:
            fn(*_fit_args(fn, args))
        except Exception as exc:
            _warn_once(f"{list_name}:{getattr(fn, '__name__', 'callback')}", exc)


@persistent
def _dispatch_load_pre(*args):
    _run('load_pre', args, True)


@persistent
def _dispatch_load_post(*args):
    _run('load_post', args, True)


@persistent
def _dispatch_save_pre(*args):
    _run('save_pre', args, True)


@persistent
def _dispatch_undo_post(*args):
    _run('undo_post', args, False)


@persistent
def _dispatch_redo_post(*args):
    _run('redo_post', args, False)


_DISPATCHERS = {
    'load_pre': _dispatch_load_pre,
    'load_post': _dispatch_load_post,
    'save_pre': _dispatch_save_pre,
    'undo_post': _dispatch_undo_post,
    'redo_post': _dispatch_redo_post,
}

for _fn in _DISPATCHERS.values():
    _fn._smsm_event_hub = True
    # The dispatcher reports each callback itself; no companion status marker.
    _fn._jelararagi_status_self_reported_v3 = True
del _fn


def _sequence(list_name):
    return getattr(bpy.app.handlers, list_name, None)


def _attach(list_name):
    seq = _sequence(list_name)
    if seq is None:
        return
    fn = _DISPATCHERS[list_name]
    if fn not in seq:
        seq.append(fn)


def _detach(list_name):
    seq = _sequence(list_name)
    if seq is None:
        return
    fn = _DISPATCHERS[list_name]
    while fn in seq:
        seq.remove(fn)


def add(list_name, fn):
    """Register ``fn`` for ``list_name`` (idempotent)."""
    items = _REGISTRY[list_name]
    if fn not in items:
        items.append(fn)
    _attach(list_name)


def remove(list_name, fn):
    """Unregister ``fn``; the Blender dispatcher goes away with the last callback."""
    items = _REGISTRY[list_name]
    while fn in items:
        items.remove(fn)
    if not items:
        _detach(list_name)


def has(list_name, fn):
    return fn in _REGISTRY[list_name]


def shutdown():
    """Remove every dispatcher and forget every callback (package unregister)."""
    for list_name, items in _REGISTRY.items():
        del items[:]
        _detach(list_name)
