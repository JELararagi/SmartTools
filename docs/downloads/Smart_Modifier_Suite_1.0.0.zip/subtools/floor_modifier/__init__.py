# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for floor_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "floor_modifier"
PLUGIN_LABEL = "Floor Modifier"
OPERATOR_ID = "sms.floor_generator"
PLUGIN_ICON = "MESH_GRID"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
