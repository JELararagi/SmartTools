# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for randomize_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "randomize_modifier"
PLUGIN_LABEL = "Randomize Modifier"
OPERATOR_ID = "smsp.randomize_selected"
PLUGIN_ICON = "RNDCURVE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
