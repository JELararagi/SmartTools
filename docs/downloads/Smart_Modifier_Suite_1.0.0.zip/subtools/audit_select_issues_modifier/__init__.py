# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for audit_select_issues_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "audit_select_issues_modifier"
PLUGIN_LABEL = "Audit Select Issues"
OPERATOR_ID = "smsp.audit_select_issues"
PLUGIN_ICON = "VIEWZOOM"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
