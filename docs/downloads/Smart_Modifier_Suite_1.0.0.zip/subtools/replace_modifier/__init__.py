# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for replace_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "replace_modifier"
PLUGIN_LABEL = "Replace Modifier"
OPERATOR_ID = "smsp.replace_with_active"
PLUGIN_ICON = "ARROW_LEFTRIGHT"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
