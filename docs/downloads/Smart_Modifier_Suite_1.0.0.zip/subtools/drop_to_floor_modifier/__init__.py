# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for drop_to_floor_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "drop_to_floor_modifier"
PLUGIN_LABEL = "Drop To Floor Modifier"
OPERATOR_ID = "smsp.drop_to_floor"
PLUGIN_ICON = "TRIA_DOWN"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
