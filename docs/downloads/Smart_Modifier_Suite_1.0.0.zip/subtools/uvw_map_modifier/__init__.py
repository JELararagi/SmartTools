# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================
from __future__ import annotations

import bpy
from bpy.props import StringProperty
from bpy.types import Operator
from mathutils import Vector

from ...translation import choose_text

try:
    from ...icons import icon_value as _sms_icon_value, operator as _sms_icon_operator
except Exception:
    def _sms_icon_value(name=None, fallback=None):
        return 0
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs = {'text': text}
        if fallback_icon and fallback_icon != 'NONE':
            kwargs['icon'] = fallback_icon
        if emboss is not None:
            kwargs['emboss'] = emboss
        if depress is not None:
            kwargs['depress'] = depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None)
            kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)

try:
    from ...help_button import draw_help_header
except Exception:
    def draw_help_header(layout, context, label, icon, help_id, **kwargs):
        try:
            layout.label(text=choose_text(label, label, context=context), icon='GROUP_UVS')
        except Exception:
            pass

from ...core import (
    ms_register_plugin, ms_unregister_plugin, get_main_object,
    ms_next_logical_name_from_base, ms_obj_set_disp_name, ms_set_ui_active_index,
    safe_move_modifier, ms_calc_target_insert_index, set_mod_enabled_state,
    set_mod_viewport_state, ms_apply_state_post_action, ms_group_modifiers_as_instance,
    ms_is_instance_modifier, ms_get_instance_id, ms_iter_instance_members,
    ms_is_shape_mesh_proxy,
)
from ..uv_stack_common import (
    capture_selection, restore_selection, ensure_object_mode, restore_mode,
    selected_mesh_targets, socket_by_name,
)

PLUGIN_ID = 'uvw_map_modifier'
OP_ID = 'smsm.uvw_map_modifier'
EDIT_ID = 'smsm.uvw_map_edit_modifier'
RESTORE_ID = 'smsm.uvw_map_restore_backup'
LABEL = 'UVW Map'
ICON = 'GROUP_UVS'
MARKER = '_smsm_uvw_map_modifier'
PREFIX = 'smsm_uvw_map_'

UVW_GIZMO_TARGET_PROP = 'smsm_uvw_target'
UVW_GIZMO_MODIFIER_PROP = 'smsm_uvw_modifier'
UVW_GIZMO_NAME_PROP = 'smsm_uvw_gizmo_name'
UVW_GIZMO_SOCKET_PROP = 'smsm_uvw_gizmo_socket'
UVW_NODE_GROUP_PROP = 'smsm_uvw_node_group'
UVW_HELPER_PROP = 'smsm_uvw_helper'
UVW_PROXY_OWNER_PROP = 'smsm_uvw_proxy_owner'
UVW_UV_NAME_PROP = 'smsm_uvw_uv_name'
UVW_COLLECTION_NAME = 'UVWmap_Collection'
DEFAULT_UV_NAME = 'UVMap'
MODIFIER_BASE_NAME = 'Smart Connect UVW'
NODE_GROUP_PREFIX = 'Smart Connect UVW'
GIZMO_BASE_NAME = 'Smart_Connect_UVW_Gizmo'


def _safe_name(value: str, fallback: str = 'Object') -> str:
    text = str(value or '').strip()
    return text if text else fallback


def _unique_name(base: str, collection) -> str:
    used = {str(getattr(x, 'name', '') or '') for x in (collection or [])}
    base = _safe_name(base, 'Smart Connect UVW')
    if base not in used:
        return base
    for i in range(1, 10000):
        name = f'{base}.{i:03d}'
        if name not in used:
            return name
    return base


def _add_interface_socket(group, name: str, in_out: str, socket_type: str, description: str = ''):
    try:
        sock = group.interface.new_socket(name=str(name), in_out=str(in_out), socket_type=str(socket_type))
        if description:
            try:
                sock.description = str(description)
            except Exception:
                pass
        return sock
    except Exception:
        pass
    try:
        sockets = group.inputs if str(in_out).upper() == 'INPUT' else group.outputs
        return sockets.new(str(socket_type), str(name))
    except Exception:
        return None


def _set_socket_default(sock, value):
    if sock is None:
        return False
    try:
        sock.default_value = value
        return True
    except Exception:
        return False


def _link(group, out_socket, in_socket) -> bool:
    if group is None or out_socket is None or in_socket is None:
        return False
    try:
        group.links.new(out_socket, in_socket)
        return True
    except Exception:
        return False


def _new_node(group, node_type: str, loc=(0, 0), label: str = ''):
    try:
        node = group.nodes.new(node_type)
        node.location = loc
        if label:
            try:
                node.label = label
            except Exception:
                pass
        return node
    except Exception:
        return None


def _modifier_socket_id(group, prop_name: str, *names: str) -> str:
    if group is None:
        return ''
    try:
        sid = str(group.get(prop_name, '') or '')
        if sid:
            return sid
    except Exception:
        pass
    try:
        items = list(getattr(group.interface, 'items_tree', []) or [])
        lookup = {str(getattr(x, 'name', '') or ''): x for x in items}
        for name in names:
            item = lookup.get(str(name or ''))
            if item is not None:
                return str(getattr(item, 'identifier', '') or '')
    except Exception:
        pass
    return ''


def _set_modifier_socket_value(mod, socket_id: str, value) -> bool:
    socket_id = str(socket_id or '')
    if mod is None or not socket_id:
        return False
    try:
        mod[socket_id] = value
        return True
    except Exception:
        return False


def _get_or_create_uvw_collection(context=None):
    """Modifier_System_Collection/UVWmap_Collection を取得または作成します。"""
    try:
        scene = getattr(context, 'scene', None) if context is not None else bpy.context.scene
    except Exception:
        scene = None
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is None:
            root = bpy.data.collections.new('Modifier_System_Collection')
        if scene is not None:
            try:
                if root.name not in [c.name for c in scene.collection.children]:
                    scene.collection.children.link(root)
            except Exception:
                pass
        col = bpy.data.collections.get(UVW_COLLECTION_NAME)
        if col is None:
            col = bpy.data.collections.new(UVW_COLLECTION_NAME)
        try:
            if col.name not in [c.name for c in root.children]:
                root.children.link(col)
        except Exception:
            pass
        return col
    except Exception:
        return None


def _link_object_to_uvw_collection(obj, context=None, exclusive: bool = True) -> None:
    if obj is None:
        return
    col = _get_or_create_uvw_collection(context)
    if col is None:
        return
    try:
        if obj.name not in [o.name for o in col.objects]:
            col.objects.link(obj)
    except Exception:
        pass
    if exclusive:
        for other in list(getattr(obj, 'users_collection', []) or []):
            if other == col:
                continue
            try:
                other.objects.unlink(obj)
            except Exception:
                pass


def _collection_is_empty(col) -> bool:
    try:
        if len(col.objects) > 0:
            return False
    except Exception:
        pass
    try:
        if len(col.children) > 0:
            return False
    except Exception:
        pass
    return True


def _cleanup_empty_collections() -> None:
    try:
        col = bpy.data.collections.get(UVW_COLLECTION_NAME)
        if col is not None and _collection_is_empty(col):
            bpy.data.collections.remove(col)
    except Exception:
        pass
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is not None and _collection_is_empty(root):
            bpy.data.collections.remove(root)
    except Exception:
        pass


def _set_helper_visibility(obj, visible: bool) -> None:
    if obj is None:
        return
    try:
        # hide_viewport はアウトライナーの「ビューポートで無効」です。
        # 編集対象オブジェクトの操作不能を避けるため、UVW補助オブジェクトだけ stale 状態を解除します。
        if bool(getattr(obj, 'hide_viewport', False)):
            obj.hide_viewport = False
    except Exception:
        pass
    try:
        obj.hide_set(not bool(visible))
    except Exception:
        pass
    if bool(visible):
        try:
            if bool(obj.get(UVW_HELPER_PROP, False)) or bool(obj.get(UVW_PROXY_OWNER_PROP, False)):
                obj.hide_select = False
        except Exception:
            pass


def _bounds_center_world(obj) -> Vector:
    try:
        pts = [obj.matrix_world @ Vector(corner) for corner in getattr(obj, 'bound_box', [])]
        if pts:
            acc = Vector((0.0, 0.0, 0.0))
            for p in pts:
                acc += p
            return acc / len(pts)
    except Exception:
        pass
    try:
        return Vector(obj.matrix_world.translation)
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _find_gizmo(obj, modifier_name: str):
    if obj is None:
        return None
    modifier_name = str(modifier_name or '')
    try:
        mod = obj.modifiers.get(modifier_name) if modifier_name else None
        if mod is not None:
            name = str(mod.get(UVW_GIZMO_NAME_PROP, '') or '')
            if name:
                found = bpy.data.objects.get(name)
                if found is not None:
                    return found
    except Exception:
        pass
    for candidate in list(bpy.data.objects):
        try:
            if str(candidate.get(UVW_GIZMO_TARGET_PROP, '') or '') != getattr(obj, 'name', ''):
                continue
            if modifier_name and str(candidate.get(UVW_GIZMO_MODIFIER_PROP, '') or '') != modifier_name:
                continue
            return candidate
        except Exception:
            continue
    return None


def _new_uvw_gizmo(obj, modifier_name: str, context=None):
    """対象メッシュの中心に、UVW投影用のImage Emptyギズモを作成します。"""
    gizmo = bpy.data.objects.new(GIZMO_BASE_NAME, None)
    try:
        gizmo.empty_display_type = 'IMAGE'
    except Exception:
        pass
    try:
        gizmo.empty_display_size = 1.0
    except Exception:
        pass
    try:
        gizmo.location = _bounds_center_world(obj)
    except Exception:
        pass
    try:
        if context is not None and getattr(context, 'collection', None) is not None:
            context.collection.objects.link(gizmo)
        else:
            bpy.context.collection.objects.link(gizmo)
    except Exception:
        try:
            bpy.context.scene.collection.objects.link(gizmo)
        except Exception:
            pass
    try:
        gizmo[UVW_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
        gizmo[UVW_GIZMO_MODIFIER_PROP] = str(modifier_name or '')
        gizmo[UVW_HELPER_PROP] = True
        gizmo['smsm_internal_helper'] = True
    except Exception:
        pass
    _link_object_to_uvw_collection(gizmo, context=context, exclusive=True)
    _set_helper_visibility(gizmo, True)
    return gizmo


UVW_SOCKET_KEYS = ('mapping', 'cap', 'u_tile', 'v_tile', 'flip_u', 'flip_v', 'uv_name')
UVW_SOCKET_PROP_PREFIX = 'smsm_uvw_sock_'
UVW_MAPPING_ITEMS = (
    ('Planar', '平面'), ('Cylindrical', '円柱'), ('Spherical', '球'), ('Shrink Wrap', 'シュリンクラップ'),
    ('Box', 'ボックス'), ('Face', 'フェース'), ('XYZ to UVW', 'XYZ to UVW'),
)
UVW_MAPPING_CYLINDRICAL = 1


def _uvw_socket_ids(group):
    """作った時に控えた入力の識別子を返します（古い平面だけの版では空）。"""
    out = {}
    if group is None:
        return out
    for key in UVW_SOCKET_KEYS:
        try:
            sid = str(group.get(UVW_SOCKET_PROP_PREFIX + key, '') or '')
        except Exception:
            sid = ''
        if sid:
            out[key] = sid
    return out


def _enabled(sockets):
    return [sock for sock in sockets if getattr(sock, 'enabled', True)]


def _make_uvw_node_group(obj, context=None):
    """3ds Max の UVW Map（平面・円柱・球・シュリンクラップ・ボックス・フェース・XYZ to UVW）相当の Geometry Nodes を構築します。"""
    name = _unique_name(f'{NODE_GROUP_PREFIX} - {getattr(obj, "name", "Object")}', bpy.data.node_groups)
    group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    try:
        group.is_modifier = True
    except Exception:
        pass
    try:
        group.nodes.clear()
    except Exception:
        pass

    def ct(en, ja):
        return choose_text(en, ja, context=context)

    # --- モディファイア入力/出力ソケット。Geometry と Gizmo は前の版と同じ順に置きます。 ---
    _add_interface_socket(group, 'Geometry', 'INPUT', 'NodeSocketGeometry', ct('Input mesh geometry.', '入力メッシュジオメトリです。'))
    gizmo_in = _add_interface_socket(group, 'Gizmo', 'INPUT', 'NodeSocketObject', ct('UVW mapping gizmo object. Its location, rotation and scale (length, width, height) place the projection, and it can be animated.', 'UVWマッピング用ギズモです。位置・回転・スケール（長さ・幅・高さ）で投影を決め、アニメーションもできます。'))
    socks = {
        'mapping': _add_interface_socket(group, ct('Mapping', 'マッピング'), 'INPUT', 'NodeSocketMenu', ct('Projection used by the 3ds Max UVW Map: Planar, Cylindrical, Spherical, Shrink Wrap, Box, Face or XYZ to UVW.', '3ds Max の UVW マップと同じ投影方式です。平面・円柱・球・シュリンクラップ・ボックス・フェース・XYZ to UVW から選びます。')),
        'cap': _add_interface_socket(group, ct('Cap', 'キャップ'), 'INPUT', 'NodeSocketBool', ct('Cylindrical only: faces that look along the gizmo Z axis get planar mapping.', '円柱のときだけ、ギズモの Z 軸を向く面に平面の投影を使います。')),
        'u_tile': _add_interface_socket(group, ct('U Tile', 'U タイル'), 'INPUT', 'NodeSocketFloat', ct('Repeats the map along U.', 'U 方向の繰り返し回数です。')),
        'v_tile': _add_interface_socket(group, ct('V Tile', 'V タイル'), 'INPUT', 'NodeSocketFloat', ct('Repeats the map along V.', 'V 方向の繰り返し回数です。')),
        'flip_u': _add_interface_socket(group, ct('Flip U', 'U 反転'), 'INPUT', 'NodeSocketBool', ct('Mirrors the map along U.', 'U 方向に反転します。')),
        'flip_v': _add_interface_socket(group, ct('Flip V', 'V 反転'), 'INPUT', 'NodeSocketBool', ct('Mirrors the map along V.', 'V 方向に反転します。')),
        'uv_name': _add_interface_socket(group, ct('UV Map', 'UV マップ'), 'INPUT', 'NodeSocketString', ct('Name of the UV map to write. It corresponds to the 3ds Max map channel.', '書き込む UV マップの名前です。3ds Max のマップチャンネルに当たります。')),
    }
    _add_interface_socket(group, 'Geometry', 'OUTPUT', 'NodeSocketGeometry', ct('Geometry with the regenerated UV map.', 'UV マップを作り直したジオメトリです。'))
    _set_socket_default(socks['u_tile'], 1.0)
    _set_socket_default(socks['v_tile'], 1.0)
    _set_socket_default(socks['uv_name'], DEFAULT_UV_NAME)
    try:
        group[UVW_GIZMO_SOCKET_PROP] = str(getattr(gizmo_in, 'identifier', '') or '')
        group[UVW_UV_NAME_PROP] = DEFAULT_UV_NAME
        for key, sock in socks.items():
            group[UVW_SOCKET_PROP_PREFIX + key] = str(getattr(sock, 'identifier', '') or '')
    except Exception:
        pass

    def node(node_type, x, y, label=''):
        return _new_node(group, node_type, (x, y), label)

    def feed(sock, value):
        if value is None:
            return
        if isinstance(value, (int, float)):
            _set_socket_default(sock, float(value))
        else:
            _link(group, value, sock)

    def math(op, a=None, b=None, c=None, x=0, y=0):
        n = node('ShaderNodeMath', x, y)
        n.operation = op
        for index, value in enumerate((a, b, c)):
            feed(n.inputs[index], value)
        return n.outputs[0]

    def vmath(op, a=None, b=None, x=0, y=0, value_out=False):
        n = node('ShaderNodeVectorMath', x, y)
        n.operation = op
        for index, value in enumerate((a, b)):
            if value is not None:
                _link(group, value, n.inputs[index])
        return n.outputs[1] if value_out else n.outputs[0]

    def separate(vec, x=0, y=0):
        n = node('ShaderNodeSeparateXYZ', x, y)
        _link(group, vec, n.inputs[0])
        return n.outputs[0], n.outputs[1], n.outputs[2]

    def combine(u, v, x=0, y=0):
        n = node('ShaderNodeCombineXYZ', x, y)
        feed(n.inputs[0], u)
        feed(n.inputs[1], v)
        return n.outputs[0]

    def on_face(value, data_type='FLOAT', x=0, y=0):
        n = node('GeometryNodeFieldOnDomain', x, y)
        n.domain = 'FACE'
        n.data_type = data_type
        _link(group, value, _enabled(n.inputs)[0])
        return _enabled(n.outputs)[0]

    def compare(op, a, b, x=0, y=0):
        n = node('FunctionNodeCompare', x, y)
        n.data_type = 'FLOAT'
        n.operation = op
        ins = _enabled(n.inputs)
        feed(ins[0], a)
        feed(ins[1], b)
        return n.outputs[0]

    def boolean(op, a, b=None, x=0, y=0):
        n = node('FunctionNodeBooleanMath', x, y)
        n.operation = op
        _link(group, a, n.inputs[0])
        if b is not None:
            _link(group, b, n.inputs[1])
        return n.outputs[0]

    def switch(cond, if_false, if_true, x=0, y=0):
        n = node('GeometryNodeSwitch', x, y)
        n.input_type = 'VECTOR'
        ins = _enabled(n.inputs)
        _link(group, cond, ins[0])
        _link(group, if_false, ins[1])
        _link(group, if_true, ins[2])
        return _enabled(n.outputs)[0]

    group_input = node('NodeGroupInput', -1800, 0, 'Group Input')
    group_output = node('NodeGroupOutput', 1500, 0, 'Group Output')
    try:
        group_output.is_active_output = True
    except Exception:
        pass

    def gin(key, fallback):
        sock = socks.get(key)
        ident = str(getattr(sock, 'identifier', '') or '')
        for out in group_input.outputs:
            if ident and str(getattr(out, 'identifier', '')) == ident:
                return out
        return socket_by_name(group_input.outputs, (fallback,), 0)

    store = node('GeometryNodeStoreNamedAttribute', 1300, 0, 'Store UVMap')
    store.data_type = 'FLOAT2'
    store.domain = 'CORNER'
    _set_socket_default(socket_by_name(store.inputs, ('Name',), 2), DEFAULT_UV_NAME)
    _set_socket_default(socket_by_name(store.inputs, ('Selection',), 1), True)
    _link(group, socket_by_name(group_input.outputs, ('Geometry',), 0), socket_by_name(store.inputs, ('Geometry',), 0))
    _link(group, socket_by_name(store.outputs, ('Geometry',), 0), socket_by_name(group_output.inputs, ('Geometry',), 0))
    _link(group, gin('uv_name', 'UV Map'), socket_by_name(store.inputs, ('Name',), 2))

    # --- 入力メッシュの座標をギズモ空間へ：M = inverse(ギズモの行列) × 自分の行列 ---
    # 親の非一様スケールと子の回転が作るせん断を失わないよう、分解せず完全な行列で扱います。
    position = node('GeometryNodeInputPosition', -1800, -300, 'Position')
    self_obj = node('GeometryNodeSelfObject', -1800, -500, 'Self Object')
    self_info = node('GeometryNodeObjectInfo', -1600, -500, 'Object Info: Self')
    gizmo_info = node('GeometryNodeObjectInfo', -1600, -150, 'Object Info: Gizmo')
    _link(group, socket_by_name(self_obj.outputs, ('Self Object',), 0), socket_by_name(self_info.inputs, ('Object',), 0))
    _link(group, socket_by_name(group_input.outputs, ('Gizmo',), 1), socket_by_name(gizmo_info.inputs, ('Object',), 0))
    inverse_gizmo = node('FunctionNodeInvertMatrix', -1400, -150, 'Inverse Gizmo Transform')
    _link(group, socket_by_name(gizmo_info.outputs, ('Transform',), 0), socket_by_name(inverse_gizmo.inputs, ('Matrix',), 0))
    to_gizmo = node('FunctionNodeMatrixMultiply', -1200, -300, 'Object to Gizmo')
    _link(group, socket_by_name(inverse_gizmo.outputs, ('Matrix',), 0), to_gizmo.inputs[0])
    _link(group, socket_by_name(self_info.outputs, ('Transform',), 0), to_gizmo.inputs[1])
    gizmo_point = node('FunctionNodeTransformPoint', -1000, -300, 'Position to Gizmo')
    _link(group, socket_by_name(position.outputs, ('Position',), 0), socket_by_name(gizmo_point.inputs, ('Vector',), 0))
    _link(group, to_gizmo.outputs[0], socket_by_name(gizmo_point.inputs, ('Transform',), 1))
    px, py, pz = separate(socket_by_name(gizmo_point.outputs, ('Vector',), 0), -800, -300)

    # --- 面の法線をギズモ空間へ（法線の行列＝逆行列の転置）。ボックスとキャップで使います。 ---
    normal = node('GeometryNodeInputNormal', -1400, -800, 'Normal')
    face_normal = on_face(socket_by_name(normal.outputs, ('Normal',), 0), 'FLOAT_VECTOR', -1200, -800)
    inverse_m = node('FunctionNodeInvertMatrix', -1000, -650, 'Inverse Object to Gizmo')
    _link(group, to_gizmo.outputs[0], socket_by_name(inverse_m.inputs, ('Matrix',), 0))
    normal_matrix = node('FunctionNodeTransposeMatrix', -850, -650, 'Normal Matrix')
    _link(group, socket_by_name(inverse_m.outputs, ('Matrix',), 0), normal_matrix.inputs[0])
    gizmo_dir = node('FunctionNodeTransformDirection', -700, -800, 'Normal to Gizmo')
    _link(group, face_normal, socket_by_name(gizmo_dir.inputs, ('Direction',), 0))
    _link(group, normal_matrix.outputs[0], socket_by_name(gizmo_dir.inputs, ('Transform',), 1))
    nx, ny, nz = separate(vmath('NORMALIZE', socket_by_name(gizmo_dir.outputs, ('Direction',), 0), x=-550, y=-800), -400, -800)
    ax, ay, az = math('ABSOLUTE', nx, x=-250, y=-750), math('ABSOLUTE', ny, x=-250, y=-850), math('ABSOLUTE', nz, x=-250, y=-950)

    # 平面（ギズモの XY を U/V に、中心が 0.5）
    u_planar = math('ADD', px, 0.5, x=-500, y=200)
    v_planar = math('ADD', py, 0.5, x=-500, y=120)
    uv_planar = combine(u_planar, v_planar, -300, 200)

    # 円柱と球の U：面の中心の角度を基準に、角の角度との差を -π〜π に包んでつなぎ目で割れないようにします。
    theta_corner = math('ARCTAN2', py, px, x=-500, y=-60)
    theta_face = math('ARCTAN2', on_face(py, x=-650, y=-140), on_face(px, x=-650, y=-220), x=-500, y=-160)
    delta = math('WRAP', math('SUBTRACT', theta_corner, theta_face, x=-350, y=-100), 3.141592653589793, -3.141592653589793, x=-200, y=-100)
    u_angle = math('MULTIPLY_ADD', math('ADD', theta_face, delta, x=-50, y=-100), 0.15915494309189535, 0.5, x=100, y=-100)
    v_height = math('ADD', pz, 0.5, x=-500, y=-300)
    uv_cyl_side = combine(u_angle, v_height, 250, -100)

    # ボックス（面の法線の一番大きい軸で平面投影。裏の面は U を反転して鏡像にしない）
    neg_px = math('MULTIPLY', px, -1.0, x=-100, y=-500)
    uv_box_x = combine(math('MULTIPLY_ADD', math('SIGN', nx, x=-100, y=-600), py, 0.5, x=50, y=-600), v_height, 200, -600)
    uv_box_y = combine(math('MULTIPLY_ADD', math('SIGN', ny, x=-100, y=-700), neg_px, 0.5, x=50, y=-700), v_height, 200, -700)
    uv_box_z = combine(math('MULTIPLY_ADD', math('SIGN', nz, x=-100, y=-800), px, 0.5, x=50, y=-800), v_planar, 200, -800)
    is_x = boolean('AND', compare('GREATER_EQUAL', ax, ay, -100, -900), compare('GREATER_EQUAL', ax, az, -100, -960), 50, -930)
    is_y = boolean('AND', boolean('NOT', is_x, x=200, y=-930), compare('GREATER_EQUAL', ay, az, 200, -990), 350, -960)
    uv_box = switch(is_x, switch(is_y, uv_box_z, uv_box_y, 500, -800), uv_box_x, 650, -700)

    # 円柱のキャップ：ギズモの Z 軸に 45 度より近い面だけ Z の平面投影
    radial = vmath('LENGTH', combine(nx, ny, -100, -1100), x=50, y=-1100, value_out=True)
    is_cap = boolean('AND', compare('GREATER_THAN', az, radial, 200, -1100), gin('cap', 'Cap'), 350, -1100)
    uv_cyl = switch(is_cap, uv_cyl_side, uv_box_z, 500, -100)

    # 球（緯度を V に）
    rho = vmath('LENGTH', combine(px, py, -300, 400), x=-150, y=400, value_out=True)
    v_lat = math('MULTIPLY_ADD', math('ARCTAN2', pz, rho, x=0, y=400), 0.3183098861837907, 0.5, x=150, y=400)
    uv_sph = combine(u_angle, v_lat, 300, 400)

    # シュリンクラップ（上の極が中心、下の極がマップの外周に集まる）
    radius = math('DIVIDE', math('ARCTAN2', rho, pz, x=0, y=600), 3.141592653589793, x=150, y=600)
    dx, dy, _dz = separate(vmath('NORMALIZE', combine(px, py, -300, 650), x=-150, y=650), 0, 700)
    edge = math('MAXIMUM', math('ABSOLUTE', dx, x=150, y=760), math('ABSOLUTE', dy, x=150, y=820), x=300, y=780)
    reach = math('MULTIPLY', math('DIVIDE', radius, edge, x=450, y=650), 0.5, x=600, y=650)
    uv_shrink = combine(math('MULTIPLY_ADD', dx, reach, 0.5, x=750, y=700), math('MULTIPLY_ADD', dy, reach, 0.5, x=750, y=620), 900, 650)

    # フェース（面ごとに 0〜1 の全体を貼る。四角形は角が (0,0)(1,0)(1,1)(0,1)）
    corner = node('GeometryNodeFaceOfCorner', -300, 1000, 'Face of Corner')
    neighbors = node('GeometryNodeInputMeshFaceNeighbors', -300, 900, 'Face Neighbors')
    turn = math('DIVIDE', socket_by_name(corner.outputs, ('Index in Face',), 1), socket_by_name(neighbors.outputs, ('Vertex Count',), 0), x=-100, y=950)
    angle = math('MULTIPLY_ADD', turn, 6.283185307179586, -2.356194490192345, x=50, y=950)
    cos_a, sin_a = math('COSINE', angle, x=200, y=1000), math('SINE', angle, x=200, y=900)
    square = math('MAXIMUM', math('ABSOLUTE', cos_a, x=350, y=1000), math('ABSOLUTE', sin_a, x=350, y=900), x=500, y=950)
    half = math('DIVIDE', 0.5, square, x=650, y=950)
    uv_face = combine(math('MULTIPLY_ADD', cos_a, half, 0.5, x=800, y=1000), math('MULTIPLY_ADD', sin_a, half, 0.5, x=800, y=900), 950, 950)

    # XYZ to UVW（ギズモを使わず、入ってきたメッシュのオブジェクト座標。UV は 2 次元なので W は残りません）
    ox, oy, _oz = separate(socket_by_name(position.outputs, ('Position',), 0), -300, 1200)
    uv_xyz = combine(ox, oy, -100, 1200)

    # --- 投影の切り替え（項目の値は 0〜6 の順） ---
    menu = node('GeometryNodeMenuSwitch', 1000, 0, 'Mapping')
    items = menu.enum_definition.enum_items
    labels = [ct(en, ja) for en, ja in UVW_MAPPING_ITEMS]
    for index, label in enumerate(labels):
        if index < len(items):
            items[index].name = label
        else:
            items.new(label)
    menu.data_type = 'VECTOR'
    _link(group, gin('mapping', 'Mapping'), menu.inputs[0])
    for index, value in enumerate((uv_planar, uv_cyl, uv_sph, uv_shrink, uv_box, uv_face, uv_xyz)):
        _link(group, value, menu.inputs[index + 1])
    try:
        socks['mapping'].default_value = labels[0]
    except Exception:
        pass

    # --- 反転とタイル：u = (反転なら 1 - u) × U タイル ---
    mu, mv, _mw = separate(_enabled(menu.outputs)[0], 1100, -200)
    flip_u = math('MULTIPLY_ADD', gin('flip_u', 'Flip U'), math('MULTIPLY_ADD', mu, -2.0, 1.0, x=1150, y=-300), mu, x=1200, y=-250)
    flip_v = math('MULTIPLY_ADD', gin('flip_v', 'Flip V'), math('MULTIPLY_ADD', mv, -2.0, 1.0, x=1150, y=-450), mv, x=1200, y=-400)
    tiled = combine(math('MULTIPLY', flip_u, gin('u_tile', 'U Tile'), x=1250, y=-250), math('MULTIPLY', flip_v, gin('v_tile', 'V Tile'), x=1250, y=-400), 1250, -150)
    _link(group, tiled, socket_by_name(store.inputs, ('Value',), 3))
    return group


def _create_uvw_modifier(obj, context=None, insert_idx=None):
    group = _make_uvw_node_group(obj, context=context)
    mod_name = ms_next_logical_name_from_base(obj, MODIFIER_BASE_NAME)
    mod = obj.modifiers.new(name=mod_name, type='NODES')
    try:
        mod.node_group = group
    except Exception:
        pass
    try:
        mod.show_expanded = True
    except Exception:
        pass
    try:
        mod[MARKER] = True
        mod['smsm_plugin_id'] = PLUGIN_ID
        mod[UVW_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[UVW_UV_NAME_PROP] = DEFAULT_UV_NAME
    except Exception:
        pass
    try:
        if insert_idx is not None:
            target_index = max(0, int(insert_idx))
        else:
            try:
                master = get_main_object(getattr(context, 'active_object', None)) if context is not None else obj
            except Exception:
                master = obj
            target_index = ms_calc_target_insert_index(master or obj, obj, context)
        safe_move_modifier(obj, mod.name, target_index)
    except Exception:
        pass
    try:
        ms_obj_set_disp_name(obj, mod.name, choose_text('UVW Map', 'UVWマップ', context=context))
        set_mod_enabled_state(obj, mod.name, True)
        set_mod_viewport_state(obj, mod.name, True)
        obj['ui_active_item'] = mod.name
        obj['ui_active_row'] = obj.modifiers.find(mod.name)
        ms_set_ui_active_index(obj, obj.modifiers.find(mod.name))
        obj.modifiers.active = mod
    except Exception:
        pass
    _configure_uvw_modifier(obj, mod, context=context)
    return mod


def _configure_uvw_modifier(obj, mod, context=None):
    if obj is None or mod is None:
        return None
    group = getattr(mod, 'node_group', None)
    if group is None:
        group = _make_uvw_node_group(obj, context=context)
        try:
            mod.node_group = group
        except Exception:
            pass
    gizmo = _find_gizmo(obj, getattr(mod, 'name', ''))
    if gizmo is None:
        gizmo = _new_uvw_gizmo(obj, getattr(mod, 'name', ''), context=context)
    try:
        if ms_is_shape_mesh_proxy(obj):
            obj[UVW_PROXY_OWNER_PROP] = f'{getattr(obj, "name", "")}|{getattr(mod, "name", "")}'
            _link_object_to_uvw_collection(obj, context=context, exclusive=True)
    except Exception:
        pass
    try:
        _link_object_to_uvw_collection(gizmo, context=context, exclusive=True)
    except Exception:
        pass
    sid = _modifier_socket_id(group, UVW_GIZMO_SOCKET_PROP, 'Gizmo')
    if sid:
        _set_modifier_socket_value(mod, sid, gizmo)
    try:
        # 投影の選択がまだ無い（-1）なら平面にします。
        mapping_sid = _uvw_socket_ids(group).get('mapping', '')
        if mapping_sid and int(mod.get(mapping_sid, -1)) < 0:
            mod[mapping_sid] = 0
    except Exception:
        pass
    try:
        mod[MARKER] = True
        mod['smsm_plugin_id'] = PLUGIN_ID
        mod[UVW_GIZMO_NAME_PROP] = str(getattr(gizmo, 'name', '') or '')
        mod[UVW_GIZMO_SOCKET_PROP] = str(sid or '')
        mod[UVW_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[UVW_UV_NAME_PROP] = DEFAULT_UV_NAME
        if gizmo is not None:
            gizmo[UVW_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
            gizmo[UVW_GIZMO_MODIFIER_PROP] = str(getattr(mod, 'name', '') or '')
            gizmo[UVW_HELPER_PROP] = True
            gizmo['smsm_internal_helper'] = True
    except Exception:
        pass
    try:
        obj.update_tag()
    except Exception:
        pass
    return gizmo


def _select_only(context, obj) -> None:
    if obj is None:
        return
    try:
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
    except Exception:
        pass
    try:
        for o in getattr(context, 'scene', bpy.context.scene).objects:
            try:
                o.select_set(False)
            except Exception:
                pass
        obj.select_set(True)
        context.view_layer.objects.active = obj
    except Exception:
        pass


def _targets_for_run(context, target_name: str = ''):
    if target_name:
        obj = bpy.data.objects.get(str(target_name))
        return [obj] if obj is not None and getattr(obj, 'type', '') == 'MESH' else []
    items = list(selected_mesh_targets(context) or [])
    # Shape-object workflows temporarily select the generated *_SMS_CurveMesh proxy.
    # get_main_object(proxy) intentionally resolves back to the original curve for
    # stack display, so selected_mesh_targets() can filter the proxy out.  For this
    # mesh-only UVW operator, the proxy itself is the correct Geometry Nodes host.
    if not items:
        seen = set()
        try:
            for obj in list(getattr(context, 'selected_objects', []) or []):
                if obj is not None and getattr(obj, 'type', '') == 'MESH' and hasattr(obj, 'modifiers'):
                    name = str(getattr(obj, 'name', '') or '')
                    if name and name not in seen:
                        seen.add(name); items.append(obj)
        except Exception:
            pass
    if not items:
        active_raw = getattr(context, 'active_object', None)
        if active_raw is not None and getattr(active_raw, 'type', '') == 'MESH' and hasattr(active_raw, 'modifiers'):
            items = [active_raw]
    try:
        active_raw = getattr(context, 'active_object', None)
        active = active_raw if active_raw in items else get_main_object(active_raw)
    except Exception:
        active = getattr(context, 'active_object', None)
    if active in items:
        items = [active] + [o for o in items if o != active]
    return items


def _run_add(context, target_name: str = ''):
    targets = _targets_for_run(context, target_name)
    if not targets:
        return [], []
    sel, act = capture_selection(context)
    mode = ensure_object_mode(context)
    pairs = []
    failed = []
    first_gizmo = None
    try:
        for obj in targets:
            try:
                mod = _create_uvw_modifier(obj, context=context)
                gizmo = _find_gizmo(obj, getattr(mod, 'name', ''))
                if first_gizmo is None and gizmo is not None:
                    first_gizmo = gizmo
                pairs.append((obj, mod))
                try:
                    ms_apply_state_post_action(context, obj, interactive_default=False)
                except Exception:
                    pass
            except Exception as exc:
                failed.append((getattr(obj, 'name', 'Object'), exc))
        if len(pairs) > 1:
            try:
                ms_group_modifiers_as_instance(pairs, disp_name=choose_text('UVW Map', 'UVWマップ', context=context), sync_from_first=True, context=context)
            except Exception:
                pass
    finally:
        # 仕様通り、処理終了時はギズモだけを選択し、即座に移動・回転・スケール操作できる状態にします。
        if first_gizmo is not None:
            _select_only(context, first_gizmo)
        else:
            restore_selection(context, sel, act)
            restore_mode(context, mode, act)
    return pairs, failed


def match_modifier(mod):
    try:
        if bool(mod.get(MARKER, False)):
            return True
    except Exception:
        pass
    try:
        if bool(mod.get(UVW_GIZMO_NAME_PROP, '')):
            return True
    except Exception:
        pass
    try:
        group = getattr(mod, 'node_group', None)
        return getattr(mod, 'type', '') == 'NODES' and str(getattr(group, 'name', '') or '').startswith(NODE_GROUP_PREFIX)
    except Exception:
        return False


def get_main_object_for_uvw(obj):
    try:
        if obj is not None and hasattr(obj, 'get'):
            if UVW_GIZMO_TARGET_PROP in obj:
                target = bpy.data.objects.get(str(obj.get(UVW_GIZMO_TARGET_PROP, '') or ''))
                if target is not None:
                    return target
    except Exception:
        pass
    return None


def _collect_cleanup_state(obj, mod):
    state = {'gizmo': '', 'group': '', 'proxy': '', 'vertex_groups': []}
    if obj is None or mod is None:
        return state
    try:
        state['gizmo'] = str(mod.get(UVW_GIZMO_NAME_PROP, '') or '')
    except Exception:
        pass
    try:
        group = getattr(mod, 'node_group', None)
        state['group'] = str(getattr(group, 'name', '') or '')
    except Exception:
        pass
    try:
        if ms_is_shape_mesh_proxy(obj):
            state['proxy'] = str(getattr(obj, 'name', '') or '')
    except Exception:
        pass
    try:
        for vg in getattr(obj, 'vertex_groups', []) or []:
            name = str(getattr(vg, 'name', '') or '')
            if name.startswith('SMS_UVW') or name.startswith('smsm_uvw'):
                state['vertex_groups'].append(name)
    except Exception:
        pass
    return state


def _remove_object_if_unused(name: str) -> None:
    obj = bpy.data.objects.get(str(name or ''))
    if obj is not None:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass


def _remove_node_group_if_unused(name: str) -> None:
    group = bpy.data.node_groups.get(str(name or ''))
    if group is not None:
        try:
            # A Smart-owned name is not proof that this exact datablock is
            # disposable: copied/instanced modifier rows can still consume it.
            if int(getattr(group, 'users', 0) or 0) <= 0:
                bpy.data.node_groups.remove(group)
        except Exception:
            pass


def _remove_proxy_if_unused(proxy_name: str) -> None:
    proxy = bpy.data.objects.get(str(proxy_name or ''))
    if proxy is None:
        _cleanup_empty_collections()
        return
    remove_proxy = False
    try:
        if bool(proxy.get(UVW_PROXY_OWNER_PROP, False)):
            non_internal = []
            for m in getattr(proxy, 'modifiers', []) or []:
                is_converter = False
                try:
                    if bool(m.get('ms_shape_curve_mesh_converter', False)):
                        is_converter = True
                except Exception:
                    pass
                try:
                    if str(getattr(m, 'name', '') or '') in {'Curve to Mesh via Geometry Nodes', 'ジオメトリノードでカーブを読み込み・メッシュ化'}:
                        is_converter = True
                except Exception:
                    pass
                try:
                    ng = getattr(m, 'node_group', None)
                    if ng is not None and str(getattr(ng, 'name', '') or '').startswith('SMS Curve To Mesh'):
                        is_converter = True
                except Exception:
                    pass
                if is_converter:
                    continue
                try:
                    if match_modifier(m):
                        continue
                except Exception:
                    pass
                non_internal.append(m)
            remove_proxy = not non_internal
    except Exception:
        remove_proxy = False
    if not remove_proxy:
        return
    data = getattr(proxy, 'data', None)
    try:
        bpy.data.objects.remove(proxy, do_unlink=True)
    except Exception:
        pass
    try:
        if data is not None and int(getattr(data, 'users', 0) or 0) == 0:
            bpy.data.meshes.remove(data)
    except Exception:
        pass
    try:
        for source in list(bpy.data.objects):
            try:
                if source.get('ms_shape_mesh_proxy_object') == proxy_name:
                    for key in ('ms_shape_mesh_proxy_object', 'ms_shape_mesh_proxy_object_id'):
                        try:
                            del source[key]
                        except Exception:
                            pass
            except Exception:
                continue
    except Exception:
        pass
    _cleanup_empty_collections()


def _cleanup_owned_data(state, context=None) -> None:
    try:
        state = dict(state or {})
    except Exception:
        state = {}
    gizmo_name = str(state.get('gizmo', '') or '')
    if gizmo_name:
        still_used = False
        for candidate in list(bpy.data.objects):
            try:
                for other in getattr(candidate, 'modifiers', []) or []:
                    if str(other.get(UVW_GIZMO_NAME_PROP, '') or '') == gizmo_name:
                        still_used = True
                        break
                if still_used:
                    break
            except Exception:
                continue
        if not still_used:
            _remove_object_if_unused(gizmo_name)
    group_name = str(state.get('group', '') or '')
    if group_name:
        _remove_node_group_if_unused(group_name)
    proxy_name = str(state.get('proxy', '') or '')
    if proxy_name:
        _remove_proxy_if_unused(proxy_name)
    try:
        for obj in list(bpy.data.objects):
            for vg_name in list(state.get('vertex_groups', []) or []):
                try:
                    vg = obj.vertex_groups.get(str(vg_name))
                    if vg is not None:
                        obj.vertex_groups.remove(vg)
                except Exception:
                    pass
    except Exception:
        pass
    _cleanup_empty_collections()


def cleanup_before_remove(main_obj, context, obj, mod):
    # 削除/適用オペレーターでは before_item_action で状態を記録し、
    # Blenderがモディファイアを外した後の after_item_action で補助データを削除します。
    # ここで先にEmptyやプロキシを消すと、適用前評価や通常削除処理が壊れるため何もしません。
    return


def before_item_action(main_obj, context, obj, mod, action, clipboard):
    try:
        if match_modifier(mod) and str(action or '') in {'APPLY', 'APPLY_BELOW', 'DELETE', 'CUT'}:
            return _collect_cleanup_state(obj, mod)
    except Exception:
        pass
    return {}


def after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    try:
        if str(action or '') in {'APPLY', 'APPLY_BELOW', 'DELETE', 'CUT'}:
            _cleanup_owned_data(state, context=context)
    except Exception:
        pass


def _iter_uvw_modifiers(obj):
    if obj is None:
        return []
    out = []
    try:
        for mod in getattr(obj, 'modifiers', []) or []:
            if match_modifier(mod):
                out.append(mod)
    except Exception:
        pass
    return out


def sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive):
    if main_obj is None:
        return None
    try:
        stack_obj = main_obj
        active_id = str(effective_active_id or 'BASE')
        for mod in _iter_uvw_modifiers(stack_obj):
            visible = bool(active_id and active_id != 'BASE' and getattr(mod, 'name', '') == active_id)
            gizmo = _find_gizmo(stack_obj, getattr(mod, 'name', ''))
            if gizmo is None:
                try:
                    gizmo = _configure_uvw_modifier(stack_obj, mod, context=context)
                except Exception:
                    gizmo = None
            if gizmo is not None:
                _link_object_to_uvw_collection(gizmo, context=context, exclusive=True)
                _set_helper_visibility(gizmo, visible)
            try:
                if ms_is_shape_mesh_proxy(stack_obj) and bool(stack_obj.get(UVW_PROXY_OWNER_PROP, False)):
                    _link_object_to_uvw_collection(stack_obj, context=context, exclusive=True)
                    _set_helper_visibility(stack_obj, visible)
            except Exception:
                pass
    except Exception:
        pass
    return None


def _uvw_socket_values(mod):
    """マッピング・キャップ・タイル・反転・UV マップ名の今の値を、鍵ごとに返します。"""
    values = {}
    for key, sid in _uvw_socket_ids(getattr(mod, 'node_group', None)).items():
        try:
            if sid in mod.keys():
                value = mod[sid]
                if isinstance(value, (bool, int, float, str)):
                    values[key] = value
        except Exception:
            pass
    return values


def _apply_uvw_socket_values(mod, values) -> bool:
    ids = _uvw_socket_ids(getattr(mod, 'node_group', None))
    changed = False
    for key, value in dict(values or {}).items():
        sid = ids.get(key)
        if not sid:
            continue
        try:
            mod[sid] = value
            changed = True
        except Exception:
            pass
    return changed


def clipboard_copy(main_obj, context, obj, mod):
    if not match_modifier(mod):
        return {}
    payload = {'plugin_id': PLUGIN_ID, 'uv_name': DEFAULT_UV_NAME}
    values = _uvw_socket_values(mod)
    if values:
        payload['uvw_values'] = values
    return payload


def clipboard_paste(main_obj, context, obj, insert_idx, clipboard):
    mod = _create_uvw_modifier(obj, context=context, insert_idx=insert_idx)
    try:
        payload = (clipboard or {}).get('payload') or {}
        if _apply_uvw_socket_values(mod, payload.get('uvw_values')):
            obj.update_tag()
    except Exception:
        pass
    return getattr(mod, 'name', None)


def after_instance_sync(src_obj, src_mod, obj, mod, context=None):
    if not match_modifier(mod):
        return
    try:
        # インスタンス同期時も、各オブジェクトは独自のEmpty/NodeGroupを保持します。
        if getattr(mod, 'node_group', None) is None or str(getattr(getattr(mod, 'node_group', None), 'name', '') or '').startswith(NODE_GROUP_PREFIX) is False:
            pass
        _configure_uvw_modifier(obj, mod, context=context)
    except Exception:
        pass


def get_skip_copy_props(mod):
    skip = {
        'node_group', MARKER, UVW_GIZMO_NAME_PROP, UVW_GIZMO_SOCKET_PROP,
        UVW_NODE_GROUP_PROP, UVW_HELPER_PROP, UVW_PROXY_OWNER_PROP,
        UVW_GIZMO_TARGET_PROP, UVW_GIZMO_MODIFIER_PROP,
    }
    try:
        sid = str(mod.get(UVW_GIZMO_SOCKET_PROP, '') or '')
        if sid:
            skip.add(sid)
            skip.add(f'{sid}_use_attribute')
            skip.add(f'{sid}_attribute_name')
    except Exception:
        pass
    return skip


def draw_props(layout, mod, obj=None, context=None):
    if not match_modifier(mod):
        return False
    box = layout.box()
    draw_help_header(box, context, 'UVW Map', ICON, 'uvw_map_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    try:
        gizmo_name = str(mod.get(UVW_GIZMO_NAME_PROP, '') or '')
    except Exception:
        gizmo_name = ''
    ids = _uvw_socket_ids(getattr(mod, 'node_group', None))
    try:
        if ids.get('mapping'):
            col.prop(mod, f'["{ids["mapping"]}"]', text=choose_text('Mapping', 'マッピング', context=context))
            try:
                is_cylindrical = int(mod.get(ids['mapping'], 0)) == UVW_MAPPING_CYLINDRICAL
            except Exception:
                is_cylindrical = False
            if is_cylindrical and ids.get('cap'):
                col.prop(mod, f'["{ids["cap"]}"]', text=choose_text('Cap', 'キャップ', context=context))
            for key, en, ja in (('u_tile', 'U Tile', 'U タイル'), ('v_tile', 'V Tile', 'V タイル'), ('flip_u', 'Flip U', 'U 反転'), ('flip_v', 'Flip V', 'V 反転'), ('uv_name', 'UV Map', 'UV マップ')):
                if ids.get(key):
                    col.prop(mod, f'["{ids[key]}"]', text=choose_text(en, ja, context=context))
        else:
            row = col.row(align=True)
            row.label(text=choose_text('Projection', '投影方式', context=context))
            row.label(text=choose_text('Planar', '平面', context=context))
            row = col.row(align=True)
            row.label(text=choose_text('UV Map', 'UVマップ', context=context))
            row.label(text=DEFAULT_UV_NAME)
        row = col.row(align=True)
        row.label(text=choose_text('Gizmo', 'ギズモ', context=context))
        row.label(text=gizmo_name or '-')
    except Exception:
        pass
    row = box.row(align=True)
    op = _sms_icon_operator(row, EDIT_ID, text=choose_text('Select Gizmo', 'ギズモを選択', context=context), icon_name='select_linked_instances', fallback_icon='EMPTY_AXIS')
    op.target_obj_name = getattr(obj, 'name', '') if obj else ''
    op.modifier_name = getattr(mod, 'name', '')
    return True


class SMSM_OT_uvw_map_modifier(Operator):
    bl_idname = OP_ID
    bl_label = LABEL
    bl_description = 'Add a non-destructive Smart Connect UVW Geometry Nodes modifier with a transformable mapping Empty gizmo and the 3ds Max mapping types.'
    bl_options = {'UNDO'}

    target_obj_name: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return bool(_targets_for_run(context))

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Add a non-destructive UVW Map: Planar, Cylindrical, Spherical, Shrink Wrap, Box, Face or XYZ to UVW. A Smart_Connect_UVW_Gizmo Empty is created, and moving, rotating, scaling, or animating it updates the UV map through Geometry Nodes.',
            '非破壊のUVWマップを追加します。平面・円柱・球・シュリンクラップ・ボックス・フェース・XYZ to UVW から投影を選べます。Smart_Connect_UVW_Gizmo Emptyを作成し、移動・回転・スケール・アニメーションでGeometry Nodes側のUVマップを更新します。',
            context=context,
        )

    def execute(self, context):
        pairs, failed = _run_add(context, self.target_obj_name)
        if not pairs:
            msg = failed[0][1] if failed else choose_text('Select one or more mesh objects.', 'メッシュオブジェクトを1つ以上選択してください。', context=context)
            self.report({'ERROR'}, str(msg))
            return {'CANCELLED'}
        self.report({'INFO'}, choose_text(f'UVW Map added to {len(pairs)} object(s).', f'UVWマップ を {len(pairs)} 個のオブジェクトに追加しました。', context=context))
        return {'FINISHED'}


class SMSM_OT_uvw_map_edit_modifier(Operator):
    bl_idname = EDIT_ID
    bl_label = 'Select UVW Gizmo'
    bl_description = 'Select the Smart Connect UVW Empty gizmo for the active UVW Map modifier.'
    bl_options = {'UNDO'}

    target_obj_name: StringProperty(options={'SKIP_SAVE'})
    modifier_name: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        obj = bpy.data.objects.get(self.target_obj_name) or get_main_object(getattr(context, 'active_object', None))
        mod = obj.modifiers.get(self.modifier_name) if obj is not None and self.modifier_name else None
        if mod is None and obj is not None:
            try:
                mod = obj.modifiers.active
            except Exception:
                mod = None
        if obj is None or mod is None or not match_modifier(mod):
            self.report({'ERROR'}, choose_text('UVW Map modifier was not found.', 'UVWマップモディファイアが見つかりません。', context=context))
            return {'CANCELLED'}
        gizmo = _find_gizmo(obj, getattr(mod, 'name', '')) or _configure_uvw_modifier(obj, mod, context=context)
        if gizmo is None:
            self.report({'ERROR'}, choose_text('UVW gizmo could not be created.', 'UVWギズモを作成できませんでした。', context=context))
            return {'CANCELLED'}
        _set_helper_visibility(gizmo, True)
        _select_only(context, gizmo)
        return {'FINISHED'}


class SMSM_OT_uvw_map_restore_backup(Operator):
    bl_idname = RESTORE_ID
    bl_label = 'Clean UVW Map Helpers'
    bl_description = 'Clean unused Smart Connect UVW helper objects and node groups.'
    bl_options = {'UNDO'}

    target_obj_name: StringProperty(options={'SKIP_SAVE'})
    modifier_name: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        obj = bpy.data.objects.get(self.target_obj_name) or get_main_object(getattr(context, 'active_object', None))
        mod = obj.modifiers.get(self.modifier_name) if obj is not None and self.modifier_name else None
        if obj is not None and mod is not None and match_modifier(mod):
            _configure_uvw_modifier(obj, mod, context=context)
        _cleanup_empty_collections()
        return {'FINISHED'}


def draw_add_menu(layout, context):
    _sms_icon_operator(layout, OP_ID, text=choose_text('UVW Map', 'UVWマップ', context=context), icon_name='uvw_map', fallback_icon=ICON)


CLASSES = (SMSM_OT_uvw_map_modifier, SMSM_OT_uvw_map_edit_modifier, SMSM_OT_uvw_map_restore_backup)


def register_embedded():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass
    ms_register_plugin(PLUGIN_ID, {
        'id': PLUGIN_ID,
        'label': LABEL,
        'label_ja': 'UVWマップ',
        'operator_id': OP_ID,
        'icon': ICON,
        'custom_icon': 'uvw_map',
        'priority': 105,
        'group': 'uv_mapping',
        'group_label': 'UV / Mapping',
        'group_icon': 'GROUP_UVS',
        'group_priority': 72,
        'description_en': 'Generate a non-destructive Smart Connect UVW planar mapping modifier driven by an animatable Empty gizmo.',
        'description_ja': 'アニメーション可能なEmptyギズモで制御する非破壊のSmart Connect UVW平面マッピングモディファイアを生成します。',
        'usage_en': 'Select mesh object(s), run Add Modifier > User > UV / Mapping > UVW Map, then move, rotate, scale, or animate the Smart_Connect_UVW_Gizmo Empty.',
        'usage_ja': 'メッシュオブジェクトを選択し、モディファイアを追加 > ユーザー > UV / Mapping > UVWマップを実行します。その後Smart_Connect_UVW_Gizmo Emptyを移動・回転・スケール・アニメーションします。',
        'stack_addable': True,
        'modeling_side': True,
        'draw_add_menu': draw_add_menu,
        'match_modifier': match_modifier,
        'get_main_object': get_main_object_for_uvw,
        'draw_modifier_properties_extra': draw_props,
        'cleanup_before_remove': cleanup_before_remove,
        'before_item_action': before_item_action,
        'after_item_action': after_item_action,
        'clipboard_copy': clipboard_copy,
        'clipboard_paste': clipboard_paste,
        'sync_objects': sync_objects,
        'always_sync': True,
        'supports_base': True,
        'after_instance_sync': after_instance_sync,
        'get_skip_copy_props': get_skip_copy_props,
    })


def unregister_embedded():
    try:
        ms_unregister_plugin(PLUGIN_ID)
    except Exception:
        pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    register_embedded()


def unregister():
    unregister_embedded()
