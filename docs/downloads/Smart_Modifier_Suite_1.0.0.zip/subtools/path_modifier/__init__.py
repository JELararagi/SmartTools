# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for path_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "path_modifier"
PLUGIN_LABEL = "Path Modifier"
OPERATOR_ID = "smsp.selected_objects_to_path"
PLUGIN_ICON = "CURVE_PATH"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
