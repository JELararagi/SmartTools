# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for solo_selected_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "solo_selected_modifier"
PLUGIN_LABEL = "Solo Selected Modifier"
OPERATOR_ID = "smsp.toggle_solo_selected"
PLUGIN_ICON = "HIDE_OFF"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
