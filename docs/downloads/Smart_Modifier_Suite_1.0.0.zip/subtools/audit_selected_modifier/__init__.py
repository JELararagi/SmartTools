# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for audit_selected_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "audit_selected_modifier"
PLUGIN_LABEL = "Audit Selected Modifier"
OPERATOR_ID = "smsp.audit_selected"
PLUGIN_ICON = "CHECKMARK"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
