# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="detach_separate_clean_modifier"
PLUGIN_LABEL ='Detach Separate Clean Modifier'
OPERATOR_ID ="sms.detach_separate_clean"
PLUGIN_ICON ="MESH_DATA"


def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )


def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
