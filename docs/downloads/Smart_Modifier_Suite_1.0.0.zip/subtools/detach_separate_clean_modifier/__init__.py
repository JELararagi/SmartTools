# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for detach_separate_clean_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "detach_separate_clean_modifier"
PLUGIN_LABEL = "Detach Separate Clean Modifier"
OPERATOR_ID = "sms.detach_separate_clean"
PLUGIN_ICON = "MESH_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
