# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for instances_along_path_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "instances_along_path_modifier"
PLUGIN_LABEL = "Instances Along Path Modifier"
OPERATOR_ID = "smsp.instances_along_path"
PLUGIN_ICON = "DUPLICATE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
