# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for pipe_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "pipe_modifier"
PLUGIN_LABEL = "Pipe Modifier"
OPERATOR_ID = "sms.smart_pipe_from_selection"
PLUGIN_ICON = "META_CAPSULE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
