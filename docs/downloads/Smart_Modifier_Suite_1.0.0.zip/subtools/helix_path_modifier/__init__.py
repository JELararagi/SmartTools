# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for helix_path_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "helix_path_modifier"
PLUGIN_LABEL = "Helix Path Modifier"
OPERATOR_ID = "smsp.add_helix_path"
PLUGIN_ICON = "CURVE_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
