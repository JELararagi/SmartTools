# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================
from __future__ import annotations

import math
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Operator

from ...translation import choose_text

try:
    from ...icons import icon_value as _sms_icon_value, operator as _sms_icon_operator
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)

def _sms_label(layout, text='', icon_name='modifier', fallback_icon='MODIFIER'):
    try:
        iv = _sms_icon_value(icon_name, fallback_icon)
        if iv:
            layout.label(text=text, icon_value=iv)
            return
    except Exception:
        pass
    try:
        layout.label(text=text, icon=fallback_icon)
    except Exception:
        layout.label(text=text)

try:
    from ...help_button import draw_help_header
except Exception:
    def draw_help_header(layout, context, label, icon, help_id, **kwargs):
        try:
            _sms_label(layout, text=choose_text(label, label, context=context), icon_name=str(icon or 'modifier'), fallback_icon='MODIFIER')
        except Exception:
            try:
                layout.label(text=choose_text(label, label, context=context))
            except Exception:
                pass

from ...core import ms_register_plugin, ms_unregister_plugin
from ..uv_stack_common import (
    capture_selection, restore_selection, ensure_object_mode, restore_mode,
    selected_mesh_targets, new_marker_modifier, ensure_uv_layer, make_uv_backup,
    restore_uv_backup, finalize, draw_kv, set_props, get_prop, draw_idprop,
    ms_group_modifiers_as_instance, ms_is_instance_modifier, ms_get_instance_id, ms_iter_instance_members,
)

PLUGIN_ID = 'unwrap_uvw_modifier'
OP_ID = 'smsm.unwrap_uvw_modifier'
EDIT_ID = 'smsm.unwrap_uvw_edit_modifier'
RESTORE_ID = 'smsm.unwrap_uvw_restore_backup'
LABEL = 'Unwrap UVW'
ICON = 'UV'
MARKER = '_smsm_unwrap_uvw_modifier'
PREFIX = 'smsm_unwrap_uvw_'
BACKUP_KEY = '_smsm_unwrap_uvw_backup'

METHOD_ITEMS = (
    ('ANGLE_BASED', 'Peel / Angle Based', 'Unwraps the selected faces with an angle-based solver. Use this for organic shapes, curved surfaces, and seams that should relax naturally.'),
    ('CONFORMAL', 'Conformal', 'Unwraps with a conformal solver. Use this for hard-surface or mechanical meshes where straight edges and shape preservation are important.'),
    ('SMART_PROJECT', 'Flatten / Smart Project', 'Automatically cuts the mesh into islands using an angle limit and packs them. Use this as a 3ds Max flatten-mapping style automatic unwrap.'),
    ('QUICK_PLANAR', 'Quick Planar Map', 'Projects UVs from the current 3D View direction. Use this for decals, flat selections, and fast one-sided mapping.'),
    ('CUBE_PROJECT', 'Box Map', 'Projects UVs from a box around the mesh. Use this for hard-surface objects, blockout meshes, and forms with several flat sides.'),
    ('CYLINDER_PROJECT', 'Cylindrical Map', 'Projects UVs around a cylinder. Use this for pipes, columns, bottles, handles, and tube-like selections.'),
    ('SPHERE_PROJECT', 'Spherical Map', 'Projects UVs around a sphere. Use this for ball-like or rounded selections.'),
    ('LIGHTMAP_PACK', 'Pack', 'Packs the existing or selected UV islands into the UV tile with the specified margin. Use this after manual seams or another unwrap method.'),
)


def find_mod(obj, name):
    try: return obj.modifiers.get(name) if obj and name else None
    except Exception: return None


def target_objects(context, name=''):
    if name:
        obj = bpy.data.objects.get(name); return [obj] if obj and getattr(obj, 'type', '') == 'MESH' else []
    return selected_mesh_targets(context)


def settings(op):
    return {k: getattr(op, k) for k in ('method','uv_map_name','selected_only','correct_aspect','scale_to_bounds','clip_to_bounds','fill_holes','use_subsurf_data','pack_islands','angle_limit','island_margin','area_weight','cube_size','projection_radius')}


def load_from_mod(op, mod):
    if mod is None: return
    for k, default in settings(op).items():
        try: setattr(op, k, get_prop(mod, PREFIX, k, default))
        except Exception: pass


def activate_only(context, obj):
    try:
        vl = context.view_layer
        for item in vl.objects:
            try: item.select_set(item == obj)
            except Exception: pass
        vl.objects.active = obj; obj.select_set(True)
    except Exception: pass


def try_ops(funcs):
    last = None
    for fn in funcs:
        try:
            r = fn()
            if not (isinstance(r, set) and 'CANCELLED' in r): return True
        except Exception as exc: last = exc
    if last: raise last
    return False


def run_uv_method(s):
    method = str(s.get('method','ANGLE_BASED')).upper()
    margin = float(s.get('island_margin', 0.02) or 0.0)
    angle = math.radians(float(s.get('angle_limit', 66.0) or 66.0))
    correct = bool(s.get('correct_aspect', True)); scale = bool(s.get('scale_to_bounds', True)); clip = bool(s.get('clip_to_bounds', False))
    fill = bool(s.get('fill_holes', True)); subsurf = bool(s.get('use_subsurf_data', False)); area = float(s.get('area_weight', 0.0) or 0.0)
    cube = max(0.000001, float(s.get('cube_size', 1.0) or 1.0)); radius = max(0.000001, float(s.get('projection_radius', 1.0) or 1.0))
    if method in {'ANGLE_BASED','CONFORMAL'}:
        m = 'CONFORMAL' if method == 'CONFORMAL' else 'ANGLE_BASED'
        return try_ops((
            lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, method=m, fill_holes=fill, correct_aspect=correct, use_subsurf_data=subsurf, margin=margin),
            lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, method=m, fill_holes=fill, correct_aspect=correct, margin=margin),
            lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, method=m, margin=margin), lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, method=m), lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, )))
    if method == 'SMART_PROJECT':
        return try_ops((
            lambda: bpy.ops.uv.smart_project('EXEC_DEFAULT', False, angle_limit=angle, island_margin=margin, area_weight=area, correct_aspect=correct, scale_to_bounds=scale),
            lambda: bpy.ops.uv.smart_project('EXEC_DEFAULT', False, angle_limit=angle, island_margin=margin, correct_aspect=correct, scale_to_bounds=scale),
            lambda: bpy.ops.uv.smart_project('EXEC_DEFAULT', False, angle_limit=angle, island_margin=margin), lambda: bpy.ops.uv.smart_project('EXEC_DEFAULT', False, )))
    if method == 'QUICK_PLANAR':
        return try_ops((lambda: bpy.ops.uv.project_from_view('EXEC_DEFAULT', False, correct_aspect=correct, scale_to_bounds=scale), lambda: bpy.ops.uv.project_from_view('EXEC_DEFAULT', False, correct_aspect=correct), lambda: bpy.ops.uv.project_from_view('EXEC_DEFAULT', False, )))
    if method == 'CUBE_PROJECT':
        return try_ops((lambda: bpy.ops.uv.cube_project('EXEC_DEFAULT', False, cube_size=cube, correct_aspect=correct, clip_to_bounds=clip, scale_to_bounds=scale), lambda: bpy.ops.uv.cube_project('EXEC_DEFAULT', False, cube_size=cube, correct_aspect=correct), lambda: bpy.ops.uv.cube_project('EXEC_DEFAULT', False, cube_size=cube), lambda: bpy.ops.uv.cube_project('EXEC_DEFAULT', False, )))
    if method == 'CYLINDER_PROJECT':
        return try_ops((lambda: bpy.ops.uv.cylinder_project('EXEC_DEFAULT', False, direction='VIEW_ON_EQUATOR', align='POLAR_ZX', radius=radius, correct_aspect=correct, clip_to_bounds=clip, scale_to_bounds=scale), lambda: bpy.ops.uv.cylinder_project('EXEC_DEFAULT', False, radius=radius, correct_aspect=correct), lambda: bpy.ops.uv.cylinder_project('EXEC_DEFAULT', False, radius=radius), lambda: bpy.ops.uv.cylinder_project('EXEC_DEFAULT', False, )))
    if method == 'SPHERE_PROJECT':
        return try_ops((lambda: bpy.ops.uv.sphere_project('EXEC_DEFAULT', False, direction='VIEW_ON_EQUATOR', align='POLAR_ZX', correct_aspect=correct, clip_to_bounds=clip, scale_to_bounds=scale), lambda: bpy.ops.uv.sphere_project('EXEC_DEFAULT', False, correct_aspect=correct), lambda: bpy.ops.uv.sphere_project('EXEC_DEFAULT', False, )))
    if method == 'LIGHTMAP_PACK':
        # Keep the saved enum identifier, but Pack must preserve existing islands.
        return try_ops((lambda: bpy.ops.uv.pack_islands('EXEC_DEFAULT', False, margin=margin),))
    return try_ops((lambda: bpy.ops.uv.unwrap('EXEC_DEFAULT', False, ),))


def unwrap_object(context, obj, s):
    mesh = obj.data
    layers = mesh.uv_layers
    previous_names = {uv.name for uv in layers}
    previous_active = layers.active.name if layers.active else None
    previous_render = {uv.name for uv in layers if uv.active_render}
    uv = ensure_uv_layer(mesh, s.get('uv_map_name') or 'UVMap')
    created_name = uv.name if uv is not None and uv.name not in previous_names else None
    activate_only(context, obj)
    ok = False
    try:
        try: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
        except Exception: return False
        try: bpy.ops.mesh.select_mode('EXEC_DEFAULT', False, type='FACE')
        except Exception: pass
        if not s.get('selected_only'):
            try: bpy.ops.mesh.select_all('EXEC_DEFAULT', False, action='SELECT')
            except Exception: pass
        ok = run_uv_method(s)
        if ok and s.get('pack_islands'):
            try: bpy.ops.uv.pack_islands('EXEC_DEFAULT', False, margin=float(s.get('island_margin', 0.02) or 0.0))
            except Exception: pass
        return bool(ok)
    finally:
        # Leave Edit Mode before removing only this failed call's new UV layer.
        try: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        except Exception: pass
        if not ok:
            if created_name is not None:
                created = layers.get(created_name)
                if created is not None:
                    layers.remove(created)
            if previous_active is not None:
                active = layers.get(previous_active)
                if active is not None:
                    layers.active = active
            for layer in layers:
                if layer.name in previous_render:
                    layer.active_render = True
        try: mesh.update()
        except Exception: pass


class UnwrapBase:
    method: EnumProperty(name='Unwrap Method', description='Chooses the UV generation workflow. Angle Based and Conformal solve seams, Smart Project creates automatic islands, projection modes map from a view/box/cylinder/sphere, and Pack arranges existing islands.', items=METHOD_ITEMS, default='ANGLE_BASED')
    uv_map_name: StringProperty(name='Map Channel / UV Map', description='Name of the Blender UV map used as the map channel. Use UVMap for channel 1 or enter another UV map name when the object needs multiple mapping channels.', default='UVMap')
    selected_only: BoolProperty(name='Selected Faces Only', description='When enabled, unwraps only the current Edit Mode face selection. When disabled, all faces on each target mesh are selected before generating UVs.', default=False)
    correct_aspect: BoolProperty(name='Correct Aspect', description='Preserves the active image aspect ratio when Blender UV operators support it. Keep this on when UVs should match a non-square texture image.', default=True)
    scale_to_bounds: BoolProperty(name='Scale To Bounds', description='Scales generated UVs into the 0-1 tile when the selected unwrap/projection method supports it. Use this for texture-ready coordinates inside the main tile.', default=True)
    clip_to_bounds: BoolProperty(name='Clip To Bounds', description='Clips projected UVs to the 0-1 tile when supported. Use this when projection should stay inside the main texture area instead of extending outside.', default=False)
    fill_holes: BoolProperty(name='Fill Holes', description='Allows the unwrap solver to treat holes as filled while calculating islands. This often gives cleaner results on meshes with internal borders.', default=True)
    use_subsurf_data: BoolProperty(name='Use Subdivision Surface', description='Uses subdivision-surface evaluation data while unwrapping when Blender supports it. Enable this when the UVs should better match a smoothed subdivision result.', default=False)
    pack_islands: BoolProperty(name='Pack Islands', description='Packs UV islands after the unwrap or projection method finishes. Disable this when you want to keep the generated islands in their raw position for manual layout.', default=True)
    angle_limit: FloatProperty(name='Angle Limit', description='Angle threshold used by Smart Project to decide where automatic UV cuts are created. Lower values create more islands; higher values keep larger islands together.', default=66.0, min=0.0, max=180.0)
    island_margin: FloatProperty(name='Island Margin', description='Padding between UV islands during Smart Project or Pack. Increase it to reduce texture bleeding; decrease it to use more of the UV tile.', default=0.02, min=0.0, max=1.0)
    area_weight: FloatProperty(name='Area Weight', description='Area weighting used by Smart Project. Higher values give larger faces more influence when automatic islands are generated.', default=0.0, min=0.0, max=1.0)
    cube_size: FloatProperty(name='Cube Size', description='Virtual cube size used by Box Map projection. Increase it to make projected UVs cover a smaller portion of the texture tile.', default=1.0, min=0.000001)
    projection_radius: FloatProperty(name='Projection Radius', description='Virtual radius used by Cylindrical Map projection. Adjust it when cylindrical mapping appears too compressed or too stretched.', default=1.0, min=0.000001)
    target_obj_name: StringProperty(options={'SKIP_SAVE'}); modifier_name: StringProperty(options={'SKIP_SAVE'})

    def draw(self, context):
        l = self.layout; l.use_property_split = True; l.use_property_decorate = False
        for prop, en, ja in [
            ('method','Unwrap Method','アンラップ方式'),('uv_map_name','Map Channel / UV Map','マップチャンネル / UVマップ'),('selected_only','Selected Faces Only','選択フェースのみ'),('island_margin','Island Margin','アイランド余白'),('pack_islands','Pack Islands','アイランドをパック'),('angle_limit','Angle Limit','角度制限'),('area_weight','Area Weight','面積ウェイト'),('fill_holes','Fill Holes','穴を埋めて計算'),('use_subsurf_data','Use Subdivision Surface','サブディビジョンサーフェスを使用'),('correct_aspect','Correct Aspect','アスペクト補正'),('scale_to_bounds','Scale To Bounds','0-1範囲へスケール'),('clip_to_bounds','Clip To Bounds','0-1範囲でクリップ'),('cube_size','Cube Size','ボックスサイズ'),('projection_radius','Projection Radius','投影半径')]:
            l.prop(self, prop, text=choose_text(en, ja, context=context))

    def run(self, context, update=False):
        objs = target_objects(context, self.target_obj_name)
        if not objs:
            self.report({'ERROR'}, choose_text('Select one or more mesh objects.', 'メッシュオブジェクトを1つ以上選択してください。', context=context)); return {'CANCELLED'}
        s = settings(self); sel, act = capture_selection(context); mode = ensure_object_mode(context); made=[]; failed=[]; pairs=[]
        work_items = []
        if update:
            for obj in objs:
                mod = find_mod(obj, self.modifier_name)
                if mod is not None and ms_is_instance_modifier(mod, obj):
                    try:
                        iid = ms_get_instance_id(mod, obj)
                        for member_obj, member_mod in ms_iter_instance_members(iid):
                            if member_obj and member_mod and match_modifier(member_mod):
                                work_items.append((member_obj, member_mod))
                    except Exception:
                        work_items.append((obj, mod))
                else:
                    work_items.append((obj, mod))
        else:
            work_items = [(obj, None) for obj in objs]
        seen = set(); unique_items = []
        for obj, mod in work_items:
            key = (getattr(obj, 'name', ''), getattr(mod, 'name', '') if mod else '')
            if key in seen: continue
            seen.add(key); unique_items.append((obj, mod))
        for obj, mod in unique_items:
            try:
                backup = str(mod.get(BACKUP_KEY, '') or '') if mod else ''
                if not backup: backup = make_uv_backup(obj.data, s.get('uv_map_name'))
                if not unwrap_object(context, obj, s): raise RuntimeError('UV unwrap failed')
                if mod is None: mod = new_marker_modifier(obj, PLUGIN_ID, MARKER, LABEL, 'SMS Unwrap UVW', context=context)
                set_props(mod, PREFIX, s)
                if backup: mod[BACKUP_KEY] = backup
                pairs.append((obj, mod))
                made.append(obj.name); finalize(context, obj)
            except Exception as exc:
                failed.append((getattr(obj,'name','Object'), exc))
                try: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
                except Exception: pass
        if (not update) and len(pairs) > 1:
            try: ms_group_modifiers_as_instance(pairs, disp_name=choose_text('Unwrap UVW','UVアンラップ',context=context), sync_from_first=True, context=context)
            except Exception: pass
        restore_selection(context, sel, act); restore_mode(context, mode, act)
        if failed and not made:
            self.report({'ERROR'}, choose_text(f'Unwrap UVW failed: {failed[0][1]}', f'Unwrap UVW に失敗しました: {failed[0][1]}', context=context)); return {'CANCELLED'}
        self.report({'INFO'}, choose_text(f'Unwrap UVW updated for {len(made)} object(s).', f'UVアンラップ を {len(made)} 個のオブジェクトで更新しました。', context=context)); return {'FINISHED'}


class SMSM_OT_unwrap_uvw_modifier(UnwrapBase, Operator):
    bl_idname = OP_ID; bl_label = LABEL
    bl_description = 'Add a stack-managed Unwrap UVW entry for assigning, rebuilding, packing, and manually editing UV coordinates through Blender UV tools.'
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context): return bool(selected_mesh_targets(context))
    @classmethod
    def description(cls, context, properties):
        return choose_text('Add an Unwrap UVW stack entry for angle-based, conformal, smart flatten, quick planar, box, cylindrical, spherical, and pack workflows.', '角度ベース、コンフォーマル、スマート展開、クイック平面、ボックス、円柱、球、パックのワークフロー用 Unwrap UVW スタック項目を追加します。', context=context)
    def invoke(self, context, event):
        try: return context.window_manager.invoke_props_dialog(self, width=520)
        except Exception: return self.execute(context)
    def execute(self, context): return self.run(context, update=False)


class SMSM_OT_unwrap_uvw_edit_modifier(UnwrapBase, Operator):
    bl_idname = EDIT_ID; bl_label = 'Edit Unwrap UVW'
    bl_description = 'Edit the saved Unwrap UVW method and rebuild the selected UV map coordinates on the target mesh.'
    bl_options = {'UNDO'}
    def invoke(self, context, event):
        obj = bpy.data.objects.get(self.target_obj_name) or getattr(context, 'active_object', None); load_from_mod(self, find_mod(obj, self.modifier_name))
        try: return context.window_manager.invoke_props_dialog(self, width=520)
        except Exception: return self.execute(context)
    def execute(self, context): return self.run(context, update=True)


class SMSM_OT_unwrap_uvw_restore_backup(Operator):
    bl_idname = RESTORE_ID; bl_label = 'Restore Unwrap UVW Backup'
    bl_description = 'Restore the UV coordinates that were backed up before this Unwrap UVW stack entry first generated or rebuilt the selected UV map.'
    bl_options = {'UNDO'}
    target_obj_name: StringProperty(options={'SKIP_SAVE'}); modifier_name: StringProperty(options={'SKIP_SAVE'})
    def execute(self, context):
        obj = bpy.data.objects.get(self.target_obj_name) or getattr(context, 'active_object', None); mod = find_mod(obj, self.modifier_name)
        data = str(mod.get(BACKUP_KEY, '') or '') if mod else ''
        if not restore_uv_backup(obj, data):
            self.report({'WARNING'}, choose_text('No compatible UV backup is stored on this modifier.', 'このモディファイアには復元可能なUVバックアップが保存されていません。', context=context)); return {'CANCELLED'}
        finalize(context, obj); return {'FINISHED'}


def draw_add_menu(layout, context): _sms_icon_operator(layout, OP_ID, text=choose_text('Unwrap UVW', 'UVアンラップ', context=context), icon_name='unwrap', fallback_icon=ICON)

def match_modifier(mod):
    try:
        if bool(mod.get(MARKER, False)): return True
    except Exception: pass
    try: return getattr(mod,'type','') == 'NODES' and str(getattr(getattr(mod,'node_group',None),'name','') or '').startswith('SMS Unwrap UVW')
    except Exception: return False



def settings_from_mod(mod):
    return {k: get_prop(mod, PREFIX, k, None) for k in ('method','uv_map_name','selected_only','correct_aspect','scale_to_bounds','clip_to_bounds','fill_holes','use_subsurf_data','pack_islands','angle_limit','island_margin','area_weight','cube_size','projection_radius')}


def cleanup_before_remove(main_obj, context, obj, mod):
    if not match_modifier(mod): return
    data = str(mod.get(BACKUP_KEY, '') or '') if mod else ''
    if data:
        restore_uv_backup(obj, data)
        finalize(context, obj)



def enabled_state_changed(main_obj, context, obj, mod, state):
    if not match_modifier(mod): return
    sel, act = capture_selection(context)
    mode = ensure_object_mode(context)
    try:
        if state:
            s = settings_from_mod(mod)
            if unwrap_object(context, obj, s):
                finalize(context, obj)
        else:
            data = str(mod.get(BACKUP_KEY, '') or '') if mod else ''
            if data and restore_uv_backup(obj, data):
                finalize(context, obj)
    finally:
        restore_selection(context, sel, act)
        restore_mode(context, mode, act)


def clipboard_copy(main_obj, context, obj, mod):
    if not match_modifier(mod): return {}
    return {
        'plugin_id': PLUGIN_ID,
        'settings': settings_from_mod(mod),
    }


def clipboard_paste(main_obj, context, obj, insert_idx, clipboard):
    payload = (clipboard or {}).get('payload') or {}
    s = payload.get('settings') or {}
    if not s: return None
    backup = make_uv_backup(getattr(obj, 'data', None), s.get('uv_map_name') or 'UVMap')
    if not unwrap_object(context, obj, s): return None
    mod = new_marker_modifier(obj, PLUGIN_ID, MARKER, LABEL, 'SMS Unwrap UVW', context=context, insert_idx=insert_idx)
    set_props(mod, PREFIX, s)
    if backup: mod[BACKUP_KEY] = backup
    finalize(context, obj)
    return getattr(mod, 'name', None)


def draw_props(layout, mod, obj=None, context=None):
    if not match_modifier(mod): return False
    box = layout.box(); draw_help_header(box, context, 'Unwrap UVW', ICON, 'unwrap_uvw_modifier')
    col = box.column(align=True); col.use_property_split = True; col.use_property_decorate = False
    method = str(mod.get(PREFIX + 'method', 'ANGLE_BASED') or 'ANGLE_BASED').upper()
    split = col.split(factor=0.4)
    name_row = split.row(); name_row.alignment = 'RIGHT'
    name_row.label(text=choose_text('Method', 'アンラップ方式', context=context))
    split.label(text=next((item[1] for item in METHOD_ITEMS if item[0] == method), METHOD_ITEMS[0][1]))
    for key, en, ja in (('uv_map_name', 'UV Map', 'UVマップ'), ('selected_only', 'Selected Only', '選択フェースのみ'), ('island_margin', 'Island Margin', 'アイランド余白'), ('pack_islands', 'Pack Islands', 'パック'), ('angle_limit', 'Angle Limit', '角度制限'), ('area_weight', 'Area Weight', '面積ウェイト'), ('fill_holes', 'Fill Holes', '穴を埋めて計算'), ('use_subsurf_data', 'Use Subdivision', '細分化の形を使用'), ('correct_aspect', 'Correct Aspect', 'アスペクト補正'), ('scale_to_bounds', 'Scale To Bounds', '0-1範囲へスケール'), ('clip_to_bounds', 'Clip To Bounds', '0-1範囲でクリップ'), ('cube_size', 'Cube Size', 'ボックスサイズ'), ('projection_radius', 'Radius', '投影半径')):
        draw_idprop(col, mod, PREFIX, key, choose_text(en, ja, context=context))
    row = box.row(align=True)
    op = _sms_icon_operator(row, EDIT_ID, text=choose_text('Edit / Rebuild','編集 / 再生成',context=context), icon_name='refresh', fallback_icon='FILE_REFRESH'); op.target_obj_name = getattr(obj,'name','') if obj else ''; op.modifier_name = getattr(mod,'name','')
    op = _sms_icon_operator(row, RESTORE_ID, text=choose_text('Restore','復元',context=context), icon_name='refresh', fallback_icon='LOOP_BACK'); op.target_obj_name = getattr(obj,'name','') if obj else ''; op.modifier_name = getattr(mod,'name','')
    return True


def after_instance_sync(src_obj, src_mod, obj, mod, context=None):
    if not match_modifier(mod) or context is None: return
    try:
        s = settings_from_mod(mod)
        if unwrap_object(context, obj, s):
            finalize(context, obj)
    except Exception:
        pass


def get_skip_copy_props(mod):
    # Keep each object's generated node group and UV backup local.
    # Instance synchronization shares the user-facing UV parameters and then
    # rebuilds each object through after_instance_sync(), avoiding cross-object
    # helper datablock aliasing.
    return {BACKUP_KEY, 'node_group'}


CLASSES = (SMSM_OT_unwrap_uvw_modifier, SMSM_OT_unwrap_uvw_edit_modifier, SMSM_OT_unwrap_uvw_restore_backup)

def register_embedded():
    for cls in CLASSES:
        try: bpy.utils.register_class(cls)
        except Exception: pass
    ms_register_plugin(PLUGIN_ID, {'id':PLUGIN_ID,'label':LABEL,'operator_id':OP_ID,'icon':ICON,'priority':104,'group':'uv_mapping','group_label':'UV / Mapping','group_icon':'GROUP_UVS','group_priority':72,'description_en':'Create a stack-managed Unwrap UVW entry for assigning, rebuilding, and manually editing UV map coordinates through Blender UV tools.','description_ja':'Blender のUVツールを使って UV マップ座標の割り当て、再生成、手動編集を行うスタック管理式の Unwrap UVW 項目を作成します。','usage_en':'Select mesh object(s), run Add Modifier > User > UV / Mapping > Unwrap UVW, choose the unwrap method and map channel, then use Edit / Rebuild or Blender UV Editor for later edits.','usage_ja':'メッシュオブジェクトを選択し、モディファイアを追加 > ユーザー > UV / Mapping > Unwrap UVW を実行します。方式とマップチャンネルを選び、後から「編集 / 再生成」または Blender のUVエディターで編集します。','stack_addable':False,'modeling_side':True,'draw_add_menu':draw_add_menu,'match_modifier':match_modifier,'draw_modifier_properties_extra':draw_props,'cleanup_before_remove':cleanup_before_remove,'clipboard_copy':clipboard_copy,'clipboard_paste':clipboard_paste,'enabled_state_changed':enabled_state_changed,'after_instance_sync':after_instance_sync,'get_skip_copy_props':get_skip_copy_props})

def unregister_embedded():
    try: ms_unregister_plugin(PLUGIN_ID)
    except Exception: pass
    for cls in reversed(CLASSES):
        try: bpy.utils.unregister_class(cls)
        except Exception: pass

def register(): register_embedded()
def unregister(): unregister_embedded()
