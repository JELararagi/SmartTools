# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for quad_checker_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "quad_checker_modifier"
PLUGIN_LABEL = "Quad Checker Modifier"
OPERATOR_ID = "smsp.quad_checker"
PLUGIN_ICON = "FACESEL"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
