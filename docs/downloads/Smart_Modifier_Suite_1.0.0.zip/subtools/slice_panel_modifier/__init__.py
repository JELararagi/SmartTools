# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for slice_panel_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "slice_panel_modifier"
PLUGIN_LABEL = "Slice Panel Modifier"
OPERATOR_ID = "smsa.slice_panel_stack"
PLUGIN_ICON = "MOD_BOOLEAN"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
