# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="slice_panel_modifier"
PLUGIN_LABEL ='Slice Panel Modifier'
OPERATOR_ID ="smsa.slice_panel_stack"
PLUGIN_ICON ="MOD_BOOLEAN"

def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )

def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
