# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy 
import bmesh 
import mathutils 
import gpu 
from gpu_extras .batch import batch_for_shader 
import numpy as np 
import uuid 
import time 
import sys 
import types 
iface_ = getattr(getattr(bpy.app, "translations", None), "pgettext_iface", lambda msg: msg)
from .translation import translation_dict as _SL_TRANSLATIONS 

def _sl_should_translate_interface ()->bool :
    """Respect Blender's interface translation toggle.

    Smart Lattice is bundled under Smart Modifier and should follow Blender's current
    UI language behavior automatically instead of forcing our fallback dictionary.
    """
    try :
        view =getattr (getattr (bpy .context ,"preferences",None ),"view",None )
        if view is None :
            return True 
        return bool (getattr (view ,"use_translate_interface",True ))
    except Exception :
        return True 


def t (msgid :str )->str :
    """Translate UI strings (interface context) with a Blender-aligned fallback."""
    if not _sl_should_translate_interface ():
        return msgid 

    try :
        translated =iface_ (msgid )
        if translated and translated !=msgid :
            return translated 
    except Exception :
        pass 

    lang =""
    try :
        lang =getattr (bpy .app .translations ,"locale","")or ""
    except Exception :
        lang =""
    if not lang :
        try :
            lang =getattr (getattr (bpy .context .preferences ,"view",None ),"language","")or ""
        except Exception :
            lang =""

    candidates =[]
    if lang :
        candidates .append (lang )
        if lang .startswith ("ja"):
            candidates .append ("ja_JP")
        elif lang .startswith ("en"):
            candidates .append ("en_US")

    for key in candidates :
        table =_SL_TRANSLATIONS .get (key )
        if isinstance (table ,dict ):
            translated =table .get (("*",msgid ))
            if translated :
                return translated 
    return msgid 


def _sl_runtime_api ():
    try :
        return _sl_ms_api ("_MS_RUNTIME_API_V1")
    except Exception :
        return {}


def _sl_runtime_live_enabled ()->bool :
    try :
        api =_sl_runtime_api ()
        fn =api .get ("smart_lattice_live_enabled")
        if callable (fn ):
            return bool (fn ())
    except Exception :
        pass 
    try :
        return bool (bpy .app .driver_namespace .get ("_SL_RUNTIME_ENABLED_V1",False ))
    except Exception :
        return False 


def _sl_request_live_runtime ():
    # Always-on Smart Lattice overlay/sync is controlled only from the N-panel
    # 常時機能切り替え.  Tool execution must not turn it on implicitly.
    try :
        api =_sl_runtime_api ()
        enabled =api .get ("smart_lattice_live_enabled")
        if callable (enabled )and not bool (enabled ()):return
        sync =api .get ("sync_runtime_services")
        if callable (sync ):sync ()
    except Exception :
        pass 




        # ------------------------------------------------------------
        # Add-on module name helper (supports modular package layout)
        # ------------------------------------------------------------
def _sl_addon_id ():
    """Return the add-on module identifier.

    Blender Extensions use dotted module paths (e.g. ``bl_ext.user_default.name``).
    We must keep that full dotted path. Truncating to the first component
    (``bl_ext``) is not used for bundled N-panel settings.
    """
    pkg =(__package__ or "").strip ()
    if pkg :
        return pkg 
    name =(__name__ or "").strip ()
    return name .split (".",1 )[0 ]if name else "lattice_modifier"

SL_ADDON_ID =_sl_addon_id ()
# ------------------------------------------
# SmartLattice shared-active cache (prevents full bpy.data.objects scan spam)
# ------------------------------------------
_SL_SHARED_ACTIVE_CACHE ={}# {lat_name: (t, bool)}

def _sl_is_shared_active (lat_obj ,ttl =0.25 ):
    """Return True if any mesh has a LATTICE modifier using this lattice and is currently active on it (ui_active_item).
    Cached for ttl seconds to avoid heavy scans on depsgraph spam.
    """
    try :
        nm =getattr (lat_obj ,"name","")
        now =time .time ()
        t ,v =_SL_SHARED_ACTIVE_CACHE .get (nm ,(0.0 ,False ))
        if (now -float (t or 0.0 ))<float (ttl or 0.0 ):
            return bool (v )
    except Exception :
        nm =""
        now =time .time ()

    shared_active =False 
    try :
        for o in bpy .data .objects :
            if not o or getattr (o ,"type","")!='MESH':
                continue 
            ui =str (o .get ("ui_active_item","")or "")
            if not ui :
                continue 
            for om in getattr (o ,"modifiers",[]):
                if getattr (om ,"type","")=='LATTICE'and getattr (om ,"object",None )==lat_obj :
                    if ui ==getattr (om ,"name",""):
                        shared_active =True 
                        break 
            if shared_active :
                break 
    except Exception :
        shared_active =False 

    try :
        _SL_SHARED_ACTIVE_CACHE [getattr (lat_obj ,"name","")]=(now ,shared_active )
    except Exception :
        pass 
    return shared_active 

def _sl_set_hidden (obj ,hide :bool ):
    """Hide/unhide Smart Lattice helpers without disabling viewport objects."""
    try :
        hide =bool (hide )
        # Do not set hide_viewport=True.  This is the Outliner restriction flag
        # and can make edit targets unusable after stack synchronization.
        if (not hide) and bool (getattr (obj ,"hide_viewport",False )):
            obj .hide_viewport =False
        if bool (getattr (obj ,"hide_select",False ))!=hide :
            obj .hide_select =hide 
        try :
            cur =bool (obj .hide_get ())
        except Exception :
            cur =False 
        if cur !=hide :
            obj .hide_set (hide )
    except Exception :
        pass 


        # ------------------------------------------
        # 安全なオブジェクト判定
        # ------------------------------------------
def is_valid_obj (obj ):
    try :
        if obj and obj .name :return True 
    except :return False 
    return False 

    # ------------------------------------------
    # 高速化用 Numpy ヘルパー
    # ------------------------------------------
def _fast_get_selected_points (mesh_obj ,indices =None ):
    if not is_valid_obj (mesh_obj )or not getattr (mesh_obj ,"data",None ):
        return np .empty ((0 ,3 ),dtype =np .float32 )
    me =mesh_obj .data 
    v_count =len (me .vertices )
    if v_count ==0 :
        return np .empty ((0 ,3 ),dtype =np .float32 )

    co_arr =np .empty ((v_count ,3 ),dtype =np .float32 )
    me .vertices .foreach_get ("co",co_arr .ravel ())

    if indices is not None :
        valid_indices =[i for i in indices if i <v_count ]
        if not valid_indices :
            return np .empty ((0 ,3 ),dtype =np .float32 )
        return co_arr [valid_indices ]
    return co_arr 

def _fast_transform_points (points ,matrix ):
    if len (points )==0 :
        return points 
    mat =np .array (matrix ,dtype =np .float32 )
    points_4d =np .c_ [points ,np .ones (points .shape [0 ],dtype =np .float32 )]
    return (points_4d @mat .T )[:,:3 ]

def _sl_capture_selection (mesh_obj ):
    res ={"v":[],"e":[],"f":[]}
    if not is_valid_obj (mesh_obj )or mesh_obj .type !='MESH'or not getattr (mesh_obj ,"data",None ):
        return res 
    try :
        if mesh_obj .mode =='EDIT':
            bm =bmesh .from_edit_mesh (mesh_obj .data )
            res ["v"]=[v .index for v in bm .verts if v .select ]
            res ["e"]=[e .index for e in bm .edges if e .select ]
            res ["f"]=[f .index for f in bm .faces if f .select ]
            return res 
    except :pass 
    try :
        me =mesh_obj .data 
        res ["v"]=[v .index for v in me .vertices if v .select ]
        res ["e"]=[e .index for e in me .edges if e .select ]
        res ["f"]=[p .index for p in me .polygons if p .select ]
    except :pass 
    return res 

def _resolve_selection_to_verts (mesh_obj ,sel_dict ):
    verts =set (sel_dict .get ("v",[]))
    try :
        me =mesh_obj .data 
        for e_idx in sel_dict .get ("e",[]):
            try :
                e =me .edges [e_idx ]
                verts .add (e .vertices [0 ]);verts .add (e .vertices [1 ])
            except :pass 
        for f_idx in sel_dict .get ("f",[]):
            try :
                f =me .polygons [f_idx ]
                verts .update (f .vertices )
            except :pass 
    except :pass 
    return verts 

def _get_carrier_selection (main_obj ,carrier_obj ,live_sel_dicts ):
    try :
        live_sel_dicts =live_sel_dicts or {}
        if carrier_obj and getattr (carrier_obj ,'name','')in live_sel_dicts :
            live_sel_dict =live_sel_dicts .get (carrier_obj .name )or {'v':[],'e':[],'f':[]}
            return _resolve_selection_to_verts (carrier_obj ,live_sel_dict )
    except Exception :
        pass 

        # Prefer Smart Modifier selection cache API
    try :
        api =_sl_ms_api ()
        sel_get =api .get ("sel_get")
        if callable (sel_get ):
            carrier_key ="BASE"if carrier_obj ==main_obj else _sl_find_ep_modifier_name_for_edit_object (main_obj ,carrier_obj )
            sel_dict =sel_get (main_obj ,carrier_key )
            if sel_dict and any (sel_dict .values ()):
                return _resolve_selection_to_verts (carrier_obj ,sel_dict )
    except Exception :
        pass 

        # Legacy direct driver_namespace cache
    try :
        root =_sl_dn_get_dict ("_MS_SEL_CACHE")
        carrier_key ="BASE"if carrier_obj ==main_obj else _sl_find_ep_modifier_name_for_edit_object (main_obj ,carrier_obj )
        sel_dict =root .get (main_obj .name ,{}).get (carrier_key )
        if sel_dict and any (sel_dict .values ()):
            return _resolve_selection_to_verts (carrier_obj ,sel_dict )
    except Exception :
        pass 

        # Fallback: current live selection on carrier mesh
    res =set ()
    try :
        me =carrier_obj .data 
        res .update ([v .index for v in me .vertices if v .select ])
        for e in me .edges :
            if e .select :res .update (e .vertices )
        for p in me .polygons :
            if p .select :res .update (p .vertices )
    except Exception :
        pass 
    return res 

def _sl_shared_lock_active ():
    try :return bool (bpy .app .driver_namespace .get ("_MS_MODIFIER_STACK_SYNC_LOCK",False ))
    except :return False 

def _sl_dn_get_dict (name ):
    try :ns =bpy .app .driver_namespace 
    except :return {}
    d =ns .get (name )
    if d is None :
        d ={}
        ns [name ]=d 
    return d 

def _sl_find_ep_modifier_name_for_edit_object (main_obj ,edit_obj ):
    if not is_valid_obj (main_obj )or not is_valid_obj (edit_obj ):return None 
    try :
        for m in main_obj .modifiers :
            if is_ep_layer_check (m )and m .node_group :
                if m .node_group .get ("ep_edit_mesh")==edit_obj .name :
                    return m .name 
    except :pass 
    return None 

def _find_nearest_upper_carrier_object (main_obj ,target_idx ):
    if not is_valid_obj (main_obj )or main_obj .type !='MESH':
        return main_obj 
    mods =list (main_obj .modifiers )
    for i in range (target_idx -1 ,-1 ,-1 ):
        try :
            m =mods [i ]
            if not m .show_render :continue 
            if is_ep_layer_check (m ):
                ep_obj =_ep_get_edit_object (m )
                if ep_obj :return ep_obj 
        except :continue 
    return main_obj 

    # ------------------------------------------
    # Collection & General Management
    # ------------------------------------------
def ensure_modifier_system_collections (scene ):
    """Ensure SmartLattice_Collection exists under Modifier_System_Collection.

    IMPORTANT:
    - Do NOT create/move/remove EditPoly collections here (EditPoly manages its own helpers).
    - Do NOT unlink other collections from the scene root (can cause view-layer exclude issues).
    """
    if not scene :
        return (None ,None )
    parent_name ="Modifier_System_Collection"
    sl_name ="SmartLattice_Collection"

    parent =bpy .data .collections .get (parent_name )
    if not parent :
        try :
            parent =bpy .data .collections .new (parent_name )
        except Exception :
            parent =None 

    if parent :
        try :
            if parent .name not in {c .name for c in scene .collection .children }:
                scene .collection .children .link (parent )
        except Exception :
            pass 

    sl_col =bpy .data .collections .get (sl_name )
    if not sl_col :
        try :
            sl_col =bpy .data .collections .new (sl_name )
        except Exception :
            sl_col =None 

    if parent and sl_col :
        try :
            if sl_col .name not in {c .name for c in parent .children }:
                parent .children .link (sl_col )
        except Exception :
            pass 

    return parent ,sl_col 

def cleanup_modifier_system_collections ():
    """Legacy no-op.

    Collection cleanup is handled by each tool that owns the helpers.
    Removing shared collections here can conflict with EditPoly / Smart Modifier and cause instability.
    """
    return 

def get_main_object (obj ):
    if not is_valid_obj (obj ):return None 
    if "sl_main_target"in obj :
        main_name =obj ["sl_main_target"]
        if main_name in bpy .data .objects :return bpy .data .objects [main_name ]
    if "ep_main_target"in obj :
        main_name =obj ["ep_main_target"]
        if main_name in bpy .data .objects :return bpy .data .objects [main_name ]

    for o in bpy .data .objects :
        if o .type =='MESH'and o !=obj :
            for m in o .modifiers :
                if m .type =='NODES'and hasattr (m ,"node_group")and m .node_group :
                    if m .node_group .get ("ep_edit_mesh")==obj .name :
                        return o 

    if getattr (obj ,'type','')=='LATTICE':
        try :
            for cand in bpy .data .objects :
                if getattr (cand ,'type','')!='MESH' or cand ==obj :continue 
                for m in getattr (cand ,'modifiers',[]) :
                    if getattr (m ,'type','')=='LATTICE' and getattr (m ,'object',None )==obj :
                        return cand 
        except Exception :pass 
    # Ordinary parent-child relationships must not redirect the stack target.
    # Explicit helper markers above remain the only parented-helper resolution path.
    return obj 

def is_ep_layer_check (mod ):
    if not mod :return False 
    if mod .type =='NODES'and hasattr (mod ,"node_group")and mod .node_group :
        ng =mod .node_group 
        return (ng .get ("ep_edit_mesh")is not None )and (ng .get ("ep_frozen_mesh")is not None )
    return False 

def _ep_get_edit_object (mod ):
    if not is_ep_layer_check (mod ):return None 
    ng =mod .node_group 
    en =ng .get ("ep_edit_mesh")if ng else None 
    if en :return bpy .data .objects .get (en )
    return None 

def get_unique_vgroup_name (obj ,base_name ):
    name =base_name 
    if name not in obj .vertex_groups :return name 
    count =1 
    while name in obj .vertex_groups :
        name =f"{base_name }.{count :03d}"
        count +=1 
    return name 


def _sl_reset_vgroup (obj ,vg_name ):
    if not is_valid_obj (obj )or not vg_name :return None 
    try :
        vg =obj .vertex_groups .get (vg_name )
        if vg :obj .vertex_groups .remove (vg )
    except Exception :pass 
    try :return obj .vertex_groups .new (name =vg_name )
    except Exception :return None 


def _sl_assign_vgroup_indices (obj ,vg_name ,indices ,reset =True ):
    if not is_valid_obj (obj )or getattr (obj ,'type','')!='MESH'or not vg_name :return False 
    try :idx =sorted ({int (i )for i in (indices or [])if int (i )>=0 })
    except Exception :idx =[]
    if reset :vg =_sl_reset_vgroup (obj ,vg_name )
    else :
        try :vg =obj .vertex_groups .get (vg_name )or obj .vertex_groups .new (name =vg_name )
        except Exception :vg =None 
    if not vg :return False 
    try :
        n =len (getattr (getattr (obj ,'data',None ),'vertices',[])or [])
        idx =[i for i in idx if i <n ]
    except Exception :pass 
    try :
        if idx :vg .add (idx ,1.0 ,'REPLACE')
    except Exception :pass 
    return True 


def _sl_remove_vgroup_if_present (obj ,vg_name ):
    if not is_valid_obj (obj )or not vg_name :return 
    try :
        vg =obj .vertex_groups .get (vg_name )
        if vg :obj .vertex_groups .remove (vg )
    except Exception :pass 


def _sl_is_smart_lattice_tool_vgroup_name (name ):
    """Return True only for vertex groups generated by Smart Lattice.

    Current layers use names that mirror the logical modifier name
    (SmartLattice, SmartLattice.001, ...). Older bundled builds could also
    leave *_VG variants behind after apply. Do not match arbitrary user groups
    such as SmartLatticeMask.
    """
    nm =str (name or "")
    base ="SmartLattice"
    if not nm .startswith (base ):
        return False 
    suffix =nm [len (base ):]
    if suffix in ("","_VG"):
        return True 
    if suffix .endswith ("_VG"):
        suffix =suffix [:-3 ]
    if not suffix .startswith ("."):
        return False 
    parts =suffix [1 :].split (".")
    if not parts :
        return False 
    return all (p and len (p )==3 and p .isdigit ()for p in parts )


def _sl_collect_referenced_vertex_groups (obj ):
    used =set ()
    try :
        for m in getattr (obj ,"modifiers",[])or []:
            vg =str (getattr (m ,"vertex_group","")or "")
            if vg :
                used .add (vg )
    except Exception :
        pass 
    return used 


def _sl_prune_unused_smart_lattice_vertex_groups (obj ):
    """Remove only stale Smart Lattice-owned vertex groups on this mesh.

    Groups still referenced by any modifier are preserved so stacked Smart
    Lattice layers keep independent influence masks. Unreferenced groups left
    by a previous apply/remove are removed before a new layer builds its own
    mask.
    """
    try :
        if not is_valid_obj (obj )or getattr (obj ,"type","")!='MESH':
            return 
    except Exception :
        return 
    used =_sl_collect_referenced_vertex_groups (obj )
    to_remove =[]
    try :
        for vg in list (getattr (obj ,"vertex_groups",[])or []):
            nm =str (getattr (vg ,"name","")or "")
            if nm and nm not in used and _sl_is_smart_lattice_tool_vgroup_name (nm ):
                to_remove .append (nm )
    except Exception :
        to_remove =[]
    for nm in to_remove :
        try :
            vg =obj .vertex_groups .get (nm )
            if vg :
                obj .vertex_groups .remove (vg )
        except Exception :
            pass 


def _sl_get_current_carrier_selection (main_obj ,carrier_obj ,live_sel_dicts ,strict_live =False ):
    """Resolve vertices from the current Base/EditPoly carrier selection.

    When Smart Lattice is added from Edit Mesh, never fall back to an older
    Smart Modifier selection cache. This prevents a previous influence mask
    from being reused by the next new Smart Lattice.
    """
    if strict_live :
        try :
            if live_sel_dicts is not None and getattr (carrier_obj ,"name","")in live_sel_dicts :
                return _resolve_selection_to_verts (carrier_obj ,live_sel_dicts .get (carrier_obj .name )or {"v":[],"e":[],"f":[]})
        except Exception :
            return set ()
        return set ()
    return _get_carrier_selection (main_obj ,carrier_obj ,live_sel_dicts or {})

    # ------------------------------------------
    # Instance + Naming helpers
    # ------------------------------------------
_MS_INSTANCE_KEY ="ms_instance_id"
_MS_INST_MAP_KEY ="ms_instance_map"

def _sl_ms_mapping_like (value ):
    try :return value is not None and callable (getattr (value ,"keys",None ))and callable (getattr (value ,"get",None ))
    except Exception :return False 

def _sl_get_logical_used_names (obj ,base ):
    used =set ()
    if not is_valid_obj (obj )or not obj .modifiers :return used 
    for m in obj .modifiers :
        dn =None 
        items =getattr (obj ,"ms_instance_map_items",None )
        if items :
            for it in items :
                if it .mod_name ==m .name :
                    dn =it .disp_name ;break 
        name =dn if dn else m .name 
        if name ==base :used .add (base )
        elif name .startswith (base +"."):
            suf =name [len (base )+1 :]
            if len (suf )==3 and suf .isdigit ():used .add (name )
    return used 

def _sl_get_next_smartlattice_name (targets ,base ="SmartLattice"):
    """Pick a unique logical name for SmartLattice across targets.

    Prefer Smart Modifier API (logical name system) when available.
    """
    try :
        api =_sl_ms_api ()
        fn =api .get ("next_logical_default_name_across_objects")
        if callable (fn ):
            return str (fn (list (targets or []),str (base )))
    except Exception :
        pass 

        # Fallback (legacy)
    used =set ()
    for o in targets :
        if o and getattr (o ,"type","")=='MESH':
            used |=_sl_get_logical_used_names (o ,base )

    def _is_used (n ):
        if n in used :return True 
        if n in bpy .data .objects :return True 
        for o in targets :
            if o and getattr (o ,"type","")=='MESH':
                if n in o .modifiers :return True 
        return False 

    if not _is_used (base ):return base 
    for i in range (1 ,10000 ):
        cand =f"{base }.{i :03d}"
        if not _is_used (cand ):return cand 
    return f"{base }.{uuid .uuid4 ().hex [:3 ]}"

def _sl_ms_obj_set_instance_id (obj ,mod_name ,instance_id ,disp_name =None ):
# Prefer Smart Modifier API when available
    try :
        api =_sl_ms_api ()
        fn =api .get ("obj_set_instance_id")
        if callable (fn ):
            fn (obj ,mod_name ,instance_id ,disp_name =disp_name )
            return 
    except Exception :
        pass 

        # Fallback (legacy)
    if not is_valid_obj (obj )or not mod_name or not instance_id :return 
    iid =str (instance_id )
    dn =None if disp_name is None else str (disp_name )
    try :
        items =getattr (obj ,"ms_instance_map_items",None )
        if items is not None :
            found =next ((it for it in items if str (getattr (it ,"mod_name","")or "")==mod_name ),None )
            if found is None :
                found =items .add ()
                found .mod_name =mod_name 
            found .instance_id =iid 
            if dn is not None and hasattr (found ,"disp_name"):found .disp_name =dn 
    except :pass 
    try :
        m =obj .get (_MS_INST_MAP_KEY )
        if not _sl_ms_mapping_like (m ):
            try :
                if _MS_INST_MAP_KEY in obj .keys ():del obj [_MS_INST_MAP_KEY ]
            except Exception :pass 
            obj [_MS_INST_MAP_KEY ]={}
            m =obj .get (_MS_INST_MAP_KEY )
        if _sl_ms_mapping_like (m ):m [mod_name ]=iid 
    except :pass 
    try :
        mod =obj .modifiers .get (mod_name )
        if mod :mod [_MS_INSTANCE_KEY ]=iid 
    except :pass 

def _sl_ms_obj_set_disp_name (obj ,mod_name ,disp_name ):
# Prefer Smart Modifier API when available
    try :
        api =_sl_ms_api ()
        fn =api .get ("obj_set_disp_name")
        if callable (fn ):
            fn (obj ,mod_name ,disp_name )
            return 
    except Exception :
        pass 

        # Fallback (legacy)
    if not is_valid_obj (obj )or not mod_name or not disp_name :return 
    try :
        items =getattr (obj ,"ms_instance_map_items",None )
        if items is not None :
            found =next ((it for it in items if str (getattr (it ,"mod_name","")or "")==mod_name ),None )
            if not found :
                found =items .add ()
                found .mod_name =mod_name 
            if hasattr (found ,"disp_name"):found .disp_name =str (disp_name )
    except :pass 

def _cleanup_orphaned_lattices_and_vgs ():
    """Remove orphaned SmartLattice helper objects and unused SmartLattice vertex groups.

    Stability / performance rules:
    - No bpy.ops here (timers/handlers safe).
    - Only run in OBJECT mode (Edit modes can invalidate data edits).
    - Never touch objects that are still referenced by any LATTICE modifier.
    """
    try :
        if bpy .context .mode !='OBJECT':
            return 
    except Exception :
        return 

    used_lattices =set ()
    used_vgs ={}

    # Collect usage
    try :
        for o in bpy .data .objects :
            if not o or getattr (o ,"type","")!='MESH':
                continue 
            used_vgs [o .name ]=set ()
            for m in getattr (o ,"modifiers",[]):
                if getattr (m ,"type","")!='LATTICE':
                    continue 
                lat =getattr (m ,"object",None )
                if not is_valid_obj (lat ):
                    continue 
                if "sl_main_target"not in lat :
                    continue 
                used_lattices .add (lat .name )
                vg =getattr (m ,"vertex_group","")or ""
                if vg :
                    used_vgs [o .name ].add (vg )
    except Exception :
        pass 

    ctx =bpy .context 
    vl =getattr (ctx ,"view_layer",None )

    # 1) Remove orphaned lattices (tagged) that are not used by any modifier
    try :
        for lat_obj in list (bpy .data .objects ):
            try :
                if not lat_obj or getattr (lat_obj ,"type","")!='LATTICE':
                    continue 
                if "sl_main_target"not in lat_obj :
                    continue 
                if lat_obj .name in used_lattices :
                    continue 
                    # Ensure it is not the active object
                try :
                    if vl and vl .objects .active ==lat_obj :
                        vl .objects .active =None 
                except Exception :
                    pass 
                try :
                    lat_obj .hide_select =False 
                except Exception :
                    pass 
                try :
                    lat_obj .select_set (False )
                except Exception :
                    pass 
                try :
                    bpy .data .objects .remove (lat_obj ,do_unlink =True )
                except Exception :
                    pass 
            except Exception :
                continue 
    except Exception :
        pass 

        # 2) Remove unused SmartLattice vertex groups (only those created by this tool)
    try :
        for obj in bpy .data .objects :
            if not obj or getattr (obj ,"type","")!='MESH':
                continue 
            vgs_to_remove =[]
            try :
                for vg in getattr (obj ,"vertex_groups",[]):
                    nm =getattr (vg ,"name","")
                    if _sl_is_smart_lattice_tool_vgroup_name (nm )and nm not in used_vgs .get (obj .name ,set ()):
                        vgs_to_remove .append (nm )
            except Exception :
                vgs_to_remove =[]

            for vg_name in vgs_to_remove :
                try :
                    vg =obj .vertex_groups .get (vg_name )
                    if vg :
                        obj .vertex_groups .remove (vg )
                except Exception :
                    pass 
    except Exception :
        pass 

        # 3) Instance state cleanup: if a lattice is used by only one mesh, clear ms_instance_id mapping on that modifier
    try :
        for lat_name in list (used_lattices ):
            users =[]
            for o in bpy .data .objects :
                if not o or getattr (o ,"type","")!='MESH':
                    continue 
                for m in getattr (o ,"modifiers",[]):
                    if getattr (m ,"type","")!='LATTICE':
                        continue 
                    lat =getattr (m ,"object",None )
                    if lat and getattr (lat ,"name","")==lat_name :
                        users .append ((o ,m ))
                        break 
            if len (users )==1 :
                obj ,mod =users [0 ]
                try :
                    if _MS_INSTANCE_KEY in mod :
                        del mod [_MS_INSTANCE_KEY ]
                except Exception :
                    pass 
                try :
                    items =getattr (obj ,"ms_instance_map_items",None )
                    if items :
                        for i in range (len (items )-1 ,-1 ,-1 ):
                            if items [i ].mod_name ==mod .name :
                                items .remove (i )
                except Exception :
                    pass 
                try :
                    m_map =obj .get (_MS_INST_MAP_KEY )
                    if _sl_ms_mapping_like (m_map )and mod .name in m_map :
                        del m_map [mod .name ]
                except Exception :
                    pass 
    except Exception :
        pass 

def _do_cleanup_now ():
    _cleanup_orphaned_lattices_and_vgs ()
    return None 

def _sl_cleanup_timer ():
    """Deferred cleanup runner (lightweight, safe).

    Runs only when requested via driver_namespace flag and only in OBJECT mode.
    """
    try :
        if not bpy .app .driver_namespace .get ("_SL_NEED_CLEANUP",False ):
            return 1.0 
            # Defer while not in OBJECT mode (avoid conflicts with EditPoly / selection pinning)
        try :
            if bpy .context .mode !='OBJECT':
                return 0.25 
        except Exception :
            return 0.5 
        bpy .app .driver_namespace ["_SL_NEED_CLEANUP"]=False 
        _cleanup_orphaned_lattices_and_vgs ()
    except KeyboardInterrupt :
        try :
            bpy .app .driver_namespace ["_SL_NEED_CLEANUP"]=False 
        except Exception :
            pass 
        return 1.0 
    except Exception :
        pass 
def _sl_shared_refresh_token ():
    try :
        return float (bpy .app .driver_namespace .get ("_MS_FORCE_SL_SHARED_REFRESH_T",0.0 )or 0.0 )
    except Exception :
        return 0.0 


def _sl_deselect_all_lattice_points (lat_obj )->bool :
    try :
        if not lat_obj or getattr (lat_obj ,'type','')!='LATTICE':
            return False 
        lat_data =getattr (lat_obj ,'data',None )
        points =getattr (lat_data ,'points',None )
        if points is None :
            return False 
        changed =False 
        for point in points :
            for attr in ('select','select_control_point','select_u','select_v','select_w'):
                if not hasattr (point ,attr ):
                    continue 
                try :
                    if bool (getattr (point ,attr )):
                        setattr (point ,attr ,False )
                        changed =True 
                except Exception :
                    continue 
        try :
            if changed and hasattr (lat_data ,'update'):
                lat_data .update ()
        except Exception :
            pass 
        return changed 
    except Exception :
        return False 


class SLM_OT_add_layer (bpy .types .Operator ):
    bl_idname ="smart_lattice.add_layer"
    bl_label ='Add Smart Lattice'
    bl_description =(
    'Add Smart Lattice (a helper system that makes lattice deformation easier) to the selected mesh.\n\n- Automatically creates a Lattice and the required helper objects/collections.\n- Places the lattice to fit the mesh size.\n- Lets you choose the resolution (U/V/W divisions) to control deformation detail.\n\nTip: Higher resolution is heavier—start low and increase only if needed.'




    )
    bl_options ={'UNDO'}

    resolution_type :bpy .props .EnumProperty (
    name ='Resolution',
    description =(
    'Set the lattice divisions (U/V/W).\nChoose a preset (2/3/4) or Custom.\n\nNote: Higher values allow finer deformation but are heavier.'


    ),
    items =[
    ('2',"2 x 2 x 2",'Coarse (lightweight)'),
    ('3',"3 x 3 x 3",'Standard'),
    ('4',"4 x 4 x 4",'Fine (heavier)'),
    ('CUSTOM','Custom','Specify U/V/W separately'),
    ],
    default ='4'
    )
    res_u :bpy .props .IntProperty (name ="U",description ='Number of divisions in U (mainly X) direction.',default =4 ,min =2 ,max =64 )
    res_v :bpy .props .IntProperty (name ="V",description ='Number of divisions in V (mainly Y) direction.',default =4 ,min =2 ,max =64 )
    res_w :bpy .props .IntProperty (name ="W",description ='Number of divisions in W (mainly Z) direction.',default =4 ,min =2 ,max =64 )

    def invoke (self ,context ,event ):
        return context .window_manager .invoke_props_dialog (self )

    def draw (self ,context ):
        layout =self .layout 
        layout .prop (self ,"resolution_type")
        if self .resolution_type =='CUSTOM':
            row =layout .row (align =True )
            row .prop (self ,"res_u");row .prop (self ,"res_v");row .prop (self ,"res_w")

    def execute (self ,context ):
        _sl_request_live_runtime ()
        if self .resolution_type !='CUSTOM':
            self .res_u =self .res_v =self .res_w =int (self .resolution_type )

        pre_selected =list (getattr (context ,"selected_objects",[])or [])
        pre_active =getattr (context ,"active_object",None )
        pre_objects_in_mode =list (getattr (context ,"objects_in_mode",[])or [])if context .mode =='EDIT_MESH'else []

        live_sel_dicts ={}
        if context .mode =='EDIT_MESH':
            for o in pre_objects_in_mode :
                if o .type =='MESH':
                    live_sel_dicts [o .name ]=_sl_capture_selection (o )

                    # Determine targets/anchor from the snapshot BEFORE switching modes (mode switch can change selection).
        raw_src =pre_objects_in_mode if (context .mode =='EDIT_MESH'and pre_objects_in_mode )else pre_selected 
        raw_targets =[get_main_object (o )for o in raw_src if o and o .type =='MESH']
        anchor =get_main_object (pre_active )

        if context .mode !='OBJECT':
            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')

        targets =[]
        seen =set ()
        for t in raw_targets :
            if is_valid_obj (t )and t .name not in seen :
                targets .append (t )
                seen .add (t .name )

        if not targets :
            if is_valid_obj (anchor )and anchor .type =='MESH':
                targets =[anchor ]
            else :
                self .report ({'WARNING'},t ('Please select a mesh object.'))
                return {'CANCELLED'}

        if anchor not in targets :
            anchor =targets [0 ]

        _ms_lock_fn =None 
        _ms_prev_lock =False 
        try :
            _api =_sl_ms_api ()
            _ms_lock_fn =_api .get ("shared_lock_set")
            if callable (_ms_lock_fn ):
                _ms_prev_lock =bool (bpy .app .driver_namespace .get ("_MS_MODIFIER_STACK_SYNC_LOCK",False ))
                _ms_lock_fn (True )
        except :pass 

        try :
            mat_anchor_inv =anchor .matrix_world .inverted ()
            all_points_world =[]
            selection_info ={}
            target_idx_info ={}

            target_data_list =[]
            any_selection_exists =False 

            for obj in targets :
                active_id =obj .get ("ui_active_item","BASE")
                if is_valid_obj (context .active_object )and context .active_object !=obj :
                    ep_mod_name =_sl_find_ep_modifier_name_for_edit_object (obj ,context .active_object )
                    if ep_mod_name :
                        active_id =ep_mod_name 

                if active_id =="BASE":
                    target_idx =0 
                else :
                    aidx =obj .modifiers .find (active_id )
                    if aidx >=0 :
                        target_idx =aidx +1 
                    else :
                        target_idx =len (obj .modifiers )

                target_idx_info [obj .name ]=target_idx 

                carrier_obj =_find_nearest_upper_carrier_object (obj ,target_idx )
                sel_indices =_get_carrier_selection (obj ,carrier_obj ,live_sel_dicts )

                if sel_indices :
                    any_selection_exists =True 

                target_data_list .append ((obj ,carrier_obj ,sel_indices ))

            for obj ,carrier_obj ,sel_indices in target_data_list :
                mat_world =carrier_obj .matrix_world 

                if any_selection_exists :
                    if sel_indices :
                        idx_list =list (sel_indices )
                        selection_info [obj .name ]=idx_list 
                        coords =_fast_get_selected_points (carrier_obj ,idx_list )
                        all_points_world .append (_fast_transform_points (coords ,mat_world ))
                    else :
                        selection_info [obj .name ]=[]
                else :
                    selection_info [obj .name ]=None 
                    bbox =np .array (carrier_obj .bound_box ,dtype =np .float32 )
                    all_points_world .append (_fast_transform_points (bbox ,mat_world ))

            if not all_points_world :
                return {'CANCELLED'}

            try :
                merged_pts =np .vstack (all_points_world )
                if len (merged_pts )==0 :return {'CANCELLED'}
                min_arr ,max_arr =np .min (merged_pts ,axis =0 ),np .max (merged_pts ,axis =0 )
                center_world =(mathutils .Vector (min_arr )+mathutils .Vector (max_arr ))/2.0 
                size_world =mathutils .Vector (max_arr )-mathutils .Vector (min_arr )
                size_world .x =max (size_world .x ,0.01 );size_world .y =max (size_world .y ,0.01 );size_world .z =max (size_world .z ,0.01 )
            except :
                return {'CANCELLED'}

            is_multi =len (targets )>1 
            lat_name =_sl_get_next_smartlattice_name (targets ,base ="SmartLattice")

            lat_data =bpy .data .lattices .new (f"{lat_name }_Data")
            lat_obj =bpy .data .objects .new (lat_name ,lat_data )

            _ ,sl_col =ensure_modifier_system_collections (context .scene )
            try :sl_col .objects .link (lat_obj )
            except :pass 

            lat_data .points_u =self .res_u ;lat_data .points_v =self .res_v ;lat_data .points_w =self .res_w 
            lat_data .interpolation_type_u =lat_data .interpolation_type_v =lat_data .interpolation_type_w ='KEY_BSPLINE'
            lat_data .use_outside =False 

            lat_obj .parent =None 
            lat_obj .location =center_world 
            lat_obj .scale =size_world 
            try :lat_obj .rotation_euler =(0.0 ,0.0 ,0.0 )
            except :pass 

            lat_obj .parent =anchor 
            lat_obj .matrix_parent_inverse =anchor .matrix_world .inverted ()

            try :lat_obj ["sl_main_target"]=anchor .name 
            except :pass 
            try :_sl_register_lat_user (lat_obj .name ,anchor .name )
            except Exception :pass 
            try :lat_obj ["_ms_deselect_lattice_points_once"]=True 
            except Exception :pass 

            instance_id =uuid .uuid4 ().hex if is_multi else ""
            created_mod_anchor =None 
            carrier_by_name ={}
            try :
                carrier_by_name ={_o .name :_c for (_o ,_c ,_s )in target_data_list if _o and _c }
            except Exception :carrier_by_name ={}

            for obj in targets :
                target_idx =target_idx_info [obj .name ]
                indices =selection_info .get (obj .name )
                carrier_obj =carrier_by_name .get (obj .name ,obj )
                vg_name =None 

                if indices is not None :
                    try :
                        vg_name =get_unique_vgroup_name (obj ,lat_name )
                        _sl_assign_vgroup_indices (obj ,vg_name ,indices ,reset =True )
                        try :
                            if carrier_obj and carrier_obj !=obj and getattr (carrier_obj ,'type','')=='MESH':
                                _sl_assign_vgroup_indices (carrier_obj ,vg_name ,indices ,reset =True )
                        except Exception :pass 
                    except Exception :vg_name =None 

                try :mod =obj .modifiers .new (name =lat_name ,type ='LATTICE')
                except :continue 

                mod .object =lat_obj 
                mod .show_in_editmode =True 
                mod .show_on_cage =True 
                if vg_name :mod .vertex_group =vg_name 

                try :
                    cur =obj .modifiers .find (mod .name )
                    if cur >=0 :obj .modifiers .move (cur ,max (0 ,min (target_idx ,len (obj .modifiers )-1 )))
                except :pass 

                if instance_id :_sl_ms_obj_set_instance_id (obj ,mod .name ,instance_id ,disp_name =lat_name )
                else :_sl_ms_obj_set_disp_name (obj ,mod .name ,lat_name )

                try :obj ["ui_active_item"]=mod .name 
                except :pass 
                try :obj .modifiers .active =mod 
                except :pass 
                try :obj .update_tag ()
                except :pass 

                if obj ==anchor :created_mod_anchor =mod 

            if not created_mod_anchor :return {'CANCELLED'}

            if hasattr (bpy .ops .object ,"ms_switch_level"):
                try :
                    with context .temp_override (active_object =anchor ,selected_objects =targets ,object =anchor ):
                        bpy .ops .object .ms_switch_level ('EXEC_DEFAULT', False, target_mod_name =created_mod_anchor .name ,target_obj_name =anchor .name )
                except :
                    try :
                        bpy .ops .object .ms_switch_level ('EXEC_DEFAULT', False, target_mod_name =created_mod_anchor .name ,target_obj_name =anchor .name )
                    except :
                        pass 

                        # NOTE:
                        # Smart Modifier intentionally disables 'interactive' mode switching while multi-selection is active.
                        # SmartLattice multi-add must still enter EDIT_LATTICE on the created lattice, so we do it here.
                if is_multi :
                    try :
                        lat_obj .hide_set (False )
                        lat_obj .hide_viewport =False 
                        lat_obj .hide_select =False 
                    except Exception :
                        pass 
                    try :
                        if not lat_obj .select_get ():
                            lat_obj .select_set (True )
                    except Exception :
                        pass 
                    try :
                        context .view_layer .objects .active =lat_obj 
                    except Exception :
                        pass 
                    try :
                        if bpy .ops .object .mode_set .poll ():
                            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
                    except Exception :
                        pass 
                    try :
                        _sl_deselect_all_lattice_points (lat_obj )
                    except Exception :
                        pass 
                    try :
                        lat_obj .pop ("_ms_deselect_lattice_points_once",None )
                    except Exception :
                        pass 
            else :
                try :
                    if bpy .ops .object .select_all .poll ():bpy .ops .object .select_all ('EXEC_DEFAULT', False, action ='DESELECT')
                    lat_obj .hide_set (False )
                    lat_obj .hide_select =False 
                    context .view_layer .objects .active =lat_obj 
                    lat_obj .select_set (True )
                    for obj in targets :
                        obj .select_set (True )
                    if bpy .ops .object .mode_set .poll ():bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
                    try :
                        _sl_deselect_all_lattice_points (lat_obj )
                    except Exception :
                        pass 
                    try :
                        lat_obj .pop ("_ms_deselect_lattice_points_once",None )
                    except Exception :
                        pass 
                except :pass 

            return {'FINISHED'}

        finally :
            if _ms_lock_fn :
                try :_ms_lock_fn (_ms_prev_lock )
                except :pass 

                # ==========================================
                # 1.5 影響範囲 更新オペレーター
                # ==========================================
class SLM_OT_update_influence (bpy .types .Operator ):
    bl_idname ="smart_lattice.update_influence"
    bl_label ='Update Influence'
    bl_description =(
    'Recalculate Smart Lattice influence (the lattice-to-mesh deformation range).\n\n- Use this after changing the lattice size/position if deformation is offset or not working.\n- Automatically detects and updates the target Smart Lattice.\n\nTip: Applying/confirming lattice edits first tends to be more stable.'



    )
    bl_options ={'UNDO'}

    main_obj_name :bpy .props .StringProperty (default ="",description ='Main object name (internal)')
    modifier_name :bpy .props .StringProperty (default ="",description ='Modifier name (internal)')

    def execute (self ,context ):
        _sl_request_live_runtime ()
        main_obj =bpy .data .objects .get (self .main_obj_name )if self .main_obj_name else None 
        mod =None 

        if not is_valid_obj (main_obj ):
            obj =context .object 
            if is_valid_obj (obj )and obj .type =='MESH':main_obj =obj 

        if main_obj :
            if self .modifier_name :
                mod =main_obj .modifiers .get (self .modifier_name )
            else :
                am =getattr (main_obj .modifiers ,"active",None )
                if am and am .type =='LATTICE'and am .object and "sl_main_target"in am .object :mod =am 

        if (not is_valid_obj (main_obj )or not mod )and getattr (context .active_object ,"type","")=='LATTICE':
            lat_active =context .active_object 
            if "sl_main_target"in lat_active :
                main_obj =bpy .data .objects .get (lat_active ["sl_main_target"])
                if is_valid_obj (main_obj ):
                    for m in main_obj .modifiers :
                        if m .type =='LATTICE'and getattr (m ,"object",None )==lat_active :
                            mod =m ;break 

        if not is_valid_obj (main_obj )or not mod or mod .type !='LATTICE'or not getattr (mod ,"object",None ):
            self .report ({'WARNING'},t ('No valid lattice found.'))
            return {'CANCELLED'}

        lat_obj =mod .object 

        live_sel_dicts ={}
        if context .mode =='EDIT_MESH':
            for o in context .objects_in_mode :
                if o .type =='MESH':
                    live_sel_dicts [o .name ]=_sl_capture_selection (o )

        if context .mode !='OBJECT':
            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')

        shared_users =[]
        for o in bpy .data .objects :
            if o .type =='MESH':
                for m in o .modifiers :
                    if m .type =='LATTICE'and getattr (m ,"object",None )==lat_obj :
                        shared_users .append ((o ,m ))
                        break 

        all_pts_world =[]
        any_selection_exists =False 

        target_datas =[]
        for o ,m in shared_users :
            t_idx =o .modifiers .find (m .name )
            c_obj =_find_nearest_upper_carrier_object (o ,t_idx )
            s_idx =_get_carrier_selection (o ,c_obj ,live_sel_dicts )
            if s_idx :any_selection_exists =True 
            target_datas .append ((o ,m ,c_obj ,s_idx ))

        for o ,m ,c_obj ,s_idx in target_datas :
            vg_name =m .vertex_group 
            if vg_name :
                _sl_remove_vgroup_if_present (o ,vg_name )
                try :
                    if c_obj and c_obj !=o and getattr (c_obj ,'type','')=='MESH':
                        _sl_remove_vgroup_if_present (c_obj ,vg_name )
                except Exception :pass 

            vg_name =get_unique_vgroup_name (o ,f"{m .name }_VG")
            _sl_assign_vgroup_indices (o ,vg_name ,s_idx ,reset =True )
            try :
                if c_obj and c_obj !=o and getattr (c_obj ,'type','')=='MESH':
                    _sl_assign_vgroup_indices (c_obj ,vg_name ,s_idx ,reset =True )
            except Exception :pass 
            m .vertex_group =vg_name 

            mat_w =c_obj .matrix_world 
            if any_selection_exists :
                if s_idx :
                    coords =_fast_get_selected_points (c_obj ,list (s_idx ))
                    all_pts_world .append (_fast_transform_points (coords ,mat_w ))
            else :
                bbox =np .array (c_obj .bound_box ,dtype =np .float32 )
                all_pts_world .append (_fast_transform_points (bbox ,mat_w ))

        if len (all_pts_world )>0 :
            merged_pts =np .vstack (all_pts_world )
            if len (merged_pts )>0 :
                min_co =mathutils .Vector (np .min (merged_pts ,axis =0 ))
                max_co =mathutils .Vector (np .max (merged_pts ,axis =0 ))
                center_world =(min_co +max_co )/2.0 
                size_world =max_co -min_co 
                size_world .x =max (size_world .x ,0.01 );size_world .y =max (size_world .y ,0.01 );size_world .z =max (size_world .z ,0.01 )

                data_min ,data_max =mathutils .Vector ((1e18 ,1e18 ,1e18 )),mathutils .Vector ((-1e18 ,-1e18 ,-1e18 ))
                pts =getattr (lat_obj .data ,"points",None )
                if pts :
                    for p in pts :
                        co =getattr (p ,"co_deform",None )or getattr (p ,"co",None )
                        if not co :continue 
                        data_min .x ,data_max .x =min (data_min .x ,co .x ),max (data_max .x ,co .x )
                        data_min .y ,data_max .y =min (data_min .y ,co .y ),max (data_max .y ,co .y )
                        data_min .z ,data_max .z =min (data_min .z ,co .z ),max (data_max .z ,co .z )

                if data_min .x >data_max .x :
                    data_min ,data_max =mathutils .Vector ((-0.5 ,-0.5 ,-0.5 )),mathutils .Vector ((0.5 ,0.5 ,0.5 ))

                data_center =(data_min +data_max )*0.5 
                data_size =data_max -data_min 
                data_size .x =max (abs (data_size .x ),1e-6 );data_size .y =max (abs (data_size .y ),1e-6 );data_size .z =max (abs (data_size .z ),1e-6 )

                scale =mathutils .Vector ((size_world .x /data_size .x ,size_world .y /data_size .y ,size_world .z /data_size .z ))

                lat_obj .parent =None 
                try :lat_obj .rotation_euler =(0.0 ,0.0 ,0.0 )
                except :pass 
                lat_obj .scale =scale 
                loc =mathutils .Vector ((
                center_world .x -(data_center .x *scale .x ),
                center_world .y -(data_center .y *scale .y ),
                center_world .z -(data_center .z *scale .z )
                ))
                lat_obj .location =loc 

                lat_obj .parent =main_obj 
                lat_obj .matrix_parent_inverse =main_obj .matrix_world .inverted ()

        for o ,m ,c_obj ,s_idx in target_datas :
            try :o .update_tag ()
            except Exception :pass 
            except :pass 
        try :lat_obj .update_tag ()
        except :pass 

        self .report ({'INFO'},iface_ ("Smart Lattice updated: synced selection state for all linked users."))
        return {'FINISHED'}

        # ==========================================
        # 2. Smart_Mesh_Overlay 連携描画
        # ==========================================
def get_smo_prefs (context ):
    return None 

_smo_shader =None 
def get_overlay_shader ():
    global _smo_shader 
    if _smo_shader :return _smo_shader 
    vert_code ="""
        void main() {
            gl_Position = u_mvpMatrix * vec4(pos, 1.0);
            gl_PointSize = u_pointSize;
            gl_Position.z -= u_zOffset * gl_Position.w;
        }
    """
    frag_code ="void main() { fragColor = u_color; }"
    try :
        from gpu .types import GPUShaderCreateInfo 
        info =GPUShaderCreateInfo ()
        info .push_constant ('MAT4',"u_mvpMatrix");info .push_constant ('FLOAT',"u_zOffset")
        info .push_constant ('FLOAT',"u_pointSize");info .push_constant ('VEC4',"u_color")
        info .vertex_in (0 ,'VEC3',"pos");info .fragment_out (0 ,'VEC4',"fragColor")
        info .vertex_source (vert_code );info .fragment_source (frag_code )
        _smo_shader =gpu .shader .create_from_info (info )
    except :pass 
    return _smo_shader 


def _sl_safe_float(value, default=0.0):
    try:
        f = float(value)
    except Exception:
        return float(default)
    try:
        if f != f:
            return float(default)
    except Exception:
        return float(default)
    return f


def _sl_safe_bool(obj, attr, default=False):
    try:
        if obj is not None and hasattr(obj, attr):
            return bool(getattr(obj, attr))
    except Exception:
        pass
    return bool(default)


def _sl_safe_color3(obj, attr, default):
    try:
        value = getattr(obj, attr)
        if value is not None and len(value) >= 3:
            return (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        pass
    try:
        return (float(default[0]), float(default[1]), float(default[2]))
    except Exception:
        return (1.0, 1.0, 1.0)


def _sl_view_is_xray(context):
    try:
        sh = getattr(getattr(context, 'space_data', None), 'shading', None)
        if sh is None:
            return False
        if str(getattr(sh, 'type', '') or '') == 'WIREFRAME':
            return bool(getattr(sh, 'show_xray_wireframe', False))
        enabled = bool(getattr(sh, 'show_xray', False))
        try:
            if float(getattr(sh, 'xray_alpha', 1.0)) <= 0.0:
                enabled = False
        except Exception:
            pass
        return enabled
    except Exception:
        return False


def _sl_depth_direction(rv3d):
    try:
        from mathutils import Vector
        mat = getattr(rv3d, 'window_matrix', None)
        if mat is None:
            return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False
        def _project(z_value):
            try:
                v = mat @ Vector((0.0, 0.0, float(z_value), 1.0))
                w = float(v.w)
                if abs(w) <= 1.0e-20:
                    return None
                return float(v.z) / w
            except Exception:
                return None
        for near_z, far_z in ((-1.0, -2.0), (-0.01, -100.0), (-0.1, -1000.0)):
            near = _project(near_z)
            far = _project(far_z)
            if near is None or far is None:
                continue
            delta = near - far
            if abs(delta) <= 1.0e-12:
                continue
            if delta > 0.0:
                return 'GREATER_EQUAL', 'LESS_EQUAL', -1.0, True
            return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False
    except Exception:
        pass
    return 'LESS_EQUAL', 'GREATER_EQUAL', 1.0, False


def _sl_visible_depth_test(rv3d, visible_test, strict=False):
    if not strict:
        return visible_test
    try:
        if bool(getattr(rv3d, 'is_perspective', False)):
            return visible_test
    except Exception:
        return visible_test
    if visible_test == 'LESS_EQUAL':
        return 'LESS'
    if visible_test == 'GREATER_EQUAL':
        return 'GREATER'
    return visible_test


def _sl_strict_occluded_depth_test(occluded_test):
    if occluded_test == 'GREATER_EQUAL':
        return 'GREATER'
    if occluded_test == 'LESS_EQUAL':
        return 'LESS'
    return occluded_test


def _sl_lattice_overlay_draw_state(context, prefs):
    """Resolve Smart Overlay Suite draw-time optimization settings for the FFD mesh guide."""
    is_xray = _sl_view_is_xray(context)
    occ_mode = 'XRAY_ONLY'
    try:
        occ_mode = str(getattr(prefs, 'occluded_display_mode', 'XRAY_ONLY') or 'XRAY_ONLY')
    except Exception:
        pass
    do_occ_pass = (occ_mode == 'ALWAYS') or (occ_mode == 'XRAY_ONLY' and is_xray)
    if occ_mode == 'NEVER':
        do_occ_pass = False
    if _sl_safe_bool(prefs, 'hide_occluded_colors_when_xray_off', True) and not is_xray:
        do_occ_pass = False
    if _sl_safe_bool(prefs, 'optimization_lightest_disable_occluded_pass', False):
        do_occ_pass = False
    show_occ_faces = _sl_safe_bool(prefs, 'show_occ_faces', True)
    show_vis_faces = _sl_safe_bool(prefs, 'show_vis_faces', True)
    hide_visible_when_occ_off = _sl_safe_bool(prefs, 'hide_visible_occluded_when_occluded_off', False)
    hide_visible_occluded_now = bool(hide_visible_when_occ_off and (not do_occ_pass or not show_occ_faces))
    occ_style = ''
    try:
        occ_style = str(getattr(prefs, 'occluded_style', 'FADE_THIN') or 'FADE_THIN')
    except Exception:
        occ_style = 'FADE_THIN'
    occ_alpha_mul = _sl_safe_float(getattr(prefs, 'occluded_alpha_mul', 0.45), 0.45) if ('FADE' in occ_style) else 1.0
    occ_alpha_mul = max(0.0, min(1.0, occ_alpha_mul))
    use_all_occluders = _sl_safe_bool(prefs, 'use_all_objects_as_occluders', False)
    return {
        'is_xray': is_xray,
        'do_occ_pass': bool(do_occ_pass and show_occ_faces),
        'show_vis_faces': show_vis_faces,
        'show_occ_faces': show_occ_faces,
        'hide_visible_occluded_now': hide_visible_occluded_now,
        'occ_alpha_mul': occ_alpha_mul,
        'use_all_occluders': use_all_occluders,
    }


def _sl_overlay_ndc_bias(prefs, attr, *, fallback=5.0e-5, all_occluders=False, xray=False):
    """Convert Smart Overlay depth setting into the simple clip-space shader used by Smart Lattice."""
    raw = _sl_safe_float(getattr(prefs, attr, fallback), fallback)
    if raw <= 0.0:
        base = 0.0
    elif raw < 0.05:
        base = raw * 0.04
    else:
        base = raw * 1.0e-4
    min_bias = 2.0e-5 if xray else 5.0e-5
    if all_occluders:
        min_bias = max(min_bias, 2.5e-4)
    if raw > 0.0:
        base = max(base, min_bias)
    return max(0.0, min(1.5e-3, base))



def _sl_external_smart_overlay_mesh_modules_for_patch():
    """Return loaded Smart Overlay Suite mesh modules without modifying their files."""
    modules = []
    preferred = (
        'bl_ext.user_default.smart_overlay_suite.mesh',
        'smart_overlay_suite.mesh',
        'Smart_Overlay_Suite.mesh',
    )
    for name in preferred:
        try:
            mod = sys.modules.get(name)
            if mod is not None and mod not in modules:
                modules.append(mod)
        except Exception:
            pass
    try:
        for name, mod in list(sys.modules.items()):
            try:
                lname = str(name or '').lower()
                if lname.endswith('.mesh') and 'overlay' in lname and 'suite' in lname and mod is not None and mod not in modules:
                    modules.append(mod)
            except Exception:
                continue
    except Exception:
        pass
    return tuple(modules)


def _sl_collect_active_lattice_overlay_target_names(context=None):
    """Collect Smart Lattice/FFD target meshes for the current lattice edit session."""
    names = set()
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context
    try:
        lat_obj = getattr(ctx, 'active_object', None)
    except Exception:
        lat_obj = None
    if lat_obj is None:
        return names
    try:
        if str(getattr(lat_obj, 'type', '') or '') != 'LATTICE':
            return names
    except Exception:
        return names
    try:
        if str(getattr(ctx, 'mode', '') or '') != 'EDIT_LATTICE':
            return names
    except Exception:
        pass
    try:
        main_name = str(lat_obj.get('sl_main_target', '') or '')
        if main_name:
            names.add(main_name)
    except Exception:
        pass
    try:
        scene = getattr(ctx, 'scene', None)
        objects = tuple(getattr(scene, 'objects', ()) or ()) if scene is not None else tuple(getattr(bpy.data, 'objects', ()) or ())
    except Exception:
        objects = tuple(getattr(bpy.data, 'objects', ()) or ())
    for obj in objects:
        try:
            if str(getattr(obj, 'type', '') or '') != 'MESH':
                continue
        except Exception:
            continue
        try:
            for mod in getattr(obj, 'modifiers', ()) or ():
                try:
                    if str(getattr(mod, 'type', '') or '') == 'LATTICE' and getattr(mod, 'object', None) is lat_obj:
                        obj_name = str(getattr(obj, 'name', '') or '')
                        if obj_name:
                            names.add(obj_name)
                        break
                except Exception:
                    continue
        except Exception:
            continue
    return names


def _sl_should_exclude_from_sos_extra_occluders(context, obj):
    """Keep the FFD target mesh out of Smart Overlay's all-object occluder pass."""
    if obj is None:
        return False
    try:
        obj_name = str(getattr(obj, 'name', '') or '')
    except Exception:
        obj_name = ''
    if not obj_name:
        return False
    try:
        return obj_name in _sl_collect_active_lattice_overlay_target_names(context)
    except Exception:
        return False


def _sl_install_smart_overlay_occluder_patch():
    """Runtime-only Smart Overlay compatibility patch.

    Smart Overlay Suite is not edited.  Smart Modifier wraps the loaded runtime
    function so Smart Lattice/FFD target meshes are not treated as external
    all-object occluders while the lattice cage is being edited.
    """
    for mod in _sl_external_smart_overlay_mesh_modules_for_patch():
        try:
            if bool(getattr(mod, '_sms_lattice_occluder_patch_installed', False)):
                continue
        except Exception:
            pass
        try:
            original = getattr(mod, '_sos_object_is_extra_depth_occluder', None)
            if not callable(original):
                continue
        except Exception:
            continue
        try:
            def _sms_wrapped_sos_object_is_extra_depth_occluder(*args, __sms_original=original, **kwargs):
                try:
                    ctx = args[0] if len(args) >= 1 else kwargs.get('context', None)
                    obj = args[1] if len(args) >= 2 else kwargs.get('obj', None)
                    if _sl_should_exclude_from_sos_extra_occluders(ctx, obj):
                        return False
                except Exception:
                    pass
                try:
                    return __sms_original(*args, **kwargs)
                except Exception:
                    return False
            try:
                setattr(mod, '_sms_lattice_occluder_patch_original', original)
            except Exception:
                pass
            setattr(mod, '_sos_object_is_extra_depth_occluder', _sms_wrapped_sos_object_is_extra_depth_occluder)
            setattr(mod, '_sms_lattice_occluder_patch_installed', True)
        except Exception:
            continue


def _sl_uninstall_smart_overlay_occluder_patch():
    """Restore Smart Overlay runtime functions wrapped by Smart Modifier."""
    for mod in _sl_external_smart_overlay_mesh_modules_for_patch():
        try:
            if not bool(getattr(mod, '_sms_lattice_occluder_patch_installed', False)):
                continue
        except Exception:
            continue
        try:
            original = getattr(mod, '_sms_lattice_occluder_patch_original', None)
            if callable(original):
                setattr(mod, '_sos_object_is_extra_depth_occluder', original)
        except Exception:
            pass
        for attr in ('_sms_lattice_occluder_patch_original', '_sms_lattice_occluder_patch_installed'):
            try:
                delattr(mod, attr)
            except Exception:
                pass

_draw_handler =None 

def draw_lattice_overlay ():
    if not _sl_runtime_live_enabled ():
        return 
    context =bpy .context 
    try :_sl_install_smart_overlay_occluder_patch ()
    except Exception :pass 
    if context .mode !='EDIT_LATTICE':return 

    lat_obj =context .active_object 
    if not is_valid_obj (lat_obj )or lat_obj .type !='LATTICE':return 

    if not _sl_smart_overlay_runtime_enabled(context):
        return
    smo_prefs =get_smo_prefs (context )
    if not smo_prefs :return 
    show_faces =bool (getattr (smo_prefs ,'show_faces_edit',False ))
    show_edges =False 
    if not show_faces and not show_edges :return 

    shader =get_overlay_shader ()
    if not shader :return 

    depsgraph =context .evaluated_depsgraph_get ()

    shared_meshes =[]
    for o in bpy .data .objects :
        if o .type =='MESH':
            for m in o .modifiers :
                if m .type =='LATTICE'and getattr (m ,"object",None )==lat_obj :
                    shared_meshes .append (o )
                    break 

    if not shared_meshes and "sl_main_target"in lat_obj :
        mo =bpy .data .objects .get (lat_obj ["sl_main_target"])
        if mo :shared_meshes .append (mo )

    # These values depend only on the current viewport and preferences, not on
    # a target mesh.  Calculate them once so instanced/shared lattice targets
    # issue identical geometry commands without repeating CPU-only work.
    rv3d =context .region_data 
    if not rv3d :return 
    view_proj_mat =rv3d .window_matrix @rv3d .view_matrix 
    depth_vis ,depth_occ ,offset_sign ,_reversed_z =_sl_depth_direction (rv3d )
    draw_state =_sl_lattice_overlay_draw_state (context ,smo_prefs )
    is_xray =bool (draw_state .get ('is_xray',False ))
    all_occluders =bool (draw_state .get ('use_all_occluders',False ))
    f_mag =_sl_overlay_ndc_bias (smo_prefs ,'face_depth_offset',fallback =5.0e-5 ,all_occluders =all_occluders ,xray =is_xray )
    e_mag =_sl_overlay_ndc_bias (smo_prefs ,'edge_depth_offset',fallback =5.0e-5 ,all_occluders =all_occluders ,xray =is_xray )
    f_off =offset_sign *f_mag 
    e_off =offset_sign *e_mag 
    if bool (draw_state .get ('hide_visible_occluded_now',False )):
        f_off =0.0 
        e_off =0.0 
    opacity =max (0.0 ,min (1.0 ,_sl_safe_float (getattr (smo_prefs ,'opacity',0.16 ),0.16 )))
    fcv =(*_sl_safe_color3 (smo_prefs ,'face_color',(0.09 ,0.63 ,1.0 )),opacity )
    fco =(*_sl_safe_color3 (smo_prefs ,'face_occluded_color',_sl_safe_color3 (smo_prefs ,'face_color',(0.09 ,0.63 ,1.0 ))),opacity *max (0.0 ,min (1.0 ,_sl_safe_float (draw_state .get ('occ_alpha_mul',0.45 ),0.45 ))))
    ecv =(*_sl_safe_color3 (smo_prefs ,'edge_color',(0.96 ,0.98 ,1.0 )),1.0 )
    eco =(*_sl_safe_color3 (smo_prefs ,'edge_occluded_color',_sl_safe_color3 (smo_prefs ,'edge_color',(0.96 ,0.98 ,1.0 ))),max (0.0 ,min (1.0 ,_sl_safe_float (draw_state .get ('occ_alpha_mul',0.45 ),0.45 ))))
    show_vis_faces =bool (draw_state .get ('show_vis_faces',True ))

    for mesh_obj in shared_meshes :
        eval_obj =mesh_obj .evaluated_get (depsgraph )
        try :me =eval_obj .to_mesh (preserve_all_data_layers =False )
        except :continue 

        v_count =len (me .vertices )
        if v_count ==0 :
            eval_obj .to_mesh_clear ()
            continue 

        v_arr =np .empty (v_count *3 ,dtype =np .float32 )
        me .vertices .foreach_get ("co",v_arr )
        v_arr =v_arr .reshape (-1 ,3 )

        batch_tris =batch_edges =None 
        show_faces =smo_prefs .show_faces_edit 
        # Smart Lattice editing uses the source mesh as a translucent surface guide.
        # Per request, draw only the face overlay on the original mesh: no edge/line
        # overlay is added while the lattice object is selected or edited.
        show_edges =False 

        if show_faces :
            try :
                me .calc_loop_triangles ()
                t_idx =np .empty (len (me .loop_triangles )*3 ,dtype =np .int32 )
                me .loop_triangles .foreach_get ("vertices",t_idx )
                batch_tris =batch_for_shader (shader ,'TRIS',{"pos":v_arr },indices =t_idx .reshape (-1 ,3 ))
            except :pass 
        if show_edges :
            try :
                e_idx =np .empty (len (me .edges )*2 ,dtype =np .int32 )
                me .edges .foreach_get ("vertices",e_idx )
                batch_edges =batch_for_shader (shader ,'LINES',{"pos":v_arr },indices =e_idx .reshape (-1 ,2 ))
            except :pass 

        eval_obj .to_mesh_clear ()

        mvp =view_proj_mat @mesh_obj .matrix_world 
        do_occ_faces =bool (draw_state .get ('do_occ_pass',False ))

        try :
            # Local depth pre-pass.  It gives this Smart Lattice mesh guide the
            # same stable self-occlusion reference that Smart Overlay Suite uses,
            # while avoiding color output.  It also prevents the external
            # all-object occluder pass from hiding the guide on its own target mesh.
            if batch_tris :
                try :gpu .state .blend_set ('NONE')
                except Exception :pass 
                try :gpu .state .depth_mask_set (True )
                except Exception :pass 
                try :gpu .state .color_mask_set (False ,False ,False ,False )
                except Exception :pass 
                try :gpu .state .face_culling_set ('NONE')
                except Exception :pass 
                try :gpu .state .depth_test_set (depth_vis )
                except Exception :pass 
                shader .bind ()
                shader .uniform_float ("u_mvpMatrix",mvp )
                shader .uniform_float ("u_zOffset",0.0 )
                shader .uniform_float ("u_pointSize",1.0 )
                shader .uniform_float ("u_color",(0.0 ,0.0 ,0.0 ,0.0 ))
                batch_tris .draw (shader )

            try :gpu .state .color_mask_set (True ,True ,True ,True )
            except Exception :pass 
            try :gpu .state .blend_set ('ALPHA')
            except Exception :pass 
            for st ,v in [('line_smooth_set',True ),('multisample_set',True ),('depth_mask_set',False )]:
                try :getattr (gpu .state ,st )(v )
                except Exception :pass 
            try :gpu .state .face_culling_set ('NONE'if _sl_safe_bool (smo_prefs ,'double_sided',True )else 'BACK')
            except Exception :pass 

            shader .bind ()
            shader .uniform_float ("u_mvpMatrix",mvp )
            shader .uniform_float ("u_pointSize",1.0 )

            if batch_tris and show_vis_faces and _sl_safe_bool (smo_prefs ,'show_faces_edit',True ):
                shader .uniform_float ("u_zOffset",f_off )
                gpu .state .depth_test_set (_sl_visible_depth_test (rv3d ,depth_vis ,bool (draw_state .get ('hide_visible_occluded_now',False ))))
                shader .uniform_float ("u_color",fcv )
                batch_tris .draw (shader )

            if batch_tris and do_occ_faces and _sl_safe_bool (smo_prefs ,'show_faces_edit',True ):
                shader .uniform_float ("u_zOffset",-f_off if abs (f_off )>0.0 else -offset_sign *max (f_mag ,2.0e-5 ))
                gpu .state .depth_test_set (_sl_strict_occluded_depth_test (depth_occ ))
                shader .uniform_float ("u_color",fco )
                batch_tris .draw (shader )

            if batch_edges and _sl_safe_bool (smo_prefs ,'show_vis_edges',True ):
                gpu .state .line_width_set (max (1.0 ,_sl_safe_float (getattr (smo_prefs ,'edge_size',1.0 ),1.0 )))
                shader .uniform_float ("u_zOffset",e_off )
                gpu .state .depth_test_set (_sl_visible_depth_test (rv3d ,depth_vis ,bool (draw_state .get ('hide_visible_occluded_now',False ))))
                shader .uniform_float ("u_color",ecv )
                batch_edges .draw (shader )
                if bool (draw_state .get ('do_occ_pass',False ))and _sl_safe_bool (smo_prefs ,'show_occ_edges',True ):
                    shader .uniform_float ("u_zOffset",-e_off if abs (e_off )>0.0 else -offset_sign *max (e_mag ,2.0e-5 ))
                    gpu .state .depth_test_set (_sl_strict_occluded_depth_test (depth_occ ))
                    shader .uniform_float ("u_color",eco )
                    batch_edges .draw (shader )
        finally :
            try :gpu .state .color_mask_set (True ,True ,True ,True )
            except Exception :pass 
            for st ,v in [('blend_set','NONE'),('depth_mask_set',True ),('face_culling_set','BACK'),
            ('depth_test_set','NONE'),('line_width_set',1.0 )]:
                try :getattr (gpu .state ,st )(v )
                except Exception :pass 

                # ------------------------------------------
                # 完全な状態移行・復元システムタイマー (排他制御・シーケンシャル・EDIT実体追従版)
                # ------------------------------------------
_restore_selection_meshes =[]
_restore_mode =None 
_restore_active_item =None 
_is_processing_restore =False 
_prev_active_obj =None 
_prev_mod_counts ={}
_prev_active_mod_names ={}

def _do_restore_selection ():
    """Legacy no-op (selection restoration is handled by Smart Modifier)."""
    return None 

def _switch_to_lattice_action (lat_name ):
    """Legacy no-op.

    Switching edit targets is now handled by Smart Modifier via plugin sync_objects (target_obj).
    """
    return None 

_SL_DG_LOCK =False 
_SL_LAST_TAG_TS ={}


# Lattice->dependent mesh cache (to avoid full bpy.data.objects scans while editing)
_SL_LATTICE_USERS ={}# {lat_name: set(main_names)}
def _sl_register_lat_user (lat_name :str ,main_name :str ):
    try :
        s =_SL_LATTICE_USERS .get (lat_name )
        if s is None :
            s =set ()
            _SL_LATTICE_USERS [lat_name ]=s 
        s .add (main_name )
    except Exception :
        pass 


def _sl_unregister_lat_user (lat_name :str ,main_name :str ):
    try :
        s =_SL_LATTICE_USERS .get (lat_name )
        if not s :
            return 
        try :
            s .discard (main_name )
        except Exception :
            pass 
        if not s :
            _SL_LATTICE_USERS .pop (lat_name ,None )
    except Exception :
        pass 

def _sl_depsgraph_touches_active_lattice (depsgraph ,lat_obj ):
    if depsgraph is None or not lat_obj :
        return False 
    try :
        updates =getattr (depsgraph ,"updates",None )
        if not updates :
            return False 
    except Exception :
        return False 
    try :
        lat_data =getattr (lat_obj ,"data",None )
    except Exception :
        lat_data =None 
    for update in updates :
        try :candidate =update .id 
        except Exception :candidate =None 
        if candidate is lat_obj or candidate is lat_data :
            return True 
    return False 

def smart_lattice_depsgraph_update (scene ,depsgraph ):
    """Very lightweight depsgraph hook.

    Purpose: when editing a SmartLattice (EDIT_LATTICE), tag dependent meshes for redraw/update.
    All selection/mode switching is handled by Smart Modifier (plugin integration).
    """
    global _SL_DG_LOCK ,_SL_LAST_TAG_TS 
    if not _sl_runtime_live_enabled ():
        return 
    if _SL_DG_LOCK :
        return 
    try :
        if bpy .app .driver_namespace .get ("_MS_MODIFIER_STACK_SYNC_LOCK",False ):
            return 
    except Exception :
        pass 

    ctx =bpy .context 
    try :
        if getattr (ctx ,"mode","")!='EDIT_LATTICE':
            return 
    except Exception :
        return 

    lat_obj =getattr (ctx ,"active_object",None )
    if not is_valid_obj (lat_obj )or getattr (lat_obj ,"type","")!='LATTICE':
        return 
    try :
        if "sl_main_target"not in lat_obj :
            return 
    except Exception :
        return 
    if not _sl_depsgraph_touches_active_lattice (depsgraph ,lat_obj ):
        return 

        # Throttle per lattice
    try :
        import time as _time 
        now =_time .time ()
        ln =lat_obj .name 
        last =float (_SL_LAST_TAG_TS .get (ln ,0.0 )or 0.0 )
        if (now -last )<0.10 :
            return 
        _SL_LAST_TAG_TS [ln ]=now 
    except Exception :
        pass 

    _SL_DG_LOCK =True 
    try :
    # Prefer cached dependent meshes for this lattice (fast).
        try :
            names =list (_SL_LATTICE_USERS .get (lat_obj .name ,()))
        except Exception :
            names =[]
        if names :
            for nm in names :
                o =bpy .data .objects .get (nm )
                if o and getattr (o ,'type','')=='MESH':
                    try :o .update_tag ()
                    except Exception :pass 
        else :
        # Fallback: scan all meshes once (slower but safe for lattices created outside MS).
            for o in bpy .data .objects :
                if not o or getattr (o ,'type','')!='MESH':
                    continue 
                try :
                    for m in getattr (o ,'modifiers',[]):
                        if getattr (m ,'type','')=='LATTICE'and getattr (m ,'object',None )==lat_obj :
                            o .update_tag ()
                            break 
                except Exception :
                    continue 
    finally :
        _SL_DG_LOCK =False 

class VIEW3D_PT_smart_lattice_standalone (bpy .types .Panel ):
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_label ="SmartLattice Standalone"
    @classmethod 
    def poll (cls ,context ):
        return False 
    def draw (self ,context ):
        layout =self .layout 
        main_obj =get_main_object (context .active_object )
        if not is_valid_obj (main_obj )or main_obj .type !='MESH':
            layout .label (text =t ('Please select a mesh object.'),icon='NONE')
            return 
        layout .operator ("smart_lattice.add_layer",text =t ('Add Smart Lattice'),icon ='ADD')
        layout .label (text =t ('* For stack management, please use Smart Modifier.'),icon='NONE')

def _sl_ms_match_modifier (mod ):
    try :return bool (mod )and mod .type =='LATTICE'and getattr (mod ,"object",None )and ("sl_main_target"in mod .object )
    except :return False 

def _sl_ms_get_main_object (active_obj ):
    try :
        if is_valid_obj (active_obj )and "sl_main_target"in active_obj :
            return bpy .data .objects .get (active_obj ["sl_main_target"])
    except :pass 
    return None 

def _sl_ui_active_from_object (main_obj ,active_obj ):
    try :
        if not is_valid_obj (main_obj )or not is_valid_obj (active_obj )or active_obj .type !='LATTICE'or active_obj .get ("sl_main_target")!=main_obj .name :
            return None 
        for m in main_obj .modifiers :
            if _sl_ms_match_modifier (m )and getattr (m ,"object",None )==active_obj :return m .name 
    except :pass 
    return None 

def _sl_ms_sync_objects (main_obj ,context ,effective_active_id ,carrier_key ,show_end ,interactive ):
    """Smart Modifier integration point.

    - Hide non-effective SmartLattice helpers for this main object.
    - When SmartLattice modifier is the effective active level, return the lattice object as target_obj
      so Smart Modifier can switch to EDIT_LATTICE safely (single selection interactive).
    """
    try :
        vl =getattr (context ,"view_layer",None )
        res_target =None 

        for m in main_obj .modifiers :
            if not _sl_ms_match_modifier (m ):
                continue 
            lat_obj =m .object 
            if not is_valid_obj (lat_obj ):
                continue 

            is_effective_active =(m .name ==effective_active_id )and bool (getattr (m ,"show_render",True ))
            if is_effective_active :
                res_target =lat_obj 

            want_hide =not is_effective_active 

            if not want_hide :
                try :
                    lat_obj ["sl_main_target"]=main_obj .name 
                except Exception :
                    pass 
                    # Show helper only when needed (avoid hide_set spam)
                _sl_set_hidden (lat_obj ,False )
            else :
            # If the lattice is shared across meshes, keep it visible when any user is active on it.
            # Force refresh right after an explicit stack click (set by Smart Modifier) so hide happens immediately.
                _ttl =0.25 
                try :
                    t_force =float (bpy .app .driver_namespace .get ("_MS_FORCE_SL_SHARED_REFRESH_T",0.0 )or 0.0 )
                    if (time .time ()-t_force )<0.5 :
                        _ttl =0.0 
                except Exception :
                    pass 
                shared_active =_sl_is_shared_active (lat_obj ,ttl =_ttl )
                if not shared_active :
                    _sl_set_hidden (lat_obj ,True )


                    # When already in an Edit mode (multi-edit workflows), keep the active object aligned without bpy.ops.
        try :
            if res_target and getattr (context ,"mode","OBJECT")!='OBJECT'and vl :
                try :
                    _sl_set_hidden (res_target ,False )
                except Exception :
                    pass 
                try :
                    if not res_target .select_get ():
                        res_target .select_set (True )
                except Exception :
                    pass 
                try :
                    if res_target .name in vl .objects :
                        vl .objects .active =res_target 
                except Exception :
                    pass 
        except Exception :
            pass 

        if res_target :
            return {"target_obj":res_target ,"priority":20 }
    except Exception :
        pass 
    return {}

def _sl_ms_cleanup_before_apply (main_obj ,context ,obj ,mod ):
    try :
        if not mod or not _sl_ms_match_modifier (mod ):return 
        vg_name =getattr (mod ,"vertex_group",None )
        if vg_name and is_valid_obj (obj )and obj .type =='MESH'and vg_name in obj .vertex_groups :
            try :obj .vertex_groups .remove (obj .vertex_groups [vg_name ])
            except :pass 
        bpy .app .driver_namespace ["_SL_NEED_CLEANUP"]=True 
    except :pass 

def _sl_ms_cleanup_before_remove (main_obj ,context ,obj ,mod ):
    """Cleanup hook called by Smart Modifier before removing a SmartLattice modifier.

    Only removes the per-mesh SmartLattice vertex group (if any) and schedules orphan cleanup.
    Never changes selection/mode here (Smart Modifier already preserves them).
    """
    try :
        if not mod or not _sl_ms_match_modifier (mod ):
            return 
        try :
            lat_obj =getattr (mod ,"object",None )
            if lat_obj :_sl_unregister_lat_user (getattr (lat_obj ,"name",""),getattr (obj ,"name",""))
        except Exception :
            pass 
        vg_name =getattr (mod ,"vertex_group",None )
        if vg_name and is_valid_obj (obj )and obj .type =='MESH':
            try :
                vg =obj .vertex_groups .get (vg_name )
                if vg :
                    obj .vertex_groups .remove (vg )
            except Exception :
                pass 
        try :
            bpy .app .driver_namespace ["_SL_NEED_CLEANUP"]=True 
        except Exception :
            pass 
    except Exception :
        pass 

def _sl_ms_before_item_action (main_obj ,context ,obj ,mod ,action ,clipboard ):
    if action not in ('DELETE','CUT'):return None 
    if not mod or not _sl_ms_match_modifier (mod ):return None 
    api ={}
    try :api =_sl_ms_api ()
    except :pass 
    snapshot =None 
    try :
        ss =api .get ("sel_snapshot")
        if callable (ss ):snapshot =ss (main_obj )
    except :pass 
    return {"sel_snapshot":snapshot }

def _sl_ms_after_item_action (main_obj ,context ,obj ,mod ,action ,clipboard ,state ):
    if not state :return 
    snapshot =state .get ("sel_snapshot")
    if snapshot is None :return 
    try :
        api =_sl_ms_api ()
        rs =api .get ("sel_restore")
        if callable (rs ):
            rs (main_obj ,snapshot )
            return 
    except :pass 

def _sl_ms_draw_modifier_properties_extra (col ,mod ,main_obj =None ):
    if not _sl_ms_match_modifier (mod ):return 
    try :
        lat_data =mod .object .data 
        bx =col .box ();b_col =bx .column (align =True )
        b_col .label (text =t ('Smart Lattice Resolution'),icon ='LATTICE_DATA')

        r =b_col .row (align =True )
        r .prop (lat_data ,"points_u",text =t ("U"));r .prop (lat_data ,"points_v",text =t ("V"));r .prop (lat_data ,"points_w",text =t ("W"))
        r2 =b_col .row (align =True )
        r2 .prop (lat_data ,"interpolation_type_u",text =t ("U"));r2 .prop (lat_data ,"interpolation_type_v",text =t ("V"));r2 .prop (lat_data ,"interpolation_type_w",text =t ("W"))
        try :
            if hasattr (lat_data ,"use_outside"):
                b_col .prop (lat_data ,"use_outside")
        except Exception :
            pass 
    except :pass 

def _sl_ms_draw_add_menu (layout ,context ):
    try :layout .operator ("smart_lattice.add_layer",text =t ("Smart Lattice"),icon ='MOD_LATTICE')
    except :pass 


def _sl_ms_get_skip_copy_props (mod ):
    # Keep the per-object helper lattice object and auto-selection vertex group
    # local.  Instance sync copies the user-facing lattice-data parameters below.
    return {"object","vertex_group"}


def _sl_ms_after_instance_sync (src_obj ,src_mod ,obj ,mod ,context =None ):
    try :
        src_lat =getattr (src_mod ,"object",None )
        dst_lat =getattr (mod ,"object",None )
        src_data =getattr (src_lat ,"data",None )
        dst_data =getattr (dst_lat ,"data",None )
        if not src_data or not dst_data :return
        for attr in ("points_u","points_v","points_w","interpolation_type_u","interpolation_type_v","interpolation_type_w","use_outside"):
            try :
                if hasattr (src_data ,attr )and hasattr (dst_data ,attr ):
                    setattr (dst_data ,attr ,getattr (src_data ,attr ))
            except Exception :pass
        try :
            if len (src_data .points )==len (dst_data .points ):
                for sp ,dp in zip (src_data .points ,dst_data .points ):
                    try :dp .co_deform =sp .co_deform
                    except Exception :pass
        except Exception :pass
        try :dst_data .update_tag ()
        except Exception :pass
        try :dst_lat .update_tag ()
        except Exception :pass
    except Exception :pass

def _sl_ms_build_plugin ():
    return {
    "id":"smart_lattice",
    "label":"Smart Lattice",
    "label_ja":"スマートラティス",
    "operator_id":"smart_lattice.add_layer",
    "icon":"MOD_LATTICE",
    "group":"deformers",
    "priority":83 ,
    "always_sync":True ,
    "description_en":"Add a stack-managed Smart Lattice layer that behaves like an FFD-style cage modifier with helper-aware editing.",
    "description_ja":"FFD風ケージモディファイアとして扱える、スタック管理付き Smart Lattice レイヤーを追加します。",
    "usage_en":"Use Object Mode or Edit Mesh on an active mesh object, then run Smart Lattice to add the stack-managed cage layer.",
    "usage_ja":"オブジェクトモードまたは編集メッシュでアクティブメッシュを対象に実行し、スタック管理されるケージレイヤーを追加します。",
    "match_modifier":_sl_ms_match_modifier ,"get_main_object":_sl_ms_get_main_object ,
    "ui_active_from_object":_sl_ui_active_from_object ,"sync_objects":_sl_ms_sync_objects ,
    "cleanup_before_apply":_sl_ms_cleanup_before_apply ,"cleanup_before_remove":_sl_ms_cleanup_before_remove ,
    "before_item_action":_sl_ms_before_item_action ,"after_item_action":_sl_ms_after_item_action ,
    "draw_modifier_properties_extra":_sl_ms_draw_modifier_properties_extra ,"draw_add_menu":_sl_ms_draw_add_menu ,
    "get_skip_copy_props":_sl_ms_get_skip_copy_props ,"after_instance_sync":_sl_ms_after_instance_sync ,
    }

def _sl_ms_register_plugin ():
    """Register SmartLattice as a Smart Modifier plugin (robust across reloads)."""
    try :
        _sl_install_smart_overlay_occluder_patch ()
    except Exception :
        pass 
    try :
        dn =bpy .app .driver_namespace 
        plugin =_sl_ms_build_plugin ()

        # Prefer Smart Modifier's public registration hook when available.
        fn =dn .get ("_MS_REGISTER_PLUGIN_V1")
        if callable (fn ):
            try :
                fn ("smart_lattice",plugin )
            except Exception :
                pass 

                # Always ensure the shared registry is a dict and contains our entry.
        reg =_sl_ms_plugin_registry (dn )
        reg ["smart_lattice"]=plugin 
    except Exception :
        pass 

def _sl_ms_unregister_plugin ():
    try :
        dn =bpy .app .driver_namespace 
        fn =dn .get ("_MS_UNREGISTER_PLUGIN_V1")
        if callable (fn ):
            try :
                fn ("smart_lattice")
            except Exception :
                pass 

        reg =_sl_ms_plugin_registry (dn )
        reg .pop ("smart_lattice",None )
    except Exception :
        pass 


        # --- Tooltip completion ---
VIEW3D_PT_smart_lattice_standalone .bl_description ='Standalone panel for Smart Lattice Modifier when it is used outside the main Smart Modifier stack.'


# -----------------------------------------------------------------------------
# Standalone-reference behavior patch
# - Match the standalone Smart Lattice add-on when explicitly used.
# - Fix mixed-selection fitting, empty vertex-group creation, and lattice
#   transform alignment so the lattice follows the active mesh orientation.
# -----------------------------------------------------------------------------
import importlib as _sl_importlib


def _sl_runtime_live_enabled() -> bool:
    user_enabled = False
    try:
        api = _sl_runtime_api()
        fn = api.get("smart_lattice_live_enabled")
        if callable(fn):
            user_enabled = bool(fn())
    except Exception:
        user_enabled = False
    try:
        module_enabled = bool(bpy.app.driver_namespace.get("_SL_RUNTIME_ENABLED_V1", False))
    except Exception:
        module_enabled = False
    return bool(user_enabled or module_enabled)


def _sl_request_live_runtime():
    """Arm Smart Lattice runtime when the tool is actually used.

    The standalone Smart Lattice add-on is live immediately. Bundled Smart
    Modifier keeps it dormant for idle performance, but explicit Smart Lattice
    use must still behave like the standalone tool without requiring a separate
    toggle step.
    """
    try:
        api = _sl_ms_api("_MS_RUNTIME_API_V1")
    except Exception:
        api = {}
    enabled_fn = api.get("smart_lattice_live_enabled") if isinstance(api, dict) else None
    user_enabled = False
    try:
        if callable(enabled_fn):
            user_enabled = bool(enabled_fn())
    except Exception:
        user_enabled = False
    if user_enabled:
        try:
            sync = api.get("sync_runtime_services")
            if callable(sync):
                sync()
        except Exception:
            pass
        return

    try:
        pkg = (__package__ or "").strip()
        if pkg:
            mod = _sl_importlib.import_module(pkg)
            fn = getattr(mod, "set_runtime_enabled", None)
            if callable(fn):
                fn(True)
                return
    except Exception:
        pass


def _sl__safe_object_mode(context):
    try:
        if getattr(context, "mode", "OBJECT") != 'OBJECT' and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
    except Exception:
        pass


def _sl__enter_edit_lattice(context, lat_obj):
    if not is_valid_obj(lat_obj):
        return
    _main_for_preview = None
    try:
        if hasattr(lat_obj, 'get') and lat_obj.get('sl_main_target'):
            _main_for_preview = bpy.data.objects.get(str(lat_obj.get('sl_main_target') or ''))
    except Exception:
        _main_for_preview = None
    try:
        if is_valid_obj(_main_for_preview):
            _sl_ms_set_endpreview_allowed(_main_for_preview, bool(getattr(_main_for_preview, 'ms_show_end_result', False)))
    except Exception:
        pass
    try:
        _sl__safe_object_mode(context)
    except Exception:
        pass
    try:
        if bpy.ops.object.select_all.poll():
            bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
    except Exception:
        pass
    try:
        lat_obj.hide_set(False)
    except Exception:
        pass
    try:
        lat_obj.hide_viewport = False
    except Exception:
        pass
    try:
        lat_obj.hide_select = False
    except Exception:
        pass
    try:
        context.view_layer.objects.active = lat_obj
    except Exception:
        pass
    try:
        lat_obj.select_set(True)
    except Exception:
        pass
    try:
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
    except Exception:
        pass
    try:
        _sl_deselect_all_lattice_points(lat_obj)
    except Exception:
        pass
    try:
        lat_obj.pop("_ms_deselect_lattice_points_once", None)
    except Exception:
        pass
    try:
        if is_valid_obj(_main_for_preview):
            _sl_ms_refresh_preview_later(_main_for_preview.name, delay=0.02)
    except Exception:
        pass




# -----------------------------------------------------------------------------
# Smart Modifier stack preview / Smart Lattice apply cleanup helpers
# -----------------------------------------------------------------------------
_SL_PENDING_APPLY_CLEANUP_KEY = "_SL_PENDING_APPLY_CLEANUP_V1"


# Blender REPLACES bpy.app.driver_namespace on every file load, so every
# ``driver_namespace.get("_MS_API_V1") or {}`` in this module returned an empty
# dict for the rest of the session and each Smart Modifier call became a silent
# no-op.  The re-arm entry point is anchored in a synthetic sys.modules entry by
# runtime._ensure_driver_namespace_api, which survives file loads and the
# live-update submodule purge, so any consumer heals the namespace on first
# touch rather than waiting for the load_post handler.
_SL_NS_ANCHOR_MODULE_NAME = "jelararagi_smart_modifier_ns_anchor_v1"
_SL_NS_ANCHOR_ATTR = "SMS_NS_VALUES"
_SL_NS_REARM_KEY = "_MS_REARM_NS_API_V1"


def _sl_ns_anchor_store():
    """Smart Modifier's process-lifetime driver_namespace anchor.  Never raises."""
    try:
        module = sys.modules.get(_SL_NS_ANCHOR_MODULE_NAME)
        if not isinstance(module, types.ModuleType):
            module = types.ModuleType(_SL_NS_ANCHOR_MODULE_NAME)
            module.__doc__ = ("Smart Modifier Suite driver_namespace anchor.  "
                              "Not an importable module.")
            setattr(module, _SL_NS_ANCHOR_ATTR, {})
            sys.modules[_SL_NS_ANCHOR_MODULE_NAME] = module
        store = getattr(module, _SL_NS_ANCHOR_ATTR, None)
        if not isinstance(store, dict):
            store = {}
            setattr(module, _SL_NS_ANCHOR_ATTR, store)
        return store
    except Exception:
        return {}


def _sl_ns_rearm():
    """Ask the anchored re-arm entry point to republish the API.  Never raises."""
    try:
        fn = _sl_ns_anchor_store().get(_SL_NS_REARM_KEY)
        if callable(fn):
            fn()
            return True
    except Exception:
        pass
    return False


def _sl_ms_api(key="_MS_API_V1"):
    """Read a Smart Modifier API table, healing a namespace wiped by a file load."""
    try:
        dn = bpy.app.driver_namespace
        value = dn.get(key)
        if value is None:
            _sl_ns_rearm()
            value = dn.get(key)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _sl_ms_plugin_registry(dn):
    """Return the shared stack-plugin registry, adopting the anchored one.

    ``_sl_delayed_register_plugin`` is a persistent timer, so it can fire right
    after a file load; minting an empty dict here would strand the 160 plugins
    the rest of the suite already registered.
    """
    store = _sl_ns_anchor_store()
    try:
        reg = dn.get("_MS_MODIFIER_STACK_PLUGINS_V1")
    except Exception:
        reg = None
    if not isinstance(reg, dict):
        anchored = store.get("_MS_MODIFIER_STACK_PLUGINS_V1")
        reg = anchored if isinstance(anchored, dict) else {}
        try:
            dn["_MS_MODIFIER_STACK_PLUGINS_V1"] = reg
        except Exception:
            pass
    store["_MS_MODIFIER_STACK_PLUGINS_V1"] = reg
    return reg


def _sl_ms_set_endpreview_allowed(main_obj, allowed: bool):
    """Allow or disallow Smart Modifier's final-result preview for this edit session."""
    if not is_valid_obj(main_obj):
        return
    try:
        api = _sl_ms_api()
        fn = api.get("endpreview_set_allowed")
        if callable(fn):
            fn(main_obj, bool(allowed))
            if not bool(allowed):
                cleanup = api.get("endpreview_request_cleanup")
                if callable(cleanup):
                    cleanup(main_obj)
            return
    except Exception:
        pass
    # Fallback for older Smart Modifier runtimes.
    try:
        dn = bpy.app.driver_namespace
        key = "_MS_ENDPREVIEW_ALLOWED_MAP_V1"
        m = dn.get(key)
        if not isinstance(m, dict):
            m = {}
        if bool(allowed):
            m[main_obj.name] = True
        else:
            m.pop(main_obj.name, None)
        dn[key] = m
    except Exception:
        pass


def _sl_ms_refresh_preview_later(main_name: str, delay: float = 0.02):
    """Refresh the stack-level mesh and full final preview after Blender settles."""
    main_name = str(main_name or "")
    if not main_name:
        return

    def _timer():
        try:
            main_obj = bpy.data.objects.get(main_name)
            if not is_valid_obj(main_obj):
                return None
            api = _sl_ms_api()
            fn = api.get("apply_modifier_stack_state")
            if callable(fn):
                fn(main_obj, bpy.context, interactive=False)
            try:
                wm = getattr(bpy.context, "window_manager", None)
                if wm:
                    for window in wm.windows:
                        for area in window.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.tag_redraw()
            except Exception:
                pass
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(_timer, first_interval=float(delay))
    except Exception:
        try:
            _timer()
        except Exception:
            pass


def _sl_lattice_has_modifier_users(lat_name: str) -> bool:
    lat_name = str(lat_name or "")
    if not lat_name:
        return False
    try:
        for o in bpy.data.objects:
            if not o or getattr(o, "type", "") != 'MESH':
                continue
            for m in getattr(o, "modifiers", []) or []:
                try:
                    if getattr(m, "type", "") == 'LATTICE':
                        lat = getattr(m, "object", None)
                        if lat and getattr(lat, "name", "") == lat_name:
                            return True
                except Exception:
                    continue
    except Exception:
        pass
    return False


def _sl_collect_apply_cleanup_state(main_obj, context, obj, mod, *, force_return_to_main_edit=None):
    if not mod or not _sl_ms_match_modifier(mod):
        return None
    lat_obj = getattr(mod, "object", None)
    if not is_valid_obj(lat_obj):
        return None

    main_name = getattr(main_obj, "name", "") if is_valid_obj(main_obj) else ""
    obj_name = getattr(obj, "name", "") if is_valid_obj(obj) else ""
    lat_name = getattr(lat_obj, "name", "")
    mod_name = getattr(mod, "name", "")
    vg_name = ""
    try:
        vg_name = str(getattr(mod, "vertex_group", "") or "")
    except Exception:
        vg_name = ""

    if force_return_to_main_edit is None:
        force_return_to_main_edit = False
        try:
            active_obj = getattr(context, "active_object", None)
            edit_obj = getattr(context, "edit_object", None)
            force_return_to_main_edit = bool(
                (active_obj is lat_obj)
                or (edit_obj is lat_obj)
                or (
                    is_valid_obj(main_obj)
                    and bool(main_obj.get("ms_sl_engaged", False))
                    and str(main_obj.get("ms_sl_engaged_mod", "") or "") == mod_name
                )
            )
        except Exception:
            force_return_to_main_edit = False

    return {
        "main_name": str(main_name or ""),
        "obj_name": str(obj_name or ""),
        "mod_name": str(mod_name or ""),
        "lat_name": str(lat_name or ""),
        "lat_data_name": str(getattr(getattr(lat_obj, "data", None), "name", "") or ""),
        "vg_name": str(vg_name or ""),
        "return_to_main_edit": bool(force_return_to_main_edit),
    }


def _sl_pending_cleanup_key(state: dict) -> str:
    try:
        return "|".join((
            str(state.get("obj_name", "") or ""),
            str(state.get("mod_name", "") or ""),
            str(state.get("lat_name", "") or ""),
        ))
    except Exception:
        return ""


def _sl_push_pending_apply_cleanup(state: dict | None):
    if not isinstance(state, dict):
        return
    key = _sl_pending_cleanup_key(state)
    if not key:
        return
    try:
        dn = bpy.app.driver_namespace
        pending = dn.get(_SL_PENDING_APPLY_CLEANUP_KEY)
        if not isinstance(pending, list):
            pending = []
        merged = False
        for item in pending:
            if isinstance(item, dict) and _sl_pending_cleanup_key(item) == key:
                for k, v in state.items():
                    if k == "return_to_main_edit":
                        item[k] = bool(item.get(k, False) or v)
                    elif v not in (None, ""):
                        item[k] = v
                merged = True
                break
        if not merged:
            pending.append(dict(state))
        dn[_SL_PENDING_APPLY_CLEANUP_KEY] = pending
    except Exception:
        pass


def _sl_take_pending_apply_cleanups():
    try:
        dn = bpy.app.driver_namespace
        pending = dn.get(_SL_PENDING_APPLY_CLEANUP_KEY)
        dn.pop(_SL_PENDING_APPLY_CLEANUP_KEY, None)
        return list(pending) if isinstance(pending, list) else []
    except Exception:
        return []


def _sl_remove_object_if_unused(obj):
    if not is_valid_obj(obj):
        return
    try:
        if getattr(obj, "type", "") == 'LATTICE' and _sl_lattice_has_modifier_users(getattr(obj, "name", "")):
            return
    except Exception:
        pass
    data = None
    try:
        data = getattr(obj, "data", None)
    except Exception:
        data = None
    try:
        vl = getattr(bpy.context, "view_layer", None)
        if vl and getattr(vl.objects, "active", None) == obj:
            vl.objects.active = None
    except Exception:
        pass
    try:
        obj.select_set(False)
    except Exception:
        pass
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    try:
        if data and getattr(data, "users", 0) == 0:
            if data.__class__.__name__ == "Lattice":
                bpy.data.lattices.remove(data)
            elif data.__class__.__name__ == "Mesh":
                bpy.data.meshes.remove(data)
            elif data.__class__.__name__ == "Curve":
                bpy.data.curves.remove(data)
    except Exception:
        pass


def _sl_cleanup_tagged_helpers_for_lattice(lat_name: str, main_name: str):
    lat_name = str(lat_name or "")
    main_name = str(main_name or "")
    if not lat_name:
        return

    # Remove non-mesh Smart Lattice helpers that are explicitly tagged to this lattice/main.
    # This covers future helper types (including generated geometry-node helper objects)
    # without touching unrelated Smart Modifier or Edit Poly helpers.
    try:
        for ob in list(bpy.data.objects):
            try:
                if not ob:
                    continue
                if getattr(ob, "name", "") == lat_name:
                    continue
                tagged = False
                if hasattr(ob, "get"):
                    tagged = bool(
                        ob.get("sl_owner_lattice") == lat_name
                        or ob.get("sl_lattice_object") == lat_name
                        or (
                            main_name
                            and ob.get("sl_main_target") == main_name
                            and getattr(ob, "type", "") != 'MESH'
                        )
                    )
                if tagged:
                    _sl_remove_object_if_unused(ob)
            except Exception:
                continue
    except Exception:
        pass


def _sl_cleanup_empty_smart_lattice_collections():
    # Remove the SmartLattice collection if it no longer owns any helper, then
    # remove the shared parent only when it is completely empty.
    try:
        sl_col = bpy.data.collections.get("SmartLattice_Collection")
        if sl_col and len(getattr(sl_col, "objects", [])) == 0 and len(getattr(sl_col, "children", [])) == 0:
            try:
                for parent in list(bpy.data.collections):
                    try:
                        if sl_col.name in {c.name for c in parent.children}:
                            parent.children.unlink(sl_col)
                    except Exception:
                        pass
                try:
                    scene_col = getattr(getattr(bpy.context, "scene", None), "collection", None)
                    if scene_col and sl_col.name in {c.name for c in scene_col.children}:
                        scene_col.children.unlink(sl_col)
                except Exception:
                    pass
            except Exception:
                pass
            try:
                bpy.data.collections.remove(sl_col)
            except Exception:
                pass
    except Exception:
        pass

    try:
        parent = bpy.data.collections.get("Modifier_System_Collection")
        if parent and len(getattr(parent, "objects", [])) == 0 and len(getattr(parent, "children", [])) == 0:
            try:
                scene_col = getattr(getattr(bpy.context, "scene", None), "collection", None)
                if scene_col and parent.name in {c.name for c in scene_col.children}:
                    scene_col.children.unlink(parent)
            except Exception:
                pass
            try:
                bpy.data.collections.remove(parent)
            except Exception:
                pass
    except Exception:
        pass


def _sl_schedule_select_main_edit(main_name: str):
    main_name = str(main_name or "")
    if not main_name:
        return

    def _timer():
        try:
            ctx = bpy.context
            obj = bpy.data.objects.get(main_name)
            if not is_valid_obj(obj) or getattr(obj, "type", "") != 'MESH':
                return None
            try:
                if getattr(ctx, "mode", "OBJECT") != 'OBJECT' and bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
            except Exception:
                pass
            vl = getattr(ctx, "view_layer", None)
            try:
                if bpy.ops.object.select_all.poll():
                    bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
            except Exception:
                pass
            try:
                obj.hide_viewport = False
                obj.hide_set(False)
                obj.hide_select = False
            except Exception:
                pass
            try:
                obj.select_set(True)
            except Exception:
                pass
            try:
                if vl:
                    vl.objects.active = obj
            except Exception:
                pass
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
            except Exception:
                pass
            try:
                _sl_ms_set_endpreview_allowed(obj, bool(getattr(obj, 'ms_show_end_result', False)))
                _sl_ms_refresh_preview_later(obj.name, delay=0.02)
            except Exception:
                pass
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(_timer, first_interval=0.01)
    except Exception:
        try:
            _timer()
        except Exception:
            pass


def _sl_finalize_pending_apply_cleanups(context):
    states = _sl_take_pending_apply_cleanups()
    if not states:
        return

    return_to_main = ""
    lattices_to_check = set()

    for st in states:
        if not isinstance(st, dict):
            continue
        main_name = str(st.get("main_name", "") or "")
        obj_name = str(st.get("obj_name", "") or "")
        mod_name = str(st.get("mod_name", "") or "")
        lat_name = str(st.get("lat_name", "") or "")
        vg_name = str(st.get("vg_name", "") or "")

        obj = bpy.data.objects.get(obj_name) if obj_name else None
        # If the modifier still exists, modifier_apply failed or has not happened; keep helpers intact.
        try:
            if obj and mod_name and obj.modifiers.get(mod_name):
                _sl_push_pending_apply_cleanup(st)
                continue
        except Exception:
            pass

        if main_name and bool(st.get("return_to_main_edit", False)) and not return_to_main:
            return_to_main = main_name

        if obj and getattr(obj, "type", "") == 'MESH' and vg_name:
            try:
                vg = obj.vertex_groups.get(vg_name)
                if vg:
                    obj.vertex_groups.remove(vg)
            except Exception:
                pass

        try:
            if lat_name and main_name:
                _sl_unregister_lat_user(lat_name, obj_name or main_name)
        except Exception:
            pass

        if lat_name:
            lattices_to_check.add((lat_name, main_name))

    for lat_name, main_name in sorted(lattices_to_check):
        try:
            if _sl_lattice_has_modifier_users(lat_name):
                continue
            _sl_cleanup_tagged_helpers_for_lattice(lat_name, main_name)
            lat_obj = bpy.data.objects.get(lat_name)
            if lat_obj:
                _sl_remove_object_if_unused(lat_obj)
        except Exception:
            pass

    try:
        _cleanup_orphaned_lattices_and_vgs()
    except Exception:
        pass
    try:
        _sl_cleanup_empty_smart_lattice_collections()
    except Exception:
        pass

    if return_to_main:
        _sl_schedule_select_main_edit(return_to_main)


def _sl_ms_cleanup_before_apply(main_obj, context, obj, mod):
    """Record Smart Lattice helper data before apply; actual cleanup runs after apply.

    The vertex group must remain in place until Blender bakes the Lattice modifier.
    Removing it before modifier_apply changes the deformation result, so this hook
    only records what must be deleted once the modifier is gone.
    """
    try:
        if not mod or not _sl_ms_match_modifier(mod):
            return
        state = _sl_collect_apply_cleanup_state(main_obj, context, obj, mod)
        _sl_push_pending_apply_cleanup(state)
        try:
            bpy.app.driver_namespace["_SL_NEED_CLEANUP"] = True
        except Exception:
            pass
    except Exception:
        pass


def _sl_ms_before_item_action(main_obj, context, obj, mod, action, clipboard):
    if action in ('APPLY', 'APPLY_BELOW'):
        try:
            if mod and _sl_ms_match_modifier(mod):
                lat_obj = getattr(mod, "object", None)
                active_obj = getattr(context, "active_object", None)
                edit_obj = getattr(context, "edit_object", None)
                return_edit = bool(
                    (is_valid_obj(lat_obj) and (active_obj is lat_obj or edit_obj is lat_obj))
                    or (
                        is_valid_obj(main_obj)
                        and bool(main_obj.get("ms_sl_engaged", False))
                        and str(main_obj.get("ms_sl_engaged_mod", "") or "") == getattr(mod, "name", "")
                    )
                )
                state = _sl_collect_apply_cleanup_state(main_obj, context, obj, mod, force_return_to_main_edit=return_edit)
                _sl_push_pending_apply_cleanup(state)
                return {"apply_cleanup": state}
        except Exception:
            pass
        return None

    if action not in ('DELETE', 'CUT'):
        return None
    if not mod or not _sl_ms_match_modifier(mod):
        return None
    api = {}
    try:
        api = _sl_ms_api()
    except Exception:
        pass
    snapshot = None
    try:
        ss = api.get("sel_snapshot")
        if callable(ss):
            snapshot = ss(main_obj)
    except Exception:
        pass
    return {"sel_snapshot": snapshot}


def _sl_ms_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    if action in ('APPLY', 'APPLY_BELOW'):
        try:
            _sl_finalize_pending_apply_cleanups(context)
        except Exception:
            pass
        return

    if not state:
        return
    snapshot = state.get("sel_snapshot")
    if snapshot is None:
        return
    try:
        api = _sl_ms_api()
        rs = api.get("sel_restore")
        if callable(rs):
            rs(main_obj, snapshot)
            return
    except Exception:
        pass


def _slm_fixed_add_execute(self, context):
    _sl_request_live_runtime()
    if getattr(self, "resolution_type", 'CUSTOM') != 'CUSTOM':
        try:
            self.res_u = self.res_v = self.res_w = int(self.resolution_type)
        except Exception:
            pass

    pre_selected = list(getattr(context, "selected_objects", []) or [])
    pre_active = getattr(context, "active_object", None)
    pre_objects_in_mode = list(getattr(context, "objects_in_mode", []) or []) if getattr(context, "mode", '') == 'EDIT_MESH' else []

    live_sel_dicts = {}
    if getattr(context, "mode", '') == 'EDIT_MESH':
        for o in pre_objects_in_mode:
            try:
                if o.type == 'MESH':
                    live_sel_dicts[o.name] = _sl_capture_selection(o)
            except Exception:
                pass

    raw_src = pre_objects_in_mode if (getattr(context, "mode", '') == 'EDIT_MESH' and pre_objects_in_mode) else pre_selected
    raw_targets = [get_main_object(o) for o in raw_src if o and getattr(o, 'type', '') == 'MESH']
    anchor = get_main_object(pre_active)

    _sl__safe_object_mode(context)

    targets = []
    seen = set()
    for t in raw_targets:
        try:
            if is_valid_obj(t) and t.name not in seen and getattr(t, 'type', '') == 'MESH':
                targets.append(t)
                seen.add(t.name)
        except Exception:
            pass

    if not targets:
        if is_valid_obj(anchor) and getattr(anchor, 'type', '') == 'MESH':
            targets = [anchor]
        else:
            self.report({'WARNING'}, t('Please select a mesh object.'))
            return {'CANCELLED'}

    if anchor not in targets:
        anchor = targets[0]

    _ms_lock_fn = None
    _ms_prev_lock = False
    try:
        _api = _sl_ms_api()
        _ms_lock_fn = _api.get("shared_lock_set")
        if callable(_ms_lock_fn):
            _ms_prev_lock = bool(bpy.app.driver_namespace.get("_MS_MODIFIER_STACK_SYNC_LOCK", False))
            _ms_lock_fn(True)
    except Exception:
        _ms_lock_fn = None

    try:
        mat_anchor_inv = anchor.matrix_world.inverted()
        all_points_local = []
        selection_info = {}
        target_idx_info = {}
        target_data_list = []

        for obj in targets:
            active_id = obj.get("ui_active_item", "BASE")
            try:
                if is_valid_obj(context.active_object) and context.active_object != obj:
                    ep_mod_name = _sl_find_ep_modifier_name_for_edit_object(obj, context.active_object)
                    if ep_mod_name:
                        active_id = ep_mod_name
            except Exception:
                pass

            if active_id == "BASE":
                target_idx = 0
            else:
                aidx = obj.modifiers.find(active_id)
                target_idx = (aidx + 1) if aidx >= 0 else len(obj.modifiers)
            target_idx_info[obj.name] = target_idx

            carrier_obj = _find_nearest_upper_carrier_object(obj, target_idx)
            sel_indices = _get_carrier_selection(obj, carrier_obj, live_sel_dicts)
            target_data_list.append((obj, carrier_obj, sorted(sel_indices) if sel_indices else None))

        for obj, carrier_obj, sel_indices in target_data_list:
            mat_diff = mat_anchor_inv @ carrier_obj.matrix_world
            if sel_indices:
                selection_info[obj.name] = list(sel_indices)
                coords = _fast_get_selected_points(carrier_obj, selection_info[obj.name])
                if len(coords):
                    all_points_local.append(_fast_transform_points(coords, mat_diff))
            else:
                selection_info[obj.name] = None
                try:
                    bbox = np.array(carrier_obj.bound_box, dtype=np.float32)
                    all_points_local.append(_fast_transform_points(bbox, mat_diff))
                except Exception:
                    pass

        if not all_points_local:
            self.report({'WARNING'}, t('No valid selection found.'))
            return {'CANCELLED'}

        merged_pts = np.vstack(all_points_local)
        if len(merged_pts) == 0:
            return {'CANCELLED'}

        min_arr = np.min(merged_pts, axis=0)
        max_arr = np.max(merged_pts, axis=0)
        center_local = (mathutils.Vector(min_arr) + mathutils.Vector(max_arr)) / 2.0
        size_local = mathutils.Vector(max_arr) - mathutils.Vector(min_arr)
        size_local.x = max(size_local.x, 0.01)
        size_local.y = max(size_local.y, 0.01)
        size_local.z = max(size_local.z, 0.01)

        is_multi = len(targets) > 1
        lat_name = _sl_get_next_smartlattice_name(targets, base="SmartLattice")

        lat_data = bpy.data.lattices.new(f"{lat_name}_Data")
        lat_obj = bpy.data.objects.new(lat_name, lat_data)

        _parent, sl_col = ensure_modifier_system_collections(context.scene)
        try:
            if sl_col is not None:
                sl_col.objects.link(lat_obj)
        except Exception:
            pass

        lat_data.points_u = self.res_u
        lat_data.points_v = self.res_v
        lat_data.points_w = self.res_w
        lat_data.interpolation_type_u = lat_data.interpolation_type_v = lat_data.interpolation_type_w = 'KEY_BSPLINE'
        lat_data.use_outside = False

        try:
            lat_obj.matrix_world = anchor.matrix_world.copy()
        except Exception:
            pass
        try:
            lat_obj.location = anchor.matrix_world @ center_local
        except Exception:
            lat_obj.location = anchor.location.copy()
        try:
            s = anchor.matrix_world.to_scale()
            lat_obj.scale = (size_local.x * s.x, size_local.y * s.y, size_local.z * s.z)
        except Exception:
            lat_obj.scale = size_local

        try:
            lat_obj.parent = anchor
            lat_obj.matrix_parent_inverse = anchor.matrix_world.inverted()
        except Exception:
            pass

        try:
            lat_obj["sl_main_target"] = anchor.name
        except Exception:
            pass
        try:
            _sl_register_lat_user(lat_obj.name, anchor.name)
        except Exception:
            pass
        try:
            lat_obj["_ms_deselect_lattice_points_once"] = True
        except Exception:
            pass

        instance_id = uuid.uuid4().hex if is_multi else ""
        created_mod_anchor = None

        for obj, _carrier_obj, _sel_indices in target_data_list:
            target_idx = target_idx_info.get(obj.name, len(obj.modifiers))
            indices = selection_info.get(obj.name)
            vg_name = None
            if indices:
                try:
                    vg_name = get_unique_vgroup_name(obj, lat_name)
                    _sl_assign_vgroup_indices(obj, vg_name, indices, reset=True)
                    try:
                        if _carrier_obj and _carrier_obj != obj and getattr(_carrier_obj, 'type', '') == 'MESH':
                            _sl_assign_vgroup_indices(_carrier_obj, vg_name, indices, reset=True)
                    except Exception:
                        pass
                except Exception:
                    vg_name = None

            try:
                mod = obj.modifiers.new(name=lat_name, type='LATTICE')
            except Exception:
                continue
            mod.object = lat_obj
            mod.show_in_editmode = True
            mod.show_on_cage = True
            if vg_name:
                mod.vertex_group = vg_name
            else:
                try:
                    mod.vertex_group = ""
                except Exception:
                    pass

            try:
                cur = obj.modifiers.find(mod.name)
                if cur >= 0:
                    obj.modifiers.move(cur, max(0, min(int(target_idx), len(obj.modifiers) - 1)))
            except Exception:
                pass

            try:
                if instance_id:
                    _sl_ms_obj_set_instance_id(obj, mod.name, instance_id, disp_name=lat_name)
                else:
                    _sl_ms_obj_set_disp_name(obj, mod.name, lat_name)
            except Exception:
                pass

            try:
                obj["ui_active_item"] = mod.name
            except Exception:
                pass
            try:
                obj.modifiers.active = mod
            except Exception:
                pass
            try:
                obj.update_tag()
            except Exception:
                pass

            if obj == anchor:
                created_mod_anchor = mod

        if not created_mod_anchor:
            return {'CANCELLED'}

        try:
            if hasattr(bpy.ops.object, 'ms_switch_level'):
                with context.temp_override(active_object=anchor, selected_objects=targets, object=anchor):
                    bpy.ops.object.ms_switch_level('EXEC_DEFAULT', False, target_mod_name=created_mod_anchor.name, target_obj_name=anchor.name)
        except Exception:
            try:
                if hasattr(bpy.ops.object, 'ms_switch_level'):
                    bpy.ops.object.ms_switch_level('EXEC_DEFAULT', False, target_mod_name=created_mod_anchor.name, target_obj_name=anchor.name)
            except Exception:
                pass

        _sl__enter_edit_lattice(context, lat_obj)
        return {'FINISHED'}
    finally:
        if _ms_lock_fn:
            try:
                _ms_lock_fn(_ms_prev_lock)
            except Exception:
                pass



def _slm_fixed_update_execute(self, context):
    _sl_request_live_runtime()
    main_obj = bpy.data.objects.get(self.main_obj_name) if getattr(self, 'main_obj_name', '') else None
    mod = None

    if not is_valid_obj(main_obj):
        obj = getattr(context, 'object', None)
        if is_valid_obj(obj) and getattr(obj, 'type', '') == 'MESH':
            main_obj = obj

    if main_obj:
        if getattr(self, 'modifier_name', ''):
            mod = main_obj.modifiers.get(self.modifier_name)
        else:
            am = getattr(main_obj.modifiers, 'active', None)
            if am and am.type == 'LATTICE' and am.object and ('sl_main_target' in am.object):
                mod = am

    if (not is_valid_obj(main_obj) or not mod) and getattr(getattr(context, 'active_object', None), 'type', '') == 'LATTICE':
        lat_active = context.active_object
        if 'sl_main_target' in lat_active:
            main_obj = bpy.data.objects.get(lat_active['sl_main_target'])
            if is_valid_obj(main_obj):
                for m in main_obj.modifiers:
                    if m.type == 'LATTICE' and getattr(m, 'object', None) == lat_active:
                        mod = m
                        break

    if (not is_valid_obj(main_obj)) or (not mod) or mod.type != 'LATTICE' or (not getattr(mod, 'object', None)):
        self.report({'WARNING'}, t('No valid lattice found.'))
        return {'CANCELLED'}

    lat_obj = mod.object

    live_sel_dicts = {}
    if getattr(context, 'mode', '') == 'EDIT_MESH':
        for o in getattr(context, 'objects_in_mode', []) or []:
            try:
                if o.type == 'MESH':
                    live_sel_dicts[o.name] = _sl_capture_selection(o)
            except Exception:
                pass

    _sl__safe_object_mode(context)

    shared_users = []
    for o in bpy.data.objects:
        try:
            if o.type != 'MESH':
                continue
            for m in o.modifiers:
                if m.type == 'LATTICE' and getattr(m, 'object', None) == lat_obj:
                    shared_users.append((o, m))
                    break
        except Exception:
            continue

    if not shared_users:
        self.report({'WARNING'}, t('No valid lattice users found.'))
        return {'CANCELLED'}

    mat_main_inv = main_obj.matrix_world.inverted()
    all_points_local = []
    target_datas = []

    for o, m in shared_users:
        t_idx = o.modifiers.find(m.name)
        c_obj = _find_nearest_upper_carrier_object(o, t_idx)
        s_idx = _get_carrier_selection(o, c_obj, live_sel_dicts)
        target_datas.append((o, m, c_obj, sorted(s_idx) if s_idx else None))

    for o, m, c_obj, s_idx in target_datas:
        old_vg = getattr(m, 'vertex_group', '') or ''
        try:
            if old_vg and old_vg in o.vertex_groups:
                o.vertex_groups.remove(o.vertex_groups[old_vg])
        except Exception:
            pass

        if s_idx:
            valid_indices = [i for i in s_idx if i < len(o.data.vertices)]
            if valid_indices:
                try:
                    vg_name = get_unique_vgroup_name(o, m.name)
                    vg = o.vertex_groups.new(name=vg_name)
                    vg.add(valid_indices, 1.0, 'REPLACE')
                    m.vertex_group = vg_name
                except Exception:
                    try:
                        m.vertex_group = ""
                    except Exception:
                        pass
            else:
                try:
                    m.vertex_group = ""
                except Exception:
                    pass
            coords = _fast_get_selected_points(c_obj, valid_indices if s_idx else None)
            if len(coords):
                all_points_local.append(_fast_transform_points(coords, mat_main_inv @ c_obj.matrix_world))
            else:
                try:
                    bbox = np.array(c_obj.bound_box, dtype=np.float32)
                    all_points_local.append(_fast_transform_points(bbox, mat_main_inv @ c_obj.matrix_world))
                except Exception:
                    pass
        else:
            try:
                m.vertex_group = ""
            except Exception:
                pass
            try:
                bbox = np.array(c_obj.bound_box, dtype=np.float32)
                all_points_local.append(_fast_transform_points(bbox, mat_main_inv @ c_obj.matrix_world))
            except Exception:
                pass

    if not all_points_local:
        self.report({'WARNING'}, t('No valid selection found.'))
        return {'CANCELLED'}

    merged_pts = np.vstack(all_points_local)
    if len(merged_pts) == 0:
        return {'CANCELLED'}

    min_co = mathutils.Vector(np.min(merged_pts, axis=0))
    max_co = mathutils.Vector(np.max(merged_pts, axis=0))
    center_local = (min_co + max_co) / 2.0
    size_local = max_co - min_co
    size_local.x = max(size_local.x, 0.01)
    size_local.y = max(size_local.y, 0.01)
    size_local.z = max(size_local.z, 0.01)

    data_min = mathutils.Vector((1e18, 1e18, 1e18))
    data_max = mathutils.Vector((-1e18, -1e18, -1e18))
    pts = getattr(lat_obj.data, 'points', None)
    if pts:
        for p in pts:
            co = getattr(p, 'co_deform', None) or getattr(p, 'co', None)
            if not co:
                continue
            data_min.x, data_max.x = min(data_min.x, co.x), max(data_max.x, co.x)
            data_min.y, data_max.y = min(data_min.y, co.y), max(data_max.y, co.y)
            data_min.z, data_max.z = min(data_min.z, co.z), max(data_max.z, co.z)
    if data_min.x > data_max.x:
        data_min = mathutils.Vector((-0.5, -0.5, -0.5))
        data_max = mathutils.Vector((0.5, 0.5, 0.5))

    data_center = (data_min + data_max) * 0.5
    data_size = data_max - data_min
    data_size.x = max(abs(data_size.x), 1e-6)
    data_size.y = max(abs(data_size.y), 1e-6)
    data_size.z = max(abs(data_size.z), 1e-6)

    local_scale = mathutils.Vector((
        size_local.x / data_size.x,
        size_local.y / data_size.y,
        size_local.z / data_size.z,
    ))
    local_loc = mathutils.Vector((
        center_local.x - (data_center.x * local_scale.x),
        center_local.y - (data_center.y * local_scale.y),
        center_local.z - (data_center.z * local_scale.z),
    ))

    try:
        lat_obj.parent = None
    except Exception:
        pass
    try:
        world_matrix = (
            main_obj.matrix_world
            @ mathutils.Matrix.Translation(local_loc)
            @ mathutils.Matrix.Diagonal((local_scale.x, local_scale.y, local_scale.z, 1.0))
        )
        lat_obj.matrix_world = world_matrix
    except Exception:
        try:
            lat_obj.location = main_obj.matrix_world @ center_local
        except Exception:
            pass
    try:
        lat_obj.parent = main_obj
        lat_obj.matrix_parent_inverse = main_obj.matrix_world.inverted()
    except Exception:
        pass

    for o, m, c_obj, s_idx in target_datas:
        try:
            o.update_tag()
        except Exception:
            pass
    try:
        lat_obj.update_tag()
    except Exception:
        pass

    self.report({'INFO'}, iface_("Smart Lattice updated: synced selection state for all linked users."))
    return {'FINISHED'}


try:
    SLM_OT_add_layer.execute = _slm_fixed_add_execute
except Exception:
    pass

try:
    SLM_OT_update_influence.execute = _slm_fixed_update_execute
except Exception:
    pass


# -----------------------------------------------------------------------------
# Smart Lattice edit-mode selection + stack activation patch
# - Edit-mode add uses only the nearest upper BASE/EditPoly selection.
# - Lattice stack activation keeps the mesh stack visible, enters EDIT_LATTICE,
#   and enables the mesh overlay without relying on an external add-on.
# - Switching away hides the lattice helper again and restores mesh editing
#   through Smart Modifier's existing carrier-selection pipeline.
# -----------------------------------------------------------------------------
from types import SimpleNamespace as _SL_SimpleNamespace


def _sl_has_any_element_selection(sel_dict):
    try:
        if not isinstance(sel_dict, dict):
            return False
        return bool(sel_dict.get('v') or sel_dict.get('e') or sel_dict.get('f'))
    except Exception:
        return False


def _sl_cache_edit_snapshot_to_ms(pre_objects_in_mode, live_sel_dicts):
    try:
        api = _sl_ms_api()
    except Exception:
        api = {}
    sel_set = api.get('sel_set') if isinstance(api, dict) else None
    get_layer = api.get('get_layer_key_from_active_object') if isinstance(api, dict) else None
    if not callable(sel_set):
        return
    for eo in list(pre_objects_in_mode or []):
        try:
            if not is_valid_obj(eo) or getattr(eo, 'type', '') != 'MESH':
                continue
        except Exception:
            continue
        sel = live_sel_dicts.get(getattr(eo, 'name', '')) or {'v': [], 'e': [], 'f': []}
        main_obj = None
        layer_key = None
        if callable(get_layer):
            try:
                res = get_layer(eo)
                if res and isinstance(res, (tuple, list)) and len(res) == 2:
                    main_obj, layer_key = res[0], res[1]
            except Exception:
                main_obj, layer_key = None, None
        if not is_valid_obj(main_obj):
            try:
                main_obj = get_main_object(eo)
            except Exception:
                main_obj = None
        if not is_valid_obj(main_obj) or getattr(main_obj, 'type', '') != 'MESH':
            continue
        if not layer_key:
            if eo == main_obj:
                layer_key = 'BASE'
            else:
                layer_key = _sl_find_ep_modifier_name_for_edit_object(main_obj, eo) or 'BASE'
        try:
            sel_set(main_obj, layer_key, {
                'v': list(sel.get('v', []) or []),
                'e': list(sel.get('e', []) or []),
                'f': list(sel.get('f', []) or []),
            })
        except Exception:
            pass


def _sl_carrier_key_for_effective(main_obj, effective_id):
    if (not main_obj) or (not effective_id) or effective_id == 'BASE':
        return 'BASE'
    try:
        idx = main_obj.modifiers.find(effective_id)
    except Exception:
        idx = -1
    if idx < 0:
        return 'BASE'
    try:
        mods = list(main_obj.modifiers)
    except Exception:
        mods = []
    for i in range(idx - 1, -1, -1):
        try:
            m = mods[i]
        except Exception:
            m = None
        if not m:
            continue
        try:
            if not bool(getattr(m, 'show_render', True)):
                continue
        except Exception:
            pass
        try:
            if is_ep_layer_check(m):
                return m.name
        except Exception:
            continue
    return 'BASE'


def _sl_smart_overlay_runtime_enabled(context):
    """Return whether Smart Overlay Suite's Mesh Overlay runtime is enabled.

    Smart Overlay Suite registers the main Mesh Overlay toggle as
    WindowManager.sos_enabled.  Older experimental builds used smo_enabled.
    If neither property exists, keep the bundled fallback overlay available so
    Smart Lattice can still show a mesh guide without the external add-on.
    """
    try:
        wm = getattr(context, 'window_manager', None)
    except Exception:
        wm = None
    if wm is None:
        return True
    try:
        if hasattr(wm, 'sos_enabled'):
            return bool(getattr(wm, 'sos_enabled', False))
    except Exception:
        return False
    try:
        if hasattr(wm, 'smo_enabled'):
            return bool(getattr(wm, 'smo_enabled', False))
    except Exception:
        return False
    return True


def _sl_get_external_smart_overlay_settings(context):
    """Resolve Smart Overlay Suite effective settings when that add-on is loaded."""
    candidates = []
    try:
        pkg = (__package__ or '').split('.')[0]
    except Exception:
        pkg = ''
    preferred = (
        'bl_ext.user_default.smart_overlay_suite.mesh',
        'smart_overlay_suite.mesh',
        'smart_overlay.mesh',
    )
    for name in preferred:
        mod = sys.modules.get(name)
        if mod is not None:
            candidates.append(mod)
    try:
        for name, mod in list(sys.modules.items()):
            if mod in candidates:
                continue
            lname = str(name or '').lower()
            if lname.endswith('.mesh') and ('smart_overlay_suite' in lname or 'smart_overlay' in lname):
                candidates.append(mod)
    except Exception:
        pass
    for mod in candidates:
        try:
            fn = getattr(mod, 'get_effective_settings', None)
            if callable(fn):
                prefs = fn(context)
                if prefs is not None:
                    return prefs
        except Exception:
            continue
    return None


def get_smo_prefs(context):
    """Return Smart Overlay drawing preferences for the lattice mesh guide.

    When Smart Overlay Suite is installed, use its effective mesh-overlay
    settings and obey its Mesh Overlay ON/OFF switch.  Without it, keep the
    lightweight internal defaults used by Smart Lattice itself.
    """
    # External Smart Overlay Suite compatibility.
    try:
        prefs = _sl_get_external_smart_overlay_settings(context)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    # Legacy compatibility: old builds copied the draw settings onto WindowManager.
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            required = (
                'show_faces_edit', 'show_edges_edit', 'show_vis_faces', 'show_vis_edges',
                'face_color', 'edge_color', 'opacity', 'double_sided',
                'face_depth_offset', 'edge_depth_offset', 'edge_size',
            )
            if all(hasattr(wm, name) for name in required):
                return wm
    except Exception:
        pass
    return _SL_SimpleNamespace(
        show_faces_edit=True,
        show_edges_edit=True,
        show_vis_faces=True,
        show_vis_edges=True,
        face_color=(0.09, 0.63, 1.00),
        edge_color=(0.96, 0.98, 1.00),
        opacity=0.16,
        double_sided=True,
        face_depth_offset=3.0,
        edge_depth_offset=5.0,
        edge_size=1.4,
    )


def _sl_ms_post_object_mode(main_obj, context, effective_active_id):
    """Prepare the lattice helper before Smart Modifier switches back into edit mode.

    ms__safe_mode_set() restores the helper's previous hidden state after mode
    switching.  If the lattice was still hidden here, EDIT_LATTICE would open on
    a helper that immediately becomes hidden again.  Unhide it *before* the safe
    mode transition when Smart Lattice is the chosen stack item.
    """
    try:
        if not is_valid_obj(main_obj) or not effective_active_id or effective_active_id == 'BASE':
            return
        mod = main_obj.modifiers.get(str(effective_active_id))
        if not _sl_ms_match_modifier(mod):
            return
        lat_obj = getattr(mod, 'object', None)
        if not is_valid_obj(lat_obj):
            return
        try:
            lat_obj['sl_main_target'] = main_obj.name
        except Exception:
            pass
        _sl_set_hidden(lat_obj, False)
        try:
            lat_obj.hide_select = False
        except Exception:
            pass
        try:
            lat_obj.hide_viewport = False
        except Exception:
            pass
    except Exception:
        pass


def _sl_ms_on_stack_change(main_obj, context, interactive):
    try:
        if not is_valid_obj(main_obj):
            return False
        active_id = str(main_obj.get('ui_active_item', 'BASE') or 'BASE')
        if active_id == 'BASE':
            return False
        mod = main_obj.modifiers.get(active_id)
        if not _sl_ms_match_modifier(mod):
            return False
        _sl_request_live_runtime()
        lat_obj = getattr(mod, 'object', None)
        if is_valid_obj(lat_obj):
            try:
                lat_obj['sl_main_target'] = main_obj.name
            except Exception:
                pass
            _sl_set_hidden(lat_obj, False)
            try:
                main_obj.update_tag()
            except Exception:
                pass
            try:
                lat_obj.update_tag()
            except Exception:
                pass
    except Exception:
        pass
    return False


def _sl_ms_sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive):
    """Smart Modifier integration point for Smart Lattice.

    Desired behavior:
    - Only the active Smart Lattice helper stays visible/selectable.
    - The mesh object remains the stack owner in the UI.
    - When Smart Lattice is active, Smart Modifier edits the lattice helper in
      EDIT_LATTICE while the mesh overlay continues to draw on the main mesh.
    - Switching to Base or another modifier hides the lattice helper again.
    """
    del show_end, interactive
    try:
        res_target = None
        for m in list(getattr(main_obj, 'modifiers', []) or []):
            if not _sl_ms_match_modifier(m):
                continue
            lat_obj = getattr(m, 'object', None)
            if not is_valid_obj(lat_obj):
                continue
            is_effective_active = (m.name == effective_active_id) and bool(getattr(m, 'show_render', True))
            if is_effective_active:
                res_target = lat_obj
                try:
                    lat_obj['sl_main_target'] = main_obj.name
                except Exception:
                    pass
                try:
                    lat_obj['sl_carrier_key'] = str(carrier_key or 'BASE')
                except Exception:
                    pass
                _sl_set_hidden(lat_obj, False)
                try:
                    lat_obj.hide_select = False
                except Exception:
                    pass
            else:
                _ttl = 0.25
                try:
                    t_force = float(bpy.app.driver_namespace.get('_MS_FORCE_SL_SHARED_REFRESH_T', 0.0) or 0.0)
                    if (time.time() - t_force) < 0.5:
                        _ttl = 0.0
                except Exception:
                    pass
                try:
                    shared_active = _sl_is_shared_active(lat_obj, ttl=_ttl)
                except Exception:
                    shared_active = False
                if not shared_active:
                    _sl_set_hidden(lat_obj, True)
        if is_valid_obj(res_target):
            return {'target_obj': res_target, 'priority': 32}
    except Exception:
        pass
    return {}


def _slm_fixed_add_execute(self, context):
    _sl_request_live_runtime()
    if getattr(self, 'resolution_type', 'CUSTOM') != 'CUSTOM':
        try:
            self.res_u = self.res_v = self.res_w = int(self.resolution_type)
        except Exception:
            pass

    pre_selected = list(getattr(context, 'selected_objects', []) or [])
    pre_active = getattr(context, 'active_object', None)
    edit_mode_request = str(getattr(context, 'mode', '') or '') == 'EDIT_MESH'
    pre_objects_in_mode = list(getattr(context, 'objects_in_mode', []) or []) if edit_mode_request else []
    if edit_mode_request and not pre_objects_in_mode:
        try:
            eo = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
            if is_valid_obj(eo) and getattr(eo, 'type', '') == 'MESH':
                pre_objects_in_mode = [eo]
        except Exception:
            pre_objects_in_mode = []

    live_sel_dicts = {}
    if edit_mode_request:
        for o in pre_objects_in_mode:
            try:
                if getattr(o, 'type', '') == 'MESH':
                    live_sel_dicts[o.name] = _sl_capture_selection(o)
            except Exception:
                pass
        _sl_cache_edit_snapshot_to_ms(pre_objects_in_mode, live_sel_dicts)

    raw_src = pre_objects_in_mode if (edit_mode_request and pre_objects_in_mode) else pre_selected
    raw_targets = [get_main_object(o) for o in raw_src if o and getattr(o, 'type', '') == 'MESH']
    anchor = get_main_object(pre_active)

    _sl__safe_object_mode(context)

    targets = []
    seen = set()
    for raw_target in raw_targets:
        try:
            if is_valid_obj(raw_target) and getattr(raw_target, 'type', '') == 'MESH' and raw_target.name not in seen:
                targets.append(raw_target)
                seen.add(raw_target.name)
        except Exception:
            pass
    if not targets:
        if is_valid_obj(anchor) and getattr(anchor, 'type', '') == 'MESH':
            targets = [anchor]
        else:
            self.report({'WARNING'}, t('Please select a mesh object.'))
            return {'CANCELLED'}
    if anchor not in targets:
        anchor = targets[0]

    _ms_lock_fn = None
    _ms_prev_lock = False
    try:
        _api = _sl_ms_api()
        _ms_lock_fn = _api.get('shared_lock_set')
        if callable(_ms_lock_fn):
            _ms_prev_lock = bool(bpy.app.driver_namespace.get('_MS_MODIFIER_STACK_SYNC_LOCK', False))
            _ms_lock_fn(True)
    except Exception:
        _ms_lock_fn = None

    try:
        mat_anchor_inv = anchor.matrix_world.inverted()
        target_idx_info = {}
        target_data_list = []
        for obj in targets:
            active_id = obj.get('ui_active_item', 'BASE')
            try:
                if is_valid_obj(pre_active) and pre_active != obj:
                    ep_mod_name = _sl_find_ep_modifier_name_for_edit_object(obj, pre_active)
                    if ep_mod_name:
                        active_id = ep_mod_name
            except Exception:
                pass
            if active_id == 'BASE':
                target_idx = 0
            else:
                try:
                    aidx = obj.modifiers.find(active_id)
                except Exception:
                    aidx = -1
                target_idx = (aidx + 1) if aidx >= 0 else len(obj.modifiers)
            target_idx_info[obj.name] = target_idx
            carrier_obj = _find_nearest_upper_carrier_object(obj, target_idx)
            sel_indices = _sl_get_current_carrier_selection(obj, carrier_obj, live_sel_dicts, strict_live=edit_mode_request)
            target_data_list.append((obj, carrier_obj, sorted(sel_indices) if sel_indices else []))

        has_any_edit_selection = bool(edit_mode_request and any(bool(s_idx) for _, _, s_idx in target_data_list))
        if edit_mode_request and not has_any_edit_selection:
            self.report({'WARNING'}, t('Please select vertices, edges, or faces.'))
            return {'CANCELLED'}

        effective_target_data = []
        if has_any_edit_selection:
            effective_target_data = [(obj, carrier_obj, s_idx) for (obj, carrier_obj, s_idx) in target_data_list if s_idx]
        else:
            effective_target_data = [(obj, carrier_obj, None) for (obj, carrier_obj, _s) in target_data_list]
        if not effective_target_data:
            self.report({'WARNING'}, t('No valid selection found.'))
            return {'CANCELLED'}

        if anchor not in [obj for (obj, _carrier, _s) in effective_target_data]:
            anchor = effective_target_data[0][0]
            try:
                mat_anchor_inv = anchor.matrix_world.inverted()
            except Exception:
                mat_anchor_inv = mathutils.Matrix.Identity(4)

        for _obj, _carrier, _sel in effective_target_data:
            try:
                _sl_prune_unused_smart_lattice_vertex_groups(_obj)
            except Exception:
                pass

        all_points_local = []
        selection_info = {}
        for obj, carrier_obj, sel_indices in effective_target_data:
            mat_diff = mat_anchor_inv @ carrier_obj.matrix_world
            if sel_indices:
                selection_info[obj.name] = list(sel_indices)
                coords = _fast_get_selected_points(carrier_obj, selection_info[obj.name])
                if len(coords):
                    all_points_local.append(_fast_transform_points(coords, mat_diff))
            else:
                selection_info[obj.name] = None
                try:
                    bbox = np.array(carrier_obj.bound_box, dtype=np.float32)
                    all_points_local.append(_fast_transform_points(bbox, mat_diff))
                except Exception:
                    pass
        if not all_points_local:
            self.report({'WARNING'}, t('No valid selection found.'))
            return {'CANCELLED'}

        merged_pts = np.vstack(all_points_local)
        if len(merged_pts) == 0:
            return {'CANCELLED'}
        min_arr = np.min(merged_pts, axis=0)
        max_arr = np.max(merged_pts, axis=0)
        center_local = (mathutils.Vector(min_arr) + mathutils.Vector(max_arr)) / 2.0
        size_local = mathutils.Vector(max_arr) - mathutils.Vector(min_arr)
        size_local.x = max(size_local.x, 0.01)
        size_local.y = max(size_local.y, 0.01)
        size_local.z = max(size_local.z, 0.01)

        created_targets = [obj for (obj, _carrier, _sel) in effective_target_data]
        is_multi = len(created_targets) > 1
        lat_name = _sl_get_next_smartlattice_name(created_targets, base='SmartLattice')
        lat_data = bpy.data.lattices.new(f'{lat_name}_Data')
        lat_obj = bpy.data.objects.new(lat_name, lat_data)
        _parent, sl_col = ensure_modifier_system_collections(context.scene)
        try:
            if sl_col is not None:
                sl_col.objects.link(lat_obj)
        except Exception:
            pass
        lat_data.points_u = self.res_u
        lat_data.points_v = self.res_v
        lat_data.points_w = self.res_w
        lat_data.interpolation_type_u = lat_data.interpolation_type_v = lat_data.interpolation_type_w = 'KEY_BSPLINE'
        lat_data.use_outside = False

        try:
            lat_obj.matrix_world = anchor.matrix_world.copy()
        except Exception:
            pass
        try:
            lat_obj.location = anchor.matrix_world @ center_local
        except Exception:
            lat_obj.location = anchor.location.copy()
        try:
            s = anchor.matrix_world.to_scale()
            lat_obj.scale = (size_local.x * s.x, size_local.y * s.y, size_local.z * s.z)
        except Exception:
            lat_obj.scale = size_local
        try:
            lat_obj.parent = anchor
            lat_obj.matrix_parent_inverse = anchor.matrix_world.inverted()
        except Exception:
            pass
        try:
            lat_obj['sl_main_target'] = anchor.name
            lat_obj['sl_carrier_key'] = _sl_carrier_key_for_effective(anchor, str(anchor.get('ui_active_item', 'BASE') or 'BASE'))
        except Exception:
            pass
        try:
            _sl_register_lat_user(lat_obj.name, anchor.name)
        except Exception:
            pass
        try:
            lat_obj['_ms_deselect_lattice_points_once'] = True
        except Exception:
            pass

        instance_id = uuid.uuid4().hex if is_multi else ''
        created_mod_anchor = None
        for obj, _carrier_obj, _sel_indices in effective_target_data:
            target_idx = int(target_idx_info.get(obj.name, len(obj.modifiers)))
            indices = selection_info.get(obj.name)
            vg_name = None
            if indices:
                try:
                    vg_name = get_unique_vgroup_name(obj, lat_name)
                    _sl_assign_vgroup_indices(obj, vg_name, indices, reset=True)
                    try:
                        if _carrier_obj and _carrier_obj != obj and getattr(_carrier_obj, 'type', '') == 'MESH':
                            _sl_assign_vgroup_indices(_carrier_obj, vg_name, indices, reset=True)
                    except Exception:
                        pass
                except Exception:
                    vg_name = None
            try:
                mod = obj.modifiers.new(name=lat_name, type='LATTICE')
            except Exception:
                continue
            mod.object = lat_obj
            mod.show_in_editmode = True
            mod.show_on_cage = True
            try:
                mod.show_viewport = True
            except Exception:
                pass
            if vg_name:
                try:
                    mod.vertex_group = vg_name
                except Exception:
                    pass
            else:
                try:
                    mod.vertex_group = ''
                except Exception:
                    pass
            try:
                cur = obj.modifiers.find(mod.name)
                if cur >= 0:
                    obj.modifiers.move(cur, max(0, min(target_idx, len(obj.modifiers) - 1)))
            except Exception:
                pass
            try:
                if instance_id:
                    _sl_ms_obj_set_instance_id(obj, mod.name, instance_id, disp_name=lat_name)
                else:
                    _sl_ms_obj_set_disp_name(obj, mod.name, lat_name)
            except Exception:
                pass
            try:
                obj['ui_active_item'] = mod.name
                obj.modifiers.active = mod
                obj.update_tag()
            except Exception:
                pass
            try:
                _sl_register_lat_user(lat_obj.name, obj.name)
            except Exception:
                pass
            if obj == anchor:
                created_mod_anchor = mod
        if not created_mod_anchor:
            try:
                bpy.data.objects.remove(lat_obj, do_unlink=True)
            except Exception:
                pass
            return {'CANCELLED'}

        try:
            if hasattr(bpy.ops.object, 'ms_switch_level'):
                with context.temp_override(active_object=anchor, selected_objects=created_targets, object=anchor):
                    bpy.ops.object.ms_switch_level('EXEC_DEFAULT', False, target_mod_name=created_mod_anchor.name, target_obj_name=anchor.name)
            else:
                raise RuntimeError
        except Exception:
            try:
                if hasattr(bpy.ops.object, 'ms_switch_level'):
                    bpy.ops.object.ms_switch_level('EXEC_DEFAULT', False, target_mod_name=created_mod_anchor.name, target_obj_name=anchor.name)
            except Exception:
                pass

        _sl__enter_edit_lattice(context, lat_obj)
        try:
            anchor['ms_sl_engaged'] = True
            anchor['ms_sl_engaged_mod'] = created_mod_anchor.name
        except Exception:
            pass
        return {'FINISHED'}
    finally:
        if _ms_lock_fn:
            try:
                _ms_lock_fn(_ms_prev_lock)
            except Exception:
                pass


def _slm_fixed_update_execute(self, context):
    _sl_request_live_runtime()
    main_obj = bpy.data.objects.get(self.main_obj_name) if getattr(self, 'main_obj_name', '') else None
    mod = None
    if not is_valid_obj(main_obj):
        obj = getattr(context, 'object', None)
        if is_valid_obj(obj) and getattr(obj, 'type', '') == 'MESH':
            main_obj = obj
    if main_obj:
        if getattr(self, 'modifier_name', ''):
            mod = main_obj.modifiers.get(self.modifier_name)
        else:
            am = getattr(main_obj.modifiers, 'active', None)
            if am and am.type == 'LATTICE' and am.object and ('sl_main_target' in am.object):
                mod = am
    if (not is_valid_obj(main_obj) or not mod) and getattr(getattr(context, 'active_object', None), 'type', '') == 'LATTICE':
        lat_active = context.active_object
        if 'sl_main_target' in lat_active:
            main_obj = bpy.data.objects.get(lat_active['sl_main_target'])
            if is_valid_obj(main_obj):
                for m in main_obj.modifiers:
                    if m.type == 'LATTICE' and getattr(m, 'object', None) == lat_active:
                        mod = m
                        break
    if (not is_valid_obj(main_obj)) or (not mod) or mod.type != 'LATTICE' or (not getattr(mod, 'object', None)):
        self.report({'WARNING'}, t('No valid lattice found.'))
        return {'CANCELLED'}
    lat_obj = mod.object

    edit_mode_request = str(getattr(context, 'mode', '') or '') == 'EDIT_MESH'
    live_sel_dicts = {}
    update_objects_in_mode = []
    if edit_mode_request:
        try:
            update_objects_in_mode = list(getattr(context, 'objects_in_mode', []) or [])
        except Exception:
            update_objects_in_mode = []
        if not update_objects_in_mode:
            try:
                eo = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
                if is_valid_obj(eo) and getattr(eo, 'type', '') == 'MESH':
                    update_objects_in_mode = [eo]
            except Exception:
                update_objects_in_mode = []
        for o in update_objects_in_mode:
            try:
                if o.type == 'MESH':
                    live_sel_dicts[o.name] = _sl_capture_selection(o)
            except Exception:
                pass
        _sl_cache_edit_snapshot_to_ms(update_objects_in_mode, live_sel_dicts)

    _sl__safe_object_mode(context)

    shared_users = []
    for o in bpy.data.objects:
        try:
            if o.type != 'MESH':
                continue
            for m in o.modifiers:
                if m.type == 'LATTICE' and getattr(m, 'object', None) == lat_obj:
                    shared_users.append((o, m))
                    break
        except Exception:
            continue
    if not shared_users:
        self.report({'WARNING'}, t('No valid lattice users found.'))
        return {'CANCELLED'}

    mat_main_inv = main_obj.matrix_world.inverted()
    target_datas = []
    for o, m in shared_users:
        t_idx = o.modifiers.find(m.name)
        c_obj = _find_nearest_upper_carrier_object(o, t_idx)
        s_idx = _sl_get_current_carrier_selection(o, c_obj, live_sel_dicts, strict_live=edit_mode_request)
        target_datas.append((o, m, c_obj, sorted(s_idx) if s_idx else []))

    has_any_edit_selection = bool(edit_mode_request and any(bool(s_idx) for _o, _m, _c, s_idx in target_datas))
    contributing = []
    if has_any_edit_selection:
        contributing = [(o, m, c_obj, s_idx) for (o, m, c_obj, s_idx) in target_datas if s_idx]
        if not contributing:
            self.report({'WARNING'}, t('Please select vertices, edges, or faces.'))
            return {'CANCELLED'}
    else:
        contributing = list(target_datas)

    all_points_local = []
    for o, m, c_obj, s_idx in target_datas:
        old_vg = getattr(m, 'vertex_group', '') or ''
        if has_any_edit_selection and (not s_idx):
            # Leave untouched users as-is; only the explicitly selected carriers define
            # the new influence region when editing from Edit Mode.
            continue
        try:
            if old_vg:
                _sl_remove_vgroup_if_present(o, old_vg)
                try:
                    if c_obj and c_obj != o and getattr(c_obj, 'type', '') == 'MESH':
                        _sl_remove_vgroup_if_present(c_obj, old_vg)
                except Exception:
                    pass
        except Exception:
            pass
        if s_idx:
            try:
                vg_name = get_unique_vgroup_name(o, m.name)
                _sl_assign_vgroup_indices(o, vg_name, s_idx, reset=True)
                try:
                    if c_obj and c_obj != o and getattr(c_obj, 'type', '') == 'MESH':
                        _sl_assign_vgroup_indices(c_obj, vg_name, s_idx, reset=True)
                except Exception:
                    pass
                m.vertex_group = vg_name
            except Exception:
                try:
                    m.vertex_group = ''
                except Exception:
                    pass
            coords = _fast_get_selected_points(c_obj, s_idx if s_idx else None)
            if len(coords):
                all_points_local.append(_fast_transform_points(coords, mat_main_inv @ c_obj.matrix_world))
        else:
            try:
                m.vertex_group = ''
            except Exception:
                pass
            try:
                bbox = np.array(c_obj.bound_box, dtype=np.float32)
                all_points_local.append(_fast_transform_points(bbox, mat_main_inv @ c_obj.matrix_world))
            except Exception:
                pass

    if not all_points_local:
        self.report({'WARNING'}, t('No valid selection found.'))
        return {'CANCELLED'}

    merged_pts = np.vstack(all_points_local)
    if len(merged_pts) == 0:
        return {'CANCELLED'}
    min_co = mathutils.Vector(np.min(merged_pts, axis=0))
    max_co = mathutils.Vector(np.max(merged_pts, axis=0))
    center_local = (min_co + max_co) / 2.0
    size_local = max_co - min_co
    size_local.x = max(size_local.x, 0.01)
    size_local.y = max(size_local.y, 0.01)
    size_local.z = max(size_local.z, 0.01)

    data_min = mathutils.Vector((1e18, 1e18, 1e18))
    data_max = mathutils.Vector((-1e18, -1e18, -1e18))
    pts = getattr(lat_obj.data, 'points', None)
    if pts:
        for p in pts:
            co = getattr(p, 'co_deform', None) or getattr(p, 'co', None)
            if not co:
                continue
            data_min.x, data_max.x = min(data_min.x, co.x), max(data_max.x, co.x)
            data_min.y, data_max.y = min(data_min.y, co.y), max(data_max.y, co.y)
            data_min.z, data_max.z = min(data_min.z, co.z), max(data_max.z, co.z)
    if data_min.x > data_max.x:
        data_min = mathutils.Vector((-0.5, -0.5, -0.5))
        data_max = mathutils.Vector((0.5, 0.5, 0.5))
    data_center = (data_min + data_max) * 0.5
    data_size = data_max - data_min
    data_size.x = max(abs(data_size.x), 1e-6)
    data_size.y = max(abs(data_size.y), 1e-6)
    data_size.z = max(abs(data_size.z), 1e-6)
    local_scale = mathutils.Vector((
        size_local.x / data_size.x,
        size_local.y / data_size.y,
        size_local.z / data_size.z,
    ))
    local_loc = mathutils.Vector((
        center_local.x - (data_center.x * local_scale.x),
        center_local.y - (data_center.y * local_scale.y),
        center_local.z - (data_center.z * local_scale.z),
    ))
    try:
        lat_obj.parent = None
    except Exception:
        pass
    try:
        world_matrix = (
            main_obj.matrix_world
            @ mathutils.Matrix.Translation(local_loc)
            @ mathutils.Matrix.Diagonal((local_scale.x, local_scale.y, local_scale.z, 1.0))
        )
        lat_obj.matrix_world = world_matrix
    except Exception:
        try:
            lat_obj.location = main_obj.matrix_world @ center_local
        except Exception:
            pass
    try:
        lat_obj.parent = main_obj
        lat_obj.matrix_parent_inverse = main_obj.matrix_world.inverted()
    except Exception:
        pass
    for o, m, c_obj, s_idx in target_datas:
        try:
            o.update_tag()
        except Exception:
            pass
    try:
        lat_obj.update_tag()
    except Exception:
        pass
    self.report({'INFO'}, iface_('Smart Lattice updated: synced selection state for selected carriers.'))
    return {'FINISHED'}


def _sl_ms_build_plugin():
    return {
        'id': 'smart_lattice',
        'label': 'Smart Lattice',
        'label_ja': 'スマートラティス',
        'operator_id': 'smart_lattice.add_layer',
        'icon': 'MOD_LATTICE',
        'group': 'deformers',
        'priority': 83,
        'always_sync': True,
        'description_en': 'Add a stack-managed Smart Lattice layer that behaves like an FFD-style cage modifier with helper-aware editing.',
        'description_ja': 'FFD風ケージモディファイアとして扱える、スタック管理付き Smart Lattice レイヤーを追加します。',
        'usage_en': 'Use Object Mode or Edit Mesh on an active mesh object, then run Smart Lattice to add the stack-managed cage layer.',
        'usage_ja': 'オブジェクトモードまたは編集メッシュでアクティブメッシュを対象に実行し、スタック管理されるケージレイヤーを追加します。',
        'match_modifier': _sl_ms_match_modifier,
        'get_main_object': _sl_ms_get_main_object,
        'ui_active_from_object': _sl_ui_active_from_object,
        'carrier_key_for_effective': _sl_carrier_key_for_effective,
        'sync_objects': _sl_ms_sync_objects,
        'cleanup_before_apply': _sl_ms_cleanup_before_apply,
        'cleanup_before_remove': _sl_ms_cleanup_before_remove,
        'before_item_action': _sl_ms_before_item_action,
        'after_item_action': _sl_ms_after_item_action,
        'draw_modifier_properties_extra': _sl_ms_draw_modifier_properties_extra,
        'draw_add_menu': _sl_ms_draw_add_menu,
        'post_object_mode': _sl_ms_post_object_mode,
        'on_stack_change': _sl_ms_on_stack_change,
    }


try:
    SLM_OT_add_layer.execute = _slm_fixed_add_execute
except Exception:
    pass

try:
    SLM_OT_update_influence.execute = _slm_fixed_update_execute
except Exception:
    pass
