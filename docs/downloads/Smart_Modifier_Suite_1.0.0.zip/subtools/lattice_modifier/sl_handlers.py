# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose Smart Lattice's dependency-update callback."""

from .sl_core import smart_lattice_depsgraph_update

__all__ = ["smart_lattice_depsgraph_update"]
