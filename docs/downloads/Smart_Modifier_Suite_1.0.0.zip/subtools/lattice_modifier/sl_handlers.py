# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from .sl_core import smart_lattice_depsgraph_update

__all__=["smart_lattice_depsgraph_update"]
