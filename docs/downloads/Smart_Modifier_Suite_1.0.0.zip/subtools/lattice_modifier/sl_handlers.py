# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from .sl_core import smart_lattice_depsgraph_update

__all__=["smart_lattice_depsgraph_update"]
