# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from .sl_core import VIEW3D_PT_smart_lattice_standalone

__all__=["VIEW3D_PT_smart_lattice_standalone"]
