# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the Smart Lattice sidebar panel."""

from .sl_core import VIEW3D_PT_smart_lattice_standalone

__all__ = ["VIEW3D_PT_smart_lattice_standalone"]
