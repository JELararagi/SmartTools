# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# This file provides Japanese translations for UI strings used by this add-on.
# Source language: English

translation_dict = {
    "ja_JP": {
        ('*', '* For stack management, please use Smart Modifier.'): '※スタック管理は Smart Modifierをご利用ください',
        ('*', '2 x 2 x 2'): '2 × 2 × 2',
        ('*', '2 x 3 x 2'): '2 x 3 x 2',
        ('*', '3 x 3 x 3'): '3 x 3 x 3',
        ('*', '4 x 4 x 4'): '4 x 4 x 4',
        ('*', 'Add Smart Lattice'): 'Smart Latticeを追加',
        ('*', 'Add Smart Lattice (a helper system that makes lattice deformation easier) to the selected mesh.\n\n- Automatically creates a Lattice and the required helper objects/collections.\n- Places the lattice to fit the mesh size.\n- Lets you choose the resolution (U/V/W divisions) to control deformation detail.\n\nTip: Higher resolution is heavier—start low and increase only if needed.'): '選択中のメッシュに Smart Lattice（ラティス変形を扱いやすくする補助システム）を追加します。\n\n・自動で Lattice と必要な補助オブジェクト/コレクションを作成します。\n・メッシュの大きさに合わせてラティスを配置します。\n・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n\nヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。',
        ('*', 'Coarse (lightweight)'): '粗い（軽い）',
        ('*', 'Custom'): 'カスタム',
        ('*', 'FFD lattice tool integrated with Smart Modifier'): 'Smart Modifier連動のFFDラティスツール',
        ('*', 'Fine (heavier)'): '細かい（やや重い）',
        ('*', 'Main object name (internal)'): '対象メインオブジェクト名（内部用）',
        ('*', 'Modifier name (internal)'): '対象モディファイア名（内部用）',
        ('*', 'No valid lattice found.'): '有効なラティスが見つかりません。',
        ('*', 'Number of divisions in U (mainly X) direction.'): 'U方向（主にX方向）の分割数です。',
        ('*', 'Number of divisions in V (mainly Y) direction.'): 'V方向（主にY方向）の分割数です。',
        ('*', 'Number of divisions in W (mainly Z) direction.'): 'W方向（主にZ方向）の分割数です。',
        ('*', 'Please select a mesh object.'): 'メッシュオブジェクトを選択してください。',
        ('*', 'Recalculate Smart Lattice influence (the lattice-to-mesh deformation range).\n\n- Use this after changing the lattice size/position if deformation is offset or not working.\n- Automatically detects and updates the target Smart Lattice.\n\nTip: Applying/confirming lattice edits first tends to be more stable.'): 'Smart Lattice の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n\n・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n・対象の Smart Lattice（ラティス）を自動で検出して更新します。\n\nヒント：まずラティス側の変形を確定してから実行すると安定します。',
        ('*', 'Resolution'): '解像度',
        ('*', 'Set the lattice divisions (U/V/W).\nChoose a preset (2/3/4) or Custom.\n\nNote: Higher values allow finer deformation but are heavier.'): 'ラティスの分割数（U/V/W）を指定します。\nプリセット（2/3/4）またはカスタムを選択できます。\n\n※値が大きいほど細かく変形できますが処理が重くなります。',
        ('*', 'Show a lightweight standalone N-panel tab so you can still use Smart Lattice without Smart Modifier.\nNormally, managing it from Smart Modifier is recommended. Turn this ON only for standalone use.'): 'Smart Modifier が無い環境でも Smart Lattice を最低限操作できるように、N パネルに単体用の簡易タブを表示します。\n通常は Smart Modifier から管理するのがおすすめです。単体運用時だけ ON にしてください。',
        ('*', 'Show a standalone N-panel tab even without Smart Modifier.'): 'Smart Modifierがない環境でも使えるように、独自のNパネルタブを表示します',
        ('*', 'Show dedicated N-panel tab'): 'Nパネルに専用タブを表示',
        ('*', 'Smart Lattice'): 'スマートラティス',
        ('*', 'Smart Lattice Resolution'): 'Smart Lattice 解像度',
        ('*', 'Smart Lattice updated: synced selection state for all linked users.'): 'SmartLattice 更新: 全共有ユーザーの選択状態を反映',
        ('*', 'Smart Lattice の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n\n・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n・対象の Smart Lattice（ラティス）を自動で検出して更新します。\n\nヒント：まずラティス側の変形を確定してから実行すると安定します。'): 'スマートラティス の影響範囲（ラティス→メッシュの作用範囲）を再計算します。\n\n・ラティスのサイズ/位置を変更した後に、変形がずれる/効かない場合に実行します。\n・対象の スマートラティス（ラティス）を自動で検出して更新します。\n\nヒント：まずラティス側の変形を確定してから実行すると安定します。',
        ('*', 'Smart Lattice 解像度'): 'スマートラティス 解像度',
        ('*', 'Smart Latticeを追加'): 'スマートラティスを追加',
        ('*', 'Smart Lattice（単体）'): 'スマートラティス（単体）',
        ('*', 'SmartLattice'): 'スマートラティス',
        ('*', 'SmartLattice Standalone'): 'スマートラティス（単体）',
        ('*', 'SmartLattice Update: reflect selection state of all shared users'): 'SmartLattice 更新: 全共有ユーザーの選択状態を反映',
        ('*', 'Specify U/V/W separately'): 'U/V/W を個別に指定',
        ('*', 'Standard'): '標準',
        ('*', 'U'): 'U',
        ('*', 'Update Influence'): '影響範囲の更新',
        ('*', 'V'): 'V',
        ('*', 'W'): 'W',
        ('*', '選択中のメッシュに Smart Lattice（ラティス変形を扱いやすくする補助システム）を追加します。\n\n・自動で Lattice と必要な補助オブジェクト/コレクションを作成します。\n・メッシュの大きさに合わせてラティスを配置します。\n・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n\nヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。'): '選択中のメッシュに スマートラティス（ラティス変形を扱いやすくする補助システム）を追加します。\n\n・自動で Lattice と必要な補助オブジェクト/コレクションを作成します。\n・メッシュの大きさに合わせてラティスを配置します。\n・解像度（U/V/Wの分割数）を指定して変形の細かさを調整できます。\n\nヒント：細かくするほど重くなるので、まず低め→必要に応じて上げるのがおすすめです。',
    }
}
# --- Toolset complete i18n override START ---
translation_dict.setdefault('ja_JP', {}).update({('*', '2 x 2 x 2'): '2 × 2 × 2', ('*', '3 x 3 x 3'): '3 × 3 × 3', ('*', '4 x 4 x 4'): '4 × 4 × 4'})
# --- Toolset complete i18n override END ---
