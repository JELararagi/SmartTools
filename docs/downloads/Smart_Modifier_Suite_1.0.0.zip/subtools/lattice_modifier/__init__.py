# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import sys
import types

import bpy

try:
    from ...translation import choose_text as _sms_choose_text
except Exception:
    def _sms_choose_text(en, ja='', context=None):
        return str(en or ja or '')

from ... import feature_toggle as _feature_toggle
bl_info = {
    "name": "Smart Lattice Modifier",
    "author": "JELararagi",
    "version": (1, 9, 5),
    "blender": (5, 0, 0),
    "location": _sms_choose_text ("Smart Modifier User Menu / View3D > N-Panel (Optional)", "Smart Modifier ユーザーメニュー / 3Dビュー > Nパネル（任意）"),
    "description": _sms_choose_text ("FFD lattice tool integrated with Smart Modifier", "Smart Modifier に統合された FFD ラティスツールです。"),
    "category": "Object",
}

# NOTE:
# This add-on is modularized. Avoid `from .sl_core import *` because
# private integration helpers (starting with '_') are not imported by star-import.

from .translation import translation_dict
from . import sl_core as sl
from .sl_operators import SLM_OT_add_layer, SLM_OT_update_influence
from .sl_ui import VIEW3D_PT_smart_lattice_standalone
from .sl_handlers import smart_lattice_depsgraph_update

classes = (
    SLM_OT_add_layer,
    SLM_OT_update_influence,
    VIEW3D_PT_smart_lattice_standalone,
)

# Smart Modifier keeps configuration in the N-panel only. The legacy standalone
# preference class is intentionally not registered; embedded registration
# also excludes the optional standalone N-panel.
_EMBEDDED_EXCLUDE = {VIEW3D_PT_smart_lattice_standalone}
classes_embedded = tuple(cls for cls in classes if cls not in _EMBEDDED_EXCLUDE)

def _sl_delayed_register_plugin():
    try:
        sl._sl_ms_register_plugin()
    except Exception:
        pass
    return None






_draw_handler = None
_RUNTIME_ENABLED = False


def _sl_register_runtime_handlers():
    global _draw_handler
    dn = bpy.app.driver_namespace
    try:
        if _draw_handler is None:
            _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
                sl.draw_lattice_overlay, (), 'WINDOW', 'POST_VIEW'
            )
    except Exception:
        _draw_handler = None
    dn["_SL_DRAW_HANDLER"] = _draw_handler

    try:
        if smart_lattice_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(smart_lattice_depsgraph_update)
    except Exception:
        pass
    dn["_SL_DEPSGRAPH_UPDATE"] = smart_lattice_depsgraph_update

    try:
        if hasattr(bpy.app.timers, "is_registered"):
            if not bpy.app.timers.is_registered(sl._sl_cleanup_timer):
                bpy.app.timers.register(sl._sl_cleanup_timer, persistent=True)
        else:
            bpy.app.timers.register(sl._sl_cleanup_timer, persistent=True)
    except Exception:
        try:
            bpy.app.timers.register(sl._sl_cleanup_timer, persistent=True)
        except Exception:
            pass
    dn["_SL_CLEANUP_TIMER"] = sl._sl_cleanup_timer


def _sl_unregister_runtime_handlers():
    global _draw_handler
    dn = bpy.app.driver_namespace

    try:
        sl._sl_uninstall_smart_overlay_occluder_patch()
    except Exception:
        pass

    if _draw_handler:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        except Exception:
            pass
        _draw_handler = None

    try:
        if smart_lattice_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(smart_lattice_depsgraph_update)
    except Exception:
        pass

    try:
        if hasattr(bpy.app.timers, "is_registered") and bpy.app.timers.is_registered(sl._sl_cleanup_timer):
            bpy.app.timers.unregister(sl._sl_cleanup_timer)
    except Exception:
        pass

    for k in ("_SL_DRAW_HANDLER", "_SL_DEPSGRAPH_UPDATE", "_SL_CLEANUP_TIMER"):
        try:
            dn.pop(k, None)
        except Exception:
            pass


# Blender REPLACES bpy.app.driver_namespace on every file load, which erased
# _SL_ACTIVE_MODULE.  set_runtime_enabled() then returned early (line "if
# dn.get('_SL_ACTIVE_MODULE') != __name__"), so the live overlay/depsgraph
# handlers were never re-armed, and unregister_embedded() no longer recognised
# itself as the owner, so it skipped its own draw-handler/timer teardown.  The
# owner mark below lives in Smart Modifier's process-lifetime anchor (see
# core._ms_ns_anchor_store), which survives file loads and the live-update
# submodule purge.
_SL_NS_ANCHOR_MODULE_NAME = "jelararagi_smart_modifier_ns_anchor_v1"
_SL_NS_ANCHOR_ATTR = "SMS_NS_VALUES"
_SL_BRIDGE_OWNER_KEY = "_SL_BRIDGE_OWNER_V1"


def _sl_ns_anchor_store():
    """Smart Modifier's process-lifetime driver_namespace anchor.  Never raises."""
    try:
        module = sys.modules.get(_SL_NS_ANCHOR_MODULE_NAME)
        if not isinstance(module, types.ModuleType):
            module = types.ModuleType(_SL_NS_ANCHOR_MODULE_NAME)
            module.__doc__ = (
                "Smart Modifier Suite driver_namespace anchor.  Not an importable module."
            )
            setattr(module, _SL_NS_ANCHOR_ATTR, {})
            sys.modules[_SL_NS_ANCHOR_MODULE_NAME] = module
        store = getattr(module, _SL_NS_ANCHOR_ATTR, None)
        if not isinstance(store, dict):
            store = {}
            setattr(module, _SL_NS_ANCHOR_ATTR, store)
        return store
    except Exception:
        return {}


def _sl_publish_bridges():
    """(Re-)claim Smart Lattice ownership in driver_namespace.  Idempotent."""
    try:
        bpy.app.driver_namespace["_SL_ACTIVE_MODULE"] = __name__
    except Exception:
        return False
    _sl_ns_anchor_store()[_SL_BRIDGE_OWNER_KEY] = __name__
    return True


def _sl_release_bridges():
    """Drop the ownership mark so a torn-down generation is never re-armed."""
    try:
        _sl_ns_anchor_store().pop(_SL_BRIDGE_OWNER_KEY, None)
    except Exception:
        pass


def ensure_driver_namespace_bridges():
    """Re-arm after a file load replaced driver_namespace.

    Called by ``runtime._ms_rearm_driver_namespace_after_load`` from the suite's
    existing persistent ``load_post`` handler.  Restores ownership and then
    re-applies the live runtime state this module already decided on, so the
    overlay/depsgraph handlers match _RUNTIME_ENABLED again.  A no-op while this
    module is not the registered owner.  Never raises.
    """
    try:
        if _sl_ns_anchor_store().get(_SL_BRIDGE_OWNER_KEY) != __name__:
            return False
        if not _sl_publish_bridges():
            return False
        try:
            set_runtime_enabled(_RUNTIME_ENABLED)
        except Exception:
            pass
        return True
    except Exception:
        return False


def set_runtime_enabled(enabled: bool):
    global _RUNTIME_ENABLED
    _RUNTIME_ENABLED = bool(enabled)
    try:
        dn = bpy.app.driver_namespace
        dn["_SL_RUNTIME_ENABLED_V1"] = _RUNTIME_ENABLED
    except Exception:
        dn = {}
    if dn.get("_SL_ACTIVE_MODULE") != __name__:
        if not _RUNTIME_ENABLED:
            _sl_unregister_runtime_handlers()
        return
    if _RUNTIME_ENABLED:
        _sl_register_runtime_handlers()
    else:
        _sl_unregister_runtime_handlers()


def _expand_translation_contexts(translation_dict):
    """Mirror translations between default and operator contexts if missing."""
    try:
        from bpy.app.translations import contexts as i18n_contexts
    except Exception:
        return translation_dict

    ctx_default = i18n_contexts.default
    ctx_operator = i18n_contexts.operator_default

    expanded = {}
    for lang, table in (translation_dict or {}).items():
        if not isinstance(table, dict):
            continue
        new_table = dict(table)
        for key, value in list(table.items()):
            if not (isinstance(key, tuple) and len(key) == 2 and isinstance(key[1], str)):
                continue
            ctx, msgid = key
            if ctx == ctx_default and (ctx_operator, msgid) not in new_table:
                new_table[(ctx_operator, msgid)] = value
            elif ctx == ctx_operator and (ctx_default, msgid) not in new_table:
                new_table[(ctx_default, msgid)] = value
        expanded[lang] = new_table
    return expanded

def register():
    # Translations
    try:
        bpy.app.translations.register(__name__, _expand_translation_contexts(translation_dict))
    except Exception:
        pass

    dn = bpy.app.driver_namespace
    # Always claim ownership on register so stale driver_namespace values from
    # previous reloads cannot block Smart Lattice's live handlers.  The helper
    # also marks the process-lifetime anchor, which is what lets the load_post
    # re-arm restore this claim after Blender replaces driver_namespace.
    _sl_publish_bridges()
    active = __name__

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass

    # Only one module should own handlers/draw handlers, but plugin registration must happen regardless.
    try:
        sl._sl_ms_register_plugin()
    except Exception:
        pass
    try:
        if not callable(dn.get("_MS_REGISTER_PLUGIN_V1")):
            bpy.app.timers.register(_sl_delayed_register_plugin, first_interval=1.0)
    except Exception:
        pass

    if active == __name__:
        with _feature_toggle.capture_runtime('lattice_modifier', 'Smart Lattice Modifier'):
            set_runtime_enabled(True)


def unregister():
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    dn = bpy.app.driver_namespace

    # Always attempt to unregister plugin entry (safe even if not present)
    try:
        sl._sl_ms_unregister_plugin()
    except Exception:
        pass

    # Dormant-safe: a file load replaces driver_namespace, so the live key alone
    # cannot decide ownership.  The process-lifetime anchor still knows, and this
    # generation must sweep its own draw handler / depsgraph handler / timer
    # rather than release nothing.
    _sl_owned = (dn.get("_SL_ACTIVE_MODULE") == __name__
                 or _sl_ns_anchor_store().get(_SL_BRIDGE_OWNER_KEY) == __name__)
    _sl_release_bridges()
    if _sl_owned:
        global _smo_shader
        set_runtime_enabled(False)
        try:
            _smo_shader = None
        except Exception:
            pass

        try:
            dn.pop("_SL_ACTIVE_MODULE", None)
        except Exception:
            pass
        try:
            dn.pop("_SL_RUNTIME_ENABLED_V1", None)
        except Exception:
            pass

    try:
        sl.cleanup_modifier_system_collections()
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Embedded API (Smart Modifier bundled subtool)
# -----------------------------------------------------------------------------


def register_embedded():
    """Register Smart Lattice bundled subtool.

    Embedded mode:
        - No add-on preference UI (Smart Modifier manages enable/disable).
        - No standalone N-panel (avoid extra UI tabs).
        - Registers as a Smart Modifier plugin (Add Modifier menu / extra UI).
        - Overlay & depsgraph handler are shared via driver_namespace keys.
    """

    # i18n
    try:
        bpy.app.translations.register(__name__, _expand_translation_contexts(translation_dict))
    except Exception:
        pass

    dn = bpy.app.driver_namespace
    # Always claim ownership on register so stale driver_namespace values from
    # previous reloads cannot block Smart Lattice's live handlers.  The helper
    # also marks the process-lifetime anchor, which is what lets the load_post
    # re-arm restore this claim after Blender replaces driver_namespace.
    _sl_publish_bridges()
    active = __name__

    # Classes (no add-on preference UI / no standalone panel)
    for cls in classes_embedded:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass

    # Register plugin with Smart Modifier
    try:
        sl._sl_ms_register_plugin()
    except Exception:
        pass
    try:
        if not callable(dn.get("_MS_REGISTER_PLUGIN_V1")):
            bpy.app.timers.register(_sl_delayed_register_plugin, first_interval=0.2, persistent=True)
    except Exception:
        pass

    # Keep bundled Smart Lattice dormant until the user actually starts using it.
    # The runtime is armed on demand by Smart Modifier operators when needed.
    if active == __name__:
        set_runtime_enabled(False)

    try:
        sl.modsys_request_cleanup(delay=0.0)
    except Exception:
        pass


def unregister_embedded():
    """Unregister Smart Lattice bundled subtool."""

    dn = bpy.app.driver_namespace

    # Remove plugin from Smart Modifier
    try:
        sl._sl_ms_unregister_plugin()
    except Exception:
        pass

    # Unregister delayed plugin timer
    try:
        if bpy.app.timers.is_registered(_sl_delayed_register_plugin):
            bpy.app.timers.unregister(_sl_delayed_register_plugin)
    except Exception:
        pass

    # Shared draw/handlers only if we are the owner
    # Dormant-safe: see unregister().  Ownership survives the file load in the
    # anchor even when driver_namespace no longer carries the claim.
    _sl_owned = (dn.get("_SL_ACTIVE_MODULE") == __name__
                 or _sl_ns_anchor_store().get(_SL_BRIDGE_OWNER_KEY) == __name__)
    _sl_release_bridges()
    if _sl_owned:
        set_runtime_enabled(False)
        for k in ("_SL_ACTIVE_MODULE", "_SL_DRAW_HANDLER", "_SL_DEPSGRAPH_UPDATE", "_SL_CLEANUP_TIMER", "_SL_RUNTIME_ENABLED_V1"):
            try:
                dn.pop(k, None)
            except Exception:
                pass

    try:
        sl.cleanup_modifier_system_collections()
    except Exception:
        pass

    for cls in reversed(classes_embedded):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    # i18n
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
