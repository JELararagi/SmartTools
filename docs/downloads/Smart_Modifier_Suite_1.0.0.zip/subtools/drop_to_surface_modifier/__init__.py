# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for drop_to_surface_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "drop_to_surface_modifier"
PLUGIN_LABEL = "Drop To Surface Modifier"
OPERATOR_ID = "smsa.drop_to_surface"
PLUGIN_ICON = "SNAP_FACE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
