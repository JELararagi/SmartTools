# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for stack_selected_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "stack_selected_modifier"
PLUGIN_LABEL = "Stack Selected Modifier"
OPERATOR_ID = "smsp.stack_selected"
PLUGIN_ICON = "ALIGN_JUSTIFY"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
