# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for rebuild_curve_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "rebuild_curve_modifier"
PLUGIN_LABEL = "Rebuild Curve Modifier"
OPERATOR_ID = "smsp.rebuild_active_curve"
PLUGIN_ICON = "CURVE_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
