# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="array_along_curve_modifier"
PLUGIN_LABEL ='Array Along Curve Modifier'
OPERATOR_ID ="sms.smart_array_along_curve"
PLUGIN_ICON ="MOD_ARRAY"

def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )

def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
