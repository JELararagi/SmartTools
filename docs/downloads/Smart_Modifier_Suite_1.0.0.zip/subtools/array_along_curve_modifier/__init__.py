# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for array_along_curve_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "array_along_curve_modifier"
PLUGIN_LABEL = "Array Along Curve Modifier"
OPERATOR_ID = "sms.smart_array_along_curve"
PLUGIN_ICON = "MOD_ARRAY"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
