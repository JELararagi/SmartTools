# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Public names for the built-in modifier extensions."""

_MODIFIERS = (
    "boolean_stack fill straighten circle curve path vertices_path pipe "
    "array_along_curve instances_along_path loft sweep profile_primitive helix_path "
    "projection project_to_active_plane workplane cad_intersect axis_slice rebuild_curve "
    "audit_selected audit_select_issues face_component_array floor scatter replace randomize "
    "align_to_active distribute_selected stack_selected drop_to_floor quad_checker "
    "pivot_to_selection pivot_to_bottom solo_selected extrude slice_panel surface_box_detail "
    "drop_to_surface detach_separate_clean combine_join_clean reset_xform unwrap_uvw uvw_map"
)
__all__ = [f"{name}_modifier" for name in _MODIFIERS.split()]
__all__ += ["max_modifier_library", "edit_poly_modifier", "lattice_modifier"]
