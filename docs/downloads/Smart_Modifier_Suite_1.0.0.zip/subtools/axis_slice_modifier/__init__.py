# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for axis_slice_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "axis_slice_modifier"
PLUGIN_LABEL = "Axis Slice Modifier"
OPERATOR_ID = "smsp.axis_slice_edit"
PLUGIN_ICON = "MOD_MULTIRES"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
