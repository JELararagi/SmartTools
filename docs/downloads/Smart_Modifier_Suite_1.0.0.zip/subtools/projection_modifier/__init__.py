# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for projection_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "projection_modifier"
PLUGIN_LABEL = "Projection Modifier"
OPERATOR_ID = "smsp.project_to_selected_surface"
PLUGIN_ICON = "SNAP_FACE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
