# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="projection_modifier"
PLUGIN_LABEL ='Projection Modifier'
OPERATOR_ID ="smsp.project_to_selected_surface"
PLUGIN_ICON ="SNAP_FACE"

def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )

def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
