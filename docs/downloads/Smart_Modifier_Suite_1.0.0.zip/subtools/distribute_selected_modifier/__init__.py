# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for distribute_selected_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "distribute_selected_modifier"
PLUGIN_LABEL = "Distribute Selected Modifier"
OPERATOR_ID = "smsp.distribute_selected_axis"
PLUGIN_ICON = "MOD_ARRAY"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
