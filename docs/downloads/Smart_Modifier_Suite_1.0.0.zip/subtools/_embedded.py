# SPDX-License-Identifier: GPL-3.0-or-later
"""Bind an embedded modifier entry to the suite's registration service."""

from functools import partial


def embedded_entry(plugin_id, label, operator_id, icon):
    from .. import user_plugins

    def install():
        user_plugins.register_simple_plugin(plugin_id, label, operator_id, icon)

    return install, partial(user_plugins.unregister_simple_plugin, plugin_id)
