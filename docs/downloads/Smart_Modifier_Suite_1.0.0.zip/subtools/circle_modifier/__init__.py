# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for circle_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "circle_modifier"
PLUGIN_LABEL = "Circle Modifier"
OPERATOR_ID = "sms.circle_selection"
PLUGIN_ICON = "MESH_CIRCLE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
