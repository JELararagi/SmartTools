# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for project_to_active_plane_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "project_to_active_plane_modifier"
PLUGIN_LABEL = "Project To Active Plane Modifier"
OPERATOR_ID = "smsp.project_to_active_plane"
PLUGIN_ICON = "EMPTY_ARROWS"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
