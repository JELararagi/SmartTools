# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="project_to_active_plane_modifier"
PLUGIN_LABEL ='Project To Active Plane Modifier'
OPERATOR_ID ="smsp.project_to_active_plane"
PLUGIN_ICON ="EMPTY_ARROWS"


def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )


def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
