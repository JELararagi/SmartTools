# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for sweep_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "sweep_modifier"
PLUGIN_LABEL = "Sweep Modifier"
OPERATOR_ID = "smsp.sweep_active_profile"
PLUGIN_ICON = "MOD_CURVE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
