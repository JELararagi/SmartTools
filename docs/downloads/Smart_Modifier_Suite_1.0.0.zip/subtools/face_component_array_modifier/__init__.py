# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for face_component_array_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "face_component_array_modifier"
PLUGIN_LABEL = "Face Component Array Modifier"
OPERATOR_ID = "smsp.face_component_array"
PLUGIN_ICON = "DUPLICATE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
