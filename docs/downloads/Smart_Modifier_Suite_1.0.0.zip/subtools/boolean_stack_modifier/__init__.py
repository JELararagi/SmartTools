# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for boolean_stack_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "boolean_stack_modifier"
PLUGIN_LABEL = "Boolean Stack Modifier"
OPERATOR_ID = "sms.smart_boolean_stack"
PLUGIN_ICON = "MOD_BOOLEAN"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
