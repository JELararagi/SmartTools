# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================
from __future__ import annotations

import json
import bpy
from ..translation import choose_text
from ..core import (
    get_main_object, ms_get_selected_main_meshes, ms_next_logical_name_from_base,
    ms_obj_set_disp_name, ms_set_ui_active_index, safe_move_modifier,
    ms_calc_target_insert_index,
    set_mod_enabled_state, set_mod_viewport_state, ms_apply_state_post_action,
    ms_group_modifiers_as_instance, ms_is_instance_modifier, ms_get_instance_id,
    ms_iter_instance_members, ms_next_logical_default_name_across_objects,
)

MAX_BACKUP_LOOPS = 50000


def unique_name(base, existing):
    used = {str(getattr(x, 'name', '') or '') for x in (existing or [])}
    base = str(base or 'SMS UV Modifier').strip() or 'SMS UV Modifier'
    if base not in used:
        return base
    for i in range(1, 10000):
        n = f'{base}.{i:03d}'
        if n not in used:
            return n
    return base


def selected_mesh_targets(context):
    try:
        items = list(ms_get_selected_main_meshes(context) or [])
    except Exception:
        items = []
    if not items:
        try:
            obj = get_main_object(getattr(context, 'active_object', None))
        except Exception:
            obj = getattr(context, 'active_object', None)
        if obj is not None:
            items = [obj]
    out, seen = [], set()
    for obj in items:
        name = str(getattr(obj, 'name', '') or '')
        if obj is not None and name and name not in seen and getattr(obj, 'type', '') == 'MESH' and hasattr(obj, 'modifiers'):
            seen.add(name); out.append(obj)
    return out


def capture_selection(context):
    try:
        vl = context.view_layer
        selected = [o.name for o in vl.objects if o.select_get()]
        active = vl.objects.active.name if vl.objects.active else ''
        return selected, active
    except Exception:
        return [], ''


def restore_selection(context, selected_names, active_name):
    try:
        vl = context.view_layer
        s = set(selected_names or [])
        for obj in vl.objects:
            try: obj.select_set(obj.name in s)
            except Exception: pass
        active = bpy.data.objects.get(active_name) if active_name else None
        if active is not None:
            vl.objects.active = active
    except Exception:
        pass


def ensure_object_mode(context):
    mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
    if mode != 'OBJECT':
        try: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        except Exception: pass
    return mode


def restore_mode(context, mode, active_name=''):
    if not str(mode or '').startswith('EDIT'):
        return
    try:
        obj = bpy.data.objects.get(active_name) if active_name else getattr(context, 'active_object', None)
        if obj is not None:
            context.view_layer.objects.active = obj; obj.select_set(True)
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
    except Exception:
        pass


def socket_by_name(sockets, names=(), index=0):
    names = tuple(str(n or '') for n in (names or ()) if str(n or ''))
    for n in names:
        try:
            s = sockets.get(n)
            if s is not None: return s
        except Exception: pass
    try:
        for s in sockets:
            if str(getattr(s, 'name', '') or '') in names: return s
    except Exception: pass
    try: return sockets[int(index)]
    except Exception: return None


def add_interface_socket(group, name, in_out, socket_type='NodeSocketGeometry', description=''):
    try:
        s = group.interface.new_socket(name=str(name), in_out=str(in_out), socket_type=str(socket_type))
        if description:
            try: s.description = description
            except Exception: pass
        return s
    except Exception:
        pass
    try:
        col = group.inputs if str(in_out).upper() == 'INPUT' else group.outputs
        s = col.new(str(socket_type), str(name))
        if description:
            try: s.description = description
            except Exception: pass
        return s
    except Exception:
        return None


def make_passthrough_group(name, context=None):
    group = bpy.data.node_groups.new(unique_name(name, bpy.data.node_groups), 'GeometryNodeTree')
    try: group.is_modifier = True
    except Exception: pass
    try: group.nodes.clear()
    except Exception: pass
    add_interface_socket(group, 'Geometry', 'INPUT', 'NodeSocketGeometry', choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
    add_interface_socket(group, 'Geometry', 'OUTPUT', 'NodeSocketGeometry', choose_text('Output geometry.', '出力ジオメトリです。', context=context))
    try:
        gi = group.nodes.new('NodeGroupInput'); gi.location = (-240, 0)
        go = group.nodes.new('NodeGroupOutput'); go.location = (120, 0); go.is_active_output = True
        group.links.new(socket_by_name(gi.outputs, ('Geometry',), 0), socket_by_name(go.inputs, ('Geometry',), 0))
    except Exception:
        pass
    return group


def new_marker_modifier(obj, plugin_id, marker_key, label, group_prefix, context=None, insert_idx=None):
    name = ms_next_logical_name_from_base(obj, label)
    group = make_passthrough_group(f'{group_prefix} - {getattr(obj, "name", "Object")}', context=context)
    mod = obj.modifiers.new(name=name, type='NODES')
    try: mod.node_group = group
    except Exception: pass
    try: mod.show_expanded = True
    except Exception: pass
    try:
        mod[marker_key] = True; mod['smsm_plugin_id'] = str(plugin_id)
    except Exception: pass
    try:
        if insert_idx is not None:
            try: target_index = max(0, int(insert_idx))
            except Exception: target_index = None
        else:
            target_index = None
        if target_index is None:
            try:
                master = get_main_object(getattr(context, 'active_object', None)) if context is not None else obj
            except Exception:
                master = obj
            target_index = ms_calc_target_insert_index(master or obj, obj, context)
        safe_move_modifier(obj, mod.name, target_index)
    except Exception: pass
    try:
        ms_obj_set_disp_name(obj, mod.name, name)
        set_mod_enabled_state(obj, mod.name, True); set_mod_viewport_state(obj, mod.name, True)
        obj['ui_active_item'] = mod.name; obj['ui_active_row'] = obj.modifiers.find(mod.name)
        ms_set_ui_active_index(obj, obj.modifiers.find(mod.name)); obj.modifiers.active = mod
    except Exception: pass
    return mod


def finalize(context, obj):
    try: ms_apply_state_post_action(context, obj, interactive_default=False)
    except Exception: pass
    try: obj.update_tag()
    except Exception: pass


def ensure_uv_layer(mesh, name):
    if mesh is None or not hasattr(mesh, 'uv_layers'):
        return None
    name = str(name or 'UVMap').strip() or 'UVMap'
    try: uv = mesh.uv_layers.get(name)
    except Exception: uv = None
    if uv is None:
        try: uv = mesh.uv_layers.new(name=name)
        except Exception:
            try: uv = mesh.uv_layers.new(); uv.name = name
            except Exception: return None
    try: mesh.uv_layers.active = uv
    except Exception: pass
    try: mesh.uv_layers.active_render = uv
    except Exception: pass
    return uv


def make_uv_backup(mesh, name):
    uv_name = str(name or 'UVMap')
    try: uv = mesh.uv_layers.get(uv_name)
    except Exception: uv = None
    if uv is None:
        try:
            return json.dumps({'uv_map': uv_name, 'missing': True}, separators=(',', ':'))
        except Exception:
            return ''
    try: count = len(uv.data)
    except Exception: count = 0
    if count <= 0 or count > MAX_BACKUP_LOOPS: return ''
    try:
        vals = [[float(x.uv[0]), float(x.uv[1])] for x in uv.data]
        return json.dumps({'uv_map': uv.name, 'count': count, 'values': vals}, separators=(',', ':'))
    except Exception:
        return ''


def restore_uv_backup(obj, data):
    try: payload = json.loads(str(data or ''))
    except Exception: return False
    mesh = getattr(obj, 'data', None)
    uv_name = payload.get('uv_map') or 'UVMap'
    if payload.get('missing'):
        try:
            uv = mesh.uv_layers.get(str(uv_name))
            if uv is not None:
                mesh.uv_layers.remove(uv)
            try: mesh.update()
            except Exception: pass
            return True
        except Exception:
            return False
    uv = ensure_uv_layer(mesh, uv_name)
    vals = payload.get('values') or []
    if uv is None or len(vals) != len(uv.data): return False
    try:
        for item, val in zip(uv.data, vals): item.uv = (float(val[0]), float(val[1]))
        mesh.update(); return True
    except Exception:
        return False


def draw_kv(layout, label, value):
    try:
        row = layout.row(align=True); row.label(text=str(label)); row.label(text=str(value))
    except Exception: pass


def set_props(mod, prefix, settings):
    for k, v in (settings or {}).items():
        try: mod[f'{prefix}{k}'] = list(v) if isinstance(v, tuple) else v
        except Exception: pass


def get_prop(mod, prefix, key, default=None):
    try: return mod.get(f'{prefix}{key}', default)
    except Exception: return default


def draw_idprop(layout, mod, prefix, key, label, *, text_only=False):
    try:
        prop_key = f'{prefix}{key}'
        if mod is None or prop_key not in mod:
            return False
        if text_only:
            draw_kv(layout, label, mod.get(prop_key))
        else:
            layout.prop(mod, f'["{prop_key}"]', text=str(label))
        return True
    except Exception:
        try:
            draw_kv(layout, label, get_prop(mod, prefix, key, ''))
            return True
        except Exception:
            return False
