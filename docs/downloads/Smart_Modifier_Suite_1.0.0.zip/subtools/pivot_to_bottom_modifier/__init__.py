# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for pivot_to_bottom_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "pivot_to_bottom_modifier"
PLUGIN_LABEL = "Pivot To Bottom Modifier"
OPERATOR_ID = "smsp.pivot_to_bottom"
PLUGIN_ICON = "TRIA_DOWN"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
