# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for cad_intersect_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "cad_intersect_modifier"
PLUGIN_LABEL = "CAD Intersect Modifier"
OPERATOR_ID = "smsp.cad_intersect_extend"
PLUGIN_ICON = "MESH_GRID"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
