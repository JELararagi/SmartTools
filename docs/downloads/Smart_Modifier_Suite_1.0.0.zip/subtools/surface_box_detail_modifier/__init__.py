# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for surface_box_detail_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "surface_box_detail_modifier"
PLUGIN_LABEL = "Surface Box Detail Modifier"
OPERATOR_ID = "smsa.surface_box_detail"
PLUGIN_ICON = "MESH_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
