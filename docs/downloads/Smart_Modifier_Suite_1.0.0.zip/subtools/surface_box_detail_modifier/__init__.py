# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="surface_box_detail_modifier"
PLUGIN_LABEL ='Surface Box Detail Modifier'
OPERATOR_ID ="smsa.surface_box_detail"
PLUGIN_ICON ="MESH_DATA"

def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )

def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
