# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for combine_join_clean_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "combine_join_clean_modifier"
PLUGIN_LABEL = "Combine Join Clean Modifier"
OPERATOR_ID = "smsa.combine_join_clean"
PLUGIN_ICON = "MESH_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
