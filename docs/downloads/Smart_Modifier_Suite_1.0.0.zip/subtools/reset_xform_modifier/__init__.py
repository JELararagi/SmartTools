# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from __future__ import annotations

import json

import bpy
from bpy.types import Operator
from mathutils import Matrix, Euler

from ...translation import choose_text

try:
    from ...icons import icon_value as _sms_icon_value, operator as _sms_icon_operator
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='NONE', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)

def _sms_label(layout, text='', icon_name='modifier', fallback_icon='MODIFIER'):
    try:
        iv = _sms_icon_value(icon_name, fallback_icon)
        if iv:
            layout.label(text=text, icon_value=iv)
            return
    except Exception:
        pass
    try:
        layout.label(text=text, icon=fallback_icon)
    except Exception:
        layout.label(text=text)

try:
    from ...help_button import draw_help_header
except Exception:
    def draw_help_header(layout, context, label, icon, help_id, **kwargs):
        try:
            _sms_label(layout, text=choose_text(label, label, context=context), icon_name=str(icon or 'modifier'), fallback_icon='MODIFIER')
        except Exception:
            try:
                layout.label(text=choose_text(label, label, context=context))
            except Exception:
                pass

from ...core import (
    get_main_object,
    ms_apply_state_post_action,
    ms_get_selected_main_meshes,
    ms_next_logical_name_from_base,
    ms_obj_set_disp_name,
    ms_register_plugin,
    ms_group_modifiers_as_instance,
    ms_calc_target_insert_index,
    ms_set_ui_active_index,
    ms_unregister_plugin,
    safe_move_modifier,
    set_mod_enabled_state,
    set_mod_viewport_state,
)

_PLUGIN_ID = "reset_xform_modifier"
_OPERATOR_ID = "smsm.reset_xform_modifier"
_PLUGIN_LABEL = "Reset XForm"
_PLUGIN_ICON = "MOD_NODES"
_RESET_MARKER = "_smsm_reset_xform_modifier"
_RESET_MATRIX_KEY = "_smsm_reset_xform_matrix_basis"


def _unique_name(base: str, existing) -> str:
    used = {str(getattr(item, "name", "") or "") for item in (existing or [])}
    base = str(base or _PLUGIN_LABEL).strip() or _PLUGIN_LABEL
    if base not in used:
        return base
    for i in range(1, 10000):
        candidate = f"{base}.{i:03d}"
        if candidate not in used:
            return candidate
    return base


def _socket_by_name(sockets, names, fallback_index: int = 0):
    names = tuple(str(n or "") for n in (names or ()) if str(n or ""))
    for name in names:
        try:
            socket = sockets.get(name)
            if socket is not None:
                return socket
        except Exception:
            pass
    try:
        for socket in sockets:
            if str(getattr(socket, "name", "") or "") in names:
                return socket
    except Exception:
        pass
    try:
        return sockets[int(fallback_index)]
    except Exception:
        return None


def _socket_idname(sockets, names, fallback: str) -> str:
    socket = _socket_by_name(sockets, names, 0)
    try:
        value = str(getattr(socket, "bl_socket_idname", "") or "")
        if value:
            return value
    except Exception:
        pass
    return str(fallback or "NodeSocketFloat")


def _set_default_value(socket, value) -> bool:
    if socket is None:
        return False
    candidates = [value]
    try:
        if isinstance(value, Euler):
            candidates.append(tuple(float(v) for v in value))
        elif isinstance(value, (tuple, list)) and len(value) == 3:
            candidates.append(Euler((float(value[0]), float(value[1]), float(value[2])), 'XYZ'))
            candidates.append([float(value[0]), float(value[1]), float(value[2])])
    except Exception:
        pass
    for candidate in candidates:
        try:
            socket.default_value = candidate
            return True
        except Exception:
            continue
    return False


def _add_interface_socket(group, *, name: str, in_out: str, socket_type: str, default=None, description: str = ""):
    socket = None
    try:
        socket = group.interface.new_socket(
            name=str(name),
            in_out=str(in_out),
            socket_type=str(socket_type),
        )
        if description:
            try:
                socket.description = str(description)
            except Exception:
                pass
        if default is not None:
            _set_default_value(socket, default)
        return socket
    except Exception:
        socket = None

    try:
        collection = group.inputs if str(in_out).upper() == 'INPUT' else group.outputs
        socket = collection.new(str(socket_type), str(name))
        if description:
            try:
                socket.description = str(description)
            except Exception:
                pass
        if default is not None:
            _set_default_value(socket, default)
        return socket
    except Exception:
        return None


def _link_sockets(links, from_socket, to_socket) -> bool:
    if from_socket is None or to_socket is None:
        return False
    try:
        links.new(from_socket, to_socket)
        return True
    except Exception:
        return False


def _modifier_input_set(mod, socket, value):
    if mod is None or socket is None:
        return
    keys = []
    for attr in ("identifier", "name"):
        try:
            key = str(getattr(socket, attr, "") or "")
            if key and key not in keys:
                keys.append(key)
        except Exception:
            pass
    for key in keys:
        try:
            mod[key] = value
        except Exception:
            try:
                if isinstance(value, (tuple, list)):
                    mod[key] = list(value)
            except Exception:
                pass


def _make_reset_xform_node_group(obj, *, rotation_euler, scale_values, context=None):
    group_name = _unique_name(f"SMS Reset XForm - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    group = bpy.data.node_groups.new(group_name, 'GeometryNodeTree')
    try:
        group.is_modifier = True
    except Exception:
        pass

    nodes = group.nodes
    links = group.links
    try:
        nodes.clear()
    except Exception:
        pass

    transform = nodes.new('GeometryNodeTransform')
    transform.location = (0.0, 0.0)

    geometry_socket_type = _socket_idname(transform.inputs, ('Geometry',), 'NodeSocketGeometry')
    translation_socket_type = _socket_idname(transform.inputs, ('Translation',), 'NodeSocketVector')
    rotation_socket_type = _socket_idname(transform.inputs, ('Rotation',), 'NodeSocketVector')
    scale_socket_type = _socket_idname(transform.inputs, ('Scale',), 'NodeSocketVector')
    geometry_out_socket_type = _socket_idname(transform.outputs, ('Geometry',), 'NodeSocketGeometry')

    translation_name = choose_text('Translation', '移動', context=context)
    rotation_name = choose_text('Rotation', '回転', context=context)
    scale_name = choose_text('Scale', 'スケール', context=context)

    geometry_in = _add_interface_socket(
        group,
        name='Geometry',
        in_out='INPUT',
        socket_type=geometry_socket_type,
        description=choose_text(
            'Incoming geometry before the Reset XForm transform is applied.',
            'Reset XForm の変換を適用する前の入力ジオメトリです。',
            context=context,
        ),
    )
    translation_in = _add_interface_socket(
        group,
        name=translation_name,
        in_out='INPUT',
        socket_type=translation_socket_type,
        default=(0.0, 0.0, 0.0),
        description=choose_text(
            'Additional XForm move offset. Reset XForm itself keeps object position, so this starts at zero.',
            '追加の XForm 移動量です。Reset XForm 自体はオブジェクト位置を保持するため、初期値は 0 です。',
            context=context,
        ),
    )
    rotation_in = _add_interface_socket(
        group,
        name=rotation_name,
        in_out='INPUT',
        socket_type=rotation_socket_type,
        default=rotation_euler,
        description=choose_text(
            'Rotation pushed from the object transform into this modifier, matching 3ds Max Reset XForm behavior.',
            '3ds Max の Reset XForm と同様に、オブジェクト変換からこのモディファイアへ移された回転です。',
            context=context,
        ),
    )
    scale_in = _add_interface_socket(
        group,
        name=scale_name,
        in_out='INPUT',
        socket_type=scale_socket_type,
        default=scale_values,
        description=choose_text(
            'Scale pushed from the object transform into this modifier. The object scale is reset to 1.',
            'オブジェクト変換からこのモディファイアへ移されたスケールです。オブジェクト側のスケールは 1 に戻ります。',
            context=context,
        ),
    )
    _add_interface_socket(
        group,
        name='Geometry',
        in_out='OUTPUT',
        socket_type=geometry_out_socket_type,
        description=choose_text(
            'Geometry after the Reset XForm transform.',
            'Reset XForm の変換後のジオメトリです。',
            context=context,
        ),
    )

    group_input = nodes.new('NodeGroupInput')
    group_input.location = (-420.0, 0.0)
    transform.location = (-90.0, 0.0)
    group_output = nodes.new('NodeGroupOutput')
    group_output.location = (230.0, 0.0)
    try:
        group_output.is_active_output = True
    except Exception:
        pass

    _link_sockets(
        links,
        _socket_by_name(group_input.outputs, ('Geometry',), 0),
        _socket_by_name(transform.inputs, ('Geometry',), 0),
    )
    _link_sockets(
        links,
        _socket_by_name(group_input.outputs, (translation_name, 'Translation'), 1),
        _socket_by_name(transform.inputs, ('Translation',), 1),
    )
    _link_sockets(
        links,
        _socket_by_name(group_input.outputs, (rotation_name, 'Rotation'), 2),
        _socket_by_name(transform.inputs, ('Rotation',), 2),
    )
    _link_sockets(
        links,
        _socket_by_name(group_input.outputs, (scale_name, 'Scale'), 3),
        _socket_by_name(transform.inputs, ('Scale',), 3),
    )
    _link_sockets(
        links,
        _socket_by_name(transform.outputs, ('Geometry',), 0),
        _socket_by_name(group_output.inputs, ('Geometry',), 0),
    )

    # Direct defaults are kept as a fallback for Blender builds where a socket
    # type cannot be exposed through the modifier interface but the node itself
    # still accepts the value.
    _set_default_value(_socket_by_name(transform.inputs, ('Translation',), 1), (0.0, 0.0, 0.0))
    _set_default_value(_socket_by_name(transform.inputs, ('Rotation',), 2), rotation_euler)
    _set_default_value(_socket_by_name(transform.inputs, ('Scale',), 3), scale_values)

    return group, {
        'translation': translation_in,
        'rotation': rotation_in,
        'scale': scale_in,
    }


def _selected_targets(context):
    targets = []
    try:
        targets = list(ms_get_selected_main_meshes(context) or [])
    except Exception:
        targets = []
    if not targets:
        try:
            obj = get_main_object(getattr(context, 'active_object', None))
        except Exception:
            obj = getattr(context, 'active_object', None)
        if obj is not None:
            targets = [obj]
    out = []
    seen = set()
    for obj in targets:
        if obj is None:
            continue
        if getattr(obj, 'type', '') != 'MESH':
            continue
        if not hasattr(obj, 'modifiers'):
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        out.append(obj)
    return out


def _capture_selection(context):
    try:
        vl = context.view_layer
    except Exception:
        vl = None
    selected = []
    active = ''
    if vl is not None:
        try:
            selected = [obj.name for obj in vl.objects if obj.select_get()]
        except Exception:
            selected = []
        try:
            active = vl.objects.active.name if vl.objects.active else ''
        except Exception:
            active = ''
    return selected, active


def _restore_selection(context, selected_names, active_name):
    try:
        vl = context.view_layer
    except Exception:
        return
    try:
        for obj in vl.objects:
            try:
                obj.select_set(obj.name in selected_names)
            except Exception:
                pass
    except Exception:
        pass
    try:
        active = bpy.data.objects.get(active_name)
        if active is not None:
            vl.objects.active = active
    except Exception:
        pass


def _restore_children_world(children_world):
    for child, matrix in children_world:
        try:
            if child and matrix:
                child.matrix_world = matrix
        except Exception:
            pass


def _reset_single_object(obj, context=None, insert_idx=None):
    old_basis = obj.matrix_basis.copy()
    try:
        loc, rot, scale = old_basis.decompose()
    except Exception:
        loc = old_basis.to_translation()
        rot = old_basis.to_quaternion()
        scale = (1.0, 1.0, 1.0)
    rotation_euler = rot.to_euler('XYZ')
    scale_values = (float(scale[0]), float(scale[1]), float(scale[2]))

    logical_name = ms_next_logical_name_from_base(obj, _PLUGIN_LABEL)
    node_group, sockets = _make_reset_xform_node_group(
        obj,
        rotation_euler=rotation_euler,
        scale_values=scale_values,
        context=context,
    )

    mod = obj.modifiers.new(name=logical_name, type='NODES')
    mod.node_group = node_group
    try:
        mod.show_expanded = True
    except Exception:
        pass
    try:
        mod[_RESET_MARKER] = True
        mod[_RESET_MATRIX_KEY] = json.dumps([[float(old_basis[row][col]) for col in range(4)] for row in range(4)])
        mod['smsm_plugin_id'] = _PLUGIN_ID
    except Exception:
        pass

    try:
        _modifier_input_set(mod, sockets.get('translation'), (0.0, 0.0, 0.0))
        _modifier_input_set(mod, sockets.get('rotation'), tuple(float(v) for v in rotation_euler))
        _modifier_input_set(mod, sockets.get('scale'), scale_values)
    except Exception:
        pass

    try:
        target_idx = insert_idx
        if target_idx is None:
            try:
                master = get_main_object(getattr(context, 'active_object', None)) if context is not None else obj
            except Exception:
                master = obj
            target_idx = ms_calc_target_insert_index(master or obj, obj, context)
        safe_move_modifier(obj, mod.name, target_idx)
    except Exception:
        pass

    children_world = []
    try:
        children_world = [(child, child.matrix_world.copy()) for child in getattr(obj, 'children', [])]
    except Exception:
        children_world = []

    try:
        # old_basis already transferred delta rotation/scale into the modifier.
        # Blender's matrix_basis setter otherwise compensates surviving deltas
        # in the primary channels instead of leaving rotation/scale reset.
        obj.delta_rotation_euler = (0.0, 0.0, 0.0)
        obj.delta_rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        obj.delta_scale = (1.0, 1.0, 1.0)
        obj.matrix_basis = Matrix.Translation(loc)
    except Exception:
        try:
            obj.location = loc
            if getattr(obj, 'rotation_mode', 'XYZ') == 'QUATERNION':
                obj.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
            elif getattr(obj, 'rotation_mode', 'XYZ') == 'AXIS_ANGLE':
                obj.rotation_axis_angle = (0.0, 0.0, 0.0, 1.0)
            else:
                obj.rotation_euler = (0.0, 0.0, 0.0)
            obj.scale = (1.0, 1.0, 1.0)
        except Exception:
            pass

    # Child matrix_world assignment resolves local channels against the parent's
    # evaluated world matrix. Flush the reset basis before restoring children;
    # otherwise Blender uses the parent's pre-reset matrix and loses the restore
    # on the next dependency-graph evaluation.
    if children_world:
        (context or bpy.context).view_layer.update()
    _restore_children_world(children_world)

    try:
        ms_obj_set_disp_name(obj, mod.name, logical_name)
        set_mod_enabled_state(obj, mod.name, True)
        set_mod_viewport_state(obj, mod.name, True)
        obj['ui_active_item'] = mod.name
        obj['ui_active_row'] = obj.modifiers.find(mod.name)
        ms_set_ui_active_index(obj, obj.modifiers.find(mod.name))
        obj.modifiers.active = mod
    except Exception:
        pass

    try:
        obj.update_tag()
    except Exception:
        pass
    return mod


class SMSM_OT_reset_xform_modifier(Operator):
    bl_idname = _OPERATOR_ID
    bl_label = _PLUGIN_LABEL
    bl_description = 'Reset object rotation and scale into a stack modifier.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            return bool(_selected_targets(context))
        except Exception:
            return False

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Add a Reset XForm modifier to the selected mesh object(s). The current object rotation and scale are moved into a generated Geometry Nodes XForm modifier, then the object rotation is reset to 0 and scale to 1 while preserving the visible shape. Delete the modifier to remove that pushed transform, or apply it to bake the transform into the mesh.',
            '選択メッシュに Reset XForm モディファイアを追加します。現在のオブジェクト回転とスケールを生成済み Geometry Nodes XForm モディファイアへ移し、見た目を維持したままオブジェクト側の回転を 0、スケールを 1 に戻します。モディファイアを削除すると移した変換を取り除け、適用するとメッシュへベイクできます。',
            context=context,
        )

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        targets = _selected_targets(context)
        if not targets:
            self.report({'ERROR'}, choose_text('Select one or more mesh objects.', 'メッシュオブジェクトを1つ以上選択してください。', context=context))
            return {'CANCELLED'}

        selected_names, active_name = _capture_selection(context)
        initial_mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        edit_object_name = ''
        try:
            edit_obj = getattr(context, 'edit_object', None)
            edit_object_name = edit_obj.name if edit_obj else ''
        except Exception:
            edit_object_name = ''

        if initial_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
            except Exception:
                pass

        made = []
        failed = []
        pairs = []
        try:
            active_main_for_insert = get_main_object(getattr(context, 'active_object', None))
        except Exception:
            active_main_for_insert = targets[0] if targets else None
        if active_main_for_insert not in targets:
            active_main_for_insert = targets[0] if targets else active_main_for_insert

        for obj in targets:
            try:
                try:
                    insert_idx = ms_calc_target_insert_index(active_main_for_insert or obj, obj, context)
                except Exception:
                    insert_idx = None
                mod = _reset_single_object(obj, context=context, insert_idx=insert_idx)
                if mod is not None:
                    made.append(obj.name)
                    pairs.append((obj, mod))
            except Exception as exc:
                failed.append((obj.name, exc))

        if len(pairs) > 1:
            try:
                ms_group_modifiers_as_instance(pairs, disp_name=choose_text('Reset XForm', 'Xフォームをリセット', context=context), sync_from_first=False, context=context)
            except Exception:
                pass

        try:
            if made:
                main_obj = bpy.data.objects.get(made[0]) or targets[0]
                ms_apply_state_post_action(context, main_obj, interactive_default=False)
        except Exception:
            pass

        _restore_selection(context, selected_names, active_name)

        if initial_mode.startswith('EDIT') and edit_object_name:
            try:
                edit_obj = bpy.data.objects.get(edit_object_name)
                if edit_obj is not None:
                    context.view_layer.objects.active = edit_obj
                    edit_obj.select_set(True)
                    bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
            except Exception:
                pass

        if failed and not made:
            self.report({'ERROR'}, choose_text(f'Reset XForm failed: {failed[0][1]}', f'Reset XForm に失敗しました: {failed[0][1]}', context=context))
            return {'CANCELLED'}
        if failed:
            self.report({'WARNING'}, choose_text(f'Reset XForm completed with {len(failed)} failed object(s).', f'Reset XForm は完了しましたが、{len(failed)}個のオブジェクトで失敗しました。', context=context))
        else:
            self.report({'INFO'}, choose_text(f'Reset XForm added to {len(made)} object(s).', f'Reset XForm を {len(made)} 個のオブジェクトへ追加しました。', context=context))
        return {'FINISHED'}


def _draw_add_menu(layout, context):
    _sms_icon_operator(layout, _OPERATOR_ID, text=choose_text('Reset XForm', 'Xフォームをリセット', context=context), icon_name='reset_xform', fallback_icon=_PLUGIN_ICON)


def _match_modifier(mod):
    try:
        if bool(mod.get(_RESET_MARKER, False)):
            return True
    except Exception:
        pass
    try:
        return getattr(mod, 'type', '') == 'NODES' and str(getattr(getattr(mod, 'node_group', None), 'name', '') or '').startswith('SMS Reset XForm')
    except Exception:
        return False


def _draw_props(layout, mod, obj=None, context=None):
    if not _match_modifier(mod):
        return False
    box = layout.box()
    draw_help_header(box, context, 'Reset XForm', _PLUGIN_ICON, 'reset_xform_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    labels = {'Translation': ('Translation', '移動'), 'Rotation': ('Rotation', '回転'), 'Scale': ('Scale', 'スケール'), '移動': ('Translation', '移動'), '回転': ('Rotation', '回転'), 'スケール': ('Scale', 'スケール')}
    try:
        for item in mod.node_group.interface.items_tree:
            if str(getattr(item, 'item_type', '')) != 'SOCKET' or str(getattr(item, 'in_out', '')) != 'INPUT':
                continue
            pair = labels.get(str(item.name))
            if pair and str(item.identifier) in mod:
                col.prop(mod, f'["{item.identifier}"]', text=choose_text(pair[0], pair[1], context=context))
    except Exception:
        pass
    return True


def _get_skip_copy_props(mod):
    return {_RESET_MATRIX_KEY, 'node_group'}


_CLASSES = (
    SMSM_OT_reset_xform_modifier,
)


def register_embedded():
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass
    try:
        ms_register_plugin(_PLUGIN_ID, {
            'id': _PLUGIN_ID,
            'label': _PLUGIN_LABEL,
            'operator_id': _OPERATOR_ID,
            'icon': _PLUGIN_ICON,
            'priority': 106,
            'group': 'transform_xform',
            'group_label': 'Transform / XForm',
            'group_icon': 'EMPTY_ARROWS',
            'group_priority': 90,
            'description_en': 'Move the selected object rotation and scale into a generated XForm-style Geometry Nodes modifier, then reset the object rotation to 0 and scale to 1 while preserving the visible result.',
            'description_ja': '選択オブジェクトの回転とスケールを生成済みの XForm 風 Geometry Nodes モディファイアへ移し、見た目を維持したままオブジェクト側の回転を 0、スケールを 1 に戻します。',
            'usage_en': 'Select one or more mesh objects, then run it from Add Modifier > User > Transform / XForm. The generated Reset XForm modifier can be moved, disabled, deleted, or applied like other stack entries.',
            'usage_ja': 'メッシュオブジェクトを1つ以上選択し、モディファイアを追加 > ユーザー > Transform / XForm から実行します。生成された Reset XForm モディファイアは、他のスタック項目と同様に移動・無効化・削除・適用できます。',
            'stack_addable': False,
            'modeling_side': True,
            'draw_add_menu': _draw_add_menu,
            'match_modifier': _match_modifier,
            'draw_modifier_properties_extra': _draw_props,
            'get_skip_copy_props': _get_skip_copy_props,
            'requires_bottom_insert': lambda obj, mod: False,
        })
    except Exception:
        pass


def unregister_embedded():
    try:
        ms_unregister_plugin(_PLUGIN_ID)
    except Exception:
        pass
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    register_embedded()


def unregister():
    unregister_embedded()
