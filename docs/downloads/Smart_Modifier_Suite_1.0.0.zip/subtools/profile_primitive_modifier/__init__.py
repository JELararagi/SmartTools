# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for profile_primitive_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "profile_primitive_modifier"
PLUGIN_LABEL = "Profile Primitive Modifier"
OPERATOR_ID = "smsp.add_profile_primitive"
PLUGIN_ICON = "MESH_CIRCLE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
