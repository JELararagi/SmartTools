# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import sys
import types

import bpy

try:
    from ...translation import choose_text as _sms_choose_text
except Exception:
    def _sms_choose_text(en, ja='', context=None):
        return str(en or ja or '')

from ... import feature_toggle as _feature_toggle
bl_info = {
    "name": "Edit Polygon Modifier",
    "author": "JELararagi",
    "version": (1, 16, 2),
    "blender": (5, 0, 0),
    "location": _sms_choose_text ("Smart Modifier User Menu / View3D > N-Panel (Optional)", "Smart Modifier ユーザーメニュー / 3Dビュー > Nパネル（任意）"),
    "description": _sms_choose_text ("Max-style Edit Polygon layer functionality (integrates with Smart Modifier).", "Smart Modifier と統合する Max 風の編集ポリゴンレイヤー機能です。"),
    "category": "Object",
}

# NOTE:
# This add-on is modularized. Do NOT use `from .ep_core import *` because
# functions starting with '_' are not imported by star-import, and Smart Modifier
# integration relies on those private helpers.

from .translation import translation_dict
from . import ep_core as ep
from .ep_operators import EP_OT_rebake_all, EP_OT_switch_level_hijack, EP_OT_add_layer
from .ep_ui import VIEW3D_PT_edit_poly_standalone
from .ep_handlers import ep_selection_handler

classes = (
    EP_OT_rebake_all,
    EP_OT_switch_level_hijack,
    EP_OT_add_layer,
    VIEW3D_PT_edit_poly_standalone,
)

# Smart Modifier keeps configuration in the N-panel only. The legacy standalone
# preference class is intentionally not registered; embedded registration
# also excludes the optional standalone N-panel.
_EMBEDDED_EXCLUDE = {VIEW3D_PT_edit_poly_standalone}
classes_embedded = tuple(cls for cls in classes if cls not in _EMBEDDED_EXCLUDE)

_RUNTIME_ENABLED = False

# Blender REPLACES bpy.app.driver_namespace on every file load, which erased the
# _EP_* bridge callables published below.  Smart Modifier's paste/multi-edit path
# (operators.py) then found no _EP_ENTER_EDIT_MULTI_MAP_V1 and silently skipped
# entering Edit Poly, and _EP_ACTIVE_MODULE ownership was lost so this module's
# own teardown no longer recognised itself.  The owner mark below lives in Smart
# Modifier's process-lifetime anchor (see core._ms_ns_anchor_store), so the
# runtime re-arm can tell "this generation owns the bridges" from "dormant".
_EP_NS_ANCHOR_MODULE_NAME = "jelararagi_smart_modifier_ns_anchor_v1"
_EP_NS_ANCHOR_ATTR = "SMS_NS_VALUES"
_EP_BRIDGE_OWNER_KEY = "_EP_BRIDGE_OWNER_V1"


def _ep_ns_anchor_store():
    """Smart Modifier's process-lifetime driver_namespace anchor.  Never raises."""
    try:
        module = sys.modules.get(_EP_NS_ANCHOR_MODULE_NAME)
        if not isinstance(module, types.ModuleType):
            module = types.ModuleType(_EP_NS_ANCHOR_MODULE_NAME)
            module.__doc__ = (
                "Smart Modifier Suite driver_namespace anchor.  Not an importable module."
            )
            setattr(module, _EP_NS_ANCHOR_ATTR, {})
            sys.modules[_EP_NS_ANCHOR_MODULE_NAME] = module
        store = getattr(module, _EP_NS_ANCHOR_ATTR, None)
        if not isinstance(store, dict):
            store = {}
            setattr(module, _EP_NS_ANCHOR_ATTR, store)
        return store
    except Exception:
        return {}


def _ep_publish_bridges():
    """(Re-)publish the Edit Poly cross-module bridges.  Idempotent, never raises."""
    try:
        dn = bpy.app.driver_namespace
    except Exception:
        return False
    try:
        dn["_EP_ACTIVE_MODULE"] = __name__
    except Exception:
        pass
    try: dn["_EP_REBAKE_STACK_UPTO"] = ep.rebake_edit_polys_upto
    except Exception: pass
    try: dn["_EP_HELPERS_FOR_MAIN_V1"] = ep.ep_iter_helpers_for_main
    except Exception: pass
    try: dn["_EP_ENTER_EDIT_MULTI_V1"] = ep._ep_enter_edit_mode_for_layer_multi
    except Exception: pass
    try: dn["_EP_ENTER_EDIT_MULTI_MAP_V1"] = ep._ep_enter_edit_mode_for_layer_multi_map
    except Exception: pass
    try: dn["_EP_ENTER_EDIT_SINGLE_V1"] = ep._ep_enter_edit_mode_for_layer
    except Exception: pass
    _ep_ns_anchor_store()[_EP_BRIDGE_OWNER_KEY] = __name__
    return True


def _ep_release_bridges():
    """Drop the ownership mark so a torn-down generation is never re-armed."""
    try:
        _ep_ns_anchor_store().pop(_EP_BRIDGE_OWNER_KEY, None)
    except Exception:
        pass


def ensure_driver_namespace_bridges():
    """Re-arm the bridges after a file load replaced driver_namespace.

    Called by ``runtime._ms_rearm_driver_namespace_after_load`` from the suite's
    existing persistent ``load_post`` handler.  A no-op while this module is not
    the registered bridge owner, so an unregistered generation stays dormant.
    """
    try:
        if _ep_ns_anchor_store().get(_EP_BRIDGE_OWNER_KEY) != __name__:
            return False
        return bool(_ep_publish_bridges())
    except Exception:
        return False


def set_runtime_enabled(enabled: bool):
    global _RUNTIME_ENABLED
    _RUNTIME_ENABLED = bool(enabled)
    try:
        dn = bpy.app.driver_namespace
        dn["_EP_RUNTIME_ENABLED_V1"] = _RUNTIME_ENABLED
    except Exception:
        pass
    try:
        while ep_selection_handler in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(ep_selection_handler)
    except Exception:
        pass
    if not _RUNTIME_ENABLED:
        try:
            ep._ep_disarm_live_topology_poll()
        except Exception:
            pass
        for timer_name in ('_modsys_cleanup_timer', '_ep_objmode_cleanup_timer', '_delayed_register_plugin'):
            try:
                timer_fn = getattr(ep, timer_name, None)
                if callable(timer_fn) and bpy.app.timers.is_registered(timer_fn):
                    bpy.app.timers.unregister(timer_fn)
            except Exception:
                pass
        try:
            ep._EP_OBJMODE_CLEANUP_QUEUE.clear()
            ep._EP_OBJMODE_CLEANUP_TIMER_RUNNING = False
            bpy.app.driver_namespace['_MODSYS_CLEANUP_PENDING'] = False
        except Exception:
            pass
        return
    try:
        if ep_selection_handler not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(ep_selection_handler)
    except Exception:
        pass
    try:
        ep._ep_arm_live_topology_poll()
    except Exception:
        pass





def _expand_translation_contexts(translation_dict):
    """Mirror translations between default and operator contexts if missing."""
    try:
        from bpy.app.translations import contexts as i18n_contexts
    except Exception:
        return translation_dict

    ctx_default = i18n_contexts.default
    ctx_operator = i18n_contexts.operator_default

    expanded = {}
    for lang, table in (translation_dict or {}).items():
        if not isinstance(table, dict):
            continue
        new_table = dict(table)
        for key, value in list(table.items()):
            if not (isinstance(key, tuple) and len(key) == 2 and isinstance(key[1], str)):
                continue
            ctx, msgid = key
            if ctx == ctx_default and (ctx_operator, msgid) not in new_table:
                new_table[(ctx_operator, msgid)] = value
            elif ctx == ctx_operator and (ctx_default, msgid) not in new_table:
                new_table[(ctx_default, msgid)] = value
        expanded[lang] = new_table
    return expanded

def register():
    # Translations
    try:
        bpy.app.translations.register(__name__, _expand_translation_contexts(translation_dict))
    except Exception:
        pass

    dn = bpy.app.driver_namespace
    dn["_EP_ACTIVE_MODULE"] = __name__

    # Register classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            # Keep behavior stable: do not hard-fail on duplicate registers.
            pass

    with _feature_toggle.capture_runtime('edit_poly_modifier', 'Edit Polygon Modifier'):
        set_runtime_enabled(True)

    # Public API for Smart Modifier integration.  Publishing goes through the
    # shared helper so the same set is re-armed after a file load wipes it.
    _ep_publish_bridges()

    # Register plugin with Smart Modifier (IMPORTANT for "モディファイアを追加" menu)
    try:
        ep._ep_ms_register_plugin()
    except Exception:
        pass
    try:
        if not callable(dn.get("_MS_REGISTER_PLUGIN_V1")):
            bpy.app.timers.register(ep._delayed_register_plugin, first_interval=1.0)
    except Exception:
        pass

    # Cleanup is requested by actual Edit Poly commands, never at registration.


def unregister():
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    dn = bpy.app.driver_namespace

    set_runtime_enabled(False)
    try:
        dn.pop("_EP_RUNTIME_ENABLED_V1", None)
    except Exception:
        pass

    try:
        ep._ep_ms_unregister_plugin()
    except Exception:
        pass

    for k in (
        "_EP_REBAKE_STACK_UPTO",
        "_EP_HELPERS_FOR_MAIN_V1",
        "_EP_ENTER_EDIT_MULTI_V1",
        "_EP_ENTER_EDIT_MULTI_MAP_V1",
        "_EP_ENTER_EDIT_SINGLE_V1",
    ):
        try:
            dn.pop(k, None)
        except Exception:
            pass

    _ep_release_bridges()

    try:
        dn.pop("_EP_PENDING_SYNC", None)
        dn.pop("_EP_PENDING_TIMER", None)
        dn.pop("_EP_SYNC_LOCK", None)
        dn.pop("_EP_ACTIVE_MODULE", None)
        dn.pop("_EP_QUICK_SIG_V1", None)
    except Exception:
        pass

    try:
        dn.pop("_MODSYS_REQUEST_CLEANUP", None)
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            pass  # session-stable: keep classes registered during live UI
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Embedded API (Smart Modifier bundled subtool)
# -----------------------------------------------------------------------------


def register_embedded():
    """Register Edit Poly when bundled inside another add-on.

    This registers operators/handlers/plugin hooks, but does *not* register
    add-on preferences nor the standalone N-panel.
    """
    # Translations
    try:
        bpy.app.translations.register(__name__, _expand_translation_contexts(translation_dict))
    except Exception:
        pass

    dn = bpy.app.driver_namespace
    dn["_EP_ACTIVE_MODULE"] = __name__

    for cls in classes_embedded:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass

    # Keep bundled Edit Poly dormant until the user actually starts using it.
    # The runtime is armed on demand by Smart Modifier operators when needed.
    set_runtime_enabled(False)

    # Public API for Smart Modifier integration.  Publishing goes through the
    # shared helper so the same set is re-armed after a file load wipes it.
    _ep_publish_bridges()

    # Register plugin with Smart Modifier (delayed for safety)
    try:
        ep._ep_ms_register_plugin()
    except Exception:
        pass
    try:
        if not callable(dn.get("_MS_REGISTER_PLUGIN_V1")):
            bpy.app.timers.register(ep._delayed_register_plugin, first_interval=1.0)
    except Exception:
        pass

    # Cleanup is requested by actual Edit Poly commands, never at registration.


def unregister_embedded():
    """Unregister Edit Poly bundled subtool."""
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    dn = bpy.app.driver_namespace

    set_runtime_enabled(False)
    try:
        dn.pop("_EP_RUNTIME_ENABLED_V1", None)
    except Exception:
        pass

    try:
        ep._ep_ms_unregister_plugin()
    except Exception:
        pass

    for k in (
        "_EP_REBAKE_STACK_UPTO",
        "_EP_HELPERS_FOR_MAIN_V1",
        "_EP_ENTER_EDIT_MULTI_V1",
        "_EP_ENTER_EDIT_MULTI_MAP_V1",
        "_EP_ENTER_EDIT_SINGLE_V1",
    ):
        try:
            dn.pop(k, None)
        except Exception:
            pass

    _ep_release_bridges()

    try:
        dn.pop("_EP_PENDING_SYNC", None)
        dn.pop("_EP_PENDING_TIMER", None)
        dn.pop("_EP_SYNC_LOCK", None)
        dn.pop("_EP_ACTIVE_MODULE", None)
        dn.pop("_EP_QUICK_SIG_V1", None)
    except Exception:
        pass

    try:
        dn.pop("_MODSYS_REQUEST_CLEANUP", None)
    except Exception:
        pass

    for cls in reversed(classes_embedded):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
