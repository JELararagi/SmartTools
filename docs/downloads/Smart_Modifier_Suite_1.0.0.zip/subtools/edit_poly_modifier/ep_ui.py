# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from .ep_core import VIEW3D_PT_edit_poly_standalone

__all__ = ["VIEW3D_PT_edit_poly_standalone"]
