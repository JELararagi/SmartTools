# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from .ep_core import VIEW3D_PT_edit_poly_standalone

__all__ = ["VIEW3D_PT_edit_poly_standalone"]
