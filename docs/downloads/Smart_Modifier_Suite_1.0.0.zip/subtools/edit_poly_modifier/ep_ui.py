# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the Edit Poly panel under its established module name."""

from .ep_core import VIEW3D_PT_edit_poly_standalone

__all__ = ["VIEW3D_PT_edit_poly_standalone"]
