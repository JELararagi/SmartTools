# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

# This file provides Japanese translations for UI strings used by this add-on.
# Source language: English

translation_dict = {
    "ja_JP": {
        ('*', '* Please use Smart Modifier for layer management.'): '※スタック管理は Smart Modifierをご利用ください',
        ('*', 'Add Edit Poly'): '編集ポリゴンを追加',
        ('*', 'Add Edit Poly Layer'): '編集ポリゴンレイヤーを追加',
        ('*', 'Add Edit Polygon'): '編集ポリゴンを追加',
        ('*', 'Add Edit Polygon Layer'): '編集ポリゴンレイヤーを追加',
        ('*', 'Edit Polygon'): '編集ポリゴン',
        ('*', 'Edit Polygon (Standalone)'): '編集ポリゴン（単体）',
        ('*', 'Edit Polygon Modifier'): '編集ポリゴン',
        ('*', "Add an Edit Polygon layer to the selected object(s).\n\n- Automatically manages 'Frozen' (base) and 'Edit' (result) so you can edit deltas non-destructively.\n- Layers stack from top to bottom, letting you keep lower layers while adding more edits.\n\nUsage: After adding, make the layer active and edit in Edit Mode.\nUse 'Rebake All Layers' if you need to resync."): '選択したオブジェクトに編集ポリゴンレイヤーを追加します。\n\n・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n\n使い方：追加後はレイヤーをアクティブにして 編集モードで編集してください。\n必要なら『全レイヤー再計算』で整合を取り直せます。',
        ('*', 'Add an EditPoly layer to selected objects. You edit by adding a displacement offset on top of the evaluated result of the modifiers above. With multiple selection, it adds as an instance (same name/settings) and immediately enters multi-object Edit Mode.'): '選択オブジェクトにEditPolyレイヤーを追加します。上（手前）階層のモディファイア適用済み形状を基準に、差分（オフセット）を加算して編集できます。複数選択時はインスタンスとして同名で追加し、追加直後に複数オブジェクト編集モードへ入ります。',
        ('*', 'Edit Poly'): '編集ポリゴン',
        ('*', 'Edit Poly (Standalone)'): '編集ポリゴン（単体）',
        ('*', 'Edit Poly レイヤーを追加'): '編集ポリゴンレイヤーを追加',
        ('*', 'Edit Polyを追加'): '編集ポリゴンを追加',
        ('*', 'Edit Poly（単体）'): '編集ポリゴン（単体）',
        ('*', 'EditPoly'): '編集ポリゴン',
        ('*', 'Max-style Edit Poly Layer functionality (integrates with Smart Modifier).'): 'Max風編集ポリゴンレイヤー機能（Smart Modifierと連携）',
        ('*', 'Max風編集ポリゴンレイヤー機能（Smart Modifierと連携）'): 'Max風編集ポリゴンレイヤー機能（Smart Modifierと連携）',
        ('*', 'Please select a mesh object.'): 'メッシュオブジェクトを選択してください。',
        ('*', 'Rebake All'): '全レイヤー再計算',
        ('*', "Recompute all EditPoly layers. After stack changes, it rebuilds consistency between each layer's Frozen base and Edit mesh."): 'すべてのEditPolyレイヤーを再計算します。スタック構成変更後に、各レイヤーの基準形状（Frozen）と編集形状（Edit）の整合を取り直します。',
        ('*', 'Show a lightweight standalone N-panel tab so you can still add/rebake layers without Smart Modifier.\nNormally, managing layers from Smart Modifier is recommended. Turn this ON only when you want standalone operation.'): 'Smart Modifier を使わない環境でも最低限の追加/再計算を行えるように、Nパネルに単体用の簡易タブを表示します。\n通常は Smart Modifier から管理するのがおすすめです。単体運用時だけ ON にしてください。',
        ('*', 'Show a minimal UI in the N-panel so the tool can be used without Smart Modifier. Normally, manage layers with Smart Modifier.'): 'Smart Modifierが無い環境でも最低限操作できるよう、Nパネルに簡易UIを表示します。通常はSmart Modifierで管理してください。',
        ('*', 'Show dedicated tab in N-panel'): 'Nパネルに専用タブを表示',
        ('*', 'Sync EditPoly edit state safely when Smart Modifier switches the active level.'): 'Smart Modifier からのレベル切替（アクティブ段変更）を受け取り、EditPoly の編集状態を安全に同期します。',
        ('*', 'Sync Level Switch'): 'レベル切替同期',
        ('*', '選択したオブジェクトに編集ポリゴンレイヤーを追加します。\n\n・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n\n使い方：追加後はレイヤーをアクティブにして 編集モードで編集してください。\n必要なら『全レイヤー再計算』で整合を取り直せます。'): '選択したオブジェクトに 編集ポリゴンレイヤーを追加します。\n\n・『Frozen（基準形状）』と『Edit（編集結果）』を自動で管理し、非破壊で差分編集できます。\n・レイヤーは上から順に積み重なり、下のレイヤーを保ったまま追加編集できます。\n\n使い方：追加後はレイヤーをアクティブにして「編集モード」で編集してください。\n必要なら『全レイヤー再計算』で整合を取り直せます。',
    }
}
