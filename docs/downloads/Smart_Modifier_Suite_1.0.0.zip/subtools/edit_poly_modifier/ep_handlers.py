# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from .ep_core import ep_selection_handler

__all__ = ["ep_selection_handler"]
