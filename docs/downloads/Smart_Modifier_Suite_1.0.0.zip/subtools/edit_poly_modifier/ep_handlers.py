# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose Edit Poly selection updates to lifecycle registration."""

from .ep_core import ep_selection_handler

__all__ = ["ep_selection_handler"]
