# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for align_to_active_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "align_to_active_modifier"
PLUGIN_LABEL = "Align To Active Modifier"
OPERATOR_ID = "smsp.align_to_active"
PLUGIN_ICON = "ORIENTATION_GLOBAL"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
