# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for curve_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "curve_modifier"
PLUGIN_LABEL = "Curve Modifier"
OPERATOR_ID = "smsp.selected_edges_to_curve"
PLUGIN_ICON = "CURVE_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
