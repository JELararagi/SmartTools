# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for straighten_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "straighten_modifier"
PLUGIN_LABEL = "Straighten Modifier"
OPERATOR_ID = "sms.straighten_selection"
PLUGIN_ICON = "EMPTY_ARROWS"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
