# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for scatter_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "scatter_modifier"
PLUGIN_LABEL = "Scatter Modifier"
OPERATOR_ID = "sms.scatter_instances_bake"
PLUGIN_ICON = "PARTICLES"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
