# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for fill_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "fill_modifier"
PLUGIN_LABEL = "Smart Fill Modifier"
OPERATOR_ID = "sms.smart_fill_topology"
PLUGIN_ICON = "MESH_GRID"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
