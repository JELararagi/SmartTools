# -*- coding: utf-8 -*-
"""Dedicated 3ds Max-style Face Extrude backend.

The modifier consumes an exact face-domain Boolean attribute captured from the
active Smart Modifier selection layer.  Its graph is fail-closed and never
falls back to Solidify or to a passthrough node group.
"""

from __future__ import annotations

import hashlib

import bmesh
import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ...translation import choose_text


FACE_EXTRUDE_MARKER_PROP = "smsm_face_extrude_modifier"
FACE_EXTRUDE_GRAPH_CONTRACT_PROP = "smsm_face_extrude_graph_contract"
FACE_EXTRUDE_GRAPH_CONTRACT = "dedicated_face_extrude_2026_1_v1"
FACE_EXTRUDE_NODE_GROUP_PROP = "smsm_face_extrude_node_group"
FACE_EXTRUDE_SOCKET_PREFIX = "smsm_face_extrude_socket_"
FACE_EXTRUDE_GROUP_OWNER_PROP = "smsm_face_extrude_group_owner"
FACE_EXTRUDE_GROUP_OWNER_VALUE = "SmartModifier:face_extrude_modifier:4.32.90"
FACE_EXTRUDE_SELECTION_NAME_PROP = "smsm_face_extrude_selection_name"
FACE_EXTRUDE_SELECTED_COUNT_PROP = "smsm_face_extrude_selected_count"
FACE_EXTRUDE_SELECTION_PREFIX = "SMSM Face Extrude Selection"
FACE_EXTRUDE_SELECTION_OWNER_PREFIX = "smsm_fex_owner:"

FACE_EXTRUDE_SOCKET_NAMES = {
    "amount": "Amount",
    "scale": "Scale",
    "from_center": "Extrude From Center",
    "center": "Center",
    "selection_attribute": "Selection Attribute",
}

FACE_EXTRUDE_DEFAULTS = {
    "amount": 0.1,
    "scale": 1.0,
    "from_center": False,
    "center": (0.0, 0.0, 0.0),
    "selection_attribute": "",
}

REQUIRED_NODES = {
    "GeometryNodeInputNamedAttribute",
    "GeometryNodeExtrudeMesh",
    "GeometryNodeInputPosition",
    "GeometryNodeSwitch",
    "GeometryNodeSetPosition",
    "GeometryNodeScaleElements",
}


def _unique_name(base, collection):
    if collection.get(base) is None:
        return base
    index = 1
    while collection.get(f"{base}.{index:03d}") is not None:
        index += 1
    return f"{base}.{index:03d}"


def _socket(sockets, names=(), fallback=None):
    for name in names:
        try:
            found = sockets.get(name)
            if found is not None:
                return found
        except Exception:
            pass
    if fallback is not None:
        try:
            return sockets[fallback]
        except Exception:
            pass
    return None


def _link(group, source, target):
    if source is None or target is None:
        raise RuntimeError("Face Extrude graph socket was not found")
    group.links.new(source, target)


def _set_default(socket, value):
    if socket is None:
        raise RuntimeError("Face Extrude graph default socket was not found")
    socket.default_value = value


def _add_socket(group, name, in_out, socket_type, *, default=None, minimum=None, maximum=None, description=""):
    item = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    if default is not None:
        try:
            item.default_value = default
        except Exception:
            pass
    if minimum is not None:
        try:
            item.min_value = minimum
        except Exception:
            pass
    if maximum is not None:
        try:
            item.max_value = maximum
        except Exception:
            pass
    try:
        item.description = description
    except Exception:
        pass
    return item


def _interface_socket(group, name, in_out="INPUT"):
    for item in group.interface.items_tree:
        if (
            str(getattr(item, "item_type", "")) == "SOCKET"
            and str(getattr(item, "in_out", "")).upper() == in_out.upper()
            and str(getattr(item, "name", "")) == name
        ):
            return item
    return None


def _vector_math(nodes, operation, label):
    node = nodes.new("ShaderNodeVectorMath")
    node.operation = operation
    node.label = label
    return node


def make_face_extrude_group(obj, defn=None, context=None):
    owner = str(getattr(obj, "name", "Object") or "Object")
    group = None
    try:
        group = bpy.data.node_groups.new(
            _unique_name(f"Smart_Face_Extrude - {owner}", bpy.data.node_groups),
            "GeometryNodeTree",
        )
        group.is_modifier = True
        group[FACE_EXTRUDE_GROUP_OWNER_PROP] = FACE_EXTRUDE_GROUP_OWNER_VALUE
        group[FACE_EXTRUDE_GRAPH_CONTRACT_PROP] = FACE_EXTRUDE_GRAPH_CONTRACT

        _add_socket(group, "Geometry", "INPUT", "NodeSocketGeometry", description="Incoming ordered stack geometry.")
        _add_socket(group, "Amount", "INPUT", "NodeSocketFloat", default=0.1, minimum=-100000.0, maximum=100000.0, description="Moves selected faces along their averaged normals, or radially from Center.")
        _add_socket(group, "Scale", "INPUT", "NodeSocketFloat", default=1.0, minimum=-100000.0, maximum=100000.0, description="Scales every connected selected-face cluster independently around its center.")
        _add_socket(group, "Extrude From Center", "INPUT", "NodeSocketBool", default=False, description="Uses the direction from Center to each selected point instead of averaged face normals.")
        _add_socket(group, "Center", "INPUT", "NodeSocketVector", default=(0.0, 0.0, 0.0), minimum=-100000.0, maximum=100000.0, description="Animatable local-space center for radial face extrusion.")
        _add_socket(group, "Selection Attribute", "INPUT", "NodeSocketString", default="", description="Owned face-domain Boolean selection captured by this stack row.")
        _add_socket(group, "Geometry", "OUTPUT", "NodeSocketGeometry", description="Face Extrude result with generated side faces.")

        nodes = group.nodes
        nodes.clear()
        group_input = nodes.new("NodeGroupInput")
        group_output = nodes.new("NodeGroupOutput")
        group_output.is_active_output = True
        group_input.location = (-900, 0)
        group_output.location = (900, 0)

        named_selection = nodes.new("GeometryNodeInputNamedAttribute")
        named_selection.data_type = "BOOLEAN"
        named_selection.label = "Exact Face Selection"
        _link(group, _socket(group_input.outputs, ("Selection Attribute",), 5), _socket(named_selection.inputs, ("Name",), 0))

        normal_amount = nodes.new("GeometryNodeSwitch")
        normal_amount.input_type = "FLOAT"
        normal_amount.label = "Normal Amount or Zero"
        _set_default(_socket(normal_amount.inputs, ("True",), 2), 0.0)
        _link(group, _socket(group_input.outputs, ("Extrude From Center",), 3), _socket(normal_amount.inputs, ("Switch",), 0))
        _link(group, _socket(group_input.outputs, ("Amount",), 1), _socket(normal_amount.inputs, ("False",), 1))

        extrude = nodes.new("GeometryNodeExtrudeMesh")
        extrude.mode = "FACES"
        extrude.label = "Connected Face Extrude"
        _set_default(_socket(extrude.inputs, ("Offset",), 2), (0.0, 0.0, 0.0))
        _set_default(_socket(extrude.inputs, ("Individual",), 4), False)
        _link(group, _socket(group_input.outputs, ("Geometry",), 0), _socket(extrude.inputs, ("Mesh",), 0))
        _link(group, _socket(named_selection.outputs, ("Attribute",), 0), _socket(extrude.inputs, ("Selection",), 1))
        _link(group, _socket(normal_amount.outputs, ("Output",), 0), _socket(extrude.inputs, ("Offset Scale",), 3))

        position = nodes.new("GeometryNodeInputPosition")
        radial = _vector_math(nodes, "SUBTRACT", "Position From Center")
        radial_direction = _vector_math(nodes, "NORMALIZE", "Radial Direction")
        radial_amount = _vector_math(nodes, "SCALE", "Radial Amount")
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(radial.inputs, fallback=0))
        _link(group, _socket(group_input.outputs, ("Center",), 4), _socket(radial.inputs, fallback=1))
        _link(group, _socket(radial.outputs, ("Vector",), 0), _socket(radial_direction.inputs, fallback=0))
        _link(group, _socket(radial_direction.outputs, ("Vector",), 0), _socket(radial_amount.inputs, ("Vector",), 0))
        _link(group, _socket(group_input.outputs, ("Amount",), 1), _socket(radial_amount.inputs, ("Scale",), 3))

        center_offset = nodes.new("GeometryNodeSwitch")
        center_offset.input_type = "VECTOR"
        center_offset.label = "Center-mode Offset"
        _set_default(_socket(center_offset.inputs, ("False",), 1), (0.0, 0.0, 0.0))
        _link(group, _socket(group_input.outputs, ("Extrude From Center",), 3), _socket(center_offset.inputs, ("Switch",), 0))
        _link(group, _socket(radial_amount.outputs, ("Vector",), 0), _socket(center_offset.inputs, ("True",), 2))

        set_position = nodes.new("GeometryNodeSetPosition")
        set_position.label = "Move Extruded Top From Center"
        _link(group, _socket(extrude.outputs, ("Mesh",), 0), _socket(set_position.inputs, ("Geometry",), 0))
        _link(group, _socket(extrude.outputs, ("Top",), 1), _socket(set_position.inputs, ("Selection",), 1))
        _link(group, _socket(center_offset.outputs, ("Output",), 0), _socket(set_position.inputs, ("Offset",), 3))

        scale_elements = nodes.new("GeometryNodeScaleElements")
        scale_elements.domain = "FACE"
        scale_elements.label = "Scale Connected Face Clusters"
        _link(group, _socket(set_position.outputs, ("Geometry",), 0), _socket(scale_elements.inputs, ("Geometry",), 0))
        _link(group, _socket(extrude.outputs, ("Top",), 1), _socket(scale_elements.inputs, ("Selection",), 1))
        _link(group, _socket(group_input.outputs, ("Scale",), 2), _socket(scale_elements.inputs, ("Scale",), 2))
        _link(group, _socket(scale_elements.outputs, ("Geometry",), 0), _socket(group_output.inputs, ("Geometry",), 0))

        actual = {str(node.bl_idname) for node in nodes}
        if not REQUIRED_NODES.issubset(actual) or len(group.links) < 19:
            raise RuntimeError("Dedicated Face Extrude graph contract is incomplete")
        group["smsm_face_extrude_required_nodes"] = ",".join(sorted(REQUIRED_NODES))
        group["smsm_face_extrude_link_count"] = len(group.links)
        return group
    except Exception:
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        raise


def is_verified_face_extrude_group(group):
    try:
        actual = {str(node.bl_idname) for node in group.nodes}
        return (
            str(group.get(FACE_EXTRUDE_GROUP_OWNER_PROP, "") or "") == FACE_EXTRUDE_GROUP_OWNER_VALUE
            and str(group.get(FACE_EXTRUDE_GRAPH_CONTRACT_PROP, "") or "") == FACE_EXTRUDE_GRAPH_CONTRACT
            and REQUIRED_NODES.issubset(actual)
            and int(group.get("smsm_face_extrude_link_count", -1)) == len(group.links)
        )
    except Exception:
        return False


def _selection_owner_key(attribute_name):
    digest = hashlib.sha256(str(attribute_name or "").encode("utf-8")).hexdigest()[:32]
    return FACE_EXTRUDE_SELECTION_OWNER_PREFIX + digest


def _selection_socket_id(mod):
    try:
        return str(mod.get(FACE_EXTRUDE_SOCKET_PREFIX + "selection_attribute", "") or "")
    except Exception:
        return ""


def _mesh_from_owner(owner):
    if owner is None:
        return None
    if isinstance(owner, bpy.types.Mesh):
        return owner
    data = getattr(owner, "data", None)
    return data if isinstance(data, bpy.types.Mesh) else None


def _is_owned_face_selection(mesh, name):
    if mesh is None or not name:
        return False
    attribute = mesh.attributes.get(name)
    try:
        return (
            attribute is not None
            and str(getattr(attribute, "domain", "")) == "FACE"
            and str(getattr(attribute, "data_type", "")) == "BOOLEAN"
            and str(mesh.get(_selection_owner_key(name), "") or "") == FACE_EXTRUDE_GROUP_OWNER_VALUE
        )
    except Exception:
        return False


def _face_selection_is_referenced(mesh, name):
    for obj in tuple(getattr(bpy.data, "objects", ()) or ()):
        if getattr(obj, "data", None) is not mesh:
            continue
        for other in tuple(getattr(obj, "modifiers", ()) or ()):
            try:
                sid = _selection_socket_id(other)
                if sid and str(other.get(sid, "") or "") == name:
                    return True
            except Exception:
                continue
    return False


def remove_owned_face_selection_if_unused(owner, attribute_name):
    mesh = _mesh_from_owner(owner)
    name = str(attribute_name or "")
    if mesh is None or not name:
        return False
    owner_key = _selection_owner_key(name)
    if not _is_owned_face_selection(mesh, name):
        return False
    if _face_selection_is_referenced(mesh, name):
        return False
    mesh.attributes.remove(mesh.attributes.get(name))
    try:
        del mesh[owner_key]
    except Exception:
        pass
    return True


def _write_face_attribute(attribute, polygon_count, indices):
    selected = {int(index) for index in (indices or ()) if 0 <= int(index) < int(polygon_count)}
    values = [index in selected for index in range(int(polygon_count))]
    try:
        attribute.data.foreach_set("value", values)
    except Exception:
        for index, value in enumerate(values):
            attribute.data[index].value = bool(value)
    return len(selected)


def capture_face_selection(obj, mod, face_indices):
    mesh = _mesh_from_owner(obj)
    if mesh is None or mod is None or not bool(mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
        raise RuntimeError("Face Extrude owner or modifier is unavailable")
    sid = _selection_socket_id(mod)
    if not sid:
        raise RuntimeError("Face Extrude selection socket is unavailable")
    previous_name = str(mod.get(sid, "") or "")
    previous_attribute = mesh.attributes.get(previous_name) if previous_name else None
    previous_owned = _is_owned_face_selection(mesh, previous_name)
    attribute = previous_attribute if previous_owned else None
    created = False
    if attribute is None:
        name = _unique_name(f"{FACE_EXTRUDE_SELECTION_PREFIX} - {getattr(obj, 'name', 'Object')}", mesh.attributes)
        attribute = mesh.attributes.new(name=name, type="BOOLEAN", domain="FACE")
        mesh[_selection_owner_key(attribute.name)] = FACE_EXTRUDE_GROUP_OWNER_VALUE
        created = True
    try:
        count = _write_face_attribute(attribute, len(mesh.polygons), face_indices)
        mod[sid] = str(attribute.name)
        mod[FACE_EXTRUDE_SELECTION_NAME_PROP] = str(attribute.name)
        mod[FACE_EXTRUDE_SELECTED_COUNT_PROP] = int(count)
        obj.update_tag(refresh={"DATA"})
    except Exception:
        if created:
            try:
                mesh.attributes.remove(attribute)
            except Exception:
                pass
            try:
                del mesh[_selection_owner_key(attribute.name)]
            except Exception:
                pass
        raise
    if previous_name and previous_name != attribute.name:
        remove_owned_face_selection_if_unused(mesh, previous_name)
    return int(count)


def clear_face_selection(obj, mod):
    mesh = _mesh_from_owner(obj)
    sid = _selection_socket_id(mod)
    if mesh is None or not sid:
        return False
    previous_name = str(mod.get(sid, "") or "")
    mod[sid] = ""
    mod[FACE_EXTRUDE_SELECTION_NAME_PROP] = ""
    mod[FACE_EXTRUDE_SELECTED_COUNT_PROP] = 0
    removed = remove_owned_face_selection_if_unused(mesh, previous_name)
    try:
        obj.update_tag(refresh={"DATA"})
    except Exception:
        pass
    return bool(previous_name or removed)


def configure_face_extrude_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group=False, face_indices=None):
    if obj is None or mod is None:
        raise RuntimeError("Face Extrude owner/modifier is missing")
    if group is None or force_unique_group:
        group = make_face_extrude_group(obj, defn, context=context)
    if getattr(mod, "node_group", None) is not group:
        mod.node_group = group
    if not is_verified_face_extrude_group(group):
        raise RuntimeError("Face Extrude group does not satisfy its owned graph contract")
    mod[FACE_EXTRUDE_MARKER_PROP] = True
    mod[FACE_EXTRUDE_GRAPH_CONTRACT_PROP] = FACE_EXTRUDE_GRAPH_CONTRACT
    mod[FACE_EXTRUDE_NODE_GROUP_PROP] = str(group.name)
    mod["smsm_max_modifier_backend"] = "face_extrude_nodes"
    for key, socket_name in FACE_EXTRUDE_SOCKET_NAMES.items():
        socket = _interface_socket(group, socket_name)
        identifier = str(getattr(socket, "identifier", "") or "") if socket is not None else ""
        if not identifier:
            raise RuntimeError(f"Face Extrude interface socket is missing: {socket_name}")
        mod[FACE_EXTRUDE_SOCKET_PREFIX + key] = identifier
        if key in FACE_EXTRUDE_DEFAULTS and identifier not in mod:
            mod[identifier] = FACE_EXTRUDE_DEFAULTS[key]
    if face_indices is not None:
        capture_face_selection(obj, mod, face_indices)
    try:
        obj.update_tag(refresh={"DATA"})
    except Exception:
        obj.update_tag()
    return group


def face_extrude_skip_copy_props(mod):
    result = {
        FACE_EXTRUDE_MARKER_PROP,
        FACE_EXTRUDE_GRAPH_CONTRACT_PROP,
        FACE_EXTRUDE_NODE_GROUP_PROP,
        FACE_EXTRUDE_SELECTION_NAME_PROP,
        FACE_EXTRUDE_SELECTED_COUNT_PROP,
        "node_group",
    }
    result.update(str(key) for key in mod.keys() if str(key).startswith(FACE_EXTRUDE_SOCKET_PREFIX))
    selection_sid = _selection_socket_id(mod)
    if selection_sid:
        result.add(selection_sid)
    return result


def after_face_extrude_instance_sync(src_obj, src_mod, obj, mod, context=None):
    configure_face_extrude_modifier(
        obj,
        mod,
        getattr(mod, "node_group", None),
        {"key": "face_extrude_modifier", "backend": "face_extrude_nodes"},
        context=context,
    )


def after_face_extrude_make_unique(obj, mod, context=None):
    old = getattr(mod, "node_group", None)
    if old is None:
        configure_face_extrude_modifier(obj, mod, None, {"key": "face_extrude_modifier", "backend": "face_extrude_nodes"}, context=context)
        return
    copied = old.copy()
    copied.name = _unique_name(f"Smart_Face_Extrude - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    copied[FACE_EXTRUDE_GROUP_OWNER_PROP] = FACE_EXTRUDE_GROUP_OWNER_VALUE
    copied[FACE_EXTRUDE_GRAPH_CONTRACT_PROP] = FACE_EXTRUDE_GRAPH_CONTRACT
    configure_face_extrude_modifier(obj, mod, copied, {"key": "face_extrude_modifier", "backend": "face_extrude_nodes"}, context=context)


def face_extrude_before_item_action(main_obj, context, obj, mod, action, clipboard):
    try:
        if not bool(mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
            return None
    except Exception:
        return None
    sid = _selection_socket_id(mod)
    selection_name = str(mod.get(sid, "") or "") if sid else ""
    mesh = _mesh_from_owner(obj)
    return {
        "object_name": str(getattr(obj, "name", "") or ""),
        "mesh_name": str(getattr(getattr(obj, "data", None), "name", "") or ""),
        "selection_name": selection_name,
        "selection_owned": _is_owned_face_selection(mesh, selection_name),
        "group_name": str(getattr(getattr(mod, "node_group", None), "name", "") or ""),
    }


def _remove_owned_group_if_unused(group_name):
    name = str(group_name or "")
    group = bpy.data.node_groups.get(name) if name else None
    if group is None or not is_verified_face_extrude_group(group):
        return False
    for obj in tuple(getattr(bpy.data, "objects", ()) or ()):
        for mod in tuple(getattr(obj, "modifiers", ()) or ()):
            if getattr(mod, "node_group", None) is group:
                return False
    bpy.data.node_groups.remove(group)
    return True


def face_extrude_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    if str(action or "") not in {"DELETE", "CUT", "APPLY", "APPLY_BELOW"}:
        return None
    state = state or {}
    selection_name = str(state.get("selection_name", "") or "")
    meshes = []
    old_mesh = bpy.data.meshes.get(str(state.get("mesh_name", "") or ""))
    if old_mesh is not None:
        meshes.append(old_mesh)
    current_obj = bpy.data.objects.get(str(state.get("object_name", "") or ""))
    current_mesh = _mesh_from_owner(current_obj)
    if current_mesh is not None and current_mesh not in meshes:
        meshes.append(current_mesh)
    for mesh in meshes:
        if remove_owned_face_selection_if_unused(mesh, selection_name):
            continue
        if not bool(state.get("selection_owned", False)) or _face_selection_is_referenced(mesh, selection_name):
            continue
        attribute = mesh.attributes.get(selection_name)
        if attribute is None or str(attribute.domain) != "FACE" or str(attribute.data_type) != "BOOLEAN":
            continue
        mesh.attributes.remove(attribute)
        try:
            del mesh[_selection_owner_key(selection_name)]
        except Exception:
            pass
    _remove_owned_group_if_unused(str(state.get("group_name", "") or ""))
    return None


def _target(context, object_name, modifier_name):
    obj = bpy.data.objects.get(str(object_name or "")) or getattr(context, "object", None)
    mod = obj.modifiers.get(str(modifier_name or "")) if obj is not None else None
    try:
        valid = obj is not None and mod is not None and getattr(obj, "type", "") == "MESH" and bool(mod.get(FACE_EXTRUDE_MARKER_PROP, False))
    except Exception:
        valid = False
    return (obj, mod) if valid else (None, None)


def _selected_face_indices(obj):
    if getattr(obj, "mode", "OBJECT") == "EDIT":
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        return [face.index for face in bm.faces if bool(face.select)]
    return [poly.index for poly in obj.data.polygons if bool(poly.select)]


class SMSM_OT_max_face_extrude_capture_selection(Operator):
    bl_idname = "smsm.max_face_extrude_capture_selection"
    bl_label = "Capture Face Extrude Selection"
    bl_description = "Captures the exact current face selection for this Face Extrude stack row."
    bl_options = {"UNDO"}

    object_name: StringProperty(default="")
    modifier_name: StringProperty(default="")

    def execute(self, context):
        obj, mod = _target(context, self.object_name, self.modifier_name)
        if obj is None:
            self.report({"ERROR"}, choose_text("Face Extrude row was not found.", "フェース押し出し行が見つかりません。", context=context))
            return {"CANCELLED"}
        was_edit = getattr(obj, "mode", "OBJECT") == "EDIT"
        indices = _selected_face_indices(obj)
        if was_edit:
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                self.report({"ERROR"}, choose_text("Could not leave Edit Mode safely.", "編集モードを安全に終了できませんでした。", context=context))
                return {"CANCELLED"}
        try:
            count = capture_face_selection(obj, mod, indices)
        finally:
            if was_edit:
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass
        self.report({"INFO"}, choose_text(f"Captured {count} faces.", f"{count} 面を取得しました。", context=context))
        return {"FINISHED"}


class SMSM_OT_max_face_extrude_clear_selection(Operator):
    bl_idname = "smsm.max_face_extrude_clear_selection"
    bl_label = "Clear Face Extrude Selection"
    bl_description = "Clears only the face selection owned by this Face Extrude stack row."
    bl_options = {"UNDO"}

    object_name: StringProperty(default="")
    modifier_name: StringProperty(default="")

    def execute(self, context):
        obj, mod = _target(context, self.object_name, self.modifier_name)
        if obj is None:
            self.report({"ERROR"}, choose_text("Face Extrude row was not found.", "フェース押し出し行が見つかりません。", context=context))
            return {"CANCELLED"}
        clear_face_selection(obj, mod)
        self.report({"INFO"}, choose_text("Face selection cleared.", "面選択を解除しました。", context=context))
        return {"FINISHED"}


def draw_face_extrude_properties(layout, mod, context=None):
    try:
        if not bool(mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    box = layout.box()
    box.label(text=choose_text("Face Extrude Controls", "フェース押し出し制御", context=context), icon="MOD_SOLIDIFY")
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = True
    labels = {
        "amount": ("Amount", "量"),
        "scale": ("Scale", "スケール"),
        "from_center": ("Extrude From Center", "中心から押し出し"),
        "center": ("Center", "中心"),
    }
    for key in ("amount", "scale", "from_center"):
        sid = str(mod.get(FACE_EXTRUDE_SOCKET_PREFIX + key, "") or "")
        if sid:
            en, ja = labels[key]
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
    from_center_sid = str(mod.get(FACE_EXTRUDE_SOCKET_PREFIX + "from_center", "") or "")
    center_sid = str(mod.get(FACE_EXTRUDE_SOCKET_PREFIX + "center", "") or "")
    if center_sid and (not from_center_sid or bool(mod.get(from_center_sid, False))):
        col.prop(mod, f'["{center_sid}"]', text=choose_text("Center", "中心", context=context))
    owner = getattr(mod, "id_data", None)
    row = col.row(align=True)
    capture = row.operator("smsm.max_face_extrude_capture_selection", text=choose_text("Capture Selected Faces", "選択面を取得", context=context), icon="FACESEL")
    capture.object_name = str(getattr(owner, "name", "") or "")
    capture.modifier_name = str(getattr(mod, "name", "") or "")
    clear = row.operator("smsm.max_face_extrude_clear_selection", text="", icon="X")
    clear.object_name = str(getattr(owner, "name", "") or "")
    clear.modifier_name = str(getattr(mod, "name", "") or "")
    count = int(mod.get(FACE_EXTRUDE_SELECTED_COUNT_PROP, 0) or 0)
    col.label(text=choose_text(f"Captured Selection: {count} faces", f"取得した選択: {count} 面", context=context))
    return True


CLASSES = (
    SMSM_OT_max_face_extrude_capture_selection,
    SMSM_OT_max_face_extrude_clear_selection,
)
