# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from __future__ import annotations

from typing import Any
import bpy
from bpy.types import Operator
from bpy.props import BoolProperty, IntProperty, StringProperty
from mathutils import Matrix, Vector
import uuid

from ...translation import choose_text
from ... import event_hub
try:
    from ...icons import icon_value as _sms_icon_value, icon_name_for_max_definition as _sms_icon_for_defn, operator as _sms_icon_operator
except Exception:
    def _sms_icon_value(name=None, fallback=None): return 0
    def _sms_icon_for_defn(defn, fallback='max'): return fallback
    def _sms_icon_operator(layout, operator_id, *, text='', icon_name='', fallback_icon='MODIFIER', emboss=None, depress=None):
        kwargs={'text': text}
        if fallback_icon and fallback_icon != 'NONE': kwargs['icon']=fallback_icon
        if emboss is not None: kwargs['emboss']=emboss
        if depress is not None: kwargs['depress']=depress
        try:
            return layout.operator(operator_id, **kwargs)
        except Exception:
            kwargs.pop('icon', None); kwargs.pop('icon_value', None)
            return layout.operator(operator_id, **kwargs)

try:
    from ...help_button import draw_help_header
except Exception:
    def draw_help_header(layout, context, label, icon, help_id, **kwargs):
        try:
            layout.label(text=choose_text(label, label, context=context), icon='MODIFIER')
        except Exception:
            pass

from ...core import (
    get_main_object,
    ms_apply_auto_selection_to_new_modifiers,
    ms_apply_state_post_action,
    ms_capture_mode_bridge_state,
    ms_collect_new_modifiers,
    ms_enter_object_mode_bridge,
    ms_next_logical_name_from_base,
    ms_next_logical_default_name_across_objects,
    ms_obj_set_disp_name,
    ms_register_plugin,
    ms_group_modifiers_as_instance,
    ms_sync_instance_group_from,
    ms_calc_target_insert_index,
    ms_get_ui_active_id,
    ms_get_carrier_key_for_effective,
    ms_sel_get,
    ms_snapshot_modifier_names,
    ms_promote_new_modifiers_to_instances,
    ms_restore_mode_bridge,
    ms_set_ui_active_index,
    ms_unregister_plugin,
    ms_resolve_modifier_add_targets,
    ms_original_sources_for_stack_targets,
    ms_begin_temporary_stack_target_selection,
    ms_end_temporary_stack_target_selection,
    ms_is_shape_source_object,
    ms_is_shape_mesh_proxy,
    ms_shape_proxy_source,
    ms_get_modifier_stack_object,
    ms_normalize_shape_proxy_visibility_selection,
    safe_move_modifier,
    set_mod_enabled_state,
    set_mod_viewport_state,
    _ms_modifier_set_object_instance_unique,
)
from ...utils import call_operator_safe, get_operator_callable
from ...max_modifier_definitions import (
    iter_max_modifier_definitions,
    max_modifier_group_for_definition,
)
from ..uv_stack_common import make_passthrough_group, unique_name
from .xform_contract import (
    XFORM_COORDINATE_MODES,
    XFORM_GROUP_NODE_NAME_PROP,
    XFORM_GROUP_OWNER_MARKER_PROP,
    XFORM_GROUP_OWNER_MARKER_VALUE,
    XFORM_GROUP_OWNER_TOKEN_PROP,
    XFORM_SCHEMA_VERSION,
    XFormGroupOwnershipRegistry,
    make_unique_row_state,
)
from .linked_xform_backend import make_linked_group, draw_linked, cleanup_linked, forget_session_ownership, CLASSES as LINKED_XFORM_CLASSES
from .normalize_spline_backend import make_normalize_group, draw_normalize, cleanup_normalize, is_verified_normalize_group
from .push_backend import (
    CLASSES as PUSH_CLASSES,
    PUSH_GRAPH_CONTRACT,
    PUSH_GRAPH_CONTRACT_PROP,
    PUSH_GROUP_OWNER_PROP,
    PUSH_GROUP_OWNER_VALUE,
    PUSH_MARKER_PROP,
    PUSH_NODE_GROUP_PROP,
    PUSH_SOCKET_PREFIX,
    after_push_instance_sync,
    after_push_make_unique,
    configure_push_modifier,
    draw_push_properties,
    make_push_group,
    push_skip_copy_props,
)
from .preserve_backend import (
    CLASSES as PRESERVE_CLASSES,
    PRESERVE_GRAPH_CONTRACT_PROP,
    PRESERVE_MARKER_PROP,
    PRESERVE_NODE_GROUP_PROP,
    PRESERVE_SOCKET_PREFIX,
    after_preserve_instance_sync,
    after_preserve_make_unique,
    configure_preserve_modifier,
    draw_preserve_properties,
    is_verified_preserve_group,
    make_preserve_group,
    upgrade_legacy_preserve_modifier,
    preserve_skip_copy_props,
    remove_owned_preserve_selection_if_unused,
)
from .face_extrude_backend import (
    CLASSES as FACE_EXTRUDE_CLASSES,
    FACE_EXTRUDE_MARKER_PROP,
    after_face_extrude_instance_sync,
    after_face_extrude_make_unique,
    capture_face_selection,
    configure_face_extrude_modifier,
    draw_face_extrude_properties,
    face_extrude_after_item_action,
    face_extrude_before_item_action,
    face_extrude_skip_copy_props,
    make_face_extrude_group,
)
from .gizmo_deform_backend import (
    TITLES as GIZMO_DEFORM_TITLES,
    build_gizmo_deform_group,
    effect_axes_text as gizmo_deform_effect_axes_text,
    gizmo_deform_key,
    key_for_group as gizmo_deform_key_for_group,
    socket_table as gizmo_deform_socket_table,
)

PLUGIN_NAMESPACE = 'max_modifier_library'
_NOISE_LOAD_DONE_KEY = '_SMSM_NOISE_REHYDRATED_THIS_LOAD_V1'
MARKER_KEY = '_smsm_max_modifier'
KEY_PROP = 'smsm_max_modifier_key'
BACKEND_PROP = 'smsm_max_modifier_backend'
SOURCE_LABEL_PROP = 'smsm_max_source_label'
CATEGORY_PROP = 'smsm_max_category'
_CATEGORY_JA_PROP = 'smsm_max_category_ja'
_PARAM_PREFIX = 'smsm_param_'
_PARAM_LABELS = {
    'influence': ('Influence', '影響度'),
    'amount': ('Amount', '量'),
    'strength': ('Strength', '強度'),
    'angle': ('Angle', '角度'),
    'segments': ('Segments', 'セグメント'),
    'iterations': ('Iterations', '反復'),
    'tolerance': ('Tolerance', '許容値'),
    'radius': ('Radius', '半径'),
    'width': ('Width', '幅'),
    'height': ('Height', '高さ'),
    'depth': ('Depth', '奥行き'),
    'map_channel': ('Map Channel', 'マップチャンネル'),
    'u_tiling': ('U Tiling', 'U タイル'),
    'v_tiling': ('V Tiling', 'V タイル'),
    'u_offset': ('U Offset', 'U オフセット'),
    'v_offset': ('V Offset', 'V オフセット'),
    'rotation': ('Rotation', '回転'),
    'seed': ('Seed', 'シード'),
    'material_id': ('Material ID', 'マテリアル ID'),
    'preserve_boundaries': ('Preserve Boundaries', '境界を保持'),
    'use_world_space': ('World Space', 'ワールド空間'),
    'translation': ('Translation', '移動'),
    'scale': ('Scale', 'スケール'),
    'center': ('Gizmo Center', 'ギズモ中心'),
    'selection_name': ('Selection Name', '選択名'),
    'preserve_normals': ('Preserve Normals', '法線を保持'),
    'world_pivot_center': ('World Pivot Center', 'ワールドのピボット中心'),
}

_CLASSES = []
_REGISTERED = False


NOISE_GIZMO_TARGET_PROP = 'smsm_noise_target'
NOISE_GIZMO_MODIFIER_PROP = 'smsm_noise_modifier_name'
NOISE_GIZMO_NAME_PROP = 'smsm_noise_gizmo_name'
NOISE_GIZMO_SOCKET_PROP = 'smsm_noise_gizmo_socket'
NOISE_SCALE_SOCKET_PROP = 'smsm_noise_scale_socket'
NOISE_STRENGTH_SOCKET_PROP = 'smsm_noise_strength_socket'
NOISE_PHASE_SOCKET_PROP = 'smsm_noise_phase_socket'
NOISE_SEED_SOCKET_PROP = 'smsm_noise_seed_socket'
NOISE_FRACTAL_SOCKET_PROP = 'smsm_noise_fractal_socket'
NOISE_ROUGHNESS_SOCKET_PROP = 'smsm_noise_roughness_socket'
NOISE_ITERATIONS_SOCKET_PROP = 'smsm_noise_iterations_socket'
NOISE_ANIMATE_SOCKET_PROP = 'smsm_noise_animate_socket'
NOISE_FREQUENCY_SOCKET_PROP = 'smsm_noise_frequency_socket'
NOISE_GRAPH_CONTRACT_PROP = 'smsm_noise_graph_contract'
NOISE_NODE_GROUP_PROP = 'smsm_noise_node_group'
NOISE_HELPER_PROP = 'smsm_noise_helper'
NOISE_PROXY_OWNER_PROP = 'smsm_noise_proxy_owner'
NOISE_COLLECTION_NAME = 'Noise_Collection'
NOISE_NODE_GROUP_PREFIX = 'Smart_Noise_Core'
NOISE_MODIFIER_BASE_NAME = 'Smart Connect Noise'
NOISE_GIZMO_BASE_NAME = 'Smart_Connect_Noise_Gizmo'

GENERIC_GIZMO_TARGET_PROP = 'smsm_generic_target'
GENERIC_GIZMO_MODIFIER_PROP = 'smsm_generic_modifier_name'
GENERIC_GIZMO_NAME_PROP = 'smsm_generic_gizmo_name'
GENERIC_GIZMO_SOCKET_PROP = 'smsm_generic_gizmo_socket'
GENERIC_NODE_GROUP_PROP = 'smsm_generic_node_group'
GENERIC_HELPER_PROP = 'smsm_generic_helper'
GENERIC_PROXY_OWNER_PROP = 'smsm_generic_proxy_owner'
GENERIC_COLLECTION_PROP = 'smsm_generic_collection_name'
GENERIC_KIND_PROP = 'smsm_generic_kind'
GENERIC_NODE_GROUP_PREFIX = 'Smart_Connect_Max_Core'
GENERIC_GIZMO_BASE_PREFIX = 'Smart_Connect_Max_Gizmo'
SKEW_MARKER_PROP = 'smsm_skew_modifier'
SKEW_NODE_GROUP_PROP = 'smsm_skew_node_group'
SKEW_SOCKET_PREFIX = 'smsm_skew_socket_'
SKEW_GRAPH_CONTRACT_PROP = 'smsm_skew_graph_contract'
SQUEEZE_MARKER_PROP = 'smsm_squeeze_modifier'
SQUEEZE_NODE_GROUP_PROP = 'smsm_squeeze_node_group'
SQUEEZE_SOCKET_PREFIX = 'smsm_squeeze_socket_'
SQUEEZE_GRAPH_CONTRACT_PROP = 'smsm_squeeze_graph_contract'
MELT_MARKER_PROP = 'smsm_melt_modifier'
MELT_NODE_GROUP_PROP = 'smsm_melt_node_group'
MELT_SOCKET_PREFIX = 'smsm_melt_socket_'
MELT_GRAPH_CONTRACT_PROP = 'smsm_melt_graph_contract'
AFFECT_REGION_MARKER_PROP = 'smsm_affect_region_modifier'
AFFECT_REGION_NODE_GROUP_PROP = 'smsm_affect_region_node_group'
AFFECT_REGION_SOCKET_PREFIX = 'smsm_affect_region_socket_'
AFFECT_REGION_GRAPH_CONTRACT_PROP = 'smsm_affect_region_graph_contract'
AFFECT_REGION_START_NAME_PROP = 'smsm_affect_region_start_name'
AFFECT_REGION_END_NAME_PROP = 'smsm_affect_region_end_name'
AFFECT_REGION_POINT_ROLE_PROP = 'smsm_affect_region_point_role'

XFORM_SCHEMA_PROP = 'sms_xform_schema_version'
XFORM_OWNER_PROP = 'sms_xform_owner_id'
XFORM_STATE_PROP = 'sms_xform_state_id'
XFORM_SHARED_STATE_PROP = 'sms_xform_shared_state_id'
XFORM_MODE_PROP = 'sms_xform_mode'
XFORM_SUBCONTROL_PROP = 'sms_xform_active_subcontrol'
XFORM_NODE_GROUP_PROP = 'sms_xform_node_group'
XFORM_SOCKET_PREFIX = 'sms_xform_socket_'
_XFORM_GROUP_OWNERSHIP = XFormGroupOwnershipRegistry()
_XFORM_PENDING_GROUP_CAPABILITIES = {}
XFORM_MODES = tuple(sorted(XFORM_COORDINATE_MODES))



def _enum_modifier_types() -> set[str]:
    try:
        prop = bpy.types.Modifier.bl_rna.properties['type']
        return {str(item.identifier) for item in prop.enum_items}
    except Exception:
        return set()


def _modifier_type_available(modifier_type: str) -> bool:
    mt = str(modifier_type or '').strip()
    if not mt:
        return False
    types = _enum_modifier_types()
    return True if not types else mt in types


def _active_object(context):
    try:
        return getattr(context, 'active_object', None)
    except Exception:
        return None


def _selected_objects(context):
    try:
        return list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        return []


def _object_type(obj) -> str:
    try:
        return str(getattr(obj, 'type', '') or '')
    except Exception:
        return ''


def _supported_objects(context, object_types=('MESH',), *, for_execution=False) -> list:
    supported = {str(t) for t in (object_types or ('MESH',)) if str(t)}
    result = []
    seen = set()

    def _accept(obj):
        if obj is None:
            return
        try:
            main = get_main_object(obj) or obj
        except Exception:
            main = obj
        target = main
        try:
            if 'MESH' in supported and ms_is_shape_source_object(main):
                # Poll/UI drawing must not create data, but execute paths do.
                resolved = ms_resolve_modifier_add_targets([main], context=context, create_shape_proxies=bool(for_execution), migrate=True)
                if resolved:
                    target = resolved[0]
                elif not for_execution:
                    # Enable the button for shape sources; execute will create the proxy.
                    target = main
        except Exception:
            target = main
        name = str(getattr(target, 'name', '') or '')
        if not name or name in seen:
            return
        target_type = _object_type(target)
        main_type = _object_type(main)
        eligible = (not supported or target_type in supported)
        if (not eligible) and (not for_execution) and ('MESH' in supported) and main_type in {'CURVE', 'FONT', 'SURFACE'}:
            eligible = True
        if not eligible:
            return
        if not hasattr(target, 'modifiers'):
            return
        seen.add(name)
        result.append(target)

    for obj in _selected_objects(context):
        _accept(obj)
    if not result:
        _accept(_active_object(context))
    return result


def _capture_mode(context):
    try:
        return str(getattr(context, 'mode', '') or '')
    except Exception:
        return ''


def _ensure_object_mode():
    try:
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
    except Exception:
        pass


def _restore_mode(context, mode: str, active_name: str = ''):
    if not str(mode or '').startswith('EDIT'):
        return
    try:
        obj = bpy.data.objects.get(active_name) if active_name else _active_object(context)
        if obj is not None:
            context.view_layer.objects.active = obj
            obj.select_set(True)
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
    except Exception:
        pass


def _try_set_attr(obj: Any, attr: str, value: Any) -> bool:
    if obj is None or not attr:
        return False
    candidates = [value]
    if isinstance(value, tuple):
        candidates.append(list(value))
    elif isinstance(value, list):
        candidates.append(tuple(value))
    for candidate in candidates:
        try:
            setattr(obj, attr, candidate)
            return True
        except Exception:
            pass
    return False


def _try_set_prop_or_attr(mod, attr: str, value: Any) -> bool:
    if _try_set_attr(mod, attr, value):
        return True
    try:
        mod[attr] = value
        return True
    except Exception:
        try:
            mod[attr] = list(value) if isinstance(value, tuple) else value
            return True
        except Exception:
            return False


def _make_texture_for_modifier(mod, obj, defn, texture_type: str):
    texture_type = str(texture_type or '').strip().upper()
    if not texture_type:
        return None
    try:
        tex_name = unique_name(f"SMS Max {defn.get('label', 'Modifier')} Texture - {getattr(obj, 'name', 'Object')}", bpy.data.textures)
        tex = bpy.data.textures.new(tex_name, type=texture_type)
        try:
            mod.texture = tex
        except Exception:
            pass
        return tex
    except Exception:
        return None


def _apply_modifier_defaults(mod, obj, defn):
    props = dict(defn.get('properties') or {})
    texture_type = props.pop('_texture_type', '')
    if texture_type:
        _make_texture_for_modifier(mod, obj, defn, texture_type)
    for attr, value in props.items():
        _try_set_prop_or_attr(mod, attr, value)
    try:
        mtype = str(getattr(mod, 'type', '') or '')
        if mtype == 'BEVEL':
            _try_set_prop_or_attr(mod, 'show_on_cage', True)
        elif mtype == 'MIRROR':
            _try_set_prop_or_attr(mod, 'use_clip', True)
        elif mtype == 'SOLIDIFY':
            _try_set_prop_or_attr(mod, 'use_quality_normals', True)
        elif mtype == 'SUBSURF':
            _try_set_prop_or_attr(mod, 'quality', 3)
        elif mtype == 'WELD':
            _try_set_prop_or_attr(mod, 'mode', 'CONNECTED')
    except Exception:
        pass


def _socket_by_name(sockets, names=(), index=0):
    names = tuple(str(n or '') for n in (names or ()) if str(n or ''))
    for name in names:
        try:
            s = sockets.get(name)
            if s is not None:
                return s
        except Exception:
            pass
    try:
        for s in sockets:
            if str(getattr(s, 'name', '') or '') in names:
                return s
    except Exception:
        pass
    try:
        return sockets[int(index)]
    except Exception:
        return None


def _socket_type_from_node_socket(socket, fallback: str) -> str:
    try:
        value = str(getattr(socket, 'bl_socket_idname', '') or '')
        if value:
            return value
    except Exception:
        pass
    return str(fallback or 'NodeSocketFloat')


def _add_interface_socket(group, *, name: str, in_out: str, socket_type: str, default=None, description: str = ''):
    socket = None
    try:
        socket = group.interface.new_socket(name=str(name), in_out=str(in_out), socket_type=str(socket_type))
        if description:
            try:
                socket.description = str(description)
            except Exception:
                pass
        if default is not None:
            try:
                socket.default_value = default
            except Exception:
                pass
        return socket
    except Exception:
        pass
    try:
        collection = group.inputs if str(in_out).upper() == 'INPUT' else group.outputs
        socket = collection.new(str(socket_type), str(name))
        if description:
            try:
                socket.description = str(description)
            except Exception:
                pass
        if default is not None:
            try:
                socket.default_value = default
            except Exception:
                pass
        return socket
    except Exception:
        return None


def _make_legacy_trs_group(obj, defn, context=None):
    """Preserve the pre-generation TRS graph for non-target rows sharing the backend."""
    name = unique_name(f"SMS Max {defn.get('label', 'Transform')} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        group.is_modifier = True
        transform = group.nodes.new('GeometryNodeTransform')
        group_input = group.nodes.new('NodeGroupInput')
        group_output = group.nodes.new('NodeGroupOutput')
        geometry_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        translation_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Translation',), 1), 'NodeSocketVector')
        rotation_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Rotation',), 2), 'NodeSocketVector')
        scale_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Scale',), 3), 'NodeSocketVector')
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type)
        _add_interface_socket(group, name='Translation', in_out='INPUT', socket_type=translation_type, default=(0.0, 0.0, 0.0))
        _add_interface_socket(group, name='Rotation', in_out='INPUT', socket_type=rotation_type, default=(0.0, 0.0, 0.0))
        _add_interface_socket(group, name='Scale', in_out='INPUT', socket_type=scale_type, default=(1.0, 1.0, 1.0))
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=geometry_type)
        group.links.new(_socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(transform.inputs, ('Geometry',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Translation',), 1), _socket_by_name(transform.inputs, ('Translation',), 1))
        group.links.new(_socket_by_name(group_input.outputs, ('Rotation',), 2), _socket_by_name(transform.inputs, ('Rotation',), 2))
        group.links.new(_socket_by_name(group_input.outputs, ('Scale',), 3), _socket_by_name(transform.inputs, ('Scale',), 3))
        group.links.new(_socket_by_name(transform.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))
        return group
    except Exception:
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _make_xform_group(obj, defn, context=None):
    if str((defn or {}).get('key') or '') != 'xform_modifier':
        return _make_legacy_trs_group(obj, defn, context=context)
    name = unique_name(f"SMS Max {defn.get('label', 'XForm')} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        try:
            group.is_modifier = True
        except Exception:
            pass
        try:
            group.nodes.clear()
        except Exception:
            pass
        group_input = group.nodes.new('NodeGroupInput')
        group_output = group.nodes.new('NodeGroupOutput')
        named_selection = group.nodes.new('GeometryNodeInputNamedAttribute')
        named_selection.data_type = 'BOOLEAN'
        choose_selection = group.nodes.new('GeometryNodeSwitch')
        choose_selection.input_type = 'BOOLEAN'
        source_position = group.nodes.new('GeometryNodeInputPosition')
        source_normal = group.nodes.new('GeometryNodeInputNormal')
        try:
            source_normal.legacy_corner_normals = False
        except Exception:
            pass
        capture_normal = group.nodes.new('GeometryNodeCaptureAttribute')
        capture_normal.domain = 'CORNER'
        try:
            capture_normal.capture_items.clear()
        except Exception:
            pass
        # capture_items.new takes a socket type, not Attribute.data_type.
        capture_normal.capture_items.new('VECTOR', 'XForm Source Normal')
        negate_center = group.nodes.new('ShaderNodeVectorMath')
        negate_center.operation = 'SCALE'
        _socket_by_name(negate_center.inputs, ('Scale',), 3).default_value = -1.0
        self_object = group.nodes.new('GeometryNodeSelfObject')
        object_info = group.nodes.new('GeometryNodeObjectInfo')
        reference_info = group.nodes.new('GeometryNodeObjectInfo')
        try:
            object_info.transform_space = 'ORIGINAL'
            reference_info.transform_space = 'ORIGINAL'
        except Exception:
            pass
        identity_matrix = group.nodes.new('FunctionNodeCombineTransform')
        channels_matrix = group.nodes.new('FunctionNodeCombineTransform')
        center_matrix = group.nodes.new('FunctionNodeCombineTransform')
        negative_center_matrix = group.nodes.new('FunctionNodeCombineTransform')
        invert_object = group.nodes.new('FunctionNodeInvertMatrix')
        reference_basis = group.nodes.new('FunctionNodeMatrixMultiply')
        basis_switch = group.nodes.new('GeometryNodeIndexSwitch')
        basis_switch.data_type = 'MATRIX'
        while len(basis_switch.index_switch_items) < 4:
            basis_switch.index_switch_items.new()
        invert_basis = group.nodes.new('FunctionNodeInvertMatrix')
        center_channels = group.nodes.new('FunctionNodeMatrixMultiply')
        centered_matrix = group.nodes.new('FunctionNodeMatrixMultiply')
        basis_centered = group.nodes.new('FunctionNodeMatrixMultiply')
        full_matrix = group.nodes.new('FunctionNodeMatrixMultiply')
        world_mode = group.nodes.new('FunctionNodeCompare')
        world_mode.data_type = 'INT'
        world_mode.operation = 'EQUAL'
        _socket_by_name(world_mode.inputs, ('B',), 3).default_value = 2
        invert_world_pivot = group.nodes.new('FunctionNodeBooleanMath')
        invert_world_pivot.operation = 'NOT'
        use_world_origin = group.nodes.new('FunctionNodeBooleanMath')
        use_world_origin.operation = 'AND'
        world_center = group.nodes.new('FunctionNodeTransformPoint')
        center_switch = group.nodes.new('GeometryNodeSwitch')
        center_switch.input_type = 'VECTOR'
        transform_position = group.nodes.new('FunctionNodeTransformPoint')
        set_position = group.nodes.new('GeometryNodeSetPosition')
        invert_xform = group.nodes.new('FunctionNodeInvertMatrix')
        transpose_inverse = group.nodes.new('FunctionNodeTransposeMatrix')
        transform_normal = group.nodes.new('FunctionNodeTransformDirection')
        normalize_normal = group.nodes.new('ShaderNodeVectorMath')
        normalize_normal.operation = 'NORMALIZE'
        normal_selection = group.nodes.new('FunctionNodeBooleanMath')
        normal_selection.operation = 'AND'
        set_mesh_normal = group.nodes.new('GeometryNodeSetMeshNormal')
        set_mesh_normal.mode = 'FREE'
        set_mesh_normal.domain = 'CORNER'
        # FREE mode exposes Mesh and Custom Normal, not a Selection socket.
        choose_normal = group.nodes.new('GeometryNodeSwitch')
        choose_normal.input_type = 'VECTOR'
        group_input.location = (-1650, 80)
        named_selection.location = (-1650, -260)
        choose_selection.location = (-1400, -160)
        source_position.location = (-900, 500)
        source_normal.location = (-1650, 700)
        capture_normal.location = (-900, 160)
        object_info.location = (-1400, -620)
        reference_info.location = (-1400, -780)
        basis_switch.location = (-720, -560)
        channels_matrix.location = (-900, -160)
        full_matrix.location = (-240, -260)
        transform_position.location = (0, 420)
        set_position.location = (240, 180)
        transform_normal.location = (0, -40)
        set_mesh_normal.location = (500, 120)
        group_output.location = (760, 120)
        try:
            group_output.is_active_output = True
        except Exception:
            pass
        geometry_type = _socket_type_from_node_socket(_socket_by_name(set_position.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        translation_type = _socket_type_from_node_socket(_socket_by_name(channels_matrix.inputs, ('Translation',), 0), 'NodeSocketVector')
        rotation_type = _socket_type_from_node_socket(_socket_by_name(channels_matrix.inputs, ('Rotation',), 1), 'NodeSocketVector')
        scale_type = _socket_type_from_node_socket(_socket_by_name(channels_matrix.inputs, ('Scale',), 2), 'NodeSocketVector')
        out_type = _socket_type_from_node_socket(_socket_by_name(set_mesh_normal.outputs, ('Mesh', 'Geometry'), 0), 'NodeSocketGeometry')
        sockets = {}
        sockets['geometry'] = _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type, description=choose_text('Evaluated incoming geometry at this exact stack position.', 'このスタック位置で評価された入力ジオメトリです。', context=context))
        sockets['translation'] = _add_interface_socket(group, name='Translation', in_out='INPUT', socket_type=translation_type, default=(0.0, 0.0, 0.0), description=choose_text('Animatable XForm translation.', 'アニメーション可能な XForm 移動量です。', context=context))
        sockets['rotation'] = _add_interface_socket(group, name='Rotation', in_out='INPUT', socket_type=rotation_type, default=(0.0, 0.0, 0.0), description=choose_text('Animatable XForm rotation in radians.', 'アニメーション可能な XForm 回転量（ラジアン）です。', context=context))
        sockets['scale'] = _add_interface_socket(group, name='Scale', in_out='INPUT', socket_type=scale_type, default=(1.0, 1.0, 1.0), description=choose_text('Animatable XForm scale.', 'アニメーション可能な XForm スケールです。', context=context))
        sockets['center'] = _add_interface_socket(group, name='Gizmo Center', in_out='INPUT', socket_type='NodeSocketVector', default=(0.0, 0.0, 0.0), description=choose_text('Independent center used for rotation and scale.', '回転とスケールに使う独立した中心です。', context=context))
        sockets['use_named_selection'] = _add_interface_socket(group, name='Use Named Selection', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Transform only the incoming named selection.', '入力された名前付き選択だけを変形します。', context=context))
        sockets['selection_name'] = _add_interface_socket(group, name='Selection Name', in_out='INPUT', socket_type='NodeSocketString', default='', description=choose_text('Vertex group or named Boolean selection passed up the stack.', 'スタックを上がって渡される頂点グループまたは名前付き Boolean 選択です。', context=context))
        sockets['coordinate_mode'] = _add_interface_socket(group, name='Coordinate Mode', in_out='INPUT', socket_type='NodeSocketInt', default=0, description=choose_text('0 Gizmo, 1 Local, 2 World, 3 Reference Object.', '0 ギズモ、1 ローカル、2 ワールド、3 参照オブジェクトです。', context=context))
        sockets['reference_object'] = _add_interface_socket(group, name='Reference Object', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Explicit coordinate reference for Reference Object mode.', '参照オブジェクトモードで使う明示的な座標参照です。', context=context))
        sockets['world_pivot_center'] = _add_interface_socket(group, name='World Pivot Center', in_out='INPUT', socket_type='NodeSocketBool', default=True, description=choose_text('Use the 3ds Max-compatible pivot center in World mode.', 'ワールドモードで 3ds Max 互換のピボット中心を使います。', context=context))
        sockets['preserve_normals'] = _add_interface_socket(group, name='Preserve Normals', in_out='INPUT', socket_type='NodeSocketBool', default=True, description=choose_text('Request inverse-transpose normal preservation where Blender retains custom normals.', 'Blender がカスタム法線を保持できる範囲で逆転置による法線保持を要求します。', context=context))
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=out_type, description=choose_text('Output geometry.', '出力ジオメトリです。', context=context))
        group.links.new(_socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(capture_normal.inputs, ('Geometry',), 0))
        group.links.new(_socket_by_name(source_normal.outputs, ('Normal',), 0), _socket_by_name(capture_normal.inputs, ('XForm Source Normal',), 1))
        group.links.new(_socket_by_name(group_input.outputs, ('Selection Name',), 6), _socket_by_name(named_selection.inputs, ('Name',), 0))
        _socket_by_name(choose_selection.inputs, ('False',), 1).default_value = True
        group.links.new(_socket_by_name(group_input.outputs, ('Use Named Selection',), 5), _socket_by_name(choose_selection.inputs, ('Switch',), 0))
        group.links.new(_socket_by_name(named_selection.outputs, ('Attribute',), 0), _socket_by_name(choose_selection.inputs, ('True',), 2))
        group.links.new(_socket_by_name(self_object.outputs, ('Self Object', 'Object'), 0), _socket_by_name(object_info.inputs, ('Object',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Reference Object',), 8), _socket_by_name(reference_info.inputs, ('Object',), 0))
        group.links.new(_socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(invert_object.inputs, (), 0))
        group.links.new(_socket_by_name(invert_object.outputs, (), 0), _socket_by_name(reference_basis.inputs, (), 0))
        group.links.new(_socket_by_name(reference_info.outputs, ('Transform',), 4), _socket_by_name(reference_basis.inputs, (), 1))
        group.links.new(_socket_by_name(group_input.outputs, ('Coordinate Mode',), 7), _socket_by_name(basis_switch.inputs, ('Index',), 0))
        group.links.new(_socket_by_name(identity_matrix.outputs, ('Transform', 'Matrix'), 0), _socket_by_name(basis_switch.inputs, (), 1))
        group.links.new(_socket_by_name(identity_matrix.outputs, ('Transform', 'Matrix'), 0), _socket_by_name(basis_switch.inputs, (), 2))
        group.links.new(_socket_by_name(invert_object.outputs, (), 0), _socket_by_name(basis_switch.inputs, (), 3))
        group.links.new(_socket_by_name(reference_basis.outputs, (), 0), _socket_by_name(basis_switch.inputs, (), 4))
        group.links.new(_socket_by_name(basis_switch.outputs, (), 0), _socket_by_name(invert_basis.inputs, (), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Coordinate Mode',), 7), _socket_by_name(world_mode.inputs, ('A',), 2))
        group.links.new(_socket_by_name(group_input.outputs, ('World Pivot Center',), 9), _socket_by_name(invert_world_pivot.inputs, (), 0))
        group.links.new(_socket_by_name(world_mode.outputs, ('Result',), 0), _socket_by_name(use_world_origin.inputs, (), 0))
        group.links.new(_socket_by_name(invert_world_pivot.outputs, ('Boolean',), 0), _socket_by_name(use_world_origin.inputs, (), 1))
        group.links.new(_socket_by_name(group_input.outputs, ('Gizmo Center',), 4), _socket_by_name(world_center.inputs, ('Point', 'Vector'), 0))
        group.links.new(_socket_by_name(invert_object.outputs, (), 0), _socket_by_name(world_center.inputs, ('Transform', 'Matrix'), 1))
        group.links.new(_socket_by_name(use_world_origin.outputs, ('Boolean',), 0), _socket_by_name(center_switch.inputs, ('Switch',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Gizmo Center',), 4), _socket_by_name(center_switch.inputs, ('False',), 1))
        group.links.new(_socket_by_name(world_center.outputs, ('Point', 'Vector'), 0), _socket_by_name(center_switch.inputs, ('True',), 2))
        group.links.new(_socket_by_name(center_switch.outputs, ('Output',), 0), _socket_by_name(negate_center.inputs, ('Vector',), 0))
        group.links.new(_socket_by_name(center_switch.outputs, ('Output',), 0), _socket_by_name(center_matrix.inputs, ('Translation',), 0))
        group.links.new(_socket_by_name(negate_center.outputs, ('Vector',), 0), _socket_by_name(negative_center_matrix.inputs, ('Translation',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Translation',), 1), _socket_by_name(channels_matrix.inputs, ('Translation',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Rotation',), 2), _socket_by_name(channels_matrix.inputs, ('Rotation',), 1))
        group.links.new(_socket_by_name(group_input.outputs, ('Scale',), 3), _socket_by_name(channels_matrix.inputs, ('Scale',), 2))
        group.links.new(_socket_by_name(center_matrix.outputs, ('Transform', 'Matrix'), 0), _socket_by_name(center_channels.inputs, (), 0))
        group.links.new(_socket_by_name(channels_matrix.outputs, ('Transform', 'Matrix'), 0), _socket_by_name(center_channels.inputs, (), 1))
        group.links.new(_socket_by_name(center_channels.outputs, (), 0), _socket_by_name(centered_matrix.inputs, (), 0))
        group.links.new(_socket_by_name(negative_center_matrix.outputs, ('Transform', 'Matrix'), 0), _socket_by_name(centered_matrix.inputs, (), 1))
        group.links.new(_socket_by_name(basis_switch.outputs, (), 0), _socket_by_name(basis_centered.inputs, (), 0))
        group.links.new(_socket_by_name(centered_matrix.outputs, (), 0), _socket_by_name(basis_centered.inputs, (), 1))
        group.links.new(_socket_by_name(basis_centered.outputs, (), 0), _socket_by_name(full_matrix.inputs, (), 0))
        group.links.new(_socket_by_name(invert_basis.outputs, (), 0), _socket_by_name(full_matrix.inputs, (), 1))
        group.links.new(_socket_by_name(source_position.outputs, ('Position',), 0), _socket_by_name(transform_position.inputs, ('Point', 'Vector'), 0))
        group.links.new(_socket_by_name(full_matrix.outputs, (), 0), _socket_by_name(transform_position.inputs, ('Transform', 'Matrix'), 1))
        group.links.new(_socket_by_name(capture_normal.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
        group.links.new(_socket_by_name(choose_selection.outputs, ('Output',), 0), _socket_by_name(set_position.inputs, ('Selection',), 1))
        group.links.new(_socket_by_name(transform_position.outputs, ('Point', 'Vector'), 0), _socket_by_name(set_position.inputs, ('Position',), 2))
        group.links.new(_socket_by_name(full_matrix.outputs, (), 0), _socket_by_name(invert_xform.inputs, (), 0))
        group.links.new(_socket_by_name(invert_xform.outputs, (), 0), _socket_by_name(transpose_inverse.inputs, (), 0))
        group.links.new(_socket_by_name(capture_normal.outputs, ('XForm Source Normal',), 1), _socket_by_name(transform_normal.inputs, ('Direction', 'Vector'), 0))
        group.links.new(_socket_by_name(transpose_inverse.outputs, (), 0), _socket_by_name(transform_normal.inputs, ('Transform', 'Matrix'), 1))
        group.links.new(_socket_by_name(transform_normal.outputs, ('Direction', 'Vector'), 0), _socket_by_name(normalize_normal.inputs, ('Vector',), 0))
        group.links.new(_socket_by_name(group_input.outputs, ('Preserve Normals',), 10), _socket_by_name(normal_selection.inputs, (), 0))
        group.links.new(_socket_by_name(choose_selection.outputs, ('Output',), 0), _socket_by_name(normal_selection.inputs, (), 1))
        group.links.new(_socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(set_mesh_normal.inputs, ('Mesh', 'Geometry'), 0))
        group.links.new(normal_selection.outputs['Boolean'], choose_normal.inputs['Switch'])
        group.links.new(source_normal.outputs['Normal'], choose_normal.inputs['False'])
        group.links.new(normalize_normal.outputs['Vector'], choose_normal.inputs['True'])
        group.links.new(choose_normal.outputs['Output'], set_mesh_normal.inputs['Custom Normal'])
        group.links.new(_socket_by_name(set_mesh_normal.outputs, ('Mesh', 'Geometry'), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))
        if _ensure_xform_gizmo_nodes(group, context=context) is None:
            raise RuntimeError('XForm Gizmo/Center sub-control wiring failed')
        group[XFORM_SCHEMA_PROP] = int(XFORM_SCHEMA_VERSION)
        group['sms_xform_coordinate_modes'] = ','.join(XFORM_MODES)
        group['sms_xform_graph_contract'] = 'matrix_covector_preserve_normals_v3'
        for key, socket in sockets.items():
            group[XFORM_SOCKET_PREFIX + key] = str(getattr(socket, 'identifier', '') or '')
        if _mint_xform_group_ownership(group) is None:
            raise RuntimeError('Could not mint trusted XForm group ownership')
        return group
    except Exception as exc:
        # Never present a failed dedicated XForm as a successful identity graph.
        # Only the fresh, unassigned group from this call may be removed.
        failed_group = locals().get('group')
        if failed_group is not None and failed_group.users == 0:
            bpy.data.node_groups.remove(failed_group)
        raise RuntimeError('XForm graph construction failed: ' + str(exc)) from exc


# 3ds Max の XForm と同じく、スタックで選んだサブコントロール（Gizmo＝移動・回転・拡大、
# Center＝移動だけ）をビューポートで直接動かせるようにする Geometry Nodes のギズモの配線。
# ギズモの Value は、選んだ方だけをつなぐ（つないでいないギズモは Blender が出さない）。
XFORM_SUBCTL_PREFIX = 'SMS XForm SubCtl '
XFORM_GIZMO_NODE = XFORM_SUBCTL_PREFIX + 'Gizmo'
XFORM_CENTER_GIZMO_NODE = XFORM_SUBCTL_PREFIX + 'Center'
XFORM_CENTER_VALUE_NODE = XFORM_SUBCTL_PREFIX + 'Center Value'
_XFORM_SUBCTL_NODES = (
    XFORM_GIZMO_NODE, XFORM_CENTER_GIZMO_NODE, XFORM_CENTER_VALUE_NODE,
    XFORM_SUBCTL_PREFIX + 'Gizmo Position', XFORM_SUBCTL_PREFIX + 'Gizmo Space',
    XFORM_SUBCTL_PREFIX + 'Offset', XFORM_SUBCTL_PREFIX + 'Identity',
    XFORM_SUBCTL_PREFIX + 'Pivot Space', XFORM_SUBCTL_PREFIX + 'Offset Space',
    XFORM_SUBCTL_PREFIX + 'Center Space Matrix', XFORM_SUBCTL_PREFIX + 'Center Space',
    XFORM_SUBCTL_PREFIX + 'Join',
)


def _xform_link_source(socket):
    try:
        if socket is not None and socket.is_linked:
            return socket.links[0].from_socket
    except Exception:
        pass
    return None


def _xform_core_nodes(group):
    """XForm のグラフ（契約 v3）から、ギズモの配線に使う元のノードを形で探す。"""
    try:
        nodes = group.nodes
        group_input = next((n for n in nodes if n.bl_idname == 'NodeGroupInput'), None)
        outputs = [n for n in nodes if n.bl_idname == 'NodeGroupOutput']
        group_output = next((n for n in outputs if getattr(n, 'is_active_output', False)), outputs[0] if outputs else None)
        normals = [n for n in nodes if n.bl_idname == 'GeometryNodeSetMeshNormal']
        bases = [n for n in nodes if n.bl_idname == 'GeometryNodeIndexSwitch' and str(getattr(n, 'data_type', '')) == 'MATRIX']
        if group_input is None or group_output is None or len(normals) != 1 or len(bases) != 1:
            return None

        def from_input(socket, name):
            src = _xform_link_source(socket)
            return src is not None and src.node == group_input and str(src.name) == name

        channels = [n for n in nodes if n.bl_idname == 'FunctionNodeCombineTransform'
                    and not str(n.name).startswith(XFORM_SUBCTL_PREFIX)
                    and from_input(n.inputs['Translation'], 'Translation')
                    and from_input(n.inputs['Rotation'], 'Rotation')
                    and from_input(n.inputs['Scale'], 'Scale')]
        centers = [n for n in nodes if n.bl_idname == 'GeometryNodeSwitch' and str(getattr(n, 'input_type', '')) == 'VECTOR'
                   and from_input(n.inputs['False'], 'Gizmo Center')]
        if len(channels) != 1 or len(centers) != 1:
            return None
        use_world_origin = _xform_link_source(centers[0].inputs['Switch'])
        invert_object = _xform_link_source(bases[0].inputs[3])
        if use_world_origin is None or invert_object is None:
            return None
        return {
            'input': group_input, 'output': group_output, 'normal': normals[0], 'basis': bases[0],
            'channels': channels[0], 'center': centers[0],
            'use_world_origin': use_world_origin, 'invert_object': invert_object,
        }
    except (AttributeError, KeyError, IndexError, TypeError, ReferenceError):
        return None


def _ensure_xform_gizmo_nodes(group, context=None):
    """Gizmo（移動・回転・拡大）と Center（移動）のギズモを XForm のグラフに配線する。

    描く位置はメッシュの式 p' = B·C·TRS·C⁻¹·B⁻¹·p に合わせる（B は座標モードの基底）。
    Gizmo は中心が移動した先 c+t に、Center は移動後のピボット（B·T(t)·S·g、S はワールドの
    原点ピボットの時だけ Obj⁻¹）に出す。ギズモの Transform 出力を同じ行列で動かしてから
    メッシュと Join するので、ドラッグの量はそのまま Translation・Rotation・Scale・
    Gizmo Center の入力へ書き戻る。古い版のグラフ（つながっていないギズモが 1 つだけ）も
    ここで同じ形へ直す。戻り値は (Gizmo, Center) か None。
    """
    if group is None or getattr(group, 'bl_idname', '') != 'GeometryNodeTree':
        return None
    if getattr(group, 'library', None) is not None:
        return None
    try:
        nodes = group.nodes
        found = {name: nodes.get(name) for name in _XFORM_SUBCTL_NODES}
        if all(node is not None for node in found.values()):
            return found[XFORM_GIZMO_NODE], found[XFORM_CENTER_GIZMO_NODE]
        core = _xform_core_nodes(group)
        if core is None:
            return None
        links = group.links
        for node in list(nodes):
            stale_gizmo = node.bl_idname == 'GeometryNodeGizmoTransform' and not any(
                s.is_linked for s in tuple(node.inputs) + tuple(node.outputs))
            if str(node.name) in _XFORM_SUBCTL_NODES or stale_gizmo:
                nodes.remove(node)
        group_input = core['input']
        basis_out = core['basis'].outputs[0]

        def new(idname, suffix, location, label=None):
            node = nodes.new(idname)
            node.name = XFORM_SUBCTL_PREFIX + suffix
            if label:
                node.label = label
            node.location = location
            return node

        gizmo = new('GeometryNodeGizmoTransform', 'Gizmo', (-200, -1000),
                    choose_text('XForm Gizmo (move / rotate / scale)', 'Xフォームのギズモ（移動・回転・拡大）', context=context))
        center = new('GeometryNodeGizmoTransform', 'Center', (-200, -1400),
                     choose_text('XForm Center (move)', 'Xフォームの中心（移動）', context=context))
        for axis in ('x', 'y', 'z'):
            for kind in ('translation', 'rotation', 'scale'):
                setattr(gizmo, f'use_{kind}_{axis}', True)
                setattr(center, f'use_{kind}_{axis}', kind == 'translation')
        position = new('ShaderNodeVectorMath', 'Gizmo Position', (-420, -1000))
        position.operation = 'ADD'
        links.new(_socket_by_name(core['center'].outputs, ('Output',), 0), position.inputs[0])
        links.new(group_input.outputs['Translation'], position.inputs[1])
        links.new(position.outputs[0], gizmo.inputs['Position'])
        links.new(group_input.outputs['Rotation'], gizmo.inputs['Rotation'])
        gizmo_space = new('GeometryNodeTransform', 'Gizmo Space', (40, -1000))
        gizmo_space.inputs['Mode'].default_value = 'Matrix'
        links.new(gizmo.outputs['Transform'], gizmo_space.inputs['Geometry'])
        links.new(basis_out, gizmo_space.inputs['Transform'])
        center_value = new('FunctionNodeCombineTransform', 'Center Value', (-420, -1400))
        links.new(group_input.outputs['Gizmo Center'], center_value.inputs['Translation'])
        links.new(group_input.outputs['Gizmo Center'], center.inputs['Position'])
        offset = new('FunctionNodeCombineTransform', 'Offset', (-640, -1600))
        links.new(group_input.outputs['Translation'], offset.inputs['Translation'])
        identity = new('FunctionNodeCombineTransform', 'Identity', (-640, -1800))
        pivot_space = new('GeometryNodeSwitch', 'Pivot Space', (-420, -1750))
        pivot_space.input_type = 'MATRIX'
        links.new(core['use_world_origin'], pivot_space.inputs['Switch'])
        links.new(identity.outputs[0], pivot_space.inputs['False'])
        links.new(core['invert_object'], pivot_space.inputs['True'])
        offset_space = new('FunctionNodeMatrixMultiply', 'Offset Space', (-420, -1600))
        links.new(basis_out, offset_space.inputs[0])
        links.new(offset.outputs[0], offset_space.inputs[1])
        center_matrix = new('FunctionNodeMatrixMultiply', 'Center Space Matrix', (-200, -1650))
        links.new(offset_space.outputs[0], center_matrix.inputs[0])
        links.new(pivot_space.outputs[0], center_matrix.inputs[1])
        center_space = new('GeometryNodeTransform', 'Center Space', (40, -1400))
        center_space.inputs['Mode'].default_value = 'Matrix'
        links.new(center.outputs['Transform'], center_space.inputs['Geometry'])
        links.new(center_matrix.outputs[0], center_space.inputs['Transform'])
        join = new('GeometryNodeJoinGeometry', 'Join', (620, 120))
        links.new(_socket_by_name(core['normal'].outputs, ('Mesh', 'Geometry'), 0), join.inputs[0])
        links.new(gizmo_space.outputs[0], join.inputs[0])
        links.new(center_space.outputs[0], join.inputs[0])
        links.new(join.outputs[0], _socket_by_name(core['output'].inputs, ('Geometry',), 0))
        try:
            core['output'].location = (840, 120)
        except Exception:
            pass
        group['sms_xform_subcontrol_wiring'] = 1
        return gizmo, center
    except Exception:
        return None


def _xform_group_users(group):
    """このグループを使う Geometry Nodes の行（ほかの物体の行も含む）。"""
    users = []
    for obj in tuple(bpy.data.objects):
        for m in tuple(getattr(obj, 'modifiers', ())):
            try:
                if m.type == 'NODES' and m.node_group == group:
                    users.append(m)
            except (AttributeError, ReferenceError):
                continue
    return users


def _xform_extra_keys_snapshot(mod, group):
    """入力の値以外のキー（行の印 sms_* など）を写す。

    グループの中のつなぎを変えると、Blender はそのグループを使う行の ID プロパティを
    入力の値だけに作り直し、行の印を落とす（実測：58 個 → 26 個、sms_* は 21 個 → 0 個）。
    """
    socket_keys = set()
    try:
        for item in group.interface.items_tree:
            if getattr(item, 'item_type', '') == 'SOCKET' and getattr(item, 'in_out', '') == 'INPUT':
                sid = str(item.identifier)
                socket_keys.update((sid, sid + '_use_attribute', sid + '_attribute_name'))
    except (AttributeError, ReferenceError):
        return {}
    snap = {}
    for key in list(mod.keys()):
        if key in socket_keys:
            continue
        try:
            value = mod[key]
            if hasattr(value, 'to_dict'):
                value = value.to_dict()
            elif hasattr(value, 'to_list'):
                value = value.to_list()
            snap[key] = value
        except (KeyError, TypeError, AttributeError, ReferenceError):
            continue
    return snap


def _xform_restore_extra_keys(mod, snap) -> int:
    restored = 0
    for key, value in (snap or {}).items():
        try:
            if key not in mod:
                mod[key] = value
                restored += 1
        except (TypeError, ValueError, KeyError, AttributeError, ReferenceError):
            continue
    return restored


def _apply_xform_subcontrol(mod, group=None, context=None) -> bool:
    """行のサブコントロール（GIZMO／CENTER）に合わせて、ギズモの Value を 1 つだけつなぐ。"""
    if mod is None:
        return False
    group = group or getattr(mod, 'node_group', None)
    if _saved_xform_sockets(group) is None:
        return False
    # 印はつなぎ替えで消えるので、先に読み、写してから付け替える。
    choice = str(mod.get(XFORM_SUBCONTROL_PROP, 'GIZMO') or 'GIZMO').upper()
    if choice not in {'GIZMO', 'CENTER'}:
        choice = 'GIZMO'
    users = _xform_group_users(group)
    if mod not in users:
        users.append(mod)
    snaps = [(m, _xform_extra_keys_snapshot(m, group)) for m in users]
    try:
        pair = _ensure_xform_gizmo_nodes(group, context=context)
        core = _xform_core_nodes(group) if pair is not None else None
        center_value = group.nodes.get(XFORM_CENTER_VALUE_NODE) if core is not None else None
        if center_value is None:
            return False
        plan = (
            (pair[0], core['channels'].outputs[0], choice == 'GIZMO'),
            (pair[1], center_value.outputs[0], choice == 'CENTER'),
        )
        for node, source, wanted in plan:
            socket = node.inputs['Value']
            current = list(socket.links)
            if wanted and len(current) == 1 and current[0].from_socket == source:
                continue
            if not wanted and not current:
                continue
            for link in current:
                group.links.remove(link)
            if wanted:
                group.links.new(source, socket)
    finally:
        for m, snap in snaps:
            _xform_restore_extra_keys(m, snap)
    # グループを分け合う行（インスタンス）は、つなぎも分け合うので印をそろえる。
    for m in users:
        try:
            if m.get('sms_xform_modifier', False):
                m[XFORM_SUBCONTROL_PROP] = choice
        except (TypeError, AttributeError, ReferenceError):
            continue
    return True


def _xform_socket(group, key: str, fallback_name: str):
    if group is None:
        return None
    stored = ''
    try:
        stored = str(group.get(XFORM_SOCKET_PREFIX + str(key), '') or '')
    except Exception:
        pass
    return _find_interface_socket(group, stored or fallback_name, 'INPUT')


def _mint_xform_group_ownership(group):
    capability = _XFORM_GROUP_OWNERSHIP.mint(group)
    if capability is not None:
        _XFORM_PENDING_GROUP_CAPABILITIES[id(group)] = (group, capability)
    return capability


def _bind_xform_group_ownership(mod, group) -> bool:
    if mod is None or group is None:
        return False
    pending = _XFORM_PENDING_GROUP_CAPABILITIES.pop(id(group), None)
    if pending is not None and pending[0] is group:
        return _XFORM_GROUP_OWNERSHIP.bind_minted(group, mod, pending[1])
    return _XFORM_GROUP_OWNERSHIP.is_owned(group, mod)


def _is_trusted_owned_xform_group(group, mod) -> bool:
    return _XFORM_GROUP_OWNERSHIP.is_owned(group, mod)


def _forget_xform_group_ownership(group) -> None:
    _XFORM_PENDING_GROUP_CAPABILITIES.pop(id(group), None)
    _XFORM_GROUP_OWNERSHIP.forget(group)


def _release_xform_row(mod) -> None:
    _XFORM_GROUP_OWNERSHIP.release_row(mod)


def _ensure_xform_row_state(mod) -> None:
    if mod is None:
        return
    try:
        previous_schema = int(mod.get(XFORM_SCHEMA_PROP, 0) or 0)
    except Exception:
        previous_schema = 0
    try:
        if XFORM_OWNER_PROP not in mod:
            mod[XFORM_OWNER_PROP] = uuid.uuid4().hex
        if XFORM_STATE_PROP not in mod:
            mod[XFORM_STATE_PROP] = uuid.uuid4().hex
        if XFORM_SHARED_STATE_PROP not in mod:
            mod[XFORM_SHARED_STATE_PROP] = ''
        if XFORM_MODE_PROP not in mod:
            legacy_world = bool(mod.get(_param_id('use_world_space'), False))
            mod[XFORM_MODE_PROP] = 'WORLD' if legacy_world else 'GIZMO'
        if XFORM_SUBCONTROL_PROP not in mod:
            mod[XFORM_SUBCONTROL_PROP] = 'GIZMO'
        mod[XFORM_SCHEMA_PROP] = int(XFORM_SCHEMA_VERSION)
        mod['sms_xform_selection_source'] = str(mod.get('sms_xform_selection_source', 'WHOLE_GEOMETRY') or 'WHOLE_GEOMETRY')
        mod['sms_xform_reference_object'] = str(mod.get('sms_xform_reference_object', '') or '')
        mod['sms_xform_migrated_from_schema'] = int(previous_schema)
    except Exception:
        pass


def _configure_xform_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    group = group or getattr(mod, 'node_group', None)
    if group is None:
        return None
    migration_values = {}
    migrated_group_from_schema = None
    migration_specs = {
        'translation': 'Translation',
        'rotation': 'Rotation',
        'scale': 'Scale',
        'center': 'Gizmo Center',
        'use_named_selection': 'Use Named Selection',
        'selection_name': 'Selection Name',
        'coordinate_mode': 'Coordinate Mode',
        'reference_object': 'Reference Object',
        'world_pivot_center': 'World Pivot Center',
        'preserve_normals': 'Preserve Normals',
    }
    try:
        group_schema = int(group.get(XFORM_SCHEMA_PROP, 0) or 0)
    except Exception:
        group_schema = 0
    if group_schema < int(XFORM_SCHEMA_VERSION):
        previous_group = group
        previous_group_owned = _is_trusted_owned_xform_group(previous_group, mod)
        for key, fallback in migration_specs.items():
            try:
                old_socket = _xform_socket(previous_group, key, fallback)
                old_sid = str(getattr(old_socket, 'identifier', '') or '')
                if old_sid and old_sid in list(mod.keys()):
                    migration_values[key] = mod[old_sid]
            except Exception:
                pass
        try:
            replacement = _make_xform_group(
                obj,
                defn or {'key': 'xform_modifier', 'label': 'XForm', 'backend': 'xform_nodes'},
                context=context,
            )
            if replacement is not None and int(replacement.get(XFORM_SCHEMA_PROP, 0) or 0) == int(XFORM_SCHEMA_VERSION):
                mod.node_group = replacement
                group = replacement
                migrated_group_from_schema = int(group_schema)
                try:
                    if previous_group_owned and int(getattr(previous_group, 'users', 0) or 0) == 0:
                        _forget_xform_group_ownership(previous_group)
                        bpy.data.node_groups.remove(previous_group)
                except Exception:
                    pass
        except Exception:
            group = previous_group
    try:
        if force_unique_group or int(getattr(group, 'users', 0) or 0) > 1:
            group = group.copy()
            group.name = unique_name(f"SMS Max XForm - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
            if _mint_xform_group_ownership(group) is None:
                raise RuntimeError('Could not mint copied XForm group ownership')
            mod.node_group = group
    except Exception:
        pass
    _bind_xform_group_ownership(mod, group)
    _ensure_xform_row_state(mod)
    defaults = {
        'translation': ('Translation', (0.0, 0.0, 0.0)),
        'rotation': ('Rotation', (0.0, 0.0, 0.0)),
        'scale': ('Scale', (1.0, 1.0, 1.0)),
        'center': ('Gizmo Center', (0.0, 0.0, 0.0)),
        'use_named_selection': ('Use Named Selection', False),
        'selection_name': ('Selection Name', ''),
        'coordinate_mode': ('Coordinate Mode', 0),
        'world_pivot_center': ('World Pivot Center', True),
        'preserve_normals': ('Preserve Normals', True),
    }
    for key, (fallback, default) in defaults.items():
        socket = _xform_socket(group, key, fallback)
        try:
            sid = str(getattr(socket, 'identifier', '') or '')
            if sid and sid not in list(mod.keys()):
                _set_modifier_socket_value(mod, socket, default)
            if sid:
                mod[XFORM_SOCKET_PREFIX + key] = sid
        except Exception:
            pass
    for key, value in migration_values.items():
        try:
            _set_modifier_socket_value(mod, _xform_socket(group, key, migration_specs[key]), value)
        except Exception:
            pass
    try:
        ref_socket = _xform_socket(group, 'reference_object', 'Reference Object')
        ref_sid = str(getattr(ref_socket, 'identifier', '') or '')
        if ref_sid:
            mod[XFORM_SOCKET_PREFIX + 'reference_object'] = ref_sid
        mod[XFORM_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[BACKEND_PROP] = 'xform_nodes'
        mod['sms_xform_modifier'] = True
        if migrated_group_from_schema is not None:
            mod['sms_xform_group_migrated_from_schema'] = int(migrated_group_from_schema)
    except Exception:
        pass
    try:
        _apply_xform_subcontrol(mod, group, context=context)
    except Exception:
        pass
    return group


def _xform_set_mode_value(mod, mode: str) -> None:
    normalized = str(mode or 'GIZMO').upper()
    if normalized not in XFORM_COORDINATE_MODES:
        normalized = 'GIZMO'
    mod[XFORM_MODE_PROP] = normalized
    mode_value = {'GIZMO': 0, 'LOCAL': 1, 'WORLD': 2, 'REFERENCE_OBJECT': 3}[normalized]
    group = getattr(mod, 'node_group', None)
    _set_modifier_socket_value(mod, _xform_socket(group, 'coordinate_mode', 'Coordinate Mode'), mode_value)


def _make_mirror_group(obj, defn, context=None):
    name = unique_name(f"SMS Max {defn.get('label', 'Mirror')} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        try:
            group.is_modifier = True
        except Exception:
            pass
        try:
            group.nodes.clear()
        except Exception:
            pass
        group_input = group.nodes.new('NodeGroupInput')
        transform = group.nodes.new('GeometryNodeTransform')
        flip_faces = group.nodes.new('GeometryNodeFlipFaces')
        join_geometry = group.nodes.new('GeometryNodeJoinGeometry')
        copy_switch = group.nodes.new('GeometryNodeSwitch')
        copy_switch.input_type = 'GEOMETRY'
        group_output = group.nodes.new('NodeGroupOutput')
        group_input.location = (-1000, 0)
        transform.location = (-120, 0)
        flip_faces.location = (80, 0)
        join_geometry.location = (280, -80)
        copy_switch.location = (460, 0)
        group_output.location = (900, 0)
        try:
            group_output.is_active_output = True
        except Exception:
            pass
        geometry_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        scale_type = _socket_type_from_node_socket(_socket_by_name(transform.inputs, ('Scale',), 4), 'NodeSocketVector')
        out_type = _socket_type_from_node_socket(_socket_by_name(flip_faces.outputs, ('Mesh', 'Geometry'), 0), 'NodeSocketGeometry')
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type, description=choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
        _add_interface_socket(group, name=choose_text('Mirror Scale', 'ミラースケール', context=context), in_out='INPUT', socket_type=scale_type, default=(-1.0, 1.0, 1.0), description=choose_text('Axis scale used by the Max-style Mirror modifier. Set an axis to -1 to mirror on that axis.', 'Max互換ミラーで使う軸別スケールです。反転したい軸を -1 にします。', context=context))
        _offset_socket = _add_interface_socket(group, name=choose_text('Offset', 'オフセット', context=context), in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Distance, in scene units, that the mirrored side moves along each mirrored axis of the gizmo, like Offset in the 3ds Max Mirror modifier.', '3ds Max の Mirror モディファイアの Offset と同じく、反転した側をギズモの反転軸に沿ってずらす距離（シーン単位）です。', context=context))
        try:
            _offset_socket.subtype = 'DISTANCE'
        except Exception:
            pass
        _add_interface_socket(group, name=choose_text('Copy', 'コピー', context=context), in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Keep the original geometry and add a mirrored copy.', '元のジオメトリを保持し、鏡像コピーを追加します。', context=context))
        _add_interface_socket(group, name=choose_text('Mirror Center', 'ミラー中心', context=context), in_out='INPUT', socket_type='NodeSocketVector', default=(0.0, 0.0, 0.0), description=choose_text('Object-local center of the mirror plane.', 'ミラー平面のオブジェクトローカル中心です。', context=context))
        _add_interface_socket(group, name=choose_text('Mirror Rotation', 'ミラー回転', context=context), in_out='INPUT', socket_type='NodeSocketRotation', default=(0.0, 0.0, 0.0), description=choose_text('Rotation of the mirror gizmo, which tilts the mirror plane, like rotating the Mirror Center gizmo in 3ds Max.', '3ds Max で Mirror Center のギズモを回すのと同じく、ミラー平面を傾けるギズモの回転です。', context=context))
        _add_interface_socket(group, name=choose_text('Weld Seam', '継ぎ目を溶接', context=context), in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Welds vertices that lie on the mirror plane within Threshold. This is an extra that matches Weld Seam in the 3ds Max Symmetry modifier.', 'ミラー平面からしきい値以内にある頂点を溶接します。3ds Max の Symmetry モディファイアの Weld Seam に当たる追加機能です。', context=context))
        _threshold_socket = _add_interface_socket(group, name=choose_text('Threshold', 'しきい値', context=context), in_out='INPUT', socket_type='NodeSocketFloat', default=0.001, description=choose_text('Distance from the mirror plane, and between vertices, used by Weld Seam.', '継ぎ目の溶接で使う、ミラー平面からの距離と頂点どうしの距離です。', context=context))
        try:
            _threshold_socket.min_value = 0.0
        except Exception:
            pass
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=out_type, description=choose_text('Mirrored geometry with face normals corrected.', '面の向きを補正したミラージオメトリです。', context=context))

        def _group_input(names, index):
            return _socket_by_name(group_input.outputs, names, index)

        geometry_out = _group_input(('Geometry',), 0)
        scale_out = _group_input(('Mirror Scale', 'ミラースケール'), 1)
        offset_out = _group_input(('Offset', 'オフセット'), 2)
        copy_out = _group_input(('Copy', 'コピー'), 3)
        center_out = _group_input(('Mirror Center', 'ミラー中心'), 4)
        rotation_out = _group_input(('Mirror Rotation', 'ミラー回転'), 5)
        weld_out = _group_input(('Weld Seam', '継ぎ目を溶接'), 6)
        threshold_out = _group_input(('Threshold', 'しきい値'), 7)
        # Blender 5.1.2 mesh_transform changes positions, not face winding.
        # Correct orientation only for an odd number of negative axes. Compare
        # signs independently to avoid determinant-product under/overflow.
        # The gizmo rotation and the offset do not change the determinant sign.
        separate = group.nodes.new('ShaderNodeSeparateXYZ')
        separate.location = (-800, -260)
        group.links.new(scale_out, separate.inputs[0])
        negative_axes = []
        for index in range(3):
            negative = group.nodes.new('ShaderNodeMath')
            negative.operation = 'LESS_THAN'
            negative.inputs[1].default_value = 0.0
            negative.location = (-620, -260 - index * 140)
            group.links.new(separate.outputs[index], negative.inputs[0])
            negative_axes.append(negative.outputs[0])
        odd_xy = group.nodes.new('FunctionNodeBooleanMath')
        odd_xy.operation = 'XOR'
        odd_xyz = group.nodes.new('FunctionNodeBooleanMath')
        odd_xyz.operation = 'XOR'
        group.links.new(negative_axes[0], odd_xy.inputs[0])
        group.links.new(negative_axes[1], odd_xy.inputs[1])
        group.links.new(odd_xy.outputs[0], odd_xyz.inputs[0])
        group.links.new(negative_axes[2], odd_xyz.inputs[1])
        group.links.new(odd_xyz.outputs[0], _socket_by_name(flip_faces.inputs, ('Selection',), 1))
        # 3ds Max の Offset：反転する軸ごとに、反転した側をギズモの空間でずらします。
        mirrored_mask = group.nodes.new('ShaderNodeCombineXYZ')
        mirrored_mask.location = (-440, -300)
        for index in range(3):
            group.links.new(negative_axes[index], mirrored_mask.inputs[index])
        offset_vector = group.nodes.new('ShaderNodeVectorMath')
        offset_vector.operation = 'SCALE'
        offset_vector.location = (-280, -300)
        group.links.new(mirrored_mask.outputs[0], offset_vector.inputs[0])
        group.links.new(offset_out, _socket_by_name(offset_vector.inputs, ('Scale',), 3))
        # ギズモ（中心・回転）の空間で反転してから戻します：M = G・T(offset)・S・G⁻¹
        gizmo_matrix = group.nodes.new('FunctionNodeCombineTransform')
        gizmo_matrix.location = (-620, 260)
        group.links.new(center_out, _socket_by_name(gizmo_matrix.inputs, ('Translation',), 0))
        group.links.new(rotation_out, _socket_by_name(gizmo_matrix.inputs, ('Rotation',), 1))
        mirror_matrix = group.nodes.new('FunctionNodeCombineTransform')
        mirror_matrix.location = (-620, 120)
        group.links.new(offset_vector.outputs[0], _socket_by_name(mirror_matrix.inputs, ('Translation',), 0))
        group.links.new(scale_out, _socket_by_name(mirror_matrix.inputs, ('Scale',), 2))
        gizmo_inverse = group.nodes.new('FunctionNodeInvertMatrix')
        gizmo_inverse.location = (-440, 260)
        group.links.new(gizmo_matrix.outputs[0], gizmo_inverse.inputs[0])
        gizmo_mirror = group.nodes.new('FunctionNodeMatrixMultiply')
        gizmo_mirror.location = (-440, 120)
        group.links.new(gizmo_matrix.outputs[0], gizmo_mirror.inputs[0])
        group.links.new(mirror_matrix.outputs[0], gizmo_mirror.inputs[1])
        full_matrix = group.nodes.new('FunctionNodeMatrixMultiply')
        full_matrix.location = (-280, 160)
        group.links.new(gizmo_mirror.outputs[0], full_matrix.inputs[0])
        group.links.new(_socket_by_name(gizmo_inverse.outputs, ('Matrix',), 0), full_matrix.inputs[1])
        _socket_by_name(transform.inputs, ('Mode',), 1).default_value = 'Matrix'
        group.links.new(geometry_out, _socket_by_name(transform.inputs, ('Geometry',), 0))
        group.links.new(full_matrix.outputs[0], _socket_by_name(transform.inputs, ('Transform',), 5))
        group.links.new(_socket_by_name(transform.outputs, ('Geometry',), 0), _socket_by_name(flip_faces.inputs, ('Mesh', 'Geometry'), 0))
        group.links.new(geometry_out, _socket_by_name(join_geometry.inputs, ('Geometry',), 0))
        group.links.new(_socket_by_name(flip_faces.outputs, ('Mesh', 'Geometry'), 0), _socket_by_name(join_geometry.inputs, ('Geometry',), 0))
        group.links.new(copy_out, _socket_by_name(copy_switch.inputs, ('Switch',), 0))
        group.links.new(_socket_by_name(flip_faces.outputs, ('Mesh', 'Geometry'), 0), _socket_by_name(copy_switch.inputs, ('False',), 1))
        group.links.new(_socket_by_name(join_geometry.outputs, ('Geometry',), 0), _socket_by_name(copy_switch.inputs, ('True',), 2))
        # 溶接（3ds Max の Symmetry の Weld Seam に当たる追加機能）：ギズモの空間で、反転する軸の継ぎ目の面
        # （反転と Offset で動かない面）からしきい値以内の頂点を、しきい値の距離で溶接します。
        weld_merge = group.nodes.new('GeometryNodeMergeByDistance')
        weld_merge.location = (700, 0)
        weld_position = group.nodes.new('GeometryNodeInputPosition')
        weld_relative = group.nodes.new('ShaderNodeVectorMath')
        weld_relative.operation = 'SUBTRACT'
        group.links.new(weld_position.outputs[0], weld_relative.inputs[0])
        group.links.new(center_out, weld_relative.inputs[1])
        inverse_rotation = group.nodes.new('FunctionNodeInvertRotation')
        group.links.new(rotation_out, inverse_rotation.inputs[0])
        weld_local = group.nodes.new('FunctionNodeRotateVector')
        group.links.new(weld_relative.outputs[0], _socket_by_name(weld_local.inputs, ('Vector',), 0))
        group.links.new(inverse_rotation.outputs[0], _socket_by_name(weld_local.inputs, ('Rotation',), 1))
        # 継ぎ目の面：反転する軸 i で x = offset / (1 - s_i)。反転しない軸は 0（割る数は 1 にして 0 割りを避けます）。
        mirrored_scale = group.nodes.new('ShaderNodeVectorMath')
        mirrored_scale.operation = 'MULTIPLY'
        group.links.new(scale_out, mirrored_scale.inputs[0])
        group.links.new(mirrored_mask.outputs[0], mirrored_scale.inputs[1])
        seam_divisor = group.nodes.new('ShaderNodeVectorMath')
        seam_divisor.operation = 'SUBTRACT'
        seam_divisor.inputs[0].default_value = (1.0, 1.0, 1.0)
        group.links.new(mirrored_scale.outputs[0], seam_divisor.inputs[1])
        seam_plane = group.nodes.new('ShaderNodeVectorMath')
        seam_plane.operation = 'DIVIDE'
        group.links.new(offset_vector.outputs[0], seam_plane.inputs[0])
        group.links.new(seam_divisor.outputs[0], seam_plane.inputs[1])
        weld_from_seam = group.nodes.new('ShaderNodeVectorMath')
        weld_from_seam.operation = 'SUBTRACT'
        group.links.new(weld_local.outputs[0], weld_from_seam.inputs[0])
        group.links.new(seam_plane.outputs[0], weld_from_seam.inputs[1])
        weld_absolute = group.nodes.new('ShaderNodeVectorMath')
        weld_absolute.operation = 'ABSOLUTE'
        group.links.new(weld_from_seam.outputs[0], weld_absolute.inputs[0])
        weld_separate = group.nodes.new('ShaderNodeSeparateXYZ')
        group.links.new(weld_absolute.outputs[0], weld_separate.inputs[0])
        near_any = None
        for index in range(3):
            near = group.nodes.new('ShaderNodeMath')
            near.operation = 'LESS_THAN'
            group.links.new(weld_separate.outputs[index], near.inputs[0])
            group.links.new(threshold_out, near.inputs[1])
            on_axis = group.nodes.new('ShaderNodeMath')
            on_axis.operation = 'MULTIPLY'
            group.links.new(near.outputs[0], on_axis.inputs[0])
            group.links.new(negative_axes[index], on_axis.inputs[1])
            if near_any is None:
                near_any = on_axis.outputs[0]
            else:
                either = group.nodes.new('ShaderNodeMath')
                either.operation = 'MAXIMUM'
                group.links.new(near_any, either.inputs[0])
                group.links.new(on_axis.outputs[0], either.inputs[1])
                near_any = either.outputs[0]
        weld_on = group.nodes.new('ShaderNodeMath')
        weld_on.operation = 'MULTIPLY'
        group.links.new(near_any, weld_on.inputs[0])
        group.links.new(weld_out, weld_on.inputs[1])
        group.links.new(_socket_by_name(copy_switch.outputs, ('Output',), 0), _socket_by_name(weld_merge.inputs, ('Geometry',), 0))
        group.links.new(weld_on.outputs[0], _socket_by_name(weld_merge.inputs, ('Selection',), 1))
        group.links.new(threshold_out, _socket_by_name(weld_merge.inputs, ('Distance',), 3))
        group.links.new(_socket_by_name(weld_merge.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))
        return group
    except Exception:
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _set_socket_default(socket, value) -> bool:
    if socket is None:
        return False
    candidates = [value]
    if isinstance(value, tuple):
        candidates.append(list(value))
    elif isinstance(value, list):
        candidates.append(tuple(value))
    for candidate in candidates:
        try:
            socket.default_value = candidate
            return True
        except Exception:
            pass
    return False


def _link_node_sockets(group, from_socket, to_socket) -> bool:
    if group is None or from_socket is None or to_socket is None:
        return False
    try:
        group.links.new(from_socket, to_socket)
        return True
    except Exception:
        return False


def _set_modifier_socket_value(mod, socket, value) -> bool:
    if mod is None or socket is None:
        return False
    keys = []
    try:
        identifier = str(getattr(socket, 'identifier', '') or '')
    except Exception:
        identifier = ''
    if identifier:
        keys.append(identifier)
    else:
        try:
            name = str(getattr(socket, 'name', '') or '')
        except Exception:
            name = ''
        if name:
            keys.append(name)
    ok = False
    for key in keys:
        try:
            mod[key] = value
            ok = True
        except Exception:
            try:
                if isinstance(value, tuple):
                    mod[key] = list(value)
                    ok = True
            except Exception:
                pass
    if ok:
        try:
            owner = getattr(mod, 'id_data', None)
            if owner is not None:
                owner.update_tag()
        except Exception:
            pass
    return ok


def _find_interface_socket(group, name: str, in_out: str = 'INPUT'):
    target = str(name or '')
    direction = str(in_out or 'INPUT').upper()
    if group is None or not target:
        return None
    try:
        for item in group.interface.items_tree:
            try:
                if str(getattr(item, 'item_type', '') or '') != 'SOCKET':
                    continue
                if str(getattr(item, 'in_out', '') or '').upper() != direction:
                    continue
                if str(getattr(item, 'name', '') or '') == target or str(getattr(item, 'identifier', '') or '') == target:
                    return item
            except Exception:
                continue
    except Exception:
        pass
    try:
        collection = group.inputs if direction == 'INPUT' else group.outputs
        for item in collection:
            if str(getattr(item, 'name', '') or '') == target or str(getattr(item, 'identifier', '') or '') == target:
                return item
    except Exception:
        pass
    return None







def _link_object_to_existing_collections(obj, target, context=None) -> None:
    linked = False
    try:
        for col in list(getattr(target, 'users_collection', []) or []):
            try:
                if obj.name not in col.objects:
                    col.objects.link(obj)
                linked = True
            except Exception:
                pass
    except Exception:
        pass
    if not linked:
        try:
            if context is not None and getattr(context, 'collection', None) is not None:
                context.collection.objects.link(obj)
                linked = True
        except Exception:
            pass
    if not linked:
        try:
            bpy.context.scene.collection.objects.link(obj)
        except Exception:
            pass

















































# -----------------------------------------------------------------------------
# Smart Connect Noise / 4D Geometry Nodes noise
# -----------------------------------------------------------------------------

def _noise_bounds_center_world(obj) -> Vector:
    try:
        pts = [obj.matrix_world @ Vector(corner) for corner in getattr(obj, 'bound_box', [])]
        if pts:
            return sum(pts, Vector((0.0, 0.0, 0.0))) / float(len(pts))
    except Exception:
        pass
    try:
        return Vector(obj.matrix_world.translation)
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _noise_get_or_create_collection(context=None):
    """Modifier_System_Collection/Noise_Collection を取得または作成します。"""
    try:
        scene = getattr(context, 'scene', None) if context is not None else bpy.context.scene
    except Exception:
        scene = None
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is None:
            root = bpy.data.collections.new('Modifier_System_Collection')
        if scene is not None:
            try:
                if root.name not in [c.name for c in scene.collection.children]:
                    scene.collection.children.link(root)
            except Exception:
                pass
        col = bpy.data.collections.get(NOISE_COLLECTION_NAME)
        if col is None:
            col = bpy.data.collections.new(NOISE_COLLECTION_NAME)
        try:
            if col.name not in [c.name for c in root.children]:
                root.children.link(col)
        except Exception:
            pass
        return col
    except Exception:
        return None


def _noise_link_object_to_collection(obj, context=None, exclusive: bool = True) -> None:
    if obj is None:
        return
    col = _noise_get_or_create_collection(context)
    if col is None:
        return
    try:
        if obj.name not in [o.name for o in col.objects]:
            col.objects.link(obj)
    except Exception:
        pass
    if exclusive:
        for other in list(getattr(obj, 'users_collection', []) or []):
            if other == col:
                continue
            try:
                other.objects.unlink(obj)
            except Exception:
                pass


def _noise_collection_is_empty(col) -> bool:
    try:
        if len(col.objects) > 0:
            return False
    except Exception:
        pass
    try:
        if len(col.children) > 0:
            return False
    except Exception:
        pass
    return True


def _noise_cleanup_empty_collections() -> None:
    try:
        col = bpy.data.collections.get(NOISE_COLLECTION_NAME)
        if col is not None and _noise_collection_is_empty(col):
            bpy.data.collections.remove(col)
    except Exception:
        pass
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is not None and _noise_collection_is_empty(root):
            bpy.data.collections.remove(root)
    except Exception:
        pass


def _noise_set_helper_visibility(obj, visible: bool) -> None:
    if obj is None:
        return
    try:
        # 「ビューポートで無効」は評価自体を止めるため、Noise補助だけ stale 状態を解除し、
        # 一時表示は hide_set() で行います。通常編集対象オブジェクトには適用しません。
        if bool(getattr(obj, 'hide_viewport', False)):
            obj.hide_viewport = False
    except Exception:
        pass
    try:
        obj.hide_set(not bool(visible))
    except Exception:
        pass
    if bool(visible):
        try:
            if bool(obj.get(NOISE_HELPER_PROP, False)) or bool(obj.get(NOISE_PROXY_OWNER_PROP, False)):
                obj.hide_select = False
        except Exception:
            pass


def _noise_socket(group, prop_name: str, *names: str):
    if group is None:
        return None
    try:
        sid = str(group.get(prop_name, '') or '')
        if sid:
            item = _find_interface_socket(group, sid, 'INPUT')
            if item is not None:
                return item
    except Exception:
        pass
    try:
        for name in names:
            item = _find_interface_socket(group, str(name or ''), 'INPUT')
            if item is not None:
                return item
    except Exception:
        pass
    return None


def _find_noise_gizmo(obj, modifier_name: str = ''):
    if obj is None:
        return None
    mod_name = str(modifier_name or '')
    try:
        if mod_name:
            mod = obj.modifiers.get(mod_name)
            if mod is not None:
                name = str(mod.get(NOISE_GIZMO_NAME_PROP, '') or '')
                if name:
                    found = bpy.data.objects.get(name)
                    if found is not None:
                        return found
    except Exception:
        pass
    target_name = str(getattr(obj, 'name', '') or '')
    for candidate in list(bpy.data.objects):
        try:
            if str(candidate.get(NOISE_GIZMO_TARGET_PROP, '') or '') != target_name:
                continue
            if mod_name and str(candidate.get(NOISE_GIZMO_MODIFIER_PROP, '') or '') != mod_name:
                continue
            return candidate
        except Exception:
            continue
    return None


def _new_noise_gizmo(obj, modifier_name: str, context=None):
    """対象メッシュ中心に、4Dノイズ制御用のSphere Emptyギズモを作成します。"""
    try:
        name = unique_name(NOISE_GIZMO_BASE_NAME, bpy.data.objects)
    except Exception:
        name = NOISE_GIZMO_BASE_NAME
    gizmo = bpy.data.objects.new(name, None)
    try:
        gizmo.empty_display_type = 'SPHERE'
    except Exception:
        try:
            gizmo.empty_display_type = 'PLAIN_AXES'
        except Exception:
            pass
    try:
        gizmo.empty_display_size = 1.0
    except Exception:
        pass
    try:
        gizmo.location = _noise_bounds_center_world(obj)
    except Exception:
        pass
    try:
        if context is not None and getattr(context, 'collection', None) is not None:
            context.collection.objects.link(gizmo)
        else:
            bpy.context.collection.objects.link(gizmo)
    except Exception:
        try:
            bpy.context.scene.collection.objects.link(gizmo)
        except Exception:
            pass
    try:
        gizmo.hide_render = True
        gizmo.show_name = True
        gizmo[NOISE_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
        gizmo[NOISE_GIZMO_MODIFIER_PROP] = str(modifier_name or '')
        gizmo[NOISE_HELPER_PROP] = True
        gizmo['smsm_internal_helper'] = True
    except Exception:
        pass
    _noise_link_object_to_collection(gizmo, context=context, exclusive=True)
    _noise_set_helper_visibility(gizmo, True)
    return gizmo


def _make_noise_group(obj, defn=None, context=None):
    """ギズモローカル空間4Dノイズで頂点をオフセットするGeometry Nodesを構築します。"""
    try:
        name = unique_name(NOISE_NODE_GROUP_PREFIX, bpy.data.node_groups)
    except Exception:
        name = NOISE_NODE_GROUP_PREFIX
    group = None
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        try:
            group.is_modifier = True
        except Exception:
            pass
        try:
            group.nodes.clear()
        except Exception:
            pass

        # --- モディファイア入出力。GizmoはEmpty、Scale/Strength/Phaseはユーザー調整用です。 ---
        geom_in = _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry', description=choose_text('Input mesh geometry.', '入力メッシュジオメトリです。', context=context))
        gizmo_in = _add_interface_socket(group, name='Gizmo', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Noise gizmo Empty. Move, rotate, scale, or animate it to change the local-space 4D noise field.', 'ノイズギズモEmptyです。移動・回転・スケール・アニメーションでローカル空間4Dノイズ場を変更します。', context=context))
        scale_in = _add_interface_socket(group, name='Scale', in_out='INPUT', socket_type='NodeSocketFloat', default=100.0, description=choose_text('Noise feature size. Larger values are smoother, matching 3ds Max.', 'ノイズ形状のサイズです。大きい値ほど滑らかになり、3ds Max と同じ方向で動作します。', context=context))
        strength_in = _add_interface_socket(group, name='Strength', in_out='INPUT', socket_type='NodeSocketVector', default=(0.0, 0.0, 0.0), description=choose_text('Per-axis noise displacement strength.', '軸ごとのノイズ変位強度です。', context=context))
        phase_in = _add_interface_socket(group, name='Phase', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('4D noise phase / W input. Animate this for time-varying noise.', '4DノイズのPhase / W入力です。アニメーションすると時間変化するノイズになります。', context=context))
        seed_in = _add_interface_socket(group, name='Seed', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Deterministic random starting point.', '決定論的なランダム開始点です。', context=context))
        fractal_in = _add_interface_socket(group, name='Fractal', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Enables multi-octave fractal noise.', '複数オクターブのフラクタルノイズを有効にします。', context=context))
        roughness_in = _add_interface_socket(group, name='Roughness', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Fractal variation from 0 to 1.', '0から1のフラクタル変化量です。', context=context))
        iterations_in = _add_interface_socket(group, name='Iterations', in_out='INPUT', socket_type='NodeSocketFloat', default=6.0, description=choose_text('Fractal octave count from 1 to 10.', '1から10のフラクタルオクターブ数です。', context=context))
        animate_in = _add_interface_socket(group, name='Animate Noise', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Adds frame-driven motion to Phase.', 'フレームに連動した変化をPhaseへ加えます。', context=context))
        frequency_in = _add_interface_socket(group, name='Frequency', in_out='INPUT', socket_type='NodeSocketFloat', default=0.25, description=choose_text('Animation speed for the noise field.', 'ノイズ場のアニメーション速度です。', context=context))
        geom_out = _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry', description=choose_text('Noise-deformed geometry.', 'ノイズ変形後のジオメトリです。', context=context))
        try:
            group[NOISE_GIZMO_SOCKET_PROP] = str(getattr(gizmo_in, 'identifier', '') or '')
            group[NOISE_SCALE_SOCKET_PROP] = str(getattr(scale_in, 'identifier', '') or '')
            group[NOISE_STRENGTH_SOCKET_PROP] = str(getattr(strength_in, 'identifier', '') or '')
            group[NOISE_PHASE_SOCKET_PROP] = str(getattr(phase_in, 'identifier', '') or '')
            group[NOISE_SEED_SOCKET_PROP] = str(getattr(seed_in, 'identifier', '') or '')
            group[NOISE_FRACTAL_SOCKET_PROP] = str(getattr(fractal_in, 'identifier', '') or '')
            group[NOISE_ROUGHNESS_SOCKET_PROP] = str(getattr(roughness_in, 'identifier', '') or '')
            group[NOISE_ITERATIONS_SOCKET_PROP] = str(getattr(iterations_in, 'identifier', '') or '')
            group[NOISE_ANIMATE_SOCKET_PROP] = str(getattr(animate_in, 'identifier', '') or '')
            group[NOISE_FREQUENCY_SOCKET_PROP] = str(getattr(frequency_in, 'identifier', '') or '')
        except Exception:
            pass

        nodes = group.nodes
        links = group.links
        group_input = nodes.new('NodeGroupInput')
        group_output = nodes.new('NodeGroupOutput')
        position = nodes.new('GeometryNodeInputPosition')
        self_obj = nodes.new('GeometryNodeSelfObject')
        self_info = nodes.new('GeometryNodeObjectInfo')
        world_pos = nodes.new('FunctionNodeTransformPoint')
        gizmo_info = nodes.new('GeometryNodeObjectInfo')
        subtract = nodes.new('ShaderNodeVectorMath')
        invert_rot = nodes.new('FunctionNodeInvertRotation')
        rotate = nodes.new('FunctionNodeRotateVector')
        divide = nodes.new('ShaderNodeVectorMath')
        seed_combine = nodes.new('ShaderNodeCombineXYZ')
        seed_add = nodes.new('ShaderNodeVectorMath')
        scale_safe = nodes.new('ShaderNodeMath')
        scale_inverse = nodes.new('ShaderNodeMath')
        noise = nodes.new('ShaderNodeTexNoise')
        phase_passthrough = nodes.new('ShaderNodeMath')
        scene_time = nodes.new('GeometryNodeInputSceneTime')
        time_frequency = nodes.new('ShaderNodeMath')
        animated_phase = nodes.new('ShaderNodeMath')
        phase_switch = nodes.new('GeometryNodeSwitch')
        detail_switch = nodes.new('GeometryNodeSwitch')
        center = nodes.new('ShaderNodeVectorMath')
        strength_mul = nodes.new('ShaderNodeVectorMath')
        set_position = nodes.new('GeometryNodeSetPosition')

        group_input.location = (-1160, 120)
        position.location = (-1160, -260)
        self_obj.location = (-1160, -520)
        self_info.location = (-940, -520)
        world_pos.location = (-740, -260)
        gizmo_info.location = (-940, -20)
        subtract.location = (-520, -220)
        invert_rot.location = (-520, 20)
        rotate.location = (-300, -220)
        divide.location = (-80, -220)
        noise.location = (120, -220)
        phase_passthrough.location = (-80, -20)
        center.location = (360, -220)
        strength_mul.location = (580, -220)
        set_position.location = (780, 80)
        group_output.location = (1020, 80)
        try:
            group_output.is_active_output = True
        except Exception:
            pass
        try:
            subtract.operation = 'SUBTRACT'
            divide.operation = 'DIVIDE'
            seed_add.operation = 'ADD'
            scale_safe.operation = 'MAXIMUM'
            scale_inverse.operation = 'DIVIDE'
            center.operation = 'SUBTRACT'
            strength_mul.operation = 'MULTIPLY'
            phase_passthrough.operation = 'ADD'
            time_frequency.operation = 'MULTIPLY'
            animated_phase.operation = 'ADD'
        except Exception:
            pass
        try:
            noise.noise_dimensions = '4D'
            phase_switch.input_type = 'FLOAT'
            detail_switch.input_type = 'FLOAT'
        except Exception:
            pass
        # Vector Math inputs share the same display name in Blender 5.1.2.
        # Resolve the second component input by index, never by duplicate name.
        _set_socket_default(_socket_by_name(center.inputs, (), 1), (0.5, 0.5, 0.5))
        _set_socket_default(_socket_by_name(phase_passthrough.inputs, ('Value',), 1), 0.0)
        _set_socket_default(_socket_by_name(scale_safe.inputs, (), 1), 0.001)
        _set_socket_default(_socket_by_name(scale_inverse.inputs, (), 0), 100.0)
        _set_socket_default(_socket_by_name(detail_switch.inputs, ('False',), 1), 1.0)
        _set_socket_default(_socket_by_name(set_position.inputs, ('Selection',), 1), True)

        # --- ジオメトリフロー: Group Input -> Set Position -> Group Output ---
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
        _link_node_sockets(group, _socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))

        # --- PositionをSelf ObjectのTransformでワールド座標化します。 ---
        _link_node_sockets(group, _socket_by_name(self_obj.outputs, ('Self Object',), 0), _socket_by_name(self_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(position.outputs, ('Position',), 0), _socket_by_name(world_pos.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(self_info.outputs, ('Transform',), 0), _socket_by_name(world_pos.inputs, ('Transform',), 1))

        # --- GizmoのLocation/Rotation/Scaleを取得します。 ---
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Gizmo',), 1), _socket_by_name(gizmo_info.inputs, ('Object',), 0))

        # --- Position - Gizmo Location -> 逆回転 -> Scale除算でギズモローカル座標へ変換します。 ---
        _link_node_sockets(group, _socket_by_name(world_pos.outputs, ('Vector',), 0), _socket_by_name(subtract.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Location',), 1), _socket_by_name(subtract.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Rotation',), 2), _socket_by_name(invert_rot.inputs, ('Rotation',), 0))
        _link_node_sockets(group, _socket_by_name(subtract.outputs, ('Vector',), 0), _socket_by_name(rotate.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(invert_rot.outputs, ('Rotation',), 0), _socket_by_name(rotate.inputs, ('Rotation',), 1))
        _link_node_sockets(group, _socket_by_name(rotate.outputs, ('Vector',), 0), _socket_by_name(divide.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Scale',), 3), _socket_by_name(divide.inputs, (), 1))

        # --- 4D Noise: Vectorにギズモローカル座標、Scale/Phaseを公開入力から接続します。 ---
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Seed',), 5), _socket_by_name(seed_combine.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Seed',), 5), _socket_by_name(seed_combine.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Seed',), 5), _socket_by_name(seed_combine.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(divide.outputs, ('Vector',), 0), _socket_by_name(seed_add.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(seed_combine.outputs, ('Vector',), 0), _socket_by_name(seed_add.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(seed_add.outputs, ('Vector',), 0), _socket_by_name(noise.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Scale',), 2), _socket_by_name(scale_safe.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(scale_safe.outputs, (), 0), _socket_by_name(scale_inverse.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(scale_inverse.outputs, (), 0), _socket_by_name(noise.inputs, ('Scale',), 2))
        # Blender 5.1.xでは、Object入力を含むフィールド内でGroup InputのFloatをNoise TextureのWへ直結すると
        # 一部構成で評価が固定化されるため、Math ADD(0)を挟んで通常の数値入力として安定化します。
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Phase',), 4), _socket_by_name(phase_passthrough.inputs, ('Value',), 0))
        _link_node_sockets(group, _socket_by_name(scene_time.outputs, ('Frame',), 1), _socket_by_name(time_frequency.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Frequency',), 10), _socket_by_name(time_frequency.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(phase_passthrough.outputs, ('Value',), 0), _socket_by_name(animated_phase.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(time_frequency.outputs, (), 0), _socket_by_name(animated_phase.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Animate Noise',), 9), _socket_by_name(phase_switch.inputs, ('Switch',), 0))
        _link_node_sockets(group, _socket_by_name(phase_passthrough.outputs, ('Value',), 0), _socket_by_name(phase_switch.inputs, ('False',), 1))
        _link_node_sockets(group, _socket_by_name(animated_phase.outputs, (), 0), _socket_by_name(phase_switch.inputs, ('True',), 2))
        _link_node_sockets(group, _socket_by_name(phase_switch.outputs, ('Output',), 0), _socket_by_name(noise.inputs, ('W',), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Fractal',), 6), _socket_by_name(detail_switch.inputs, ('Switch',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Iterations',), 8), _socket_by_name(detail_switch.inputs, ('True',), 2))
        _link_node_sockets(group, _socket_by_name(detail_switch.outputs, ('Output',), 0), _socket_by_name(noise.inputs, ('Detail',), 3))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Roughness',), 7), _socket_by_name(noise.inputs, ('Roughness',), 4))

        # --- Noise Color - 0.5 -> Strength乗算 -> Set Position Offset ---
        _link_node_sockets(group, _socket_by_name(noise.outputs, ('Color',), 1), _socket_by_name(center.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(center.outputs, ('Vector',), 0), _socket_by_name(strength_mul.inputs, ('Vector',), 0))
        strength_input = _socket_by_name(group_input.outputs, ('Strength',), 3)
        strength_multiplier_input = _socket_by_name(strength_mul.inputs, (), 1)
        offset_input = _socket_by_name(set_position.inputs, ('Offset',), 3)
        _link_node_sockets(group, strength_input, strength_multiplier_input)
        _link_node_sockets(group, _socket_by_name(strength_mul.outputs, ('Vector',), 0), _socket_by_name(set_position.inputs, ('Offset',), 3))

        # Noise must fail closed. A nominal group or passthrough group is never
        # accepted as the dedicated backend when required field links are absent.
        required_nodes = {
            'NodeGroupInput', 'NodeGroupOutput', 'GeometryNodeInputPosition',
            'ShaderNodeTexNoise', 'ShaderNodeVectorMath', 'GeometryNodeSetPosition',
        }
        present_nodes = {str(getattr(node, 'bl_idname', '') or '') for node in nodes}
        required_links = (
            (_socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0)),
            (_socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0)),
            (_socket_by_name(center.outputs, ('Vector',), 0), _socket_by_name(strength_mul.inputs, (), 0)),
            (strength_input, strength_multiplier_input),
            (_socket_by_name(strength_mul.outputs, ('Vector',), 0), offset_input),
        )
        links_ok = all(
            source is not None and target is not None and any(
                link.from_socket == source and link.to_socket == target for link in links
            )
            for source, target in required_links
        )
        interface_ids = tuple(
            str(group.get(prop, '') or '')
            for prop in (
                NOISE_GIZMO_SOCKET_PROP, NOISE_SCALE_SOCKET_PROP,
                NOISE_STRENGTH_SOCKET_PROP, NOISE_PHASE_SOCKET_PROP,
                NOISE_SEED_SOCKET_PROP, NOISE_FRACTAL_SOCKET_PROP,
                NOISE_ROUGHNESS_SOCKET_PROP, NOISE_ITERATIONS_SOCKET_PROP,
                NOISE_ANIMATE_SOCKET_PROP, NOISE_FREQUENCY_SOCKET_PROP,
            )
        )
        if not required_nodes.issubset(present_nodes) or not links_ok or not all(interface_ids):
            raise RuntimeError('Noise graph contract failed')
        group[NOISE_GRAPH_CONTRACT_PROP] = 'dedicated_noise_graph_v2'
        group['smsm_noise_node_count'] = len(nodes)
        group['smsm_noise_link_count'] = len(links)
        return group
    except Exception:
        try:
            if group is not None and getattr(group, 'users', 0) == 0:
                bpy.data.node_groups.remove(group)
        except Exception:
            pass
        return None


def _configure_noise_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    group = group or getattr(mod, 'node_group', None)
    if force_unique_group or group is None or not str(getattr(group, 'name', '') or '').startswith(NOISE_NODE_GROUP_PREFIX):
        group = _make_noise_group(obj, defn, context=context)
        try:
            mod.node_group = group
        except Exception:
            pass
    gizmo = _find_noise_gizmo(obj, getattr(mod, 'name', ''))
    if gizmo is None:
        gizmo = _new_noise_gizmo(obj, getattr(mod, 'name', ''), context=context)
    try:
        if ms_is_shape_mesh_proxy(obj):
            obj[NOISE_PROXY_OWNER_PROP] = f'{getattr(obj, "name", "")}|{getattr(mod, "name", "")}'
            _noise_link_object_to_collection(obj, context=context, exclusive=True)
    except Exception:
        pass
    try:
        _noise_link_object_to_collection(gizmo, context=context, exclusive=True)
    except Exception:
        pass
    gizmo_socket = _noise_socket(group, NOISE_GIZMO_SOCKET_PROP, 'Gizmo')
    scale_socket = _noise_socket(group, NOISE_SCALE_SOCKET_PROP, 'Scale')
    strength_socket = _noise_socket(group, NOISE_STRENGTH_SOCKET_PROP, 'Strength')
    phase_socket = _noise_socket(group, NOISE_PHASE_SOCKET_PROP, 'Phase')
    seed_socket = _noise_socket(group, NOISE_SEED_SOCKET_PROP, 'Seed')
    fractal_socket = _noise_socket(group, NOISE_FRACTAL_SOCKET_PROP, 'Fractal')
    roughness_socket = _noise_socket(group, NOISE_ROUGHNESS_SOCKET_PROP, 'Roughness')
    iterations_socket = _noise_socket(group, NOISE_ITERATIONS_SOCKET_PROP, 'Iterations')
    animate_socket = _noise_socket(group, NOISE_ANIMATE_SOCKET_PROP, 'Animate Noise')
    frequency_socket = _noise_socket(group, NOISE_FREQUENCY_SOCKET_PROP, 'Frequency')
    _set_modifier_socket_value(mod, gizmo_socket, gizmo)
    for sock, default in ((scale_socket, 100.0), (strength_socket, (0.0, 0.0, 0.0)), (phase_socket, 0.0), (seed_socket, 0.0), (fractal_socket, False), (roughness_socket, 0.0), (iterations_socket, 6.0), (animate_socket, False), (frequency_socket, 0.25)):
        try:
            sid = str(getattr(sock, 'identifier', '') or '')
            if sid and sid not in list(mod.keys()):
                _set_modifier_socket_value(mod, sock, default)
        except Exception:
            _set_modifier_socket_value(mod, sock, default)
    try:
        mod['smsm_noise_modifier'] = True
        mod[BACKEND_PROP] = 'noise_nodes'
        mod[NOISE_GIZMO_NAME_PROP] = str(getattr(gizmo, 'name', '') or '') if gizmo is not None else ''
        mod[NOISE_GIZMO_SOCKET_PROP] = str(getattr(gizmo_socket, 'identifier', '') or '') if gizmo_socket is not None else ''
        mod[NOISE_SCALE_SOCKET_PROP] = str(getattr(scale_socket, 'identifier', '') or '') if scale_socket is not None else ''
        mod[NOISE_STRENGTH_SOCKET_PROP] = str(getattr(strength_socket, 'identifier', '') or '') if strength_socket is not None else ''
        mod[NOISE_PHASE_SOCKET_PROP] = str(getattr(phase_socket, 'identifier', '') or '') if phase_socket is not None else ''
        mod[NOISE_SEED_SOCKET_PROP] = str(getattr(seed_socket, 'identifier', '') or '') if seed_socket is not None else ''
        mod[NOISE_FRACTAL_SOCKET_PROP] = str(getattr(fractal_socket, 'identifier', '') or '') if fractal_socket is not None else ''
        mod[NOISE_ROUGHNESS_SOCKET_PROP] = str(getattr(roughness_socket, 'identifier', '') or '') if roughness_socket is not None else ''
        mod[NOISE_ITERATIONS_SOCKET_PROP] = str(getattr(iterations_socket, 'identifier', '') or '') if iterations_socket is not None else ''
        mod[NOISE_ANIMATE_SOCKET_PROP] = str(getattr(animate_socket, 'identifier', '') or '') if animate_socket is not None else ''
        mod[NOISE_FREQUENCY_SOCKET_PROP] = str(getattr(frequency_socket, 'identifier', '') or '') if frequency_socket is not None else ''
        mod[NOISE_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        if gizmo is not None:
            gizmo[NOISE_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
            gizmo[NOISE_GIZMO_MODIFIER_PROP] = str(getattr(mod, 'name', '') or '')
            gizmo[NOISE_HELPER_PROP] = True
            gizmo['smsm_internal_helper'] = True
        _stamp_modifier(mod, defn or {'key': 'noise_modifier', 'backend': 'noise_nodes'})
        try:
            owner = getattr(mod, 'id_data', None)
            if owner is not None:
                owner.update_tag()
        except Exception:
            pass
    except Exception:
        pass
    return gizmo


def _noise_collect_cleanup_state(obj, mod):
    state = {'gizmo': '', 'group': '', 'proxy': '', 'vertex_groups': []}
    if obj is None or mod is None:
        return state
    try:
        state['gizmo'] = str(mod.get(NOISE_GIZMO_NAME_PROP, '') or '')
    except Exception:
        pass
    try:
        group = getattr(mod, 'node_group', None)
        state['group'] = str(getattr(group, 'name', '') or '')
    except Exception:
        pass
    try:
        if ms_is_shape_mesh_proxy(obj):
            state['proxy'] = str(getattr(obj, 'name', '') or '')
    except Exception:
        pass
    try:
        for vg in getattr(obj, 'vertex_groups', []) or []:
            name = str(getattr(vg, 'name', '') or '')
            if name.startswith('SMS_Noise') or name.startswith('smsm_noise'):
                state['vertex_groups'].append(name)
    except Exception:
        pass
    return state


def _noise_remove_object_if_unused(name: str) -> None:
    obj = bpy.data.objects.get(str(name or ''))
    if obj is not None:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass


def _noise_remove_node_group_if_unused(name: str) -> None:
    group = bpy.data.node_groups.get(str(name or ''))
    if group is not None:
        try:
            if int(getattr(group, 'users', 0) or 0) <= 0 or str(getattr(group, 'name', '') or '').startswith(NOISE_NODE_GROUP_PREFIX):
                bpy.data.node_groups.remove(group)
        except Exception:
            pass


def _noise_remove_proxy_if_unused(proxy_name: str) -> None:
    proxy = bpy.data.objects.get(str(proxy_name or ''))
    if proxy is None:
        _noise_cleanup_empty_collections()
        return
    remove_proxy = False
    try:
        if bool(proxy.get(NOISE_PROXY_OWNER_PROP, False)):
            non_internal = []
            for m in getattr(proxy, 'modifiers', []) or []:
                is_converter = False
                try:
                    if bool(m.get('ms_shape_curve_mesh_converter', False)):
                        is_converter = True
                except Exception:
                    pass
                try:
                    if str(getattr(m, 'name', '') or '') in {'Curve to Mesh via Geometry Nodes', 'ジオメトリノードでカーブを読み込み・メッシュ化'}:
                        is_converter = True
                except Exception:
                    pass
                try:
                    ng = getattr(m, 'node_group', None)
                    if ng is not None and str(getattr(ng, 'name', '') or '').startswith('SMS Curve To Mesh'):
                        is_converter = True
                except Exception:
                    pass
                if is_converter:
                    continue
                try:
                    if bool(m.get('smsm_noise_modifier', False)):
                        continue
                except Exception:
                    pass
                non_internal.append(m)
            remove_proxy = not non_internal
    except Exception:
        remove_proxy = False
    if not remove_proxy:
        return
    data = getattr(proxy, 'data', None)
    try:
        bpy.data.objects.remove(proxy, do_unlink=True)
    except Exception:
        pass
    try:
        if data is not None and int(getattr(data, 'users', 0) or 0) == 0:
            bpy.data.meshes.remove(data)
    except Exception:
        pass
    _noise_cleanup_empty_collections()


def _noise_cleanup_owned_data(state, context=None) -> None:
    try:
        state = dict(state or {})
    except Exception:
        state = {}
    gizmo_name = str(state.get('gizmo', '') or '')
    if gizmo_name:
        still_used = False
        for candidate in list(bpy.data.objects):
            try:
                for other in getattr(candidate, 'modifiers', []) or []:
                    if str(other.get(NOISE_GIZMO_NAME_PROP, '') or '') == gizmo_name:
                        still_used = True
                        break
                if still_used:
                    break
            except Exception:
                continue
        if not still_used:
            _noise_remove_object_if_unused(gizmo_name)
    for vg_name in list(state.get('vertex_groups', []) or []):
        try:
            for obj in list(bpy.data.objects):
                vg = obj.vertex_groups.get(str(vg_name)) if hasattr(obj, 'vertex_groups') else None
                if vg is not None:
                    obj.vertex_groups.remove(vg)
        except Exception:
            pass
    group_name = str(state.get('group', '') or '')
    if group_name:
        _noise_remove_node_group_if_unused(group_name)
    proxy_name = str(state.get('proxy', '') or '')
    if proxy_name:
        _noise_remove_proxy_if_unused(proxy_name)
    _noise_cleanup_empty_collections()


def _noise_before_item_action(main_obj, context, obj, mod, action, clipboard):
    try:
        if bool(mod.get('smsm_noise_modifier', False)) and str(action or '') in {'APPLY', 'APPLY_BELOW', 'DELETE', 'CUT'}:
            return _noise_collect_cleanup_state(obj, mod)
    except Exception:
        pass
    return {}


def _noise_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    if str(action or '') in {'DELETE', 'CUT', 'APPLY', 'APPLY_BELOW'}:
        _noise_cleanup_owned_data(state, context=context)


def _noise_sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive):
    if main_obj is None:
        return None
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if stack_obj is None or not hasattr(stack_obj, 'modifiers'):
        return None
    active_id = str(effective_active_id or '')
    carrier = str(carrier_key or '')
    for mod in list(getattr(stack_obj, 'modifiers', []) or []):
        try:
            if not bool(mod.get('smsm_noise_modifier', False)):
                continue
        except Exception:
            continue
        visible = bool(str(getattr(mod, 'name', '') or '') in {active_id, carrier})
        gizmo = _find_noise_gizmo(stack_obj, getattr(mod, 'name', ''))
        if gizmo is None:
            try:
                gizmo = _configure_noise_modifier(stack_obj, mod, getattr(mod, 'node_group', None), {'key': 'noise_modifier', 'backend': 'noise_nodes'}, context=context)
            except Exception:
                gizmo = None
        if gizmo is not None:
            _noise_link_object_to_collection(gizmo, context=context, exclusive=True)
            _noise_set_helper_visibility(gizmo, visible)
        try:
            if ms_is_shape_mesh_proxy(stack_obj) and bool(stack_obj.get(NOISE_PROXY_OWNER_PROP, False)):
                _noise_link_object_to_collection(stack_obj, context=context, exclusive=True)
                _noise_set_helper_visibility(stack_obj, bool(visible))
        except Exception:
            pass
    return None


def _noise_get_target_modifier(context, object_name: str = '', modifier_name: str = ''):
    obj = bpy.data.objects.get(str(object_name or '')) if object_name else None
    if obj is None:
        try:
            obj = get_main_object(getattr(context, 'active_object', None)) or getattr(context, 'active_object', None)
        except Exception:
            obj = getattr(context, 'active_object', None)
    mod = None
    if obj is not None:
        try:
            mod = obj.modifiers.get(str(modifier_name or '')) if modifier_name else getattr(obj.modifiers, 'active', None)
        except Exception:
            mod = None
    return obj, mod


def _noise_select_gizmo(context, obj, mod) -> bool:
    if obj is None or mod is None:
        return False
    gizmo = _find_noise_gizmo(obj, getattr(mod, 'name', ''))
    if gizmo is None:
        gizmo = _configure_noise_modifier(obj, mod, getattr(mod, 'node_group', None), {'key': 'noise_modifier', 'backend': 'noise_nodes'}, context=context)
    if gizmo is None:
        return False
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    try:
        _noise_link_object_to_collection(gizmo, context=context, exclusive=True)
        _noise_set_helper_visibility(gizmo, True)
        gizmo.select_set(True)
        context.view_layer.objects.active = gizmo
        return True
    except Exception:
        return False


def _draw_noise_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get('smsm_noise_modifier', False)):
            return False
    except Exception:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    try:
        gizmo_sid = str(mod.get(NOISE_GIZMO_SOCKET_PROP, '') or '')
        scale_sid = str(mod.get(NOISE_SCALE_SOCKET_PROP, '') or '')
        strength_sid = str(mod.get(NOISE_STRENGTH_SOCKET_PROP, '') or '')
        phase_sid = str(mod.get(NOISE_PHASE_SOCKET_PROP, '') or '')
        seed_sid = str(mod.get(NOISE_SEED_SOCKET_PROP, '') or '')
        fractal_sid = str(mod.get(NOISE_FRACTAL_SOCKET_PROP, '') or '')
        roughness_sid = str(mod.get(NOISE_ROUGHNESS_SOCKET_PROP, '') or '')
        iterations_sid = str(mod.get(NOISE_ITERATIONS_SOCKET_PROP, '') or '')
        animate_sid = str(mod.get(NOISE_ANIMATE_SOCKET_PROP, '') or '')
        frequency_sid = str(mod.get(NOISE_FREQUENCY_SOCKET_PROP, '') or '')
    except Exception:
        gizmo_sid = scale_sid = strength_sid = phase_sid = seed_sid = fractal_sid = roughness_sid = iterations_sid = animate_sid = frequency_sid = ''
    box = layout.box()
    draw_help_header(box, context, choose_text('Noise', 'ノイズ', context=context), 'MOD_NOISE', 'max_noise_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    drawn = False
    if gizmo_sid:
        try:
            row = col.row(align=True)
            row.prop(mod, f'["{gizmo_sid}"]', text=choose_text('Gizmo', 'ギズモ', context=context))
            op = row.operator('smsm.max_noise_select_gizmo', text='', icon='EMPTY_AXIS')
            op.object_name = obj_name
            op.modifier_name = mod_name
            drawn = True
        except Exception:
            pass
    for sid, en, ja in (
        (seed_sid, 'Seed', 'シード'),
        (scale_sid, 'Scale', 'スケール'),
        (fractal_sid, 'Fractal', 'フラクタル'),
        (roughness_sid, 'Roughness', '粗さ'),
        (iterations_sid, 'Iterations', '反復回数'),
        (strength_sid, 'Strength X / Y / Z', '強度 X / Y / Z'),
        (animate_sid, 'Animate Noise', 'ノイズをアニメーション'),
        (frequency_sid, 'Frequency', '周波数'),
        (phase_sid, 'Phase', 'フェーズ'),
    ):
        if not sid:
            continue
        try:
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
            drawn = True
        except Exception:
            pass
    return drawn


def _noise_skip_copy_props(mod) -> set[str]:
    skip = {
        'node_group', 'smsm_noise_modifier', NOISE_GIZMO_NAME_PROP,
        NOISE_GIZMO_SOCKET_PROP, NOISE_NODE_GROUP_PROP,
        NOISE_HELPER_PROP, NOISE_PROXY_OWNER_PROP,
        NOISE_GIZMO_TARGET_PROP, NOISE_GIZMO_MODIFIER_PROP,
    }
    try:
        sid = str(mod.get(NOISE_GIZMO_SOCKET_PROP, '') or '')
        if sid:
            skip.add(sid)
            skip.add(f'{sid}_use_attribute')
            skip.add(f'{sid}_attribute_name')
    except Exception:
        pass
    return skip


def _make_skew_group(obj, defn=None, context=None):
    """Build the gizmo-space Skew / Taper / Stretch graph chosen by defn['key']."""
    key = gizmo_deform_key(defn)
    fallback_label = {'taper_modifier': 'Taper Modifier', 'stretch_modifier': 'Stretch Modifier'}.get(key, 'Skew Modifier')
    label = str((defn or {}).get('label') or fallback_label)
    name = unique_name(f"SMS Max {label} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    group = None
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        build_gizmo_deform_group(group, key, context=context)
        return group
    except Exception:
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _skew_socket(group, key: str, fallback_name: str):
    if group is None:
        return None
    stored = ''
    try:
        stored = str(group.get(SKEW_SOCKET_PREFIX + str(key), '') or '')
    except Exception:
        pass
    return _find_interface_socket(group, stored or fallback_name, 'INPUT')


def _make_squeeze_group(obj, defn=None, context=None):
    """Build the owned local-Z Squeeze graph; it never falls through to the generic Y-offset backend."""
    label = str((defn or {}).get('label') or 'Squeeze Modifier')
    name = unique_name(f"SMS Max {label} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    group = None
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        group.is_modifier = True
        nodes, links = group.nodes, group.links
        group_input = nodes.new('NodeGroupInput')
        group_output = nodes.new('NodeGroupOutput')
        position = nodes.new('GeometryNodeInputPosition')
        self_object = nodes.new('GeometryNodeSelfObject')
        object_info = nodes.new('GeometryNodeObjectInfo')
        gizmo_info = nodes.new('GeometryNodeObjectInfo')
        object_to_world = nodes.new('FunctionNodeTransformPoint')
        invert_object = nodes.new('FunctionNodeInvertMatrix')
        invert_gizmo = nodes.new('FunctionNodeInvertMatrix')
        world_to_gizmo = nodes.new('FunctionNodeTransformPoint')
        separate = nodes.new('ShaderNodeSeparateXYZ')
        squeeze_percent = nodes.new('ShaderNodeMath')
        bulge_percent = nodes.new('ShaderNodeMath')
        squeeze_curve_mul = nodes.new('ShaderNodeMath')
        bulge_curve_mul = nodes.new('ShaderNodeMath')
        squeeze_influence = nodes.new('ShaderNodeMath')
        bulge_influence = nodes.new('ShaderNodeMath')
        squeeze_add = nodes.new('ShaderNodeMath')
        bulge_add = nodes.new('ShaderNodeMath')
        scaled_x = nodes.new('ShaderNodeMath')
        scaled_y = nodes.new('ShaderNodeMath')
        scaled_z = nodes.new('ShaderNodeMath')
        combine = nodes.new('ShaderNodeCombineXYZ')
        gizmo_to_world = nodes.new('FunctionNodeTransformPoint')
        world_to_object = nodes.new('FunctionNodeTransformPoint')
        set_position = nodes.new('GeometryNodeSetPosition')
        for node, operation in ((squeeze_percent, 'DIVIDE'), (bulge_percent, 'DIVIDE'),
                                (squeeze_curve_mul, 'MULTIPLY'), (bulge_curve_mul, 'MULTIPLY'),
                                (squeeze_influence, 'MULTIPLY'), (bulge_influence, 'MULTIPLY'),
                                (squeeze_add, 'SUBTRACT'), (bulge_add, 'ADD'),
                                (scaled_x, 'MULTIPLY'), (scaled_y, 'MULTIPLY'), (scaled_z, 'MULTIPLY')):
            node.operation = operation
        squeeze_percent.inputs[1].default_value = 100.0
        bulge_percent.inputs[1].default_value = 100.0
        squeeze_add.inputs[0].default_value = 1.0
        bulge_add.inputs[0].default_value = 1.0
        group_output.is_active_output = True
        geometry_type = _socket_type_from_node_socket(_socket_by_name(set_position.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type, description=choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
        sockets = {
            'gizmo': _add_interface_socket(group, name='Gizmo', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Movable Squeeze center and basis.', '移動可能なスクイーズ中心と基準です。', context=context)),
            'squeeze': _add_interface_socket(group, name='Squeeze', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Radial squeeze in percent.', '半径方向のスクイーズ量（パーセント）です。', context=context)),
            'squeeze_curve': _add_interface_socket(group, name='Squeeze Curve', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Radial profile width in gizmo units: small is sharp, large is gradual.', 'ギズモ単位の半径方向プロファイル幅。小さい値は鋭く、大きい値は緩やかです。', context=context)),
            'bulge': _add_interface_socket(group, name='Bulge', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Local axial bulge in percent.', 'ローカル軸方向のバルジ量（パーセント）です。', context=context)),
            'bulge_curve': _add_interface_socket(group, name='Bulge Curve', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Axial bulge curve multiplier.', '軸方向バルジのカーブ倍率です。', context=context)),
            'influence': _add_interface_socket(group, name='Influence', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Overall non-destructive influence.', '全体の非破壊影響度です。', context=context)),
            'use_limits': _add_interface_socket(group, name='Use Limits', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Enable local-Z effect limits.', 'ローカル Z の効果制限を有効にします。', context=context)),
            'lower_limit': _add_interface_socket(group, name='Lower Limit', in_out='INPUT', socket_type='NodeSocketFloat', default=-1.0, description=choose_text('Lower local-Z limit.', 'ローカル Z の下限です。', context=context)),
            'upper_limit': _add_interface_socket(group, name='Upper Limit', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Upper local-Z limit.', 'ローカル Z の上限です。', context=context)),
            'bias': _add_interface_socket(group, name='Bias', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Effect Balance: shifts the effect between Bulge (positive) and Squeeze (negative) while keeping their total, in percent.', '効果のバランス：合計を保ったまま、効果をバルジ（正）とスクイーズ（負）の間で寄せます（パーセント）。', context=context)),
            'volume': _add_interface_socket(group, name='Volume', in_out='INPUT', socket_type='NodeSocketFloat', default=100.0, description=choose_text('Effect Balance: scales Squeeze and Bulge together, in percent.', '効果のバランス：スクイーズとバルジを同じ割合で強めたり弱めたりします（パーセント）。', context=context)),
        }
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=geometry_type, description=choose_text('Output geometry.', '出力ジオメトリです。', context=context))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
        _link_node_sockets(group, _socket_by_name(self_object.outputs, ('Self Object', 'Object'), 0), _socket_by_name(object_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Gizmo',), 1), _socket_by_name(gizmo_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(position.outputs, ('Position',), 0), _socket_by_name(object_to_world.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(object_to_world.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Transform',), 4), _socket_by_name(invert_gizmo.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(invert_object.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(object_to_world.outputs, ('Point', 'Vector'), 0), _socket_by_name(world_to_gizmo.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_gizmo.outputs, (), 0), _socket_by_name(world_to_gizmo.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(world_to_gizmo.outputs, ('Point', 'Vector'), 0), _socket_by_name(separate.inputs, ('Vector',), 0))
        # Radial profile in gizmo units: 1 / (1 + (z / width)^2).
        # Small Curve produces a sharp waist, large Curve a gradual one.
        # This documented interpolation is not a claim of Max numeric parity.
        def profile_math(operation, a, b=None):
            node = nodes.new('ShaderNodeMath')
            node.operation = operation
            for index, value in enumerate((a, b)):
                if value is None:
                    continue
                if isinstance(value, (int, float)):
                    node.inputs[index].default_value = float(value)
                else:
                    _link_node_sockets(group, value, node.inputs[index])
            return node.outputs[0]

        z = _socket_by_name(separate.outputs, ('Z',), 2)
        curve = _socket_by_name(group_input.outputs, ('Squeeze Curve',), 3)
        width = profile_math('MAXIMUM', profile_math('ABSOLUTE', curve), 0.0001)
        height = profile_math('DIVIDE', z, width)
        radial_profile = profile_math('DIVIDE', 1.0, profile_math('ADD', 1.0, profile_math('MULTIPLY', height, height)))
        lower = _socket_by_name(group_input.outputs, ('Lower Limit',), 8)
        upper = _socket_by_name(group_input.outputs, ('Upper Limit',), 9)
        lo = profile_math('MINIMUM', lower, upper)
        hi = profile_math('MAXIMUM', lower, upper)
        outside = profile_math('MAXIMUM', profile_math('LESS_THAN', z, lo), profile_math('GREATER_THAN', z, hi))
        use_limits = _socket_by_name(group_input.outputs, ('Use Limits',), 7)
        limit_weight = profile_math('SUBTRACT', 1.0, profile_math('MULTIPLY', use_limits, outside))
        effective_influence = profile_math('MULTIPLY', _socket_by_name(group_input.outputs, ('Influence',), 6), limit_weight)
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Squeeze',), 2), _socket_by_name(squeeze_percent.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Bulge',), 4), _socket_by_name(bulge_percent.inputs, (), 0))
        # Effect Balance (3ds Max Squeeze): Volume scales Squeeze and Bulge
        # together; Bias moves the effect between them and keeps the sum of
        # both weights at 2 (+100 = Bulge only x2, -100 = Squeeze only x2).
        volume_factor = profile_math('DIVIDE', _socket_by_name(group_input.outputs, ('Volume',), 11), 100.0)
        bias_factor = profile_math('MINIMUM', profile_math('MAXIMUM', profile_math('DIVIDE', _socket_by_name(group_input.outputs, ('Bias',), 10), 100.0), -1.0), 1.0)
        squeeze_balance = profile_math('MULTIPLY', profile_math('SUBTRACT', 1.0, bias_factor), volume_factor)
        bulge_balance = profile_math('MULTIPLY', profile_math('ADD', 1.0, bias_factor), volume_factor)
        _link_node_sockets(group, profile_math('MULTIPLY', _socket_by_name(squeeze_percent.outputs, (), 0), squeeze_balance), _socket_by_name(squeeze_curve_mul.inputs, (), 0))
        _link_node_sockets(group, radial_profile, _socket_by_name(squeeze_curve_mul.inputs, (), 1))
        _link_node_sockets(group, profile_math('MULTIPLY', _socket_by_name(bulge_percent.outputs, (), 0), bulge_balance), _socket_by_name(bulge_curve_mul.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Bulge Curve',), 5), _socket_by_name(bulge_curve_mul.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(squeeze_curve_mul.outputs, (), 0), _socket_by_name(squeeze_influence.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(bulge_curve_mul.outputs, (), 0), _socket_by_name(bulge_influence.inputs, (), 0))
        _link_node_sockets(group, effective_influence, _socket_by_name(squeeze_influence.inputs, (), 1))
        _link_node_sockets(group, effective_influence, _socket_by_name(bulge_influence.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(squeeze_influence.outputs, (), 0), _socket_by_name(squeeze_add.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(bulge_influence.outputs, (), 0), _socket_by_name(bulge_add.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('X',), 0), _socket_by_name(scaled_x.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Y',), 1), _socket_by_name(scaled_y.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Z',), 2), _socket_by_name(scaled_z.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(squeeze_add.outputs, (), 0), _socket_by_name(scaled_x.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(squeeze_add.outputs, (), 0), _socket_by_name(scaled_y.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(bulge_add.outputs, (), 0), _socket_by_name(scaled_z.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(scaled_x.outputs, (), 0), _socket_by_name(combine.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(scaled_y.outputs, (), 0), _socket_by_name(combine.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(scaled_z.outputs, (), 0), _socket_by_name(combine.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(combine.outputs, ('Vector',), 0), _socket_by_name(gizmo_to_world.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Transform',), 4), _socket_by_name(gizmo_to_world.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(gizmo_to_world.outputs, ('Point', 'Vector'), 0), _socket_by_name(world_to_object.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_object.outputs, (), 0), _socket_by_name(world_to_object.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(world_to_object.outputs, ('Point', 'Vector'), 0), _socket_by_name(set_position.inputs, ('Position',), 2))
        _link_node_sockets(group, _socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))
        group[SQUEEZE_GRAPH_CONTRACT_PROP] = 'dedicated_gizmo_space_squeeze_radial_limits_balance_v3'
        for key, socket in sockets.items():
            group[SQUEEZE_SOCKET_PREFIX + key] = str(getattr(socket, 'identifier', '') or '')
        return group
    except Exception:
        # A visible Squeeze row without its dedicated graph is a false
        # success.  Remove only the group allocated by this invocation; do
        # not search by name or touch pre-existing/foreign node groups.
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        return None


def _squeeze_socket(group, key: str, fallback_name: str):
    stored = str(group.get(SQUEEZE_SOCKET_PREFIX + str(key), '') or '') if group is not None else ''
    return _find_interface_socket(group, stored or fallback_name, 'INPUT')


def _configure_squeeze_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    defn = dict(defn or {'key': 'squeeze_modifier', 'backend': 'squeeze_nodes', 'label': 'Squeeze Modifier', 'category': 'Deform'})
    group = _make_squeeze_group(obj, defn, context=context) if group is None or force_unique_group else group
    if group is None:
        # Do not stamp a Squeeze row or create its helper when the dedicated
        # graph could not be built.  The caller can remove the unconfigured
        # modifier through the normal failed-add path.
        return None
    try:
        mod.node_group = group
        mod['smsm_generic_modifier'] = True
        mod[SQUEEZE_MARKER_PROP] = True
        mod[BACKEND_PROP] = 'squeeze_nodes'
        mod[SQUEEZE_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
    except Exception:
        pass
    gizmo = _make_generic_gizmo(obj, defn, getattr(mod, 'name', ''), context=context)
    if gizmo is not None:
        try:
            mod[GENERIC_GIZMO_NAME_PROP] = gizmo.name
        except Exception:
            pass
    for key, fallback, value in (('gizmo', 'Gizmo', gizmo), ('squeeze', 'Squeeze', 0.0), ('squeeze_curve', 'Squeeze Curve', 1.0), ('bulge', 'Bulge', 0.0), ('bulge_curve', 'Bulge Curve', 1.0), ('influence', 'Influence', 1.0), ('use_limits', 'Use Limits', False), ('lower_limit', 'Lower Limit', -1.0), ('upper_limit', 'Upper Limit', 1.0), ('bias', 'Bias', 0.0), ('volume', 'Volume', 100.0)):
        try:
            socket = _squeeze_socket(group, key, fallback)
            sid = str(getattr(socket, 'identifier', '') or getattr(socket, 'name', '') or '')
            if sid:
                mod[SQUEEZE_SOCKET_PREFIX + key] = sid
            _set_modifier_socket_value(mod, socket, value)
        except Exception:
            pass
    return gizmo


def _make_melt_gizmo(obj, defn, mod_name: str, context=None):
    gizmo = _make_generic_gizmo(obj, defn, mod_name, context=context)
    if gizmo is None:
        return None
    try:
        corners = [Vector(corner) for corner in getattr(obj, 'bound_box', ()) or ()]
        if corners:
            minimum = Vector(tuple(min(point[index] for point in corners) for index in range(3)))
            maximum = Vector(tuple(max(point[index] for point in corners) for index in range(3)))
            center = (minimum + maximum) * 0.5
            half = (maximum - minimum) * 0.5
            half = Vector(tuple(max(abs(float(value)), 1.0e-4) for value in half))
            scale_matrix = Matrix.Diagonal((half.x, half.y, half.z, 1.0))
            gizmo.matrix_world = obj.matrix_world @ Matrix.Translation(center) @ scale_matrix
        gizmo.empty_display_type = 'CUBE'
        gizmo.empty_display_size = 1.0
    except Exception:
        pass
    return gizmo


def _make_melt_group(obj, defn=None, context=None):
    """Build a dedicated bounded gizmo-space approximation of 3ds Max Melt."""
    label = str((defn or {}).get('label') or 'Melt Modifier')
    name = unique_name(f"SMS Max {label} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        group.is_modifier = True
        nodes = group.nodes
        group_input = nodes.new('NodeGroupInput')
        group_output = nodes.new('NodeGroupOutput')
        position = nodes.new('GeometryNodeInputPosition')
        self_object = nodes.new('GeometryNodeSelfObject')
        object_info = nodes.new('GeometryNodeObjectInfo')
        gizmo_info = nodes.new('GeometryNodeObjectInfo')
        object_to_world = nodes.new('FunctionNodeTransformPoint')
        invert_object = nodes.new('FunctionNodeInvertMatrix')
        invert_gizmo = nodes.new('FunctionNodeInvertMatrix')
        world_to_gizmo = nodes.new('FunctionNodeTransformPoint')
        separate = nodes.new('ShaderNodeSeparateXYZ')
        axis_value = nodes.new('GeometryNodeIndexSwitch')
        radial_x = nodes.new('ShaderNodeCombineXYZ')
        radial_y = nodes.new('ShaderNodeCombineXYZ')
        radial_z = nodes.new('ShaderNodeCombineXYZ')
        radial_vector = nodes.new('GeometryNodeIndexSwitch')
        radial_length = nodes.new('ShaderNodeVectorMath')
        radial_normalize = nodes.new('ShaderNodeMath')
        radial_clamp = nodes.new('ShaderNodeMath')
        amount_percent = nodes.new('ShaderNodeMath')
        amount_influence = nodes.new('ShaderNodeMath')
        amount_nonnegative = nodes.new('ShaderNodeMath')
        collapse_amount = nodes.new('ShaderNodeMath')
        amount_active = nodes.new('FunctionNodeCompare')
        default_distance = nodes.new('ShaderNodeMath')
        flipped_distance = nodes.new('ShaderNodeMath')
        distance_switch = nodes.new('GeometryNodeSwitch')
        height_normalize = nodes.new('ShaderNodeMath')
        height_nonnegative = nodes.new('ShaderNodeMath')
        height_clamp = nodes.new('ShaderNodeMath')
        custom_solidity = nodes.new('ShaderNodeMath')
        solidity = nodes.new('GeometryNodeIndexSwitch')
        solidity_denominator = nodes.new('ShaderNodeMath')
        solidity_hold = nodes.new('ShaderNodeMath')
        center_weight = nodes.new('ShaderNodeMath')
        preserve_center = nodes.new('ShaderNodeMath')
        preserve_solidity = nodes.new('ShaderNodeMath')
        one_minus_collapse = nodes.new('ShaderNodeMath')
        height_factor = nodes.new('ShaderNodeMath')
        new_distance = nodes.new('ShaderNodeMath')
        new_axis_default = nodes.new('ShaderNodeMath')
        new_axis_flipped = nodes.new('ShaderNodeMath')
        new_axis_switch = nodes.new('GeometryNodeSwitch')
        spread_percent = nodes.new('ShaderNodeMath')
        spread_amount = nodes.new('ShaderNodeMath')
        floor_weight = nodes.new('ShaderNodeMath')
        floor_spread = nodes.new('ShaderNodeMath')
        spread_factor = nodes.new('ShaderNodeMath')
        scaled_x = nodes.new('ShaderNodeMath')
        scaled_y = nodes.new('ShaderNodeMath')
        scaled_z = nodes.new('ShaderNodeMath')
        axis_x = nodes.new('ShaderNodeCombineXYZ')
        axis_y = nodes.new('ShaderNodeCombineXYZ')
        axis_z = nodes.new('ShaderNodeCombineXYZ')
        deformed_local = nodes.new('GeometryNodeIndexSwitch')
        gizmo_to_world = nodes.new('FunctionNodeTransformPoint')
        world_to_object = nodes.new('FunctionNodeTransformPoint')
        set_position = nodes.new('GeometryNodeSetPosition')
        geometry_switch = nodes.new('GeometryNodeSwitch')

        for node, operation in (
            (radial_length, 'LENGTH'),
            (radial_normalize, 'DIVIDE'), (radial_clamp, 'MINIMUM'),
            (amount_percent, 'DIVIDE'), (amount_influence, 'MULTIPLY'),
            (amount_nonnegative, 'MAXIMUM'), (collapse_amount, 'MINIMUM'),
            (default_distance, 'ADD'), (flipped_distance, 'SUBTRACT'),
            (height_normalize, 'DIVIDE'), (height_nonnegative, 'MAXIMUM'),
            (height_clamp, 'MINIMUM'), (custom_solidity, 'MAXIMUM'),
            (solidity_denominator, 'ADD'), (solidity_hold, 'DIVIDE'),
            (center_weight, 'SUBTRACT'), (preserve_center, 'MULTIPLY'),
            (preserve_solidity, 'MULTIPLY'), (one_minus_collapse, 'SUBTRACT'),
            (height_factor, 'ADD'), (new_distance, 'MULTIPLY'),
            (new_axis_default, 'ADD'), (new_axis_flipped, 'SUBTRACT'),
            (spread_percent, 'DIVIDE'), (spread_amount, 'MULTIPLY'),
            (floor_weight, 'SUBTRACT'), (floor_spread, 'MULTIPLY'),
            (spread_factor, 'ADD'), (scaled_x, 'MULTIPLY'),
            (scaled_y, 'MULTIPLY'), (scaled_z, 'MULTIPLY'),
        ):
            node.operation = operation
        axis_value.data_type = 'FLOAT'
        radial_vector.data_type = 'VECTOR'
        deformed_local.data_type = 'VECTOR'
        solidity.data_type = 'FLOAT'
        for node, count in ((axis_value, 3), (radial_vector, 3), (deformed_local, 3), (solidity, 5)):
            while len(node.index_switch_items) < count:
                node.index_switch_items.new()
        distance_switch.input_type = 'FLOAT'
        new_axis_switch.input_type = 'FLOAT'
        geometry_switch.input_type = 'GEOMETRY'
        amount_active.data_type = 'FLOAT'
        amount_active.operation = 'GREATER_THAN'
        amount_active.inputs[1].default_value = 0.0
        radial_normalize.inputs[1].default_value = 1.41421356237
        radial_clamp.inputs[1].default_value = 1.0
        amount_percent.inputs[1].default_value = 100.0
        amount_nonnegative.inputs[1].default_value = 0.0
        collapse_amount.inputs[1].default_value = 1.0
        default_distance.inputs[1].default_value = 1.0
        flipped_distance.inputs[0].default_value = 1.0
        height_normalize.inputs[1].default_value = 2.0
        height_nonnegative.inputs[1].default_value = 0.0
        height_clamp.inputs[1].default_value = 1.0
        custom_solidity.inputs[1].default_value = 0.2
        solidity_denominator.inputs[1].default_value = 1.0
        center_weight.inputs[0].default_value = 1.0
        one_minus_collapse.inputs[0].default_value = 1.0
        new_axis_default.inputs[0].default_value = -1.0
        new_axis_flipped.inputs[0].default_value = 1.0
        spread_percent.inputs[1].default_value = 100.0
        floor_weight.inputs[0].default_value = 1.0
        spread_factor.inputs[0].default_value = 1.0
        for index, value in enumerate((1.0, 10.0, 0.2, 0.5)):
            _set_socket_default(_socket_by_name(solidity.inputs, (), index + 1), value)
        group_output.is_active_output = True

        geometry_type = _socket_type_from_node_socket(_socket_by_name(set_position.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type, description=choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
        sockets = {
            'gizmo': _add_interface_socket(group, name='Gizmo', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Melt gizmo. Its transform defines the local melt bounds, center, and axis basis.', 'メルトギズモです。変換がローカルの溶解範囲、中心、軸基準を定義します。', context=context)),
            'amount': _add_interface_socket(group, name='Melt Amount', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Melt amount from 0 to 1000. Values above 100 continue spreading without inverting the mesh.', '0 から 1000 のメルト量です。100 を超える値はメッシュを反転させずに広がりを継続します。', context=context)),
            'spread': _add_interface_socket(group, name='Spread', in_out='INPUT', socket_type='NodeSocketFloat', default=19.0, description=choose_text('Percentage of melt used to spread the object along the plane perpendicular to the melt axis.', 'メルト軸に直交する平面へオブジェクトを広げるメルト比率です。', context=context)),
            'preset': _add_interface_socket(group, name='Solidity Preset', in_out='INPUT', socket_type='NodeSocketInt', default=0, description=choose_text('0 Ice, 1 Glass, 2 Jelly, 3 Plastic, 4 Custom.', '0 氷、1 ガラス、2 ゼリー、3 プラスチック、4 カスタムです。', context=context)),
            'custom_solidity': _add_interface_socket(group, name='Custom Solidity', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Custom solidity from 0.2 to 30.', '0.2 から 30 のカスタムソリディティです。', context=context)),
            'axis': _add_interface_socket(group, name='Melt Axis', in_out='INPUT', socket_type='NodeSocketInt', default=2, description=choose_text('0 X, 1 Y, 2 Z in gizmo-local space.', 'ギズモローカル空間で 0 X、1 Y、2 Z です。', context=context)),
            'flip_axis': _add_interface_socket(group, name='Flip Axis', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Reverse the melt direction.', 'メルト方向を反転します。', context=context)),
            'influence': _add_interface_socket(group, name='Influence', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Overall non-destructive influence.', '全体の非破壊影響度です。', context=context)),
        }
        sockets['amount'].min_value = 0.0
        sockets['amount'].max_value = 1000.0
        sockets['custom_solidity'].min_value = 0.2
        sockets['custom_solidity'].max_value = 30.0
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=geometry_type, description=choose_text('Melt-deformed geometry.', 'メルト変形後のジオメトリです。', context=context))

        _link_node_sockets(group, _socket_by_name(self_object.outputs, ('Self Object', 'Object'), 0), _socket_by_name(object_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Gizmo',), 1), _socket_by_name(gizmo_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(position.outputs, ('Position',), 0), _socket_by_name(object_to_world.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(object_to_world.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(invert_object.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Transform',), 4), _socket_by_name(invert_gizmo.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(object_to_world.outputs, ('Point', 'Vector'), 0), _socket_by_name(world_to_gizmo.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_gizmo.outputs, (), 0), _socket_by_name(world_to_gizmo.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(world_to_gizmo.outputs, ('Point', 'Vector'), 0), _socket_by_name(separate.inputs, ('Vector',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Melt Axis',), 5), _socket_by_name(axis_value.inputs, ('Index',), 0))
        for index, component in enumerate(('X', 'Y', 'Z')):
            _link_node_sockets(group, _socket_by_name(separate.outputs, (component,), index), _socket_by_name(axis_value.inputs, (), index + 1))

        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Y',), 1), _socket_by_name(radial_x.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Z',), 2), _socket_by_name(radial_x.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('X',), 0), _socket_by_name(radial_y.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Z',), 2), _socket_by_name(radial_y.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('X',), 0), _socket_by_name(radial_z.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(separate.outputs, ('Y',), 1), _socket_by_name(radial_z.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Melt Axis',), 5), _socket_by_name(radial_vector.inputs, ('Index',), 0))
        for index, node in enumerate((radial_x, radial_y, radial_z)):
            _link_node_sockets(group, _socket_by_name(node.outputs, ('Vector',), 0), _socket_by_name(radial_vector.inputs, (), index + 1))
        _link_node_sockets(group, _socket_by_name(radial_vector.outputs, (), 0), _socket_by_name(radial_length.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(radial_length.outputs, ('Value',), 1), _socket_by_name(radial_normalize.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(radial_normalize.outputs, (), 0), _socket_by_name(radial_clamp.inputs, (), 0))

        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Melt Amount',), 2), _socket_by_name(amount_percent.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(amount_percent.outputs, (), 0), _socket_by_name(amount_influence.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Influence',), 7), _socket_by_name(amount_influence.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(amount_influence.outputs, (), 0), _socket_by_name(amount_nonnegative.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(amount_nonnegative.outputs, (), 0), _socket_by_name(collapse_amount.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(amount_nonnegative.outputs, (), 0), _socket_by_name(amount_active.inputs, (), 0))

        _link_node_sockets(group, _socket_by_name(axis_value.outputs, (), 0), _socket_by_name(default_distance.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(axis_value.outputs, (), 0), _socket_by_name(flipped_distance.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Flip Axis',), 6), _socket_by_name(distance_switch.inputs, ('Switch',), 0))
        _link_node_sockets(group, _socket_by_name(default_distance.outputs, (), 0), _socket_by_name(distance_switch.inputs, ('False',), 1))
        _link_node_sockets(group, _socket_by_name(flipped_distance.outputs, (), 0), _socket_by_name(distance_switch.inputs, ('True',), 2))
        _link_node_sockets(group, _socket_by_name(distance_switch.outputs, ('Output',), 0), _socket_by_name(height_normalize.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(height_normalize.outputs, (), 0), _socket_by_name(height_nonnegative.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(height_nonnegative.outputs, (), 0), _socket_by_name(height_clamp.inputs, (), 0))

        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Custom Solidity',), 4), _socket_by_name(custom_solidity.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Solidity Preset',), 3), _socket_by_name(solidity.inputs, ('Index',), 0))
        _link_node_sockets(group, _socket_by_name(custom_solidity.outputs, (), 0), _socket_by_name(solidity.inputs, (), 5))
        _link_node_sockets(group, _socket_by_name(solidity.outputs, (), 0), _socket_by_name(solidity_denominator.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(solidity.outputs, (), 0), _socket_by_name(solidity_hold.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(solidity_denominator.outputs, (), 0), _socket_by_name(solidity_hold.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(radial_clamp.outputs, (), 0), _socket_by_name(center_weight.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(collapse_amount.outputs, (), 0), _socket_by_name(preserve_center.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(center_weight.outputs, (), 0), _socket_by_name(preserve_center.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(preserve_center.outputs, (), 0), _socket_by_name(preserve_solidity.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(solidity_hold.outputs, (), 0), _socket_by_name(preserve_solidity.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(collapse_amount.outputs, (), 0), _socket_by_name(one_minus_collapse.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(one_minus_collapse.outputs, (), 0), _socket_by_name(height_factor.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(preserve_solidity.outputs, (), 0), _socket_by_name(height_factor.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(distance_switch.outputs, ('Output',), 0), _socket_by_name(new_distance.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(height_factor.outputs, (), 0), _socket_by_name(new_distance.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(new_distance.outputs, (), 0), _socket_by_name(new_axis_default.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(new_distance.outputs, (), 0), _socket_by_name(new_axis_flipped.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Flip Axis',), 6), _socket_by_name(new_axis_switch.inputs, ('Switch',), 0))
        _link_node_sockets(group, _socket_by_name(new_axis_default.outputs, (), 0), _socket_by_name(new_axis_switch.inputs, ('False',), 1))
        _link_node_sockets(group, _socket_by_name(new_axis_flipped.outputs, (), 0), _socket_by_name(new_axis_switch.inputs, ('True',), 2))

        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Spread',), 3), _socket_by_name(spread_percent.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(amount_nonnegative.outputs, (), 0), _socket_by_name(spread_amount.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(spread_percent.outputs, (), 0), _socket_by_name(spread_amount.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(height_clamp.outputs, (), 0), _socket_by_name(floor_weight.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(spread_amount.outputs, (), 0), _socket_by_name(floor_spread.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(floor_weight.outputs, (), 0), _socket_by_name(floor_spread.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(floor_spread.outputs, (), 0), _socket_by_name(spread_factor.inputs, (), 1))
        for component, node in zip(('X', 'Y', 'Z'), (scaled_x, scaled_y, scaled_z)):
            _link_node_sockets(group, _socket_by_name(separate.outputs, (component,), ('X', 'Y', 'Z').index(component)), _socket_by_name(node.inputs, (), 0))
            _link_node_sockets(group, _socket_by_name(spread_factor.outputs, (), 0), _socket_by_name(node.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(new_axis_switch.outputs, ('Output',), 0), _socket_by_name(axis_x.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(scaled_y.outputs, (), 0), _socket_by_name(axis_x.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(scaled_z.outputs, (), 0), _socket_by_name(axis_x.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(scaled_x.outputs, (), 0), _socket_by_name(axis_y.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(new_axis_switch.outputs, ('Output',), 0), _socket_by_name(axis_y.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(scaled_z.outputs, (), 0), _socket_by_name(axis_y.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(scaled_x.outputs, (), 0), _socket_by_name(axis_z.inputs, ('X',), 0))
        _link_node_sockets(group, _socket_by_name(scaled_y.outputs, (), 0), _socket_by_name(axis_z.inputs, ('Y',), 1))
        _link_node_sockets(group, _socket_by_name(new_axis_switch.outputs, ('Output',), 0), _socket_by_name(axis_z.inputs, ('Z',), 2))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Melt Axis',), 5), _socket_by_name(deformed_local.inputs, ('Index',), 0))
        for index, node in enumerate((axis_x, axis_y, axis_z)):
            _link_node_sockets(group, _socket_by_name(node.outputs, ('Vector',), 0), _socket_by_name(deformed_local.inputs, (), index + 1))
        _link_node_sockets(group, _socket_by_name(deformed_local.outputs, (), 0), _socket_by_name(gizmo_to_world.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(gizmo_info.outputs, ('Transform',), 4), _socket_by_name(gizmo_to_world.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(gizmo_to_world.outputs, ('Point', 'Vector'), 0), _socket_by_name(world_to_object.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_object.outputs, (), 0), _socket_by_name(world_to_object.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
        _link_node_sockets(group, _socket_by_name(world_to_object.outputs, ('Point', 'Vector'), 0), _socket_by_name(set_position.inputs, ('Position',), 2))
        _link_node_sockets(group, _socket_by_name(amount_active.outputs, ('Result',), 0), _socket_by_name(geometry_switch.inputs, ('Switch',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(geometry_switch.inputs, ('False',), 1))
        _link_node_sockets(group, _socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(geometry_switch.inputs, ('True',), 2))
        _link_node_sockets(group, _socket_by_name(geometry_switch.outputs, ('Output',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))
        group[MELT_GRAPH_CONTRACT_PROP] = 'dedicated_gizmo_space_melt_v1'
        for key, socket in sockets.items():
            group[MELT_SOCKET_PREFIX + key] = str(getattr(socket, 'identifier', '') or '')
        return group
    except Exception:
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _melt_socket(group, key: str, fallback_name: str):
    stored = str(group.get(MELT_SOCKET_PREFIX + str(key), '') or '') if group is not None else ''
    return _find_interface_socket(group, stored or fallback_name, 'INPUT')


def _configure_melt_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    defn = dict(defn or {'key': 'melt_modifier', 'backend': 'melt_nodes', 'label': 'Melt Modifier', 'category': 'Deform'})
    group = _make_melt_group(obj, defn, context=context) if group is None or force_unique_group else group
    try:
        mod.node_group = group
        mod[MELT_MARKER_PROP] = True
        mod[BACKEND_PROP] = 'melt_nodes'
        mod[MELT_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod['smsm_generic_modifier'] = True
        mod[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
    except Exception:
        pass
    try:
        gizmo = bpy.data.objects.get(str(mod.get(GENERIC_GIZMO_NAME_PROP, '') or ''))
    except Exception:
        gizmo = None
    if gizmo is None:
        gizmo = _make_melt_gizmo(obj, defn, getattr(mod, 'name', ''), context=context)
    if gizmo is not None:
        try:
            mod[GENERIC_GIZMO_NAME_PROP] = gizmo.name
        except Exception:
            pass
    defaults = (
        ('gizmo', 'Gizmo', gizmo), ('amount', 'Melt Amount', 0.0),
        ('spread', 'Spread', 19.0), ('preset', 'Solidity Preset', 0),
        ('custom_solidity', 'Custom Solidity', 1.0), ('axis', 'Melt Axis', 2),
        ('flip_axis', 'Flip Axis', False), ('influence', 'Influence', 1.0),
    )
    for key, fallback, value in defaults:
        try:
            socket = _melt_socket(group, key, fallback)
            sid = str(getattr(socket, 'identifier', '') or getattr(socket, 'name', '') or '')
            if sid:
                mod[MELT_SOCKET_PREFIX + key] = sid
                if key == 'gizmo':
                    mod[GENERIC_GIZMO_SOCKET_PROP] = sid
            existing = bool(sid and sid in mod)
            current = mod.get(sid) if existing else None
            if not existing or (key == 'gizmo' and current is None):
                _set_modifier_socket_value(mod, socket, value)
        except Exception:
            pass
    return gizmo


def _draw_melt_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get(MELT_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    box = layout.box()
    draw_help_header(box, context, choose_text('Melt Controls', 'メルト制御', context=context), 'MOD_SIMPLEDEFORM', 'max_melt_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    gizmo_sid = str(mod.get(MELT_SOCKET_PREFIX + 'gizmo', '') or '')
    if gizmo_sid:
        row = col.row(align=True)
        row.prop(mod, f'["{gizmo_sid}"]', text=choose_text('Gizmo', 'ギズモ', context=context))
        op = row.operator('smsm.max_generic_select_gizmo', text='', icon='EMPTY_AXIS')
        op.object_name = obj_name
        op.modifier_name = mod_name
        op.gizmo_property = GENERIC_GIZMO_NAME_PROP
    for key, en, ja in (('amount', 'Melt Amount', 'メルト量'), ('spread', 'Spread', '広がり')):
        sid = str(mod.get(MELT_SOCKET_PREFIX + key, '') or '')
        if sid:
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
    preset_sid = str(mod.get(MELT_SOCKET_PREFIX + 'preset', '') or '')
    preset = int(mod.get(preset_sid, 0) or 0) if preset_sid else 0
    row = col.row(align=True)
    row.label(text=choose_text('Solidity', 'ソリディティ', context=context))
    for value, en, ja in ((0, 'Ice', '氷'), (1, 'Glass', 'ガラス'), (2, 'Jelly', 'ゼリー'), (3, 'Plastic', 'プラスチック'), (4, 'Custom', 'カスタム')):
        op = row.operator('smsm.max_melt_set_enum', text=choose_text(en, ja, context=context), depress=(preset == value))
        op.object_name = obj_name
        op.modifier_name = mod_name
        op.field = 'PRESET'
        op.value = value
    if preset == 4:
        sid = str(mod.get(MELT_SOCKET_PREFIX + 'custom_solidity', '') or '')
        if sid:
            col.prop(mod, f'["{sid}"]', text=choose_text('Custom Solidity', 'カスタムソリディティ', context=context))
    axis_sid = str(mod.get(MELT_SOCKET_PREFIX + 'axis', '') or '')
    axis = int(mod.get(axis_sid, 2) or 0) if axis_sid else 2
    row = col.row(align=True)
    row.label(text=choose_text('Axis To Melt', 'メルト軸', context=context))
    for value, label in ((0, 'X'), (1, 'Y'), (2, 'Z')):
        op = row.operator('smsm.max_melt_set_enum', text=label, depress=(axis == value))
        op.object_name = obj_name
        op.modifier_name = mod_name
        op.field = 'AXIS'
        op.value = value
    for key, en, ja in (('flip_axis', 'Flip Axis', '軸を反転'), ('influence', 'Influence', '影響度')):
        sid = str(mod.get(MELT_SOCKET_PREFIX + key, '') or '')
        if sid:
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
    return True


def _make_affect_region_group(obj, defn=None, context=None):
    """Build a dedicated two-point Affect Region deformation graph."""
    label = str((defn or {}).get('label') or 'Affect Region Modifier')
    name = unique_name(f"SMS Max {label} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        group.is_modifier = True
        nodes = group.nodes
        group_input = nodes.new('NodeGroupInput')
        group_output = nodes.new('NodeGroupOutput')
        position = nodes.new('GeometryNodeInputPosition')
        normal = nodes.new('GeometryNodeInputNormal')
        self_object = nodes.new('GeometryNodeSelfObject')
        object_info = nodes.new('GeometryNodeObjectInfo')
        start_info = nodes.new('GeometryNodeObjectInfo')
        end_info = nodes.new('GeometryNodeObjectInfo')
        invert_object = nodes.new('FunctionNodeInvertMatrix')
        start_to_object = nodes.new('FunctionNodeTransformPoint')
        end_to_object = nodes.new('FunctionNodeTransformPoint')
        direction = nodes.new('ShaderNodeVectorMath')
        distance = nodes.new('ShaderNodeVectorMath')
        safe_falloff = nodes.new('ShaderNodeMath')
        normalized_distance = nodes.new('ShaderNodeMath')
        clamp_distance = nodes.new('ShaderNodeMath')
        one_minus = nodes.new('ShaderNodeMath')
        t_squared = nodes.new('ShaderNodeMath')
        two_t = nodes.new('ShaderNodeMath')
        three_minus_two_t = nodes.new('ShaderNodeMath')
        smooth_weight = nodes.new('ShaderNodeMath')
        pinch_shape = nodes.new('ShaderNodeMath')
        pinch_scale = nodes.new('ShaderNodeMath')
        pinch_value = nodes.new('ShaderNodeMath')
        without_pinch = nodes.new('ShaderNodeMath')
        bubble_shape = nodes.new('ShaderNodeMath')
        bubble_curve = nodes.new('ShaderNodeMath')
        bubble_scale = nodes.new('ShaderNodeMath')
        bubble_value = nodes.new('ShaderNodeMath')
        shaped_weight = nodes.new('ShaderNodeMath')
        influenced_weight = nodes.new('ShaderNodeMath')
        normalized_direction = nodes.new('ShaderNodeVectorMath')
        normal_dot = nodes.new('ShaderNodeVectorMath')
        front_facing = nodes.new('ShaderNodeMath')
        not_ignore = nodes.new('FunctionNodeBooleanMath')
        selection = nodes.new('FunctionNodeBooleanMath')
        weighted_offset = nodes.new('ShaderNodeVectorMath')
        set_position = nodes.new('GeometryNodeSetPosition')

        direction.operation = 'SUBTRACT'
        distance.operation = 'DISTANCE'
        normalized_direction.operation = 'NORMALIZE'
        normal_dot.operation = 'DOT_PRODUCT'
        weighted_offset.operation = 'SCALE'
        for node, operation in (
            (safe_falloff, 'MAXIMUM'), (normalized_distance, 'DIVIDE'),
            (clamp_distance, 'MINIMUM'), (one_minus, 'SUBTRACT'),
            (t_squared, 'MULTIPLY'), (two_t, 'MULTIPLY'),
            (three_minus_two_t, 'SUBTRACT'), (smooth_weight, 'MULTIPLY'),
            (pinch_shape, 'MULTIPLY'), (pinch_scale, 'MULTIPLY'),
            (pinch_value, 'MULTIPLY'), (without_pinch, 'SUBTRACT'),
            (bubble_shape, 'MULTIPLY'), (bubble_curve, 'MULTIPLY'),
            (bubble_scale, 'MULTIPLY'),
            (bubble_value, 'MULTIPLY'), (shaped_weight, 'ADD'),
            (influenced_weight, 'MULTIPLY'), (front_facing, 'GREATER_THAN'),
        ):
            node.operation = operation
        not_ignore.operation = 'NOT'
        selection.operation = 'OR'
        safe_falloff.inputs[1].default_value = 0.000001
        clamp_distance.inputs[1].default_value = 1.0
        one_minus.inputs[0].default_value = 1.0
        two_t.inputs[1].default_value = 2.0
        three_minus_two_t.inputs[0].default_value = 3.0
        pinch_scale.inputs[1].default_value = 3.0
        bubble_scale.inputs[1].default_value = 3.0
        front_facing.inputs[1].default_value = 0.0
        group_output.is_active_output = True

        geometry_type = _socket_type_from_node_socket(_socket_by_name(set_position.inputs, ('Geometry',), 0), 'NodeSocketGeometry')
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type=geometry_type, description=choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
        sockets = {
            'start': _add_interface_socket(group, name='Start Point', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Base point of the Affect Region arrow.', '影響領域矢印の開始点です。', context=context)),
            'end': _add_interface_socket(group, name='End Point', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Tip point that defines displacement direction and amount.', '変位の方向と量を定義する終点です。', context=context)),
            'falloff': _add_interface_socket(group, name='Falloff', in_out='INPUT', socket_type='NodeSocketFloat', default=20.0, description=choose_text('Radius affected from the start point.', '開始点から影響する半径です。', context=context)),
            'pinch': _add_interface_socket(group, name='Pinch', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Sharpens or dimples the curve near the tip.', '先端付近のカーブを尖らせる、またはくぼませます。', context=context)),
            'bubble': _add_interface_socket(group, name='Bubble', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Changes the fullness of the radial falloff curve.', '半径減衰カーブの膨らみを変更します。', context=context)),
            'influence': _add_interface_socket(group, name='Influence', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Overall non-destructive influence.', '全体の非破壊影響度です。', context=context)),
            'ignore_back_facing': _add_interface_socket(group, name='Ignore Back Facing', in_out='INPUT', socket_type='NodeSocketBool', default=False, description=choose_text('Only deform points whose adapted normal faces the arrow direction.', '補間された法線が矢印方向を向く点だけを変形します。', context=context)),
        }
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type=geometry_type, description=choose_text('Output geometry.', '出力ジオメトリです。', context=context))

        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
        _link_node_sockets(group, _socket_by_name(self_object.outputs, ('Self Object', 'Object'), 0), _socket_by_name(object_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Transform',), 4), _socket_by_name(invert_object.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Start Point',), 1), _socket_by_name(start_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('End Point',), 2), _socket_by_name(end_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(start_info.outputs, ('Location',), 1), _socket_by_name(start_to_object.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_object.outputs, (), 0), _socket_by_name(start_to_object.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(end_info.outputs, ('Location',), 1), _socket_by_name(end_to_object.inputs, ('Point', 'Vector'), 0))
        _link_node_sockets(group, _socket_by_name(invert_object.outputs, (), 0), _socket_by_name(end_to_object.inputs, ('Transform', 'Matrix'), 1))
        _link_node_sockets(group, _socket_by_name(end_to_object.outputs, ('Point', 'Vector'), 0), _socket_by_name(direction.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(start_to_object.outputs, ('Point', 'Vector'), 0), _socket_by_name(direction.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(position.outputs, ('Position',), 0), _socket_by_name(distance.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(start_to_object.outputs, ('Point', 'Vector'), 0), _socket_by_name(distance.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Falloff',), 3), _socket_by_name(safe_falloff.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(distance.outputs, ('Value',), 1), _socket_by_name(normalized_distance.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(safe_falloff.outputs, ('Value',), 0), _socket_by_name(normalized_distance.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(normalized_distance.outputs, ('Value',), 0), _socket_by_name(clamp_distance.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(clamp_distance.outputs, ('Value',), 0), _socket_by_name(one_minus.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(one_minus.outputs, ('Value',), 0), _socket_by_name(t_squared.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(one_minus.outputs, ('Value',), 0), _socket_by_name(t_squared.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(one_minus.outputs, ('Value',), 0), _socket_by_name(two_t.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(two_t.outputs, ('Value',), 0), _socket_by_name(three_minus_two_t.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(t_squared.outputs, ('Value',), 0), _socket_by_name(smooth_weight.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(three_minus_two_t.outputs, ('Value',), 0), _socket_by_name(smooth_weight.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(clamp_distance.outputs, ('Value',), 0), _socket_by_name(pinch_shape.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(t_squared.outputs, ('Value',), 0), _socket_by_name(pinch_shape.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(pinch_shape.outputs, ('Value',), 0), _socket_by_name(pinch_scale.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(pinch_scale.outputs, ('Value',), 0), _socket_by_name(pinch_value.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Pinch',), 4), _socket_by_name(pinch_value.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(smooth_weight.outputs, ('Value',), 0), _socket_by_name(without_pinch.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(pinch_value.outputs, ('Value',), 0), _socket_by_name(without_pinch.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(clamp_distance.outputs, ('Value',), 0), _socket_by_name(bubble_shape.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(one_minus.outputs, ('Value',), 0), _socket_by_name(bubble_shape.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(bubble_shape.outputs, ('Value',), 0), _socket_by_name(bubble_curve.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(clamp_distance.outputs, ('Value',), 0), _socket_by_name(bubble_curve.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(bubble_curve.outputs, ('Value',), 0), _socket_by_name(bubble_scale.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(bubble_scale.outputs, ('Value',), 0), _socket_by_name(bubble_value.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Bubble',), 5), _socket_by_name(bubble_value.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(without_pinch.outputs, ('Value',), 0), _socket_by_name(shaped_weight.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(bubble_value.outputs, ('Value',), 0), _socket_by_name(shaped_weight.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(shaped_weight.outputs, ('Value',), 0), _socket_by_name(influenced_weight.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Influence',), 6), _socket_by_name(influenced_weight.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(direction.outputs, ('Vector',), 0), _socket_by_name(normalized_direction.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(normal.outputs, ('Normal',), 0), _socket_by_name(normal_dot.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(normalized_direction.outputs, ('Vector',), 0), _socket_by_name(normal_dot.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(normal_dot.outputs, ('Value',), 1), _socket_by_name(front_facing.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Ignore Back Facing',), 7), _socket_by_name(not_ignore.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(not_ignore.outputs, ('Boolean',), 0), _socket_by_name(selection.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(front_facing.outputs, ('Value',), 0), _socket_by_name(selection.inputs, (), 1))
        _link_node_sockets(group, _socket_by_name(selection.outputs, ('Boolean',), 0), _socket_by_name(set_position.inputs, ('Selection',), 1))
        _link_node_sockets(group, _socket_by_name(direction.outputs, ('Vector',), 0), _socket_by_name(weighted_offset.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(influenced_weight.outputs, ('Value',), 0), _socket_by_name(weighted_offset.inputs, ('Scale',), 3))
        _link_node_sockets(group, _socket_by_name(weighted_offset.outputs, ('Vector',), 0), _socket_by_name(set_position.inputs, ('Offset',), 3))
        _link_node_sockets(group, _socket_by_name(set_position.outputs, ('Geometry',), 0), _socket_by_name(group_output.inputs, ('Geometry',), 0))

        group[AFFECT_REGION_GRAPH_CONTRACT_PROP] = 'dedicated_two_point_affect_region_v1'
        for key, socket in sockets.items():
            group[AFFECT_REGION_SOCKET_PREFIX + key] = str(getattr(socket, 'identifier', '') or '')
        return group
    except Exception:
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _affect_region_socket(group, key: str, fallback_name: str):
    stored = str(group.get(AFFECT_REGION_SOCKET_PREFIX + str(key), '') or '') if group is not None else ''
    return _find_interface_socket(group, stored or fallback_name, 'INPUT')


def _make_affect_region_point(obj, defn, mod_name: str, role: str, context=None):
    point = _make_generic_gizmo(obj, defn, mod_name, context=context)
    if point is None:
        return None
    role = 'END' if str(role).upper() == 'END' else 'START'
    try:
        point[AFFECT_REGION_POINT_ROLE_PROP] = role
        point['smsm_internal_helper'] = True
        point.empty_display_type = 'SINGLE_ARROW' if role == 'END' else 'SPHERE'
        point.empty_display_size = 0.4 if role == 'END' else 0.25
    except Exception:
        pass
    if role == 'END':
        try:
            direction = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
            if direction.length <= 0.000001:
                direction = Vector((0.0, 0.0, 1.0))
            direction.normalize()
            span = max(1.0, max((abs(float(v)) for v in getattr(obj, 'dimensions', (1.0, 1.0, 1.0))), default=1.0) * 0.5)
            point.location = _generic_bounds_center_world(obj) + direction * span
        except Exception:
            pass
    return point


def _configure_affect_region_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    defn = dict(defn or {'key': 'affect_region_modifier', 'backend': 'affect_region_nodes', 'label': 'Affect Region Modifier', 'category': 'Deform'})
    preserved = {}
    for key in ('falloff', 'pinch', 'bubble', 'influence', 'ignore_back_facing'):
        try:
            sid = str(mod.get(AFFECT_REGION_SOCKET_PREFIX + key, '') or '')
            if sid and sid in mod:
                preserved[key] = mod.get(sid)
        except Exception:
            pass
    if group is None or force_unique_group:
        group = _make_affect_region_group(obj, defn, context=context)
    try:
        mod.node_group = group
        mod[AFFECT_REGION_MARKER_PROP] = True
        mod['smsm_generic_modifier'] = True
        mod[BACKEND_PROP] = 'affect_region_nodes'
        mod[AFFECT_REGION_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_KIND_PROP] = 'deform'
        mod[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
    except Exception:
        pass
    try:
        start = bpy.data.objects.get(str(mod.get(AFFECT_REGION_START_NAME_PROP, '') or ''))
    except Exception:
        start = None
    try:
        end = bpy.data.objects.get(str(mod.get(AFFECT_REGION_END_NAME_PROP, '') or ''))
    except Exception:
        end = None
    if start is None:
        start = _make_affect_region_point(obj, defn, getattr(mod, 'name', ''), 'START', context=context)
    if end is None:
        end = _make_affect_region_point(obj, defn, getattr(mod, 'name', ''), 'END', context=context)
    try:
        if start is not None:
            mod[AFFECT_REGION_START_NAME_PROP] = str(start.name)
            mod[GENERIC_GIZMO_NAME_PROP] = str(start.name)
        if end is not None:
            mod[AFFECT_REGION_END_NAME_PROP] = str(end.name)
    except Exception:
        pass
    defaults = {
        'start': start,
        'end': end,
        'falloff': preserved.get('falloff', 20.0),
        'pinch': preserved.get('pinch', 0.0),
        'bubble': preserved.get('bubble', 0.0),
        'influence': preserved.get('influence', 1.0),
        'ignore_back_facing': preserved.get('ignore_back_facing', False),
    }
    names = {
        'start': 'Start Point', 'end': 'End Point', 'falloff': 'Falloff',
        'pinch': 'Pinch', 'bubble': 'Bubble', 'influence': 'Influence',
        'ignore_back_facing': 'Ignore Back Facing',
    }
    for key, value in defaults.items():
        try:
            socket = _affect_region_socket(group, key, names[key])
            sid = str(getattr(socket, 'identifier', '') or getattr(socket, 'name', '') or '')
            if sid:
                mod[AFFECT_REGION_SOCKET_PREFIX + key] = sid
                if key == 'start':
                    mod[GENERIC_GIZMO_SOCKET_PROP] = sid
            _set_modifier_socket_value(mod, socket, value)
        except Exception:
            pass
    _stamp_modifier(mod, defn)
    return start


def _draw_affect_region_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get(AFFECT_REGION_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    box = layout.box()
    draw_help_header(box, context, choose_text('Affect Region Controls', '影響領域設定', context=context), 'MOD_DISPLACE', 'max_affect_region_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    for key, prop_name, en, ja in (
        ('start', AFFECT_REGION_START_NAME_PROP, 'Start Point', '開始点'),
        ('end', AFFECT_REGION_END_NAME_PROP, 'End Point', '終点'),
    ):
        sid = str(mod.get(AFFECT_REGION_SOCKET_PREFIX + key, '') or '')
        if not sid:
            continue
        try:
            row = col.row(align=True)
            row.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
            op = row.operator('smsm.max_generic_select_gizmo', text='', icon='EMPTY_AXIS')
            op.object_name = obj_name
            op.modifier_name = mod_name
            op.gizmo_property = prop_name
        except Exception:
            pass
    for key, en, ja in (
        ('falloff', 'Falloff', 'フォールオフ'),
        ('pinch', 'Pinch', 'ピンチ'),
        ('bubble', 'Bubble', 'バブル'),
        ('influence', 'Influence', '影響度'),
        ('ignore_back_facing', 'Ignore Back Facing', '背面を無視'),
    ):
        sid = str(mod.get(AFFECT_REGION_SOCKET_PREFIX + key, '') or '')
        if sid:
            try:
                col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
            except Exception:
                pass
    return True


def _configure_skew_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    defn = dict(defn or {})
    if not defn:
        defn = {'key': 'skew_modifier', 'backend': 'skew_nodes', 'label': 'Skew Modifier', 'category': 'Deform'}
    if group is None or force_unique_group:
        group = _make_skew_group(obj, defn, context=context)
        try:
            mod.node_group = group
        except Exception:
            pass
    else:
        try:
            if getattr(mod, 'node_group', None) is not group:
                mod.node_group = group
        except Exception:
            pass
    try:
        mod[SKEW_MARKER_PROP] = True
        mod['smsm_generic_modifier'] = True
        mod[BACKEND_PROP] = 'skew_nodes'
        mod[SKEW_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_KIND_PROP] = 'deform'
        mod[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
    except Exception:
        pass
    try:
        gizmo = bpy.data.objects.get(str(mod.get(GENERIC_GIZMO_NAME_PROP, '') or ''))
    except Exception:
        gizmo = None
    if gizmo is None:
        gizmo = _make_generic_gizmo(obj, defn, getattr(mod, 'name', ''), context=context)
        if gizmo is not None:
            # 3ds Max measures Skew / Taper / Stretch along the object's own
            # axes, so a new gizmo starts with the object's rotation.
            try:
                gizmo.rotation_euler = obj.matrix_world.to_3x3().normalized().to_euler(gizmo.rotation_mode if gizmo.rotation_mode in {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'} else 'XYZ')
            except Exception:
                pass
    if gizmo is not None:
        try:
            gizmo[GENERIC_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
            gizmo[GENERIC_GIZMO_MODIFIER_PROP] = str(getattr(mod, 'name', '') or '')
            gizmo[KEY_PROP] = gizmo_deform_key(defn)
            gizmo[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
            gizmo['smsm_internal_helper'] = True
            mod[GENERIC_GIZMO_NAME_PROP] = str(getattr(gizmo, 'name', '') or '')
        except Exception:
            pass
        try:
            _generic_link_object_to_collection(gizmo, defn, context=context, exclusive=True)
        except Exception:
            pass
    default_amount = 0.0
    try:
        default_amount = float(mod.get(_param_id('amount'), 0.0) or 0.0)
    except Exception:
        pass
    for entry in gizmo_deform_socket_table(gizmo_deform_key(defn), group):
        key = entry['key']
        try:
            sock = _skew_socket(group, key, entry['name'])
            sid = str(getattr(sock, 'identifier', '') or getattr(sock, 'name', '') or '')
            if not sid:
                continue
            # Defaults are written only the first time a socket is bound, so a
            # later configure (instance sync, undo repair) keeps user values.
            first_bind = str(mod.get(SKEW_SOCKET_PREFIX + key, '') or '') != sid
            mod[SKEW_SOCKET_PREFIX + key] = sid
            if key == 'gizmo':
                mod[GENERIC_GIZMO_SOCKET_PROP] = sid
                _set_modifier_socket_value(mod, sock, gizmo)
            elif first_bind:
                value = default_amount if (key == 'amount' and default_amount) else entry['default']
                _set_modifier_socket_value(mod, sock, value)
        except Exception:
            pass
    try:
        _stamp_modifier(mod, defn)
    except Exception:
        pass
    try:
        _ensure_undo_redo_rehydrate()
    except Exception:
        pass
    return gizmo


def _draw_skew_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get(SKEW_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    group = getattr(mod, 'node_group', None)
    deform_key = gizmo_deform_key_for_group(group) or gizmo_deform_key({'key': str(mod.get(KEY_PROP, '') or '')})
    title_en, title_ja = GIZMO_DEFORM_TITLES.get(deform_key, GIZMO_DEFORM_TITLES['skew_modifier'])
    box = layout.box()
    help_id = 'max_' + deform_key if deform_key in GIZMO_DEFORM_TITLES else 'max_skew_modifier'
    draw_help_header(box, context, choose_text(title_en, title_ja, context=context), 'MOD_SIMPLEDEFORM', help_id)
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    gizmo_sid = str(mod.get(SKEW_SOCKET_PREFIX + 'gizmo', '') or mod.get(GENERIC_GIZMO_SOCKET_PROP, '') or '')
    if gizmo_sid:
        try:
            row = col.row(align=True)
            row.prop(mod, f'["{gizmo_sid}"]', text=choose_text('Gizmo', 'ギズモ', context=context))
            op = row.operator('smsm.max_generic_select_gizmo', text='', icon='EMPTY_AXIS')
            op.object_name = obj_name
            op.modifier_name = mod_name
        except Exception:
            pass
    for entry in gizmo_deform_socket_table(deform_key, group):
        key = entry['key']
        if key == 'gizmo':
            continue
        sid = str(mod.get(SKEW_SOCKET_PREFIX + key, '') or '')
        if not sid:
            continue
        try:
            col.prop(mod, f'["{sid}"]', text=choose_text(entry['label_en'], entry['label_ja'], context=context))
        except Exception:
            pass
        if key == 'effect':
            try:
                axes = gizmo_deform_effect_axes_text(mod.get(str(mod.get(SKEW_SOCKET_PREFIX + 'axis', '') or ''), 2), mod.get(sid, 2))
                if axes:
                    col.label(text=choose_text(f'Scaled axes: {axes}', f'拡大する軸: {axes}', context=context))
            except Exception:
                pass
    return True


# -----------------------------------------------------------------------------
# Generic Smart Connect Max node modifiers
# -----------------------------------------------------------------------------

_GENERIC_SYNC_SIG_CACHE = {}


def _generic_is_backend(defn) -> bool:
    """Return True for Max-compatible custom modifiers that need generated data.

    FFD/Smart Lattice and Edit Polygon are intentionally excluded because they
    are special stack systems with their own proven helper handling.
    """
    try:
        backend = str((defn or {}).get('backend') or '')
        key = str((defn or {}).get('key') or '')
        if key in {'edit_poly_modifier', 'edit_mesh_modifier', 'edit_polygon_modifier'}:
            return False
        if key.startswith('ffd_') or key in {'lattice_modifier', 'ffd_binding_modifier'}:
            return False
        return backend == 'nodes'
    except Exception:
        return False


def _safe_collection_part(value: str, fallback: str = 'Modifier') -> str:
    raw = str(value or '').strip() or str(fallback or 'Modifier')
    out = []
    for ch in raw:
        if ch.isalnum():
            out.append(ch)
        elif ch in {'_', '-'}:
            out.append('_')
        elif ch.isspace():
            out.append('_')
    name = ''.join(out).strip('_') or str(fallback or 'Modifier')
    while '__' in name:
        name = name.replace('__', '_')
    return name[:48]


def _generic_collection_name(defn_or_mod) -> str:
    try:
        if hasattr(defn_or_mod, 'get') and not isinstance(defn_or_mod, dict):
            existing = str(defn_or_mod.get(GENERIC_COLLECTION_PROP, '') or '')
            if existing:
                return existing
            key = str(defn_or_mod.get(KEY_PROP, '') or '')
        else:
            key = str((defn_or_mod or {}).get('key') or '')
    except Exception:
        key = ''
    if key.endswith('_modifier'):
        key = key[:-9]
    return f"{_safe_collection_part(key or 'Max_Modifier')}_Collection"


def _generic_get_or_create_collection(defn_or_mod=None, context=None):
    """Modifier_System_Collection/<Modifier>_Collection を取得または作成します。"""
    try:
        scene = getattr(context, 'scene', None) if context is not None else bpy.context.scene
    except Exception:
        scene = None
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is None:
            root = bpy.data.collections.new('Modifier_System_Collection')
        if scene is not None:
            try:
                if root.name not in [c.name for c in scene.collection.children]:
                    scene.collection.children.link(root)
            except Exception:
                pass
        cname = _generic_collection_name(defn_or_mod)
        col = bpy.data.collections.get(cname)
        if col is None:
            col = bpy.data.collections.new(cname)
        try:
            if col.name not in [c.name for c in root.children]:
                root.children.link(col)
        except Exception:
            pass
        return col
    except Exception:
        return None


def _generic_collection_is_empty(col) -> bool:
    try:
        if len(col.objects) > 0:
            return False
    except Exception:
        pass
    try:
        if len(col.children) > 0:
            return False
    except Exception:
        pass
    return True


def _generic_cleanup_empty_collections(*names) -> None:
    seen = set(str(n or '') for n in names if str(n or ''))
    if not seen:
        try:
            for col in list(bpy.data.collections):
                nm = str(getattr(col, 'name', '') or '')
                if nm.endswith('_Collection') and nm not in {NOISE_COLLECTION_NAME, 'UVWmap_Collection'}:
                    seen.add(nm)
        except Exception:
            pass
    for name in list(seen):
        try:
            col = bpy.data.collections.get(name)
            if col is not None and _generic_collection_is_empty(col):
                bpy.data.collections.remove(col)
        except Exception:
            pass
    try:
        root = bpy.data.collections.get('Modifier_System_Collection')
        if root is not None and _generic_collection_is_empty(root):
            bpy.data.collections.remove(root)
    except Exception:
        pass


def _generic_link_object_to_collection(obj, defn_or_mod=None, context=None, exclusive: bool = True) -> None:
    if obj is None:
        return
    col = _generic_get_or_create_collection(defn_or_mod, context=context)
    if col is None:
        return
    try:
        if obj.name not in [o.name for o in col.objects]:
            col.objects.link(obj)
    except Exception:
        pass
    if exclusive:
        for other in list(getattr(obj, 'users_collection', []) or []):
            if other == col:
                continue
            try:
                other.objects.unlink(obj)
            except Exception:
                pass


def _generic_set_helper_visibility(obj, visible: bool) -> None:
    if obj is None:
        return
    # Do not enable global hide_viewport on normal objects.  For add-on owned
    # helpers only, clear stale disabled state so Geometry Nodes object inputs
    # keep evaluating, then use hide_set() for temporary stack-level visibility.
    try:
        if (bool(obj.get(GENERIC_HELPER_PROP, False)) or bool(obj.get(GENERIC_PROXY_OWNER_PROP, False))) and hasattr(obj, 'hide_viewport') and bool(getattr(obj, 'hide_viewport', False)):
            obj.hide_viewport = False
    except Exception:
        pass
    try:
        obj.hide_set(not bool(visible))
    except Exception:
        pass
    if bool(visible):
        try:
            if bool(obj.get(GENERIC_HELPER_PROP, False)) and hasattr(obj, 'hide_select'):
                obj.hide_select = False
        except Exception:
            pass


def _generic_bounds_center_world(obj) -> Vector:
    try:
        pts = [getattr(obj, 'matrix_world', None) @ Vector(corner) for corner in getattr(obj, 'bound_box', [])]
        pts = [p for p in pts if p is not None]
        if pts:
            return sum(pts, Vector((0.0, 0.0, 0.0))) / float(len(pts))
    except Exception:
        pass
    try:
        return Vector(getattr(obj, 'location', (0.0, 0.0, 0.0)))
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _generic_kind_for(defn) -> str:
    key = str((defn or {}).get('key') or '').casefold()
    category = str((defn or {}).get('category') or '')
    label = str((defn or {}).get('label') or '').casefold()
    if 'uvw' in key or 'map' in key or category == 'UV / Mapping':
        return 'uv'
    if category in {'Deform', 'World Space', 'Space Warp Binding', 'Surface'} or any(x in key or x in label for x in ('skew', 'squeeze', 'melt', 'morph', 'skin')):
        return 'deform'
    if category in {'Materials'} or any(x in key for x in ('material', 'color', 'vertexpaint')):
        return 'attribute'
    if category in {'Edit / Select'} or 'select' in key or 'sel' in key:
        return 'selection'
    if category in {'Topology', 'Topology / Repair', 'Conversion', 'Generate'}:
        return 'geometry'
    if category in {'Rigging', 'Simulation', 'Animation / Cache'}:
        return 'utility'
    return 'utility'


def _make_generic_gizmo(obj, defn, mod_name: str = '', context=None):
    base = f"{GENERIC_GIZMO_BASE_PREFIX}_{_safe_collection_part((defn or {}).get('key') or (defn or {}).get('label') or 'Modifier')}"
    name = unique_name(base, bpy.data.objects)
    try:
        gizmo = bpy.data.objects.new(name, None)
    except Exception:
        return None
    try:
        kind = _generic_kind_for(defn)
        gizmo.empty_display_type = 'SPHERE' if kind in {'deform', 'utility'} else ('CUBE' if kind in {'geometry', 'selection'} else 'IMAGE')
    except Exception:
        pass
    try:
        gizmo.empty_display_size = 1.0
    except Exception:
        pass
    try:
        gizmo.location = _generic_bounds_center_world(obj)
    except Exception:
        pass
    try:
        gizmo[GENERIC_HELPER_PROP] = True
        gizmo[GENERIC_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
        gizmo[GENERIC_GIZMO_MODIFIER_PROP] = str(mod_name or '')
        gizmo[KEY_PROP] = str((defn or {}).get('key') or '')
        gizmo[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
    except Exception:
        pass
    try:
        _link_object_to_existing_collections(gizmo, obj, context=context)
    except Exception:
        pass
    try:
        _generic_link_object_to_collection(gizmo, defn, context=context, exclusive=True)
    except Exception:
        pass
    _generic_set_helper_visibility(gizmo, False)
    return gizmo


def _generic_socket(group, prop_name: str, *names: str):
    if group is None:
        return None
    for name in names:
        try:
            sock = _find_interface_socket(group, str(name), 'INPUT')
            if sock is not None:
                return sock
        except Exception:
            pass
    try:
        for item in group.interface.items_tree:
            try:
                if str(getattr(item, 'item_type', '') or '') == 'SOCKET' and str(getattr(item, 'in_out', '') or '').upper() == 'INPUT':
                    nm = str(getattr(item, 'name', '') or '')
                    if nm in names or nm == prop_name:
                        return item
            except Exception:
                continue
    except Exception:
        pass
    return None


def _make_generic_smart_group(obj, defn, context=None):
    """Create a Smart Connect Geometry Nodes wrapper for Max-compatible custom modifiers."""
    label = str((defn or {}).get('label') or 'Max Modifier')
    key = str((defn or {}).get('key') or 'max_modifier')
    kind = _generic_kind_for(defn)
    name = unique_name(f"{GENERIC_NODE_GROUP_PREFIX}_{_safe_collection_part(key)} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        group = bpy.data.node_groups.new(name, 'GeometryNodeTree')
        try:
            group.is_modifier = True
        except Exception:
            pass
        try:
            group.nodes.clear()
        except Exception:
            pass
        nodes = group.nodes
        links = group.links
        group_input = nodes.new('NodeGroupInput')
        group_output = nodes.new('NodeGroupOutput')
        group_input.location = (-900, 0)
        group_output.location = (700, 0)
        try:
            group_output.is_active_output = True
        except Exception:
            pass
        _add_interface_socket(group, name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry', description=choose_text('Incoming geometry.', '入力ジオメトリです。', context=context))
        _add_interface_socket(group, name='Gizmo', in_out='INPUT', socket_type='NodeSocketObject', description=choose_text('Smart Connect helper object that defines this Max-compatible modifier space.', 'このMax互換モディファイアの空間を定義するSmart Connect補助オブジェクトです。', context=context))
        _add_interface_socket(group, name='Influence', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Overall influence of this Max-compatible modifier.', 'このMax互換モディファイアの全体影響度です。', context=context))
        _add_interface_socket(group, name='Amount', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Primary amount parameter for this Max-compatible modifier.', 'このMax互換モディファイアの主要量パラメータです。', context=context))
        _add_interface_socket(group, name='Strength', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Strength multiplier for procedural Max-compatible behavior.', '手続き型Max互換挙動の強度倍率です。', context=context))
        _add_interface_socket(group, name='Angle', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('Angle parameter used by compatible deformation/rotation style modifiers.', '変形/回転系互換モディファイアで使用する角度パラメータです。', context=context))
        _add_interface_socket(group, name='Radius', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('Radius or falloff reference for compatible modifiers.', '互換モディファイアの半径または減衰基準です。', context=context))
        _add_interface_socket(group, name='U Tiling', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('U tiling for UV-oriented Max-compatible modifiers.', 'UV系Max互換モディファイアのUタイリングです。', context=context))
        _add_interface_socket(group, name='V Tiling', in_out='INPUT', socket_type='NodeSocketFloat', default=1.0, description=choose_text('V tiling for UV-oriented Max-compatible modifiers.', 'UV系Max互換モディファイアのVタイリングです。', context=context))
        _add_interface_socket(group, name='U Offset', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('U offset for UV-oriented Max-compatible modifiers.', 'UV系Max互換モディファイアのUオフセットです。', context=context))
        _add_interface_socket(group, name='V Offset', in_out='INPUT', socket_type='NodeSocketFloat', default=0.0, description=choose_text('V offset for UV-oriented Max-compatible modifiers.', 'UV系Max互換モディファイアのVオフセットです。', context=context))
        _add_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry', description=choose_text('Output geometry.', '出力ジオメトリです。', context=context))

        # Common gizmo-space nodes.  These make every Smart Connect custom row
        # truly depend on a manipulable helper, even when a specific Max feature
        # is represented as a safe compatibility approximation.
        position = nodes.new('GeometryNodeInputPosition')
        object_info = nodes.new('GeometryNodeObjectInfo')
        subtract = nodes.new('ShaderNodeVectorMath')
        try:
            subtract.operation = 'SUBTRACT'
        except Exception:
            pass
        position.location = (-680, -220)
        object_info.location = (-680, -420)
        subtract.location = (-420, -260)
        _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Gizmo',), 1), _socket_by_name(object_info.inputs, ('Object',), 0))
        _link_node_sockets(group, _socket_by_name(position.outputs, ('Position',), 0), _socket_by_name(subtract.inputs, (), 0))
        _link_node_sockets(group, _socket_by_name(object_info.outputs, ('Location',), 1), _socket_by_name(subtract.inputs, (), 1))

        geometry_output_socket = _socket_by_name(group_input.outputs, ('Geometry',), 0)

        if kind == 'uv':
            # Max UV/Mapping compatibility: store a planar UVMap attribute from
            # object/gizmo-relative coordinates.  Dedicated UVW Map has a richer
            # implementation; this covers the rest of the Max UV helper rows.
            store = nodes.new('GeometryNodeStoreNamedAttribute')
            store.location = (220, 0)
            try:
                store.data_type = 'FLOAT2'
                store.domain = 'CORNER'
            except Exception:
                pass
            try:
                _set_socket_default(_socket_by_name(store.inputs, ('Name',), 2), 'UVMap')
            except Exception:
                pass
            scale = nodes.new('ShaderNodeVectorMath')
            add = nodes.new('ShaderNodeVectorMath')
            try:
                scale.operation = 'MULTIPLY'
                add.operation = 'ADD'
                _set_socket_default(_socket_by_name(scale.inputs, (), 1), (1.0, 1.0, 0.0))
                _set_socket_default(_socket_by_name(add.inputs, (), 1), (0.5, 0.5, 0.0))
            except Exception:
                pass
            scale.location = (-120, -220)
            add.location = (60, -220)
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(store.inputs, ('Geometry',), 0))
            _link_node_sockets(group, _socket_by_name(subtract.outputs, ('Vector',), 0), _socket_by_name(scale.inputs, (), 0))
            _link_node_sockets(group, _socket_by_name(scale.outputs, ('Vector',), 0), _socket_by_name(add.inputs, (), 0))
            _link_node_sockets(group, _socket_by_name(add.outputs, ('Vector',), 0), _socket_by_name(store.inputs, ('Value',), 3))
            geometry_output_socket = _socket_by_name(store.outputs, ('Geometry',), 0)
        elif kind in {'deform', 'geometry', 'utility'}:
            # Safe procedural deformation core.  Amount is zero by default, so
            # modifiers that require an external target remain non-destructive
            # placeholders until the user animates/adjusts the exposed controls.
            combine = nodes.new('ShaderNodeCombineXYZ')
            amount_mul = nodes.new('ShaderNodeMath')
            strength_mul = nodes.new('ShaderNodeMath')
            set_position = nodes.new('GeometryNodeSetPosition')
            try:
                amount_mul.operation = 'MULTIPLY'
                strength_mul.operation = 'MULTIPLY'
            except Exception:
                pass
            amount_mul.location = (-220, 220)
            strength_mul.location = (-20, 220)
            combine.location = (180, 180)
            set_position.location = (420, 0)
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Amount',), 3), _socket_by_name(amount_mul.inputs, (), 0))
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Influence',), 2), _socket_by_name(amount_mul.inputs, (), 1))
            _link_node_sockets(group, _socket_by_name(amount_mul.outputs, (), 0), _socket_by_name(strength_mul.inputs, (), 0))
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Strength',), 4), _socket_by_name(strength_mul.inputs, (), 1))
            # Deformation is along Z by default.  For skew-like entries, use X so
            # the row has a visibly different Max-style control without changing
            # names or UI text.
            key_l = str(key).casefold()
            x_sock = _socket_by_name(combine.inputs, ('X',), 0)
            y_sock = _socket_by_name(combine.inputs, ('Y',), 1)
            z_sock = _socket_by_name(combine.inputs, ('Z',), 2)
            target_sock = x_sock if ('skew' in key_l or 'wind' in key_l) else (y_sock if ('squeeze' in key_l or 'deflector' in key_l) else z_sock)
            _link_node_sockets(group, _socket_by_name(strength_mul.outputs, (), 0), target_sock)
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(set_position.inputs, ('Geometry',), 0))
            _link_node_sockets(group, _socket_by_name(combine.outputs, ('Vector',), 0), _socket_by_name(set_position.inputs, ('Offset',), 3))
            geometry_output_socket = _socket_by_name(set_position.outputs, ('Geometry',), 0)
        elif kind in {'attribute', 'selection'}:
            store = nodes.new('GeometryNodeStoreNamedAttribute')
            store.location = (220, 0)
            try:
                store.data_type = 'FLOAT'
                store.domain = 'POINT'
            except Exception:
                pass
            attr_name = 'smsm_material_value' if kind == 'attribute' else 'smsm_selection_value'
            try:
                _set_socket_default(_socket_by_name(store.inputs, ('Name',), 2), attr_name)
            except Exception:
                pass
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Geometry',), 0), _socket_by_name(store.inputs, ('Geometry',), 0))
            _link_node_sockets(group, _socket_by_name(group_input.outputs, ('Influence',), 2), _socket_by_name(store.inputs, ('Value',), 3))
            geometry_output_socket = _socket_by_name(store.outputs, ('Geometry',), 0)

        _link_node_sockets(group, geometry_output_socket, _socket_by_name(group_output.inputs, ('Geometry',), 0))
        return group
    except Exception:
        try:
            return make_passthrough_group(name, context=context)
        except Exception:
            return None


def _configure_generic_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group: bool = False):
    if obj is None or mod is None:
        return None
    defn = dict(defn or {})
    if not defn:
        try:
            defn = {'key': str(mod.get(KEY_PROP, '') or 'generic_modifier'), 'backend': 'nodes', 'label': str(mod.get(SOURCE_LABEL_PROP, '') or getattr(mod, 'name', 'Max Modifier')), 'category': str(mod.get(CATEGORY_PROP, '') or '')}
        except Exception:
            defn = {'key': 'generic_modifier', 'backend': 'nodes'}
    if group is None or force_unique_group:
        group = _make_generic_smart_group(obj, defn, context=context)
        try:
            mod.node_group = group
        except Exception:
            pass
    else:
        try:
            if getattr(mod, 'node_group', None) is not group:
                mod.node_group = group
        except Exception:
            pass
    try:
        mod['smsm_generic_modifier'] = True
        mod[BACKEND_PROP] = 'nodes'
        mod[GENERIC_KIND_PROP] = _generic_kind_for(defn)
        mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
        mod[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
    except Exception:
        pass
    gizmo = None
    try:
        gizmo = bpy.data.objects.get(str(mod.get(GENERIC_GIZMO_NAME_PROP, '') or ''))
    except Exception:
        gizmo = None
    if gizmo is None:
        gizmo = _make_generic_gizmo(obj, defn, getattr(mod, 'name', ''), context=context)
    if gizmo is not None:
        try:
            gizmo[GENERIC_GIZMO_TARGET_PROP] = str(getattr(obj, 'name', '') or '')
            gizmo[GENERIC_GIZMO_MODIFIER_PROP] = str(getattr(mod, 'name', '') or '')
            gizmo[KEY_PROP] = str(defn.get('key') or '')
            gizmo[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
        except Exception:
            pass
        try:
            _generic_link_object_to_collection(gizmo, defn, context=context, exclusive=True)
        except Exception:
            pass
        try:
            mod[GENERIC_GIZMO_NAME_PROP] = str(getattr(gizmo, 'name', '') or '')
        except Exception:
            pass
    sid = ''
    try:
        sock = _generic_socket(group, GENERIC_GIZMO_SOCKET_PROP, 'Gizmo', 'ギズモ')
        sid = str(getattr(sock, 'identifier', '') or getattr(sock, 'name', '') or '')
    except Exception:
        sid = ''
    if sid:
        try:
            mod[GENERIC_GIZMO_SOCKET_PROP] = sid
            if gizmo is not None:
                mod[sid] = gizmo
        except Exception:
            pass
    try:
        if ms_is_shape_mesh_proxy(obj):
            obj[GENERIC_PROXY_OWNER_PROP] = True
            obj[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
            _generic_link_object_to_collection(obj, defn, context=context, exclusive=True)
            _generic_set_helper_visibility(obj, False)
    except Exception:
        pass
    try:
        _stamp_modifier(mod, defn)
    except Exception:
        pass
    return gizmo


def _generic_collect_cleanup_state(obj, mod):
    state = {'gizmo': '', 'group': '', 'proxy': '', 'collection': '', 'vertex_groups': [], 'modifier_key': ''}
    if obj is None or mod is None:
        return state
    try:
        state['modifier_key'] = f"{getattr(obj, 'name', '')}|{getattr(mod, 'name', '')}"
    except Exception:
        pass
    try:
        state['gizmo'] = str(mod.get(GENERIC_GIZMO_NAME_PROP, '') or '')
    except Exception:
        pass
    try:
        state['collection'] = str(mod.get(GENERIC_COLLECTION_PROP, '') or '') or _generic_collection_name(mod)
    except Exception:
        pass
    try:
        group = getattr(mod, 'node_group', None)
        state['group'] = str(getattr(group, 'name', '') or '')
    except Exception:
        pass
    try:
        if ms_is_shape_mesh_proxy(obj) and bool(obj.get(GENERIC_PROXY_OWNER_PROP, False)):
            state['proxy'] = str(getattr(obj, 'name', '') or '')
    except Exception:
        pass
    try:
        prefix = 'SMS_' + _safe_collection_part(str(mod.get(KEY_PROP, '') or 'Max'))
        for vg in getattr(obj, 'vertex_groups', []) or []:
            name = str(getattr(vg, 'name', '') or '')
            if name.startswith(prefix) or name.startswith('smsm_generic'):
                state['vertex_groups'].append(name)
    except Exception:
        pass
    return state


def _generic_remove_object_if_unused(name: str, prop_name: str = GENERIC_GIZMO_NAME_PROP) -> None:
    name = str(name or '')
    if not name:
        return
    still_used = False
    for candidate in list(bpy.data.objects):
        try:
            for other in getattr(candidate, 'modifiers', []) or []:
                if str(other.get(prop_name, '') or '') == name:
                    still_used = True
                    break
            if still_used:
                break
        except Exception:
            continue
    if still_used:
        return
    obj = bpy.data.objects.get(name)
    if obj is not None:
        data = getattr(obj, 'data', None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass
        try:
            if data is not None and hasattr(bpy.data, 'meshes') and int(getattr(data, 'users', 0) or 0) == 0:
                bpy.data.meshes.remove(data)
        except Exception:
            pass


def _generic_remove_node_group_if_unused(name: str) -> None:
    name = str(name or '')
    if not name:
        return
    group = bpy.data.node_groups.get(name)
    if group is None:
        return
    try:
        if int(getattr(group, 'users', 0) or 0) <= 0 or name.startswith(GENERIC_NODE_GROUP_PREFIX) or name.startswith('SMS Max '):
            bpy.data.node_groups.remove(group)
    except Exception:
        pass


def _generic_remove_proxy_object_by_name(proxy_name: str) -> None:
    proxy_name = str(proxy_name or '')
    if not proxy_name:
        return
    proxy = bpy.data.objects.get(proxy_name)
    if proxy is None:
        _generic_cleanup_empty_collections()
        return
    data = getattr(proxy, 'data', None)
    try:
        bpy.data.objects.remove(proxy, do_unlink=True)
    except Exception:
        pass
    try:
        if data is not None and int(getattr(data, 'users', 0) or 0) == 0:
            bpy.data.meshes.remove(data)
    except Exception:
        pass
    try:
        for source in list(bpy.data.objects):
            try:
                if source.get('ms_shape_mesh_proxy_object') == proxy_name:
                    for key in ('ms_shape_mesh_proxy_object', 'ms_shape_mesh_proxy_object_id'):
                        try:
                            del source[key]
                        except Exception:
                            pass
            except Exception:
                continue
    except Exception:
        pass
    _generic_cleanup_empty_collections()


def _generic_cleanup_collection_orphan_helpers(col_name: str = '') -> None:
    col = bpy.data.collections.get(str(col_name or '')) if str(col_name or '') else None
    if col is None:
        return
    for obj in list(getattr(col, 'objects', []) or []):
        try:
            if not bool(obj.get(GENERIC_HELPER_PROP, False)) and not bool(obj.get(GENERIC_PROXY_OWNER_PROP, False)):
                continue
        except Exception:
            continue
        used = False
        try:
            name = str(getattr(obj, 'name', '') or '')
            for candidate in list(bpy.data.objects):
                for other in getattr(candidate, 'modifiers', []) or []:
                    try:
                        if any(
                            str(other.get(prop_name, '') or '') == name
                            for prop_name in (
                                GENERIC_GIZMO_NAME_PROP,
                                AFFECT_REGION_START_NAME_PROP,
                                AFFECT_REGION_END_NAME_PROP,
                            )
                        ):
                            used = True
                            break
                    except Exception:
                        pass
                if used:
                    break
        except Exception:
            used = True
        if not used:
            data = getattr(obj, 'data', None)
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass
            try:
                if data is not None and int(getattr(data, 'users', 0) or 0) == 0 and hasattr(bpy.data, 'meshes'):
                    bpy.data.meshes.remove(data)
            except Exception:
                pass


def _generic_cleanup_owned_data(state, context=None) -> None:
    try:
        state = dict(state or {})
    except Exception:
        state = {}
    col_name = str(state.get('collection', '') or '')
    gizmo_name = str(state.get('gizmo', '') or '')
    if gizmo_name:
        _generic_remove_object_if_unused(gizmo_name, GENERIC_GIZMO_NAME_PROP)
    try:
        obj_name = ''
        key = str(state.get('modifier_key', '') or '')
        if '|' in key:
            obj_name = key.split('|', 1)[0]
        owner = bpy.data.objects.get(obj_name) if obj_name else None
        if owner is not None:
            for vg_name in list(state.get('vertex_groups', []) or []):
                try:
                    vg = owner.vertex_groups.get(str(vg_name))
                    if vg is not None:
                        owner.vertex_groups.remove(vg)
                except Exception:
                    pass
    except Exception:
        pass
    group_name = str(state.get('group', '') or '')
    if group_name:
        _generic_remove_node_group_if_unused(group_name)
    if col_name:
        _generic_cleanup_collection_orphan_helpers(col_name)
    proxy_name = str(state.get('proxy', '') or '')
    if proxy_name:
        proxy = bpy.data.objects.get(proxy_name)
        remove_proxy = False
        if proxy is not None:
            try:
                if bool(proxy.get(GENERIC_PROXY_OWNER_PROP, False)):
                    visible_mods = []
                    for m in getattr(proxy, 'modifiers', []) or []:
                        is_converter = False
                        try:
                            if bool(m['ms_shape_curve_mesh_converter']):
                                is_converter = True
                        except Exception:
                            pass
                        try:
                            ng = getattr(m, 'node_group', None)
                            if ng is not None and str(getattr(ng, 'name', '') or '').startswith('SMS Curve To Mesh'):
                                is_converter = True
                        except Exception:
                            pass
                        if is_converter:
                            continue
                        try:
                            if bool(m.get('smsm_generic_modifier', False)):
                                continue
                        except Exception:
                            pass
                        visible_mods.append(m)
                    remove_proxy = len(visible_mods) == 0
            except Exception:
                remove_proxy = False
        if remove_proxy:
            _generic_remove_proxy_object_by_name(proxy_name)
    _generic_cleanup_empty_collections(col_name)


def _generic_sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive):
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if stack_obj is None or not hasattr(stack_obj, 'modifiers'):
        return None
    try:
        sig = (str(getattr(stack_obj, 'name', '') or ''), str(effective_active_id or ''), str(carrier_key or ''), len(getattr(stack_obj, 'modifiers', []) or []))
        if _GENERIC_SYNC_SIG_CACHE.get(str(getattr(stack_obj, 'name', '') or '')) == sig:
            return None
        _GENERIC_SYNC_SIG_CACHE[str(getattr(stack_obj, 'name', '') or '')] = sig
    except Exception:
        pass
    active_id = str(effective_active_id or '')
    carrier = str(carrier_key or '')
    for mod in list(getattr(stack_obj, 'modifiers', []) or []):
        try:
            if not bool(mod.get('smsm_generic_modifier', False)):
                continue
        except Exception:
            continue
        visible = bool(str(getattr(mod, 'name', '') or '') in {active_id, carrier})
        gizmo = None
        try:
            gizmo = bpy.data.objects.get(str(mod.get(GENERIC_GIZMO_NAME_PROP, '') or ''))
        except Exception:
            gizmo = None
        if gizmo is not None:
            _generic_link_object_to_collection(gizmo, mod, context=context, exclusive=True)
            _generic_set_helper_visibility(gizmo, visible)
        try:
            if ms_is_shape_mesh_proxy(stack_obj) and bool(stack_obj.get(GENERIC_PROXY_OWNER_PROP, False)):
                _generic_link_object_to_collection(stack_obj, mod, context=context, exclusive=True)
                _generic_set_helper_visibility(stack_obj, bool(visible))
        except Exception:
            pass
    return None


def _generic_before_item_action(main_obj, context, obj, mod, action, clipboard):
    try:
        if bool(mod.get('smsm_generic_modifier', False)):
            return _generic_collect_cleanup_state(obj, mod)
    except Exception:
        pass
    return None


def _generic_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    if str(action or '') in {'DELETE', 'CUT', 'APPLY', 'APPLY_BELOW'}:
        try:
            _generic_cleanup_owned_data(state, context=context)
        except Exception:
            pass
    return None


def _preserve_before_item_action(main_obj, context, obj, mod, action, clipboard):
    state = _generic_before_item_action(main_obj, context, obj, mod, action, clipboard) or {}
    state['preserve_object'] = str(getattr(obj, 'name', '') or '')
    try:
        sid = str(mod.get(PRESERVE_SOCKET_PREFIX + 'selection_attribute', '') or '')
        state['preserve_selection'] = str(mod.get(sid, '') or '') if sid else ''
    except Exception:
        state['preserve_selection'] = ''
    return state


def _preserve_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    _generic_after_item_action(main_obj, context, obj, mod, action, clipboard, state)
    if str(action or '') not in {'DELETE', 'CUT', 'APPLY', 'APPLY_BELOW'}:
        return None
    owner = bpy.data.objects.get(str((state or {}).get('preserve_object', '') or ''))
    name = str((state or {}).get('preserve_selection', '') or '')
    if owner is None or not name:
        return None
    remove_owned_preserve_selection_if_unused(owner, name)
    return None


def _affect_region_collect_cleanup_state(obj, mod):
    state = _generic_collect_cleanup_state(obj, mod)
    try:
        state['start'] = str(mod.get(AFFECT_REGION_START_NAME_PROP, '') or '')
        state['end'] = str(mod.get(AFFECT_REGION_END_NAME_PROP, '') or '')
    except Exception:
        state['start'] = ''
        state['end'] = ''
    return state


def _affect_region_before_item_action(main_obj, context, obj, mod, action, clipboard):
    try:
        if bool(mod.get(AFFECT_REGION_MARKER_PROP, False)):
            return _affect_region_collect_cleanup_state(obj, mod)
    except Exception:
        pass
    return None


def _affect_region_after_item_action(main_obj, context, obj, mod, action, clipboard, state):
    if str(action or '') not in {'DELETE', 'CUT', 'APPLY', 'APPLY_BELOW'}:
        return None
    try:
        _generic_cleanup_owned_data(state, context=context)
    except Exception:
        pass
    try:
        _generic_remove_object_if_unused(str((state or {}).get('start', '') or ''), AFFECT_REGION_START_NAME_PROP)
        _generic_remove_object_if_unused(str((state or {}).get('end', '') or ''), AFFECT_REGION_END_NAME_PROP)
    except Exception:
        pass
    return None


def _affect_region_sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive):
    _generic_sync_objects(main_obj, context, effective_active_id, carrier_key, show_end, interactive)
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if stack_obj is None or not hasattr(stack_obj, 'modifiers'):
        return None
    active_names = {str(effective_active_id or ''), str(carrier_key or '')}
    for mod in list(getattr(stack_obj, 'modifiers', []) or []):
        try:
            if not bool(mod.get(AFFECT_REGION_MARKER_PROP, False)):
                continue
            visible = str(getattr(mod, 'name', '') or '') in active_names
            for prop_name in (AFFECT_REGION_START_NAME_PROP, AFFECT_REGION_END_NAME_PROP):
                helper = bpy.data.objects.get(str(mod.get(prop_name, '') or ''))
                if helper is not None:
                    _generic_link_object_to_collection(helper, mod, context=context, exclusive=True)
                    _generic_set_helper_visibility(helper, visible)
        except Exception:
            continue
    return None


def _affect_region_skip_copy_props(mod) -> set[str]:
    skip = _generic_skip_copy_props(mod) | {
        AFFECT_REGION_MARKER_PROP,
        AFFECT_REGION_NODE_GROUP_PROP,
        AFFECT_REGION_GRAPH_CONTRACT_PROP,
        AFFECT_REGION_START_NAME_PROP,
        AFFECT_REGION_END_NAME_PROP,
        AFFECT_REGION_POINT_ROLE_PROP,
    }
    try:
        for key in ('start', 'end', 'falloff', 'pinch', 'bubble', 'influence', 'ignore_back_facing'):
            skip.add(AFFECT_REGION_SOCKET_PREFIX + key)
        for key in ('start', 'end'):
            sid = str(mod.get(AFFECT_REGION_SOCKET_PREFIX + key, '') or '')
            if sid:
                skip.update({sid, f'{sid}_use_attribute', f'{sid}_attribute_name'})
    except Exception:
        pass
    return skip


def _generic_skip_copy_props(mod) -> set[str]:
    skip = {
        'node_group', 'smsm_generic_modifier', GENERIC_GIZMO_NAME_PROP,
        GENERIC_GIZMO_SOCKET_PROP, GENERIC_NODE_GROUP_PROP, GENERIC_HELPER_PROP,
        GENERIC_PROXY_OWNER_PROP, GENERIC_COLLECTION_PROP, GENERIC_KIND_PROP,
        GENERIC_GIZMO_TARGET_PROP, GENERIC_GIZMO_MODIFIER_PROP,
    }
    try:
        sid = str(mod.get(GENERIC_GIZMO_SOCKET_PROP, '') or '')
        if sid:
            skip.add(sid)
            skip.add(f'{sid}_use_attribute')
            skip.add(f'{sid}_attribute_name')
    except Exception:
        pass
    return skip


def _generic_get_target_modifier(context, object_name: str = '', modifier_name: str = ''):
    obj = bpy.data.objects.get(str(object_name or '')) if object_name else None
    if obj is None:
        try:
            obj = get_main_object(getattr(context, 'active_object', None)) or getattr(context, 'active_object', None)
        except Exception:
            obj = getattr(context, 'active_object', None)
    mod = None
    if obj is not None:
        try:
            mod = obj.modifiers.get(str(modifier_name or '')) if modifier_name else getattr(obj.modifiers, 'active', None)
        except Exception:
            mod = None
    return obj, mod


def _generic_select_gizmo(context, obj, mod, prop_name: str = GENERIC_GIZMO_NAME_PROP) -> bool:
    if obj is None or mod is None:
        return False
    gizmo = None
    try:
        gizmo = bpy.data.objects.get(str(mod.get(str(prop_name or GENERIC_GIZMO_NAME_PROP), '') or ''))
    except Exception:
        gizmo = None
    if gizmo is None and str(prop_name or '') == GENERIC_GIZMO_NAME_PROP:
        try:
            gizmo = _configure_generic_modifier(obj, mod, getattr(mod, 'node_group', None), None, context=context)
        except Exception:
            gizmo = None
    if gizmo is None:
        return False
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    try:
        _generic_link_object_to_collection(gizmo, mod, context=context, exclusive=True)
        _generic_set_helper_visibility(gizmo, True)
        gizmo.select_set(True)
        context.view_layer.objects.active = gizmo
        return True
    except Exception:
        return False


def _draw_squeeze_node_properties(layout, mod, context=None) -> bool:
    """Expose only the Squeeze modifier's existing interface sockets."""
    try:
        if not bool(mod.get(SQUEEZE_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    fields = (
        ('gizmo', 'Gizmo', 'ギズモ'),
        ('squeeze', 'Squeeze', 'スクイーズ'),
        ('squeeze_curve', 'Squeeze Curve', 'スクイーズカーブ'),
        ('bulge', 'Bulge', 'バルジ'),
        ('bulge_curve', 'Bulge Curve', 'バルジカーブ'),
        ('influence', 'Influence', '影響'),
        ('use_limits', 'Use Limits', '制限を使用'),
        ('lower_limit', 'Lower Limit', '下限'),
        ('upper_limit', 'Upper Limit', '上限'),
        ('bias', 'Bias', 'バイアス'),
        ('volume', 'Volume', 'ボリューム'),
    )
    box = layout.box()
    draw_help_header(box, context, choose_text('Squeeze Parameters', 'スクイーズパラメーター', context=context), 'MOD_SIMPLEDEFORM', 'max_squeeze_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    drawn = False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    for key, english, japanese in fields:
        try:
            socket_id = str(mod.get(SQUEEZE_SOCKET_PREFIX + key, '') or '')
            if socket_id:
                if key == 'gizmo':
                    row = col.row(align=True)
                    row.prop(mod, f'["{socket_id}"]', text=choose_text(english, japanese, context=context))
                    op = row.operator('smsm.max_generic_select_gizmo', text='', icon='EMPTY_AXIS')
                    op.object_name = obj_name
                    op.modifier_name = mod_name
                else:
                    col.prop(mod, f'["{socket_id}"]', text=choose_text(english, japanese, context=context))
                drawn = True
        except Exception:
            pass
    return drawn


def _draw_generic_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get('smsm_generic_modifier', False)) or bool(mod.get(SQUEEZE_MARKER_PROP, False)) or bool(mod.get(MELT_MARKER_PROP, False)) or bool(mod.get(AFFECT_REGION_MARKER_PROP, False)) or bool(mod.get(PUSH_MARKER_PROP, False)) or bool(mod.get(SKEW_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    try:
        gizmo_sid = str(mod.get(GENERIC_GIZMO_SOCKET_PROP, '') or '')
    except Exception:
        gizmo_sid = ''
    if not gizmo_sid:
        # ギズモを持たない行（Preserve など）に中身の無い箱を出さない
        return False
    box = layout.box()
    draw_help_header(box, context, choose_text('Smart Connect', 'スマート接続', context=context), 'EMPTY_AXIS', 'max_generic_smart_connect')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    drawn = False
    if gizmo_sid:
        try:
            row = col.row(align=True)
            row.prop(mod, f'["{gizmo_sid}"]', text=choose_text('Gizmo', 'ギズモ', context=context))
            op = row.operator('smsm.max_generic_select_gizmo', text='', icon='EMPTY_AXIS')
            op.object_name = obj_name
            op.modifier_name = mod_name
            drawn = True
        except Exception:
            pass
    return drawn

def _finish_new_modifier(obj, mod, logical_name: str, insert_idx=None, context=None, master_obj=None):
    try:
        target_index = None
        if insert_idx is not None:
            try:
                target_index = max(0, int(insert_idx))
            except Exception:
                target_index = None
        if target_index is None:
            try:
                target_index = ms_calc_target_insert_index(master_obj or get_main_object(getattr(context, 'active_object', None)) or obj, obj, context)
            except Exception:
                target_index = max(0, len(obj.modifiers) - 1)
        safe_move_modifier(obj, mod.name, target_index)
    except Exception:
        pass
    try:
        ms_obj_set_disp_name(obj, mod.name, logical_name)
        set_mod_enabled_state(obj, mod.name, True)
        set_mod_viewport_state(obj, mod.name, True)
        obj['ui_active_item'] = mod.name
        obj['ui_active_row'] = obj.modifiers.find(mod.name)
        ms_set_ui_active_index(obj, obj.modifiers.find(mod.name))
        obj.modifiers.active = mod
    except Exception:
        pass


def _stamp_modifier(mod, defn):
    try:
        mod[MARKER_KEY] = True
        mod[KEY_PROP] = str(defn.get('key', ''))
        mod[BACKEND_PROP] = str(defn.get('backend', ''))
        mod[SOURCE_LABEL_PROP] = str(defn.get('label', ''))
        mod[CATEGORY_PROP] = str(defn.get('category', ''))
        mod[_CATEGORY_JA_PROP] = str(defn.get('category_ja', defn.get('category', '')))
        mod['smsm_plugin_id'] = str(defn.get('plugin_id', ''))
        mod['smsm_max_equivalent'] = str(defn.get('label', ''))
        mod['smsm_max_description_en'] = str(defn.get('description_en', ''))
        mod['smsm_max_description_ja'] = str(defn.get('description_ja', ''))
        mod['smsm_ui_generation'] = 2
    except Exception:
        pass
    try:
        if not event_hub.has('undo_post', _rehydrate_xform_load_post):
            _ensure_undo_redo_rehydrate()
    except Exception:
        pass


def _param_id(name: str) -> str:
    return _PARAM_PREFIX + str(name or '').strip().lower().replace(' ', '_').replace('-', '_')


def _param_label(prop_id: str, context=None) -> str:
    key = str(prop_id or '')
    if key.startswith(_PARAM_PREFIX):
        key = key[len(_PARAM_PREFIX):]
    en, ja = _PARAM_LABELS.get(key, (key.replace('_', ' ').title(), key.replace('_', ' ').title()))
    return choose_text(en, ja, context=context)


def _add_param(schema, key, default, *, min_value=None, max_value=None, description_en='', description_ja=''):
    prop_id = _param_id(key)
    if any(item.get('id') == prop_id for item in schema):
        return
    schema.append({
        'id': prop_id,
        'key': str(key),
        'default': default,
        'min': min_value,
        'max': max_value,
        'description_en': description_en or f'3ds Max-compatible {key.replace("_", " ")} value stored on this stack row.',
        'description_ja': description_ja or f'このスタック行に保持される 3ds Max 互換の {key.replace("_", " ")} 値です。',
    })


def _parameter_schema(defn):
    schema = []
    label = str(defn.get('label') or '').casefold()
    key = str(defn.get('key') or '').casefold()
    category = str(defn.get('category') or '')
    backend = str(defn.get('backend') or '')
    modifier_type = str(defn.get('modifier_type') or '')

    if backend == 'noise_nodes' or key == 'noise_modifier' or backend in {'push_nodes', 'preserve_nodes', 'face_extrude_nodes', 'xform_nodes', 'linked_xform_nodes', 'mirror_nodes'} or key in {'push_modifier', 'preserve_modifier', 'face_extrude_modifier', 'xform_modifier', 'linked_xform_modifier', 'mirror_modifier'}:
        return schema
    if backend in {'skew_nodes', 'melt_nodes', 'affect_region_nodes'} or key in {'skew_modifier', 'melt_modifier', 'affect_region_modifier'}:
        return schema

    _add_param(schema, 'influence', 1.0, min_value=0.0, max_value=1.0,
               description_en='Global stack influence for this Max-compatible row. Use it as a non-destructive blend/strength reference when the backend exposes a compatible control.',
               description_ja='この Max 互換行の全体影響度です。バックエンドが対応する制御を持つ場合の非破壊ブレンド / 強度基準として使います。')

    if key == 'xform_modifier':
        # XForm channels live on the Geometry Nodes modifier socket ID-properties
        # so they remain animatable and ordered with this exact stack row.
        return schema

    if backend == 'xform_nodes' or category == 'Transform' or 'xform' in label:
        _add_param(schema, 'amount', 0.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'use_world_space', False)
        return schema

    if category in {'Deform', 'Space Warp Binding', 'World Space', 'Surface'} or modifier_type in {'SIMPLE_DEFORM', 'DISPLACE', 'WAVE'}:
        _add_param(schema, 'amount', 0.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'strength', 1.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'angle', 0.0, min_value=-6.283185307, max_value=6.283185307)
        _add_param(schema, 'radius', 1.0, min_value=0.0, max_value=100000.0)
    if category in {'Generate', 'Subdivision'} or modifier_type in {'ARRAY', 'BEVEL', 'SOLIDIFY', 'SUBSURF', 'MULTIRES', 'SCREW'}:
        _add_param(schema, 'amount', 0.1, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'segments', 1, min_value=0, max_value=256)
        _add_param(schema, 'width', 1.0, min_value=0.0, max_value=100000.0)
        _add_param(schema, 'height', 1.0, min_value=0.0, max_value=100000.0)
        _add_param(schema, 'depth', 1.0, min_value=0.0, max_value=100000.0)
    if category == 'UV / Mapping' or 'uvw' in key or 'map' in key:
        _add_param(schema, 'map_channel', 1, min_value=1, max_value=99)
        _add_param(schema, 'u_tiling', 1.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'v_tiling', 1.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'u_offset', 0.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'v_offset', 0.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'rotation', 0.0, min_value=-6.283185307, max_value=6.283185307)
    if category in {'Edit / Select', 'Topology', 'Topology / Repair', 'Conversion'} or modifier_type in {'WELD', 'DECIMATE', 'REMESH'}:
        _add_param(schema, 'tolerance', 0.001, min_value=0.0, max_value=1000.0)
        _add_param(schema, 'iterations', 1, min_value=0, max_value=1000)
        _add_param(schema, 'preserve_boundaries', True)
    if category in {'Simulation', 'Animation / Cache', 'Materials'}:
        _add_param(schema, 'strength', 1.0, min_value=-1000.0, max_value=1000.0)
        _add_param(schema, 'seed', 1, min_value=0, max_value=999999)
    if category == 'Materials':
        _add_param(schema, 'material_id', 1, min_value=1, max_value=9999)
    return schema


def _install_custom_parameter_props(mod, defn, context=None):
    try:
        ui = dict(mod.get('_RNA_UI', {}) or {})
    except Exception:
        ui = {}
    changed = False
    for item in _parameter_schema(defn):
        pid = str(item.get('id') or '')
        if not pid:
            continue
        try:
            if pid not in mod:
                mod[pid] = item.get('default')
                changed = True
        except Exception:
            pass
        try:
            meta = dict(ui.get(pid, {}) or {})
            if item.get('min') is not None:
                meta['min'] = item.get('min')
                meta['soft_min'] = item.get('min')
            if item.get('max') is not None:
                meta['max'] = item.get('max')
                meta['soft_max'] = item.get('max')
            meta['description'] = choose_text(item.get('description_en', ''), item.get('description_ja', ''), context=context)
            ui[pid] = meta
            changed = True
        except Exception:
            pass
    try:
        if changed:
            mod['_RNA_UI'] = ui
    except Exception:
        pass


def _draw_max_parameter_props(layout, mod, context=None):
    try:
        if bool(mod.get(SQUEEZE_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    drawn = False
    try:
        param_keys = [str(k) for k in mod.keys() if str(k).startswith(_PARAM_PREFIX)]
    except Exception:
        param_keys = []
    if not param_keys:
        return False
    box = layout.box()
    draw_help_header(box, context, 'Max Parameters', 'MODIFIER', 'max_modifier_parameters')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    for key in sorted(param_keys):
        try:
            col.prop(mod, f'["{key}"]', text=_param_label(key, context=context))
            drawn = True
        except Exception:
            pass
    return drawn


def _make_compatibility_group(obj, defn, context=None):
    name = unique_name(f"SMS Max {defn.get('label', 'Modifier')} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    try:
        return make_passthrough_group(name, context=context)
    except Exception:
        return _make_xform_group(obj, defn, context=context)


def _new_nodes_modifier(obj, defn, context=None, insert_idx=None, logical_name=None, shared_group=None):
    label = choose_text(defn.get('label', 'Max Modifier'), defn.get('label_ja', defn.get('label', 'Max Modifier')), context=context)
    if defn.get('backend') == 'noise_nodes':
        name = ms_next_logical_name_from_base(obj, NOISE_MODIFIER_BASE_NAME)
        display_name = str(logical_name or label)
    else:
        name = str(logical_name or ms_next_logical_name_from_base(obj, label))
        display_name = name
    # Noise / XForm / generic Max nodes must keep a per-object Geometry Nodes
    # group and helper Empty.  Sharing the node group through instance
    # synchronization copies Object sockets and makes multiple objects use one
    # helper.
    if str(defn.get('key') or '') == 'xform_modifier':
        group = _make_xform_group(obj, defn, context=context)
    elif str(defn.get('key') or '') == 'linked_xform_modifier':
        group = make_linked_group(obj, defn, context=context)
    elif str(defn.get('key') or '') == 'normalize_spline_modifier':
        group = make_normalize_group(obj, defn, context=context)
    elif defn.get('backend') == 'skew_nodes':
        group = _make_skew_group(obj, defn, context=context)
    elif defn.get('backend') == 'squeeze_nodes':
        group = _make_squeeze_group(obj, defn, context=context)
    elif defn.get('backend') == 'melt_nodes':
        group = _make_melt_group(obj, defn, context=context)
    elif defn.get('backend') == 'affect_region_nodes':
        group = _make_affect_region_group(obj, defn, context=context)
    elif defn.get('backend') == 'noise_nodes':
        group = _make_noise_group(obj, defn, context=context)
    elif defn.get('backend') == 'push_nodes':
        group = make_push_group(obj, defn, context=context)
    elif defn.get('backend') == 'preserve_nodes':
        group = make_preserve_group(obj, defn, context=context)
    elif defn.get('backend') == 'face_extrude_nodes':
        group = make_face_extrude_group(obj, defn, context=context)
    elif _generic_is_backend(defn):
        group = _make_generic_smart_group(obj, defn, context=context)
    elif shared_group is not None:
        group = shared_group
    elif defn.get('backend') == 'xform_nodes':
        group = _make_xform_group(obj, defn, context=context)
    elif defn.get('backend') == 'mirror_nodes':
        group = _make_mirror_group(obj, defn, context=context)
    elif defn.get('backend') == 'skew_nodes':
        group = _make_skew_group(obj, defn, context=context)
    else:
        group = _make_compatibility_group(obj, defn, context=context)
    if str(defn.get('backend') or '') == 'squeeze_nodes' and group is None:
        # The dedicated Squeeze graph is the transaction boundary.  Do not
        # create or stamp a NODES row when graph construction failed.
        return None
    mod = obj.modifiers.new(name=name, type='NODES')
    try:
        mod.node_group = group
    except Exception:
        pass
    try:
        mod.show_expanded = True
    except Exception:
        pass
    if str(defn.get('key') or '') == 'xform_modifier':
        try:
            _configure_xform_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if str(defn.get('backend') or '') == 'noise_nodes':
        try:
            _configure_noise_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if str(defn.get('backend') or '') == 'push_nodes':
        configure_push_modifier(obj, mod, group, defn, context=context)
    if str(defn.get('backend') or '') == 'preserve_nodes':
        configure_preserve_modifier(obj, mod, group, defn, context=context)
    if str(defn.get('backend') or '') == 'face_extrude_nodes':
        configure_face_extrude_modifier(obj, mod, group, defn, context=context)
    if str(defn.get('backend') or '') == 'skew_nodes':
        try:
            _configure_skew_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if str(defn.get('backend') or '') == 'squeeze_nodes':
        try:
            _configure_squeeze_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if str(defn.get('backend') or '') == 'melt_nodes':
        try:
            _configure_melt_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if str(defn.get('backend') or '') == 'affect_region_nodes':
        try:
            _configure_affect_region_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    if _generic_is_backend(defn):
        try:
            _configure_generic_modifier(obj, mod, group, defn, context=context)
        except Exception:
            pass
    _stamp_modifier(mod, defn)
    _install_custom_parameter_props(mod, defn, context=context)
    _finish_new_modifier(obj, mod, display_name, insert_idx=insert_idx, context=context)
    return mod


def _curve_reference_from_selection(obj, context):
    try:
        for candidate in _selected_objects(context):
            try:
                candidate = get_main_object(candidate)
            except Exception:
                pass
            if candidate is not None and candidate != obj and getattr(candidate, 'type', '') == 'CURVE':
                return candidate
    except Exception:
        pass
    try:
        for candidate in bpy.context.scene.objects:
            if candidate is not None and candidate != obj and getattr(candidate, 'type', '') == 'CURVE':
                return candidate
    except Exception:
        pass
    return None


def _apply_context_reference_defaults(mod, obj, defn, context=None):
    try:
        key = str(defn.get('key') or '')
        mtype = str(getattr(mod, 'type', '') or '')
        if mtype == 'CURVE' or key in {'pathdeform_modifier', 'pathdeform_wsm_modifier', 'path_follow_modifier'}:
            curve_obj = _curve_reference_from_selection(obj, context)
            if curve_obj is not None:
                _try_set_prop_or_attr(mod, 'object', curve_obj)
    except Exception:
        pass


def _new_builtin_modifier(obj, defn, context=None, insert_idx=None, logical_name=None):
    modifier_type = str(defn.get('modifier_type') or '').strip()
    if not _modifier_type_available(modifier_type):
        alt = dict(defn)
        alt['backend'] = 'nodes'
        return _new_nodes_modifier(obj, alt, context=context, insert_idx=insert_idx, logical_name=logical_name)
    label = choose_text(defn.get('label', 'Max Modifier'), defn.get('label_ja', defn.get('label', 'Max Modifier')), context=context)
    logical_name = str(logical_name or ms_next_logical_name_from_base(obj, label))
    try:
        mod = obj.modifiers.new(name=logical_name, type=modifier_type)
    except Exception:
        alt = dict(defn)
        alt['backend'] = 'nodes'
        return _new_nodes_modifier(obj, alt, context=context, insert_idx=insert_idx, logical_name=logical_name)
    _stamp_modifier(mod, defn)
    _install_custom_parameter_props(mod, defn, context=context)
    _apply_modifier_defaults(mod, obj, defn)
    _apply_context_reference_defaults(mod, obj, defn, context=context)
    _finish_new_modifier(obj, mod, logical_name, insert_idx=insert_idx, context=context)
    return mod


def _delegate_operator_kwargs(defn, op_id: str) -> dict:
    key = str(defn.get('key') or '')
    if str(op_id or '') == 'smart_lattice.add_layer':
        preset = {
        }.get(key, 4)
        return {'resolution_type': str(preset), 'res_u': preset, 'res_v': preset, 'res_w': preset}
    return {}


def _delegate_scene_property_overrides(defn, op_id: str) -> dict:
    """Return temporary scene-property overrides for delegate-backed Max entries.

    Some delegated tools are broad generators when used from their own panels.
    Max-compatible stack entries must still add one stack modifier per execution,
    so narrow those delegate calls here without changing saved user settings.
    """
    key = str((defn or {}).get('key') or '').strip()
    op = str(op_id or '').strip()
    if key in {'conform_modifier', 'space_conform_modifier'} and op == 'smsp.surface_conform_modifier':
        return {'smsp_props': {'conform_add_normals': False}}
    if key == 'sweep_modifier' and op == 'smsp.sweep_active_profile':
        return {'smsp_props': {'sweep_duplicate_path': False}}
    return {}


def _apply_delegate_scene_property_overrides(context, overrides: dict) -> list:
    saved = []
    if not overrides:
        return saved
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    if scene is None:
        return saved
    for group_name, values in dict(overrides or {}).items():
        try:
            group = getattr(scene, str(group_name), None)
        except Exception:
            group = None
        if group is None:
            continue
        for attr, value in dict(values or {}).items():
            name = str(attr or '').strip()
            if not name:
                continue
            try:
                old_value = getattr(group, name)
            except Exception:
                continue
            try:
                setattr(group, name, value)
                saved.append((group, name, old_value))
            except Exception:
                pass
    return saved


def _restore_delegate_scene_property_overrides(saved: list) -> None:
    for group, name, old_value in reversed(list(saved or [])):
        try:
            setattr(group, name, old_value)
        except Exception:
            pass



def _new_modifier_count_from_snapshot(targets, before_snapshot) -> int:
    total = 0
    try:
        after = ms_collect_new_modifiers(targets or [], before_snapshot or {})
    except Exception:
        after = {}
    try:
        for mods in (after or {}).values():
            total += len(list(mods or []))
    except Exception:
        pass
    return int(total)

def _run_delegate(defn, context):
    op_id = str(defn.get('delegate') or '').strip()
    if not op_id:
        return {'CANCELLED'}
    targets = _supported_objects(context, defn.get('object_types') or ('MESH',), for_execution=True)
    source_targets = ms_original_sources_for_stack_targets(targets) or list(targets)
    try:
        active_main = get_main_object(getattr(context, 'active_object', None))
    except Exception:
        active_main = getattr(context, 'active_object', None)
    try:
        if op_id in {'smsp.surface_conform_modifier', 'smsp.normal_transfer_to_selected', 'sms.conform_to_surface'}:
            targets = [obj for obj in targets if obj and obj != active_main]
        elif op_id == 'sms.smart_boolean_stack':
            targets = [active_main] if active_main is not None else []
        elif op_id == 'smsp.sweep_active_profile':
            targets = [active_main] if active_main is not None and getattr(active_main, 'type', '') == 'CURVE' else []
            source_targets = list(targets)
    except Exception:
        pass
    before_snapshot = ms_snapshot_modifier_names(targets) if targets else {}
    pre_effective_id_by_obj = {}
    for obj in targets:
        try:
            if obj and getattr(obj, 'type', '') == 'MESH':
                pre_effective_id_by_obj[obj.name] = ms_get_ui_active_id(obj)
        except Exception:
            pass
    bridge_state = None
    try:
        from ... import user_plugins
        loader = getattr(user_plugins, '_lazy_register_operator_module', None)
        if callable(loader):
            loader(op_id, context)
    except Exception:
        pass
    op = get_operator_callable(op_id)
    if op is None:
        return {'CANCELLED'}
    if str(getattr(context, 'mode', '') or '').startswith('EDIT'):
        try:
            need_bridge = not bool(op.poll())
        except Exception:
            need_bridge = True
        if need_bridge:
            bridge_state = ms_capture_mode_bridge_state(context)
    proxy_selection_state = None
    try:
        if bridge_state is not None:
            try:
                ms_enter_object_mode_bridge(context, bridge_state)
            except Exception:
                pass
        try:
            if any(ms_is_shape_mesh_proxy(obj) for obj in targets):
                active_exec = targets[0] if targets else None
                proxy_selection_state = ms_begin_temporary_stack_target_selection(context, targets, active_exec)
        except Exception:
            proxy_selection_state = None
        op_kwargs = _delegate_operator_kwargs(defn, op_id)
        override_snapshot = _apply_delegate_scene_property_overrides(context, _delegate_scene_property_overrides(defn, op_id))
        try:
            runners = (lambda: op('EXEC_DEFAULT', **op_kwargs), lambda: op(**op_kwargs), lambda: op('INVOKE_DEFAULT', **op_kwargs))
            for runner in runners:
                result = call_operator_safe(runner)
                if result is None:
                    continue
                if isinstance(result, set) and 'CANCELLED' in result:
                    if _new_modifier_count_from_snapshot(targets, before_snapshot) > 0:
                        result = {'FINISHED'}
                    elif bridge_state is not None:
                        continue
                    else:
                        continue
                if result is not None:
                    try:
                        if isinstance(result, set) and 'FINISHED' in result:
                            if len(targets) > 1:
                                ms_promote_new_modifiers_to_instances(context, targets, before_snapshot, allow_copy_missing=True, effective_id_by_obj=pre_effective_id_by_obj)
                            ms_apply_auto_selection_to_new_modifiers(targets, before_snapshot, pre_effective_id_by_obj, context=context)
                            try:
                                new_after = ms_collect_new_modifiers(targets, before_snapshot)
                            except Exception:
                                new_after = {}
                            try:
                                for _mods in (new_after or {}).values():
                                    for _mod in list(_mods or []):
                                        try:
                                            if len (targets )>1:
                                                _ms_modifier_set_object_instance_unique (_mod ,True )
                                        except Exception:
                                            pass
                                        try:
                                            _stamp_modifier(_mod, defn)
                                        except Exception:
                                            pass
                            except Exception:
                                pass
                            if str(defn.get('key') or '') == 'ffd_binding_modifier':
                                # 3ds Max Bind to Space Warp: world-space lattice, evaluated last, Only In Volume
                                try:
                                    from ..lattice_modifier.sl_core import sl_ffd_binding_finalize
                                    sl_ffd_binding_finalize(context, new_after)
                                except Exception:
                                    pass
                            for obj in (source_targets or targets):
                                try:
                                    ms_apply_state_post_action(context, obj, interactive_default=False)
                                except Exception:
                                    pass
                    except Exception:
                        pass
                    return result
        finally:
            _restore_delegate_scene_property_overrides(override_snapshot)
    finally:
        if proxy_selection_state is not None:
            try:
                ms_end_temporary_stack_target_selection(context, proxy_selection_state)
            except Exception:
                pass
        try:
            if source_targets:
                ms_normalize_shape_proxy_visibility_selection(context, source_targets)
        except Exception:
            pass
        if bridge_state is not None:
            try:
                ms_restore_mode_bridge(context, bridge_state)
            except Exception:
                pass
    return {'CANCELLED'}


def add_max_modifier(context, defn, *, insert_idx=None):
    backend = str(defn.get('backend') or 'builtin')
    if backend == 'delegate':
        return _run_delegate(defn, context)
    active = _active_object(context)
    bridge_state = ms_capture_mode_bridge_state(context) if str(getattr(context, 'mode', '') or '').startswith('EDIT') else None
    if bridge_state is not None:
        try:
            ms_enter_object_mode_bridge(context, bridge_state)
        except Exception:
            pass
    try:
        key_for_targets = str(defn.get('key') or '')
        try:
            active_main_for_targets = get_main_object(active) or active
        except Exception:
            active_main_for_targets = active
        if key_for_targets in {'pathdeform_modifier', 'pathdeform_wsm_modifier', 'path_follow_modifier'} and active_main_for_targets is not None:
            try:
                if ms_is_shape_source_object(active_main_for_targets):
                    targets = ms_resolve_modifier_add_targets([active_main_for_targets], context=context, create_shape_proxies=True, migrate=True) or [active_main_for_targets]
                else:
                    targets = [active_main_for_targets]
            except Exception:
                targets = [active_main_for_targets]
        else:
            targets = _supported_objects(context, defn.get('object_types') or ('MESH',), for_execution=True)
        source_targets = ms_original_sources_for_stack_targets(targets) or list(targets)
        if not targets:
            if key_for_targets == 'normalize_spline_modifier':
                raise RuntimeError('Normalize Spline: no eligible Curve target / 対応するカーブがありません')
            return {'CANCELLED'}
        before_snapshot = ms_snapshot_modifier_names(targets)
        pre_effective_id_by_obj = {}
        for obj in targets:
            try:
                if obj and getattr(obj, 'type', '') == 'MESH':
                    pre_effective_id_by_obj[obj.name] = ms_get_ui_active_id(obj)
            except Exception:
                pass
        pre_face_selection_by_obj = {}
        if backend == 'face_extrude_nodes':
            for obj in targets:
                try:
                    main_obj = get_main_object(obj) or obj
                except Exception:
                    main_obj = obj
                try:
                    effective_id = pre_effective_id_by_obj.get(obj.name) or pre_effective_id_by_obj.get(main_obj.name) or 'BASE'
                    carrier_key = ms_get_carrier_key_for_effective(main_obj, effective_id)
                    selection = ms_sel_get(main_obj, carrier_key)
                except Exception:
                    selection = None
                if selection is not None:
                    indices = list(selection.get('f', []) or [])
                else:
                    try:
                        indices = [poly.index for poly in obj.data.polygons if bool(poly.select)]
                    except Exception:
                        indices = []
                pre_face_selection_by_obj[obj.name] = indices
        try:
            active_main = get_main_object(active)
        except Exception:
            active_main = active
        master = active_main if active_main in targets else targets[0]
        label = choose_text(defn.get('label', 'Max Modifier'), defn.get('label_ja', defn.get('label', 'Max Modifier')), context=context)
        if backend == 'noise_nodes':
            label = NOISE_MODIFIER_BASE_NAME
        shared_name = ms_next_logical_default_name_across_objects(targets, label) if len(targets) > 1 else None
        added = []
        shared_group = None
        for obj in targets:
            try:
                per_insert = insert_idx
                if per_insert is None:
                    try:
                        per_insert = ms_calc_target_insert_index(master, obj, context)
                    except Exception:
                        per_insert = None
                if backend == 'builtin':
                    mod = _new_builtin_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name)
                elif str(defn.get('key') or '') == 'xform_modifier':
                    # Every XForm row owns its node group and row identity.  A
                    # multi-object add may instance controller values later, but
                    # never shares the owned graph or helper identity.
                    mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name, shared_group=None)
                elif backend in {'skew_nodes', 'melt_nodes', 'affect_region_nodes', 'push_nodes', 'preserve_nodes', 'face_extrude_nodes'}:
                    # Dedicated Skew, Melt, and Affect Region rows own per-object node
                    # groups and helper objects.
                    mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name, shared_group=None)
                elif backend == 'noise_nodes':
                    # Smart Connect Noise also owns a per-object node group and Empty gizmo.
                    mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name, shared_group=None)
                elif _generic_is_backend(defn):
                    # Generic Smart Connect Max nodes own a per-object node group
                    # and helper Empty, just like Noise.
                    mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name, shared_group=None)
                else:
                    mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=per_insert, logical_name=shared_name, shared_group=shared_group)
                    if shared_group is None:
                        try:
                            shared_group = getattr(mod, 'node_group', None)
                        except Exception:
                            shared_group = None
                if mod is not None:
                    added.append((obj, mod))
            except Exception as exc:
                if key_for_targets == 'normalize_spline_modifier':
                    raise RuntimeError('Normalize Spline construction failed / 構築失敗: ' + str(exc)) from exc
                continue
        added_instance_id = ''
        if backend == 'face_extrude_nodes':
            for _obj, _mod in list(added or []):
                configure_face_extrude_modifier(
                    _obj,
                    _mod,
                    getattr(_mod, 'node_group', None),
                    defn,
                    context=context,
                    force_unique_group=False,
                    face_indices=pre_face_selection_by_obj.get(_obj.name, []),
                )
        if len(added) > 1:
            try:
                added_instance_id = ms_group_modifiers_as_instance(added, disp_name=shared_name or label, sync_from_first=(False if (str(defn.get('key') or '') == 'xform_modifier' or backend in {'skew_nodes', 'melt_nodes', 'noise_nodes', 'affect_region_nodes', 'push_nodes', 'preserve_nodes', 'face_extrude_nodes'} or _generic_is_backend(defn)) else True), context=context) or ''
            except Exception:
                added_instance_id = ''
            try:
                for _obj ,_mod in list (added or []):
                    _ms_modifier_set_object_instance_unique (_mod ,True )
            except Exception:
                pass
        if str(defn.get('key') or '') == 'xform_modifier':
            shared_state_id = uuid.uuid4().hex if len(added) > 1 else ''
            try:
                for _obj, _mod in list(added or []):
                    _configure_xform_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
                    _mod[XFORM_SHARED_STATE_PROP] = shared_state_id
            except Exception:
                pass
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        if backend == 'noise_nodes':
            try:
                for _obj, _mod in list(added or []):
                    _configure_noise_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
            # Re-assign the instance id after forcing per-object node groups.
            # Blender 5.1.x can clear non-interface ID properties when a NODES
            # modifier receives a freshly generated node group, so the Smart
            # Modifier instance metadata must be restored after the final group
            # assignment.  Do not copy settings here; each Noise modifier keeps
            # its own Gizmo Empty and node group.
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        if backend == 'push_nodes':
            try:
                for _obj, _mod in list(added or []):
                    configure_push_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
        if backend == 'preserve_nodes':
            for _obj, _mod in list(added or []):
                configure_preserve_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        if backend == 'skew_nodes':
            try:
                for _obj, _mod in list(added or []):
                    _configure_skew_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        if backend == 'affect_region_nodes':
            try:
                for _obj, _mod in list(added or []):
                    _configure_affect_region_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        if _generic_is_backend(defn):
            try:
                for _obj, _mod in list(added or []):
                    _configure_generic_modifier(_obj, _mod, getattr(_mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
            if len(added) > 1:
                try:
                    ms_group_modifiers_as_instance(
                        added,
                        instance_id=(added_instance_id or None),
                        disp_name=shared_name or label,
                        sync_from_first=False,
                        context=context,
                    )
                except Exception:
                    pass
        try:
            ms_apply_auto_selection_to_new_modifiers(targets, before_snapshot, pre_effective_id_by_obj, context=context)
        except Exception:
            pass
        for obj in (source_targets or targets):
            try:
                if key_for_targets != 'normalize_spline_modifier':
                    ms_apply_state_post_action(context, obj, interactive_default=False)
            except Exception:
                pass
        if backend == 'noise_nodes' and added:
            try:
                _noise_select_gizmo(context, added[0][0], added[0][1])
            except Exception:
                pass
        return {'FINISHED'} if added else {'CANCELLED'}
    finally:
        try:
            if key_for_targets != 'normalize_spline_modifier' and 'source_targets' in locals() and source_targets:
                ms_normalize_shape_proxy_visibility_selection(context, source_targets)
        except Exception:
            pass
        if bridge_state is not None:
            try:
                ms_restore_mode_bridge(context, bridge_state)
            except Exception:
                pass


def _draw_add_menu_for(defn):
    def _draw(layout, context):
        label = choose_text(defn.get('label', 'Max Modifier'), defn.get('label_ja', defn.get('label', 'Max Modifier')), context=context)
        row = layout.row(align=True)
        try:
            row.enabled = bool(_supported_objects(context, defn.get('object_types') or ('MESH',))) or str(defn.get('backend')) == 'delegate'
        except Exception:
            pass
        return _sms_icon_operator(row, str(defn.get('operator_id')), text=label, icon_name=_sms_icon_for_defn(defn, 'max'), fallback_icon='MODIFIER')
    _draw.__name__ = f"draw_{defn.get('plugin_id', 'max_modifier')}"
    return _draw


def _is_verified_push_group(group) -> bool:
    required_nodes = {
        'GeometryNodeRepeatInput', 'GeometryNodeRepeatOutput', 'GeometryNodeInputNormal',
        'GeometryNodeSetPosition', 'GeometryNodeBlurAttribute', 'GeometryNodeCollectionInfo',
        'GeometryNodeRaycast', 'GeometryNodeProximity', 'GeometryNodeStoreNamedAttribute',
    }
    try:
        node_types = {str(getattr(node, 'bl_idname', '') or '') for node in group.nodes}
        return (
            str(group.get(PUSH_GROUP_OWNER_PROP, '') or '') == PUSH_GROUP_OWNER_VALUE
            and str(group.get(PUSH_GRAPH_CONTRACT_PROP, '') or '') == PUSH_GRAPH_CONTRACT
            and required_nodes.issubset(node_types)
            and int(group.get('smsm_push_link_count', -1)) == len(group.links)
        )
    except Exception:
        return False


def _match_for(defn):
    plugin_id = str(defn.get('plugin_id') or '')
    key = str(defn.get('key') or '')
    def _match(mod):
        try:
            matched = str(mod.get('smsm_plugin_id', '')) == plugin_id or str(mod.get(KEY_PROP, '')) == key
            if matched:
                return True
            if key == 'push_modifier' and _is_verified_push_group(getattr(mod, 'node_group', None)):
                obj = getattr(mod, 'id_data', None)
                _stamp_modifier(mod, defn)
                configure_push_modifier(obj, mod, mod.node_group, defn, context=bpy.context, force_unique_group=False)
                return bool(mod.get(PUSH_MARKER_PROP, False))
            if key == 'preserve_modifier' and is_verified_preserve_group(getattr(mod, 'node_group', None)):
                obj = getattr(mod, 'id_data', None)
                _stamp_modifier(mod, defn)
                configure_preserve_modifier(obj, mod, mod.node_group, defn, context=bpy.context, force_unique_group=False)
                return bool(mod.get(PRESERVE_MARKER_PROP, False))
            if key == 'normalize_spline_modifier' and is_verified_normalize_group(getattr(mod, 'node_group', None)):
                _stamp_modifier(mod, defn)
                return True
            return False
        except Exception:
            return False
    _match.__name__ = f"match_{key}"
    return _match


def _split_ui(text: str, limit: int = 92):
    text = str(text or '')
    if len(text) <= limit:
        return [text]
    out = []
    buf = ''
    for part in text.replace('。', '。 ').split(' '):
        if not part:
            continue
        if len(buf) + len(part) + 1 > limit and buf:
            out.append(buf.strip())
            buf = part
        else:
            buf = f'{buf} {part}' if buf else part
    if buf:
        out.append(buf.strip())
    return out or [text]




_NODE_INPUT_LABELS = {
    'Mirror Scale': ('Scale', 'スケール'),
    'ミラースケール': ('Scale', 'スケール'),
    'Copy': ('Copy', 'コピー'),
    'コピー': ('Copy', 'コピー'),
    'Mirror Center': ('Center', '中心'),
    'ミラー中心': ('Center', '中心'),
    'Offset': ('Offset', 'オフセット'),
    'オフセット': ('Offset', 'オフセット'),
    'Mirror Rotation': ('Rotation', '回転'),
    'ミラー回転': ('Rotation', '回転'),
    'Weld Seam': ('Weld Seam', '継ぎ目を溶接'),
    '継ぎ目を溶接': ('Weld Seam', '継ぎ目を溶接'),
    'Threshold': ('Threshold', 'しきい値'),
    'しきい値': ('Threshold', 'しきい値'),
}


def _node_input_sockets(mod):
    sockets = {}
    try:
        for item in mod.node_group.interface.items_tree:
            if str(getattr(item, 'item_type', '')) == 'SOCKET' and str(getattr(item, 'in_out', '')) == 'INPUT' and str(getattr(item, 'socket_type', '')) != 'NodeSocketGeometry':
                sockets[str(item.identifier)] = str(item.name)
    except Exception:
        pass
    return sockets


def _draw_modifier_id_properties(layout, mod, context=None):
    skip = {MARKER_KEY, KEY_PROP, BACKEND_PROP, SOURCE_LABEL_PROP, CATEGORY_PROP, _CATEGORY_JA_PROP, 'smsm_plugin_id', 'smsm_max_equivalent', 'smsm_max_description_en', 'smsm_max_description_ja', 'smsm_ui_generation', 'ms_instance_id', '_ms_instance_last_source_sig', 'smsm_noise_modifier', NOISE_GIZMO_NAME_PROP, NOISE_GIZMO_SOCKET_PROP, NOISE_SCALE_SOCKET_PROP, NOISE_STRENGTH_SOCKET_PROP, NOISE_PHASE_SOCKET_PROP, NOISE_NODE_GROUP_PROP, NOISE_HELPER_PROP, NOISE_PROXY_OWNER_PROP, 'smsm_generic_modifier', GENERIC_GIZMO_NAME_PROP, GENERIC_GIZMO_SOCKET_PROP, GENERIC_NODE_GROUP_PROP, GENERIC_HELPER_PROP, GENERIC_PROXY_OWNER_PROP, GENERIC_COLLECTION_PROP, GENERIC_KIND_PROP, GENERIC_GIZMO_TARGET_PROP, GENERIC_GIZMO_MODIFIER_PROP, SKEW_MARKER_PROP, SKEW_NODE_GROUP_PROP, SKEW_GRAPH_CONTRACT_PROP, MELT_MARKER_PROP, MELT_NODE_GROUP_PROP, MELT_GRAPH_CONTRACT_PROP, AFFECT_REGION_MARKER_PROP, AFFECT_REGION_NODE_GROUP_PROP, AFFECT_REGION_GRAPH_CONTRACT_PROP, AFFECT_REGION_START_NAME_PROP, AFFECT_REGION_END_NAME_PROP, AFFECT_REGION_POINT_ROLE_PROP, PUSH_MARKER_PROP, PUSH_NODE_GROUP_PROP, PUSH_GRAPH_CONTRACT_PROP}
    skip.update({PRESERVE_MARKER_PROP, PRESERVE_NODE_GROUP_PROP, PRESERVE_GRAPH_CONTRACT_PROP})
    drawn = False
    try:
        keys = [str(k) for k in mod.keys() if str(k) not in skip and not str(k).startswith('_') and not str(k).startswith(('smsm_', 'sms_', 'ms_', 'jel_'))]
        try:
            if bool(mod.get('sms_xform_modifier', False)):
                xform_keys = set(_xform_skip_copy_props(mod))
                xform_keys.update(str(mod.get(XFORM_SOCKET_PREFIX + key, '') or '') for key in ('translation', 'rotation', 'scale', 'center', 'use_named_selection', 'selection_name', 'coordinate_mode', 'reference_object', 'world_pivot_center', 'preserve_normals'))
                keys = [key for key in keys if key not in xform_keys and not key.startswith('Socket_') and not key.startswith('sms_xform_')]
            if bool(mod.get('smsm_noise_modifier', False)):
                noise_keys = {
                    str(mod.get(NOISE_GIZMO_SOCKET_PROP, '') or ''),
                    str(mod.get(NOISE_SCALE_SOCKET_PROP, '') or ''),
                    str(mod.get(NOISE_STRENGTH_SOCKET_PROP, '') or ''),
                    str(mod.get(NOISE_PHASE_SOCKET_PROP, '') or ''),
                    'Gizmo', 'Scale', 'Strength', 'Phase', 'ギズモ', 'スケール', '強度', 'フェーズ',
                }
                keys = [k for k in keys if k not in noise_keys and not k.startswith('Socket_')]
            if bool(mod.get('smsm_generic_modifier', False)):
                generic_keys = {
                    str(mod.get(GENERIC_GIZMO_SOCKET_PROP, '') or ''),
                    'Gizmo', 'Influence', 'Amount', 'Strength', 'Angle', 'Radius', 'U Tiling', 'V Tiling', 'U Offset', 'V Offset',
                    'ギズモ', '影響度', '量', '強度', '角度', '半径', 'U タイル', 'V タイル', 'U オフセット', 'V オフセット',
                }
                keys = [k for k in keys if k not in generic_keys and not k.startswith('Socket_')]
            if bool(mod.get(SQUEEZE_MARKER_PROP, False)):
                squeeze_keys = {
                    SQUEEZE_MARKER_PROP,
                    SQUEEZE_NODE_GROUP_PROP,
                    SQUEEZE_GRAPH_CONTRACT_PROP,
                    *(str(mod.get(SQUEEZE_SOCKET_PREFIX + key, '') or '') for key in (
                        'gizmo', 'squeeze', 'squeeze_curve', 'bulge', 'bulge_curve',
                        'influence', 'use_limits', 'lower_limit', 'upper_limit', 'bias', 'volume',
                    )),
                }
                keys = [k for k in keys if k not in squeeze_keys and not k.startswith('Socket_') and not k.startswith(SQUEEZE_SOCKET_PREFIX)]
            if bool(mod.get(PUSH_MARKER_PROP, False)):
                push_keys = {str(mod.get(PUSH_SOCKET_PREFIX + key, '') or '') for key in ('amount', 'steps', 'normal_relax_iterations', 'vertex_relax_iterations', 'collision_objects', 'falloff', 'axis_multiplier', 'scale_normals', 'influence')}
                keys = [k for k in keys if k not in push_keys and not k.startswith(PUSH_SOCKET_PREFIX)]
            if bool(mod.get(SKEW_MARKER_PROP, False)):
                skew_keys = {
                    str(mod.get(k, '') or '') for k in mod.keys() if str(k).startswith(SKEW_SOCKET_PREFIX)
                } | {
                    'Gizmo', 'Amount', 'Direction', 'Primary Axis', 'Use Limits', 'Lower Limit', 'Upper Limit', 'Influence',
                    'Curve', 'Effect', 'Symmetry', 'Stretch', 'Amplify',
                    'ギズモ', '量', '方向', '主軸', '制限を使用', '下限', '上限', '影響度',
                    'カーブ', '効果の軸', '対称', 'ストレッチ', '増幅',
                }
                keys = [k for k in keys if k not in skew_keys and not k.startswith('smsm_skew_socket_')]
            if bool(mod.get(MELT_MARKER_PROP, False)):
                melt_keys = {
                    str(mod.get(MELT_SOCKET_PREFIX + key, '') or '')
                    for key in ('gizmo', 'amount', 'spread', 'preset', 'custom_solidity', 'axis', 'flip_axis', 'influence')
                }
                keys = [k for k in keys if k not in melt_keys and not k.startswith(MELT_SOCKET_PREFIX)]
            if bool(mod.get(AFFECT_REGION_MARKER_PROP, False)):
                affect_keys = {
                    str(mod.get(AFFECT_REGION_SOCKET_PREFIX + key, '') or '')
                    for key in ('start', 'end', 'falloff', 'pinch', 'bubble', 'influence', 'ignore_back_facing')
                }
                keys = [k for k in keys if k not in affect_keys and not k.startswith(AFFECT_REGION_SOCKET_PREFIX)]
        except Exception:
            pass
    except Exception:
        keys = []
    # Socket_N is only a raw identifier: draw it under its node input name, and
    # leave out what a tool's own controls already draw. A key that merely repeats
    # an input name is not connected to the node group.
    node_inputs = _node_input_sockets(mod)
    try:
        owned = {str(mod.get(k)) for k in mod.keys() if str(k).startswith(('smsm_', 'sms_')) and 'socket' in str(k)}
        if '_smsm_reset_xform_modifier' in mod:
            owned.update(node_inputs)
    except Exception:
        owned = set()
    for key in keys:
        try:
            if key.endswith(('_use_attribute', '_attribute_name')):
                continue
            if key.startswith('Socket_'):
                if key in owned or key not in node_inputs:
                    continue
                name = node_inputs[key]
                en, ja = _NODE_INPUT_LABELS.get(name, (name, name))
                layout.prop(mod, f'["{key}"]', text=choose_text(en, ja, context=context))
                drawn = True
                continue
            if key in node_inputs.values():
                continue
            layout.prop(mod, f'["{key}"]', text=key.replace('_', ' ').title())
            drawn = True
        except Exception:
            pass
    return drawn


# Sweep (schema 3): the inputs of the 3ds Max Sweep Parameters rollout.
_SWEEP_V3_INPUTS = (
    'Mirror On XZ Plane', 'Mirror On XY Plane', 'X Offset', 'Y Offset', 'Angle',
    'Smooth Section', 'Smooth Path', 'Pivot Alignment', 'Banking', 'Union Intersections',
    'Gen. Mapping Coords', 'Real-World Map Size', 'Generate Material IDs', 'Use Section IDs', 'Use Path IDs',
)
# Pivot Alignment buttons: value = column * 3 + row, the column-major order of the 3ds Max grid.
_SWEEP_PIVOT_ROWS = (('top', '上'), ('middle', '中'), ('bottom', '下'))
_SWEEP_PIVOT_COLUMNS = (('left', '左'), ('center', '中央'), ('right', '右'))


def _sweep_v3_inputs(mod):
    """{input name: identifier} of a schema 3 Sweep row, or None."""
    try:
        if not bool(mod.get('sms_sweep_modifier', False)):
            return None
        group = getattr(mod, 'node_group', None)
        if group is None or int(group.get('sms_sweep_schema', 0) or 0) < 3:
            return None
        inputs = _sweep_group_inputs(group)
    except Exception:
        return None
    if not inputs or any(name not in inputs for name in _SWEEP_V3_INPUTS):
        return None
    return inputs


def _draw_sweep_node_properties(layout, mod, context=None) -> bool:
    """Sweep rows in the order of the 3ds Max Sweep Parameters rollout (schema 3 only)."""
    inputs = _sweep_v3_inputs(mod)
    if inputs is None:
        return False
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')

    def value(name, default):
        try:
            return mod.get(inputs[name], default)
        except Exception:
            return default

    def prop(col, name, en, ja, enabled=True):
        sid = inputs.get(name)
        if not sid:
            return
        row = col.row(align=True)
        row.enabled = bool(enabled)
        row.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))

    box = layout.box()
    draw_help_header(box, context, choose_text('Sweep Parameters', 'スイープパラメーター', context=context), 'CURVE_PATH', 'max_sweep_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = False
    prop(col, 'Profile Curve', 'Profile Curve', 'プロファイルカーブ')
    prop(col, 'Sweep Resolution', 'Sweep Resolution', 'スイープ解像度')
    prop(col, 'Sweep Fill Caps', 'Sweep Fill Caps', 'スイープ端面を閉じる')
    col.separator()
    prop(col, 'Mirror On XZ Plane', 'Mirror On XZ Plane', 'XZ 平面でミラー')
    prop(col, 'Mirror On XY Plane', 'Mirror On XY Plane', 'XY 平面でミラー')
    prop(col, 'X Offset', 'X Offset', 'X オフセット')
    prop(col, 'Y Offset', 'Y Offset', 'Y オフセット')
    prop(col, 'Angle', 'Angle', '角度')
    prop(col, 'Smooth Section', 'Smooth Section', '断面をスムーズ')
    prop(col, 'Smooth Path', 'Smooth Path', 'パスをスムーズ')
    try:
        pivot = int(value('Pivot Alignment', -1))
    except Exception:
        pivot = -1
    grid = col.column(align=True)
    head = grid.row(align=True)
    head.label(text=choose_text('Pivot Alignment', 'ピボット位置合わせ', context=context), icon='PIVOT_BOUNDBOX')
    if not (0 <= pivot <= 8):
        head.label(text=choose_text('Profile origin', 'プロファイルの原点', context=context))
    for row_index in range(3):
        line = grid.row(align=True)
        for column_index in range(3):
            button = column_index * 3 + row_index
            active = pivot == button
            op = line.operator('smsm.max_sweep_set_pivot', text='', icon=('RADIOBUT_ON' if active else 'RADIOBUT_OFF'), depress=active)
            op.object_name = obj_name
            op.modifier_name = mod_name
            op.value = button
    prop(col, 'Banking', 'Banking', 'バンク')
    prop(col, 'Union Intersections', 'Union Intersections', '交差部を結合')
    mapping = bool(value('Gen. Mapping Coords', False))
    prop(col, 'Gen. Mapping Coords', 'Gen. Mapping Coords', 'マッピング座標を生成')
    prop(col, 'Real-World Map Size', 'Real-World Map Size', '実際のマップサイズ', enabled=mapping)
    generate = bool(value('Generate Material IDs', True))
    prop(col, 'Generate Material IDs', 'Generate Material IDs', 'マテリアル ID を生成')
    prop(col, 'Use Section IDs', 'Use Section IDs', '断面の ID を使用', enabled=generate)
    prop(col, 'Use Path IDs', 'Use Path IDs', 'パスの ID を使用', enabled=generate)
    return True


def _draw_xform_node_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get('sms_xform_modifier', False)):
            return False
    except Exception:
        return False
    _ensure_xform_row_state(mod)
    owner = getattr(mod, 'id_data', None)
    obj_name = str(getattr(owner, 'name', '') or '')
    mod_name = str(getattr(mod, 'name', '') or '')
    mode = str(mod.get(XFORM_MODE_PROP, 'GIZMO') or 'GIZMO')
    subcontrol = str(mod.get(XFORM_SUBCONTROL_PROP, 'GIZMO') or 'GIZMO')
    box = layout.box()
    draw_help_header(box, context, choose_text('XForm Controls', 'Xフォーム制御', context=context), 'ORIENTATION_GIMBAL', 'max_xform_modifier')
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = True
    row = col.row(align=True)
    row.label(text=choose_text('Coordinate Mode', '座標モード', context=context))
    for value, en, ja in (('GIZMO', 'Gizmo', 'ギズモ'), ('LOCAL', 'Local', 'ローカル'), ('WORLD', 'World', 'ワールド'), ('REFERENCE_OBJECT', 'Reference', '参照')):
        op = row.operator('smsm.max_xform_set_mode', text=choose_text(en, ja, context=context), depress=(mode == value))
        op.object_name = obj_name
        op.modifier_name = mod_name
        op.mode = value
    row = col.row(align=True)
    row.label(text=choose_text('Sub-control', 'サブコントロール', context=context))
    for value, en, ja, icon in (('GIZMO', 'Gizmo', 'ギズモ', 'ORIENTATION_GIMBAL'), ('CENTER', 'Center', '中心', 'PIVOT_MEDIAN')):
        op = row.operator('smsm.max_xform_set_subcontrol', text=choose_text(en, ja, context=context), icon=icon, depress=(subcontrol == value))
        op.object_name = obj_name
        op.modifier_name = mod_name
        op.subcontrol = value
    for key, en, ja in (
        ('translation', 'Translation', '移動'),
        ('rotation', 'Rotation', '回転'),
        ('scale', 'Scale', 'スケール'),
        ('center', 'Gizmo Center', 'ギズモ中心'),
        ('use_named_selection', 'Use Named Selection', '名前付き選択を使用'),
        ('selection_name', 'Selection Name', '選択名'),
        ('preserve_normals', 'Preserve Normals', '法線を保持'),
    ):
        sid = str(mod.get(XFORM_SOCKET_PREFIX + key, '') or '')
        if not sid:
            continue
        # 3ds Max の変換の値の入力と同じく、選んだサブコントロールの値だけを出す。
        if key in ('translation', 'rotation', 'scale') and subcontrol == 'CENTER':
            continue
        if key == 'center' and subcontrol != 'CENTER':
            continue
        if key == 'selection_name':
            use_sid = str(mod.get(XFORM_SOCKET_PREFIX + 'use_named_selection', '') or '')
            if use_sid and not bool(mod.get(use_sid, False)):
                continue
        try:
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
        except Exception:
            pass
    if mode == 'WORLD':
        sid = str(mod.get(XFORM_SOCKET_PREFIX + 'world_pivot_center', '') or '')
        if sid:
            col.prop(mod, f'["{sid}"]', text=choose_text('World Pivot Center', 'ワールドのピボット中心', context=context))
    if mode == 'REFERENCE_OBJECT':
        sid = str(mod.get(XFORM_SOCKET_PREFIX + 'reference_object', '') or '')
        if sid:
            col.prop(mod, f'["{sid}"]', text=choose_text('Reference Object', '参照オブジェクト', context=context))
    return True


def _draw_props_for(defn):
    def _draw(layout, mod, obj=None, context=None):
        if not _match_for(defn)(mod):
            return False
        label = choose_text(defn.get('label', 'Max Modifier'), defn.get('label_ja', defn.get('label', 'Max Modifier')), context=context)
        category = choose_text(defn.get('category', ''), defn.get('category_ja', defn.get('category', '')), context=context)
        backend = str(defn.get('backend') or '')
        box = layout.box()
        draw_help_header(box, context, label, _sms_icon_for_defn(defn, 'max'), 'max_modifier_parameters')
        col = box.column(align=True)
        col.label(text=choose_text(f"3ds Max equivalent: {defn.get('label', '')}", f"3ds Max 相当: {defn.get('label_ja') or defn.get('label', '')}", context=context))
        col.label(text=choose_text(f"Category: {category}", f"カテゴリ: {category}", context=context))
        if str(defn.get('key') or '') == 'linked_xform_modifier':
            draw_linked(col, mod, obj=obj, context=context)
            return True
        if str(defn.get('key') or '') == 'normalize_spline_modifier':
            draw_normalize(col, mod)
            return True
        try:
            _draw_xform_node_properties(col, mod, context=context)
            _draw_max_parameter_props(col, mod, context=context)
            _draw_noise_node_properties(col, mod, context=context)
            draw_push_properties(col, mod, context=context)
            draw_preserve_properties(col, mod, context=context)
            draw_face_extrude_properties(col, mod, context=context)
            _draw_skew_node_properties(col, mod, context=context)
            _draw_melt_node_properties(col, mod, context=context)
            _draw_affect_region_node_properties(col, mod, context=context)
            _draw_squeeze_node_properties(col, mod, context=context)
            _draw_generic_node_properties(col, mod, context=context)
            _sweep_drawn = _draw_sweep_node_properties(col, mod, context=context)
            if not _sweep_drawn and not _other_plugin_draws_row(mod):
                _draw_modifier_id_properties(col, mod, context=context)
        except Exception:
            pass
        return True
    _draw.__name__ = f"draw_props_{defn.get('key', 'max_modifier')}"
    return _draw


def _other_plugin_draws_row(mod) -> bool:
    """委譲先の道具（UVW マップなど）が自分の欄を描く行では、ノード入力をここで重ねて描かない。"""
    try:
        from ...core import ms_get_plugins_sorted
        from ...max_modifier_definitions import get_max_modifier_definition
        plugins = ms_get_plugins_sorted()
    except Exception:
        return False
    for plugin in plugins:
        try:
            if get_max_modifier_definition(plugin_id=str(plugin.get('id') or '')) is not None:
                continue
            match = plugin.get('match_modifier')
            if callable(match) and callable(plugin.get('draw_modifier_properties_extra')) and match(mod):
                return True
        except Exception:
            continue
    return False


def _clipboard_copy_for(defn):
    def _copy(main_obj, context, obj, mod):
        payload = {'kind': 'max_modifier_library', 'definition_key': str(defn.get('key') or ''), 'modifier_type': str(getattr(mod, 'type', '') or ''), 'modifier_name': str(getattr(mod, 'name', '') or ''), 'custom_properties': {}, 'settings': {}}
        try:
            if str((defn or {}).get('key') or '') == 'xform_modifier':
                skip_props = _xform_skip_copy_props(mod)
            elif bool(mod.get('smsm_noise_modifier', False)):
                skip_props = _noise_skip_copy_props(mod)
            elif bool(mod.get(AFFECT_REGION_MARKER_PROP, False)):
                skip_props = _affect_region_skip_copy_props(mod)
            elif bool(mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
                skip_props = face_extrude_skip_copy_props(mod)
            elif bool(mod.get('smsm_generic_modifier', False)):
                skip_props = _generic_skip_copy_props(mod)
            else:
                skip_props = set()
            payload['custom_properties'] = {str(k): mod.get(k) for k in mod.keys() if str(k) not in skip_props}
        except Exception:
            pass
        try:
            for prop in mod.bl_rna.properties:
                ident = str(prop.identifier)
                if prop.is_readonly or ident in {'rna_type', 'name', 'type'}:
                    continue
                try:
                    value = getattr(mod, ident)
                    if isinstance(value, (str, int, float, bool)):
                        payload['settings'][ident] = value
                except Exception:
                    pass
        except Exception:
            pass
        return payload
    return _copy


def _clipboard_paste_for(defn):
    def _paste(main_obj, context, obj, insert_idx, clipboard):
        payload = clipboard.get('payload') or {}
        if payload.get('kind') != 'max_modifier_library':
            return ''
        try:
            if str(defn.get('backend')) == 'builtin':
                result_mod = _new_builtin_modifier(obj, defn, context=context, insert_idx=insert_idx)
            else:
                result_mod = _new_nodes_modifier(obj, defn, context=context, insert_idx=insert_idx)
            if result_mod is not None:
                if str((defn or {}).get('key') or '') == 'xform_modifier':
                    skip_props = _xform_skip_copy_props(result_mod)
                elif bool(result_mod.get('smsm_noise_modifier', False)):
                    skip_props = _noise_skip_copy_props(result_mod)
                elif bool(result_mod.get(AFFECT_REGION_MARKER_PROP, False)):
                    skip_props = _affect_region_skip_copy_props(result_mod)
                elif bool(result_mod.get(PRESERVE_MARKER_PROP, False)):
                    skip_props = _generic_skip_copy_props(result_mod) | preserve_skip_copy_props(result_mod)
                elif bool(result_mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
                    skip_props = face_extrude_skip_copy_props(result_mod)
                elif bool(result_mod.get('smsm_generic_modifier', False)):
                    skip_props = _generic_skip_copy_props(result_mod)
                else:
                    skip_props = set()
                for k, v in (payload.get('custom_properties') or {}).items():
                    if str(k) in skip_props:
                        continue
                    try:
                        result_mod[k] = v
                    except Exception:
                        pass
                for k, v in (payload.get('settings') or {}).items():
                    if str(k) in skip_props:
                        continue
                    _try_set_prop_or_attr(result_mod, k, v)
                if bool(result_mod.get(FACE_EXTRUDE_MARKER_PROP, False)):
                    try:
                        indices = [poly.index for poly in obj.data.polygons if bool(poly.select)]
                    except Exception:
                        indices = []
                    capture_face_selection(obj, result_mod, indices)
                return result_mod.name
        except Exception:
            if str((defn or {}).get('backend') or '') in {'push_nodes', 'preserve_nodes'} or str((defn or {}).get('key') or '') in {'push_modifier', 'preserve_modifier'}:
                raise
            pass
        return ''
    return _paste


def _cleanup_before_remove_for(defn):
    def _cleanup(main_obj, context, obj, mod):
        if str((defn or {}).get('key') or '') == 'linked_xform_modifier':
            cleanup_linked(mod)
            return
        if str((defn or {}).get('key') or '') == 'normalize_spline_modifier':
            cleanup_normalize(mod)
            return
        try:
            if str((defn or {}).get('key') or '') == 'sweep_modifier':
                group = getattr(mod, 'node_group', None)
                if (
                    group is not None
                    and int(group.get('sms_sweep_schema', 0) or 0) in _SWEEP_GROUP_SCHEMAS
                    and bool(group.get('sms_owned_node_group', False))
                    and int(getattr(group, 'users', 0) or 0) <= 1
                ):
                    bpy.data.node_groups.remove(group)
                return
        except Exception:
            return
        try:
            if str((defn or {}).get('backend') or '') == 'xform_nodes' or str((defn or {}).get('key') or '') == 'xform_modifier':
                group = getattr(mod, 'node_group', None)
                if (
                    group is not None
                    and _is_trusted_owned_xform_group(group, mod)
                    and int(getattr(group, 'users', 0) or 0) <= 1
                ):
                    _forget_xform_group_ownership(group)
                    bpy.data.node_groups.remove(group)
                _release_xform_row(mod)
                return
        except Exception:
            # XForm ownership is fail-closed: never reach the generic name fallback.
            return
        try:
            if str((defn or {}).get('backend') or '') == 'noise_nodes' or str((defn or {}).get('key') or '') == 'noise_modifier':
                return
        except Exception:
            pass
        try:
            if str((defn or {}).get('backend') or '') == 'affect_region_nodes' or str((defn or {}).get('key') or '') == 'affect_region_modifier':
                return
        except Exception:
            pass
        try:
            if str((defn or {}).get('backend') or '') == 'face_extrude_nodes' or str((defn or {}).get('key') or '') == 'face_extrude_modifier':
                return
        except Exception:
            return
        try:
            if _generic_is_backend(defn) or bool(mod.get('smsm_generic_modifier', False)):
                state = _generic_collect_cleanup_state(obj, mod)
                gizmo_name = str(state.get('gizmo', '') or '')
                if gizmo_name:
                    _generic_remove_object_if_unused(gizmo_name, GENERIC_GIZMO_NAME_PROP)
                return
        except Exception:
            pass
        try:
            group = getattr(mod, 'node_group', None)
            if group is not None and str(getattr(group, 'name', '')).startswith('SMS Max '):
                if int(getattr(group, 'users', 0) or 0) <= 1:
                    bpy.data.node_groups.remove(group)
        except Exception:
            pass
    return _cleanup


def _sweep_cleanup_before_apply(main_obj, context, obj, mod):
    """Bake a sole Curve Sweep through Blender's supported object conversion."""
    try:
        is_sweep = bool(mod.get('sms_sweep_modifier', False))
    except Exception:
        is_sweep = False
    if not is_sweep:
        raise RuntimeError('The selected modifier is not a verified SmartModifier Sweep.')
    if getattr(obj, 'type', '') != 'CURVE':
        return
    if str(getattr(obj, 'mode', '') or '') != 'OBJECT':
        raise RuntimeError('Sweep can only be applied in Object Mode.')
    try:
        target_index = int(obj.modifiers.find(mod.name))
    except Exception:
        target_index = -1
    if target_index != 0 or len(obj.modifiers) != 1:
        raise RuntimeError('Sweep must be the only modifier before it can be applied safely.')

    old_curve = getattr(obj, 'data', None)
    shape_keys = getattr(old_curve, 'shape_keys', None)
    if shape_keys is not None and len(getattr(shape_keys, 'key_blocks', ()) or ()) > 0:
        raise RuntimeError('Sweep apply does not discard curve shape keys; remove or bake them first.')

    target_state = (
        bool(getattr(mod, 'show_viewport', True)),
        bool(getattr(mod, 'show_render', True)),
    )
    probe_mesh = None
    try:
        mod.show_viewport = True
        mod.show_render = True
        try:
            context.view_layer.update()
        except Exception:
            pass
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        try:
            probe_mesh = bpy.data.meshes.new_from_object(
                evaluated,
                preserve_all_data_layers=False,
                depsgraph=depsgraph,
            )
        except TypeError:
            probe_mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
        if probe_mesh is None or len(getattr(probe_mesh, 'polygons', ())) <= 0:
            raise RuntimeError('Sweep evaluation produced no mesh faces.')
    finally:
        try:
            mod.show_viewport, mod.show_render = target_state
        except Exception:
            pass
        try:
            context.view_layer.update()
        except Exception:
            pass
        try:
            if probe_mesh is not None and int(getattr(probe_mesh, 'users', 0) or 0) == 0:
                bpy.data.meshes.remove(probe_mesh)
        except Exception:
            pass

    group = getattr(mod, 'node_group', None)
    selected_before = list(getattr(context, 'selected_objects', ()) or ())
    active_before = getattr(context.view_layer.objects, 'active', None)
    try:
        for selected in selected_before:
            selected.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        mod.show_viewport = True
        mod.show_render = True
        result = bpy.ops.object.convert('EXEC_DEFAULT', target='MESH', keep_original=False)
        if result != {'FINISHED'} or getattr(obj, 'type', '') != 'MESH':
            raise RuntimeError(f'Blender Curve-to-Mesh conversion failed: {result}')
        if len(getattr(obj.data, 'polygons', ())) <= 0:
            raise RuntimeError('Blender Curve-to-Mesh conversion produced no faces.')
    finally:
        try:
            for selected in tuple(getattr(context, 'selected_objects', ()) or ()):
                selected.select_set(False)
            for selected in selected_before:
                if selected is not None and selected.name in bpy.data.objects:
                    selected.select_set(True)
            if active_before is not None and active_before.name in bpy.data.objects:
                context.view_layer.objects.active = active_before
        except Exception:
            pass

    try:
        if old_curve is not None and int(getattr(old_curve, 'users', 0) or 0) == 0:
            bpy.data.curves.remove(old_curve)
    except Exception:
        pass
    try:
        if (
            group is not None
            and int(group.get('sms_sweep_schema', 0) or 0) in _SWEEP_GROUP_SCHEMAS
            and bool(group.get('sms_owned_node_group', False))
            and int(getattr(group, 'users', 0) or 0) == 0
        ):
            bpy.data.node_groups.remove(group)
    except Exception:
        pass
    try:
        obj.update_tag()
    except Exception:
        pass


def _make_operator_class(defn):
    key = str(defn.get('key') or 'modifier')
    op_id = str(defn.get('operator_id') or f'smsm.max_{key}')
    label = str(defn.get('label') or key.replace('_', ' ').title())
    class_name = 'SMSM_OT_max_' + key.replace('-', '_')

    def execute(self, context):
        result = add_max_modifier(context, defn)
        if result == {'CANCELLED'}:
            msg = choose_text(
                f"Could not add {label}. Select a supported object or check required source/target setup.",
                f"{defn.get('label_ja') or label} を追加できませんでした。対応オブジェクトの選択、または必要な参照元 / 参照先設定を確認してください。",
                context=context,
            )
            try:
                self.report({'WARNING'}, msg)
            except Exception:
                pass
        return result

    @classmethod
    def poll(cls, context):
        if str(defn.get('backend')) == 'delegate':
            return True
        return bool(_supported_objects(context, defn.get('object_types') or ('MESH',)))

    @classmethod
    def description(cls, context, properties):
        desc = choose_text(defn.get('description_en', ''), defn.get('description_ja', ''), context=context)
        usage = choose_text(defn.get('usage_en', ''), defn.get('usage_ja', ''), context=context)
        return (desc + ('\n\n' + usage if usage else '')).strip()

    attrs = {
        '__module__': __name__,
        'bl_idname': op_id,
        'bl_label': label,
        'bl_description': defn.get('description_en', label),
        'bl_options': {'REGISTER', 'UNDO'},
        'execute': execute,
        'poll': poll,
        'description': description,
        '_smsm_max_definition': defn,
    }
    return type(class_name, (Operator,), attrs)



def _stack_get_target_modifier(context, object_name: str = '', modifier_name: str = ''):
    obj = bpy.data.objects.get(str(object_name or '')) if str(object_name or '') else None
    if obj is None:
        try:
            obj = get_main_object(getattr(context, 'active_object', None)) or getattr(context, 'active_object', None)
        except Exception:
            obj = getattr(context, 'active_object', None)
    if obj is None:
        return None, None
    mod = None
    if modifier_name:
        try:
            mod = obj.modifiers.get(str(modifier_name))
        except Exception:
            mod = None
    if mod is None:
        try:
            mod = getattr(obj.modifiers, 'active', None)
        except Exception:
            mod = None
    return obj, mod






class SMSM_OT_max_xform_set_mode(Operator):
    bl_idname = 'smsm.max_xform_set_mode'
    bl_label = 'Set XForm Coordinate Mode'
    bl_description = 'Sets the coordinate system owned by this XForm stack row.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')
    mode: StringProperty(default='GIZMO')

    def execute(self, context):
        obj, mod = _stack_get_target_modifier(context, self.object_name, self.modifier_name)
        try:
            valid = obj is not None and mod is not None and bool(mod.get('sms_xform_modifier', False))
        except Exception:
            valid = False
        if not valid or str(self.mode or '').upper() not in XFORM_COORDINATE_MODES:
            self.report({'ERROR'}, choose_text('XForm row was not found.', 'Xフォーム行が見つかりません。', context=context))
            return {'CANCELLED'}
        _xform_set_mode_value(mod, self.mode)
        try:
            ms_sync_instance_group_from(obj, mod, context=context)
            obj.update_tag()
        except Exception:
            pass
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Selects Gizmo, Local, World, or Reference Object coordinates for this ordered XForm row. Explicit instances share controller values; independent copies do not.',
            'この順序付き Xフォーム行の座標をギズモ、ローカル、ワールド、参照オブジェクトから選びます。明示的なインスタンスは制御値を共有し、独立コピーは共有しません。',
            context=context,
        )


class SMSM_OT_max_xform_set_subcontrol(Operator):
    bl_idname = 'smsm.max_xform_set_subcontrol'
    bl_label = 'Select XForm Sub-control'
    bl_description = 'Selects the Gizmo or Center sub-control owned by this XForm row.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')
    subcontrol: StringProperty(default='GIZMO')

    def execute(self, context):
        obj, mod = _stack_get_target_modifier(context, self.object_name, self.modifier_name)
        value = str(self.subcontrol or 'GIZMO').upper()
        try:
            if (mod is not None and not mod.get('sms_xform_modifier', False)
                    and _saved_xform_sockets(getattr(mod, 'node_group', None)) is not None):
                # ノードエディターでのつなぎ替えなどで印が落ちた行：グループから印を戻す。
                _rehydrate_xform_modifier_metadata()
        except Exception:
            pass
        try:
            valid = obj is not None and mod is not None and bool(mod.get('sms_xform_modifier', False)) and value in {'GIZMO', 'CENTER'}
        except Exception:
            valid = False
        if not valid:
            self.report({'ERROR'}, choose_text('XForm sub-control was not found.', 'Xフォームのサブコントロールが見つかりません。', context=context))
            return {'CANCELLED'}
        mod[XFORM_SUBCONTROL_PROP] = value
        try:
            wired = bool(_apply_xform_subcontrol(mod, context=context))
        except Exception:
            wired = False
        # Geometry Nodes のギズモは有効な行の分だけ出るので、選んだ行を有効にする。
        try:
            obj.modifiers.active = mod
        except Exception:
            pass
        try:
            obj.update_tag()
        except Exception:
            pass
        if not wired:
            self.report({'WARNING'}, choose_text(
                'The viewport gizmo could not be attached to this XForm graph.',
                'この Xフォームのグラフにビューポートのギズモを付けられませんでした。',
                context=context))
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Like the 3ds Max XForm sub-object levels: Gizmo shows a move / rotate / scale gizmo that transforms the mesh, Center shows a move gizmo for the pivot used by rotation and scale. The gizmo appears in the viewport while this row is the active modifier.',
            '3ds Max の XForm のサブオブジェクトと同じです。ギズモはメッシュを動かす移動・回転・拡大のギズモを、中心は回転と拡大の軸になるピボットを動かす移動のギズモをビューポートに出します。ギズモはこの行が有効なモディファイアの間に出ます。',
            context=context,
        )






class SMSM_OT_max_melt_set_enum(Operator):
    bl_idname = 'smsm.max_melt_set_enum'
    bl_label = 'Set Melt Control'
    bl_description = 'Sets the selected solidity preset or local melt axis for this Melt stack row.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')
    field: StringProperty(default='PRESET')
    value: IntProperty(default=0)

    def execute(self, context):
        obj, mod = _stack_get_target_modifier(context, self.object_name, self.modifier_name)
        try:
            valid = obj is not None and mod is not None and bool(mod.get(MELT_MARKER_PROP, False))
        except Exception:
            valid = False
        field = str(self.field or '').upper()
        key = 'preset' if field == 'PRESET' else ('axis' if field == 'AXIS' else '')
        limit = 4 if key == 'preset' else 2
        if not valid or not key or not (0 <= int(self.value) <= limit):
            self.report({'ERROR'}, choose_text('Melt row was not found.', 'メルト行が見つかりません。', context=context))
            return {'CANCELLED'}
        sid = str(mod.get(MELT_SOCKET_PREFIX + key, '') or '')
        if not sid:
            self.report({'ERROR'}, choose_text('Melt socket was not found.', 'メルトソケットが見つかりません。', context=context))
            return {'CANCELLED'}
        try:
            mod[sid] = int(self.value)
            obj.update_tag()
            ms_sync_instance_group_from(obj, mod, context=context)
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Sets a 3ds Max-style Melt solidity preset or the gizmo-local X, Y, or Z melt axis.',
            '3ds Max 形式のメルト用ソリディティプリセット、またはギズモローカルの X、Y、Z メルト軸を設定します。',
            context=context,
        )



class SMSM_OT_max_sweep_set_pivot(Operator):
    bl_idname = 'smsm.max_sweep_set_pivot'
    bl_label = 'Set Sweep Pivot Alignment'
    bl_description = 'Puts a point of the section bounding box on the path, like the 3ds Max Sweep Pivot Alignment grid.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')
    value: IntProperty(default=-1, min=-1, max=8)

    def execute(self, context):
        obj, mod = _stack_get_target_modifier(context, self.object_name, self.modifier_name)
        inputs = _sweep_v3_inputs(mod) if mod is not None else None
        if obj is None or inputs is None:
            self.report({'ERROR'}, choose_text('Sweep row was not found.', 'スイープ行が見つかりません。', context=context))
            return {'CANCELLED'}
        sid = inputs['Pivot Alignment']
        try:
            current = int(mod.get(sid, -1))
        except Exception:
            current = -1
        value = int(self.value)
        # Clicking the pressed button again goes back to the profile origin.
        new_value = -1 if value == current else value
        try:
            mod[sid] = new_value
            obj.update_tag()
            ms_sync_instance_group_from(obj, mod, context=context)
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        value = int(getattr(properties, 'value', -1))
        if not (0 <= value <= 8):
            return choose_text('Uses the profile origin as the pivot.', 'プロファイルの原点をピボットにします。', context=context)
        column, row = divmod(value, 3)
        row_en, row_ja = _SWEEP_PIVOT_ROWS[row]
        column_en, column_ja = _SWEEP_PIVOT_COLUMNS[column]
        return choose_text(
            f'Puts the {row_en} {column_en} point of the section bounding box on the path. Click the pressed button again to use the profile origin.',
            f'断面の外枠の{row_ja}・{column_ja}の点をパスに合わせます。押されているボタンをもう一度押すと、プロファイルの原点に戻ります。',
            context=context,
        )



class SMSM_OT_max_noise_select_gizmo(Operator):
    bl_idname = 'smsm.max_noise_select_gizmo'
    bl_label = 'Select Noise Gizmo'
    bl_description = 'Selects the Empty used as the Smart Connect Noise gizmo for this Noise modifier.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')

    def execute(self, context):
        obj, mod = _noise_get_target_modifier(context, self.object_name, self.modifier_name)
        try:
            is_noise = bool(mod.get('smsm_noise_modifier', False)) if mod is not None else False
        except Exception:
            is_noise = False
        if obj is None or mod is None or not is_noise:
            self.report({'ERROR'}, choose_text('Noise modifier was not found.', 'ノイズモディファイアが見つかりません。', context=context))
            return {'CANCELLED'}
        if not _noise_select_gizmo(context, obj, mod):
            self.report({'ERROR'}, choose_text('Noise gizmo could not be created.', 'ノイズギズモを作成できませんでした。', context=context))
            return {'CANCELLED'}
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Selects the Smart_Connect_Noise_Gizmo Empty so you can move, rotate, scale, or animate the 4D noise space. The stack still resolves back to the original object.',
            'Smart_Connect_Noise_Gizmo Empty を選択し、4Dノイズ空間を移動・回転・スケール・アニメーションできるようにします。スタック表示は元オブジェクトへ解決されます。',
            context=context,
        )


class SMSM_OT_max_generic_select_gizmo(Operator):
    bl_idname = 'smsm.max_generic_select_gizmo'
    bl_label = 'Select Smart Connect Gizmo'
    bl_description = 'Selects the Empty used as the Smart Connect gizmo for this Max-compatible custom modifier.'
    bl_options = {'UNDO'}

    object_name: StringProperty(default='')
    modifier_name: StringProperty(default='')
    gizmo_property: StringProperty(default=GENERIC_GIZMO_NAME_PROP)

    def execute(self, context):
        obj, mod = _generic_get_target_modifier(context, self.object_name, self.modifier_name)
        try:
            is_generic = bool(mod.get('smsm_generic_modifier', False)) if mod is not None else False
        except Exception:
            is_generic = False
        if obj is None or mod is None or not is_generic:
            self.report({'ERROR'}, choose_text('Smart Connect modifier was not found.', 'Smart Connectモディファイアが見つかりません。', context=context))
            return {'CANCELLED'}
        allowed_prop = str(self.gizmo_property or GENERIC_GIZMO_NAME_PROP)
        if allowed_prop not in {GENERIC_GIZMO_NAME_PROP, AFFECT_REGION_START_NAME_PROP, AFFECT_REGION_END_NAME_PROP}:
            allowed_prop = GENERIC_GIZMO_NAME_PROP
        if not _generic_select_gizmo(context, obj, mod, allowed_prop):
            self.report({'ERROR'}, choose_text('Smart Connect gizmo could not be selected.', 'Smart Connectギズモを選択できませんでした。', context=context))
            return {'CANCELLED'}
        return {'FINISHED'}

    @classmethod
    def description(cls, context, properties):
        return choose_text(
            'Selects the generated Empty gizmo for this Max-compatible custom modifier. Move, rotate, scale, or animate the gizmo to control the Smart Connect stack row when supported.',
            'このMax互換独自モディファイア用に生成されたEmptyギズモを選択します。対応している場合はギズモの移動・回転・スケール・アニメーションでSmart Connectスタック行を制御します。',
            context=context,
        )

def _ensure_operator_classes():
    if _CLASSES:
        return _CLASSES
    for defn in iter_max_modifier_definitions():
        try:
            _CLASSES.append(_make_operator_class(defn))
        except Exception:
            continue
    for cls in (SMSM_OT_max_xform_set_mode, SMSM_OT_max_xform_set_subcontrol, SMSM_OT_max_melt_set_enum, SMSM_OT_max_sweep_set_pivot, SMSM_OT_max_noise_select_gizmo, SMSM_OT_max_generic_select_gizmo, *PUSH_CLASSES, *PRESERVE_CLASSES, *FACE_EXTRUDE_CLASSES, *LINKED_XFORM_CLASSES):
        if cls not in _CLASSES:
            _CLASSES.append(cls)
    return _CLASSES





def _xform_skip_copy_props(mod) -> set[str]:
    """Keep row ownership local while allowing controller socket values to sync."""
    skip = {
        'node_group',
        XFORM_OWNER_PROP,
        XFORM_STATE_PROP,
        XFORM_SHARED_STATE_PROP,
        XFORM_GROUP_OWNER_MARKER_PROP,
        XFORM_GROUP_OWNER_TOKEN_PROP,
        XFORM_NODE_GROUP_PROP,
        XFORM_SCHEMA_PROP,
        XFORM_SUBCONTROL_PROP,
        'sms_xform_migrated_from_schema',
    }
    try:
        skip.update(str(key) for key in mod.keys() if str(key).startswith(XFORM_SOCKET_PREFIX))
    except Exception:
        pass
    return skip


def _after_xform_make_unique(obj, mod, context=None):
    """Sever only the XForm controller identity after the core breaks the instance."""
    if mod is None:
        return
    state = {
        'owner_id': str(mod.get(XFORM_OWNER_PROP, '') or ''),
        'state_id': str(mod.get(XFORM_STATE_PROP, '') or ''),
        'shared_state_id': str(mod.get(XFORM_SHARED_STATE_PROP, '') or ''),
    }
    unique = make_unique_row_state(state)
    try:
        mod[XFORM_OWNER_PROP] = str(unique['owner_id'])
        mod[XFORM_STATE_PROP] = str(unique['state_id'])
        mod[XFORM_SHARED_STATE_PROP] = ''
        mod[XFORM_SCHEMA_PROP] = int(XFORM_SCHEMA_VERSION)
    except Exception:
        pass
    try:
        _configure_xform_modifier(obj, mod, getattr(mod, 'node_group', None), {'key': 'xform_modifier', 'backend': 'xform_nodes'}, context=context)
    except Exception:
        pass


def _skip_copy_props_for(defn):
    def _skip(mod):
        if str((defn or {}).get('key') or '') == 'xform_modifier':
            return _xform_skip_copy_props(mod)
        if str((defn or {}).get('backend') or '') == 'skew_nodes' or str((defn or {}).get('key') or '') == 'skew_modifier':
            extra = {SKEW_MARKER_PROP, SKEW_NODE_GROUP_PROP, SKEW_GRAPH_CONTRACT_PROP}
            try:
                extra.update(str(k) for k in mod.keys() if str(k).startswith(SKEW_SOCKET_PREFIX))
            except Exception:
                pass
            return _generic_skip_copy_props(mod) | extra
        if str((defn or {}).get('backend') or '') == 'melt_nodes' or str((defn or {}).get('key') or '') == 'melt_modifier':
            extra = {MELT_MARKER_PROP, MELT_NODE_GROUP_PROP, MELT_GRAPH_CONTRACT_PROP}
            try:
                extra.update(str(k) for k in mod.keys() if str(k).startswith(MELT_SOCKET_PREFIX))
            except Exception:
                pass
            return _generic_skip_copy_props(mod) | extra
        if str((defn or {}).get('backend') or '') == 'noise_nodes' or str((defn or {}).get('key') or '') == 'noise_modifier':
            return _noise_skip_copy_props(mod)
        if str((defn or {}).get('backend') or '') == 'push_nodes' or str((defn or {}).get('key') or '') == 'push_modifier':
            return _generic_skip_copy_props(mod) | push_skip_copy_props(mod)
        if str((defn or {}).get('backend') or '') == 'preserve_nodes' or str((defn or {}).get('key') or '') == 'preserve_modifier':
            return _generic_skip_copy_props(mod) | preserve_skip_copy_props(mod)
        if str((defn or {}).get('backend') or '') == 'face_extrude_nodes' or str((defn or {}).get('key') or '') == 'face_extrude_modifier':
            return face_extrude_skip_copy_props(mod)
        if str((defn or {}).get('backend') or '') == 'affect_region_nodes' or str((defn or {}).get('key') or '') == 'affect_region_modifier':
            return _affect_region_skip_copy_props(mod)
        if _generic_is_backend(defn):
            return _generic_skip_copy_props(mod)
        return set()
    return _skip


def _after_instance_sync_for(defn):
    def _after(src_obj, src_mod, obj, mod, context=None):
        try:
            _install_custom_parameter_props(mod, defn, context=context)
        except Exception:
            pass
        if str((defn or {}).get('key') or '') == 'xform_modifier':
            try:
                _configure_xform_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context)
            except Exception:
                pass
        if str((defn or {}).get('backend') or '') == 'skew_nodes' or str((defn or {}).get('key') or '') == 'skew_modifier':
            try:
                _configure_skew_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
        if str((defn or {}).get('backend') or '') == 'melt_nodes' or str((defn or {}).get('key') or '') == 'melt_modifier':
            try:
                _configure_melt_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
        if str((defn or {}).get('backend') or '') == 'noise_nodes' or str((defn or {}).get('key') or '') == 'noise_modifier':
            try:
                _configure_noise_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
        if str((defn or {}).get('backend') or '') == 'push_nodes' or str((defn or {}).get('key') or '') == 'push_modifier':
            try:
                after_push_instance_sync(src_obj, src_mod, obj, mod, context=context)
            except Exception:
                pass
        if str((defn or {}).get('backend') or '') == 'preserve_nodes' or str((defn or {}).get('key') or '') == 'preserve_modifier':
            after_preserve_instance_sync(src_obj, src_mod, obj, mod, context=context)
        if str((defn or {}).get('backend') or '') == 'face_extrude_nodes' or str((defn or {}).get('key') or '') == 'face_extrude_modifier':
            after_face_extrude_instance_sync(src_obj, src_mod, obj, mod, context=context)
        if str((defn or {}).get('backend') or '') == 'affect_region_nodes' or str((defn or {}).get('key') or '') == 'affect_region_modifier':
            try:
                _configure_affect_region_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
        if _generic_is_backend(defn):
            try:
                _configure_generic_modifier(obj, mod, getattr(mod, 'node_group', None), defn, context=context, force_unique_group=False)
            except Exception:
                pass
    return _after

def _register_plugin_for(defn):
    ms_register_plugin(defn.get('plugin_id'), {
        'id': defn.get('plugin_id'),
        'label': defn.get('label'),
        'label_ja': defn.get('label_ja'),
        'operator_id': defn.get('operator_id'),
        'icon': defn.get('icon') or 'MODIFIER',
        'custom_icon': _sms_icon_for_defn(defn, 'max'),
        'priority': int(defn.get('priority', 0) or 0),
        'group': max_modifier_group_for_definition(defn),
        'description_en': defn.get('description_en', ''),
        'description_ja': defn.get('description_ja', ''),
        'usage_en': defn.get('usage_en', ''),
        'usage_ja': defn.get('usage_ja', ''),
        'stack_addable': True,
        'modeling_side': False,
        'draw_add_menu': _draw_add_menu_for(defn),
        'match_modifier': _match_for(defn),
        'draw_modifier_properties_extra': _draw_props_for(defn),
        'clipboard_copy': _clipboard_copy_for(defn),
        'clipboard_paste': _clipboard_paste_for(defn),
        'cleanup_before_remove': _cleanup_before_remove_for(defn),
        'cleanup_before_apply': (_sweep_cleanup_before_apply if str(defn.get('key') or '') == 'sweep_modifier' else None),
        'before_item_action': (face_extrude_before_item_action if str(defn.get('key') or '') == 'face_extrude_modifier' else (_preserve_before_item_action if str(defn.get('key') or '') == 'preserve_modifier' else (_noise_before_item_action if (str(defn.get('backend') or '') == 'noise_nodes' or str(defn.get('key') or '') == 'noise_modifier') else (_affect_region_before_item_action if (str(defn.get('backend') or '') == 'affect_region_nodes' or str(defn.get('key') or '') == 'affect_region_modifier') else (_generic_before_item_action if (str(defn.get('backend') or '') in {'skew_nodes', 'melt_nodes', 'push_nodes'} or _generic_is_backend(defn)) else None))))),
        'after_item_action': (face_extrude_after_item_action if str(defn.get('key') or '') == 'face_extrude_modifier' else (_preserve_after_item_action if str(defn.get('key') or '') == 'preserve_modifier' else (_noise_after_item_action if (str(defn.get('backend') or '') == 'noise_nodes' or str(defn.get('key') or '') == 'noise_modifier') else (_affect_region_after_item_action if (str(defn.get('backend') or '') == 'affect_region_nodes' or str(defn.get('key') or '') == 'affect_region_modifier') else (_generic_after_item_action if (str(defn.get('backend') or '') in {'skew_nodes', 'melt_nodes', 'push_nodes'} or _generic_is_backend(defn)) else None))))),
        'sync_objects': (_noise_sync_objects if (str(defn.get('backend') or '') == 'noise_nodes' or str(defn.get('key') or '') == 'noise_modifier') else (_affect_region_sync_objects if (str(defn.get('backend') or '') == 'affect_region_nodes' or str(defn.get('key') or '') == 'affect_region_modifier') else (_generic_sync_objects if (str(defn.get('backend') or '') in {'skew_nodes', 'melt_nodes', 'push_nodes', 'preserve_nodes'} or _generic_is_backend(defn)) else None))),
        'always_sync': bool(str(defn.get('backend') or '') in {'noise_nodes', 'skew_nodes', 'melt_nodes', 'affect_region_nodes', 'push_nodes', 'preserve_nodes', 'face_extrude_nodes'} or str(defn.get('key') or '') in {'xform_modifier', 'noise_modifier', 'skew_modifier', 'melt_modifier', 'affect_region_modifier', 'push_modifier', 'preserve_modifier', 'face_extrude_modifier'} or _generic_is_backend(defn)),
        'get_skip_copy_props': _skip_copy_props_for(defn),
        'after_instance_sync': _after_instance_sync_for(defn),
        'after_make_unique': (_after_xform_make_unique if str(defn.get('key') or '') == 'xform_modifier' else (after_push_make_unique if str(defn.get('key') or '') == 'push_modifier' else (after_preserve_make_unique if str(defn.get('key') or '') == 'preserve_modifier' else (after_face_extrude_make_unique if str(defn.get('key') or '') == 'face_extrude_modifier' else None)))),
    })


def _rehydrate_noise_modifier_metadata() -> int:
    """Restore non-interface NODES metadata from the durable owned group."""
    defn = next((item for item in iter_max_modifier_definitions() if str(item.get('key') or '') == 'noise_modifier'), None)
    if defn is None:
        return 0
    repaired = 0
    for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
        changed = False
        for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
            try:
                group = getattr(mod, 'node_group', None)
                if group is None or str(group.get(NOISE_GRAPH_CONTRACT_PROP, '') or '') != 'dedicated_noise_graph_v2':
                    continue
                _stamp_modifier(mod, defn)
                _configure_noise_modifier(obj, mod, group, defn, context=bpy.context, force_unique_group=False)
                if not bool(mod.get('smsm_noise_modifier', False)):
                    continue
                changed = True
                repaired += 1
            except Exception:
                continue
        if changed:
            try:
                obj.update_tag()
            except Exception:
                pass
    return repaired


def _rehydrate_noise_once_for_load() -> int:
    """Run the Noise restoration once per file load.

    Both this library's load_post callback and the stack's load_post restoration
    ask for it, in either order.  Blender replaces driver_namespace on every file
    load, so a mark stored there lasts exactly until the next load.
    """
    namespace = bpy.app.driver_namespace
    if namespace.get(_NOISE_LOAD_DONE_KEY):
        return 0
    namespace[_NOISE_LOAD_DONE_KEY] = True
    return _rehydrate_noise_modifier_metadata()


@bpy.app.handlers.persistent
def _rehydrate_noise_load_post(_dummy=None):
    _rehydrate_noise_once_for_load()


@bpy.app.handlers.persistent
def _rehydrate_noise_undo_redo_post(_dummy=None):
    _rehydrate_noise_modifier_metadata()


def _rehydrate_skew_modifier_metadata() -> int:
    defns = {str(item.get('key') or ''): item for item in iter_max_modifier_definitions() if str(item.get('backend') or '') == 'skew_nodes'}
    if not defns:
        return 0
    repaired = 0
    for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
        changed = False
        for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
            try:
                group = getattr(mod, 'node_group', None)
                deform_key = gizmo_deform_key_for_group(group)
                defn = defns.get(deform_key) if deform_key else None
                if defn is None:
                    continue
                _stamp_modifier(mod, defn)
                mod[SKEW_MARKER_PROP] = True
                mod['smsm_generic_modifier'] = True
                mod[BACKEND_PROP] = 'skew_nodes'
                mod[SKEW_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
                mod[GENERIC_NODE_GROUP_PROP] = str(getattr(group, 'name', '') or '')
                mod[GENERIC_KIND_PROP] = 'deform'
                mod[GENERIC_COLLECTION_PROP] = _generic_collection_name(defn)
                for entry in gizmo_deform_socket_table(deform_key, group):
                    key = entry['key']
                    socket = _skew_socket(group, key, entry['name'])
                    sid = str(getattr(socket, 'identifier', '') or getattr(socket, 'name', '') or '')
                    if not sid:
                        continue
                    mod[SKEW_SOCKET_PREFIX + key] = sid
                    if key == 'gizmo':
                        mod[GENERIC_GIZMO_SOCKET_PROP] = sid
                        gizmo = mod.get(sid)
                        if gizmo is not None:
                            mod[GENERIC_GIZMO_NAME_PROP] = str(getattr(gizmo, 'name', '') or '')
                changed = True
                repaired += 1
            except Exception:
                continue
        if changed:
            try:
                obj.update_tag(refresh={'DATA'})
            except Exception:
                pass
    return repaired


@bpy.app.handlers.persistent
def _rehydrate_skew_undo_redo_post(_dummy=None):
    _rehydrate_skew_modifier_metadata()


def _rehydrate_push_modifier_metadata() -> int:
    """Restore NODES-modifier metadata only from a fully verified Push graph."""
    defn = next((item for item in iter_max_modifier_definitions() if str(item.get('key') or '') == 'push_modifier'), None)
    if defn is None:
        return 0
    repaired = 0
    for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
        changed = False
        for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
            try:
                group = getattr(mod, 'node_group', None)
                if not _is_verified_push_group(group):
                    continue
                _stamp_modifier(mod, defn)
                configure_push_modifier(obj, mod, group, defn, context=bpy.context, force_unique_group=False)
                if not bool(mod.get(PUSH_MARKER_PROP, False)):
                    continue
                changed = True
                repaired += 1
            except Exception:
                continue
        if changed:
            try:
                obj.update_tag(refresh={'DATA'})
            except Exception:
                pass
    return repaired


@bpy.app.handlers.persistent
def _rehydrate_push_load_undo_redo_post(_dummy=None):
    _rehydrate_push_modifier_metadata()


def _rehydrate_preserve_modifier_metadata() -> int:
    defn = next((item for item in iter_max_modifier_definitions() if str(item.get('key') or '') == 'preserve_modifier'), None)
    if defn is None:
        return 0
    repaired = 0
    for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
        for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
            try:
                if upgrade_legacy_preserve_modifier(obj, mod, context=bpy.context):
                    _stamp_modifier(mod, defn)
                    repaired += 1
                    continue
                if not is_verified_preserve_group(getattr(mod, 'node_group', None)):
                    continue
                _stamp_modifier(mod, defn)
                configure_preserve_modifier(obj, mod, mod.node_group, defn, context=bpy.context, force_unique_group=False)
                repaired += 1
            except Exception:
                continue
    return repaired


@bpy.app.handlers.persistent
def _rehydrate_preserve_load_undo_redo_post(_dummy=None):
    _rehydrate_preserve_modifier_metadata()


# Sweep groups written by precision_tools: schema 1 (older files), schema 2, and schema 3
# (the 3ds Max Sweep Parameters rollout).
_SWEEP_GROUP_SCHEMAS = (1, 2, 3)
_SWEEP_REQUIRED_INPUTS = ('Profile Curve', 'Sweep Resolution', 'Sweep Fill Caps')


def _sweep_group_inputs(group):
    """Return {input name: identifier} of an add-on Sweep group, or None."""
    if group is None or getattr(group, 'bl_idname', '') != 'GeometryNodeTree':
        return None
    try:
        if int(group.get('sms_sweep_schema', 0) or 0) not in _SWEEP_GROUP_SCHEMAS:
            return None
        if not bool(group.get('sms_owned_node_group', False)):
            return None
        inputs = {}
        for item in group.interface.items_tree:
            if getattr(item, 'item_type', '') == 'SOCKET' and getattr(item, 'in_out', '') == 'INPUT':
                inputs[str(item.name)] = str(item.identifier)
    except Exception:
        return None
    if any(name not in inputs for name in _SWEEP_REQUIRED_INPUTS):
        return None
    return inputs


def _rehydrate_sweep_modifier_metadata() -> int:
    """Restore Sweep row markers that a file load or undo drops from a Geometry Nodes modifier.

    Without them the row is no longer a curve-source row: selecting it moves the curve's
    stack onto a mesh proxy, deleting it leaves the group behind and Apply has no
    Curve-to-Mesh path.  Socket values are never touched.
    """
    defn = next((d for d in iter_max_modifier_definitions() if d.get('key') == 'sweep_modifier'), None)
    if defn is None:
        return 0
    repaired = 0
    for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
        if getattr(obj, 'type', '') != 'CURVE':
            continue
        for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
            try:
                if mod.type != 'NODES':
                    continue
                inputs = _sweep_group_inputs(mod.node_group)
                if inputs is None:
                    continue
                if (
                    str(mod.get(KEY_PROP, '') or '') == 'sweep_modifier'
                    and bool(mod.get('sms_sweep_modifier', False))
                    and bool(mod.get('sms_curve_source_modifier', False))
                ):
                    continue
                _stamp_modifier(mod, defn)
                mod['sms_sweep_modifier'] = True
                mod['sms_curve_source_modifier'] = True
                profile = mod.get(inputs['Profile Curve'])
                if profile is not None and hasattr(profile, 'name'):
                    mod['sms_sweep_profile_name'] = str(profile.name)
                repaired += 1
            except Exception:
                continue
    return repaired


@bpy.app.handlers.persistent
def _rehydrate_sweep_load_undo_redo_post(_dummy=None):
    _rehydrate_sweep_modifier_metadata()


def _saved_xform_sockets(group):
    """Operational recognition only: public markers never grant deletion ownership."""
    if group is None or getattr(group, 'bl_idname', '') != 'GeometryNodeTree':
        return None
    try:
        if group.get(XFORM_GROUP_OWNER_MARKER_PROP) != XFORM_GROUP_OWNER_MARKER_VALUE:
            return None
        if group.get(XFORM_SCHEMA_PROP) != XFORM_SCHEMA_VERSION:
            return None
        if group.get('sms_xform_graph_contract') != 'matrix_covector_preserve_normals_v3':
            return None
        expected = {
            'translation': 'Translation', 'rotation': 'Rotation', 'scale': 'Scale',
            'center': 'Gizmo Center', 'use_named_selection': 'Use Named Selection',
            'selection_name': 'Selection Name', 'coordinate_mode': 'Coordinate Mode',
            'reference_object': 'Reference Object', 'world_pivot_center': 'World Pivot Center',
            'preserve_normals': 'Preserve Normals',
        }
        sockets = {}
        for key, name in expected.items():
            socket = _xform_socket(group, key, name)
            sid = str(getattr(socket, 'identifier', '') or '')
            if not sid or getattr(socket, 'name', '') != name or group.get(XFORM_SOCKET_PREFIX + key) != sid:
                return None
            sockets[key] = sid
        if len(set(sockets.values())) != 10:
            return None
        required = {'GeometryNodeCaptureAttribute', 'GeometryNodeSetPosition',
                    'GeometryNodeSetMeshNormal', 'FunctionNodeTransformPoint',
                    'FunctionNodeInvertMatrix', 'FunctionNodeTransposeMatrix'}
        if not required.issubset({n.bl_idname for n in group.nodes}):
            return None
        if len(group.links) < 10:
            return None
        normals = [n for n in group.nodes if n.bl_idname == 'GeometryNodeSetMeshNormal']
        positions = [n for n in group.nodes if n.bl_idname == 'GeometryNodeSetPosition']
        if len(normals) != 1 or len(positions) != 1:
            return None
        if normals[0].mode != 'FREE' or normals[0].domain != 'CORNER':
            return None
        if not normals[0].inputs['Custom Normal'].is_linked or not positions[0].inputs['Position'].is_linked:
            return None
        return sockets
    except (AttributeError, KeyError, TypeError, ReferenceError):
        return None


def _rehydrate_xform_modifier_metadata() -> int:
    """Restore UI bindings without resetting socket values or adopting group ownership."""
    defn = next((d for d in iter_max_modifier_definitions() if d.get('key') == 'xform_modifier'), None)
    if defn is None:
        return 0
    repaired = 0
    for obj in tuple(bpy.data.objects):
        for mod in tuple(obj.modifiers):
            if mod.type != 'NODES':
                continue
            group = mod.node_group
            sockets = _saved_xform_sockets(group)
            if sockets is None:
                continue
            # Missing real inputs are an invalid saved state, not permission to insert defaults.
            if any(sid not in mod for key, sid in sockets.items() if key != 'reference_object'):
                continue
            mode = mod[sockets['coordinate_mode']]
            if mode not in (0, 1, 2, 3):
                continue
            _stamp_modifier(mod, defn)
            _ensure_xform_row_state(mod)
            for key, sid in sockets.items():
                mod[XFORM_SOCKET_PREFIX + key] = sid
            mod[XFORM_MODE_PROP] = ('GIZMO', 'LOCAL', 'WORLD', 'REFERENCE_OBJECT')[int(mode)]
            mod[XFORM_NODE_GROUP_PROP] = group.name
            mod['sms_xform_modifier'] = True
            # No configure call: its multi-user copy/migration path is inappropriate on reload.
            # No mint/bind: ownership is only what the creation path recorded (the object's
            # row binding and the group's own identity); a group without that proof must
            # remain deletion-unowned.
            repaired += 1
    return repaired


@bpy.app.handlers.persistent
def _rehydrate_xform_load_post(_dummy=None):
    _rehydrate_xform_modifier_metadata()


def _library_modifiers_present() -> bool:
    """True when the open file already holds a modifier made by this library."""
    try:
        for obj in tuple(getattr(bpy.data, 'objects', ()) or ()):
            for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
                if mod.get(MARKER_KEY) or mod.get(KEY_PROP):
                    return True
                group = getattr(mod, 'node_group', None)
                if group is not None and any(str(key).startswith('smsm') for key in group.keys()):
                    return True
    except Exception:
        return False
    return False


def _ensure_undo_redo_rehydrate():
    """Add the Undo / Redo rehydration callbacks (only once the library is in use)."""
    for _fn in _UNDO_REHYDRATE_FUNCS:
        event_hub.add('undo_post', _fn)
        event_hub.add('redo_post', _fn)


@bpy.app.handlers.persistent
def _rehydrate_arm_undo_redo_after_load(_dummy=None):
    if not event_hub.has('undo_post', _rehydrate_xform_load_post) and _library_modifiers_present():
        _ensure_undo_redo_rehydrate()


_LOAD_REHYDRATE_FUNCS = (
    _rehydrate_push_load_undo_redo_post, _rehydrate_preserve_load_undo_redo_post,
    _rehydrate_sweep_load_undo_redo_post, _rehydrate_xform_load_post,
    _rehydrate_noise_load_post, _rehydrate_arm_undo_redo_after_load,
)
_UNDO_REHYDRATE_FUNCS = (
    _rehydrate_skew_undo_redo_post, _rehydrate_noise_undo_redo_post,
    _rehydrate_push_load_undo_redo_post, _rehydrate_preserve_load_undo_redo_post,
    _rehydrate_sweep_load_undo_redo_post, _rehydrate_xform_load_post,
)


def _rehydrate_all_metadata():
    _rehydrate_xform_modifier_metadata()
    _rehydrate_noise_modifier_metadata()
    _rehydrate_push_modifier_metadata()
    _rehydrate_preserve_modifier_metadata()
    _rehydrate_sweep_modifier_metadata()


def _rehydrate_after_restricted_register():
    # The mark means a load_post already restored the file after registration.
    if not bpy.app.driver_namespace.get(_NOISE_LOAD_DONE_KEY):
        try:
            _rehydrate_all_metadata()
        except Exception:
            pass
    return None


def register_embedded():
    global _REGISTERED
    for cls in _ensure_operator_classes():
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass
        except Exception:
            pass
    for defn in iter_max_modifier_definitions():
        try:
            _register_plugin_for(defn)
        except Exception:
            pass
    # One suite-wide load_post dispatcher runs these (see event_hub).  Undo / Redo
    # rehydration is added only once the library is in use (_ensure_undo_redo_rehydrate).
    for _fn in (_rehydrate_push_load_undo_redo_post, _rehydrate_preserve_load_undo_redo_post,
                _rehydrate_sweep_load_undo_redo_post, _rehydrate_xform_load_post,
                _rehydrate_noise_load_post, _rehydrate_arm_undo_redo_after_load):
        event_hub.add('load_post', _fn)
    # bpy.data is restricted while Blender enables an add-on.  A file opened at
    # startup is restored by the load_post callbacks; enabling it in a running
    # session has no load event, so a one-shot timer restores the open file.
    bpy.app.driver_namespace.pop(_NOISE_LOAD_DONE_KEY, None)
    if isinstance(bpy.data, bpy.types.BlendData):
        _rehydrate_all_metadata()
        _rehydrate_arm_undo_redo_after_load()
    elif not bpy.app.timers.is_registered(_rehydrate_after_restricted_register):
        bpy.app.timers.register(_rehydrate_after_restricted_register, first_interval=0.0)
    _REGISTERED = True


def unregister_embedded():
    global _REGISTERED
    if bpy.app.timers.is_registered(_rehydrate_after_restricted_register):
        bpy.app.timers.unregister(_rehydrate_after_restricted_register)
    forget_session_ownership()
    for defn in reversed(tuple(iter_max_modifier_definitions())):
        try:
            ms_unregister_plugin(defn.get('plugin_id'))
        except Exception:
            pass
    for _fn in _LOAD_REHYDRATE_FUNCS:
        event_hub.remove('load_post', _fn)
    for _fn in _UNDO_REHYDRATE_FUNCS:
        event_hub.remove('undo_post', _fn)
        event_hub.remove('redo_post', _fn)
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED = False


def register():
    register_embedded()


def unregister():
    unregister_embedded()
