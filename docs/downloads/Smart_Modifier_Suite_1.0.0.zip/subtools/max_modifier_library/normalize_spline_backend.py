"""Non-destructive per-spline arc-length normalization; POLY output."""
import bpy
from ..uv_stack_common import unique_name

CONTRACT = 'sms_normalize_spline_arc_v1'
OWNER_PROP = 'sms_normalize_owner'
OWNER_VALUE = 'smart_modifier_suite.normalize_spline.v1'
SCHEMA_PROP = 'sms_normalize_schema'
SCHEMA_VERSION = 1


def is_verified_normalize_group(group, *, require_owner=False):
    try:
        if group is None or group.bl_idname != 'GeometryNodeTree':
            return False
        if group.get('sms_normalize_contract') != CONTRACT:
            return False
        if require_owner and (
            group.get(OWNER_PROP) != OWNER_VALUE
            or int(group.get(SCHEMA_PROP, 0) or 0) != SCHEMA_VERSION
            or not str(group.name).startswith('SMS Normalize Spline')
        ):
            return False
        socket_ids = [str(group.get('sms_normalize_' + key, '') or '') for key in ('by_count', 'length', 'count', 'maximum')]
        if not all(socket_ids) or len(set(socket_ids)) != 4:
            return False
        resample = [node for node in group.nodes if node.bl_idname == 'GeometryNodeResampleCurve']
        return (
            len(resample) == 1
            and resample[0].inputs['Mode'].default_value == 'Count'
            and resample[0].inputs['Curve'].is_linked
            and resample[0].inputs['Count'].is_linked
            and len(group.links) >= 20
        )
    except (AttributeError, KeyError, TypeError, ReferenceError):
        return False


def make_normalize_group(obj, defn=None, context=None):
    if obj is None or obj.type != 'CURVE':
        raise ValueError('Curve object required / カーブが必要です')
    data = obj.data
    if data.bevel_depth or data.extrude or data.bevel_object is not None:
        raise ValueError('Normalize before bevel/extrusion / ベベル・押出しより前に適用してください')
    if not data.splines or any(s.type not in {'POLY', 'BEZIER'} for s in data.splines):
        raise ValueError('POLY/BEZIER splines only; NURBS unsupported / POLY・BEZIERのみ対応')
    if any((len(s.bezier_points) if s.type == 'BEZIER' else len(s.points)) < (3 if s.use_cyclic_u else 2) for s in data.splines):
        raise ValueError('Spline has insufficient knots / スプラインのノット数が不足しています')
    group = bpy.data.node_groups.new(unique_name('SMS Normalize Spline', bpy.data.node_groups), 'GeometryNodeTree')
    try:
        group.is_modifier = True
        group.interface.new_socket(name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
        group.interface.new_socket(name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
        for key, name, kind, value, lower, upper in [
            ('by_count', 'Use Knot Count', 'NodeSocketBool', False, None, None),
            ('length', 'Segment Length', 'NodeSocketFloat', 20.0, 0.000001, 1000000.0),
            ('count', 'Knot Count', 'NodeSocketInt', 20, 2, 4096),
            ('maximum', 'Max Knots', 'NodeSocketInt', 1000, 3, 4096),
        ]:
            socket = group.interface.new_socket(name=name, in_out='INPUT', socket_type=kind)
            socket.default_value = value
            if lower is not None:
                socket.min_value = lower
                socket.max_value = upper
            group['sms_normalize_' + key] = socket.identifier

        def node(kind):
            return group.nodes.new(kind)

        def link(source, target):
            group.links.new(source, target)

        def math_node(operation, first, second=None):
            math = node('ShaderNodeMath')
            math.operation = operation
            if isinstance(first, (int, float)):
                math.inputs[0].default_value = first
            else:
                link(first, math.inputs[0])
            if second is not None:
                if isinstance(second, (int, float)):
                    math.inputs[1].default_value = second
                else:
                    link(second, math.inputs[1])
            return math.outputs[0]

        group_input = node('NodeGroupInput')
        group_output = node('NodeGroupOutput')
        group_output.is_active_output = True
        spline_length = node('GeometryNodeSplineLength')
        cyclic = node('GeometryNodeInputSplineCyclic')
        ends = node('GeometryNodeSwitch')
        ends.input_type = 'INT'
        ends.inputs['False'].default_value = 1
        ends.inputs['True'].default_value = 0
        link(cyclic.outputs[0], ends.inputs['Switch'])
        minimum = node('GeometryNodeSwitch')
        minimum.input_type = 'INT'
        minimum.inputs['False'].default_value = 2
        minimum.inputs['True'].default_value = 3
        link(cyclic.outputs[0], minimum.inputs['Switch'])
        safe_length = math_node('MAXIMUM', group_input.outputs['Segment Length'], 0.000001)
        intervals = math_node('CEIL', math_node('DIVIDE', spline_length.outputs['Length'], safe_length))
        length_count = math_node('ADD', intervals, ends.outputs[0])
        mode = node('GeometryNodeSwitch')
        mode.input_type = 'INT'
        link(group_input.outputs['Use Knot Count'], mode.inputs['Switch'])
        link(length_count, mode.inputs['False'])
        link(group_input.outputs['Knot Count'], mode.inputs['True'])
        cap = math_node('MINIMUM', math_node('MAXIMUM', group_input.outputs['Max Knots'], 3), 4096)
        count = math_node('MINIMUM', math_node('MAXIMUM', mode.outputs[0], minimum.outputs[0]), cap)
        resample = node('GeometryNodeResampleCurve')
        resample.inputs['Mode'].default_value = 'Count'
        link(group_input.outputs['Geometry'], resample.inputs['Curve'])
        link(count, resample.inputs['Count'])
        link(resample.outputs['Curve'], group_output.inputs['Geometry'])
        group['sms_normalize_contract'] = CONTRACT
        group[OWNER_PROP] = OWNER_VALUE
        group[SCHEMA_PROP] = SCHEMA_VERSION
        return group
    except Exception:
        bpy.data.node_groups.remove(group)
        raise


def draw_normalize(layout, mod):
    group = getattr(mod, 'node_group', None)
    if not is_verified_normalize_group(group):
        layout.label(text='Legacy row: re-add required / 旧形式は再追加が必要', icon='ERROR')
        return
    for key, english, japanese in [
        ('by_count', 'Use Knot Count', 'ノット数を指定'),
        ('length', 'Segment Length', '区間長'),
        ('count', 'Knot Count / Spline', '各スプラインのノット数'),
        ('maximum', 'Max Knots / Spline', '各スプラインの最大ノット数'),
    ]:
        layout.prop(mod, '["' + group['sms_normalize_' + key] + '"]', text=english + ' / ' + japanese)
    layout.label(text='All splines; open ends and cyclic closure retained / 全スプライン・端点と閉鎖を保持')
    layout.label(text='POLY output; Bezier uses evaluated resolution / 出力POLY・Bezierは評価解像度依存')
    layout.label(text='No Insert/Retain Knots/Tangents / 挿入・旧ノット・接線保持は非対応')


def cleanup_normalize(mod):
    group = getattr(mod, 'node_group', None)
    try:
        trusted_modifier = str(mod.get('smsm_max_modifier_key', '') or '') == 'normalize_spline_modifier'
        local_group = group is not None and getattr(group, 'library', None) is None
        disposable = int(getattr(group, 'users', 0) or 0) <= 1 and not bool(getattr(group, 'use_fake_user', False))
        if trusted_modifier and local_group and disposable and is_verified_normalize_group(group, require_owner=True):
            bpy.data.node_groups.remove(group)
            return True
    except (AttributeError, KeyError, TypeError, ReferenceError):
        pass
    return False
