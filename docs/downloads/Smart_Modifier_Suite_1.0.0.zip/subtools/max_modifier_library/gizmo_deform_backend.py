# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Gizmo-space deformers that follow the 3ds Max Skew, Taper and Stretch modifiers.

All three share one Geometry Nodes layout: points are moved into the gizmo
space (the gizmo location is the center and its rotation gives the axes), the
primary axis and the two secondary axes are picked with an index switch, the
3ds Max formula is applied, and the result is moved back and blended with
Influence.

  Skew    : secondary += Amount * h / L * (cos Direction, sin Direction)
            L is the extent along the primary axis, or Upper - Lower with limits.
  Taper   : secondary *= 1 + Amount * u + Curve * u * (1 - u),  u = h / L
            Symmetry mirrors h below the center, Effect picks the axes.
  Stretch : primary   = hc * f(Stretch) + (h - hc)
            secondary *= 1 + (1 / f(Stretch * f(Amplify)) - 1) * (1 - t^2)
            f(s) = s + 1 for s >= 0, -1 / (s - 1) for s < 0.

Skew groups built before this module (contract v1, amount in degrees) are
kept as they are; new Skew rows use the distance-based v2 graph.
"""

from __future__ import annotations

import bpy

from ...translation import choose_text


CONTRACT_PROP = "smsm_skew_graph_contract"
SOCKET_PREFIX = "smsm_skew_socket_"

SKEW_V1_CONTRACT = "dedicated_gizmo_space_skew_v1"
SKEW_CONTRACT = "dedicated_gizmo_space_skew_v2"
TAPER_CONTRACT = "dedicated_gizmo_space_taper_v1"
STRETCH_CONTRACT = "dedicated_gizmo_space_stretch_v1"

KEY_CONTRACTS = {
    "skew_modifier": SKEW_CONTRACT,
    "taper_modifier": TAPER_CONTRACT,
    "stretch_modifier": STRETCH_CONTRACT,
}
CONTRACT_KEYS = {
    SKEW_V1_CONTRACT: "skew_modifier",
    SKEW_CONTRACT: "skew_modifier",
    TAPER_CONTRACT: "taper_modifier",
    STRETCH_CONTRACT: "stretch_modifier",
}

_EPS = 1.0e-6


def _entry(key, name, kind, default, label_en, label_ja, desc_en, desc_ja, minimum=None, maximum=None):
    return {
        "key": key,
        "name": name,
        "kind": kind,
        "default": default,
        "label_en": label_en,
        "label_ja": label_ja,
        "desc_en": desc_en,
        "desc_ja": desc_ja,
        "min": minimum,
        "max": maximum,
    }


_GIZMO = _entry(
    "gizmo", "Gizmo", "OBJECT", None, "Gizmo", "ギズモ",
    "Helper empty of this modifier. Its location is the center and its rotation gives the primary and secondary axes.",
    "このモディファイアの補助エンプティです。位置が中心、回転が主軸と副軸の向きになります。",
)
_AXIS = _entry(
    "axis", "Primary Axis", "INT", 2, "Primary Axis (0=X, 1=Y, 2=Z)", "主軸 (0=X, 1=Y, 2=Z)",
    "Gizmo axis along which the effect is measured: 0 = X, 1 = Y, 2 = Z.",
    "効果を測るギズモの軸です。0 = X、1 = Y、2 = Z。",
    0, 2,
)
_USE_LIMITS = _entry(
    "use_limits", "Use Limits", "BOOL", False, "Limit Effect", "効果を制限",
    "Apply the effect only between Lower Limit and Upper Limit. Points outside keep the value at the limit.",
    "下限と上限の間だけに効果をかけます。外側の点は限界の値のまま動きます。",
)
_LOWER = _entry(
    "lower_limit", "Lower Limit", "FLOAT", -1.0, "Lower Limit", "下限",
    "Lower limit along the primary axis, in gizmo-space units from the center.",
    "主軸に沿った下限です（中心からのギズモ空間の距離）。",
)
_UPPER = _entry(
    "upper_limit", "Upper Limit", "FLOAT", 1.0, "Upper Limit", "上限",
    "Upper limit along the primary axis, in gizmo-space units from the center.",
    "主軸に沿った上限です（中心からのギズモ空間の距離）。",
)
_INFLUENCE = _entry(
    "influence", "Influence", "FLOAT", 1.0, "Influence", "影響度",
    "Blend between the incoming shape (0) and the full effect (1).",
    "入力の形（0）と効果を全部かけた形（1）の間で混ぜます。",
    0.0, 1.0,
)

SOCKET_TABLES = {
    "skew_modifier": (
        _GIZMO,
        _entry(
            "amount", "Amount", "FLOAT", 0.0, "Amount (distance)", "量（距離）",
            "Skew distance across the whole extent along the primary axis, in scene units, as in the 3ds Max Skew modifier.",
            "主軸に沿った全長でずらす距離（シーン単位）です。3ds Max の Skew の Amount と同じです。",
        ),
        _entry(
            "direction", "Direction", "FLOAT", 0.0, "Direction (degrees)", "方向（度）",
            "Direction of the skew around the primary axis, in degrees.",
            "主軸のまわりのずらす向き（度）です。",
        ),
        _AXIS, _USE_LIMITS, _LOWER, _UPPER, _INFLUENCE,
    ),
    "taper_modifier": (
        _GIZMO,
        _entry(
            "amount", "Amount", "FLOAT", 0.0, "Amount", "量",
            "Scale change at one full extent from the center along the primary axis, as in the 3ds Max Taper modifier. Positive widens the upper side.",
            "主軸に沿って中心から全長ぶん離れた所での拡大の変化です（3ds Max の Taper の Amount と同じ）。正の値で上側が広がります。",
        ),
        _entry(
            "curve", "Curve", "FLOAT", 0.0, "Curve", "カーブ",
            "Bends the tapered sides: positive bulges outward, negative curves inward, 0 keeps them straight.",
            "テーパーの側面を曲げます。正は外へふくらみ、負は内へへこみ、0 はまっすぐです。",
        ),
        _AXIS,
        _entry(
            "effect", "Effect", "INT", 2, "Effect (0=first, 1=second, 2=both)", "効果の軸 (0=第1副軸, 1=第2副軸, 2=両方)",
            "Secondary axes that are scaled. For primary Z: 0 = X, 1 = Y, 2 = XY. For primary X: 0 = Y, 1 = Z, 2 = YZ. For primary Y: 0 = X, 1 = Z, 2 = XZ.",
            "拡大する副軸です。主軸 Z では 0 = X、1 = Y、2 = XY。主軸 X では 0 = Y、1 = Z、2 = YZ。主軸 Y では 0 = X、1 = Z、2 = XZ。",
            0, 2,
        ),
        _entry(
            "symmetry", "Symmetry", "BOOL", False, "Symmetry", "対称",
            "Mirror the taper around the center so both ends change the same way.",
            "中心をはさんで両端が同じように変わるよう、テーパーを対称にします。",
        ),
        _USE_LIMITS, _LOWER, _UPPER, _INFLUENCE,
    ),
    "stretch_modifier": (
        _GIZMO,
        _entry(
            "stretch", "Stretch", "FLOAT", 0.0, "Stretch", "ストレッチ",
            "Scale along the primary axis: Stretch + 1 for positive values and -1 / (Stretch - 1) for negative values. The secondary axes get the inverse scale, strongest at the center.",
            "主軸方向の拡大です。正の値は Stretch + 1、負の値は -1 / (Stretch - 1) 倍になります。副軸には逆の拡大が中心ほど強くかかります。",
        ),
        _entry(
            "amplify", "Amplify", "FLOAT", 0.0, "Amplify", "増幅",
            "Changes the secondary-axis scale. 0 uses the plain inverse, positive values exaggerate it and negative values reduce it.",
            "副軸の拡大を変えます。0 はそのままの逆数、正の値で強め、負の値で弱めます。",
        ),
        _AXIS, _USE_LIMITS, _LOWER, _UPPER, _INFLUENCE,
    ),
}

# Skew groups made by the earlier v1 graph keep their degree-based amount.
SKEW_V1_TABLE = (
    _GIZMO,
    _entry(
        "amount", "Amount", "FLOAT", 0.0, "Amount (degrees)", "量（度）",
        "Skew angle in degrees (graph made by an earlier version).",
        "スキューの角度（度）です（前の版で作ったグラフ）。",
    ),
    SOCKET_TABLES["skew_modifier"][2],
    _AXIS, _USE_LIMITS, _LOWER, _UPPER, _INFLUENCE,
)

TITLES = {
    "skew_modifier": ("Skew Controls", "スキュー設定"),
    "taper_modifier": ("Taper Controls", "テーパー設定"),
    "stretch_modifier": ("Stretch Controls", "ストレッチ設定"),
}

_SOCKET_TYPES = {
    "OBJECT": "NodeSocketObject",
    "FLOAT": "NodeSocketFloat",
    "INT": "NodeSocketInt",
    "BOOL": "NodeSocketBool",
}


def gizmo_deform_key(defn) -> str:
    key = str((defn or {}).get("key") or "")
    return key if key in KEY_CONTRACTS else "skew_modifier"


def group_contract(group) -> str:
    if group is None:
        return ""
    try:
        return str(group.get(CONTRACT_PROP, "") or "")
    except Exception:
        return ""


def key_for_group(group) -> str:
    return CONTRACT_KEYS.get(group_contract(group), "")


def socket_table(key, group=None):
    if group_contract(group) == SKEW_V1_CONTRACT:
        return SKEW_V1_TABLE
    return SOCKET_TABLES.get(str(key or ""), SOCKET_TABLES["skew_modifier"])


def effect_axes_text(axis, effect) -> str:
    try:
        names = {0: ("Y", "Z"), 1: ("X", "Z"), 2: ("X", "Y")}[int(axis)]
        effect = int(effect)
    except Exception:
        return ""
    if effect == 0:
        return names[0]
    if effect == 1:
        return names[1]
    if effect == 2:
        return names[0] + names[1]
    return ""


# ---------------------------------------------------------------- graph helpers
def _sock(sockets, name, index=0):
    found = [s for s in sockets if str(getattr(s, "name", "")) == name and bool(getattr(s, "enabled", True))]
    if not found:
        raise RuntimeError(f"Gizmo deform graph socket was not found: {name}")
    return found[index]


def _node(nodes, idname, label="", **props):
    node = nodes.new(idname)
    if label:
        node.label = label
    for key, value in props.items():
        setattr(node, key, value)
    return node


def _feed(group, socket, value):
    if isinstance(value, bool):
        socket.default_value = value
    elif isinstance(value, (int, float)):
        socket.default_value = float(value) if socket.type == "VALUE" else value
    elif isinstance(value, (tuple, list)):
        socket.default_value = value
    else:
        group.links.new(value, socket)


def _fmath(group, operation, a=None, b=None, *, label=""):
    node = _node(group.nodes, "ShaderNodeMath", label, operation=operation)
    for index, value in ((0, a), (1, b)):
        if value is not None:
            _feed(group, node.inputs[index], value)
    return node.outputs[0]


def _add(group, a, b):
    return _fmath(group, "ADD", a, b)


def _sub(group, a, b):
    return _fmath(group, "SUBTRACT", a, b)


def _mul(group, a, b):
    return _fmath(group, "MULTIPLY", a, b)


def _div(group, a, b):
    return _fmath(group, "DIVIDE", a, b)


def _mix(group, a, b, t):
    """a + (b - a) * t with t in 0..1 (t may be a bool socket)."""
    return _add(group, a, _mul(group, _sub(group, b, a), t))


def _index_switch(group, data_type, index, values, *, label=""):
    node = _node(group.nodes, "GeometryNodeIndexSwitch", label, data_type=data_type)
    while len(node.index_switch_items) < len(values):
        node.index_switch_items.new()
    group.links.new(index, node.inputs[0])
    for i, value in enumerate(values):
        _feed(group, node.inputs[1 + i], value)
    return node.outputs[0]


def _transform(group, point, matrix, *, label=""):
    node = _node(group.nodes, "FunctionNodeTransformPoint", label)
    group.links.new(point, _sock(node.inputs, "Vector"))
    group.links.new(matrix, _sock(node.inputs, "Transform"))
    return _sock(node.outputs, "Vector")


def _invert(group, matrix, *, label=""):
    node = _node(group.nodes, "FunctionNodeInvertMatrix", label)
    group.links.new(matrix, _sock(node.inputs, "Matrix"))
    return _sock(node.outputs, "Matrix")


def _combine(group, x, y, z):
    node = _node(group.nodes, "ShaderNodeCombineXYZ")
    for index, value in enumerate((x, y, z)):
        _feed(group, node.inputs[index], value)
    return node.outputs[0]


def _factor(group, s):
    """3ds Max Stretch scale factor: s + 1 for s >= 0, -1 / (s - 1) for s < 0."""
    positive = _add(group, s, 1.0)
    negative = _div(group, 1.0, _sub(group, 1.0, s))
    is_negative = _fmath(group, "LESS_THAN", s, 0.0)
    return _mix(group, positive, negative, is_negative)


def _add_socket(group, entry, context=None):
    item = group.interface.new_socket(name=entry["name"], in_out="INPUT", socket_type=_SOCKET_TYPES[entry["kind"]])
    if entry["default"] is not None:
        try:
            item.default_value = entry["default"]
        except Exception:
            pass
    for attr, value in (("min_value", entry["min"]), ("max_value", entry["max"])):
        if value is None:
            continue
        try:
            setattr(item, attr, value)
        except Exception:
            pass
    item.description = choose_text(entry["desc_en"], entry["desc_ja"], context=context)
    return item


# ---------------------------------------------------------------- graph
def build_gizmo_deform_group(group, key, context=None) -> dict:
    """Fill an empty GeometryNodeTree with the gizmo-space deformer for key."""
    key = key if key in KEY_CONTRACTS else "skew_modifier"
    table = SOCKET_TABLES[key]
    try:
        group.is_modifier = True
    except Exception:
        pass
    group.nodes.clear()
    geometry_in = group.interface.new_socket(name="Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    geometry_in.description = choose_text("Incoming geometry.", "入力ジオメトリです。", context=context)
    sockets = {entry["key"]: _add_socket(group, entry, context=context) for entry in table}
    geometry_out = group.interface.new_socket(name="Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    geometry_out.description = choose_text("Output geometry.", "出力ジオメトリです。", context=context)

    nodes = group.nodes
    gin = _node(nodes, "NodeGroupInput")
    gout = _node(nodes, "NodeGroupOutput")
    try:
        gout.is_active_output = True
    except Exception:
        pass

    def gi(entry_key):
        name = next(entry["name"] for entry in table if entry["key"] == entry_key)
        return _sock(gin.outputs, name)

    # Points in gizmo space.
    position = _node(nodes, "GeometryNodeInputPosition").outputs[0]
    self_object = _node(nodes, "GeometryNodeSelfObject")
    object_info = _node(nodes, "GeometryNodeObjectInfo", "Object", transform_space="ORIGINAL")
    group.links.new(self_object.outputs[0], _sock(object_info.inputs, "Object"))
    gizmo_info = _node(nodes, "GeometryNodeObjectInfo", "Gizmo", transform_space="ORIGINAL")
    group.links.new(gi("gizmo"), _sock(gizmo_info.inputs, "Object"))
    object_matrix = _sock(object_info.outputs, "Transform")
    gizmo_matrix = _sock(gizmo_info.outputs, "Transform")
    world = _transform(group, position, object_matrix, label="Object To World")
    local = _transform(group, world, _invert(group, gizmo_matrix), label="World To Gizmo")
    separate = _node(nodes, "ShaderNodeSeparateXYZ")
    group.links.new(local, separate.inputs[0])
    x, y, z = separate.outputs[0], separate.outputs[1], separate.outputs[2]
    axis = gi("axis")
    h = _index_switch(group, "FLOAT", axis, (x, y, z), label="Primary")
    a = _index_switch(group, "FLOAT", axis, (y, x, x), label="First Secondary")
    b = _index_switch(group, "FLOAT", axis, (z, z, y), label="Second Secondary")

    # Extent along the primary axis (3ds Max uses the bounding box of the input).
    statistic = _node(nodes, "GeometryNodeAttributeStatistic", "Primary Extent", data_type="FLOAT", domain="POINT")
    group.links.new(_sock(gin.outputs, "Geometry"), _sock(statistic.inputs, "Geometry"))
    group.links.new(h, _sock(statistic.inputs, "Attribute"))
    h_min = _sock(statistic.outputs, "Min")
    h_max = _sock(statistic.outputs, "Max")
    h_range = _sock(statistic.outputs, "Range")

    # Limits: effective only when enabled and Upper > Lower.
    lower = gi("lower_limit")
    upper = gi("upper_limit")
    limits = _mul(group, gi("use_limits"), _fmath(group, "GREATER_THAN", _sub(group, upper, lower), _EPS))
    clamped = _fmath(group, "MINIMUM", _fmath(group, "MAXIMUM", h, lower), upper)
    hc = _mix(group, h, clamped, limits)

    h2, a2, b2 = h, a, b
    if key == "skew_modifier":
        length = _fmath(group, "MAXIMUM", _mix(group, h_range, _sub(group, upper, lower), limits), _EPS)
        shift = _div(group, _mul(group, gi("amount"), hc), length)
        direction = _fmath(group, "RADIANS", gi("direction"))
        a2 = _add(group, a, _mul(group, shift, _fmath(group, "COSINE", direction)))
        b2 = _add(group, b, _mul(group, shift, _fmath(group, "SINE", direction)))
    elif key == "taper_modifier":
        length = _fmath(group, "MAXIMUM", h_range, _EPS)
        mirrored = _mix(group, hc, _fmath(group, "ABSOLUTE", hc), gi("symmetry"))
        u = _div(group, mirrored, length)
        f = _add(group, _add(group, 1.0, _mul(group, gi("amount"), u)), _mul(group, gi("curve"), _mul(group, u, _sub(group, 1.0, u))))
        do_a = _index_switch(group, "FLOAT", gi("effect"), (1.0, 0.0, 1.0), label="Effect First")
        do_b = _index_switch(group, "FLOAT", gi("effect"), (0.0, 1.0, 1.0), label="Effect Second")
        f_minus_one = _sub(group, f, 1.0)
        a2 = _mul(group, a, _add(group, 1.0, _mul(group, f_minus_one, do_a)))
        b2 = _mul(group, b, _add(group, 1.0, _mul(group, f_minus_one, do_b)))
    else:
        stretch = gi("stretch")
        major = _factor(group, stretch)
        inverse = _div(group, 1.0, _factor(group, _mul(group, stretch, _factor(group, gi("amplify")))))
        h2 = _add(group, _mul(group, hc, major), _sub(group, h, hc))
        top = _mix(group, h_max, upper, limits)
        bottom = _mix(group, _fmath(group, "MULTIPLY", h_min, -1.0), _fmath(group, "MULTIPLY", lower, -1.0), limits)
        end = _fmath(group, "MAXIMUM", _mix(group, top, bottom, _fmath(group, "LESS_THAN", hc, 0.0)), _EPS)
        t = _fmath(group, "MINIMUM", _div(group, _fmath(group, "ABSOLUTE", hc), end), 1.0)
        weight = _sub(group, 1.0, _mul(group, t, t))
        scale = _add(group, 1.0, _mul(group, _sub(group, inverse, 1.0), weight))
        a2 = _mul(group, a, scale)
        b2 = _mul(group, b, scale)

    moved_local = _index_switch(
        group, "VECTOR", axis,
        (_combine(group, h2, a2, b2), _combine(group, a2, h2, b2), _combine(group, a2, b2, h2)),
        label="Back To Axes",
    )
    moved_world = _transform(group, moved_local, gizmo_matrix, label="Gizmo To World")
    moved = _transform(group, moved_world, _invert(group, object_matrix), label="World To Object")
    delta = _node(nodes, "ShaderNodeVectorMath", "Delta", operation="SUBTRACT")
    group.links.new(moved, delta.inputs[0])
    group.links.new(position, delta.inputs[1])
    scaled = _node(nodes, "ShaderNodeVectorMath", "Influence", operation="SCALE")
    group.links.new(delta.outputs[0], scaled.inputs[0])
    group.links.new(gi("influence"), scaled.inputs[3])
    blended = _node(nodes, "ShaderNodeVectorMath", "Blend", operation="ADD")
    group.links.new(position, blended.inputs[0])
    group.links.new(scaled.outputs[0], blended.inputs[1])
    set_position = _node(nodes, "GeometryNodeSetPosition")
    group.links.new(_sock(gin.outputs, "Geometry"), _sock(set_position.inputs, "Geometry"))
    group.links.new(blended.outputs[0], _sock(set_position.inputs, "Position"))
    group.links.new(_sock(set_position.outputs, "Geometry"), _sock(gout.inputs, "Geometry"))

    group[CONTRACT_PROP] = KEY_CONTRACTS[key]
    for entry_key, item in sockets.items():
        group[SOCKET_PREFIX + entry_key] = str(getattr(item, "identifier", "") or "")
    return sockets
