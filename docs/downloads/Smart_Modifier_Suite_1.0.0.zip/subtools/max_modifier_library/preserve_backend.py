# -*- coding: utf-8 -*-
"""Dedicated topology-matched Preserve backend.

Construction is fail-closed.  Preserve never falls back to Corrective Smooth
or to a passthrough graph when its complete contract cannot be built.
"""

from __future__ import annotations

import hashlib

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ...translation import choose_text


PRESERVE_MARKER_PROP = "smsm_preserve_modifier"
PRESERVE_GRAPH_CONTRACT_PROP = "smsm_preserve_graph_contract"
PRESERVE_GRAPH_CONTRACT = "dedicated_topology_matched_preserve_v1"
PRESERVE_NODE_GROUP_PROP = "smsm_preserve_node_group"
PRESERVE_SOCKET_PREFIX = "smsm_preserve_socket_"
PRESERVE_GROUP_OWNER_PROP = "smsm_preserve_group_owner"
PRESERVE_GROUP_OWNER_VALUE = "SmartModifier:preserve_modifier:4.32.76"
PRESERVE_SELECTION_PREFIX = "SMSM Preserve Selection"
PRESERVE_SELECTION_OWNER_PREFIX = "smsm_preserve_selection_owner:"

PRESERVE_SOCKET_NAMES = {
    "reference": "Reference Object",
    "iterations": "Iterations",
    "edge_lengths": "Edge Lengths",
    "face_angles": "Face Angles",
    "volume": "Volume",
    "whole_mesh": "Apply to Whole Mesh",
    "selection_attribute": "Selection Attribute",
    "invert_selection": "Invert Selection",
    "influence": "Influence",
}

PRESERVE_DEFAULTS = {
    "iterations": 1,
    "edge_lengths": 1.0,
    "face_angles": 0.3,
    "volume": 0.3,
    "whole_mesh": True,
    "selection_attribute": "",
    "invert_selection": False,
    "influence": 1.0,
}

REQUIRED_NODES = {
    "GeometryNodeRepeatInput",
    "GeometryNodeRepeatOutput",
    "GeometryNodeObjectInfo",
    "GeometryNodeSampleIndex",
    "GeometryNodeInputIndex",
    "GeometryNodeInputNormal",
    "GeometryNodeAttributeStatistic",
    "GeometryNodeInputNamedAttribute",
    "GeometryNodeSetPosition",
    "GeometryNodeAttributeDomainSize",
}


def _unique_name(base, collection):
    if collection.get(base) is None:
        return base
    index = 1
    while collection.get(f"{base}.{index:03d}") is not None:
        index += 1
    return f"{base}.{index:03d}"


def preserve_selection_owner_key(group_name):
    digest = hashlib.sha256(str(group_name or "").encode("utf-8")).hexdigest()[:32]
    return PRESERVE_SELECTION_OWNER_PREFIX + digest


def _native_modifier_may_use_vertex_group(modifier, group_name):
    """Fail closed for a native modifier whose vertex-group usage is unknown."""
    if modifier is None:
        return False
    try:
        if str(getattr(modifier, "type", "") or "") == "NODES":
            # A generic Geometry Nodes graph can consume a named attribute without
            # an inspectable vertex_group RNA property.
            group = getattr(modifier, "node_group", None)
            verified_preserve = (
                bool(modifier.get(PRESERVE_MARKER_PROP, False))
                and str(modifier.get(PRESERVE_GRAPH_CONTRACT_PROP, "") or "") == PRESERVE_GRAPH_CONTRACT
                and is_verified_preserve_group(group)
            )
            if not verified_preserve:
                return True
            sid = str(modifier.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
            actual_socket = _interface_socket(group, PRESERVE_SOCKET_NAMES["selection_attribute"])
            actual_sid = str(getattr(actual_socket, "identifier", "") or "")
            # The GN interface is authoritative. Missing or stale mapping data
            # cannot establish that this graph no longer consumes the old group.
            if not sid or not actual_sid or sid != actual_sid or sid not in modifier:
                return True
            return str(modifier.get(actual_sid, "") or "") == str(group_name or "")
        properties = getattr(getattr(modifier, "bl_rna", None), "properties", None)
        if properties is None:
            return True
        for prop in properties:
            identifier = str(getattr(prop, "identifier", "") or "")
            if "vertex_group" not in identifier or str(getattr(prop, "type", "")) != "STRING":
                continue
            if str(getattr(modifier, identifier, "") or "") == str(group_name or ""):
                return True
    except Exception:
        return True
    return False


def remove_owned_preserve_selection_if_unused(owner, group_name):
    name = str(group_name or "")
    if owner is None or not name:
        return False
    vertex_group = owner.vertex_groups.get(name)
    owner_key = preserve_selection_owner_key(name)
    try:
        owned = vertex_group is not None and str(owner.get(owner_key, "") or "") == PRESERVE_GROUP_OWNER_VALUE
    except Exception:
        owned = False
    if not owned:
        return False
    try:
        # Vertex groups are object-owned, but a linked mesh makes it unsafe to
        # infer that this object is the only consumer of the captured selection.
        if int(getattr(getattr(owner, "data", None), "users", 1) or 1) > 1:
            return False
    except Exception:
        return False
    for other in tuple(getattr(owner, "modifiers", ()) or ()):
        try:
            sid = str(other.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
            if sid and str(other.get(sid, "") or "") == name:
                return False
        except Exception:
            return False
        if _native_modifier_may_use_vertex_group(other, name):
            return False
    owner.vertex_groups.remove(vertex_group)
    try:
        del owner[owner_key]
    except Exception:
        pass
    return True


def _socket(sockets, names=(), fallback=None):
    for name in names:
        try:
            value = sockets.get(name)
            if value is not None:
                return value
        except Exception:
            pass
    if fallback is not None:
        try:
            return sockets[fallback]
        except Exception:
            pass
    return None


def _link(group, source, target):
    if source is None or target is None:
        raise RuntimeError("Preserve graph socket was not found")
    group.links.new(source, target)


def _set(socket, value):
    if socket is None:
        raise RuntimeError("Preserve graph default socket was not found")
    socket.default_value = value


def _add_socket(group, name, in_out, socket_type, *, default=None, minimum=None, maximum=None, description=""):
    item = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    if default is not None:
        try:
            item.default_value = default
        except Exception:
            pass
    if minimum is not None:
        try:
            item.min_value = minimum
        except Exception:
            pass
    if maximum is not None:
        try:
            item.max_value = maximum
        except Exception:
            pass
    item.description = description
    return item


def _interface_socket(group, name, in_out="INPUT"):
    for item in group.interface.items_tree:
        if str(getattr(item, "item_type", "")) == "SOCKET" and str(getattr(item, "in_out", "")).upper() == in_out and str(getattr(item, "name", "")) == name:
            return item
    return None


def _math(nodes, operation, *, label, a=0.0, b=0.0):
    node = nodes.new("ShaderNodeMath")
    node.operation = operation
    node.label = label
    _set(_socket(node.inputs, fallback=0), a)
    _set(_socket(node.inputs, fallback=1), b)
    return node


def _vector(nodes, operation, *, label):
    node = nodes.new("ShaderNodeVectorMath")
    node.operation = operation
    node.label = label
    return node


def make_preserve_group(obj, defn=None, context=None):
    owner = str(getattr(obj, "name", "Object") or "Object")
    group = None
    try:
        group = bpy.data.node_groups.new(_unique_name(f"Smart_Preserve - {owner}", bpy.data.node_groups), "GeometryNodeTree")
        group.is_modifier = True
        group[PRESERVE_GROUP_OWNER_PROP] = PRESERVE_GROUP_OWNER_VALUE
        group[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT

        _add_socket(group, "Geometry", "INPUT", "NodeSocketGeometry", description="Incoming ordered-stack geometry.")
        _add_socket(group, "Reference Object", "INPUT", "NodeSocketObject", description="External mesh with exactly matching point topology.")
        _add_socket(group, "Iterations", "INPUT", "NodeSocketInt", default=1, minimum=1, maximum=64)
        _add_socket(group, "Edge Lengths", "INPUT", "NodeSocketFloat", default=1.0, minimum=0.0, maximum=1.0)
        _add_socket(group, "Face Angles", "INPUT", "NodeSocketFloat", default=0.3, minimum=0.0, maximum=1.0)
        _add_socket(group, "Volume", "INPUT", "NodeSocketFloat", default=0.3, minimum=0.0, maximum=1.0)
        _add_socket(group, "Apply to Whole Mesh", "INPUT", "NodeSocketBool", default=True)
        _add_socket(group, "Selection Attribute", "INPUT", "NodeSocketString", default="")
        _add_socket(group, "Invert Selection", "INPUT", "NodeSocketBool", default=False)
        _add_socket(group, "Influence", "INPUT", "NodeSocketFloat", default=1.0, minimum=0.0, maximum=1.0)
        _add_socket(group, "Geometry", "OUTPUT", "NodeSocketGeometry")

        nodes = group.nodes
        nodes.clear()
        gi = nodes.new("NodeGroupInput")
        go = nodes.new("NodeGroupOutput")
        go.is_active_output = True

        repeat_out = nodes.new("GeometryNodeRepeatOutput")
        repeat_in = nodes.new("GeometryNodeRepeatInput")
        repeat_in.pair_with_output(repeat_out)
        repeat_in.label = "Recompute Preserve Geometry"
        _link(group, _socket(gi.outputs, ("Geometry",), 0), _socket(repeat_in.inputs, ("Geometry",), 1))
        _link(group, _socket(gi.outputs, ("Iterations",), 2), _socket(repeat_in.inputs, ("Iterations",), 0))

        obj_info = nodes.new("GeometryNodeObjectInfo")
        obj_info.transform_space = "ORIGINAL"
        _link(group, _socket(gi.outputs, ("Reference Object",), 1), _socket(obj_info.inputs, ("Object",), 0))
        index = nodes.new("GeometryNodeInputIndex")
        current_pos = nodes.new("GeometryNodeInputPosition")
        current_normal = nodes.new("GeometryNodeInputNormal")

        sample_pos = nodes.new("GeometryNodeSampleIndex")
        sample_pos.data_type = "FLOAT_VECTOR"
        sample_pos.domain = "POINT"
        sample_pos.clamp = False
        ref_pos_field = nodes.new("GeometryNodeInputPosition")
        _link(group, _socket(obj_info.outputs, ("Geometry",), 4), _socket(sample_pos.inputs, ("Geometry",), 0))
        _link(group, _socket(ref_pos_field.outputs, ("Position",), 0), _socket(sample_pos.inputs, ("Value",), 1))
        _link(group, _socket(index.outputs, ("Index",), 0), _socket(sample_pos.inputs, ("Index",), 2))

        sample_normal = nodes.new("GeometryNodeSampleIndex")
        sample_normal.data_type = "FLOAT_VECTOR"
        sample_normal.domain = "POINT"
        sample_normal.clamp = False
        ref_normal_field = nodes.new("GeometryNodeInputNormal")
        _link(group, _socket(obj_info.outputs, ("Geometry",), 4), _socket(sample_normal.inputs, ("Geometry",), 0))
        _link(group, _socket(ref_normal_field.outputs, ("Normal",), 0), _socket(sample_normal.inputs, ("Value",), 1))
        _link(group, _socket(index.outputs, ("Index",), 0), _socket(sample_normal.inputs, ("Index",), 2))

        current_size = nodes.new("GeometryNodeAttributeDomainSize")
        reference_size = nodes.new("GeometryNodeAttributeDomainSize")
        _link(group, _socket(repeat_in.outputs, ("Geometry",), 1), _socket(current_size.inputs, ("Geometry",), 0))
        _link(group, _socket(obj_info.outputs, ("Geometry",), 4), _socket(reference_size.inputs, ("Geometry",), 0))
        topology_equal = _math(nodes, "COMPARE", label="Exact Topology Point Count", a=0.0, b=0.0)
        _set(_socket(topology_equal.inputs, fallback=2), 0.1)
        _link(group, _socket(current_size.outputs, ("Point Count",), 0), _socket(topology_equal.inputs, fallback=0))
        _link(group, _socket(reference_size.outputs, ("Point Count",), 0), _socket(topology_equal.inputs, fallback=1))

        delta = _vector(nodes, "SUBTRACT", label="Reference Position Delta")
        _link(group, _socket(sample_pos.outputs, ("Value",), 0), _socket(delta.inputs, fallback=0))
        _link(group, _socket(current_pos.outputs, ("Position",), 0), _socket(delta.inputs, fallback=1))
        edge_term = _vector(nodes, "SCALE", label="Edge Length Correction")
        _link(group, _socket(delta.outputs, ("Vector",), 0), _socket(edge_term.inputs, ("Vector",), 0))
        _link(group, _socket(gi.outputs, ("Edge Lengths",), 3), _socket(edge_term.inputs, ("Scale",), 3))

        face_dot = _vector(nodes, "DOT_PRODUCT", label="Face Angle Signed Distance")
        _link(group, _socket(delta.outputs, ("Vector",), 0), _socket(face_dot.inputs, fallback=0))
        _link(group, _socket(sample_normal.outputs, ("Value",), 0), _socket(face_dot.inputs, fallback=1))
        face_term = _vector(nodes, "SCALE", label="Face Angle Correction")
        _link(group, _socket(sample_normal.outputs, ("Value",), 0), _socket(face_term.inputs, ("Vector",), 0))
        face_weight = _math(nodes, "MULTIPLY", label="Face Angle Weight")
        _link(group, _socket(face_dot.outputs, ("Value",), 1), _socket(face_weight.inputs, fallback=0))
        _link(group, _socket(gi.outputs, ("Face Angles",), 4), _socket(face_weight.inputs, fallback=1))
        _link(group, _socket(face_weight.outputs, ("Value",), 0), _socket(face_term.inputs, ("Scale",), 3))

        current_center = nodes.new("GeometryNodeAttributeStatistic")
        reference_center = nodes.new("GeometryNodeAttributeStatistic")
        current_center.data_type = reference_center.data_type = "FLOAT_VECTOR"
        current_center.domain = reference_center.domain = "POINT"
        _link(group, _socket(repeat_in.outputs, ("Geometry",), 1), _socket(current_center.inputs, ("Geometry",), 0))
        _link(group, _socket(current_pos.outputs, ("Position",), 0), _socket(current_center.inputs, ("Attribute",), 2))
        _link(group, _socket(obj_info.outputs, ("Geometry",), 4), _socket(reference_center.inputs, ("Geometry",), 0))
        _link(group, _socket(ref_pos_field.outputs, ("Position",), 0), _socket(reference_center.inputs, ("Attribute",), 2))
        current_radius = _vector(nodes, "SUBTRACT", label="Current Radius")
        reference_radius = _vector(nodes, "SUBTRACT", label="Reference Radius")
        _link(group, _socket(current_pos.outputs, ("Position",), 0), _socket(current_radius.inputs, fallback=0))
        _link(group, _socket(current_center.outputs, ("Mean",), 2), _socket(current_radius.inputs, fallback=1))
        _link(group, _socket(sample_pos.outputs, ("Value",), 0), _socket(reference_radius.inputs, fallback=0))
        _link(group, _socket(reference_center.outputs, ("Mean",), 2), _socket(reference_radius.inputs, fallback=1))
        current_len = _vector(nodes, "LENGTH", label="Current Radius Length")
        reference_len = _vector(nodes, "LENGTH", label="Reference Radius Length")
        radial_dir = _vector(nodes, "NORMALIZE", label="Reference Radial Direction")
        _link(group, _socket(current_radius.outputs, ("Vector",), 0), _socket(current_len.inputs, fallback=0))
        _link(group, _socket(reference_radius.outputs, ("Vector",), 0), _socket(reference_len.inputs, fallback=0))
        _link(group, _socket(reference_radius.outputs, ("Vector",), 0), _socket(radial_dir.inputs, fallback=0))
        radial_difference = _math(nodes, "SUBTRACT", label="Volume Radius Difference")
        _link(group, _socket(reference_len.outputs, ("Value",), 1), _socket(radial_difference.inputs, fallback=0))
        _link(group, _socket(current_len.outputs, ("Value",), 1), _socket(radial_difference.inputs, fallback=1))
        volume_weight = _math(nodes, "MULTIPLY", label="Volume Weight")
        _link(group, _socket(radial_difference.outputs, ("Value",), 0), _socket(volume_weight.inputs, fallback=0))
        _link(group, _socket(gi.outputs, ("Volume",), 5), _socket(volume_weight.inputs, fallback=1))
        volume_term = _vector(nodes, "SCALE", label="Volume Correction")
        _link(group, _socket(radial_dir.outputs, ("Vector",), 0), _socket(volume_term.inputs, ("Vector",), 0))
        _link(group, _socket(volume_weight.outputs, ("Value",), 0), _socket(volume_term.inputs, ("Scale",), 3))

        edge_face = _vector(nodes, "ADD", label="Edge plus Face")
        total = _vector(nodes, "ADD", label="Weighted Preserve Correction")
        _link(group, _socket(edge_term.outputs, ("Vector",), 0), _socket(edge_face.inputs, fallback=0))
        _link(group, _socket(face_term.outputs, ("Vector",), 0), _socket(edge_face.inputs, fallback=1))
        _link(group, _socket(edge_face.outputs, ("Vector",), 0), _socket(total.inputs, fallback=0))
        _link(group, _socket(volume_term.outputs, ("Vector",), 0), _socket(total.inputs, fallback=1))

        iteration_floor = _math(nodes, "MAXIMUM", label="Minimum One Iteration", a=1.0, b=1.0)
        step_scale = _math(nodes, "DIVIDE", label="Influence Per Iteration", a=1.0, b=1.0)
        _link(group, _socket(gi.outputs, ("Iterations",), 2), _socket(iteration_floor.inputs, fallback=0))
        _link(group, _socket(gi.outputs, ("Influence",), 9), _socket(step_scale.inputs, fallback=0))
        _link(group, _socket(iteration_floor.outputs, ("Value",), 0), _socket(step_scale.inputs, fallback=1))
        step_offset = _vector(nodes, "SCALE", label="Preserve Step Offset")
        _link(group, _socket(total.outputs, ("Vector",), 0), _socket(step_offset.inputs, ("Vector",), 0))
        _link(group, _socket(step_scale.outputs, ("Value",), 0), _socket(step_offset.inputs, ("Scale",), 3))

        named = nodes.new("GeometryNodeInputNamedAttribute")
        named.data_type = "FLOAT"
        _link(group, _socket(gi.outputs, ("Selection Attribute",), 7), _socket(named.inputs, ("Name",), 0))
        selected = _math(nodes, "GREATER_THAN", label="Captured Vertex Selection", a=0.0, b=0.5)
        _link(group, _socket(named.outputs, ("Attribute",), 0), _socket(selected.inputs, fallback=0))
        inverted = nodes.new("FunctionNodeBooleanMath")
        inverted.operation = "NOT"
        _link(group, _socket(selected.outputs, ("Value",), 0), _socket(inverted.inputs, fallback=0))
        invert_switch = nodes.new("GeometryNodeSwitch")
        invert_switch.input_type = "BOOLEAN"
        _link(group, _socket(gi.outputs, ("Invert Selection",), 8), _socket(invert_switch.inputs, ("Switch",), 0))
        _link(group, _socket(selected.outputs, ("Value",), 0), _socket(invert_switch.inputs, ("False",), 1))
        _link(group, _socket(inverted.outputs, ("Boolean",), 0), _socket(invert_switch.inputs, ("True",), 2))
        whole_switch = nodes.new("GeometryNodeSwitch")
        whole_switch.input_type = "BOOLEAN"
        _set(_socket(whole_switch.inputs, ("True",), 2), True)
        _link(group, _socket(gi.outputs, ("Apply to Whole Mesh",), 6), _socket(whole_switch.inputs, ("Switch",), 0))
        _link(group, _socket(invert_switch.outputs, ("Output",), 0), _socket(whole_switch.inputs, ("False",), 1))
        final_selection = nodes.new("FunctionNodeBooleanMath")
        final_selection.operation = "AND"
        _link(group, _socket(whole_switch.outputs, ("Output",), 0), _socket(final_selection.inputs, fallback=0))
        _link(group, _socket(topology_equal.outputs, ("Value",), 0), _socket(final_selection.inputs, fallback=1))

        set_position = nodes.new("GeometryNodeSetPosition")
        _link(group, _socket(repeat_in.outputs, ("Geometry",), 1), _socket(set_position.inputs, ("Geometry",), 0))
        _link(group, _socket(final_selection.outputs, ("Boolean",), 0), _socket(set_position.inputs, ("Selection",), 1))
        _link(group, _socket(step_offset.outputs, ("Vector",), 0), _socket(set_position.inputs, ("Offset",), 3))
        _link(group, _socket(set_position.outputs, ("Geometry",), 0), _socket(repeat_out.inputs, ("Geometry",), 0))
        _link(group, _socket(repeat_out.outputs, ("Geometry",), 0), _socket(go.inputs, ("Geometry",), 0))

        actual = {str(node.bl_idname) for node in nodes}
        if not REQUIRED_NODES.issubset(actual) or len(group.links) < 55:
            raise RuntimeError("Dedicated Preserve graph contract is incomplete")
        group["smsm_preserve_required_nodes"] = ",".join(sorted(REQUIRED_NODES))
        group["smsm_preserve_link_count"] = len(group.links)
        return group
    except Exception:
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        raise


def is_verified_preserve_group(group):
    try:
        actual = {str(node.bl_idname) for node in group.nodes}
        return (
            str(group.get(PRESERVE_GROUP_OWNER_PROP, "")) == PRESERVE_GROUP_OWNER_VALUE
            and str(group.get(PRESERVE_GRAPH_CONTRACT_PROP, "")) == PRESERVE_GRAPH_CONTRACT
            and REQUIRED_NODES.issubset(actual)
            and int(group.get("smsm_preserve_link_count", -1)) == len(group.links)
        )
    except Exception:
        return False


def configure_preserve_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group=False):
    if obj is None or mod is None:
        raise RuntimeError("Preserve owner/modifier is missing")
    if group is None or force_unique_group:
        group = make_preserve_group(obj, defn, context=context)
    if getattr(mod, "node_group", None) is not group:
        mod.node_group = group
    if not is_verified_preserve_group(group):
        raise RuntimeError("Preserve group does not satisfy its owned graph contract")
    mod[PRESERVE_MARKER_PROP] = True
    mod[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT
    mod[PRESERVE_NODE_GROUP_PROP] = str(group.name)
    mod["smsm_generic_modifier"] = True
    mod["smsm_max_modifier_backend"] = "preserve_nodes"
    for key, socket_name in PRESERVE_SOCKET_NAMES.items():
        socket = _interface_socket(group, socket_name)
        if socket is None or not str(getattr(socket, "identifier", "") or ""):
            raise RuntimeError(f"Preserve interface socket is missing: {socket_name}")
        identifier = str(socket.identifier)
        mod[PRESERVE_SOCKET_PREFIX + key] = identifier
        if key in PRESERVE_DEFAULTS and identifier not in mod:
            mod[identifier] = PRESERVE_DEFAULTS[key]
    obj.update_tag()
    return group


def preserve_skip_copy_props(mod):
    result = {PRESERVE_MARKER_PROP, PRESERVE_GRAPH_CONTRACT_PROP, PRESERVE_NODE_GROUP_PROP, "node_group"}
    result.update(str(key) for key in mod.keys() if str(key).startswith(PRESERVE_SOCKET_PREFIX))
    return result


def after_preserve_instance_sync(src_obj, src_mod, obj, mod, context=None):
    configure_preserve_modifier(obj, mod, getattr(mod, "node_group", None), {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)


def after_preserve_make_unique(obj, mod, context=None):
    old = getattr(mod, "node_group", None)
    if old is None:
        configure_preserve_modifier(obj, mod, None, {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)
        return
    copied = old.copy()
    copied.name = _unique_name(f"Smart_Preserve - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    copied[PRESERVE_GROUP_OWNER_PROP] = PRESERVE_GROUP_OWNER_VALUE
    copied[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT
    configure_preserve_modifier(obj, mod, copied, {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)


def draw_preserve_properties(layout, mod, context=None):
    if not bool(mod.get(PRESERVE_MARKER_PROP, False)):
        return False
    box = layout.box()
    box.label(text=choose_text("Topology-matched Preserve", "同一トポロジー保持", context=context), icon="MOD_SMOOTH")
    col = box.column(align=True)
    col.use_property_split = True
    labels = {
        "reference": ("Reference Object", "参照オブジェクト"), "iterations": ("Iterations", "反復"),
        "edge_lengths": ("Edge Lengths", "エッジ長"), "face_angles": ("Face Angles", "面角度"),
        "volume": ("Volume", "ボリューム"), "whole_mesh": ("Apply to Whole Mesh", "メッシュ全体に適用"),
        "selection_attribute": ("Selection Attribute", "選択属性"), "invert_selection": ("Invert Selection", "選択を反転"),
        "influence": ("Influence", "影響度"),
    }
    for key in PRESERVE_SOCKET_NAMES:
        sid = str(mod.get(PRESERVE_SOCKET_PREFIX + key, "") or "")
        if sid:
            en, ja = labels[key]
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
    owner = getattr(mod, "id_data", None)
    op = col.operator("smsm.max_preserve_capture_selection", text=choose_text("Capture Selected Vertices", "選択頂点を取得", context=context), icon="VERTEXSEL")
    op.object_name = str(getattr(owner, "name", "") or "")
    op.modifier_name = str(getattr(mod, "name", "") or "")
    col.label(text=choose_text("Reference topology must match exactly; mismatch leaves geometry unchanged.", "参照トポロジーが一致しない場合、形状は変更されません。", context=context))
    return True


class SMSM_OT_max_preserve_capture_selection(Operator):
    bl_idname = "smsm.max_preserve_capture_selection"
    bl_label = "Capture Preserve Vertex Selection"
    bl_options = {"UNDO"}

    object_name: StringProperty(default="")
    modifier_name: StringProperty(default="")

    def execute(self, context):
        obj = bpy.data.objects.get(str(self.object_name or "")) or getattr(context, "object", None)
        mod = obj.modifiers.get(str(self.modifier_name or "")) if obj is not None else None
        if obj is None or mod is None or getattr(obj, "type", "") != "MESH" or not bool(mod.get(PRESERVE_MARKER_PROP, False)):
            return {"CANCELLED"}
        was_edit = getattr(obj, "mode", "OBJECT") == "EDIT"
        try:
            if getattr(obj, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        indices = [vertex.index for vertex in obj.data.vertices if bool(vertex.select)]
        selection_sid = str(mod.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
        whole_sid = str(mod.get(PRESERVE_SOCKET_PREFIX + "whole_mesh", "") or "")
        if not selection_sid or not whole_sid:
            raise RuntimeError("Preserve selection sockets are unavailable")
        previous_selection = str(mod.get(selection_sid, "") or "")
        previous_whole_mesh = mod.get(whole_sid, True)
        group_name = _unique_name(f"{PRESERVE_SELECTION_PREFIX} - {obj.name}", obj.vertex_groups)
        vertex_group = obj.vertex_groups.new(name=group_name)
        owner_key = preserve_selection_owner_key(vertex_group.name)
        try:
            if indices:
                vertex_group.add(indices, 1.0, "REPLACE")
            obj[owner_key] = PRESERVE_GROUP_OWNER_VALUE
            mod[selection_sid] = vertex_group.name
            mod[whole_sid] = False
        except Exception:
            try:
                mod[selection_sid] = previous_selection
                mod[whole_sid] = previous_whole_mesh
            except Exception:
                pass
            try:
                del obj[owner_key]
            except Exception:
                pass
            try:
                obj.vertex_groups.remove(vertex_group)
            except Exception:
                pass
            raise
        if previous_selection and previous_selection != vertex_group.name:
            remove_owned_preserve_selection_if_unused(obj, previous_selection)
        if was_edit:
            bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, choose_text(f"Captured {len(indices)} vertices.", f"{len(indices)} 頂点を取得しました。", context=context))
        return {"FINISHED"}


CLASSES = (SMSM_OT_max_preserve_capture_selection,)
