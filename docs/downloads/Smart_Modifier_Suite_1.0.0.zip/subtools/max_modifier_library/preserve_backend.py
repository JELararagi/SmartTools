# -*- coding: utf-8 -*-
"""Dedicated topology-matched Preserve backend.

Construction is fail-closed.  Preserve never falls back to Corrective Smooth
or to a passthrough graph when its complete contract cannot be built.
"""

from __future__ import annotations

import hashlib

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ...translation import choose_text


PRESERVE_MARKER_PROP = "smsm_preserve_modifier"
PRESERVE_GRAPH_CONTRACT_PROP = "smsm_preserve_graph_contract"
PRESERVE_GRAPH_CONTRACT = "dedicated_topology_matched_preserve_v2"
PRESERVE_LEGACY_GRAPH_CONTRACTS = ("dedicated_topology_matched_preserve_v1",)
PRESERVE_MIN_LINKS = 132
PRESERVE_NODE_GROUP_PROP = "smsm_preserve_node_group"
PRESERVE_SOCKET_PREFIX = "smsm_preserve_socket_"
PRESERVE_GROUP_OWNER_PROP = "smsm_preserve_group_owner"
PRESERVE_GROUP_OWNER_VALUE = "SmartModifier:preserve_modifier:4.32.76"
PRESERVE_SELECTION_PREFIX = "SMSM Preserve Selection"
PRESERVE_SELECTION_OWNER_PREFIX = "smsm_preserve_selection_owner:"

PRESERVE_SOCKET_NAMES = {
    "reference": "Reference Object",
    "iterations": "Iterations",
    "edge_lengths": "Edge Lengths",
    "face_angles": "Face Angles",
    "volume": "Volume",
    "whole_mesh": "Apply to Whole Mesh",
    "selection_attribute": "Selection Attribute",
    "invert_selection": "Invert Selection",
    "influence": "Influence",
}

PRESERVE_DEFAULTS = {
    "iterations": 1,
    "edge_lengths": 1.0,
    "face_angles": 0.3,
    "volume": 0.3,
    "whole_mesh": True,
    "selection_attribute": "",
    "invert_selection": False,
    "influence": 1.0,
}

REQUIRED_NODES = {
    "GeometryNodeRepeatInput",
    "GeometryNodeRepeatOutput",
    "GeometryNodeObjectInfo",
    "GeometryNodeSampleIndex",
    "GeometryNodeInputIndex",
    "GeometryNodeInputNormal",
    "GeometryNodeAttributeStatistic",
    "GeometryNodeInputNamedAttribute",
    "GeometryNodeSetPosition",
    "GeometryNodeAttributeDomainSize",
    "GeometryNodeInputMeshEdgeVertices",
    "GeometryNodeInputMeshFaceArea",
    "GeometryNodeFieldOnDomain",
    "GeometryNodeCaptureAttribute",
}


def _unique_name(base, collection):
    if collection.get(base) is None:
        return base
    index = 1
    while collection.get(f"{base}.{index:03d}") is not None:
        index += 1
    return f"{base}.{index:03d}"


def preserve_selection_owner_key(group_name):
    digest = hashlib.sha256(str(group_name or "").encode("utf-8")).hexdigest()[:32]
    return PRESERVE_SELECTION_OWNER_PREFIX + digest


def _native_modifier_may_use_vertex_group(modifier, group_name):
    """Fail closed for a native modifier whose vertex-group usage is unknown."""
    if modifier is None:
        return False
    try:
        if str(getattr(modifier, "type", "") or "") == "NODES":
            # A generic Geometry Nodes graph can consume a named attribute without
            # an inspectable vertex_group RNA property.
            group = getattr(modifier, "node_group", None)
            verified_preserve = (
                bool(modifier.get(PRESERVE_MARKER_PROP, False))
                and str(modifier.get(PRESERVE_GRAPH_CONTRACT_PROP, "") or "") == PRESERVE_GRAPH_CONTRACT
                and is_verified_preserve_group(group)
            )
            if not verified_preserve:
                return True
            sid = str(modifier.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
            actual_socket = _interface_socket(group, PRESERVE_SOCKET_NAMES["selection_attribute"])
            actual_sid = str(getattr(actual_socket, "identifier", "") or "")
            # The GN interface is authoritative. Missing or stale mapping data
            # cannot establish that this graph no longer consumes the old group.
            if not sid or not actual_sid or sid != actual_sid or sid not in modifier:
                return True
            return str(modifier.get(actual_sid, "") or "") == str(group_name or "")
        properties = getattr(getattr(modifier, "bl_rna", None), "properties", None)
        if properties is None:
            return True
        for prop in properties:
            identifier = str(getattr(prop, "identifier", "") or "")
            if "vertex_group" not in identifier or str(getattr(prop, "type", "")) != "STRING":
                continue
            if str(getattr(modifier, identifier, "") or "") == str(group_name or ""):
                return True
    except Exception:
        return True
    return False


def remove_owned_preserve_selection_if_unused(owner, group_name):
    name = str(group_name or "")
    if owner is None or not name:
        return False
    vertex_group = owner.vertex_groups.get(name)
    owner_key = preserve_selection_owner_key(name)
    try:
        owned = vertex_group is not None and str(owner.get(owner_key, "") or "") == PRESERVE_GROUP_OWNER_VALUE
    except Exception:
        owned = False
    if not owned:
        return False
    try:
        # Vertex groups are object-owned, but a linked mesh makes it unsafe to
        # infer that this object is the only consumer of the captured selection.
        if int(getattr(getattr(owner, "data", None), "users", 1) or 1) > 1:
            return False
    except Exception:
        return False
    for other in tuple(getattr(owner, "modifiers", ()) or ()):
        # ID プロパティを持つのはジオメトリノードのモディファイアだけ。ネイティブ（WELD など）に
        # .get を呼ぶと TypeError になり、使っていない選択の頂点グループまで残ってしまう。
        if str(getattr(other, "type", "") or "") == "NODES":
            try:
                sid = str(other.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
                if sid and str(other.get(sid, "") or "") == name:
                    return False
            except Exception:
                return False
        if _native_modifier_may_use_vertex_group(other, name):
            return False
    owner.vertex_groups.remove(vertex_group)
    try:
        del owner[owner_key]
    except Exception:
        pass
    return True


def _socket(sockets, names=(), fallback=None):
    for name in names:
        try:
            value = sockets.get(name)
            if value is not None:
                return value
        except Exception:
            pass
    if fallback is not None:
        try:
            return sockets[fallback]
        except Exception:
            pass
    return None


def _link(group, source, target):
    if source is None or target is None:
        raise RuntimeError("Preserve graph socket was not found")
    group.links.new(source, target)


def _set(socket, value):
    if socket is None:
        raise RuntimeError("Preserve graph default socket was not found")
    socket.default_value = value


def _add_socket(group, name, in_out, socket_type, *, default=None, minimum=None, maximum=None, description=""):
    item = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    if default is not None:
        try:
            item.default_value = default
        except Exception:
            pass
    if minimum is not None:
        try:
            item.min_value = minimum
        except Exception:
            pass
    if maximum is not None:
        try:
            item.max_value = maximum
        except Exception:
            pass
    item.description = description
    return item


def _interface_socket(group, name, in_out="INPUT"):
    for item in group.interface.items_tree:
        if str(getattr(item, "item_type", "")) == "SOCKET" and str(getattr(item, "in_out", "")).upper() == in_out and str(getattr(item, "name", "")) == name:
            return item
    return None


def _math(nodes, operation, *, label, a=0.0, b=0.0):
    node = nodes.new("ShaderNodeMath")
    node.operation = operation
    node.label = label
    _set(_socket(node.inputs, fallback=0), a)
    _set(_socket(node.inputs, fallback=1), b)
    return node


def _vector(nodes, operation, *, label):
    node = nodes.new("ShaderNodeVectorMath")
    node.operation = operation
    node.label = label
    return node


def _sock(sockets, name, index=None):
    """名前で有効なソケットを返す。同名が複数ある時は有効な物の index 番目。"""
    found = [s for s in sockets if str(getattr(s, "name", "")) == name and bool(getattr(s, "enabled", True))]
    if not found:
        raise RuntimeError(f"Preserve graph socket was not found: {name}")
    return found[index or 0]


def _node(nodes, idname, label="", **props):
    node = nodes.new(idname)
    if label:
        node.label = label
    for key, value in props.items():
        setattr(node, key, value)
    return node


def _vmath(group, operation, a=None, b=None, scale=None, *, label=""):
    node = _node(group.nodes, "ShaderNodeVectorMath", label, operation=operation)
    for index, value in ((0, a), (1, b)):
        if value is None:
            continue
        if isinstance(value, (tuple, list)):
            node.inputs[index].default_value = value
        else:
            group.links.new(value, node.inputs[index])
    if scale is not None:
        if isinstance(scale, (int, float)):
            node.inputs[3].default_value = float(scale)
        else:
            group.links.new(scale, node.inputs[3])
    return node


def _fmath(group, operation, a=None, b=None, *, label=""):
    node = _node(group.nodes, "ShaderNodeMath", label, operation=operation)
    for index, value in ((0, a), (1, b)):
        if value is None:
            continue
        if isinstance(value, (int, float)):
            node.inputs[index].default_value = float(value)
        else:
            group.links.new(value, node.inputs[index])
    return node.outputs[0]


def _on_domain(group, domain, data_type, value, *, label=""):
    node = _node(group.nodes, "GeometryNodeFieldOnDomain", label, domain=domain, data_type=data_type)
    group.links.new(value, _sock(node.inputs, "Value"))
    return _sock(node.outputs, "Value")


def _sample(group, geometry, domain, data_type, value, index, *, label=""):
    node = _node(group.nodes, "GeometryNodeSampleIndex", label, domain=domain, data_type=data_type)
    node.clamp = False
    group.links.new(geometry, _sock(node.inputs, "Geometry"))
    group.links.new(value, _sock(node.inputs, "Value"))
    group.links.new(index, _sock(node.inputs, "Index"))
    return _sock(node.outputs, "Value")


def _statistic(group, geometry, domain, data_type, value, output, *, label=""):
    node = _node(group.nodes, "GeometryNodeAttributeStatistic", label, domain=domain, data_type=data_type)
    group.links.new(geometry, _sock(node.inputs, "Geometry"))
    group.links.new(value, _sock(node.inputs, "Attribute"))
    return _sock(node.outputs, output)


def _edge_length_field(group, *, label=""):
    edge = _node(group.nodes, "GeometryNodeInputMeshEdgeVertices", label)
    dist = _vmath(group, "DISTANCE", _sock(edge.outputs, "Position 1"), _sock(edge.outputs, "Position 2"), label=label + " Length")
    return edge, dist.outputs[1]


def _corner_to_face_center_field(group, *, label=""):
    pos = _node(group.nodes, "GeometryNodeInputPosition", label + " Position")
    center = _on_domain(group, "FACE", "FLOAT_VECTOR", _sock(pos.outputs, "Position"), label=label + " Face Center")
    rel = _vmath(group, "SUBTRACT", _sock(pos.outputs, "Position"), center, label=label + " Corner To Center")
    return rel.outputs[0]


def _signed_volume(group, geometry, *, label=""):
    """V = Σ A·((c − g)·n)/3。重心 g からの体積なので剛体の移動で変わらない。"""
    pos = _node(group.nodes, "GeometryNodeInputPosition", label + " Position")
    centroid = _statistic(group, geometry, "POINT", "FLOAT_VECTOR", _sock(pos.outputs, "Position"), "Mean", label=label + " Centroid")
    normal = _node(group.nodes, "GeometryNodeInputNormal", label + " Face Normal")
    area = _node(group.nodes, "GeometryNodeInputMeshFaceArea", label + " Face Area")
    rel = _vmath(group, "SUBTRACT", _sock(pos.outputs, "Position"), centroid, label=label + " Face Offset")
    dot = _vmath(group, "DOT_PRODUCT", rel.outputs[0], _sock(normal.outputs, "Normal"), label=label + " Height")
    cone = _fmath(group, "MULTIPLY", dot.outputs[1], _sock(area.outputs, "Area"), label=label + " Cone")
    cone = _fmath(group, "DIVIDE", cone, 3.0, label=label + " Cone Volume")
    volume = _statistic(group, geometry, "FACE", "FLOAT", cone, "Sum", label=label + " Volume")
    return volume, area


def make_preserve_group(obj, defn=None, context=None):
    """3ds Max の Preserve と同じ考え方：参照の辺の長さ・面の形・体積へ近づける緩和を反復する。

    参照の位置へは引き戻さない（剛体の移動では形が変わらない）。
    """
    owner = str(getattr(obj, "name", "Object") or "Object")
    group = None
    try:
        group = bpy.data.node_groups.new(_unique_name(f"Smart_Preserve - {owner}", bpy.data.node_groups), "GeometryNodeTree")
        group.is_modifier = True
        group[PRESERVE_GROUP_OWNER_PROP] = PRESERVE_GROUP_OWNER_VALUE
        group[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT

        _add_socket(group, "Geometry", "INPUT", "NodeSocketGeometry", description="Incoming ordered-stack geometry.")
        _add_socket(group, "Reference Object", "INPUT", "NodeSocketObject", description="Original mesh with exactly matching topology (the shape to preserve).")
        _add_socket(group, "Iterations", "INPUT", "NodeSocketInt", default=1, minimum=1, maximum=64, description="Relaxation passes; more passes follow the reference measurements more closely.")
        _add_socket(group, "Edge Lengths", "INPUT", "NodeSocketFloat", default=1.0, minimum=0.0, maximum=1.0, description="Weight for keeping the reference edge lengths.")
        _add_socket(group, "Face Angles", "INPUT", "NodeSocketFloat", default=0.3, minimum=0.0, maximum=1.0, description="Weight for keeping the reference face shapes.")
        _add_socket(group, "Volume", "INPUT", "NodeSocketFloat", default=0.3, minimum=0.0, maximum=1.0, description="Weight for keeping the reference volume.")
        _add_socket(group, "Apply to Whole Mesh", "INPUT", "NodeSocketBool", default=True)
        _add_socket(group, "Selection Attribute", "INPUT", "NodeSocketString", default="")
        _add_socket(group, "Invert Selection", "INPUT", "NodeSocketBool", default=False)
        _add_socket(group, "Influence", "INPUT", "NodeSocketFloat", default=1.0, minimum=0.0, maximum=1.0)
        _add_socket(group, "Geometry", "OUTPUT", "NodeSocketGeometry")

        nodes, links = group.nodes, group.links
        nodes.clear()
        gi = _node(nodes, "NodeGroupInput")
        go = _node(nodes, "NodeGroupOutput")
        go.is_active_output = True

        ref_info = _node(nodes, "GeometryNodeObjectInfo", "Reference Object", transform_space="ORIGINAL")
        links.new(_sock(gi.outputs, "Reference Object"), _sock(ref_info.inputs, "Object"))
        ref_geo = _sock(ref_info.outputs, "Geometry")

        repeat_out = _node(nodes, "GeometryNodeRepeatOutput")
        repeat_in = _node(nodes, "GeometryNodeRepeatInput", "Preserve Relaxation")
        repeat_in.pair_with_output(repeat_out)
        links.new(_sock(gi.outputs, "Geometry"), _sock(repeat_in.inputs, "Geometry"))
        links.new(_sock(gi.outputs, "Iterations"), _sock(repeat_in.inputs, "Iterations"))
        cur_geo = _sock(repeat_in.outputs, "Geometry")

        # 位相の一致（点・辺・角の数）。一致しない時は形を変えない。
        cur_size = _node(nodes, "GeometryNodeAttributeDomainSize", "Current Topology")
        ref_size = _node(nodes, "GeometryNodeAttributeDomainSize", "Reference Topology")
        links.new(cur_geo, _sock(cur_size.inputs, "Geometry"))
        links.new(ref_geo, _sock(ref_size.inputs, "Geometry"))
        same = None
        for name in ("Point Count", "Edge Count", "Face Corner Count"):
            cmp = _node(nodes, "FunctionNodeCompare", f"Same {name}", data_type="INT", operation="EQUAL")
            links.new(_sock(cur_size.outputs, name), _sock(cmp.inputs, "A"))
            links.new(_sock(ref_size.outputs, name), _sock(cmp.inputs, "B"))
            if same is None:
                same = cmp.outputs[0]
            else:
                both = _node(nodes, "FunctionNodeBooleanMath", "Topology Match", operation="AND")
                links.new(same, both.inputs[0])
                links.new(cmp.outputs[0], both.inputs[1])
                same = both.outputs[0]

        index = _node(nodes, "GeometryNodeInputIndex", "Element Index")
        position = _node(nodes, "GeometryNodeInputPosition", "Current Position")
        pos = _sock(position.outputs, "Position")

        # 参照とは点の番号だけで対応させる（3ds Max と同じ）。辺や角の並びが参照と違っても正しく働く。
        ref_position = _node(nodes, "GeometryNodeInputPosition", "Reference Position")
        ref_point = _sample(group, ref_geo, "POINT", "FLOAT_VECTOR", _sock(ref_position.outputs, "Position"), _sock(index.outputs, "Index"), label="Reference Point Position")
        capture = _node(nodes, "GeometryNodeCaptureAttribute", "Reference Point On Current", domain="POINT")
        capture.capture_items.new("VECTOR", "Reference Position")
        links.new(cur_geo, _sock(capture.inputs, "Geometry"))
        links.new(ref_point, _sock(capture.inputs, "Reference Position"))
        step_geo = _sock(capture.outputs, "Geometry")
        ref_at_point = _sock(capture.outputs, "Reference Position")

        # 辺の長さ：辺ごとに k = L0/L − 1、端点は k·(p − 中点) だけ動く。点へは接する辺の平均。
        cur_edge, cur_len = _edge_length_field(group, label="Current Edge")
        ref_start = _sample(group, ref_geo, "POINT", "FLOAT_VECTOR", _sock(ref_position.outputs, "Position"), _sock(cur_edge.outputs, "Vertex Index 1"), label="Reference Edge Start")
        ref_end = _sample(group, ref_geo, "POINT", "FLOAT_VECTOR", _sock(ref_position.outputs, "Position"), _sock(cur_edge.outputs, "Vertex Index 2"), label="Reference Edge End")
        ref_len = _vmath(group, "DISTANCE", ref_start, ref_end, label="Reference Edge Length").outputs[1]
        k = _fmath(group, "DIVIDE", ref_len, _fmath(group, "MAXIMUM", cur_len, 1.0e-8), label="Edge Ratio")
        k = _fmath(group, "SUBTRACT", k, 1.0, label="Edge Correction Factor")
        mid = _vmath(group, "ADD", _sock(cur_edge.outputs, "Position 1"), _sock(cur_edge.outputs, "Position 2"), label="Edge Sum")
        mid = _vmath(group, "SCALE", mid.outputs[0], scale=0.5, label="Edge Midpoint")
        k_mid = _vmath(group, "SCALE", mid.outputs[0], scale=k, label="Edge Weighted Midpoint")
        k_avg = _on_domain(group, "EDGE", "FLOAT", k, label="Edge Factor On Edges")
        k_mid_avg = _on_domain(group, "EDGE", "FLOAT_VECTOR", k_mid.outputs[0], label="Edge Midpoint On Edges")
        edge_term = _vmath(group, "SCALE", pos, scale=k_avg, label="Edge Scaled Position")
        edge_term = _vmath(group, "SUBTRACT", edge_term.outputs[0], k_mid_avg, label="Edge Length Correction")

        # 面の形：角ごとに頂点から面の中心までの距離を参照に合わせる。点へは角の平均。
        cur_rel = _corner_to_face_center_field(group, label="Current Corner")
        ref_center = _on_domain(group, "FACE", "FLOAT_VECTOR", ref_at_point, label="Reference Face Center")
        ref_rel = _vmath(group, "SUBTRACT", ref_at_point, ref_center, label="Reference Corner To Center")
        ref_dist = _vmath(group, "LENGTH", ref_rel.outputs[0], label="Reference Corner Distance").outputs[1]
        cur_dist = _vmath(group, "LENGTH", cur_rel, label="Current Corner Distance")
        q = _fmath(group, "DIVIDE", ref_dist, _fmath(group, "MAXIMUM", cur_dist.outputs[1], 1.0e-8), label="Face Ratio")
        q = _fmath(group, "SUBTRACT", q, 1.0, label="Face Correction Factor")
        corner_move = _vmath(group, "SCALE", cur_rel, scale=q, label="Corner Correction")
        face_term = _on_domain(group, "CORNER", "FLOAT_VECTOR", corner_move.outputs[0], label="Face Shape Correction")

        # 体積：差 (V0 − V) を全面積で割った距離だけ頂点の法線の向きへ動かす。
        cur_volume, cur_area = _signed_volume(group, cur_geo, label="Current")
        ref_volume, _ref_area = _signed_volume(group, ref_geo, label="Reference")
        total_area = _statistic(group, cur_geo, "FACE", "FLOAT", _sock(cur_area.outputs, "Area"), "Sum", label="Current Area")
        offset = _fmath(group, "DIVIDE", _fmath(group, "SUBTRACT", ref_volume, cur_volume), _fmath(group, "MAXIMUM", total_area, 1.0e-8), label="Volume Offset")
        vnormal = _node(nodes, "GeometryNodeInputNormal", "Vertex Normal")
        volume_term = _vmath(group, "SCALE", _sock(vnormal.outputs, "Normal"), scale=offset, label="Volume Correction")

        # 重み：辺と面は合計が 1 を超えないように割り、体積は足す。
        w_edge = _sock(gi.outputs, "Edge Lengths")
        w_face = _sock(gi.outputs, "Face Angles")
        w_vol = _sock(gi.outputs, "Volume")
        norm = _fmath(group, "MAXIMUM", _fmath(group, "ADD", w_edge, w_face), 1.0, label="Shape Weight Sum")
        e_w = _vmath(group, "SCALE", edge_term.outputs[0], scale=_fmath(group, "DIVIDE", w_edge, norm), label="Weighted Edge")
        f_w = _vmath(group, "SCALE", face_term, scale=_fmath(group, "DIVIDE", w_face, norm), label="Weighted Face")
        v_w = _vmath(group, "SCALE", volume_term.outputs[0], scale=w_vol, label="Weighted Volume")
        total = _vmath(group, "ADD", e_w.outputs[0], f_w.outputs[0], label="Shape Correction")
        total = _vmath(group, "ADD", total.outputs[0], v_w.outputs[0], label="Preserve Correction")

        # 選択：全体／選択頂点だけ／反転。
        named = _node(nodes, "GeometryNodeInputNamedAttribute", "Selection Attribute", data_type="FLOAT")
        links.new(_sock(gi.outputs, "Selection Attribute"), _sock(named.inputs, "Name"))
        to_bool = _node(nodes, "FunctionNodeCompare", "Captured Vertex Selection", data_type="FLOAT", operation="GREATER_THAN")
        links.new(_sock(named.outputs, "Attribute"), _sock(to_bool.inputs, "A"))
        _sock(to_bool.inputs, "B").default_value = 0.5
        xor = _node(nodes, "FunctionNodeBooleanMath", "Invert Selection", operation="XOR")
        links.new(to_bool.outputs[0], xor.inputs[0])
        links.new(_sock(gi.outputs, "Invert Selection"), xor.inputs[1])
        whole = _node(nodes, "FunctionNodeBooleanMath", "Whole Mesh Or Selection", operation="OR")
        links.new(_sock(gi.outputs, "Apply to Whole Mesh"), whole.inputs[0])
        links.new(xor.outputs[0], whole.inputs[1])
        final = _node(nodes, "FunctionNodeBooleanMath", "Preserve Selection", operation="AND")
        links.new(whole.outputs[0], final.inputs[0])
        links.new(same, final.inputs[1])

        set_pos = _node(nodes, "GeometryNodeSetPosition", "Preserve Step")
        links.new(step_geo, _sock(set_pos.inputs, "Geometry"))
        links.new(final.outputs[0], _sock(set_pos.inputs, "Selection"))
        links.new(total.outputs[0], _sock(set_pos.inputs, "Offset"))
        links.new(_sock(set_pos.outputs, "Geometry"), _sock(repeat_out.inputs, "Geometry"))

        # 影響度：入力の位置と緩和後の位置を混ぜる。
        orig_pos = _node(nodes, "GeometryNodeInputPosition", "Input Position")
        orig = _sample(group, _sock(gi.outputs, "Geometry"), "POINT", "FLOAT_VECTOR", _sock(orig_pos.outputs, "Position"), _sock(index.outputs, "Index"), label="Input Position Sample")
        relaxed = _node(nodes, "GeometryNodeInputPosition", "Relaxed Position")
        diff = _vmath(group, "SUBTRACT", _sock(relaxed.outputs, "Position"), orig, label="Relaxation Offset")
        diff = _vmath(group, "SCALE", diff.outputs[0], scale=_sock(gi.outputs, "Influence"), label="Influenced Offset")
        blended = _vmath(group, "ADD", orig, diff.outputs[0], label="Influenced Position")
        blend = _node(nodes, "GeometryNodeSetPosition", "Preserve Influence")
        links.new(_sock(repeat_out.outputs, "Geometry"), _sock(blend.inputs, "Geometry"))
        links.new(blended.outputs[0], _sock(blend.inputs, "Position"))
        links.new(_sock(blend.outputs, "Geometry"), _sock(go.inputs, "Geometry"))

        actual = {str(node.bl_idname) for node in nodes}
        if not REQUIRED_NODES.issubset(actual) or len(group.links) < PRESERVE_MIN_LINKS:
            raise RuntimeError("Dedicated Preserve graph contract is incomplete")
        group["smsm_preserve_required_nodes"] = ",".join(sorted(REQUIRED_NODES))
        group["smsm_preserve_link_count"] = len(group.links)
        return group
    except Exception:
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        raise


def is_verified_preserve_group(group):
    try:
        actual = {str(node.bl_idname) for node in group.nodes}
        return (
            str(group.get(PRESERVE_GROUP_OWNER_PROP, "")) == PRESERVE_GROUP_OWNER_VALUE
            and str(group.get(PRESERVE_GRAPH_CONTRACT_PROP, "")) == PRESERVE_GRAPH_CONTRACT
            and REQUIRED_NODES.issubset(actual)
            and int(group.get("smsm_preserve_link_count", -1)) == len(group.links)
        )
    except Exception:
        return False


def upgrade_legacy_preserve_modifier(obj, mod, context=None):
    """前の版（参照の位置へ引き戻す v1）のグラフを、値を引き継いで今のグラフへ作り替える。"""
    group = getattr(mod, "node_group", None)
    try:
        legacy = (
            group is not None
            and str(group.get(PRESERVE_GROUP_OWNER_PROP, "")) == PRESERVE_GROUP_OWNER_VALUE
            and str(group.get(PRESERVE_GRAPH_CONTRACT_PROP, "")) in PRESERVE_LEGACY_GRAPH_CONTRACTS
        )
    except Exception:
        legacy = False
    if not legacy or obj is None:
        return False
    values = {}
    for key in PRESERVE_SOCKET_NAMES:
        try:
            sid = str(mod.get(PRESERVE_SOCKET_PREFIX + key, "") or "")
            if sid and sid in mod:
                values[key] = mod[sid]
        except Exception:
            continue
    configure_preserve_modifier(obj, mod, None, {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)
    for key, value in values.items():
        try:
            sid = str(mod.get(PRESERVE_SOCKET_PREFIX + key, "") or "")
            if sid:
                mod[sid] = value
        except Exception:
            continue
    try:
        if int(getattr(group, "users", 0) or 0) == 0:
            bpy.data.node_groups.remove(group)
    except Exception:
        pass
    obj.update_tag()
    return True


def configure_preserve_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group=False):
    if obj is None or mod is None:
        raise RuntimeError("Preserve owner/modifier is missing")
    if group is None or force_unique_group:
        group = make_preserve_group(obj, defn, context=context)
    if getattr(mod, "node_group", None) is not group:
        mod.node_group = group
    if not is_verified_preserve_group(group):
        raise RuntimeError("Preserve group does not satisfy its owned graph contract")
    mod[PRESERVE_MARKER_PROP] = True
    mod[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT
    mod[PRESERVE_NODE_GROUP_PROP] = str(group.name)
    mod["smsm_generic_modifier"] = True
    mod["smsm_max_modifier_backend"] = "preserve_nodes"
    for key, socket_name in PRESERVE_SOCKET_NAMES.items():
        socket = _interface_socket(group, socket_name)
        if socket is None or not str(getattr(socket, "identifier", "") or ""):
            raise RuntimeError(f"Preserve interface socket is missing: {socket_name}")
        identifier = str(socket.identifier)
        mod[PRESERVE_SOCKET_PREFIX + key] = identifier
        if key in PRESERVE_DEFAULTS and identifier not in mod:
            mod[identifier] = PRESERVE_DEFAULTS[key]
    obj.update_tag()
    return group


def preserve_skip_copy_props(mod):
    result = {PRESERVE_MARKER_PROP, PRESERVE_GRAPH_CONTRACT_PROP, PRESERVE_NODE_GROUP_PROP, "node_group"}
    result.update(str(key) for key in mod.keys() if str(key).startswith(PRESERVE_SOCKET_PREFIX))
    return result


def after_preserve_instance_sync(src_obj, src_mod, obj, mod, context=None):
    configure_preserve_modifier(obj, mod, getattr(mod, "node_group", None), {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)


def after_preserve_make_unique(obj, mod, context=None):
    old = getattr(mod, "node_group", None)
    if old is None:
        configure_preserve_modifier(obj, mod, None, {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)
        return
    copied = old.copy()
    copied.name = _unique_name(f"Smart_Preserve - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    copied[PRESERVE_GROUP_OWNER_PROP] = PRESERVE_GROUP_OWNER_VALUE
    copied[PRESERVE_GRAPH_CONTRACT_PROP] = PRESERVE_GRAPH_CONTRACT
    configure_preserve_modifier(obj, mod, copied, {"key": "preserve_modifier", "backend": "preserve_nodes"}, context=context)


def draw_preserve_properties(layout, mod, context=None):
    if not bool(mod.get(PRESERVE_MARKER_PROP, False)):
        return False
    box = layout.box()
    box.label(text=choose_text("Topology-matched Preserve", "同一トポロジー保持", context=context), icon="MOD_SMOOTH")
    col = box.column(align=True)
    col.use_property_split = True
    labels = {
        "reference": ("Reference Object", "参照オブジェクト"), "iterations": ("Iterations", "反復"),
        "edge_lengths": ("Edge Lengths", "エッジ長"), "face_angles": ("Face Angles", "面角度"),
        "volume": ("Volume", "ボリューム"), "whole_mesh": ("Apply to Whole Mesh", "メッシュ全体に適用"),
        "selection_attribute": ("Selection Attribute", "選択属性"), "invert_selection": ("Invert Selection", "選択を反転"),
        "influence": ("Influence", "影響度"),
    }
    for key in PRESERVE_SOCKET_NAMES:
        sid = str(mod.get(PRESERVE_SOCKET_PREFIX + key, "") or "")
        if sid:
            en, ja = labels[key]
            col.prop(mod, f'["{sid}"]', text=choose_text(en, ja, context=context))
    owner = getattr(mod, "id_data", None)
    op = col.operator("smsm.max_preserve_capture_selection", text=choose_text("Capture Selected Vertices", "選択頂点を取得", context=context), icon="VERTEXSEL")
    op.object_name = str(getattr(owner, "name", "") or "")
    op.modifier_name = str(getattr(mod, "name", "") or "")
    col.label(text=choose_text("Reference topology must match exactly; mismatch leaves geometry unchanged.", "参照トポロジーが一致しない場合、形状は変更されません。", context=context))
    return True


class SMSM_OT_max_preserve_capture_selection(Operator):
    bl_idname = "smsm.max_preserve_capture_selection"
    bl_label = "Capture Preserve Vertex Selection"
    bl_options = {"UNDO"}

    object_name: StringProperty(default="")
    modifier_name: StringProperty(default="")

    def execute(self, context):
        obj = bpy.data.objects.get(str(self.object_name or "")) or getattr(context, "object", None)
        mod = obj.modifiers.get(str(self.modifier_name or "")) if obj is not None else None
        if obj is None or mod is None or getattr(obj, "type", "") != "MESH" or not bool(mod.get(PRESERVE_MARKER_PROP, False)):
            return {"CANCELLED"}
        was_edit = getattr(obj, "mode", "OBJECT") == "EDIT"
        try:
            if getattr(obj, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        indices = [vertex.index for vertex in obj.data.vertices if bool(vertex.select)]
        selection_sid = str(mod.get(PRESERVE_SOCKET_PREFIX + "selection_attribute", "") or "")
        whole_sid = str(mod.get(PRESERVE_SOCKET_PREFIX + "whole_mesh", "") or "")
        if not selection_sid or not whole_sid:
            raise RuntimeError("Preserve selection sockets are unavailable")
        previous_selection = str(mod.get(selection_sid, "") or "")
        previous_whole_mesh = mod.get(whole_sid, True)
        group_name = _unique_name(f"{PRESERVE_SELECTION_PREFIX} - {obj.name}", obj.vertex_groups)
        vertex_group = obj.vertex_groups.new(name=group_name)
        owner_key = preserve_selection_owner_key(vertex_group.name)
        try:
            if indices:
                vertex_group.add(indices, 1.0, "REPLACE")
            obj[owner_key] = PRESERVE_GROUP_OWNER_VALUE
            mod[selection_sid] = vertex_group.name
            mod[whole_sid] = False
        except Exception:
            try:
                mod[selection_sid] = previous_selection
                mod[whole_sid] = previous_whole_mesh
            except Exception:
                pass
            try:
                del obj[owner_key]
            except Exception:
                pass
            try:
                obj.vertex_groups.remove(vertex_group)
            except Exception:
                pass
            raise
        if previous_selection and previous_selection != vertex_group.name:
            remove_owned_preserve_selection_if_unused(obj, previous_selection)
        if was_edit:
            bpy.ops.object.mode_set(mode="EDIT")
        self.report({"INFO"}, choose_text(f"Captured {len(indices)} vertices.", f"{len(indices)} 頂点を取得しました。", context=context))
        return {"FINISHED"}


CLASSES = (SMSM_OT_max_preserve_capture_selection,)
