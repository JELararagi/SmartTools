# -*- coding: utf-8 -*-
"""Dedicated 3ds Max 2026.1-style Push backend for SmartModifier.

The graph is fail-closed: construction errors remove the partial node group and
propagate to the add operator.  It never returns a passthrough or native
Displace modifier under the Push name.
"""

from __future__ import annotations

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ...core import ms_sync_instance_group_from
from ...translation import choose_text


PUSH_MARKER_PROP = "smsm_push_modifier"
PUSH_GRAPH_CONTRACT_PROP = "smsm_push_graph_contract"
PUSH_GRAPH_CONTRACT = "dedicated_push_2026_1_v4_typed_pointcloud_falloff"
PUSH_LEGACY_GRAPH_CONTRACTS = {
    "dedicated_push_2026_1_v1",
    "dedicated_push_2026_1_v2_scale_geometry_off",
    "dedicated_push_2026_1_v3_collision_selection_falloff",
}
PUSH_NODE_GROUP_PROP = "smsm_push_node_group"
PUSH_SOCKET_PREFIX = "smsm_push_socket_"
PUSH_GROUP_PREFIX = "Smart_Push_2026_1"
PUSH_GROUP_OWNER_PROP = "smsm_push_group_owner"
PUSH_GROUP_OWNER_VALUE = "SmartModifier:push_modifier:4.32.75"
PUSH_COLLIDED_ATTRIBUTE = "smsm_push_collided"

PUSH_SOCKET_NAMES = {
    "amount": "Amount",
    "steps": "Steps",
    "normal_relax_iterations": "Normal Relax Iterations",
    "vertex_relax_iterations": "Vertex Relax Iterations",
    "collision_objects": "Collision Objects",
    "falloff": "Falloff",
    "axis_multiplier": "Axis Multiplier",
    "scale_normals": "Scale Normals",
    "influence": "Influence",
}

PUSH_DEFAULTS = {
    "amount": 0.0,
    "steps": 1,
    "normal_relax_iterations": 0,
    "vertex_relax_iterations": 0,
    "falloff": 0.0,
    "axis_multiplier": (1.0, 1.0, 1.0),
    "scale_normals": True,
    "influence": 1.0,
}


def _unique_name(base: str, collection) -> str:
    if collection.get(base) is None:
        return base
    index = 1
    while collection.get(f"{base}.{index:03d}") is not None:
        index += 1
    return f"{base}.{index:03d}"


def _interface_socket(group, name: str, in_out: str):
    for item in group.interface.items_tree:
        if (
            str(getattr(item, "item_type", "")) == "SOCKET"
            and str(getattr(item, "in_out", "")).upper() == in_out.upper()
            and str(getattr(item, "name", "")) == name
        ):
            return item
    return None


def _add_socket(group, name: str, in_out: str, socket_type: str, *, default=None, minimum=None, maximum=None, description=""):
    socket = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    if default is not None:
        try:
            socket.default_value = default
        except Exception:
            pass
    if minimum is not None:
        try:
            socket.min_value = minimum
        except Exception:
            pass
    if maximum is not None:
        try:
            socket.max_value = maximum
        except Exception:
            pass
    try:
        socket.description = description
    except Exception:
        pass
    return socket


def _socket(sockets, names=(), fallback=None):
    for name in names:
        try:
            found = sockets.get(name)
            if found is not None:
                return found
        except Exception:
            pass
    if fallback is not None:
        try:
            return sockets[fallback]
        except Exception:
            pass
    return None


def _active_typed_socket(sockets, name, bl_idname):
    matches = [
        socket for socket in sockets
        if socket.name == name
        and socket.bl_idname == bl_idname
        and bool(getattr(socket, "enabled", False))
        and not bool(getattr(socket, "hide", False))
    ]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one active {bl_idname} {name} socket, found {len(matches)}")
    return matches[0]


def _link(group, source, target) -> None:
    if source is None or target is None:
        raise RuntimeError("Push graph socket was not found")
    group.links.new(source, target)


def _set_default(socket, value) -> None:
    if socket is None:
        raise RuntimeError("Push graph default socket was not found")
    socket.default_value = value


def _math(nodes, operation: str, x: float, y: float, *, label: str):
    node = nodes.new("ShaderNodeMath")
    node.operation = operation
    node.label = label
    _set_default(_socket(node.inputs, fallback=0), x)
    _set_default(_socket(node.inputs, fallback=1), y)
    return node


def _vector_math(nodes, operation: str, *, label: str):
    node = nodes.new("ShaderNodeVectorMath")
    node.operation = operation
    node.label = label
    return node


def make_push_group(obj, defn=None, context=None):
    label = str((defn or {}).get("label") or "Push Modifier")
    owner_name = str(getattr(obj, "name", "Object") or "Object")
    name = _unique_name(f"{PUSH_GROUP_PREFIX} - {owner_name}", bpy.data.node_groups)
    group = None
    try:
        group = bpy.data.node_groups.new(name, "GeometryNodeTree")
        group.is_modifier = True
        group[PUSH_GROUP_OWNER_PROP] = PUSH_GROUP_OWNER_VALUE
        group[PUSH_GRAPH_CONTRACT_PROP] = PUSH_GRAPH_CONTRACT

        _add_socket(group, "Geometry", "INPUT", "NodeSocketGeometry", description="Incoming ordered stack geometry.")
        _add_socket(group, "Amount", "INPUT", "NodeSocketFloat", default=0.0, minimum=-100000.0, maximum=100000.0, description="World-unit distance along the current averaged vertex normal; negative values move inward.")
        _add_socket(group, "Steps", "INPUT", "NodeSocketInt", default=1, minimum=1, maximum=64, description="Re-evaluates geometry and normals for each Push step.")
        _add_socket(group, "Normal Relax Iterations", "INPUT", "NodeSocketInt", default=0, minimum=0, maximum=64, description="Separately smooths the current averaged vertex-normal field per step.")
        _add_socket(group, "Vertex Relax Iterations", "INPUT", "NodeSocketInt", default=0, minimum=0, maximum=64, description="Separately relaxes current vertex positions per step without changing topology.")
        _add_socket(group, "Collision Objects", "INPUT", "NodeSocketCollection", description="Scene collection used as collision-reference geometry.")
        _add_socket(group, "Falloff", "INPUT", "NodeSocketFloat", default=0.0, minimum=0.0, maximum=100000.0, description="Distance around collision-limited vertices included by Select Collided Vertices; it never reduces the collision travel distance.")
        _add_socket(group, "Axis Multiplier", "INPUT", "NodeSocketVector", default=(1.0, 1.0, 1.0), minimum=-1000.0, maximum=1000.0, description="Multiplies the current normal independently on local X, Y, and Z.")
        _add_socket(group, "Scale Normals", "INPUT", "NodeSocketBool", default=True, description="When enabled, axis multipliers limit Push along each axis. When disabled, they scale the resulting local mesh coordinates.")
        _add_socket(group, "Influence", "INPUT", "NodeSocketFloat", default=1.0, minimum=0.0, maximum=1.0, description="Global non-destructive Push influence.")
        _add_socket(group, "Geometry", "OUTPUT", "NodeSocketGeometry", description="Topology-preserving Push result with smsm_push_collided point attribute.")

        nodes = group.nodes
        links = group.links
        nodes.clear()
        group_input = nodes.new("NodeGroupInput")
        group_output = nodes.new("NodeGroupOutput")
        group_output.is_active_output = True
        group_input.location = (-1500, 0)
        group_output.location = (1540, 0)

        repeat_output = nodes.new("GeometryNodeRepeatOutput")
        repeat_input = nodes.new("GeometryNodeRepeatInput")
        repeat_input.pair_with_output(repeat_output)
        repeat_input.label = "Recompute Push Geometry"
        repeat_output.label = "Iterative Push Result"
        repeat_input.location = (-1180, 260)
        repeat_output.location = (1260, 260)

        _link(group, _socket(group_input.outputs, ("Geometry",), 0), _socket(repeat_input.inputs, ("Geometry",), 1))
        _link(group, _socket(group_input.outputs, ("Steps",), 2), _socket(repeat_input.inputs, ("Iterations",), 0))

        position = nodes.new("GeometryNodeInputPosition")
        normal = nodes.new("GeometryNodeInputNormal")
        previous_collision = nodes.new("GeometryNodeInputNamedAttribute")
        previous_collision.data_type = "BOOLEAN"
        _set_default(_socket(previous_collision.inputs, ("Name",), 0), PUSH_COLLIDED_ATTRIBUTE)

        normal_blur = nodes.new("GeometryNodeBlurAttribute")
        normal_blur.data_type = "FLOAT_VECTOR"
        normal_blur.label = "Normal Relax"
        _link(group, _socket(normal.outputs, ("Normal",), 0), _socket(normal_blur.inputs, ("Value",), 0))
        _link(group, _socket(group_input.outputs, ("Normal Relax Iterations",), 3), _socket(normal_blur.inputs, ("Iterations",), 1))

        position_blur = nodes.new("GeometryNodeBlurAttribute")
        position_blur.data_type = "FLOAT_VECTOR"
        position_blur.label = "Vertex Relax"
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(position_blur.inputs, ("Value",), 0))
        _link(group, _socket(group_input.outputs, ("Vertex Relax Iterations",), 4), _socket(position_blur.inputs, ("Iterations",), 1))

        relaxed_delta = _vector_math(nodes, "SUBTRACT", label="Vertex Relax Delta")
        _link(group, _socket(position_blur.outputs, ("Value",), 0), _socket(relaxed_delta.inputs, fallback=0))
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(relaxed_delta.inputs, fallback=1))

        axis_normal = _vector_math(nodes, "MULTIPLY", label="Axis Multiplier")
        _link(group, _socket(normal_blur.outputs, ("Value",), 0), _socket(axis_normal.inputs, fallback=0))
        _link(group, _socket(group_input.outputs, ("Axis Multiplier",), 7), _socket(axis_normal.inputs, fallback=1))

        scale_normal_switch = nodes.new("GeometryNodeSwitch")
        scale_normal_switch.input_type = "VECTOR"
        scale_normal_switch.label = "Scale Normals"
        _link(group, _socket(group_input.outputs, ("Scale Normals",), 8), _socket(scale_normal_switch.inputs, ("Switch",), 0))
        _link(group, _socket(normal_blur.outputs, ("Value",), 0), _socket(scale_normal_switch.inputs, ("False",), 1))
        _link(group, _socket(axis_normal.outputs, ("Vector",), 0), _socket(scale_normal_switch.inputs, ("True",), 2))

        step_floor = _math(nodes, "MAXIMUM", 1.0, 1.0, label="Minimum One Step")
        step_amount = _math(nodes, "DIVIDE", 0.0, 1.0, label="Amount Per Step")
        influenced_amount = _math(nodes, "MULTIPLY", 0.0, 1.0, label="Push Influence")
        _link(group, _socket(group_input.outputs, ("Steps",), 2), _socket(step_floor.inputs, fallback=0))
        _link(group, _socket(group_input.outputs, ("Amount",), 1), _socket(step_amount.inputs, fallback=0))
        _link(group, _socket(step_floor.outputs, ("Value",), 0), _socket(step_amount.inputs, fallback=1))
        _link(group, _socket(step_amount.outputs, ("Value",), 0), _socket(influenced_amount.inputs, fallback=0))
        _link(group, _socket(group_input.outputs, ("Influence",), 9), _socket(influenced_amount.inputs, fallback=1))

        movement = _vector_math(nodes, "SCALE", label="Signed Normal Push")
        _link(group, _socket(scale_normal_switch.outputs, ("Output",), 0), _socket(movement.inputs, ("Vector",), 0))
        _link(group, _socket(influenced_amount.outputs, ("Value",), 0), _socket(movement.inputs, ("Scale",), 3))
        movement_length = _vector_math(nodes, "LENGTH", label="Step Length")
        movement_direction = _vector_math(nodes, "NORMALIZE", label="Step Direction")
        _link(group, _socket(movement.outputs, ("Vector",), 0), _socket(movement_length.inputs, fallback=0))
        _link(group, _socket(movement.outputs, ("Vector",), 0), _socket(movement_direction.inputs, fallback=0))

        collection_info = nodes.new("GeometryNodeCollectionInfo")
        realize = nodes.new("GeometryNodeRealizeInstances")
        raycast = nodes.new("GeometryNodeRaycast")
        proximity = nodes.new("GeometryNodeProximity")
        raycast.data_type = "FLOAT"
        proximity.target_element = "FACES"
        collection_info.label = "Collision Reference Collection"
        raycast.label = "Directional Collision Clamp"
        proximity.label = "Nearest Collision Surface"
        _link(group, _socket(group_input.outputs, ("Collision Objects",), 5), _socket(collection_info.inputs, ("Collection",), 0))
        _link(group, _socket(collection_info.outputs, ("Instances",), 0), _socket(realize.inputs, ("Geometry",), 0))
        _link(group, _socket(realize.outputs, ("Geometry",), 0), _socket(raycast.inputs, ("Target Geometry",), 0))
        _link(group, _socket(realize.outputs, ("Geometry",), 0), _socket(proximity.inputs, ("Target", "Target Geometry"), 0))
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(raycast.inputs, ("Source Position",), 2))
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(proximity.inputs, ("Source Position", "Sample Position"), 1))
        _link(group, _socket(movement_direction.outputs, ("Vector",), 0), _socket(raycast.inputs, ("Ray Direction",), 3))
        _link(group, _socket(movement_length.outputs, ("Value",), 1), _socket(raycast.inputs, ("Ray Length",), 4))

        nearest_hit = _math(nodes, "MINIMUM", 0.0, 0.0, label="Nearest Directional Surface")
        nonnegative_distance = _math(nodes, "MAXIMUM", 0.0, 0.0, label="Nonnegative Allowed Distance")
        safe_length = _math(nodes, "MAXIMUM", 0.0, 0.0000001, label="Safe Step Denominator")
        distance_ratio = _math(nodes, "DIVIDE", 0.0, 1.0, label="Collision Clamp Ratio")
        ratio_cap = _math(nodes, "MINIMUM", 0.0, 1.0, label="Maximum Clamp Ratio")
        _link(group, _socket(raycast.outputs, ("Hit Distance",), 2), _socket(nearest_hit.inputs, fallback=0))
        _link(group, _socket(proximity.outputs, ("Distance",), 1), _socket(nearest_hit.inputs, fallback=1))
        _link(group, _socket(nearest_hit.outputs, ("Value",), 0), _socket(nonnegative_distance.inputs, fallback=0))
        _link(group, _socket(movement_length.outputs, ("Value",), 1), _socket(safe_length.inputs, fallback=0))
        _link(group, _socket(nonnegative_distance.outputs, ("Value",), 0), _socket(distance_ratio.inputs, fallback=0))
        _link(group, _socket(safe_length.outputs, ("Value",), 0), _socket(distance_ratio.inputs, fallback=1))
        _link(group, _socket(distance_ratio.outputs, ("Value",), 0), _socket(ratio_cap.inputs, fallback=0))

        clamped_movement = _vector_math(nodes, "SCALE", label="Collision-clamped Push")
        _link(group, _socket(movement.outputs, ("Vector",), 0), _socket(clamped_movement.inputs, ("Vector",), 0))
        _link(group, _socket(ratio_cap.outputs, ("Value",), 0), _socket(clamped_movement.inputs, ("Scale",), 3))
        collision_switch = nodes.new("GeometryNodeSwitch")
        collision_switch.input_type = "VECTOR"
        _link(group, _socket(raycast.outputs, ("Is Hit",), 0), _socket(collision_switch.inputs, ("Switch",), 0))
        _link(group, _socket(movement.outputs, ("Vector",), 0), _socket(collision_switch.inputs, ("False",), 1))
        _link(group, _socket(clamped_movement.outputs, ("Vector",), 0), _socket(collision_switch.inputs, ("True",), 2))

        total_offset = _vector_math(nodes, "ADD", label="Push plus Vertex Relax")
        _link(group, _socket(collision_switch.outputs, ("Output",), 0), _socket(total_offset.inputs, fallback=0))
        _link(group, _socket(relaxed_delta.outputs, ("Vector",), 0), _socket(total_offset.inputs, fallback=1))
        set_position = nodes.new("GeometryNodeSetPosition")
        _link(group, _socket(repeat_input.outputs, ("Geometry",), 1), _socket(set_position.inputs, ("Geometry",), 0))
        _link(group, _socket(total_offset.outputs, ("Vector",), 0), _socket(set_position.inputs, ("Offset",), 3))

        collision_or = nodes.new("FunctionNodeBooleanMath")
        collision_or.operation = "OR"
        _link(group, _socket(previous_collision.outputs, ("Attribute",), 0), _socket(collision_or.inputs, fallback=0))
        _link(group, _socket(raycast.outputs, ("Is Hit",), 0), _socket(collision_or.inputs, fallback=1))
        store_collision = nodes.new("GeometryNodeStoreNamedAttribute")
        store_collision.data_type = "BOOLEAN"
        store_collision.domain = "POINT"
        _set_default(_socket(store_collision.inputs, ("Name",), 2), PUSH_COLLIDED_ATTRIBUTE)
        _link(group, _socket(set_position.outputs, ("Geometry",), 0), _socket(store_collision.inputs, ("Geometry",), 0))
        _link(group, _socket(collision_or.outputs, ("Boolean",), 0), _socket(store_collision.inputs, ("Value",), 3))
        _link(group, _socket(store_collision.outputs, ("Geometry",), 0), _socket(repeat_output.inputs, ("Geometry",), 0))

        # 3ds Max Push Axis Multiplier has two distinct contracts.  The existing
        # Scale Normals=True branch above limits the normal-direction Push per
        # axis.  With Scale Normals=False, scale final object-local mesh data;
        # this intentionally includes the zero-Amount case and is visible to
        # higher stack rows as geometry, not as a normal-only direction change.
        mesh_data_axis_scale = _vector_math(nodes, "MULTIPLY", label="Mesh Data Axis Scale (Scale Normals Off)")
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(mesh_data_axis_scale.inputs, fallback=0))
        _link(group, _socket(group_input.outputs, ("Axis Multiplier",), 7), _socket(mesh_data_axis_scale.inputs, fallback=1))
        scale_mesh_data = nodes.new("GeometryNodeSetPosition")
        scale_mesh_data.label = "Scale Mesh Data When Scale Normals Is Off"
        _link(group, _socket(repeat_output.outputs, ("Geometry",), 0), _socket(scale_mesh_data.inputs, ("Geometry",), 0))
        _link(group, _socket(mesh_data_axis_scale.outputs, ("Vector",), 0), _socket(scale_mesh_data.inputs, ("Position",), 2))
        output_geometry = nodes.new("GeometryNodeSwitch")
        output_geometry.input_type = "GEOMETRY"
        output_geometry.label = "Scale Normals Output Contract"
        _link(group, _socket(group_input.outputs, ("Scale Normals",), 8), _socket(output_geometry.inputs, ("Switch",), 0))
        _link(group, _socket(scale_mesh_data.outputs, ("Geometry",), 0), _socket(output_geometry.inputs, ("False",), 1))
        _link(group, _socket(repeat_output.outputs, ("Geometry",), 0), _socket(output_geometry.inputs, ("True",), 2))

        # 3ds Max Push Falloff expands the selectable affected-vertex field
        # around collision-limited vertices; it is not travel safety distance.
        final_collision = nodes.new("GeometryNodeInputNamedAttribute")
        final_collision.data_type = "BOOLEAN"
        _set_default(_socket(final_collision.inputs, ("Name",), 0), PUSH_COLLIDED_ATTRIBUTE)
        collision_points = nodes.new("GeometryNodeMeshToPoints")
        collision_points.mode = "VERTICES"
        collision_points.label = "Collision-limited Vertices"
        _link(group, _socket(output_geometry.outputs, ("Output",), 0), _socket(collision_points.inputs, ("Mesh",), 0))
        _link(group, _socket(final_collision.outputs, ("Attribute",), 0), _socket(collision_points.inputs, ("Selection",), 1))
        falloff_proximity = nodes.new("GeometryNodeProximity")
        falloff_proximity.target_element = "POINTS"
        falloff_proximity.label = "Collision Selection Falloff"
        _link(group, _socket(collision_points.outputs, ("Points",), 0), _socket(falloff_proximity.inputs, ("Target", "Target Geometry"), 0))
        _link(group, _socket(position.outputs, ("Position",), 0), _socket(falloff_proximity.inputs, ("Source Position", "Sample Position"), 1))
        within_falloff = nodes.new("FunctionNodeCompare")
        within_falloff.data_type = "FLOAT"
        within_falloff.operation = "LESS_EQUAL"
        _link(group, _socket(falloff_proximity.outputs, ("Distance",), 1), _active_typed_socket(within_falloff.inputs, "A", "NodeSocketFloat"))
        _link(group, _socket(group_input.outputs, ("Falloff",), 6), _active_typed_socket(within_falloff.inputs, "B", "NodeSocketFloat"))
        point_count = nodes.new("GeometryNodeAttributeDomainSize")
        point_count.component = "POINTCLOUD"
        _link(group, _socket(collision_points.outputs, ("Points",), 0), _socket(point_count.inputs, ("Geometry",), 0))
        has_collision = nodes.new("FunctionNodeCompare")
        has_collision.data_type = "INT"
        has_collision.operation = "GREATER_THAN"
        _link(group, _socket(point_count.outputs, ("Point Count",), 0), _active_typed_socket(has_collision.inputs, "A", "NodeSocketInt"))
        _set_default(_active_typed_socket(has_collision.inputs, "B", "NodeSocketInt"), 0)
        falloff_active = nodes.new("FunctionNodeBooleanMath")
        falloff_active.operation = "AND"
        _link(group, _socket(within_falloff.outputs, ("Result",), 0), _socket(falloff_active.inputs, fallback=0))
        _link(group, _socket(has_collision.outputs, ("Result",), 0), _socket(falloff_active.inputs, fallback=1))
        affected_vertices = nodes.new("FunctionNodeBooleanMath")
        affected_vertices.operation = "OR"
        _link(group, _socket(final_collision.outputs, ("Attribute",), 0), _socket(affected_vertices.inputs, fallback=0))
        _link(group, _socket(falloff_active.outputs, ("Boolean",), 0), _socket(affected_vertices.inputs, fallback=1))
        store_affected = nodes.new("GeometryNodeStoreNamedAttribute")
        store_affected.data_type = "BOOLEAN"
        store_affected.domain = "POINT"
        store_affected.label = "Store Collision Falloff Selection"
        _set_default(_socket(store_affected.inputs, ("Name",), 2), PUSH_COLLIDED_ATTRIBUTE)
        _link(group, _socket(output_geometry.outputs, ("Output",), 0), _socket(store_affected.inputs, ("Geometry",), 0))
        _link(group, _socket(affected_vertices.outputs, ("Boolean",), 0), _socket(store_affected.inputs, ("Value",), 3))
        _link(group, _socket(store_affected.outputs, ("Geometry",), 0), _socket(group_output.inputs, ("Geometry",), 0))

        required = {
            "GeometryNodeRepeatInput",
            "GeometryNodeRepeatOutput",
            "GeometryNodeInputNormal",
            "GeometryNodeSetPosition",
            "GeometryNodeBlurAttribute",
            "GeometryNodeCollectionInfo",
            "GeometryNodeRaycast",
            "GeometryNodeProximity",
            "GeometryNodeMeshToPoints",
            "GeometryNodeAttributeDomainSize",
            "GeometryNodeStoreNamedAttribute",
        }
        actual = {str(node.bl_idname) for node in nodes}
        if not required.issubset(actual) or len(links) < 35:
            raise RuntimeError("Dedicated Push graph contract is incomplete")
        group["smsm_push_required_nodes"] = ",".join(sorted(required))
        group["smsm_push_link_count"] = len(links)
        return group
    except Exception:
        if group is not None:
            try:
                bpy.data.node_groups.remove(group)
            except Exception:
                pass
        raise


def configure_push_modifier(obj, mod, group=None, defn=None, context=None, *, force_unique_group=False):
    if obj is None or mod is None:
        raise RuntimeError("Push owner/modifier is missing")
    preserved = {}
    for key in PUSH_SOCKET_NAMES:
        try:
            identifier = str(mod.get(PUSH_SOCKET_PREFIX + key, "") or "")
            if identifier and identifier in mod:
                preserved[key] = mod.get(identifier)
        except Exception:
            pass
    old_group = group
    old_contract = str(getattr(group, "get", lambda *_: "")(PUSH_GRAPH_CONTRACT_PROP, "") or "") if group is not None else ""
    if (
        old_contract in PUSH_LEGACY_GRAPH_CONTRACTS
        and str(group.get(PUSH_GROUP_OWNER_PROP, "") or "") != PUSH_GROUP_OWNER_VALUE
    ):
        raise RuntimeError("Push legacy group lacks trusted ownership")
    if group is None or force_unique_group or old_contract in PUSH_LEGACY_GRAPH_CONTRACTS:
        group = make_push_group(obj, defn, context=context)
    if getattr(mod, "node_group", None) is not group:
        mod.node_group = group
    if str(group.get(PUSH_GROUP_OWNER_PROP, "") or "") != PUSH_GROUP_OWNER_VALUE:
        raise RuntimeError("Push node group lacks trusted ownership")
    if str(group.get(PUSH_GRAPH_CONTRACT_PROP, "") or "") != PUSH_GRAPH_CONTRACT:
        raise RuntimeError("Push node group contract mismatch")
    mod[PUSH_MARKER_PROP] = True
    mod[PUSH_GRAPH_CONTRACT_PROP] = PUSH_GRAPH_CONTRACT
    mod[PUSH_NODE_GROUP_PROP] = str(group.name)
    mod["smsm_generic_modifier"] = True
    mod["smsm_max_modifier_backend"] = "push_nodes"
    for key, socket_name in PUSH_SOCKET_NAMES.items():
        socket = _interface_socket(group, socket_name, "INPUT")
        if socket is None:
            raise RuntimeError(f"Push interface socket is missing: {socket_name}")
        identifier = str(getattr(socket, "identifier", "") or "")
        if not identifier:
            raise RuntimeError(f"Push interface identifier is missing: {socket_name}")
        mod[PUSH_SOCKET_PREFIX + key] = identifier
        if key in preserved:
            mod[identifier] = preserved[key]
        elif key in PUSH_DEFAULTS and identifier not in mod:
            mod[identifier] = PUSH_DEFAULTS[key]
    if old_group is not None and old_group is not group:
        try:
            if (
                str(old_group.get(PUSH_GROUP_OWNER_PROP, "") or "") == PUSH_GROUP_OWNER_VALUE
                and int(getattr(old_group, "users", 0) or 0) == 0
            ):
                bpy.data.node_groups.remove(old_group)
        except Exception:
            pass
    try:
        obj.update_tag(refresh={"DATA"})
    except Exception:
        obj.update_tag()
    return group


def push_skip_copy_props(mod) -> set[str]:
    skip = {PUSH_MARKER_PROP, PUSH_GRAPH_CONTRACT_PROP, PUSH_NODE_GROUP_PROP, "node_group"}
    try:
        skip.update(str(key) for key in mod.keys() if str(key).startswith(PUSH_SOCKET_PREFIX))
    except Exception:
        pass
    return skip


def after_push_instance_sync(src_obj, src_mod, obj, mod, context=None) -> None:
    configure_push_modifier(obj, mod, getattr(mod, "node_group", None), {"key": "push_modifier", "backend": "push_nodes", "label": "Push Modifier"}, context=context)


def after_push_make_unique(obj, mod, context=None) -> None:
    old_group = getattr(mod, "node_group", None)
    if old_group is None:
        configure_push_modifier(obj, mod, None, {"key": "push_modifier", "backend": "push_nodes", "label": "Push Modifier"}, context=context)
        return
    if str(old_group.get(PUSH_GRAPH_CONTRACT_PROP, "") or "") in PUSH_LEGACY_GRAPH_CONTRACTS:
        configure_push_modifier(obj, mod, old_group, {"key": "push_modifier", "backend": "push_nodes", "label": "Push Modifier"}, context=context)
        return
    copied = old_group.copy()
    copied.name = _unique_name(f"{PUSH_GROUP_PREFIX} - {getattr(obj, 'name', 'Object')}", bpy.data.node_groups)
    copied[PUSH_GROUP_OWNER_PROP] = PUSH_GROUP_OWNER_VALUE
    copied[PUSH_GRAPH_CONTRACT_PROP] = PUSH_GRAPH_CONTRACT
    configure_push_modifier(obj, mod, copied, {"key": "push_modifier", "backend": "push_nodes", "label": "Push Modifier"}, context=context)


def draw_push_properties(layout, mod, context=None) -> bool:
    try:
        if not bool(mod.get(PUSH_MARKER_PROP, False)):
            return False
    except Exception:
        return False
    box = layout.box()
    box.label(text=choose_text("Push 2026.1 Controls", "Push 2026.1 制御", context=context), icon="MOD_NORMALEDIT")
    col = box.column(align=True)
    col.use_property_split = True
    col.use_property_decorate = True
    labels = {
        "amount": ("Amount", "量"),
        "steps": ("Steps", "ステップ"),
        "normal_relax_iterations": ("Normal Relax Iterations", "法線リラックス反復"),
        "vertex_relax_iterations": ("Vertex Relax Iterations", "頂点リラックス反復"),
        "collision_objects": ("Collision Objects", "衝突オブジェクト"),
        "falloff": ("Falloff", "フォールオフ"),
        "axis_multiplier": ("Axis Multiplier", "軸倍率"),
        "scale_normals": ("Scale Normals", "法線をスケール"),
        "influence": ("Influence", "影響度"),
    }
    for key in PUSH_SOCKET_NAMES:
        identifier = str(mod.get(PUSH_SOCKET_PREFIX + key, "") or "")
        if not identifier:
            continue
        en, ja = labels[key]
        try:
            col.prop(mod, f'["{identifier}"]', text=choose_text(en, ja, context=context))
        except Exception:
            pass
    owner = getattr(mod, "id_data", None)
    op = col.operator(
        "smsm.max_push_select_collided",
        text=choose_text("Select Collided Vertices", "衝突頂点を選択", context=context),
        icon="VERTEXSEL",
    )
    op.object_name = str(getattr(owner, "name", "") or "")
    op.modifier_name = str(getattr(mod, "name", "") or "")
    col.label(text=choose_text("Falloff expands the selected collision-affected vertices.", "フォールオフは選択される衝突影響頂点の範囲を広げます。", context=context))
    col.label(text=choose_text("Scale Normals limits Push per axis; off scales local mesh data.", "法線をスケールは軸ごとの Push を制限し、オフではローカルメッシュデータをスケールします。", context=context))
    return True


class SMSM_OT_max_push_select_collided(Operator):
    bl_idname = "smsm.max_push_select_collided"
    bl_label = "Select Push Collided Vertices"
    bl_description = "Selects exactly the point-domain vertices marked by the evaluated Push collision field."
    bl_options = {"UNDO"}

    object_name: StringProperty(default="")
    modifier_name: StringProperty(default="")

    def execute(self, context):
        obj = bpy.data.objects.get(str(self.object_name or ""))
        if obj is None:
            obj = getattr(context, "object", None)
        mod = obj.modifiers.get(str(self.modifier_name or "")) if obj is not None else None
        try:
            valid = obj is not None and mod is not None and bool(mod.get(PUSH_MARKER_PROP, False))
        except Exception:
            valid = False
        if not valid or getattr(obj, "type", "") != "MESH":
            self.report({"ERROR"}, choose_text("Push row was not found.", "Push 行が見つかりません。", context=context))
            return {"CANCELLED"}
        try:
            if getattr(obj, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
        selected = []
        try:
            attribute = mesh.attributes.get(PUSH_COLLIDED_ATTRIBUTE)
            if attribute is None or str(attribute.domain) != "POINT":
                raise RuntimeError("Push collided-vertex attribute is missing")
            selected = [index for index, datum in enumerate(attribute.data) if bool(getattr(datum, "value", False))]
        finally:
            evaluated.to_mesh_clear()
        selected_set = set(selected)
        mesh_data = obj.data
        for vertex in mesh_data.vertices:
            vertex.select = vertex.index in selected_set
        # Face and edge flags win over vertex flags when Edit Mode rebuilds its
        # selection, so they must be replaced for "exactly these vertices".
        for edge in mesh_data.edges:
            edge.select = all(index in selected_set for index in edge.vertices)
        for polygon in mesh_data.polygons:
            polygon.select = all(index in selected_set for index in polygon.vertices)
        try:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode="EDIT")
        except Exception:
            pass
        self.report({"INFO"}, choose_text(f"Selected {len(selected)} collided vertices.", f"衝突頂点を {len(selected)} 個選択しました。", context=context))
        return {"FINISHED"}


CLASSES = (SMSM_OT_max_push_select_collided,)
