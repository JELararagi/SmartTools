# -*- coding: utf-8 -*-
"""Pure XForm semantics and row-state ownership for Smart Modifier.

This module intentionally has no Blender dependency.  The Geometry Nodes builder
uses the same schema, while deterministic no-spawn gates exercise the coordinate
and ownership rules without importing the add-on or starting Blender.
"""

from __future__ import annotations

import math
import uuid


XFORM_SCHEMA_VERSION = 3
XFORM_COORDINATE_MODES = frozenset({"GIZMO", "LOCAL", "WORLD", "REFERENCE_OBJECT"})
XFORM_GROUP_OWNER_MARKER_PROP = 'sms_xform_group_owner_marker'
XFORM_GROUP_OWNER_TOKEN_PROP = 'sms_xform_group_owner_token'
XFORM_GROUP_NODE_NAME_PROP = 'sms_xform_node_group'
XFORM_GROUP_OWNER_MARKER_VALUE = 'SMARTMODIFIER_XFORM_GROUP_OWNER_V1'
# Written only by bind_minted(), on the group itself: the identity of the exact group that was
# created for a row.  A duplicate made by the user carries the copied values, but neither its
# session identity nor its name matches them.
XFORM_GROUP_OWNED_NAME_PROP = 'sms_xform_owned_group_name'
XFORM_GROUP_OWNED_SESSION_PROP = 'sms_xform_owned_group_session'
# Written only by bind_minted(), on the object: {str(modifier.persistent_uid): token}.
# Custom properties of a Geometry Nodes modifier are rebuilt from the node interface on file
# load and on undo, so the row's own copy of the token is lost there; object ID properties and
# the modifier's persistent_uid survive both.
XFORM_OBJECT_OWNED_ROWS_PROP = 'sms_xform_owned_rows'
# Random per-import key: a recorded session identity is only comparable inside this session.
_SESSION_KEY = uuid.uuid4().hex
XFORM_ROW_STATE_KEYS = frozenset({
    "mode",
    "translation",
    "rotation",
    "scale",
    "center",
    "selection_source",
    "selection_name",
    "reference_object",
    "preserve_normals",
    "world_pivot_center",
    "owner_id",
    "state_id",
    "shared_state_id",
})


def _session_identity(group) -> str:
    """Blender session identity of a datablock, keyed to this import of the add-on."""
    try:
        uid = int(getattr(group, "session_uid", 0) or 0)
    except Exception:
        uid = 0
    return f"{_SESSION_KEY}:{uid}" if uid > 0 else ""


def _row_key(modifier) -> str:
    try:
        uid = int(getattr(modifier, "persistent_uid", 0) or 0)
    except Exception:
        uid = 0
    return str(uid) if uid > 0 else ""


def _row_owner(modifier):
    try:
        return getattr(modifier, "id_data", None)
    except Exception:
        return None


def _owned_rows(owner, *, create=False):
    try:
        rows = owner.get(XFORM_OBJECT_OWNED_ROWS_PROP)
        if rows is not None and hasattr(rows, "keys"):
            return rows
        if not create:
            return None
        owner[XFORM_OBJECT_OWNED_ROWS_PROP] = {}
        return owner[XFORM_OBJECT_OWNED_ROWS_PROP]
    except Exception:
        return None


def _recorded_row_token(modifier) -> str:
    key = _row_key(modifier)
    owner = _row_owner(modifier)
    if not key or owner is None:
        return ""
    rows = _owned_rows(owner)
    if rows is None:
        return ""
    try:
        return str(rows.get(key, "") or "")
    except Exception:
        return ""


def _record_row_token(modifier, token) -> bool:
    key = _row_key(modifier)
    owner = _row_owner(modifier)
    if not key or owner is None:
        return False
    rows = _owned_rows(owner, create=True)
    if rows is None:
        return False
    try:
        rows[key] = str(token)
        return True
    except Exception:
        return False


class XFormGroupOwnershipRegistry:
    """Current-execution capabilities for groups created or copied by this add-on."""

    def __init__(self):
        self._entries = {}

    @staticmethod
    def _valid_token(value) -> bool:
        try:
            token = str(value or "")
        except Exception:
            return False
        return len(token) == 32 and all(char in "0123456789abcdef" for char in token)

    def mint(self, group):
        """Mint an unforgeable in-memory capability for a trusted creation operation."""
        if group is None:
            return None
        existing = self._entries.get(id(group))
        if existing is not None and existing.get("group") is group:
            return None
        capability = object()
        token = uuid.uuid4().hex
        try:
            group[XFORM_GROUP_OWNER_MARKER_PROP] = XFORM_GROUP_OWNER_MARKER_VALUE
            group[XFORM_GROUP_OWNER_TOKEN_PROP] = token
        except Exception:
            return None
        self._entries[id(group)] = {
            "group": group,
            "token": token,
            "capability": capability,
            "pending": True,
            "modifiers": {},
        }
        return capability

    def bind_minted(self, group, modifier, capability) -> bool:
        """Consume the exact capability and bind its group to one live modifier."""
        if group is None or modifier is None or capability is None:
            return False
        entry = self._entries.get(id(group))
        if not (
            entry is not None
            and entry.get("group") is group
            and entry.get("pending") is True
            and entry.get("capability") is capability
        ):
            return False
        token = entry.get("token")
        if not self._valid_token(token):
            return False
        try:
            modifier[XFORM_GROUP_OWNER_MARKER_PROP] = XFORM_GROUP_OWNER_MARKER_VALUE
            modifier[XFORM_GROUP_OWNER_TOKEN_PROP] = token
            modifier[XFORM_GROUP_NODE_NAME_PROP] = str(getattr(group, "name", "") or "")
            group[XFORM_GROUP_OWNED_NAME_PROP] = str(getattr(group, "name", "") or "")
            group[XFORM_GROUP_OWNED_SESSION_PROP] = _session_identity(group)
        except Exception:
            return False
        # The durable binding (survives undo and save/reload, unlike the row's own properties).
        _record_row_token(modifier, token)
        entry["pending"] = False
        entry["modifiers"][id(modifier)] = modifier
        return self.is_owned(group, modifier)

    def is_owned(self, group, modifier) -> bool:
        """Ownership proven from the data written by this add-on's own creation path.

        mint() stamps a fresh random token on a group the add-on has just created or
        copied, and only bind_minted() (which needs the in-memory capability returned by
        mint) records the same token for the modifier it was made for (on the object, keyed
        by the modifier's persistent_uid, and on the row itself) and stamps the group's own
        identity on the group.  The check therefore works with fresh Python wrappers, after
        undo and after save/reload.  A group the user made is never owned: it has no token,
        or, when it is a duplicate of ours, it carries the copied token but neither the
        recorded session identity nor the recorded name.  Linked library data is never owned.
        """
        if group is None or modifier is None:
            return False
        try:
            if getattr(group, "library", None) is not None:
                return False
            group_name = str(getattr(group, "name", "") or "")
            group_marker = group.get(XFORM_GROUP_OWNER_MARKER_PROP)
            group_token = str(group.get(XFORM_GROUP_OWNER_TOKEN_PROP, "") or "")
            owned_name = str(group.get(XFORM_GROUP_OWNED_NAME_PROP, "") or "")
            owned_session = str(group.get(XFORM_GROUP_OWNED_SESSION_PROP, "") or "")
            modifier_marker = modifier.get(XFORM_GROUP_OWNER_MARKER_PROP)
            modifier_token = str(modifier.get(XFORM_GROUP_OWNER_TOKEN_PROP, "") or "")
        except Exception:
            return False
        if not (self._valid_token(group_token) and group_marker == XFORM_GROUP_OWNER_MARKER_VALUE):
            return False
        bound = _recorded_row_token(modifier) == group_token or (
            modifier_marker == XFORM_GROUP_OWNER_MARKER_VALUE and modifier_token == group_token
        )
        if not bound:
            return False
        session = _session_identity(group)
        if owned_session and session and owned_session == session:
            return True
        return bool(group_name and owned_name == group_name)

    def release_row(self, modifier) -> None:
        """Drop the durable binding of a row that is being removed."""
        key = _row_key(modifier)
        owner = _row_owner(modifier)
        if not key or owner is None:
            return
        rows = _owned_rows(owner)
        if rows is None:
            return
        try:
            if key in rows.keys():
                del rows[key]
            if not list(rows.keys()):
                del owner[XFORM_OBJECT_OWNED_ROWS_PROP]
        except Exception:
            pass

    def can_remove(self, group, modifier, *, users=None) -> bool:
        if not self.is_owned(group, modifier):
            return False
        try:
            user_count = int(getattr(group, "users", -1) if users is None else users)
        except Exception:
            return False
        return user_count == 0

    def forget(self, group) -> None:
        entry = self._entries.get(id(group)) if group is not None else None
        if entry is not None and entry.get("group") is group:
            self._entries.pop(id(group), None)


class XFormController:
    """Mutable channel block shared only by an explicit instanced copy."""

    def __init__(self, values=None):
        values = dict(values or {})
        self.mode = str(values.get("mode", "GIZMO"))
        self.translation = tuple(values.get("translation", (0.0, 0.0, 0.0)))
        self.rotation = tuple(values.get("rotation", (0.0, 0.0, 0.0)))
        self.scale = tuple(values.get("scale", (1.0, 1.0, 1.0)))
        self.center = tuple(values.get("center", (0.0, 0.0, 0.0)))
        self.selection_source = str(values.get("selection_source", "WHOLE_GEOMETRY"))
        self.selection_name = str(values.get("selection_name", ""))
        self.reference_object = str(values.get("reference_object", ""))
        self.preserve_normals = bool(values.get("preserve_normals", True))
        self.world_pivot_center = bool(values.get("world_pivot_center", True))

    def snapshot(self):
        return {key: getattr(self, key) for key in (
            "mode", "translation", "rotation", "scale", "center",
            "selection_source", "selection_name", "reference_object",
            "preserve_normals", "world_pivot_center",
        )}


class XFormRowModel:
    """Pure ownership model mirroring one ordered Smart Modifier stack row."""

    def __init__(self, *, controller=None, owner_id=None, state_id=None, shared_state_id=""):
        self.controller = controller if controller is not None else XFormController()
        self.owner_id = str(owner_id or uuid.uuid4().hex)
        self.state_id = str(state_id or uuid.uuid4().hex)
        self.shared_state_id = str(shared_state_id or "")


def new_row_model(values=None):
    return XFormRowModel(controller=XFormController(values))


def copy_row_model(row, *, instanced=False):
    if not isinstance(row, XFormRowModel):
        raise TypeError("row must be XFormRowModel")
    if instanced:
        shared = str(row.shared_state_id or row.state_id or uuid.uuid4().hex)
        row.shared_state_id = shared
        return XFormRowModel(controller=row.controller, shared_state_id=shared)
    return XFormRowModel(controller=XFormController(row.controller.snapshot()))


def make_unique_row_model(row):
    if not isinstance(row, XFormRowModel):
        raise TypeError("row must be XFormRowModel")
    return XFormRowModel(controller=XFormController(row.controller.snapshot()))


def _identity():
    return (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )


def _matmul(left, right):
    return tuple(
        tuple(sum(float(left[row][k]) * float(right[k][column]) for k in range(4)) for column in range(4))
        for row in range(4)
    )


def _apply(matrix, point, *, direction=False):
    vector = (float(point[0]), float(point[1]), float(point[2]), 0.0 if direction else 1.0)
    result = tuple(sum(float(matrix[row][column]) * vector[column] for column in range(4)) for row in range(4))
    return result[:3]


def _inverse_affine(matrix):
    a, b, c = (float(matrix[0][0]), float(matrix[0][1]), float(matrix[0][2]))
    d, e, f = (float(matrix[1][0]), float(matrix[1][1]), float(matrix[1][2]))
    g, h, i = (float(matrix[2][0]), float(matrix[2][1]), float(matrix[2][2]))
    determinant = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(determinant) <= 1.0e-12:
        raise ValueError("XForm coordinate matrix is singular")
    reciprocal = 1.0 / determinant
    linear = (
        ((e * i - f * h) * reciprocal, (c * h - b * i) * reciprocal, (b * f - c * e) * reciprocal),
        ((f * g - d * i) * reciprocal, (a * i - c * g) * reciprocal, (c * d - a * f) * reciprocal),
        ((d * h - e * g) * reciprocal, (b * g - a * h) * reciprocal, (a * e - b * d) * reciprocal),
    )
    translation = (float(matrix[0][3]), float(matrix[1][3]), float(matrix[2][3]))
    inverse_translation = tuple(-sum(linear[row][column] * translation[column] for column in range(3)) for row in range(3))
    return tuple(tuple(linear[row]) + (inverse_translation[row],) for row in range(3)) + ((0.0, 0.0, 0.0, 1.0),)


def _translation(value):
    return (
        (1.0, 0.0, 0.0, float(value[0])),
        (0.0, 1.0, 0.0, float(value[1])),
        (0.0, 0.0, 1.0, float(value[2])),
        (0.0, 0.0, 0.0, 1.0),
    )


def _rotation_xyz(value):
    x, y, z = (float(component) for component in value)
    cx, sx = math.cos(x), math.sin(x)
    cy, sy = math.cos(y), math.sin(y)
    cz, sz = math.cos(z), math.sin(z)
    rx = ((1.0, 0.0, 0.0, 0.0), (0.0, cx, -sx, 0.0), (0.0, sx, cx, 0.0), (0.0, 0.0, 0.0, 1.0))
    ry = ((cy, 0.0, sy, 0.0), (0.0, 1.0, 0.0, 0.0), (-sy, 0.0, cy, 0.0), (0.0, 0.0, 0.0, 1.0))
    rz = ((cz, -sz, 0.0, 0.0), (sz, cz, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))
    return _matmul(rz, _matmul(ry, rx))


def _scale(value):
    return (
        (float(value[0]), 0.0, 0.0, 0.0),
        (0.0, float(value[1]), 0.0, 0.0),
        (0.0, 0.0, float(value[2]), 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )


def _basis(mode, object_matrix, reference_matrix, gizmo_matrix):
    normalized = str(mode or "LOCAL").upper()
    if normalized not in XFORM_COORDINATE_MODES:
        raise ValueError(f"Unsupported XForm coordinate mode: {mode!r}")
    if normalized == "LOCAL":
        return _identity()
    if normalized == "WORLD":
        return _inverse_affine(object_matrix)
    if normalized == "REFERENCE_OBJECT":
        return _matmul(_inverse_affine(object_matrix), reference_matrix)
    return gizmo_matrix


def _xform_matrix(translation, rotation, scale, center, basis):
    channels = _matmul(_translation(translation), _matmul(_rotation_xyz(rotation), _scale(scale)))
    centered = _matmul(_translation(center), _matmul(channels, _translation(tuple(-float(value) for value in center))))
    return _matmul(basis, _matmul(centered, _inverse_affine(basis)))


def apply_xform_points(
    points,
    selection,
    translation,
    rotation,
    scale,
    center,
    mode,
    object_matrix,
    reference_matrix,
    gizmo_matrix,
    world_pivot_center,
):
    """Apply one non-destructive XForm row to selected incoming points."""
    basis = _basis(mode, object_matrix, reference_matrix, gizmo_matrix)
    pivot = center
    if str(mode).upper() == "WORLD" and not bool(world_pivot_center):
        pivot = _apply(_inverse_affine(object_matrix), center)
    matrix = _xform_matrix(translation, rotation, scale, pivot, basis)
    mask = tuple(bool(value) for value in selection) if selection is not None else ()
    result = []
    for index, point in enumerate(points):
        selected = True if not mask else (mask[index] if index < len(mask) else False)
        result.append(_apply(matrix, point) if selected else tuple(float(value) for value in point))
    return result


def transform_normals(normals, rotation, scale, mode, object_matrix, reference_matrix, gizmo_matrix):
    """Transform split normals by the inverse transpose of the XForm linear map."""
    basis = _basis(mode, object_matrix, reference_matrix, gizmo_matrix)
    matrix = _xform_matrix((0.0, 0.0, 0.0), rotation, scale, (0.0, 0.0, 0.0), basis)
    inverse = _inverse_affine(matrix)
    inverse_transpose = tuple(tuple(inverse[column][row] for column in range(4)) for row in range(4))
    result = []
    for normal in normals:
        transformed = _apply(inverse_transpose, normal, direction=True)
        length = math.sqrt(sum(value * value for value in transformed))
        result.append(tuple(value / length for value in transformed) if length > 1.0e-12 else (0.0, 0.0, 0.0))
    return result


def new_row_state(*, owner_id=None, shared_state_id=""):
    return {
        "schema_version": XFORM_SCHEMA_VERSION,
        "mode": "GIZMO",
        "translation": (0.0, 0.0, 0.0),
        "rotation": (0.0, 0.0, 0.0),
        "scale": (1.0, 1.0, 1.0),
        "center": (0.0, 0.0, 0.0),
        "selection_source": "WHOLE_GEOMETRY",
        "selection_name": "",
        "reference_object": "",
        "preserve_normals": True,
        "world_pivot_center": True,
        "owner_id": str(owner_id or uuid.uuid4().hex),
        "state_id": uuid.uuid4().hex,
        "shared_state_id": str(shared_state_id or ""),
    }


def migrate_row_state(values):
    """Migrate legacy TRS rows without conflating row identity with node groups."""
    state = new_row_state(owner_id=values.get("owner_id") if values else None)
    source = dict(values or {})
    for key in XFORM_ROW_STATE_KEYS:
        if key in source:
            state[key] = source[key]
    if source.get("use_world_space") and "mode" not in source:
        state["mode"] = "WORLD"
    state["schema_version"] = XFORM_SCHEMA_VERSION
    return state


def copy_row_state(values, *, instanced=False):
    """Independent copies own new state; explicit instances share only controller state."""
    source = migrate_row_state(values)
    copied = dict(source)
    copied["owner_id"] = uuid.uuid4().hex
    copied["state_id"] = uuid.uuid4().hex
    if instanced:
        shared = str(source.get("shared_state_id") or source.get("state_id") or uuid.uuid4().hex)
        source["shared_state_id"] = shared
        copied["shared_state_id"] = shared
    else:
        copied["shared_state_id"] = ""
    return source, copied


def make_unique_row_state(values):
    unique = migrate_row_state(values)
    unique["owner_id"] = uuid.uuid4().hex
    unique["state_id"] = uuid.uuid4().hex
    unique["shared_state_id"] = ""
    return unique
