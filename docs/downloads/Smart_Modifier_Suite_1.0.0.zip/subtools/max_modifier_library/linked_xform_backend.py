"""Linked XForm: bind-space affine controller delta, mesh POINT Boolean mask."""
import math
import bpy
from bpy.props import StringProperty, BoolProperty
from mathutils import Matrix
from ..uv_stack_common import unique_name
from ...translation import choose_text

CONTRACT='sms_linked_xform_affine_v1'
OWNED=set()

def _prune_owned():
    # session_uid is Blender's read-only, session-unique ID, not a recyclable
    # memory address or user-editable ID property. Never retain RNA wrappers.
    OWNED.intersection_update(int(g.session_uid) for g in bpy.data.node_groups)

def _remember_owned(group):
    _prune_owned()
    uid=int(group.session_uid)
    if uid <= 0:raise ValueError(choose_text('Missing Blender session identity', 'Blender のセッション情報がありません'))
    OWNED.add(uid)

def _is_owned(group):
    return int(group.session_uid) in OWNED

def _forget_owned(group):
    OWNED.discard(int(group.session_uid))

def verified(group):
    return group is not None and group.get('sms_linked_contract')==CONTRACT and all(group.get('sms_linked_'+k) for k in ('control','back','mask','use_mask'))

def matrix_check(matrix):
    if not all(math.isfinite(v) for row in matrix for v in row) or abs(matrix.determinant())<1e-9:
        raise ValueError(choose_text('Singular/non-finite transform', '特異・不正な変換です'))

def pack(matrix): return [float(matrix[r][c]) for r in range(4) for c in range(4)]
def unpack(values): return Matrix([list(values)[i:i+4] for i in range(0,16,4)])

def local_matrix(obj,mod):
    g=mod.node_group
    if not verified(g):raise ValueError(choose_text('Legacy Linked XForm conversion unsupported', '旧形式は変換非対応'))
    if not g.get('sms_linked_bound',False):return Matrix.Identity(4)
    control=mod.get(g['sms_linked_control'])
    if control is None:raise ValueError(choose_text('Bound control missing', '制御オブジェクトがありません'))
    matrix_check(control.matrix_world);matrix_check(obj.matrix_world)
    t0=unpack(g['sms_linked_t0']);c0i=unpack(g['sms_linked_c0i']);rest=unpack(g['sms_linked_rest'])
    left=obj.matrix_world.inverted() if bool(mod.get(g['sms_linked_back'],True)) else t0.inverted()
    return left @ control.matrix_world @ c0i @ t0 @ rest

def make_linked_group(obj,defn=None,context=None,*,control=None,rest=None,mask='',back=True):
    if obj is None or obj.type!='MESH':raise ValueError(choose_text('Linked XForm supports Mesh only', 'メッシュのみ対応'))
    t0=obj.matrix_world.copy();matrix_check(t0)
    c0=control.matrix_world.copy() if control else Matrix.Identity(4)
    matrix_check(c0);rest=rest if rest is not None else Matrix.Identity(4)
    g=bpy.data.node_groups.new(unique_name('SMS Linked XForm',bpy.data.node_groups),'GeometryNodeTree')
    try:
        g.is_modifier=True
        def node(kind):return g.nodes.new(kind)
        def link(a,b):g.links.new(a,b)
        def socket(name,kind,default=None):
            s=g.interface.new_socket(name=name,in_out='INPUT',socket_type=kind)
            if default is not None:s.default_value=default
            return s
        socket('Geometry','NodeSocketGeometry');g.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
        for key,name,kind,value in [('control','Control Object','NodeSocketObject',control),('back','Back Transform','NodeSocketBool',back),('mask','Mask','NodeSocketString',mask),('use_mask','Use Mask','NodeSocketBool',bool(mask))]:
            s=socket(name,kind,value);g['sms_linked_'+key]=s.identifier
        inp=node('NodeGroupInput');out=node('NodeGroupOutput');out.is_active_output=True
        def constant(mat):
            n=node('FunctionNodeCombineMatrix')
            for c in range(4):
                for r in range(4):n.inputs[f'Column {c+1} Row {r+1}'].default_value=float(mat[r][c])
            return n.outputs['Matrix']
        def mul(a,b):
            n=node('FunctionNodeMatrixMultiply');link(a,n.inputs[0]);link(b,n.inputs[1]);return n.outputs[0]
        def inv(a):
            n=node('FunctionNodeInvertMatrix');link(a,n.inputs[0]);return n.outputs[0]
        ctrl=node('GeometryNodeObjectInfo');ctrl.transform_space='ORIGINAL';link(inp.outputs['Control Object'],ctrl.inputs['Object'])
        selfobj=node('GeometryNodeSelfObject');target=node('GeometryNodeObjectInfo');target.transform_space='ORIGINAL';link(selfobj.outputs[0],target.inputs['Object'])
        delta=mul(ctrl.outputs['Transform'],constant(c0.inverted()))
        body=mul(mul(delta,constant(t0)),constant(rest))
        on=mul(inv(target.outputs['Transform']),body);off=mul(constant(t0.inverted()),body)
        switch=node('GeometryNodeSwitch');switch.input_type='MATRIX';link(inp.outputs['Back Transform'],switch.inputs['Switch']);link(off,switch.inputs['False']);link(on,switch.inputs['True'])
        transform=switch.outputs['Output'] if control else constant(Matrix.Identity(4))
        pos=node('GeometryNodeInputPosition');move=node('FunctionNodeTransformPoint');link(pos.outputs['Position'],move.inputs[0]);link(transform,move.inputs[1])
        attr=node('GeometryNodeInputNamedAttribute');attr.data_type='BOOLEAN';link(inp.outputs['Mask'],attr.inputs['Name'])
        select=node('GeometryNodeSwitch');select.input_type='BOOLEAN';select.inputs['False'].default_value=True;link(inp.outputs['Use Mask'],select.inputs['Switch']);link(attr.outputs['Attribute'],select.inputs['True'])
        normal=node('GeometryNodeInputNormal');capture=node('GeometryNodeCaptureAttribute');capture.domain='CORNER';capture.capture_items.clear();capture.capture_items.new('VECTOR','Source Normal')
        link(inp.outputs['Geometry'],capture.inputs['Geometry']);link(normal.outputs['Normal'],capture.inputs['Source Normal'])
        setpos=node('GeometryNodeSetPosition');link(capture.outputs['Geometry'],setpos.inputs['Geometry']);link(select.outputs['Output'],setpos.inputs['Selection']);link(move.outputs[0],setpos.inputs['Position'])
        transpose=node('FunctionNodeTransposeMatrix');link(inv(transform),transpose.inputs[0])
        direction=node('FunctionNodeTransformDirection');link(capture.outputs['Source Normal'],direction.inputs[0]);link(transpose.outputs[0],direction.inputs[1])
        normalize=node('ShaderNodeVectorMath');normalize.operation='NORMALIZE';link(direction.outputs[0],normalize.inputs[0])
        choose=node('GeometryNodeSwitch');choose.input_type='VECTOR';link(select.outputs['Output'],choose.inputs['Switch']);link(normal.outputs['Normal'],choose.inputs['False']);link(normalize.outputs['Vector'],choose.inputs['True'])
        setnormal=node('GeometryNodeSetMeshNormal');setnormal.mode='FREE';setnormal.domain='CORNER';link(setpos.outputs['Geometry'],setnormal.inputs['Mesh']);link(choose.outputs['Output'],setnormal.inputs['Custom Normal']);link(setnormal.outputs['Mesh'],out.inputs['Geometry'])
        g['sms_linked_contract']=CONTRACT;g['sms_linked_bound']=control is not None
        g['sms_linked_t0']=pack(t0);g['sms_linked_c0i']=pack(c0.inverted());g['sms_linked_rest']=pack(rest)
        _remember_owned(g)
        return g
    except Exception:
        bpy.data.node_groups.remove(g)
        raise

def cleanup_linked(mod):
    g=getattr(mod,'node_group',None)
    _prune_owned()
    if g is not None and _is_owned(g) and g.users<=1:
        _forget_owned(g);bpy.data.node_groups.remove(g)

class SMSM_OT_linked_xform_bind(bpy.types.Operator):
    bl_idname='smsm.linked_xform_bind'
    bl_label='Bind / Rebind Control'
    bl_options={'UNDO'}
    target_object:StringProperty(name='Target')
    modifier_name:StringProperty(name='Modifier')
    control_object:StringProperty(name='Control Object')
    mask_name:StringProperty(name='Mask')
    back_transform:BoolProperty(name='Back Transform',default=True)
    def invoke(self,context,event):return context.window_manager.invoke_props_dialog(self)
    def draw(self,context):
        self.layout.prop_search(self,'control_object',bpy.data,'objects',text=choose_text('Control Object','制御オブジェクト',context=context))
        self.layout.prop(self,'mask_name',text=choose_text('Mask (point Boolean attribute)','マスク（頂点の Boolean 属性）',context=context))
        self.layout.prop(self,'back_transform',text=choose_text('Back Transform','二重変換を防止',context=context))
    def execute(self,context):
        obj=bpy.data.objects.get(self.target_object);control=bpy.data.objects.get(self.control_object)
        mod=obj.modifiers.get(self.modifier_name) if obj else None
        try:
            if obj is None or obj.type!='MESH' or mod is None or mod.type!='NODES' or not verified(mod.node_group):raise ValueError(choose_text('Unsupported/legacy Linked XForm', '非対応・旧形式'))
            if control is None or control is obj or control not in tuple(context.scene.objects):raise ValueError(choose_text('Choose a separate scene control', '別の制御オブジェクトを選択'))
            parent=control
            while parent is not None:
                if parent is obj:raise ValueError(choose_text('Control dependency cycle', '制御の親子循環'))
                parent=parent.parent
            matrix_check(obj.matrix_world);matrix_check(control.matrix_world)
            if self.mask_name:
                attr=obj.data.attributes.get(self.mask_name)
                if attr is None or attr.domain!='POINT' or attr.data_type!='BOOLEAN':raise ValueError(choose_text('Mask must be POINT Boolean', '頂点Boolean属性が必要'))
            old=mod.node_group
            if old.get('sms_linked_bound') and str(mod.get(old['sms_linked_mask'],'') or '')!=self.mask_name:raise ValueError(choose_text('Rebind mask change unsupported', '再バインドの時はマスクを変更できません'))
            rest=local_matrix(obj,mod)
            fresh=make_linked_group(obj,control=control,rest=rest,mask=self.mask_name,back=self.back_transform)
            try:
                mod.node_group=fresh
                for key,value in [('control',control),('back',self.back_transform),('mask',self.mask_name),('use_mask',bool(self.mask_name))]:mod[fresh['sms_linked_'+key]]=value
            except Exception:
                mod.node_group=old
                _forget_owned(fresh);bpy.data.node_groups.remove(fresh)
                raise
            if _is_owned(old) and old.users==0:
                _forget_owned(old);bpy.data.node_groups.remove(old)
            obj.update_tag();context.view_layer.update()
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}

def draw_linked(layout,mod,obj=None,context=None):
    if not verified(getattr(mod,'node_group',None)):
        layout.label(text=choose_text('This older format cannot be converted','この旧形式は変換できません',context=context),icon='ERROR');return
    g=mod.node_group;obj=obj or mod.id_data
    control=mod.get(g['sms_linked_control'])
    layout.label(text=choose_text('Control: ','制御: ',context=context)+(control.name if control else choose_text('Not bound','未設定',context=context)),translate=False)
    layout.operator_context='INVOKE_DEFAULT'
    op=layout.operator('smsm.linked_xform_bind',text=choose_text('Bind / Rebind Control','制御をバインド / 再バインド',context=context),translate=False);op.target_object=obj.name;op.modifier_name=mod.name
    op.control_object=control.name if control else '';op.mask_name=str(mod.get(g['sms_linked_mask'],'') or '')
    op.back_transform=bool(mod.get(g['sms_linked_back'],True))
    layout.prop(mod,'["'+g['sms_linked_back']+'"]',text=choose_text('Back Transform','二重変換を防止',context=context))
    layout.label(text=choose_text('Mask: ','マスク: ',context=context)+(str(mod.get(g['sms_linked_mask'],'') or '') or choose_text('None','なし',context=context)),translate=False)

CLASSES=(SMSM_OT_linked_xform_bind,)

def forget_session_ownership():
    # Disable releases Python references, never deletes saved or foreign data.
    OWNED.clear()
