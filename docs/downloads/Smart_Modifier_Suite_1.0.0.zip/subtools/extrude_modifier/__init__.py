# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for extrude_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "extrude_modifier"
PLUGIN_LABEL = "Smart Extrude Modifier"
OPERATOR_ID = "smsa.smart_extrude_clean"
PLUGIN_ICON = "MESH_DATA"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
