# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import bpy 
from ...user_plugins import register_simple_plugin ,unregister_simple_plugin 

PLUGIN_ID ="pivot_to_selection_modifier"
PLUGIN_LABEL ='Pivot To Selection Modifier'
OPERATOR_ID ="smsp.pivot_to_selection"
PLUGIN_ICON ="PIVOT_CURSOR"

def register_embedded ():
    register_simple_plugin (PLUGIN_ID ,PLUGIN_LABEL ,OPERATOR_ID ,PLUGIN_ICON )

def unregister_embedded ():
    unregister_simple_plugin (PLUGIN_ID )
