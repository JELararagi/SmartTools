# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for workplane_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "workplane_modifier"
PLUGIN_LABEL = "Workplane Modifier"
OPERATOR_ID = "smsp.workplane_from_active"
PLUGIN_ICON = "EMPTY_ARROWS"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
