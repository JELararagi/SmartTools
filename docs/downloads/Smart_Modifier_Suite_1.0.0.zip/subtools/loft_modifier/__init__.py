# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Modifier embedded entry for loft_modifier."""

from .._embedded import embedded_entry


PLUGIN_ID = "loft_modifier"
PLUGIN_LABEL = "Loft Modifier"
OPERATOR_ID = "smsp.loft_bridge_paths"
PLUGIN_ICON = "SURFACE_NCURVE"
register_embedded, unregister_embedded = embedded_entry(
    PLUGIN_ID, PLUGIN_LABEL, OPERATOR_ID, PLUGIN_ICON,
)
