# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Choose the user-facing language and translate labels via Blender catalogs."""
from functools import cache
from importlib import import_module
import re

try:
    import bpy
except ImportError:
    bpy = None

_JAPANESE = re.compile("[ぁ-んァ-ヴ一-龠々ー]")


def contains_japanese(text):
    return _JAPANESE.search(str(text or "")) is not None


def ui_language(context=None):
    if context is None:
        context = getattr(bpy, "context", None)
    view = getattr(getattr(context, "preferences", None), "view", None)
    if not getattr(view, "use_translate_interface", False):
        return "en"
    language = str(getattr(view, "language", "") or "")
    return "ja" if language.casefold().startswith("ja") else "en"


def choose_text(en="", ja="", context=None):
    translated = (str(en or "").strip(), str(ja or "").strip())
    index = int(ui_language(context) == "ja")
    return translated[index] or translated[1 - index]


def split_bilingual_text(text):
    label = str(text or "").strip()
    fragments = label.split(" / ")
    boundaries = [
        (" / ".join(fragments[:i]).strip(), " / ".join(fragments[i:]).strip())
        for i in range(len(fragments) - 1, 0, -1)
    ]
    for reverse in (False, True):
        for pair in boundaries:
            english, japanese = pair[::-1] if reverse else pair
            if english and japanese and not contains_japanese(english) and contains_japanese(japanese):
                return english, japanese
    return label, ""


def localize_inline_bilingual(text, context=None):
    english, japanese = split_bilingual_text(text)
    return choose_text(english, japanese, context)


@cache
def _japanese_catalog():
    phrases = {}
    for name in ("translation_catalog", "translation_generated"):
        try:
            module = import_module(f".{name}", __package__)
        except ImportError:
            continue
        messages = getattr(module, "translation_catalog_dict", {}).get("ja_JP", {})
        for key, result in messages.items():
            if isinstance(key, tuple) and len(key) == 2 and isinstance(key[1], str):
                phrases[key[1]] = str(result)
    return phrases


def _lookup(text, context, method):
    message = localize_inline_bilingual(text, context)
    if bpy is not None:
        try:
            native = getattr(bpy.app.translations, method)(message)
        except (AttributeError, TypeError, RuntimeError, ValueError):
            native = message
        if native != message:
            return native
    if ui_language(context) == "ja":
        return _japanese_catalog().get(message, message)
    return message


def pgettext_iface(text, context=None):
    return _lookup(text, context, "pgettext_iface")


def pgettext(text, context=None):
    return _lookup(text, context, "pgettext")
