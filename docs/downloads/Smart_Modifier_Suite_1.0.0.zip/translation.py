# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

from __future__ import annotations

import re

try:
    import bpy
except Exception:  # pragma: no cover - Blender runtime only
    bpy = None

_JP_RE = re.compile(r'[ぁ-んァ-ヴ一-龠々ー]')
_FALLBACK_JA_TABLE: dict[str, str] | None = None


def contains_japanese(text: str | None) -> bool:
    return bool(_JP_RE.search(str(text or '')))


def ui_language(context=None) -> str:
    prefs_view = None
    try:
        ctx = context if context is not None else getattr(bpy, 'context', None)
        prefs_view = getattr(getattr(ctx, 'preferences', None), 'view', None)
    except Exception:
        prefs_view = None
    if prefs_view is None:
        return 'en'
    try:
        if not bool(getattr(prefs_view, 'use_translate_interface', True)):
            return 'en'
    except Exception:
        pass
    try:
        lang = str(getattr(prefs_view, 'language', '') or '')
    except Exception:
        lang = ''
    return 'ja' if lang.lower().startswith('ja') else 'en'


def choose_text(en: str | None = '', ja: str | None = '', context=None) -> str:
    en_text = str(en or '').strip()
    ja_text = str(ja or '').strip()
    if ui_language(context) == 'ja':
        return ja_text or en_text
    return en_text or ja_text


def split_bilingual_text(text: str | None) -> tuple[str, str]:
    raw = str(text or '').strip()
    if not raw:
        return '', ''
    if ' / ' not in raw or not contains_japanese(raw):
        return raw, ''

    indexes = []
    start = 0
    while True:
        idx = raw.find(' / ', start)
        if idx == -1:
            break
        indexes.append(idx)
        start = idx + 3

    for idx in reversed(indexes):
        left = raw[:idx].strip()
        right = raw[idx + 3:].strip()
        if left and right and (not contains_japanese(left)) and contains_japanese(right):
            return left, right

    for idx in reversed(indexes):
        left = raw[:idx].strip()
        right = raw[idx + 3:].strip()
        if left and right and contains_japanese(left) and (not contains_japanese(right)):
            return right, left

    return raw, ''


def localize_inline_bilingual(text: str | None, context=None) -> str:
    en, ja = split_bilingual_text(text)
    if ja:
        return choose_text(en, ja, context=context)
    return en


def _fallback_ja_table() -> dict[str, str]:
    """Return the root Japanese translation_catalog table for deterministic fallback.

    Blender normally translates registered UI strings itself.  Some Smart Tools
    panels are generated lazily or through proxy classes, so a small local
    fallback prevents English-only labels/tooltips while the deferred modules are
    being registered.  Only msgid -> Japanese text is stored here; English output
    is never affected.
    """
    global _FALLBACK_JA_TABLE
    if _FALLBACK_JA_TABLE is not None:
        return _FALLBACK_JA_TABLE
    table: dict[str, str] = {}
    for module_name in ('translation_catalog', 'translation_generated'):
        try:
            module = __import__(f'{__package__}.{module_name}', fromlist=['translation_catalog_dict'])
            raw = getattr(module, 'translation_catalog_dict', {})
            ja = raw.get('ja_JP', {}) if isinstance(raw, dict) else {}
            if isinstance(ja, dict):
                for key, value in ja.items():
                    if isinstance(key, tuple) and len(key) == 2 and isinstance(key[1], str):
                        table[key[1]] = str(value)
        except Exception:
            continue
    _FALLBACK_JA_TABLE = table
    return table


def _fallback_translate_ja(msg: str, context=None) -> str:
    if ui_language(context) != 'ja':
        return msg
    return _fallback_ja_table().get(msg, msg)


def pgettext_iface(text: str | None, context=None) -> str:
    msg = localize_inline_bilingual(text, context=context)
    if bpy is None:
        return _fallback_translate_ja(msg, context=context)
    try:
        translated = bpy.app.translations.pgettext_iface(msg)
    except Exception:
        translated = msg
    if translated == msg:
        return _fallback_translate_ja(msg, context=context)
    return translated


def pgettext(text: str | None, context=None) -> str:
    msg = localize_inline_bilingual(text, context=context)
    if bpy is None:
        return _fallback_translate_ja(msg, context=context)
    try:
        translated = bpy.app.translations.pgettext(msg)
    except Exception:
        translated = msg
    if translated == msg:
        return _fallback_translate_ja(msg, context=context)
    return translated
