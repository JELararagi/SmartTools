# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass, field
import math
import uuid
from typing import Iterable

import bpy
from bpy.app.translations import pgettext_iface as iface_
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from mathutils import Matrix, Vector

try:
    import bmesh
except Exception:  # pragma: no cover - bmesh is available inside Blender.
    bmesh = None

bl_info = {
    "name": "Drag Clone",
    "author": "JELararagi",
    "version": (1, 4, 8),
    "blender": (5, 1, 0),
    "location": "View3D: manually registered shortcut, typically Shift + Left Drag",
    "description": "Clone the current selection at left-drag start, then transform the clone directly while dragging.",
    "category": "3D View",
}

PACKAGE_ID = "max_shift_drag_clone"
ADDON_ID = f"{__package__}.max_shift_drag_clone" if __package__ else __name__
_TRANSLATION_CONTEXT = "*"
_addon_keymaps: list[tuple[bpy.types.KeyMap, bpy.types.KeyMapItem]] = []
_MSDC_MODAL_ACTIVE = False
_MSDC_WATCHER_ENABLED = False
_MSDC_WATCHER_RUNNING = False
_MSDC_FORCE_START = False
_PENDING_CONFIRM_SESSIONS: dict[str, object] = {}
_DRAG_START_PIXELS = 5

_TRIGGER_KEY_DESCRIPTION = "Require this keyboard key in addition to any enabled modifier keys after Drag Clone is invoked from a manually registered keymap item and before starting the clone with left-drag. This lets you keep Shift and Ctrl available for Blender transform precision and snapping after the clone starts."
_TRIGGER_KEY_ITEMS = (
    ("NONE", "No Extra Key", "Start the clone with only the enabled modifier keys plus left-drag after you manually assign this operator in Blender Preferences > Keymap. The add-on never creates keymap items automatically."),
    ("A", "A", _TRIGGER_KEY_DESCRIPTION), ("B", "B", _TRIGGER_KEY_DESCRIPTION), ("C", "C", _TRIGGER_KEY_DESCRIPTION),
    ("D", "D", _TRIGGER_KEY_DESCRIPTION), ("E", "E", _TRIGGER_KEY_DESCRIPTION), ("F", "F", _TRIGGER_KEY_DESCRIPTION),
    ("G", "G", _TRIGGER_KEY_DESCRIPTION), ("H", "H", _TRIGGER_KEY_DESCRIPTION), ("I", "I", _TRIGGER_KEY_DESCRIPTION),
    ("J", "J", _TRIGGER_KEY_DESCRIPTION), ("K", "K", _TRIGGER_KEY_DESCRIPTION), ("L", "L", _TRIGGER_KEY_DESCRIPTION),
    ("M", "M", _TRIGGER_KEY_DESCRIPTION), ("N", "N", _TRIGGER_KEY_DESCRIPTION), ("O", "O", _TRIGGER_KEY_DESCRIPTION),
    ("P", "P", _TRIGGER_KEY_DESCRIPTION), ("Q", "Q", _TRIGGER_KEY_DESCRIPTION), ("R", "R", _TRIGGER_KEY_DESCRIPTION),
    ("S", "S", _TRIGGER_KEY_DESCRIPTION), ("T", "T", _TRIGGER_KEY_DESCRIPTION), ("U", "U", _TRIGGER_KEY_DESCRIPTION),
    ("V", "V", _TRIGGER_KEY_DESCRIPTION), ("W", "W", _TRIGGER_KEY_DESCRIPTION), ("X", "X", _TRIGGER_KEY_DESCRIPTION),
    ("Y", "Y", _TRIGGER_KEY_DESCRIPTION), ("Z", "Z", _TRIGGER_KEY_DESCRIPTION),
    ("ZERO", "0", _TRIGGER_KEY_DESCRIPTION), ("ONE", "1", _TRIGGER_KEY_DESCRIPTION), ("TWO", "2", _TRIGGER_KEY_DESCRIPTION),
    ("THREE", "3", _TRIGGER_KEY_DESCRIPTION), ("FOUR", "4", _TRIGGER_KEY_DESCRIPTION), ("FIVE", "5", _TRIGGER_KEY_DESCRIPTION),
    ("SIX", "6", _TRIGGER_KEY_DESCRIPTION), ("SEVEN", "7", _TRIGGER_KEY_DESCRIPTION), ("EIGHT", "8", _TRIGGER_KEY_DESCRIPTION),
    ("NINE", "9", _TRIGGER_KEY_DESCRIPTION),
    ("SPACE", "Space", _TRIGGER_KEY_DESCRIPTION), ("TAB", "Tab", _TRIGGER_KEY_DESCRIPTION), ("RET", "Enter", _TRIGGER_KEY_DESCRIPTION),
    ("BACK_SPACE", "Backspace", _TRIGGER_KEY_DESCRIPTION), ("DEL", "Delete", _TRIGGER_KEY_DESCRIPTION), ("ESC", "Escape", _TRIGGER_KEY_DESCRIPTION),
    ("INSERT", "Insert", _TRIGGER_KEY_DESCRIPTION), ("HOME", "Home", _TRIGGER_KEY_DESCRIPTION), ("END", "End", _TRIGGER_KEY_DESCRIPTION),
    ("PAGE_UP", "Page Up", _TRIGGER_KEY_DESCRIPTION), ("PAGE_DOWN", "Page Down", _TRIGGER_KEY_DESCRIPTION),
    ("LEFT_ARROW", "Left Arrow", _TRIGGER_KEY_DESCRIPTION), ("RIGHT_ARROW", "Right Arrow", _TRIGGER_KEY_DESCRIPTION),
    ("UP_ARROW", "Up Arrow", _TRIGGER_KEY_DESCRIPTION), ("DOWN_ARROW", "Down Arrow", _TRIGGER_KEY_DESCRIPTION),
    ("SEMI_COLON", ";", _TRIGGER_KEY_DESCRIPTION), ("PERIOD", ".", _TRIGGER_KEY_DESCRIPTION), ("COMMA", ",", _TRIGGER_KEY_DESCRIPTION),
    ("QUOTE", "Quote", _TRIGGER_KEY_DESCRIPTION), ("ACCENT_GRAVE", "Backquote", _TRIGGER_KEY_DESCRIPTION),
    ("MINUS", "-", _TRIGGER_KEY_DESCRIPTION), ("PLUS", "+", _TRIGGER_KEY_DESCRIPTION), ("SLASH", "/", _TRIGGER_KEY_DESCRIPTION),
    ("BACK_SLASH", "\\", _TRIGGER_KEY_DESCRIPTION), ("EQUAL", "=", _TRIGGER_KEY_DESCRIPTION),
    ("LEFT_BRACKET", "[", _TRIGGER_KEY_DESCRIPTION), ("RIGHT_BRACKET", "]", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_0", "Numpad 0", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_1", "Numpad 1", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_2", "Numpad 2", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_3", "Numpad 3", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_4", "Numpad 4", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_5", "Numpad 5", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_6", "Numpad 6", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_7", "Numpad 7", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_8", "Numpad 8", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_9", "Numpad 9", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_PERIOD", "Numpad .", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_SLASH", "Numpad /", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_ASTERIX", "Numpad *", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_MINUS", "Numpad -", _TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_PLUS", "Numpad +", _TRIGGER_KEY_DESCRIPTION), ("NUMPAD_ENTER", "Numpad Enter", _TRIGGER_KEY_DESCRIPTION),
    ("F1", "F1", _TRIGGER_KEY_DESCRIPTION), ("F2", "F2", _TRIGGER_KEY_DESCRIPTION), ("F3", "F3", _TRIGGER_KEY_DESCRIPTION),
    ("F4", "F4", _TRIGGER_KEY_DESCRIPTION), ("F5", "F5", _TRIGGER_KEY_DESCRIPTION), ("F6", "F6", _TRIGGER_KEY_DESCRIPTION),
    ("F7", "F7", _TRIGGER_KEY_DESCRIPTION), ("F8", "F8", _TRIGGER_KEY_DESCRIPTION), ("F9", "F9", _TRIGGER_KEY_DESCRIPTION),
    ("F10", "F10", _TRIGGER_KEY_DESCRIPTION), ("F11", "F11", _TRIGGER_KEY_DESCRIPTION), ("F12", "F12", _TRIGGER_KEY_DESCRIPTION),
    ("F13", "F13", _TRIGGER_KEY_DESCRIPTION), ("F14", "F14", _TRIGGER_KEY_DESCRIPTION), ("F15", "F15", _TRIGGER_KEY_DESCRIPTION),
    ("F16", "F16", _TRIGGER_KEY_DESCRIPTION), ("F17", "F17", _TRIGGER_KEY_DESCRIPTION), ("F18", "F18", _TRIGGER_KEY_DESCRIPTION),
    ("F19", "F19", _TRIGGER_KEY_DESCRIPTION), ("F20", "F20", _TRIGGER_KEY_DESCRIPTION), ("F21", "F21", _TRIGGER_KEY_DESCRIPTION),
    ("F22", "F22", _TRIGGER_KEY_DESCRIPTION), ("F23", "F23", _TRIGGER_KEY_DESCRIPTION), ("F24", "F24", _TRIGGER_KEY_DESCRIPTION),
    ("PAUSE", "Pause", _TRIGGER_KEY_DESCRIPTION), ("APP", "Application", _TRIGGER_KEY_DESCRIPTION), ("GRLESS", "Grless", _TRIGGER_KEY_DESCRIPTION),
)
_TRIGGER_KEY_IDS = {item[0] for item in _TRIGGER_KEY_ITEMS}


# -----------------------------------------------------------------------------
# Add-on preferences and translation helpers


def _get_settings():
    try:
        from . import preferences as _sms_preferences
        return _sms_preferences.get_preferences(getattr(bpy, "context", None))
    except Exception:
        return None


def _iface(message: str) -> str:
    return iface_(message)


def _refresh_keymaps(_self=None, _context=None) -> None:
    refresh_keymaps(_context)




def _drag_shortcut_enabled() -> bool:
    """Return True for manually registered Drag Clone keymap invocations.

    Smart Modifier no longer uses N-panel trigger-key properties to decide
    whether Drag Clone may run.  Blender's manually registered keymap item is
    the single source of truth for the key/mouse combination.
    """
    return True


def _active_tool_is_selection_tool(context: bpy.types.Context) -> bool:
    """Return True while Blender's native selection tools own left-drag events."""
    try:
        area = getattr(context, "area", None)
        if area is not None and str(getattr(area, "type", "")) != "VIEW_3D":
            return False
        workspace = getattr(context, "workspace", None)
        if workspace is None:
            return False
        mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")
        tool = workspace.tools.from_space_view3d_mode(mode, create=False)
        tool_id = str(getattr(tool, "idname", "") or "").lower()
        return tool_id in {
            "builtin.select",
            "builtin.select_box",
            "builtin.select_circle",
            "builtin.select_lasso",
        } or tool_id.startswith("builtin.select_")
    except Exception:
        return False


def _keymap_name_is_selection_tool(name: str) -> bool:
    n = str(name or "").lower()
    return n.startswith("3d view tool:") and ("select" in n or "tweak" in n)

def _event_matches_preferences(_context: bpy.types.Context, _event: bpy.types.Event) -> bool:
    """Trust Blender's manually registered keymap item.

    The add-on must not expose or maintain a second N-panel shortcut trigger.
    If Blender invokes this operator from a user keymap, the operator handles
    that event and temporarily suppresses its own keymap entries only while the
    modal drag is active.
    """
    return _drag_shortcut_enabled()


def _event_modifier_matches_keymap_spec(event: bpy.types.Event, spec: _ManualDragKeySpec) -> bool:
    try:
        if bool(getattr(spec, "any_modifier", False)):
            return True
        return (
            bool(getattr(event, "shift", False)) == bool(getattr(spec, "shift", False))
            and bool(getattr(event, "ctrl", False)) == bool(getattr(spec, "ctrl", False))
            and bool(getattr(event, "alt", False)) == bool(getattr(spec, "alt", False))
            and bool(getattr(event, "oskey", False)) == bool(getattr(spec, "oskey", False))
        )
    except Exception:
        return False


def _manual_drag_clone_key_modifier_specs() -> tuple[_ManualDragKeySpec, ...]:
    """Read manual normal-key + left-drag Drag Clone keymaps without creating keymaps.

    Blender can let a regular key binding such as C / Circle Select enter its own
    modal handler before a C + left-drag key-modifier item reaches this operator.
    This read-only scan lets the event watcher latch only normal keys the user
    has explicitly registered for Drag Clone.  No Blender preference keymap item
    is created, removed, or rewritten by this function.
    """
    specs: list[_ManualDragKeySpec] = []
    seen: set[tuple] = set()
    try:
        wm = bpy.context.window_manager
        keyconfigs = getattr(wm, "keyconfigs", None)
        if keyconfigs is None:
            return ()
        # Manual edits live in the user keyconfig.  The active keyconfig is also
        # scanned because Blender may expose merged user entries there depending
        # on startup state.  The add-on keyconfig is intentionally ignored: this
        # add-on must not resurrect older automatic entries.
        for keyconfig_name in ("user", "active"):
            keyconfig = getattr(keyconfigs, keyconfig_name, None)
            if keyconfig is None:
                continue
            for km in list(getattr(keyconfig, "keymaps", []) or []):
                try:
                    if str(getattr(km, "space_type", "")) not in {"VIEW_3D", "EMPTY"}:
                        continue
                except Exception:
                    continue
                for kmi in list(getattr(km, "keymap_items", []) or []):
                    try:
                        if str(getattr(kmi, "idname", "") or "") != MSDC_OT_drag_clone.bl_idname:
                            continue
                        if not bool(getattr(kmi, "active", True)):
                            continue
                        key_modifier = str(getattr(kmi, "key_modifier", "NONE") or "NONE")
                        if key_modifier == "NONE" or not _event_type_is_keyboard(key_modifier):
                            continue
                        mouse_type = str(getattr(kmi, "type", "") or "")
                        mouse_value = str(getattr(kmi, "value", "") or "")
                        if mouse_type not in {"LEFTMOUSE", "EVT_TWEAK_L"}:
                            continue
                        if mouse_value not in {"PRESS", "CLICK_DRAG", "ANY", "NOTHING"}:
                            continue
                        spec = _ManualDragKeySpec(
                            key_modifier=key_modifier,
                            mouse_type=mouse_type,
                            mouse_value=mouse_value,
                            direction=str(getattr(kmi, "direction", "ANY") or "ANY"),
                            shift=bool(getattr(kmi, "shift", False)),
                            ctrl=bool(getattr(kmi, "ctrl", False)),
                            alt=bool(getattr(kmi, "alt", False)),
                            oskey=bool(getattr(kmi, "oskey", False)),
                            any_modifier=bool(getattr(kmi, "any", False)),
                        )
                        marker = (
                            spec.key_modifier, spec.mouse_type, spec.mouse_value, spec.direction,
                            spec.shift, spec.ctrl, spec.alt, spec.oskey, spec.any_modifier,
                        )
                        if marker in seen:
                            continue
                        seen.add(marker)
                        specs.append(spec)
                    except Exception:
                        continue
    except Exception as exc:
        _safe_log(f"manual keymap scan failed: {exc}")
    return tuple(specs)


def _manual_drag_clone_key_modifier_available() -> bool:
    try:
        return bool(_manual_drag_clone_key_modifier_specs())
    except Exception:
        return False


def _event_matches_manual_drag_mouse_spec(event: bpy.types.Event, spec: _ManualDragKeySpec) -> bool:
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
        if spec.mouse_type == "EVT_TWEAK_L":
            if event_type != "EVT_TWEAK_L":
                return False
        elif event_type not in {"LEFTMOUSE", "EVT_TWEAK_L"}:
            return False
        if spec.mouse_value == "CLICK_DRAG":
            if not _event_is_left_drag_start(event):
                return False
        elif spec.mouse_value == "PRESS":
            if not (event_type == "LEFTMOUSE" and event_value == "PRESS"):
                return False
        elif spec.mouse_value not in {"ANY", "NOTHING"}:
            return False
        if not _event_modifier_matches_keymap_spec(event, spec):
            return False
        return True
    except Exception:
        return False


def _trigger_key() -> str:
    """Legacy compatibility hook.  Drag Clone no longer has an N-panel trigger key."""
    return "NONE"


def _keymap_modifiers() -> dict[str, bool | str]:
    prefs = _get_settings()
    modifiers: dict[str, bool | str] = {
        "shift": False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_shift", False)),
        "ctrl": False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_ctrl", False)),
        "alt": False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_alt", False)),
        "oskey": False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_oskey", False)),
    }
    trigger_key = _trigger_key()
    if trigger_key != "NONE":
        modifiers["key_modifier"] = trigger_key
    return modifiers


def _keymap_modifier_variants(*, include_key_modifier: bool = True) -> tuple[dict[str, bool | str], ...]:
    """Return keymap modifier variants for the current drag-clone shortcut.

    For dedicated trigger keys such as F6, Shift and Ctrl should be transform
    modifiers, not blockers.  Blender keymap items treat ``shift=False`` and
    ``ctrl=False`` as strict requirements, so register additional variants when
    those keys are not explicitly part of the trigger.
    """
    prefs = _get_settings()
    trigger_key = _trigger_key()
    if trigger_key == "NONE":
        base = _keymap_modifiers()
        if not include_key_modifier:
            base = {k: v for k, v in base.items() if k != "key_modifier"}
        return (base,)

    use_shift = False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_shift", False))
    use_ctrl = False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_ctrl", False))
    use_alt = False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_alt", False))
    use_oskey = False if prefs is None else bool(getattr(prefs, "shift_drag_clone_use_oskey", False))

    shift_values = (True,) if use_shift else (False, True)
    ctrl_values = (True,) if use_ctrl else (False, True)
    variants: list[dict[str, bool | str]] = []
    seen: set[tuple[tuple[str, str], ...]] = set()
    for shift_state in shift_values:
        for ctrl_state in ctrl_values:
            modifiers: dict[str, bool | str] = {
                "shift": bool(shift_state),
                "ctrl": bool(ctrl_state),
                "alt": bool(use_alt),
                "oskey": bool(use_oskey),
            }
            if include_key_modifier:
                modifiers["key_modifier"] = trigger_key
            marker = tuple(sorted((str(k), str(v)) for k, v in modifiers.items()))
            if marker in seen:
                continue
            seen.add(marker)
            variants.append(modifiers)
    return tuple(variants)


def _default_clone_type() -> str:
    prefs = _get_settings()
    return "COPY" if prefs is None else str(getattr(prefs, "shift_drag_clone_default_clone_type", "COPY"))


def _default_copy_count() -> int:
    prefs = _get_settings()
    return 1 if prefs is None else int(getattr(prefs, "shift_drag_clone_default_copy_count", 1))


def _transform_source() -> str:
    prefs = _get_settings()
    return "AUTO" if prefs is None else str(getattr(prefs, "shift_drag_clone_transform_source", "AUTO"))


# -----------------------------------------------------------------------------
# Active tool and transform dispatch


def _active_tool_id(context: bpy.types.Context, space_type: str = "VIEW_3D") -> str:
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        return ""
    tools = getattr(workspace, "tools", None)
    if tools is None:
        return ""

    mode = getattr(context, "mode", "OBJECT") or "OBJECT"

    try:
        if space_type == "VIEW_3D" and hasattr(tools, "from_space_view3d_mode"):
            tool = tools.from_space_view3d_mode(mode, create=False)
            return "" if tool is None else getattr(tool, "idname", "")
    except TypeError:
        try:
            tool = tools.from_space_view3d_mode(mode)
            return "" if tool is None else getattr(tool, "idname", "")
        except Exception:
            pass
    except Exception:
        pass

    # Blender 4.x compatibility fallback. Blender 5.1 uses from_space_view3d_mode.
    try:
        if hasattr(tools, "from_space_type"):
            tool = tools.from_space_type(space_type, mode=mode, create=False)
            return "" if tool is None else getattr(tool, "idname", "")
    except TypeError:
        try:
            tool = tools.from_space_type(space_type, mode=mode)
            return "" if tool is None else getattr(tool, "idname", "")
        except Exception:
            pass
    except Exception:
        pass

    return ""


def _resolve_transform_kind(context: bpy.types.Context) -> str:
    source = _transform_source()
    if source in {"TRANSLATE", "ROTATE", "SCALE"}:
        return source

    area_type = "" if context.area is None else context.area.type
    if area_type != "VIEW_3D":
        return "TRANSLATE"

    # When the optional trigger key itself is one of Blender's standard transform
    # shortcuts, keep that meaning.  This lets a configured G/R/S + left-drag clone
    # start Move/Rotate/Scale like the standard or Smart G/R/S workflow.
    trigger = _trigger_key()
    if trigger == "G":
        return "TRANSLATE"
    if trigger == "R":
        return "ROTATE"
    if trigger == "S":
        return "SCALE"

    tool_id = _active_tool_id(context, "VIEW_3D").lower()
    if "rotate" in tool_id:
        return "ROTATE"
    if "scale" in tool_id or "resize" in tool_id:
        return "SCALE"
    if "move" in tool_id or "translate" in tool_id:
        return "TRANSLATE"
    return "TRANSLATE"


def _view3d_window_region_and_data(context: bpy.types.Context):
    area = getattr(context, "area", None)
    if area is None or getattr(area, "type", "") != "VIEW_3D":
        return None, None
    region = getattr(context, "region", None)
    if region is None or getattr(region, "type", "") != "WINDOW":
        try:
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
        except Exception:
            region = None
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return None, None
    return region, rv3d


def _selected_transform_center(context: bpy.types.Context) -> Vector | None:
    try:
        pivot = str(getattr(getattr(context, "scene", None).tool_settings, "transform_pivot_point", "") or "")
    except Exception:
        pivot = ""
    if pivot == "CURSOR":
        try:
            return getattr(context.scene, "cursor").location.copy()
        except Exception:
            pass

    # Edit Mesh needs the component center.  Object origins alone make gizmo-axis
    # hit detection unreliable when the edited elements are away from the origin.
    try:
        mode = str(getattr(context, "mode", "") or "")
        obj = getattr(context, "active_object", None)
        if mode == "EDIT_MESH" and obj is not None and getattr(obj, "type", "") == "MESH" and bmesh is not None:
            bm = bmesh.from_edit_mesh(obj.data)
            points = [obj.matrix_world @ v.co for v in bm.verts if bool(getattr(v, "select", False))]
            if points:
                center = Vector((0.0, 0.0, 0.0))
                for p in points:
                    center += p
                return center / max(1, len(points))
    except Exception:
        pass

    objects = []
    try:
        objects = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        objects = []
    if objects:
        try:
            center = Vector((0.0, 0.0, 0.0))
            for obj in objects:
                center += obj.matrix_world.translation
            return center / max(1, len(objects))
        except Exception:
            pass
    obj = getattr(context, "active_object", None)
    if obj is not None:
        try:
            return obj.matrix_world.translation.copy()
        except Exception:
            pass
    return None


def _orientation_axis_matrix(context: bpy.types.Context) -> Matrix:
    orientation = "GLOBAL"
    try:
        slots = getattr(getattr(context, "scene", None), "transform_orientation_slots", None)
        if slots:
            orientation = str(getattr(slots[0], "type", "GLOBAL") or "GLOBAL").upper()
    except Exception:
        orientation = "GLOBAL"
    obj = getattr(context, "active_object", None)
    try:
        if orientation == "LOCAL" and obj is not None:
            return obj.matrix_world.to_3x3().normalized().to_4x4()
        if orientation == "VIEW":
            rv3d = getattr(context, "region_data", None)
            if rv3d is not None:
                return rv3d.view_matrix.inverted().to_3x3().normalized().to_4x4()
        if orientation == "CURSOR":
            cursor = getattr(getattr(context, "scene", None), "cursor", None)
            if cursor is not None:
                return cursor.matrix.to_3x3().normalized().to_4x4()
    except Exception:
        pass
    return Matrix.Identity(4)


def _selection_scale_for_gizmo_probe(context: bpy.types.Context) -> float:
    values = []
    try:
        for obj in list(getattr(context, "selected_objects", []) or []):
            try:
                dim = getattr(obj, "dimensions", None)
                if dim is not None:
                    values.append(max(float(dim.x), float(dim.y), float(dim.z)))
            except Exception:
                pass
    except Exception:
        pass
    try:
        rv3d = getattr(context, "region_data", None)
        dist = float(getattr(rv3d, "view_distance", 0.0) or 0.0)
        if dist > 0.0:
            values.append(dist * 0.18)
    except Exception:
        pass
    values = [v for v in values if v and v > 1.0e-6]
    return max(0.25, min(max(values) if values else 1.0, 1000.0))


def _point_segment_distance_2d(point: Vector, start: Vector, end: Vector) -> tuple[float, float]:
    delta = end - start
    denom = float(delta.length_squared)
    if denom <= 1.0e-8:
        return float((point - start).length), 0.0
    t = max(0.0, min(1.0, float((point - start).dot(delta) / denom)))
    closest = start + delta * t
    return float((point - closest).length), t


def _axis_constraint_from_drag_origin(context: bpy.types.Context, event: bpy.types.Event, transform_kind: str) -> tuple[bool, bool, bool] | None:
    """Infer a clicked gizmo axis from the initial mouse position.

    Blender does not expose the exact standard-gizmo or third-party smart-gizmo
    handle that was clicked once this add-on has intercepted the shortcut.  To
    keep axis-constrained dragging usable, the add-on samples the current 3D View
    projection before duplicating and passes the closest X/Y/Z axis constraint to
    Blender's own modal transform.  When the pointer is not close to an axis line
    the transform is left unconstrained, preserving normal free-drag behaviour.
    """
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return None
        if transform_kind not in {"TRANSLATE", "ROTATE", "SCALE"}:
            return None
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _selected_transform_center(context)
        if center is None:
            return None
        start_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        if start_2d is None:
            return None
        mouse = Vector((float(getattr(event, "mouse_region_x", 0) or 0), float(getattr(event, "mouse_region_y", 0) or 0)))
        start = Vector((float(start_2d.x), float(start_2d.y)))
        orientation = _orientation_axis_matrix(context)
        axis_len = _selection_scale_for_gizmo_probe(context)
        axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        best_axis = None
        best_score = 10 ** 9
        try:
            tool_id = _active_tool_id(context, "VIEW_3D").lower()
        except Exception:
            tool_id = ""
        threshold = 30.0 if transform_kind == "ROTATE" else (30.0 if "smart" in tool_id or "gizmo" in tool_id else 24.0)
        for index, axis in enumerate(axes):
            try:
                world_axis = (orientation.to_3x3() @ axis).normalized()
            except Exception:
                world_axis = axis
            for sign in (1.0, -1.0):
                end_3d = center + world_axis * axis_len * sign
                end_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, end_3d)
                if end_2d is None:
                    continue
                end = Vector((float(end_2d.x), float(end_2d.y)))
                if (end - start).length < 18.0:
                    continue
                dist, t = _point_segment_distance_2d(mouse, start, end)
                # Avoid constraining when the user clicks the center/free-transform
                # handle; require the hit to be on the visible axis stroke.
                if t < 0.08:
                    continue
                score = dist + (0.0 if sign > 0.0 else 1.5)
                if score < best_score:
                    best_score = score
                    best_axis = index
        if best_axis is None or best_score > threshold:
            return None
        return tuple(best_axis == i for i in range(3))  # type: ignore[return-value]
    except Exception:
        return None



def _transform_tool_axis_handle_from_drag_origin(context: bpy.types.Context, event: bpy.types.Event) -> tuple[str, tuple[bool, bool, bool] | None] | None:
    """Infer translate/scale axis intent for combined Transform-style gizmos.

    Native gizmo pass-through is still preferred.  This fallback is used only
    when no native transform delta appears, so the heuristic is conservative:
    rotation rings are detected elsewhere; here, an axis-end hit is treated as
    scale while an axis-shaft hit is treated as translate.
    """
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return None
        try:
            tool_id = _active_tool_id(context, "VIEW_3D").lower()
        except Exception:
            tool_id = ""
        if "transform" not in tool_id:
            return None
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _selected_transform_center(context)
        if center is None:
            return None
        start_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        if start_2d is None:
            return None
        mouse = Vector((float(getattr(event, "mouse_region_x", 0) or 0), float(getattr(event, "mouse_region_y", 0) or 0)))
        start = Vector((float(start_2d.x), float(start_2d.y)))
        orientation = _orientation_axis_matrix(context)
        axis_len = _selection_scale_for_gizmo_probe(context)
        axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        best_axis = None
        best_t = 0.0
        best_score = 10 ** 9
        for index, local_axis in enumerate(axes):
            try:
                world_axis = (orientation.to_3x3() @ local_axis).normalized()
            except Exception:
                world_axis = local_axis
            for sign in (1.0, -1.0):
                end_3d = center + world_axis * axis_len * sign
                end_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, end_3d)
                if end_2d is None:
                    continue
                end = Vector((float(end_2d.x), float(end_2d.y)))
                if (end - start).length < 18.0:
                    continue
                dist, t = _point_segment_distance_2d(mouse, start, end)
                if t < 0.08:
                    continue
                score = float(dist) + (0.0 if sign > 0.0 else 1.5)
                if score < best_score:
                    best_score = score
                    best_axis = index
                    best_t = float(t)
        if best_axis is None or best_score > 30.0:
            return None
        axis = tuple(best_axis == i for i in range(3))  # type: ignore[assignment]
        # Standard and Smart transform gizmos usually place the scale box at the
        # end of the axis.  Treat only clear end hits as scale, so arrow/shaft
        # drags remain translate.
        if best_t >= 0.78:
            return "SCALE", axis  # type: ignore[return-value]
        return "TRANSLATE", axis  # type: ignore[return-value]
    except Exception:
        return None



def _axis_index_from_constraint(axis_constraint: tuple[bool, bool, bool] | None) -> int | None:
    try:
        if axis_constraint is None:
            return None
        for index, state in enumerate(tuple(axis_constraint)):
            if bool(state):
                return int(index)
    except Exception:
        pass
    return None


def _world_axis_from_constraint(context: bpy.types.Context, axis_constraint: tuple[bool, bool, bool] | None) -> Vector | None:
    index = _axis_index_from_constraint(axis_constraint)
    if index is None:
        return None
    try:
        axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        orientation = _orientation_axis_matrix(context)
        axis = (orientation.to_3x3() @ axes[index]).normalized()
        if axis.length <= 1.0e-8:
            return axes[index].copy()
        return axis
    except Exception:
        try:
            return (
                Vector((1.0, 0.0, 0.0)),
                Vector((0.0, 1.0, 0.0)),
                Vector((0.0, 0.0, 1.0)),
            )[index].copy()
        except Exception:
            return None


def _view_direction_world(context: bpy.types.Context) -> Vector:
    try:
        rv3d = getattr(context, "region_data", None)
        if rv3d is not None:
            direction = (rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))).normalized()
            if direction.length > 1.0e-8:
                return direction
    except Exception:
        pass
    return Vector((0.0, 0.0, 1.0))


def _rotation_axis_constraint_from_drag_origin(context: bpy.types.Context, event: bpy.types.Event) -> tuple[bool, bool, bool] | None:
    """Infer the rotate-gizmo axis by sampling projected X/Y/Z rotation rings."""
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return None
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _selected_transform_center(context)
        if center is None:
            return None
        mouse = Vector((float(getattr(event, "mouse_region_x", 0) or 0), float(getattr(event, "mouse_region_y", 0) or 0)))
        orientation = _orientation_axis_matrix(context)
        radius = _selection_scale_for_gizmo_probe(context)
        axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        best_axis = None
        best_dist = 10 ** 9
        threshold = 24.0
        samples = 48
        for index, local_axis in enumerate(axes):
            try:
                normal = (orientation.to_3x3() @ local_axis).normalized()
            except Exception:
                normal = local_axis.copy()
            # Build a stable orthonormal basis on the rotation plane.
            ref = Vector((0.0, 0.0, 1.0))
            if abs(float(normal.dot(ref))) > 0.92:
                ref = Vector((0.0, 1.0, 0.0))
            u = normal.cross(ref)
            if u.length <= 1.0e-8:
                continue
            u.normalize()
            v = normal.cross(u)
            if v.length <= 1.0e-8:
                continue
            v.normalize()
            prev = None
            for sample in range(samples + 1):
                angle = (math.tau * float(sample)) / float(samples)
                point = center + (math.cos(angle) * u + math.sin(angle) * v) * radius
                p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, point)
                if p2 is None:
                    prev = None
                    continue
                cur = Vector((float(p2.x), float(p2.y)))
                if prev is not None and (cur - prev).length > 2.0:
                    dist, _t = _point_segment_distance_2d(mouse, prev, cur)
                    if dist < best_dist:
                        best_dist = dist
                        best_axis = index
                prev = cur
        if best_axis is None or best_dist > threshold:
            return None
        return tuple(best_axis == i for i in range(3))  # type: ignore[return-value]
    except Exception:
        return None


def _infer_gizmo_transform_from_drag_origin(context: bpy.types.Context, event: bpy.types.Event, transform_kind: str) -> tuple[str, tuple[bool, bool, bool] | None]:
    """Resolve fallback transform kind and axis from the initial Smart/standard gizmo hit.

    Native pass-through remains the primary path.  This information is used only
    when Blender/Smart Gizmo does not consume the handed-off drag and the add-on
    has to move the visible clone itself.
    """
    kind = str(transform_kind or "TRANSLATE").upper()
    tool_id = _active_tool_id(context, "VIEW_3D").lower()
    try:
        if "rotate" in tool_id:
            kind = "ROTATE"
        elif "scale" in tool_id or "resize" in tool_id:
            kind = "SCALE"
        elif "move" in tool_id or "translate" in tool_id:
            kind = "TRANSLATE"
    except Exception:
        pass

    # A plain selection/cursor tool must behave like a free transform.  Previous
    # builds probed the projected gizmo axes even when the active tool was not a
    # transform tool; an ordinary Shift+left-drag could then be mistaken for an
    # axis handle and the clone appeared locked to that axis.  Only use handle
    # hit-testing when the current tool is actually a transform/gizmo tool.
    transformish_tool = any(token in tool_id for token in ("move", "translate", "rotate", "scale", "resize", "transform", "gizmo"))
    if not transformish_tool:
        return kind, None

    if kind == "ROTATE":
        axis = _rotation_axis_constraint_from_drag_origin(context, event)
        if axis is None:
            axis = _axis_constraint_from_drag_origin(context, event, "ROTATE")
        return "ROTATE", axis

    if kind == "SCALE":
        return "SCALE", _axis_constraint_from_drag_origin(context, event, "SCALE")

    # Combined Transform tools can expose translate arrows, scale boxes, and
    # rotate rings while the active tool id does not identify a single transform
    # mode.  Prefer a clear axis hit first because the axis endpoints can be near
    # projected rotate rings in perspective views.  Native pass-through remains
    # the primary path; this data is only a fallback.
    try:
        if "transform" in tool_id and not any(token in tool_id for token in ("move", "translate", "rotate", "scale", "resize")):
            handle = _transform_tool_axis_handle_from_drag_origin(context, event)
            if handle is not None:
                return handle
            ring_axis = _rotation_axis_constraint_from_drag_origin(context, event)
            if ring_axis is not None:
                return "ROTATE", ring_axis
    except Exception:
        pass

    return "TRANSLATE", _axis_constraint_from_drag_origin(context, event, "TRANSLATE")



def _axis_constraint_from_drag_delta(context: bpy.types.Context, start_xy: tuple[int, int], event: bpy.types.Event, transform_kind: str, session: _CloneSession | None = None) -> tuple[bool, bool, bool] | None:
    """Infer a Smart/standard gizmo axis from the actual drag direction.

    Some external Smart Gizmo handlers do not expose the clicked axis to this
    add-on once the configured drag-start key intercepts LEFTMOUSE.  The initial
    hit-test can also miss custom handles whose screen drawing differs from
    Blender's built-in gizmo.  When the visible clone has to use the safe
    fallback transform, use the mouse drag vector itself to recover X/Y/Z axis
    intent.  The inference is deliberately conservative so center/free-drag
    clicks remain unconstrained.
    """
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return None
        if str(transform_kind or "TRANSLATE").upper() not in {"TRANSLATE", "SCALE"}:
            return None
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = None
        try:
            if session is not None:
                center = _session_reference_world_location(session)
        except Exception:
            center = None
        if center is None:
            center = _selected_transform_center(context)
        if center is None:
            return None
        center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        if center_2d is None:
            return None
        sx, sy = int(start_xy[0]), int(start_xy[1])
        cx, cy = _event_xy(event)
        drag = Vector((float(cx - sx), float(cy - sy)))
        if drag.length < float(_DRAG_START_PIXELS) * 1.25:
            return None
        # Free-center transform handles normally start very close to the pivot.
        # Do not convert such drags into axis constraints unless an earlier
        # hit-test already found an explicit axis.
        start_from_center = Vector((float(sx - center_2d.x), float(sy - center_2d.y)))
        try:
            tool_id = _active_tool_id(context, "VIEW_3D").lower()
        except Exception:
            tool_id = ""
        center_guard = 4.0 if ("smart" in tool_id or "gizmo" in tool_id) else 8.0
        if start_from_center.length < center_guard:
            return None
        drag.normalize()
        orientation = _orientation_axis_matrix(context)
        axis_len = _selection_scale_for_gizmo_probe(context)
        axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        scores: list[tuple[float, int]] = []
        p0 = Vector((float(center_2d.x), float(center_2d.y)))
        for index, local_axis in enumerate(axes):
            try:
                world_axis = (orientation.to_3x3() @ local_axis).normalized()
            except Exception:
                world_axis = local_axis.copy()
            best = 0.0
            for sign in (1.0, -1.0):
                p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, center + world_axis * axis_len * sign)
                if p1 is None:
                    continue
                axis_2d = Vector((float(p1.x), float(p1.y))) - p0
                if axis_2d.length < 8.0:
                    continue
                axis_2d.normalize()
                score = abs(float(drag.dot(axis_2d)))
                best = max(best, score)
            scores.append((best, index))
        if not scores:
            return None
        scores.sort(reverse=True)
        best_score, best_axis = scores[0]
        second_score = scores[1][0] if len(scores) > 1 else 0.0
        # 0.84 ~= within 33 degrees.  The separation guard prevents ambiguous
        # perspective views from forcing a wrong axis.
        if best_score < 0.84 or (best_score - second_score) < 0.08:
            return None
        return tuple(best_axis == i for i in range(3))  # type: ignore[return-value]
    except Exception:
        return None


def _ensure_session_axis_from_drag(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event, transform_kind: str) -> Vector | None:
    """Return only an axis captured from the initial transform-handle hit.

    Free left-drag must remain unconstrained.  Inferring X/Y/Z from mouse
    movement alone caused ordinary Drag Clone movement to look locked,
    especially with selection tools and manual Shift+left-drag keymaps.
    """
    return _session_axis_world(session)


def _transform_kwargs(transform_kind: str, axis_constraint: tuple[bool, bool, bool] | None = None) -> dict:
    kwargs = {"release_confirm": True, "use_accurate": False}
    # Do not pass the transform duplicate-cancel flag here.  The clone is created by this add-on
    # before Blender's modal transform starts, not by Blender's own duplicate
    # operator.  In Blender 5.1 on Windows, invoking transform.translate with
    # the transform duplicate-cancel flag enabled in that state can enter Blender's duplicate-cleanup
    # path without valid duplicate data and crash inside wm_handler_operator_call.
    # Session cancellation is handled explicitly by _cancel_session(), so this flag
    # is both unnecessary and unsafe for this integrated clone workflow.
    if axis_constraint is not None and any(axis_constraint):
        kwargs["constraint_axis"] = axis_constraint
    return kwargs


def _transform_context_is_safe(context: bpy.types.Context, area_type: str) -> bool:
    try:
        if area_type not in {"VIEW_3D", "GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
            return False
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        if area is None or getattr(area, "type", "") != area_type:
            return False
        if region is None or getattr(region, "type", "") != "WINDOW":
            return False
        if area_type == "VIEW_3D":
            mode = str(getattr(context, "mode", "") or "")
            if mode == "OBJECT" and not list(getattr(context, "selected_objects", []) or []):
                return False
            if mode != "OBJECT" and getattr(context, "active_object", None) is None:
                return False
        return True
    except Exception:
        return False


def _operator_context_override_args(context: bpy.types.Context, area, region) -> dict:
    override = {"area": area, "region": region}
    try:
        space = getattr(area, "spaces", None).active
    except Exception:
        space = None
    if space is not None:
        override["space_data"] = space
        try:
            if getattr(area, "type", "") == "VIEW_3D" and getattr(space, "region_3d", None) is not None:
                override["region_data"] = space.region_3d
        except Exception:
            pass
    try:
        override["screen"] = context.screen
    except Exception:
        pass
    try:
        override["window"] = context.window
    except Exception:
        pass
    return override


def _start_transform(context: bpy.types.Context, transform_kind: str, *, axis_constraint: tuple[bool, bool, bool] | None = None) -> set[str]:
    """Never start Blender modal transform from this integrated drag-clone add-on.

    The submitted Blender 5.1.0 Windows crash logs show wm_handler_operator_call
    crashes immediately after transform.translate is invoked from the add-on drag
    clone path, both with and without remove_on_cancel.  To keep the add-on from
    entering that crash-prone internal path, every supported editor now uses
    native event pass-through: the add-on duplicates first, then the
    original mouse/key event is left to Blender's standard gizmo, Smart Gizmo,
    standard G/R/S, or Smart G/R/S handler.
    """
    return {"CANCELLED"}


def _view3d_transform_handoff_enabled(context: bpy.types.Context) -> bool:
    """Use the active 3D View transform handler instead of starting transform.ops.

    Blender 5.1.0 for Windows can crash inside wm_handler_operator_call when this
    add-on starts Blender modal transform operators from the same mouse event.  The safe object
    mode path duplicates the selection immediately, keeps the originals fixed,
    passes the real LEFTMOUSE/G/R/S event through to Blender's standard gizmo,
    Smart Gizmo, standard G/R/S, or Smart G/R/S handler, and lets that visible
    clone move during the drag.  That preserves the handler's own axis hit-test,
    orientation, pivot, snapping, precision, and custom behavior.
    """
    try:
        return ("" if context.area is None else context.area.type) == "VIEW_3D"
    except Exception:
        return False


def _view3d_native_gizmo_handoff_required(context: bpy.types.Context) -> bool:
    """Return True when the active View3D tool should receive the drag natively.

    Smart Gizmo and Blender's transform gizmos can expose custom handles and
    custom axes such as U/V.  Those axes are not represented by Blender's normal
    X/Y/Z constraint tuple after this operator intercepts a key-modified drag.
    For transform/gizmo tools, Drag Clone therefore duplicates first and hands
    the original mouse event back to the active tool, preserving its own axis
    constraint, pivot, orientation, snapping, precision, and custom behavior.
    """
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return False
        tool_id = _active_tool_id(context, "VIEW_3D").lower()
        if not tool_id:
            return False
        selection_tokens = {"builtin.select", "builtin.select_box", "builtin.select_circle", "builtin.select_lasso"}
        if tool_id in selection_tokens or tool_id.startswith("builtin.select_"):
            return False
        return any(token in tool_id for token in (
            "smart", "gizmo", "transform", "move", "translate", "rotate", "scale", "resize"
        ))
    except Exception:
        return False


def _modal_passthrough_running() -> set[str]:
    return {"RUNNING_MODAL", "PASS_THROUGH"}


def _modal_finished_passthrough() -> set[str]:
    return {"FINISHED", "PASS_THROUGH"}

def _modal_finished_no_passthrough() -> set[str]:
    return {"FINISHED"}


# -----------------------------------------------------------------------------
# Clone session data


@dataclass
class _ObjectPair:
    original: bpy.types.Object
    clone: bpy.types.Object
    original_matrix: Matrix
    original_data: bpy.types.ID | None = None
    clone_data: bpy.types.ID | None = None


@dataclass
class _DeferredObjectState:
    original: bpy.types.Object
    original_matrix: Matrix
    final_matrix: Matrix | None = None
    original_data: bpy.types.ID | None = None
    was_selected: bool = True
    was_active: bool = False


@dataclass
class _MeshEditState:
    obj: bpy.types.Object
    original_indices: list[int] = field(default_factory=list)
    clone_indices: list[int] = field(default_factory=list)
    original_coords: dict[int, Vector] = field(default_factory=dict)
    clone_initial_coords: dict[int, Vector] = field(default_factory=dict)
    delta_matrix: Matrix | None = None
    edge_extrude: bool = False


@dataclass
class _KeyRef:
    action: bpy.types.Action
    fcurve: bpy.types.FCurve
    key: bpy.types.Keyframe
    co: Vector


@dataclass(frozen=True)
class _ManualDragKeySpec:
    key_modifier: str
    mouse_type: str
    mouse_value: str
    direction: str = "ANY"
    shift: bool = False
    ctrl: bool = False
    alt: bool = False
    oskey: bool = False
    any_modifier: bool = False


@dataclass
class _CloneSession:
    area_type: str
    mode: str
    transform_kind: str
    mesh_edge_extrude: bool = False
    object_pairs: list[_ObjectPair] = field(default_factory=list)
    deferred_object_states: list[_DeferredObjectState] = field(default_factory=list)
    mesh_states: list[_MeshEditState] = field(default_factory=list)
    key_refs: list[_KeyRef] = field(default_factory=list)
    owned_data: set[bpy.types.ID] = field(default_factory=set)
    created_objects: list[bpy.types.Object] = field(default_factory=list)
    created_by_original: dict[str, list[bpy.types.Object]] = field(default_factory=dict)
    released: bool = False
    dialog_opened: bool = False
    finished: bool = False
    cancel_requested: bool = False
    timer = None
    native_handoff: bool = False
    native_handoff_fallback_started: bool = False
    native_handoff_timer_ticks: int = 0
    axis_constraint: tuple[bool, bool, bool] | None = None
    axis_world: tuple[float, float, float] | None = None
    fallback_center_world: tuple[float, float, float] | None = None
    trigger_shift: bool = False
    trigger_ctrl: bool = False
    trigger_alt: bool = False
    trigger_oskey: bool = False

    @property
    def transform_started_by_addon(self) -> bool:
        return not self.native_handoff or self.native_handoff_fallback_started

    @property
    def supports_clone_type(self) -> bool:
        return self.area_type == "VIEW_3D" and self.mode == "OBJECT" and bool(self.object_pairs or self.deferred_object_states)

    @property
    def supports_copy_count(self) -> bool:
        return bool(self.object_pairs or self.deferred_object_states or self.mesh_states or self.key_refs)


# -----------------------------------------------------------------------------
# Object cloning


def _same_collections(obj: bpy.types.Object) -> Iterable[bpy.types.Collection]:
    if obj.users_collection:
        return obj.users_collection
    return (bpy.context.scene.collection,)


def _sms_core_module():
    try:
        from . import core as _sms_core
        return _sms_core
    except Exception:
        return None


def _sms_prepare_created_object_for_smart_modifier(obj: bpy.types.Object | None) -> None:
    if obj is None:
        return
    core = _sms_core_module()
    if core is None:
        return
    try:
        clear_gid = getattr(core, 'ms_clear_object_instance_id', None)
        if callable(clear_gid):
            clear_gid(obj)
    except Exception:
        pass
    try:
        for mod in list(getattr(obj, 'modifiers', ()) or []):
            try:
                clear_iid = getattr(core, 'ms_obj_clear_instance_id', None)
                if callable(clear_iid):
                    clear_iid(obj, mod.name)
            except Exception:
                pass
            try:
                set_unique = getattr(core, '_ms_modifier_set_object_instance_unique', None)
                if callable(set_unique):
                    set_unique(mod, False)
            except Exception:
                pass
    except Exception:
        pass


def _sms_finalize_object_instance_groups(context: bpy.types.Context, session: _CloneSession) -> None:
    core = _sms_core_module()
    if core is None or not getattr(session, 'object_pairs', None):
        return
    affected: set[str] = set()
    prefer_by_gid: dict[str, bpy.types.Object] = {}
    for pair in session.object_pairs:
        original = pair.original
        if original is None or getattr(original, 'name', '') not in bpy.data.objects:
            continue
        try:
            gid = str(core.ms_get_object_instance_id(original) or uuid.uuid4().hex)
        except Exception:
            gid = uuid.uuid4().hex
        members = [original]
        try:
            members.extend(list(session.created_by_original.get(original.name, []) or []))
        except Exception:
            members.append(pair.clone)
        seen: set[str] = set()
        for obj in members:
            if obj is None or getattr(obj, 'name', '') not in bpy.data.objects:
                continue
            if obj.name in seen:
                continue
            seen.add(obj.name)
            try:
                core.ms_set_object_instance_id(obj, gid)
                try:
                    allow_member = getattr(core, 'ms_allow_new_object_instance_member', None)
                    if callable(allow_member) and obj is not original:
                        allow_member(obj, gid)
                except Exception:
                    pass
            except Exception:
                pass
            try:
                for mod in list(getattr(obj, 'modifiers', ()) or []):
                    set_unique = getattr(core, '_ms_modifier_set_object_instance_unique', None)
                    if callable(set_unique):
                        set_unique(mod, False)
            except Exception:
                pass
        affected.add(gid)
        prefer_by_gid[gid] = original

    for gid in tuple(affected):
        try:
            core.ms_group_object_instance_modifier_stacks(gid, context=context, prefer_obj=prefer_by_gid.get(gid), force=True)
        except Exception:
            pass
    try:
        core.ms_sync_object_instance_modifier_additions(context, force=True)
    except Exception:
        pass
    try:
        core.ms_sync_all_instance_groups(context, prefer_active=True, force=True)
    except Exception:
        pass


def _copy_object_data_for_initial_clone(obj: bpy.types.Object):
    data = getattr(obj, "data", None)
    if data is None:
        return None
    copy_fn = getattr(data, "copy", None)
    if copy_fn is None:
        return data
    try:
        return copy_fn()
    except Exception:
        return data


def _capture_deferred_object_transform_session(context: bpy.types.Context, transform_kind: str) -> _CloneSession:
    """Capture object transforms and let Blender/Smart Gizmo move originals natively."""
    originals = list(getattr(context, "selected_objects", []) or [])
    if not originals:
        raise RuntimeError(_iface("No selected object is available for cloning."))
    active = getattr(context.view_layer.objects, "active", None)
    session = _CloneSession(area_type="VIEW_3D", mode="OBJECT", transform_kind=transform_kind)
    for obj in originals:
        try:
            session.deferred_object_states.append(_DeferredObjectState(
                original=obj,
                original_matrix=obj.matrix_world.copy(),
                final_matrix=None,
                original_data=getattr(obj, "data", None),
                was_selected=bool(obj.select_get()),
                was_active=(obj == active),
            ))
        except Exception:
            pass
    if not session.deferred_object_states:
        raise RuntimeError(_iface("No selected object is available for cloning."))
    session.native_handoff = True
    return session


def _capture_deferred_object_final_matrices(session: _CloneSession) -> None:
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    for state in list(getattr(session, "deferred_object_states", []) or []):
        obj = state.original
        if obj is None or getattr(obj, "name", "") not in bpy.data.objects:
            continue
        try:
            state.final_matrix = obj.matrix_world.copy()
        except Exception:
            state.final_matrix = state.original_matrix.copy()


def _restore_deferred_original_objects(context: bpy.types.Context, session: _CloneSession) -> None:
    states = list(getattr(session, "deferred_object_states", []) or [])
    if not states:
        return
    for state in states:
        obj = state.original
        if obj is None or getattr(obj, "name", "") not in bpy.data.objects:
            continue
        try:
            obj.matrix_world = state.original_matrix.copy()
        except Exception:
            pass
    try:
        context.view_layer.update()
    except Exception:
        pass


def _object_delta_from_deferred_state(state: _DeferredObjectState) -> Matrix:
    final = state.final_matrix
    if final is None:
        try:
            final = state.original.matrix_world.copy()
        except Exception:
            final = state.original_matrix.copy()
    try:
        return final @ state.original_matrix.inverted()
    except Exception:
        return Matrix.Identity(4)


def _make_deferred_object_clone(context: bpy.types.Context, session: _CloneSession, state: _DeferredObjectState, clone_type: str, matrix: Matrix) -> bpy.types.Object | None:
    original = state.original
    if original is None or getattr(original, "name", "") not in bpy.data.objects:
        return None
    try:
        new_obj = original.copy()
    except Exception:
        return None
    source_data = getattr(original, "data", None)
    if source_data is not None:
        if clone_type == "INSTANCE":
            new_obj.data = source_data
        else:
            copy_fn = getattr(source_data, "copy", None)
            if callable(copy_fn):
                try:
                    new_data = copy_fn()
                    new_obj.data = new_data
                    session.owned_data.add(new_data)
                except Exception:
                    new_obj.data = source_data
            else:
                new_obj.data = source_data
    try:
        _link_object_to_collections(new_obj, original)
    except Exception:
        try:
            bpy.context.scene.collection.objects.link(new_obj)
        except Exception:
            pass
    try:
        new_obj.matrix_world = matrix.copy()
    except Exception:
        pass
    try:
        new_obj.hide_viewport = original.hide_viewport
        new_obj.hide_select = original.hide_select
    except Exception:
        pass
    if clone_type != "INSTANCE":
        _sms_prepare_created_object_for_smart_modifier(new_obj)
    session.created_objects.append(new_obj)
    try:
        session.created_by_original.setdefault(original.name, []).append(new_obj)
    except Exception:
        pass
    return new_obj


def _finish_deferred_object_session(context: bpy.types.Context, session: _CloneSession, clone_type: str, copy_count: int) -> None:
    states = list(getattr(session, "deferred_object_states", []) or [])
    if not states:
        return
    _capture_deferred_object_final_matrices(session)
    copy_count = max(1, int(copy_count))
    _restore_deferred_original_objects(context, session)
    created: list[bpy.types.Object] = []
    for state in states:
        delta = _object_delta_from_deferred_state(state)
        previous_matrix = state.original_matrix.copy()
        for _copy_index in range(1, copy_count + 1):
            previous_matrix = delta @ previous_matrix
            new_obj = _make_deferred_object_clone(context, session, state, clone_type, previous_matrix)
            if new_obj is not None:
                created.append(new_obj)
    try:
        for obj in list(getattr(context.scene, "objects", []) or []):
            obj.select_set(False)
    except Exception:
        pass
    for obj in created:
        try:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        except Exception:
            pass
    if created:
        try:
            context.view_layer.objects.active = created[-1]
        except Exception:
            pass
    if clone_type == "INSTANCE":
        pairs: list[_ObjectPair] = []
        for state in states:
            first = None
            try:
                for obj in session.created_by_original.get(state.original.name, []) or []:
                    first = obj
                    break
            except Exception:
                first = None
            if first is not None:
                pairs.append(_ObjectPair(state.original, first, state.original_matrix.copy(), state.original_data, getattr(first, "data", None)))
        session.object_pairs = pairs
        _sms_finalize_object_instance_groups(context, session)
    else:
        for obj in list(created):
            _sms_prepare_created_object_for_smart_modifier(obj)
    _remove_orphan_owned_data(session)


def _duplicate_objects_for_session(context: bpy.types.Context) -> tuple[list[_ObjectPair], list[bpy.types.Object], set[bpy.types.ID]]:
    originals = list(context.selected_objects)
    if not originals:
        raise RuntimeError(_iface("No selected object is available for cloning."))

    active_original = context.view_layer.objects.active
    pairs: list[_ObjectPair] = []
    created: list[bpy.types.Object] = []
    owned_data: set[bpy.types.ID] = set()

    for obj in originals:
        clone = obj.copy()
        original_data = getattr(obj, "data", None)
        clone_data = _copy_object_data_for_initial_clone(obj)
        if clone_data is not None:
            clone.data = clone_data
            if clone_data is not original_data:
                owned_data.add(clone_data)

        for collection in _same_collections(obj):
            try:
                collection.objects.link(clone)
            except RuntimeError:
                pass
        clone.matrix_world = obj.matrix_world.copy()
        clone.hide_viewport = obj.hide_viewport
        clone.hide_select = obj.hide_select
        _sms_prepare_created_object_for_smart_modifier(clone)
        pairs.append(_ObjectPair(obj, clone, obj.matrix_world.copy(), original_data, clone_data))
        created.append(clone)

    for obj in originals:
        obj.select_set(False)
    for pair in pairs:
        pair.clone.select_set(True)

    if active_original is not None:
        for pair in pairs:
            if pair.original == active_original:
                context.view_layer.objects.active = pair.clone
                break
        else:
            context.view_layer.objects.active = pairs[0].clone
    else:
        context.view_layer.objects.active = pairs[0].clone

    return pairs, created, owned_data


def _remove_orphan_owned_data(session: _CloneSession) -> None:
    for data in list(session.owned_data):
        if data is None:
            session.owned_data.discard(data)
            continue
        users = getattr(data, "users", 0)
        if users == 0:
            try:
                bpy.data.batch_remove(ids=(data,))
            except Exception:
                try:
                    bpy.data.remove(data)
                except Exception:
                    pass
            session.owned_data.discard(data)


def _set_object_clone_type(session: _CloneSession, clone_type: str) -> None:
    if clone_type != "INSTANCE":
        return
    for pair in session.object_pairs:
        if pair.original_data is None:
            continue
        old_data = getattr(pair.clone, "data", None)
        try:
            pair.clone.data = pair.original_data
        except Exception:
            continue
        if old_data is not None and old_data is not pair.original_data and old_data in session.owned_data:
            session.owned_data.discard(old_data)
            if getattr(old_data, "users", 0) == 0:
                try:
                    bpy.data.batch_remove(ids=(old_data,))
                except Exception:
                    pass


def _object_delta_matrix(pair: _ObjectPair) -> Matrix:
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    try:
        return pair.clone.matrix_world @ pair.original_matrix.inverted()
    except Exception:
        return Matrix.Identity(4)


def _link_object_to_collections(new_obj: bpy.types.Object, source_obj: bpy.types.Object) -> None:
    linked = False
    for collection in _same_collections(source_obj):
        try:
            collection.objects.link(new_obj)
            linked = True
        except RuntimeError:
            pass
    if not linked:
        bpy.context.scene.collection.objects.link(new_obj)


def _append_object_copies(context: bpy.types.Context, session: _CloneSession, clone_type: str, copy_count: int) -> None:
    if copy_count <= 1 or not session.object_pairs:
        return

    deltas = [_object_delta_matrix(pair) for pair in session.object_pairs]
    previous_objects = [pair.clone for pair in session.object_pairs]
    all_created = list(previous_objects)

    for _copy_index in range(2, copy_count + 1):
        new_previous: list[bpy.types.Object] = []
        for pair, previous, delta in zip(session.object_pairs, previous_objects, deltas):
            new_obj = previous.copy()
            if pair.original_data is not None:
                if clone_type == "INSTANCE":
                    new_obj.data = pair.original_data
                else:
                    source_data = getattr(previous, "data", None) or pair.original_data
                    copy_fn = getattr(source_data, "copy", None)
                    if copy_fn is not None:
                        try:
                            new_data = copy_fn()
                            new_obj.data = new_data
                            session.owned_data.add(new_data)
                        except Exception:
                            new_obj.data = source_data
                    else:
                        new_obj.data = source_data
            _link_object_to_collections(new_obj, previous)
            _sms_prepare_created_object_for_smart_modifier(new_obj)
            try:
                session.created_by_original.setdefault(pair.original.name, []).append(new_obj)
            except Exception:
                pass
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
            new_obj.matrix_world = delta @ previous.matrix_world
            session.created_objects.append(new_obj)
            all_created.append(new_obj)
            new_previous.append(new_obj)
        previous_objects = new_previous

    for obj in context.scene.objects:
        obj.select_set(False)
    for obj in all_created:
        if obj.name in bpy.data.objects:
            obj.select_set(True)
    if all_created:
        context.view_layer.objects.active = all_created[-1]


# -----------------------------------------------------------------------------
# Mesh edit cloning and repeated affine copies


def _ensure_bmesh() -> None:
    if bmesh is None:
        raise RuntimeError(_iface("Mesh edit cloning requires Blender's bmesh module."))


def _editable_mesh_objects(context: bpy.types.Context) -> list[bpy.types.Object]:
    objects = getattr(context, "objects_in_mode_unique_data", None)
    if objects:
        return [obj for obj in objects if getattr(obj, "type", "") == "MESH"]
    active = context.active_object
    return [active] if active is not None and active.type == "MESH" else []


def _capture_mesh_states_before_duplicate(context: bpy.types.Context) -> list[_MeshEditState]:
    _ensure_bmesh()
    states: list[_MeshEditState] = []
    for obj in _editable_mesh_objects(context):
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        selected = [v for v in bm.verts if v.select]
        if not selected:
            continue
        state = _MeshEditState(obj=obj)
        for v in selected:
            state.original_indices.append(v.index)
            state.original_coords[v.index] = v.co.copy()
        states.append(state)
    return states


def _mesh_select_mode_flags(context: bpy.types.Context) -> tuple[bool, bool, bool]:
    try:
        tool_settings = getattr(context, "tool_settings", None)
        select_mode = tuple(getattr(tool_settings, "mesh_select_mode", (True, False, False)) or ())
        vert_mode = bool(select_mode[0]) if len(select_mode) > 0 else True
        edge_mode = bool(select_mode[1]) if len(select_mode) > 1 else False
        face_mode = bool(select_mode[2]) if len(select_mode) > 2 else False
        return vert_mode, edge_mode, face_mode
    except Exception:
        return True, False, False


def _mesh_edge_extrude_clone_requested(context: bpy.types.Context) -> bool:
    """Use bridge-style edge extrusion only for selected boundary edges.

    In edge select mode, Drag Clone follows the 3ds Max-style contour-edge
    behavior requested for this suite: selected boundary edges are duplicated at
    drag start, and bridge faces are created between the original and cloned
    edge loop.  Interior/non-boundary edges are intentionally rejected instead
    of falling back to loose edge duplication.
    """
    try:
        if str(getattr(context, "mode", "") or "") != "EDIT_MESH":
            return False
        _vert_mode, edge_mode, face_mode = _mesh_select_mode_flags(context)
        if not edge_mode or face_mode:
            return False
    except Exception:
        return False
    try:
        found_selected_edge = False
        for obj in _editable_mesh_objects(context):
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            if any(bool(getattr(face, "select", False)) for face in bm.faces):
                return False
            selected_edges = [edge for edge in bm.edges if bool(getattr(edge, "select", False))]
            if not selected_edges:
                continue
            found_selected_edge = True
            for edge in selected_edges:
                # Boundary/contour edge in Blender has exactly one linked face.
                # Loose wire edges have zero linked faces and are not treated as
                # face contours for the bridge-generation mode.
                if len(getattr(edge, "link_faces", []) or []) != 1:
                    return False
        return found_selected_edge
    except Exception:
        return False


def _mesh_edge_mode_has_selected_edges(context: bpy.types.Context) -> bool:
    try:
        if str(getattr(context, "mode", "") or "") != "EDIT_MESH":
            return False
        _vert_mode, edge_mode, face_mode = _mesh_select_mode_flags(context)
        if not edge_mode or face_mode:
            return False
        for obj in _editable_mesh_objects(context):
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            if any(bool(getattr(edge, "select", False)) for edge in bm.edges):
                return True
    except Exception:
        return False
    return False


def _prepare_mesh_selection_for_drag_duplicate(context: bpy.types.Context) -> None:
    """Constrain duplicate geometry to the active edit-mesh component mode."""
    try:
        if str(getattr(context, "mode", "") or "") != "EDIT_MESH":
            return
        vert_mode, edge_mode, face_mode = _mesh_select_mode_flags(context)
        # Pure vertex mode must duplicate vertices only, even if old edge/face
        # selection flags are still present internally.
        if vert_mode and not edge_mode and not face_mode:
            for obj in _editable_mesh_objects(context):
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
                selected_vert_indices = [int(v.index) for v in bm.verts if bool(getattr(v, "select", False))]
                for face in bm.faces:
                    try:
                        face.select_set(False)
                    except Exception:
                        pass
                for edge in bm.edges:
                    try:
                        edge.select_set(False)
                    except Exception:
                        pass
                for vert in bm.verts:
                    try:
                        vert.select_set(False)
                    except Exception:
                        pass
                for index in selected_vert_indices:
                    try:
                        if 0 <= index < len(bm.verts):
                            bm.verts[index].select_set(True)
                    except Exception:
                        pass
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _capture_mesh_states_before_edge_extrude(context: bpy.types.Context) -> list[_MeshEditState]:
    _ensure_bmesh()
    states: list[_MeshEditState] = []
    for obj in _editable_mesh_objects(context):
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        selected_edges = [edge for edge in bm.edges if bool(getattr(edge, "select", False))]
        if not selected_edges:
            continue
        source_verts = []
        seen = set()
        for edge in selected_edges:
            for vert in edge.verts:
                try:
                    idx = int(vert.index)
                except Exception:
                    continue
                if idx in seen:
                    continue
                seen.add(idx)
                source_verts.append(vert)
        if not source_verts:
            continue
        state = _MeshEditState(obj=obj, edge_extrude=True)
        for vert in sorted(source_verts, key=lambda item: int(item.index)):
            idx = int(vert.index)
            state.original_indices.append(idx)
            state.original_coords[idx] = vert.co.copy()
        states.append(state)
    return states


def _deselect_mesh_edit_geometry(bm) -> None:
    try:
        for face in bm.faces:
            face.select_set(False)
    except Exception:
        pass
    try:
        for edge in bm.edges:
            edge.select_set(False)
    except Exception:
        pass
    try:
        for vert in bm.verts:
            vert.select_set(False)
    except Exception:
        pass


def _edge_extrude_selected_geometry(state: _MeshEditState) -> bool:
    """Extrude selected boundary edges with Blender's edit-mesh operator.

    For edge-mode Drag Clone, the desired 3ds Max-style result is an edge copy
    with bridge faces to the source contour.  Blender's native edit-mesh
    extrude operator creates a stable edit-mode mesh for this case; direct
    bmesh face construction in a left-drag modal path can leave Blender 5.1.x
    with edit-mesh caches that crash on shutdown.
    """
    _ensure_bmesh()
    bm = bmesh.from_edit_mesh(state.obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    selected_edges = [edge for edge in bm.edges if bool(getattr(edge, "select", False))]
    if not selected_edges:
        return False
    for edge in selected_edges:
        try:
            if len(getattr(edge, "link_faces", []) or []) != 1:
                return False
        except Exception:
            return False

    original_vert_count = len(bm.verts)
    try:
        bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass

    try:
        # Use the non-modal edit-mesh extrusion operator.  This avoids invoking
        # Blender's modal transform stack from inside Drag Clone while still
        # producing Blender-native bridge topology for contour edges.
        result = bpy.ops.mesh.extrude_region(mirror=False)
    except Exception:
        try:
            result = bpy.ops.mesh.extrude_region_move(
                MESH_OT_extrude_region={
                    "use_normal_flip": False,
                    "use_dissolve_ortho_edges": False,
                    "mirror": False,
                },
                TRANSFORM_OT_translate={"value": (0.0, 0.0, 0.0)},
            )
        except Exception:
            try:
                result = bpy.ops.mesh.extrude_edges_move(TRANSFORM_OT_translate={"value": (0.0, 0.0, 0.0)})
            except Exception:
                return False
    if "CANCELLED" in result:
        return False

    bm = bmesh.from_edit_mesh(state.obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    original_set = set(int(i) for i in state.original_indices)
    clone_indices = [int(v.index) for v in bm.verts if bool(getattr(v, "select", False)) and int(v.index) not in original_set]
    if not clone_indices:
        clone_indices = [int(v.index) for v in bm.verts if int(v.index) >= int(original_vert_count)]
    if not clone_indices:
        return False

    state.clone_indices = sorted(set(int(i) for i in clone_indices if int(i) >= 0))
    state.original_indices = sorted(state.original_indices)
    state.clone_initial_coords.clear()
    for index in state.clone_indices:
        try:
            if 0 <= int(index) < len(bm.verts):
                state.clone_initial_coords[int(index)] = bm.verts[int(index)].co.copy()
        except Exception:
            pass
    try:
        bmesh.update_edit_mesh(state.obj.data, loop_triangles=True, destructive=True)
    except Exception:
        pass
    return bool(state.clone_indices)



def _extrude_mesh_edges_for_session(context: bpy.types.Context) -> list[_MeshEditState]:
    states = _capture_mesh_states_before_edge_extrude(context)
    if not states:
        raise RuntimeError(_iface("No selected mesh component is available for cloning."))
    ok_any = False
    for state in states:
        if _edge_extrude_selected_geometry(state):
            ok_any = True
    if not ok_any:
        raise RuntimeError(_iface("Blender cancelled the mesh duplicate operation."))
    return states


def _capture_mesh_states_after_duplicate(states: list[_MeshEditState]) -> None:
    _ensure_bmesh()
    for state in states:
        bm = bmesh.from_edit_mesh(state.obj.data)
        bm.verts.ensure_lookup_table()
        original_set = set(state.original_indices)
        clone_indices = [v.index for v in bm.verts if v.select and v.index not in original_set]
        if len(clone_indices) != len(state.original_indices):
            selected_indices = [v.index for v in bm.verts if v.select]
            clone_indices = selected_indices[-len(state.original_indices):]
        state.clone_indices = sorted(clone_indices)
        state.original_indices = sorted(state.original_indices)
        state.clone_initial_coords.clear()
        for index in state.clone_indices:
            try:
                if 0 <= int(index) < len(bm.verts):
                    state.clone_initial_coords[int(index)] = bm.verts[int(index)].co.copy()
            except Exception:
                pass


def _duplicate_mesh_for_session(context: bpy.types.Context) -> list[_MeshEditState]:
    if _mesh_edge_extrude_clone_requested(context):
        return _extrude_mesh_edges_for_session(context)
    if _mesh_edge_mode_has_selected_edges(context):
        raise RuntimeError(_iface("Edge drag cloning requires selected boundary edges."))
    _prepare_mesh_selection_for_drag_duplicate(context)
    states = _capture_mesh_states_before_duplicate(context)
    if not states:
        raise RuntimeError(_iface("No selected mesh component is available for cloning."))
    result = bpy.ops.mesh.duplicate(mode=1)
    if "CANCELLED" in result:
        raise RuntimeError(_iface("Blender cancelled the mesh duplicate operation."))
    _capture_mesh_states_after_duplicate(states)
    return states


def _affine_from_pairs(source_points: list[Vector], target_points: list[Vector]) -> Matrix:
    count = min(len(source_points), len(target_points))
    if count == 0:
        return Matrix.Identity(4)
    if count == 1:
        return Matrix.Translation(target_points[0] - source_points[0])

    normal = [[0.0] * 4 for _ in range(4)]
    rhs = [[0.0] * 3 for _ in range(4)]
    for src, dst in zip(source_points[:count], target_points[:count]):
        f = (float(src.x), float(src.y), float(src.z), 1.0)
        d = (float(dst.x), float(dst.y), float(dst.z))
        for i in range(4):
            for j in range(4):
                normal[i][j] += f[i] * f[j]
            for axis in range(3):
                rhs[i][axis] += f[i] * d[axis]

    try:
        coeff = Matrix(normal).inverted_safe() @ Matrix(rhs)
        return Matrix(
            (
                (coeff[0][0], coeff[1][0], coeff[2][0], coeff[3][0]),
                (coeff[0][1], coeff[1][1], coeff[2][1], coeff[3][1]),
                (coeff[0][2], coeff[1][2], coeff[2][2], coeff[3][2]),
                (0.0, 0.0, 0.0, 1.0),
            )
        )
    except Exception:
        src_center = sum((p for p in source_points[:count]), Vector()) / count
        dst_center = sum((p for p in target_points[:count]), Vector()) / count
        return Matrix.Translation(dst_center - src_center)


def _mesh_state_delta_matrix(state: _MeshEditState, transform_kind: str = "") -> Matrix:
    if state.delta_matrix is not None:
        return state.delta_matrix
    _ensure_bmesh()
    bm = bmesh.from_edit_mesh(state.obj.data)
    bm.verts.ensure_lookup_table()
    source: list[Vector] = []
    target: list[Vector] = []
    for original_index, clone_index in zip(state.original_indices, state.clone_indices):
        if clone_index >= len(bm.verts):
            continue
        base = state.clone_initial_coords.get(clone_index)
        if base is None:
            base = state.original_coords.get(original_index)
        if base is None:
            continue
        source.append(base)
        target.append(bm.verts[clone_index].co.copy())
    if transform_kind == "TRANSLATE" and source and target:
        count = min(len(source), len(target))
        delta = sum((target[i] - source[i] for i in range(count)), Vector()) / count
        state.delta_matrix = Matrix.Translation(delta)
    else:
        state.delta_matrix = _affine_from_pairs(source, target)
    return state.delta_matrix


def _apply_mesh_delta_to_selected(state: _MeshEditState, matrix: Matrix) -> None:
    _ensure_bmesh()
    bm = bmesh.from_edit_mesh(state.obj.data)
    bm.verts.ensure_lookup_table()
    for v in bm.verts:
        if v.select:
            v.co = matrix @ v.co
    bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)


def _append_mesh_copies(session: _CloneSession, copy_count: int) -> None:
    if copy_count <= 1 or not session.mesh_states:
        return
    matrices = {state.obj.name: _mesh_state_delta_matrix(state, session.transform_kind) for state in session.mesh_states}
    use_edge_extrude = bool(getattr(session, "mesh_edge_extrude", False))
    for _copy_index in range(2, copy_count + 1):
        if use_edge_extrude:
            extruded_any = False
            for state in session.mesh_states:
                if not bool(getattr(state, "edge_extrude", False)):
                    continue
                if _edge_extrude_selected_geometry(state):
                    extruded_any = True
                    matrix = matrices.get(state.obj.name, Matrix.Identity(4))
                    _apply_mesh_delta_to_selected(state, matrix)
            if not extruded_any:
                break
            continue
        result = bpy.ops.mesh.duplicate(mode=1)
        if "CANCELLED" in result:
            break
        for state in session.mesh_states:
            matrix = matrices.get(state.obj.name, Matrix.Identity(4))
            _apply_mesh_delta_to_selected(state, matrix)


# -----------------------------------------------------------------------------
# Keyframe cloning and repeated offsets


def _iter_action_fcurves(action: bpy.types.Action):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        for fcurve in legacy_fcurves:
            yield fcurve
        return
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for channelbag in getattr(strip, "channelbags", []):
                for fcurve in getattr(channelbag, "fcurves", []):
                    yield fcurve


def _iter_selected_key_refs() -> list[_KeyRef]:
    refs: list[_KeyRef] = []
    for action in bpy.data.actions:
        for fcurve in _iter_action_fcurves(action):
            for key in fcurve.keyframe_points:
                if bool(getattr(key, "select_control_point", False)):
                    refs.append(_KeyRef(action, fcurve, key, key.co.copy()))
    refs.sort(key=lambda item: (item.action.name, item.fcurve.data_path, item.fcurve.array_index, item.co.x, item.co.y))
    return refs


def _duplicate_keys_for_session(context: bpy.types.Context) -> list[_KeyRef]:
    before = _iter_selected_key_refs()
    if not before:
        raise RuntimeError(_iface("No selected keyframe is available for cloning."))
    area_type = "" if context.area is None else context.area.type
    if area_type == "GRAPH_EDITOR":
        result = bpy.ops.graph.duplicate()
    else:
        result = bpy.ops.action.duplicate()
    if "CANCELLED" in result:
        raise RuntimeError(_iface("Blender cancelled the keyframe duplicate operation."))
    after = _iter_selected_key_refs()
    return after or before


def _key_delta(session: _CloneSession) -> Vector:
    refs = [ref for ref in session.key_refs if ref.key is not None]
    if not refs:
        return Vector((0.0, 0.0))
    dx = 0.0
    dy = 0.0
    total = 0
    for ref in refs:
        try:
            dx += float(ref.key.co.x - ref.co.x)
            dy += float(ref.key.co.y - ref.co.y)
            total += 1
        except Exception:
            pass
    if total == 0:
        return Vector((0.0, 0.0))
    return Vector((dx / total, dy / total))


def _offset_selected_keys(delta: Vector, include_value: bool) -> None:
    for action in bpy.data.actions:
        for fcurve in _iter_action_fcurves(action):
            changed = False
            for key in fcurve.keyframe_points:
                if bool(getattr(key, "select_control_point", False)):
                    key.co.x += delta.x
                    key.handle_left.x += delta.x
                    key.handle_right.x += delta.x
                    if include_value:
                        key.co.y += delta.y
                        key.handle_left.y += delta.y
                        key.handle_right.y += delta.y
                    changed = True
            if changed:
                try:
                    fcurve.update()
                except Exception:
                    pass


def _append_key_copies(context: bpy.types.Context, session: _CloneSession, copy_count: int) -> None:
    if copy_count <= 1 or not session.key_refs:
        return
    delta = _key_delta(session)
    include_value = ("" if context.area is None else context.area.type) == "GRAPH_EDITOR"
    for _copy_index in range(2, copy_count + 1):
        if context.area is not None and context.area.type == "GRAPH_EDITOR":
            result = bpy.ops.graph.duplicate()
        else:
            result = bpy.ops.action.duplicate()
        if "CANCELLED" in result:
            break
        _offset_selected_keys(delta, include_value=include_value)


# -----------------------------------------------------------------------------
# Generic duplicate and cleanup


def _duplicate_for_session(context: bpy.types.Context, transform_kind: str) -> _CloneSession:
    area_type = "" if context.area is None else context.area.type
    mode = getattr(context, "mode", "OBJECT")
    session = _CloneSession(area_type=area_type, mode=mode, transform_kind=transform_kind)

    if area_type in {"GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
        session.key_refs = _duplicate_keys_for_session(context)
        return session

    if mode == "OBJECT":
        pairs, created, owned = _duplicate_objects_for_session(context)
        session.object_pairs = pairs
        session.created_objects = created
        session.owned_data = owned
        for pair in pairs:
            try:
                session.created_by_original.setdefault(pair.original.name, []).append(pair.clone)
            except Exception:
                pass
        return session

    active = context.active_object
    object_type = "" if active is None else active.type

    if mode == "EDIT_MESH" or object_type == "MESH":
        session.mesh_states = _duplicate_mesh_for_session(context)
        session.mesh_edge_extrude = any(bool(getattr(state, "edge_extrude", False)) for state in session.mesh_states)
        return session
    if mode in {"EDIT_CURVE", "EDIT_SURFACE"} or object_type in {"CURVE", "SURFACE"}:
        result = bpy.ops.curve.duplicate()
    elif mode == "EDIT_ARMATURE" or object_type == "ARMATURE":
        result = bpy.ops.armature.duplicate()
    elif mode == "EDIT_METABALL" or object_type == "META":
        result = bpy.ops.mball.duplicate_metaelems()
    elif mode == "EDIT_GREASE_PENCIL" or object_type == "GREASEPENCIL":
        result = bpy.ops.grease_pencil.duplicate()
    elif mode == "EDIT_CURVES" or object_type == "CURVES":
        result = bpy.ops.curves.duplicate()
    elif mode == "EDIT_POINTCLOUD" or object_type == "POINTCLOUD":
        result = bpy.ops.pointcloud.duplicate()
    else:
        raise RuntimeError(_iface("This mode does not expose a Blender duplicate operation."))

    if "CANCELLED" in result:
        raise RuntimeError(_iface("Blender cancelled the duplicate operation."))
    return session


def _restore_original_object_selection(context: bpy.types.Context, session: _CloneSession) -> None:
    if not session.object_pairs:
        return
    for obj in context.scene.objects:
        obj.select_set(False)
    for pair in session.object_pairs:
        if pair.original.name in bpy.data.objects:
            pair.original.select_set(True)
    if session.object_pairs[0].original.name in bpy.data.objects:
        context.view_layer.objects.active = session.object_pairs[0].original


def _delete_session_objects(context: bpy.types.Context, session: _CloneSession) -> None:
    for obj in list(session.created_objects):
        if obj is not None and obj.name in bpy.data.objects:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass
    _remove_orphan_owned_data(session)
    _restore_original_object_selection(context, session)


def _delete_mesh_clone_vertices_from_session(session: _CloneSession | None) -> None:
    """Delete temporary edit-mesh clone vertices without mesh delete operator.

    Calling mesh.delete from a modal callback after mode/area changes can leave
    Blender's event handler in an invalid state on Windows.  The safe path edits
    only the stored clone vertex indices through bmesh while the object is still
    in edit mode.  If the context is no longer suitable, the function intentionally
    does nothing; leaving temporary geometry is preferable to crashing Blender.
    """
    if session is None or not getattr(session, "mesh_states", None):
        return
    try:
        _ensure_bmesh()
    except Exception:
        return
    for state in list(getattr(session, "mesh_states", []) or []):
        obj = getattr(state, "obj", None)
        if obj is None or getattr(obj, "name", "") not in bpy.data.objects:
            continue
        if getattr(obj, "mode", "") != "EDIT":
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            verts = []
            for index in list(getattr(state, "clone_indices", []) or []):
                try:
                    if 0 <= int(index) < len(bm.verts):
                        verts.append(bm.verts[int(index)])
                except Exception:
                    pass
            if not verts:
                continue
            bmesh.ops.delete(bm, geom=verts, context="VERTS")
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        except Exception:
            continue


def _delete_selected_mesh_clone(_context: bpy.types.Context) -> None:
    # Legacy compatibility wrapper.  Intentionally no mesh delete operator here.
    return


def _delete_selected_key_clone(context: bpy.types.Context) -> None:
    try:
        if context.area is not None and context.area.type == "GRAPH_EDITOR":
            bpy.ops.graph.delete()
        else:
            bpy.ops.action.delete()
    except Exception:
        pass


def _cancel_session(context: bpy.types.Context, session: _CloneSession | None) -> None:
    if session is None or session.finished:
        return
    if getattr(session, "deferred_object_states", None):
        _restore_deferred_original_objects(context, session)
    elif session.object_pairs:
        _delete_session_objects(context, session)
    elif session.mesh_states:
        _delete_mesh_clone_vertices_from_session(session)
    elif session.key_refs:
        _delete_selected_key_clone(context)
    session.finished = True


def _finish_session(context: bpy.types.Context, session: _CloneSession, clone_type: str, copy_count: int) -> None:
    if session.finished:
        return
    copy_count = max(1, int(copy_count))
    if getattr(session, "deferred_object_states", None):
        _finish_deferred_object_session(context, session, clone_type, copy_count)
    elif session.object_pairs:
        _set_object_clone_type(session, clone_type)
        _append_object_copies(context, session, clone_type, copy_count)
        if clone_type == "INSTANCE":
            _sms_finalize_object_instance_groups(context, session)
        else:
            for obj in list(getattr(session, "created_objects", []) or []):
                _sms_prepare_created_object_for_smart_modifier(obj)
        _remove_orphan_owned_data(session)
    elif session.mesh_states:
        _append_mesh_copies(session, copy_count)
    elif session.key_refs:
        _append_key_copies(context, session, copy_count)
    session.finished = True


# -----------------------------------------------------------------------------
# Operators and preferences UI



def _safe_log(message: str) -> None:
    try:
        print(f"[Smart Modifier / Drag Clone] {message}")
    except Exception:
        pass


def _temporarily_suspend_own_keymaps(operator=None) -> None:
    """No-op guard for manual keymap workflows.

    Drag Clone is now manual-keymap only.  During execution the modal operator
    itself owns the event stream, so editing Blender KeyMapItem.active flags is
    unnecessary and unsafe: changing the currently dispatching keymap item can
    leave Blender with invalid native event-handler state.
    """
    try:
        if operator is not None:
            operator._sms_keymap_restore = []
    except Exception:
        pass

def _restore_temporarily_suspended_keymaps(operator=None) -> None:
    if operator is None:
        return
    try:
        restore = list(getattr(operator, "_sms_keymap_restore", []) or [])
    except Exception:
        restore = []
    for kmi, was_active in reversed(restore):
        try:
            kmi.active = bool(was_active)
        except Exception:
            pass
    try:
        operator._sms_keymap_restore = None
    except Exception:
        pass


def _clear_modal_guard(operator=None) -> None:
    global _MSDC_MODAL_ACTIVE
    try:
        if operator is None or bool(getattr(operator, "_owns_modal_guard", False)):
            _MSDC_MODAL_ACTIVE = False
            _restore_temporarily_suspended_keymaps(operator)
        if operator is not None:
            try:
                operator._owns_modal_guard = False
            except Exception:
                pass
    except Exception:
        _MSDC_MODAL_ACTIVE = False
        try:
            _restore_temporarily_suspended_keymaps(operator)
        except Exception:
            pass


def _schedule_view3d_confirmation(context: bpy.types.Context, operator, session: _CloneSession, *, pass_through: bool = True) -> set[str]:
    """Open clone options after the native drag release without keeping this modal alive.

    Keeping the drag-clone modal operator alive while Blender's native gizmo or
    transform handler is also finishing the same mouse event can leave two modal
    handlers competing for wm_handler_operator_call.  The supplied Windows crash
    logs show Blender crashing in that path immediately after transform.translate.
    This function stores the temporary clone session, finishes the drag modal, and
    opens a small confirmation operator on the next UI tick.  The clone is not
    finalized as Copy/Instance until that confirmation operator executes.
    """
    try:
        if session.dialog_opened:
            _clear_modal_guard(operator)
            return _modal_finished_passthrough() if pass_through else _modal_finished_no_passthrough()
        session.dialog_opened = True
        try:
            operator._remove_timer(context)
        except Exception:
            pass
        token = uuid.uuid4().hex
        clone_type = str(getattr(operator, "clone_type", _default_clone_type()) or _default_clone_type())
        copy_count = int(getattr(operator, "copy_count", _default_copy_count()) or _default_copy_count())
        _PENDING_CONFIRM_SESSIONS[token] = (session, clone_type, copy_count)

        def _invoke_confirm():
            packed = _PENDING_CONFIRM_SESSIONS.get(token)
            if packed is None:
                return None
            sess, default_clone_type, default_copy_count = packed
            try:
                result = bpy.ops.view3d.max_shift_drag_clone_confirm(
                    "INVOKE_DEFAULT",
                    session_id=token,
                    clone_type=str(default_clone_type),
                    copy_count=int(default_copy_count),
                )
                if "CANCELLED" in result and token in _PENDING_CONFIRM_SESSIONS:
                    # If there is no valid UI context for a dialog, finish safely
                    # with the current defaults rather than leaving temporary data.
                    sess2, ct2, cc2 = _PENDING_CONFIRM_SESSIONS.pop(token)
                    _finish_session(bpy.context, sess2, str(ct2), int(cc2))
            except Exception as exc:
                _safe_log(f"confirmation dialog invoke failed: {exc}")
                packed2 = _PENDING_CONFIRM_SESSIONS.pop(token, None)
                if packed2 is not None:
                    sess2, ct2, cc2 = packed2
                    try:
                        _finish_session(bpy.context, sess2, str(ct2), int(cc2))
                    except Exception as finish_exc:
                        _safe_log(f"fallback finish after dialog failure failed: {finish_exc}")
            return None

        try:
            bpy.app.timers.register(_invoke_confirm, first_interval=0.01)
        except Exception as exc:
            _safe_log(f"confirmation timer registration failed: {exc}")
            _PENDING_CONFIRM_SESSIONS.pop(token, None)
            _finish_session(context, session, clone_type, copy_count)
            _clear_modal_guard(operator)
            return {"FINISHED"}
        _clear_modal_guard(operator)
        return _modal_finished_passthrough() if pass_through else _modal_finished_no_passthrough()
    except Exception as exc:
        _safe_log(f"schedule confirmation failed: {exc}")
        try:
            _cancel_session(context, session)
        except Exception:
            pass
        _clear_modal_guard(operator)
        return {"CANCELLED"}


def _event_xy(event: bpy.types.Event) -> tuple[int, int]:
    x = getattr(event, "mouse_region_x", None)
    y = getattr(event, "mouse_region_y", None)
    if x is None or y is None:
        x = getattr(event, "mouse_x", 0)
        y = getattr(event, "mouse_y", 0)
    return int(x or 0), int(y or 0)


def _drag_distance_sq(start_xy: tuple[int, int], event: bpy.types.Event) -> int:
    x, y = _event_xy(event)
    dx = x - int(start_xy[0])
    dy = y - int(start_xy[1])
    return dx * dx + dy * dy


def _event_is_left_drag_start(event: bpy.types.Event) -> bool:
    """Return True for the manual keymap events that should start Drag Clone.

    Blender can dispatch manually registered left-drag shortcuts either as a
    LEFTMOUSE PRESS/CLICK_DRAG event or as the higher-level EVT_TWEAK_L event.
    Older builds added the modal handler before checking this, so unrelated
    INVOKE_DEFAULT calls or unsupported event types could leave a dangling modal
    handler and crash Blender during shutdown.
    """
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
    except Exception:
        return False
    if event_type == "LEFTMOUSE" and event_value in {"PRESS", "CLICK_DRAG", "ANY"}:
        return True
    if event_type == "EVT_TWEAK_L" and event_value in {"ANY", "PRESS", "CLICK_DRAG", "NOTHING"}:
        return True
    return False


def _region_xy_from_absolute_event_xy(event: bpy.types.Event, absolute_x, absolute_y) -> tuple[int, int] | None:
    """Convert absolute window mouse coordinates from an event into region coordinates."""
    try:
        current_rx = getattr(event, "mouse_region_x", None)
        current_ry = getattr(event, "mouse_region_y", None)
        current_x = getattr(event, "mouse_x", None)
        current_y = getattr(event, "mouse_y", None)
        if None in (current_rx, current_ry, current_x, current_y, absolute_x, absolute_y):
            return None
        offset_x = int(current_rx or 0) - int(current_x or 0)
        offset_y = int(current_ry or 0) - int(current_y or 0)
        return int(absolute_x or 0) + offset_x, int(absolute_y or 0) + offset_y
    except Exception:
        return None


def _drag_start_xy_from_event(event: bpy.types.Event) -> tuple[int, int]:
    """Estimate the actual left-drag press point for manual keymap invocations.

    Normal-key key modifiers such as ``C + left drag`` often invoke the operator
    only after Blender has already promoted the pointer gesture to CLICK_DRAG or
    EVT_TWEAK_L.  Using that delayed event's current mouse position as the start
    makes the first transform delta zero and can leave the clone apparently
    locked.  Prefer the recorded left-button press coordinate, then the previous
    mouse coordinate, converted back into the current region coordinate space.
    """
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
        if event_type in {"EVT_TWEAK_L", "LEFTMOUSE"} and event_value in {"ANY", "PRESS", "CLICK_DRAG", "NOTHING"}:
            for attr_x, attr_y in (("mouse_prev_press_x", "mouse_prev_press_y"), ("mouse_prev_x", "mouse_prev_y")):
                converted = _region_xy_from_absolute_event_xy(event, getattr(event, attr_x, None), getattr(event, attr_y, None))
                if converted is not None:
                    return converted
    except Exception:
        pass
    return _event_xy(event)


def _event_mouse_xy_changed_since(event: bpy.types.Event, xy: tuple[int, int] | None, *, pixels: int = 1) -> bool:
    try:
        if xy is None:
            return False
        cx, cy = _event_xy(event)
        dx = int(cx) - int(xy[0])
        dy = int(cy) - int(xy[1])
        return (dx * dx + dy * dy) >= max(1, int(pixels)) * max(1, int(pixels))
    except Exception:
        return False


def _event_type_is_keyboard(event_type: str) -> bool:
    try:
        items = getattr(bpy.types.Event.bl_rna.properties["type"], "enum_items", ())
        item = items.get(event_type) if hasattr(items, "get") else None
        if item is not None:
            name = (str(getattr(item, "name", "") or "") + " " + str(getattr(item, "description", "") or "")).lower()
            if "mouse" in name or "timer" in name or "ndof" in name:
                return False
        return event_type not in {
            "NONE", "TIMER", "TIMER0", "TIMER1", "TIMER2", "TIMER_JOBS", "TIMER_AUTOSAVE", "TIMER_REPORT", "TIMERREGION",
            "MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "TRACKPADPAN", "TRACKPADZOOM",
            "LEFTMOUSE", "MIDDLEMOUSE", "RIGHTMOUSE", "BUTTON4MOUSE", "BUTTON5MOUSE", "BUTTON6MOUSE", "BUTTON7MOUSE",
            "EVT_TWEAK_L", "EVT_TWEAK_M", "EVT_TWEAK_R", "WHEELUPMOUSE", "WHEELDOWNMOUSE", "WHEELINMOUSE", "WHEELOUTMOUSE",
            "WINDOW_DEACTIVATE",
        }
    except Exception:
        return event_type not in {"", "NONE", "MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "LEFTMOUSE", "MIDDLEMOUSE", "RIGHTMOUSE", "EVT_TWEAK_L"}


def _keyboard_type_from_left_drag_event(event: bpy.types.Event) -> str:
    """Best-effort recovery of a normal key_modifier, e.g. C in C+left-drag."""
    try:
        event_type = str(getattr(event, "type", "") or "")
        if event_type in {"LEFTMOUSE", "EVT_TWEAK_L"}:
            for attr in ("type_prev",):
                candidate = str(getattr(event, attr, "") or "")
                if candidate and _event_type_is_keyboard(candidate):
                    return candidate
    except Exception:
        pass
    return ""


def _key_modifier_from_registered_drag_clone_keymaps(event: bpy.types.Event) -> str:
    """Return the normal key_modifier used by a manually registered Drag Clone KMI.

    Python's Event RNA exposes modifier booleans but not the keymodifier field
    visible in Blender's event debug output.  Recover it from the active/manual
    keymap entries so shortcuts such as C+left-drag can consume C auto-repeat
    while the drag is in progress.
    """
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
        if event_type not in {"LEFTMOUSE", "EVT_TWEAK_L"}:
            return ""
        wm = getattr(bpy.context, "window_manager", None)
        keyconfigs = getattr(wm, "keyconfigs", None) if wm is not None else None
        if keyconfigs is None:
            return ""
        target_id = MSDC_OT_drag_clone.bl_idname if "MSDC_OT_drag_clone" in globals() else "view3d.max_shift_drag_clone"
        config_names = ("user", "addon", "active", "default")
        for config_name in config_names:
            keyconfig = getattr(keyconfigs, config_name, None)
            if keyconfig is None:
                continue
            for km in list(getattr(keyconfig, "keymaps", []) or []):
                for kmi in list(getattr(km, "keymap_items", []) or []):
                    try:
                        if str(getattr(kmi, "idname", "") or "") != target_id:
                            continue
                        if not bool(getattr(kmi, "active", True)):
                            continue
                        kmi_type = str(getattr(kmi, "type", "") or "")
                        kmi_value = str(getattr(kmi, "value", "") or "")
                        if kmi_type not in {event_type, "EVT_TWEAK_L" if event_type == "LEFTMOUSE" else "LEFTMOUSE"}:
                            continue
                        if kmi_value not in {event_value, "ANY", "CLICK_DRAG"}:
                            continue
                        key_modifier = str(getattr(kmi, "key_modifier", "") or "")
                        if key_modifier and key_modifier != "NONE" and _event_type_is_keyboard(key_modifier):
                            return key_modifier
                    except Exception:
                        continue
    except Exception:
        pass
    return ""


def _event_should_drive_drag_motion(operator, event: bpy.types.Event) -> bool:
    """Return True when the event should update the direct drag transform.

    Blender can report mouse movement during a normal-key modifier drag as
    repeated key press events instead of MOUSEMOVE/EVT_TWEAK_L events.  This is
    common with shortcuts like ``C + left drag`` because the held normal key is
    auto-repeating while the pointer moves.  Treat those repeat events as drag
    motion for the active Drag Clone session and consume them so the normal key's
    own shortcut, such as Circle Select on C, cannot interfere during the drag.
    """
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
    except Exception:
        return False
    if event_type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "EVT_TWEAK_L"}:
        return True
    if event_type == "LEFTMOUSE" and event_value == "CLICK_DRAG":
        return True
    try:
        if bool(getattr(event, "is_repeat", False)) and event_value in {"PRESS", "CLICK", "NOTHING"}:
            key_modifier_type = str(getattr(operator, "_key_modifier_type", "") or "")
            if key_modifier_type and event_type == key_modifier_type:
                return True
            if _event_type_is_keyboard(event_type) and _event_mouse_xy_changed_since(event, getattr(operator, "_last_mouse_xy", None), pixels=1):
                return True
    except Exception:
        pass
    return False


def _event_should_be_consumed_as_drag_key(operator, event: bpy.types.Event) -> bool:
    try:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "")
        key_modifier_type = str(getattr(operator, "_key_modifier_type", "") or "")
        if key_modifier_type and event_type == key_modifier_type and event_value in {"PRESS", "RELEASE", "CLICK", "NOTHING"}:
            return True
        if bool(getattr(event, "is_repeat", False)) and _event_type_is_keyboard(event_type) and _event_mouse_xy_changed_since(event, getattr(operator, "_last_mouse_xy", None), pixels=1):
            return True
    except Exception:
        pass
    return False


def _matrix_has_meaningful_delta(current: Matrix, base: Matrix, epsilon: float = 1.0e-6) -> bool:
    try:
        for row in range(4):
            for col in range(4):
                if abs(float(current[row][col]) - float(base[row][col])) > epsilon:
                    return True
    except Exception:
        return False
    return False


def _session_has_transform_delta(session: _CloneSession | None, epsilon: float = 1.0e-6) -> bool:
    """Return whether Blender's native handler has already transformed the clone.

    Drag Clone first gives the real mouse/key event back to Blender's gizmo or
    Smart Gizmo.  The add-on fallback should move the visible copy only when no
    native transform delta appears.  This function intentionally checks the
    duplicated copy/component against its stored pre-drag source state without
    mutating the session, so it is safe to call repeatedly from modal events.
    """
    if session is None:
        return False
    try:
        for pair in list(getattr(session, "object_pairs", []) or []):
            clone = getattr(pair, "clone", None)
            if clone is None or getattr(clone, "name", "") not in bpy.data.objects:
                continue
            try:
                if _matrix_has_meaningful_delta(clone.matrix_world, pair.original_matrix, epsilon):
                    return True
            except Exception:
                continue
    except Exception:
        pass

    try:
        for state in list(getattr(session, "mesh_states", []) or []):
            obj = getattr(state, "obj", None)
            if obj is None or getattr(obj, "name", "") not in bpy.data.objects:
                continue
            if getattr(obj, "mode", "") != "EDIT" or bmesh is None:
                continue
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                for original_index, clone_index in zip(list(state.original_indices), list(state.clone_indices)):
                    if clone_index < 0 or clone_index >= len(bm.verts):
                        continue
                    base = state.clone_initial_coords.get(clone_index)
                    if base is None:
                        base = state.original_coords.get(original_index)
                    if base is None:
                        continue
                    if (bm.verts[clone_index].co - base).length > epsilon:
                        return True
            except Exception:
                continue
    except Exception:
        pass

    try:
        for state in list(getattr(session, "deferred_object_states", []) or []):
            obj = getattr(state, "original", None)
            if obj is None or getattr(obj, "name", "") not in bpy.data.objects:
                continue
            try:
                if _matrix_has_meaningful_delta(obj.matrix_world, state.original_matrix, epsilon):
                    return True
            except Exception:
                continue
    except Exception:
        pass

    try:
        for ref in list(getattr(session, "key_refs", []) or []):
            key = getattr(ref, "key", None)
            if key is None:
                continue
            try:
                if (key.co - ref.co).length > epsilon:
                    return True
            except Exception:
                continue
    except Exception:
        pass

    return False


def _session_reference_world_location(session: _CloneSession) -> Vector | None:
    try:
        packed_center = getattr(session, "fallback_center_world", None)
        if packed_center is not None:
            return Vector(tuple(float(v) for v in packed_center))
    except Exception:
        pass
    try:
        points: list[Vector] = []
        for pair in list(getattr(session, "object_pairs", []) or []):
            try:
                points.append(pair.original_matrix.translation.copy())
            except Exception:
                pass
        for state in list(getattr(session, "mesh_states", []) or []):
            try:
                mw = state.obj.matrix_world
                for idx in state.original_indices:
                    co = state.original_coords.get(idx)
                    if co is not None:
                        points.append(mw @ co)
            except Exception:
                pass
        if points:
            acc = Vector((0.0, 0.0, 0.0))
            for p in points:
                acc += p
            return acc / max(1, len(points))
    except Exception:
        pass
    return None


def _view3d_drag_world_delta(context: bpy.types.Context, start_xy: tuple[int, int], event: bpy.types.Event, session: _CloneSession) -> Vector | None:
    try:
        if ("" if context.area is None else context.area.type) != "VIEW_3D":
            return None
        if str(getattr(session, "transform_kind", "TRANSLATE") or "TRANSLATE") != "TRANSLATE":
            return None
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        depth = _session_reference_world_location(session) or _selected_transform_center(context)
        if depth is None:
            return None
        sx, sy = int(start_xy[0]), int(start_xy[1])
        cx, cy = _event_xy(event)
        start_loc = view3d_utils.region_2d_to_location_3d(region, rv3d, Vector((sx, sy)), depth)
        current_loc = view3d_utils.region_2d_to_location_3d(region, rv3d, Vector((cx, cy)), depth)
        if start_loc is None or current_loc is None:
            return None
        return current_loc - start_loc
    except Exception:
        return None


def _session_axis_world(session: _CloneSession) -> Vector | None:
    try:
        packed = getattr(session, "axis_world", None)
        if packed is None:
            return None
        axis = Vector(tuple(float(v) for v in packed))
        if axis.length <= 1.0e-8:
            return None
        axis.normalize()
        return axis
    except Exception:
        return None


def _view3d_axis_drag_scalar(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event, axis_world: Vector) -> float | None:
    try:
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _session_reference_world_location(session) or _selected_transform_center(context)
        if center is None:
            return None
        axis_len = _selection_scale_for_gizmo_probe(context)
        p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, center + axis_world.normalized() * axis_len)
        if p0 is None or p1 is None:
            return None
        a2 = Vector((float(p1.x - p0.x), float(p1.y - p0.y)))
        if a2.length <= 1.0e-4:
            return None
        pixels_per_world = a2.length / max(axis_len, 1.0e-6)
        a2.normalize()
        sx, sy = int(start_xy[0]), int(start_xy[1])
        cx, cy = _event_xy(event)
        mouse_delta = Vector((float(cx - sx), float(cy - sy)))
        signed_pixels = float(mouse_delta.dot(a2))
        return signed_pixels / max(pixels_per_world, 1.0e-6)
    except Exception:
        return None


def _axis_scale_matrix(axis_world: Vector, factor: float) -> Matrix:
    axis = axis_world.normalized()
    f = float(factor) - 1.0
    return Matrix((
        (1.0 + f * axis.x * axis.x, f * axis.x * axis.y, f * axis.x * axis.z, 0.0),
        (f * axis.y * axis.x, 1.0 + f * axis.y * axis.y, f * axis.y * axis.z, 0.0),
        (f * axis.z * axis.x, f * axis.z * axis.y, 1.0 + f * axis.z * axis.z, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    ))


def _apply_world_transform_to_session_clones(context: bpy.types.Context, session: _CloneSession, transform: Matrix) -> bool:
    changed = False
    try:
        if getattr(session, "object_pairs", None):
            for pair in list(session.object_pairs):
                try:
                    if pair.clone is not None and getattr(pair.clone, "name", "") in bpy.data.objects:
                        pair.clone.matrix_world = transform @ pair.original_matrix
                        changed = True
                except Exception:
                    pass
        elif getattr(session, "mesh_states", None):
            _ensure_bmesh()
            for state in list(session.mesh_states):
                try:
                    bm = bmesh.from_edit_mesh(state.obj.data)
                    bm.verts.ensure_lookup_table()
                    inv = state.obj.matrix_world.inverted_safe()
                    mw = state.obj.matrix_world
                    for original_index, clone_index in zip(state.original_indices, state.clone_indices):
                        if clone_index >= len(bm.verts):
                            continue
                        base = state.clone_initial_coords.get(clone_index)
                        if base is None:
                            base = state.original_coords.get(original_index)
                        if base is None:
                            continue
                        bm.verts[clone_index].co = inv @ (transform @ (mw @ base))
                        changed = True
                    bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
        elif getattr(session, "deferred_object_states", None):
            for state in list(session.deferred_object_states):
                try:
                    obj = state.original
                    if obj is not None and getattr(obj, "name", "") in bpy.data.objects:
                        obj.matrix_world = transform @ state.original_matrix
                        changed = True
                except Exception:
                    pass
        if changed:
            try:
                context.view_layer.update()
            except Exception:
                pass
    except Exception:
        return False
    return bool(changed)


def _event_modifier_active_for_transform(event: bpy.types.Event, name: str, session: _CloneSession | None = None) -> bool:
    """Return modifier-key state after subtracting keys used to start Drag Clone.

    Manual Drag Clone is commonly bound to Shift+left-drag or Ctrl+left-drag.
    Those modifier keys should start the clone but must not automatically force
    precision mode or snapping for the whole drag.  After the trigger event,
    only newly pressed modifier states are treated as transform modifiers.
    """
    try:
        key = str(name or "").lower()
        active = bool(getattr(event, key, False))
    except Exception:
        return False
    if not active or session is None:
        return active
    try:
        if key == "shift" and bool(getattr(session, "trigger_shift", False)):
            return False
        if key == "ctrl" and bool(getattr(session, "trigger_ctrl", False)):
            return False
        if key == "alt" and bool(getattr(session, "trigger_alt", False)):
            return False
        if key == "oskey" and bool(getattr(session, "trigger_oskey", False)):
            return False
    except Exception:
        pass
    return active


def _precision_factor_from_event(event: bpy.types.Event, session: _CloneSession | None = None) -> float:
    try:
        return 0.1 if _event_modifier_active_for_transform(event, "shift", session) else 1.0
    except Exception:
        return 1.0


def _snap_enabled_from_event(context: bpy.types.Context, event: bpy.types.Event, session: _CloneSession | None = None) -> bool:
    try:
        if _event_modifier_active_for_transform(event, "ctrl", session):
            return True
    except Exception:
        pass
    try:
        tool_settings = getattr(context, "tool_settings", None)
        return bool(getattr(tool_settings, "use_snap", False))
    except Exception:
        return False


def _snap_step_for_translate(context: bpy.types.Context, event: bpy.types.Event, session: _CloneSession | None = None) -> float:
    step = 1.0
    try:
        scene = getattr(context, "scene", None)
        unit_settings = getattr(scene, "unit_settings", None)
        scale_length = float(getattr(unit_settings, "scale_length", 1.0) or 1.0)
        if scale_length > 1.0e-8:
            step = scale_length
    except Exception:
        pass
    try:
        if _event_modifier_active_for_transform(event, "shift", session):
            step *= 0.1
    except Exception:
        pass
    return max(float(step), 1.0e-6)


def _snap_step_for_rotate(_context: bpy.types.Context, event: bpy.types.Event, session: _CloneSession | None = None) -> float:
    try:
        return math.radians(1.0 if _event_modifier_active_for_transform(event, "shift", session) else 5.0)
    except Exception:
        return math.radians(5.0)


def _snap_step_for_scale(_context: bpy.types.Context, event: bpy.types.Event, session: _CloneSession | None = None) -> float:
    try:
        return 0.01 if _event_modifier_active_for_transform(event, "shift", session) else 0.1
    except Exception:
        return 0.1


def _snap_scalar(value: float, step: float) -> float:
    try:
        step = max(float(step), 1.0e-8)
        return round(float(value) / step) * step
    except Exception:
        return float(value)


def _apply_precision_and_snap_to_delta(context: bpy.types.Context, event: bpy.types.Event, delta: Vector, session: _CloneSession | None = None) -> Vector:
    result = delta.copy()
    try:
        precision = _precision_factor_from_event(event, session)
        if precision != 1.0:
            result *= precision
    except Exception:
        pass
    if _snap_enabled_from_event(context, event, session):
        try:
            step = _snap_step_for_translate(context, event, session)
            result = Vector((_snap_scalar(result.x, step), _snap_scalar(result.y, step), _snap_scalar(result.z, step)))
        except Exception:
            pass
    return result


def _apply_precision_and_snap_to_scalar(context: bpy.types.Context, event: bpy.types.Event, value: float, *, kind: str, session: _CloneSession | None = None) -> float:
    result = float(value)
    try:
        precision = _precision_factor_from_event(event, session)
        if precision != 1.0:
            result *= precision
    except Exception:
        pass
    if _snap_enabled_from_event(context, event, session):
        try:
            upper = str(kind or "").upper()
            if upper == "ROTATE":
                step = _snap_step_for_rotate(context, event, session)
            elif upper == "SCALE":
                step = _snap_step_for_scale(context, event, session)
            else:
                step = _snap_step_for_translate(context, event, session)
            result = _snap_scalar(result, step)
        except Exception:
            pass
    return float(result)


def _apply_view3d_translate_fallback(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event) -> bool:
    delta = _view3d_drag_world_delta(context, start_xy, event, session)
    axis = _ensure_session_axis_from_drag(context, session, start_xy, event, "TRANSLATE")
    if axis is not None:
        scalar = _view3d_axis_drag_scalar(context, session, start_xy, event, axis)
        if scalar is not None:
            scalar = _apply_precision_and_snap_to_scalar(context, event, float(scalar), kind="TRANSLATE", session=session)
            delta = axis * float(scalar)
        elif delta is not None:
            scalar = _apply_precision_and_snap_to_scalar(context, event, float(delta.dot(axis)), kind="TRANSLATE", session=session)
            delta = axis * float(scalar)
    elif delta is not None:
        delta = _apply_precision_and_snap_to_delta(context, event, delta, session=session)
    if delta is None:
        return False
    transform = Matrix.Translation(delta)
    return _apply_world_transform_to_session_clones(context, session, transform)


def _view3d_rotation_drag_angle(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event, axis_world: Vector) -> float | None:
    try:
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _session_reference_world_location(session) or _selected_transform_center(context)
        if center is None:
            return None
        center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        if center_2d is None:
            return None
        sx, sy = int(start_xy[0]), int(start_xy[1])
        cx, cy = _event_xy(event)
        v0 = Vector((float(sx - center_2d.x), float(sy - center_2d.y)))
        v1 = Vector((float(cx - center_2d.x), float(cy - center_2d.y)))
        if v0.length <= 2.0 or v1.length <= 2.0:
            return None
        cross = float(v0.x * v1.y - v0.y * v1.x)
        dot = float(v0.dot(v1))
        angle = math.atan2(cross, dot)
        try:
            if float(axis_world.normalized().dot(_view_direction_world(context))) < 0.0:
                angle = -angle
        except Exception:
            pass
        return angle
    except Exception:
        return None


def _apply_view3d_rotate_fallback(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event) -> bool:
    center = _session_reference_world_location(session) or _selected_transform_center(context)
    if center is None:
        return False
    axis = _session_axis_world(session) or _view_direction_world(context)
    if axis.length <= 1.0e-8:
        return False
    axis.normalize()
    angle = _view3d_rotation_drag_angle(context, session, start_xy, event, axis)
    if angle is None:
        return False
    angle = _apply_precision_and_snap_to_scalar(context, event, float(angle), kind="ROTATE", session=session)
    transform = Matrix.Translation(center) @ Matrix.Rotation(float(angle), 4, axis) @ Matrix.Translation(-center)
    return _apply_world_transform_to_session_clones(context, session, transform)


def _view3d_scale_drag_factor(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event, axis_world: Vector | None) -> float | None:
    try:
        if axis_world is not None:
            scalar = _view3d_axis_drag_scalar(context, session, start_xy, event, axis_world)
            if scalar is None:
                return None
            denom = max(_selection_scale_for_gizmo_probe(context), 1.0e-6)
            return max(0.001, 1.0 + float(scalar) / denom)
        region, rv3d = _view3d_window_region_and_data(context)
        if region is None or rv3d is None:
            return None
        try:
            from bpy_extras import view3d_utils
        except Exception:
            return None
        center = _session_reference_world_location(session) or _selected_transform_center(context)
        if center is None:
            return None
        c2 = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
        if c2 is None:
            return None
        sx, sy = int(start_xy[0]), int(start_xy[1])
        cx, cy = _event_xy(event)
        d0 = Vector((float(sx - c2.x), float(sy - c2.y))).length
        d1 = Vector((float(cx - c2.x), float(cy - c2.y))).length
        if d0 <= 2.0:
            # Center-handle scale fallback: use horizontal drag as a stable uniform factor.
            d1 = float(cx - sx)
            return max(0.001, 1.0 + d1 / 120.0)
        return max(0.001, float(d1) / max(float(d0), 1.0e-6))
    except Exception:
        return None


def _apply_view3d_scale_fallback(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event) -> bool:
    center = _session_reference_world_location(session) or _selected_transform_center(context)
    if center is None:
        return False
    axis = _ensure_session_axis_from_drag(context, session, start_xy, event, "SCALE")
    factor = _view3d_scale_drag_factor(context, session, start_xy, event, axis)
    if factor is None:
        return False
    try:
        factor = 1.0 + (float(factor) - 1.0) * _precision_factor_from_event(event, session)
        if _snap_enabled_from_event(context, event, session):
            step = _snap_step_for_scale(context, event, session)
            factor = _snap_scalar(float(factor), step)
        factor = max(0.001, float(factor))
    except Exception:
        factor = max(0.001, float(factor))
    if axis is not None:
        scale = _axis_scale_matrix(axis, float(factor))
    else:
        scale = Matrix.Diagonal((float(factor), float(factor), float(factor), 1.0))
    transform = Matrix.Translation(center) @ scale @ Matrix.Translation(-center)
    return _apply_world_transform_to_session_clones(context, session, transform)


def _apply_view3d_transform_fallback(context: bpy.types.Context, session: _CloneSession, start_xy: tuple[int, int], event: bpy.types.Event) -> bool:
    kind = str(getattr(session, "transform_kind", "TRANSLATE") or "TRANSLATE").upper()
    if kind == "ROTATE":
        return _apply_view3d_rotate_fallback(context, session, start_xy, event)
    if kind == "SCALE":
        return _apply_view3d_scale_fallback(context, session, start_xy, event)
    return _apply_view3d_translate_fallback(context, session, start_xy, event)


def _drag_modal_context_override_args(operator, context: bpy.types.Context) -> dict | None:
    try:
        area = getattr(operator, "_drag_area", None)
        region = getattr(operator, "_drag_region", None)
        if area is None or region is None:
            return None
        if str(getattr(area, "type", "") or "") != "VIEW_3D":
            return None
        if str(getattr(region, "type", "") or "") != "WINDOW":
            return None
        return _operator_context_override_args(context, area, region)
    except Exception:
        return None


class MSDC_OT_drag_clone(bpy.types.Operator):
    bl_idname = "view3d.max_shift_drag_clone"
    bl_label = "Drag Clone"
    bl_description = "Clone the current selection at left-drag start, transform the clone directly during the drag, and confirm with clone options."
    bl_options = {"UNDO"}

    clone_type: EnumProperty(
        name="Clone Type",
        description="Choose the object clone type when the confirmation dialog appears after releasing the left mouse button. Copy creates independent object data; Instance shares object data with the source object where Blender supports linked data.",
        items=(
            ("COPY", "Copy", "Create a normal independent copy of the cloned object data."),
            ("INSTANCE", "Instance", "Create an instance-style linked duplicate that shares object data with the source object where Blender supports it."),
        ),
        default="COPY",
    )
    copy_count: IntProperty(
        name="Number of Copies",
        description="Set the total number of copies to create after the first drag result. A value of 1 keeps only the dragged copy; higher values repeat the same move, rotate, scale, mesh edit, or keyframe offset successively.",
        default=1,
        min=1,
        soft_max=100,
    )
    watcher_mode: BoolProperty(
        default=False,
        options={"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        try:
            area_type = "" if context.area is None else context.area.type
            # The modal transform must only be launched from editors that provide
            # a valid WINDOW region for transform.  Allowing global Window/Object
            # keymaps to invoke this operator from the Outliner, Properties editor,
            # or other non-transform areas can crash Blender 5.1 when transform is
            # started from an invalid area context.
            if area_type not in {"VIEW_3D", "GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
                return False
            if area_type in {"GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
                return True
            if context.mode == "OBJECT":
                return bool(context.selected_objects)
            return context.active_object is not None
        except Exception:
            return False

    def _remove_timer(self, context: bpy.types.Context) -> None:
        try:
            session = getattr(self, "_session", None)
            timer = getattr(session, "timer", None) if session is not None else None
            if timer is not None:
                try:
                    context.window_manager.event_timer_remove(timer)
                except Exception:
                    pass
                try:
                    session.timer = None
                except Exception:
                    pass
        except Exception:
            pass

    def _end_without_clone(self) -> set[str]:
        try:
            _clear_modal_guard(self)
        except Exception:
            pass
        return {"CANCELLED"}

    def _safe_cancel_current_session(self, context: bpy.types.Context) -> None:
        try:
            session = getattr(self, "_session", None)
            if session is not None:
                self._remove_timer(context)
                _cancel_session(context, session)
        except Exception as exc:
            _safe_log(f"cancel cleanup failed: {exc}")
        finally:
            try:
                _clear_modal_guard(self)
            except Exception:
                pass

    def _add_modal_handler_once(self, context: bpy.types.Context) -> None:
        if not getattr(self, "_modal_handler_added", False):
            try:
                context.window_manager.modal_handler_add(self)
                self._modal_handler_added = True
            except Exception as exc:
                _safe_log(f"modal handler add failed: {exc}")

    def _activate_clone_modal_guard(self, context: bpy.types.Context) -> None:
        global _MSDC_MODAL_ACTIVE
        _MSDC_MODAL_ACTIVE = True
        self._owns_modal_guard = True
        _temporarily_suspend_own_keymaps(self)
        self._add_modal_handler_once(context)

    def _reset_to_keymap_watcher(self) -> None:
        try:
            self._session = None
            self._phase = "WATCH"
            self._watch_key_specs = []
            self._watch_key_held = None
            self._trigger_key = "NONE"
            self._trigger_key_held = False
            self._owns_modal_guard = False
            self._sms_keymap_restore = None
            self._moved_after_press = False
            self._native_handoff_move_events = 0
            self._drag_area = None
            self._drag_region = None
            self._drag_space = None
            self._key_modifier_type = ""
            self._last_mouse_xy = (0, 0)
        except Exception:
            pass

    def _invoke_keymap_watcher(self, context: bpy.types.Context, _event: bpy.types.Event) -> set[str]:
        global _MSDC_WATCHER_RUNNING
        if _MSDC_WATCHER_RUNNING:
            return {"CANCELLED"}
        _MSDC_WATCHER_RUNNING = True
        self._watcher_instance = True
        self._modal_handler_added = False
        self._reset_to_keymap_watcher()
        self._add_modal_handler_once(context)
        return {"RUNNING_MODAL"}

    def _modal_keymap_watcher(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        global _MSDC_WATCHER_RUNNING
        try:
            if not _MSDC_WATCHER_ENABLED:
                _MSDC_WATCHER_RUNNING = False
                return {"CANCELLED"}
            event_type = str(getattr(event, "type", "") or "")
            event_value = str(getattr(event, "value", "") or "")

            held_key = getattr(self, "_watch_key_held", None)
            held_specs = list(getattr(self, "_watch_key_specs", []) or [])

            if held_key is None:
                if event_value == "PRESS":
                    specs = [
                        spec for spec in _manual_drag_clone_key_modifier_specs()
                        if spec.key_modifier == event_type and _event_modifier_matches_keymap_spec(event, spec)
                    ]
                    if specs:
                        self._watch_key_held = event_type
                        self._watch_key_specs = specs
                        self._key_modifier_type = event_type
                        # Consume only the normal key the user manually assigned
                        # as Drag Clone's key_modifier.  This prevents built-in
                        # single-key tools such as C / Circle Select from entering
                        # their own modal handler before the following left-drag.
                        return {"RUNNING_MODAL"}
                return _modal_passthrough_running()

            if event_type == held_key and event_value in {"RELEASE", "CLICK"}:
                self._watch_key_held = None
                self._watch_key_specs = []
                return {"RUNNING_MODAL"}

            if _event_is_left_drag_start(event):
                matched = [spec for spec in held_specs if _event_matches_manual_drag_mouse_spec(event, spec)]
                if matched:
                    self._activate_clone_modal_guard(context)
                    result = self._begin_clone_modal(context, event)
                    if "CANCELLED" in result:
                        self._reset_to_keymap_watcher()
                        return {"RUNNING_MODAL"}
                    return result
                return {"RUNNING_MODAL"}

            # While the normal key is held, keep consuming its repeat events so
            # the ordinary key action does not start before the left-drag.  Mouse
            # movement and unrelated viewport events pass through normally.
            if event_type == held_key:
                return {"RUNNING_MODAL"}
            return _modal_passthrough_running()
        except Exception as exc:
            _safe_log(f"keymap watcher failed: {exc}")
            _MSDC_WATCHER_RUNNING = False
            return {"CANCELLED"}

    def _begin_clone_modal(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        try:
            if getattr(self, "_session", None) is not None:
                return {"RUNNING_MODAL"}

            area, region = _supported_area_under_event(context, event)
            if area is None or region is None:
                _safe_log("clone ignored: no supported editor under the mouse event")
                _clear_modal_guard(self)
                return {"CANCELLED"}

            self._drag_area = area
            self._drag_region = region
            try:
                self._drag_space = getattr(getattr(area, "spaces", None), "active", None)
            except Exception:
                self._drag_space = None

            override_args = _operator_context_override_args(context, area, region)
            with context.temp_override(**override_args):
                octx = bpy.context
                self.clone_type = _default_clone_type()
                self.copy_count = _default_copy_count()
                transform_kind = _resolve_transform_kind(octx)
                axis_constraint = None
                axis_world = None
                center_world = None
                try:
                    if ("" if octx.area is None else octx.area.type) == "VIEW_3D":
                        transform_kind, axis_constraint = _infer_gizmo_transform_from_drag_origin(octx, event, transform_kind)
                        axis_world_vec = _world_axis_from_constraint(octx, axis_constraint)
                        if axis_world_vec is not None:
                            axis_world = (float(axis_world_vec.x), float(axis_world_vec.y), float(axis_world_vec.z))
                        center_vec = _selected_transform_center(octx)
                        if center_vec is not None:
                            center_world = (float(center_vec.x), float(center_vec.y), float(center_vec.z))
                except Exception:
                    axis_constraint = None
                    axis_world = None
                    center_world = None
                area_type = "" if octx.area is None else octx.area.type
                # View3D drag cloning is handled directly by this add-on.  The clone
                # is created at the left-button press and translated/rotated/scaled
                # from mouse movement until release, so the selection cannot be left
                # locked waiting for a native transform handler that may never take
                # over the event.
                session = _duplicate_for_session(octx, transform_kind)
                if area_type == "VIEW_3D":
                    # Preserve Smart Gizmo / transform-gizmo native behavior,
                    # including custom U/V axes, by handing the real drag event
                    # back after the clone has become the active selection.
                    # Plain selection/free drags continue to use the safe direct
                    # fallback so they do not appear locked when no native
                    # transform handler owns the event.
                    session.native_handoff = _view3d_native_gizmo_handoff_required(octx)
                elif area_type in {"GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
                    session.native_handoff = True
                else:
                    session.native_handoff = False
                try:
                    session.axis_constraint = axis_constraint
                    session.axis_world = axis_world
                    session.fallback_center_world = center_world
                    session.trigger_shift = bool(getattr(event, "shift", False))
                    session.trigger_ctrl = bool(getattr(event, "ctrl", False))
                    session.trigger_alt = bool(getattr(event, "alt", False))
                    session.trigger_oskey = bool(getattr(event, "oskey", False))
                except Exception:
                    pass
                self._session = session
                self._phase = "CLONE"
                self._mouse_start_xy = _drag_start_xy_from_event(event)
                self._last_mouse_xy = _event_xy(event)
                try:
                    key_modifier_type = _keyboard_type_from_left_drag_event(event) or _key_modifier_from_registered_drag_clone_keymaps(event)
                    if key_modifier_type:
                        self._key_modifier_type = key_modifier_type
                except Exception:
                    pass
                self._moved_after_press = False
                self._native_handoff_move_events = 0
                try:
                    if (
                        area_type == "VIEW_3D"
                        and not bool(getattr(session, "native_handoff", False))
                        and _drag_distance_sq(self._mouse_start_xy, event) >= (_DRAG_START_PIXELS * _DRAG_START_PIXELS)
                    ):
                        self._moved_after_press = True
                        if _apply_view3d_transform_fallback(octx, session, self._mouse_start_xy, event):
                            session.native_handoff_fallback_started = True
                except Exception as exc:
                    _safe_log(f"initial drag transform failed: {exc}")


            # View3D direct drag clone receives real mouse move/release events; it
            # does not need a timer.  Avoiding an unnecessary timer removes one
            # more native event handler from the crash-prone left-drag path.
            session.timer = None
            if session.native_handoff:
                return _modal_passthrough_running()
            return {"RUNNING_MODAL"}
        except Exception as exc:
            _safe_log(f"begin clone failed: {exc}")
            self._safe_cancel_current_session(context)
            return {"CANCELLED"}

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        try:
            return self._invoke_impl(context, event)
        except Exception as exc:
            _safe_log(f"invoke failed: {exc}")
            self._safe_cancel_current_session(context)
            return {"CANCELLED"}

    def _invoke_impl(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        global _MSDC_MODAL_ACTIVE
        if bool(getattr(self, "watcher_mode", False)):
            # Safety policy: never start a persistent modal watcher from add-on registration.
            # Normal-key key_modifier shortcuts must be handled only by Blender's explicitly
            # invoked manual keymap item so ordinary View3D shortcuts and mouse operations
            # remain untouched after installation.
            return {"CANCELLED"}
        if _MSDC_MODAL_ACTIVE:
            return {"PASS_THROUGH"}

        trigger_key = _trigger_key()
        event_type = str(getattr(event, "type", ""))
        event_value = str(getattr(event, "value", ""))

        self._session = None
        self._phase = "WAIT_MOUSE"
        self._mouse_start_xy = _event_xy(event)
        self._trigger_key = trigger_key
        self._trigger_key_held = False
        self._owns_modal_guard = False
        self._modal_handler_added = False
        self._sms_keymap_restore = None
        self._moved_after_press = False
        self._native_handoff_move_events = 0
        self._drag_area = None
        self._drag_region = None
        self._drag_space = None
        self._key_modifier_type = ""
        self._last_mouse_xy = self._mouse_start_xy

        if not _event_matches_preferences(context, event):
            return {"PASS_THROUGH"}

        def _activate_modal_guard() -> None:
            global _MSDC_MODAL_ACTIVE
            _MSDC_MODAL_ACTIVE = True
            self._owns_modal_guard = True
            _temporarily_suspend_own_keymaps(self)
            self._add_modal_handler_once(context)

        # G/R/S are transform operators, not pointer tools.  For these trigger keys,
        # duplicate immediately and pass the original key event through so Blender's
        # standard G/R/S or Smart G/R/S operator starts on the cloned selection.
        # No Blender modal transform operators call is made by this add-on, avoiding the Windows
        # wm_handler_operator_call crash path and preserving the native transform.
        if trigger_key in {"G", "R", "S"} and event_type == trigger_key and event_value in {"PRESS", "CLICK"}:
            _activate_modal_guard()
            return self._begin_clone_modal(context, event)

        # A non-modifier trigger key such as A, F4, or Numpad 1 starts a short modal
        # latch.  The clone is created on the following left mouse press, so Blender's
        # current mouse position and the still-held left button are available to the
        # native gizmo or active tool handler.
        if trigger_key != "NONE" and event_type == trigger_key and event_value in {"PRESS", "CLICK"}:
            _activate_modal_guard()
            self._phase = "WAIT_MOUSE"
            self._trigger_key_held = True
            return {"RUNNING_MODAL"}

        # Modifier-only shortcuts and key_modifier fallback shortcuts enter here.
        # Start at LEFTMOUSE PRESS/CLICK_DRAG or Blender's EVT_TWEAK_L left-drag
        # event.  Unsupported INVOKE_DEFAULT calls must pass through without adding
        # a modal handler; adding then passing through is a native crash source.
        if _event_is_left_drag_start(event):
            _activate_modal_guard()
            return self._begin_clone_modal(context, event)

        return {"PASS_THROUGH"}

    def _modal_wait_mouse(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        try:
            event_type = str(getattr(event, "type", ""))
            event_value = str(getattr(event, "value", ""))
            trigger_key = getattr(self, "_trigger_key", "NONE")

            if trigger_key != "NONE" and event_type == trigger_key and event_value == "RELEASE":
                return self._end_without_clone()
            if event_type in {"ESC", "RIGHTMOUSE"}:
                return self._end_without_clone()
            if _event_is_left_drag_start(event):
                if not _event_matches_preferences(context, event):
                    return self._end_without_clone()
                return self._begin_clone_modal(context, event)
            return {"RUNNING_MODAL"}
        except Exception as exc:
            _safe_log(f"wait mouse failed: {exc}")
            self._safe_cancel_current_session(context)
            return {"CANCELLED"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        try:
            if bool(getattr(self, "_watcher_instance", False)) and getattr(self, "_phase", "WATCH") == "WATCH":
                return self._modal_keymap_watcher(context, event)
            result = self._modal_impl(context, event)
            if bool(getattr(self, "_watcher_instance", False)) and ("FINISHED" in result or "CANCELLED" in result):
                pass_through = "PASS_THROUGH" in result
                self._reset_to_keymap_watcher()
                return _modal_passthrough_running() if pass_through else {"RUNNING_MODAL"}
            return result
        except Exception as exc:
            _safe_log(f"modal failed: {exc}")
            self._safe_cancel_current_session(context)
            if bool(getattr(self, "_watcher_instance", False)):
                self._reset_to_keymap_watcher()
                return {"RUNNING_MODAL"}
            return {"CANCELLED"}

    def _modal_impl(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        phase = getattr(self, "_phase", "CLONE")
        if phase == "WAIT_MOUSE":
            return self._modal_wait_mouse(context, event)

        session: _CloneSession | None = getattr(self, "_session", None)
        if session is None:
            _clear_modal_guard(self)
            return {"CANCELLED"}

        event_type = str(getattr(event, "type", ""))
        event_value = str(getattr(event, "value", ""))

        is_drag_motion_event = _event_should_drive_drag_motion(self, event)
        if is_drag_motion_event:
            start_xy = getattr(self, "_mouse_start_xy", (0, 0))
            moved_enough = _drag_distance_sq(start_xy, event) >= (_DRAG_START_PIXELS * _DRAG_START_PIXELS)
            try:
                self._last_mouse_xy = _event_xy(event)
            except Exception:
                pass
            if bool(getattr(session, "native_handoff", False)):
                # Do not synthesize fallback transforms while Smart Gizmo or a
                # native transform gizmo owns the drag.  Native pass-through is
                # the only path that can preserve custom U/V handles exactly.
                if moved_enough or _session_has_transform_delta(session):
                    self._moved_after_press = True
                return _modal_passthrough_running()
            if moved_enough:
                self._moved_after_press = True
                try:
                    self._native_handoff_move_events = int(getattr(self, "_native_handoff_move_events", 0) or 0) + 1
                except Exception:
                    self._native_handoff_move_events = 1
                if getattr(session, "area_type", "") == "VIEW_3D":
                    applied = False
                    override_args = _drag_modal_context_override_args(self, context)
                    if override_args is not None:
                        try:
                            with context.temp_override(**override_args):
                                applied = _apply_view3d_transform_fallback(bpy.context, session, start_xy, event)
                        except Exception as exc:
                            _safe_log(f"drag fallback override failed: {exc}")
                            applied = False
                    if not applied:
                        applied = _apply_view3d_transform_fallback(context, session, start_xy, event)
                    if applied:
                        session.native_handoff_fallback_started = True
                    return {"RUNNING_MODAL"}
            return {"RUNNING_MODAL"}

        if _event_should_be_consumed_as_drag_key(self, event):
            try:
                self._last_mouse_xy = _event_xy(event)
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            if getattr(session, "deferred_object_states", None):
                _capture_deferred_object_final_matrices(session)
            session.released = True
            if getattr(session, "area_type", "") == "VIEW_3D" and not bool(getattr(session, "native_handoff", False)):
                if not bool(getattr(self, "_moved_after_press", True)) and not _session_has_transform_delta(session):
                    _cancel_session(context, session)
                    _clear_modal_guard(self)
                    return {"CANCELLED"}
                # Open the confirmation through the separate confirmation operator
                # on the next UI tick.  Do not invoke a properties dialog on this
                # still-running modal operator; that modal/dialog overlap can crash
                # Blender during left-drag finalization.
                return _schedule_view3d_confirmation(context, self, session, pass_through=False)
            if bool(getattr(session, "native_handoff", False)):
                if not bool(getattr(self, "_moved_after_press", True)) and not _session_has_transform_delta(session):
                    _cancel_session(context, session)
                    _clear_modal_guard(self)
                    return _modal_finished_passthrough()
                return _schedule_view3d_confirmation(context, self, session, pass_through=(not bool(getattr(session, "native_handoff_fallback_started", False))))
            return _modal_passthrough_running()

        if event_type in {"RET", "NUMPAD_ENTER", "SPACE"} and event_value in {"PRESS", "RELEASE"}:
            # Keyboard-confirmed G/R/S transforms do not always produce a left-mouse
            # release event for this operator.  For View3D handoff, schedule the
            # confirmation dialog on the next UI tick and finish this modal handler
            # so it cannot collide with Blender's native transform finalization.
            if getattr(session, "deferred_object_states", None):
                _capture_deferred_object_final_matrices(session)
            session.released = True
            if bool(getattr(session, "native_handoff", False)):
                return _schedule_view3d_confirmation(context, self, session, pass_through=(not bool(getattr(session, "native_handoff_fallback_started", False))))
            return _modal_passthrough_running()

        if event_type in {"ESC", "RIGHTMOUSE"} and not session.dialog_opened:
            session.cancel_requested = True
            _cancel_session(context, session)
            _clear_modal_guard(self)
            return _modal_finished_passthrough() if bool(getattr(session, "native_handoff", False)) else {"CANCELLED"}

        if event_type == "TIMER":
            if bool(getattr(session, "native_handoff", False)):
                return _modal_passthrough_running()
            event_timer = getattr(event, "timer", None)
            if event_timer is not None and session.timer is not None and event_timer != session.timer:
                return _modal_passthrough_running()
            if session.cancel_requested:
                self._remove_timer(context)
                _cancel_session(context, session)
                _clear_modal_guard(self)
                return {"CANCELLED"}
            if session.released and not session.dialog_opened:
                # A plain click without any actual drag should not leave a duplicate.
                # This preserves normal click workflows while the keymap starts at
                # LEFTMOUSE PRESS for reliable modal transform hand-off.
                if getattr(session, "deferred_object_states", None):
                    _capture_deferred_object_final_matrices(session)
                if not bool(getattr(self, "_moved_after_press", True)) and not _session_has_transform_delta(session):
                    self._remove_timer(context)
                    _cancel_session(context, session)
                    _clear_modal_guard(self)
                    return {"CANCELLED"}
                return _schedule_view3d_confirmation(context, self, session, pass_through=False)
            return _modal_passthrough_running()

        return _modal_passthrough_running()

    def execute(self, context: bpy.types.Context) -> set[str]:
        try:
            session: _CloneSession | None = getattr(self, "_session", None)
            if session is None:
                _clear_modal_guard(self)
                return {"CANCELLED"}
            _finish_session(context, session, self.clone_type, self.copy_count)
            _clear_modal_guard(self)
            return {"FINISHED"}
        except Exception as exc:
            _safe_log(f"execute failed: {exc}")
            self._safe_cancel_current_session(context)
            return {"CANCELLED"}

    def cancel(self, context: bpy.types.Context) -> None:
        global _MSDC_WATCHER_RUNNING
        try:
            if bool(getattr(self, "_watcher_instance", False)):
                _MSDC_WATCHER_RUNNING = False
            self._safe_cancel_current_session(context)
        except Exception:
            try:
                _clear_modal_guard(self)
            except Exception:
                pass


class MSDC_OT_drag_clone_confirm(bpy.types.Operator):
    bl_idname = "view3d.max_shift_drag_clone_confirm"
    bl_label = "Drag Clone Options"
    bl_description = "Confirm the clone type and copy count before the temporary drag clone is committed."
    bl_options = {"UNDO", "INTERNAL"}

    session_id: StringProperty(options={"SKIP_SAVE"})
    clone_type: EnumProperty(
        name="Clone Type",
        description="Choose the object clone type before the temporary drag clone is committed. Copy creates independent object data; Instance shares object data with the source object where Blender supports linked data.",
        items=(
            ("COPY", "Copy", "Create a normal independent copy of the cloned object data."),
            ("INSTANCE", "Instance", "Create an instance-style linked duplicate that shares object data with the source object where Blender supports it."),
        ),
        default="COPY",
    )
    copy_count: IntProperty(
        name="Number of Copies",
        description="Set the total number of copies to create. The dragged clone is copy 1; higher values repeat the same transform interval successively.",
        default=1,
        min=1,
        soft_max=100,
    )

    @classmethod
    def poll(cls, _context: bpy.types.Context) -> bool:
        return True

    def _get_packed(self):
        return _PENDING_CONFIRM_SESSIONS.get(str(getattr(self, "session_id", "") or ""))

    def invoke(self, context: bpy.types.Context, _event: bpy.types.Event) -> set[str]:
        packed = self._get_packed()
        if packed is None:
            return {"CANCELLED"}
        session, default_clone_type, default_copy_count = packed
        try:
            self.clone_type = str(default_clone_type)
        except Exception:
            self.clone_type = _default_clone_type()
        try:
            self.copy_count = max(1, int(default_copy_count))
        except Exception:
            self.copy_count = _default_copy_count()

        if not session.supports_copy_count and not session.supports_clone_type:
            _PENDING_CONFIRM_SESSIONS.pop(str(self.session_id), None)
            _finish_session(context, session, self.clone_type, 1)
            return {"FINISHED"}
        try:
            return context.window_manager.invoke_props_dialog(self, width=640)
        except Exception as exc:
            _safe_log(f"clone confirmation dialog failed: {exc}")
            _PENDING_CONFIRM_SESSIONS.pop(str(self.session_id), None)
            _finish_session(context, session, self.clone_type, self.copy_count)
            return {"FINISHED"}

    def execute(self, context: bpy.types.Context) -> set[str]:
        packed = _PENDING_CONFIRM_SESSIONS.pop(str(getattr(self, "session_id", "") or ""), None)
        if packed is None:
            return {"CANCELLED"}
        session, _default_clone_type_value, _default_copy_count_value = packed
        try:
            _finish_session(context, session, self.clone_type, self.copy_count)
            return {"FINISHED"}
        except Exception as exc:
            _safe_log(f"clone confirmation execute failed: {exc}")
            try:
                _cancel_session(context, session)
            except Exception:
                pass
            return {"CANCELLED"}

    def cancel(self, context: bpy.types.Context) -> None:
        packed = _PENDING_CONFIRM_SESSIONS.pop(str(getattr(self, "session_id", "") or ""), None)
        if packed is None:
            return
        session, _default_clone_type_value, _default_copy_count_value = packed
        try:
            _cancel_session(context, session)
        except Exception as exc:
            _safe_log(f"clone confirmation cancel failed: {exc}")

    def draw(self, _context: bpy.types.Context) -> None:
        layout = self.layout
        packed = self._get_packed()
        session = packed[0] if packed is not None else None
        layout.label(text=_iface("Clone Options"))
        if session is not None and session.supports_clone_type:
            layout.prop(self, "clone_type")
        else:
            layout.label(text=_iface("Clone Type: Copy"))
        if session is not None and session.supports_copy_count:
            layout.prop(self, "copy_count")
        else:
            layout.label(text=_iface("Number of Copies: 1"))
        layout.separator()
        layout.label(text=_iface("The dragged clone is the first copy. Additional copies repeat the same transform interval."))


def _supported_area_under_event(context: bpy.types.Context, event: bpy.types.Event):
    supported = {"VIEW_3D", "GRAPH_EDITOR", "DOPESHEET_EDITOR"}
    mouse_x = int(getattr(event, "mouse_x", 0) or 0)
    mouse_y = int(getattr(event, "mouse_y", 0) or 0)

    def _window_region_for_area(candidate):
        try:
            return next((region for region in candidate.regions if region.type == "WINDOW"), None)
        except Exception:
            return None

    def _mouse_inside_area(candidate) -> bool:
        try:
            return candidate.x <= mouse_x < candidate.x + candidate.width and candidate.y <= mouse_y < candidate.y + candidate.height
        except Exception:
            return False

    area = getattr(context, "area", None)
    if area is not None and area.type in supported and _mouse_inside_area(area):
        region = _window_region_for_area(area)
        if region is not None:
            return area, region

    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window is not None else getattr(context, "screen", None)
    if screen is None:
        return None, None

    for candidate in screen.areas:
        if candidate.type not in supported:
            continue
        if _mouse_inside_area(candidate):
            region = _window_region_for_area(candidate)
            if region is not None:
                return candidate, region
    return None, None


classes = (
    MSDC_OT_drag_clone,
    MSDC_OT_drag_clone_confirm,
)


TRANSLATIONS = {
    "ja_JP": {
        (_TRANSLATION_CONTEXT, "Drag Clone"): "ドラッグクローン",
        (_TRANSLATION_CONTEXT, "Drag Clone Options"): "ドラッグクローン オプション",
        (_TRANSLATION_CONTEXT, "Confirm the clone type and copy count before the temporary drag clone is committed."): "一時的なドラッグクローンを確定する前に、クローン方式とコピー数を確認します。",
        (_TRANSLATION_CONTEXT, "Choose the object clone type before the temporary drag clone is committed. Copy creates independent object data; Instance shares object data with the source object where Blender supports linked data."): "一時的なドラッグクローンを確定する前に、オブジェクトのクローン方式を選びます。コピーは独立したオブジェクトデータを作成し、インスタンスは Blender が対応する範囲で元オブジェクトとデータを共有します。",
        (_TRANSLATION_CONTEXT, "Set the total number of copies to create. The dragged clone is copy 1; higher values repeat the same transform interval successively."): "作成するコピー総数を設定します。ドラッグしたクローンを 1 個目として数え、2 以上では同じ変形間隔で連続コピーを追加します。",
        (_TRANSLATION_CONTEXT, "Clone the current selection at left-drag start, transform the clone directly during the drag, and confirm with clone options."): "左ドラッグ開始時に現在の選択を複製し、ドラッグ中の変形を直接適用して、最後にクローンオプションで確定します。",
        (_TRANSLATION_CONTEXT, "Clone the current selection at left-drag start, then transform the clone directly while dragging."): "左ドラッグ開始時に現在の選択を複製し、ドラッグ中にクローンを直接変形します。",
        (_TRANSLATION_CONTEXT, "No selected object is available for cloning."): "複製できる選択オブジェクトがありません。",
        (_TRANSLATION_CONTEXT, "Mesh edit cloning requires Blender's bmesh module."): "メッシュ編集の複製には Blender の bmesh モジュールが必要です。",
        (_TRANSLATION_CONTEXT, "No selected mesh component is available for cloning."): "複製できる選択メッシュ要素がありません。",
        (_TRANSLATION_CONTEXT, "Blender cancelled the mesh duplicate operation."): "Blender がメッシュ複製処理をキャンセルしました。",
        (_TRANSLATION_CONTEXT, "Edge drag cloning requires selected boundary edges."): "辺ドラッグクローンには、選択された輪郭線の辺が必要です。",
        (_TRANSLATION_CONTEXT, "No selected keyframe is available for cloning."): "複製できる選択キーフレームがありません。",
        (_TRANSLATION_CONTEXT, "Blender cancelled the keyframe duplicate operation."): "Blender がキーフレーム複製処理をキャンセルしました。",
        (_TRANSLATION_CONTEXT, "This mode does not expose a Blender duplicate operation."): "このモードでは、Blender 側に利用可能な複製処理がありません。",
        (_TRANSLATION_CONTEXT, "Blender cancelled the duplicate operation."): "Blender が複製処理をキャンセルしました。",
        (_TRANSLATION_CONTEXT, "No active clone session is available."): "有効なクローン処理セッションがありません。",
        (_TRANSLATION_CONTEXT, "Clone Options"): "クローンオプション",
        (_TRANSLATION_CONTEXT, "Clone Type: Copy"): "クローン方式: コピー",
        (_TRANSLATION_CONTEXT, "Number of Copies: 1"): "コピー数: 1",
        (_TRANSLATION_CONTEXT, "The dragged clone is the first copy. Additional copies repeat the same transform interval."): "ドラッグしたクローンが 1 個目のコピーです。追加コピーは同じ変形間隔を順番に繰り返して作成します。",
        (_TRANSLATION_CONTEXT, "Clone Type"): "クローン方式",
        (_TRANSLATION_CONTEXT, "Choose the object clone type when the confirmation dialog appears after releasing the left mouse button. Copy creates independent object data; Instance shares object data with the source object where Blender supports linked data."): "左ボタンを離した後に表示される確定ダイアログで、オブジェクトのクローン方式を選びます。コピーは独立したオブジェクトデータを作成し、インスタンスは Blender が対応する範囲で元オブジェクトとデータを共有します。",
        (_TRANSLATION_CONTEXT, "Copy"): "コピー",
        (_TRANSLATION_CONTEXT, "Create a normal independent copy of the cloned object data."): "クローンしたオブジェクトデータを、元とは独立した通常コピーとして作成します。",
        (_TRANSLATION_CONTEXT, "Instance"): "インスタンス",
        (_TRANSLATION_CONTEXT, "Create an instance-style linked duplicate that shares object data with the source object where Blender supports it."): "Blender が対応する範囲で、元オブジェクトと同じデータを共有するインスタンス形式のリンク複製を作成します。",
        (_TRANSLATION_CONTEXT, "Number of Copies"): "コピー数",
        (_TRANSLATION_CONTEXT, "Set the total number of copies to create after the first drag result. A value of 1 keeps only the dragged copy; higher values repeat the same move, rotate, scale, mesh edit, or keyframe offset successively."): "最初のドラッグ結果を含めて作成するコピー総数を設定します。1 ではドラッグしたコピーだけを残し、2 以上では同じ移動・回転・スケール・メッシュ編集・キーフレームオフセットを順番に繰り返して追加コピーを作成します。",
        (_TRANSLATION_CONTEXT, "Shift"): "Shift",
        (_TRANSLATION_CONTEXT, "Ctrl"): "Ctrl",
        (_TRANSLATION_CONTEXT, "Alt"): "Alt",
        (_TRANSLATION_CONTEXT, "Command"): "Command",
        (_TRANSLATION_CONTEXT, "No Extra Key"): "追加キーなし",
        (_TRANSLATION_CONTEXT, "Space"): "スペース",
        (_TRANSLATION_CONTEXT, "Tab"): "Tab",
        (_TRANSLATION_CONTEXT, "Enter"): "Enter",
        (_TRANSLATION_CONTEXT, "Backspace"): "Backspace",
        (_TRANSLATION_CONTEXT, "Delete"): "Delete",
        (_TRANSLATION_CONTEXT, "Escape"): "Esc",
        (_TRANSLATION_CONTEXT, "Insert"): "Insert",
        (_TRANSLATION_CONTEXT, "Home"): "Home",
        (_TRANSLATION_CONTEXT, "End"): "End",
        (_TRANSLATION_CONTEXT, "Page Up"): "Page Up",
        (_TRANSLATION_CONTEXT, "Page Down"): "Page Down",
        (_TRANSLATION_CONTEXT, "Left Arrow"): "左矢印",
        (_TRANSLATION_CONTEXT, "Right Arrow"): "右矢印",
        (_TRANSLATION_CONTEXT, "Up Arrow"): "上矢印",
        (_TRANSLATION_CONTEXT, "Down Arrow"): "下矢印",
        (_TRANSLATION_CONTEXT, "Quote"): "引用符",
        (_TRANSLATION_CONTEXT, "Backquote"): "バッククォート",
        (_TRANSLATION_CONTEXT, "Numpad 0"): "テンキー 0",
        (_TRANSLATION_CONTEXT, "Numpad 1"): "テンキー 1",
        (_TRANSLATION_CONTEXT, "Numpad 2"): "テンキー 2",
        (_TRANSLATION_CONTEXT, "Numpad 3"): "テンキー 3",
        (_TRANSLATION_CONTEXT, "Numpad 4"): "テンキー 4",
        (_TRANSLATION_CONTEXT, "Numpad 5"): "テンキー 5",
        (_TRANSLATION_CONTEXT, "Numpad 6"): "テンキー 6",
        (_TRANSLATION_CONTEXT, "Numpad 7"): "テンキー 7",
        (_TRANSLATION_CONTEXT, "Numpad 8"): "テンキー 8",
        (_TRANSLATION_CONTEXT, "Numpad 9"): "テンキー 9",
        (_TRANSLATION_CONTEXT, "Numpad ."): "テンキー .",
        (_TRANSLATION_CONTEXT, "Numpad /"): "テンキー /",
        (_TRANSLATION_CONTEXT, "Numpad *"): "テンキー *",
        (_TRANSLATION_CONTEXT, "Numpad -"): "テンキー -",
        (_TRANSLATION_CONTEXT, "Numpad +"): "テンキー +",
        (_TRANSLATION_CONTEXT, "Numpad Enter"): "テンキー Enter",
        (_TRANSLATION_CONTEXT, "Application"): "Application",
        (_TRANSLATION_CONTEXT, "Grless"): "Grless",
        (_TRANSLATION_CONTEXT, "Default Clone Type"): "既定のクローン方式",
        (_TRANSLATION_CONTEXT, "Set the default choice shown in the clone confirmation dialog for Object Mode. Copy makes independent object data; Instance links the cloned object data to the source where Blender supports linked data."): "オブジェクトモードのクローン確定ダイアログに最初に表示する方式を設定します。コピーは独立したオブジェクトデータを作成し、インスタンスは Blender が対応する範囲で元データへリンクします。",
        (_TRANSLATION_CONTEXT, "Use normal independent object-data copies by default."): "既定で、元とは独立した通常のオブジェクトデータコピーを使います。",
        (_TRANSLATION_CONTEXT, "Use linked object-data instances by default where Blender supports linked data."): "既定で、Blender が対応する範囲のリンクデータインスタンスを使います。",
        (_TRANSLATION_CONTEXT, "Default Number of Copies"): "既定のコピー数",
        (_TRANSLATION_CONTEXT, "Set the default number shown in the clone confirmation dialog. The dragged clone counts as copy 1; values above 1 add successive repeated copies at the same transform interval."): "クローン確定ダイアログに最初に表示するコピー数を設定します。ドラッグしたクローンを 1 個目として数え、2 以上では同じ変形間隔の連続コピーを追加します。",
        (_TRANSLATION_CONTEXT, "Transform Mode"): "変形モード",
        (_TRANSLATION_CONTEXT, "Choose the transform launched immediately after cloning. Auto follows the current Move, Rotate, or Scale tool; standard gizmos, Smart Gizmo, standard G/R/S, and Smart G/R/S keep their normal axis constraints, orientation, pivot, snapping, and precision behavior."): "クローン作成直後に開始する変形を選びます。自動では現在の移動・回転・スケールツールに従い、標準ギズモ、スマートギズモ、標準 G/R/S、スマート G/R/S の軸拘束、座標系、ピボット、スナップ、精密化を通常どおり維持します。",
        (_TRANSLATION_CONTEXT, "Auto"): "自動",
        (_TRANSLATION_CONTEXT, "Use the active 3D View tool: Move, Rotate, or Scale. If it is not a transform tool, use Move."): "3D ビューで現在有効な移動・回転・スケールツールを使います。変形ツールでない場合は移動を使います。",
        (_TRANSLATION_CONTEXT, "Move"): "移動",
        (_TRANSLATION_CONTEXT, "Always start a Move transform after cloning."): "クローン作成後、常に移動変形を開始します。",
        (_TRANSLATION_CONTEXT, "Rotate"): "回転",
        (_TRANSLATION_CONTEXT, "Always start a Rotate transform after cloning."): "クローン作成後、常に回転変形を開始します。",
        (_TRANSLATION_CONTEXT, "Scale"): "スケール",
        (_TRANSLATION_CONTEXT, "Always start a Scale transform after cloning."): "クローン作成後、常にスケール変形を開始します。",
        (_TRANSLATION_CONTEXT, "After the clone is created, keep holding the left mouse button to continue the modal transform; Ctrl snaps and Shift uses precision according to Blender's transform controls."): "クローン作成後も左ボタンを押したままにすると、モーダル変形を継続できます。変形中は Blender の変形操作に従って Ctrl でスナップ、Shift で精密化を使います。",
        (_TRANSLATION_CONTEXT, "Set the default choice shown in the clone confirmation dialog for Object Mode. Copy makes independent object data; Instance links the cloned object data to the source and also joins Smart Modifier object-instance groups so modifier instances stay synchronized."): "オブジェクトモードのクローン確定ダイアログに最初に表示する方式を設定します。コピーは独立したオブジェクトデータを作成し、インスタンスは元データへリンクしたうえで Smart Modifier のオブジェクトインスタンスグループにも参加させ、モディファイアインスタンスの同期を維持します。",
        (_TRANSLATION_CONTEXT, "Use linked object-data instances by default and synchronize Smart Modifier modifier instances."): "既定でリンクデータインスタンスを使い、Smart Modifier のモディファイアインスタンスも同期します。",
    }
}


# -----------------------------------------------------------------------------
# Manual key-modifier watcher and keymaps/registration


def _first_view3d_override_args() -> dict | None:
    try:
        wm = bpy.context.window_manager
        for window in list(getattr(wm, "windows", []) or []):
            screen = getattr(window, "screen", None)
            if screen is None:
                continue
            for area in list(getattr(screen, "areas", []) or []):
                if str(getattr(area, "type", "")) != "VIEW_3D":
                    continue
                region = next((r for r in getattr(area, "regions", []) if getattr(r, "type", "") == "WINDOW"), None)
                if region is None:
                    continue
                args = _operator_context_override_args(bpy.context, area, region)
                args["window"] = window
                args["screen"] = screen
                return args
    except Exception:
        pass
    return None


def _start_manual_key_modifier_watcher() -> None:
    """Disabled safety hook.

    Earlier builds started a persistent modal listener to rescue normal-key
    key_modifier bindings such as C + left-drag.  That listener necessarily saw
    unrelated View3D keyboard and mouse events, and could consume or delay core
    Blender operations.  Smart Modifier must not affect Blender's base controls
    merely by being installed, so no background modal listener is started.
    """
    global _MSDC_WATCHER_RUNNING
    _MSDC_WATCHER_RUNNING = False
    return None


def _schedule_manual_key_modifier_watcher() -> None:
    """Disabled by policy: no registration-time timers or modal event watchers."""
    return None


def _iter_keymap_definitions() -> tuple[tuple[str, str, str], ...]:
    defs: list[tuple[str, str, str]] = []

    def add(name: str, space_type: str, region_type: str = "WINDOW") -> None:
        item = (name, space_type, region_type)
        if item not in defs:
            defs.append(item)

    # Limit the trigger to editors that can actually consume the follow-up drag.
    # Older builds registered Window/Object/Mesh EMPTY-space keymaps as well; those
    # can invoke the modal from Outliner/Properties or survive add-on reloads and
    # collide with Blender's event handlers.  Register only editor-local keymaps.
    add("3D View", "VIEW_3D")
    add("Graph Editor", "GRAPH_EDITOR")
    add("Dopesheet", "DOPESHEET_EDITOR")

    # Active tool keymaps have high priority for left-drag.  Registering the same
    # clone trigger in them prevents Blender's Move/Rotate/Scale tools from swallowing
    # the event before this add-on sees it.
    try:
        wm = bpy.context.window_manager
        for keyconfig_name in ("default", "active"):
            keyconfig = getattr(wm.keyconfigs, keyconfig_name, None)
            if keyconfig is None:
                continue
            for km in keyconfig.keymaps:
                if km.name.startswith("3D View Tool:") and km.space_type == "VIEW_3D":
                    if _keymap_name_is_selection_tool(km.name):
                        continue
                    add(km.name, km.space_type, km.region_type)
    except Exception:
        pass

    return tuple(defs)


def _keymap_item_matches(kmi: bpy.types.KeyMapItem, *, event_type: str, event_value: str, modifiers: dict[str, bool | str]) -> bool:
    try:
        if str(getattr(kmi, "idname", "")) != MSDC_OT_drag_clone.bl_idname:
            return False
        if str(getattr(kmi, "type", "")) != str(event_type):
            return False
        if str(getattr(kmi, "value", "")) != str(event_value):
            return False
        for name, expected in modifiers.items():
            actual = getattr(kmi, name, None)
            if isinstance(expected, bool):
                if bool(actual) != expected:
                    return False
            else:
                if str(actual or "NONE") != str(expected or "NONE"):
                    return False
        return True
    except Exception:
        return False


def _reuse_inactive_keymap_item(km: bpy.types.KeyMap, *, event_type: str, event_value: str, modifiers: dict[str, bool | str]) -> bpy.types.KeyMapItem | None:
    try:
        for kmi in list(getattr(km, "keymap_items", []) or []):
            try:
                if bool(getattr(kmi, "active", False)):
                    continue
                if _keymap_item_matches(kmi, event_type=event_type, event_value=event_value, modifiers=modifiers):
                    kmi.active = True
                    return kmi
            except Exception:
                continue
    except Exception:
        pass
    return None


def _new_keymap_item_safe(_km: bpy.types.KeyMap, *, event_type: str, event_value: str, modifiers: dict[str, bool | str]) -> bpy.types.KeyMapItem | None:
    """Disabled by policy: Smart Modifier never creates Blender keymap items automatically."""
    return None


def _drag_clone_keymap_target_ids() -> set[str]:
    return {MSDC_OT_drag_clone.bl_idname, MSDC_OT_drag_clone_confirm.bl_idname}


def _manual_only_keymap_target_ids() -> set[str]:
    """Operator IDs that Smart Modifier documents for manual keymap registration.

    Registration-time cleanup may deactivate only add-on-created entries for
    these IDs.  User keymaps are left intact except for clearly dangerous stale
    Drag Clone mouse bindings that old automatic builds could create.
    """
    return {
        MSDC_OT_drag_clone.bl_idname,
        MSDC_OT_drag_clone_confirm.bl_idname,
        "object.ms_toggle_show_end_result",
        "object.ms_active_stack_level_up",
        "object.ms_active_stack_level_down",
        "object.sms_instance_copy",
        "object.sms_instance_make_unique",
    }


def _keymap_item_has_no_modifiers(kmi: bpy.types.KeyMapItem) -> bool:
    try:
        return (
            not bool(getattr(kmi, "any", False))
            and not bool(getattr(kmi, "shift", False))
            and not bool(getattr(kmi, "ctrl", False))
            and not bool(getattr(kmi, "alt", False))
            and not bool(getattr(kmi, "oskey", False))
            and str(getattr(kmi, "key_modifier", "NONE") or "NONE") == "NONE"
        )
    except Exception:
        return False


def _is_left_mouse_drag_clone_binding(kmi: bpy.types.KeyMapItem) -> bool:
    try:
        return str(getattr(kmi, "type", "") or "") in {"LEFTMOUSE", "EVT_TWEAK_L"}
    except Exception:
        return False


def _keymap_item_is_stale_automatic_shortcut(config_name: str, km: bpy.types.KeyMap, kmi: bpy.types.KeyMapItem) -> bool:
    """Identify shortcuts that can make Blender's base controls unusable.

    Older experimental builds created Drag Clone keymaps automatically, including
    entries in high-priority active-tool keymaps and in some cases plain
    LEFTMOUSE/drag bindings.  Those entries hijack selection, transform-gizmo,
    and viewport interaction as soon as this operator class exists.  Current
    Smart Modifier is manual-keymap only, so legacy automatic entries are made
    inactive at registration.  Intentional user shortcuts with a normal
    key_modifier such as C+left-drag are preserved.
    """
    try:
        idname = str(getattr(kmi, "idname", "") or "")
    except Exception:
        idname = ""
    if not idname:
        return False

    if idname == MSDC_OT_drag_clone_confirm.bl_idname:
        # The confirmation operator is opened internally and should never be
        # bound to a mouse/key event.
        return True

    if str(config_name or "") == "addon" and idname in _manual_only_keymap_target_ids():
        return True

    if idname != MSDC_OT_drag_clone.bl_idname:
        return False

    try:
        km_name = str(getattr(km, "name", "") or "")
    except Exception:
        km_name = ""
    if km_name.startswith("3D View Tool:"):
        # Auto-generated active-tool entries have higher priority than Blender's
        # native gizmos and selection tools.  Manual registration is documented
        # for the normal 3D View keymap, not the internal tool keymaps.
        return True

    if _is_left_mouse_drag_clone_binding(kmi) and _keymap_item_has_no_modifiers(kmi):
        # Old defaults could create a plain left-mouse binding when the N-panel
        # shortcut modifiers were all off.  That captures every select/drag.
        return True

    return False


def _neutralize_legacy_drag_clone_runtime() -> None:
    """Stop runtime input hooks left by older Smart Modifier modules.

    A previous build used a persistent modal watcher to make normal-key
    key_modifier shortcuts such as C+left-drag work.  If Blender reloads the
    add-on under a different package name, that old modal instance can remain in
    the window manager even after the new add-on is enabled.  Setting the old
    module globals to disabled makes the stale watcher cancel on its next event,
    and unregistering its timer prevents it from being started again.
    """
    import sys
    try:
        timers = getattr(getattr(bpy, "app", None), "timers", None)
    except Exception:
        timers = None

    current_module_name = str(__name__)
    current_root = current_module_name.rsplit(".", 1)[0] if "." in current_module_name else current_module_name
    for module_name, module in list(sys.modules.items()):
        try:
            if module is None or module_name == current_module_name:
                continue
            if current_root and (str(module_name) == current_root or str(module_name).startswith(current_root + ".")):
                continue
            lower = str(module_name or "").lower()
            if not (
                lower.endswith("max_shift_drag_clone")
                or lower.endswith("transform_guard")
                or "smart_modifier_suite" in lower
            ):
                continue

            if lower.endswith("max_shift_drag_clone"):
                for attr in ("_MSDC_MODAL_ACTIVE", "_MSDC_WATCHER_ENABLED", "_MSDC_WATCHER_RUNNING", "_MSDC_FORCE_START"):
                    try:
                        setattr(module, attr, False)
                    except Exception:
                        pass
                for timer_name in ("_manual_key_modifier_watcher_timer", "_start_manual_key_modifier_watcher"):
                    try:
                        fn = getattr(module, timer_name, None)
                        if fn is not None and timers is not None and hasattr(timers, "is_registered") and timers.is_registered(fn):
                            timers.unregister(fn)
                    except Exception:
                        pass

            if lower.endswith("transform_guard"):
                try:
                    fn = getattr(module, "_restore_timer", None)
                    if fn is not None and timers is not None and hasattr(timers, "is_registered") and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    pass
                try:
                    unregister_fn = getattr(module, "unregister", None)
                    if callable(unregister_fn):
                        unregister_fn()
                except Exception:
                    pass
        except Exception:
            continue

    try:
        dn = getattr(getattr(bpy, "app", None), "driver_namespace", {})
        for key in (
            "_SMSM_TRANSFORM_GUARD_ACTIVE_V1",
            "_SMSM_TRANSFORM_GUARD_SESSION_V1",
            "_SMSM_TRANSFORM_GUARD_UNTIL_V1",
            "_SMSM_TRANSFORM_GUARD_TIMER_ARMED_V1",
            "_SMSM_TRANSFORM_GUARD_REASON_V1",
        ):
            try:
                dn.pop(key, None)
            except Exception:
                pass
    except Exception:
        pass


def _deactivate_keymap_item_safe(kmi: bpy.types.KeyMapItem | None) -> bool:
    """Disable a keymap item without freeing Blender-owned RNA data.

    Blender 5.1.0 on Windows can crash inside WM_keymap_remove_item while the
    application is exiting if an add-on removes keymap items whose operator
    properties have already entered UI-data teardown.  Python cannot catch that
    native access violation, so this add-on must not call native keymap item removal.
    for drag-clone shortcuts.  Deactivation is enough to prevent stale shortcuts
    from firing and does not ask Blender to free the KeyMapItem immediately.
    """
    if kmi is None:
        return False
    try:
        if getattr(kmi, "active", True):
            kmi.active = False
            return True
        return False
    except Exception:
        return False


def _purge_stale_keymap_items() -> None:
    """Deactivate stale automatic Smart Modifier shortcuts.

    The add-on must never create Blender keymap entries automatically.  This
    cleanup only disables entries that older builds created automatically or
    bindings that are known to capture core Blender left-mouse operations.  User
    shortcuts with an explicit key_modifier/modifier combination remain active.
    """
    try:
        wm = bpy.context.window_manager
        keyconfigs = getattr(wm, "keyconfigs", None)
        if keyconfigs is None:
            return
        for config_name in ("addon", "user", "active"):
            keyconfig = getattr(keyconfigs, config_name, None)
            if keyconfig is None:
                continue
            for km in list(getattr(keyconfig, "keymaps", []) or []):
                for kmi in list(getattr(km, "keymap_items", []) or []):
                    try:
                        if not _keymap_item_is_stale_automatic_shortcut(config_name, km, kmi):
                            continue
                        _deactivate_keymap_item_safe(kmi)
                    except Exception:
                        continue
    except Exception as exc:
        _safe_log(f"stale keymap deactivation failed: {exc}")


def register_keymaps() -> None:
    """Do not create keymap items. Only neutralize stale auto entries from older builds."""
    _purge_stale_keymap_items()
    _addon_keymaps.clear()


def unregister_keymaps() -> None:
    # Never remove keymap items here.  On Blender 5.1.0/Windows, removing
    # drag-clone keymap items during add-on disable or process exit can crash
    # Blender in WM_keymap_remove_item before Python can handle the error.
    # Mark tracked items inactive only; register_keymaps() deactivates any
    # stale inactive/active entries before creating the current shortcut set.
    for _km, kmi in reversed(_addon_keymaps):
        _deactivate_keymap_item_safe(kmi)
    _addon_keymaps.clear()


def refresh_keymaps(_context=None) -> None:
    """Refresh policy hook. It never registers Blender keymaps automatically."""
    try:
        unregister_keymaps()
    except Exception:
        pass
    try:
        register_keymaps()
    except Exception:
        pass





def register() -> None:
    global _MSDC_WATCHER_ENABLED, _MSDC_WATCHER_RUNNING, _MSDC_MODAL_ACTIVE
    _MSDC_MODAL_ACTIVE = False
    _MSDC_WATCHER_ENABLED = False
    _MSDC_WATCHER_RUNNING = False
    _neutralize_legacy_drag_clone_runtime()
    try:
        bpy.app.translations.register(ADDON_ID, TRANSLATIONS)
    except ValueError:
        bpy.app.translations.unregister(ADDON_ID)
        bpy.app.translations.register(ADDON_ID, TRANSLATIONS)

    for cls in classes:
        bpy.utils.register_class(cls)
    register_keymaps()


def unregister() -> None:
    global _MSDC_MODAL_ACTIVE, _MSDC_WATCHER_ENABLED, _MSDC_WATCHER_RUNNING
    _MSDC_MODAL_ACTIVE = False
    _MSDC_WATCHER_ENABLED = False
    _MSDC_WATCHER_RUNNING = False
    try:
        _PENDING_CONFIRM_SESSIONS.clear()
    except Exception:
        pass
    unregister_keymaps()
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
