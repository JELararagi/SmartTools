# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bisect 
import math 
import random 

import bpy 
from bpy .props import (
BoolProperty ,
EnumProperty ,
FloatProperty ,
IntProperty ,
PointerProperty ,
)
from bpy .types import Operator ,Panel ,PropertyGroup 
from mathutils import Matrix ,Vector 

from .utils import call_operator_safe ,get_operator_callable ,operator_available ,operator_runnable ,safe_mode_set
from .context import capture_object_context ,ensure_object_mode ,restore_object_context 
from .translation import pgettext as _sms_pgettext
from .help_button import draw_help_button, draw_help_header

PANEL_CATEGORY ="Smart Modifier"


def _persist_panel_state(_self=None, context=None) -> None:
    try:
        if context is None:
            context = getattr(bpy, 'context', None)
        from . import persistent_state
        persistent_state.request_save(context, immediate=True)
    except Exception:
        pass


def _persistent_property_factory(factory):
    def _wrapped(*args, **kwargs):
        kwargs.setdefault('update', _persist_panel_state)
        return factory(*args, **kwargs)
    return _wrapped


_BpyBoolProperty = BoolProperty
_BpyEnumProperty = EnumProperty
_BpyFloatProperty = FloatProperty
_BpyIntProperty = IntProperty
_BpyPointerProperty = PointerProperty
BoolProperty = _persistent_property_factory(_BpyBoolProperty)
EnumProperty = _persistent_property_factory(_BpyEnumProperty)
FloatProperty = _persistent_property_factory(_BpyFloatProperty)
IntProperty = _persistent_property_factory(_BpyIntProperty)
PointerProperty = _persistent_property_factory(_BpyPointerProperty)

translation_catalog_dict ={
"ja_JP":{
("*","Smart Modifier Hub"):"スマートモディファイアハブ",
("*","Curated high-coverage modeling workflow that unifies hard-surface, topology, CAD-like, array, scatter, cleanup, shading, and organization tools in one place."):"ハードサーフェス、トポロジー、CADライク、配列、散布、クリーンアップ、シェーディング、整理を1か所に統合した高網羅ワークフローハブです。",
("*","Hard Surface / Boolean"):"ハードサーフェス / ブーリアン",
("*","Topology / Repair"):"トポロジー / 修復",
("*","Curves / Repetition"):"カーブ / 反復配置",
("*","Profile / Helix"):"断面 / ヘリックス",
("*","Quick profile and helix primitives for sweep, trim, cable, and spring workflows."):"スイープ、トリム、ケーブル、バネ向けの断面 / ヘリックスの簡易プリミティブです。",
("*","• Curve prep: Add Profile Primitive and Add Helix Path provide reusable sweep sections and spring/spiral guide curves directly from the hub."):"• カーブ準備: 断面プリミティブを追加 と ヘリックスパスを追加 で、再利用可能な断面とバネ / 螺旋ガイドカーブをハブから直接作成。",
("*","Scatter / Environment"):"散布 / 環境構築",
("*","Workflow / Existing Tools"):"ワークフロー / 既存ツール",
("*","Guide / Tips"):"ガイド / ヒント",
("*","Build HS Boolean Stack"):"HSブーリアンスタック構築",
("*","Create a compact non-destructive hard-surface stack on the active object using the other selected mesh objects as cutters. Adds Boolean modifiers per cutter, optional bevel support, optional weighted normals, and optional cutter organization for a Hard Ops / Boxcutter / Hard Mesh / MeshFusion style workflow."):"選択中の他メッシュをカッターとして使用し、アクティブオブジェクトにコンパクトな非破壊ハードサーフェススタックを構築します。各カッターごとにBooleanモディファイアを追加し、必要に応じてベベル補助・重み付き法線・カッター整理を自動設定して、Hard Ops / Boxcutter / Hard Mesh / MeshFusion 風のワークフローを実現します。",
("*","Quick Repair / Cleanup"):"即修復 / クリーンアップ",
("*","Repair common mesh issues on the selected mesh objects: merge doubles, dissolve degenerates, delete loose geometry, optionally fill holes, optionally join triangles to quads, and recalculate normals. Designed as a safe recovery pass for imported assets, boolean-heavy meshes, and messy kitbash data."):"選択メッシュのよくある問題をまとめて修復します。重複頂点の統合、縮退要素の削除、ルーズジオメトリ削除、必要に応じた穴埋め、三角形の四角化、法線再計算を行います。インポート資産、ブーリアン多用メッシュ、荒れたキットバッシュデータの安全な復旧処理向けです。",
("*","Smart Fill / Quad Repair"):"スマート面張り / 四角化補助",
("*","Fill the current edit-mode boundary with a grid-first strategy, then fall back to standard face creation and fill tools. Optionally beautifies and converts triangles to quads. This acts as a practical upper-compatible helper inspired by F2, Quad Adder, and manual patch tools."):"編集モード中の境界を、まずグリッドフィル優先で埋め、失敗時は標準の面生成やFillへフォールバックします。必要に応じて Beautify と三角形の四角化も行います。F2、Quad Adder、各種パッチ系ツールを実務向けに統合した上位互換補助です。",
("*","Make Pipe / Cable"):"パイプ / ケーブル化",
("*","Convert the current selected edge path into a beveled curve pipe. This is useful for cable, hose, trim, and sweep-style workflows inspired by Sweep Mesh, Cablerator, ReeperX, and curve-based modeling tools."):"現在選択中のエッジパスを、ベベル付きカーブパイプへ変換します。ケーブル、ホース、モール、スイープ系モデリングに有効で、Sweep Mesh、Cablerator、ReeperX、各種カーブ系ツールを参考にした実装です。",
("*","Array Along Curve"):"カーブに沿って配列",
("*","Build an Array + Curve modifier stack on the active mesh using the selected curve as the path. Useful for RailClone-like repetition, trims, railing, modular walls, and architectural detailing."):"選択カーブをパスとして、アクティブメッシュに Array + Curve モディファイア構成を自動作成します。RailClone 的な反復、トリム、手すり、モジュラー壁、建築ディテールに便利です。",
("*","Scatter Instances (Bake)"):"インスタンス散布（ベイク）",
("*","Scatter linked object instances over the active surface using weighted triangle-area sampling. Creates a dedicated scatter collection and a root empty, making it useful for environment blocking, vegetation placement, debris, and kitbash dressing inspired by Forest Pack / Geo-Scatter style workflows."):"三角形面積に基づく重み付きサンプリングで、アクティブ面上にリンクインスタンスを散布します。専用コレクションとルートEmptyを作成するため、環境レイアウト、植生配置、デブリ配置、キットバッシュ装飾など、Forest Pack / Geo-Scatter 系ワークフローのベイク版として有効です。",
("*","Boolean Operation"):"ブーリアン演算",
("*","Difference"):"差分",
("*","Union"):"合成",
("*","Intersect"):"交差",
("*","Exact"):"Exact",
("*","Fast"):"Fast",
("*","Prefer Grid Fill"):"Grid Fill優先",
("*","Beautify Fill"):"Beautify Fill",
("*","Convert To Quads"):"四角化",
("*","Choose how cutter meshes affect the active target mesh."):"カッターメッシュがアクティブターゲットへ与える演算方法を選びます。",
("*","Solver"):"ソルバー",
("*","Boolean solver used for newly created modifiers. Exact is safer for complex intersections; Fast is lighter."):"新規Booleanモディファイアに使用するソルバーです。複雑な交差には Exact が安全で、Fast は軽量です。",
("*","Auto Bevel"):"自動ベベル",
("*","Add a support bevel modifier after the boolean stack to stabilize highlights in hard-surface workflows."):"ブーリアン後に補助ベベルモディファイアを追加し、ハードサーフェスでハイライトを安定させます。",
("*","Bevel Width"):"ベベル幅",
("*","Width used by the auto-created bevel modifier."):"自動作成されるベベルモディファイアの幅です。",
("*","Bevel Segments"):"ベベル分割数",
("*","Segment count used by the auto-created bevel modifier."):"自動作成されるベベルモディファイアの分割数です。",
("*","Auto Weighted Normal"):"自動重み付き法線",
("*","Add a Weighted Normal modifier after the hard-surface stack for cleaner shading."):"ハードサーフェススタックの最後に Weighted Normal を追加し、シェーディングを整えます。",
("*","Organize Cutters"):"カッターを整理",
("*","Link cutters into a dedicated collection so boolean helper objects stay organized in the Outliner."):"Boolean補助オブジェクトをアウトライナーで整理しやすいよう、専用コレクションへリンクします。",
("*","Merge Distance"):"結合距離",
("*","Distance used when merging overlapping vertices during cleanup."):"クリーンアップ時に重複頂点を統合する距離です。",
("*","Fill Holes"):"穴埋め",
("*","Try to fill open boundaries after cleanup."):"クリーンアップ後に開いた境界を可能な範囲で埋めます。",
("*","Join Triangles"):"三角形を結合",
("*","Try to join adjacent triangles into quads after cleanup or fill."):"クリーンアップや穴埋め後に隣接三角形を四角形へまとめるよう試みます。",
("*","Recalculate Normals"):"法線再計算",
("*","Recalculate normals after cleanup to reduce shading glitches."):"クリーンアップ後に法線を再計算し、シェーディング乱れを抑えます。",
("*","Pipe Radius"):"パイプ半径",
("*","Bevel depth applied to the generated pipe curve."):"生成されるパイプカーブに設定するベベル深度です。",
("*","Pipe Resolution"):"パイプ解像度",
("*","Curve bevel resolution used for the generated pipe."):"生成されるパイプのカーブベベル解像度です。",
("*","Fill Caps"):"端面を閉じる",
("*","Close the pipe ends when the curve supports cap filling."):"カーブが対応している場合に、パイプ両端を閉じます。",
("*","Array Offset X"):"配列オフセット X",
("*","Relative X offset used by the Array modifier."):"Arrayモディファイアで使用する相対Xオフセットです。",
("*","Array Count"):"配列数",
("*","Fallback count used when fit-curve mode is unavailable or disabled."):"Fit Curve が使えない場合や無効な場合の予備配列数です。",
("*","Merge Array Vertices"):"配列頂点を結合",
("*","Merge touching vertices in the generated array when the modifier supports it."):"モディファイアが対応している場合、配列で接触する頂点を結合します。",
("*","Scatter Count"):"散布数",
("*","Number of linked instances to scatter across the active surface."):"アクティブ面へ散布するリンクインスタンス数です。",
("*","Scatter Seed"):"散布シード",
("*","Random seed used for scatter placement."):"散布配置に使う乱数シードです。",
("*","Scale Min"):"最小スケール",
("*","Minimum random scale used by the scatter operator."):"散布時に使用するランダムスケールの最小値です。",
("*","Scale Max"):"最大スケール",
("*","Maximum random scale used by the scatter operator."):"散布時に使用するランダムスケールの最大値です。",
("*","Random Z (deg)"):"ランダムZ回転（度）",
("*","Maximum random rotation around the local up axis in degrees."):"ローカル上方向まわりに加えるランダム回転の最大角度（度）です。",
("*","Align to Surface"):"面法線に揃える",
("*","Align scattered instances to the surface normal."):"散布インスタンスを面法線方向へ揃えます。",
("*","Surface Offset"):"面オフセット",
("*","Push scattered instances away from the surface along the normal."):"散布インスタンスを法線方向へ少し浮かせます。",
("*","Quick access to the deeper suite tools is kept below so beginners can start from the hub and advanced users can still jump to the specialized operators."):"初心者はこのハブから始められ、熟練者は下のボタンから既存の専門ツールへすぐ移動できるようにしています。",
("*","Active mesh object required"):"アクティブなメッシュオブジェクトが必要です",
("*","Could not switch to Object Mode"):"オブジェクトモードへ切り替えられませんでした",
("*","Select at least one cutter mesh besides the active object"):"アクティブ以外に少なくとも1つのカッターメッシュを選択してください",
("*","Select one curve object together with the active mesh object"):"アクティブメッシュと一緒に、1つのカーブオブジェクトを選択してください",
("*","Select at least one scatter source object besides the active surface"):"アクティブ面以外に、少なくとも1つの散布元オブジェクトを選択してください",
("*","No valid surface triangles were found on the active object"):"アクティブオブジェクト上に有効な面三角形が見つかりませんでした",
("*","Select some edges in Edit Mode first"):"先に編集モードでエッジを選択してください",
("*","The selection has no open boundary to fill"):"選択範囲に埋められる開いた境界がありません",
("*","Failed to isolate the duplicated edge selection"):"複製したエッジ選択部分を新規オブジェクトとして分離できませんでした",
("*","Created hard-surface boolean stack"):"ハードサーフェス用ブーリアンスタックを作成しました",
("*","Cleanup complete"):"クリーンアップが完了しました",
("*","Fill / repair complete"):"面張り / 修復が完了しました",
("*","Generated pipe curve from selected edges"):"選択エッジからパイプカーブを生成しました",
("*","Failed to build curve data from the selected edges"):"選択エッジからカーブデータを構築できませんでした",
("*","Updated active curve with pipe settings"):"アクティブカーブへパイプ設定を適用しました",
("*","Created array-along-curve stack"):"カーブ沿い配列スタックを作成しました",
("*","Scatter bake complete"):"散布ベイクが完了しました",
("*","Suggested workflows"):"おすすめワークフロー",
("*","• Hard-surface blockout: Boolean Stack → Crease / Weighted Normal → Direct Delete for cleanup."):"• ハードサーフェスのブロックアウト: Boolean Stack → Crease / Weighted Normal → Direct Delete で整理。",
("*","• Retopo / repair: Smart Fill → Quick Repair / Cleanup → Smart Vertex Slide / Mesh Align."):"• リトポ / 修復: Smart Fill → Quick Repair / Cleanup → Smart Vertex Slide / Mesh Align で整理します。",
("*","• Cables / trims: Make Pipe / Cable, then Array Along Curve for repeating details."):"• ケーブル / トリム: Make Pipe / Cable の後に Array Along Curve で反復ディテール化。",
("*","• Environment dressing: Scatter Instances (Bake) for rocks, foliage, debris, and kitbash details."):"• 環境装飾: Scatter Instances (Bake) で岩、植生、デブリ、キットバッシュを配置。",
("*","Deep tools"):"詳細ツール",
("*","Weighted Normal"):"Weighted Normal",
("*","Apply or refresh a Weighted Normal modifier on the selected mesh objects for cleaner hard-surface shading. Works well after boolean, bevel, or kitbash-style detail stacking and keeps the modifier stack editable."):"選択メッシュへ Weighted Normal モディファイアを適用または更新し、ハードサーフェスの陰影を整えます。ブーリアン、ベベル、キットバッシュ的な積層後に有効で、スタックも編集可能なまま保てます。",
("*","Keep Sharp"):"シャープを保持",
("*","Preserve existing sharp-edge shading when the modifier supports it."):"モディファイアが対応している場合、既存のシャープエッジの陰影を保持します。",
("*","Face Influence"):"面影響",
("*","Use face strength / influence information when available for stronger hard-surface shading control."):"利用可能な場合、面の強度 / 影響情報を使ってハードサーフェスの陰影制御を強めます。",
("*","Reuse Existing"):"既存を再利用",
("*","If a Weighted Normal modifier already exists on the object, update it instead of creating duplicates."):"オブジェクトに既存の Weighted Normal モディファイアがある場合、重複追加せず更新します。",
("*","Shade Smooth"):"スムーズシェード",
("*","Mark all faces smooth before or while applying the modifier."):"モディファイア適用前または適用時に全フェースをスムーズ表示にします。",
("*","Weighted normal applied / updated"):"Weighted Normal を適用 / 更新しました",
("*","Crease Preset"):"Crease Preset",
("*","Mesh Align"):"Mesh Align",
("*","Direct Delete"):"Direct Delete",
("*","Vertex Slide"):"Vertex Slide",
("*","Organize"):"整理",
("*","Merge / Snap"):"マージ / スナップ",
("*","Vertex Copy"):"頂点コピー",
("*","Begin with the compact hub, then dive into the specialized tools only when you need deeper control."):"まずはコンパクトなハブから始め、より深い制御が必要なときだけ専門ツールへ進むのがおすすめです。",
}

}

translation_catalog_dict ["ja_JP"].update ({
("*","Surface / Kitbash"):"サーフェス / キットバッシュ",
("*","Pattern / Architecture"):"パターン / 建築",
("*","Conform / Stitch To Surface"):"面へ追従 / ステッチ",
("*","Add a non-destructive shrinkwrap-based conform setup to the selected detail meshes so they follow the active surface. This is useful for kitbash details, decals, trim pieces, and surface-mounted parts inspired by xyShrinkWrap, Polystein Kit, NitroDraw, and similar surface placement workflows."):"選択したディテールメッシュへ、Shrinkwrapベースの非破壊追従設定を追加し、アクティブ面に沿わせます。キットバッシュ部品、デカール的な貼り物、トリム、面上に載せる機械パーツなど、xyShrinkWrap、Polystein Kit、NitroDraw 系ワークフローを意識した機能です。",
("*","Detach / Separate Clean"):"デタッチ / クリーン分離",
("*","Separate the current selection into a new object with an optional duplicate-first step and a light cleanup pass. This acts as a safe Blender-friendly helper inspired by Maya detachSeparate and similar clean detachment utilities."):"現在の選択を新しいオブジェクトへ分離します。必要なら複製してから分離し、軽いクリーンアップも行います。Maya の detachSeparate などを意識した、Blender向けの安全な分離補助です。",
("*","Relax Selection"):"選択をリラックス",
("*","Relax the current selected vertices or edge loop. Uses LoopTools Relax when available, and otherwise falls back to Blender smoothing for a safer all-in-one cleanup pass inspired by LoopTools, NitroRelax, and oaRelaxVerts."):"現在の選択頂点やエッジループをリラックスします。LoopTools Relax が使える場合はそれを使い、使えない場合は Blender 標準のスムージングへ安全にフォールバックします。LoopTools、NitroRelax、oaRelaxVerts 系の用途をまとめた補助です。",
("*","Circle Selection"):"選択を円形化",
("*","Fit the current selected vertices into a circular shape. Uses LoopTools Circle when available, and otherwise falls back to Blender's To Sphere transform for a practical circle helper inspired by LoopTools and NitroCycle."):"現在の選択頂点を円形に整えます。LoopTools Circle が使える場合はそれを使い、使えない場合は Blender 標準の To Sphere へフォールバックします。LoopTools や NitroCycle を参考にした実務向け円形化補助です。",
("*","Straighten Selection"):"選択を直線化",
("*","Project the current selected vertices onto the best line defined by the farthest selected pair. Useful for fast edge straightening and mesh unbending inspired by Align Edges and Unbend Mesh style tools."):"選択頂点のうち最も離れた2点で定義される直線へ投影し、直線化します。乱れたエッジの整列やメッシュの矯正など、Align Edges / Unbend Mesh 系の用途に向いています。",
("*","Floor Generator"):"フロア生成",
("*","Generate a procedural floorboard mesh inside the active object's local footprint using board width, length, gap, thickness, and stagger settings. This is a compact Blender-native helper inspired by FloorGenerator and architectural pattern tools."):"アクティブオブジェクトのローカルな占有範囲に合わせて、板幅・長さ・目地・厚み・ずらし量を使ったフロアボードメッシュを生成します。FloorGenerator などの建築系パターンツールを意識した、Blenderネイティブのコンパクト実装です。",
("*","Conform Mode"):"追従モード",
("*","Nearest Surface"):"最近接面",
("*","Project"):"投影",
("*","Choose how selected detail meshes should conform to the active surface."):"選択ディテールメッシュをアクティブ面へどのように追従させるかを選びます。",
("*","Use the closest surface point for each detail mesh"):"各ディテールメッシュを最近接面へ追従させます。",
("*","Project onto the surface along the object local Z axis when supported"):"対応している場合はオブジェクトのローカル Z 軸方向へ投影して面へ追従させます。",
("*","Conform Offset"):"追従オフセット",
("*","Offset kept between the conformed detail and the target surface."):"追従させたディテールと対象面の間に保つ距離です。",
("*","Parent To Surface"):"面へ親子付け",
("*","Parent the conformed detail objects to the active surface for easier scene organization."):"追従させたディテールオブジェクトをアクティブ面の子にして整理しやすくします。",
("*","Organize Details"):"ディテールを整理",
("*","Link conformed detail objects into a dedicated helper collection."):"追従ディテールを専用の補助コレクションへリンクして整理します。",
("*","Duplicate First"):"先に複製",
("*","Duplicate the selected geometry before separating it, so the source object keeps the original polygons."):"分離前に選択ジオメトリを複製し、元オブジェクト側にも元のポリゴンを残します。",
("*","Cleanup New Object"):"新規オブジェクトを整理",
("*","Run a light cleanup pass on the newly separated object to reduce loose elements and normal issues."):"分離後の新規オブジェクトに軽いクリーンアップを行い、ルーズ要素や法線の乱れを減らします。",
("*","Iterations"):"反復回数",
("*","How many smoothing passes to run when a fallback method is used."):"フォールバック方式を使うときに実行するスムージング回数です。",
("*","Prefer LoopTools"):"LoopTools を優先",
("*","Use LoopTools when available before falling back to built-in Blender smoothing."):"利用可能なら LoopTools を優先し、使えない場合のみ Blender 標準のスムージングへフォールバックします。",
("*","Use LoopTools when available before falling back to Blender's To Sphere transform."):"利用可能なら LoopTools を優先し、使えない場合のみ Blender 標準の To Sphere へフォールバックします。",
("*","Floor Board Width"):"床板の幅",
("*","Width of each generated floor board row."):"生成する各床板列の幅です。",
("*","Floor Board Length"):"床板の長さ",
("*","Target length of each floor board segment."):"各床板セグメントの目標長さです。",
("*","Floor Gap"):"目地幅",
("*","Gap placed between generated floor boards."):"生成する床板同士の間に入る目地幅です。",
("*","Floor Thickness"):"床板の厚み",
("*","Thickness of the generated floor boards."):"生成する床板の厚みです。",
("*","Floor Stagger"):"床板のずらし量",
("*","Row-to-row offset ratio used to stagger floor boards."):"各列の床板をずらす比率です。",
("*","Board Axis"):"板方向",
("*","Choose whether boards mainly run along the local X axis or Y axis of the active object."):"床板がアクティブオブジェクトのローカル X 軸方向か Y 軸方向のどちらへ主に伸びるかを選びます。",
("*","Boards run mainly along the local X axis"):"床板を主にローカル X 軸方向へ走らせます。",
("*","Boards run mainly along the local Y axis"):"床板を主にローカル Y 軸方向へ走らせます。",
("*","Boards X"):"X方向",
("*","Boards Y"):"Y方向",
("*","Select at least one detail mesh besides the active surface"):"アクティブ面以外に少なくとも1つのディテールメッシュを選択してください",
("*","Conformed selected detail meshes to active surface"):"選択ディテールメッシュをアクティブ面へ追従させました",
("*","Detached selection into a clean new object"):"選択をクリーンな新規オブジェクトへ分離しました",
("*","Relax complete"):"リラックスが完了しました",
("*","Circle alignment complete"):"円形化が完了しました",
("*","Straighten complete"):"直線化が完了しました",
("*","Generated floor pattern mesh"):"フロアパターンメッシュを生成しました",
("*","Select at least one component in Edit Mode first"):"先に編集モードで少なくとも1つの要素を選択してください",
("*","Need at least 3 selected vertices for circle fitting"):"円形化には少なくとも3つの選択頂点が必要です",
("*","Need at least 2 selected vertices to straighten"):"直線化には少なくとも2つの選択頂点が必要です",
("*","Failed to separate the current selection into a new object"):"現在の選択を新規オブジェクトとして分離できませんでした",
("*","Active mesh object with a usable footprint is required"):"有効な占有範囲を持つアクティブなメッシュオブジェクトが必要です",
("*","• Surface detailing: Conform / Stitch To Surface for kitbash parts and layered details."):"• 面上ディテール: Conform / Stitch To Surface でキットバッシュ部品や重ねディテールを面へ追従配置。",
("*","• Archviz patterns: Floor Generator for quick floorboard blockouts and layout previews."):"• Archviz パターン: Floor Generator で床板のラフ作成やレイアウト確認を素早く実行。",
})

translation_catalog_dict ["ja_JP"].update ({
("*","Fill, cap, or bridge the current edit-mode boundary with a smarter fallback chain. The operator tries boundary-aware bridge, grid fill, EdgeNet preparation/fill, and then standard face creation tools before optional beautify / quad cleanup. This acts as a more failure-resistant helper inspired by F2, Quad Adder, Quad Cap Tool, NitroCap, and day-to-day patch repair workflows."):"編集モードの境界選択を、より賢いフォールバック連鎖で埋め・キャップ・ブリッジします。境界に応じた Bridge、Grid Fill、EdgeNet Prepare / Fill、その後に通常の面生成系を順に試し、必要に応じて Beautify / Quad 化まで行います。F2、Quad Adder、Quad Cap Tool、NitroCap、日常的なパッチ修復ワークフローを意識した、失敗しにくい補助です。",
("*","Try Bridge Loops"):"ブリッジループを試す",
("*","When the selection resolves to two disconnected edge groups, try Bridge Edge Loops first so strips and caps can be generated in-place."):"選択が2つの分離したエッジ群に解決される場合、まず Bridge Edge Loops を試して、帯状面やキャップをその場で生成しやすくします。",
("*","Try EdgeNet Fill"):"EdgeNet Fill を試す",
("*","Run EdgeNet Prepare / Fill before generic face fill. This improves success on branchy edge networks and patch-like selections."):"汎用的な面生成の前に EdgeNet Prepare / Fill を実行します。枝分かれしたエッジネットワークやパッチ状の選択で成功率が上がります。",
("*","Try Holes Fill"):"Fill Holes を試す",
("*","Use Fill Holes as a late fallback for open boundary cleanup when other fill methods do not succeed."):"他の埋め処理が成功しない場合の遅い段階のフォールバックとして Fill Holes を使い、開いた境界のクリーンアップを試みます。",
("*","Bridge Edge Loops"):"Bridge Edge Loops",
("*","Grid Fill"):"Grid Fill",
("*","EdgeNet Fill"):"EdgeNet Fill",
("*","Edge / Face Add"):"Edge / Face Add",
})

translation_catalog_dict ["ja_JP"].update ({
("*","Precision / CAD / Workplane"):"精密 / CAD / ワークプレーン",
("*","Advanced Surface / Deform"):"高度サーフェス / デフォーム",
("*","Layout / Replacement"):"レイアウト / 置換",
("*","Use selected edges/faces/objects as a high-level guide, then drop into the specialized precision panels only when you need deeper parameters."):"選択したエッジ・面・オブジェクトを高レベルなガイドとして使い、より細かい調整が必要な時だけ専門パネルへ入れるようにしています。",
("*","Expose the migrated surface-detail, smart-extrude, slice, deform, and cleanup helpers directly in the hub so the suite stays compact for beginners and fast for experts."):"移行済みの面ディテール、スマート押し出し、スライス、デフォーム、クリーンアップ補助をハブへ直接表示し、初心者にはコンパクトに、熟練者には高速に使える構成にしています。",
("*","Replacement, randomization, face-based component placement, drop-to-surface, isolation, and audit helpers for archviz, kitbash layout, and environment dressing."):"置換、ランダム化、面ベース配置、面へのドロップ、孤立表示、監査をまとめ、Archviz、キットバッシュ配置、環境ドレッシングを素早く行えるようにします。",
})


def _t (msg :str )->str :
    try :
        return _sms_pgettext (msg )
    except Exception :
        return msg 


def _unique_name (existing ,base :str )->str :
    if base not in existing :
        return base 
    i =1 
    while True :
        name =f"{base }_{i :03d}"
        if name not in existing :
            return name 
        i +=1 


def _ensure_collection (context ,name :str ):
    col =bpy .data .collections .get (name )
    if col is None :
        col =bpy .data .collections .new (name )
        context .scene .collection .children .link (col )
    return col 


_SMS_FACTORY_OWNER_KEY = "_sms_factory_owner"

def _ensure_owned_collection (context ,name :str ,owner :str ):
    col =bpy .data .collections .get (name )
    if col is not None and col .get (_SMS_FACTORY_OWNER_KEY )==owner :
        return col ,False 
    actual_name =_unique_name (set (bpy .data .collections .keys ()),name )
    col =bpy .data .collections .new (actual_name )
    try :
        col [_SMS_FACTORY_OWNER_KEY ]=owner 
        context .scene .collection .children .link (col )
    except Exception :
        bpy .data .collections .remove (col )
        raise 
    return col ,True 



def _link_object_to_collection (obj ,col ):
    if col :
        try :
            if col .objects .get (obj .name )is None :
                col .objects .link (obj )
        except Exception :
            pass 


def _set_all_faces_smooth (obj ):
    try :
        for poly in obj .data .polygons :
            poly .use_smooth =True 
    except Exception :
        pass 


def _add_box_to_bmesh (bm ,min_corner :Vector ,max_corner :Vector ):
    x0 ,y0 ,z0 =min_corner 
    x1 ,y1 ,z1 =max_corner 
    verts =[
    bm .verts .new ((x0 ,y0 ,z0 )),
    bm .verts .new ((x1 ,y0 ,z0 )),
    bm .verts .new ((x1 ,y1 ,z0 )),
    bm .verts .new ((x0 ,y1 ,z0 )),
    bm .verts .new ((x0 ,y0 ,z1 )),
    bm .verts .new ((x1 ,y0 ,z1 )),
    bm .verts .new ((x1 ,y1 ,z1 )),
    bm .verts .new ((x0 ,y1 ,z1 )),
    ]
    bm .verts .ensure_lookup_table ()
    faces =(
    (0 ,1 ,2 ,3 ),
    (4 ,5 ,6 ,7 ),
    (0 ,1 ,5 ,4 ),
    (1 ,2 ,6 ,5 ),
    (2 ,3 ,7 ,6 ),
    (3 ,0 ,4 ,7 ),
    )
    for idxs in faces :
        try :
            bm .faces .new ([verts [i ]for i in idxs ])
        except ValueError :
            pass 
    return verts 


def _find_existing_modifier (obj ,mod_type :str ,name_prefix :str =""):
    for mod in getattr (obj ,'modifiers',[]):
        try :
            if getattr (mod ,'type','')==mod_type and (not name_prefix or str (getattr (mod ,'name','')).startswith (name_prefix )):
                return mod 
        except Exception :
            continue 
    if name_prefix :
        for mod in getattr (obj ,'modifiers',[]):
            try :
                if getattr (mod ,'type','')==mod_type :
                    return mod 
            except Exception :
                continue 
    return None 


def _add_weighted_normal_modifier (obj ,reuse_existing :bool =True ):
    mod =_find_existing_modifier (obj ,'WEIGHTED_NORMAL','SMS_WeightedNormal')if reuse_existing else None 
    if mod is None and reuse_existing :
        mod =_find_existing_modifier (obj ,'WEIGHTED_NORMAL')
    if mod is None :
        mod =obj .modifiers .new (name =_unique_name ({m .name for m in obj .modifiers },"SMS_WeightedNormal"),type ='WEIGHTED_NORMAL')
    if hasattr (mod ,'keep_sharp'):
        mod .keep_sharp =True 
    if hasattr (mod ,'weight'):
        mod .weight =50 
    if hasattr (mod ,'mode'):
        mod .mode ='FACE_AREA_WITH_ANGLE'
    if hasattr (mod ,'use_face_influence'):
        mod .use_face_influence =True 
    return mod 


def _add_bevel_modifier (obj ,width :float ,segments :int ,reuse_existing :bool =True ):
    mod =_find_existing_modifier (obj ,'BEVEL','SMS_Bevel')if reuse_existing else None 
    if mod is None and reuse_existing :
        mod =_find_existing_modifier (obj ,'BEVEL')
    if mod is None :
        mod =obj .modifiers .new (name =_unique_name ({m .name for m in obj .modifiers },"SMS_Bevel"),type ='BEVEL')
    if hasattr (mod ,'limit_method'):
        mod .limit_method ='ANGLE'
    if hasattr (mod ,'width'):
        mod .width =max (0.0 ,float (width ))
    if hasattr (mod ,'segments'):
        mod .segments =max (1 ,int (segments ))
    if hasattr (mod ,'profile'):
        mod .profile =0.7 
    if hasattr (mod ,'harden_normals'):
        mod .harden_normals =True 
    if hasattr (mod ,'miter_outer'):
        try :
            mod .miter_outer ='MITER_ARC'
        except Exception :
            pass 
    return mod 


def _selected_mesh_objects (context ,include_active =True ):
    objs =[o for o in context .selected_objects if o and o .type =='MESH']
    if include_active and context .active_object and context .active_object .type =='MESH'and context .active_object not in objs :
        objs .append (context .active_object )
    return objs 


def _active_mesh_object (context ):
    obj =context .active_object 
    if obj and obj .type =='MESH':
        return obj 
    return None 


def _feature_enabled (context ,key :str ,default :bool =True )->bool :
    try :
        from .utils import external_feature_enabled 
        return external_feature_enabled (context ,'smart_modeling_suite',key ,default =default ,when_missing =False )
    except Exception :
        return False 


def _operator_available (operator_id :str )->bool :
    return operator_available (operator_id )


def _operator_runnable (operator_id :str )->bool :
    return operator_runnable (operator_id )


def _draw_ui_operator (layout ,context ,operator_id :str ,*,text =None ,icon ='NONE',enabled =True ,missing_icon ='ERROR'):
    sub =layout .row (align =True )
    available =_operator_available (operator_id )
    runnable =_operator_runnable (operator_id )if available else False 
    sub .enabled =bool (enabled and runnable )
    if available :
        try :
            from .icons import operator as _sms_icon_operator
            return _sms_icon_operator (sub ,operator_id ,text =text ,icon_name =operator_id ,fallback_icon =icon )
        except Exception :
            if text is None :
                return sub .operator (operator_id ,icon =icon )
            return sub .operator (operator_id ,text =text ,icon =icon )
    sub .alert =True 
    sub .enabled =False 
    label =text if text is not None else operator_id 
    try :
        from .icons import label as _sms_icon_label
        _sms_icon_label (sub ,text =label ,icon_name =missing_icon ,fallback_icon =missing_icon )
    except Exception :
        sub .label (text =label ,icon =missing_icon )
    return None 


class SMSHubProperties (PropertyGroup ):
    boolean_operation :EnumProperty (
    name ="Boolean Operation",
    description ="Choose how cutter meshes affect the active target mesh.",
    items =[
    ('DIFFERENCE','Difference','Subtract cutters from the target'),
    ('UNION','Union','Fuse cutters into the target'),
    ('INTERSECT','Intersect','Keep only overlapping volume'),
    ],
    default ='DIFFERENCE',
    )
    boolean_solver :EnumProperty (
    name ="Solver",
    description ="Boolean solver used for newly created modifiers. Exact is safer for complex intersections; Fast is lighter.",
    items =[
    ('EXACT','Exact','Safer for complex hard-surface intersections'),
    ('FAST','Fast','Lighter and faster for simpler cases'),
    ],
    default ='EXACT',
    )
    hs_auto_bevel :BoolProperty (
    name ="Auto Bevel",
    description ="Add a support bevel modifier after the boolean stack to stabilize highlights in hard-surface workflows.",
    default =True ,
    )
    hs_bevel_width :FloatProperty (
    name ="Bevel Width",
    description ="Width used by the auto-created bevel modifier.",
    default =0.01 ,
    min =0.0 ,
    max =10.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    hs_bevel_segments :IntProperty (
    name ="Bevel Segments",
    description ="Segment count used by the auto-created bevel modifier.",
    default =3 ,
    min =1 ,
    max =12 ,
    )
    hs_weighted_normal :BoolProperty (
    name ="Auto Weighted Normal",
    description ="Add a Weighted Normal modifier after the hard-surface stack for cleaner shading.",
    default =True ,
    )
    hs_organize_cutters :BoolProperty (
    name ="Organize Cutters",
    description ="Link cutters into a dedicated collection so boolean helper objects stay organized in the Outliner.",
    default =True ,
    )

    cleanup_merge_distance :FloatProperty (
    name ="Merge Distance",
    description ="Distance used when merging overlapping vertices during cleanup.",
    default =0.0001 ,
    min =0.0 ,
    max =0.1 ,
    precision =6 ,
    subtype ='DISTANCE',
    )
    cleanup_fill_holes :BoolProperty (
    name ="Fill Holes",
    description ="Try to fill open boundaries after cleanup.",
    default =False ,
    )
    cleanup_join_tris :BoolProperty (
    name ="Join Triangles",
    description ="Try to join adjacent triangles into quads after cleanup or fill.",
    default =True ,
    )
    cleanup_recalc_normals :BoolProperty (
    name ="Recalculate Normals",
    description ="Recalculate normals after cleanup to reduce shading glitches.",
    default =True ,
    )

    pipe_radius :FloatProperty (
    name ="Pipe Radius",
    description ="Bevel depth applied to the generated pipe curve.",
    default =0.01 ,
    min =0.0 ,
    max =10.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    pipe_resolution :IntProperty (
    name ="Pipe Resolution",
    description ="Curve bevel resolution used for the generated pipe.",
    default =4 ,
    min =0 ,
    max =24 ,
    )
    pipe_fill_caps :BoolProperty (
    name ="Fill Caps",
    description ="Close the pipe ends when the curve supports cap filling.",
    default =True ,
    )

    array_offset_x :FloatProperty (
    name ="Array Offset X",
    description ="Relative X offset used by the Array modifier.",
    default =1.0 ,
    min =-1000.0 ,
    max =1000.0 ,
    precision =4 ,
    )
    array_count :IntProperty (
    name ="Array Count",
    description ="Fallback count used when fit-curve mode is unavailable or disabled.",
    default =8 ,
    min =1 ,
    max =10000 ,
    )
    array_merge_vertices :BoolProperty (
    name ="Merge Array Vertices",
    description ="Merge touching vertices in the generated array when the modifier supports it.",
    default =True ,
    )

    scatter_count :IntProperty (
    name ="Scatter Count",
    description ="Number of linked instances to scatter across the active surface.",
    default =64 ,
    min =1 ,
    max =100000 ,
    )
    scatter_seed :IntProperty (
    name ="Scatter Seed",
    description ="Random seed used for scatter placement.",
    default =0 ,
    min =0 ,
    max =2 **31 -1 ,
    )
    scatter_scale_min :FloatProperty (
    name ="Scale Min",
    description ="Minimum random scale used by the scatter operator.",
    default =0.85 ,
    min =0.0001 ,
    max =1000.0 ,
    )
    scatter_scale_max :FloatProperty (
    name ="Scale Max",
    description ="Maximum random scale used by the scatter operator.",
    default =1.15 ,
    min =0.0001 ,
    max =1000.0 ,
    )
    scatter_random_z_deg :FloatProperty (
    name ="Random Z (deg)",
    description ="Maximum random rotation around the local up axis in degrees.",
    default =180.0 ,
    min =0.0 ,
    max =360.0 ,
    )
    scatter_align_normal :BoolProperty (
    name ="Align to Surface",
    description ="Align scattered instances to the surface normal.",
    default =True ,
    )
    scatter_surface_offset :FloatProperty (
    name ="Surface Offset",
    description ="Push scattered instances away from the surface along the normal.",
    default =0.0 ,
    min =-10.0 ,
    max =10.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )

    conform_mode :EnumProperty (
    name ="Conform Mode",
    description ="Choose how selected detail meshes should conform to the active surface.",
    items =[
    ('NEAREST_SURFACEPOINT','Nearest Surface','Use the closest surface point for each detail mesh'),
    ('PROJECT','Project','Project onto the surface along the object local Z axis when supported'),
    ],
    default ='NEAREST_SURFACEPOINT',
    )
    conform_offset :FloatProperty (
    name ="Conform Offset",
    description ="Offset kept between the conformed detail and the target surface.",
    default =0.001 ,
    min =-10.0 ,
    max =10.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    conform_parent :BoolProperty (
    name ="Parent To Surface",
    description ="Parent the conformed detail objects to the active surface for easier scene organization.",
    default =False ,
    )
    conform_organize :BoolProperty (
    name ="Organize Details",
    description ="Link conformed detail objects into a dedicated helper collection.",
    default =True ,
    )

    floor_board_width :FloatProperty (
    name ="Floor Board Width",
    description ="Width of each generated floor board row.",
    default =0.18 ,
    min =0.001 ,
    max =1000.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    floor_board_length :FloatProperty (
    name ="Floor Board Length",
    description ="Target length of each floor board segment.",
    default =1.2 ,
    min =0.001 ,
    max =1000.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    floor_gap :FloatProperty (
    name ="Floor Gap",
    description ="Gap placed between generated floor boards.",
    default =0.005 ,
    min =0.0 ,
    max =1.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    floor_thickness :FloatProperty (
    name ="Floor Thickness",
    description ="Thickness of the generated floor boards.",
    default =0.02 ,
    min =0.0001 ,
    max =10.0 ,
    precision =4 ,
    subtype ='DISTANCE',
    )
    floor_stagger :FloatProperty (
    name ="Floor Stagger",
    description ="Row-to-row offset ratio used to stagger floor boards.",
    default =0.5 ,
    min =0.0 ,
    max =1.0 ,
    precision =3 ,
    )
    floor_axis :EnumProperty (
    name ="Board Axis",
    description ="Choose whether boards mainly run along the local X axis or Y axis of the active object.",
    items =[
    ('X','Boards X','Boards run mainly along the local X axis'),
    ('Y','Boards Y','Boards run mainly along the local Y axis'),
    ],
    default ='X',
    )


BoolProperty = _BpyBoolProperty
EnumProperty = _BpyEnumProperty
FloatProperty = _BpyFloatProperty
IntProperty = _BpyIntProperty
PointerProperty = _BpyPointerProperty

class SMS_OT_apply_weighted_normal_modifier (Operator ):
    bl_idname ="sms.apply_weighted_normal_modifier"
    bl_label ="Weighted Normal"
    bl_description ="Apply or refresh a Weighted Normal modifier on the selected mesh objects for cleaner hard-surface shading. Works well after boolean, bevel, or kitbash-style detail stacking and keeps the modifier stack editable."
    bl_options ={'UNDO'}

    keep_sharp :BoolProperty (name ="Keep Sharp",description ="Preserve existing sharp-edge shading when the modifier supports it.",default =True )
    use_face_influence :BoolProperty (name ="Face Influence",description ="Use face strength / influence information when available for stronger hard-surface shading control.",default =True )
    reuse_existing :BoolProperty (name ="Reuse Existing",description ="If a Weighted Normal modifier already exists on the object, update it instead of creating duplicates.",default =True )
    shade_smooth :BoolProperty (name ="Shade Smooth",description ="Mark all faces smooth before or while applying the modifier.",default =True )
    weight :IntProperty (name ="Weight",min =1 ,max =100 ,default =50 )
    mode :EnumProperty (
    name ="Mode",
    description ="Weighted Normal mode used by the modifier when Blender exposes the option.",
    items =[
    ('FACE_AREA','Face Area','Weight by face area.'),
    ('CORNER_ANGLE','Corner Angle','Weight by corner angle.'),
    ('FACE_AREA_WITH_ANGLE','Area + Angle','Weight by both face area and corner angle.'),
    ],
    default ='FACE_AREA_WITH_ANGLE',
    )

    @classmethod 
    def poll (cls ,context ):
        return any (o for o in getattr (context ,'selected_objects',[])if getattr (o ,'type','')=='MESH')or (context .active_object and context .active_object .type =='MESH')

    def _iter_targets (self ,context ):
        seen =set ()
        for obj in list (getattr (context ,'selected_objects',[])or []):
            if obj and getattr (obj ,'type','')=='MESH'and obj .name not in seen :
                seen .add (obj .name )
                yield obj 
        obj =getattr (context ,'active_object',None )
        if obj and getattr (obj ,'type','')=='MESH'and obj .name not in seen :
            yield obj 

    def execute (self ,context ):
        count =0 
        for obj in self ._iter_targets (context ):
            mod =None 
            if self .reuse_existing :
                for m in obj .modifiers :
                    if getattr (m ,'type','')=='WEIGHTED_NORMAL':
                        mod =m 
                        break 
            if mod is None :
                try :
                    mod =_add_weighted_normal_modifier (obj )
                except Exception :
                    mod =None 
            if mod is None :
                continue 
            if self .shade_smooth :
                _set_all_faces_smooth (obj )
            try :
                if hasattr (obj .data ,'use_auto_smooth'):
                    obj .data .use_auto_smooth =True 
            except Exception :
                pass 
            try :
                if hasattr (mod ,'keep_sharp'):
                    mod .keep_sharp =bool (self .keep_sharp )
            except Exception :
                pass 
            try :
                if hasattr (mod ,'weight'):
                    mod .weight =int (self .weight )
            except Exception :
                pass 
            try :
                if hasattr (mod ,'mode'):
                    mod .mode =self .mode 
            except Exception :
                pass 
            try :
                if hasattr (mod ,'use_face_influence'):
                    mod .use_face_influence =bool (self .use_face_influence )
            except Exception :
                pass 
            count +=1 

        if count ==0 :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}
        self .report ({'INFO'},f"{_t ('Weighted normal applied / updated')}: {count }")
        return {'FINISHED'}


class SMS_OT_smart_boolean_stack (Operator ):
    bl_idname ="sms.smart_boolean_stack"
    bl_label ="Build HS Boolean Stack"
    bl_description ="Create a compact non-destructive hard-surface stack on the active object using the other selected mesh objects as cutters. Adds Boolean modifiers per cutter, optional bevel support, optional weighted normals, and optional cutter organization for a Hard Ops / Boxcutter / Hard Mesh / MeshFusion style workflow."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        props =context .scene .hub_props 
        target =_active_mesh_object (context )
        if target is None :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}
        cutters =[o for o in _selected_mesh_objects (context )if o !=target ]
        if not cutters :
            self .report ({'WARNING'},_t ("Select at least one cutter mesh besides the active object"))
            return {'CANCELLED'}

        if context .mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        cutter_col =_ensure_collection (context ,f"SMS_Cutters_{target .name }")if props .hs_organize_cutters else None 
        for cutter in cutters :
            mod =target .modifiers .new (
            name =_unique_name ({m .name for m in target .modifiers },f"SMS_{props .boolean_operation }_{cutter .name }"),
            type ='BOOLEAN'
            )
            try :
                mod .operation =props .boolean_operation 
            except Exception :
                pass 
            if hasattr (mod ,'solver'):
                try :
                    mod .solver =props .boolean_solver 
                except Exception :
                    pass 
            try :
                mod .object =cutter 
            except Exception :
                pass 

            if cutter_col :
                _link_object_to_collection (cutter ,cutter_col )
            try :
                cutter .display_type ='WIRE'
            except Exception :
                pass 
            try :
                cutter .hide_render =True 
            except Exception :
                pass 

        _set_all_faces_smooth (target )
        if props .hs_auto_bevel :
            _add_bevel_modifier (target ,props .hs_bevel_width ,props .hs_bevel_segments )
        if props .hs_weighted_normal :
            _add_weighted_normal_modifier (target )

        self .report ({'INFO'},_t ("Created hard-surface boolean stack"))
        return {'FINISHED'}


class SMS_OT_smart_cleanup_repair (Operator ):
    bl_idname ="sms.smart_cleanup_repair"
    bl_label ="Quick Repair / Cleanup"
    bl_description ="Repair common mesh issues on the selected mesh objects: merge doubles, dissolve degenerates, delete loose geometry, optionally fill holes, optionally join triangles to quads, and recalculate normals. Designed as a safe recovery pass for imported assets, boolean-heavy meshes, and messy kitbash data."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        props =context .scene .hub_props 
        objects =_selected_mesh_objects (context )
        if not objects :
            obj =_active_mesh_object (context )
            if obj :
                objects =[obj ]
        if not objects :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}

        processed =0 
        seen_meshes =set ()
        for obj in objects :
            # Linked duplicates share one mesh: repair it once, through the Edit Mode
            # BMesh whenever that mesh is in Edit Mode (whichever object entered it).
            mesh_key =obj .data .as_pointer ()
            if mesh_key in seen_meshes :
                continue 
            seen_meshes .add (mesh_key )
            try :
                import bmesh 
            except Exception as exc :
                self .report ({'ERROR'},_t ("Mesh repair could not start: {detail}").format (detail =str (exc )))
                return {'CANCELLED'}

            if obj .data .is_editmode :
                bm =bmesh .from_edit_mesh (obj .data )
                owns_bm =False 
            else :
                bm =bmesh .new ()
                bm .from_mesh (obj .data )
                owns_bm =True 

            try :
                bmesh .ops .remove_doubles (bm ,verts =list (bm .verts ),dist =props .cleanup_merge_distance )
            except Exception :
                pass 
            try :
                bmesh .ops .dissolve_degenerate (bm ,edges =list (bm .edges ),dist =max (1e-9 ,props .cleanup_merge_distance *0.1 ))
            except Exception :
                pass 
            try :
                loose_verts =[v for v in bm .verts if not v .link_edges ]
                loose_edges =[e for e in bm .edges if not e .link_faces ]
                if loose_edges :
                    bmesh .ops .delete (bm ,geom =loose_edges ,context ='EDGES')
                if loose_verts :
                    bmesh .ops .delete (bm ,geom =loose_verts ,context ='VERTS')
            except Exception :
                pass 
            if props .cleanup_fill_holes :
                try :
                    boundary_edges =[e for e in bm .edges if e .is_boundary ]
                    if boundary_edges :
                        bmesh .ops .holes_fill (bm ,edges =boundary_edges ,sides =0 )
                except Exception :
                    pass 
            if props .cleanup_join_tris :
                try :
                    bmesh .ops .join_triangles (
                    bm ,
                    faces =list (bm .faces ),
                    angle_face_threshold =math .radians (45.0 ),
                    angle_shape_threshold =math .radians (45.0 ),
                    )
                except Exception :
                    pass 
            if props .cleanup_recalc_normals :
                try :
                    bmesh .ops .recalc_face_normals (bm ,faces =list (bm .faces ))
                except Exception :
                    pass 

            if owns_bm :
                bm .to_mesh (obj .data )
                obj .data .update ()
                bm .free ()
            else :
                bmesh .update_edit_mesh (obj .data ,loop_triangles =True ,destructive =True )
            processed +=1 

        if processed :
            self .report ({'INFO'},_t ("Cleanup complete"))
            return {'FINISHED'}
        return {'CANCELLED'}


class SMS_OT_smart_fill_topology (Operator ):
    bl_idname ="sms.smart_fill_topology"
    bl_label ="Smart Fill / Quad Repair"
    bl_description ="Fill, cap, or bridge the current edit-mode boundary with a smarter fallback chain. The operator tries boundary-aware bridge, grid fill, EdgeNet preparation/fill, and then standard face creation tools before optional beautify / quad cleanup. This acts as a more failure-resistant helper inspired by F2, Quad Adder, Quad Cap Tool, NitroCap, and day-to-day patch repair workflows."
    bl_options ={'UNDO'}

    prefer_grid_fill :BoolProperty (name ="Prefer Grid Fill",description ="Try Grid Fill early when a single boundary loop is selected so patch results stay quad-friendly when possible.",default =True )
    try_bridge_loops :BoolProperty (name ="Try Bridge Loops",description ="When the selection resolves to two disconnected edge groups, try Bridge Edge Loops first so strips and caps can be generated in-place.",default =True )
    try_edgenet_fill :BoolProperty (name ="Try EdgeNet Fill",description ="Run EdgeNet Prepare / Fill before generic face fill. This improves success on branchy edge networks and patch-like selections.",default =True )
    try_holes_fill :BoolProperty (name ="Try Holes Fill",description ="Use Fill Holes as a late fallback for open boundary cleanup when other fill methods do not succeed.",default =True )
    beautify :BoolProperty (name ="Beautify Fill",description ="Run a beautify pass after filling to reduce awkward internal diagonals when Blender can improve them safely.",default =True )
    tris_to_quads :BoolProperty (name ="Convert To Quads",description ="Attempt triangle-to-quad conversion after fill to keep the result cleaner for subdivision and retopo cleanup.",default =True )

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='EDIT_MESH'and context .active_object and context .active_object .type =='MESH'

    def execute (self ,context ):
        import bmesh 

        obj =context .active_object 
        bm =bmesh .from_edit_mesh (obj .data )
        selected_edges =[e for e in bm .edges if e .select ]
        if not selected_edges :
            self .report ({'WARNING'},_t ("Select some edges in Edit Mode first"))
            return {'CANCELLED'}

        # Every selected edge already bordered only by selected faces means the
        # selection is a closed region: there is nothing to fill or bridge.
        if all (e .is_manifold and all (f .select for f in e .link_faces )for e in selected_edges ):
            self .report ({'WARNING'},_t ("The selection has no open boundary to fill"))
            return {'CANCELLED'}

        def _selected_edge_group_count ():
            remaining =set (selected_edges )
            groups =0 
            while remaining :
                edge =remaining .pop ()
                stack =[edge ]
                groups +=1 
                while stack :
                    cur =stack .pop ()
                    for v in cur .verts :
                        for linked in v .link_edges :
                            if linked .select and linked in remaining :
                                remaining .remove (linked )
                                stack .append (linked )
            return groups 

        group_count =_selected_edge_group_count ()
        ok =False 
        step_used =None 

        def _face_count ():
            return len (bmesh .from_edit_mesh (obj .data ).faces )

        def _try (op ,label ):
            nonlocal ok ,step_used
            if ok :
                return None
            before =_face_count ()
            result =call_operator_safe (op )
            # Blender's fill operators can finish without creating anything
            # (for example on a closed selection), so success means new faces.
            if result is not None and _face_count ()>before :
                ok =True
                step_used =label
            return result

        if self .try_bridge_loops and group_count ==2 :
            _try (lambda :bpy .ops .mesh .bridge_edge_loops ('EXEC_DEFAULT', False, ),"Bridge Edge Loops")
        if self .prefer_grid_fill and group_count ==1 :
            _try (lambda :bpy .ops .mesh .fill_grid ('EXEC_DEFAULT', False, ),"Grid Fill")
        if self .try_edgenet_fill and not ok :
            prepare_op =get_operator_callable ("mesh.edgenet_prepare")if operator_available ("mesh.edgenet_prepare")else None
            fill_op =get_operator_callable ("mesh.edgenet_fill")if operator_available ("mesh.edgenet_fill")else None
            if prepare_op is not None and fill_op is not None :
                call_operator_safe (prepare_op ,'EXEC_DEFAULT',False )
                _try (lambda :fill_op ('EXEC_DEFAULT',False ),"EdgeNet Fill")
        _try (lambda :bpy .ops .mesh .edge_face_add ('EXEC_DEFAULT', False, ),"Edge / Face Add")
        _try (lambda :bpy .ops .mesh .fill ('EXEC_DEFAULT', False, ),"Fill")
        if self .try_holes_fill :
            _try (lambda :bpy .ops .mesh .fill_holes ('EXEC_DEFAULT', False, sides =0 ),"Fill Holes")

        if not ok :
            self .report ({'WARNING'},_t ("The selection has no open boundary to fill"))
            return {'CANCELLED'}
        if self .beautify :
            call_operator_safe (lambda :bpy .ops .mesh .beautify_fill ('EXEC_DEFAULT', False, ))
        if self .tris_to_quads :
            call_operator_safe (lambda :bpy .ops .mesh .tris_convert_to_quads ('EXEC_DEFAULT', False, ))
        msg =_t ("Fill / repair complete")
        if step_used :
            msg =f"{msg } ({step_used })"
        self .report ({'INFO'},msg )
        return {'FINISHED'}


class SMS_OT_smart_pipe_from_selection (Operator ):
    bl_idname ="sms.smart_pipe_from_selection"
    bl_label ="Make Pipe / Cable"
    bl_description ="Convert the current selected edge path into a beveled curve pipe. This is useful for cable, hose, trim, and sweep-style workflows inspired by Sweep Mesh, Cablerator, ReeperX, and curve-based modeling tools."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        obj =context .active_object 
        if not obj :
            return False 
        if context .mode =='EDIT_MESH'and obj .type =='MESH':
            return True 
        if context .mode =='OBJECT'and obj .type =='CURVE':
            return True 
        return False 

    def execute (self ,context ):
        props =context .scene .hub_props 
        obj =context .active_object 
        if context .mode =='OBJECT'and obj .type =='CURVE':
            curve =obj .data 
            try :
                curve .dimensions ='3D'
            except Exception :
                pass 
            try :
                curve .bevel_depth =props .pipe_radius 
            except Exception :
                pass 
            try :
                curve .bevel_resolution =props .pipe_resolution 
            except Exception :
                pass 
            if hasattr (curve ,'use_fill_caps'):
                try :
                    curve .use_fill_caps =props .pipe_fill_caps 
                except Exception :
                    pass 
            self .report ({'INFO'},_t ("Updated active curve with pipe settings"))
            return {'FINISHED'}

        import bmesh 
        from .precision_tools import _selected_edge_paths_world_from_bmesh ,_new_curve_object_from_world_paths ,_activate_only 

        bm =bmesh .from_edit_mesh (obj .data )
        paths =_selected_edge_paths_world_from_bmesh (obj ,bm )
        if not paths :
            self .report ({'WARNING'},_t ("Select some edges in Edit Mode first"))
            return {'CANCELLED'}

        state =capture_object_context (context )
        if not ensure_object_mode (context ,obj ):
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        curve_obj =_new_curve_object_from_world_paths (
        context ,
        _unique_name (set (bpy .data .objects .keys ()),f"Pipe_{obj .name }"),
        paths ,
        reference_obj =obj ,
        bevel_depth =props .pipe_radius ,
        bevel_resolution =props .pipe_resolution ,
        fill_caps =props .pipe_fill_caps ,
        )
        if curve_obj is None :
            restore_object_context (context ,state )
            self .report ({'ERROR'},_t ("Failed to build curve data from the selected edges"))
            return {'CANCELLED'}

        _activate_only (context ,curve_obj )
        self .report ({'INFO'},_t ("Generated pipe curve from selected edges"))
        return {'FINISHED'}



class SMS_OT_smart_array_along_curve (Operator ):
    bl_idname ="sms.smart_array_along_curve"
    bl_label ="Array Along Curve"
    bl_description ="Build an Array + Curve modifier stack on the active mesh using the selected curve as the path. Useful for RailClone-like repetition, trims, railing, modular walls, and architectural detailing."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        props =context .scene .hub_props 
        active =_active_mesh_object (context )
        if active is None :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}
        curve_objs =[o for o in context .selected_objects if o and o !=active and o .type =='CURVE']
        if len (curve_objs )!=1 :
            self .report ({'WARNING'},_t ("Select one curve object together with the active mesh object"))
            return {'CANCELLED'}
        curve =curve_objs [0 ]

        if context .mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        array_mod =_find_existing_modifier (active ,'ARRAY','SMS_Array')
        if array_mod is None :
            array_mod =active .modifiers .new (name =_unique_name ({m .name for m in active .modifiers },"SMS_Array"),type ='ARRAY')
        if hasattr (array_mod ,'use_relative_offset'):
            array_mod .use_relative_offset =True 
        if hasattr (array_mod ,'relative_offset_displace'):
            array_mod .relative_offset_displace [0 ]=props .array_offset_x 
            array_mod .relative_offset_displace [1 ]=0.0 
            array_mod .relative_offset_displace [2 ]=0.0 
        if hasattr (array_mod ,'fit_type'):
            try :
                array_mod .fit_type ='FIT_CURVE'
                array_mod .curve =curve 
            except Exception :
                try :
                    array_mod .count =props .array_count 
                except Exception :
                    pass 
        elif hasattr (array_mod ,'count'):
            array_mod .count =props .array_count 
        if hasattr (array_mod ,'use_merge_vertices'):
            try :
                array_mod .use_merge_vertices =props .array_merge_vertices 
            except Exception :
                pass 
        if hasattr (array_mod ,'merge_threshold'):
            try :
                array_mod .merge_threshold =0.0001 
            except Exception :
                pass 

        curve_mod =_find_existing_modifier (active ,'CURVE','SMS_Curve')
        if curve_mod is None :
            curve_mod =active .modifiers .new (name =_unique_name ({m .name for m in active .modifiers },"SMS_Curve"),type ='CURVE')
        curve_mod .object =curve 
        if hasattr (curve_mod ,'deform_axis'):
            try :
                curve_mod .deform_axis ='POS_X'
            except Exception :
                pass 

        self .report ({'INFO'},_t ("Created array-along-curve stack"))
        return {'FINISHED'}


class SMS_OT_scatter_instances_bake (Operator ):
    bl_idname ="sms.scatter_instances_bake"
    bl_label ="Scatter Instances (Bake)"
    bl_description ="Scatter linked object instances over the active surface using weighted triangle-area sampling. Creates a dedicated scatter collection and a root empty, making it useful for environment blocking, vegetation placement, debris, and kitbash dressing inspired by Forest Pack / Geo-Scatter style workflows."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        props =context .scene .hub_props 
        surface =_active_mesh_object (context )
        if surface is None :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}
        sources =[o for o in context .selected_objects if o and o !=surface and o .type in {'MESH','CURVE','EMPTY'}]
        if not sources :
            self .report ({'WARNING'},_t ("Select at least one scatter source object besides the active surface"))
            return {'CANCELLED'}

        if context .mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        depsgraph =context .evaluated_depsgraph_get ()
        eval_obj =surface .evaluated_get (depsgraph )
        mesh =eval_obj .to_mesh ()
        try :
            mesh .calc_loop_triangles ()
            tris =list (mesh .loop_triangles )
            if not tris :
                self .report ({'WARNING'},_t ("No valid surface triangles were found on the active object"))
                return {'CANCELLED'}

            areas =[]
            total =0.0 
            tri_payload =[]
            verts =mesh .vertices 
            for tri in tris :
                ia ,ib ,ic =tri .vertices 
                a =verts [ia ].co .copy ()
                b =verts [ib ].co .copy ()
                c =verts [ic ].co .copy ()
                area =((b -a ).cross (c -a )).length *0.5 
                if area <=1e-12 :
                    continue 
                total +=area 
                areas .append (total )
                tri_payload .append ((a ,b ,c ,tri .normal .copy ()))
            if not tri_payload or total <=0.0 :
                self .report ({'WARNING'},_t ("No valid surface triangles were found on the active object"))
                return {'CANCELLED'}

            owner ="scatter_instances_bake"
            scatter_col ,_scatter_col_created =_ensure_owned_collection (context ,f"SMS_Scatter_{surface .name }",owner )
            root_empty =bpy .data .objects .new (_unique_name (set (bpy .data .objects .keys ()),f"SMS_ScatterRoot_{surface .name }"),None )
            root_empty [_SMS_FACTORY_OWNER_KEY ]=owner 
            _link_object_to_collection (root_empty ,scatter_col )
            root_empty .empty_display_type ='PLAIN_AXES'
            root_empty .matrix_world =surface .matrix_world .copy ()

            rng =random .Random (props .scatter_seed )
            rot_max =math .radians (float (props .scatter_random_z_deg ))
            for _ in range (int (props .scatter_count )):
                pick =rng .random ()*total 
                idx =bisect .bisect_left (areas ,pick )
                a ,b ,c ,normal_local =tri_payload [min (idx ,len (tri_payload )-1 )]
                r1 =math .sqrt (rng .random ())
                r2 =rng .random ()
                p_local =(1.0 -r1 )*a +(r1 *(1.0 -r2 ))*b +(r1 *r2 )*c 
                n_world =(surface .matrix_world .to_3x3 ()@normal_local ).normalized ()
                p_world =surface .matrix_world @p_local 
                p_world =p_world +(n_world *props .scatter_surface_offset )

                src =rng .choice (sources )
                dup =src .copy ()
                if getattr (src ,'data',None )is not None :
                    dup .data =src .data 
                try :
                    dup .animation_data_clear ()
                except Exception :
                    pass 

                base_rot =Matrix .Identity (4 )
                if props .scatter_align_normal :
                    try :
                        base_rot =n_world .to_track_quat ('Z','Y').to_matrix ().to_4x4 ()
                    except Exception :
                        base_rot =Matrix .Identity (4 )
                rand_rot =Matrix .Rotation (rng .uniform (-rot_max ,rot_max ),4 ,'Z')
                s =rng .uniform (min (props .scatter_scale_min ,props .scatter_scale_max ),max (props .scatter_scale_min ,props .scatter_scale_max ))
                scale_mat =Matrix .Diagonal ((s ,s ,s ,1.0 ))
                dup .matrix_world =Matrix .Translation (p_world )@base_rot @rand_rot @scale_mat 
                dup .parent =root_empty 
                _link_object_to_collection (dup ,scatter_col )
        finally :
            eval_obj .to_mesh_clear ()

        self .report ({'INFO'},_t ("Scatter bake complete"))
        return {'FINISHED'}



class SMS_OT_conform_to_surface (Operator ):
    bl_idname ="sms.conform_to_surface"
    bl_label ="Conform / Stitch To Surface"
    bl_description ="Add a non-destructive shrinkwrap-based conform setup to the selected detail meshes so they follow the active surface. This is useful for kitbash details, decals, trim pieces, and surface-mounted parts inspired by xyShrinkWrap, Polystein Kit, NitroDraw, and similar surface placement workflows."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        props =context .scene .hub_props 
        surface =_active_mesh_object (context )
        if surface is None :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}
        details =[o for o in context .selected_objects if o and o !=surface and o .type =='MESH']
        if not details :
            self .report ({'WARNING'},_t ("Select at least one detail mesh besides the active surface"))
            return {'CANCELLED'}

        if context .mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        helper_col =_ensure_collection (context ,f"SMS_Conform_{surface .name }")if props .conform_organize else None 

        for obj in details :
            mod =_find_existing_modifier (obj ,'SHRINKWRAP','SMS_Conform')
            if mod is None :
                mod =obj .modifiers .new (name =_unique_name ({m .name for m in obj .modifiers },"SMS_Conform"),type ='SHRINKWRAP')
            try :
                mod .target =surface 
            except Exception :
                pass 
            if hasattr (mod ,'wrap_method'):
                try :
                    mod .wrap_method =props .conform_mode 
                except Exception :
                    try :
                        mod .wrap_method ='NEAREST_SURFACEPOINT'
                    except Exception :
                        pass 
            if props .conform_mode =='PROJECT':
                for attr in ('use_project_z','use_positive_direction','use_negative_direction'):
                    if hasattr (mod ,attr ):
                        try :
                            setattr (mod ,attr ,True )
                        except Exception :
                            pass 
            if hasattr (mod ,'offset'):
                try :
                    mod .offset =props .conform_offset 
                except Exception :
                    pass 
            if hasattr (mod ,'wrap_mode'):
                try :
                    mod .wrap_mode ='OUTSIDE_SURFACE'
                except Exception :
                    pass 
            if props .conform_parent :
                try :
                    obj .parent =surface 
                    obj .matrix_parent_inverse =surface .matrix_world .inverted ()
                except Exception :
                    pass 
            if helper_col is not None :
                _link_object_to_collection (obj ,helper_col )

        self .report ({'INFO'},_t ("Conformed selected detail meshes to active surface"))
        return {'FINISHED'}


class SMS_OT_detach_separate_clean (Operator ):
    bl_idname ="sms.detach_separate_clean"
    bl_label ="Detach / Separate Clean"
    bl_description ="Separate the current selection into a new object with an optional duplicate-first step and a light cleanup pass. This acts as a safe Blender-friendly helper inspired by Maya detachSeparate and similar clean detachment utilities."
    bl_options ={'UNDO'}

    duplicate_first :BoolProperty (
    name ="Duplicate First",
    description ="Duplicate the selected geometry before separating it, so the source object keeps the original polygons.",
    default =False ,
    )
    cleanup_new_object :BoolProperty (
    name ="Cleanup New Object",
    description ="Run a light cleanup pass on the newly separated object to reduce loose elements and normal issues.",
    default =True ,
    )

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='EDIT_MESH'and context .active_object and context .active_object .type =='MESH'

    def execute (self ,context ):
        import bmesh 

        obj =context .active_object 
        bm =bmesh .from_edit_mesh (obj .data )
        if not (any (v .select for v in bm .verts )or any (e .select for e in bm .edges )or any (f .select for f in bm .faces )):
            self .report ({'WARNING'},_t ("Select at least one component in Edit Mode first"))
            return {'CANCELLED'}

        before_names =set (bpy .data .objects .keys ())
        switched_to_object =True 
        try :
            if self .duplicate_first and call_operator_safe (lambda :bpy .ops .mesh .duplicate ('EXEC_DEFAULT', False, ))is None :
                self .report ({'WARNING'},_t ("Select at least one component in Edit Mode first"))
                return {'CANCELLED'}
            if call_operator_safe (lambda :bpy .ops .mesh .separate ('EXEC_DEFAULT', False, type ='SELECTED'))is None :
                self .report ({'WARNING'},_t ("Failed to separate the current selection into a new object"))
                return {'CANCELLED'}
            switched_to_object =call_operator_safe (lambda :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT'))is not None 
        except Exception as exc :
            self .report ({'ERROR'},_t ("Detach / Separate Clean failed: {detail}").format (detail =str (exc )))
            return {'CANCELLED'}

        new_names =[name for name in bpy .data .objects .keys ()if name not in before_names ]
        new_objects =[bpy .data .objects [name ]for name in new_names if name in bpy .data .objects ]
        if not new_objects :
            self .report ({'WARNING'},_t ("Failed to separate the current selection into a new object"))
            return {'CANCELLED'}

        if self .cleanup_new_object :
            for new_obj in new_objects :
                if new_obj .type !='MESH':
                    continue 
                try :
                    bm_new =bmesh .new ()
                    bm_new .from_mesh (new_obj .data )
                    try :
                        bmesh .ops .remove_doubles (bm_new ,verts =list (bm_new .verts ),dist =1e-6 )
                    except Exception :
                        pass 
                    try :
                        bmesh .ops .dissolve_degenerate (bm_new ,edges =list (bm_new .edges ),dist =1e-8 )
                    except Exception :
                        pass 
                    try :
                        loose_verts =[v for v in bm_new .verts if not v .link_edges ]
                        loose_edges =[e for e in bm_new .edges if not e .link_faces ]
                        if loose_edges :
                            bmesh .ops .delete (bm_new ,geom =loose_edges ,context ='EDGES')
                        if loose_verts :
                            bmesh .ops .delete (bm_new ,geom =loose_verts ,context ='VERTS')
                    except Exception :
                        pass 
                    try :
                        bmesh .ops .recalc_face_normals (bm_new ,faces =list (bm_new .faces ))
                    except Exception :
                        pass 
                    bm_new .to_mesh (new_obj .data )
                    new_obj .data .update ()
                    bm_new .free ()
                except Exception :
                    pass 

        if switched_to_object :
            for obj_sel in context .selected_objects :
                try :
                    obj_sel .select_set (False )
                except Exception :
                    pass 
            for new_obj in new_objects :
                try :
                    new_obj .select_set (True )
                except Exception :
                    pass 
            try :
                context .view_layer .objects .active =new_objects [0 ]
            except Exception :
                pass 
        else :
            self .report ({'WARNING'},_t ('Separated selection, but could not switch to Object Mode for final object handoff.'))

        self .report ({'INFO'},_t ("Detached selection into a clean new object"))
        return {'FINISHED'}


class SMS_OT_relax_selection (Operator ):
    bl_idname ="sms.relax_selection"
    bl_label ="Relax Selection"
    bl_description ="Relax the current selected vertices or edge loop. Uses LoopTools Relax when available, and otherwise falls back to Blender smoothing for a safer all-in-one cleanup pass inspired by LoopTools, NitroRelax, and oaRelaxVerts."
    bl_options ={'UNDO'}

    iterations :IntProperty (
    name ="Iterations",
    description ="How many smoothing passes to run when a fallback method is used.",
    default =10 ,
    min =1 ,
    max =100 ,
    )
    use_looptools :BoolProperty (
    name ="Prefer LoopTools",
    description ="Use LoopTools when available before falling back to built-in Blender smoothing.",
    default =True ,
    )

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='EDIT_MESH'and context .active_object and context .active_object .type =='MESH'

    def execute (self ,context ):
        if self .use_looptools and operator_available ('mesh.looptools_relax'):
            result =call_operator_safe (lambda :bpy .ops .mesh .looptools_relax ('EXEC_DEFAULT', False, interpolation ='cubic',iterations =int (self .iterations ),regular =True ))
            if result is None :
                result =call_operator_safe (lambda :bpy .ops .mesh .looptools_relax ('EXEC_DEFAULT', False, ))
            if result is not None :
                self .report ({'INFO'},_t ("Relax complete"))
                return {'FINISHED'}
        for op_name ,kwargs in (
        # EXEC_DEFAULT uses the RNA default (factor=0), not the UI tool's
        # remembered smoothing strength. Supply the intended half-step.
        ('vertices_smooth',{'repeat':max (1 ,int (self .iterations )), 'factor':0.5}),
        ('vertices_smooth_laplacian',{'repeat':max (1 ,int (self .iterations ))}),
        ):
            result =call_operator_safe (lambda _op_name =op_name ,_kwargs =kwargs :getattr (bpy .ops .mesh ,_op_name )('EXEC_DEFAULT', False, **_kwargs ))
            if result is not None :
                self .report ({'INFO'},_t ("Relax complete"))
                return {'FINISHED'}
        self .report ({'WARNING'},_t ("Select at least one component in Edit Mode first"))
        return {'CANCELLED'}


class SMS_OT_circle_selection (Operator ):
    bl_idname ="sms.circle_selection"
    bl_label ="Circle Selection"
    bl_description ="Fit the current selected vertices into a circular shape. Uses LoopTools Circle when available, and otherwise falls back to Blender's To Sphere transform for a practical circle helper inspired by LoopTools and NitroCycle."
    bl_options ={'UNDO'}

    use_looptools :BoolProperty (
    name ="Prefer LoopTools",
    description ="Use LoopTools when available before falling back to Blender's To Sphere transform.",
    default =True ,
    )

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='EDIT_MESH'and context .active_object and context .active_object .type =='MESH'

    def execute (self ,context ):
        import bmesh 

        bm =bmesh .from_edit_mesh (context .active_object .data )
        sel_verts =[v for v in bm .verts if v .select ]
        if len (sel_verts )<3 :
            self .report ({'WARNING'},_t ("Need at least 3 selected vertices for circle fitting"))
            return {'CANCELLED'}

        if self .use_looptools and operator_available ('mesh.looptools_circle'):
            result =call_operator_safe (lambda :bpy .ops .mesh .looptools_circle ('EXEC_DEFAULT', False, custom_radius =False ,fit ='best',flatten =False ,influence =100.0 ,regular =True ))
            if result is None :
                result =call_operator_safe (lambda :bpy .ops .mesh .looptools_circle ('EXEC_DEFAULT', False, ))
            if result is not None :
                self .report ({'INFO'},_t ("Circle alignment complete"))
                return {'FINISHED'}

        if call_operator_safe (lambda :bpy .ops .transform .tosphere ('EXEC_DEFAULT', False, value =1.0 ))is not None :
            self .report ({'INFO'},_t ("Circle alignment complete"))
            return {'FINISHED'}
        self .report ({'WARNING'},_t ("Need at least 3 selected vertices for circle fitting"))
        return {'CANCELLED'}


class SMS_OT_straighten_selection (Operator ):
    bl_idname ="sms.straighten_selection"
    bl_label ="Straighten Selection"
    bl_description ="Project the current selected vertices onto the best line defined by the farthest selected pair. Useful for fast edge straightening and mesh unbending inspired by Align Edges and Unbend Mesh style tools."
    bl_options ={'UNDO'}

    @classmethod 
    def poll (cls ,context ):
        return context .mode =='EDIT_MESH'and context .active_object and context .active_object .type =='MESH'

    def execute (self ,context ):
        import bmesh 

        bm =bmesh .from_edit_mesh (context .active_object .data )
        sel_verts =[v for v in bm .verts if v .select ]
        if len (sel_verts )<2 :
            self .report ({'WARNING'},_t ("Need at least 2 selected vertices to straighten"))
            return {'CANCELLED'}

        coords =[v .co .copy ()for v in sel_verts ]
        a =coords [0 ]
        b =coords [-1 ]
        best =-1.0 
        for i in range (len (coords )):
            for j in range (i +1 ,len (coords )):
                d =(coords [i ]-coords [j ]).length_squared 
                if d >best :
                    best =d 
                    a =coords [i ]
                    b =coords [j ]

        direction =b -a 
        if direction .length <=1e-12 :
            self .report ({'WARNING'},_t ("Need at least 2 selected vertices to straighten"))
            return {'CANCELLED'}
        direction .normalize ()

        for v in sel_verts :
            t =(v .co -a ).dot (direction )
            v .co =a +direction *t 

        bmesh .update_edit_mesh (context .active_object .data ,loop_triangles =False ,destructive =False )
        self .report ({'INFO'},_t ("Straighten complete"))
        return {'FINISHED'}


class SMS_OT_floor_generator (Operator ):
    bl_idname ="sms.floor_generator"
    bl_label ="Floor Generator"
    bl_description ="Generate a procedural floorboard mesh inside the active object's local footprint using board width, length, gap, thickness, and stagger settings. This is a compact Blender-native helper inspired by FloorGenerator and architectural pattern tools."
    bl_options ={'UNDO'}

    def execute (self ,context ):
        import bmesh 

        props =context .scene .hub_props 
        active =_active_mesh_object (context )
        if active is None :
            self .report ({'WARNING'},_t ("Active mesh object required"))
            return {'CANCELLED'}

        if context .mode !='OBJECT'and safe_mode_set ('OBJECT')is None :
            self .report ({'WARNING'},_t ("Could not switch to Object Mode"))
            return {'CANCELLED'}

        bbox =[Vector (corner )for corner in active .bound_box ]
        min_x =min (v .x for v in bbox )
        max_x =max (v .x for v in bbox )
        min_y =min (v .y for v in bbox )
        max_y =max (v .y for v in bbox )
        min_z =min (v .z for v in bbox )
        max_z =max (v .z for v in bbox )

        if (max_x -min_x )<=1e-6 or (max_y -min_y )<=1e-6 :
            self .report ({'WARNING'},_t ("Active mesh object with a usable footprint is required"))
            return {'CANCELLED'}

        board_width =max (1e-6 ,float (props .floor_board_width ))
        board_length =max (board_width ,float (props .floor_board_length ))
        gap =max (0.0 ,float (props .floor_gap ))
        thickness =max (1e-6 ,float (props .floor_thickness ))
        stagger =max (0.0 ,min (1.0 ,float (props .floor_stagger )))*board_length 

        if props .floor_axis =='X':
            along_min ,along_max =min_x ,max_x 
            cross_min ,cross_max =min_y ,max_y 
            axis ='X'
        else :
            along_min ,along_max =min_y ,max_y 
            cross_min ,cross_max =min_x ,max_x 
            axis ='Y'

        bm =bmesh .new ()
        row_index =0 
        cross =cross_min 
        board_count =0 
        z0 =max_z 
        z1 =max_z +thickness 

        while cross <(cross_max -1e-9 ):
            c0 =cross 
            c1 =min (cross +board_width ,cross_max )
            row_offset =stagger if (row_index %2 ==1 )else 0.0 
            along =along_min -row_offset 

            while along <(along_max -1e-9 ):
                a0 =max (along ,along_min )
                a1 =min (along +board_length ,along_max )
                if (a1 -a0 )>1e-6 and (c1 -c0 )>1e-6 :
                    if axis =='X':
                        min_corner =Vector ((a0 ,c0 ,z0 ))
                        max_corner =Vector ((a1 ,c1 ,z1 ))
                    else :
                        min_corner =Vector ((c0 ,a0 ,z0 ))
                        max_corner =Vector ((c1 ,a1 ,z1 ))
                    _add_box_to_bmesh (bm ,min_corner ,max_corner )
                    board_count +=1 
                along +=board_length +gap 

            cross +=board_width +gap 
            row_index +=1 

        if board_count <=0 :
            bm .free ()
            self .report ({'WARNING'},_t ("Active mesh object with a usable footprint is required"))
            return {'CANCELLED'}

        mesh =bpy .data .meshes .new (_unique_name (set (bpy .data .meshes .keys ()),f"SMS_Floor_{active .name }"))
        bm .to_mesh (mesh )
        mesh .update ()
        bm .free ()

        obj =bpy .data .objects .new (_unique_name (set (bpy .data .objects .keys ()),f"SMS_Floor_{active .name }"),mesh )
        obj .matrix_world =active .matrix_world .copy ()
        col =_ensure_collection (context ,f"SMS_Floor_{active .name }")
        _link_object_to_collection (obj ,col )

        try :
            for o in context .selected_objects :
                o .select_set (False )
            obj .select_set (True )
            context .view_layer .objects .active =obj 
        except Exception :
            pass 

        self .report ({'INFO'},_t ("Generated floor pattern mesh"))
        return {'FINISHED'}


class VIEW3D_PT_msm_hub (Panel ):
    bl_label ="Smart Modifier Hub"
    bl_description ='Smart Modifier Hub panel in the Smart Modifier workspace.'
    bl_idname ="VIEW3D_PT_msm_hub"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}
    bl_order =40
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'smart_modifier_hub', context=context)

    def draw (self ,context ):
        layout =self .layout 
        layout .use_property_split =False 
        layout .use_property_decorate =False 

        props =getattr (getattr (context ,"scene",None ),"hub_props",None )
        if props is None :
            layout .label (text =_t ("Failed to load Smart Modifier sections"),icon ='ERROR')
            return 

        draw_help_header (layout ,context ,'Smart Modifier Hub','TOOL_SETTINGS','smart_modifier_hub')

        box =layout .box ()
        draw_help_header (box ,context ,"Hard Surface / Boolean",'MOD_BOOLEAN','hub_hard_surface')
        row =box .row (align =True )
        row .prop (props ,"boolean_operation",text ="")
        row .prop (props ,"boolean_solver",text ="")
        row =box .row (align =True )
        row .prop (props ,"hs_auto_bevel")
        row .prop (props ,"hs_weighted_normal")
        row =box .row (align =True )
        row .prop (props ,"hs_bevel_width")
        row .prop (props ,"hs_bevel_segments")
        box .prop (props ,"hs_organize_cutters")
        _draw_ui_operator (box ,context ,'sms.smart_boolean_stack',icon ='MOD_BOOLEAN')

        box =layout .box ()
        draw_help_header (box ,context ,"Topology / Repair",'MOD_REMESH','hub_topology_repair')
        row =box .row (align =True )
        row .prop (props ,"cleanup_merge_distance")
        row .prop (props ,"cleanup_fill_holes")
        row =box .row (align =True )
        row .prop (props ,"cleanup_join_tris")
        row .prop (props ,"cleanup_recalc_normals")
        _draw_ui_operator (box ,context ,'sms.smart_cleanup_repair',icon ='TOOL_SETTINGS')
        _draw_ui_operator (box ,context ,'sms.smart_fill_topology',icon ='MESH_GRID')
        row =box .row (align =True )
        _draw_ui_operator (row ,context ,'sms.detach_separate_clean',icon ='MESH_DATA')
        _draw_ui_operator (row ,context ,'sms.relax_selection',icon ='MOD_SMOOTH')
        row =box .row (align =True )
        _draw_ui_operator (row ,context ,'sms.circle_selection',icon ='MESH_CIRCLE')
        _draw_ui_operator (row ,context ,'sms.straighten_selection',icon ='IPO_LINEAR')

        box =layout .box ()
        draw_help_header (box ,context ,"Curves / Repetition",'CURVE_DATA','hub_curves_repetition')
        row =box .row (align =True )
        row .prop (props ,"pipe_radius")
        row .prop (props ,"pipe_resolution")
        box .prop (props ,"pipe_fill_caps")
        _draw_ui_operator (box ,context ,'sms.smart_pipe_from_selection',icon ='META_CAPSULE')
        row =box .row (align =True )
        row .prop (props ,"array_offset_x")
        row .prop (props ,"array_count")
        box .prop (props ,"array_merge_vertices")
        _draw_ui_operator (box ,context ,'sms.smart_array_along_curve',icon ='MOD_ARRAY')

        box =layout .box ()
        draw_help_header (box ,context ,"Conform / Stitch To Surface",'SNAP_FACE','hub_conform_surface')
        row =box .row (align =True )
        row .prop (props ,"conform_mode",text ="")
        row .prop (props ,"conform_offset")
        row =box .row (align =True )
        row .prop (props ,"conform_parent")
        row .prop (props ,"conform_organize")
        _draw_ui_operator (box ,context ,'sms.conform_to_surface',icon ='MOD_SHRINKWRAP')

        box =layout .box ()
        draw_help_header (box ,context ,"Scatter / Environment",'PARTICLES','hub_scatter_environment')
        row =box .row (align =True )
        row .prop (props ,"scatter_count")
        row .prop (props ,"scatter_seed")
        row =box .row (align =True )
        row .prop (props ,"scatter_scale_min")
        row .prop (props ,"scatter_scale_max")
        row =box .row (align =True )
        row .prop (props ,"scatter_random_z_deg")
        row .prop (props ,"scatter_align_normal")
        box .prop (props ,"scatter_surface_offset")
        _draw_ui_operator (box ,context ,'sms.scatter_instances_bake',icon ='OUTLINER_COLLECTION')

        box =layout .box ()
        draw_help_header (box ,context ,"Floor Generator",'MESH_GRID','hub_floor_generator')
        row =box .row (align =True )
        row .prop (props ,"floor_board_width")
        row .prop (props ,"floor_board_length")
        row =box .row (align =True )
        row .prop (props ,"floor_gap")
        row .prop (props ,"floor_thickness")
        row =box .row (align =True )
        row .prop (props ,"floor_stagger")
        row .prop (props ,"floor_axis",text ="")
        _draw_ui_operator (box ,context ,'sms.floor_generator',icon ='MESH_GRID')


class VIEW3D_PT_msm_hub_help (Panel ):
    bl_label ="Guide / Tips"
    bl_description ='Retired compact guide panel. Use the Help icon buttons for detailed localized help.'
    bl_idname ="VIEW3D_PT_msm_hub_help"
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_parent_id = ""
    bl_options ={'DEFAULT_CLOSED'}

    def draw (self ,context ):
        layout =self .layout
        draw_help_header (layout ,context ,'Smart Modifier Hub','TOOL_SETTINGS','smart_modifier_hub')




def _sms_root_only_panel_poll (cls ,context):
    # This panel body is rendered by Smart Modifier's unified root section UI.
    # Hide the separate Blender child-panel header to avoid duplicate section names.
    return False

def _sms_panel_draw_guard (draw_fn ,label ):
    def _wrapped (self ,context ):
        try :
            return draw_fn (self ,context )
        except Exception :
            try :
                layout =getattr (self ,'layout',None )
                if layout is not None :
                    box =layout .box ()
                    box .label (text =_t ('Smart Modifier UI could not be drawn safely.'),icon ='ERROR')
                    box .label (text =_t ('Close and reopen the N-panel, or reload the add-on if this message persists.'),icon='NONE')
            except Exception :
                pass
            return None
    return _wrapped

VIEW3D_PT_msm_hub .poll =classmethod (_sms_root_only_panel_poll)
VIEW3D_PT_msm_hub_help .poll =classmethod (_sms_root_only_panel_poll)

VIEW3D_PT_msm_hub .draw =_sms_panel_draw_guard (VIEW3D_PT_msm_hub .draw ,'VIEW3D_PT_msm_hub')
VIEW3D_PT_msm_hub_help .draw =_sms_panel_draw_guard (VIEW3D_PT_msm_hub_help .draw ,'VIEW3D_PT_msm_hub_help')

classes =(
SMSHubProperties ,
SMS_OT_apply_weighted_normal_modifier ,
SMS_OT_smart_boolean_stack ,
SMS_OT_smart_cleanup_repair ,
SMS_OT_smart_fill_topology ,
SMS_OT_smart_pipe_from_selection ,
SMS_OT_smart_array_along_curve ,
SMS_OT_scatter_instances_bake ,
SMS_OT_conform_to_surface ,
SMS_OT_detach_separate_clean ,
SMS_OT_relax_selection ,
SMS_OT_circle_selection ,
SMS_OT_straighten_selection ,
SMS_OT_floor_generator ,
)

def _unregister_retired_panel (class_name :str ):
    cls =getattr (bpy .types ,str (class_name or ''),None )
    if cls is None :
        return 
    try :
        pass  # session-stable: keep classes registered during live UI
    except Exception :
        pass 


def register ():
    _unregister_retired_panel ("VIEW3D_PT_msm_hub")
    _unregister_retired_panel ("VIEW3D_PT_msm_hub_help")
    try :
        bpy .app .translations .register (__name__ ,translation_catalog_dict )
    except ValueError :
        try :
            bpy .app .translations .unregister (__name__ )
        except Exception :
            pass 
        bpy .app .translations .register (__name__ ,translation_catalog_dict )

    for cls in classes :
        try :
            bpy .utils .register_class (cls )
        except ValueError :
            pass 

    try :
        bpy .types .Scene .hub_props =PointerProperty (type =SMSHubProperties ,description ='Stores settings used by the Smart Modifier Hub operators and their Add Modifier entry points.')
    except Exception :
        pass 


def unregister ():
    _unregister_retired_panel ("VIEW3D_PT_msm_hub")
    _unregister_retired_panel ("VIEW3D_PT_msm_hub_help")
    try :
        del bpy .types .Scene .hub_props 
    except Exception :
        pass 

    for cls in reversed (classes ):
        try :
            bpy .utils .unregister_class (cls )
        except Exception :
            pass 

    try :
        bpy .app .translations .unregister (__name__ )
    except Exception :
        pass 


        # --- Tooltip completion (hub panels) ---
VIEW3D_PT_msm_hub .bl_description ='Main compact modifier hub that groups hard-surface, repair, curve, scatter, and workflow entry points in one place.'
VIEW3D_PT_msm_hub_help .bl_description ='Beginner-friendly workflow notes for the Smart Modifier Hub.'
# --- Toolset complete i18n override START ---
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', 'Area + Angle'): '面積 + 角度',
 ('*', 'Attempt triangle-to-quad conversion after fill to keep the result cleaner for subdivision and retopo cleanup.'): 'フィル後に三角形から四角形への変換を試み、サブディビジョンやリトポ整理に向いた結果にします。',
 ('*', 'Beautify Fill'): 'フィルを整形',
 ('*', 'Corner Angle'): '角度',
 ('*', 'Exact'): '正確',
 ('*', 'Face Area'): '面積',
 ('*', 'Fast'): '高速',
 ('*', 'Fuse cutters into the target'): 'カッターをターゲットへ合成します。',
 ('*', 'Keep only overlapping volume'): '重なった体積だけを残します。',
 ('*', 'Lighter and faster for simpler cases'): '単純なケースで軽量・高速です。',
 ('*', 'Run a beautify pass after filling to reduce awkward internal diagonals when Blender can improve them safely.'): 'フィル後に安全に改善できる場合は '
                                                                                                                        'Beautify '
                                                                                                                        '処理を実行し、不自然な内部対角線を減らします。',
 ('*', 'Safer for complex hard-surface intersections'): '複雑なハードサーフェス交差に安全です。',
 ('*', 'Subtract cutters from the target'): 'カッターをターゲットから差し引きます。',
 ('*', 'Try Grid Fill early when a single boundary loop is selected so patch results stay quad-friendly when possible.'): '単一の境界ループが選択されている場合は早めに '
                                                                                                                          'Grid Fill '
                                                                                                                          'を試し、可能な範囲で四角面に向いたパッチ結果にします。',
 ('*', 'Weight'): 'ウェイト',
 ('*', 'Weight by both face area and corner angle.'): '面積と角度の両方で重み付けします。',
 ('*', 'Weight by corner angle.'): '角度で重み付けします。',
 ('*', 'Weight by face area.'): '面積で重み付けします。',
 ('*', 'Weighted Normal'): '重み付き法線',
 ('*', 'Weighted Normal mode used by the modifier when Blender exposes the option.'): 'Blender が項目を公開している場合に、モディファイアで使用する Weighted Normal '
                                                                                      'モードです。'})
translation_catalog_dict.setdefault('ja_JP', {}).update({('*', 'Failed to load Smart Modifier sections'): 'Smart Modifier セクションの読み込みに失敗しました'})
# --- Toolset complete i18n override END ---


# Final Japanese overrides for entries that should not remain English in Japanese UI.
translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Exact'): '正確',
    ('*', 'Fast'): '高速',
    ('*', 'Weighted Normal'): '重み付き法線',
    ('*', 'Beautify Fill'): 'フィルを整形',
    ('*', 'Crease Preset'): 'クリースプリセット',
    ('*', 'Mesh Align'): 'メッシュ整列',
    ('*', 'Direct Delete'): '直接削除',
    ('*', 'Vertex Slide'): '頂点スライド',
    ('*', 'Bridge Edge Loops'): 'ブリッジエッジループ',
    ('*', 'Grid Fill'): 'グリッドフィル',
    ('*', 'EdgeNet Fill'): 'エッジネットフィル',
    ('*', 'Edge / Face Add'): '辺 / 面を追加',
})


translation_catalog_dict.setdefault('ja_JP', {}).update({
    ('*', 'Smart Modifier UI could not be drawn safely.'): 'Smart Modifier UIを安全に描画できませんでした。',
    ('*', 'Close and reopen the N-panel, or reload the add-on if this message persists.'): 'この表示が続く場合は、Nパネルを閉じて開き直すか、アドオンを再読み込みしてください。',
})
