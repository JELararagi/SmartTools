# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

import json
import os
import re
import sys
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

from .translation import pgettext as _sms_pgettext

PACKAGE_ID = 'smart_modifier_suite'
ADDON_NAME = 'Smart_Modifier_Suite'
TOOL_LABEL_EN = 'Smart Modifier'
TOOL_LABEL_JA = 'スマートモディファイア'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'
_RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES = (
    'SMART_MODIFIER_PT_always_on',
    'VIEW3D_PT_ms_always_on_toggles_panel',
    'VIEW3D_PT_ms_always_on_toggles_group_panel',
    'VIEW3D_PT_ms_live_runtime_panel',
)

_PREVIEW_COLLECTION = None
_PENDING_PREVIEW_REMOVALS = []
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


_PANEL_HELP_TOPIC_MAP = {
    'VIEW3D_PT_smart_modifier_root_panel': 'always_on',
    'VIEW3D_PT_ms_settings_panel': 'settings',
    'VIEW3D_PT_modifier_stack_panel': 'modifier_stack',
    'VIEW3D_PT_ms_modswitcher_main': 'modifier_switcher',
    'VIEW3D_PT_ms_tool_catalog_panel': 'bundled_catalog',
    'VIEW3D_PT_msm_hub': 'smart_modifier_hub',
    'VIEW3D_PT_msm_hub_help': 'smart_modifier_hub',
    'SMSP_PT_precision_layout': 'precision_layout_path',
    'SMSP_PT_precision_guide': 'precision_layout_path',
    'VIEW3D_PT_sms_advanced': 'advanced_surface_modeling',
    'VIEW3D_PT_sms_advanced_help': 'advanced_surface_modeling',
    'MODSWITCH_PT_MainPanel': 'modifier_switcher',
    'MODSWITCH_PT_main': 'modifier_switcher',
    'MODSWITCH_PT_ObjectListPanel': 'modifier_switcher_objects',
    'MODSWITCH_PT_objects': 'modifier_switcher_objects',
    'MODSWITCH_PT_AdvancedPanel': 'switcher_details',
    'MODSWITCH_PT_advanced': 'switcher_details',
}


def _resolve_help_topic(topic):
    raw = str(topic or '').strip()
    if not raw:
        return 'settings'
    direct = _PANEL_HELP_TOPIC_MAP.get(raw)
    if direct:
        return direct
    lowered = raw.lower()
    for key, value in _PANEL_HELP_TOPIC_MAP.items():
        if lowered == str(key).lower():
            return value
    if 'catalog_group:' in lowered:
        return raw
    if 'advanced' in lowered or 'surface' in lowered:
        return 'advanced_surface_modeling'
    if 'precision' in lowered or 'layout' in lowered or 'path' in lowered:
        return 'precision_layout_path'
    if 'hub' in lowered:
        return 'smart_modifier_hub'
    if 'catalog' in lowered:
        return 'bundled_catalog'
    if 'switcher' in lowered or 'modswitch' in lowered:
        if 'object' in lowered:
            return 'modifier_switcher_objects'
        if 'advanced' in lowered or 'detail' in lowered:
            return 'switcher_details'
        return 'modifier_switcher'
    if 'stack' in lowered:
        return 'modifier_stack'
    if 'always' in lowered or 'root' in lowered:
        return 'always_on'
    if 'setting' in lowered or 'preference' in lowered:
        return 'settings'
    return raw


def _help_topic_for_panel(cls):
    for attr in ('__name__', 'bl_idname', 'bl_label'):
        try:
            topic = _resolve_help_topic(getattr(cls, attr, '') or '')
            if topic and topic != str(getattr(cls, attr, '') or '').strip():
                return topic
        except Exception:
            pass
    try:
        return _resolve_help_topic(getattr(cls, '__name__', '') or getattr(cls, 'bl_idname', '') or 'settings')
    except Exception:
        return 'settings'


def package_root():
    return Path(__file__).resolve().parent


def _blender_version_string():
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return str(int(version[0])) + '.' + str(int(version[1]))
    except Exception:
        pass
    return '5.1'


def _platform_suite_config_root(create=True):
    try:
        value = bpy.utils.user_resource('CONFIG', path='Smart_Modifier_Suite', create=create)
    except Exception:
        value = ''
    if value:
        root = Path(value)
    else:
        version = _blender_version_string()
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Modifier_Suite'
        else:
            root = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_Modifier_Suite'
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def _platform_user_data_root(create=True):
    root = _platform_suite_config_root(create=create) / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_root(create=True):
    # Generated files live below Blender CONFIG/Smart_Modifier_Suite. Delegate to
    # the shared storage module so every subsystem uses one immutable-package-safe
    # location, including import/resolve failure fallbacks.
    try:
        from .storage import user_data_dir
        root = user_data_dir(create=create)
        if root is not None:
            return Path(root)
    except Exception:
        pass
    return _platform_user_data_root(create=create)


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        from .storage import suite_config_path
        return suite_config_path(create=True)
    except Exception:
        return _platform_suite_config_root(create=True) / 'Smart_Modifier_Suite.json'


def legacy_package_settings_path():
    return package_root() / _STORAGE_DIRNAME / 'settings' / 'n_panel_settings.json'


def _legacy_common_settings_paths():
    paths = []
    try:
        old_storage = storage_root(False) / 'settings' / 'n_panel_settings.json'
        paths.append(old_storage)
    except Exception:
        pass
    try:
        paths.append(legacy_package_settings_path())
    except Exception:
        pass
    return [p for p in paths if p]


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        icons_dir = package_root() / 'icons'
        mapped = {
            'header': 'text_header_font',
            'help': 'help_question',
            'clock': 'clock_always_on',
        }
        for name, filename in mapped.items():
            path = icons_dir / (filename + '.png')
            if path.exists():
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    try:
        from .icons import icon_value as _sms_icon_value
        value = _sms_icon_value(name, None)
        if value:
            return value
    except Exception:
        pass
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_preview_collection_later(pcoll):
    if pcoll is None:
        return
    try:
        if pcoll not in _PENDING_PREVIEW_REMOVALS:
            _PENDING_PREVIEW_REMOVALS.append(pcoll)
    except Exception:
        return

    def _cleanup_preview_collections():
        pending = list(_PENDING_PREVIEW_REMOVALS)
        _PENDING_PREVIEW_REMOVALS.clear()
        for item in pending:
            try:
                import bpy.utils.previews
                bpy.utils.previews.remove(item)
            except Exception:
                pass
        return None

    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_cleanup_preview_collections, first_interval=0.5)
            return
    except Exception:
        pass
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def _remove_previews():
    global _PREVIEW_COLLECTION
    # Do not free preview collections during a running UI session.  Sidebar panel
    # button blocks can outlive an add-on refresh and still hold preview icon IDs.
    # Keeping the collection alive avoids stale icon-pointer crashes in
    # blender::ui::ui_handler_panel.
    return


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            try:
                from .icons import label as _sms_icon_label
                _sms_icon_label(layout, text=line, icon_name=icon, fallback_icon=icon)
            except Exception:
                layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_MODIFIER_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group. The help content is loaded only when this button is clicked.'
    bl_options = set()

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = _resolve_help_topic(getattr(self, 'topic', '') or 'settings')
        try:
            from . import help as _help
            _help.draw_help(layout, context, topic, popup_width_px=680)
        except Exception as exc:
            box = layout.box()
            box.label(text=text('Help content could not be loaded.', 'ヘルプ内容を読み込めませんでした。', context), icon='ERROR')
            _draw_wrapped(box, context, str(exc))


class SMART_MODIFIER_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled. The N-panel State Save option controls whether the change is written immediately or deferred to scene close / preferences save.'
    bl_options = {'UNDO'}

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report(
                    {'WARNING'},
                    _sms_pgettext(
                        'Always-on setting update failed: {detail}',
                        context=context,
                    ).format(detail=str(exc)),
                )
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report(
                    {'WARNING'},
                    _sms_pgettext(
                        'Always-on setting update failed: {detail}',
                        context=context,
                    ).format(detail=str(exc)),
                )
        try:
            save_persistent_settings(context)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_MODIFIER_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = ''
    bl_description = ''
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        try:
            from . import preferences as _preferences_module
            _preferences_module.save_settings(context=context, force=True)
        except Exception:
            pass
        try:
            from . import persistent_state as _persistent_state
            _persistent_state.request_save(context, immediate=True, force=True)
        except Exception:
            pass
        try:
            from . import feature_toggle as _feature_toggle_module
            save_state = getattr(_feature_toggle_module, 'save_state', None)
            if callable(save_state):
                save_state(context=context, force=True)
        except Exception:
            pass
        save_persistent_settings(context, force=True)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        return {'FINISHED'}



def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _unregister_legacy_always_on_panels():
    """Hide retired Always-on panels without unregistering classes.

    Blender 5.1 may retain UI panel button blocks during Smart Tools Manager
    refreshes and mode/workspace changes.  Unregistering a Panel class while
    such blocks exist can crash in blender::ui::ui_handler_panel.  Therefore old
    duplicate panels are disabled by poll override only.
    """
    for name in _RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES:
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            cls = None
        if not isinstance(cls, type):
            continue
        try:
            cls.poll = classmethod(lambda _cls, context: False)
        except Exception:
            pass




def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        pass  # session-stable: keep classes registered during live UI
        return True
    except Exception:
        return False


def _flatten_npanel_parent_before_register(cls):
    """Keep all SmartTools N-panel sections horizontally aligned.

    Blender indents Panel classes that use ``bl_parent_id``.  In a deep or
    lazily loaded SmartTools UI this compounds every time a child/grandchild
    section is exposed.  Flatten only sidebar (``bl_region_type == 'UI'``)
    panels before registration; non-sidebar panels keep their native parents.
    """
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            if str(getattr(cls, 'bl_region_type', '') or '') == 'UI':
                if str(getattr(cls, 'bl_parent_id', '') or ''):
                    cls.bl_parent_id = ''
    except Exception:
        pass
    return cls


def _register_class_wrapper(cls):
    _flatten_npanel_parent_before_register(cls)
    class_name = str(getattr(cls, '__name__', '') or '')
    bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    if class_name in _RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES or bl_idname in _RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES:
        try:
            if issubclass(cls, bpy.types.Panel):
                return None
        except Exception:
            return None
    _materialize_annotations(cls)
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type) and existing is not cls:
            # Do not unregister a live class during Smart Tools Manager refresh or
            # N-panel redraw.  If Blender already has this class, keep it until the
            # next full Blender restart instead of invalidating active UI blocks.
            if _same_package_class(existing) or _old_generated_name(getattr(existing, '__name__', '')):
                return None
    except Exception:
        pass
    try:
        return _ORIGINAL_REGISTER_CLASS(cls)
    except ValueError:
        return None


def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    try:
        _ORIGINAL_REGISTER_CLASS = bpy.utils.register_class
        bpy.utils.register_class = _register_class_wrapper
    except Exception:
        _ORIGINAL_REGISTER_CLASS = None


def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    if _ORIGINAL_REGISTER_CLASS is not None:
        try:
            bpy.utils.register_class = _ORIGINAL_REGISTER_CLASS
        except Exception:
            pass
    _ORIGINAL_REGISTER_CLASS = None


def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
        class_name = str(getattr(cls, '__name__', '') or '')
        if bl_idname in _RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES or class_name in _RETIRED_ALWAYS_ON_PANEL_CLASS_NAMES:
            continue
        yield cls


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    # Runtime mutation of already-registered Panel callbacks is unsafe while
    # Blender is handling sidebar UI events.  The package's panel classes now own
    # their headers directly, so this compatibility hook intentionally performs
    # no class mutation.
    return None


def _unpatch_panel_headers():
    # See _patch_panel_headers(): avoid mutating panel callbacks during teardown.
    _PATCHED_PANELS.clear()
    _PATCHED_POLLS.clear()
    return None


def _iter_relevant_addon_preferences():
    return iter(())


def _patch_addon_preferences():
    return None


def _unpatch_addon_preferences():
    _PATCHED_PREFERENCES.clear()


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    # Never capture another SmartTools package merely because its identifier
    # begins with ``smart_``/``sps_``/etc.  The old broad prefix list caused
    # Smart Modifier load restoration to assign Smart Node's master switch,
    # whose callback then replaced Node's canonical scene settings with the new
    # scene defaults.  Restrict roots to Modifier-owned namespaces.
    prefixes = ('sms_', 'ms_', 'modswitch_', 'hub_', 'smsp_', 'smsa_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
        owner_module = str(getattr(type(owner), '__module__', '') or '').lower()
        if prefix and owner_module.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None and _prop_relevant(key, child, obj):
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key) and _prop_relevant(key, value, obj):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS
    primary = settings_path()
    try:
        if primary.exists():
            raw = json.loads(primary.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                if isinstance(raw.get('common_state'), dict):
                    _LOADED_SETTINGS = raw.get('common_state') or {}
                    return _LOADED_SETTINGS
                if not any(key in raw for key in ('settings', 'panel_state', 'feature_toggles', 'common_state')):
                    _LOADED_SETTINGS = raw
                    return raw
    except Exception:
        pass
    for path in _legacy_common_settings_paths():
        try:
            if path.exists():
                raw = json.loads(path.read_text(encoding='utf-8'))
                if isinstance(raw, dict):
                    _LOADED_SETTINGS = raw
                    try:
                        save_persistent_settings(bpy.context, force=True)
                    except Exception:
                        pass
                    return raw
        except Exception:
            pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    try:
        from .save_policy import should_write_config
        if not should_write_config(context, force=force):
            return
    except Exception:
        if not force:
            return
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        path = settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {}
        try:
            if path.exists():
                payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        payload.setdefault('version', 1)
        payload.setdefault('addon_id', PACKAGE_ID)
        payload['common_state'] = data
        from . import storage
        storage.atomic_write_json(path, payload, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        pass


def _autosave_timer():
    """Terminate a recurring common-settings timer from older builds."""
    return None


@persistent
def _load_post_handler(dummy=None):
    # ``persistent_state`` is the sole restore authority. The old common-state
    # mirror must not overwrite its freshly restored values with stale data.
    return None


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register():
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
    except Exception:
        pass
    _unregister_legacy_always_on_panels()
    for cls in (SMART_MODIFIER_OT_open_help, SMART_MODIFIER_OT_set_always_on, SMART_MODIFIER_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    load_settings_file()
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    # Property callbacks and lifecycle handlers already persist every setting.
    # Never scan and serialize the complete state on an idle interval.
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _patch_panel_headers()


def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    _unpatch_panel_headers()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    _unregister_legacy_always_on_panels()
    for attr_name in (_ALWAYS_ON_PROP,):
        try:
            if hasattr(bpy.types.WindowManager, attr_name):
                delattr(bpy.types.WindowManager, attr_name)
        except Exception:
            pass
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    end_register()
