# -*- coding: utf-8 -*-
# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

"""Transform preservation guard for file save/load and runtime restoration.

Smart Modifier uses helper objects, preview meshes, and load-time UI state
restoration.  None of those systems should ever change the transform of real
scene objects when a .blend file is saved and opened again.  This module keeps a
short-lived transform snapshot across load/register-time recovery so incidental
stack synchronization cannot reset user object transforms.
"""
from __future__ import annotations

import json
import time
from typing import Any

import bpy
from bpy.app.handlers import persistent
from mathutils import Matrix

_IDPROP_KEY = '_smsm_transform_guard_basis_v1'
_DN_ACTIVE_KEY = '_SMSM_TRANSFORM_GUARD_ACTIVE_V1'
_DN_SESSION_KEY = '_SMSM_TRANSFORM_GUARD_SESSION_V1'
_DN_UNTIL_KEY = '_SMSM_TRANSFORM_GUARD_UNTIL_V1'
_DN_TIMER_KEY = '_SMSM_TRANSFORM_GUARD_TIMER_ARMED_V1'
_DN_REASON_KEY = '_SMSM_TRANSFORM_GUARD_REASON_V1'
_REGISTERED = False

_HELPER_MARKERS = (
    'ms_end_preview_main',
    'ep_main_target',
    'sl_main_target',
)
_HELPER_SUFFIXES = (
    '_EndPreview',
    '_MS_EndPreview',
)


def _dn() -> dict:
    try:
        return bpy.app.driver_namespace
    except Exception:
        return {}


def is_active() -> bool:
    try:
        return bool(_dn().get(_DN_ACTIVE_KEY, False))
    except Exception:
        return False


def _is_linked_or_readonly(obj: Any) -> bool:
    try:
        if getattr(obj, 'library', None) is not None:
            return True
    except Exception:
        pass
    try:
        if getattr(obj, 'override_library', None) is not None and getattr(obj.override_library, 'reference', None) is not None:
            # Local overrides are technically editable, but restoring their
            # transforms during file-load handlers can fight Blender's override
            # resync. Leave them to Blender.
            return True
    except Exception:
        pass
    return False


def is_runtime_helper_object(obj: Any) -> bool:
    if obj is None:
        return True
    try:
        name = str(getattr(obj, 'name', '') or '')
        if name.endswith(_HELPER_SUFFIXES):
            return True
    except Exception:
        pass
    try:
        if hasattr(obj, 'get'):
            for key in _HELPER_MARKERS:
                try:
                    if obj.get(key, None) is not None:
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def _matrix_to_list(matrix: Matrix | Any) -> list[list[float]]:
    return [[float(matrix[row][col]) for col in range(4)] for row in range(4)]


def _matrix_from_list(value: Any) -> Matrix | None:
    try:
        rows = list(value)
        if len(rows) != 4:
            return None
        parsed = []
        for row in rows:
            r = list(row)
            if len(r) != 4:
                return None
            parsed.append([float(v) for v in r])
        return Matrix(parsed)
    except Exception:
        return None


def _matrix_close(a: Matrix, b: Matrix, eps: float = 1.0e-7) -> bool:
    try:
        for r in range(4):
            for c in range(4):
                if abs(float(a[r][c]) - float(b[r][c])) > eps:
                    return False
        return True
    except Exception:
        return False


def _iter_preserved_objects(scene: Any | None = None):
    try:
        source = list(getattr(scene, 'objects', []) or []) if scene is not None else list(bpy.data.objects)
    except Exception:
        source = []
    seen = set()
    for obj in source:
        try:
            if obj is None:
                continue
            ptr = int(obj.as_pointer())
            if ptr in seen:
                continue
            seen.add(ptr)
        except Exception:
            pass
        if is_runtime_helper_object(obj) or _is_linked_or_readonly(obj):
            continue
        yield obj


def _object_record(obj: Any) -> dict[str, Any] | None:
    try:
        return {
            'basis': _matrix_to_list(obj.matrix_basis.copy()),
            'world': _matrix_to_list(obj.matrix_world.copy()),
            'rotation_mode': str(getattr(obj, 'rotation_mode', '') or ''),
        }
    except Exception:
        return None


def _read_object_record(obj: Any) -> dict[str, Any] | None:
    try:
        raw = obj.get(_IDPROP_KEY, '') if hasattr(obj, 'get') else ''
    except Exception:
        raw = ''
    if not raw:
        return None
    try:
        data = json.loads(str(raw))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _write_object_record(obj: Any) -> None:
    rec = _object_record(obj)
    if not rec:
        return
    try:
        obj[_IDPROP_KEY] = json.dumps(rec, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def _snapshot_current(scene: Any | None = None) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for obj in _iter_preserved_objects(scene):
        try:
            name = str(getattr(obj, 'name', '') or '')
        except Exception:
            name = ''
        if not name:
            continue
        rec = _object_record(obj)
        if rec:
            out[name] = rec
    return out


def _snapshot_saved_props(scene: Any | None = None) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for obj in _iter_preserved_objects(scene):
        try:
            name = str(getattr(obj, 'name', '') or '')
        except Exception:
            name = ''
        if not name:
            continue
        rec = _read_object_record(obj)
        if rec:
            out[name] = rec
    return out


def _apply_record(obj: Any, rec: dict[str, Any]) -> bool:
    if obj is None or not isinstance(rec, dict):
        return False
    if is_runtime_helper_object(obj) or _is_linked_or_readonly(obj):
        return False
    basis = _matrix_from_list(rec.get('basis'))
    if basis is None:
        # Fallback for files saved by an intermediate build.
        basis = _matrix_from_list(rec.get('world'))
    if basis is None:
        return False
    try:
        current = obj.matrix_basis.copy()
        if _matrix_close(current, basis):
            return False
    except Exception:
        pass
    try:
        obj.matrix_basis = basis
        try:
            obj.update_tag()
        except Exception:
            pass
        return True
    except Exception:
        # Fallback: preserve world matrix if matrix_basis assignment is not valid
        # for this object type in this Blender state.
        world = _matrix_from_list(rec.get('world'))
        if world is None:
            return False
        try:
            obj.matrix_world = world
            try:
                obj.update_tag()
            except Exception:
                pass
            return True
        except Exception:
            return False


def _restore_snapshot(snapshot: dict[str, dict[str, Any]] | None) -> int:
    if not isinstance(snapshot, dict) or not snapshot:
        return 0
    changed = 0
    for name, rec in list(snapshot.items()):
        try:
            obj = bpy.data.objects.get(str(name))
        except Exception:
            obj = None
        if obj is None:
            continue
        if _apply_record(obj, rec):
            changed += 1
    try:
        if changed:
            ctx = getattr(bpy, 'context', None)
            vl = getattr(ctx, 'view_layer', None) if ctx is not None else None
            if vl is not None:
                vl.update()
    except Exception:
        pass
    return changed


def enter_transient_guard(context: Any | None = None, *, reason: str = 'runtime', duration: float = 1.20, use_saved_props: bool = False) -> None:
    """Compatibility no-op for Blender base-operation safety.

    Older builds restored object transforms repeatedly for a short interval after
    add-on registration or file-load recovery.  That timer could make normal
    View3D transforms feel locked while Blender was otherwise usable.  Smart
    Modifier must not mutate object transforms unless the user runs a specific
    tool, so this hook now only clears stale guard state left by older builds and
    never registers a restore timer.
    """
    del context, reason, duration, use_saved_props
    try:
        dn = _dn()
        # Stop stale sessions from older versions.  The timer function itself is
        # unregistered in register()/unregister() when it is known to Blender.
        dn.pop(_DN_ACTIVE_KEY, None)
        dn.pop(_DN_SESSION_KEY, None)
        dn.pop(_DN_UNTIL_KEY, None)
        dn.pop(_DN_REASON_KEY, None)
        dn.pop(_DN_TIMER_KEY, None)
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_restore_timer):
            timers.unregister(_restore_timer)
    except Exception:
        pass
    return None

def _restore_timer():
    try:
        dn = _dn()
        snapshot = dn.get(_DN_SESSION_KEY)
        if isinstance(snapshot, dict) and snapshot:
            _restore_snapshot(snapshot)
        until = float(dn.get(_DN_UNTIL_KEY, 0.0) or 0.0)
        if time.time() < until:
            return 0.15
        dn.pop(_DN_ACTIVE_KEY, None)
        dn.pop(_DN_SESSION_KEY, None)
        dn.pop(_DN_UNTIL_KEY, None)
        dn.pop(_DN_REASON_KEY, None)
        dn.pop(_DN_TIMER_KEY, None)
        return None
    except Exception:
        try:
            dn = _dn()
            dn.pop(_DN_ACTIVE_KEY, None)
            dn.pop(_DN_SESSION_KEY, None)
            dn.pop(_DN_UNTIL_KEY, None)
            dn.pop(_DN_REASON_KEY, None)
            dn.pop(_DN_TIMER_KEY, None)
        except Exception:
            pass
        return None


@persistent
def _save_pre_handler(_dummy=None):
    try:
        ctx = getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        for obj in _iter_preserved_objects(scene):
            _write_object_record(obj)
    except Exception:
        pass


@persistent
def _load_post_handler(_dummy=None):
    # Do not start transform restoration on file load.  Basic Blender View3D
    # transforms must remain fully native immediately after enabling/loading.
    try:
        enter_transient_guard(getattr(bpy, 'context', None), reason='load_post_disabled', duration=0.0, use_saved_props=False)
    except Exception:
        pass

def _append_once(seq, fn) -> None:
    try:
        if fn not in seq:
            seq.append(fn)
    except Exception:
        pass


def _remove_all(seq, fn) -> None:
    try:
        while fn in seq:
            seq.remove(fn)
    except Exception:
        pass


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    try:
        handlers = bpy.app.handlers
        _append_once(handlers.save_pre, _save_pre_handler)
        # Intentionally do not append load_post.  Load-time transform restoration
        # was the source of apparent transform locking in Blender 5.1.x.
        _remove_all(handlers.load_post, _load_post_handler)
        try:
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_restore_timer):
                timers.unregister(_restore_timer)
        except Exception:
            pass
        enter_transient_guard(None, reason='register_cleanup', duration=0.0, use_saved_props=False)
        _REGISTERED = True
    except Exception:
        pass

def unregister() -> None:
    global _REGISTERED
    try:
        handlers = bpy.app.handlers
        _remove_all(handlers.save_pre, _save_pre_handler)
        _remove_all(handlers.load_post, _load_post_handler)
    except Exception:
        pass
    try:
        dn = _dn()
        dn.pop(_DN_ACTIVE_KEY, None)
        dn.pop(_DN_SESSION_KEY, None)
        dn.pop(_DN_UNTIL_KEY, None)
        dn.pop(_DN_REASON_KEY, None)
        dn.pop(_DN_TIMER_KEY, None)
    except Exception:
        pass
    _REGISTERED = False
