# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

import bpy
import copy
import uuid
import re
import json
import sys
import time
import types
import bmesh
from mathutils import Matrix
from .translation import pgettext_iface as _sms_pgettext_iface, choose_text as _sms_choose_text


# ------------------------------------------------------------
# Add-on module name helper (supports modular package layout)
# ------------------------------------------------------------
def _ms_addon_id():
    """Return the full add-on module key for legacy internal identifiers."""

    try:
        pkg = __package__
        if pkg:
            # Keep the full dotted module name (required for Extensions)
            return pkg
    except Exception:
        pass

    try:
        # Fallback (rare): use the top-level module of __name__
        name = __name__ or ""
        return name.split('.', 1)[0] if name else ""
    except Exception:
        return __name__

def _ms_get_addon_prefs(context=None):
    """Return Smart Modifier N-panel runtime settings."""
    try:
        from .preferences import get_preferences
        prefs = get_preferences(context)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    return None


# ------------------------------------------------------------
# Viewport redraw / depsgraph dirty tracking (performance-safe)
# ------------------------------------------------------------
_MS_REDRAW_MIN_INTERVAL = 1.0 / 30.0


def _ms_tag_redraw_all_view3d_now():
    """Request redraw on all 3D Viewport areas immediately."""
    try:
        wm = bpy.context.window_manager
        for win in wm.windows:
            scr = getattr(win, "screen", None)
            if not scr:
                continue
            for area in getattr(scr, "areas", []):
                if getattr(area, "type", "") == 'VIEW_3D':
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _ms_deferred_view3d_redraw():
    try:
        dn = bpy.app.driver_namespace
        dn["_MS_REDRAW_PENDING_V1"] = False
        dn["_MS_REDRAW_LAST_V1"] = time.time()
    except Exception:
        pass
    _ms_tag_redraw_all_view3d_now()
    return None


def _ms_tag_redraw_all_view3d():
    """Request redraw on all 3D Viewport areas, coalescing repeated calls."""
    try:
        dn = bpy.app.driver_namespace
        now = time.time()
        last = float(dn.get("_MS_REDRAW_LAST_V1", 0.0) or 0.0)
        if (now - last) < _MS_REDRAW_MIN_INTERVAL:
            if not bool(dn.get("_MS_REDRAW_PENDING_V1", False)):
                dn["_MS_REDRAW_PENDING_V1"] = True
                try:
                    bpy.app.timers.register(_ms_deferred_view3d_redraw, first_interval=_MS_REDRAW_MIN_INTERVAL, persistent=False)
                except Exception:
                    dn["_MS_REDRAW_PENDING_V1"] = False
                    _ms_tag_redraw_all_view3d_now()
            return
        dn["_MS_REDRAW_LAST_V1"] = now
    except Exception:
        pass
    _ms_tag_redraw_all_view3d_now()


def _ms_tag_redraw_active_view3d(context=None):
    """Prefer the active window's 3D Viewports to avoid global redraw spam."""
    try:
        ctx = context or bpy.context
        win = getattr(ctx, "window", None)
        scr = getattr(win, "screen", None) if win else None
        if scr:
            redrawn = False
            for area in getattr(scr, "areas", []):
                if getattr(area, "type", "") != 'VIEW_3D':
                    continue
                try:
                    area.tag_redraw()
                    redrawn = True
                except Exception:
                    pass
            if redrawn:
                return
    except Exception:
        pass
    _ms_tag_redraw_all_view3d()


def _ms_object_relates_to_main(candidate, main_obj=None, active_obj=None):
    if candidate is None:
        return False
    try:
        if active_obj is not None and candidate is active_obj:
            return True
        if active_obj is not None:
            active_data = getattr(active_obj, "data", None)
            if active_data is not None and candidate is active_data:
                return True
    except Exception:
        pass
    try:
        if main_obj is not None and candidate is main_obj:
            return True
        if main_obj is not None:
            main_data = getattr(main_obj, "data", None)
            if main_data is not None and candidate is main_data:
                return True
    except Exception:
        pass
    try:
        if isinstance(candidate, bpy.types.Object):
            target_name = getattr(main_obj, "name", "") if main_obj is not None else ""
            if target_name:
                if candidate.get("ms_end_preview_main") == target_name:
                    return True
                if candidate.get("ep_main_target") == target_name:
                    return True
                if candidate.get("sl_main_target") == target_name:
                    return True
                if candidate.get("smsm_slice_target") == target_name:
                    return True
                if candidate.get("smsm_uvw_target") == target_name:
                    return True
                if candidate.get("smsm_noise_target") == target_name:
                    return True
            if active_obj is not None and candidate.get("sl_main_target") == getattr(active_obj, "name", ""):
                return True
            if active_obj is not None and candidate.get("smsm_slice_target") == getattr(active_obj, "name", ""):
                return True
            if active_obj is not None and candidate.get("smsm_uvw_target") == getattr(active_obj, "name", ""):
                return True
            if active_obj is not None and candidate.get("smsm_noise_target") == getattr(active_obj, "name", ""):
                return True
    except Exception:
        pass
    return False


def _ms_has_relevant_depsgraph_updates(depsgraph, main_obj=None, active_obj=None):
    if depsgraph is None:
        return False
    try:
        updates = getattr(depsgraph, "updates", None)
        if not updates:
            return False
        for update in updates:
            try:
                candidate = update.id
            except Exception:
                candidate = None
            if _ms_object_relates_to_main(candidate, main_obj=main_obj, active_obj=active_obj):
                return True
        return False
    except Exception:
        return False


def _ms_dg_mark_dirty(dn, depsgraph, main_obj):
    """Increment per-object dirty counter when depsgraph reports updates for the object/mesh."""
    if not dn or not depsgraph or not main_obj:
        return False
    try:
        updates = getattr(depsgraph, "updates", None)
        if not updates:
            return False
        oid = main_obj
        mid = getattr(main_obj, "data", None)
        for u in updates:
            try:
                idd = u.id
            except Exception:
                idd = None
            if idd is oid or (mid is not None and idd is mid):
                root = dn.get("_MS_OBJ_DIRTY_REV_V1")
                if not isinstance(root, dict):
                    root = {}
                root[main_obj.name] = int(root.get(main_obj.name, 0) or 0) + 1
                dn["_MS_OBJ_DIRTY_REV_V1"] = root
                return True
        return False
    except Exception:
        return False

def _ms_get_dirty_rev(dn, obj_name: str) -> int:
    try:
        root = dn.get("_MS_OBJ_DIRTY_REV_V1")
        if isinstance(root, dict):
            return int(root.get(obj_name, 0) or 0)
    except Exception:
        pass
    return 0


# ------------------------------------------------------------
# Realtime properties timer (ensures modifier property edits update EndPreview)
# ------------------------------------------------------------
def _ms_realtime_properties_timer():
    """Terminate the former sidebar-visible polling timer.

    Modifier and mesh changes are processed by depsgraph events, while live
    EndPreview editing uses ``_ms_endpreview_live_sync_timer`` only for the
    duration of that explicit feature.
    """
    return None


def ms__safe_mode_set(context, obj, mode):
    """Safely set object mode without breaking selection.
    Returns True on success, False otherwise.
    Uses context override and ensures a valid active object in the current view layer.
    """
    if obj is None:
        return False

    # Hard guard: never change mode unless a user-initiated Smart Modifier transition is active.
    try:
        dn = _ms__dn()
        if not bool(dn.get("_MS_ALLOW_MODESET_V1", False)):
            return False
    except Exception:
        return False
    try:
        vl = getattr(context, "view_layer", None)
    except Exception:
        vl = None
    if not vl:
        return False
    try:
        # Object must be in the current view layer to be set active
        if obj.name not in vl.objects:
            return False
    except Exception:
        return False

    # Ensure there is an active object for poll(), but do not change selection.
    try:
        if vl.objects.active is None or vl.objects.active.name not in vl.objects:
            vl.objects.active = obj
        elif vl.objects.active != obj and getattr(vl.objects.active, "select_get", lambda: True)() is False:
            # Active is not selectable/selected; prefer obj.
            vl.objects.active = obj
    except Exception:
        try:
            vl.objects.active = obj
        except Exception:
            return False

    # Temporarily make sure the target is not locked/hidden from selection.
    prev_hide_select = getattr(obj, "hide_select", False)
    prev_hide_viewport = getattr(obj, "hide_viewport", False)
    try:
        if hasattr(obj, "hide_viewport") and obj.hide_viewport:
            obj.hide_viewport = False
        if hasattr(obj, "hide_select") and obj.hide_select:
            obj.hide_select = False

        # Use override so poll/mode_set always has a valid active object context.
        try:
            with context.temp_override(object=obj, active_object=obj):
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode=mode)
                    return True
        except Exception:
            # Fallback: call without override if override fails in this context.
            try:
                if bpy.ops.object.mode_set.poll():
                    bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode=mode)
                    return True
            except Exception:
                pass
    finally:
        try:
            if hasattr(obj, "hide_select"):
                obj.hide_select = prev_hide_select
            if hasattr(obj, "hide_viewport"):
                obj.hide_viewport = prev_hide_viewport
        except Exception:
            pass
    return False




MS_Clipboard = {"is_empty": True, "plugin_id": "", "mod_type": "", "name": "", "settings": {}, "payload": {}, "source_obj_name": "", "source_mod_name": "", "source_instance_id": ""}
_MS_SYNC_LOCK = False
_MS_ACTION_LOCK = False

def _ms_json_prop_dict(obj, prop_name):
    try:
        data = json.loads(obj.get(prop_name, "{}"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}

def _ms_set_json_prop_dict(obj, prop_name, data):
    try:
        text = json.dumps(data if isinstance(data, dict) else {}, ensure_ascii=False, sort_keys=True)
        try:
            current = obj.get(prop_name)
        except Exception:
            current = None
        if isinstance(current, str) and current == text:
            return False
        obj[prop_name] = text
        return True
    except Exception:
        pass
    return False

def _ms_get_modifier_actual_flag(obj, mod_name, attr, default=True):
    try:
        mod = obj.modifiers.get(mod_name) if obj and mod_name and hasattr(obj, "modifiers") else None
        if mod is not None and hasattr(mod, attr):
            return bool(getattr(mod, attr))
    except Exception:
        pass
    return bool(default)

_MS_MOD_DISPLAY_CHANNELS = {
    'vp': ('show_viewport', 'ms_mod_viewport_bak', True, 'viewport'),
    'render': ('show_render', 'ms_mod_render_bak', True, 'render'),
    'edit': ('show_in_editmode', 'ms_mod_editmode_bak', False, 'editmode'),
    'cage': ('show_on_cage', 'ms_mod_cage_bak', False, 'cage'),
}
_MS_MOD_DISPLAY_CHANNEL_ALIASES = {
    'vp': 'vp', 'viewport': 'vp', 'show_viewport': 'vp',
    'render': 'render', 'show_render': 'render',
    'edit': 'edit', 'editmode': 'edit', 'edit_mode': 'edit', 'show_in_editmode': 'edit',
    'cage': 'cage', 'on_cage': 'cage', 'show_on_cage': 'cage',
}


def _ms_normalize_modifier_display_channel(channel):
    key = str(channel or '').strip().lower()
    return _MS_MOD_DISPLAY_CHANNEL_ALIASES.get(key, key if key in _MS_MOD_DISPLAY_CHANNELS else '')


def _ms_modifier_display_channel_spec(channel):
    key = _ms_normalize_modifier_display_channel(channel)
    return key, _MS_MOD_DISPLAY_CHANNELS.get(key)


def _ms_modifier_supports_display_channel(mod, channel):
    _key, spec = _ms_modifier_display_channel_spec(channel)
    if mod is None or not spec:
        return False
    try:
        return hasattr(mod, spec[0])
    except Exception:
        return False


def ms_get_auto_disable_restore_mode(context=None):
    """Return the configured restoration policy for rows leaving Auto Disable suppression."""
    try:
        prefs = _ms_get_addon_prefs(context)
        mode = str(getattr(prefs, 'auto_disable_restore_mode', 'PRESERVE') or 'PRESERVE').strip().upper()
    except Exception:
        mode = 'PRESERVE'
    return mode if mode in {'PRESERVE', 'FORCE_ENABLE'} else 'PRESERVE'


def ms_get_auto_disable_force_enable_channels(context=None):
    """Return the independently selected display channels forced ON after restoration."""
    try:
        prefs = _ms_get_addon_prefs(context)
    except Exception:
        prefs = None
    values = {
        'cage': True,
        'edit': True,
        'vp': True,
        'render': True,
    }
    prop_names = {
        'cage': 'auto_disable_force_enable_cage',
        'edit': 'auto_disable_force_enable_editmode',
        'vp': 'auto_disable_force_enable_viewport',
        'render': 'auto_disable_force_enable_render',
    }
    for channel, prop_name in prop_names.items():
        try:
            values[channel] = bool(getattr(prefs, prop_name, True)) if prefs is not None else True
        except Exception:
            values[channel] = True
    return values


def _ms_ensure_modifier_display_backups(obj, active_idx=None, auto_disable=False):
    """Store all four manual modifier-header states before Auto Disable mutates them."""
    if obj is None or not hasattr(obj, 'modifiers'):
        return
    backups = {}
    changed = {}
    for channel, (_attr, backup_key, _default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
        backups[channel] = _ms_json_prop_dict(obj, backup_key)
        changed[channel] = False
    try:
        original = _ms_auto_disable_original_display_map(obj)
        if not isinstance(original, dict): original = {}
    except Exception: original = {}
    try:
        forced = _ms_auto_disable_forced_display_map(obj)
        if not isinstance(forced, dict): forced = {}
    except Exception: forced = {}
    try:
        suppressed = _ms_auto_disable_suppressed_display_map(obj)
        if not isinstance(suppressed, dict): suppressed = {}
    except Exception: suppressed = {}

    def _snapshot_info(mod_name, channel, actual_default):
        for root in (original, forced, suppressed):
            try:
                entry = root.get(mod_name) if isinstance(root, dict) else None
                if isinstance(entry, dict) and channel in entry:
                    return True, bool(entry.get(channel, actual_default))
            except Exception:
                continue
        return False, bool(actual_default)

    try: names = {m.name for m in obj.modifiers}
    except Exception: names = set()
    for channel, data in backups.items():
        for key in list(data.keys()):
            if key not in names:
                data.pop(key, None); changed[channel] = True
    try: ai = int(active_idx) if active_idx is not None else None
    except Exception: ai = None
    try: modifiers = list(obj.modifiers)
    except Exception: modifiers = []
    for index, mod in enumerate(modifiers):
        try: suppressed_now = bool(auto_disable) and ai is not None and int(index) > int(ai)
        except Exception: suppressed_now = False
        for channel, (attr, _backup_key, default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
            if not _ms_modifier_supports_display_channel(mod, channel):
                continue
            try: actual_value = bool(getattr(mod, attr, default))
            except Exception: actual_value = bool(default)
            if actual_value:
                wanted = True
            else:
                found_snapshot, snapshot_value = _snapshot_info(mod.name, channel, actual_value)
                if found_snapshot:
                    wanted = bool(snapshot_value)
                elif (channel in {'vp', 'render'}
                      and _ms_json_prop_dict(obj, 'ms_mod_suite_muted_display').get(mod.name, False)):
                    found_backup, backup_value = _ms_find_manual_display_backup(obj, mod.name, channel, actual_value)
                    wanted = bool(backup_value) if found_backup else bool(actual_value)
                elif suppressed_now:
                    # A newly suppressed row still exposes the user's last setting.
                    wanted = actual_value
                else:
                    wanted = bool(actual_value)
            if backups[channel].get(mod.name, None) != bool(wanted):
                backups[channel][mod.name] = bool(wanted); changed[channel] = True
    for channel, (_attr, backup_key, _default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
        if changed[channel]:
            _ms_set_json_prop_dict(obj, backup_key, backups[channel])


def _ms_capture_modifier_display_backups_from_actual(obj):
    """Refresh all four manual display backups while Auto Disable is already OFF."""
    if obj is None or not hasattr(obj, 'modifiers'):
        return
    values = {channel: {} for channel in _MS_MOD_DISPLAY_CHANNELS}
    try: modifiers = list(obj.modifiers)
    except Exception: modifiers = []
    for mod in modifiers:
        for channel, (attr, _backup_key, default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
            if not _ms_modifier_supports_display_channel(mod, channel):
                continue
            if (channel in {'vp', 'render'}
                    and _ms_json_prop_dict(obj, 'ms_mod_suite_muted_display').get(mod.name, False)
                    and not bool(getattr(mod, attr, default))):
                found, value = _ms_find_manual_display_backup(obj, mod.name, channel, default)
                if found:
                    values[channel][mod.name] = bool(value)
                    continue
            try: values[channel][mod.name] = bool(getattr(mod, attr, default))
            except Exception: values[channel][mod.name] = bool(default)
    for channel, (_attr, backup_key, _default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
        _ms_set_json_prop_dict(obj, backup_key, values[channel])


def _ms_auto_disable_forced_display_map(obj):
    data = _ms_json_prop_dict(obj, '_MS_AUTO_DISABLE_FORCED_DISPLAY_V2')
    return data if isinstance(data, dict) else {}


def _ms_set_auto_disable_forced_display_map(obj, data):
    _ms_set_json_prop_dict(obj, '_MS_AUTO_DISABLE_FORCED_DISPLAY_V2', data if isinstance(data, dict) else {})


def _ms_auto_disable_suppressed_display_map(obj):
    data = _ms_json_prop_dict(obj, '_MS_AUTO_DISABLE_SUPPRESSED_DISPLAY_V1')
    return data if isinstance(data, dict) else {}


def _ms_set_auto_disable_suppressed_display_map(obj, data):
    _ms_set_json_prop_dict(obj, '_MS_AUTO_DISABLE_SUPPRESSED_DISPLAY_V1', data if isinstance(data, dict) else {})


def _ms_auto_disable_original_display_map(obj):
    data = _ms_json_prop_dict(obj, '_MS_AUTO_DISABLE_ORIGINAL_DISPLAY_V3')
    return data if isinstance(data, dict) else {}


def _ms_set_auto_disable_original_display_map(obj, data):
    _ms_set_json_prop_dict(obj, '_MS_AUTO_DISABLE_ORIGINAL_DISPLAY_V3', data if isinstance(data, dict) else {})


def _ms_clear_auto_disable_map_entry(getter, setter, obj, mod_name, channel=None):
    try:
        data = getter(obj)
        if not isinstance(data, dict) or mod_name not in data: return
        normalized = _ms_normalize_modifier_display_channel(channel) if channel is not None else None
        if normalized is None:
            data.pop(mod_name, None)
        else:
            entry = data.get(mod_name)
            if isinstance(entry, dict):
                entry.pop(normalized, None)
                if entry: data[mod_name] = entry
                else: data.pop(mod_name, None)
            else: data.pop(mod_name, None)
        setter(obj, data)
    except Exception:
        pass


def _ms_clear_auto_disable_original_display_entry(obj, mod_name, channel=None):
    _ms_clear_auto_disable_map_entry(_ms_auto_disable_original_display_map, _ms_set_auto_disable_original_display_map, obj, mod_name, channel)


def _ms_clear_auto_disable_forced_display_entry(obj, mod_name, channel=None):
    _ms_clear_auto_disable_map_entry(_ms_auto_disable_forced_display_map, _ms_set_auto_disable_forced_display_map, obj, mod_name, channel)


def _ms_clear_auto_disable_suppressed_display_entry(obj, mod_name, channel=None):
    _ms_clear_auto_disable_map_entry(_ms_auto_disable_suppressed_display_map, _ms_set_auto_disable_suppressed_display_map, obj, mod_name, channel)


def _ms_set_manual_display_backup(obj, mod_name, *, viewport=None, render=None, editmode=None, cage=None):
    values = {'vp': viewport, 'render': render, 'edit': editmode, 'cage': cage}
    for channel, value in values.items():
        if value is None: continue
        try:
            _attr, backup_key, _default, _kw = _MS_MOD_DISPLAY_CHANNELS[channel]
            data = _ms_json_prop_dict(obj, backup_key)
            data[mod_name] = bool(value)
            _ms_set_json_prop_dict(obj, backup_key, data)
        except Exception:
            pass


def _ms_find_manual_display_backup(obj, mod_name, channel, default=None):
    _normalized, spec = _ms_modifier_display_channel_spec(channel)
    if not spec: return False, bool(default)
    _attr, backup_key, channel_default, _kw = spec
    fallback = channel_default if default is None else bool(default)
    try:
        data = _ms_json_prop_dict(obj, backup_key)
        if isinstance(data, dict) and mod_name in data:
            return True, bool(data.get(mod_name, fallback))
    except Exception: pass
    return False, bool(fallback)


def _ms_get_manual_display_backup(obj, mod_name, channel, default=None):
    return bool(_ms_find_manual_display_backup(obj, mod_name, channel, default)[1])


def _ms_get_mod_display_state(obj, mod_name, channel, default=None):
    normalized, spec = _ms_modifier_display_channel_spec(channel)
    if not spec: return bool(default)
    attr, backup_key, channel_default, _kw = spec
    fallback = channel_default if default is None else bool(default)
    try:
        mod = obj.modifiers.get(mod_name) if obj and hasattr(obj, 'modifiers') else None
        if mod is not None and hasattr(mod, attr) and bool(getattr(mod, attr)):
            return True
    except Exception: pass
    try:
        for root in (_ms_auto_disable_original_display_map(obj), _ms_auto_disable_forced_display_map(obj), _ms_auto_disable_suppressed_display_map(obj)):
            entry = root.get(mod_name) if isinstance(root, dict) else None
            if isinstance(entry, dict) and normalized in entry:
                return bool(entry.get(normalized, fallback))
        data = _ms_json_prop_dict(obj, backup_key)
        if mod_name in data: return bool(data.get(mod_name, fallback))
        return _ms_get_modifier_actual_flag(obj, mod_name, attr, fallback)
    except Exception: return bool(fallback)


def _ms_set_mod_display_state(obj, mod_name, channel, state):
    normalized, spec = _ms_modifier_display_channel_spec(channel)
    if not spec: return False
    attr, backup_key, _default, _kw = spec
    changed = False; desired = bool(state)
    data = _ms_json_prop_dict(obj, backup_key)
    if data.get(mod_name, None) != desired:
        data[mod_name] = desired
        changed = bool(_ms_set_json_prop_dict(obj, backup_key, data)) or changed
    _ms_clear_auto_disable_original_display_entry(obj, mod_name, normalized)
    _ms_clear_auto_disable_forced_display_entry(obj, mod_name, normalized)
    _ms_clear_auto_disable_suppressed_display_entry(obj, mod_name, normalized)
    try:
        mod = obj.modifiers.get(mod_name) if obj and hasattr(obj, 'modifiers') else None
        if mod is not None and hasattr(mod, attr) and bool(getattr(mod, attr)) != desired:
            setattr(mod, attr, desired); changed = True
    except Exception: pass
    return changed


def get_mod_viewport_state(obj, mod_name): return _ms_get_mod_display_state(obj, mod_name, 'vp', True)
def set_mod_viewport_state(obj, mod_name, state): return _ms_set_mod_display_state(obj, mod_name, 'vp', state)
def get_mod_render_state(obj, mod_name): return _ms_get_mod_display_state(obj, mod_name, 'render', True)
def set_mod_render_state(obj, mod_name, state): return _ms_set_mod_display_state(obj, mod_name, 'render', state)
def get_mod_editmode_state(obj, mod_name): return _ms_get_mod_display_state(obj, mod_name, 'edit', False)
def set_mod_editmode_state(obj, mod_name, state): return _ms_set_mod_display_state(obj, mod_name, 'edit', state)
def get_mod_cage_state(obj, mod_name): return _ms_get_mod_display_state(obj, mod_name, 'cage', False)
def set_mod_cage_state(obj, mod_name, state): return _ms_set_mod_display_state(obj, mod_name, 'cage', state)


def ms_mod_display_row_state(obj, mod, channel):
    """The state a stack row icon shows, which is what pressing it must flip.

    A live row shows its real flag. A row held OFF by Auto Disable or by its enable
    toggle shows its saved state instead: the flag there says nothing about what
    the row returns to, and pressing it changes only what it returns to.
    """
    _normalized, spec = _ms_modifier_display_channel_spec(channel)
    if not spec or mod is None: return False
    attr, _backup_key, default, _kw = spec
    actual = bool(getattr(mod, attr, default))
    if actual: return True
    try:
        if _ms_modifier_auto_disable_suppressed(obj, mod.name) or not bool(get_mod_enabled_state(obj, mod.name)):
            return bool(_ms_get_mod_display_state(obj, mod.name, channel, default))
    except Exception: pass
    return False


_MS_TOOL_DEFAULT_MODIFIER_NAMES = {
    'Reset XForm': ('Reset XForm', 'Xフォームをリセット'),
    'Unwrap UVW': ('Unwrap UVW', 'UVアンラップ'),
    'SmartLattice': ('SmartLattice', 'スマートラティス'),
    'SMS_Array': ('Array', '配列'),
    'SMS_Bevel': ('Bevel', 'ベベル'),
    'SMS_Conform': ('Conform', 'コンフォーム'),
    'SMS_Curve': ('Curve', 'カーブ'),
    'SMS_WeightedNormal': ('Weighted Normal', '法線の重み付け'),
}


def ms_modifier_row_display_name(name, context=None):
    """Show a name a bundled tool always gives in English in the UI language.

    The real modifier name stays as it is, because tools find their modifiers by
    it. Any other name belongs to the user and is shown exactly as written.
    """
    text = str(name or '')
    match = re.match(r'^(.*?)(\.\d{3})?$', text)
    pair = _MS_TOOL_DEFAULT_MODIFIER_NAMES.get(match.group(1)) if match else None
    if not pair: return text
    return _sms_choose_text(pair[0], pair[1], context=context) + (match.group(2) or '')


def _ms_modifier_auto_disable_suppressed(obj, mod_name, context=None):
    try:
        if obj is None or not mod_name or not ms_object_has_modifier_collection(obj): return False
        main_obj = get_main_object(obj) or obj
        if not main_obj or not bool(ms_auto_disable_modifiers_enabled(main_obj)): return False
        try: stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=False) or main_obj
        except Exception: stack_obj = main_obj
        if stack_obj is not obj:
            try:
                if not hasattr(stack_obj, 'modifiers') or stack_obj.modifiers.get(mod_name) is None: stack_obj = obj
            except Exception: stack_obj = obj
        if not ms_object_has_modifier_collection(stack_obj): return False
        try:
            effective_active_id = ms_get_effective_active_id(main_obj, ms_get_ui_active_id(main_obj))
            active_idx = stack_obj.modifiers.find(effective_active_id) if effective_active_id != 'BASE' else -1
            mod_idx = stack_obj.modifiers.find(mod_name)
        except Exception:
            active_idx = -1; mod_idx = -1
        if not bool(mod_idx >= 0 and mod_idx > active_idx): return False
        for root in (_ms_auto_disable_original_display_map(stack_obj), _ms_auto_disable_forced_display_map(stack_obj), _ms_auto_disable_suppressed_display_map(stack_obj)):
            try:
                entry = root.get(mod_name) if isinstance(root, dict) else None
                if isinstance(entry, dict) and any(key in entry for key in _MS_MOD_DISPLAY_CHANNELS): return True
            except Exception: continue
        return False
    except Exception: return False


def _ms_update_auto_disable_display_snapshots(obj, mod_name, *, viewport=None, render=None, editmode=None, cage=None, context=None):
    if obj is None or not mod_name: return
    try: suppressed = _ms_modifier_auto_disable_suppressed(obj, mod_name, context=context)
    except Exception: suppressed = False
    channels = [(c, bool(v)) for c,v in (('vp',viewport),('render',render),('edit',editmode),('cage',cage)) if v is not None]
    if not channels: return
    def _update(root, setter):
        try:
            data = root(obj)
            if not isinstance(data, dict): data = {}
            if mod_name not in data and not suppressed: return
            entry = data.get(mod_name)
            if not isinstance(entry, dict): entry = {}
            changed = False
            for channel, value in channels:
                if entry.get(channel, None) != value:
                    entry[channel] = value; changed = True
            if entry: data[mod_name] = entry
            elif mod_name in data: data.pop(mod_name, None); changed = True
            if changed: setter(obj, data)
        except Exception: pass
    _update(_ms_auto_disable_original_display_map, _ms_set_auto_disable_original_display_map)
    _update(_ms_auto_disable_forced_display_map, _ms_set_auto_disable_forced_display_map)
    _update(_ms_auto_disable_suppressed_display_map, _ms_set_auto_disable_suppressed_display_map)


def _ms_assign_modifier_display_values(mod, values, *, suppressed=False):
    if mod is None or not isinstance(values, dict): return False
    order = ('cage','edit','vp','render') if suppressed else ('vp','edit','cage','render')
    changed = False
    for channel in order:
        if channel not in values or values.get(channel) is None: continue
        _normalized, spec = _ms_modifier_display_channel_spec(channel)
        if not spec: continue
        attr = spec[0]
        if not hasattr(mod, attr): continue
        desired = False if suppressed else bool(values.get(channel))
        try:
            if bool(getattr(mod, attr)) != desired:
                setattr(mod, attr, desired); changed = True
        except Exception: pass
    return changed


def _ms_set_modifier_display_state_for_instance_sync(obj, mod, *, viewport=None, render=None, editmode=None, cage=None, context=None):
    if obj is None or mod is None: return False
    try: mod_name = str(getattr(mod, 'name', '') or '')
    except Exception: mod_name = ''
    if not mod_name: return False
    _ms_set_manual_display_backup(obj, mod_name, viewport=viewport, render=render, editmode=editmode, cage=cage)
    _ms_update_auto_disable_display_snapshots(obj, mod_name, viewport=viewport, render=render, editmode=editmode, cage=cage, context=context)
    try: suppressed = _ms_modifier_auto_disable_suppressed(obj, mod_name, context=context)
    except Exception: suppressed = False
    return _ms_assign_modifier_display_values(mod, {'vp':viewport,'render':render,'edit':editmode,'cage':cage}, suppressed=bool(suppressed))


def _ms_get_modifier_manual_display_for_sync(obj, mod, *, context=None):
    if mod is None: return True, True, False, False
    try: vp = bool(get_mod_viewport_state(obj, mod.name)) if obj is not None else bool(getattr(mod, 'show_viewport', True))
    except Exception: vp = True
    try: rd = bool(get_mod_render_state(obj, mod.name)) if obj is not None else bool(getattr(mod, 'show_render', True))
    except Exception: rd = True
    try: edit = bool(get_mod_editmode_state(obj, mod.name)) if obj is not None else bool(getattr(mod, 'show_in_editmode', False))
    except Exception: edit = False
    try: cage = bool(get_mod_cage_state(obj, mod.name)) if obj is not None else bool(getattr(mod, 'show_on_cage', False))
    except Exception: cage = False
    return vp, rd, edit, cage


def get_mod_enabled_state(obj, mod_name):
    try: return _ms_json_prop_dict(obj, "ms_mod_enabled_bak").get(mod_name, True)
    except Exception: return True

def set_mod_enabled_state(obj, mod_name, state):
    desired = bool(state)
    data = _ms_json_prop_dict(obj, "ms_mod_enabled_bak")
    if data.get(mod_name, None) == desired:
        return False
    data[mod_name] = desired
    return bool(_ms_set_json_prop_dict(obj, "ms_mod_enabled_bak", data))

# -----------------------------------------------------------------------------
# Smart Modifier stack row expand/collapse state (4.32.49)
#
# Blender's native ``show_expanded`` is deliberately excluded from generic stack
# drawing by ``_MS_MODIFIER_HEADER_PROP_IDS`` in ui.py, and it is already owned by
# ``object.ms_expand_selected_modifier_only``.  Custom stack rows therefore carry
# their own expand state, stored with the same bounded JSON ID-property pattern
# used by ``get_mod_enabled_state`` / ``set_mod_enabled_state`` above.  Object
# ID-properties persist with the .blend, which keeps the state per-object and
# per-modifier instead of pushing per-object data into the global panel-state file.
#
# The dict is bounded twice: only names of live modifiers are ever kept, and the
# entry count is hard-capped, so a pathological stack cannot grow it without limit.
# Collapsed is the default and is stored as absence, so an untouched stack keeps a
# completely empty (in fact unset) property.
# -----------------------------------------------------------------------------

_MS_ROW_EXPAND_PROP = "ms_mod_row_expanded"
_MS_ROW_EXPAND_MAX_ENTRIES = 512


def _ms_row_expand_live_names(obj):
    names = []
    try:
        mods = obj.modifiers
    except Exception:
        return names
    if not mods:
        return names
    for m in mods:
        try:
            name = str(m.name)
        except Exception:
            continue
        if name:
            names.append(name)
    return names


def _ms_row_expand_normalize(obj, data):
    live = set(_ms_row_expand_live_names(obj))
    kept = {str(k): True for k, v in (data or {}).items() if str(k) in live and bool(v)}
    if len(kept) > _MS_ROW_EXPAND_MAX_ENTRIES:
        for key in sorted(kept.keys())[_MS_ROW_EXPAND_MAX_ENTRIES:]:
            kept.pop(key, None)
    return kept


def ms_prune_row_expanded_state(obj):
    """Drop row-expand entries whose modifier no longer exists. True when changed."""
    if obj is None:
        return False
    data = _ms_json_prop_dict(obj, _MS_ROW_EXPAND_PROP)
    if not data:
        return False
    pruned = _ms_row_expand_normalize(obj, data)
    if pruned == data:
        return False
    return bool(_ms_set_json_prop_dict(obj, _MS_ROW_EXPAND_PROP, pruned))


def get_mod_row_expanded(obj, mod_name):
    """Return the custom stack-row expand state. Default is collapsed."""
    if obj is None or not mod_name:
        return False
    try:
        return bool(_ms_json_prop_dict(obj, _MS_ROW_EXPAND_PROP).get(str(mod_name), False))
    except Exception:
        return False


def set_mod_row_expanded(obj, mod_name, state):
    """Set one row's expand state. True when the stored dict actually changed."""
    if obj is None or not mod_name:
        return False
    key = str(mod_name)
    data = _ms_row_expand_normalize(obj, _ms_json_prop_dict(obj, _MS_ROW_EXPAND_PROP))
    if bool(state):
        if key not in data and len(data) >= _MS_ROW_EXPAND_MAX_ENTRIES:
            return False
        data[key] = True
    else:
        data.pop(key, None)
    return bool(_ms_set_json_prop_dict(obj, _MS_ROW_EXPAND_PROP, data))


def ms_set_all_rows_expanded(obj, state):
    """Bulk expand/collapse every live stack row. True when the stored dict changed."""
    if obj is None:
        return False
    if bool(state):
        data = {str(n): True for n in _ms_row_expand_live_names(obj)[:_MS_ROW_EXPAND_MAX_ENTRIES]}
    else:
        data = {}
    return bool(_ms_set_json_prop_dict(obj, _MS_ROW_EXPAND_PROP, data))


def ms_any_row_expanded(obj):
    """True when at least one live stack row is currently expanded."""
    if obj is None:
        return False
    try:
        return bool(_ms_row_expand_normalize(obj, _ms_json_prop_dict(obj, _MS_ROW_EXPAND_PROP)))
    except Exception:
        return False


_MS_NAME_SUFFIX_RE = re.compile(r"^(.*?)(?:\.(\d{3}))?$")

def ms_modifier_type_display_name(mod_type: str) -> str:
    try:
        label = bpy.types.Modifier.bl_rna.properties["type"].enum_items[mod_type].name
        return _sms_pgettext_iface(label)
    except Exception: return mod_type or ""

def ms_obj_get_disp_name(obj, mod_name) -> str:
    if not obj or not mod_name: return ""
    items = getattr(obj, "ms_instance_map_items", None)
    if items:
        for it in items:
            if it.mod_name == mod_name and it.disp_name: return it.disp_name
    return ""

def ms_obj_set_disp_name(obj, mod_name, disp_name):
    if not obj or not mod_name or not disp_name:
        return False
    changed = False
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        found = next((it for it in items if it.mod_name == mod_name), None)
        if not found:
            found = items.add()
            found.mod_name = mod_name
            changed = True
        if str(getattr(found, "disp_name", "") or "") != str(disp_name):
            found.disp_name = str(disp_name)
            changed = True
    return changed

def ms_get_logical_modifier_name(obj, mod) -> str:
    if not obj or not mod: return ""
    dn = ms_obj_get_disp_name(obj, mod.name)
    return str(dn) if dn else str(mod.name)

def ms_collect_logical_used_default_names(obj, base_name: str) -> set:
    used = set()
    if not obj or not base_name or not obj.modifiers: return used
    base = str(base_name)
    for m in obj.modifiers:
        ln = ms_get_logical_modifier_name(obj, m)
        if not ln: continue
        if ln == base: used.add(base)
        elif ln.startswith(base + "."):
            suf = ln[len(base)+1:]
            if len(suf) == 3 and suf.isdigit(): used.add(ln)
    return used

def ms_next_logical_name_from_base(obj, base_name: str) -> str:
    base = str(base_name).strip() if base_name else "Modifier"
    used = ms_collect_logical_used_default_names(obj, base)
    if base not in used: return base
    for i in range(1, 10000):
        cand = f"{base}.{i:03d}"
        if cand not in used: return cand
    return f"{base}.{uuid.uuid4().hex[:3]}"

def ms_next_logical_default_name(obj, mod_type: str) -> str:
    base = (ms_modifier_type_display_name(mod_type) or str(mod_type) or "Modifier").strip()
    return ms_next_logical_name_from_base(obj, base)

def ms_next_logical_default_name_across_objects(objects, base_c: str) -> str:
    objs = [o for o in (objects or []) if o]
    base = str(base_c).strip() if base_c else "Modifier"
    used = set()
    for o in objs: used |= ms_collect_logical_used_default_names(o, base)
    if base not in used: return base
    for i in range(1, 10000):
        cand = f"{base}.{i:03d}"
        if cand not in used: return cand
    return f"{base}.{uuid.uuid4().hex[:3]}"

def ms_safe_rename_modifier(obj, mod, new_name: str) -> bool:
    if not obj or not mod or not new_name: return False
    new_name = str(new_name)
    if mod.name == new_name: return True
    if obj.modifiers.get(new_name) is not None and obj.modifiers.get(new_name) != mod: return False
    old_name = mod.name
    mod.name = new_name
    ms_obj_rename_instance_key(obj, old_name, mod.name)
    if obj.get("ui_active_item", "") == old_name: obj["ui_active_item"] = mod.name
    return True

def ms_normalize_default_modifier_names(obj, mod_type: str):
    if not obj or not mod_type or not obj.modifiers: return
    base = (ms_modifier_type_display_name(mod_type) or str(mod_type) or "").strip()
    if not base: return
    mods = [m for m in obj.modifiers if getattr(m, "type", "") == mod_type]
    if len(mods) != 1: return
    m = mods[0]
    ln = ms_get_logical_modifier_name(obj, m)
    mm = _MS_NAME_SUFFIX_RE.match(ln or "")
    if not mm or not mm.group(2) or mm.group(1).strip() != base: return
    if obj.modifiers.get(base) is not None and obj.modifiers.get(base) != m: return
    ms_safe_rename_modifier(obj, m, base)
    ms_obj_set_disp_name(obj, m.name, base)

def _ms__dn():
    return bpy.app.driver_namespace

# ------------------------------------------
# Fast visibility setters (avoid redundant hide_set / property writes)
# ------------------------------------------

def _ms_obj_hide_get(obj):
    try:
        return bool(obj.hide_get())
    except Exception:
        try:
            return bool(getattr(obj, "hide_viewport", False))
        except Exception:
            return False

def _ms_is_internal_visibility_helper_object(obj) -> bool:
    """True only for Smart Modifier-owned helper/proxy objects.

    Normal user objects must not have Outliner restriction states changed by
    stack synchronization.  Helper visibility is controlled with hide_set() so
    Blender's global "Disable in Viewport" state is not toggled unexpectedly.
    """
    if obj is None:
        return False
    try:
        if hasattr(obj, "get"):
            for key in (
                "ep_main_target", "sl_main_target", "ms_end_preview_main",
                "smsm_slice_target", "smsm_slice_helper",
                "smsm_internal_helper", "ms_shape_mesh_proxy_source",
                "smsm_slice_proxy_owner",
                "smsm_uvw_target", "smsm_uvw_helper",
                "smsm_uvw_proxy_owner",
                "smsm_noise_target", "smsm_noise_helper",
                "smsm_noise_proxy_owner",
            ):
                try:
                    if key in obj or bool(obj.get(key, False)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    try:
        name = str(getattr(obj, "name", "") or "")
        if "_SMS_CurveMesh" in name:
            return True
    except Exception:
        pass
    return False


def _ms_set_obj_hidden(obj, hide: bool, hide_select: bool = None):
    """Set view visibility without mutating normal objects' restriction flags.

    Smart Modifier may hide helper/proxy objects as stack levels change.  It must
    not flip user edit targets' hide_select or hide_viewport flags.
    """
    if not obj:
        return
    is_helper = _ms_is_internal_visibility_helper_object(obj)
    # Never set hide_viewport=True here.  That is the Outliner monitor state and
    # can make the real edit target unusable.  When showing an object that this
    # add-on owns, clear stale disabled state only for helpers/proxies.
    try:
        if is_helper and not hide and hasattr(obj, "hide_viewport") and bool(obj.hide_viewport):
            obj.hide_viewport = False
    except Exception:
        pass
    try:
        cur_h = _ms_obj_hide_get(obj)
        if cur_h != bool(hide):
            try:
                obj.hide_set(bool(hide))
            except Exception:
                pass
    except Exception:
        pass
    if hide_select is not None and is_helper:
        try:
            if hasattr(obj, "hide_select"):
                cur = bool(obj.hide_select)
                if cur != bool(hide_select):
                    obj.hide_select = bool(hide_select)
        except Exception:
            pass

def _ms_set_obj_select(obj, sel: bool):
    if not obj:
        return
    try:
        if hasattr(obj, "select_get") and obj.select_get() != bool(sel):
            obj.select_set(bool(sel))
    except Exception:
        pass

# ------------------------------------------
# End Result Preview (Show End Result OFF)
# ------------------------------------------

_MS_PREVIEW_COLL_NAME = "EndPreview_Collection"
_MS_STACK_COLLECTION_NAME = "Smart Modifier_Collection"
_MS_ENDPREVIEW_COLLECTION_NAME = "EndPreview_Collection"
_MS_MODSYS_ROOT_COLLECTION = "Modifier_System_Collection"
_MS_EDITPOLY_COLLECTION = "EditPoly_Collection"
_MS_PREVIEW_OBJ_KEY = "_MS_END_PREVIEW_OBJ_V1"
_MS_PREVIEW_STAMP_KEY = "_MS_END_PREVIEW_STAMP_V1"
_MS_PREVIEW_SIG_KEY = "_MS_END_PREVIEW_SIG_V1"

# EndPreview lifecycle control (ephemeral):
# - Preview object should exist only during Smart Modifier-driven Edit operations.
# - It is removed when leaving edit mode or when the main object is deselected.
_MS_ENDPREVIEW_ALLOWED_MAP_KEY = "_MS_ENDPREVIEW_ALLOWED_MAP_V1"
_MS_ENDPREVIEW_CLEANUP_SET_KEY = "_MS_ENDPREVIEW_CLEANUP_SET_V1"
_MS_ENDPREVIEW_CLEANUP_ARMED_KEY = "_MS_ENDPREVIEW_CLEANUP_ARMED_V1"
_MS_STACK_PANEL_DRAW_T_KEY = "_MS_STACK_PANEL_DRAW_T_V1"
_MS_STACK_PANEL_DRAW_MAIN_KEY = "_MS_STACK_PANEL_DRAW_MAIN_V1"
_MS_ENDPREVIEW_LIVE_TIMER_ARMED_KEY = "_MS_ENDPREVIEW_LIVE_TIMER_ARMED_V1"
_MS_ENDPREVIEW_LIVE_LAST_STATE_KEY = "_MS_ENDPREVIEW_LIVE_LAST_STATE_V1"


def _ms_defer_data_cleanup_delay():
    """Return a positive delay while mode/UI state is unsafe for data removal."""
    try:
        dn = _ms__dn()
        grace = float(dn.get("_MS_MODE_GRACE_UNTIL_V1", 0.0) or 0.0)
        now = time.time()
        if grace and now < grace:
            return max(0.05, min(0.25, grace - now))
    except Exception:
        pass
    try:
        ctx = bpy.context
        wm = getattr(ctx, 'window_manager', None)
        if bool(getattr(wm, 'is_interface_locked', False)):
            return 0.20
        mode = str(getattr(ctx, 'mode', 'OBJECT') or 'OBJECT')
        if mode == 'SCULPT' or mode.startswith('PAINT'):
            return 0.20
    except Exception:
        pass
    return 0.0

def ms_ensure_show_end_result_default_off(obj) -> None:
    """Keep newly encountered objects defaulting to Show End Result OFF.

    Older builds registered the RNA default as ON.  During a hot update in the
    same Blender session that RNA definition may still exist, so objects that
    have never explicitly stored this setting can appear ON.  This helper
    normalizes only unset objects and does not overwrite user-saved choices.
    """
    try:
        if obj is None or getattr(obj, "type", "") != 'MESH':
            return
        if not hasattr(obj, "ms_show_end_result"):
            return
        unset = False
        try:
            unset = not bool(obj.is_property_set("ms_show_end_result"))
        except Exception:
            unset = False
        if unset and bool(getattr(obj, "ms_show_end_result", False)):
            setattr(obj, "ms_show_end_result", False)
    except Exception:
        pass


def ms_normalize_show_end_result_defaults() -> int:
    """Normalize legacy unset values once at registration/file-load boundaries."""
    changed = 0
    for obj in tuple(getattr(getattr(bpy, 'data', None), 'objects', ()) or ()):
        try:
            before = bool(getattr(obj, 'ms_show_end_result', False))
            was_set = bool(obj.is_property_set('ms_show_end_result'))
            ms_ensure_show_end_result_default_off(obj)
            after = bool(getattr(obj, 'ms_show_end_result', False))
            if not was_set and before and not after:
                changed += 1
        except Exception:
            continue
    return changed


def ms_auto_disable_modifiers_enabled(obj) -> bool:
    """Return whether active-level automatic modifier disabling is enabled.

    The value is stored per Smart Modifier base object so the N-panel state
    persistence system can restore it.  Missing data defaults to True to keep
    the existing stack behavior until the user explicitly turns the new toggle
    off.
    """
    try:
        if obj is None or getattr(obj, "type", "") != 'MESH':
            return False
        if hasattr(obj, "ms_auto_disable_modifiers"):
            return bool(getattr(obj, "ms_auto_disable_modifiers", True))
    except Exception:
        pass
    return True


def _ms_context_active_main_mesh(context=None):
    """Return the active Smart Modifier base mesh for the current context, if any."""
    try:
        ctx = context or bpy.context
        vl = getattr(ctx, "view_layer", None)
        ao = getattr(getattr(vl, "objects", None), "active", None) if vl else None
        main = get_main_object(ao) if ao else None
        if main is None:
            main = ao
        if main and getattr(main, "type", "") == 'MESH':
            ms_ensure_show_end_result_default_off(main)
            return main
    except Exception:
        pass
    return None


def ms_modifier_stack_panel_is_recent(main_obj=None, max_age=1.20):
    """True only while the Modifier Stack panel has been drawn recently.

    Blender does not expose a direct 'panel expanded' flag to Python, so the draw
    method refreshes this timestamp.  If the user collapses the stack panel, hides
    the N-panel, changes workspace, or switches away, the timestamp naturally
    expires and preview collections are purged.
    """
    try:
        dn = _ms__dn()
        t = float(dn.get(_MS_STACK_PANEL_DRAW_T_KEY, 0.0) or 0.0)
        if (time.time() - t) > float(max_age):
            return False
        if main_obj is not None:
            n = str(dn.get(_MS_STACK_PANEL_DRAW_MAIN_KEY, "") or "")
            if n and n != getattr(main_obj, "name", ""):
                return False
        return True
    except Exception:
        return False


def ms_preview_context_allows_collections(main_obj=None, context=None):
    """Gate creation/retention of Smart Modifier preview collections.

    The preview collections are intentionally ephemeral.  They may exist only when:
    - the user explicitly enabled Show End Result,
    - Blender is in mesh Edit Mode,
    - the base mesh object itself is the active/edit object,
    - Show Final Result is enabled.
    """
    try:
        ctx = context or bpy.context
        main = main_obj or _ms_context_active_main_mesh(ctx)
        if not main or getattr(main, "type", "") != 'MESH':
            return False
        ms_ensure_show_end_result_default_off(main)
        if not bool(getattr(main, "ms_show_end_result", False)):
            return False
        if str(getattr(ctx, "mode", "OBJECT") or "OBJECT") != 'EDIT_MESH':
            return False
        vl = getattr(ctx, "view_layer", None)
        ao = getattr(getattr(vl, "objects", None), "active", None) if vl else None
        if ao is not main:
            return False
        try:
            eo = getattr(ctx, "edit_object", None)
            if eo is not None and eo is not main:
                return False
        except Exception:
            pass
        return True
    except Exception:
        return False


def ms_mark_modifier_stack_panel_drawn(context=None, main_obj=None):
    """Called from the Modifier Stack panel draw method to arm preview lifetime.

    This function is intentionally draw-safe.  It records that the stack panel is
    visible, but it avoids scheduling cleanup work on every sidebar redraw.  3D
    View orbit/pan/zoom can redraw the N-panel many times per second; repeatedly
    scanning/removing preview data from here causes visible navigation latency.
    """
    try:
        ctx = context or bpy.context
        main = main_obj or _ms_context_active_main_mesh(ctx)
        if not main or getattr(main, "type", "") != 'MESH':
            return
        dn = _ms__dn()
        now = time.time()
        dn[_MS_STACK_PANEL_DRAW_T_KEY] = now
        dn[_MS_STACK_PANEL_DRAW_MAIN_KEY] = main.name

        preview_live = bool(ms_preview_context_allows_collections(main, ctx))
        prev_live_map = dn.get("_MS_PREVIEW_CONTEXT_LIVE_MAP_V1")
        if not isinstance(prev_live_map, dict):
            prev_live_map = {}
        prev_live = bool(prev_live_map.get(main.name, False))
        prev_live_map[main.name] = preview_live
        dn["_MS_PREVIEW_CONTEXT_LIVE_MAP_V1"] = prev_live_map

        # Reconcile event handlers only when the explicit preview session starts
        # or stops.  Do not perform runtime service work during ordinary sidebar
        # redraws caused by orbit, pan, zoom, or mouse movement.
        if preview_live != prev_live:
            try:
                api = dn.get("_MS_RUNTIME_API_V1") or {}
                sync_runtime = api.get("sync_runtime_services") if isinstance(api, dict) else None
                if callable(sync_runtime):
                    sync_runtime(ctx)
            except Exception:
                pass

        if preview_live:
            ms_endpreview_set_allowed(main, True)
            ms_request_endpreview_live_sync()
            return

        # Cleanup is transition-driven.  Never scan every scene object from a
        # panel draw merely to discover whether a preview exists.
        ms_endpreview_set_allowed(main, False)
        if prev_live:
            ms_request_endpreview_global_purge("panel_context_not_live")
    except Exception:
        pass

def ms_request_endpreview_live_sync():
    """Arm a lightweight timer that keeps EndPreview synchronized in edit mode."""
    try:
        dn = _ms__dn()
        if not dn.get(_MS_ENDPREVIEW_LIVE_TIMER_ARMED_KEY):
            dn[_MS_ENDPREVIEW_LIVE_TIMER_ARMED_KEY] = True
            bpy.app.timers.register(_ms_endpreview_live_sync_timer, first_interval=0.08)
    except Exception:
        pass


def ms_endpreview_mode_msgbus_notify(*_args):
    """Start EndPreview when Edit Mode is entered with Show End Result already ON."""
    try:
        ctx = bpy.context
        main = _ms_context_active_main_mesh(ctx)
        if main is None or not ms_auto_disable_modifiers_enabled(main):
            return
        if ms_preview_context_allows_collections(main, ctx):
            ms_endpreview_set_allowed(main, True)
            ms_request_endpreview_live_sync()
    except Exception:
        pass


def _ms_flush_edit_mesh_for_endpreview(main_obj=None, context=None) -> bool:
    """Flush live Edit Mesh coordinates so EndPreview follows modal drags.

    Blender often commits edit-mesh coordinates to the evaluated object only when
    a modal transform finishes.  EndPreview is a separate object, so it must read
    the current bmesh while the user is still dragging vertices.  This helper is
    intentionally limited to the base mesh edit context used by EndPreview.
    """
    try:
        ctx = context or bpy.context
        if str(getattr(ctx, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT_MESH':
            return False
        obj = main_obj or getattr(ctx, 'edit_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return False
        if getattr(ctx, 'edit_object', None) is not obj:
            return False
        me = getattr(obj, 'data', None)
        if me is None:
            return False
        try:
            bmesh.from_edit_mesh(me)
        except Exception:
            return False
        try:
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        except TypeError:
            try:
                bmesh.update_edit_mesh(me)
            except Exception:
                return False
        except Exception:
            return False
        try:
            me.update()
        except Exception:
            pass
        # Object.to_mesh(preserve_all_data_layers=True) evaluates the original mesh
        # data, which does not hold edit-mesh changes until they are written back.
        try:
            obj.update_from_editmode()
        except Exception:
            pass
        try:
            obj.update_tag()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _ms_edit_mesh_live_signature(main_obj=None, context=None):
    """Return a bounded edit-mesh signature for live EndPreview updates.

    The signature deliberately samples only a small number of vertices.  It is
    used to avoid expensive evaluated-mesh rebuilds while the user is merely
    orbiting/panning/zooming the 3D View.  When selected vertex coordinates
    change during a transform, the sampled signature changes and the preview is
    refreshed.
    """
    try:
        ctx = context or bpy.context
        if str(getattr(ctx, 'mode', 'OBJECT') or 'OBJECT') != 'EDIT_MESH':
            return None
        obj = main_obj or getattr(ctx, 'edit_object', None)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return None
        if getattr(ctx, 'edit_object', None) is not obj:
            return None
        me = getattr(obj, 'data', None)
        if me is None:
            return None
        bm = bmesh.from_edit_mesh(me)
        try:
            sel_mode = tuple(bool(v) for v in getattr(getattr(ctx, 'tool_settings', None), 'mesh_select_mode', (False, False, False)))
        except Exception:
            sel_mode = ()
        samples = []
        selected_seen = 0
        scanned = 0
        max_scan = 2048
        max_samples = 32
        try:
            for v in bm.verts:
                scanned += 1
                take = False
                try:
                    if v.select:
                        selected_seen += 1
                        take = True
                except Exception:
                    take = False
                # Add a sparse structural sample so non-selection edits still
                # get a periodic signature without scanning the whole mesh.
                if not take and len(samples) < 8:
                    try:
                        idx = int(getattr(v, 'index', scanned - 1) or 0)
                    except Exception:
                        idx = scanned - 1
                    take = (idx < 4 or (idx % 257) == 0)
                if take and len(samples) < max_samples:
                    try:
                        co = v.co
                        samples.append((int(getattr(v, 'index', scanned - 1) or 0), bool(getattr(v, 'select', False)), round(float(co.x), 5), round(float(co.y), 5), round(float(co.z), 5)))
                    except Exception:
                        pass
                if scanned >= max_scan and len(samples) >= max_samples:
                    break
        except Exception:
            pass
        try:
            return (len(bm.verts), len(bm.edges), len(bm.faces), sel_mode, selected_seen, tuple(samples))
        except Exception:
            return (sel_mode, selected_seen, tuple(samples))
    except Exception:
        return None


def _ms_endpreview_live_sync_timer():
    try:
        dn = _ms__dn()
        delay = _ms_defer_data_cleanup_delay()
        if delay:
            return max(0.08, min(0.20, delay))
        ctx = bpy.context
        main = _ms_context_active_main_mesh(ctx)
        if not ms_preview_context_allows_collections(main, ctx):
            try:
                if main:
                    ms_endpreview_set_allowed(main, False)
                ms_request_endpreview_global_purge("live_context_inactive")
            except Exception:
                pass
            dn.pop(_MS_ENDPREVIEW_LIVE_TIMER_ARMED_KEY, None)
            return None
        try:
            ms_endpreview_set_allowed(main, True)
            now = time.time()
            state = dn.get(_MS_ENDPREVIEW_LIVE_LAST_STATE_KEY)
            if not isinstance(state, dict):
                state = {}

            dirty_rev = _ms_get_dirty_rev(dn, main.name)
            live_sig = _ms_edit_mesh_live_signature(main, ctx)
            key = main.name
            last_rev = int(state.get(key + ":rev", -1) or -1)
            last_sig = state.get(key + ":mesh_sig")
            last_apply = float(state.get(key + ":t", 0.0) or 0.0)

            need = (dirty_rev != last_rev) or (live_sig is not None and live_sig != last_sig)
            # Slow safety fallback keeps preview coherent for rare edit updates that
            # are not represented in the bounded signature.  It is intentionally too
            # slow to interfere with viewport drag responsiveness.
            if (not need) and (now - last_apply) >= 0.85:
                need = True

            if need:
                if live_sig is not None and live_sig != last_sig:
                    _ms_flush_edit_mesh_for_endpreview(main, ctx)
                    root = dn.get("_MS_OBJ_DIRTY_REV_V1")
                    if not isinstance(root, dict):
                        root = {}
                    dirty_rev = int(root.get(main.name, dirty_rev) or 0) + 1
                    root[main.name] = dirty_rev
                    dn["_MS_OBJ_DIRTY_REV_V1"] = root
                state[key + ":rev"] = int(dirty_rev)
                state[key + ":mesh_sig"] = live_sig
                state[key + ":t"] = now
                dn[_MS_ENDPREVIEW_LIVE_LAST_STATE_KEY] = state
                apply_modifier_stack_state(main, ctx, interactive=False)
                try:
                    state[key + ":rev"] = int(_ms_get_dirty_rev(dn, main.name))
                    state[key + ":t"] = time.time()
                    dn[_MS_ENDPREVIEW_LIVE_LAST_STATE_KEY] = state
                except Exception:
                    pass
                _ms_tag_redraw_active_view3d(ctx)
                return 0.08

            state[key + ":mesh_sig"] = live_sig
            dn[_MS_ENDPREVIEW_LIVE_LAST_STATE_KEY] = state
        except Exception:
            pass
        return 0.16
    except Exception:
        try:
            _ms__dn().pop(_MS_ENDPREVIEW_LIVE_TIMER_ARMED_KEY, None)
        except Exception:
            pass
        return None

def ms_endpreview_is_allowed(main_obj):
    try:
        if not main_obj: return False
        dn = _ms__dn()
        m = dn.get(_MS_ENDPREVIEW_ALLOWED_MAP_KEY)
        return bool(isinstance(m, dict) and m.get(main_obj.name, False))
    except Exception:
        return False

def ms_endpreview_set_allowed(main_obj, allowed: bool):
    """Allow EndPreview creation for this main object during Edit-mode operations."""
    try:
        if not main_obj: return
        dn = _ms__dn()
        m = dn.get(_MS_ENDPREVIEW_ALLOWED_MAP_KEY)
        if not isinstance(m, dict):
            m = {}
        if allowed:
            m[main_obj.name] = True
        else:
            m.pop(main_obj.name, None)
        dn[_MS_ENDPREVIEW_ALLOWED_MAP_KEY] = m
    except Exception:
        pass

def ms_request_endpreview_cleanup(main_obj):
    """Request deletion of this main object's EndPreview object on a safe timer."""
    try:
        if not main_obj: return
        dn = _ms__dn()
        lst = dn.get(_MS_ENDPREVIEW_CLEANUP_SET_KEY)
        if not isinstance(lst, list):
            lst = []
        if main_obj.name not in lst:
            lst.append(main_obj.name)
        dn[_MS_ENDPREVIEW_CLEANUP_SET_KEY] = lst
        if not dn.get(_MS_ENDPREVIEW_CLEANUP_ARMED_KEY):
            dn[_MS_ENDPREVIEW_CLEANUP_ARMED_KEY] = True
            bpy.app.timers.register(_ms_endpreview_cleanup_timer, first_interval=0.20)
    except Exception:
        pass

def ms_delete_endpreview_obj_now(main_obj, context):
    """Delete EndPreview object immediately (should only be called from timers/main loop)."""
    if not main_obj or not context:
        return
    try:
        name = str(main_obj.get(_MS_PREVIEW_OBJ_KEY, "") or "")
    except Exception:
        name = ""
    if not name:
        return
    pobj = bpy.data.objects.get(name)
    if not pobj:
        # Clear stale keys
        try:
            main_obj.pop(_MS_PREVIEW_OBJ_KEY, None)
            main_obj.pop(_MS_PREVIEW_STAMP_KEY, None)
            main_obj.pop(_MS_PREVIEW_SIG_KEY, None)
        except Exception:
            pass
        return
    mesh = getattr(pobj, "data", None)
    try:
        bpy.data.objects.remove(pobj, do_unlink=True)
    except Exception:
        # Fallback unlink + remove
        try:
            for c in list(getattr(pobj, "users_collection", []) or []):
                try: c.objects.unlink(pobj)
                except Exception: pass
            bpy.data.objects.remove(pobj)
        except Exception:
            pass
    # Remove mesh datablock if unused
    try:
        if mesh and getattr(mesh, "users", 0) == 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass
    # Clear stamps so future creation is not rate-limited incorrectly
    try:
        main_obj.pop(_MS_PREVIEW_OBJ_KEY, None)
        main_obj.pop(_MS_PREVIEW_STAMP_KEY, None)
        main_obj.pop(_MS_PREVIEW_SIG_KEY, None)
    except Exception:
        pass
    try:
        _ms_cleanup_empty_system_collections()
    except Exception:
        pass

def _ms_endpreview_cleanup_timer():
    try:
        dn = _ms__dn()
        lst = dn.get(_MS_ENDPREVIEW_CLEANUP_SET_KEY)
        if not isinstance(lst, list) or not lst:
            dn.pop(_MS_ENDPREVIEW_CLEANUP_ARMED_KEY, None)
            return None
        ctx = bpy.context
        delay = _ms_defer_data_cleanup_delay()
        if delay:
            return delay
        # Process a few per tick to stay responsive
        batch = lst[:6]
        rest = lst[6:]
        dn[_MS_ENDPREVIEW_CLEANUP_SET_KEY] = rest
        for main_name in batch:
            mo = bpy.data.objects.get(main_name)
            if mo:
                ms_delete_endpreview_obj_now(mo, ctx)
        # Keep running if work remains
        if rest:
            return 0.05
        dn.pop(_MS_ENDPREVIEW_CLEANUP_ARMED_KEY, None)
        return None
    except Exception:
        try:
            _ms__dn().pop(_MS_ENDPREVIEW_CLEANUP_ARMED_KEY, None)
        except Exception:
            pass
        return None

# ------------------------------------------------------------
# Global EndPreview & empty collection purge (safe, timer-based)
# ------------------------------------------------------------
_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_KEY = "_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_V1"
_MS_ENDPREVIEW_GLOBAL_PURGE_REQ_KEY = "_MS_ENDPREVIEW_GLOBAL_PURGE_REQ_V1"

def ms_any_endpreview_objects_exist():
    """Return True if any EndPreview object (including legacy *_MS_EndPreview) exists."""
    try:
        for o in bpy.data.objects:
            n = getattr(o, "name", "") or ""
            if n.endswith("_EndPreview") or n.endswith("_MS_EndPreview"):
                return True
    except Exception:
        pass
    return False

def ms_request_endpreview_global_purge(reason=""):
    """Request a safe purge of unnecessary EndPreview objects and empty system collections."""
    try:
        dn = _ms__dn()
        dn[_MS_ENDPREVIEW_GLOBAL_PURGE_REQ_KEY] = str(reason or "")
        if not dn.get(_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_KEY):
            dn[_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_KEY] = True
            bpy.app.timers.register(_ms_endpreview_global_purge_timer, first_interval=0.25)
    except Exception:
        pass

def _ms__unlink_collection_everywhere(col):
    if not col:
        return
    try:
        # Unlink from parent collections
        for parent in list(getattr(col, "users_collection", []) or []):
            try:
                parent.children.unlink(col)
            except Exception:
                pass
    except Exception:
        pass
    try:
        # Unlink from scene root(s) if directly linked
        for sc in list(getattr(bpy.data, "scenes", []) or []):
            try:
                if sc and sc.collection and sc.collection.children.get(col.name) is not None:
                    sc.collection.children.unlink(col)
            except Exception:
                pass
    except Exception:
        pass

def _ms__remove_collection_if_empty(col):
    """Remove collection if it has no objects and no child collections."""
    try:
        if not col:
            return False
        if (len(col.objects) == 0) and (len(col.children) == 0):
            _ms__unlink_collection_everywhere(col)
            try:
                bpy.data.collections.remove(col)
            except Exception:
                try:
                    bpy.data.collections.remove(col, do_unlink=True)
                except Exception:
                    pass
            return True
    except Exception:
        pass
    return False

def _ms_cleanup_empty_system_collections():
    """Delete empty Smart Modifier preview collections, then the empty root.

    Required order:
    1. Smart Modifier_Collection / EndPreview_Collection when empty.
    2. Modifier_System_Collection when it is empty after child cleanup.
    """
    try:
        root = bpy.data.collections.get("Modifier_System_Collection")
        # First remove the explicitly managed preview/stack collections even if
        # they were accidentally linked outside the root by an older build.
        for name in (_MS_STACK_COLLECTION_NAME, _MS_ENDPREVIEW_COLLECTION_NAME):
            col = bpy.data.collections.get(name)
            if col:
                _ms__remove_collection_if_empty(col)

        root = bpy.data.collections.get("Modifier_System_Collection")
        if root:
            # Remove any other empty child collection under the system root.  This
            # keeps the root tidy but never deletes non-empty helper collections.
            for child in list(root.children):
                _ms__remove_collection_if_empty(child)
            _ms__remove_collection_if_empty(root)
    except Exception:
        pass

def _ms_endpreview_global_purge_timer():
    """Safely purge EndPreview objects that should not exist, and delete empty system collections."""
    try:
        dn = _ms__dn()
        ctx = bpy.context
        delay = _ms_defer_data_cleanup_delay()
        if delay:
            return delay
        # Resolve allowed map (main object names that are allowed to have EndPreview right now).
        allowed_map = dn.get(_MS_ENDPREVIEW_ALLOWED_MAP_KEY)
        if not isinstance(allowed_map, dict):
            allowed_map = {}

        # A preview may be retained only for the single base mesh that is currently
        # active in mesh Edit Mode while the Modifier Stack panel is open.
        keep_preview_names = set()
        live_main = None
        try:
            active_main = _ms_context_active_main_mesh(ctx)
            if active_main and ms_preview_context_allows_collections(active_main, ctx):
                live_main = active_main
                allowed_map[active_main.name] = True
                pn = str(active_main.get(_MS_PREVIEW_OBJ_KEY, "") or "")
                if pn:
                    keep_preview_names.add(pn)
                keep_preview_names.add(f"{active_main.name}_EndPreview")
        except Exception:
            live_main = None

        purge_all = (live_main is None)

        if purge_all:
            try:
                dn[_MS_ENDPREVIEW_ALLOWED_MAP_KEY] = {}
            except Exception:
                pass
        else:
            try:
                dn[_MS_ENDPREVIEW_ALLOWED_MAP_KEY] = allowed_map
            except Exception:
                pass

        # Remove EndPreview objects.
        try:
            for o in list(bpy.data.objects):
                n = getattr(o, "name", "") or ""
                if not (n.endswith("_EndPreview") or n.endswith("_MS_EndPreview")):
                    continue
                if purge_all or (n not in keep_preview_names):
                    # Safe remove; also remove mesh datablock if unused.
                    mesh = getattr(o, "data", None)
                    try:
                        bpy.data.objects.remove(o, do_unlink=True)
                    except Exception:
                        try:
                            for c in list(getattr(o, "users_collection", []) or []):
                                try: c.objects.unlink(o)
                                except Exception: pass
                            bpy.data.objects.remove(o)
                        except Exception:
                            pass
                    try:
                        if mesh and getattr(mesh, "users", 0) == 0:
                            bpy.data.meshes.remove(mesh)
                    except Exception:
                        pass
        except Exception:
            pass

        # Clear stale preview-object references from real scene objects.  These
        # keys are only a cache for the transient EndPreview object; keeping them
        # in saved .blend files after the preview object was purged creates old
        # proxy data with no runtime behavior.
        try:
            live_name = str(getattr(live_main, 'name', '') or '') if live_main is not None else ''
            for obj in list(bpy.data.objects):
                try:
                    pn = str(obj.get(_MS_PREVIEW_OBJ_KEY, '') or '') if hasattr(obj, 'get') else ''
                except Exception:
                    pn = ''
                if not pn:
                    continue
                keep_for_live = bool((not purge_all) and live_name and obj.name == live_name and pn in keep_preview_names and bpy.data.objects.get(pn) is not None)
                if keep_for_live:
                    continue
                if purge_all or bpy.data.objects.get(pn) is None or pn not in keep_preview_names:
                    try:
                        obj.pop(_MS_PREVIEW_OBJ_KEY, None)
                        obj.pop(_MS_PREVIEW_STAMP_KEY, None)
                        obj.pop(_MS_PREVIEW_SIG_KEY, None)
                    except Exception:
                        pass
        except Exception:
            pass

        # Clean up empty system collections.
        _ms_cleanup_empty_system_collections()

    except Exception:
        pass

    # Always clear armed flag
    try:
        dn = _ms__dn()
        dn.pop(_MS_ENDPREVIEW_GLOBAL_PURGE_ARMED_KEY, None)
    except Exception:
        pass
    return None

def _ms_get_preview_collection(scene):
    """Return EndPreview_Collection under Modifier_System_Collection.
    This EndPreview is used by Smart Modifier generally (not EditPoly-only)."""
    if not scene:
        return None
    try:
        # Ensure Modifier_System_Collection exists and is linked under the scene root
        root = bpy.data.collections.get("Modifier_System_Collection")
        if not root:
            root = bpy.data.collections.new("Modifier_System_Collection")
        if scene.collection.children.get(root.name) is None:
            scene.collection.children.link(root)

        # Smart Modifier_Collection is not created here anymore.  It is an
        # organizational legacy collection and must be removed whenever empty.
        # If an older build left it behind, cleanup will delete it after this pass.
        ms_col = bpy.data.collections.get(_MS_STACK_COLLECTION_NAME)

        # Ensure EndPreview_Collection exists
        end_col = bpy.data.collections.get(_MS_ENDPREVIEW_COLLECTION_NAME)
        if not end_col:
            end_col = bpy.data.collections.new(_MS_ENDPREVIEW_COLLECTION_NAME)

        # Always unlink EndPreview_Collection from wrong parents (it must live directly under Modifier_System_Collection)
        if ms_col and ms_col.children.get(end_col.name) is not None:
            try:
                ms_col.children.unlink(end_col)
            except Exception:
                pass
        if scene.collection.children.get(end_col.name) is not None:
            try:
                scene.collection.children.unlink(end_col)
            except Exception:
                pass

        # Link EndPreview_Collection under Modifier_System_Collection
        if root.children.get(end_col.name) is None:
            try:
                root.children.link(end_col)
            except Exception:
                pass

        try:
            if ms_col:
                _ms__remove_collection_if_empty(ms_col)
        except Exception:
            pass
        return end_col
    except Exception:
        return None



def _ms_get_or_create_modsys_collection(scene):
    if not scene: return None
    try:
        col = bpy.data.collections.get(_MS_MODSYS_ROOT_COLLECTION)
        if not col:
            col = bpy.data.collections.new(_MS_MODSYS_ROOT_COLLECTION)
        # Ensure linked under scene root
        if col.name not in [c.name for c in scene.collection.children]:
            scene.collection.children.link(col)
        return col
    except Exception:
        return None

def _ms_get_or_create_editpoly_collection(scene):
    if not scene: return None
    try:
        root = _ms_get_or_create_modsys_collection(scene)
        if not root: return None
        col = bpy.data.collections.get(_MS_EDITPOLY_COLLECTION)
        if not col:
            col = bpy.data.collections.new(_MS_EDITPOLY_COLLECTION)
        # Ensure linked under Modifier_System_Collection
        if col.name not in [c.name for c in root.children]:
            root.children.link(col)
        return col
    except Exception:
        return None

def ms_get_or_create_end_preview_obj(main_obj, context):
    if not main_obj or not context: return None
    # Never create preview collections outside the live Modifier Stack edit context.
    if not ms_preview_context_allows_collections(main_obj, context):
        try:
            ms_request_endpreview_global_purge("create_context_denied")
        except Exception:
            pass
        return None
    scene = getattr(context, "scene", None)
    col = _ms_get_preview_collection(scene)
    if not col: return None

    name = str(main_obj.get(_MS_PREVIEW_OBJ_KEY, "") or "")

    # Migrate legacy name: *_MS_EndPreview -> *_EndPreview
    try:
        if name and str(name).endswith("_MS_EndPreview"):
            new_name = f"{main_obj.name}_EndPreview"
            pobj_old = bpy.data.objects.get(str(name))
            if pobj_old and bpy.data.objects.get(new_name) is None:
                try: pobj_old.name = new_name
                except Exception: pass
            name = new_name
            try: main_obj[_MS_PREVIEW_OBJ_KEY] = name
            except Exception: pass
    except Exception:
        pass

    if not name:
        name = f"{main_obj.name}_EndPreview"
        try: main_obj[_MS_PREVIEW_OBJ_KEY] = name
        except Exception: pass

    pobj = bpy.data.objects.get(name)
    if not pobj:
        try:
            me = bpy.data.meshes.new(f"{name}_Mesh")
            pobj = bpy.data.objects.new(name, me)
            col.objects.link(pobj)
        except Exception: return None
        try: pobj["ms_end_preview_main"] = main_obj.name
        except Exception: pass

    
    # Ensure EndPreview object lives under EndPreview_Collection (Modifier_System_Collection/EndPreview_Collection)
    try:
        if col and pobj and pobj.name not in [o.name for o in col.objects]:
            col.objects.link(pobj)
    except Exception:
        pass

    # Unlink from legacy/tool-managed collections to avoid view-layer exclude conflicts
    try:
        for c in list(getattr(pobj, "users_collection", [])):
            if not c:
                continue
            if c.name in ("MS_EndResult_Preview", _MS_EDITPOLY_COLLECTION):
                try:
                    c.objects.unlink(pobj)
                except Exception:
                    pass
    except Exception:
        pass
    try:
        pobj.hide_select = True
        pobj.hide_render = True
        pobj.display_type = 'SOLID'
        pobj.show_in_front = False
    except Exception: pass
    return pobj

def ms_set_end_preview_visible(main_obj, context, visible: bool):
    pobj = ms_get_or_create_end_preview_obj(main_obj, context) if visible else None
    if not visible:
        try:
            name = str(main_obj.get(_MS_PREVIEW_OBJ_KEY, "") or "")
            pobj2 = bpy.data.objects.get(name) if name else None
            if pobj2:
                # Keep Outliner "Disable in Viewport" untouched; only hide this
                # preview helper in the current view.
                pobj2.hide_set(True)
        except Exception: pass
        return None
    if pobj:
        try:
            pobj.hide_viewport = False
            pobj.hide_set(False)
        except Exception: pass
    return pobj

def ms_update_end_preview_mesh(main_obj, context, full_flags: dict, restore_flags: dict, signature: str, force: bool = False):
    if not main_obj or not context: return
    # Do not create/update EndPreview unless this main object is currently allowed and we are in Edit mode.
    try:
        if (not ms_preview_context_allows_collections(main_obj, context)) or (not ms_endpreview_is_allowed(main_obj)):
            try:
                ms_endpreview_set_allowed(main_obj, False)
                ms_request_endpreview_global_purge("update_context_denied")
            except Exception:
                pass
            return
    except Exception:
        return

    try:
        now = time.time()
        last_sig = str(main_obj.get(_MS_PREVIEW_SIG_KEY, "") or "")
        last_t = float(main_obj.get(_MS_PREVIEW_STAMP_KEY, 0.0) or 0.0)
        if (not force) and signature == last_sig and (now - last_t) < 0.35: return
    except Exception: pass

    pobj = ms_set_end_preview_visible(main_obj, context, True)
    if not pobj: return

    mods = list(getattr(main_obj, "modifiers", []) or [])
    orig = {}
    try:
        for m in mods: orig[m.name] = bool(getattr(m, "show_viewport", True))
    except Exception: orig = {}

    changed = False
    orig_hide = main_obj.hide_viewport
    main_obj.hide_viewport = False
    try:
        for m in mods:
            want = bool(full_flags.get(m.name, True))
            cur = bool(getattr(m, "show_viewport", True))
            if cur != want:
                m.show_viewport = want
                changed = True
    except Exception: pass

    try:
        if str(getattr(context, 'mode', 'OBJECT') or 'OBJECT') == 'EDIT_MESH':
            _ms_flush_edit_mesh_for_endpreview(main_obj, context)
    except Exception:
        pass

    dg = None
    try: dg = context.evaluated_depsgraph_get()
    except Exception: dg = None
    
    # Ensure depsgraph is evaluated when modifier properties change (otherwise preview may lag until another action).
    if force or bool(getattr(main_obj, "ms_show_properties", False)) or (getattr(context, "mode", "OBJECT") != "OBJECT") or changed or orig_hide:
        try:
            if dg and hasattr(dg, "update"): dg.update()
            else: context.view_layer.update()
        except Exception:
            try: context.view_layer.update()
            except Exception: pass

    mesh_copy = None
    eval_obj = None
    try:
        dg2 = dg or context.evaluated_depsgraph_get()
        eval_obj = main_obj.evaluated_get(dg2) if dg2 else main_obj
        tmp = None
        try: tmp = eval_obj.to_mesh(preserve_all_data_layers=True, depsgraph=dg2) if dg2 else eval_obj.to_mesh(preserve_all_data_layers=True)
        except TypeError:
            try: tmp = eval_obj.to_mesh(preserve_all_data_layers=True)
            except Exception: tmp = None
        if tmp:
            try: mesh_copy = tmp.copy()
            except Exception: mesh_copy = None
    except Exception: mesh_copy = None
    finally:
        try:
            if eval_obj: eval_obj.to_mesh_clear()
        except Exception: pass
        main_obj.hide_viewport = orig_hide

    try:
        for m in mods:
            want = bool(restore_flags.get(m.name, orig.get(m.name, True)))
            cur = bool(getattr(m, "show_viewport", True))
            if cur != want: m.show_viewport = want
    except Exception: pass

    if mesh_copy:
        try:
            old = getattr(pobj, "data", None)
            pobj.data = mesh_copy
            # NOTE: Do NOT remove old mesh datablocks here.
            # Removing datablocks during/near depsgraph rebuild can crash Blender (EXCEPTION_ACCESS_VIOLATION).
            # Orphan meshes will be cleaned by Blender / file reload / manual purge.
        except Exception: pass
    try: pobj.matrix_world = main_obj.matrix_world.copy()
    except Exception:
        try: pobj.matrix_world = main_obj.matrix_world
        except Exception: pass

    try:
        main_obj[_MS_PREVIEW_SIG_KEY] = signature
        main_obj[_MS_PREVIEW_STAMP_KEY] = time.time()
    except Exception: pass

# ------------------------------------------
# Plugin System Hooks
# ------------------------------------------

# ---------------------------------------------------------------------------
# Process-lifetime anchor for driver_namespace state
# ---------------------------------------------------------------------------
# Blender REPLACES ``bpy.app.driver_namespace`` with a fresh dict on every file
# load (measured on 5.1.2 ec6e62d40fa9).  Smart Modifier parks its whole
# cross-module API and the 160-entry modifier-stack plugin registry there and
# published it from register() only, so after the user opened one .blend every
# consumer read an empty dict and silently no-opped:  the Add Modifier menu lost
# every plugin entry (365 -> 205 signature rows, 160 -> 0 plugins),
# ms_find_plugin_for_modifier() stopped recognising the Smart Lattice / Edit Poly
# rows already present in the user's file, and the plugins' cleanup_before_remove
# hooks never ran again.  No error was raised anywhere.
#
# A synthetic ``sys.modules`` entry is process-lifetime: it survives file loads
# and this package's own live-update submodule purge (that purge removes only
# ``<package>.`` keys), so the authoritative objects stay reachable and can be
# re-published into the fresh namespace deterministically.  The anchor is scoped
# to this package alone and holds shared data only, never Blender resources.
_MS_NS_ANCHOR_MODULE_NAME = "jelararagi_smart_modifier_ns_anchor_v1"
_MS_NS_ANCHOR_ATTR = "SMS_NS_VALUES"
_MS_NS_REARM_KEY = "_MS_REARM_NS_API_V1"


def _ms_ns_anchor_store():
    """Return this package's process-lifetime anchor dict.  Never raises."""
    try:
        module = sys.modules.get(_MS_NS_ANCHOR_MODULE_NAME)
        if not isinstance(module, types.ModuleType):
            module = types.ModuleType(_MS_NS_ANCHOR_MODULE_NAME)
            module.__doc__ = (
                "Smart Modifier Suite driver_namespace anchor.  Keeps the exact "
                "shared objects reachable across Blender file loads, which "
                "replace bpy.app.driver_namespace.  Not an importable module."
            )
            setattr(module, _MS_NS_ANCHOR_ATTR, {})
            sys.modules[_MS_NS_ANCHOR_MODULE_NAME] = module
        store = getattr(module, _MS_NS_ANCHOR_ATTR, None)
        if not isinstance(store, dict):
            store = {}
            setattr(module, _MS_NS_ANCHOR_ATTR, store)
        return store
    except Exception:
        return {}


def _ms_ns_adopt_dict(dn, key):
    """Return the live dict for ``key``, adopting the anchored one when wiped.

    An empty dict is minted only when this process genuinely never had one, so a
    file load that replaced ``driver_namespace`` can no longer strand the real
    records.  The anchor is left pointing at the exact live object, which keeps
    entries recorded through any other write path visible.
    """
    store = _ms_ns_anchor_store()
    try:
        value = dn.get(key)
    except Exception:
        value = None
    if not isinstance(value, dict):
        anchored = store.get(key)
        value = anchored if isinstance(anchored, dict) else {}
        try:
            dn[key] = value
        except Exception:
            pass
    store[key] = value
    return value


def _ms_ns_rearm():
    """Ask this generation's re-arm entry point to re-publish the shared API.

    The callable is anchored by ``runtime._ensure_driver_namespace_api`` and
    dropped by ``runtime._clear_driver_namespace_api``, so a disabled add-on can
    never be resurrected into a fresh namespace.  Never raises.
    """
    try:
        fn = _ms_ns_anchor_store().get(_MS_NS_REARM_KEY)
        if callable(fn):
            fn()
            return True
    except Exception:
        pass
    return False


def _ms_plugins_dict():
    """Return the shared Smart Modifier plugin registry dict.

    Safety:
    - Always returns a dict.
    - If an older/buggy add-on left a non-dict value in driver_namespace, it is replaced.
    - A file load replaces driver_namespace wholesale; the registry is adopted
      back from the process-lifetime anchor instead of being minted empty.
    """
    return _ms_ns_adopt_dict(_ms__dn(), "_MS_MODIFIER_STACK_PLUGINS_V1")


def _ms_api(key="_MS_API_V1"):
    """Read a published Smart Modifier API table, healing a wiped namespace.

    Any consumer heals the namespace on first touch this way, so recovery does
    not depend on the ``load_post`` handler having run first.  Always a dict.
    """
    try:
        dn = _ms__dn()
        value = dn.get(key)
        if value is None:
            _ms_ns_rearm()
            value = dn.get(key)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}

_MS_PLUGIN_SORT_CACHE_SIG = None
_MS_PLUGIN_SORT_CACHE = ()


def _ms_invalidate_plugin_sort_cache():
    global _MS_PLUGIN_SORT_CACHE_SIG, _MS_PLUGIN_SORT_CACHE
    _MS_PLUGIN_SORT_CACHE_SIG = None
    _MS_PLUGIN_SORT_CACHE = ()


def ms_register_plugin(plugin_id, plugin_dict):
    if plugin_id and plugin_dict:
        plugin_dict["id"] = str(plugin_id)
        _ms_plugins_dict()[str(plugin_id)] = plugin_dict
        _ms_invalidate_plugin_sort_cache()

def ms_unregister_plugin(plugin_id):
    if plugin_id:
        _ms_plugins_dict().pop(str(plugin_id), None)
        _ms_invalidate_plugin_sort_cache()

def _ms_request_deferred_plugin_bootstrap(reason="plugins", include_optional=True):
    """Compatibility hook kept side-effect-free for UI draw safety.

    Bundled plugin operators and registry entries are preloaded from
    runtime.register_runtime().  This getter is used by N-panel drawing,
    so it must not register/unregister Blender classes, schedule timers, edit
    keymaps, or mutate Workspace Tool state.  Missing registry entries fail
    safely by returning the plugins that are already registered.
    """
    del reason, include_optional
    return None

def ms_get_plugins_sorted():
    _ms_request_deferred_plugin_bootstrap(reason="plugins", include_optional=True)
    plugins_dict = _ms_plugins_dict()
    try:
        sig = tuple((str(k), id(v), int(v.get("priority", 0) or 0)) for k, v in plugins_dict.items())
    except Exception:
        sig = None
    global _MS_PLUGIN_SORT_CACHE_SIG, _MS_PLUGIN_SORT_CACHE
    if sig is not None and sig == _MS_PLUGIN_SORT_CACHE_SIG:
        return list(_MS_PLUGIN_SORT_CACHE)
    plugins = list(plugins_dict.values())
    plugins.sort(key=lambda p: int(p.get("priority", 0) or 0), reverse=True)
    if sig is not None:
        _MS_PLUGIN_SORT_CACHE_SIG = sig
        _MS_PLUGIN_SORT_CACHE = tuple(plugins)
    return plugins

def ms_find_plugin_for_modifier(mod):
    if not mod: return None
    for p in ms_get_plugins_sorted():
        fn = p.get("match_modifier")
        if callable(fn) and fn(mod): return p
    return None

def ms_call_plugins(hook_name, *args, **kwargs):
    out = []
    for p in ms_get_plugins_sorted():
        fn = p.get(hook_name)
        if callable(fn):
            try: out.append((p.get("id", ""), fn(*args, **kwargs)))
            except Exception: out.append((p.get("id", ""), None))
    return out

def ms_should_suppress_properties(mod):
    p = ms_find_plugin_for_modifier(mod)
    if p and callable(p.get("suppress_properties")):
        return bool(p.get("suppress_properties")(mod))
    return False

def ms_plugin_is_edit_source(obj, mod):
    p = ms_find_plugin_for_modifier(mod)
    if p and callable(p.get("is_edit_source")):
        return bool(p.get("is_edit_source")(obj, mod))
    return False

def ms_plugin_requires_bottom_insert(obj, mod):
    # The stack insertion policy is now global: every standard/custom modifier
    # is inserted directly below the active stack slot.  Legacy plugin-level
    # bottom insertion requests are intentionally ignored.
    return False

def ms_find_nearest_edit_source_id(main_obj, effective_active_id: str, active_idx: int) -> str:
    if not main_obj: return "BASE"
    if not effective_active_id or effective_active_id == "BASE": return "BASE"
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if not ms_object_has_modifier_collection(stack_obj): return "BASE"
    active_mod = stack_obj.modifiers.get(effective_active_id)
    if active_mod is None or ms_modifier_is_internal_stack_helper(active_mod): return "BASE"

    if ms_plugin_is_edit_source(stack_obj, active_mod):
        return effective_active_id

    p = ms_find_plugin_for_modifier(active_mod)
    if p and callable(p.get("sync_objects")):
        return effective_active_id

    try: idx = int(active_idx)
    except Exception: idx = -1
    if idx < 0: idx = stack_obj.modifiers.find(effective_active_id)
    if idx < 0: return "BASE"

    for j in range(idx, -1, -1):
        m = stack_obj.modifiers[j]
        if ms_modifier_is_internal_stack_helper(m):
            continue
        if ms_plugin_is_edit_source(stack_obj, m):
            return m.name
    return "BASE"

def _ms_set_shared_lock(state: bool):
    bpy.app.driver_namespace["_MS_MODIFIER_STACK_SYNC_LOCK"] = bool(state)

def clear_clipboard_meshes():
    payload = MS_Clipboard.get("payload") or {}
    names = []
    if isinstance(payload.get("mesh_names"), (list, tuple)):
        names.extend([n for n in payload.get("mesh_names") if isinstance(n, str) and n])
    for k in ("edit_mesh_name", "frozen_mesh_name"):
        n = payload.get(k)
        if isinstance(n, str) and n: names.append(n)
    for n in list(dict.fromkeys(names)):
        me = bpy.data.meshes.get(n)
        # NOTE: Do NOT remove datablocks here (stability).
        # if me: bpy.data.meshes.remove(me)

_MS_INST_SYNC_LOCK = False
_MS_INSTANCE_KEY = "ms_instance_id"
_MS_INST_MAP_KEY = "ms_instance_map"


def _ms_instance_map_is_mapping(value) -> bool:
    """Accept both Python dictionaries and Blender IDPropertyGroup values."""
    if value is None:
        return False
    try:
        return callable(getattr(value, "keys", None)) and callable(getattr(value, "get", None))
    except Exception:
        return False


def _ms_instance_id_from_current_storage(obj, mod_name) -> str:
    """Recover an ID without calling the public lookup path recursively."""
    name = str(mod_name or "")
    if not obj or not name:
        return ""
    try:
        items = getattr(obj, "ms_instance_map_items", None)
        if items is not None:
            for item in items:
                if str(getattr(item, "mod_name", "") or "") == name:
                    value = str(getattr(item, "instance_id", "") or "")
                    if value:
                        return value
    except Exception:
        pass
    try:
        mod = obj.modifiers.get(name)
        if mod is not None and hasattr(mod, "keys") and _MS_INSTANCE_KEY in mod.keys():
            return str(mod.get(_MS_INSTANCE_KEY, "") or "")
    except Exception:
        pass
    return ""


def _ms_instance_map_recover(obj, raw) -> dict:
    """Read known legacy payload shapes without mutating the .blend file."""
    recovered = {}

    def add_pair(name, instance_id):
        key = str(name or "")
        value = str(instance_id or "")
        if key and value:
            recovered[key] = value

    def add_name(name):
        key = str(name or "")
        if key:
            add_pair(key, _ms_instance_id_from_current_storage(obj, key))

    value = raw
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            add_name(value)
            return recovered

    if _ms_instance_map_is_mapping(value):
        try:
            for key in value.keys():
                add_pair(key, value.get(key))
        except Exception:
            pass
        return recovered

    try:
        entries = list(value) if value is not None else []
    except Exception:
        entries = []
    for entry in entries:
        if _ms_instance_map_is_mapping(entry):
            try:
                mod_name = entry.get("mod_name")
                instance_id = entry.get("instance_id")
            except Exception:
                mod_name = instance_id = None
            if mod_name:
                add_pair(mod_name, instance_id or _ms_instance_id_from_current_storage(obj, mod_name))
                continue
            try:
                for key in entry.keys():
                    add_pair(key, entry.get(key))
            except Exception:
                pass
            continue
        if isinstance(entry, (list, tuple)) and len(entry) >= 2:
            add_pair(entry[0], entry[1])
            continue
        if isinstance(entry, str):
            add_name(entry)
    return recovered


def _ms_obj_legacy_instance_map_state(obj, *, repair=False, create=False):
    """Return a safe mapping and optionally replace an incompatible legacy value.

    Old production files may contain ``ms_instance_map`` as a list of modifier
    names. Current code stores IDs in ``ms_instance_map_items`` and, for backward
    compatibility, mirrors them to a mapping ID property. Reads stay side-effect
    free; mutation paths repair the legacy value lazily.
    """
    if not obj:
        return {}, False
    try:
        has_key = _MS_INST_MAP_KEY in obj.keys()
        raw = obj.get(_MS_INST_MAP_KEY)
    except Exception:
        has_key = False
        raw = None
    if _ms_instance_map_is_mapping(raw):
        return raw, False

    recovered = _ms_instance_map_recover(obj, raw)
    if not ((repair and has_key) or create):
        return recovered, False

    try:
        if has_key:
            del obj[_MS_INST_MAP_KEY]
        obj[_MS_INST_MAP_KEY] = dict(recovered)
        stored = obj.get(_MS_INST_MAP_KEY)
        if _ms_instance_map_is_mapping(stored):
            return stored, True
    except Exception:
        if has_key:
            try:
                obj[_MS_INST_MAP_KEY] = raw
            except Exception:
                pass
    return recovered, False


def ms_obj_inst_map(obj, create=True):
    if not obj: return None
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        return {it.mod_name: it.instance_id for it in items if it.mod_name and it.instance_id}
    m, _repaired = _ms_obj_legacy_instance_map_state(obj, repair=bool(create), create=bool(create))
    return m

def ms_obj_cleanup_instance_map(obj):
    if not obj or not obj.modifiers: return
    changed = False
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        stale = [i for i, it in enumerate(items) if it.mod_name and not obj.modifiers.get(it.mod_name)]
        if stale:
            changed = True
        for i in reversed(stale): items.remove(i)
    m, _repaired = _ms_obj_legacy_instance_map_state(obj)
    if m:
        stale = [k for k in list(m.keys()) if not obj.modifiers.get(k)]
        if stale:
            changed = True
        for k in stale: del m[k]
    if changed:
        try:
            _ms_modifier_instance_cache_mark_dirty()
        except Exception:
            pass

def ms_obj_get_instance_id(obj, mod_name):
    if not obj or not mod_name: return ""
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        for it in items:
            if it.mod_name == mod_name: return it.instance_id
    m, _repaired = _ms_obj_legacy_instance_map_state(obj)
    if m and m.get(mod_name): return str(m.get(mod_name))
    mod = obj.modifiers.get(mod_name)
    if mod:
        try:
            if hasattr(mod, "keys") and _MS_INSTANCE_KEY in mod.keys(): 
                return str(mod.get(_MS_INSTANCE_KEY))
        except Exception: pass
    return ""

def ms_obj_get_instance_display_name(obj, mod_name) -> str:
    return ms_obj_get_disp_name(obj, mod_name)

def _ms_instance_subscription_refresh_timer():
    try:
        _ms__dn().pop(_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_KEY, None)
        _ms_modifier_instance_cache_mark_dirty()
        ms_refresh_instance_sync_subscriptions(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _ms_request_instance_subscription_refresh() -> None:
    """Watch the modifier type of a newly linked row once its operator has finished."""
    dn = _ms__dn()
    if not dn.get(_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_KEY):
        dn[_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_KEY] = True
        bpy.app.timers.register(_ms_instance_subscription_refresh_timer, first_interval=0.02)


def ms_obj_set_instance_id(obj, mod_name, instance_id, disp_name=None):
    if not obj or not mod_name or not instance_id:
        return False
    changed = False
    iid = str(instance_id)
    dn = str(disp_name) if disp_name is not None else None
    old_iid = ""
    try:
        old_iid = str(ms_get_instance_id(obj.modifiers.get(mod_name), obj) or "")
    except Exception:
        old_iid = ""
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        found = next((it for it in items if it.mod_name == mod_name), None)
        if not found:
            found = items.add()
            found.mod_name = mod_name
            changed = True
        if str(getattr(found, "instance_id", "") or "") != iid:
            found.instance_id = iid
            changed = True
        if dn is not None and str(getattr(found, "disp_name", "") or "") != dn:
            found.disp_name = dn
            changed = True
    m, repaired = _ms_obj_legacy_instance_map_state(obj, repair=True, create=True)
    changed = bool(changed or repaired)
    try:
        if m is not None and str(m.get(mod_name, "") or "") != iid:
            m[mod_name] = iid
            changed = True
    except Exception:
        pass
    try:
        mod = obj.modifiers.get(mod_name)
    except Exception:
        mod = None
    if mod:
        try:
            if hasattr(mod, "keys") and str(mod.get(_MS_INSTANCE_KEY, "") or "") != iid:
                mod[_MS_INSTANCE_KEY] = iid
                changed = True
        except Exception:
            pass
    if old_iid != iid:
        try:
            _ms_modifier_instance_cache_mark_dirty()
            _ms_request_instance_subscription_refresh()
        except Exception:
            pass
    return changed

def ms_obj_clear_instance_id(obj, mod_name):
    if not obj or not mod_name: return
    had_iid = False
    try:
        had_iid = bool(ms_obj_get_instance_id(obj, mod_name))
    except Exception:
        had_iid = False
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        for it in items:
            if it.mod_name == mod_name:
                it.instance_id = ""
                break
    try:
        has_legacy_map = _MS_INST_MAP_KEY in obj.keys()
    except Exception:
        has_legacy_map = False
    m, repaired = _ms_obj_legacy_instance_map_state(obj, repair=has_legacy_map)
    if m and mod_name in m: del m[mod_name]
    mod = obj.modifiers.get(mod_name)
    if mod:
        try:
            if hasattr(mod, "keys") and _MS_INSTANCE_KEY in mod.keys(): 
                del mod[_MS_INSTANCE_KEY]
        except Exception: pass
    if had_iid or repaired:
        try:
            _ms_modifier_instance_cache_mark_dirty()
        except Exception:
            pass

def ms_obj_rename_instance_key(obj, old_name, new_name):
    if not obj or not old_name or not new_name or old_name == new_name: return
    changed = False
    items = getattr(obj, "ms_instance_map_items", None)
    if items is not None:
        for it in items:
            if it.mod_name == old_name:
                it.mod_name = new_name
                changed = True
                break
    try:
        has_legacy_map = _MS_INST_MAP_KEY in obj.keys()
    except Exception:
        has_legacy_map = False
    m, repaired = _ms_obj_legacy_instance_map_state(obj, repair=has_legacy_map)
    changed = bool(changed or repaired)
    if m and old_name in m and new_name not in m:
        m[new_name] = m[old_name]; del m[old_name]
        changed = True
    if changed:
        try:
            _ms_modifier_instance_cache_mark_dirty()
        except Exception:
            pass

def ms_is_instance_modifier(mod, obj=None):
    if not mod: return False
    try:
        if hasattr(mod, "keys") and _MS_INSTANCE_KEY in mod.keys(): return True
    except Exception: pass
    if obj and ms_obj_get_instance_id(obj, getattr(mod, "name", "")): return True
    return False

def ms_get_instance_id(mod, obj=None):
    if not mod: return ""
    try:
        if hasattr(mod, "keys") and _MS_INSTANCE_KEY in mod.keys(): return str(mod.get(_MS_INSTANCE_KEY))
    except Exception: pass
    if obj:
        v = ms_obj_get_instance_id(obj, getattr(mod, "name", ""))
        if v: return str(v)
    return ""

def ms_instance_paste_id():
    return uuid.uuid4().hex

# -----------------------------------------------------------------------------
# Object-level instance groups for Smart Modifier Suite instance copy
# -----------------------------------------------------------------------------
_MS_OBJECT_INSTANCE_KEY = "sms_object_instance_id"
_MS_OBJECT_INSTANCE_SIG_KEY = "sms_object_instance_modifier_signature"
_MS_OBJECT_INSTANCE_UNIQUE_MOD_KEY = "sms_object_instance_unique_modifier"
_MS_OBJECT_INSTANCE_UNIQUE_MOD_MAP_KEY = "sms_object_instance_unique_modifier_map"
_MS_OBJECT_INSTANCE_SYNC_LOCK = False
_MS_OBJECT_INSTANCE_GROUP_CACHE_KEY = "_MS_OBJECT_INSTANCE_GROUP_CACHE_V1"
_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY = "_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_V1"
_MS_OBJECT_INSTANCE_TIMER_LAST_FULL_T_KEY = "_MS_OBJECT_INSTANCE_TIMER_LAST_FULL_T_V1"
_MS_INSTANCE_EVENT_SYNC_ARMED_KEY = "_MS_INSTANCE_EVENT_SYNC_ARMED_V1"
_MS_INSTANCE_EVENT_SANITIZE_KEY = "_MS_INSTANCE_EVENT_SANITIZE_V1"
_MS_INSTANCE_EVENT_SCENE_SIG_KEY = "_MS_INSTANCE_EVENT_SCENE_SIG_V1"
_MS_INSTANCE_EVENT_DUE_KEY = "_MS_INSTANCE_EVENT_DUE_V1"
_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY = "_MS_INSTANCE_EVENT_MEMBER_NAMES_V1"
_MS_MODIFIER_INSTANCE_GROUP_CACHE_KEY = "_MS_MODIFIER_INSTANCE_GROUP_CACHE_V1"
_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY = "_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_V1"
_MS_MODIFIER_INSTANCE_RUNTIME_SIG_CACHE_KEY = "_MS_MODIFIER_INSTANCE_RUNTIME_SIG_CACHE_V1"
_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY = "_MS_INSTANCE_ACTIVE_CHECK_ARMED_V1"
_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY = "_MS_INSTANCE_ACTIVE_CHECK_DUE_V1"
_MS_INSTANCE_MSGBUS_SUBSCRIPTION_COUNT_KEY = "_MS_INSTANCE_MSGBUS_SUBSCRIPTION_COUNT_V1"
_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY = "_MS_INSTANCE_MSGBUS_CHANGED_PROPS_V1"
_MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_KEY = "_MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_V1"
_MS_INSTANCE_MSGBUS_OWNER = object()
_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_KEY = "_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_V1"
_MS_INSTANCE_NODES_NOTIFIED_SIGS_KEY = "_MS_INSTANCE_NODES_NOTIFIED_SIGS_V1"

_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY = "_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_V1"
_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY = "_MS_OBJECT_INSTANCE_ALLOWED_NEW_V1"


def _ms_object_identity_key(obj) -> str:
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        name = ''
    if not name:
        return ''
    try:
        ptr = str(int(obj.as_pointer()))
    except Exception:
        ptr = ''
    return name + '|' + ptr


def ms_snapshot_existing_object_instance_members(context=None) -> None:
    """Record existing objects so native Shift+D copies can be detected later.

    Blender copies object/modifier custom properties during normal duplication.
    Without an explicit snapshot, a normal Shift+D copy of a Smart Modifier
    object-instance keeps sms_object_instance_id and is incorrectly absorbed into
    the synchronized instance group.
    """
    try:
        objects = list((context.scene.objects if context is not None and hasattr(context, 'scene') else bpy.data.objects) or [])
    except Exception:
        objects = list(getattr(bpy.data, 'objects', []) or [])
    known = []
    seen = set()
    for obj in objects:
        key = _ms_object_identity_key(obj)
        if key and key not in seen:
            seen.add(key)
            known.append(key)
    try:
        _ms__dn()[_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY] = known
    except Exception:
        pass


def ms_allow_new_object_instance_member(obj, group_id=None) -> None:
    """Mark a newly-created object as an intentional Smart Modifier instance.

    Only the suite's Instance Copy / drag-instance paths call this.  Native
    Blender duplication remains unapproved and is converted to a unique copy.
    """
    key = _ms_object_identity_key(obj)
    if not key:
        return
    try:
        dn = _ms__dn()
        allowed = dn.get(_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY)
        if not isinstance(allowed, dict):
            allowed = {}
        allowed[key] = str(group_id or ms_get_object_instance_id(obj) or '')
        dn[_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY] = allowed
    except Exception:
        pass


def ms_make_object_instance_copy_unique(obj, context=None) -> bool:
    """Detach one object copied by native duplicate from Smart Modifier instances."""
    if not obj:
        return False
    changed = False
    try:
        data = getattr(obj, 'data', None)
        if data is not None and int(getattr(data, 'users', 0) or 0) > 1:
            try:
                obj.data = data.copy()
                changed = True
            except Exception:
                pass
    except Exception:
        pass
    try:
        gid = ms_get_object_instance_id(obj)
        if gid:
            ms_clear_object_instance_id(obj)
            changed = True
    except Exception:
        pass
    try:
        for mod in list(getattr(obj, 'modifiers', ()) or []):
            try:
                if ms_get_instance_id(mod, obj):
                    try:
                        ms_make_modifier_unique(obj, mod, context=context)
                    except Exception:
                        ms_obj_clear_instance_id(obj, mod.name)
                    changed = True
                else:
                    ms_obj_clear_instance_id(obj, mod.name)
                _ms_modifier_set_object_instance_unique(mod, False)
            except Exception:
                continue
    except Exception:
        pass
    try:
        obj.update_tag()
    except Exception:
        pass
    if changed:
        try:
            _ms_object_instance_cache_mark_dirty()
            _ms_modifier_instance_cache_mark_dirty()
        except Exception:
            pass
    return changed


def ms_sanitize_unapproved_object_instance_copies(context=None) -> int:
    """Convert native duplicate copies of Smart Modifier instances into unique copies.

    This preserves the intended split:
    - Smart Modifier 「インスタンスコピー」 keeps object-instance synchronization.
    - Blender normal copy (Shift+D / duplicate) becomes an independent object.
    """
    try:
        dn = _ms__dn()
    except Exception:
        return 0
    try:
        objects = list((context.scene.objects if context is not None and hasattr(context, 'scene') else bpy.data.objects) or [])
    except Exception:
        objects = list(getattr(bpy.data, 'objects', []) or [])
    known_raw = dn.get(_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY)
    if not isinstance(known_raw, list):
        ms_snapshot_existing_object_instance_members(context)
        return 0
    known = set(str(x) for x in known_raw if x)
    allowed = dn.get(_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY)
    if not isinstance(allowed, dict):
        allowed = {}
    changed = 0
    for obj in objects:
        key = _ms_object_identity_key(obj)
        if not key:
            continue
        if key not in known:
            gid = ''
            try:
                gid = str(ms_get_object_instance_id(obj) or '')
            except Exception:
                gid = ''
            has_instance_marker = bool(gid)
            if not has_instance_marker:
                try:
                    for _mod in tuple(getattr(obj, 'modifiers', ()) or ()):
                        if ms_get_instance_id(_mod, obj):
                            has_instance_marker = True
                            break
                except Exception:
                    pass
            approved = key in allowed
            if has_instance_marker and not approved:
                try:
                    changed += int(bool(ms_make_object_instance_copy_unique(obj, context=context)))
                except Exception:
                    pass
            known.add(key)
            try:
                allowed.pop(key, None)
            except Exception:
                pass
    try:
        dn[_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY] = sorted(known)
        if allowed:
            dn[_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY] = allowed
        else:
            dn.pop(_MS_OBJECT_INSTANCE_ALLOWED_NEW_KEY, None)
    except Exception:
        pass
    return changed



def _ms_modifier_instance_runtime_marker_key(obj, mod, iid='') -> str:
    try:
        obj_name = str(getattr(obj, 'name', '') or '')
    except Exception:
        obj_name = ''
    try:
        mod_name = str(getattr(mod, 'name', '') or '')
    except Exception:
        mod_name = ''
    try:
        ptr = str(int(mod.as_pointer())) if hasattr(mod, 'as_pointer') else ''
    except Exception:
        ptr = ''
    return '|'.join((str(iid or ''), obj_name, mod_name, ptr))


def _ms_get_modifier_last_source_sig(obj, mod, iid='') -> str:
    try:
        value = str(mod.get('_ms_instance_last_source_sig', '') or '')
        if value:
            return value
    except Exception:
        pass
    try:
        cache = _ms__dn().get(_MS_MODIFIER_INSTANCE_RUNTIME_SIG_CACHE_KEY)
        if isinstance(cache, dict):
            return str(cache.get(_ms_modifier_instance_runtime_marker_key(obj, mod, iid), '') or '')
    except Exception:
        pass
    return ''


def _ms_set_modifier_last_source_sig(obj, mod, sig, iid='') -> bool:
    sig = str(sig or '')
    if not sig:
        return False
    data_changed = False
    stored_on_modifier = False
    try:
        current = _ms_get_modifier_last_source_sig(obj, mod, iid)
        if current != sig:
            mod['_ms_instance_last_source_sig'] = sig
            data_changed = True
        stored_on_modifier = True
    except Exception:
        stored_on_modifier = False
    if not stored_on_modifier:
        try:
            dn = _ms__dn()
            cache = dn.get(_MS_MODIFIER_INSTANCE_RUNTIME_SIG_CACHE_KEY)
            if not isinstance(cache, dict):
                cache = {}
            key = _ms_modifier_instance_runtime_marker_key(obj, mod, iid)
            if str(cache.get(key, '') or '') != sig:
                cache[key] = sig
                dn[_MS_MODIFIER_INSTANCE_RUNTIME_SIG_CACHE_KEY] = cache
        except Exception:
            pass
    return data_changed


def _ms_object_instance_cache_mark_dirty() -> None:
    try:
        _ms__dn()[_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY] = True
    except Exception:
        pass


def _ms_object_instance_scene_signature(context=None):
    try:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    try:
        objects = getattr(scene, 'objects', None) if scene is not None else getattr(bpy.data, 'objects', None)
        count = len(objects or [])
    except Exception:
        count = 0
    try:
        scene_ptr = int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        scene_ptr = 0
    return (scene_ptr, int(count))


def _ms_object_instance_group_cache(context=None, *, force=False):
    """Return cached object-instance groups as {gid: (object names...)}.

    Full scene scans are expensive during viewport redraw/timer activity.  The
    cache is dirtied whenever this add-on changes object-instance membership and
    is also rebuilt if the scene object count changes.
    """
    try:
        dn = _ms__dn()
        sig = _ms_object_instance_scene_signature(context)
        cache = dn.get(_MS_OBJECT_INSTANCE_GROUP_CACHE_KEY)
        dirty = bool(dn.get(_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY, False))
        if (not force) and isinstance(cache, dict) and cache.get('sig') == sig and not dirty:
            groups = cache.get('groups')
            if isinstance(groups, dict):
                return groups
        try:
            objs = list((context.scene.objects if context and hasattr(context, 'scene') else bpy.data.objects) or [])
        except Exception:
            objs = list(getattr(bpy.data, 'objects', []) or [])
        groups = {}
        for obj in objs:
            try:
                gid = ms_get_object_instance_id(obj)
                if gid:
                    name = str(getattr(obj, 'name', '') or '')
                    if name:
                        groups.setdefault(str(gid), []).append(name)
            except Exception:
                continue
        groups = {gid: tuple(names) for gid, names in groups.items() if names}
        dn[_MS_OBJECT_INSTANCE_GROUP_CACHE_KEY] = {'sig': sig, 'groups': groups}
        dn.pop(_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY, None)
        return groups
    except Exception:
        return {}


def _ms_object_instance_group_members_from_cache(group_id, context=None):
    gid = str(group_id or '')
    if not gid:
        return []
    groups = _ms_object_instance_group_cache(context)
    names = groups.get(gid) if isinstance(groups, dict) else None
    if names is None:
        groups = _ms_object_instance_group_cache(context, force=True)
        names = groups.get(gid) if isinstance(groups, dict) else ()
    members = []
    stale = False
    seen = set()
    for name in tuple(names or ()): 
        try:
            obj = bpy.data.objects.get(str(name))
        except Exception:
            obj = None
        if obj is None:
            stale = True
            continue
        try:
            if ms_get_object_instance_id(obj) != gid:
                stale = True
                continue
            oname = str(getattr(obj, 'name', '') or '')
            if oname and oname not in seen:
                seen.add(oname)
                members.append(obj)
        except Exception:
            stale = True
    if stale:
        _ms_object_instance_cache_mark_dirty()
    return members


def _ms_modifier_instance_cache_mark_dirty() -> None:
    try:
        _ms__dn()[_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY] = True
    except Exception:
        pass


def _ms_modifier_instance_group_cache(context=None, *, force=False):
    """Return cached virtual modifier-instance groups as {iid: ((obj, mod), ... names)}."""
    try:
        dn = _ms__dn()
        sig = _ms_object_instance_scene_signature(context)
        cache = dn.get(_MS_MODIFIER_INSTANCE_GROUP_CACHE_KEY)
        dirty = bool(dn.get(_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY, False))
        if (not force) and isinstance(cache, dict) and cache.get('sig') == sig and not dirty:
            groups = cache.get('groups')
            if isinstance(groups, dict):
                return groups
        try:
            objs = list((context.scene.objects if context and hasattr(context, 'scene') else bpy.data.objects) or [])
        except Exception:
            objs = list(getattr(bpy.data, 'objects', []) or [])
        groups = {}
        for obj in objs:
            try:
                mods = getattr(obj, 'modifiers', None)
                # Fast path for ordinary scene objects: if no modifiers are present,
                # there cannot be a virtual Smart Modifier instance to synchronize.
                # Avoid the broader stack-support checks on every object during
                # viewport-navigation timers.
                try:
                    if not mods or len(mods) == 0:
                        continue
                except Exception:
                    if not mods:
                        continue
                if not ms_object_has_modifier_collection(obj):
                    continue
                try:
                    ms_obj_cleanup_instance_map(obj)
                except Exception:
                    pass
                seen_mods = set()
                m = ms_obj_inst_map(obj, create=False)
                if m:
                    for mod_name, iid in list(m.items()):
                        try:
                            mod = mods.get(mod_name)
                            sid = str(iid or '')
                            if mod and sid:
                                key = (str(getattr(obj, 'name', '') or ''), str(getattr(mod, 'name', '') or ''))
                                if key[0] and key[1]:
                                    groups.setdefault(sid, []).append(key)
                                    seen_mods.add(key[1])
                        except Exception:
                            continue
                for mod in mods:
                    try:
                        mname = str(getattr(mod, 'name', '') or '')
                        if not mname or mname in seen_mods:
                            continue
                        sid = ''
                        if hasattr(mod, 'keys'):
                            sid = str(mod.get(_MS_INSTANCE_KEY) or '')
                        if sid:
                            key = (str(getattr(obj, 'name', '') or ''), mname)
                            if key[0] and key[1]:
                                groups.setdefault(sid, []).append(key)
                    except Exception:
                        continue
            except Exception:
                continue
        packed = {}
        for iid, items in groups.items():
            if not iid:
                continue
            unique = []
            seen = set()
            for item in items:
                if item not in seen:
                    seen.add(item)
                    unique.append(item)
            if len(unique) > 1:
                packed[str(iid)] = tuple(unique)
        dn[_MS_MODIFIER_INSTANCE_GROUP_CACHE_KEY] = {'sig': sig, 'groups': packed}
        dn.pop(_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY, None)
        return packed
    except Exception:
        return {}


def _ms_resolve_modifier_instance_groups(groups, *, mark_stale=True):
    resolved = {}
    stale = False
    try:
        iterable = tuple((groups or {}).items())
    except Exception:
        iterable = ()
    for iid, items in iterable:
        pairs = []
        seen = set()
        sid = str(iid or '')
        if not sid:
            continue
        for oname, mname in tuple(items or ()): 
            try:
                obj = bpy.data.objects.get(str(oname))
                mod = obj.modifiers.get(str(mname)) if obj and ms_object_has_modifier_collection(obj) else None
                if not obj or not mod or str(ms_get_instance_id(mod, obj) or '') != sid:
                    stale = True
                    continue
                key = (str(getattr(obj, 'name', '') or ''), str(getattr(mod, 'name', '') or ''))
                if key[0] and key[1] and key not in seen:
                    seen.add(key)
                    pairs.append((obj, mod))
            except Exception:
                stale = True
        if len(pairs) > 1:
            resolved[sid] = pairs
    if stale and mark_stale:
        _ms_modifier_instance_cache_mark_dirty()
    return resolved, stale


def ms_get_object_instance_id(obj) -> str:
    if not obj:
        return ""
    try:
        return str(obj.get(_MS_OBJECT_INSTANCE_KEY, "") or "")
    except Exception:
        return ""


def ms_set_object_instance_id(obj, group_id) -> None:
    if not obj:
        return
    gid = str(group_id or "")
    changed = False
    try:
        old_gid = str(obj.get(_MS_OBJECT_INSTANCE_KEY, "") or "")
    except Exception:
        old_gid = ""
    try:
        if gid:
            obj[_MS_OBJECT_INSTANCE_KEY] = gid
        elif _MS_OBJECT_INSTANCE_KEY in obj.keys():
            del obj[_MS_OBJECT_INSTANCE_KEY]
        changed = (old_gid != gid)
    except Exception:
        pass
    if changed:
        _ms_object_instance_cache_mark_dirty()


def ms_clear_object_instance_id(obj) -> None:
    if not obj:
        return
    changed = False
    try:
        if _MS_OBJECT_INSTANCE_KEY in obj.keys():
            del obj[_MS_OBJECT_INSTANCE_KEY]
            changed = True
    except Exception:
        pass
    try:
        if _MS_OBJECT_INSTANCE_SIG_KEY in obj.keys():
            del obj[_MS_OBJECT_INSTANCE_SIG_KEY]
    except Exception:
        pass
    if changed:
        _ms_object_instance_cache_mark_dirty()


def _ms_modifier_unique_owner(mod):
    try:
        owner = getattr(mod, 'id_data', None)
        if owner is not None and hasattr(owner, 'modifiers'):
            return owner
    except Exception:
        pass
    return None


def _ms_load_object_instance_unique_mod_map(obj) -> dict:
    if obj is None:
        return {}
    try:
        raw = obj.get(_MS_OBJECT_INSTANCE_UNIQUE_MOD_MAP_KEY, {})
    except Exception:
        raw = {}
    if isinstance(raw, dict):
        return {str(k): bool(v) for k, v in raw.items()}
    if isinstance(raw, str) and raw:
        try:
            val = json.loads(raw)
            if isinstance(val, dict):
                return {str(k): bool(v) for k, v in val.items()}
        except Exception:
            pass
    return {}


def _ms_store_object_instance_unique_mod_map(obj, data: dict) -> None:
    if obj is None:
        return
    clean = {str(k): bool(v) for k, v in (data or {}).items() if str(k) and bool(v)}
    try:
        if clean:
            obj[_MS_OBJECT_INSTANCE_UNIQUE_MOD_MAP_KEY] = json.dumps(clean, ensure_ascii=False, sort_keys=True)
        else:
            try:
                if _MS_OBJECT_INSTANCE_UNIQUE_MOD_MAP_KEY in obj.keys():
                    del obj[_MS_OBJECT_INSTANCE_UNIQUE_MOD_MAP_KEY]
            except Exception:
                pass
    except Exception:
        pass


def _ms_modifier_set_object_instance_unique(mod, state=True) -> None:
    if not mod:
        return
    stored_on_modifier = False
    try:
        if state:
            mod[_MS_OBJECT_INSTANCE_UNIQUE_MOD_KEY] = True
            stored_on_modifier = True
        elif hasattr(mod, 'keys') and _MS_OBJECT_INSTANCE_UNIQUE_MOD_KEY in mod.keys():
            del mod[_MS_OBJECT_INSTANCE_UNIQUE_MOD_KEY]
            stored_on_modifier = True
    except Exception:
        pass
    # Blender 5.1 modifiers can reject ID properties.  Keep an object-side map
    # so object-instance synchronization can still identify rows that should not
    # be propagated to every base-object instance.
    try:
        owner = _ms_modifier_unique_owner(mod)
        name = str(getattr(mod, 'name', '') or '')
        if owner is not None and name:
            mapping = _ms_load_object_instance_unique_mod_map(owner)
            if state:
                mapping[name] = True
            else:
                mapping.pop(name, None)
            _ms_store_object_instance_unique_mod_map(owner, mapping)
    except Exception:
        pass


def _ms_modifier_is_object_instance_unique(mod) -> bool:
    if not mod:
        return False
    try:
        return bool(mod.get(_MS_OBJECT_INSTANCE_UNIQUE_MOD_KEY, False))
    except Exception:
        pass
    try:
        owner = _ms_modifier_unique_owner(mod)
        name = str(getattr(mod, 'name', '') or '')
        if owner is not None and name:
            return bool(_ms_load_object_instance_unique_mod_map(owner).get(name, False))
    except Exception:
        pass
    return False


def ms_iter_object_instance_members(group_id, context=None):
    gid = str(group_id or "")
    if not gid:
        return
    for obj in _ms_object_instance_group_members_from_cache(gid, context=context):
        yield obj


def ms_get_object_instance_members(obj, context=None):
    gid = ms_get_object_instance_id(obj)
    if not gid:
        return []
    return list(ms_iter_object_instance_members(gid, context=context))



def ms_object_has_linked_base_instance(obj, context=None) -> bool:
    """Return True when the Base Object row represents a linked object instance.

    Smart Modifier object-instance copies are tracked with an object-instance ID,
    while Blender-native linked duplicates can share the same object data without
    that ID.  The Base Object row should show an instance mark for either case.
    """
    if not obj:
        return False
    try:
        gid = ms_get_object_instance_id(obj)
        if gid:
            members = [m for m in ms_iter_object_instance_members(gid, context=context) if m is not None]
            if len(members) > 1:
                return True
    except Exception:
        pass
    try:
        data = getattr(obj, 'data', None)
        if data is None:
            return False
        try:
            if int(getattr(data, 'users', 0) or 0) <= 1:
                return False
        except Exception:
            pass
        try:
            objects = list((context.scene.objects if context is not None and hasattr(context, 'scene') else bpy.data.objects) or [])
        except Exception:
            objects = list(getattr(bpy.data, 'objects', []) or [])
        count = 0
        for other in objects:
            try:
                if other is not None and getattr(other, 'data', None) is data:
                    count += 1
                    if count > 1:
                        return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def ms_cleanup_object_instance_group_after_release(group_id, context=None) -> None:
    """Normalize a Smart Modifier object-instance group after selected members leave it."""
    gid = str(group_id or '')
    if not gid:
        return
    try:
        _ms_object_instance_cache_mark_dirty()
    except Exception:
        pass
    try:
        members = [m for m in ms_iter_object_instance_members(gid, context=context) if m is not None]
    except Exception:
        members = []
    if len(members) >= 2:
        try:
            ms_mark_object_instance_targets_synced(members, context=context)
        except Exception:
            pass
        try:
            ms_sync_object_instance_modifier_additions(context, force=True)
        except Exception:
            pass
        try:
            ms_sync_all_instance_groups(context, prefer_active=True, force=True)
        except Exception:
            pass
        return
    if len(members) == 1:
        obj = members[0]
        try:
            ms_clear_object_instance_id(obj)
        except Exception:
            pass
        seen_iids = set()
        try:
            for mod in list(getattr(obj, 'modifiers', ()) or []):
                try:
                    iid = str(ms_get_instance_id(mod, obj) or '')
                    if iid and iid not in seen_iids:
                        seen_iids.add(iid)
                        ms_instance_post_remove_cleanup(iid, context=context)
                    _ms_modifier_set_object_instance_unique(mod, False)
                except Exception:
                    continue
        except Exception:
            pass
        try:
            obj.update_tag()
        except Exception:
            pass


def ms_expand_targets_for_object_instance_groups(targets, context=None):
    """Expand selected add-modifier targets to all object-instance members."""
    out = []
    seen = set()
    try:
        source = list(targets or [])
    except Exception:
        source = []
    for obj in source:
        if not obj:
            continue
        try:
            name = str(getattr(obj, 'name', '') or '')
        except Exception:
            name = ''
        if name and name not in seen:
            seen.add(name)
            out.append(obj)
        gid = ms_get_object_instance_id(obj)
        if not gid:
            continue
        for member in ms_iter_object_instance_members(gid, context=context):
            try:
                mname = str(getattr(member, 'name', '') or '')
            except Exception:
                mname = ''
            if mname and mname not in seen:
                seen.add(mname)
                out.append(member)
    return out


def _ms_object_instance_stack_signature(obj) -> str:
    try:
        mods = list(getattr(obj, 'modifiers', ()) or [])
    except Exception:
        mods = []
    data = []
    for mod in mods:
        try:
            data.append({
                'name': str(getattr(mod, 'name', '') or ''),
                'type': str(getattr(mod, 'type', '') or ''),
                'iid': str(ms_get_instance_id(mod, obj) or ''),
                'unique': bool(_ms_modifier_is_object_instance_unique(mod)),
            })
        except Exception:
            pass
    try:
        return json.dumps(data, sort_keys=True, ensure_ascii=False)
    except Exception:
        return str(data)


def ms_mark_object_instance_targets_synced(targets, context=None) -> int:
    changed = 0
    try:
        objs = list(targets or [])
    except Exception:
        objs = []
    for obj in objs:
        try:
            if obj and ms_get_object_instance_id(obj):
                sig = _ms_object_instance_stack_signature(obj)
                if str(obj.get(_MS_OBJECT_INSTANCE_SIG_KEY, '') or '') != sig:
                    obj[_MS_OBJECT_INSTANCE_SIG_KEY] = sig
                    changed += 1
        except Exception:
            pass
    return changed


def _ms_choose_object_instance_master(members, context=None, prefer_obj=None):
    live = [o for o in (members or []) if o and ms_object_has_modifier_collection(o)]
    if not live:
        return None
    if prefer_obj in live:
        return prefer_obj
    try:
        active = get_main_object(getattr(context, 'active_object', None)) if context else None
    except Exception:
        active = None
    if active in live:
        try:
            max_count = max(len(getattr(o, 'modifiers', ()) or []) for o in live)
            if len(getattr(active, 'modifiers', ()) or []) >= max_count:
                return active
        except Exception:
            return active
    try:
        return max(live, key=lambda o: len(getattr(o, 'modifiers', ()) or []))
    except Exception:
        return live[0]


def _ms_find_matching_modifier_for_object_instance(obj, src_mod, src_index):
    if not obj or not src_mod or not ms_object_has_modifier_collection(obj):
        return None
    try:
        mods = list(obj.modifiers)
    except Exception:
        mods = []
    try:
        if 0 <= int(src_index) < len(mods):
            candidate = mods[int(src_index)]
            if getattr(candidate, 'type', '') == getattr(src_mod, 'type', ''):
                return candidate
    except Exception:
        pass
    try:
        candidate = obj.modifiers.get(getattr(src_mod, 'name', ''))
        if candidate and getattr(candidate, 'type', '') == getattr(src_mod, 'type', ''):
            return candidate
    except Exception:
        pass
    return None


def ms_group_object_instance_modifier_stacks(group_id, context=None, prefer_obj=None, force=False):
    """Make all object-instance members share equivalent Smart Modifier instance IDs."""
    global _MS_OBJECT_INSTANCE_SYNC_LOCK
    if _MS_OBJECT_INSTANCE_SYNC_LOCK:
        return 0
    gid = str(group_id or "")
    if not gid:
        return 0
    members = [o for o in ms_iter_object_instance_members(gid, context=context) if ms_object_has_modifier_collection(o)]
    if len(members) < 2:
        ms_mark_object_instance_targets_synced(members, context=context)
        return 0
    master = _ms_choose_object_instance_master(members, context=context, prefer_obj=prefer_obj)
    if not master:
        return 0
    changed = 0
    _MS_OBJECT_INSTANCE_SYNC_LOCK = True
    try:
        master_mods = list(getattr(master, 'modifiers', ()) or [])
        for index, src_mod in enumerate(master_mods):
            if _ms_modifier_is_object_instance_unique(src_mod):
                continue
            try:
                iid = ms_get_instance_id(src_mod, master) or uuid.uuid4().hex
                src_name = str(getattr(src_mod, 'name', '') or '')
                logical_name = ms_get_logical_modifier_name(master, src_mod) or src_name
                if ms_obj_set_instance_id(master, src_name, iid, disp_name=logical_name):
                    changed += 1
                if ms_obj_set_disp_name(master, src_name, logical_name):
                    changed += 1
            except Exception:
                continue
            for obj in members:
                if obj == master or not ms_object_has_modifier_collection(obj):
                    continue
                try:
                    dst_mod = _ms_find_matching_modifier_for_object_instance(obj, src_mod, index)
                    if dst_mod is None:
                        dst_mod = obj.modifiers.new(name=src_name or logical_name or 'Modifier', type=getattr(src_mod, 'type', ''))
                        changed += 1
                    if dst_mod is None or _ms_modifier_is_object_instance_unique(dst_mod):
                        continue
                    try:
                        safe_move_modifier(obj, dst_mod.name, index)
                    except Exception:
                        pass
                    try:
                        ms_copy_modifier_settings(src_mod, dst_mod, include_name=False, skip_display_flags=True)
                    except Exception:
                        pass
                    try:
                        src_vp, src_rd, src_edit, src_cage = _ms_get_modifier_manual_display_for_sync(master, src_mod, context=context)
                        if _ms_set_modifier_display_state_for_instance_sync(obj, dst_mod, viewport=src_vp, render=src_rd, editmode=src_edit, cage=src_cage, context=context):
                            changed += 1
                    except Exception:
                        pass
                    try:
                        if ms_obj_set_disp_name(obj, dst_mod.name, logical_name):
                            changed += 1
                        if ms_obj_set_instance_id(obj, dst_mod.name, iid, disp_name=logical_name):
                            changed += 1
                        _ms_modifier_set_object_instance_unique(dst_mod, False)
                        obj.update_tag()
                    except Exception:
                        pass
                except Exception:
                    continue
        ms_mark_object_instance_targets_synced(members, context=context)
    finally:
        _MS_OBJECT_INSTANCE_SYNC_LOCK = False
    if changed:
        try:
            _ms_modifier_instance_cache_mark_dirty()
            ms_refresh_instance_sync_subscriptions(context)
        except Exception:
            pass
    return changed


def ms_sync_object_instance_modifier_additions(context=None, *, force=False):
    """Detect native/Python modifier additions on one object instance and mirror them."""
    if _MS_OBJECT_INSTANCE_SYNC_LOCK:
        return 0
    try:
        cache = _ms_object_instance_group_cache(context)
        group_ids = tuple(cache.keys()) if isinstance(cache, dict) else ()
    except Exception:
        group_ids = ()
    changed = 0
    for gid in group_ids:
        members = [obj for obj in _ms_object_instance_group_members_from_cache(gid, context=context) if obj and ms_object_has_modifier_collection(obj)]
        if len(members) < 2:
            changed += int(ms_mark_object_instance_targets_synced(members, context=context) or 0)
            continue
        need = bool(force)
        counts = []
        for obj in members:
            try:
                mods = list(getattr(obj, 'modifiers', ()) or [])
                counts.append(len(mods))
                prev = str(obj.get(_MS_OBJECT_INSTANCE_SIG_KEY, '') or '')
                cur = _ms_object_instance_stack_signature(obj)
                if cur != prev:
                    need = True
                for mod in mods:
                    if not _ms_modifier_is_object_instance_unique(mod) and not ms_get_instance_id(mod, obj):
                        need = True
            except Exception:
                pass
        if counts and min(counts) != max(counts):
            need = True
        if not need:
            continue
        master = _ms_choose_object_instance_master(members, context=context, prefer_obj=None)
        try:
            changed += int(ms_group_object_instance_modifier_stacks(gid, context=context, prefer_obj=master, force=True) or 0)
        except Exception:
            pass
    return changed


# -----------------------------------------------------------------------------
# Generic object / asset support for the Modifier Stack UI
# -----------------------------------------------------------------------------
# The stack UI is no longer mesh-only.  Mesh-only edit helpers still keep their
# explicit MESH guards, but the generic list/base-data/property/instance UI must
# accept every object type Blender can place in a scene.
_MS_STACK_OBJECT_TYPES = {
    'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES',
    'POINTCLOUD', 'VOLUME', 'GREASEPENCIL', 'GPENCIL',
    'ARMATURE', 'LATTICE', 'EMPTY', 'IMAGE',
    'LIGHT', 'LIGHT_PROBE', 'LIGHTPROBE', 'CAMERA', 'SPEAKER',
}


def ms_object_supports_modifier_stack(obj) -> bool:
    """Return True for any live scene object Smart Modifier can list.

    Some object types do not have a native Blender modifier collection, but they
    still have an Object Data tab and user-editable data.  They therefore appear
    in the stack with a Base Object row and a data/property body, while modifier
    add/instance actions are disabled or safely skipped when Blender does not
    expose Object.modifiers for that type.
    """
    if obj is None:
        return False
    try:
        name = str(getattr(obj, 'name', '') or '')
        if not name:
            return False
    except Exception:
        return False
    try:
        if bpy.data.objects.get(name) is not obj:
            return False
    except Exception:
        pass
    try:
        typ = str(getattr(obj, 'type', '') or '')
        if typ in _MS_STACK_OBJECT_TYPES:
            return True
        # Collection instances, image empties and force fields are all EMPTY in
        # Blender, but keep these fallbacks for future object-type changes.
        if getattr(obj, 'instance_collection', None) is not None:
            return True
        if getattr(obj, 'field', None) is not None:
            return True
        if getattr(obj, 'data', None) is not None:
            return True
    except Exception:
        pass
    return False


def ms_object_has_modifier_collection(obj) -> bool:
    if not ms_object_supports_modifier_stack(obj):
        return False
    try:
        mods = getattr(obj, 'modifiers', None)
        if mods is None:
            return False
        # Accessing length catches invalid RNA wrappers without mutating data.
        len(mods)
        return True
    except Exception:
        return False


def ms_get_object_modifiers(obj):
    try:
        stack_obj = ms_get_modifier_stack_object(obj, context=None, create=False) if 'ms_get_modifier_stack_object' in globals() else obj
    except Exception:
        stack_obj = obj
    if not ms_object_has_modifier_collection(stack_obj):
        return ()
    try:
        out = []
        for mod in tuple(getattr(stack_obj, 'modifiers', ()) or ()):
            try:
                if 'ms_modifier_is_internal_stack_helper' in globals() and ms_modifier_is_internal_stack_helper(mod):
                    continue
            except Exception:
                pass
            out.append(mod)
        return tuple(out)
    except Exception:
        return ()



# -----------------------------------------------------------------------------
# Shape / Curve mesh-stack bridge
# -----------------------------------------------------------------------------
# Mesh-only stack levels for Curve/Font/Surface style shape objects are carried
# by a generated mesh proxy.  The original shape stays editable and non-
# destructive; mesh modifiers are evaluated on the proxy after a Geometry Nodes
# converter that reads the source shape and turns it into mesh geometry.
_MS_SHAPE_STACK_TYPES = {'CURVE', 'FONT', 'SURFACE'}
_MS_SHAPE_PROXY_SOURCE_KEY = 'ms_shape_mesh_proxy_source'
_MS_SHAPE_PROXY_OBJECT_KEY = 'ms_shape_mesh_proxy_object'
_MS_SHAPE_PROXY_CONVERTER_KEY = 'ms_shape_curve_mesh_converter'
_MS_SHAPE_PROXY_INTERNAL_KEY = 'ms_shape_proxy_internal'
_MS_SHAPE_PROXY_LINK_ID_KEY = 'ms_shape_mesh_proxy_link_id'
_MS_SHAPE_PROXY_SOURCE_ID_KEY = 'ms_shape_mesh_proxy_source_id'
_MS_SHAPE_PROXY_OBJECT_ID_KEY = 'ms_shape_mesh_proxy_object_id'


def ms_is_shape_source_object(obj) -> bool:
    try:
        return bool(obj is not None and str(getattr(obj, 'type', '') or '') in _MS_SHAPE_STACK_TYPES)
    except Exception:
        return False


def ms_is_shape_mesh_proxy(obj) -> bool:
    try:
        return bool(obj is not None and hasattr(obj, 'get') and obj.get(_MS_SHAPE_PROXY_SOURCE_KEY))
    except Exception:
        return False


def _ms_shape_ensure_link_id(source_obj=None, proxy_obj=None, *, create=False) -> str:
    link_id = ''
    for obj in (source_obj, proxy_obj):
        try:
            value = str(obj.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or '') if obj is not None and hasattr(obj, 'get') else ''
        except Exception:
            value = ''
        if value:
            link_id = value
            break
    if not link_id and create:
        try:
            link_id = uuid.uuid4().hex
        except Exception:
            link_id = str(time.time())
    if link_id:
        for obj in (source_obj, proxy_obj):
            try:
                if obj is not None and hasattr(obj, '__setitem__'):
                    obj[_MS_SHAPE_PROXY_LINK_ID_KEY] = link_id
            except Exception:
                pass
    return link_id


def _ms_shape_proxy_matches_source(proxy_obj, source_obj) -> bool:
    if proxy_obj is None or source_obj is None or not ms_is_shape_mesh_proxy(proxy_obj):
        return False
    try:
        if not ms_is_shape_source_object(source_obj):
            return False
    except Exception:
        return False
    try:
        if str(proxy_obj.get(_MS_SHAPE_PROXY_SOURCE_KEY, '') or '') == str(getattr(source_obj, 'name', '') or ''):
            return True
    except Exception:
        pass
    try:
        sid = str(source_obj.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or '')
        pid = str(proxy_obj.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or '')
        if sid and pid and sid == pid:
            return True
    except Exception:
        pass
    try:
        source_id = str(source_obj.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '')
        proxy_source_id = str(proxy_obj.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '')
        if source_id and proxy_source_id and source_id == proxy_source_id:
            return True
    except Exception:
        pass
    return False


def _ms_shape_stamp_proxy_link(source_obj, proxy_obj, *, create_id=True):
    if source_obj is None or proxy_obj is None:
        return
    link_id = _ms_shape_ensure_link_id(source_obj, proxy_obj, create=create_id)
    try:
        if not str(source_obj.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '') and create_id:
            source_obj[_MS_SHAPE_PROXY_SOURCE_ID_KEY] = uuid.uuid4().hex
    except Exception:
        pass
    try:
        source_id = str(source_obj.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '')
    except Exception:
        source_id = ''
    try:
        proxy_obj[_MS_SHAPE_PROXY_SOURCE_KEY] = source_obj.name
        proxy_obj[_MS_SHAPE_PROXY_SOURCE_ID_KEY] = source_id
        proxy_obj[_MS_SHAPE_PROXY_INTERNAL_KEY] = True
        if link_id:
            proxy_obj[_MS_SHAPE_PROXY_LINK_ID_KEY] = link_id
    except Exception:
        pass
    try:
        source_obj[_MS_SHAPE_PROXY_OBJECT_KEY] = proxy_obj.name
        source_obj[_MS_SHAPE_PROXY_OBJECT_ID_KEY] = str(proxy_obj.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or link_id or '')
        if link_id:
            source_obj[_MS_SHAPE_PROXY_LINK_ID_KEY] = link_id
    except Exception:
        pass


def ms_shape_proxy_source(obj):
    if not ms_is_shape_mesh_proxy(obj):
        return None
    try:
        source_name = str(obj.get(_MS_SHAPE_PROXY_SOURCE_KEY) or '')
        if source_name:
            source = bpy.data.objects.get(source_name)
            if source is not None and ms_is_shape_source_object(source):
                try:
                    _ms_shape_stamp_proxy_link(source, obj, create_id=False)
                except Exception:
                    pass
                return source
    except Exception:
        pass
    try:
        link_id = str(obj.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or '')
        source_id = str(obj.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '')
        for cand in bpy.data.objects:
            if not ms_is_shape_source_object(cand):
                continue
            try:
                if link_id and str(cand.get(_MS_SHAPE_PROXY_LINK_ID_KEY, '') or '') == link_id:
                    _ms_shape_stamp_proxy_link(cand, obj, create_id=False)
                    return cand
            except Exception:
                pass
            try:
                if source_id and str(cand.get(_MS_SHAPE_PROXY_SOURCE_ID_KEY, '') or '') == source_id:
                    _ms_shape_stamp_proxy_link(cand, obj, create_id=False)
                    return cand
            except Exception:
                pass
            try:
                if str(cand.get(_MS_SHAPE_PROXY_OBJECT_KEY, '') or '') == str(getattr(obj, 'name', '') or ''):
                    _ms_shape_stamp_proxy_link(cand, obj, create_id=False)
                    return cand
            except Exception:
                pass
    except Exception:
        pass
    return None


def _ms_shape_proxy_unique_name(base: str) -> str:
    base = str(base or 'SMS Shape Mesh')
    try:
        if bpy.data.objects.get(base) is None:
            return base
        i = 1
        while True:
            name = f"{base}.{i:03d}"
            if bpy.data.objects.get(name) is None:
                return name
            i += 1
    except Exception:
        return base


def _ms_modifier_is_shape_converter(mod) -> bool:
    try:
        if mod is None:
            return False
        try:
            if hasattr(mod, 'get') and bool(mod.get(_MS_SHAPE_PROXY_CONVERTER_KEY)):
                return True
        except Exception:
            pass
        try:
            ng = getattr(mod, 'node_group', None)
            if ng is not None:
                try:
                    if hasattr(ng, 'get') and bool(ng.get(_MS_SHAPE_PROXY_CONVERTER_KEY)):
                        return True
                except Exception:
                    pass
                try:
                    if str(getattr(ng, 'name', '') or '').startswith('SMS Curve To Mesh'):
                        return True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            name = str(getattr(mod, 'name', '') or '')
            if name in {'Curve to Mesh via Geometry Nodes', 'ジオメトリノードでカーブを読み込み・メッシュ化'}:
                return True
        except Exception:
            pass
    except Exception:
        pass
    return False


def _ms_socket_by_name(sockets, names, fallback_index=0):
    if isinstance(names, str):
        names = (names,)
    try:
        for name in names:
            try:
                sock = sockets.get(name)
                if sock is not None:
                    return sock
            except Exception:
                pass
            try:
                for sock in sockets:
                    if str(getattr(sock, 'name', '') or '') == str(name) or str(getattr(sock, 'identifier', '') or '') == str(name):
                        return sock
            except Exception:
                pass
        try:
            return sockets[int(fallback_index)]
        except Exception:
            return None
    except Exception:
        return None


def _ms_add_gn_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry'):
    try:
        return group.interface.new_socket(name=str(name), in_out=str(in_out), socket_type=str(socket_type))
    except Exception:
        pass
    try:
        col = group.outputs if str(in_out).upper() == 'OUTPUT' else group.inputs
        return col.new(str(socket_type), str(name))
    except Exception:
        return None


def _ms_shape_make_curve_to_mesh_group(source_obj, context=None):
    src_name = str(getattr(source_obj, 'name', '') or 'Shape')
    group_name = _ms_shape_proxy_unique_name(f"SMS Curve To Mesh - {src_name}")
    try:
        group = bpy.data.node_groups.new(group_name, 'GeometryNodeTree')
        try:
            group.is_modifier = True
        except Exception:
            pass
        try:
            group.nodes.clear()
        except Exception:
            pass
        _ms_add_gn_interface_socket(group, name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
        nodes = group.nodes
        links = group.links
        out = nodes.new('NodeGroupOutput')
        try:
            out.is_active_output = True
        except Exception:
            pass
        out.location = (360, 0)
        info = nodes.new('GeometryNodeObjectInfo')
        info.location = (-640, 70)
        try:
            _ms_socket_by_name(info.inputs, ('Object',), 0).default_value = source_obj
        except Exception:
            pass
        try:
            as_instance = _ms_socket_by_name(info.inputs, ('As Instance',), 1)
            if as_instance is not None:
                as_instance.default_value = False
        except Exception:
            pass
        curve_to_mesh = nodes.new('GeometryNodeCurveToMesh')
        curve_to_mesh.location = (-120, 0)
        circle = nodes.new('GeometryNodeCurvePrimitiveCircle')
        circle.location = (-420, -170)
        try:
            radius = 0.01
            data = getattr(source_obj, 'data', None)
            bd = float(getattr(data, 'bevel_depth', 0.0) or 0.0) if data is not None else 0.0
            if bd > 0.0:
                radius = max(0.0001, bd)
            _ms_socket_by_name(circle.inputs, ('Radius',), 4).default_value = radius
        except Exception:
            pass
        try:
            _ms_socket_by_name(circle.inputs, ('Resolution',), 0).default_value = 8
        except Exception:
            pass
        try:
            fill = _ms_socket_by_name(curve_to_mesh.inputs, ('Fill Caps',), 3)
            if fill is not None:
                fill.default_value = True
        except Exception:
            pass
        try:
            links.new(_ms_socket_by_name(info.outputs, ('Geometry',), 3), _ms_socket_by_name(curve_to_mesh.inputs, ('Curve',), 0))
            links.new(_ms_socket_by_name(circle.outputs, ('Curve',), 0), _ms_socket_by_name(curve_to_mesh.inputs, ('Profile Curve',), 1))
            links.new(_ms_socket_by_name(curve_to_mesh.outputs, ('Mesh', 'Geometry'), 0), _ms_socket_by_name(out.inputs, ('Geometry',), 0))
        except Exception:
            try:
                links.new(_ms_socket_by_name(info.outputs, ('Geometry',), 3), _ms_socket_by_name(out.inputs, ('Geometry',), 0))
            except Exception:
                pass
        try:
            group[_MS_SHAPE_PROXY_CONVERTER_KEY] = True
            group[_MS_SHAPE_PROXY_INTERNAL_KEY] = True
        except Exception:
            pass
        return group
    except Exception:
        return None


def _ms_shape_link_proxy_to_source_collections(source_obj, proxy_obj):
    try:
        linked = False
        for col in list(getattr(source_obj, 'users_collection', []) or []):
            try:
                if proxy_obj.name not in col.objects:
                    col.objects.link(proxy_obj)
                linked = True
            except Exception:
                pass
        if not linked:
            try:
                bpy.context.collection.objects.link(proxy_obj)
            except Exception:
                pass
    except Exception:
        try:
            bpy.context.collection.objects.link(proxy_obj)
        except Exception:
            pass


def _ms_shape_sync_proxy_transform(source_obj, proxy_obj):
    try:
        proxy_obj.matrix_world = source_obj.matrix_world.copy()
    except Exception:
        try:
            proxy_obj.location = source_obj.location
            proxy_obj.rotation_euler = source_obj.rotation_euler
            proxy_obj.scale = source_obj.scale
        except Exception:
            pass
    try:
        proxy_obj.hide_select = bool(getattr(source_obj, 'hide_select', False))
    except Exception:
        pass


def ms_shape_refresh_proxy_mesh_data(source_obj, proxy_obj, context=None):
    """Refresh the proxy's base mesh datablock from the current shape.

    The internal Geometry Nodes converter remains the evaluated, non-destructive
    source of the final stack geometry.  The base mesh snapshot is kept in sync
    so legacy/custom operators that read Object.bound_box or mesh data before
    modifiers still behave like they do on a normal mesh object.
    """
    if source_obj is None or proxy_obj is None:
        return False
    try:
        if getattr(proxy_obj, 'type', '') != 'MESH' or not ms_is_shape_source_object(source_obj):
            return False
    except Exception:
        return False
    try:
        mode = str(getattr(proxy_obj, 'mode', '') or '')
        if mode != 'OBJECT':
            return False
    except Exception:
        pass
    try:
        if context is not None and getattr(context, 'edit_object', None) == proxy_obj:
            return False
    except Exception:
        pass
    new_mesh = None
    try:
        depsgraph = context.evaluated_depsgraph_get() if context is not None else bpy.context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    try:
        eval_obj = source_obj.evaluated_get(depsgraph) if depsgraph is not None else source_obj
    except Exception:
        eval_obj = source_obj
    try:
        if hasattr(bpy.data.meshes, 'new_from_object'):
            try:
                new_mesh = bpy.data.meshes.new_from_object(eval_obj, depsgraph=depsgraph)
            except TypeError:
                new_mesh = bpy.data.meshes.new_from_object(eval_obj)
    except Exception:
        new_mesh = None
    if new_mesh is None:
        return False
    try:
        new_mesh.name = _ms_shape_proxy_unique_name(f"{source_obj.name}_SMS_MeshData")
    except Exception:
        pass
    old_mesh = None
    try:
        old_mesh = proxy_obj.data
    except Exception:
        old_mesh = None
    try:
        proxy_obj.data = new_mesh
        try:
            proxy_obj[_MS_SHAPE_PROXY_INTERNAL_KEY] = True
        except Exception:
            pass
        try:
            if old_mesh is not None and old_mesh != new_mesh and int(getattr(old_mesh, 'users', 0) or 0) <= 0:
                bpy.data.meshes.remove(old_mesh)
        except Exception:
            pass
        return True
    except Exception:
        try:
            if new_mesh is not None and int(getattr(new_mesh, 'users', 0) or 0) <= 0:
                bpy.data.meshes.remove(new_mesh)
        except Exception:
            pass
    return False


def _ms_shape_find_converter(proxy_obj):
    try:
        for mod in proxy_obj.modifiers:
            if _ms_modifier_is_shape_converter(mod):
                return mod
    except Exception:
        pass
    return None


def _ms_shape_ensure_converter(source_obj, proxy_obj, context=None):
    mod = _ms_shape_find_converter(proxy_obj)
    if mod is None:
        label = _sms_choose_text('Curve to Mesh via Geometry Nodes', 'ジオメトリノードでカーブを読み込み・メッシュ化', context=context)
        try:
            mod = proxy_obj.modifiers.new(name=label, type='NODES')
        except Exception:
            mod = None
        if mod is not None:
            try:
                mod[_MS_SHAPE_PROXY_CONVERTER_KEY] = True
                mod[_MS_SHAPE_PROXY_INTERNAL_KEY] = True
            except Exception:
                pass
    if mod is not None:
        try:
            if getattr(mod, 'type', '') == 'NODES' and getattr(mod, 'node_group', None) is None:
                mod.node_group = _ms_shape_make_curve_to_mesh_group(source_obj, context=context)
        except Exception:
            pass
        try:
            mod.show_viewport = True
            if hasattr(mod, 'show_render'):
                mod.show_render = True
            if hasattr(mod, 'show_in_editmode'):
                mod.show_in_editmode = True
        except Exception:
            pass
        try:
            idx = proxy_obj.modifiers.find(mod.name)
            if idx > 0:
                safe_move_modifier(proxy_obj, mod.name, 0)
        except Exception:
            pass
    return mod


def _ms_shape_copy_modifier_state(src_obj, src_mod, dst_obj, dst_mod):
    if not src_obj or not src_mod or not dst_obj or not dst_mod:
        return
    try:
        ms_copy_modifier_settings(src_mod, dst_mod, include_name=False)
    except Exception:
        pass
    try:
        disp = ms_obj_get_disp_name(src_obj, src_mod.name) or src_mod.name
        ms_obj_set_disp_name(dst_obj, dst_mod.name, disp)
    except Exception:
        pass
    try:
        set_mod_enabled_state(dst_obj, dst_mod.name, get_mod_enabled_state(src_obj, src_mod.name))
    except Exception:
        pass
    try:
        set_mod_viewport_state(dst_obj, dst_mod.name, get_mod_viewport_state(src_obj, src_mod.name))
    except Exception:
        pass
    try:
        if hasattr(dst_mod, 'show_render'):
            set_mod_render_state(dst_obj, dst_mod.name, get_mod_render_state(src_obj, src_mod.name))
    except Exception:
        pass
    try:
        iid = ms_get_instance_id(src_mod, src_obj)
        if iid:
            ms_obj_set_instance_id(dst_obj, dst_mod.name, iid, disp_name=(ms_obj_get_disp_name(src_obj, src_mod.name) or src_mod.name))
    except Exception:
        pass


def _ms_shape_migrate_source_modifiers(source_obj, proxy_obj, context=None):
    if not source_obj or not proxy_obj:
        return
    try:
        mods = [m for m in list(getattr(source_obj, 'modifiers', []) or []) if not _ms_modifier_is_shape_converter(m)]
    except Exception:
        mods = []
    if not mods:
        return
    existing = {m.name for m in getattr(proxy_obj, 'modifiers', []) or []}
    active_name = ''
    try:
        active_name = str(source_obj.get('ui_active_item', '') or '')
    except Exception:
        active_name = ''
    for src_mod in mods:
        dst_mod = None
        try:
            if src_mod.name in existing:
                dst_mod = proxy_obj.modifiers.get(src_mod.name)
            if dst_mod is None:
                dst_mod = proxy_obj.modifiers.new(name=src_mod.name, type=getattr(src_mod, 'type', ''))
            if dst_mod is not None:
                _ms_shape_copy_modifier_state(source_obj, src_mod, proxy_obj, dst_mod)
                existing.add(dst_mod.name)
        except Exception:
            dst_mod = None
    try:
        for src_mod in mods:
            try:
                source_obj.modifiers.remove(src_mod)
            except Exception:
                pass
    except Exception:
        pass
    try:
        if active_name and active_name != 'BASE' and proxy_obj.modifiers.get(active_name):
            source_obj['ui_active_item'] = active_name
            ms_set_ui_active_index(source_obj, proxy_obj.modifiers.find(active_name))
        else:
            source_obj['ui_active_item'] = 'BASE'
            ms_set_ui_active_index(source_obj, -1)
    except Exception:
        pass


def ms_shape_get_mesh_proxy(source_obj, context=None, create=False, migrate=True):
    if ms_is_shape_mesh_proxy(source_obj):
        return source_obj
    if not ms_is_shape_source_object(source_obj):
        return None
    proxy = None
    try:
        _ms_shape_ensure_link_id(source_obj, None, create=bool(create))
    except Exception:
        pass
    try:
        name = str(source_obj.get(_MS_SHAPE_PROXY_OBJECT_KEY, '') or '')
        if name:
            cand = bpy.data.objects.get(name)
            if cand and ms_is_shape_mesh_proxy(cand) and _ms_shape_proxy_matches_source(cand, source_obj):
                proxy = cand
    except Exception:
        proxy = None
    if proxy is None:
        try:
            for cand in bpy.data.objects:
                if _ms_shape_proxy_matches_source(cand, source_obj):
                    proxy = cand
                    break
        except Exception:
            proxy = None
    if proxy is None and not create:
        return None
    if proxy is None:
        try:
            mesh = bpy.data.meshes.new(_ms_shape_proxy_unique_name(f"{source_obj.name}_SMS_MeshData"))
            proxy = bpy.data.objects.new(_ms_shape_proxy_unique_name(f"{source_obj.name}_SMS_CurveMesh"), mesh)
            _ms_shape_stamp_proxy_link(source_obj, proxy, create_id=True)
            _ms_shape_link_proxy_to_source_collections(source_obj, proxy)
        except Exception:
            proxy = None
    if proxy is None:
        return None
    try:
        _ms_shape_stamp_proxy_link(source_obj, proxy, create_id=True)
    except Exception:
        pass
    try:
        _ms_shape_link_proxy_to_source_collections(source_obj, proxy)
    except Exception:
        pass
    _ms_shape_sync_proxy_transform(source_obj, proxy)
    try:
        ms_shape_refresh_proxy_mesh_data(source_obj, proxy, context=context)
    except Exception:
        pass
    _ms_shape_ensure_converter(source_obj, proxy, context=context)
    if migrate:
        _ms_shape_migrate_source_modifiers(source_obj, proxy, context=context)
    return proxy


def ms_resolve_modifier_add_targets(targets, context=None, *, create_shape_proxies=True, migrate=True):
    """Return stack objects that should receive newly added modifiers.

    Curve/Font/Surface source objects keep their visible/editable shape data on
    the source, but mesh-only stack entries must be created on the persistent
    mesh proxy.  This helper normalizes standard and custom modifier add paths
    to the same target set without changing the caller's selection.
    """
    out = []
    seen = set()
    for obj in (targets or []):
        try:
            main = get_main_object(obj) or obj
        except Exception:
            main = obj
        target = main
        try:
            if ms_is_shape_source_object(main):
                proxy = ms_shape_get_mesh_proxy(main, context=context, create=bool(create_shape_proxies), migrate=bool(migrate))
                if proxy is not None:
                    target = proxy
        except Exception:
            target = main
        try:
            name = str(getattr(target, 'name', '') or '')
        except Exception:
            name = ''
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(target)
    return out


def ms_original_sources_for_stack_targets(targets):
    out = []
    seen = set()
    for obj in (targets or []):
        source = None
        try:
            if ms_is_shape_mesh_proxy(obj):
                source = ms_shape_proxy_source(obj)
        except Exception:
            source = None
        if source is None:
            try:
                source = get_main_object(obj) or obj
            except Exception:
                source = obj
        try:
            name = str(getattr(source, 'name', '') or '')
        except Exception:
            name = ''
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(source)
    return out


def ms_get_modifier_stack_object(main_obj, context=None, create=False):
    if main_obj is None:
        return None
    try:
        if ms_is_shape_mesh_proxy(main_obj):
            return main_obj
        if ms_is_shape_source_object(main_obj):
            # Sweep is a true curve-domain Geometry Nodes stack row. Keep it on
            # the editable source curve instead of replacing that curve with the
            # mesh-only compatibility proxy used by other shape modifiers.
            if any(bool(mod.get('sms_curve_source_modifier', False)) for mod in main_obj.modifiers):
                return main_obj
            proxy = ms_shape_get_mesh_proxy(main_obj, context=context, create=create, migrate=True)
            return proxy if proxy is not None else main_obj
    except Exception:
        pass
    return main_obj



# -----------------------------------------------------------------------------
# Stale shape-proxy data cleanup
# -----------------------------------------------------------------------------
# The generated *_SMS_CurveMesh objects are behavior-relevant only while their
# original Curve/Font/Surface source object still exists.  Older builds could
# leave those proxies, their converter node groups, and source-side ID-property
# links behind after the source object was deleted or after a regular mesh was
# converted back to a normal object.  The cleanup below removes only data owned
# by this bridge and never touches user meshes, UVW gizmos, or other helpers that
# are still referenced by a live modifier.
_MS_SHAPE_PROXY_CLEANUP_ARMED_KEY = "_MS_SHAPE_PROXY_CLEANUP_ARMED_V1"
_MS_SHAPE_PROXY_CLEANUP_REQ_KEY = "_MS_SHAPE_PROXY_CLEANUP_REQ_V1"
_MS_SHAPE_PROXY_CLEANUP_LAST_T_KEY = "_MS_SHAPE_PROXY_CLEANUP_LAST_T_V1"
_MS_SHAPE_PROXY_MAINTENANCE_KEY = "_MS_SHAPE_PROXY_MAINTENANCE_ENABLED_V1"
_MS_SHAPE_PROXY_MAINTENANCE_LAST_T_KEY = "_MS_SHAPE_PROXY_MAINTENANCE_LAST_T_V1"
_MS_SHAPE_PROXY_KEYS_ALL = (
    _MS_SHAPE_PROXY_SOURCE_KEY,
    _MS_SHAPE_PROXY_OBJECT_KEY,
    _MS_SHAPE_PROXY_INTERNAL_KEY,
    _MS_SHAPE_PROXY_LINK_ID_KEY,
    _MS_SHAPE_PROXY_SOURCE_ID_KEY,
    _MS_SHAPE_PROXY_OBJECT_ID_KEY,
)
_MS_SHAPE_PROXY_SOURCE_LINK_KEYS = (
    _MS_SHAPE_PROXY_OBJECT_KEY,
    _MS_SHAPE_PROXY_OBJECT_ID_KEY,
)


def _ms_idprop_has(obj, key) -> bool:
    try:
        return bool(obj is not None and hasattr(obj, 'keys') and key in obj)
    except Exception:
        return False


def _ms_idprop_pop(obj, key) -> bool:
    try:
        if obj is not None and hasattr(obj, 'keys') and key in obj:
            del obj[key]
            return True
    except Exception:
        try:
            obj.pop(key, None)
            return True
        except Exception:
            pass
    return False


def _ms_shape_proxy_has_any_key(obj) -> bool:
    try:
        if obj is None or not hasattr(obj, 'keys'):
            return False
        return any(key in obj for key in _MS_SHAPE_PROXY_KEYS_ALL)
    except Exception:
        return False


def _ms_shape_proxy_is_owned_proxy_object(obj) -> bool:
    """Return True only for generated mesh proxy objects owned by this bridge."""
    if obj is None:
        return False
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        name = ''
    try:
        if bool(obj.get(_MS_SHAPE_PROXY_INTERNAL_KEY, False)) and bool(obj.get(_MS_SHAPE_PROXY_SOURCE_KEY, '')):
            return True
    except Exception:
        pass
    try:
        if getattr(obj, 'type', '') == 'MESH' and bool(obj.get(_MS_SHAPE_PROXY_SOURCE_KEY, '')) and '_SMS_CurveMesh' in name:
            return True
    except Exception:
        pass
    return False


def _ms_shape_proxy_collect_internal_node_groups(proxy_obj):
    groups = []
    try:
        for mod in list(getattr(proxy_obj, 'modifiers', []) or []):
            if not _ms_modifier_is_shape_converter(mod):
                continue
            try:
                group = getattr(mod, 'node_group', None)
            except Exception:
                group = None
            if group is None:
                continue
            try:
                if bool(group.get(_MS_SHAPE_PROXY_CONVERTER_KEY, False)) or bool(group.get(_MS_SHAPE_PROXY_INTERNAL_KEY, False)) or str(getattr(group, 'name', '') or '').startswith('SMS Curve To Mesh'):
                    groups.append(group)
            except Exception:
                try:
                    if str(getattr(group, 'name', '') or '').startswith('SMS Curve To Mesh'):
                        groups.append(group)
                except Exception:
                    pass
    except Exception:
        pass
    return groups


def _ms_shape_proxy_remove_object(proxy_obj, report=None) -> bool:
    if proxy_obj is None:
        return False
    report = report if isinstance(report, dict) else {}
    try:
        name = str(getattr(proxy_obj, 'name', '') or '')
    except Exception:
        name = ''
    if not _ms_shape_proxy_is_owned_proxy_object(proxy_obj):
        return False
    node_groups = _ms_shape_proxy_collect_internal_node_groups(proxy_obj)
    try:
        data = getattr(proxy_obj, 'data', None)
    except Exception:
        data = None
    try:
        bpy.data.objects.remove(proxy_obj, do_unlink=True)
        try:
            report.setdefault('removed_objects', []).append(name)
        except Exception:
            pass
    except Exception:
        try:
            for col in list(getattr(proxy_obj, 'users_collection', []) or []):
                try:
                    col.objects.unlink(proxy_obj)
                except Exception:
                    pass
            bpy.data.objects.remove(proxy_obj)
            try:
                report.setdefault('removed_objects', []).append(name)
            except Exception:
                pass
        except Exception:
            return False
    try:
        if data is not None and int(getattr(data, 'users', 0) or 0) <= 0:
            data_name = str(getattr(data, 'name', '') or '')
            bpy.data.meshes.remove(data)
            try:
                report.setdefault('removed_meshes', []).append(data_name)
            except Exception:
                pass
    except Exception:
        pass
    for group in list(node_groups or []):
        try:
            if group is not None and int(getattr(group, 'users', 0) or 0) <= 0:
                group_name = str(getattr(group, 'name', '') or '')
                bpy.data.node_groups.remove(group)
                try:
                    report.setdefault('removed_node_groups', []).append(group_name)
                except Exception:
                    pass
        except Exception:
            pass
    return True


def _ms_shape_proxy_valid_source_for_proxy(proxy_obj):
    try:
        source = ms_shape_proxy_source(proxy_obj)
    except Exception:
        source = None
    try:
        if source is None or not ms_is_shape_source_object(source):
            return None
        if not _ms_shape_proxy_matches_source(proxy_obj, source):
            return None
        return source
    except Exception:
        return None


def _ms_shape_proxy_clear_stale_reference_props(obj, keys, report=None) -> int:
    count = 0
    for key in keys:
        if _ms_idprop_pop(obj, key):
            count += 1
    if count and isinstance(report, dict):
        try:
            report.setdefault('cleared_props', []).append((str(getattr(obj, 'name', '') or ''), int(count)))
        except Exception:
            pass
    return count


def _ms_shape_proxy_cleanup_orphan_meshes_and_groups(report=None):
    report = report if isinstance(report, dict) else {}
    try:
        for mesh in list(getattr(bpy.data, 'meshes', []) or []):
            try:
                if int(getattr(mesh, 'users', 0) or 0) != 0:
                    continue
                name = str(getattr(mesh, 'name', '') or '')
                if '_SMS_MeshData' not in name:
                    continue
                bpy.data.meshes.remove(mesh)
                report.setdefault('removed_meshes', []).append(name)
            except Exception:
                pass
    except Exception:
        pass
    try:
        for group in list(getattr(bpy.data, 'node_groups', []) or []):
            try:
                if int(getattr(group, 'users', 0) or 0) != 0:
                    continue
                name = str(getattr(group, 'name', '') or '')
                owned = name.startswith('SMS Curve To Mesh')
                try:
                    owned = owned or bool(group.get(_MS_SHAPE_PROXY_CONVERTER_KEY, False)) or bool(group.get(_MS_SHAPE_PROXY_INTERNAL_KEY, False))
                except Exception:
                    pass
                if not owned:
                    continue
                bpy.data.node_groups.remove(group)
                report.setdefault('removed_node_groups', []).append(name)
            except Exception:
                pass
    except Exception:
        pass


def ms_cleanup_stale_shape_proxy_data(context=None, *, force=False):
    """Remove stale Smart Modifier shape-proxy objects and obsolete link props.

    This is intentionally narrow: it removes only generated mesh proxies whose
    Curve/Font/Surface source can no longer be resolved, and it clears proxy-link
    ID properties from regular mesh objects where those properties have no active
    behavior.  Live shape-source/proxy pairs are kept intact.
    """
    report = {
        'removed_objects': [],
        'removed_meshes': [],
        'removed_node_groups': [],
        'cleared_props': [],
    }
    try:
        if not force:
            delay = _ms_defer_data_cleanup_delay()
            if delay:
                report['deferred'] = float(delay)
                return report
    except Exception:
        pass
    try:
        proxies_to_remove = []
        for obj in list(getattr(bpy.data, 'objects', []) or []):
            try:
                if _ms_shape_proxy_is_owned_proxy_object(obj):
                    source = _ms_shape_proxy_valid_source_for_proxy(obj)
                    if source is None:
                        proxies_to_remove.append(obj)
                    continue

                if not _ms_shape_proxy_has_any_key(obj):
                    continue

                if not ms_is_shape_source_object(obj):
                    # Shape-proxy properties on normal mesh/user objects are legacy
                    # residue.  They are not used by the current bridge and can
                    # cause new proxies to be matched to unrelated objects.
                    _ms_shape_proxy_clear_stale_reference_props(obj, _MS_SHAPE_PROXY_KEYS_ALL, report)
                    continue

                # Shape source: keep stable link/source ids only while a matching
                # proxy exists.  Remove stale object-name links when the object no
                # longer exists or no longer matches this source.
                proxy_name = ''
                try:
                    proxy_name = str(obj.get(_MS_SHAPE_PROXY_OBJECT_KEY, '') or '')
                except Exception:
                    proxy_name = ''
                if proxy_name:
                    proxy = bpy.data.objects.get(proxy_name)
                    if not (proxy is not None and _ms_shape_proxy_is_owned_proxy_object(proxy) and _ms_shape_proxy_matches_source(proxy, obj)):
                        _ms_shape_proxy_clear_stale_reference_props(obj, _MS_SHAPE_PROXY_SOURCE_LINK_KEYS, report)
            except Exception:
                continue

        removed_proxy_names = []
        for proxy in list(proxies_to_remove):
            try:
                removed_proxy_names.append(str(getattr(proxy, 'name', '') or ''))
                _ms_shape_proxy_remove_object(proxy, report)
            except Exception:
                pass

        # Clear source-side links that point at just-removed/missing proxies.
        try:
            removed_set = set(n for n in removed_proxy_names if n)
            for obj in list(getattr(bpy.data, 'objects', []) or []):
                try:
                    pname = str(obj.get(_MS_SHAPE_PROXY_OBJECT_KEY, '') or '') if hasattr(obj, 'get') else ''
                except Exception:
                    pname = ''
                if not pname:
                    continue
                proxy = bpy.data.objects.get(pname)
                if pname in removed_set or proxy is None or not (_ms_shape_proxy_is_owned_proxy_object(proxy) and ms_is_shape_source_object(obj) and _ms_shape_proxy_matches_source(proxy, obj)):
                    _ms_shape_proxy_clear_stale_reference_props(obj, _MS_SHAPE_PROXY_SOURCE_LINK_KEYS if ms_is_shape_source_object(obj) else _MS_SHAPE_PROXY_KEYS_ALL, report)
        except Exception:
            pass

        _ms_shape_proxy_cleanup_orphan_meshes_and_groups(report)
        try:
            _ms_cleanup_empty_system_collections()
        except Exception:
            pass
    except Exception:
        pass
    try:
        report['removed_object_count'] = len(report.get('removed_objects') or [])
        report['removed_mesh_count'] = len(report.get('removed_meshes') or [])
        report['removed_node_group_count'] = len(report.get('removed_node_groups') or [])
        report['cleared_prop_object_count'] = len(report.get('cleared_props') or [])
        report['cleared_prop_count'] = sum(int(item[1]) for item in (report.get('cleared_props') or []) if isinstance(item, (tuple, list)) and len(item) >= 2)
    except Exception:
        pass
    return report


def ms_shape_proxy_names():
    return {obj.name for obj in bpy.data.objects if ms_is_shape_mesh_proxy(obj)}


def ms_discard_unused_shape_proxies(known_proxy_names):
    """Remove proxies created after known_proxy_names that received no modifier."""
    report = {}
    removed = set()
    for proxy in list(bpy.data.objects):
        if proxy.name in known_proxy_names or not ms_is_shape_mesh_proxy(proxy):
            continue
        if any(not _ms_modifier_is_shape_converter(mod) for mod in proxy.modifiers):
            continue
        removed.add(proxy.name)
        _ms_shape_proxy_remove_object(proxy, report)
    if removed:
        for obj in bpy.data.objects:
            if str(obj.get(_MS_SHAPE_PROXY_OBJECT_KEY, '') or '') in removed:
                _ms_shape_proxy_clear_stale_reference_props(obj, _MS_SHAPE_PROXY_SOURCE_LINK_KEYS, report)
        _ms_shape_proxy_cleanup_orphan_meshes_and_groups(report)
    return removed


def _ms_shape_proxy_cleanup_timer():
    try:
        dn = _ms__dn()
        delay = _ms_defer_data_cleanup_delay()
        if delay:
            return delay
        report = ms_cleanup_stale_shape_proxy_data(getattr(bpy, 'context', None), force=True)
        try:
            dn['_MS_SHAPE_PROXY_LAST_REPORT_V1'] = report
            dn[_MS_SHAPE_PROXY_CLEANUP_LAST_T_KEY] = time.time()
        except Exception:
            pass
    except Exception:
        pass
    try:
        _ms__dn().pop(_MS_SHAPE_PROXY_CLEANUP_ARMED_KEY, None)
    except Exception:
        pass
    return None


def ms_request_shape_proxy_cleanup(reason='', *, force=False):
    """Request one safe cleanup pass for stale generated shape proxies."""
    try:
        dn = _ms__dn()
        now = time.time()
        if not force:
            last = float(dn.get(_MS_SHAPE_PROXY_CLEANUP_LAST_T_KEY, 0.0) or 0.0)
            if last and (now - last) < 1.50:
                return False
        dn[_MS_SHAPE_PROXY_CLEANUP_REQ_KEY] = str(reason or '')
        if not dn.get(_MS_SHAPE_PROXY_CLEANUP_ARMED_KEY):
            dn[_MS_SHAPE_PROXY_CLEANUP_ARMED_KEY] = True
            bpy.app.timers.register(_ms_shape_proxy_cleanup_timer, first_interval=0.20 if force else 0.60)
        return True
    except Exception:
        return False


def _ms_shape_proxy_maintenance_timer():
    """Terminate legacy periodic proxy scans."""
    try:
        _ms__dn().pop(_MS_SHAPE_PROXY_MAINTENANCE_KEY, None)
    except Exception:
        pass
    return None


def ms_register_shape_proxy_cleanup_maintenance():
    """Install event-driven proxy cleanup with no recurring idle scan.

    Load, save, undo/redo, object-count changes, and proxy operators request
    one safe cleanup pass.  Registration performs one initial pass only.
    """
    try:
        dn = _ms__dn()
        dn.pop(_MS_SHAPE_PROXY_MAINTENANCE_KEY, None)
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_ms_shape_proxy_maintenance_timer):
            timers.unregister(_ms_shape_proxy_maintenance_timer)
    except Exception:
        pass
    try:
        return bool(ms_request_shape_proxy_cleanup('register_cleanup', force=True))
    except Exception:
        return False


def ms_unregister_shape_proxy_cleanup_maintenance():
    try:
        dn = _ms__dn()
        dn.pop(_MS_SHAPE_PROXY_MAINTENANCE_KEY, None)
        dn.pop(_MS_SHAPE_PROXY_CLEANUP_ARMED_KEY, None)
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_ms_shape_proxy_maintenance_timer):
            timers.unregister(_ms_shape_proxy_maintenance_timer)
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_ms_shape_proxy_cleanup_timer):
            timers.unregister(_ms_shape_proxy_cleanup_timer)
    except Exception:
        pass

def ms_modifier_is_internal_stack_helper(mod) -> bool:
    return _ms_modifier_is_shape_converter(mod)


def ms_iter_visible_stack_modifiers(obj, context=None):
    stack_obj = ms_get_modifier_stack_object(obj, context=context, create=False) or obj
    if not ms_object_has_modifier_collection(stack_obj):
        return ()
    out = []
    try:
        for mod in getattr(stack_obj, 'modifiers', []) or []:
            if ms_modifier_is_internal_stack_helper(mod):
                continue
            out.append(mod)
    except Exception:
        pass
    return tuple(out)


def ms_shape_user_insert_index(obj, base_index=0):
    try:
        if ms_is_shape_mesh_proxy(obj) or (obj and hasattr(obj, 'get') and obj.get(_MS_SHAPE_PROXY_SOURCE_KEY)):
            conv = _ms_shape_find_converter(obj)
            if conv is not None:
                cidx = obj.modifiers.find(conv.name)
                try:
                    return max(int(base_index), int(cidx) + 1)
                except Exception:
                    return int(cidx) + 1
    except Exception:
        pass
    try:
        return int(base_index)
    except Exception:
        return 0


def ms_shape_sync_visibility_for_active(main_obj, context=None, active_id=None):
    if not ms_is_shape_source_object(main_obj):
        return None
    try:
        if any(bool(mod.get('sms_curve_source_modifier', False)) for mod in main_obj.modifiers):
            _ms_set_obj_hidden(main_obj, False, False)
            proxy = ms_shape_get_mesh_proxy(main_obj, context=context, create=False, migrate=False)
            if proxy is not None:
                _ms_set_obj_hidden(proxy, True, True)
            return main_obj
    except Exception:
        pass
    proxy = ms_shape_get_mesh_proxy(main_obj, context=context, create=bool(active_id and active_id != 'BASE'), migrate=True)
    if proxy is None:
        return None
    _ms_shape_sync_proxy_transform(main_obj, proxy)
    try:
        ms_shape_refresh_proxy_mesh_data(main_obj, proxy, context=context)
    except Exception:
        pass
    is_mesh_side = bool(active_id and active_id != 'BASE')
    try:
        if is_mesh_side:
            _ms_set_obj_hidden(main_obj, True, True)
            _ms_set_obj_hidden(proxy, False, False)
        else:
            _ms_set_obj_hidden(main_obj, False, False)
            _ms_set_obj_hidden(proxy, True, True)
    except Exception:
        pass
    return proxy if is_mesh_side else main_obj


def ms_get_selected_stack_objects(context):
    out = []
    seen = set()
    try:
        sel = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        sel = []
    # Prefer the ViewLayer active object and process it first.  This prevents the
    # stack UI from continuing to use a previously selected mesh when the user
    # switches to a curve/font/surface/Geometry Nodes object and Blender's
    # selected_objects order still starts with the old mesh.
    try:
        vl_active = getattr(getattr(getattr(context, "view_layer", None), "objects", None), "active", None)
    except Exception:
        vl_active = None
    try:
        ao = vl_active or getattr(context, "active_object", None)
        if ao:
            if ao in sel:
                sel.remove(ao)
                sel.insert(0, ao)
            else:
                mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")
                if mode.startswith("EDIT"):
                    sel.insert(0, ao)
                else:
                    try:
                        if getattr(ao, "select_get", lambda: False)():
                            sel.insert(0, ao)
                    except Exception:
                        pass
    except Exception:
        pass
    for o in sel:
        try:
            mo = get_main_object(o) or o
        except Exception:
            mo = o
        if mo and ms_object_supports_modifier_stack(mo):
            try:
                key = str(getattr(mo, 'name', '') or '')
            except Exception:
                key = ''
            if key and key not in seen:
                seen.add(key)
                out.append(mo)
    return out


def ms_get_selected_mesh_mains(context):
    return [o for o in ms_get_selected_stack_objects(context) if getattr(o, 'type', '') == 'MESH']


def ms_get_selected_main_meshes(context):
    # Compatibility alias retained for existing stack call sites.  The generic
    # Modifier Stack now supports all scene object/data types; mesh-only subtools
    # must call ms_get_selected_mesh_mains() or keep explicit MESH guards.
    return ms_get_selected_stack_objects(context)


def ms_is_multi_mode(context):
    return len(ms_get_selected_stack_objects(context)) > 1


def ms_iter_instance_members(instance_id, context=None):
    if not instance_id: return
    iid = str(instance_id)
    groups = _ms_modifier_instance_group_cache(context)
    items = groups.get(iid) if isinstance(groups, dict) else None
    if items is None:
        groups = _ms_modifier_instance_group_cache(context, force=True)
        items = groups.get(iid) if isinstance(groups, dict) else ()
    resolved, stale = _ms_resolve_modifier_instance_groups({iid: items}, mark_stale=True)
    if stale:
        groups = _ms_modifier_instance_group_cache(context, force=True)
        items = groups.get(iid) if isinstance(groups, dict) else ()
        resolved, stale = _ms_resolve_modifier_instance_groups({iid: items}, mark_stale=False)
    for obj, mod in resolved.get(iid, []):
        yield obj, mod

def ms_instance_post_remove_cleanup(instance_id, context=None):
    if not instance_id: return
    iid = str(instance_id)
    try:
        _ms_modifier_instance_cache_mark_dirty()
    except Exception:
        pass
    members = []
    seen = set()
    try:
        objs = list((context.scene.objects if context and hasattr(context, 'scene') else bpy.data.objects) or [])
    except Exception:
        objs = list(getattr(bpy.data, 'objects', []) or [])
    for o in objs:
        try:
            if not o or not ms_object_has_modifier_collection(o):
                continue
            ms_obj_cleanup_instance_map(o)
            for m in getattr(o, 'modifiers', []) or []:
                try:
                    if str(ms_get_instance_id(m, o) or "") != iid:
                        continue
                    key = (str(getattr(o, 'name', '') or ''), str(getattr(m, 'name', '') or ''))
                    if key in seen:
                        continue
                    seen.add(key)
                    members.append((o, m))
                except Exception:
                    continue
        except Exception:
            continue
    if len(members) == 1:
        o, m = members[0]
        disp_name = ""
        try:
            disp_name = ms_get_logical_modifier_name(o, m) or getattr(m, "name", "") or ""
        except Exception:
            disp_name = ""
        ms_obj_clear_instance_id(o, m.name)
        if disp_name:
            try:
                ms_obj_set_disp_name(o, m.name, disp_name)
            except Exception:
                pass
        ms_obj_cleanup_instance_map(o)
        ms_normalize_default_modifier_names(o, getattr(m, "type", ""))

def _ms_instance_internal_idprop(key: str) -> bool:
    """True for Smart Modifier bookkeeping keys that must not synchronize."""
    sk = str(key or '')
    if not sk:
        return True
    if sk in {'_RNA_UI', _MS_INSTANCE_KEY, '_ms_instance_last_source_sig', '_ms_instance_group_sig'}:
        return True
    # Keep per-object helper/linkage values local.  Custom modifier settings that
    # are intended to sync use non-internal ID-property names or plugin-managed
    # hooks (for example UVW Map / Unwrap UVW / Max-library parameter blocks).
    lowered = sk.lower()
    if lowered.startswith(('ep_', 'sl_', '_ep_', '_sl_')):
        return True
    if lowered.startswith('_ms_') and lowered not in {'_ms_enabled', '_ms_viewport_enabled'}:
        return True
    return False


def _ms_fingerprint_value(value, _depth=0):
    """Return a JSON-safe identity for RNA/ID-property values.

    The signature intentionally records ID datablock pointers by type/name instead
    of stringifying only scalar values, so Boolean.object, Shrinkwrap.target,
    Displace.texture, GeometryNodes.node_group and similar pointer changes are
    detected and can drive instance synchronization.
    """
    if _depth > 3:
        return '<depth>'
    try:
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
    except Exception:
        pass
    try:
        if isinstance(value, set):
            return sorted([_ms_fingerprint_value(v, _depth + 1) for v in value], key=str)
    except Exception:
        pass
    try:
        if isinstance(value, dict):
            return {str(k): _ms_fingerprint_value(v, _depth + 1) for k, v in sorted(value.items(), key=lambda it: str(it[0]))}
    except Exception:
        pass
    try:
        if isinstance(value, bpy.types.ID):
            lib = getattr(getattr(value, 'library', None), 'filepath', '') or ''
            return {'ID': str(value.__class__.__name__), 'name': str(getattr(value, 'name_full', getattr(value, 'name', '')) or ''), 'library': str(lib)}
    except Exception:
        pass
    try:
        # bpy_prop_array, Vector, Color, Matrix, IDPropertyArray, enum flag arrays.
        if hasattr(value, '__len__') and not isinstance(value, (bytes, bytearray)):
            return [_ms_fingerprint_value(value[i], _depth + 1) for i in range(len(value))]
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return '<unrepr>'


def _ms_copyable_value(value):
    """Return a safe value for RNA/ID-property synchronization."""
    try:
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
    except Exception:
        pass
    try:
        if isinstance(value, bpy.types.ID):
            # Pointer properties should share the same target datablock, just like
            # a 3ds Max instanced modifier shares reference parameters.
            return value
    except Exception:
        pass
    try:
        if isinstance(value, set):
            return set(value)
    except Exception:
        pass
    try:
        if isinstance(value, dict):
            return {str(k): _ms_copyable_value(v) for k, v in value.items()}
    except Exception:
        pass
    try:
        if isinstance(value, (list, tuple)):
            return [_ms_copyable_value(v) for v in value]
    except Exception:
        pass
    try:
        if hasattr(value, '__len__') and not isinstance(value, (bytes, bytearray)):
            return [_ms_copyable_value(value[i]) for i in range(len(value))]
    except Exception:
        pass
    try:
        return copy.copy(value)
    except Exception:
        try:
            return copy.deepcopy(value)
        except Exception:
            return value


def _ms_set_rna_value(dst_mod, identifier, value):
    try:
        setattr(dst_mod, identifier, value)
        return True
    except Exception:
        pass
    try:
        if isinstance(value, list):
            setattr(dst_mod, identifier, tuple(value))
            return True
    except Exception:
        pass
    try:
        current = getattr(dst_mod, identifier)
        if hasattr(current, '__len__') and isinstance(value, (list, tuple)):
            for i, v in enumerate(value):
                try:
                    current[i] = v
                except Exception:
                    pass
            return True
    except Exception:
        pass
    return False


def _ms_modifier_sync_signature(mod):
    """Compact signature for Max-style modifier-instance synchronization."""
    if not mod:
        return ''
    data = {'type': str(getattr(mod, 'type', '') or '')}
    try:
        props = {}
        skip_props = _ms_get_modifier_skip_copy_props(mod)
        # Modifier-instance synchronization intentionally keeps per-object row
        # names local.  Including RNA "name" in the sync signature makes two
        # already-synchronized modifiers with different local names look dirty
        # forever, which causes the idle sync timer to rewrite and re-render.
        skip_props.add('name')
        # Realtime/Render flags are normalized below from Smart Modifier's manual
        # backups.  Reading raw RNA here would treat Modifier Auto Disable's
        # temporary OFF as an instance-setting change and propagate it to every
        # linked modifier.
        skip_props.update({'show_viewport', 'show_render', 'show_in_editmode', 'show_on_cage'})
        for prop in mod.bl_rna.properties:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in {'rna_type', 'type', 'id_data'} or ident in skip_props:
                continue
            # Read-only props are ignored except the visibility/status fields that
            # are explicitly handled outside the RNA iterator.
            try:
                if bool(getattr(prop, 'is_readonly', False)):
                    continue
            except Exception:
                pass
            try:
                props[ident] = _ms_fingerprint_value(getattr(mod, ident))
            except Exception:
                pass
        try:
            owner = _ms_modifier_unique_owner(mod)
        except Exception:
            owner = None
        try:
            vp_state, render_state, editmode_state, cage_state = _ms_get_modifier_manual_display_for_sync(owner, mod)
            props['show_viewport'] = _ms_fingerprint_value(bool(vp_state))
            if hasattr(mod, 'show_render'):
                props['show_render'] = _ms_fingerprint_value(bool(render_state))
            if hasattr(mod, 'show_in_editmode'):
                props['show_in_editmode'] = _ms_fingerprint_value(bool(editmode_state))
            if hasattr(mod, 'show_on_cage'):
                props['show_on_cage'] = _ms_fingerprint_value(bool(cage_state))
        except Exception:
            pass
        data['props'] = props
    except Exception:
        pass
    try:
        idp = {}
        if hasattr(mod, 'keys'):
            skip_props = _ms_get_modifier_skip_copy_props(mod)
            for k in mod.keys():
                sk = str(k)
                if _ms_instance_internal_idprop(sk) or sk in skip_props:
                    continue
                try:
                    idp[sk] = _ms_fingerprint_value(mod.get(k))
                except Exception:
                    pass
        data['idprops'] = idp
    except Exception:
        pass
    try:
        return json.dumps(data, sort_keys=True, ensure_ascii=False, default=str)
    except Exception:
        return str(data)


def _ms_get_modifier_skip_copy_props(mod):
    skip = {'rna_type', 'type', 'id_data', 'persistent_uid'}
    try:
        if str(getattr(mod, 'type', '') or '') == 'BUILD' and not bool(getattr(mod, 'use_random_order', False)):
            # Blender 5.1 can create Build modifiers with seed=0 although the RNA
            # setter clamps user-written values to >=1.  When random order is off
            # the seed is not functionally used, so excluding it prevents false
            # instance desync while preserving seed sync once random order is enabled.
            skip.add('seed')
    except Exception:
        pass
    try:
        p = ms_find_plugin_for_modifier(mod)
        if p and callable(p.get('get_skip_copy_props')):
            extra = p.get('get_skip_copy_props')(mod)
            if extra:
                skip.update(str(v) for v in extra)
    except Exception:
        pass
    return skip


def ms_copy_modifier_settings(src_mod, dst_mod, include_name=False, skip_display_flags=False):
    """Copy a modifier's parameter block to another modifier.

    This is the core of the 3ds Max style virtual instancing model.  Blender
    stores a separate Modifier RNA instance per object; this function copies every
    writable user-facing value that Blender accepts, including pointer parameters
    and Geometry Nodes socket ID-properties, while preserving per-object helper
    references requested by plugin skip hooks.
    """
    if not src_mod or not dst_mod:
        return
    skip_props = _ms_get_modifier_skip_copy_props(src_mod)
    try:
        skip_props.update(_ms_get_modifier_skip_copy_props(dst_mod))
    except Exception:
        pass
    if not include_name:
        skip_props.add('name')
    if bool(skip_display_flags):
        # Instance sync handles these through Smart Modifier manual backups so
        # Auto Disable's temporary OFF does not become a shared instance state.
        skip_props.update({'show_viewport', 'show_render', 'show_in_editmode', 'show_on_cage'})
    try:
        for prop in src_mod.bl_rna.properties:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in skip_props:
                continue
            try:
                if bool(getattr(prop, 'is_readonly', False)):
                    continue
            except Exception:
                pass
            try:
                value = _ms_copyable_value(getattr(src_mod, ident))
            except Exception:
                continue
            _ms_set_rna_value(dst_mod, ident, value)
    except Exception:
        pass
    # Visibility/header values are not always included in the regular property
    # loop depending on Blender's RNA flags, so copy them explicitly.
    for ident in ('show_render', 'show_viewport', 'show_in_editmode', 'show_on_cage'):
        if ident in skip_props:
            continue
        try:
            setattr(dst_mod, ident, getattr(src_mod, ident))
        except Exception:
            pass
    try:
        if hasattr(src_mod, 'keys') and hasattr(dst_mod, 'keys'):
            for k in src_mod.keys():
                sk = str(k)
                if _ms_instance_internal_idprop(sk) or sk in skip_props:
                    continue
                try:
                    dst_mod[sk] = _ms_copyable_value(src_mod.get(k))
                except Exception:
                    pass
            # Remove stale synced ID-properties that are no longer present on the
            # source.  Keep private/internal/helper properties local.
            for k in list(dst_mod.keys()):
                sk = str(k)
                if _ms_instance_internal_idprop(sk) or sk in skip_props:
                    continue
                try:
                    if sk not in src_mod.keys():
                        del dst_mod[sk]
                except Exception:
                    pass
    except Exception:
        pass
    if include_name and dst_mod.name != src_mod.name:
        try:
            dst_mod.name = src_mod.name
        except Exception:
            pass


def ms_sync_instance_group_from(src_obj, src_mod, context=None):
    global _MS_INST_SYNC_LOCK
    if _MS_INST_SYNC_LOCK or not src_obj or not src_mod:
        return 0
    iid = ms_get_instance_id(src_mod, src_obj)
    if not iid:
        return 0
    changed = 0
    _MS_INST_SYNC_LOCK = True
    try:
        src_plugin = ms_find_plugin_for_modifier(src_mod)
        try:
            source_viewport_state, source_render_state, source_editmode_state, source_cage_state = _ms_get_modifier_manual_display_for_sync(src_obj, src_mod, context=context)
        except Exception:
            source_viewport_state, source_render_state, source_editmode_state, source_cage_state = True, True, False, False
        try:
            if _ms_set_modifier_display_state_for_instance_sync(src_obj, src_mod, viewport=source_viewport_state, render=source_render_state, editmode=source_editmode_state, cage=source_cage_state, context=context):
                changed += 1
        except Exception:
            pass
        try:
            source_enabled_state = bool(get_mod_enabled_state(src_obj, src_mod.name))
        except Exception:
            source_enabled_state = True
        source_sig = _ms_modifier_sync_signature(src_mod)
        for obj, mod in ms_iter_instance_members(iid, context=context):
            if obj == src_obj and mod == src_mod:
                continue
            try:
                target_sig = _ms_modifier_sync_signature(mod)
            except Exception:
                target_sig = ''
            if source_sig and target_sig == source_sig:
                try:
                    if _ms_set_modifier_last_source_sig(obj, mod, source_sig, iid):
                        changed += 1
                except Exception:
                    pass
                try:
                    if _ms_set_modifier_display_state_for_instance_sync(obj, mod, viewport=source_viewport_state, render=source_render_state, editmode=source_editmode_state, cage=source_cage_state, context=context):
                        changed += 1
                    if set_mod_enabled_state(obj, mod.name, source_enabled_state):
                        changed += 1
                except Exception:
                    pass
                continue
            old_name = mod.name
            ms_copy_modifier_settings(src_mod, mod, include_name=False, skip_display_flags=True)
            changed += 1
            try:
                if source_sig:
                    _ms_set_modifier_last_source_sig(obj, mod, source_sig, iid)
            except Exception:
                pass
            if old_name != mod.name:
                ms_obj_rename_instance_key(obj, old_name, mod.name)
            if ms_obj_set_instance_id(obj, mod.name, iid):
                changed += 1
            try:
                if _ms_set_modifier_display_state_for_instance_sync(obj, mod, viewport=source_viewport_state, render=source_render_state, editmode=source_editmode_state, cage=source_cage_state, context=context):
                    changed += 1
                if set_mod_enabled_state(obj, mod.name, source_enabled_state):
                    changed += 1
            except Exception:
                pass
            ms_obj_cleanup_instance_map(obj)
            try:
                target_plugin = ms_find_plugin_for_modifier(mod) or src_plugin
                hook = target_plugin.get('after_instance_sync') if target_plugin else None
                if callable(hook):
                    hook(src_obj, src_mod, obj, mod, context)
            except Exception:
                pass
            try:
                obj.update_tag()
            except Exception:
                pass
        try:
            if source_sig and _ms_set_modifier_last_source_sig(src_obj, src_mod, source_sig, iid):
                changed += 1
        except Exception:
            pass
    finally:
        _MS_INST_SYNC_LOCK = False
    return changed


def ms_collect_instance_groups(context=None):
    groups = _ms_modifier_instance_group_cache(context)
    resolved, stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=True)
    if stale:
        groups = _ms_modifier_instance_group_cache(context, force=True)
        resolved, stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=False)
    return resolved

def ms_sync_all_instance_groups(context=None, *, prefer_active=True, force=False):
    """Synchronize virtual modifier-instance groups only when a member changes.

    The idle timer must not write source markers or backup ID-properties on every
    pass.  Doing so invalidates the viewport and restarts active render previews.
    """
    if _MS_INST_SYNC_LOCK:
        return 0
    groups = ms_collect_instance_groups(context)
    if not groups:
        return 0
    try:
        active_obj = get_main_object(getattr(context, 'active_object', None)) if context else None
    except Exception:
        active_obj = None
    changed = 0
    for iid, pairs in groups.items():
        live_pairs = [(obj, mod) for obj, mod in (pairs or []) if obj is not None and mod is not None]
        if not live_pairs:
            continue
        active_pair = None
        if prefer_active and active_obj:
            try:
                active_mod = getattr(active_obj.modifiers, 'active', None)
                if active_mod:
                    for obj, mod in live_pairs:
                        if obj == active_obj and mod == active_mod:
                            active_pair = (obj, mod)
                            break
            except Exception:
                active_pair = None

        dirty_pairs = []
        for obj, mod in live_pairs:
            try:
                sig = _ms_modifier_sync_signature(mod)
            except Exception:
                sig = ''
            try:
                prev = _ms_get_modifier_last_source_sig(obj, mod, iid)
            except Exception:
                prev = ''
            if force or (sig and sig != prev):
                dirty_pairs.append((obj, mod, sig, prev))

        source = None
        if force:
            source = active_pair or ((dirty_pairs[0][0], dirty_pairs[0][1]) if dirty_pairs else live_pairs[0])
        elif active_pair is not None:
            try:
                active_sig = _ms_modifier_sync_signature(active_pair[1])
                active_prev = _ms_get_modifier_last_source_sig(active_pair[0], active_pair[1], iid)
            except Exception:
                active_sig = active_prev = ''
            if active_sig and active_sig != active_prev:
                source = active_pair
        if source is None and dirty_pairs:
            source = (dirty_pairs[0][0], dirty_pairs[0][1])
        if source is None:
            continue

        try:
            changed += int(ms_sync_instance_group_from(source[0], source[1], context=context) or 0)
        except Exception:
            pass
    return changed


def _ms_instance_sync_timer():
    """Terminate the former recurring instance-group poller."""
    return None


def _ms_instance_object_has_marker(obj) -> bool:
    if obj is None:
        return False
    try:
        if ms_get_object_instance_id(obj):
            return True
    except Exception:
        pass
    try:
        mapping, _repaired = _ms_obj_legacy_instance_map_state(obj)
        if mapping and len(mapping):
            return True
    except Exception:
        pass
    try:
        for mod in getattr(obj, 'modifiers', ()) or ():
            try:
                if ms_get_instance_id(mod, obj):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _ms_instance_cached_member_names(context=None):
    """Return cached member names for diagnostics and compatibility only.

    The ordinary viewport path no longer invokes this function from
    depsgraph_update_post. It remains available to operators and audits.
    """
    try:
        dn = _ms__dn()
        dirty = bool(
            dn.get(_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY, False)
            or dn.get(_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY, False)
        )
        cached = dn.get(_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY)
        if not dirty and isinstance(cached, (set, frozenset)):
            return cached
        if bool(dn.get(_MS_OBJECT_INSTANCE_GROUP_CACHE_DIRTY_KEY, False)):
            _ms_object_instance_group_cache(context, force=True)
        if bool(dn.get(_MS_MODIFIER_INSTANCE_GROUP_CACHE_DIRTY_KEY, False)):
            _ms_modifier_instance_group_cache(context, force=True)
        names = set()
        ocache = dn.get(_MS_OBJECT_INSTANCE_GROUP_CACHE_KEY)
        ogroups = ocache.get('groups') if isinstance(ocache, dict) else {}
        if isinstance(ogroups, dict):
            for members in ogroups.values():
                names.update(str(name) for name in tuple(members or ()) if name)
        mcache = dn.get(_MS_MODIFIER_INSTANCE_GROUP_CACHE_KEY)
        mgroups = mcache.get('groups') if isinstance(mcache, dict) else {}
        if isinstance(mgroups, dict):
            for members in mgroups.values():
                for item in tuple(members or ()):
                    try:
                        oname = str(item[0] or '')
                    except Exception:
                        oname = ''
                    if oname:
                        names.add(oname)
        cached = frozenset(names)
        dn[_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY] = cached
        return cached
    except Exception:
        return frozenset()


def _ms_request_instance_event_sync(*, sanitize=False, delay=0.18) -> bool:
    """Queue one synchronization pass after an actual instance-related event."""
    try:
        dn = _ms__dn()
        if sanitize:
            dn[_MS_INSTANCE_EVENT_SANITIZE_KEY] = True
        due = time.monotonic() + max(0.02, float(delay or 0.18))
        dn[_MS_INSTANCE_EVENT_DUE_KEY] = due
        if dn.get(_MS_INSTANCE_EVENT_SYNC_ARMED_KEY):
            return True
        dn[_MS_INSTANCE_EVENT_SYNC_ARMED_KEY] = True
        bpy.app.timers.register(
            _ms_instance_event_sync_timer,
            first_interval=max(0.02, float(delay or 0.18)),
            persistent=False,
        )
        return True
    except Exception:
        try:
            dn = _ms__dn()
            dn.pop(_MS_INSTANCE_EVENT_SYNC_ARMED_KEY, None)
            dn.pop(_MS_INSTANCE_EVENT_DUE_KEY, None)
        except Exception:
            pass
        return False


def _ms_modifier_instance_rna_subscription_keys(context=None):
    """Return unique concrete modifier RNA type/property keys in live groups.

    Blender emits message-bus notifications for inherited modifier properties
    (including show_viewport) only when the concrete modifier RNA type is used.
    These subscriptions are completely dormant during object transforms,
    viewport navigation, redraw and dependency-graph evaluation.
    """
    keys = set()
    try:
        groups = _ms_modifier_instance_group_cache(context)
        resolved, stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=True)
        if stale:
            groups = _ms_modifier_instance_group_cache(context, force=True)
            resolved, _unused_stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=False)
    except Exception:
        resolved = {}
    try:
        group_values = tuple(resolved.values())
    except Exception:
        group_values = ()
    for pairs in group_values:
        for _obj, mod in tuple(pairs or ()):
            if mod is None:
                continue
            try:
                rna_type = type(mod)
                props = tuple(getattr(getattr(mod, 'bl_rna', None), 'properties', ()) or ())
            except Exception:
                continue
            for prop in props:
                try:
                    ident = str(getattr(prop, 'identifier', '') or '')
                    if not ident or ident in {'rna_type', 'type'}:
                        continue
                    if bool(getattr(prop, 'is_readonly', False)):
                        continue
                    keys.add((rna_type, ident))
                except Exception:
                    continue
    return keys


def _ms_instance_display_snapshot(context=None):
    """Capture raw display flags for instance members without mutating .blend data."""
    snapshot = {}
    try:
        groups = _ms_modifier_instance_group_cache(context)
        resolved, stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=True)
        if stale:
            groups = _ms_modifier_instance_group_cache(context, force=True)
            resolved, _unused_stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=False)
    except Exception:
        resolved = {}
    try:
        group_values = tuple(resolved.values())
    except Exception:
        group_values = ()
    for pairs in group_values:
        for obj, mod in tuple(pairs or ()):
            if obj is None or mod is None:
                continue
            try:
                obj_name = str(getattr(obj, 'name', '') or '')
                mod_name = str(getattr(mod, 'name', '') or '')
            except Exception:
                continue
            if not obj_name or not mod_name:
                continue
            for channel, (attr, _backup_key, default, _kw) in _MS_MOD_DISPLAY_CHANNELS.items():
                try:
                    if not hasattr(mod, attr):
                        continue
                    snapshot[(obj_name, mod_name, attr)] = bool(getattr(mod, attr, default))
                except Exception:
                    continue
    return snapshot


def _ms_refresh_instance_display_snapshot(context=None):
    try:
        _ms__dn()[_MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_KEY] = _ms_instance_display_snapshot(context)
    except Exception:
        pass


def _ms_capture_notified_manual_display_state(context=None):
    """Convert real user display toggles into Smart Modifier manual backups.

    Auto Disable changes the live RNA flags temporarily. Those changes are
    ignored while a row is marked as suppressed, so the original manual state
    remains intact. A raw-value snapshot identifies the actual member changed by
    a type-level message-bus notification, including non-active stack rows.
    """
    try:
        dn = _ms__dn()
        pending = dn.pop(_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY, set())
    except Exception:
        pending = set()
    try:
        pending = set(str(value or '') for value in pending if value)
    except Exception:
        pending = set()
    display_attrs = {
        'show_viewport': ('vp', 'viewport'),
        'show_render': ('render', 'render'),
        'show_in_editmode': ('edit', 'editmode'),
        'show_on_cage': ('cage', 'cage'),
    }
    attrs = tuple(attr for attr in pending if attr in display_attrs)
    if not attrs:
        return 0
    try:
        previous = dn.get(_MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_KEY)
        if not isinstance(previous, dict):
            previous = {}
    except Exception:
        previous = {}
    changed_count = 0
    try:
        groups = _ms_modifier_instance_group_cache(context)
        resolved, stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=True)
        if stale:
            groups = _ms_modifier_instance_group_cache(context, force=True)
            resolved, _unused_stale = _ms_resolve_modifier_instance_groups(groups, mark_stale=False)
    except Exception:
        resolved = {}
    try:
        group_values = tuple(resolved.values())
    except Exception:
        group_values = ()
    for pairs in group_values:
        for obj, mod in tuple(pairs or ()):
            if obj is None or mod is None:
                continue
            try:
                obj_name = str(getattr(obj, 'name', '') or '')
                mod_name = str(getattr(mod, 'name', '') or '')
            except Exception:
                continue
            if not obj_name or not mod_name:
                continue
            try:
                suppressed = bool(_ms_modifier_auto_disable_suppressed(obj, mod_name, context=context))
            except Exception:
                suppressed = False
            kwargs = {'viewport': None, 'render': None, 'editmode': None, 'cage': None}
            member_changed = False
            for attr in attrs:
                try:
                    if not hasattr(mod, attr):
                        continue
                    current = bool(getattr(mod, attr))
                except Exception:
                    continue
                key = (obj_name, mod_name, attr)
                if key in previous and bool(previous.get(key)) == current:
                    continue
                if suppressed:
                    continue
                channel, kw_name = display_attrs[attr]
                try:
                    found, backup = _ms_find_manual_display_backup(obj, mod_name, channel, current)
                except Exception:
                    found, backup = False, current
                # A notification may come from a different member of the same
                # concrete type. Only commit when this member's raw value really
                # differs from its last snapshot or stored manual state.
                if key not in previous and found and bool(backup) == current:
                    continue
                kwargs[kw_name] = current
                member_changed = True
            if not member_changed:
                continue
            try:
                _ms_set_manual_display_backup(obj, mod_name, **kwargs)
                _ms_update_auto_disable_display_snapshots(obj, mod_name, context=context, **kwargs)
                changed_count += 1
            except Exception:
                pass
    return changed_count


def _ms_instance_modifier_msgbus_notify(prop_identifier=''):
    """Debounce synchronization only after a subscribed modifier value changes."""
    try:
        if _MS_INST_SYNC_LOCK or _MS_OBJECT_INSTANCE_SYNC_LOCK:
            return
    except Exception:
        pass
    try:
        dn = _ms__dn()
        pending = dn.get(_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY)
        if not isinstance(pending, set):
            pending = set(pending or ())
        if prop_identifier:
            pending.add(str(prop_identifier))
        dn[_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY] = pending
    except Exception:
        pass
    _ms_request_instance_event_sync(sanitize=False, delay=0.02)


def _ms_instance_event_sync_timer():
    """Synchronize once after an RNA notification, never while idle."""
    try:
        ctx = getattr(bpy, 'context', None)
        dn = _ms__dn()
        try:
            remaining = float(dn.get(_MS_INSTANCE_EVENT_DUE_KEY, 0.0) or 0.0) - time.monotonic()
        except Exception:
            remaining = 0.0
        if remaining > 0.0:
            return max(0.02, min(0.20, remaining))
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if bool(getattr(wm, 'is_interface_locked', False)):
            return 0.10
        dn.pop(_MS_INSTANCE_EVENT_DUE_KEY, None)
        sanitize = bool(dn.pop(_MS_INSTANCE_EVENT_SANITIZE_KEY, False))
        dn.pop(_MS_INSTANCE_EVENT_SYNC_ARMED_KEY, None)
        membership_changed = False
        if sanitize:
            try:
                membership_changed = bool(ms_sanitize_unapproved_object_instance_copies(ctx))
            except Exception:
                membership_changed = False
            _ms_object_instance_cache_mark_dirty()
            _ms_modifier_instance_cache_mark_dirty()
        try:
            _ms_capture_notified_manual_display_state(ctx)
        except Exception:
            pass
        try:
            ms_sync_object_instance_modifier_additions(ctx, force=False)
        except Exception:
            pass
        try:
            ms_sync_all_instance_groups(ctx, prefer_active=True, force=False)
        except Exception:
            pass
        try:
            dn[_MS_INSTANCE_EVENT_SCENE_SIG_KEY] = _ms_object_instance_scene_signature(ctx)
            dn.pop(_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY, None)
        except Exception:
            pass
        try:
            _ms_refresh_instance_display_snapshot(ctx)
        except Exception:
            pass
        if sanitize or membership_changed:
            try:
                ms_refresh_instance_sync_subscriptions(ctx)
            except Exception:
                pass
    except Exception:
        try:
            dn = _ms__dn()
            dn.pop(_MS_INSTANCE_EVENT_SYNC_ARMED_KEY, None)
            dn.pop(_MS_INSTANCE_EVENT_SANITIZE_KEY, None)
            dn.pop(_MS_INSTANCE_EVENT_DUE_KEY, None)
            dn.pop(_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY, None)
        except Exception:
            pass
    return None


def _ms_request_instance_active_check(delay=0.05) -> bool:
    try:
        dn = _ms__dn()
        due = time.monotonic() + max(0.02, float(delay or 0.05))
        dn[_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY] = due
        if dn.get(_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY):
            return True
        dn[_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY] = True
        bpy.app.timers.register(
            _ms_instance_active_check_timer,
            first_interval=max(0.02, float(delay or 0.05)),
            persistent=False,
        )
        return True
    except Exception:
        try:
            dn = _ms__dn()
            dn.pop(_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY, None)
            dn.pop(_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY, None)
        except Exception:
            pass
        return False


def _ms_instance_active_object_msgbus_notify(*_args):
    """Observe active-object changes without a dependency-graph callback.

    Ordinary selection changes take an O(1) fast path and do not arm a timer.
    Native Shift+D changes the scene object count and makes the new copy active,
    which is the only case that needs a deferred sanitation pass.
    """
    try:
        ctx = getattr(bpy, 'context', None)
        dn = _ms__dn()
        current_sig = _ms_object_instance_scene_signature(ctx)
        previous_sig = dn.get(_MS_INSTANCE_EVENT_SCENE_SIG_KEY)
        active = getattr(getattr(getattr(ctx, 'view_layer', None), 'objects', None), 'active', None)
        active_key = _ms_object_identity_key(active)
        known_raw = dn.get(_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY)
        if current_sig == previous_sig and (
            not active_key or (isinstance(known_raw, list) and active_key in known_raw)
        ):
            return
    except Exception:
        pass
    _ms_request_instance_active_check(0.05)


def _ms_instance_active_check_timer():
    try:
        ctx = getattr(bpy, 'context', None)
        dn = _ms__dn()
        try:
            remaining = float(dn.get(_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY, 0.0) or 0.0) - time.monotonic()
        except Exception:
            remaining = 0.0
        if remaining > 0.0:
            return max(0.02, min(0.10, remaining))
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if bool(getattr(wm, 'is_interface_locked', False)):
            return 0.10
        dn.pop(_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY, None)
        dn.pop(_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY, None)

        current_sig = _ms_object_instance_scene_signature(ctx)
        previous_sig = dn.get(_MS_INSTANCE_EVENT_SCENE_SIG_KEY)
        try:
            active = getattr(getattr(getattr(ctx, 'view_layer', None), 'objects', None), 'active', None)
        except Exception:
            active = None
        active_key = _ms_object_identity_key(active)
        known_raw = dn.get(_MS_OBJECT_INSTANCE_KNOWN_OBJECTS_KEY)
        active_is_new = bool(active_key and isinstance(known_raw, list) and active_key not in known_raw)
        if current_sig == previous_sig and not active_is_new:
            return None

        count_changed = current_sig != previous_sig
        changed = 0
        try:
            changed = int(ms_sanitize_unapproved_object_instance_copies(ctx) or 0)
        except Exception:
            changed = 0
        if count_changed or changed:
            _ms_object_instance_cache_mark_dirty()
            _ms_modifier_instance_cache_mark_dirty()
            dn.pop(_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY, None)
            try:
                ms_request_shape_proxy_cleanup('object_count_change', force=False)
            except Exception:
                pass
            try:
                _ms_object_instance_group_cache(ctx, force=True)
                _ms_modifier_instance_group_cache(ctx, force=True)
            except Exception:
                pass
            try:
                ms_sync_object_instance_modifier_additions(ctx, force=False)
            except Exception:
                pass
            try:
                ms_sync_all_instance_groups(ctx, prefer_active=True, force=False)
            except Exception:
                pass
            try:
                ms_refresh_instance_sync_subscriptions(ctx)
            except Exception:
                pass
        dn[_MS_INSTANCE_EVENT_SCENE_SIG_KEY] = current_sig
    except Exception:
        try:
            dn = _ms__dn()
            dn.pop(_MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY, None)
            dn.pop(_MS_INSTANCE_ACTIVE_CHECK_DUE_KEY, None)
        except Exception:
            pass
    return None


def _ms_instance_nodes_values_changed(obj) -> bool:
    """True once per new value of a linked Geometry Nodes row on this object."""
    notified = None
    for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
        if str(getattr(mod, 'type', '') or '') != 'NODES':
            continue
        iid = ms_get_instance_id(mod, obj)
        if not iid:
            continue
        sig = _ms_modifier_sync_signature(mod)
        if not sig or sig == _ms_get_modifier_last_source_sig(obj, mod, iid):
            continue
        if notified is None:
            dn = _ms__dn()
            notified = dn.get(_MS_INSTANCE_NODES_NOTIFIED_SIGS_KEY)
            if not isinstance(notified, dict):
                notified = {}
                dn[_MS_INSTANCE_NODES_NOTIFIED_SIGS_KEY] = notified
        key = (str(obj.name), str(mod.name))
        if notified.get(key) != sig:
            notified[key] = sig
            return True
    return False


@bpy.app.handlers.persistent
def _ms_instance_nodes_depsgraph_post(_scene=None, depsgraph=None):
    """Notice Geometry Nodes input changes, which the message bus does not publish.

    Those inputs are ID properties. This callback exists only while a linked
    Geometry Nodes row exists and reads only objects whose geometry was updated.
    """
    try:
        if _MS_INST_SYNC_LOCK or _MS_OBJECT_INSTANCE_SYNC_LOCK:
            return
        if depsgraph is None or depsgraph.mode != 'VIEWPORT':
            return
        screen = getattr(bpy.context, 'screen', None)
        if screen is not None and screen.is_animation_playing:
            return
        for update in depsgraph.updates:
            if not update.is_updated_geometry:
                continue
            obj = getattr(update.id, 'original', None)
            if isinstance(obj, bpy.types.Object) and _ms_instance_nodes_values_changed(obj):
                _ms_request_instance_event_sync(sanitize=False, delay=0.02)
                return
    except Exception:
        pass


def _ms_set_instance_nodes_watch(enabled) -> None:
    handlers = bpy.app.handlers.depsgraph_update_post
    if enabled:
        if _ms_instance_nodes_depsgraph_post not in handlers:
            handlers.append(_ms_instance_nodes_depsgraph_post)
    else:
        while _ms_instance_nodes_depsgraph_post in handlers:
            handlers.remove(_ms_instance_nodes_depsgraph_post)


def ms_refresh_instance_sync_subscriptions(context=None) -> int:
    """Rebuild dormant message-bus subscriptions for current instance groups."""
    try:
        bpy.msgbus.clear_by_owner(_MS_INSTANCE_MSGBUS_OWNER)
    except Exception:
        pass
    count = 0
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.LayerObjects, 'active'),
            owner=_MS_INSTANCE_MSGBUS_OWNER,
            args=(),
            notify=_ms_instance_active_object_msgbus_notify,
            options={'PERSISTENT'},
        )
        count += 1
    except Exception:
        pass
    for rna_type, ident in tuple(_ms_modifier_instance_rna_subscription_keys(context)):
        try:
            bpy.msgbus.subscribe_rna(
                key=(rna_type, ident),
                owner=_MS_INSTANCE_MSGBUS_OWNER,
                args=(ident,),
                notify=_ms_instance_modifier_msgbus_notify,
                options={'PERSISTENT'},
            )
            count += 1
        except Exception:
            continue
    try:
        _ms_set_instance_nodes_watch(any(
            str(getattr(mod, 'type', '') or '') == 'NODES'
            for pairs in tuple(ms_collect_instance_groups(context).values())
            for _obj, mod in tuple(pairs or ())
        ))
    except Exception:
        pass
    try:
        dn = _ms__dn()
        dn[_MS_INSTANCE_MSGBUS_SUBSCRIPTION_COUNT_KEY] = int(count)
        dn.pop(_MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY, None)
    except Exception:
        pass
    _ms_refresh_instance_display_snapshot(context)
    return count


def ms_rebuild_instance_sync_after_file_load(context=None) -> int:
    """Reset caches and subscriptions after a blend/scene replacement."""
    ctx = context or getattr(bpy, 'context', None)
    try:
        ms_snapshot_existing_object_instance_members(ctx)
    except Exception:
        pass
    try:
        _ms_object_instance_cache_mark_dirty()
        _ms_modifier_instance_cache_mark_dirty()
        _ms_object_instance_group_cache(ctx, force=True)
        _ms_modifier_instance_group_cache(ctx, force=True)
        dn = _ms__dn()
        dn[_MS_INSTANCE_EVENT_SCENE_SIG_KEY] = _ms_object_instance_scene_signature(ctx)
        dn.pop(_MS_INSTANCE_EVENT_MEMBER_NAMES_KEY, None)
    except Exception:
        pass
    return ms_refresh_instance_sync_subscriptions(ctx)


@bpy.app.handlers.persistent
def _ms_instance_sync_depsgraph_handler(_scene=None, _depsgraph=None):
    """Legacy compatibility no-op; this callback is never registered now."""
    return None


@bpy.app.handlers.persistent
def _ms_instance_sync_undo_redo_post(_dummy=None):
    """Invalidate instance caches after Undo/Redo without scanning the scene.

    The cache accessors rebuild lazily on the next instance operation. Rebuilding
    groups and message-bus subscriptions inside Blender's global Undo callback
    caused the UI freeze to continue after the core Undo operation had finished.
    """
    try:
        _ms_object_instance_cache_mark_dirty()
        _ms_modifier_instance_cache_mark_dirty()
        dn = _ms__dn()
        for key in (
            _MS_INSTANCE_EVENT_SCENE_SIG_KEY,
            _MS_INSTANCE_EVENT_MEMBER_NAMES_KEY,
            _MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY,
            _MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_KEY,
        ):
            dn.pop(key, None)
    except Exception:
        pass


def ms_register_instance_sync_timer():
    """Register message-bus driven instance synchronization with zero idle polling."""
    try:
        timers = getattr(bpy.app, 'timers', None)
        for fn in (_ms_instance_sync_timer, _ms_instance_event_sync_timer, _ms_instance_active_check_timer):
            try:
                if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(fn):
                    timers.unregister(fn)
            except Exception:
                pass
    except Exception:
        pass
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        for fn in tuple(handlers):
            try:
                if fn is _ms_instance_sync_depsgraph_handler or (
                    str(getattr(fn, '__name__', '') or '') == '_ms_instance_sync_depsgraph_handler'
                    and 'smart_modifier_suite' in str(getattr(fn, '__module__', '') or '').lower()
                ):
                    handlers.remove(fn)
            except Exception:
                pass
    except Exception:
        pass
    try:
        ms_rebuild_instance_sync_after_file_load(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        for sequence in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
            if _ms_instance_sync_undo_redo_post not in sequence:
                sequence.append(_ms_instance_sync_undo_redo_post)
    except Exception:
        pass


def ms_unregister_instance_sync_timer():
    try:
        bpy.msgbus.clear_by_owner(_MS_INSTANCE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        _ms_set_instance_nodes_watch(False)
    except Exception:
        pass
    try:
        _ms__dn().pop(_MS_INSTANCE_SUBSCRIPTION_REFRESH_ARMED_KEY, None)
    except Exception:
        pass
    try:
        timers = getattr(bpy.app, 'timers', None)
        for fn in (_ms_instance_sync_timer, _ms_instance_event_sync_timer, _ms_instance_active_check_timer, _ms_instance_subscription_refresh_timer):
            try:
                if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(fn):
                    timers.unregister(fn)
            except Exception:
                pass
    except Exception:
        pass
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        for fn in tuple(handlers):
            try:
                if fn is _ms_instance_sync_depsgraph_handler or (
                    str(getattr(fn, '__name__', '') or '') == '_ms_instance_sync_depsgraph_handler'
                    and 'smart_modifier_suite' in str(getattr(fn, '__module__', '') or '').lower()
                ):
                    handlers.remove(fn)
            except Exception:
                pass
    except Exception:
        pass
    try:
        for sequence in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
            while _ms_instance_sync_undo_redo_post in sequence:
                sequence.remove(_ms_instance_sync_undo_redo_post)
    except Exception:
        pass
    try:
        dn = _ms__dn()
        for key in (
            _MS_INSTANCE_EVENT_SYNC_ARMED_KEY,
            _MS_INSTANCE_EVENT_SANITIZE_KEY,
            _MS_INSTANCE_EVENT_DUE_KEY,
            _MS_INSTANCE_EVENT_MEMBER_NAMES_KEY,
            _MS_INSTANCE_ACTIVE_CHECK_ARMED_KEY,
            _MS_INSTANCE_ACTIVE_CHECK_DUE_KEY,
            _MS_INSTANCE_MSGBUS_SUBSCRIPTION_COUNT_KEY,
            _MS_INSTANCE_MSGBUS_CHANGED_PROPS_KEY,
            _MS_INSTANCE_MSGBUS_DISPLAY_SNAPSHOT_KEY,
        ):
            dn.pop(key, None)
    except Exception:
        pass


def ms_group_modifiers_as_instance(pairs, instance_id=None, disp_name=None, sync_from_first=True, context=None):
    """Assign one Smart Modifier instance id to multiple (object, modifier) pairs."""
    clean = []
    seen = set()
    for item in (pairs or []):
        try:
            obj, mod = item
        except Exception:
            continue
        if not obj or not mod:
            continue
        key = (getattr(obj, 'name', ''), getattr(mod, 'name', ''))
        if not key[0] or not key[1] or key in seen:
            continue
        seen.add(key)
        clean.append((obj, mod))
    if not clean:
        return ''
    iid = str(instance_id or ms_get_instance_id(clean[0][1], clean[0][0]) or uuid.uuid4().hex)
    source_obj, source_mod = clean[0]
    logical_name = str(disp_name or ms_get_logical_modifier_name(source_obj, source_mod) or getattr(source_mod, 'name', '') or 'Modifier')
    try:
        src_enabled = get_mod_enabled_state(source_obj, source_mod.name)
    except Exception:
        src_enabled = True
    try:
        src_viewport, src_render, src_editmode, src_cage = _ms_get_modifier_manual_display_for_sync(source_obj, source_mod, context=context)
    except Exception:
        src_viewport, src_render, src_editmode, src_cage = True, True, False, False
    for obj, mod in clean:
        try:
            if sync_from_first and not (obj == source_obj and mod == source_mod):
                ms_copy_modifier_settings(source_mod, mod, include_name=False, skip_display_flags=True)
        except Exception:
            pass
        try:
            ms_obj_set_instance_id(obj, mod.name, iid, disp_name=logical_name)
            ms_obj_set_disp_name(obj, mod.name, logical_name)
            set_mod_enabled_state(obj, mod.name, src_enabled)
            _ms_set_modifier_display_state_for_instance_sync(obj, mod, viewport=src_viewport, render=src_render, editmode=src_editmode, cage=src_cage, context=context)
            ms_obj_cleanup_instance_map(obj)
            obj.update_tag()
        except Exception:
            pass
    if sync_from_first:
        try:
            ms_sync_instance_group_from(source_obj, source_mod, context=context)
        except Exception:
            pass
    try:
        _ms_modifier_instance_cache_mark_dirty()
        ms_refresh_instance_sync_subscriptions(context)
    except Exception:
        pass
    return iid


def ms_make_modifier_unique(obj, mod, context=None):
    """Break one modifier out of a Smart Modifier instance group."""
    if not obj or not mod:
        return False
    iid = ms_get_instance_id(mod, obj)
    if not iid:
        return True
    disp_name = ms_get_logical_modifier_name(obj, mod) or getattr(mod, 'name', '')
    try:
        group = getattr(mod, 'node_group', None)
        if group is not None and int(getattr(group, 'users', 0) or 0) > 1:
            new_group = group.copy()
            try:
                new_group.name = (str(getattr(group, 'name', '') or 'Node Group') + ' Unique')
            except Exception:
                pass
            try:
                mod.node_group = new_group
            except Exception:
                pass
    except Exception:
        pass
    try:
        tex = getattr(mod, 'texture', None)
        if tex is not None and int(getattr(tex, 'users', 0) or 0) > 1:
            try:
                mod.texture = tex.copy()
            except Exception:
                pass
    except Exception:
        pass
    try:
        try:
            if ms_get_object_instance_id(obj):
                _ms_modifier_set_object_instance_unique(mod, True)
        except Exception:
            pass
        ms_obj_clear_instance_id(obj, mod.name)
        if disp_name:
            ms_obj_set_disp_name(obj, mod.name, disp_name)
        ms_obj_cleanup_instance_map(obj)
        if iid:
            ms_instance_post_remove_cleanup(iid, context=context)
        try:
            plugin = ms_find_plugin_for_modifier(mod)
            hook = plugin.get('after_make_unique') if plugin else None
            if callable(hook):
                hook(obj, mod, context)
        except Exception:
            pass
        obj.update_tag()
        try:
            _ms_modifier_instance_cache_mark_dirty()
            ms_refresh_instance_sync_subscriptions(context)
        except Exception:
            pass
        return True
    except Exception:
        return False


def ms_snapshot_modifier_names(objects):
    out = {}
    for obj in (objects or []):
        try:
            out[obj.name] = [m.name for m in obj.modifiers]
        except Exception:
            pass
    return out


def ms_collect_new_modifiers(objects, before_snapshot):
    before_snapshot = before_snapshot or {}
    out = {}
    for obj in (objects or []):
        try:
            before = set(before_snapshot.get(obj.name, []) or [])
            mods = [m for m in obj.modifiers if m.name not in before]
            if mods:
                out[obj.name] = mods
        except Exception:
            pass
    return out


def ms_position_new_modifiers_to_active_slot(targets, before_snapshot, effective_id_by_obj=None, *, context=None, new_by_obj=None):
    """Move newly created modifiers directly below the pre-add active stack slot.

    Legacy/custom tools often create modifiers at Blender's default bottom of
    the stack.  This normalizes those additions to the same insertion policy as
    OBJECT_OT_ms_add_modifier: Base Object -> index 0, active modifier -> its
    direct next slot.
    """
    clean_targets = []
    seen = set()
    for obj in (targets or []):
        try:
            if not obj or not hasattr(obj, 'modifiers'):
                continue
            name = str(getattr(obj, 'name', '') or '')
            if not name or name in seen:
                continue
            seen.add(name)
            clean_targets.append(obj)
        except Exception:
            continue
    if not clean_targets:
        return []

    if new_by_obj is None:
        new_by_obj = ms_collect_new_modifiers(clean_targets, before_snapshot)
    if not new_by_obj:
        return []

    active = None
    try:
        active = get_main_object(getattr(context, 'active_object', None))
    except Exception:
        active = None
    master = active if active in clean_targets and new_by_obj.get(active.name) else None
    if master is None:
        for obj in clean_targets:
            try:
                if new_by_obj.get(obj.name):
                    master = obj
                    break
            except Exception:
                pass
    if master is None:
        master = clean_targets[0]

    effective_map = dict(effective_id_by_obj or {})
    try:
        master_ui_override = str(effective_map.get(master.name, '') or '')
    except Exception:
        master_ui_override = ''
    if not master_ui_override:
        try:
            master_ui_override = ms_get_ui_active_id(master)
        except Exception:
            master_ui_override = 'BASE'

    moved = []
    for obj in clean_targets:
        try:
            mods = [m for m in list(new_by_obj.get(obj.name) or []) if m and obj.modifiers.get(m.name)]
        except Exception:
            mods = []
        if not mods:
            continue
        try:
            base_insert = ms_calc_target_insert_index(master, obj, context, master_ui_id_override=master_ui_override)
        except Exception:
            try:
                base_insert = len(obj.modifiers)
            except Exception:
                base_insert = 0
        for ordinal, mod in enumerate(mods):
            try:
                target_idx = int(base_insert) + int(ordinal)
            except Exception:
                target_idx = 0
            try:
                safe_move_modifier(obj, mod.name, target_idx)
                moved.append((obj.name, mod.name))
            except Exception:
                pass
        try:
            active_mod = mods[-1]
            if active_mod and obj.modifiers.get(active_mod.name):
                try:
                    ui_owner = get_main_object(obj) or obj
                except Exception:
                    ui_owner = obj
                idx = obj.modifiers.find(active_mod.name)
                ui_owner['ui_active_item'] = active_mod.name
                ui_owner['ui_active_row'] = idx
                ms_set_ui_active_index(ui_owner, idx)
                obj['ui_active_item'] = active_mod.name
                obj['ui_active_row'] = idx
                ms_set_ui_active_index(obj, idx)
                obj.modifiers.active = active_mod
        except Exception:
            pass
    return moved


def ms_apply_auto_selection_to_new_modifiers(targets, before_snapshot, effective_id_by_obj=None, *, context=None):
    """Apply edit-selection-limited vertex groups to newly created modifiers.

    This is the generic bridge used by legacy/custom subtools that create
    modifiers outside OBJECT_OT_ms_add_modifier. It supports:
    - single-object add/update flows
    - multi-object pseudo-instance promotion flows
    - BaseObject / Edit Poly selection inheritance
    """
    clean_targets = []
    seen = set()
    for obj in (targets or []):
        if not obj or not hasattr(obj, 'modifiers'):
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        clean_targets.append(obj)
    if not clean_targets:
        return []
    new_by_obj = ms_collect_new_modifiers(clean_targets, before_snapshot)
    if not new_by_obj:
        return []

    try:
        ms_position_new_modifiers_to_active_slot(
            clean_targets,
            before_snapshot,
            effective_id_by_obj,
            context=context,
            new_by_obj=new_by_obj,
        )
    except Exception:
        pass

    active = None
    try:
        active = get_main_object(getattr(context, 'active_object', None))
    except Exception:
        active = None
    master = active if active in clean_targets and new_by_obj.get(active.name) else None
    if master is None:
        for obj in clean_targets:
            if new_by_obj.get(obj.name):
                master = obj
                break
    if master is None:
        master = clean_targets[0]

    max_len = 0
    for obj in clean_targets:
        try:
            max_len = max(max_len, len(new_by_obj.get(obj.name, []) or []))
        except Exception:
            pass
    if max_len <= 0:
        return []

    effective_map = dict(effective_id_by_obj or {})
    applied = []
    for ordinal in range(max_len):
        group_map = {}
        for obj in clean_targets:
            mods = list(new_by_obj.get(obj.name) or [])
            if ordinal < len(mods):
                try:
                    group_map[obj.name] = mods[ordinal].name
                except Exception:
                    pass
        if not group_map:
            continue

        iid = ''
        try:
            probe_names = [master.name] + [n for n in group_map.keys() if n != master.name]
        except Exception:
            probe_names = list(group_map.keys())
        for oname in probe_names:
            try:
                obj = bpy.data.objects.get(oname)
                mod = obj.modifiers.get(group_map.get(oname, '')) if obj else None
                iid = str(ms_get_instance_id(mod, obj) or '') if mod else ''
            except Exception:
                iid = ''
            if iid:
                break

        used_instance = False
        if iid:
            try:
                members = list(ms_iter_instance_members(iid))
                if len(members) > 1:
                    _ms_auto_sel_apply_instance_for_new_mods(iid, group_map, effective_map)
                    applied.append(iid)
                    used_instance = True
            except Exception:
                used_instance = False
        if used_instance:
            continue

        for oname, mname in group_map.items():
            try:
                obj = bpy.data.objects.get(oname)
                mod = obj.modifiers.get(mname) if obj else None
                if not obj or not mod:
                    continue
                eff = str(effective_map.get(oname, 'BASE') or 'BASE')
                _ms_auto_sel_try_apply_single(obj, obj, mod, eff, vg_seed=mname)
                applied.append((oname, mname))
            except Exception:
                continue
    return applied


def ms_promote_new_modifiers_to_instances(context, targets, before_snapshot, *, allow_copy_missing=True, display_name=None, effective_id_by_obj=None):
    """Detect modifiers created by a legacy subtool and link/copy them across selected objects."""
    clean_targets = []
    seen = set()
    for obj in (targets or []):
        if not obj or not hasattr(obj, 'modifiers'):
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        clean_targets.append(obj)
    if len(clean_targets) <= 1:
        return []
    new_by_obj = ms_collect_new_modifiers(clean_targets, before_snapshot)
    if not new_by_obj:
        return []
    active = None
    try:
        active = get_main_object(getattr(context, 'active_object', None))
    except Exception:
        active = None
    master = active if active in clean_targets and new_by_obj.get(active.name) else None
    if master is None:
        for obj in clean_targets:
            if new_by_obj.get(obj.name):
                master = obj
                break
    if master is None:
        return []
    master_mods = list(new_by_obj.get(master.name) or [])
    effective_map = dict(effective_id_by_obj or {})
    try:
        master_ui_override = str(effective_map.get(master.name, '') or '')
    except Exception:
        master_ui_override = ''
    if not master_ui_override:
        try:
            master_ui_override = ms_get_ui_active_id(master)
        except Exception:
            master_ui_override = 'BASE'
    instance_ids = []
    for ordinal, src_mod in enumerate(master_mods):
        try:
            existing_iid = ms_get_instance_id(src_mod, master)
            if existing_iid and len(list(ms_iter_instance_members(existing_iid))) > 1:
                continue
        except Exception:
            pass
        pairs = [(master, src_mod)]
        logical = str(display_name or ms_get_logical_modifier_name(master, src_mod) or src_mod.name)
        for obj in clean_targets:
            if obj == master:
                continue
            mods = list(new_by_obj.get(obj.name) or [])
            mod = mods[ordinal] if ordinal < len(mods) else None
            if mod is None and allow_copy_missing:
                try:
                    mod = obj.modifiers.new(name=logical, type=getattr(src_mod, 'type', ''))
                    ms_copy_modifier_settings(src_mod, mod, include_name=False)
                    try:
                        insert_idx = ms_calc_target_insert_index(master, obj, context, master_ui_id_override=master_ui_override)
                        safe_move_modifier(obj, mod.name, insert_idx)
                    except Exception:
                        pass
                except Exception:
                    mod = None
            if mod is not None:
                pairs.append((obj, mod))
        if len(pairs) > 1:
            iid = ms_group_modifiers_as_instance(pairs, disp_name=logical, sync_from_first=True, context=context)
            if iid:
                instance_ids.append(iid)
    return instance_ids

def ms_list_instance_modifiers_in_stack_order(obj, instance_id):
    if not obj or not instance_id or not obj.modifiers: return []
    iid = str(instance_id)
    ms_obj_cleanup_instance_map(obj)
    return [mm for mm in obj.modifiers if str(ms_get_instance_id(mm, obj) or "") == iid]

def ms_find_modifier_by_instance_id(obj, instance_id):
    lst = ms_list_instance_modifiers_in_stack_order(obj, instance_id)
    return lst[0] if lst else None

def ms_find_modifier_by_instance_id_and_ordinal(obj, instance_id, ordinal):
    lst = ms_list_instance_modifiers_in_stack_order(obj, instance_id)
    if not lst: return None
    idx = int(ordinal) if isinstance(ordinal, (int, float, str)) and str(ordinal).isdigit() else 0
    return lst[idx] if 0 <= idx < len(lst) else lst[0]

def ms_apply_state_post_action(context, main_obj, interactive_default=True):
    if not main_obj: return
    interactive = False if ms_is_multi_mode(context) else bool(interactive_default)
    apply_modifier_stack_state(main_obj, context, interactive=interactive)

def get_main_object(obj):
    if obj is None:
        return None

    # Fast-path: known helper markers (do not depend on plugin registration).
    try:
        if hasattr(obj, "get"):
            # EditPoly helper mesh
            if "ep_main_target" in obj:
                mn = obj.get("ep_main_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and getattr(mo, "type", "") == 'MESH':
                    return mo
            # SmartLattice lattice/helper
            if "sl_main_target" in obj:
                mn = obj.get("sl_main_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and getattr(mo, "type", "") == 'MESH':
                    return mo
            # EndPreview object created by Smart Modifier
            if "ms_end_preview_main" in obj:
                mn = obj.get("ms_end_preview_main")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and getattr(mo, "type", "") == 'MESH':
                    return mo
            # Max Slice plane Empty created by Smart Modifier
            if "smsm_slice_target" in obj:
                mn = obj.get("smsm_slice_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and ms_object_supports_modifier_stack(mo):
                    return mo
            # Smart Connect UVW Empty created by Smart Modifier
            if "smsm_uvw_target" in obj:
                mn = obj.get("smsm_uvw_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and ms_object_supports_modifier_stack(mo):
                    return mo
            # Smart Connect Noise Empty created by Smart Modifier
            if "smsm_noise_target" in obj:
                mn = obj.get("smsm_noise_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and ms_object_supports_modifier_stack(mo):
                    return mo
            # Generic Smart Connect Max Empty created by Smart Modifier
            if "smsm_generic_target" in obj:
                mn = obj.get("smsm_generic_target")
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and ms_object_supports_modifier_stack(mo):
                    return mo
            # Shape mesh proxy created by Smart Modifier for curve/font/surface stacks
            if _MS_SHAPE_PROXY_SOURCE_KEY in obj:
                mn = obj.get(_MS_SHAPE_PROXY_SOURCE_KEY)
                mo = bpy.data.objects.get(str(mn)) if mn else None
                if mo and ms_object_supports_modifier_stack(mo):
                    return mo
    except Exception:
        pass

    # Plugin-based resolution
    for p in ms_get_plugins_sorted():
        fn = p.get("get_main_object")
        if callable(fn):
            try:
                mo = fn(obj)
            except Exception:
                mo = None
            if mo:
                try:
                    if ms_is_shape_mesh_proxy(mo):
                        _shape_src = ms_shape_proxy_source(mo)
                        if _shape_src:
                            return _shape_src
                except Exception:
                    pass
                return mo

    # Do not resolve ordinary parented scene objects to their parent.
    # Smart Modifier helpers are resolved above through explicit markers or plugin hooks.
    # A generic parent-mesh fallback made normal child objects show the parent stack.

    # Lattice object fallback: resolve only lattices that are actually used by a Lattice modifier.
    try:
        if getattr(obj, "type", "") == 'LATTICE':
            for cand in bpy.data.objects:
                if getattr(cand, "type", "") == 'MESH':
                    for m in cand.modifiers:
                        if m.type == 'LATTICE' and getattr(m, "object", None) == obj:
                            return cand
    except Exception:
        pass

    return obj

def _ms_dn_get_dict(name):
    dn = bpy.app.driver_namespace
    if name not in dn: dn[name] = {}
    return dn[name]

def _ms_sel_cache_snapshot(main_obj):
    if not main_obj: return None
    return copy.deepcopy(_ms_dn_get_dict("_MS_SEL_CACHE").get(main_obj.name, {}))

def _ms_sel_cache_restore(main_obj, snapshot):
    if main_obj and snapshot is not None:
        _ms_dn_get_dict("_MS_SEL_CACHE")[main_obj.name] = snapshot

def _ms_capture_edit_mesh_selection_obj(mesh_obj):
    if not mesh_obj or mesh_obj.type != 'MESH': return None
    if getattr(bpy.context, "mode", "") != 'EDIT_MESH' or bpy.context.edit_object != mesh_obj: return None
    try:
        bm = bmesh.from_edit_mesh(mesh_obj.data)
        v = [e.index for e in bm.verts if e.select]
        e = [e.index for e in bm.edges if e.select]
        f = [e.index for e in bm.faces if e.select]
        return {"v": v, "e": e, "f": f}
    except Exception: return None

def _ms_sel_set(main_obj, layer_key, sel):
    if not main_obj or not layer_key or not sel: return
    root = _ms_dn_get_dict("_MS_SEL_CACHE")
    if main_obj.name not in root: root[main_obj.name] = {}
    root[main_obj.name][layer_key] = {
        "v": list(sel.get("v", [])),
        "e": list(sel.get("e", [])),
        "f": list(sel.get("f", []))
    }

def _ms_capture_edit_mesh_selection(context):
    ctx = context or bpy.context
    if getattr(ctx, "mode", "") != 'EDIT_MESH':
        return None
    ao = None
    try:
        ao = ctx.view_layer.objects.active
    except Exception:
        ao = None
    if not ao or getattr(ao, "type", "") != 'MESH':
        return None
    return _ms_capture_edit_mesh_selection_for_obj(ao)

def _ms_apply_edit_mesh_selection(obj, sel):
    if not obj or obj.type != 'MESH' or not sel or getattr(bpy.context, "mode", "") != 'EDIT_MESH': return
    me = getattr(obj, "data", None)
    if not me: return
    try:
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        for v in bm.verts: v.select = False
        for e in bm.edges: e.select = False
        for f in bm.faces: f.select = False
        for i in sel.get("v", []):
            if 0 <= int(i) < len(bm.verts): bm.verts[int(i)].select = True
        for i in sel.get("e", []):
            if 0 <= int(i) < len(bm.edges): bm.edges[int(i)].select = True
        for i in sel.get("f", []):
            if 0 <= int(i) < len(bm.faces): bm.faces[int(i)].select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    except Exception: pass

def ms_sel_cache(main_obj):
    if not main_obj: return {}
    root = _ms_dn_get_dict("_MS_SEL_CACHE")
    if main_obj.name not in root: root[main_obj.name] = {}
    return root[main_obj.name]

def ms_sel_set(main_obj, layer_key, sel):
    if not main_obj or not layer_key or not sel: return
    cache = ms_sel_cache(main_obj)
    hv = (len(sel.get("v", [])), len(sel.get("e", [])), len(sel.get("f", [])),
          sel.get("v")[0] if sel.get("v") else None, sel.get("v")[-1] if sel.get("v") else None,
          sel.get("e")[0] if sel.get("e") else None, sel.get("e")[-1] if sel.get("e") else None,
          sel.get("f")[0] if sel.get("f") else None, sel.get("f")[-1] if sel.get("f") else None)
    hroot = _ms_dn_get_dict("_MS_SEL_HASH")
    if main_obj.name not in hroot: hroot[main_obj.name] = {}
    if hroot[main_obj.name].get(layer_key) == hv: return
    hroot[main_obj.name][layer_key] = hv
    cache[layer_key] = {
        "v": list(sel.get("v", [])),
        "e": list(sel.get("e", [])),
        "f": list(sel.get("f", [])),
    }

def ms_sel_get(main_obj, layer_key):
    if not main_obj or not layer_key: return None
    return ms_sel_cache(main_obj).get(layer_key)

def ms_get_layer_key_from_active_object(active_obj):
    if not active_obj: return (None, None)
    for p in ms_get_plugins_sorted():
        fn = p.get("layer_key_from_active_object")
        if callable(fn):
            res = fn(active_obj)
            if res and isinstance(res, (tuple, list)) and len(res) == 2 and res[0] and res[1]:
                return (res[0], res[1])
    main_obj = get_main_object(active_obj)
    if not main_obj: return (None, None)
    return (main_obj, "BASE") if active_obj == main_obj else (main_obj, None)

def ms_get_carrier_key_for_effective(main_obj, effective_id):
    """Return the selection carrier key for the given effective UI id.

    - BASE => "BASE"
    - Plugins (EditPoly / SmartLattice etc.) may provide their own carrier keys.
    - For standard modifiers (no plugin carrier), we inherit the nearest selection-capable
      layer ABOVE this modifier in the stack (BaseObject/EditPoly), so selection stays stable
      and new modifiers under EditPoly inherit EditPoly selection.
    """
    if not main_obj or effective_id == "BASE" or not effective_id:
        return "BASE"

    # Plugin-provided carrier
    for p in ms_get_plugins_sorted():
        fn = p.get("carrier_key_for_effective")
        if callable(fn):
            try:
                k = fn(main_obj, effective_id)
            except Exception:
                k = None
            if k:
                return k

    # Fallback for standard modifiers: inherit nearest selection-capable layer above
    try:
        idx = main_obj.modifiers.find(effective_id)
    except Exception:
        idx = -1
    if idx is None or idx < 0:
        return "BASE"

    # Scan upwards in the visible stack (towards final result). In Blender's list order,
    # indices lower than idx are above in the UI.
    try:
        for j in range(idx - 1, -1, -1):
            try:
                m = main_obj.modifiers[j]
            except Exception:
                m = None
            if not m:
                continue
            # A layer is selection-capable if any plugin supplies a carrier key for it.
            for p in ms_get_plugins_sorted():
                fn = p.get("carrier_key_for_effective")
                if callable(fn):
                    try:
                        k = fn(main_obj, m.name)
                    except Exception:
                        k = None
                    if k:
                        return k
    except Exception:
        pass

    return "BASE"

def ms_find_inherit_key_for_carrier(main_obj, carrier_key):
    if not main_obj or not carrier_key or carrier_key == "BASE": return "BASE"
    for p in ms_get_plugins_sorted():
        fn = p.get("inherit_key_for_carrier")
        if callable(fn):
            k = fn(main_obj, carrier_key)
            if k: return k
    return "BASE"

def ms_capture_selection_to_cache(context):
    """Capture current edit-mesh selection to cache.

    IMPORTANT (fix):
    - Do NOT key selection solely by UI active item.
      During OBJECT->EDIT transitions, Blender can briefly enter EDIT on the main object
      even when EditPoly is the UI-active layer. If we store under the UI-derived carrier,
      BaseObject selection overwrites EditPoly selection (they become identical).
    - Instead, derive the layer key from the *actual edit object*:
        * main object => "BASE"
        * EditPoly helper mesh => that EP layer name (via plugin hook)
      with a safe fallback for unknown cases.
    """
    ctx = context or bpy.context
    if getattr(ctx, "mode", "") != 'EDIT_MESH':
        return

    ao = getattr(ctx, "edit_object", None)
    if not ao:
        try:
            ao = ctx.view_layer.objects.active
        except Exception:
            ao = None
    if not ao or getattr(ao, "type", "") != 'MESH':
        return

    main_obj = None
    layer_key = None
    try:
        res = ms_get_layer_key_from_active_object(ao)
        if res and isinstance(res, (tuple, list)) and len(res) == 2:
            main_obj, layer_key = res[0], res[1]
    except Exception:
        main_obj, layer_key = None, None

    if not main_obj:
        main_obj = get_main_object(ao)
    if not main_obj:
        return

    if not layer_key:
        if ao == main_obj:
            layer_key = "BASE"
        else:
            try:
                effective_id = ms_get_ui_active_id(main_obj)
            except Exception:
                effective_id = "BASE"
            layer_key = ms_get_carrier_key_for_effective(main_obj, effective_id)

    sel = _ms_capture_edit_mesh_selection_for_obj(ao)
    if sel:
        ms_sel_set(main_obj, layer_key, sel)

def _ms_capture_edit_mesh_selection_for_obj(mesh_obj):
    """Capture edit-mesh selection for a specific mesh object (multi-edit safe, optimized, accurate).

    Strategy:
    - Read selection totals from Mesh (cheap).
    - Try select_history first (fast for sparse selection) and accept it ONLY if it matches totals.
    - Otherwise fall back to full scan.
    """
    if not mesh_obj or getattr(mesh_obj, "type", "") != 'MESH':
        return None
    if getattr(bpy.context, "mode", "") != 'EDIT_MESH':
        return None
    me = getattr(mesh_obj, "data", None)
    if not me:
        return None

    try:
        tv = int(getattr(me, "total_vert_sel", 0) or 0)
        te = int(getattr(me, "total_edge_sel", 0) or 0)
        tf = int(getattr(me, "total_face_sel", 0) or 0)
    except Exception:
        tv = te = tf = -1

    try:
        bm = bmesh.from_edit_mesh(me)

        # Fast path: use select_history when it fully represents selection
        try:
            hist = list(getattr(bm, "select_history", []) or [])
        except Exception:
            hist = []
        if hist:
            vs, es, fs = set(), set(), set()
            for elem in hist:
                try:
                    if not getattr(elem, "select", False):
                        continue
                    tn = elem.__class__.__name__
                    if tn == "BMVert":
                        vs.add(int(elem.index))
                    elif tn == "BMEdge":
                        es.add(int(elem.index))
                    elif tn == "BMFace":
                        fs.add(int(elem.index))
                except Exception:
                    continue

            # Accept history only when counts match mesh totals (prevents partial/missing selection bugs)
            if (tv >= 0 and te >= 0 and tf >= 0):
                if len(vs) == tv and len(es) == te and len(fs) == tf:
                    return {"v": sorted(vs), "e": sorted(es), "f": sorted(fs)}
            else:
                # If totals not available, accept only when non-empty and small (best effort)
                if vs or es or fs:
                    return {"v": sorted(vs), "e": sorted(es), "f": sorted(fs)}

        # Fallback: full scan (accurate)
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            pass
        return {
            "v": [v.index for v in bm.verts if v.select],
            "e": [e.index for e in bm.edges if e.select],
            "f": [f.index for f in bm.faces if f.select],
        }
    except Exception:
        return None

def ms_capture_selection_to_cache_all(context):
    """Capture selection for all edit-mode mesh objects (supports multi-object edit mode).

    IMPORTANT (fix):
    - In multi-object edit mode, some objects may be EditPoly helper meshes while others are main meshes.
      Store selection under the layer key derived from the *actual* edit object, so:
        * main object selection stays in "BASE"
        * EditPoly helper selection stays in its EP layer key
      This prevents BaseObject/EditPoly selections from collapsing into the same cache entry.
    - For unknown/unsupported edit objects, fall back to the UI-derived carrier key.
    """
    ctx = context or bpy.context
    if getattr(ctx, "mode", "") != 'EDIT_MESH':
        return
    objs = []
    try:
        objs = list(getattr(ctx, "objects_in_mode", None) or [])
    except Exception:
        objs = []
    if not objs:
        try:
            ao = ctx.view_layer.objects.active
            if ao:
                objs = [ao]
        except Exception:
            objs = []
    for eo in objs:
        if not eo or getattr(eo, "type", "") != 'MESH':
            continue

        main_obj = None
        layer_key = None
        try:
            res = ms_get_layer_key_from_active_object(eo)
            if res and isinstance(res, (tuple, list)) and len(res) == 2:
                main_obj, layer_key = res[0], res[1]
        except Exception:
            main_obj, layer_key = None, None

        if not main_obj:
            main_obj = get_main_object(eo)
        if not main_obj:
            continue

        if not layer_key:
            if eo == main_obj:
                layer_key = "BASE"
            else:
                try:
                    effective_id = ms_get_ui_active_id(main_obj)
                except Exception:
                    effective_id = "BASE"
                layer_key = ms_get_carrier_key_for_effective(main_obj, effective_id)

        sel = _ms_capture_edit_mesh_selection_for_obj(eo)
        if sel:
            ms_sel_set(main_obj, layer_key, sel)

def _ms_auto_sel_is_base_or_editpoly_effective(main_obj, effective_id):
    """Return True if the effective active layer is BASE or an Edit Poly layer."""
    if not main_obj: return False
    if not effective_id or effective_id == "BASE": return True
    try:
        m = main_obj.modifiers.get(effective_id)
        if not m: return False
        p = ms_find_plugin_for_modifier(m)
        return bool(p and (p.get("id", "") == "edit_poly"))
    except Exception:
        return False

def _ms_modifier_supports_vertex_group(mod):
    if not mod: return False
    try:
        prop = mod.bl_rna.properties.get("vertex_group")
        if not prop: return False
        if getattr(prop, "is_readonly", False): return False
        return True
    except Exception:
        return False



def _ms_find_nearest_carrier_effective_id_for_modifier(main_obj, mod_name, order=None):
    """Find the nearest EditPoly (or BASE) in the direction towards BaseObject based on stack order.
    - TOP_DOWN (BaseObject Top): search towards smaller modifier indices.
    - BOTTOM_UP (BaseObject Bottom): search towards larger modifier indices.
    """
    if not main_obj or not mod_name:
        return "BASE"
    if order is None:
        try:
            order = ms_get_stack_order()
        except Exception:
            order = 'TOP_DOWN'
    try:
        idx = main_obj.modifiers.find(mod_name)
    except Exception:
        idx = -1
    if idx < 0:
        return "BASE"
    try:
        mods = list(main_obj.modifiers)
    except Exception:
        mods = []
    n = len(mods)
    if order == 'TOP_DOWN':
        rng = range(idx - 1, -1, -1)
    else:
        rng = range(idx + 1, n, 1)
    for j in rng:
        try:
            cand = mods[j]
            p = ms_find_plugin_for_modifier(cand)
            if p and p.get("id", "") == "edit_poly":
                return cand.name
        except Exception:
            continue
    return "BASE"
def _ms_auto_sel_is_empty(sel):
    if not sel or not isinstance(sel, dict): return True
    return (not sel.get("v")) and (not sel.get("e")) and (not sel.get("f"))

def _ms_auto_sel_make_group_name(seed=""):
    if seed:
        try:
            s = re.sub(r"[^A-Za-z0-9]+", "", str(seed))
            if not s: s = uuid.uuid4().hex
            return "MS_Sel_" + s[:12]
        except Exception:
            return "MS_Sel_" + uuid.uuid4().hex[:12]
    return "MS_Sel_" + uuid.uuid4().hex[:12]

def ms_auto_sel_sync_edit_mesh(obj):
    """Mesh.vertices/edges/polygons lag behind the BMesh during Edit Mode; bring them up to date."""
    if getattr(obj, "mode", "OBJECT") == 'EDIT':
        obj.update_from_editmode()

def _ms_auto_sel_sel_to_vert_indices(mesh, sel):
    """Convert cached selection (v/e/f indices) to a vertex index set for vertex-group use."""
    if not mesh or not sel: return []
    try:
        vset = set(int(i) for i in (sel.get("v") or []) if int(i) >= 0)
    except Exception:
        vset = set()
    try:
        edges = getattr(mesh, "edges", None)
        if edges:
            for ei in (sel.get("e") or []):
                try:
                    ii = int(ei)
                    if 0 <= ii < len(edges):
                        ev = edges[ii].vertices
                        if ev and len(ev) >= 2:
                            vset.add(int(ev[0])); vset.add(int(ev[1]))
                except Exception:
                    continue
    except Exception:
        pass
    try:
        polys = getattr(mesh, "polygons", None)
        if polys:
            for fi in (sel.get("f") or []):
                try:
                    ii = int(fi)
                    if 0 <= ii < len(polys):
                        for vi in polys[ii].vertices:
                            vset.add(int(vi))
                except Exception:
                    continue
    except Exception:
        pass
    # Clamp to mesh vertex count
    try:
        n = len(mesh.vertices)
        vset = {i for i in vset if 0 <= i < n}
    except Exception:
        pass
    return sorted(vset)

def _ms_auto_sel_reset_vgroup(obj, vg_name):
    if not obj or not vg_name: return None
    try:
        vg = obj.vertex_groups.get(vg_name)
        if vg: obj.vertex_groups.remove(vg)
    except Exception:
        pass
    try:
        return obj.vertex_groups.new(name=vg_name)
    except Exception:
        return None

def _ms_auto_sel_ensure_vgroup(obj, vg_name):
    if not obj or not vg_name: return None
    try:
        vg = obj.vertex_groups.get(vg_name)
        if vg: return vg
    except Exception:
        pass
    try:
        return obj.vertex_groups.new(name=vg_name)
    except Exception:
        return None

def _ms_auto_sel_apply_vgroup_weights(obj, vg_name, vert_indices):
    """Create/reset and assign weights for the vertex group."""
    if not obj or not vg_name: return
    vg = obj.vertex_groups.get(vg_name)
    # For our auto groups, reset to avoid stale weights.
    if vg and (vg_name.startswith("MS_Sel_")):
        vg = _ms_auto_sel_reset_vgroup(obj, vg_name)
    else:
        vg = _ms_auto_sel_ensure_vgroup(obj, vg_name)
    if not vg: return
    if not vert_indices: return
    if getattr(obj, "mode", "OBJECT") == 'EDIT':
        # VertexGroup.add() refuses Edit Mode; the live weights are in the BMesh.
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        layer = bm.verts.layers.deform.verify()
        bm.verts.ensure_lookup_table()
        for index in vert_indices:
            bm.verts[index][layer][vg.index] = 1.0
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return
    vg.add(list(vert_indices), 1.0, 'REPLACE')

def ms_auto_sel_bind_vgroup(mod, vg_name):
    """Make the modifier actually limited by the group it was given."""
    mod.vertex_group = vg_name
    # Bevel ignores vertex_group unless its limit method asks for it.
    if getattr(mod, "type", "") == 'BEVEL':
        mod.limit_method = 'VGROUP'
    # Only Geometry Nodes modifiers can store ID properties.
    if getattr(mod, "type", "") == 'NODES':
        mod["_ms_auto_sel_vg"] = vg_name

def _ms_auto_sel_get_vg_from_modifier(mod):
    if not mod: return ""
    try:
        vg = mod.get("_ms_auto_sel_vg", "")
        if vg: return str(vg)
    except Exception:
        pass
    try:
        vg2 = getattr(mod, "vertex_group", "") or ""
        return str(vg2) if vg2 else ""
    except Exception:
        return ""

def _ms_auto_sel_cleanup_vgroup_if_unused(obj, vg_name):
    """Remove auto-created vertex group if no remaining modifier references it."""
    if not obj or not vg_name: return
    if not str(vg_name).startswith("MS_Sel_"): return
    try:
        for m in obj.modifiers:
            try:
                if getattr(m, "vertex_group", "") == vg_name:
                    return
            except Exception:
                continue
    except Exception:
        return
    try:
        vg = obj.vertex_groups.get(vg_name)
        if vg: obj.vertex_groups.remove(vg)
    except Exception:
        pass

def _ms_auto_sel_try_apply_single(main_obj, obj, mod, effective_id, vg_seed=""):
    """Apply selection-limited vertex group to a single newly created modifier."""
    if not main_obj or not obj or not mod: return ""
    if not _ms_modifier_supports_vertex_group(mod): return ""
    if not _ms_auto_sel_is_base_or_editpoly_effective(main_obj, effective_id): return ""
    carrier_key = ms_get_carrier_key_for_effective(main_obj, effective_id)
    sel = ms_sel_get(main_obj, carrier_key)
    if _ms_auto_sel_is_empty(sel): return ""
    ms_auto_sel_sync_edit_mesh(obj)
    v_idx = _ms_auto_sel_sel_to_vert_indices(getattr(obj, "data", None), sel)
    if not v_idx: return ""
    vg_name = _ms_auto_sel_get_vg_from_modifier(mod) or _ms_auto_sel_make_group_name(vg_seed)
    _ms_auto_sel_apply_vgroup_weights(obj, vg_name, v_idx)
    ms_auto_sel_bind_vgroup(mod, vg_name)
    return vg_name

def _ms_auto_sel_apply_instance_for_new_mods(instance_id, new_mods_by_objname, effective_id_by_objname):
    """For instance operations: if any object has a selection, set a shared vertex group and ensure each member has it."""
    if not instance_id or not new_mods_by_objname: return ""
    vg_name = ""
    # If any member already has an auto vg, reuse it.
    try:
        for on, mn in new_mods_by_objname.items():
            o = bpy.data.objects.get(on)
            if not o: continue
            m = o.modifiers.get(mn) if mn else None
            if not m: continue
            vg_name = _ms_auto_sel_get_vg_from_modifier(m)
            if vg_name: break
    except Exception:
        vg_name = ""
    if not vg_name:
        vg_name = _ms_auto_sel_make_group_name(instance_id)

    # Determine if any selection exists across the new target objects
    any_sel = False
    sel_by_obj = {}
    for on, mn in new_mods_by_objname.items():
        o = bpy.data.objects.get(on)
        if not o or getattr(o, "type", "") != 'MESH': continue
        eff = (effective_id_by_objname or {}).get(on, "BASE")
        # Only BASE / Edit Poly layers participate in this feature
        if not _ms_auto_sel_is_base_or_editpoly_effective(o, eff):
            sel_by_obj[on] = None
            continue
        carrier_key = ms_get_carrier_key_for_effective(o, eff)
        sel = ms_sel_get(o, carrier_key)
        sel_by_obj[on] = sel
        if not _ms_auto_sel_is_empty(sel): any_sel = True

    if not any_sel:
        return ""

    # Apply to all instance members (including source if it becomes a member later)
    try:
        for o, m in ms_iter_instance_members(instance_id):
            if not o or not m: continue
            if not _ms_modifier_supports_vertex_group(m): continue
            ms_auto_sel_sync_edit_mesh(o)
            sel = sel_by_obj.get(o.name)
            if not _ms_auto_sel_is_empty(sel):
                v_idx = _ms_auto_sel_sel_to_vert_indices(getattr(o, "data", None), sel)
                if not v_idx:
                    v_idx = list(range(len(o.data.vertices))) if getattr(o, "data", None) else []
            else:
                v_idx = list(range(len(o.data.vertices))) if getattr(o, "data", None) else []
            # Only set weights when this modifier did not already have an auto vg.
            had = bool(_ms_auto_sel_get_vg_from_modifier(m))
            if not had:
                _ms_auto_sel_apply_vgroup_weights(o, vg_name, v_idx)
            else:
                # Ensure group exists at least
                _ms_auto_sel_ensure_vgroup(o, vg_name)
            ms_auto_sel_bind_vgroup(m, vg_name)
    except Exception:
        pass
    return vg_name

def ms_apply_selection_for_carrier(main_obj, target_obj, carrier_key):
    if not main_obj or not target_obj or not carrier_key: return
    sel = ms_sel_get(main_obj, carrier_key)
    if not sel:
        inherit_key = ms_find_inherit_key_for_carrier(main_obj, carrier_key)
        sel = ms_sel_get(main_obj, inherit_key)
        if sel: ms_sel_set(main_obj, carrier_key, sel)
    if sel: _ms_apply_edit_mesh_selection(target_obj, sel)

def ms_get_ui_active_id(main_obj):
    if not main_obj: return "BASE"
    ui_id = main_obj.get("ui_active_item", "BASE")
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if not ms_object_has_modifier_collection(stack_obj):
        if ui_id != "BASE":
            main_obj["ui_active_item"] = "BASE"
        return "BASE"
    try:
        if ui_id != "BASE":
            mod = stack_obj.modifiers.get(ui_id)
            if mod is None or ms_modifier_is_internal_stack_helper(mod):
                ui_id = "BASE"
                main_obj["ui_active_item"] = ui_id
    except Exception:
        ui_id = "BASE"
        try: main_obj["ui_active_item"] = ui_id
        except Exception: pass
    return ui_id

def ms_set_ui_active_index(main_obj, idx_val):
    if main_obj: main_obj["ui_active_index"] = int(idx_val)

def ms_get_ui_active_index(main_obj):
    if not main_obj: return -1
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    v = main_obj.get("ui_active_index", None)
    if v is not None:
        try:
            iv = int(v)
            if iv == -1: return -1
            if 0 <= iv < len(getattr(stack_obj, "modifiers", [])): return iv
        except Exception: pass
    ui_id = main_obj.get("ui_active_item", "BASE")
    if ui_id == "BASE": return -1
    if hasattr(stack_obj, "modifiers"): return stack_obj.modifiers.find(ui_id)
    return -1

def ms_refresh_ui_active_index(main_obj):
    if not main_obj: return
    ui_id = main_obj.get("ui_active_item", "BASE")
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if ui_id == "BASE" or not ms_object_has_modifier_collection(stack_obj):
        ms_set_ui_active_index(main_obj, -1)
    else:
        ms_set_ui_active_index(main_obj, stack_obj.modifiers.find(ui_id))

def ms_get_effective_active_id(main_obj, ui_id=None):
    if not main_obj: return "BASE"
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if not ms_object_has_modifier_collection(stack_obj): return "BASE"
    if ui_id is None: ui_id = ms_get_ui_active_id(main_obj)
    if ui_id == "BASE": return "BASE"
    mod = stack_obj.modifiers.get(ui_id)
    if mod and (not ms_modifier_is_internal_stack_helper(mod)) and get_mod_enabled_state(stack_obj, mod.name): return ui_id
    idx = stack_obj.modifiers.find(ui_id)
    if idx > 0:
        for i in range(idx - 1, -1, -1):
            m = stack_obj.modifiers[i]
            if ms_modifier_is_internal_stack_helper(m):
                continue
            if get_mod_enabled_state(stack_obj, m.name): return m.name
    return "BASE"

def ms_get_top_enabled_ui_id(main_obj):
    if not main_obj: return "BASE"
    try:
        stack_obj = ms_get_modifier_stack_object(main_obj, context=None, create=False) or main_obj
    except Exception:
        stack_obj = main_obj
    if not ms_object_has_modifier_collection(stack_obj): return "BASE"
    for mod in reversed(list(stack_obj.modifiers)):
        if ms_modifier_is_internal_stack_helper(mod):
            continue
        if get_mod_enabled_state(stack_obj, mod.name): return mod.name
    return "BASE"

def safe_move_modifier(obj, mod_name, target_idx):
    # Fast path: use data API (ModifierSequence.move) whenever possible.
    # This avoids bpy.ops (slow) and avoids depending on active object context.
    if not obj or not mod_name:
        return
    mods = getattr(obj, "modifiers", None)
    if not mods:
        return
    mod = mods.get(mod_name)
    if not mod:
        return

    try:
        current_idx = mods.find(mod.name)
    except Exception:
        current_idx = -1

    try:
        target_idx = int(target_idx)
    except Exception:
        target_idx = current_idx

    if current_idx < 0:
        return

    try:
        n = len(mods)
    except Exception:
        n = 0

    if n <= 0:
        return

    if target_idx < 0:
        target_idx = 0
    elif target_idx > n - 1:
        target_idx = n - 1

    if current_idx == target_idx:
        return

    # Preferred: direct move (Blender 2.8+)
    if hasattr(mods, "move"):
        try:
            mods.move(current_idx, target_idx)
            return
        except Exception:
            pass

    # Fallback: ops (slow, but preserves compatibility)
    try:
        vl = bpy.context.view_layer
        prev_active = vl.objects.active
        vl.objects.active = obj
    except Exception:
        vl = None
        prev_active = None

    try:
        if hasattr(bpy.ops.object, "modifier_move_to_index"):
            try:
                bpy.ops.object.modifier_move_to_index('EXEC_DEFAULT', False, modifier=mod.name, index=target_idx)
                return
            except Exception:
                pass

        if current_idx < target_idx:
            for _ in range(target_idx - current_idx):
                try:
                    bpy.ops.object.modifier_move_down('EXEC_DEFAULT', False, modifier=mod.name)
                except Exception:
                    break
        else:
            for _ in range(current_idx - target_idx):
                try:
                    bpy.ops.object.modifier_move_up('EXEC_DEFAULT', False, modifier=mod.name)
                except Exception:
                    break
    finally:
        try:
            if vl:
                vl.objects.active = prev_active
        except Exception:
            pass

def _ms_force_deselect_all(vl):
    if not vl: return
    try:
        if bpy.ops.object.select_all.poll():
            bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
    except Exception: pass

    for o in vl.objects:
        try:
            if not o.select_get(): continue
        except Exception: continue
        try:
            was_hide_select = bool(getattr(o, "hide_select", False))
            is_ep_helper = bool(getattr(o, "get", None) and o.get("ep_main_target"))
            if was_hide_select and is_ep_helper:
                try: o.hide_select = False
                except Exception: pass
            try: o.select_set(False)
            except Exception: pass
            if was_hide_select and is_ep_helper:
                try: o.hide_select = True
                except Exception: pass
        except Exception: pass


def _ms_snapshot_object_selection(vl):
    """Return (selected_names, active_name). Safe and lightweight."""
    if not vl:
        return ([], "")
    try:
        selected = [o.name for o in vl.objects if getattr(o, "select_get", None) and o.select_get()]
    except Exception:
        selected = []
    try:
        ao = getattr(vl.objects, "active", None)
        active_name = ao.name if ao else ""
    except Exception:
        active_name = ""
    return (selected, active_name)


def ms_set_exact_object_selection(context, selected_names, active_name=""):
    """Set the exact object selection/active object in the current view layer."""
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    if not vl:
        return False
    names = []
    seen = set()
    for n in (selected_names or []):
        try:
            obj = vl.objects.get(n)
        except Exception:
            obj = None
        if obj is None:
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        names.append(obj.name)
    if not names and active_name:
        try:
            obj = vl.objects.get(active_name)
            if obj is not None:
                names = [obj.name]
        except Exception:
            names = []
    selected_set = set(names)
    for obj in vl.objects:
        try:
            if obj.name in selected_set:
                try:
                    obj.hide_set(False)
                    if _ms_is_internal_visibility_helper_object(obj):
                        if hasattr(obj, "hide_viewport"):
                            obj.hide_viewport = False
                        if hasattr(obj, "hide_select"):
                            obj.hide_select = False
                except Exception:
                    pass
            obj.select_set(obj.name in selected_set)
        except Exception:
            pass
    active = None
    if active_name:
        try:
            active = vl.objects.get(active_name)
        except Exception:
            active = None
    if active is None and names:
        try:
            active = vl.objects.get(names[0])
        except Exception:
            active = None
    if active is not None:
        try:
            vl.objects.active = active
        except Exception:
            pass
    return bool(active is not None or names)


def ms_begin_temporary_stack_target_selection(context, targets, active_target=None):
    """Temporarily select stack execution targets such as shape mesh proxies.

    This is used by custom/operator-based modifier add paths whose underlying
    Blender operator reads context.selected_objects / active_object.  The caller
    must restore with ms_end_temporary_stack_target_selection().
    """
    state = {'selected_names': [], 'active_name': ''}
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    if not vl:
        return state
    try:
        state['selected_names'], state['active_name'] = _ms_snapshot_object_selection(vl)
    except Exception:
        pass
    names = []
    seen = set()
    for obj in (targets or []):
        try:
            if obj is None:
                continue
            _ms_set_obj_hidden(obj, False, False)
            name = str(getattr(obj, 'name', '') or '')
            if name and name not in seen:
                seen.add(name)
                names.append(name)
        except Exception:
            pass
    if active_target is None:
        try:
            active_target = targets[0] if targets else None
        except Exception:
            active_target = None
    active_name = str(getattr(active_target, 'name', '') or '') if active_target is not None else ''
    try:
        if names:
            ms_set_exact_object_selection(context, names, active_name or names[0])
    except Exception:
        pass
    return state


def ms_end_temporary_stack_target_selection(context, state):
    state = state or {}
    try:
        return ms_set_exact_object_selection(context, state.get('selected_names') or [], state.get('active_name', ''))
    except Exception:
        return False


def ms_normalize_shape_proxy_visibility_selection(context, source_targets=None):
    """Keep curve/font/surface sources and their mesh proxies in their active-level display state.

    When a mesh-side modifier is active, the visible/selectable object is the
    generated mesh proxy; when Base Object is active, the visible/selectable
    object is the original shape.  This function preserves the user's selection
    while replacing hidden counterparts with the currently visible counterpart.
    """
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    if not vl:
        return False
    sources = []
    seen = set()
    for obj in (source_targets or []):
        source = None
        try:
            if ms_is_shape_mesh_proxy(obj):
                source = ms_shape_proxy_source(obj)
            else:
                source = get_main_object(obj) or obj
        except Exception:
            source = obj
        try:
            if source is not None and ms_is_shape_source_object(source):
                name = str(getattr(source, 'name', '') or '')
                if name and name not in seen:
                    seen.add(name)
                    sources.append(source)
        except Exception:
            pass
    if not sources:
        try:
            selected = list(getattr(context, 'selected_objects', []) or [])
        except Exception:
            selected = []
        try:
            active = getattr(vl.objects, 'active', None)
            if active is not None and active not in selected:
                selected.append(active)
        except Exception:
            pass
        for obj in selected:
            source = None
            try:
                if ms_is_shape_mesh_proxy(obj):
                    source = ms_shape_proxy_source(obj)
                else:
                    source = get_main_object(obj) or obj
            except Exception:
                source = obj
            try:
                if source is not None and ms_is_shape_source_object(source):
                    name = str(getattr(source, 'name', '') or '')
                    if name and name not in seen:
                        seen.add(name)
                        sources.append(source)
            except Exception:
                pass
    if not sources:
        return False
    try:
        selected_names, active_name = _ms_snapshot_object_selection(vl)
    except Exception:
        selected_names, active_name = [], ''
    selected_set = set(selected_names or [])
    changed = False
    active_new = active_name
    for source in sources:
        try:
            active_id = ms_get_ui_active_id(source)
        except Exception:
            active_id = 'BASE'
        try:
            visible_target = ms_shape_sync_visibility_for_active(source, context=context, active_id=active_id)
        except Exception:
            visible_target = None
        if visible_target is None:
            continue
        try:
            proxy = ms_shape_get_mesh_proxy(source, context=context, create=False, migrate=False)
        except Exception:
            proxy = None
        names = {str(getattr(source, 'name', '') or '')}
        if proxy is not None:
            names.add(str(getattr(proxy, 'name', '') or ''))
        visible_name = str(getattr(visible_target, 'name', '') or '')
        if not visible_name:
            continue
        if selected_set.intersection(names):
            selected_set.difference_update(names)
            selected_set.add(visible_name)
            changed = True
        if active_name in names:
            active_new = visible_name
            changed = True
    if changed:
        try:
            ordered = [n for n in (selected_names or []) if n in selected_set]
            for n in selected_set:
                if n not in ordered:
                    ordered.append(n)
            ms_set_exact_object_selection(context, ordered, active_new)
        except Exception:
            pass
    return changed


def ms_capture_mode_bridge_state(context):
    """Capture raw edit selection and a normalized main-object execution selection."""
    state = {
        'mode': str(getattr(context, 'mode', '') or ''),
        'raw_selected_names': [],
        'raw_active_name': '',
        'raw_edit_object_names': [],
        'exec_selected_names': [],
        'exec_active_name': '',
    }
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    raw_selected_objs = []
    if vl:
        try:
            raw_selected_names, raw_active_name = _ms_snapshot_object_selection(vl)
        except Exception:
            raw_selected_names, raw_active_name = [], ''
        state['raw_selected_names'] = list(raw_selected_names or [])
        state['raw_active_name'] = str(raw_active_name or '')
        for n in (raw_selected_names or []):
            try:
                obj = vl.objects.get(n)
            except Exception:
                obj = None
            if obj is not None:
                raw_selected_objs.append(obj)
    raw_active = None
    try:
        raw_active = bpy.data.objects.get(state['raw_active_name']) if state['raw_active_name'] else getattr(context, 'active_object', None)
    except Exception:
        raw_active = getattr(context, 'active_object', None)
    if raw_active is not None and raw_active not in raw_selected_objs:
        raw_selected_objs.append(raw_active)
    try:
        state['raw_edit_object_names'] = [o.name for o in list(getattr(context, 'objects_in_mode', None) or []) if o]
    except Exception:
        state['raw_edit_object_names'] = []

    resolved = []
    seen = set()
    for obj in raw_selected_objs:
        try:
            main = get_main_object(obj) or obj
        except Exception:
            main = obj
        name = str(getattr(main, 'name', '') or '')
        if not name or name in seen:
            continue
        seen.add(name)
        resolved.append(main)
    if not resolved and raw_active is not None:
        try:
            main = get_main_object(raw_active) or raw_active
        except Exception:
            main = raw_active
        name = str(getattr(main, 'name', '') or '')
        if name:
            resolved = [main]
    state['exec_selected_names'] = [str(getattr(o, 'name', '') or '') for o in resolved if o]
    try:
        exec_active = get_main_object(raw_active) or raw_active
    except Exception:
        exec_active = raw_active
    state['exec_active_name'] = str(getattr(exec_active, 'name', '') or '')
    if not state['exec_active_name'] and state['exec_selected_names']:
        state['exec_active_name'] = state['exec_selected_names'][0]
    return state


def ms_enter_object_mode_bridge(context, bridge_state):
    """Normalize selection to main objects and leave edit mode for stack-add execution."""
    state = bridge_state or {}
    mode = str(state.get('mode', '') or '')
    if not mode.startswith('EDIT'):
        return False
    if mode == 'EDIT_MESH':
        try:
            ms_capture_selection_to_cache_all(context)
        except Exception:
            try:
                ms_capture_selection_to_cache(context)
            except Exception:
                pass
    try:
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
    except Exception:
        pass
    try:
        ms_set_exact_object_selection(context, state.get('exec_selected_names') or [], state.get('exec_active_name', ''))
    except Exception:
        pass
    return True


def ms_restore_mode_bridge(context, bridge_state):
    """Restore the original edit-mode object set when a bridged stack-add finishes."""
    state = bridge_state or {}
    mode = str(state.get('mode', '') or '')
    if not mode.startswith('EDIT'):
        return False
    restore_selected = list(state.get('raw_edit_object_names') or [])
    restore_active = str(state.get('raw_active_name', '') or '')
    if restore_active and restore_active not in restore_selected:
        restore_selected.append(restore_active)
    if not restore_selected:
        restore_selected = list(state.get('exec_selected_names') or [])
    if not restore_active:
        restore_active = str(state.get('exec_active_name', '') or '')

    ok = False
    try:
        ok = ms_set_exact_object_selection(context, restore_selected, restore_active)
    except Exception:
        ok = False
    if not ok:
        try:
            ok = ms_set_exact_object_selection(context, state.get('exec_selected_names') or [], state.get('exec_active_name', ''))
        except Exception:
            ok = False
    try:
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='EDIT')
        return True
    except Exception:
        return False



def ms_stack_popup_prepare_object_mode(context):
    """Temporarily leave Edit Mode for right-side stack popup operations."""
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''
    if not mode.startswith('EDIT'):
        return None
    try:
        state = ms_capture_mode_bridge_state(context)
    except Exception:
        state = {'mode': mode}
    try:
        ms_enter_object_mode_bridge(context, state)
    except Exception:
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        except Exception:
            pass
    return state


def _ms_stack_popup_filter_restore_names_for_mode(context, names, active_name, mode):
    mode = str(mode or '')
    type_map = {
        'EDIT_MESH': {'MESH'},
        'EDIT_CURVE': {'CURVE'},
        'EDIT_SURFACE': {'SURFACE'},
        'EDIT_TEXT': {'FONT'},
        'EDIT_ARMATURE': {'ARMATURE'},
        'EDIT_METABALL': {'META'},
        'EDIT_LATTICE': {'LATTICE'},
        'EDIT_GREASE_PENCIL': {'GREASEPENCIL'},
    }
    allowed = type_map.get(mode)
    if not allowed:
        return list(names or []), str(active_name or '')
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    out = []
    seen = set()
    for name in list(names or []):
        try:
            obj = vl.objects.get(str(name)) if vl else bpy.data.objects.get(str(name))
        except Exception:
            obj = None
        if obj is None:
            continue
        if str(getattr(obj, 'type', '') or '') not in allowed:
            continue
        obj_name = str(getattr(obj, 'name', '') or '')
        if obj_name and obj_name not in seen:
            seen.add(obj_name)
            out.append(obj_name)
    active = str(active_name or '')
    if active:
        try:
            active_obj = vl.objects.get(active) if vl else bpy.data.objects.get(active)
        except Exception:
            active_obj = None
        if active_obj is None or str(getattr(active_obj, 'type', '') or '') not in allowed:
            active = ''
    if not active and out:
        active = out[0]
    return out, active


def ms_stack_popup_restore_mode(context, bridge_state, *, use_current_selection=False):
    """Return to the Edit Mode that was active before a stack popup operation."""
    if not bridge_state:
        return False
    try:
        if str(getattr(context, 'mode', '') or '').startswith('EDIT'):
            return True
    except Exception:
        pass
    state = bridge_state
    try:
        if use_current_selection:
            state = dict(bridge_state)
            try:
                vl = getattr(context, 'view_layer', None)
            except Exception:
                vl = None
            try:
                names, active = _ms_snapshot_object_selection(vl) if vl else ([], '')
            except Exception:
                names, active = [], ''
            names, active = _ms_stack_popup_filter_restore_names_for_mode(context, names, active, state.get('mode', ''))
            if names:
                state['raw_edit_object_names'] = list(names)
                state['raw_selected_names'] = list(names)
                state['raw_active_name'] = active or names[0]
    except Exception:
        state = bridge_state
    try:
        return ms_restore_mode_bridge(context, state)
    except Exception:
        return False

def _ms_ensure_object_selection(vl, selected_names):
    """Ensure the given object names are selected. Never deselects anything."""
    if not vl or not selected_names:
        return
    for n in selected_names:
        try:
            o = vl.objects.get(n)
        except Exception:
            o = None
        if not o:
            continue
        try:
            try:
                o.hide_set(False)
                if _ms_is_internal_visibility_helper_object(o):
                    if hasattr(o, "hide_viewport"):
                        o.hide_viewport = False
                    if hasattr(o, "hide_select"):
                        o.hide_select = False
            except Exception:
                pass
            o.select_set(True)
        except Exception:
            pass

def ms_get_stack_order():
    prefs = _ms_get_addon_prefs()
    return (prefs.stack_order if prefs and hasattr(prefs, "stack_order") else 'TOP_DOWN')

def ms_calc_insert_index_bottom(main_obj, pre_add=False):
    if not main_obj: return 0, 0
    mods_len = len(main_obj.modifiers)
    order = ms_get_stack_order()
    if order == 'BOTTOM_UP':
        internal = 0
        ui_row = max(0, mods_len - 1)
    else:
        internal = mods_len
        ui_row = mods_len
    if pre_add: return max(0, min(mods_len, internal)), ui_row
    return max(0, min(max(0, mods_len - 1), internal)), ui_row

def ms_calc_insert_index_above_active(main_obj, pre_add=False):
    if not main_obj: return 0, 0
    mods_len = len(main_obj.modifiers)
    ui_id = ms_get_ui_active_id(main_obj)
    prefs = _ms_get_addon_prefs()
    order = prefs.stack_order if prefs and hasattr(prefs, "stack_order") else 'TOP_DOWN'

    internal_idx = -1
    if ui_id != "BASE":
        idx_cand = main_obj.modifiers.find(ui_id)
        if idx_cand >= 0: internal_idx = idx_cand

    target = internal_idx + 1
    ui_insert_pos = (mods_len - target) if order == 'BOTTOM_UP' else target
    if pre_add: return max(0, min(mods_len, target)), ui_insert_pos
    return max(0, min(target, max(0, mods_len - 1))), ui_insert_pos


def ms_calc_target_insert_index(master_obj, target_obj, context=None, master_ui_id_override=None):
    """Return the Blender modifier index where a newly added stack item belongs.

    Smart Modifier's stack has a virtual Base Object row followed by Blender's
    real modifiers.  New items must always be inserted one slot *below* the
    currently active stack row:

    - Base Object active  -> index 0, directly before the first real modifier.
    - Modifier active     -> index after the matching active modifier.

    For multi-object instance workflows, the active row on the master object is
    translated to the corresponding instance on each target object.
    """
    if not master_obj or not target_obj:
        return 0
    try:
        target_mods = getattr(target_obj, "modifiers", None)
        if target_mods is None:
            return 0
    except Exception:
        return 0

    try:
        master_ui_id = str(master_ui_id_override or ms_get_ui_active_id(master_obj) or "BASE")
    except Exception:
        master_ui_id = "BASE"

    # Base Object is a virtual row above the first user modifier.  Shape mesh
    # proxies keep an internal Curve-to-Mesh converter at index 0, so user
    # modifiers must be inserted after that hidden bridge.
    if master_ui_id == "BASE":
        return ms_shape_user_insert_index(target_obj, 0)

    try:
        master_stack_obj = ms_get_modifier_stack_object(master_obj, context=context, create=False) or master_obj
    except Exception:
        master_stack_obj = master_obj

    try:
        m_mod = master_stack_obj.modifiers.get(master_ui_id)
    except Exception:
        m_mod = None
    if not m_mod:
        try:
            return ms_shape_user_insert_index(target_obj, len(target_mods))
        except Exception:
            return 0

    try:
        master_active_iid = ms_get_instance_id(m_mod, master_obj)
    except Exception:
        master_active_iid = ""

    if master_active_iid:
        try:
            ref_mod = ms_find_modifier_by_instance_id(target_obj, master_active_iid)
        except Exception:
            ref_mod = None
        if ref_mod:
            try:
                return ms_shape_user_insert_index(target_obj, list(target_mods).index(ref_mod) + 1)
            except Exception:
                pass

    try:
        ref_mod = target_mods.get(master_ui_id)
    except Exception:
        ref_mod = None
    if ref_mod:
        try:
            return ms_shape_user_insert_index(target_obj, list(target_mods).index(ref_mod) + 1)
        except Exception:
            pass

    try:
        master_idx = list(master_stack_obj.modifiers).index(m_mod)
        return ms_shape_user_insert_index(target_obj, max(0, min(len(target_mods), master_idx + 1)))
    except Exception:
        try:
            return ms_shape_user_insert_index(target_obj, len(target_mods))
        except Exception:
            return 0

# ==========================================
# Stack insertion policy helpers
# ==========================================

def ms_calc_insert_index_above_active_add(main_obj, pre_add=False):
    return ms_calc_insert_index_above_active(main_obj, pre_add=pre_add)[0]

def apply_modifier_stack_state(main_obj, context, interactive=True):
    global _MS_SYNC_LOCK
    ms_ensure_show_end_result_default_off(main_obj)
    if not main_obj or _MS_SYNC_LOCK: return
    _MS_SYNC_LOCK = True
    _ms_set_shared_lock(True)
    try:
        vl = getattr(context, "view_layer", None)
        wm = getattr(context, "window_manager", None)
        interactive = False if ms_is_multi_mode(context) else bool(interactive)
        
        dn_bg = _ms__dn()
        bg_sync = bool(dn_bg.get('_MS_BG_SYNC_V1', False))
        if interactive: ms_capture_selection_to_cache(context)

        try:
            _pre_ui_id = str(main_obj.get("ui_active_item", "BASE") or "BASE")
        except Exception:
            _pre_ui_id = "BASE"
        try:
            stack_obj = ms_get_modifier_stack_object(main_obj, context=context, create=bool(ms_is_shape_source_object(main_obj) and _pre_ui_id != "BASE")) or main_obj
        except Exception:
            stack_obj = main_obj

        ui_active_id = ms_get_ui_active_id(main_obj)
        effective_active_id = ms_get_effective_active_id(main_obj, ui_active_id)
        try:
            configured_restore_mode = ms_get_auto_disable_restore_mode(context)
        except Exception:
            configured_restore_mode = 'PRESERVE'
        try:
            configured_force_channels = ms_get_auto_disable_force_enable_channels(context)
        except Exception:
            configured_force_channels = {'cage': True, 'edit': True, 'vp': True, 'render': True}

        # --- Fast path: skip re-applying identical state repeatedly (selection/mode spam) ---
        try:
            dn = _ms__dn()
            now = time.time()
            root = dn.get("_MS_APPLY_STATE_SIG_V1")
            if not isinstance(root, dict):
                root = {}
            dirty_rev = _ms_get_dirty_rev(dn, main_obj.name)
            sig = (ui_active_id, effective_active_id,
                   bool(getattr(main_obj, "ms_show_end_result", False)),
                   bool(ms_auto_disable_modifiers_enabled(main_obj)),
                   str(configured_restore_mode),
                   tuple(bool(configured_force_channels.get(ch, True)) for ch in ('cage', 'edit', 'vp', 'render')),
                   str(getattr(context, "mode", "OBJECT")),
                   int(dirty_rev))
            prev = root.get(main_obj.name)
            if (not interactive) and isinstance(prev, (tuple, list)) and len(prev) == 2:
                prev_sig, prev_t = prev
                try:
                    if prev_sig == sig and (now - float(prev_t or 0.0)) < 0.25:
                        # When the property panel is open, do not skip: we need realtime preview refresh.
                        if not bool(getattr(main_obj, "ms_show_properties", False)):
                            force_map = None
                            t_force = 0.0
                            try:
                                dn_force = _ms__dn()
                                force_map = dn_force.get('_MS_FORCE_APPLY_ONCE_V1')
                                if isinstance(force_map, dict):
                                    t_force = float(force_map.get(main_obj.name, 0.0) or 0.0)
                            except Exception:
                                force_map = None
                            # If forced apply is requested recently, do not skip this call.
                            if (not isinstance(force_map, dict)) or ((now - t_force) >= 3.0):
                                return
                except Exception:
                    pass
            root[main_obj.name] = (sig, now)
            dn["_MS_APPLY_STATE_SIG_V1"] = root
        except Exception:
            pass
        
        main_obj["ui_active_item"] = ui_active_id
        ms_refresh_ui_active_index(main_obj)

        # Non-mesh assets such as cameras, lights, empties, speakers and
        # collection instances may not expose a native Object.modifiers
        # collection.  They still use the Base Object data panel, but there is no
        # modifier level to apply.  Exit before touching modifier-specific state.
        if not ms_object_has_modifier_collection(stack_obj):
            try:
                main_obj["ui_active_item"] = "BASE"
                ms_set_ui_active_index(main_obj, -1)
            except Exception:
                pass
            try:
                ms_endpreview_set_allowed(main_obj, False)
                ms_request_endpreview_global_purge("non_modifier_asset")
            except Exception:
                pass
            return

        show_end = getattr(main_obj, "ms_show_end_result", False)
        auto_disable_modifiers = bool(ms_auto_disable_modifiers_enabled(main_obj))
        prev_show_end = bool(main_obj.get("_MS_PREVIEW_PREV_SHOW_END_V1", True))

        # In Edit Mode, Modifier Auto Disable shows the editable mesh only up to
        # the active stack item. Show End Result can then display the final result
        # as a separate, non-editable EndPreview mesh. When Modifier Auto Disable
        # is OFF, Smart Modifier keeps the manually enabled modifier stack visible
        # and does not mute later/below stack items because of the active slot.
        force_level_view = auto_disable_modifiers and ((getattr(context, "mode", "OBJECT") != "OBJECT") or bool(interactive))
        full_flags = {}
        restore_flags = {}

        active_idx = stack_obj.modifiers.find(effective_active_id) if effective_active_id != "BASE" else -1

        try:
            prev_auto_for_backup = bool(main_obj.get("_MS_PREV_AUTO_DISABLE_MODIFIERS_V1", auto_disable_modifiers))
        except Exception:
            prev_auto_for_backup = bool(auto_disable_modifiers)
        try:
            if (not bool(auto_disable_modifiers)) and (not bool(prev_auto_for_backup)):
                _ms_capture_modifier_display_backups_from_actual(stack_obj)
            else:
                _ms_ensure_modifier_display_backups(stack_obj, active_idx=active_idx, auto_disable=auto_disable_modifiers)
        except Exception:
            pass

        edit_effective_id = ms_find_nearest_edit_source_id(main_obj, effective_active_id, active_idx)
        carrier_key = ms_get_carrier_key_for_effective(main_obj, edit_effective_id)

        try:
            _auto_original_display = _ms_auto_disable_original_display_map(stack_obj)
            if not isinstance(_auto_original_display, dict):
                _auto_original_display = {}
        except Exception:
            _auto_original_display = {}
        _auto_original_display_changed = False
        try:
            _auto_forced_display = _ms_auto_disable_forced_display_map(stack_obj)
            if not isinstance(_auto_forced_display, dict):
                _auto_forced_display = {}
        except Exception:
            _auto_forced_display = {}
        _auto_forced_display_changed = False
        try:
            _auto_last_suppressed_display = _ms_auto_disable_suppressed_display_map(stack_obj)
            if not isinstance(_auto_last_suppressed_display, dict):
                _auto_last_suppressed_display = {}
        except Exception:
            _auto_last_suppressed_display = {}
        _auto_last_suppressed_display_changed = False

        # Restoration is transition-based: selected channels are forced ON only
        # when a row actually leaves Auto Disable suppression.  Normal redraws do
        # not continuously overwrite a user's later manual visibility changes.
        _auto_restore_mode = configured_restore_mode
        _auto_force_channels = configured_force_channels
        _auto_force_on_restore = bool(auto_disable_modifiers) and _auto_restore_mode == 'FORCE_ENABLE'

        def _ms_auto_entry_for(root, mod_name):
            try:
                entry = root.get(mod_name) if isinstance(root, dict) else None
                return entry if isinstance(entry, dict) else {}
            except Exception:
                return {}

        # Rows disabled by this suite retain their manual state until re-enabled.
        # Native header edits on other rows must win over old saved snapshots.
        _suite_muted = _ms_json_prop_dict(stack_obj, 'ms_mod_suite_muted_display')

        def _ms_auto_manual_value(mod_obj, channel):
            normalized, spec = _ms_modifier_display_channel_spec(channel)
            if not normalized or not spec or not _ms_modifier_supports_display_channel(mod_obj, normalized):
                return None
            attr, _backup_key, default, _kw = spec
            try:
                actual_value = bool(getattr(mod_obj, attr, default))
            except Exception:
                actual_value = bool(default)
            # Auto Disable only writes OFF.  Therefore a live ON is always a
            # trustworthy current manual state, even when a stale snapshot exists.
            if actual_value:
                return True
            for root in (_auto_original_display, _auto_forced_display, _auto_last_suppressed_display):
                entry = _ms_auto_entry_for(root, mod_obj.name)
                if normalized in entry:
                    return bool(entry.get(normalized, default))
            if (get_mod_enabled_state(stack_obj, mod_obj.name)
                    and not _suite_muted.get(mod_obj.name, False)):
                return actual_value
            try:
                found, backup_value = _ms_find_manual_display_backup(stack_obj, mod_obj.name, normalized, default)
                if found:
                    return bool(backup_value)
            except Exception:
                pass
            return bool(actual_value)

        def _ms_auto_snapshot(mod_obj):
            values = {}
            for channel in ('vp', 'edit', 'cage', 'render'):
                value = _ms_auto_manual_value(mod_obj, channel)
                if value is not None:
                    values[channel] = bool(value)
            return values

        def _ms_store_manual_values(mod_name, values):
            if not isinstance(values, dict):
                return
            _ms_set_manual_display_backup(
                stack_obj,
                mod_name,
                viewport=values.get('vp') if 'vp' in values else None,
                render=values.get('render') if 'render' in values else None,
                editmode=values.get('edit') if 'edit' in values else None,
                cage=values.get('cage') if 'cage' in values else None,
            )

        for i, mod in enumerate(stack_obj.modifiers):
            is_enabled = get_mod_enabled_state(stack_obj, mod.name)
            try:
                is_auto_suppressed = bool(auto_disable_modifiers) and (int(i) > int(active_idx))
            except Exception:
                is_auto_suppressed = False

            original_entry = _ms_auto_entry_for(_auto_original_display, mod.name)
            forced_entry = _ms_auto_entry_for(_auto_forced_display, mod.name)
            last_entry = _ms_auto_entry_for(_auto_last_suppressed_display, mod.name)
            was_auto_suppressed = bool(original_entry or forced_entry or last_entry)
            manual_values = _ms_auto_snapshot(mod)
            if is_enabled:
                _suite_muted.pop(mod.name, None)
            else:
                _suite_muted[mod.name] = True

            if is_auto_suppressed:
                # Capture all four modifier-header states before muting the row.
                # Existing snapshots win over temporary RNA OFF values; a live ON
                # still updates the snapshot through _ms_auto_manual_value above.
                snapshot = dict(manual_values)
                _ms_store_manual_values(mod.name, snapshot)

                if _auto_original_display.get(mod.name) != snapshot:
                    _auto_original_display[mod.name] = dict(snapshot)
                    _auto_original_display_changed = True
                if _auto_forced_display.get(mod.name) != snapshot:
                    _auto_forced_display[mod.name] = dict(snapshot)
                    _auto_forced_display_changed = True
                if _auto_last_suppressed_display.get(mod.name) != snapshot:
                    _auto_last_suppressed_display[mod.name] = dict(snapshot)
                    _auto_last_suppressed_display_changed = True

                full_want = bool(snapshot.get('vp', True)) if bool(is_enabled) else False
                full_flags[mod.name] = full_want
                restore_flags[mod.name] = False
                _ms_assign_modifier_display_values(mod, snapshot, suppressed=True)
                continue

            if was_auto_suppressed:
                # The row has moved back into the active evaluation range.  Restore
                # the saved state exactly, then optionally force only the selected
                # channels ON.  Turning Auto Disable itself OFF always preserves the
                # original state and never applies the force policy.
                restored_values = dict(manual_values)
                if _auto_force_on_restore:
                    for channel, selected in (_auto_force_channels or {}).items():
                        if bool(selected) and _ms_modifier_supports_display_channel(mod, channel):
                            restored_values[channel] = True
                manual_values = restored_values
                _ms_store_manual_values(mod.name, manual_values)

                if mod.name in _auto_original_display:
                    _auto_original_display.pop(mod.name, None)
                    _auto_original_display_changed = True
                if mod.name in _auto_forced_display:
                    _auto_forced_display.pop(mod.name, None)
                    _auto_forced_display_changed = True
                if mod.name in _auto_last_suppressed_display:
                    _auto_last_suppressed_display.pop(mod.name, None)
                    _auto_last_suppressed_display_changed = True
            else:
                # Keep the canonical backups current for normal, unsuppressed rows.
                _ms_store_manual_values(mod.name, manual_values)

            full_want = bool(manual_values.get('vp', True)) if bool(is_enabled) else False
            full_render_want = bool(manual_values.get('render', True)) if bool(is_enabled) else False
            full_flags[mod.name] = full_want
            restore_flags[mod.name] = full_want

            live_values = dict(manual_values)
            if 'vp' in live_values:
                live_values['vp'] = full_want
            if 'render' in live_values:
                live_values['render'] = full_render_want
            _ms_assign_modifier_display_values(mod, live_values, suppressed=False)

        try:
            _existing_names = {m.name for m in stack_obj.modifiers}
            _ms_set_json_prop_dict(stack_obj, 'ms_mod_suite_muted_display',
                                   {n: True for n in _suite_muted if n in _existing_names})
            for _name in list(_auto_original_display.keys()):
                if _name not in _existing_names:
                    _auto_original_display.pop(_name, None)
                    _auto_original_display_changed = True
            for _name in list(_auto_forced_display.keys()):
                if _name not in _existing_names:
                    _auto_forced_display.pop(_name, None)
                    _auto_forced_display_changed = True
            for _name in list(_auto_last_suppressed_display.keys()):
                if _name not in _existing_names:
                    _auto_last_suppressed_display.pop(_name, None)
                    _auto_last_suppressed_display_changed = True
            if _auto_original_display_changed:
                _ms_set_auto_disable_original_display_map(stack_obj, _auto_original_display)
            if _auto_forced_display_changed:
                _ms_set_auto_disable_forced_display_map(stack_obj, _auto_forced_display)
            if _auto_last_suppressed_display_changed:
                _ms_set_auto_disable_suppressed_display_map(stack_obj, _auto_last_suppressed_display)
        except Exception:
            pass

        try: main_obj["_MS_PREVIEW_PREV_SHOW_END_V1"] = bool(show_end)
        except Exception: pass
        try: main_obj["_MS_PREV_AUTO_DISABLE_MODIFIERS_V1"] = bool(auto_disable_modifiers)
        except Exception: pass

        # EndPreview (ephemeral): update only when Show Final Result is enabled
        # and this edit session was explicitly allowed by Smart Modifier / a stack plugin.
        # The editable object itself stays at the active stack level; EndPreview shows
        # the fully evaluated result after every enabled modifier in stack order.
        preview_context_live = ms_preview_context_allows_collections(main_obj, context)
        allowed_preview = bool(auto_disable_modifiers) and bool(show_end) and bool(ms_endpreview_is_allowed(main_obj)) and bool(preview_context_live)
        if not allowed_preview:
            try:
                ms_endpreview_set_allowed(main_obj, False)
                ms_request_endpreview_global_purge("apply_context_not_allowed")
            except Exception:
                pass
        if allowed_preview:
            try:
                dirty_rev2 = _ms_get_dirty_rev(_ms__dn(), main_obj.name)
                sig = f"{main_obj.name}|{ui_active_id}|{effective_active_id}|{edit_effective_id}|{carrier_key}|{active_idx}|{dirty_rev2}|"
                try:
                    sig += "".join(("1" if full_flags.get(m.name, False) else "0") for m in stack_obj.modifiers)
                    sig += "|"
                    sig += "".join(("1" if restore_flags.get(m.name, False) else "0") for m in stack_obj.modifiers)
                except Exception:
                    pass
                ms_update_end_preview_mesh(main_obj, context, full_flags, restore_flags, sig, force=bool(getattr(main_obj, "ms_show_properties", False)))
            except Exception:
                pass

        # Background sync: do not alter helper visibility/selection/mode; only modifier viewport flags above were applied.
        if bg_sync:
            return

        target_obj = main_obj
        edit_targets_for_edit = None
        best_pri = -10**9
        hide_main_request = False

        # --- Housekeeping sync: plugins may opt-in to always_sync to manage helper objects
        #     even when they are not the current edit source (e.g. SmartLattice helper visibility).
        try:
            carrier_key_eff = ms_get_carrier_key_for_effective(main_obj, effective_active_id)
            for _p in ms_get_plugins_sorted():
                if not bool(_p.get("always_sync", False)):
                    continue
                _fn = _p.get("sync_objects")
                if callable(_fn):
                    try:
                        _fn(main_obj, context, effective_active_id, carrier_key_eff, show_end, False)
                    except Exception:
                        pass
        except Exception:
            pass

        sync_mod_obj = stack_obj.modifiers.get(edit_effective_id) if edit_effective_id != "BASE" else None
        plugin_stack_obj = stack_obj if (stack_obj is not None and stack_obj != main_obj and ms_is_shape_source_object(main_obj)) else main_obj
        for p in ms_get_plugins_sorted():
            # When editing the Base object level, ignore plugins unless they explicitly opt-in.
            # Shape mesh-proxy stacks still call mesh-side plugins with BASE so helper objects
            # created on the proxy can be hidden when the original shape becomes active again.
            if edit_effective_id == "BASE" and plugin_stack_obj == main_obj and not bool(p.get("supports_base", False)):
                continue
            fn = p.get("sync_objects")
            if not callable(fn): continue
            if sync_mod_obj is not None:
                mfn = p.get("match_modifier")
                if not callable(mfn): continue
                try:
                    if not mfn(sync_mod_obj): continue
                except Exception: continue
            try: res = fn(plugin_stack_obj, context, edit_effective_id, carrier_key, show_end, interactive)
            except Exception: res = None
            if isinstance(res, dict) and res.get("target_obj"):
                pri = int(res.get("priority", 0) or 0)
                if pri >= best_pri:
                    best_pri = pri
                    target_obj = res.get("target_obj") or target_obj
                    if res.get("hide_main"): hide_main_request = True

        try:
            helpers = None
            try:
                dn = _ms__dn()
                fn = None
                for k in ("_EP_HELPERS_FOR_MAIN_V1", "_EP_LIST_HELPERS_V1", "_EP_ITER_HELPERS_V1"):
                    cand = dn.get(k)
                    if callable(cand):
                        fn = cand; break
                if fn: helpers = fn(main_obj.name)
            except Exception: helpers = None

            if helpers is None: raise RuntimeError("No EP helper API")

            for ob in helpers:
                if not ob or ob == main_obj or ob == target_obj: continue
                try:
                    try: ob.select_set(False)
                    except Exception: pass
                    _ms_set_obj_hidden(ob, True, True)
                except Exception: pass
        except Exception:
            try:
                for ob in bpy.data.objects:
                    if ob != main_obj and ob != target_obj and ob.get("ep_main_target") == main_obj.name:
                        try:
                            try: ob.select_set(False)
                            except Exception: pass
                            _ms_set_obj_hidden(ob, True, True)
                        except Exception: pass
            except Exception: pass

        try:
            _shape_target = ms_shape_sync_visibility_for_active(main_obj, context=context, active_id=effective_active_id)
            if _shape_target is not None:
                # For standard mesh-side modifiers, edit the generated mesh proxy.
                # For plugin modifiers such as Smart Lattice, keep the plugin-provided
                # helper edit target while still syncing source/proxy visibility.
                if target_obj is None or target_obj is main_obj or target_obj is stack_obj:
                    target_obj = _shape_target
                    hide_main_request = bool(target_obj is not main_obj)
                elif _shape_target is not main_obj:
                    hide_main_request = True
        except Exception:
            pass

        try: _ = target_obj.name
        except ReferenceError: target_obj = main_obj

        if target_obj and target_obj != main_obj and hide_main_request:
            _ms_set_obj_hidden(main_obj, True, True)
        else:
            _ms_set_obj_hidden(main_obj, False, False)

        try:
            if target_obj and hasattr(target_obj, "display_type"): target_obj.display_type = 'SOLID'
        except Exception: pass
        try:
            if target_obj == main_obj:
                if hasattr(main_obj, "display_type"): main_obj.display_type = 'SOLID'
        except Exception: pass

        if effective_active_id != "BASE":
            mod = stack_obj.modifiers.get(effective_active_id)
            if mod: stack_obj.modifiers.active = mod

        if interactive and vl:
            if getattr(context, "mode", "OBJECT") != 'OBJECT':
                try: bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
                except Exception: pass
                if getattr(context, "mode", "OBJECT") != 'OBJECT':
                    try: vl.objects.active = main_obj; bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
                    except Exception: pass

            ms_call_plugins("post_object_mode", main_obj, context, edit_effective_id)
            ms_call_plugins("on_stack_change", main_obj, context, interactive)

            if target_obj and target_obj != main_obj and hide_main_request:
                pass
            else:
                _ms_set_obj_hidden(main_obj, False, False)
            
            # Preserve user's selection: never deselect existing objects.
            
            _orig_sel_names, _orig_active_name = _ms_snapshot_object_selection(vl)
            
            if _orig_sel_names:
            
                _ms_ensure_object_selection(vl, _orig_sel_names)
            if target_obj and target_obj != main_obj:
                edit_targets_for_edit = [target_obj]
                try:
                    cm = stack_obj.modifiers.get(carrier_key) if carrier_key and carrier_key != "BASE" else None
                    if ms_is_multi_mode(context) and cm and ms_is_instance_modifier(cm, main_obj) and ms_plugin_is_edit_source(main_obj, cm):
                        iid = ms_get_instance_id(cm, main_obj)
                        if iid:
                            tmp = []
                            for o2, m2 in ms_iter_instance_members(iid):
                                try:
                                    ng = getattr(m2, "node_group", None)
                                    en = ng.get("ep_edit_mesh") if ng else None
                                    eo = bpy.data.objects.get(en) if en else None
                                    if eo:
                                        _ms_set_obj_hidden(eo, False, False)
                                        tmp.append(eo)
                                except Exception: continue
                            if tmp: edit_targets_for_edit = tmp
                except Exception: pass

                for eo in edit_targets_for_edit:
                    try: eo.select_set(True)
                    except Exception: pass

                try: vl.objects.active = target_obj if target_obj in edit_targets_for_edit else (edit_targets_for_edit[0] if edit_targets_for_edit else target_obj)
                except Exception: pass
            else:
                edit_targets_for_edit = None
                main_obj.select_set(True)
                vl.objects.active = main_obj

        # Safety: sometimes selection can end up empty (e.g. helper creation timing). Keep at least the main object selected.
        if interactive:
            try:
                vl2 = getattr(context, 'view_layer', None)
                if vl2:
                    any_sel = False
                    try:
                        any_sel = any(o.select_get() for o in vl2.objects)
                    except Exception:
                        any_sel = False
                    if (not any_sel) or (vl2.objects.active is None):
                        try:
                            main_obj.hide_set(False)
                            if _ms_is_internal_visibility_helper_object(main_obj):
                                if hasattr(main_obj, "hide_viewport"):
                                    main_obj.hide_viewport = False
                                if hasattr(main_obj, "hide_select"):
                                    main_obj.hide_select = False
                        except Exception:
                            pass
                        try:
                            main_obj.select_set(True)
                            vl2.objects.active = main_obj
                        except Exception:
                            pass
            except Exception:
                pass

        main_obj.update_tag()
        if target_obj and target_obj != main_obj: target_obj.update_tag()

        if interactive and target_obj:
            # Ensure a valid active object before switching to Edit Mode
            try:
                if vl:
                    try: vl.objects.active = target_obj
                    except Exception: vl.objects.active = main_obj
            except Exception:
                pass
            ms__safe_mode_set(context, target_obj or main_obj, 'EDIT')
            if edit_targets_for_edit and isinstance(edit_targets_for_edit, (list, tuple)) and len(edit_targets_for_edit) > 1:
                try: active_eo = vl.objects.active if vl else target_obj
                except Exception: active_eo = target_obj
                try: ms_apply_selection_for_carrier(main_obj, active_eo or target_obj, carrier_key)
                except Exception: pass
                for eo in edit_targets_for_edit:
                    if eo is None or eo == active_eo: continue
                    try: ms_apply_selection_for_carrier(main_obj, eo, carrier_key)
                    except Exception: pass
            else:
                ms_apply_selection_for_carrier(main_obj, target_obj, carrier_key)
            target_obj.update_tag()

        if wm:
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D': area.tag_redraw()
    finally:
        # Timestamp for external deterministic switchers.
        # (If this function early-returns due to lock, timestamp won't advance.)
        try:
            dn = _ms__dn()
            mp = dn.get('_MS_LAST_APPLY_T_V1')
            if not isinstance(mp, dict):
                mp = {}
            mp[main_obj.name] = time.time()
            dn['_MS_LAST_APPLY_T_V1'] = mp
        except Exception:
            pass
        _ms_set_shared_lock(False)
        _MS_SYNC_LOCK = False
        try:
            from . import persistent_state as _sms_persistent_state
            save_request = getattr(_sms_persistent_state, 'request_save', None)
            if callable(save_request):
                # Respect the canonical N-panel State Save gate.  A forced
                # write here used to let these two object controls modify the
                # JSON even while the user had explicitly disabled saving.
                save_request(context, immediate=True)
        except Exception:
            pass

def update_auto_disable_modifiers_prop(self, context):
    try:
        if _ms__dn().get('_SMSM_TRANSFORM_GUARD_ACTIVE_V1'):
            return
    except Exception:
        pass
    try:
        from . import persistent_state as _ms_persistent_state
        if hasattr(_ms_persistent_state, 'is_applying') and _ms_persistent_state.is_applying():
            return
    except Exception:
        pass
    try:
        if not bool(ms_auto_disable_modifiers_enabled(self)):
            ms_endpreview_set_allowed(self, False)
            ms_request_endpreview_cleanup(self)
            ms_request_endpreview_global_purge("auto_disable_off")
        elif bool(getattr(self, "ms_show_end_result", False)) and ms_preview_context_allows_collections(self, context):
            ms_endpreview_set_allowed(self, True)
            ms_request_endpreview_live_sync()
    except Exception:
        pass
    apply_modifier_stack_state(self, context)


def update_show_end_result_prop(self, context):
    try:
        if _ms__dn().get('_SMSM_TRANSFORM_GUARD_ACTIVE_V1'):
            return
    except Exception:
        pass
    try:
        from . import persistent_state as _ms_persistent_state
        if hasattr(_ms_persistent_state, 'is_applying') and _ms_persistent_state.is_applying():
            return
    except Exception:
        pass
    try:
        if bool(getattr(self, "ms_show_end_result", False)) and bool(ms_auto_disable_modifiers_enabled(self)):
            if ms_preview_context_allows_collections(self, context):
                ms_endpreview_set_allowed(self, True)
                ms_request_endpreview_live_sync()
        else:
            # Show End Result OFF, or Modifier Auto Disable OFF, means the
            # EndPreview object/collection must not be generated or retained.
            # Purge through the safe timer path so UI panel handlers never keep a
            # reference to removed data.
            ms_endpreview_set_allowed(self, False)
            ms_request_endpreview_cleanup(self)
            reason = "auto_disable_off" if not bool(ms_auto_disable_modifiers_enabled(self)) else "show_end_result_off"
            ms_request_endpreview_global_purge(reason)
    except Exception:
        pass
    # Not interactive: pressing the eye must not leave Edit Mode.
    apply_modifier_stack_state(self, context, interactive=False)

def _ms_popup_do_move(self, context, direction):
    bridge_state = ms_stack_popup_prepare_object_mode(context)
    try:
        return _ms_popup_do_move_impl(self, context, direction)
    finally:
        ms_stack_popup_restore_mode(context, bridge_state)


def _ms_popup_do_move_impl(self, context, direction):
    mod_name = context.window_manager.ms_target_mod
    obj_name = context.window_manager.ms_target_obj
    obj = bpy.data.objects.get(obj_name)
    if not obj: return
    mod = obj.modifiers.get(mod_name) if mod_name else None
    if not mod: return

    prefs = _ms_get_addon_prefs(context)
    order = prefs.stack_order if prefs and hasattr(prefs, "stack_order") else 'TOP_DOWN'
    internal_dir = -1 if direction == 'UP' else 1
    if order == 'BOTTOM_UP': internal_dir *= -1

    if ms_is_instance_modifier(mod, obj):
        iid = ms_get_instance_id(mod, obj)
        for o, m in ms_iter_instance_members(iid):
            try:
                cur = list(o.modifiers).index(m)
                tgt = cur + internal_dir
                safe_move_modifier(o, m.name, tgt)
            except Exception: pass
        main_obj = get_main_object(obj)
        ms_apply_state_post_action(context, main_obj, interactive_default=False)
        return

    try:
        current_idx = list(obj.modifiers).index(mod)
        target_idx = current_idx + internal_dir
        safe_move_modifier(obj, mod.name, target_idx)
    except Exception: pass
    
    main_obj = get_main_object(obj)
    ms_apply_state_post_action(context, main_obj, interactive_default=True)

def _ms_popup_move_up_update(self, context):
    if self.ms_move_up: _ms_popup_do_move(self, context, 'UP'); self.ms_move_up = False
        
def _ms_popup_move_down_update(self, context):
    if self.ms_move_down: _ms_popup_do_move(self, context, 'DOWN'); self.ms_move_down = False



# -----------------------------------------------------------------------------
# Inline stack-row rename plumbing (4.32.49)
#
# The editable field on the row writes into a WindowManager StringProperty.  Its
# update callback is the commit point, and it delegates to the existing
# ``object.ms_rename_modifier`` operator in EXEC_DEFAULT so the dialog invoke() is
# bypassed while the established disp_name / instance-propagation logic in
# ``_execute_core`` stays the single rename implementation.
# -----------------------------------------------------------------------------

_MS_INLINE_RENAME_SEEDING = False


def ms_inline_rename_is_active(wm, obj_name, mod_name):
    if wm is None or not obj_name or not mod_name:
        return False
    try:
        return (str(getattr(wm, "ms_inline_rename_obj", "") or "") == str(obj_name)
                and str(getattr(wm, "ms_inline_rename_mod", "") or "") == str(mod_name))
    except Exception:
        return False


def ms_inline_rename_clear(wm):
    """Leave inline-rename mode without committing anything."""
    global _MS_INLINE_RENAME_SEEDING
    if wm is None:
        return False
    previous = _MS_INLINE_RENAME_SEEDING
    _MS_INLINE_RENAME_SEEDING = True
    try:
        for attr in ("ms_inline_rename_obj", "ms_inline_rename_mod", "ms_inline_rename_value"):
            try:
                setattr(wm, attr, "")
            except Exception:
                pass
    finally:
        _MS_INLINE_RENAME_SEEDING = previous
    return True


def ms_inline_rename_begin(wm, obj, mod_name):
    """Enter inline-rename mode for one row, seeded with its current display name."""
    global _MS_INLINE_RENAME_SEEDING
    if wm is None or obj is None or not mod_name:
        return False
    try:
        seed = ms_obj_get_disp_name(obj, str(mod_name)) or str(mod_name)
    except Exception:
        seed = str(mod_name)
    previous = _MS_INLINE_RENAME_SEEDING
    _MS_INLINE_RENAME_SEEDING = True
    try:
        wm.ms_inline_rename_obj = str(getattr(obj, "name", "") or "")
        wm.ms_inline_rename_mod = str(mod_name)
        wm.ms_inline_rename_value = str(seed)
    except Exception:
        return False
    finally:
        _MS_INLINE_RENAME_SEEDING = previous
    return True


def _ms_inline_rename_value_update(self, context):
    global _MS_INLINE_RENAME_SEEDING
    if _MS_INLINE_RENAME_SEEDING:
        return
    try:
        obj_name = str(getattr(self, "ms_inline_rename_obj", "") or "")
        mod_name = str(getattr(self, "ms_inline_rename_mod", "") or "")
        new_name = str(getattr(self, "ms_inline_rename_value", "") or "").strip()
    except Exception:
        return
    if not obj_name or not mod_name:
        return
    # An emptied field is a cancel, never a rename to "".
    if not new_name:
        ms_inline_rename_clear(self)
        return
    try:
        current = ms_obj_get_disp_name(bpy.data.objects.get(obj_name), mod_name) or mod_name
    except Exception:
        current = ""
    if new_name != str(current):
        try:
            bpy.ops.object.ms_rename_modifier(
                'EXEC_DEFAULT',
                modifier_name=mod_name,
                target_obj_name=obj_name,
                new_name=new_name,
            )
        except Exception:
            pass
    ms_inline_rename_clear(self)
    try:
        _ms_tag_redraw_all_view3d()
    except Exception:
        pass


# Export all public and internal symbols for modular submodules.
__all__ = [k for k in globals().keys() if not k.startswith('__')]
