# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
# =============================================================================

"""Smart Tools settings storage and drawing helpers for Smart Modifier."""

from __future__ import annotations

import json
import os
import sys
import types

import bpy

from .utils import _root_id_from_package
from .translation import choose_text, pgettext_iface
from .help_button import draw_help_header

try:
    from .icons import prop as _sms_icon_prop
except Exception:
    def _sms_icon_prop(layout, data, prop_name, *, text='', icon_name='', fallback_icon='NONE', **kwargs):
        if fallback_icon and fallback_icon != 'NONE':
            kwargs['icon'] = fallback_icon
        try:
            return layout.prop(data, prop_name, text=text, **kwargs)
        except Exception:
            kwargs.pop('icon', None)
            kwargs.pop('icon_value', None)
            try:
                return layout.prop(data, prop_name, text=text, **kwargs)
            except Exception:
                return None

ADDON_ID = _root_id_from_package(__package__ or __name__, suite_basename='smart_modifier_suite')
_SETTINGS_PROP_NAME = 'sms_settings_state'
_SETTINGS_VERSION = 2
_SETTINGS_LOADED = False
_SETTINGS_APPLY_GUARD = False
_SHIFT_DRAG_CLONE_UPDATE_GUARD = False
_FILE_LOAD_GUARD = False

_DEFAULT_SETTINGS = {
    'use_modifier_stack': True,
    'use_modifier_switcher': True,
    'use_edit_poly_modifier': True,
    'use_smart_lattice_modifier': True,
    'stack_order': 'TOP_DOWN',
    # Modifier Auto Disable restoration policy.  PRESERVE restores the four
    # modifier-header states exactly as they were before temporary suppression.
    # FORCE_ENABLE restores them and then enables only the channels selected by
    # the four icon toggles below.
    'auto_disable_restore_mode': 'PRESERVE',
    'auto_disable_force_enable_cage': True,
    'auto_disable_force_enable_editmode': True,
    'auto_disable_force_enable_viewport': True,
    'auto_disable_force_enable_render': True,
    'show_always_on_toggles': False,
    # Root N-panel section states.  These drive the unified Smart Modeling-style
    # section rows in the Smart Modifier panel.
    'ui_section_always_on': False,
    'ui_section_modifier_stack': True,
    'ui_section_modifier_switcher': False,
    'ui_section_settings': False,
    'ui_section_hub': False,
    'ui_section_precision': False,
    'ui_section_advanced': False,
    'ui_section_tool_catalog': False,
    # Integrated Drag Clone settings. These are stored in the same
    # N-panel/runtime settings object instead of Blender Add-on Preferences so
    # the add-on preference property area remains empty.
    'shift_drag_clone_use_shift': False,
    'shift_drag_clone_use_ctrl': False,
    'shift_drag_clone_use_alt': False,
    'shift_drag_clone_use_oskey': False,
    'shift_drag_clone_trigger_key': 'NONE',
    'shift_drag_clone_default_clone_type': 'COPY',
    'shift_drag_clone_default_copy_count': 1,
    'shift_drag_clone_transform_source': 'AUTO',
    # Internal migration marker. Version 2 changes the install default from
    # Shift+Left Drag to completely disabled until the user explicitly enables
    # a modifier key or extra trigger key.
    'shift_drag_clone_shortcut_schema': 2,
}

_UI_SECTION_SETTING_NAMES = tuple(name for name in _DEFAULT_SETTINGS if name.startswith('ui_section_'))

_MSDC_TRIGGER_KEY_DESCRIPTION = "Require this keyboard key in addition to any enabled modifier keys after Drag Clone is invoked from a manually registered keymap item and before starting the clone with left-drag. This lets you keep Shift and Ctrl available for Blender transform precision and snapping after the clone starts."
_MSDC_TRIGGER_KEY_ITEMS = (
    ("NONE", "No Extra Key", "Start the clone with only the enabled modifier keys plus left-drag after you manually assign this operator in Blender Preferences > Keymap. The add-on never creates keymap items automatically."),
    ("A", "A", _MSDC_TRIGGER_KEY_DESCRIPTION), ("B", "B", _MSDC_TRIGGER_KEY_DESCRIPTION), ("C", "C", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("D", "D", _MSDC_TRIGGER_KEY_DESCRIPTION), ("E", "E", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F", "F", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("G", "G", _MSDC_TRIGGER_KEY_DESCRIPTION), ("H", "H", _MSDC_TRIGGER_KEY_DESCRIPTION), ("I", "I", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("J", "J", _MSDC_TRIGGER_KEY_DESCRIPTION), ("K", "K", _MSDC_TRIGGER_KEY_DESCRIPTION), ("L", "L", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("M", "M", _MSDC_TRIGGER_KEY_DESCRIPTION), ("N", "N", _MSDC_TRIGGER_KEY_DESCRIPTION), ("O", "O", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("P", "P", _MSDC_TRIGGER_KEY_DESCRIPTION), ("Q", "Q", _MSDC_TRIGGER_KEY_DESCRIPTION), ("R", "R", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("S", "S", _MSDC_TRIGGER_KEY_DESCRIPTION), ("T", "T", _MSDC_TRIGGER_KEY_DESCRIPTION), ("U", "U", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("V", "V", _MSDC_TRIGGER_KEY_DESCRIPTION), ("W", "W", _MSDC_TRIGGER_KEY_DESCRIPTION), ("X", "X", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("Y", "Y", _MSDC_TRIGGER_KEY_DESCRIPTION), ("Z", "Z", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("ZERO", "0", _MSDC_TRIGGER_KEY_DESCRIPTION), ("ONE", "1", _MSDC_TRIGGER_KEY_DESCRIPTION), ("TWO", "2", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("THREE", "3", _MSDC_TRIGGER_KEY_DESCRIPTION), ("FOUR", "4", _MSDC_TRIGGER_KEY_DESCRIPTION), ("FIVE", "5", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("SIX", "6", _MSDC_TRIGGER_KEY_DESCRIPTION), ("SEVEN", "7", _MSDC_TRIGGER_KEY_DESCRIPTION), ("EIGHT", "8", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NINE", "9", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("SPACE", "Space", _MSDC_TRIGGER_KEY_DESCRIPTION), ("TAB", "Tab", _MSDC_TRIGGER_KEY_DESCRIPTION), ("RET", "Enter", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("BACK_SPACE", "Backspace", _MSDC_TRIGGER_KEY_DESCRIPTION), ("DEL", "Delete", _MSDC_TRIGGER_KEY_DESCRIPTION), ("ESC", "Escape", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("INSERT", "Insert", _MSDC_TRIGGER_KEY_DESCRIPTION), ("HOME", "Home", _MSDC_TRIGGER_KEY_DESCRIPTION), ("END", "End", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("PAGE_UP", "Page Up", _MSDC_TRIGGER_KEY_DESCRIPTION), ("PAGE_DOWN", "Page Down", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("LEFT_ARROW", "Left Arrow", _MSDC_TRIGGER_KEY_DESCRIPTION), ("RIGHT_ARROW", "Right Arrow", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("UP_ARROW", "Up Arrow", _MSDC_TRIGGER_KEY_DESCRIPTION), ("DOWN_ARROW", "Down Arrow", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("SEMI_COLON", ";", _MSDC_TRIGGER_KEY_DESCRIPTION), ("PERIOD", ".", _MSDC_TRIGGER_KEY_DESCRIPTION), ("COMMA", ",", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("QUOTE", "Quote", _MSDC_TRIGGER_KEY_DESCRIPTION), ("ACCENT_GRAVE", "Backquote", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("MINUS", "-", _MSDC_TRIGGER_KEY_DESCRIPTION), ("PLUS", "+", _MSDC_TRIGGER_KEY_DESCRIPTION), ("SLASH", "/", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("BACK_SLASH", "\\", _MSDC_TRIGGER_KEY_DESCRIPTION), ("EQUAL", "=", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("LEFT_BRACKET", "[", _MSDC_TRIGGER_KEY_DESCRIPTION), ("RIGHT_BRACKET", "]", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_0", "Numpad 0", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_1", "Numpad 1", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_2", "Numpad 2", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_3", "Numpad 3", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_4", "Numpad 4", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_5", "Numpad 5", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_6", "Numpad 6", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_7", "Numpad 7", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_8", "Numpad 8", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_9", "Numpad 9", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_PERIOD", "Numpad .", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_SLASH", "Numpad /", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_ASTERIX", "Numpad *", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_MINUS", "Numpad -", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("NUMPAD_PLUS", "Numpad +", _MSDC_TRIGGER_KEY_DESCRIPTION), ("NUMPAD_ENTER", "Numpad Enter", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F1", "F1", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F2", "F2", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F3", "F3", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F4", "F4", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F5", "F5", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F6", "F6", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F7", "F7", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F8", "F8", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F9", "F9", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F10", "F10", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F11", "F11", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F12", "F12", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F13", "F13", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F14", "F14", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F15", "F15", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F16", "F16", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F17", "F17", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F18", "F18", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F19", "F19", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F20", "F20", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F21", "F21", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("F22", "F22", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F23", "F23", _MSDC_TRIGGER_KEY_DESCRIPTION), ("F24", "F24", _MSDC_TRIGGER_KEY_DESCRIPTION),
    ("PAUSE", "Pause", _MSDC_TRIGGER_KEY_DESCRIPTION), ("APP", "Application", _MSDC_TRIGGER_KEY_DESCRIPTION), ("GRLESS", "Grless", _MSDC_TRIGGER_KEY_DESCRIPTION),
)

_FALLBACK_SETTINGS = types.SimpleNamespace(**_DEFAULT_SETTINGS)

_RETIRED_ALWAYS_ON_SETTINGS: set[str] = set()


def begin_file_load(context=None) -> None:
    """Block RNA update callbacks while Blender deserializes a .blend file."""
    global _FILE_LOAD_GUARD
    _FILE_LOAD_GUARD = True
    try:
        from . import save_policy
        save_policy.begin_scene_restore(context)
    except Exception:
        pass


def end_file_load(context=None) -> None:
    """Release the file-load write barrier after canonical settings replay."""
    del context
    global _FILE_LOAD_GUARD
    _FILE_LOAD_GUARD = False
    # persistent_state.apply_panel_state() exclusively owns the successful
    # Scene-barrier release.  A failed/incomplete replay must remain fail-closed.

def _d(*lines: str) -> str:
    cleaned = []
    for line in lines:
        if line is None:
            continue
        cleaned.append(str(line).strip())
    return "\n".join(cleaned)


_DESC_USE_MODIFIER_STACK = _d(
    'Enable the Smart Modifier panel/features.',
    '',
    '- Shows the compact Modifier Stack workflow inside the Smart Modifier N-panel.',
    "- Turning this OFF does not change modifiers on existing objects; it only hides this add-on's stack workspace and related controls.",
    '- Leave this ON for normal use. Turn it OFF only when you want the suite installed but temporarily inactive.',
)

_DESC_USE_MODIFIER_SWITCHER = _d(
    'Enable the Modifier Management panel/features.',
    '',
    '- Shows the separate Modifier Management panel below Modifier Stack in the Smart Modifier N-panel.',
    '- Use it to batch-toggle modifier visibility states such as Viewport / Render / Edit Mode / On Cage.',
    '- Turn this OFF when you do not need list-based visibility management.',
)

_DESC_USE_EDIT_POLY = _d(
    'Enable the Edit Polygon Modifier subtool.',
    '',
    "- Adds Edit Polygon entries to Smart Modifier's Add Modifier > User menu.",
    '- Integrates edit-level switching and related helper logic into Smart Modifier.',
    '- Turn this OFF when you do not use Edit Polygon and want to keep the add-on lighter while idle.',
)

_DESC_USE_SMART_LATTICE = _d(
    'Enable the Smart Lattice Modifier subtool.',
    '',
    "- Adds Smart Lattice entries to Smart Modifier's Add Modifier > User menu.",
    '- Integrates lattice helper logic and layer management into Smart Modifier.',
    '- Turn this OFF when you do not use Smart Lattice and want to keep the add-on lighter while idle.',
)

_DESC_STACK_ORDER = _d(
    "Set the display order inside the Smart Modifier panel (Top → Bottom / Bottom → Top).",
    "This does not change Blender's actual modifier order; it only changes how the list is shown.",
    "Beginner tip: 'Top → Bottom' matches Blender's default. 'Bottom → Top' is handy when you want to see the last-applied result modifiers at the top.",
)


def _settings_directory() -> str:
    try:
        from .storage import config_dir
        return str(config_dir(create=True))
    except Exception:
        try:
            return str(bpy.utils.user_resource('CONFIG', path='', create=True) or '')
        except Exception:
            return ''


def _settings_filename() -> str:
    return 'Smart_Modifier_Suite.json'


def _settings_path() -> str:
    try:
        from .storage import suite_config_path
        return str(suite_config_path(create=True))
    except Exception:
        base = _settings_directory()
        return os.path.join(base, 'Smart_Modifier_Suite', _settings_filename()) if base else ''


def _legacy_settings_paths() -> list[str]:
    paths: list[str] = []
    # Previous extension/user_data storage location.
    try:
        from .storage import storage_dir
        base = storage_dir(create=False)
        if base is not None:
            safe_id = (
                str(ADDON_ID or 'smart_modifier_suite')
                .replace('\\', '_')
                .replace('/', '_')
                .replace(':', '_')
                .replace('.', '__')
            )
            paths.append(os.path.join(str(base), f'{safe_id}_settings.json'))
    except Exception:
        pass
    # Previous config/smart_modifier_suite fallback.
    try:
        base = bpy.utils.user_resource('CONFIG', create=False) or ''
    except Exception:
        base = ''
    if base:
        safe_id = (
            str(ADDON_ID or 'smart_modifier_suite')
            .replace('\\', '_')
            .replace('/', '_')
            .replace(':', '_')
            .replace('.', '__')
        )
        paths.append(os.path.join(base, 'smart_modifier_suite', f'{safe_id}_settings.json'))
    return [p for p in paths if p]


def _legacy_settings_path() -> str:
    paths = _legacy_settings_paths()
    return paths[0] if paths else ''

def _iter_window_managers(context=None):
    seen = set()
    candidates = []
    for ctx in (context, getattr(bpy, 'context', None)):
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is not None:
            candidates.append(wm)
    try:
        candidates.extend(list(getattr(bpy.data, 'window_managers', []) or []))
    except Exception:
        pass
    for wm in candidates:
        key = id(wm)
        if key in seen:
            continue
        seen.add(key)
        yield wm


def _settings_state_from_wm(wm):
    if wm is None:
        return None
    try:
        return getattr(wm, _SETTINGS_PROP_NAME, None)
    except Exception:
        return None


def _normalize_loaded_values(values: dict | None) -> dict:
    normalized = dict(_DEFAULT_SETTINGS)
    if not isinstance(values, dict):
        values = {}
    for name in ('use_modifier_stack', 'use_modifier_switcher', 'use_edit_poly_modifier', 'use_smart_lattice_modifier'):
        if name in values:
            normalized[name] = bool(values.get(name))
    for name in _RETIRED_ALWAYS_ON_SETTINGS:
        normalized[name] = True
    order = str(values.get('stack_order', normalized['stack_order']) or normalized['stack_order']).strip().upper()
    normalized['stack_order'] = order if order in {'TOP_DOWN', 'BOTTOM_UP'} else _DEFAULT_SETTINGS['stack_order']
    restore_mode = str(values.get('auto_disable_restore_mode', normalized['auto_disable_restore_mode']) or 'PRESERVE').strip().upper()
    normalized['auto_disable_restore_mode'] = restore_mode if restore_mode in {'PRESERVE', 'FORCE_ENABLE'} else _DEFAULT_SETTINGS['auto_disable_restore_mode']
    for name in (
        'auto_disable_force_enable_cage',
        'auto_disable_force_enable_editmode',
        'auto_disable_force_enable_viewport',
        'auto_disable_force_enable_render',
    ):
        if name in values:
            normalized[name] = bool(values.get(name))
    if 'show_always_on_toggles' in values:
        normalized['show_always_on_toggles'] = bool(values.get('show_always_on_toggles'))
    for name in _UI_SECTION_SETTING_NAMES:
        if name in values:
            normalized[name] = bool(values.get(name))
    for name in (
        'shift_drag_clone_use_shift',
        'shift_drag_clone_use_ctrl',
        'shift_drag_clone_use_alt',
        'shift_drag_clone_use_oskey',
    ):
        if name in values:
            normalized[name] = bool(values.get(name))
    trigger_key = str(values.get('shift_drag_clone_trigger_key', normalized['shift_drag_clone_trigger_key']) or 'NONE')
    valid_trigger_keys = {item[0] for item in _MSDC_TRIGGER_KEY_ITEMS}
    normalized['shift_drag_clone_trigger_key'] = trigger_key if trigger_key in valid_trigger_keys else 'NONE'
    try:
        shortcut_schema = int(values.get('shift_drag_clone_shortcut_schema', 0) or 0)
    except Exception:
        shortcut_schema = 0
    if shortcut_schema < 2:
        # Old integrated builds wrote Shift=True / Trigger=NONE as an implicit
        # default.  Treat exactly that untouched legacy tuple as the new disabled
        # install default, so upgrading does not keep using a shortcut condition
        # the user never explicitly chose.  Any non-default key or modifier
        # combination remains untouched.
        legacy_shift_only = (
            bool(values.get('shift_drag_clone_use_shift', False)) is True
            and bool(values.get('shift_drag_clone_use_ctrl', False)) is False
            and bool(values.get('shift_drag_clone_use_alt', False)) is False
            and bool(values.get('shift_drag_clone_use_oskey', False)) is False
            and str(values.get('shift_drag_clone_trigger_key', 'NONE') or 'NONE') == 'NONE'
        )
        if legacy_shift_only:
            normalized['shift_drag_clone_use_shift'] = False
    normalized['shift_drag_clone_shortcut_schema'] = 2
    clone_type = str(values.get('shift_drag_clone_default_clone_type', normalized['shift_drag_clone_default_clone_type']) or 'COPY').upper()
    normalized['shift_drag_clone_default_clone_type'] = clone_type if clone_type in {'COPY', 'INSTANCE'} else 'COPY'
    transform_source = str(values.get('shift_drag_clone_transform_source', normalized['shift_drag_clone_transform_source']) or 'AUTO').upper()
    normalized['shift_drag_clone_transform_source'] = transform_source if transform_source in {'AUTO', 'TRANSLATE', 'ROTATE', 'SCALE'} else 'AUTO'
    try:
        copy_count = int(values.get('shift_drag_clone_default_copy_count', normalized['shift_drag_clone_default_copy_count']))
    except Exception:
        copy_count = int(_DEFAULT_SETTINGS['shift_drag_clone_default_copy_count'])
    normalized['shift_drag_clone_default_copy_count'] = max(1, min(1000, copy_count))
    return normalized


def _settings_to_dict(prefs_obj=None, context=None) -> dict:
    prefs = prefs_obj if prefs_obj is not None else get_preferences(context)
    values = {}
    valid_trigger_keys = {item[0] for item in _MSDC_TRIGGER_KEY_ITEMS}
    for name, default in _DEFAULT_SETTINGS.items():
        try:
            value = getattr(prefs, name)
        except Exception:
            value = default
        if name == 'stack_order':
            value = str(value or default).strip().upper()
            if value not in {'TOP_DOWN', 'BOTTOM_UP'}:
                value = default
        elif name == 'auto_disable_restore_mode':
            value = str(value or default).strip().upper()
            if value not in {'PRESERVE', 'FORCE_ENABLE'}:
                value = default
        elif name == 'shift_drag_clone_trigger_key':
            value = str(value or default)
            if value not in valid_trigger_keys:
                value = default
        elif name == 'shift_drag_clone_default_clone_type':
            value = str(value or default).strip().upper()
            if value not in {'COPY', 'INSTANCE'}:
                value = default
        elif name == 'shift_drag_clone_transform_source':
            value = str(value or default).strip().upper()
            if value not in {'AUTO', 'TRANSLATE', 'ROTATE', 'SCALE'}:
                value = default
        elif name == 'shift_drag_clone_default_copy_count':
            try:
                value = max(1, min(1000, int(value)))
            except Exception:
                value = int(default)
        elif isinstance(default, bool):
            value = bool(value)
            if name in _RETIRED_ALWAYS_ON_SETTINGS:
                value = True
        else:
            value = value if value is not None else default
        values[name] = value
    return values


def _apply_values_to_state(state, values: dict) -> None:
    global _SETTINGS_APPLY_GUARD
    if state is None:
        return
    _SETTINGS_APPLY_GUARD = True
    try:
        normalized = _normalize_loaded_values(values)
        for name, value in normalized.items():
            try:
                setattr(state, name, value)
            except Exception:
                pass
    finally:
        _SETTINGS_APPLY_GUARD = False
_SHIFT_DRAG_CLONE_UPDATE_GUARD = False


def _read_settings_from_disk() -> dict:
    # Primary unified config file: <Blender config>/Smart_Modifier_Suite/Smart_Modifier_Suite.json
    try:
        from .storage import read_suite_config
        payload = read_suite_config()
        if isinstance(payload, dict):
            section = payload.get('settings')
            if isinstance(section, dict):
                return _normalize_loaded_values(section)
            # Migration fallback for builds that only persisted these values inside
            # panel_state.settings.  Use it only when the canonical top-level
            # settings section is absent, so stale panel_state never overrides the
            # current saved drag-start-key settings on Blender startup.
            panel_state = payload.get('panel_state') if isinstance(payload.get('panel_state'), dict) else {}
            panel_settings = panel_state.get('settings') if isinstance(panel_state.get('settings'), dict) else None
            if isinstance(panel_settings, dict) and any(name in panel_settings for name in _DEFAULT_SETTINGS):
                return _normalize_loaded_values(panel_settings)
            # Accept a direct settings dict for hand-edited files.
            if any(name in payload for name in _DEFAULT_SETTINGS):
                return _normalize_loaded_values(payload)
    except Exception:
        pass

    # Legacy files are read only for migration.  New writes always go to the
    # unified Smart_Modifier_Suite/Smart_Modifier_Suite.json file in Blender's versioned config dir.
    for path in _legacy_settings_paths():
        if not path or not os.path.isfile(path):
            continue
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
        except Exception:
            continue
        if isinstance(payload, dict) and isinstance(payload.get('settings'), dict):
            payload = payload['settings']
        values = _normalize_loaded_values(payload)
        try:
            save_settings(prefs_obj=types.SimpleNamespace(**values), force=True)
        except Exception:
            pass
        return values
    return dict(_DEFAULT_SETTINGS)



def save_settings(context=None, prefs_obj=None, *, force: bool = False) -> bool:
    # During .blend deserialization Blender assigns WindowManager RNA one field
    # at a time and invokes normal update callbacks.  Those transient/default
    # assignments are not user edits and must never replace the external
    # Smart_Modifier_Suite.json profile before load_post restores it.
    if _FILE_LOAD_GUARD:
        return False
    try:
        from .save_policy import should_write_config
        if not should_write_config(context, force=force):
            return False
    except Exception:
        return False
    values = _settings_to_dict(prefs_obj=prefs_obj, context=context)
    payload = {
        'version': _SETTINGS_VERSION,
        'addon_id': ADDON_ID,
        'settings': values,
    }
    try:
        from .storage import read_suite_config, write_suite_config
        data = read_suite_config()
        if not isinstance(data, dict):
            data = {}
        data.update({k: v for k, v in payload.items() if k != 'settings'})
        data['settings'] = values
        return bool(write_suite_config(data))
    except Exception:
        pass

    path = _settings_path()
    if not path:
        return False
    directory = os.path.dirname(path)
    try:
        if directory:
            os.makedirs(directory, exist_ok=True)
        existing = {}
        if os.path.isfile(path):
            try:
                with open(path, 'r', encoding='utf-8') as handle:
                    existing = json.load(handle)
            except Exception:
                existing = {}
        if not isinstance(existing, dict):
            existing = {}
        existing.update({k: v for k, v in payload.items() if k != 'settings'})
        existing['settings'] = values
        from . import storage
        storage.atomic_write_json(path, existing, indent=2, ensure_ascii=False, sort_keys=True)
        return True
    except Exception:
        return False


def load_settings(context=None, *, force=False) -> bool:
    global _SETTINGS_LOADED
    if _SETTINGS_LOADED and not force:
        return True
    values = _read_settings_from_disk()
    applied = False
    for wm in _iter_window_managers(context):
        state = _settings_state_from_wm(wm)
        if state is None:
            continue
        _apply_values_to_state(state, values)
        applied = True
    if applied:
        _SETTINGS_LOADED = True
        if not _FILE_LOAD_GUARD:
            save_settings(context=context)
    return applied


def _runtime_pref_update(_self, context) -> None:
    if _SETTINGS_APPLY_GUARD or _FILE_LOAD_GUARD:
        return
    save_settings(context=context)
    try:
        from . import persistent_state
        persistent_state.request_save(context, immediate=True, force=False)
    except Exception:
        pass
    runtime = sys.modules.get(f"{__package__}.runtime")
    if runtime is None:
        return
    try:
        sync_runtime_from_prefs = getattr(runtime, 'sync_runtime_from_prefs', None)
        if callable(sync_runtime_from_prefs):
            sync_runtime_from_prefs(context)
    except Exception:
        pass


def _shift_drag_clone_pref_update(_self, context) -> None:
    global _SHIFT_DRAG_CLONE_UPDATE_GUARD
    if _SETTINGS_APPLY_GUARD or _FILE_LOAD_GUARD:
        return
    if _SHIFT_DRAG_CLONE_UPDATE_GUARD:
        return
    _SHIFT_DRAG_CLONE_UPDATE_GUARD = True
    try:
        _runtime_pref_update(_self, context)
        # Drag-start settings are saved immediately, but Smart Modifier must not
        # rebuild or create Blender keymap entries automatically.  Use the copied
        # operator ID in Blender Preferences > Keymap for manual shortcut binding.
        try:
            save_settings(context=context, force=False)
        except Exception:
            pass
    finally:
        _SHIFT_DRAG_CLONE_UPDATE_GUARD = False


def _msdc_trigger_key_items(_self=None, _context=None):
    try:
        from . import max_shift_drag_clone as _msdc
        return tuple(getattr(_msdc, '_TRIGGER_KEY_ITEMS', ())) or (("NONE", "No Extra Key", "Start the clone with only the enabled modifier keys plus left-drag after you manually assign this operator in Blender Preferences > Keymap."),)
    except Exception:
        return (("NONE", "No Extra Key", "Start the clone with only the enabled modifier keys plus left-drag after you manually assign this operator in Blender Preferences > Keymap."),)


class MS_RuntimeSettings(bpy.types.PropertyGroup):
    use_modifier_stack: bpy.props.BoolProperty(
        name='Enable Smart Modifier',
        description=_DESC_USE_MODIFIER_STACK,
        default=_DEFAULT_SETTINGS['use_modifier_stack'],
        update=_runtime_pref_update,
    )

    use_modifier_switcher: bpy.props.BoolProperty(
        name='Enable Modifier Management',
        description=_DESC_USE_MODIFIER_SWITCHER,
        default=_DEFAULT_SETTINGS['use_modifier_switcher'],
        update=_runtime_pref_update,
    )

    use_edit_poly_modifier: bpy.props.BoolProperty(
        name='Enable Edit Polygon Modifier (Bundled)',
        description=_DESC_USE_EDIT_POLY,
        default=_DEFAULT_SETTINGS['use_edit_poly_modifier'],
        update=_runtime_pref_update,
    )

    use_smart_lattice_modifier: bpy.props.BoolProperty(
        name='Enable Smart Lattice Modifier (Bundled)',
        description=_DESC_USE_SMART_LATTICE,
        default=_DEFAULT_SETTINGS['use_smart_lattice_modifier'],
        update=_runtime_pref_update,
    )

    stack_order: bpy.props.EnumProperty(
        name='Stack Order',
        description=_DESC_STACK_ORDER,
        items=[
            (
                'TOP_DOWN',
                'Base Object Top',
                'Show the base object at the top and place modifiers below it.',
            ),
            (
                'BOTTOM_UP',
                'Base Object Bottom',
                'Show the base object at the bottom and place modifiers above it.',
            ),
        ],
        default=_DEFAULT_SETTINGS['stack_order'],
        update=_runtime_pref_update,
    )


    auto_disable_restore_mode: bpy.props.EnumProperty(
        name='Auto Disable Restore Behavior',
        description=(
            'Choose what happens to the four modifier-header display states when a modifier leaves temporary suppression caused by Modifier Auto Disable. '
            'Preserve Current States restores exactly the On Cage, Edit Mode, Realtime Viewport, and Render states saved before suppression. '
            'Force Enable Selected States restores the saved states and then turns ON only the channels selected by the four icon buttons below.'
        ),
        items=(
            (
                'PRESERVE',
                'Preserve Current States',
                'Restore each modifier to the exact On Cage, Edit Mode, Realtime Viewport, and Render states it had before Modifier Auto Disable temporarily turned it off.',
            ),
            (
                'FORCE_ENABLE',
                'Force Enable Selected States',
                'After restoring a modifier that was temporarily suppressed, turn ON the display channels selected by the four icon buttons below. Unselected channels keep their saved states.',
            ),
        ),
        default=_DEFAULT_SETTINGS['auto_disable_restore_mode'],
        update=_runtime_pref_update,
    )

    auto_disable_force_enable_cage: bpy.props.BoolProperty(
        name='Force On Cage',
        description=(
            'When Auto Disable Restore Behavior is Force Enable Selected States, turn On Cage ON when a temporarily suppressed modifier becomes active again. '
            'Use this when you want the editable cage to resume automatically. This setting affects only restoration after Modifier Auto Disable; it does not continuously override later manual changes.'
        ),
        default=_DEFAULT_SETTINGS['auto_disable_force_enable_cage'],
        update=_runtime_pref_update,
    )
    auto_disable_force_enable_editmode: bpy.props.BoolProperty(
        name='Force Edit Mode',
        description=(
            'When Auto Disable Restore Behavior is Force Enable Selected States, turn Show in Edit Mode ON when a temporarily suppressed modifier becomes active again. '
            'Use this when you always want the restored modifier evaluated while editing. This setting affects only the restoration transition and does not continuously override later manual changes.'
        ),
        default=_DEFAULT_SETTINGS['auto_disable_force_enable_editmode'],
        update=_runtime_pref_update,
    )
    auto_disable_force_enable_viewport: bpy.props.BoolProperty(
        name='Force Realtime Viewport',
        description=(
            'When Auto Disable Restore Behavior is Force Enable Selected States, turn Realtime Viewport ON when a temporarily suppressed modifier becomes active again. '
            'Use this when restored modifiers must immediately appear in the 3D View. This setting affects only the restoration transition and does not continuously override later manual changes.'
        ),
        default=_DEFAULT_SETTINGS['auto_disable_force_enable_viewport'],
        update=_runtime_pref_update,
    )
    auto_disable_force_enable_render: bpy.props.BoolProperty(
        name='Force Render',
        description=(
            'When Auto Disable Restore Behavior is Force Enable Selected States, turn Render ON when a temporarily suppressed modifier becomes active again. '
            'Use this when restored modifiers must be included in final rendering. This setting affects only the restoration transition and does not continuously override later manual changes.'
        ),
        default=_DEFAULT_SETTINGS['auto_disable_force_enable_render'],
        update=_runtime_pref_update,
    )


    show_always_on_toggles: bpy.props.BoolProperty(
        name='Always-on Toggles',
        description=(
            'Open or close the Always-on Toggles group at the top of the Smart Modifier N-panel. '
            'The default is closed to keep normal sidebar drawing light. This UI state is saved immediately and restored after Blender restarts or a different scene is opened.'
        ),
        default=_DEFAULT_SETTINGS['show_always_on_toggles'],
        update=_runtime_pref_update,
    )

    ui_section_always_on: bpy.props.BoolProperty(
        name='Always-on Toggles Section',
        description='Open or close the Always-on Toggles section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_always_on'],
        update=_runtime_pref_update,
    )
    ui_section_modifier_stack: bpy.props.BoolProperty(
        name='Modifier Stack Section',
        description='Open or close the Modifier Stack section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_modifier_stack'],
        update=_runtime_pref_update,
    )
    ui_section_modifier_switcher: bpy.props.BoolProperty(
        name='Modifier Management Section',
        description='Open or close the Modifier Management section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_modifier_switcher'],
        update=_runtime_pref_update,
    )
    ui_section_settings: bpy.props.BoolProperty(
        name='Settings Section',
        description='Open or close the Settings section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_settings'],
        update=_runtime_pref_update,
    )
    ui_section_hub: bpy.props.BoolProperty(
        name='Smart Modifier Hub Section',
        description='Open or close the Smart Modifier Hub section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_hub'],
        update=_runtime_pref_update,
    )
    ui_section_precision: bpy.props.BoolProperty(
        name='Precision / Layout / Path Section',
        description='Open or close the Precision / Layout / Path section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_precision'],
        update=_runtime_pref_update,
    )
    ui_section_advanced: bpy.props.BoolProperty(
        name='Advanced / Surface Modeling Section',
        description='Open or close the Advanced / Surface Modeling section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_advanced'],
        update=_runtime_pref_update,
    )
    ui_section_tool_catalog: bpy.props.BoolProperty(
        name='Bundled Tool Catalog Section',
        description='Open or close the Bundled Tool Catalog section in the unified Smart Modifier N-panel.',
        default=_DEFAULT_SETTINGS['ui_section_tool_catalog'],
        update=_runtime_pref_update,
    )

    shift_drag_clone_use_shift: bpy.props.BoolProperty(
        name='Shift',
        description="Require the Shift key after the Drag Clone operator is invoked from a manually registered keymap item. Smart Modifier never registers this shortcut automatically.",
        default=_DEFAULT_SETTINGS['shift_drag_clone_use_shift'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_use_ctrl: bpy.props.BoolProperty(
        name='Ctrl',
        description='Require the Ctrl key after the Drag Clone operator is invoked from a manually registered keymap item. During the transform itself Blender still uses Ctrl for snapping.',
        default=_DEFAULT_SETTINGS['shift_drag_clone_use_ctrl'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_use_alt: bpy.props.BoolProperty(
        name='Alt',
        description='Require the Alt key after the Drag Clone operator is invoked from a manually registered keymap item. This keeps Shift and Ctrl free for precision and snapping after the clone is created.',
        default=_DEFAULT_SETTINGS['shift_drag_clone_use_alt'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_use_oskey: bpy.props.BoolProperty(
        name='Command',
        description='Require the operating-system modifier key after the Drag Clone operator is invoked from a manually registered keymap item. On Windows this is the Windows key; on macOS this is Command; use it only when the OS and Blender keymap allow it.',
        default=_DEFAULT_SETTINGS['shift_drag_clone_use_oskey'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_trigger_key: bpy.props.EnumProperty(
        name='Trigger Key',
        description='Optionally require one non-modifier keyboard key in addition to the enabled modifier keys after the manually registered Drag Clone operator is invoked. Set this to No Extra Key for modifier-only behavior.',
        items=_MSDC_TRIGGER_KEY_ITEMS,
        default=_DEFAULT_SETTINGS['shift_drag_clone_trigger_key'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_transform_source: bpy.props.EnumProperty(
        name='Transform Mode',
        description='Choose the transform launched immediately after cloning. Auto follows the current Move, Rotate, or Scale tool; standard gizmos, Smart Gizmo, standard G/R/S, and Smart G/R/S keep their normal axis constraints, orientation, pivot, snapping, and precision behavior.',
        items=(
            ('AUTO', 'Auto', 'Use the active 3D View tool: Move, Rotate, or Scale. If it is not a transform tool, use Move.'),
            ('TRANSLATE', 'Move', 'Always start a Move transform after cloning.'),
            ('ROTATE', 'Rotate', 'Always start a Rotate transform after cloning.'),
            ('SCALE', 'Scale', 'Always start a Scale transform after cloning.'),
        ),
        default=_DEFAULT_SETTINGS['shift_drag_clone_transform_source'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_default_clone_type: bpy.props.EnumProperty(
        name='Default Clone Type',
        description='Set the default choice shown in the clone confirmation dialog for Object Mode. Copy makes independent object data; Instance links the cloned object data to the source and also joins Smart Modifier object-instance groups so modifier instances stay synchronized.',
        items=(
            ('COPY', 'Copy', 'Use normal independent object-data copies by default.'),
            ('INSTANCE', 'Instance', 'Use linked object-data instances by default and synchronize Smart Modifier modifier instances.'),
        ),
        default=_DEFAULT_SETTINGS['shift_drag_clone_default_clone_type'],
        update=_shift_drag_clone_pref_update,
    )
    shift_drag_clone_default_copy_count: bpy.props.IntProperty(
        name='Default Number of Copies',
        description='Set the default number shown in the clone confirmation dialog. The dragged clone counts as copy 1; values above 1 add successive repeated copies at the same transform interval.',
        default=_DEFAULT_SETTINGS['shift_drag_clone_default_copy_count'],
        min=1,
        soft_max=100,
        update=_shift_drag_clone_pref_update,
    )


def get_preferences(context=None):
    if not _SETTINGS_LOADED:
        load_settings(context=context)
    for wm in _iter_window_managers(context):
        state = _settings_state_from_wm(wm)
        if state is not None:
            return state
    return _FALLBACK_SETTINGS


def _safe_prop(layout, data, prop_name: str, **kwargs) -> None:
    if data is None or not hasattr(data, prop_name):
        return
    try:
        layout.prop(data, prop_name, **kwargs)
    except Exception:
        pass



def _draw_show_end_result_keymap_info(layout, context) -> None:
    """Draw copyable keymap registration information for Show End Result."""
    box = layout.box()
    draw_help_header(
        box,
        context,
        choose_text('Show End Result Shortcut', '最終結果を表示ショートカット', context=context),
        'KEYINGSET',
        'settings_show_end_result_shortcut',
    )
    box.label(
        text=choose_text(
            'Recommended keymap location: Preferences > Keymap > 3D View > 3D View (Global)',
            '推奨キーマップ登録場所: プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）',
            context=context,
        ),
        icon='NONE',
    )
    box.label(
        text=choose_text(
            'Operator ID to add/copy:',
            '追加・コピーする登録ID:',
            context=context,
        ),
        icon='NONE',
    )
    wm = getattr(context, 'window_manager', None) if context is not None else None
    try:
        if wm is not None and hasattr(wm, 'sms_show_end_result_keymap_id'):
            row = box.row(align=True)
            row.label(text=choose_text('Show End Result', '最終結果を表示', context=context))
            row.operator('object.ms_copy_keymap_id', text=choose_text('Copy ID', 'IDをコピー', context=context), icon='COPYDOWN').text = 'object.ms_toggle_show_end_result'
            return
    except Exception:
        pass





def _draw_stack_level_keymap_info(layout, context) -> None:
    """Draw copyable keymap IDs for active Smart Modifier stack-level navigation."""
    box = layout.box()
    draw_help_header(
        box,
        context,
        choose_text('Active Stack Level Shortcuts', 'アクティブ階層ショートカット', context=context),
        'KEYINGSET',
        'settings_active_stack_level_shortcuts',
    )
    box.label(
        text=choose_text(
            'Recommended keymap location for Object Mode: Preferences > Keymap > 3D View > Object Mode',
            'オブジェクトモード推奨登録場所: プリファレンス > キーマップ > 3Dビュー > オブジェクトモード',
            context=context,
        ),
        icon='NONE',
    )
    box.label(
        text=choose_text(
            'Recommended keymap location for Edit Mode: Preferences > Keymap > Mesh > Edit Mode',
            '編集モード推奨登録場所: プリファレンス > キーマップ > Mesh > 編集モード',
            context=context,
        ),
        icon='NONE',
    )
    box.label(
        text=choose_text(
            'These shortcuts change the active stack level only. They do not move modifier order.',
            'このショートカットはアクティブ階層だけを切り替えます。モディファイアの並び順は変更しません。',
            context=context,
        ),
        icon='NONE',
    )
    box.label(
        text=choose_text(
            'When Modifier Auto Disable or Show End Result is enabled, the shortcut uses the same switching path as clicking a stack row.',
            '「モディファイア自動無効」または「最終結果を表示」が有効な場合も、スタック行をクリックした時と同じ切り替え処理を使用します。',
            context=context,
        ),
        icon='NONE',
    )

    box.label(
        text=choose_text(
            'Smart Modifier does not add keymap items automatically. Copy the IDs below and register only the shortcuts you need.',
            'Smart Modifier はキーマップ項目を自動追加しません。下記IDをコピーし、必要なショートカットだけ手動登録してください。',
            context=context,
        ),
        icon='KEYINGSET',
    )

    wm = getattr(context, 'window_manager', None) if context is not None else None

    def _id_row(prop_name: str, label_en: str, label_ja: str, operator_id: str) -> None:
        try:
            row_id = box.row(align=True)
            row_id.label(text=choose_text(label_en, label_ja, context=context))
            row_id.operator('object.ms_copy_keymap_id', text=choose_text('Copy ID', 'IDをコピー', context=context), icon='COPYDOWN').text = operator_id
            return
        except Exception:
            pass

    _id_row('sms_active_stack_level_up_keymap_id', 'Active Level Up ID', 'アクティブ階層を上へID', 'object.ms_active_stack_level_up')
    _id_row('sms_active_stack_level_down_keymap_id', 'Active Level Down ID', 'アクティブ階層を下へID', 'object.ms_active_stack_level_down')

def _draw_instance_copy_controls(layout, context) -> None:
    """Draw Instance Copy buttons and copyable keymap registration IDs."""
    box = layout.box()
    draw_help_header(
        box,
        context,
        choose_text('Instance Copy', 'インスタンスコピー', context=context),
        'LINKED',
        'settings_instance_copy',
    )
    row = box.row(align=True)
    try:
        row.operator_context = 'INVOKE_DEFAULT'
        row.operator(
            'object.sms_instance_copy',
            text=choose_text('Instance Copy', 'インスタンスコピー', context=context),
            icon='LINKED',
        )
    except Exception:
        row.label(text=choose_text('Instance Copy is not available.', 'インスタンスコピーは利用できません。', context=context), icon='ERROR')
    try:
        row.operator_context = 'EXEC_DEFAULT'
        row.operator(
            'object.sms_instance_make_unique',
            text=choose_text('Release Instance', 'インスタンス解除', context=context),
            icon='UNLINKED',
        )
    except Exception:
        pass

    prefs = get_preferences(context)
    drag_box = box.box()
    draw_help_header(
        drag_box,
        context,
        choose_text('Drag Clone', 'ドラッグクローン', context=context),
        'MOUSE_LMB_DRAG',
        'settings_max_shift_drag_clone',
    )
    options_box = drag_box.box()
    options_box.label(text=choose_text('Clone Defaults', 'クローン既定値', context=context), icon='PREFERENCES')
    _safe_prop(options_box, prefs, 'shift_drag_clone_default_clone_type', text=choose_text('Default Clone Type', '既定のクローン方式', context=context))
    _safe_prop(options_box, prefs, 'shift_drag_clone_default_copy_count', text=choose_text('Default Number of Copies', '既定のコピー数', context=context))

    info = box.box()
    draw_help_header(
        info,
        context,
        choose_text('Instance Copy Shortcut IDs', 'インスタンスコピーのショートカットID', context=context),
        'KEYINGSET',
        'settings_instance_copy_shortcuts',
    )
    info.label(
        text=choose_text(
            'Instance Copy / Release recommended location: Preferences > Keymap > 3D View > Object Mode',
            'インスタンスコピー / 解除の推奨登録場所: プリファレンス > キーマップ > 3Dビュー > オブジェクトモード',
            context=context,
        ),
        icon='NONE',
    )

    info.label(
        text=choose_text(
            'Drag Clone recommended location: Preferences > Keymap > 3D View > 3D View (Global)',
            'ドラッグクローンの推奨登録場所: プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）',
            context=context,
        ),
        icon='NONE',
    )
    info.label(
        text=choose_text(
            'Smart Modifier does not add keymap items automatically. Copy the IDs below and register only the shortcuts you need.',
            'Smart Modifier はキーマップ項目を自動追加しません。下記IDをコピーし、必要なショートカットだけ手動登録してください。',
            context=context,
        ),
        icon='KEYINGSET',
    )

    wm = getattr(context, 'window_manager', None) if context is not None else None

    def _id_row(prop_name: str, label_en: str, label_ja: str, operator_id: str) -> None:
        try:
            row_id = info.row(align=True)
            row_id.label(text=choose_text(label_en, label_ja, context=context))
            row_id.operator('object.ms_copy_keymap_id', text=choose_text('Copy ID', 'IDをコピー', context=context), icon='COPYDOWN').text = operator_id
            return
        except Exception:
            pass

    _id_row('sms_instance_copy_keymap_id', 'Instance Copy ID', 'インスタンスコピーID', 'object.sms_instance_copy')
    _id_row('sms_instance_make_unique_keymap_id', 'Release Instance ID', 'インスタンス解除ID', 'object.sms_instance_make_unique')
    _id_row('sms_shift_drag_clone_keymap_id', 'Drag Clone ID', 'ドラッグクローンID', 'view3d.max_shift_drag_clone')


def draw_smart_tools_preferences(layout, context, prefs_obj=None) -> None:
    prefs = prefs_obj if prefs_obj is not None else get_preferences(context)

    layout.use_property_split = False
    layout.use_property_decorate = False

    _draw_show_end_result_keymap_info(layout, context)
    _draw_stack_level_keymap_info(layout, context)
    _draw_instance_copy_controls(layout, context)

    stack_box = layout.box()
    draw_help_header(stack_box, context, 'Modifier Stack', 'MODIFIER', 'settings_stack')
    _safe_prop(
        stack_box,
        prefs,
        'use_modifier_stack',
        text=pgettext_iface('Enable Smart Modifier', context=context),
    )

    feature_box = layout.box()
    draw_help_header(feature_box, context, 'Bundled Subtools', 'PREFERENCES', 'settings_bundled')
    _safe_prop(
        feature_box,
        prefs,
        'use_modifier_switcher',
        text=pgettext_iface('Enable Modifier Management', context=context),
    )
    _safe_prop(
        feature_box,
        prefs,
        'use_edit_poly_modifier',
        text=pgettext_iface('Enable Edit Polygon Modifier (Bundled)', context=context),
    )
    _safe_prop(
        feature_box,
        prefs,
        'use_smart_lattice_modifier',
        text=pgettext_iface('Enable Smart Lattice Modifier (Bundled)', context=context),
    )

    order_box = stack_box.box()
    draw_help_header(order_box, context, choose_text('Modifier Stack Display', 'モディファイアスタック表示', context=context), 'SORTSIZE', 'settings_stack_display')
    if prefs is not None and hasattr(prefs, 'stack_order'):
        row = order_box.row(align=True)
        try:
            row.prop_enum(
                prefs,
                'stack_order',
                'TOP_DOWN',
                text=pgettext_iface('Base Object Top', context=context),
            )
            row.prop_enum(
                prefs,
                'stack_order',
                'BOTTOM_UP',
                text=pgettext_iface('Base Object Bottom', context=context),
            )
        except Exception:
            _safe_prop(order_box, prefs, 'stack_order', expand=True)

    restore_box = stack_box.box()
    draw_help_header(
        restore_box,
        context,
        choose_text('Auto Disable Restore', '自動無効からの復元', context=context),
        'MODIFIER',
        'settings_auto_disable_restore',
    )
    _safe_prop(
        restore_box,
        prefs,
        'auto_disable_restore_mode',
        text=choose_text('Restore Behavior', '復元動作', context=context),
    )
    try:
        force_mode = str(getattr(prefs, 'auto_disable_restore_mode', 'PRESERVE') or 'PRESERVE') == 'FORCE_ENABLE'
    except Exception:
        force_mode = False
    if force_mode:
        row = restore_box.row(align=True)
        row.label(text=choose_text('Force ON', '強制有効', context=context))
        _sms_icon_prop(
            row,
            prefs,
            'auto_disable_force_enable_cage',
            text='',
            icon_name='cage',
            fallback_icon='MESH_DATA',
            toggle=True,
        )
        _sms_icon_prop(
            row,
            prefs,
            'auto_disable_force_enable_editmode',
            text='',
            icon_name='edit',
            fallback_icon='EDITMODE_HLT',
            toggle=True,
        )
        try:
            viewport_enabled = bool(getattr(prefs, 'auto_disable_force_enable_viewport', True))
        except Exception:
            viewport_enabled = True
        _sms_icon_prop(
            row,
            prefs,
            'auto_disable_force_enable_viewport',
            text='',
            icon_name='visible_on' if viewport_enabled else 'visible_off',
            fallback_icon='HIDE_OFF' if viewport_enabled else 'HIDE_ON',
            toggle=True,
        )
        try:
            render_enabled = bool(getattr(prefs, 'auto_disable_force_enable_render', True))
        except Exception:
            render_enabled = True
        _sms_icon_prop(
            row,
            prefs,
            'auto_disable_force_enable_render',
            text='',
            icon_name='render_on' if render_enabled else 'render_off',
            fallback_icon='RESTRICT_RENDER_OFF' if render_enabled else 'RESTRICT_RENDER_ON',
            toggle=True,
        )


CLASSES = (
    MS_RuntimeSettings,
)


def _purge_legacy_addon_preferences_class() -> None:
    """Remove AddonPreferences classes from older builds.

    Current Smart Modifier settings are managed in the N-panel through
    WindowManager state.  Registering or leaving an AddonPreferences class makes
    Blender show a Preferences section in the add-on/extension detail UI, so any
    stale class from previous versions is explicitly removed during registration.
    """
    candidates = []
    target_bl_idnames = {
        'smart_modifier_suite',
        'Smart_Modifier_Suite',
        str(__package__ or '').strip(),
        'bl_ext.user_default.smart_modifier_suite',
    }
    for name in tuple(dir(getattr(bpy, 'types', object()))):
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        try:
            bl_idname = str(getattr(cls, 'bl_idname', '') or '')
            module_name = str(getattr(cls, '__module__', '') or '')
            class_name = str(getattr(cls, '__name__', '') or name)
            token = ' '.join((bl_idname, module_name, class_name)).casefold()
            if (
                bl_idname in target_bl_idnames
                or 'smart_modifier_suite' in token
                or 'smart modifier' in token
                or class_name in {'MS_Preferences', 'SmartModifierPreferences', 'SMART_MODIFIER_Preferences'}
            ):
                candidates.append(cls)
        except Exception:
            continue
    for cls in tuple(dict.fromkeys(candidates)):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    _purge_legacy_addon_preferences_class()
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass
    try:
        bpy.types.WindowManager.sms_settings_state = bpy.props.PointerProperty(type=MS_RuntimeSettings)
    except Exception:
        pass
    load_settings(context=getattr(bpy, 'context', None), force=True)


def unregister():
    global _SETTINGS_LOADED
    # Every editable N-panel value is persisted synchronously by its update
    # callback.  Runtime teardown runs before this function and has already
    # detached Scene pointer properties, so a forced snapshot here would turn
    # valid saved Collection/Object selectors into ``null`` on Blender exit.
    try:
        if hasattr(bpy.types.WindowManager, 'sms_settings_state'):
            del bpy.types.WindowManager.sms_settings_state
    except Exception:
        pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _SETTINGS_LOADED = False
