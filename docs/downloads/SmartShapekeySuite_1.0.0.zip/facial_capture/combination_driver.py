# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""Explicit connections for artist-authored corrective keys, using standard drivers.

The BOX weight is the existing Shape Axis BOX weight. No scheduler or Python
driver namespace is needed to play a saved model. Geometry is never changed.
"""
import json,math,uuid
import bpy
from .capture_csv import canonical_name

PROPERTY='smart_shapekey_facial_combination_drivers'
OWNER='smart_shapekey_suite.facial_combination.v1'

def _records(obj):
    raw=obj.get(PROPERTY,'')
    if not raw:return {}
    if not isinstance(raw,str) or len(raw)>65536:raise ValueError('Corrective driver ownership is invalid.')
    try:value=json.loads(raw)
    except (ValueError,TypeError):raise ValueError('Corrective driver ownership is invalid.') from None
    if not isinstance(value,dict) or len(value)>32:raise ValueError('Corrective driver ownership is invalid.')
    for record in value.values():
        if not isinstance(record,dict) or record.get('owner')!=OWNER or not isinstance(record.get('token'),str) or not isinstance(record.get('settings'),dict) or not isinstance(record.get('driver'),dict) or not isinstance(record.get('animation_data_created'),bool):raise ValueError('Corrective driver ownership is invalid.')
    return value

def _target(context,name):
    meshes=[o for o in context.selected_objects if o.type=='MESH']
    obj=context.object
    if context.mode!='OBJECT' or obj not in meshes:raise ValueError('Activate the corrective mesh and select its input parts in Object Mode.')
    keys=obj.data.shape_keys
    if not keys or not keys.use_relative or obj.library or obj.data.library or keys.library or obj.data.users!=1:
        raise ValueError('Use a local unshared mesh with relative shape keys.')
    key=keys.key_blocks.get(name)
    if not key or key==keys.reference_key or canonical_name(key.name):raise ValueError('Choose an existing corrective key outside the ARKit 52 names.')
    if key.relative_key!=keys.reference_key or key.vertex_group or key.mute or not (key.slider_min<=0 and key.slider_max>=1):
        raise ValueError('The corrective key must be unmuted, relative to Basis, and cover values 0 to 1.')
    if len(obj.data.vertices)>200000:raise ValueError('The corrective mesh exceeds 200000 vertices.')
    return obj,keys,key

def _curve(keys,path):
    curves=[f for f in keys.animation_data.drivers if f.data_path==path] if keys.animation_data else []
    if len(curves)>1:raise ValueError('The corrective driver was changed outside this tool.')
    return curves[0] if curves else None

def _signature(curve,keys):
    if not curve:return None
    variables=[]
    for v in curve.driver.variables:
        targets=[]
        for t in v.targets:
            row={'same_key':t.id==keys,'id_type':t.id_type,'path':t.data_path}
            if t.id!=keys:row['key_id_name']=t.id.name if t.id else None
            targets.append(row)
        variables.append({'name':v.name,'type':v.type,'targets':targets})
    return {'array_index':curve.array_index,'mute':curve.mute,'modifiers':len(curve.modifiers),
        'points':len(curve.keyframe_points),'type':curve.driver.type,'expression':curve.driver.expression,'variables':variables}

def _foreign_references(keys,path,allowed):
    bindings=[];ad=keys.animation_data
    if ad:
        if ad.action and ad.action_slot:bindings.append((ad.action,ad.action_slot))
        bindings.extend((s.action,s.action_slot) for track in ad.nla_tracks for s in track.strips if s.action and s.action_slot)
    for action in bpy.data.actions:
        if action.get('smart_shapekey_facial_owner_key')==keys.name:
            bindings.extend((action,s) for s in action.slots if s.identifier==action.get('smart_shapekey_facial_slot_identifier'))
    for action,slot in bindings:
        for layer in action.layers:
            for strip in layer.strips:
                bag=strip.channelbag(slot)
                if bag and any(f.data_path==path for f in bag.fcurves):raise ValueError('The corrective key already has animation or external references.')
    count=0
    for owner in list(bpy.data.objects)+list(bpy.data.shape_keys):
        if not owner.animation_data:continue
        for curve in owner.animation_data.drivers:
            count+=1
            if count>10000:raise ValueError('The driver reference check exceeds 10000 curves.')
            if owner==keys and curve==allowed:continue
            if owner==keys and curve.data_path==path:raise ValueError('The corrective key already has animation or external references.')
            if any(t.id==keys and t.data_path==path for v in curve.driver.variables for t in v.targets):
                raise ValueError('The corrective key already has animation or external references.')

def _source_keys(obj):
    keys=obj.data.shape_keys if obj and obj.type=='MESH' else None
    if not keys or not keys.use_relative or obj.library or obj.data.library or keys.library or obj.data.users!=1:
        raise ValueError('Use local unshared input parts with relative shape keys.')
    return keys

def _input_keys(keys,settings):
    sources=settings.get('sources',[None,None]);result=[]
    for source,name in zip(sources,settings['inputs']):
        source_keys=keys if source is None else _source_keys(bpy.data.objects.get(source))
        key=source_keys.key_blocks.get(name)
        if not key or key.relative_key!=source_keys.reference_key or key.vertex_group or key.mute or not (key.slider_min<=0 and key.slider_max>=1):
            raise ValueError('Corrective inputs must be unmuted Basis-relative ARKit shapes.')
        result.append((source_keys,key))
    return result

def _ramp_starts(mode,centers,start_x,start_y):
    starts=(start_x,start_y)
    if any(type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=1 for v in starts):raise ValueError('Use finite ramp starts between zero and one.')
    if mode!='RAMP':
        if any(starts):raise ValueError('Ramp starts require the RAMP response.')
        return None
    if any(s>=c for s,c in zip(starts,centers)):raise ValueError('Each ramp start must be below its full-response value.')
    return list(starts) if any(starts) else None

def _ramp_expression(settings):
    cx,cy=settings['centers'];starts=settings.get('starts')
    if not starts:return f'min(1,max(0,x/{cx!r}))*min(1,max(0,y/{cy!r}))'
    sx,sy=starts
    return f'min(1,max(0,(x-{sx!r})/({cx!r}-{sx!r})))*min(1,max(0,(y-{sy!r})/({cy!r}-{sy!r})))'


def _settings(keys,key,first,second,center_x,center_y,radius,*,context=None,mode='BOX',sources=None,jaw_floor=None,start_x=0.,start_y=0.):
    if not canonical_name(first) or not canonical_name(second) or canonical_name(first)==canonical_name(second):
        raise ValueError('Choose two different ARKit input keys.')
    values=(center_x,center_y,radius)
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in values) or not (0<=center_x<=1 and 0<=center_y<=1 and .01<=radius<=1):
        raise ValueError('Centers must be 0 to 1 and radius must be 0.01 to 1.')
    if mode not in ('BOX','RAMP','PLATEAU','COMPLEMENT','JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP') or (mode=='RAMP' and (center_x<=0 or center_y<=0)):
        raise ValueError('Ramped inputs require positive full-response values.')
    if mode=='COMPLEMENT' and (center_x,center_y)!=(1,0):raise ValueError('Complementary inputs require centers 1 and 0.')
    starts=_ramp_starts(mode,(center_x,center_y),start_x,start_y)
    floor_mode=mode in ('JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP')
    if floor_mode:
        if [canonical_name(first),canonical_name(second)]!=['tongueOut','jawOpen'] or type(jaw_floor) not in (int,float) or not math.isfinite(jaw_floor) or not .01<=jaw_floor<=1:raise ValueError('Invalid jaw clearance inputs or limit.')
        if mode=='FLOOR_RAMP' and (center_x<=0 or center_y<=0):raise ValueError('Invalid ramp centers.')
    elif jaw_floor is not None:raise ValueError('Jaw clearance limit requires its response mode.')
    if sources is not None and (not isinstance(sources,list) or len(sources)!=2):raise ValueError('Invalid corrective input source list.')
    resolved=[]
    for i,name in enumerate((first,second)):
        source=None if sources is None else sources[i]
        if source is None and keys.key_blocks.get(name):resolved.append(None);continue
        selected=[o for o in getattr(context,'selected_objects',[]) if o.type=='MESH']
        if sources is None:
            candidates=[o for o in selected if o.data.shape_keys and o.data.shape_keys!=keys and o.data.shape_keys.key_blocks.get(name)]
            if len(candidates)!=1:raise ValueError('Select exactly one input part for a missing ARKit key.')
            obj=candidates[0];source=obj.name
        else:
            if not isinstance(source,str) or not source or len(source)>255 or any(ord(c)<32 or ord(c) in (34,92) for c in source):
                raise ValueError('Invalid corrective input source name.')
            obj=bpy.data.objects.get(source)
            if obj not in selected:raise ValueError('Corrective input parts must be selected.')
        _source_keys(obj);resolved.append(source)
    settings={'inputs':[first,second],'centers':[center_x,center_y],'radius':radius}
    if any(s is not None for s in resolved):settings['sources']=resolved
    if mode!='BOX':settings['mode']=mode
    if starts:settings['starts']=starts
    if floor_mode:settings['jaw_floor']=jaw_floor
    inputs=_input_keys(keys,settings);settings['paths']=[k.path_from_id('value') for _,k in inputs]
    return settings

def jaw_floor_expression(settings):
    mode=settings['mode'];limit=settings['jaw_floor'];cx,cy=settings['centers'];radius=settings['radius']
    goal=f'max(y,min(x,{limit!r}))'
    if mode=='JAW_FLOOR':return f'max(0,min(x,{limit!r})-y)'
    def response(jaw):
        distance=f'max(abs(x-{cx!r}),abs({jaw}-{cy!r}))'
        if mode=='FLOOR_PLATEAU':return f'max(0,min(1,2-2*{distance}/{radius!r}))'
        if mode=='FLOOR_RAMP':return f'min(1,max(0,x/{cx!r}))*min(1,max(0,{jaw}/{cy!r}))'
        return f'max(0,1-{distance}/{radius!r})'
    return f'({response(goal)})-({response("y")})'

def _configure(curve,keys,settings):
    curve.mute=False
    for modifier in list(curve.modifiers):curve.modifiers.remove(modifier)
    # A pure response must bypass Blender's default two-point remapping curve.
    while len(curve.keyframe_points):curve.keyframe_points.remove(curve.keyframe_points[-1],fast=True)
    curve.update()
    driver=curve.driver;driver.type='SCRIPTED'
    for variable in list(driver.variables):driver.variables.remove(variable)
    for name,(source,key) in zip(('x','y'),_input_keys(keys,settings)):
        variable=driver.variables.new();variable.name=name;variable.type='SINGLE_PROP'
        target=variable.targets[0];target.id_type='KEY';target.id=source;target.data_path=key.path_from_id('value')
    cx,cy=settings['centers'];radius=settings['radius']
    if settings.get('mode') in ('JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP'):
        driver.expression=jaw_floor_expression(settings)
    elif settings.get('mode','BOX')=='COMPLEMENT':driver.expression='min(1,max(0,x))*(1-min(1,max(0,y)))'
    elif settings.get('mode','BOX')=='RAMP':driver.expression=_ramp_expression(settings)
    elif settings.get('mode','BOX')=='PLATEAU':driver.expression=f'max(0,min(1,2-2*max(abs(x-{cx!r}),abs(y-{cy!r}))/{radius!r}))'
    else:driver.expression=f'max(0,1-max(abs(x-{cx!r}),abs(y-{cy!r}))/{radius!r})'
    if not driver.is_simple_expression:raise ValueError('The corrective driver must use a standard simple expression.')

def bind(context,name,first,second,center_x,center_y,radius,*,mode='BOX',sources=None,jaw_floor=None,start_x=0.,start_y=0.):
    obj,keys,key=_target(context,name);records=_records(obj);record=records.get(name)
    settings=_settings(keys,key,first,second,center_x,center_y,radius,context=context,mode=mode,sources=sources,jaw_floor=jaw_floor,start_x=start_x,start_y=start_y)
    path=key.path_from_id('value');curve=_curve(keys,path)
    if record:
        if _signature(curve,keys)!=record.get('driver'):raise ValueError('The corrective driver was changed outside this tool.')
    elif curve:raise ValueError('The corrective key already has a driver owned by another tool.')
    elif len(records)>=32:raise ValueError('A mesh can own at most 32 corrective drivers.')
    _foreign_references(keys,path,curve)
    if record and settings==record['settings']:return {'key':name,'status':'KEPT'}
    raw=obj.get(PROPERTY);new_curve=curve is None;ad_absent=keys.animation_data is None
    try:
        if new_curve:curve=key.driver_add('value')
        _configure(curve,keys,settings)
        records[name]={'owner':OWNER,'token':record['token'] if record else uuid.uuid4().hex,
            'settings':settings,'driver':_signature(curve,keys),
            'animation_data_created':record['animation_data_created'] if record else ad_absent}
        obj[PROPERTY]=json.dumps(records,sort_keys=True,separators=(',',':'))
        keys.update_tag();context.view_layer.update()
        return {'key':name,'status':'UPDATED' if record else 'CREATED'}
    except Exception:
        if new_curve:
            key.driver_remove('value')
            if ad_absent and keys.animation_data and not keys.animation_data.action and not keys.animation_data.nla_tracks and not keys.animation_data.drivers:keys.animation_data_clear()
        else:_configure(curve,keys,record['settings'])
        if raw is None:
            if PROPERTY in obj:del obj[PROPERTY]
        else:obj[PROPERTY]=raw
        raise

def release(context,name):
    obj,keys,key=_target(context,name);records=_records(obj);record=records.get(name)
    if not record:raise ValueError('This corrective driver is not owned by this tool.')
    path=key.path_from_id('value');curve=_curve(keys,path)
    if _signature(curve,keys)!=record.get('driver'):raise ValueError('The corrective driver was changed outside this tool.')
    _foreign_references(keys,path,curve)
    key.driver_remove('value');records.pop(name)
    if records:obj[PROPERTY]=json.dumps(records,sort_keys=True,separators=(',',':'))
    elif PROPERTY in obj:del obj[PROPERTY]
    if record['animation_data_created'] and keys.animation_data and not keys.animation_data.action and not keys.animation_data.nla_tracks and not keys.animation_data.drivers:keys.animation_data_clear()
    keys.update_tag();context.view_layer.update()
    return {'key':name,'status':'RELEASED','geometry_preserved':True}
