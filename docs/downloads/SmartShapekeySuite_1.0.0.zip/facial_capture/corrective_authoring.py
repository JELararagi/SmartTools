# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""Capture a standard shape mix, let the artist sculpt it, then derive a delta."""
import array,json,math,sys,uuid
from .shape_library import safe_objects,coordinates,digest,topology
from .shape_correction import state,_references
from . import combination_driver as connection

PROPERTY='smart_shapekey_facial_corrective_targets'

def _object(context):
    from ..axis_control.face_tracker import core
    if core.TRACKER_RUNNING:raise ValueError('Stop live Face Tracker before authoring a corrective.')
    objects=[o for o in context.selected_objects if o.type=='MESH']
    if context.mode!='OBJECT' or context.object not in objects:raise ValueError('Activate the corrective mesh and select its input parts in Object Mode.')
    obj=safe_objects([context.object])[0];keys=obj.data.shape_keys
    if not keys or not keys.use_relative:raise ValueError('Use a local unshared mesh with relative shape keys.')
    if sum(len(k.data) for k in keys.key_blocks)>2000000:raise ValueError('Corrective authoring exceeds two million stored shape vertices.')
    return obj,keys

def _records(obj):
    raw=obj.get(PROPERTY,'')
    if not raw:return {}
    try:
        if not isinstance(raw,str) or len(raw)>1024*1024:raise ValueError()
        value=json.loads(raw)
        if not isinstance(value,dict) or len(value)>32:raise ValueError()
        for record in value.values():
            if record['version']!=1 or record['status'] not in ('PREPARED','COMPLETE'):raise ValueError()
        return value
    except (ValueError,TypeError,KeyError):raise ValueError('Corrective target ownership is invalid.') from None

def _verify(obj,keys,record):
    if digest(coordinates(obj.data.vertices))!=record['vertices'] or topology(obj.data)!=record['topology'] or digest(coordinates(keys.reference_key.data))!=record['basis']:
        raise ValueError('The corrective target Basis or topology was changed.')
    baseline=keys.key_blocks.get(record['baseline']);target=keys.key_blocks.get(record['target'])
    if not baseline or not target or state(baseline)!=record['baseline_state']:raise ValueError('The stored corrective mix reference was changed.')
    for name,old in record['original_keys'].items():
        key=keys.key_blocks.get(name)
        if not key or state(key)!=old:raise ValueError('An original shape was edited after capturing the target.')
    if target.relative_key!=keys.reference_key or target.vertex_group:raise ValueError('The target must remain relative to Basis without a vertex group.')
    if _references(keys,[baseline.name,target.name]):raise ValueError('The corrective target already has animation or driver references.')
    return baseline,target

def capture_target(context,target_name,first,second,center_x,center_y,radius,*,mode='BOX',start_x=0.,start_y=0.):
    obj,keys=_object(context);records=_records(obj)
    settings=connection._settings(keys,None,first,second,center_x,center_y,radius,context=context,mode=mode,start_x=start_x,start_y=start_y)
    if not isinstance(target_name,str) or not target_name or len(target_name)>63 or any(c in target_name for c in '\\"\n\r\t') or connection.canonical_name(target_name) or target_name==keys.reference_key.name:
        raise ValueError('Use a non-ARKit name for the editing target.')
    if target_name in records:
        record=records[target_name];_verify(obj,keys,record)
        if record['status']=='PREPARED' and record['settings']==settings:return {'target':target_name,'status':'KEPT'}
        raise ValueError('This editing target is already recorded; choose a new target name.')
    if target_name in keys.key_blocks or len(records)>=32:raise ValueError('The editing target name already exists or the 32-target limit is reached.')
    if obj.show_only_shape_key:raise ValueError('Disable Show Only Shape Key before capturing a new target.')
    context.view_layer.update()
    if any(abs(k.value-c)>1e-5 for (_,k),c in zip(connection._input_keys(keys,settings),settings['centers'])):
        raise ValueError('Set both input values to their centers before capturing the target.')
    old_active=obj.active_shape_key_index;old_only=obj.show_only_shape_key;old_edit=obj.use_shape_key_edit_mode
    original={k.name:state(k) for k in keys.key_blocks};made=[];old_raw=obj.get(PROPERTY)
    try:
        baseline=obj.shape_key_add(name='SS_MixRef_'+uuid.uuid4().hex[:10],from_mix=True);made.append(baseline)
        if any(not math.isfinite(v) for v in _floats(coordinates(baseline.data))):raise ValueError('The corrective target contains non-finite coordinates.')
        target=obj.shape_key_add(name=target_name,from_mix=False);made.append(target)
        target.data.foreach_set('co',_floats(coordinates(baseline.data)))
        baseline.relative_key=keys.reference_key;baseline.value=0;baseline.mute=True
        target.relative_key=keys.reference_key;target.value=0;target.mute=False
        if target.name!=target_name:raise ValueError('Blender changed the requested target name.')
        if any(state(keys.key_blocks[n])!=old for n,old in original.items()):raise RuntimeError('Original shapes changed during target capture.')
        records[target_name]={'version':1,'status':'PREPARED','target':target_name,'baseline':baseline.name,'settings':settings,
            'baseline_state':state(baseline),'original_keys':original,'vertices':digest(coordinates(obj.data.vertices)),
            'basis':digest(coordinates(keys.reference_key.data)),'topology':topology(obj.data),
            'old_active':old_active,'old_only':old_only,'old_edit':old_edit}
        obj[PROPERTY]=json.dumps(records,sort_keys=True,allow_nan=False)
        obj.active_shape_key_index=keys.key_blocks.find(target_name);obj.show_only_shape_key=True;obj.use_shape_key_edit_mode=False
        return {'target':target_name,'status':'CREATED','baseline':baseline.name}
    except Exception:
        for key in reversed(made):obj.shape_key_remove(key)
        obj.active_shape_key_index=old_active;obj.show_only_shape_key=old_only;obj.use_shape_key_edit_mode=old_edit
        if old_raw is None:
            if PROPERTY in obj:del obj[PROPERTY]
        else:obj[PROPERTY]=old_raw
        raise

def _floats(data):
    values=array.array('f');values.frombytes(data)
    if sys.byteorder!='little':values.byteswap()
    return values


def sculpt_root_target(context,target_name,scale_x,scale_y,maximum_delta,*,tip_lift=0.,profile_lift=0.,profile_arrival=.5,thickness_scale=1.,thickness_root_hold=.2,thickness_increment_limit=.0007,tip_profile=False,tip_width=1.,tip_thickness=1.,tip_shortening=0.,tip_root_hold=.45,tip_center_retraction=0.):
    from .target_affine import root_xy_delta,root_tip_thickness_delta,captured_tip_delta
    obj,keys=_object(context);records=_records(obj);record=records.get(target_name)
    if not record or record['status']!='PREPARED':raise ValueError('Capture a new editing target before shaping it.')
    baseline,target=_verify(obj,keys,record)
    previous=coordinates(target.data);reference=coordinates(baseline.data);owned=record.get('root_xy_recipe')
    if owned:
        if owned.get('version') not in (1,2,3,4,5,6) or owned.get('result_sha256')!=digest(previous):raise ValueError('The generated editing target was changed; keep it and capture a new target.')
    elif previous!=reference:raise ValueError('The editing target was manually changed; keep it and capture a new target.')
    raw=_floats(coordinates(keys.reference_key.data));points=[list(raw[i:i+3]) for i in range(0,len(raw),3)]
    base=_floats(reference)
    if isinstance(thickness_scale,bool) or not isinstance(thickness_scale,(int,float)) or not math.isfinite(thickness_scale):raise ValueError('Use finite numeric thickness parameters.')
    if not isinstance(tip_profile,bool):raise ValueError('Use a boolean captured tip mode.')
    if tip_profile:
        reference_points=[list(base[i:i+3]) for i in range(0,len(base),3)]
        recipe=captured_tip_delta(reference_points,tip_width,tip_thickness,tip_shortening,maximum_delta,root_hold=tip_root_hold,center_retraction=tip_center_retraction)
    elif thickness_scale>1:
        if scale_x!=1 or scale_y!=1 or tip_lift!=0 or profile_lift!=0:raise ValueError('Thickness increase preserves width, depth and lift; use neutral shaping parameters.')
        reference_points=[list(base[i:i+3]) for i in range(0,len(base),3)]
        recipe=root_tip_thickness_delta(points,reference_points,thickness_scale,maximum_delta,root_hold=thickness_root_hold,increment_limit=thickness_increment_limit)
    else:
        recipe=root_xy_delta(points,scale_x,scale_y,maximum_delta,tip_lift=tip_lift,profile_lift=profile_lift,profile_arrival=profile_arrival,thickness_scale=thickness_scale)
    wanted=array.array('f',(base[i]+recipe['delta'][i//3][i%3] for i in range(len(base))))
    result_bytes=wanted.tobytes()
    if sys.byteorder!='little':wanted.byteswap();result_bytes=wanted.tobytes();wanted.byteswap()
    if previous==result_bytes and owned:return dict(target=target_name,status='KEPT',maximum_delta=recipe['maximum_delta'])
    old_raw=obj.get(PROPERTY)
    try:
        target.data.foreach_set('co',wanted)
        if digest(coordinates(target.data))!=digest(result_bytes):raise RuntimeError('The generated editing target did not match the prepared coordinates.')
        _verify(obj,keys,record)
        record['root_xy_recipe']=dict(version=6 if tip_profile else (4 if thickness_scale>1 else 3),mode='CAPTURED_TIP_PROFILE' if tip_profile else ('THICKEN_CAPTURED_REFERENCE' if thickness_scale>1 else 'BASIS_SHAPING'),tip_width=tip_width if tip_profile else None,tip_thickness=tip_thickness if tip_profile else None,tip_shortening=tip_shortening if tip_profile else None,tip_root_hold=tip_root_hold if tip_profile else None,tip_center_retraction=tip_center_retraction if tip_profile else None,thickness_root_hold=thickness_root_hold if thickness_scale>1 else None,thickness_increment_limit=thickness_increment_limit if thickness_scale>1 else None,scale_x=scale_x,scale_y=scale_y,limit=maximum_delta,tip_lift=tip_lift,profile_lift=profile_lift,profile_arrival=profile_arrival,thickness_scale=thickness_scale,center_x=recipe['center_x'],root_y=recipe['root_y'],result_sha256=digest(result_bytes))
        encoded=json.dumps(records,sort_keys=True,allow_nan=False)
        if len(encoded)>1024*1024:raise ValueError('Corrective target ownership is invalid.')
        obj[PROPERTY]=encoded;keys.update_tag();context.view_layer.update()
        return dict(target=target_name,status='SHAPED',maximum_delta=recipe['maximum_delta'])
    except Exception:
        target.data.foreach_set('co',_floats(previous));obj[PROPERTY]=old_raw;keys.update_tag();context.view_layer.update();raise

def create_corrective(context,target_name,helper_name,first,second,center_x,center_y,radius,*,mode='BOX',start_x=0.,start_y=0.):
    obj,keys=_object(context);records=_records(obj);record=records.get(target_name)
    if not record:raise ValueError('Capture an editing target with this tool first.')
    baseline,target=_verify(obj,keys,record)
    if record['status']=='COMPLETE':
        owned=connection._records(obj).get(record['helper']);helper=keys.key_blocks.get(record['helper'])
        if helper and helper_name==record['helper'] and owned and owned['token']==record['driver_token']:
            if connection._signature(connection._curve(keys,helper.path_from_id('value')),keys)!=owned['driver']:raise ValueError('The corrective driver was changed outside this tool.')
            return {'key':helper_name,'status':'KEPT'}
        raise ValueError('The completed corrective was changed; keep it and use a new editing target.')
    settings=connection._settings(keys,None,first,second,center_x,center_y,radius,context=context,mode=mode,start_x=start_x,start_y=start_y)
    if settings['inputs']!=record['settings']['inputs'] or settings['centers']!=record['settings']['centers'] or settings.get('sources')!=record['settings'].get('sources') or settings.get('mode','BOX')!=record['settings'].get('mode','BOX') or settings.get('starts',[0.,0.])!=record['settings'].get('starts',[0.,0.]):
        raise ValueError('Use the input names and centers recorded with the editing target.')
    if not helper_name or len(helper_name)>63 or helper_name in keys.key_blocks or connection.canonical_name(helper_name):
        raise ValueError('Use a new non-ARKit name for the corrective key.')
    wanted=_floats(coordinates(target.data));reference=_floats(coordinates(baseline.data));basis=_floats(coordinates(keys.reference_key.data))
    result=array.array('f',(b+t-r for b,t,r in zip(basis,wanted,reference)))
    if any(not math.isfinite(v) for v in result):raise ValueError('The corrective target contains non-finite coordinates.')
    old_raw=obj.get(PROPERTY);driver_raw=obj.get(connection.PROPERTY);ad_absent=keys.animation_data is None
    old_active=obj.active_shape_key_index;old_only=obj.show_only_shape_key;old_edit=obj.use_shape_key_edit_mode
    old_target_value=target.value;old_target_mute=target.mute;helper=None
    try:
        helper=obj.shape_key_add(name=helper_name,from_mix=False);helper.relative_key=keys.reference_key;helper.value=0;helper.slider_min=0;helper.slider_max=1
        if helper.name!=helper_name:raise ValueError('Blender changed the requested corrective name.')
        helper.data.foreach_set('co',result)
        connection.bind(context,helper_name,first,second,center_x,center_y,radius,mode=mode,sources=settings.get('sources'),start_x=start_x,start_y=start_y)
        owned=connection._records(obj)[helper_name]
        record.update(status='COMPLETE',helper=helper_name,driver_token=owned['token'],helper_initial_sha256=digest(coordinates(helper.data)),target_finished_sha256=digest(coordinates(target.data)))
        target.value=0;target.mute=True
        obj[PROPERTY]=json.dumps(records,sort_keys=True,allow_nan=False)
        obj.show_only_shape_key=record['old_only'];obj.use_shape_key_edit_mode=record['old_edit'];obj.active_shape_key_index=keys.key_blocks.find(helper_name)
        keys.update_tag();context.view_layer.update()
        return {'key':helper_name,'status':'CREATED','target':target_name,'original_keys_preserved':True}
    except Exception:
        if helper:obj.shape_key_remove(helper)
        if driver_raw is None:
            if connection.PROPERTY in obj:del obj[connection.PROPERTY]
        else:obj[connection.PROPERTY]=driver_raw
        if ad_absent and keys.animation_data and not keys.animation_data.action and not keys.animation_data.nla_tracks and not keys.animation_data.drivers:keys.animation_data_clear()
        obj[PROPERTY]=old_raw;target.value=old_target_value;target.mute=old_target_mute
        obj.active_shape_key_index=old_active;obj.show_only_shape_key=old_only;obj.use_shape_key_edit_mode=old_edit
        raise
