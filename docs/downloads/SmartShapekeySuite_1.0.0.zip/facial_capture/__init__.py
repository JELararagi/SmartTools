# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""Explicit user-operated facial CSV tools inside Smart Shapekey Suite.

This module adds no panel, timer, camera, network connection or new add-on ID.
Standard Key Actions keep playing and remain editable without this module.
"""
import math
import hashlib,json
import zipfile
from pathlib import Path
import bpy
from bpy.props import IntProperty, BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, PointerProperty, StringProperty
from bpy_extras.io_utils import ImportHelper,ExportHelper
from .capture_csv import canonical_name, read_csv
from .capture_take import create_take
from .bone_capture import create_bone_take,target_rig,preflight as preflight_bones,switch_role as switch_bone_role
from .bone_capture_processing import read_bone_calibration,neutral_draft,default_bone_calibration
from .capture_calibration import loads as read_calibration_text,read_table as read_calibration_table,write_table as write_calibration_table,dumps as calibration_dumps
from .shape_library import export_library,apply_library
from .arp_generation import read_recipe,generate
from .video_capture import convert_video,csv_text
from .mediapipe_schema import EXPECTED_CHANNELS
from .blender_bake import preflight_targets
from .shape_correction import apply_correction,restore_initial
from .head_csv import read_head_csv
from .head_bake import create_head_take,switch_head_role,disconnect_head
from .material_correction import correct_material,restore_material,correct_rim
from .working_copy import export_working_copy
from .combination_driver import bind as bind_combination,release as release_combination
from .corrective_authoring import capture_target,create_corrective
from .mix_preview import apply as apply_mix_preview
from .contact_diagnosis import diagnose_selected,write_report,select_report_vertices
from .contact_action import inspect_action_batch
from . import calibration_tools
from . import ark_ops

PREFIX='smart_shapekey_facial_'

def targets(context):
    if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔メッシュを選択してください')
    result=[];owners=set()
    for obj in sorted(context.selected_objects,key=lambda o:o.name):
        if obj.type!='MESH' or not obj.data.shape_keys:continue
        keys=obj.data.shape_keys
        if not any(canonical_name(k.name) for k in keys.key_blocks):continue
        if obj.library or obj.data.library or keys.library:raise ValueError('リンクされたデータは対象にできません: '+obj.name)
        if obj.data.users!=1 or keys.as_pointer() in owners:raise ValueError('共有メッシュは対象にできません: '+obj.name)
        owners.add(keys.as_pointer());result.append(obj)
    if not result:raise ValueError('ARKit名のシェイプキーを持つ顔メッシュを選択してください')
    if len(result)>64:raise ValueError('対象メッシュは64個以内にしてください')
    return result

def _complement_response_updated(self,context):
    if self.combination_response=='COMPLEMENT':
        self.combination_center_x=1.0;self.combination_center_y=0.0

class SMARTSHAPEKEY_PG_FacialCapture(bpy.types.PropertyGroup):
    rig:PointerProperty(name='Facial Rig',type=bpy.types.Object,poll=lambda self,obj:obj.type=='ARMATURE')
    capture_destination:EnumProperty(name='Capture Destination',items=(('BONES','To Bones','ARKit controller bones'),('SHAPEKEYS','To Shape Keys','Existing shape-key comparison mode')),default='BONES')
    bone_start_frame:FloatProperty(name='Start Frame',default=1,min=-1048574,max=1048574)
    bone_frame_offset:FloatProperty(name='Frame Offset',default=0,min=-1048574,max=1048574)
    bone_calibration_enabled:BoolProperty(name='Controller Calibration (EDIT Only)',default=True)
    estimate_nose:BoolProperty(name='Infer Zero Nose Sneer',default=True,description='Only for present columns whose raw maximum is at most0.0004; measured values take priority')
    estimate_cheek:BoolProperty(name='Infer Zero Cheek Squint',default=True,description='Only for present columns whose raw maximum is at most0.0004; measured values take priority')
    nose_k:FloatProperty(name='Nose Estimator k',default=.6,min=0,max=1)
    cheek_k:FloatProperty(name='Cheek Estimator k',default=.8,min=0,max=1)
    bone_calibration_sha:StringProperty(default='',maxlen=64,options={'HIDDEN'})
    bone_calibration_status:StringProperty(default='',maxlen=240,options={'HIDDEN'})
    last_capture_csv:StringProperty(name='Source CSV',subtype='FILE_PATH',default='')
    generation_strength:FloatProperty(name='Initial Shape Strength',default=1,min=.1,max=3)
    recipe_path:StringProperty(name='Custom Pose Recipe (Optional)',subtype='FILE_PATH',default='')
    require_all:BoolProperty(name='Require All ARKit Channels',default=True)
    archive_existing:BoolProperty(name='Keep Existing Actions for New Take',default=False)
    smoothing:FloatProperty(name='EDIT Smoothing (Seconds)',default=0,min=0,max=1,precision=3)
    calibration_enabled:BoolProperty(name='Per-Channel Calibration (EDIT Only)',default=False,
        description='Map neutral to0 and maximum to1 before EDIT gain/smoothing; RAW is preserved')
    calibration_table_json:StringProperty(default='',maxlen=16384,options={'HIDDEN'})
    calibration_label:StringProperty(default='',maxlen=240,options={'HIDDEN'})
    eyes_gain:FloatProperty(name='Eye Strength',default=1,min=0,max=3)
    mouth_gain:FloatProperty(name='Mouth and Jaw Strength',default=1,min=0,max=3)
    brows_gain:FloatProperty(name='Brow Strength',default=1,min=0,max=3)
    cheeks_gain:FloatProperty(name='Cheek and Nose Strength',default=1,min=0,max=3)
    tongue_gain:FloatProperty(name='Tongue Strength',default=1,min=0,max=3)
    head_bone:StringProperty(name='Head Controller',default='c_head.x')
    material_image_node:StringProperty(name='Image Node to Replace',default='')
    material_color:FloatVectorProperty(name='Correction Color (Linear RGBA)',subtype='COLOR',size=4,default=(.584,.205,.250,1),min=0,max=1)
    material_rim_node:StringProperty(name='Rim Mix or Emission Node',default='')
    material_rim_factor:FloatProperty(name='Rim Multiplier',default=.5,min=0,max=1)
    jaw_clearance_limit:FloatProperty(name='Jaw Assist Limit',description='Maximum jaw opening assisted by tongue input; recorded Action coefficients remain unchanged',default=.5,min=.01,max=1,precision=3)
    combination_key:StringProperty(name='Corrective Key',default='SS_Tongue_Midpoint',maxlen=63)
    corrective_tip_profile:BoolProperty(name='Shape Captured Tip',default=False,description='Hold the captured root and change only the distal width, thickness and length')
    corrective_tip_width:FloatProperty(name='Tip Width Scale',default=1,min=1,max=2,precision=3)
    corrective_tip_thickness:FloatProperty(name='Tip Thickness Scale',default=1,min=1,max=3,precision=3)
    corrective_tip_shortening:FloatProperty(name='Tip Shortening (Local)',default=0,min=0,max=.02,precision=6)
    corrective_tip_center_retraction:FloatProperty(name='Tip Retraction (Local)',default=0,min=0,max=.01,precision=6,description='Retract the distal center along local Y while holding the captured root and preserving width and thickness')
    corrective_tip_root_hold:FloatProperty(name='Tip Root Hold',default=.45,min=0,max=.8,precision=3)
    corrective_target:StringProperty(name='Editing Target Key',default='SS_Corrective_Target',maxlen=63)
    corrective_scale_x:FloatProperty(name='Target Width Scale',default=1,min=.6,max=1,precision=6)
    corrective_scale_y:FloatProperty(name='Target Depth Scale',default=1,min=.6,max=1,precision=6)
    corrective_max_delta:FloatProperty(name='Max Displacement',default=.006,min=.000001,max=1,precision=6)
    corrective_thickness_scale:FloatProperty(name='Target Thickness Scale',default=1,min=.4,max=2,precision=6)
    corrective_thickness_root_hold:FloatProperty(name='Thickness Root Hold',description='Keep this root portion unchanged when increasing captured target thickness',default=.2,min=0,max=.8,precision=3)
    corrective_thickness_increment_limit:FloatProperty(name='Max Thickness Gain',description='Maximum per-vertex thickness increase in the part local coordinates',default=.0007,min=.000001,max=.01,precision=6)
    corrective_tip_lift:FloatProperty(name='Tip Lift (Local)',default=0,min=-.01,max=.01,precision=6)
    corrective_profile_lift:FloatProperty(name='Root Lift (Local)',default=0,min=-.01,max=.01,precision=6)
    corrective_profile_arrival:FloatProperty(name='Lift Arrival Position',default=.5,min=.05,max=1,precision=6,description='Root to tip spans zero to one; the front region beyond this position receives the same lift')
    combination_first:StringProperty(name='First ARKit Input',default='jawOpen',maxlen=63)
    combination_second:StringProperty(name='Second ARKit Input',default='tongueOut',maxlen=63)
    combination_center_x:FloatProperty(name='First Input Center',default=.5,min=0,max=1,precision=3)
    combination_center_y:FloatProperty(name='Second Input Center',default=.5,min=0,max=1,precision=3)
    combination_start_x:FloatProperty(name='First Ramp Start',default=0,min=0,max=1,precision=3)
    combination_start_y:FloatProperty(name='Second Ramp Start',default=0,min=0,max=1,precision=3)
    combination_radius:FloatProperty(name='Corrective Radius',default=.5,min=.01,max=1,precision=3)
    combination_response:EnumProperty(name='Corrective Response',items=[('BOX','BOX Weight','Fade around the two input centers.'),('RAMP','Ramped Inputs','Increase from zero to the full-response values, then hold.'),('COMPLEMENT','First × (1 − Second)','First input times one minus second input; fixed centers one and zero.'),('PLATEAU','Plateau BOX','Hold full correction inside half the radius, then fade to zero at the radius.')],default='BOX',update=_complement_response_updated)
    preview_reset_others:BoolProperty(name='Reset Other Inputs for Preview',default=True)
    contact_action_report_name:StringProperty(name='Action Contact Report Text',default='',maxlen=128)
    contact_action_pending:BoolProperty(name='Action Contact Continue',default=False,options={'HIDDEN'})
    contact_action_report_status:StringProperty(name='Action Contact Inspection Result',default='',maxlen=1024)
    contact_report_name:StringProperty(name='Contact Report Text',default='',maxlen=128)
    contact_selection_surface:StringProperty(name='Contact Surface Part',default='',maxlen=128)
    contact_selection_sample:IntProperty(name='Contact Sample Number',default=0,min=0,max=127)
    contact_probe_name:StringProperty(name='Contact Face Probe Report Text',default="",maxlen=128)
    contact_probe_status:StringProperty(name='Contact Face Probe Result',default="",maxlen=1024)
    contact_report_status:StringProperty(name='Contact Inspection Result',default='',maxlen=1024)
    result:StringProperty(name='Import Result',default='Not imported',maxlen=512)
    ark_spec_path:StringProperty(name='Rig Spec JSON',subtype='FILE_PATH',default='',description='The spec JSON (ark_reapply_spec.json format) that names the rig, its ARKit Actions, Action constraints, bone collections and hand values')
    ark_range_mode:EnumProperty(name='Bake Range',items=(('AUTO','Scene + Keys','Bake the scene range joined with the range of the slider and hand-value keys'),('EXPLICIT','Explicit Range','Bake only the frames given below')),default='AUTO')
    ark_frame_start:IntProperty(name='First Frame to Bake',default=1,min=-1048574,max=1048574,description='First frame to bake when Explicit Range is chosen')
    ark_frame_end:IntProperty(name='Last Frame to Bake',default=250,min=-1048574,max=1048574,description='Last frame to bake when Explicit Range is chosen')
    ark_allow_partial:BoolProperty(name='Allow Partial Bake',default=False,description='Bake the explicit range even when slider keys reach outside it (expressions outside the range are lost)')
    ark_verify:BoolProperty(name='Self Check After Bake',default=True,description='Compare the face mesh before and after the bake on every 10th frame and report the largest movement')

class SMARTSHAPEKEY_OT_facial_action_contacts(bpy.types.Operator):
    bl_idname='smart_shapekey.inspect_facial_action_batch'
    bl_label='Inspect Four Action Key Frames'
    bl_description='Inspect up to four assigned ARKit Action key frames and restore the starting frame; stop on contact'
    bl_options={'UNDO'}
    restart:BoolProperty(name='Start New Inspection',default=False,options={'HIDDEN'})
    def execute(self,context):
        from ..translation import pgettext
        try:
            result=inspect_action_batch(context,restart=self.restart)
            level={'WARNING'} if result['status']=='CONTACT_FOUND' else {'INFO'}
            self.report(level,context.scene.smart_shapekey_facial_settings.contact_action_report_status)
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_contact_report(bpy.types.Operator):
    bl_idname='smart_shapekey.inspect_facial_contacts'
    bl_label='Inspect Selected Oral Contacts'
    bl_description='Report exact triangle crossings for the active tongue and selected face or teeth; preserve geometry and Actions'
    bl_options={'UNDO'}
    def execute(self,context):
        try:
            result=diagnose_selected(context);name=write_report(context,result)
            self.report({'INFO'},_status('接触レポートをテキストへ保存: ',context)+name);return {'FINISHED'}
        except (ValueError,RuntimeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_contact_select(bpy.types.Operator):
    bl_idname='smart_shapekey.select_facial_contact_vertices'
    bl_label='Select Contact Vertices'
    bl_description='Select the verified source polygon in an owned editing target after checking the current report and geometry'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=select_report_vertices(context,cfg.contact_selection_surface,cfg.contact_selection_sample)
            self.report({'INFO'},pgettext('Selected {count} source vertices in the editing target.',context).format(count=len(result['vertices'])))
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_contact_probe(bpy.types.Operator):
    bl_idname='smart_shapekey.probe_facial_contact_face'
    bl_label='Probe the Reported Contact Face'
    bl_description='Read finite solid occupancy samples inside the current reported contact face; samples do not certify clearance'
    bl_options=set()
    def execute(self,context):
        from .solid_contact_probe import probe_reported_face,write_probe_report
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            report=probe_reported_face(context,cfg.contact_selection_surface,cfg.contact_selection_sample);name=write_probe_report(context,report)
            self.report({'INFO'},_status('面内標本をテキストへ保存: ',context)+name);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_mix_preview(bpy.types.Operator):
    bl_idname='smart_shapekey.preview_facial_mix'
    bl_label='Preview Two Inputs'
    bl_description='Set the existing two input center values on every matching selected facial part; keep Actions and shape coordinates protected'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            first=canonical_name(cfg.combination_first);second=canonical_name(cfg.combination_second)
            if not first or not second or first==second:raise ValueError('Choose two distinct ARKit preview inputs.')
            result=apply_mix_preview(context,targets(context),{first:cfg.combination_center_x,second:cfg.combination_center_y},reset_others=cfg.preview_reset_others)
            cfg.result=pgettext('Preview synchronized: {parts} parts / {bindings} ARKit bindings',context).format(**result);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_mix_reset(bpy.types.Operator):
    bl_idname='smart_shapekey.reset_facial_mix'
    bl_label='Reset ARKit Values to Zero'
    bl_description='Reset only ARKit coefficients on selected facial parts; keep original shapes, corrective drivers and Actions protected'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        try:
            result=apply_mix_preview(context,targets(context),{},reset_others=True)
            context.scene.smart_shapekey_facial_settings.result=pgettext('ARKit preview reset: {parts} parts / {bindings} bindings',context).format(**result);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_mix_save(bpy.types.Operator,ExportHelper):
    bl_idname='smart_shapekey.save_facial_mix'
    bl_label='Save Facial Mix'
    bl_description='Save the current synchronized ARKit coefficient values from selected facial meshes'
    bl_options=set()
    filename_ext='.ssmix'
    filter_glob:StringProperty(default='*.ssmix',options={'HIDDEN'})
    def execute(self,context):
        from ..translation import pgettext
        from .mix_presets import capture,save
        try:
            values=save(self.filepath,capture([o for o in context.selected_objects if o.type=='MESH']))
            context.scene.smart_shapekey_facial_settings.result=pgettext('Facial mix saved: {count} coefficients',context).format(count=len(values))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_mix_read(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.read_facial_mix'
    bl_label='Read Facial Mix'
    bl_description='Apply a saved ARKit mix to all selected facial parts and reset other ARKit values; preserve existing Actions'
    bl_options={'UNDO'}
    filename_ext='.ssmix'
    filter_glob:StringProperty(default='*.ssmix',options={'HIDDEN'})
    def execute(self,context):
        from ..translation import pgettext
        from .mix_presets import read
        try:
            values=read(self.filepath)
            result=apply_mix_preview(context,[o for o in context.selected_objects if o.type=='MESH'],values,reset_others=True)
            context.scene.smart_shapekey_facial_settings.result=pgettext('Facial mix applied: {parts} parts / {count} coefficients',context).format(parts=result['parts'],count=len(values))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_corrective_target(bpy.types.Operator):
    bl_idname='smart_shapekey.capture_facial_corrective_target'
    bl_label='Capture Mix as Editing Target'
    bl_description='Store the current shape mix as a protected reference and an editable target; original keys stay unchanged'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=capture_target(context,cfg.corrective_target,cfg.combination_first,cfg.combination_second,cfg.combination_center_x,cfg.combination_center_y,cfg.combination_radius,mode=cfg.combination_response,start_x=cfg.combination_start_x if cfg.combination_response=='RAMP' else 0.,start_y=cfg.combination_start_y if cfg.combination_response=='RAMP' else 0.)
            cfg.result=pgettext('Editing target captured: {key}',context).format(key=result['target']);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_corrective_root_target(bpy.types.Operator):
    bl_idname='smart_shapekey.sculpt_root_facial_target'
    bl_label='Shape Editing Target'
    bl_description='Add local width, depth and root-preserving lift profiles to the captured editing target'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        from .corrective_authoring import sculpt_root_target
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            increase=cfg.corrective_thickness_scale>1
            result=sculpt_root_target(context,cfg.corrective_target,1 if increase else cfg.corrective_scale_x,1 if increase else cfg.corrective_scale_y,cfg.corrective_max_delta,tip_lift=0 if increase else cfg.corrective_tip_lift,profile_lift=0 if increase else cfg.corrective_profile_lift,profile_arrival=cfg.corrective_profile_arrival,thickness_scale=cfg.corrective_thickness_scale,thickness_root_hold=cfg.corrective_thickness_root_hold,thickness_increment_limit=cfg.corrective_thickness_increment_limit,tip_profile=cfg.corrective_tip_profile,tip_width=cfg.corrective_tip_width,tip_thickness=cfg.corrective_tip_thickness,tip_shortening=cfg.corrective_tip_shortening,tip_root_hold=cfg.corrective_tip_root_hold,tip_center_retraction=cfg.corrective_tip_center_retraction)
            cfg.result=pgettext('Editing target shaped: {key}',context).format(key=result['target']);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_jaw_clearance(bpy.types.Operator):
    bl_idname='smart_shapekey.create_facial_jaw_clearance'
    bl_label='Create Jaw Assist'
    bl_description='Create the jaw assist: copies the existing jaw and related correctives and adds an opening driven by the tongue input, without changing recorded values'
    bl_options={'UNDO'}
    def execute(self,context):
        from .jaw_clearance import create
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=create(context,cfg.jaw_clearance_limit)
            cfg.result='開口補助: '+str(result['created'])+'個生成（既存表情は保持）';return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_jaw_clearance_remove(bpy.types.Operator):
    bl_idname='smart_shapekey.remove_facial_jaw_clearance'
    bl_label='Remove Jaw Assist'
    bl_description="Remove only the jaw assist made by this tool and keep the original expressions and correctives"
    bl_options={'UNDO'}
    def execute(self,context):
        from .jaw_clearance import remove
        try:
            result=remove(context)
            context.scene.smart_shapekey_facial_settings.result='開口補助: '+str(result['removed'])+'個除去';return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_corrective_create(bpy.types.Operator):
    bl_idname='smart_shapekey.create_facial_corrective_from_target'
    bl_label='Create Corrective from Target'
    bl_description='Derive the edited target minus its stored mix reference, add a new corrective key and connect the two-input BOX driver'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=create_corrective(context,cfg.corrective_target,cfg.combination_key,cfg.combination_first,cfg.combination_second,cfg.combination_center_x,cfg.combination_center_y,cfg.combination_radius,mode=cfg.combination_response,start_x=cfg.combination_start_x if cfg.combination_response=='RAMP' else 0.,start_y=cfg.combination_start_y if cfg.combination_response=='RAMP' else 0.)
            cfg.result=pgettext('Corrective created from target: {key}',context).format(key=result['key']);return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_combination_bind(bpy.types.Operator):
    bl_idname='smart_shapekey.bind_facial_corrective_driver'
    bl_label='Connect Corrective Driver'
    bl_description='Drive an existing corrective key with the Shape Axis BOX weight from two ARKit inputs'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=bind_combination(context,cfg.combination_key,cfg.combination_first,cfg.combination_second,cfg.combination_center_x,cfg.combination_center_y,cfg.combination_radius,mode=cfg.combination_response,start_x=cfg.combination_start_x if cfg.combination_response=='RAMP' else 0.,start_y=cfg.combination_start_y if cfg.combination_response=='RAMP' else 0.)
            cfg.result=pgettext('Corrective driver connected: {key}',context).format(key=result['key'])
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_combination_release(bpy.types.Operator):
    bl_idname='smart_shapekey.release_facial_corrective_driver'
    bl_label='Disconnect Corrective Driver'
    bl_description='Remove only this tool\'s unchanged driver and keep the corrective shape'
    bl_options={'UNDO'}
    def execute(self,context):
        from ..translation import pgettext
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=release_combination(context,cfg.combination_key)
            cfg.result=pgettext('Corrective driver disconnected; shape retained: {key}',context).format(key=result['key'])
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

def material_target(context):
    meshes=[o for o in context.selected_objects if o.type=='MESH']
    if context.mode!='OBJECT' or len(meshes)!=1 or context.object!=meshes[0]:raise ValueError('オブジェクトモードで補正するメッシュ1つだけを選択してください')
    return meshes[0]

class SMARTSHAPEKEY_OT_material_correct(bpy.types.Operator):
    bl_idname='smart_shapekey.correct_facial_material'
    bl_label='Copy Material and Correct Color'
    bl_options={'UNDO'}
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=correct_material(material_target(context),cfg.material_image_node,tuple(cfg.material_color))
            cfg.result=f"材質の色補正：{result['material']} / {result['links']}接続。元の共有材質は保持"
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError) as error:self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_material_rim(bpy.types.Operator):
    bl_idname='smart_shapekey.attenuate_facial_rim'
    bl_label='Adjust Selected Material Rim'
    bl_options={'UNDO'}
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=correct_rim(material_target(context),cfg.material_rim_node,cfg.material_rim_factor)
            cfg.result=f"リム調整：{result['material']} / 倍率{cfg.material_rim_factor:g}"
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError) as error:self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_material_restore(bpy.types.Operator):
    bl_idname='smart_shapekey.restore_facial_material'
    bl_label='Restore Original Shared Material'
    bl_options={'UNDO'}
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            result=restore_material(material_target(context));cfg.result='元の材質を復元：'+result['material']
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError) as error:self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_head_csv(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.import_head_csv'
    bl_label='Bake Head Rotation CSV'
    bl_options={'UNDO'}
    filename_ext='.csv'
    filter_glob:StringProperty(default='*.csv',options={'HIDDEN'})
    source_fps:FloatProperty(name='Source Timecode FPS',default=60,min=1,max=240)
    start_frame:FloatProperty(name='Start Frame',default=1,min=-1048573,max=1048573)
    units:EnumProperty(name='Head Angle Units',items=(('RADIANS','Radians','Use when the CSV uses radians'),('DEGREES','Degrees','Use when the CSV uses degrees')),default='RADIANS')
    pitch_axis:EnumProperty(name='Pitch Local Axis',items=(('X','X',''),('Y','Y',''),('Z','Z','')),default='X')
    yaw_axis:EnumProperty(name='Yaw Local Axis',items=(('X','X',''),('Y','Y',''),('Z','Z','')),default='Y')
    roll_axis:EnumProperty(name='Roll Local Axis',items=(('X','X',''),('Y','Y',''),('Z','Z','')),default='Z')
    invert_pitch:BoolProperty(name='Invert Pitch',default=False)
    invert_yaw:BoolProperty(name='Invert Yaw',default=False)
    invert_roll:BoolProperty(name='Invert Roll',default=False)
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            if context.mode not in ('OBJECT','POSE'):raise ValueError('オブジェクトまたはポーズモードで取り込んでください')
            rows,source=read_head_csv(self.filepath,source_fps=self.source_fps)
            result=create_head_take(rows,cfg.rig,cfg.head_bone,source_text=source,name=Path(self.filepath).stem,
                start_frame=self.start_frame,units=self.units,axes=(self.pitch_axis,self.yaw_axis,self.roll_axis),
                signs=tuple(-1 if x else 1 for x in (self.invert_pitch,self.invert_yaw,self.invert_roll)))
            cfg.result=f"頭回転 {result['samples']}フレーム：EDITアクションで手修正できます"
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,UnicodeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_head_role(bpy.types.Operator):
    bl_idname='smart_shapekey.switch_head_role'
    bl_label='Switch Head Rotation Action'
    bl_options={'UNDO'}
    role:EnumProperty(items=(('RAW_HEAD','RAW','Recorded head rotation'),('EDIT_HEAD','EDIT','Head rotation for manual editing')),default='EDIT_HEAD')
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            obj=switch_head_role(cfg.rig,cfg.head_bone,self.role)
            cfg.result=f"{self.role}：{obj.name}を選択してグラフエディターで編集"
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError) as error:self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_head_disconnect(bpy.types.Operator):
    bl_idname='smart_shapekey.disconnect_head_capture'
    bl_label='Disconnect Head Capture'
    bl_options={'UNDO'}
    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            disconnect_head(cfg.rig,cfg.head_bone)
            cfg.result='頭収録の接続を解除しました。身体アクションと保管テイクは保持しています'
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError) as error:self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

def _capture_calibration(cfg):
    if not cfg.calibration_enabled:return None
    if not cfg.calibration_table_json:raise ValueError('Load a calibration CSV/JSON table before enabling calibration.')
    return read_calibration_text(cfg.calibration_table_json)

def _bone_calibration(cfg):
    if not cfg.bone_calibration_enabled:return None
    if cfg.calibration_table_json:return read_calibration_text(cfg.calibration_table_json)
    return default_bone_calibration()[0]

def _bone_take(context,cfg,clip,*,name,source_text,source,start_frame,frame_offset,source_sha='',source_fps=60):
    result=create_bone_take(clip,target_rig(context,cfg),name=name,source_text=source_text,
        source=source,source_sha256=source_sha,source_fps=source_fps,start_frame=start_frame,
        frame_offset=frame_offset,archive_existing=cfg.archive_existing,calibration=_bone_calibration(cfg),
        calibration_sha256=(cfg.bone_calibration_sha if cfg.calibration_table_json else default_bone_calibration()[1]) if cfg.bone_calibration_enabled else '',
        smoothing_seconds=cfg.smoothing,estimate_nose=cfg.estimate_nose,estimate_cheek=cfg.estimate_cheek,
        nose_k=cfg.nose_k,cheek_k=cfg.cheek_k)
    if cfg.bone_calibration_enabled and not cfg.calibration_table_json:
        result['warnings'].append('汎用校正表を使用。本人用の校正表があれば読み込んで差し替えできます。')
    return result

class SMARTSHAPEKEY_OT_facial_calibration_read(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.import_facial_calibration'
    bl_label='Load Per-Channel Calibration'
    bl_options={'UNDO'}
    filename_ext='.json'
    filter_glob:StringProperty(default='*.json;*.csv',options={'HIDDEN'})
    def execute(self,context):
        try:
            cfg=context.scene.smart_shapekey_facial_settings
            if cfg.capture_destination=='BONES':table,digest,status=read_bone_calibration(self.filepath)
            else:table=read_calibration_table(self.filepath);digest='';status=''
            encoded=calibration_dumps(table)
            previous=(cfg.calibration_table_json,cfg.calibration_label,cfg.bone_calibration_sha,cfg.bone_calibration_status)
            try:
                cfg.calibration_table_json=encoded
                cfg.calibration_label=str(len(table['channels']))+' / '+Path(self.filepath).name
                cfg.bone_calibration_sha=digest;cfg.bone_calibration_status=status
            except Exception:
                cfg.calibration_table_json,cfg.calibration_label,cfg.bone_calibration_sha,cfg.bone_calibration_status=previous;raise
            self.report({'INFO'},_status('校正表を読み込みました。RAWは保持し、EDITにだけ適用します。',context))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,UnicodeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_calibration_save(bpy.types.Operator,ExportHelper):
    bl_idname='smart_shapekey.export_facial_calibration'
    bl_label='Save Per-Channel Calibration'
    bl_options=set()
    filename_ext='.json'
    filter_glob:StringProperty(default='*.json;*.csv',options={'HIDDEN'})
    file_format:EnumProperty(name='Calibration Format',items=(('JSON','JSON','Calibration JSON'),('CSV','CSV','Calibration CSV')),default='JSON')
    def check(self,context):
        suffix='.csv' if self.file_format=='CSV' else '.json';self.filename_ext=suffix
        if self.filepath and Path(self.filepath).suffix.lower()!=suffix:
            self.filepath=str(Path(self.filepath).with_suffix(suffix));return True
        return False
    def execute(self,context):
        try:
            cfg=context.scene.smart_shapekey_facial_settings
            if not cfg.calibration_table_json:raise ValueError('Load a calibration table before saving.')
            table=read_calibration_text(cfg.calibration_table_json)
            target=Path(self.filepath).with_suffix('.csv' if self.file_format=='CSV' else '.json')
            write_calibration_table(target,table)
            self.report({'INFO'},_status('校正表を保存しました。',context));return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,UnicodeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_neutral_draft(bpy.types.Operator,ExportHelper):
    bl_idname='smart_shapekey.export_facial_neutral_draft'
    bl_label='Save Neutral Calibration Draft'
    filename_ext='.json'
    filter_glob:StringProperty(default='*.json',options={'HIDDEN'})
    source_csv:StringProperty(name='Source CSV',subtype='FILE_PATH')
    source_fps:FloatProperty(name='Source Timecode FPS',default=60,min=1,max=240)
    neutral_seconds:FloatProperty(name='Neutral Seconds',default=.5,min=.01,max=5)
    neutral_frames:IntProperty(name='First N Frames (0 = Seconds)',default=0,min=0,max=30000)
    def draw(self,context):
        for field in ('source_csv','source_fps','neutral_seconds','neutral_frames'):self.layout.prop(self,field)
        self.layout.label(text='maxは手入力してください。下書きは未受入です。')
    def execute(self,context):
        try:
            path=Path(self.source_csv)
            if not path.is_file() or path.stat().st_size>20*1024*1024:raise ValueError('Source CSV must be within 20 MiB.')
            clip=read_csv(path,source_fps=self.source_fps)
            table=neutral_draft(clip,source=str(path),seconds=self.neutral_seconds,frames=self.neutral_frames)
            dest=Path(self.filepath).with_suffix('.json')
            with dest.open('x',encoding='utf-8') as stream:json.dump(table,stream,ensure_ascii=False,indent=2,allow_nan=False)
            self.report({'INFO'},_status('neutralの下書きを保存しました。maxは手入力してください。',context));return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,UnicodeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_csv(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.import_facial_csv'
    bl_label='Bake Facial CSV'
    bl_options={'UNDO'}
    filename_ext='.csv'
    filter_glob:StringProperty(default='*.csv',options={'HIDDEN'})
    source_fps:FloatProperty(name='Source Timecode FPS',default=60,min=1,max=240)
    start_frame:FloatProperty(name='Start Frame',default=1,min=-1048574,max=1048574)
    frame_offset:FloatProperty(name='Frame Offset',default=0,min=-1048574,max=1048574)
    units:EnumProperty(name='Coefficient Units',items=(('UNIT','0 to 1','Standard coefficients'),('PERCENT','0 to 100','Divide percentages by one hundred')),default='UNIT')

    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            if cfg.capture_destination=='BONES':
                path=Path(self.filepath)
                if path.suffix.lower()!='.csv' or not path.is_file() or path.stat().st_size>20*1024*1024:
                    raise ValueError('20 MiB以内のCSVファイルを指定してください')
                source=path.read_text(encoding='utf-8-sig')
                clip=read_csv(path,source_fps=self.source_fps,value_scale=.01 if self.units=='PERCENT' else 1,range_policy='reject')
                result=_bone_take(context,cfg,clip,name='SmartShapekey_'+path.stem,source_text=source,
                    source=str(path),source_sha=hashlib.sha256(path.read_bytes()).hexdigest(),
                    start_frame=self.start_frame,frame_offset=self.frame_offset,source_fps=self.source_fps)
                cfg.last_capture_csv=str(path)
                cfg.result=f"骨 {len(result['raw']['mapped_channels'])} / 無い列 {len(result['missing_columns'])} / 未対応骨 {len(result['unmapped_channels'])}"
                for warning in result['warnings']:self.report({'WARNING'},warning)
                frame=result['start_frame'];context.scene.frame_set(math.floor(frame),subframe=frame%1)
                self.report({'WARNING'} if result['missing_columns'] or result['unmapped_channels'] else {'INFO'},_status(cfg.result,context))
                return {'FINISHED'}
            calibration=_capture_calibration(cfg)
            objects=targets(context);path=Path(self.filepath)
            if path.suffix.lower()!='.csv' or not path.is_file() or path.stat().st_size>20*1024*1024:
                raise ValueError('20 MiB以内のCSVファイルを指定してください')
            source=path.read_text(encoding='utf-8-sig')
            clip=read_csv(path,source_fps=self.source_fps,value_scale=.01 if self.units=='PERCENT' else 1,range_policy='reject')
            result=create_take(clip,objects,name='SmartShapekey_'+path.stem,source_text=source,
                start_frame=self.start_frame,require_all=cfg.require_all,archive_existing=cfg.archive_existing,
                smoothing_seconds=cfg.smoothing,gains={'eyes':cfg.eyes_gain,'mouth':cfg.mouth_gain,
                    'brows':cfg.brows_gain,'cheeks':cfg.cheeks_gain,'tongue':cfg.tongue_gain},calibration=calibration)
            cfg.result=f"対応 {len(result['raw']['mapped_channels'])} / 未対応 {len(result['unmapped_channels'])} / {clip.duration:.2f}秒"
            context.scene.frame_set(math.floor(self.start_frame),subframe=self.start_frame%1)
            self.report({'WARNING'} if result['unmapped_channels'] else {'INFO'},_status(cfg.result,context))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,UnicodeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_video(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.import_facial_video'
    bl_label='Bake Video to Facial Action'
    bl_options={'UNDO'}
    filename_ext='.mp4'
    filter_glob:StringProperty(default='*.mp4;*.mov;*.mkv;*.avi;*.webm',options={'HIDDEN'})
    start_frame:FloatProperty(name='Start Frame',default=1,min=-1048574,max=1048574)
    frame_offset:FloatProperty(name='Frame Offset',default=0,min=-1048574,max=1048574)
    input_mirrored:BoolProperty(name='Recording Is Mirrored',default=False)
    timestamps:EnumProperty(name='Video Timestamps',items=(('decoded','Recorded timestamps','Use decoded timestamps'),
        ('cfr','Constant FPS','Explicitly use frame indices for constant FPS recording')),default='decoded')

    def execute(self,context):
        cfg=context.scene.smart_shapekey_facial_settings
        try:
            from ..axis_control.face_tracker import core,installer
            if core.TRACKER_RUNNING:raise ValueError('ライブフェイストラッカーを停止してから録画を取り込んでください')
            if cfg.capture_destination=='BONES':
                rig=target_rig(context,cfg)
                bindings,_=preflight_bones(rig,EXPECTED_CHANNELS,archive_existing=cfg.archive_existing)
                fps=context.scene.render.fps/context.scene.render.fps_base
                duration_limit=min(30,(250000/(2*len(bindings))-2)/fps)
                if not math.isfinite(duration_limit) or duration_limit<=0:raise ValueError('ベイクの上限を超えています')
                installer.ensure_dependency_target_on_path()
                model=Path(core.__file__).parent/'assets/face_landmarker.task'
                clip,metadata=convert_video(self.filepath,model,input_mirrored=self.input_mirrored,
                    timestamps=self.timestamps,max_duration=duration_limit)
                result=_bone_take(context,cfg,clip,name='SmartShapekey_'+Path(self.filepath).stem,
                    source_text=csv_text(clip),source=str(Path(self.filepath)),source_fps=float(metadata.get('declared_fps',fps)),
                    start_frame=self.start_frame,frame_offset=self.frame_offset)
                metadata['take_id']=result['take_id'];metadata['source_text']=result['source_text']
                context.scene['smart_shapekey_facial_video_report']=json.dumps(metadata,allow_nan=False)
                cfg.result=f"動画→骨 {len(result['raw']['mapped_channels'])} / 無い列 {len(result['missing_columns'])} / {clip.duration:.2f}秒"
                for warning in result['warnings']:self.report({'WARNING'},warning)
                frame=result['start_frame'];context.scene.frame_set(math.floor(frame),subframe=frame%1)
                self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
            calibration=_capture_calibration(cfg)
            objects=targets(context)
            bindings,_=preflight_targets(objects,EXPECTED_CHANNELS,allow_new_take=cfg.archive_existing)
            if cfg.require_all and set(EXPECTED_CHANNELS)-set(bindings):raise ValueError('動画の51表情に対応するキーが必要です')
            fps=context.scene.render.fps/context.scene.render.fps_base
            duration_limit=min(30,(250000/sum(len(v) for v in bindings.values())-2)/fps)
            if not math.isfinite(duration_limit) or duration_limit<=0:raise ValueError('ベイクする対象・fpsが上限を超えています')
            installer.ensure_dependency_target_on_path()
            model=Path(core.__file__).parent/'assets/face_landmarker.task'
            clip,metadata=convert_video(self.filepath,model,input_mirrored=self.input_mirrored,
                timestamps=self.timestamps,max_duration=duration_limit)
            result=create_take(clip,objects,name='SmartShapekey_'+Path(self.filepath).stem,source_text=csv_text(clip),
                start_frame=self.start_frame,require_all=cfg.require_all,archive_existing=cfg.archive_existing,
                smoothing_seconds=cfg.smoothing,gains={'eyes':cfg.eyes_gain,'mouth':cfg.mouth_gain,
                    'brows':cfg.brows_gain,'cheeks':cfg.cheeks_gain,'tongue':cfg.tongue_gain},calibration=calibration)
            metadata['take_id']=result['take_id'];metadata['source_text']=result['source_text']
            context.scene['smart_shapekey_facial_video_report']=json.dumps(metadata,allow_nan=False)
            cfg.result=f"動画51表情 / {clip.duration:.2f}秒 / 舌・頭回転は未収録"
            context.scene.frame_set(math.floor(self.start_frame),subframe=self.start_frame%1)
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,ImportError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_role(bpy.types.Operator):
    bl_idname='smart_shapekey.switch_facial_role'
    bl_label='Switch Facial Action'
    bl_options={'UNDO'}
    role:EnumProperty(items=(('RAW_CAPTURE','RAW','Recorded values'),('EDIT_CAPTURE','EDIT','Action for manual editing')),default='EDIT_CAPTURE')

    def execute(self,context):
        changes=[];before=[]
        try:
            cfg=context.scene.smart_shapekey_facial_settings
            if cfg.capture_destination=='BONES':
                switch_bone_role(target_rig(context,cfg),self.role)
                context.scene.frame_set(context.scene.frame_current,subframe=context.scene.frame_subframe)
                cfg.result='RAW：収録時の骨の値' if self.role=='RAW_CAPTURE' else 'EDIT：手修正できる骨のアクション'
                return {'FINISHED'}
            for obj in targets(context):
                keys=obj.data.shape_keys;ad=keys.animation_data
                if not ad or not ad.action:raise ValueError('選択メッシュに収録アクションがありません: '+obj.name)
                if ad.use_nla and any(not t.mute for t in ad.nla_tracks):raise ValueError('有効なNLAを保護します: '+obj.name)
                current=ad.action;take=current.get(PREFIX+'take_id');owner=current.get(PREFIX+'owner_key')
                if not take or not owner:raise ValueError('このアドオンで取り込んだ収録アクションではありません: '+obj.name)
                matches=[a for a in bpy.data.actions if a.get(PREFIX+'take_id')==take and a.get(PREFIX+'owner_key')==owner and a.get(PREFIX+'role')==self.role]
                if len(matches)!=1:raise ValueError('RAW/EDITの対応を一意に確認できません: '+obj.name)
                action=matches[0];slot_name=action.get(PREFIX+'slot_identifier')
                slots=[s for s in action.slots if s.identifier==slot_name and s.target_id_type=='KEY']
                if len(slots)!=1:raise ValueError('キーのアクションスロットが一致しません: '+obj.name)
                changes.append((keys,action,slots[0]))
                before.append((keys,current,ad.action_slot))
            for keys,action,slot in changes:
                keys.animation_data.action=action;keys.animation_data.action_slot=slot
            context.scene.frame_set(context.scene.frame_current,subframe=context.scene.frame_subframe)
            context.scene.smart_shapekey_facial_settings.result='RAW：収録時の値' if self.role=='RAW_CAPTURE' else 'EDIT：グラフエディターで手修正できます'
            return {'FINISHED'}
        except (ValueError,RuntimeError,TypeError) as error:
            for keys,action,slot in before:
                keys.animation_data.action=action
                if slot:keys.animation_data.action_slot=slot
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_export(bpy.types.Operator,ExportHelper):
    bl_idname='smart_shapekey.export_facial_library'
    bl_label='Save Facial Shapes and Correctives'
    selection_only:BoolProperty(name='Save Selected Parts Only',description='Save the existing channels and owned correctives of the selected parts; this does not certify all 52 expressions',default=False)
    filename_ext='.ssfacial'
    filter_glob:StringProperty(default='*.ssfacial',options={'HIDDEN'})
    def draw(self,context):
        from ..axis_control.face_tracker.ui import _ui_text
        self.layout.prop(self,'selection_only',text=_ui_text('Save Selected Parts Only','選択した部品だけ保存',context))
        self.layout.label(text=_ui_text('Existing channels only; 52 expressions are not required' if self.selection_only else 'All 52 ARKit expressions are required','既存表情だけ保存します（52表情の完成判定はしません）' if self.selection_only else '選択全体にARKit 52表情が必要です',context))
    def execute(self,context):
        try:
            from ..translation import pgettext
            result=export_library(targets(context),self.filepath,selection_only=self.selection_only)
            context.scene.smart_shapekey_facial_settings.result=pgettext('Facial preset saved: {parts} parts / {shapes} shapes / {correctives} correctives',context).format(parts=result['parts'],shapes=result['shape_bindings'],correctives=result['corrective_bindings'])
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError) as error:
            from ..translation import pgettext
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_work_copy(bpy.types.Operator,ExportHelper):
    bl_idname='smart_shapekey.export_facial_working_copy'
    bl_label='Export Facial Working Copy'
    filename_ext='.blend'
    filter_glob:StringProperty(default='*.blend',options={'HIDDEN'})
    def execute(self,context):
        try:
            cfg=context.scene.smart_shapekey_facial_settings
            result=export_working_copy(context,[o for o in context.selected_objects if o.type=='MESH'],cfg.rig,self.filepath)
            cfg.result=f"顔制作コピーを保存：{result['face_parts']}部品。コピーを開いて初期形状を生成してください"
            self.report({'INFO'},_status(cfg.result,context));return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_generate(bpy.types.Operator):
    bl_idname='smart_shapekey.generate_facial_arp52'
    bl_label='Generate 52 Initial Shapes from ARP'
    bl_options={'UNDO'}
    def execute(self,context):
        try:
            if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔メッシュを選択してください')
            cfg=context.scene.smart_shapekey_facial_settings
            path=bpy.path.abspath(cfg.recipe_path) if cfg.recipe_path else Path(__file__).with_name('arp52_draft_recipe.json')
            recipe=read_recipe(path)
            result=generate([o for o in context.selected_objects if o.type=='MESH'],cfg.rig,recipe,strength=cfg.generation_strength)
            result['recipe_sha256']=hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()
            result['rig']=cfg.rig.name;result['strength']=cfg.generation_strength
            context.scene['smart_shapekey_facial_generation_report']=json.dumps(result,allow_nan=False)
            cfg.result=f"初期52表情を生成：{result['bindings']}キー / 見た目の調整が必要です"
            self.report({'INFO'},_status(cfg.result,context))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_correct(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.correct_owned_facial_shapes'
    bl_label='Apply Correction Preset'
    bl_options={'UNDO'}
    filename_ext='.ssfacial'
    filter_glob:StringProperty(default='*.ssfacial',options={'HIDDEN'})
    def execute(self,context):
        try:
            if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔部品を選択してください')
            result=apply_correction([o for o in context.selected_objects if o.type=='MESH'],self.filepath)
            context.scene.smart_shapekey_facial_settings.result=f"初期形状を保管して補正：更新 {result['changed_owned']} / 追加 {result['new_bindings']}"
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError,zipfile.BadZipFile) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_restore(bpy.types.Operator):
    bl_idname='smart_shapekey.restore_initial_facial_shapes'
    bl_label='Restore Archived Initial Shapes'
    bl_options={'UNDO'}
    def execute(self,context):
        try:
            if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔部品を選択してください')
            result=restore_initial([o for o in context.selected_objects if o.type=='MESH'])
            context.scene.smart_shapekey_facial_settings.result=f"初期表情を復元：{result['parts']}部品"
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError) as error:
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

class SMARTSHAPEKEY_OT_facial_apply(bpy.types.Operator,ImportHelper):
    bl_idname='smart_shapekey.apply_facial_library'
    bl_label='Apply Facial Shapes and Correctives'
    bl_options={'UNDO'}
    filename_ext='.ssfacial'
    filter_glob:StringProperty(default='*.ssfacial',options={'HIDDEN'})
    def execute(self,context):
        try:
            from ..translation import pgettext
            if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔メッシュを選択してください')
            result=apply_library([o for o in context.selected_objects if o.type=='MESH'],self.filepath)
            context.scene.smart_shapekey_facial_settings.result=pgettext('Facial preset applied: {shapes} new shapes / {correctives} new correctives',context).format(shapes=result['created'],correctives=result.get('correctives_created',0))
            return {'FINISHED'}
        except (ValueError,RuntimeError,OSError,KeyError,TypeError,zipfile.BadZipFile) as error:
            from ..translation import pgettext
            self.report({'ERROR'},_message(error,context));return {'CANCELLED'}

def _status(text,context=None):
    from ..translation import translate_known
    return translate_known(text,context)

def _message(error,context=None):
    from ..translation import exception_text
    return exception_text(error,context)

def _heading(layout,context,label_en,label_ja,help_id,icon='NONE'):
    """Group heading with the section help "?" at its right end (no explanation text in the panel)."""
    from ..axis_control.face_tracker.ui import _draw_help_button,_ui_text
    row=layout.row(align=True)
    split=row.split(factor=0.85,align=True)
    left=split.row(align=True)
    left.label(text=_ui_text(label_en,label_ja,context),icon=icon)
    right=split.row(align=True);right.alignment='RIGHT'
    _draw_help_button(right,help_id,context)
    return row

def draw(layout,context):
    from ..ui_sections import stacked_prop
    # Reuse the Suite's existing disclosure style inside Face Tracker.
    # SmartTools help rule (2026-10-17): explanations live in the "?" help of each heading.
    from ..axis_control.face_tracker.ui import _draw_section,_ui_text
    box=_draw_section(layout,context,'face_tracker.capture_csv',_ui_text('Facial CSV Capture','フェイシャルCSV収録',context),
        'ACTION','face_tracker_capture_csv',default=False)
    if box is None:return
    cfg=context.scene.smart_shapekey_facial_settings
    stacked_prop(box,cfg,'rig')
    _heading(box,context,'Initial shapes (rig building)','初期形状の生成','facial_shape_generation','SHAPEKEY_DATA')
    box.operator('smart_shapekey.export_facial_working_copy',icon='EXPORT')
    box.prop(cfg,'generation_strength');stacked_prop(box,cfg,'recipe_path')
    box.operator('smart_shapekey.generate_facial_arp52',icon='SHAPEKEY_DATA')
    correction=box.column(align=True)
    correction.operator('smart_shapekey.correct_owned_facial_shapes',icon='IMPORT')
    correction.operator('smart_shapekey.restore_initial_facial_shapes',icon='LOOP_BACK')
    box.prop(cfg,'jaw_clearance_limit')
    jaw_row=box.column(align=True);jaw_row.operator('smart_shapekey.create_facial_jaw_clearance');jaw_row.operator('smart_shapekey.remove_facial_jaw_clearance')
    box.separator()
    _heading(box,context,'Corrective key (two inputs)','補正キー（2 つの入力）','facial_corrective','DRIVER')
    stacked_prop(box,cfg,'combination_response')
    active_keys=context.object.data.shape_keys if context.object and context.object.type=='MESH' else None
    if active_keys:stacked_prop(box,cfg,'combination_key',search=(active_keys,'key_blocks'))
    else:stacked_prop(box,cfg,'combination_key')
    stacked_prop(box,cfg,'combination_first');stacked_prop(box,cfg,'combination_second')
    centers=box.column(align=True);centers.enabled=cfg.combination_response!='COMPLEMENT'
    if cfg.combination_response=='RAMP':
        centers.prop(cfg,'combination_center_x',text=_ui_text('First Full Response','1つ目の最大補正値',context))
        centers.prop(cfg,'combination_center_y',text=_ui_text('Second Full Response','2つ目の最大補正値',context))
    else:centers.prop(cfg,'combination_center_x');centers.prop(cfg,'combination_center_y')
    box.prop(cfg,'preview_reset_others')
    preview=box.column(align=True)
    preview.operator('smart_shapekey.preview_facial_mix',icon='HIDE_OFF')
    preview.operator('smart_shapekey.reset_facial_mix',icon='LOOP_BACK')
    mixes=box.column(align=True)
    mixes.operator('smart_shapekey.save_facial_mix',icon='EXPORT')
    mixes.operator('smart_shapekey.read_facial_mix',icon='IMPORT')
    radius_row=box.row();radius_row.enabled=cfg.combination_response in ('BOX','PLATEAU');radius_row.prop(cfg,'combination_radius')
    if cfg.combination_response=='RAMP':
        starts=box.column(align=True);starts.prop(cfg,'combination_start_x');starts.prop(cfg,'combination_start_y')
    stacked_prop(box,cfg,'corrective_target')
    author=box.column(align=True)
    author.operator('smart_shapekey.capture_facial_corrective_target',icon='SHAPEKEY_DATA')
    author.prop(cfg,'corrective_tip_profile')
    if cfg.corrective_tip_profile:
        row=author.column(align=True);row.prop(cfg,'corrective_tip_width');row.prop(cfg,'corrective_tip_thickness')
        author.prop(cfg,'corrective_tip_shortening');author.prop(cfg,'corrective_tip_center_retraction');author.prop(cfg,'corrective_tip_root_hold')
    else:
        increase=cfg.corrective_thickness_scale>1
        scales=author.column(align=True);scales.enabled=not increase;scales.prop(cfg,'corrective_scale_x');scales.prop(cfg,'corrective_scale_y')
        author.prop(cfg,'corrective_thickness_scale')
        lifts=author.column(align=True);lifts.enabled=not increase;lifts.prop(cfg,'corrective_tip_lift')
        profile=lifts.column(align=True);profile.prop(cfg,'corrective_profile_lift');profile.prop(cfg,'corrective_profile_arrival')
        if increase:
            guards=author.column(align=True);guards.prop(cfg,'corrective_thickness_root_hold');guards.prop(cfg,'corrective_thickness_increment_limit')
    author.prop(cfg,'corrective_max_delta')
    author.operator('smart_shapekey.sculpt_root_facial_target',icon='SHAPEKEY_DATA')
    author.operator('smart_shapekey.create_facial_corrective_from_target',icon='SHAPEKEY_DATA')
    combination=box.column(align=True)
    combination.operator('smart_shapekey.bind_facial_corrective_driver',icon='DRIVER')
    combination.operator('smart_shapekey.release_facial_corrective_driver',icon='UNLINKED')
    box.separator()
    _heading(box,context,'Facial presets','表情・補正プリセット','facial_library','EXPORT')
    library=box.column(align=True)
    library.operator('smart_shapekey.export_facial_library',text=_ui_text('Save Shapes and Correctives','表情・補正を保存',context),icon='EXPORT')
    library.operator('smart_shapekey.apply_facial_library',text=_ui_text('Apply Shapes and Correctives','表情・補正を適用',context),icon='IMPORT')
    inspection=box.box()
    _heading(inspection,context,'Oral contact inspection','口内の接触検査','facial_contact_inspection','VIEWZOOM')
    inspection.operator('smart_shapekey.inspect_facial_contacts',icon='VIEWZOOM')
    action_row=inspection.column(align=True)
    action_row.operator('smart_shapekey.inspect_facial_action_batch',text=_ui_text('Start Action Inspection','アクション検査開始',context),icon='PLAY').restart=True
    action_next=action_row.column(align=True);action_next.enabled=bool(cfg.contact_action_report_name and cfg.contact_action_pending)
    action_next.operator('smart_shapekey.inspect_facial_action_batch',text=_ui_text('Next Four Key Frames','次のキー4点',context),icon='NEXT_KEYFRAME').restart=False
    if cfg.contact_action_report_status:
        inspection.label(text=_status(cfg.contact_action_report_status,context))
        inspection.label(text=cfg.contact_action_report_name,translate=False,icon='TEXT')
    stacked_prop(inspection,cfg,'contact_selection_surface',text=_ui_text('Contact Surface Part','交差した相手部品',context))
    inspection.prop(cfg,'contact_selection_sample',text=_ui_text('Contact Sample Number','交差例の番号（0始まり）',context))
    inspection.operator('smart_shapekey.select_facial_contact_vertices',icon='VERTEXSEL')
    inspection.operator('smart_shapekey.probe_facial_contact_face',icon='VIEWZOOM')
    if cfg.contact_probe_status:
        for line in _status(cfg.contact_probe_status,context).split('\n'):inspection.label(text=line,translate=False)
        inspection.label(text=cfg.contact_probe_name,translate=False,icon='TEXT')
    if cfg.contact_report_status:
        for line in _status(cfg.contact_report_status,context).split('\n'):inspection.label(text=line,translate=False)
        inspection.label(text=cfg.contact_report_name,translate=False,icon='TEXT')
    box.separator()
    _heading(box,context,'Capture settings','収録の取り込みの設定','facial_capture_setup','IMPORT')
    if cfg.capture_destination=='SHAPEKEYS':box.prop(cfg,'require_all')
    box.prop(cfg,'archive_existing')
    stacked_prop(box,cfg,'capture_destination')
    bone_mode=cfg.capture_destination=='BONES'
    if bone_mode:
        box.prop(cfg,'bone_start_frame');box.prop(cfg,'bone_frame_offset')
    _heading(box,context,'Calibration (EDIT only)','校正（EDITだけ）','facial_calibration','PREFERENCES')
    if bone_mode:
        box.prop(cfg,'bone_calibration_enabled',text=_ui_text('Bone Calibration (EDIT Only)','骨の校正（EDITのみ）',context))
        if cfg.bone_calibration_enabled and not cfg.calibration_table_json:box.label(text=_ui_text('In use: generic table','使用中: 汎用校正表（本人用は任意）',context))
        box.prop(cfg,'estimate_nose');box.prop(cfg,'nose_k')
        box.prop(cfg,'estimate_cheek');box.prop(cfg,'cheek_k')
    else:box.prop(cfg,'calibration_enabled',text=_ui_text('Per-Channel Calibration (EDIT Only)','係数別校正（EDITのみ）',context))
    box.operator('smart_shapekey.import_facial_calibration',text=_ui_text('Load Calibration','校正表を読む',context),icon='IMPORT')
    calibration_row=box.row(align=True)
    calibration_row.operator('smart_shapekey.export_facial_calibration',text='JSON',translate=False,icon='EXPORT').file_format='JSON'
    calibration_row.operator('smart_shapekey.export_facial_calibration',text='CSV',translate=False,icon='EXPORT').file_format='CSV'
    if cfg.calibration_label:box.label(text=cfg.calibration_label,translate=False)
    if bone_mode:
        draft=box.operator('smart_shapekey.export_facial_neutral_draft',text=_ui_text('Neutral Draft JSON','neutralの下書きJSON',context))
        draft.source_csv=cfg.last_capture_csv
        if cfg.bone_calibration_status:box.label(text=_status(cfg.bone_calibration_status,context),translate=False)
    calibration_tools.draw_build(box,context)
    _heading(box,context,'Bake and RAW / EDIT','取り込みと RAW／EDIT','facial_capture_bake','ACTION')
    box.prop(cfg,'smoothing')
    if not bone_mode:
        for field in ('eyes_gain','mouth_gain','brows_gain','cheeks_gain','tongue_gain'):box.prop(cfg,field)
    op=box.operator('smart_shapekey.import_facial_csv',icon='IMPORT')
    op.start_frame=cfg.bone_start_frame if bone_mode else context.scene.frame_current+context.scene.frame_subframe
    op.frame_offset=cfg.bone_frame_offset if bone_mode else 0
    video=box.operator('smart_shapekey.import_facial_video',icon='FILE_MOVIE')
    video.start_frame=cfg.bone_start_frame if bone_mode else context.scene.frame_current+context.scene.frame_subframe
    video.frame_offset=cfg.bone_frame_offset if bone_mode else 0
    row=box.row(align=True)
    row.operator('smart_shapekey.switch_facial_role',text='RAW').role='RAW_CAPTURE'
    row.operator('smart_shapekey.switch_facial_role',text='EDIT').role='EDIT_CAPTURE'
    calibration_tools.draw_inspection(box,context)
    box.separator()
    _heading(box,context,'Head rotation CSV','頭の回転CSV','facial_head_capture','BONE_DATA')
    if cfg.rig and cfg.rig.type=='ARMATURE':stacked_prop(box,cfg,'head_bone',search=(cfg.rig.data,'bones'))
    else:stacked_prop(box,cfg,'head_bone')
    head=box.operator('smart_shapekey.import_head_csv',icon='IMPORT')
    head.start_frame=context.scene.frame_current+context.scene.frame_subframe
    heads=box.row(align=True)
    heads.operator('smart_shapekey.switch_head_role',text=_ui_text('Head RAW','頭RAW',context)).role='RAW_HEAD'
    heads.operator('smart_shapekey.switch_head_role',text=_ui_text('Head EDIT','頭EDIT',context)).role='EDIT_HEAD'
    box.operator('smart_shapekey.disconnect_head_capture',icon='UNLINKED')
    ark_ops.draw(box,context,_heading)
    box.separator()
    _heading(box,context,'Material color correction','材質の色補正','facial_material','MATERIAL')
    material=context.object.active_material if context.object and context.object.type=='MESH' else None
    if material and material.node_tree:stacked_prop(box,cfg,'material_image_node',search=(material.node_tree,'nodes'))
    else:stacked_prop(box,cfg,'material_image_node')
    box.prop(cfg,'material_color')
    box.operator('smart_shapekey.correct_facial_material',icon='MATERIAL')
    if material and material.node_tree:stacked_prop(box,cfg,'material_rim_node',search=(material.node_tree,'nodes'))
    else:stacked_prop(box,cfg,'material_rim_node')
    box.prop(cfg,'material_rim_factor')
    box.operator('smart_shapekey.attenuate_facial_rim',icon='MATERIAL')
    box.operator('smart_shapekey.restore_facial_material',icon='LOOP_BACK')
    box.label(text=_status(cfg.result,context))

classes=(SMARTSHAPEKEY_PG_FacialCapture,SMARTSHAPEKEY_OT_facial_neutral_draft,SMARTSHAPEKEY_OT_facial_calibration_read,SMARTSHAPEKEY_OT_facial_calibration_save,SMARTSHAPEKEY_OT_facial_action_contacts,SMARTSHAPEKEY_OT_facial_contact_report,SMARTSHAPEKEY_OT_facial_contact_select,SMARTSHAPEKEY_OT_facial_contact_probe,SMARTSHAPEKEY_OT_facial_work_copy,SMARTSHAPEKEY_OT_facial_csv,SMARTSHAPEKEY_OT_facial_video,SMARTSHAPEKEY_OT_facial_role,SMARTSHAPEKEY_OT_facial_export,SMARTSHAPEKEY_OT_facial_apply,SMARTSHAPEKEY_OT_facial_generate,SMARTSHAPEKEY_OT_facial_correct,SMARTSHAPEKEY_OT_facial_restore,SMARTSHAPEKEY_OT_head_csv,SMARTSHAPEKEY_OT_head_role,SMARTSHAPEKEY_OT_head_disconnect,SMARTSHAPEKEY_OT_material_correct,SMARTSHAPEKEY_OT_material_rim,SMARTSHAPEKEY_OT_material_restore)

def register(ledger):
    from .. import lifecycle
    for cls in (SMARTSHAPEKEY_OT_facial_mix_preview,SMARTSHAPEKEY_OT_facial_mix_reset,SMARTSHAPEKEY_OT_facial_mix_save,SMARTSHAPEKEY_OT_facial_mix_read):lifecycle.register_class(ledger,cls)
    for cls in (SMARTSHAPEKEY_OT_corrective_target,SMARTSHAPEKEY_OT_corrective_root_target,SMARTSHAPEKEY_OT_corrective_create):lifecycle.register_class(ledger,cls)
    for cls in (SMARTSHAPEKEY_OT_jaw_clearance,SMARTSHAPEKEY_OT_jaw_clearance_remove,SMARTSHAPEKEY_OT_combination_bind,SMARTSHAPEKEY_OT_combination_release):lifecycle.register_class(ledger,cls)
    for cls in classes:lifecycle.register_class(ledger,cls)
    lifecycle.register_rna_property(ledger,bpy.types.Scene,'smart_shapekey_facial_settings',PointerProperty(type=SMARTSHAPEKEY_PG_FacialCapture))
    calibration_tools.register(ledger)
    for cls in ark_ops.CLASSES:lifecycle.register_class(ledger,cls)

def unregister():
    # The existing Suite ledger removes only this registration's exact resources.
    return None
