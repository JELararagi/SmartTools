# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""Declarative corrective payloads; selected source parts, no executable code."""
import array,math,sys
from types import SimpleNamespace
from .capture_csv import ARKIT_NAMES,canonical_name

def _settings(value):
    required={'inputs','centers','radius'}
    if not isinstance(value,dict) or not required<=set(value) or set(value)-required-{'sources','mode','jaw_floor','starts'}:raise ValueError('Invalid corrective BOX settings.')
    inputs=value['inputs'];centers=value['centers'];radius=value['radius']
    if not isinstance(inputs,list) or len(inputs)!=2 or inputs[0]==inputs[1] or any(n not in ARKIT_NAMES for n in inputs):raise ValueError('Invalid corrective ARKit input names.')
    if not isinstance(centers,list) or len(centers)!=2 or any(type(v) not in (float,int) or not math.isfinite(v) or not 0<=v<=1 for v in centers):raise ValueError('Invalid corrective centers.')
    if type(radius) not in (float,int) or not math.isfinite(radius) or not .01<=radius<=1:raise ValueError('Invalid corrective radius.')
    mode=value.get('mode','BOX')
    if mode not in ('BOX','RAMP','PLATEAU','COMPLEMENT','JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP') or (mode=='RAMP' and any(c<=0 for c in centers)):raise ValueError('Invalid corrective response mode.')
    if mode=='COMPLEMENT' and tuple(centers)!=(1,0):raise ValueError('Complementary inputs require centers 1 and 0.')
    if 'starts' in value:
        from .combination_driver import _ramp_starts
        if not isinstance(value['starts'],list) or len(value['starts'])!=2:raise ValueError('Invalid ramp start pair.')
        _ramp_starts(mode,centers,*value['starts'])
    floor_mode=mode in ('JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP')
    if floor_mode:
        limit=value.get('jaw_floor')
        if inputs!=['tongueOut','jawOpen'] or type(limit) not in (int,float) or not math.isfinite(limit) or not .01<=limit<=1 or (mode=='FLOOR_RAMP' and any(c<=0 for c in centers)):raise ValueError('Invalid jaw clearance settings.')
    elif 'jaw_floor' in value:raise ValueError('Unexpected jaw clearance limit.')
    sources=value.get('sources',[None,None])
    if not isinstance(sources,list) or len(sources)!=2:raise ValueError('Invalid corrective input source list.')
    if any(s is not None and (not isinstance(s,str) or not s or len(s)>255 or any(ord(c)<32 or ord(c) in (34,92) for c in s)) for s in sources):raise ValueError('Invalid corrective input source name.')
    return value

def validate_input_parts(manifest):
    parts={p['name']:p for p in manifest['objects']}
    for part in manifest['objects']:
        for row in part.get('correctives',[]):
            box=_settings(row['box'])
            if manifest['version']<3 and ('sources' in box or 'mode' in box):raise ValueError('Invalid corrective response mode.')
            for channel,source in zip(box['inputs'],box.get('sources',[None,None])):
                name=part['name'] if source is None else source
                if name not in parts:raise ValueError('The corrective source part is absent from the preset.')
                if channel not in {s['name'] for s in parts[name]['shapes']}:raise ValueError('The corrective input is absent from its preset source part.')

def export_correctives(obj,index,part,payload):
    from . import combination_driver as connection
    from .shape_library import coordinates,digest
    records=connection._records(obj);keys=obj.data.shape_keys;rows=[];size=0
    # Preserve Blender's floating-point shape accumulation and driver order.
    ordered=[k.name for k in keys.key_blocks if k.name in records]
    if set(ordered)!=set(records):raise ValueError('The owned corrective shape is absent.')
    for name in ordered:
        record=records[name]
        key=keys.key_blocks.get(name);settings=record['settings']
        if not key or key==keys.reference_key or canonical_name(name) or key.relative_key!=keys.reference_key or key.vertex_group or key.mute:raise ValueError('The owned corrective shape was changed or muted.')
        curve=connection._curve(keys,key.path_from_id('value'))
        if connection._signature(curve,keys)!=record['driver']:raise ValueError('The corrective driver was changed outside this tool.')
        connection._input_keys(keys,settings)
        declarative={'inputs':[canonical_name(n) for n in settings['inputs']],'centers':settings['centers'],'radius':settings['radius']}
        if 'sources' in settings:declarative['sources']=settings['sources']
        if settings.get('mode','BOX')!='BOX':declarative['mode']=settings['mode']
        if 'jaw_floor' in settings:declarative['jaw_floor']=settings['jaw_floor']
        if 'starts' in settings:declarative['starts']=settings['starts']
        _settings(declarative)
        data=coordinates(key.data);values=array.array('f');values.frombytes(data)
        if sys.byteorder!='little':values.byteswap()
        if any(not math.isfinite(v) for v in values):raise ValueError('The corrective target contains non-finite coordinates.')
        member=f'parts/{index:03d}/correctives/{len(rows):03d}.f32';payload[member]=data;size+=len(data)
        rows.append({'name':name,'member':member,'sha256':digest(data),'slider_min':key.slider_min,'slider_max':key.slider_max,'interpolation':key.interpolation,'box':declarative})
    if rows:part['correctives']=rows
    return len(rows),size

def read_correctives(archive,part,index,payload,expected,names):
    from .shape_library import digest
    rows=part.get('correctives',[])
    if not isinstance(rows,list) or len(rows)>32:raise ValueError('Invalid corrective count in the preset.')
    used=set();count=part['vertex_count']
    for j,row in enumerate(rows):
        if not isinstance(row,dict) or set(row)!= {'name','member','sha256','slider_min','slider_max','interpolation','box'}:raise ValueError('Invalid corrective descriptor in the preset.')
        name=row['name'];member=row['member']
        if not isinstance(name,str) or not name or len(name)>63 or name=='Basis' or canonical_name(name) or name in used or member!=f'parts/{index:03d}/correctives/{j:03d}.f32':raise ValueError('Invalid corrective name or member path.')
        _settings(row['box'])
        if member not in names or archive.getinfo(member).file_size!=count*12:raise ValueError('Invalid corrective coordinate length.')
        data=archive.read(member)
        if digest(data)!=row['sha256']:raise ValueError('Corrective coordinate hash mismatch.')
        values=array.array('f');values.frombytes(data)
        if sys.byteorder!='little':values.byteswap()
        if any(not math.isfinite(v) for v in values):raise ValueError('The corrective target contains non-finite coordinates.')
        lo=row['slider_min'];hi=row['slider_max']
        if any(type(v) not in (float,int) or not math.isfinite(v) for v in (lo,hi)) or not (-10<=lo<=0 and 1<=hi<=10):raise ValueError('Invalid corrective slider range.')
        if row['interpolation'] not in ('KEY_LINEAR','KEY_CARDINAL','KEY_CATMULL_ROM','KEY_BSPLINE'):raise ValueError('Invalid corrective interpolation.')
        payload[member]=values;expected.add(member);used.add(name)

def apply_correctives(objects,manifest,payload,apply_shapes):
    import bpy
    from . import combination_driver as connection
    from .shape_library import coordinates,digest
    validate_input_parts(manifest)
    objects=list(objects);by_name={o.name:o for o in objects};parts={p['name']:p for p in manifest['objects']};plans=[];kept=0
    contexts={o.name:SimpleNamespace(object=o,selected_objects=objects,mode='OBJECT',view_layer=bpy.context.view_layer) for o in objects}
    existing_maps={o.name:{canonical_name(k.name):k for k in o.data.shape_keys.key_blocks if canonical_name(k.name)} if o.data.shape_keys else {} for o in objects}
    def refs(owner,box,require_existing=False):
        keys=[]
        for channel,source in zip(box['inputs'],box.get('sources',[None,None])):
            source_obj=by_name[owner.name if source is None else source];source_keys=source_obj.data.shape_keys
            key=existing_maps[source_obj.name].get(channel)
            if key:
                if key.relative_key!=source_keys.reference_key or key.vertex_group or key.mute or not (key.slider_min<=0 and key.slider_max>=1):raise ValueError('Corrective inputs must be unmuted Basis-relative ARKit shapes.')
            else:
                incoming=next(r for r in parts[source_obj.name]['shapes'] if r['name']==channel)
                if require_existing or not incoming['slider_min']<=0<=1<=incoming['slider_max']:raise ValueError('Corrective inputs must be unmuted Basis-relative ARKit shapes.')
            keys.append(key)
        return keys
    for part in manifest['objects']:
        obj=by_name[part['name']];keys=obj.data.shape_keys;records=connection._records(obj);rows=part.get('correctives',[])
        if len(records)+sum(1 for row in rows if row['name'] not in records)>32:raise ValueError('A mesh can own at most 32 corrective drivers.')
        for row in rows:
            box=row['box'];input_keys=refs(obj,box);existing=keys.key_blocks.get(row['name']) if keys else None
            if existing:
                owned=records.get(row['name']);input_keys=refs(obj,box,True)
                if not owned or digest(coordinates(existing.data))!=row['sha256'] or existing.relative_key!=keys.reference_key or existing.vertex_group or existing.mute or existing.slider_min!=row['slider_min'] or existing.slider_max!=row['slider_max'] or existing.interpolation!=row['interpolation']:raise ValueError('Protecting a different or foreign existing corrective key.')
                wanted=connection._settings(keys,existing,input_keys[0].name,input_keys[1].name,*box['centers'],box['radius'],context=contexts[obj.name],mode=box.get('mode','BOX'),sources=box.get('sources'),jaw_floor=box.get('jaw_floor'),start_x=box.get('starts',[0.,0.])[0],start_y=box.get('starts',[0.,0.])[1])
                curve=connection._curve(keys,existing.path_from_id('value'))
                if owned['settings']!=wanted or connection._signature(curve,keys)!=owned['driver']:raise ValueError('Protecting a different or foreign existing corrective key.')
                connection._foreign_references(keys,existing.path_from_id('value'),curve);kept+=1
            else:plans.append((obj,row))
    old_names={o.name:set(k.name for k in o.data.shape_keys.key_blocks) if o.data.shape_keys else set() for o in objects}
    old_active={o.name:o.active_shape_key_index for o in objects};old_properties={o.name:o.get(connection.PROPERTY) for o in objects}
    old_ad_absent={o.name:not o.data.shape_keys or o.data.shape_keys.animation_data is None for o in objects}
    try:
        result=apply_shapes(objects,manifest,payload)
        for obj,row in plans:
            keys=obj.data.shape_keys;key=obj.shape_key_add(name=row['name'],from_mix=False);key.relative_key=keys.reference_key;key.value=0
            if key.name!=row['name']:raise ValueError('Blender changed the requested corrective name.')
            key.data.foreach_set('co',payload[row['member']]);key.slider_min=row['slider_min'];key.slider_max=row['slider_max'];key.interpolation=row['interpolation']
            box=row['box'];actual=[]
            for channel,source in zip(box['inputs'],box.get('sources',[None,None])):
                source_obj=by_name[obj.name if source is None else source]
                lookup={canonical_name(k.name):k.name for k in source_obj.data.shape_keys.key_blocks if canonical_name(k.name)};actual.append(lookup[channel])
            connection.bind(contexts[obj.name],key.name,*actual,*box['centers'],box['radius'],mode=box.get('mode','BOX'),sources=box.get('sources'),jaw_floor=box.get('jaw_floor'),start_x=box.get('starts',[0.,0.])[0],start_y=box.get('starts',[0.,0.])[1])
        result.update(correctives_created=len(plans),identical_correctives_kept=kept,preset_version=manifest['version']);return result
    except Exception:
        for obj in reversed(objects):
            if obj.data.shape_keys:
                for key in reversed(list(obj.data.shape_keys.key_blocks)):
                    if key.name not in old_names[obj.name]:obj.shape_key_remove(key)
            raw=old_properties[obj.name]
            if raw is None:
                if connection.PROPERTY in obj:del obj[connection.PROPERTY]
            else:obj[connection.PROPERTY]=raw
            keys=obj.data.shape_keys
            if old_ad_absent[obj.name] and keys and keys.animation_data and not keys.animation_data.action and not keys.animation_data.nla_tracks and not keys.animation_data.drivers:keys.animation_data_clear()
        raise
    finally:
        for obj in objects:obj.active_shape_key_index=old_active[obj.name]
