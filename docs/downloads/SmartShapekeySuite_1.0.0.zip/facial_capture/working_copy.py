# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""Explicit face-scene library export. No edits to source objects, rigs or keys."""
from pathlib import Path
import bpy
from .shape_library import safe_objects

def _write_scene(path,scene):
    bpy.data.libraries.write(str(path),{scene},path_remap='ABSOLUTE',fake_user=False,compress=True)

def _driver_objects(owner,source_scene):
    result=[];animation=getattr(owner,'animation_data',None)
    if animation:
        for curve in animation.drivers:
            for variable in curve.driver.variables:
                for target in variable.targets:
                    if isinstance(target.id,bpy.types.Scene):
                        raise ValueError('シーンを参照するドライバーは原シーン全体を含むため、このコピーでは扱えません')
                    if isinstance(target.id,bpy.types.Object):result.append(target.id)
    return result

def export_working_copy(context,objects,rig,path):
    if context.mode!='OBJECT':raise ValueError('オブジェクトモードで顔メッシュを選択してください')
    objects=safe_objects(objects)
    if rig is None or rig.type!='ARMATURE' or rig.library or rig.data.library:
        raise ValueError('ローカルの表情リグを指定してください')
    path=Path(bpy.path.abspath(str(path))).resolve()
    if path.suffix.lower()!='.blend' or not path.parent.is_dir():raise ValueError('保存先に既存フォルダーの.blendを指定してください')
    if path.exists():raise ValueError('既存ファイルを保護します。新しい名前で保存してください')
    source=context.scene;layer=context.view_layer
    if any(o.name not in layer.objects for o in objects+[rig]):raise ValueError('顔とリグは現在のビューレイヤー内に必要です')
    included=set(objects)|{rig};queue=list(included);visited_trees=set()
    def add(obj):
        if isinstance(obj,bpy.types.Object) and obj not in included:
            included.add(obj);queue.append(obj)
            if len(included)>128:raise ValueError('参照物が128個を超えます。顔専用モデルで作業してください')
    def tree_dependencies(tree):
        if not tree or tree.as_pointer() in visited_trees:return
        visited_trees.add(tree.as_pointer())
        for obj in _driver_objects(tree,source):add(obj)
        for node in tree.nodes:
            add(getattr(node,'object',None))
            if node.type=='GROUP':tree_dependencies(getattr(node,'node_tree',None))
    while queue:
        obj=queue.pop();add(obj.parent)
        for owner in (obj,obj.data,getattr(obj.data,'shape_keys',None)):
            if owner:
                for dependency in _driver_objects(owner,source):add(dependency)
        for modifier in obj.modifiers:
            if modifier.show_viewport or modifier.show_render:
                for field in ('object','target','origin','mirror_object'):add(getattr(modifier,field,None))
        constraints=list(obj.constraints)
        if obj.type=='ARMATURE':constraints.extend(c for p in obj.pose.bones for c in p.constraints)
        for constraint in constraints:add(getattr(constraint,'target',None))
        if obj.type=='MESH':
            for material in obj.data.materials:
                if material:
                    for dependency in _driver_objects(material,source):add(dependency)
                    tree_dependencies(material.node_tree)
    tree_dependencies(source.world.node_tree if source.world else None)
    # World trees may have added dependencies after the object traversal.
    if queue:raise ValueError('ワールドが追加のオブジェクト参照を持つため、このコピーでは扱えません')
    temporary=None
    try:
        temporary=bpy.data.scenes.new('Facial_Working_Copy')
        temporary.world=source.world
        temporary.render.fps=source.render.fps;temporary.render.fps_base=source.render.fps_base
        temporary.frame_start=source.frame_start;temporary.frame_end=source.frame_end
        temporary.frame_current=source.frame_current;temporary.frame_subframe=source.frame_subframe
        temporary.unit_settings.system=source.unit_settings.system;temporary.unit_settings.scale_length=source.unit_settings.scale_length
        for field in ('view_transform','look','exposure','gamma'):
            setattr(temporary.view_settings,field,getattr(source.view_settings,field))
        for obj in sorted(included,key=lambda o:o.name):temporary.collection.objects.link(obj)
        new_layer=temporary.view_layers[0]
        for obj in included:
            if obj.name in layer.objects:obj.hide_set(obj.hide_get(view_layer=layer),view_layer=new_layer)
        temporary['smart_shapekey_facial_working_copy']=True
        temporary['smart_shapekey_facial_source_file']=bpy.data.filepath
        temporary['smart_shapekey_facial_source_scene']=source.name
        cfg=temporary.smart_shapekey_facial_settings;original=source.smart_shapekey_facial_settings
        cfg.rig=rig;cfg.recipe_path=original.recipe_path;cfg.generation_strength=original.generation_strength
        _write_scene(path,temporary)
        if not path.is_file():raise RuntimeError('制作コピーが保存されませんでした')
        return {'path':str(path),'face_parts':len(objects),'scene_objects':len(included),'objects':sorted(o.name for o in included),'source_unchanged':True}
    finally:
        if temporary is not None:bpy.data.scenes.remove(temporary,do_unlink=True)
