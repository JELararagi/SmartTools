# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""ARKit facial rig tools: bake to hand keys, return to expression mode, check / reapply from a spec JSON.

Every name (rig, bones, constraints, Actions, slots, collections, hand values) is read from the
explicitly chosen spec JSON (format ``mik_ark_reapply_spec``).  Nothing here executes Text blocks or
other code, and no character-specific name is written in this module.

Mutations run inside a journal (``_Txn``).  Any exception rolls back every journaled change, so a
failed operation leaves the scene as it was.  Only transaction-owned data is touched: the bake
records what it disabled, created and replaced, and the return undoes exactly that.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
import os
import struct
import uuid

import bpy

SPEC_FORMAT = 'mik_ark_reapply_spec'
RECORD_KEY = 'smart_shapekey_ark_bake'
RECORD_SCHEMA = 'smart_shapekey.ark_bake.v1'
BACKUP_KEY = 'smart_shapekey_ark_bake_backup'
# Records written by the older Text-block tools.  A bake made by them is not owned here.
FOREIGN_RECORD_KEYS = ('ark_baked_channels', 'ark_baked_extra', 'ark_bake_static', 'ark_bake_backup',
                       'ark_bake_slot', 'ark_bake_range')
LIVE_PROP_DEFAULT = 'ark_live'
HAND_GROUP = 'ARK hand'
KEYING_SET_NAME = '顔の手付け'
KEYING_SET_IDNAME = 'ark_face_hand'
KEYING_SET_GROUP = 'ARK baked'
SPEC_MAX_BYTES = 16 * 1024 * 1024
MAX_BAKE_FRAMES = 100000

CON_KEYS = ('name', 'index', 'target', 'action', 'action_slot', 'space_object', 'owner_space', 'target_space',
            'space_subtarget', 'mute', 'enabled', 'influence', 'subtarget', 'mix_mode', 'transform_channel',
            'use_bone_object_action', 'frame_start', 'frame_end', 'max', 'min', 'eval_time', 'use_eval_time')
# Same fields, same order as the reviewed reapply script.
ACTION_FIELDS = ('owner_space', 'target_space', 'space_subtarget', 'mute', 'enabled', 'influence', 'subtarget',
                 'mix_mode', 'transform_channel', 'use_bone_object_action', 'frame_start', 'frame_end', 'max', 'min',
                 'eval_time', 'use_eval_time')
_CON_TYPES = {'name': str, 'index': int, 'target': str, 'action': str, 'action_slot': str, 'owner_space': str,
              'target_space': str, 'space_subtarget': str, 'mute': bool, 'enabled': bool, 'influence': float,
              'subtarget': str, 'mix_mode': str, 'transform_channel': str, 'use_bone_object_action': bool,
              'frame_start': int, 'frame_end': int, 'max': float, 'min': float, 'eval_time': float,
              'use_eval_time': bool}
_CON_ENUMS = ('owner_space', 'target_space', 'mix_mode', 'transform_channel')
_FLOAT_FIELDS = ('influence', 'max', 'min', 'eval_time')
ACT_KEYS = ('name', 'slot', 'layer', 'use_fake_user', 'props', 'fcurves')
SLOT_KEYS = ('identifier', 'name', 'target_id_type')
FC_KEYS = ('data_path', 'index', 'group', 'extrapolation', 'keys')
COLL_KEYS = ('is_visible', 'visible_only_when_live', 'parent', 'bones')
KEY_ATTRS = ('interpolation', 'easing', 'type', 'back', 'amplitude', 'period', 'handle_left_type', 'handle_right_type')

# Test hook for the rollback acceptance (name of a fault point, or None).  Never set by the UI.
_FAULT = None


class ArkError(Exception):
    """A refusal.  ``problems`` is a list of (english, japanese) pairs; nothing was changed."""

    def __init__(self, problems):
        if isinstance(problems, tuple):
            problems = [problems]
        self.problems = list(problems)
        super().__init__('; '.join(p[0] for p in self.problems))


def _fault(name):
    if _FAULT == name:
        raise RuntimeError('injected fault: %s' % name)


def _p(en, ja):
    return (en, ja)


# ---------------------------------------------------------------------------- numbers
def _f32(v):
    return struct.unpack('<f', struct.pack('<f', float(v)))[0]


def _same_value(cur, want, as_float32):
    if isinstance(want, bool) or isinstance(cur, bool):
        return bool(cur) == bool(want) and type(want) is bool
    if as_float32:
        return float(cur) == _f32(want)
    return cur == want


def _clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else hi if v > hi else v


# ---------------------------------------------------------------------------- spec loading
def spec_path_resolved(path):
    raw = str(path or '').strip()
    if not raw:
        return ''
    try:
        raw = bpy.path.abspath(raw)
    except Exception:
        pass
    return os.path.normpath(raw)


def load_spec(path):
    """Read and strictly validate the spec JSON.  Returns (spec, sha256_upper)."""
    p = spec_path_resolved(path)
    if not p:
        raise ArkError(_p('Choose the rig spec JSON.', '正本の JSON を選んでください。'))
    if not os.path.isfile(p):
        raise ArkError(_p('The rig spec JSON was not found: %s' % p, '正本の JSON が見つかりません：%s' % p))
    if os.path.getsize(p) > SPEC_MAX_BYTES:
        raise ArkError(_p('The rig spec JSON is larger than 16 MiB.', '正本の JSON が 16 MiB を超えています。'))
    with open(p, 'rb') as fh:
        raw = fh.read()
    try:
        spec = json.loads(raw.decode('utf-8-sig'))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ArkError(_p('The rig spec is not valid UTF-8 JSON: %s' % exc, '正本が正しい UTF-8 の JSON ではありません：%s' % exc))
    validate_spec(spec)
    return spec, hashlib.sha256(raw).hexdigest().upper()


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))


def _type_ok(v, t):
    if t is float:
        return _is_num(v)
    if t is int:
        return isinstance(v, int) and not isinstance(v, bool)
    return isinstance(v, t)


def _parse_owner_path(data_path):
    """'pose.bones["B"].prop' -> (B, prop) or None."""
    if not data_path.startswith('pose.bones["'):
        return None
    rest = data_path[len('pose.bones["'):]
    end = rest.find('"]')
    if end <= 0 or not rest[end + 2:].startswith('.'):
        return None
    return rest[:end], rest[end + 3:]


def validate_spec(spec):
    """Strict schema check of every section these tools read.  Raises ArkError with all problems."""
    bad = []

    def err(en, ja):
        bad.append(_p(en, ja))

    if not isinstance(spec, dict):
        raise ArkError(_p('The rig spec must be a JSON object.', '正本は JSON のオブジェクトにしてください。'))
    if spec.get('format') != SPEC_FORMAT:
        err('Unknown spec format (expected %s).' % SPEC_FORMAT, '正本の形式が違います（%s のはず）。' % SPEC_FORMAT)
    if not _type_ok(spec.get('version'), int) or spec.get('version') < 1:
        err('The spec version must be a positive integer.', '正本の version は正の整数にしてください。')
    for key in ('rig',):
        if not isinstance(spec.get(key), str) or not spec.get(key):
            err('The spec needs a non-empty "%s" name.' % key, '正本に空でない「%s」の名前が要ります。' % key)
    if 'face' in spec and not isinstance(spec['face'], str):
        err('"face" must be a name.', '「face」は名前にしてください。')
    live = spec.get('live_property', LIVE_PROP_DEFAULT)
    if not isinstance(live, str) or not live:
        err('"live_property" must be a name.', '「live_property」は名前にしてください。')
    props = spec.get('rig_props')
    if not isinstance(props, dict) or not props:
        err('The spec needs "rig_props".', '正本に「rig_props」が要ります。')
    else:
        if live not in props:
            err('rig_props has no mode switch "%s".' % live, 'rig_props にモードの切り替え「%s」がありません。' % live)
        for n, d in props.items():
            if not isinstance(d, dict) or not _is_num(d.get('value')):
                err('rig_props["%s"] needs a numeric "value".' % n, 'rig_props["%s"] に数の「value」が要ります。' % n)
    colls = spec.get('bone_collections')
    if not isinstance(colls, dict) or not colls:
        err('The spec needs "bone_collections".', '正本に「bone_collections」が要ります。')
    else:
        for cn, d in colls.items():
            if not isinstance(d, dict):
                err('bone_collections["%s"] must be an object.' % cn, 'bone_collections["%s"] はオブジェクトにしてください。' % cn)
                continue
            unknown = sorted(set(d) - set(COLL_KEYS))
            if unknown:
                err('bone_collections["%s"] has unknown keys: %s' % (cn, unknown), 'bone_collections["%s"] に知らないキー：%s' % (cn, unknown))
            if not isinstance(d.get('is_visible'), bool) or not isinstance(d.get('bones'), list) \
                    or not all(isinstance(b, str) for b in d.get('bones') or []):
                err('bone_collections["%s"] needs is_visible and a bone list.' % cn, 'bone_collections["%s"] に is_visible と骨の一覧が要ります。' % cn)
            if 'visible_only_when_live' in d and not isinstance(d['visible_only_when_live'], bool):
                err('visible_only_when_live must be true or false.', 'visible_only_when_live は true か false にしてください。')
    acts = spec.get('actions')
    act_by = {}
    if not isinstance(acts, list) or not acts:
        err('The spec needs "actions".', '正本に「actions」が要ります。')
    else:
        for i, a in enumerate(acts):
            if not isinstance(a, dict):
                err('actions[%d] must be an object.' % i, 'actions[%d] はオブジェクトにしてください。' % i)
                continue
            if sorted(a) != sorted(ACT_KEYS):
                err('actions[%d] keys must be exactly %s.' % (i, list(ACT_KEYS)), 'actions[%d] のキーは %s だけにしてください。' % (i, list(ACT_KEYS)))
                continue
            name = a['name']
            if not isinstance(name, str) or not name:
                err('actions[%d] needs a name.' % i, 'actions[%d] に名前が要ります。' % i)
                continue
            if name in act_by:
                err('Action "%s" is declared twice.' % name, 'アクション「%s」が 2 回あります（あいまい）。' % name)
            act_by[name] = a
            s = a['slot']
            if not isinstance(s, dict) or sorted(s) != sorted(SLOT_KEYS) or not all(isinstance(s[k], str) and s[k] for k in SLOT_KEYS):
                err('Action "%s" slot must have exactly %s.' % (name, list(SLOT_KEYS)), 'アクション「%s」の slot は %s だけにしてください。' % (name, list(SLOT_KEYS)))
            if not isinstance(a['layer'], str) or not isinstance(a['use_fake_user'], bool) or not isinstance(a['props'], dict):
                err('Action "%s" layer / use_fake_user / props have wrong types.' % name, 'アクション「%s」の layer・use_fake_user・props の型が違います。' % name)
            elif not all(isinstance(v, (str, int, float)) and not isinstance(v, bool) for v in a['props'].values()):
                err('Action "%s" props must be strings or numbers.' % name, 'アクション「%s」の props は文字か数にしてください。' % name)
            fcs = a['fcurves']
            if not isinstance(fcs, list) or not fcs:
                err('Action "%s" needs F-curves.' % name, 'アクション「%s」に F カーブが要ります。' % name)
                continue
            seen = set()
            for f in fcs:
                if not isinstance(f, dict) or sorted(f) != sorted(FC_KEYS):
                    err('Action "%s" F-curve keys must be exactly %s.' % (name, list(FC_KEYS)), 'アクション「%s」の F カーブのキーは %s だけにしてください。' % (name, list(FC_KEYS)))
                    continue
                if not isinstance(f['data_path'], str) or not _type_ok(f['index'], int) or f['index'] < 0 \
                        or not (f['group'] is None or isinstance(f['group'], str)) or not isinstance(f['extrapolation'], str):
                    err('Action "%s" has an F-curve with wrong types.' % name, 'アクション「%s」に型の違う F カーブがあります。' % name)
                    continue
                if _parse_owner_path(f['data_path']) is None:
                    err('Action "%s" F-curve path is not a pose bone channel: %s' % (name, f['data_path']),
                        'アクション「%s」の F カーブが骨のチャンネルではありません：%s' % (name, f['data_path']))
                ident = (f['data_path'], f['index'])
                if ident in seen:
                    err('Action "%s" has the F-curve %s[%d] twice.' % (name, ident[0], ident[1]), 'アクション「%s」に同じ F カーブ %s[%d] が 2 つあります。' % (name, ident[0], ident[1]))
                seen.add(ident)
                keys = f['keys']
                if not isinstance(keys, list) or not keys or not all(
                        isinstance(k, list) and len(k) == 3 and _is_num(k[0]) and _is_num(k[1]) and isinstance(k[2], str) for k in keys):
                    err('Action "%s" keys must be [frame, value, interpolation].' % name, 'アクション「%s」のキーは [フレーム, 値, 補間] にしてください。' % name)
    cons = spec.get('action_constraints')
    total = 0
    if not isinstance(cons, dict) or not cons:
        err('The spec needs "action_constraints".', '正本に「action_constraints」が要ります。')
    else:
        for bone, lst in cons.items():
            if not isinstance(lst, list) or not lst:
                err('action_constraints["%s"] must be a non-empty list.' % bone, 'action_constraints["%s"] は空でない一覧にしてください。' % bone)
                continue
            names = set()
            for k, d in enumerate(lst):
                total += 1
                if not isinstance(d, dict) or sorted(d) != sorted(CON_KEYS):
                    extra = sorted(set(d) - set(CON_KEYS)) if isinstance(d, dict) else []
                    miss = sorted(set(CON_KEYS) - set(d)) if isinstance(d, dict) else list(CON_KEYS)
                    err('Constraint %d on "%s": unknown keys %s, missing keys %s.' % (k, bone, extra, miss),
                        '骨「%s」の %d 番目の拘束：知らないキー %s、足りないキー %s。' % (bone, k, extra, miss))
                    continue
                for key, t in _CON_TYPES.items():
                    if not _type_ok(d[key], t):
                        err('Constraint "%s" on "%s": %s has the wrong type.' % (d.get('name'), bone, key),
                            '骨「%s」の拘束「%s」：%s の型が違います。' % (bone, d.get('name'), key))
                if not (d['space_object'] is None or isinstance(d['space_object'], str)):
                    err('Constraint "%s": space_object must be a name or null.' % d['name'], '拘束「%s」：space_object は名前か null にしてください。' % d['name'])
                if d['index'] != k:
                    err('Constraint "%s" on "%s": index %r must equal its position %d.' % (d['name'], bone, d['index'], k),
                        '骨「%s」の拘束「%s」：index %r は並びの位置 %d と同じにしてください。' % (bone, d['name'], d['index'], k))
                if d['name'] in names:
                    err('Constraint "%s" is declared twice on "%s".' % (d['name'], bone), '骨「%s」に拘束「%s」が 2 回あります（あいまい）。' % (bone, d['name']))
                names.add(d['name'])
                a = act_by.get(d['action'])
                if a is None:
                    err('Constraint "%s" on "%s" uses Action "%s", which is not declared in actions.' % (d['name'], bone, d['action']),
                        '骨「%s」の拘束「%s」が、actions に無いアクション「%s」を指しています（対応の欠け）。' % (bone, d['name'], d['action']))
                elif isinstance(a.get('slot'), dict) and a['slot'].get('identifier') != d['action_slot']:
                    err('Constraint "%s" slot %s differs from Action "%s" slot.' % (d['name'], d['action_slot'], d['action']),
                        '拘束「%s」のスロット %s がアクション「%s」のスロットと違います。' % (d['name'], d['action_slot'], d['action']))
        if 'action_constraints_count' in spec and spec['action_constraints_count'] != total:
            err('action_constraints_count %r differs from the %d declared constraints.' % (spec['action_constraints_count'], total),
                'action_constraints_count %r が拘束の数 %d と違います。' % (spec['action_constraints_count'], total))
    drv = spec.get('drivers', [])
    if not isinstance(drv, list):
        err('"drivers" must be a list.', '「drivers」は一覧にしてください。')
    if bad:
        raise ArkError(bad)


# ---------------------------------------------------------------------------- safe expression
_FUNCS = {'min': min, 'max': max, 'abs': abs}


def _expr_check(expr):
    try:
        tree = ast.parse(expr, mode='eval')
    except SyntaxError as exc:
        raise ArkError(_p('Driver expression is not valid: %s' % expr, 'ドライバーの式が正しくありません：%s' % expr)) from exc
    for node in ast.walk(tree):
        if isinstance(node, (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Name, ast.Load, ast.Add, ast.Sub, ast.Mult,
                             ast.Div, ast.USub, ast.UAdd)):
            continue
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            continue
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS and not node.keywords:
            continue
        raise ArkError(_p('Unsupported driver expression (only + - * / min max abs): %s' % expr,
                          '扱えないドライバーの式です（+ - * / min max abs だけ）：%s' % expr))
    return tree


def _expr_value(tree, names):
    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant):
            return n.value
        if isinstance(n, ast.Name):
            return names[n.id]
        if isinstance(n, ast.UnaryOp):
            v = ev(n.operand)
            return -v if isinstance(n.op, ast.USub) else +v
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            return a / b
        if isinstance(n, ast.Call):
            return _FUNCS[n.func.id](*[ev(x) for x in n.args])
        raise ArkError(_p('Unsupported driver expression node.', '扱えない式の要素です。'))
    return float(ev(tree))


# ---------------------------------------------------------------------------- model from the spec
class Model:
    """Everything the three operations need, resolved from the spec and checked against the scene."""

    def __init__(self, spec, sha):
        self.spec = spec
        self.sha = sha
        self.live = spec.get('live_property', LIVE_PROP_DEFAULT)
        self.rig_name = spec['rig']
        self.face_name = spec.get('face')
        self.declared = {}          # (bone, name) -> spec entry
        self.order = []             # (bone, name) in spec order
        for bone, lst in spec['action_constraints'].items():
            for d in lst:
                self.declared[(bone, d['name'])] = d
                self.order.append((bone, d['name']))
        self.actions = {a['name']: a for a in spec['actions']}
        colls = spec['bone_collections']
        self.board_colls = [cn for cn, d in colls.items() if d.get('visible_only_when_live', False)]
        self.hand_colls = [cn for cn, d in colls.items() if not d.get('visible_only_when_live', False)]
        hand_bones = set(b for cn in self.hand_colls for b in colls[cn]['bones'])
        self.keep_live = set(k for k, d in self.declared.items() if d['subtarget'] in hand_bones)
        self.slider_bones = set(d['subtarget'] for d in self.declared.values()) | set(
            b for d in colls.values() for b in d['bones'])
        self.hand = self._hand_drivers(spec)

    def _hand_drivers(self, spec):
        """Drivers that read the mode switch (m) and one hand value (h): baked value = expression at m=1."""
        out = []
        seen = set()
        props = spec['rig_props']
        for s in spec.get('drivers', []):
            if not isinstance(s, dict):
                continue
            vars_ = s.get('variables') or []
            m_vars, h_vars = [], []
            for v in vars_:
                t = (v.get('targets') or [{}])[0] if isinstance(v, dict) else {}
                if v.get('type') == 'SINGLE_PROP' and t.get('id') == self.rig_name and t.get('id_type') == 'OBJECT':
                    dp = t.get('data_path') or ''
                    if dp.startswith('["') and dp.endswith('"]'):
                        pn = dp[2:-2]
                        if pn == self.live:
                            m_vars.append(v['name'])
                        elif pn in props:
                            h_vars.append((v['name'], pn))
            if not m_vars or not h_vars:
                continue
            if len(h_vars) != 1:
                raise ArkError(_p('Driver %s reads more than one hand value.' % s.get('path'), 'ドライバー %s が手の値を 2 つ以上読みます（あいまい）。' % s.get('path')))
            hname, prop = h_vars[0]
            if prop in seen:
                raise ArkError(_p('Hand value "%s" is read by two drivers.' % prop, '手の値「%s」を 2 つのドライバーが読みます（あいまい）。' % prop))
            seen.add(prop)
            if s.get('type') != 'SCRIPTED' or not isinstance(s.get('expression'), str):
                raise ArkError(_p('Hand driver %s must be a scripted simple expression.' % s.get('path'), '手の値のドライバー %s は単純式にしてください。' % s.get('path')))
            tree = _expr_check(s['expression'])
            reads = {}
            for v in vars_:
                t = v['targets'][0]
                if v['name'] in m_vars:
                    reads[v['name']] = ('const', 1.0)
                elif v['name'] == hname:
                    reads[v['name']] = ('path', '["%s"]' % prop, 0)
                elif v.get('type') == 'TRANSFORMS' and t.get('id') == self.rig_name and t.get('transform_space') == 'LOCAL_SPACE' \
                        and t.get('transform_type') in ('LOC_X', 'LOC_Y', 'LOC_Z') and t.get('bone_target'):
                    reads[v['name']] = ('path', 'pose.bones["%s"].location' % t['bone_target'],
                                        'XYZ'.index(t['transform_type'][-1]))
                else:
                    raise ArkError(_p('Hand driver %s has a variable that cannot be baked: %s' % (s.get('path'), v.get('name')),
                                      '手の値のドライバー %s に焼けない変数があります：%s' % (s.get('path'), v.get('name'))))
            names_in_expr = set(n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and not isinstance(n, ast.Call))
            names_in_expr -= set(_FUNCS)
            if not names_in_expr <= set(reads):
                raise ArkError(_p('Hand driver %s uses unknown names %s.' % (s.get('path'), sorted(names_in_expr - set(reads))),
                                  '手の値のドライバー %s に知らない名前 %s があります。' % (s.get('path'), sorted(names_in_expr - set(reads)))))
            out.append({'prop': prop, 'path': '["%s"]' % prop, 'tree': tree, 'reads': reads, 'driver': s.get('path')})
        return out


def _is_linked(idb):
    return idb is not None and (getattr(idb, 'library', None) is not None or getattr(idb, 'override_library', None) is not None)


def resolve_rig(spec, chosen=None):
    name = spec['rig']
    rig = chosen if chosen is not None else bpy.data.objects.get(name)
    if rig is None:
        raise ArkError(_p('The rig "%s" named in the spec is not in this file.' % name, '正本の rig「%s」がこのファイルにありません。' % name))
    if rig.name != name:
        raise ArkError(_p('Facial Rig "%s" differs from the spec rig "%s".' % (rig.name, name),
                          '表情リグ「%s」と正本の rig「%s」が違います。' % (rig.name, name)))
    if rig.type != 'ARMATURE':
        raise ArkError(_p('"%s" is not an armature.' % name, '「%s」はアーマチュアではありません。' % name))
    if _is_linked(rig) or _is_linked(rig.data):
        raise ArkError(_p('The rig is linked or overridden (read-only).', 'リグがリンクかオーバーライドです（読み取り専用）。'))
    return rig


def _enum_ok(struct_type, prop, value):
    try:
        return value in {e.identifier for e in struct_type.bl_rna.properties[prop].enum_items}
    except Exception:
        return False


def check_scene(model, rig, for_bake=False):
    """Scene-side strict checks shared by every operation.  Raises ArkError before anything changes."""
    bad = []
    spec = model.spec
    rig_data = rig.data
    for (bone, cname), d in model.declared.items():
        pb = rig.pose.bones.get(bone)
        if pb is None:
            bad.append(_p('Bone "%s" from the spec is not in the rig.' % bone, '正本の骨「%s」がリグにありません。' % bone))
            continue
        if rig.pose.bones.get(d['subtarget']) is None:
            bad.append(_p('Slider bone "%s" is not in the rig.' % d['subtarget'], 'スライダーの骨「%s」がリグにありません。' % d['subtarget']))
        if bpy.data.objects.get(d['target']) is None:
            bad.append(_p('Constraint target "%s" is not in this file.' % d['target'], '拘束の的「%s」がこのファイルにありません。' % d['target']))
        if d['space_object'] and bpy.data.objects.get(d['space_object']) is None:
            bad.append(_p('Space object "%s" is not in this file.' % d['space_object'], '空間のオブジェクト「%s」がありません。' % d['space_object']))
        for f in _CON_ENUMS:
            if not _enum_ok(bpy.types.ActionConstraint, f, d[f]):
                bad.append(_p('Constraint "%s": %s value %r is not valid.' % (cname, f, d[f]), '拘束「%s」：%s の値 %r は使えません。' % (cname, f, d[f])))
        c = pb.constraints.get(cname)
        if c is not None and c.type != 'ACTION':
            bad.append(_p('"%s" on "%s" is a %s constraint, not an Action constraint (collision).' % (cname, bone, c.type),
                          '骨「%s」の「%s」は %s の拘束で、アクション の拘束ではありません（衝突）。' % (bone, cname, c.type)))
        if c is not None and c.type == 'ACTION' and _is_linked(c.action):
            bad.append(_p('Constraint "%s" uses a linked Action.' % cname, '拘束「%s」がリンクのアクションを使っています。' % cname))
    # Actions: linked, shared with things outside the declared constraints, or of another structure.
    refs = {}
    for (bone, cname), d in model.declared.items():
        pb = rig.pose.bones.get(bone)
        c = pb.constraints.get(cname) if pb else None
        if c is not None and c.type == 'ACTION' and c.action is not None:
            refs[c.action.name] = refs.get(c.action.name, 0) + 1
    for name, a in model.actions.items():
        act = bpy.data.actions.get(name)
        if not _enum_ok(bpy.types.ActionSlot, 'target_id_type', a['slot']['target_id_type']):
            bad.append(_p('Action "%s": slot type %r is not valid.' % (name, a['slot']['target_id_type']), 'アクション「%s」：スロットの型 %r は使えません。' % (name, a['slot']['target_id_type'])))
        for f in a['fcurves']:
            if not _enum_ok(bpy.types.FCurve, 'extrapolation', f['extrapolation']) or not all(
                    _enum_ok(bpy.types.Keyframe, 'interpolation', k[2]) for k in f['keys']):
                bad.append(_p('Action "%s": extrapolation or interpolation value is not valid.' % name, 'アクション「%s」：外挿か補間の値が使えません。' % name))
                break
        if act is None:
            continue
        if act.library is not None or act.override_library is not None:
            bad.append(_p('Action "%s" is linked (read-only).' % name, 'アクション「%s」はリンク（読み取り専用）です。' % name))
            continue
        foreign = act.users - (1 if act.use_fake_user else 0) - refs.get(name, 0)
        if foreign > 0:
            bad.append(_p('Action "%s" is also used outside the declared constraints (%d users).' % (name, foreign),
                          'アクション「%s」を正本の拘束の外でも使っています（%d か所。共有）。' % (name, foreign)))
        if not _action_structure_ok(act, a):
            bad.append(_p('Action "%s" has another slot / layer layout; it is not the declared Action.' % name,
                          'アクション「%s」のスロットや層の形が違います。正本のアクションではありません（衝突）。' % name))
    if for_bake:
        if rig_data.users > 1:
            bad.append(_p('The armature data is shared by %d objects.' % rig_data.users, 'アーマチュアのデータを %d 個のオブジェクトが共有しています。' % rig_data.users))
        ad = rig.animation_data
        if ad is not None and ad.action is not None:
            act = ad.action
            if _is_linked(act):
                bad.append(_p('The rig Action is linked (read-only).', 'リグのアクションがリンク（読み取り専用）です。'))
            else:
                # Same count as the return's re-check, so a bake is never made that the return must refuse.
                users = _uses_beyond_owned(act, rig, True)
                if users:
                    bad.append(_p('The rig Action "%s" is shared with other data (%s).' % (act.name, _names(users)),
                                  'リグのアクション「%s」をほかのデータと共有しています（%s）。' % (act.name, _names(users))))
        if ad is not None and ad.use_tweak_mode:
            bad.append(_p('Leave NLA tweak mode first.', '先に NLA の編集モードを抜けてください。'))
        for cn in model.board_colls + model.hand_colls:
            if rig_data.collections_all.get(cn) is None:
                bad.append(_p('Bone collection "%s" is not in the rig.' % cn, '骨コレクション「%s」がリグにありません。' % cn))
        if model.live not in rig.keys():
            bad.append(_p('The rig has no "%s" property.' % model.live, 'リグにプロパティ「%s」がありません。' % model.live))
        for h in model.hand:
            if h['prop'] not in rig.keys():
                bad.append(_p('The rig has no hand value "%s".' % h['prop'], 'リグに手の値「%s」がありません。' % h['prop']))
            for r in h['reads'].values():
                if r[0] == 'path' and r[1].startswith('pose.bones["'):
                    bn = _parse_owner_path(r[1])[0]
                    if rig.pose.bones.get(bn) is None:
                        bad.append(_p('Driver bone "%s" is not in the rig.' % bn, 'ドライバーの骨「%s」がリグにありません。' % bn))
    if bad:
        raise ArkError(bad)


def _action_structure_ok(act, a):
    if len(act.slots) == 0 and len(act.layers) == 0:
        return True  # empty container: filled as declared
    if len(act.slots) != 1 or act.slots[0].identifier != a['slot']['identifier']:
        return False
    if len(act.layers) != 1 or len(act.layers[0].strips) != 1:
        return False
    return getattr(act.layers[0].strips[0], 'type', 'KEYFRAME') == 'KEYFRAME'


# ---------------------------------------------------------------------------- transaction journal
class _Txn:
    def __init__(self):
        self.undo = []
        self._fc_snapped = set()

    def set(self, obj, attr, value):
        old = getattr(obj, attr)
        if hasattr(old, '__len__') and not isinstance(old, str):
            old = tuple(old)
        setattr(obj, attr, value)
        self.undo.append(lambda o=obj, a=attr, v=old: setattr(o, a, v))

    def set_prop(self, idb, key, value):
        had = key in idb.keys()
        old = idb[key] if had else None
        if had and hasattr(old, 'to_list'):
            old = old.to_list()
        elif had and hasattr(old, 'to_dict'):
            old = old.to_dict()
        idb[key] = value

        def back(i=idb, k=key, h=had, v=old):
            if h:
                i[k] = v
            elif k in i.keys():
                del i[k]
        self.undo.append(back)

    def del_prop(self, idb, key):
        if key not in idb.keys():
            return
        old = idb[key]
        if hasattr(old, 'to_list'):
            old = old.to_list()
        elif hasattr(old, 'to_dict'):
            old = old.to_dict()
        del idb[key]
        self.undo.append(lambda i=idb, k=key, v=old: i.__setitem__(k, v))

    def snap_fcurve(self, bag, path, index):
        ident = (bag.as_pointer(), path, index)
        if ident in self._fc_snapped:
            return
        self._fc_snapped.add(ident)
        fc = bag.fcurves.find(path, index=index)
        if fc is None:
            def back(b=bag, p=path, i=index):
                f = b.fcurves.find(p, index=i)
                if f is not None:
                    b.fcurves.remove(f)
        else:
            snap = (fc.group.name if fc.group else '', fc.extrapolation, snap_keys(fc))

            def back(b=bag, p=path, i=index, s=snap):
                f = b.fcurves.find(p, index=i)
                if f is None:
                    f = b.fcurves.new(p, index=i, group_name=s[0]) if s[0] else b.fcurves.new(p, index=i)
                    f.extrapolation = s[1]
                write_keys_snapshot(f, s[2])
        self.undo.append(back)

    def snap_groups(self, bag):
        before = [g.name for g in bag.groups]

        def back(b=bag, names=before):
            for g in list(b.groups):
                if g.name not in names and len(g.channels) == 0:
                    b.groups.remove(g)
        self.undo.append(back)

    def created_action(self, act):
        self.undo.append(lambda a=act: bpy.data.actions.remove(a) if a.name in bpy.data.actions else None)

    def call(self, fn):
        self.undo.append(fn)

    def rollback(self):
        errors = []
        for fn in reversed(self.undo):
            try:
                fn()
            except Exception as exc:  # keep rolling back the rest
                errors.append(str(exc))
        self.undo = []
        return errors


def snap_keys(fc):
    out = []
    for k in fc.keyframe_points:
        out.append((tuple(k.co), tuple(k.handle_left), tuple(k.handle_right),
                    tuple(getattr(k, a) for a in KEY_ATTRS)))
    return out


def write_keys_snapshot(fc, snap):
    pts = fc.keyframe_points
    while len(pts):
        pts.remove(pts[len(pts) - 1], fast=True)
    pts.add(len(snap))
    for p, (co, hl, hr, attrs) in zip(pts, snap):
        p.co = co
        for a, v in zip(KEY_ATTRS[:6], attrs[:6]):
            setattr(p, a, v)
        p.handle_left_type = attrs[6]
        p.handle_right_type = attrs[7]
        p.handle_left = hl
        p.handle_right = hr
    fc.update()


# ---------------------------------------------------------------------------- shared helpers (ported)
def _channelbag(action, slot):
    from bpy_extras import anim_utils
    if action is None or slot is None:
        return None
    return anim_utils.action_get_channelbag_for_slot(action, slot)


def _rig_bag(rig):
    ad = rig.animation_data
    if ad is None or ad.action is None or ad.action_slot is None:
        return (ad.action if ad else None), None
    return ad.action, _channelbag(ad.action, ad.action_slot)


def _fc_find(bag, path, index):
    if bag is None:
        return None
    return bag.fcurves.find(path, index=index)


def _reader(rig, bag):
    """(path, index) -> value at a frame: the F-curve when it has keys, else the current value."""
    cache = {}

    def read(path, index, frame):
        key = (path, index)
        if key not in cache:
            fc = _fc_find(bag, path, index)
            if fc is not None and len(fc.keyframe_points):
                cache[key] = ('fc', fc)
            else:
                v = rig.path_resolve(path)
                try:
                    v = v[index]
                except TypeError:
                    pass
                cache[key] = ('const', float(v))
        kind, obj = cache[key]
        return obj.evaluate(frame) if kind == 'fc' else obj
    return read


def _declared_in_rig_order(rig, model):
    out = []
    for pb in rig.pose.bones:
        for c in pb.constraints:
            if c.type == 'ACTION' and (pb.name, c.name) in model.declared:
                out.append((pb, c))
    return out


def _slider_index(c):
    return {'LOCATION_X': 0, 'LOCATION_Y': 1, 'LOCATION_Z': 2}[c.transform_channel]


def _plan(rig, model):
    """Constraints to bake (enabled, declared, not kept live) and every channel of their owner bones."""
    bad = []
    present = set((pb.name, c.name) for pb, c in _declared_in_rig_order(rig, model))
    missing = [k for k in model.order if k not in present]
    if missing:
        bad.append(_p('%d declared constraints are missing (first: %s on %s). Run Check / Reapply first.' % (len(missing), missing[0][1], missing[0][0]),
                      '正本の拘束が %d 本足りません（最初：骨「%s」の「%s」）。先に「検査」と「当て直す」を使ってください。' % (len(missing), missing[0][0], missing[0][1])))
    per = {}
    used = []
    for pb, c in _declared_in_rig_order(rig, model):
        if (pb.name, c.name) in model.keep_live or not c.enabled:
            continue
        if c.influence != 1.0:
            bad.append(_p('"%s" on "%s" has influence %r; only 1.0 can be baked.' % (c.name, pb.name, c.influence),
                          '骨「%s」の「%s」の影響が %r です。1.0 の時だけ焼けます。' % (pb.name, c.name, c.influence)))
            continue
        if (not c.transform_channel.startswith('LOCATION_') or c.target_space != 'LOCAL' or c.owner_space != 'LOCAL'
                or c.mix_mode != 'BEFORE_SPLIT' or c.use_eval_time or c.use_bone_object_action or c.target != rig):
            bad.append(_p('"%s" on "%s" uses settings these tools cannot bake (needs local location slider, BEFORE_SPLIT, target = rig).' % (c.name, pb.name),
                          '骨「%s」の「%s」は焼けない設定です（ローカルの位置のスライダー・BEFORE_SPLIT・的が rig の時だけ）。' % (pb.name, c.name)))
            continue
        if rig.pose.bones.get(c.subtarget) is None:
            bad.append(_p('"%s" has no slider bone.' % c.name, '「%s」にスライダーの骨がありません。' % c.name))
            continue
        bag = _channelbag(c.action, c.action_slot)
        if bag is None:
            bad.append(_p('The Action of "%s" cannot be read (no slot).' % c.name, '「%s」のアクションが読めません（スロットなし）。' % c.name))
            continue
        head = 'pose.bones["%s"].' % pb.name
        for fc in bag.fcurves:
            if not fc.data_path.startswith(head):
                continue
            prop = fc.data_path[len(head):]
            if prop not in ('location', 'scale'):
                bad.append(_p('Unexpected channel %s in "%s".' % (fc.data_path, c.name), '「%s」に想定外のチャンネル %s があります。' % (c.name, fc.data_path)))
                continue
            per.setdefault((pb.name, prop, fc.array_index), []).append((c, fc))
        used.append((pb.name, c.name))
    if bad:
        raise ArkError(bad)
    drv = set()
    if rig.animation_data:
        drv = set((d.data_path, d.array_index) for d in rig.animation_data.drivers)
    for bn in sorted(set(k[0] for k in per)):
        pb = rig.pose.bones[bn]
        rm = pb.rotation_mode
        rprop, rn = (('rotation_quaternion', 4) if rm == 'QUATERNION' else
                     ('rotation_axis_angle', 4) if rm == 'AXIS_ANGLE' else ('rotation_euler', 3))
        for prop, n in (('location', 3), (rprop, rn), ('scale', 3)):
            for idx in range(n):
                if (bn, prop, idx) in per:
                    continue
                if ('pose.bones["%s"].%s' % (bn, prop), idx) in drv:
                    continue
                per[(bn, prop, idx)] = []
    plan = []
    for (bn, prop, idx), lst in sorted(per.items()):
        kind = prop if prop in ('location', 'scale') else 'rotation'
        plan.append((bn, 'pose.bones["%s"].%s' % (bn, prop), idx, kind, lst))
    return plan, used


def _keyed_range(bag, model):
    if bag is None:
        return None
    lo = hi = None
    hand_paths = set(h['path'] for h in model.hand)
    for fc in bag.fcurves:
        own = _parse_owner_path(fc.data_path)
        if not ((own is not None and own[0] in model.slider_bones) or fc.data_path in hand_paths):
            continue
        for kp in fc.keyframe_points:
            x = kp.co.x
            lo = x if lo is None or x < lo else lo
            hi = x if hi is None or x > hi else hi
    if lo is None:
        return None
    return [int(math.floor(lo + 1e-6)), int(math.ceil(hi - 1e-6))]


def _slider_frac(c, read, frame):
    v = read('pose.bones["%s"].location' % c.subtarget, _slider_index(c), frame)
    span = (c.max - c.min) or 1e-9
    s = _clamp((v - c.min) / span)
    return c.frame_start + s * (c.frame_end - c.frame_start)


def _hand_values(model, read, frame):
    out = {}
    for h in model.hand:
        names = {}
        for vn, r in h['reads'].items():
            names[vn] = r[1] if r[0] == 'const' else read(r[1], r[2], frame)
        out[h['prop']] = _expr_value(h['tree'], names)
    return out


def _write_keys(txn, bag, path, index, frames, values, group):
    txn.snap_fcurve(bag, path, index)
    fc = bag.fcurves.find(path, index=index)
    if fc is None:
        fc = bag.fcurves.new(path, index=index, group_name=group)
    f0, f1 = frames[0], frames[-1]
    pts = fc.keyframe_points
    i = len(pts) - 1
    while i >= 0:
        if f0 - 1e-4 <= pts[i].co.x <= f1 + 1e-4:
            pts.remove(pts[i], fast=False)
        i -= 1
    n0 = len(pts)
    pts.add(len(frames))
    for k, (f, v) in enumerate(zip(frames, values)):
        p = pts[n0 + k]
        p.co = (f, v)
        p.interpolation = 'LINEAR'
        p.handle_left_type = p.handle_right_type = 'AUTO_CLAMPED'
    fc.update()
    return fc


def _copy_key(k, p):
    p.co = k.co
    p.interpolation = k.interpolation
    p.easing = k.easing
    p.type = k.type
    p.back = k.back
    p.amplitude = k.amplitude
    p.period = k.period
    p.handle_left_type = k.handle_left_type
    p.handle_right_type = k.handle_right_type
    p.handle_left = k.handle_left
    p.handle_right = k.handle_right


def _remove_keys(txn, bag, path, index, f0, f1, drop_empty=True):
    fc = _fc_find(bag, path, index)
    if fc is None:
        return 0
    txn.snap_fcurve(bag, path, index)
    n = 0
    pts = fc.keyframe_points
    i = len(pts) - 1
    while i >= 0:
        if f0 - 1e-4 <= pts[i].co.x <= f1 + 1e-4:
            pts.remove(pts[i], fast=False)
            n += 1
        i -= 1
    if len(pts) == 0:
        if drop_empty:
            bag.fcurves.remove(fc)
    else:
        fc.update()
    return n


def _capture(objs):
    import numpy as np
    dg = bpy.context.evaluated_depsgraph_get()
    out = {}
    for ob in objs:
        oe = ob.evaluated_get(dg)
        me = oe.to_mesh()
        a = np.empty(len(me.vertices) * 3)
        me.vertices.foreach_get('co', a)
        mw = np.array(oe.matrix_world)
        a = a.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3]
        oe.to_mesh_clear()
        out[ob.name] = a
    return out


def _max_diff(a, b):
    import numpy as np
    m = 0.0
    for k in a:
        if k in b and a[k].shape == b[k].shape:
            m = max(m, float(np.abs(a[k] - b[k]).max()) if a[k].size else 0.0)
        else:
            return float('inf')
    return m


def _refresh(rig):
    rig.update_tag()
    bpy.context.view_layer.update()


def _static_values(rig, channels):
    """Stored (not evaluated) values of the channels an operation writes keys to: pose-bone transforms and
    hand values.  Any depsgraph evaluation while keys are on those channels writes the keyed value into them
    (keying_set_remove and view_layer.update do), so a rollback puts these back after its last evaluation."""
    out = []
    for path, idx in channels:
        if path.startswith('["') and path.endswith('"]'):
            k = path[2:-2]
            if k in rig.keys():
                v = rig[k]
                out.append((path, idx, True, v.to_list() if hasattr(v, 'to_list') else v))
            else:
                out.append((path, idx, False, None))
            continue
        own = _parse_owner_path(path)
        pb = rig.pose.bones.get(own[0]) if own else None
        if pb is not None and hasattr(pb, own[1]):
            out.append((path, idx, True, getattr(pb, own[1])[idx]))
    return out


def _static_restore(rig, saved):
    for path, idx, had, v in saved:
        if path.startswith('["'):
            k = path[2:-2]
            if not had:
                if k in rig.keys():
                    del rig[k]
            else:
                cur = rig[k] if k in rig.keys() else None
                if cur is None or (cur.to_list() if hasattr(cur, 'to_list') else cur) != v:
                    rig[k] = v
            continue
        own = _parse_owner_path(path)
        pb = rig.pose.bones.get(own[0]) if own else None
        if pb is not None:
            vec = getattr(pb, own[1])
            if vec[idx] != v:
                vec[idx] = v


def _keying_set_find(scene):
    for k in scene.keying_sets:
        if k.bl_label == KEYING_SET_NAME:
            return k
    return None


def _keying_set_paths(ks):
    return [[p.id.name if p.id else None, p.data_path, p.array_index, p.group_method, p.group] for p in ks.paths]


# Options a path keeps that the name-only record does not hold (a re-added path gets them all off).
KEYING_PATH_FLAGS = ('use_entire_array', 'use_insertkey_override_needed', 'use_insertkey_override_visual',
                     'use_insertkey_needed', 'use_insertkey_visual')


def _keying_path_loss(p, rig):
    """(english, japanese) when the record [object name, path, index, group method, group] could not put this
    existing path back exactly; None when it can.  Only paths on the Facial Rig itself are kept: the record
    holds a name, and a name can later point at another object (renamed or replaced), so any other target
    is refused before the bake instead of being restored by name."""
    tid = p.id
    if tid is None:
        return ('"%s" has no target ID' % p.data_path, '「%s」に対象の ID がありません' % p.data_path)
    if not isinstance(tid, bpy.types.Object) or p.id_type != 'OBJECT':
        return ('%s "%s" (%s)' % (type(tid).__name__, tid.name, p.data_path),
                '%s「%s」（%s）' % (type(tid).__name__, tid.name, p.data_path))
    if tid.as_pointer() != rig.as_pointer():
        return ('Object "%s" (%s) is not the Facial Rig' % (tid.name, p.data_path),
                'オブジェクト「%s」（%s）は表情リグではありません' % (tid.name, p.data_path))
    flags = [f for f in KEYING_PATH_FLAGS if getattr(p, f)]
    if flags:
        return ('Object "%s" (%s) uses %s' % (tid.name, p.data_path, ', '.join(flags)),
                'オブジェクト「%s」（%s）が %s を使っています' % (tid.name, p.data_path, ', '.join(flags)))
    return None


def _keying_set_bake_check(scene, rig):
    """Fail closed before the bake changes anything: an existing keying set with this tool's label must only hold
    paths on the Facial Rig that the return can put back exactly.  Nothing is dropped, rebound or guessed."""
    ks = _keying_set_find(scene)
    if ks is None:
        return
    lost = [x for x in (_keying_path_loss(p, rig) for p in ks.paths) if x]
    if lost:
        raise ArkError(_p('The keying set "%s" already has paths the return could not put back exactly: %s. '
                          'Only paths on the Facial Rig itself can stay in it. '
                          'Move them to another keying set or remove them first. Nothing was changed.'
                          % (KEYING_SET_NAME, '; '.join(x[0] for x in lost)),
                          'キーイングセット「%s」に、戻す時にそのまま戻せない道があります：%s。'
                          '残せるのは表情リグそのものの道だけです。'
                          '先に別のキーイングセットへ移すか消してください。何も変えていません。'
                          % (KEYING_SET_NAME, '、'.join(x[1] for x in lost))))


def _keying_record_foreign(paths, rig):
    """Recorded paths that do not name the Facial Rig (null, another object, or a Material name from an older
    record).  A name cannot prove the object is still the one the bake saw, so these are never put back."""
    return [str(e[0]) for e in paths if e[0] != rig.name]


def _keying_set_set_paths(ks, rig, paths, active=None):
    # Every target is resolved before anything is removed: only the rig's own name resolves, and it resolves
    # to this rig object (never to another object found by that name).  Anything else leaves the keying set as it is.
    targets = []
    for idname, path, idx, method, group in paths:
        target = rig if idname == rig.name else None
        if target is None:
            raise ArkError(_p('The keying set "%s" path target "%s" is missing; the keying set was left unchanged.' % (KEYING_SET_NAME, idname),
                              'キーイングセット「%s」の道の対象「%s」がありません。キーイングセットは変えていません。' % (KEYING_SET_NAME, idname)))
        targets.append((target, path, idx, method, group))
    while len(ks.paths):
        ks.paths.remove(ks.paths[0])
    for target, path, idx, method, group in targets:
        ks.paths.add(target, path, index=idx, group_method=method, group_name=group)
    if active is not None and 0 <= active < len(ks.paths):
        ks.paths.active_index = active


def _keying_set_remove(scene, ks):
    keep = scene.keying_sets.active_index
    pos = list(scene.keying_sets).index(ks)
    scene.keying_sets.active_index = pos
    with bpy.context.temp_override(scene=scene):
        bpy.ops.anim.keying_set_remove()
    if keep > pos:
        keep -= 1
    if 0 <= keep < len(scene.keying_sets):
        scene.keying_sets.active_index = keep


def ark_mode(rig, live=LIVE_PROP_DEFAULT):
    """'LIVE' (expression mode), 'BAKED' (hand-key mode) or 'UNKNOWN'."""
    try:
        if live not in rig.keys():
            return 'UNKNOWN'
        return 'LIVE' if int(rig[live]) != 0 else 'BAKED'
    except Exception:
        return 'UNKNOWN'


def owned_record(rig):
    ad = rig.animation_data
    act = ad.action if ad else None
    if act is None or RECORD_KEY not in act.keys():
        return None
    try:
        rec = json.loads(str(act[RECORD_KEY]))
    except ValueError:
        return None
    return rec if rec.get('schema') == RECORD_SCHEMA else None


# ---------------------------------------------------------------------------- 1. bake
def bake(context, model, rig, frame_start=None, frame_end=None, allow_partial=False, verify=True, verify_every=10):
    sc = context.scene
    check_scene(model, rig, for_bake=True)
    _keying_set_bake_check(sc, rig)
    live_now = rig.get(model.live)
    if live_now is not None and int(live_now) == 0:
        raise ArkError(_p('Already in hand-key mode (%s = 0). Return first.' % model.live,
                          '既に手付けモード（%s＝0）です。先に表情モードへ戻してください。' % model.live))
    ad0 = rig.animation_data
    if ad0 is not None and ad0.action is not None and (RECORD_KEY in ad0.action.keys() or any(k in ad0.action.keys() for k in FOREIGN_RECORD_KEYS)):
        raise ArkError(_p('The rig Action already carries bake records. Return them with the tool that made them.',
                          'リグのアクションに焼いた記録が既にあります。作った道具で戻してください。'))
    plan, used = _plan(rig, model)
    _a0, b0 = _rig_bag(rig)
    keyed = _keyed_range(b0, model)
    scene_rng = [int(sc.frame_start), int(sc.frame_end)]
    if frame_start is None and frame_end is None:
        f0, f1 = scene_rng
        if keyed:
            f0, f1 = min(f0, keyed[0]), max(f1, keyed[1])
        range_source = 'scene+keys'
    else:
        f0 = int(scene_rng[0] if frame_start is None else frame_start)
        f1 = int(scene_rng[1] if frame_end is None else frame_end)
        range_source = 'explicit'
        if f1 < f0:
            raise ArkError(_p('The end frame is before the start frame.', '終わりのフレームが始まりより前です。'))
        if keyed and (keyed[0] < f0 or keyed[1] > f1) and not allow_partial:
            raise ArkError(_p('Slider keys (%d to %d) are outside the bake range (%d to %d); expressions would vanish there. Widen the range, choose Scene + Keys, or turn on Allow Partial Bake.' % (keyed[0], keyed[1], f0, f1),
                              'スライダーのキー（%d〜%d）が焼く範囲（%d〜%d）の外にあります。焼くと範囲の外で表情が消えます。範囲を広げるか、「シーン＋キー」にするか、「一部だけ焼くのを許す」を入れてください。' % (keyed[0], keyed[1], f0, f1)))
    if f1 - f0 + 1 > MAX_BAKE_FRAMES:
        raise ArkError(_p('The bake range is longer than %d frames.' % MAX_BAKE_FRAMES, '焼く範囲が %d コマを超えています。' % MAX_BAKE_FRAMES))
    frames = list(range(f0, f1 + 1))
    report = {'frames': [f0, f1], 'scene_range': scene_rng, 'keyed_range': keyed, 'range_source': range_source,
              'range_extended_beyond_scene': f0 < scene_rng[0] or f1 > scene_rng[1], 'spec_sha256': model.sha}
    txn = _Txn()
    frame_now = sc.frame_current
    nla_state = []
    wm = context.window_manager
    # Stored values of every channel the bake keys, taken before anything changes.  On failure they are put
    # back as the last rollback step and once more after the frame is restored below, because evaluations
    # inside the rollback (removing the keying set it made runs one) write the baked keys into them.
    statics = _static_values(rig, [(path, idx) for _bn, path, idx, _kind, _lst in plan]
                             + [(h['path'], 0) for h in model.hand])
    failed = False
    txn.call(lambda r=rig, s=statics: _static_restore(r, s))
    try:
        # NLA muted while measuring (restored in finally)
        if rig.animation_data:
            for t in rig.animation_data.nla_tracks:
                nla_state.append((t.name, t.mute))
                t.mute = True
        # 1. Action, slot and the backup copy
        ad = rig.animation_data
        created_animdata = ad is None
        if ad is None:
            ad = rig.animation_data_create()
            txn.call(lambda r=rig: r.animation_data_clear() if r.animation_data and not r.animation_data.drivers and r.animation_data.action is None and not r.animation_data.nla_tracks else None)
        created_action = False
        created_slot = False
        if ad.action is None:
            act = bpy.data.actions.new(rig.name + '_action')
            txn.created_action(act)
            txn.set(ad, 'action', act)
            created_action = True
        act = ad.action
        if ad.action_slot is None:
            slot = act.slots.new('OBJECT', rig.name)
            txn.call(lambda a=act, s=slot: a.slots.remove(s) if s in list(a.slots) else None)
            txn.set(ad, 'action_slot', slot)
            created_slot = True
        from bpy_extras import anim_utils
        had_bag = anim_utils.action_get_channelbag_for_slot(act, ad.action_slot) is not None
        bag = anim_utils.action_ensure_channelbag_for_slot(act, ad.action_slot)
        txn.snap_groups(bag)
        n = 1
        while bpy.data.actions.get('%s_prebake_%03d' % (act.name, n)):
            n += 1
        backup = act.copy()
        txn.created_action(backup)
        backup.name = '%s_prebake_%03d' % (act.name, n)
        backup.use_fake_user = True
        for k in (RECORD_KEY,):
            if k in backup.keys():
                del backup[k]
        tid = uuid.uuid4().hex
        backup[BACKUP_KEY] = tid
        report['backup'] = backup.name
        # verification shapes (before)
        objs = []
        if verify and model.face_name and bpy.data.objects.get(model.face_name) is not None \
                and bpy.data.objects[model.face_name].type == 'MESH':
            objs = [bpy.data.objects[model.face_name]]
        check_frames = frames[::max(1, int(verify_every))] if objs else []
        if objs and frames[-1] not in check_frames:
            check_frames.append(frames[-1])
        before = {}
        for f in check_frames:
            sc.frame_set(f)
            before[f] = _capture(objs)
        # 2. compute
        read = _reader(rig, bag)
        values = {}
        try:
            wm.progress_begin(0, len(frames))
        except Exception:
            pass
        for i, f in enumerate(frames):
            for bn, path, idx, kind, lst in plan:
                base = read(path, idx, f)
                if kind == 'location':
                    v = base + sum(fc.evaluate(_slider_frac(c, read, f)) for c, fc in lst)
                elif kind == 'scale':
                    v = base
                    for c, fc in lst:
                        v *= fc.evaluate(_slider_frac(c, read, f))
                else:
                    v = base
                values.setdefault((bn, path, idx), []).append(v)
            for p, v in _hand_values(model, read, f).items():
                values.setdefault((None, '["%s"]' % p, 0), []).append(v)
            try:
                wm.progress_update(i)
            except Exception:
                pass
        # 3. write keys (remember values of channels that had no keys)
        extra = [[path, idx] for bn, path, idx, kind, lst in plan if not lst]
        static = {}
        for (bn, path, idx) in values:
            fc0 = _fc_find(bag, path, idx)
            if fc0 is None or len(fc0.keyframe_points) == 0:
                v = read(path, idx, frames[0])
                if path.startswith('["') and path.endswith('"]') and isinstance(rig.get(path[2:-2]), (int, float)):
                    v = float(rig[path[2:-2]])
                static['%s|%d' % (path, idx)] = v
        written = []
        for (bn, path, idx), vals in values.items():
            _write_keys(txn, bag, path, idx, frames, vals, bn or HAND_GROUP)
            written.append([path, idx])
        _fault('bake.after_keys')
        # 4. switch to hand-key mode (only what this bake changes is recorded)
        disabled = []
        for pb, c in _declared_in_rig_order(rig, model):
            if (pb.name, c.name) in used and c.enabled:
                txn.set(c, 'enabled', False)
                # name + identity (Action, slider bone): the return re-enables only this constraint
                disabled.append([pb.name, c.name, c.action.name if c.action else None, c.subtarget])
        live_prev = rig.get(model.live)
        txn.set_prop(rig, model.live, 0)
        colls_prev = {}
        for cn in model.board_colls:
            col = rig.data.collections_all[cn]
            colls_prev[cn] = bool(col.is_visible)
            txn.set(col, 'is_visible', False)
        for cn in model.hand_colls:
            col = rig.data.collections_all[cn]
            colls_prev[cn] = bool(col.is_visible)
            txn.set(col, 'is_visible', True)
        ks = _keying_set_find(sc)
        ks_rec = {'created': ks is None, 'prev_paths': _keying_set_paths(ks) if ks is not None else None,
                  'active_prev': int(sc.keying_sets.active_index)}
        if ks is not None:
            ks_rec['prev_path_active'] = int(ks.paths.active_index)
        if ks is None:
            act_prev = int(sc.keying_sets.active_index)
            ks = sc.keying_sets.new(idname=KEYING_SET_IDNAME, name=KEYING_SET_NAME)
            txn.call(lambda s=sc, a_=act_prev: (_keying_set_remove(s, _keying_set_find(s)) if _keying_set_find(s) is not None else None,
                                               setattr(s.keying_sets, 'active_index', a_) if 0 <= a_ < len(s.keying_sets) else None))
        else:
            prev = ks_rec['prev_paths']
            txn.call(lambda s=sc, r=rig, pp=prev, pa=ks_rec['prev_path_active']:
                     _keying_set_set_paths(_keying_set_find(s), r, pp, pa) if _keying_set_find(s) is not None else None)
        _keying_set_set_paths(ks, rig, [[rig.name, p, i, 'NAMED', KEYING_SET_GROUP] for p, i in written])
        rec = {'schema': RECORD_SCHEMA, 'txn': tid, 'rig': rig.name, 'spec_sha256': model.sha,
               'slot': ad.action_slot.identifier, 'slot_handle': int(ad.action_slot.handle), 'range': [f0, f1], 'channels': written, 'extra': extra,
               'static': static, 'backup': backup.name, 'created_action': created_action, 'created_slot': created_slot,
               'created_animdata': created_animdata,
               'had_channelbag': had_bag, 'disabled': disabled, 'live': model.live,
               'live_prev': live_prev if isinstance(live_prev, (int, float)) else None,
               'collections_prev': colls_prev, 'keying_set': ks_rec,
               'scene': {'name': sc.name, 'ptr': int(sc.as_pointer())},
               'hand_paths': [h['path'] for h in model.hand]}
        txn.set_prop(act, RECORD_KEY, json.dumps(rec, ensure_ascii=False))
        _refresh(rig)
        report.update(channels=len(written), extra_channels=len(extra), constraints_disabled=len(disabled),
                      keying_set=KEYING_SET_NAME)
        # 5. self check (same shapes before and after)
        if check_frames:
            md = 0.0
            for f in check_frames:
                sc.frame_set(f)
                md = max(md, _max_diff(before[f], _capture(objs)))
            report['verify_max_diff_mm'] = md * 1000.0
            report['verify_frames'] = check_frames
            report['verify_pass'] = md * 1000.0 <= 0.01
        report['ok'] = True
    except BaseException:
        failed = True
        errs = txn.rollback()
        if errs:
            report['rollback_errors'] = errs
        raise
    finally:
        try:
            wm.progress_end()
        except Exception:
            pass
        ad = rig.animation_data
        if ad:
            for name, m in nla_state:
                t = ad.nla_tracks.get(name)
                if t:
                    t.mute = m
        sc.frame_set(frame_now)
        if failed:
            try:
                _static_restore(rig, statics)
            except Exception as exc:  # the original failure is still the one reported
                report.setdefault('rollback_errors', []).append(str(exc))
    return report


# ---------------------------------------------------------------------------- ownership re-check
def _foreign_uses(idb, allowed_ptrs, expected, named=()):
    """Uses of `idb` beyond the `expected` owned ones.  The fake user is bookkeeping, not a user.
    `named` are uses already found by name (see _rig_self_refs).  Returns a list of readable user
    names ('' entries for counted uses that nothing names); empty when only the owned uses remain."""
    out = []
    try:
        umap = bpy.data.user_map(subset=[idb])
    except Exception:
        umap = {}
    ptr = idb.as_pointer()
    for key, users in umap.items():
        if key.as_pointer() != ptr:
            continue
        for u in sorted(users, key=lambda x: (type(x).__name__, x.name)):
            if u.as_pointer() not in allowed_ptrs:
                out.append('%s "%s"' % (type(u).__name__, u.name))
    for n in named:
        if n not in out:
            out.append(n)
    extra = idb.users - (1 if getattr(idb, 'use_fake_user', False) else 0) - expected
    if extra > len(out):
        out.extend([''] * (extra - len(out)))
    return out


def _strips_all(strips):
    for s in strips:
        yield s
        yield from _strips_all(s.strips)


def _idprop_refs(owner, idb, label, out, depth=0):
    """ID properties (also nested in groups and lists) of `owner` that point at `idb`."""
    if depth > 8:
        return
    try:
        items = [(k, owner[k]) for k in owner.keys()]
    except Exception:
        return
    for k, v in items:
        _idprop_value(v, idb, '%s["%s"]' % (label, k), out, depth)


def _idprop_value(v, idb, label, out, depth):
    if isinstance(v, bpy.types.ID):
        if v == idb:
            out.append('ID property %s' % label)
    elif isinstance(v, (list, tuple)):
        for i, x in enumerate(v):
            _idprop_value(x, idb, '%s[%d]' % (label, i), out, depth + 1)
    elif type(v).__name__ == 'IDPropertyGroup':
        _idprop_refs(v, idb, label, out, depth + 1)


def _rig_self_refs(rig, idb):
    """Every use of `idb` held by the rig itself (the object and its armature data) other than the
    rig's active Action: NLA strips, the NLA tweak storage, Action constraints (object and pose bones),
    driver variable targets (object and armature data) and ID properties (object, pose bones, armature,
    bones).  The user map names the rig itself for these, so it cannot tell them from the owned use, and
    driver targets are not counted in `users` at all; each route is therefore looked at here by name."""
    out = []
    for owner, lab in ((rig, ''), (rig.data, 'armature ')):
        ad = getattr(owner, 'animation_data', None)
        if ad is None:
            continue
        if owner is not rig and ad.action == idb:
            out.append('%sAction' % lab)
        if ad.action_tweak_storage == idb:
            out.append('%sNLA tweak storage' % lab)
        for t in ad.nla_tracks:
            for s in _strips_all(t.strips):
                if s.action == idb:
                    out.append('%sNLA "%s" / "%s"' % (lab, t.name, s.name))
        for fc in ad.drivers:
            for v in fc.driver.variables:
                for tg in v.targets:
                    if tg.id == idb:
                        out.append('%sdriver "%s"[%d] / "%s"' % (lab, fc.data_path, fc.array_index, v.name))
    cons = [(None, c) for c in rig.constraints] + [(pb.name, c) for pb in rig.pose.bones for c in pb.constraints]
    for bone, c in cons:
        if c.type == 'ACTION' and c.action == idb:
            out.append('constraint "%s"%s' % (c.name, (' (%s)' % bone) if bone else ''))
    _idprop_refs(rig, idb, 'object', out)
    for pb in rig.pose.bones:
        _idprop_refs(pb, idb, 'pose bone "%s"' % pb.name, out)
    _idprop_refs(rig.data, idb, 'armature', out)
    for b in rig.data.bones:
        _idprop_refs(b, idb, 'bone "%s"' % b.name, out)
    return out


def _uses_beyond_owned(idb, rig, rig_action):
    """The one place that counts uses of an Action the bake owns or touches.
    rig_action=True: `idb` is the rig's active Action, and that single use is the owned one.
    rig_action=False: `idb` is the backup, which nothing may use (the fake user aside).
    Returns readable names of every other use; empty means owned only."""
    if rig_action:
        return _foreign_uses(idb, {rig.as_pointer()}, 1, _rig_self_refs(rig, idb))
    return _foreign_uses(idb, set(), 0, _rig_self_refs(rig, idb))


def _action_only_owned_content(act, slot):
    """True when the Action holds nothing but the rig slot (no slot or layer added since)."""
    return slot is not None and len(act.slots) == 1 and act.slots[0].handle == slot.handle and len(act.layers) <= 1


def _disabled_entry_matches(c, entry):
    """A record entry is [bone, name] (older) or [bone, name, action, slider bone]."""
    if len(entry) < 4:
        return True
    return (c.action.name if c.action else None) == entry[2] and c.subtarget == entry[3]


def _names(lst):
    named = [x for x in lst if x]
    unnamed = len(lst) - len(named)
    txt = ', '.join(named)
    if unnamed:
        txt = (txt + ', ' if txt else '') + '+%d' % unnamed
    return txt


def _scene_holds_bake(s, rig, rec):
    """True when scene `s` still has this tool's keying set holding exactly the paths the bake wrote on this rig."""
    ks = _keying_set_find(s)
    if ks is None:
        return False
    if any(p.id is None or p.id.as_pointer() != rig.as_pointer() for p in ks.paths):
        return False
    want = sorted((rig.name, p, int(i), 'NAMED', KEYING_SET_GROUP) for p, i in rec.get('channels', []))
    return sorted(tuple(x) for x in _keying_set_paths(ks)) == want


def _baked_scene(rig, rec):
    """The scene the bake was made in, or None when it cannot be told apart safely.
    The candidate is found by the recorded pointer first (same session; survives a rename), then, when no scene is at
    that pointer (the file was saved and opened again, or the scene was deleted), by the recorded name.  Records
    without a scene (older candidates) only accept a file with a single scene.  In every case the candidate must still
    hold the bake's keying set with exactly the baked paths on this rig: a pointer freed by a deleted scene can be
    reused by a new scene (measured), and a new scene can take the old name; neither holds that keying set.
    Anything else is None and the return refuses."""
    info = rec.get('scene')
    scenes = list(bpy.data.scenes)
    if not isinstance(info, dict):
        s = scenes[0] if len(scenes) == 1 else None
    else:
        name, ptr = info.get('name'), info.get('ptr')
        at_ptr = [x for x in scenes if ptr is not None and x.as_pointer() == int(ptr)]
        if at_ptr:
            s = at_ptr[0]
        else:
            s = bpy.data.scenes.get(name) if isinstance(name, str) else None
    return s if (s is not None and _scene_holds_bake(s, rig, rec)) else None


def _return_scene_check(sc, rig, rec):
    """Return works only in the scene the bake was made in: the keying set and its active entry it restores live there."""
    baked = _baked_scene(rig, rec)
    rec_name = (rec.get('scene') or {}).get('name') if isinstance(rec.get('scene'), dict) else None
    if baked is None:
        raise ArkError(_p('The scene the bake was made in ("%s") is gone, or its keying set "%s" no longer holds the baked paths, '
                          'so it cannot be told apart safely. Nothing was changed.'
                          % (rec_name if rec_name else '?', KEYING_SET_NAME),
                          '焼いたシーン（「%s」）が無いか、そのキーイングセット「%s」が焼いた道のままではないので、安全に見分けられません。何も変えていません。'
                          % (rec_name if rec_name else '?', KEYING_SET_NAME)))
    if baked.as_pointer() != sc.as_pointer():
        raise ArkError(_p('This rig was baked in the scene "%s". Switch to that scene and return there. Nothing was changed.' % baked.name,
                          'このリグはシーン「%s」で焼いています。そのシーンへ切り替えて戻してください。何も変えていません。' % baked.name))
    return baked


def _return_ownership_check(sc, rig, ad, act, pre, rec):
    """Fail closed before the return changes anything when the data the bake owns is now used,
    shared or replaced by something else.  Nothing is cloned, rebound, unlinked or removed."""
    baked = _return_scene_check(sc, rig, rec)
    bad = []
    if 'slot_handle' in rec and int(ad.action_slot.handle) != int(rec['slot_handle']):
        bad.append(_p('The rig Action slot was replaced after the bake.', '焼いた後にリグのアクションのスロットが別の物に替わっています。'))
    if not _action_only_owned_content(act, ad.action_slot) and rec.get('created_action'):
        bad.append(_p('The rig Action "%s" made by the bake now has other slots or layers.' % act.name,
                      '焼きが作ったリグのアクション「%s」に、別のスロットか層が増えています。' % act.name))
    users = _uses_beyond_owned(act, rig, True)
    if users:
        bad.append(_p('The rig Action "%s" is now also used elsewhere (%s). Nothing was changed.' % (act.name, _names(users)),
                      'リグのアクション「%s」を、焼いた後にほかでも使っています（%s）。何も変えていません。' % (act.name, _names(users))))
    users = _uses_beyond_owned(pre, rig, False)
    if users:
        bad.append(_p('The backup Action "%s" is now used (%s). Nothing was changed.' % (pre.name, _names(users)),
                      '控えのアクション「%s」を、焼いた後に使っています（%s）。何も変えていません。' % (pre.name, _names(users))))
    users = _foreign_uses(rig.data, {rig.as_pointer()}, 1)
    if users:
        bad.append(_p('The armature data is now shared (%s). Nothing was changed.' % _names(users),
                      'アーマチュアのデータを共有しています（%s）。何も変えていません。' % _names(users)))
    for entry in rec.get('disabled', []):
        pb = rig.pose.bones.get(entry[0])
        c = pb.constraints.get(entry[1]) if pb else None
        if c is not None and (c.type != 'ACTION' or not _disabled_entry_matches(c, entry)):
            bad.append(_p('The constraint "%s" on "%s" is not the one the bake turned off (collision).' % (entry[1], entry[0]),
                          '骨「%s」の拘束「%s」は、焼きが止めた物ではありません（衝突）。' % (entry[0], entry[1])))
    ks_rec = rec.get('keying_set') or {}
    ks = _keying_set_find(sc)
    if ks is not None and (ks_rec.get('created') or ks_rec.get('prev_paths') is not None):
        want = sorted((rig.name, p, int(i), 'NAMED', KEYING_SET_GROUP) for p, i in rec.get('channels', []))
        cur = sorted(tuple(x) for x in _keying_set_paths(ks))
        if cur != want:
            bad.append(_p('The keying set "%s" was changed after the bake.' % KEYING_SET_NAME,
                          'キーイングセット「%s」が焼いた後に変わっています。' % KEYING_SET_NAME))
    if ks is not None and not ks_rec.get('created') and ks_rec.get('prev_paths') is not None:
        # The paths the bake replaced are put back onto this rig only; a record naming anything else
        # could bind the path to a different object, so it is refused.
        foreign = _keying_record_foreign(ks_rec['prev_paths'], rig)
        if foreign:
            bad.append(_p('The keying set "%s" paths recorded before the bake name %s, not the Facial Rig; they cannot be put back safely. Nothing was changed.'
                          % (KEYING_SET_NAME, ', '.join('"%s"' % m for m in foreign)),
                          'キーイングセット「%s」の焼く前の道の記録が、表情リグではなく %s を指しています。安全に戻せません。何も変えていません。'
                          % (KEYING_SET_NAME, '、'.join('「%s」' % m for m in foreign))))
    if bad:
        raise ArkError(bad)
    return baked


# ---------------------------------------------------------------------------- 2. return
def ark_return(context, rig, live_name=None):
    sc = context.scene
    ad = rig.animation_data
    act = ad.action if ad else None
    if act is None or RECORD_KEY not in act.keys():
        if act is not None and any(k in act.keys() for k in FOREIGN_RECORD_KEYS):
            raise ArkError(_p('This bake was made by another tool; it is not owned here.', 'この焼きは別の道具が作った物で、ここの持ち物ではありません。'))
        raise ArkError(_p('No bake made by this tool is on the rig Action.', 'リグのアクションに、この道具の焼いた記録がありません。'))
    rec = owned_record(rig)
    if rec is None or rec.get('rig') != rig.name:
        raise ArkError(_p('The bake record is unreadable or belongs to another rig.', '焼いた記録が読めないか、別のリグの物です。'))
    if _is_linked(act) or _is_linked(rig) or _is_linked(rig.data):
        raise ArkError(_p('The rig or its Action is linked (read-only).', 'リグかアクションがリンク（読み取り専用）です。'))
    if ad.action_slot is None or ad.action_slot.identifier != rec['slot']:
        raise ArkError(_p('The rig Action slot changed after the bake.', '焼いた後にリグのアクションのスロットが変わっています。'))
    pre = bpy.data.actions.get(rec['backup'])
    if pre is None or pre.get(BACKUP_KEY) != rec['txn']:
        raise ArkError(_p('The backup Action "%s" of this bake is missing or was replaced.' % rec['backup'],
                          'この焼きの控えのアクション「%s」が無いか、別の物に替わっています。' % rec['backup']))
    pre_bag = None
    for s in pre.slots:
        if s.identifier == rec['slot']:
            pre_bag = _channelbag(pre, s)
    bag = _channelbag(act, ad.action_slot)
    if bag is None:
        raise ArkError(_p('The rig Action has no channels for its slot.', 'リグのアクションにスロットのチャンネルがありません。'))
    # Ownership is checked again now, before anything changes: users can appear after the bake.
    # The keying set and its active entry are restored in the scene the bake was made in, and only there.
    sc = _return_ownership_check(sc, rig, ad, act, pre, rec)
    f0, f1 = rec['range']
    chans = [tuple(x) for x in rec['channels']]
    static = rec.get('static', {})
    report = {'range': [f0, f1]}
    txn = _Txn()
    # Same as the bake: stored values of every touched channel come back as the last rollback step, after
    # any evaluation the rollback runs (which would write whichever keys exist at that moment into them).
    statics = _static_values(rig, chans + [(p, 0) for p in rec.get('hand_paths', []) if (p, 0) not in chans])
    txn.call(lambda r=rig, s=statics: _static_restore(r, s))
    try:
        txn.snap_groups(bag)
        removed = 0
        restored = 0
        pre_groups = set(g.name for g in pre_bag.groups) if pre_bag is not None else set()
        done = set()
        hand_paths = [(p, 0) for p in rec.get('hand_paths', [])]
        drop = []   # F-curves the bake created: removed at the end, once they are empty
        for path, idx in chans + [x for x in hand_paths if x not in chans]:
            if (path, idx) in done:
                continue
            done.add((path, idx))
            src = pre_bag.fcurves.find(path, index=idx) if pre_bag is not None else None
            ks = [k for k in src.keyframe_points if f0 - 1e-4 <= k.co.x <= f1 + 1e-4] if src is not None else []
            removed += _remove_keys(txn, bag, path, idx, f0, f1, drop_empty=False)
            if src is None:
                drop.append((path, idx))
            if ks:
                txn.snap_fcurve(bag, path, idx)
                fc = _fc_find(bag, path, idx)
                if fc is None:
                    group = src.group.name if src.group is not None else ''
                    fc = bag.fcurves.new(path, index=idx, group_name=group) if group else bag.fcurves.new(path, index=idx)
                    fc.extrapolation = src.extrapolation
                pts = fc.keyframe_points
                n0 = len(pts)
                pts.add(len(ks))
                for j, k in enumerate(ks):
                    _copy_key(k, pts[n0 + j])
                fc.update()
                restored += len(ks)
            fc = _fc_find(bag, path, idx)
            if fc is not None and len(fc.keyframe_points):
                if (path, idx) in drop:
                    drop.remove((path, idx))
                continue
            key = '%s|%d' % (path, idx)
            if path.startswith('pose.bones['):
                own = _parse_owner_path(path)
                pb = rig.pose.bones.get(own[0]) if own else None
                if pb is not None:
                    prop = own[1]
                    if key in static:
                        v = float(static[key])
                    else:
                        v = {'scale': (1.0, 1.0, 1.0), 'rotation_quaternion': (1.0, 0.0, 0.0, 0.0),
                             'rotation_axis_angle': (0.0, 0.0, 1.0, 0.0)}.get(prop, (0.0, 0.0, 0.0, 0.0))[idx]
                    vec = list(getattr(pb, prop))
                    vec[idx] = v
                    txn.set(pb, prop, vec)
            elif path.startswith('["') and path.endswith('"]'):
                p = path[2:-2]
                if key in static:
                    txn.set_prop(rig, p, float(static[key]))
                else:
                    try:
                        d = rig.id_properties_ui(p).as_dict().get('default', 0.0)
                    except Exception:
                        d = 0.0
                    txn.set_prop(rig, p, float(d))
        _fault('return.after_keys')
        on = 0
        for entry in rec.get('disabled', []):
            bone, cname = entry[0], entry[1]
            pb = rig.pose.bones.get(bone)
            c = pb.constraints.get(cname) if pb else None
            if c is not None and c.type == 'ACTION' and not c.enabled and _disabled_entry_matches(c, entry):
                txn.set(c, 'enabled', True)
                on += 1
        live = rec.get('live') or live_name or LIVE_PROP_DEFAULT
        lp = rec.get('live_prev')
        txn.set_prop(rig, live, lp if lp is not None else 1)
        for cn, vis in rec.get('collections_prev', {}).items():
            col = rig.data.collections_all.get(cn)
            if col is not None and bool(col.is_visible) != bool(vis):
                txn.set(col, 'is_visible', bool(vis))
        ks_rec = rec.get('keying_set') or {}
        ks = _keying_set_find(sc)
        if ks is not None:
            if ks_rec.get('created'):
                cur = _keying_set_paths(ks)
                txn.call(lambda s=sc, r=rig, pp=cur: _keying_set_restore_created(s, r, pp))
                _keying_set_remove(sc, ks)
            elif ks_rec.get('prev_paths') is not None:
                cur = _keying_set_paths(ks)
                cur_active = int(ks.paths.active_index)
                txn.call(lambda s=sc, r=rig, pp=cur, pa=cur_active:
                         _keying_set_set_paths(_keying_set_find(s), r, pp, pa) if _keying_set_find(s) is not None else None)
                _keying_set_set_paths(ks, rig, ks_rec['prev_paths'], ks_rec.get('prev_path_active'))
        if ks_rec.get('active_prev') is not None and 0 <= ks_rec['active_prev'] < len(sc.keying_sets) \
                and sc.keying_sets.active_index != ks_rec['active_prev']:
            txn.set(sc.keying_sets, 'active_index', ks_rec['active_prev'])
        txn.del_prop(act, RECORD_KEY)
        # Evaluate before the F-curves are dropped: a failure up to here rolls back without re-creating
        # any F-curve, so the channel order of the Action stays as it was.
        _refresh(rig)
        # Last step: drop the now-empty F-curves the bake created and the empty groups it made.
        for path, idx in drop:
            fc = _fc_find(bag, path, idx)
            if fc is not None and len(fc.keyframe_points) == 0:
                bag.fcurves.remove(fc)
        for g in list(bag.groups):
            if len(g.channels) == 0 and g.name not in pre_groups:
                bag.groups.remove(g)
    except BaseException:
        txn.rollback()
        raise
    # Committed.  Remove the owned leftovers: the backup copy, and the Action (with its slot) and the
    # animation data the bake created, when nothing else was keyed into them since.
    # Each removal re-checks that the datablock is still used by nothing but this bake (fake user aside);
    # anything used elsewhere is kept, never removed or unlinked.
    try:
        kept = []
        if not _uses_beyond_owned(pre, rig, False):
            bpy.data.actions.remove(pre)
        else:
            kept.append(pre.name)
        if rec.get('created_action') and len(bag.fcurves) == 0 and _action_only_owned_content(act, ad.action_slot):
            if _uses_beyond_owned(act, rig, True):
                kept.append(act.name)
            else:
                ad.action = None
                bpy.data.actions.remove(act)
                report['removed_created_action'] = True
                if rec.get('created_animdata') and not ad.drivers and not ad.nla_tracks:
                    rig.animation_data_clear()
        if kept:
            report['kept_in_use'] = kept
    except Exception as exc:  # the scene is already back in expression mode
        report['cleanup_warning'] = str(exc)
    report.update(ok=True, keys_removed=removed, keys_restored=restored, constraints_enabled=on)
    return report


def _keying_set_restore_created(scene, rig, paths):
    ks = _keying_set_find(scene)
    if ks is None:
        ks = scene.keying_sets.new(idname=KEYING_SET_IDNAME, name=KEYING_SET_NAME)
    _keying_set_set_paths(ks, rig, paths)


# ---------------------------------------------------------------------------- 3. check / reapply
class _Rep:
    def __init__(self, dry):
        self.dry = dry
        self.changed = []
        self.notes = []

    def ch(self, en, ja):
        self.changed.append(_p(en, ja))
        return not self.dry


def _action_matches(act, a):
    if not _action_structure_ok(act, a) or len(act.slots) != 1:
        return False
    cb = act.layers[0].strips[0].channelbag(act.slots[0])
    if cb is None or len(cb.fcurves) != len(a['fcurves']):
        return False
    for f in a['fcurves']:
        fc = cb.fcurves.find(f['data_path'], index=f['index'])
        if fc is None or fc.extrapolation != f['extrapolation'] or len(fc.keyframe_points) != len(f['keys']):
            return False
        if (fc.group.name if fc.group else None) != f['group']:
            return False
        for k, (x, y, ip) in zip(fc.keyframe_points, f['keys']):
            if not (float(k.co[0]) == _f32(x) and float(k.co[1]) == _f32(y) and k.interpolation == ip):
                return False
    for k, v in a['props'].items():
        if k not in act.keys() or act[k] != v:
            return False
    return bool(act.use_fake_user) == a['use_fake_user']


HOLD_NAME = '.smart_shapekey_ark_reapply_hold'
_GROUP_FLAGS = ('select', 'lock', 'mute', 'show_expanded', 'show_expanded_graph', 'use_pin')
_THEME_COLORS = ('normal', 'select', 'active')


def _rna_dump(s, depth=0):
    """Every RNA value of an F-Curve (all key attributes, modifiers and their settings, samples); pointers by name."""
    out = {}
    for p in s.bl_rna.properties:
        k = p.identifier
        if k == 'rna_type':
            continue
        v = getattr(s, k)
        if p.type == 'POINTER':
            out[k] = getattr(v, 'name', type(v).__name__) if v is not None else None
        elif p.type == 'COLLECTION':
            out[k] = [_rna_dump(x, depth + 1) for x in v] if depth < 4 else len(v)
        elif isinstance(v, set):
            out[k] = sorted(v)
        elif hasattr(v, '__len__') and not isinstance(v, str):
            out[k] = list(v)
        else:
            out[k] = v
    return out


def _group_state(g):
    return ({k: getattr(g, k) for k in _GROUP_FLAGS}, g.color_set,
            tuple(tuple(getattr(g.colors, c)) for c in _THEME_COLORS), g.colors.show_colored_constraints)


def _group_restore(g, st):
    flags, color_set, colors, constraints = st
    g.color_set = color_set
    if color_set == 'CUSTOM':
        for c, v in zip(_THEME_COLORS, colors):
            setattr(g.colors, c, v)
        g.colors.show_colored_constraints = constraints
    for k, v in flags.items():
        setattr(g, k, v)


def _group_by_name(bag, name):
    return next((g for g in bag.groups if g.name == name), None)


class _Hold:
    """Exact copies of the curves of every Action the reapply will rewrite, made and checked before the first write.

    The copies live in one hidden Action (created inside the transaction, so a rollback removes it last) and carry
    everything an F-Curve has: modifiers and their settings, mute / lock / hide / select, colour, smoothing,
    extrapolation, every key attribute and sampled points.  A rollback copies them back; a success removes the hold.
    """

    def __init__(self, txn):
        self.txn = txn
        self.act = None
        self.strip = None
        self.held = {}

    def take(self, act):
        entry = {'curves': [], 'groups': []}
        self.held[act.as_pointer()] = entry
        if len(act.slots) == 0 or len(act.layers) == 0 or len(act.layers[0].strips) == 0:
            return []
        bag = act.layers[0].strips[0].channelbag(act.slots[0])
        if bag is None:
            return []
        if self.act is None:
            self.act = bpy.data.actions.new(HOLD_NAME)
            self.txn.created_action(self.act)
            self.strip = self.act.layers.new('Hold').strips.new(type='KEYFRAME')
        hold_bag = self.strip.channelbag(self.act.slots.new('OBJECT', 'Hold%d' % len(self.held)), ensure=True)
        bad = []
        for fc in bag.fcurves:
            copy = hold_bag.fcurves.new_from_fcurve(fc)
            want, got = _rna_dump(fc), _rna_dump(copy)
            want.pop('group', None)
            got.pop('group', None)
            if want != got:
                bad.append('%s[%d] (%s)' % (fc.data_path, fc.array_index, ', '.join(sorted(k for k in want if want[k] != got.get(k)))))
            entry['curves'].append((fc.data_path, fc.array_index, fc.group.name if fc.group else None, copy))
        entry['groups'] = [(g.name, _group_state(g)) for g in bag.groups]
        return bad

    def get(self, act):
        return self.held.get(act.as_pointer())

    def release(self):
        if self.act is not None and self.act.name in bpy.data.actions:
            bpy.data.actions.remove(self.act)
        self.act = None


def _fill_action(txn, act, a, held=None):
    """Write the declared content into an Action (existing slot kept, so constraint slot handles stay).

    ``held`` is the exact copy of the Action's curves made by ``_Hold`` before the first write: the rollback copies
    them back unchanged, and a declared curve that already existed keeps its own settings (modifiers, mute, lock,
    colour ...), only its declared content (keys, group, extrapolation) is rewritten.
    """
    from bpy_extras import anim_utils
    if len(act.slots) == 0:
        slot = act.slots.new(a['slot']['target_id_type'], a['slot']['name'])
        txn.call(lambda x=act, s=slot: x.slots.remove(s) if s in list(x.slots) else None)
    slot = act.slots[0]
    if len(act.layers) == 0:
        lay = act.layers.new(a['layer'] or 'Layer')
        txn.call(lambda x=act, l_=lay: x.layers.remove(l_) if l_ in list(x.layers) else None)
        lay.strips.new(type='KEYFRAME')
    strip = act.layers[0].strips[0]
    had_bag = strip.channelbag(slot) is not None
    cb = strip.channelbag(slot, ensure=True)
    if not had_bag:
        txn.call(lambda s_=strip, c=cb: s_.channelbags.remove(c) if c in list(s_.channelbags) else None)
    if held is None:
        if len(cb.fcurves):
            raise ArkError(_p('Action %s: its curves were not copied before the write.' % act.name,
                              'アクション %s：書く前に F カーブを写せていません。' % act.name))
        held = {'curves': [], 'groups': []}
    curves, groups = held['curves'], held['groups']

    def back(c=cb, cs=curves, gs=groups):
        while len(c.fcurves):
            c.fcurves.remove(c.fcurves[0])
        for g in list(c.groups):
            c.groups.remove(g)
        for gname, _st in gs:
            c.groups.new(gname)
        for _path, _idx, gname, copy in cs:
            f = c.fcurves.new_from_fcurve(copy)
            if gname is not None:
                f.group = _group_by_name(c, gname)
        for gname, st in gs:
            _group_restore(_group_by_name(c, gname), st)
    txn.call(back)
    old = {(path, idx): copy for path, idx, _g, copy in curves}
    while len(cb.fcurves):
        cb.fcurves.remove(cb.fcurves[0])
    for g in list(cb.groups):
        cb.groups.remove(g)
    for f in a['fcurves']:
        src = old.get((f['data_path'], f['index']))
        if src is None or len(src.sampled_points):
            fc = cb.fcurves.new(f['data_path'], index=f['index'], group_name=f['group'] or '')
        else:
            fc = cb.fcurves.new_from_fcurve(src)
            while len(fc.keyframe_points):
                fc.keyframe_points.remove(fc.keyframe_points[len(fc.keyframe_points) - 1], fast=True)
            if f['group']:
                fc.group = _group_by_name(cb, f['group']) or cb.groups.new(f['group'])
        pts = fc.keyframe_points
        for x, y, ip in f['keys']:
            # insert() gives a new key Blender's own defaults (easing, back, amplitude, period); the handle
            # type is set explicitly so the result does not depend on the user's keyframe preferences.
            p = pts.insert(x, y, options={'FAST'})
            p.interpolation = ip
            p.handle_left_type = p.handle_right_type = 'AUTO_CLAMPED'
        fc.update()
        fc.extrapolation = f['extrapolation']
    for gname, st in groups:
        g = _group_by_name(cb, gname)
        if g is not None:
            _group_restore(g, st)
    for k, v in a['props'].items():
        txn.set_prop(act, k, v)
    if bool(act.use_fake_user) != a['use_fake_user']:
        txn.set(act, 'use_fake_user', a['use_fake_user'])
    _ = anim_utils  # imported for parity with other helpers


def _set_fields(txn, rep, obj, d, fields, label, skip=()):
    for k in fields:
        if k in skip:
            continue
        cur = getattr(obj, k)
        want = d[k]
        if not _same_value(cur, want, k in _FLOAT_FIELDS):
            if rep.ch('%s.%s: %r -> %r' % (label, k, cur, want), '%s.%s：%r → %r' % (label, k, cur, want)):
                txn.set(obj, k, want)


def reapply(context, model, rig, dry_run=True):
    """Check (dry_run) or reapply the declared Actions and Action constraints (stack order included)."""
    check_scene(model, rig, for_bake=False)
    rep = _Rep(dry_run)
    baked = ark_mode(rig, model.live) == 'BAKED'
    skip = ('enabled', 'mute') if baked else ()
    if baked:
        rep.notes.append(_p('Hand-key mode: enabled / mute of the declared constraints are not checked.',
                            '手付けモードなので、正本の拘束の有効・ミュートは見ません。'))
    txn = _Txn()
    hold = _Hold(txn)
    try:
        if not dry_run:
            # Copy and check every Action to be rewritten before the first write; refuse with nothing changed
            # (the hold is removed by the rollback) if any curve cannot be copied exactly.
            bad = []
            for name, a in model.actions.items():
                act = bpy.data.actions.get(name)
                if act is not None and not _action_matches(act, a):
                    bad += [_p('Action "%s": F-Curve %s cannot be copied exactly.' % (name, x),
                               'アクション「%s」：F カーブ %s をそのまま写せません。' % (name, x)) for x in hold.take(act)]
            if bad:
                raise ArkError(bad + [_p('Nothing was changed.', '何も変えていません。')])
        for name, a in model.actions.items():
            act = bpy.data.actions.get(name)
            if act is not None and _action_matches(act, a):
                continue
            if not rep.ch('Action %s %s' % (name, 'created' if act is None else 'rewritten'),
                          'アクション %s を%s' % (name, '作った' if act is None else '書き直した')):
                continue
            if act is None:
                act = bpy.data.actions.new(name)
                txn.created_action(act)
                if act.name != name:
                    raise ArkError(_p('Blender renamed the new Action %s.' % name, 'Blender が新しいアクション %s の名前を変えました。' % name))
            _fill_action(txn, act, a, hold.get(act))
            if act.slots[0].identifier != a['slot']['identifier']:
                raise ArkError(_p('Action %s slot became %s (spec %s).' % (name, act.slots[0].identifier, a['slot']['identifier']),
                                  'アクション %s のスロットが %s になりました（正本 %s）。' % (name, act.slots[0].identifier, a['slot']['identifier'])))
            _fault('reapply.after_action')
        for bone, lst in model.spec['action_constraints'].items():
            pb = rig.pose.bones[bone]
            for k, d in enumerate(lst):
                c = pb.constraints.get(d['name'])
                lab = '%s/%s' % (bone, d['name'])
                if c is None:
                    if not rep.ch('%s added' % lab, '%s を足した' % lab):
                        continue
                    prev_active = next((x for x in pb.constraints if x.active), None)
                    c = pb.constraints.new('ACTION')
                    txn.call(lambda p=pb, cc=c: p.constraints.remove(cc) if cc in list(p.constraints) else None)
                    c.name = d['name']
                    if c.name != d['name']:
                        raise ArkError(_p('Blender renamed the new constraint %s.' % lab, 'Blender が新しい拘束 %s の名前を変えました。' % lab))
                    if prev_active is not None:
                        prev_active.active = True
                tgt = bpy.data.objects.get(d['target']) if d['target'] else None
                if c.target != tgt and rep.ch('%s.target -> %s' % (lab, d['target']), '%s.target → %s' % (lab, d['target'])):
                    txn.set(c, 'target', tgt)
                sp = bpy.data.objects.get(d['space_object']) if d['space_object'] else None
                if c.space_object != sp and rep.ch('%s.space_object -> %s' % (lab, d['space_object']), '%s.space_object → %s' % (lab, d['space_object'])):
                    txn.set(c, 'space_object', sp)
                _set_fields(txn, rep, c, d, ('subtarget',), lab)
                act = bpy.data.actions.get(d['action'])
                if c.action != act and rep.ch('%s.action -> %s' % (lab, d['action']), '%s.action → %s' % (lab, d['action'])):
                    txn.set(c, 'action', act)
                if act is not None:
                    slot = next((s for s in act.slots if s.identifier == d['action_slot']), None)
                    if slot is None and not dry_run:
                        raise ArkError(_p('%s: Action %s has no slot %s.' % (lab, d['action'], d['action_slot']),
                                          '%s：アクション %s にスロット %s がありません。' % (lab, d['action'], d['action_slot'])))
                    if slot is not None and (c.action_slot.identifier if c.action_slot else None) != d['action_slot'] \
                            and rep.ch('%s.action_slot -> %s' % (lab, d['action_slot']), '%s.action_slot → %s' % (lab, d['action_slot'])):
                        txn.set(c, 'action_slot', slot)
                _set_fields(txn, rep, c, d, ACTION_FIELDS, lab, skip=skip + ('subtarget',))
                names = [x.name for x in pb.constraints]
                cur = names.index(c.name) if c.name in names else -1
                if cur != k and cur >= 0 and rep.ch('%s position %d -> %d' % (lab, cur, k), '%s の位置 %d → %d' % (lab, cur, k)):
                    pb.constraints.move(cur, k)
                    txn.call(lambda p=pb, a_=cur, b_=k: p.constraints.move(b_, a_))
                _fault('reapply.after_constraint')
        if not dry_run:
            _refresh(rig)
            hold.release()
    except BaseException:
        txn.rollback()
        raise
    return {'dry_run': dry_run, 'changed': rep.changed, 'changed_count': len(rep.changed), 'notes': rep.notes,
            'spec_sha256': model.sha}


def build_model(spec, sha):
    return Model(spec, sha)
