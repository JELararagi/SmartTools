# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
"""現在の交差面の内部標本を有限回調べる。標本を面全体の合格とはしない。"""
import json,math
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from .contact_diagnosis import validated_report_sample,geometry
PROBE_OWNER='smart_shapekey_suite.solid_contact_probe.v1'
MAX_POINTS=128
MAX_RAY_HITS=16
TOLERANCE_M=2e-7
LATTICE_ORDER=7

def solid_tree(geo):
    if geo['boundary_edges'] or geo['nonmanifold_edges']:raise ValueError('Solid probe requires a closed manifold surface.')
    points=geo['points'];tris=geo['tris']
    volume=sum(points[a].dot(points[b].cross(points[c]))/6 for a,b,c in tris)
    if not math.isfinite(volume) or abs(volume)<1e-12:raise ValueError('Solid probe surface has no verified finite volume.')
    return dict(tree=BVHTree.FromPolygons(points,tris,all_triangles=True),geometry=geo,orientation=1 if volume>0 else -1,
        mins=[min(p[k] for p in points)-.003 for k in range(3)],maxs=[max(p[k] for p in points)+.003 for k in range(3)],volume=volume)

def ray_hits(solid,origin,direction,distance):
    cursor=origin.copy();end=origin+direction*distance;hits=[]
    for _ in range(MAX_RAY_HITS):
        location,normal,triangle,dist=solid['tree'].ray_cast(cursor,direction,max(0.,(end-cursor).dot(direction)))
        if location is None:return hits,True
        a,b,c=[solid['geometry']['points'][i] for i in solid['geometry']['tris'][triangle]]
        ab=b-a;ac=c-a;ap=location-a;d00=ab.dot(ab);d01=ab.dot(ac);d11=ac.dot(ac);d20=ap.dot(ab);d21=ap.dot(ac);den=d00*d11-d01*d01
        if abs(den)<1e-20:return hits,False
        u=(d11*d20-d01*d21)/den;v=(d00*d21-d01*d20)/den
        hits.append(dict(point=location,normal=normal,triangle=triangle,edge=min(u,v,1-u-v)<1e-8))
        cursor=location+direction*.000001
    return hits,False

def classify_point(solid,point):
    states=[];boundary=False
    for axis in range(3):
        direction=Vector(tuple(1. if k==axis else 0. for k in range(3)));origin=point.copy();origin[axis]=solid['mins'][axis]
        hits,complete=ray_hits(solid,origin,direction,solid['maxs'][axis]-solid['mins'][axis])
        if any(abs(h['point'][axis]-point[axis])<=TOLERANCE_M for h in hits):boundary=True;states.append('boundary');continue
        if not complete:states.append('unknown_ray_limit');continue
        if any(h['edge'] for h in hits):states.append('unknown_edge');continue
        signs=[h['normal'].dot(direction)*solid['orientation'] for h in hits]
        if len(hits)%2 or any(abs(v)<1e-7 for v in signs) or any((v<0)!=(i%2==0) for i,v in enumerate(signs)):
            states.append('unknown_crossings');continue
        states.append('inside' if sum(h['point'][axis]<point[axis] for h in hits)%2 else 'outside')
    known=[s for s in states if s in ('inside','outside')]
    state='boundary' if boundary else (known[0] if len(known)>=2 and len(set(known))==1 else 'unknown')
    result=dict(state=state,axis_states=states)
    if state=='inside':
        location,normal,triangle,distance=solid['tree'].find_nearest(point)
        if location is None or not math.isfinite(distance):return dict(state='unknown',axis_states=states)
        result.update(finite_boundary_distance_mm=distance*1000,nearest_surface_triangle=triangle,nearest_surface_point_m=list(location))
    return result

def probe_reported_face(context,surface_name,sample_index):
    obj,target,text,data,current,polygon,indices=validated_report_sample(context,surface_name,sample_index)
    surface=context.scene.objects.get(surface_name)
    if surface is None or surface==obj or surface.type!='MESH':raise ValueError('Choose a current reported mesh surface.')
    other=geometry(surface,context.evaluated_depsgraph_get())
    if data['geometry_signatures'].get(surface_name)!=other['signature']:raise ValueError('The probe surface geometry is stale. Reinspect the current target.')
    triangles=[i for i,p in enumerate(current['triangle_polygons']) if p==polygon]
    per_triangle=(LATTICE_ORDER+1)*(LATTICE_ORDER+2)//2
    if not triangles or len(triangles)*per_triangle>MAX_POINTS:raise ValueError('The contact face exceeds the solid probe point limit.')
    solid=solid_tree(other);samples=[];counts=dict(outside=0,inside=0,boundary=0,unknown=0)
    for ti in triangles:
        verts=current['tris'][ti];points=[current['points'][i] for i in verts]
        for ia in range(LATTICE_ORDER+1):
            for ib in range(LATTICE_ORDER+1-ia):
                weights=(ia/LATTICE_ORDER,ib/LATTICE_ORDER,(LATTICE_ORDER-ia-ib)/LATTICE_ORDER)
                point=sum((p*w for p,w in zip(points,weights)),Vector());classification=classify_point(solid,point);counts[classification['state']]+=1
                samples.append(dict(reference_triangle=ti,barycentric=list(weights),point_m=list(point),classification=classification))
    return dict(schema_version=1,scene=context.scene.name,frame=context.scene.frame_current_final,reference_part=obj.name,reference_mesh=obj.data.name,reference_active_key=target.name,surface_part=surface_name,
        source_contact_report=text.name,geometry_signatures={obj.name:current['signature'],surface_name:other['signature']},reference_polygon=polygon,reference_source_polygon_vertices=indices,
        lattice_order=LATTICE_ORDER,max_points=MAX_POINTS,max_ray_hits=MAX_RAY_HITS,position_tolerance_m=TOLERANCE_M,counts=counts,samples=samples,
        max_sampled_penetration_mm=max((s['classification'].get('finite_boundary_distance_mm',0) for s in samples),default=0),sampling_is_not_full_surface_clearance=True,
        boundary_and_unknown_do_not_pass=True,geometry_changed=False,full_contact_accepted=False)

def write_probe_report(context,report):
    cfg=context.scene.smart_shapekey_facial_settings;old_name=cfg.contact_probe_name;old_status=cfg.contact_probe_status
    payload=json.dumps(report,indent=2,ensure_ascii=False)
    if len(payload)>2*1024*1024:raise ValueError('Solid probe report exceeds its write limit.')
    text=bpy.data.texts.get(old_name)
    if not(text and not text.library and text.get('ss_contact_probe_owner')==PROBE_OWNER and text.get('ss_contact_probe_scene')==context.scene.name):
        text=next((t for t in bpy.data.texts if not t.library and t.get('ss_contact_probe_owner')==PROBE_OWNER and t.get('ss_contact_probe_scene')==context.scene.name),None)
    created=text is None;previous=text.as_string() if text else None
    try:
        if created:text=bpy.data.texts.new('SS_Facial_Contact_Probe')
        text.clear();text.write(payload);text['ss_contact_probe_owner']=PROBE_OWNER;text['ss_contact_probe_scene']=context.scene.name
        cfg.contact_probe_name=text.name;c=report['counts'];cfg.contact_probe_status='標本：外側{outside} / 内部{inside} / 境界{boundary} / 未確定{unknown}\n最大標本侵入 {depth:.4f}mm（全表面の合格判定ではありません）'.format(**c,depth=report['max_sampled_penetration_mm'])
        return text.name
    except Exception:
        if created and text:bpy.data.texts.remove(text)
        elif text and previous is not None:text.clear();text.write(previous)
        cfg.contact_probe_name=old_name;cfg.contact_probe_status=old_status
        raise
