# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Operators and panel rows for the ARKit facial rig tools (bake / return / check / reapply).

The rows live inside "Facial CSV Capture" under two headings, each with its own "?" help.
Explanations are only in that help; the panel shows controls, tooltips and one-line status.
"""
from __future__ import annotations

import bpy

from . import ark_rig

# Last result per operation, kept in memory only (a check must not change saved data).
_STATUS = {'bake': '', 'check': ''}
_MAX_REPORT_LINES = 40


def _ui(en, ja, context=None):
    try:
        from ..translation import ui_text
        return ui_text(en, ja, context)
    except Exception:
        return en


def _pick(pair, context=None):
    return _ui(pair[0], pair[1], context)


def _settings(context):
    scene = getattr(context, 'scene', None)
    return getattr(scene, 'smart_shapekey_facial_settings', None) if scene is not None else None


def _load(context):
    cfg = _settings(context)
    if cfg is None:
        raise ark_rig.ArkError(ark_rig._p('Scene settings are not available.', 'シーンの設定がありません。'))
    spec, sha = ark_rig.load_spec(cfg.ark_spec_path)
    model = ark_rig.build_model(spec, sha)
    rig = ark_rig.resolve_rig(spec, cfg.rig)
    if context.mode == 'EDIT_ARMATURE' and context.object == rig:
        raise ark_rig.ArkError(ark_rig._p('Leave Edit Mode of the rig first.', '先にリグの編集モードを抜けてください。'))
    return cfg, model, rig


def _report_error(op, context, exc):
    if isinstance(exc, ark_rig.ArkError):
        lines = [_pick(p, context) for p in exc.problems]
    else:
        lines = [_ui('The operation failed and was not completed: %s' % exc,
                     '失敗したので、完了していません：%s' % exc, context)]
    for line in lines[:_MAX_REPORT_LINES]:
        op.report({'ERROR'}, line)
    if len(lines) > _MAX_REPORT_LINES:
        op.report({'ERROR'}, _ui('... and %d more.' % (len(lines) - _MAX_REPORT_LINES), '…ほか %d 件。' % (len(lines) - _MAX_REPORT_LINES), context))
    return lines[0] if lines else ''


class SMARTSHAPEKEY_OT_ark_bake(bpy.types.Operator):
    bl_idname = 'smart_shapekey.ark_bake'
    bl_label = 'Bake Face to Hand Keys'
    bl_description = 'Bake the ARKit slider result of every frame in the range into keys on the face controller bones and hand values, then switch the rig to hand-key mode'
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            cfg, model, rig = _load(context)
            if cfg.ark_range_mode == 'EXPLICIT':
                rep = ark_rig.bake(context, model, rig, frame_start=cfg.ark_frame_start, frame_end=cfg.ark_frame_end,
                                   allow_partial=cfg.ark_allow_partial, verify=cfg.ark_verify)
            else:
                rep = ark_rig.bake(context, model, rig, verify=cfg.ark_verify)
        except Exception as exc:
            _STATUS['bake'] = _report_error(self, context, exc)
            return {'CANCELLED'}
        f0, f1 = rep['frames']
        line = _ui('Baked frames %d to %d: %d channels, %d constraints off.' % (f0, f1, rep['channels'], rep['constraints_disabled']),
                   '%d〜%d コマを焼きました：%d チャンネル、拘束 %d 本を止めました。' % (f0, f1, rep['channels'], rep['constraints_disabled']), context)
        if 'verify_max_diff_mm' in rep:
            line += _ui(' Self check %.6f mm.' % rep['verify_max_diff_mm'], ' 自己確認 %.6f mm。' % rep['verify_max_diff_mm'], context)
            if not rep.get('verify_pass'):
                self.report({'WARNING'}, _ui('The shape moved more than 0.01 mm in the self check.', '自己確認で形が 0.01 mm より大きく動きました。', context))
        if rep.get('range_extended_beyond_scene'):
            self.report({'WARNING'}, _ui('Keys reach outside the scene range; frames %d to %d were baked.' % (f0, f1),
                                         'キーがシーンの範囲の外まであるので、%d〜%d を焼きました。' % (f0, f1), context))
        _STATUS['bake'] = line
        self.report({'INFO'}, line)
        return {'FINISHED'}


class SMARTSHAPEKEY_OT_ark_return(bpy.types.Operator):
    bl_idname = 'smart_shapekey.ark_return'
    bl_label = 'Return to Expression Mode'
    bl_description = 'Remove the keys this tool baked, put back the keys and values from before the bake, and turn the ARKit constraints it stopped back on'
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            cfg = _settings(context)
            if cfg is None:
                raise ark_rig.ArkError(ark_rig._p('Scene settings are not available.', 'シーンの設定がありません。'))
            rig = cfg.rig
            if rig is None:
                rec_rig = None
                for ob in bpy.data.objects:
                    if ob.type == 'ARMATURE' and ark_rig.owned_record(ob) is not None:
                        if rec_rig is not None:
                            raise ark_rig.ArkError(ark_rig._p('Several rigs carry a bake; choose Facial Rig.', '焼いたリグが複数あります。「表情リグ」を選んでください。'))
                        rec_rig = ob
                rig = rec_rig
            if rig is None or rig.type != 'ARMATURE':
                raise ark_rig.ArkError(ark_rig._p('Choose Facial Rig.', '「表情リグ」を選んでください。'))
            rep = ark_rig.ark_return(context, rig)
        except Exception as exc:
            _STATUS['bake'] = _report_error(self, context, exc)
            return {'CANCELLED'}
        line = _ui('Returned to expression mode: %d keys removed, %d keys put back, %d constraints on.' % (rep['keys_removed'], rep['keys_restored'], rep['constraints_enabled']),
                   '表情モードへ戻しました：キー %d 個を消し、%d 個を戻し、拘束 %d 本を有効にしました。' % (rep['keys_removed'], rep['keys_restored'], rep['constraints_enabled']), context)
        if rep.get('cleanup_warning'):
            self.report({'WARNING'}, rep['cleanup_warning'])
        _STATUS['bake'] = line
        self.report({'INFO'}, line)
        return {'FINISHED'}


def _list_changes(op, context, rep):
    for pair in rep['changed'][:_MAX_REPORT_LINES]:
        op.report({'INFO'}, _pick(pair, context))
    if rep['changed_count'] > _MAX_REPORT_LINES:
        op.report({'INFO'}, _ui('... and %d more.' % (rep['changed_count'] - _MAX_REPORT_LINES), '…ほか %d 件。' % (rep['changed_count'] - _MAX_REPORT_LINES), context))
    for pair in rep['notes']:
        op.report({'INFO'}, _pick(pair, context))


class SMARTSHAPEKEY_OT_ark_check(bpy.types.Operator):
    bl_idname = 'smart_shapekey.ark_check'
    bl_label = 'Check Against Spec'
    bl_description = 'List every declared ARKit Action and Action constraint that differs from the spec JSON without changing anything'
    bl_options = set()

    def execute(self, context):
        try:
            _cfg, model, rig = _load(context)
            rep = ark_rig.reapply(context, model, rig, dry_run=True)
        except Exception as exc:
            _STATUS['check'] = _report_error(self, context, exc)
            return {'CANCELLED'}
        _list_changes(self, context, rep)
        line = _ui('Check: %d differences.' % rep['changed_count'], '検査：違い %d 件。' % rep['changed_count'], context)
        _STATUS['check'] = line
        self.report({'INFO'}, line)
        return {'FINISHED'}


class SMARTSHAPEKEY_OT_ark_reapply(bpy.types.Operator):
    bl_idname = 'smart_shapekey.ark_reapply'
    bl_label = 'Reapply From Spec'
    bl_description = 'Add the missing declared ARKit Actions and Action constraints and correct the ones that differ from the spec JSON (order included)'
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            _cfg, model, rig = _load(context)
            rep = ark_rig.reapply(context, model, rig, dry_run=False)
        except Exception as exc:
            _STATUS['check'] = _report_error(self, context, exc)
            return {'CANCELLED'}
        _list_changes(self, context, rep)
        line = _ui('Reapplied: %d changes.' % rep['changed_count'], '当て直しました：変更 %d 件。' % rep['changed_count'], context)
        _STATUS['check'] = line
        self.report({'INFO'}, line)
        return {'FINISHED'}


CLASSES = (SMARTSHAPEKEY_OT_ark_bake, SMARTSHAPEKEY_OT_ark_return, SMARTSHAPEKEY_OT_ark_check, SMARTSHAPEKEY_OT_ark_reapply)


def _mode_line(context, cfg):
    rig = cfg.rig
    if rig is None or rig.type != 'ARMATURE':
        return _ui('Rig: not chosen', 'リグ：未選択', context)
    if ark_rig.owned_record(rig) is not None:
        return _ui('Rig: hand-key mode (baked by this tool)', 'リグ：手付けモード（この道具で焼いた状態）', context)
    mode = ark_rig.ark_mode(rig)
    if mode == 'BAKED':
        return _ui('Rig: hand-key mode (not baked by this tool)', 'リグ：手付けモード（この道具の焼きではない）', context)
    if mode == 'LIVE':
        return _ui('Rig: expression mode', 'リグ：表情モード', context)
    return _ui('Rig: no mode switch property', 'リグ：モードの切り替えのプロパティなし', context)


def draw(layout, context, heading):
    """Rows for the two headings; ``heading`` is the facial_capture heading helper."""
    from ..ui_sections import stacked_prop
    cfg = _settings(context)
    if cfg is None:
        return
    layout.separator()
    heading(layout, context, 'ARKit rig: bake / return', 'ARKitリグの焼きと戻し',
            'facial_ark_bake', 'KEYFRAME_HLT')
    stacked_prop(layout, cfg, 'ark_spec_path')
    row = layout.row(align=True)
    row.prop(cfg, 'ark_range_mode', expand=True)
    if cfg.ark_range_mode == 'EXPLICIT':
        rng = layout.column(align=True)
        rng.prop(cfg, 'ark_frame_start')
        rng.prop(cfg, 'ark_frame_end')
        layout.prop(cfg, 'ark_allow_partial')
    layout.prop(cfg, 'ark_verify')
    ops = layout.column(align=True)
    ops.operator('smart_shapekey.ark_bake', text=_ui('Bake Face to Hand Keys', '顔を手付け用に焼く', context), icon='KEYFRAME_HLT')
    ops.operator('smart_shapekey.ark_return', text=_ui('Return to Expression Mode', '表情モードへ戻す', context), icon='LOOP_BACK')
    layout.label(text=_mode_line(context, cfg))
    if _STATUS['bake']:
        layout.label(text=_STATUS['bake'])
    layout.separator()
    heading(layout, context, 'ARKit rig: check / reapply', 'ARKitリグの検査と当て直し',
            'facial_ark_reapply', 'FILE_REFRESH')
    ops = layout.column(align=True)
    ops.operator('smart_shapekey.ark_check', text=_ui('Check Against Spec', '正本と比べて検査', context), icon='VIEWZOOM')
    ops.operator('smart_shapekey.ark_reapply', text=_ui('Reapply From Spec', '正本から当て直す', context), icon='FILE_REFRESH')
    if _STATUS['check']:
        layout.label(text=_STATUS['check'])
