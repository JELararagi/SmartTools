# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Exact-identity lifecycle ownership for Smart Shapekey Suite.

The ledger deliberately avoids process-global monkeypatching and name/prefix based
teardown. Every resource is recorded immediately after Blender returns its native
identity, together with the native remover that must be used for rollback.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable
import threading
import time
import uuid

import bpy

SUITE_ID = "smart_shapekey_suite"
_NAMESPACE_KEY = "SMART_SHAPEKEY_SUITE_LIFECYCLE_V1420"
_GENERATION_KEY = "SMART_SHAPEKEY_SUITE_LIFECYCLE_GENERATION_V1420"
_FAULT_STAGE: str | None = None

# Blender clears ``bpy.app.driver_namespace`` on EVERY file load (measured on
# 5.1.2 ec6e62d40fa9). A ledger stored only there is orphaned as soon as the
# user opens a .blend, which turned unregister into a silent no-op and leaked
# classes/RNA properties/translations into the next live reinstall. This
# module-level mirror survives file loads for the lifetime of this module
# generation; ``current_ledger`` republishes it into the namespace on demand.
_LEDGER_GLOBAL: Any = None
_GENERATION_GLOBAL: int = 0


@dataclass(slots=True)
class GenerationToken:
    owner_suite_id: str
    owner_uuid: str
    generation: int
    registration_instance_uuid: str = ""
    created_monotonic: float = field(default_factory=time.monotonic)
    active: bool = True
    ready: bool = False


@dataclass(slots=True)
class LedgerEntry:
    kind: str
    identity: Any
    remover: Callable[[], None]
    label: str = ""
    native_owner: Any = None
    owner_suite_id: str = SUITE_ID
    owner_uuid: str = ""
    generation: int = 0
    callback_identity: Any = None
    native_remover: Any = None
    removed: bool = False

    def remove_exact(self) -> bool:
        if self.removed:
            return False
        self.remover()
        self.removed = True
        return True


class ResourceLedger:
    """Generation-scoped exact resource journal.

    A ledger is stored in ``bpy.app.driver_namespace`` so reloads can remove the
    previous generation by the exact Python/RNA/handler identities it created.
    Foreign resources are never removed merely because a name matches.
    """

    __slots__ = ("token", "entries", "state", "errors", "_lock")

    def __init__(self, token: GenerationToken):
        self.token = token
        self.entries: list[LedgerEntry] = []
        self.state = "REGISTERING"
        self.errors: list[str] = []
        self._lock = threading.RLock()

    def record_entry(
        self,
        kind: str,
        identity: Any,
        remover: Callable[[], None],
        *,
        label: str = "",
        native_owner: Any = None,
        callback_identity: Any = None,
        native_remover: Any = None,
    ) -> LedgerEntry:
        if identity is None:
            raise RuntimeError(f"cannot journal null identity: {kind}:{label}")
        if not callable(remover):
            raise RuntimeError(f"cannot journal non-callable remover: {kind}:{label}")
        entry = LedgerEntry(
            kind=kind,
            identity=identity,
            remover=remover,
            label=label,
            native_owner=native_owner,
            owner_suite_id=self.token.owner_suite_id,
            owner_uuid=self.token.owner_uuid,
            generation=self.token.generation,
            callback_identity=callback_identity,
            native_remover=native_remover if native_remover is not None else remover,
        )
        with self._lock:
            if not self.token.active or self.state not in {"REGISTERING", "READY"}:
                raise RuntimeError(f"cannot journal resource into inactive generation: {kind}:{label}")
            self.entries.append(entry)
        return entry

    def record(
        self,
        kind: str,
        identity: Any,
        remover: Callable[[], None],
        *,
        label: str = "",
        native_owner: Any = None,
        callback_identity: Any = None,
        native_remover: Any = None,
    ) -> Any:
        self.record_entry(
            kind,
            identity,
            remover,
            label=label,
            native_owner=native_owner,
            callback_identity=callback_identity,
            native_remover=native_remover,
        )
        return identity

    def find(self, kind: str, identity: Any) -> LedgerEntry | None:
        with self._lock:
            for entry in reversed(self.entries):
                if not entry.removed and entry.kind == kind and entry.identity is identity:
                    return entry
        return None

    def rollback(self) -> None:
        self.token.active = False
        self.token.ready = False
        self.state = "ROLLING_BACK"
        with self._lock:
            entries = tuple(reversed(self.entries))
        for entry in entries:
            if entry.removed:
                continue
            try:
                entry.remove_exact()
            except Exception as exc:  # retained for audit; never printed
                self.errors.append(f"{entry.kind}:{entry.label}:{type(exc).__name__}:{exc}")
        self.state = "INACTIVE"

    def mark_ready(self) -> None:
        self.token.ready = True
        self.state = "READY"

    def snapshot(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        live = 0
        with self._lock:
            for entry in self.entries:
                if not entry.removed:
                    live += 1
                    counts[entry.kind] = counts.get(entry.kind, 0) + 1
        return {
            "owner_suite_id": self.token.owner_suite_id,
            "owner_uuid": self.token.owner_uuid,
            "generation": self.token.generation,
            "active": self.token.active,
            "ready": self.token.ready,
            "state": self.state,
            "live_entries": live,
            "counts": counts,
            "errors": tuple(self.errors),
            "entries": tuple(
                {
                    "kind": entry.kind,
                    "label": entry.label,
                    "owner_suite_id": entry.owner_suite_id,
                    "owner_uuid": entry.owner_uuid,
                    "generation": entry.generation,
                    "identity_id": id(entry.identity),
                    "callback_identity_id": id(entry.callback_identity) if entry.callback_identity is not None else None,
                    "native_owner_id": id(entry.native_owner) if entry.native_owner is not None else None,
                    "native_remover_id": id(entry.native_remover) if entry.native_remover is not None else None,
                    "removed": entry.removed,
                }
                for entry in self.entries
            ),
        }



def set_fault_injection(stage: str | None) -> None:
    """Testing hook used only by explicit audit scripts."""
    global _FAULT_STAGE
    _FAULT_STAGE = str(stage) if stage else None


def fault_checkpoint(stage: str) -> None:
    if _FAULT_STAGE and _FAULT_STAGE == str(stage):
        raise RuntimeError(f"injected lifecycle fault: {stage}")

def _namespace() -> dict:
    return bpy.app.driver_namespace


def _is_owned_ledger(value: Any) -> bool:
    """Accept the previous module generation's ledger by protocol.

    Blender can reload Python modules without clearing ``driver_namespace``.
    ``isinstance`` therefore rejects the old class object even though it still
    owns exact native removers.  The protocol check is deliberately strict and
    never accepts a foreign ledger merely by name.
    """
    if value is None:
        return False
    token = getattr(value, "token", None)
    return bool(
        getattr(token, "owner_suite_id", None) == SUITE_ID
        and isinstance(getattr(token, "owner_uuid", None), str)
        and callable(getattr(value, "rollback", None))
        and callable(getattr(value, "snapshot", None))
        and hasattr(value, "entries")
    )


def current_ledger() -> ResourceLedger | Any | None:
    try:
        value = _namespace().get(_NAMESPACE_KEY)
    except Exception:
        value = None
    if _is_owned_ledger(value):
        return value
    fallback = _LEDGER_GLOBAL
    if _is_owned_ledger(fallback):
        # The namespace was cleared by a file load; restore the published copy
        # so foreign module generations can still discover this ledger.
        try:
            namespace = _namespace()
            namespace[_NAMESPACE_KEY] = fallback
            namespace[_GENERATION_KEY] = max(
                int(namespace.get(_GENERATION_KEY, 0) or 0),
                int(getattr(fallback.token, "generation", 0) or 0),
                int(_GENERATION_GLOBAL or 0),
            )
        except Exception:
            pass
        return fallback
    return None


def current_token() -> GenerationToken | None:
    ledger = current_ledger()
    return ledger.token if ledger is not None else None


def generation_is_current(token: GenerationToken | None) -> bool:
    if token is None or not token.active:
        return False
    ledger = current_ledger()
    return bool(ledger is not None and ledger.token is token and token.ready)


def generation_is_active(token: GenerationToken | None) -> bool:
    if token is None or not token.active:
        return False
    ledger = current_ledger()
    return bool(ledger is not None and ledger.token is token)


def invalidate_current_generation() -> ResourceLedger | None:
    ledger = current_ledger()
    if ledger is not None:
        ledger.token.active = False
        ledger.token.ready = False
        if ledger.state == "READY":
            ledger.state = "STOPPING"
    return ledger


def begin_registration(registration_instance_uuid: str = "") -> ResourceLedger:
    global _LEDGER_GLOBAL, _GENERATION_GLOBAL
    namespace = _namespace()
    previous = current_ledger()
    prior_generation = max(int(namespace.get(_GENERATION_KEY, 0) or 0), int(_GENERATION_GLOBAL or 0))
    if previous is not None:
        prior_generation = max(prior_generation, int(getattr(previous.token, "generation", 0) or 0))
        previous.rollback()
        if int(previous.snapshot().get("live_entries", 0)):
            raise RuntimeError("RESTART_REQUIRED: previous Smart Shapekey resources could not be removed exactly")
    generation = prior_generation + 1
    token = GenerationToken(SUITE_ID, uuid.uuid4().hex, generation, str(registration_instance_uuid or ""))
    ledger = ResourceLedger(token)
    namespace[_GENERATION_KEY] = generation
    namespace[_NAMESPACE_KEY] = ledger
    _LEDGER_GLOBAL = ledger
    _GENERATION_GLOBAL = generation
    return ledger


def finish_registration(ledger: ResourceLedger) -> None:
    if current_ledger() is not ledger:
        raise RuntimeError("registration ledger lost ownership before READY")
    ledger.mark_ready()


def teardown_current() -> None:
    global _LEDGER_GLOBAL
    ledger = current_ledger()
    if ledger is None:
        return
    ledger.rollback()
    # Retain exact remover identities if Blender refused any teardown. A future
    # enable can retry them or return RESTART_REQUIRED without touching names.
    try:
        if int(ledger.snapshot().get("live_entries", 0)) == 0:
            if _namespace().get(_NAMESPACE_KEY) is ledger:
                _namespace().pop(_NAMESPACE_KEY, None)
            if _LEDGER_GLOBAL is ledger:
                _LEDGER_GLOBAL = None
    except Exception:
        pass


def _previous_owned_entry(kind: str, identity: Any) -> LedgerEntry | None:
    ledger = current_ledger()
    if ledger is None:
        return None
    return ledger.find(kind, identity)


def _class_owned_rna_identity(cls: type) -> Any | None:
    """Return the exact RNA object attached to *this class object*.

    Blender Extensions do not guarantee publication as ``bpy.types.<PythonName>``.
    ``vars(cls)['bl_rna']`` is therefore the authoritative class-owned identity;
    no name lookup is used for registration, rollback or teardown.
    """
    try:
        return vars(cls).get("bl_rna")
    except Exception:
        return None


def register_class(ledger: ResourceLedger, cls: type) -> bool:
    name = str(getattr(cls, "__name__", "") or "")
    existing_rna = _class_owned_rna_identity(cls)
    if existing_rna is not None:
        owned = ledger.find("class", cls)
        if owned is not None and owned.native_owner is existing_rna:
            return False
        raise RuntimeError(f"RESTART_REQUIRED: exact class object is registered but unjournaled: {name}")

    fault_checkpoint(f"before_class:{name}")
    bpy.utils.register_class(cls)
    registered_rna = _class_owned_rna_identity(cls)
    if registered_rna is None:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f"class-owned RNA identity verification failed: {name}")

    def remover() -> None:
        # Remove only this exact class object while its exact class-owned RNA is
        # still present. Never resolve or unregister a class by Python/RNA name.
        if _class_owned_rna_identity(cls) is registered_rna:
            bpy.utils.unregister_class(cls)

    try:
        ledger.record(
            "class",
            cls,
            remover,
            label=name,
            native_owner=registered_rna,
            callback_identity=cls,
            native_remover=bpy.utils.unregister_class,
        )
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_class:{name}")
    return True


def unregister_class_exact(cls: type) -> bool:
    registered_rna = _class_owned_rna_identity(cls)
    if registered_rna is None:
        return False
    bpy.utils.unregister_class(cls)
    return True

def register_rna_property(ledger: ResourceLedger, owner: type, name: str, prop: Any) -> Any:
    name = str(name)
    owner_dict = getattr(owner, "__dict__", {})
    sentinel = object()
    existing = owner_dict.get(name, sentinel)
    if existing is not sentinel:
        if ledger.find("rna", existing) is not None:
            return existing
        # Residue of a previously shipped installation whose unregister was
        # orphaned (driver_namespace is cleared on file load, so its ledger
        # never rolled back). The new generation must survive ANY old
        # version's residue: retire the stale descriptor, then attach fresh.
        try:
            delattr(owner, name)
        except Exception:
            pass
        if getattr(owner, "__dict__", {}).get(name) is not None:
            raise RuntimeError(
                f"RESTART_REQUIRED: stale RNA property could not be retired: {owner.__name__}.{name}"
            )
    fault_checkpoint(f"before_rna:{owner.__name__}.{name}")
    setattr(owner, name, prop)
    descriptor = getattr(owner, "__dict__", {}).get(name)
    if descriptor is None:
        try:
            delattr(owner, name)
        except Exception:
            pass
        raise RuntimeError(f"RNA descriptor verification failed: {owner.__name__}.{name}")

    def remover() -> None:
        current = getattr(owner, "__dict__", {}).get(name)
        if current is descriptor:
            delattr(owner, name)

    try:
        ledger.record("rna", descriptor, remover, label=f"{owner.__name__}.{name}", native_owner=owner, callback_identity=prop, native_remover=delattr)
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_rna:{owner.__name__}.{name}")
    return descriptor


def append_handler(ledger: ResourceLedger, collection: list, callback: Callable, *, label: str) -> bool:
    if any(item is callback for item in tuple(collection)):
        return False
    fault_checkpoint(f"before_handler:{label}")
    collection.append(callback)
    if not any(item is callback for item in tuple(collection)):
        raise RuntimeError(f"handler identity verification failed: {label}")

    def remover() -> None:
        for idx in range(len(collection) - 1, -1, -1):
            if collection[idx] is callback:
                collection.pop(idx)

    try:
        ledger.record("handler", callback, remover, label=label, native_owner=collection, callback_identity=callback, native_remover=collection.remove)
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_handler:{label}")
    return True


def register_timer(ledger: ResourceLedger, callback: Callable, *, first_interval: float = 0.0, persistent: bool = False, label: str = "") -> bool:
    timers = bpy.app.timers
    timer_label = label or getattr(callback, "__name__", "")
    fault_checkpoint(f"before_timer:{timer_label}")
    try:
        if timers.is_registered(callback):
            return False
    except Exception:
        pass
    timers.register(callback, first_interval=max(0.0, float(first_interval)), persistent=bool(persistent))
    try:
        if not timers.is_registered(callback):
            raise RuntimeError(f"timer identity verification failed: {label}")
    except AttributeError:
        pass

    def remover() -> None:
        try:
            if timers.is_registered(callback):
                timers.unregister(callback)
        except Exception:
            pass

    try:
        ledger.record("timer", callback, remover, label=timer_label, native_owner=timers, callback_identity=callback, native_remover=timers.unregister)
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_timer:{timer_label}")
    return True


def subscribe_msgbus(ledger: ResourceLedger, *, key: Any, args: tuple, notify: Callable, options: set[str] | None = None, label: str = "") -> object:
    fault_checkpoint(f"before_msgbus:{label}")
    owner = object()
    bpy.msgbus.subscribe_rna(key=key, owner=owner, args=args, notify=notify, options=options or set())

    def remover() -> None:
        bpy.msgbus.clear_by_owner(owner)

    try:
        ledger.record("msgbus", owner, remover, label=label, native_owner=bpy.msgbus, callback_identity=notify, native_remover=bpy.msgbus.clear_by_owner)
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_msgbus:{label}")
    return owner


def add_draw_handler(ledger: ResourceLedger, space_cls: type, callback: Callable, args: tuple, region_type: str, draw_type: str, *, label: str = "") -> Any:
    fault_checkpoint(f"before_draw_handler:{label}")
    handle = space_cls.draw_handler_add(callback, args, region_type, draw_type)

    def remover() -> None:
        space_cls.draw_handler_remove(handle, region_type)

    try:
        ledger.record("draw_handler", handle, remover, label=label, native_owner=space_cls, callback_identity=callback, native_remover=space_cls.draw_handler_remove)
    except Exception:
        try:
            remover()
        finally:
            raise
    fault_checkpoint(f"after_draw_handler:{label}")
    return handle


def track_socket(ledger: ResourceLedger, sock: Any, close_func: Callable[[], None] | None = None, *, label: str = "") -> Any:
    def remover() -> None:
        if close_func is not None:
            close_func()
            return
        try:
            sock.shutdown(2)
        except Exception:
            pass
        try:
            sock.close()
        except Exception:
            pass

    try:
        ledger.record("socket", sock, remover, label=label, native_owner=sock, callback_identity=close_func, native_remover=close_func or getattr(sock, "close", None))
    except Exception:
        try:
            remover()
        finally:
            raise
    return sock


def track_thread(ledger: ResourceLedger, thread: threading.Thread, stop_join: Callable[[], None], *, label: str = "") -> threading.Thread:
    try:
        ledger.record("thread", thread, stop_join, label=label, native_owner=thread, callback_identity=stop_join, native_remover=stop_join)
    except Exception:
        try:
            stop_join()
        finally:
            raise
    return thread


def resource_snapshot() -> dict[str, Any]:
    ledger = current_ledger()
    return ledger.snapshot() if ledger is not None else {
        "owner_suite_id": SUITE_ID,
        "active": False,
        "ready": False,
        "state": "INACTIVE",
        "live_entries": 0,
        "counts": {},
        "errors": (),
    }
