# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Lazy help popups for Smart Shapekey.

The help text lives in ``help_content.py`` and the popup drawing logic lives
here, so normal N-panel drawing only creates a small operator button.  This
module is imported by ``skm.show_help`` only after the user opens help.

SmartTools common specification (2026-10-17): every explanation is in the
header "?" popup; the panels themselves carry no INFO-icon explanations.
"""

from __future__ import annotations

import unicodedata

try:
    import bpy
except Exception:  # pragma: no cover - Blender-only module
    bpy = None

try:
    from . import translation as _sss_translation
except Exception:  # pragma: no cover - fallback outside Blender
    _sss_translation = None

try:
    from . import icons as _sss_icons
except Exception:  # pragma: no cover - fallback outside Blender
    _sss_icons = None

try:
    from .help_content import HELP_DATA, SECTION_ORDER, SECTION_TITLES
except Exception:  # pragma: no cover - fallback outside the package
    from help_content import HELP_DATA, SECTION_ORDER, SECTION_TITLES  # type: ignore


def _is_ja(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    try:
        view = getattr(getattr(context, 'preferences', None), 'view', None)
        if view is None and bpy is not None:
            view = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'view', None)
        language = str(getattr(view, 'language', '') or '').upper()
        return language.startswith('JA')
    except Exception:
        return False


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_ja(context) else en)


def _suite_icon_name(icon: str | None) -> str | None:
    mapping = {
        'HELP': 'HELP',
        'QUESTION': 'HELP',
        'PREFERENCES': 'SETTINGS',
        'MODIFIER': 'MODIFIER',
        'DRIVER': 'DRIVER',
        'CAMERA_DATA': 'TRACKER',
        'GROUP': 'GROUP',
    }
    return mapping.get(str(icon or '').upper())


def _icon_label(layout, *, text: str = '', icon: str = 'NONE'):
    try:
        icon_name = _suite_icon_name(icon)
        if _sss_icons is not None and icon_name:
            value = int(_sss_icons.icon_value(icon_name) or 0)
            if value:
                return layout.label(text=text, icon_value=value)
    except Exception:
        pass
    try:
        return layout.label(text=text, icon=icon)
    except Exception:
        return layout.label(text=text)


def _localized_pair(pair, context=None) -> str:
    # The help carries its own Japanese; the shared UI catalog maps some short words
    # differently in places, so it is not used here.  (Names quoted in the help are checked against
    # the panel's real display by tests/setup_help18.py.)
    return str(pair[1] if _is_ja(context) else pair[0])


# ---------------------------------------------------------------------------
# Popup geometry
#
# All geometry is computed in unscaled UI units: invoke_popup(width=...) and
# the label font (11 points) are both multiplied by Blender's UI scale factor,
# so wrapping in unscaled units stays valid at every UI scale.  Only the editor
# area width is reported in real pixels; it is divided by the effective scale
# (PreferencesSystem.ui_scale) before it is used.
# ---------------------------------------------------------------------------
_FONT_POINTS = 11.0
_POPUP_TARGET_WIDTH = 1440
_POPUP_MIN_WIDTH = 360
_TWO_COLUMN_MIN_WIDTH = 1100
_POPUP_EDGE_MARGIN = 64
_COLUMN_GAP = 40.0
_COLUMN_CHROME = 46.0
_SINGLE_CHROME = 86.0
_SAFETY = 0.94


def _system_scale(context=None) -> float:
    try:
        system = getattr(getattr(context, 'preferences', None), 'system', None)
        if system is None and bpy is not None:
            system = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'system', None)
        value = float(getattr(system, 'ui_scale', 1.0) or 1.0)
        return max(0.5, min(value, 4.0))
    except Exception:
        return 1.0


def _context_area_width(context=None) -> int | None:
    for owner_name in ('area', 'window'):
        try:
            owner = getattr(context, owner_name, None)
            value = int(getattr(owner, 'width', 0) or 0)
            if value > 0:
                return value
        except Exception:
            pass
    return None


def _target_popup_width(context=None, area_width: int | None = None) -> int:
    width = float(_POPUP_TARGET_WIDTH)
    if area_width is None:
        area_width = _context_area_width(context)
    if area_width:
        width = min(width, float(area_width) / _system_scale(context) - _POPUP_EDGE_MARGIN)
    return int(max(_POPUP_MIN_WIDTH, width))


def column_layout(context=None, area_width: int | None = None):
    """Return (popup_width, column_count, text_width) in unscaled units."""
    width = _target_popup_width(context, area_width)
    columns = 2 if width >= _TWO_COLUMN_MIN_WIDTH else 1
    if columns == 2:
        text_width = (width - _COLUMN_GAP) / 2.0 - _COLUMN_CHROME
    else:
        text_width = width - _SINGLE_CHROME
    return width, columns, max(160.0, text_width * _SAFETY)


_BREAK_AFTER_CHARS = set(' \t、。,.，．:：;；!！?？/／・-ー–—)）]］』」')
_BREAK_BEFORE_CHARS = set('([{（［「『')


def _estimated_text_width_px(text: str) -> float:
    """Fallback width estimator used only outside Blender or when BLF is unavailable."""
    width = 0.0
    for ch in str(text or ''):
        if ch == '\t':
            width += 24.0
        elif unicodedata.combining(ch):
            continue
        elif ch.isspace():
            width += 3.8
        elif unicodedata.east_asian_width(ch) in {'F', 'W'}:
            width += 11.2
        elif ch in "ilI.,:;|!'`":
            width += 3.4
        elif ch in 'MW@#%&':
            width += 9.2
        else:
            width += 6.5
    return width


def text_width_px(text: str) -> float:
    """Rendered text width in unscaled units (BLF when available)."""
    text = str(text or '')
    if not text:
        return 0.0
    try:
        import blf  # Blender-only module
        blf.size(0, _FONT_POINTS)
        measured = float(blf.dimensions(0, text)[0])
        if measured > 0.0:
            return max(measured, _estimated_text_width_px(text) * 0.85)
    except Exception:
        pass
    return _estimated_text_width_px(text)


def _longest_prefix_that_fits(text: str, max_px: float) -> int:
    if text_width_px(text) <= max_px:
        return len(text)
    lo, hi, best = 1, len(text), 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if text_width_px(text[:mid]) <= max_px:
            best = mid
            lo = mid + 1
        else:
            hi = mid - 1
    return max(1, best)


def _last_preferred_break(text: str, limit: int) -> int:
    limit = max(0, min(int(limit), len(text)))
    for index in range(limit - 1, -1, -1):
        ch = text[index]
        if ch.isspace() or ch in _BREAK_AFTER_CHARS:
            return index + 1
        if index > 0 and ch in _BREAK_BEFORE_CHARS:
            return index
    return -1


def wrap_text(text: str, first_max_px: float, next_max_px: float) -> list[str]:
    remaining = str(text or '').strip()
    chunks: list[str] = []
    while remaining:
        limit = max(48.0, float(first_max_px if not chunks else next_max_px))
        if text_width_px(remaining) <= limit:
            chunks.append(remaining)
            break
        fit = _longest_prefix_that_fits(remaining, limit)
        break_at = _last_preferred_break(remaining, fit)
        if break_at <= 0 or break_at < max(1, fit // 3):
            break_at = fit
        line = remaining[:break_at].strip()
        if not line:
            break_at = max(1, fit)
            line = remaining[:break_at].strip()
        chunks.append(line)
        remaining = remaining[break_at:].lstrip()
    return chunks


def wrapped_item_lines(text: str, prefix: str, max_px: float) -> list[str]:
    indent = '    ' if prefix else ''
    first = max_px - text_width_px(prefix)
    rest = max_px - text_width_px(indent)
    lines = wrap_text(text, first, rest)
    if not lines:
        return []
    return [prefix + lines[0]] + [indent + line for line in lines[1:]]


_UNWANTED_HELP_LOAD_NOTE_PARTS = (
    ('ヘルプ' + '本文', 'このボタン'),
    ('Blender' + '起動時', '通常の' + 'Nパネル', '追加' + '負荷'),
    ('Blender ' + '起動時', '通常の N パネル', '追加' + '負荷'),
    ('help ' + 'text', 'only when', 'button'),
    ('Help ' + 'text', 'only when', 'button'),
    ('full ' + 'help module', 'only after', 'button'),
    ('loaded ' + 'only', 'button', 'clicked'),
)


def _is_unwanted_help_load_note(value) -> bool:
    text = str(value or '')
    compact = text.replace(' ', '').replace('　', '')
    for parts in _UNWANTED_HELP_LOAD_NOTE_PARTS:
        if all(part in text or part.replace(' ', '').replace('　', '') in compact for part in parts):
            return True
    return False


_SECTION_ICONS = {
    'purpose': 'QUESTION',
    'prepare': 'CHECKBOX_HLT',
    'steps': 'LINENUMBERS_ON',
    'settings': 'PREFERENCES',
    'verify': 'CHECKMARK',
    'undo': 'LOOP_BACK',
}


def section_items(tool_id: str, section: str, japanese: bool) -> list[str]:
    data = HELP_DATA.get(str(tool_id or '')) or {}
    pair = data.get(section) or ((), ())
    return [line for line in (pair[1] if japanese else pair[0]) if not _is_unwanted_help_load_note(line)]


def section_lines(tool_id: str, section: str, japanese: bool, max_px: float) -> list[str]:
    """Wrapped display lines of one help section (shared by draw and tests)."""
    out: list[str] = []
    for index, item in enumerate(section_items(tool_id, section, japanese), start=1):
        prefix = f'{index}. ' if section == 'steps' else '• '
        out.extend(wrapped_item_lines(item, prefix, max_px))
    return out


def column_split(row_counts) -> int:
    """Index that splits the ordered sections into two columns with the lowest tallest column.

    Reading order is kept: the left column holds sections [0:k] and the right [k:].
    """
    counts = [int(c) for c in row_counts]
    best_k, best_h = max(1, len(counts) // 2), None
    for k in range(1, len(counts)):
        h = max(sum(counts[:k]), sum(counts[k:]))
        if best_h is None or h < best_h:
            best_k, best_h = k, h
    return best_k


def _draw_section(layout, tool_id: str, section: str, japanese: bool, max_px: float, lines=None) -> None:
    if lines is None:
        lines = section_lines(tool_id, section, japanese, max_px)
    if not lines:
        return
    box = layout.box()
    title = SECTION_TITLES.get(section, (section, section))
    _icon_label(box, text=title[1] if japanese else title[0], icon=_SECTION_ICONS.get(section, 'NONE'))
    col = box.column(align=True)
    for line in lines:
        col.label(text=line)


def get_title(tool_id: str, context=None) -> str:
    data = HELP_DATA.get(str(tool_id or ''))
    if not data:
        return _ui_text('Help', 'ヘルプ', context)
    return _localized_pair(data['title'], context)


def popup_width(tool_id: str, context=None) -> int:
    del tool_id
    return column_layout(context)[0]


def draw_help_popup(layout, context, tool_id: str) -> None:
    data = HELP_DATA.get(str(tool_id or ''))
    if not data:
        layout.label(text=_ui_text('Help content is not available for this tool.', 'このツールのヘルプ内容を利用できません。', context), icon='ERROR')
        return

    layout.use_property_split = False
    layout.use_property_decorate = False
    japanese = _is_ja(context)
    _width, columns, max_px = column_layout(context)

    header = layout.box()
    _icon_label(header, text=_localized_pair(data['title'], context), icon='QUESTION')

    wrapped = [(section, section_lines(tool_id, section, japanese, max_px)) for section in SECTION_ORDER]
    if columns == 2:
        k = column_split([1 + len(lines) for _section, lines in wrapped])
        split = layout.split(factor=0.5)
        left = split.column()
        right = split.column()
        for section, lines in wrapped[:k]:
            _draw_section(left, tool_id, section, japanese, max_px, lines)
        for section, lines in wrapped[k:]:
            _draw_section(right, tool_id, section, japanese, max_px, lines)
    else:
        for section, lines in wrapped:
            _draw_section(layout, tool_id, section, japanese, max_px, lines)
