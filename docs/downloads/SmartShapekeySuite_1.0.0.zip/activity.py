# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Exact, generation-scoped leases for optional Smart Shapekey activity.

All optional timers, handlers, msgbus owners, draw handles, sockets, workers and
I/O resources are mirrored into the authoritative lifecycle ledger immediately
after native registration.  This lets a reload remove the previous generation by
exact identity even when the old Python module objects have been replaced.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable
import threading
import time
import uuid

import bpy

from . import lifecycle

SUITE_ID = "smart_shapekey_suite"
_ACTIVITY_GENERATION_KEY = "SMART_SHAPEKEY_SUITE_ACTIVITY_GENERATION_V1420"


@dataclass(slots=True)
class ActivityToken:
    generation: int
    owner_uuid: str = field(default_factory=lambda: uuid.uuid4().hex)
    active: bool = True


@dataclass(slots=True)
class ActivityEntry:
    kind: str
    identity: Any
    remover: Callable[[], Any]
    callback_identity: Any
    native_owner: Any
    label: str
    lifecycle_entry: Any = None
    removed: bool = False

    def mark_removed(self) -> None:
        self.removed = True
        central = self.lifecycle_entry
        if central is not None:
            try:
                central.removed = True
            except Exception:
                pass

    def remove(self) -> None:
        if self.removed:
            return
        result = self.remover()
        if result is False:
            raise RuntimeError(f"resource refused teardown: {self.kind}:{self.label}")
        self.mark_removed()


class ActivityLease:
    __slots__ = ("feature", "token", "lifecycle_ledger", "entries", "state", "errors", "created_monotonic", "_lock")

    def __init__(self, feature: str, token: ActivityToken, lifecycle_ledger: Any):
        self.feature = str(feature)
        self.token = token
        self.lifecycle_ledger = lifecycle_ledger
        self.entries: list[ActivityEntry] = []
        self.state = "ACTIVE"
        self.errors: list[str] = []
        self.created_monotonic = time.monotonic()
        self._lock = threading.RLock()

    def record(
        self,
        kind: str,
        identity: Any,
        remover: Callable[[], Any],
        *,
        callback_identity: Any = None,
        native_owner: Any = None,
        label: str = "",
    ) -> Any:
        if identity is None:
            raise RuntimeError(f"null activity identity: {self.feature}:{kind}:{label}")
        if not callable(remover):
            raise RuntimeError(f"non-callable activity remover: {self.feature}:{kind}:{label}")
        entry = ActivityEntry(kind, identity, remover, callback_identity, native_owner, str(label))
        central = self.lifecycle_ledger
        try:
            with self._lock:
                central_token = getattr(central, "token", None)
                if (
                    self.state != "ACTIVE"
                    or not token_is_current(self.token)
                    or central is None
                    or not bool(getattr(central_token, "active", False))
                    or str(getattr(central, "state", "")) not in {"REGISTERING", "READY"}
                ):
                    raise RuntimeError(f"inactive activity generation: {self.feature}:{kind}:{label}")
                record_entry = getattr(central, "record_entry", None)
                if not callable(record_entry):
                    raise RuntimeError(f"lifecycle ledger cannot journal activity: {self.feature}:{kind}:{label}")
                entry.lifecycle_entry = record_entry(
                    kind,
                    identity,
                    remover,
                    label=f"activity:{self.feature}:{label}",
                    native_owner=native_owner,
                    callback_identity=callback_identity,
                    native_remover=remover,
                )
                self.entries.append(entry)
                return identity
        except Exception:
            # The native resource was created before it could be journaled. Close
            # that exact resource immediately and never leave it alive by name.
            try:
                remover()
            finally:
                raise

    def mark_native_finished(self, identity: Any) -> None:
        with self._lock:
            for entry in self.entries:
                if not entry.removed and entry.identity is identity:
                    entry.mark_removed()
                    break
            if self.entries and all(entry.removed for entry in self.entries):
                self.state = "INACTIVE"

    def callback_is_active(self) -> bool:
        """Return whether callbacks may still enter this exact lease."""
        with self._lock:
            return bool(self.state == "ACTIVE" and token_is_current(self.token))

    def teardown(self) -> bool:
        with self._lock:
            if self.state == "INACTIVE":
                return True
            self.state = "STOPPING"
            entries = tuple(reversed(self.entries))
        all_removed = True
        for entry in entries:
            if entry.removed:
                continue
            try:
                entry.remove()
            except Exception as exc:
                all_removed = False
                message = f"{entry.kind}:{entry.label}:{type(exc).__name__}:{exc}"
                if message not in self.errors:
                    self.errors.append(message)
        if all_removed:
            self.state = "INACTIVE"
        return all_removed

    def record_callback_error(self, kind: str, label: str, exc: BaseException) -> None:
        message = f"{kind}:{label}:{type(exc).__name__}:{exc}"[:2048]
        with self._lock:
            if message not in self.errors and len(self.errors) < 32:
                self.errors.append(message)

    def snapshot(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        live = 0
        with self._lock:
            for entry in self.entries:
                if not entry.removed:
                    live += 1
                    counts[entry.kind] = counts.get(entry.kind, 0) + 1
        return {
            "feature": self.feature,
            "owner_suite_id": SUITE_ID,
            "owner_uuid": self.token.owner_uuid,
            "generation": self.token.generation,
            "state": self.state,
            "live_entries": live,
            "counts": counts,
            "errors": tuple(self.errors),
        }


_LOCK = threading.RLock()
_GENERATION = 0
_TOKEN = ActivityToken(0, active=False)
_LEASES: dict[str, ActivityLease] = {}


def current_token() -> ActivityToken:
    return _TOKEN


def token_is_current(token: ActivityToken | None) -> bool:
    with _LOCK:
        return bool(token is not None and token is _TOKEN and token.active)


def new_generation(*, teardown_existing: bool = True) -> ActivityToken:
    global _GENERATION, _TOKEN
    if teardown_existing and not teardown_all():
        raise RuntimeError("Smart Shapekey activity teardown did not complete")
    with _LOCK:
        _TOKEN.active = False
        try:
            namespace = bpy.app.driver_namespace
            persisted = int(namespace.get(_ACTIVITY_GENERATION_KEY, 0) or 0)
        except Exception:
            namespace = None
            persisted = 0
        _GENERATION = max(_GENERATION, persisted) + 1
        if namespace is not None:
            namespace[_ACTIVITY_GENERATION_KEY] = _GENERATION
        _TOKEN = ActivityToken(_GENERATION)
        return _TOKEN


def invalidate_generation() -> ActivityToken:
    with _LOCK:
        _TOKEN.active = False
        return _TOKEN


def new_lease(feature: str, *, replace: bool = True) -> ActivityLease:
    feature = str(feature)
    if replace and not teardown_feature(feature):
        raise RuntimeError(f"previous activity lease could not stop: {feature}")
    token = current_token()
    if not token.active:
        token = new_generation(teardown_existing=False)
    central = lifecycle.current_ledger()
    if central is None or not lifecycle.generation_is_active(getattr(central, "token", None)):
        raise RuntimeError(f"no active lifecycle generation for activity lease: {feature}")
    lease = ActivityLease(feature, token, central)
    with _LOCK:
        _LEASES[feature] = lease
    return lease


def get_lease(feature: str) -> ActivityLease | None:
    with _LOCK:
        return _LEASES.get(str(feature))


def _drop_inactive(feature: str, lease: ActivityLease) -> None:
    if lease.state != "INACTIVE":
        return
    with _LOCK:
        if _LEASES.get(feature) is lease:
            _LEASES.pop(feature, None)


def mark_native_finished(feature: str, identity: Any) -> None:
    feature = str(feature)
    with _LOCK:
        lease = _LEASES.get(feature)
    if lease is None:
        return
    lease.mark_native_finished(identity)
    _drop_inactive(feature, lease)


def teardown_feature(feature: str) -> bool:
    feature = str(feature)
    with _LOCK:
        lease = _LEASES.get(feature)
    if lease is None:
        return True
    ok = lease.teardown()
    if ok:
        _drop_inactive(feature, lease)
    return ok


def teardown_all() -> bool:
    with _LOCK:
        leases = tuple(_LEASES.items())
    ok = True
    for feature, lease in reversed(leases):
        if not lease.teardown():
            ok = False
        else:
            _drop_inactive(feature, lease)
    return ok




def _handle_callback_failure(lease: ActivityLease, label: str, exc: BaseException) -> None:
    """Contain callback exceptions and synchronously retire the feature lease.

    Blender prints uncaught timer/handler/draw/msgbus exceptions to the console on
    every invocation.  Recording one bounded diagnostic and removing the exact
    lease resources prevents repeated Traceback/WARNING output.
    """
    message = f"callback:{label}:{type(exc).__name__}:{exc}"[:2048]
    with lease._lock:
        if message not in lease.errors:
            if len(lease.errors) >= 64:
                lease.errors.pop(0)
            lease.errors.append(message)
    try:
        teardown_feature(lease.feature)
    except Exception:
        pass


def add_timer(
    lease: ActivityLease,
    callback: Callable,
    *,
    first_interval: float = 0.0,
    persistent: bool = False,
    label: str = "",
) -> Callable:
    token = lease.token
    feature = lease.feature

    def generation_callback():
        if not lease.callback_is_active():
            mark_native_finished(feature, generation_callback)
            return None
        try:
            result = callback()
        except Exception as exc:
            _handle_callback_failure(lease, label or getattr(callback, "__name__", "timer"), exc)
            mark_native_finished(feature, generation_callback)
            return None
        if result is None:
            mark_native_finished(feature, generation_callback)
        return result

    generation_callback.__name__ = f"{getattr(callback, '__name__', 'timer')}_g{token.generation}"
    bpy.app.timers.register(
        generation_callback,
        first_interval=max(0.0, float(first_interval)),
        persistent=bool(persistent),
    )

    def remover() -> None:
        try:
            if bpy.app.timers.is_registered(generation_callback):
                bpy.app.timers.unregister(generation_callback)
        except Exception:
            # If Blender reports the one-shot timer already finished, the exact
            # identity is no longer registered and teardown is complete.
            pass

    lease.record(
        "timer",
        generation_callback,
        remover,
        callback_identity=callback,
        native_owner=bpy.app.timers,
        label=label,
    )
    return generation_callback


def add_handler(lease: ActivityLease, collection: list, callback: Callable, *, label: str = "") -> Callable:
    token = lease.token

    def generation_callback(*args, **kwargs):
        if not lease.callback_is_active():
            return None
        try:
            return callback(*args, **kwargs)
        except Exception as exc:
            _handle_callback_failure(lease, label or getattr(callback, "__name__", "handler"), exc)
            return None

    generation_callback.__name__ = f"{getattr(callback, '__name__', 'handler')}_g{token.generation}"
    collection.append(generation_callback)

    def remover() -> None:
        for index in range(len(collection) - 1, -1, -1):
            if collection[index] is generation_callback:
                collection.pop(index)

    lease.record(
        "handler",
        generation_callback,
        remover,
        callback_identity=callback,
        native_owner=collection,
        label=label,
    )
    return generation_callback


def add_draw_handler(
    lease: ActivityLease,
    space_cls: type,
    callback: Callable,
    args: tuple,
    region_type: str,
    draw_type: str,
    *,
    label: str = "",
) -> Any:
    token = lease.token

    def generation_callback(*cb_args):
        if not lease.callback_is_active():
            return None
        try:
            return callback(*cb_args)
        except Exception as exc:
            _handle_callback_failure(lease, label or getattr(callback, "__name__", "draw"), exc)
            return None

    handle = space_cls.draw_handler_add(generation_callback, args, region_type, draw_type)

    def remover() -> None:
        try:
            space_cls.draw_handler_remove(handle, region_type)
        except Exception:
            # Exact handles can already have been invalidated by Blender window
            # teardown. No name-based fallback is attempted.
            pass

    lease.record(
        "draw_handler",
        handle,
        remover,
        callback_identity=generation_callback,
        native_owner=space_cls,
        label=label,
    )
    return handle


def add_msgbus(
    lease: ActivityLease,
    *,
    key: Any,
    args: tuple,
    notify: Callable,
    options: set[str] | None = None,
    label: str = "",
) -> object:
    token = lease.token
    owner = object()

    def generation_notify(*cb_args):
        if not lease.callback_is_active():
            return None
        try:
            return notify(*cb_args)
        except Exception as exc:
            _handle_callback_failure(lease, label or getattr(notify, "__name__", "msgbus"), exc)
            return None

    bpy.msgbus.subscribe_rna(
        key=key,
        owner=owner,
        args=args,
        notify=generation_notify,
        options=options or set(),
    )
    lease.record(
        "msgbus",
        owner,
        lambda: bpy.msgbus.clear_by_owner(owner),
        callback_identity=generation_notify,
        native_owner=bpy.msgbus,
        label=label,
    )
    return owner


def track_socket(lease: ActivityLease, sock: Any, close_func: Callable[[], Any], *, label: str = "") -> Any:
    return lease.record(
        "socket",
        sock,
        close_func,
        callback_identity=close_func,
        native_owner=sock,
        label=label,
    )


def track_thread(lease: ActivityLease, thread: threading.Thread, stop_join: Callable[[], Any], *, label: str = "") -> threading.Thread:
    return lease.record(
        "thread",
        thread,
        stop_join,
        callback_identity=stop_join,
        native_owner=thread,
        label=label,
    )


def track_resource(lease: ActivityLease, kind: str, identity: Any, remover: Callable[[], Any], *, label: str = "") -> Any:
    return lease.record(
        kind,
        identity,
        remover,
        callback_identity=remover,
        native_owner=identity,
        label=label,
    )


def resource_snapshot() -> dict[str, Any]:
    with _LOCK:
        leases = tuple(_LEASES.values())
        token = _TOKEN
    snapshots = [lease.snapshot() for lease in leases]
    totals: dict[str, int] = {}
    live = 0
    for item in snapshots:
        live += int(item["live_entries"])
        for kind, count in item["counts"].items():
            totals[kind] = totals.get(kind, 0) + int(count)
    return {
        "owner_suite_id": SUITE_ID,
        "generation": token.generation,
        "generation_active": token.active,
        "live_entries": live,
        "counts": totals,
        "leases": snapshots,
    }
