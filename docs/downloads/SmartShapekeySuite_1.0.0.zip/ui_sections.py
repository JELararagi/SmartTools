# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import re

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore


def _clean_key(key: object) -> str:
    text = str(key or '').strip()
    text = re.sub(r'[^A-Za-z0-9_.:-]+', '_', text)
    return text or 'section'


def section_idprop(key: object) -> str:
    return '_smart_shapekey_ui_section_' + _clean_key(key)


def _runtime_module():
    try:
        from . import runtime
        return runtime
    except Exception:
        return None


def section_state_get(context, key: object, default: bool = False) -> bool:
    cleaned = _clean_key(key)
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is None and bpy is not None:
            wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None:
            prop = section_idprop(cleaned)
            if prop in wm:
                return bool(wm[prop])
    except Exception:
        pass
    try:
        runtime = _runtime_module()
        getter = getattr(runtime, 'get_ui_section_state', None) if runtime is not None else None
        if callable(getter):
            return bool(getter(cleaned, default))
    except Exception:
        pass
    return bool(default)



def section_state_set(context, key: object, value: bool) -> bool:
    cleaned = _clean_key(key)
    saved = False
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is None and bpy is not None:
            wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None:
            wm[section_idprop(cleaned)] = bool(value)
            saved = True
    except Exception:
        saved = False
    try:
        runtime = _runtime_module()
        setter = getattr(runtime, 'save_ui_section_state', None) if runtime is not None else None
        if callable(setter):
            setter(cleaned, bool(value))
            saved = True
    except Exception:
        pass
    return bool(saved)



def section_state_toggle(context, key: object, default: bool = False) -> bool:
    current = section_state_get(context, key, default)
    new_value = not current
    section_state_set(context, key, new_value)
    return new_value


def stacked_prop(layout, data, prop_name: str, *, text: str = '', search=None):
    """The name above its field, for rows whose name does not fit beside the field at the default width."""
    column = layout.column(align=True)
    column.label(text=text or data.bl_rna.properties[prop_name].name)
    if search is not None:
        # A name typed here need not exist yet, so a name that is not in the list is not an error.
        column.prop_search(data, prop_name, search[0], search[1], text='', results_are_suggestions=True)
    else:
        column.prop(data, prop_name, text='')
    return column


def draw_help_button(layout, tool_id: object):
    tool = str(tool_id or '').strip()
    if not tool:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION', emboss=True)
        op.tool_id = tool
        return op
    except Exception:
        return None


def draw_collapsible_section(
    layout,
    context,
    key: object,
    label: str,
    *,
    icon: str = 'NONE',
    help_id: object = '',
    default: bool = False,
    split_factor: float = 0.90,
    body_property_split: bool = False,
    align_body: bool = False,
):
    """Draw a Smart Modeling-style grouped collapsible section.

    Header order: disclosure button, icon+section-name toggle button, compact
    standard QUESTION help button at the far right.  The returned body never
    repeats the section name.
    """
    section_key = _clean_key(key)
    section_label = str(label or section_key)
    expanded = section_state_get(context, section_key, default)

    box = layout.box()
    try:
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        pass

    header = box.row(align=True)
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass

    try:
        split = header.split(factor=float(split_factor), align=True)
    except Exception:
        split = header

    try:
        left = split.row(align=True)
    except Exception:
        left = split

    try:
        op = left.operator(
            'skm.toggle_ui_section',
            text='',
            icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
            emboss=True,
            depress=bool(expanded),
        )
        op.section_key = section_key
        op.label = section_label
        op.default_state = bool(default)
    except Exception:
        try:
            left.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
        except Exception:
            pass

    safe_icon = str(icon or 'NONE')
    try:
        op = left.operator(
            'skm.toggle_ui_section',
            text=section_label,
            icon=safe_icon,
            emboss=False,
            depress=bool(expanded),
        )
        op.section_key = section_key
        op.label = section_label
        op.default_state = bool(default)
    except TypeError:
        try:
            op = left.operator('skm.toggle_ui_section', text=section_label, icon=safe_icon, emboss=False)
            op.section_key = section_key
            op.label = section_label
            op.default_state = bool(default)
        except Exception:
            try:
                left.label(text=section_label, icon=safe_icon)
            except Exception:
                left.label(text=section_label)
    except Exception:
        try:
            left.label(text=section_label, icon=safe_icon)
        except Exception:
            left.label(text=section_label)

    try:
        right = split.row(align=True)
    except Exception:
        right = header.row(align=True)
    try:
        right.alignment = 'RIGHT'
    except Exception:
        pass
    draw_help_button(right, help_id)

    if not expanded:
        return None

    body = box.column(align=bool(align_body))
    try:
        body.use_property_split = bool(body_property_split)
        body.use_property_decorate = False
    except Exception:
        pass
    return body

def draw_child_section(
    layout,
    context,
    key: object,
    label: str,
    *,
    icon: str = 'NONE',
    help_id: object = '',
    default: bool = False,
    body_property_split: bool = False,
    align_body: bool = False,
):
    """Draw a child or grandchild section only with ``UILayout.panel()``.

    The native panel owns the thin disclosure chevron and stores its expanded
    state in the current UI region under a stable idname.  No operator row,
    disclosure-icon imitation, WindowManager ID property, or non-native child
    header fallback is used.  ``default`` maps directly to
    ``default_closed=not default`` on first display.
    """
    del context, align_body
    section_key = _clean_key(key)
    section_label = str(label or section_key)
    safe_icon = str(icon or 'NONE')
    panel_id = 'smart_shapekey_child_' + section_key

    try:
        header, body = layout.panel(panel_id, default_closed=(not bool(default)))
    except TypeError:
        # Compatibility with test doubles that expose the native panel method
        # without Blender's default_closed keyword.  This remains a native
        # UILayout.panel() path and never substitutes a custom disclosure row.
        try:
            header, body = layout.panel(panel_id)
        except Exception:
            return None
    except Exception:
        return None

    if header is not None:
        try:
            if safe_icon and safe_icon != 'NONE':
                header.label(text=section_label, icon=safe_icon)
            else:
                header.label(text=section_label)
        except Exception:
            try:
                header.label(text=section_label)
            except Exception:
                pass

        if help_id:
            try:
                right = header.row(align=True)
                right.alignment = 'RIGHT'
                draw_help_button(right, help_id)
            except Exception:
                try:
                    draw_help_button(header, help_id)
                except Exception:
                    pass

    if body is None:
        return None
    try:
        body.use_property_split = bool(body_property_split)
        body.use_property_decorate = False
    except Exception:
        pass
    return body
