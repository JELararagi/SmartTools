# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
CONTRACT_VERSION = 3
EXTENSION_ID = 'smart_shapekey_suite'
CONFIG_FOLDER = 'Smart_Shapekey_Suite'
CONFIG_FILE = 'Smart_Shapekey_Suite.json'
STATE_SAVE_PATH = 'window_manager.skm_suite_settings.n_panel_state_save_enabled'
SECTION_OPEN_PATH = 'window_manager.skm_suite_settings.show_always_on_toggles'
RUNTIME_TOGGLE_PATHS = (
    'window_manager.skm_suite_settings.always_axis_ui_enabled',
    'window_manager.skm_suite_settings.always_frame_sync_enabled',
    'window_manager.skm_suite_settings.always_external_tracker_enabled',
    'window_manager.skm_suite_settings.always_face_tracker_enabled',
    'window_manager.skm_suite_settings.always_face_tracker_hud_enabled',
)
# Exact activations excluded from automated ON tests because they access an
# external UDP endpoint or physical webcam.  Every other runtime toggle,
# including the face-tracker HUD by itself, remains safe for ON -> OFF probing.
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = (
    'window_manager.skm_suite_settings.always_external_tracker_enabled',
    'window_manager.skm_suite_settings.always_face_tracker_enabled',
)
ROOT_PANEL_IDS = (
    'SKM_PT_view3d_root',
    'SKM_PT_image_editor_root',
    'SKM_PT_node_editor_root',
    'SKM_PT_sequence_editor_root',
    'SKM_PT_clip_editor_root',
    'SKM_PT_dopesheet_editor_root',
    'SKM_PT_graph_editor_root',
    'SKM_PT_nla_editor_root',
    'SKM_PT_text_editor_root',
    'SKM_PT_file_browser_root',
    'SKM_PT_spreadsheet_root',
    'SKM_PT_asset_browser_root',
)
ROOT_PANEL_LOGICAL_EDITOR_KEYS = {
    'SKM_PT_view3d_root': ('VIEW_3D',),
    'SKM_PT_image_editor_root': ('IMAGE_EDITOR', 'UV_EDITOR'),
    'SKM_PT_node_editor_root': ('SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR'),
    'SKM_PT_sequence_editor_root': ('VIDEO_SEQUENCER',),
    'SKM_PT_clip_editor_root': ('MOVIE_CLIP_EDITOR',),
    'SKM_PT_dopesheet_editor_root': ('DOPE_SHEET',),
    'SKM_PT_graph_editor_root': ('GRAPH_EDITOR', 'DRIVERS'),
    'SKM_PT_nla_editor_root': ('NLA_EDITOR',),
    'SKM_PT_text_editor_root': ('TEXT_EDITOR',),
    'SKM_PT_file_browser_root': ('FILE_BROWSER',),
    'SKM_PT_asset_browser_root': ('ASSET_BROWSER',),
    'SKM_PT_spreadsheet_root': ('SPREADSHEET',),
}
ROOT_PANEL_REGIONS = {
    panel_id: 'TOOL_PROPS' if panel_id == 'SKM_PT_asset_browser_root' else 'UI'
    for panel_id in ROOT_PANEL_IDS
}
PERSISTENCE_ROOTS = (
    'window_manager.skm_suite_settings',
    'object.skm_uv_map_name',
    'object.skm_keep_map_shapes',
    'object.skm_mirror_axis',
    'object.skm_mirror_center_x',
    'object.skm_mirror_center_y',
    'object.skm_mirror_center_z',
    'object.skm_mirror_epsilon',
    'object.skm_index',
    'scene.shape_xy_tracker_port',
    'scene.tracker_cam_index',
    'scene.driver_helper_props',
    'scene.shape_xy_allow_drag',
    # Serialized per stable object name; the corresponding active index is
    # included in the same shape-axis object payload.
    'object.shape_xy_groups',
    'object.shape_xy_group_index',
    'scene.shape_xy_presets',
    'scene.shape_xy_preset_index',
    'scene.tracker_targets',
    'scene.tracker_target_index',
)
EXCLUDED_TRANSIENT_PATHS = (
    'window_manager.skm_suite_settings.name',
    'scene.driver_helper_props.name',
    'object.skm__suppress_apply',
    # Per-object artistic shape-map data belongs to the .blend, not global UI state.
    'object.skm_maps',
)
# Driver Helper values are children of the already-contracted
# ``scene.driver_helper_props`` PointerProperty, not direct Scene RNA.
# Consequently there are no additional lazy RNA roots here.
PERSISTED_DYNAMIC_RNA_PATTERNS = ()

# The draggable Axis HUD geometry is held by the feature's runtime state dict,
# not Blender RNA.  runtime._collect_axis_hud_state() and
# runtime._apply_axis_hud_state() serialize these keys in the canonical suite
# JSON alongside the RNA-backed N-panel settings.
PERSISTED_INTERNAL_STATE_KEYS = (
    'axis_hud_x',
    'axis_hud_y',
    'axis_hud_size',
)
