# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None

try:
    from ... import icons as _sss_icons
except Exception:
    _sss_icons = None
try:
    from ... import ui_sections as _sss_ui_sections
except Exception:
    _sss_ui_sections = None



def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, 'preferences', None), 'view', None)
    if view is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
    language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT').upper()
    return language.startswith('JA')


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _safe_view3d_context(context) -> bool:
    area = getattr(context, 'area', None)
    return area is None or getattr(area, 'type', None) == 'VIEW_3D'


def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None


def _safe_active_mesh(context, *, require_selected: bool = True):
    obj = None
    for attr in ('object', 'active_object'):
        try:
            candidate = getattr(context, attr, None)
        except Exception:
            candidate = None
        if candidate is not None:
            obj = candidate
            break
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        if getattr(obj, 'data', None) is None:
            return None
    except Exception:
        return None
    try:
        if getattr(bpy.data.objects, 'get', None) and bpy.data.objects.get(getattr(obj, 'name', '')) is not obj:
            return None
    except Exception:
        return None
    if require_selected:
        try:
            selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
            if selected_objects and obj not in selected_objects:
                return None
        except Exception:
            pass
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode in {'', 'OBJECT'} and hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
    return obj


def _safe_mesh_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None and _safe_active_mesh(context, require_selected=True) is not None


def _safe_scene_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None




def _save_panel_settings(context=None):
    try:
        from ... import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(context if context is not None else getattr(bpy, 'context', None))
    except Exception:
        pass


def _persistent_default(key: str, default):
    try:
        from ... import runtime
        getter = getattr(runtime, 'get_persistent_setting', None)
        if callable(getter):
            return getter(key, default)
    except Exception:
        pass
    return default


def _tracker_target_update(self, context):
    _save_panel_settings(context)


_TRACKER_TARGET_INDEX_IDPROP = '_smart_shapekey_tracker_target_index'


def _tracker_target_get(scene):
    """Return the durable global index for newly created Scene datablocks."""
    try:
        if _TRACKER_TARGET_INDEX_IDPROP in scene:
            return int(scene[_TRACKER_TARGET_INDEX_IDPROP])
    except Exception:
        pass
    try:
        return int(_persistent_default('tracker_target_index', -1))
    except Exception:
        return -1


def _tracker_target_set(scene, value):
    try:
        scene[_TRACKER_TARGET_INDEX_IDPROP] = int(value)
    except Exception:
        pass


def _icon_op(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.operator(layout, operator_id, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=fallback, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def _icon_label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE'):
    try:
        if _sss_icons is not None:
            return _sss_icons.label(layout, text=text, icon_name=icon_name, fallback=fallback)
    except Exception:
        pass
    try:
        return layout.label(text=text, icon=fallback)
    except Exception:
        return layout.label(text=text)


def _large_icon_row(layout, *, scale: float = 1.30):
    row = layout.row(align=True)
    try:
        row.scale_y = max(float(getattr(row, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass
    return row


def _large_icon_column(layout, *, scale: float = 1.30):
    col = layout.column(align=True)
    try:
        col.scale_y = max(float(getattr(col, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass
    return col


def _draw_help_button(layout, tool_id: str, context=None, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Selector-style help button.

    The button uses Blender's built-in QUESTION icon and an empty label.
    """
    del context, icon, text
    if not tool_id:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION')
        op.tool_id = str(tool_id or '')
        return op
    except Exception:
        return None


def _draw_section(layout, context, key: str, label: str, icon: str, help_id: str, *, default: bool = False, body_property_split: bool = False):
    if _sss_ui_sections is None:
        return None
    return _sss_ui_sections.draw_child_section(layout, context, key, label, icon=icon, help_id=help_id, default=default, body_property_split=body_property_split)


def _draw_help_header(layout, label: str, icon_name: str, fallback: str, tool_id: str, context=None):
    row = layout.row(align=True)
    split = row.split(factor=0.70, align=True)
    left = split.row(align=True)
    _icon_label(left, text=label, icon_name=icon_name, fallback=fallback)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    _draw_help_button(right, tool_id, context)
    return row


def draw_axis_settings(layout, group, axis, context=None):
    pfx = f'tracker_{axis}_'
    axis_label = 'X' if axis == 'x' else 'Y'
    body = _draw_section(
        layout,
        context,
        f'face_tracker.axis_{axis}',
        _ui_text(f'{axis_label}-Axis Mapping', f'{axis_label} 軸マッピング', context),
        'CON_LOCLIKE',
        'face_tracker_axis_mapping',
        default=False,
        body_property_split=True,
    )
    if body is None:
        return

    body.prop(group, pfx + 'mode', text=_ui_text('Tracking Mode', 'トラッキング方式', context))

    row = body.row()
    row.prop(group, pfx + 'pt_a', text=_ui_text('Point A', '点 A', context))
    row.prop(group, pfx + 'pt_b', text=_ui_text('Point B', '点 B', context))

    col = body.column(align=True)
    col.label(text=_ui_text('Input Range', '入力範囲', context) + ':')
    col.prop(group, pfx + 'rmin', text=_ui_text('Lower Bound', '下限', context))
    col.prop(group, pfx + 'rmax', text=_ui_text('Upper Bound', '上限', context))

    row_cal = _large_icon_row(body, scale=1.18)
    _icon_op(row_cal, f'shape_xy.tracker_cal_min_{axis}', text=_ui_text('Capture Min', '最小を取得', context), icon_name='CAPTURE_MIN', fallback='TRIA_LEFT')
    _icon_op(row_cal, f'shape_xy.tracker_cal_max_{axis}', text=_ui_text('Capture Max', '最大を取得', context), icon_name='CAPTURE_MAX', fallback='TRIA_RIGHT')

    col = body.column(align=True)
    col.label(text=_ui_text('Output Signal Tuning', '出力信号調整', context) + ':')
    col.prop(group, pfx + 'omin', text=_ui_text('Min Target', '最小出力', context))
    col.prop(group, pfx + 'omax', text=_ui_text('Max Target', '最大出力', context))
    col.prop(group, pfx + 'sens', text=_ui_text('Gain', 'ゲイン', context))
    col.prop(group, pfx + 'exp', text=_ui_text('Curve (Exp)', 'カーブ（指数）', context))

    col = body.column(align=True)
    col.label(text=_ui_text('Smoothing', 'スムージング', context) + ':')
    col.prop(group, pfx + 'lerp_en', text=_ui_text('Enable Filter', 'フィルターを有効化', context))
    if getattr(group, pfx + 'lerp_en'):
        col.prop(group, pfx + 'lerp_fac', text=_ui_text('Smooth Factor', 'スムーズ係数', context))


class SHAPE_XY_PG_tracker_target(bpy.types.PropertyGroup):
    obj: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name=_ui_text('Object', 'オブジェクト'),
        description=_ui_text('Object that receives the face-tracker output.', 'フェイストラッカーの出力を受け取るオブジェクトです。'),
        update=_tracker_target_update,
    )
    group_name: bpy.props.StringProperty(
        name=_ui_text('Group', 'グループ'),
        description=_ui_text('Shape Axis group name on the selected object that should receive tracker values.', '選択したオブジェクト上で、トラッカー値を受け取るシェイプ軸グループ名です。'),
        update=_tracker_target_update,
    )


class SHAPE_XY_UL_tracker_targets(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        _icon_label(row, text=_ui_text(f'List {index + 1}:', f'一覧 {index + 1}:', context), icon_name='GROUP', fallback='DOT')
        row.prop(item, 'obj', text='')
        if item.obj and hasattr(item.obj, 'shape_xy_groups'):
            row.prop_search(item, 'group_name', item.obj, 'shape_xy_groups', text='')
        else:
            row.label(text=_ui_text('<Select>', '<選択>', context))


def draw_face_tracker_body(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    scene = _safe_scene(context)
    if scene is None:
        layout.label(text=_ui_text('Scene settings are not available.', 'シーン設定を利用できません。', context), icon='ERROR')
        return

    # CSV bake is available independently of optional webcam dependencies.
    from ... import facial_capture
    facial_capture.draw(layout, context)

    from .installer import check_dependencies
    status = getattr(scene, 'tracker_install_status', '')

    if not check_dependencies():
        box = layout.box()
        _icon_label(box, text=_ui_text('Dependencies Missing', '依存関係が不足しています', context) + '!', icon_name='DISABLED', fallback='ERROR')
        _icon_op(box, 'shape_xy.install_deps', text=_ui_text('Install Face Tracker Requirements', 'フェイストラッカー の必要環境をインストール', context), icon_name='INSTALL_FACE_TRACKER_DEPS', fallback='PLUGIN')
        if status:
            box.label(text=status)
        return

    from .core import TRACKER_RUNNING

    if hasattr(scene, 'tracker_cam_index'):
        layout.prop(scene, 'tracker_cam_index', text=_ui_text('Camera', 'カメラ', context))
    if TRACKER_RUNNING:
        _icon_label(layout, text=getattr(scene, 'tracker_fps_status', ''), icon_name='TRACKER', fallback='TIME')
    else:
        _icon_label(layout, text=_ui_text('Status: Stopped until you explicitly start it.', '状態: 明示的に開始するまでは停止したままです。', context), icon_name='STOP', fallback='PAUSE')

    _icon_op(layout, 'shape_xy.tracker_open_map', text=_ui_text('Reference Map', '参照マップ', context), icon_name='OPEN_TRACKER_REFERENCE_MAP', fallback='HELP')

    targets = _draw_section(layout, context, 'face_tracker.targets', _ui_text('Live Target Group', 'ライブ対象グループ', context), 'OUTLINER_OB_GROUP_INSTANCE', 'face_tracker_targets', default=False)
    if targets is not None:
        row_list = targets.row()
        row_list.template_list('SHAPE_XY_UL_tracker_targets', '', scene, 'tracker_targets', scene, 'tracker_target_index', rows=3)
        col_list = _large_icon_column(row_list)
        _icon_op(col_list, 'shape_xy.tracker_add_target', icon_name='ADD_TRACKER_TARGET', fallback='ADD', text='', emboss=True)
        _icon_op(col_list, 'shape_xy.tracker_remove_target', icon_name='REMOVE_TRACKER_TARGET', fallback='REMOVE', text='', emboss=True)

    idx = scene.tracker_target_index
    if hasattr(scene, 'tracker_targets') and 0 <= idx < len(scene.tracker_targets):
        target = scene.tracker_targets[idx]
        obj = target.obj
        if obj and target.group_name and hasattr(obj, 'shape_xy_groups') and target.group_name in obj.shape_xy_groups:
            group = obj.shape_xy_groups[target.group_name]
            setup = _draw_section(layout, context, 'face_tracker.target_setup', _ui_text(f'Tracker Setup: {group.name}', f'トラッカー設定: {group.name}', context), 'GROUP', 'face_tracker_target_setup', default=False)
            if setup is not None:
                row_preset = _large_icon_row(setup, scale=1.18)
                op = _icon_op(row_preset, 'shape_xy.tracker_apply_preset', text=_ui_text('Mouth', '口', context), icon_name='PRESET_MOUTH', fallback='MESH_DATA')
                op.preset_type = 'MOUTH'
                op = _icon_op(row_preset, 'shape_xy.tracker_apply_preset', text=_ui_text('Eyes', '目', context), icon_name='PRESET_EYES', fallback='HIDE_OFF')
                op.preset_type = 'EYES'
                op = _icon_op(row_preset, 'shape_xy.tracker_apply_preset', text=_ui_text('Blink', 'まばたき', context), icon_name='PRESET_BLINK', fallback='HIDE_ON')
                op.preset_type = 'EYE_BLINK'
                draw_axis_settings(setup, group, 'x', context)
                draw_axis_settings(setup, group, 'y', context)


class SHAPE_XY_PT_tracker_panel(bpy.types.Panel):
    bl_label = _ui_text('Face Tracker (Built-In)', 'フェイストラッカー（内蔵）')
    bl_idname = 'SHAPE_XY_PT_tracker_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        draw_face_tracker_body(self.layout, context)

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'face_tracker', context)


def register(ledger):
    from ... import lifecycle
    saved_target_index = int(_persistent_default('tracker_target_index', -1))
    lifecycle.register_class(ledger, SHAPE_XY_PG_tracker_target)
    lifecycle.register_rna_property(
        ledger, bpy.types.Scene, 'tracker_targets',
        bpy.props.CollectionProperty(
            type=SHAPE_XY_PG_tracker_target,
            description=_ui_text(
                'Face Tracker target rows. Each row links one object and Shape Axis group to live camera tracking input.',
                'フェイストラッカー対象行です。各行で、1つのオブジェクトとシェイプ軸グループをライブカメラ入力に割り当てます。',
            ),
        ),
    )
    lifecycle.register_rna_property(
        ledger, bpy.types.Scene, 'tracker_target_index',
        bpy.props.IntProperty(
            description=_ui_text(
                'Active Face Tracker target row. The selected row chooses which object and Shape Axis group receives tracker input.',
                '現在のフェイストラッカー対象行です。選択した行のオブジェクトとシェイプ軸グループがトラッカー入力を受け取ります。',
            ),
            default=saved_target_index,
            get=_tracker_target_get,
            set=_tracker_target_set,
            update=_tracker_target_update,
        ),
    )
    lifecycle.register_class(ledger, SHAPE_XY_UL_tracker_targets)


def unregister():
    return None
