# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Bounded external UDP tracker for Smart Shapekey Suite.

Continuous samples are coalesced into one latest-value slot. Control requests
use a separate bounded/deduplicated queue. Blender data is indexed once when the
feature is explicitly started and incrementally refreshed only for depsgraph
updates while the lease is active.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from itertools import islice
import json
import socket
import threading
import time

import bpy

from ... import activity as _activity
from ... import bounded_udp as _bounded_udp
from ... import lifecycle as _lifecycle
try:
    from ... import translation as _translation
except Exception:
    _translation = None
try:
    from ... import icons as _icons
except Exception:
    _icons = None

from ..core.main import get_limit, update_shapes


def _is_japanese_locale(context=None) -> bool:
    try:
        return bool(_translation is not None and _translation.is_japanese_locale(context))
    except Exception:
        return False


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _translation is not None:
            return _translation.ui_text(en, ja, context)
    except Exception:
        pass
    return ja if _is_japanese_locale(context) else en


def _set_suite_always_on_state(context, key: str, value: bool) -> None:
    try:
        settings = getattr(getattr(context, 'window_manager', None), 'skm_suite_settings', None)
        if settings is not None and hasattr(settings, key):
            setattr(settings, key, bool(value))
    except Exception:
        pass


def _persistent_default(key: str, default):
    try:
        from ... import runtime
        return runtime.get_persistent_setting(key, default)
    except Exception:
        return default


def _save_scene_runtime_setting(prop_name: str, value) -> None:
    try:
        from ... import runtime
        runtime.save_scene_runtime_setting(prop_name, value)
    except Exception:
        pass


def _on_tracker_port_update(self, _context):
    _save_scene_runtime_setting('shape_xy_tracker_port', int(getattr(self, 'shape_xy_tracker_port', 5000)))


@dataclass(frozen=True, slots=True)
class _TargetRef:
    object_name: str
    group_name: str


_LOCK = threading.RLock()
_INBOX = _bounded_udp.BoundedUDPInbox()
_LEASE = None
_THREAD: threading.Thread | None = None
_SOCKET: socket.socket | None = None
_STOP_EVENT = threading.Event()
_RUNNING = False
_LAST_ERROR = ''
_GROUP_INDEX: dict[str, _TargetRef] = {}
_OBJECT_INDEX_KEYS: dict[str, set[str]] = {}
_DIRTY_OBJECTS: set[str] = set()
_INDEX_REBUILDS = 0
_DIRTY_REINDEXES = 0
_PACKETS_APPLIED = 0
_CONTROL_RESPONSES = 0
_INDEX_OVERFLOW = 0
_DIRTY_OVERFLOW = 0
_TICK_BUDGET_OVERRUNS = 0
_MAX_TOTAL_TICK_SECONDS = 0.0
MAX_INDEX_TARGETS = 8192
MAX_DIRTY_TARGETS = 2048
MAX_CONTROL_RESPONSE_GROUPS = 512


def _set_error(message: object) -> None:
    global _LAST_ERROR
    _LAST_ERROR = str(message or '')[:2048]


def last_error() -> str:
    return _LAST_ERROR


def _groups_for_object(obj) -> tuple[Any, ...]:
    try:
        groups = getattr(obj, 'shape_xy_groups', None)
        return tuple(groups) if groups else ()
    except Exception:
        return ()


def _reindex_object(obj, *, object_name: str = '') -> None:
    global _DIRTY_REINDEXES, _INDEX_OVERFLOW
    obj_name = str(getattr(obj, 'name', '') or object_name or '')
    if not obj_name:
        return
    with _LOCK:
        stale = tuple(_OBJECT_INDEX_KEYS.pop(obj_name, ()))
        for key in stale:
            _GROUP_INDEX.pop(key, None)
        if obj is None:
            _DIRTY_REINDEXES += 1
            return
        groups = _groups_for_object(obj) if getattr(obj, 'type', None) == 'MESH' else ()
        object_keys: set[str] = set()
        for group in groups:
            group_name = str(getattr(group, 'name', '') or '')
            if not group_name:
                continue
            key = f'{obj_name}_{group_name}'
            if key not in _GROUP_INDEX and len(_GROUP_INDEX) >= MAX_INDEX_TARGETS:
                _INDEX_OVERFLOW += 1
                continue
            _GROUP_INDEX[key] = _TargetRef(obj_name, group_name)
            object_keys.add(key)
        if object_keys:
            _OBJECT_INDEX_KEYS[obj_name] = object_keys
        _DIRTY_REINDEXES += 1


def _build_target_index() -> None:
    """One explicit start-boundary scan; never called from a timer or draw."""
    global _INDEX_REBUILDS, _DIRTY_REINDEXES, _INDEX_OVERFLOW
    index: dict[str, _TargetRef] = {}
    reverse: dict[str, set[str]] = {}
    overflow = 0
    try:
        objects = tuple(getattr(bpy.data, 'objects', ()) or ())
    except Exception:
        objects = ()
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        groups = _groups_for_object(obj)
        if not groups:
            continue
        obj_name = str(getattr(obj, 'name', '') or '')
        if not obj_name:
            continue
        for group in groups:
            group_name = str(getattr(group, 'name', '') or '')
            if not group_name:
                continue
            key = f'{obj_name}_{group_name}'
            if key not in index and len(index) >= MAX_INDEX_TARGETS:
                overflow += 1
                continue
            index[key] = _TargetRef(obj_name, group_name)
            reverse.setdefault(obj_name, set()).add(key)
    with _LOCK:
        _GROUP_INDEX.clear()
        _GROUP_INDEX.update(index)
        _OBJECT_INDEX_KEYS.clear()
        _OBJECT_INDEX_KEYS.update(reverse)
        _DIRTY_OBJECTS.clear()
        _INDEX_REBUILDS += 1
        _DIRTY_REINDEXES = 0
        _INDEX_OVERFLOW += overflow


def _depsgraph_dirty(_scene, depsgraph) -> None:
    if not is_tracker_running():
        return
    try:
        updates = tuple(getattr(depsgraph, 'updates', ()) or ())
    except Exception:
        updates = ()
    names: set[str] = set()
    for update in updates:
        value = getattr(update, 'id', None)
        if isinstance(value, bpy.types.Object):
            name = str(getattr(value, 'name', '') or '')
            if name:
                names.add(name)
    if names:
        global _DIRTY_OVERFLOW
        with _LOCK:
            for name in names:
                if name in _DIRTY_OBJECTS:
                    continue
                if len(_DIRTY_OBJECTS) >= MAX_DIRTY_TARGETS:
                    _DIRTY_OVERFLOW += 1
                    continue
                _DIRTY_OBJECTS.add(name)


def _apply_dirty_index_updates(*, limit: int, deadline: float) -> int:
    processed = 0
    while processed < max(0, int(limit)) and time.perf_counter() < deadline:
        with _LOCK:
            if not _DIRTY_OBJECTS:
                break
            name = _DIRTY_OBJECTS.pop()
        try:
            obj = bpy.data.objects.get(name)
        except Exception:
            obj = None
        _reindex_object(obj, object_name=name)
        processed += 1
    return processed


def _resolve_group(ref: _TargetRef):
    try:
        obj = bpy.data.objects.get(ref.object_name)
    except Exception:
        obj = None
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None, None
    group = None
    groups = getattr(obj, 'shape_xy_groups', None)
    if groups is not None:
        getter = getattr(groups, 'get', None)
        if callable(getter):
            try:
                group = getter(ref.group_name)
            except Exception:
                group = None
        if group is None:
            finder = getattr(groups, 'find', None)
            if callable(finder):
                try:
                    index = int(finder(ref.group_name))
                    group = groups[index] if index >= 0 else None
                except Exception:
                    group = None
    return obj, group


def _set_group_value(obj, group, x: float, y: float) -> bool:
    if obj is None or group is None:
        return False
    try:
        group.joy_x = max(-1.0, min(1.0, float(x)))
        group.joy_y = max(-1.0, min(1.0, float(y)))
        update_shapes(obj, group, get_limit(group))
        return True
    except Exception:
        return False


def _process_control(message: dict[str, Any]) -> None:
    global _CONTROL_RESPONSES
    kind = str(message.get('type', '') or '').upper()
    if kind != 'GET_GROUPS':
        return
    address = message.get('_address')
    with _LOCK:
        total = len(_GROUP_INDEX)
        names = tuple(islice(_GROUP_INDEX.keys(), MAX_CONTROL_RESPONSE_GROUPS))
        sock = _SOCKET
    if sock is None or address is None:
        return
    # Keep the response below the maximum UDP payload without scanning Blender
    # data. The index is already a bounded immutable name snapshot here.
    selected: list[str] = []
    # Reserve deterministic envelope overhead, then account for each encoded
    # string once. A final exact check trims only if escaping made it larger.
    used = 96
    for name in names:
        encoded_size = len(json.dumps(name, ensure_ascii=False, allow_nan=False).encode('utf-8')) + 1
        if used + encoded_size > _bounded_udp.MAX_PACKET_BYTES:
            break
        selected.append(name)
        used += encoded_size
    payload = json.dumps({'type': 'GROUPS', 'groups': selected, 'total': total, 'truncated': len(selected) < total}, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
    while selected and len(payload) > _bounded_udp.MAX_PACKET_BYTES:
        selected.pop()
        payload = json.dumps({'type': 'GROUPS', 'groups': selected, 'total': total, 'truncated': True}, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
    try:
        sock.sendto(payload, address)
        _CONTROL_RESPONSES += 1
    except Exception as exc:
        _set_error(exc)


def _active_group_target(message: dict[str, Any]):
    """Resolve one event target without scanning the object database.

    Senders may optionally provide ``object``/``object_name`` next to the
    ``_ACTIVE_GROUP_`` sample. Otherwise Blender's current active object is the
    sole target, preserving the legacy active-group protocol without O(scene)
    work on every UDP frame.
    """
    object_name = str(message.get('object_name') or message.get('object') or '')
    try:
        obj = bpy.data.objects.get(object_name) if object_name else getattr(bpy.context, 'active_object', None)
    except Exception:
        obj = None
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None, None
    groups = getattr(obj, 'shape_xy_groups', None)
    try:
        index = int(getattr(obj, 'shape_xy_group_index', -1))
        group = groups[index] if groups is not None and 0 <= index < len(groups) else None
    except Exception:
        group = None
    return obj, group


def _process_continuous(message: dict[str, Any], *, deadline: float) -> tuple[int, dict[str, Any] | None]:
    global _PACKETS_APPLIED
    changed = False
    processed = 0
    deferred: dict[str, Any] | None = None
    if '_ACTIVE_GROUP_' in message:
        sample = message.get('_ACTIVE_GROUP_') or {}
        if type(sample) is dict and time.perf_counter() < deadline:
            obj, group = _active_group_target(message)
            changed = _set_group_value(obj, group, sample.get('x', 0.0), sample.get('y', 0.0))
            processed = 1
    else:
        items = tuple(message.items())[:_bounded_udp.MAX_CONTINUOUS_TARGETS]
        cursor = 0
        for group_id, sample in items:
            if processed >= _bounded_udp.TICK_MAX_CONTINUOUS_TARGETS or time.perf_counter() >= deadline:
                break
            with _LOCK:
                ref = _GROUP_INDEX.get(str(group_id))
            if ref is None or type(sample) is not dict:
                cursor += 1
                continue
            obj, group = _resolve_group(ref)
            changed = _set_group_value(obj, group, sample.get('x', 0.0), sample.get('y', 0.0)) or changed
            processed += 1
            cursor += 1
        if cursor < len(items):
            deferred = dict(items[cursor:])
    if changed:
        _PACKETS_APPLIED += 1
    return processed, deferred


def _process_tracker_tick():
    global _TICK_BUDGET_OVERRUNS, _MAX_TOTAL_TICK_SECONDS
    if not is_tracker_running():
        # A worker may terminate naturally after a socket error or generation
        # invalidation.  The main-thread timer owns the final join boundary so
        # the exact thread handle is retained until ``join`` succeeds.
        with _LOCK:
            pending = _THREAD is not None or _SOCKET is not None or _LEASE is not None
        if pending:
            stop_tracker()
        return None
    started = time.perf_counter()
    deadline = started + _bounded_udp.TICK_TIME_BUDGET_SECONDS
    processed = 0
    try:
        processed += _apply_dirty_index_updates(limit=_bounded_udp.TICK_MAX_DIRTY_TARGETS, deadline=deadline)
        control_count = 0
        while control_count < _bounded_udp.TICK_MAX_CONTROL and processed < _bounded_udp.TICK_MAX_ITEMS and time.perf_counter() < deadline:
            message = _INBOX.pop_control(deadline=deadline)
            if message is None:
                break
            _process_control(message)
            control_count += 1
            processed += 1
        if processed < _bounded_udp.TICK_MAX_ITEMS and time.perf_counter() < deadline:
            continuous = _INBOX.pop_continuous(deadline=deadline)
            if continuous is not None:
                _target_count, deferred = _process_continuous(continuous, deadline=deadline)
                if deferred:
                    _INBOX.defer_continuous(deferred)
                processed += 1
    except Exception as exc:
        _set_error(exc)
        stop_tracker()
        return None
    finally:
        elapsed = max(0.0, time.perf_counter() - started)
        _INBOX.record_tick(processed, elapsed)
        _MAX_TOTAL_TICK_SECONDS = max(_MAX_TOTAL_TICK_SECONDS, elapsed)
        if elapsed > _bounded_udp.TICK_TIME_BUDGET_SECONDS:
            _TICK_BUDGET_OVERRUNS += 1
    return 0.05


def process_tracker_queue():
    """Compatibility timer name retained for existing integrations."""
    return _process_tracker_tick()


def _udp_worker(sock: socket.socket, stop_event: threading.Event, token) -> None:
    global _RUNNING
    try:
        while not stop_event.is_set() and _activity.token_is_current(token):
            try:
                data, address = sock.recvfrom(_bounded_udp.MAX_PACKET_BYTES + 1)
            except socket.timeout:
                continue
            except OSError:
                break
            except Exception as exc:
                _set_error(exc)
                break
            _INBOX.offer_packet(data, address)
    finally:
        # Close the native socket immediately.  The exact thread entry remains in
        # the journal until a main-thread stop/join boundary confirms termination;
        # this prevents losing the only authoritative join handle while alive.
        _close_socket_exact(sock)
        _activity.mark_native_finished('external_udp_tracker', sock)
        with _LOCK:
            _RUNNING = False
        # Do not mutate Blender timers/handlers from this worker thread.  The
        # generation-scoped main-thread timer observes ``_RUNNING == False`` and
        # performs the exact socket/thread/handler teardown and join boundary.


def _close_socket_exact(sock: socket.socket) -> None:
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except Exception:
        pass
    try:
        sock.close()
    except Exception:
        pass


def _join_thread_exact(thread: threading.Thread) -> None:
    if thread is threading.current_thread():
        raise RuntimeError('cannot join tracker worker from itself')
    deadline = time.monotonic() + 2.0
    while thread.is_alive() and time.monotonic() < deadline:
        thread.join(timeout=0.05)
    if thread.is_alive():
        raise RuntimeError('UDP tracker worker did not stop after socket close')


def start_tracker(port) -> bool:
    global _LEASE, _THREAD, _SOCKET, _STOP_EVENT, _RUNNING, _LAST_ERROR
    if is_tracker_running():
        return True
    try:
        port = int(port)
    except Exception:
        _set_error('invalid UDP port')
        return False
    if not 1024 <= port <= 65535:
        _set_error('UDP port must be between 1024 and 65535')
        return False

    stop_tracker()
    _LAST_ERROR = ''
    _INBOX.clear(reset_stats=True)
    _build_target_index()
    stop_event = threading.Event()
    lease = None
    sock = None
    thread = None
    try:
        lease = _activity.new_lease('external_udp_tracker', replace=True)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('0.0.0.0', port))
        sock.settimeout(0.25)

        token = lease.token
        thread = threading.Thread(
            target=_udp_worker,
            args=(sock, stop_event, token),
            name=f'SmartShapekeyUDP-g{token.generation}',
            daemon=True,
        )
        # Record thread before socket so reverse teardown closes the socket first,
        # unblocks recvfrom, then joins while retaining the handle until success.
        _activity.track_thread(lease, thread, lambda t=thread: _join_thread_exact(t), label='UDP receive worker')
        _activity.track_socket(lease, sock, lambda s=sock: _close_socket_exact(s), label='UDP receive socket')

        with _LOCK:
            _STOP_EVENT = stop_event
            _THREAD = thread
            _SOCKET = sock
            _LEASE = lease
            _RUNNING = True
        thread.start()
        _activity.add_handler(lease, bpy.app.handlers.depsgraph_update_post, _depsgraph_dirty, label='UDP dirty target index')
        _activity.add_timer(lease, _process_tracker_tick, first_interval=0.05, persistent=False, label='UDP bounded processing tick')
        return True
    except Exception as exc:
        _set_error(exc)
        stop_event.set()
        if sock is not None:
            _close_socket_exact(sock)
        try:
            _activity.teardown_feature('external_udp_tracker')
        except Exception:
            pass
        alive = bool(thread is not None and thread.is_alive())
        if alive and thread is not threading.current_thread():
            try:
                _join_thread_exact(thread)
                alive = False
                _activity.teardown_feature('external_udp_tracker')
            except Exception as join_exc:
                _set_error(join_exc)
        if not alive:
            with _LOCK:
                if _THREAD is thread:
                    _THREAD = None
                if _SOCKET is sock:
                    _SOCKET = None
                if _LEASE is lease:
                    _LEASE = None
                _RUNNING = False
        return False


def stop_tracker() -> bool:
    global _LEASE, _THREAD, _SOCKET, _RUNNING
    with _LOCK:
        stop_event = _STOP_EVENT
        thread = _THREAD
        sock = _SOCKET
        _RUNNING = False
    stop_event.set()
    # Close first even if the activity ledger has become unavailable.
    if sock is not None:
        _close_socket_exact(sock)
    ok = _activity.teardown_feature('external_udp_tracker')
    alive = bool(thread is not None and thread.is_alive())
    if alive and thread is not threading.current_thread():
        try:
            _join_thread_exact(thread)
            alive = False
            # Retry the exact lease after the blocking native resource has now
            # stopped; this marks the retained journal identity removed.
            ok = bool(_activity.teardown_feature('external_udp_tracker') and ok)
        except Exception as exc:
            _set_error(exc)
            ok = False
    if not alive:
        with _LOCK:
            if _THREAD is thread:
                _THREAD = None
            if _SOCKET is sock:
                _SOCKET = None
            _LEASE = None
            _GROUP_INDEX.clear()
            _OBJECT_INDEX_KEYS.clear()
            _DIRTY_OBJECTS.clear()
        _INBOX.clear()
    return bool(ok and not alive)


def clear_runtime_cache() -> None:
    """Clear bounded scene/RNA-derived caches only after worker teardown."""
    if is_tracker_running():
        return
    with _LOCK:
        _GROUP_INDEX.clear()
        _OBJECT_INDEX_KEYS.clear()
        _DIRTY_OBJECTS.clear()
    _INBOX.clear()


def is_tracker_running() -> bool:
    with _LOCK:
        return bool(_RUNNING and _THREAD is not None and _THREAD.is_alive() and _SOCKET is not None)


def tracker_audit_snapshot() -> dict[str, Any]:
    with _LOCK:
        thread_alive = bool(_THREAD is not None and _THREAD.is_alive())
        socket_open = bool(_SOCKET is not None and getattr(_SOCKET, 'fileno', lambda: -1)() >= 0)
        index_size = len(_GROUP_INDEX)
        dirty_size = len(_DIRTY_OBJECTS)
        running = bool(_RUNNING)
    return {
        'running': running,
        'thread_alive': thread_alive,
        'socket_open': socket_open,
        'index_size': index_size,
        'dirty_target_count': dirty_size,
        'index_rebuilds': _INDEX_REBUILDS,
        'dirty_reindexes': _DIRTY_REINDEXES,
        'continuous_samples_applied': _PACKETS_APPLIED,
        'control_responses': _CONTROL_RESPONSES,
        'index_overflow': _INDEX_OVERFLOW,
        'dirty_overflow': _DIRTY_OVERFLOW,
        'tick_budget_overruns': _TICK_BUDGET_OVERRUNS,
        'max_total_tick_seconds': _MAX_TOTAL_TICK_SECONDS,
        'limits': {
            'index_targets': MAX_INDEX_TARGETS,
            'dirty_targets': MAX_DIRTY_TARGETS,
            'control_response_groups': MAX_CONTROL_RESPONSE_GROUPS,
        },
        'last_error': _LAST_ERROR,
        'inbox': _INBOX.snapshot(),
    }


class SHAPE_XY_OT_tracker_start(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_start'
    bl_options = {'INTERNAL'}
    bl_label = _ui_text('Start External Tracker', '外部トラッカーを開始')
    bl_description = _ui_text(
        'Start the bounded UDP listener. Continuous frames are coalesced, control requests are deduplicated, and only indexed or depsgraph-dirty Shape Axis targets are updated.',
        '有界 UDP 待受を開始します。連続フレームは最新値へ集約し、制御要求は重複排除し、索引済みまたは依存グラフで変更されたシェイプ軸対象だけを更新します。',
    )

    def execute(self, context):
        if not start_tracker(context.scene.shape_xy_tracker_port):
            _set_suite_always_on_state(context, 'always_external_tracker_enabled', False)
            self.report({'ERROR'}, _ui_text('External UDP tracker could not be started. Check the UDP port.', '外部 UDP トラッカーを開始できませんでした。UDP ポートを確認してください。', context))
            return {'CANCELLED'}
        _set_suite_always_on_state(context, 'always_external_tracker_enabled', True)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_stop(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_stop'
    bl_options = {'INTERNAL'}
    bl_label = _ui_text('Stop External Tracker', '外部トラッカーを停止')
    bl_description = _ui_text(
        'Stop the processing timer, close the UDP socket to unblock receive, join the worker, and clear the bounded inbox.',
        '処理タイマーを止め、UDP ソケットを先に閉じて受信待ちを解除し、ワーカー終了を確認して有界受信箱を消去します。',
    )

    def execute(self, context):
        ok = stop_tracker()
        _set_suite_always_on_state(context, 'always_external_tracker_enabled', False)
        if not ok:
            self.report({'WARNING'}, _ui_text('The tracker requested shutdown but a worker is still being retained for safe teardown.', '安全な終了確認のためトラッカーワーカーの参照を保持しています。', context))
        return {'FINISHED'}


def draw_external_tracker_body(layout, context):
    scene = getattr(context, 'scene', None)
    if scene is None:
        layout.label(text=_ui_text('Scene settings are not available.', 'シーン設定を利用できません。', context), icon='ERROR')
        return
    layout.use_property_split = False
    layout.use_property_decorate = False
    if hasattr(scene, 'shape_xy_tracker_port'):
        layout.prop(scene, 'shape_xy_tracker_port', text=_ui_text('UDP Port', 'UDPポート', context))
    state = tracker_audit_snapshot()
    text = _ui_text('Status: Listening (bounded/coalescing).', '状態: 有界・集約方式で待受中です。', context) if state['running'] else _ui_text('Status: Stopped.', '状態: 停止中です。', context)
    layout.label(text=text, icon='CHECKMARK' if state['running'] else 'PAUSE')


class SHAPE_XY_PT_tracker_interface_panel(bpy.types.Panel):
    bl_label = _ui_text('External Tracker (UDP)', '外部トラッカー (UDP)')
    bl_idname = 'SHAPE_XY_PT_tracker_interface_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_parent_id = ''
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        draw_external_tracker_body(self.layout, context)

    def draw_header_preset(self, context):
        del context
        try:
            self.layout.operator('skm.show_help', text='', icon='QUESTION').tool_id = 'external_tracker'
        except Exception:
            pass


def register(ledger):
    _lifecycle.register_class(ledger, SHAPE_XY_OT_tracker_start)
    _lifecycle.register_class(ledger, SHAPE_XY_OT_tracker_stop)
    _lifecycle.register_rna_property(
        ledger,
        bpy.types.Scene,
        'shape_xy_tracker_port',
        bpy.props.IntProperty(
            name=_ui_text('UDP Port', 'UDPポート'),
            default=int(_persistent_default('shape_xy_tracker_port', 5000)),
            min=1024,
            max=65535,
            update=_on_tracker_port_update,
            description=_ui_text(
                'UDP port used only while External Tracker is enabled. Match it with the sender; disabling closes the socket and joins the worker.',
                '外部トラッカー有効中だけ使用する UDP ポートです。送信側と一致させてください。無効化時はソケットを閉じてワーカー終了を確認します。',
            ),
        ),
    )


def unregister():
    stop_tracker()
