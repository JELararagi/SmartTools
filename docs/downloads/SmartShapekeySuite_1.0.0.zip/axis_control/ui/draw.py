# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Immutable/prebuilt Axis HUD rendering.

All Blender RNA reads and GPU batch construction occur in ``update_snapshot``
from explicit operator/event boundaries.  ``draw_hud`` only replays the frozen
snapshot and restores every queryable GPU state in ``finally``.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None

from ... import gpu_state
from ..core.state import HUD_STATE
from ..core.main import get_limit


@dataclass(frozen=True, slots=True)
class _BatchDraw:
    batch: Any
    color: tuple[float, float, float, float]


@dataclass(frozen=True, slots=True)
class _TextDraw:
    text: str
    x: float
    y: float
    size: int
    color: tuple[float, float, float, float]


@dataclass(frozen=True, slots=True)
class AxisHUDSnapshot:
    shader: Any
    batches: tuple[_BatchDraw, ...]
    texts: tuple[_TextDraw, ...]
    object_name: str
    group_name: str
    hud_x: float
    hud_y: float
    hud_size: float


_HUD_SHADER_CACHE = None
_HUD_TITLE_CACHE: dict[str, str] = {}
_HUD_SNAPSHOT: AxisHUDSnapshot | None = None
_LAST_BUILD_ERROR = ""
_DRAW_ERRORS = 0
_BUILD_COUNT = 0


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, "preferences", None), "view", None)
    if view is None:
        prefs = getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
    language = str(getattr(view, "language", "DEFAULT") or "DEFAULT").upper()
    return language.startswith("JA")


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def get_shader():
    global _HUD_SHADER_CACHE
    if _HUD_SHADER_CACHE is None:
        try:
            _HUD_SHADER_CACHE = gpu.shader.from_builtin("UNIFORM_COLOR")
        except Exception:
            _HUD_SHADER_CACHE = gpu.shader.from_builtin("2D_UNIFORM_COLOR")
    return _HUD_SHADER_CACHE


def _hud_title_text(context=None) -> str:
    key = "ja" if _is_japanese_locale(context) else "en"
    cached = _HUD_TITLE_CACHE.get(key)
    if cached is None:
        cached = _ui_text("ShapeKey Axis Control", "シェイプキー軸コントロール", context)
        if len(_HUD_TITLE_CACHE) >= 2:
            _HUD_TITLE_CACHE.clear()
        _HUD_TITLE_CACHE[key] = cached
    return cached


def _rect(x0: float, y0: float, x1: float, y1: float) -> tuple[tuple[float, float], ...]:
    return ((x0, y0), (x1, y0), (x1, y1), (x0, y1))


def _add_rect(
    shader,
    batches: list[_BatchDraw],
    verts: tuple[tuple[float, float], ...],
    fill: tuple[float, float, float, float],
    outline: tuple[float, float, float, float] | None = None,
) -> None:
    batches.append(
        _BatchDraw(
            batch_for_shader(shader, "TRIS", {"pos": verts}, indices=((0, 1, 2), (2, 3, 0))),
            fill,
        )
    )
    if outline is not None:
        batches.append(_BatchDraw(batch_for_shader(shader, "LINE_LOOP", {"pos": verts}), outline))


def clear_snapshot() -> None:
    global _HUD_SNAPSHOT
    _HUD_SNAPSHOT = None


def update_snapshot(obj=None, group=None, context=None) -> bool:
    """Build a complete immutable draw snapshot outside the draw callback."""
    global _HUD_SNAPSHOT, _LAST_BUILD_ERROR, _BUILD_COUNT
    if obj is None or group is None:
        _HUD_SNAPSHOT = None
        return False
    try:
        shader = get_shader()
        x = float(HUD_STATE.get("x", 50.0))
        y = float(HUD_STATE.get("y", 120.0))
        size = max(32.0, float(HUD_STATE.get("size", 200.0)))
        limit = float(get_limit(group) or 1.0)
        if abs(limit) < 1.0e-8:
            limit = 1.0
        joy_x = float(getattr(group, "joy_x", 0.0))
        joy_y = float(getattr(group, "joy_y", 0.0))
        group_name = str(getattr(group, "name", "") or _ui_text("None", "未設定", context))
        object_name = str(getattr(obj, "name", "") or "")

        batches: list[_BatchDraw] = []
        texts: list[_TextDraw] = []
        outline = (0.1, 0.1, 0.1, 1.0)
        button_color = (0.32, 0.32, 0.32, 1.0)
        text_color = (0.85, 0.85, 0.85, 1.0)

        panel_y_min = y - 112.0
        _add_rect(shader, batches, _rect(x - 4, panel_y_min, x + size + 4, y + size), (0.18, 0.18, 0.18, 0.98), (0.3, 0.3, 0.3, 0.98))
        _add_rect(shader, batches, _rect(x - 4, y + size, x + size + 4, y + size + 25), (0.12, 0.12, 0.12, 0.98))
        texts.append(_TextDraw(_hud_title_text(context), x + 8, y + size + 7, 14, (0.9, 0.9, 0.9, 1.0)))

        joy_rect = _rect(x, y, x + size, y + size)
        _add_rect(shader, batches, joy_rect, (0.11, 0.11, 0.11, 1.0), (0.05, 0.05, 0.05, 1.0))
        cx, cy = x + size * 0.5, y + size * 0.5

        # Snapshot all mapping values before batch construction.
        mapping_values: list[tuple[str, float, float, float]] = []
        for item in tuple(getattr(group, "shape_xy_list", ()) or ()):
            mapping_values.append(
                (
                    str(getattr(item, "shape_name", "") or ""),
                    float(getattr(item, "target_x", 0.0)),
                    float(getattr(item, "target_y", 0.0)),
                    max(0.0, float(getattr(item, "radius", 0.0))),
                )
            )
        for shape_name, target_x, target_y, radius in mapping_values:
            px = cx + (target_x / limit) * (size * 0.5)
            py = cy + (target_y / limit) * (size * 0.5)
            pr = (radius / abs(limit)) * (size * 0.5)
            circle = tuple(
                (px + math.cos(i / 32.0 * math.tau) * pr, py + math.sin(i / 32.0 * math.tau) * pr)
                for i in range(33)
            )
            batches.append(_BatchDraw(batch_for_shader(shader, "LINE_STRIP", {"pos": circle}), (1.0, 0.2, 0.2, 0.6)))
            _add_rect(shader, batches, _rect(px - 3, py - 3, px + 3, py + 3), (0.8, 0.8, 0.8, 1.0))
            if shape_name:
                texts.append(_TextDraw(shape_name, px + 5, py + 5, 12, (1.0, 1.0, 1.0, 1.0)))

        cross = ((cx, y), (cx, y + size), (x, cy), (x + size, cy))
        batches.append(_BatchDraw(batch_for_shader(shader, "LINES", {"pos": cross}), (0.2, 0.2, 0.2, 1.0)))
        dot_x = cx + joy_x * size * 0.5
        dot_y = cy + joy_y * size * 0.5
        _add_rect(shader, batches, _rect(dot_x - 8, dot_y - 8, dot_x + 8, dot_y + 8), (0.3, 0.6, 1.0, 1.0))

        reset_y = y - 35
        edit_y = y - 75
        group_y = y - 105
        _add_rect(shader, batches, _rect(x, reset_y, x + size, reset_y + 30), button_color, outline)
        _add_rect(shader, batches, _rect(x, edit_y, x + size, edit_y + 35), (0.11, 0.11, 0.11, 1.0), outline)
        _add_rect(shader, batches, _rect(x, group_y, x + 30, group_y + 25), button_color, outline)
        _add_rect(shader, batches, _rect(x + 35, group_y, x + size - 35, group_y + 25), (0.22, 0.22, 0.22, 1.0), outline)
        _add_rect(shader, batches, _rect(x + size - 30, group_y, x + size, group_y + 25), button_color, outline)

        texts.extend(
            (
                _TextDraw(_ui_text("Reset Position", "位置をリセット", context), x + 50, reset_y + 8, 14, text_color),
                _TextDraw(f"X: {joy_x * limit:.3f}     Y: {joy_y * limit:.3f}", x + 10, edit_y + 12, 14, (0.9, 0.9, 0.9, 1.0)),
                _TextDraw("<", x + 11, group_y + 7, 13, text_color),
                _TextDraw(group_name, x + 42, group_y + 7, 12, (1.0, 1.0, 1.0, 1.0)),
                _TextDraw(">", x + size - 19, group_y + 7, 13, text_color),
            )
        )

        _HUD_SNAPSHOT = AxisHUDSnapshot(
            shader=shader,
            batches=tuple(batches),
            texts=tuple(texts),
            object_name=object_name,
            group_name=group_name,
            hud_x=x,
            hud_y=y,
            hud_size=size,
        )
        _LAST_BUILD_ERROR = ""
        _BUILD_COUNT += 1
        return True
    except Exception as exc:
        _HUD_SNAPSHOT = None
        _LAST_BUILD_ERROR = f"{type(exc).__name__}: {exc}"[:800]
        return False


def consume_build_error() -> str:
    global _LAST_BUILD_ERROR
    message = _LAST_BUILD_ERROR
    _LAST_BUILD_ERROR = ""
    return message


def draw_hud() -> None:
    """Replay immutable batches/text only; never reads Blender RNA."""
    global _DRAW_ERRORS
    snapshot = _HUD_SNAPSHOT
    if snapshot is None:
        return
    try:
        with gpu_state.preserved():
            gpu.state.blend_set("ALPHA")
            shader = snapshot.shader
            for entry in snapshot.batches:
                shader.bind()
                shader.uniform_float("color", entry.color)
                entry.batch.draw(shader)
            for entry in snapshot.texts:
                blf.position(0, entry.x, entry.y, 0)
                blf.size(0, entry.size)
                blf.color(0, *entry.color)
                blf.draw(0, entry.text)
    except Exception:
        # The callback must never print/raise repeatedly.  A bounded counter is
        # available to the explicit operator/audit boundary.
        _DRAW_ERRORS = min(_DRAW_ERRORS + 1, 2**31 - 1)


def audit_snapshot() -> dict[str, Any]:
    snapshot = _HUD_SNAPSHOT
    return {
        "snapshot_ready": snapshot is not None,
        "batch_count": len(snapshot.batches) if snapshot is not None else 0,
        "text_count": len(snapshot.texts) if snapshot is not None else 0,
        "build_count": int(_BUILD_COUNT),
        "draw_errors": int(_DRAW_ERRORS),
        "last_build_error": _LAST_BUILD_ERROR,
        "draw_reads_rna": False,
        "draw_builds_batches": False,
    }
