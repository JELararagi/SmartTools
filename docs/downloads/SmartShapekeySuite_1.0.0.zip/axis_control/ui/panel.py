# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None
try:
    from ... import icons as _sss_icons
except Exception:
    _sss_icons = None
try:
    from ... import ui_sections as _sss_ui_sections
except Exception:
    _sss_ui_sections = None


from ..core.main import get_active_group, unique_group_name


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, 'preferences', None), 'view', None)
    if view is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
    language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT').upper()
    return language.startswith('JA')


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _safe_view3d_context(context) -> bool:
    area = getattr(context, 'area', None)
    return area is None or getattr(area, 'type', None) == 'VIEW_3D'


def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None


def _safe_active_mesh(context, *, require_selected: bool = True):
    obj = None
    for attr in ('object', 'active_object'):
        try:
            candidate = getattr(context, attr, None)
        except Exception:
            candidate = None
        if candidate is not None:
            obj = candidate
            break
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        if getattr(obj, 'data', None) is None:
            return None
    except Exception:
        return None
    try:
        if getattr(bpy.data.objects, 'get', None) and bpy.data.objects.get(getattr(obj, 'name', '')) is not obj:
            return None
    except Exception:
        return None
    if require_selected:
        try:
            selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
            if selected_objects and obj not in selected_objects:
                return None
        except Exception:
            pass
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode in {'', 'OBJECT'} and hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
    return obj


def _safe_mesh_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None and _safe_active_mesh(context, require_selected=True) is not None


def _safe_scene_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None




def _save_panel_settings(context=None):
    ctx = context if context is not None else getattr(bpy, 'context', None)
    try:
        from ... import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(ctx)
    except Exception:
        pass
    try:
        from .. import refresh_frame_sync_registration
        refresh_frame_sync_registration(getattr(ctx, 'scene', None))
    except Exception:
        pass


def _icon_op(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.operator(layout, operator_id, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=fallback, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def _icon_label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', translate: bool = True):
    try:
        if _sss_icons is not None:
            return _sss_icons.label(layout, text=text, icon_name=icon_name, fallback=fallback, translate=translate)
    except Exception:
        pass
    try:
        return layout.label(text=text, translate=translate, icon=fallback)
    except Exception:
        return layout.label(text=text, translate=translate)


def _large_icon_column(layout, *, scale: float = 1.22):
    col = layout.column(align=True)
    try:
        col.scale_y = max(float(getattr(col, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass
    return col


def _large_icon_row(layout, *, scale: float = 1.22):
    row = layout.row(align=True)
    try:
        row.scale_y = max(float(getattr(row, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass
    return row


def _draw_help_button(layout, tool_id: str, context=None, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Selector-style help button.

    The button uses Blender's built-in QUESTION icon and an empty label.
    """
    del context, icon, text
    if not tool_id:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION')
        op.tool_id = str(tool_id or '')
        return op
    except Exception:
        return None


def _draw_section(layout, context, key: str, label: str, icon: str, help_id: str, *, default: bool = False, body_property_split: bool = False):
    if _sss_ui_sections is None:
        return None
    return _sss_ui_sections.draw_child_section(layout, context, key, label, icon=icon, help_id=help_id, default=default, body_property_split=body_property_split)


def _draw_help_header(layout, label: str, icon_name: str, fallback: str, tool_id: str, context=None):
    row = layout.row(align=True)
    split = row.split(factor=0.70, align=True)
    left = split.row(align=True)
    _icon_label(left, text=label, icon_name=icon_name, fallback=fallback)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    _draw_help_button(right, tool_id, context)
    return row


class SHAPE_XY_UL_group_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        _icon_label(layout, text=str(getattr(item, 'name', '') or ''), icon_name='GROUP', fallback='GROUP', translate=False)


class SHAPE_XY_UL_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=str(getattr(item, 'shape_name', '') or _ui_text('None', '未設定', context)), translate=False)
        try:
            layout.label(text=f"X:{float(getattr(item, 'target_x', 0.0)):.1f} Y:{float(getattr(item, 'target_y', 0.0)):.1f}")
        except Exception:
            layout.label(text='')


class SHAPE_XY_UL_preset_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        _icon_label(layout, text=str(getattr(item, 'name', '') or ''), icon_name='PRESET', fallback='USER', translate=False)


class SHAPE_XY_OT_add_group(bpy.types.Operator):
    bl_idname = 'shape_xy.add_group'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Add Group', 'グループを追加')
    bl_description = _ui_text('Create a new ShapeKey control group for the active object.', 'アクティブオブジェクトに新しいシェイプキー 制御グループを作成します。')

    def execute(self, context):
        obj = context.active_object
        if obj is None or not hasattr(obj, 'shape_xy_groups'):
            return {'CANCELLED'}
        number = len(obj.shape_xy_groups) + 1
        name = unique_group_name(obj.shape_xy_groups, _ui_text(f'Group {number}', f'グループ {number}', context))
        new_group = obj.shape_xy_groups.add()
        new_group.name = name
        obj.shape_xy_group_index = len(obj.shape_xy_groups) - 1
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_remove_group(bpy.types.Operator):
    bl_idname = 'shape_xy.remove_group'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Remove Group', 'グループを削除')
    bl_description = _ui_text('Delete the currently selected ShapeKey control group.', '現在選択中のシェイプキー 制御グループを削除します。')

    def execute(self, context):
        obj = context.active_object
        if obj is None or not hasattr(obj, 'shape_xy_groups'):
            return {'CANCELLED'}
        idx = obj.shape_xy_group_index
        if 0 <= idx < len(obj.shape_xy_groups):
            obj.shape_xy_groups.remove(idx)
            obj.shape_xy_group_index = min(max(0, idx - 1), len(obj.shape_xy_groups) - 1) if len(obj.shape_xy_groups) else -1
            _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_add(bpy.types.Operator):
    bl_idname = 'shape_xy.add_item'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Add Mapping', 'マッピングを追加')
    bl_description = _ui_text('Add a new ShapeKey mapping to the current group.', '現在のグループへ新しいシェイプキーマッピングを追加します。')

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group:
            group.shape_xy_list.add()
            group.shape_xy_index = len(group.shape_xy_list) - 1
            _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_remove(bpy.types.Operator):
    bl_idname = 'shape_xy.remove_item'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Remove Mapping', 'マッピングを削除')
    bl_description = _ui_text('Remove the currently selected ShapeKey mapping from the group.', '現在選択中のシェイプキーマッピングをグループから削除します。')

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group and group.shape_xy_list:
            idx = group.shape_xy_index
            if 0 <= idx < len(group.shape_xy_list):
                group.shape_xy_list.remove(idx)
                group.shape_xy_index = min(max(0, idx - 1), len(group.shape_xy_list) - 1) if len(group.shape_xy_list) else -1
                _save_panel_settings(context)
        return {'FINISHED'}



def draw_shape_axis_control_body(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    try:
        obj = _safe_active_mesh(context, require_selected=False)
        scene = _safe_scene(context)

        if scene is None:
            layout.label(text=_ui_text('Scene settings are not available.', 'シーン設定を利用できません。', context), icon='ERROR')
            return

        if not obj or obj.type != 'MESH':
            layout.label(text=_ui_text('Select a mesh object.', 'メッシュオブジェクトを選択してください。', context))
            return

        row = layout.column(align=True)
        _icon_op(row, 'shape_xy.reset_handle', text=_ui_text('Reset', 'リセット', context), icon_name='AXIS_RESET', fallback='FILE_REFRESH')
        _icon_op(row, 'shape_xy.reset_all', text=_ui_text('Reset All', 'すべてリセット', context), icon_name='AXIS_RESET_ALL', fallback='FILE_REFRESH')
        _icon_op(row, 'shape_xy.reset_hud', text=_ui_text('Reset HUD', 'HUD をリセット', context), icon_name='HUD', fallback='MODIFIER')

        if hasattr(scene, 'shape_xy_allow_drag'):
            layout.prop(scene, 'shape_xy_allow_drag', text=_ui_text('Point Drag', 'ポイントドラッグ', context))

        groups = _draw_section(layout, context, 'shape_axis.groups', _ui_text('Groups', 'グループ', context), 'GROUP', 'shape_axis_groups', default=False)
        if groups is not None:
            if not hasattr(obj, 'shape_xy_groups') or len(obj.shape_xy_groups) == 0:
                groups.alert = True
                _icon_op(groups, 'shape_xy.add_group', text=_ui_text('Create the First Group to Set Up', '最初のグループを作成して設定開始', context), icon_name='CREATE_FIRST_GROUP', fallback='ADD')
                groups.alert = False
            else:
                row = groups.row()
                row.template_list('SHAPE_XY_UL_group_list', '', obj, 'shape_xy_groups', obj, 'shape_xy_group_index')
                col = _large_icon_column(row)
                _icon_op(col, 'shape_xy.add_group', icon_name='ADD_GROUP', fallback='ADD', text='', emboss=True)
                _icon_op(col, 'shape_xy.remove_group', icon_name='REMOVE_GROUP', fallback='REMOVE', text='', emboss=True)
                col.separator()
                _icon_op(col, 'shape_xy.move_group', icon_name='MOVE_GROUP_UP', fallback='TRIA_UP', text='', emboss=True).direction = 'UP'
                _icon_op(col, 'shape_xy.move_group', icon_name='MOVE_GROUP_DOWN', fallback='TRIA_DOWN', text='', emboss=True).direction = 'DOWN'

        group = get_active_group(obj)
        if group:
            handle = _draw_section(layout, context, 'shape_axis.handle_values', _ui_text('Handle / Values', 'ハンドル / 値', context), 'DRIVER', 'shape_axis_handle_values', default=False)
            if handle is not None:
                handle.prop(group, 'name', text=_ui_text('Group Name', 'グループ名', context))
                row_h = handle.row(align=True)
                _icon_op(row_h, 'shape_xy.reset_handle', text=_ui_text('Reset Handle', 'ハンドルをリセット', context), icon_name='RESET_HANDLE', fallback='FILE_REFRESH')
                _icon_op(row_h, 'shape_xy.keyframe_handle', text=_ui_text('Key Handle [I]', 'ハンドルにキー [I]', context), icon_name='KEY_HANDLE', fallback='KEY_HLT')
                _icon_op(handle, 'shape_xy.edit_values', text=_ui_text('Edit Values', '値を編集', context), icon_name='EDIT_VALUES', fallback='DRIVER')
                _icon_op(handle, 'shape_xy.bake_animation', text=_ui_text('Bake Animation', 'アニメーションをベイク', context), icon_name='BAKE_ANIMATION', fallback='ACTION_TWEAK')

                box_val = handle.box()
                row_val = box_val.column(align=True)
                row_val.prop(group, 'joy_x', text=_ui_text('X (Drivable)', 'X（ドライブ可）', context))
                row_val.prop(group, 'joy_y', text=_ui_text('Y (Drivable)', 'Y（ドライブ可）', context))

                row_io = handle.row(align=True)
                _icon_op(row_io, 'shape_xy.import_group', text=_ui_text('Import JSON', 'JSON を読み込み', context), icon_name='IMPORT_GROUP_JSON', fallback='IMPORT')
                _icon_op(row_io, 'shape_xy.export_group', text=_ui_text('Export JSON', 'JSON を書き出し', context), icon_name='EXPORT_GROUP_JSON', fallback='EXPORT')

            mappings = _draw_section(layout, context, 'shape_axis.mappings', _ui_text('Mappings', 'マッピング', context), 'OUTLINER_COLLECTION', 'shape_axis_mappings', default=False)
            if mappings is not None:
                row = mappings.row()
                row.template_list('SHAPE_XY_UL_list', '', group, 'shape_xy_list', group, 'shape_xy_index')

                col = _large_icon_column(row)
                _icon_op(col, 'shape_xy.add_item', icon_name='ADD_MAPPING', fallback='ADD', text='', emboss=True)
                _icon_op(col, 'shape_xy.remove_item', icon_name='REMOVE_MAPPING', fallback='REMOVE', text='', emboss=True)
                col.separator()
                _icon_op(col, 'shape_xy.move_item', icon_name='MOVE_MAPPING_UP', fallback='TRIA_UP', text='', emboss=True).direction = 'UP'
                _icon_op(col, 'shape_xy.move_item', icon_name='MOVE_MAPPING_DOWN', fallback='TRIA_DOWN', text='', emboss=True).direction = 'DOWN'
                col.separator()
                _icon_op(col, 'shape_xy.mirror_mappings', icon_name='MIRROR_MAPPINGS', fallback='MOD_MIRROR', text='', emboss=True)

                if 0 <= group.shape_xy_index < len(group.shape_xy_list):
                    item = group.shape_xy_list[group.shape_xy_index]
                    settings = _draw_section(mappings, context, 'shape_axis.mapping_settings', _ui_text('Mapping Settings', 'マッピング設定', context), 'TOOL_SETTINGS', 'shape_axis_mapping_settings', default=False, body_property_split=True)
                    if settings is not None:
                        if obj.data and hasattr(obj.data, 'shape_keys') and obj.data.shape_keys:
                            settings.prop_search(item, 'shape_name', obj.data.shape_keys, 'key_blocks', text=_ui_text('Shape Key', 'シェイプキー', context))
                        else:
                            settings.prop(item, 'shape_name', text=_ui_text('Shape Key', 'シェイプキー', context))
                        row_coord = settings.row()
                        row_coord.prop(item, 'target_x', text='X')
                        row_coord.prop(item, 'target_y', text='Y')
                        row_blend = settings.row()
                        row_blend.prop(item, 'radius', text=_ui_text('Radius', '半径', context))
                        row_blend.prop(item, 'blend_mode', text=_ui_text('Blend', 'ブレンド', context))
        else:
            mappings = _draw_section(layout, context, 'shape_axis.mappings', _ui_text('Mappings', 'マッピング', context), 'OUTLINER_COLLECTION', 'shape_axis_mappings', default=False)
            if mappings is not None:
                mappings.label(text=_ui_text('No group yet.', 'グループがまだありません。', context))

        presets = _draw_section(layout, context, 'shape_axis.presets', _ui_text('Global Animation Presets', 'アニメーションプリセット', context), 'USER', 'shape_axis_presets', default=False)
        if presets is not None:
            row_preset = presets.row()
            row_preset.template_list('SHAPE_XY_UL_preset_list', '', scene, 'shape_xy_presets', scene, 'shape_xy_preset_index')

            p_col = _large_icon_column(row_preset)
            _icon_op(p_col, 'shape_xy.add_preset', icon_name='ADD_PRESET', fallback='ADD', text='', emboss=True)
            _icon_op(p_col, 'shape_xy.remove_preset', icon_name='REMOVE_PRESET', fallback='REMOVE', text='', emboss=True)
            p_col.separator()
            _icon_op(p_col, 'shape_xy.move_preset', icon_name='MOVE_PRESET_UP', fallback='TRIA_UP', text='', emboss=True).direction = 'UP'
            _icon_op(p_col, 'shape_xy.move_preset', icon_name='MOVE_PRESET_DOWN', fallback='TRIA_DOWN', text='', emboss=True).direction = 'DOWN'

            if 0 <= scene.shape_xy_preset_index < len(scene.shape_xy_presets):
                preset = scene.shape_xy_presets[scene.shape_xy_preset_index]
                presets.prop(preset, 'name', text=_ui_text('Preset Name', 'プリセット名', context))
                p_ops = presets.row(align=True)
                _icon_op(p_ops, 'shape_xy.set_preset', text=_ui_text('Set', '保存', context), icon_name='SET_PRESET_BUTTON', fallback='GREASEPENCIL')
                _icon_op(p_ops, 'shape_xy.call_preset', text=_ui_text('Call', '呼び出し', context), icon_name='CALL_PRESET_BUTTON', fallback='RESTRICT_SELECT_OFF')
                _icon_op(p_ops, 'shape_xy.keyframe_preset', text=_ui_text('Key', 'キー', context), icon_name='KEY_PRESET', fallback='KEY_HLT')

    except Exception as exc:
        box = layout.box()
        box.alert = True
        box.label(text=_ui_text('The Shape Axis panel could not be drawn.', 'シェイプ軸パネルを描画できませんでした。', context), icon='ERROR')


class SHAPE_XY_PT_panel(bpy.types.Panel):
    bl_label = _ui_text('ShapeKey Axis Control', 'シェイプキー軸コントロール')
    bl_idname = 'SHAPE_XY_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        draw_shape_axis_control_body(self.layout, context)

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'shape_axis_control', context)
