# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from math import pi

import bpy

try:
    from .. import translation as _sss_translation
except Exception:
    _sss_translation = None

try:
    from .. import icons as _sss_icons
except Exception:
    _sss_icons = None


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, 'preferences', None), 'view', None)
    if view is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
    language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT').upper()
    return language.startswith('JA')


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _safe_view3d_context(context) -> bool:
    area = getattr(context, 'area', None)
    return area is None or getattr(area, 'type', None) == 'VIEW_3D'


def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None


def _safe_active_mesh(context, *, require_selected: bool = True):
    obj = None
    for attr in ('object', 'active_object'):
        try:
            candidate = getattr(context, attr, None)
        except Exception:
            candidate = None
        if candidate is not None:
            obj = candidate
            break
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        if getattr(obj, 'data', None) is None:
            return None
    except Exception:
        return None
    try:
        if getattr(bpy.data.objects, 'get', None) and bpy.data.objects.get(getattr(obj, 'name', '')) is not obj:
            return None
    except Exception:
        return None
    if require_selected:
        try:
            selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
            if selected_objects and obj not in selected_objects:
                return None
        except Exception:
            pass
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode in {'', 'OBJECT'} and hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
    return obj


def _safe_mesh_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None and _safe_active_mesh(context, require_selected=True) is not None


def _safe_scene_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None






def _icon_op(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.operator(layout, operator_id, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=fallback, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def _icon_label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE'):
    try:
        if _sss_icons is not None:
            return _sss_icons.label(layout, text=text, icon_name=icon_name, fallback=fallback)
    except Exception:
        pass
    try:
        return layout.label(text=text, icon=fallback)
    except Exception:
        return layout.label(text=text)


def _draw_help_button(layout, tool_id: str, context=None, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Selector-style help button.

    The button uses Blender's built-in QUESTION icon and an empty label.
    """
    del context, icon, text
    if not tool_id:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION')
        op.tool_id = str(tool_id or '')
        return op
    except Exception:
        return None


def _persistent_default(key: str, default):
    try:
        from .. import runtime
        getter = getattr(runtime, 'get_persistent_setting', None)
        if callable(getter):
            return getter(key, default)
    except Exception:
        pass
    return default


def _save_persistent_setting(key: str, value) -> None:
    try:
        from .. import runtime
        saver = getattr(runtime, 'save_persistent_setting', None)
        if callable(saver):
            saver(key, value)
    except Exception:
        pass


def _on_driverhelper_mode_update(self, context):
    _save_persistent_setting('driverhelper_mode', getattr(self, 'driverhelper_mode', 'LOC'))
    update_driverhelper_mode(self, context)


def _on_driverhelper_min_update(self, context):
    del context
    _save_persistent_setting('driverhelper_min', float(getattr(self, 'driverhelper_min', 0.0)))


def _on_driverhelper_max_update(self, context):
    del context
    _save_persistent_setting('driverhelper_max', float(getattr(self, 'driverhelper_max', 1.0)))


def _on_driverhelper_power_update(self, context):
    del context
    _save_persistent_setting('driverhelper_power', float(getattr(self, 'driverhelper_power', 1.0)))


def _driverhelper_has_target(context) -> bool:
    obj = getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    data = getattr(obj, 'data', None)
    shape_keys = getattr(data, 'shape_keys', None) if data is not None else None
    key_blocks = getattr(shape_keys, 'key_blocks', None) if shape_keys is not None else None
    return bool(key_blocks)


class DriverHelperProperties(bpy.types.PropertyGroup):
    driverhelper_mode: bpy.props.EnumProperty(
        name=_ui_text('Driver Mode', 'ドライバーモード'),
        description=_ui_text(
            'Choose which transform channel the generated driver formula should read from: Location, Rotation, or Scale.',
            '生成するドライバー式が参照する変形チャンネルを選びます。Location・Rotation・Scale のどれを使うか決めます。',
        ),
        items=[
            ('LOC', 'LOC', _ui_text('Location channel', '位置チャンネル')),
            ('ROT', 'ROT', _ui_text('Rotation channel', '回転チャンネル')),
            ('SCALE', 'SCALE', _ui_text('Scale channel', 'スケールチャンネル')),
        ],
        default=str(_persistent_default('driverhelper_mode', 'LOC') or 'LOC'),
        update=_on_driverhelper_mode_update,
    )  # type: ignore
    driverhelper_min: bpy.props.FloatProperty(
        name=_ui_text('Min', '最小'),
        description=_ui_text(
            'Lower input bound used by the formula. The driver stays at 0 until the source reaches this value.',
            '式の下限入力値です。元の値がここに達するまではドライバー出力を 0 のままにします。',
        ),
        default=float(_persistent_default('driverhelper_min', 0.0)),
        update=_on_driverhelper_min_update,
    )  # type: ignore
    driverhelper_max: bpy.props.FloatProperty(
        name=_ui_text('Max', '最大'),
        description=_ui_text(
            'Upper input bound used by the formula. When the source reaches this value, the driver output reaches 1.',
            '式の上限入力値です。元の値がここに達するとドライバー出力が 1 になります。',
        ),
        default=float(_persistent_default('driverhelper_max', 1.0)),
        update=_on_driverhelper_max_update,
    )  # type: ignore
    driverhelper_power: bpy.props.FloatProperty(
        name=_ui_text('Power', 'パワー'),
        description=_ui_text(
            'Curve exponent for easing. 1.0 keeps the response linear, values above 1.0 ease in, and values below 1.0 ease out.',
            '補間カーブの指数です。1.0 は線形、1.0 より大きいとイーズイン、1.0 より小さいとイーズアウトになります。',
        ),
        default=float(_persistent_default('driverhelper_power', 1.0)),
        update=_on_driverhelper_power_update,
    )  # type: ignore


def driver_formula(min_val: float, max_val: float, transform_type='ROT', power: float = 1.0) -> str:
    if transform_type == 'ROT':
        min_rad = min_val * pi / 180
        max_rad = max_val * pi / 180
        if min_val == 0:
            num = 'var'
            denom = f'{max_rad}' if max_val != 0 else '1'
        else:
            num = f'var-({min_rad})'
            denom = f'{max_rad - min_rad}' if max_val != min_val else '1'
    else:
        if min_val == 0:
            num = 'var'
            denom = f'{max_val}' if max_val != 0 else '1'
        else:
            num = f'var-{min_val}'
            denom = f'{max_val - min_val}' if max_val != min_val else '1'

    base = f'min(max({num},0),1)' if denom == '1' else f'min(max(({num})/({denom}),0),1)'
    return f'pow({base},{power})' if power != 1.0 else base


class DRIVERHELPER_OT_show_text(bpy.types.Operator):
    bl_idname = 'driverhelper.show_text'
    bl_label = _ui_text('DriverHelper Formula', 'ドライバーヘルパー の式')
    bl_description = _ui_text(
        'Open a popup that shows the generated driver formula so you can copy it into a driver expression.',
        '生成したドライバー式をポップアップで表示し、式欄へコピーできるようにします。',
    )

    output_text: bpy.props.StringProperty(
        name=_ui_text('Formula', '式'),
        description=_ui_text(
            'Generated driver expression. Copy this text and paste it into a driver expression field.',
            '生成されたドライバー式です。この文字列をコピーして、ドライバーの式欄へ貼り付けます。',
        ),
    )  # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=600)

    def draw(self, context):
        layout = self.layout
        layout.label(text=_ui_text('Copy the formula for the driver:', 'ドライバー用の式をコピーしてください:', context))
        layout.prop(self, 'output_text', text='')

    def execute(self, context):
        return {'FINISHED'}


class DRIVERHELPER_OT_genformula_operator(bpy.types.Operator):
    bl_idname = 'driverhelper.genformula_operator'
    bl_label = _ui_text('Generate Driver Formula', 'ドライバー式を生成')
    bl_description = _ui_text(
        'Generate a ready-to-paste driver expression from the current DriverHelper settings.',
        '現在の ドライバーヘルパー 設定から、すぐに貼り付けられるドライバー式を生成します。',
    )

    def execute(self, context):
        scene = _safe_scene(context)
        if scene is None or not hasattr(scene, 'driver_helper_props'):
            self.report({'ERROR'}, _ui_text('DriverHelper settings are not available.', 'ドライバーヘルパー 設定を利用できません。', context))
            return {'CANCELLED'}
        props = scene.driver_helper_props
        mode = props.driverhelper_mode
        min_val = props.driverhelper_min
        max_val = props.driverhelper_max
        power = props.driverhelper_power

        if min_val == max_val:
            self.report({'ERROR'}, _ui_text('Min and Max cannot be the same value.', '最小値と最大値を同じ値にはできません。', context))
            return {'CANCELLED'}

        formula = driver_formula(min_val, max_val, mode, power)
        bpy.ops.driverhelper.show_text('INVOKE_DEFAULT', output_text=formula)
        return {'FINISHED'}


def update_driverhelper_mode(self, context):
    # Intentionally quiet. The original add-on printed to console on every click.
    return None


def draw_driver_helper_body(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False

    scene = _safe_scene(context)
    if scene is None or not hasattr(scene, 'driver_helper_props'):
        layout.label(text=_ui_text('DriverHelper settings are not available.', 'ドライバーヘルパー 設定を利用できません。', context), icon='ERROR')
        return

    if not _driverhelper_has_target(context):
        layout.label(text=_ui_text('Select a mesh object with Shape Keys.', 'シェイプキーのあるメッシュを選択', context))
        return

    props = scene.driver_helper_props
    row = layout.row(align=True)
    row.prop(props, 'driverhelper_mode', expand=True)

    col = layout.column(align=True)
    col.prop(props, 'driverhelper_min', text=_ui_text('Min', '最小', context))
    col.prop(props, 'driverhelper_max', text=_ui_text('Max', '最大', context))
    col.prop(props, 'driverhelper_power', text=_ui_text('Power', 'パワー', context))

    _icon_op(layout, 'driverhelper.genformula_operator', text=_ui_text('Generate Formula', '式を生成', context), icon_name='DRIVER', fallback='FILE_SCRIPT')


class DRIVERHELPER_PT_smarttools_panel(bpy.types.Panel):
    bl_label = _ui_text('Driver Helper', 'ドライバーヘルパー')
    bl_idname = 'DRIVERHELPER_PT_smarttools_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        draw_driver_helper_body(self.layout, context)

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'driver_helper', context)


_CLASSES = (
    DriverHelperProperties,
    DRIVERHELPER_OT_show_text,
    DRIVERHELPER_OT_genformula_operator,
)


def register(ledger):
    from .. import lifecycle
    for cls in _CLASSES:
        lifecycle.register_class(ledger, cls)
    lifecycle.register_rna_property(
        ledger,
        bpy.types.Scene,
        'driver_helper_props',
        bpy.props.PointerProperty(
            type=DriverHelperProperties,
            description=_ui_text(
                'Driver Helper N-panel settings used to generate Shape Key driver formulas.',
                'シェイプキードライバー式を生成するための ドライバーヘルパー の N パネル設定です。',
            ),
        ),
    )


def unregister():
    return None


if __name__ == '__main__':
    register()
