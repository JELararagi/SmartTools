# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import re

try:
    import bpy
except Exception:  # pragma: no cover - Blender-only module
    bpy = None

TRANSLATIONS_JA = { 'Per-Channel Calibration (EDIT Only)':'係数別校正（EDITのみ）',
 'Map neutral to0 and maximum to1 before EDIT gain/smoothing; RAW is preserved':'利得・平滑化前に無表情を0、最大を1へ写像。RAWは保持',
 'Load Per-Channel Calibration':'係数別の校正表を読む',
 'Save Per-Channel Calibration':'係数別の校正表を保存',
 'Calibration Format':'校正表の形式',
 'Calibration JSON':'JSONの校正表',
 'Calibration CSV':'CSVの校正表',
 'Load a calibration CSV/JSON table before enabling calibration.':'校正を有効にする前にCSV/JSONの校正表を読み込んでください。',
 'Load a calibration table before saving.':'保存する前に校正表を読み込んでください。',
 'Protecting an existing file; choose a new calibration filename.':'既存ファイルを保護します。新しい校正表の名前を選んでください。',
'Action key point limit exceeded.':'アクションのキーポイント読込上限を超えました。',
 'Action contains an invalid frame.':'アクションに無効なフレームが含まれています。',
 'Action has more than 4096 distinct key frames.':'アクションのキー時刻が4096点を超えています。',
 'No assigned ARKit shape-key Action frames were found.':'割り当て済みARKitシェイプキーアクションのキー時刻がありません。',
 'Restart the Action contact inspection.':'アクションの接触検査を新しく開始してください。',
 'The Action contact frame plan is invalid. Restart.':'接触検査のフレーム計画が無効です。新しく開始してください。',
 'The Action contact progress is invalid. Restart.':'接触検査の進捗が無効です。新しく開始してください。',
 'The Action contact rows do not match the frame plan. Restart.':'接触検査の結果とフレーム計画が一致しません。新しく開始してください。',
 'Source data, Actions, selection or the starting frame changed. Restart the inspection.':'元データ・アクション・選択・開始フレームが変わりました。検査を新しく開始してください。',
 'The Action contact status is invalid. Restart.':'接触検査の状態が無効です。新しく開始してください。',
 'This inspection has stopped. Start a new inspection.':'この検査は停止済みです。新しく開始してください。',
 'The contact diagnosis returned invalid surfaces.':'接触診断の相手部品情報が無効です。',
 'The contact diagnosis returned invalid contact counts.':'接触診断の交差数が無効です。',
 'The starting frame or source state could not be restored; progress was not saved.':'開始フレームまたは元データを復元できませんでした。進捗は保存していません。',
 'Mute the shape-key NLA tracks before inspecting the assigned Action.':'割り当てアクションの検査前にシェイプキーのNLAトラックをミュートしてください。',
 'The assigned Action has no active slot.':'割り当てアクションのアクティブスロットがありません。',
 'Only standard keyframe Action strips are supported.':'標準のキーフレームアクションストリップに対応しています。',
 'Activate the tongue and select two to four oral meshes in Object Mode.':'オブジェクトモードで舌をアクティブにし、口内部品を2～4メッシュ選択してください。',
 'Use an editable local scene for the Action contact report.':'アクションの接触検査には編集可能なローカルシーンを使用してください。',
 'An assigned ARKit Action curve is muted or invalid.':'割り当てARKitアクションのカーブがミュート中、または無効です。',
 'Action contact dependency depth exceeded.':'接触検査の参照深度上限を超えました。',
 'Action contact dependency item limit exceeded.':'接触検査の参照項目数上限を超えました。',
 'Action contact source coordinate limit exceeded.':'接触検査の元座標読込上限を超えました。',
 'Action contact dependency ID limit exceeded.':'接触検査の参照データ数上限を超えました。',
 'This Action contact batch does not support simulation or this modifier type.':'このアクション分割検査はシミュレーションまたは指定モディファイアに未対応です。',
 'Action contact mesh topology limit exceeded.':'接触検査のメッシュ構造読込上限を超えました。',
 'Action contact attribute item limit exceeded.':'接触検査の属性読込上限を超えました。',
 'Unsupported contact dependency. Use the single-frame report instead.':'未対応の参照データがあります。単一フレームの接触レポートを使用してください。',
 'Start an Action contact inspection first.':'先にアクションの接触検査を開始してください。',
 'Action contact report exceeds the read limit.':'アクションの接触レポート読込上限を超えました。',
 'The Action contact report was edited. Start a new inspection.':'アクションの接触レポートが編集されています。検査を新しく開始してください。',
 'Blender did not reach the requested Action frame.':'Blenderが指定したアクションフレームへ移動できませんでした。',
 'Action contact report exceeds the write limit; progress was not saved.':'アクションの接触レポート保存上限を超えました。進捗は保存していません。',
 'Inspect Four Action Key Frames':'アクションのキー時刻を4点検査',
 'Inspect up to four assigned ARKit Action key frames and restore the starting frame; stop on contact':'割当ARKitアクションのキー時刻を最大4点検査し開始フレームへ戻す。接触時は停止。',
 'Start New Inspection':'新しく検査を開始',
 'First × (1 − Second)':'1つ目入力・2つ目解除',
 'First Input with Second Released':'1つ目入力・2つ目解除',
 'First input times one minus second input; fixed centers one and zero.':'1つ目の入力×（1−2つ目の入力）。中心値は1と0に固定。',
 'Complementary inputs require centers 1 and 0.':'解除型の中心値は1と0にしてください。',
 'Live Target Group': 'ライブ対象グループ',
 'Mapping Settings': 'マッピング設定',
 'Handle / Values': 'ハンドル / 値',
 ' (Frame Sync enabled)': '（フレーム同期を有効化）',
 ' failed because the mesh no longer has the same number of vertices after applying the selected modifiers.': ' '
                                                                                                              'は、選択モディファイア適用後にメッシュの頂点数が一致しなくなったため失敗しました。',
 ' on shape key ': '、シェイプキー: ',
 '1pt (Proj)': '1点投影',
 '2pt (Dist)': '2点距離',
 '3D Cursor': '3Dカーソル',
 '3D View was not found.': '3Dビュー が見つかりません。',
 '<- Click Add to create a group first.': '← 先に追加でグループを作成してください。',
 '<Select>': '<選択>',
 'About': '説明',
 'Active Object': 'アクティブ',
 'Active Smart Shapekey map index shown in the N-panel map list.': 'Nパネルのマップリストに表示されるアクティブな Smart Shapekey マップ番号です。',
 'Active object is not a mesh.': 'アクティブオブジェクトがメッシュではありません。',
 'Active object must be a mesh.': 'アクティブオブジェクトはメッシュである必要があります。',
 'Add Global Preset': 'グローバルプリセットを追加',
 'Add Group': 'グループを追加',
 'Add Mapping': 'マッピングを追加',
 'Add Target': '対象を追加',
 'Add a new ShapeKey mapping to the current group.': '現在のグループへ新しいシェイプキーマッピングを追加します。',
 'Add a new object-and-group target entry for the face tracker.': 'フェイストラッカー用のオブジェクト・グループ対象を新しく追加します。',
 'All': '全て',
 'Allow dragging mapping points directly inside the Axis HUD to change their X and Y target positions.': 'シェイプ軸 HUD 内でマッピング点を直接ドラッグし、X と Y の目標位置を調整できるようにします。',
 'Allow or block direct dragging of mapping points inside the Axis UI HUD. Turn it off to avoid accidental edits while keeping the HUD available.': 'シェイプ軸 '
                                                                                                                                                    'HUD '
                                                                                                                                                    '内でマッピング点を直接ドラッグできるかどうかを切り替えます。HUDを表示したまま誤操作を避けたい場合はオフにしてください。',
 'Always Active': '常時有効',
 'Always-on Toggles draw failed.': '常時機能切り替えの描画に失敗しました。',
 'Always-on Toggles': '常時機能切り替え',
 'An unexpected error occurred.': '予期しないエラーが発生しました。',
 'Animation': 'アニメーション',
 'Apply Modifier(s) for Mesh with Shape Keys': 'シェイプキー保持で適用',
 'Apply Modifiers While Keeping Shape Keys': 'シェイプキーを保持してモディファイア適用',
 'Apply Keeping Shape Keys': 'シェイプキー保持で適用',
 'Apply Tracking Preset': 'トラッキングプリセットを適用',
 'Apply failed.': '適用に失敗しました。',
 'Apply the saved joystick coordinates from this preset to all groups across all objects.': 'このプリセットに保存されたジョイスティック座標を、すべてのオブジェクト・すべてのグループへ適用します。',
 'Auto': '自動',
 'Automatic initialization is pending for this tool.': 'このツールは自動初期化待機中です。',
 'Automatic retry occurs when the suite runtime refreshes.': 'ツールセット実行時が更新されると自動的に再試行されます。',
 'Automatically choose the most suitable falloff behavior.': '最適な減衰方法を自動で選びます。',
 'Automatically generate symmetrical ShapeKey mappings for .L・.R style name pairs.': '.L・.R などの名前ペアから、左右対称の '
                                                                                     'シェイプキーマッピングを自動生成します。',
 'Axis': '軸',
 'Axis UI': 'シェイプ軸 HUD',
 'Axis UI Point Drag': 'シェイプ軸 HUD ポイントドラッグ',
 'Bake Animation': 'アニメーションをベイク',
 'Bake Animation to Shape Keys': 'アニメーションをシェイプキーにベイク',
 'Bake every Nth frame. Use 1 to bake every frame.': '何フレームごとにベイクするかを指定します。1 なら毎フレームです。',
 'Bake the animated joystick logic into raw Shape Key keyframes for export such as FBX or glTF.': 'アニメーションしたジョイスティック制御を、FBX や glTF などへ書き出しやすいシェイプキーキーフレームへベイクします。',
 'Basis cannot be deleted.': 'Basisは削除できません。',
 'Blend': 'ブレンド',
 'Blend Mode': 'ブレンドモード',
 'Blink': 'まばたき',
 'Box Falloff': 'ボックス減衰',
 'CONFIG resource path is empty': 'CONFIGリソースパスが空です。',
 'Call': '呼び出し',
 'Call Global Preset': 'グローバルプリセットを呼び出し',
 'Call this preset and immediately insert keyframes for all affected Shape Keys.': 'このプリセットを呼び出した直後に、影響するすべてのシェイプキーへキーフレームを挿入します。',
 'Camera': 'カメラ',
 'Camera Index': 'カメラ番号',
 'Camera device index used by the built-in Face Tracker. Change this when the tracker opens the wrong webcam.': '内蔵 '
                                                                                                                'Face '
                                                                                                                'Tracker '
                                                                                                                'が使うカメラデバイス番号です。別のウェブカメラを開いてしまう場合はここを変更してください。',
 'Capture Max': '最大を取得',
 'Capture Min': '最小を取得',
 'Capture X Max': 'X 最大を取得',
 'Capture X Min': 'X 最小を取得',
 'Capture Y Max': 'Y 最大を取得',
 'Capture Y Min': 'Y 最小を取得',
 'Center': '中心',
 'Center X': '中心X',
 'Center Y': '中心Y',
 'Center Z': '中心Z',
 'Choose Modifiers': 'モディファイアを選択',
 'Choose how the controller distance is converted into Shape Key influence for this mapping point.': 'このマッピング点で、コントローラー位置の距離をシェイプキーの影響量へどう変換するかを選びます。',
 'Choose how the face tracker calculates the X-axis input for this group.': 'このグループの X 軸入力を、フェイストラッカーがどの方法で計算するかを選びます。',
 'Choose how the face tracker calculates the Y-axis input for this group.': 'このグループの Y 軸入力を、フェイストラッカーがどの方法で計算するかを選びます。',
 'Choose maps to import': '読み込むマップを選択',
 'Choose the UV map used as the correspondence key. The tool reconstructs shapes by sampling in UV space.': '対応付けに使うUVマップを選びます。本ツールは“UV空間でサンプリング”して形状を復元するため、別トポロジーでもUVが同じなら復元できます。',
 'Choose where the grid starts.': '配置の開始位置を選びます。',
 'Choose whether the operation uses all maps or only maps marked Select.': '処理対象をすべてのマップにするか、Select '
                                                                           'が付いたマップだけにするかを選びます。',
 'Choose whether the selected map moves up or down in the map list.': '選択中のマップをマップリスト内で上へ移動するか下へ移動するかを選びます。',
 'Choose which maps to import from the file.': 'ファイルから読み込むマップを選択します。',
 'Choose which side is copied across the mirror plane: left to right or right to left.': 'ミラー平面をまたいでコピーする方向を選びます。左から右、または右から左を選択できます。',
 'Choose which transform channel the generated driver formula should read from: Location, Rotation, or Scale.': '生成するドライバー式が参照する変形チャンネルを選びます。Location・Rotation・Scale '
                                                                                                                'のどれを使うか決めます。',
 'Clean Orphans': '孤立キャッシュ掃除',
 'Clean Orphans (Scene)': 'シーン内の全孤立キャッシュを掃除',
 'Cleanup': 'クリーンアップ',
 'Columns': '列数',
 'Control / Tracking': '制御・トラッキング',
 'Copy Selected Verts': '選択頂点のコピー',
 'Copy positions of currently selected vertices into an internal clipboard.': '現在選択中の頂点座標を内部クリップボードにコピーします。',
 'Copy the formula for the driver:': 'ドライバー用の式をコピーしてください:',
 'Create a base snapshot (Basis) used as reference. This does NOT change the current mesh.': '基準となるベース（Basis）を作成します。現在のメッシュ形状は変更しません（UVと形状を参照データとして保存するだけです）。',
 'Create a driver expression from Location, Rotation, or Scale.': 'Location・Rotation・Scale からドライバー式を作成します。',
 'Create a duplicated map, inverted around Basis (new = 2*Basis - Map).': '選択中のマップをベース基準で反転して複製します（新 = 2*Basis − '
                                                                          '元マップ）。',
 'Create a new ShapeKey control group for the active object.': 'アクティブオブジェクトに新しいシェイプキー制御グループを作成します。',
 'Create a new global animation preset.': '新しいアニメーションプリセットを作成します。',
 'Create a new map from the current mesh shape. The mesh shape is not changed.': '現在の形状から新しいマップを作成します。現在のメッシュ形状は変更しません。',
 'Create clean mesh objects for each map, placed in a grid.': '各マップをクリーンオブジェクトとして生成し、グリッド配置します。',
 'Create the First Group to Set Up': '最初のグループを作成して設定開始',
 'Current horizontal joystick value for this group. This can be keyed, driven, or adjusted from the HUD.': 'このグループの現在の水平ジョイスティック値です。キーフレーム、ドライバー、HUD '
                                                                                                           'から調整できます。',
 'Current vertical joystick value for this group. This can be keyed, driven, or adjusted from the HUD.': 'このグループの現在の垂直ジョイスティック値です。キーフレーム、ドライバー、HUD '
                                                                                                         'から調整できます。',
 'Curve (Exp)': 'カーブ（指数）',
 'Curve exponent applied to the raw X-axis tracker signal before final output.': '最終出力前に、生の X 軸トラッカー信号へ掛けるカーブ指数です。',
 'Curve exponent applied to the raw Y-axis tracker signal before final output.': '最終出力前に、生の Y 軸トラッカー信号へ掛けるカーブ指数です。',
 'Curve exponent for easing. 1.0 keeps the response linear, values above 1.0 ease in, and values below 1.0 ease out.': '補間カーブの指数です。1.0 '
                                                                                                                       'は線形、1.0 '
                                                                                                                       'より大きいとイーズイン、1.0 '
                                                                                                                       'より小さいとイーズアウトになります。',
 'Deferred until use': '使用時に読み込み',
 'Delete ALL data created by this tool from ALL objects in the scene.': 'シーン内全オブジェクトから本ツール関連データをすべて削除します。',
 'Delete ALL data created by this tool on the selected object.': '選択オブジェクトの本ツール関連データをすべて削除します。',
 'Delete Map': 'マップ削除',
 'Delete the currently selected ShapeKey control group.': '現在選択中のシェイプキー制御グループを削除します。',
 'Delete the currently selected global animation preset.': '現在選択中のアニメーションプリセットを削除します。',
 'Delete the selected map (locked maps cannot be deleted).': '選択中のマップを削除します（ロック中は削除できません）。',
 'Dependencies Missing': '依存関係が不足しています',
 'Deselect All': '全選択解除',
 'Direct dragging of mapping points inside the Axis UI HUD.': 'シェイプ軸 HUD 内のマッピング点を直接ドラッグする機能です。',
 'Direction': '方向',
 'Direction to move the selected item.': '選択項目を移動する方向です。',
 'Disable tracking for the X axis.': 'X 軸のトラッキングを無効にします。',
 'Disable tracking for the Y axis.': 'Y 軸のトラッキングを無効にします。',
 'Disabled': '無効',
 'Disabled in Tool Settings': 'ツール設定で無効',
 'Distance between generated objects. Example: 0.5 means 50cm if your scene uses meters.': '生成オブジェクト同士の間隔です。例：シーン単位がmなら0.5で50cm。',
 'Done.': '完了しました。',
 'Down': '下へ',
 'Driver': 'ドライバー',
 'Driver Helper': 'ドライバーヘルパー',
 'Driver Mode': 'ドライバーモード',
 'DriverHelper Formula': 'ドライバーヘルパーの式',
 'DriverHelper settings are not available.': 'ドライバーヘルパー設定を利用できません。',
 'Drivers': 'ドライバー',
 'Duplicate Inverted': '反転で複製',
 'Duplicate Map': '複製',
 'Duplicate the selected map as a new map.': '選択中のマップを複製して新規マップとして追加します。',
 'Each bundled tool is always active while Smart Shapekey is enabled. Usage details are available in tooltips.': 'Smart Shapekey が有効な間、移植済みツールは常に有効です。このセクションでは概要と使い方のみを表示します。',
 'Edit X and Y Values': 'X と Y の値を編集',
 'Editing': '編集',
 'Enable': '有効化',
 'Enable Drag Point': 'ポイントドラッグを有効化',
 'Enable Filter': 'フィルターを有効化',
 'Enable frame-change updates for animated Shape Axis handles. Turn this on only while you need the joystick values to follow the timeline during playback or scrubbing, and leave it off when idle to keep Blender lighter.': 'タイムライン再生やスクラブ中にシェイプ軸のハンドル値を自動更新したいときだけ ON にしてください。未使用時は OFF のままにすると、常時フレーム変更コールバックを止めて Blender を軽くできます。',
 'Enable or disable a long-running Smart Shapekey feature from the unified Always-on Toggles group.': '統合された常時機能切り替えグループから、Smart '
                                                                                                      'Shapekey '
                                                                                                      'の常駐機能を有効または無効にします。',
 'Enable or disable every map entry in the current import selection dialog.': '現在の読み込み選択ダイアログ内にあるすべてのマップ項目を有効または無効にします。',
 'Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.': '3Dビュー内のフェイストラッカーランドマークオーバーレイを有効または無効にします。このオーバーレイは内蔵 '
                                                                                                                                              'Face '
                                                                                                                                              'Tracker '
                                                                                                                                              'の実行中のみ描画されます。',
 'Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.': 'タイムライン再生やスクラブ中にシェイプ軸ハンドルを更新するフレーム変更ハンドラを有効または無効にします。アニメーション済みジョイスティック値を現在フレームに追従させる必要がない場合はオフにしてください。',
 'Enabled': '有効',
 'End Frame': '終了フレーム',
 'Exact X coordinate to write into the current group joystick.': '現在のグループのジョイスティックへ書き込む正確な X 座標です。',
 'Exact Y coordinate to write into the current group joystick.': '現在のグループのジョイスティックへ書き込む正確な Y 座標です。',
 'Export': '書き出し',
 'Export Group Settings': 'グループ設定を書き出し',
 'Export JSON': 'JSON を書き出し',
 'Export all or selected maps as Shape Keys on the active object.': '全てまたは選択中のマップをシェイプキーとしてアクティブオブジェクトに書き出します。',
 'Export the current ShapeKey group mappings to a JSON file.': '現在のシェイプキーグループのマッピングを JSON ファイルへ書き出します。',
 'Export to Objects': 'オブジェクトに書き出し',
 'Export to Shape Keys': 'シェイプキーへ書き出し',
 'External Smart Shapekey map file currently being inspected for import.': '読み込み対象として現在検査中の外部 Smart Shapekey '
                                                                           'マップファイルです。',
 'External Smart Shapekey map file to load.': '読み込む外部 Smart Shapekey マップファイルです。',
 'External Tracker (UDP)': '外部トラッカー（UDP）',
 'External file path where Smart Shapekey map data is saved.': 'Smart Shapekey マップデータを保存する外部ファイルパスです。',
 'Extra gain multiplier applied to the X-axis tracker output.': 'X 軸トラッカー出力へ追加で掛けるゲイン倍率です。',
 'Extra gain multiplier applied to the Y-axis tracker output.': 'Y 軸トラッカー出力へ追加で掛けるゲイン倍率です。',
 'Eyes': '目',
 'Face Tracker (Built-In)': 'フェイストラッカー（内蔵）',
 'Face Tracker Point HUD': 'フェイストラッカーポイントHUD',
 'Failed to create a valid temporary object with Shape Keys.': 'シェイプキー付きの有効な一時オブジェクトを作成できませんでした。',
 'Failed to prepare shape key: ': 'シェイプキーの準備に失敗しました: ',
 'Failed to restore driver for ': 'ドライバーの復元に失敗しました: ',
 'Failed to switch the feature.': '機能の切り替えに失敗しました。',
 'Failed. Check console for details.': '失敗しました。詳細はコンソールを確認してください。',
 'Feature': '機能',
 'File browser filter that shows Smart Shapekey map files.': 'Smart Shapekey マップファイルを表示するファイルブラウザー用フィルターです。',
 'Fill the current tracker settings with a prepared mouth, eye, or blink preset.': '現在のトラッカー設定へ、口・目・まばたき用の準備済みプリセットを入れます。',
 'First frame included in the bake range.': 'ベイク範囲に含める最初のフレームです。',
 'First landmark index used for X-axis tracking.': 'X 軸トラッキングに使う 1 つ目のランドマーク番号です。',
 'First landmark index used for Y-axis tracking.': 'Y 軸トラッキングに使う 1 つ目のランドマーク番号です。',
 'Formula': '式',
 'Frame Sync': 'フレーム同期',
 'Frame-change handler that updates animated Shape Axis handles.': 'アニメーションしたシェイプ軸ハンドルを更新するフレーム変更ハンドラです。',
 'Full Cleanup': '全てクリーンナップ',
 'Full Cleanup (Scene)': 'シーン内を全てクリーンナップ',
 'Gain': 'ゲイン',
 'Generate Driver Formula': 'ドライバー式を生成',
 'Generate Formula': '式を生成',
 'Generate a ready-to-paste driver expression from the current DriverHelper settings.': '現在のドライバーヘルパー '
                                                                                        '設定から、すぐに貼り付けられるドライバー式を生成します。',
 'Global Animation Presets': 'アニメーションプリセット',
 'Group': 'グループ',
 'Group Name': 'グループ名',
 'Groups': 'グループ',
 'Help': 'ヘルプ',
 'Help content is not available for this tool.': 'このツールのヘルプ内容は利用できません。',
 'Help popup draw failed.': 'ヘルプポップアップの描画に失敗しました。',
 'Horizontal target position of this mapping point inside the Axis controller. Move farther from the center to react at a larger X range.': 'シェイプ軸コントローラー内でのこのマッピング点の水平目標位置です。中心から離すほど、より大きい X 範囲で反応します。',
 'How many objects per row before wrapping to next row.': '横に並べる数（この数で折り返して次の行に移ります）。',
 'How strongly the X-axis smoothing filter blends toward the new value each update.': '更新ごとに X '
                                                                                      '軸スムージングが新しい値へどれだけ寄せるかを決めます。',
 'How strongly the Y-axis smoothing filter blends toward the new value each update.': '更新ごとに Y '
                                                                                      '軸スムージングが新しい値へどれだけ寄せるかを決めます。',
 'How to Use': '使い方',
 'If enabled, this map will be included when using Selected export/save.': 'ONにすると「選択のみ」の書き出しまたは保存に含まれます。',
 'Import / Export': '読み込み・書き出し',
 'Import Group Settings': 'グループ設定を読み込み',
 'Import JSON': 'JSON を読み込み',
 'Import ShapeKey group mappings from a JSON file.': 'JSON ファイルからシェイプキーグループのマッピングを読み込みます。',
 'Imported Group': '読み込みグループ',
 'Influence radius around this mapping point. Larger values make the Shape Key react across a wider area of the controller.': 'このマッピング点の影響半径です。値を大きくすると、コントローラー内のより広い範囲でシェイプキーが反応します。',
 'Input Range': '入力範囲',
 'Insert Keyframe for Global Preset': 'グローバルプリセットへキー挿入',
 'Insert keyframes for the current group joystick handle at the current frame.': '現在フレームで、現在のグループのジョイスティックハンドルへキーフレームを挿入します。',
 'Install Face Tracker Requirements': '必要環境をインストール',
 'Install the Python packages required by the built-in Face Tracker into Blender’s Python environment.': '内蔵 Face '
                                                                                                         'Tracker に必要な '
                                                                                                         'Python '
                                                                                                         'パッケージを '
                                                                                                         'Blender の '
                                                                                                         'Python '
                                                                                                         '環境へインストールします。',
 'Installation is already running.': 'インストールはすでに実行中です。',
 'Installed successfully.': 'インストールに成功しました。',
 'Installing (this may take a few minutes)...': 'インストール中です（数分かかる場合があります）...',
 'Integrated Add-on Info': '統合アドオン情報',
 'Interactive 2D HUD Axis controller in the 3D Viewport.': '3Dビューポート内の対話式のシェイプ軸 HUD です。',
 'Internal channel ID that links this map entry to its hidden UV storage layers.': 'このマップ項目と非表示UV保存レイヤーを結び付ける内部チャンネルIDです。',
 'Internal guard that temporarily blocks automatic map application while the tool updates stored data.': 'ツールが保存データを更新している間、自動マップ適用を一時的に止める内部ガードです。',
 'Internal help topic identifier.': '内部ヘルプトピック識別子です。',
 'Internal list of Smart Shapekey maps detected in the selected import file.': '選択した読み込みファイル内で検出された Smart Shapekey '
                                                                               'マップの内部リストです。',
 'Internal switch used by the import dialog to disable every listed map.': '読み込みダイアログで一覧内のすべてのマップを無効にするための内部スイッチです。',
 'Internal switch used by the import dialog to enable every listed map.': '読み込みダイアログで一覧内のすべてのマップを有効にするための内部スイッチです。',
 'Invalid JSON format.': 'JSON 形式が不正です。',
 'Invalid file.': 'ファイルが不正です。',
 'Invert Selected Shape': '選択頂点の形状を反転',
 'Invert the current selection around Basis (selected verts only).': '選択頂点のみをベース（Basis）基準で反転します。',
 'Iris': '虹彩',
 'It is always active while Smart Shapekey is enabled.': 'スマートシェイプキーが有効な間は常に有効です。',
 'Item': '項目',
 'Items': '項目',
 'Joystick X': 'ジョイスティック X',
 'Joystick Y': 'ジョイスティック Y',
 'Keep Map Shapes': 'マップ形状を保持',
 'Key': 'キー',
 'Key Handle [I]': 'ハンドルにキー [I]',
 'Keyframe Handle': 'ハンドルにキーフレーム',
 'Keyframes inserted for the handle': 'ハンドルにキーフレームを挿入しました',
 'Landmark overlay for the built-in Face Tracker.': '内蔵フェイストラッカー用のランドマークオーバーレイです。',
 'Last frame included in the bake range.': 'ベイク範囲に含める最後のフレームです。',
 'Live List Group': 'ライブ対象グループ',
 'Load': '読み込み',
 'Load failed': '読み込み失敗',
 'Load maps from an external file. A popup lets you choose which maps to import.': '外部ファイルからマップを読み込みます。ポップアップで読み込むマップを選べます。',
 'Loaded': '読み込み済み',
 'Location channel': '位置チャンネル',
 'Lock': 'ロック',
 'Lock the map to prevent deletion.': 'ロックすると削除できなくなります。',
 'Locked map cannot be deleted.': 'ロック中のマップは削除できません。',
 'Long-running feature to enable or disable.': '有効または無効にする常駐機能です。',
 'Lower Bound': '下限',
 'Lower input bound used by the formula. The driver stays at 0 until the source reaches this value.': '式の下限入力値です。元の値がここに達するまではドライバー出力を '
                                                                                                      '0 のままにします。',
 'Lower tracked input bound for X-axis normalization.': 'X 軸の正規化に使う入力下限値です。',
 'Lower tracked input bound for Y-axis normalization.': 'Y 軸の正規化に使う入力下限値です。',
 "Manually input exact X and Y coordinates for the current group's joystick.": '現在のグループのジョイスティックに対して、正確な X と Y '
                                                                               '座標を手入力します。',
 'Map name (must be unique). Click to rename.': 'マップ名です（重複不可）。クリックしてリスト上で直接リネームできます。',
 'Map name found in the selected external map file.': '選択した外部マップファイル内で見つかったマップ名です。',
 'Map name must be unique.': 'マップ名は重複できません。',
 'Mappings': 'マッピング',
 'Maps': 'マップ',
 'Map Count': 'マップ数',
 'Max': '最大',
 'Max Target': '最大出力',
 'Maximum distance to find the mirrored counterpart vertex. Increase if vertices do not match.': 'ミラー先頂点を探す最大距離です。対応が取れない場合は少し増やしてください。',
 'Maximum output value sent to the X joystick channel after normalization.': '正規化後に X ジョイスティックへ送る最大出力値です。',
 'Maximum output value sent to the Y joystick channel after normalization.': '正規化後に Y ジョイスティックへ送る最大出力値です。',
 'Menu': 'メニュー',
 'Menus': 'メニュー',
 'Mesh has no faces.': 'メッシュに面がありません。',
 'Migrated Tool': '移植ツール',
 'Min': '最小',
 'Min Target': '最小出力',
 'Min and Max cannot be the same value.': '最小値と最大値を同じ値にはできません。',
 'Minimum output value sent to the X joystick channel after normalization.': '正規化後に X ジョイスティックへ送る最小出力値です。',
 'Minimum output value sent to the Y joystick channel after normalization.': '正規化後に Y ジョイスティックへ送る最小出力値です。',
 'Mirror Axis': 'ミラー軸',
 'Mirror Center': 'ミラー中心',
 'Mirror Epsilon': 'ミラー許容値',
 'Mirror Mappings': 'マッピングを左右反転',
 'Mirror Selected': '選択頂点をミラー',
 'Mirror Selected (L→R)': '選択頂点の形状をミラー（左→右）',
 'Mirror Selected (R→L)': '選択頂点の形状をミラー（右→左）',
 'Mirror Settings': 'ミラー設定',
 'Mirror Tools': 'ミラーと反転ツール',
 'Mirror axis used by mirror tools.': 'ミラーに使用する軸です。',
 'Mirror center coordinate. Usually 0.0 for symmetrical models.': 'ミラー中心座標です。左右対称モデルなら通常0.0です。',
 'Mirror selected vertices shape (uses mirror settings).': 'ミラー設定を使い、選択頂点の形状を反対側へ写します。',
 'Modifier': 'モディファイア',
 'Modifiers': 'モディファイア',
 'Mouth': '口',
 'Move': '移動',
 'Move Down': '下へ',
 'Move Group': 'グループを移動',
 'Move Mapping': 'マッピングを移動',
 'Move Preset': 'プリセットを移動',
 'Move Up': '上へ',
 'Move the selected ShapeKey group up or down in the list.': '選択中のシェイプキーグループを一覧内で上下へ移動します。',
 'Move the selected ShapeKey mapping up or down in the list.': '選択中のシェイプキーマッピングを一覧内で上下へ移動します。',
 'Move the selected global animation preset up or down in the list.': '選択中のアニメーションプリセットを一覧内で上下へ移動します。',
 'Move the selected item downward.': '選択項目を下へ移動します。',
 'Move the selected item upward.': '選択項目を上へ移動します。',
 'N-panel List': 'Nパネル一覧',
 'N-panel Menu': 'Nパネルメニュー',
 'N-panel Pie Menu': 'Nパネルパイメニュー',
 'Name': '名前',
 'Name of this Shape Axis group. Each group stores one joystick handle and a list of Shape Key mappings.': 'このシェイプ軸グループの名前です。各グループは 1 つのジョイスティックハンドルとシェイプキーマッピング一覧を持ちます。',
 'Name of this global preset. Use presets to store joystick positions for multiple objects and groups at once.': 'このグローバルプリセットの名前です。複数オブジェクト・複数グループのジョイスティック位置をまとめて保存できます。',
 'New Group': '新規グループ',
 'New Map': '新規マップ',
 'New Preset': '新規プリセット',
 'No UV layers found.': 'UVレイヤーが見つかりません。',
 'No collection was available for the temporary duplicate object.': '一時複製オブジェクトを配置するコレクションが見つかりませんでした。',
 'No direct operator or menu entry was found.': '直接呼び出せるオペレーターやメニューが見つかりませんでした。',
 'No feature was selected.': '機能が選択されていません。',
 'No migrated tools were found in this package.': 'このパッケージには移植済みツールが見つかりません。',
 'No modifiers selected.': 'モディファイアが選択されていません。',
 'No settings are registered.': '登録済みの設定項目がありません。',
 'No valid Shape Keys are mapped in this group.': 'このグループには有効なシェイプキーマッピングがありません。',
 'No valid selected modifiers were found on the active object.': 'アクティブオブジェクトに有効な選択モディファイアがありません。',
 'None': 'なし',
 'Object': 'オブジェクト',
 'Object has no Shape Keys.': 'オブジェクトにシェイプキーがありません。',
 'Object that receives the face-tracker output.': 'フェイストラッカーの出力を受け取るオブジェクトです。',
 'Open Feature Map': '特徴点マップを開く',
 "Open a checklist dialog that lets you apply selected modifiers while preserving the mesh's Shape Keys.": 'シェイプキーを保持したまま、適用したいモディファイアだけをチェックして実行するダイアログを開きます。',
 'Open a help popup for this Smart Shapekey tool.': 'この Smart Shapekey ツールのヘルプポップアップを開きます。',
 'Open a popup that shows the generated driver formula so you can copy it into a driver expression.': '生成したドライバー式をポップアップで表示し、式欄へコピーできるようにします。',
 'Open mirror settings (axis / center / tolerance).': 'ミラー設定（軸・中心・許容距離）を開きます。',
 'Open operator choices from the Smart Shapekey N-panel.': 'Smart Shapekey のNパネルからオペレーター選択一覧を開きます。',
 'Open or close the Always-on Toggles group at the top of the N-panel. It is closed by default to avoid unnecessary drawing and detection work during startup and normal display.': 'Nパネル上部の常時機能切り替えグループを開閉します。起動時や通常表示時の不要な描画・検出処理を避けるため、初期状態では閉じています。',
 'Open or close the Smart Shapekey controls from the Smart Shapekey N-panel. Use this suite to set a base shape, store UV-based maps, mirror selected vertices, export Shape Keys or objects, and clean tool data.': 'Smart '
                                                                                                                                                                                                                     'Shapekey '
                                                                                                                                                                                                                     'からスマートシェイプキー操作を開閉します。ベース形状の設定、UV基準マップ保存、選択頂点のミラー、シェイプキーやオブジェクトへの書き出し、ツールデータ整理に使います。',
 'Open or close the Smart Shapekey controls from the Smart Shapekey N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.': 'Smart '
                                                                                                                                                                                                                           'Shapekey '
                                                                                                                                                                                                                           'からスマートシェイプキー操作を開閉します。ベース形状の設定、UV基準マップ保存、頂点編集のミラー、マップファイルの保存と読み込み、結果の書き出し、ツールデータ整理に使います。',
 'Open the landmark reference image with your OS default viewer.': 'ランドマーク参照画像を OS の既定ビューアで開きます。',
 'Open the original dialog and choose which modifiers to apply.': '元アドオンのダイアログを開き、適用するモディファイアを選びます。',
 'Open the tool settings in the N-panel': 'Nパネルのツール設定を開きます。',
 'Open this menu from the Smart Shapekey N-panel.': 'Smart Shapekey のNパネルからこのメニューを開きます。',
 'Open this pie menu from the Smart Shapekey N-panel.': 'Smart Shapekey のNパネルからこのパイメニューを開きます。',
 'Operators': 'オペレーター',
 'Original panel has no draw function.': '元パネルに draw 関数がありません。',
 'Other': 'その他',
 'Output Signal Tuning': '出力信号調整',
 'Overview': '概要',
 'Panel draw failed': 'パネル描画に失敗しました',
 'Paste Mirrored': '反転して貼り付け',
 'Paste Verts': '頂点の貼り付け',
 'Paste copied vertex positions back to the currently selected vertices.': 'コピーした頂点座標を、現在選択中の頂点へ貼り付けます。',
 'Paste copied vertex positions mirrored (uses mirror settings).': 'コピーした頂点座標をミラーして貼り付けます（ミラー設定を使用）。',
 'Persistent Smart Shapekey N-panel settings stored outside the add-on preferences UI.': 'アドオンプリファレンスUIではなく外部保存される '
                                                                                               'Smart Shapekey '
                                                                                               'のNパネル永続設定です。',
 'Please run Set Base first.': '先に「ベースを設定」を実行してください。',
 'Point A': '点 A',
 'Point B': '点 B',
 'Power': 'パワー',
 'Preset Name': 'プリセット名',
 'Previous internal map name used to restore the value when a duplicate name is rejected.': '重複名が拒否されたときに値を復元するための直前の内部マップ名です。',
 'Project one point relative to another along the face axis.': '顔の軸に沿って 1 点を別の点に対して投影します。',
 'Quick Access': 'クイックアクセス',
 'Radial Falloff': '放射状減衰',
 'Radius': '半径',
 'React mainly along the X axis.': '主に X 軸方向に反応させます。',
 'React mainly along the Y axis.': '主に Y 軸方向に反応させます。',
 'Receive joystick values from an external app over UDP.': '外部アプリから UDP でジョイスティック値を受け取ります。',
 'Reference Map': '参照マップ',
 'Reference map image was not found.': '参照マップ画像が見つかりませんでした。',
 'Remove Global Preset': 'グローバルプリセットを削除',
 'Remove Group': 'グループを削除',
 'Remove Mapping': 'マッピングを削除',
 'Remove Target': '対象を削除',
 'Remove hidden/unused internal map data that is not listed.': 'リストに表示されていない隠れマップや不要な内部データを削除します。',
 'Remove the currently selected ShapeKey mapping from the group.': '現在選択中のシェイプキーマッピングをグループから削除します。',
 'Remove the currently selected face-tracker target entry.': '現在選択中のフェイストラッカー対象エントリーを削除します。',
 'Reorder the map list. Export order follows this list order.': 'マップリストを並び替えます。書き出しの順もこの並び順に従います。',
 'Report Message': '報告メッセージ',
 'Reset': 'リセット',
 'Reset All': 'すべてリセット',
 'Reset All Handles': 'すべてのハンドルをリセット',
 'Reset HUD': 'HUD をリセット',
 'Reset Handle': 'ハンドルをリセット',
 'Reset Modal HUD': 'モーダル HUD をリセット',
 'Reset Position': '位置をリセット',
 'Reset every joystick handle across all groups and objects to center (0.0, 0.0).': 'すべてのオブジェクト・すべてのグループのジョイスティックハンドルを中央 '
                                                                                    '(0.0, 0.0) に戻します。',
 'Reset the Axis UI position back to its default on-screen location.': 'シェイプ軸 HUD の位置を既定の画面内位置へ戻します。',
 'Reset the active group joystick handle to center (0.0, 0.0).': 'アクティブグループのジョイスティックハンドルを中央 (0.0, 0.0) に戻します。',
 'Rotation channel': '回転チャンネル',
 'Run orphan cleanup for all objects in the scene using this tool.': 'シーン内で本ツールを使っている全オブジェクトに孤立掃除を実行します。',
 'Save (All)': '全て保存',
 'Save Map File': 'マップファイルを保存',
 'Overwrite Map File': 'マップファイルの上書き',
 'Replace the existing map file with the current maps.': '既存のマップファイルを今のマップで置き換えます。',
 'This file already exists: {name}': 'このファイルは既にあります: {name}',
 'Overwrite': '上書き',
 'Save (Selected)': '選択を保存',
 'Save all maps to an external file.': '全マップを外部ファイルに保存します。',
 'Save only maps with the Select checkbox enabled in the list.': 'リストのSelectがONのマップのみ外部ファイルに保存します。',
 'Save/Load': '保存と読み込み',
 'Scale channel': 'スケールチャンネル',
 'Scene settings are not available.': 'シーン設定を利用できません。',
 'Second landmark index used for X-axis tracking.': 'X 軸トラッキングに使う 2 つ目のランドマーク番号です。',
 'Second landmark index used for Y-axis tracking.': 'Y 軸トラッキングに使う 2 つ目のランドマーク番号です。',
 'Select': '選択',
 'Select All': '全選択',
 'Select a mesh object in Object Mode that has Shape Keys and modifiers.': 'シェイプキーとモディファイアを持つメッシュを オブジェクト '
                                                                           'モードで選択してください。',
 'Select a mesh object with Shape Keys.': 'シェイプキーのあるメッシュを選択',
 'Select a mesh object.': 'メッシュオブジェクトを選択してください。',
 'Select a valid tracker target first.': '先に有効なトラッカー対象を選択してください。',
 'Select which modifier(s) to apply': '適用するモディファイアを選択',
 'Selected': '選択のみ',
 'Selected modifier was not found: ': '選択したモディファイアが見つかりません: ',
 'Selected modifiers were applied while keeping Shape Keys.': '選択したモディファイアをシェイプキーを保持したまま適用しました。',
 'Set': '保存',
 'Set Base': 'ベースを設定',
 'Set Global Preset': 'グローバルプリセットを保存',
 'Settings storage is not available.': '設定保存領域にアクセスできません。',
 'Setup / Utility': '設定・ユーティリティ',
 'Shape Axis group name on the selected object that should receive tracker values.': '選択したオブジェクト上で、トラッカー値を受け取るシェイプ軸グループ名です。',
 'Shape Key': 'シェイプキー',
 'Shape Key Axis Control': 'シェイプキー軸コントロール',
 'Shape Key name driven by this mapping point. Choose one of the mesh Shape Keys you want this target position to affect.': 'このマッピング点で駆動するシェイプキー名です。目標位置に応じて変化させたいメッシュのシェイプキーを選んでください。',
 'ShapeKey Axis Control': 'シェイプキー軸コントロール',
 'Show Point HUD': 'ポイントHUDを表示',
 'Show Point HUD in Viewport': 'ビューポートにポイント HUD を表示',
 'Show overview and usage details for bundled tools.': '同梱Smart Shapekeyの概要と使い方を表示します。',
 'Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.': '3DビューのNパネルに '
                                                                                                                                                                                                         'Smart '
                                                                                                                                                                                                         'Shapekey '
                                                                                                                                                                                                         'の操作UIを表示します。このツールセットでは、ベース形状の設定、UVベースのマップ保存、頂点編集のミラー、マップファイルの保存・読み込み、結果の書き出し、ツールデータの整理を行えます。',
 'Show the face-tracker landmark HUD in the 3D View only while Face Tracker is running. Leave this off when you do not need the overlay so Blender avoids a constant viewport draw callback.': 'Face '
                                                                                                                                                                                               'Tracker '
                                                                                                                                                                                               '実行中だけ '
                                                                                                                                                                                               '3D '
                                                                                                                                                                                               'View '
                                                                                                                                                                                               'にランドマーク '
                                                                                                                                                                                               'HUD '
                                                                                                                                                                                               'を表示します。オーバーレイが不要なときは '
                                                                                                                                                                                               'OFF '
                                                                                                                                                                                               'のままにすると、常時ビューポート描画コールバックを避けて軽くできます。',
 'Show the tool settings in the N-panel.': 'ツール設定をNパネルに表示します。',
 'Smart Shapekey': 'Smart Shapekey',
 'Smart Shapekey exposes its tool settings in the 3D View Sidebar N-panel category Smart Shapekey.': 'Smart Shapekey の設定を、3DビューのサイドバーNパネル内「Smart Shapekey」カテゴリに表示します。',
 'Smart Shapekey map rows saved on this object and shown in the N-panel list.': 'このオブジェクトに保存され、Nパネルリストに表示される Smart '
                                                                                'Shapekey マップ行です。',
 'Smooth Factor': 'スムーズ係数',
 'Smooth the X-axis tracker output over time to reduce jitter.': 'X 軸トラッカー出力を時間方向で平滑化し、細かな揺れを減らします。',
 'Smooth the Y-axis tracker output over time to reduce jitter.': 'Y 軸トラッカー出力を時間方向で平滑化し、細かな揺れを減らします。',
 'Smoothing': 'スムージング',
 'Spacing': '間隔',
 'Start': '開始位置',
 'Start Axis UI': 'シェイプ軸 HUD を開始',
 'Start External Tracker': '外部トラッカーを開始',
 'Start Face Tracker': 'フェイストラッカーを開始',
 'Start Frame': '開始フレーム',
 'Start Tracker': 'トラッカーを開始',
 'Start listening for external UDP tracking data on the configured port. Use this only while a sender app is active.': '設定したポートで外部 '
                                                                                                                       'UDP '
                                                                                                                       'トラッキング入力を受信開始します。送信アプリを使うときだけ開始してください。',
 'Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.': '外部トラッキングアプリからジョイスティック値を受信する '
                                                                                                                                                                                  'UDP '
                                                                                                                                                                                  'リスナーを開始または停止します。送信側アプリが動作していて、ポート設定が一致している場合のみ有効にしてください。',
 'Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.': '内蔵ウェブカメラフェイストラッカーを開始または停止します。カメラスレッドと '
                                                                                                                                                                        'Blender '
                                                                                                                                                                        '更新タイマーを維持するため、ライブ表情モーションを取得する間だけ有効にしてください。',
 'Start or stop the interactive 2D HUD Axis controller in the 3D Viewport.': '3D ビューポート内のシェイプ軸 HUD を開始または停止します。',
 'Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.': '3Dビューポート内の対話式のシェイプ軸 HUD を開始または停止します。ジョイスティック値を編集しないときは無効にして、Blender がモーダルビューポートツールを動かし続けないようにしてください。',
 'Start the built-in webcam face tracker.': '内蔵ウェブカメラのフェイストラッカーを開始します。',
 'Status: Listening for incoming UDP data.': '状態: UDP データ待受中です。',
 'Status: Stopped until you explicitly start it.': '状態: 明示的に開始するまでは停止したままです。',
 'Step': 'ステップ',
 'Stop Axis UI': 'シェイプ軸 HUD を停止',
 'Stop External Tracker': '外部トラッカーを停止',
 'Stop Face Tracker': 'フェイストラッカーを停止',
 'Stop Tracker': 'トラッカーを停止',
 'Stop the built-in webcam face tracker.': '内蔵ウェブカメラのフェイストラッカーを停止します。',
 'Stop the external UDP tracker listener and release its socket.': '外部 UDP トラッカーの待受を停止し、ソケットを解放します。',
 'Stopped': '停止中',
 'Store the current joystick coordinates of all groups across all objects into this preset.': 'すべてのオブジェクト・すべてのグループの現在ジョイスティック座標を、このプリセットへ保存します。',
 'Store the current raw X tracker value as the lower input bound.': '現在の生の X トラッカー値を入力下限として保存します。',
 'Store the current raw X tracker value as the upper input bound.': '現在の生の X トラッカー値を入力上限として保存します。',
 'Store the current raw Y tracker value as the lower input bound.': '現在の生の Y トラッカー値を入力下限として保存します。',
 'Store the current raw Y tracker value as the upper input bound.': '現在の生の Y トラッカー値を入力上限として保存します。',
 'Superseded or deduplicated': '上位互換または重複のため統合対象外',
 'Switch an always-on feature on or off and save the setting immediately.': '常時発動機能の有効・無効を切り替え、設定を即時保存します。',
 'Switch to Object Mode.': 'オブジェクトモードに切り替えてください。',
 'Target': '対象',
 'Target X': '目標 X',
 'Target Y': '目標 Y',
 'Target checked state applied to all map import choices.': 'すべてのマップ読み込み選択へ適用するチェック状態です。',
 'The active mesh has no Shape Keys.': 'シェイプキーがありません。',
 'The active mesh has no modifiers to apply.': '適用するモディファイアがありません。',
 'The active mesh has no modifiers to choose from.': 'アクティブメッシュに選択できるモディファイアがありません。',
 'This integrated package is included, but it is disabled on the current platform.': 'この統合パッケージは同梱されていますが、現在の環境では無効です。',
 'This map file cannot be rebuilt on a different topology. Load it on a mesh with the same loop count.': 'このマップファイルは異なるトポロジー上では再構築できません。同じループ数のメッシュで読み込んでください。',
 'The UV layout of this mesh differs from the map file, so the shape would break. Nothing was loaded. Give the mesh the same UV layout, then load again.': 'このメッシュの UV の開き方がファイルと違うので、読み込むと形が崩れます。読み込みを止めました（メッシュは変わっていません）。UV の開き方を同じにしてから読み込んでください。',
 'The saved mesh has overlapping UVs, so positions cannot be read from them on a different vertex layout. Nothing was loaded. Save from a mesh without overlapping UVs, or load onto a mesh with the same vertex layout.': '保存元のメッシュの UV が重なっているので、頂点の並びが違うメッシュへは位置を読み取れません。読み込みを止めました（メッシュは変わっていません）。UV が重ならないメッシュから保存するか、頂点の並びが同じメッシュへ読み込んでください。',
 'This package is intentionally disabled because a duplicate or superseded version was skipped.': '重複または上位互換により無効化されています。',
 'This tool is disabled in tool settings and will stay hidden until you enable it again there.': 'このツールはツール設定で無効化されています。再度有効にするまで読み込まれません。',
 'This tool requires a mesh with Shape Keys and modifiers in Object Mode.': 'このツールはシェイプキーとモディファイアを持つメッシュを オブジェクト '
                                                                            'モードで選択している必要があります。',
 'Toggle All': '全選択を切り替え',
 'Toggle Always-on Feature': '常時起動機能を切り替え',
 'Toggle Axis UI': 'シェイプ軸 HUD を切り替え',
 'Toggle Feature': '機能を切り替え',
 'Tolerance': '許容値',
 'Tool': 'ツール',
 'Tool Details': 'ツール詳細',
 'Tool Settings': 'ツール設定',
 'Tools': 'ツール',
 'Tracking Mode': 'トラッキング方式',
 'Turn this feature on when enabled, or turn it off when disabled.': '有効時はこの機能をオンにし、無効時はオフにします。',
 'UDP Port': 'UDPポート',
 'UDP listener for external joystick or tracking data.': '外部ジョイスティックまたはトラッキングデータ用の UDP リスナーです。',
 'UDP port used by the external tracker listener. Match this port with the sender application.': '外部トラッカー受信に使う UDP '
                                                                                                 'ポートです。送信アプリ側のポート番号と一致させてください。',
 'UI Error:': 'UI エラー:',
 'USER resource path is empty': 'USERリソースパスが空です。',
 'UV Map': 'UVマップ',
 'UV triangles are degenerate.': 'UV三角形が縮退しています。',
 'UV-driven shape map storage & export (topology independent by UV).': 'UVを基準にした形状マップの保存と書き出しを行い、UV が一致する別トポロジーにも復元できる機能です。',
 'UV-driven shapekey map storage, mirroring, save/load, export, and cleanup available in the Smart Shapekey N-panel.': 'UV基準のシェイプキーマップ保存、ミラー、保存と読み込み、書き出し、整理をSmart '
                                                                                                                       'Shapekey '
                                                                                                                       'のNパネルで利用できます。',
 'Unknown': '不明',
 'Unsupported platform': '現在の OS・CPU では無効',
 'Up': '上へ',
 'Upper Bound': '上限',
 'Upper input bound used by the formula. When the source reaches this value, the driver output reaches 1.': '式の上限入力値です。元の値がここに達するとドライバー出力が '
                                                                                                            '1 になります。',
 'Upper tracked input bound for X-axis normalization.': 'X 軸の正規化に使う入力上限値です。',
 'Upper tracked input bound for Y-axis normalization.': 'Y 軸の正規化に使う入力上限値です。',
 'Use a box-shaped falloff around the target point.': '目標点の周囲でボックス状の減衰を使います。',
 'Use a circular radial falloff around the target point.': '目標点の周囲で円形の放射状減衰を使います。',
 'Use iris motion as the source value.': '虹彩の動きを入力値として使います。',
 'Use the normalized distance between two landmark points.': '2 つのランドマーク間の正規化距離を使います。',
 'User Interface': 'ユーザーインターフェイス',
 'Vertical target position of this mapping point inside the Axis controller. Move farther from the center to react at a larger Y range.': 'シェイプ軸コントローラー内でのこのマッピング点の垂直目標位置です。中心から離すほど、より大きい Y 範囲で反応します。',
 'Verts': '頂点数',
 'View3D > Sidebar > Smart Shapekey': '3Dビュー > サイドバー > スマートシェイプキー',
 'Viewport / Editor': 'ビューポート・エディター',
 'Webcam-based built-in face tracker.': 'ウェブカメラベースの内蔵フェイストラッカーです。',
 'When ON, maps are treated as absolute shapes in UV space. Base deformation does not affect maps. When OFF, maps follow base deformation by applying offsets.': 'ON：マップは“絶対形状”として保存または適用され、ベースを変形してもマップは影響を受けません。OFF：マップはベースの変形に追従し、オフセットとして適用されます。',
 'When enabled, duplicate the selected map as the inverse of its stored offset from Basis.': 'オンにすると、選択中のマップを Basis '
                                                                                             'からの保存オフセットの反転として複製します。',
 'When enabled, paste copied vertices mirrored by the current mirror settings.': 'オンにすると、現在のミラー設定で反転したコピー済み頂点を貼り付けます。',
 'When enabled, run this cleanup for all compatible mesh objects in the current scene.': 'オンにすると、現在のシーン内にある対応メッシュオブジェクトすべてにこのクリーンアップを実行します。',
 'When enabled, save only maps marked Select instead of every map.': 'オンにすると、すべてのマップではなく Select が付いたマップだけを保存します。',
 'When enabled, this map is imported from the selected external map file.': 'オンにすると、選択した外部マップファイルからこのマップを読み込みます。',
 'World Origin': '原点',
 'X (Drivable)': 'X（ドライブ可）',
 'X Curve': 'X カーブ',
 'X Gain': 'X ゲイン',
 'X Output Max': 'X 出力最大',
 'X Output Min': 'X 出力最小',
 'X Point A': 'X 点 A',
 'X Point B': 'X 点 B',
 'X Radius Max': 'X 半径最大',
 'X Radius Min': 'X 半径最小',
 'X Smooth': 'X スムーズ',
 'X Smooth Factor': 'X スムーズ係数',
 'X Tracking Mode': 'X トラッキングモード',
 'X Value': 'X 値',
 'X-Axis': 'X 軸',
 'Y (Drivable)': 'Y（ドライブ可）',
 'Y Curve': 'Y カーブ',
 'Y Gain': 'Y ゲイン',
 'Y Output Max': 'Y 出力最大',
 'Y Output Min': 'Y 出力最小',
 'Y Point A': 'Y 点 A',
 'Y Point B': 'Y 点 B',
 'Y Radius Max': 'Y 半径最大',
 'Y Radius Min': 'Y 半径最小',
 'Y Smooth': 'Y スムーズ',
 'Y Smooth Factor': 'Y スムーズ係数',
 'Y Tracking Mode': 'Y トラッキングモード',
 'Y Value': 'Y 値',
 'Y-Axis': 'Y 軸',
 'open command failed': '開くコマンドが失敗しました。',
 'tool settings are available in the N-panel.': 'ツール設定はNパネルから利用できます。'}


TRANSLATIONS_JA.update({
    'init_relpath is empty': 'init_relpath が空です。',
    'Missing init file: ': 'init ファイルが見つかりません: ',
    'Failed to create module spec for ': 'モジュール仕様を作成できませんでした: ',
    '[Smart Shapekey] Failed to register integrated add-ons runtime': '[Smart Shapekey] 統合アドオン実行環境の登録に失敗しました',
    '[Smart Shapekey] Failed to unregister integrated add-ons runtime': '[Smart Shapekey] 統合アドオン実行環境の登録解除に失敗しました',
    'Failed to report to Info Log:': '情報ログへの報告に失敗しました:',
    '--- PIP INSTALL FAILURE ---': '--- PIP インストール失敗 ---',
    'STDOUT:': '標準出力:',
    'STDERR:': '標準エラー:',
    'ShapeKey Tracker Error: ': 'シェイプキートラッカーエラー: ',
    'Error sending groups: ': 'グループ送信エラー: ',
    '[HUD Error] Failed to get shader: ': '[HUD エラー] シェーダー取得に失敗しました: ',
    '[HUD Error] Failed drawing Background: ': '[HUD エラー] 背景描画に失敗しました: ',
    '[HUD Error] Failed drawing mapping points: ': '[HUD エラー] マッピング点描画に失敗しました: ',
    '[HUD Error] Failed drawing Joystick crosshair/dot: ': '[HUD エラー] ジョイスティックの十字線と点の描画に失敗しました: ',
    '[HUD Error] Failed drawing Buttons/Boxes: ': '[HUD エラー] ボタンとボックス描画に失敗しました: ',
    '[HUD Error] Failed drawing Button Texts: ': '[HUD エラー] ボタン文字描画に失敗しました: ',
    'User Interface': 'ユーザーインターフェイス',
    'Bake Animation to Shape Keys': 'アニメーションをシェイプキーにベイク',
    'Bake the animated joystick logic into raw Shape Key keyframes for export such as FBX or glTF.': 'アニメーションしたジョイスティック制御を、FBX や glTF などへ書き出しやすいシェイプキーキーフレームへベイクします。',
    'Call this preset and immediately insert keyframes for all affected Shape Keys.': 'このプリセットを呼び出した直後に、影響するすべてのシェイプキーへキーフレームを挿入します。',
    'Camera device index used by the built-in Face Tracker. Change this when the tracker opens the wrong webcam.': '内蔵フェイストラッカーが使うカメラデバイス番号です。別のウェブカメラを開いてしまう場合はここを変更してください。',
    'Choose how the controller distance is converted into Shape Key influence for this mapping point.': 'このマッピング点で、コントローラー位置の距離をシェイプキーの影響量へどう変換するかを選びます。',
    'Each bundled tool is always active while Smart Shapekey is enabled. Usage details are available in tooltips.': 'スマートシェイプキーが有効な間、同梱ツールは常に有効です。使い方はツールチップで確認できます。',
    'Enable frame-change updates for animated Shape Axis handles. Turn this on only while you need the joystick values to follow timeline playback or scrubbing. Leave it off when unused to keep Blender from running a constant frame-change callback.': 'タイムライン再生やスクラブ中にシェイプ軸のハンドル値を自動更新したいときだけ ON にしてください。未使用時は OFF のままにすると、常時フレーム変更コールバックを止めて Blender を軽くできます。',
    'Influence radius around this mapping point. Larger values make the Shape Key react across a wider area of the controller.': 'このマッピング点の影響半径です。値を大きくすると、コントローラー内のより広い範囲でシェイプキーが反応します。',
    'Install the Python packages required by the built-in Face Tracker into Blender’s Python environment.': '内蔵フェイストラッカーに必要な Python パッケージを Blender の Python 環境へインストールします。',
    'Name of this Shape Axis group. Each group stores one joystick handle and a list of Shape Key mappings.': 'このシェイプ軸グループの名前です。各グループは 1 つのジョイスティックハンドルとシェイプキーマッピング一覧を持ちます。',
    'Select a mesh object in Object Mode that has Shape Keys and modifiers.': 'シェイプキーとモディファイアを持つメッシュをオブジェクトモードで選択してください。',
    'Target Shape Axis group name on the selected object that receives tracker values.': '選択したオブジェクト上で、トラッカー値を受け取るシェイプ軸グループ名です。',
    'Shape Key name driven by this mapping point. Choose one of the mesh Shape Keys you want this target position to affect.': 'このマッピング点で駆動するシェイプキー名です。目標位置に応じて変化させたいメッシュのシェイプキーを選んでください。',
    'Show the face-tracker landmark HUD in the 3D View only while Face Tracker is running. Leave this off when you do not need the overlay so Blender avoids a constant viewport draw callback.': 'フェイストラッカー実行中だけ 3Dビューにランドマーク HUD を表示します。オーバーレイが不要なときは OFF のままにすると、常時ビューポート描画コールバックを避けて軽くできます。',
    'Smart Shapekey exposes its tool settings in the 3D View Sidebar N-panel category Smart Shapekey.': 'Smart Shapekey の設定を、3DビューのサイドバーNパネル内「Smart Shapekey」カテゴリに表示します。',
    'This tool is disabled in tool settings and will stay hidden until you enable it again there.': 'このツールはツール設定で無効化されています。再度有効にするまで読み込まれません。',
    'This tool requires a mesh with Shape Keys and modifiers in Object Mode.': 'このツールはシェイプキーとモディファイアを持つメッシュをオブジェクトモードで選択している必要があります。',
    'Object has no Shape Keys.': 'オブジェクトにシェイプキーがありません。',
    'No valid Shape Keys are mapped in this group.': 'このグループには有効なシェイプキーマッピングがありません。',
    'Shape Keys': 'シェイプキー',
    'Smart Shapekey exposes its controls in the 3D View Sidebar N-panel category Smart Shapekey.': 'Smart Shapekey の操作項目を、3DビューのサイドバーNパネル内「Smart Shapekey」カテゴリに表示します。',
    'Show the Smart Shapekey controls in the N-panel.': 'スマートシェイプキーの操作項目をNパネルに表示します。',
    'Smart Shapekey controls are available in the N-panel.': 'スマートシェイプキーの操作項目はNパネルから利用できます。',
    'UV-driven shapekey map storage, mirroring, save/load, export, and cleanup for the 3D View N-panel.': 'UV基準のシェイプキーマップ保存、ミラー、保存と読み込み、書き出し、整理を3DビューのNパネルで行います。',
    'Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.': 'スマートシェイプキー操作項目を3DビューのNパネルに表示します。ベース形状の設定、UV基準マップ保存、頂点編集のミラー、マップファイルの保存と読み込み、結果の書き出し、ツールデータ整理に使います。',
})


TRANSLATIONS_JA.update({
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggles draw failed.': '常時機能切り替えの描画に失敗しました。',
    'Enabled': '有効',
    'Disabled': '無効',
    'Toggle Always-on Feature': '常時起動機能を切り替え',
    'Enable or disable a long-running Smart Shapekey feature from the unified Always-on Toggles group.': '統一された「常時機能切り替え」グループから、スマートシェイプキーの常時稼働系機能を有効または無効にします。',
    'Feature': '機能',
    'Long-running feature to enable or disable.': '有効または無効にする常時稼働系機能です。',
    'Enable': '有効化',
    'Turn this feature on when enabled, or turn it off when disabled.': '有効のときはこの機能を開始し、無効のときは停止します。',
    'No feature was selected.': '機能が選択されていません。',
    'Failed to switch the feature.': '機能の切り替えに失敗しました。',
    'Scene settings are not available.': 'シーン設定を利用できません。',
    'Axis UI': 'シェイプ軸 HUD',
    'Axis UI Point Drag': 'シェイプ軸 HUD ポイントドラッグ',
    'Face Tracker Point HUD': 'フェイストラッカーポイントHUD',
    'Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.': '3Dビューポート内の対話式のシェイプ軸 HUD を開始または停止します。ジョイスティック値を編集しないときは無効にし、モーダル式ビューポートツールを動かしたままにしないようにします。',
    'Allow or block direct dragging of mapping points inside the Axis UI HUD. Turn it off to avoid accidental edits while keeping the HUD available.': 'シェイプ軸 HUD 内でマッピング点を直接ドラッグできるかを切り替えます。HUD を表示したまま誤編集を避けたいときは無効にします。',
    'Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.': 'タイムライン再生やスクラブ中にシェイプ軸ハンドルを更新するフレーム変更ハンドラーを有効または無効にします。アニメーションしたジョイスティック値を現在フレームへ追従させる必要があるときだけ有効にしてください。',
    'Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.': '外部トラッキングアプリからジョイスティック値を受け取る UDP 待受を開始または停止します。送信側アプリが起動していて、ポート設定が一致しているときだけ有効にします。',
    'Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.': '内蔵ウェブカメラフェイストラッカーを開始または停止します。カメラスレッドと Blender 更新タイマーを動かすため、表情モーションをライブ取得するときだけ有効にしてください。',
    'Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.': '3Dビュー内のフェイストラッカーランドマーク表示を有効または無効にします。この表示は内蔵フェイストラッカー実行中だけ描画されます。',
    'Interactive 2D HUD Axis controller in the 3D Viewport.': '3Dビューポート内の対話式のシェイプ軸 HUD です。',
    'Direct dragging of mapping points inside the Axis UI HUD.': 'シェイプ軸 HUD 内でマッピング点を直接ドラッグする機能です。',
    'Frame-change handler that updates animated Shape Axis handles.': 'アニメーションしたシェイプ軸ハンドルを更新するフレーム変更ハンドラーです。',
    'UDP listener for external joystick or tracking data.': '外部ジョイスティック値またはトラッキングデータを受け取る UDP 待受です。',
    'Webcam-based built-in face tracker.': 'ウェブカメラを使用する内蔵フェイストラッカーです。',
    'Landmark overlay for the built-in Face Tracker.': '内蔵フェイストラッカー用のランドマーク表示です。',
    'Edit Values': '値を編集',
    'Always-on Toggles': '常時機能切り替え',
    'Open or close the Always-on Toggles group at the top of the N-panel. It is closed by default to avoid unnecessary drawing and detection work during startup and normal display.': 'Nパネル最上部の常時機能切り替えグループを開閉します。既定では閉じた状態にして、起動時や通常表示時の余計な描画・検出処理を避けます。',
})



TRANSLATIONS_JA.update({
    'Help': 'ヘルプ',
    'Show Help': 'ヘルプを表示',
    'Open a help popup for this Smart Shapekey tool.': 'この Smart Shapekey ツールのヘルプポップアップを開きます。',
    'Tool': 'ツール',
    'Internal help topic identifier.': '内部ヘルプトピック識別子です。',
    'Help popup draw failed.': 'ヘルプポップアップの描画に失敗しました。',
    'Help content is not available for this tool.': 'このツールのヘルプ内容を利用できません。',
    'Feature Overview': '機能概要',
    'Settings': '設定項目',
})


TRANSLATIONS_JA.update({
    'Previous internal map name used to restore the value when a duplicate name is rejected.': '重複名が拒否されたときに値を戻すための、直前の内部マップ名です。',
    'Internal channel ID that links this map entry to its hidden UV storage layers.': 'このマップ項目を非表示 UV 保存レイヤーへ紐づける内部チャンネル ID です。',
    'Map name found in the selected external map file.': '選択した外部マップファイル内で見つかったマップ名です。',
    'When enabled, this map is imported from the selected external map file.': '有効にすると、このマップを選択した外部マップファイルから読み込みます。',
    'When enabled, duplicate the selected map as the inverse of its stored offset from Basis.': '有効にすると、選択マップを Basis からの保存オフセットの反転として複製します。',
    'Choose whether the selected map moves up or down in the map list.': '選択したマップをマップ一覧の上方向または下方向のどちらへ移動するかを選びます。',
    'When enabled, paste copied vertices mirrored by the current mirror settings.': '有効にすると、コピーした頂点を現在のミラー設定で反転して貼り付けます。',
    'Choose which side is copied across the mirror plane: left to right or right to left.': 'ミラー面を挟んでどちら側からどちら側へコピーするかを選びます。左から右、または右から左を指定します。',
    'Choose whether the operation uses all maps or only maps marked Select.': '処理対象をすべてのマップにするか、「選択」が付いたマップだけにするかを選びます。',
    'File browser filter that shows Smart Shapekey map files.': 'Smart Shapekey マップファイルをファイルブラウザーに表示するためのフィルターです。',
    'When enabled, save only maps marked Select instead of every map.': '有効にすると、すべてのマップではなく「選択」が付いたマップだけを保存します。',
    'External file path where Smart Shapekey map data is saved.': 'Smart Shapekey マップデータを書き出す外部ファイルパスです。',
    'External Smart Shapekey map file to load.': '読み込む外部 Smart Shapekey マップファイルです。',
    'External Smart Shapekey map file currently being inspected for import.': '読み込み対象として現在内容を確認している外部 Smart Shapekey マップファイルです。',
    'Internal switch used by the import dialog to enable every listed map.': '読み込みダイアログで一覧内の全マップを有効にするための内部スイッチです。',
    'Internal switch used by the import dialog to disable every listed map.': '読み込みダイアログで一覧内の全マップを無効にするための内部スイッチです。',
    'Target checked state applied to all map import choices.': 'マップ読み込み候補すべてへ適用するチェック状態です。',
    'When enabled, run this cleanup for all compatible mesh objects in the current scene.': '有効にすると、現在のシーン内にある対応メッシュオブジェクトすべてにこのクリーンアップを実行します。',
    'Active Smart Shapekey map index shown in the N-panel map list.': 'N パネルのマップ一覧で表示される、現在の Smart Shapekey マップ番号です。',
    'Internal guard that temporarily blocks automatic map application while the tool updates stored data.': 'ツールが保存データを更新している間、自動マップ適用を一時的に止める内部ガードです。',
})


_TRANSLATION_OWNER = __name__
_TRANSLATIONS_REGISTERED = False


# Additional runtime strings added by the audit pass.  These keep
# static Operator/Property tooltips from falling back to English in Japanese UI.
TRANSLATIONS_JA.update({
    'Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.': '3DビューのNパネルにSmart Shapekeyの操作項目を表示します。ベース形状の設定、UV基準マップ保存、頂点編集のミラー、マップファイルの保存と読み込み、結果の書き出し、ツールデータ整理に使います。',
    'Enable or disable every map entry in the current import selection dialog.': '現在の読み込み選択ダイアログ内の全マップ項目を有効または無効にします。',
    'Enable or disable a long-running Smart Shapekey feature from the unified Always-on Toggles group.': '統合された常時機能切り替えグループから、継続動作するSmart Shapekey機能を有効または無効にします。',
    'Help': 'ヘルプ',
    'Open a help popup for this Smart Shapekey tool.': 'このSmart Shapekeyツールのヘルプポップアップを開きます。',
    'Toggle Always-on Feature': '常時起動機能を切り替え',
    'Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.': '3Dビューポート内の対話式のシェイプ軸 HUD を開始または停止します。ジョイスティック値を編集しないときは、Blender内でモーダルビューポートツールが動作し続けないよう無効にします。',
    'Allow or block direct dragging of mapping points inside the Axis UI HUD. Turn it off to avoid accidental edits while keeping the HUD available.': 'シェイプ軸 HUD内のマッピング点を直接ドラッグできるかどうかを切り替えます。HUDを表示したまま誤編集を避けたい場合はオフにします。',
    'Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.': 'タイムライン再生やスクラブ中にシェイプ軸ハンドルを更新するフレーム変更ハンドラを有効または無効にします。アニメーションしたジョイスティック値を現在フレームへ追従させる必要がない場合はオフにします。',
    'Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.': '外部トラッキングアプリからジョイスティック値を受信するUDPリスナーを開始または停止します。送信側が起動していてポート設定が一致する場合のみ有効にします。',
    'Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.': '内蔵Webカメラフェイストラッカーを開始または停止します。カメラスレッドとBlender更新タイマーを動作させるため、表情モーションをライブ取得するときだけ有効にします。',
    'Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.': '3Dビュー内のフェイストラッカーランドマークオーバーレイを有効または無効にします。オーバーレイは内蔵フェイストラッカーの動作中だけ描画されます。',
    'Previous internal map name used to restore the value when a duplicate name is rejected.': '重複名が拒否されたときに値を戻すための、直前の内部マップ名です。',
    'Internal channel ID that links this map entry to its hidden UV storage layers.': 'このマップ項目と隠しUV保存レイヤーを結び付ける内部チャンネルIDです。',
    'Map name found in the selected external map file.': '選択した外部マップファイル内で見つかったマップ名です。',
    'When enabled, this map is imported from the selected external map file.': '有効にすると、選択した外部マップファイルからこのマップを読み込みます。',
    'When enabled, duplicate the selected map as the inverse of its stored offset from Basis.': '有効にすると、選択中のマップをBasisからの保存オフセットの反転として複製します。',
    'Choose whether the selected map moves up or down in the map list.': '選択中のマップをマップリスト内で上へ移動するか下へ移動するかを選びます。',
    'When enabled, paste copied vertices mirrored by the current mirror settings.': '有効にすると、コピー済み頂点を現在のミラー設定で反転して貼り付けます。',
    'Choose which side is copied across the mirror plane: left to right or right to left.': 'ミラー平面をまたいでコピーする方向を選びます。左から右、または右から左を指定します。',
    'Choose whether the operation uses all maps or only maps marked Select.': '操作対象を全マップにするか、Selectが有効なマップだけにするかを選びます。',
    'This map file cannot be rebuilt on a different topology. Load it on a mesh with the same loop count.': 'このマップファイルは異なるトポロジー上では再構築できません。同じループ数のメッシュで読み込んでください。',
    'File browser filter that shows Smart Shapekey map files.': 'Smart Shapekeyマップファイルを表示するファイルブラウザー用フィルターです。',
    'When enabled, save only maps marked Select instead of every map.': '有効にすると、全マップではなくSelectが有効なマップだけを保存します。',
    'External file path where Smart Shapekey map data is saved.': 'Smart Shapekeyマップデータを保存する外部ファイルパスです。',
    'External Smart Shapekey map file to load.': '読み込む外部Smart Shapekeyマップファイルです。',
    'External Smart Shapekey map file currently being inspected for import.': '読み込み対象として現在検査している外部Smart Shapekeyマップファイルです。',
    'Internal list of Smart Shapekey maps detected in the selected import file.': '選択した読み込みファイル内で検出されたSmart Shapekeyマップの内部リストです。',
    'Internal switch used by the import dialog to enable every listed map.': '読み込みダイアログで一覧内の全マップを有効にするための内部スイッチです。',
    'Internal switch used by the import dialog to disable every listed map.': '読み込みダイアログで一覧内の全マップを無効にするための内部スイッチです。',
    'Target checked state applied to all map import choices.': 'すべてのマップ読み込み選択へ適用するチェック状態です。',
    'When enabled, run this cleanup for all compatible mesh objects in the current scene.': '有効にすると、現在のシーン内にある対応メッシュオブジェクトすべてにこのクリーンアップを実行します。',
    'Always-on Toggles': '常時機能切り替え',
    'Open or close the Always-on Toggles group at the top of the N-panel. It is closed by default to avoid unnecessary drawing and detection work during startup and normal display.': 'Nパネル上部の常時機能切り替えグループを開閉します。起動時や通常表示中の不要な描画・検出処理を避けるため、標準では閉じています。',
    'Axis UI': 'シェイプ軸 HUD',
    'Axis UI Point Drag': 'シェイプ軸 HUD点ドラッグ',
    'Face Tracker Point HUD': 'フェイストラッカー点HUD',
    'Enabled': '有効',
    'Disabled': '無効',
    'Tool': 'ツール',
    'Internal help topic identifier.': '内部ヘルプトピック識別子です。',
    'Feature': '機能',
    'Long-running feature to enable or disable.': '有効または無効にする継続動作機能です。',
    'Enable': '有効化',
    'Turn this feature on when enabled, or turn it off when disabled.': '有効の場合はこの機能をオンにし、無効の場合はオフにします。',
    'Scene settings are not available.': 'シーン設定を利用できません。',
    'Help content is not available for this tool.': 'このツールのヘルプ内容を利用できません。',
    'No feature was selected.': '機能が選択されていません。',
    'Failed to switch the feature.': '機能の切り替えに失敗しました。',
    'Persistent Smart Shapekey N-panel settings stored outside the add-on preferences UI.': 'アドオンプリファレンスUIを使わずに外部保存されるSmart ShapekeyのNパネル設定です。',
    'Smart Shapekey map rows saved on this object and shown in the N-panel list.': 'このオブジェクトに保存され、Nパネルのリストに表示されるSmart Shapekeyマップ行です。',
    'Active Smart Shapekey map index shown in the N-panel map list.': 'Nパネルのマップリストに表示されるアクティブなSmart Shapekeyマップ番号です。',
    'Internal guard that temporarily blocks automatic map application while the tool updates stored data.': 'ツールが保存データを更新している間、自動マップ適用を一時的に止める内部ガードです。',
    'Interactive 2D HUD Axis controller in the 3D Viewport.': '3Dビューポート内の対話式のシェイプ軸 HUD です。',
    'Direct dragging of mapping points inside the Axis UI HUD.': 'シェイプ軸 HUD内でマッピング点を直接ドラッグする機能です。',
    'Frame-change handler that updates animated Shape Axis handles.': 'アニメーションしたシェイプ軸ハンドルを更新するフレーム変更ハンドラです。',
    'UDP listener for external joystick or tracking data.': '外部ジョイスティックまたはトラッキングデータ用のUDPリスナーです。',
    'Webcam-based built-in face tracker.': 'Webカメラを使う内蔵フェイストラッカーです。',
    'Landmark overlay for the built-in Face Tracker.': '内蔵フェイストラッカー用のランドマークオーバーレイです。',
    'Help popup draw failed.': 'ヘルプポップアップの描画に失敗しました。',
    'Always-on Toggles draw failed.': '常時機能切り替えの描画に失敗しました。',
})


# Final overrides for the Smart Rig-style unified always-on UI and normal Point Drag option.
TRANSLATIONS_JA.update({
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggles draw failed.': '常時機能切り替えの描画に失敗しました。',
    'Always-on Toggles draw failed.': '常時機能切り替えの描画に失敗しました。',
    'Open or close the Always-on Toggles group at the top of the N-panel. It is closed by default to avoid unnecessary drawing and detection work during startup and normal display.': 'Nパネル最上部の常時機能切り替えグループを開閉します。既定では閉じた状態にし、起動時や通常表示中の不要な描画・検出処理を避けます。',
    'Enable or disable a long-running Smart Shapekey feature from the unified Always-on Toggles group.': '統一された常時機能切り替えグループから、Smart Shapekey の継続動作機能を有効または無効にします。',
    'Enable or disable a long-running Smart Shapekey feature from the unified Always-on Toggles group.': '統一された常時機能切り替えグループから、Smart Shapekey の継続動作機能を有効または無効にします。',
    'Scene settings are not available.': 'シーン設定を利用できません。',
    'Enabled': '有効',
    'Disabled': '無効',
    'Axis UI': 'シェイプ軸 HUD',
    'Frame Sync': 'フレーム同期',
    'External Tracker (UDP)': '外部トラッカー UDP',
    'Face Tracker (Built-In)': 'フェイストラッカー（内蔵）',
    'Face Tracker Point HUD': 'フェイストラッカーポイントHUD',
    'Point Drag': 'ポイントドラッグ',
    'Axis UI Point Drag': 'シェイプ軸 HUD ポイントドラッグ',
    'Allow direct dragging of mapping points inside the Axis UI HUD. This is a normal editing option, not a background feature; it does not start handlers or timers by itself.': 'シェイプ軸 HUD 内でマッピング点を直接ドラッグできる通常編集オプションです。常時起動機能ではなく、単体ではハンドラーやタイマーを開始しません。',
    'Direct dragging of mapping points inside the Axis UI HUD.': 'シェイプ軸 HUD 内でマッピング点を直接ドラッグする通常編集オプションです。',
    'Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.': '3D ビューポート内の対話式のシェイプ軸 HUD を開始または停止します。ジョイスティック値を編集しないときは無効にし、モーダル式ビューポートツールを動かし続けないようにします。',
    'Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.': 'タイムライン再生やスクラブ中にシェイプ軸ハンドルを更新するフレーム変更ハンドラーを有効または無効にします。アニメーションしたジョイスティック値を現在フレームへ追従させる必要がある場合だけ有効にします。',
    'Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.': '外部トラッキングアプリからジョイスティック値を受信する UDP 待受を開始または停止します。送信側が動作していて、ポート設定が一致している間だけ有効にします。',
    'Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.': '内蔵 Web カメラ式フェイストラッカーを開始または停止します。カメラスレッドと Blender 更新タイマーを動かすため、表情モーションをライブ取得する間だけ有効にします。',
    'Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.': '3D ビュー内のフェイストラッカーランドマーク表示を有効または無効にします。この表示は内蔵フェイストラッカー実行中だけ描画されます。',
    'Interactive 2D HUD Axis controller in the 3D Viewport.': '3D ビューポート内の対話式のシェイプ軸 HUD です。',
    'Frame-change handler that updates animated Shape Axis handles.': 'アニメーションしたシェイプ軸ハンドルを更新するフレーム変更ハンドラーです。',
    'UDP listener for external joystick or tracking data.': '外部ジョイスティックまたはトラッキングデータ用の UDP 待受です。',
    'Webcam-based built-in face tracker.': 'Web カメラを使う内蔵フェイストラッカーです。',
    'Landmark overlay for the built-in Face Tracker.': '内蔵フェイストラッカー用のランドマーク表示です。',
    'Axis UI and Frame Sync: Long-running runtime switches are managed only in the Always-on Toggles group.': 'シェイプ軸 HUD とフレーム同期: 継続動作するランタイム切り替えは「常時機能切り替え」グループだけで管理します。',
    'Point Drag: Normal editing option that allows direct mapping-point dragging inside the Axis UI HUD. It is saved with N-panel settings but does not start handlers, timers, or threads by itself.': 'ポイントドラッグ: シェイプ軸 HUD 内でマッピング点を直接ドラッグできる通常編集オプションです。N パネル設定として保存されますが、単体ではハンドラー、タイマー、スレッドを開始しません。',
    'The listener is controlled from the Always-on Toggles group so all long-running background features share one unified switch area.': '待受は「常時機能切り替え」グループから制御します。継続動作するバックグラウンド機能を一箇所で統一管理するためです。',
    'Enable External Tracker in Always-on Toggles only while the sender is running.': '送信側が動作している間だけ、「常時機能切り替え」で外部トラッカーを有効にします。',
    'External Tracker Toggle: Starts or stops the UDP socket, receiving thread, and processing timer from Always-on Toggles. Disabled releases the socket, unregisters the timer, and clears queued packets.': '外部トラッカー切り替え: 「常時機能切り替え」から UDP ソケット、受信スレッド、処理タイマーを開始または停止します。無効にするとソケット解放、タイマー解除、キュー破棄を行います。',
    'The camera thread and update timer are controlled from Always-on Toggles; the point HUD remains an optional runtime overlay controlled from the same group.': 'カメラスレッドと更新タイマーは「常時機能切り替え」から制御します。ポイント HUD も同じグループから制御する任意のランタイムオーバーレイです。',
    'Set the Camera index, add target object and group entries, then enable Face Tracker from Always-on Toggles.': 'カメラ番号を設定し、対象オブジェクトとグループを追加してから、「常時機能切り替え」でフェイストラッカーを有効にします。',
    'Face Tracker Toggle: Starts or stops the camera thread and update timer from Always-on Toggles.': 'フェイストラッカー切り替え: 「常時機能切り替え」からカメラスレッドと更新タイマーを開始または停止します。',
    'Face Tracker Point HUD Toggle: Starts or stops the 3D View landmark overlay from Always-on Toggles.': 'フェイストラッカーポイント HUD 切り替え: 「常時機能切り替え」から 3D ビューのランドマーク表示を開始または停止します。',
})

# Shared common.py operator labels and tooltips (registered here so every
# translation context, including 'Operator', receives the Japanese text).
TRANSLATIONS_JA.update({
    'Open Help': 'ヘルプを開く',
    'Open the detailed help popup for this tool group.': 'このツールグループの詳細ヘルプポップアップを開きます。',
    'Always-on Toggle': '常時機能切り替え',
    'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.': '常時起動機能の有効・無効を切り替え、Nパネル設定を即時保存します。',
    'Save Preferences': 'プリファレンスを保存',
    'Save current N-panel settings to the Smart Shapekey folder in Blender CONFIG and request Blender to save user preferences.': '現在のNパネル設定を Blender の設定フォルダー内の Smart Shapekey フォルダーへ保存し、Blender にユーザープリファレンスの保存を要求します。',
})


def _normalize_locale(value: object) -> str:
    return str(value or '').strip().replace('-', '_').upper()


def is_japanese_locale(context=None) -> bool:
    """Return True only when Blender's current interface language is Japanese."""
    candidates = []
    try:
        prefs = getattr(context, 'preferences', None)
        view = getattr(prefs, 'view', None)
        candidates.append(getattr(view, 'language', None))
    except Exception:
        pass
    try:
        if bpy is not None:
            view = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'view', None)
            candidates.append(getattr(view, 'language', None))
    except Exception:
        pass

    explicit = []
    for candidate in candidates:
        token = _normalize_locale(candidate)
        if token and token not in {'DEFAULT', 'SYSTEM'}:
            explicit.append(token)
    if explicit:
        return any(token.startswith('JA') or token in {'JAPANESE', 'JP'} for token in explicit)

    try:
        if bpy is not None:
            translations = getattr(getattr(bpy, 'app', None), 'translations', None)
            token = _normalize_locale(getattr(translations, 'locale', None))
            return token.startswith('JA') or token in {'JAPANESE', 'JP'}
    except Exception:
        pass
    return False


def ui_text(en: str, ja: str | None = None, context=None) -> str:
    """Return the text for the active Blender UI language without combined bilingual display."""
    en_text = str(en)
    if is_japanese_locale(context):
        return str(TRANSLATIONS_JA.get(en_text, ja if ja is not None else en_text))
    return en_text


_JAPANESE_CHARS = re.compile('[\u3040-\u30ff\u4e00-\u9fff]')
_TEMPLATE_CACHE: dict[str, list[tuple[re.Pattern, str]]] = {}


def _compiled_templates(cache_key: str, table: dict[str, str]) -> list[tuple[re.Pattern, str]]:
    """Templates with a variable part, the ones with the most fixed text first."""
    compiled = _TEMPLATE_CACHE.get(cache_key)
    if compiled is None:
        ranked = []
        for source, target in table.items():
            if '{}' not in source:
                continue
            pattern = '(.*?)'.join(re.escape(part) for part in source.split('{}'))
            ranked.append((len(source.replace('{}', '')), re.compile(pattern, re.DOTALL), target))
        ranked.sort(key=lambda item: item[0], reverse=True)
        compiled = [(pattern, target) for _length, pattern, target in ranked]
        _TEMPLATE_CACHE[cache_key] = compiled
    return compiled


def _fill_template(target: str, values: tuple[str, ...]) -> str:
    # A value is a name or a number; str.format would trip over braces in a name.
    parts = target.split('{}')
    out = [parts[0]]
    for value, part in zip(values, parts[1:]):
        out.append(value)
        out.append(part)
    return ''.join(out)


def _english_line(value: str, exact: dict[str, str], templates) -> str:
    if value in exact:
        return exact[value]
    for pattern, target in templates:
        match = pattern.fullmatch(value)
        if match:
            # A variable part is a name, unless it is one of the fixed sentences of the table.
            return _fill_template(target, tuple(exact.get(group, group) for group in match.groups()))
    return value


def _english_from_japanese(value: str) -> str:
    """Whole sentences and sentences with a variable part only; names are left as they are."""
    if not _JAPANESE_CHARS.search(value):
        return value
    from .translation_en import JA_TO_EN, JA_TEMPLATES
    table = {key + '{}': text + '{}' for key, text in JA_TO_EN.items() if key.endswith(': ')}
    table.update(JA_TEMPLATES)
    templates = _compiled_templates('en', table)
    return '\n'.join(_english_line(line, JA_TO_EN, templates) for line in value.split('\n'))


def _japanese_from_english(value: str) -> str | None:
    """The Japanese sentence for a message, with its variable parts kept, or None when it is unknown."""
    if value in TRANSLATIONS_JA:
        return str(TRANSLATIONS_JA[value])
    from .translation_errors import ERROR_TEMPLATES_JA
    if value in ERROR_TEMPLATES_JA:
        return ERROR_TEMPLATES_JA[value]
    for pattern, target in _compiled_templates('ja', ERROR_TEMPLATES_JA):
        match = pattern.fullmatch(value)
        if match:
            # A variable part is a name or a number. Only a nested message of two or more words is translated,
            # so a name such as "Key" stays as it is.
            return _fill_template(target, tuple(
                (_japanese_from_english(group) or group) if ' ' in group else group for group in match.groups()
            ))
    head, sep, tail = value.partition(': ')
    if sep and head in TRANSLATIONS_JA:
        return str(TRANSLATIONS_JA[head]) + sep + tail
    return None


def translate_known(text: object, context=None) -> str:
    value = str(text or '')
    if not is_japanese_locale(context):
        return _english_from_japanese(value)
    return str(TRANSLATIONS_JA.get(value, value))


def _os_error_text(error: OSError, context=None) -> str:
    from .translation_errors import OS_ERROR_DEFAULT, OS_ERROR_TEXT
    en, ja = OS_ERROR_TEXT.get(type(error).__name__, OS_ERROR_DEFAULT)
    head = ja if is_japanese_locale(context) else en
    filename = getattr(error, 'filename', None)
    return f"{head}: {filename}" if filename else head


def exception_text(error: object, context=None) -> str:
    """The message of an exception in the UI language, with what caused it."""
    generic = ui_text('The operation could not be completed.', '操作を完了できませんでした。', context)
    if isinstance(error, OSError):
        return _os_error_text(error, context)
    if isinstance(error, (AttributeError, IndexError, KeyError, NameError, ReferenceError, TypeError)):
        return generic
    text = str(error or '').strip()
    if not text or 'poll()' in text or 'Traceback' in text:
        return generic
    if text.startswith('Error: '):
        text = text[len('Error: '):].strip()
    if not is_japanese_locale(context):
        return _english_from_japanese(text)
    translated = _japanese_from_english(text)
    if translated:
        return translated
    if _JAPANESE_CHARS.search(text):
        return text
    # A message from Blender or Python that no table knows: it may still name what to fix.
    return '操作を完了できませんでした（詳細: ' + text + '）'


def pgettext(msgid: str, context=None) -> str:
    return translate_known(msgid, context)


TRANSLATIONS_JA.update({
    'Select vertices in Edit Mode first.':'先に編集モードで頂点を選んでください。',
    'No selected vertices on the source side, or no matching vertices on the other side.':'選んだ頂点が元の側に無いか、反対側に対応する頂点がありません。',
    'Corrective Key':'補正キー',
    'First ARKit Input':'1つ目のARKit入力',
    'Second ARKit Input':'2つ目のARKit入力',
    'First Input Center':'1つ目の中心値',
    'Second Input Center':'2つ目の中心値',
    'Corrective Radius':'補正の半径',
    'Connect Corrective Driver':'補正キーを2表情に接続',
    'Disconnect Corrective Driver':'補正ドライバーの接続を解除',
    'Drive an existing corrective key with the Shape Axis BOX weight from two ARKit inputs':'制作済み補正キーを2つのARKit入力からシェイプ軸のBOX補正量で駆動',
    "Remove only this tool's unchanged driver and keep the corrective shape":'このツールが作成した未変更のドライバーだけを解除し、補正形状を保持',
    'Corrective driver connected: {key}':'補正ドライバーを接続：{key}',
    'Corrective driver disconnected; shape retained: {key}':'補正形状を保持して接続解除：{key}',
    'Corrective driver ownership is invalid.':'補正ドライバーの所有記録が不正です。',
    'Select one corrective mesh in Object Mode.':'オブジェクトモードで補正するメッシュを1つ選択してください。',
    'Use a local unshared mesh with relative shape keys.':'相対シェイプキーを持つ、共有されていないローカルメッシュを使用してください。',
    'Choose an existing corrective key outside the ARKit 52 names.':'ARKit 52表情名以外の制作済み補正キーを選択してください。',
    'The corrective key must be unmuted, relative to Basis, and cover values 0 to 1.':'補正キーはミュートを解除し、Basisを相対元として、0〜1の範囲を使用してください。',
    'The corrective mesh exceeds 200000 vertices.':'補正メッシュは20万頂点以内にしてください。',
    'The corrective driver was changed outside this tool.':'補正ドライバーがこのツール以外で変更されています。',
    'The corrective key already has animation or external references.':'補正キーには既存のアニメーションまたは外部参照があります。',
    'The driver reference check exceeds 10000 curves.':'ドライバー参照検査の上限1万カーブを超えています。',
    'Choose two different ARKit input keys on this mesh.':'同じメッシュの異なるARKit入力キーを2つ選択してください。',
    'Centers must be 0 to 1 and radius must be 0.01 to 1.':'中心値は0〜1、半径は0.01〜1にしてください。',
    'The corrective driver must use a standard simple expression.':'補正ドライバーは標準の単純式を使用する必要があります。',
    'The corrective key already has a driver owned by another tool.':'補正キーには他のツールが所有するドライバーがあります。',
    'A mesh can own at most 32 corrective drivers.':'1メッシュの補正ドライバーは32個以内にしてください。',
    'This corrective driver is not owned by this tool.':'この補正ドライバーはこのツールの所有物ではありません。',
})

TRANSLATIONS_JA.update({
    'Editing Target Key':'編集目標キー',
    'Capture Mix as Editing Target':'ミックスを編集目標にする',
    'Create Corrective from Target':'編集目標から補正キーを作成',
    'Store the current shape mix as a protected reference and an editable target; original keys stay unchanged':'現在の表情ミックスを保護した基準と編集目標に保存し、元キーを保持',
    'Derive the edited target minus its stored mix reference, add a new corrective key and connect the two-input BOX driver':'編集目標と保管したミックス基準の差分から新しい補正キーを作り、2入力のBOXドライバーに接続',
    'Editing target captured: {key}':'編集目標を取り込み：{key}',
    'Corrective created from target: {key}':'編集目標から補正を作成：{key}',
    'Save Facial Shapes and Correctives':'表情・補正プリセットを保存',
    'Apply Facial Shapes and Correctives':'表情・補正プリセットを適用',
    'Facial preset saved: {parts} parts / {shapes} shapes / {correctives} correctives':'表情プリセットを保存：{parts}部品／{shapes}キー／{correctives}補正',
    'Facial preset applied: {shapes} new shapes / {correctives} new correctives':'表情プリセットを適用：新規{shapes}キー／新規{correctives}補正',
    'Stop live Face Tracker before authoring a corrective.':'ライブフェイストラッカーを停止してから補正を制作してください。',
    'Corrective authoring exceeds two million stored shape vertices.':'補正制作の形状データ上限200万頂点を超えています。',
    'Corrective target ownership is invalid.':'編集目標の所有記録が不正です。',
    'The corrective target Basis or topology was changed.':'編集目標のBasisまたはトポロジーが変わっています。',
    'The stored corrective mix reference was changed.':'保管したミックス基準が変わっています。',
    'An original shape was edited after capturing the target.':'目標を取り込んだ後に元のシェイプキーが編集されています。',
    'The target must remain relative to Basis without a vertex group.':'編集目標はBasis基準・頂点グループなしを維持してください。',
    'The corrective target already has animation or driver references.':'編集目標にはアニメーションまたはドライバー参照があります。',
    'Use a non-ARKit name for the editing target.':'編集目標にはARKit名以外の名前を使用してください。',
    'This editing target is already recorded; choose a new target name.':'この編集目標は記録済みです。新しい目標名を使用してください。',
    'The editing target name already exists or the 32-target limit is reached.':'編集目標名が既存、または32目標の上限に達しています。',
    'Disable Show Only Shape Key before capturing a new target.':'新しい目標を取り込む前に「シェイプキーのみ表示」を解除してください。',
    'Set both input values to their centers before capturing the target.':'目標の取り込み前に、両入力の値を指定した中心値に合わせてください。',
    'Blender changed the requested target name.':'Blenderが指定した目標名を変更しました。',
    'Capture an editing target with this tool first.':'先にこのツールで編集目標を取り込んでください。',
    'The completed corrective was changed; keep it and use a new editing target.':'完成した補正が変わっています。既存補正を保護し、新しい編集目標を使用してください。',
    'Use the input names and centers recorded with the editing target.':'編集目標と一緒に記録した入力名と中心値を使用してください。',
    'Use a new non-ARKit name for the corrective key.':'補正キーには未使用のARKit名以外の名前を使用してください。',
    'The corrective target contains non-finite coordinates.':'編集目標に非有限の座標があります。',
    'Blender changed the requested corrective name.':'Blenderが指定した補正キー名を変更しました。',
    'Invalid corrective BOX settings.':'補正のBOX設定が不正です。',
    'Invalid corrective ARKit input names.':'補正のARKit入力名が不正です。',
    'Invalid corrective centers.':'補正の中心値が不正です。',
    'Invalid corrective radius.':'補正の半径が不正です。',
    'The owned corrective shape was changed or muted.':'所有補正の形状設定が変わったか、ミュートされています。',
    'Corrective inputs must be unmuted Basis-relative ARKit shapes.':'補正入力はミュートなし・Basis基準のARKit形状にしてください。',
    'The corrective inputs are absent from this preset part.':'このプリセット部品に補正入力がありません。',
    'Invalid corrective count in the preset.':'プリセットの補正数が不正です。',
    'Invalid corrective descriptor in the preset.':'プリセットの補正記述が不正です。',
    'Invalid corrective name or member path.':'補正名または格納パスが不正です。',
    'Invalid corrective coordinate length.':'補正座標の長さが不正です。',
    'Corrective coordinate hash mismatch.':'補正座標のハッシュが一致しません。',
    'Invalid corrective slider range.':'補正のスライダー範囲が不正です。',
    'Invalid corrective interpolation.':'補正の補間方式が不正です。',
    'Protecting a different or foreign existing corrective key.':'異なる補正、または所有外の既存補正キーを保護します。',
})

TRANSLATIONS_JA.update({
    'Reset Other Inputs for Preview':'プレビュー時に他を0へ戻す',
    'Preview Two Inputs':'選択部品の2入力値を揃えてプレビュー',
    'Set the existing two input center values on every matching selected facial part; keep Actions and shape coordinates protected':'既存の2入力中心値を選択顔部品へ揃えます。アクションと形状座標を保護します。',
    'Reset ARKit Values to Zero':'選択部品のARKit値をゼロへ戻す',
    'Reset only ARKit coefficients on selected facial parts; keep original shapes, corrective drivers and Actions protected':'選択顔部品のARKit値だけをゼロへ戻します。原形状、補正ドライバー、アクションを保護します。',
    'Preview synchronized: {parts} parts / {bindings} ARKit bindings':'プレビューを同期：{parts}部品／{bindings}割当',
    'ARKit preview reset: {parts} parts / {bindings} bindings':'ARKitプレビューをリセット：{parts}部品／{bindings}割当',
    'Choose two distinct ARKit preview inputs.':'異なるARKit入力を2つ選択してください。',
    'Preview facial coefficients in Object Mode.':'オブジェクトモードで表情値をプレビューしてください。',
    'Stop live Face Tracker before previewing facial coefficients.':'表情値のプレビュー前にライブフェイストラッカーを停止してください。',
    'Preview inputs must be distinct ARKit names with finite values from zero to one.':'プレビューにはARKit名と0〜1の有限値が必要です。',
    'Choose at least one ARKit preview input.':'ARKitプレビュー入力を選択してください。',
    'Preview requires relative shape keys on every selected facial mesh.':'選択顔メッシュすべてに相対シェイプキーが必要です。',
    'Turn off Show Only Shape Key before previewing a mix.':'ミックスのプレビュー前に「シェイプキーのみ表示」をオフにしてください。',
    'Existing shape-key Action protected during preview.':'プレビュー中は既存シェイプキーアクションを保護します。',
    'Active shape-key NLA protected during preview.':'プレビュー中は有効なシェイプキーNLAを保護します。',
    'Ambiguous duplicate ARKit names in one mesh.':'同じメッシュに重複するARKit名があり対応を一意に確認できません。',
    'Driven ARKit input protected during preview.':'プレビュー中はドライバー付きARKit入力を保護します。',
    'Preview requires unmuted ARKit shapes relative to Basis.':'プレビュー対象のARKitキーはミュート解除し、Basisを基準にしてください。',
    'An ARKit slider range does not include the preview value.':'ARKitキーのスライダー範囲にプレビュー値が含まれていません。',
    'Selected facial meshes do not contain both preview inputs.':'選択顔メッシュに2つのプレビュー入力が揃っていません。',
    'Preview requires one to 5500 ARKit bindings.':'プレビュー対象は1〜5500割当にしてください。',
    'Blender rejected an ARKit preview value.':'BlenderがARKitプレビュー値を受け入れませんでした。',
})

_TRANSLATION_CONTEXTS = ('*', 'Operator', 'Property', 'Tooltip', 'UI', 'Panel', 'Menu', 'Addon')


TRANSLATIONS_JA.update({'Save Facial Mix': '表情ミックスを保存', 'Read Facial Mix': '表情ミックスを読み込む', 'Save the current synchronized ARKit coefficient values from selected facial meshes': '選択顔メッシュで同期した現在のARKit係数を保存', 'Apply a saved ARKit mix to all selected facial parts and reset other ARKit values; preserve existing Actions': '保存済みのARKitミックスを選択顔パーツ全体へ適用し、他のARKit値をリセット。既存アクションは保護', 'Facial mix saved: {count} coefficients': '表情ミックスを保存：{count}係数', 'Facial mix applied: {parts} parts / {count} coefficients': '表情ミックスを適用：{parts}部品／{count}係数', 'A facial mix must contain one to 52 ARKit coefficients.': '表情ミックスには1～52のARKit係数が必要です。', 'Facial mix coefficients require exact ARKit names and finite values from zero to one.': '表情ミックスの係数は正確なARKit名と0～1の有限値にしてください。', 'Duplicate fields are not allowed in a facial mix.': '表情ミックス内の項目重複は使用できません。', 'Facial mix file exceeds 64 KiB.': '表情ミックスのファイルが64 KiBを超えています。', 'Invalid facial mix JSON.': '表情ミックスのJSONが不正です。', 'Unsupported facial mix format or version.': 'この表情ミックス形式または版には対応していません。', 'Facial mix file must use UTF-8.': '表情ミックスの文字コードはUTF-8にしてください。', 'Existing facial mix file protected; choose a new filename.': '既存ミックスを保護しています。新しいファイル名で保存してください。', 'Facial mix export requires relative shape keys.': '表情ミックスの保存には相対シェイプキーが必要です。', 'Selected facial meshes have different values for the same ARKit input.': '選択顔メッシュ間で同じARKit入力の値が一致しません。', 'Facial mix export requires one to 5500 ARKit bindings.': '表情ミックスの保存には1～5500のARKit割当が必要です。', 'Selected facial meshes do not contain all requested preview inputs.': '選択顔メッシュに指定されたプレビュー入力が揃っていません。'})


# ARKit rig: bake / return / check / reapply from the spec JSON.
TRANSLATIONS_JA.update({
 'Rig Spec JSON': 'リグの正本JSON',
 'The spec JSON (ark_reapply_spec.json format) that names the rig, its ARKit Actions, Action constraints, bone collections and hand values': 'リグ・ARKitのアクション・アクションの拘束・骨コレクション・手の値の名前を書いた正本のJSON（ark_reapply_spec.json の形）',
 'Bake Range': '焼く範囲',
 'Scene + Keys': 'シーン＋キー',
 'Bake the scene range joined with the range of the slider and hand-value keys': 'シーンの範囲と、スライダー・手の値のキーの範囲を合わせて焼きます',
 'Explicit Range': '範囲を指定',
 'Bake only the frames given below': '下で決めたコマだけを焼きます',
 'First Frame to Bake': '焼く最初のコマ',
 'Last Frame to Bake': '焼く最後のコマ',
 'First frame to bake when Explicit Range is chosen': '「範囲を指定」の時に焼く最初のコマ',
 'Last frame to bake when Explicit Range is chosen': '「範囲を指定」の時に焼く最後のコマ',
 'Allow Partial Bake': '一部だけ焼くのを許す',
 'Bake the explicit range even when slider keys reach outside it (expressions outside the range are lost)': 'スライダーのキーが範囲の外にあっても、決めた範囲を焼きます（範囲の外の表情は消えます）',
 'Self Check After Bake': '焼いた後に自己確認',
 'Compare the face mesh before and after the bake on every 10th frame and report the largest movement': '焼く前と後の顔のメッシュを10コマおきに比べ、一番大きい動きを出します',
 'Bake Face to Hand Keys': '顔を手付け用に焼く',
 'Bake the ARKit slider result of every frame in the range into keys on the face controller bones and hand values, then switch the rig to hand-key mode': '範囲の全部のコマのARKitのスライダーの結果を、顔のコントローラーの骨と手の値のキーへ焼き、リグを手付けモードにします',
 'Return to Expression Mode': '表情モードへ戻す',
 'Remove the keys this tool baked, put back the keys and values from before the bake, and turn the ARKit constraints it stopped back on': 'この道具が焼いたキーを消し、焼く前のキーと値を戻し、止めたARKitの拘束を有効に戻します',
 'Check Against Spec': '正本と比べて検査',
 'List every declared ARKit Action and Action constraint that differs from the spec JSON without changing anything': '正本のJSONと違うARKitのアクションとアクションの拘束を、何も変えずに並べます',
 'Reapply From Spec': '正本から当て直す',
 'Add the missing declared ARKit Actions and Action constraints and correct the ones that differ from the spec JSON (order included)': '正本のJSONにあるARKitのアクションとアクションの拘束のうち、無い物を足し、違う物を直します（並びも）',
})


TRANSLATIONS_JA.update({
    'No maps were selected.': 'マップが選ばれていません。',
    'The operation could not be completed.': '操作を完了できませんでした。',
    'To Bones': '骨',
    'To Shape Keys': 'シェイプキー',
    'Not imported': '未取り込み',
    'Create the jaw assist: copies the existing jaw and related correctives and adds an opening driven by the tongue input, without changing recorded values': '既存の顎と関連補正を複製し、収録値を変えず舌入力に応じた開口補助を生成します',
    "Remove only the jaw assist made by this tool and keep the original expressions and correctives": 'このツールが所有する開口補助だけを除去し、元の表情と補正を保持します',
    'Save only maps with the Select checkbox enabled in the list.': 'マップの一覧でチェックを入れたマップだけを外部ファイルに保存します。',
    'If enabled, this map will be included when using Selected export/save.': 'オンにすると「選択のみ」の書き出しまたは保存に含まれます。',
    'Choose whether the operation uses all maps or only maps marked Select.': '処理の対象を、すべてのマップにするか、チェックを入れたマップだけにするかを選びます。',
    'When enabled, save only maps marked Select instead of every map.': 'オンにすると、すべてのマップではなく、チェックを入れたマップだけを保存します。',
    'Choose which transform channel the generated driver formula should read from: Location, Rotation, or Scale.': '生成するドライバー式が読むトランスフォームの種類を、位置・回転・スケールから選びます。',
    'Create a driver expression from Location, Rotation, or Scale.': '位置・回転・スケールからドライバー式を作ります。',
    'Select a mesh object in Object Mode that has Shape Keys and modifiers.': 'シェイプキーとモディファイアを持つメッシュを、オブジェクトモードで選んでください。',
    'Contact Report Text': '接触レポートのテキスト',
    'Contact Face Probe Report Text': '面内標本レポートのテキスト',
    'Corrective coordinate hash mismatch.': '補正の座標のハッシュが一致しません。',
})

TRANSLATIONS_JA.update({
    'Open or close the Always-on Features group at the top of the N-panel. It is closed by default.': 'N パネルの一番上の「常時機能切り替え」を開け閉めします。既定では閉じています。',
    'Frame Offset': 'フレームのオフセット値',
    'Bone Calibration (EDIT Only)': '骨の校正（EDITのみ）',
    'In use: generic table': '使用中: 汎用校正表（本人用は任意）',
    'Neutral Draft JSON': 'neutralの下書きJSON',
    'Select the ARKit controller armature.': 'ARKit コントローラーのアーマチュアを選んでください。',
    'A local writable armature is required.': '書き込めるローカルのアーマチュアが要ります。',
    'Library override rigs are protected.': 'ライブラリオーバーライドのリグは変更しません。',
    'Active NLA protected.': '有効な NLA があるので変更しません。',
    'No matching cc_arkit controller bones.': '対応する ARKit コントローラーの骨がありません。',
    'Missing Object Action Slot.': 'オブジェクトのアクションスロットがありません。',
    'Finite frame/FPS values required.': 'フレームと FPS は有限の値にしてください。',
    'Frame/FPS outside supported range.': 'フレームか FPS が扱える範囲の外です。',
    'RAW + EDIT exceeds 250,000 keys; split this take.': 'RAW と EDIT で 25 万キーを超えます。テイクを分けてください。',
    'Source CSV exceeds 20 MiB.': '元の CSV が 20 MiB を超えています。',
    'Linked rig protected.': 'リンクされたリグは変更しません。',
    'No active controller capture Action.': '有効なコントローラーの収録アクションがありません。',
    'Controller take owner mismatch.': 'コントローラーのテイクの持ち主が一致しません。',
    'RAW/EDIT pair is ambiguous.': 'RAW と EDIT の組を特定できません。',
    'Object Action Slot mismatch.': 'オブジェクトのアクションスロットが一致しません。',
    'Linked/tweak-mode body Action protected.': 'リンクまたは編集中の体のアクションは変更しません。',
    'Enable Keep Existing Actions before importing over a body Action.': '体のアクションの上へ取り込む時は、先に「既存アクションを残す」をオンにしてください。',
    'Object Action Slot required.': 'オブジェクトのアクションスロットが要ります。',
    'Multi-layer body Actions are protected; use a single-layer working copy.': '複数の層の体のアクションは変更しません。1 層の作業用の写しを使ってください。',
    'Controller key insertion failed.': 'コントローラーのキーを打てませんでした。',
    'Calibration exceeds 256 KiB.': '校正表が 256 KiB を超えています。',
    'Neutral window must be 0 to 5 seconds.': '真顔の区間は 0〜5 秒にしてください。',
    'Invalid neutral frame count.': '真顔の区間のフレーム数が正しくありません。',
    'Empty neutral window.': '真顔の区間が空です。',
    'Unknown annotated calibration fields.': '校正表に知らない項目があります。',
    'Estimator k must be between 0 and 1.': '推定の係数は 0〜1 にしてください。',
    'Invalid calibration JSON.': '校正表の JSON が正しくありません。',
    'Calibration neutral/max must be finite numbers between 0 and 1.': '校正表の neutral と max は 0〜1 の有限の数にしてください。',
    'Invalid calibration table schema.': '校正表の形が正しくありません。',
    'Unsupported calibration table version.': '対応していない校正表の形式です。',
    'Calibration needs 1 to 52 named channels.': '校正表には名前付きの係数が 1〜52 個要ります。',
    'Calibration table exceeds the stored-data limit.': '校正表が保存できる大きさを超えています。',
    'Calibration table exceeds 256 KiB.': '校正表が 256 KiB を超えています。',
    'Calibration version 2 (knots) is JSON only; CSV supports version 1 neutral/max/clamp.': '折れ点のある校正表は JSON だけです。CSV は neutral・max・clamp の形だけ扱えます。',
    'Calibration CSV requires channel,neutral,max and optional clamp columns.': '校正表の CSV には channel・neutral・max の列が要ります（clamp は任意）。',
    'Calibration version 2 (knots) is JSON only; save it as .json.': '折れ点のある校正表は JSON だけです。.json で保存してください。',
    'Choose a calibration CSV/JSON file within 256 KiB.': '256 KiB 以内の校正表（CSV か JSON）を選んでください。',
    'Save calibration as .csv or .json.': '校正表は .csv か .json で保存してください。',
    'Calibration channel names must be strings.': '校正表の係数の名前は文字にしてください。',
    'Invalid calibration CSV row or row limit.': '校正表の CSV の行が正しくないか、行が多すぎます。',
    'Unknown or duplicate calibration CSV channel.': '校正表の CSV に知らない係数か重複した係数があります。',
    'Calibration CSV clamp must be true,false,1 or 0.': '校正表の CSV の clamp は true・false・1・0 のどれかにしてください。',
    'Invalid calibration CSV number.': '校正表の CSV の数値が正しくありません。',
    'Positive source fps required for frame-based timecode': 'フレーム単位のタイムコードには、0 より大きい元の FPS が要ります。',
    'Drop-frame timecode needs an explicit supported conversion; not treated as non-drop': 'ドロップフレームのタイムコードは扱えません。',
    'Invalid capture time': '収録の時刻が正しくありません。',
    'Unknown range policy': '値の範囲の扱いが正しくありません。',
    'value_scale must be finite and positive': '値の倍率は 0 より大きい有限の数にしてください。',
    'At least two timed samples required': '時刻付きの行が 2 行以上要ります。',
    'Invalid target timebase': '取り込み先の時間の基準が正しくありません。',
    'Expected seconds or HH:MM:SS:FF timecode': '時刻は秒か HH:MM:SS:FF の形にしてください。',
    'Duplicate CSV column names': 'CSV の列名が重複しています。',
    'No recognized ARKit channels': '分かる ARKit の列がありません。',
    'Invalid timecode': 'タイムコードが正しくありません。',
    'Capture row limit exceeded': '収録の行数が上限を超えています。',
    'Capture needs time_seconds, timestamp_ms, or Timecode; row index is not time': '時刻の列（time_seconds・timestamp_ms・Timecode）が要ります。',
    'Nonfinite or negative timestamp': '時刻が有限でないか、負の値です。',
    'Timestamps must increase strictly': '時刻は行ごとに増えるようにしてください。',
    'Smoothing time must be 0..1 seconds': '平滑化の時間は 0〜1 秒にしてください。',
    'Region gain must be finite and 0..3': '部位の利得は 0〜3 の有限の数にしてください。',
    'Take exceeds 250,000 keys; split the source take before import': '25 万キーを超えます。取り込む前にテイクを分けてください。',
    'Source CSV exceeds 20 MiB': '元の CSV が 20 MiB を超えています。',
    'Invalid jaw clearance inputs or limit.': '開口補助の入力か上限が正しくありません。',
    'Invalid ramp centers.': '開始値が正しくありません。',
    'Jaw clearance limit requires its response mode.': '開口補助の上限には、その応答方式が要ります。',
    'Original shapes changed during target capture.': '編集目標の取り込み中に元の形が変わりました。',
    'The owned corrective shape is absent.': '補正の形がありません。',
    'Invalid jaw clearance settings.': '開口補助の設定が正しくありません。',
    'Unexpected jaw clearance limit.': '開口補助の上限が想定と違います。',
    'Invalid selected-part library option.': '選択部品の保存の設定が正しくありません。',
    'Source CSV must be within 20 MiB.': '元の CSV は 20 MiB 以内にしてください。',
    'No matching driver-free ARKit target shapes': 'ドライバーの付いていない対応する ARKit のシェイプキーがありません。',
    'Missing Key Action Slot': 'キーのアクションスロットがありません。',
    'Key insertion failed': 'キーを打てませんでした。',
    'Axis handle keyframe insertion failed': 'ハンドルにキーを打てませんでした。',
    'Axis auto-key insertion failed': 'ハンドルの自動キーを打てませんでした。',
    'Invalid map move direction': 'マップの移動の向きが正しくありません。',
})

def translation_dict():
    return {
        'ja_JP': {
            (context, en): ja
            for en, ja in TRANSLATIONS_JA.items()
            for context in _TRANSLATION_CONTEXTS
        }
    }


def register() -> None:
    global _TRANSLATIONS_REGISTERED
    if bpy is None or _TRANSLATIONS_REGISTERED:
        return
    try:
        # Unregister-first clears any stale cache left under this same
        # deterministic owner by an orphaned previous installation.
        try:
            bpy.app.translations.unregister(_TRANSLATION_OWNER)
        except Exception:
            pass
        bpy.app.translations.register(_TRANSLATION_OWNER, translation_dict())
        _TRANSLATIONS_REGISTERED = True
    except ValueError:
        _TRANSLATIONS_REGISTERED = True
    except Exception:
        pass


def unregister() -> None:
    global _TRANSLATIONS_REGISTERED
    if bpy is None or not _TRANSLATIONS_REGISTERED:
        return
    try:
        bpy.app.translations.unregister(_TRANSLATION_OWNER)
    except Exception:
        pass
    _TRANSLATIONS_REGISTERED = False

# Explicit selected-part corrective inputs and monotonic response.
TRANSLATIONS_JA.update({'Corrective Response': '補正の応答方式', 'BOX Weight': 'BOX補正', 'Ramped Inputs': '入力に合わせて増加', 'Fade around the two input centers.': '2入力の中心から離れるほど補正を減らします。', 'Increase from zero to the full-response values, then hold.': '最大補正値までは入力に合わせて増加し、それ以降は保持します。', 'Activate the corrective mesh and select its input parts in Object Mode.': 'オブジェクトモードで補正メッシュをアクティブにし、入力パーツも選択してください。', 'Use local unshared input parts with relative shape keys.': '入力にはローカルかつ共有されていない相対シェイプキーのパーツを使ってください。', 'Choose two different ARKit input keys.': '異なる2つのARKit入力キーを指定してください。', 'Ramped inputs require positive full-response values.': '増加方式の最大補正値は0より大きい値を指定してください。', 'Invalid corrective input source list.': '補正入力パーツの一覧が不正です。', 'Select exactly one input part for a missing ARKit key.': 'アクティブ側にないARKitキーを持つ入力パーツを1つだけ選択してください。', 'Invalid corrective input source name.': '補正入力パーツの名前が不正です。', 'Corrective input parts must be selected.': '補正入力パーツを選択してください。', 'The corrective source part is absent from the preset.': '補正入力パーツがライブラリに含まれていません。', 'The corrective input is absent from its preset source part.': '補正の入力キーがライブラリの入力パーツにありません。', 'Invalid corrective response mode.': '補正の応答方式が不正です。'})

# User-invoked bounded oral contact report.
TRANSLATIONS_JA.update({'Inspect Selected Oral Contacts': '選択部品の口内交差を検査', 'Report exact triangle crossings for the active tongue and selected face or teeth; preserve geometry and Actions': 'アクティブな舌と選択した顔・歯の三角形交差を検査し、形状とアクションを保護します'})

TRANSLATIONS_JA.update({'Contact Surface Part': '交差した相手部品', 'Contact Sample Number': '交差例の番号（0始まり）', 'Select Contact Vertices': '補正目標の交差した面頂点を選択', 'Select the verified source polygon in an owned editing target after checking the current report and geometry': '現在の検査と形状を照合し、所有する編集目標の元の面頂点を選択します', 'Selected {count} source vertices in the editing target.': '編集目標の元頂点を{count}個選択しました', 'Select contact vertices from Object Mode.': '頂点選択はオブジェクトモードから実行してください', 'Activate an owned prepared editing target before selecting contacts.': '所有する未確定の編集目標キーをアクティブにしてください', 'Run the owned contact report before selecting vertices.': '先にこのシーンで交差検査を実行してください', 'Contact report exceeds the selection read limit.': '接触レポートが選択の読取上限を超えています', 'Reinspect the current editing target before selecting vertices.': '現在の編集目標を再検査してから頂点を選択してください', 'The contact report frame is stale. Reinspect the current target.': '検査時のフレームから変わっています。現在の目標を再検査してください', 'Current source vertex mapping is unavailable.': '現在の元頂点への対応は未証明です', 'The contact report geometry is stale. Reinspect the current target.': '検査時の形状から変わっています。現在の目標を再検査してください', 'Choose a reported surface and an available sample number.': 'レポートにある相手部品名と交差例番号を指定してください', 'The report has no verified source polygon for this sample.': 'この交差例には証明された元の面がありません', 'Reported source polygon vertices differ from the current mesh.': 'レポートの面頂点と現在のメッシュが一致しません', 'Could not enter the editing target.': '編集目標の編集モードへ移れませんでした'})

TRANSLATIONS_JA.update({'Probe the Reported Contact Face': '交差面の内部標本を調べる', 'Read finite solid occupancy samples inside the current reported contact face; samples do not certify clearance': '現在の交差面内を有限回調べます。標本から全表面の接触解消を合格にしません', 'Solid probe requires a closed manifold surface.': '面内標本の相手部品には、閉じた多様体メッシュが必要です', 'Solid probe surface has no verified finite volume.': '相手部品の有限な体積を確認できません', 'Choose a current reported mesh surface.': '現在のレポートにある相手メッシュを指定してください', 'The probe surface geometry is stale. Reinspect the current target.': '相手部品の形状が検査時から変わっています。現在の目標を再検査してください', 'The contact face exceeds the solid probe point limit.': 'この交差面は面内標本の128点上限を超えています', 'Solid probe report exceeds its write limit.': '面内標本レポートが書込上限を超えています'})

TRANSLATIONS_JA.update({'Save Selected Parts Only': '選択した部品だけ保存', 'Save the existing channels and owned correctives of the selected parts; this does not certify all 52 expressions': '選択した部品の既存表情と所有補正を保存します。52表情の完成判定はしません', 'Existing channels only; 52 expressions are not required': '既存表情だけ保存します（52表情の完成判定はしません）', 'All 52 ARKit expressions are required': '選択全体にARKit 52表情が必要です', 'Invalid selected-part library declaration.': '選択部品ライブラリの宣言が不正です', 'Selected-part libraries require format version 4.': '選択部品ライブラリには形式バージョン4が必要です', 'Selected-part channel declaration does not match the payload.': '宣言された表情とライブラリ内の表情が一致しません'})

TRANSLATIONS_JA.update({'Shape Editing Target': '編集目標を舌根固定で整形', 'Add a Basis-relative local X/Y shrink delta to the captured target; hold the positive Y end fixed': '基準形状のX/Y縮小差分を取得済み目標へ追加し、+Y端の舌根を固定', 'Editing target shaped: {key}': '編集目標を整形：{key}', 'Use finite numeric target parameters.': '目標の設定には有限の数値を使用してください。', 'Use target width and depth scales between 0.6 and 1.0.': '目標の幅・奥行き倍率は0.6〜1.0にしてください。', 'Use a positive target displacement limit.': '目標の最大移動量には正の値を指定してください。', 'Use a target Basis with at most 100000 vertices.': '目標の基準形状は10万頂点以内にしてください。', 'The target Basis contains invalid coordinates.': '目標の基準形状に不正な座標があります。', 'The target Basis needs nonzero local width and depth.': '目標の基準形状には幅と奥行きが必要です。', 'The target displacement exceeds the chosen limit.': '目標の移動量が指定した上限を超えています。', 'Capture a new editing target before shaping it.': '新しい編集目標を取り込んでから整形してください。', 'The generated editing target was changed; keep it and capture a new target.': '生成後の編集目標が変更されています。保持して新しい目標を取り込んでください。', 'The editing target was manually changed; keep it and capture a new target.': '編集目標に手編集があります。保持して新しい目標を取り込んでください。', 'The generated editing target did not match the prepared coordinates.': '生成した編集目標が準備した座標と一致しませんでした。'})

TRANSLATIONS_JA.update({'Add local width, depth and root-preserving lift profiles to the captured editing target':'幅・奥行きと根元を保持する持ち上げを取得済み目標へ追加','Use lift values within 0.01 local units and arrival between 0.05 and 1.0.':'持ち上げ量はローカル±0.01以内、到達位置は0.05〜1.0にしてください。'})

TRANSLATIONS_JA.update({'Use a target thickness scale between 0.4 and 1.0.':'目標の厚み倍率は0.4〜1.0にしてください。'})

TRANSLATIONS_JA.update({'Plateau BOX':'範囲内を保持するBOX','Hold full correction inside half the radius, then fade to zero at the radius.':'半径の内側半分は最大補正を保持し、外側半分でゼロへ減衰します。'})

TRANSLATIONS_JA.update({'Thickness Root Hold': '厚みの根元固定', 'Keep this root portion unchanged when increasing captured target thickness': '取得した編集目標を厚くするとき、この割合の根元を固定します', 'Max Thickness Gain': '厚み増加の変形上限', 'Maximum per-vertex thickness increase in the part local coordinates': '部品ローカル座標での頂点ごとの厚み増加の上限', 'Thickness increase preserves width, depth and lift': '厚み増加時は幅・奥行き・持ち上げを保持', 'Use finite numeric thickness parameters.': '厚み設定には有限の数値を使用してください。', 'Use thickness 1 to 2, root hold 0 to 0.8 and positive displacement limits.': '厚みは1より大きく2以下、根元固定は0〜0.8、変形上限は正の値を指定してください。', 'The captured thickness reference must match the Basis vertex count.': '厚みの基準はBasisと同じ頂点数である必要があります。', 'The thickness geometry contains invalid coordinates.': '厚みの形状に不正な座標があります。', 'The thickness Basis needs nonzero local depth.': '厚みのBasisにはローカル奥行きが必要です。', 'The captured thickness reference needs nonzero local depth.': '取得した厚み基準にはローカル奥行きが必要です。', 'Thickness increase preserves width, depth and lift; use neutral shaping parameters.': '厚み増加では幅・奥行き・持ち上げを保持する設定を使用してください。'})

# Facial RNA labels observed in the actual EN GUI.
TRANSLATIONS_JA.update({'Facial Rig': '表情リグ', 'Initial Shape Strength': '初期形状の生成強度', 'Custom Pose Recipe (Optional)': '独自ポーズレシピ（任意）', 'Require All ARKit Channels': 'CSVの全表情キーを必須にする', 'Keep Existing Actions for New Take': '既存アクションを残す', 'EDIT Smoothing (Seconds)': 'EDITの平滑化（秒）', 'Eye Strength': '目の強さ', 'Mouth and Jaw Strength': '口・顎の強さ', 'Brow Strength': '眉の強さ', 'Cheek and Nose Strength': '頬・鼻の強さ', 'Tongue Strength': '舌の強さ', 'Head Controller': '頭コントローラー', 'Image Node to Replace': '置き換える画像ノード', 'Correction Color (Linear RGBA)': '補正色（線形RGBA）', 'Rim Emission Node': 'リム発光ノード', 'Rim Emission Multiplier': 'リム発光の倍率', 'Jaw Assist Limit': '舌の開口補助上限', 'Maximum jaw opening assisted by tongue input; recorded Action coefficients remain unchanged': '舌入力に応じて補う顎の開きの上限。収録アクションの係数は変更しません', 'Target Width Scale': '目標の横幅倍率', 'Target Depth Scale': '目標の奥行き倍率', 'Max Displacement': '最大移動量', 'Target Thickness Scale': '目標の厚み倍率', 'Tip Lift (Local)': '舌先の上下移動', 'Root Lift (Local)': '前側の持ち上げ', 'Lift Arrival Position': '持ち上げの到達位置', 'Root to tip spans zero to one; the front region beyond this position receives the same lift': '根元から前端までを0〜1とし、この位置から前側は同じ持ち上げ量', 'Contact Report Text': '接触レポートテキスト', 'Contact Face Probe Report Text': '面内標本レポートテキスト', 'Contact Face Probe Result': '面内標本結果', 'Contact Inspection Result': '接触検査結果', 'Import Result': '取り込み結果', 'Create Jaw Assist': '舌の開口補助を生成', 'Remove Jaw Assist': '開口補助を除去', 'Copy Material and Correct Color': '選択部品の材質を複製して色補正', 'Copy Selected Material and Adjust Rim Emission': '選択部品の材質を複製してリム発光を調整', 'Restore Original Shared Material': '選択部品を元の共有材質へ戻す', 'Bake Head Rotation CSV': '頭回転CSVをベイク', 'Source Timecode FPS': 'タイムコードのフレーム基数', 'Start Frame': '開始フレーム', 'Head Angle Units': '頭角度の単位', 'Radians': 'ラジアン', 'Use when the CSV uses radians': 'CSVがラジアンの場合', 'Degrees': '度', 'Use when the CSV uses degrees': 'CSVが度の場合', 'Pitch Local Axis': 'ピッチのローカル軸', 'Yaw Local Axis': 'ヨーのローカル軸', 'Roll Local Axis': 'ロールのローカル軸', 'Invert Pitch': 'ピッチの符号を反転', 'Invert Yaw': 'ヨーの符号を反転', 'Invert Roll': 'ロールの符号を反転', 'Switch Head Rotation Action': '頭回転アクションを切り替え', 'Recorded head rotation': '収録時の頭回転', 'Head rotation for manual editing': '手修正用の頭回転', 'Disconnect Head Capture': '頭収録の接続を解除', 'Bake Facial CSV': 'フェイシャルCSVをベイク', 'Coefficient Units': '係数の単位', '0 to 1': '0〜1', 'Standard coefficients': '標準の係数', '0 to 100': '0〜100', 'Divide percentages by one hundred': '百分率を100で割る', 'Bake Video to Facial Action': '録画動画をフェイシャルへベイク', 'Recording Is Mirrored': '録画が左右反転済み', 'Video Timestamps': '動画の時刻', 'Recorded timestamps': '録画の時刻', 'Use decoded timestamps': 'デコード時刻を使用', 'Constant FPS': '固定fps', 'Explicitly use frame indices for constant FPS recording': '固定fpsの録画で明示的にフレーム番号を使用', 'Switch Facial Action': 'フェイシャルアクションを切り替える', 'Recorded values': '収録時の値', 'Action for manual editing': '手修正するアクション', 'Export Facial Working Copy': '顔制作コピーを書き出す', 'Generate 52 Initial Shapes from ARP': 'ARPから52表情の初期形状を生成', 'Apply Correction Preset': '初期表情へ補正プリセットを反映', 'Restore Archived Initial Shapes': '保管した初期表情へ戻す'})

TRANSLATIONS_JA.update({'Rim Mix or Emission Node':'リム合成／発光ノード','Rim Multiplier':'リムの倍率','Adjust Selected Material Rim':'選択材質のリムを調整'})

TRANSLATIONS_JA.update({'Shape Captured Tip': '取り込んだ舌先を整形', 'Tip Width Scale': '舌先の幅倍率', 'Tip Thickness Scale': '舌先の厚み倍率', 'Tip Shortening (Local)': '舌先の短縮量', 'Tip Root Hold': '固定する舌根の割合', 'Hold the captured root and change only the distal width, thickness and length': '取り込んだ形状の舌根を保持し、先端の幅・厚み・長さだけを変更', 'Use finite captured tip parameters.': '舌先の設定には有限の数値を使用してください。', 'Tip shortening would fold the longitudinal profile.': '短縮すると形状が折り返します。短縮量を小さくしてください。', 'The captured tip reference contains invalid coordinates.': '舌先の参照形状に不正な座標があります。', 'The captured tip needs nonzero local depth.': '舌先の参照形状には奥行きが必要です。', 'Use a boolean captured tip mode.': '舌先整形のモード設定が不正です。', 'Use tip width 1 to 2, thickness 1 to 3, shortening 0 to 0.02 and root hold 0 to 0.8.': '舌先の幅は1〜2、厚みは1〜3、短縮量は0〜0.02、舌根固定は0〜0.8にしてください。'})

TRANSLATIONS_JA.update({'First Ramp Start': '第一入力の開始値', 'Second Ramp Start': '第二入力の開始値', 'Use finite ramp starts between zero and one.': '開始値は0〜1の有限の数値にしてください。', 'Ramp starts require the RAMP response.': '開始値はRAMP応答で使用してください。', 'Each ramp start must be below its full-response value.': '各開始値は、その入力の最大応答値より小さくしてください。', 'Invalid ramp start pair.': '開始値は2つの数値にしてください。'})

TRANSLATIONS_JA.update({'Tip Retraction (Local)': '舌先中央の後退', 'Retract the distal center along local Y while holding the captured root and preserving width and thickness': '取り込んだ根元・幅・厚みを保持し、舌先の中央をローカルY方向へ少量後退させます', 'Captured tip center retraction must be between 0 and 0.01.': '舌先中央の後退量は0〜0.01にしてください。', 'The captured tip needs nonzero local width.': '舌先の参照形状には幅が必要です。'})

# rows of Facial CSV Capture (and its neutral-draft dialog) that were still English in the Japanese UI.
TRANSLATIONS_JA.update({
 'Capture Destination': '取り込み先',
 'ARKit controller bones': 'ARKitのコントローラーの骨',
 'Existing shape-key comparison mode': '既存のシェイプキーで比べる',
 'Infer Zero Nose Sneer': '鼻しわが0なら推定',
 'Infer Zero Cheek Squint': '頬の持ち上げが0なら推定',
 'Only for present columns whose raw maximum is at most0.0004; measured values take priority': 'RAWの最大値が0.0004以下の列だけ推定します。測れた値が優先です',
 'Nose Estimator k': '鼻しわ推定の係数k',
 'Cheek Estimator k': '頬の持ち上げ推定の係数k',
 'Source CSV': '元のCSV',
 'Neutral Seconds': '無表情の秒数',
 'First N Frames (0 = Seconds)': '先頭のフレーム数（0なら秒数を使う）',
})

# Build Calibration Table and Capture Inspection.
TRANSLATIONS_JA.update({
 'Capture CSV': '収録のCSV',
 'Frames': 'コマ数',
 'Channel': '係数',
 'RAW Maximum': 'RAWの最大',
 'EDIT Maximum': 'EDITの最大',
 'EDIT Stick Share': 'EDITの張り付きの割合',
 'Peak Row': '山の行',
 'Peak Time': '山の時刻',
 'Neutral Residual': '真顔の残り値',
 'Flags': '印',
 'Has EDIT': 'EDITあり',
 'Active Capture': '選んでいる収録',
 'Previous Table (Optional)': '前の表（任意）',
 'Targeted Maxima (Optional)': '狙った表情の最大（任意）',
 'Percentile Rounding Digits': '分位点の丸めの桁',
 'Rule A: jawOpen': '決まりA：jawOpen',
 'jawOpen Knot 1 In': 'jawOpen 折れ点1の入力',
 'jawOpen Knot 1 Out': 'jawOpen 折れ点1の出力',
 'jawOpen Knot 2 In': 'jawOpen 折れ点2の入力',
 'jawOpen Knot 2 Out': 'jawOpen 折れ点2の出力',
 'Narrow Span Below': '幅が狭いとみなす線',
 'Target Needed for Rule D': '決まりDに要る狙った最大',
 'Minimum Span': '幅の下限',
 'Gaze Neutral Percentile': '視線のneutralの分位点',
 'Gaze Maximum Percentile': '視線のmaxの分位点',
 'eyeLookDownLeft Cap': 'eyeLookDownLeftの頭打ち',
 'eyeLookInLeft Cap': 'eyeLookInLeftの頭打ち',
 'eyeLookOutLeft Cap': 'eyeLookOutLeftの頭打ち',
 'eyeLookUpLeft Cap': 'eyeLookUpLeftの頭打ち',
 'eyeLookDownRight Cap': 'eyeLookDownRightの頭打ち',
 'eyeLookInRight Cap': 'eyeLookInRightの頭打ち',
 'eyeLookOutRight Cap': 'eyeLookOutRightの頭打ち',
 'eyeLookUpRight Cap': 'eyeLookUpRightの頭打ち',
 'Visible Share Needed': '見える割合の下限',
 'Brow Down Neutral Percentile': '眉下げのneutralの分位点',
 'Brow Raise Neutral Percentile': '眉上げのneutralの分位点',
 'Brow Maximum Percentile': '眉のmaxの分位点',
 'No-Table Neutral Percentile': '表が無い時のneutralの分位点',
 'No-Table Max Percentile': '表が無い時のmaxの分位点',
 'Gaze/Brow Neutral from Segment': '視線と眉のneutralを真顔から',
 'Neutral Capture (0 = All)': '真顔の区間の収録番号（0は全部）',
 'Neutral From (Seconds)': '真顔の始まり（秒）',
 'Neutral To (Seconds)': '真顔の終わり（秒）',
 'Stick Line': '張り付きとみなす値',
 'Stick Share Limit': '張り付きの割合の上限',
 'Rule G: Widen Sticking Channels': '決まりG：張り付く係数の幅を広げる',
 'Neutral Residual Line': '真顔の残り値の線',
 'Use the New Table for Import': '作った表を取り込みに使う',
 'Build Result': '作った結果',
 'Capture to Inspect': '点検する収録のCSV',
 'Reach Line': '届いたとみなす値',
 'Check Neutral From (s)': '点検の真顔の始まり（秒）',
 'Check Neutral To (s)': '点検の真顔の終わり（秒）',
 'Peak Jump Start Frame': '山へ移る時の開始フレーム',
 'Active Channel': '選んでいる係数',
 'Inspection Result': '点検の結果',
 'Add Captures': '収録を足す',
 'Add one or more RAW ARKit capture CSV files to the list used to build a calibration table': '校正表を作るのに使う一覧へ、ARKitの収録のRAWのCSVを1つ以上足します',
 'Remove Capture': '収録を外す',
 'Remove the active capture from the list (the file is not touched)': '選んでいる収録を一覧から外します（ファイルには触りません）',
 'Remove All': '全部外す',
 'Count Distribution': '分布を数える',
 'Read every listed capture and count its frames (nothing is written)': '一覧の収録を全部読んでコマ数を数えます（何も書きません）',
 'Rule Defaults': '決め方の既定値',
 'Put the documented v4 or v5 rule values into the rule settings (gaze caps, files and segment are kept)': '文書にあるv4かv5の決まりの値を設定に入れます（視線の頭打ち・ファイル・区間はそのまま）',
 'Rules': '決め方',
 'v5 Rules': 'v5 の決め方',
 'v4 Rules': 'v4 の決め方',
 'v4 rules with brow raise neutral at the 75th percentile': '眉上げのneutralを75%点にしたv4の決まり',
 'Rules A, C, D, E and F of calibration v4': '校正表v4の決まりA・C・D・E・F',
 'Read Gaze Caps from Sweep': '掃引のJSONから視線の頭打ちを読む',
 'Set the eyeLook caps from a measured visibility sweep JSON (upper end where the visible share stays at or above the line)': '測った黒目の見え方の掃引JSONから、eyeLookの頭打ち（見える割合が下限以上で続く上の端）を入れます',
 'Build Calibration Table': '校正表を作る',
 'Count the listed captures and write a new calibration table JSON (plus a _report.json) with the rule settings': '一覧の収録を数え、決め方の設定で新しい校正表のJSON（と _report.json）を書き出します',
 'Inspect Capture': '点検する',
 'Read the capture CSV and list, per channel, RAW and EDIT reach, stick share, peak row and neutral residual with the current import settings': '収録のCSVを読み、今の取り込みの設定で、係数ごとのRAWとEDITの届く範囲・張り付きの割合・山の行・真顔の残り値を一覧にします',
 'Go to Peak Frame': '山のコマへ移る',
 'Move the current frame to the RAW peak of the active channel in the inspection list': '点検の一覧で選んでいる係数のRAWの山のコマへ、今のフレームを移します',
 'Export Inspection Table': '点検表を書き出す',
 'Write the last inspection table to a new JSON or CSV file': '最後の点検表を新しいJSONかCSVのファイルへ書き出します',
 'Table Format': '表の形式',
 'Inspection JSON': '点検表のJSON',
 'Inspection CSV': '点検表のCSV',
 'Choose capture CSV files within 20 MiB': '20 MiB以内の収録のCSVを選んでください',
 'Use at most 64 captures.': '収録は64本までにしてください。',
 'Add at least one capture CSV.': '収録のCSVを1本以上足してください。',
 'Protecting an existing file; choose a new file name': '既にあるファイルを守ります。新しい名前を選んでください',
 'Choose the capture CSV to inspect.': '点検する収録のCSVを選んでください。',
 'Inspect a capture first.': '先に収録を点検してください。',
 'The peak frame is outside the supported range.': '山のコマが扱える範囲の外です。',
 'Rule values must be finite numbers.': '決まりの値は有限の数にしてください。',
 'Percentile rounding must be 0 to 9 digits.': '分位点の丸めの桁は0〜9にしてください。',
 'Percentiles must be between 0 and 100': '分位点は0〜100にしてください',
 'Rule values must be between 0 and 1': '決まりの値は0〜1にしてください',
 'Minimum span must be at least 0.000001.': '幅の下限は0.000001以上にしてください。',
 'jawOpen knots need 0 < x1 < x2 < 1 and 0 <= y1 <= y2 <= 1.': 'jawOpenの折れ点は 0 < 入力1 < 入力2 < 1、0 <= 出力1 <= 出力2 <= 1 にしてください。',
 'Gaze caps must be above 0 and at most 1': '視線の頭打ちは0より大きく1以下にしてください',
 'Neutral segment needs take 0 or more and start <= end.': '真顔の区間は、収録番号を0以上、始まりを終わり以下にしてください。',
 'No values to count.': '数える値がありません。',
 'Choose a JSON/CSV file within 2 MiB': '2 MiB以内のJSONかCSVを選んでください',
 'Targets must be a JSON or CSV file.': '狙った表情の最大はJSONかCSVにしてください。',
 'Unknown target table format.': '狙った表情の最大の形式が分かりません。',
 'The target table has no ARKit channel values.': '狙った表情の最大にARKitの係数の値がありません。',
 'Unknown sweep format.': '掃引の形式が分かりません。',
 'The sweep file has no eyeLook channels with visible amounts.': '掃引のファイルに、見える量のあるeyeLookの係数がありません。',
 'The neutral segment take number is larger than the capture count.': '真顔の区間の収録番号が、収録の数より大きいです。',
 'Every capture must have these columns': '全部の収録に次の列が要ります',
 'The neutral segment has no frames.': '真顔の区間にコマがありません。',
 'Inspection settings must be finite numbers.': '点検の設定は有限の数にしてください。',
 'Neutral segment needs 0 <= start <= end.': '真顔の区間は 0 <= 始まり <= 終わり にしてください。',
 'The neutral segment has no samples.': '真顔の区間に標本がありません。',
})
