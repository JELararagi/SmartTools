# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Help text for every Smart Shapekey section header (the "?" button).

Pure data.  ``help.py`` imports this module only when a help popup is opened,
so normal N-panel drawing never loads it.  Every entry carries the six parts
required by the SmartTools common specification (2026-10-17):

    purpose   - what the feature does
    prepare   - what to select / which mode before using it
    steps     - numbered operating steps
    settings  - every button and setting, with recommended values
    verify    - how to check the result
    undo      - how to undo, cautions and limits

Each part is a pair ``(english_lines, japanese_lines)``.
"""

SECTION_ORDER = ('purpose', 'prepare', 'steps', 'settings', 'verify', 'undo')

SECTION_TITLES = {
    'purpose': ('1. What it does', '1. 何をする機能か'),
    'prepare': ('2. Before you start', '2. 使う前の準備'),
    'steps': ('3. Steps', '3. 操作の手順'),
    'settings': ('4. Buttons and settings (recommended values)', '4. 各ボタン・設定の意味とおすすめの値'),
    'verify': ('5. Checking the result', '5. 結果の確かめ方'),
    'undo': ('6. Undo, cautions and limits', '6. 元に戻す方法・注意・限界'),
}


def _e(title, **parts):
    entry = {'title': tuple(title)}
    for key in SECTION_ORDER:
        en, ja = parts.get(key, ((), ()))
        entry[key] = (tuple(en), tuple(ja))
    return entry


HELP_DATA = {}

# ---------------------------------------------------------------------------
# Root panel
# ---------------------------------------------------------------------------
HELP_DATA['smart_shapekey_suite'] = _e(
    ('Smart Shapekey', 'Smart Shapekey'),
    purpose=(
        ['A set of tools for making, organizing and driving Shape Keys, shown in the 3D View sidebar (N-panel).',
         'From top to bottom: Always-on Features, Basis and New Map, Maps, Mirror Tools, Export, Save/Load, '
         'Mirror Settings, Modifiers, Drivers and Control / Tracking.',
         'Press the "?" at the right end of any header to read how that section works. All explanations live in these "?" popups.'],
        ['シェイプキー（形の変化）を作る・整理する・動かすための道具を、3D ビューのサイドバー（N パネル）にまとめた物です。',
         '上から順に「常時機能切り替え」「Basis と新規マップ」「マップ」「ミラーと反転ツール」「書き出し」'
         '「保存と読み込み」「ミラー設定」「モディファイア」「ドライバー」「制御・トラッキング」が並びます。',
         '各見出しの右端の「？」を押すと、その欄の使い方が出ます。解説はすべてこの「？」の中にあります。']),
    prepare=(
        ['In the 3D View press N to open the sidebar and choose the "Smart Shapekey" tab.',
         'Select one mesh object and use Object Mode or Edit Mode. Otherwise the panel shows only a status line such as '
         '"Select a mesh object." or "Switch to Object Mode or Edit Mode."',
         'Save the .blend under a new name before you start so you can always go back.'],
        ['3D ビューで N キーを押してサイドバーを開き、「Smart Shapekey」タブを選びます。',
         'メッシュのオブジェクトを 1 つ選び、オブジェクトモードか編集モードにします。それ以外の時は、パネルに'
         '「メッシュオブジェクトを選択してください。」などの状態の 1 行だけが出ます。',
         '始める前に .blend を別名で保存しておくと、いつでも元へ戻れます。']),
    steps=(
        ['To build and keep shapes: use Basis and New Map, then Maps, then Export.',
         'To apply modifiers while keeping Shape Keys: open Modifiers.',
         'To make a driver expression: open Drivers.',
         'To move Shape Keys with a joystick, UDP input or a webcam, and to bake facial captures (CSV / video): open Control / Tracking.',
         'Features that keep running in the background (HUD, UDP receiver, camera) are switched on and off only in Always-on Features.'],
        ['形を作って残したい時：「Basis と新規マップ」→「マップ」→「書き出し」の順に使います。',
         'シェイプキーを保ったままモディファイアを適用したい時：「モディファイア」を開きます。',
         'ドライバーの式を作りたい時：「ドライバー」を開きます。',
         'ジョイスティック・UDP・ウェブカメラでシェイプキーを動かす時と、顔の収録（CSV・動画）を焼き込む時：「制御・トラッキング」を開きます。',
         '背景で動き続ける機能（HUD・UDP の受信・カメラ）は、「常時機能切り替え」でだけ入切します。']),
    settings=(
        ['Header triangle: opens or closes that section. The open state is remembered.',
         'Header "?": opens the help of that section. Reading help never changes the scene.'],
        ['見出しの三角：押すとその欄が開閉します。開閉の状態は覚えられます。',
         '見出しの「？」：その欄のヘルプを開きます。ヘルプを開いてもシーンは変わりません。']),
    verify=(
        ['Open a section and check that its buttons are not greyed out. Grey buttons mean the selection or the mode does not match; '
         'read "Before you start" in that section\'s help.'],
        ['欄を開き、ボタンが灰色になっていない事を確かめます。灰色の時は、選んでいる物かモードが条件に合っていません。'
         'その欄のヘルプの「使う前の準備」を見てください。']),
    undo=(
        ['Most operations can be undone with Ctrl+Z. Files written outside Blender (exports) are not removed by Ctrl+Z.',
         'When Smart Tools Manager hides this panel for an editor, the panel is not shown there.'],
        ['ほとんどの操作は Ctrl+Z で戻せます。Blender の外へ書き出したファイルは Ctrl+Z では消えません。',
         'Smart Tools Manager でこのパネルを隠している画面では、パネルは表示されません。']),
)

# ---------------------------------------------------------------------------
# Always-on toggles
# ---------------------------------------------------------------------------
HELP_DATA['always_on'] = _e(
    ('Always-on Features', '常時機能切り替え'),
    purpose=(
        ['One place to switch on and off every Smart Shapekey feature that can keep running in the background '
         '(handlers, timers, draw callbacks, a UDP socket, a camera thread or a viewport HUD).',
         'A feature that is Disabled is fully stopped, so startup, idle drawing and ordinary modeling stay light.'],
        ['背景で動き続ける可能性がある機能（ハンドラー・タイマー・描画・UDP のソケット・カメラのスレッド・ビューポートの HUD）を、1 か所でまとめて入切する欄です。',
         '「無効」の機能は完全に止まります。そのため、起動・待機中の描画・ふつうのモデリングは軽いままです。']),
    prepare=(
        ['Usually leave this group closed. Prepare the section that uses the feature first (for example Control / Tracking).'],
        ['ふだんは閉じたままでかまいません。先に、その機能を使う欄（例：「制御・トラッキング」）の準備を済ませます。']),
    steps=(
        ['Open the group with the header triangle.',
         'Press the button on the right of the feature row ("Disabled") so that it reads "Enabled".',
         'When you are finished, press it again to return to "Disabled".'],
        ['見出しの三角で欄を開きます。',
         '使いたい機能の行の右のボタン（「無効」）を押して「有効」にします。',
         '使い終わったら、もう一度押して「無効」に戻します。']),
    settings=(
        ['N-panel State Save: while Enabled, every panel setting change is saved at once to a JSON file in the Blender config folder '
         'and restored next time. Turning it off saves that Off state once and blocks further writes until enabled again. '
         'Recommended: Enabled (default).',
         'Axis UI: shows the interactive 2D Shape Axis HUD (joystick) in the 3D View. Recommended: only while moving values by eye.',
         'Frame Sync: updates animated Shape Axis handles during playback and scrubbing. Recommended: only while playing keyed axes.',
         'External Tracker (UDP): receives X/Y values from an external sender over UDP (socket, receive thread and timer). '
         'Recommended: only while the sender is running.',
         'Face Tracker (Built-In): reads your face from a webcam and drives Shape Axis groups (camera, worker thread and timer). '
         'Recommended: only while tracking.',
         'Face Tracker Point HUD: draws the built-in tracker\'s face landmarks in the 3D View. Recommended: only while checking landmark numbers.'],
        ['Nパネル状態保存：有効の間は、パネルの設定を変えるたびに Blender の設定フォルダーの JSON へすぐ保存し、次に開いた時に戻します。'
         '無効にすると、その「無効」だけを 1 回保存し、再び有効にするまで書き込みを止めます。おすすめ：有効（既定）。',
         'シェイプ軸 HUD：3D ビューに、シェイプ軸の 2D の HUD（ジョイスティック）を出し、マウスで動かせるようにします。おすすめ：値を見ながら動かす間だけ有効。',
         'フレーム同期：再生やタイムラインのスクラブの時に、アニメーションしたシェイプ軸のハンドルを更新します。おすすめ：軸にキーを打って再生する時だけ有効。',
         '外部トラッカー UDP：外部の送信アプリから UDP で X/Y の値を受け取ります（ソケット・受信スレッド・タイマーを使います）。おすすめ：送信アプリを動かしている間だけ有効。',
         'フェイストラッカー（内蔵）：ウェブカメラで顔を読み、シェイプ軸を動かします（カメラ・計算スレッド・タイマーを使います）。おすすめ：トラッキングする間だけ有効。',
         'フェイストラッカーポイントHUD：内蔵トラッカーの顔の点（ランドマーク）を 3D ビューに描きます。おすすめ：点の番号を確かめる間だけ有効。']),
    verify=(
        ['The row button reads "Enabled" and is shown highlighted while the feature runs.',
         'If a feature fails to start, the switch returns to "Disabled" by itself and an error is reported, so the display never disagrees with reality.'],
        ['動いている間は、その行のボタンが「有効」になり、強調して表示されます。',
         '開始に失敗した時は、表示と実際がずれないよう自動で「無効」へ戻り、エラーが出ます。']),
    undo=(
        ['Set the row back to "Disabled" to stop it. Closing Blender stops everything.',
         'A camera or a UDP port can be held by another application. If it cannot start, close the other application first.',
         'Features saved as Enabled are started again after you open another .blend file.'],
        ['「無効」に戻すと止まります。Blender を閉じると全部止まります。',
         'カメラや UDP のポートは、他のアプリが使っていると開けません。開始できない時は、先に他のアプリを閉じます。',
         '「有効」で保存された機能は、別の .blend を開いた後に、もう一度開始されます。']),
)

# ---------------------------------------------------------------------------
# Core (MorphMapper style)
# ---------------------------------------------------------------------------
HELP_DATA['smart_shapekey_core'] = _e(
    ('Basis and New Map', 'Basis と新規マップ'),
    purpose=(
        ['Keeps the shape of a mesh inside this add-on as a Basis (the reference shape) plus one difference per channel ("map"), '
         'the same idea as MorphMapper in 3ds Max.',
         'You can build many shapes (expressions, correctives) on one mesh, switch between them, and finally export them as ordinary Shape Keys.'],
        ['メッシュの形を、Basis（基準の形）と、そこからの差（チャンネル＝「マップ」）として、このアドオンの中に保存します。3ds Max の MorphMapper と同じ考え方です。',
         '1 つのメッシュの上で表情や補正の形をいくつも作り、切り替えながら直し、最後にふつうのシェイプキーとして書き出せます。']),
    prepare=(
        ['Select one mesh. It must be local and not shared with other objects; linked or shared meshes are refused.',
         'Do not change the vertex count or connections after Set Base. Otherwise storing and switching shapes is refused.',
         'Put the mesh in its reference shape (for example the neutral face) before Set Base.',
         'Turn Auto Keying off. Maps cannot be switched while it is on.'],
        ['メッシュを 1 つ選びます。ローカルで、他のオブジェクトと共有していないメッシュが必要です（リンク・共有のメッシュは断られます）。',
         '「ベースを設定」の後は、頂点の数とつながりを変えないでください。変えると、形の保存と切り替えが断られます。',
         '「ベースを設定」の前に、メッシュを基準の形（例：無表情）にしておきます。',
         'オートキー（自動キー挿入）を切っておきます。オンの間はマップを切り替えられません。']),
    steps=(
        ['With the mesh in its reference shape, press Set Base. The first time, confirm with All Polygons. The visible mesh does not change.',
         'Press New, type a name and confirm. The current shape becomes a new map and that map becomes active.',
         'Edit the mesh into the shape you want with ordinary Blender editing (Edit Mode, sculpting and so on).',
         'In the Maps list click another map (for example Basis). Your edit is stored into the map you leave, and the mesh changes to the clicked map.',
         'Repeat 2 to 4 for more shapes, then use Export to make Shape Keys.'],
        ['メッシュを基準の形にしたまま「ベースを設定」を押します。初めての時は「すべてのポリゴン」で確定します。見えているメッシュは変わりません。',
         '「新規」を押し、名前を入れて確定します。今の形が新しいマップとして保存され、そのマップが選ばれた状態になります。',
         'ふつうの Blender の編集（編集モード・スカルプトなど）で、メッシュを作りたい形に直します。',
         '「マップ」の一覧で別のマップ（例：Basis）を押します。今の編集が、離れるマップへ保存され、押したマップの形に切り替わります。',
         '2〜4 を繰り返して形を増やし、「書き出し」でシェイプキーにします。']),
    settings=(
        ['Object: name of the target mesh (status line).',
         'Verts / Maps: vertex count of the target and number of stored maps (status line).',
         'Set Base: records the Basis again. From the second time you can choose Selected Polygons (only vertices of faces selected in Edit Mode take '
         'the current shape) or All Polygons. Existing maps are recalculated so that their absolute shapes stay the same. Recommended: All Polygons the first time.',
         'New: creates a new map from the current mesh shape. The dialog shows the reference map it starts from and the channel number. An empty name is refused.'],
        ['オブジェクト：対象のメッシュの名前です（状態の表示）。',
         '頂点数 / マップ数：対象の頂点の数と、保存したマップの数です（状態の表示）。',
         'ベースを設定：Basis を記録し直します。2 回目からは「選択ポリゴン」（編集モードで選んだ面の頂点だけを今の形にする）か「すべてのポリゴン」を選べます。'
         '既にあるマップは、見た目の形が変わらないように差を計算し直します。おすすめ：初回は「すべてのポリゴン」。',
         '新規：今のメッシュの形から新しいマップを作ります。ダイアログに、元にする参照マップとチャンネル番号が出ます。空の名前は使えません。']),
    verify=(
        ['Check that "Maps" increased and the new row appears in the Maps list.',
         'Click Basis and the map alternately in the list and check that the mesh switches shape.'],
        ['「マップ数」が増え、「マップ」の一覧に新しい行がある事を確かめます。',
         '一覧で Basis とマップを交互に押し、形が切り替わる事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes these operations.',
         'An edit is stored only when you switch to another map (or press New). If you export without switching, the last edit is not included.',
         'The data lives inside this mesh. Deleting the mesh deletes its maps.'],
        ['これらの操作は Ctrl+Z で戻せます。',
         '編集した形は、別のマップへ切り替えた時（または「新規」を押した時）に保存されます。切り替えずに書き出すと、最後の編集は入りません。',
         'データはこのメッシュの中にあります。メッシュを消すと、マップも消えます。']),
)

HELP_DATA['smart_shapekey_maps'] = _e(
    ('Maps', 'マップ'),
    purpose=(
        ['The list of stored maps. Click a row to show that shape, and manage names, order and deletion here.'],
        ['保存したマップの一覧です。行を押すとその形に切り替わります。名前・並び順・消去もここで管理します。']),
    prepare=(
        ['Create maps first with Set Base and New in Basis and New Map.',
         'Turn Auto Keying off; switching maps is refused while it is on.'],
        ['先に「Basis と新規マップ」の「ベースを設定」と「新規」でマップを作っておきます。',
         'オートキーを切っておきます。オンの間はマップの切り替えが断られます。']),
    steps=(
        ['With the mode button showing "Select", click a row. The mesh changes to that shape and the previous shape is stored into the map you left.',
         'To reorder maps or to choose which maps to export, press the mode button so that it shows "Edit". Check boxes appear and clicking a row no longer changes the mesh.',
         'In Edit, tick the check boxes and use Up, Down, Sort by Name or ID Order.',
         'If you want to export only the ticked maps, run Export while still in Edit.',
         'Press the mode button again to return to "Select". Leaving Edit clears all ticks.'],
        ['モードのボタンが「選択」の状態で行を押します。メッシュがその形に切り替わり、直前の形は離れたマップへ保存されます。',
         '並べ替えたい時や、書き出すマップを選びたい時は、モードのボタンを押して「編集」にします。行の左にチェックが出て、行を押しても形は変わらなくなります。',
         '「編集」の状態で、チェックを付けたり、「上へ」「下へ」「名前順」「ID順」を使います。',
         'チェックしたマップだけを書き出したい時は、「編集」のまま「書き出し」を実行します。',
         'もう一度モードのボタンを押すと「選択」に戻ります。「編集」を出るとチェックはすべて外れます。']),
    settings=(
        ['List: each row shows the map name and its channel number. Basis has the mesh icon and cannot be deleted.',
         'Select / Edit (mode button): "Select" switches the mesh shape when a row is clicked; "Edit" ticks and reorders rows without changing the shape. Recommended: Select for normal work.',
         'Up / Down (Edit only): move the chosen rows. Export follows this order.',
         'Sort by Name / ID Order (Edit only): order rows by name, or back to creation order (channel number). Shapes and channel numbers do not change.',
         'Rename: renames the active map. A name already used is refused.',
         'Clear: makes the active map equal to Basis, either on Selected Polygons (faces selected in Edit Mode) or on All Polygons.',
         'Delete: deletes the active map after a confirmation. Basis cannot be deleted. The mesh then shows the first row.',
         'Delete All: deletes all map data of this mesh after a confirmation. The shape currently visible stays as it is (on a mesh with Shape Keys, it returns to the mix of the keys).',
         'Rename, Clear and Delete are greyed out while Basis is the active row.'],
        ['一覧：行ごとにマップ名とチャンネル番号が出ます。Basis はメッシュのアイコンで、消せません。',
         '選択 / 編集（モードのボタン）：「選択」は行を押すと形が切り替わる状態、「編集」は形を変えずにチェックと並べ替えをする状態です。おすすめ：ふだんは「選択」。',
         '上へ・下へ（「編集」の時だけ）：選んだ行を動かします。書き出しはこの順になります。',
         '名前順 / ID順（「編集」の時だけ）：名前の順、または作った順（チャンネル番号の順）に並べます。形とチャンネル番号は変わりません。',
         '名前変更：選んでいるマップの名前を変えます。既にある名前は使えません。',
         'クリア：選んでいるマップを Basis と同じ形に戻します。「選択ポリゴン」（編集モードで選んだ面）か「すべてのポリゴン」を選びます。',
         '削除：確認の後、選んでいるマップを消します。Basis は消せません。消した後は一覧の最初の行の形になります。',
         'すべて削除：確認の後、このメッシュのマップのデータを全部消します。今見えている形はそのまま残ります。',
         'Basis を選んでいる間は、「名前変更」「クリア」「削除」は灰色です。']),
    verify=(
        ['Click rows in Select and watch the shape change in the viewport.',
         'The number next to each name is the channel number; it stays the same after sorting.'],
        ['「選択」の状態で行を押し、ビューポートで形が変わる事を確かめます。',
         '名前の横の番号はチャンネル番号です。並べ替えても変わりません。']),
    undo=(
        ['Ctrl+Z undoes list operations.',
         'Delete All cannot be undone once you save and close the file. Save a copy first.',
         'If switching fails, the active row and the shape return to the previous state and an error is shown.',
         'On a mesh with Shape Keys, the map you press is shown through one extra Shape Key, SKM_Map_Preview, added on top of the values you set. Basis and your values do not change, and the key disappears when you press Basis or Delete All. If you press Set Base while another map is selected, that shape becomes the new Basis row, so the key stays until Delete All. Do not edit it.',
         'On a mesh with Shape Keys, switch maps in Object Mode (in Edit Mode the switch is refused), and the shape of the map you leave is not stored again. It does not show while Shape Key Lock is on, and Absolute Shape Keys cannot show it.'],
        ['一覧の操作は Ctrl+Z で戻せます。',
         '「すべて削除」は、保存してファイルを閉じた後は戻せません。先に控えを保存してください。',
         '切り替えに失敗した時は、選んでいた行と形が元に戻り、エラーが出ます。',
         'シェイプキーのあるメッシュでは、押したマップの形を、シェイプキー 1 本（SKM_Map_Preview）で、利用者の値の上に重ねて見せます。Basis と利用者の値は変わりません。Basis か「すべて削除」を押すとこのキーは消えます。別のマップを選んだまま「ベースを設定」を押すと、その形が新しい Basis の行になるので、「すべて削除」までキーが残ります。このキーは編集しないでください。',
         'シェイプキーのあるメッシュでは、マップの切り替えはオブジェクトモードで行います（編集モードでは断ります）。離れたマップへの保存もしません。シェイプキーの固定（ピン）がオンの間は見えません。絶対シェイプキーでは見せられません。']),
)

HELP_DATA['smart_shapekey_mirror_tools'] = _e(
    ('Mirror Tools', 'ミラーと反転ツール'),
    purpose=(
        ['Edits the stored shape of the active map on the selected vertices: flips the change around Basis, or copies the change of one side to the other side.'],
        ['選んでいるマップの形を、選択した頂点について直します。Basis を境に変化の向きを反転するか、片側の変化を反対側へ写します。']),
    prepare=(
        ['Press a map other than Basis in the Maps list. The buttons are greyed out while Basis is the active row.',
         'Select vertices in Edit Mode. The selection stays in use even after you return to Object Mode.',
         'Check the axis and center in Mirror Settings. The defaults (X, center 0) suit a model built symmetrically around the world center line.'],
        ['「マップ」の一覧で Basis 以外のマップを押します。Basis の行を選んでいる間、ボタンは押せません。',
         '編集モードで頂点を選びます。選択はオブジェクトモードに戻っても使われます。',
         '「ミラー設定」の軸と中心を確かめます。既定（X・中心 0）は、中心線を境に左右対称に作ったモデルに合います。']),
    steps=(
        ['To flip the change: select the vertices and press Invert Selected Shape.',
         'To make the two sides match: shape one side, select the vertices of that side (selecting all is fine), and press the button whose arrow starts from that side.',
         'Check the result in the viewport. The stored map is updated at once.'],
        ['変化の向きを反転する時：頂点を選び、「選択頂点の形状を反転」を押します。',
         '左右をそろえる時：片側だけ形を作り、その側の頂点を選び（全部選んでもかまいません）、矢印がその側から始まるボタンを押します。',
         '3D ビューで結果を確かめます。保存したマップはその場で更新されます。']),
    settings=(
        ['Invert Selected Shape: each selected vertex moves to the opposite side of its Basis position (new = 2 x Basis - current).',
         '-X -> +X / +X -> -X: the change of the selected vertices on the side where the arrow starts is copied, flipped, onto the matching vertices of the other side. '
         'The letter follows the axis in Mirror Settings. Vertices on the other side do not need to be selected. Vertices on the center line do not change.'],
        ['選択頂点の形状を反転：選んだ頂点が、Basis の位置を境に反対側へ動きます（新しい形 = 2 × Basis − 今の形）。',
         '-X → +X ／ +X → -X：矢印が始まる側で選んだ頂点の変化を、向きを反転して、反対側の対応する頂点へ写します。'
         '文字は「ミラー設定」の軸に合わせて変わります。反対側の頂点は選ばなくてかまいません。中心線の上の頂点は変わりません。']),
    verify=(
        ['Press Basis and then the map again in the list, and check that the shape stays.',
         'Look at the mesh from the front and compare both sides.'],
        ['一覧で Basis を押してからそのマップを押し直し、形が残っている事を確かめます。',
         '正面からメッシュを見て、左右を見比べます。']),
    undo=(
        ['Ctrl+Z undoes these buttons.',
         'Pressing the opposite arrow does not restore the side that was overwritten. Use Ctrl+Z.',
         'If nothing can be copied (no selected vertex on the source side, or no counterpart within the Tolerance of Mirror Settings) an error is shown and nothing changes.',
         'Matching vertices are found on the Basis shape, so a vertex is copied only where the Basis is symmetric around the center.'],
        ['これらのボタンは Ctrl+Z で戻せます。',
         '逆の矢印を押しても、上書きされた側は元に戻りません。Ctrl+Z を使ってください。',
         '写せる頂点が無い時（元の側に選んだ頂点が無い、「ミラー設定」の許容値の中に対応する頂点が無い）は、エラーが出て何も変わりません。',
         '対応する頂点は Basis の形で探します。Basis が中心を境に対称でない所の頂点は写りません。']),
)

HELP_DATA['smart_shapekey_mirror_settings'] = _e(
    ('Mirror Settings', 'ミラー設定'),
    purpose=(
        ['The mirror plane used by the -X -> +X / +X -> -X buttons of Mirror Tools. Each mesh keeps its own values.'],
        ['「ミラーと反転ツール」の「-X → +X」「+X → -X」のボタンが使う、鏡の面の設定です。メッシュごとに値を持ちます。']),
    prepare=(
        ['Select the mesh. Nothing else is needed.'],
        ['メッシュを選びます。ほかに準備はありません。']),
    steps=(
        ['Set the axis across which the two sides face each other.',
         'If the model is not centered on the world origin, enter the coordinate of its center line in X, Y or Z (only the one for the chosen axis is used).',
         'If some vertices are not copied, raise the Tolerance.'],
        ['左右が向かい合う軸を選びます。',
         'モデルの中心線がワールドの原点に無い時は、中心線の座標を X・Y・Z に入れます（使うのは選んだ軸の値だけです）。',
         '写らない頂点がある時は、許容値を上げます。']),
    settings=(
        ['Axis: X, Y or Z. Recommended: X.',
         'X / Y / Z: the center coordinate in the local space of the mesh. Recommended: 0.',
         'Tolerance: the largest distance allowed when looking for the matching vertex on the other side. Default 0.001. Raise it only if the model is slightly out of symmetry.'],
        ['軸：X・Y・Z。おすすめ：X。',
         'X / Y / Z：中心の座標（メッシュのローカル座標）です。おすすめ：0。',
         '許容値：反対側の対応する頂点を探す時に許す距離です。既定 0.001。モデルの左右が少しずれている時だけ上げます。']),
    verify=(
        ['Press a mirror button in Mirror Tools and compare both sides.'],
        ['「ミラーと反転ツール」のボタンを押して、左右を見比べます。']),
    undo=(
        ['Changing these values does not change the mesh.'],
        ['値を変えただけでは、メッシュは変わりません。']),
)

HELP_DATA['smart_shapekey_export'] = _e(
    ('Export', '書き出し'),
    purpose=(
        ['Turns stored maps into ordinary Blender Shape Keys on the same mesh, or into separate mesh objects. '
         'It can also read existing Shape Keys back as maps.'],
        ['保存したマップを、同じメッシュのふつうのシェイプキー、または別々のメッシュのオブジェクトにします。'
         '逆に、今あるシェイプキーをマップとして読み込む事もできます。']),
    prepare=(
        ['Store your last edit first by clicking another map in the Maps list (Export uses stored maps only).',
         'To export only some maps, switch Maps to Edit and tick them. If nothing is ticked, all maps are exported.'],
        ['先に「マップ」の一覧で別のマップを押し、最後の編集を保存します（書き出しは保存済みのマップだけを使います）。',
         '一部だけ書き出す時は、「マップ」を「編集」にしてチェックを付けます。何もチェックしていなければ、全部のマップを書き出します。']),
    steps=(
        ['Press Export.',
         'In the dialog choose the Output: Shape Keys or Object.',
         'For Shape Keys, decide whether to replace Shape Keys that have the same name. For Object, set Prefix, Offset and Line.',
         'Press OK.',
         'To read Shape Keys as maps instead, press Import and confirm.'],
        ['「書き出し」を押します。',
         'ダイアログで「出力先」を「シェイプキー」か「オブジェクト」から選びます。',
         'シェイプキーの時は「同名のシェイプキーを置換」を決めます。オブジェクトの時は「接頭辞」「間隔」「1行の個数」を決めます。',
         'OK を押します。',
         '逆にシェイプキーをマップとして読む時は、「読み込み」を押して確定します。']),
    settings=(
        ['Output: Shape Keys (keys on this mesh, for rigging and animation) or Object (one new mesh object per map, for checking or transfer). Recommended: Shape Keys.',
         'Replace matching Shape Keys (Shape Keys only): when on, a Shape Key with the same name is overwritten; when off, existing keys are kept and protected. Recommended: off.',
         'Prefix (Object only): text put in front of each new object name.',
         'Offset (Object only): distance between the new objects. Default 10.',
         'Line (Object only): how many objects are placed in one row before starting the next row. Default 5.',
         'Import: adds every Shape Key except Basis as a map, exactly relative to Basis. Your Shape Keys and other data are kept. '
         'Maps this add-on made before are replaced. The values of the Shape Keys go to 0 and Axis handles go back to center, so the mesh returns to the Basis shape.'],
        ['出力先：「シェイプキー」（このメッシュのシェイプキーにする。リグやアニメーション用）か「オブジェクト」（マップごとに新しいメッシュのオブジェクトにする。確認や受け渡し用）。おすすめ：シェイプキー。',
         '同名のシェイプキーを置換（シェイプキーの時だけ）：オンにすると、同じ名前のシェイプキーを上書きします。オフなら既にあるキーを守って残します。おすすめ：オフ。',
         '接頭辞（オブジェクトの時だけ）：新しいオブジェクト名の頭に付ける文字です。',
         '間隔（オブジェクトの時だけ）：新しいオブジェクト同士の距離です。既定 10。',
         '1行の個数（オブジェクトの時だけ）：1 列に並べる数です。超えると次の列へ並べます。既定 5。',
         '読み込み：Basis 以外のシェイプキーを全部、Basis からの正確な差としてマップに足します。シェイプキーや他のデータはそのまま残ります。このアドオンが前に作ったマップは置き換えます。シェイプキーの値は 0 に、シェイプ軸のハンドルは中央に戻り、メッシュの形は Basis に戻ります。']),
    verify=(
        ['Shape Keys: open the Object Data properties > Shape Keys and move each new key from 0 to 1.',
         'Object: check the new objects next to the active object.',
         'Import: check that new rows appear in the Maps list.'],
        ['シェイプキー：プロパティの「オブジェクトデータ」→「シェイプキー」で、新しいキーを 0 から 1 へ動かして形を見ます。',
         'オブジェクト：アクティブなオブジェクトの横に並んだ新しいオブジェクトを確かめます。',
         '読み込み：「マップ」の一覧に新しい行が増えた事を確かめます。']),
    undo=(
        ['Ctrl+Z removes what Export or Import created.',
         'The mesh must keep the vertex count of the stored Basis; otherwise export is refused before anything changes.',
         'If no map is selected for a Selected export, a warning is shown and nothing is written.',
         'Import cannot return every shape to Basis: a Shape Key value or Axis handle with a driver or keyframes comes back at the next update; a key whose slider minimum is above 0 stops at that minimum; Absolute Shape Keys follow Evaluation Time, not their values.',
         'Exporting to Shape Keys selects the Basis row and leaves SKM_Map_Preview out of the result.',
         'Pressing a map afterwards adds the extra Shape Key SKM_Map_Preview to show it (see the help of Maps).'],
        ['「書き出し」「読み込み」で作った物は Ctrl+Z で消せます。',
         'メッシュの頂点の数が保存した Basis と違うと、何も変えずに書き出しを断ります。',
         '選んだマップが無い時は警告が出て、何も書き出しません。',
         '読み込みで Basis に戻せない形：ドライバーやキーフレームが付いたシェイプキーの値・シェイプ軸のハンドルは次の更新で戻ります。スライダーの最小が 0 より大きいキーは、その最小までしか下がりません。絶対シェイプキーは値でなく評価時間で形が決まります。',
         'シェイプキーへの書き出しの後は Basis の行に戻ります。SKM_Map_Preview は結果に入りません。',
         'その後でマップを押すと、形を見せるためのシェイプキー SKM_Map_Preview が 1 本増えます（「マップ」のヘルプを見てください）。']),
)

HELP_DATA['smart_shapekey_save_load'] = _e(
    ('Save/Load', '保存と読み込み'),
    purpose=(
        ['Saves maps to a separate file and reads them back, for use in another .blend or on another mesh.',
         'You do not need this just to keep maps: they are stored inside the mesh, so saving the .blend keeps them.'],
        ['マップを別のファイルへ保存し、読み戻します。別の .blend や別のメッシュへ持って行く時に使います。',
         'マップを残すだけなら要りません。マップはメッシュの中に入っているので、.blend を保存すれば残ります。']),
    prepare=(
        ['Select the mesh and run Set Base. At least one map is needed for saving.',
         'To load, the target mesh always needs a UV map. A mesh with the same vertex layout takes the shapes as they are, whatever its UVs look like.',
         'A mesh with a different vertex layout must also have the same UV layout as the saved mesh: positions are matched through the UVs. If the layout differs, or the saved mesh has overlapping UVs, Load stops with a message and changes nothing.',
         'A part of the saved mesh (with some faces deleted) also loads, as long as it still stands in the saved shape. Modifiers do not count: the maps go onto the mesh before its modifiers.',
         'For a different vertex layout, Load compares the median displacement of the mesh and each UV island, and also checks local displacement along the surface. A mismatch stops before changing the mesh. A subdivided mesh can still load when every corner matches an actual Simple or Catmull-Clark subdivision of the saved Basis in both position and UV; its maps use that same subdivision. Differences below the tolerances can still load; inspect the result. Custom subdivision settings and arbitrary remeshing are not guaranteed to match. Ctrl+Z undoes a completed load.'],
        ['メッシュを選び、「ベースを設定」を済ませます。保存にはマップが 1 つ以上要ります。',
         '読み込む先のメッシュには、いつも UV マップが要ります。頂点の並びが同じなら、UV の開き方が違っても形はそのまま入ります。',
         '頂点の並びが違うメッシュは、UV の開き方も保存元と同じである必要があります（UV を手がかりに位置を合わせます）。開き方が違う時と、保存元の UV が重なっている時は、読み込みは知らせを出して止まり、メッシュは変わりません。',
         '保存元の一部の面を消したメッシュも、形が保存元のままなら入ります。モディファイアは関係しません（モディファイアをかける前のメッシュに入ります）。',
         '頂点の並びが違う時は、メッシュ全体と UV の島ごとの位置のずれの中央値に加え、面に沿った局所的なずれも調べます。不一致ならメッシュを変える前に止めます。ただし、保存した Basis を Simple または Catmull-Clark で細分化した結果と、全ての面の角の位置・UV が一致すれば、その細分化をマップにも使って読み込めます。許容差より小さい違いは入ることがあるので、結果は目でも確かめてください。特殊な細分化設定や任意のリメッシュでの一致は保証しません。完了した読み込みは Ctrl+Z で戻せます。']),
    steps=(
        ['Save: press Save (All) and choose the file name and folder.',
         'To save only some maps: turn on the mode button under the Maps list so it reads Edit, tick the maps in the list, then press Save (Selected).',
         'If the name already exists, a confirmation appears before the file is replaced.',
         'Load: press Load, choose the file, tick the maps to bring in in the window that opens, and press OK.'],
        ['保存：「全て保存」を押し、ファイルの名前と場所を決めます。',
         '一部だけ保存する時：「マップ」の一覧の下のモードのボタンを押して「編集」にし、一覧で残したいマップにチェックを入れてから「選択を保存」を押します。',
         '同じ名前のファイルがある時は、置き換える前に確認が出ます。',
         '読み込み：「読み込み」を押してファイルを選び、開いた窓で読み込むマップにチェックを入れて「OK」を押します。']),
    settings=(
        ['Save (All): writes every map except Basis, plus the Basis shape.',
         'Save (Selected): writes only the ticked maps. It is greyed out until a map is ticked.',
         'Load: replaces the maps and the Basis of this mesh with those from the file, and the mesh takes the shape of the loaded Basis (Undo brings it back). Maps not ticked in the window are not brought in.',
         'Select All / Deselect All (in the Load window): ticks or clears every map at once.'],
        ['全て保存：Basis の形と、Basis 以外の全部のマップを書きます。',
         '選択を保存：チェックを入れたマップだけを書きます。チェックが 1 つも無い間は灰色で押せません。',
         '読み込み：このメッシュのマップと Basis を、ファイルの物に置き換えます。メッシュの形も読み込んだ Basis になります（取り消しで戻せます）。窓でチェックを外したマップは入りません。',
         '全選択 / 全選択解除（読み込みの窓）：全部のチェックをまとめて入れる・外します。']),
    verify=(
        ['After Load, the Maps list shows Basis and the maps you ticked. Press each row to see its shape.'],
        ['読み込みの後、「マップ」の一覧に Basis とチェックしたマップが並びます。行を押して形を確かめます。']),
    undo=(
        ['Ctrl+Z undoes Load. Saving only writes the file; delete the file yourself if you no longer need it.',
         'Load removes the maps that were on the mesh. Save them first if you want to keep them.'],
        ['読み込みは Ctrl+Z で戻せます。保存はファイルを書くだけなので、要らなくなったファイルは自分で消します。',
         '読み込むと、メッシュにあったマップは無くなります。残したい時は、先に保存します。']),
)

# ---------------------------------------------------------------------------
# Modifiers / Drivers
# ---------------------------------------------------------------------------
HELP_DATA['modifiers_group'] = _e(
    ('Modifiers', 'モディファイア'),
    purpose=(
        ['Group for modifier tools. It contains Apply Keeping Shape Keys, which applies modifiers without losing Shape Keys.'],
        ['モディファイアの道具をまとめた欄です。中に「シェイプキー保持で適用」（シェイプキーを失わずにモディファイアを適用する）があります。']),
    prepare=(
        ['Nothing runs in the background here. Open the section only when you need it.'],
        ['この欄は背景で何も動かしません。必要な時だけ開きます。']),
    steps=(
        ['Open the section.',
         'Open the child section Apply Keeping Shape Keys and press its "?" for the detailed steps.'],
        ['欄を開きます。',
         '中の「シェイプキー保持で適用」を開き、その「？」で詳しい手順を読みます。']),
    settings=(
        ['Apply Keeping Shape Keys: child section (see its help).'],
        ['シェイプキー保持で適用：中の欄です（その欄のヘルプを見てください）。']),
    verify=(
        ['See the child section help.'],
        ['中の欄のヘルプを見てください。']),
    undo=(
        ['Opening the section changes nothing.'],
        ['欄を開いても何も変わりません。']),
)

HELP_DATA['apply_modifiers'] = _e(
    ('Apply Keeping Shape Keys', 'シェイプキー保持で適用'),
    purpose=(
        ['Applies the modifiers you choose to a mesh that has Shape Keys, and keeps every Shape Key. Blender\'s own Apply refuses this case.',
         'Basis and every Shape Key are rebuilt and checked on temporary copies first; the original is changed only when all of them succeed.'],
        ['シェイプキーを持つメッシュに、選んだモディファイアを適用し、シェイプキーを全部残します（Blender 標準の「適用」はこの場合を断ります）。',
         '先に一時的な複製の上で Basis と全シェイプキーを作り直して確かめ、全部うまくいった時だけ元のメッシュを変えます。']),
    prepare=(
        ['Select a mesh object that has Shape Keys and modifiers, and make it active.',
         'Switch to Object Mode.',
         'Otherwise the section shows only a status line such as "The active mesh has no Shape Keys." or "Switch to Object Mode."',
         'Save a copy of the .blend first.'],
        ['シェイプキーとモディファイアを持つメッシュを選び、アクティブにします。',
         'オブジェクトモードにします。',
         '条件に合わない時は「シェイプキーがありません。」「オブジェクトモードに切り替えてください。」などの状態の 1 行だけが出ます。',
         '先に .blend の控えを保存します。']),
    steps=(
        ['Press Choose Modifiers.',
         'In the dialog tick only the modifiers you want to apply.',
         'Press OK. A message reports when the modifiers were applied with Shape Keys kept.'],
        ['「モディファイアを選択」を押します。',
         'ダイアログで、適用したいモディファイアだけにチェックを付けます。',
         'OK を押します。シェイプキーを保ったまま適用できた事が表示されます。']),
    settings=(
        ['Choose Modifiers: opens the dialog with one check box per modifier. Ticked modifiers are applied, unticked ones are kept as they are.',
         'Works with modifiers that build the same mesh for every Shape Key (for example Shrinkwrap, Smooth, Displace, Subdivision Surface, Mirror, Solidify, Triangulate).'],
        ['モディファイアを選択：モディファイアごとのチェックがあるダイアログを開きます。チェックした物を適用し、外した物はそのまま残します。',
         '使えるのは、どのシェイプキーでも同じメッシュを作るモディファイアです（シュリンクラップ・スムーズ・ディスプレイス・サブディビジョンサーフェス・ミラー・ソリッド化・三角形化など）。']),
    verify=(
        ['Check that the chosen modifiers disappeared from the modifier stack.',
         'Move each Shape Key from 0 to 1 and check the shape.'],
        ['選んだモディファイアがモディファイアの一覧から消えた事を確かめます。',
         '各シェイプキーを 0 から 1 へ動かして、形を確かめます。']),
    undo=(
        ['Ctrl+Z restores the mesh, modifiers and Shape Keys.',
         'If a chosen modifier builds a different mesh for any Shape Key (Decimate, Boolean, Bevel, Remesh and so on), '
         'the check fails and the operation is cancelled without changing the original.',
         'A mesh with maps is refused. Export them if needed and press Delete All in Maps first.',
         'Heavy meshes with many Shape Keys take time, because every key is rebuilt.'],
        ['Ctrl+Z で、メッシュ・モディファイア・シェイプキーが元に戻ります。',
         '選んだモディファイアが、シェイプキーごとに違うメッシュを作る時（デシメート・ブーリアン・ベベル・リメッシュなど）は確認で失敗し、元を変えずに中止します。',
         'マップのあるメッシュは断ります。必要なら書き出してから、「マップ」の「すべて削除」を押します。',
         '重いメッシュでシェイプキーが多いと、キーごとに作り直すので時間がかかります。']),
)

HELP_DATA['drivers_group'] = _e(
    ('Drivers', 'ドライバー'),
    purpose=(
        ['Group for driver tools. It contains Driver Helper, which writes a driver expression for you.'],
        ['ドライバーの道具をまとめた欄です。中に、ドライバーの式を作る「ドライバーヘルパー」があります。']),
    prepare=(
        ['Nothing runs in the background here.'],
        ['この欄は背景で何も動かしません。']),
    steps=(
        ['Open the section, open Driver Helper and press its "?" for the steps.'],
        ['欄を開き、「ドライバーヘルパー」を開いて、その「？」で手順を読みます。']),
    settings=(
        ['Driver Helper: child section (see its help).'],
        ['ドライバーヘルパー：中の欄です（その欄のヘルプを見てください）。']),
    verify=(
        ['See the child section help.'],
        ['中の欄のヘルプを見てください。']),
    undo=(
        ['Opening the section changes nothing.'],
        ['欄を開いても何も変わりません。']),
)

HELP_DATA['driver_helper'] = _e(
    ('Driver Helper', 'ドライバーヘルパー'),
    purpose=(
        ['Writes a driver expression that turns a bone or object channel (location, rotation or scale) into a Shape Key value from 0 to 1.',
         'The expression is shown in a popup so you can copy it into a driver.'],
        ['ボーンやオブジェクトの位置・回転・スケールの値を、シェイプキーの 0〜1 の値に変えるドライバーの式を作ります。',
         'できた式はポップアップに出るので、コピーしてドライバーに貼ります。']),
    prepare=(
        ['Select a mesh that has Shape Keys and make it active. Otherwise the section shows "Select a mesh object with Shape Keys."',
         'Make a driver on the Shape Key value first (right-click the value > Add Driver) with one variable named var that reads the channel.'],
        ['シェイプキーを持つメッシュを選び、アクティブにします。条件に合わない時は「シェイプキーのあるメッシュを選択」と出ます。',
         '先に、シェイプキーの値にドライバーを付けます（値を右クリック→「ドライバーを追加」）。変数の名前を var にして、読みたいチャンネルを指定します。']),
    steps=(
        ['Choose LOC, ROT or SCALE.',
         'Set Min (value where the Shape Key starts) and Max (value where it reaches 1).',
         'Set Power if you want an eased response.',
         'Press Generate Formula and copy the text in the popup.',
         'Paste it into the Expression field of the driver.'],
        ['LOC（位置）・ROT（回転）・SCALE（スケール）から選びます。',
         '「最小」（シェイプキーが動き始める値）と「最大」（1 になる値）を決めます。',
         '動き方をなだらかにしたい時は「パワー」を決めます。',
         '「式を生成」を押し、ポップアップの文字をコピーします。',
         'ドライバーの「式」欄に貼り付けます。']),
    settings=(
        ['LOC / ROT / SCALE: which kind of channel the variable var reads. With ROT, type Min and Max in degrees; the expression converts them to radians.',
         'Min: input value where the output is still 0. Max: input value where the output reaches 1. Min and Max cannot be equal (an error is shown).',
         'Power: exponent of the curve. 1.0 is straight; above 1.0 starts slowly (ease in); below 1.0 starts fast (ease out). Recommended: 1.0.',
         'Generate Formula: builds the expression and opens the popup with the text.'],
        ['LOC / ROT / SCALE：変数 var が読むチャンネルの種類です。ROT の時は「最小」「最大」を度で入れます。式の中でラジアンに直します。',
         '最小：出力がまだ 0 の入力値です。最大：出力が 1 になる入力値です。同じ値にはできません（エラーが出ます）。',
         'パワー：カーブの指数です。1.0 は直線、1.0 より大きいとゆっくり始まり（イーズイン）、小さいと速く始まります（イーズアウト）。おすすめ：1.0。',
         '式を生成：式を作り、文字の入ったポップアップを開きます。']),
    verify=(
        ['Move the bone or object and watch the Shape Key value go from 0 to 1 between Min and Max.',
         'The output is clamped to 0..1, so values outside Min and Max stay at 0 or 1.'],
        ['ボーンやオブジェクトを動かし、「最小」から「最大」の間でシェイプキーの値が 0 から 1 になる事を確かめます。',
         '出力は 0〜1 に制限されます。「最小」「最大」の外では 0 か 1 のままです。']),
    undo=(
        ['Generating a formula changes nothing in the scene. Delete or edit the driver expression to undo.',
         'The expression expects the variable name var. If your variable has another name, rename it.'],
        ['式を作ってもシーンは変わりません。戻す時は、ドライバーの式を消すか書き直します。',
         '式は変数名 var を前提にしています。別の名前の時は var に変えてください。']),
)

# ---------------------------------------------------------------------------
# Control / Tracking
# ---------------------------------------------------------------------------
HELP_DATA['control_tracking_group'] = _e(
    ('Control / Tracking', '制御・トラッキング'),
    purpose=(
        ['Group for joystick-style Shape Key control and live input: ShapeKey Axis Control, External Tracker (UDP) and Face Tracker (Built-In).',
         'Facial capture baking (Facial CSV Capture) is inside Face Tracker (Built-In).'],
        ['シェイプキーのジョイスティック式の操作と、外からの入力をまとめた欄です。「シェイプキー軸コントロール」「外部トラッカー UDP」「フェイストラッカー（内蔵）」があります。',
         '顔の収録の焼き込み（「フェイシャルCSV収録」）は、「フェイストラッカー（内蔵）」の中にあります。']),
    prepare=(
        ['The child sections draw only; live features start only from Always-on Features.'],
        ['中の欄は表示だけです。動き続ける機能は「常時機能切り替え」からだけ開始します。']),
    steps=(
        ['Build groups and mappings in ShapeKey Axis Control.',
         'Feed values from another application with External Tracker (UDP), or from a webcam with Face Tracker (Built-In).',
         'Start and stop live input in Always-on Features.'],
        ['「シェイプキー軸コントロール」でグループとマッピングを作ります。',
         '他のアプリから値を送る時は「外部トラッカー UDP」、ウェブカメラから送る時は「フェイストラッカー（内蔵）」を使います。',
         '入力の開始と停止は「常時機能切り替え」で行います。']),
    settings=(
        ['ShapeKey Axis Control, External Tracker (UDP), Face Tracker (Built-In): child sections (see their help).'],
        ['シェイプキー軸コントロール・外部トラッカー UDP・フェイストラッカー（内蔵）：中の欄です（それぞれのヘルプを見てください）。']),
    verify=(
        ['See the child section help.'],
        ['中の欄のヘルプを見てください。']),
    undo=(
        ['Opening the section starts nothing.'],
        ['欄を開いても何も開始しません。']),
)

HELP_DATA['shape_axis_control'] = _e(
    ('ShapeKey Axis Control', 'シェイプキー軸コントロール'),
    purpose=(
        ['Makes joystick-style X/Y controllers. Each group has one X/Y handle; mapping rows decide which Shape Key reacts near which X/Y point.',
         'The handle can be moved from the panel, the Axis UI HUD, keyframes, drivers or trackers.'],
        ['ジョイスティック式の X/Y のコントローラーを作ります。グループごとに X/Y のハンドルが 1 つあり、マッピングの行で「どの X/Y の近くでどのシェイプキーが効くか」を決めます。',
         'ハンドルは、パネル・シェイプ軸 HUD・キーフレーム・ドライバー・トラッカーから動かせます。']),
    prepare=(
        ['Select a mesh with Shape Keys. Otherwise the section shows "Select a mesh object."',
         'Make the Shape Keys you want to blend first.'],
        ['シェイプキーを持つメッシュを選びます。条件に合わない時は「メッシュオブジェクトを選択してください。」と出ます。',
         '混ぜたいシェイプキーを先に作っておきます。']),
    steps=(
        ['Open Groups and create the first group.',
         'Open Mappings, add rows, choose a Shape Key for each row and set its target X/Y.',
         'Move X and Y in Handle / Values (or turn on Axis UI in Always-on Features and drag in the viewport).',
         'Key the handle or store positions in Global Animation Presets.'],
        ['「グループ」を開き、最初のグループを作ります。',
         '「マッピング」を開いて行を足し、行ごとにシェイプキーと目標の X/Y を決めます。',
         '「ハンドル / 値」で X と Y を動かします（「常時機能切り替え」でシェイプ軸 HUD を有効にして、ビューポートでドラッグしてもかまいません）。',
         'ハンドルにキーを打つか、「アニメーションプリセット」に位置を保存します。']),
    settings=(
        ['Reset: returns the active group\'s handle to the center. Reset All: returns every group\'s handle to the center.',
         'Reset HUD: restores the position and size of the Axis UI HUD.',
         'Point Drag: when on, mapping points can be dragged directly inside the Axis UI HUD. Recommended: off unless you are arranging points.',
         'Axis UI and Frame Sync are switched in Always-on Features.'],
        ['リセット：選んでいるグループのハンドルを中心へ戻します。すべてリセット：全グループのハンドルを中心へ戻します。',
         'HUD をリセット：シェイプ軸 HUD の位置と大きさを元に戻します。',
         'ポイントドラッグ：オンにすると、シェイプ軸 HUD の中でマッピングの点を直接ドラッグできます。おすすめ：点を並べる時以外はオフ。',
         'シェイプ軸 HUD とフレーム同期は「常時機能切り替え」で入切します。']),
    verify=(
        ['Move X/Y and watch the Shape Key values in the Shape Keys list.'],
        ['X/Y を動かし、シェイプキーの一覧で値が変わる事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes value changes. Pressing Esc or right-click while dragging in the HUD restores the values and removes keys added by that drag.'],
        ['値の変更は Ctrl+Z で戻せます。HUD でドラッグ中に Esc か右クリックを押すと、値が戻り、そのドラッグで足したキーも消えます。']),
)

HELP_DATA['shape_axis_groups'] = _e(
    ('Groups', 'グループ'),
    purpose=(
        ['Manages the Shape Axis groups stored on the active object. One group is one independent X/Y controller with its own values, mappings and tracker settings.'],
        ['アクティブなオブジェクトに保存したシェイプ軸のグループを管理します。1 つのグループは、値・マッピング・トラッカーの設定を持つ、独立した X/Y のコントローラーです。']),
    prepare=(
        ['Select the mesh that should receive the control.'],
        ['操作を受けるメッシュを選びます。']),
    steps=(
        ['If there is no group yet, press Create the First Group to Set Up.',
         'Otherwise use the buttons to the right of the list to add, remove or reorder groups.',
         'Click a group to make it active; Handle / Values and Mappings then show that group.'],
        ['まだグループが無い時は「最初のグループを作成して設定開始」を押します。',
         'グループがある時は、一覧の右のボタンで追加・削除・並べ替えをします。',
         'グループを押すと選ばれ、「ハンドル / 値」と「マッピング」にそのグループが出ます。']),
    settings=(
        ['Group list: groups on the active object.',
         '+ / -: add a group / remove the selected group.',
         'Up / Down arrows: reorder groups.'],
        ['グループの一覧：アクティブなオブジェクトのグループです。',
         '＋ / －：グループを足す / 選んだグループを消す。',
         '上下の矢印：グループの順番を変えます。']),
    verify=(
        ['The new group appears in the list and the Handle / Values section appears below.'],
        ['新しいグループが一覧に出て、その下に「ハンドル / 値」の欄が出る事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes adding or removing a group. Removing a group also removes its mappings.'],
        ['グループの追加・削除は Ctrl+Z で戻せます。グループを消すと、そのマッピングも消えます。']),
)

HELP_DATA['shape_axis_handle_values'] = _e(
    ('Handle / Values', 'ハンドル / 値'),
    purpose=(
        ['Moves the active group\'s handle by number and provides animation helpers: key, bake, and JSON import/export.'],
        ['選んでいるグループのハンドルを数値で動かし、アニメーションの補助（キー・ベイク・JSON の読み書き）を行います。']),
    prepare=(
        ['Select a group in Groups.'],
        ['「グループ」でグループを選びます。']),
    steps=(
        ['Rename the group in Group Name if you like.',
         'Type X (Drivable) and Y (Drivable), or use Edit Values for an exact popup.',
         'Press Key Handle [I] to key the current X/Y on the current frame.',
         'When animation is finished, press Bake Animation and set Start Frame, End Frame and Step to turn it into ordinary Shape Key keys.'],
        ['必要なら「グループ名」で名前を変えます。',
         '「X（ドライブ可）」「Y（ドライブ可）」に数値を入れるか、「値を編集」で正確な値を入れます。',
         '「ハンドルにキー [I]」で、今のフレームに今の X/Y のキーを打ちます。',
         'アニメーションが決まったら「アニメーションをベイク」を押し、開始フレーム・終了フレーム・ステップを決めて、ふつうのシェイプキーのキーに変えます。']),
    settings=(
        ['Group Name: name of the group.',
         'Reset Handle: returns X and Y to 0.',
         'Key Handle [I]: inserts keys for X and Y.',
         'Edit Values: opens a popup for exact X/Y input.',
         'Bake Animation: writes the driven Shape Key results as keyframes from Start Frame to End Frame every Step frames. Recommended Step: 1.',
         'X (Drivable) / Y (Drivable): current handle position. They can be keyed or driven.',
         'Import JSON / Export JSON: read a group setup from a JSON file as a new group / write the selected group\'s mappings to a JSON file.'],
        ['グループ名：グループの名前です。',
         'ハンドルをリセット：X と Y を 0 に戻します。',
         'ハンドルにキー [I]：X と Y にキーを打ちます。',
         '値を編集：X/Y を正確に入れるポップアップを開きます。',
         'アニメーションをベイク：動かした結果のシェイプキーの値を、開始フレームから終了フレームまで、ステップごとにキーとして書きます。おすすめのステップ：1。',
         'X（ドライブ可）/ Y（ドライブ可）：今のハンドルの位置です。キーやドライバーを付けられます。',
         'JSON を読み込み / JSON を書き出し：JSON から新しいグループとして読み込む / 選んだグループのマッピングを JSON に書き出します。']),
    verify=(
        ['After Key Handle, the X/Y fields turn yellow on keyed frames. After Bake, the Shape Keys have keys in the Dope Sheet.',
         'A message reports how many keys were baked or how many mappings were exported or imported.'],
        ['キーを打つと、キーのあるフレームで X/Y の欄が黄色になります。ベイクの後は、ドープシートでシェイプキーにキーがある事を確かめます。',
         'ベイクしたキーの数、読み書きしたマッピングの数が表示されます。']),
    undo=(
        ['Ctrl+Z undoes keys and bakes. A failed bake is rolled back.',
         'Baked keys do not follow later mapping changes; bake again after changes.'],
        ['キーとベイクは Ctrl+Z で戻せます。途中で失敗したベイクは自動で元に戻ります。',
         'ベイクしたキーは、後でマッピングを変えても追従しません。変えた後はベイクし直します。']),
)

HELP_DATA['shape_axis_mappings'] = _e(
    ('Mappings', 'マッピング'),
    purpose=(
        ['The rows of the active group. Each row links one Shape Key to a target X/Y point with a radius and a blend mode.'],
        ['選んでいるグループの行です。各行で、1 つのシェイプキーを、目標の X/Y の点・半径・ブレンドモードに結び付けます。']),
    prepare=(
        ['Select a group first. If there is no group, the section shows the status line "No group yet."; create one in Groups.'],
        ['先にグループを選びます。グループが無い時は状態の 1 行「グループがまだありません。」が出るので、「グループ」で作ります。']),
    steps=(
        ['Press + to add a row.',
         'Click the row and set it in Mapping Settings (Shape Key, X, Y, Radius, Blend).',
         'For left/right pairs named .L and .R, press the mirror button to make the opposite rows.'],
        ['＋ で行を足します。',
         '行を押し、「マッピング設定」でシェイプキー・X・Y・半径・ブレンドを決めます。',
         '.L と .R の名前の左右の組がある時は、ミラーのボタンで反対側の行を作ります。']),
    settings=(
        ['Mapping list: rows driven by this group.',
         '+ / -: add / remove a row. Up / Down arrows: reorder rows.',
         'Mirror button: creates symmetric rows for matching .L / .R Shape Key names.'],
        ['マッピングの一覧：このグループで動かす行です。',
         '＋ / －：行を足す / 消す。上下の矢印：行の順番を変えます。',
         'ミラーのボタン：.L / .R の対になったシェイプキー名から、左右対称の行を作ります。']),
    verify=(
        ['Move the handle toward a row\'s target X/Y and watch that Shape Key rise.'],
        ['ハンドルを行の目標の X/Y へ近づけ、そのシェイプキーの値が上がる事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes row changes. A message reports how many Shape Keys were mirrored.'],
        ['行の変更は Ctrl+Z で戻せます。ミラーで足した数が表示されます。']),
)

HELP_DATA['shape_axis_mapping_settings'] = _e(
    ('Mapping Settings', 'マッピング設定'),
    purpose=(
        ['Edits the selected mapping row: which Shape Key, where on the controller, how wide, and how it fades.'],
        ['選んだマッピングの行を編集します。どのシェイプキーを、コントローラーのどこで、どの広さで、どう弱めて効かせるかを決めます。']),
    prepare=(
        ['Select a row in Mappings.'],
        ['「マッピング」で行を選びます。']),
    steps=(
        ['Choose the Shape Key.',
         'Set X and Y to the controller position where the Shape Key should be fully on.',
         'Adjust Radius and Blend until the response looks natural.'],
        ['シェイプキーを選びます。',
         'X と Y を、そのシェイプキーを最大にしたいコントローラーの位置にします。',
         '反応が自然になるまで「半径」と「ブレンド」を調整します。']),
    settings=(
        ['Shape Key: the key driven by this row.',
         'X / Y: target position on the controller. Defaults 1 and 0.',
         'Radius: how far from the target the key still reacts. Larger is softer and wider. Default 1.',
         'Blend: Auto (chooses automatically, recommended), Box Falloff (square area), Radial Falloff (circle), X-Axis (mainly horizontal distance), Y-Axis (mainly vertical distance).'],
        ['シェイプキー：この行で動かすキーです。',
         'X / Y：コントローラー上の目標の位置です。既定は 1 と 0。',
         '半径：目標からどこまで離れても効くかです。大きいほど広く柔らかく効きます。既定 1。',
         'ブレンド：自動（自動で選ぶ。おすすめ）・ボックス減衰（四角の範囲）・放射状減衰（円）・X 軸（主に横の距離）・Y 軸（主に縦の距離）。']),
    verify=(
        ['Move the handle around the target and watch the value change smoothly.'],
        ['ハンドルを目標の周りで動かし、値がなめらかに変わる事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes setting changes.'],
        ['設定の変更は Ctrl+Z で戻せます。']),
)

HELP_DATA['shape_axis_presets'] = _e(
    ('Global Animation Presets', 'アニメーションプリセット'),
    purpose=(
        ['Stores and recalls the handle positions of all Shape Axis groups (across objects) as named presets, for pose libraries and quick blocking.'],
        ['全オブジェクトのシェイプ軸グループのハンドルの位置を、名前を付けたプリセットとして保存し、呼び出します。ポーズの一覧や、素早いアニメーションの下書きに使います。']),
    prepare=(
        ['Set up groups and put the handles where you want them.'],
        ['グループを作り、ハンドルを残したい位置にしておきます。']),
    steps=(
        ['Press + to add a preset and type its Preset Name.',
         'Press Set to store the current positions.',
         'Later press Call to restore them, or Key to restore them and insert keys at once.'],
        ['＋ でプリセットを足し、「プリセット名」を入れます。',
         '「保存」で今の位置を保存します。',
         '後で「呼び出し」を押すと戻り、「キー」を押すと戻してすぐキーを打ちます。']),
    settings=(
        ['Preset list, + / -, Up / Down arrows: manage presets.',
         'Preset Name: name of the selected preset.',
         'Set: stores the current handle positions into the preset.',
         'Call: applies the stored positions.',
         'Key: applies the stored positions and inserts keys for them.'],
        ['プリセットの一覧・＋ / －・上下の矢印：プリセットを管理します。',
         'プリセット名：選んだプリセットの名前です。',
         '保存：今のハンドルの位置をプリセットに入れます。',
         '呼び出し：保存した位置を当てます。',
         'キー：保存した位置を当て、その値にキーを打ちます。']),
    verify=(
        ['After Call, the handles jump to the stored positions.'],
        ['「呼び出し」の後、ハンドルが保存した位置へ移る事を確かめます。']),
    undo=(
        ['Ctrl+Z undoes Call and Key. Presets refer to objects and groups by name; renamed ones are not found.'],
        ['「呼び出し」「キー」は Ctrl+Z で戻せます。プリセットはオブジェクトとグループを名前で覚えるので、名前を変えると見つかりません。']),
)

HELP_DATA['external_tracker'] = _e(
    ('External Tracker (UDP)', '外部トラッカー UDP'),
    purpose=(
        ['Receives X/Y controller values from another application over UDP and applies them to Shape Axis groups.'],
        ['他のアプリから UDP で X/Y の値を受け取り、シェイプ軸のグループに当てます。']),
    prepare=(
        ['Set up a Shape Axis group, and start the sending application.'],
        ['シェイプ軸のグループを作り、送信するアプリを起動しておきます。']),
    steps=(
        ['Set UDP Port to the port the sender uses.',
         'Enable External Tracker (UDP) in Always-on Features.',
         'When finished, set it back to Disabled to close the socket.'],
        ['「UDPポート」を、送信アプリと同じ番号にします。',
         '「常時機能切り替え」で「外部トラッカー UDP」を有効にします。',
         '終わったら無効に戻し、ソケットを閉じます。']),
    settings=(
        ['UDP Port: local port Blender listens on (1024 to 65535).',
         'Status line: "Stopped." or "Listening (bounded/coalescing)." Incoming values are combined per target so a fast sender cannot flood Blender.'],
        ['UDPポート：Blender が受け取りを待つポートの番号です（1024〜65535）。',
         '状態の行：「停止中です。」か「有界・集約方式で待受中です。」。速く送られても溜まらないよう、対象ごとに最新の値へまとめます。']),
    verify=(
        ['The status line says it is listening and the handle moves when the sender sends.'],
        ['状態の行が待受中になり、送信するとハンドルが動く事を確かめます。']),
    undo=(
        ['Disable the toggle to stop. If the port is used by another program, choose another port.'],
        ['止める時は切り替えを無効にします。ポートが他のプログラムに使われている時は、別の番号にします。']),
)

HELP_DATA['face_tracker'] = _e(
    ('Face Tracker (Built-In)', 'フェイストラッカー（内蔵）'),
    purpose=(
        ['Reads face landmarks from a webcam and drives Shape Axis groups live.',
         'The same section also contains Facial CSV Capture, which bakes recorded ARKit captures (CSV or video) into Actions.'],
        ['ウェブカメラから顔の点（ランドマーク）を読み、シェイプ軸のグループをその場で動かします。',
         '同じ欄の中に、収録した ARKit の表情（CSV・動画）をアクションに焼き込む「フェイシャルCSV収録」もあります。']),
    prepare=(
        ['The first time, press Install Face Tracker Requirements (shown only when they are missing). It downloads MediaPipe and related packages '
         'into Smart_Shapekey_Suite/python_modules in the Blender config folder; it runs only when you press it.',
         'Connect a webcam, and make a Shape Axis group to receive the values.'],
        ['初めての時は「必要環境をインストール」を押します（足りない時だけ出ます）。MediaPipe などを Blender の設定フォルダーの '
         'Smart_Shapekey_Suite/python_modules へダウンロードします。押した時だけ動きます。',
         'ウェブカメラをつなぎ、値を受けるシェイプ軸のグループを作っておきます。']),
    steps=(
        ['Choose the Camera number.',
         'In Live Target Group add a row and pick the object and its group.',
         'In Tracker Setup apply the Mouth, Eyes or Blink preset as a start, then tune X-Axis Mapping and Y-Axis Mapping.',
         'Enable Face Tracker (Built-In) in Always-on Features to start; disable it to stop.'],
        ['「カメラ」の番号を選びます。',
         '「ライブ対象グループ」で行を足し、オブジェクトとそのグループを選びます。',
         '「トラッカー設定」で「口」「目」「まばたき」のプリセットを出発点として当て、「X 軸マッピング」「Y 軸マッピング」を調整します。',
         '「常時機能切り替え」で「フェイストラッカー（内蔵）」を有効にすると開始、無効にすると停止します。']),
    settings=(
        ['Install Face Tracker Requirements: installs the packages (network access only when pressed). The line under it shows progress or errors.',
         'Camera: webcam device number. Recommended: 0 for the first camera.',
         'Status line: "Stopped until you explicitly start it." or the live FPS.',
         'Reference Map: opens the landmark number image with your system viewer.',
         'Facial CSV Capture, Live Target Group, Tracker Setup: sub-sections (see their help).'],
        ['必要環境をインストール：必要なパッケージを入れます（押した時だけネットにつなぎます）。下の行に進み具合やエラーが出ます。',
         'カメラ：ウェブカメラの番号です。おすすめ：1 台目は 0。',
         '状態の行：「明示的に開始するまでは停止したままです。」か、動いている時の FPS です。',
         '参照マップ：ランドマークの番号の画像を、OS の画像ビューアで開きます。',
         'フェイシャルCSV収録・ライブ対象グループ・トラッカー設定：中の欄です（それぞれのヘルプを見てください）。']),
    verify=(
        ['After starting, the status line shows FPS and the target handles move with your face. Turn on Face Tracker Point HUD to see the landmarks.'],
        ['開始すると状態の行に FPS が出て、顔に合わせて対象のハンドルが動きます。点を見る時は「フェイストラッカーポイントHUD」を有効にします。']),
    undo=(
        ['Disable the toggle to stop the camera. Opening another .blend stops it as well.',
         'Lighting, glasses and camera angle change the readings; calibrate with Capture Min / Capture Max.'],
        ['カメラを止める時は切り替えを無効にします。別の .blend を開いた時も止まります。',
         '明るさ・眼鏡・カメラの角度で読み取りが変わります。「最小を取得」「最大を取得」で合わせ直します。']),
)

HELP_DATA['face_tracker_targets'] = _e(
    ('Live Target Group', 'ライブ対象グループ'),
    purpose=(
        ['Chooses which objects and Shape Axis groups receive the live Face Tracker output. Each row is one object plus one group.'],
        ['ライブのフェイストラッカーの出力を受けるオブジェクトとシェイプ軸のグループを決めます。1 行が「オブジェクト 1 つ＋グループ 1 つ」です。']),
    prepare=(
        ['Make the Shape Axis groups first.'],
        ['先にシェイプ軸のグループを作っておきます。']),
    steps=(
        ['Press + to add a row.',
         'Pick the object, then pick its group.',
         'Click the row you want to tune; Tracker Setup and calibration act on the selected row.'],
        ['＋ で行を足します。',
         'オブジェクトを選び、次にそのグループを選びます。',
         '調整したい行を押して選びます。「トラッカー設定」と取得は、選んだ行に効きます。']),
    settings=(
        ['Target list: rows used by the tracker. "<Select>" means the object has no groups yet.',
         '+ / -: add / remove a row.'],
        ['対象の一覧：トラッカーが使う行です。「<選択>」と出る時は、そのオブジェクトにまだグループがありません。',
         '＋ / －：行を足す / 消す。']),
    verify=(
        ['After selecting a valid row, the Tracker Setup section appears below.'],
        ['正しい行を選ぶと、下に「トラッカー設定」の欄が出ます。']),
    undo=(
        ['Removing a row does not change the object or its group.'],
        ['行を消しても、オブジェクトとグループは変わりません。']),
)

HELP_DATA['face_tracker_target_setup'] = _e(
    ('Tracker Setup', 'トラッカー設定'),
    purpose=(
        ['Sets how the selected target group reacts to the face, using a preset as the starting point and per-axis mapping.'],
        ['選んだ対象のグループが顔にどう反応するかを、プリセットを出発点にして、軸ごとのマッピングで決めます。']),
    prepare=(
        ['Select a valid row in Live Target Group.'],
        ['「ライブ対象グループ」で正しい行を選びます。']),
    steps=(
        ['Press Mouth, Eyes or Blink to load bundled starting values.',
         'Open X-Axis Mapping and Y-Axis Mapping and fine-tune them for this face and camera.'],
        ['「口」「目」「まばたき」を押し、同梱の初期値を読みます。',
         '「X 軸マッピング」「Y 軸マッピング」を開き、この顔とカメラに合わせて調整します。']),
    settings=(
        ['Mouth: starting values for mouth open / width tracking.',
         'Eyes: starting values for eye (iris) movement.',
         'Blink: starting values for eyelid blinks.',
         'X-Axis Mapping / Y-Axis Mapping: sub-sections (see their help).'],
        ['口：口の開き・幅を読む初期値です。',
         '目：目（虹彩）の動きを読む初期値です。',
         'まばたき：まぶたのまばたきを読む初期値です。',
         'X 軸マッピング / Y 軸マッピング：中の欄です（そのヘルプを見てください）。']),
    verify=(
        ['Start the tracker and check the handle follows your face.'],
        ['トラッカーを開始し、ハンドルが顔に合わせて動く事を確かめます。']),
    undo=(
        ['A preset overwrites the axis mapping values of this group; Ctrl+Z restores them.'],
        ['プリセットはこのグループの軸のマッピングの値を上書きします。Ctrl+Z で戻せます。']),
)

HELP_DATA['face_tracker_axis_mapping'] = _e(
    ('X-Axis / Y-Axis Mapping', 'X 軸 / Y 軸マッピング'),
    purpose=(
        ['Converts a raw landmark measurement into the X or Y value of the group. X and Y have separate settings.'],
        ['ランドマークの生の計測値を、グループの X か Y の値に変えます。X と Y は別々に設定します。']),
    prepare=(
        ['Open Reference Map to find landmark numbers. Start the tracker so the current raw value can be captured.'],
        ['「参照マップ」でランドマークの番号を調べます。今の値を取るため、トラッカーを開始しておきます。']),
    steps=(
        ['Choose the Tracking Mode.',
         'Set Point A and Point B.',
         'Make the neutral face and press Capture Min; make the strongest face and press Capture Max.',
         'Set the output range, Gain, Curve and Smoothing until the motion is stable.'],
        ['「トラッキング方式」を選びます。',
         '「点 A」「点 B」を決めます。',
         '無表情で「最小を取得」、一番強い表情で「最大を取得」を押します。',
         '動きが落ち着くまで、出力の範囲・ゲイン・カーブ・スムージングを調整します。']),
    settings=(
        ['Tracking Mode: None (off), 2pt (Dist) (distance between Point A and B), 1pt (Proj) (one point projected along the face axis), Iris (iris movement, vertical normalized by eye height).',
         'Point A / Point B: landmark numbers.',
         'Lower Bound / Upper Bound: raw input range. A reversed range also works.',
         'Capture Min / Capture Max: write the current raw value into the bound.',
         'Min Target / Max Target: output range sent to the joystick.',
         'Gain: multiplies the output. Default 1. Curve (Exp): exponent of the response. Default 1.2.',
         'Enable Filter / Smooth Factor: smoothing over time; how far each update moves toward the new value. Default 0.15.'],
        ['トラッキング方式：なし（使わない）・2点距離（点 A と B の距離）・1点投影（顔の軸に沿って 1 点を投影）・虹彩（虹彩の動き。縦は目の高さで割る）。',
         '点 A / 点 B：ランドマークの番号です。',
         '下限 / 上限：生の入力の範囲です。逆向きの範囲でも動きます。',
         '最小を取得 / 最大を取得：今の生の値を、その境界へ書きます。',
         '最小出力 / 最大出力：ジョイスティックへ送る範囲です。',
         'ゲイン：出力の倍率です。既定 1。カーブ（指数）：反応の指数です。既定 1.2。',
         'フィルターを有効化 / スムーズ係数：時間方向のなめらかさです。1 回ごとに新しい値へどれだけ寄せるかです。既定 0.15。']),
    verify=(
        ['Move your face slowly and check the value goes from Min Target to Max Target without jumping.'],
        ['顔をゆっくり動かし、値が最小出力から最大出力まで飛ばずに動く事を確かめます。']),
    undo=(
        ['Ctrl+Z restores values. Re-capture Min/Max after moving the camera.'],
        ['値は Ctrl+Z で戻せます。カメラを動かした後は、最小・最大を取り直します。']),
)

# ---------------------------------------------------------------------------
# Facial CSV Capture and its sub-groups
# ---------------------------------------------------------------------------
HELP_DATA['face_tracker_capture_csv'] = _e(
    ('Facial CSV Capture', 'フェイシャルCSV収録'),
    purpose=(
        ['Bakes a recorded ARKit 52 facial capture (CSV, or a recorded video analysed on this computer) into an Action, either on the facial '
         'rig\'s controller bones or on the ARKit-named Shape Keys of the face meshes. Two Actions are made: RAW (as recorded) and EDIT (for hand fixes).',
         'The same section also has tools for building the face rig: initial shapes, corrective keys, facial presets, oral contact inspection, '
         'head rotation, the ARKit rig bake for hand keys / return to expression mode, the ARKit rig check / reapply from its spec JSON, '
         'and material color correction. Each group has its own heading with a "?".'],
        ['収録した ARKit 52 表情（CSV、またはこのパソコンで解析する録画の動画）を、顔リグのコントローラーの骨か、顔メッシュの ARKit 名のシェイプキーへアクションとして焼き込みます。'
         'RAW（収録のまま）と EDIT（手で直す用）の 2 つのアクションができます。',
         '同じ欄に、顔リグを作るための道具（初期形状・補正キー・表情プリセット・口内の接触検査・頭の回転・ARKit リグの手付け用の焼きと表情モードへの戻し・'
         'ARKit リグの正本 JSON での検査と当て直し・材質の色補正）もあります。グループごとに「？」付きの見出しがあります。']),
    prepare=(
        ['Use Object Mode. Save a working copy under a new name before importing, before baking for hand animation, and before reverting.',
         'Set Facial Rig to the face armature (needed for bone capture, head rotation and initial shapes).',
         'Stop the live Face Tracker before importing a video.'],
        ['オブジェクトモードにします。取り込む前・手付け用に焼く前・戻す前には、そのつど作業の写しを別名で保存します。',
         '「表情リグ」に顔のアーマチュアを指定します（骨への取り込み・頭の回転・初期形状で使います）。',
         '動画を取り込む前に、ライブのフェイストラッカーを止めておきます。']),
    steps=(
        ['Choose Facial Rig.',
         'To put a capture on a finished model, use the groups "Capture settings", "Calibration (EDIT only)" and "Bake and RAW / EDIT" in that order.',
         'While building a rig, use "Initial shapes (rig building)", "Corrective key (two inputs)" and "Facial presets".',
         'To find the tongue cutting into teeth or face, use "Oral contact inspection".',
         'To fix an ARKit slider rig by hand, use "ARKit rig: bake / return"; to put its sliders back after a rig update, use "ARKit rig: check / reapply".',
         'To make a calibration table from several captures, use "Build Calibration Table"; to check what a capture gives before or after the import, use "Capture Inspection".',
         'Read the result line at the bottom of the section after each operation.'],
        ['「表情リグ」を選びます。',
         '完成したモデルへ収録を入れる時は、「収録の取り込みの設定」→「校正（EDITだけ）」→「取り込みと RAW／EDIT」の順に、その見出しの下を使います。',
         'リグを作る段階では、「初期形状の生成」「補正キー（2 つの入力）」「表情・補正プリセット」を使います。',
         '舌が歯や顔に食い込んでいないか調べる時は「口内の接触検査」を使います。',
         'ARKit のスライダーのリグを手で直す時は「ARKitリグの焼きと戻し」、リグの更新の後にスライダーのつながりを戻す時は「ARKitリグの検査と当て直し」を使います。',
         '何本もの収録から校正表を作る時は「校正表を作る」、取り込みの前後で係数の届き方を確かめる時は「取り込みの点検」を使います。',
         '操作のたびに、欄の一番下の結果の行を読みます。']),
    settings=(
        ['Facial Rig: armature with the face controllers (for example an Auto-Rig Pro rig with cc_arkit_* controller bones).',
         'Result line (bottom): result of the last operation; "Not imported" at first.'],
        ['表情リグ：顔のコントローラーを持つアーマチュアです（例：cc_arkit_* のコントローラーの骨を持つ Auto-Rig Pro のリグ）。',
         '結果の行（一番下）：直前の操作の結果です。最初は「未取り込み」。']),
    verify=(
        ['Read the result line and the warnings in the status bar / Info editor. Missing columns or unmapped bones mean the capture is not complete.'],
        ['結果の行と、ステータスバー・情報エディターの警告を読みます。足りない列や対応の無い骨がある時は、取り込めたと見なしません。']),
    undo=(
        ['Most operations can be undone with Ctrl+Z. Files written to disk stay.',
         'Do not overwrite the original file, RAW, older takes or backup Actions.'],
        ['ほとんどの操作は Ctrl+Z で戻せます。ディスクへ書いたファイルは残ります。',
         '元のファイル・RAW・古いテイク・控えのアクションを上書きしたり消したりしないでください。']),
)

HELP_DATA['facial_shape_generation'] = _e(
    ('Initial shapes (rig building)', '初期形状の生成'),
    purpose=(
        ['Creates draft ARKit 52 Shape Keys from Auto-Rig Pro (ARP) face rig poses, and helps refine them. Use it while building a rig; '
         'do not use it when you only put a capture on a finished model.'],
        ['Auto-Rig Pro（ARP）の顔リグのポーズから、ARKit 52 表情の下書きのシェイプキーを作り、直す手助けをします。リグを作る段階の道具です。'
         '完成したモデルへ収録を入れるだけの時は使いません。']),
    prepare=(
        ['Work on a copy: Export Facial Working Copy writes the selected face parts and the rig to a separate .blend; open that copy.',
         'Object Mode. Select the face part meshes and set Facial Rig.'],
        ['写しで作業します。「顔制作コピーを書き出す」で、選んだ顔の部品とリグを別の .blend に書き出し、その写しを開きます。',
         'オブジェクトモードにします。顔の部品のメッシュを選び、「表情リグ」を指定します。']),
    steps=(
        ['Select the face parts and press Export Facial Working Copy, then choose the file name.',
         'Open the exported copy.',
         'Set Initial Shape Strength and, if needed, Custom Pose Recipe (Optional).',
         'Select the face parts and press Generate 52 Initial Shapes from ARP.',
         'After fixing shapes by hand, apply a correction preset (.ssfacial) with Apply Correction Preset if you have one.',
         'If the jaw should open a little when the tongue comes out, set Jaw Assist Limit and press Create Jaw Assist.'],
        ['顔の部品を選んで「顔制作コピーを書き出す」を押し、ファイル名を決めます。',
         '書き出した写しを開きます。',
         '「初期形状の生成強度」と、必要なら「独自ポーズレシピ（任意）」を決めます。',
         '顔の部品を選んで「ARPから52表情の初期形状を生成」を押します。',
         '形を手で直した後、補正プリセット（.ssfacial）がある時は「初期表情へ補正プリセットを反映」で当てます。',
         '舌を出す時に顎も少し開けたい時は、「舌の開口補助上限」を決めて「舌の開口補助を生成」を押します。']),
    settings=(
        ['Export Facial Working Copy: writes the selected face parts and the rig to another .blend. The open file is not changed.',
         'Initial Shape Strength: multiplier of the rig poses (0.1 to 3). Recommended: 1.',
         'Custom Pose Recipe (Optional): JSON describing the 52 poses. Empty uses the bundled draft recipe.',
         'Generate 52 Initial Shapes from ARP: poses the rig as the recipe says and stores each result as an ARKit-named Shape Key. The result says adjustments are needed: it is a draft.',
         'Apply Correction Preset: applies a .ssfacial correction to the initial shapes made by this tool; the initial shapes are archived first.',
         'Restore Archived Initial Shapes: returns to the archived initial shapes.',
         'Jaw Assist Limit: largest jaw opening added from tongue input (0.01 to 1). Recommended: 0.5 (default). Recorded Action values are not changed.',
         'Create Jaw Assist / Remove Jaw Assist: duplicates the jaw and related correctives to add tongue-driven opening / removes only the assistance this tool made.'],
        ['顔制作コピーを書き出す：選んだ顔の部品とリグを、別の .blend に書き出します。開いているファイルは変わりません。',
         '初期形状の生成強度：リグのポーズの強さの倍率です（0.1〜3）。おすすめ：1。',
         '独自ポーズレシピ（任意）：52 表情のポーズの作り方を書いた JSON です。空なら同梱の下書きのレシピを使います。',
         'ARPから52表情の初期形状を生成：レシピの通りにリグを動かし、その形を ARKit 名のシェイプキーとして作ります。結果に「見た目の調整が必要です」と出ます。下書きです。',
         '初期表情へ補正プリセットを反映：.ssfacial の補正を、この道具が作った初期形状へ当てます。当てる前に初期形状を保管します。',
         '保管した初期表情へ戻す：保管した初期形状へ戻します。',
         '舌の開口補助上限：舌の入力で顎を足す開きの上限です（0.01〜1）。おすすめ：0.5（既定）。収録のアクションの値は変えません。',
         '舌の開口補助を生成 / 開口補助を除去：顎と関連の補正を複製して、舌の入力で顎が開く補助を作る / この道具が作った補助だけを消します。']),
    verify=(
        ['The result line shows how many keys were generated or updated. Move each new Shape Key from 0 to 1 and look at the face from several angles.'],
        ['結果の行に、作った・更新したキーの数が出ます。新しいシェイプキーを 0 から 1 へ動かし、いろいろな角度から顔を見ます。']),
    undo=(
        ['Ctrl+Z, Restore Archived Initial Shapes, or Remove Jaw Assist.',
         'Linked or shared meshes are refused. Generated shapes are drafts, not final quality.'],
        ['Ctrl+Z、「保管した初期表情へ戻す」、「開口補助を除去」で戻せます。',
         'リンク・共有のメッシュは断られます。生成した形は下書きで、そのまま完成の品質にはなりません。']),
)

HELP_DATA['facial_corrective'] = _e(
    ('Corrective key (two inputs)', '補正キー（2 つの入力）'),
    purpose=(
        ['Makes a corrective Shape Key that fixes the shape when two ARKit expressions are on together (for example jawOpen and tongueOut), '
         'and connects it with a driver so it turns on automatically from the two input values.',
         'The driver is a standard Blender expression, so it plays without this add-on.'],
        ['2 つの ARKit の表情が同時に効いた時（例：jawOpen と tongueOut）の形のずれを直す「補正キー」を作り、2 つの入力の値で自動に効くようドライバーで接続します。',
         'ドライバーは Blender 標準の式なので、このアドオンが無くても再生できます。']),
    prepare=(
        ['Object Mode. Make the corrective part (for example the tongue) active, and also select another part that has the input ARKit keys (for example the face).',
         'The parts must be local, not shared, with relative Shape Keys.'],
        ['オブジェクトモードにします。補正するパーツ（例：舌）をアクティブにし、入力の ARKit キーを持つ別のパーツ（例：顔）も一緒に選びます。',
         'パーツはローカルで共有されておらず、相対のシェイプキーを持っている必要があります。']),
    steps=(
        ['Choose Corrective Response.',
         'Type the Corrective Key name, First ARKit Input and Second ARKit Input (defaults jawOpen and tongueOut).',
         'Set the two center values to the input values where the correction should be strongest.',
         'Press Preview Two Inputs to see that mix.',
         'Press Capture Mix as Editing Target. The current mixed shape is stored as the Editing Target Key.',
         'Fix the Editing Target Key with ordinary Shape Key editing (Edit Mode or sculpting). For a tongue you can also use the shaping settings below.',
         'Press Create Corrective from Target. The fixed difference becomes a new corrective key connected to the two inputs.',
         'To connect an existing corrective key only, use Connect Corrective Driver; to disconnect, use Disconnect Corrective Driver.'],
        ['「補正の応答方式」を選びます。',
         '「補正キー」の名前と、「1つ目のARKit入力」「2つ目のARKit入力」を入れます（既定は jawOpen と tongueOut）。',
         '2 つの中心値を、補正を一番強く効かせたい入力の値にします。',
         '「選択部品の2入力値を揃えてプレビュー」を押し、その混ざり方を見ます。',
         '「ミックスを編集目標にする」を押します。今の混ざった形が「編集目標キー」として保存されます。',
         '編集目標キーを、ふつうのシェイプキーの編集（編集モード・スカルプト）で正しい形に直します。舌は、下の整形の設定でも整えられます。',
         '「編集目標から補正キーを作成」を押します。直した差が新しい補正キーになり、2 つの入力に接続されます。',
         '既にある補正キーを接続するだけの時は「補正キーを2表情に接続」、外す時は「補正ドライバーの接続を解除」を使います。']),
    settings=(
        ['Corrective Response: BOX Weight (fades away from the two centers), Ramped Inputs (rises from the start values to the full-response values, then holds), '
         'First × (1 − Second) (centers fixed to 1 and 0), Plateau BOX (full inside half the radius, zero at the radius). Recommended: BOX Weight first.',
         'Corrective Key: name of the key to create or connect. Default SS_Tongue_Midpoint.',
         'First / Second ARKit Input: the two ARKit names that trigger the correction. They must differ.',
         'First / Second Input Center (Full Response Value with Ramped Inputs): input value (0 to 1) where the correction is full.',
         'Corrective Radius (BOX and Plateau BOX): how far from the centers it still works (0.01 to 1). Default 0.5.',
         'First / Second Ramp Start (Ramped Inputs): value where the correction starts to rise; must be below the full-response value.',
         'Reset Other Inputs for Preview: sets other ARKit values to 0 during preview so the mix is easy to see. Recommended: on.',
         'Reset ARKit Values to Zero: sets only ARKit values of the selected parts to 0. Actions and shapes are protected.',
         'Save Facial Mix / Read Facial Mix: save the current ARKit values to a .ssmix file / apply one to the selected parts (other ARKit values become 0).',
         'Editing Target Key: name of the captured target. Default SS_Corrective_Target.',
         'Shape Captured Tip: when on, keeps the captured root and changes only the tip: width scale 1 to 2, thickness scale 1 to 3, '
         'shortening 0 to 0.02, center retraction 0 to 0.01, root hold 0 to 0.8 (default 0.45).',
         'When off: Target Width / Depth Scale (0.6 to 1), Target Thickness Scale (above 1 keeps width, depth and lift; those fields turn grey and '
         'Thickness Root Hold and Max Thickness Gain appear), Tip Vertical Offset and Root-Preserving Lift (within ±0.01), '
         'Lift Arrival Position (0.05 to 1; root to tip is 0 to 1, the part beyond it gets the same lift).',
         'Max Displacement: largest movement of one vertex by shaping. Default 0.006.',
         'Shape Editing Target: applies the shaping settings above to the captured editing target.'],
        ['補正の応答方式：BOX補正（2 つの中心から離れるほど弱まる）・入力に合わせて増加（開始値から最大補正値まで増え、その後は保持）・'
         '1つ目×（1−2つ目）（中心は 1 と 0 に固定）・範囲内を保持するBOX（半径の内側半分は最大、半径の端でゼロ）。おすすめ：まず BOX補正。',
         '補正キー：作る・接続する補正キーの名前です。既定 SS_Tongue_Midpoint。',
         '1つ目 / 2つ目のARKit入力：補正のきっかけになる 2 つの ARKit の名前です。違う 2 つにします。',
         '1つ目 / 2つ目の中心値（「入力に合わせて増加」の時は最大補正値）：補正が最大になる入力の値です（0〜1）。',
         '補正の半径（BOX補正・範囲内を保持するBOX）：中心からどこまで効かせるかです（0.01〜1）。既定 0.5。',
         '第一 / 第二入力の開始値（入力に合わせて増加）：補正が増え始める値です。最大補正値より小さくします。',
         'プレビュー時に他を0へ戻す：プレビューの時に他の ARKit の値を 0 にして、混ざり方を見やすくします。おすすめ：オン。',
         '選択部品のARKit値をゼロへ戻す：選んだ部品の ARKit の値だけを 0 にします。アクションと形は守られます。',
         '表情ミックスを保存 / 表情ミックスを読み込む：今の ARKit の値を .ssmix に保存する / 読んで選んだ部品へ当てます（他の ARKit の値は 0 になります）。',
         '編集目標キー：取り込む編集目標の名前です。既定 SS_Corrective_Target。',
         '取り込んだ舌先を整形：オンにすると、取り込んだ舌根を保ち、舌先だけを変えます。舌先の幅倍率 1〜2、舌先の厚み倍率 1〜3、舌先の短縮量 0〜0.02、'
         '舌先中央の後退 0〜0.01、固定する舌根の割合 0〜0.8（既定 0.45）。',
         'オフの時：目標の横幅倍率・目標の奥行き倍率（0.6〜1）、目標の厚み倍率（1 より大きくすると幅・奥行き・持ち上げは保たれ、その欄は灰色になり、'
         '「厚みの根元固定」と「厚み増加の変形上限」が出ます）、舌先の上下移動と前側の持ち上げ（±0.01 以内）、'
         '持ち上げの到達位置（0.05〜1。根元から先端を 0〜1 とし、そこから前は同じ持ち上げ）。',
         '最大移動量：整形で 1 つの頂点が動ける最大の量です。既定 0.006。',
         '編集目標を舌根固定で整形：上の整形の設定を、取り込んだ編集目標へ当てます。']),
    verify=(
        ['Set both inputs to their centers: the shape should be fixed. Move only one input: the correction should fade.',
         'The corrective key value field turns purple (driven).'],
        ['両方の入力を中心値にした時に形が直り、片方だけ動かした時は補正が弱まる事を確かめます。',
         '補正キーの値の欄が紫（ドライバー付き）になります。']),
    undo=(
        ['Ctrl+Z undoes these operations. Disconnect Corrective Driver removes only an unchanged driver made by this tool and keeps the corrective shape.',
         'An existing corrective name, Basis or a canonical ARKit key cannot be used as the corrective target.',
         'If the editing target was edited by hand, capture a new target before shaping again.'],
        ['これらの操作は Ctrl+Z で戻せます。「補正ドライバーの接続を解除」は、この道具が作って変えていないドライバーだけを外し、補正の形は残します。',
         '既にある補正の名前、Basis、ARKit の正規のキーは、補正の対象にできません。',
         '編集目標を手で直した後に整形し直す時は、新しく取り込み直します。']),
)

HELP_DATA['facial_library'] = _e(
    ('Facial presets', '表情・補正プリセット'),
    purpose=(
        ['Saves the ARKit expression shapes of face parts and the corrective keys made by this tool (including their BOX settings) into one .ssfacial file, '
         'and applies such a file to matching meshes.'],
        ['顔の部品の ARKit の表情の形と、この道具が作った補正キー（BOX の設定を含む）を 1 つの .ssfacial ファイルに保存し、そのファイルを対応するメッシュへ当てます。']),
    prepare=(
        ['Object Mode. Select the face meshes with ARKit-named Shape Keys (up to 64; linked or shared meshes are refused).'],
        ['オブジェクトモードにします。ARKit 名のシェイプキーを持つ顔のメッシュを選びます（64 個まで。リンク・共有のメッシュは断られます）。']),
    steps=(
        ['To save: press Save Shapes and Correctives and choose a file name. In the dialog, Save Selected Parts Only saves only the expressions the selected parts have; '
         'when it is off, all 52 ARKit expressions must exist across the selection.',
         'To apply: select the target face meshes, press Apply Shapes and Correctives and choose the .ssfacial file.'],
        ['保存：「表情・補正を保存」を押し、ファイル名を決めます。ダイアログの「選択した部品だけ保存」をオンにすると、選んだ部品にある表情だけを保存します。'
         'オフの時は、選んだ全体で ARKit 52 表情がそろっている必要があります。',
         '適用：当てたい顔のメッシュを選び、「表情・補正を適用」を押して .ssfacial を選びます。']),
    settings=(
        ['Save Shapes and Correctives: writes a .ssfacial file.',
         'Save Selected Parts Only (save dialog): saves the existing expressions of the selected parts; it does not check that all 52 exist.',
         'Apply Shapes and Correctives: adds the shapes and correctives from the file to the selected meshes.'],
        ['表情・補正を保存：.ssfacial ファイルを書きます。',
         '選択した部品だけ保存（保存のダイアログ）：選んだ部品にある表情だけを保存します。52 表情がそろっているかは確かめません。',
         '表情・補正を適用：ファイルの形と補正を、選んだメッシュへ足します。']),
    verify=(
        ['The result line shows how many parts, shapes and correctives were saved, or how many new shapes and correctives were added.'],
        ['結果の行に、保存した部品・形・補正の数、または新しく足した形・補正の数が出ます。']),
    undo=(
        ['Ctrl+Z undoes Apply Shapes and Correctives. The saved file stays on disk.'],
        ['「表情・補正を適用」は Ctrl+Z で戻せます。保存したファイルはディスクに残ります。']),
)

HELP_DATA['facial_contact_inspection'] = _e(
    ('Oral contact inspection', '口内の接触検査'),
    purpose=(
        ['Checks whether the tongue cuts into the teeth or the inside of the face, by counting exact triangle crossings. Shapes and Actions are not changed.'],
        ['舌が歯や顔の内側に食い込んでいないかを、三角形の交差の数で調べます。形とアクションは変えません。']),
    prepare=(
        ['Object Mode. Make the tongue active and also select the face and the upper and lower teeth.'],
        ['オブジェクトモードにします。舌をアクティブにし、顔と上下の歯も選びます。']),
    steps=(
        ['Press Inspect Selected Oral Contacts. The result appears in the section and the report is saved as a Text.',
         'To check inside a capture Action, press Start Action Inspection. It checks four key frames at a time and returns to the starting frame each time; it stops when a contact is found.',
         'Press Next Four Key Frames to continue (available only while there is more to check).',
         'To find where to fix an editing target: capture a target and inspect it, type Contact Surface Part and Contact Sample Number from the report, then press Select Contact Vertices.',
         'Press Probe the Reported Contact Face to sample inside the reported face (up to 128 points).'],
        ['「選択部品の口内交差を検査」を押します。結果がこの欄に出て、報告がテキストに保存されます。',
         '収録のアクションの中を調べる時は「アクション検査開始」を押します。キーのある時刻を 4 点ずつ調べ、毎回開始フレームへ戻ります。接触が見つかると止まります。',
         '続ける時は「次のキー4点」を押します（続きがある時だけ押せます）。',
         '編集目標の直す場所を探す時：目標を取り込んで検査し、報告から「交差した相手部品」と「交差例の番号（0始まり）」を入れ、「補正目標の交差した面頂点を選択」を押します。',
         '「交差面の内部標本を調べる」で、報告された交差面の中を調べます（最大 128 点）。']),
    settings=(
        ['Inspect Selected Oral Contacts: counts triangle crossings between the active tongue and the selected face or teeth.',
         'Start Action Inspection / Next Four Key Frames: inspect the assigned ARKit Action at key frames only, four at a time.',
         'Contact Surface Part: name of the crossed part from the report. Contact Sample Number: which crossing example (counted from 0).',
         'Select Contact Vertices: selects the source face vertices of that example in the owned editing target (checked against the current report).',
         'Probe the Reported Contact Face: reads a limited number of solid samples inside the reported face.',
         'Result lines and Text names (with the text icon): status of the last inspection. Open the Text in the Text Editor to read it.'],
        ['選択部品の口内交差を検査：アクティブな舌と、選んだ顔・歯の三角形の交差を数えます。',
         'アクション検査開始 / 次のキー4点：割り当てた ARKit のアクションを、キーのある時刻だけ 4 点ずつ調べます。',
         '交差した相手部品：報告にある相手の部品の名前です。交差例の番号（0始まり）：どの交差の例かです。',
         '補正目標の交差した面頂点を選択：この道具の編集目標で、その例の元の面の頂点を選びます（今の報告と形を照らしてから選びます）。',
         '交差面の内部標本を調べる：報告された面の中を、決まった数だけ調べます。',
         '結果の行とテキストの名前（テキストのアイコン付き）：直前の検査の状態です。テキストエディターでそのテキストを開いて読みます。']),
    verify=(
        ['A crossing count of 0 means no triangle crossing was found among the inspected parts and frames.'],
        ['交差の数が 0 なら、調べた部品と時刻の中に三角形の交差は見つかっていません。']),
    undo=(
        ['Inspection changes nothing except the vertex selection.',
         'Only crossings are counted; visibility and transparency are not judged. Samples do not prove that the whole surface is clear.',
         'After changing the shape or the frame, the old report is stale and you are asked to inspect again.'],
        ['検査は、頂点の選択のほかは何も変えません。',
         '数えるのは交差だけです。見えるか・透けるか（可視性・透明度）は判定しません。標本は「全面に接触が無い」証明になりません。',
         '形やフレームを変えた後は、古い報告は使えず、もう一度検査するよう求められます。']),
)

HELP_DATA['facial_capture_setup'] = _e(
    ('Capture settings', '収録の取り込みの設定'),
    purpose=(
        ['Decides where the capture is written, how existing Actions are treated, and when the capture starts.'],
        ['収録をどこへ書くか、既にあるアクションをどう扱うか、どのフレームから始めるかを決めます。']),
    prepare=(
        ['For bones: set Facial Rig to the armature with cc_arkit_* controller bones. For Shape Keys: select the face meshes with ARKit-named Shape Keys.',
         'Unmuted NLA tracks on the target are protected and make the import stop. Mute other layered animation first.'],
        ['骨の時：「表情リグ」に cc_arkit_* のコントローラーの骨を持つアーマチュアを指定します。シェイプキーの時：ARKit 名のシェイプキーを持つ顔のメッシュを選びます。',
         '対象に効いている（ミュートしていない）NLA のトラックがあると、守るために取り込みを止めます。他の重ねたアニメーションは先にミュートします。']),
    steps=(
        ['In Capture Destination choose To Bones or To Shape Keys. For a finished rig choose To Bones.',
         'To keep the body Action and earlier hand fixes, turn on Keep Existing Actions for New Take.',
         'For bones, check Start Frame and Frame Offset.',
         'For Shape Keys, decide Require All ARKit Channels.'],
        ['「取り込み先」で「骨」か「シェイプキー」を選びます。完成したリグへ入れる時は「骨」です。',
         '体のアクションとこれまでの手直しを残す時は、「既存アクションを残す」をオンにします。',
         '骨の時は「開始フレーム」と「フレームのオフセット値」を確かめます。',
         'シェイプキーの時は「CSVの全表情キーを必須にする」を決めます。']),
    settings=(
        ['Capture Destination: To Bones writes the ARKit controller bones (their Y movement); To Shape Keys writes the existing ARKit Shape Keys of the face meshes (for comparison). Recommended: To Bones.',
         'Require All ARKit Channels (Shape Keys only): when on, the import stops if a capture expression has no matching key. Recommended: on.',
         'Keep Existing Actions for New Take: when on, the current Action is kept and a new take is made. When off and the rig already has a body Action, the import is refused. Recommended: on.',
         'Start Frame / Frame Offset (bones only): frame where the first sample is placed, and an extra shift. Do not change the scene FPS just for the import.'],
        ['取り込み先：「骨」は ARKit のコントローラーの骨（その Y の動き）へ書きます。「シェイプキー」は顔メッシュの既存の ARKit シェイプキーへ書きます（比べる用）。おすすめ：骨。',
         'CSVの全表情キーを必須にする（シェイプキーの時だけ）：オンだと、収録の表情に合うキーが無い時に取り込みを止めます。おすすめ：オン。',
         '既存アクションを残す：オンだと、今のアクションを残して新しいテイクを作ります。オフで、リグに体のアクションが既にある時は、取り込みを断ります。おすすめ：オン。',
         '開始フレーム / フレームのオフセット値（骨の時だけ）：最初の標本を置くフレームと、さらにずらす量です。取り込みのためだけにシーンの fps を変えないでください。']),
    verify=(
        ['After the import, read the result line, for example "Bones 51 / missing columns 0 / unmapped bones 0".'],
        ['取り込んだ後、結果の行（例「骨 51 / 無い列 0 / 未対応骨 0」）を読みます。']),
    undo=(
        ['Changing these settings does not change existing takes; they apply to the next import.'],
        ['この設定を変えても、既にあるテイクは変わりません。次の取り込みから効きます。']),
)

HELP_DATA['facial_calibration'] = _e(
    ('Calibration (EDIT only)', '校正（EDITだけ）'),
    purpose=(
        ['Rescales the captured values (0 to 1) to strengths that suit this face. It applies only to EDIT; RAW keeps the recorded values.',
         'The order is: calibration, then gain (strength), then smoothing.'],
        ['収録の値（0〜1）を、この顔に合う強さへ直します。EDIT にだけ掛かり、RAW は収録の値のままです。',
         '掛かる順番は、校正 → 利得（強さ） → 平滑化 です。']),
    prepare=(
        ['Decide which table to use before importing. Calibration is applied at import time.'],
        ['取り込む前に、どの校正表を使うか決めます。校正は取り込みの時に掛かります。']),
    steps=(
        ['Bones: keep Bone Calibration (EDIT Only) on (default on). Without a loaded table the bundled generic table is used and the line "In use: generic table" is shown.',
         'To use your own table, press Load Calibration and choose a JSON or CSV file. The line "count / file name" appears and the generic-table line disappears.',
         'Shape Keys: load a table first, then turn on Per-Channel Calibration (EDIT Only). Turning it on without a table stops the import with an error.',
         'Decide the nose and cheek estimation (bones only).',
         'Import in the next group.'],
        ['骨の時：「骨の校正（EDITのみ）」をオンのままにします（既定はオン）。表を読まない時は同梱の汎用校正表が使われ、「使用中: 汎用校正表（本人用は任意）」と出ます。',
         '自分の表を使う時は「校正表を読む」を押し、JSON か CSV を選びます。「係数の数 / ファイル名」の行が出て、「使用中: 汎用校正表」の行は消えます。',
         'シェイプキーの時：先に表を読んでから「係数別校正（EDITのみ）」をオンにします。表を読まずにオンにすると、取り込みがエラーで止まります。',
         '鼻と頬の推定を決めます（骨の時だけ）。',
         '次のグループで取り込みます。']),
    settings=(
        ['Bone Calibration (EDIT Only) / Per-Channel Calibration (EDIT Only): turn calibration on or off.',
         'Table format: version 1 (JSON or CSV) maps neutral to 0 and maximum to 1 per channel. Version 2 (JSON only) may add knots to a row: '
         '2 to 4 [x, y] pairs between 0 and 1, x increasing, y not decreasing; outside the knots the end value is held. Invalid tables are refused with a reason.',
         'Load Calibration: reads a JSON or CSV table; it overrides the bundled table.',
         'JSON / CSV: saves the loaded table. A version 2 table cannot be saved as CSV.',
         'Neutral Draft JSON (bones only): writes a neutral-side draft from the neutral part (first seconds or frames) of the last imported CSV. Type the maximum values by hand; the draft is not an accepted table.',
         'Infer Zero Nose Sneer / Infer Zero Cheek Squint (default on) and Nose / Cheek Estimator k (0.6 / 0.8): only when that recorded column never exceeds 0.0004, '
         'the value is estimated from other expressions. Measured values always win.',
         'Tongue (tongueOut) and cheek puff (cheekPuff) are for hand animation only; bone import writes no keys for them, and the per-part gain is 1.'],
        ['骨の校正（EDITのみ）/ 係数別校正（EDITのみ）：校正の入切です。',
         '表の形式：version 1（JSON か CSV）は、係数ごとに neutral を 0、max を 1 にします。version 2（JSON だけ）は、行に折れ点 knots を足せます。'
         '0〜1 の [x, y] を 2〜4 組、x は増える順、y は減らない順です。折れ点の外は端の値を保ちます。正しくない表は理由付きで断られます。',
         '校正表を読む：JSON か CSV の表を読みます。同梱の表より優先します。',
         'JSON / CSV：読んだ表を保存します。version 2 の表は CSV では保存できません。',
         'neutralの下書きJSON（骨の時だけ）：最後に取り込んだ CSV の無表情の区間（最初の秒数かフレーム数）から、neutral 側の下書きを書き出します。max は手で入れます。下書きは受け入れ済みの表ではありません。',
         '鼻しわが0なら推定 / 頬の持ち上げが0なら推定 / 鼻しわ推定の係数k / 頬の持ち上げ推定の係数k：既定はオン・オン・0.6・0.8。鼻しわ（noseSneer）・頬の持ち上げ（cheekSquint）の列の収録の値が最大でも 0.0004 以下の時だけ、他の表情から推定します。測れた値があれば、そちらが優先です。',
         '舌（tongueOut）と頬ふくらみ（cheekPuff）は手付け専用です。骨への取り込みではキーを書かず、部位ごとの利得は 1 です。']),
    verify=(
        ['After importing, switch between RAW and EDIT and compare. Calibration changes only EDIT.'],
        ['取り込んだ後、RAW と EDIT を切り替えて比べます。校正で変わるのは EDIT だけです。']),
    undo=(
        ['Changing calibration does not recalculate an EDIT that already exists. Import again into a new take to compare.',
         'The bundled table is generic, not fitted to a person. Well-behaved numbers do not mean the face looks right; check it visually.'],
        ['校正を変えても、既にある EDIT は計算し直されません。比べる時は、新しいテイクへ取り込み直します。',
         '同梱の表は一般的な物で、個人に合わせた物ではありません。数値が整っても見た目の合格ではないので、目で確かめます。']),
)

HELP_DATA['facial_capture_bake'] = _e(
    ('Bake and RAW / EDIT', '取り込みと RAW／EDIT'),
    purpose=(
        ['Imports the capture (CSV, or a recorded video analysed here) and switches between the RAW and EDIT Actions.'],
        ['収録（CSV、またはここで解析する録画の動画）を取り込み、RAW と EDIT のアクションを切り替えます。']),
    prepare=(
        ['Finish the capture settings and calibration first.',
         'For video, the Face Tracker requirements must be installed and the live Face Tracker must be stopped.'],
        ['先に、取り込みの設定と校正を済ませます。',
         '動画の時は、フェイストラッカーの必要環境がインストール済みで、ライブのフェイストラッカーが止まっている必要があります。']),
    steps=(
        ['Set EDIT Smoothing (Seconds) and, for Shape Keys, the five strength values.',
         'Press Bake Facial CSV and choose the CSV, or press Bake Video to Facial Action and choose the video.',
         'Check the options on the right of the file browser, then confirm.',
         'Read the result line and warnings.',
         'Press RAW or EDIT to switch the Action. Use EDIT for production; keep RAW for comparison.'],
        ['「EDITの平滑化（秒）」と、シェイプキーの時は 5 つの強さを決めます。',
         '「フェイシャルCSVをベイク」を押して CSV を選ぶか、「録画動画をフェイシャルへベイク」を押して動画を選びます。',
         'ファイル選択の画面の右側の設定を確かめてから、確定します。',
         '結果の行と警告を読みます。',
         '「RAW」「EDIT」を押してアクションを切り替えます。制作には EDIT を使い、RAW は比べるために残します。']),
    settings=(
        ['EDIT Smoothing (Seconds): smoothing applied to EDIT only (0 to 1). Recommended: 0 at first.',
         'Eye / Mouth and Jaw / Brow / Cheek and Nose / Tongue Strength (Shape Keys only): gain per part (0 to 3). 1 keeps the value. Recommended: 1.',
         'Bake Facial CSV: CSV up to 20 MiB. File browser options: Source Timecode FPS (default 60), Start Frame, Frame Offset, Coefficient Units (0 to 1, or 0 to 100 which is divided by 100).',
         'Bake Video to Facial Action: mp4 / mov / mkv / avi / webm, up to 30 seconds. 51 expressions are read by the bundled MediaPipe model; tongue and head rotation are not available. '
         'Options: Recording Is Mirrored, Video Timestamps (recorded timestamps or constant FPS).',
         'RAW / EDIT: switch the take between the recorded values and the Action for hand editing.'],
        ['EDITの平滑化（秒）：EDIT にだけ掛ける平滑化です（0〜1）。おすすめ：まず 0。',
         '目の強さ・口・顎の強さ・眉の強さ・頬・鼻の強さ・舌の強さ（シェイプキーの時だけ）：部位ごとの倍率です（0〜3）。1 でそのまま。おすすめ：1。',
         'フェイシャルCSVをベイク：20 MiB までの CSV。ファイル選択の画面の設定：タイムコードのフレーム基数（既定 60）・開始フレーム・フレームのオフセット値・係数の単位（0〜1、または 100 で割る 0〜100）。',
         '録画動画をフェイシャルへベイク：mp4 / mov / mkv / avi / webm、30 秒まで。同梱の MediaPipe のモデルで 51 表情を読みます。舌と頭の回転は取れません。'
         '設定：録画が左右反転済み、動画の時刻（録画の時刻か固定fps）。',
         'RAW / EDIT：テイクを、収録の値のアクションと、手で直す用のアクションの間で切り替えます。']),
    verify=(
        ['The result line shows mapped bones or channels, missing columns and unmapped items. Missing columns mean the capture is incomplete; note them.',
         'Play the timeline over the whole working range.'],
        ['結果の行に、対応した骨や係数・足りない列・対応の無い物の数が出ます。足りない列がある時は取り込めたと見なさず、記録します。',
         '作業範囲の終わりまでタイムラインを再生して確かめます。']),
    undo=(
        ['Ctrl+Z undoes an import. Switching RAW / EDIT changes only which Action is assigned.',
         'Limits: RAW + EDIT together may hold at most 250,000 keys; split longer takes. Unmuted NLA tracks and linked or override rigs are protected and refused.'],
        ['取り込みは Ctrl+Z で戻せます。RAW / EDIT の切り替えは、割り当てるアクションを替えるだけです。',
         '限界：RAW と EDIT を合わせて 25 万キーまでです。長いテイクは分けます。効いている NLA のトラックや、リンク・オーバーライドのリグは守るために断ります。']),
)

HELP_DATA['facial_head_capture'] = _e(
    ('Head rotation CSV', '頭の回転CSV'),
    purpose=(
        ['Bakes a head rotation CSV (pitch, yaw, roll) onto the rig\'s head controller bone as RAW and EDIT Actions. '
         'It is added on top of the body motion, and the first pose of the CSV is treated as neutral.'],
        ['頭の回転（ピッチ・ヨー・ロール）の CSV を、リグの頭のコントローラーの骨へ、RAW と EDIT のアクションとして焼き込みます。'
         '体の動きに足し合わせ（加算）、CSV の最初の姿勢を基準（無回転）として扱います。']),
    prepare=(
        ['Set Facial Rig. Use Object Mode or Pose Mode.'],
        ['「表情リグ」を指定します。オブジェクトモードかポーズモードにします。']),
    steps=(
        ['Check Head Controller (default c_head.x).',
         'Press Bake Head Rotation CSV and choose the CSV. In the file browser set the options, then confirm.',
         'Switch with Head RAW / Head EDIT.',
         'To remove the connection, press Disconnect Head Capture.'],
        ['「頭コントローラー」を確かめます（既定 c_head.x）。',
         '「頭回転CSVをベイク」を押して CSV を選びます。ファイル選択の画面で設定を決めてから確定します。',
         '「頭RAW」「頭EDIT」で切り替えます。',
         'つなぎを外す時は「頭収録の接続を解除」を押します。']),
    settings=(
        ['Head Controller: bone that receives the rotation.',
         'File browser options: Source Timecode FPS (default 60), Start Frame (current frame), Head Angle Units (radians or degrees), Pitch / Yaw / Roll Local Axis (X / Y / Z, defaults X, Y, Z), Invert Pitch / Yaw / Roll.',
         'Head RAW / Head EDIT: switch between recorded and editable head rotation.',
         'Disconnect Head Capture: removes the head capture connection; the body Action and archived takes are kept.'],
        ['頭コントローラー：回転を受ける骨です。',
         'ファイル選択の画面の設定：タイムコードのフレーム基数（既定 60）・開始フレーム（今のフレーム）・頭角度の単位（ラジアンか度）・ピッチ / ヨー / ロールのローカル軸（X / Y / Z。既定は X・Y・Z）・各符号の反転。',
         '頭RAW / 頭EDIT：収録のままの頭の回転と、手で直せる頭の回転を切り替えます。',
         '頭収録の接続を解除：頭の収録のつなぎを外します。体のアクションと保管したテイクは残ります。']),
    verify=(
        ['The result line shows the number of frames. Play the animation and check the head turns the right way.'],
        ['結果の行にフレームの数が出ます。再生して、頭が正しい向きに回る事を確かめます。']),
    undo=(
        ['Ctrl+Z or Disconnect Head Capture. If the head turns the wrong way, the axis or sign is wrong: import again with other options.'],
        ['Ctrl+Z か「頭収録の接続を解除」で戻せます。逆に回る時は軸か符号が違うので、設定を変えて取り込み直します。']),
)

HELP_DATA['facial_ark_bake'] = _e(
    ('ARKit rig: bake / return', 'ARKitリグの焼きと戻し'),
    purpose=(
        ['For a face rig driven by ARKit sliders (52 slider bones that move the face controller bones through Action constraints), '
         'this switches between two modes:',
         'Expression mode: the sliders move the face. Captures and expression presets are keyed on the sliders.',
         'Hand-key mode: the result of the sliders is written (baked) as keys on every frame into the face controller bones and the '
         'hand values, the slider constraints are stopped, and you can fix the face by hand with ordinary keys.',
         'Bake Face to Hand Keys goes to hand-key mode. Return to Expression Mode removes exactly what the bake wrote and puts back the '
         'keys and values from before the bake.',
         'All names (rig, bones, constraints, Actions, bone collections, hand values) are read from the rig spec JSON you choose, so the '
         'same buttons work for any character that has such a JSON. No Text block or script in the .blend is used.'],
        ['ARKit のスライダー（52 本のスライダーの骨が、アクションの拘束で顔のコントローラーの骨を動かす作り）で動く顔のリグで、次の 2 つのモードを切り替えます。',
         '表情モード：スライダーが顔を動かします。収録や表情のプリセットは、スライダーにキーを打ちます。',
         '手付けモード：スライダーの結果を、全部のコマのキーとして顔のコントローラーの骨と手の値へ書き込み（＝焼き）、スライダーの拘束を止めます。'
         '普通のキーで顔を手で直せるようになります。',
         '「顔を手付け用に焼く」で手付けモードへ、「表情モードへ戻す」で、焼きが書いた物だけを消して、焼く前のキーと値を元へ戻します。',
         '名前（リグ・骨・拘束・アクション・骨コレクション・手の値）は、選んだ「リグの正本JSON」からすべて読みます。そのような JSON があるキャラクターなら、'
         '同じボタンで動きます。.blend の中のテキストや台本は使いません。']),
    prepare=(
        ['Save the .blend under a new name first.',
         'Set Facial Rig (above, at the top of Facial CSV Capture) to the face armature, or leave it empty to use the rig named in the JSON.',
         'Set Rig Spec JSON to the spec file of this rig (the same format as ark_reapply_spec.json).',
         'The rig must be in expression mode (its mode switch property is 1), and every constraint declared in the JSON must exist. '
         'If you are not sure, press Check Against Spec in the next group first; it must report 0 differences or only harmless ones.',
         'Leave Edit Mode of the rig. Linked or overridden rigs and Actions shared with other objects are refused.'],
        ['先に .blend を別名で保存します。',
         '「表情リグ」（「フェイシャルCSV収録」の一番上）に顔のアーマチュアを選びます。空のままなら、JSON に書いてある名前のリグを使います。',
         '「リグの正本JSON」に、このリグの正本のファイル（ark_reapply_spec.json と同じ形）を選びます。',
         'リグが表情モード（モードの切り替えのプロパティが 1）で、JSON にある拘束がすべてそろっている必要があります。'
         '分からない時は、先に次のグループの「正本と比べて検査」を押し、違いが 0 件である事を確かめます。',
         'リグの編集モードは抜けておきます。リンク・オーバーライドのリグや、ほかのオブジェクトと共有しているアクションは、守るために断ります。']),
    steps=(
        ['Choose Bake Range. Scene + Keys (recommended) bakes the scene range joined with the frames where the sliders and hand values have keys.',
         'Only with Explicit Range: set First Frame to Bake and Last Frame to Bake.',
         'Press Bake Face to Hand Keys and confirm.',
         'Read the result line (frames, channels, constraints stopped, self check in mm). The status line under the buttons changes to hand-key mode.',
         'Fix the face with ordinary keys on the face controller bones and hand values. The keying set named 顔の手付け holds exactly the baked channels.',
         'When you want the sliders back, press Return to Expression Mode and confirm.'],
        ['「焼く範囲」を選びます。「シーン＋キー」（おすすめ）は、シーンの範囲と、スライダー・手の値にキーがあるコマの範囲を合わせて焼きます。',
         '「範囲を指定」の時だけ、「焼く最初のコマ」「焼く最後のコマ」を決めます。',
         '「顔を手付け用に焼く」を押し、確認で OK を押します。',
         '結果の行（焼いたコマ・チャンネルの数・止めた拘束の数・自己確認の mm）を読みます。ボタンの下の状態の行が手付けモードに変わります。',
         '顔のコントローラーの骨と手の値に普通のキーを打って、顔を直します。名前が 顔の手付け のキーイングセットに、焼いたチャンネルがちょうど入っています。',
         'スライダーに戻したい時は「表情モードへ戻す」を押し、確認で OK を押します。']),
    settings=(
        ['Rig Spec JSON: the spec file. It is read every time you press a button; nothing from it is stored in the .blend except its SHA-256 in the bake record.',
         'Bake Range: Scene + Keys (recommended) or Explicit Range.',
         'First Frame to Bake / Last Frame to Bake: frames for Explicit Range.',
         'Allow Partial Bake (off recommended): with Explicit Range, bake even when slider keys reach outside the range. '
         'Outside the range the expressions are not baked, so they disappear there in hand-key mode.',
         'Self Check After Bake (on recommended): compares the face mesh named in the JSON before and after the bake on every 10th frame '
         'and the last frame, and shows the largest movement. Up to 0.01 mm is normal (the bake follows the constraints numerically).',
         'Bake Face to Hand Keys: writes a LINEAR key on every frame for every channel of the face controller bones the sliders move '
         '(location, rotation, scale; channels with drivers are skipped) and for the hand values. Existing keys inside the range are replaced; '
         'keys outside the range stay. It stops the slider constraints (one constraint whose slider belongs to the bone collection without '
         'the visible_only_when_live mark stays on, as the JSON declares), sets the mode switch to 0, hides the slider bone collection, shows the '
         'hand bone collection, and makes a keying set named 顔の手付け.',
         'Return to Expression Mode: removes the keys this bake wrote, puts back the keys from before the bake with every attribute '
         '(value, interpolation, easing, key type, handles), puts back values of channels that had no keys, turns on only the constraints the '
         'bake stopped, restores the mode switch, the bone collection visibility and the keying set, and deletes the backup Action and the '
         'Action it created (when nothing else was keyed into it). Before it changes anything it checks again that the rig Action, the backup '
         'and the armature are used by nothing else (other objects, NLA strips, constraints) and that the slot, the stopped constraints and '
         'the keying set are still the ones the bake made; otherwise it refuses and changes nothing.',
         'The status line under the buttons shows expression mode, hand-key mode baked by this tool, or hand-key mode not baked by this tool.'],
        ['リグの正本JSON：正本のファイルです。ボタンを押すたびに読みます。.blend に残すのは、焼いた記録の中のファイルの SHA-256 だけです。',
         '焼く範囲：「シーン＋キー」（おすすめ）か「範囲を指定」。',
         '焼く最初のコマ／焼く最後のコマ：「範囲を指定」の時のコマです。',
         '一部だけ焼くのを許す（おすすめは切）：「範囲を指定」で、スライダーのキーが範囲の外にあっても焼きます。範囲の外の表情は焼かれないので、'
         '手付けモードではそこで表情が消えます。',
         '焼いた後に自己確認（おすすめは入）：JSON にある顔のメッシュの形を、焼く前と後で 10 コマおきと最後のコマで比べ、一番大きい動きを出します。'
         '0.01 mm までは普通です（焼きは拘束の計算を数値でなぞるため）。',
         '顔を手付け用に焼く：スライダーが動かす顔のコントローラーの骨の全部のチャンネル（位置・回転・拡大。ドライバーの付いたチャンネルは除く）と手の値に、'
         '全部のコマに LINEAR のキーを打ちます。範囲の中の既にあるキーは置き換え、範囲の外のキーは残します。'
         'スライダーの拘束を止め（JSON のとおり、visible_only_when_live の印の無い骨コレクションのスライダーの拘束 1 本は動いたまま）、'
         'モードの切り替えを 0 にし、スライダーの骨コレクションを隠し、手の骨コレクションを見せ、名前が 顔の手付け のキーイングセットを作ります。',
         '表情モードへ戻す：この焼きが書いたキーを消し、焼く前のキーを全部の属性（値・補間・イージング・キーの種類・ハンドル）ごと戻し、'
         'キーの無かったチャンネルは焼く前の値へ戻し、焼きが止めた拘束だけを有効にし、モードの切り替え・骨コレクションの表示・キーイングセットを元へ戻し、'
         '控えのアクションと、焼きが作ったアクション（ほかにキーが打たれていない時）を消します。'
         '変える前に、リグのアクション・控え・アーマチュアをほか（別のオブジェクト・NLA のストリップ・拘束）が使っていないこと、'
         'スロット・止めた拘束・キーイングセットが焼いた時の物のままであることを確かめ直し、違えば断って何も変えません。',
         'ボタンの下の状態の行に、表情モード、この道具で焼いた手付けモード、この道具の焼きではない手付けモード、のどれかが出ます。']),
    verify=(
        ['Read the result line: the self check should be 0.01 mm or less.',
         'Play the animation: in hand-key mode the face moves the same as before the bake.',
         'After Return to Expression Mode, the status line says expression mode and the slider keys work again.'],
        ['結果の行を読みます。自己確認は 0.01 mm 以下のはずです。',
         '再生します。手付けモードでも、焼く前と同じに顔が動きます。',
         '「表情モードへ戻す」の後、状態の行が表情モードになり、スライダーのキーがまた効きます。']),
    undo=(
        ['Both buttons can be undone with Ctrl+Z, and both ask for confirmation first (Cancel changes nothing).',
         'If anything fails in the middle, the press stops, puts back what it changed and shows the reason: keys, values of the '
         'channels it keyed (also those that had no keys), constraints, the mode switch, bone collections and the keying set. '
         'A failed press is not a finished one: the rig stays in the mode it was in.',
         'Rare exception: when Return to Expression Mode fails in the middle, the keys, their values and which data they belong to stay as '
         'before you pressed, but the order in which the baked F-Curves are listed (for example in the Graph Editor or the Dope Sheet) can '
         'come out different. Fix the cause named in the message, then press Return to Expression Mode again; or go back with Ctrl+Z, or '
         'open the copy of the .blend you saved earlier.',
         'Keying set 顔の手付け: if one already exists before the bake, it may hold only paths on the Facial Rig itself, without '
         'whole-array paths or insert-key overrides. A path on another object, a material or a missing target makes the bake refuse '
         'and change nothing; move such paths to another keying set first. Return puts the earlier rig paths back onto the same rig. '
         'If the rig was renamed or replaced after the bake, or the bake record names any other object, Return refuses and changes nothing.',
         'Return in the scene you baked in: the keying set it puts back lives in that scene. Pressed in another scene, or after that scene '
         'was deleted, Return refuses and changes nothing.',
         'Do not rename the scene you baked in until you have returned. If it is renamed and the file is then saved and opened again '
         '(also when the rename was made before the file was first saved), the scene can only be looked up by the name it had at the bake, '
         'so Return cannot tell it apart, refuses and changes nothing. Then give the scene back that name (the refusal message shows it in '
         'quotes), switch to that scene and press Return to Expression Mode again.',
         'Do not edit the keying set 顔の手付け while in hand-key mode. If you add a path to it, remove or change one, or delete the keying '
         'set, Return refuses and changes nothing. Keep your own paths in another keying set. To recover, go back with Ctrl+Z to before the '
         'edit, or open the copy of the .blend you saved before the edit, then press Return to Expression Mode.',
         'Hand fixes made in hand-key mode inside the baked range are removed by Return to Expression Mode (that range goes back to the keys from before the bake). '
         'Keep a copy of the .blend if you want to keep them.',
         'Bake again or return again is refused when the rig is already in that mode. A bake made by another tool (for example an older script) is not touched.',
         'Limits: only Action constraints with a local location slider, BEFORE_SPLIT mixing, influence 1 and the rig as target can be baked. '
         'Hand values are baked from simple driver expressions (+ - * / min max abs) of the JSON. At most 100,000 frames.'],
        ['どちらのボタンも Ctrl+Z で戻せます。押した時に確認が出ます（キャンセルなら何も変わりません）。',
         '途中で失敗した時は、そこで止め、その回に変えた物を元へ戻して、理由を出します。キー、キーを打ったチャンネルの値（キーの無かったチャンネルも）、'
         '拘束、モードの切り替え、骨コレクション、キーイングセットが元に戻ります。失敗は完了ではありません。リグは押す前のモードのままです。',
         'まれな例外：「表情モードへ戻す」が途中で失敗した時は、キーとその値、どのデータの持ち物かは押す前のままですが、'
         '焼いた Fカーブ の並ぶ順番（グラフエディターやドープシートでの並び）が押す前と変わることがあります。'
         '出た文にある原因を直してから、もう一度「表情モードへ戻す」を押します。または Ctrl+Z で戻すか、前に保存しておいた .blend の写しを開きます。',
         'キーイングセット 顔の手付け：焼く前に既にある時は、表情リグそのものの道だけを入れておけます（配列まるごとの道・キー挿入の上書きは不可）。'
         'ほかのオブジェクト・マテリアル・対象の無い道があると、焼きは断って何も変えません。その道は先に別のキーイングセットへ移します。'
         '「表情モードへ戻す」は、焼く前のリグの道を同じリグへ戻します。焼いた後にリグの名前を変えたり別のリグに替えたりした時や、'
         '焼いた記録がリグ以外のオブジェクトを指している時は、断って何も変えません。',
         '焼いたシーンで戻します（戻すキーイングセットはそのシーンにあります）。別のシーンで押した時や、焼いたシーンを消した後は、断って何も変えません。',
         '焼いたシーンの名前は、戻すまで変えないでください。名前を変えてからファイルを保存して開き直すと（初めて保存する前に変えた時も同じです）、'
         'そのシーンは焼いた時の名前でしか探せないので見分けられず、「表情モードへ戻す」は断って何も変えません。'
         'その時は、シーンの名前を焼いた時の名前（断りの文の「」の中に出ます）に戻し、そのシーンへ切り替えてから、もう一度「表情モードへ戻す」を押します。',
         'キーイングセット 顔の手付け は、手付けモードの間は変えないでください。道を足す・消す・書き換える、またはキーイングセットを消すと、'
         '「表情モードへ戻す」は断って何も変えません。自分の道は別のキーイングセットに入れます。'
         'そうなった時は、Ctrl+Z で変える前まで戻すか、変える前に保存しておいた .blend の写しを開いてから、「表情モードへ戻す」を押します。',
         '手付けモードで焼いた範囲の中に打った手直しは、「表情モードへ戻す」で消えます（その範囲は焼く前のキーに戻ります）。残したい時は .blend の写しを取っておきます。',
         '既にそのモードの時に、もう一度焼く・もう一度戻すは断ります。別の道具（例えば前の台本）が作った焼きには触りません。',
         '限界：焼けるのは、ローカルの位置のスライダー・BEFORE_SPLIT の混ぜ方・影響 1・的がリグ、のアクションの拘束だけです。'
         '手の値は、JSON のドライバーの単純な式（+ - * / min max abs）から焼きます。10 万コマまでです。']),
)

HELP_DATA['facial_ark_reapply'] = _e(
    ('ARKit rig: check / reapply', 'ARKitリグの検査と当て直し'),
    purpose=(
        ['Compares the three layers of the ARKit rig (slider bones -> Action constraints -> face controller bones, and the Actions they use) '
         'with the rig spec JSON, and puts them back when another tool (for example a rig update) removed or changed them.',
         'Check Against Spec only lists differences and changes nothing. Reapply From Spec adds what is missing and corrects what differs, '
         'including the order in each bone\'s constraint stack.'],
        ['ARKit のリグの 3 層（スライダーの骨 → アクションの拘束 → 顔のコントローラーの骨、とそれが使うアクション）を「リグの正本JSON」と比べ、'
         'ほかの道具（例えばリグの更新）が消したり変えたりした時に元へ戻します。',
         '「正本と比べて検査」は違いを並べるだけで、何も変えません。「正本から当て直す」は、足りない物を足し、違う物を直します。骨ごとの拘束の並びも直します。']),
    prepare=(
        ['Choose Rig Spec JSON in the group above, and Facial Rig if the rig is not named as in the JSON.',
         'Save the .blend under a new name before reapplying.'],
        ['上のグループで「リグの正本JSON」を選びます。リグの名前が JSON と同じでない時は「表情リグ」も選びます（名前は JSON と同じである必要があります）。',
         '当て直す前に .blend を別名で保存します。']),
    steps=(
        ['Press Check Against Spec. Each difference is listed in the Info editor / status bar, and the count is shown below the buttons.',
         'If the count is not 0 and you want the rig as the JSON says, press Reapply From Spec and confirm.',
         'Press Check Against Spec again: it must say 0 differences.'],
        ['「正本と比べて検査」を押します。違いが 1 件ずつ情報エディター・ステータスバーに出て、件数がボタンの下に出ます。',
         '件数が 0 でなく、JSON のとおりにしたい時は「正本から当て直す」を押し、確認で OK を押します。',
         'もう一度「正本と比べて検査」を押し、違いが 0 件になった事を確かめます。']),
    settings=(
        ['Check Against Spec: reads the JSON, checks it strictly (unknown keys, missing names, duplicate names, constraints that point to Actions '
         'not in the JSON are refused), checks the scene (bones and targets exist, no constraint of another type with the same name, Actions '
         'not linked and not used by anything outside the declared constraints), then lists every Action and constraint value that differs. '
         'Values are compared exactly (no tolerance).',
         'Reapply From Spec: same checks, then: rewrites differing Actions (the slot is kept so constraints stay connected), creates missing '
         'Actions and constraints, sets every declared constraint value, and moves constraints to their declared position. Constraints that are '
         'not in the JSON are never removed or changed.',
         'In hand-key mode (after a bake) the on/off state of the declared constraints is not checked, so the bake is not undone.'],
        ['正本と比べて検査：JSON を読み、厳しく確かめ（知らないキー・無い名前・同じ名前の重なり・JSON に無いアクションを指す拘束は断ります）、'
         'シーンを確かめ（骨と的がある、同じ名前の別の種類の拘束が無い、アクションがリンクでなく、正本の拘束の外で使われていない）、'
         '違うアクションと拘束の値をすべて並べます。値はそのまま比べます（許す差はありません）。',
         '正本から当て直す：同じ確かめの後、違うアクションを書き直し（スロットは保つので、拘束のつながりは切れません）、無いアクションと拘束を作り、'
         '正本の拘束の値をすべて合わせ、拘束を正本の位置へ並べ直します。JSON に無い拘束は消しも変えもしません。',
         '手付けモード（焼いた後）では、正本の拘束の有効・無効は見ません（焼きを壊さないため）。']),
    verify=(
        ['After Reapply From Spec, Check Against Spec reports 0 differences, and pressing Reapply From Spec again reports 0 changes.',
         'Move a slider in expression mode and check the face moves.'],
        ['「正本から当て直す」の後、「正本と比べて検査」が違い 0 件、もう一度「正本から当て直す」を押しても変更 0 件になります。',
         '表情モードでスライダーを動かし、顔が動く事を確かめます。']),
    undo=(
        ['Reapply From Spec can be undone with Ctrl+Z and asks for confirmation first. If anything fails in the middle, every change of that press is rolled back.',
         'If the reapply fails or is refused, nothing is lost: every curve, key and group is put back exactly as it was. Before anything '
         'changes, every curve of the Actions to be rewritten is copied and compared; if one cannot be copied exactly, the reapply is refused '
         'with nothing changed, and the message names the Action and curve. Remove or apply that setting on the named curve in the Graph '
         'Editor, then press Reapply From Spec again.',
         'If the reapply succeeds, each rewritten Action is rebuilt from the JSON. The keys of every curve in the JSON are made again from the '
         'JSON (frame, value, interpolation), so hand-made key settings (handle positions and types, easing, key type) are not kept and go '
         'back to the defaults, and the extrapolation is set from the JSON. The other settings of a curve in the JSON (modifiers, mute, lock, '
         'hide, color, smoothing) and the settings of a group in the JSON (color, mute, lock) are kept. A curve made of sampled points is made '
         'again from scratch, so its modifiers, mute and other settings are not kept. Curves and groups that are not in the JSON, including '
         'empty groups, are deleted.',
         'If these Actions hold hand-made keys or curve settings you need, save a copy of the .blend under another name before reapplying. '
         'You can open that copy, or append from it, to get them back.',
         'Check Against Spec changes nothing, so there is nothing to undo.',
         'Limits: only the Actions and Action constraints of the JSON are handled here. Other parts of the JSON (bones, bone collections, '
         'drivers, other constraints, shape keys) are not changed by these buttons. An Action with another slot or layer layout is refused instead of being replaced.'],
        ['「正本から当て直す」は Ctrl+Z で戻せます。押した時に確認が出ます。途中で失敗した時は、その回に変えた物をすべて元へ戻します。',
         '当て直しが失敗した時や断った時は、何も失いません。F カーブ・キー・グループをすべて元のとおりに戻します。何かを変える前に、'
         '書き直すアクションの F カーブをすべて写して比べ、そのまま写せない物が 1 つでもあれば当て直しを断り、何も変えません。'
         'メッセージにアクションと F カーブの名前が出ます。グラフエディターでその F カーブの設定を外すか適用してから、もう一度「正本から当て直す」を押します。',
         '当て直しが成功した時は、書き直したアクションを JSON から作り直します。JSON にある F カーブのキーは JSON の値（フレーム・値・補間）で'
         '打ち直すので、手で付けたキーの設定（ハンドルの位置と種類・イージング・キーの種類など）は残らず、既定の値に戻ります。外挿も JSON の値になります。'
         'JSON にある F カーブのほかの設定（モディファイアー・ミュート・ロック・非表示・色・スムージング）と、JSON にあるグループの設定（色・ミュート・ロック）は残ります。'
         'ただし、サンプル点でできた F カーブは一から作り直すので、モディファイアー・ミュートなどの設定は残りません。'
         'JSON に無い F カーブとグループ（空のグループも）は消えます。',
         '大事な手付けのキーや F カーブの設定がある時は、当て直す前に .blend の写しを別名で保存します。あとでその写しを開くか、写しからアペンドして取り戻せます。',
         '「正本と比べて検査」は何も変えないので、戻す物はありません。',
         '限界：ここで扱うのは JSON のアクションとアクションの拘束だけです。JSON のほかの部分（骨・骨コレクション・ドライバー・ほかの拘束・シェイプキー）は、このボタンでは変えません。'
         'スロットや層の形が違うアクションは、置き換えずに断ります。']),
)

HELP_DATA['facial_material'] = _e(
    ('Material color correction', '材質の色補正'),
    purpose=(
        ['Copies the material of one selected mesh and corrects it: replaces an image texture with a flat correction color, or weakens a rim light. '
         'The original shared material is kept unchanged.'],
        ['選んだ 1 つのメッシュの材質を複製して直します。画像テクスチャを一色の補正色に置き換えたり、リムの光を弱めたりします。元の共有の材質はそのまま残ります。']),
    prepare=(
        ['Object Mode. Select exactly one mesh and make it active. Its active material slot must be linked to the mesh data and use nodes.'],
        ['オブジェクトモードにします。補正するメッシュを 1 つだけ選び、アクティブにします。アクティブな材質スロットがメッシュ側にあり、ノードを使う材質である必要があります。']),
    steps=(
        ['Pick Image Node to Replace and set Correction Color (Linear RGBA).',
         'Press Copy Material and Correct Color.',
         'For a rim light, pick Rim Mix or Emission Node, set Rim Multiplier and press Adjust Selected Material Rim.',
         'To go back, press Restore Original Shared Material.'],
        ['「置き換える画像ノード」を選び、「補正色（線形RGBA）」を決めます。',
         '「選択部品の材質を複製して色補正」を押します。',
         'リムの光を弱める時は「リム合成／発光ノード」を選び、「リムの倍率」を決めて「選択材質のリムを調整」を押します。',
         '戻す時は「選択部品を元の共有材質へ戻す」を押します。']),
    settings=(
        ['Image Node to Replace: an Image Texture node whose Color / Alpha outputs are connected. Empty at first: pick it from the list.',
         'Correction Color (Linear RGBA): the flat color used instead of the image (0 to 1 each).',
         'Copy Material and Correct Color: makes a copy named "…_SS_Facial_Color" for this mesh and reconnects those outputs to the color.',
         'Rim Mix or Emission Node: a MixRGB node (its factor) or an Emission node (its strength). Empty at first: pick it from the list.',
         'Rim Multiplier: multiplies the rim input (0 to 1). Default 0.5.',
         'Restore Original Shared Material: puts the original shared material back on the slot.'],
        ['置き換える画像ノード：Color / Alpha の出力がつながった画像テクスチャのノードです。最初は空なので、一覧から選びます。',
         '補正色（線形RGBA）：画像の代わりに使う一色です（各 0〜1）。',
         '選択部品の材質を複製して色補正：このメッシュ用に「…_SS_Facial_Color」という写しを作り、その出力を補正色へつなぎ替えます。',
         'リム合成／発光ノード：MixRGB のノード（その係数）か Emission のノード（その強さ）です。最初は空なので、一覧から選びます。',
         'リムの倍率：リムの入力に掛ける倍率です（0〜1）。既定 0.5。',
         '選択部品を元の共有材質へ戻す：スロットに元の共有の材質を戻します。']),
    verify=(
        ['The result line names the corrected material. Check it in Material Preview.'],
        ['結果の行に、直した材質の名前が出ます。マテリアルプレビューで見て確かめます。']),
    undo=(
        ['Restore Original Shared Material or Ctrl+Z.',
         'If the corrected copy or the original was edited by hand, restoring is refused to protect it. Restore before choosing another color or another rim node.'],
        ['「選択部品を元の共有材質へ戻す」か Ctrl+Z で戻せます。',
         '直した写しか元の材質を手で編集していると、守るために戻すのを断ります。別の色や別のリムのノードに替える前に、一度元へ戻します。']),
)

# ---------------------------------------------------------------------------
# Build Calibration Table / Capture Inspection
# ---------------------------------------------------------------------------
HELP_DATA['facial_calibration_build'] = _e(
    ('Build Calibration Table', '校正表を作る'),
    purpose=(
        ['Makes a per-channel calibration table (neutral, max and knots for each ARKit channel) from the values of several recorded captures (RAW CSV files).',
         'The result is a JSON table in the same format that "Load Calibration" reads, so it can be used for the import as it is.',
         'The table is decided by written rules (A, C, D, E, F and the optional G, see "Rules (fixed values)"). The same captures and the same settings always give the same table.',
         'A second file with the same name plus _report.json is written next to the table. For every channel it records which rule was used, the counted percentiles, the share of sticking frames after calibration and the neutral residual.'],
        ['何本もの収録（ARKit の 51 か 52 の係数の、RAW の CSV）の値の分布から、係数ごとの校正表（係数ごとの neutral・max・折れ点 knots）を作ります。',
         '出来るのは「校正表を読む」で読むのと同じ形の JSON の表なので、そのまま取り込みに使えます。',
         '表の決め方は、文書にした決まり（A・C・D・E・F と、使う時だけの G。「決め方（決まりの値）」を見てください）です。同じ収録と同じ設定なら、いつも同じ表になります。',
         '表の隣に、同じ名前の後ろに _report を付けた JSON も書きます。係数ごとに、当てた決まり・数えた分位点・校正した後に 1.0 に張り付くコマの割合・真顔の残り値が入ります。']),
    prepare=(
        ['Capture CSV files with a time_seconds column and ARKit-named columns, holding the recorded RAW values (up to 20 MiB each, up to 64 files). Every capture must have the same channels.',
         'Optional: the table you use now. Channels that no rule changes are copied from it unchanged. Without it, every row starts from percentiles of the captures.',
         'Optional: targeted maxima, the largest value of each channel while that expression was performed on purpose. A segment table JSON, a JSON of channel and value, or a CSV of only the targeted expressions.',
         'Optional: gaze caps. If you measured on the rig how far the iris stays visible for each eyeLook amount, keep that sweep JSON ready.',
         'Decide where the neutral (straight face) part of the captures is, in seconds.'],
        ['time_seconds の列と ARKit 名の列がある、収録のままの RAW の値の CSV を用意します（1 本 20 MiB まで、64 本まで）。全部の収録に同じ係数の列が要ります。',
         '任意：今使っている校正表。どの決まりにも当たらない係数は、この表の行をそのまま写します。無い時は、全部の行を収録の分位点から作ります。',
         '任意：狙った表情の最大（その表情をわざと作った時の、係数ごとの一番大きな値）。区間表の JSON、係数と値だけの JSON、または狙った表情だけを集めた CSV のどれかです。',
         '任意：視線の頭打ち。リグで、eyeLook の量ごとに黒目がどこまで見えるかを測った掃引の JSON があれば用意します。',
         '収録のどこ（何秒から何秒）が真顔かを決めておきます。']),
    steps=(
        ['Press "Add Captures" (the + button) and choose the CSV files; several can be chosen at once. "Remove Capture" (the - button) removes the selected one, "Remove All" (the bin button) clears the list.',
         'Press "Count Distribution". The line below shows how many captures and frames were counted.',
         'Choose "Previous Table (Optional)" and "Targeted Maxima (Optional)" with their folder buttons, or leave them empty.',
         'Open "Rules (fixed values)", press "v5 Rules" or "v4 Rules" to put in the documented values, then change values only where you have a reason.',
         'Check "Use the New Table for Import", press "Build Calibration Table" and give a new file name.',
         'Read the result line, then open the _report.json and look at the channels marked STICK or NEUTRAL_RESIDUAL.'],
        ['「収録を足す」（＋ の印）を押し、CSV を選びます。一度に何本でも選べます。「収録を外す」（－ の印）は選んでいる 1 本を、「全部外す」（ごみ箱の印）は一覧を空にします。',
         '「分布を数える」を押します。下の行に、数えた収録の本数とコマ数が出ます。',
         '「前の表（任意）」と「狙った表情の最大（任意）」を、右のフォルダの印から選びます。使わない時は空のままにします。',
         '「決め方（決まりの値）」を開き、「v5 の決め方」か「v4 の決め方」を押して文書の値を入れます。理由がある所だけ値を変えます。',
         '「作った表を取り込みに使う」を確かめてから「校正表を作る」を押し、新しいファイル名を付けます。',
         '結果の行を読み、_report.json を開いて、STICK（張り付き）か NEUTRAL_RESIDUAL（真顔に残る）の印が付いた係数を確かめます。']),
    settings=(
        ['The capture list shows the captures that are counted. The number on the right of a row is its frame count (after "Count Distribution").',
         'Add Captures / Remove Capture / Remove All: change the list only; the files are never touched.',
         'Count Distribution: reads every listed capture and counts its frames. Nothing is written.',
         'Previous Table (Optional): a calibration JSON or CSV. Rules A, C and D keep its neutral, and rows that no rule touches are copied from it. Recommended: the table you use now.',
         'Targeted Maxima (Optional): a segment table JSON (the largest value per channel over its segments), a JSON of channel and value, or a CSV (its largest value per channel).',
         'Use the New Table for Import: when on, the new table is put into the import calibration slot, exactly as "Load Calibration" does. Recommended: on.',
         'Build Calibration Table: writes the new table JSON and the _report.json. An existing file name is refused, so nothing is overwritten.'],
        ['収録の一覧には、数える収録が並びます。行の右の数字は、「分布を数える」の後に出るコマ数です。',
         '収録を足す / 収録を外す / 全部外す：一覧を変えるだけで、ファイルには触りません。',
         '分布を数える：一覧の収録を全部読み、コマ数を数えます。何も書きません。',
         '前の表（任意）：校正表の JSON か CSV です。決まり A・C・D は、この表の neutral を使います。どの決まりにも当たらない係数の行は、この表から写します。おすすめ：今使っている表。',
         '狙った表情の最大（任意）：区間表の JSON（区間をまたいだ係数ごとの一番大きな値）、係数と値だけの JSON、または CSV（係数ごとの一番大きな値）です。',
         '作った表を取り込みに使う：オンだと、作った表を「校正表を読む」と同じように、取り込みの校正表の欄へ入れます。おすすめ：オン。',
         '校正表を作る：新しい表の JSON と _report.json を書きます。既にある名前は断るので、上書きはしません。']),
    verify=(
        ['The result line shows the channel count, how many rows changed, how many channels stick and how many keep a value on the straight face.',
         'Under "Calibration (EDIT only)" the line "count / file name" now names the new table, so the next import uses it.',
         'Use "Capture Inspection" to see whether EDIT sticks at 1.0 or stays above 0 on the straight face with the new table.',
         'Finally look at the face. Tidy numbers do not prove the face looks right.'],
        ['結果の行に、係数の数・変えた行の数・張り付く係数の数・真顔に値が残る係数の数が出ます。',
         '「校正（EDITだけ）」の下の「係数の数 / ファイル名」の行が、作った表の名前になります。次の取り込みからこの表が使われます。',
         '「取り込みの点検」で、作った表で EDIT が 1.0 に張り付かないか、真顔で 0 より上に残らないかを見ます。',
         '最後は顔を目で見て確かめます。数値が整っても、見た目の合格ではありません。']),
    undo=(
        ['The new table stays as a file. To go back, load the previous table again with "Load Calibration".',
         'Limits: a calibration table maps each channel on its own (a straight line plus knots). Combinations of two channels, such as looking up and in at once, cannot be limited by a table.',
         'Channels the tracker never outputs (a column that stays 0, such as tongue or cheek puff) get a row, but it has no meaning.',
         'The default rule values were decided and checked on 11 captures (3,365 frames) of one performer and one tracker. Whether they give a good table for another performer, tracker or face is not checked.'],
        ['作った表はファイルとして残ります。前の表へ戻す時は、「校正表を読む」で前の表を読み直します。',
         '限界：校正表は係数を 1 本ずつ直線（と折れ点）で直す物です。2 つの係数の組み合わせ（例：上と内を同時に見る視線）は、表では抑えられません。',
         '追跡器が出さない係数（ずっと 0 の列。舌・頬ふくらみなど）にも行は出来ますが、意味はありません。',
         '決まりの既定の値は、1 人の演者・1 つの追跡器の 11 本の収録（3,365 コマ）で決めて確かめた値です。別の演者・追跡器・顔で良い表になる事は確かめていません。']),
)

HELP_DATA['facial_calibration_rules'] = _e(
    ('Rules (fixed values)', '決め方（決まりの値）'),
    purpose=(
        ['Holds every value the rules use. "Build Calibration Table" reads them; nothing is guessed or tuned automatically.',
         'Percentile p means the value at position int(p / 100 x (frames - 1)) after sorting all frames of all listed captures (no interpolation), rounded to "Percentile Rounding Digits".',
         'Rule A (jawOpen): neutral from the previous table, max = targeted maximum, knots [0,0] [knot 1] [knot 2] [1,1]. Without a targeted maximum the row is kept.',
         'Rules C and D (narrow rows): when the previous max - neutral is below "Narrow Span Below": with a targeted maximum of at least "Target Needed for Rule D" the max becomes that maximum (D); otherwise max = neutral + "Minimum Span" (C), so tiny noise is not stretched to 1.',
         'Rule E (the 8 eyeLook channels): neutral = "Gaze Neutral Percentile", max = the largest of the previous max, the targeted maximum and "Gaze Maximum Percentile". A cap below 1 adds the knots [0,0] [1,cap].',
         'Rule F (5 brow channels): browDown neutral = "Brow Down Neutral Percentile", browInnerUp / browOuterUp neutral = "Brow Raise Neutral Percentile", max = "Brow Maximum Percentile".',
         'Rule G (optional): after A to F, a channel whose calibrated share at or above "Stick Line" is larger than "Stick Share Limit" gets its max widened to the percentile 100 - 100 x limit.',
         'Every other row is copied from the previous table unchanged.'],
        ['決まりが使う値を全部ここに置きます。「校正表を作る」はこの値を読むだけで、勝手に推測したり値を回したりしません。',
         '分位点 p は、一覧の全部の収録の全部のコマを小さい順に並べ、int(p ÷ 100 × (コマ数 − 1)) 番目にある値です（間を補わない）。「分位点の丸めの桁」の桁で丸めます。',
         '決まり A（jawOpen）：neutral は前の表のまま、max は狙った表情の最大、knots は [0,0]・折れ点1・折れ点2・[1,1]。狙った表情の最大が無い時は行を変えません。',
         '決まり C・D（幅の狭い行）：前の表の max − neutral が「幅が狭いとみなす線」より小さい時、狙った表情の最大が「決まりDに要る狙った最大」以上ならその値を max にします（D）。そうでなければ max ＝ neutral ＋「幅の下限」にします（C）。ほぼ 0 の揺れを 1 まで引き伸ばさないためです。',
         '決まり E（eyeLook の 8 本）：neutral は「視線のneutralの分位点」、max は前の表の max・狙った表情の最大・「視線のmaxの分位点」の一番大きな値です。頭打ちが 1 より小さい時は knots [0,0]・[1,頭打ち] を足します。',
         '決まり F（眉の 5 本）：browDown の neutral は「眉下げのneutralの分位点」、browInnerUp・browOuterUp の neutral は「眉上げのneutralの分位点」、max は「眉のmaxの分位点」です。',
         '決まり G（使う時だけ）：A〜F の後、校正した値が「張り付きとみなす値」以上のコマの割合が「張り付きの割合の上限」より大きい係数は、max を 100 − 100 × 上限 の分位点まで広げます。',
         'ほかの行は前の表のまま写します。']),
    prepare=(
        ['Add the captures and press "Count Distribution" first. Decide whether you use a previous table and targeted maxima.'],
        ['先に収録を足し、「分布を数える」を押します。前の表と狙った表情の最大を使うかを決めます。']),
    steps=(
        ['Press "v5 Rules" (recommended, the newest documented rules) or "v4 Rules". Gaze caps, files and the neutral segment are not changed by these buttons.',
         'If you have a visibility sweep, check "Visible Share Needed" and press the import button on its right ("Read Gaze Caps from Sweep"). Otherwise type the caps, or leave them at 1.',
         'Set the neutral segment: "Neutral Capture (0 = All)", "Neutral From (Seconds)" and "Neutral To (Seconds)".',
         'Change other values only with a reason, then press "Build Calibration Table".'],
        ['「v5 の決め方」（おすすめ。いちばん新しい文書の決まり）か「v4 の決め方」を押します。このボタンは、視線の頭打ち・ファイル・真顔の区間を変えません。',
         '黒目の見え方の掃引があれば、「見える割合の下限」を確かめ、その右の読み込みの印（「掃引のJSONから視線の頭打ちを読む」）を押して掃引の JSON を選びます。無ければ頭打ちを手で入れるか、1 のままにします。',
         '真顔の区間を「真顔の区間の収録番号（0は全部）」「真顔の始まり（秒）」「真顔の終わり（秒）」で決めます。',
         'ほかの値は理由がある時だけ変えて、「校正表を作る」を押します。']),
    settings=(
        ['v5 Rules / v4 Rules: v4 = rules A, C, D, E, F of calibration v4. v5 = the same with "Brow Raise Neutral Percentile" 75 instead of 50. Both: rounding 5 digits, knots 0.1 to 0.1 and 0.3 to 0.42, narrow span 0.12, target 0.15, minimum span 0.25, gaze 75 / 99.5, brow down 50, brow max 99.',
         'Percentile Rounding Digits: decimals kept for every percentile (default 5).',
         'Rule A: jawOpen: turns rule A on. Off: jawOpen is treated like the other rows (rules C and D).',
         'jawOpen Knot 1 In / jawOpen Knot 1 Out / jawOpen Knot 2 In / jawOpen Knot 2 Out: the two middle knots of jawOpen (defaults 0.1, 0.1, 0.3, 0.42: up to 0.1 unchanged, 0.1 to 0.3 lifted). Need 0 < in 1 < in 2 < 1 and out 1 <= out 2.',
         'Narrow Span Below / Target Needed for Rule D / Minimum Span: the three values of rules C and D (0.12 / 0.15 / 0.25).',
         'Gaze Neutral Percentile / Gaze Maximum Percentile: rule E (75 / 99.5).',
         'eyeLookDownLeft Cap / eyeLookInLeft Cap / eyeLookOutLeft Cap / eyeLookUpLeft Cap / eyeLookDownRight Cap / eyeLookInRight Cap / eyeLookOutRight Cap / eyeLookUpRight Cap: the largest calibrated value of each eyeLook channel (1 = no cap). Use a cap when the iris hides behind the lids at large values on your rig.',
         'Visible Share Needed: for the sweep import; the cap becomes the upper end of the run from 0 where the visible share stays at or above this value (default 0.55).',
         'Brow Down Neutral Percentile / Brow Raise Neutral Percentile / Brow Maximum Percentile: rule F (50 / 75 for v5, 50 for v4 / 99).',
         'No-Table Neutral Percentile / No-Table Max Percentile: the starting row when there is no previous table (50 / 99.5). This start is an assumption, not a measured recommendation.',
         'Gaze/Brow Neutral from Segment: when on, rules E and F count their neutral percentile only inside the neutral segment instead of all frames. Default off.',
         'Neutral Capture (0 = All) / Neutral From (Seconds) / Neutral To (Seconds): the neutral segment, in seconds from the first sample of the chosen capture (number in the list, 0 = every capture). Also used for the neutral residual in the report.',
         'Rule G: Widen Sticking Channels: turns rule G on (default off; v4 and v5 do not use it).',
         'Stick Line / Stick Share Limit: a frame at or above the line counts as sticking (0.99); a channel sticking in more than the limit (0.01 = 1%) is marked STICK.',
         'Neutral Residual Line: a channel whose calibrated value inside the neutral segment goes above this (0.1) is marked NEUTRAL_RESIDUAL.'],
        ['v5 の決め方 / v4 の決め方：v4 は校正表 v4 の決まり A・C・D・E・F です。v5 はそれの「眉上げのneutralの分位点」を 50 から 75 にした物です。どちらも、丸め 5 桁、折れ点 0.1→0.1 と 0.3→0.42、幅が狭い線 0.12、狙った最大 0.15、幅の下限 0.25、視線 75 と 99.5、眉下げ 50、眉の max 99 です。',
         '分位点の丸めの桁：分位点を小数第何桁まで残すかです（既定 5）。',
         '決まりA：jawOpen：決まり A の入切です。切ると jawOpen もほかの行と同じ扱い（決まり C・D）になります。',
         'jawOpen 折れ点1の入力 / jawOpen 折れ点1の出力 / jawOpen 折れ点2の入力 / jawOpen 折れ点2の出力：jawOpen の真ん中の 2 つの折れ点です（既定 0.1・0.1・0.3・0.42。0.1 まではそのまま、0.1〜0.3 を持ち上げる）。0 < 入力1 < 入力2 < 1、出力1 ≦ 出力2 にします。',
         '幅が狭いとみなす線 / 決まりDに要る狙った最大 / 幅の下限：決まり C・D の 3 つの値です（0.12・0.15・0.25）。',
         '視線のneutralの分位点 / 視線のmaxの分位点：決まり E です（75・99.5）。',
         'eyeLookDownLeftの頭打ち / eyeLookInLeftの頭打ち / eyeLookOutLeftの頭打ち / eyeLookUpLeftの頭打ち / eyeLookDownRightの頭打ち / eyeLookInRightの頭打ち / eyeLookOutRightの頭打ち / eyeLookUpRightの頭打ち：eyeLook の係数ごとの、校正した値の一番上です（1 は頭打ちなし）。大きな値で黒目が瞼に隠れるリグの時に使います。',
         '見える割合の下限：掃引の読み込み用です。0 から続けて、見える割合がこの値以上の所の上の端が頭打ちになります（既定 0.55）。',
         '眉下げのneutralの分位点 / 眉上げのneutralの分位点 / 眉のmaxの分位点：決まり F です（50、v5 は 75・v4 は 50、99）。',
         '表が無い時のneutralの分位点 / 表が無い時のmaxの分位点：表が無い時の出発の行です（50・99.5）。この出発点は仮の決めで、測って勧める値ではありません。',
         '視線と眉のneutralを真顔から：オンだと、決まり E・F の neutral の分位点を、全部のコマではなく真顔の区間の中だけで数えます。既定はオフ。',
         '真顔の区間の収録番号（0は全部） / 真顔の始まり（秒） / 真顔の終わり（秒）：真顔の区間です。選んだ収録（一覧の番号、0 は全部の収録）の最初の標本からの秒数です。_report.json の真顔の残り値にも使います。',
         '決まりG：張り付く係数の幅を広げる：決まり G の入切です（既定はオフ。v4・v5 は使いません）。',
         '張り付きとみなす値 / 張り付きの割合の上限：この値以上のコマを張り付きと数えます（0.99）。張り付きの割合が上限（0.01＝1%）より大きい係数に STICK の印を付けます。',
         '真顔の残り値の線：真顔の区間で校正した値がこれより上に出る係数に NEUTRAL_RESIDUAL の印を付けます（0.1）。']),
    verify=(
        ['After building, the _report.json lists the rules and every value used (rules block) together with the inputs and their SHA-256, so the same table can be made again.'],
        ['作った後の _report.json に、使った決まりの値（rules の欄）と、入力のファイルとその SHA-256 が全部入ります。同じ表をもう一度作れます。']),
    undo=(
        ['Press "v5 Rules" or "v4 Rules" to return to the documented values. Changing a value here does not change a table that was already written.',
         'The defaults were decided for one performer (11 captures). They are a starting point; check the face after every change.'],
        ['「v5 の決め方」か「v4 の決め方」を押すと、文書の値へ戻ります。ここで値を変えても、既に書いた表は変わりません。',
         '既定の値は、1 人の演者（11 本の収録）で決めた物です。出発点として使い、変えるたびに顔を目で見て確かめます。']),
)

HELP_DATA['facial_capture_inspection'] = _e(
    ('Capture Inspection', '取り込みの点検'),
    purpose=(
        ['Lists, for every channel of a capture, what the import receives (RAW) and what EDIT becomes with the current settings: how far it reaches, how often it sticks at 1.0, where its peak is and what stays on the straight face.',
         'Use it before or after an import to find weak channels, channels that stick and the frames of the targeted expressions.'],
        ['収録の係数ごとに、取り込みが受け取る値（RAW）と、今の設定で EDIT になる値を一覧にします。どこまで届くか、どれだけ 1.0 に張り付くか、山（一番大きな値）はどこか、真顔に何が残るかを見ます。',
         '取り込みの前か後に、届かない係数・張り付く係数・狙った表情の山のコマを見つけるのに使います。']),
    prepare=(
        ['Set "Capture Destination", the calibration ("Calibration (EDIT only)") and, for Shape Keys, the strengths first. EDIT is computed with exactly these settings, the same way the import computes it.',
         'Choose the capture in "Capture to Inspect". When it is empty, the last imported CSV is used.'],
        ['先に「取り込み先」、校正（「校正（EDITだけ）」）、シェイプキーの時は強さを決めます。EDIT は、取り込みと同じ計算で、この設定のまま求めます。',
         '「点検する収録のCSV」で収録を選びます。空の時は、最後に取り込んだ CSV を使います。']),
    steps=(
        ['Choose "Capture to Inspect", and check "Source Timecode FPS" and the units (same as for the import).',
         'Set the neutral part with "Check Neutral From (s)" and "Check Neutral To (s)".',
         'Press "Inspect Capture". The result line shows the counts of sticking, weak and neutral residual channels.',
         'Read the list. Select a channel and press "Go to Peak Frame" to jump to its RAW peak.',
         'Press JSON or CSV to write the full table to a new file.'],
        ['「点検する収録のCSV」を選び、「タイムコードのフレーム基数」と係数の単位を確かめます（取り込みと同じにします）。',
         '「点検の真顔の始まり（秒）」と「点検の真顔の終わり（秒）」で真顔の部分を決めます。',
         '「点検する」を押します。結果の行に、張り付き・届かない・真顔に残る係数の数が出ます。',
         '一覧を読みます。係数を選んで「山のコマへ移る」を押すと、その RAW の山のコマへ移ります。',
         'JSON か CSV を押すと、全部の列の表を新しいファイルへ書きます。']),
    settings=(
        ['Capture to Inspect: the CSV to inspect (up to 20 MiB). Empty = the last imported CSV.',
         'Source Timecode FPS / Coefficient Units: read the CSV as the import does (60, 0 to 1).',
         'Check Neutral From (s) / Check Neutral To (s): the straight-face part, in seconds from the first sample (default 0 to 1).',
         'Reach Line: a channel whose EDIT maximum stays below this is marked weak (default 0.3).',
         'Stick Line / Stick Share Limit: a sample at or above the line counts as sticking (0.99); more than the limit (0.01 = 1%) marks the channel.',
         'Neutral Residual Line: an EDIT value above this inside the neutral part marks the channel (0.1).',
         'Peak Jump Start Frame (Shape Keys only): the start frame you used for the import. For bones the capture settings Start Frame and Frame Offset are used.',
         'The list columns are channel, RAW max > EDIT max, EDIT stick share, peak row (0-based CSV row of the RAW maximum), EDIT maximum on the straight face. A warning mark means the channel has a flag.',
         'The exported table also has min, p50 / p95 / p99 (linear between ranks), share at or above 0.5, peak time and the neutral mean, for RAW and EDIT.'],
        ['点検する収録のCSV：点検する CSV です（20 MiB まで）。空なら最後に取り込んだ CSV です。',
         'タイムコードのフレーム基数 / 係数の単位：取り込みと同じ読み方です（60、0〜1）。',
         '点検の真顔の始まり（秒） / 点検の真顔の終わり（秒）：真顔の部分です。最初の標本からの秒数です（既定 0〜1）。',
         '届いたとみなす値：EDIT の最大がこれより下の係数を、届かないとします（既定 0.3）。',
         '張り付きとみなす値 / 張り付きの割合の上限：この値以上の標本を張り付きと数えます（0.99）。割合が上限（0.01＝1%）より大きい係数に印を付けます。',
         '真顔の残り値の線：真顔の部分で EDIT がこれより上に出る係数に印を付けます（0.1）。',
         '山へ移る時の開始フレーム（シェイプキーの時だけ）：取り込みに使った開始フレームです。骨の時は、取り込みの設定の開始フレームとフレームのオフセット値を使います。',
         '一覧の列は、係数、RAW の最大＞EDIT の最大、EDIT の張り付きの割合、山の行（RAW の最大がある CSV の 0 始まりの行）、真顔での EDIT の最大です。警告の印は、その係数に印がある事を示します。',
         '書き出した表には、RAW と EDIT の最小・p50 / p95 / p99（順位の間を直線で補う）・0.5 以上の割合・山の時刻・真顔の平均も入ります。']),
    verify=(
        ['A channel marked sticking: widen its max in the calibration table, or check "Build Calibration Table".',
         'A weak channel whose RAW maximum is also small: the tracker does not output it strongly; calibration cannot create movement that is not recorded.',
         'Compare with the RAW and EDIT Actions after the import (RAW / EDIT buttons).'],
        ['張り付きの印がある係数：校正表の max を広げるか、「校正表を作る」で作り直します。',
         'RAW の最大も小さい、届かない係数：追跡器がその動きを強く出していません。校正で、収録されていない動きは作れません。',
         '取り込んだ後は、RAW・EDIT のボタンでアクションを切り替えて見比べます。']),
    undo=(
        ['Inspecting changes no Action and no shape. It only replaces the list. Exported files stay.',
         'Limits: EDIT is computed in the capture samples, before the import resamples them to scene frames, so a value between frames may differ slightly from the baked key. Tongue and cheek puff are not written to bones, so their EDIT column is empty in bone mode.'],
        ['点検はアクションも形も変えません。一覧を入れ替えるだけです。書き出したファイルは残ります。',
         '限界：EDIT は、取り込みがシーンのフレームへ並べ直す前の、収録の標本のままで求めます。フレームの間の値は、焼いたキーと少し違う事があります。舌と頬ふくらみは骨へ書かないので、骨の時は EDIT の欄が空です。']),
)
