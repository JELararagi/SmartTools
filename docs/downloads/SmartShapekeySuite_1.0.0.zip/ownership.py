# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Exact ownership metadata for suite-generated temporary Blender datablocks."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import uuid

import bpy

SUITE_ID = "smart_shapekey_suite"
SCHEMA = "smart_shapekey_suite.temp.v2"
PROP_SUITE = "skm_owner_suite_id"
PROP_OWNER_UUID = "skm_owner_uuid"
PROP_SOURCE_OBJECT_UUID = "skm_source_object_uuid"
PROP_SOURCE_MESH_UUID = "skm_source_mesh_uuid"
PROP_FILE_GENERATION = "skm_file_generation"
PROP_SESSION_GENERATION = "skm_session_generation"
PROP_SCHEMA = "skm_owner_schema"
PROP_TEMPORARY = "skm_temporary"
PROP_ID_UUID = "skm_identity_uuid"
_FILE_KEY = "SMART_SHAPEKEY_SUITE_FILE_GENERATION"
_SESSION_KEY = "SMART_SHAPEKEY_SUITE_SESSION_GENERATION"


@dataclass(frozen=True, slots=True)
class OwnershipIdentity:
    owner_uuid: str
    source_object_uuid: str
    source_mesh_uuid: str
    file_generation: str
    session_generation: str
    schema: str = SCHEMA
    suite_id: str = SUITE_ID


def _ns() -> dict:
    return bpy.app.driver_namespace


def new_file_generation() -> str:
    value = uuid.uuid4().hex
    _ns()[_FILE_KEY] = value
    return value


def current_file_generation() -> str:
    value = str(_ns().get(_FILE_KEY, "") or "")
    return value or new_file_generation()


def new_session_generation() -> str:
    value = uuid.uuid4().hex
    _ns()[_SESSION_KEY] = value
    return value


def current_session_generation() -> str:
    value = str(_ns().get(_SESSION_KEY, "") or "")
    return value or new_session_generation()


def existing_identity(data: Any) -> str:
    if data is None:
        return ""
    try:
        return str(data.get(PROP_ID_UUID, "") or "")
    except Exception:
        return ""


def ensure_identity(data: Any) -> str:
    existing = existing_identity(data)
    if existing:
        return existing
    if data is None:
        return ""
    value = uuid.uuid4().hex
    data[PROP_ID_UUID] = value
    return value


def source_identity(source_obj: Any, *, create: bool = True) -> OwnershipIdentity | None:
    """Return source identity without mutating foreign/user data on read paths.

    ``create=True`` is reserved for explicit Suite operations that are creating
    owned data. Cleanup, poll, draw, lookup and unregister must use
    ``create=False``; a missing UUID then means "not owned" rather than silently
    stamping a user datablock.
    """
    if source_obj is None:
        return None
    mesh = getattr(source_obj, "data", None)
    object_uuid = ensure_identity(source_obj) if create else existing_identity(source_obj)
    mesh_uuid = ensure_identity(mesh) if create and mesh is not None else existing_identity(mesh)
    if not object_uuid or not mesh_uuid:
        return None
    return OwnershipIdentity(
        owner_uuid=object_uuid,
        source_object_uuid=object_uuid,
        source_mesh_uuid=mesh_uuid,
        file_generation=current_file_generation(),
        session_generation=current_session_generation(),
    )


def identity_from_metadata(data: Any) -> OwnershipIdentity | None:
    values = metadata(data)
    required = (
        PROP_OWNER_UUID, PROP_SOURCE_OBJECT_UUID, PROP_SOURCE_MESH_UUID,
        PROP_FILE_GENERATION, PROP_SESSION_GENERATION, PROP_SCHEMA, PROP_SUITE,
    )
    if not values or any(not str(values.get(key) or "") for key in required):
        return None
    return OwnershipIdentity(
        owner_uuid=str(values[PROP_OWNER_UUID]),
        source_object_uuid=str(values[PROP_SOURCE_OBJECT_UUID]),
        source_mesh_uuid=str(values[PROP_SOURCE_MESH_UUID]),
        file_generation=str(values[PROP_FILE_GENERATION]),
        session_generation=str(values[PROP_SESSION_GENERATION]),
        schema=str(values[PROP_SCHEMA]),
        suite_id=str(values[PROP_SUITE]),
    )


def refresh_generation(data: Any, identity: OwnershipIdentity) -> None:
    """Refresh only a graph already proven owned by source UUID/schema."""
    data[PROP_FILE_GENERATION] = identity.file_generation
    data[PROP_SESSION_GENERATION] = identity.session_generation


def mark_temporary(data: Any, identity: OwnershipIdentity) -> Any:
    data[PROP_SUITE] = identity.suite_id
    data[PROP_OWNER_UUID] = identity.owner_uuid
    data[PROP_SOURCE_OBJECT_UUID] = identity.source_object_uuid
    data[PROP_SOURCE_MESH_UUID] = identity.source_mesh_uuid
    data[PROP_FILE_GENERATION] = identity.file_generation
    data[PROP_SESSION_GENERATION] = identity.session_generation
    data[PROP_SCHEMA] = identity.schema
    data[PROP_TEMPORARY] = True
    ensure_identity(data)
    return data


def metadata(data: Any) -> dict[str, Any]:
    try:
        return {
            PROP_SUITE: data.get(PROP_SUITE),
            PROP_OWNER_UUID: data.get(PROP_OWNER_UUID),
            PROP_SOURCE_OBJECT_UUID: data.get(PROP_SOURCE_OBJECT_UUID),
            PROP_SOURCE_MESH_UUID: data.get(PROP_SOURCE_MESH_UUID),
            PROP_FILE_GENERATION: data.get(PROP_FILE_GENERATION),
            PROP_SESSION_GENERATION: data.get(PROP_SESSION_GENERATION),
            PROP_SCHEMA: data.get(PROP_SCHEMA),
            PROP_TEMPORARY: data.get(PROP_TEMPORARY),
        }
    except Exception:
        return {}


def is_owned_temporary(data: Any, identity: OwnershipIdentity | None, *, require_current_session: bool = True) -> bool:
    if data is None or identity is None:
        return False
    values = metadata(data)
    if values.get(PROP_SUITE) != identity.suite_id:
        return False
    if values.get(PROP_OWNER_UUID) != identity.owner_uuid:
        return False
    if values.get(PROP_SOURCE_OBJECT_UUID) != identity.source_object_uuid:
        return False
    if values.get(PROP_SOURCE_MESH_UUID) != identity.source_mesh_uuid:
        return False
    if values.get(PROP_FILE_GENERATION) != identity.file_generation:
        return False
    if require_current_session and values.get(PROP_SESSION_GENERATION) != identity.session_generation:
        return False
    if values.get(PROP_SCHEMA) != identity.schema:
        return False
    return type(values.get(PROP_TEMPORARY)) is bool and values.get(PROP_TEMPORARY) is True


def same_owned_graph(parent: Any, child: Any) -> bool:
    """Require every ownership field to match; names/custom tags are irrelevant."""
    a = metadata(parent)
    b = metadata(child)
    keys = (
        PROP_SUITE,
        PROP_OWNER_UUID,
        PROP_SOURCE_OBJECT_UUID,
        PROP_SOURCE_MESH_UUID,
        PROP_FILE_GENERATION,
        PROP_SESSION_GENERATION,
        PROP_SCHEMA,
        PROP_TEMPORARY,
    )
    return bool(a and b and all(a.get(key) == b.get(key) for key in keys) and a.get(PROP_TEMPORARY) is True)



def matches_persistent_source(data: Any, source_obj: Any) -> bool:
    """Match a persisted owned datablock to a source while ignoring generations.

    File/session generations intentionally change at load boundaries. Adoption is
    permitted only after suite/schema/temporary/owner/source UUIDs all match the
    persistent UUIDs already present on the source Object and Mesh.
    """
    if data is None or source_obj is None:
        return False
    object_uuid = existing_identity(source_obj)
    mesh_uuid = existing_identity(getattr(source_obj, "data", None))
    if not object_uuid or not mesh_uuid:
        return False
    values = metadata(data)
    return bool(
        values.get(PROP_SUITE) == SUITE_ID
        and values.get(PROP_SCHEMA) == SCHEMA
        and values.get(PROP_TEMPORARY) is True
        and values.get(PROP_OWNER_UUID) == object_uuid
        and values.get(PROP_SOURCE_OBJECT_UUID) == object_uuid
        and values.get(PROP_SOURCE_MESH_UUID) == mesh_uuid
    )


def adopt_persistent_graph(parent: Any, child: Any, source_obj: Any) -> OwnershipIdentity | None:
    if not matches_persistent_source(parent, source_obj):
        return None
    if not matches_persistent_source(child, source_obj):
        return None
    a = metadata(parent)
    b = metadata(child)
    for key in (PROP_SUITE, PROP_OWNER_UUID, PROP_SOURCE_OBJECT_UUID, PROP_SOURCE_MESH_UUID, PROP_SCHEMA, PROP_TEMPORARY):
        if a.get(key) != b.get(key):
            return None
    identity = OwnershipIdentity(
        owner_uuid=existing_identity(source_obj),
        source_object_uuid=existing_identity(source_obj),
        source_mesh_uuid=existing_identity(getattr(source_obj, "data", None)),
        file_generation=current_file_generation(),
        session_generation=current_session_generation(),
    )
    refresh_generation(parent, identity)
    refresh_generation(child, identity)
    return identity

def clear_session_generation() -> None:
    try:
        _ns().pop(_SESSION_KEY, None)
    except Exception:
        pass
