# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Strict, recoverable JSON persistence for Smart Shapekey Suite.

This module is intentionally independent of ``bpy`` so fault-injection tests can
exercise NUL/truncation/duplicate-key/non-finite/read-only/disk-full paths without
opening or mutating the user's Blender configuration.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping
import copy
import hashlib
import hmac
import json
import math
import os
import time
import uuid

SCHEMA_ID = "smart_shapekey_suite.settings"
SCHEMA_REVISION = 2
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_QUARANTINE_RECORDS = 32
MAX_COLLECTION_ITEMS = 10000
MAX_TEXT_LENGTH = 32768
_FAULT_INJECTION_HOOK = None


def set_fault_injection_hook(hook) -> None:
    """Install an audit-only checkpoint hook; pass ``None`` in production."""
    global _FAULT_INJECTION_HOOK
    _FAULT_INJECTION_HOOK = hook if callable(hook) else None


def _checkpoint(stage: str) -> None:
    hook = _FAULT_INJECTION_HOOK
    if callable(hook):
        hook(str(stage))



class SettingsError(ValueError):
    pass


class DuplicateKeyError(SettingsError):
    pass


@dataclass(slots=True)
class SettingsSnapshot:
    settings: dict[str, Any]
    generation: int
    checksum: str
    source: str


@dataclass(slots=True)
class SettingsState:
    last_good: SettingsSnapshot | None = None
    dirty: bool = False
    last_error: str = ""
    notification_pending: bool = False
    last_notified_error: str = ""
    quarantined: list[str] = field(default_factory=list)

    def mark_failure(self, exc: BaseException) -> None:
        self.dirty = True
        message = f"{type(exc).__name__}: {exc}"
        self.last_error = message
        self.notification_pending = bool(message != self.last_notified_error)


STATE = SettingsState()


def _reject_constant(value: str) -> None:
    raise SettingsError(f"non-finite JSON number is not allowed: {value}")


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise DuplicateKeyError(f"duplicate JSON key: {key}")
        out[key] = value
    return out


def _loads_strict(raw: str) -> Any:
    if "\x00" in raw:
        raise SettingsError("NUL byte detected")
    try:
        value = json.loads(raw, object_pairs_hook=_unique_pairs, parse_constant=_reject_constant)
    except SettingsError:
        raise
    except Exception as exc:
        raise SettingsError(f"invalid or truncated JSON: {exc}") from exc
    _validate_json_value(value, path="$", depth=0)
    return value


def _validate_json_value(value: Any, *, path: str, depth: int) -> None:
    if depth > 24:
        raise SettingsError(f"nesting too deep at {path}")
    if value is None or isinstance(value, (bool, str)):
        if isinstance(value, str) and len(value) > MAX_TEXT_LENGTH:
            raise SettingsError(f"text too long at {path}")
        return
    if isinstance(value, int) and not isinstance(value, bool):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise SettingsError(f"non-finite number at {path}")
        return
    if isinstance(value, list):
        if len(value) > MAX_COLLECTION_ITEMS:
            raise SettingsError(f"list too large at {path}")
        for index, item in enumerate(value):
            _validate_json_value(item, path=f"{path}[{index}]", depth=depth + 1)
        return
    if isinstance(value, dict):
        if len(value) > MAX_COLLECTION_ITEMS:
            raise SettingsError(f"object too large at {path}")
        for key, item in value.items():
            if not isinstance(key, str) or not key:
                raise SettingsError(f"invalid object key at {path}")
            if len(key) > 512:
                raise SettingsError(f"object key too long at {path}")
            _validate_json_value(item, path=f"{path}.{key}", depth=depth + 1)
        return
    raise SettingsError(f"unsupported JSON value at {path}: {type(value).__name__}")


def _canonical_settings_bytes(settings: Mapping[str, Any]) -> bytes:
    return json.dumps(settings, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _checksum(settings: Mapping[str, Any], generation: int) -> str:
    digest = hashlib.sha256()
    digest.update(SCHEMA_ID.encode("utf-8"))
    digest.update(b"\0")
    digest.update(str(SCHEMA_REVISION).encode("ascii"))
    digest.update(b"\0")
    digest.update(str(int(generation)).encode("ascii"))
    digest.update(b"\0")
    digest.update(_canonical_settings_bytes(settings))
    return digest.hexdigest()


def _expect_exact_type(key: str, value: Any, expected: type) -> Any:
    if expected is bool:
        if type(value) is not bool:
            raise SettingsError(f"{key} must be bool")
    elif expected is int:
        if type(value) is not int:
            raise SettingsError(f"{key} must be int")
    elif expected is float:
        if type(value) not in (int, float) or isinstance(value, bool) or not math.isfinite(float(value)):
            raise SettingsError(f"{key} must be finite number")
        value = float(value)
    elif expected is str:
        if type(value) is not str:
            raise SettingsError(f"{key} must be string")
    elif expected is list:
        if type(value) is not list:
            raise SettingsError(f"{key} must be list")
    elif expected is dict:
        if type(value) is not dict:
            raise SettingsError(f"{key} must be object")
    return value


def _preserve_unknown_fields(source: Mapping[str, Any], known: set[str], out: dict[str, Any], path: str) -> dict[str, Any]:
    """Copy forward-compatible fields after generic bounded JSON validation."""
    for key, value in source.items():
        if key in known:
            continue
        _validate_json_value(value, path=f"{path}.{key}", depth=0)
        out[str(key)] = copy.deepcopy(value)
    return out


def _validate_ui_sections(value: dict[str, Any]) -> dict[str, bool]:
    out: dict[str, bool] = {}
    if len(value) > 512:
        raise SettingsError("ui_sections exceeds 512 entries")
    for key, item in value.items():
        if type(item) is not bool:
            raise SettingsError(f"ui_sections.{key} must be bool")
        out[str(key)] = bool(item)
    return out


def _validate_target_rows(value: list[Any], key: str) -> list[dict[str, Any]]:
    allowed = {"obj_name", "group_name"}
    out: list[dict[str, Any]] = []
    for index, row in enumerate(value):
        if type(row) is not dict:
            raise SettingsError(f"{key}[{index}] must be object")
        validated = {
            "obj_name": _expect_exact_type(f"{key}[{index}].obj_name", row.get("obj_name", ""), str),
            "group_name": _expect_exact_type(f"{key}[{index}].group_name", row.get("group_name", ""), str),
        }
        out.append(_preserve_unknown_fields(row, allowed, validated, f"{key}[{index}]"))
    return out


def _validate_preset_state(row: Any, path: str) -> dict[str, Any]:
    if type(row) is not dict:
        raise SettingsError(f"{path} must be object")
    allowed = {"obj_name", "group_name", "joy_x", "joy_y"}
    out = {
        "obj_name": _expect_exact_type(f"{path}.obj_name", row.get("obj_name", ""), str),
        "group_name": _expect_exact_type(f"{path}.group_name", row.get("group_name", ""), str),
        "joy_x": _expect_exact_type(f"{path}.joy_x", row.get("joy_x", 0.0), float),
        "joy_y": _expect_exact_type(f"{path}.joy_y", row.get("joy_y", 0.0), float),
    }
    return _preserve_unknown_fields(row, allowed, out, path)


def _validate_presets(value: list[Any], key: str) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for index, row in enumerate(value):
        path = f"{key}[{index}]"
        if type(row) is not dict:
            raise SettingsError(f"{path} must be object")
        allowed = {"name", "states"}
        states = _expect_exact_type(f"{path}.states", row.get("states", []), list)
        validated = {
            "name": _expect_exact_type(f"{path}.name", row.get("name", ""), str),
            "states": [_validate_preset_state(item, f"{path}.states[{i}]") for i, item in enumerate(states)],
        }
        out.append(_preserve_unknown_fields(row, allowed, validated, path))
    return out


def _validate_axis_item(row: Any, path: str) -> dict[str, Any]:
    if type(row) is not dict:
        raise SettingsError(f"{path} must be object")
    allowed = {"shape_name", "target_x", "target_y", "radius", "blend_mode"}
    out = {
        "shape_name": _expect_exact_type(f"{path}.shape_name", row.get("shape_name", ""), str),
        "target_x": _expect_exact_type(f"{path}.target_x", row.get("target_x", 0.0), float),
        "target_y": _expect_exact_type(f"{path}.target_y", row.get("target_y", 0.0), float),
        "radius": _expect_exact_type(f"{path}.radius", row.get("radius", 0.25), float),
        "blend_mode": _expect_exact_type(f"{path}.blend_mode", row.get("blend_mode", "MAX"), str),
    }
    return _preserve_unknown_fields(row, allowed, out, path)


def _validate_axis_group(row: Any, path: str) -> dict[str, Any]:
    if type(row) is not dict:
        raise SettingsError(f"{path} must be object")
    scalar_string = {"name", "tracker_x_mode", "tracker_y_mode"}
    scalar_float = {
        "joy_x", "joy_y", "tracker_x_rmin", "tracker_x_rmax", "tracker_x_omin", "tracker_x_omax",
        "tracker_x_sens", "tracker_x_exp", "tracker_x_lerp_fac", "tracker_y_rmin", "tracker_y_rmax",
        "tracker_y_omin", "tracker_y_omax", "tracker_y_sens", "tracker_y_exp", "tracker_y_lerp_fac",
    }
    scalar_int = {"shape_xy_index", "tracker_x_pt_a", "tracker_x_pt_b", "tracker_y_pt_a", "tracker_y_pt_b"}
    scalar_bool = {"tracker_x_lerp_en", "tracker_y_lerp_en"}
    allowed = scalar_string | scalar_float | scalar_int | scalar_bool | {"items"}
    out: dict[str, Any] = {}
    for key in scalar_string:
        if key in row:
            out[key] = _expect_exact_type(f"{path}.{key}", row[key], str)
    for key in scalar_float:
        if key in row:
            out[key] = _expect_exact_type(f"{path}.{key}", row[key], float)
    for key in scalar_int:
        if key in row:
            out[key] = _expect_exact_type(f"{path}.{key}", row[key], int)
    for key in scalar_bool:
        if key in row:
            out[key] = _expect_exact_type(f"{path}.{key}", row[key], bool)
    items = _expect_exact_type(f"{path}.items", row.get("items", []), list)
    out["items"] = [_validate_axis_item(item, f"{path}.items[{i}]") for i, item in enumerate(items)]
    return _preserve_unknown_fields(row, allowed, out, path)


def _validate_object_groups(value: dict[str, Any], key: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for object_name, payload in value.items():
        path = f"{key}.{object_name}"
        if type(payload) is not dict:
            raise SettingsError(f"{path} must be object")
        allowed = {"index", "groups"}
        groups = _expect_exact_type(f"{path}.groups", payload.get("groups", []), list)
        validated = {
            "index": _expect_exact_type(f"{path}.index", payload.get("index", -1), int),
            "groups": [_validate_axis_group(item, f"{path}.groups[{i}]") for i, item in enumerate(groups)],
        }
        out[str(object_name)] = _preserve_unknown_fields(payload, allowed, validated, path)
    return out


def validate_settings(settings: Any, defaults: Mapping[str, Any]) -> dict[str, Any]:
    if type(settings) is not dict:
        raise SettingsError("settings payload must be an object")
    allowed = set(defaults)
    missing = allowed - set(settings)
    if missing:
        raise SettingsError(f"missing settings field(s): {sorted(missing)}")

    out: dict[str, Any] = {}
    for key, default in defaults.items():
        value = settings[key]
        if key == "ui_sections":
            out[key] = _validate_ui_sections(_expect_exact_type(key, value, dict))
        elif key in {"face_tracker_targets", "tracker_targets"}:
            out[key] = _validate_target_rows(_expect_exact_type(key, value, list), key)
        elif key in {"shape_axis_presets", "shape_xy_presets"}:
            out[key] = _validate_presets(_expect_exact_type(key, value, list), key)
        elif key in {"shape_axis_object_groups", "shape_xy_groups"}:
            out[key] = _validate_object_groups(_expect_exact_type(key, value, dict), key)
        elif type(default) is bool:
            out[key] = _expect_exact_type(key, value, bool)
        elif type(default) is int:
            out[key] = _expect_exact_type(key, value, int)
        elif type(default) is float:
            out[key] = _expect_exact_type(key, value, float)
        elif type(default) is str:
            out[key] = _expect_exact_type(key, value, str)
        elif type(default) is list:
            out[key] = copy.deepcopy(_expect_exact_type(key, value, list))
        elif type(default) is dict:
            out[key] = copy.deepcopy(_expect_exact_type(key, value, dict))
        else:
            raise SettingsError(f"unsupported default schema for {key}")
    _preserve_unknown_fields(settings, allowed, out, "settings")
    return out


def validate_legacy_settings(settings: Any, defaults: Mapping[str, Any]) -> dict[str, Any]:
    """Validate a pre-envelope snapshot without discarding known user values.

    Legacy files may legitimately predate newer settings fields. Missing known
    fields receive current defaults; bounded unknown fields are preserved for
    forward compatibility and ignored by this runtime.
    """
    if type(settings) is not dict:
        raise SettingsError("legacy settings payload must be an object")
    merged = copy.deepcopy(dict(defaults))
    for key, value in settings.items():
        merged[key] = copy.deepcopy(value)
    return validate_settings(merged, defaults)


def _decode_document(raw: str, defaults: Mapping[str, Any], *, source: str) -> SettingsSnapshot:
    decoded = _loads_strict(raw)
    if type(decoded) is not dict:
        raise SettingsError("top-level JSON must be an object")

    envelope_keys = {"schema", "revision", "generation", "checksum", "settings"}
    if "settings" in decoded or "schema" in decoded:
        unknown = set(decoded) - envelope_keys
        missing = envelope_keys - set(decoded)
        if unknown:
            raise SettingsError(f"unknown envelope field(s): {sorted(unknown)}")
        if missing:
            raise SettingsError(f"missing envelope field(s): {sorted(missing)}")
        if decoded["schema"] != SCHEMA_ID:
            raise SettingsError("schema identifier mismatch")
        if type(decoded["revision"]) is not int or decoded["revision"] != SCHEMA_REVISION:
            raise SettingsError("schema revision mismatch")
        if type(decoded["generation"]) is not int or decoded["generation"] < 1:
            raise SettingsError("invalid settings generation")
        if type(decoded["checksum"]) is not str or len(decoded["checksum"]) != 64:
            raise SettingsError("invalid checksum field")
        settings = validate_settings(decoded["settings"], defaults)
        expected = _checksum(settings, decoded["generation"])
        if not hmac.compare_digest(expected, decoded["checksum"]):
            raise SettingsError("checksum mismatch")
        return SettingsSnapshot(settings, int(decoded["generation"]), expected, source)

    # Legacy flat JSON is not rewritten during recovery.  Known fields are
    # preserved, missing newer fields receive schema defaults, and unknown or
    # mistyped fields remain strict failures.
    settings = validate_legacy_settings(decoded, defaults)
    checksum = _checksum(settings, 0)
    return SettingsSnapshot(settings, 0, checksum, source)


def read_snapshot(path: Path | str, defaults: Mapping[str, Any], *, source: str | None = None) -> SettingsSnapshot:
    file_path = Path(path)
    try:
        size = file_path.stat().st_size
    except Exception as exc:
        raise SettingsError(f"cannot stat settings file: {exc}") from exc
    if size <= 0 or size > MAX_FILE_BYTES:
        raise SettingsError(f"invalid settings file size: {size}")
    try:
        raw = file_path.read_text(encoding="utf-8", errors="strict")
    except Exception as exc:
        raise SettingsError(f"cannot read UTF-8 settings file: {exc}") from exc
    return _decode_document(raw, defaults, source=source or str(file_path))


def _quarantine(path: Path, state: SettingsState) -> None:
    if not path.exists():
        return
    suffix = f".corrupt.{int(time.time())}.{uuid.uuid4().hex}"
    target = path.with_name(path.name + suffix)
    try:
        os.replace(path, target)
        _fsync_directory(path.parent)
        state.quarantined.append(str(target))
    except Exception:
        # Treat as logically quarantined even if permissions prevent rename.
        state.quarantined.append(str(path))
    if len(state.quarantined) > MAX_QUARANTINE_RECORDS:
        del state.quarantined[:-MAX_QUARANTINE_RECORDS]


def recover_settings(
    main_path: Path | str,
    defaults: Mapping[str, Any],
    *,
    backup_path: Path | str | None = None,
    legacy_paths: Iterable[Path | str] = (),
    quarantine_main: bool = True,
    state: SettingsState = STATE,
) -> SettingsSnapshot:
    main = Path(main_path)
    backup = Path(backup_path) if backup_path is not None else main.with_name(main.name + ".bak")
    failures: list[str] = []

    if main.exists():
        try:
            snap = read_snapshot(main, defaults, source="main")
            state.last_good = snap
            state.dirty = False
            state.last_error = ""
            state.notification_pending = False
            state.last_notified_error = ""
            return copy.deepcopy(snap)
        except Exception as exc:
            failures.append(f"main:{type(exc).__name__}:{exc}")
            if quarantine_main:
                _quarantine(main, state)

    if backup.exists():
        try:
            snap = read_snapshot(backup, defaults, source="backup")
            state.last_good = snap
            state.dirty = False
            state.last_error = "; ".join(failures)
            state.notification_pending = bool(state.last_error and state.last_error != state.last_notified_error)
            return copy.deepcopy(snap)
        except Exception as exc:
            failures.append(f"backup:{type(exc).__name__}:{exc}")

    for legacy in legacy_paths:
        candidate = Path(legacy)
        if not candidate.exists() or candidate == main or candidate == backup:
            continue
        try:
            snap = read_snapshot(candidate, defaults, source=f"legacy:{candidate}")
            state.last_good = snap
            state.dirty = False
            state.last_error = "; ".join(failures)
            state.notification_pending = bool(state.last_error and state.last_error != state.last_notified_error)
            return copy.deepcopy(snap)
        except Exception as exc:
            failures.append(f"legacy:{candidate}:{type(exc).__name__}:{exc}")

    settings = copy.deepcopy(dict(defaults))
    settings = validate_settings(settings, defaults)
    snap = SettingsSnapshot(settings, 0, _checksum(settings, 0), "defaults")
    state.last_good = snap
    state.dirty = False
    state.last_error = "; ".join(failures)
    state.notification_pending = bool(state.last_error and state.last_error != state.last_notified_error)
    return copy.deepcopy(snap)


def _fsync_directory(path: Path) -> None:
    if not hasattr(os, "O_DIRECTORY"):
        return
    fd = None
    try:
        fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
        os.fsync(fd)
    finally:
        if fd is not None:
            os.close(fd)


def _write_bytes_fsync(path: Path, payload: bytes) -> None:
    with open(path, "xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _serialize_snapshot(settings: dict[str, Any], generation: int) -> tuple[bytes, SettingsSnapshot]:
    checksum = _checksum(settings, generation)
    document = {
        "schema": SCHEMA_ID,
        "revision": SCHEMA_REVISION,
        "generation": generation,
        "checksum": checksum,
        "settings": settings,
    }
    raw = (json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    return raw, SettingsSnapshot(copy.deepcopy(settings), generation, checksum, "main")


def _restore_previous_main(main: Path, previous_bytes: bytes | None, defaults: Mapping[str, Any]) -> None:
    """Best-effort atomic restoration after a post-replace verification fault."""
    if previous_bytes is None:
        try:
            if main.exists():
                main.unlink()
                _fsync_directory(main.parent)
        except Exception:
            pass
        return
    restore_tmp = main.with_name(f".{main.name}.{uuid.uuid4().hex}.restore.tmp")
    try:
        _write_bytes_fsync(restore_tmp, previous_bytes)
        read_snapshot(restore_tmp, defaults, source="restore-staged")
        os.replace(restore_tmp, main)
        _fsync_directory(main.parent)
        read_snapshot(main, defaults, source="restore-readback")
    finally:
        try:
            if restore_tmp.exists():
                restore_tmp.unlink()
        except Exception:
            pass


def atomic_write_settings(
    main_path: Path | str,
    settings: Mapping[str, Any],
    defaults: Mapping[str, Any],
    *,
    backup_path: Path | str | None = None,
    state: SettingsState = STATE,
) -> SettingsSnapshot:
    """Atomically commit one strictly validated settings generation.

    The authoritative in-memory snapshot and dirty flag are changed only after
    the committed file passes strict read-back.  If replacement succeeds but a
    later verification fails, the last validated main is restored from the
    validated backup on a best-effort atomic path; the caller still receives the
    original failure and the last-good in-memory snapshot remains authoritative.
    """
    main = Path(main_path)
    backup = Path(backup_path) if backup_path is not None else main.with_name(main.name + ".bak")
    cleaned = validate_settings(copy.deepcopy(dict(settings)), defaults)
    generation = max(1, int(getattr(state.last_good, "generation", 0) or 0) + 1)
    raw, expected = _serialize_snapshot(cleaned, generation)
    main.parent.mkdir(parents=True, exist_ok=True)
    backup.parent.mkdir(parents=True, exist_ok=True)

    tmp_main = main.with_name(f".{main.name}.{uuid.uuid4().hex}.tmp")
    tmp_backup = backup.with_name(f".{backup.name}.{uuid.uuid4().hex}.tmp")
    restore_tmp = main.with_name(f".{main.name}.{uuid.uuid4().hex}.restore.tmp")
    validated_previous: bytes | None = None
    main_replaced = False
    try:
        _checkpoint("before_backup")
        # A valid existing main is the last durable snapshot. Its backup update
        # is mandatory; main is never replaced until backup read-back succeeds.
        if main.exists():
            read_snapshot(main, defaults, source="prewrite-main")
            validated_previous = main.read_bytes()
            _checkpoint("before_backup_write")
            _write_bytes_fsync(tmp_backup, validated_previous)
            _checkpoint("after_backup_fsync")
            backup_staged = read_snapshot(tmp_backup, defaults, source="backup-staged")
            if not backup_staged.checksum:
                raise SettingsError("backup staged read-back mismatch")
            os.replace(tmp_backup, backup)
            _checkpoint("after_backup_replace")
            _fsync_directory(backup.parent)
            backup_committed = read_snapshot(backup, defaults, source="backup-readback")
            if backup_committed.settings != backup_staged.settings or backup_committed.checksum != backup_staged.checksum:
                raise SettingsError("backup committed read-back mismatch")
        _checkpoint("backup_verified")

        _checkpoint("before_tmp_write")
        _write_bytes_fsync(tmp_main, raw)
        _checkpoint("after_tmp_fsync")
        staged = read_snapshot(tmp_main, defaults, source="staged")
        if staged.generation != expected.generation or staged.checksum != expected.checksum or staged.settings != expected.settings:
            raise SettingsError("staged read-back mismatch")
        _checkpoint("staged_verified")
        os.replace(tmp_main, main)
        main_replaced = True
        _checkpoint("after_main_replace")
        _fsync_directory(main.parent)
        _checkpoint("after_directory_fsync")
        committed = read_snapshot(main, defaults, source="main")
        if committed.generation != expected.generation or committed.checksum != expected.checksum or committed.settings != expected.settings:
            raise SettingsError("committed read-back mismatch")
        _checkpoint("readback_verified")
    except Exception as exc:
        # Restore the validated previous generation if replacement occurred but
        # the committed generation could not be verified.  This path is bounded
        # to the suite's settings files and never mutates Blender datablocks.
        if main_replaced:
            try:
                _restore_previous_main(main, validated_previous, defaults)
            except Exception:
                pass
        for tmp in (tmp_main, tmp_backup, restore_tmp):
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
        state.mark_failure(exc)
        raise

    for tmp in (tmp_main, tmp_backup, restore_tmp):
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
    state.last_good = committed
    state.dirty = False
    state.last_error = ""
    state.notification_pending = False
    state.last_notified_error = ""
    return copy.deepcopy(committed)

def mark_dirty(state: SettingsState = STATE) -> None:
    state.dirty = True


def peek_notification(state: SettingsState = STATE) -> str:
    if not state.notification_pending:
        return ""
    return state.last_error or "Smart Shapekey settings recovery was required."


def acknowledge_notification(state: SettingsState = STATE) -> None:
    state.last_notified_error = state.last_error
    state.notification_pending = False


def consume_notification(state: SettingsState = STATE) -> str:
    """Compatibility helper; prefer peek+ack when UI delivery can fail."""
    message = peek_notification(state)
    if message:
        acknowledge_notification(state)
    return message

