# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_shapekey_suite'
USER_DATA_DIRNAME = 'user_data'
CONFIG_DIRNAME = 'Smart_Shapekey_Suite'


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_shapekey_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        if create:
            installed.mkdir(parents=True, exist_ok=True)
        return installed
    for candidate in (_extension_path_user_root(pkg, create), _user_resource_root(pkg, create)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, create)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    # Historical callers use this helper for mutable suite-owned files.  An
    # installed Extension package is immutable, so keep those files in the
    # versioned Blender CONFIG tree instead of extensions/user_default.
    del package_id
    root = blender_config_dir(CONFIG_DIRNAME, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = blender_config_dir(CONFIG_DIRNAME, create=create)
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def blender_config_dir(*parts: object, create: bool = True) -> Path:
    """Return Blender's versioned user CONFIG directory.

    On Blender 5.1 for Windows this is rooted at
    ``%APPDATA%/Blender Foundation/Blender/5.1/config``.
    """
    path: Path | None = None
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': create}),
                (('CONFIG',), {'create': create}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    continue
                if value:
                    path = Path(value)
                    break
        if path is None:
            resource_path = getattr(getattr(bpy, 'utils', None), 'resource_path', None)
            if callable(resource_path):
                try:
                    value = resource_path('USER')
                except Exception:
                    value = ''
                if value:
                    path = Path(value) / 'config'
    if path is None:
        version = _blender_version()
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
        else:
            path = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config')) / 'blender' / version / 'config'
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def blender_config_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('blender_config_file requires a filename')
    path = blender_config_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    del package
    root = blender_config_dir(CONFIG_DIRNAME, 'runtime', create=create)
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    del package_id
    root = blender_config_dir(CONFIG_DIRNAME, 'storage', create=create)
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def legacy_extension_path(*parts: object) -> Path:
    """Return a package-local mutable path without creating it."""
    clean = _clean_parts(parts)
    root = _package_root()
    return root.joinpath(*clean) if clean else root


def migrate_legacy_extension_data() -> list[str]:
    """Copy old package-local user files into CONFIG without altering them.

    Only known mutable roots are considered.  No
    shipped source, icon, preset asset, or other package content is touched.
    Existing CONFIG files remain authoritative; collisions are preserved under
    ``legacy_conflicts`` so migration never loses user data.  The installed
    package is treated as a read-only migration source.
    """
    mutable_roots = (
        USER_DATA_DIRNAME,
        'python_modules',
        'pip_cache',
        'pip_tmp',
        'maps',
        'settings',
    )
    package_root = _package_root()
    target_root = blender_config_dir(CONFIG_DIRNAME, create=True)
    migrated: list[str] = []

    for root_name in mutable_roots:
        source_root = package_root / root_name
        try:
            if not source_root.is_dir() or source_root.is_symlink():
                continue
            entries = sorted(source_root.rglob('*'), key=lambda path: (len(path.parts), path.as_posix()))
        except Exception:
            continue
        for source in entries:
            try:
                if source.is_symlink() or not source.is_file():
                    continue
                child = source.relative_to(source_root)
                # ``user_data`` was the old aggregate mutable root; its
                # children now live directly below the suite CONFIG folder.
                # Other historical roots retain their explicit directory name.
                relative = child if root_name == USER_DATA_DIRNAME else Path(root_name) / child
                target = target_root / relative
                if target.exists():
                    if target.read_bytes() == source.read_bytes():
                        continue
                    target = target_root / 'legacy_conflicts' / relative
                    if target.exists():
                        if target.read_bytes() == source.read_bytes():
                            continue
                        index = 1
                        while True:
                            candidate = target.with_name(f'{target.stem}_{index}{target.suffix}')
                            if candidate.exists() and candidate.read_bytes() == source.read_bytes():
                                target = candidate
                                break
                            if not candidate.exists():
                                target = candidate
                                break
                            index += 1
                        if target.exists() and target.read_bytes() == source.read_bytes():
                            continue
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                migrated.append(relative.as_posix())
            except Exception:
                continue
    return migrated


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(text, encoding=encoding)
    tmp.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = True) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        if remove_legacy:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
