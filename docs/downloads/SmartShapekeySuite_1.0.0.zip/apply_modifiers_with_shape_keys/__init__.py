# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from .. import translation as _sss_translation
except Exception:
    _sss_translation = None

try:
    from .. import icons as _sss_icons
except Exception:
    _sss_icons = None



def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _safe_view3d_context(context) -> bool:
    area = getattr(context, 'area', None)
    return area is None or getattr(area, 'type', None) == 'VIEW_3D'


def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None


def _safe_active_mesh(context, *, require_selected: bool = True):
    obj = None
    for attr in ('object', 'active_object'):
        try:
            candidate = getattr(context, attr, None)
        except Exception:
            candidate = None
        if candidate is not None:
            obj = candidate
            break
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        if getattr(obj, 'data', None) is None:
            return None
    except Exception:
        return None
    try:
        if getattr(bpy.data.objects, 'get', None) and bpy.data.objects.get(getattr(obj, 'name', '')) is not obj:
            return None
    except Exception:
        return None
    if require_selected:
        try:
            selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
            if selected_objects and obj not in selected_objects:
                return None
        except Exception:
            pass
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode in {'', 'OBJECT'} and hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
    return obj


def _safe_mesh_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None and _safe_active_mesh(context, require_selected=True) is not None


def _safe_scene_panel_context(context) -> bool:
    return _safe_view3d_context(context) and _safe_scene(context) is not None




def _icon_op(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.operator(layout, operator_id, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=fallback, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def _icon_label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE'):
    try:
        if _sss_icons is not None:
            return _sss_icons.label(layout, text=text, icon_name=icon_name, fallback=fallback)
    except Exception:
        pass
    try:
        return layout.label(text=text, icon=fallback)
    except Exception:
        return layout.label(text=text)


def _draw_help_button(layout, tool_id: str, context=None, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Selector-style help button.

    The button uses Blender's built-in QUESTION icon and an empty label.
    """
    del context, icon, text
    if not tool_id:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION')
        op.tool_id = str(tool_id or '')
        return op
    except Exception:
        return None


from .apply_modifiers_with_shape_keys import ModifierList, OBJECT_OT_apply_modifiers_with_shape_keys



def draw_apply_modifiers_body(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False

    obj = _safe_active_mesh(context, require_selected=False)
    shape_keys = getattr(getattr(obj, 'data', None), 'shape_keys', None) if obj is not None else None
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        layout.label(text=_ui_text('Select a mesh object.', 'メッシュオブジェクトを選択してください。', context))
        return
    if shape_keys is None:
        layout.label(text=_ui_text('The active mesh has no Shape Keys.', 'シェイプキーがありません。', context))
        return
    if getattr(obj, 'mode', 'OBJECT') != 'OBJECT':
        layout.label(text=_ui_text('Switch to Object Mode.', 'オブジェクトモードに切り替えてください。', context))
        return
    if not getattr(obj, 'modifiers', None):
        layout.label(text=_ui_text('The active mesh has no modifiers to apply.', '適用するモディファイアがありません。', context))
        return

    _icon_op(layout, OBJECT_OT_apply_modifiers_with_shape_keys.bl_idname, text=_ui_text('Choose Modifiers', 'モディファイアを選択', context), icon_name='APPLY_MODIFIERS_CHOOSE', fallback='CHECKMARK')


class AMWSK_PT_smarttools_panel(bpy.types.Panel):
    bl_label = _ui_text('Apply Keeping Shape Keys', 'シェイプキー保持で適用')
    bl_idname = 'AMWSK_PT_smarttools_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        draw_apply_modifiers_body(self.layout, context)

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'apply_modifiers', context)


classes = [
    ModifierList,
    OBJECT_OT_apply_modifiers_with_shape_keys,
]


def register(ledger):
    from .. import lifecycle
    for cls in classes:
        lifecycle.register_class(ledger, cls)


def unregister():
    return None
