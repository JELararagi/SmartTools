# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from .. import translation as _sss_translation
except Exception:
    _sss_translation = None


from .functions import apply_modifiers_with_shape_keys, morph_maps_block_apply, morph_maps_block_message


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _valid_target_object(context):
    obj = getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    if getattr(getattr(obj, 'data', None), 'shape_keys', None) is None:
        return None
    if getattr(getattr(context, 'object', None), 'mode', 'OBJECT') != 'OBJECT':
        return None
    if len(getattr(obj, 'modifiers', ())) <= 0:
        return None
    return obj


class ModifierList(bpy.types.PropertyGroup):
    apply_modifier: bpy.props.BoolProperty(
        name='',
        description=_ui_text('Enable this modifier for the apply operation. Disabled modifiers remain unchanged.', 'このモディファイアを適用対象にします。無効のモディファイアは変更しません。'),
        default=False,
    )


class OBJECT_OT_apply_modifiers_with_shape_keys(bpy.types.Operator):
    bl_idname = 'object.apply_modifiers_with_shape_keys'
    bl_label = _ui_text('Apply Modifier(s) for Mesh with Shape Keys', 'シェイプキー保持で適用')
    bl_description = _ui_text(
        "Open a checklist dialog that lets you apply selected modifiers while preserving the mesh's Shape Keys.",
        'シェイプキーを保持したまま、適用したいモディファイアだけをチェックして実行するダイアログを開きます。',
    )
    bl_options = {'UNDO'}

    collection_property: bpy.props.CollectionProperty(
        type=ModifierList,
        description=_ui_text(
            'Internal checklist rows for the modifier apply dialog. Each row matches one visible modifier on the active mesh.',
            'モディファイア適用ダイアログ用の内部チェックリスト行です。各行はアクティブメッシュ上の表示モディファイアに対応します。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return _valid_target_object(context) is not None

    def execute(self, context):
        obj = _valid_target_object(context)
        if obj is None:
            self.report({'ERROR'}, _ui_text('Select a mesh object in Object Mode that has Shape Keys and modifiers.', 'シェイプキーとモディファイアを持つメッシュをオブジェクトモードで選択してください。', context))
            return {'CANCELLED'}

        selected_modifiers = [item.name for item in self.collection_property if item.apply_modifier]
        if not selected_modifiers:
            self.report({'ERROR'}, _ui_text('No modifiers selected.', 'モディファイアが選択されていません。', context))
            return {'CANCELLED'}

        success, error_info = apply_modifiers_with_shape_keys(context, selected_modifiers)
        if not success:
            self.report({'ERROR'}, _sss_translation.exception_text(error_info, context) if error_info else _ui_text('Apply failed.', '適用に失敗しました。', context))
            return {'CANCELLED'}

        self.report({'INFO'}, _ui_text('Selected modifiers were applied while keeping Shape Keys.', '選択したモディファイアをシェイプキーを保持したまま適用しました。', context))
        return {'FINISHED'}

    def draw(self, context):
        self.layout.label(text=_ui_text('Select which modifier(s) to apply', '適用するモディファイアを選択', context))
        box = self.layout.box()
        for prop in self.collection_property:
            box.prop(prop, 'apply_modifier', text=prop.name, translate=False)

    def invoke(self, context, event):
        obj = _valid_target_object(context)
        if obj is None:
            self.report({'ERROR'}, _ui_text('This tool requires a mesh with Shape Keys and modifiers in Object Mode.', 'このツールはシェイプキーとモディファイアを持つメッシュをオブジェクトモードで選択している必要があります。', context))
            return {'CANCELLED'}
        if morph_maps_block_apply(obj):
            self.report({'ERROR'}, morph_maps_block_message(context))
            return {'CANCELLED'}

        self.collection_property.clear()
        for modifier in obj.modifiers:
            item = self.collection_property.add()
            item.name = modifier.name
            item.apply_modifier = False

        if len(self.collection_property) == 0:
            self.report({'ERROR'}, _ui_text('The active mesh has no modifiers to choose from.', 'アクティブメッシュに選択できるモディファイアがありません。', context))
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self)
