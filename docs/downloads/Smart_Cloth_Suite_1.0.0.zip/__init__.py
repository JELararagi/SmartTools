"""SmartCloth extension for Blender 5.1."""
import bpy
from bpy.app.handlers import persistent
from . import bindings,properties,persistence,jiggle,rigid,manager_bridge,translation,output
__version__='1.0.0'
REGISTERED=[]
@persistent
def after_load(_=None):
    persistence.load();jiggle.reset();jiggle.sync()
    if bpy.context.scene:rigid.sync(bpy.context.scene)
def register():
    try:
        properties.register();translation.register()
        for cls in bindings.CLASSES:
            if hasattr(bpy.types,cls.__name__):continue
            bpy.utils.register_class(cls);REGISTERED.append(cls)
        bpy.app.handlers.load_post.append(after_load);manager_bridge.bind()
        if not bpy.app.timers.is_registered(deferred):bpy.app.timers.register(deferred,first_interval=.1)
    except Exception:
        unregister();raise
def deferred():after_load();return None
def unregister():
    if bpy.app.timers.is_registered(deferred):bpy.app.timers.unregister(deferred)
    if after_load in bpy.app.handlers.load_post:bpy.app.handlers.load_post.remove(after_load)
    output.close();persistence.stop();jiggle.unregister();rigid.clear_shortcut();manager_bridge.unbind()
    while REGISTERED:bpy.utils.unregister_class(REGISTERED.pop())
    properties.unregister();translation.unregister()
