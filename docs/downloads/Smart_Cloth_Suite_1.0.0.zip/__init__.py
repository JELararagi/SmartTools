# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Smart Cloth Suite Blender Extension entry point."""

from __future__ import annotations

import bpy

from . import lifecycle
from . import runtime
from . import translation

__version__ = "2.10.6"

bl_info = {
    "name": 'Smart Cloth',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Sidebar > Smart Cloth",
    "description": "External cloth companion with batch setup, diagnostics, Quick Rigid, and Jiggle Physics.",
    "category": "Physics",
}

__addon_enabled__ = False
_RUNTIME_EXPORTS = (
    "_RUNTIME_STATE",
    "_INTEGRATED_RUNTIME_STATE",
    "ensure_runtime_initialized",
    "ensure_core_runtime_initialized",
    "schedule_core_runtime_initialization",
)


def _sync_runtime_exports() -> None:
    for name in _RUNTIME_EXPORTS:
        if hasattr(runtime, name):
            globals()[name] = getattr(runtime, name)


def get_addon_preferences(context=None):
    try:
        from . import preferences
        return preferences.get_root_preferences(context)
    except Exception:
        return None


def __getattr__(name: str):
    if str(name).startswith("__") and str(name).endswith("__"):
        raise AttributeError(name)
    return getattr(runtime, name)


def register() -> None:
    global __addon_enabled__
    lease, acquired = lifecycle.begin_generation()
    if not acquired:
        __addon_enabled__ = lease.state == "READY"
        _sync_runtime_exports()
        return

    try:
        lifecycle.register_translation(__name__, translation.I18N_DICT, scope="root.translation")
        runtime.register()
        lifecycle.mark_ready(lease)
        __addon_enabled__ = True
        _sync_runtime_exports()
    except Exception:
        __addon_enabled__ = False
        lifecycle.release_current(reason="register_rollback")
        raise


def unregister() -> None:
    global __addon_enabled__
    lease = lifecycle.current_lease()
    if lease is None:
        # No resolvable lease: this generation cannot release its exact
        # identities. Detaching this package's own @persistent handlers is
        # still mandatory and unconditional -- handlers left attached to a
        # torn-down module keep firing on every later load and save, which is
        # what escalated a dormant teardown into a process crash.
        lifecycle.sweep_dormant_package_handlers()
        __addon_enabled__ = False
        _sync_runtime_exports()
        return
    if not lifecycle.current_module_owns_lease(lease):
        # An overlapping import did not replace the visible generation. Its
        # explicit disable still retires that generation through the captured
        # exact release callback; no new-module class/RNA lookup is performed.
        lifecycle.release_current(reason="unregister_handoff")
        __addon_enabled__ = False
        _sync_runtime_exports()
        return
    try:
        runtime.unregister()
    finally:
        lifecycle.release_current(reason="unregister")
        __addon_enabled__ = False
        _sync_runtime_exports()


_sync_runtime_exports()


if __name__ == "__main__":
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
