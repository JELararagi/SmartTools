# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTENSION_ID = "smart_cloth_suite"
CONFIG_FOLDER = "Smart_Cloth_Suite"
CONFIG_FILE = "Smart_Cloth_Suite.json"
STATE_SAVE_PATH = "window_manager.smart_tools_runtime_preferences_v420.always_suite_npanel_persistence"
SECTION_OPEN_PATH = "window_manager.smart_tools_runtime_preferences_v420.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.smart_tools_runtime_preferences_v420.always_jiggle_runtime_callbacks",
    "window_manager.smart_tools_runtime_preferences_v420.always_jiggle_overlay_rest_pose",
    "window_manager.smart_tools_runtime_preferences_v420.always_jiggle_overlay_simulation",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = (
    "SMARTCLOTHSUITE_PT_main_panel_view3d_v260",
)
PERSISTENCE_ROOTS = (
    "window_manager.smart_tools_runtime_preferences_v420",
    "scene.smart_cloth_suite_companion",
    "scene.quick_rigid_settings",
    "scene.jiggle",
)
EXCLUDED_TRANSIENT_PATHS = (
    "window_manager.smart_tools_runtime_preferences_v420.legacy_storage_migrated",
    "window_manager.smart_tools_runtime_preferences_v420.name",
    "scene.smart_cloth_suite_companion.last_status",
    "scene.smart_cloth_suite_companion.last_report_path",
    "scene.smart_cloth_suite_companion.name",
    "scene.quick_rigid_settings.name",
    "scene.jiggle.name",
    "scene.jiggle.lastframe",
)
BLEND_OWNED_NPANEL_PATHS = ()
