"""One reversible-in-progress output command per window manager, streamed one garment at a time."""
import bpy
from . import garment
from .core import integration
active=None
def close(ctx=None):
    global active
    transaction=active;active=None
    if transaction:
        try:transaction['wm'].event_timer_remove(transaction['timer'])
        except (ReferenceError,RuntimeError):pass
def process(ctx,name,action):
    obj=ctx.scene.objects.get(name);mod=garment.cloth(obj) if obj else None
    if not mod:raise ValueError('The garment was removed during output.')
    with garment.selected(ctx,obj):
        if action=='FINISH':
            ret=integration.call_external_operator('object.finish_cloth',ctx,mode='APPLYCLOTH',apply_all_modifiers=False)
            if 'FINISHED' not in ret:raise ValueError('The provider cancelled the finish operation.')
            return
        with ctx.temp_override(point_cache=mod.point_cache):
            if action=='BAKE' and not mod.point_cache.is_baked:
                if bpy.ops.ptcache.bake(bake=True)!={'FINISHED'} or not mod.point_cache.is_baked:raise ValueError('Cloth cache did not bake.')
            if action=='FREE_BAKE' and mod.point_cache.is_baked:
                if bpy.ops.ptcache.free_bake()!={'FINISHED'} or mod.point_cache.is_baked:raise ValueError('Cloth cache did not release.')
def begin(op,ctx):
    global active
    if active:raise ValueError('Another output operation is in progress.')
    c=ctx.scene.smart_cloth_suite_companion;targets=garment.meshes(ctx,c);action=op.action
    if action!='FREE_BAKE' and c.stop_on_preflight_error and garment.check(ctx,c,targets):raise ValueError(c.last_status)
    names=[o.name for o in targets if garment.cloth(o)]
    if not names:raise ValueError('Select an object with a Cloth modifier.')
    if action=='FINISH' and not integration.external_status(force=True).ready:raise ValueError('Enable Simply Cloth Studio first.')
    if bpy.app.background:
        for name in names:process(ctx,name,action)
        c.last_status=f'{action} · {len(names)}';return {'FINISHED'}
    wm=ctx.window_manager;timer=wm.event_timer_add(.12,window=ctx.window)
    try:
        active=dict(operator=op.as_pointer(),names=names,action=action,index=0,wm=wm,timer=timer,scene=ctx.scene.name);wm.modal_handler_add(op)
    except Exception:
        close(ctx);raise
    return {'RUNNING_MODAL'}
def event(op,ctx,event):
    t=active
    if not t or t['operator']!=op.as_pointer():return {'CANCELLED'}
    if event.type=='ESC' or t['scene']!=ctx.scene.name:
        close(ctx);return {'CANCELLED'}
    if event.type!='TIMER':return {'PASS_THROUGH'}
    try:
        process(ctx,t['names'][t['index']],t['action']);t['index']+=1
        if t['index']<len(t['names']):return {'RUNNING_MODAL'}
        ctx.scene.smart_cloth_suite_companion.last_status=f"{t['action']} · {t['index']}";close(ctx);return {'FINISHED'}
    except (ValueError,RuntimeError,ReferenceError) as err:
        ctx.scene.smart_cloth_suite_companion.last_status=str(err);op.report({'WARNING'},str(err));close(ctx);return {'CANCELLED'}

