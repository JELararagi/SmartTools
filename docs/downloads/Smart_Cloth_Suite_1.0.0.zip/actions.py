"""Dispatch registered RNA commands to their native workflow."""
import bpy,json
from . import garment,skirt,component,bridge,rigid,jiggle,properties
from .core import integration
def core(key,op,ctx):
    pref=properties.prefs(ctx)
    if key=='show_help_popup':
        from . import ui
        ui.help_popup(ctx,op.topic);return
    if key=='copy_text':ctx.window_manager.clipboard=op.text;return
    if key=='lazy_execute_tool':
        if op.menu_id:
            from .bindings import CLASSES
            if op.menu_id not in {c.__name__ for c in CLASSES if issubclass(c,bpy.types.Menu)}:raise ValueError('Unknown menu.')
            return bpy.ops.wm.call_menu(name=op.menu_id)
        oid=op.operator_id
        if oid not in properties.DATA['operators'] or oid=='smart_core.lazy_execute_tool':raise ValueError('Unknown tool.')
        module,command=oid.split('.');params=json.loads(op.operator_props_json or '{}')
        if not isinstance(params,dict):raise ValueError('Invalid operator settings.')
        return getattr(getattr(bpy.ops,module),command)(op.execution_context,**params)
    if key=='disable_all_always_on_features':
        for n in properties.DATA['groups']['SMARTCLOTHSUITE_PG_RuntimePreferences']:
            if n.startswith('always_'):setattr(pref,n,False)
        return
    if key=='toggle_ui_section':
        n=op.section_key
        if not hasattr(pref,n):n='ui_open_'+n
    elif key=='toggle_always_on_feature':n=op.feature_key
    elif key=='toggle_jiggle_overlay_runtime':n='always_jiggle_overlay_rest_pose' if op.overlay_kind.upper() in ('REST','REST_POSE','POSE') else 'always_jiggle_overlay_simulation'
    else:
        name=op.module_name.lower();n='show_quick_rigid_tools' if 'rigid' in name else 'show_jiggle_physics_tools' if 'jiggle' in name else ''
    spec=properties.DATA['groups']['SMARTCLOTHSUITE_PG_RuntimePreferences'].get(n)
    if not spec or spec['type']!='BOOLEAN':raise ValueError('Unknown toggle.')
    setattr(pref,n,op.enable if key=='toggle_standard_npanel_tool' else not getattr(pref,n))
class Command:
    def execute(self,context):
        namespace,key=type(self).__name__.split('_OT_',1);namespace=namespace.lower()
        from .translation import localized
        c=getattr(context.scene,'smart_cloth_suite_companion',None);previous=c.last_status if c else ''
        try:
            if namespace=='smart_core':result=core(key,self,context)
            elif key=='safe_output':
                from . import output
                result=output.begin(self,context)
            elif key.startswith('skirt_'):result=skirt.execute(key,self,context)
            elif key.startswith('bridge_'):result=bridge.execute(key,self,context)
            elif key.startswith('component_'):result=component.execute(key,self,context)
            elif namespace=='smart_cloth_suite':result=garment.execute(key,self,context)
            elif 'jiggle' in key:result=jiggle.execute(key,self,context)
            else:result=rigid.execute(key,self,context)
            if namespace=='smart_cloth_suite' and c:
                c.last_status=localized(c.last_status,context) if c.last_status!=previous else self.bl_label
            return result if isinstance(result,set) else {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,OSError,TypeError) as exc:
            msg=localized(str(exc),context);c=getattr(context.scene,'smart_cloth_suite_companion',None)
            if c:c.last_status=msg
            self.report({'WARNING'},msg);return {'CANCELLED'}
