# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from .. import lifecycle

bl_info = {
    "name": "Quick Rigid",
    "author": "JELararagi",
    "version": (1, 2, 1),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Cloth",
    "description": "Speeds up the rigid body workflow with standard 3D View Sidebar N-panel panels, presets, and quick menu access.",
    "warning": "",
    "doc_url": "",
    "category": "Simulation",
}

from . import translation as i18n
from . import properties
from . import presets
from . import operators
from . import menus
from . import panels


def register(include_ui: bool = True):
    mark = lifecycle.checkpoint()
    try:
        i18n.register_translations()
        properties.register()
        operators.register()
        menus.register()
        if bool(include_ui):
            panels.register()
    except Exception:
        lifecycle.rollback_to(mark)
        raise


def unregister():
    panels.unregister()
    menus.unregister()
    operators.unregister()
    properties.unregister()
    i18n.unregister_translations()
