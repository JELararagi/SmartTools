# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import time

import bpy

from .. import lifecycle

try:
    from .. import ui_icons as _suite_ui_icons
except Exception:
    _suite_ui_icons = None


_QR_STARTUP_PANEL_GUARD_UNTIL = time.monotonic() + 3.0


def _qr_panel_context_available(context=None) -> bool:
    try:
        area = getattr(context, 'area', None)
        area_type = str(getattr(area, 'type', '') or '').upper() if area is not None else ''
        if area_type and area_type != 'VIEW_3D':
            return False
        mode = str(getattr(context, 'mode', '') or 'OBJECT').upper()
        if mode not in {'OBJECT', 'POSE'}:
            return False
        return getattr(context, 'active_object', None) is not None
    except Exception:
        return False


def _qr_startup_panel_guard_active() -> bool:
    try:
        return time.monotonic() < _QR_STARTUP_PANEL_GUARD_UNTIL
    except Exception:
        return False


def _qr_draw_startup_guard(layout, context) -> None:
    try:
        layout.label(text=_qr_ui_text('Initializing...', '初期化中...', context), icon='TIME')
    except Exception:
        pass


def _qr_panel(layout, settings, prop_name, text, icon='NONE'):
    """Standard panel disclosure bound to a stored bool; returns the body layout or None when closed."""
    try:
        header, body = layout.panel_prop(settings, prop_name)
    except Exception:
        return None
    header.label(text=text, icon=icon)
    return body


def _qr_is_japanese_locale(context=None) -> bool:
    view = None
    try:
        view = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else None
    except Exception:
        view = None
    if view is None:
        try:
            view = getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        except Exception:
            view = None
    try:
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
    except Exception:
        return False
    candidates = []
    try:
        candidates.append(str(getattr(view, 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _qr_ui_text(en: str, ja: str, context=None) -> str:
    return str(ja if _qr_is_japanese_locale(context) else en)




def _qr_custom_icon_id(icon_name: str) -> int:
    try:
        getter = getattr(_suite_ui_icons, 'get_icon_id', None)
        return int(getter(str(icon_name)) if callable(getter) else 0)
    except Exception:
        return 0


def _qr_operator_with_custom_icon(layout, operator_id: str, *, text: str, custom_icon: str = '', fallback_icon: str = 'NONE', **props):
    icon_value = _qr_custom_icon_id(custom_icon) if custom_icon else 0
    try:
        if icon_value:
            op = layout.operator(operator_id, text=text, icon_value=icon_value)
        else:
            op = layout.operator(operator_id, text=text, icon=fallback_icon)
    except TypeError:
        if icon_value:
            op = layout.operator(operator_id, text=text, icon_value=icon_value)
        else:
            op = layout.operator(operator_id, text=text, icon=fallback_icon)
    for key, value in props.items():
        try:
            setattr(op, key, value)
        except Exception:
            pass
    return op

class VIEW3D_PT_QuickRigid(bpy.types.Panel):
    """Panel for Quick Rigid tools"""
    bl_label = "Quick Rigid"
    bl_idname = "VIEW3D_PT_quick_rigid_scs_v179"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Cloth'
    bl_options = {'DEFAULT_CLOSED'}
   
    @classmethod
    def poll(cls, context):
        return _qr_panel_context_available(context)

    def draw_header(self, context):
        # Use a built-in icon only. Loading custom preview images from a draw
        # callback can destabilize Blender during panel refresh on some systems.
        try:
            self.layout.label(text="", icon='PHYSICS')
        except Exception:
            pass
   
    def draw(self, context):
        layout = self.layout
        if _qr_startup_panel_guard_active():
            _qr_draw_startup_guard(layout, context)
            return
        layout.scale_y = 1.2
        
        # Get quick rigid settings - moved to the top so we can use it everywhere
        scene = getattr(context, 'scene', None)
        settings = getattr(scene, 'quick_rigid_settings', None) if scene is not None else None
        if settings is None:
            layout.label(text=_qr_ui_text('Quick Rigid settings are not available.', 'Quick Rigid 設定を取得できません。', context), icon='ERROR')
            return

        menu_box = layout.box()
        menu_box.label(text=_qr_ui_text('Quick Menu', 'クイックメニュー', context), icon='MENU_PANEL')
        menu_row = menu_box.row(align=True)
        menu_op = menu_row.operator('wm.call_menu', text=_qr_ui_text('Open Quick Rigid Menu', 'Quick Rigid メニューを開く', context), icon='COLLAPSEMENU')
        menu_op.name = 'VIEW3D_MT_quick_rigid'
        submenu_col = menu_box.column(align=True)
        submenu_col.label(text=_qr_ui_text('Quick Rigid Submenus', 'Quick Rigid サブメニュー', context), icon='MENU_PANEL')
        submenu_col.menu('VIEW3D_MT_quick_rigid_main_submenu', text=_qr_ui_text('Main Settings', 'メイン設定', context), icon='SETTINGS')
        submenu_col.menu('VIEW3D_MT_quick_rigid_physics_submenu', text=_qr_ui_text('Physical Properties', '物理プロパティ', context), icon='PHYSICS')
        submenu_col.menu('VIEW3D_MT_quick_rigid_sim_submenu', text=_qr_ui_text('Simulation Settings', 'シミュレーション設定', context), icon='PLAY')
        submenu_col.menu('VIEW3D_MT_quick_rigid_presets_submenu', text=_qr_ui_text('Presets', 'プリセット', context), icon='PRESET')
        submenu_col.menu('VIEW3D_MT_quick_rigid_bake_submenu', text=_qr_ui_text('Bake Options', 'ベイクオプション', context), icon='KEY_HLT')
        
        active_object = getattr(context, 'active_object', None)
        if active_object is None:
            layout.label(text=_qr_ui_text('Select a mesh to add a rigid body', '剛体を追加するメッシュを選択してください', context))
            # Still show addon settings even when nothing is selected
            self.draw_settings_box(context, layout, settings)
            return
            
        # Check if there are selected mesh objects
        selected_meshes = [active_object] if getattr(active_object, 'type', None) == 'MESH' else []
        if not selected_meshes:
            layout.label(text=_qr_ui_text('Select a mesh to add a rigid body', '剛体を追加するメッシュを選択してください', context))
            # Still show addon settings even when no mesh is selected
            self.draw_settings_box(context, layout, settings)
            return
            
        # Show info about selection count if multiple objects - moved to the top
        if len(selected_meshes) > 1:
            rb_count = len([obj for obj in selected_meshes if obj.rigid_body])
            layout.label(text=_qr_ui_text("%(count)s objects selected (%(rigid)s with rigid bodies)", "%(count)s 個のオブジェクトを選択中（剛体付き %(rigid)s 個）", context) % {'count': len(selected_meshes), 'rigid': rb_count})
            
        # Add rigid body box - always show this
        box = layout.box()
        box = _qr_panel(box, settings, "show_add_section", _qr_ui_text('Add Rigid Body:', '剛体追加:', context), 'PHYSICS')
        
        # Only show contents if expanded
        if box is not None:
            row = box.column(align=True)
            row.operator("object.add_active_rigid_body", text=_qr_ui_text('Add Active', 'アクティブを追加', context), icon='MESH_MONKEY')
            row.operator("object.add_passive_rigid_body", text=_qr_ui_text('Add Passive', 'パッシブを追加', context), icon='MESH_CUBE')
            
            # Remove button with red color
            remove_row = box.row()
            remove_row.alert = True  # This makes the button red
            remove_row.operator("rigidbody.object_remove", text=_qr_ui_text('Remove Rigid Body', '剛体を削除', context), icon='X')

            # Show rigid body type inside the box if active object has rigid body
            obj = context.active_object
            if obj and obj.rigid_body:
                type_row = box.row()
                icon = 'PINNED' if obj.rigid_body.type == 'PASSIVE' else 'UNPINNED'
                type_row.label(text=_qr_ui_text("Type: %(type)s", "タイプ: %(type)s", context) % {'type': _qr_ui_text('Passive', 'パッシブ', context) if obj.rigid_body.type == 'PASSIVE' else _qr_ui_text('Active', 'アクティブ', context)}, icon=icon)

        # Get the active object and check for rigid body
        obj = context.active_object
        has_rigid_body = obj and hasattr(obj, "rigid_body") and obj.rigid_body is not None
        
        # Only show the rigid body specific settings if active object has rigid body
        if has_rigid_body:
            # Main settings - collapsible
            box = layout.box()
            box = _qr_panel(box, settings, "show_main_settings", _qr_ui_text('Main Settings:', 'メイン設定:', context), 'SETTINGS')
            
            if box is not None:
                # Collision shape property
                col = box.column(align=True)
                col.prop(obj.rigid_body, "collision_shape", text=_qr_ui_text('Shape', '形状', context), icon='MESH_ICOSPHERE')
                
                # Add a small space between shape and animated properties
                box.separator(factor=0.5)
                
                # Animated property 
                anim_row = box.row()
                anim_row.prop(obj.rigid_body, "kinematic", text=_qr_ui_text('Animated', 'アニメーション', context), icon='RENDER_ANIMATION', toggle=True)
                
                # Copy settings button
                box.separator(factor=0.7)
                copy_row = box.row(align=True)
                copy_row.operator("rigidbody.object_settings_copy", text=_qr_ui_text('Copy Settings', '設定をコピー', context), icon='COPYDOWN')
            
            # Mass settings - collapsible
            box = layout.box()
            box = _qr_panel(box, settings, "show_mass", _qr_ui_text('Mass:', '質量:', context), 'PHYSICS')
            
            if box is not None:
                col = box.column(align=True)
                col.prop(obj.rigid_body, "mass", slider=True)
                col.operator("rigidbody.mass_calculate", text=_qr_ui_text('Calculate Mass', '質量を計算', context), icon='FILE_REFRESH')

            # Surface Response - collapsible
            box = layout.box()
            box = _qr_panel(box, settings, "show_surface", _qr_ui_text('Surface Response:', '表面応答:', context), 'MOD_PHYSICS')
            
            if box is not None:
                col = box.column(align=True)
                col.prop(obj.rigid_body, "friction", slider=True)
                col.prop(obj.rigid_body, "restitution", text=_qr_ui_text('Bounciness', '反発', context), slider=True)

            # Gravity and Simulation - collapsible
            box = layout.box()
            box = _qr_panel(box, settings, "show_simulation", _qr_ui_text('Simulation:', 'シミュレーション:', context), 'WORLD')
            
            if box is not None:
                col = box.column(align=True)
                col.prop(scene, "use_gravity", text=_qr_ui_text('Gravity', '重力', context))
                if scene.use_gravity:
                    col.prop(scene, "gravity", text="")
                
                col.separator()
                if scene.rigidbody_world:
                    col.prop(scene.rigidbody_world, "time_scale", text=_qr_ui_text('Sim Speed', 'シム速度', context), slider=True)
            
            # Presets section - only show when we have a rigid body
            box = layout.box()
            box = _qr_panel(box, settings, "show_presets", _qr_ui_text('Presets:', 'プリセット:', context), 'PRESET')
            
            if box is not None:
                # Create a grid layout for presets - 1 column
                grid = box.column()
                
                # Check if any presets exist
                has_presets = False
                if hasattr(scene, "rigid_body_presets") and len(scene.rigid_body_presets) > 0:
                    has_presets = True
                
                # If no presets exist, show info message
                if not has_presets:
                    info_row = grid.row(align=True)
                    info_row.alignment = 'CENTER'
                    info_row.label(text=_qr_ui_text('No presets available', '利用可能なプリセットはありません', context))
                    
                    info_row = grid.row(align=True)
                    info_row.alignment = 'CENTER'
                    info_row.label(text=_qr_ui_text('Add one below', '下で追加できます', context))
                    
                    grid.separator()
                else:
                    # User presets from the scene - each with delete button
                    for preset in scene.rigid_body_presets:
                        # Create a row for this preset with the delete button
                        user_row = grid.row(align=True)
                        
                        # Preset button (takes most of the row)
                        if preset.name.strip():
                            preset_op = user_row.operator("object.apply_rigid_body_preset", text=preset.name, translate=False)
                            preset_op.preset_name = preset.name
                        else:
                            user_row.label(text=_qr_ui_text('(No name)', '（名前なし）', context))
                        
                        # Delete button - explicit X button
                        delete_op = user_row.operator("object.delete_rigid_body_preset", text="", icon='X')
                        delete_op.preset_name = preset.name
                
                # Add new preset button
                box.separator()
                row = box.row(align=True)
                row.operator("object.add_rigid_body_preset", text=_qr_ui_text('Add New Preset', '新規プリセットを追加', context), icon='ADD')
        
        # Only show Bake section if there's a rigid body and a rigidbody_world
        if has_rigid_body and scene.rigidbody_world:
            bake_box = layout.box()
            bake_box = _qr_panel(bake_box, settings, "show_bake", _qr_ui_text('Bake:', 'ベイク:', context), 'KEY_HLT')
            
            if bake_box is not None:
                # Nice visual separation
                bake_box.separator()
                
                # Point Cache settings reference
                rb_world = scene.rigidbody_world
                point_cache = rb_world.point_cache
                
                # Main bake options section
                bake_col = bake_box.column(align=True)
                
                # All bake options vertically stacked like in default Blender
                bake_col.scale_y = 1.2
                bake_col.operator("rigidbody.bake_to_keyframes", text=_qr_ui_text('Bake to Keyframes', 'キーフレームへベイク', context), icon='ACTION')
                bake_col.operator("ptcache.bake_all", text=_qr_ui_text('Bake All Dynamics', '全ダイナミクスをベイク', context), icon='PHYSICS').bake=True
                bake_col.operator("ptcache.bake", text=_qr_ui_text('Calculate to Frame', '現在フレームまで計算', context), icon='PREVIEW_RANGE')
                
                cache_op = bake_col.operator("ptcache.bake", text=_qr_ui_text('Current Cache to Bake', '現在キャッシュをベイク化', context), icon='FILE_TICK')
                cache_op.bake = True
                
                # Delete button with red color at the bottom
                bake_col.separator()
                delete_row = bake_col.row(align=True)
                delete_row.alert = True  # This makes the button red
                _qr_operator_with_custom_icon(delete_row, 'ptcache.free_bake_all', text=_qr_ui_text('Delete All Bakes', 'すべてのベイクを削除', context), custom_icon='', fallback_icon='TRASH')
                
                bake_box.separator()
                
                # Frame range settings - collapsible
                timeline_box = bake_box.box()
                timeline_box = _qr_panel(timeline_box, settings, "show_timeline", _qr_ui_text('Timeline Settings:', 'タイムライン設定:', context), 'TIME')
                
                if timeline_box is not None:
                    # Frame range in a clean row with better visual arrangement
                    frame_row = timeline_box.row(align=True)
                    frame_row.label(text=_qr_ui_text('Frame Range:', 'フレーム範囲:', context))
                    
                    range_row = timeline_box.row(align=True)
                    range_row.prop(point_cache, "frame_start", text=_qr_ui_text('Start', '開始', context))
                    range_row.prop(point_cache, "frame_end", text=_qr_ui_text('End', '終了', context))
                    
                    # Add step as part of timeline settings
                    step_row = timeline_box.row()
                    step_row.prop(point_cache, "step", text=_qr_ui_text('Cache Step', 'キャッシュステップ', context))
                
                # Advanced simulation settings - collapsible
                sim_box = bake_box.box()
                sim_box = _qr_panel(sim_box, settings, "show_sim_settings", _qr_ui_text('Simulation Settings:', 'シミュレーション設定:', context), 'SETTINGS')
                
                if sim_box is not None:
                    # Solver settings with better organization
                    col = sim_box.column(align=True)
                    col.prop(scene.rigidbody_world, "solver_iterations", text=_qr_ui_text('Solver Iterations', 'ソルバー反復回数', context))
                    col.prop(scene.rigidbody_world, "use_split_impulse", text=_qr_ui_text('Split Impulse', 'スプリットインパルス', context))
                
                # Cache information - collapsible
                cache_box = bake_box.box()
                cache_box = _qr_panel(cache_box, settings, "show_cache_status", _qr_ui_text('Cache Status:', 'キャッシュ状態:', context), 'NONE')
                
                if cache_box is not None:
                    # Status indicator with appropriate icons
                    status_row = cache_box.row()
                    if point_cache.is_baked:
                        status_row.label(text=_qr_ui_text('Baked', 'ベイク済み', context), icon='CHECKMARK')
                    elif point_cache.is_baking:
                        status_row.label(text=_qr_ui_text('Baking in Progress...', 'ベイク中...', context), icon='TEMP')
                    else:
                        status_row.label(text=_qr_ui_text('Not Baked', '未ベイク', context), icon='X')
                    
                    # Disk cache options with better organization
                    cache_box.separator()
                    
                    # Check if blend file is saved before enabling disk cache
                    is_saved = bool(bpy.data.filepath)
                    disk_row = cache_box.row()
                    disk_row.enabled = is_saved  # Gray out if file is not saved
                    disk_row.prop(point_cache, "use_disk_cache", text=_qr_ui_text('Disk Cache', 'ディスクキャッシュ', context), icon='DISK_DRIVE')
                    
                    if not is_saved:
                        # Show message explaining why it's disabled
                        info_row = cache_box.row()
                        info_row.alignment = 'CENTER'
                        info_row.label(text=_qr_ui_text('Save file first', '先に保存してください', context), icon='ERROR')
                    
                    # Only show additional disk options when enabled and file is saved
                    if point_cache.use_disk_cache and is_saved:
                        disk_col = cache_box.column(align=True)
                        disk_col.prop(point_cache, "use_library_path", text=_qr_ui_text('Use Lib Path', 'ライブラリパスを使用', context))
                        disk_col.prop(point_cache, "compression", text=_qr_ui_text('Compression', '圧縮', context))
                        disk_col.separator()
                        disk_col.prop(point_cache, "filepath", text=_qr_ui_text('File Path', 'ファイルパス', context))
        
        # Always show settings box at the bottom
        self.draw_settings_box(context, layout, settings)
    
    def draw_settings_box(self, context, layout, settings):
        """Draw the addon settings box"""
        # Addon Settings - collapsible
        settings_box = layout.box()
        settings_box = _qr_panel(settings_box, settings, "show_settings", _qr_ui_text('Addon Settings:', 'アドオン設定:', context), 'PREFERENCES')
        
        if settings_box is not None:
            col = settings_box.column()
            doc_row = col.row()
            doc_op = doc_row.operator("wm.url_open", text=_qr_ui_text("Official Contact", "公式連絡先", context), icon='URL')
            doc_op.url = ""

            tutorial_row = col.row()
            tutorial_op = tutorial_row.operator("wm.url_open", text=_qr_ui_text("Video Tutorials", "動画チュートリアル", context), icon='HELP')
            tutorial_op.url = ""

            support_row = col.row()
            support_op = support_row.operator("wm.url_open", text=_qr_ui_text("Support Contact", "サポート窓口", context), icon='ERROR')
            support_op.url = ""

            col.separator()

            version_row = col.row()
            version_row.alignment = 'CENTER'
            version_row.label(text=_qr_ui_text("Quick Rigid for Blender 5.1.0", "Blender 5.1.0 用 Quick Rigid", context))

            credit_row = col.row()
            credit_row.alignment = 'CENTER'
            credit_row.label(text=_qr_ui_text('Copyright (C) 2026 JELararagi', 'Copyright (C) 2026 JELararagi', context))



def _quick_rigid_safe_panel_call(func, fallback_label):
    del fallback_label
    return func

def _safe_register_class(cls):
    return lifecycle.register_class(cls, scope='quick.panels.classes')


def _safe_unregister_class(cls):
    del cls
    lifecycle.release_scope('quick.panels.classes')

# List of classes to register
classes = [
    VIEW3D_PT_QuickRigid
]

def register():
    mark = lifecycle.checkpoint()
    try:
        for cls in classes:
            lifecycle.register_class(cls, scope='quick.panels.classes')
    except Exception:
        lifecycle.rollback_to(mark)
        raise


def unregister():
    lifecycle.release_scope('quick.panels.classes')
