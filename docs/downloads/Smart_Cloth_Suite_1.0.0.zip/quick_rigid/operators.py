# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from .. import lifecycle
from bpy.props import StringProperty

from .presets import RigidBodyPreset, RigidBodyPresetManager
from .properties import _qr_ui_text

def _unnamed_preset_indices(scene):
    return [index for index, preset in enumerate(getattr(scene, "rigid_body_presets", ())) if not preset.name.strip()]

def _open_preset_chooser(operator, context, title, icon):
    """Let the user pick a saved preset; the chosen entry runs the same operator with its name."""
    names = [preset.name for preset in getattr(context.scene, "rigid_body_presets", ()) if preset.name.strip()]
    if not names:
        operator.report({'WARNING'}, _qr_ui_text("No presets available", "利用可能なプリセットはありません", context))
        return {'CANCELLED'}
    operator_id = operator.bl_idname

    def _draw(menu, _context):
        for name in names:
            menu.layout.operator(operator_id, text=name, translate=False, icon=icon).preset_name = name

    context.window_manager.popup_menu(_draw, title=title, icon='PRESET')
    return {'INTERFACE'}

class AddPassiveRigidBody(bpy.types.Operator):
    """Add passive rigid bodies to all selected mesh objects"""
    bl_idname = "object.add_passive_rigid_body"
    bl_label = "Add Passive Rigid Body"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if at least one selected object is a mesh
        return any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        # Store originally selected objects
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        original_active_object = context.active_object
        
        if not selected_objects:
            self.report({'ERROR'}, _qr_ui_text("Rigid bodies can only be added to mesh objects", "剛体はメッシュオブジェクトにのみ追加できます。", context))
            return {'CANCELLED'}
        
        # Add passive rigid body to each selected mesh object
        for obj in selected_objects:
            # Set the object as active
            context.view_layer.objects.active = obj
            # Add rigid body as passive
            bpy.ops.rigidbody.objects_add(type='PASSIVE')
        
        # Restore the original active object if it was in the selected objects
        # or set the active object to the last processed object with a rigid body
        if original_active_object in selected_objects:
            context.view_layer.objects.active = original_active_object
        else:
            # Set the last processed object as active so UI will show settings
            context.view_layer.objects.active = selected_objects[-1]
        
        # Report how many objects were affected
        self.report({'INFO'}, _qr_ui_text("Added passive rigid bodies to %(count)s objects", "%(count)s 個のオブジェクトへ パッシブ剛体を追加しました。", context) % {'count': len(selected_objects)})
        return {'FINISHED'}

class AddActiveRigidBody(bpy.types.Operator):
    """Add active rigid bodies to all selected mesh objects"""
    bl_idname = "object.add_active_rigid_body"
    bl_label = "Add Active Rigid Body"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if at least one selected object is a mesh
        return any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        # Store originally selected objects
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        original_active_object = context.active_object
        
        if not selected_objects:
            self.report({'ERROR'}, _qr_ui_text("Rigid bodies can only be added to mesh objects", "剛体はメッシュオブジェクトにのみ追加できます。", context))
            return {'CANCELLED'}
        
        # Add active rigid body to each selected mesh object
        for obj in selected_objects:
            # Set the object as active
            context.view_layer.objects.active = obj
            # Add rigid body as active
            bpy.ops.rigidbody.objects_add(type='ACTIVE')
        
        # Restore the original active object if it was in the selected objects
        # or set the active object to the last processed object with a rigid body
        if original_active_object in selected_objects:
            context.view_layer.objects.active = original_active_object
        else:
            # Set the last processed object as active so UI will show settings
            context.view_layer.objects.active = selected_objects[-1]
        
        # Report how many objects were affected
        self.report({'INFO'}, _qr_ui_text("Added active rigid bodies to %(count)s objects", "%(count)s 個のオブジェクトへ アクティブ剛体を追加しました。", context) % {'count': len(selected_objects)})
        return {'FINISHED'}

class RIGID_BODY_OT_toggle_animated(bpy.types.Operator):
    """Toggle the animated state of the rigid body"""
    bl_idname = "rigid_body.toggle_animated"
    bl_label = "Toggle Animated State"
    bl_description = "Toggle the animated state of the rigid body"
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj and obj.rigid_body:
            obj.rigid_body.kinematic = not obj.rigid_body.kinematic
        return {'FINISHED'}

class AddRigidBodyPreset(bpy.types.Operator):
    """Add a new preset based on current rigid body settings"""
    bl_idname = "object.add_rigid_body_preset"
    bl_label = "Add Rigid Body Preset"
    bl_options = {'UNDO'}
    
    preset_name: StringProperty(
        name="Preset Name",
        description="Name of the preset to save",
        default="New Preset"
    )
    
    overwrite: bpy.props.BoolProperty(
        name="Overwrite Existing",
        description="Overwrite existing preset with the same name",
        default=False
    )
    
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.rigid_body
    
    def invoke(self, context, event):
        # Show dialog to get preset name
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")
        
        # Check if a preset with this name already exists
        preset_exists = False
        if hasattr(context.scene, "rigid_body_presets"):
            for preset in context.scene.rigid_body_presets:
                if preset.name == self.preset_name:
                    preset_exists = True
                    break
        
        # Show warning and checkbox if preset already exists
        if preset_exists:
            warning_row = layout.row()
            warning_row.alert = True
            warning_row.label(text=_qr_ui_text("Warning: Preset '%(preset)s' already exists!", "警告: プリセット '%(preset)s' は既に存在します。", context) % {'preset': self.preset_name})
            layout.prop(self, "overwrite", text=_qr_ui_text("Overwrite existing preset", "既存プリセットを上書き", context))
    
    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.rigid_body:
            self.report({'ERROR'}, _qr_ui_text("No active object with rigid body", "アクティブな剛体オブジェクトがありません。", context))
            return {'CANCELLED'}
            
        # A preset without a name could never be chosen again
        if not self.preset_name.strip():
            self.report({'WARNING'}, _qr_ui_text("Enter a preset name", "プリセット名を入力してください。", context))
            return {'CANCELLED'}

        # Check if preset with this name already exists
        preset_exists = False
        if hasattr(context.scene, "rigid_body_presets"):
            for preset in context.scene.rigid_body_presets:
                if preset.name == self.preset_name:
                    preset_exists = True
                    break
        
        # If preset exists and user didn't choose to overwrite, cancel
        if preset_exists and not self.overwrite:
            self.report({'WARNING'}, _qr_ui_text("Preset '%(preset)s' already exists. Choose a different name or enable overwrite.", "プリセット '%(preset)s' は既に存在します。別の名前にするか、上書きを有効にしてください。", context) % {'preset': self.preset_name})
            return {'CANCELLED'}
            
        # Create preset from current settings
        preset = RigidBodyPreset.from_object(obj, self.preset_name)
        
        # Save preset to scene with both rigid body and simulation settings
        success = RigidBodyPresetManager.save_preset_to_scene(
            self.preset_name, 
            preset.settings,
            preset.simulation_settings
        )
        
        if success:
            self.report({'INFO'}, _qr_ui_text("Saved preset '%(preset)s'", "プリセット '%(preset)s' を保存しました。", context) % {'preset': self.preset_name})
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, _qr_ui_text("Failed to save preset", "プリセットの保存に失敗しました。", context))
            return {'CANCELLED'}

class ApplyRigidBodyPreset(bpy.types.Operator):
    """Apply a rigid body preset to the selected objects"""
    bl_idname = "object.apply_rigid_body_preset"
    bl_label = "Apply Rigid Body Preset"
    bl_options = {'UNDO'}
    
    preset_name: StringProperty(
        name="Preset Name",
        description="Name of the preset to apply",
        default="",
        options={'SKIP_SAVE'}
    )
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(obj.rigid_body for obj in context.selected_objects)
    
    def invoke(self, context, event):
        if self.preset_name:
            return self.execute(context)
        return _open_preset_chooser(self, context, _qr_ui_text("Choose a preset to apply", "適用するプリセットを選択", context), 'IMPORT')
    
    def execute(self, context):
        if not self.preset_name:
            self.report({'ERROR'}, _qr_ui_text("No preset name specified", "プリセット名が指定されていません。", context))
            return {'CANCELLED'}
            
        # Get selected objects with rigid bodies
        selected_rb_objects = [obj for obj in context.selected_objects if obj.rigid_body]
        if not selected_rb_objects:
            self.report({'ERROR'}, _qr_ui_text("No selected objects with rigid bodies", "剛体付きの選択オブジェクトがありません。", context))
            return {'CANCELLED'}
            
        # Apply preset to all selected objects with rigid bodies
        count = 0
        for obj in selected_rb_objects:
            if RigidBodyPresetManager.apply_preset_by_name(self.preset_name, obj):
                count += 1
                
        if count > 0:
            self.report({'INFO'}, _qr_ui_text("Applied preset '%(preset)s' to %(count)s objects", "プリセット '%(preset)s' を %(count)s 個のオブジェクトへ適用しました。", context) % {'preset': self.preset_name, 'count': count})
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, _qr_ui_text("Failed to apply preset '%(preset)s'", "プリセット '%(preset)s' の適用に失敗しました。", context) % {'preset': self.preset_name})
            return {'CANCELLED'}

class DeleteRigidBodyPreset(bpy.types.Operator):
    """Delete a saved rigid body preset"""
    bl_idname = "object.delete_rigid_body_preset"
    bl_label = "Delete Rigid Body Preset"
    bl_options = {'UNDO'}
    
    preset_name: StringProperty(
        name="Preset Name",
        description="Name of the preset to delete",
        default="",
        options={'SKIP_SAVE'}
    )
    
    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, "rigid_body_presets")
    
    def invoke(self, context, event):
        if self.preset_name or _unnamed_preset_indices(context.scene):
            return self.execute(context)
        return _open_preset_chooser(self, context, _qr_ui_text("Choose a preset to delete", "削除するプリセットを選択", context), 'TRASH')
    
    def execute(self, context):
        if not self.preset_name:
            # Older files may hold a row saved without a name; nothing else can reach it
            unnamed = _unnamed_preset_indices(context.scene)
            if unnamed:
                for index in reversed(unnamed):
                    context.scene.rigid_body_presets.remove(index)
                self.report({'INFO'}, _qr_ui_text("Deleted the preset without a name", "名前のないプリセットを削除しました。", context))
                return {'FINISHED'}
            self.report({'ERROR'}, _qr_ui_text("No preset name specified", "プリセット名が指定されていません。", context))
            return {'CANCELLED'}

        scene = context.scene
        if not hasattr(scene, "rigid_body_presets"):
            self.report({'ERROR'}, _qr_ui_text("No presets available", "利用可能なプリセットはありません", context))
            return {'CANCELLED'}
            
        # Find and remove the preset
        for i, preset in enumerate(scene.rigid_body_presets):
            if preset.name == self.preset_name:
                scene.rigid_body_presets.remove(i)
                self.report({'INFO'}, _qr_ui_text("Deleted preset '%(preset)s'", "プリセット '%(preset)s' を削除しました。", context) % {'preset': self.preset_name})
                return {'FINISHED'}
                
        self.report({'ERROR'}, _qr_ui_text("Preset '%(preset)s' not found", "プリセット '%(preset)s' が見つかりません。", context) % {'preset': self.preset_name})
        return {'CANCELLED'}

class ApplyShortcutKey(bpy.types.Operator):
    """Copy manual shortcut registration data for the Quick Rigid menu"""
    bl_idname = "quick_rigid.apply_shortcut_key"
    bl_label = "Copy Manual Shortcut Registration"
    bl_description = "Copy the Quick Rigid shortcut registration details so you can add the shortcut yourself in Preferences > Keymap"
    bl_options = set()
    _sms_no_undo = True
    
    def execute(self, context):
        from .menus import build_manual_shortcut_info

        info = build_manual_shortcut_info(context)
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, _qr_ui_text("Clipboard is not available", "クリップボードが利用できません。", context))
            return {'CANCELLED'}
        try:
            wm.clipboard = str(info.get('copy_text') or '')
        except Exception:
            self.report({'ERROR'}, _qr_ui_text("Could not copy shortcut setup", "ショートカット設定のコピーに失敗しました。", context))
            return {'CANCELLED'}

        combo_text = str(info.get('shortcut_combo') or 'U')
        self.report({'INFO'}, _qr_ui_text("Copied manual Quick Rigid shortcut setup for %(combo)s. Register it yourself in Preferences > Keymap", "Quick Rigid の手動ショートカット設定 %(combo)s をコピーしました。プリファレンス > キーマップ で手動登録してください。", context) % {'combo': combo_text})
        return {'FINISHED'}


def _safe_register_class(cls):
    return lifecycle.register_class(cls, scope='quick.operators.classes')


def _safe_unregister_class(cls):
    del cls
    lifecycle.release_scope('quick.operators.classes')

# List of classes to register
classes = [
    AddPassiveRigidBody,
    AddActiveRigidBody,
    RIGID_BODY_OT_toggle_animated,
    AddRigidBodyPreset,
    ApplyRigidBodyPreset,
    DeleteRigidBodyPreset,
    ApplyShortcutKey
]

def register():
    mark = lifecycle.checkpoint()
    try:
        for cls in classes:
            lifecycle.register_class(cls, scope='quick.operators.classes')
    except Exception:
        lifecycle.rollback_to(mark)
        raise


def unregister():
    lifecycle.release_scope('quick.operators.classes')
