"""Damped world-space tip springs with wind, collision and reversible pose baking."""
from math import exp,sin
import bpy,json
from mathutils import Vector,Quaternion
from bpy.app.handlers import persistent
from . import properties
states={};original={};drawing={};last_frame={};baking=False;pending=None
def target_bones(arm):return [p for p in arm.pose.bones if p.jiggle.enable]
def restore():
    for arm_name,bone_name in tuple(original):
        arm=bpy.data.objects.get(arm_name);p=arm.pose.bones.get(bone_name) if arm and arm.type=='ARMATURE' else None
        if p:p.matrix_basis=original[arm_name,bone_name]
    original.clear()
def reset():
    restore();states.clear();last_frame.clear()
def pinned(p):return p.head if not p.parent else p.parent.tail if p.bone.use_connect else p.head
def project(pos,collider,padding,friction,velocity):
    if not collider or collider.type!='MESH':return pos,velocity
    w=collider.matrix_world;ok,surface,normal,index=collider.closest_point_on_mesh(w.inverted_safe()@pos)
    if not ok:return pos,velocity
    surface=w@surface;normal=(w.to_3x3().inverted_safe().transposed()@normal).normalized()
    d=(pos-surface).dot(normal)
    if d<padding:
        pos=pos+normal*(padding-d);velocity=(velocity-normal*min(0.,velocity.dot(normal)))*(1-friction)
    return pos,velocity
def simulate(scene,force=False):
    options=scene.jiggle
    if not force:
        if not options.enable:return
        if not options.simulate_during_scrub and not any(w.screen.is_animation_playing for w in bpy.context.window_manager.windows):return
    frame=scene.frame_current;scene_key=scene.as_pointer();previous=last_frame.get(scene_key);last_frame[scene_key]=frame
    restart=previous is None or abs(frame-previous)>1 or (frame<previous and not options.loop)
    substeps=max(1,min(40,options.substeps));h=scene.render.fps_base/max(1,scene.render.fps)/substeps
    for arm in scene.objects:
        if arm.type!='ARMATURE' or not arm.jiggle.enable or arm.jiggle.mute or (arm.jiggle.freeze and not force):continue
        world=arm.matrix_world;inverse=world.inverted_safe();bones=sorted(target_bones(arm),key=lambda b:len(b.parent_recursive))
        rest={p.name:(world@p.head,world@p.tail,p.matrix.copy()) for p in bones};pose={};ends={}
        for p in bones:
            ident=(arm.name,p.name);root,tip,matrix=rest[p.name];length=max(.00001,(tip-root).length);original[ident]=p.matrix_basis.copy()
            parent=p.parent;anchor=root.copy()
            if parent and parent.name in ends:anchor+=ends[parent.name]-rest[parent.name][1]
            previous_state=None if restart else states.get(ident)
            head,velocity_head,tail,velocity_tip=previous_state or (root.copy(),Vector(),tip.copy(),Vector())
            stiffness=10+49*p.jiggle_angle_elasticity;root_stiff=stiffness*(1+1.7*p.jiggle_root_elasticity)
            drag=6+10*p.jiggle_air_drag;gravity=scene.gravity*(options.gravity*p.jiggle_gravity)
            for j in range(substeps):
                if p.bone.use_connect:head=anchor.copy();velocity_head.zero()
                else:
                    acceleration=(anchor-head)*root_stiff+gravity*(.75 if parent and parent.name in ends else 1)
                    velocity_head=velocity_head*exp(-drag*h)+acceleration*h;head+=velocity_head*h
                force_tip=(head+(tip-root)-tail)*stiffness+gravity
                if options.enable_wind:
                    gust=1+.25*sin(frame*options.wind_evolution_speed+len(p.name)*options.wind_turbulence_scale)
                    force_tip+=Vector(options.wind_direction)*options.wind_speed*gust
                velocity_tip=velocity_tip*exp(-drag*h)+force_tip*h;tail+=velocity_tip*h
                for _ in range(max(1,min(16,options.iterations))):
                    axis=tail-head
                    if axis.length>1e-8:tail=tail.lerp(head+axis.normalized()*length,p.jiggle_length_elasticity)
                colliders=[p.jiggle.collider] if p.jiggle.collider_type=='Object' else (p.jiggle.collider_collection.all_objects if p.jiggle.collider_collection else [])
                for collider in colliders:tail,velocity_tip=project(tail,collider,p.jiggle_collision_radius,p.jiggle_friction,velocity_tip)
            blend=max(0,min(1,p.jiggle_blend*(1-.5*p.jiggle_elasticity_soften)));new_head=root.lerp(head,blend);new_tip=tip.lerp(tail,blend)
            old_dir=inverse@tip-inverse@root;new_dir=inverse@new_tip-inverse@new_head
            desired=old_dir.rotation_difference(new_dir).to_matrix().to_4x4()@matrix if old_dir.length and new_dir.length else matrix.copy()
            desired.translation=inverse@new_head;pose[p.name]=desired
            if parent:
                parent_matrix=pose.get(parent.name,parent.matrix)
                p.matrix_basis=p.bone.convert_local_to_pose(desired,p.bone.matrix_local,parent_matrix=parent_matrix,parent_matrix_local=parent.bone.matrix_local,invert=True)
            else:p.matrix_basis=p.bone.convert_local_to_pose(desired,p.bone.matrix_local,invert=True)
            ends[p.name]=new_tip;states[ident]=(head.copy(),velocity_head.copy(),tail.copy(),velocity_tip.copy())
            p.jiggle.position_last1=p.jiggle.position1;p.jiggle.position_last2=p.jiggle.position2;p.jiggle.position1=new_head;p.jiggle.position2=new_tip;p.jiggle.rest_pose_position1=root;p.jiggle.rest_pose_position2=tip
@persistent
def pre(scene,*unused):
    if not baking:restore()
@persistent
def post(scene,*unused):
    if not baking:simulate(scene)
def overlays(pref):
    for key,prop in [('REST','always_jiggle_overlay_rest_pose'),('SIM','always_jiggle_overlay_simulation')]:
        enabled=bool(pref and getattr(pref,prop))
        if enabled and key not in drawing and not bpy.app.background:
            drawing[key]=bpy.types.SpaceView3D.draw_handler_add(draw,(key,),'WINDOW','POST_VIEW')
        elif not enabled and key in drawing:bpy.types.SpaceView3D.draw_handler_remove(drawing.pop(key),'WINDOW')
def draw(key):
    import gpu
    from gpu_extras.batch import batch_for_shader
    lines=[]
    for o in bpy.context.scene.objects:
        if o.type=='ARMATURE' and o.jiggle.enable:
            for b in target_bones(o):
                if key=='SIM':lines.extend([b.jiggle.position1[:],b.jiggle.position2[:]])
                else:lines.extend([o.matrix_world@b.bone.head_local,o.matrix_world@b.bone.tail_local])
    if lines:
        shader=gpu.shader.from_builtin('UNIFORM_COLOR');shader.bind();shader.uniform_float('color',(.27,.85,.75,1.) if key=='SIM' else (.91,.67,.27,1.));batch_for_shader(shader,'LINES',{'pos':lines}).draw(shader)
def sync(ctx=None,pref=None):
    ctx=ctx or bpy.context;pref=pref or properties.prefs(ctx);scene=getattr(ctx,'scene',None)
    enabled=bool((pref and pref.always_jiggle_runtime_callbacks) or (scene and hasattr(scene,'jiggle') and scene.jiggle.runtime_callbacks_enabled))
    for handlers,fn in ((bpy.app.handlers.frame_change_pre,pre),(bpy.app.handlers.frame_change_post,post)):
        if enabled and fn not in handlers:handlers.append(fn)
        if not enabled and fn in handlers:handlers.remove(fn)
    if not enabled:reset()
    overlays(pref)
def unregister():
    cancel_job()
    for group,fn in ((bpy.app.handlers.frame_change_pre,pre),(bpy.app.handlers.frame_change_post,post)):
        if fn in group:group.remove(fn)
    overlays(None);reset()
def clear_bake(arm):
    a=arm.animation_data;name=arm.get('sc_jiggle_baked','');baked=bpy.data.actions.get(name) if name else None
    if baked is None or baked.get('sc_jiggle_owner')!=arm.name:return
    if a:
        for track in list(a.nla_tracks):
            if track.name==arm.get('sc_jiggle_track','') and all(st.action==baked for st in track.strips):a.nla_tracks.remove(track)
            elif track.name==arm.get('sc_jiggle_backup_track','') and all(st.action and st.action.name==arm.get('sc_jiggle_previous','') for st in track.strips):a.nla_tracks.remove(track)
        if a.action==baked:
            a.action=bpy.data.actions.get(arm.get('sc_jiggle_previous',''))
            handle=arm.get('sc_jiggle_previous_slot',0)
            if a.action and handle:
                slot=next((x for x in a.action.slots if x.handle==handle),None)
                if slot:a.action_slot=slot
    if not baked.users:bpy.data.actions.remove(baked)
    for k in ('sc_jiggle_baked','sc_jiggle_track','sc_jiggle_previous','sc_jiggle_previous_slot','sc_jiggle_backup_track'):
        if k in arm:del arm[k]
    arm.jiggle.freeze=False
def sample_bake(ctx):
    global baking
    scene=ctx.scene;arm=ctx.object
    if not arm or arm.type!='ARMATURE' or not target_bones(arm):raise ValueError('Enable jiggle on one or more bones.')
    if 'sc_jiggle_baked' in arm:
        if not scene.jiggle.bake_overwrite:raise ValueError('Clear the previous jiggle bake or allow replacement.')
    frame=scene.frame_current;anim=arm.animation_data_create();prior=anim.action;slot=anim.action_slot
    existing=arm.get('sc_jiggle_baked','');saved_track=next((t for t in anim.nla_tracks if t.name==arm.get('sc_jiggle_track','')),None);muted=saved_track.mute if saved_track else False
    if existing and prior and prior.name==existing:
        anim.action=bpy.data.actions.get(arm.get('sc_jiggle_previous',''))
        previous_slot=next((s for s in anim.action.slots if s.handle==arm.get('sc_jiggle_previous_slot')) ,None) if anim.action else None
        if previous_slot:anim.action_slot=previous_slot
    if saved_track:saved_track.mute=True
    samples=[];baking=True;reset()
    try:
        for fr in range(scene.frame_start,scene.frame_end+1):
            restore();scene.frame_set(fr);ctx.view_layer.update()
            if fr==scene.frame_start:
                for _ in range(min(250,scene.jiggle.preroll)):simulate(scene,True);restore()
            simulate(scene,True)
            samples.append((fr,[(b.name,b.matrix_basis.copy()) for b in target_bones(arm)]));yield fr
        restore()
        if existing:
            if prior and prior.name==existing:anim.action=prior
            clear_bake(arm);prior=anim.action;slot=anim.action_slot;existing='';saved_track=None
        action=prior.copy() if prior else bpy.data.actions.new('Jiggle '+arm.name)
        action.name='Jiggle '+arm.name;action['sc_jiggle_owner']=arm.name;anim.action=action
        arm['sc_jiggle_previous']=prior.name if prior else '';arm['sc_jiggle_previous_slot']=slot.handle if slot else 0;arm['sc_jiggle_baked']=action.name
        if prior and not scene.jiggle.bake_nla:
            track=anim.nla_tracks.new();track.name='SmartCloth | original motion';track.mute=True
            strip=track.strips.new(prior.name,scene.frame_start,prior)
            if slot:strip.action_slot=slot
            arm['sc_jiggle_backup_track']=track.name
        for fr,poses in samples:
            for name,mat in poses:
                b=arm.pose.bones[name];b.matrix_basis=mat;channel={'QUATERNION':'rotation_quaternion','AXIS_ANGLE':'rotation_axis_angle'}.get(b.rotation_mode,'rotation_euler')
                b.keyframe_insert(data_path=channel,frame=fr,group=name);b.keyframe_insert(data_path='location',frame=fr,group=name)
        if scene.jiggle.bake_nla:
            track=anim.nla_tracks.new();track.name='Jiggle '+arm.name;track.strips.new(action.name,scene.frame_start,action);arm['sc_jiggle_track']=track.name;anim.action=prior
        arm.jiggle.freeze=True
    except Exception:
        if not existing and 'sc_jiggle_baked' in arm:clear_bake(arm)
        raise
    finally:
        if existing:
            anim.action=prior
            if prior and slot:anim.action_slot=slot
            if saved_track:saved_track.mute=muted
        baking=False;reset();scene.frame_set(frame)
def cancel_job():
    global pending
    if pending:
        job=pending;pending=None
        try:job['stream'].close()
        finally:
            try:job['wm'].event_timer_remove(job['timer'])
            except (RuntimeError,ReferenceError):pass
def job_event(op,ctx,event):
    if not pending or pending['operator']!=op.as_pointer():return {'CANCELLED'}
    if event.type=='ESC' or ctx.scene.name!=pending['scene']:cancel_job();return {'CANCELLED'}
    if event.type!='TIMER':return {'PASS_THROUGH'}
    try:
        for _ in range(3):next(pending['stream'])
        return {'RUNNING_MODAL'}
    except StopIteration:cancel_job();return {'FINISHED'}
    except Exception as exc:cancel_job();op.report({'WARNING'},str(exc));return {'CANCELLED'}
def start_bake(op,ctx):
    global pending
    if pending:raise ValueError('Another jiggle bake is in progress.')
    stream=sample_bake(ctx)
    if bpy.app.background:
        for _ in stream:pass
        return {'FINISHED'}
    # Start sampling before adding an event handler so selection or data errors are synchronous.
    next(stream);wm=ctx.window_manager
    try:
        pending=dict(operator=op.as_pointer(),stream=stream,wm=wm,timer=wm.event_timer_add(.06,window=ctx.window),scene=ctx.scene.name);wm.modal_handler_add(op)
    except Exception:
        stream.close();cancel_job();raise
    return {'RUNNING_MODAL'}
def execute(key,op,ctx):
    arm=ctx.object
    if key=='jiggle_reset':reset();return
    if key=='jiggle_profile':
        n=sum(len(target_bones(a))for a in ctx.scene.objects if a.type=='ARMATURE' and a.jiggle.enable);op.report({'INFO'},f'{n} simulated bones');return
    if not arm or arm.type!='ARMATURE':raise ValueError('Select an armature.')
    if key=='jiggle_bake':
        if op.clear_only:clear_bake(arm)
        else:return start_bake(op,ctx)
        return
    if key=='jiggle_clear_keyframes':
        anim=arm.animation_data;selected=ctx.selected_pose_bones or []
        if not anim or not anim.action or not anim.action_slot:return
        prefixes=tuple(p.path_from_id()+'.jiggle_' for p in selected)
        for layer in anim.action.layers:
            for strip in layer.strips:
                bag=strip.channelbag(anim.action_slot)
                if bag:
                    for curve in list(bag.fcurves):
                        if curve.data_path.startswith(prefixes):bag.fcurves.remove(curve)
        return
    active=ctx.active_pose_bone or arm.pose.bones.get(arm.data.bones.active.name if arm.data.bones.active else '');bones=list(ctx.selected_pose_bones or [])
    if key=='jiggle_select':
        for p in arm.pose.bones:p.select=p.jiggle.enable
    elif key=='jiggle_copy':
        if not active:raise ValueError('Select an active pose bone.')
        for p in bones:
            for n in properties.DATA['roots']['PoseBone']:
                if n!='jiggle':setattr(p,n,getattr(active,n))
            for n in ('enable','collider_type','collider','collider_collection'):setattr(p.jiggle,n,getattr(active.jiggle,n))
    elif key=='jiggle_bone_connected_disable':
        names=[p.name for p in bones];bpy.ops.object.mode_set(mode='EDIT')
        try:
            for name in names:arm.data.edit_bones[name].use_connect=False
        finally:bpy.ops.object.mode_set(mode='POSE')
    elif key=='jiggle_bone_constraints_disable':
        for p in bones:
            for c in p.constraints:c.mute=True
    else:
        from . import persistence
        if not active:raise ValueError('Select an active pose bone.')
        from pathlib import Path
        import re
        name=re.sub(r'[^\w -]','_',active.name).strip() or 'Bone'
        directory=Path(bpy.utils.extension_path_user(__package__,path='jiggle_physics/presets/jigglebones',create=False))
        path=directory/(name+'.py')
        if op.remove_active or op.remove_name:
            if path.exists():path.unlink()
        else:
            directory.mkdir(parents=True,exist_ok=True)
            values={n:getattr(active,n) for n in properties.DATA['roots']['PoseBone'] if n!='jiggle'}
            path.write_text('import bpy\nvalues = '+repr(values)+'\nfor name, value in values.items():\n    setattr(bpy.context.active_pose_bone, name, value)\n','utf8')
