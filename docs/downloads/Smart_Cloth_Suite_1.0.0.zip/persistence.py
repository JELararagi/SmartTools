"""Version-three user settings with atomic replacement and lossless preservation of unknown keys."""
import bpy,json,os,tempfile
from pathlib import Path
from . import properties
NAME='Smart_Cloth_Suite.json'
def folder():
    prefs=properties.prefs()
    if prefs and prefs.storage_mode=='BLEND_RELATIVE' and bpy.data.filepath:return Path(bpy.data.filepath).parent/'Smart_Cloth_Suite'
    if prefs and prefs.storage_mode=='CUSTOM' and prefs.custom_storage_dir:
        return Path(bpy.path.abspath(prefs.custom_storage_dir))
    return Path(bpy.utils.user_resource('CONFIG'))/'Smart_Cloth_Suite'
def read(path,default):
    try:return json.loads(path.read_text('utf-8-sig'))
    except FileNotFoundError:return default
def atomic(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf8')
    with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.'+path.name+'.',delete=False) as f:
        tmp=Path(f.name);f.write(raw)
    try:os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)
def scalar(group):
    out={}
    for key in properties.DATA['groups'].get(group.bl_rna.identifier,{}):
        v=getattr(group,key);p=group.bl_rna.properties[key]
        if p.type=='POINTER':v={'__pointer__':v.bl_rna.identifier if v else '', 'name':v.name if v else ''}
        elif getattr(p,'array_length',0):v=list(v)
        out[key]=v
    return out
def save(ctx=None,force=False):
    ctx=ctx or bpy.context;p=properties.prefs(ctx)
    if not p or properties.loading or (not force and not p.always_suite_npanel_persistence):return
    path=folder()/NAME;doc=read(path,{})
    if not isinstance(doc,dict):raise ValueError('Invalid settings document.')
    runtime=scalar(p);doc.update(schema='jelararagi.smart_cloth.settings.v3',file=NAME,version=283)
    groups={'runtime_preferences':runtime,'always_on_toggles':{k:v for k,v in runtime.items() if k.startswith('always_')},'ui_sections':{k:v for k,v in runtime.items() if k.startswith('ui_')},'storage_settings':{k:runtime[k] for k in ('storage_mode','custom_storage_dir','result_collection_name','auto_create_result_collection')},'tool_visibility':{k:v for k,v in runtime.items() if k.startswith('show_')}}
    for k,values in groups.items():doc.setdefault(k,{}).update(values)
    scene=doc.setdefault('scene_settings',{})
    for k in ('jiggle','quick_rigid_settings','smart_cloth_suite_companion'):scene.setdefault(k,{}).update(scalar(getattr(ctx.scene,k)))
    if path.is_file():atomic(path.with_suffix('.json.bak'),read(path,{}))
    atomic(path,doc)
def assign(group,mapping,only_unset=False):
    if not isinstance(mapping,dict):return
    for k,v in mapping.items():
        p=group.bl_rna.properties.get(k)
        if not p or p.is_readonly or (only_unset and group.is_property_set(k)):continue
        try:
            if p.type=='POINTER':
                collection={'Object':bpy.data.objects,'Collection':bpy.data.collections}.get(p.fixed_type.identifier)
                name=v.get('name','') if isinstance(v,dict) else ''
                if name and collection is not None and collection.get(name):setattr(group,k,collection[name])
            else:setattr(group,k,v)
        except (ValueError,TypeError,AttributeError):continue
def load(*args):
    p=properties.prefs()
    if not p:return
    path=folder()/NAME
    legacy=Path(bpy.utils.user_resource('CONFIG'))/NAME
    if not path.is_file() and legacy.is_file():path=legacy
    try:doc=read(path,{})
    except (ValueError,OSError):
        try:doc=read(path.with_suffix('.json.bak'),{})
        except (ValueError,OSError):return
    if not isinstance(doc,dict):return
    properties.loading=True
    try:
        for k in ('runtime_preferences','storage_settings','ui_sections','tool_visibility','always_on_toggles'):assign(p,doc.get(k,{}))
        if p.always_suite_npanel_persistence:
            for k in ('jiggle','quick_rigid_settings','smart_cloth_suite_companion'):
                assign(getattr(bpy.context.scene,k),doc.get('scene_settings',{}).get(k,{}),True)
    finally:properties.loading=False
def deferred():
    try:save()
    except (ValueError,OSError) as exc:print('[SmartCloth settings]',exc)
    return None
def schedule():
    if not bpy.app.timers.is_registered(deferred):bpy.app.timers.register(deferred,first_interval=.25)
def stop():
    if bpy.app.timers.is_registered(deferred):bpy.app.timers.unregister(deferred);deferred()
