"""Apply the measured rope motion response to the currently active pose bone."""
import bpy

values = {
    "air_drag": 0.1,
    "angle_elasticity": 0.55,
    "blend": 1.0,
    "collision_radius": 0.1,
    "elasticity_soften": 1.0,
    "friction": 0.5,
    "gravity": 1.0,
    "length_elasticity": 0.9,
    "root_elasticity": 0.9
}
bone = bpy.context.active_pose_bone
if bone is not None:
    for parameter, value in values.items():
        setattr(bone, "jiggle_" + parameter, value)
