"""Apply the measured stiff motion response to the currently active pose bone."""
import bpy

values = {
    "air_drag": 0.0,
    "angle_elasticity": 0.95,
    "blend": 1.0,
    "collision_radius": 0.1,
    "elasticity_soften": 0.0,
    "friction": 0.5,
    "gravity": 0.5,
    "length_elasticity": 0.95,
    "root_elasticity": 0.95
}
bone = bpy.context.active_pose_bone
if bone is not None:
    for parameter, value in values.items():
        setattr(bone, "jiggle_" + parameter, value)
