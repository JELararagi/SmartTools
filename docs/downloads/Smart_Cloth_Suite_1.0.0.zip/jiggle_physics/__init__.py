# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy, math, cProfile, pstats, io, os, shutil, time, uuid
from collections import deque
from bpy.types import Scene, Panel, Operator, Menu, PoseBone, SpaceView3D, Object, PropertyGroup, Collection
from bpy.props import StringProperty, EnumProperty, BoolProperty, IntProperty, FloatProperty, FloatVectorProperty, PointerProperty
from bl_operators.presets import AddPresetBase
from mathutils import Vector, Matrix, Euler, Quaternion, geometry
from bpy.app.handlers import persistent
from bpy_extras import anim_utils
from . import translation as jiggle_i18n
from .. import lifecycle

try:
    from .. import storage as _suite_storage  # type: ignore
except Exception:
    _suite_storage = None


def _jiggle_fallback_user_default_dir(*parts: str, create: bool = False) -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        version_text = f'{int(version[0])}.{int(version[1])}' if version and len(version) >= 2 else '5.1'
    except Exception:
        version_text = '5.1'
    appdata = os.environ.get('APPDATA') or ''
    if appdata:
        root = os.path.join(appdata, 'Blender Foundation', 'Blender', version_text, 'extensions', 'user_default')
    else:
        root = os.path.join(os.path.expanduser('~'), '.config', 'blender', version_text, 'extensions', 'user_default')
    path = os.path.join(root, 'smart_cloth_suite', 'user_data', *[str(part).strip('/\\') for part in parts if str(part or '').strip('/\\')])
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def _jiggle_preset_subdir(create: bool = False) -> str:
    """Return the folder for saved Jiggle presets. The package itself is cleared on update."""
    try:
        package = str(__package__ or '').rpartition('.')[0]
        return bpy.utils.extension_path_user(package, path=os.path.join('jiggle_physics', 'presets', 'jigglebones'), create=bool(create))
    except Exception:
        pass
    if _suite_storage is not None:
        return str(_suite_storage.user_data_dir('jiggle_physics', 'presets', 'jigglebones', create=bool(create)))
    return _jiggle_fallback_user_default_dir('jiggle_physics', 'presets', 'jigglebones', create=bool(create))


bl_info = {
    "name": "Jiggle Physics",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Cloth",
    "description": "Armature jiggle physics with standard 3D View Sidebar N-panel panels, overlays, wind, presets, and bake utilities.",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}


_JIGGLE_STARTUP_PANEL_GUARD_UNTIL = 0.0
_JIGGLE_OBJECT_CACHE_LIMIT = 128
_BAKE_DEBUG_LOG_LIMIT = 256
_BAKE_DEBUG_FRAME_LIMIT = 128
_BAKE_DEBUG_OBJECT_LIMIT = 128
_BAKE_DEBUG_MODIFIER_LIMIT = 128


def _jiggle_startup_panel_guard_active() -> bool:
    return False


def _jiggle_draw_startup_guard(layout, context) -> None:
    try:
        layout.label(text=_jiggle_ui_text('Jiggle Physics UI is initializing.', 'Jiggle Physics UI を初期化中です。', context))
        layout.label(text=_jiggle_ui_text('Heavy panel drawing is skipped during Blender startup.', 'Blender 起動直後の重いパネル描画は省略しています。', context), icon='TIME')
    except Exception:
        pass


def _jiggle_is_japanese_locale(context=None) -> bool:
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _jiggle_help_button(layout, topic):
    """Open the suite's "?" help popup for this topic (same operator as every other "?" button)."""
    try:
        row = layout.row(align=True)
        row.operator_context = 'INVOKE_DEFAULT'
        row.operator('smart_core.show_help_popup', text='', icon='QUESTION').topic = str(topic)
    except Exception:
        pass


def _jiggle_ui_text(en: str, ja: str, context=None) -> str:
    # Class labels and RNA property metadata are created without draw context.
    # Store English source strings there and let Blender translations localize
    # them. Runtime UI/report calls pass context and switch language directly.
    if context is None:
        return str(en)
    return str(ja if _jiggle_is_japanese_locale(context) else en)

class BakeDebugger:
    """Small bounded diagnostic ring used only during an explicit bake."""

    def __init__(self):
        self.clear()

    def clear(self):
        self.log_entries = deque(maxlen=_BAKE_DEBUG_LOG_LIMIT)
        self.start_time = None
        self.frame_start_time = None
        self.frame_times = {}
        self.object_evaluations = {}
        self.modifier_evaluations = {}
        self.dropped_log_entries = 0
        self.dropped_frame_times = 0
        self.dropped_object_evaluations = 0
        self.dropped_modifier_evaluations = 0
        self.total_object_evaluations = 0
        self.total_modifier_evaluations = 0

    def start_logging(self):
        self.clear()
        self.start_time = time.monotonic()
        self.log("=== STARTING NLA BAKE DEBUG SESSION ===")

    def log(self, message):
        timestamp = time.monotonic() - self.start_time if self.start_time is not None else 0.0
        if len(self.log_entries) == self.log_entries.maxlen:
            self.dropped_log_entries += 1
        self.log_entries.append(f"[{timestamp:.3f}s] {message}")

    def log_frame_start(self, frame):
        self.frame_start_time = time.monotonic()
        self.log(f"--- FRAME {int(frame)} START ---")

    def log_frame_end(self, frame):
        started = self.frame_start_time
        duration = max(0.0, time.monotonic() - started) if started is not None else 0.0
        key = int(frame)
        if key in self.frame_times or len(self.frame_times) < _BAKE_DEBUG_FRAME_LIMIT:
            self.frame_times[key] = duration
        else:
            self.dropped_frame_times += 1
        self.log(f"--- FRAME {key} END ({duration:.3f}s) ---")

    @staticmethod
    def _bounded_increment(mapping, key, limit):
        if key in mapping:
            mapping[key] += 1
            return True
        if len(mapping) >= int(limit):
            return False
        mapping[key] = 1
        return True

    def log_object_evaluation(self, obj_name, obj_type):
        self.total_object_evaluations += 1
        if not self._bounded_increment(self.object_evaluations, str(obj_name), _BAKE_DEBUG_OBJECT_LIMIT):
            self.dropped_object_evaluations += 1
        self.log(f"EVALUATING OBJECT: {obj_name} ({obj_type})")

    def log_modifier_evaluation(self, obj_name, mod_name, mod_type):
        self.total_modifier_evaluations += 1
        key = f"{obj_name}.{mod_name}"
        if not self._bounded_increment(self.modifier_evaluations, key, _BAKE_DEBUG_MODIFIER_LIMIT):
            self.dropped_modifier_evaluations += 1
        self.log(f"EVALUATING MODIFIER: {key} ({mod_type})")

    def generate_report(self):
        total_time = time.monotonic() - self.start_time if self.start_time is not None else 0.0
        report = [
            "=== NLA BAKE PERFORMANCE REPORT ===",
            f"Total bake time: {total_time:.3f}s",
            f"Object evaluations: {self.total_object_evaluations}",
            f"Modifier evaluations: {self.total_modifier_evaluations}",
            "",
        ]
        if self.frame_times:
            values = tuple(self.frame_times.items())
            avg_frame_time = sum(value for _frame, value in values) / max(1, len(values))
            slowest_frame = max(values, key=lambda item: item[1])
            fastest_frame = min(values, key=lambda item: item[1])
            report.extend((
                "FRAME TIMING:",
                f"  Average frame time: {avg_frame_time:.3f}s",
                f"  Slowest frame: {slowest_frame[0]} ({slowest_frame[1]:.3f}s)",
                f"  Fastest frame: {fastest_frame[0]} ({fastest_frame[1]:.3f}s)",
                "",
            ))
        if self.object_evaluations:
            report.append("MOST EVALUATED OBJECTS:")
            for obj_name, count in sorted(self.object_evaluations.items(), key=lambda item: item[1], reverse=True)[:20]:
                report.append(f"  {obj_name}: {count} evaluations")
            report.append("")
        if self.modifier_evaluations:
            report.append("MOST EVALUATED MODIFIERS:")
            for mod_key, count in sorted(self.modifier_evaluations.items(), key=lambda item: item[1], reverse=True)[:20]:
                report.append(f"  {mod_key}: {count} evaluations")
            report.append("")
        report.append("FULL LOG:")
        if self.dropped_frame_times:
            report.append(f"[TRUNCATED] Dropped frame timing entries: {self.dropped_frame_times}")
        if self.dropped_object_evaluations:
            report.append(f"[TRUNCATED] Dropped object evaluation keys: {self.dropped_object_evaluations}")
        if self.dropped_modifier_evaluations:
            report.append(f"[TRUNCATED] Dropped modifier evaluation keys: {self.dropped_modifier_evaluations}")
        if self.dropped_log_entries:
            report.append(f"[RING] Overwritten log entries: {self.dropped_log_entries}")
        report.extend(tuple(self.log_entries))
        return "\n".join(report)

    def save_to_text_block(self, name="NLA_Bake_Debug_Log"):
        report = self.generate_report()
        try:
            text_block = bpy.data.texts.get(name)
            if text_block is None:
                text_block = bpy.data.texts.new(name)
            else:
                text_block.clear()
            text_block.write(report)
            return text_block
        finally:
            self.clear()


_bake_debugger = BakeDebugger()


def clear_debug_runtime_data():
    _bake_debugger.clear()


def debug_object_update(self, context, depsgraph):
    del context, depsgraph
    if _jiggle_globals.jiggle_baking:
        _bake_debugger.log_object_evaluation(getattr(self, 'name', ''), getattr(self, 'type', ''))


@persistent
def debug_frame_change_pre(scene, depsgraph):
    del depsgraph
    jiggle = getattr(scene, 'jiggle', None)
    if _jiggle_globals.jiggle_baking and bool(getattr(jiggle, 'bake_debug', False)):
        _bake_debugger.log_frame_start(getattr(scene, 'frame_current', 0))


@persistent
def debug_frame_change_post(scene, depsgraph):
    jiggle = getattr(scene, 'jiggle', None)
    if not (_jiggle_globals.jiggle_baking and bool(getattr(jiggle, 'bake_debug', False))):
        return
    _bake_debugger.log_frame_end(getattr(scene, 'frame_current', 0))
    updates = tuple(getattr(depsgraph, 'updates', ()) or ())[:_BAKE_DEBUG_OBJECT_LIMIT]
    for update in updates:
        datablock = getattr(update, 'id', None)
        if datablock is None:
            continue
        _bake_debugger.log_object_evaluation(getattr(datablock, 'name', ''), type(datablock).__name__)




ZERO_VEC = Vector((0,0,0))
IDENTITY_MAT = Matrix.Identity(4)
IDENTITY_QUAT = Quaternion()
# We merge bones that are closer than this as bones perfectly on top of each other don't work well with jiggle physics.
MERGE_BONE_THRESHOLD = 0.01

# Simple 3D/4D noise function for wind turbulence
def noise_hash(x, y, z, w=0):
    """Simple hash function for noise generation"""
    import math
    n = math.sin(x * 12.9898 + y * 78.233 + z * 37.719 + w * 17.389) * 43758.5453
    return n - math.floor(n)

def smooth_step(t):
    """Smoothstep interpolation function"""
    return t * t * (3.0 - 2.0 * t)

def noise_3d(x, y, z):
    """Simple 3D noise function (Perlin-like)"""
    import math

    # Get integer and fractional parts
    xi = math.floor(x)
    yi = math.floor(y)
    zi = math.floor(z)

    xf = x - xi
    yf = y - yi
    zf = z - zi

    # Smooth the fractional parts
    u = smooth_step(xf)
    v = smooth_step(yf)
    w = smooth_step(zf)

    # Hash coordinates of the 8 cube corners
    n000 = noise_hash(xi, yi, zi)
    n100 = noise_hash(xi + 1, yi, zi)
    n010 = noise_hash(xi, yi + 1, zi)
    n110 = noise_hash(xi + 1, yi + 1, zi)
    n001 = noise_hash(xi, yi, zi + 1)
    n101 = noise_hash(xi + 1, yi, zi + 1)
    n011 = noise_hash(xi, yi + 1, zi + 1)
    n111 = noise_hash(xi + 1, yi + 1, zi + 1)

    # Trilinear interpolation
    x00 = n000 * (1 - u) + n100 * u
    x10 = n010 * (1 - u) + n110 * u
    x01 = n001 * (1 - u) + n101 * u
    x11 = n011 * (1 - u) + n111 * u

    y0 = x00 * (1 - v) + x10 * v
    y1 = x01 * (1 - v) + x11 * v

    return y0 * (1 - w) + y1 * w

def noise_4d(x, y, z, w):
    """Simple 4D noise function (Perlin-like)"""
    import math

    # Get integer and fractional parts
    xi = math.floor(x)
    yi = math.floor(y)
    zi = math.floor(z)
    wi = math.floor(w)

    xf = x - xi
    yf = y - yi
    zf = z - zi
    wf = w - wi

    # Smooth the fractional parts
    u = smooth_step(xf)
    v = smooth_step(yf)
    s = smooth_step(zf)
    t = smooth_step(wf)

    # Hash coordinates of the 16 hypercube corners
    n0000 = noise_hash(xi, yi, zi, wi)
    n1000 = noise_hash(xi + 1, yi, zi, wi)
    n0100 = noise_hash(xi, yi + 1, zi, wi)
    n1100 = noise_hash(xi + 1, yi + 1, zi, wi)
    n0010 = noise_hash(xi, yi, zi + 1, wi)
    n1010 = noise_hash(xi + 1, yi, zi + 1, wi)
    n0110 = noise_hash(xi, yi + 1, zi + 1, wi)
    n1110 = noise_hash(xi + 1, yi + 1, zi + 1, wi)

    n0001 = noise_hash(xi, yi, zi, wi + 1)
    n1001 = noise_hash(xi + 1, yi, zi, wi + 1)
    n0101 = noise_hash(xi, yi + 1, zi, wi + 1)
    n1101 = noise_hash(xi + 1, yi + 1, zi, wi + 1)
    n0011 = noise_hash(xi, yi, zi + 1, wi + 1)
    n1011 = noise_hash(xi + 1, yi, zi + 1, wi + 1)
    n0111 = noise_hash(xi, yi + 1, zi + 1, wi + 1)
    n1111 = noise_hash(xi + 1, yi + 1, zi + 1, wi + 1)

    # 4D interpolation
    x000 = n0000 * (1 - u) + n1000 * u
    x100 = n0100 * (1 - u) + n1100 * u
    x010 = n0010 * (1 - u) + n1010 * u
    x110 = n0110 * (1 - u) + n1110 * u

    x001 = n0001 * (1 - u) + n1001 * u
    x101 = n0101 * (1 - u) + n1101 * u
    x011 = n0011 * (1 - u) + n1011 * u
    x111 = n0111 * (1 - u) + n1111 * u

    y00 = x000 * (1 - v) + x100 * v
    y10 = x010 * (1 - v) + x110 * v
    y01 = x001 * (1 - v) + x101 * v
    y11 = x011 * (1 - v) + x111 * v

    z0 = y00 * (1 - s) + y10 * s
    z1 = y01 * (1 - s) + y11 * s

    return z0 * (1 - t) + z1 * t

def get_wind_force(position, wind_direction, wind_speed, turbulence_scale, evolution):
    """Calculate wind force at a given world position using 3D/4D noise"""
    if turbulence_scale <= 0:
        return wind_direction * wind_speed

    # Sample position in noise field (scaled by turbulence)
    sample_pos = position / turbulence_scale

    # Offset sample position by wind direction and speed (creates flowing effect)
    offset = wind_direction * wind_speed * evolution
    sample_x = sample_pos.x + offset.x
    sample_y = sample_pos.y + offset.y
    sample_z = sample_pos.z + offset.z

    # Use 4D noise if evolution speed is non-zero, otherwise 3D
    if evolution > 0:
        noise_val = noise_4d(sample_x, sample_y, sample_z, evolution)
    else:
        noise_val = noise_3d(sample_x, sample_y, sample_z)

    # Convert noise from [0,1] to [-1,1] range for turbulence
    turbulence = (noise_val * 2.0 - 1.0)

    # Create turbulent wind direction
    # Add perpendicular components for swirling effect
    up = Vector((0, 0, 1))
    if abs(wind_direction.dot(up)) > 0.99:
        up = Vector((1, 0, 0))

    perp1 = wind_direction.cross(up).normalized()
    perp2 = wind_direction.cross(perp1).normalized()

    # Sample noise for each perpendicular direction
    turb_x = noise_3d(sample_x + 100, sample_y, sample_z) * 2.0 - 1.0
    turb_y = noise_3d(sample_x, sample_y + 100, sample_z) * 2.0 - 1.0

    # Combine base wind direction with turbulence
    wind_force = wind_direction * wind_speed * (1.0 + turbulence * 0.5)
    wind_force += perp1 * turb_x * wind_speed * 0.3
    wind_force += perp2 * turb_y * wind_speed * 0.3

    return wind_force

class AreaProperties:
    __slots__ = ('overlay_pose', 'overlay_simulation')

    def __init__(self):
        self.overlay_pose = False
        self.overlay_simulation = False


class JiggleGlobals:
    def __init__(self):
        self.is_rendering = False
        self.is_preroll = False
        self.is_animation_playing = False
        self.profiler = None
        self.area_overlays = {}
        self.physics_resetting = False
        self.jiggle_object_virtual_point_cache = {}
        self.jiggle_scene_virtual_point_cache = []
        self.jiggle_baking = False
        self.suspend_runtime_evaluation = False
        self.overlay_handler = None
        self.propagating_props = False
        self._overlay_shader = None
        self._overlay_batch_factory = None
        self._overlay_snapshot = ()
        self._overlay_circle_segments = 8
        self._overlay_circle_angle_cache = ()

    def get_profiler(self, *, create=False):
        if self.profiler is None and create:
            self.profiler = cProfile.Profile()
        return self.profiler

    def _live_area_pointers(self):
        pointers = set()
        try:
            wm = getattr(bpy.context, 'window_manager', None)
            for window in tuple(getattr(wm, 'windows', ()) or ()):
                screen = getattr(window, 'screen', None)
                for area in tuple(getattr(screen, 'areas', ()) or ()):
                    try:
                        pointers.add(int(area.as_pointer()))
                    except Exception:
                        pass
        except Exception:
            pass
        return pointers

    def prune_area_overlay_properties(self):
        live_pointers = self._live_area_pointers()
        if not live_pointers:
            return
        for area_pointer in tuple(self.area_overlays):
            if area_pointer not in live_pointers:
                self.area_overlays.pop(area_pointer, None)
        while len(self.area_overlays) > 32:
            self.area_overlays.pop(next(iter(self.area_overlays)), None)

    def ensure_area_overlay_properties(self, area):
        if area is None:
            return None
        try:
            area_pointer = int(area.as_pointer())
        except Exception:
            return None
        state = self.area_overlays.get(area_pointer)
        if state is None:
            self.prune_area_overlay_properties()
            while len(self.area_overlays) >= 32:
                self.area_overlays.pop(next(iter(self.area_overlays)), None)
            state = AreaProperties()
            self.area_overlays[area_pointer] = state
        return state

    def get_area_overlay_properties(self, area):
        return self.ensure_area_overlay_properties(area)

    def peek_area_overlay_properties(self, area):
        try:
            return self.area_overlays.get(int(area.as_pointer()))
        except Exception:
            return None

    def _prepare_overlay_gpu(self):
        if self._overlay_shader is not None and self._overlay_batch_factory is not None:
            return True
        try:
            import gpu as _gpu
            from gpu_extras.batch import batch_for_shader as _batch_for_shader
            shader = _gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            self._overlay_shader = None
            self._overlay_batch_factory = None
            return False
        self._overlay_shader = shader
        self._overlay_batch_factory = _batch_for_shader
        self._overlay_circle_angle_cache = tuple(
            (math.cos(2 * math.pi * i / self._overlay_circle_segments),
             math.sin(2 * math.pi * i / self._overlay_circle_segments))
            for i in range(self._overlay_circle_segments)
        )
        return True

    def refresh_overlay_snapshot(self, scene, virtual_particles=None):
        if scene is None:
            self._overlay_snapshot = ()
            return
        if virtual_particles is None:
            try:
                virtual_particles = get_virtual_particles(scene)
            except Exception:
                self._overlay_snapshot = ()
                return
        snapshot = []
        for particle in tuple(virtual_particles or ()):
            if not (getattr(particle, 'parent', None) and getattr(particle, 'bone', None)):
                continue
            try:
                local_radius = float(particle.jiggle_settings.collision_radius)
                bone_matrix_world = particle.bone.id_data.matrix_world @ particle.bone.matrix
                world_radius = max(0.0, sum(bone_matrix_world.to_scale()) / 3.0 * local_radius)
                snapshot.append((
                    particle.parent.rest_pose_position.copy(),
                    particle.rest_pose_position.copy(),
                    particle.parent.position.copy(),
                    particle.position.copy(),
                    world_radius,
                ))
            except Exception:
                continue
        self._overlay_snapshot = tuple(snapshot[:4096])

    def update_overlay_draw_handler(self):
        self.remove_overlay_draw_handler(clear_states=False)
        if not _jiggle_runtime_callbacks_enabled():
            return
        self.prune_area_overlay_properties()
        has_overlay = any(
            bool(state.overlay_simulation or state.overlay_pose)
            for state in tuple(self.area_overlays.values())
        )
        if not has_overlay or not self._prepare_overlay_gpu():
            return
        try:
            self.refresh_overlay_snapshot(getattr(bpy.context, 'scene', None))
        except Exception:
            self._overlay_snapshot = ()
        self.overlay_handler = lifecycle.register_draw_handler(
            SpaceView3D,
            draw_callback,
            (),
            'WINDOW',
            'POST_VIEW',
            scope='jiggle.overlay',
        )

    def remove_overlay_draw_handler(self, *, clear_states=True):
        lifecycle.release_scope('jiggle.overlay')
        self.overlay_handler = None
        self._overlay_shader = None
        self._overlay_batch_factory = None
        self._overlay_snapshot = ()
        self._overlay_circle_angle_cache = ()
        if clear_states:
            self.area_overlays.clear()

    def prune_virtual_point_caches(self, scene=None, keep_object=None):
        cache = self.jiggle_object_virtual_point_cache
        scene_pointers = None
        if scene is not None:
            scene_pointers = set()
            for item in tuple(getattr(scene, 'objects', ()) or ()):
                try:
                    scene_pointers.add(int(item.as_pointer()))
                except Exception:
                    pass
        keep_pointer = None
        try:
            keep_pointer = int(keep_object.as_pointer()) if keep_object is not None else None
        except Exception:
            pass
        for obj in tuple(cache):
            valid = True
            pointer = None
            try:
                pointer = int(obj.as_pointer())
                name = str(obj.name or '')
                current = bpy.data.objects.get(name)
                valid = bool(name) and getattr(obj, 'type', None) == 'ARMATURE' and current is obj
            except Exception:
                valid = False
            if valid and scene_pointers is not None and pointer not in scene_pointers and pointer != keep_pointer:
                valid = False
            if not valid:
                cache.pop(obj, None)
        while len(cache) > _JIGGLE_OBJECT_CACHE_LIMIT:
            oldest = next(iter(cache), None)
            if oldest is None:
                break
            if oldest is keep_object and len(cache) > 1:
                cache[oldest] = cache.pop(oldest)
                oldest = next(iter(cache), None)
            cache.pop(oldest, None)
        if len(cache) == 0:
            self.jiggle_scene_virtual_point_cache.clear()

    def clear_per_object_caches(self):
        self.jiggle_object_virtual_point_cache.clear()
        self.jiggle_scene_virtual_point_cache.clear()
        self._overlay_snapshot = ()

    def clear_per_frame_caches(self):
        self.jiggle_scene_virtual_point_cache.clear()

    def on_register(self):
        self.remove_overlay_draw_handler(clear_states=True)
        self.is_rendering = False
        self.is_preroll = False
        self.is_animation_playing = False
        self.profiler = None
        self.physics_resetting = False
        self.clear_per_object_caches()
        self.jiggle_baking = False
        self.suspend_runtime_evaluation = False
        self.propagating_props = False
        clear_debug_runtime_data()

    def on_unregister(self):
        self.remove_overlay_draw_handler(clear_states=True)
        self.is_rendering = False
        self.is_preroll = False
        self.is_animation_playing = False
        self.profiler = None
        self.physics_resetting = False
        self.clear_per_object_caches()
        self.jiggle_baking = False
        self.suspend_runtime_evaluation = False
        self.propagating_props = False
        clear_debug_runtime_data()


_jiggle_globals = JiggleGlobals()

_JIGGLE_RUNTIME_HANDLERS_INSTALLED = False
_JIGGLE_OVERLAY_MENU_INSTALLED = False


def _jiggle_runtime_callbacks_enabled(scene=None):
    try:
        scene = scene or getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    jiggle = getattr(scene, 'jiggle', None) if scene is not None else None
    return bool(getattr(jiggle, 'runtime_callbacks_enabled', False)) and bool(getattr(jiggle, 'enable', False))


def _install_overlay_menu() -> None:
    global _JIGGLE_OVERLAY_MENU_INSTALLED
    _JIGGLE_OVERLAY_MENU_INSTALLED = False


def _remove_overlay_menu() -> None:
    global _JIGGLE_OVERLAY_MENU_INSTALLED
    _JIGGLE_OVERLAY_MENU_INSTALLED = False


def _install_runtime_handlers() -> None:
    global _JIGGLE_RUNTIME_HANDLERS_INSTALLED
    if _JIGGLE_RUNTIME_HANDLERS_INSTALLED:
        return
    if not _jiggle_runtime_callbacks_enabled():
        return
    mark = lifecycle.checkpoint()
    try:
        handlers = bpy.app.handlers
        for collection, callback in (
            (handlers.frame_change_post, jiggle_post),
            (handlers.render_pre, jiggle_render_pre),
            (handlers.render_post, jiggle_render_post),
            (handlers.render_cancel, jiggle_render_cancel),
            (handlers.animation_playback_pre, jiggle_playback_start),
            (handlers.animation_playback_post, jiggle_playback_end),
        ):
            lifecycle.register_handler(collection, callback, scope='jiggle.runtime')
        _JIGGLE_RUNTIME_HANDLERS_INSTALLED = True
        _jiggle_globals.update_overlay_draw_handler()
    except Exception:
        lifecycle.rollback_to(mark)
        _JIGGLE_RUNTIME_HANDLERS_INSTALLED = False
        raise


def _remove_runtime_handlers() -> None:
    global _JIGGLE_RUNTIME_HANDLERS_INSTALLED
    lifecycle.release_scope('jiggle.overlay')
    lifecycle.release_scope('jiggle.runtime')
    _remove_overlay_menu()
    _jiggle_globals.overlay_handler = None
    _jiggle_globals.area_overlays.clear()
    _jiggle_globals.clear_per_object_caches()
    _jiggle_globals.profiler = None
    _jiggle_globals.is_animation_playing = False
    _jiggle_globals.is_rendering = False
    _jiggle_globals.suspend_runtime_evaluation = False
    clear_debug_runtime_data()
    _JIGGLE_RUNTIME_HANDLERS_INSTALLED = False


def _sync_runtime_handlers(scene=None) -> bool:
    enabled = _jiggle_runtime_callbacks_enabled(scene)
    if enabled:
        _install_runtime_handlers()
    else:
        _remove_runtime_handlers()
    return enabled


def _update_npanel_persist(_self=None, context=None):
    try:
        from .. import runtime as _suite_runtime
        persist = getattr(_suite_runtime, '_persist_npanel_runtime_state', None)
        if callable(persist):
            persist(context, force=False)
    except Exception:
        pass

def _update_runtime_handler_state(self, context):
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is None:
        scene = getattr(self, 'id_data', None)
    _sync_runtime_handlers(scene)
    _update_npanel_persist(self, context)


def _find_view3d_area(context=None):
    try:
        context = context or bpy.context
    except Exception:
        context = None

    area = getattr(context, 'area', None) if context is not None else None
    if area is not None and getattr(area, 'type', None) == 'VIEW_3D' and len(getattr(area, 'spaces', ()) or ()) > 0:
        return area

    screen = getattr(context, 'screen', None) if context is not None else None
    if screen is None:
        window = getattr(context, 'window', None) if context is not None else None
        screen = getattr(window, 'screen', None) if window is not None else None
    if screen is not None:
        for candidate in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(candidate, 'type', None) == 'VIEW_3D' and len(getattr(candidate, 'spaces', ()) or ()) > 0:
                return candidate

    wm = getattr(bpy.context, 'window_manager', None)
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for candidate in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(candidate, 'type', None) == 'VIEW_3D' and len(getattr(candidate, 'spaces', ()) or ()) > 0:
                return candidate
    return None


def _tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
    except Exception:
        pass

class JiggleSettings:
    def __init__(self, root_elasticity, angle_elasticity, length_elasticity, elasticity_soften, gravity, blend, air_drag, friction, collision_radius):
        self.angle_elasticity = angle_elasticity
        self.length_elasticity = length_elasticity
        self.root_elasticity = root_elasticity
        self.elasticity_soften = elasticity_soften
        self.gravity = gravity
        self.blend = blend
        self.air_drag = air_drag
        self.friction = friction
        self.collision_radius = collision_radius
    @classmethod
    def from_bone(cls, bone):
        return cls(bone.jiggle_root_elasticity, bone.jiggle_angle_elasticity, bone.jiggle_length_elasticity, bone.jiggle_elasticity_soften, bone.jiggle_gravity, bone.jiggle_blend, bone.jiggle_air_drag, bone.jiggle_friction, bone.jiggle_collision_radius)

STATIC_JIGGLE_SETTINGS = JiggleSettings(1.0,1.0,1.0,0.0,0.0,1.0,0.0,1.0,0.1)

def get_jiggle_settings(bone, static=False):
    if static:
        while not bone.jiggle.enable:
            if not bone.parent:
                return STATIC_JIGGLE_SETTINGS
            bone = bone.parent
        return JiggleSettings(1.0,1.0,1.0,0.0,0.0,bone.jiggle_blend,0.0,1.0,0.1)
    return JiggleSettings.from_bone(bone)

class VirtualParticle:
    def read(self):
        self.obj_world_matrix = self.obj.matrix_world
        self.bone = self.obj.pose.bones[self.bone_name]

        match self.particleType:
            case 'normal':
                self.position = self.bone.jiggle.position1.copy()
                self.position_last = self.bone.jiggle.position_last1
                self.rest_pose_position = self.bone.jiggle.rest_pose_position1
                self.pose = (self.obj_world_matrix@self.bone.head)
                self.working_position = self.position.copy()
                self.jiggle_settings = get_jiggle_settings(self.bone, self.static)
            case 'backProject':
                self.position = self.bone.jiggle.position0.copy()
                self.position_last = self.bone.jiggle.position_last0
                self.rest_pose_position = self.bone.jiggle.rest_pose_position0
                self.jiggle_settings = STATIC_JIGGLE_SETTINGS
                headpos = self.bone.head
                tailpos = self.bone.tail
                diff = (headpos-tailpos)
                if diff.length < MERGE_BONE_THRESHOLD:
                    diff = diff.normalized()*MERGE_BONE_THRESHOLD*2
                self.pose = self.obj_world_matrix@(diff+headpos)
                self.parent_pose = self.obj_world_matrix@((diff*2.0)+headpos)
                self.working_position = self.pose.copy()
            case 'forwardProject':
                self.position = self.bone.jiggle.position2.copy()
                self.position_last = self.bone.jiggle.position_last2
                self.rest_pose_position = self.bone.jiggle.rest_pose_position2
                headpos = self.bone.head
                tailpos = self.bone.tail
                diff = tailpos - headpos
                if diff.length < MERGE_BONE_THRESHOLD:
                    diff = diff.normalized()*MERGE_BONE_THRESHOLD*2
                self.pose = self.obj_world_matrix@(headpos+diff)
                self.working_position = self.position.copy()
                self.jiggle_settings = get_jiggle_settings(self.bone, self.static)
        if self.parent:
            self.parent_pose = self.parent.pose
        self.desired_length_to_parent = max((self.pose - self.parent_pose).length, MERGE_BONE_THRESHOLD)
        self.needs_collision = self.get_needs_collision()

    def __init__(self, obj, bone, particleType, static=False):
        self.obj = obj
        self.obj_world_matrix = obj.matrix_world
        self.bone = bone
        self.bone_name = bone.name
        self.particleType = particleType
        self.static = static
        self.parent = None
        self.pose = ZERO_VEC
        self.parent_pose = ZERO_VEC
        self.rolling_error = IDENTITY_QUAT
        self.desired_length_to_parent = 1
        self.children = []
        self.jiggle_settings = None
        self.desired_constrain = ZERO_VEC
        self.needs_collision = False
        self.read()

    def set_parent(self, parent):
        self.parent = parent
        parent.set_child(self)
        self.parent_pose = parent.pose
        self.desired_length_to_parent = max((self.pose - self.parent_pose).length, MERGE_BONE_THRESHOLD)

    def set_child(self, child):
        self.children.append(child)

    def write(self):
        match self.particleType:
            case 'backProject':
                self.bone.jiggle.position0 = self.position
                self.bone.jiggle.position_last0 = self.position_last
                self.bone.jiggle.rest_pose_position0 = self.rest_pose_position
            case 'normal':
                self.bone.jiggle.position1 = self.position
                self.bone.jiggle.position_last1 = self.position_last
                self.bone.jiggle.rest_pose_position1 = self.rest_pose_position
            case 'forwardProject':
                self.bone.jiggle.position2 = self.position
                self.bone.jiggle.position_last2 = self.position_last
                self.bone.jiggle.rest_pose_position2 = self.rest_pose_position

    def verlet_integrate(self, dt2, gravity, wind_force=ZERO_VEC):
        if not self.parent:
            return
        delta = self.position - self.position_last
        local_space_velocity = delta - (self.parent.position - self.parent.position_last)
        velocity = delta - local_space_velocity
        if self.parent.parent:
            self.working_position = self.position + velocity * (1.0-self.parent.jiggle_settings.air_drag) + local_space_velocity * (1.0-self.parent.jiggle_settings.friction) + gravity * self.parent.jiggle_settings.gravity * dt2 + wind_force * dt2
        else:
            self.working_position = self.position + velocity * (1.0-self.jiggle_settings.air_drag) + local_space_velocity * (1.0-self.jiggle_settings.friction) + gravity * self.jiggle_settings.gravity * dt2 + wind_force * dt2

    def mesh_collide(self, collider, depsgraph, position):
        collider_matrix = collider.matrix_world
        local_working_position = collider_matrix.inverted() @ position
        result, local_location, local_normal, _ = collider.closest_point_on_mesh(local_working_position, depsgraph=depsgraph)
        if not result:
            return position
        location = collider_matrix @ local_location
        normal = collider_matrix.to_quaternion() @ local_normal
        diff = position-location

        local_radius = self.parent.jiggle_settings.collision_radius
        bone_matrix_world = (self.bone.id_data.matrix_world @ self.bone.matrix)
        world_radius = sum(bone_matrix_world.to_scale()) / 3.0 * local_radius

        if (diff).length > world_radius:
            return position
        return location + diff.normalized() * world_radius

    def empty_collide(self, collider, position):
        collider_matrix = collider.matrix_world

        local_radius = self.parent.jiggle_settings.collision_radius
        bone_matrix_world = (self.bone.id_data.matrix_world @ self.bone.matrix)
        world_radius = sum(bone_matrix_world.to_scale()) / 3.0 * local_radius

        world_vec = (position-collider_matrix.translation).normalized()*world_radius;
        local_vec = collider_matrix.inverted().to_3x3() @ world_vec

        local_working_position = collider_matrix.inverted() @ position
        local_radius = local_vec.length

        diff = local_working_position
        empty_radius = 1.0
        if diff.length-local_radius > empty_radius:
            return position
        local_working_position = diff.normalized() * (empty_radius+local_radius)
        return collider_matrix @ local_working_position

    def get_needs_collision(self):
        if not self.bone.jiggle.collider_type:
            return False
        if self.bone.jiggle.collider_type == 'Object':
            if not self.bone.jiggle.collider:
                return False
        else:
            if not self.bone.jiggle.collider_collection:
                return False
        return True

    def solve_collisions(self, depsgraph, position):
        if self.bone.jiggle.collider_type == 'Object':
            collider = self.bone.jiggle.collider
            if collider.type == 'MESH':
                return self.mesh_collide(collider, depsgraph, position)
            if collider.type == 'EMPTY':
                return self.empty_collide(collider, position)
        else:
            collider_collection = self.bone.jiggle.collider_collection
            for collider in collider_collection.objects:
                if collider.type == 'MESH':
                    position = self.mesh_collide(collider, depsgraph, position)
                if collider.type == 'EMPTY':
                    position = self.empty_collide(collider, position)
        return position

    def constrain_angle(self):
        parent_aim_pose = (self.parent_pose - self.parent.parent_pose).normalized()
        if not self.parent.parent:
            parent_aim = (self.parent.desired_constrain - self.parent.parent_pose).normalized()
        else:
            parent_aim = (self.parent.desired_constrain - self.parent.parent.desired_constrain).normalized()

        current_length = (self.working_position - self.parent.desired_constrain).length
        from_to_rot = parent_aim_pose.rotation_difference(parent_aim)
        current_pose_dir = (self.pose - self.parent_pose).normalized()
        constraintTarget = from_to_rot @ (current_pose_dir * current_length)

        error = (self.working_position - (self.parent.desired_constrain + constraintTarget)).length
        error /= self.desired_length_to_parent
        error = min(error, 1.0)
        error = pow(error, self.parent.jiggle_settings.elasticity_soften*self.parent.jiggle_settings.elasticity_soften)
        self.desired_constrain = self.working_position.lerp(self.parent.desired_constrain + constraintTarget, self.parent.jiggle_settings.angle_elasticity * self.parent.jiggle_settings.angle_elasticity * error)
        return self.parent.desired_constrain + constraintTarget

    def constrain(self, depsgraph):
        if not self.parent:
            return

        if not self.parent.parent:
            self.desired_constrain = self.working_position = self.working_position.lerp(self.pose, self.jiggle_settings.root_elasticity*self.jiggle_settings.root_elasticity)

            headpos = self.bone.head
            tailpos = self.bone.tail
            diff = (headpos-tailpos)
            self.parent.desired_constrain = self.desired_constrain + (self.obj_world_matrix.to_3x3()@diff)
            return

        # constrain angle
        forward_constraint = self.constrain_angle()

        if self.needs_collision:
            self.desired_constrain = self.solve_collisions(depsgraph, self.desired_constrain)

        length_elasticity = self.parent.jiggle_settings.length_elasticity * self.parent.jiggle_settings.length_elasticity
        if self.bone.bone.use_connect:
            length_elasticity = 1

        # constrain length
        diff = self.desired_constrain - self.parent.desired_constrain
        dir = diff.normalized()
        forward_constraint = self.desired_constrain.lerp(self.parent.desired_constrain + dir * self.desired_length_to_parent, length_elasticity)
        self.desired_constrain = forward_constraint

        if not self.needs_collision or self.parent.jiggle_settings.angle_elasticity == 1 and self.parent.jiggle_settings.length_elasticity == 1:
            self.working_position = forward_constraint
            return

        if len(self.children) > 0:
            child = self.children[0]

            aim_pose = (child.pose - self.parent_pose).normalized()
            aim = (child.working_position - self.parent.working_position).normalized()
            from_to_rot = aim_pose.rotation_difference(aim)
            parent_to_self = (self.pose - self.parent_pose).normalized()
            real_length = (self.working_position - self.parent.working_position).length
            targetPos = (from_to_rot@(parent_to_self*real_length)) + self.parent.working_position

            error = (self.working_position - targetPos).length
            error /= self.desired_length_to_parent
            error = min(error, 1.0)
            error = pow(error, self.parent.jiggle_settings.elasticity_soften*self.parent.jiggle_settings.elasticity_soften)
            backward_constraint = self.working_position.lerp(targetPos, (self.parent.jiggle_settings.angle_elasticity * self.parent.jiggle_settings.angle_elasticity * error))

            child_length_elasticity = self.jiggle_settings.length_elasticity * self.jiggle_settings.length_elasticity
            if child.bone.bone.use_connect:
                child_length_elasticity = 1

            cdiff = backward_constraint - child.working_position
            cdir = cdiff.normalized()
            backward_constraint = backward_constraint.lerp(child.working_position + cdir * child.desired_length_to_parent, child_length_elasticity*0.5)
            self.working_position = forward_constraint.lerp(backward_constraint, 0.5)
        else:
            self.working_position = forward_constraint

    def finish_step(self):
        self.position_last = self.position
        self.position = self.working_position

    def apply_pose(self):
        if len(self.children) == 0:
            self.rest_pose_position = self.pose
            return
        child = self.children[0]

        inverted_obj_matrix = self.obj_world_matrix.inverted()

        local_pose = (inverted_obj_matrix@self.pose)
        local_child_pose = (inverted_obj_matrix@child.pose)
        local_child_working_position = (inverted_obj_matrix@child.working_position)
        local_working_position = (inverted_obj_matrix@self.working_position)

        self.rest_pose_position = self.pose

        if not self.parent:
            self.rolling_error = IDENTITY_QUAT
            return

        if len(self.children) == 1:
            cachedAnimatedVector = (local_child_pose - local_pose).normalized()
            simulatedVector = (local_child_working_position - local_working_position).normalized()
        else:
            cachedAnimatedVectorSum = ZERO_VEC.copy() 
            simulatedVectorSum = ZERO_VEC.copy()
            for child in self.children:
                local_child_pose = (inverted_obj_matrix@child.pose)
                local_child_working_position = (inverted_obj_matrix@child.working_position)
                cachedAnimatedVectorSum += (local_child_pose - local_pose).normalized()
                simulatedVectorSum += (local_child_working_position - local_working_position).normalized()
            cachedAnimatedVector = (cachedAnimatedVectorSum * (1.0/len(self.children))).normalized()
            simulatedVector = (simulatedVectorSum * (1.0/len(self.children))).normalized()
        animPoseToPhysicsPose = cachedAnimatedVector.rotation_difference(simulatedVector).slerp(IDENTITY_QUAT, 1-self.jiggle_settings.blend).normalized()

        loc, rot, scale = self.bone.matrix.decompose()
        if self.bone.bone.use_inherit_rotation:
            prot = self.parent.rolling_error.inverted().slerp(IDENTITY_QUAT, 1-self.jiggle_settings.blend)
        else:
            prot = IDENTITY_QUAT


        parent_pose_aim = local_pose - (inverted_obj_matrix@self.parent_pose) 
        adjusted_pose = (inverted_obj_matrix@self.parent.working_position) + (self.parent.rolling_error@parent_pose_aim)
        diff = (inverted_obj_matrix@self.working_position)-adjusted_pose

        settings = self.bone.jiggle
        if not settings.rest_basis_valid:
            settings.rest_basis = self.bone.matrix_basis
            settings.rest_basis_valid = True

        loc = loc + (prot@diff) * self.jiggle_settings.blend
        self.bone.matrix = Matrix.Translation(loc) @ prot.to_matrix().to_4x4() @ animPoseToPhysicsPose.to_matrix().to_4x4() @ rot.to_matrix().to_4x4() @ Matrix.Diagonal(scale).to_4x4()
        self.rolling_error = self.parent.rolling_error.slerp(IDENTITY_QUAT, self.jiggle_settings.blend)@animPoseToPhysicsPose

def get_virtual_particles_obj(obj):
    global _jiggle_globals
    _jiggle_globals.prune_virtual_point_caches(keep_object=obj)
    jiggle_object_virtual_point_cache = _jiggle_globals.jiggle_object_virtual_point_cache

    if obj in jiggle_object_virtual_point_cache:
        virtual_particles = jiggle_object_virtual_point_cache[obj]
        for particle in virtual_particles:
            particle.read()
        return jiggle_object_virtual_point_cache[obj]

    virtual_particles_cache = []
    bones = obj.pose.bones
    # A bone nobody reset still holds the zero state: it would be pulled from the world
    # origin up to its pose on the first simulated frame.
    for bone in bones:
        settings = bone.jiggle
        if settings.mode != 'none' and settings.position1.length_squared == 0.0 and settings.rest_pose_position1.length_squared == 0.0:
            reset_bone(bone)
    def visit(bone, last_particle=None):
        bone_jiggle = bone.jiggle
        static = not bone_jiggle.enable
        match bone.jiggle.mode:
            case 'normal':
                particle = VirtualParticle(obj, bone, 'normal', static)
                particle.set_parent(last_particle)
                virtual_particles_cache.append(particle)
                last_particle = particle
            case 'root':
                back_particle = VirtualParticle(obj, bone, 'backProject', static)
                virtual_particles_cache.append(back_particle)
                particle = VirtualParticle(obj, bone, 'normal', static)
                particle.set_parent(back_particle)
                virtual_particles_cache.append(particle)
                last_particle = particle
            case 'tip':
                particle = VirtualParticle(obj, bone, 'normal', static)
                particle.set_parent(last_particle)
                virtual_particles_cache.append(particle)
                tip = VirtualParticle(obj, bone, 'forwardProject', static)
                tip.set_parent(particle)
                virtual_particles_cache.append(tip)
                return
            case 'solo':
                back_particle = VirtualParticle(obj, bone, 'backProject', static)
                virtual_particles_cache.append(back_particle)
                particle = VirtualParticle(obj, bone, 'normal', static)
                particle.set_parent(back_particle)
                virtual_particles_cache.append(particle)
                tip = VirtualParticle(obj, bone, 'forwardProject', static)
                tip.set_parent(particle)
                virtual_particles_cache.append(tip)
                return
        for child in bone.children:
            if child.jiggle.mode == 'none':
                continue
            visit(child, last_particle)
    for bone in bones:
        if bone.jiggle.mode == 'root' or bone.jiggle.mode == 'solo':
            visit(bone)
    jiggle_object_virtual_point_cache[obj] = virtual_particles_cache
    _jiggle_globals.prune_virtual_point_caches(keep_object=obj)
    return virtual_particles_cache

def get_virtual_particles(scene):
    global _jiggle_globals
    _jiggle_globals.prune_virtual_point_caches(scene=scene)
    jiggle_baking = _jiggle_globals.jiggle_baking
    jiggle_scene_virtual_point_cache = _jiggle_globals.jiggle_scene_virtual_point_cache

    if len(jiggle_scene_virtual_point_cache) > 0:
        return jiggle_scene_virtual_point_cache 
    jiggle_objs = [obj for obj in scene.objects if obj.type == 'ARMATURE' and obj.jiggle.enable and not obj.jiggle.mute and (not obj.jiggle.freeze or jiggle_baking)]
    for obj in jiggle_objs:
        jiggle_scene_virtual_point_cache.extend(get_virtual_particles_obj(obj))
    return jiggle_scene_virtual_point_cache 


def _action_fcurve_owners(action):
    """Every F-curve of an action, with the collection that owns it.

    Blender 5.1 has no ``Action.fcurves``. An action holds slots, layers, strips
    and one channelbag per slot, and the curves live on the channelbag. Reading
    the old flat collection raises AttributeError, which is what made
    ``anim.jiggle_clear_keyframes`` -- a button on the panel -- fail outright,
    and what made ``_keyframe_selection_snapshot`` silently return nothing
    because its own try/except hid the same error.
    """
    if action is None:
        return []
    owners = []
    flat = getattr(action, 'fcurves', None)
    if flat is not None:
        for fcurve in tuple(flat):
            owners.append((flat, fcurve))
        return owners
    for layer in getattr(action, 'layers', ()):
        for strip in getattr(layer, 'strips', ()):
            for channelbag in getattr(strip, 'channelbags', ()):
                for fcurve in tuple(channelbag.fcurves):
                    owners.append((channelbag.fcurves, fcurve))
    return owners


def _action_fcurves(action):
    return [fcurve for _owner, fcurve in _action_fcurve_owners(action)]


def lerp(a, b, t):
    return a + (b - a) * t

def is_bone_animated(armature, bone_name):
    anim_data = armature.animation_data
    if not anim_data or not anim_data.action:
        return False
    if bpy.app.version < (5, 0, 0):
        for fcurve in anim_data.action.fcurves:
            if f'pose.bones["{bone_name}"]' in fcurve.data_path:
                return True
    else:
        for slot in anim_data.action.slots:
            channelbag = anim_utils.action_get_channelbag_for_slot(anim_data.action, slot)
            if not channelbag:
                continue
            for fcurve in channelbag.fcurves:
                if f'pose.bones["{bone_name}"]' in fcurve.data_path:
                    return True
    return False

def reset_bone(b):
    head_pos = (b.id_data.matrix_world@b.head)
    tail_pos = (b.id_data.matrix_world@b.tail)

    b.jiggle.rest_pose_position0 = b.jiggle.position0 = b.jiggle.position_last0 = head_pos + (head_pos-tail_pos)
    b.jiggle.rest_pose_position1 = b.jiggle.position1 = b.jiggle.position_last1 = head_pos
    b.jiggle.rest_pose_position2 = b.jiggle.position2 = b.jiggle.position_last2 = tail_pos

def update_pose_bone_jiggle_prop(self,context,prop): 
    global _jiggle_globals
    if _jiggle_globals.propagating_props:
        return
    if context.mode != 'POSE':
        return
    if context.selected_pose_bones is None:
        return
    def keyframe(auto_key, b, prop):
        if auto_key and prop in ['jiggle_root_elasticity', 'jiggle_angle_elasticity', 'jiggle_length_elasticity', 'jiggle_elasticity_soften', 'jiggle_gravity', 'jiggle_blend', 'jiggle_air_drag', 'jiggle_friction']:
            b.keyframe_insert(data_path=prop, index=-1)
    _jiggle_globals.propagating_props = True
    try:
        auto_key = bpy.context.scene.tool_settings.use_keyframe_insert_auto
        for b in context.selected_pose_bones:
            if b == self:
                keyframe(auto_key, b, prop)
                continue
            if getattr(b,prop) == getattr(self,prop):
                keyframe(auto_key, b, prop)
                continue
            setattr(b, prop, getattr(self,prop))
            keyframe(auto_key, b, prop)
    finally:
        _jiggle_globals.propagating_props = False

def mark_jiggle_tree(obj):
    if not obj or obj.type != 'ARMATURE':
        return
    global _jiggle_globals
    _jiggle_globals.clear_per_object_caches()
    def visit(bone, last_jiggle_parent=None, promotion_queue=[]):
        jiggle_enabled = getattr(bone.jiggle, 'enable', False)
        jiggle_count = 0
        if last_jiggle_parent is None and jiggle_enabled:
            last_jiggle_parent = bone
            bone.jiggle.mode = 'root'
        elif jiggle_enabled:
            last_bone = bone
            for promoted_bone in promotion_queue:
                if (promoted_bone.head-last_bone.head).length < MERGE_BONE_THRESHOLD:
                    promoted_bone.jiggle.mode = 'merge'
                elif promoted_bone.parent and (promoted_bone.head-promoted_bone.parent.head).length < MERGE_BONE_THRESHOLD:
                    promoted_bone.jiggle.mode = 'merge'
                else:
                    promoted_bone.jiggle.mode = 'normal'
                last_bone = promoted_bone
            promotion_queue.clear()
            bone.jiggle.mode = 'normal' if len(bone.children) > 0 else 'tip'
            last_jiggle_parent = bone
            jiggle_count += 1
        elif not jiggle_enabled and last_jiggle_parent is not None:
            promotion_queue.append(bone)

        if len(bone.children) == 0:
            promotion_queue.clear()

        for child in bone.children:
            jiggle_count += visit(child, last_jiggle_parent, promotion_queue.copy())
        if jiggle_count == 0:
            if bone.jiggle.mode == 'root':
                bone.jiggle.mode = 'solo'
            elif bone.jiggle.mode == 'normal':
                bone.jiggle.mode = 'tip'
        return jiggle_count

    bones = obj.pose.bones
    for bone in bones:
        bone.jiggle.mode = 'none'
    root_bones = [b for b in bones if b.parent is None]
    for bone in root_bones:
        visit(bone, None, [])

def update_nested_jiggle_prop(self,context,prop): 
    global _jiggle_globals
    if _jiggle_globals.propagating_props:
        return
    _jiggle_globals.propagating_props = True
    try:
        if context.mode != 'POSE':
            return
        if context.selected_pose_bones is None:
            return
        if prop == 'enable':
            self.id_data.jiggle.enable = True
        for b in context.selected_pose_bones:
            if getattr(b.jiggle,prop) == getattr(self,prop):
                continue
            setattr(b.jiggle, prop, getattr(self,prop))
        if prop == 'enable':
            mark_jiggle_tree(self.id_data)
            for b in (*context.selected_pose_bones, context.active_pose_bone):
                if b is not None:
                    reset_bone(b)
                    if not b.jiggle.enable:
                        b.jiggle.rest_basis_valid = False
    finally:
        _jiggle_globals.propagating_props = False

def get_jiggle_parent(b):
    p = b.parent
    if p and getattr(p.jiggle,'enable', False):
        return p
    return None

def billboard_circle(verts, center, radius, segments=8):
    rv3d = bpy.context.region_data
    if rv3d is None:
        return
    view_matrix = rv3d.view_matrix
    inv_view = view_matrix.inverted()
    right = inv_view.col[0].xyz.normalized()
    up = inv_view.col[1].xyz.normalized()
    _append_billboard_circle(verts, center, radius, right, up, segments)


def _append_billboard_circle(verts, center, radius, right, up, segments=8):
    segments = max(3, int(segments))
    cache = _jiggle_globals._overlay_circle_angle_cache if segments == 8 else tuple(
        (math.cos(2 * math.pi * i / segments), math.sin(2 * math.pi * i / segments))
        for i in range(segments)
    )
    count = len(cache)
    for index, (cos_v, sin_v) in enumerate(cache):
        next_cos, next_sin = cache[(index + 1) % count]
        verts.append(center + (right * cos_v + up * sin_v) * radius)
        verts.append(center + (right * next_cos + up * next_sin) * radius)


def _overlay_shader():
    return _jiggle_globals._overlay_shader


def draw_callback():
    scene = getattr(bpy.context, 'scene', None)
    jiggle = getattr(scene, 'jiggle', None) if scene is not None else None
    if jiggle is None or not _jiggle_runtime_callbacks_enabled(scene):
        return
    area = getattr(bpy.context, 'area', None)
    if area is None:
        return
    spaces = tuple(getattr(area, 'spaces', ()) or ())
    if not any(
        getattr(space, 'type', None) == 'VIEW_3D'
        and bool(getattr(getattr(space, 'overlay', None), 'show_overlays', False))
        for space in spaces
    ):
        return
    area_properties = _jiggle_globals.peek_area_overlay_properties(area)
    if area_properties is None:
        return
    do_pose = bool(area_properties.overlay_pose)
    do_simulation = bool(area_properties.overlay_simulation)
    if not (do_pose or do_simulation):
        return
    shader = _jiggle_globals._overlay_shader
    batch_factory = _jiggle_globals._overlay_batch_factory
    snapshot = _jiggle_globals._overlay_snapshot
    if shader is None or batch_factory is None or not snapshot:
        return
    rv3d = getattr(bpy.context, 'region_data', None)
    if rv3d is None:
        return
    try:
        inv_view = rv3d.view_matrix.inverted()
        right = inv_view.col[0].xyz.normalized()
        up = inv_view.col[1].xyz.normalized()
    except Exception:
        return
    simulation_verts = []
    rest_verts = []
    for parent_rest, rest, parent_position, position, world_radius in snapshot:
        if do_pose:
            rest_verts.extend((parent_rest, rest))
        if do_simulation:
            simulation_verts.extend((parent_position, position))
            _append_billboard_circle(simulation_verts, position, world_radius, right, up, 8)
    try:
        shader.bind()
        if rest_verts:
            batch = batch_factory(shader, 'LINES', {'pos': rest_verts})
            shader.uniform_float('color', (0.10196078431372549, 1.0, 0.10196078431372549, 1.0))
            batch.draw(shader)
        if simulation_verts:
            batch = batch_factory(shader, 'LINES', {'pos': simulation_verts})
            shader.uniform_float('color', (0.29411764705882354, 0.0, 0.5725490196078431, 1.0))
            batch.draw(shader)
    except Exception:
        return


def jiggle_simulate(scene, depsgraph, virtual_particles, framecount):
    dt = 1.0 / scene.render.fps
    jiggle = scene.jiggle
    substeps = max(1, min(16, int(getattr(jiggle, 'substeps', 1) or 1)))
    iterations = max(1, min(32, int(getattr(jiggle, 'iterations', 1) or 1)))
    sub_dt = dt / float(substeps)
    sub_dt2 = sub_dt * sub_dt
    gravity_scale = max(0.0, float(getattr(jiggle, 'gravity', 1.0) or 0.0))
    scene_gravity = scene.gravity * gravity_scale

    # Get wind settings
    wind_enabled = jiggle.enable_wind
    wind_direction = Vector(jiggle.wind_direction).normalized() if jiggle.wind_direction.length > 0 else Vector((1, 0, 0))
    wind_speed = jiggle.wind_speed
    turbulence_scale = jiggle.wind_turbulence_scale
    evolution_speed = jiggle.wind_evolution_speed

    for frame_step in range(framecount):
        for substep in range(substeps):
            # Calculate evolution value for 4D noise (changes over time)
            evolution_frame = scene.frame_current + frame_step + (substep / float(substeps))
            evolution = evolution_frame * evolution_speed if evolution_speed > 0 else 0

            for particle in virtual_particles:
                # Calculate wind force at particle position
                if wind_enabled and wind_speed > 0:
                    wind_force = get_wind_force(particle.position, wind_direction, wind_speed, turbulence_scale, evolution)
                else:
                    wind_force = ZERO_VEC

                particle.verlet_integrate(sub_dt2, scene_gravity, wind_force)
            for _iteration in range(iterations):
                for particle in virtual_particles:
                    particle.constrain(depsgraph)
            for particle in virtual_particles:
                particle.finish_step()
    for particle in virtual_particles:
        particle.apply_pose()
        particle.write()

@persistent
def jiggle_playback_start(scene):
    global _jiggle_globals
    if not _jiggle_runtime_callbacks_enabled(scene):
        return
    _jiggle_globals.is_animation_playing = True

@persistent
def jiggle_playback_end(scene):
    global _jiggle_globals
    if not _jiggle_runtime_callbacks_enabled(scene):
        _jiggle_globals.is_animation_playing = False
        return
    _jiggle_globals.is_animation_playing = False

@persistent                
def jiggle_post(scene,depsgraph):
    global _jiggle_globals
    if not _jiggle_runtime_callbacks_enabled(scene) or _jiggle_globals.suspend_runtime_evaluation:
        return
    _jiggle_globals.clear_per_frame_caches()
    physics_resetting = _jiggle_globals.physics_resetting
    jiggle_scene_virtual_point_cache = _jiggle_globals.jiggle_scene_virtual_point_cache
    profiler = _jiggle_globals.get_profiler(create=bool(getattr(getattr(scene, 'jiggle', None), 'debug', False)))
    is_rendering = _jiggle_globals.is_rendering

    if physics_resetting:
        return
    objects = scene.objects
    jiggle = scene.jiggle

    if not jiggle.enable or is_rendering:
        return

    if not scene.jiggle.simulate_during_scrub and not _jiggle_globals.is_animation_playing and not _jiggle_globals.jiggle_baking:
        # Nothing is simulated while stopped, but returning to the first frame still
        # starts over: the next playback must not carry the previous one's motion.
        if scene.frame_current == scene.frame_start and jiggle.lastframe != scene.frame_current and not jiggle.loop and not _jiggle_globals.is_preroll:
            jiggle_reset(bpy.context)
        return

    if jiggle.debug and profiler is not None: profiler.enable()

    lastframe = jiggle.lastframe

    if (lastframe == scene.frame_current):
        try:
            virtual_particles = get_virtual_particles(scene)
        except KeyError:
            jiggle_reset(bpy.context)
            if jiggle.debug and profiler is not None: profiler.disable()
            return
        for particle in virtual_particles:
            particle.apply_pose()
        _jiggle_globals.refresh_overlay_snapshot(scene, virtual_particles)
        if jiggle.debug and profiler is not None: profiler.disable()
        return

    frame_start, frame_end, frame_current = scene.frame_start, scene.frame_end, scene.frame_current
    frame_is_preroll = _jiggle_globals.is_preroll
    frame_loop = jiggle.loop

    if (frame_current == frame_start) and not frame_loop and not frame_is_preroll:
        jiggle_reset(bpy.context)
        if jiggle.debug and profiler is not None: profiler.disable()
        return

    if frame_current >= lastframe:
        frames_elapsed = frame_current - lastframe
    else:
        e1 = (frame_end - lastframe) + (frame_current - frame_start) + 1
        e2 = lastframe - frame_current
        frames_elapsed = min(e1,e2)

    if frames_elapsed > 4 or frame_is_preroll:
        frames_elapsed = 1

    jiggle.lastframe = frame_current
    accumulatedFrames = frames_elapsed

    try:
        virtual_particles = get_virtual_particles(scene)
    except KeyError:
        jiggle_reset(bpy.context)
        if jiggle.debug and profiler is not None: profiler.disable()
        return

    jiggle_simulate(scene, depsgraph, virtual_particles, accumulatedFrames)
    _jiggle_globals.refresh_overlay_snapshot(scene, virtual_particles)

    if jiggle.debug and profiler is not None: profiler.disable()

def collider_poll(self, object):
    return object.type == 'MESH' or object.type == 'EMPTY'

@persistent        
def jiggle_render_pre(scene):
    global _jiggle_globals
    if not _jiggle_runtime_callbacks_enabled(scene):
        _jiggle_globals.is_rendering = False
        return
    _jiggle_globals.is_rendering = True
    
@persistent
def jiggle_render_post(scene):
    global _jiggle_globals
    _jiggle_globals.is_rendering = False
    
@persistent
def jiggle_render_cancel(scene):
    global _jiggle_globals
    _jiggle_globals.is_rendering = False

class ARMATURE_OT_JiggleCopy(Operator):
    """Copy active jiggle settings to selected bones"""
    bl_idname = "armature.jiggle_copy"
    bl_label = "Copy Settings to Selected"
    bl_options = {'UNDO'}
    
    @classmethod
    def poll(cls,context):
        return context.mode in ['POSE'] and context.active_pose_bone and (len(context.selected_pose_bones)>1) and getattr(context.active_pose_bone.jiggle, "enable", False)
    
    def execute(self,context):
        bone = context.active_pose_bone
        for other_bone in context.selected_pose_bones:
            if other_bone == bone: continue
            other_bone.jiggle.enable = bone.jiggle.enable
            other_bone.jiggle.collider_type = bone.jiggle.collider_type
            other_bone.jiggle.collider = bone.jiggle.collider
            other_bone.jiggle.collider_collection = bone.jiggle.collider_collection
            other_bone.jiggle_root_elasticity = bone.jiggle_root_elasticity
            other_bone.jiggle_angle_elasticity = bone.jiggle_angle_elasticity
            other_bone.jiggle_length_elasticity = bone.jiggle_length_elasticity
            other_bone.jiggle_elasticity_soften = bone.jiggle_elasticity_soften
            other_bone.jiggle_gravity = bone.jiggle_gravity
            other_bone.jiggle_blend = bone.jiggle_blend
            other_bone.jiggle_air_drag = bone.jiggle_air_drag
            other_bone.jiggle_friction = bone.jiggle_friction
            other_bone.jiggle_collision_radius = bone.jiggle_collision_radius
        return {'FINISHED'}

def _nla_stack_actions(animation_data):
    """Actions the NLA stack evaluates, so the channels they drive count as animated."""
    if animation_data is None or not animation_data.use_nla:
        return []
    tracks = tuple(animation_data.nla_tracks)
    any_solo = any(track.is_solo for track in tracks)
    actions = []

    def collect(strips):
        for strip in strips:
            if strip.mute:
                continue
            if strip.type == 'META':
                collect(strip.strips)
            elif strip.action is not None:
                actions.append(strip.action)

    for track in tracks:
        if not track.mute and (track.is_solo or not any_solo):
            collect(track.strips)
    return actions


def _animated_channels(animation_data):
    """(data_path, array_index) of every channel animation writes on the next frame change."""
    if animation_data is None:
        return set()
    actions = _nla_stack_actions(animation_data)
    if animation_data.action is not None:
        actions.append(animation_data.action)
    return {(fcurve.data_path, fcurve.array_index) for action in actions for fcurve in _action_fcurves(action)}


def _restore_unkeyed_channels(bone, rest, animated):
    """Put back the channels of a bone that animation does not write. Returns True if any was written."""
    base = bone.path_from_id()
    mode = bone.rotation_mode
    if mode == 'QUATERNION':
        rotation_name, rotation_size = 'rotation_quaternion', 4
    elif mode == 'AXIS_ANGLE':
        rotation_name, rotation_size = 'rotation_axis_angle', 4
    else:
        rotation_name, rotation_size = 'rotation_euler', 3
    channels = [('location', index) for index in range(3)]
    channels += [(rotation_name, index) for index in range(rotation_size)]
    channels += [('scale', index) for index in range(3)]
    free = [(name, index) for name, index in channels if (f'{base}.{name}', index) not in animated]
    if not free:
        return False
    if len(free) == len(channels):
        bone.matrix_basis = rest
        return True
    location, quaternion, scale = rest.decompose()
    if mode == 'QUATERNION':
        rotation = quaternion
    elif mode == 'AXIS_ANGLE':
        axis, angle = quaternion.to_axis_angle()
        rotation = (angle, axis.x, axis.y, axis.z)
    else:
        rotation = quaternion.to_euler(mode)
    values = {'location': location, rotation_name: rotation, 'scale': scale}
    for name, index in free:
        getattr(bone, name)[index] = values[name][index]
    return True


def _restore_rest_poses(scene):
    """Put channels without animation back to the pose they had before the simulation.

    The simulation writes into the pose bones. An animated channel gets its value back
    from the action or the NLA stack on the next frame change, but any other channel
    would keep the last simulated value, and the next reset would take it as its rest.
    """
    restored = False
    for ob in scene.objects:
        if ob.type != 'ARMATURE':
            continue
        animated = None
        for bone in ob.pose.bones:
            settings = bone.jiggle
            if not settings.rest_basis_valid:
                continue
            settings.rest_basis_valid = False
            if animated is None:
                animated = _animated_channels(ob.animation_data)
            if _restore_unkeyed_channels(bone, settings.rest_basis, animated):
                restored = True
    return restored


def jiggle_reset(context):
    global _jiggle_globals
    _jiggle_globals.clear_per_object_caches()
    _jiggle_globals.clear_per_frame_caches()
    if _restore_rest_poses(context.scene):
        context.view_layer.update()
    jiggle_objs = [obj for obj in context.scene.objects if obj.type == 'ARMATURE' and obj.jiggle.enable and not obj.jiggle.mute]
    for ob in jiggle_objs:
        mark_jiggle_tree(ob)
        for bone in ob.pose.bones:
            reset_bone(bone)
    context.scene.jiggle.lastframe = context.scene.frame_current

# Legacy standalone profiler and overlay toggle operators were removed from
# registration and source because all always-on Jiggle runtime switches are now
# centralized in the Smart Cloth N-panel Always-on Toggles group.

class SCENE_OT_JiggleReset(Operator):
    """Reset jiggle physics of scene, bone, or object depending on context"""
    bl_idname = "scene.jiggle_reset"
    bl_label = "Reset Physics"
    bl_options = {'UNDO'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.mode in ['OBJECT', 'POSE']
    
    def execute(self,context):
        frame = context.scene.frame_current
        global _jiggle_globals
        _jiggle_globals.physics_resetting = True
        try:
            context.scene.frame_set(frame-1)
            jiggle_reset(context)
            context.scene.frame_set(frame)
        finally:
            _jiggle_globals.physics_resetting = False
        return {'FINISHED'}

class ANIM_OT_JiggleClearKeyframes(Operator):
    """Reset keyframes on jiggle parameters"""
    bl_idname = "anim.jiggle_clear_keyframes"
    bl_label = "Clear Parameter Keyframes"
    bl_description = "Remove keyframes from jiggle parameters on selected bones. This will not remove the jiggle settings themselves, just the keyframes that control them."
    bl_options = {'UNDO'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.mode in ['POSE'] and context.object and context.object.animation_data and context.object.animation_data.action
    
    def execute(self,context):
        action = context.object.animation_data.action
        for bone in context.selected_pose_bones:
            for prop in ['jiggle_root_elasticity', 'jiggle_angle_elasticity', 'jiggle_length_elasticity', 'jiggle_elasticity_soften', 'jiggle_gravity', 'jiggle_blend', 'jiggle_air_drag', 'jiggle_friction', 'jiggle_collision_radius']:
                data_path = f'pose.bones["{bone.name}"].{prop}'
                for owner, fcurve in _action_fcurve_owners(action):
                    if fcurve.data_path == data_path:
                        owner.remove(fcurve)
        return {'FINISHED'}

class SCENE_OT_JiggleProfile(Operator):
    """Prints the execution time of the top 20 functions to the System Console"""
    bl_idname = "scene.jiggle_profile"
    bl_label = "Print Profiling Information to Console"
    bl_options = set()
    _sms_no_undo = True
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.scene.jiggle.debug
    
    def execute(self,context):
        global _jiggle_globals
        profiler = _jiggle_globals.get_profiler(create=False)
        # pstats.Stats raises TypeError for a profiler that never sampled: Debug on
        # while scrubbing creates one, but only simulated frames fill it.
        if profiler is None or not profiler.getstats():
            self.report({'INFO'}, _jiggle_ui_text('No profiling samples are available.', '利用できる計測サンプルがありません。', context))
            return {'CANCELLED'}
        stream = io.StringIO()
        pstats.Stats(profiler, stream=stream).sort_stats('cumulative').print_stats(20)
        text_block = bpy.data.texts.get('Jiggle_Profile_Report') or bpy.data.texts.new('Jiggle_Profile_Report')
        text_block.clear()
        text_block.write(stream.getvalue())
        profiler.clear()
        self.report({'INFO'}, _jiggle_ui_text('Profiling report was written to Jiggle_Profile_Report.', '計測結果を Jiggle_Profile_Report に書き出しました。', context))
        return {'FINISHED'}

def jiggle_select(context):
    jiggle_objs = [obj for obj in context.scene.objects if obj.type == 'ARMATURE' and obj.jiggle.enable and not obj.jiggle.mute]
    for ob in jiggle_objs:
        jiggle_bones = [bone for bone in ob.pose.bones if getattr(bone.jiggle, 'enable', False)]
        for bone in jiggle_bones:
            if bpy.app.version < (5, 0, 0):
                bone.bone.select = True
            else:
                bone.select = True
    
class ARMATURE_OT_JiggleSelect(Operator):
    """Select jiggle bones on selected objects in pose mode"""
    bl_idname = "armature.jiggle_select"
    bl_label = "Select Enabled"
    bl_options = {'UNDO'}
    
    @classmethod
    def poll(cls,context):
        return context.mode in ['POSE']
    
    def execute(self,context):
        jiggle_select(context)
        return {'FINISHED'}


_ACTIVE_JIGGLE_BAKE = None
_JIGGLE_ACTION_OWNER_KEY = '_scs_jiggle_owner'
_JIGGLE_ACTION_UUID_KEY = '_scs_jiggle_uuid'
_JIGGLE_ACTION_GENERATION_KEY = '_scs_jiggle_generation'


def _jiggle_current_generation():
    lease = lifecycle.current_lease(require_current=False)
    return int(getattr(lease, 'generation', 0) or 0)


def _mark_jiggle_owned(data, transaction_uuid, generation=None):
    generation = _jiggle_current_generation() if generation is None else int(generation)
    try:
        data[_JIGGLE_ACTION_OWNER_KEY] = lifecycle.OWNER_ID
        data[_JIGGLE_ACTION_UUID_KEY] = str(transaction_uuid)
        data[_JIGGLE_ACTION_GENERATION_KEY] = generation
        return _is_jiggle_owned(data, transaction_uuid, generation)
    except Exception:
        return False


def _clear_jiggle_owner_marker(data, transaction_uuid, generation):
    if not _is_jiggle_owned(data, transaction_uuid, generation):
        return
    for key in (_JIGGLE_ACTION_GENERATION_KEY, _JIGGLE_ACTION_UUID_KEY, _JIGGLE_ACTION_OWNER_KEY):
        try:
            del data[key]
        except Exception:
            pass


def _is_jiggle_owned(data, transaction_uuid, generation):
    try:
        return (
            data.get(_JIGGLE_ACTION_OWNER_KEY) == lifecycle.OWNER_ID
            and data.get(_JIGGLE_ACTION_UUID_KEY) == str(transaction_uuid)
            and int(data.get(_JIGGLE_ACTION_GENERATION_KEY, -1)) == int(generation)
        )
    except Exception:
        return False


def _pose_bone_selected(bone):
    try:
        return bool(bone.bone.select)
    except Exception:
        try:
            return bool(bone.select)
        except Exception:
            return False


def _set_pose_bone_selected(bone, value):
    try:
        bone.bone.select = bool(value)
        return
    except Exception:
        pass
    try:
        bone.select = bool(value)
    except Exception:
        pass


def _keyframe_selection_snapshot(action):
    result = []
    if action is None:
        return result
    try:
        for fcurve in _action_fcurves(action):
            for point in tuple(fcurve.keyframe_points):
                result.append((point, bool(point.select_control_point), bool(point.select_left_handle), bool(point.select_right_handle)))
    except Exception:
        pass
    return result


def _restore_keyframe_selection(snapshot):
    for point, control, left, right in tuple(snapshot or ()):
        try:
            point.select_control_point = control
            point.select_left_handle = left
            point.select_right_handle = right
        except Exception:
            pass


class ARMATURE_OT_JiggleBake(Operator):
    """Bake this object's visible jiggle bones to keyframes."""
    bl_idname = 'armature.jiggle_bake'
    bl_label = 'Bake Jiggle'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'object', None)
        settings = getattr(obj, 'jiggle', None) if obj is not None else None
        return bool(
            obj is not None
            and getattr(context, 'mode', None) == 'POSE'
            and getattr(obj, 'type', None) == 'ARMATURE'
            and bool(getattr(settings, 'enable', False))
            and not bool(getattr(settings, 'mute', False))
        )

    def invoke(self, context, event):
        del event
        return self._start(context)

    def execute(self, context):
        return self._start(context)

    def _start(self, context):
        global _ACTIVE_JIGGLE_BAKE
        if _ACTIVE_JIGGLE_BAKE not in (None, self):
            self.report({'ERROR'}, _jiggle_ui_text('Another Jiggle bake is already running.', '別の Jiggle ベイクが実行中です。', context))
            return {'CANCELLED'}
        self._transaction_uuid = uuid.uuid4().hex
        self._generation = _jiggle_current_generation()
        if self._generation <= 0:
            self.report({'ERROR'}, _jiggle_ui_text('Jiggle bake has no active Suite generation.', 'Jiggle ベイクに有効なSuite世代がありません。', context))
            return {'CANCELLED'}
        self._owned_resources = {}
        self._timer = None
        self._created_track = None
        self._created_strip = None
        self._working_action = None
        self._scene = None
        self._object = None
        self._original = {}
        self._debug = False
        self._finished = False
        self._rolled_back = False
        try:
            self._prepare(context)
            _ACTIVE_JIGGLE_BAKE = self
            wm = getattr(context, 'window_manager', None)
            window = getattr(context, 'window', None)
            if wm is not None and window is not None:
                self._timer = wm.event_timer_add(0.01, window=window)
                wm.modal_handler_add(self)
                return {'RUNNING_MODAL'}
            while not self._process_one_step(context):
                pass
            return self._commit(context)
        except Exception:
            self._rollback(context, reason='exception')
            self.report({'ERROR'}, _jiggle_ui_text('Jiggle bake failed and all transactional state was restored.', 'Jiggle ベイクに失敗したため、トランザクション状態をすべて復元しました。', context))
            return {'CANCELLED'}

    def modal(self, context, event):
        if getattr(event, 'type', '') in {'ESC', 'RIGHTMOUSE'}:
            self._rollback(context, reason='cancel')
            self.report({'INFO'}, _jiggle_ui_text('Jiggle bake cancelled. Original state was restored.', 'Jiggle ベイクをキャンセルし、元の状態を復元しました。', context))
            return {'CANCELLED'}
        if getattr(event, 'type', '') != 'TIMER':
            return {'RUNNING_MODAL'}
        try:
            if self._process_one_step(context):
                return self._commit(context)
        except Exception:
            self._rollback(context, reason='exception')
            self.report({'ERROR'}, _jiggle_ui_text('Jiggle bake failed and all transactional state was restored.', 'Jiggle ベイクに失敗したため、トランザクション状態をすべて復元しました。', context))
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._rollback(context, reason='cancel')

    def _remember_owned(self, data, kind):
        if data is None:
            raise RuntimeError(f'Cannot own missing Jiggle {kind} resource')
        marker_written = _mark_jiggle_owned(data, self._transaction_uuid, self._generation)
        self._owned_resources[id(data)] = (
            data,
            lifecycle.OWNER_ID,
            self._transaction_uuid,
            self._generation,
            str(kind),
            bool(marker_written),
        )
        return data

    def _owns(self, data):
        record = self._owned_resources.get(id(data))
        if record is None:
            return False
        identity, owner, transaction_uuid, generation, _kind, marker_written = record
        if identity is not data:
            return False
        if owner != lifecycle.OWNER_ID or transaction_uuid != self._transaction_uuid or generation != self._generation:
            return False
        if marker_written and not _is_jiggle_owned(data, transaction_uuid, generation):
            return False
        return True

    def _forget_owned(self, data, *, clear_marker):
        if not self._owns(data):
            return
        if clear_marker:
            _clear_jiggle_owner_marker(data, self._transaction_uuid, self._generation)
        self._owned_resources.pop(id(data), None)

    def _prepare(self, context):
        scene = context.scene
        obj = context.object
        scene_settings = scene.jiggle
        self._scene = scene
        self._object = obj
        self._debug = bool(getattr(scene_settings, 'bake_debug', False))
        _jiggle_globals.suspend_runtime_evaluation = True
        if _restore_rest_poses(scene):
            context.view_layer.update()
        _jiggle_globals.suspend_runtime_evaluation = False
        self._original = self._capture_state(context)
        self._selected_bones = tuple(
            bone for bone in tuple(getattr(obj.pose, 'bones', ()) or ())
            if bool(getattr(getattr(bone, 'jiggle', None), 'enable', False))
        )
        if not self._selected_bones:
            raise RuntimeError('No enabled Jiggle bones')
        self._frame_start = int(scene.frame_preview_start if scene.use_preview_range else scene.frame_start)
        self._frame_end = int(scene.frame_preview_end if scene.use_preview_range else scene.frame_end)
        if self._frame_end < self._frame_start:
            self._frame_end = self._frame_start
        self._frame_count = max(1, self._frame_end - self._frame_start + 1)
        self._frame_index = 0
        self._preroll_total = max(0, int(getattr(scene_settings, 'preroll', 0) or 0))
        self._preroll_index = 0
        self._phase = 'PREROLL' if self._preroll_total > 0 else 'BAKE'
        self._samples = []
        if self._debug:
            _bake_debugger.start_logging()
            _bake_debugger.log(f"Starting transactional bake for object: {obj.name}")
            _bake_debugger.log(f"Frame count: {self._frame_count}")
        _jiggle_globals.jiggle_baking = True
        _jiggle_globals.suspend_runtime_evaluation = True
        self._prepare_working_action(obj, scene_settings)
        self._apply_temporary_optimization(scene)
        for collection in tuple(getattr(obj.data, 'collections', ()) or ()):
            collection.is_solo = False
            collection.is_visible = True
        for bone in tuple(getattr(obj.pose, 'bones', ()) or ()):
            _set_pose_bone_selected(bone, bone in self._selected_bones)
        try:
            obj.data.bones.active = self._selected_bones[0].bone
        except Exception:
            pass
        scene.frame_set(self._frame_start)
        jiggle_reset(context)

    def _capture_state(self, context):
        scene = context.scene
        obj = context.object
        view_layer = context.view_layer
        active = getattr(getattr(view_layer, 'objects', None), 'active', None)
        selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
        object_states = []
        modifier_states = []
        for item in tuple(getattr(scene, 'objects', ()) or ()):
            try:
                hidden = bool(item.hide_get())
            except Exception:
                hidden = False
            object_states.append((item, bool(getattr(item, 'hide_viewport', False)), bool(getattr(item, 'hide_render', False)), hidden, bool(item.select_get())))
            for modifier in tuple(getattr(item, 'modifiers', ()) or ()):
                modifier_states.append((modifier, bool(getattr(modifier, 'show_viewport', True))))
        collection_states = tuple(
            (collection, bool(collection.is_visible), bool(collection.is_solo))
            for collection in tuple(getattr(obj.data, 'collections', ()) or ())
        )
        bone_states = []
        for bone in tuple(getattr(obj.pose, 'bones', ()) or ()):
            internal = None
            settings = getattr(bone, 'jiggle', None)
            if settings is not None:
                try:
                    internal = tuple(getattr(settings, name).copy() for name in (
                        'position0', 'position_last0', 'rest_pose_position0',
                        'position1', 'position_last1', 'rest_pose_position1',
                        'position2', 'position_last2', 'rest_pose_position2',
                    ))
                except Exception:
                    internal = None
            try:
                basis = bone.matrix_basis.copy()
            except Exception:
                basis = None
            bone_states.append((bone, basis, _pose_bone_selected(bone), internal))
        active_bone = getattr(getattr(obj.data, 'bones', None), 'active', None)
        animation_data = getattr(obj, 'animation_data', None)
        original_action = getattr(animation_data, 'action', None) if animation_data is not None else None
        return {
            'frame': int(scene.frame_current),
            'mode': str(getattr(context, 'mode', 'POSE')),
            'active_object': active,
            'selected_objects': selected_objects,
            'object_states': tuple(object_states),
            'modifier_states': tuple(modifier_states),
            'collection_states': collection_states,
            'bone_states': tuple(bone_states),
            'active_bone': active_bone,
            'animation_data_existed': animation_data is not None,
            'original_action': original_action,
            'keyframe_selection': _keyframe_selection_snapshot(original_action),
            'nla_tracks': tuple(getattr(animation_data, 'nla_tracks', ()) or ()) if animation_data is not None else (),
            'freeze': bool(getattr(obj.jiggle, 'freeze', False)),
            'lastframe': int(getattr(scene.jiggle, 'lastframe', scene.frame_current)),
            'global_jiggle_baking': bool(_jiggle_globals.jiggle_baking),
            'global_is_preroll': bool(_jiggle_globals.is_preroll),
            'global_suspend_runtime_evaluation': bool(_jiggle_globals.suspend_runtime_evaluation),
        }

    def _prepare_working_action(self, obj, scene_settings):
        animation_data = obj.animation_data_create()
        original_action = self._original['original_action']
        overwrite = bool(getattr(scene_settings, 'bake_overwrite', False))
        # The working action keeps the existing keys: the jiggle reacts to that motion.
        if original_action is not None:
            action = original_action.copy()
            action.name = original_action.name if overwrite else 'JiggleAction'
        else:
            action = bpy.data.actions.new('JiggleAction')
        self._remember_owned(action, 'ACTION')
        self._working_action = action
        animation_data.action = action

    def _collision_objects(self, scene):
        result = set()
        for armature in tuple(getattr(scene, 'objects', ()) or ()):
            if getattr(armature, 'type', None) != 'ARMATURE':
                continue
            for bone in tuple(getattr(getattr(armature, 'pose', None), 'bones', ()) or ()):
                settings = getattr(bone, 'jiggle', None)
                if not bool(getattr(settings, 'enable', False)):
                    continue
                if getattr(settings, 'collider_type', '') == 'Object' and getattr(settings, 'collider', None) is not None:
                    result.add(settings.collider)
                elif getattr(settings, 'collider_type', '') == 'Collection' and getattr(settings, 'collider_collection', None) is not None:
                    result.update(tuple(settings.collider_collection.objects))
        return result

    def _apply_temporary_optimization(self, scene):
        collision_objects = self._collision_objects(scene)
        expensive = {'NODES', 'SUBSURF', 'MULTIRES', 'FLUID', 'CLOTH', 'SOFT_BODY', 'OCEAN', 'DYNAMIC_PAINT'}
        for item in tuple(getattr(scene, 'objects', ()) or ()):
            if item in collision_objects:
                for modifier in tuple(getattr(item, 'modifiers', ()) or ()):
                    if getattr(modifier, 'type', None) in expensive:
                        modifier.show_viewport = False
                continue
            if getattr(item, 'type', None) in {'ARMATURE', 'EMPTY'}:
                continue
            for modifier in tuple(getattr(item, 'modifiers', ()) or ()):
                modifier.show_viewport = False
            item.hide_viewport = True

    def _process_one_step(self, context):
        if self._phase == 'PREROLL':
            duration = max(1, self._frame_count)
            if bool(getattr(self._scene.jiggle, 'loop', False)):
                frame = self._frame_end - ((self._preroll_total - self._preroll_index - 1) % duration)
            else:
                frame = self._frame_start
            self._scene.frame_set(int(frame))
            self._simulate_one(context)
            self._preroll_index += 1
            if self._preroll_index >= self._preroll_total:
                self._phase = 'BAKE'
            return False
        if self._phase == 'KEYS':
            # Keys are written after the whole simulation: a key written earlier
            # would be evaluated by the next frame_set and read back as the animated
            # pose of a jiggle bone that has keys of its own.
            if self._samples:
                self._insert_keyframes(*self._samples.pop(0))
            return not self._samples
        frame = self._frame_start + self._frame_index
        if self._debug:
            _bake_debugger.log_frame_start(frame)
        self._scene.frame_set(int(frame))
        self._simulate_one(context)
        self._samples.append((frame, self._sample_pose()))
        if self._debug:
            _bake_debugger.log_frame_end(frame)
        self._frame_index += 1
        if self._frame_index >= self._frame_count:
            self._phase = 'KEYS'
        return False

    def _simulate_one(self, context):
        depsgraph = context.evaluated_depsgraph_get()
        # jiggle_post is suspended during a bake, so nothing else drops the per-frame
        # cache. A cached list keeps the pose read on the first frame, and the parent's
        # motion would never reach the simulation.
        _jiggle_globals.clear_per_frame_caches()
        virtual_particles = get_virtual_particles(self._scene)
        jiggle_simulate(self._scene, depsgraph, virtual_particles, 1)
        _jiggle_globals.refresh_overlay_snapshot(self._scene, virtual_particles)

    def _sample_pose(self):
        return tuple(
            (bone, bone.location.copy(), bone.rotation_quaternion.copy(), tuple(bone.rotation_axis_angle), bone.rotation_euler.copy(), bone.scale.copy())
            for bone in self._selected_bones
        )

    def _insert_keyframes(self, frame, sample):
        for bone, location, quaternion, axis_angle, euler, scale in sample:
            bone.location = location
            bone.rotation_quaternion = quaternion
            bone.rotation_axis_angle = axis_angle
            bone.rotation_euler = euler
            bone.scale = scale
            bone.keyframe_insert(data_path='location', frame=frame, group=bone.name)
            rotation_mode = str(getattr(bone, 'rotation_mode', 'QUATERNION'))
            if rotation_mode == 'QUATERNION':
                bone.keyframe_insert(data_path='rotation_quaternion', frame=frame, group=bone.name)
            elif rotation_mode == 'AXIS_ANGLE':
                bone.keyframe_insert(data_path='rotation_axis_angle', frame=frame, group=bone.name)
            else:
                bone.keyframe_insert(data_path='rotation_euler', frame=frame, group=bone.name)
            bone.keyframe_insert(data_path='scale', frame=frame, group=bone.name)

    def _commit(self, context):
        if self._finished:
            return {'FINISHED'}
        try:
            settings = self._scene.jiggle
            if not bool(getattr(settings, 'bake_overwrite', False)) and bool(getattr(settings, 'bake_nla', False)):
                original_action = self._original['original_action']
                animation_data = self._object.animation_data
                if original_action is not None and animation_data is not None:
                    track = animation_data.nla_tracks.new()
                    self._created_track = track
                    self._remember_owned(track, 'NLA_TRACK')
                    track.name = original_action.name
                    start = int(original_action.frame_range[0]) if getattr(original_action, 'frame_range', None) else self._frame_start
                    strip = track.strips.new(original_action.name, start, original_action)
                    self._created_strip = strip
                    self._remember_owned(strip, 'NLA_STRIP')
            self._object.jiggle.freeze = True
            self._restore_transient(context, restore_action=False, restore_freeze=False)
            if self._debug:
                _bake_debugger.log('=== BAKE COMPLETE ===')
                _bake_debugger.save_to_text_block()
            else:
                clear_debug_runtime_data()
            for data in (self._working_action, self._created_strip, self._created_track):
                if data is not None:
                    self._forget_owned(data, clear_marker=True)
            self._finished = True
            if bool(getattr(settings, 'bake_overwrite', False)):
                self._replace_original_action()
            return {'FINISHED'}
        except Exception:
            self._rollback(context, reason='commit_exception')
            self.report({'ERROR'}, _jiggle_ui_text('Jiggle bake commit failed; original state was restored.', 'Jiggle ベイクの確定に失敗したため、元の状態を復元しました。', context))
            return {'CANCELLED'}

    def _replace_original_action(self):
        original_action = self._original.get('original_action')
        working_action = self._working_action
        if original_action is None or working_action is None or original_action is working_action:
            return
        name = original_action.name
        working_action.use_fake_user = original_action.use_fake_user
        original_action.user_remap(working_action)
        bpy.data.actions.remove(original_action)
        working_action.name = name

    def _remove_created_nla(self):
        obj = getattr(self, '_object', None)
        animation_data = getattr(obj, 'animation_data', None) if obj is not None else None
        track = getattr(self, '_created_track', None)
        strip = getattr(self, '_created_strip', None)
        if animation_data is not None and track is not None and self._owns(track):
            try:
                if track in tuple(animation_data.nla_tracks):
                    animation_data.nla_tracks.remove(track)
            except Exception:
                pass
        if strip is not None:
            self._forget_owned(strip, clear_marker=False)
        if track is not None:
            self._forget_owned(track, clear_marker=False)
        self._created_track = None
        self._created_strip = None

    def _remove_working_action(self):
        action = getattr(self, '_working_action', None)
        if action is None or not self._owns(action):
            return
        obj = getattr(self, '_object', None)
        try:
            if obj is not None and getattr(obj, 'animation_data', None) is not None and obj.animation_data.action is action:
                obj.animation_data.action = None
        except Exception:
            pass
        try:
            if int(getattr(action, 'users', 0)) == 0:
                bpy.data.actions.remove(action)
        except Exception:
            pass
        self._forget_owned(action, clear_marker=False)
        self._working_action = None

    def _rollback(self, context, *, reason):
        del reason
        if bool(getattr(self, '_rolled_back', False)) or bool(getattr(self, '_finished', False)):
            return
        original = dict(getattr(self, '_original', {}) or {})
        obj = getattr(self, '_object', None)
        try:
            self._remove_created_nla()
            animation_data = getattr(obj, 'animation_data', None) if obj is not None else None
            if animation_data is not None:
                animation_data.action = original.get('original_action')
            self._remove_working_action()
            if obj is not None and original and not bool(original.get('animation_data_existed', True)):
                animation_data = getattr(obj, 'animation_data', None)
                if animation_data is not None and animation_data.action is None and len(tuple(animation_data.nla_tracks)) == 0:
                    try:
                        obj.animation_data_clear()
                    except Exception:
                        pass
            self._restore_transient(context, restore_action=True, restore_freeze=True)
        finally:
            if bool(getattr(self, '_debug', False)):
                _bake_debugger.log('=== BAKE CANCELLED / ROLLED BACK ===')
                _bake_debugger.save_to_text_block()
            else:
                clear_debug_runtime_data()
            self._owned_resources.clear()
            self._rolled_back = True

    def _restore_transient(self, context, *, restore_action, restore_freeze):
        global _ACTIVE_JIGGLE_BAKE
        self._remove_timer(context)
        original = dict(getattr(self, '_original', {}) or {})
        obj = getattr(self, '_object', None)
        scene = getattr(self, '_scene', None)
        ctx = context or getattr(bpy, 'context', None)
        _jiggle_globals.suspend_runtime_evaluation = True
        try:
            for modifier, show_viewport in original.get('modifier_states', ()):
                try:
                    modifier.show_viewport = show_viewport
                except Exception:
                    pass
            for item, hide_viewport, hide_render, hidden, selected in original.get('object_states', ()):
                try:
                    item.hide_viewport = hide_viewport
                    item.hide_render = hide_render
                    item.hide_set(hidden)
                    item.select_set(selected)
                except Exception:
                    pass
            for collection, visible, solo in original.get('collection_states', ()):
                try:
                    collection.is_visible = visible
                    collection.is_solo = solo
                except Exception:
                    pass
            for bone, basis, selected, internal in original.get('bone_states', ()):
                try:
                    if basis is not None:
                        bone.matrix_basis = basis
                    _set_pose_bone_selected(bone, selected)
                    if internal is not None:
                        settings = bone.jiggle
                        for name, value in zip((
                            'position0', 'position_last0', 'rest_pose_position0',
                            'position1', 'position_last1', 'rest_pose_position1',
                            'position2', 'position_last2', 'rest_pose_position2',
                        ), internal):
                            setattr(settings, name, value)
                except Exception:
                    pass
            if obj is not None:
                try:
                    obj.data.bones.active = original.get('active_bone')
                except Exception:
                    pass
            if ctx is not None:
                try:
                    ctx.view_layer.objects.active = original.get('active_object')
                except Exception:
                    pass
            if scene is not None:
                try:
                    scene.jiggle.lastframe = original.get('lastframe', scene.frame_current)
                    scene.frame_set(original.get('frame', scene.frame_current))
                except Exception:
                    pass
            if restore_action and obj is not None:
                try:
                    if obj.animation_data is not None:
                        obj.animation_data.action = original.get('original_action')
                except Exception:
                    pass
            if restore_freeze and obj is not None:
                try:
                    obj.jiggle.freeze = original.get('freeze', False)
                except Exception:
                    pass
            _restore_keyframe_selection(original.get('keyframe_selection', ()))
            self._restore_mode(ctx, original.get('mode', 'POSE'))
            _jiggle_globals.clear_per_object_caches()
        finally:
            _jiggle_globals.jiggle_baking = bool(original.get('global_jiggle_baking', False))
            _jiggle_globals.is_preroll = bool(original.get('global_is_preroll', False))
            _jiggle_globals.suspend_runtime_evaluation = bool(original.get('global_suspend_runtime_evaluation', False))
            if _ACTIVE_JIGGLE_BAKE is self:
                _ACTIVE_JIGGLE_BAKE = None

    def _restore_mode(self, context, mode):
        if context is None:
            return
        desired = {
            'EDIT_MESH': 'EDIT',
            'EDIT_ARMATURE': 'EDIT',
            'PAINT_WEIGHT': 'WEIGHT_PAINT',
            'PAINT_VERTEX': 'VERTEX_PAINT',
            'PAINT_TEXTURE': 'TEXTURE_PAINT',
            'SCULPT': 'SCULPT',
            'POSE': 'POSE',
        }.get(str(mode or '').upper(), 'OBJECT')
        current = str(getattr(context, 'mode', '') or '').upper()
        if current == str(mode or '').upper() or (desired == 'OBJECT' and current == 'OBJECT'):
            return
        try:
            bpy.ops.object.mode_set(mode=desired)
        except Exception:
            pass

    def _remove_timer(self, context):
        timer = getattr(self, '_timer', None)
        self._timer = None
        if timer is None:
            return
        ctx = context or getattr(bpy, 'context', None)
        try:
            ctx.window_manager.event_timer_remove(timer)
        except Exception:
            pass


def cancel_active_bake_transaction():
    operator = _ACTIVE_JIGGLE_BAKE
    if operator is None:
        return False
    try:
        operator._rollback(getattr(bpy, 'context', None), reason='lifecycle')
    except Exception:
        pass
    return True


def _jiggle_panel_context_available(context=None) -> bool:
    try:
        area = getattr(context, 'area', None)
        area_type = str(getattr(area, 'type', '') or '').upper() if area is not None else ''
        return not area_type or area_type == 'VIEW_3D'
    except Exception:
        return False


class JigglePanel:
    bl_category = 'Smart Cloth'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    
    @classmethod
    def poll(cls,context):
        return _jiggle_panel_context_available(context)

def draw_jiggle_overlay_menu(self, context):
    # Overlay controls are intentionally centralized in the Smart Cloth N-panel
    # top-level Always-on Toggles group. Keep this legacy append callback inert
    # so old Overlay-panel UI paths cannot reintroduce duplicate toggles.
    try:
        self.layout.label(
            text=_jiggle_ui_text(
                "Use Always-on Toggles in the Smart Cloth N-panel.",
                "Smart Cloth Nパネルの「常時機能切り替え」を使用してください。",
                context,
            ),
        )
    except Exception:
        pass
    return

class JIGGLE_PT_Settings(JigglePanel, Panel):
    bl_label = "Jiggle Physics"
    bl_idname = "JIGGLE_PT_Settings_scs_v179"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self,context):
        # Keep the header simple and side-effect-free. Blender 5.x calls panel
        # header drawing from the same low-level panel_draw path as body drawing,
        # so avoid PresetPanel helper code here. Presets remain available from
        # the Jiggle Bone Presets menu/operator classes.
        try:
            self.layout.label(text="", icon='PHYSICS')
        except Exception:
            pass
        
    def draw(self,context):
        row = self.layout.row()
        enabled = bool(context.scene.jiggle.enable)
        row.label(
            text=_jiggle_ui_text('Jiggle scene is enabled.', 'Jiggle シーンは有効です。', context) if enabled else _jiggle_ui_text('Jiggle scene is disabled.', 'Jiggle シーンは無効です。', context),
            icon='SCENE_DATA' if enabled else 'HIDE_ON',
        )

        if not context.scene.jiggle.enable:
            row = self.layout.row()
            row.label(text=_jiggle_ui_text('Enable in Always-on Toggles', '「常時機能切り替え」で有効化', context))
            return
        obj = getattr(context, 'object', None)
        if obj is None or getattr(obj, 'type', None) != 'ARMATURE':
            row.label(text=_jiggle_ui_text(' Select armature.', ' アーマチュアを選択してください。', context))
            return
        obj_jiggle = getattr(obj, 'jiggle', None)
        if obj_jiggle is None:
            row.label(text=_jiggle_ui_text('Jiggle settings unavailable', 'Jiggle 設定を取得できません', context))
            return
        if obj_jiggle.freeze:
            row.label(text=_jiggle_ui_text('Jiggle Frozen after Bake.', 'ベイク後に Jiggle が固定されています。', context), icon='FREEZE')
            row = self.layout.row()
            row.label(text=_jiggle_ui_text('Release in Always-on Toggles', '「常時機能切り替え」で解除', context))
            return
        if obj_jiggle.mute:
            row.label(text=_jiggle_ui_text('Armature muted.', 'アーマチュアでミュートされています。', context), icon='HIDE_ON')
            row = self.layout.row()
            row.label(text=_jiggle_ui_text('Unmute in Always-on Toggles', '「常時機能切り替え」でミュート解除', context))
            return
        if not context.active_pose_bone:
            row.label(text=_jiggle_ui_text(' Select pose bone.', ' ポーズボーンを選択してください。', context))
            return


class JIGGLE_OT_bone_connected_disable(Operator):
    bl_idname = "armature.jiggle_bone_connected_disable"
    bl_label = "Disconnect Selected Bones"
    bl_description = "Connected bones ignore length elasticity, preventing them from stretching. Click this button to automatically fix"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls,context):
        return context.object and context.active_pose_bone

    def execute(self, context):
        obj = context.object
        previous_mode = obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        for pose_bone in obj.pose.bones:
            if bpy.app.version < (5, 0, 0):
                if not pose_bone.bone.select:
                    continue
            else:
                if not pose_bone.select:
                    continue
            edit_bone = obj.data.edit_bones.get(pose_bone.name)
            if edit_bone is None:
                continue
            if edit_bone.parent:
                edit_bone.use_connect = False

        bpy.ops.object.mode_set(mode=previous_mode)
        return {'FINISHED'}

class JIGGLE_OT_bone_constraints_disable(Operator):
    bl_idname = "armature.jiggle_bone_constraints_disable"
    bl_label = "Disable Constraints"
    bl_description = "Constraints are applied after jiggle, which can cause strange behavior. Click this button to automatically disable constraints on selected bones"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls,context):
        return context.object and context.active_pose_bone

    def execute(self, context):
        obj = context.object
        for pose_bone in obj.pose.bones:
            if bpy.app.version < (5, 0, 0):
                if not pose_bone.bone.select:
                    continue
            else:
                if not pose_bone.select:
                    continue
            for constraint in pose_bone.constraints:
                constraint.enabled = False
        return {'FINISHED'}

class JIGGLE_PT_NoKeyframesWarning(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_NoKeyframesWarning_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and not context.object.jiggle.mute and context.active_pose_bone and context.active_pose_bone.jiggle.enable and not is_bone_animated(context.active_pose_bone.id_data, context.active_pose_bone.name)
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text=_jiggle_ui_text('No Keyframes Detected', 'キーフレームが見つかりません', context), icon='ERROR')
        row.separator(factor=0.35)
        _jiggle_help_button(row, 'jiggle_warning_no_keyframes')
    
    def draw(self,context):
        pass

class JIGGLE_PT_BoneConstraintsWarning(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_BoneConstraintsWarning_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and not context.object.jiggle.mute and context.active_pose_bone and context.active_pose_bone.jiggle.enable and any(c.enabled for c in context.active_pose_bone.constraints)
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text=_jiggle_ui_text('Bone Constraints Detected', 'ボーン制約を検出', context), icon='ERROR')
        row.separator(factor=0.35)
        _jiggle_help_button(row, 'jiggle_warning_bone_constraints')
    
    def draw(self,context):
        self.layout.operator(JIGGLE_OT_bone_constraints_disable.bl_idname, text=_jiggle_ui_text('Disable Constraints on Selected Bones', '選択ボーンの制約を無効化', context))

class JIGGLE_PT_ConnectedBonesWarning(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_ConnectedBonesWarning_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and not context.object.jiggle.mute and context.active_pose_bone and context.active_pose_bone.jiggle.enable and any(bone.bone.use_connect for bone in context.selected_pose_bones)
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text=_jiggle_ui_text('Connected Bones Detected', '接続ボーンを検出', context), icon='ERROR')
        row.separator(factor=0.35)
        _jiggle_help_button(row, 'jiggle_warning_connected_bones')
    
    def draw(self,context):
        self.layout.operator(JIGGLE_OT_bone_connected_disable.bl_idname, text=_jiggle_ui_text('Disconnect Selected Bones', '選択ボーンの接続を解除', context))

class JIGGLE_PT_FrameSkippingEnabledWarning(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_FrameSkippingEnabledWarning_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.scene.sync_mode == 'FRAME_DROP'
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text=_jiggle_ui_text('Frame Dropping Detected', 'フレームドロップを検出', context), icon='ERROR')
        row.separator(factor=0.35)
        _jiggle_help_button(row, 'jiggle_warning_frame_skipping_enabled')
    
    def draw(self,context):
        pass

class JIGGLE_PT_MeshCollisionWarning(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_MeshCollisionWarning_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls,context):
        if not context.scene.jiggle.enable or not context.object or context.object.jiggle.mute or not context.active_pose_bone or not context.active_pose_bone.jiggle.enable:
            return False
        if context.active_pose_bone.jiggle.collider_type == 'Object':
            collider = context.active_pose_bone.jiggle.collider
            if collider and collider.type == 'MESH':
                return True
        elif context.active_pose_bone.jiggle.collider_type == 'Collection':
            collider_collection = context.active_pose_bone.jiggle.collider_collection
            if collider_collection:
                for collider in collider_collection.objects:
                    if collider.type == 'MESH':
                        return True
        return False
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text=_jiggle_ui_text('Mesh Collision Detected', 'メッシュ衝突を検出', context), icon='ERROR')
        row.separator(factor=0.35)
        _jiggle_help_button(row, 'jiggle_warning_mesh_collision')
    
    def draw(self,context):
        pass

class JIGGLE_PT_Bone(JigglePanel,Panel):
    bl_label = ''
    bl_idname = 'JIGGLE_PT_Bone_scs_v179'
    bl_parent_id = ""
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and not context.object.jiggle.mute and context.active_pose_bone
    
    def draw_header(self,context):
        row=self.layout.row(align=True)
        row.label(text='', icon='BONE_DATA')
    
    def draw(self,context):
        b = context.active_pose_bone
        if not b.jiggle.enable:
            self.layout.label(text=_jiggle_ui_text('Enable in Always-on Toggles', '「常時機能切り替え」で有効化', context))
            return
    
        layout = self.layout
        preset_box = layout.box()
        preset_box.label(text=_jiggle_ui_text('Jiggle Bone Presets', 'Jiggle ボーンプリセット', context), icon='PRESET')
        preset_row = preset_box.row(align=True)
        preset_row.menu(JIGGLE_MT_JiggleBonePresets.__name__, text=_jiggle_ui_text('Apply Preset', 'プリセットを適用', context), icon='PRESET')
        preset_row.operator(JIGGLE_OT_AddJiggleBonePreset.bl_idname, text=_jiggle_ui_text('Save Preset', 'プリセットを保存', context), icon='ADD')
        remove_op = preset_row.operator(JIGGLE_OT_AddJiggleBonePreset.bl_idname, text='', icon='REMOVE')
        remove_op.remove_active = True
        layout.use_property_split = True
        layout.use_property_decorate = False
        
        def drawprops(layout,b,props):
            for p in props:
                layout.prop(b, p)
        
        col = layout.column(align=True)
        if b.jiggle.mode == 'root' or b.jiggle.mode == 'solo':
            drawprops(col,b,['jiggle_root_elasticity', 'jiggle_angle_elasticity', 'jiggle_length_elasticity', 'jiggle_elasticity_soften', 'jiggle_gravity', 'jiggle_blend', 'jiggle_air_drag', 'jiggle_friction'])
        else:
            drawprops(col,b,['jiggle_angle_elasticity', 'jiggle_length_elasticity', 'jiggle_elasticity_soften', 'jiggle_gravity', 'jiggle_blend', 'jiggle_air_drag', 'jiggle_friction'])
        col.separator()
        collision = False
        col.prop(b.jiggle, 'collider_type', text=_jiggle_ui_text('Collisions', '衝突', context))
        if b.jiggle.collider_type == 'Object':
            row = col.row(align=True)
            row.prop_search(b.jiggle, 'collider', context.scene, 'objects',text=' ')
            if b.jiggle.collider:
                if b.jiggle.collider:
                    collision = True
                else:
                    row.label(text='',icon='UNLINKED')
        else:
            row = col.row(align=True)
            row.prop_search(b.jiggle, 'collider_collection', bpy.data, 'collections', text=' ')
            if b.jiggle.collider_collection:
                if b.jiggle.collider_collection in context.scene.collection.children_recursive:
                    collision = True
                else:
                    row.label(text='',icon='UNLINKED')
            
        col = layout.column(align=True)
        drawprops(col,b,['jiggle_collision_radius'])
        layout.operator(ANIM_OT_JiggleClearKeyframes.bl_idname)

class JIGGLE_PT_Utilities(JigglePanel,Panel):
    bl_label = 'Global Jiggle Utilities'
    bl_idname = 'JIGGLE_PT_Utilities_scs_v179'
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable

    def draw(self,context):
        layout = self.layout
        layout.use_property_split=True
        layout.use_property_decorate=False

        obj = getattr(context, 'object', None)
        mode = getattr(context, 'mode', '')
        can_edit_pose_tools = bool(obj and getattr(obj, 'jiggle', None) and obj.jiggle.enable and mode == 'POSE')

        col = layout.column(align=True)
        if can_edit_pose_tools:
            col.operator(ARMATURE_OT_JiggleCopy.bl_idname)
            col.operator(ARMATURE_OT_JiggleSelect.bl_idname)
        col.operator(SCENE_OT_JiggleReset.bl_idname)

        if context.scene.jiggle.debug:
            layout.operator(SCENE_OT_JiggleProfile.bl_idname, text=_jiggle_ui_text('Print Profiling Information', '計測結果を出力', context), icon='TEXT')

        layout.prop(context.scene.jiggle, 'loop')

class JIGGLE_PT_Wind(JigglePanel,Panel):
    bl_label = 'Wind Force'
    bl_idname = 'JIGGLE_PT_Wind_scs_v179'
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable

    def draw_header(self,context):
        self.layout.label(text='', icon='FORCE_WIND')

    def draw(self,context):
        layout = self.layout
        layout.use_property_split=True
        layout.use_property_decorate=False

        jiggle = context.scene.jiggle
        layout.enabled = jiggle.enable_wind

        col = layout.column(align=True)
        col.prop(jiggle, 'wind_direction')
        col.prop(jiggle, 'wind_speed')
        col.separator()
        col.prop(jiggle, 'wind_turbulence_scale')
        col.prop(jiggle, 'wind_evolution_speed')
        
class JIGGLE_PT_Bake(JigglePanel,Panel):
    bl_label = 'Bake Jiggle'
    bl_idname = 'JIGGLE_PT_Bake_scs_v179'
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}
    
    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and context.object.jiggle.enable and context.mode == 'POSE'
    
    def draw(self,context):
        layout = self.layout
        layout.use_property_split=True
        layout.use_property_decorate=False
        jiggle = context.scene.jiggle
        layout.prop(jiggle, 'preroll')
        layout.prop(jiggle, 'bake_overwrite')
        row = layout.row()
        row.enabled = not jiggle.bake_overwrite
        row.prop(jiggle, 'bake_nla')
        layout.prop(jiggle, 'bake_debug')
        layout.operator('armature.jiggle_bake')

_JIGGLE_BUNDLED_PRESET_NAMES = {
    'breast': ('Breast', '胸'),
    'hair': ('Hair', '髪'),
    'rope': ('Rope', 'ロープ'),
    'stiff': ('Stiff', '硬め'),
    'tail': ('Tail', '尻尾'),
}


def _jiggle_preset_display_name(filepath):
    names = _JIGGLE_BUNDLED_PRESET_NAMES.get(os.path.splitext(os.path.basename(filepath))[0])
    if names:
        return _jiggle_ui_text(*names, bpy.context)
    # Names the user gave stay exactly as they are.
    return bpy.path.display_name(filepath, title_case=False)


class JIGGLE_MT_JiggleBonePresets(Menu):
    bl_label = 'Jiggle Bone Presets'
    preset_subdir = _jiggle_preset_subdir(create=False)
    preset_operator = 'script.execute_preset'

    def draw(self, _context):
        # Menu.draw_preset routes preset_subdir through bpy.utils.preset_paths,
        # which raises "invalid subdir given ..." for any absolute path (measured
        # on 5.1.2: os.path.join discards the base, the startswith check fails).
        # This package stores presets on an absolute path in the extension's
        # user folder, so hand path_menu the directory directly.
        subdir = str(getattr(self, 'preset_subdir', '') or '')
        searchpaths = [subdir] if subdir and os.path.isdir(subdir) else []
        # Explicit class-bound call: identical to self.path_menu(...) because no
        # subclass overrides it, and it keeps working when self is duck-typed.
        Menu.path_menu(
            self,
            searchpaths,
            self.preset_operator,
            filter_ext=lambda ext: ext.lower() in {'.py', '.xml'},
            display_name=_jiggle_preset_display_name,
            translate=False,
        )

class JIGGLE_OT_AddJiggleBonePreset(AddPresetBase, Operator):
    """Saves or removes the current jiggle bone settings on the active bone as a preset."""
    bl_idname = 'armature.add_jigglebone_preset'
    bl_label = 'Add/Remove Jiggle Bone preset'
    preset_menu = 'JIGGLE_MT_JiggleBonePresets'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls,context):
        return context.scene.jiggle.enable and context.object and context.object.jiggle.enable and context.mode == 'POSE' and context.active_pose_bone and context.active_pose_bone.jiggle.enable

    # Common variable used for all preset values
    preset_defines = [
        'b = bpy.context.active_pose_bone',
    ]

    preset_values = [
        'b.jiggle_root_elasticity',
        'b.jiggle_angle_elasticity',
        'b.jiggle_length_elasticity',
        'b.jiggle_elasticity_soften',
        'b.jiggle_gravity',
        'b.jiggle_blend',
        'b.jiggle_air_drag',
        'b.jiggle_friction',
    ]

    def execute(self, context):
        # AddPresetBase only accepts folders under scripts/presets and raises for
        # an absolute one, so the extension's user folder is handled here directly.
        folder = _jiggle_preset_subdir(create=True)
        menu = JIGGLE_MT_JiggleBonePresets
        try:
            if self.remove_active or self.remove_name:
                name = menu.bl_label if self.remove_active else self.name
                stem = next((f[:-3] for f in sorted(os.listdir(folder)) if f.endswith('.py')
                             and name in (f[:-3], bpy.path.display_name(f, title_case=False))), None)
                if stem is None:
                    self.report({'WARNING'}, _jiggle_ui_text('Apply the preset to remove first.', '削除するプリセットを先に適用してください。', context))
                    return {'CANCELLED'}
                if stem in _JIGGLE_BUNDLED_PRESET_NAMES:
                    self.report({'WARNING'}, _jiggle_ui_text('Bundled presets cannot be removed.', '同梱のプリセットは削除できません。', context))
                    return {'CANCELLED'}
                os.remove(os.path.join(folder, stem + '.py'))
                menu.bl_label = 'Jiggle Bone Presets'
                return {'FINISHED'}
            name = self.name.strip()
            if not name:
                self.report({'WARNING'}, _jiggle_ui_text('Enter a preset name.', 'プリセット名を入力してください。', context))
                return {'CANCELLED'}
            filename = self.as_filename(name)
            filepath = os.path.join(folder, filename + '.py')
            if os.path.exists(filepath):
                self.report({'WARNING'}, _jiggle_ui_text('A preset with this name already exists.', '同じ名前のプリセットがあります。', context))
                return {'CANCELLED'}
            bone = context.active_pose_bone
            lines = ['import bpy', self.preset_defines[0], '']
            lines += ['%s = %r' % (path, getattr(bone, path.split('.', 1)[1])) for path in self.preset_values]
            with open(filepath, 'w', encoding='utf-8') as handle:
                handle.write('\n'.join(lines) + '\n')
            menu.bl_label = bpy.path.display_name(filename, title_case=False)
            return {'FINISHED'}
        except OSError:
            self.report({'ERROR'}, _jiggle_ui_text('Could not access the preset folder.', 'プリセットのフォルダーを読み書きできませんでした。', context))
            return {'CANCELLED'}

    # Directory to store the presets.  The value is refreshed at register time
    # to the extension's absolute user folder so Blender's preset operator
    # never writes to the global user scripts preset directory.
    preset_subdir = _jiggle_preset_subdir(create=False)


def _refresh_jiggle_preset_paths() -> None:
    try:
        path = _jiggle_preset_subdir(create=True)
        JIGGLE_MT_JiggleBonePresets.preset_subdir = path
        JIGGLE_OT_AddJiggleBonePreset.preset_subdir = path
    except Exception:
        pass


class JiggleBone(PropertyGroup):
    position0: FloatVectorProperty(
        name=_jiggle_ui_text('Jiggle particle position 0', 'Jiggle 粒子位置0'),
        description=_jiggle_ui_text('Internal current simulated particle position for this Jiggle bone chain segment.', 'この Jiggle ボーンチェーン区間の現在の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    position_last0: FloatVectorProperty(
        name=_jiggle_ui_text('Previous Jiggle particle position 0', '前回 Jiggle 粒子位置0'),
        description=_jiggle_ui_text('Internal previous simulated particle position used to derive velocity.', '速度計算に使う前回の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    rest_pose_position0: FloatVectorProperty(
        name=_jiggle_ui_text('Rest pose particle position 0', 'レスト姿勢粒子位置0'),
        description=_jiggle_ui_text('Internal rest-pose reference particle position for the Jiggle solver.', 'Jiggle ソルバーが使う内部レスト姿勢基準粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )

    position1: FloatVectorProperty(
        name=_jiggle_ui_text('Jiggle particle position 1', 'Jiggle 粒子位置1'),
        description=_jiggle_ui_text('Internal current simulated particle position for this Jiggle bone chain segment.', 'この Jiggle ボーンチェーン区間の現在の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    position_last1: FloatVectorProperty(
        name=_jiggle_ui_text('Previous Jiggle particle position 1', '前回 Jiggle 粒子位置1'),
        description=_jiggle_ui_text('Internal previous simulated particle position used to derive velocity.', '速度計算に使う前回の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    rest_pose_position1: FloatVectorProperty(
        name=_jiggle_ui_text('Rest pose particle position 1', 'レスト姿勢粒子位置1'),
        description=_jiggle_ui_text('Internal rest-pose reference particle position for the Jiggle solver.', 'Jiggle ソルバーが使う内部レスト姿勢基準粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )

    position2: FloatVectorProperty(
        name=_jiggle_ui_text('Jiggle particle position 2', 'Jiggle 粒子位置2'),
        description=_jiggle_ui_text('Internal current simulated particle position for this Jiggle bone chain segment.', 'この Jiggle ボーンチェーン区間の現在の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    position_last2: FloatVectorProperty(
        name=_jiggle_ui_text('Previous Jiggle particle position 2', '前回 Jiggle 粒子位置2'),
        description=_jiggle_ui_text('Internal previous simulated particle position used to derive velocity.', '速度計算に使う前回の内部シミュレーション粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )
    rest_pose_position2: FloatVectorProperty(
        name=_jiggle_ui_text('Rest pose particle position 2', 'レスト姿勢粒子位置2'),
        description=_jiggle_ui_text('Internal rest-pose reference particle position for the Jiggle solver.', 'Jiggle ソルバーが使う内部レスト姿勢基準粒子位置です。'),
        subtype='TRANSLATION',
        override={'LIBRARY_OVERRIDABLE'},
    )

    enable: BoolProperty(
        name = 'Enable Bone Jiggle',
        description = "Enable jiggle on this bone", default = False,
        override={'LIBRARY_OVERRIDABLE'},
        options={'HIDDEN'},
        update=lambda s, c: update_nested_jiggle_prop(s, c, 'enable')
    )
    rest_basis: FloatVectorProperty(
        name='Rest Basis',
        size=(4, 4),
        subtype='MATRIX',
        options={'HIDDEN'},
    )
    rest_basis_valid: BoolProperty(
        name='Rest Basis Valid',
        default=False,
        options={'HIDDEN'},
    )
    mode: EnumProperty(
        name=_jiggle_ui_text('Jiggle Mode', 'Jiggle モード'),
        description=_jiggle_ui_text('Internal mode showing how this bone participates in the Jiggle chain.', 'このボーンが Jiggle チェーンにどのように参加するかを示す内部モードです。'),
        items=[('none','None','Not jiggled, and contains no jiggle bone children'),
               ('root','Root','A root jiggle bone'),
               ('solo','Solo','A bone without jiggled children or parents'),
               ('merge','Merge','Ignore this bone, but within its children is a jiggle bone'),
               ('normal','Normal','User-driven jiggle'),
               ('tip', 'Tip', 'A tip jiggle bone, needing a forward projected particle, contains no jiggle bone children')],
        override={'LIBRARY_OVERRIDABLE'},
        options={'HIDDEN'},
    )
    collider_type: EnumProperty(
        name=_jiggle_ui_text('Collider Type', 'コライダー種別'),
        description=_jiggle_ui_text('Choose whether this bone collides with one mesh object or every mesh in a collection.', 'このボーンが単一メッシュオブジェクトと衝突するか、コレクション内の全メッシュと衝突するかを選びます。'),
        items=[('Object','Object','Collide with a selected mesh'),('Collection','Collection','Collide with all meshes in selected collection')],
        override={'LIBRARY_OVERRIDABLE'},
        update=lambda s, c: update_nested_jiggle_prop(s, c, 'collider_type')
    )
    collider: PointerProperty(
        name='Collider Object', 
        description='Mesh object to collide with', 
        type=Object, 
        poll = collider_poll, 
        override={'LIBRARY_OVERRIDABLE'}, 
        update=lambda s, c: update_nested_jiggle_prop(s, c, 'collider')
    )
    collider_collection: PointerProperty(
        name = 'Collider Collection', 
        description='Collection to collide with', 
        type=Collection, 
        override={'LIBRARY_OVERRIDABLE'}, 
        update=lambda s, c: update_nested_jiggle_prop(s, c, 'collider_collection')
    )
    
class JiggleScene(PropertyGroup):
    lastframe: IntProperty(
        name=_jiggle_ui_text('Last Evaluated Frame', '最終評価フレーム'),
        description=_jiggle_ui_text('Internal frame number used to track Jiggle simulation continuity.', 'Jiggle シミュレーションの連続性を追跡するための内部フレーム番号です。'),
        options={'HIDDEN'},
    )
    loop: BoolProperty(
        name='Loop Physics',
        description='Physics continues as timeline loops',
        default=False,
        update=_update_npanel_persist,
    )
    gravity: FloatProperty(
        name=_jiggle_ui_text('Gravity Scale', '重力スケール'),
        description=_jiggle_ui_text('Scene-level multiplier applied to Blender scene gravity before Jiggle integration. 1.0 keeps the scene gravity unchanged.', 'Jiggle 積分前に Blender シーン重力へ掛けるシーン単位の倍率です。1.0 はシーン重力をそのまま使います。'),
        default=1.0,
        min=0.0,
        soft_max=4.0,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    substeps: IntProperty(
        name=_jiggle_ui_text('Substeps', 'サブステップ'),
        description=_jiggle_ui_text('Number of substeps evaluated per frame. Higher values improve stability for fast bones and heavy secondary motion at the cost of computation time.', '1フレーム内で評価するサブステップ数です。値を上げると高速ボーンや重い二次揺れの安定性が上がりますが、計算負荷も増えます。'),
        default=1,
        min=1,
        max=16,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    iterations: IntProperty(
        name=_jiggle_ui_text('Constraint Iterations', '拘束反復'),
        description=_jiggle_ui_text('Constraint-solver iterations evaluated inside each Jiggle substep. Increase when chains stretch too much or collisions feel soft.', '各 Jiggle サブステップ内で行う拘束ソルバー反復数です。チェーンが伸びすぎる場合や衝突が柔らかすぎる場合に上げます。'),
        default=1,
        min=1,
        max=32,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    preroll: IntProperty(
        name='Preroll',
        description='Frames to run simulation before bake',
        min=0,
        default=30,
        update=_update_npanel_persist,
    )
    bake_overwrite: BoolProperty(
        name='Overwrite Current Action',
        description='Bake jiggle into current action, instead of creating a new one',
        default=False,
        update=_update_npanel_persist,
    )
    bake_nla: BoolProperty(
        name='Current Action to NLA',
        description='Move existing animation on the armature into an NLA strip',
        default=False,
        update=_update_npanel_persist,
    ) 
    bake_debug: BoolProperty(
        name='Enable Bake Debugging', 
        description='Enable detailed logging during bake process. Creates a text block with performance analysis', 
        default = False,
            update=_update_npanel_persist,
)
    enable: BoolProperty(
        name = 'Enable Scene',
        description = 'Enable jiggle on this scene',
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
        update=_update_runtime_handler_state,
    )
    runtime_callbacks_enabled: BoolProperty(
        name = _jiggle_ui_text('Enable Runtime Callbacks', '実行コールバックを有効化'),
        description = _jiggle_ui_text(
            'Enables the frame-change, playback, render, and overlay callbacks required for live Jiggle Physics. Keep this off while not using Jiggle to reduce startup and background overhead.',
            'ライブ Jiggle Physics に必要なフレーム変更・再生・レンダー・オーバーレイ用コールバックを有効化します。使っていない間は OFF のままにして、起動時と常駐時の負荷を抑えてください。',
        ),
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
        update=_update_runtime_handler_state,
    )
    debug: BoolProperty(
        name = 'Enable debug',
        description = 'Enable profiling and debug features',
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    simulate_during_scrub: BoolProperty(
        name = 'Simulate During Scrub',
        description = 'Simulate jiggle physics while scrubbing the timeline',
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)

    # Wind settings
    enable_wind: BoolProperty(
        name = 'Enable Wind',
        description = 'Enable wind force affecting jiggle physics',
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    wind_direction: FloatVectorProperty(
        name = 'Wind Direction',
        description = 'Direction of the wind in world space',
        default = (1.0, 0.0, 0.0),
        subtype = 'DIRECTION',
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    wind_speed: FloatProperty(
        name = 'Wind Speed',
        description = 'Base speed/strength of the wind',
        default = 0.5,
        min = 0.0,
        soft_max = 10.0,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    wind_turbulence_scale: FloatProperty(
        name = 'Turbulence Scale',
        description = 'Scale of the wind turbulence noise field (larger = smoother, more gradual changes)',
        default = 2.0,
        min = 0,
        soft_max = 10.0,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)
    wind_evolution_speed: FloatProperty(
        name = 'Evolution Speed',
        description = 'Speed at which the wind pattern evolves over time (4D noise)',
        default = 0.1,
        min = 0.0,
        soft_max = 1.0,
        override={'LIBRARY_OVERRIDABLE'},
            update=_update_npanel_persist,
)

class JiggleObject(PropertyGroup):
    enable: BoolProperty(
        name = 'Enable Armature',
        description = 'Enable jiggle on this armature',
        default = False,
        options={'HIDDEN'},
        override={'LIBRARY_OVERRIDABLE'}
    )
    mute: BoolProperty(
        name = 'Mute Armature',
        description = 'Mute jiggle on this armature',
        default = False,
        override={'LIBRARY_OVERRIDABLE'},
    )
    freeze: BoolProperty(
        name = 'Freeze Jiggle',
        description = 'Jiggle Calculation frozen after baking',
        default = False,
        override={'LIBRARY_OVERRIDABLE'}
    )

def install_presets():
    try:
        # Path to bundled presets
        src_dir = os.path.join(os.path.dirname(__file__), "presets", "jigglebones")
        # The extension's user folder, which updates leave in place.
        dst_dir = _jiggle_preset_subdir(create=True)

        # Copy each bundled Python preset if it doesn't exist already.
        # Ignore cache folders or other non-preset files that Blender/Python may
        # create beside the bundled preset scripts.
        for filename in os.listdir(src_dir):
            if not str(filename).lower().endswith('.py'):
                continue
            src_file = os.path.join(src_dir, filename)
            if not os.path.isfile(src_file):
                continue
            dst_file = os.path.join(dst_dir, filename)
            if not os.path.exists(dst_file):
                shutil.copyfile(src_file, dst_file)
    except Exception:
        return False
    return True


_JIGGLE_POSE_BONE_FLOAT_PROPS = (
    "jiggle_angle_elasticity",
    "jiggle_length_elasticity",
    "jiggle_root_elasticity",
    "jiggle_elasticity_soften",
    "jiggle_gravity",
    "jiggle_blend",
    "jiggle_air_drag",
    "jiggle_friction",
    "jiggle_collision_radius",
)

_JIGGLE_DATA_CLASSES = (JiggleBone, JiggleObject, JiggleScene)
_JIGGLE_UI_CLASSES = (
    SCENE_OT_JiggleReset,
    ANIM_OT_JiggleClearKeyframes,
    SCENE_OT_JiggleProfile,
    ARMATURE_OT_JiggleCopy,
    ARMATURE_OT_JiggleSelect,
    ARMATURE_OT_JiggleBake,
    JIGGLE_PT_Settings,
    JIGGLE_PT_Bone,
    JIGGLE_PT_NoKeyframesWarning,
    JIGGLE_PT_ConnectedBonesWarning,
    JIGGLE_PT_BoneConstraintsWarning,
    JIGGLE_PT_MeshCollisionWarning,
    JIGGLE_PT_FrameSkippingEnabledWarning,
    JIGGLE_PT_Utilities,
    JIGGLE_PT_Wind,
    JIGGLE_PT_Bake,
    JIGGLE_OT_bone_connected_disable,
    JIGGLE_OT_bone_constraints_disable,
    JIGGLE_MT_JiggleBonePresets,
    JIGGLE_OT_AddJiggleBonePreset,
)

_JIGGLE_STARTUP_SAFE_CLASSES = (
    SCENE_OT_JiggleReset,
    ANIM_OT_JiggleClearKeyframes,
    SCENE_OT_JiggleProfile,
    ARMATURE_OT_JiggleCopy,
    ARMATURE_OT_JiggleSelect,
    ARMATURE_OT_JiggleBake,
    JIGGLE_OT_bone_connected_disable,
    JIGGLE_OT_bone_constraints_disable,
    JIGGLE_MT_JiggleBonePresets,
    JIGGLE_OT_AddJiggleBonePreset,
)

_JIGGLE_PANEL_CLASSES = (
    JIGGLE_PT_Settings,
    JIGGLE_PT_Bone,
    JIGGLE_PT_NoKeyframesWarning,
    JIGGLE_PT_ConnectedBonesWarning,
    JIGGLE_PT_BoneConstraintsWarning,
    JIGGLE_PT_MeshCollisionWarning,
    JIGGLE_PT_FrameSkippingEnabledWarning,
    JIGGLE_PT_Utilities,
    JIGGLE_PT_Wind,
    JIGGLE_PT_Bake,
)


def _register_pose_bone_numeric_properties() -> None:
    lifecycle.register_rna(PoseBone, 'jiggle_angle_elasticity', FloatProperty(name='Angle Elasticity', description='Spring angle stiffness, higher means more rigid. Also has a small effect on the bone length', min=0, default=0.6, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_angle_elasticity')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_length_elasticity', FloatProperty(name='Length Elasticity', description='Spring length stiffness, higher means more rigid to tension', min=0, default=0.8, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_length_elasticity')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_root_elasticity', FloatProperty(name='Root Elasticity', description='Elasticity of the root bone, higher means more rigid to tension', min=0, default=0.8, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_root_elasticity')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_elasticity_soften', FloatProperty(name='Elasticity Soften', description='Weakens the elasticity of the bone when its closer to the target pose. Higher means more like a free-rolling-ball-socket', min=0, default=0, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_elasticity_soften')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_gravity', FloatProperty(name='Gravity', description='Multiplier for scene gravity', default=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_gravity')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_blend', FloatProperty(name='Blend', description='jiggle blend, 0 means no jiggle, 1 means full jiggle', min=0, default=1, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_blend')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_air_drag', FloatProperty(name='Air Drag', description='How much the bone is slowed down by air, higher means more drag', min=0, default=0, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_air_drag')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_friction', FloatProperty(name='Friction', description='Internal friction, higher means return to rest quicker', min=0, default=0.1, max=1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_friction')), scope='jiggle.rna')
    lifecycle.register_rna(PoseBone, 'jiggle_collision_radius', FloatProperty(name='Collision Radius', description='Collision radius for use in collision detection and depenetration.', min=0, default=0.1, override={'LIBRARY_OVERRIDABLE'}, update=lambda s, c: update_pose_bone_jiggle_prop(s, c, 'jiggle_collision_radius')), scope='jiggle.rna')


def _register_pointer_properties() -> None:
    lifecycle.register_rna(
        PoseBone,
        'jiggle',
        PointerProperty(
            name='Jiggle Bone Settings',
            description='Stores Jiggle Physics settings for this pose bone, edited from the Smart Cloth N-panel.',
            type=JiggleBone,
            override={'LIBRARY_OVERRIDABLE'},
        ),
        scope='jiggle.rna',
    )
    lifecycle.register_rna(
        Object,
        'jiggle',
        PointerProperty(
            name='Jiggle Object Settings',
            description='Stores Jiggle Physics settings for this armature object, edited from the Smart Cloth N-panel.',
            type=JiggleObject,
            override={'LIBRARY_OVERRIDABLE'},
        ),
        scope='jiggle.rna',
    )
    lifecycle.register_rna(
        Scene,
        'jiggle',
        PointerProperty(
            name='Jiggle Scene Settings',
            description='Stores Jiggle Physics scene settings edited from the Smart Cloth N-panel.',
            type=JiggleScene,
            override={'LIBRARY_OVERRIDABLE'},
        ),
        scope='jiggle.rna',
    )


def register(include_ui: bool = True):
    mark = lifecycle.checkpoint()
    _jiggle_globals.on_register()
    try:
        _refresh_jiggle_preset_paths()
        install_presets()
        jiggle_i18n.register_translations()
        for cls in _JIGGLE_DATA_CLASSES:
            lifecycle.register_class(cls, scope='jiggle.data')
        _register_pose_bone_numeric_properties()
        _register_pointer_properties()
        classes = _JIGGLE_UI_CLASSES if bool(include_ui) else _JIGGLE_STARTUP_SAFE_CLASSES
        for cls in classes:
            lifecycle.register_class(cls, scope='jiggle.ui')
        _remove_runtime_handlers()
    except Exception:
        lifecycle.rollback_to(mark)
        _jiggle_globals.on_unregister()
        raise


def unregister():
    cancel_active_bake_transaction()
    _remove_runtime_handlers()
    _jiggle_globals.on_unregister()
    for scope in ('jiggle.ui', 'jiggle.rna', 'jiggle.data', 'jiggle.i18n'):
        lifecycle.release_scope(scope)


if __name__ == '__main__':
    register()

