# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from .. import lifecycle

EXTENSION_ID = __package__ or "jiggle_physics"

_UI_TRANSLATIONS = {
    "Jiggle Physics": "Jiggle Physics",
    "Copy Settings to Selected": "設定を選択ボーンへコピー",
    "Toggle Jiggle Profiler": "Jiggle プロファイラー切替",
    "Toggle Jiggle Rest Pose Overlay": "Jiggle レスト姿勢オーバーレイ切替",
    "Toggle Jiggle Simulation Overlay": "Jiggle シミュレーションオーバーレイ切替",
    "Reset Physics": "物理をリセット",
    "Clear Parameter Keyframes": "パラメーターキーフレームを削除",
    "Print Profiling Information to Console": "計測結果をコンソールへ出力",
    "Select Enabled": "有効ボーンを選択",
    "Bake Jiggle": "Jiggle をベイク",
    "Disconnect Selected Bones": "選択ボーンの接続を解除",
    "Disable Constraints": "制約を無効化",
    "Global Jiggle Utilities": "Jiggle ユーティリティ",
    "Wind Force": "風の力",
    "Jiggle Bone Presets": "Jiggle ボーンプリセット",
    "Add/Remove Jiggle Bone preset": "Jiggle ボーンプリセットを追加 / 削除",
    "Enable Bone Jiggle": "ボーン Jiggle を有効化",
    "Active Bone Jiggle": "アクティブボーン Jiggle",
    "Enable jiggle on this bone": "このボーンで Jiggle を有効化します。",
    "Jiggle Mode": "Jiggle モード",
    "Collider Type": "コライダー種別",
    "Collider Object": "コライダーオブジェクト",
    "Mesh object to collide with": "衝突判定に使うメッシュオブジェクトです。",
    "Collider Collection": "コライダーコレクション",
    "Collection to collide with": "衝突対象に使うコレクションです。",
    "Loop Physics": "物理をループ",
    "Physics continues as timeline loops": "タイムラインがループした時も物理計算を継続します。",
    "Preroll": "プリロール",
    "Frames to run simulation before bake": "ベイク前に先行計算するフレーム数です。",
    "Overwrite Current Action": "現在のアクションを上書き",
    "Bake jiggle into current action, instead of creating a new one": "新規アクションを作らず、現在のアクションへ Jiggle を焼き込みます。",
    "Current Action to NLA": "現在のアクションを NLA へ移動",
    "Move existing animation on the armature into an NLA strip": "アーマチュア上の既存アニメーションを NLA ストリップへ移動します。",
    "Enable Bake Debugging": "ベイクデバッグを有効化",
    "Enable detailed logging during bake process. Creates a text block with performance analysis": "ベイク中の詳細ログを有効化します。性能解析付きのテキストブロックを生成します。",
    "Enable Scene": "シーンで Jiggle を有効化",
    "Enable jiggle on this scene": "このシーンで Jiggle を有効化します。",
    "Enable Runtime Callbacks": "実行コールバックを有効化",
    "Enables the frame-change, playback, render, and overlay callbacks required for live Jiggle Physics. Keep this off while not using Jiggle to reduce startup and background overhead.": "ライブ Jiggle Physics に必要なフレーム変更・再生・レンダー・オーバーレイ用コールバックを有効化します。使っていない間は OFF のままにして、起動時と常駐時の負荷を抑えてください。",
    "Enable debug": "デバッグを有効化",
    "Enable profiling and debug features": "計測とデバッグ機能を有効化します。",
    "Simulate During Scrub": "スクラブ中もシミュレート",
    "Simulate jiggle physics while scrubbing the timeline": "タイムラインをスクラブしている間も Jiggle Physics を計算します。",
    "Enable Wind": "風を有効化",
    "Enable wind force affecting jiggle physics": "Jiggle Physics に影響する風の力を有効化します。",
    "Wind Direction": "風向き",
    "Direction of the wind in world space": "ワールド空間での風の向きです。",
    "Wind Speed": "風速",
    "Base speed/strength of the wind": "風の基本速度 / 強さです。",
    "Turbulence Scale": "乱流スケール",
    "Scale of the wind turbulence noise field (larger = smoother, more gradual changes)": "風の乱流ノイズのスケールです。大きいほど変化がなだらかになります。",
    "Evolution Speed": "変化速度",
    "Speed at which the wind pattern evolves over time (4D noise)": "時間経過に対して風パターンが変化する速度です（4D ノイズ）。",
    "Enable Armature": "アーマチュアで Jiggle を有効化",
    "Enable jiggle on this armature": "このアーマチュアで Jiggle を有効化します。",
    "Mute Armature": "アーマチュアをミュート",
    "Mute jiggle on this armature": "このアーマチュアで Jiggle を一時停止します。",
    "Freeze Jiggle": "Jiggle を固定",
    "Jiggle Calculation frozen after baking": "ベイク後に Jiggle 計算を固定します。",
    "Angle Elasticity": "角度弾性",
    "Spring angle stiffness, higher means more rigid. Also has a small effect on the bone length": "角度方向のばね剛性です。高いほど硬くなり、ボーン長にも少し影響します。",
    "Length Elasticity": "長さ弾性",
    "Spring length stiffness, higher means more rigid to tension": "長さ方向のばね剛性です。高いほど引っ張りに強くなります。",
    "Root Elasticity": "ルート弾性",
    "Elasticity of the root bone, higher means more rigid to tension": "ルートボーンの弾性です。高いほど引っ張りに強くなります。",
    "Elasticity Soften": "弾性ソフト化",
    "Weakens the elasticity of the bone when its closer to the target pose. Higher means more like a free-rolling-ball-socket": "目標姿勢へ近づいた時の弾性を弱めます。高いほど自由度の高いボールジョイントに近い挙動になります。",
    "Gravity": "重力",
    "Multiplier for scene gravity": "シーン重力に掛ける倍率です。",
    "Blend": "ブレンド",
    "jiggle blend, 0 means no jiggle, 1 means full jiggle": "Jiggle の混合量です。0 は無効、1 はフル適用です。",
    "Air Drag": "空気抵抗",
    "How much the bone is slowed down by air, higher means more drag": "空気による減速量です。高いほど空気抵抗が強くなります。",
    "Friction": "摩擦",
    "Internal friction, higher means return to rest quicker": "内部摩擦です。高いほど静止姿勢へ早く戻ります。",
    "Collision Radius": "衝突半径",
    "Collision radius for use in collision detection and depenetration.": "衝突判定とめり込み補正に使う半径です。",
    "No Keyframes Detected": "キーフレームが見つかりません",
    "Position and rotation keyframes are used for the rest pose.": "位置と回転のキーフレームをレスト姿勢の基準として使います。",
    "You can safely ignore this if you are using actions in the NLA.": "NLA 上のアクションを使っている場合は、この警告を無視して構いません。",
    "Bone Constraints Detected": "ボーン制約を検出",
    "Bone constraints are applied after jiggle, which can cause strange behavior.": "ボーン制約は Jiggle 後に適用されるため、不自然な挙動の原因になります。",
    "Be weary that using constraints in place of parenting can also cause the jiggle pose to not work as intended.": "親子関係の代わりに制約を使っている場合も、Jiggle 姿勢が意図通りに動かないことがあります。",
    "Click the button below to automatically disable constraints on selected bones.": "下のボタンを押すと、選択ボーンの制約を自動で無効化できます。",
    "You can safely ignore this if you are intending to constrain the jiggle pose.": "Jiggle 姿勢を意図的に制約している場合は、この警告を無視して構いません。",
    "Connected Bones Detected": "接続ボーンを検出",
    "Bones that are connected cannot be translated, preventing them from stretching.": "接続されたボーンは移動できないため、伸び方向の挙動が制限されます。",
    "This makes them ignore length elasticity.": "その結果、長さ弾性が効かなくなります。",
    "You can safely ignore this if stretchiness is not desired.": "伸びる挙動が不要な場合は、この警告を無視して構いません。",
    "Frame Dropping Detected": "フレームドロップを検出",
    "Playback set to Frame Dropping can cause the preview to be inaccurate.": "再生がフレームドロップになっていると、プレビュー精度が下がることがあります。",
    "Bakes will look very different.": "ベイク結果が大きく異なって見える場合があります。",
    "Scene muted.": "シーンでミュートされています。",
    " Select armature.": " アーマチュアを選択してください。",
    "Jiggle Frozen after Bake.": "ベイク後に Jiggle が固定されています。",
    "Armature muted.": "アーマチュアでミュートされています。",
    'Remove keyframes from jiggle parameters on selected bones. This will not remove the jiggle settings themselves, just the keyframes that control them.': '選択ボーンの Jiggle パラメーターからキーフレームだけを削除します。Jiggle 設定自体は削除されず、それを制御するキーフレームのみを消去します。',
    'Connected bones ignore length elasticity, preventing them from stretching. Click this button to automatically fix': '接続ボーンは長さ弾性が効かず、伸び挙動が無効になります。このボタンで自動修正できます。',
    'Constraints are applied after jiggle, which can cause strange behavior. Click this button to automatically disable constraints on selected bones': '制約は Jiggle の後に適用されるため、不自然な挙動の原因になります。このボタンで選択ボーンの制約を自動無効化できます。',
    'Disable Constraints on Selected Bones': '選択ボーンの制約を無効化',
    'Mesh Collision Detected': 'メッシュ衝突を検出',
    'Collisions': '衝突',
    " Select pose bone.": " ポーズボーンを選択してください。",
    "No VIEW_3D area found for overlay control": "オーバーレイ操作に使える 3D ビューのエリアが見つかりません。",
}

# --- Toolset complete language-setting additions v18 START ---
_UI_TRANSLATIONS.update({
    "Show Rest Pose": "レスト姿勢を表示",
    "Show Simulation": "シミュレーションを表示",
    "Heavy frame, playback, render, and overlay callbacks stay OFF until needed.": "重いフレーム・再生・レンダー・オーバーレイ用コールバックは、必要になるまで OFF のままです。",
    "Profiler": "プロファイラー",
    "Print Profiling Information": "計測結果を出力",
    "Overlay": "オーバーレイ",
    "Open a 3D View area to use overlay controls.": "オーバーレイ操作には 3D ビューのエリアを開いてください。",
    "Enable Runtime Callbacks first to draw the overlays live.": "ライブ表示するには先に実行コールバックを有効化してください。",
    "Meshes are not convex, making them suboptimal for collisions.": "メッシュは凸形状ではないため、衝突判定には最適ではありません。",
    "Please use scaled Empty spheres instead (Add -> Empty -> Sphere)": "代わりにスケールした球のエンプティを使ってください（追加 > エンプティ > 球）。",
    "None": "なし",
    "Not jiggled, and contains no jiggle bone children": "Jiggle されず、子に Jiggle ボーンも含みません。",
    "Root": "ルート",
    "A root jiggle bone": "ルート Jiggle ボーンです。",
    "Solo": "単独",
    "A bone without jiggled children or parents": "Jiggle された子や親を持たないボーンです。",
    "Merge": "マージ",
    "Ignore this bone, but within its children is a jiggle bone": "このボーンは無視しますが、子の中に Jiggle ボーンがあります。",
    "Normal": "通常",
    "User-driven jiggle": "ユーザー設定で動作する Jiggle です。",
    "Tip": "先端",
    "A tip jiggle bone, needing a forward projected particle, contains no jiggle bone children": "前方へ投影されたパーティクルが必要な先端 Jiggle ボーンです。子に Jiggle ボーンは含みません。",
    "Object": "オブジェクト",
    "Collide with a selected mesh": "選択したメッシュと衝突させます。",
    "Collection": "コレクション",
    "Collide with all meshes in selected collection": "選択したコレクション内のすべてのメッシュと衝突させます。",
})
# --- Toolset complete language-setting additions v18 END ---

TRANSLATIONS_DICT = {}


def _build_translations_dict() -> dict[str, dict[tuple[str, str], str]]:
    return {
        "ja_JP": {(context, source): target for context in ("*", "Operator") for source, target in _UI_TRANSLATIONS.items()},
    }


def register_translations() -> None:
    global TRANSLATIONS_DICT
    TRANSLATIONS_DICT = _build_translations_dict()
    lifecycle.register_translation(EXTENSION_ID, TRANSLATIONS_DICT, scope='jiggle.i18n')


def unregister_translations() -> None:
    lifecycle.release_scope('jiggle.i18n')


# --- Toolset complete language-source normalization v20 START ---
_UI_TRANSLATIONS.update({
    ' Select armature.': ' アーマチュアを選択してください。',
    ' Select pose bone.': ' ポーズボーンを選択してください。',
    'Add/Remove Jiggle Bone preset': 'Jiggle ボーンプリセットを追加 / 削除',
    'Animation': 'アニメーション',
    'Armature jiggle physics with standard 3D View Sidebar N-panel panels, overlays, wind, presets, and bake utilities.': '通常の3DビューサイドバーNパネル、オーバーレイ、風、プリセット、ベイク機能を備えたアーマチュア用 Jiggle 物理です。',
    'Armature muted.': 'アーマチュアでミュートされています。',
    'Armature Jiggle settings are not available.': 'アーマチュアの Jiggle 設定を取得できません。',
    'Bake Jiggle': 'Jiggle をベイク',
    'Bakes will look very different.': 'ベイク結果が大きく異なって見える場合があります。',
    'Be weary that using constraints in place of parenting can also cause the jiggle pose to not work as intended.': '親子関係の代わりに制約を使っている場合も、Jiggle 姿勢が意図通りに動かないことがあります。',
    'Bone Constraints Detected': 'ボーン制約を検出',
    'Bone constraints are applied after jiggle, which can cause strange behavior.': 'ボーン制約は Jiggle 後に適用されるため、不自然な挙動の原因になります。',
    'Bones that are connected cannot be translated, preventing them from stretching.': '接続されたボーンは移動できないため、伸び方向の挙動が制限されます。',
    'Clear Parameter Keyframes': 'パラメーターキーフレームを削除',
    'Click the button below to automatically disable constraints on selected bones.': '下のボタンを押すと、選択ボーンの制約を自動で無効化できます。',
    'Collisions': '衝突',
    'Connected Bones Detected': '接続ボーンを検出',
    'Connected bones ignore length elasticity, preventing them from stretching. Click this button to automatically fix': '接続ボーンは長さ弾性が効かず、伸び挙動が無効になります。このボタンで自動修正できます。',
    'Constraints are applied after jiggle, which can cause strange behavior. Click this button to automatically disable constraints on selected bones': '制約は Jiggle の後に適用されるため、不自然な挙動の原因になります。このボタンで選択ボーンの制約を自動無効化できます。',
    'Copy Settings to Selected': '設定を選択ボーンへコピー',
    'Disable Constraints': '制約を無効化',
    'Disable Constraints on Selected Bones': '選択ボーンの制約を無効化',
    'Disable Profiler': 'プロファイラーを無効化',
    'Disconnect Selected Bones': '選択ボーンの接続を解除',
    'Enable Profiler': 'プロファイラーを有効化',
    'Enable Runtime Callbacks': '実行コールバックを有効化',
    'Enable Runtime Callbacks first to draw the overlays live.': 'ライブ表示するには先に実行コールバックを有効化してください。',
    'Enables the frame-change, playback, render, and overlay callbacks required for live Jiggle Physics. Keep this off while not using Jiggle to reduce startup and background overhead.': 'ライブ Jiggle Physics に必要なフレーム変更・再生・レンダー・オーバーレイ用コールバックを有効化します。使っていない間は OFF のままにして、起動時と常駐時の負荷を抑えてください。',
    'Frame Dropping Detected': 'フレームドロップを検出',
    'Global Jiggle Utilities': 'Jiggle ユーティリティ',
    'Heavy frame, playback, render, and overlay callbacks stay OFF until needed.': '重いフレーム・再生・レンダー・オーバーレイ用コールバックは、必要になるまで OFF のままです。',
    'Jiggle Bone Presets': 'Jiggle ボーンプリセット',
    'Jiggle Frozen after Bake.': 'ベイク後に Jiggle が固定されています。',
    'Jiggle Physics': 'Jiggle Physics',
    'Mesh Collision Detected': 'メッシュ衝突を検出',
    'Meshes are not convex, making them suboptimal for collisions.': 'メッシュは凸形状ではないため、衝突判定には最適ではありません。',
    'No Keyframes Detected': 'キーフレームが見つかりません',
    'No VIEW_3D area found for overlay control': 'オーバーレイ操作に使える 3D ビューのエリアが見つかりません。',
    'Open a 3D View area to use overlay controls.': 'オーバーレイ操作には 3D ビューのエリアを開いてください。',
    'Overlay': 'オーバーレイ',
    'Playback set to Frame Dropping can cause the preview to be inaccurate.': '再生がフレームドロップになっていると、プレビュー精度が下がることがあります。',
    'Please use scaled Empty spheres instead (Add -> Empty -> Sphere)': '代わりにスケールした球のエンプティを使ってください（追加 > エンプティ > 球）。',
    'Position and rotation keyframes are used for the rest pose.': '位置と回転のキーフレームをレスト姿勢の基準として使います。',
    'Print Profiling Information': '計測結果を出力',
    'Print Profiling Information to Console': '計測結果をコンソールへ出力',
    'Profiler': 'プロファイラー',
    'Remove keyframes from jiggle parameters on selected bones. This will not remove the jiggle settings themselves, just the keyframes that control them.': '選択ボーンの Jiggle パラメーターからキーフレームだけを削除します。Jiggle 設定自体は削除されず、それを制御するキーフレームのみを消去します。',
    'Reset Physics': '物理をリセット',
    'Scene muted.': 'シーンでミュートされています。',
    'Select Enabled': '有効ボーンを選択',
    'Show Rest Pose': 'レスト姿勢を表示',
    'Show Simulation': 'シミュレーションを表示',
    'Smart Cloth': 'Smart Cloth',
    'Bundled Tools': '同梱ツール',
    'This makes them ignore length elasticity.': 'その結果、長さ弾性が効かなくなります。',
    'Toggle Jiggle Profiler': 'Jiggle プロファイラー切替',
    'Toggle Jiggle Rest Pose Overlay': 'Jiggle レスト姿勢オーバーレイ切替',
    'Toggle Jiggle Simulation Overlay': 'Jiggle シミュレーションオーバーレイ切替',
    'Wind Force': '風の力',
    'You can safely ignore this if stretchiness is not desired.': '伸びる挙動が不要な場合は、この警告を無視して構いません。',
    'You can safely ignore this if you are intending to constrain the jiggle pose.': 'Jiggle 姿勢を意図的に制約している場合は、この警告を無視して構いません。',
    'You can safely ignore this if you are using actions in the NLA.': 'NLA 上のアクションを使っている場合は、この警告を無視して構いません。',
})
try:
    TRANSLATIONS_DICT = _build_translations_dict()
except Exception:
    pass
# --- Toolset complete language-source normalization v20 END ---

# --- Toolset persistence tooltip i18n v21 START ---
_UI_TRANSLATIONS.update({
    'Jiggle particle position 0': 'Jiggle 粒子位置0',
    'Previous Jiggle particle position 0': '前回 Jiggle 粒子位置0',
    'Rest pose particle position 0': 'レスト姿勢粒子位置0',
    'Jiggle particle position 1': 'Jiggle 粒子位置1',
    'Previous Jiggle particle position 1': '前回 Jiggle 粒子位置1',
    'Rest pose particle position 1': 'レスト姿勢粒子位置1',
    'Jiggle particle position 2': 'Jiggle 粒子位置2',
    'Previous Jiggle particle position 2': '前回 Jiggle 粒子位置2',
    'Rest pose particle position 2': 'レスト姿勢粒子位置2',
    'Internal current simulated particle position for this Jiggle bone chain segment.': 'この Jiggle ボーンチェーン区間の現在の内部シミュレーション粒子位置です。',
    'Internal previous simulated particle position used to derive velocity.': '速度計算に使う前回の内部シミュレーション粒子位置です。',
    'Internal rest-pose reference particle position for the Jiggle solver.': 'Jiggle ソルバーが使う内部レスト姿勢基準粒子位置です。',
    'Internal mode showing how this bone participates in the Jiggle chain.': 'このボーンが Jiggle チェーンにどのように参加するかを示す内部モードです。',
    'Choose whether this bone collides with one mesh object or every mesh in a collection.': 'このボーンが単一メッシュオブジェクトと衝突するか、コレクション内の全メッシュと衝突するかを選びます。',
    'Last Evaluated Frame': '最終評価フレーム',
    'Internal frame number used to track Jiggle simulation continuity.': 'Jiggle シミュレーションの連続性を追跡するための内部フレーム番号です。',
})
try:
    TRANSLATIONS_DICT = _build_translations_dict()
except Exception:
    pass
# --- Toolset persistence tooltip i18n v21 END ---

# --- Toolset pointer property i18n v22 START ---
_UI_TRANSLATIONS.update({
    'Jiggle Bone Settings': 'Jiggle ボーン設定',
    'Stores Jiggle Physics settings for this pose bone, edited from the Smart Cloth N-panel.': 'Smart Cloth Nパネルで編集した、このポーズボーン用 Jiggle Physics 設定を保持します。',
    'Jiggle Object Settings': 'Jiggle オブジェクト設定',
    'Stores Jiggle Physics settings for this armature object, edited from the Smart Cloth N-panel.': 'Smart Cloth Nパネルで編集した、このアーマチュアオブジェクト用 Jiggle Physics 設定を保持します。',
    'Jiggle Scene Settings': 'Jiggle シーン設定',
    'Stores Jiggle Physics scene settings edited from the Smart Cloth N-panel.': 'Smart Cloth Nパネルで編集した Jiggle Physics のシーン設定を保持します。',
})
try:
    TRANSLATIONS_DICT = _build_translations_dict()
except Exception:
    pass
# --- Toolset pointer property i18n v22 END ---
