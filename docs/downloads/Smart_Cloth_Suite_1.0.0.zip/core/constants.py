# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

EXTENSION_ID = 'smart_cloth_suite'
EXTENSION_NAME = 'Smart Cloth Suite'
EXTENSION_VERSION = (2, 10, 6)
EXTENSION_VERSION_STR = '.'.join(str(v) for v in EXTENSION_VERSION)
AUTHOR_NAME = 'JELararagi'
COPYRIGHT_TEXT = 'Copyright (C) 2026 JELararagi'

EXTERNAL_ADDON_ID = 'simply_cloth_studio'
EXTERNAL_ADDON_NAME = 'Simply Cloth Studio'
EXTERNAL_CLOTH_MODIFIER = 'SimplyCloth'
EXTERNAL_PIN_GROUP = 'SimplyPin'
EXTERNAL_COLLISION_MODIFIER = 'SimplyCollision'

UTILITY_COLLECTION_RESULTS = 'Smart Cloth Suite Results'

STORAGE_MODE_ITEMS = (
    ('USER_DEFAULT', 'Blender Config', 'Store Smart Cloth Suite settings and reports in Blender 5.1/config/Smart_Cloth_Suite.'),
    ('BLEND_RELATIVE', 'Blender Config', 'Compatibility alias. Smart Cloth Suite still uses Blender 5.1/config/Smart_Cloth_Suite.'),
    ('CUSTOM', 'Custom', 'Use a manually selected external directory for generated output where supported.'),
)

TARGET_SCOPE_ITEMS = (
    ('ACTIVE', 'Active Cloth', 'Process only the active mesh cloth object.'),
    ('SELECTED', 'Selected Cloth', 'Process selected mesh cloth objects.'),
    ('ALL', 'All Cloth in Scene', 'Process every mesh with a Cloth modifier in the current scene.'),
)

QUALITY_PROFILE_ITEMS = (
    ('PREVIEW', 'Preview', 'Fast interactive values for blocking and viewport iteration.'),
    ('BALANCED', 'Balanced', 'General-purpose values for normal production work.'),
    ('PRODUCTION', 'Production', 'Higher solver and collision quality for production review and baking.'),
    ('HERO', 'Hero', 'Highest bundled quality profile for difficult close-up cloth.'),
)

QUALITY_PROFILE_VALUES = {
    'PREVIEW': {
        'quality': 4,
        'collision_quality': 2,
        'time_scale': 0.85,
    },
    'BALANCED': {
        'quality': 8,
        'collision_quality': 4,
        'time_scale': 0.75,
    },
    'PRODUCTION': {
        'quality': 12,
        'collision_quality': 6,
        'time_scale': 0.65,
    },
    'HERO': {
        'quality': 20,
        'collision_quality': 8,
        'time_scale': 0.55,
    },
}

REPORT_FORMAT_ITEMS = (
    ('JSON', 'JSON', 'Write a structured JSON report.'),
    ('TEXT', 'Text', 'Write a readable plain-text report.'),
)

ANALYSIS_GROUP_CURVATURE = 'SCSuite_CurvatureRisk'
ANALYSIS_GROUP_PIN = 'SCSuite_PinSuggestion'
ANALYSIS_GROUP_PROXIMITY = 'SCSuite_CollisionProximity'
PREVIEW_STATE_KEY = '_smart_cloth_suite_preview_state_v1'
LAYER_ORDER_KEY = '_smart_cloth_suite_layer_order_v1'
