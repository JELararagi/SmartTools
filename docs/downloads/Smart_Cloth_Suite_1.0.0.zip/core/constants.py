EXTERNAL_ADDON_ID='simply_cloth_studio'
EXTERNAL_ADDON_NAME='Simply Cloth Studio'
