# SPDX-License-Identifier: GPL-3.0-or-later
"""SmartCloth adapter to separately installed, RNA-registered Blender tools."""
from contextlib import nullcontext
from dataclasses import dataclass
from pathlib import Path
import sys
import tomllib

import bpy

from .constants import EXTERNAL_ADDON_ID, EXTERNAL_ADDON_NAME


_REQUIRED = ('object.create_cloth', 'object.simply_collision_manager',
             'screen.animation_manager', 'object.finish_cloth')
_OPTIONAL = ('object.scs_performance_mode', 'object.scs_calculate_modifier_performance',
             'object.sc_setup_simply_geo_nodes', 'object.scs_setup_overlapping_cloth',
             'object.create_pin_layers')


@dataclass(frozen=True)
class ExternalStatus:
    installed: bool
    enabled: bool
    version: str
    addon_key: str
    manifest_path: str
    missing_required: tuple[str, ...]
    available_optional: tuple[str, ...]

    @property
    def ready(self):
        return self.enabled and not self.missing_required


_empty = ExternalStatus(False, False, '', '', '', _REQUIRED, ())
_snapshot = None


def peek_external_status():
    return _snapshot if _snapshot is not None else _empty


def invalidate_status_cache():
    global _snapshot
    _snapshot = None


def _operator_callable(idname):
    bits = str(idname).split('.')
    if len(bits) != 2 or not all(bit.isidentifier() and not bit.startswith('_') for bit in bits):
        return None
    try:
        operator = getattr(getattr(bpy.ops, bits[0]), bits[1])
        operator.get_rna_type()
    except (AttributeError, KeyError, RuntimeError, ValueError):
        return None
    return operator


def operator_available(idname):
    return _operator_callable(idname) is not None


def _locations(key):
    # Reading metadata from an already enabled module does not execute vendor code.
    source = getattr(sys.modules.get(key), '__file__', None)
    if source:
        yield Path(source).parent
    prefs = getattr(bpy.context, 'preferences', None)
    repos = getattr(getattr(prefs, 'extensions', None), 'repos', ())
    for repo in repos:
        if repo.directory:
            yield Path(repo.directory) / EXTERNAL_ADDON_ID
    for kind in ('EXTENSIONS','SCRIPTS','CONFIG'):
        location = bpy.utils.user_resource(kind, create=False)
        if not location:
            continue
        base = Path(location)
        if kind == 'CONFIG':
            yield base.parent / 'extensions' / 'user_default' / EXTERNAL_ADDON_ID
            yield base.parent / 'scripts' / 'addons' / EXTERNAL_ADDON_ID
            continue
        yield base / EXTERNAL_ADDON_ID
        yield base / 'addons' / EXTERNAL_ADDON_ID
        yield base / 'user_default' / EXTERNAL_ADDON_ID
        if kind == 'EXTENSIONS' and base.is_dir():
            try:
                children = sorted(base.iterdir())
            except OSError:
                continue
            for repo in children:
                yield repo / EXTERNAL_ADDON_ID


def _manifest(key):
    for folder in dict.fromkeys(_locations(key)):
        path = folder / 'blender_manifest.toml'
        try:
            with path.open('rb') as stream:
                info = tomllib.load(stream)
        except FileNotFoundError:
            continue
        except (tomllib.TOMLDecodeError, UnicodeError):
            # An installed extension with an unreadable version is still installed.
            return str(path), ''
        except OSError:
            continue
        if info.get('id',EXTERNAL_ADDON_ID) == EXTERNAL_ADDON_ID:
            return str(path), str(info.get('version',''))
    return '', ''


def external_status(*, force=False):
    global _snapshot
    if _snapshot is None or force:
        prefs = getattr(bpy.context, 'preferences', None)
        keys = getattr(prefs, 'addons', {})
        key = next((key for key in keys.keys()
                    if key.rsplit('.',1)[-1].casefold()==EXTERNAL_ADDON_ID.casefold()), '')
        missing = tuple(identifier for identifier in _REQUIRED if not operator_available(identifier))
        extra = tuple(identifier for identifier in _OPTIONAL if operator_available(identifier))
        enabled = bool(key or len(missing) < len(_REQUIRED))
        location, version = _manifest(key)
        _snapshot = ExternalStatus(bool(enabled or location), enabled, version, key, location, missing, extra)
    return _snapshot


def view3d_override(context=None):
    ctx = context or bpy.context
    active = getattr(ctx, 'window', None)
    windows = list(getattr(getattr(ctx,'window_manager',None), 'windows', ()))
    if active is not None:
        windows = [active] + [win for win in windows if win != active]
    for window in windows:
        screen = window.screen
        if screen is None:
            continue
        areas = list(screen.areas)
        preferred = getattr(ctx, 'area', None)
        if preferred is not None and preferred in areas:
            areas = [preferred] + [area for area in areas if area != preferred]
        for area in areas:
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if region:
                    return bpy.context.temp_override(window=window, screen=screen, area=area, region=region)
    return nullcontext()


def _error_text(en, ja, context=None):
    prefs = getattr(context or bpy.context, 'preferences', None)
    view = getattr(prefs, 'view', None)
    if view and view.use_translate_interface:
        language = bpy.app.translations.locale or view.language
        if language.lower().startswith('ja'):
            return ja
    return en


def call_external_operator(idname, context=None, *, execution_context='EXEC_DEFAULT', **properties):
    operator = _operator_callable(idname)
    if operator is None:
        raise RuntimeError(_error_text(f'A required {EXTERNAL_ADDON_NAME} command is unavailable.',
                                      f'{EXTERNAL_ADDON_NAME} の必要な操作を使えません。',context))
    with view3d_override(context):
        if not operator.poll():
            raise RuntimeError(_error_text(f'{EXTERNAL_ADDON_NAME} cannot run this command now. Check the selection and mode.',
                                          f'今の状態では {EXTERNAL_ADDON_NAME} の操作を実行できません。選択とモードを確かめてください。',context))
        return operator(execution_context or 'EXEC_DEFAULT', **properties)
