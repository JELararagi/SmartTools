# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Public-operator bridge for an externally installed Simply Cloth Studio.

This module never imports or bundles Simply Cloth Studio implementation files.
It detects the external extension and calls only operators registered in
``bpy.ops``. Status probes are cached so N-panel redraws remain lightweight.
"""

from __future__ import annotations

from contextlib import contextmanager, nullcontext
from dataclasses import dataclass
import re
import importlib
from pathlib import Path
from typing import Iterator

import bpy

from .constants import EXTERNAL_ADDON_ID, EXTERNAL_ADDON_NAME

_REQUIRED_OPERATORS = (
    'object.create_cloth',
    'object.simply_collision_manager',
    'screen.animation_manager',
    'object.finish_cloth',
)

_OPTIONAL_OPERATORS = (
    'object.scs_performance_mode',
    'object.scs_calculate_modifier_performance',
    'object.sc_setup_simply_geo_nodes',
    'object.scs_setup_overlapping_cloth',
    'object.create_pin_layers',
)

_STATUS_CACHE: 'ExternalStatus | None' = None


@dataclass(frozen=True)
class ExternalStatus:
    installed: bool
    enabled: bool
    version: str
    addon_key: str
    manifest_path: str
    missing_required: tuple[str, ...]
    available_optional: tuple[str, ...]

    @property
    def ready(self) -> bool:
        return bool(self.enabled and not self.missing_required)


_UNKNOWN_STATUS = ExternalStatus(
    installed=False,
    enabled=False,
    version="",
    addon_key="",
    manifest_path="",
    missing_required=_REQUIRED_OPERATORS,
    available_optional=(),
)


def peek_external_status() -> ExternalStatus:
    """Return the immutable snapshot without probing modules, files, or operators."""
    return _STATUS_CACHE if _STATUS_CACHE is not None else _UNKNOWN_STATUS


def _operator_callable(idname: str):
    category, sep, name = str(idname or '').partition('.')
    if not sep or not category or not name:
        return None
    try:
        namespace = getattr(bpy.ops, category)
        operator = getattr(namespace, name)
        operator.get_rna_type()
        return operator
    except Exception:
        return None


def operator_available(idname: str) -> bool:
    return _operator_callable(idname) is not None


def _addon_keys() -> tuple[str, ...]:
    try:
        addons = getattr(getattr(bpy.context, 'preferences', None), 'addons', None)
        if addons is None:
            return ()
        return tuple(str(key) for key in addons.keys())
    except Exception:
        return ()


def _matching_addon_key() -> str:
    for key in _addon_keys():
        lower = key.lower()
        if lower == EXTERNAL_ADDON_ID or lower.endswith('.' + EXTERNAL_ADDON_ID):
            return key
    return ''


def _module_manifest_candidates(addon_key: str) -> list[Path]:
    candidates: list[Path] = []
    if not addon_key:
        return candidates
    try:
        module = importlib.import_module(addon_key)
        module_path = Path(getattr(module, '__file__', '')).resolve().parent
        candidates.append(module_path / 'blender_manifest.toml')
    except Exception:
        pass
    return candidates


def _installation_manifest_candidates() -> list[Path]:
    candidates: list[Path] = []
    try:
        repos = bpy.context.preferences.extensions.repos
        for repo in repos:
            directory = str(getattr(repo, 'directory', '') or '')
            if directory:
                candidates.append(Path(directory) / EXTERNAL_ADDON_ID / 'blender_manifest.toml')
    except Exception:
        pass
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if callable(user_resource):
        for kind in ('EXTENSIONS', 'SCRIPTS'):
            try:
                value = user_resource(kind, create=False) or ''
            except TypeError:
                try:
                    value = user_resource(kind) or ''
                except Exception:
                    value = ''
            except Exception:
                value = ''
            if not value:
                continue
            root = Path(value)
            if kind == 'EXTENSIONS':
                # Simply Cloth Studio may live in any extension repository
                # (it ships from superhivemarket_com, not user_default).
                try:
                    for repo in sorted(root.iterdir()):
                        if repo.is_dir():
                            candidates.append(repo / EXTERNAL_ADDON_ID / 'blender_manifest.toml')
                except OSError:
                    pass
            candidates.extend((
                root / 'user_default' / EXTERNAL_ADDON_ID / 'blender_manifest.toml',
                root / EXTERNAL_ADDON_ID / 'blender_manifest.toml',
                root / 'addons' / EXTERNAL_ADDON_ID / 'blender_manifest.toml',
            ))
    try:
        config = Path(bpy.utils.user_resource('CONFIG', create=False) or '')
        if config:
            version_root = config.resolve().parent
            candidates.append(version_root / 'extensions' / 'user_default' / EXTERNAL_ADDON_ID / 'blender_manifest.toml')
            candidates.append(version_root / 'scripts' / 'addons' / EXTERNAL_ADDON_ID / 'blender_manifest.toml')
    except Exception:
        pass
    return candidates


def _find_manifest(addon_key: str) -> Path | None:
    seen: set[str] = set()
    for candidate in [*_module_manifest_candidates(addon_key), *_installation_manifest_candidates()]:
        try:
            key = str(candidate.resolve())
        except Exception:
            key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        try:
            if candidate.is_file():
                return candidate
        except Exception:
            continue
    return None


def _manifest_version(path: Path | None) -> str:
    if path is None:
        return ''
    try:
        text = path.read_text(encoding='utf-8', errors='ignore')
        match = re.search(r'^\s*version\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
        return str(match.group(1)) if match else ''
    except Exception:
        return ''


def invalidate_status_cache() -> None:
    global _STATUS_CACHE
    _STATUS_CACHE = None


def external_status(*, force: bool = False) -> ExternalStatus:
    global _STATUS_CACHE
    # Status discovery scans registered operators, enabled add-ons, loaded
    # modules, and installation paths. Cache the single result until an explicit
    # refresh or lifecycle invalidation so repeated N-panel draws do no work.
    if not force and _STATUS_CACHE is not None:
        return _STATUS_CACHE

    addon_key = _matching_addon_key()
    missing = tuple(idname for idname in _REQUIRED_OPERATORS if not operator_available(idname))
    optional = tuple(idname for idname in _OPTIONAL_OPERATORS if operator_available(idname))
    enabled = bool(addon_key or len(missing) < len(_REQUIRED_OPERATORS))
    manifest = _find_manifest(addon_key)
    installed = bool(enabled or manifest is not None)
    status = ExternalStatus(
        installed=installed,
        enabled=enabled,
        version=_manifest_version(manifest),
        addon_key=addon_key,
        manifest_path=str(manifest or ''),
        missing_required=missing,
        available_optional=optional,
    )
    _STATUS_CACHE = status
    return status


def _window_area_region(context=None):
    ctx = context or bpy.context
    try:
        area = getattr(ctx, 'area', None)
        region = getattr(ctx, 'region', None)
        window = getattr(ctx, 'window', None)
        if area is not None and area.type == 'VIEW_3D' and region is not None and region.type == 'WINDOW' and window is not None:
            return window, area, region
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) or bpy.context.window_manager
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in tuple(getattr(area, 'regions', ()) or ()):
                    if getattr(region, 'type', None) == 'WINDOW':
                        return window, area, region
    except Exception:
        pass
    return None, None, None


@contextmanager
def view3d_override(context=None) -> Iterator[None]:
    window, area, region = _window_area_region(context)
    if window is None or area is None or region is None:
        with nullcontext():
            yield
        return
    try:
        with bpy.context.temp_override(window=window, screen=window.screen, area=area, region=region):
            yield
    except Exception:
        with nullcontext():
            yield


def _error_text(en: str, ja: str, context=None) -> str:
    try:
        view = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return en
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        return ja if (locale or language).lower().startswith('ja') else en
    except Exception:
        return en


def call_external_operator(idname: str, context=None, *, execution_context: str = 'EXEC_DEFAULT', **properties):
    operator = _operator_callable(idname)
    if operator is None:
        raise RuntimeError(_error_text(f'A required {EXTERNAL_ADDON_NAME} command is unavailable.', f'{EXTERNAL_ADDON_NAME} の必要な操作を使えません。', context))
    with view3d_override(context):
        try:
            if not operator.poll():
                raise RuntimeError(_error_text(f'{EXTERNAL_ADDON_NAME} cannot run this command now. Check the selection and mode.', f'今の状態では {EXTERNAL_ADDON_NAME} の操作を実行できません。選択とモードを確かめてください。', context))
        except AttributeError:
            pass
        return operator(str(execution_context or 'EXEC_DEFAULT'), **properties)
