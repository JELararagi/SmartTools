"""Public non-mutating bridge-state contract for adjacent SmartTools."""
from ..bridge import BridgeStatusV1,status as bridge_status,PROFILE as BRIDGE_PROFILE_KEY,OWNER as BRIDGE_OWNER_KEY
from ..component import KEY as COMPONENT_PROFILE_KEY,OWNER as COMPONENT_OWNER_KEY,BACKUP as COMPONENT_BACKUP_ID_KEY
COMPONENT_HOOK_MODIFIER='SC_ComponentSupport'
