"""Optional companion provider interface."""
