# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from . import integration
from . import skirt


def _is_japanese(context=None) -> bool:
    try:
        view = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        return (locale or language).lower().startswith('ja')
    except Exception:
        return False


def _t(en: str, ja: str, context=None) -> str:
    return str(ja if _is_japanese(context) else en)


def _settings(context=None):
    scene = getattr(context or bpy.context, 'scene', None)
    return getattr(scene, 'smart_cloth_suite_companion', None) if scene is not None else None


def _child_panel(layout, settings, prop_name: str, label: str, icon: str = 'NONE'):
    del icon
    opened = bool(getattr(settings, prop_name, False))
    try:
        header, body = layout.panel_prop(settings, prop_name)
    except Exception:
        layout.prop(settings, prop_name, text=label, toggle=True)
        return layout.column(align=True) if opened else None
    header.label(text=label)
    return body.column(align=True) if body is not None else None


def _prop(layout, settings, name: str, en: str, ja: str, context, **kwargs):
    label = _t(en, ja, context)
    try:
        # A field next to its name leaves the name a few characters at the default
        # sidebar width, so fields with a text value get the name on its own line.
        if settings.bl_rna.properties[name].type in {'ENUM', 'POINTER', 'STRING'}:
            column = layout.column(align=True)
            column.label(text=label)
            column.prop(settings, name, text='', **kwargs)
        else:
            layout.prop(settings, name, text=label, **kwargs)
    except Exception:
        pass


_BRIDGE_STATUS_REASONS = {
    'explicit_armature_required': ('Select a target armature.', '対象アーマチュアを選択してください。'),
    'orphan_owned_output': ('An owned output has no saved bridge profile.', '保存されたボーン焼付け設定のない所有出力があります。'),
    'invalid_saved_profile': ('The saved bridge profile is invalid.', '保存されたボーン焼付け設定が不正です。'),
    'invalid_source': ('The saved source mesh is invalid.', '保存された採取元メッシュが不正です。'),
    'missing_source': ('The saved source mesh is missing.', '保存された採取元メッシュが見つかりません。'),
    'source_mismatch': ('The selected mesh differs from the saved source.', '選択したメッシュが保存された採取元と異なります。'),
    'armature_mismatch': ('The saved target armature differs.', '保存された対象アーマチュアが異なります。'),
    'unknown_saved_mode': ('The saved bridge mode is unsupported.', '保存されたボーン焼付け方式に対応していません。'),
    'invalid_output_rows': ('The saved output list is invalid.', '保存されたボーン出力の一覧が不正です。'),
    'duplicate_or_invalid_output': ('The saved output contains duplicate or invalid entries.', '保存されたボーン出力に重複または不正な項目があります。'),
    'missing_helper_bone': ('An owned helper bone is missing.', '所有する補助ボーンが見つかりません。'),
    'unrecorded_owned_output': ('An unrecorded owned output exists.', '記録されていない所有ボーン出力があります。'),
    'missing_or_nonfinite_owned_influence': ('An owned output has missing or invalid influence.', '所有するボーン出力の影響度が未設定または不正です。'),
    'owned_output_influence_not_full': ('An owned output is not at full influence.', '所有するボーン出力の影響度が100%ではありません。'),
    'saved_mode_output_disagree': ('Saved mode and owned output disagree.', '保存された方式と所有ボーン出力の状態が一致しません。'),
    'inconsistent_owned_output': ('Owned bridge resources are inconsistent.', '所有するボーン焼付けのリソースに不整合があります。'),
}


def _bridge_status_reason(reason: str, context) -> str:
    en, ja = _BRIDGE_STATUS_REASONS.get(
        reason, ('Inspect the bridge output and saved setup.', 'ボーン焼付け出力と保存設定を確認してください。'))
    return _t(en, ja, context)


def _status_box(layout, context):
    status = integration.peek_external_status()
    box = layout.box()
    row = box.row(align=True)
    row.label(text='Simply Cloth Studio', icon='CHECKMARK' if status.ready else 'ERROR', translate=False)
    row.operator('smart_cloth_suite.refresh_external_status', text='', icon='FILE_REFRESH')
    if status.ready:
        box.label(text=_t('Ready', '使用可能', context))
    elif status.installed and not status.enabled:
        box.label(text=_t('Installed but disabled', 'インストール済み・無効', context))
    elif status.installed:
        box.label(text=_t('Required commands missing', '必須の操作が未検出', context))
    else:
        box.label(text=_t('Not detected', '未検出', context))
    if status.version:
        box.label(text=_t('External version: %(version)s', '外部バージョン: %(version)s', context) % {'version': status.version}, translate=False)
    return status, box


def draw_integration(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        layout.label(text=_t('Companion settings are unavailable.', '連携設定を取得できません。', context), icon='ERROR')
        return
    status, box = _status_box(layout, context)
    row = box.column(align=True)
    row.operator('smart_cloth_suite.open_external_preferences', text=_t('Open Add-on Settings', 'アドオン設定を開く', context), icon='PREFERENCES')
    if status.ready:
        row.operator('smart_cloth_suite.apply_colliders', text=_t('Apply Colliders', 'コライダー適用', context), icon='MOD_PHYSICS')

    body = _child_panel(layout, settings, 'ui_external_details', _t('Integration Targets', '連携対象', context), 'LINKED')
    if body is not None:
        _prop(body, settings, 'body_object', 'Body Collider', 'ボディコライダー', context)
        _prop(body, settings, 'collider_collection', 'Collider Collection', 'コライダーコレクション', context)
        body.separator(factor=0.35)
        if status.missing_required:
            body.label(text=_t('Missing required commands: %(count)s', '未検出の必須の操作: %(count)s 個', context) % {'count': len(status.missing_required)}, icon='ERROR', translate=False)
        else:
            body.label(text=_t('All required commands are available.', '必須の操作をすべて利用できます。', context), icon='CHECKMARK')


def draw_workflow(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    row = layout.column(align=True)
    row.scale_y = 1.35
    row.operator('smart_cloth_suite.smart_setup', text=_t('Smart Setup', 'スマートセットアップ', context), icon='MOD_CLOTH')
    row.operator('smart_cloth_suite.apply_quality_profile', text=_t('Apply Profile', 'プロファイル適用', context), icon='PRESET')
    body = _child_panel(layout, settings, 'ui_workflow_options', _t('Smart Setup Options', 'スマートセットアップ設定', context), 'TOOL_SETTINGS')
    if body is not None:
        _prop(body, settings, 'target_scope', 'Target Scope', '対象範囲', context)
        _prop(body, settings, 'quality_profile', 'Quality Profile', '品質プロファイル', context)
        _prop(body, settings, 'external_modifiers_handling', 'Existing Modifiers', '既存モディファイア', context)
        col = body.column(align=True)
        _prop(col, settings, 'apply_profile_after_setup', 'Apply Quality Profile', '品質プロファイルを適用', context)
        _prop(col, settings, 'auto_collision_after_setup', 'Auto Collision Distance', '衝突距離を自動調整', context)
        _prop(col, settings, 'apply_colliders_after_setup', 'Apply Collider Setup', 'コライダー設定を適用', context)
        _prop(col, settings, 'auto_pin_top', 'Create Top Pin When Missing', '未設定時に上端ピンを作成', context)
        if settings.auto_pin_top:
            _prop(col, settings, 'preserve_existing_pin', 'Preserve Existing Pin Weights', '既存ピンウェイトを保持', context)
            _prop(col, settings, 'pin_band_ratio', 'Top Pin Band', '上端ピン帯幅', context, slider=True)
    draw_skirt(layout, context)


def draw_performance(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    row = layout.column(align=True)
    op = row.operator('smart_cloth_suite.batch_preview', text=_t('Apply Batch Preview', '一括プレビュー適用', context), icon='HIDE_OFF')
    op.action = 'APPLY'
    op = row.operator('smart_cloth_suite.batch_preview', text=_t('Restore Preview State', 'プレビュー状態を復元', context), icon='LOOP_BACK')
    op.action = 'RESTORE'
    row = layout.row(align=True)
    row.operator('smart_cloth_suite.apply_quality_profile', text=_t('Apply Selected Profile', '選択プロファイルを適用', context), icon='PRESET')
    body = _child_panel(layout, settings, 'ui_performance_options', _t('Batch / Preview Options', '一括処理 / プレビュー設定', context), 'OPTIONS')
    if body is not None:
        _prop(body, settings, 'target_scope', 'Target Scope', '対象範囲', context)
        _prop(body, settings, 'quality_profile', 'Quality Profile', '品質プロファイル', context)
        _prop(body, settings, 'preview_quality', 'Preview Solver Quality', 'プレビューソルバー品質', context)
        _prop(body, settings, 'preview_hide_heavy_modifiers', 'Hide Heavy Modifiers', '高負荷モディファイアを非表示', context)


def draw_precision(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    row = layout.column(align=True)
    row.operator('smart_cloth_suite.auto_collision_distance', text=_t('Auto Distance', '距離を自動調整', context), icon='DRIVER_DISTANCE')
    row.operator('smart_cloth_suite.temporal_guard', text=_t('Temporal Guard', '時間方向ガード', context), icon='TIME')
    row.operator('smart_cloth_suite.layer_clearance', text=_t('Layer Clearance', 'レイヤー間隔', context), icon='SORT_ASC')
    body = _child_panel(layout, settings, 'ui_precision_options', _t('Precision / Collision Options', '精度 / 衝突設定', context), 'MOD_PHYSICS')
    if body is not None:
        _prop(body, settings, 'target_scope', 'Target Scope', '対象範囲', context)
        _prop(body, settings, 'enable_self_collision', 'Self Collision', '自己衝突', context)
        _prop(body, settings, 'collision_distance_factor', 'Edge Distance Factor', 'エッジ距離係数', context)
        row = body.column(align=True)
        _prop(row, settings, 'min_collision_distance', 'Minimum', '最小距離', context)
        _prop(row, settings, 'max_collision_distance', 'Maximum', '最大距離', context)
        _prop(body, settings, 'layer_gap', 'Layer Gap', 'レイヤー間隔', context)
        _prop(body, settings, 'motion_sample_frames', 'Motion Sample Frames', '動きサンプルフレーム', context)
        _prop(body, settings, 'temporal_guard_multiplier', 'Temporal Guard Multiplier', '時間方向ガード倍率', context)
        _prop(body, settings, 'body_object', 'Body Collider', 'ボディコライダー', context)


def draw_analysis(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    row = layout.column(align=True)
    row.operator('smart_cloth_suite.build_analysis_maps', text=_t('Build Analysis Maps', '解析マップ作成', context), icon='GROUP_VERTEX')
    row.operator('smart_cloth_suite.preflight', text=_t('Run Preflight', 'プリフライト実行', context), icon='VIEWZOOM')
    row = layout.row(align=True)
    row.operator('smart_cloth_suite.repair_topology', text=_t('Safe Topology Repair', '安全なトポロジー補正', context), icon='TOOL_SETTINGS')
    body = _child_panel(layout, settings, 'ui_analysis_options', _t('Analysis / Repair Options', '解析 / 補正設定', context), 'VIEWZOOM')
    if body is not None:
        _prop(body, settings, 'target_scope', 'Target Scope', '対象範囲', context)
        _prop(body, settings, 'body_object', 'Body Collider', 'ボディコライダー', context)
        _prop(body, settings, 'analysis_proximity_distance', 'Proximity Distance', '近接解析距離', context)
        _prop(body, settings, 'repair_merge_factor', 'Merge Distance Factor', 'マージ距離係数', context)
        _prop(body, settings, 'repair_remove_loose', 'Remove Isolated Vertices', '孤立頂点を削除', context)


def draw_output(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    row = layout.column(align=True)
    op = row.operator('smart_cloth_suite.safe_output', text=_t('Safe Bake', '安全ベイク', context), icon='REC')
    op.action = 'BAKE'
    op = row.operator('smart_cloth_suite.safe_output', text=_t('Safe Finish', '安全仕上げ', context), icon='CHECKMARK')
    op.action = 'FINISH'
    op = row.operator('smart_cloth_suite.safe_output', text=_t('Free Bake', 'ベイク解除', context), icon='X')
    op.action = 'FREE_BAKE'
    row = layout.column(align=True)
    row.operator('smart_cloth_suite.preflight', text=_t('Export Preflight Report', 'プリフライトレポート出力', context), icon='EXPORT')
    row.operator('smart_cloth_suite.open_data_folder', text=_t('Open Data Folder', 'データフォルダーを開く', context), icon='FILE_FOLDER')
    body = _child_panel(layout, settings, 'ui_output_options', _t('Bake / Report Options', 'ベイク / レポート設定', context), 'OUTPUT')
    if body is not None:
        _prop(body, settings, 'target_scope', 'Target Scope', '対象範囲', context)
        _prop(body, settings, 'report_format', 'Report Format', 'レポート形式', context)
        _prop(body, settings, 'stop_on_preflight_error', 'Stop on Preflight Error', 'プリフライトエラー時に停止', context)
        if settings.last_report_path:
            body.label(text=_t('Last Report:', '最新レポート:', context), icon='TEXT')
            body.label(text=str(settings.last_report_path), translate=False)
    if settings.last_status:
        layout.label(text=str(settings.last_status), translate=False)


def _draw_cloth_bone_bridge(component_body, settings, context) -> None:
    bridge_header, bridge_body = component_body.panel_prop(settings, 'ui_cloth_bone_bridge')
    bridge_header.label(text=_t('Cloth to Garment Bones', 'クロスから衣装ボーンへ', context), icon='ARMATURE_DATA')
    if bridge_body is None:
        return
    _prop(bridge_body, settings, 'bridge_source_mesh', 'Baked Cloth Mesh', 'ベイク済みクロスメッシュ', context)
    _prop(bridge_body, settings, 'bridge_target_armature', 'Target Armature', '対象アーマチュア', context)
    row = bridge_body.column(align=True)
    _prop(row, settings, 'bridge_frame_start', 'First Frame', '開始フレーム', context)
    _prop(row, settings, 'bridge_frame_end', 'Last Frame', '終了フレーム', context)
    row = bridge_body.row(align=True)
    row.operator('smart_cloth_suite.bridge_preview', text=_t('Preview', '確認', context), icon='VIEWZOOM')
    row.operator('smart_cloth_suite.bridge_bake', text=_t('Bake to Bones', 'ボーンへ焼付け', context), icon='ACTION')
    status = skirt.bridge_status(getattr(settings, 'bridge_target_armature', None))
    bridge_mode = status.state
    row = bridge_body.row(align=True)
    op = row.operator('smart_cloth_suite.bridge_mode', text=_t('Standard', '標準', context),
                      depress=bridge_mode == 'STANDARD')
    op.mode = 'STANDARD'
    op = row.operator('smart_cloth_suite.bridge_mode', text=_t('Cloth Baked', 'クロス焼付け', context),
                      depress=bridge_mode == 'CLOTH_BAKED')
    op.mode = 'CLOTH_BAKED'
    if bridge_mode == 'MIXED':
        bridge_body.label(text=_t('Bridge state: Mixed', 'ボーン焼付けの状態: 混在', context), icon='ERROR')
        bridge_body.label(text=_bridge_status_reason(status.reason, context), translate=False)
    elif bridge_mode == 'INVALID':
        bridge_body.label(text=_t('Bridge state: Invalid', 'ボーン焼付けの状態: 不正', context), icon='ERROR')
        bridge_body.label(text=_bridge_status_reason(status.reason, context), translate=False)
    elif bridge_mode == 'ABSENT':
        bridge_body.label(text=_t('Bridge state: Absent', 'ボーン焼付けの状態: なし', context))
    elif bridge_mode not in ('STANDARD', 'CLOTH_BAKED'):
        bridge_body.label(text=_t('Bridge state: Unknown', 'ボーン焼付けの状態: 不明', context), icon='ERROR')
    bridge_body.operator('smart_cloth_suite.bridge_clear', text=_t('Clear Bone Bake', 'ボーン焼付けを解除', context), icon='TRASH')


def _draw_simply_adoption(layout, settings, context) -> None:
    """Simply Cloth Studio as the primary cloth: state line and two actions."""
    garment = skirt.adoption_target(settings, context)
    state = skirt.adoption_state(garment)
    kind = {'SIMPLY': _t('Simply primary', 'Simply 主体', context),
            'OWN': _t('own cloth', '自前クロス', context),
            'NONE': _t('none', '無し', context)}.get(state['kind'], '-')
    switch = state['switch'] or _t('none (Bones / Cloth buttons)', 'なし（ボーン／クロスのボタン）', context)
    box = layout.box()
    box.label(text=_t('Cloth: %(kind)s', 'クロス: %(kind)s', context) % {'kind': kind}, icon='MOD_CLOTH', translate=False)
    box.label(text=_t('Switch: %(switch)s', '切替: %(switch)s', context) % {'switch': switch}, translate=False)
    row = box.column(align=True)
    row.operator('smart_cloth_suite.skirt_adopt_simply',
                 text=_t('Move Cloth to Simply', 'Simply に載せ替え', context), icon='MOD_CLOTH')
    row.operator('smart_cloth_suite.skirt_adopt_simply_revert',
                 text=_t('Restore Original Cloth', '元のクロスに戻す', context), icon='LOOP_BACK')
    box.operator('smart_cloth_suite.skirt_bake_check',
                 text=_t('Bake and Check Intersections', '焼きと交差の確認', context), icon='PHYSICS')


def draw_skirt(layout, context) -> None:
    settings = _settings(context)
    if settings is None:
        return
    header, body = layout.panel_prop(settings, 'ui_skirt_mapping')
    header.label(text=_t('Reusable Skirt Setup', '再利用可能なスカート設定', context),
                 icon='MOD_CLOTH')
    if body is None:
        return
    _prop(body, settings, 'skirt_garment', 'Garment Mesh', '衣装メッシュ', context)
    _prop(body, settings, 'skirt_armature', 'Armature', 'アーマチュア', context)
    _prop(body, settings, 'skirt_bones', 'Skirt Bone Names', 'スカート骨名（カンマ区切り）', context)
    _prop(body, settings, 'skirt_leg_bones', 'Leg Bone Names', '脚骨名（カンマ区切り）', context)
    _prop(body, settings, 'skirt_collider_collection', 'Collider Collection', '衝突対象コレクション', context)
    _prop(body, settings, 'skirt_outside_offset', 'Outside Offset', '外側補正距離', context)
    _prop(body, settings, 'skirt_setup_route', 'Cloth Setup Route', 'クロス設定経路', context)
    row = body.column(align=True)
    row.operator('smart_cloth_suite.skirt_preview', text=_t('Preview Mapping', '割当てを確認', context), icon='VIEWZOOM')
    row.operator('smart_cloth_suite.skirt_setup', text=_t('Apply Setup', '設定を適用', context), icon='MOD_CLOTH')
    row = body.column(align=True)
    row.operator('smart_cloth_suite.skirt_audit', text=_t('Configuration Consistency', '設定整合', context), icon='CHECKMARK')
    row.operator('smart_cloth_suite.skirt_save', text=_t('Save Mapping', '割当てを保存', context), icon='FILE_TICK')
    body.operator('smart_cloth_suite.skirt_outside', text=_t('Outside Correction', '外側補正', context), icon='MOD_SHRINKWRAP')
    mapping = skirt.resolve_mapping(settings, context)
    obj = mapping['garment']
    mode = ''
    if obj is not None and obj.type == 'MESH':
        profile = skirt.read_profile(obj)
        if profile.get('adopted') == skirt.ROUTE_ADOPTED:
            mode = skirt.adopted_mode(obj)
        elif skirt.profile_schema(profile) == 3:
            mode = skirt.current_mode(obj)
    row = body.row(align=True)
    op = row.operator('smart_cloth_suite.skirt_mode', text=_t('Bones', 'ボーン', context),
                      icon='ARMATURE_DATA', depress=mode == skirt.MODE_BONE)
    op.mode = 'BONE'
    op = row.operator('smart_cloth_suite.skirt_mode', text=_t('Cloth', 'クロス', context),
                      icon='MOD_CLOTH', depress=mode == skirt.MODE_CLOTH)
    op.mode = 'CLOTH'
    if obj is not None and obj.type == 'MESH':
        body.label(text=_t('%(name)s is driven by %(mode)s.', '%(name)s は %(mode)s 駆動です。', context) % {
            'name': obj.name,
            'mode': (_t('cloth', 'クロス', context) if mode == skirt.MODE_CLOTH
                     else _t('bones', 'ボーン', context))}, translate=False)
    _draw_simply_adoption(body, settings, context)
    component_header, component_body = body.panel_prop(settings, 'ui_skirt_component')
    component_header.label(text=_t('Fabric / Retained Trim', '布部分 / 保持する帯・装飾', context),
                           icon='MATERIAL')
    if component_body is not None:
        _prop(component_body, settings, 'component_source', 'Fabric Selection', '布の選択方法', context)
        if settings.component_source == 'MATERIAL':
            _prop(component_body, settings, 'component_material_slot', 'Fabric Material Slot', '布の材質スロット', context)
        else:
            _prop(component_body, settings, 'component_fabric_group', 'Fabric Vertex Group', '布の頂点グループ', context)
            _prop(component_body, settings, 'component_group_threshold', 'Selection Weight', '選択ウェイト', context)
        _prop(component_body, settings, 'component_support_armature', 'Support Armature', '支持アーマチュア', context)
        _prop(component_body, settings, 'component_support_bone', 'Support Bone', '支持ボーン', context)
        _prop(component_body, settings, 'component_pin_group', 'Pin Vertex Group', '固定頂点グループ', context)
        if not settings.component_pin_group:
            _prop(component_body, settings, 'component_pin_band', 'Pin Height Fraction', '上端固定の高さ割合', context)
        _prop(component_body, settings, 'component_total_mass_kg', 'Simulated Fabric Mass (kg)', '布の総重量 (kg)', context)
        _prop(component_body, settings, 'component_tension', 'Fabric Tension', '布の引張剛性', context)
        _prop(component_body, settings, 'component_bending', 'Fabric Bending', '布の曲げ剛性', context)
        row = component_body.column(align=True)
        row.operator('smart_cloth_suite.component_preview', text=_t('Preview Fabric', '布部分を確認', context), icon='VIEWZOOM')
        row.operator('smart_cloth_suite.component_apply', text=_t('Create Cloth Simulation', '布シミュレーションを作成', context), icon='MOD_CLOTH')
        component_body.operator('smart_cloth_suite.component_audit', text=_t('Configuration Consistency', '設定整合', context), icon='CHECKMARK')
        row = component_body.row(align=True)
        op = row.operator('smart_cloth_suite.component_mode', text=_t('Bones', 'ボーン', context), icon='ARMATURE_DATA')
        op.mode = 'BONE'
        op = row.operator('smart_cloth_suite.component_mode', text=_t('Cloth', 'クロス', context), icon='MOD_CLOTH')
        op.mode = 'CLOTH'
        component_body.operator('smart_cloth_suite.component_cleanup', text=_t('Remove Cloth Simulation', '布シミュレーションを解除', context), icon='TRASH')
        _draw_cloth_bone_bridge(component_body, settings, context)

_SECTION_DRAWERS = {
    'integration': draw_integration,
    'workflow': draw_workflow,
    'performance': draw_performance,
    'precision': draw_precision,
    'skirt': draw_skirt,
    'analysis': draw_analysis,
    'output': draw_output,
}



def draw_section(layout, context, section_key: str) -> None:
    drawer = _SECTION_DRAWERS.get(str(section_key or '').strip().lower())
    if drawer is not None:
        drawer(layout, context)


def draw_all(layout, context) -> None:
    for key in ('integration', 'workflow', 'performance', 'precision', 'skirt', 'analysis', 'output'):
        draw_section(layout, context, key)
