"""Use Blender rigid bodies, named durable presets and an optional managed menu key."""
from pathlib import Path
import bpy,json
from . import persistence
KEYMAP=None
ATTR=('type','mass','kinematic','collision_shape','mesh_source','friction','restitution','linear_damping','angular_damping','use_deactivation','use_start_deactivated','deactivate_linear_velocity','deactivate_angular_velocity','use_margin','collision_margin','enabled')
def bodies(ctx):return [o for o in ctx.selected_objects if o.type=='MESH']
def ensure(ctx,kind):
    objects=bodies(ctx)
    if not objects:raise ValueError('Select at least one mesh.')
    for obj in objects:
        if obj.rigid_body is None:
            with ctx.temp_override(object=obj,active_object=obj,selected_objects=[obj],selected_editable_objects=[obj]):
                if bpy.ops.rigidbody.object_add(type=kind)!={'FINISHED'}:raise ValueError(obj.name)
        else:obj.rigid_body.type=kind
def presets(s):
    return {p.name:p for p in s.rigid_body_presets}
def capture(rb):return {k:getattr(rb,k) for k in ATTR if hasattr(rb,k)}
def settings_path():return persistence.folder()/'rigid_body_presets.json'
def stored():
    try:return json.loads(settings_path().read_text('utf8'))
    except (OSError,ValueError):return {}
def sync(scene):
    existing=presets(scene)
    for name,value in stored().items():
        if name in existing or not isinstance(value,dict):continue
        item=scene.rigid_body_presets.add();item.name=name;item.settings_json=json.dumps(value)
def execute(key,op,ctx):
    s=ctx.scene;rb=getattr(ctx.object,'rigid_body',None)
    if key in ('add_active_rigid_body','add_passive_rigid_body'):ensure(ctx,'ACTIVE' if 'active' in key else 'PASSIVE');return
    if key=='apply_shortcut_key':update_shortcut(s);return
    if key=='toggle_animated':
        targets=[obj.rigid_body for obj in bodies(ctx) if obj.rigid_body]
        if not targets:raise ValueError('Select an object with a rigid body.')
        target=not (rb or targets[-1]).kinematic
        for body in targets:body.kinematic=target
        return
    sync(s);name=op.preset_name.strip()
    if not name:raise ValueError('Give the preset a name.')
    table=presets(s);bank=stored()
    if key=='add_rigid_body_preset':
        if rb is None:raise ValueError('The active object needs a rigid body.')
        if name in table and not op.overwrite:raise ValueError('This preset already exists.')
        val=capture(rb);world=s.rigidbody_world
        val['simulation']=dict(use_gravity=s.use_gravity,gravity=list(s.gravity),time_scale=world.time_scale,solver_iterations=world.solver_iterations,use_split_impulse=world.use_split_impulse) if world else {}
        item=table.get(name) or s.rigid_body_presets.add();item.name=name;item.settings_json=json.dumps(val);bank[name]=val
    elif key=='delete_rigid_body_preset':
        if name not in table:raise ValueError('Unknown preset.')
        s.rigid_body_presets.remove(s.rigid_body_presets.find(name));bank.pop(name,None)
    else:
        if name not in table:raise ValueError('Unknown preset.')
        values=json.loads(table[name].settings_json)
        for obj in bodies(ctx):
            if obj.rigid_body:
                for k in ATTR:
                    if k in values:setattr(obj.rigid_body,k,values[k])
        simulation=values.get('simulation',{})
        for k in ('use_gravity','gravity','time_scale','solver_iterations','use_split_impulse'):
            target=s if k in ('use_gravity','gravity') else s.rigidbody_world
            if target and k in simulation:setattr(target,k,simulation[k])
        return
    persistence.atomic(settings_path(),bank)
def clear_shortcut():
    global KEYMAP
    if KEYMAP:
        km,it=KEYMAP
        try:km.keymap_items.remove(it)
        except (ReferenceError,RuntimeError):pass
        KEYMAP=None
def update_shortcut(scene):
    global KEYMAP
    clear_shortcut();cfg=scene.quick_rigid_settings;wm=bpy.context.window_manager
    if cfg.enable_floating_menu and wm.keyconfigs.addon:
        km=wm.keyconfigs.addon.keymaps.new(name='3D View',space_type='VIEW_3D')
        it=km.keymap_items.new('wm.call_menu',cfg.shortcut_key,'PRESS',ctrl=cfg.use_ctrl,alt=cfg.use_alt,shift=cfg.use_shift);it.properties.name='VIEW3D_MT_quick_rigid';KEYMAP=(km,it)
