"""Serialize Blender driver relationships using RNA paths and the original ID datablocks."""
import bpy
TARGET_FIELDS=('data_path','bone_target','transform_type','transform_space','rotation_mode','context_property','use_fallback_value','fallback_value')
def inventory(owner,mod):
    prefix=mod.path_from_id();out=[]
    for curve in owner.animation_data.drivers if owner.animation_data else ():
        if not curve.data_path.startswith(prefix+'.'):continue
        d=curve.driver;row=dict(suffix=curve.data_path[len(prefix):],index=curve.array_index,type=d.type,expression=d.expression,use_self=d.use_self,mute=curve.mute,variables=[])
        for v in d.variables:
            variable=dict(name=v.name,type=v.type,targets=[]);row['variables'].append(variable)
            for t in v.targets:
                values={k:getattr(t,k)for k in TARGET_FIELDS if hasattr(t,k)};values.update(id_type=t.id_type,id=t.id.name if t.id else '',library=t.id.library.filepath if t.id and t.id.library else '');variable['targets'].append(values)
        out.append(row)
    return out
def resolve(spec):
    if not spec.get('id'):return None
    group={'OBJECT':'objects','SCENE':'scenes','KEY':'shape_keys','ARMATURE':'armatures','MATERIAL':'materials','WORLD':'worlds','NODETREE':'node_groups','MESH':'meshes','COLLECTION':'collections','ACTION':'actions','CAMERA':'cameras','LIGHT':'lights','CURVE':'curves','TEXTURE':'textures','IMAGE':'images','LATTICE':'lattices','SOUND':'sounds','SPEAKER':'speakers','VOLUME':'volumes','WORKSPACE':'workspaces','PARTICLE':'particles'}.get(spec['id_type'])
    if group:
        lib=spec.get('library','');target=next((item for item in getattr(bpy.data,group) if item.name==spec['id'] and (not lib or item.library and item.library.filepath==lib)),None)
        if target:return target
    raise ValueError('Driver target is unavailable: '+spec['id'])
def validate(records):
    for row in records:
        if not row['suffix'].startswith('.') or '..' in row['suffix']:raise ValueError('Invalid driver property path.')
        for v in row['variables']:
            for t in v['targets']:resolve(t)
def detach(owner,mod,records):
    prefix=mod.path_from_id()
    for row in records:
        path=prefix+row['suffix']
        try:owner.driver_remove(path,row['index'])
        except (TypeError,RuntimeError):owner.driver_remove(path)
def restore(owner,mod,records):
    validate(records);prefix=mod.path_from_id()
    for row in records:
        path=prefix+row['suffix']
        try:curve=owner.driver_add(path,row['index'])
        except (TypeError,RuntimeError):curve=owner.driver_add(path)
        if isinstance(curve,list):curve=curve[row['index']]
        drv=curve.driver;drv.type=row['type'];drv.use_self=row.get('use_self',False)
        for v in list(drv.variables):drv.variables.remove(v)
        for spec in row['variables']:
            v=drv.variables.new();v.type=spec['type'];v.name=spec['name']
            for target,settings in zip(v.targets,spec['targets']):
                if not target.is_property_readonly('id_type'):target.id_type=settings['id_type']
                if settings.get('id'):target.id=resolve(settings)
                for k in TARGET_FIELDS:
                    if k in settings and hasattr(target,k) and not target.is_property_readonly(k):setattr(target,k,settings[k])
        if drv.type=='SCRIPTED':drv.expression=row['expression']
        curve.mute=row.get('mute',False)
