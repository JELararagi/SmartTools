import bpy
from . import properties,actions,ui

class ANIM_OT_jiggle_clear_keyframes(actions.Command,bpy.types.Operator):
    bl_idname='anim.jiggle_clear_keyframes'
    bl_label='Clear Parameter Keyframes'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('anim.jiggle_clear_keyframes')

class ARMATURE_OT_add_jigglebone_preset(actions.Command,bpy.types.Operator):
    bl_idname='armature.add_jigglebone_preset'
    bl_label='Add/Remove Jiggle Bone preset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.add_jigglebone_preset')

class ARMATURE_OT_jiggle_bake(actions.Command,bpy.types.Operator):
    bl_idname='armature.jiggle_bake'
    bl_label='Bake Jiggle'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.jiggle_bake')
    clear_only: bpy.props.BoolProperty(name='Restore original motion',default=False,options={'SKIP_SAVE'})
    def modal(self,context,event):
        from . import jiggle
        return jiggle.job_event(self,context,event)
    def cancel(self,context):
        from . import jiggle
        if jiggle.pending and jiggle.pending['operator']==self.as_pointer():jiggle.cancel_job()

class ARMATURE_OT_jiggle_bone_connected_disable(actions.Command,bpy.types.Operator):
    bl_idname='armature.jiggle_bone_connected_disable'
    bl_label='Disconnect Selected Bones'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.jiggle_bone_connected_disable')

class ARMATURE_OT_jiggle_bone_constraints_disable(actions.Command,bpy.types.Operator):
    bl_idname='armature.jiggle_bone_constraints_disable'
    bl_label='Disable Constraints'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.jiggle_bone_constraints_disable')

class ARMATURE_OT_jiggle_copy(actions.Command,bpy.types.Operator):
    bl_idname='armature.jiggle_copy'
    bl_label='Copy Settings to Selected'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.jiggle_copy')

class ARMATURE_OT_jiggle_select(actions.Command,bpy.types.Operator):
    bl_idname='armature.jiggle_select'
    bl_label='Select Enabled'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('armature.jiggle_select')

class OBJECT_OT_add_active_rigid_body(actions.Command,bpy.types.Operator):
    bl_idname='object.add_active_rigid_body'
    bl_label='Add Active Rigid Body'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('object.add_active_rigid_body')

class OBJECT_OT_add_passive_rigid_body(actions.Command,bpy.types.Operator):
    bl_idname='object.add_passive_rigid_body'
    bl_label='Add Passive Rigid Body'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('object.add_passive_rigid_body')

class OBJECT_OT_add_rigid_body_preset(actions.Command,bpy.types.Operator):
    bl_idname='object.add_rigid_body_preset'
    bl_label='Add Rigid Body Preset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('object.add_rigid_body_preset')

class OBJECT_OT_apply_rigid_body_preset(actions.Command,bpy.types.Operator):
    bl_idname='object.apply_rigid_body_preset'
    bl_label='Apply Rigid Body Preset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('object.apply_rigid_body_preset')

class OBJECT_OT_delete_rigid_body_preset(actions.Command,bpy.types.Operator):
    bl_idname='object.delete_rigid_body_preset'
    bl_label='Delete Rigid Body Preset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('object.delete_rigid_body_preset')

class QUICK_RIGID_OT_apply_shortcut_key(actions.Command,bpy.types.Operator):
    bl_idname='quick_rigid.apply_shortcut_key'
    bl_label='Copy Manual Shortcut Registration'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('quick_rigid.apply_shortcut_key')

class RIGID_BODY_OT_toggle_animated(actions.Command,bpy.types.Operator):
    bl_idname='rigid_body.toggle_animated'
    bl_label='Toggle Animated State'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('rigid_body.toggle_animated')

class SCENE_OT_jiggle_profile(actions.Command,bpy.types.Operator):
    bl_idname='scene.jiggle_profile'
    bl_label='Print Profiling Information to Console'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('scene.jiggle_profile')

class SCENE_OT_jiggle_reset(actions.Command,bpy.types.Operator):
    bl_idname='scene.jiggle_reset'
    bl_label='Reset Physics'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('scene.jiggle_reset')

class SMART_CLOTH_SUITE_OT_apply_colliders(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.apply_colliders'
    bl_label='Apply External Collider Setup'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.apply_colliders')

class SMART_CLOTH_SUITE_OT_apply_quality_profile(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.apply_quality_profile'
    bl_label='Apply Quality Profile'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.apply_quality_profile')

class SMART_CLOTH_SUITE_OT_auto_collision_distance(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.auto_collision_distance'
    bl_label='Auto Collision Distance'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.auto_collision_distance')

class SMART_CLOTH_SUITE_OT_batch_preview(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.batch_preview'
    bl_label='Batch Preview State'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.batch_preview')

class SMART_CLOTH_SUITE_OT_bridge_bake(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.bridge_bake'
    bl_label='Bake Cloth to Garment Bones'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.bridge_bake')

class SMART_CLOTH_SUITE_OT_bridge_clear(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.bridge_clear'
    bl_label='Clear Owned Cloth-Bone Bake'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.bridge_clear')

class SMART_CLOTH_SUITE_OT_bridge_mode(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.bridge_mode'
    bl_label='Switch Cloth-Bone Output'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.bridge_mode')

class SMART_CLOTH_SUITE_OT_bridge_preview(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.bridge_preview'
    bl_label='Preview Cloth-to-Bone Sampling'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.bridge_preview')

class SMART_CLOTH_SUITE_OT_build_analysis_maps(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.build_analysis_maps'
    bl_label='Build Analysis Maps'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.build_analysis_maps')

class SMART_CLOTH_SUITE_OT_component_apply(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.component_apply'
    bl_label='Create Fabric Component'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.component_apply')

class SMART_CLOTH_SUITE_OT_component_audit(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.component_audit'
    bl_label='Fabric Configuration Consistency'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.component_audit')

class SMART_CLOTH_SUITE_OT_component_cleanup(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.component_cleanup'
    bl_label='Remove Owned Fabric Helpers'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.component_cleanup')

class SMART_CLOTH_SUITE_OT_component_mode(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.component_mode'
    bl_label='Switch Fabric Component'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.component_mode')

class SMART_CLOTH_SUITE_OT_component_preview(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.component_preview'
    bl_label='Preview Fabric Component'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.component_preview')

class SMART_CLOTH_SUITE_OT_layer_clearance(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.layer_clearance'
    bl_label='Apply Layer Clearance'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.layer_clearance')

class SMART_CLOTH_SUITE_OT_open_data_folder(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.open_data_folder'
    bl_label='Open Smart Cloth Suite Folder'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.open_data_folder')

class SMART_CLOTH_SUITE_OT_open_external_preferences(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.open_external_preferences'
    bl_label='Open External Add-on Settings'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.open_external_preferences')

class SMART_CLOTH_SUITE_OT_preflight(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.preflight'
    bl_label='Run Preflight'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.preflight')

class SMART_CLOTH_SUITE_OT_refresh_external_status(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.refresh_external_status'
    bl_label='Refresh External Tool Status'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.refresh_external_status')

class SMART_CLOTH_SUITE_OT_repair_topology(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.repair_topology'
    bl_label='Safe Topology Repair'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.repair_topology')

class SMART_CLOTH_SUITE_OT_safe_output(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.safe_output'
    bl_label='Safe Bake / Finish'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.safe_output')
    def modal(self,context,event):
        from . import output
        return output.event(self,context,event)
    def cancel(self,context):
        from . import output
        if output.active and output.active['operator']==self.as_pointer():output.close(context)

class SMART_CLOTH_SUITE_OT_skirt_adopt_simply(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_adopt_simply'
    bl_label='Move Cloth to Simply Cloth Studio'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_adopt_simply')

class SMART_CLOTH_SUITE_OT_skirt_adopt_simply_revert(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_adopt_simply_revert'
    bl_label='Restore Original Cloth'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_adopt_simply_revert')

class SMART_CLOTH_SUITE_OT_skirt_audit(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_audit'
    bl_label='Configuration Consistency'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_audit')

class SMART_CLOTH_SUITE_OT_skirt_bake_check(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_bake_check'
    bl_label='Bake and Check Intersections'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_bake_check')

class SMART_CLOTH_SUITE_OT_skirt_mode(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_mode'
    bl_label='Switch Bones / Cloth'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_mode')

class SMART_CLOTH_SUITE_OT_skirt_outside(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_outside'
    bl_label='Outside Correction'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_outside')

class SMART_CLOTH_SUITE_OT_skirt_preview(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_preview'
    bl_label='Preview Skirt Mapping'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_preview')

class SMART_CLOTH_SUITE_OT_skirt_save(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_save'
    bl_label='Save Skirt Setup'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_save')

class SMART_CLOTH_SUITE_OT_skirt_setup(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.skirt_setup'
    bl_label='Apply Skirt Mapping'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.skirt_setup')

class SMART_CLOTH_SUITE_OT_smart_setup(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.smart_setup'
    bl_label='Smart Setup'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.smart_setup')

class SMART_CLOTH_SUITE_OT_temporal_guard(actions.Command,bpy.types.Operator):
    bl_idname='smart_cloth_suite.temporal_guard'
    bl_label='Apply Temporal Guard'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_cloth_suite.temporal_guard')

class SMART_CORE_OT_copy_text(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.copy_text'
    bl_label='Copy Text'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.copy_text')

class SMART_CORE_OT_disable_all_always_on_features(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.disable_all_always_on_features'
    bl_label='Disable All Always-on Features'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.disable_all_always_on_features')

class SMART_CORE_OT_lazy_execute_tool(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.lazy_execute_tool'
    bl_label='Run Tool Command'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.lazy_execute_tool')

class SMART_CORE_OT_show_help_popup(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.show_help_popup'
    bl_label='Help'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.show_help_popup')

class SMART_CORE_OT_toggle_always_on_feature(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.toggle_always_on_feature'
    bl_label='Toggle Always-on Feature'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.toggle_always_on_feature')

class SMART_CORE_OT_toggle_jiggle_overlay_runtime(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.toggle_jiggle_overlay_runtime'
    bl_label='Toggle Jiggle Overlay'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.toggle_jiggle_overlay_runtime')

class SMART_CORE_OT_toggle_standard_npanel_tool(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.toggle_standard_npanel_tool'
    bl_label='Toggle Tool Module'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.toggle_standard_npanel_tool')

class SMART_CORE_OT_toggle_tool_panel_visibility(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.toggle_tool_panel_visibility'
    bl_label='Toggle Tool Section Visibility'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.toggle_tool_panel_visibility')

class SMART_CORE_OT_toggle_ui_section(actions.Command,bpy.types.Operator):
    bl_idname='smart_core.toggle_ui_section'
    bl_label='Toggle UI Section'
    bl_options={'REGISTER','UNDO'}
    __annotations__=properties.arguments('smart_core.toggle_ui_section')

class JIGGLE_MT_JiggleBonePresets(ui.Menu,bpy.types.Menu):
    bl_label='Jiggle Bone Presets'

class SMARTCLOTHSUITE_PT_main_panel_asset_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_asset_v283'
    bl_label='Smart Cloth'
    bl_space_type='FILE_BROWSER'
    bl_region_type='TOOL_PROPS'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_clip_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_clip_v283'
    bl_label='Smart Cloth'
    bl_space_type='CLIP_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283'
    bl_label='Smart Cloth'
    bl_space_type='DOPESHEET_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_file_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_file_v283'
    bl_label='Smart Cloth'
    bl_space_type='FILE_BROWSER'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_graph_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_graph_v283'
    bl_label='Smart Cloth'
    bl_space_type='GRAPH_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_image_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_image_v283'
    bl_label='Smart Cloth'
    bl_space_type='IMAGE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_nla_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_nla_v283'
    bl_label='Smart Cloth'
    bl_space_type='NLA_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_node_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_node_v283'
    bl_label='Smart Cloth'
    bl_space_type='NODE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_sequence_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_sequence_v283'
    bl_label='Smart Cloth'
    bl_space_type='SEQUENCE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283'
    bl_label='Smart Cloth'
    bl_space_type='SPREADSHEET'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_text_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_text_v283'
    bl_label='Smart Cloth'
    bl_space_type='TEXT_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class SMARTCLOTHSUITE_PT_main_panel_view3d_v283(ui.Sidebar,bpy.types.Panel):
    bl_idname='SMARTCLOTHSUITE_PT_main_panel_view3d_v283'
    bl_label='Smart Cloth'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Smart Cloth'

class VIEW3D_MT_quick_rigid(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid'
    bl_label='Quick Rigid'

class VIEW3D_MT_quick_rigid_bake_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_bake_submenu'
    bl_label='Bake Options'

class VIEW3D_MT_quick_rigid_collision_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_collision_submenu'
    bl_label='Collision Shape'

class VIEW3D_MT_quick_rigid_main_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_main_submenu'
    bl_label='Main Settings'

class VIEW3D_MT_quick_rigid_physics_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_physics_submenu'
    bl_label='Physical Properties'

class VIEW3D_MT_quick_rigid_presets_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_presets_submenu'
    bl_label='Presets'

class VIEW3D_MT_quick_rigid_sim_submenu(ui.Menu,bpy.types.Menu):
    bl_idname='VIEW3D_MT_quick_rigid_sim_submenu'
    bl_label='Simulation Settings'

CLASSES=(
    ANIM_OT_jiggle_clear_keyframes,
    ARMATURE_OT_add_jigglebone_preset,
    ARMATURE_OT_jiggle_bake,
    ARMATURE_OT_jiggle_bone_connected_disable,
    ARMATURE_OT_jiggle_bone_constraints_disable,
    ARMATURE_OT_jiggle_copy,
    ARMATURE_OT_jiggle_select,
    OBJECT_OT_add_active_rigid_body,
    OBJECT_OT_add_passive_rigid_body,
    OBJECT_OT_add_rigid_body_preset,
    OBJECT_OT_apply_rigid_body_preset,
    OBJECT_OT_delete_rigid_body_preset,
    QUICK_RIGID_OT_apply_shortcut_key,
    RIGID_BODY_OT_toggle_animated,
    SCENE_OT_jiggle_profile,
    SCENE_OT_jiggle_reset,
    SMART_CLOTH_SUITE_OT_apply_colliders,
    SMART_CLOTH_SUITE_OT_apply_quality_profile,
    SMART_CLOTH_SUITE_OT_auto_collision_distance,
    SMART_CLOTH_SUITE_OT_batch_preview,
    SMART_CLOTH_SUITE_OT_bridge_bake,
    SMART_CLOTH_SUITE_OT_bridge_clear,
    SMART_CLOTH_SUITE_OT_bridge_mode,
    SMART_CLOTH_SUITE_OT_bridge_preview,
    SMART_CLOTH_SUITE_OT_build_analysis_maps,
    SMART_CLOTH_SUITE_OT_component_apply,
    SMART_CLOTH_SUITE_OT_component_audit,
    SMART_CLOTH_SUITE_OT_component_cleanup,
    SMART_CLOTH_SUITE_OT_component_mode,
    SMART_CLOTH_SUITE_OT_component_preview,
    SMART_CLOTH_SUITE_OT_layer_clearance,
    SMART_CLOTH_SUITE_OT_open_data_folder,
    SMART_CLOTH_SUITE_OT_open_external_preferences,
    SMART_CLOTH_SUITE_OT_preflight,
    SMART_CLOTH_SUITE_OT_refresh_external_status,
    SMART_CLOTH_SUITE_OT_repair_topology,
    SMART_CLOTH_SUITE_OT_safe_output,
    SMART_CLOTH_SUITE_OT_skirt_adopt_simply,
    SMART_CLOTH_SUITE_OT_skirt_adopt_simply_revert,
    SMART_CLOTH_SUITE_OT_skirt_audit,
    SMART_CLOTH_SUITE_OT_skirt_bake_check,
    SMART_CLOTH_SUITE_OT_skirt_mode,
    SMART_CLOTH_SUITE_OT_skirt_outside,
    SMART_CLOTH_SUITE_OT_skirt_preview,
    SMART_CLOTH_SUITE_OT_skirt_save,
    SMART_CLOTH_SUITE_OT_skirt_setup,
    SMART_CLOTH_SUITE_OT_smart_setup,
    SMART_CLOTH_SUITE_OT_temporal_guard,
    SMART_CORE_OT_copy_text,
    SMART_CORE_OT_disable_all_always_on_features,
    SMART_CORE_OT_lazy_execute_tool,
    SMART_CORE_OT_show_help_popup,
    SMART_CORE_OT_toggle_always_on_feature,
    SMART_CORE_OT_toggle_jiggle_overlay_runtime,
    SMART_CORE_OT_toggle_standard_npanel_tool,
    SMART_CORE_OT_toggle_tool_panel_visibility,
    SMART_CORE_OT_toggle_ui_section,
    JIGGLE_MT_JiggleBonePresets,
    SMARTCLOTHSUITE_PT_main_panel_asset_v283,
    SMARTCLOTHSUITE_PT_main_panel_clip_v283,
    SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283,
    SMARTCLOTHSUITE_PT_main_panel_file_v283,
    SMARTCLOTHSUITE_PT_main_panel_graph_v283,
    SMARTCLOTHSUITE_PT_main_panel_image_v283,
    SMARTCLOTHSUITE_PT_main_panel_nla_v283,
    SMARTCLOTHSUITE_PT_main_panel_node_v283,
    SMARTCLOTHSUITE_PT_main_panel_sequence_v283,
    SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283,
    SMARTCLOTHSUITE_PT_main_panel_text_v283,
    SMARTCLOTHSUITE_PT_main_panel_view3d_v283,
    VIEW3D_MT_quick_rigid,
    VIEW3D_MT_quick_rigid_bake_submenu,
    VIEW3D_MT_quick_rigid_collision_submenu,
    VIEW3D_MT_quick_rigid_main_submenu,
    VIEW3D_MT_quick_rigid_physics_submenu,
    VIEW3D_MT_quick_rigid_presets_submenu,
    VIEW3D_MT_quick_rigid_sim_submenu,
)
