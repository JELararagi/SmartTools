# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Read-only Smart Tools Manager current-cell bridge.

The bridge binds exactly one documented public Manager rule function during the
Suite registration boundary. Fixed root ``Panel.poll`` methods only read the
immutable binding and call that public function. They never import modules,
perform file I/O, register resources, request redraws, or mutate Manager state.
"""

from __future__ import annotations

from dataclasses import dataclass
import importlib
from typing import Any, Callable

import bpy

from . import lifecycle


TOOL_KEY = "SMART_CLOTH"
LOGICAL_EDITORS = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "UV_EDITOR",
    "SHADER_EDITOR",
    "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR",
    "TEXTURE_NODE_EDITOR",
    "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR",
    "DOPE_SHEET",
    "GRAPH_EDITOR",
    "DRIVERS",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "ASSET_BROWSER",
    "FILE_BROWSER",
    "SPREADSHEET",
)
PHYSICAL_TO_LOGICAL = {
    "VIEW_3D": ("VIEW_3D",),
    "IMAGE_EDITOR": ("IMAGE_EDITOR", "UV_EDITOR"),
    "NODE_EDITOR": ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR"),
    "SEQUENCE_EDITOR": ("VIDEO_SEQUENCER",),
    "CLIP_EDITOR": ("MOVIE_CLIP_EDITOR",),
    "DOPESHEET_EDITOR": ("DOPE_SHEET",),
    "GRAPH_EDITOR": ("GRAPH_EDITOR", "DRIVERS"),
    "NLA_EDITOR": ("NLA_EDITOR",),
    "TEXT_EDITOR": ("TEXT_EDITOR",),
    "FILE_BROWSER": ("ASSET_BROWSER", "FILE_BROWSER"),
    "SPREADSHEET": ("SPREADSHEET",),
}


@dataclass(frozen=True)
class ManagerBinding:
    manager_present: bool
    manager_module: str
    public_api_name: str
    public_api: Callable[[str, Any, str], bool] | None
    suite_generation: int
    binding_generation: int


_BINDING_SERIAL = 0
_BINDING = ManagerBinding(False, "", "", None, 0, 0)


def _enabled_addon_keys(context=None) -> tuple[str, ...]:
    ctx = context or getattr(bpy, "context", None)
    try:
        addons = getattr(getattr(ctx, "preferences", None), "addons", None)
        return tuple(str(key) for key in addons.keys()) if addons is not None else ()
    except Exception:
        return ()


def _manager_addon_key(context=None) -> str:
    for key in _enabled_addon_keys(context):
        lower = key.lower()
        if lower == "smart_tools_manager" or lower.endswith(".smart_tools_manager"):
            return key
    return ""


def _suite_generation() -> int:
    lease = lifecycle.current_lease(require_current=False)
    return int(getattr(lease, "generation", 0) or 0)


def _public_rule_from_package(package: Any) -> Callable[[str, Any, str], bool] | None:
    """Return only the Manager's documented current-cell rule API."""
    for public_object in (package, getattr(package, "manager", None)):
        if public_object is None:
            continue
        fn = getattr(public_object, "panel_rule_allows_context", None)
        if callable(fn):
            return fn
    return None


def bind(context=None) -> bool:
    """Capture the public Manager rule function at a lifecycle boundary."""
    global _BINDING_SERIAL, _BINDING
    _BINDING_SERIAL += 1
    serial = _BINDING_SERIAL
    suite_generation = _suite_generation()
    addon_key = _manager_addon_key(context)
    if not addon_key:
        _BINDING = ManagerBinding(False, "", "", None, suite_generation, serial)
        return False

    try:
        package = importlib.import_module(addon_key)
        fn = _public_rule_from_package(package)
    except Exception:
        fn = None

    _BINDING = ManagerBinding(
        True,
        addon_key,
        "panel_rule_allows_context" if fn is not None else "",
        fn,
        suite_generation,
        serial,
    )
    return fn is not None


def unbind() -> None:
    global _BINDING_SERIAL, _BINDING
    _BINDING_SERIAL += 1
    _BINDING = ManagerBinding(False, "", "", None, 0, _BINDING_SERIAL)


def logical_editor_key(context=None) -> str:
    ctx = context or getattr(bpy, "context", None)
    try:
        area = getattr(ctx, "area", None)
        area_type = str(getattr(area, "type", "") or "").upper()
    except Exception:
        return ""
    try:
        space = getattr(ctx, "space_data", None)
    except Exception:
        space = None

    if area_type == "VIEW_3D":
        return "VIEW_3D"
    if area_type == "IMAGE_EDITOR":
        mode = str(getattr(space, "mode", "") or "").upper()
        return "UV_EDITOR" if mode == "UV" else "IMAGE_EDITOR"
    if area_type == "NODE_EDITOR":
        tree_type = str(getattr(space, "tree_type", "") or "")
        return {
            "ShaderNodeTree": "SHADER_EDITOR",
            "CompositorNodeTree": "COMPOSITOR",
            "GeometryNodeTree": "GEOMETRY_NODE_EDITOR",
            "TextureNodeTree": "TEXTURE_NODE_EDITOR",
        }.get(tree_type, "SHADER_EDITOR")
    if area_type == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if area_type == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if area_type == "DOPESHEET_EDITOR":
        return "DOPE_SHEET"
    if area_type == "GRAPH_EDITOR":
        return "DRIVERS" if str(getattr(space, "mode", "") or "").upper() == "DRIVERS" else "GRAPH_EDITOR"
    if area_type == "NLA_EDITOR":
        return "NLA_EDITOR"
    if area_type == "TEXT_EDITOR":
        return "TEXT_EDITOR"
    if area_type == "FILE_BROWSER":
        browse_mode = str(getattr(space, "browse_mode", "") or "").upper()
        return "ASSET_BROWSER" if browse_mode in {"ASSETS", "ASSET"} else "FILE_BROWSER"
    if area_type == "SPREADSHEET":
        return "SPREADSHEET"
    return ""


def panel_allowed(context=None, *, physical_space: str) -> bool:
    """Pure hot-path placement query used by every fixed root Panel.poll.

    The Manager is authoritative when its public current-cell API is bound.
    Manager absence, a registration hand-off, or temporary API failure is
    fail-open so an already valid Suite generation is not blanked mid-reload.
    """
    ctx = context or getattr(bpy, "context", None)
    try:
        area_type = str(getattr(getattr(ctx, "area", None), "type", "") or "").upper()
    except Exception:
        return False
    physical_space = str(physical_space or "").upper()
    logical_spaces = PHYSICAL_TO_LOGICAL.get(physical_space)
    if area_type != physical_space or logical_spaces is None:
        return False
    editor_key = logical_editor_key(ctx)
    if editor_key not in logical_spaces:
        return False

    binding = _BINDING
    if not binding.manager_present or binding.public_api is None:
        return True
    if binding.suite_generation != _suite_generation():
        return True
    try:
        return bool(binding.public_api(TOOL_KEY, context=ctx, editor_key=editor_key))
    except Exception:
        return True


def binding_snapshot() -> dict[str, Any]:
    binding = _BINDING
    return {
        "manager_present": binding.manager_present,
        "manager_module": binding.manager_module,
        "public_api": binding.public_api_name,
        "suite_generation": binding.suite_generation,
        "binding_generation": binding.binding_generation,
        "cached_result_count": 0,
    }
