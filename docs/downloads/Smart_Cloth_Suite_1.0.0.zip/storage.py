"""Compatible local path resolution for suite settings and extension user data."""
from pathlib import Path
import bpy
from . import persistence
def blender_config_dir():return Path(bpy.utils.user_resource('CONFIG'))
def smart_suite_config_dir():return blender_config_dir()/'Smart_Cloth_Suite'
def smart_suite_config_file():return smart_suite_config_dir()/persistence.NAME
def legacy_smart_suite_config_file():return blender_config_dir()/persistence.NAME
def user_data_dir(*parts,create=True):
    p=Path(__file__).resolve().parent/'user_data'
    path=p.joinpath(*map(str,parts))
    if create:path.mkdir(parents=True,exist_ok=True)
    return path
def settings_dir(*parts,create=True):return user_data_dir('settings',*parts,create=create)
def addon_data_dir(*parts,create=True):return user_data_dir('data',*parts,create=create)
def runtime_dir(*parts,create=True,package=None):return user_data_dir('runtime',*parts,create=create)
def settings_file(name,*,create=True):return settings_dir(create=create)/name
def runtime_file(filename,*subdirs,create=True,package=None):return runtime_dir(*subdirs,create=create)/filename
def addon_storage_path(filename,*subdirs,package_id=None,create=True):return addon_data_dir(*subdirs,create=create)/filename
def storage_path(filename,*parts,create=True):return addon_storage_path(filename,*parts,create=create)
def read_json(path,default=None):
    try:return persistence.read(Path(path),default)
    except (ValueError,OSError):return default
def atomic_write_json(path,data,**options):persistence.atomic(Path(path),data)
