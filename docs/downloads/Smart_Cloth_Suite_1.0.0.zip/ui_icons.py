# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Compatibility icon API.

The external-companion package uses Blender standard icons exclusively.  A
small no-op API is retained because the startup-safe runtime calls it through a
stable compatibility hook.
"""

from __future__ import annotations


def load_icons():
    return None


def get_icon_id(_icon_name: str) -> int:
    return 0


def unload_icons() -> None:
    return None
