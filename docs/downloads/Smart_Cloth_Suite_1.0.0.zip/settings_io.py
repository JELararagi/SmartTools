# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Strict UTF-8 JSON persistence with verified atomic replacement.

Current Smart Cloth Suite documents require an exact schema identifier,
non-duplicated keys, finite JSON numbers, and type-correct known sections.
Writes use a unique sibling temporary file, file and directory synchronization,
atomic replacement, semantic readback verification, and a verified backup.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import uuid
from typing import Any, Callable


DOCUMENT_SCHEMA = "jelararagi.smart_cloth.settings.v3"
MAX_DOCUMENT_BYTES = 8 * 1024 * 1024
_ALLOWED_TOP_LEVEL = frozenset({
    "schema",
    "version",
    "file",
    "runtime_preferences",
    "ui_sections",
    "always_on_toggles",
    "tool_visibility",
    "storage_settings",
    "scene_settings",
})
_MAPPING_SECTIONS = frozenset({
    "runtime_preferences",
    "ui_sections",
    "always_on_toggles",
    "tool_visibility",
    "storage_settings",
    "scene_settings",
})
_SCENE_ROOTS = frozenset({"smart_cloth_suite_companion", "quick_rigid_settings", "jiggle"})

_RUNTIME_BOOL_KEYS = frozenset({
    "show_tool_controls",
    "show_always_on_toggles",
    "show_displayed_tool_modules",
    "show_quick_rigid_tools",
    "show_jiggle_physics_tools",
    "always_suite_npanel_persistence",
    "always_jiggle_runtime_callbacks",
    "always_jiggle_overlay_rest_pose",
    "always_jiggle_overlay_simulation",
    "auto_create_result_collection",
    "ui_open_scs_external",
    "ui_open_scs_workflow",
    "ui_open_scs_performance",
    "ui_open_scs_precision",
    "ui_open_scs_analysis",
    "ui_open_scs_output",
    "ui_open_tool_quick_rigid",
    "ui_open_tool_jiggle_physics",
    "ui_open_quick_rigid_all_commands",
    "ui_open_jiggle_all_commands",
    "ui_open_quick_rigid_menu",
    "ui_open_quick_rigid_setup",
    "ui_open_quick_rigid_active_body",
    "ui_open_quick_rigid_presets",
    "ui_open_jiggle_scene",
    "ui_open_jiggle_utilities",
    "ui_open_jiggle_armature",
    "ui_open_jiggle_bone",
    "legacy_storage_migrated",
})
_RUNTIME_STRING_KEYS = frozenset({"storage_mode", "custom_storage_dir", "result_collection_name"})
_UI_SECTION_KEYS = frozenset(key for key in _RUNTIME_BOOL_KEYS if key.startswith("ui_open_"))
_ALWAYS_ON_KEYS = frozenset(key for key in _RUNTIME_BOOL_KEYS if key.startswith("always_"))
_TOOL_VISIBILITY_KEYS = frozenset({
    "show_tool_controls",
    "show_always_on_toggles",
    "show_displayed_tool_modules",
    "show_quick_rigid_tools",
    "show_jiggle_physics_tools",
})
_STORAGE_TYPES = {
    "storage_mode": str,
    "custom_storage_dir": str,
    "result_collection_name": str,
    "auto_create_result_collection": bool,
}
_STORAGE_MODES = frozenset({"USER_DEFAULT", "BLEND_RELATIVE", "CUSTOM"})
_MAX_SCENE_PROPERTIES_PER_ROOT = 4096
_MAX_SCENE_ARRAY_ITEMS = 256
_POINTER_KEYS = frozenset({"__pointer__", "name"})

_DIRTY = False
_LAST_ERROR = ""


@dataclass(frozen=True)
class ReadResult:
    status: str
    document: dict[str, Any] | None
    source: str
    error: str = ""


def backup_path(path: str | Path) -> Path:
    target = Path(path)
    return target.with_name(target.name + ".bak")


def _set_failure(error: BaseException | str) -> None:
    global _DIRTY, _LAST_ERROR
    _DIRTY = True
    _LAST_ERROR = str(error)


def mark_clean() -> None:
    global _DIRTY, _LAST_ERROR
    _DIRTY = False
    _LAST_ERROR = ""


def mark_dirty() -> None:
    global _DIRTY
    _DIRTY = True


def dirty() -> bool:
    return bool(_DIRTY)


def last_error() -> str:
    return str(_LAST_ERROR)


def _reject_constant(value: str) -> None:
    raise ValueError(f"Non-finite JSON constant is not allowed: {value}")


def _object_without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key is not allowed: {key}")
        result[key] = value
    return result


def _validate_json_value(value: Any, *, path: str = "$") -> None:
    if value is None or type(value) in {bool, int, str}:
        return
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError(f"Non-finite number at {path}")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _validate_json_value(item, path=f"{path}[{index}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"Non-string key at {path}")
            _validate_json_value(item, path=f"{path}.{key}")
        return
    raise TypeError(f"Unsupported JSON value type at {path}: {type(value).__name__}")


def _require_exact_keys(values: dict[str, Any], allowed: frozenset[str], section: str) -> None:
    unknown = set(values).difference(allowed)
    if unknown:
        raise ValueError(f"Unknown {section} keys: {', '.join(sorted(unknown))}")


def _validate_bool_mapping(values: dict[str, Any], allowed: frozenset[str], section: str) -> None:
    _require_exact_keys(values, allowed, section)
    for key, value in values.items():
        if type(key) is not str or type(value) is not bool:
            raise TypeError(f"{section}.{key} must be a boolean")


def _validate_scene_property(value: Any, *, path: str) -> None:
    if value is None or type(value) in {bool, int, str}:
        return
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError(f"Non-finite number at {path}")
        return
    if isinstance(value, list):
        if len(value) > _MAX_SCENE_ARRAY_ITEMS:
            raise ValueError(f"Scene settings array is too large at {path}")
        for index, item in enumerate(value):
            if type(item) not in {bool, int, float, str}:
                raise TypeError(f"Unsupported scene settings array item at {path}[{index}]")
            if type(item) is float and not math.isfinite(item):
                raise ValueError(f"Non-finite number at {path}[{index}]")
        return
    if isinstance(value, dict):
        if set(value) != _POINTER_KEYS:
            raise ValueError(f"Scene pointer value has an invalid schema at {path}")
        if type(value.get("__pointer__")) is not str or type(value.get("name")) is not str:
            raise TypeError(f"Scene pointer value must contain string fields at {path}")
        return
    raise TypeError(f"Unsupported scene settings value at {path}: {type(value).__name__}")


def validate_document(document: dict[str, Any], *, require_schema: bool = True) -> None:
    if not isinstance(document, dict):
        raise TypeError("Smart Cloth settings root must be a JSON object")
    unknown = set(document).difference(_ALLOWED_TOP_LEVEL)
    if unknown:
        raise ValueError(f"Unknown Smart Cloth settings keys: {', '.join(sorted(unknown))}")
    schema = document.get("schema")
    if require_schema and schema != DOCUMENT_SCHEMA:
        raise ValueError("Smart Cloth settings schema is missing or unsupported")
    if schema is not None and schema != DOCUMENT_SCHEMA:
        raise ValueError("Smart Cloth settings schema is unsupported")
    if "version" in document and type(document["version"]) is not int:
        raise TypeError("Smart Cloth settings version must be an integer")
    if "file" in document and type(document["file"]) is not str:
        raise TypeError("Smart Cloth settings file marker must be a string")
    for section in _MAPPING_SECTIONS:
        if section in document and not isinstance(document[section], dict):
            raise TypeError(f"Smart Cloth settings section must be an object: {section}")

    runtime = document.get("runtime_preferences", {})
    if isinstance(runtime, dict):
        _require_exact_keys(runtime, _RUNTIME_BOOL_KEYS | _RUNTIME_STRING_KEYS, "runtime_preferences")
        for key, value in runtime.items():
            if key in _RUNTIME_BOOL_KEYS and type(value) is not bool:
                raise TypeError(f"runtime_preferences.{key} must be a boolean")
            if key in _RUNTIME_STRING_KEYS and type(value) is not str:
                raise TypeError(f"runtime_preferences.{key} must be a string")
        storage_mode = runtime.get("storage_mode")
        if storage_mode is not None and storage_mode not in _STORAGE_MODES:
            raise ValueError("runtime_preferences.storage_mode is unsupported")

    ui_sections = document.get("ui_sections", {})
    if isinstance(ui_sections, dict):
        _validate_bool_mapping(ui_sections, _UI_SECTION_KEYS, "ui_sections")
    always_on = document.get("always_on_toggles", {})
    if isinstance(always_on, dict):
        _validate_bool_mapping(always_on, _ALWAYS_ON_KEYS, "always_on_toggles")
    tool_visibility = document.get("tool_visibility", {})
    if isinstance(tool_visibility, dict):
        _validate_bool_mapping(tool_visibility, _TOOL_VISIBILITY_KEYS, "tool_visibility")

    storage = document.get("storage_settings", {})
    if isinstance(storage, dict):
        _require_exact_keys(storage, frozenset(_STORAGE_TYPES), "storage_settings")
        for key, value in storage.items():
            expected = _STORAGE_TYPES[key]
            if type(value) is not expected:
                raise TypeError(f"storage_settings.{key} has an invalid type")
        storage_mode = storage.get("storage_mode")
        if storage_mode is not None and storage_mode not in _STORAGE_MODES:
            raise ValueError("storage_settings.storage_mode is unsupported")

    scene_settings = document.get("scene_settings", {})
    if isinstance(scene_settings, dict):
        unknown_roots = set(scene_settings).difference(_SCENE_ROOTS)
        if unknown_roots:
            raise ValueError(f"Unknown scene settings roots: {', '.join(sorted(unknown_roots))}")
        for root, values in scene_settings.items():
            if root not in _SCENE_ROOTS or not isinstance(values, dict):
                raise TypeError("scene_settings entries must be known objects")
            if len(values) > _MAX_SCENE_PROPERTIES_PER_ROOT:
                raise ValueError(f"Too many properties in scene_settings.{root}")
            for key, value in values.items():
                if type(key) is not str or not key:
                    raise TypeError(f"Invalid scene settings property key in {root}")
                _validate_scene_property(value, path=f"$.scene_settings.{root}.{key}")
    _validate_json_value(document)


def _decode_json(raw: bytes) -> Any:
    if len(raw) > MAX_DOCUMENT_BYTES:
        raise ValueError("Smart Cloth settings file exceeds the size limit")
    text = raw.decode("utf-8", errors="strict")
    return json.loads(
        text,
        object_pairs_hook=_object_without_duplicates,
        parse_constant=_reject_constant,
    )


def _decode_document(raw: bytes, *, require_schema: bool = True) -> dict[str, Any]:
    value = _decode_json(raw)
    if not isinstance(value, dict):
        raise TypeError("Smart Cloth settings root must be a JSON object")
    validate_document(value, require_schema=require_schema)
    return value


def _read_one(path: Path, *, require_schema: bool = True) -> dict[str, Any]:
    return _decode_document(path.read_bytes(), require_schema=require_schema)


def read_legacy_document(path: str | Path) -> ReadResult:
    """Read a migration-only legacy JSON object without accepting it as current."""
    target = Path(path)
    if not target.exists():
        return ReadResult("MISSING", None, str(target))
    try:
        value = _decode_json(target.read_bytes())
        if not isinstance(value, dict):
            raise TypeError("Legacy Smart Cloth settings root must be a JSON object")
        _validate_json_value(value)
        return ReadResult("LEGACY", value, str(target))
    except Exception as exc:
        _set_failure(exc)
        return ReadResult("CORRUPT", None, str(target), str(exc))


def _fsync_directory(path: Path) -> None:
    flags = getattr(os, "O_DIRECTORY", 0) | os.O_RDONLY
    try:
        fd = os.open(str(path), flags)
    except OSError:
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _unique_tmp(target: Path, label: str) -> Path:
    return target.with_name(f".{target.name}.{label}.{os.getpid()}.{uuid.uuid4().hex}.tmp")


def _write_unique_file(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def _replace_verified(target: Path, data: bytes) -> None:
    tmp = _unique_tmp(target, "write")
    try:
        _write_unique_file(tmp, data)
        os.replace(tmp, target)
        _fsync_directory(target.parent)
        readback = target.read_bytes()
        if readback != data:
            raise OSError("Atomic settings readback did not match written bytes")
        _decode_document(readback, require_schema=True)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass


def _create_verified_backup(target: Path, backup: Path) -> None:
    current = target.read_bytes()
    _decode_document(current, require_schema=True)
    tmp = _unique_tmp(backup, "backup")
    try:
        _write_unique_file(tmp, current)
        os.replace(tmp, backup)
        _fsync_directory(backup.parent)
        readback = backup.read_bytes()
        if readback != current:
            raise OSError("Settings backup readback mismatch")
        _decode_document(readback, require_schema=True)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass


def recover_backup(path: str | Path) -> ReadResult:
    target = Path(path)
    backup = backup_path(target)
    try:
        document = _read_one(backup, require_schema=True)
        raw = serialize_document(document)
        _replace_verified(target, raw)
        mark_clean()
        return ReadResult("RECOVERED", document, str(backup))
    except Exception as exc:
        _set_failure(exc)
        return ReadResult("CORRUPT", None, str(backup), str(exc))


def read_document(path: str | Path, *, recover: bool = True) -> ReadResult:
    target = Path(path)
    backup = backup_path(target)
    if not target.exists():
        if recover and backup.exists():
            return recover_backup(target)
        return ReadResult("MISSING", None, str(target))
    try:
        document = _read_one(target, require_schema=True)
        return ReadResult("OK", document, str(target))
    except Exception as target_error:
        if recover and backup.exists():
            recovered = recover_backup(target)
            if recovered.document is not None:
                return recovered
        _set_failure(target_error)
        return ReadResult("CORRUPT", None, str(target), str(target_error))


def serialize_document(document: dict[str, Any]) -> bytes:
    if not isinstance(document, dict):
        raise TypeError("Smart Cloth settings root must be a dict")
    payload = dict(document)
    payload["schema"] = DOCUMENT_SCHEMA
    validate_document(payload, require_schema=True)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    return text.encode("utf-8") + b"\n"


def write_document(path: str | Path, document: dict[str, Any], *, allow_create: bool = True) -> bool:
    target = Path(path)
    backup = backup_path(target)
    try:
        existing = read_document(target, recover=True)
        if existing.status == "CORRUPT":
            # A corrupt primary with no valid backup is never replaced by an
            # empty/default document. The caller retains dirty state.
            raise OSError(existing.error or "Settings file and backup are corrupt")
        if existing.status == "MISSING" and not allow_create:
            raise FileNotFoundError(str(target))
        data = serialize_document(document)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            _create_verified_backup(target, backup)
        _replace_verified(target, data)
        parsed = _decode_document(target.read_bytes(), require_schema=True)
        expected = _decode_document(data, require_schema=True)
        if parsed != expected:
            raise OSError("Settings semantic readback mismatch")
        mark_clean()
        return True
    except Exception as exc:
        _set_failure(exc)
        # Restore a known-valid backup if replacement damaged the primary.
        try:
            if backup.exists():
                backup_document = _read_one(backup, require_schema=True)
                backup_data = serialize_document(backup_document)
                _replace_verified(target, backup_data)
        except Exception:
            pass
        return False


def update_document(
    path: str | Path,
    mutator: Callable[[dict[str, Any]], dict[str, Any]],
    *,
    allow_create: bool = True,
) -> bool:
    result = read_document(path, recover=True)
    if result.status == "CORRUPT":
        return False
    if result.status == "MISSING":
        if not allow_create:
            mark_dirty()
            return False
        base: dict[str, Any] = {}
    else:
        base = dict(result.document or {})
    try:
        updated = mutator(base)
        if not isinstance(updated, dict):
            raise TypeError("Settings mutator must return a dict")
    except Exception as exc:
        _set_failure(exc)
        return False
    return write_document(path, updated, allow_create=allow_create)


def strict_bool(value: Any, default: bool) -> bool:
    return value if type(value) is bool else bool(default)


def strict_string(value: Any, default: str = "") -> str:
    return value if isinstance(value, str) else str(default)


def strict_int(value: Any, default: int = 0) -> int:
    return value if type(value) is int else int(default)


def strict_number(value: Any, default: float = 0.0) -> float:
    if type(value) in {int, float} and not isinstance(value, bool) and math.isfinite(float(value)):
        return float(value)
    return float(default)
