"""Public settings validation and recovery, with an untouched corrupt primary on reads."""
from dataclasses import dataclass
from pathlib import Path
import json
from . import persistence
@dataclass(frozen=True)
class ReadResult:
    status:str
    document:dict|None
    source:str
    error:str=''
def backup_path(path):return Path(str(path)+'.bak')
def validate_document(document,*,require_schema=True):
    if not isinstance(document,dict) or (require_schema and document.get('schema')!='jelararagi.smart_cloth.settings.v3'):raise ValueError('Unknown SmartCloth settings document.')
def read_document(path,*,recover=True):
    path=Path(path)
    for file in (path,backup_path(path)) if recover else (path,):
        try:
            document=persistence.read(file,None);validate_document(document)
            return ReadResult('ok' if file==path else 'recovered',document,str(file))
        except (ValueError,OSError):continue
    return ReadResult('invalid' if path.exists() else 'missing',None,str(path),'No valid settings document.')
def write_document(path,document,*,allow_create=True):
    path=Path(path);validate_document(document)
    if not path.exists() and not allow_create:return False
    if path.exists():
        old=read_document(path,recover=False)
        if old.document is None:return False
        persistence.atomic(backup_path(path),old.document)
    persistence.atomic(path,document);return True
