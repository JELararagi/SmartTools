"""Bilingual cloth controls with contextual help and actual saved-state readouts."""
import bpy
from .translation import localized
from . import properties,manager_bridge,bridge,skirt
from .core import integration
MANUAL='https://jelararagi.github.io/SmartTools/manuals/SmartCloth/'
def txt(ctx,en,ja):
    view=ctx.preferences.view;return ja if view.use_translate_interface and (view.language or bpy.app.translations.locale).lower().startswith('ja') else en
def help_popup(ctx,topic):
    guide={'component':('Choose the fabric material or weight group, then split and switch the garment.','布の素材または頂点グループを指定し、分割して表示を切り替えます。'),'bridge':('Bake the cloth cache. Select a chain of weighted pose bones, including its root.','布をベイクし、根元を含むウェイト付きのボーン列を選びます。'),'skirt':('Map the garment, armature and body. Preview before enabling Cloth.','衣装、アーマチュア、体を指定し、プレビュー後にクロスを有効にします。'),'jiggle':('Enable the runtime, scene, rig and selected bones, then play the timeline.','常時起動、シーン、リグ、対象ボーンを有効にし、再生します。'),'rigid':('Add active bodies to falling objects and passive bodies to the floor.','落下する物体をアクティブ、床をパッシブに設定します。')}
    def draw(pop,c):
        pop.layout.label(text=txt(c,*guide.get(topic,('Prepare cloth, rig motion and collisions from this sidebar.','サイドバーで衣装の布、ボーンの揺れ、衝突を準備します。'))))
        pop.layout.operator('wm.url_open',text=txt(c,'SmartCloth manual','SmartCloth 取扱説明書'),icon='URL').url=MANUAL
    ctx.window_manager.popup_menu(draw,title='Smart Cloth · '+topic,icon='QUESTION')
def help_button(layout,topic):layout.operator('smart_core.show_help_popup',text='',icon='QUESTION',emboss=False).topic=topic
def group(layout,ctx,data,attr,en,ja,topic):
    box=layout.box();row=box.row(align=True);row.prop(data,attr,text='',icon='TRIA_DOWN' if getattr(data,attr) else 'TRIA_RIGHT',toggle=True);row.label(text='',icon={'suite':'PREFERENCES','skirt':'MOD_CLOTH','rigid':'RIGID_BODY','component':'MESH_GRID','bridge':'BONE_DATA','jiggle':'ARMATURE_DATA'}.get(topic,'DOT'));lane=row.row();lane.alignment='CENTER';lane.label(text=txt(ctx,en,ja));help_button(row,topic)
    return box.column(align=True) if getattr(data,attr) else None
def fields(layout,ctx,data,items):
    for name,en,ja in items:layout.prop(data,name,text=txt(ctx,en,ja))
def action(layout,ctx,key,en,ja,**kw):
    op=layout.operator(key if '.' in key else 'smart_cloth_suite.'+key,text=txt(ctx,en,ja))
    for n,v in kw.items():setattr(op,n,v)
def ops(layout,ctx,items):
    for k,en,ja in items:action(layout,ctx,k,en,ja)
class Sidebar:
    @classmethod
    def poll(cls,context):return manager_bridge.panel_allowed(context,physical_space=cls.bl_space_type)
    def draw_header_preset(self,context):help_button(self.layout,'suite')
    def draw(self,context):
        l=self.layout;c=context.scene.smart_cloth_suite_companion;p=properties.prefs(context);scene=context.scene
        box=group(l,context,p,'show_always_on_toggles','Always-on features','常時起動切り替え','suite')
        if box:fields(box,context,p,[('always_suite_npanel_persistence','Remember panel settings','パネル設定を保存'),('always_jiggle_runtime_callbacks','Run jiggle simulation','揺れを計算'),('always_jiggle_overlay_rest_pose','Show rest pose','レスト姿勢を表示'),('always_jiggle_overlay_simulation','Show simulated tips','揺れの結果を表示')])
        box=group(l,context,c,'ui_skirt_mapping','Skirt and collision body','スカートと衝突する体','skirt')
        if box:
            fields(box,context,c,[('skirt_garment','Garment','衣装'),('skirt_armature','Armature','アーマチュア'),('skirt_bones','Garment bones','衣装ボーン'),('skirt_leg_bones','Leg bones','脚ボーン'),('body_object','Body','体'),('skirt_collider_collection','Collider collection','衝突コレクション'),('skirt_setup_route','Cloth provider','クロスの方式'),('skirt_clearance','Clearance','間隔'),('skirt_outside_offset','Outside offset','外側補正量')])
            row=box.row(align=True);action(row,context,'skirt_preview','Preview','確認');action(row,context,'skirt_setup','Prepare skirt','スカートを設定')
            row=box.row(align=True);action(row,context,'skirt_mode','Bones','ボーン',mode='BONE');action(row,context,'skirt_mode','Cloth','クロス',mode='CLOTH')
            if c.skirt_garment and c.skirt_armature:
                state=skirt.mode_status(c.skirt_garment,c.skirt_armature,skirt.profile(c.skirt_garment));box.label(text=txt(context,'Current mode · ','現在のモード · ')+{'BONE':txt(context,'Bones','ボーン'),'CLOTH':txt(context,'Cloth','クロス'),'MIXED':txt(context,'Mixed','混在'),'INVALID':txt(context,'Invalid','設定要確認'),'ABSENT':txt(context,'Unprepared','未設定')}.get(state,state))
            ops(box,context,[('skirt_outside','Outside correction','外側補正'),('skirt_audit','Check mapping','設定を点検'),('skirt_bake_check','Bake and inspect surfaces','ベイクとめり込み検査'),('skirt_save','Save mapping','設定を保存'),('skirt_adopt_simply','Adopt Simply Cloth','Simply Cloth に切り替え'),('skirt_adopt_simply_revert','Revert adoption','切り替えを戻す')])
        box=group(l,context,c,'ui_skirt_component','Fabric and retained trim','部分布と飾り','component')
        if box:
            for k,en,ja in [('component_source','Region source','布の指定方法'),('component_material_slot','Material slot','素材スロット'),('component_fabric_group','Fabric group','布グループ'),('component_group_threshold','Minimum weight','最小ウェイト'),('component_pin_group','Pin group','固定グループ'),('component_pin_band','Pin band','固定帯'),('component_support_armature','Support rig','支持リグ'),('component_support_bone','Support bone','支持ボーン'),('component_total_mass_kg','Mass (kg)','全体の質量 (kg)'),('component_tension','Tension','張力'),('component_bending','Bending','曲げ')]:box.prop(c,k,text=txt(context,en,ja))
            ops(box,context,[('component_preview','Preview region','範囲を確認'),('component_apply','Prepare parts','部分布を作成')])
            row=box.row(align=True);action(row,context,'component_mode','Bones','ボーン',mode='BONE');action(row,context,'component_mode','Cloth','クロス',mode='CLOTH')
            ops(box,context,[('component_audit','Check parts','部分布を点検'),('component_cleanup','Restore original','元の衣装に戻す')])
        box=group(l,context,c,'ui_cloth_bone_bridge','Cloth motion to bones','布の動きをボーンへ','bridge')
        if box:
            fields(box,context,c,[('bridge_source_mesh','Simulated mesh','シミュレーションした布'),('bridge_target_armature','Target rig','対象リグ'),('bridge_frame_start','First frame','開始'),('bridge_frame_end','Last frame','終了')])
            st=bridge.status(c.bridge_target_armature,c.bridge_source_mesh);box.label(text=txt(context,'State · ','状態 · ')+localized(st.state,context))
            if st.reason:box.label(text=localized(st.reason,context))
            ops(box,context,[('bridge_preview','Check selected chain','選択したボーンを確認'),('bridge_bake','Bake motion','動きをベイク')]);row=box.row(align=True);action(row,context,'bridge_mode','Original','従来',mode='STANDARD');action(row,context,'bridge_mode','Baked','ベイク結果',mode='CLOTH_BAKED');action(box,context,'bridge_clear','Remove bridge','連携結果を解除')
        workflow(l,context,c,p);motion(l,context,p,scene)
        if c.last_status:l.label(text=c.last_status[:100])
def workflow(l,ctx,c,p):
    groups=[('ui_open_scs_external','External provider','外部製品',(),[('refresh_external_status','Refresh status','状態を更新'),('open_external_preferences','Extension preferences','拡張機能の設定')]),('ui_open_scs_workflow','Garment setup','衣装の設定',('quality_profile','target_scope','apply_profile_after_setup','auto_collision_after_setup','apply_colliders_after_setup','auto_pin_top','preserve_existing_pin','pin_band_ratio','enable_self_collision'),[('smart_setup','Smart setup','衣装を一括設定'),('apply_colliders','Apply colliders','衝突を設定'),('apply_quality_profile','Apply quality','品質を適用')]),('ui_open_scs_precision','Collision and motion','衝突と動き',('collision_distance_factor','min_collision_distance','max_collision_distance','layer_gap','motion_sample_frames','temporal_guard_multiplier'),[('auto_collision_distance','Size collision distance','衝突距離を計算'),('layer_clearance','Separate layers','レイヤー間隔'),('temporal_guard','Guard fast motion','高速移動の保護')]),('ui_open_scs_analysis','Mesh analysis','メッシュ解析',('analysis_proximity_distance','repair_remove_loose','repair_merge_factor'),[('build_analysis_maps','Build analysis weights','解析ウェイトを作成'),('repair_topology','Repair topology','形状を修復')]),('ui_open_scs_performance','Preview performance','軽量プレビュー',('preview_hide_heavy_modifiers','preview_quality'),[]),('ui_open_scs_output','Output and checks','出力と検査',('report_format','stop_on_preflight_error','external_modifiers_handling'),[('preflight','Run preflight','事前点検'),('open_data_folder','Open data folder','保存先を開く')])]
    for attr,en,ja,names,entries in groups:
        box=group(l,ctx,p,attr,en,ja,'suite')
        if not box:continue
        for n in names:box.prop(c,n)
        ops(box,ctx,entries)
        if attr=='ui_open_scs_external':
            s=integration.peek_external_status();box.label(text=('Simply Cloth Studio '+s.version) if s.ready else txt(ctx,'Not enabled','未有効'))
        if attr=='ui_open_scs_performance':
            for k,en,ja in [('APPLY','Enable preview','プレビューを適用'),('RESTORE','Restore settings','設定を戻す')]:action(box,ctx,'batch_preview',en,ja,action=k)
        if attr=='ui_open_scs_output':
            for k,en,ja in [('BAKE','Bake cloth','布をベイク'),('FREE_BAKE','Free bake','ベイクを解除'),('FINISH','Finish with provider','外部製品で確定')]:action(box,ctx,'safe_output',en,ja,action=k)
def motion(l,ctx,p,s):
    box=group(l,ctx,p,'ui_open_tool_quick_rigid','Rigid bodies','リジッドボディ','rigid') if p.show_quick_rigid_tools else None
    if box:
        ops(box,ctx,[('object.add_active_rigid_body','Active body','動く物体'),('object.add_passive_rigid_body','Passive collider','固定する物体'),('rigid_body.toggle_animated','Switch animated','アニメーション切替')]);obj=ctx.object
        if obj and obj.rigid_body:
            for k in ('mass','friction','restitution','collision_shape','kinematic'):box.prop(obj.rigid_body,k)
        box.menu('VIEW3D_MT_quick_rigid_presets_submenu',text=txt(ctx,'Presets','プリセット'));box.prop(s.quick_rigid_settings,'enable_floating_menu');box.prop(s.quick_rigid_settings,'shortcut_key');action(box,ctx,'quick_rigid.apply_shortcut_key','Apply shortcut','ショートカット適用')
    box=group(l,ctx,p,'ui_open_tool_jiggle_physics','Jiggle bones','揺れボーン','jiggle') if p.show_jiggle_physics_tools else None
    if box:
        fields(box,ctx,s.jiggle,[('enable','Enable scene','シーンで有効'),('runtime_callbacks_enabled','Update on frames','フレーム更新'),('simulate_during_scrub','Scrub preview','スクラブ'),('substeps','Substeps','サブステップ'),('gravity','Gravity','重力'),('enable_wind','Wind','風')])
        if ctx.object and ctx.object.type=='ARMATURE':box.prop(ctx.object.jiggle,'enable',text=txt(ctx,'Enable rig','リグで有効'))
        if ctx.active_pose_bone:
            b=ctx.active_pose_bone;box.prop(b.jiggle,'enable',text=txt(ctx,'Enable bone','ボーンで有効'))
            for k in properties.DATA['roots']['PoseBone']:
                if k!='jiggle':box.prop(b,k)
        ops(box,ctx,[('armature.jiggle_select','Select simulated bones','揺れるボーンを選択'),('armature.jiggle_copy','Copy bone settings','設定を複製'),('armature.jiggle_bone_connected_disable','Disconnect selected bones','選択ボーンの接続を解除'),('armature.jiggle_bone_constraints_disable','Mute selected constraints','選択ボーンの制約を停止'),('scene.jiggle_reset','Reset simulation','シミュレーションを戻す'),('scene.jiggle_profile','Statistics','計算情報'),('armature.jiggle_bake','Bake motion','揺れをベイク'),('anim.jiggle_clear_keyframes','Clear selected parameter keys','選択ボーンの設定キーを消去')]);action(box,ctx,'armature.jiggle_bake','Restore original motion','元の動きへ戻す',clear_only=True);box.menu('JIGGLE_MT_JiggleBonePresets')
class Menu:
    def draw(self,context):
        l=self.layout;name=type(self).__name__;scene=context.scene
        if name=='JIGGLE_MT_JiggleBonePresets':
            from pathlib import Path
            locations=[Path(__file__).parent/'jiggle_physics/presets/jigglebones',Path(bpy.utils.extension_path_user(__package__,path='jiggle_physics/presets/jigglebones',create=False))]
            scripts={f.stem:f for loc in locations if loc.is_dir() for f in loc.glob('*.py')}
            for title,path in sorted(scripts.items()):
                op=l.operator('script.execute_preset',text=title.title());op.filepath=str(path);op.menu_idname=name
            l.operator('armature.add_jigglebone_preset',text=txt(context,'Save active bone preset','現在のボーン設定を保存'));l.operator('armature.add_jigglebone_preset',text=txt(context,'Remove active bone preset','現在のボーン設定を削除')).remove_active=True;return
        if 'preset' in name:
            l.operator('object.add_rigid_body_preset')
            for item in scene.rigid_body_presets:l.operator('object.apply_rigid_body_preset',text=item.name).preset_name=item.name
        elif name=='VIEW3D_MT_quick_rigid':
            for k in ('main','physics','collision','sim','bake','presets'):l.menu('VIEW3D_MT_quick_rigid_'+k+'_submenu')
        elif 'bake' in name:l.operator('ptcache.bake_all');l.operator('ptcache.free_bake_all')
        elif 'main' in name:l.operator('object.add_active_rigid_body');l.operator('object.add_passive_rigid_body')
        elif context.object and context.object.rigid_body:
            for k in {'physics':('mass','friction','restitution'),'collision':('collision_shape','use_margin','collision_margin'),'sim':('kinematic','enabled','linear_damping')}.get(name.split('_')[-2],()):l.prop(context.object.rigid_body,k)
