"""Extract two reversible, tagged garment parts from a material or a weighted region."""
from uuid import uuid4
import json,bpy,bmesh
from . import skirt
ACTION_OWNER='_smart_cloth_suite_component_action_owner_v1'
from .core import integration
KEY='_smart_cloth_suite_component_v1'
OWNER='_smart_cloth_suite_component_owner_v1'
BACKUP='_smart_cloth_suite_component_backup_id_v1'
def parse(g):
    v=g.get(KEY)
    return json.loads(v) if isinstance(v,str) else v.to_dict() if v else {}
def plan(c,g):
    if g.data.shape_keys or any(m.type=='CLOTH' for m in g.modifiers):raise ValueError('Use a mesh without shape keys or pre-existing Cloth.')
    rig=c.component_support_armature or g.find_armature();bone=c.component_support_bone
    if not rig or rig.type!='ARMATURE' or bone not in rig.pose.bones:raise ValueError('Choose an existing support bone.')
    if c.component_source=='VERTEX_GROUP':
        group=g.vertex_groups.get(c.component_fabric_group)
        if not group:raise ValueError('Choose the fabric vertex group.')
        mask={v.index for v in g.data.vertices if any(x.group==group.index and x.weight>=c.component_group_threshold for x in v.groups)}
        selected={p.index for p in g.data.polygons if all(i in mask for i in p.vertices)}
    else:selected={p.index for p in g.data.polygons if p.material_index==c.component_material_slot}
    if not selected or len(selected)==len(g.data.polygons):raise ValueError('Select both fabric and retained trim.')
    return rig,bone,selected
def split(g,keep,name,token):
    obj=g.copy();obj.data=g.data.copy();obj.name=g.name+name;obj[OWNER]=token;obj.data[OWNER]=token;g.users_collection[0].objects.link(obj)
    bm=bmesh.new()
    try:
        bm.from_mesh(obj.data);bm.faces.ensure_lookup_table();bmesh.ops.delete(bm,geom=[f for f in bm.faces if f.index not in keep],context='FACES')
        bmesh.ops.delete(bm,geom=[v for v in bm.verts if not v.link_faces],context='VERTS');bm.to_mesh(obj.data)
    finally:bm.free()
    obj.data.update();return obj
def remove_obj(obj):
    mesh=obj.data;bpy.data.objects.remove(obj,do_unlink=True)
    if mesh.users==0:bpy.data.meshes.remove(mesh)
def owned(p,key):
    o=bpy.data.objects.get(p.get(key,''))
    if not o or o.get(OWNER)!=p['token']:raise ValueError('The saved fabric helpers have changed ownership.')
    return o
def mode(g,p,new):
    fabric=owned(p,'fabric_helper');trim=owned(p,'trim_helper');cloth=fabric.modifiers.get(p['cloth_modifier'])
    if not cloth or cloth.type!='CLOTH':raise ValueError('The prepared fabric Cloth is missing.')
    show=new=='CLOTH';g.hide_viewport=True if show else p['original']['hide_viewport'];g.hide_render=True if show else p['original']['hide_render']
    fabric.hide_viewport=fabric.hide_render=trim.hide_viewport=trim.hide_render=not show;skirt.visible(cloth,show);p['mode']=new;g[KEY]=json.dumps(p)
def clear(g,p):
    if not p:return
    objs=[owned(p,k) for k in ('fabric_helper','trim_helper')]
    extra=bpy.data.objects.get(p.get('external_backup',''))
    if extra and extra.get(OWNER)==p['token'] and extra.get(BACKUP)==p.get('external_backup_id'):objs.append(extra)
    g.hide_viewport=p['original']['hide_viewport'];g.hide_render=p['original']['hide_render']
    for obj in objs:remove_obj(obj)
    for name in p.get('owned_actions',[]):
        a=bpy.data.actions.get(name)
        if a and a.get(ACTION_OWNER)==p['token'] and a.users==0:bpy.data.actions.remove(a)
    del g[KEY]
def apply(ctx,c,g,rig,bone,faces):
    if parse(g):raise ValueError('The garment already has prepared components.')
    if not integration.external_status(force=True).ready:raise ValueError('Enable the separately installed Simply Cloth Studio.')
    token=uuid4().hex;objs=[];actions=set(bpy.data.actions);before=set(bpy.data.objects);selected=list(ctx.selected_objects);active=ctx.view_layer.objects.active
    try:
        fabric=split(g,faces,'_SC_Fabric',token);objs.append(fabric);trim=split(g,set(range(len(g.data.polygons)))-faces,'_SC_Trim',token);objs.append(trim)
        pin=fabric.vertex_groups.get(c.component_pin_group) if c.component_pin_group else None
        if not pin:
            pin=fabric.vertex_groups.new(name='SC_ComponentPin_'+token[:8]);world=[(fabric.matrix_world@v.co).z for v in fabric.data.vertices];cut=max(world)-(max(world)-min(world))*c.component_pin_band
            pin.add([i for i,z in enumerate(world) if z>=cut],1,'REPLACE')
        hook=fabric.modifiers.new('SC_ComponentSupport','HOOK');hook.object=rig;hook.subtarget=bone;hook.vertex_group=pin.name
        hook.matrix_inverse=(rig.matrix_world@rig.pose.bones[bone].matrix).inverted_safe()@fabric.matrix_world
        for o in selected:o.select_set(False)
        fabric.select_set(True);ctx.view_layer.objects.active=fabric
        result=integration.call_external_operator('object.create_cloth',ctx,mode='CREATECLOTH',modifiers_handling='DO_NOTHING')
        extras=[o for o in bpy.data.objects if o not in before and o not in objs]
        for o in extras:o[OWNER]=token;o[BACKUP]=uuid4().hex
        objs.extend(extras);cloth=next((m for m in fabric.modifiers if m.type=='CLOTH'),None)
        if not cloth or 'FINISHED' not in result:raise ValueError('The fabric provider did not produce Cloth.')
        fabric.modifiers.move(list(fabric.modifiers).index(cloth),list(fabric.modifiers).index(hook)+1)
        auxiliaries=[m for m in fabric.modifiers if m!=cloth and m not in (hook,) and m.name not in {v.name for v in g.modifiers}]
        for aux in auxiliaries:skirt.visible(aux,False)
        n=len(fabric.data.vertices);cloth.settings.mass=c.component_total_mass_kg/n;cloth.settings.vertex_group_mass=pin.name;cloth.settings.tension_stiffness=c.component_tension;cloth.settings.bending_stiffness=c.component_bending
        added_actions=[a.name for a in bpy.data.actions if a not in actions]
        for action_name in added_actions:bpy.data.actions[action_name][ACTION_OWNER]=token
        p=dict(schema=2,pin_vertices=sum(any(w.group==pin.index and w.weight>0 for w in v.groups) for v in fabric.data.vertices),external_aux_modifiers=[m.name for m in auxiliaries],selection=dict(source=c.component_source,material_slot=c.component_material_slot,group=c.component_fabric_group,threshold=c.component_group_threshold),token=token,fabric_helper=fabric.name,trim_helper=trim.name,cloth_modifier=cloth.name,pin_group=pin.name,support_hook=hook.name,support_armature=rig.name,support_bone=bone,fabric_faces=len(faces),trim_faces=len(trim.data.polygons),simulated_vertices=n,total_mass_kg=c.component_total_mass_kg,mass_per_vertex_kg=cloth.settings.mass,source_material_slots=[x.name if x else '' for x in g.data.materials],source_uv_layers=[v.name for v in g.data.uv_layers],owned_actions=added_actions,original=dict(hide_viewport=g.hide_viewport,hide_render=g.hide_render,modifiers=skirt.stack(g)),external_backup=extras[0].name if extras else '',external_backup_id=extras[0][BACKUP] if extras else '')
        mode(g,p,'BONE')
    except Exception:
        for o in reversed(objs):
            if o and o.name in bpy.data.objects:remove_obj(o)
        raise
    finally:
        for o in ctx.selected_objects:o.select_set(False)
        for o in selected:o.select_set(True)
        ctx.view_layer.objects.active=active
def execute(key,op,ctx):
    c=ctx.scene.smart_cloth_suite_companion;g=c.skirt_garment or ctx.object
    if not g or g.type!='MESH':raise ValueError('Choose the garment.')
    p=parse(g)
    if key=='component_cleanup':clear(g,p);return
    if key in ('component_preview','component_apply'):
        rig,bone,faces=plan(c,g)
        if key=='component_apply':apply(ctx,c,g,rig,bone,faces)
        else:c.last_status=f'{len(faces)} fabric faces / {len(g.data.polygons)-len(faces)} trim faces'
        return
    if not p and key=='component_audit':c.last_status='No prepared fabric parts.';return
    if not p:raise ValueError('Prepare garment components first.')
    if key=='component_mode':mode(g,p,op.mode);return
    f=owned(p,'fabric_helper');trim=owned(p,'trim_helper')
    cloth=f.modifiers.get(p['cloth_modifier']);hook=f.modifiers.get(p['support_hook'])
    if not cloth or not hook or not hook.object or not hook.subtarget or len(f.data.vertices)!=p['simulated_vertices'] or len(trim.data.polygons)!=p['trim_faces']:raise ValueError('The garment component mapping is incomplete.')
    c.last_status='Cloth' if cloth.show_viewport and not f.hide_viewport and g.hide_viewport else 'Bones' if not cloth.show_viewport and f.hide_viewport and not g.hide_viewport else 'Mixed'
