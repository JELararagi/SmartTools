"""The 5.1 RNA compatibility surface, including scene, armature and individual pose-bone values."""
from pathlib import Path
import json,bpy
DATA=json.loads((Path(__file__).parent/'rna.json').read_text('utf8'))
GROUPS={};ROOTS=[];loading=False
def changed_pref(pref,ctx):
    if loading:return
    from . import persistence,jiggle
    if getattr(pref,'always_suite_npanel_persistence',False):persistence.schedule()
    jiggle.sync(ctx,pref)
def toggle_storage(pref,ctx):
    if not loading:
        from . import persistence
        persistence.save(ctx,force=True)
def scene_changed(group,ctx):
    if not loading:
        from . import persistence
        p=prefs(ctx)
        if p and p.always_suite_npanel_persistence:persistence.schedule()
def changed_callbacks(scene,ctx):
    if not loading:
        from . import jiggle
        jiggle.sync(ctx)
def field(owner,key,p):
    kind=p['type'];args={'name':key.replace('_',' ').title()}
    if owner=='SMARTCLOTHSUITE_PG_RuntimePreferences':args['update']=toggle_storage if key=='always_suite_npanel_persistence' else changed_pref
    if owner in ('SMARTCLOTHSUITE_PG_companion_settings','QuickRigidSettings','JiggleScene') and key not in ('lastframe','last_status','last_report_path'):args['update']=scene_changed
    if owner=='JiggleScene' and key=='runtime_callbacks_enabled':args['update']=changed_callbacks
    if kind in ('POINTER','COLLECTION'):
        target=GROUPS.get(p['ref']) or getattr(bpy.types,p['ref'])
        return (bpy.props.PointerProperty if kind=='POINTER' else bpy.props.CollectionProperty)(type=target,**args)
    if kind=='ENUM':
        args['items']=[(k,k.replace('_',' ').title(),'',v)for k,v in p['enum']]
        if args['items']:args['default']=p['default']
        return bpy.props.EnumProperty(**args)
    for a in ('default','min','max'):
        if a in p:args[a]=p[a]
    if p.get('subtype') not in ('NONE',None):args['subtype']=p['subtype']
    if p.get('array_length'):
        args['size']=p['array_length']
        if p.get('subtype')=='MATRIX':args['size']=(4,4);args['default']=[p['default'][i:i+4]for i in range(0,16,4)]
        fn=bpy.props.FloatVectorProperty if kind=='FLOAT' else bpy.props.IntVectorProperty
    else:fn={'INT':bpy.props.IntProperty,'FLOAT':bpy.props.FloatProperty,'BOOLEAN':bpy.props.BoolProperty,'STRING':bpy.props.StringProperty}[kind]
    return fn(**args)
def register():
    for owner,rows in DATA['groups'].items():
        cls=type(owner,(bpy.types.PropertyGroup,),{'__module__':__name__,'__annotations__':{k:field(owner,k,v)for k,v in rows.items()}})
        bpy.utils.register_class(cls);GROUPS[owner]=cls
    for owner,rows in DATA['roots'].items():
        cl=getattr(bpy.types,owner)
        for name,p in rows.items():
            if hasattr(cl,name):continue
            setattr(cl,name,field(owner,name,p));ROOTS.append((cl,name))
def unregister():
    while ROOTS:
        t,k=ROOTS.pop()
        if hasattr(t,k):delattr(t,k)
    for cls in reversed(tuple(GROUPS.values())):bpy.utils.unregister_class(cls)
    GROUPS.clear()
def arguments(idname):return {n:field(idname,n,v) for n,v in DATA['operators'][idname].items()}
def prefs(context=None):return getattr((context or bpy.context).window_manager,'smart_tools_runtime_preferences_v420',None)
