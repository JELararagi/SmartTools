"""Per-garment mappings, reversible owned simulation and external-provider adoption."""
from mathutils import Vector
from hashlib import sha256
import bpy,json,re
from .core import integration
from . import driver_state
PROFILE='_smart_cloth_suite_skirt_profile_v1'
ADOPT='_smartcloth_independent_adoption'
def mapped(ctx):
    c=ctx.scene.smart_cloth_suite_companion;g=c.skirt_garment or (ctx.object if ctx.object and ctx.object.type=='MESH' else None)
    if not g or g.type!='MESH':raise ValueError('Select a skirt mesh.')
    rig=c.skirt_armature or g.find_armature()
    if not rig or rig.type!='ARMATURE':raise ValueError('Choose the garment armature.')
    raw=lambda s:[v.strip() for v in re.split(r'[,;\n]+',s) if v.strip()]
    p=profile(g);bones=raw(c.skirt_bones) or list(p.get('skirt_bones',[]));legs=raw(c.skirt_leg_bones) or list(p.get('leg_bones',[]))
    group=c.skirt_collider_collection or c.collider_collection
    targets=[o for o in group.all_objects if o.type=='MESH' and o!=g] if group else []
    if c.body_object and c.body_object!=g and c.body_object not in targets:targets.append(c.body_object)
    if any(b not in rig.pose.bones for b in bones+legs):raise ValueError('One or more mapped bones are missing.')
    return c,g,rig,bones,legs,targets
def value(v):return v.to_dict() if hasattr(v,'to_dict') else dict(v)
def profile(g):return value(g[PROFILE]) if PROFILE in g else {}
def store(g,p):g[PROFILE]=p
def stack(g):return [dict(name=m.name,type=m.type,show_viewport=m.show_viewport,show_render=m.show_render) for m in g.modifiers]
def restore_stack(g,snapshot):
    for d in snapshot:
        m=g.modifiers.get(d['name'])
        if m and m.type==d['type']:m.show_viewport=d['show_viewport'];m.show_render=d['show_render']
def pin(obj,name,ratio):
    grp=obj.vertex_groups.new(name=name);v=obj.data.vertices
    if not len(v):raise ValueError('The mesh has no vertices.')
    heights=[(obj.matrix_world@x.co).z for x in v];lo=min(heights);hi=max(heights);levels=sorted(set(round(z,5) for z in heights),reverse=True)
    if len(levels)>1:cut=hi-min(max(.0001,(hi-lo)*ratio),max(.0001,(hi-levels[1])*.98))
    else:cut=hi-.0001
    members=[i for i,z in enumerate(heights) if z>=cut];grp.add(members,1.,'REPLACE');return grp
def group_used(obj,name):
    gr=obj.vertex_groups.get(name)
    return bool(gr and any(x.group==gr.index and x.weight>1e-5 for v in obj.data.vertices for x in v.groups))
def avoid_name(g,b,leg):return 'SC_SkirtAvoid_'+sha256((g.name+'|'+b+'|'+leg).encode()).hexdigest()[:16]
def visible(c,on):c.show_viewport=on;c.show_render=on
def verified_cloth(g,p):
    m=g.modifiers.get(p.get('cloth_modifier',''))
    if not m or m.type!='CLOTH':raise ValueError('The saved Cloth modifier is missing.')
    return m
def set_mode(g,rig,p,mode):
    if not p:raise ValueError('Prepare a skirt setup first.')
    cloth=verified_cloth(g,p)
    if mode=='TOGGLE':mode='BONE' if cloth.show_viewport else 'CLOTH'
    if mode=='CLOTH' and cloth.point_cache.is_baked and not cloth.show_viewport:raise ValueError('Free the baked Cloth cache before switching.')
    visible(cloth,mode=='CLOTH')
    if mode=='BONE':restore_stack(g,json.loads(p.get('original_stack_json','[]')))
    names=set(p.get('avoid_constraints',[]))
    for b in rig.pose.bones:
        for c in b.constraints:
            if c.name in names and c.type=='LIMIT_DISTANCE':c.mute=mode!='BONE'
    m=g.modifiers.get(p.get('outside_modifier','SC_SkirtOutside'))
    if m and m.type=='SHRINKWRAP' and p.get('correction_enabled'):visible(m,mode=='BONE')
    p['mode']=mode;store(g,p)
def mode_status(g,rig,p):
    if not p:return 'ABSENT'
    cloth=g.modifiers.get(p.get('cloth_modifier',''))
    if not cloth or cloth.type!='CLOTH':return 'INVALID'
    if cloth.show_viewport!=cloth.show_render:return 'MIXED'
    names=set(p.get('avoid_constraints',[]));records=[c for b in rig.pose.bones for c in b.constraints if c.name in names]
    if len(records)!=len(names):return 'INVALID'
    if any(c.mute!=cloth.show_viewport or c.influence<.999 for c in records):return 'MIXED'
    return 'CLOTH' if cloth.show_viewport else 'BONE'
def create(ctx,c,g,rig,bones,legs,targets,ratio,quality):
    existing=profile(g)
    if existing:
        verified_cloth(g,existing);return existing
    if any(m.type=='CLOTH' for m in g.modifiers):raise ValueError('Existing Cloth must be explicitly adopted.')
    original=stack(g);added=[];new_groups=[];constraints=[];collisions=[]
    try:
        if c.skirt_setup_route=='SIMPLY':
            if not integration.external_status(force=True).ready:raise ValueError('Simply Cloth Studio is required for this route.')
            with ctx.temp_override(active_object=g,object=g,selected_objects=[g],selected_editable_objects=[g]):
                result=integration.call_external_operator('object.create_cloth',ctx,mode='CREATECLOTH',modifiers_handling='DO_NOTHING')
            added=[m for m in g.modifiers if m.name not in {a['name'] for a in original}]
            cloth=next((m for m in added if m.type=='CLOTH'),None)
            if not cloth or 'FINISHED' not in result:raise ValueError('The provider did not create Cloth.')
        else:cloth=g.modifiers.new('SC_SkirtCloth','CLOTH');added.append(cloth)
        grp=pin(g,'SC_SkirtPin',ratio);new_groups.append(grp);cloth.settings.vertex_group_mass=grp.name;cloth.settings.quality=quality
        if c.skirt_setup_route=='OWNED':cloth.settings.shear_stiffness=15.
        if c.skirt_collider_collection:cloth.collision_settings.collection=c.skirt_collider_collection
        for obj in targets:
            if not any(m.type=='COLLISION' for m in obj.modifiers):collisions.append((obj,obj.modifiers.new('SC_SkirtCollision','COLLISION')))
        shared=[b for b in bones if any(group_used(obj,b) and obj.find_armature()==rig for obj in targets)]
        for name in bones:
            if name in shared:continue
            for leg in legs:
                if name==leg:continue
                pb=rig.pose.bones[name];co=pb.constraints.new('LIMIT_DISTANCE');co.name=avoid_name(g,name,leg);co.target=rig;co.subtarget=leg;co.limit_mode='LIMITDIST_OUTSIDE';co.distance=c.skirt_clearance;constraints.append((pb,co))
        p=dict(schema=3,armature=rig.name,skirt_bones=bones,leg_bones=legs,colliders=[o.name for o in targets],clearance=c.skirt_clearance,route=c.skirt_setup_route,cloth_modifier=cloth.name,pin_group=grp.name,collision_modifiers=[m.name for _,m in collisions],avoid_constraints=[k.name for _,k in constraints],shared_bones=shared,original_stack_json=json.dumps(original),external_added_json=json.dumps([m.name for m in added]),migration='independent_1',correction_enabled=False,mode='BONE')
        store(g,p);set_mode(g,rig,p,'BONE');return p
    except Exception:
        for pb,co in reversed(constraints):pb.constraints.remove(co)
        for obj,m in reversed(collisions):obj.modifiers.remove(m)
        for gr in reversed(new_groups):g.vertex_groups.remove(gr)
        for m in reversed(added):g.modifiers.remove(m)
        if PROFILE in g:del g[PROFILE]
        raise
def outside(c,g,p,targets):
    if not p or not targets:raise ValueError('Choose a prepared garment and a collision body.')
    current=g.modifiers.get(p.get('outside_modifier',''))
    if current:
        if current.type!='SHRINKWRAP':raise ValueError('Saved outside correction has changed type.')
        p['correction_enabled']=not p.get('correction_enabled',False);visible(current,p['correction_enabled'] and p.get('mode')=='BONE')
    else:
        m=g.modifiers.new('SC_SkirtOutside','SHRINKWRAP');m.target=targets[0];m.wrap_method='NEAREST_SURFACEPOINT';m.wrap_mode='OUTSIDE';m.offset=c.skirt_outside_offset
        p['outside_modifier']=m.name;p['correction_enabled']=True;visible(m,p.get('mode')=='BONE')
    store(g,p)
def snapshot_fields(group):
    saved={}
    for prop in group.bl_rna.properties:
        if prop.is_readonly or prop.type in ('COLLECTION','POINTER'):continue
        v=getattr(group,prop.identifier)
        if getattr(prop,'is_array',False):v=list(v)
        if isinstance(v,(str,int,float,bool,list)):saved[prop.identifier]=v
    return saved
def restore_fields(group,values):
    for k,v in values.items():
        try:setattr(group,k,v)
        except (AttributeError,TypeError,ValueError):pass
def restore_native(g,p,doc):
    for name,kind in reversed(doc['parts']):
        m=g.modifiers.get(name)
        if m and m.type==kind:
            driver_state.detach(g,m,driver_state.inventory(g,m));g.modifiers.remove(m)
    for name in doc['groups']:
        gr=g.vertex_groups.get(name)
        if gr:g.vertex_groups.remove(gr)
    for name in doc['extras']:
        obj=bpy.data.objects.get(name)
        if obj and obj.get(ADOPT)==doc['token']:
            mesh=obj.data;bpy.data.objects.remove(obj,do_unlink=True)
            if mesh and not mesh.users and isinstance(mesh,bpy.types.Mesh):bpy.data.meshes.remove(mesh)
    anim=g.animation_data
    if anim:
        current=anim.action
        if current and (current.name in doc['actions'] or current.get(ADOPT)==doc['token']):
            anim.action=bpy.data.actions.get(doc['prior_action'])
            if anim.action:
                slot=next((s for s in anim.action.slots if s.handle==doc['prior_slot']),None)
                if slot:anim.action_slot=slot
    for name in doc['actions']:
        act=bpy.data.actions.get(name)
        if act and act.get(ADOPT)==doc['token'] and not act.users:bpy.data.actions.remove(act)
    local=g.modifiers.new(doc['oldname'],'CLOTH')
    for grp,vals in ((local.settings,doc['settings']),(local.collision_settings,doc['collision']),(local.point_cache,doc['cache'])):restore_fields(grp,vals)
    driver_state.restore(g,local,doc.get('drivers',[]));restore_fields(local.settings.effector_weights,doc.get('effector',{}))
    if doc.get('effector_collection'):local.settings.effector_weights.collection=bpy.data.collections.get(doc['effector_collection'])
    if doc['collection']:local.collision_settings.collection=bpy.data.collections.get(doc['collection'])
    g.modifiers.move(len(g.modifiers)-1,min(doc['index'],len(g.modifiers)-1));restore_stack(g,doc['stack']);p['route']=doc['route'];p['cloth_modifier']=local.name;p['pin_group']=doc['pin'];store(g,p)
def take_over(ctx,c,g,p):
    if not p or ADOPT in g or p.get('route')=='SIMPLY':raise ValueError('Prepare a local skirt before adoption.')
    if not integration.external_status(force=True).ready:raise ValueError('Enable Simply Cloth Studio first.')
    from uuid import uuid4
    from .garment import selected
    local=verified_cloth(g,p)
    if local.point_cache.is_baked:raise ValueError('Free the native cache before adoption.')
    prefix=local.path_from_id()
    drivers=driver_state.inventory(g,local);driver_state.validate(drivers)
    prior=g.animation_data.action if g.animation_data else None;slot=g.animation_data.action_slot if g.animation_data else None
    doc=dict(drivers=drivers,effector=snapshot_fields(local.settings.effector_weights),effector_collection=local.settings.effector_weights.collection.name if local.settings.effector_weights.collection else '',token=uuid4().hex,oldname=local.name,index=list(g.modifiers).index(local),route=p['route'],pin=p['pin_group'],stack=stack(g),settings=snapshot_fields(local.settings),collision=snapshot_fields(local.collision_settings),cache=snapshot_fields(local.point_cache),collection=local.collision_settings.collection.name if local.collision_settings.collection else '',prior_action=prior.name if prior else '',prior_slot=slot.handle if slot else 0)
    fields={m.name for m in g.modifiers if m!=local};groups={v.name for v in g.vertex_groups};objs=set(bpy.data.objects);acts=set(bpy.data.actions)
    if prior:g.animation_data.action=prior.copy()
    driver_state.detach(g,local,drivers);g.modifiers.remove(local)
    try:
        with selected(ctx,g):ret=integration.call_external_operator('object.create_cloth',ctx,mode='CREATECLOTH',modifiers_handling='DO_NOTHING')
        new=next((m for m in g.modifiers if m.type=='CLOTH' and m.name not in fields),None)
        if not new or 'FINISHED' not in ret:raise ValueError('Simply Cloth did not create a usable simulation.')
        driver_state.restore(g,new,drivers)
        layer=g.vertex_groups.new(name='SC_SkirtPinLayer');zs=[(g.matrix_world@v.co).z for v in g.data.vertices];top=max(zs);cut=top-(top-min(zs))*.28
        layer.add([i for i,z in enumerate(zs) if z>=cut],1,'REPLACE');new.settings.vertex_group_mass=layer.name
        if integration.operator_available('object.create_pin_layers'):
            with selected(ctx,g):integration.call_external_operator('object.create_pin_layers',ctx,mode='MERGEWEIGHTS',name=layer.name)
        if g.vertex_groups.get('SimplyPin'):
            g.vertex_groups['SimplyPin'].add([i for i,z in enumerate(zs) if z>=cut],1,'REPLACE');new.settings.vertex_group_mass='SimplyPin'
        for m in g.modifiers:
            if m.name not in fields:visible(m,m==new and p['mode']=='CLOTH')
        p['route']='SIMPLY';p['cloth_modifier']=new.name;p['pin_group']=new.settings.vertex_group_mass;store(g,p)
    finally:
        extras=[o for o in bpy.data.objects if o not in objs];actions=[a for a in bpy.data.actions if a not in acts]
        for o in extras:o[ADOPT]=doc['token']
        for a in actions:a[ADOPT]=doc['token']
        doc.update(parts=[(m.name,m.type) for m in g.modifiers if m.name not in fields],groups=[v.name for v in g.vertex_groups if v.name not in groups],extras=[o.name for o in extras],actions=[a.name for a in actions])
        if p.get('route')=='SIMPLY':g[ADOPT]=json.dumps(doc)
        else:restore_native(g,p,doc)
def undo_adopt(g,p):
    if ADOPT not in g:
        key='smart_cloth_suite_replaced_cloth_v1'
        if key not in g:raise ValueError('There is no stored adoption record.')
        record=json.loads(g[key]);previous=json.loads(record['profile_before']);owned=record.get('created_modifiers',[])
        driver_state.validate(record.get('drivers',[]))
        if not owned or p.get('cloth_modifier') not in owned or any(not g.modifiers.get(name) for name in owned):raise ValueError('The legacy provider stack is incomplete.')
        cloth=g.modifiers[p['cloth_modifier']]
        if cloth.type!='CLOTH' or cloth.point_cache.is_baked:raise ValueError('Free the external cache before restoring the native setup.')
        index=record['index'];groups=record.get('created_groups',[])
        for name in reversed(owned):
            mod=g.modifiers[name];driver_state.detach(g,mod,driver_state.inventory(g,mod));g.modifiers.remove(mod)
        for name in groups:
            group=g.vertex_groups.get(name)
            if group:g.vertex_groups.remove(group)
        local=g.modifiers.new(record['name'],'CLOTH')
        restore_fields(local.settings,record['settings']);restore_fields(local.settings.effector_weights,record.get('effector',{}));restore_fields(local.collision_settings,record.get('collision',{}));restore_fields(local.point_cache,record.get('point_cache',{}))
        local.point_cache.frame_start=record.get('frame_start',1);local.point_cache.frame_end=record.get('frame_end',250)
        for group,key_name,prop in ((local.settings.effector_weights,'effector_collection','collection'),(local.collision_settings,'collection','collection')):
            if record.get(key_name):setattr(group,prop,bpy.data.collections.get(record[key_name]))
        if record.get('shape_target') and g.data.shape_keys:local.settings.rest_shape_key=g.data.shape_keys.key_blocks.get(record['shape_target'])
        driver_state.restore(g,local,record.get('drivers',[]))
        g.modifiers.move(len(g.modifiers)-1,min(index,len(g.modifiers)-1));local.show_viewport=record['show_viewport'];local.show_render=record['show_render'];store(g,previous);del g[key];return
    doc=json.loads(g[ADOPT]);driver_state.validate(doc.get('drivers',[]))
    if any(not g.modifiers.get(k) or g.modifiers[k].type!=kind for k,kind in doc['parts']):raise ValueError('The external stack changed. Restore it before reverting.')
    restore_native(g,p,doc);del g[ADOPT]
def evaluate_check(ctx,g,cloth,targets):
    cache=cloth.point_cache;scene=ctx.scene;frame=scene.frame_current
    flags=(cloth.show_viewport,cloth.show_render);report={'lowest_z':None,'max_inside':0,'vertices':len(g.data.vertices),'invalid':0,'samples':[]}
    try:
        visible(cloth,True)
        if not cache.is_baked:
            with ctx.temp_override(scene=scene,object=g,active_object=g,point_cache=cache):
                if bpy.ops.ptcache.bake(bake=True)!={'FINISHED'}:raise ValueError('Cloth cache baking failed.')
        from math import isfinite
        for fr in range(cache.frame_start,cache.frame_end+1):
            scene.frame_set(fr);dg=ctx.evaluated_depsgraph_get();mesh=g.evaluated_get(dg);inside=0
            colliders=[o.evaluated_get(dg) for o in targets]
            for v in mesh.data.vertices:
                pt=mesh.matrix_world@v.co
                if not all(isfinite(x)for x in pt):report['invalid']+=1;continue
                report['lowest_z']=pt.z if report['lowest_z'] is None else min(pt.z,report['lowest_z'])
                for obj in colliders:
                    local=obj.matrix_world.inverted_safe()@pt;ok,surf,n,_=obj.closest_point_on_mesh(local)
                    if ok and (local-surf).dot(n)<-.00001:inside+=1;break
            report['max_inside']=max(report['max_inside'],inside);report['samples'].append([fr,inside])
        g['_smart_cloth_suite_bake_check_v1']=json.dumps(report)
    finally:cloth.show_viewport,cloth.show_render=flags;scene.frame_set(frame)
def execute(key,op,ctx):
    c,g,rig,bones,legs,targets=mapped(ctx);p=profile(g)
    if key=='skirt_preview':c.last_status=f'{g.name} · {rig.name} · {len(bones)} bones · {len(targets)} colliders';return
    if key=='skirt_setup':create(ctx,c,g,rig,bones,legs,targets,op.band_ratio,op.quality);return
    if key=='skirt_mode':set_mode(g,rig,p,op.mode);return
    if key=='skirt_audit':
        state=mode_status(g,rig,p);c.last_status=state+' · surface contacts require evaluated geometry';return
    if key=='skirt_save':
        if not p:raise ValueError('Prepare a skirt setup first.')
        from . import persistence
        persistence.atomic(persistence.folder()/'skirt_profiles'/(''.join(ch for ch in g.name if ch.isalnum() or ch in '-_')+'.json'),p)
    elif key=='skirt_outside':outside(c,g,p,targets)
    elif key=='skirt_bake_check':evaluate_check(ctx,g,verified_cloth(g,p),targets)
    elif key=='skirt_adopt_simply':take_over(ctx,c,g,p)
    elif key=='skirt_adopt_simply_revert':undo_adopt(g,p)
