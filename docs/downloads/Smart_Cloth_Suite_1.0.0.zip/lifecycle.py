# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Generation-scoped exact ownership for Smart Cloth Suite resources.

The module never discovers resources by class name, RNA identifier scan, or
``bpy.types`` traversal. Every acquired resource is recorded at creation time
and released only through its captured identity. An overlapping imported
module generation preserves the currently visible READY lease; Blender's
orderly unregister then releases that lease through its captured identities.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import sys
import types
from typing import Any, Callable

import bpy
from bpy.app.handlers import persistent


OWNER_ID = "JELararagi.smart_cloth_suite"
CONTRACT_VERSION = 3
LEASE_KEY = "JELARARAGI_SMART_CLOTH_SUITE_EXACT_LEASE_V3"
GENERATION_KEY = "JELARARAGI_SMART_CLOTH_SUITE_GENERATION_V3"
_MODULE_TOKEN = object()
_MISSING = object()

# Process-lifetime anchor for the exact lease.  Blender REPLACES
# ``bpy.app.driver_namespace`` with a brand-new dict on every file load
# (measured on 5.1.2 ec6e62d40fa9: ``id(driver_namespace)`` changes and every
# published key is gone).  The lease object itself survives -- this module's
# ``_CURRENT_LEASE`` still references it -- but ``current_lease()`` identity
# checked it against the replaced dict, found ``None is not lease`` and
# reported "no lease".  ``unregister()`` then released nothing: 7 PropertyGroups,
# 8 Menus, 6 pointer properties and 7 ``@persistent`` handlers stayed attached
# to a torn-down module, and the next enable terminated the process with
# EXCEPTION_ACCESS_VIOLATION.  A synthetic ``sys.modules`` entry survives both
# file loads and this package's own live-update submodule purge (which removes
# only ``<package>.`` keys), so the authoritative lease can always be
# re-published into the fresh driver namespace.
_ANCHOR_MODULE_NAME = "jelararagi_smart_cloth_suite_lease_anchor_v1"


def _anchor_store() -> dict[str, Any]:
    """Return this package's process-lifetime anchor dict.

    Scoped to Smart Cloth Suite alone -- never a shared cross-suite registry.
    """
    module = sys.modules.get(_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart Cloth Suite lease anchor. Keeps the exact resource lease "
            "reachable across Blender file loads, which replace "
            "bpy.app.driver_namespace. Not an importable module."
        )
        module.SCS_LEASE_ANCHOR = {}
        sys.modules[_ANCHOR_MODULE_NAME] = module
    store = getattr(module, "SCS_LEASE_ANCHOR", None)
    if not isinstance(store, dict):
        store = {}
        module.SCS_LEASE_ANCHOR = store
    return store


@dataclass
class ResourceRecord:
    kind: str
    scope: str
    identity: Any
    remover: Callable[[], None]
    active: bool = True


@dataclass
class Lease:
    owner_id: str
    contract_version: int
    generation: int
    module_token: object
    state: str = "REGISTERING"
    resources: list[ResourceRecord] = field(default_factory=list)
    rna: dict[tuple[int, str], Any] = field(default_factory=dict)
    classes: dict[int, type] = field(default_factory=dict)
    msgbus_owner: object = field(default_factory=object)
    release: Callable[..., None] | None = None


_CURRENT_LEASE: Lease | None = None


def _namespace() -> dict[str, Any]:
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    if not isinstance(namespace, dict):
        raise RuntimeError("Blender driver namespace is unavailable")
    return namespace


def _lease_attr(lease: Any, name: str, default: Any = None) -> Any:
    try:
        return getattr(lease, name)
    except Exception:
        return default


def _class_rna_identity(cls: type) -> Any:
    """Return only RNA attached to this exact class, never an inherited base."""
    try:
        return vars(cls).get("bl_rna", _MISSING)
    except Exception:
        return _MISSING


def _is_our_lease(lease: Any) -> bool:
    return bool(
        lease is not None
        and _lease_attr(lease, "owner_id") == OWNER_ID
        and int(_lease_attr(lease, "contract_version", -1)) == CONTRACT_VERSION
        and callable(_lease_attr(lease, "release"))
    )


def _live_lease_state(lease: Any) -> bool:
    return bool(_lease_attr(lease, "state") in {"REGISTERING", "READY"})


def _published_lease() -> Any:
    """Return the lease published for this package, healing a replaced dict.

    A file load hands us a fresh, empty ``driver_namespace``.  Absence of the
    key is therefore never evidence that the generation ended -- only a
    *different* live lease being published is.  When the key is missing this
    re-publishes the authoritative object: this module's own live lease first,
    then the anchored one (which is how a live-update submodule purge is
    survived).  A genuinely foreign or already-released lease is never revived.
    """
    namespace = _namespace()
    value = namespace.get(LEASE_KEY)
    if value is None:
        for candidate in (_CURRENT_LEASE, _anchor_store().get(LEASE_KEY)):
            if _is_our_lease(candidate) and _live_lease_state(candidate):
                namespace[LEASE_KEY] = candidate
                value = candidate
                break
    if value is not None:
        # Keep the anchor pointing at the exact live object, including one
        # created or adopted by another generation of this suite.
        _anchor_store()[LEASE_KEY] = value
    return value


def current_lease(*, require_current: bool = True) -> Lease | None:
    lease = _CURRENT_LEASE
    if lease is None:
        return None
    if require_current:
        try:
            # Strict identity is still the ownership guarantee: if a different
            # live lease is published, this generation has genuinely been
            # handed off and must not release another generation's resources.
            if _published_lease() is not lease:
                return None
        except Exception:
            return None
    return lease


def current_module_owns_lease(lease: Lease | None = None) -> bool:
    """Return whether this imported lifecycle module owns the exact lease."""
    lease = lease or current_lease(require_current=False)
    return bool(lease is not None and _lease_attr(lease, "module_token") is _MODULE_TOKEN)


@persistent
def _rearm_after_load(*_args) -> None:
    """Re-publish the exact lease after Blender replaces driver_namespace.

    Reading the lease is what re-arms it (see ``_published_lease``), so the
    load event itself restores the resource-owning generation rather than
    leaving it to whichever caller happens to touch it first.  This never
    raises: a ``@persistent`` handler that escapes would abort the remaining
    load_post handlers, including foreign add-ons' and the suite's own.
    """
    try:
        current_lease()
    except Exception:
        pass


def _arm_load_post_rearm() -> None:
    """Journal the load_post re-arm as this generation's first acquisition.

    Recorded through ``register_handler`` like every other resource, so
    ``unregister()`` retires it with the rest of the lease -- an orphaned
    persistent handler is exactly the failure this fix exists to remove.
    """
    collection = bpy.app.handlers.load_post
    # Only this module's own exact callable identity is ever reclaimed.
    while _rearm_after_load in collection:
        collection.remove(_rearm_after_load)
    register_handler(collection, _rearm_after_load, scope="lifecycle.rearm")


def sweep_dormant_package_handlers() -> list[str]:
    """Detach this package's app handlers when no lease can be resolved.

    Dormant-safe teardown backstop.  A lease-less unregister that leaves
    ``@persistent`` handlers attached turns a dormant generation into a crash:
    they keep firing on every later load and save against a torn-down module.
    Ownership evidence is the callback's ``__module__`` -- this package's own
    module tree only, never a name match and never a foreign callable.
    """
    removed: list[str] = []
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is None:
        return removed
    for attribute in dir(handlers):
        if attribute.startswith("_"):
            continue
        try:
            collection = getattr(handlers, attribute)
        except Exception:
            continue
        if not isinstance(collection, list):
            continue
        for callback in tuple(collection):
            try:
                if not _module_belongs_to_this_suite(getattr(callback, "__module__", "")):
                    continue
                collection.remove(callback)
            except Exception:
                continue
            removed.append(f"{attribute}.{getattr(callback, '__name__', '?')}")
    return removed


def begin_generation() -> tuple[Lease, bool]:
    """Acquire the package lease.

    Returns ``(lease, acquired)``. A repeated register call in the same module
    generation is an exact no-op. An overlapping import preserves the current
    REGISTERING/READY generation; a new generation is created only after the
    current lease has been released by its owning module.
    """

    global _CURRENT_LEASE
    namespace = _namespace()
    # Resolve through the anchor: after a file load the namespace is empty, and
    # taking that as "no generation" is what minted a second generation on top
    # of still-registered classes and terminated the process.
    existing = _published_lease()

    if existing is not None:
        if not _is_our_lease(existing):
            raise RuntimeError("Smart Cloth Suite resource lease is owned by foreign code")
        # Repeated register and an overlapping module reload are exact no-ops.
        # Keeping the READY lease avoids blanking visible Panels if a competing
        # generation is imported before Blender has called the old unregister.
        # Normal disable/enable and Blender's orderly reload release the old
        # lease first, after which a new generation is acquired below.
        if _lease_attr(existing, "state") in {"REGISTERING", "READY"}:
            _CURRENT_LEASE = existing
            return existing, False
        release = _lease_attr(existing, "release")
        release(reason="retire_noncurrent")
        if namespace.get(LEASE_KEY) is existing:
            namespace.pop(LEASE_KEY, None)

    anchor = _anchor_store()
    # The counter is anchored as well; a file load must not rewind generation
    # numbers, because the class ownership tags are keyed on them.
    generation = max(
        int(namespace.get(GENERATION_KEY, 0) or 0),
        int(anchor.get(GENERATION_KEY, 0) or 0),
    ) + 1
    namespace[GENERATION_KEY] = generation
    anchor[GENERATION_KEY] = generation
    lease = Lease(
        owner_id=OWNER_ID,
        contract_version=CONTRACT_VERSION,
        generation=generation,
        module_token=_MODULE_TOKEN,
    )
    lease.release = lambda *, reason="unregister", _lease=lease: _release_lease(_lease, reason=reason)
    namespace[LEASE_KEY] = lease
    anchor[LEASE_KEY] = lease
    _CURRENT_LEASE = lease
    _arm_load_post_rearm()
    return lease, True


def mark_ready(lease: Lease) -> None:
    if _published_lease() is not lease:
        raise RuntimeError("Smart Cloth Suite generation lost ownership before READY")
    if lease.state != "REGISTERING":
        raise RuntimeError(f"Invalid Smart Cloth Suite lifecycle state: {lease.state}")
    validate_required_identities(lease)
    lease.state = "READY"


def validate_required_identities(lease: Lease | None = None) -> None:
    lease = lease or current_lease()
    if lease is None:
        raise RuntimeError("Smart Cloth Suite lease is not active")
    for record in tuple(lease.resources):
        if not record.active:
            continue
        if record.kind == "CLASS":
            cls = record.identity
            if lease.classes.get(id(cls)) is not cls:
                raise RuntimeError("Class identity ledger mismatch")
            if getattr(cls, "_scs_owner_id", None) != OWNER_ID:
                raise RuntimeError(f"Class owner mismatch: {getattr(cls, '__name__', '<unknown>')}")
            if int(getattr(cls, "_scs_generation", -1)) != lease.generation:
                raise RuntimeError(f"Class generation mismatch: {getattr(cls, '__name__', '<unknown>')}")
            if _class_rna_identity(cls) is _MISSING:
                raise RuntimeError(f"Class did not acquire exact RNA: {getattr(cls, '__name__', '<unknown>')}")
        elif record.kind == "RNA":
            owner, name, descriptor = record.identity
            current = vars(owner).get(name, _MISSING)
            if current is not descriptor:
                raise RuntimeError(f"RNA identity mismatch: {getattr(owner, '__name__', owner)}.{name}")
            if lease.rna.get((id(owner), name), _MISSING) is not descriptor:
                raise RuntimeError(f"RNA ledger mismatch: {getattr(owner, '__name__', owner)}.{name}")


def checkpoint() -> int:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Smart Cloth Suite lease is not active")
    return len(lease.resources)


def rollback_to(mark: int) -> None:
    lease = current_lease()
    if lease is None:
        return
    mark = max(0, min(int(mark), len(lease.resources)))
    for record in reversed(lease.resources[mark:]):
        _release_record(record)
    del lease.resources[mark:]
    _prune_ledgers(lease)


def release_scope(scope: str) -> None:
    lease = current_lease(require_current=False)
    if lease is None:
        return
    target = str(scope or "")
    for record in reversed(tuple(lease.resources)):
        if record.active and record.scope == target:
            _release_record(record)
    _prune_ledgers(lease)


def release_current(*, reason: str = "unregister") -> None:
    lease = current_lease(require_current=False)
    if lease is not None and callable(lease.release):
        lease.release(reason=reason)


def _release_record(record: ResourceRecord) -> None:
    if not record.active:
        return
    try:
        record.remover()
    finally:
        record.active = False


def _prune_ledgers(lease: Lease) -> None:
    active_classes = {
        id(record.identity): record.identity
        for record in lease.resources
        if record.active and record.kind == "CLASS"
    }
    active_rna = {
        (id(owner), name): descriptor
        for record in lease.resources
        if record.active and record.kind == "RNA"
        for owner, name, descriptor in (record.identity,)
    }
    lease.classes.clear()
    lease.classes.update(active_classes)
    lease.rna.clear()
    lease.rna.update(active_rna)


def _release_lease(lease: Lease, *, reason: str = "unregister") -> None:
    del reason
    global _CURRENT_LEASE
    if lease.state == "RELEASED":
        return
    lease.state = "RELEASING"
    for record in reversed(tuple(lease.resources)):
        try:
            _release_record(record)
        except Exception:
            # Release continues so a single invalid Blender resource cannot leak
            # the remaining exact identities.  No foreign lookup or name-based
            # fallback is performed.
            pass
    lease.resources.clear()
    lease.classes.clear()
    lease.rna.clear()
    lease.state = "RELEASED"
    try:
        namespace = _namespace()
        if namespace.get(LEASE_KEY) is lease:
            namespace.pop(LEASE_KEY, None)
    except Exception:
        pass
    try:
        # Retire the anchor with the lease, otherwise a released generation
        # would be revived into the next fresh driver namespace.
        anchor = _anchor_store()
        if anchor.get(LEASE_KEY) is lease:
            anchor.pop(LEASE_KEY, None)
    except Exception:
        pass
    if _CURRENT_LEASE is lease:
        _CURRENT_LEASE = None


def register_class(cls: type, *, scope: str) -> type:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot register class without the current Smart Cloth Suite lease")
    existing = lease.classes.get(id(cls))
    if existing is cls and _class_rna_identity(cls) is not _MISSING:
        return cls

    setattr(cls, "_scs_owner_id", OWNER_ID)
    setattr(cls, "_scs_generation", lease.generation)
    try:
        bpy.utils.register_class(cls)
    except Exception:
        # Some Blender registration failures occur after RNA was attached. Only
        # the exact class identity tagged by this generation may be unwound.
        if (
            getattr(cls, "_scs_owner_id", None) == OWNER_ID
            and int(getattr(cls, "_scs_generation", -1)) == lease.generation
            and _class_rna_identity(cls) is not _MISSING
        ):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        raise
    if _class_rna_identity(cls) is _MISSING:
        try:
            bpy.utils.unregister_class(cls)
        finally:
            raise RuntimeError(f"Blender did not register exact class RNA: {getattr(cls, '__name__', '<unknown>')}")

    def remove(_cls=cls, _generation=lease.generation) -> None:
        if getattr(_cls, "_scs_owner_id", None) != OWNER_ID:
            return
        if int(getattr(_cls, "_scs_generation", -1)) != _generation:
            return
        if _class_rna_identity(_cls) is _MISSING:
            return
        bpy.utils.unregister_class(_cls)

    record = ResourceRecord("CLASS", str(scope), cls, remove)
    lease.resources.append(record)
    lease.classes[id(cls)] = cls
    return cls


def _module_belongs_to_this_suite(module_name: str) -> bool:
    package_name = str(__package__ or "")
    module_name = str(module_name or "")
    return bool(
        package_name
        and (module_name == package_name or module_name.startswith(package_name + "."))
    )


def _value_references_this_suite(value: Any, *, depth: int = 0) -> bool:
    """Return whether a deferred-property keyword references this package.

    Pointer/Collection properties retain their PropertyGroup ``type`` class.
    Scalar properties retain callbacks such as ``update``/``get``/``set``.
    Those exact Python identities provide ownership evidence after an
    install-over-active reload without relying on the RNA name alone.
    """
    if depth > 2:
        return False
    if isinstance(value, dict):
        return any(
            _value_references_this_suite(item, depth=depth + 1)
            for item in value.values()
        )
    if isinstance(value, (tuple, list, set, frozenset)):
        return any(
            _value_references_this_suite(item, depth=depth + 1)
            for item in value
        )
    try:
        module_name = str(getattr(value, "__module__", "") or "")
    except Exception:
        module_name = ""
    return _module_belongs_to_this_suite(module_name)


def _is_stale_suite_rna(
    descriptor: Any,
    deferred_property: Any,
    property_name: str,
) -> bool:
    """Return whether *descriptor* is orphaned RNA from this package.

    Blender may leave dynamic RNA behind during install-over-active/live reload.
    Replacement is allowed only when the existing deferred descriptor has the
    same property constructor as the incoming definition and its retained type
    or callback identity belongs to this Smart Cloth Suite package.  Same-named
    RNA from Blender or another add-on is never claimed.
    """
    try:
        keywords = getattr(descriptor, "keywords", None)
        incoming_keywords = getattr(deferred_property, "keywords", None)
    except Exception:
        return False
    if not isinstance(keywords, dict) or not isinstance(incoming_keywords, dict):
        return False

    expected_name = str(property_name or "")
    for values in (keywords, incoming_keywords):
        try:
            attr_name = str(values.get("attr", "") or "")
        except Exception:
            return False
        if attr_name and attr_name != expected_name:
            return False

    try:
        current_function = getattr(descriptor, "function", None)
        incoming_function = getattr(deferred_property, "function", None)
    except Exception:
        return False
    if current_function is not incoming_function:
        try:
            current_name = str(getattr(current_function, "__name__", "") or "")
            incoming_name = str(getattr(incoming_function, "__name__", "") or "")
        except Exception:
            return False
        if not current_name or current_name != incoming_name:
            return False

    for keyword in ("type", "update", "get", "set", "poll", "search", "items"):
        if keyword in keywords and _value_references_this_suite(keywords.get(keyword)):
            return True
    return False


def register_rna(owner: type, name: str, deferred_property: Any, *, scope: str) -> Any:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot register RNA without the current Smart Cloth Suite lease")
    name = str(name or "").strip()
    if not name:
        raise ValueError("RNA property name is empty")
    key = (id(owner), name)
    known = lease.rna.get(key, _MISSING)
    current = vars(owner).get(name, _MISSING)
    if known is not _MISSING and current is known:
        return known
    if current is not _MISSING:
        if known is _MISSING and _is_stale_suite_rna(current, deferred_property, name):
            try:
                delattr(owner, name)
            except Exception as exc:
                raise RuntimeError(
                    f"Could not retire stale Smart Cloth RNA: {getattr(owner, '__name__', owner)}.{name}"
                ) from exc
        else:
            raise RuntimeError(f"Refusing to replace foreign RNA: {getattr(owner, '__name__', owner)}.{name}")

    try:
        setattr(owner, name, deferred_property)
    except Exception:
        descriptor = vars(owner).get(name, _MISSING)
        if descriptor is not _MISSING:
            try:
                if vars(owner).get(name, _MISSING) is descriptor:
                    delattr(owner, name)
            except Exception:
                pass
        raise
    descriptor = vars(owner).get(name, _MISSING)
    if descriptor is _MISSING:
        raise RuntimeError(f"RNA assignment failed: {getattr(owner, '__name__', owner)}.{name}")

    def remove(_owner=owner, _name=name, _descriptor=descriptor) -> None:
        if vars(_owner).get(_name, _MISSING) is _descriptor:
            delattr(_owner, _name)

    identity = (owner, name, descriptor)
    lease.resources.append(ResourceRecord("RNA", str(scope), identity, remove))
    lease.rna[key] = descriptor
    return descriptor


def register_handler(collection: Any, callback: Callable[..., Any], *, scope: str) -> Callable[..., Any]:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot register handler without the current Smart Cloth Suite lease")
    for record in lease.resources:
        if record.active and record.kind == "HANDLER" and record.identity == (collection, callback):
            return callback
    if callback in collection:
        raise RuntimeError("Refusing to claim a pre-existing handler identity")
    collection.append(callback)

    def remove(_collection=collection, _callback=callback) -> None:
        if _callback in _collection:
            _collection.remove(_callback)

    lease.resources.append(ResourceRecord("HANDLER", str(scope), (collection, callback), remove))
    return callback


def register_msgbus(*, key: Any, notify: Callable[..., Any], scope: str, args: tuple[Any, ...] = (), options: set[str] | None = None) -> object:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot register message bus without the current Smart Cloth Suite lease")
    owner = lease.msgbus_owner
    bpy.msgbus.subscribe_rna(
        key=key,
        owner=owner,
        args=tuple(args),
        notify=notify,
        options=set(options or ()),
    )

    # One clear-by-owner record is enough for all subscriptions in this lease.
    for record in lease.resources:
        if record.active and record.kind == "MSGBUS" and record.identity is owner:
            return owner

    def remove(_owner=owner) -> None:
        bpy.msgbus.clear_by_owner(_owner)

    lease.resources.append(ResourceRecord("MSGBUS", str(scope), owner, remove))
    return owner


def register_draw_handler(space_type: Any, callback: Callable[..., Any], args: tuple[Any, ...], region_type: str, draw_type: str, *, scope: str) -> Any:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot register draw handler without the current Smart Cloth Suite lease")
    handle = space_type.draw_handler_add(callback, tuple(args), str(region_type), str(draw_type))

    def remove(_space=space_type, _handle=handle, _region=str(region_type)) -> None:
        _space.draw_handler_remove(_handle, _region)

    lease.resources.append(ResourceRecord("DRAW_HANDLER", str(scope), handle, remove))
    return handle


def record_cleanup(identity: Any, remover: Callable[[], None], *, scope: str, kind: str = "RESOURCE") -> Any:
    lease = current_lease()
    if lease is None:
        raise RuntimeError("Cannot record cleanup without the current Smart Cloth Suite lease")
    lease.resources.append(ResourceRecord(str(kind), str(scope), identity, remover))
    return identity


def register_translation(owner: str, payload: Any, *, scope: str) -> str:
    """Replace one exact Smart Cloth translation owner and journal teardown."""
    owner = str(owner or "").strip()
    if not owner:
        raise ValueError("Smart Cloth translation owner is empty")
    translations = getattr(getattr(bpy, "app", None), "translations", None)
    native_register = getattr(translations, "register", None)
    native_unregister = getattr(translations, "unregister", None)
    if not callable(native_register) or not callable(native_unregister):
        raise RuntimeError("Blender translations API is unavailable")
    # Blender keeps this cache independently from Python module generations.
    # The owner keys used here are all fixed Smart Cloth package namespaces.
    try:
        native_unregister(owner)
    except (KeyError, RuntimeError, ValueError):
        pass
    native_register(owner, payload)

    def remove_translation(_owner=owner, _unregister=native_unregister) -> None:
        try:
            _unregister(_owner)
        except (KeyError, RuntimeError, ValueError):
            pass

    record_cleanup(
        ("translations", owner),
        remove_translation,
        scope=str(scope),
        kind="TRANSLATION",
    )
    return owner


def resource_counts(lease: Lease | None = None) -> dict[str, int]:
    lease = lease or current_lease(require_current=False)
    counts: dict[str, int] = {}
    if lease is None:
        return counts
    for record in lease.resources:
        if record.active:
            counts[record.kind] = counts.get(record.kind, 0) + 1
    return counts
