"""Native garment analysis and simulation controls; delegate vendor features to installed operators."""
import bpy,bmesh,json,re
from mathutils import Vector
from pathlib import Path
from contextlib import contextmanager
from . import persistence,skirt
from .core import integration
PREVIEW='_smart_cloth_suite_preview_v1'
QUALITY={'PREVIEW':(4,2,.85),'BALANCED':(8,4,.75),'PRODUCTION':(12,6,.65),'HERO':(20,8,.55)}
def meshes(ctx,c):
    pool=[ctx.object] if c.target_scope=='ACTIVE' else ctx.scene.objects if c.target_scope=='ALL' else ctx.selected_objects
    return [o for o in pool if o and o.type=='MESH']
def cloth(o):return next((m for m in o.modifiers if m.type=='CLOTH'),None)
@contextmanager
def selected(ctx,obj):
    previous=list(ctx.selected_objects);active=ctx.view_layer.objects.active
    try:
        for o in previous:o.select_set(False)
        obj.select_set(True);ctx.view_layer.objects.active=obj
        with ctx.temp_override(object=obj,active_object=obj,selected_objects=[obj],selected_editable_objects=[obj]):yield
    finally:
        for o in ctx.selected_objects:o.select_set(False)
        for o in previous:o.select_set(True)
        ctx.view_layer.objects.active=active
def quality(c,m):
    n,col,t=QUALITY[c.quality_profile];m.settings.quality=n;m.settings.time_scale=t;m.collision_settings.collision_quality=col;m.collision_settings.use_collision=True;m.collision_settings.use_self_collision=c.enable_self_collision
def edge_length(obj):
    vs=obj.data.vertices;rot=obj.matrix_world.to_3x3()
    return sum((rot@(vs[a].co-vs[b].co)).length for a,b in (e.vertices for e in obj.data.edges))/max(1,len(obj.data.edges))
def auto(c,o,m):
    d=max(c.min_collision_distance,min(c.max_collision_distance,edge_length(o)*c.collision_distance_factor))
    m.collision_settings.distance_min=d;m.collision_settings.self_distance_min=d*1.25
def colliders(c):
    objs=list(c.collider_collection.all_objects) if c.collider_collection else []
    if c.body_object and c.body_object not in objs:objs.append(c.body_object)
    return [o for o in objs if o.type=='MESH']
def add_colliders(ctx,targets):
    for obj in targets:
        if any(m.type=='COLLISION' for m in obj.modifiers):continue
        with selected(ctx,obj):
            if integration.external_status().ready:integration.call_external_operator('object.simply_collision_manager',ctx,mode='ADDNEW')
            if not any(m.type=='COLLISION' for m in obj.modifiers):obj.modifiers.new('Smart Cloth Collision','COLLISION')
def maps(c,o,ctx):
    data=o.data;world=o.matrix_world;scale=c.analysis_proximity_distance;neighbors=[[]for _ in data.vertices]
    for edge in data.edges:
        a,b=edge.vertices;neighbors[a].append(b);neighbors[b].append(a)
    targets=[v.evaluated_get(ctx.evaluated_depsgraph_get())for v in colliders(c) if v!=o];heights=[(world@v.co).z for v in data.vertices]
    if not heights:return
    low=min(heights);rng=max(1e-7,max(heights)-low)
    groups=[o.vertex_groups.get(n) or o.vertex_groups.new(name=n) for n in ('SCSuite_CurvatureRisk','SCSuite_PinSuggestion','SCSuite_CollisionProximity')]
    for i,v in enumerate(data.vertices):
        ns=neighbors[i];curve=sum(1-v.normal.dot(data.vertices[k].normal) for k in ns)/max(1,len(ns));near=0;pt=world@v.co
        for item in targets:
            ok,q,_,_=item.closest_point_on_mesh(item.matrix_world.inverted_safe()@pt)
            if ok:near=max(near,1-(pt-item.matrix_world@q).length/max(.000001,scale))
        vals=(min(1,max(0,curve)),(heights[i]-low)/rng,max(0,min(1,near)))
        for grp,value in zip(groups,vals):grp.add([i],value,'REPLACE')
def check(ctx,c,targets):
    errors=[];warnings=[]
    for obj in targets:
        m=cloth(obj)
        if not m:errors.append(obj.name+' · no Cloth');continue
        if m.settings.vertex_group_mass and not obj.vertex_groups.get(m.settings.vertex_group_mass):errors.append(obj.name+' · missing pin group')
        if not m.settings.vertex_group_mass:warnings.append(obj.name+' · no pins')
        if not m.point_cache.is_baked:warnings.append(obj.name+' · unbaked cache')
    if not targets:errors.append('Select one or more garment meshes.')
    report=dict(errors=errors,warnings=warnings,objects=[x.name for x in targets],frame=ctx.scene.frame_current)
    path=persistence.folder()/'reports'/('preflight.'+('json' if c.report_format=='JSON' else 'txt'))
    if c.report_format=='JSON':persistence.atomic(path,report)
    else:path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n'.join(errors+warnings) or 'OK','utf8')
    c.last_report_path=str(path);c.last_status=f'{len(errors)} errors / {len(warnings)} warnings';return errors
def setup(ctx,c,targets):
    if not integration.external_status(force=True).ready:raise ValueError('Enable Simply Cloth Studio to use Smart Setup.')
    garment=[o for o in targets if o not in colliders(c)]
    if not garment:raise ValueError('Select a garment.')
    for o in garment:
        m=cloth(o)
        if not m:
            with selected(ctx,o):result=integration.call_external_operator('object.create_cloth',ctx,mode='CREATECLOTH',modifiers_handling=c.external_modifiers_handling)
            m=cloth(o)
            if not m or 'FINISHED' not in result:raise ValueError('The provider did not create Cloth.')
        if c.apply_profile_after_setup:quality(c,m)
        if c.auto_collision_after_setup:auto(c,o,m)
        if c.auto_pin_top and (not c.preserve_existing_pin or not m.settings.vertex_group_mass):m.settings.vertex_group_mass=skirt.pin(o,'SCSuite_PinTop',c.pin_band_ratio).name
    if c.apply_colliders_after_setup:add_colliders(ctx,colliders(c))
def execute(key,op,ctx):
    c=ctx.scene.smart_cloth_suite_companion;targets=meshes(ctx,c);scene=ctx.scene
    if key=='refresh_external_status':
        st=integration.external_status(force=True);c.last_status='Simply Cloth Studio '+st.version if st.ready else 'Simply Cloth Studio unavailable';return
    if key=='open_external_preferences':
        bpy.ops.screen.userpref_show('INVOKE_DEFAULT');ctx.preferences.active_section='ADDONS';return
    if key=='open_data_folder':
        path=persistence.folder();path.mkdir(parents=True,exist_ok=True);bpy.ops.wm.path_open(filepath=str(path));return
    if key=='smart_setup':setup(ctx,c,targets);return
    if key=='apply_colliders':add_colliders(ctx,colliders(c) or targets);return
    if key=='preflight':check(ctx,c,targets);return
    cloths=[(o,cloth(o)) for o in targets if cloth(o)]
    if key not in ('build_analysis_maps','repair_topology') and not cloths:raise ValueError('Select an object with a Cloth modifier.')
    if key=='layer_clearance':cloths.sort(key=lambda item:(sum((item[0].matrix_world@v.co).z for v in item[0].data.vertices)/max(1,len(item[0].data.vertices)),item[0].name))
    for i,(o,m) in enumerate(cloths):
        if key=='apply_quality_profile':quality(c,m)
        elif key=='auto_collision_distance':auto(c,o,m)
        elif key=='layer_clearance':
            d=max(c.min_collision_distance,min(c.max_collision_distance,m.collision_settings.distance_min+i*c.layer_gap));m.collision_settings.distance_min=d;m.collision_settings.self_distance_min=max(m.collision_settings.self_distance_min,d)
        elif key=='temporal_guard':
            f=scene.frame_current;start=max(scene.frame_start,f-c.motion_sample_frames)
            try:
                scene.frame_set(start);before=o.evaluated_get(ctx.evaluated_depsgraph_get());a=[before.matrix_world@v.co for v in before.data.vertices]
                scene.frame_set(f);after=o.evaluated_get(ctx.evaluated_depsgraph_get());drift=max(((after.matrix_world@v.co-p).length for v,p in zip(after.data.vertices,a)),default=0)/max(1,f-start)
            finally:scene.frame_set(f)
            m.collision_settings.distance_min=max(m.collision_settings.distance_min,min(c.max_collision_distance,drift*c.temporal_guard_multiplier))
        elif key=='batch_preview':
            if op.action=='APPLY':
                if PREVIEW not in o:o[PREVIEW]=json.dumps({'quality':m.settings.quality,'stack':skirt.stack(o)})
                m.settings.quality=c.preview_quality
                if c.preview_hide_heavy_modifiers:
                    for mod in o.modifiers:
                        if mod.type in ('SUBSURF','MULTIRES','CORRECTIVE_SMOOTH','SURFACE_DEFORM'):mod.show_viewport=False
            elif PREVIEW in o:
                original=json.loads(o[PREVIEW]);m.settings.quality=original['quality'];skirt.restore_stack(o,original['stack']);del o[PREVIEW]
    for o in targets:
        if key=='build_analysis_maps':maps(c,o,ctx)
        if key=='repair_topology' and not o.data.shape_keys:
            if o.data.users>1:o.data=o.data.copy()
            bm=bmesh.new()
            try:
                bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=max(.0000001,edge_length(o)*c.repair_merge_factor))
                if c.repair_remove_loose:bmesh.ops.delete(bm,geom=[v for v in bm.verts if not v.link_faces],context='VERTS')
                bm.to_mesh(o.data);o.data.update()
            finally:bm.free()
    c.last_status=f'{key.replace("_"," ")} · {len(targets)} mesh objects'
